package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"syscall"
	"time"
)

type Options struct {
	nonInteractive bool
	noProgress     bool
	summarize      bool
	apparent       bool
	noPrefix       bool
	showKib        bool
	si             bool
	reverse        bool
	noHidden       bool
	followSymlinks bool
	showDisks      bool
	writeConfig    bool
	depth          int
	top            int
	outputFile     string
	inputFile      string
	configFile     string
	logFile        string
	dbFile         string
	types          map[string]bool
	excludeTypes   map[string]bool
	ignoreDirs     []string
	ignorePatterns []*regexp.Regexp
	since          *time.Time
	until          *time.Time
	minAge         *time.Duration
	maxAge         *time.Duration
	path           string
}

type Node struct {
	Name     string  `json:"name"`
	ASize    int64   `json:"asize,omitempty"`
	DSize    int64   `json:"dsize,omitempty"`
	MTime    int64   `json:"mtime,omitempty"`
	NotReg   bool    `json:"notreg,omitempty"`
	Err      bool    `json:"err,omitempty"`
	Children []*Node `json:"-"`
	IsDir    bool    `json:"-"`
	Empty    bool    `json:"-"`
	Flag     string  `json:"-"`
	Path     string  `json:"-"`
	Items    int     `json:"-"`
}

func main() {
	opts, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
	if opts.showDisks {
		showDisks()
		return
	}
	if opts.writeConfig {
		if err := writeConfig(opts); err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
		return
	}
	var root *Node
	if opts.inputFile != "" {
		root, err = readJSON(opts.inputFile)
	} else {
		root, err = scan(opts.path, opts)
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, "Error:", err)
		os.Exit(1)
	}
	if opts.outputFile != "" {
		if err := writeJSON(opts.outputFile, root); err != nil {
			fmt.Fprintln(os.Stderr, "Error:", err)
			os.Exit(1)
		}
	}
	printReport(root, opts)
}

func parseArgs(args []string) (Options, error) {
	o := Options{path: ".", logFile: "/dev/null", configFile: defaultConfig(), ignoreDirs: []string{"/proc", "/dev", "/sys", "/run"}}
	o.types = map[string]bool{}
	o.excludeTypes = map[string]bool{}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			if i+1 < len(args) {
				o.path = args[i+1]
			}
			break
		}
		if !strings.HasPrefix(a, "-") || a == "-" {
			o.path = a
			continue
		}
		if strings.HasPrefix(a, "--") {
			name, val, hasVal := strings.Cut(a[2:], "=")
			next := func() (string, error) {
				if hasVal {
					return val, nil
				}
				if i+1 >= len(args) {
					return "", fmt.Errorf("flag needs an argument: --%s", name)
				}
				i++
				return args[i], nil
			}
			switch name {
			case "help":
				usage(os.Stdout)
				os.Exit(0)
			case "version":
				version()
				os.Exit(0)
			case "archive-browsing", "collapse-path", "enable-profiling", "mouse", "no-color", "no-cross", "no-delete", "no-spawn-shell", "no-unicode", "read-from-storage", "sequential", "show-annexed-size", "show-apparent-size", "show-item-count", "show-mtime", "show-relative-size", "shared", "use-git-ignore":
				applyBool(name, &o)
			case "non-interactive":
				o.nonInteractive = true
			case "no-progress":
				o.noProgress = true
			case "summarize":
				o.summarize = true
			case "show-disks":
				o.showDisks = true
			case "no-hidden":
				o.noHidden = true
			case "follow-symlinks":
				o.followSymlinks = true
			case "no-prefix":
				o.noPrefix = true
			case "reverse-sort":
				o.reverse = true
			case "si":
				o.si = true
			case "show-in-kib":
				o.showKib = true
			case "write-config":
				o.writeConfig = true
			case "depth", "top", "max-cores":
				s, err := next()
				if err != nil {
					return o, err
				}
				n, err := strconv.Atoi(s)
				if err != nil {
					return o, fmt.Errorf("invalid argument %q for %q flag: strconv.ParseInt: parsing %q: invalid syntax", s, "--"+name, s)
				}
				if name == "depth" {
					o.depth = n
				} else if name == "top" {
					o.top = n
				}
			case "output-file", "input-file", "config-file", "log-file", "db", "storage", "style":
				s, err := next()
				if err != nil {
					return o, err
				}
				switch name {
				case "output-file":
					o.outputFile = s
				case "input-file":
					o.inputFile = s
				case "config-file":
					o.configFile = s
				case "log-file":
					o.logFile = s
				case "db":
					o.dbFile = s
				}
			case "type", "exclude-type", "ignore-dirs", "ignore-dirs-pattern", "ignore-from", "since", "until", "min-age", "max-age":
				s, err := next()
				if err != nil {
					return o, err
				}
				if err := applyValue(name, s, &o); err != nil {
					return o, err
				}
			default:
				return o, fmt.Errorf("unknown flag: --%s", name)
			}
			continue
		}
		for j := 1; j < len(a); j++ {
			c := a[j]
			needs := strings.ContainsRune("DfilmoEIXTt", rune(c))
			var val string
			if needs {
				if j+1 < len(a) {
					val = a[j+1:]
					j = len(a)
				} else {
					if i+1 >= len(args) {
						return o, fmt.Errorf("flag needs an argument: -%c", c)
					}
					i++
					val = args[i]
				}
			}
			switch c {
			case 'h':
				usage(os.Stdout)
				os.Exit(0)
			case 'v':
				version()
				os.Exit(0)
			case 'n':
				o.nonInteractive = true
			case 'p':
				o.noProgress = true
			case 's':
				o.summarize = true
			case 'a':
				o.apparent = true
			case 'k':
				o.showKib = true
			case 'd':
				o.showDisks = true
			case 'H':
				o.noHidden = true
			case 'L':
				o.followSymlinks = true
			case 'c', 'x', 'u', 'A', 'B', 'C', 'M', 'r', 'g':
			case 'D':
				o.dbFile = val
			case 'f':
				o.inputFile = val
			case 'o':
				o.outputFile = val
			case 'l':
				o.logFile = val
			case 'i':
				o.ignoreDirs = splitCSV(val)
			case 'I':
				if err := applyValue("ignore-dirs-pattern", val, &o); err != nil {
					return o, err
				}
			case 'X':
				if err := applyValue("ignore-from", val, &o); err != nil {
					return o, err
				}
			case 'T':
				for _, x := range splitCSV(val) {
					o.types[strings.TrimPrefix(x, ".")] = true
				}
			case 'E':
				for _, x := range splitCSV(val) {
					o.excludeTypes[strings.TrimPrefix(x, ".")] = true
				}
			case 't':
				n, err := strconv.Atoi(val)
				if err != nil {
					return o, err
				}
				o.top = n
			case 'm':
				_, err := strconv.Atoi(val)
				if err != nil {
					return o, err
				}
			default:
				return o, fmt.Errorf("unknown shorthand flag: %q in -%s", string(c), a[1:])
			}
		}
	}
	return o, nil
}

func applyBool(name string, o *Options) {
	switch name {
	case "show-apparent-size":
		o.apparent = true
	case "no-hidden":
		o.noHidden = true
	case "follow-symlinks":
		o.followSymlinks = true
	case "show-disks":
		o.showDisks = true
	}
}

func applyValue(name, val string, o *Options) error {
	switch name {
	case "type":
		for _, x := range splitCSV(val) {
			o.types[strings.TrimPrefix(x, ".")] = true
		}
	case "exclude-type":
		for _, x := range splitCSV(val) {
			o.excludeTypes[strings.TrimPrefix(x, ".")] = true
		}
	case "ignore-dirs":
		o.ignoreDirs = splitCSV(val)
	case "ignore-dirs-pattern":
		for _, p := range splitCSV(val) {
			re, err := regexp.Compile(p)
			if err != nil {
				return err
			}
			o.ignorePatterns = append(o.ignorePatterns, re)
		}
	case "ignore-from":
		b, err := os.ReadFile(val)
		if err != nil {
			return err
		}
		for _, line := range strings.Split(string(b), "\n") {
			line = strings.TrimSpace(line)
			if line == "" || strings.HasPrefix(line, "#") {
				continue
			}
			re, err := regexp.Compile(line)
			if err == nil {
				o.ignorePatterns = append(o.ignorePatterns, re)
			}
		}
	case "since", "until":
		t, err := parseWhen(val, name == "until")
		if err != nil {
			return err
		}
		if name == "since" {
			o.since = &t
		} else {
			o.until = &t
		}
	case "min-age", "max-age":
		d, err := parseDuration(val)
		if err != nil {
			return err
		}
		if name == "min-age" {
			o.minAge = &d
		} else {
			o.maxAge = &d
		}
	}
	return nil
}

func scan(path string, o Options) (*Node, error) {
	info, err := os.Lstat(path)
	if err != nil {
		return nil, err
	}
	abs, _ := filepath.Abs(path)
	n := makeNode(abs, info, o, true)
	if info.IsDir() {
		scanDir(n, abs, o, true)
	}
	return n, nil
}

func scanDir(n *Node, path string, o Options, isRoot bool) {
	entries, err := os.ReadDir(path)
	if err != nil {
		n.Err = true
		n.Flag = "!"
		return
	}
	for _, ent := range entries {
		full := filepath.Join(path, ent.Name())
		if shouldIgnore(full, ent.Name(), o, isRoot) {
			continue
		}
		info, err := os.Lstat(full)
		if err != nil {
			continue
		}
		mode := info.Mode()
		if mode&os.ModeSymlink != 0 && o.followSymlinks {
			if st, err := os.Stat(full); err == nil && !st.IsDir() {
				info = st
			}
		}
		child := makeNode(ent.Name(), info, o, false)
		child.Path = full
		if info.IsDir() {
			scanDir(child, full, o, false)
		}
		if includeNode(child, o) {
			n.Children = append(n.Children, child)
			n.ASize += child.ASize
			n.DSize += child.DSize
			n.Items += 1 + child.Items
			if child.MTime > n.MTime {
				n.MTime = child.MTime
			}
			if child.Err {
				n.Err = true
				if n.Flag == "" {
					n.Flag = "."
				}
			}
		}
	}
	n.Empty = len(n.Children) == 0
	if n.Empty && n.Flag == "" {
		n.Flag = "e"
	}
}

func makeNode(name string, info os.FileInfo, o Options, root bool) *Node {
	asize := info.Size()
	dsize := diskSize(info)
	notreg := !info.Mode().IsRegular() && !info.IsDir()
	if info.IsDir() {
		asize = info.Size()
	}
	flag := ""
	if notreg {
		flag = "@"
		if !o.followSymlinks {
			dsize = 0
		}
	}
	return &Node{Name: name, ASize: asize, DSize: dsize, MTime: info.ModTime().Unix(), NotReg: notreg, IsDir: info.IsDir(), Flag: flag, Path: name}
}

func includeNode(n *Node, o Options) bool {
	if n.IsDir {
		return true
	}
	ext := strings.TrimPrefix(strings.ToLower(filepath.Ext(n.Name)), ".")
	if len(o.types) > 0 && !o.types[ext] {
		return false
	}
	if o.excludeTypes[ext] {
		return false
	}
	t := time.Unix(n.MTime, 0)
	if o.since != nil && t.Before(*o.since) {
		return false
	}
	if o.until != nil && t.After(*o.until) {
		return false
	}
	now := time.Now()
	if o.maxAge != nil && now.Sub(t) > *o.maxAge {
		return false
	}
	if o.minAge != nil && now.Sub(t) < *o.minAge {
		return false
	}
	return true
}

func shouldIgnore(path, base string, o Options, isRoot bool) bool {
	if o.noHidden && strings.HasPrefix(base, ".") {
		return true
	}
	abs, _ := filepath.Abs(path)
	for _, ig := range o.ignoreDirs {
		if ig == "" {
			continue
		}
		if filepath.IsAbs(ig) {
			if abs == filepath.Clean(ig) || strings.HasPrefix(abs, filepath.Clean(ig)+string(os.PathSeparator)) {
				return true
			}
		} else if base == ig || (!isRoot && strings.Contains(abs, string(os.PathSeparator)+ig+string(os.PathSeparator))) {
			return true
		}
	}
	for _, re := range o.ignorePatterns {
		if re.MatchString(path) || re.MatchString(base) {
			return true
		}
	}
	return false
}

func diskSize(info os.FileInfo) int64 {
	if st, ok := info.Sys().(*syscall.Stat_t); ok {
		return st.Blocks * 512
	}
	return info.Size()
}

func printReport(root *Node, o Options) {
	if o.top > 0 {
		var files []*Node
		collectFiles(root, &files)
		sortNodes(files, o)
		if len(files) > o.top {
			files = files[:o.top]
		}
		for _, n := range files {
			fmt.Printf("%s %s\n", sizeField(sizeOf(n, o), o), n.Path)
		}
		return
	}
	if o.summarize {
		fmt.Printf("%s %s\n", sizeField(sizeOf(root, o), o), filepath.Base(root.Name))
		return
	}
	if o.depth > 0 {
		printDepth(root, o, 0)
		return
	}
	children := append([]*Node(nil), root.Children...)
	sortNodes(children, o)
	for _, n := range children {
		name := n.Name
		if n.IsDir {
			name = "/" + name
		}
		fmt.Printf("%s%s %s\n", flagField(n), sizeField(sizeOf(n, o), o), name)
	}
}

func printDepth(n *Node, o Options, level int) {
	fmt.Printf("%s %s\n", sizeFieldDepth(sizeOf(n, o), o), n.Path)
	if level >= o.depth {
		return
	}
	children := append([]*Node(nil), n.Children...)
	sortNodes(children, o)
	for _, c := range children {
		printDepth(c, o, level+1)
	}
}

func sortNodes(ns []*Node, o Options) {
	sort.SliceStable(ns, func(i, j int) bool {
		a, b := sizeOf(ns[i], o), sizeOf(ns[j], o)
		if a == b {
			if o.reverse {
				return ns[i].Name < ns[j].Name
			}
			return ns[i].Name > ns[j].Name
		}
		if o.reverse {
			return a < b
		}
		return a > b
	})
}

func collectFiles(n *Node, out *[]*Node) {
	for _, c := range n.Children {
		if c.IsDir {
			collectFiles(c, out)
		} else {
			*out = append(*out, c)
		}
	}
}

func sizeOf(n *Node, o Options) int64 {
	if o.apparent {
		return n.ASize
	}
	return n.DSize
}

func flagField(n *Node) string {
	if n.Flag == "" {
		return " "
	}
	return n.Flag
}

func sizeField(n int64, o Options) string {
	if o.noPrefix {
		return fmt.Sprintf("%10d", n)
	}
	return fmt.Sprintf("%10s", formatSize(n, o))
}

func sizeFieldDepth(n int64, o Options) string {
	if o.noPrefix {
		return fmt.Sprintf("%9d", n)
	}
	return fmt.Sprintf("%9s", formatSize(n, o))
}

func formatSize(n int64, o Options) string {
	if o.noPrefix {
		return strconv.FormatInt(n, 10)
	}
	if o.showKib {
		unit := "KiB"
		if o.si {
			unit = "kB"
		}
		return fmt.Sprintf("%.1f %s", float64(n)/1024.0, unit)
	}
	base := float64(1024)
	units := []string{"B", "KiB", "MiB", "GiB", "TiB", "PiB"}
	if o.si {
		base = 1000
		units = []string{"B", "kB", "MB", "GB", "TB", "PB"}
	}
	v := float64(n)
	idx := 0
	for v >= base && idx < len(units)-1 {
		v /= base
		idx++
	}
	if idx == 0 {
		return fmt.Sprintf("%d B", n)
	}
	return fmt.Sprintf("%.1f %s", v, units[idx])
}

func writeJSON(path string, root *Node) error {
	meta := map[string]any{"progname": "gdu", "progver": "dev", "timestamp": time.Now().Unix()}
	top := []any{float64(1), float64(2), meta, nodeJSON(root, true)}
	b, err := json.Marshal(top)
	if err != nil {
		return err
	}
	return os.WriteFile(path, b, 0644)
}

func nodeJSON(n *Node, root bool) any {
	m := map[string]any{"name": n.Name}
	if n.MTime != 0 {
		m["mtime"] = n.MTime
	}
	if !n.IsDir {
		if n.ASize != 0 {
			m["asize"] = n.ASize
		}
		if n.DSize != 0 {
			m["dsize"] = n.DSize
		}
		if n.NotReg {
			m["notreg"] = true
		}
		return m
	}
	arr := []any{m}
	for _, c := range n.Children {
		arr = append(arr, nodeJSON(c, false))
	}
	return arr
}

func readJSON(path string) (*Node, error) {
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	var v any
	if err := json.Unmarshal(b, &v); err != nil {
		return nil, err
	}
	arr, ok := v.([]any)
	if !ok {
		return nil, errors.New("invalid JSON")
	}
	var body any
	if len(arr) >= 4 {
		body = arr[3]
	} else {
		body = v
	}
	return parseNodeJSON(body, "", true)
}

func parseNodeJSON(v any, parent string, root bool) (*Node, error) {
	if arr, ok := v.([]any); ok {
		if len(arr) == 0 {
			return nil, errors.New("invalid JSON node")
		}
		head, ok := arr[0].(map[string]any)
		if !ok {
			return nil, errors.New("invalid JSON node")
		}
		n := nodeFromMap(head)
		n.IsDir = true
		if n.ASize == 0 {
			n.ASize = 4096
		}
		if n.DSize == 0 {
			n.DSize = 4096
		}
		if !root {
			n.Path = filepath.Join(parent, n.Name)
		} else {
			n.Path = n.Name
		}
		for _, cv := range arr[1:] {
			c, err := parseNodeJSON(cv, n.Path, false)
			if err != nil {
				return nil, err
			}
			n.Children = append(n.Children, c)
			n.ASize += c.ASize
			n.DSize += c.DSize
			n.Items += 1 + c.Items
			if c.MTime > n.MTime {
				n.MTime = c.MTime
			}
		}
		n.Empty = len(n.Children) == 0
		return n, nil
	}
	if m, ok := v.(map[string]any); ok {
		n := nodeFromMap(m)
		n.Path = filepath.Join(parent, n.Name)
		return n, nil
	}
	return nil, errors.New("invalid JSON node")
}

func nodeFromMap(m map[string]any) *Node {
	n := &Node{}
	if s, _ := m["name"].(string); s != "" {
		n.Name = s
	}
	n.ASize = intFromAny(m["asize"])
	n.DSize = intFromAny(m["dsize"])
	n.MTime = intFromAny(m["mtime"])
	if b, _ := m["notreg"].(bool); b {
		n.NotReg = true
		n.Flag = "@"
	}
	return n
}

func intFromAny(v any) int64 {
	switch x := v.(type) {
	case float64:
		return int64(x)
	case int64:
		return x
	case json.Number:
		i, _ := x.Int64()
		return i
	}
	return 0
}

func splitCSV(s string) []string {
	var out []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out = append(out, p)
		}
	}
	return out
}

func parseWhen(s string, until bool) (time.Time, error) {
	if t, err := time.Parse(time.RFC3339, s); err == nil {
		return t, nil
	}
	t, err := time.ParseInLocation("2006-01-02", s, time.Local)
	if err != nil {
		return time.Time{}, err
	}
	if until {
		t = t.Add(24*time.Hour - time.Nanosecond)
	}
	return t, nil
}

func parseDuration(s string) (time.Duration, error) {
	re := regexp.MustCompile(`(?i)(\d+)(y|mo|w|d|h|m|s)`)
	var total time.Duration
	pos := 0
	for _, m := range re.FindAllStringSubmatchIndex(s, -1) {
		if m[0] != pos {
			return 0, fmt.Errorf("invalid duration %q", s)
		}
		num, _ := strconv.Atoi(s[m[2]:m[3]])
		unit := strings.ToLower(s[m[4]:m[5]])
		switch unit {
		case "y":
			total += time.Duration(num) * 365 * 24 * time.Hour
		case "mo":
			total += time.Duration(num) * 30 * 24 * time.Hour
		case "w":
			total += time.Duration(num) * 7 * 24 * time.Hour
		case "d":
			total += time.Duration(num) * 24 * time.Hour
		case "h":
			total += time.Duration(num) * time.Hour
		case "m":
			total += time.Duration(num) * time.Minute
		case "s":
			total += time.Duration(num) * time.Second
		}
		pos = m[1]
	}
	if pos != len(s) || total == 0 {
		return 0, fmt.Errorf("invalid duration %q", s)
	}
	return total, nil
}

func defaultConfig() string {
	if h := os.Getenv("HOME"); h != "" {
		return filepath.Join(h, ".gdu.yaml")
	}
	return "$HOME/.gdu.yaml"
}

func writeConfig(o Options) error {
	path := o.configFile
	if path == "" {
		path = defaultConfig()
	}
	content := "no-color: false\nno-progress: false\nnon-interactive: false\n"
	return os.WriteFile(path, []byte(content), 0644)
}

func showDisks() {
	fmt.Println("   Device      Size      Used      Free Used% Mount point")
	data, err := os.ReadFile("/proc/mounts")
	if err != nil {
		return
	}
	seen := map[string]bool{}
	for _, line := range strings.Split(string(data), "\n") {
		f := strings.Fields(line)
		if len(f) < 2 || seen[f[1]] {
			continue
		}
		seen[f[1]] = true
		var st syscall.Statfs_t
		if err := syscall.Statfs(f[1], &st); err != nil {
			continue
		}
		size := int64(st.Blocks) * int64(st.Bsize)
		free := int64(st.Bavail) * int64(st.Bsize)
		used := size - free
		pct := 0
		if size > 0 {
			pct = int(float64(used) / float64(size) * 100)
		}
		fmt.Printf("%9s %9s %9s %9s %4d%% %s\n", f[0], formatSize(size, Options{}), formatSize(used, Options{}), formatSize(free, Options{}), pct, f[1])
	}
}

func usage(w io.Writer) {
	cores := runtime.NumCPU()
	fmt.Fprintln(w, "Pretty fast disk usage analyzer written in Go.")
	fmt.Fprintln(w)
	fmt.Fprintln(w, "Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.")
	fmt.Fprintln(w, "However HDDs work as well, but the performance gain is not so huge.")
	fmt.Fprintln(w)
	fmt.Fprintln(w, "Usage:")
	fmt.Fprintln(w, "  gdu [directory_to_scan] [flags]")
	fmt.Fprintln(w)
	fmt.Fprintln(w, "Flags:")
	fmt.Fprintln(w, "      --archive-browsing              Enable browsing of zip/jar archives")
	fmt.Fprintln(w, "      --collapse-path                 Collapse single-child directory chains")
	fmt.Fprintln(w, "      --config-file string            Read config from file (default is $HOME/.gdu.yaml)")
	fmt.Fprintln(w, "  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)")
	fmt.Fprintln(w, "      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)")
	fmt.Fprintln(w, "      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/")
	fmt.Fprintln(w, "  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)")
	fmt.Fprintln(w, "  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)")
	fmt.Fprintln(w, "  -h, --help                          help for gdu")
	fmt.Fprintln(w, "  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])")
	fmt.Fprintln(w, "  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)")
	fmt.Fprintln(w, "  -X, --ignore-from string            Read path patterns to ignore from file")
	fmt.Fprintln(w, "  -f, --input-file string             Import analysis from JSON file")
	fmt.Fprintln(w, "  -l, --log-file string               Path to a logfile (default \"/dev/null\")")
	fmt.Fprintln(w, "      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)")
	fmt.Fprintf(w, "  -m, --max-cores int                 Set max cores that Gdu will use. %d cores available (default %d)\n", cores, cores)
	fmt.Fprintln(w, "      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)")
	fmt.Fprintln(w, "      --mouse                         Use mouse")
	fmt.Fprintln(w, "  -c, --no-color                      Do not use colorized output")
	fmt.Fprintln(w, "  -x, --no-cross                      Do not cross filesystem boundaries")
	fmt.Fprintln(w, "      --no-delete                     Do not allow deletions")
	fmt.Fprintln(w, "  -H, --no-hidden                     Ignore hidden directories (beginning with dot)")
	fmt.Fprintln(w, "      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode")
	fmt.Fprintln(w, "  -p, --no-progress                   Do not show progress in non-interactive mode")
	fmt.Fprintln(w, "      --no-spawn-shell                Do not allow spawning shell")
	fmt.Fprintln(w, "  -u, --no-unicode                    Do not use Unicode symbols (for size bar)")
	fmt.Fprintln(w, "  -n, --non-interactive               Do not run in interactive mode")
	fmt.Fprintln(w, "  -o, --output-file string            Export all info into file as JSON")
	fmt.Fprintln(w, "  -r, --read-from-storage             Use existing database instead of re-scanning")
	fmt.Fprintln(w, "      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode")
	fmt.Fprintln(w, "      --sequential                    Use sequential scanning (intended for rotating HDDs)")
	fmt.Fprintln(w, "  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)")
	fmt.Fprintln(w, "  -a, --show-apparent-size            Show apparent size")
	fmt.Fprintln(w, "  -d, --show-disks                    Show all mounted disks")
	fmt.Fprintln(w, "  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode")
	fmt.Fprintln(w, "  -C, --show-item-count               Show number of items in directory")
	fmt.Fprintln(w, "  -M, --show-mtime                    Show latest mtime of items in directory")
	fmt.Fprintln(w, "  -B, --show-relative-size            Show relative size")
	fmt.Fprintln(w, "      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)")
	fmt.Fprintln(w, "      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)")
	fmt.Fprintln(w, "  -s, --summarize                     Show only a total in non-interactive mode")
	fmt.Fprintln(w, "  -t, --top int                       Show only top X largest files in non-interactive mode")
	fmt.Fprintln(w, "  -T, --type strings                  File types to include (e.g., --type yaml,json)")
	fmt.Fprintln(w, "      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD")
	fmt.Fprintln(w, "  -v, --version                       Print version")
	fmt.Fprintln(w, "      --write-config                  Write current configuration to file (default is $HOME/.gdu.yaml)")
}

func version() {
	fmt.Println("Version:\t dev")
	fmt.Println("Built time:\t Fri Apr 17 19:59:35 UTC 2026")
	fmt.Println("Built user:\t root")
}
