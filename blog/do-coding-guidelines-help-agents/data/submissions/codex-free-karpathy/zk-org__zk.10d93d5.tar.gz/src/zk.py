#!/usr/bin/env python3
import argparse
import datetime as _dt
import json
import os
import random
import re
import string
import subprocess
import sys
from pathlib import Path


TOP_HELP = """Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command."""

INIT_HELP = """Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation."""

INDEX_HELP = """Usage: zk index

Index the notes to be searchable.

You usually do not need to run `zk index` manually, as notes are indexed
automatically when needed.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress."""

NEW_HELP = """Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

Flags:
  -h, --help                   Show context-sensitive help.
      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually
                               the notebook where commands are run.
  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the
                               current working directory.
      --no-input               Never prompt or ask for confirmation.

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
                               Takes precedence over the config of the
                               directory.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value."""

LIST_HELP = """Usage: zk list [<path> ...]

List notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --mention=PATH,...           Find notes mentioning the title of the given
                                   ones.
      --mentioned-by=PATH,...      Find notes whose title is mentioned in the
                                   given ones.
  -l, --link-to=PATH,...           Find notes which are linking to the given
                                   ones.
      --no-link-to=PATH,...        Find notes which are not linking to the given
                                   notes.
  -L, --linked-by=PATH,...         Find notes which are linked by the given
                                   ones.
      --no-linked-by=PATH,...      Find notes which are not linked by the given
                                   ones.
      --orphan                     Find notes which are not linked by any other
                                   note.
      --tagless                    Find notes which have no tags.
      --missing-backlink           Find notes with at least one missing
                                   backlink.
      --related=PATH,...           Find notes which might be related to the
                                   given ones.
      --max-distance=COUNT         Maximum distance between two linked notes.
  -r, --recursive                  Follow links recursively.
      --created=DATE
      --created-before=DATE        Find notes created before the given date.
      --created-after=DATE         Find notes created after the given date.
      --modified=DATE              Find notes modified on the given date.
      --modified-before=DATE       Find notes modified before the given date.
      --modified-after=DATE        Find notes modified after the given date.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion."""

GRAPH_HELP = LIST_HELP.replace("Usage: zk list [<path> ...]", "Usage: zk graph --format=STRING [<path> ...]").replace("List notes matching the given criteria.", "Produce a graph of the notes matching the given criteria.").replace("Formatting\n  -f, --format=TEMPLATE    Pretty print the list using a custom template or one\n                           of the predefined formats: oneline, short, medium,\n                           long, full, json, jsonl.", "Formatting\n  -f, --format=STRING    Format of the graph among: json.").replace("      --header=STRING      Arbitrary text printed at the start of the list.\n      --footer=\"\\\\n\"       Arbitrary text printed at the end of the list.\n  -d, --delimiter=\"\\\\n\"     Print notes delimited by the given separator.\n  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This\n                           is useful when used in conjunction with `xargs -0`.\n  -P, --no-pager           Do not pipe output into a pager.\n", "")

EDIT_HELP = LIST_HELP.replace("Usage: zk list [<path> ...]", "Usage: zk edit [<path> ...]").replace("List notes matching the given criteria.", "Edit notes matching the given criteria.").replace("Formatting\n  -f, --format=TEMPLATE    Pretty print the list using a custom template or one\n                           of the predefined formats: oneline, short, medium,\n                           long, full, json, jsonl.\n      --header=STRING      Arbitrary text printed at the start of the list.\n      --footer=\"\\\\n\"       Arbitrary text printed at the end of the list.\n  -d, --delimiter=\"\\\\n\"     Print notes delimited by the given separator.\n  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This\n                           is useful when used in conjunction with `xargs -0`.\n  -P, --no-pager           Do not pipe output into a pager.\n  -q, --quiet              Do not print the total number of notes found.\n\n", "  -f, --force                Do not confirm before editing many notes at the\n                             same time.\n\n")

TAG_HELP = """Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation."""

TAG_LIST_HELP = """Usage: zk tag list

List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is
                           useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion."""

CONFIG = """# zk configuration file
#
# Uncomment the properties you want to customize.

[note]
template = "default.md"

[format.markdown]
link-format = "wiki"
hashtags = true
colon-tags = false
multiword-tags = false
"""

DEFAULT_TEMPLATE = "# {{title}}\n\n{{content}}\n"


def fail(msg, code=1):
    print(f"zk: error: {msg}", file=sys.stderr)
    return code


def unescape(s):
    return s.encode("utf-8").decode("unicode_escape")


def parse_global(argv):
    opts = {"notebook_dir": None, "working_dir": None, "no_input": False}
    out = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--notebook-dir":
            i += 1; opts["notebook_dir"] = argv[i]
        elif a.startswith("--notebook-dir="):
            opts["notebook_dir"] = a.split("=", 1)[1]
        elif a in ("-W", "--working-dir"):
            i += 1; opts["working_dir"] = argv[i]
        elif a.startswith("--working-dir="):
            opts["working_dir"] = a.split("=", 1)[1]
        elif a == "--no-input":
            opts["no_input"] = True
        else:
            out.append(a)
        i += 1
    if opts["working_dir"]:
        os.chdir(opts["working_dir"])
    return opts, out


def find_notebook(opts):
    if opts.get("notebook_dir"):
        p = Path(opts["notebook_dir"]).expanduser().resolve()
        if not (p / ".zk").is_dir():
            raise RuntimeError(f"failed to open notebook: no notebook found in {p} or a parent directory")
        return p
    cur = Path.cwd().resolve()
    for p in [cur] + list(cur.parents):
        if (p / ".zk").is_dir():
            return p
    raise RuntimeError(f"failed to open notebook: no notebook found in {cur} or a parent directory")


def read_config(root):
    cfg = {"filename": "{{id}}", "extension": "md", "template": "default.md"}
    path = root / ".zk" / "config.toml"
    try:
        text = path.read_text()
    except OSError:
        return cfg
    in_note = False
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("["):
            in_note = line == "[note]"
            continue
        if in_note and "=" in line:
            k, v = line.split("=", 1)
            k = k.strip()
            v = v.strip().strip('"').strip("'")
            if k in cfg:
                cfg[k] = v
    return cfg


def relpath(path, root):
    return path.relative_to(root).as_posix()


def title_from_text(text, fallback):
    m = re.search(r"(?m)^title:\s*['\"]?(.+?)['\"]?\s*$", text)
    if m:
        return m.group(1).strip()
    m = re.search(r"(?m)^#\s+(.+?)\s*$", text)
    if m:
        return re.sub(r"\s+#*$", "", m.group(1)).strip()
    return fallback


def tags_from_text(text):
    tags = set()
    for m in re.finditer(r"(?<![\w/])#([A-Za-z0-9][A-Za-z0-9_/-]*)", text):
        tags.add(m.group(1).strip("/"))
    for m in re.finditer(r":([A-Za-z0-9][A-Za-z0-9_-]*(?::[A-Za-z0-9][A-Za-z0-9_-]*)+):", text):
        for part in m.group(1).split(":"):
            tags.add(part)
    return sorted(t for t in tags if t)


def links_from_text(text):
    links = []
    for m in re.finditer(r"\[\[([^\]|#]+)(?:#[^\]|]+)?(?:\|[^\]]+)?\]\]", text):
        links.append(m.group(1).strip())
    for m in re.finditer(r"\[[^\]]+\]\(([^)]+)\)", text):
        target = m.group(1).split("#", 1)[0]
        if target and not re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", target):
            links.append(target)
    return links


def load_notes(root):
    notes = []
    for path in sorted(p for p in root.rglob("*") if p.is_file() and p.suffix.lower() in (".md", ".markdown")):
        if ".zk" in path.parts:
            continue
        try:
            text = path.read_text(errors="replace")
        except OSError:
            continue
        st = path.stat()
        rp = relpath(path, root)
        notes.append({
            "path": rp,
            "abs": path,
            "filename": path.name,
            "title": title_from_text(text, path.stem),
            "body": text,
            "tags": tags_from_text(text),
            "links": links_from_text(text),
            "created": _dt.datetime.fromtimestamp(st.st_ctime).isoformat(timespec="seconds"),
            "modified": _dt.datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds"),
        })
    return notes


def split_csv(values):
    out = []
    for v in values or []:
        out.extend([p for p in v.split(",") if p])
    return out


def note_matches_path(note, paths):
    if not paths:
        return True
    rp = note["path"]
    for p in paths:
        p = p.strip("/")
        if rp == p or rp.startswith(p.rstrip("/") + "/") or Path(rp).match(p):
            return True
    return False


def apply_filters(notes, args):
    paths = getattr(args, "paths", []) or []
    notes = [n for n in notes if note_matches_path(n, paths)]
    for ex in split_csv(getattr(args, "exclude", [])):
        notes = [n for n in notes if not note_matches_path(n, [ex])]
    for tag in split_csv(getattr(args, "tag", [])):
        tag = tag.lstrip("#")
        notes = [n for n in notes if tag in n["tags"]]
    if getattr(args, "tagless", False):
        notes = [n for n in notes if not n["tags"]]
    strategy = getattr(args, "match_strategy", "fts") or "fts"
    for q in split_csv(getattr(args, "match", [])):
        if strategy == "re":
            rx = re.compile(q, re.I)
            notes = [n for n in notes if rx.search(n["body"]) or rx.search(n["title"]) or rx.search(n["path"])]
        elif strategy == "exact":
            notes = [n for n in notes if q in n["body"] or q in n["title"] or q in n["path"]]
        else:
            terms = q.lower().split()
            notes = [n for n in notes if all(t in (n["body"] + " " + n["title"] + " " + n["path"]).lower() for t in terms)]
    if getattr(args, "orphan", False):
        linked = set()
        by_title = {n["title"].lower(): n["path"] for n in notes}
        by_stem = {Path(n["path"]).stem.lower(): n["path"] for n in notes}
        for n in notes:
            for l in n["links"]:
                key = l.removesuffix(".md").split("/")[-1].lower()
                if l in [m["path"] for m in notes]:
                    linked.add(l)
                elif key in by_stem:
                    linked.add(by_stem[key])
                elif l.lower() in by_title:
                    linked.add(by_title[l.lower()])
        notes = [n for n in notes if n["path"] not in linked]
    sort = split_csv(getattr(args, "sort", []))
    for term in reversed(sort or ["path"]):
        rev = term.endswith("-")
        key = term.rstrip("+-")
        notes.sort(key=lambda n: (n.get(key) or "").lower() if isinstance(n.get(key), str) else n.get(key), reverse=rev)
    lim = getattr(args, "limit", None)
    if lim is not None:
        notes = notes[:max(0, lim)]
    return notes


def init_cmd(opts, argv):
    if argv and argv[0] in ("-h", "--help"):
        print(INIT_HELP); return 0
    dest = Path(argv[0] if argv else ".").expanduser()
    (dest / ".zk" / "templates").mkdir(parents=True, exist_ok=True)
    (dest / ".zk" / "templates" / "default.md").write_text(DEFAULT_TEMPLATE)
    (dest / ".zk" / "config.toml").write_text(CONFIG)
    (dest / ".zk" / "notebook.db").touch()
    return 0


def index_cmd(opts, argv):
    if any(a in ("-h", "--help") for a in argv):
        print(INDEX_HELP); return 0
    try:
        root = find_notebook(opts)
    except RuntimeError as e:
        return fail(str(e))
    quiet = "-q" in argv or "--quiet" in argv
    verbose = "-v" in argv or "--verbose" in argv
    notes = load_notes(root)
    if verbose:
        for n in notes:
            print(f"indexed {n['path']}")
    if not quiet:
        print(f"{len(notes)} notes indexed")
    return 0


def slugify(s):
    s = s.lower()
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s or "untitled"


def render_template(tpl, data, extra):
    out = tpl
    for k, v in data.items():
        out = out.replace("{{" + k + "}}", str(v))
        out = out.replace("{{ " + k + " }}", str(v))
    for k, v in extra.items():
        out = out.replace("{{extra." + k + "}}", v)
        out = out.replace("{{ extra." + k + " }}", v)
    out = re.sub(r"{{\s*format-date\s+now\s*}}", data.get("date", ""), out)
    return out


def random_id():
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(4))


def new_cmd(opts, argv):
    if any(a in ("-h", "--help") for a in argv):
        print(NEW_HELP); return 0
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("directory", nargs="?")
    p.add_argument("-i", "--interactive", action="store_true")
    p.add_argument("-t", "--title")
    p.add_argument("--date")
    p.add_argument("-g", "--group")
    p.add_argument("--extra", action="append")
    p.add_argument("--template")
    p.add_argument("-p", "--print-path", action="store_true")
    p.add_argument("-n", "--dry-run", action="store_true")
    p.add_argument("--id")
    args = p.parse_args(argv)
    try:
        root = find_notebook(opts)
    except RuntimeError as e:
        return fail(str(e))
    title = args.title or "Untitled"
    content = sys.stdin.read() if args.interactive or not sys.stdin.isatty() else ""
    date = args.date or _dt.date.today().isoformat()
    nid = args.id or random_id()
    cfg = read_config(root)
    target_dir = root / (args.directory or "")
    extra = {}
    for item in split_csv(args.extra):
        if "=" in item:
            k, v = item.split("=", 1); extra[k] = v
    tpl_name = args.template or cfg["template"]
    tpl_path = Path(tpl_name).expanduser()
    if not tpl_path.is_absolute() and args.template:
        tpl_path = root / ".zk" / "templates" / tpl_name
    elif not tpl_path.is_absolute():
        tpl_path = root / ".zk" / "templates" / tpl_name
    try:
        tpl = tpl_path.read_text()
    except OSError:
        tpl = DEFAULT_TEMPLATE
    data = {"title": title, "content": content.rstrip("\n"), "id": nid, "slug": slugify(title), "date": date, "now": date}
    stem = render_template(cfg["filename"], data, extra).strip() or nid
    filename = f"{stem}.{cfg['extension'].lstrip('.')}"
    body = render_template(tpl, data, extra)
    path = target_dir / filename
    display = relpath(path, root)
    if args.dry_run:
        sys.stdout.write(body)
        if not body.endswith("\n"):
            sys.stdout.write("\n")
        print(display, file=sys.stderr)
        return 0
    target_dir.mkdir(parents=True, exist_ok=True)
    path.write_text(body)
    if args.print_path:
        print(display)
    else:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
        if editor:
            subprocess.call([editor, str(path)])
        else:
            print(display)
    return 0


def add_list_args(p):
    p.add_argument("paths", nargs="*")
    p.add_argument("-f", "--format", default="oneline")
    p.add_argument("--header", default="")
    p.add_argument("--footer", default="\n")
    p.add_argument("-d", "--delimiter", default="\n")
    p.add_argument("-0", "--delimiter0", action="store_true")
    p.add_argument("-P", "--no-pager", action="store_true")
    p.add_argument("-q", "--quiet", action="store_true")
    p.add_argument("-i", "--interactive", action="store_true")
    p.add_argument("-n", "--limit", type=int)
    p.add_argument("-m", "--match", action="append")
    p.add_argument("-M", "--match-strategy", choices=["fts", "re", "exact"], default="fts")
    p.add_argument("-x", "--exclude", action="append")
    p.add_argument("-t", "--tag", action="append")
    for name in ["mention", "mentioned-by", "link-to", "no-link-to", "linked-by", "no-linked-by", "related"]:
        p.add_argument("--" + name, action="append")
    p.add_argument("-l", dest="link_to_short", action="append")
    p.add_argument("-L", dest="linked_by_short", action="append")
    p.add_argument("--orphan", action="store_true")
    p.add_argument("--tagless", action="store_true")
    p.add_argument("--missing-backlink", action="store_true")
    p.add_argument("--max-distance", type=int)
    p.add_argument("-r", "--recursive", action="store_true")
    for name in ["created", "created-before", "created-after", "modified", "modified-before", "modified-after"]:
        p.add_argument("--" + name)
    p.add_argument("-s", "--sort", action="append")


def note_obj(n):
    return {"path": n["path"], "title": n["title"], "tags": n["tags"], "links": n["links"], "created": n["created"], "modified": n["modified"]}


def format_note(n, fmt):
    if fmt in ("oneline", "short"):
        return n["path"]
    if fmt == "medium":
        return f"{n['path']}\t{n['title']}"
    if fmt == "long":
        return f"{n['path']}\n  title: {n['title']}\n  tags: {', '.join(n['tags'])}"
    if fmt == "full":
        return n["body"].rstrip("\n")
    if "{{" in fmt:
        return render_template(fmt, {"path": n["path"], "title": n["title"], "filename": n["filename"]}, {})
    return n["path"]


def list_cmd(opts, argv):
    if any(a in ("-h", "--help") for a in argv):
        print(LIST_HELP); return 0
    p = argparse.ArgumentParser(add_help=False)
    add_list_args(p)
    args = p.parse_args(argv)
    try:
        notes = apply_filters(load_notes(find_notebook(opts)), args)
    except RuntimeError as e:
        return fail(str(e))
    fmt = args.format
    if fmt == "json":
        print(json.dumps([note_obj(n) for n in notes], ensure_ascii=False))
        return 0
    if fmt == "jsonl":
        for n in notes:
            print(json.dumps(note_obj(n), ensure_ascii=False))
        return 0
    delim = "\0" if args.delimiter0 else unescape(args.delimiter)
    parts = [format_note(n, fmt) for n in notes]
    sys.stdout.write(args.header)
    sys.stdout.write(delim.join(parts))
    if parts:
        sys.stdout.write(unescape(args.footer))
    return 0


def graph_cmd(opts, argv):
    if any(a in ("-h", "--help") for a in argv):
        print(GRAPH_HELP); return 0
    p = argparse.ArgumentParser(add_help=False)
    add_list_args(p)
    p.set_defaults(format=None)
    args = p.parse_args(argv)
    if args.format != "json":
        return fail("missing required flag --format")
    try:
        notes = apply_filters(load_notes(find_notebook(opts)), args)
    except RuntimeError as e:
        return fail(str(e))
    by_title = {n["title"].lower(): n["path"] for n in notes}
    by_stem = {Path(n["path"]).stem.lower(): n["path"] for n in notes}
    paths = {n["path"] for n in notes}
    links = []
    for n in notes:
        for l in n["links"]:
            key = l.removesuffix(".md").split("/")[-1].lower()
            to = l if l in paths else by_stem.get(key) or by_title.get(l.lower())
            if to:
                links.append({"source": n["path"], "target": to})
    print(json.dumps({"nodes": [note_obj(n) for n in notes], "links": links}, ensure_ascii=False))
    return 0


def edit_cmd(opts, argv):
    if any(a in ("-h", "--help") for a in argv):
        print(EDIT_HELP); return 0
    filtered = [a for a in argv if a not in ("-f", "--force")]
    p = argparse.ArgumentParser(add_help=False)
    add_list_args(p)
    args = p.parse_args(filtered)
    try:
        notes = apply_filters(load_notes(find_notebook(opts)), args)
    except RuntimeError as e:
        return fail(str(e))
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor:
        for n in notes:
            print(n["path"])
        return 0
    for n in notes:
        subprocess.call([editor, str(n["abs"])])
    return 0


def tag_cmd(opts, argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(TAG_HELP); return 0
    if argv[0] != "list":
        return fail(f"unexpected argument {argv[0]}")
    rest = argv[1:]
    if any(a in ("-h", "--help") for a in rest):
        print(TAG_LIST_HELP); return 0
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-f", "--format", default="name")
    p.add_argument("--header", default="")
    p.add_argument("--footer", default="\n")
    p.add_argument("-d", "--delimiter", default="\n")
    p.add_argument("-0", "--delimiter0", action="store_true")
    p.add_argument("-P", "--no-pager", action="store_true")
    p.add_argument("-q", "--quiet", action="store_true")
    p.add_argument("-s", "--sort", action="append")
    args = p.parse_args(rest)
    try:
        notes = load_notes(find_notebook(opts))
    except RuntimeError as e:
        return fail(str(e))
    counts = {}
    for n in notes:
        for t in n["tags"]:
            counts[t] = counts.get(t, 0) + 1
    tags = [{"name": k, "note-count": v, "note_count": v} for k, v in sorted(counts.items())]
    if args.sort:
        for term in reversed(split_csv(args.sort)):
            rev = term.endswith("-")
            key = term.rstrip("+-")
            tags.sort(key=lambda t: t.get(key.replace("_", "-"), t.get(key, "")), reverse=rev)
    if args.format == "json":
        print(json.dumps(tags, ensure_ascii=False)); return 0
    if args.format == "jsonl":
        for t in tags:
            print(json.dumps(t, ensure_ascii=False))
        return 0
    if args.format == "full":
        parts = [f"{t['name']}\t{t['note-count']}" for t in tags]
    elif "{{" in args.format:
        parts = [render_template(args.format, {"name": t["name"], "note-count": t["note-count"], "note_count": t["note-count"]}, {}) for t in tags]
    else:
        parts = [t["name"] for t in tags]
    delim = "\0" if args.delimiter0 else unescape(args.delimiter)
    sys.stdout.write(args.header + delim.join(parts))
    if parts:
        sys.stdout.write(unescape(args.footer))
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(TOP_HELP); return 0
    if argv[0] == "--version":
        print("zk dev"); return 0
    opts, rest = parse_global(argv)
    if not rest or rest[0] in ("-h", "--help"):
        print(TOP_HELP); return 0
    cmd, args = rest[0], rest[1:]
    try:
        if cmd == "init":
            return init_cmd(opts, args)
        if cmd == "index":
            return index_cmd(opts, args)
        if cmd == "new":
            return new_cmd(opts, args)
        if cmd == "list":
            return list_cmd(opts, args)
        if cmd == "graph":
            return graph_cmd(opts, args)
        if cmd == "edit":
            return edit_cmd(opts, args)
        if cmd == "tag":
            return tag_cmd(opts, args)
        return fail(f"unexpected argument {cmd}")
    except SystemExit as e:
        return int(e.code or 0)
    except Exception as e:
        return fail(str(e))


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
