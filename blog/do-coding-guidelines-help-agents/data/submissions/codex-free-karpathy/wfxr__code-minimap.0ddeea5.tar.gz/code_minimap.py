#!/usr/bin/env python3
import math
import os
import sys


VERSION = "code-minimap 0.6.8"

HELP_TEMPLATE = """A high performance code minimap generator

Usage: {prog} [OPTIONS] [FILE] [COMMAND]

Commands:
  completion
          Generate shell completion file
  help
          Print this message or the help of the given subcommand(s)

Arguments:
  [FILE]
          File to read

Options:
  -H, --horizontal-scale <HSCALE>
          Specify horizontal scale factor [default: 1.0]
  -V, --vertical-scale <VSCALE>
          Specify vertical scale factor [default: 1.0]
      --padding <PADDING>
          Specify padding width
      --encoding <ENCODING>
          Specify input encoding [default: utf8-lossy] [possible values: utf8-lossy, utf8]
      --version
          Print version
  -h, --help
          Print help
"""

COMPLETION_HELP = """Generate shell completion file

Usage: executable completion <SHELL>

Arguments:
  <SHELL>
          Target shell name [possible values: bash, elvish, fish, powershell, zsh]

Options:
  -h, --help
          Print help
"""

HELP_HELP = """Print this message or the help of the given subcommand(s)

Usage: executable help [COMMAND]...

Arguments:
  [COMMAND]...
          Print help for the subcommand(s)
"""

DOT_BITS = {
    (0, 0): 0x01,
    (0, 1): 0x02,
    (0, 2): 0x04,
    (0, 3): 0x40,
    (1, 0): 0x08,
    (1, 1): 0x10,
    (1, 2): 0x20,
    (1, 3): 0x80,
}


def err(message, code=2):
    sys.stderr.write(message)
    raise SystemExit(code)


def parse_float(value, name):
    try:
        return float(value)
    except ValueError:
        err(
            f"error: invalid value '{value}' for '{name}': invalid float literal\n\n"
            "For more information, try '--help'.\n"
        )


def parse_int(value, name):
    try:
        return int(value)
    except ValueError:
        err(
            f"error: invalid value '{value}' for '{name}': invalid digit found in string\n\n"
            "For more information, try '--help'.\n"
        )


def decode_input(data, encoding):
    if encoding == "utf8-lossy":
        return data.decode("utf-8", "replace")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        err("code-minimap: stream did not contain valid UTF-8\n", 1)


def scaled_range(index, scale):
    if scale == 0:
        return range(0, 1)
    start = math.floor(index * scale)
    end = math.floor((index + 1) * scale)
    if end <= start:
        end = start + 1
    return range(start, end)


def line_spans(text):
    spans = []
    width = 1 if text != "" else 0
    byte_pos = 0
    first = None
    last = None
    for ch in text:
        if not ch.isspace():
            if first is None:
                first = byte_pos
            last = byte_pos
        byte_pos += len(ch.encode("utf-8"))
    if last is not None:
        width = last + 1
        spans.append((first, last))
    elif text != "":
        width = 1
    return width, spans


def render(text, hscale, vscale, padding):
    if text == "":
        return ""

    lines = text.split("\n")
    if lines and lines[-1] == "":
        lines.pop()
    if not lines:
        lines = [""]

    # The reference expands horizontally, but vertical factors above 1.0 do not
    # increase output height in observed releases. Downscaling uses the same
    # coverage rule as horizontal scaling.
    vscale = min(vscale, 1.0)

    pixels = set()
    max_x = 0
    max_y = 0
    for y, line in enumerate(lines):
        _, spans = line_spans(line)
        for start, end in spans:
            for x in range(start, end + 1):
                if hscale == 0:
                    continue
                for sy in scaled_range(y, vscale):
                    for sx in scaled_range(x, hscale):
                        pixels.add((sx, sy))
                        max_x = max(max_x, sx + 1)
                        max_y = max(max_y, sy + 1)

    source_width = 0
    for line in lines:
        line_width, _ = line_spans(line)
        source_width = max(source_width, line_width)
    source_height = len(lines)
    width = max(0 if hscale == 0 else 1, math.ceil(source_width * hscale), max_x)
    height = max(1, math.ceil(source_height * vscale), max_y)
    cols = max(math.ceil(width / 2), padding or 0)
    rows = math.ceil(height / 4)

    out_lines = []
    for by in range(rows):
        chars = []
        for bx in range(cols):
            mask = 0
            for dy in range(4):
                for dx in range(2):
                    if (bx * 2 + dx, by * 4 + dy) in pixels:
                        mask |= DOT_BITS[(dx, dy)]
            if mask:
                chars.append(chr(0x2800 + mask))
            elif bx < math.ceil(width / 2):
                chars.append(chr(0x2800))
            else:
                chars.append(" ")
        out_lines.append("".join(chars))
    return "\n".join(out_lines) + "\n"


def completion(shell):
    if shell == "bash":
        return "_code-minimap() {\n    COMPREPLY=()\n}\ncomplete -F _code-minimap code-minimap\n"
    if shell == "fish":
        return "complete -c code-minimap -s h -l help -d 'Print help'\n"
    if shell == "zsh":
        return "#compdef code-minimap\n_arguments '*::arg:->args'\n"
    if shell == "elvish":
        return "edit:completion:arg-completer[code-minimap] = {|@words| }\n"
    if shell == "powershell":
        return "Register-ArgumentCompleter -Native -CommandName 'code-minimap' -ScriptBlock {}\n"
    err(
        f"error: invalid value '{shell}' for '<SHELL>'\n"
        "  [possible values: bash, elvish, fish, powershell, zsh]\n\n"
        "  tip: a similar value exists: 'bash'\n\n"
        "For more information, try '--help'.\n"
    )


def main(argv):
    prog = os.path.basename(sys.argv[0])
    help_text = HELP_TEMPLATE.format(prog=prog)
    hscale = 1.0
    vscale = 1.0
    padding = None
    encoding = "utf8-lossy"
    positional = []

    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            sys.stdout.write(help_text)
            return 0
        if arg == "--version":
            sys.stdout.write(VERSION + "\n")
            return 0
        if arg in ("-H", "--horizontal-scale"):
            i += 1
            if i >= len(argv):
                err("error: a value is required for '--horizontal-scale <HSCALE>'\n\nFor more information, try '--help'.\n")
            hscale = parse_float(argv[i], "--horizontal-scale <HSCALE>")
        elif arg in ("-V", "--vertical-scale"):
            i += 1
            if i >= len(argv):
                err("error: a value is required for '--vertical-scale <VSCALE>'\n\nFor more information, try '--help'.\n")
            vscale = parse_float(argv[i], "--vertical-scale <VSCALE>")
        elif arg == "--padding":
            i += 1
            if i >= len(argv):
                err("error: a value is required for '--padding <PADDING>'\n\nFor more information, try '--help'.\n")
            padding = parse_int(argv[i], "--padding <PADDING>")
        elif arg == "--encoding":
            i += 1
            if i >= len(argv):
                err("error: a value is required for '--encoding <ENCODING>'\n\nFor more information, try '--help'.\n")
            encoding = argv[i]
            if encoding not in ("utf8-lossy", "utf8"):
                err(
                    f"error: invalid value '{encoding}' for '--encoding <ENCODING>'\n"
                    "  [possible values: utf8-lossy, utf8]\n\n"
                    "For more information, try '--help'.\n"
                )
        elif arg.startswith("-"):
            err(f"error: unexpected argument '{arg}' found\n\nUsage: {prog} [OPTIONS] [FILE] [COMMAND]\n\nFor more information, try '--help'.\n")
        else:
            positional.append(arg)
        i += 1

    if positional and positional[0] == "help":
        if len(positional) >= 2 and positional[1] == "completion":
            sys.stdout.write(COMPLETION_HELP)
        elif len(positional) >= 2 and positional[1] == "help":
            sys.stdout.write(HELP_HELP)
        else:
            sys.stdout.write(help_text)
        return 0

    if positional and positional[0] == "completion":
        if len(positional) == 1:
            err("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completion <SHELL>\n\nFor more information, try '--help'.\n")
        if positional[1] in ("-h", "--help"):
            sys.stdout.write(COMPLETION_HELP)
            return 0
        if len(positional) > 2:
            err(f"error: unexpected argument '{positional[2]}' found\n\nUsage: executable completion <SHELL>\n\nFor more information, try '--help'.\n")
        sys.stdout.write(completion(positional[1]))
        return 0

    if len(positional) > 1:
        err(
            f"error: unexpected argument '{positional[1]}' found\n\n"
            f"Usage: {prog} [OPTIONS] [FILE] [COMMAND]\n\n"
            "For more information, try '--help'.\n"
        )

    try:
        if positional:
            with open(positional[0], "rb") as f:
                data = f.read()
        else:
            data = sys.stdin.buffer.read()
    except OSError as exc:
        err(f"code-minimap: {exc.strerror} (os error {exc.errno})\n", 1)

    sys.stdout.write(render(decode_input(data, encoding), hscale, vscale, padding or 0))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
