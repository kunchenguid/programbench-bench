#!/usr/bin/env python3
import argparse
import os
import re
import sys
import textwrap
from pathlib import Path

VERSION = "tex-fmt 0.5.6"
DEFAULT_LISTS = ["itemize", "enumerate", "description", "inlineroman", "inventory"]
DEFAULT_VERBATIMS = ["verbatim", "Verbatim", "lstlisting", "minted", "comment"]
DEFAULT_NOIN = ["document"]
EXTS = {".tex", ".bib", ".cls", ".sty"}

class Config:
    def __init__(self):
        self.check = False
        self.print = False
        self.fail_on_change = False
        self.wrap = True
        self.wraplen = 80
        self.wrapmin = 70
        self.tabsize = 2
        self.tabchar = "space"
        self.stdin = False
        self.verbosity = "warn"
        self.lists = list(DEFAULT_LISTS)
        self.verbatims = list(DEFAULT_VERBATIMS)
        self.no_indent_envs = list(DEFAULT_NOIN)
        self.wrap_chars = []
        self.recursive = False

    def indent_unit(self):
        return "\t" if self.tabchar == "tab" else " " * self.tabsize

def parse_bool(v):
    return v.strip().lower() in ("true", "1", "yes", "on")

def parse_array(v):
    v = v.strip()
    if not (v.startswith("[") and v.endswith("]")):
        return []
    inner = v[1:-1].strip()
    if not inner:
        return []
    out = []
    cur = ""
    quote = None
    esc = False
    for ch in inner:
        if esc:
            cur += ch; esc = False; continue
        if ch == "\\":
            esc = True; continue
        if quote:
            if ch == quote:
                quote = None
            else:
                cur += ch
        elif ch in "'\"":
            quote = ch
        elif ch == ',':
            out.append(cur.strip()); cur = ""
        else:
            cur += ch
    if cur.strip() or inner.endswith(',') is False:
        out.append(cur.strip())
    return [x for x in out if x]

def load_config(path, cfg):
    try:
        text = Path(path).read_text()
    except OSError:
        return
    for raw in text.splitlines():
        line = raw.split('#', 1)[0].strip()
        if not line or '=' not in line:
            continue
        k, v = [x.strip() for x in line.split('=', 1)]
        k = k.strip('"\'')
        if k == 'check': cfg.check = parse_bool(v)
        elif k == 'print': cfg.print = parse_bool(v)
        elif k == 'fail-on-change': cfg.fail_on_change = parse_bool(v)
        elif k == 'wrap': cfg.wrap = parse_bool(v)
        elif k == 'wraplen':
            try: cfg.wraplen = int(v)
            except ValueError: pass
        elif k == 'wrapmin':
            try: cfg.wrapmin = int(v)
            except ValueError: pass
        elif k == 'tabsize':
            try: cfg.tabsize = int(v)
            except ValueError: pass
        elif k == 'tabchar': cfg.tabchar = v.strip().strip('"\'')
        elif k == 'stdin': cfg.stdin = parse_bool(v)
        elif k == 'verbosity': cfg.verbosity = v.strip().strip('"\'')
        elif k == 'lists': cfg.lists = DEFAULT_LISTS + parse_array(v)
        elif k == 'verbatims': cfg.verbatims = DEFAULT_VERBATIMS + parse_array(v)
        elif k == 'no-indent-envs': cfg.no_indent_envs = DEFAULT_NOIN + parse_array(v)
        elif k == 'wrap-chars': cfg.wrap_chars = parse_array(v)

def find_config(args):
    if args.noconfig:
        return None
    if args.config:
        return args.config
    cwd = Path.cwd()
    local = cwd / 'tex-fmt.toml'
    if local.exists():
        return str(local)
    p = cwd
    while True:
        if (p / '.git').exists() and (p / 'tex-fmt.toml').exists():
            return str(p / 'tex-fmt.toml')
        if p.parent == p:
            break
        p = p.parent
    home = Path.home() / '.config' / 'tex-fmt' / 'tex-fmt.toml'
    if home.exists():
        return str(home)
    return None

begin_re = re.compile(r"^\\begin\s*\{([^}]+)\}")
end_re = re.compile(r"^\\end\s*\{([^}]+)\}")
item_re = re.compile(r"^\\item(?:\s|\[|$)")

def is_wrap_candidate(s):
    if not s or s.startswith('%'):
        return False
    if s.startswith('\\') or s in ('{', '}'):
        return False
    if len(s.split()) < 2:
        return False
    return True

def wrap_line(prefix, content, cfg):
    if not cfg.wrap:
        return [prefix + content]
    width = max(20, cfg.wrapmin - len(prefix))
    if len(content) <= width:
        return [prefix + content]
    chars = ''.join(re.escape(c) for c in cfg.wrap_chars)
    text = content
    if chars:
        text = re.sub(f'([{chars}])', r'\1 ', text)
    return [prefix + x for x in textwrap.wrap(text, width=width, break_long_words=False, break_on_hyphens=False)] or [prefix]

def brace_delta(s):
    esc = False; delta = 0; in_comment = False
    for ch in s:
        if in_comment: break
        if esc:
            esc = False; continue
        if ch == '\\':
            esc = True; continue
        if ch == '%':
            in_comment = True; continue
        if ch == '{': delta += 1
        elif ch == '}': delta -= 1
    return delta

def format_tex(text, cfg):
    unit = cfg.indent_unit()
    indent = 0
    out = []
    verbatim = None
    off = False
    list_stack = []
    after_item = False
    lines = text.splitlines()
    for raw in lines:
        original_no_nl = raw.rstrip('\r')
        stripped = original_no_nl.strip()

        if off:
            out.append(original_no_nl.rstrip())
            if '% tex-fmt: on' in stripped:
                off = False
            continue
        if '% tex-fmt: off' in stripped:
            out.append(stripped if not original_no_nl.startswith(' ') else original_no_nl.rstrip())
            off = True
            continue
        if '% tex-fmt: skip' in stripped:
            out.append(original_no_nl.rstrip())
            continue
        if verbatim:
            out.append(original_no_nl.rstrip())
            m_end = end_re.match(stripped)
            if m_end and m_end.group(1) == verbatim:
                verbatim = None
            continue
        if stripped == '':
            out.append('')
            after_item = False
            continue

        m_end = end_re.match(stripped)
        if stripped.startswith('\\]'):
            indent = max(0, indent - 1)
            after_item = False
        elif m_end:
            env = m_end.group(1)
            if env not in cfg.no_indent_envs:
                indent = max(0, indent - 1)
            if list_stack and list_stack[-1] == env:
                list_stack.pop()
            after_item = False
        elif stripped.startswith('}') or stripped.startswith(']'):
            indent = max(0, indent - 1)
            after_item = False

        line_indent = indent
        if list_stack and after_item and not item_re.match(stripped) and not m_end:
            line_indent = indent + 1
        if item_re.match(stripped):
            line_indent = indent
            after_item = True
        elif not (list_stack and after_item and not m_end):
            after_item = False

        prefix = unit * line_indent
        if is_wrap_candidate(stripped):
            out.extend(wrap_line(prefix, stripped, cfg))
        else:
            out.append(prefix + stripped)

        m_begin = begin_re.match(stripped)
        if stripped.startswith('\\['):
            indent += 1
            after_item = False
        elif m_begin:
            env = m_begin.group(1)
            if env in cfg.verbatims:
                verbatim = env
            if env in cfg.lists:
                list_stack.append(env)
            if env not in cfg.no_indent_envs and env not in cfg.verbatims:
                indent += 1
            after_item = False
        elif not m_end:
            d = brace_delta(stripped)
            if d > 0 and not stripped.startswith('\\begin'):
                indent += d
            elif d < 0 and not stripped.startswith('}'):
                indent = max(0, indent + d)
    return '\n'.join(out) + ('\n' if text.endswith('\n') or text else '')

def discover_files(paths, recursive):
    if not paths:
        paths = ['.'] if recursive else []
    found = []
    for p in paths:
        path = Path(p)
        if path.is_dir():
            if recursive:
                for root, dirs, files in os.walk(path):
                    dirs[:] = [d for d in dirs if d not in ('.git', 'target', 'build', 'eval')]
                    for f in files:
                        fp = Path(root) / f
                        if fp.suffix in EXTS:
                            found.append(str(fp))
            else:
                continue
        elif path.suffix in EXTS or path.exists():
            found.append(str(path))
    return found

def print_args(cfg, files, config_path):
    print('tex-fmt')
    vals = [
        ('check', str(cfg.check).lower()), ('print', str(cfg.print).lower()),
        ('fail-on-change', str(cfg.fail_on_change).lower()), ('wrap', str(cfg.wrap).lower()),
        ('wraplen', str(cfg.wraplen)), ('wrapmin', str(cfg.wrapmin)),
        ('tabsize', str(cfg.tabsize)), ('tabchar', 'tab' if cfg.tabchar == 'tab' else 'space'),
        ('stdin', str(cfg.stdin).lower()), ('config', f'Some("{config_path}")' if config_path else 'None'),
        ('verbosity', cfg.verbosity)
    ]
    for k, v in vals:
        print(f'  {k + ":":<24} {v}')
    for name, arr in [('lists', cfg.lists), ('verbatims', cfg.verbatims), ('no-indent-envs', cfg.no_indent_envs), ('wrap-chars', cfg.wrap_chars)]:
        print(f'  {name + ":":<24} ' + (arr[0] if arr else ''))
        for x in arr[1:]: print(f'  {"":<24} {x}')
    print(f'  {"files:":<24} ' + '\n'.join(files))

def main():
    parser = argparse.ArgumentParser(prog='executable', add_help=False)
    parser.add_argument('-c','--check', action='store_true')
    parser.add_argument('-p','--print', dest='print_', action='store_true')
    parser.add_argument('-f','--fail-on-change', action='store_true')
    parser.add_argument('-n','--nowrap', action='store_true')
    parser.add_argument('-l','--wraplen', type=int)
    parser.add_argument('-t','--tabsize', type=int)
    parser.add_argument('--usetabs', action='store_true')
    parser.add_argument('-s','--stdin', action='store_true')
    parser.add_argument('--config')
    parser.add_argument('--noconfig', action='store_true')
    parser.add_argument('-v','--verbose', action='store_true')
    parser.add_argument('-q','--quiet', action='store_true')
    parser.add_argument('--trace', action='store_true')
    parser.add_argument('--completion', choices=['bash','elvish','fish','powershell','zsh'])
    parser.add_argument('--man', action='store_true')
    parser.add_argument('--args', action='store_true')
    parser.add_argument('-r','--recursive', action='store_true')
    parser.add_argument('-h','--help', action='store_true')
    parser.add_argument('-V','--version', action='store_true')
    parser.add_argument('files', nargs='*')
    args = parser.parse_args()

    if args.help:
        print(VERSION + "\n\nLaTeX formatter written in Rust\n")
        print("Usage: executable [OPTIONS] [files]...\n")
        print("Options:\n  -c, --check\n  -p, --print\n  -f, --fail-on-change\n  -n, --nowrap\n  -l, --wraplen <N>\n  -t, --tabsize <N>\n      --usetabs\n  -s, --stdin\n      --config <PATH>\n      --noconfig\n  -r, --recursive\n  -h, --help\n  -V, --version")
        return 0
    if args.version:
        print(VERSION); return 0
    if args.completion:
        print(f"# completion for tex-fmt ({args.completion})") ; return 0
    if args.man:
        print(".TH TEX-FMT 1\n.SH NAME\ntex-fmt - LaTeX formatter") ; return 0

    cfg = Config()
    config_path = find_config(args)
    if config_path:
        load_config(config_path, cfg)
    if args.check: cfg.check = True
    if args.print_: cfg.print = True
    if args.fail_on_change: cfg.fail_on_change = True
    if args.nowrap: cfg.wrap = False
    if args.wraplen is not None:
        cfg.wraplen = args.wraplen; cfg.wrapmin = max(0, args.wraplen - 10)
    if args.tabsize is not None: cfg.tabsize = args.tabsize
    if args.usetabs: cfg.tabchar = 'tab'
    if args.stdin: cfg.stdin = True
    if args.trace: cfg.verbosity = 'trace'
    elif args.verbose: cfg.verbosity = 'info'
    elif args.quiet: cfg.verbosity = 'error'
    cfg.recursive = args.recursive
    if cfg.check:
        cfg.fail_on_change = True
    if cfg.print:
        cfg.fail_on_change = True

    files = discover_files(args.files, cfg.recursive)
    if args.args:
        print_args(cfg, files or args.files, config_path); return 0

    changed = False
    if cfg.stdin:
        sys.stdout.write(format_tex(sys.stdin.read(), cfg))
        return 0
    if not files:
        return 0
    for f in files:
        try:
            old = Path(f).read_text()
        except OSError as e:
            if cfg.verbosity != 'error': print(f"ERROR: tex-fmt {f}: {e}", file=sys.stderr)
            changed = True; continue
        new = format_tex(old, cfg)
        if cfg.print:
            sys.stdout.write(new)
        elif cfg.check:
            if new != old:
                print(f"ERROR: tex-fmt {f}: Incorrect formatting. ", file=sys.stderr)
        else:
            if new != old:
                Path(f).write_text(new)
        changed = changed or (new != old)
    return 1 if changed and (cfg.check or cfg.fail_on_change) else 0

if __name__ == '__main__':
    sys.exit(main())
