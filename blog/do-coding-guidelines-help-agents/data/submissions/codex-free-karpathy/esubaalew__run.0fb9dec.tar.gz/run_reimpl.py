#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import tempfile


LANGUAGES = [
    "bash", "c", "cpp", "crystal", "csharp", "dart", "elixir", "go",
    "groovy", "haskell", "java", "javascript", "julia", "kotlin", "lua",
    "nim", "perl", "php", "python", "r", "ruby", "rust", "swift",
    "typescript", "zig",
]

ALIASES = {
    "sh": "bash",
    "shell": "bash",
    "py": "python",
    "python3": "python",
    "js": "javascript",
    "node": "javascript",
    "rb": "ruby",
    "rs": "rust",
    "c++": "cpp",
    "ts": "typescript",
}

EXTS = {
    ".sh": "bash", ".bash": "bash",
    ".c": "c", ".h": "c",
    ".cc": "cpp", ".cpp": "cpp", ".cxx": "cpp", ".hpp": "cpp",
    ".cr": "crystal",
    ".cs": "csharp",
    ".dart": "dart",
    ".ex": "elixir", ".exs": "elixir",
    ".go": "go",
    ".groovy": "groovy",
    ".hs": "haskell",
    ".java": "java",
    ".js": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".jl": "julia",
    ".kt": "kotlin", ".kts": "kotlin",
    ".lua": "lua",
    ".nim": "nim",
    ".pl": "perl", ".pm": "perl",
    ".php": "php",
    ".py": "python",
    ".r": "r", ".R": "r",
    ".rb": "ruby",
    ".rs": "rust",
    ".swift": "swift",
    ".ts": "typescript",
    ".zig": "zig",
}

REQ = {
    "bash": ("bash", "Bash support requires the `bash` executable. Install Bash and ensure it is on your PATH."),
    "c": ("gcc", "C support requires the `gcc` executable. Install GCC and ensure it is on your PATH."),
    "cpp": ("g++", "C++ support requires the `g++` executable. Install G++ and ensure it is on your PATH."),
    "crystal": ("crystal", "Crystal support requires the `crystal` executable. Install Crystal and ensure it is on your PATH."),
    "csharp": ("dotnet", "C# support requires the `dotnet` executable. Install .NET and ensure it is on your PATH."),
    "dart": ("dart", "Dart support requires the `dart` executable. Install Dart and ensure it is on your PATH."),
    "elixir": ("elixir", "Elixir support requires the `elixir` executable. Install Elixir and ensure it is on your PATH."),
    "go": ("go", "Go support requires the `go` executable. Install Go and ensure it is on your PATH."),
    "groovy": ("groovy", "Groovy support requires the `groovy` executable. Install Groovy and ensure it is on your PATH."),
    "haskell": ("runghc", "Haskell support requires the `runghc` executable. Install GHC and ensure it is on your PATH."),
    "java": ("javac", "Java support requires the `javac` executable. Install a JDK and ensure it is on your PATH."),
    "javascript": ("node", "JavaScript support requires the `node` executable. Install Node.js and ensure it is on your PATH."),
    "julia": ("julia", "Julia support requires the `julia` executable. Install Julia and ensure it is on your PATH."),
    "kotlin": ("kotlinc", "Kotlin support requires the `kotlinc` executable. Install Kotlin and ensure it is on your PATH."),
    "lua": ("lua", "Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH."),
    "nim": ("nim", "Nim support requires the `nim` executable. Install Nim and ensure it is on your PATH."),
    "perl": ("perl", "Perl support requires the `perl` executable. Install Perl and ensure it is on your PATH."),
    "php": ("php", "PHP support requires the `php` CLI executable. Install PHP and ensure it is on your PATH."),
    "python": ("python3", "Python support requires the `python3` executable. Install Python and ensure it is on your PATH."),
    "r": ("Rscript", "R support requires the `Rscript` executable. Install R and ensure it is on your PATH."),
    "ruby": ("ruby", "Ruby support requires the `ruby` executable. Install Ruby and ensure it is on your PATH."),
    "rust": ("rustc", "Rust support requires the `rustc` executable. Install Rust and ensure it is on your PATH."),
    "swift": ("swift", "Swift support requires the `swift` executable. Install Swift and ensure it is on your PATH."),
    "typescript": ("ts-node", "TypeScript support requires the `ts-node` executable. Install ts-node and ensure it is on your PATH."),
    "zig": ("zig", "Zig support requires the `zig` executable. Install Zig and ensure it is on your PATH."),
}


def help_text():
    return """Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help
"""


def version_text():
    return """run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)
"""


def unknown_language(lang):
    print(f"Error: Unknown language '{lang}'. Available languages: {', '.join(LANGUAGES)}", file=sys.stderr)
    return 1


def norm_lang(lang):
    low = lang.lower()
    return ALIASES.get(low, low)


def lang_from_path(path):
    base, ext = os.path.splitext(path)
    return EXTS.get(ext)


def detect_code(code, no_detect=False):
    s = code.strip()
    if no_detect:
        return "ruby"
    if "console.log" in s or "process." in s:
        return "javascript"
    if s.startswith("puts ") or "\nputs " in s:
        return "ruby"
    if s.startswith("echo ") or s.startswith("#!/bin/sh") or s.startswith("#!/usr/bin/env bash"):
        return "bash"
    if s.startswith("import ") or s.startswith("from ") or "sys." in s or s.startswith("def "):
        return "python"
    if s.startswith("package main") or "func main" in s:
        return "go"
    if "fn main" in s or s.startswith("use std"):
        return "rust"
    if "#include" in s:
        return "cpp" if "iostream" in s or "std::" in s else "c"
    if "public class" in s and "static void main" in s:
        return "java"
    if s.startswith("print("):
        return "lua"
    return "bash"


def ensure(lang):
    exe, msg = REQ[lang]
    if shutil.which(exe):
        return True
    print(f"Error: {msg}", file=sys.stderr)
    return False


def run(cmd, **kw):
    try:
        p = subprocess.run(cmd, **kw)
        return p.returncode
    except FileNotFoundError:
        return 127


def write(path, data):
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)


def source_text(code):
    if "\\n" in code and "\n" not in code:
        return code.replace("\\n", "\n")
    return code


def run_lang(lang, code=None, path=None):
    if lang not in LANGUAGES:
        return unknown_language(lang)
    if not ensure(lang):
        return 1

    if path is not None:
        if lang == "python":
            return run(["python3", path])
        if lang == "javascript":
            return run(["node", path])
        if lang == "ruby":
            return run(["ruby", path])
        if lang == "perl":
            return run(["perl", path])
        if lang == "bash":
            return run(["bash", path])
        if lang == "php":
            return run(["php", path])
        if lang == "lua":
            return run(["lua", path])
        if lang == "go":
            return run(["go", "run", path])
        if lang == "rust":
            with tempfile.TemporaryDirectory(prefix="run-rust") as d:
                out = os.path.join(d, "main")
                rc = run(["rustc", path, "-o", out])
                return rc if rc else run([out])
        if lang == "c":
            with tempfile.TemporaryDirectory(prefix="run-c") as d:
                out = os.path.join(d, "main")
                rc = run(["gcc", path, "-o", out])
                return rc if rc else run([out])
        if lang == "cpp":
            with tempfile.TemporaryDirectory(prefix="run-cpp") as d:
                out = os.path.join(d, "main")
                rc = run(["g++", path, "-o", out])
                return rc if rc else run([out])
        if lang == "java":
            with tempfile.TemporaryDirectory(prefix="run-java") as d:
                target = os.path.join(d, "Main.java")
                with open(path, "r", encoding="utf-8", errors="replace") as src:
                    write(target, src.read())
                rc = run(["javac", target])
                return rc if rc else run(["java", "-cp", d, "Main"])
        if lang == "typescript":
            return run(["ts-node", path])
        simple = {
            "crystal": ["crystal", "run", path],
            "dart": ["dart", path],
            "elixir": ["elixir", path],
            "groovy": ["groovy", path],
            "haskell": ["runghc", path],
            "julia": ["julia", path],
            "kotlin": ["kotlinc", "-script", path],
            "nim": ["nim", "r", path],
            "r": ["Rscript", path],
            "swift": ["swift", path],
            "zig": ["zig", "run", path],
        }
        return run(simple[lang])

    code = "" if code is None else code
    if lang == "python":
        return run(["python3", "-c", code])
    if lang == "javascript":
        return run(["node", "-e", code])
    if lang == "ruby":
        return run(["ruby", "-e", code])
    if lang == "perl":
        return run(["perl", "-e", code])
    if lang == "bash":
        return run(["bash", "-c", code])
    if lang == "php":
        return run(["php", "-r", code.replace("<?php", "", 1).strip()])
    if lang == "lua":
        return run(["lua", "-e", code])
    if lang == "go":
        with tempfile.TemporaryDirectory(prefix="run-go") as d:
            src = os.path.join(d, "main.go")
            write(src, source_text(code))
            return run(["go", "run", src])
    if lang == "rust":
        with tempfile.TemporaryDirectory(prefix="run-rust") as d:
            src = os.path.join(d, "main.rs")
            out = os.path.join(d, "main")
            write(src, source_text(code))
            rc = run(["rustc", src, "-o", out])
            return rc if rc else run([out])
    if lang == "c":
        with tempfile.TemporaryDirectory(prefix="run-c") as d:
            src = os.path.join(d, "main.c")
            out = os.path.join(d, "main")
            write(src, source_text(code))
            rc = run(["gcc", src, "-o", out])
            return rc if rc else run([out])
    if lang == "cpp":
        with tempfile.TemporaryDirectory(prefix="run-cpp") as d:
            src = os.path.join(d, "main.cpp")
            out = os.path.join(d, "main")
            write(src, source_text(code))
            rc = run(["g++", src, "-o", out])
            return rc if rc else run([out])
    if lang == "java":
        with tempfile.TemporaryDirectory(prefix="run-java") as d:
            src = os.path.join(d, "Main.java")
            write(src, source_text(code))
            rc = run(["javac", src])
            return rc if rc else run(["java", "-cp", d, "Main"])
    if lang == "typescript":
        return run(["ts-node", "-e", code])
    ext = {
        "crystal": ("main.cr", ["crystal", "run"]),
        "dart": ("main.dart", ["dart"]),
        "elixir": ("main.exs", ["elixir"]),
        "groovy": ("main.groovy", ["groovy"]),
        "haskell": ("main.hs", ["runghc"]),
        "julia": ("main.jl", ["julia"]),
        "kotlin": ("main.kts", ["kotlinc", "-script"]),
        "nim": ("main.nim", ["nim", "r"]),
        "r": ("main.R", ["Rscript"]),
        "swift": ("main.swift", ["swift"]),
        "zig": ("main.zig", ["zig", "run"]),
    }
    name, cmd = ext[lang]
    with tempfile.TemporaryDirectory(prefix=f"run-{lang}") as d:
        src = os.path.join(d, name)
        write(src, source_text(code))
        return run(cmd + [src])


def parse(argv):
    lang = None
    code = None
    file_path = None
    no_detect = False
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(help_text(), end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(version_text(), end="")
            sys.exit(0)
        if a == "--no-detect":
            no_detect = True
            i += 1
            continue
        if a in ("-l", "--lang"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{a} <LANG>' but none was supplied", file=sys.stderr)
                sys.exit(2)
            lang = norm_lang(argv[i + 1])
            i += 2
            continue
        if a.startswith("--lang="):
            lang = norm_lang(a.split("=", 1)[1])
            i += 1
            continue
        if a in ("-f", "--file"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{a} <PATH>' but none was supplied", file=sys.stderr)
                sys.exit(2)
            file_path = argv[i + 1]
            i += 2
            continue
        if a.startswith("--file="):
            file_path = a.split("=", 1)[1]
            i += 1
            continue
        if a in ("-c", "--code"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{a} <CODE>' but none was supplied", file=sys.stderr)
                sys.exit(2)
            code = argv[i + 1]
            i += 2
            continue
        if a.startswith("--code="):
            code = a.split("=", 1)[1]
            i += 1
            continue
        if a.startswith("-") and a != "-":
            print(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [ARGS]...\n\nFor more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        args.append(a)
        i += 1
    return lang, code, file_path, no_detect, args


def main():
    lang, code, file_path, no_detect, args = parse(sys.argv[1:])
    if code is not None and args:
        print("Error: Unexpected positional arguments after specifying --code", file=sys.stderr)
        return 1

    if args and norm_lang(args[0]) in LANGUAGES + list(ALIASES):
        if lang is None:
            lang = norm_lang(args.pop(0))

    if file_path is None and code is None and args:
        if len(args) == 1 and (os.path.exists(args[0]) or lang_from_path(args[0])):
            file_path = args[0]
        else:
            code = " ".join(args)

    if file_path is not None:
        if lang is None:
            lang = lang_from_path(file_path)
        if lang is None:
            lang = "bash" if no_detect else detect_code(open(file_path, "r", encoding="utf-8", errors="replace").read(), no_detect)
        return run_lang(lang, path=file_path)

    if code is None:
        if sys.stdin.isatty():
            return 0
        code = sys.stdin.read()

    if lang is None:
        lang = detect_code(code, no_detect)
    return run_lang(lang, code=code)


if __name__ == "__main__":
    sys.exit(main())
