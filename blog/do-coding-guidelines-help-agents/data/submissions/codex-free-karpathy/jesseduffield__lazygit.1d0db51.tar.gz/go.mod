module lazygit-reimplementation

go 1.20
