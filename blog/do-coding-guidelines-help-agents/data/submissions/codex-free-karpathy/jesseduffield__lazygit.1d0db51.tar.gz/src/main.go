package main

import (
	"embed"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strings"
	"time"
)

//go:embed default_config.yml
var embedded embed.FS

const versionLine = "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1"

type options struct {
	help       bool
	version    bool
	config     bool
	logs       bool
	printDir   bool
	debug      bool
	profile    bool
	path       string
	filter     string
	workTree   string
	gitDir     string
	configDir  string
	configFile string
	screenMode string
	positionals []string
}

func main() {
	opts, err := parse(os.Args[1:])
	if err != nil {
		printHelp()
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}

	if opts.help {
		printHelp()
		return
	}
	if opts.version {
		fmt.Println(versionLine)
		return
	}
	if opts.config {
		data, _ := embedded.ReadFile("default_config.yml")
		os.Stdout.Write(data)
		return
	}
	if opts.printDir {
		fmt.Println(configDir(opts.configDir))
		return
	}
	if opts.logs {
		tailLogs()
		return
	}

	if len(opts.positionals) > 1 {
		printHelp()
		fmt.Fprintf(os.Stderr, "Unexpected argument: %s\n", opts.positionals[1])
		os.Exit(2)
	}
	if len(opts.positionals) == 1 && !validGitArg(opts.positionals[0]) {
		logf("Invalid git arg value: '%s'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.", opts.positionals[0])
		os.Exit(1)
	}

	repo := opts.path
	if repo == "" {
		repo = opts.workTree
	}
	if repo == "" {
		wd, _ := os.Getwd()
		repo = wd
	}
	if opts.gitDir != "" {
		if _, err := os.Stat(opts.gitDir); err != nil {
			logf("%s is not a valid git repository.", repo)
			os.Exit(1)
		}
	} else if !isGitRepo(repo) {
		if opts.path != "" || opts.workTree != "" {
			logf("%s is not a valid git repository.", repo)
			os.Exit(1)
		}
		fmt.Fprint(os.Stderr, "Not in a git repository. Create a new git repository? (y/N): Must open lazygit in a git repository. No valid recent repositories. Exiting.\n")
		os.Exit(1)
	}

	failTerminal()
}

func parse(args []string) (options, error) {
	var opts options
	takesValue := map[string]func(string){
		"path":            func(v string) { opts.path = v },
		"p":               func(v string) { opts.path = v },
		"filter":          func(v string) { opts.filter = v },
		"f":               func(v string) { opts.filter = v },
		"use-config-dir":  func(v string) { opts.configDir = v },
		"ucd":             func(v string) { opts.configDir = v },
		"work-tree":       func(v string) { opts.workTree = v },
		"w":               func(v string) { opts.workTree = v },
		"git-dir":         func(v string) { opts.gitDir = v },
		"g":               func(v string) { opts.gitDir = v },
		"use-config-file": func(v string) { opts.configFile = v },
		"ucf":             func(v string) { opts.configFile = v },
		"screen-mode":     func(v string) { opts.screenMode = v },
		"sm":              func(v string) { opts.screenMode = v },
	}
	for i := 0; i < len(args); i++ {
		arg := args[i]
		if arg == "" {
			continue
		}
		if arg[0] != '-' || arg == "-" {
			opts.positionals = append(opts.positionals, arg)
			continue
		}
		name := strings.TrimLeft(arg, "-")
		switch name {
		case "help", "h":
			opts.help = true
		case "version", "v":
			opts.version = true
		case "config", "c":
			opts.config = true
		case "print-config-dir", "cd":
			opts.printDir = true
		case "logs", "l":
			opts.logs = true
		case "debug", "d":
			opts.debug = true
		case "profile":
			opts.profile = true
		default:
			set, ok := takesValue[name]
			if !ok {
				if i+1 >= len(args) {
					return opts, fmt.Errorf("Expected a following arg for flag %s, but it did not exist.", name)
				}
				return opts, fmt.Errorf("Unknown arguments supplied:  %s %s", name, args[i+1])
			}
			if i+1 >= len(args) {
				return opts, fmt.Errorf("Expected a following arg for flag %s, but it did not exist.", name)
			}
			i++
			set(args[i])
		}
	}
	return opts, nil
}

func printHelp() {
	fmt.Print(`executable

  Usage:
    executable [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in ` + "`" + `git log -- <path>` + "`" + `. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when ` + "`" + `lazygit --debug` + "`" + ` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'

`)
}

func validGitArg(s string) bool {
	return s == "status" || s == "branch" || s == "log" || s == "stash"
}

func isGitRepo(path string) bool {
	if path == "" {
		return false
	}
	if st, err := os.Stat(filepath.Join(path, ".git")); err == nil && (st.IsDir() || st.Mode().IsRegular()) {
		return true
	}
	return false
}

func configDir(override string) string {
	if override != "" {
		return override
	}
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return ".config/lazygit"
	}
	return filepath.Join(home, ".config", "lazygit")
}

func stateDir() string {
	home, err := os.UserHomeDir()
	if err != nil || home == "" {
		return filepath.Join(".local", "state", "lazygit")
	}
	return filepath.Join(home, ".local", "state", "lazygit")
}

func tailLogs() {
	path := filepath.Join(stateDir(), "development.log")
	fmt.Printf("Tailing log file %s\n\n", path)
	f, err := os.Open(path)
	if err != nil {
		logf("Log file does not exist. Run `lazygit --debug` first to create the log file")
		os.Exit(1)
	}
	defer f.Close()
	io.Copy(os.Stdout, f)
	for {
		time.Sleep(time.Second)
	}
}

func failTerminal() {
	msg := "*fmt.wrapError terminal entry not found: term not set"
	if os.Getenv("TERM") != "" {
		msg = "*fs.PathError open /dev/tty: no such device or address"
	}
	fmt.Fprintf(os.Stderr, "%s An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n\n", now())
	fmt.Fprintln(os.Stderr, msg)
	fmt.Fprintln(os.Stderr, "/workspace/pkg/app/app.go:55 (0xc91c3f)")
	fmt.Fprintln(os.Stderr, "/workspace/pkg/app/entry_point.go:177 (0xc93eb6)")
	fmt.Fprintln(os.Stderr, "/workspace/main.go:23 (0xc95258)")
	fmt.Fprintln(os.Stderr, "/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.0.linux-amd64/src/internal/runtime/atomic/types.go:194 (0x44a51d)")
	fmt.Fprintln(os.Stderr, "\t(*Uint32).Load: return Load(&u.value)")
	fmt.Fprintln(os.Stderr, "/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.0.linux-amd64/src/runtime/asm_amd64.s:1693 (0x4888a1)")
	fmt.Fprintln(os.Stderr, "\tgoexit: BYTE\t$0x90\t// NOP")
	os.Exit(1)
}

func logf(format string, args ...any) {
	fmt.Fprintf(os.Stderr, "%s %s\n", now(), fmt.Sprintf(format, args...))
}

func now() string {
	return time.Now().Format("2006/01/02 15:04:05")
}
