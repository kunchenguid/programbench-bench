#!/usr/bin/env python3
import math
import os
import sys


HELP = """Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
"""


def fail(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)


def parse_int(value, opt):
    try:
        return int(value, 10)
    except ValueError:
        fail(f"{opt} <integer> expected. ParseIntError {{ kind: InvalidDigit }}\nerror: invalid digit found in string")


def parse_args(argv):
    opts = {
        "cols": 10,
        "length": None,
        "fmt": "x",
        "color": "1",
        "array": None,
        "func": None,
        "places": 4,
        "prefix": "1",
        "input": None,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if arg in ("-V", "--version"):
            print("hx 0.7.0")
            sys.exit(0)
        if arg == "--":
            if i + 1 < len(argv):
                opts["input"] = argv[i + 1]
            break
        value_opts = {
            "-c": "cols", "--cols": "cols",
            "-l": "length", "--len": "length",
            "-f": "fmt", "--format": "fmt",
            "-t": "color", "--color": "color",
            "-a": "array", "--array": "array",
            "-u": "func", "--func": "func",
            "-p": "places", "--places": "places",
            "-r": "prefix", "--prefix": "prefix",
        }
        if arg in value_opts:
            if i + 1 >= len(argv):
                fail(f"error: a value is required for '{arg}' but none was supplied")
            key = value_opts[arg]
            val = argv[i + 1]
            if key in ("cols", "length", "func"):
                opts[key] = parse_int(val, arg)
            elif key == "places":
                opts[key] = val
            else:
                opts[key] = val
            i += 2
            continue
        if arg.startswith("--"):
            fail(f"error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'.")
        if arg.startswith("-") and len(arg) > 2:
            # Minimal support for clustered short flags with a value in the next argument.
            for ch in arg[1:]:
                if ch in "hV":
                    return parse_args(["-" + ch] + argv[i + 1:])
            fail(f"error: unexpected argument '{arg}' found")
        if opts["input"] is None:
            opts["input"] = arg
        else:
            fail(f"error: unexpected argument '{arg}' found")
        i += 1

    if opts["fmt"] not in ("o", "x", "X", "b"):
        fail(f"error: invalid value '{opts['fmt']}' for '--format <format>'\n  [possible values: o, x, X, b]")
    if opts["array"] is not None and opts["array"] not in ("r", "c", "g", "p", "k", "j", "s", "f"):
        fail(f"error: invalid value '{opts['array']}' for '--array <array_format>'\n  [possible values: r, c, g, p, k, j, s, f]")
    if opts["color"] not in ("0", "1"):
        fail(f"error: invalid value '{opts['color']}' for '--color <color>'\n  [possible values: 0, 1]")
    if opts["prefix"] not in ("0", "1"):
        fail(f"error: invalid value '{opts['prefix']}' for '--prefix <prefix>'\n  [possible values: 0, 1]")
    if opts["func"] is not None:
        opts["places"] = parse_int(str(opts["places"]), "-p, --places")
    return opts


def read_input(path, limit):
    try:
        if path is None:
            data = sys.stdin.buffer.read()
        else:
            with open(path, "rb") as f:
                data = f.read()
    except OSError as e:
        fail(f"error: {e.strerror} (os error {e.errno})")
    if limit is not None and limit > 0:
        data = data[:limit]
    return data


def byte_token(b, fmt, prefix):
    if fmt == "x":
        return ("0x" if prefix else "") + f"{b:02x}"
    if fmt == "X":
        return ("0x" if prefix else "") + f"{b:02X}"
    if fmt == "b":
        return ("0b" if prefix else "") + f"{b:08b}"
    return ("0o" if prefix else "") + f"{b:04o}"


def token_width(fmt, prefix):
    if fmt in ("x", "X"):
        return 4 if prefix else 2
    if fmt == "b":
        return 10 if prefix else 8
    return 6 if prefix else 4


def ascii_for(chunk):
    return "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)


def dump(data, cols, fmt, prefix):
    if cols < 0:
        cols = 10
    step = cols
    if step == 0:
        print("0x000000: ")
        print(f"   bytes: {len(data)}")
        return
    total_rows = len(data) // step + 1
    for row in range(total_rows):
        off = row * step
        chunk = data[off:off + step]
        toks = " ".join(byte_token(b, fmt, prefix) for b in chunk)
        extra = 0 if len(chunk) == 0 else 1
        pad = " " * ((cols - len(chunk)) * 5 + extra)
        print(f"0x{off:06x}: {toks}{pad}{ascii_for(chunk)}")
    print(f"   bytes: {len(data)}")


def array_out(data, style, cols):
    if cols <= 0:
        cols = 10
    n = len(data)
    starts = {
        "r": f"let ARRAY: [u8; {n}] = [",
        "c": f"unsigned char ARRAY[{n}] = {{",
        "g": f"a := [{n}]byte{{",
        "p": "a = [",
        "k": "val a = byteArrayOf(",
        "j": "byte[] a = new byte[]{",
        "s": "let a: [UInt8] = [",
        "f": "let a = [|",
    }
    ends = {
        "r": "];",
        "c": "};",
        "g": "}",
        "p": "]",
        "k": ")",
        "j": "};",
        "s": "]",
        "f": "|]",
    }
    sep = "; " if style == "f" else ", "
    suffix = "uy" if style == "f" else ""
    print(starts[style])
    rows = [data[i:i + cols] for i in range(0, n, cols)]
    for idx, chunk in enumerate(rows):
        parts = [f"0x{b:02x}{suffix}" for b in chunk]
        line = "    " + sep.join(parts)
        last = idx == len(rows) - 1
        if style == "g" or not last:
            line += "; " if style == "f" and not last else ", "
        print(line)
    if n == 0 or n % cols == 0:
        print("    ")
    print(ends[style])


def func_wave(length, places):
    vals = []
    for i in range(max(0, length)):
        v = math.sin(i * math.pi / (2 * length)) if length else 0.0
        vals.append(f"{v:.{places}f}")
    if vals:
        print(",".join(vals) + ",")
    else:
        print()


def main():
    opts = parse_args(sys.argv[1:])
    if opts["func"] is not None:
        func_wave(opts["func"], opts["places"])
        return
    data = read_input(opts["input"], opts["length"])
    if opts["array"]:
        array_out(data, opts["array"], opts["cols"])
    else:
        dump(data, opts["cols"], opts["fmt"], opts["prefix"] == "1")


if __name__ == "__main__":
    main()
