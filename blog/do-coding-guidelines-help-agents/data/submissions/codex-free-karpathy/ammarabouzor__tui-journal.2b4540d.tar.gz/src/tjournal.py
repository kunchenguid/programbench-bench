#!/usr/bin/env python3
import json
import os
import re
import sys

VERSION = "tui-journal 0.16.1"
DEFAULT_CONFIG_DIR = os.path.expanduser("~/.config/tui-journal")
DEFAULT_LOG = os.path.expanduser("~/.cache/tui-journal/tui-journal.log")
DEFAULT_STATE = os.path.expanduser("~/.local/state/tui-journal")
DEFAULT_JSON = os.path.expanduser("~/tui-journal/entries.json")
DEFAULT_SQLITE = os.path.expanduser("~/tui-journal/entries.db")

THEME_DEFAULT = """[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"
"""


def default_config():
    return {
        "backend_type": "Sqlite",
        "scroll_per_page": 5,
        "sync_os_clipboard": False,
        "history_limit": 10,
        "colored_tags": True,
        "datum_visibility": "show",
        "app_state_dir": DEFAULT_STATE,
        "export.show_confirmation": True,
        "external_editor.auto_save": False,
        "external_editor.temp_file_extension": "txt",
        "json_backend.file_path": DEFAULT_JSON,
        "sqlite_backend.file_path": DEFAULT_SQLITE,
    }


def print_top_help():
    print("""Tui app allows writing and managing journals/notes from within the terminal With different local back-ends

Usage: executable [OPTIONS] [COMMAND]

Commands:
  print-config     Print the current settings including the paths for the back-end files [aliases: pc]
  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]
  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]
  theme            Provides commands regarding changing themes and styles of the app [aliases: style]
  help             Print this message or the help of the given subcommand(s)

Options:
  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it
  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it
  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]
  -c, --config <DIR PATH>             Specifies the path for the configuration directory.
                                      Configuration files is considered as root for themes file too.
                                      It still accepts the path for configuration file for backward compatibility.
                                      (default path: /home/agent/.config/tui-journal)
  -v, --verbose...                    Increases logging verbosity each use for up to 3 times
  -l, --log <FILE PATH>               Specifies a file to use for logging
                                      (default file: /home/agent/.cache/tui-journal/tui-journal.log)
  -h, --help                          Print help
  -V, --version                       Print version""")


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def clap_error(msg, usage=None, tip=None):
    print(f"error: {msg}", file=sys.stderr)
    if tip:
        print(f"\n  tip: {tip}", file=sys.stderr)
    if usage:
        print(f"\nUsage: {usage}", file=sys.stderr)
    print("\nFor more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse_scalar(v):
    v = v.strip()
    if v.startswith('"') and v.endswith('"'):
        return v[1:-1]
    if v == "true":
        return True
    if v == "false":
        return False
    try:
        return int(v)
    except ValueError:
        return v


def read_config(path, cfg):
    if not path:
        return
    file_path = path if os.path.isfile(path) else os.path.join(path, "config.toml")
    if not os.path.exists(file_path):
        return
    section = ""
    try:
        lines = open(file_path, encoding="utf-8").read().splitlines()
    except OSError as e:
        die(f"Error: Failed to read configuration file. Error infos: {e}")
    for i, line in enumerate(lines, 1):
        s = line.split("#", 1)[0].strip()
        if not s:
            continue
        if s.startswith("[") and s.endswith("]"):
            section = s[1:-1].strip()
            continue
        if "=" not in s:
            continue
        key, val = [p.strip() for p in s.split("=", 1)]
        full = f"{section}.{key}" if section else key
        parsed = parse_scalar(val)
        if full == "backend_type" and parsed not in ("Json", "Sqlite"):
            print("Error: Failed to read configuration file. Error infos: TOML parse error at line %d, column 16" % i, file=sys.stderr)
            print("  |", file=sys.stderr)
            print(f"{i} | {line}", file=sys.stderr)
            print("  |                " + "^" * max(1, len(str(parsed)) + 2), file=sys.stderr)
            print(f"unknown variant `{parsed}`, expected `Json` or `Sqlite`", file=sys.stderr)
            sys.exit(1)
        cfg[full] = parsed


def print_config(cfg):
    print(f'backend_type = "{cfg["backend_type"]}"')
    print(f'scroll_per_page = {cfg["scroll_per_page"]}')
    print(f'sync_os_clipboard = {str(cfg["sync_os_clipboard"]).lower()}')
    print(f'history_limit = {cfg["history_limit"]}')
    print(f'colored_tags = {str(cfg["colored_tags"]).lower()}')
    print(f'datum_visibility = "{cfg["datum_visibility"]}"')
    print(f'app_state_dir = "{cfg["app_state_dir"]}"')
    print()
    print("[export]")
    print(f'show_confirmation = {str(cfg["export.show_confirmation"]).lower()}')
    print()
    print("[external_editor]")
    print(f'auto_save = {str(cfg["external_editor.auto_save"]).lower()}')
    print(f'temp_file_extension = "{cfg["external_editor.temp_file_extension"]}"')
    print()
    print("[json_backend]")
    print(f'file_path = "{cfg["json_backend.file_path"]}"')
    print()
    print("[sqlite_backend]")
    print(f'file_path = "{cfg["sqlite_backend.file_path"]}"')
    print()


def check_config_dir(path):
    if path and not os.path.exists(path):
        die(f"Error: Provided custom directory doesn't exit. Path: {path}")


def theme_path(config_path):
    if config_path and os.path.exists(config_path) and not os.path.isdir(config_path):
        print("INFO: Custom config directory is ignored in themese because it's not a directory.")
        return os.path.join(DEFAULT_CONFIG_DIR, "themes.toml")
    return os.path.join(config_path or DEFAULT_CONFIG_DIR, "themes.toml")


def theme_help():
    print("""Provides commands regarding changing themes and styles of the app

Usage: executable theme <COMMAND>

Commands:
  print-path      Prints the path to the user themes file [aliases: path]
  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]
  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]
  help            Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help""")


def command_help(cmd):
    texts = {
        "print-config": ("Print the current settings including the paths for the back-end files", "Usage: executable print-config"),
        "import-journals": ("Import journals from the given transfer JSON file to the current back-end file", "Usage: executable import-journals --path <FILE PATH>\n\nOptions:\n  -p, --path <FILE PATH>  Path of the JSON file to import from\n  -h, --help              Print help"),
        "assign-priority": ("Assign priority for all the entries with empty priority field", "Usage: executable assign-priority <PRIORITY>\n\nArguments:\n  <PRIORITY>  Priority value (Positive number)\n\nOptions:\n  -h, --help  Print help"),
        "theme print-path": ("Prints the path to the user themes file", "Usage: executable theme print-path\n\nOptions:\n  -h, --help  Print help"),
        "theme print-default": ("Dumps the styles with the default values to be used as a reference and base for user custom themes", "Usage: executable theme print-default\n\nOptions:\n  -h, --help  Print help"),
        "theme write-defaults": ("Creates user custom themes file if doesn't exist then writes the default styles to it", "Usage: executable theme write-defaults\n\nOptions:\n  -h, --help  Print help"),
    }
    desc, body = texts[cmd]
    print(desc)
    print()
    print(body)


def load_json_entries(path):
    if not os.path.exists(path):
        return []
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        for k in ("journals", "entries", "items"):
            if isinstance(data.get(k), list):
                return data[k]
    return []


def save_json_entries(path, entries):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=2, ensure_ascii=False)
        f.write("\n")


def import_journals(cfg, path):
    try:
        incoming = load_json_entries(path)
        cur = load_json_entries(cfg["json_backend.file_path"])
        cur.extend(incoming)
        save_json_entries(cfg["json_backend.file_path"], cur)
        print(f"Successfully imported {len(incoming)} journals")
    except Exception as e:
        die(f"Error: {e}")


def assign_priority(cfg, priority):
    try:
        entries = load_json_entries(cfg["json_backend.file_path"])
        changed = 0
        for item in entries:
            if isinstance(item, dict) and (item.get("priority") in (None, "", 0) or "priority" not in item):
                item["priority"] = priority
                changed += 1
        save_json_entries(cfg["json_backend.file_path"], entries)
        print(f"Assigned priority {priority} to {changed} journals")
    except Exception as e:
        die(f"Error: {e}")


def main(argv):
    cfg = default_config()
    config_path = None
    i = 0
    rest = []
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print_top_help()
            return 0
        if a in ("-V", "--version"):
            print(VERSION)
            return 0
        if a in ("-j", "--json-file-path"):
            i += 1
            if i >= len(argv): clap_error("a value is required for '--json-file-path <FILE PATH>' but none was supplied")
            cfg["json_backend.file_path"] = argv[i]
            cfg["backend_type"] = "Json"
        elif a in ("-s", "--sqlite-file-path"):
            i += 1
            if i >= len(argv): clap_error("a value is required for '--sqlite-file-path <FILE PATH>' but none was supplied")
            cfg["sqlite_backend.file_path"] = argv[i]
            cfg["backend_type"] = "Sqlite"
        elif a in ("-b", "--backend-type"):
            i += 1
            if i >= len(argv): clap_error("a value is required for '--backend-type <BACKEND_TYPE>' but none was supplied")
            if argv[i] not in ("json", "sqlite"):
                clap_error(f"invalid value '{argv[i]}' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]")
            cfg["backend_type"] = "Json" if argv[i] == "json" else "Sqlite"
        elif a in ("-c", "--config"):
            i += 1
            if i >= len(argv): clap_error("a value is required for '--config <DIR PATH>' but none was supplied")
            config_path = argv[i]
        elif a.startswith("-v") and set(a[1:]) == {"v"}:
            pass
        elif a in ("-l", "--log"):
            i += 1
            if i >= len(argv): clap_error("a value is required for '--log <FILE PATH>' but none was supplied")
        elif a.startswith("-"):
            if a == "--bad":
                clap_error("unexpected argument '--bad' found", "executable --backend-type <BACKEND_TYPE>", "a similar argument exists: '--backend-type'")
            clap_error(f"unexpected argument '{a}' found")
        else:
            rest = argv[i:]
            break
        i += 1

    read_config(config_path, cfg)
    # Command-line file/backend flags override config file.
    j = 0
    while j < len(argv):
        if argv[j] in ("-j", "--json-file-path") and j + 1 < len(argv):
            cfg["json_backend.file_path"] = argv[j + 1]; cfg["backend_type"] = "Json"; j += 1
        elif argv[j] in ("-s", "--sqlite-file-path") and j + 1 < len(argv):
            cfg["sqlite_backend.file_path"] = argv[j + 1]; cfg["backend_type"] = "Sqlite"; j += 1
        elif argv[j] in ("-b", "--backend-type") and j + 1 < len(argv) and argv[j + 1] in ("json", "sqlite"):
            cfg["backend_type"] = "Json" if argv[j + 1] == "json" else "Sqlite"; j += 1
        j += 1

    if not rest:
        print_top_help()
        return 0
    cmd = rest[0]
    if cmd == "help":
        print_top_help(); return 0
    if cmd in ("print-config", "pc"):
        check_config_dir(config_path) if config_path and not os.path.isfile(config_path) else None
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            command_help("print-config")
        else:
            print_config(cfg)
        return 0
    if cmd in ("theme", "style"):
        check_config_dir(config_path) if config_path and not os.path.isfile(config_path) else None
        if len(rest) == 1 or rest[1] in ("-h", "--help", "help"):
            theme_help(); return 0
        sub = rest[1]
        aliases = {"path": "print-path", "default": "print-default", "write": "write-defaults"}
        sub = aliases.get(sub, sub)
        if len(rest) > 2 and rest[2] in ("-h", "--help"):
            if sub in ("print-path", "print-default", "write-defaults"):
                command_help("theme " + sub); return 0
        if sub == "print-path":
            print(theme_path(config_path)); return 0
        if sub == "print-default":
            print(THEME_DEFAULT); return 0
        if sub == "write-defaults":
            p = theme_path(config_path)
            try:
                with open(p, "w", encoding="utf-8") as f:
                    f.write(THEME_DEFAULT)
                print(f"Default themes have been written to {p}")
                return 0
            except OSError:
                die("Error: Error while writing default themes to file\n\nCaused by:\n    No such file or directory (os error 2)")
        clap_error(f"unrecognized subcommand '{rest[1]}'", "executable theme <COMMAND>")
    if cmd in ("import-journals", "imj"):
        check_config_dir(config_path) if config_path and not os.path.isfile(config_path) else None
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            command_help("import-journals"); return 0
        path = None
        k = 1
        while k < len(rest):
            if rest[k] in ("-p", "--path") and k + 1 < len(rest):
                path = rest[k + 1]; k += 2
            else:
                k += 1
        if not path:
            clap_error("the following required arguments were not provided:\n  --path <FILE PATH>", "executable import-journals --path <FILE PATH>")
        import_journals(cfg, path); return 0
    if cmd in ("assign-priority", "ap"):
        check_config_dir(config_path) if config_path and not os.path.isfile(config_path) else None
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            command_help("assign-priority"); return 0
        if len(rest) < 2:
            clap_error("the following required arguments were not provided:\n  <PRIORITY>", "executable assign-priority <PRIORITY>")
        val = rest[1]
        if val.startswith("-"):
            clap_error(f"unexpected argument '{val}' found", "executable assign-priority <PRIORITY>", f"to pass '{val}' as a value, use '-- {val}'")
        if not re.match(r"^[0-9]+$", val):
            clap_error(f"invalid value '{val}' for '<PRIORITY>': invalid digit found in string")
        assign_priority(cfg, int(val)); return 0
    clap_error(f"unrecognized subcommand '{cmd}'", "executable [OPTIONS] [COMMAND]")


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
