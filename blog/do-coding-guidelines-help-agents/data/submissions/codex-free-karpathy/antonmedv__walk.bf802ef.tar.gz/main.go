package main

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"sort"
	"strings"
	"syscall"
	"time"
	"unicode"
	"unsafe"
)

const version = "v1.13.0"

const helpText = `
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode
`

type options struct {
	icons      bool
	dirOnly    bool
	hideHidden bool
	preview    bool
	border     bool
	fuzzy      bool
	path       string
}

type app struct {
	opts    options
	cwd     string
	entries []entry
	cursor  int
	query   string
	search  bool
	status  string
}

type entry struct {
	name  string
	path  string
	isDir bool
	size  int64
	mode  os.FileMode
	mtime time.Time
}

type termState struct {
	fd  int
	old syscall.Termios
	ok  bool
}

func main() {
	opts, action, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(2)
	}
	if action == "help" {
		fmt.Print(helpText)
		os.Exit(1)
	}
	if action == "version" {
		fmt.Println(version)
		return
	}

	root := opts.path
	if root == "" {
		root = "."
	}
	abs, err := filepath.Abs(root)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	info, err := os.Stat(abs)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if !info.IsDir() {
		abs = filepath.Dir(abs)
	}

	a := &app{opts: opts, cwd: abs}
	a.reload()

	if !isTerminal(os.Stdin.Fd()) {
		for _, e := range a.entries {
			fmt.Println(e.name)
		}
		return
	}

	ts, _ := makeRaw(int(os.Stdin.Fd()))
	if ts.ok {
		defer restore(ts)
	}
	defer showCursor()
	hideCursor()
	a.loop(os.Stdin, os.Stdout)
}

func parseArgs(args []string) (options, string, error) {
	var opts options
	for _, arg := range args {
		switch arg {
		case "-h", "--help":
			return opts, "help", nil
		case "--version", "-v":
			return opts, "version", nil
		case "--icons":
			opts.icons = true
		case "--dir-only":
			opts.dirOnly = true
		case "--hide-hidden":
			opts.hideHidden = true
		case "--preview":
			opts.preview = true
		case "--with-border":
			opts.border = true
		case "--fuzzy":
			opts.fuzzy = true
		default:
			if strings.HasPrefix(arg, "-") {
				return opts, "", fmt.Errorf("unknown flag: %s", arg)
			}
			if opts.path == "" {
				opts.path = arg
			} else {
				return opts, "", fmt.Errorf("too many arguments")
			}
		}
	}
	return opts, "", nil
}

func (a *app) loop(in io.Reader, out io.Writer) {
	a.draw(out)
	r := bufio.NewReader(in)
	for {
		b, err := r.ReadByte()
		if err != nil {
			return
		}
		switch b {
		case 3:
			fmt.Fprint(out, "\033[2J\033[H")
			return
		case 'q':
			fmt.Fprint(out, "\033[2J\033[H")
			fmt.Fprintln(out, a.selectedDir())
			return
		case '?':
			a.status = "arrows, hjkl move  enter open  backspace up  / search  q exit"
		case 'j':
			a.move(1)
		case 'k':
			a.move(-1)
		case 'h', 127, 8:
			a.up()
		case 'l', '\r', '\n':
			a.enter()
		case ' ':
			a.opts.preview = !a.opts.preview
		case '.':
			a.opts.hideHidden = !a.opts.hideHidden
			a.reload()
		case '/':
			a.search = true
			a.query = ""
		case 'd':
			a.deleteSelected()
		case 'y':
			a.status = a.selectedDir()
		case 0x1b:
			if r.Buffered() >= 2 {
				seq, _ := r.Peek(2)
				if len(seq) == 2 && seq[0] == '[' {
					r.Discard(2)
					switch seq[1] {
					case 'A':
						a.move(-1)
					case 'B':
						a.move(1)
					case 'C':
						a.enter()
					case 'D':
						a.up()
					}
				}
			} else {
				fmt.Fprint(out, "\033[2J\033[H")
				fmt.Fprintln(out, a.selectedDir())
				return
			}
		default:
			if a.search {
				if b == 13 || b == 10 {
					a.search = false
				} else if b == 127 || b == 8 {
					if len(a.query) > 0 {
						a.query = a.query[:len(a.query)-1]
					}
					a.applySearch()
				} else if b >= 32 && b < 127 {
					a.query += string(b)
					a.applySearch()
				}
			}
		}
		a.draw(out)
	}
}

func (a *app) reload() {
	a.entries = a.entries[:0]
	items, err := os.ReadDir(a.cwd)
	if err != nil {
		a.status = err.Error()
		return
	}
	for _, item := range items {
		name := item.Name()
		if a.opts.hideHidden && strings.HasPrefix(name, ".") {
			continue
		}
		info, err := item.Info()
		if err != nil {
			continue
		}
		if a.opts.dirOnly && !info.IsDir() {
			continue
		}
		a.entries = append(a.entries, entry{
			name: name, path: filepath.Join(a.cwd, name), isDir: info.IsDir(),
			size: info.Size(), mode: info.Mode(), mtime: info.ModTime(),
		})
	}
	sort.SliceStable(a.entries, func(i, j int) bool {
		if a.entries[i].isDir != a.entries[j].isDir {
			return a.entries[i].isDir
		}
		return strings.ToLower(a.entries[i].name) < strings.ToLower(a.entries[j].name)
	})
	if a.cursor >= len(a.entries) {
		a.cursor = len(a.entries) - 1
	}
	if a.cursor < 0 {
		a.cursor = 0
	}
}

func (a *app) draw(out io.Writer) {
	fmt.Fprint(out, "\033[2J\033[H")
	fmt.Fprintf(out, " %s\n\n", a.cwd)
	if len(a.entries) == 0 {
		fmt.Fprintln(out, "  (empty)")
	} else {
		limit := len(a.entries)
		if limit > 24 {
			limit = 24
		}
		for i := 0; i < limit; i++ {
			e := a.entries[i]
			prefix := "  "
			if i == a.cursor {
				prefix = "> "
			}
			icon := ""
			if a.opts.icons {
				if e.isDir {
					icon = "d "
				} else {
					icon = "f "
				}
			}
			slash := ""
			if e.isDir {
				slash = "/"
			}
			fmt.Fprintf(out, "%s%s%s%s\n", prefix, icon, e.name, slash)
		}
	}
	if a.search {
		fmt.Fprintf(out, "\n/ %s\n", a.query)
	}
	if a.opts.preview {
		a.drawPreview(out)
	}
	if a.status != "" {
		fmt.Fprintf(out, "\n%s\n", a.status)
	}
}

func (a *app) drawPreview(out io.Writer) {
	if len(a.entries) == 0 {
		return
	}
	e := a.entries[a.cursor]
	if a.opts.border {
		fmt.Fprintln(out, "\n--- preview ---")
	} else {
		fmt.Fprintln(out)
	}
	if e.isDir {
		children, _ := os.ReadDir(e.path)
		for i, child := range children {
			if i >= 8 {
				break
			}
			fmt.Fprintf(out, "  %s\n", child.Name())
		}
		return
	}
	f, err := os.Open(e.path)
	if err != nil {
		fmt.Fprintln(out, err)
		return
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for i := 0; i < 10 && sc.Scan(); i++ {
		line := sc.Text()
		if len(line) > 100 {
			line = line[:100]
		}
		fmt.Fprintln(out, line)
	}
}

func (a *app) move(delta int) {
	if len(a.entries) == 0 {
		return
	}
	a.cursor += delta
	if a.cursor < 0 {
		a.cursor = 0
	}
	if a.cursor >= len(a.entries) {
		a.cursor = len(a.entries) - 1
	}
	a.status = statusFor(a.entries[a.cursor])
}

func (a *app) enter() {
	if len(a.entries) == 0 {
		return
	}
	e := a.entries[a.cursor]
	if e.isDir {
		a.cwd = e.path
		a.cursor = 0
		a.query = ""
		a.reload()
		return
	}
	editor := os.Getenv("WALK_EDITOR")
	if editor == "" {
		editor = os.Getenv("EDITOR")
	}
	if editor == "" {
		a.status = e.path
		return
	}
	cmd := exec.Command(editor, e.path)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	_ = cmd.Run()
}

func (a *app) up() {
	parent := filepath.Dir(a.cwd)
	if parent != a.cwd {
		a.cwd = parent
		a.cursor = 0
		a.reload()
	}
}

func (a *app) applySearch() {
	if a.query == "" {
		a.cursor = 0
		return
	}
	q := strings.ToLower(a.query)
	for i, e := range a.entries {
		name := strings.ToLower(e.name)
		if strings.Contains(name, q) || (a.opts.fuzzy && fuzzyMatch(name, q)) {
			a.cursor = i
			return
		}
	}
}

func (a *app) selectedDir() string {
	if len(a.entries) == 0 {
		return a.cwd
	}
	e := a.entries[a.cursor]
	if e.isDir {
		return e.path
	}
	return a.cwd
}

func (a *app) deleteSelected() {
	if len(a.entries) == 0 {
		return
	}
	e := a.entries[a.cursor]
	cmdline := os.Getenv("WALK_REMOVE_CMD")
	var err error
	if cmdline != "" {
		parts := strings.Fields(cmdline)
		if len(parts) > 0 {
			cmd := exec.Command(parts[0], append(parts[1:], e.path)...)
			err = cmd.Run()
		}
	} else {
		err = os.RemoveAll(e.path)
	}
	if err != nil {
		a.status = err.Error()
	} else {
		a.status = "deleted " + e.name
		a.reload()
	}
}

func statusFor(e entry) string {
	return fmt.Sprintf("%s %8s %s", e.mode.String(), humanSize(e.size), e.mtime.Format("Jan _2 15:04"))
}

func humanSize(n int64) string {
	units := []string{"B", "K", "M", "G", "T"}
	f := float64(n)
	i := 0
	for f >= 1024 && i < len(units)-1 {
		f /= 1024
		i++
	}
	if i == 0 {
		return fmt.Sprintf("%dB", n)
	}
	return fmt.Sprintf("%.1f%s", f, units[i])
}

func fuzzyMatch(s, q string) bool {
	pos := 0
	for _, r := range s {
		if pos < len(q) && unicode.ToLower(r) == rune(q[pos]) {
			pos++
		}
	}
	return pos == len(q)
}

func isTerminal(fd uintptr) bool {
	var termios syscall.Termios
	_, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, fd, syscall.TCGETS, uintptr(unsafe.Pointer(&termios)), 0, 0, 0)
	return errno == 0
}

func makeRaw(fd int) (termState, error) {
	var old syscall.Termios
	_, _, errno := syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), syscall.TCGETS, uintptr(unsafe.Pointer(&old)), 0, 0, 0)
	if errno != 0 {
		return termState{}, errno
	}
	raw := old
	raw.Iflag &^= syscall.ICRNL | syscall.IXON
	raw.Lflag &^= syscall.ECHO | syscall.ICANON | syscall.ISIG
	raw.Cc[syscall.VMIN] = 1
	raw.Cc[syscall.VTIME] = 0
	_, _, errno = syscall.Syscall6(syscall.SYS_IOCTL, uintptr(fd), syscall.TCSETS, uintptr(unsafe.Pointer(&raw)), 0, 0, 0)
	return termState{fd: fd, old: old, ok: errno == 0}, errno
}

func restore(ts termState) {
	if ts.ok {
		syscall.Syscall6(syscall.SYS_IOCTL, uintptr(ts.fd), syscall.TCSETS, uintptr(unsafe.Pointer(&ts.old)), 0, 0, 0)
	}
}

func hideCursor() { fmt.Print("\033[?25l") }
func showCursor() { fmt.Print("\033[?25h") }
