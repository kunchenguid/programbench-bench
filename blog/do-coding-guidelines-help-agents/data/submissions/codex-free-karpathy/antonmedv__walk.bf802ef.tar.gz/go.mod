module walkreimpl

go 1.20
