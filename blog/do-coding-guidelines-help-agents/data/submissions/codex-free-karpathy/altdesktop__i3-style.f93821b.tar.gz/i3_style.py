#!/usr/bin/env python3
import os
import re
import sys

VERSION = "i3-style 1.0"

THEME_INFO = [
    ("slate", "Slate theme by Jody Ribton <jody@ribton.me>"),
    ("alphare", "A beige theme by Alphare"),
    ("ubuntu", "Ubuntu theme by lasers"),
    ("flat-gray", "flat gray based theme"),
    ("purple", "Purple theme by AAlakkad <http://aalakkad.me>"),
    ("archlinux", "Archlinux theme by okraits <http://okraits.de>"),
    ("default", "Default theme for i3wm <http://i3wm.org>"),
    ("debian", "Debian theme by lasers"),
    ("oceanic-next", "Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)"),
    ("base16-tomorrow", "Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)"),
    ("okraits", "A simple theme by okraits <http://okraits.de>"),
    ("icelines", "icelines theme by mbfraga"),
    ("solarized", "Solarized theme by lasers"),
    ("deep-purple", "Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>"),
    ("tomorrow-night-80s", "Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>"),
    ("seti", "seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui"),
    ("lime", "Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>"),
    ("gruvbox", "Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>"),
    ("mate", "Theme for blending i3 into MATE"),
]

def t(bar, client):
    return {"bar": bar, "client": client}

THEMES = {
    "slate": t(
        {"separator":["#586e75"],"background":["#002b36"],"statusline":["#aea79f"],"focused_workspace":["#586e75","#586e75","#ffffff"],"active_workspace":["#073642","#073642","#ffffff"],"inactive_workspace":["#002b36","#002b36","#aea79f"],"urgent_workspace":["#77216f","#77216f","#ffffff"]},
        {"focused":["#586e75","#586e75","#fdf6e3","#268bd2"],"focused_inactive":["#073642","#073642","#93a1a1","#002b36"],"unfocused":["#002b36","#002b36","#586e75","#002b36"],"urgent":["#dc322f","#dc322f","#fdf6e3","#dc322f"]}),
    "alphare": t(
        {"separator":["#000000"],"background":["#FDF6E3"],"statusline":["#002B36"],"focused_workspace":["#000000","#268BD2","#FFFFFF"],"active_workspace":["#333333","#222222","#FFFFFF"],"inactive_workspace":["#333333","#222222","#888888"],"urgent_workspace":["#2F343A","#900000","#FFFFFF"]},
        {"focused":["#000000","#FDF6E3","#002B36","#000000"],"focused_inactive":["#000000","#5F676A","#FDF6E3","#484E50"],"unfocused":["#000000","#000000","#FDF6E3","#000000"],"urgent":["#000000","#DC322F","#FDF6E3","#DC322F"]}),
    "ubuntu": t(
        {"separator":["#333333"],"background":["#2c001e"],"statusline":["#aea79f"],"focused_workspace":["#dd4814","#dd4814","#ffffff"],"active_workspace":["#902a07","#902a07","#aea79f"],"inactive_workspace":["#902a07","#902a07","#aea79f"],"urgent_workspace":["#77216f","#77216f","#ffffff"]},
        {"focused":["#dd4814","#dd4814","#ffffff","#902a07"],"focused_inactive":["#5e2750","#5e2750","#aea79f","#5e2750"],"unfocused":["#5e2750","#5e2750","#aea79f","#5e2750"],"urgent":["#77216f","#77216f","#ffffff","#efb73e"]}),
    "flat-gray": t(
        {"background":["#333333"],"statusline":["#AAAAAA"],"focused_workspace":["#282828","#282828","#FFFFFF"],"inactive_workspace":["#333333","#333333","#AAAAAA"]},
        {"focused":["#000000","#000000","#FFFFFF","#000000"],"focused_inactive":["#333333","#333333","#FFFFFF","#000000"],"unfocused":["#333333","#333333","#FFFFFF","#333333"]}),
    "purple": t(
        {"separator":["#AAAAAA"],"background":["#222133"],"statusline":["#FFFFFF"],"focused_workspace":["#664477","#664477","#cccccc"],"active_workspace":["#DCCD69","#DCCD69","#181715"],"inactive_workspace":["#222133","#222133","#AAAAAA"],"urgent_workspace":["#CE4045","#CE4045","#FFFFFF"]},
        {"focused":["#664477","#664477","#cccccc","#e7d8b1"],"focused_inactive":["#e7d8b1","#e7d8b1","#181715","#A074C4"],"unfocused":["#222133","#222133","#AAAAAA","#A074C4"],"urgent":["#CE4045","#CE4045","#e7d8b1","#DCCD69"]}),
    "archlinux": t(
        {"separator":["#666666"],"background":["#222222"],"statusline":["#dddddd"],"focused_workspace":["#0088CC","#0088CC","#ffffff"],"active_workspace":["#333333","#333333","#ffffff"],"inactive_workspace":["#333333","#333333","#888888"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},
        {"focused":["#0088CC","#0088CC","#ffffff","#dddddd"],"focused_inactive":["#333333","#333333","#888888","#292d2e"],"unfocused":["#333333","#333333","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
    "default": t(
        {"separator":["#666666"],"background":["#000000"],"statusline":["#ffffff"],"focused_workspace":["#4c7899","#285577","#ffffff"],"active_workspace":["#333333","#5f676a","#ffffff"],"inactive_workspace":["#333333","#222222","#888888"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},
        {"focused":["#4c7899","#285577","#ffffff","#2e9ef4"],"focused_inactive":["#333333","#5f676a","#ffffff","#484e50"],"unfocused":["#333333","#222222","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
    "debian": t(
        {"separator":["#444444"],"background":["#222222"],"statusline":["#666666"],"focused_workspace":["#d70a53","#d70a53","#ffffff"],"active_workspace":["#333333","#333333","#888888"],"inactive_workspace":["#333333","#333333","#888888"],"urgent_workspace":["#eb709b","#eb709b","#ffffff"]},
        {"focused":["#d70a53","#d70a53","#ffffff","#8c0333"],"focused_inactive":["#333333","#333333","#888888","#333333"],"unfocused":["#333333","#333333","#888888","#333333"],"urgent":["#eb709b","#eb709b","#ffffff","#eb709b"]}),
    "oceanic-next": t(
        {"separator":["#65737E"],"background":["#1B2B34"],"statusline":["#D8DEE9"],"focused_workspace":["#6699CC","#6699CC","#1B2B34"],"active_workspace":["#5FB3B3","#5FB3B3","#1B2B34"],"inactive_workspace":["#343D46","#343D46","#D8DEE9"],"urgent_workspace":["#EC5f67","#EC5f67","#1B2B34"]},
        {"focused":["#6699CC","#6699CC","#1B2B34","#6699CC"],"focused_inactive":["#5FB3B3","#5FB3B3","#D8DEE9","#A7ADBA"],"unfocused":["#343D46","#343D46","#D8DEE9","#343D46"],"urgent":["#EC5f67","#EC5f67","#1B2B34","#EC5f67"]}),
    "base16-tomorrow": t(
        {"separator":["#969896"],"background":["#1d1f21"],"statusline":["#c5c8c6"],"focused_workspace":["#81a2be","#81a2be","#1d1f21"],"active_workspace":["#373b41","#373b41","#ffffff"],"inactive_workspace":["#282a2e","#282a2e","#969896"],"urgent_workspace":["#cc6666","#cc6666","#ffffff"]},
        {"focused":["#81a2be","#81a2be","#1d1f21","#282a2e"],"focused_inactive":["#373b41","#373b41","#969896","#282a2e"],"unfocused":["#282a2e","#282a2e","#969896","#282a2e"],"urgent":["#373b41","#cc6666","#ffffff","#cc6666"]}),
    "okraits": t(
        {"separator":["#666666"],"background":["#333333"],"statusline":["#bbbbbb"],"focused_workspace":["#888888","#dddddd","#222222"],"active_workspace":["#333333","#555555","#bbbbbb"],"inactive_workspace":["#333333","#555555","#bbbbbb"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},
        {"focused":["#888888","#dddddd","#222222","#2e9ef4"],"focused_inactive":["#333333","#555555","#bbbbbb","#484e50"],"unfocused":["#333333","#333333","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
    "icelines": t(
        {"separator":["#7d7d7d"],"background":["#141414"],"statusline":["#00b0ef"],"focused_workspace":["#00b0ef","#141414","#00b0ef"],"active_workspace":["#141414","#141414","#00b0ef"],"inactive_workspace":["#141414","#141414","#7d7d7d"],"urgent_workspace":["#ff7066","#141414","#ff7066"]},
        {"focused":["#00b0ef","#00b0ef","#141414","#ff7066"],"focused_inactive":["#141414","#141414","#00b0ef","#472b2a"],"unfocused":["#141414","#141414","#7d7d7d","#141414"],"urgent":["#ff7066","#ff7066","#141414","#ff7066"]}),
    "solarized": t(
        {"separator":["#dc322f"],"background":["#002b36"],"statusline":["#268bd2"],"focused_workspace":["#fdf6e3","#859900","#fdf6e3"],"active_workspace":["#fdf6e3","#6c71c4","#fdf6e3"],"inactive_workspace":["#586e75","#93a1a1","#002b36"],"urgent_workspace":["#d33682","#d33682","#fdf6e3"]},
        {"focused":["#859900","#859900","#fdf6e3","#6c71c4"],"focused_inactive":["#073642","#073642","#eee8d5","#6c71c4"],"unfocused":["#073642","#073642","#93a1a1","#586e75"],"urgent":["#d33682","#d33682","#fdf6e3","#dc322f"]}),
    "deep-purple": t(
        {"separator":["#666666"],"background":["#000000"],"statusline":["#ffffff"],"focused_workspace":["#551a8b","#551a8b","#ffffff"],"active_workspace":["#333333","#5f676a","#ffffff"],"inactive_workspace":["#000000","#000000","#888888"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},
        {"focused":["#3b1261","#3b1261","#ffffff","#662b9c"],"focused_inactive":["#333333","#5f676a","#ffffff","#484e50"],"unfocused":["#222222","#222222","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
    "tomorrow-night-80s": t(
        {"separator":["#515151"],"background":["#2d2d2d"],"statusline":["#cccccc"],"focused_workspace":["#99cc99","#99cc99","#000000"],"active_workspace":["#333333","#333333","#ffffff"],"inactive_workspace":["#2d2d2d","#2d2d2d","#999999"],"urgent_workspace":["#f2777a","#f2777a","#ffffff"]},
        {"focused":["#99cc99","#99cc99","#000000","#2d2d2d"],"focused_inactive":["#393939","#393939","#888888","#292d2e"],"unfocused":["#2d2d2d","#2d2d2d","#999999","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
    "seti": t(
        {"separator":["#AAAAAA"],"background":["#1f2326"],"statusline":["#FFFFFF"],"focused_workspace":["#9FCA56","#9FCA56","#151718"],"active_workspace":["#DCCD69","#DCCD69","#151718"],"inactive_workspace":["#1f2326","#1f2326","#AAAAAA"],"urgent_workspace":["#CE4045","#CE4045","#FFFFFF"]},
        {"focused":["#4F99D3","#4F99D3","#151718","#9FCA56"],"focused_inactive":["#9FCA56","#9FCA56","#151718","#A074C4"],"unfocused":["#1f2326","#1f2326","#AAAAAA","#A074C4"],"urgent":["#CE4045","#CE4045","#FFFFFF","#DCCD69"]}),
    "lime": t(
        {"separator":["#888888"],"background":["#333333"],"statusline":["#FFFFFF"],"focused_workspace":["#4E9C00","#4E9C00","#FFFFFF"],"active_workspace":["#333333","#333333","#FFFFFF"],"inactive_workspace":["#333333","#333333","#888888"],"urgent_workspace":["#C20000","#C20000","#FFFFFF"]},
        {"focused":["#4E9C00","#4E9C00","#FFFFFF","#FFFFFF"],"focused_inactive":["#1B3600","#1B3600","#888888","#FFFFFF"],"unfocused":["#333333","#333333","#888888","#FFFFFF"],"urgent":["#C20000","#C20000","#FFFFFF","#FFFFFF"]}),
    "gruvbox": t(
        {"separator":["#928374"],"background":["#282828"],"statusline":["#ebdbb2"],"focused_workspace":["#689d6a","#689d6a","#282828"],"active_workspace":["#1d2021","#1d2021","#928374"],"inactive_workspace":["#32302f","#32302f","#928374"],"urgent_workspace":["#cc241d","#cc241d","#ebdbb2"]},
        {"focused":["#689d6a","#689d6a","#282828","#282828"],"focused_inactive":["#1d2021","#1d2021","#928374","#282828"],"unfocused":["#32302f","#32302f","#928374","#282828"],"urgent":["#cc241d","#cc241d","#ebdbb2","#282828"]}),
    "mate": t(
        {"separator":["#ffffff"],"background":["#3c3b37"],"statusline":["#ffffff"],"focused_workspace":["#526532","#526532","#ffffff"],"active_workspace":["#aea79f","#aea79f","#3c3b37"],"inactive_workspace":["#3c3b37","#3c3b37","#aea79f"],"urgent_workspace":["#FF0000","#FF0000","#ffffff"]},
        {"focused":["#526532","#526532","#ffffff","#a4cb64"],"focused_inactive":["#aea79f","#aea79f","#3c3b37","#aea79f"],"unfocused":["#3c3b37","#3c3b37","#aea79f","#3c3b37"],"urgent":["#FF0000","#FF0000","#ffffff","#FF0000"]}),
}

BAR_ORDER = ["separator", "background", "statusline", "focused_workspace", "active_workspace", "inactive_workspace", "urgent_workspace"]
CLIENT_ORDER = ["focused", "focused_inactive", "unfocused", "urgent"]
PARTS4 = ["border", "background", "text", "indicator"]
PARTS3 = ["border", "background", "text"]

def print_help():
    print("""i3-style 1.0
Make your i3 config a bit more stylish

USAGE:
    executable [FLAGS] [OPTIONS] [theme]

FLAGS:
    -h, --help        Prints help information
    -l, --list-all    Print a list of all available themes
    -r, --reload      Apply the theme by reloading the config
    -s, --save        Set the output file to the path of the input file
    -V, --version     Prints version information

OPTIONS:
    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.
    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>
    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others
                             [default: ]

ARGS:
    <theme>    The theme to use""")

def list_all():
    print("Available themes:\n")
    width = max(len(n) for n, _ in THEME_INFO)
    for name, desc in THEME_INFO:
        print(f"  {name:<{width}} - {desc}")

def parse_args(argv):
    opts = {"config": None, "output": None, "to_theme": None, "save": False, "reload": False, "theme": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print_help(); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a in ("-l", "--list-all"):
            list_all(); sys.exit(0)
        if a in ("-r", "--reload"):
            opts["reload"] = True; i += 1; continue
        if a in ("-s", "--save"):
            opts["save"] = True; i += 1; continue
        if a in ("-c", "--config", "-o", "--output", "-t", "--to-theme"):
            if i + 1 >= len(argv):
                die(f"error: The argument '{a}' requires a value but none was supplied")
            key = {"-c":"config","--config":"config","-o":"output","--output":"output","-t":"to_theme","--to-theme":"to_theme"}[a]
            opts[key] = argv[i+1]
            i += 2
            continue
        if a.startswith("-"):
            die(f"error: Found argument '{a}' which wasn't expected")
        if opts["theme"] is None:
            opts["theme"] = a
        else:
            die(f"error: Found argument '{a}' which wasn't expected")
        i += 1
    return opts

def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)

def default_config_path():
    home = os.environ.get("HOME", "")
    return os.path.join(home, ".config", "i3", "config")

def load_theme(name):
    if name in THEMES:
        return THEMES[name]
    if os.path.exists(name):
        return parse_theme_file(read_file(name))
    die(f"Could not find theme `{name}`. Use `--list-all` to see available themes.")

def strip_quote(v):
    v = v.strip()
    if "#" in v and not v.startswith("#"):
        v = v[v.index("#"):]
    v = v.strip().strip("'\"")
    return v

def resolve_color(v, colors):
    v = strip_quote(v)
    return colors.get(v, v)

def parse_theme_file(text):
    colors = {}
    out = {"bar": {}, "client": {}}
    section = None
    subsection = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#") or raw.strip() == "---":
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if indent == 0:
            key = line.rstrip(":")
            if key == "colors": section = "colors"
            elif key == "window_colors": section = "client"
            elif key == "bar_colors": section = "bar"
            else: section = None
            subsection = None
            continue
        if section == "colors" and indent == 2 and ":" in line:
            k, v = line.split(":", 1)
            colors[k.strip()] = strip_quote(v)
        elif section in ("client", "bar"):
            if indent == 2 and line.endswith(":"):
                subsection = line[:-1].strip()
                if section == "client":
                    out["client"].setdefault(subsection, [])
                else:
                    out["bar"].setdefault(subsection, [])
            elif indent == 2 and ":" in line and section == "bar":
                k, v = line.split(":", 1)
                out["bar"][k.strip()] = [resolve_color(v, colors)]
            elif indent == 4 and ":" in line and subsection:
                k, v = line.split(":", 1)
                target = out["client"] if section == "client" else out["bar"]
                parts = PARTS4 if section == "client" else PARTS3
                arr = target.setdefault(subsection, [""] * len(parts))
                if k.strip() in parts:
                    arr[parts.index(k.strip())] = resolve_color(v, colors)
    for group in ("bar", "client"):
        for k in list(out[group].keys()):
            out[group][k] = [x for x in out[group][k] if x]
    return out

def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

def write_file(path, data):
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)

def color_block(theme, indent):
    lines = [indent + "colors {"]
    inner = indent + "  "
    for key in BAR_ORDER:
        vals = theme["bar"].get(key)
        if vals:
            lines.append(inner + key + " " + " ".join(vals))
    lines.append(indent + "}")
    return lines

def replace_bar_colors(lines, theme):
    out = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if re.match(r"^\s*bar\s*\{", line):
            out.append(line)
            i += 1
            depth = line.count("{") - line.count("}")
            inserted = False
            while i < len(lines) and depth > 0:
                cur = lines[i]
                if re.match(r"^\s*colors\s*\{", cur):
                    indent = re.match(r"^(\s*)", cur).group(1)
                    out.extend(color_block(theme, indent))
                    depth += cur.count("{") - cur.count("}")
                    i += 1
                    while i < len(lines) and depth > 1:
                        depth += lines[i].count("{") - lines[i].count("}")
                        i += 1
                    inserted = True
                    continue
                if depth == 1 and cur.strip() == "}":
                    if not inserted:
                        out.extend(color_block(theme, "  "))
                        inserted = True
                    out.append(cur)
                    depth += cur.count("{") - cur.count("}")
                    i += 1
                    break
                out.append(cur)
                depth += cur.count("{") - cur.count("}")
                i += 1
            continue
        out.append(line)
        i += 1
    return out

def apply_theme(config, theme):
    had_newline = config.endswith("\n")
    lines = config.splitlines()
    lines = replace_bar_colors(lines, theme)
    seen = set()
    out = []
    for line in lines:
        m = re.match(r"^(\s*)client\.(focused_inactive|focused|unfocused|urgent)\b", line)
        if m and m.group(2) in theme["client"]:
            name = m.group(2)
            out.append(m.group(1) + "client." + name + " " + " ".join(theme["client"][name]))
            seen.add(name)
        else:
            out.append(line)
    for name in CLIENT_ORDER:
        vals = theme["client"].get(name)
        if vals and name not in seen:
            out.append("client." + name + " " + " ".join(vals))
    result = "\n".join(out)
    return result + "\n" if had_newline or result else result

def extract_theme(config):
    theme = {"bar": {}, "client": {}}
    for line in config.splitlines():
        s = line.strip()
        m = re.match(r"client\.(focused_inactive|focused|unfocused|urgent)\s+(.+)$", s)
        if m:
            theme["client"][m.group(1)] = m.group(2).split()[:4]
        m = re.match(r"(separator|background|statusline|focused_workspace|active_workspace|inactive_workspace|urgent_workspace)\s+(.+)$", s)
        if m:
            n = 1 if m.group(1) in ("separator", "background", "statusline") else 3
            theme["bar"][m.group(1)] = m.group(2).split()[:n]
    return theme

def theme_yaml(theme):
    lines = ["---", "meta:", "  description: AUTOMATICALLY GENERATED THEME", "window_colors:"]
    for name in CLIENT_ORDER:
        vals = theme["client"].get(name)
        if vals and len(vals) >= 4:
            lines += [f"  {name}:"]
            for part, val in zip(PARTS4, vals):
                lines.append(f"    {part}: \"{val}\"")
    lines.append("bar_colors:")
    for key in BAR_ORDER:
        vals = theme["bar"].get(key)
        if not vals:
            continue
        if len(vals) == 1:
            lines.append(f"  {key}: \"{vals[0]}\"")
        else:
            lines.append(f"  {key}:")
            for part, val in zip(PARTS3, vals):
                lines.append(f"    {part}: \"{val}\"")
    return "\n".join(lines) + "\n"

def main(argv):
    opts = parse_args(argv)
    cfg = opts["config"] or default_config_path()
    if opts["to_theme"] is not None:
        out = theme_yaml(extract_theme(read_file(opts["to_theme"])))
        if opts["output"]:
            write_file(opts["output"], out)
        else:
            sys.stdout.write(out)
        return
    if opts["theme"] is None:
        print("USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nSelect a theme as the first argument. Use `--list-all` to see the themes.", file=sys.stderr)
        sys.exit(1)
    output = opts["output"]
    if opts["save"]:
        output = cfg
    if not output:
        output = cfg
    theme = load_theme(opts["theme"])
    rendered = apply_theme(read_file(cfg), theme)
    write_file(output, rendered)

if __name__ == "__main__":
    main(sys.argv[1:])
