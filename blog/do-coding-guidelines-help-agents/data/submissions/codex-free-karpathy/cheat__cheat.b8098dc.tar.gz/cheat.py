#!/usr/bin/env python3
import os
import re
import sys
import glob
import shutil
import subprocess

VERSION = "5.1.0"

HELP = """cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember.

Usage:
  cheat [cheatsheet] [flags]

Examples:
  To initialize a config file:
    mkdir -p ~/.config/cheat && cheat --init > ~/.config/cheat/conf.yml

  To view the tar cheatsheet:
    cheat tar

  To edit (or create) the foo cheatsheet:
    cheat -e foo

  To edit (or create) the foo/bar cheatsheet on the "work" cheatpath:
    cheat -p work -e foo/bar

  To view all cheatsheet directories:
    cheat -d

  To list all available cheatsheets:
    cheat -l

  To briefly list all cheatsheets whose titles match "apt":
    cheat -b apt

  To list all tags in use:
    cheat -T

  To list available cheatsheets that are tagged as "personal":
    cheat -l -t personal

  To search for "ssh" among all cheatsheets, and colorize matches:
    cheat -c -s ssh

  To search (by regex) for cheatsheets that contain an IP address:
    cheat -c -r -s '(?:[0-9]{1,3}\\.){3}[0-9]{1,3}'

  To remove (delete) the foo/bar cheatsheet:
    cheat --rm foo/bar

  To update all git-backed cheatpaths:
    cheat --update

  To view the configuration file path:
    cheat --conf

  To generate shell completions (bash, zsh, fish, powershell):
    cheat --completion bash

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number"""


def expand_path(s):
    return os.path.abspath(os.path.expandvars(os.path.expanduser(s.strip().strip('"').strip("'"))))


def list_value(v):
    v = v.strip()
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        if not inner:
            return []
        return [x.strip().strip('"').strip("'") for x in inner.split(",") if x.strip()]
    return [v.strip().strip('"').strip("'")] if v else []


def find_config_path():
    env = os.environ.get("CHEAT_CONFIG_PATH")
    if env:
        return expand_path(env), os.path.exists(expand_path(env))
    home = os.environ.get("HOME", "")
    xdg = os.environ.get("XDG_CONFIG_HOME")
    candidates = []
    if xdg:
        candidates.append(os.path.join(expand_path(xdg), "cheat", "conf.yml"))
    if home:
        candidates.append(os.path.join(home, ".config", "cheat", "conf.yml"))
        candidates.append(os.path.join(home, ".cheat", "conf.yml"))
    candidates.append("/etc/cheat/conf.yml")
    for p in candidates:
        if os.path.exists(p):
            return p, True
    return candidates[0], False


def default_config():
    home = os.environ.get("HOME", "/home/agent")
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or "EDITOR_PATH"
    pager = shutil.which("pager") or "/usr/bin/pager"
    base = os.path.join(home, ".config", "cheat", "cheatsheets")
    return f"""---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: {editor}

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
# Options are available here:
#   https://github.com/alecthomas/chroma/tree/master/styles
style: monokai

# Which 'chroma' "formatter" should be applied?
# One of: "terminal", "terminal256", "terminal16m"
formatter: terminal256

# Through which pager should output be piped?
# 'less -FRX' is recommended on Unix systems
# 'more' is recommended on Windows
pager: {pager}

# The paths at which cheatsheets are available. Tags associated with a cheatpath
# are automatically attached to all cheatsheets residing on that path.
#
# Whenever cheatsheets share the same title (like 'tar'), the most local
# cheatsheets (those which come later in this file) take precedence over the
# less local sheets. This allows you to create your own "overides" for
# "upstream" cheatsheets.
#
# But what if you want to view the "upstream" cheatsheets instead of your own?
# Cheatsheets may be filtered by 'tags' in combination with the '--tag' flag.
# 
# Example: 'cheat tar --tag=community' will display the 'tar' cheatsheet that
# is tagged as 'community' rather than your own.
#
# Paths that come earlier are considered to be the most "global", and paths
# that come later are considered to be the most "local". The most "local" paths
# take precedence.
#
# See: https://github.com/cheat/cheat/blob/master/doc/cheat.1.md#cheatpaths
cheatpaths:

  # Cheatsheets that are tagged "personal" are stored here by default:
  - name: personal
    path: {base}/personal
    tags: [ personal ]
    readonly: false

  # Cheatsheets that are tagged "work" are stored here by default:
  - name: work
    path: {base}/work
    tags: [ work ]
    readonly: false

  # Community cheatsheets (https://github.com/cheat/cheatsheets):
  # To install: git clone https://github.com/cheat/cheatsheets {base}/community
  #- name: community
  #  path: {base}/community
  #  tags: [ community ]
  #  readonly: true

  # You can also use glob patterns to automatically load cheatsheets from all
  # directories that match.
  #
  # Example: overload cheatsheets for projects under ~/src/github.com/example/*/
  #- name: example-projects
  #  path: ~/src/github.com/example/**/.cheat
  #  tags: [ example ]
  #  readonly: true
"""


def no_config_error():
    sys.stdout.write("A config file was not found. Would you like to create one now? [Y/n]: ")
    sys.stdout.flush()
    sys.stderr.write("failed to create config: failed to prompt: EOF\n")
    return 1


def parse_config(path):
    cfg = {"editor": "vi", "pager": "", "colorize": False, "cheatpaths": []}
    cur = None
    for raw in open(path, encoding="utf-8", errors="replace"):
        line = raw.rstrip("\n")
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped == "---":
            continue
        if stripped.startswith("- "):
            if cur and cur.get("name") and cur.get("path"):
                cfg["cheatpaths"].append(cur)
            cur = {"tags": [], "readonly": False}
            rest = stripped[2:].strip()
            if ":" in rest:
                k, v = rest.split(":", 1)
                cur[k.strip()] = v.strip().strip('"').strip("'")
            continue
        if ":" not in stripped:
            continue
        k, v = stripped.split(":", 1)
        k, v = k.strip(), v.strip()
        if k == "cheatpaths":
            continue
        target = cur if cur is not None and k in ("name", "path", "tags", "readonly") else cfg
        if k == "tags":
            target[k] = list_value(v)
        elif k == "readonly":
            target[k] = v.lower() == "true"
        elif k == "colorize":
            cfg[k] = v.lower() == "true"
        else:
            target[k] = v.strip('"').strip("'")
    if cur and cur.get("name") and cur.get("path"):
        cfg["cheatpaths"].append(cur)
    out = []
    for cp in cfg["cheatpaths"]:
        for p in glob.glob(expand_path(cp["path"]), recursive=True) or [expand_path(cp["path"])]:
            n = dict(cp)
            n["path"] = p
            out.append(n)
    cfg["cheatpaths"] = out
    add_cwd_cheatpath(cfg)
    return cfg


def add_cwd_cheatpath(cfg):
    here = os.getcwd()
    while True:
        p = os.path.join(here, ".cheat")
        if os.path.isdir(p):
            cfg["cheatpaths"].append({"name": "cwd", "path": p, "tags": [], "readonly": False})
            return
        parent = os.path.dirname(here)
        if parent == here:
            return
        here = parent


def parse_frontmatter(text):
    tags = []
    syntax = ""
    if text.startswith("---\n") or text.startswith("---\r\n"):
        lines = text.splitlines(True)
        end = None
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                end = i
                break
        if end is not None:
            for line in lines[1:end]:
                s = line.strip()
                if s.startswith("tags:"):
                    tags.extend(list_value(s.split(":", 1)[1]))
                elif s.startswith("syntax:"):
                    syntax = s.split(":", 1)[1].strip().strip('"').strip("'")
            return "".join(lines[end + 1:]), tags, syntax
    return text, tags, syntax


def scan_sheets(cfg):
    sheets = []
    for idx, cp in enumerate(cfg["cheatpaths"]):
        root = cp["path"]
        if not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.startswith(".") and d != ".git"]
            for fn in filenames:
                if fn.startswith("."):
                    continue
                full = os.path.join(dirpath, fn)
                if not os.path.isfile(full):
                    continue
                title = os.path.relpath(full, root).replace(os.sep, "/")
                try:
                    raw = open(full, encoding="utf-8", errors="replace").read()
                except OSError:
                    continue
                body, ftags, syntax = parse_frontmatter(raw)
                tags = sorted(set(cp.get("tags", []) + ftags))
                sheets.append({"title": title, "file": full, "body": body, "tags": tags,
                               "path": cp["name"], "cp": cp, "idx": idx, "syntax": syntax})
    sheets.sort(key=lambda s: (s["title"], s["file"]))
    return sheets


def filter_sheets(sheets, opts, positional_filter=True):
    out = sheets
    if opts.get("path"):
        out = [s for s in out if s["path"] == opts["path"]]
    if opts.get("tag"):
        out = [s for s in out if opts["tag"] in s["tags"]]
    if positional_filter and opts.get("args"):
        q = opts["args"][0]
        out = [s for s in out if s["title"] == q or s["title"].startswith(q)]
    return out


def print_table(rows, columns):
    widths = []
    for i, name in enumerate(columns):
        widths.append(max([len(name)] + [len(r[i]) for r in rows]))
    print(" ".join(name.ljust(widths[i]) for i, name in enumerate(columns)).rstrip())
    for r in rows:
        print(" ".join(r[i].ljust(widths[i]) for i in range(len(columns))).rstrip())


def list_cmd(sheets, opts, brief=False):
    rows = []
    for s in filter_sheets(sheets, opts):
        if brief:
            rows.append([s["title"], ",".join(s["tags"])])
        else:
            rows.append([s["title"], s["file"], ",".join(s["tags"])])
    print_table(rows, ["title:", "tags:"] if brief else ["title:", "file:", "tags:"])
    return 0


def dirs_cmd(cfg):
    names = [cp["name"] for cp in cfg["cheatpaths"]]
    w = max([0] + [len(n) + 1 for n in names])
    for cp in cfg["cheatpaths"]:
        print(f"{(cp['name'] + ':').ljust(w)} {cp['path']}")
    return 0


def display_one(sheets, opts):
    matches = [s for s in filter_sheets(sheets, opts) if s["title"] == opts["args"][0]]
    if not matches:
        print(f"No cheatsheet found for '{opts['args'][0]}'.")
        return 2
    if opts.get("all"):
        for i, s in enumerate(sorted(matches, key=lambda x: x["idx"])):
            if i:
                print()
            print(f"{s['title']} ({s['path']})")
            for line in s["body"].splitlines():
                print("\t" + line)
        return 0
    chosen = max(matches, key=lambda s: s["idx"])
    sys.stdout.write(chosen["body"])
    if chosen["body"] and not chosen["body"].endswith("\n"):
        print()
    return 0


def search_cmd(sheets, opts):
    phrase = opts["search"]
    found = []
    for s in filter_sheets(sheets, opts, positional_filter=False):
        try:
            ok = re.search(phrase, s["body"], re.MULTILINE) is not None if opts.get("regex") else phrase.lower() in s["body"].lower()
        except re.error as e:
            print(f"invalid regex: {e}", file=sys.stderr)
            return 1
        if ok:
            found.append(s)
    for i, s in enumerate(found):
        if i:
            print()
        print(f"{s['title']} ({s['path']})")
        for line in s["body"].splitlines():
            print("\t" + line)
    return 0


def edit_cmd(sheets, cfg, opts):
    title = opts["edit"]
    matches = [s for s in filter_sheets(sheets, opts, positional_filter=False) if s["title"] == title]
    writable = [cp for cp in cfg["cheatpaths"] if not cp.get("readonly") and (not opts.get("path") or cp["name"] == opts["path"])]
    if matches and not matches[-1]["cp"].get("readonly"):
        target = matches[-1]["file"]
    else:
        if not writable:
            print("No writeable cheatpath available.")
            return 1
        target = os.path.join(writable[-1]["path"], *title.split("/"))
        if matches and not os.path.exists(target):
            os.makedirs(os.path.dirname(target), exist_ok=True)
            shutil.copyfile(matches[-1]["file"], target)
    os.makedirs(os.path.dirname(target), exist_ok=True)
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or cfg.get("editor") or "vi"
    try:
        return subprocess.call(editor.split() + [target])
    except FileNotFoundError:
        print(f"editor not found: {editor}", file=sys.stderr)
        return 1


def rm_cmd(sheets, opts):
    title = opts["rm"]
    matches = [s for s in filter_sheets(sheets, opts, positional_filter=False) if s["title"] == title and not s["cp"].get("readonly")]
    if not matches:
        print(f"No cheatsheet found for '{title}'.")
        return 2
    os.remove(max(matches, key=lambda s: s["idx"])["file"])
    return 0


def tags_cmd(sheets, opts):
    tags = sorted(set(t for s in filter_sheets(sheets, opts, positional_filter=False) for t in s["tags"]))
    for t in tags:
        print(t)
    return 0


def update_cmd(cfg, opts):
    for cp in cfg["cheatpaths"]:
        if opts.get("path") and cp["name"] != opts["path"]:
            continue
        gitdir = os.path.join(cp["path"], ".git")
        if os.path.isdir(gitdir):
            subprocess.call(["git", "-C", cp["path"], "pull", "--ff-only"])
    return 0


def completion(shell):
    if shell not in ("bash", "zsh", "fish", "powershell"):
        print(f"unsupported shell: {shell} (valid: bash, zsh, fish, powershell)")
        return 1
    print(f"# {shell} completion for cheat")
    print("# generated by cheat")
    return 0


def parse_args(argv):
    opts = {"args": []}
    i = 0
    needs = {"-e": "edit", "--edit": "edit", "-p": "path", "--path": "path",
             "-s": "search", "--search": "search", "-t": "tag", "--tag": "tag",
             "--rm": "rm", "--completion": "completion"}
    flags = {"-a": "all", "--all": "all", "-b": "brief", "--brief": "brief",
             "-c": "colorize", "--colorize": "colorize", "-d": "directories",
             "--directories": "directories", "-h": "help", "--help": "help",
             "--init": "init", "-l": "list", "--list": "list", "-r": "regex",
             "--regex": "regex", "-T": "tags", "--tags": "tags",
             "-u": "update", "--update": "update", "-v": "version", "--version": "version",
             "--conf": "conf"}
    while i < len(argv):
        a = argv[i]
        if a in needs:
            if i + 1 >= len(argv):
                print(f"flag needs an argument: {a}", file=sys.stderr)
                opts["parse_error"] = 1
                return opts
            opts[needs[a]] = argv[i + 1]
            i += 2
        elif any(a.startswith(k + "=") for k in needs if k.startswith("--")):
            k, v = a.split("=", 1)
            opts[needs[k]] = v
            i += 1
        elif a in flags:
            opts[flags[a]] = True
            i += 1
        elif a.startswith("--"):
            print(f"unknown flag: {a}")
            opts["parse_error"] = 1
            return opts
        elif a.startswith("-") and len(a) > 1:
            print(f"unknown shorthand flag: '{a[1]}' in {a}")
            opts["parse_error"] = 1
            return opts
        else:
            opts["args"].append(a)
            i += 1
    return opts


def main(argv):
    opts = parse_args(argv)
    if opts.get("parse_error"):
        return 1
    if opts.get("help"):
        print(HELP)
        return 0
    if opts.get("version"):
        print(VERSION)
        return 0
    if opts.get("init"):
        sys.stdout.write(default_config())
        return 0
    if opts.get("completion") is not None:
        return completion(opts["completion"])
    cfg_path, exists = find_config_path()
    if opts.get("conf"):
        if exists:
            print(cfg_path)
            return 0
        return no_config_error()
    if not exists:
        return no_config_error()
    cfg = parse_config(cfg_path)
    sheets = scan_sheets(cfg)
    if cfg.get("colorize"):
        opts["colorize"] = True
    if opts.get("directories"):
        return dirs_cmd(cfg)
    if opts.get("list"):
        return list_cmd(sheets, opts, False)
    if opts.get("brief"):
        return list_cmd(sheets, opts, True)
    if opts.get("tags"):
        return tags_cmd(sheets, opts)
    if opts.get("search") is not None:
        return search_cmd(sheets, opts)
    if opts.get("edit") is not None:
        return edit_cmd(sheets, cfg, opts)
    if opts.get("rm") is not None:
        return rm_cmd(sheets, opts)
    if opts.get("update"):
        return update_cmd(cfg, opts)
    if opts.get("args"):
        return display_one(sheets, opts)
    print(HELP)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
