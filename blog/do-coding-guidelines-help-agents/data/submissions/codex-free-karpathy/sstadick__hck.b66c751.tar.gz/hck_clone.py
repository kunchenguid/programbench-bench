#!/usr/bin/env python3
import argparse
import gzip
import os
import re
import sys
from datetime import datetime, timezone


VERSION = "hck git:23bebe8-modified"
SHORT_HELP = """* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Input files to parse, defaults to stdin

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout
  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag [default: \\s+]
  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs [default: "\\t"]
  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals
  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions
  -Z, --try-compress
          Try to gzip compress the output
  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in `hck` staying single threaded [default: 4]
  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level [default: 6]
      --no-mmap
          Disallow the possibility of using mmap
      --crlf
          Support CRLF newlines
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""


def error(message, status=1):
    stamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    sys.stderr.write(f"[{stamp} ERROR hck] {message}\n")
    raise SystemExit(status)


def parse_fields(spec):
    ranges = []
    if spec is None:
        return ranges
    for part in spec.split(","):
        if "-" in part:
            lo_s, hi_s = part.split("-", 1)
            if lo_s == "" and hi_s == "":
                error("Failed to parse field: ")
            lo = None
            hi = None
            if lo_s:
                try:
                    lo = int(lo_s)
                except ValueError:
                    error(f"Failed to parse field: {lo_s}")
            if hi_s:
                try:
                    hi = int(hi_s)
                except ValueError:
                    error(f"Failed to parse field: {hi_s}")
            for val in (lo, hi):
                if val == 0:
                    error("Fields and positions are numbered from 1: 0")
            if lo is not None and hi is not None and hi < lo:
                error(f"High end of range less than low end of range: {part}")
            ranges.append((lo, hi))
        else:
            try:
                val = int(part)
            except ValueError:
                error(f"Failed to parse field: {part}")
            if val == 0:
                error("Fields and positions are numbered from 1: 0")
            ranges.append((val, val))
    return ranges


def expand_ranges(ranges, width):
    out = []
    for lo, hi in ranges:
        start = 1 if lo is None else lo
        end = width if hi is None else hi
        if start > width:
            continue
        end = min(end, width)
        for n in range(start, end + 1):
            out.append(n - 1)
    return out


def split_line(line, args):
    eol = "\n"
    if args.crlf:
        if line.endswith("\r\n"):
            line = line[:-2]
            eol = "\r\n"
        elif line.endswith("\n"):
            line = line[:-1]
        elif line.endswith("\r"):
            line = line[:-1]
            eol = "\r"
    else:
        if line.endswith("\n"):
            line = line[:-1]
    if args.delim_is_literal:
        return line.split(args.delimiter), eol
    return re.split(args.delimiter, line), eol


def header_matches(name, pattern, regex):
    if regex:
        return re.search(pattern, name) is not None
    return name == pattern


def header_indices(headers, args):
    selected = []
    for pat in args.header_field:
        for i, h in enumerate(headers):
            if header_matches(h, pat, args.header_is_regex):
                selected.append(i)
    return selected


def excluded_header_indices(headers, args):
    excluded = []
    for pat in args.exclude_header:
        for i, h in enumerate(headers):
            if header_matches(h, pat, args.header_is_regex):
                excluded.append(i)
    return excluded


def choose_indices(width, fields, excludes, header_sel, header_excl, have_header_sel):
    if have_header_sel:
        base = list(header_sel)
        base.extend(expand_ranges(fields, width))
    elif fields:
        base = expand_ranges(fields, width)
    else:
        base = list(range(width))

    exclude_set = set(expand_ranges(excludes, width))
    exclude_set.update(i for i in header_excl if i < width)

    seen = set()
    out = []
    for i in base:
        if i < 0 or i >= width or i in exclude_set or i in seen:
            continue
        seen.add(i)
        out.append(i)
    return out


def open_input(path, try_decompress):
    if path == "-":
        return sys.stdin
    if try_decompress and path.endswith(".gz"):
        return gzip.open(path, "rt", newline="")
    return open(path, "r", newline="")


def open_output(path, try_compress):
    if path is None:
        if try_compress:
            return gzip.open(sys.stdout.buffer, "wt", newline="")
        return sys.stdout
    if try_compress or path.endswith(".gz"):
        return gzip.open(path, "wt", newline="")
    return open(path, "w", newline="")


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)


def build_parser():
    p = Parser(
        prog="executable",
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
        description="* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`",
    )
    p.add_argument("-o", "--output")
    p.add_argument("-d", "--delimiter", default=r"\s+")
    p.add_argument("-L", "--delim-is-literal", action="store_true")
    p.add_argument("-I", "--use-input-delim", action="store_true")
    p.add_argument("-D", "--output-delimiter", default="\t")
    p.add_argument("-f", "--fields")
    p.add_argument("-e", "--exclude")
    p.add_argument("-E", "--exclude-header", action="append", default=[])
    p.add_argument("-F", "--header-field", action="append", default=[])
    p.add_argument("-r", "--header-is-regex", action="store_true")
    p.add_argument("-z", "--try-decompress", action="store_true")
    p.add_argument("-Z", "--try-compress", action="store_true")
    p.add_argument("-t", "--compression-threads", default="4")
    p.add_argument("-l", "--compression-level", default="6")
    p.add_argument("--no-mmap", action="store_true")
    p.add_argument("--crlf", action="store_true")
    p.add_argument("-h", "--help", action="help")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("inputs", nargs="*")
    return p


def process_stream(fh, out, args, fields, excludes, state):
    for line in fh:
        cols, eol = split_line(line, args)
        header_sel = []
        if state["need_header"]:
            state["need_header"] = False
            state["header_excl"] = excluded_header_indices(cols, args)
            if args.header_field:
                state["header_sel"] = header_indices(cols, args)
                if not state["header_sel"]:
                    error("No headers matched")
            header_sel = state["header_sel"]
        else:
            header_sel = state["header_sel"]
        idxs = choose_indices(
            len(cols),
            fields,
            excludes,
            header_sel,
            state["header_excl"],
            bool(args.header_field),
        )
        out.write(args.output_delimiter.join(cols[i] for i in idxs) + eol)


def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    if "-h" in argv or "--help" in argv:
        print(SHORT_HELP, end="")
        return 0
    args = build_parser().parse_args(argv)
    if args.version:
        print(VERSION)
        return 0
    if args.use_input_delim and args.delim_is_literal and args.output_delimiter == "\t":
        args.output_delimiter = args.delimiter

    fields = parse_fields(args.fields)
    excludes = parse_fields(args.exclude)
    state = {"need_header": bool(args.header_field or args.exclude_header), "header_sel": [], "header_excl": []}
    paths = args.inputs or ["-"]

    out = open_output(args.output, args.try_compress)
    try:
        for path in paths:
            with open_input(path, args.try_decompress) as fh:
                process_stream(fh, out, args, fields, excludes, state)
    finally:
        if out is not sys.stdout:
            out.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
