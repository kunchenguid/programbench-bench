#!/usr/bin/env python3
import math
import sys


class CalcError(Exception):
    pass


class SyntaxCalcError(CalcError):
    pass


class ParserCalcError(CalcError):
    pass


class DomainCalcError(CalcError):
    pass


class MathCalcError(CalcError):
    pass


FUNCS1 = {
    "sin", "cos", "tan", "csc", "sec", "cot",
    "sinh", "cosh", "tanh", "asin", "acos", "atan",
    "acsc", "asec", "acot", "ln", "log2", "log10",
    "sqrt", "ceil", "floor", "abs",
}
FUNCS2 = {"log", "nroot"}
CONSTS = {"pi": math.pi, "e": math.e}


def tokenize(text):
    toks = []
    i = 0
    while i < len(text):
        c = text[i]
        if c.isspace():
            i += 1
            continue
        if c.isdigit() or c == ".":
            j = i
            dots = 0
            while j < len(text) and (text[j].isdigit() or text[j] == "."):
                dots += text[j] == "."
                j += 1
            if dots > 1 or text[i:j] == ".":
                raise SyntaxCalcError("Invalid number")
            toks.append(("num", float(text[i:j])))
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < len(text) and (text[j].isalpha() or text[j].isdigit() or text[j] == "_"):
                j += 1
            toks.append(("name", text[i:j]))
            i = j
            continue
        if c == "*" and i + 1 < len(text) and text[i + 1] == "*":
            toks.append(("op", "^"))
            i += 2
            continue
        if c in "+-*/^(),":
            toks.append(("op", c))
            i += 1
            continue
        raise SyntaxCalcError(f"Unexpected character '{c}'")
    return insert_implicit_mul(balance_parens(toks))


def balance_parens(toks):
    bal = 0
    out = []
    for t in toks:
        if t == ("op", "("):
            bal += 1
        elif t == ("op", ")"):
            if bal == 0:
                raise SyntaxCalcError("Unmatched closing parenthesis")
            bal -= 1
        out.append(t)
    out.extend([("op", ")")] * bal)
    return out


def can_end(tok):
    return tok[0] == "num" or tok[0] == "name" or tok == ("op", ")")


def can_start(tok):
    return tok[0] == "num" or tok[0] == "name" or tok == ("op", "(")


def insert_implicit_mul(toks):
    out = []
    for i, tok in enumerate(toks):
        if out and can_end(out[-1]) and can_start(tok):
            # Function calls are not multiplication: sin(...), log(...).
            if not (out[-1][0] == "name" and tok == ("op", "(")):
                out.append(("op", "*"))
        out.append(tok)
    return out


class Parser:
    def __init__(self, toks, angle, previous):
        self.toks = toks
        self.pos = 0
        self.angle = angle
        self.previous = previous

    def peek(self):
        if self.pos < len(self.toks):
            return self.toks[self.pos]
        return None

    def eat(self, typ=None, val=None):
        tok = self.peek()
        if tok is None:
            return None
        if typ is not None and tok[0] != typ:
            return None
        if val is not None and tok[1] != val:
            return None
        self.pos += 1
        return tok

    def parse(self):
        if not self.toks:
            raise SyntaxCalcError("Empty expression")
        v = self.expr()
        if self.peek() is not None:
            raise ParserCalcError("Too many operands, too few operators")
        return v

    def expr(self):
        v = self.term()
        while True:
            if self.eat("op", "+"):
                v += self.term()
            elif self.eat("op", "-"):
                v -= self.term()
            else:
                return v

    def term(self):
        v = self.power()
        while True:
            if self.eat("op", "*"):
                v *= self.power()
            elif self.eat("op", "/"):
                rhs = self.power()
                if rhs == 0:
                    raise MathCalcError("Divide by zero error!")
                v /= rhs
            else:
                return v

    def power(self):
        v = self.unary()
        if self.eat("op", "^"):
            rhs = self.power()
            try:
                v = math.pow(v, rhs)
            except ValueError:
                raise DomainCalcError("Out of bounds!")
        return v

    def unary(self):
        if self.eat("op", "+"):
            return self.unary()
        if self.eat("op", "-"):
            return -self.unary()
        return self.primary()

    def primary(self):
        tok = self.peek()
        if tok is None:
            raise ParserCalcError("Too many operators, too few operands")
        if self.eat("op", "("):
            v = self.expr()
            if not self.eat("op", ")"):
                raise SyntaxCalcError("Unmatched opening parenthesis")
            return v
        tok = self.eat("num")
        if tok:
            return tok[1]
        tok = self.eat("name")
        if tok:
            name = tok[1]
            if self.eat("op", "("):
                args = []
                if not self.eat("op", ")"):
                    while True:
                        args.append(self.expr())
                        if self.eat("op", ")"):
                            break
                        if not self.eat("op", ","):
                            raise SyntaxCalcError("Expected comma or closing parenthesis")
                return self.call(name, args)
            if name == "_":
                if self.previous is None:
                    print("No previous history.")
                    return 0.0
                return self.previous
            if name in CONSTS:
                return CONSTS[name]
            raise SyntaxCalcError(f"Unknown variable '{name}'")
        raise ParserCalcError("Too many operators, too few operands")

    def to_rad(self, x):
        if self.angle == "radian":
            return x
        if self.angle == "gradian":
            return x * math.pi / 200.0
        return x * math.pi / 180.0

    def from_rad(self, x):
        if self.angle == "radian":
            return x
        if self.angle == "gradian":
            return x * 200.0 / math.pi
        return x * 180.0 / math.pi

    def call(self, name, args):
        if name not in FUNCS1 and name not in FUNCS2:
            raise SyntaxCalcError(f"Unknown function '{name}'")
        if name in FUNCS1 and len(args) != 1:
            raise SyntaxCalcError(f"Function '{name}' takes 1 argument")
        if name in FUNCS2 and len(args) != 2:
            raise SyntaxCalcError(f"Function '{name}' takes 2 arguments")
        x = args[0]
        try:
            if name == "sin": return math.sin(self.to_rad(x))
            if name == "cos": return math.cos(self.to_rad(x))
            if name == "tan": return math.tan(self.to_rad(x))
            if name == "csc": return 1.0 / math.sin(self.to_rad(x))
            if name == "sec": return 1.0 / math.cos(self.to_rad(x))
            if name == "cot": return 1.0 / math.tan(self.to_rad(x))
            if name == "sinh": return math.sinh(x)
            if name == "cosh": return math.cosh(x)
            if name == "tanh": return math.tanh(x)
            if name == "asin": return self.from_rad(math.asin(x))
            if name == "acos": return self.from_rad(math.acos(x))
            if name == "atan": return self.from_rad(math.atan(x))
            if name == "acsc": return self.from_rad(math.asin(1.0 / x))
            if name == "asec": return self.from_rad(math.acos(1.0 / x))
            if name == "acot": return self.from_rad(math.atan(1.0 / x))
            if name == "ln": return math.log(x)
            if name == "log2": return math.log2(x)
            if name == "log10": return math.log10(x)
            if name == "sqrt": return math.sqrt(x)
            if name == "ceil": return math.ceil(x)
            if name == "floor": return math.floor(x)
            if name == "abs": return abs(x)
            if name == "log": return math.log(args[0], args[1])
            if name == "nroot": return math.pow(args[0], 1.0 / args[1])
        except ZeroDivisionError:
            raise MathCalcError("Divide by zero error!")
        except ValueError:
            raise DomainCalcError("Out of bounds!")
        except OverflowError:
            raise DomainCalcError("Out of bounds!")
        raise SyntaxCalcError(f"Unknown function '{name}'")


def eval_expr(text, angle="degree", previous=None):
    return Parser(tokenize(text), angle, previous).parse()


def group_decimal(s):
    neg = s.startswith("-")
    if neg:
        s = s[1:]
    if "." in s:
        whole, frac = s.split(".", 1)
    else:
        whole, frac = s, None
    parts = []
    while len(whole) > 3:
        parts.append(whole[-3:])
        whole = whole[:-3]
    parts.append(whole)
    res = ",".join(reversed(parts))
    if neg:
        res = "-" + res
    if frac is not None:
        res += "." + frac
    return res


def convert_base(value, base, fix):
    digits = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    neg = value < 0
    value = abs(value)
    whole = int(math.floor(value))
    frac = value - whole
    if base == 1:
        out = "1" * whole if whole else "0"
        if neg:
            out = "-" + out
        return out + ".0"
    if whole == 0:
        out = "0"
    else:
        out = ""
        while whole:
            out = digits[whole % base] + out
            whole //= base
    if neg:
        out = "-" + out
    frac_digits = []
    # Reference emits enough non-decimal fractional digits to represent simple
    # terminating fractions, and at least one digit.
    limit = max(1, fix)
    while len(frac_digits) < limit:
        frac *= base
        d = int(math.floor(frac + 1e-12))
        frac_digits.append(digits[d])
        frac -= d
        if abs(frac) < 1e-12:
            break
    if not frac_digits:
        frac_digits = ["0"]
    return base_group(out, base) + "." + "".join(frac_digits)


def base_group(s, base):
    neg = s.startswith("-")
    if neg:
        s = s[1:]
    parts = []
    while len(s) > 3:
        parts.append(s[-3:])
        s = s[:-3]
    parts.append(s)
    parts = list(reversed(parts))
    # eva appears to reserve four base groups for non-decimal output.
    while len(parts) < 4:
        parts.insert(0, "")
    if neg:
        if len(parts[-1]) <= 3 and len(parts) >= 2:
            parts[-2] = "-"
        else:
            parts[-1] = "-" + parts[-1]
    first = parts[0]
    rendered = first.rjust(1)
    for p in parts[1:]:
        rendered += "," + p.rjust(3)
    return rendered


def format_value(value, base, fix):
    if base == 10:
        return group_decimal(f"{value:.{fix}f}")
    return convert_base(value, base, fix)


def print_help():
    print("""Calculator REPL similar to bc(1)

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Optional expression string to run eva in command mode

Options:
  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]
  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]
  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]
  -h, --help                     Print help
  -V, --version                  Print version""")


def parse_args(argv):
    fix = 10
    base = 10
    angle = "degree"
    expr = None
    i = 0
    literal = False
    while i < len(argv):
        a = argv[i]
        if literal:
            expr = " ".join(argv[i:])
            break
        if a == "--":
            literal = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print_help()
            sys.exit(0)
        if a in ("-V", "--version"):
            print("eva 0.3.1")
            sys.exit(0)
        if a in ("-f", "--fix"):
            i += 1
            if i >= len(argv):
                print(f"error: a value is required for '{a} <FIX>'", file=sys.stderr)
                sys.exit(2)
            try:
                fix = int(argv[i])
            except ValueError:
                print(f"error: invalid value '{argv[i]}' for '--fix <FIX>'", file=sys.stderr)
                sys.exit(2)
            if fix < 1 or fix > 64:
                print(f"error: invalid value '{fix}' for '--fix <FIX>': {fix} is not in 1..=64\n\nFor more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
        elif a in ("-b", "--base"):
            i += 1
            if i >= len(argv):
                print(f"error: a value is required for '{a} <RADIX>'", file=sys.stderr)
                sys.exit(2)
            base = int(argv[i])
            if base < 1 or base > 36:
                print(f"error: invalid value '{base}' for '--base <RADIX>': {base} is not in 1..=36\n\nFor more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
        elif a in ("-a", "--angle_unit"):
            i += 1
            if i >= len(argv):
                print(f"error: a value is required for '{a} <angle_unit>'", file=sys.stderr)
                sys.exit(2)
            angle = argv[i]
            if angle not in ("degree", "radian", "gradian"):
                print(f"error: invalid value '{angle}' for '--angle_unit <angle_unit>'", file=sys.stderr)
                sys.exit(2)
        elif a == "-r":
            angle = "radian"
        elif a.startswith("-") and expr is None:
            print(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        else:
            expr = " ".join(argv[i:])
            break
        i += 1
    return fix, base, angle, expr


def run_one(expr, fix, base, angle, previous=None):
    try:
        val = eval_expr(expr, angle, previous)
        print(format_value(val, base, fix))
        return 0, val
    except ParserCalcError as e:
        print(f"Parser Error: {e}", file=sys.stderr)
    except DomainCalcError as e:
        print(f"Domain Error: {e}", file=sys.stderr)
    except MathCalcError as e:
        print(f"Math Error: {e}", file=sys.stderr)
    except SyntaxCalcError as e:
        print(f"Syntax Error: {e}", file=sys.stderr)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
    return 1, previous


def main():
    fix, base, angle, expr = parse_args(sys.argv[1:])
    if expr is not None:
        code, _ = run_one(expr, fix, base, angle)
        sys.exit(code)
    previous = None
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        code, val = run_one(line, fix, base, angle, previous)
        if code == 0:
            previous = val


if __name__ == "__main__":
    main()
