#!/usr/bin/env python3
import os
import re
import sys

VERSION = "bat 0.26.1 (610b77c)"

THEMES = """1337
Catppuccin Frappe
Catppuccin Latte
Catppuccin Macchiato
Catppuccin Mocha
Coldark-Cold
Coldark-Dark
DarkNeon
Dracula
GitHub
Monokai Extended
Monokai Extended Bright
Monokai Extended Light
Monokai Extended Origin
Nord
OneHalfDark
OneHalfLight
Solarized (dark)
Solarized (light)
Sublime Snazzy
TwoDark
Visual Studio Dark+
ansi
base16
base16-256
gruvbox-dark
gruvbox-light
zenburn
"""

LANGUAGES = """ActionScript:as
Ada:adb,ads,gpr
Apache Conf:envvars,htaccess,HTACCESS,.htaccess,httpd.conf
AppleScript:applescript,script editor
ARM Assembly:s,S
AsciiDoc (Asciidoctor):adoc,ad,asciidoc
ASP:asa
Authorized Keys:authorized_keys,pub,authorized_keys2
AWK:awk
Batch File:bat,cmd
BibTeX:bib
Bourne Again Shell (bash):sh,bash,zsh,ash,.bashrc,.profile
C:c
C#:cs,csx
C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h
Cabal:cabal
CFML:cfml,cfm,cfc
Clojure:clj,cljc,cljs,edn
CMake:CMakeLists.txt,cmake
CoffeeScript:coffee,Cakefile,cson
Command Help:cmd-help,help
Crystal:cr
CSS:css
D:d,di
Dart:dart
Diff:diff,patch
Dockerfile:Dockerfile,dockerfile
Elixir:ex,exs
Elm:elm
Erlang:erl,hrl
Fish:fish
Fortran:f,for,ftn,f90,f95
F#:fs,fsx
Git Attributes:gitattributes,.gitattributes
Git Commit:COMMIT_EDITMSG,MERGE_MSG
Git Config:gitconfig,.gitconfig
Git Ignore:gitignore,.gitignore
Go:go
GraphQL:graphql,gql
Groovy:groovy,gvy
Haskell:hs
HTML:html,htm,shtml,xhtml
INI:ini,conf,cfg
Java:java
JavaScript:js,jsx,mjs,cjs
JSON:json,ipynb
Julia:jl
Kotlin:kt,kts
LaTeX:tex,ltx
Less:less
Lisp:lisp,lsp,cl
Lua:lua
Makefile:Makefile,makefile,mk
Markdown:md,markdown,mdown,mkd
Nim:nim
Objective-C:m,mm
OCaml:ml,mli
Org Mode:org
Pascal:pas
Perl:pl,pm
PHP:php,phtml
Plain Text:txt,text
PowerShell:ps1,psm1,psd1
Protocol Buffer:proto
Python:py,pyw,pyi,SConstruct,SConscript
R:r,R
Ruby:rb,erb,gemspec,Rakefile,Gemfile
Rust:rs
Scala:scala,sbt
SCSS:scss
SQL:sql
Swift:swift
TOML:toml
TypeScript:ts,tsx
VimL:vim
XML:xml,xsd,svg
YAML:yml,yaml
Zig:zig
"""

VALID_WHEN = {"auto", "never", "always"}


class Opts:
    def __init__(self):
        self.files = []
        self.number = False
        self.show_all = False
        self.notation = "unicode"
        self.tabs = 4
        self.squeeze = False
        self.squeeze_limit = None
        self.line_ranges = []
        self.quiet_empty = False
        self.decorations = "auto"
        self.color = "auto"
        self.style = None
        self.file_name = None
        self.force = False
        self.chop = False
        self.terminal_width = None
        self.help_long = False
        self.help_short = False


def eprint(s):
    sys.stderr.write(s)


def read_help(long_form):
    here = os.path.dirname(os.path.abspath(__file__))
    root = here if os.path.isdir(os.path.join(here, "doc")) else os.path.dirname(here)
    path = os.path.join(root, "doc", "long-help.txt" if long_form else "short-help.txt")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ("A cat(1) clone with syntax highlighting and Git integration.\n\n"
                "Usage: bat [OPTIONS] [FILE]...\n       bat <COMMAND>\n")


def usage_name():
    return os.path.basename(sys.argv[0]) or "bat"


def clap_error(msg, extra=None):
    eprint(f"error: {msg}\n")
    if extra:
        eprint(extra)
    eprint(f"\nUsage: {usage_name()} [OPTIONS] [FILE]...\n       {usage_name()} <COMMAND>\n")
    sys.exit(2)


def need_value(args, i, opt):
    if i + 1 >= len(args):
        clap_error(f"a value is required for '{opt} <value>' but none was supplied")
    return args[i + 1], i + 1


def parse_args(argv):
    opts = Opts()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opts.files.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            if a == "-h":
                opts.help_short = True
            else:
                opts.help_long = True
            i += 1
            continue
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a == "--list-themes":
            sys.stdout.write(THEMES)
            sys.exit(0)
        if a in ("-L", "--list-languages"):
            sys.stdout.write(LANGUAGES)
            sys.exit(0)
        if a == "--config-file":
            print(os.path.expanduser("~/.config/bat/config"))
            sys.exit(0)
        if a == "--diagnostic":
            print(f"#### Software version\n\n{VERSION}\n")
            sys.exit(0)
        if a == "--acknowledgements":
            print("bat includes syntax definitions, themes, and open source Rust libraries.")
            sys.exit(0)
        if a == "--generate-config-file":
            p = os.path.expanduser("~/.config/bat/config")
            os.makedirs(os.path.dirname(p), exist_ok=True)
            if not os.path.exists(p):
                open(p, "w", encoding="utf-8").close()
            print(f"Success! Config file written to {p}")
            sys.exit(0)
        if a in ("-A", "--show-all"):
            opts.show_all = True
        elif a in ("-n", "--number"):
            opts.number = True
        elif a == "-p" or a == "--plain":
            opts.style = "plain"
        elif a == "-pp":
            opts.style = "plain"
        elif a == "-P":
            pass
        elif a in ("-s", "--squeeze-blank"):
            opts.squeeze = True
            if opts.squeeze_limit is None:
                opts.squeeze_limit = 1
        elif a in ("-S", "--chop-long-lines"):
            opts.chop = True
        elif a in ("-f", "--force-colorization"):
            opts.force = True
            opts.decorations = "always"
            opts.color = "always"
        elif a in ("-E", "--quiet-empty"):
            opts.quiet_empty = True
        elif a in ("-u", "--unbuffered", "-d", "--diff"):
            pass
        elif a in ("-l", "--language", "--fallback-syntax", "--fallback-language",
                   "-H", "--highlight-line", "-m", "--map-syntax", "--ignored-suffix",
                   "--theme", "--theme-light", "--theme-dark", "--pager",
                   "--wrap", "--binary", "--italic-text",
                   "--diff-context"):
            _, i = need_value(argv, i, a)
        elif a == "--paging":
            v, i = need_value(argv, i, a)
            validate_when(v, "--paging <when>")
        elif a == "--strip-ansi":
            _, i = need_value(argv, i, a)
        elif a == "--completion":
            shell, i = need_value(argv, i, a)
            print_completion(shell)
            sys.exit(0)
        elif a in ("-r", "--line-range"):
            v, i = need_value(argv, i, a)
            opts.line_ranges.append(v)
        elif a == "--file-name":
            opts.file_name, i = need_value(argv, i, a)
        elif a == "--tabs":
            v, i = need_value(argv, i, a)
            opts.tabs = parse_int(v, "--tabs")
        elif a == "--terminal-width":
            v, i = need_value(argv, i, a)
            opts.terminal_width = parse_width(v)
        elif a == "--squeeze-limit":
            v, i = need_value(argv, i, a)
            opts.squeeze_limit = max(0, parse_int(v, "--squeeze-limit"))
        elif a == "--nonprintable-notation":
            v, i = need_value(argv, i, a)
            if v not in ("unicode", "caret"):
                clap_error(f"invalid value '{v}' for '--nonprintable-notation <notation>'",
                           "  [possible values: unicode, caret]\n")
            opts.notation = v
        elif a == "--color":
            v, i = need_value(argv, i, a)
            validate_when(v, "--color <when>")
            opts.color = v
        elif a == "--decorations":
            v, i = need_value(argv, i, a)
            validate_when(v, "--decorations <when>")
            opts.decorations = v
        elif a == "--style":
            opts.style, i = need_value(argv, i, a)
        elif a.startswith("--tabs="):
            opts.tabs = parse_int(a.split("=", 1)[1], "--tabs")
        elif a.startswith("--terminal-width="):
            opts.terminal_width = parse_width(a.split("=", 1)[1])
        elif a.startswith("--squeeze-limit="):
            opts.squeeze_limit = max(0, parse_int(a.split("=", 1)[1], "--squeeze-limit"))
        elif a.startswith("--line-range="):
            opts.line_ranges.append(a.split("=", 1)[1])
        elif a.startswith("--nonprintable-notation="):
            v = a.split("=", 1)[1]
            if v not in ("unicode", "caret"):
                clap_error(f"invalid value '{v}' for '--nonprintable-notation <notation>'",
                           "  [possible values: unicode, caret]\n")
            opts.notation = v
        elif a.startswith("--color="):
            v = a.split("=", 1)[1]
            validate_when(v, "--color <when>")
            opts.color = v
        elif a.startswith("--decorations="):
            v = a.split("=", 1)[1]
            validate_when(v, "--decorations <when>")
            opts.decorations = v
        elif a.startswith("--style="):
            opts.style = a.split("=", 1)[1]
        elif a.startswith("--paging=") or a.startswith("--theme=") or a.startswith("--theme-light=") or a.startswith("--theme-dark=") or a.startswith("--wrap=") or a.startswith("--pager=") or a.startswith("--language=") or a.startswith("--binary=") or a.startswith("--strip-ansi=") or a.startswith("--italic-text=") or a.startswith("--file-name=") or a.startswith("--map-syntax=") or a.startswith("--ignored-suffix=") or a.startswith("--diff-context=") or a.startswith("--fallback-syntax=") or a.startswith("--fallback-language=") or a.startswith("--highlight-line="):
            if a.startswith("--file-name="):
                opts.file_name = a.split("=", 1)[1]
            if a.startswith("--paging="):
                validate_when(a.split("=", 1)[1], "--paging <when>")
            pass
        elif a.startswith("-") and a != "-":
            handled = False
            if a.startswith("-l") and len(a) > 2:
                handled = True
            elif a.startswith("-r") and len(a) > 2:
                opts.line_ranges.append(a[2:])
                handled = True
            elif a.startswith("-H") and len(a) > 2:
                handled = True
            elif a.startswith("-m") and len(a) > 2:
                handled = True
            else:
                j = 1
                handled = True
                while j < len(a):
                    c = a[j]
                    if c == "p":
                        opts.style = "plain"
                    elif c == "n":
                        opts.number = True
                    elif c == "A":
                        opts.show_all = True
                    elif c == "s":
                        opts.squeeze = True
                        if opts.squeeze_limit is None:
                            opts.squeeze_limit = 1
                    elif c == "S":
                        opts.chop = True
                    elif c == "P":
                        pass
                    elif c == "E":
                        opts.quiet_empty = True
                    elif c == "u" or c == "d" or c == "f":
                        if c == "f":
                            opts.decorations = "always"
                            opts.color = "always"
                    elif c in ("l", "r", "H", "m"):
                        val = a[j + 1:]
                        if not val:
                            val, i = need_value(argv, i, "-" + c)
                        if c == "r":
                            opts.line_ranges.append(val)
                        j = len(a)
                        break
                    else:
                        handled = False
                        break
                    j += 1
            if not handled:
                clap_error(f"unexpected argument '{a}' found",
                           f"\n  tip: to pass '{a}' as a value, use '-- {a}'\n")
        else:
            opts.files.append(a)
        i += 1
    if opts.help_long or opts.help_short:
        sys.stdout.write(read_help(opts.help_long))
        sys.exit(0)
    if opts.squeeze_limit is not None:
        opts.squeeze = True
    return opts


def validate_when(v, opt):
    if v not in VALID_WHEN:
        clap_error(f"invalid value '{v}' for '{opt}'", "  [possible values: auto, never, always]\n")


def parse_int(v, opt):
    try:
        return int(v)
    except ValueError:
        clap_error(f"invalid value '{v}' for '{opt} <N>': invalid digit found in string")


def parse_width(v):
    try:
        return int(v)
    except ValueError:
        return None


def print_completion(shell):
    if shell not in ("bash", "fish", "zsh", "ps1"):
        clap_error(f"invalid value '{shell}' for '--completion <SHELL>'",
                   "  [possible values: bash, fish, zsh, ps1]\n")
    if shell == "bash":
        sys.stdout.write("_bat() { COMPREPLY=(); }\ncomplete -F _bat bat\n")
    elif shell == "fish":
        sys.stdout.write("complete -c bat -f\n")
    elif shell == "zsh":
        sys.stdout.write("#compdef bat\n_arguments '*:file:_files'\n")
    else:
        sys.stdout.write("using namespace System.Management.Automation\n")


def split_lines(data):
    if data == b"":
        return []
    return data.splitlines(True) if data.endswith((b"\n", b"\r")) else data.splitlines(True)


def parse_range(spec, n):
    if "::" in spec:
        center, ctx = spec.split("::", 1)
        c = int(center)
        k = int(ctx)
        return max(1, c - k), min(n, c + k)
    parts = spec.split(":")
    if len(parts) == 1:
        v = int(parts[0])
        return v, v
    start_s, end_s = parts[0], parts[1]
    if start_s.startswith("-") and start_s != "-":
        count = int(start_s[1:])
        start = max(1, n - count + 1)
    elif start_s == "":
        start = 1
    else:
        start = int(start_s)
    if end_s == "":
        end = n
    elif end_s.startswith("+"):
        end = start + int(end_s[1:])
    else:
        end = int(end_s)
    if len(parts) >= 3 and parts[2]:
        k = int(parts[2])
        start = max(1, start - k)
        end = min(n, end + k)
    return max(1, start), min(n, end)


def apply_ranges(lines, ranges):
    if not ranges:
        return lines, 1
    selected = []
    first = None
    n = len(lines)
    for r in ranges:
        try:
            a, b = parse_range(r, n)
        except Exception:
            continue
        if first is None:
            first = a
        if a <= b:
            selected.extend(lines[a - 1:b])
    return selected, first or 1


def is_blank_line(line):
    return line in (b"\n", b"\r\n", b"\r", b"")


def squeeze_lines(lines, limit):
    out = []
    blanks = 0
    for line in lines:
        if is_blank_line(line):
            blanks += 1
            if blanks <= limit:
                out.append(line)
        else:
            blanks = 0
            out.append(line)
    return out


def caret_byte(b):
    if b == 127:
        return b"^?"
    if b < 32:
        return ("^" + chr(b + 64)).encode()
    return bytes([b])


def visualize_line(line, notation, tabs):
    had_lf = line.endswith(b"\n")
    if had_lf:
        body = line[:-1]
        if body.endswith(b"\r"):
            body = body[:-1] + (b"^M" if notation == "caret" else "␍".encode())
    else:
        body = line
    out = bytearray()
    for b in body:
        if b == 9:
            if tabs == 0:
                out.append(b)
            elif notation == "caret":
                out.extend(b"^I")
            else:
                width = max(2, tabs)
                out.extend(("├" + "─" * max(1, width - 3) + "┤").encode())
        elif b == 32:
            out.extend("·".encode())
        elif b < 32 or b == 127:
            if notation == "caret":
                out.extend(caret_byte(b))
            else:
                names = {0: "␀", 7: "␇", 8: "␈", 10: "␊", 11: "␋", 12: "␌", 13: "␍", 27: "␛", 127: "␡"}
                out.extend(names.get(b, f"\\x{b:02x}").encode())
        else:
            out.append(b)
    if had_lf:
        out.extend(b"^J" if notation == "caret" else "␊".encode())
        out.extend(b"\n")
    return bytes(out)


def maybe_chop(line, width):
    if width is None or width <= 0:
        return line
    if line.endswith(b"\n"):
        core = line[:-1]
        return core[:width] + b"\n"
    return line[:width]


def emit_content(data, opts, start_line=1):
    lines = split_lines(data)
    if opts.quiet_empty and not lines:
        return
    lines, start_line = apply_ranges(lines, opts.line_ranges)
    if opts.squeeze:
        lines = squeeze_lines(lines, opts.squeeze_limit if opts.squeeze_limit is not None else 1)
    use_number = opts.number
    if opts.style and "numbers" in opts.style and opts.decorations == "always":
        use_number = True
    for idx, line in enumerate(lines, start_line):
        if opts.chop:
            line = maybe_chop(line, opts.terminal_width)
        if opts.show_all:
            line = visualize_line(line, opts.notation, opts.tabs)
        if use_number:
            if not line.endswith(b"\n"):
                line = line + b"\n"
            sys.stdout.buffer.write(f"{idx:4d} ".encode() + line)
        else:
            sys.stdout.buffer.write(line)


def decorate_header(name, data, opts):
    if opts.decorations != "always":
        return
    if not opts.style or opts.style == "plain" or opts.style == "numbers":
        return
    width = opts.terminal_width or 80
    sys.stdout.write("─" * 5 + "┬" + "─" * max(0, width - 6) + "\n")
    sys.stdout.write(f"     │ File: {name}\n")
    if "header-filesize" in opts.style or opts.style == "full":
        sys.stdout.write(f"     │ Size: {len(data)} B\n")
    sys.stdout.write("─────┼" + "─" * max(0, width - 6) + "\n")


def red_error(msg):
    eprint(f"\033[31m[bat error]\033[0m: {msg}\n")


def read_file(path):
    if path == "-":
        return sys.stdin.buffer.read(), None
    try:
        if os.path.isdir(path):
            return None, f"'{path}' is a directory."
        with open(path, "rb") as f:
            return f.read(), None
    except FileNotFoundError:
        return None, f"'{path}': No such file or directory (os error 2)"
    except PermissionError:
        return None, f"'{path}': Permission denied (os error 13)"
    except OSError as ex:
        return None, f"'{path}': {ex.strerror}"


def main():
    opts = parse_args(sys.argv[1:])
    files = opts.files or ["-"]
    status = 0
    for path in files:
        data, err = read_file(path)
        if err:
            red_error(err)
            status = 1
            continue
        name = opts.file_name or path
        decorate_header(name, data, opts)
        emit_content(data, opts)
        if opts.decorations == "always" and opts.style and opts.style not in ("plain", "numbers"):
            width = opts.terminal_width or 80
            sys.stdout.write("─────┴" + "─" * max(0, width - 6) + "\n")
    sys.exit(status)


if __name__ == "__main__":
    main()
