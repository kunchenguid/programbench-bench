package main

import (
    "encoding/json"
    "flag"
    "fmt"
    "io"
    "log"
    "os"
    "strings"
    "time"
)

type module struct {
    Path     string  `json:"Path"`
    Version  string  `json:"Version"`
    Time     string  `json:"Time"`
    Main     bool    `json:"Main"`
    Indirect bool    `json:"Indirect"`
    Update   *update `json:"Update"`
}

type update struct {
    Path    string `json:"Path"`
    Version string `json:"Version"`
    Time    string `json:"Time"`
}

type row struct {
    module string
    version string
    newVersion string
    direct string
    valid string
    hasUpdate bool
}

func main() {
    directOnly := flag.Bool("direct", false, "List only direct modules")
    updateOnly := flag.Bool("update", false, "List only modules with updates")
    ci := flag.Bool("ci", false, "Non-zero exit code when at least one outdated dependency was found")
    style := flag.String("style", "default", "Output style, pass 'markdown' for a Markdown table")
    flag.Parse()

    rows := readRows(*directOnly, *updateOnly)
    if len(rows) > 0 {
        printRows(rows, *style)
    }

    if *ci {
        for _, r := range rows {
            if r.hasUpdate {
                os.Exit(1)
            }
        }
    }
}

func readRows(directOnly, updateOnly bool) []row {
    dec := json.NewDecoder(os.Stdin)
    rows := []row{}
    for {
        var m module
        err := dec.Decode(&m)
        if err == io.EOF {
            break
        }
        if err != nil {
            log.Println(err)
            break
        }
        if m.Main {
            continue
        }
        direct := !m.Indirect
        hasUpdate := m.Update != nil
        if directOnly && !direct {
            continue
        }
        if updateOnly && !hasUpdate {
            continue
        }
        newVersion := ""
        if hasUpdate {
            newVersion = m.Update.Version
        }
        rows = append(rows, row{
            module: m.Path,
            version: m.Version,
            newVersion: newVersion,
            direct: fmt.Sprintf("%t", direct),
            valid: fmt.Sprintf("%t", validTimestamps(m)),
            hasUpdate: hasUpdate,
        })
    }
    return rows
}

func validTimestamps(m module) bool {
    if m.Update == nil || m.Time == "" || m.Update.Time == "" {
        return true
    }
    current, err1 := time.Parse(time.RFC3339, m.Time)
    newer, err2 := time.Parse(time.RFC3339, m.Update.Time)
    if err1 != nil || err2 != nil {
        return true
    }
    return !newer.Before(current)
}

func printRows(rows []row, style string) {
    headers := []string{"MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"}
    data := make([][]string, 0, len(rows))
    for _, r := range rows {
        data = append(data, []string{r.module, r.version, r.newVersion, r.direct, r.valid})
    }
    widths := make([]int, len(headers))
    for i, h := range headers {
        widths[i] = len(h)
    }
    for _, cells := range data {
        for i, c := range cells {
            if len(c) > widths[i] {
                widths[i] = len(c)
            }
        }
    }

    if style == "markdown" {
        printMarkdown(headers, data, widths)
        return
    }
    printDefault(headers, data, widths)
}

func printDefault(headers []string, data [][]string, widths []int) {
    border := borderLine(widths, "+")
    fmt.Println(border)
    printLine(centered(headers, widths), widths)
    fmt.Println(border)
    for _, cells := range data {
        printLine(cells, widths)
    }
    fmt.Println(border)
}

func printMarkdown(headers []string, data [][]string, widths []int) {
    printLine(centered(headers, widths), widths)
    fmt.Println(borderLine(widths, "|"))
    for _, cells := range data {
        printLine(cells, widths)
    }
}

func borderLine(widths []int, sep string) string {
    parts := make([]string, len(widths))
    for i, w := range widths {
        parts[i] = strings.Repeat("-", w+2)
    }
    return sep + strings.Join(parts, sep) + sep
}

func printLine(cells []string, widths []int) {
    fmt.Print("|")
    for i, c := range cells {
        fmt.Printf(" %-*s |", widths[i], c)
    }
    fmt.Println()
}

func centered(cells []string, widths []int) []string {
    out := make([]string, len(cells))
    for i, c := range cells {
        pad := widths[i] - len(c)
        left := pad / 2
        right := pad - left
        out[i] = strings.Repeat(" ", left) + c + strings.Repeat(" ", right)
    }
    return out
}
