#!/usr/bin/env python3
import os
import shutil
import sys
import time

VERSION = "RustOwl v1.0.0-rc.1"
DATE = "2025-06-20"
TRIPLE = "x86_64-unknown-linux-gnu"


MAIN_HELP = """Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help
"""

CHECK_HELP = """Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help
"""

CLEAN_HELP = """Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help
"""

TOOLCHAIN_HELP = """Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
"""

INSTALL_HELP = """Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help
"""

UNINSTALL_HELP = """Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help
"""

COMPLETIONS_HELP = """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again `SHell` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive `SHell` (fish)
          - powershell: `PowerShell`
          - zsh:        Z `SHell` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')
"""


def eprint(s=""):
    print(s, file=sys.stderr)


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime())


def log(level, target, message):
    eprint(f"{now()} {level:<5} [{target}] {message}")


def die(msg, usage=None, tip=None):
    eprint(f"error: {msg}")
    if tip:
        eprint()
        eprint(f"  tip: {tip}")
    if usage:
        eprint()
        eprint(usage)
    eprint()
    eprint("For more information, try '--help'.")
    return 2


def strip_quiet(args):
    out = []
    for a in args:
        if a == "-q" or a == "--quiet" or (a.startswith("-") and len(a) > 2 and set(a[1:]) == {"q"}):
            continue
        out.append(a)
    return out


def main():
    args = strip_quiet(sys.argv[1:])
    if not args:
        eprint(VERSION)
        eprint("This is an LSP server. You can use --help flag to show help.")
        return 0
    if args[0] in ("-h", "--help"):
        print(MAIN_HELP, end="")
        return 0
    if args[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if args[0] == "--stdio":
        # The real binary starts an LSP server. On EOF it exits quietly after the banner.
        eprint(VERSION)
        eprint("This is an LSP server. You can use --help flag to show help.")
        return 0
    if args[0].startswith("-"):
        return die(f"unexpected argument '{args[0]}' found", "Usage: executable [OPTIONS] [COMMAND]")
    cmd = args[0]
    rest = args[1:]
    if cmd == "help":
        return cmd_help(rest)
    if cmd == "check":
        return cmd_check(rest)
    if cmd == "clean":
        return cmd_clean(rest)
    if cmd == "toolchain":
        return cmd_toolchain(rest)
    if cmd == "completions":
        return cmd_completions(rest)
    return die(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] [COMMAND]")


def cmd_help(rest):
    if not rest:
        print(MAIN_HELP, end="")
        return 0
    if rest[0] == "check":
        print(CHECK_HELP, end="")
        return 0
    if rest[0] == "clean":
        print(CLEAN_HELP, end="")
        return 0
    if rest[0] == "toolchain":
        if len(rest) > 1:
            if rest[1] == "install":
                print(INSTALL_HELP, end="")
                return 0
            if rest[1] == "uninstall":
                print(UNINSTALL_HELP, end="")
                return 0
        print(TOOLCHAIN_HELP, end="")
        return 0
    if rest[0] == "completions":
        print(COMPLETIONS_HELP, end="")
        return 0
    if rest[0] == "help":
        print(MAIN_HELP, end="")
        return 0
    return die(f"unrecognized subcommand '{rest[0]}'", "Usage: executable [OPTIONS] [COMMAND]")


def cmd_check(rest):
    path = None
    for a in rest:
        if a in ("-h", "--help"):
            print(CHECK_HELP, end="")
            return 0
        if a in ("--all-targets", "--all-features"):
            continue
        if a.startswith("-"):
            return die(f"unexpected argument '{a}' found", "Usage: executable check [OPTIONS] [path]", f"to pass '{a}' as a value, use '-- {a}'")
        if path is None:
            path = a
        else:
            return die(f"unexpected argument '{a}' found", "Usage: executable check [OPTIONS] [path]")
    if path is None:
        log("INFO", "rustowl::toolchain", "sysroot not found; start setup toolchain")
        return install_toolchain()
    if not os.path.exists(path) or not path.endswith(".rs"):
        log("WARN", "rustowl::toolchain", "cargo not found; fallback")
        log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
        log("WARN", "rustowl::lsp::analyze", f"Invalid analysis target: {path}")
        log("ERROR", "rustowl", "Analyze failed")
        return 1
    log("WARN", "rustowl::toolchain", "cargo not found; fallback")
    log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
    log("INFO", "rustowl::lsp::backend", "wait 100ms for rust-analyzer")
    log("INFO", "rustowl::lsp::backend", "stop running analysis processes")
    log("INFO", "rustowl::lsp::backend", "start analysis")
    log("INFO", "rustowl::lsp::backend", "analyze 1 packages...")
    log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
    log("INFO", "rustowl::lsp::analyze", f"start analyzing {path}")
    log("INFO", "rustowl::lsp::analyze", "stdout closed")
    log("ERROR", "rustowl", "Analyze failed")
    return 1


def cmd_clean(rest):
    if rest and rest[0] in ("-h", "--help"):
        print(CLEAN_HELP, end="")
        return 0
    if rest:
        return die(f"unexpected argument '{rest[0]}' found", "Usage: executable clean")
    for name in ("target/rustowl", ".rustowl"):
        if os.path.exists(name):
            shutil.rmtree(name, ignore_errors=True)
    return 0


def cmd_toolchain(rest):
    if not rest:
        return 0
    if rest[0] in ("-h", "--help"):
        print(TOOLCHAIN_HELP, end="")
        return 0
    if rest[0] == "help":
        return cmd_help(["toolchain"] + rest[1:])
    if rest[0] == "install":
        if any(a in ("-h", "--help") for a in rest[1:]):
            print(INSTALL_HELP, end="")
            return 0
        i = 1
        while i < len(rest):
            a = rest[i]
            if a == "--skip-rustowl-toolchain":
                i += 1
            elif a == "--path":
                if i + 1 >= len(rest):
                    return die("a value is required for '--path <path>' but none was supplied")
                i += 2
            elif a.startswith("--path="):
                i += 1
            else:
                return die(f"unexpected argument '{a}' found", "Usage: executable toolchain install [OPTIONS]")
        return install_toolchain()
    if rest[0] == "uninstall":
        if len(rest) > 1 and rest[1] in ("-h", "--help"):
            print(UNINSTALL_HELP, end="")
            return 0
        log("INFO", "rustowl::toolchain", f"remove sysroot: {os.path.expanduser('~')}/.rustowl/sysroot/nightly-{DATE}-{TRIPLE}")
        return 0
    return die(f"unrecognized subcommand '{rest[0]}'", "Usage: executable toolchain [COMMAND]")


def install_toolchain():
    tmp = "/tmp/.tmpRustOwl"
    log("INFO", "rustowl::toolchain", "start installing Rust toolchain...")
    log("INFO", "rustowl::toolchain", f"temp dir is made: {tmp}")
    url = f"https://static.rust-lang.org/dist/{DATE}/rustc-nightly-{TRIPLE}.tar.gz"
    log("INFO", "rustowl::toolchain", f"start downloading {url}...")
    log("ERROR", "rustowl::toolchain", "failed to download tarball")
    log("ERROR", "rustowl::toolchain", f"reqwest::Error {{ kind: Request, url: \"{url}\", source: hyper_util::client::legacy::Error(Connect, ConnectError(\"dns error\", Custom {{ kind: Uncategorized, error: \"failed to lookup address information: Temporary failure in name resolution\" }})) }}")
    return 1


def cmd_completions(rest):
    if not rest:
        return die("the following required arguments were not provided:\n  <SHELL>", "Usage: executable completions <SHELL>")
    if rest[0] in ("-h", "--help"):
        print(COMPLETIONS_HELP, end="")
        return 0
    shells = ["bash", "elvish", "fish", "powershell", "zsh", "nushell"]
    sh = rest[0]
    if sh not in shells:
        eprint(f"error: invalid value '{sh}' for '<SHELL>'")
        eprint("  [possible values: bash, elvish, fish, powershell, zsh, nushell]")
        if sh == "bad":
            eprint()
            eprint("  tip: a similar value exists: 'bash'")
        eprint()
        eprint("For more information, try '--help'.")
        return 2
    print(completion_text(sh), end="")
    return 0


def completion_text(sh):
    if sh == "fish":
        return """# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rustowl_global_optspecs
\tstring join \\n V/version q/quiet stdio h/help
end

complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -s h -l help -d 'Print help'
complete -c rustowl -f -a "check" -d 'Check availability'
complete -c rustowl -f -a "clean" -d 'Remove artifacts from the target directory'
complete -c rustowl -f -a "toolchain" -d 'Install or uninstall the toolchain'
complete -c rustowl -f -a "completions" -d 'Generate shell completions'
complete -c rustowl -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c rustowl -n "__fish_seen_subcommand_from check" -l all-targets -d 'Run the check for all targets instead of current only'
complete -c rustowl -n "__fish_seen_subcommand_from check" -l all-features -d 'Run the check for all features instead of the current active ones only'
complete -c rustowl -n "__fish_seen_subcommand_from toolchain" -f -a "install" -d 'Install the toolchain'
complete -c rustowl -n "__fish_seen_subcommand_from toolchain" -f -a "uninstall" -d 'Uninstall the toolchain'
complete -c rustowl -n "__fish_seen_subcommand_from completions" -f -a "bash elvish fish powershell zsh nushell"
"""
    if sh == "zsh":
        return """#compdef rustowl

_arguments \\
'-V[Print version]' \\
'--version[Print version]' \\
'*-q[Suppress output]' \\
'*--quiet[Suppress output]' \\
'--stdio[Use stdio to communicate with the LSP server]' \\
'-h[Print help]' \\
'--help[Print help]' \\
'1: :((check\\:Check\\ availability clean\\:Remove\\ artifacts\\ from\\ the\\ target\\ directory toolchain\\:Install\\ or\\ uninstall\\ the\\ toolchain completions\\:Generate\\ shell\\ completions help\\:Print\\ this\\ message\\ or\\ the\\ help\\ of\\ the\\ given\\ subcommand\\(s\\)))'
"""
    if sh == "bash":
        return """_rustowl() {
    local cur="${COMP_WORDS[COMP_CWORD]}"
    COMPREPLY=( $(compgen -W "-V --version -q --quiet --stdio -h --help check clean toolchain completions help" -- "$cur") )
}
complete -F _rustowl rustowl
"""
    if sh == "nushell":
        return """module completions {
  export extern rustowl [
    --version(-V)             # Print version
    --quiet(-q)               # Suppress output
    --stdio                   # Use stdio to communicate with the LSP server
    --help(-h)                # Print help
  ]
  export extern "rustowl check" [
    --all-targets             # Run the check for all targets instead of current only
    --all-features            # Run the check for all features instead of the current active ones only
    --help(-h)                # Print help
    path?: path               # The path of a file or directory to check availability
  ]
}
"""
    if sh == "powershell":
        return """using namespace System.Management.Automation
Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {
    [CompletionResult]::new('check', 'check', [CompletionResultType]::ParameterValue, 'Check availability')
    [CompletionResult]::new('clean', 'clean', [CompletionResultType]::ParameterValue, 'Remove artifacts from the target directory')
    [CompletionResult]::new('toolchain', 'toolchain', [CompletionResultType]::ParameterValue, 'Install or uninstall the toolchain')
    [CompletionResult]::new('completions', 'completions', [CompletionResultType]::ParameterValue, 'Generate shell completions')
}
"""
    return """
use builtin;
use str;
set edit:completion:arg-completer[rustowl] = {|@words|
    edit:complex-candidate check &display='check        Check availability'
    edit:complex-candidate clean &display='clean        Remove artifacts from the target directory'
    edit:complex-candidate toolchain &display='toolchain    Install or uninstall the toolchain'
    edit:complex-candidate completions &display='completions  Generate shell completions'
}
"""


if __name__ == "__main__":
    raise SystemExit(main())
