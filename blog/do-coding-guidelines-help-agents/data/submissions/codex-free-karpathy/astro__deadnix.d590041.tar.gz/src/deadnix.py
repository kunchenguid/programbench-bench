#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
from dataclasses import dataclass

HELP = """Find dead code in .nix files

Usage: executable [OPTIONS] [FILE_PATHS]...

Arguments:
  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]

Options:
  -l, --no-lambda-arg                  Don't check lambda parameter arguments
  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)
  -_, --no-underscore                  Don't check any bindings that start with a _
                                       (Lambda arguments starting with _ are not checked anyway.)
  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'
  -q, --quiet                          Don't print dead code report
  -e, --edit                           Remove unused code and write to source file
  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files
      --help                           
  -f, --fail                           Exit with 1 if unused code has been found
  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]
      --exclude <EXCLUDES>...          Files to exclude from analysis
  -V, --version                        Print version
"""

ID_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_'-]*")
KEYWORDS = {"let", "in", "rec", "with", "assert", "if", "then", "else", "inherit", "true", "false", "null", "or"}


@dataclass
class Tok:
    typ: str
    val: str
    start: int
    end: int
    line: int
    col: int


@dataclass
class Decl:
    name: str
    start: int
    end: int
    line: int
    col: int
    kind: str
    stmt_start: int = 0
    stmt_end: int = 0
    skip: bool = False
    alias: bool = False


def mask_source(s):
    out = list(s)
    i = 0
    n = len(s)
    while i < n:
        if s.startswith("#", i):
            j = s.find("\n", i)
            if j < 0:
                j = n
            for k in range(i, j):
                out[k] = " "
            i = j
        elif s.startswith("/*", i):
            j = s.find("*/", i + 2)
            if j < 0:
                j = n - 2
            for k in range(i, min(n, j + 2)):
                if out[k] != "\n":
                    out[k] = " "
            i = j + 2
        elif s[i] == '"':
            i += 1
            while i < n:
                if s[i] == "\\":
                    if out[i] != "\n":
                        out[i] = " "
                    if i + 1 < n and out[i + 1] != "\n":
                        out[i + 1] = " "
                    i += 2
                elif s.startswith("${", i):
                    i += 2
                    depth = 1
                    while i < n and depth:
                        if s[i] == "{":
                            depth += 1
                        elif s[i] == "}":
                            depth -= 1
                        i += 1
                elif s[i] == '"':
                    i += 1
                    break
                else:
                    if out[i] != "\n":
                        out[i] = " "
                    i += 1
        elif s.startswith("''", i):
            i += 2
            while i < n:
                if s.startswith("${", i):
                    i += 2
                    depth = 1
                    while i < n and depth:
                        if s[i] == "{":
                            depth += 1
                        elif s[i] == "}":
                            depth -= 1
                        i += 1
                elif s.startswith("''", i):
                    i += 2
                    break
                else:
                    if out[i] != "\n":
                        out[i] = " "
                    i += 1
        else:
            i += 1
    return "".join(out)


def tokenize(s):
    toks = []
    line = 1
    col = 1
    i = 0
    syms = set("{}[]();:,.?=@")
    while i < len(s):
        c = s[i]
        if c == "\n":
            line += 1
            col = 1
            i += 1
        elif c.isspace():
            col += 1
            i += 1
        else:
            m = ID_RE.match(s, i)
            if m:
                v = m.group(0)
                toks.append(Tok("id", v, i, m.end(), line, col))
                col += len(v)
                i = m.end()
            elif c in syms:
                toks.append(Tok(c, c, i, i + 1, line, col))
                col += 1
                i += 1
            else:
                col += 1
                i += 1
    return toks


def matching(toks, idx, openv, closev):
    depth = 0
    for j in range(idx, len(toks)):
        if toks[j].val == openv:
            depth += 1
        elif toks[j].val == closev:
            depth -= 1
            if depth == 0:
                return j
    return -1


def find_top_in(toks, start):
    depth = 0
    for j in range(start, len(toks)):
        v = toks[j].val
        if v in ("{", "[", "("):
            depth += 1
        elif v in ("}", "]", ")") and depth > 0:
            depth -= 1
        elif depth == 0 and v == "in":
            return j
    return -1


def skip_marked(src, pos):
    lines = src[:pos].splitlines()
    k = len(lines) - 2
    while k >= 0:
        txt = lines[k].strip()
        if not txt:
            k -= 1
            continue
        return "deadnix: skip" in txt
    return False


def attr_lambda(toks, i, src):
    if toks[i].val != "{":
        return None
    close = matching(toks, i, "{", "}")
    if close < 0:
        return None
    after = close + 1
    alias = None
    if after + 1 < len(toks) and toks[after].val == "@" and toks[after + 1].typ == "id":
        alias = toks[after + 1]
        after += 2
    if after >= len(toks) or toks[after].val != ":":
        return None
    decls = []
    depth = 0
    item_start = True
    j = i + 1
    while j < close:
        t = toks[j]
        if t.val in ("{", "[", "("):
            depth += 1
        elif t.val in ("}", "]", ")") and depth > 0:
            depth -= 1
        elif depth == 0:
            if t.val == ",":
                item_start = True
            elif item_start and t.typ == "id":
                decls.append(Decl(t.val, t.start, t.end, t.line, t.col, "pattern", skip=skip_marked(src, t.start)))
                item_start = False
                while j < close and toks[j].val != ",":
                    j += 1
                continue
        j += 1
    if alias:
        decls.append(Decl(alias.val, alias.start, alias.end, alias.line, alias.col, "pattern", skip=skip_marked(src, alias.start), alias=True))
    return decls, after


def prefixed_attr_lambda(toks, i, src):
    if i + 2 >= len(toks) or toks[i].typ != "id" or toks[i + 1].val != "@" or toks[i + 2].val != "{":
        return None
    close = matching(toks, i + 2, "{", "}")
    if close < 0 or close + 1 >= len(toks) or toks[close + 1].val != ":":
        return None
    got = attr_lambda(toks, i + 2, src)
    decls = got[0] if got else []
    t = toks[i]
    decls.append(Decl(t.val, t.start, t.end, t.line, t.col, "pattern", skip=skip_marked(src, t.start), alias=True))
    return decls, close + 1


def collect_decls(src):
    masked = mask_source(src)
    toks = tokenize(masked)
    decls = []
    for i, t in enumerate(toks):
        if t.val != "let":
            continue
        inn = find_top_in(toks, i + 1)
        if inn < 0:
            continue
        depth = 0
        j = i + 1
        while j < inn:
            v = toks[j].val
            if v in ("{", "[", "("):
                depth += 1
            elif v in ("}", "]", ")") and depth > 0:
                depth -= 1
            elif depth == 0 and v == "inherit":
                stmt_start = toks[j].start
                k = j + 1
                if k < inn and toks[k].val == "(":
                    p = matching(toks, k, "(", ")")
                    k = p + 1 if p >= 0 else k + 1
                local = []
                while k < inn and toks[k].val != ";":
                    if toks[k].typ == "id" and toks[k].val not in KEYWORDS:
                        local.append(Decl(toks[k].val, toks[k].start, toks[k].end, toks[k].line, toks[k].col, "let", stmt_start, 0, skip_marked(src, toks[k].start)))
                    k += 1
                end = toks[k].end if k < len(toks) else toks[j].end
                for d in local:
                    d.stmt_end = end
                decls.extend(local)
                j = k
            elif depth == 0 and toks[j].typ == "id":
                k = j + 1
                if k < inn and toks[k].val in (".", "="):
                    while k < inn and toks[k].val != "=":
                        k += 1
                    if k < inn:
                        e = k
                        while e < inn and toks[e].val != ";":
                            e += 1
                        end = toks[e].end if e < len(toks) else toks[k].end
                        decls.append(Decl(toks[j].val, toks[j].start, toks[j].end, toks[j].line, toks[j].col, "let", toks[j].start, end, skip_marked(src, toks[j].start)))
                        j = e
            j += 1
    for i, t in enumerate(toks):
        got = prefixed_attr_lambda(toks, i, src)
        if got:
            decls.extend(got[0])
        if t.val == "{":
            got = attr_lambda(toks, i, src)
            if got:
                decls.extend(got[0])
        if t.val == ":" and i > 0 and toks[i - 1].typ == "id" and toks[i - 1].val not in KEYWORDS:
            prev = toks[i - 2].val if i > 1 else ""
            if prev not in (".", "@"):
                a = toks[i - 1]
                decls.append(Decl(a.val, a.start, a.end, a.line, a.col, "lambda", skip=skip_marked(src, a.start)))
    seen = set()
    out = []
    for d in decls:
        key = (d.start, d.end, d.kind, d.name)
        if key not in seen:
            seen.add(key)
            out.append(d)
    return masked, toks, out


def analyze(src, opts):
    masked, toks, decls = collect_decls(src)
    all_ids = [t for t in toks if t.typ == "id"]
    decl_locs = {(d.start, d.end) for d in decls}
    results = []
    unused_msg = {"let": "Unused let binding", "lambda": "Unused lambda argument", "pattern": "Unused lambda pattern"}
    used_msg = {"let": "Used let binding", "lambda": "Used lambda argument", "pattern": "Used lambda pattern"}
    for d in decls:
        if d.skip:
            continue
        if d.name.startswith("_"):
            if opts.no_underscore:
                continue
            if d.kind == "lambda" and not opts.warn_used_underscore:
                continue
        if d.kind == "lambda" and opts.no_lambda_arg:
            continue
        if d.kind == "pattern" and opts.no_lambda_pattern_names and not d.alias:
            continue
        occ = []
        for t in all_ids:
            if t.val != d.name or (t.start == d.start and t.end == d.end) or (t.start, t.end) in decl_locs:
                continue
            if any(other.name == d.name and d.start < other.start < t.start for other in decls):
                continue
            occ.append(t)
        used = bool(occ)
        if d.name.startswith("_") and opts.warn_used_underscore and used:
            msg = f"{used_msg[d.kind]}: {d.name}"
        elif used:
            continue
        else:
            msg = f"{unused_msg[d.kind]}: {d.name}"
        results.append({"column": d.col, "endColumn": d.col + d.end - d.start, "line": d.line, "message": msg, "_decl": d})
    results.sort(key=lambda r: (r["line"], r["column"], r["message"]))
    return results


def human(path, src, results):
    if not results:
        return ""
    lines = src.splitlines()
    first = results[0]
    out = ["Warning: Unused declarations were found.", f"   ╭─[{path}:{first['line']}:{first['column']}]"]
    for r in results:
        text = lines[r["line"] - 1] if r["line"] - 1 < len(lines) else ""
        width = max(1, r["endColumn"] - r["column"])
        out.append(f" {r['line']} │{text}")
        out.append("   │" + " " * (r["column"] - 1) + "╰" + "─" * max(1, width - 1) + " " + r["message"])
    return "\n".join(out)


def edit_file(path, results):
    if not results:
        return
    with open(path) as f:
        lines = f.read().splitlines(True)
    remove = set()
    for r in results:
        d = r.get("_decl")
        if d and d.kind == "let":
            remove.add(d.line - 1)
    if remove:
        with open(path, "w") as f:
            f.write("".join(line for i, line in enumerate(lines) if i not in remove))


def gather(paths, hidden, excludes):
    out = []
    ex = {os.path.normpath(x) for x in excludes}
    for p in paths or ["."]:
        if os.path.normpath(p) in ex:
            continue
        if not os.path.exists(p):
            print(f"Error stating file {p}: No such file or directory (os error 2)", file=sys.stderr)
            continue
        if os.path.isdir(p):
            for root, dirs, files in os.walk(p):
                dirs.sort()
                files.sort()
                if not hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                    files = [f for f in files if not f.startswith(".")]
                for f in files:
                    full = os.path.join(root, f)
                    if f.endswith(".nix") and os.path.normpath(full) not in ex:
                        out.append(full)
        elif p.endswith(".nix"):
            out.append(p)
    return out


def parse_args(argv):
    if "--help" in argv:
        print(HELP.rstrip())
        sys.exit(0)
    if "-V" in argv or "--version" in argv:
        print("deadnix 1.3.1")
        sys.exit(0)
    ap = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    ap.add_argument("-l", "--no-lambda-arg", action="store_true")
    ap.add_argument("-L", "--no-lambda-pattern-names", action="store_true")
    ap.add_argument("-_", "--no-underscore", action="store_true")
    ap.add_argument("-W", "--warn-used-underscore", action="store_true")
    ap.add_argument("-q", "--quiet", action="store_true")
    ap.add_argument("-e", "--edit", action="store_true")
    ap.add_argument("-h", "--hidden", action="store_true")
    ap.add_argument("-f", "--fail", action="store_true")
    ap.add_argument("-o", "--output-format", default="human-readable")
    ap.add_argument("--exclude", nargs="+", default=[])
    ap.add_argument("paths", nargs="*")
    ns = ap.parse_args(argv)
    if ns.output_format not in ("human-readable", "json"):
        print(f"error: invalid value '{ns.output_format}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human-readable, json]\n\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    return ns


def main(argv):
    ns = parse_args(argv)
    paths = gather(ns.paths, ns.hidden, ns.exclude)
    any_found = False
    for path in paths:
        try:
            with open(path) as f:
                src = f.read()
        except OSError as e:
            print(f"Error reading file {path}: {e}", file=sys.stderr)
            continue
        res = analyze(src, ns)
        any_found = any_found or bool(res)
        if ns.edit:
            edit_file(path, res)
        if not ns.quiet and res:
            if ns.output_format == "json":
                clean = [{k: v for k, v in r.items() if not k.startswith("_")} for r in res]
                print(json.dumps({"file": path, "results": clean}, separators=(",", ":")))
            else:
                print(human(path, src, res))
    return 1 if ns.fail and any_found else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
