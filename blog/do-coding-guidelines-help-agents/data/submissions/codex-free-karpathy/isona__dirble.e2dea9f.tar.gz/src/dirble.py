#!/usr/bin/env python3
import argparse
import base64
import html.parser
import json
import os
import random
import re
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.sax.saxutils


VERSION = "Dirble 1.4.2 (commit d520c82, build 2026-04-17)"


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class LinkParser(html.parser.HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        for key, value in attrs:
            if key.lower() == "href" and value:
                self.links.append(value)


def split_values(values):
    out = []
    for value in values or []:
        for part in value.split(","):
            part = part.strip()
            if part:
                out.append(part)
    return out


def read_lines(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return [line.strip() for line in f if line.strip() and not line.lstrip().startswith("#")]


def normalize_base(uri):
    if "://" not in uri:
        uri = "http://" + uri
    return uri.rstrip("/") + "/"


def join_url(base, path):
    path = path.lstrip("/")
    return urllib.parse.urljoin(base, path)


def parse_ranges(values):
    ranges = []
    for item in split_values(values):
        if "-" in item:
            a, b = item.split("-", 1)
            ranges.append((int(a), int(b)))
        else:
            n = int(item)
            ranges.append((n, n))
    return ranges


def size_hidden(size, ranges):
    return any(a <= size <= b for a, b in ranges)


def parse_codes(values):
    return {int(x) for x in split_values(values)}


def make_candidates(words, prefixes, extensions, force_ext, ext_sub):
    candidates = []
    exts = extensions or []
    for word in words:
        word = word.strip("/")
        if not word:
            continue
        roots = []
        for prefix in prefixes:
            roots.append(prefix + word)
        roots.append(word)
        if ext_sub and "%EXT%" in word and exts:
            for ext in exts:
                e = ext[1:] if ext.startswith(".") else ext
                for root in roots:
                    candidates.append(root.replace("%EXT%", e))
            continue
        if not force_ext:
            candidates.extend(roots)
        for ext in exts:
            ext = ext if ext.startswith(".") else "." + ext
            for root in roots:
                candidates.append(root + ext)
    seen = set()
    ordered = []
    for c in candidates:
        if c not in seen:
            seen.add(c)
            ordered.append(c)
    return ordered


class Scanner:
    def __init__(self, args, words, prefixes, extensions):
        self.args = args
        self.words = words
        self.prefixes = prefixes
        self.extensions = extensions
        self.candidates = make_candidates(words, prefixes, extensions, args.force_extension, args.ext_sub)
        self.blacklist = parse_codes(args.code_blacklist)
        self.whitelist = parse_codes(args.code_whitelist)
        self.hide_lengths = parse_ranges(args.hide_lengths)
        self.not_found = {}
        self.results = []
        handlers = [NoRedirect]
        if args.ignore_cert:
            context = ssl._create_unverified_context()
            handlers.append(urllib.request.HTTPSHandler(context=context))
        self.opener = urllib.request.build_opener(*handlers)

    def request(self, url):
        method = self.args.verb.upper()
        data = b"" if method == "POST" else None
        req = urllib.request.Request(url, data=data, method=method)
        if self.args.user_agent:
            req.add_header("User-Agent", self.args.user_agent)
        for cookie in self.args.cookie or []:
            req.add_header("Cookie", cookie)
        for header in self.args.header or []:
            if ":" in header:
                name, value = header.split(":", 1)
            elif header.endswith(";"):
                name, value = header[:-1], ""
            else:
                continue
            req.add_header(name.strip(), value.strip())
        if self.args.username or self.args.password:
            token = ("%s:%s" % (self.args.username or "", self.args.password or "")).encode()
            req.add_header("Authorization", "Basic " + base64.b64encode(token).decode())
        parsed = urllib.parse.urlparse(url)
        if parsed.username or parsed.password:
            netloc = parsed.hostname or ""
            if parsed.port:
                netloc += ":%d" % parsed.port
            clean = urllib.parse.urlunparse((parsed.scheme, netloc, parsed.path, parsed.params, parsed.query, parsed.fragment))
            token = ("%s:%s" % (urllib.parse.unquote(parsed.username or ""), urllib.parse.unquote(parsed.password or ""))).encode()
            req = urllib.request.Request(clean, data=data, method=method, headers=dict(req.header_items()))
            req.add_header("Authorization", "Basic " + base64.b64encode(token).decode())
            url = clean
        try:
            with self.opener.open(req, timeout=self.args.timeout) as resp:
                body = b"" if method == "HEAD" else resp.read()
                return {"url": url, "code": resp.getcode(), "size": int(resp.headers.get("Content-Length") or len(body)),
                        "body": body, "location": ""}
        except urllib.error.HTTPError as e:
            body = b"" if method == "HEAD" else e.read()
            return {"url": url, "code": e.code, "size": int(e.headers.get("Content-Length") or len(body)),
                    "body": body, "location": e.headers.get("Location", "")}
        except Exception as e:
            if self.args.verbose:
                print("Curl error after requesting %s : %s" % (url, e), file=sys.stderr)
            return None

    def validate(self, base):
        if self.args.disable_validator or self.whitelist:
            return
        sizes = set()
        codes = set()
        for n in (10, 20, 30):
            rand = "".join(random.choice("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") for _ in range(n))
            resp = self.request(join_url(base, rand))
            if resp:
                codes.add(resp["code"])
                sizes.add(resp["size"])
        self.not_found[base] = (codes or {404}, sizes)

    def keep(self, base, resp):
        code = resp["code"]
        if self.whitelist and code not in self.whitelist:
            return False
        if code in self.blacklist:
            return False
        if size_hidden(resp["size"], self.hide_lengths):
            return False
        if not self.args.disable_validator and not self.whitelist:
            codes, sizes = self.not_found.get(base, ({404}, set()))
            if code in codes and (not sizes or resp["size"] in sizes):
                return False
        if ".ht" in urllib.parse.urlparse(resp["url"]).path and code == 403 and not self.args.show_htaccess:
            return False
        return True

    def is_listable(self, resp):
        text = resp["body"][:4096].decode("utf-8", errors="ignore").lower()
        return "index of /" in text or "<title>index of" in text

    def add_result(self, resp, is_dir=False, found_from_listable=False):
        self.results.append({
            "url": resp["url"],
            "code": resp["code"],
            "size": resp["size"],
            "is_directory": bool(is_dir),
            "is_listable": bool(is_dir and self.args.scan_listable and self.is_listable(resp)),
            "redirect_url": resp.get("location", ""),
            "found_from_listable": bool(found_from_listable),
        })

    def scrape_links(self, resp):
        parser = LinkParser()
        try:
            parser.feed(resp["body"].decode("utf-8", errors="ignore"))
        except Exception:
            return []
        urls = []
        for link in parser.links:
            if link.startswith("?") or link.startswith("#") or link in ("../", "./"):
                continue
            urls.append(urllib.parse.urljoin(resp["url"], link))
        return urls

    def scan_base(self, base, depth=0):
        self.validate(base)
        dirs = []
        for candidate in self.candidates:
            if self.args.throttle:
                time.sleep(self.args.throttle / 1000.0)
            url = join_url(base, candidate)
            resp = self.request(url)
            if not resp:
                continue
            is_dir = False
            loc = resp.get("location", "")
            if resp["code"] in (301, 302, 303, 307, 308) and loc:
                target = urllib.parse.urljoin(url, loc)
                if urllib.parse.urlparse(target).path.endswith("/"):
                    follow = self.request(target)
                    if follow:
                        resp = follow
                        resp["url"] = target.rstrip("/") + "/"
                        is_dir = True
            elif resp["url"].endswith("/"):
                is_dir = True
            if self.keep(base, resp):
                self.add_result(resp, is_dir=is_dir)
            if is_dir:
                dirs.append(resp)
                if self.args.scrape_listable and self.is_listable(resp):
                    for link in self.scrape_links(resp):
                        sub = self.request(link)
                        if sub and self.keep(base, sub):
                            self.add_result(sub, is_dir=link.endswith("/"), found_from_listable=True)
        if not self.args.disable_recursion:
            max_depth = self.args.max_recursion_depth
            if max_depth == 0 or depth < max_depth:
                for d in dirs:
                    self.scan_base(d["url"], depth + 1)

    def run(self, uris):
        for uri in uris:
            self.scan_base(normalize_base(uri))
        return self.results


def render_text(results, uris):
    results = sorted(results, key=lambda r: r["url"])
    chunks = []
    for uri in uris:
        base = normalize_base(uri)
        chunks.append("Dirble Scan Report for %s:" % base)
        for r in results:
            if not r["url"].startswith(base):
                continue
            prefix = "L" if r["is_listable"] else ("D" if r["is_directory"] else "+")
            chunks.append("%s %s (CODE:%s|SIZE:%s)" % (prefix, r["url"], r["code"], r["size"]))
        chunks.append("")
    return "\n".join(chunks) + "\n"


def render_json(results):
    results = sorted(results, key=lambda r: r["url"])
    return json.dumps(results, separators=(",", ":")).replace("},{", "},\n{")


def render_xml(results):
    results = sorted(results, key=lambda r: r["url"])
    out = ['<?xml version="1.0" encoding="UTF-8"?>', "<dirble_scan>"]
    for r in results:
        attrs = {
            "url": r["url"],
            "code": str(r["code"]),
            "content_len": str(r["size"]),
            "is_directory": str(r["is_directory"]).lower(),
            "is_listable": str(r["is_listable"]).lower(),
            "redirect_url": r["redirect_url"],
            "found_from_listable": str(r["found_from_listable"]).lower(),
        }
        attr_text = " ".join('%s="%s"' % (k, xml.sax.saxutils.escape(v, {'"': '&quot;'})) for k, v in attrs.items())
        out.append("<path %s/>" % attr_text)
    out.append("</dirble_scan>")
    return "\n".join(out)


def parser():
    p = argparse.ArgumentParser(
        prog=os.path.basename(sys.argv[0]),
        description="Fast directory scanning and scraping tool",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory
"""
    )
    p.add_argument("uri", nargs="?")
    p.add_argument("-u", "--uri", "--url", dest="uris", action="append")
    p.add_argument("-U", "--uri-file", "--url-file")
    p.add_argument("--verb", choices=["get", "head", "post"], default="get")
    p.add_argument("-w", "--wordlist")
    p.add_argument("-p", "--prefixes", nargs="+")
    p.add_argument("-P", "--prefix-file")
    p.add_argument("-x", "--extensions", nargs="+")
    p.add_argument("-X", "--extension-file")
    p.add_argument("--ext-sub", action="store_true")
    p.add_argument("-f", "--force-extension", action="store_true")
    p.add_argument("-k", "--ignore-cert", action="store_true")
    p.add_argument("--show-htaccess", action="store_true")
    p.add_argument("--timeout", type=float, default=5)
    p.add_argument("--max-errors", type=int, default=5)
    p.add_argument("--json-file", "--oJ")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("-o", "--output-file", "--oN")
    p.add_argument("--xml-file", "--oX")
    p.add_argument("--hide-lengths", nargs="+")
    p.add_argument("--output-all", "--oA")
    p.add_argument("--burp", action="store_true")
    p.add_argument("--no-proxy", action="store_true")
    p.add_argument("--proxy")
    p.add_argument("-t", "--max-threads", type=int, default=10)
    p.add_argument("-T", "--wordlist-split", type=int, default=3)
    p.add_argument("-z", "--throttle", type=int, default=0)
    p.add_argument("--username")
    p.add_argument("--password")
    p.add_argument("-l", "--scan-listable", action="store_true")
    p.add_argument("--max-recursion-depth", type=int, default=0)
    p.add_argument("-r", "--disable-recursion", action="store_true")
    p.add_argument("--scrape-listable", action="store_true")
    p.add_argument("-a", "--user-agent")
    p.add_argument("-c", "--cookie", action="append")
    p.add_argument("-H", "--header", action="append")
    p.add_argument("-S", "--silent", action="store_true")
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-B", "--code-blacklist", nargs="+")
    p.add_argument("--disable-validator", action="store_true")
    p.add_argument("-W", "--code-whitelist", nargs="+")
    p.add_argument("--scan-401", action="store_true")
    p.add_argument("--scan-403", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


def main():
    args = parser().parse_args()
    if args.version:
        print(VERSION)
        return 0
    uris = []
    if args.uri:
        uris.append(args.uri)
    uris.extend(args.uris or [])
    if args.uri_file:
        uris.extend(read_lines(args.uri_file))
    if not uris:
        parser().error("the following required arguments were not provided:\n  <uri|--uri-file <uri-file>|--uri <uri>>")

    wordlist = args.wordlist or os.path.join(os.path.dirname(os.path.abspath(sys.argv[0])), "dirble_wordlist.txt")
    if not os.path.exists(wordlist):
        print("[ERROR] Unable to find default wordlist" if not args.wordlist else "[ERROR] Unable to open wordlist")
        return 1
    words = read_lines(wordlist)
    prefixes = split_values(args.prefixes)
    if args.prefix_file:
        prefixes.extend(read_lines(args.prefix_file))
    extensions = split_values(args.extensions)
    if args.extension_file:
        extensions.extend(read_lines(args.extension_file))

    scanner = Scanner(args, words, prefixes, extensions)
    results = scanner.run(uris)
    text = render_text(results, uris)
    if not args.silent:
        print(text, end="")
    if args.output_file:
        open(args.output_file, "w", encoding="utf-8").write(text)
    if args.json_file:
        open(args.json_file, "w", encoding="utf-8").write(render_json(results))
    if args.xml_file:
        open(args.xml_file, "w", encoding="utf-8").write(render_xml(results))
    if args.output_all:
        open(args.output_all + ".txt", "w", encoding="utf-8").write(text)
        open(args.output_all + ".json", "w", encoding="utf-8").write(render_json(results))
        open(args.output_all + ".xml", "w", encoding="utf-8").write(render_xml(results))
    return 0


if __name__ == "__main__":
    sys.exit(main())
