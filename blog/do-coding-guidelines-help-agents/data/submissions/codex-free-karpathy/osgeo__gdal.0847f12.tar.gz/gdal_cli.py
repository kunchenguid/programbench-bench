#!/usr/bin/env python3
import json
import os
import shutil
import stat
import sys
from pathlib import Path

VERSION = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20"
WARNING = """WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.
The project reserves the right to modify, rename, reorganize, and change the behavior of the utility
until it is officially frozen in a future feature release of GDAL."""

TOP_COMMANDS = [
    ("convert", "Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert')."),
    ("dataset", "Commands to manage datasets."),
    ("driver", "Command for driver specific operations."),
    ("info", "Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info')."),
    ("mdim", "Multidimensional commands."),
    ("pipeline", "Process a dataset applying several steps."),
    ("raster", "Raster commands."),
    ("vector", "Vector commands."),
    ("vsi", "GDAL Virtual System Interface (VSI) commands."),
]

GROUPS = {
    "dataset": [
        ("check", "Check whether there are errors when reading the content of a dataset."),
        ("copy", "Copy files of a dataset. (alias: cp)"),
        ("delete", "Delete dataset(s). (alias: rm, remove)"),
        ("identify", "Identify driver opening dataset(s)."),
        ("rename", "Rename files of a dataset. (alias: ren, mv)"),
    ],
    "driver": [("cog", "Command for COG driver specific operations.")],
    "mdim": [
        ("convert", "Convert a multidimensional dataset."),
        ("info", "Return information on a multidimensional dataset."),
        ("mosaic", "Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets."),
    ],
    "raster": [
        ("as-features", "Create features from pixels of a raster dataset"),
        ("aspect", "Generate an aspect map"),
        ("blend", "Blend/compose two raster datasets"),
        ("calc", "Perform raster algebra"),
        ("clean-collar", "Clean the collar of a raster dataset, removing noise."),
        ("clip", "Clip a raster dataset."),
        ("color-map", "Generate a RGB or RGBA dataset from a single band, using a color map"),
        ("compare", "Compare two raster datasets."),
        ("contour", "Creates a vector contour from a raster elevation model (DEM)."),
        ("convert", "Convert a raster dataset."),
        ("create", "Create a new raster dataset."),
        ("edit", "Edit a raster dataset."),
        ("fill-nodata", "Fill nodata raster regions by interpolation from edges."),
        ("footprint", "Compute the footprint of a raster dataset."),
        ("hillshade", "Generate a shaded relief map"),
        ("index", "Create a vector index of raster datasets."),
        ("info", "Return information on a raster dataset."),
        ("mosaic", "Build a mosaic, either virtual (VRT) or materialized."),
        ("neighbors", "Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)"),
        ("nodata-to-alpha", "Replace nodata value(s) with an alpha band."),
        ("overview", "Manage overviews of a raster dataset."),
        ("pansharpen", "Perform a pansharpen operation."),
        ("pipeline", "Process a raster dataset applying several steps."),
        ("pixel-info", "Return information on a pixel of a raster dataset."),
        ("polygonize", "Create a polygon feature dataset from a raster band."),
        ("proximity", "Produces a raster proximity map."),
        ("reclassify", "Reclassify values in a raster dataset"),
        ("reproject", "Reproject a raster dataset."),
        ("resize", "Resize a raster dataset without changing the georeferenced extents."),
        ("rgb-to-palette", "Convert a RGB image into a pseudo-color / paletted image."),
        ("roughness", "Generate a roughness map"),
        ("scale", "Scale the values of the bands of a raster dataset."),
        ("select", "Select a subset of bands from a raster dataset."),
        ("set-type", "Modify the data type of bands of a raster dataset."),
        ("sieve", "Remove small polygons from a raster dataset."),
        ("slope", "Generate a slope map"),
        ("stack", "Combine together input bands into a multi-band output, either virtual (VRT) or materialized."),
        ("tile", "Generate tiles in separate files from a raster dataset."),
        ("tpi", "Generate a Topographic Position Index (TPI) map"),
        ("tri", "Generate a Terrain Ruggedness Index (TRI) map"),
        ("unscale", "Convert scaled values of a raster dataset into unscaled values."),
        ("update", "Update the destination raster with the content of the input one."),
        ("viewshed", "Compute the viewshed of a raster dataset."),
        ("zonal-stats", "Calculate raster zonal statistics"),
    ],
    "vector": [
        ("buffer", "Compute a buffer around geometries of a vector dataset."),
        ("check-coverage", "Check a polygon coverage for validity"),
        ("check-geometry", "Check a dataset for invalid geometries"),
        ("clean-coverage", "Alter polygon boundaries to make shared edges identical, removing gaps and overlaps"),
        ("clip", "Clip a vector dataset."),
        ("combine", "Combine features into collections"),
        ("concat", "Concatenate vector datasets."),
        ("concave-hull", "Compute the concave hull of geometries of a vector dataset."),
        ("convert", "Convert a vector dataset."),
        ("convex-hull", "Compute the convex hull of geometries of a vector dataset."),
        ("create", "Create a vector dataset."),
        ("dissolve", "Dissolves multipart features"),
        ("edit", "Edit metadata of a vector dataset."),
        ("explode-collections", "Explode geometries of type collection of a vector dataset."),
        ("export-schema", "Export the OGR_SCHEMA from a vector dataset."),
        ("filter", "Filter a vector dataset."),
        ("grid", "Create a regular grid from scattered points."),
        ("index", "Create a vector index of vector datasets."),
        ("info", "Return information on a vector dataset."),
        ("layer-algebra", "Perform algebraic operation between 2 layers."),
        ("make-point", "Create point geometries from attribute fields"),
        ("make-valid", "Fix validity of geometries of a vector dataset."),
        ("partition", "Partition a vector dataset into multiple files."),
        ("pipeline", "Process a vector dataset applying several steps."),
        ("rasterize", "Burns vector geometries into a raster."),
        ("rename-layer", "Rename layer(s) of a vector dataset."),
        ("reproject", "Reproject a vector dataset."),
        ("segmentize", "Segmentize geometries of a vector dataset."),
        ("select", "Select a subset of fields from a vector dataset."),
        ("set-field-type", "Modify the type of a field."),
        ("set-geom-type", "Modify the geometry type of a vector dataset."),
        ("simplify", "Simplify geometries of a vector dataset."),
        ("simplify-coverage", "Simplify shared boundaries of a polygonal vector dataset."),
        ("sort", "Spatially order the features in a layer"),
        ("sql", "Apply SQL statement(s) to a dataset."),
        ("swap-xy", "Swap X and Y coordinates of geometries of a vector dataset."),
        ("update", "Update an existing vector dataset with an input vector dataset."),
    ],
    "vsi": [
        ("copy", "Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)"),
        ("delete", "Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)"),
        ("list", "List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)"),
        ("move", "Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)"),
        ("sozip", "Seek-optimized ZIP (SOZIP) commands."),
        ("sync", "Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI)."),
    ],
}

DRIVERS = [
    {"short_name": "GTiff", "long_name": "GeoTIFF", "scopes": ["raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "COG", "long_name": "Cloud optimized GeoTIFF generator", "scopes": ["raster"], "capabilities": ["create", "create_copy", "virtual_io"], "file_extensions": ["tif", "tiff"]},
    {"short_name": "VRT", "long_name": "Virtual Raster", "scopes": ["raster", "multidimensional_raster"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["vrt"]},
    {"short_name": "MEM", "long_name": "In Memory raster, vector and multidimensional raster", "scopes": ["raster", "multidimensional_raster", "vector"], "capabilities": ["open", "create"]},
    {"short_name": "ESRI Shapefile", "long_name": "ESRI Shapefile", "scopes": ["vector"], "capabilities": ["open", "create", "update", "virtual_io"], "file_extensions": ["shp", "dbf", "shz", "shp.zip"]},
    {"short_name": "GeoJSON", "long_name": "GeoJSON", "scopes": ["vector"], "capabilities": ["open", "create", "update", "virtual_io"], "file_extensions": ["json", "geojson"]},
    {"short_name": "GeoJSONSeq", "long_name": "GeoJSON Sequence", "scopes": ["vector"], "capabilities": ["open", "create", "virtual_io"], "file_extensions": ["geojsonl", "geojsons"]},
    {"short_name": "CSV", "long_name": "Comma Separated Value (.csv)", "scopes": ["vector"], "capabilities": ["open", "create", "virtual_io"], "file_extensions": ["csv"]},
    {"short_name": "GPKG", "long_name": "GeoPackage", "scopes": ["raster", "vector"], "capabilities": ["open", "create", "create_copy", "update", "virtual_io"], "file_extensions": ["gpkg"]},
]


def out(s="", end="\n"):
    sys.stdout.write(s + end)


def common_options(quiet=False):
    lines = [
        "Common Options:",
        "  -h, --help              Display help message and exit",
        "  --json-usage            Display usage as JSON document and exit",
        "  --config <KEY>=<VALUE>  Configuration option [may be repeated]",
    ]
    if quiet:
        lines.append("  -q, --quiet             Quiet mode (no progress bar or warning message)")
    return "\n".join(lines)


def print_warning():
    out()
    out(WARNING)


def print_top_help(try_help=False):
    out("Usage: gdal <COMMAND> [OPTIONS]")
    out("where <COMMAND> is one of:")
    for name, desc in TOP_COMMANDS:
        out(f"  - {name + ':':<9} {desc}")
    out()
    if try_help:
        out("Try 'gdal --help' for help.")
    else:
        out(common_options())
        out()
        out("Options:")
        out("  --version               Display GDAL version and exit")
        out("  --drivers               Display driver list as JSON document")
    out()
    out("'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.")
    out("And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.")
    out()
    out("For more details, consult https://gdal.org/programs/index.html")
    print_warning()


def print_group_help(group):
    out(f"Usage: gdal {group} <SUBCOMMAND> [OPTIONS]")
    out("where <SUBCOMMAND> is one of:")
    pad = max(len(n) for n, _ in GROUPS[group]) + 1
    for name, desc in GROUPS[group]:
        out(f"  - {name + ':':<{pad+3}} {desc}")
    out()
    out(common_options())
    if group in ("raster", "vector", "mdim"):
        out()
        out("Options:")
        label = {"raster": "raster", "vector": "vector", "mdim": "multidimensional"}[group]
        suffix = " and exit" if group == "vector" else ""
        out(f"  --drivers               Display {label} driver list as JSON document{suffix}")
    out()
    out(f"For more details, consult https://gdal.org/programs/gdal_{group}.html")
    print_warning()


HELP = {
    ("info",): """Usage: gdal info [OPTIONS] <INPUT>

Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text

For all options, run 'gdal raster info --help' or 'gdal vector info --help'

For more details, consult https://gdal.org/programs/gdal_info.html""",
    ("convert",): """Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>

Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').

Positional arguments:
  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]
  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format

For all options, run 'gdal raster convert --help' or 'gdal vector convert --help'

For more details, consult https://gdal.org/programs/gdal_convert.html""",
    ("dataset", "identify"): """Usage: gdal dataset identify [OPTIONS] <FILENAME>

Identify driver opening dataset(s).

Positional arguments:
  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]
  -q, --quiet                                          Quiet mode (no progress bar or warning message)

Options:
  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format
  --overwrite                                          Whether overwriting existing output dataset is allowed
  -r, --recursive                                      Recursively scan files/folders for datasets
  --detailed                                           Most detailed output. Reports the presence of georeferencing, if a GeoTIFF file is cloud optimized, etc.
  --report-failures                                    Report failures if file type is unidentified

For more details, consult https://gdal.org/programs/gdal_dataset_identify.html""",
    ("dataset", "copy"): """Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset name [required]
  --destination <DESTINATION>  Destination dataset name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

Advanced Options:
  -f, --format <FORMAT>        Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_copy.html""",
    ("dataset", "delete"): """Usage: gdal dataset delete [OPTIONS] <FILENAME>

Delete dataset(s).

Positional arguments:
  --filename <FILENAME>   File or directory name [may be repeated] [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Advanced Options:
  -f, --format <FORMAT>   Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_delete.html""",
    ("dataset", "rename"): """Usage: gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>

Rename files of a dataset.

Positional arguments:
  --source <SOURCE>            Source dataset name [required]
  --destination <DESTINATION>  Destination dataset name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]

Options:
  --overwrite                  Whether overwriting existing output dataset is allowed

Advanced Options:
  -f, --format <FORMAT>        Dataset format

For more details, consult https://gdal.org/programs/gdal_dataset_rename.html""",
    ("vsi", "list"): """Usage: gdal vsi list [OPTIONS] <FILENAME>

List files of one of the GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>                                File or directory name [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --long, --long-listing                           Use a long listing format
  -R, --recursive                                      List subdirectories recursively
  --depth <DEPTH>                                      Maximum depth in recursive mode
  --abs, --absolute-path                               Display absolute path
  --tree                                               Use a hierarchical presentation for JSON output

For more details, consult https://gdal.org/programs/gdal_vsi_list.html""",
    ("vsi", "copy"): """Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>

Copy files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

Options:
  -r, --recursive              Copy subdirectories recursively
  --skip-errors                Skip errors

For more details, consult https://gdal.org/programs/gdal_vsi_copy.html""",
    ("vsi", "delete"): """Usage: gdal vsi delete [OPTIONS] <FILENAME>

Delete files located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --filename <FILENAME>   File or directory name to delete [required]

Common Options:
  -h, --help              Display help message and exit
  --json-usage            Display usage as JSON document and exit
  --config <KEY>=<VALUE>  Configuration option [may be repeated]

Options:
  -r, -R, --recursive     Delete directories recursively

For more details, consult https://gdal.org/programs/gdal_vsi_delete.html""",
    ("vsi", "move"): """Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>

Move/rename a file/directory located on GDAL Virtual System Interface (VSI).

Positional arguments:
  --source <SOURCE>            Source file or directory name [required]
  --destination <DESTINATION>  Destination file or directory name [required]

Common Options:
  -h, --help                   Display help message and exit
  --json-usage                 Display usage as JSON document and exit
  --config <KEY>=<VALUE>       Configuration option [may be repeated]
  -q, --quiet                  Quiet mode (no progress bar or warning message)

For more details, consult https://gdal.org/programs/gdal_vsi_move.html""",
    ("raster", "info"): """Usage: gdal raster info [OPTIONS] <INPUT>

Return information on a raster dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input raster dataset [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  --mm, --min-max                                      Compute minimum and maximum value
  --stats                                              Retrieve or compute statistics, using all pixels
  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels
  --hist                                               Retrieve or compute histogram

Advanced Options:
  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]
  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]
  --no-gcp                                             Suppress ground control points list printing
  --no-md                                              Suppress metadata printing
  --no-ct                                              Suppress color table printing
  --no-fl                                              Suppress file list printing
  --checksum                                           Compute pixel checksum

For more details, consult https://gdal.org/programs/gdal_raster_info.html""",
    ("vector", "info"): """Usage: gdal vector info [OPTIONS] <INPUT>...

Return information on a vector dataset.

Positional arguments:
  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]

Common Options:
  -h, --help                                           Display help message and exit
  --json-usage                                         Display usage as JSON document and exit
  --config <KEY>=<VALUE>                               Configuration option [may be repeated]

Options:
  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text
  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]
  --features                                           List all features (beware of RAM consumption on large layers)
  --summary                                            List the layer names and the geometry type
  --limit <FEATURE-COUNT>                              Limit the number of features per layer (implies --features)
  --sql <statement>|@<filename>                        Execute the indicated SQL statement and return the result
  --where <WHERE>|@<filename>                          Attribute query in a restricted form of the queries used in the SQL WHERE statement
  --fid <FID>                                          Feature identifier
  --dialect <DIALECT>                                  SQL dialect

Advanced Options:
  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]
  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]

For more details, consult https://gdal.org/programs/gdal_vector_info.html""",
    ("raster", "create"): """Usage: gdal raster create [OPTIONS] <OUTPUT>

Create a new raster dataset.

Positional arguments:
  -o, --output <OUTPUT>                                    Output raster dataset [required]

Common Options:
  -h, --help                                               Display help message and exit
  --json-usage                                             Display usage as JSON document and exit
  --config <KEY>=<VALUE>                                   Configuration option [may be repeated]
  -q, --quiet                                              Quiet mode (no progress bar or warning message)

Options:
  -i, --like, --input <INPUT>                              Input raster datasets
  -f, --of, --format, --output-format <OUTPUT-FORMAT>      Output format ("GDALG" allowed)
  --co, --creation-option <KEY>=<VALUE>                    Creation option [may be repeated]
  --overwrite                                              Whether overwriting existing output dataset is allowed
  --size <width>,<height>                                  Output size in pixels
  --band-count <BAND-COUNT>                                Number of bands (default: 1)
  --ot, --datatype, --output-data-type <OUTPUT-DATA-TYPE>  Output data type
  --nodata <NODATA>                                        Assign a specified nodata value to output bands
  --burn <BURN>                                            Burn value [may be repeated]
  --crs <CRS>                                              Set CRS
  --bbox <BBOX>                                            Bounding box as xmin,ymin,xmax,ymax
  --metadata <KEY>=<VALUE>                                 Add metadata item [may be repeated]

For more details, consult https://gdal.org/programs/gdal_raster_create.html""",
}

ALIASES = {
    ("dataset", "cp"): ("dataset", "copy"),
    ("dataset", "rm"): ("dataset", "delete"),
    ("dataset", "remove"): ("dataset", "delete"),
    ("dataset", "ren"): ("dataset", "rename"),
    ("dataset", "mv"): ("dataset", "rename"),
    ("vsi", "cp"): ("vsi", "copy"),
    ("vsi", "rm"): ("vsi", "delete"),
    ("vsi", "rmdir"): ("vsi", "delete"),
    ("vsi", "del"): ("vsi", "delete"),
    ("vsi", "ls"): ("vsi", "list"),
    ("vsi", "mv"): ("vsi", "move"),
    ("vsi", "ren"): ("vsi", "move"),
    ("vsi", "rename"): ("vsi", "move"),
}


def normalize(cmd):
    return ALIASES.get(tuple(cmd), tuple(cmd))


def print_help_for(cmd):
    cmd = normalize(cmd)
    if len(cmd) == 1 and cmd[0] in GROUPS:
        print_group_help(cmd[0])
        return
    if cmd in HELP:
        out(HELP[cmd])
        print_warning()
        return
    if len(cmd) == 2 and cmd[0] in GROUPS:
        desc = dict(GROUPS[cmd[0]]).get(cmd[1], "Process a dataset.")
        out(f"Usage: gdal {cmd[0]} {cmd[1]} [OPTIONS] <INPUT> <OUTPUT>")
        out()
        out(desc)
        out()
        out(common_options(quiet=True))
        out()
        out(f"For more details, consult https://gdal.org/programs/gdal_{cmd[0]}_{cmd[1].replace('-', '_')}.html")
        print_warning()
        return
    print_top_help(False)


def json_usage(cmd):
    if not cmd:
        data = {
            "description": "Main gdal entry point.",
            "short_url": "/programs/index.html",
            "url": "https://gdal.org/programs/index.html",
            "sub_algorithms": [
                {"name": n, "full_path": ["gdal", n], "description": d, "sub_algorithms": []}
                for n, d in TOP_COMMANDS
            ],
            "input_arguments": [],
            "output_arguments": [],
            "input_output_arguments": [],
        }
    else:
        full = ["gdal"] + list(cmd)
        desc = " ".join(cmd)
        if len(cmd) == 1 and cmd[0] in GROUPS:
            subs = [{"name": n, "full_path": full + [n], "description": d, "sub_algorithms": []} for n, d in GROUPS[cmd[0]]]
        else:
            subs = []
        data = {"description": desc, "full_path": full, "sub_algorithms": subs, "input_arguments": [], "output_arguments": [], "input_output_arguments": []}
    out(json.dumps(data, indent=2))


def driver_json(scope=None):
    if scope == "mdim":
        filt = [d for d in DRIVERS if "multidimensional_raster" in d.get("scopes", [])]
    elif scope:
        filt = [d for d in DRIVERS if scope in d.get("scopes", [])]
    else:
        filt = DRIVERS
    out(json.dumps(filt, indent=2))


def err(msg, usage=None):
    out(msg)
    if usage:
        out(usage)
        out(f"Try '{usage.split('Usage: ')[1].split(' [OPTIONS]')[0]} --help' for help.")


def positional(args):
    vals = []
    skip_next = False
    data_opts = {"-i", "--input", "--dataset", "--source", "--destination", "--filename", "-o", "--output"}
    value_opts = {"-f", "--of", "--format", "--output-format", "--config", "--depth", "--if", "--input-format", "--oo", "--open-option", "-l", "--layer", "--input-layer", "--co", "--creation-option", "--lco", "--layer-creation-option", "--size", "--band-count", "--ot", "--datatype", "--output-data-type", "--nodata", "--burn", "--crs", "--bbox", "--metadata"} | data_opts
    capture_next = False
    for a in args:
        if skip_next:
            if capture_next:
                vals.append(a)
            skip_next = False
            capture_next = False
            continue
        if a in value_opts:
            skip_next = True
            capture_next = a in data_opts
            continue
        if a.startswith("--") and "=" not in a:
            continue
        if a.startswith("-"):
            continue
        vals.append(a)
    return vals


def infer_driver(path):
    ext = Path(path).suffix.lower()
    if ext in (".tif", ".tiff"):
        return "GTiff", "raster"
    if ext == ".vrt":
        return "VRT", "raster"
    if ext in (".json", ".geojson"):
        return "GeoJSON", "vector"
    if ext in (".shp", ".dbf"):
        return "ESRI Shapefile", "vector"
    if ext == ".csv":
        return "CSV", "vector"
    if ext == ".gpkg":
        return "GPKG", "vector"
    return None, None


def info(path, fmt="text", vector=False):
    if not os.path.exists(path):
        err(f"ERROR 4: {path}: No such file or directory", f"Usage: gdal {'vector ' if vector else ''}info [OPTIONS] <INPUT>{'...' if vector else ''}")
        return 1
    drv, typ = infer_driver(path)
    if not drv:
        err(f"ERROR 4: `{path}' not recognized as a supported file format.", f"Usage: gdal {'vector ' if vector else ''}info [OPTIONS] <INPUT>{'...' if vector else ''}")
        return 1
    st = os.stat(path)
    if fmt == "json":
        data = {"description": path, "driverShortName": drv, "driverLongName": drv, "files": [path], "size": [0, 0] if typ == "raster" else None}
        data = {k: v for k, v in data.items() if v is not None}
        out(json.dumps(data, indent=2))
    else:
        if typ == "raster":
            out(f"Driver: {drv}/{drv}")
            out(f"Files: {path}")
            out("Size is 0, 0")
        else:
            out(f"INFO: Open of `{path}'")
            out(f"      using driver `{drv}' successful.")
            out(f"1: {Path(path).stem} (Unknown)")
        out(f"File size: {st.st_size}")
    return 0


def do_copy(src, dst, overwrite=False, recursive=False):
    if not os.path.exists(src):
        out(f"ERROR 4: {src}: No such file or directory")
        return 1
    if os.path.exists(dst) and not overwrite:
        out(f"ERROR 1: {dst} already exists.")
        return 1
    if os.path.isdir(src):
        if recursive:
            if os.path.exists(dst):
                shutil.rmtree(dst)
            shutil.copytree(src, dst)
        else:
            out(f"ERROR 1: {src} is a directory")
            return 1
    else:
        if os.path.isdir(dst):
            dst = os.path.join(dst, os.path.basename(src))
        shutil.copy2(src, dst)
    return 0


def do_delete(path, recursive=False):
    if not os.path.exists(path):
        out(f"ERROR 4: {path}: No such file or directory")
        return 1
    if os.path.isdir(path):
        if recursive:
            shutil.rmtree(path)
        else:
            out(f"ERROR 1: {path} is a directory")
            return 1
    else:
        os.remove(path)
    return 0


def do_list(path, args):
    if not os.path.exists(path):
        out(f"ERROR 4: {path}: No such file or directory")
        return 1
    fmt = "json" if "json" in args or "--json" in args else "text"
    recursive = "-R" in args or "--recursive" in args
    absolute = "--abs" in args or "--absolute-path" in args
    long = "-l" in args or "--long" in args or "--long-listing" in args
    entries = []
    if os.path.isdir(path):
        if recursive:
            for root, dirs, files in os.walk(path):
                for name in sorted(dirs + files):
                    p = os.path.join(root, name)
                    entries.append(os.path.abspath(p) if absolute else os.path.relpath(p, path))
        else:
            entries = sorted(os.listdir(path))
            if absolute:
                entries = [os.path.abspath(os.path.join(path, e)) for e in entries]
    else:
        entries = [os.path.abspath(path) if absolute or path.startswith("/") else path]
    if fmt == "json":
        out(json.dumps([{"name": e} for e in entries], indent=2))
    else:
        for e in entries:
            if long:
                p = e if os.path.isabs(e) else os.path.join(path, e)
                try:
                    s = os.stat(p)
                    mode = stat.filemode(s.st_mode)
                    out(f"{mode} {s.st_size:>10} {e}")
                except OSError:
                    out(e)
            else:
                out(e)
    return 0


def raster_create(args):
    vals = positional(args)
    if not vals:
        err("ERROR 1: create: Positional arguments starting at 'OUTPUT' have not been specified.", "Usage: gdal raster create [OPTIONS] <OUTPUT>")
        return 1
    outp = vals[-1]
    if os.path.exists(outp) and "--overwrite" not in args:
        out(f"ERROR 1: {outp} already exists.")
        return 1
    Path(outp).write_text("GDAL placeholder raster dataset\n", encoding="utf-8")
    return 0


def main(argv):
    args = list(argv)
    if not args:
        out("ERROR 1: gdal: Missing command name.")
        print_top_help(True)
        return 1
    if args[0] in ("-h", "--help"):
        print_top_help(False)
        return 0
    if args[0] == "--version":
        out(VERSION)
        return 0
    if args[0] == "--drivers":
        driver_json()
        return 0
    if args[0] == "--json-usage":
        json_usage(())
        return 0
    if args[0].startswith("-"):
        out(f"ERROR 5: gdal: Option '{args[0]}' is unknown.")
        print_top_help(True)
        return 1

    cmd = args[0]
    rest = args[1:]
    if "--json-usage" in rest:
        if cmd in GROUPS and rest.index("--json-usage") == 0:
            json_usage((cmd,))
        else:
            json_usage(tuple([cmd] + [x for x in rest if not x.startswith("-")][:1]))
        return 0
    if cmd in GROUPS and "--drivers" in rest:
        driver_json("mdim" if cmd == "mdim" else cmd)
        return 0
    if cmd in GROUPS and (not rest or rest[0] in ("-h", "--help")):
        print_group_help(cmd)
        return 0
    if cmd in ("info", "convert") and (not rest or rest[0] in ("-h", "--help")):
        print_help_for((cmd,))
        return 0
    if cmd == "info":
        vals = positional(rest)
        if not vals:
            err("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.", "Usage: gdal info [OPTIONS] <INPUT>")
            return 1
        fmt = "json" if "json" in rest or "--json" in rest else "text"
        return info(vals[-1], fmt)
    if cmd == "convert":
        vals = positional(rest)
        if len(vals) < 2:
            err("ERROR 1: convert: Positional arguments starting at 'INPUT' have not been specified.", "Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>")
            return 1
        return do_copy(vals[-2], vals[-1], "--overwrite" in rest, True)

    if cmd not in GROUPS:
        out(f"ERROR 1: gdal: Unknown command: '{cmd}'")
        print_top_help(True)
        return 1

    sub = rest[0] if rest else ""
    ncmd = normalize((cmd, sub))
    tail = rest[1:]
    if sub in ("-h", "--help"):
        print_group_help(cmd)
        return 0
    if len(ncmd) == 2 and (not tail or tail[0] in ("-h", "--help")):
        print_help_for(ncmd)
        return 0
    if len(ncmd) != 2 or ncmd[1] not in dict(GROUPS.get(cmd, [])):
        out(f"ERROR 1: {cmd}: Unknown command: '{sub}'")
        print_group_help(cmd)
        return 1

    group, sub = ncmd
    vals = positional(tail)
    if group == "vsi":
        if sub == "list":
            if not vals:
                err("ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified.", "Usage: gdal vsi list [OPTIONS] <FILENAME>")
                return 1
            return do_list(vals[-1], tail)
        if sub == "copy":
            if len(vals) < 2:
                err("ERROR 1: copy: Positional arguments starting at 'SOURCE' have not been specified.", "Usage: gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>")
                return 1
            return do_copy(vals[-2], vals[-1], True, "-r" in tail or "--recursive" in tail)
        if sub == "delete":
            if not vals:
                err("ERROR 1: delete: Positional arguments starting at 'FILENAME' have not been specified.", "Usage: gdal vsi delete [OPTIONS] <FILENAME>")
                return 1
            return do_delete(vals[-1], "-r" in tail or "-R" in tail or "--recursive" in tail)
        if sub == "move":
            if len(vals) < 2:
                err("ERROR 1: move: Positional arguments starting at 'SOURCE' have not been specified.", "Usage: gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>")
                return 1
            shutil.move(vals[-2], vals[-1])
            return 0
    if group == "dataset":
        if sub == "identify":
            rc = 0
            for p in vals:
                drv, _ = infer_driver(p)
                if drv and os.path.exists(p):
                    out(f"{p}: {drv}")
                elif "--report-failures" in tail:
                    out(f"{p}: unrecognized")
                    rc = 1
            return rc
        if sub == "copy":
            if len(vals) < 2:
                err("ERROR 1: copy: Positional arguments starting at 'SOURCE' have not been specified.", "Usage: gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>")
                return 1
            return do_copy(vals[-2], vals[-1], "--overwrite" in tail, True)
        if sub == "delete":
            if not vals:
                err("ERROR 1: delete: Positional arguments starting at 'FILENAME' have not been specified.", "Usage: gdal dataset delete [OPTIONS] <FILENAME>")
                return 1
            rc = 0
            for p in vals:
                rc = do_delete(p, True) or rc
            return rc
        if sub == "rename":
            if len(vals) < 2:
                err("ERROR 1: rename: Positional arguments starting at 'SOURCE' have not been specified.", "Usage: gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>")
                return 1
            if os.path.exists(vals[-1]) and "--overwrite" not in tail:
                out(f"ERROR 1: {vals[-1]} already exists.")
                return 1
            shutil.move(vals[-2], vals[-1])
            return 0
    if group == "raster" and sub == "create":
        return raster_create(tail)
    if group in ("raster", "vector", "mdim") and sub == "info":
        if not vals:
            err(f"ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.", f"Usage: gdal {group} info [OPTIONS] <INPUT>{'...' if group == 'vector' else ''}")
            return 1
        fmt = "json" if "json" in tail or "--json" in tail else "text"
        return info(vals[-1], fmt, vector=(group == "vector"))

    out(f"ERROR 6: gdal {group} {sub}: command is not implemented in this clean-room reimplementation.")
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
