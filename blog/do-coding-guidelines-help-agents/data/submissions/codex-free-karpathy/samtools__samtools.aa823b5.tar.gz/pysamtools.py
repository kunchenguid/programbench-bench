#!/usr/bin/env python3
import gzip
import hashlib
import os
import re
import sys

VERSION = "be7a51c"

FLAGS = [
    (0x1, "PAIRED", "paired-end / multiple-segment sequencing technology"),
    (0x2, "PROPER_PAIR", "each segment properly aligned according to aligner"),
    (0x4, "UNMAP", "segment unmapped"),
    (0x8, "MUNMAP", "next segment in the template unmapped"),
    (0x10, "REVERSE", "SEQ is reverse complemented"),
    (0x20, "MREVERSE", "SEQ of next segment in template is rev.complemented"),
    (0x40, "READ1", "the first segment in the template"),
    (0x80, "READ2", "the last segment in the template"),
    (0x100, "SECONDARY", "secondary alignment"),
    (0x200, "QCFAIL", "not passing quality controls or other filters"),
    (0x400, "DUP", "PCR or optical duplicate"),
    (0x800, "SUPPLEMENTARY", "supplementary alignment"),
]
FLAG_BY_NAME = {n: v for v, n, _ in FLAGS}


def eprint(*args):
    print(*args, file=sys.stderr)


def open_text(path):
    if path == "-":
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "r", newline="")


def parse_flag(s):
    s = str(s)
    if "," in s or s.upper() in FLAG_BY_NAME:
        val = 0
        for part in [p for p in s.upper().split(",") if p]:
            if part not in FLAG_BY_NAME:
                raise ValueError(part)
            val |= FLAG_BY_NAME[part]
        return val
    return int(s, 0)


def flag_names(v):
    return ",".join(n for bit, n, _ in FLAGS if v & bit)


def cigar_ref_len(cigar):
    if cigar == "*":
        return 0
    total = 0
    for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
        if op in "MDN=X":
            total += int(n)
    return total


def cigar_query_aligned_positions(pos, cigar, include_del=False):
    ref = pos
    out = []
    if cigar == "*":
        return out
    for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
        n = int(n)
        if op in "M=X":
            out.extend(range(ref, ref + n))
            ref += n
        elif op in "DN":
            if include_del and op == "D":
                out.extend(range(ref, ref + n))
            ref += n
        elif op in "ISH":
            pass
    return out


def revcomp(seq):
    table = str.maketrans("ACGTNacgtn", "TGCANtgcan")
    return seq.translate(table)[::-1]


def read_fasta(path):
    seqs = []
    name = None
    parts = []
    with open_text(path) as f:
        for line in f:
            line = line.rstrip("\n\r")
            if line.startswith(">"):
                if name is not None:
                    seqs.append((name, "".join(parts)))
                name = line[1:].split()[0]
                parts = []
            elif name is not None:
                parts.append(line.strip())
    if name is not None:
        seqs.append((name, "".join(parts)))
    return seqs


def read_fastq(path):
    seqs = []
    with open_text(path) as f:
        while True:
            h = f.readline()
            if not h:
                break
            seq = f.readline()
            plus = f.readline()
            qual = f.readline()
            if not qual:
                break
            seqs.append((h[1:].strip().split()[0], seq.strip(), qual.strip()))
    return seqs


def write_wrapped(seq, width, out):
    if width <= 0:
        out.write(seq + "\n")
        return
    for i in range(0, len(seq), width):
        out.write(seq[i:i + width] + "\n")


def make_fai(path, fastq=False):
    entries = []
    with open(path, "rb") as f:
        name = None
        length = 0
        offset = 0
        line_bases = 0
        line_width = 0
        while True:
            start = f.tell()
            line = f.readline()
            if not line:
                break
            if line.startswith(b">") or line.startswith(b"@") and fastq and name is None:
                if name is not None:
                    entries.append((name, length, offset, line_bases, line_width))
                name = line[1:].strip().split()[0].decode()
                length = 0
                offset = f.tell()
                line_bases = 0
                line_width = 0
                if fastq:
                    seq_start = f.tell()
                    seq = f.readline()
                    plus = f.readline()
                    qual_start = f.tell()
                    qual = f.readline()
                    b = len(seq.rstrip(b"\r\n"))
                    w = len(seq)
                    entries.append((name, b, seq_start, b, w, qual_start, b, len(qual)))
                    name = None
            elif name is not None:
                b = len(line.rstrip(b"\r\n"))
                if b:
                    if line_bases == 0:
                        line_bases = b
                        line_width = len(line)
                    length += b
        if name is not None:
            entries.append((name, length, offset, line_bases, line_width))
    return entries


def parse_region(reg):
    if ":" not in reg:
        return reg, None, None
    name, rest = reg.rsplit(":", 1)
    rest = rest.replace(",", "")
    if "-" in rest:
        a, b = rest.split("-", 1)
        return name, int(a), int(b)
    p = int(rest)
    return name, p, p


def cmd_faidx(args, fastq=False):
    if not args or "-h" in args or "--help" in args:
        print(f"Usage: samtools {'fqidx' if fastq else 'faidx'} <file.{ 'fq' if fastq else 'fa'}|file.{ 'fq' if fastq else 'fa'}.gz> [<reg> [...]]")
        return 0
    out_path = None
    width = 60
    reverse = False
    cont = False
    mark = "rc"
    regs = []
    file = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-o", "--output"):
            i += 1; out_path = args[i]
        elif a in ("-n", "--length"):
            i += 1; width = int(args[i])
        elif a in ("-i", "--reverse-complement"):
            reverse = True
        elif a in ("-c", "--continue"):
            cont = True
        elif a == "--mark-strand":
            i += 1; mark = args[i]
        elif a in ("-r", "--region-file"):
            i += 1
            with open(args[i]) as rf:
                regs += [x.strip() for x in rf if x.strip()]
        elif a.startswith("-"):
            if a in ("--fai-idx", "--gzi-idx", "-@", "--output-fmt-option"):
                i += 1
        elif file is None:
            file = a
        else:
            regs.append(a)
        i += 1
    if file is None:
        return 1
    if not regs:
        idx = make_fai(file, fastq)
        with open(file + ".fai", "w") as out:
            for ent in idx:
                out.write("\t".join(map(str, ent)) + "\n")
        return 0
    records = read_fastq(file) if fastq else [(n, s, None) for n, s in read_fasta(file)]
    data = {n: (s, q) for n, s, q in records}
    out = open(out_path, "w") if out_path else sys.stdout
    ok = True
    for reg in regs:
        name, start, end = parse_region(reg)
        if name not in data:
            eprint(f"[W::fai_get_val] Reference {name} not found in FASTA file, returning empty sequence")
            ok = False
            if not cont:
                break
            continue
        seq, qual = data[name]
        if start is None:
            start, end = 1, len(seq)
            label = name
        else:
            label = f"{name}:{start}-{end}"
        frag = seq[max(0, start - 1):min(len(seq), end)]
        qfrag = qual[max(0, start - 1):min(len(seq), end)] if qual is not None else None
        if reverse:
            frag = revcomp(frag)
            qfrag = qfrag[::-1] if qfrag is not None else None
            if mark == "rc":
                label += "/rc"
            elif mark == "sign":
                label += "(-)"
            elif mark.startswith("custom,"):
                parts = mark.split(",", 2)
                if len(parts) == 3:
                    label += parts[2]
        if fastq:
            out.write(f"@{label}\n{frag}\n+\n{qfrag or 'B' * len(frag)}\n")
        else:
            out.write(f">{label}\n")
            write_wrapped(frag, width, out)
    if out is not sys.stdout:
        out.close()
    return 0 if ok else 1


def read_sam(path):
    headers, records = [], []
    with open_text(path) as f:
        for line in f:
            line = line.rstrip("\n\r")
            if not line:
                continue
            if line.startswith("@"):
                headers.append(line)
            else:
                fields = line.split("\t")
                if len(fields) >= 11:
                    fields[9] = fields[9].upper()
                records.append(fields)
    return headers, records


def header_refs(headers):
    refs = []
    for h in headers:
        if h.startswith("@SQ\t"):
            vals = {}
            for x in h.split("\t")[1:]:
                if ":" in x:
                    k, v = x.split(":", 1)
                    vals[k] = v
            if "SN" in vals:
                refs.append((vals["SN"], int(vals.get("LN", "0"))))
    return refs


def pg_line(argv):
    return "@PG\tID:samtools\tPN:samtools\tVN:%s\tCL:%s" % (VERSION, " ".join(argv))


def record_passes(r, req=0, excl=0, incl=0, min_mq=None):
    fl = int(r[1])
    if req and (fl & req) != req:
        return False
    if excl and (fl & excl):
        return False
    if incl and not (fl & incl):
        return False
    if min_mq is not None and int(r[4]) < min_mq:
        return False
    return True


def cmd_view(args, argv):
    if not args or "--help" in args or "-?" in args:
        print("Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]")
        return 0
    include_header = False
    header_only = False
    count = False
    out_path = None
    req = excl = incl = 0
    min_mq = None
    no_pg = False
    infile = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--with-header"):
            include_header = True
        elif a in ("-H", "--header-only"):
            header_only = True
        elif a in ("-c", "--count"):
            count = True
        elif a in ("--no-PG",):
            no_pg = True
        elif a in ("-o", "--output"):
            i += 1; out_path = args[i]
        elif a in ("-f", "--require-flags"):
            i += 1; req = parse_flag(args[i])
        elif a in ("-F", "--exclude-flags", "--excl-flags"):
            i += 1; excl = parse_flag(args[i])
        elif a in ("--rf", "--incl-flags", "--include-flags"):
            i += 1; incl = parse_flag(args[i])
        elif a in ("-q", "--min-MQ"):
            i += 1; min_mq = int(args[i])
        elif a in ("-S", "-b", "-u", "-1"):
            pass
        elif a.startswith("-"):
            if a in ("-t", "-T", "-O", "--output-fmt", "-@", "--input-fmt-option", "--output-fmt-option"):
                i += 1
        elif infile is None:
            infile = a
        else:
            eprint(f"[E::idx_find_and_load] Could not retrieve index file for '{infile}'")
            eprint("samtools view: Random alignment retrieval only works for indexed SAM.gz, BAM or CRAM files.")
            return 1
        i += 1
    headers, records = read_sam(infile or "-")
    selected = [r for r in records if record_passes(r, req, excl, incl, min_mq)]
    out = open(out_path, "w") if out_path else sys.stdout
    if count:
        out.write(str(len(selected)) + "\n")
    else:
        if include_header or header_only:
            for h in headers:
                out.write(h + "\n")
            if not no_pg:
                out.write(pg_line(argv) + "\n")
        if not header_only:
            for r in selected:
                out.write("\t".join(r) + "\n")
    if out is not sys.stdout:
        out.close()
    return 0


def cmd_head(args):
    hnum = None
    rnum = 0
    infile = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--headers"):
            i += 1; hnum = int(args[i])
        elif a in ("-n", "--records"):
            i += 1; rnum = int(args[i])
        elif a.startswith("-"):
            if a in ("-T", "-@", "--input-fmt-option"):
                i += 1
        else:
            infile = a
        i += 1
    headers, records = read_sam(infile or "-")
    for h in headers[:hnum]:
        print(h)
    for r in records[:rnum]:
        print("\t".join(r))
    return 0


def cmd_idxstats(args):
    infile = next((a for a in args if not a.startswith("-")), None)
    headers, records = read_sam(infile or "-")
    refs = header_refs(headers)
    counts = {n: [0, 0] for n, _ in refs}
    unmapped_star = 0
    for r in records:
        fl = int(r[1])
        if r[2] == "*":
            unmapped_star += 1
        elif r[2] in counts:
            counts[r[2]][1 if fl & 4 else 0] += 1
    for n, ln in refs:
        print(f"{n}\t{ln}\t{counts[n][0]}\t{counts[n][1]}")
    print(f"*\t0\t0\t{unmapped_star}")
    return 0


def flagstat_counts(records):
    keys = ["total","primary","secondary","supplementary","duplicates","primary duplicates","mapped","primary mapped","paired in sequencing","read1","read2","properly paired","with itself and mate mapped","singletons","diff chr","diff chr mapQ>=5"]
    qc = {k: [0, 0] for k in keys}
    for r in records:
        fl = int(r[1]); fail = 1 if fl & 0x200 else 0
        primary = not (fl & 0x100 or fl & 0x800)
        qc["total"][fail] += 1
        if primary: qc["primary"][fail] += 1
        if fl & 0x100: qc["secondary"][fail] += 1
        if fl & 0x800: qc["supplementary"][fail] += 1
        if fl & 0x400:
            qc["duplicates"][fail] += 1
            if primary: qc["primary duplicates"][fail] += 1
        if not fl & 0x4:
            qc["mapped"][fail] += 1
            if primary: qc["primary mapped"][fail] += 1
        if fl & 0x1:
            qc["paired in sequencing"][fail] += 1
            if fl & 0x40: qc["read1"][fail] += 1
            if fl & 0x80: qc["read2"][fail] += 1
            if fl & 0x2: qc["properly paired"][fail] += 1
            if not (fl & 0x4) and not (fl & 0x8):
                qc["with itself and mate mapped"][fail] += 1
                mate_ref = r[6]
                if mate_ref not in ("=", "*") and mate_ref != r[2]:
                    qc["diff chr"][fail] += 1
                    if int(r[4]) >= 5:
                        qc["diff chr mapQ>=5"][fail] += 1
            elif not (fl & 0x4) and (fl & 0x8):
                qc["singletons"][fail] += 1
    return qc


def pct(n, d):
    return "N/A" if d == 0 else f"{100.0*n/d:.2f}%"


def cmd_flagstat(args):
    fmt = "text"
    infile = None
    i = 0
    while i < len(args):
        if args[i] in ("-O", "--output-fmt"):
            i += 1; fmt = args[i].split(",", 1)[0]
        elif not args[i].startswith("-"):
            infile = args[i]
        elif args[i] in ("-@", "--input-fmt-option", "--verbosity"):
            i += 1
        i += 1
    _, records = read_sam(infile or "-")
    c = flagstat_counts(records)
    if fmt == "tsv":
        rows = [
            ("total (QC-passed reads + QC-failed reads)", c["total"]),
            ("primary", c["primary"]), ("secondary", c["secondary"]), ("supplementary", c["supplementary"]),
            ("duplicates", c["duplicates"]), ("primary duplicates", c["primary duplicates"]),
            ("mapped", c["mapped"]), ("mapped %", [pct(c["mapped"][0], c["total"][0]), pct(c["mapped"][1], c["total"][1])]),
            ("primary mapped", c["primary mapped"]), ("primary mapped %", [pct(c["primary mapped"][0], c["primary"][0]), pct(c["primary mapped"][1], c["primary"][1])]),
            ("paired in sequencing", c["paired in sequencing"]), ("read1", c["read1"]), ("read2", c["read2"]),
            ("properly paired", c["properly paired"]), ("properly paired %", [pct(c["properly paired"][0], c["paired in sequencing"][0]), pct(c["properly paired"][1], c["paired in sequencing"][1])]),
            ("with itself and mate mapped", c["with itself and mate mapped"]), ("singletons", c["singletons"]),
            ("singletons %", [pct(c["singletons"][0], c["paired in sequencing"][0]), pct(c["singletons"][1], c["paired in sequencing"][1])]),
            ("with mate mapped to a different chr", c["diff chr"]), ("with mate mapped to a different chr (mapQ>=5)", c["diff chr mapQ>=5"]),
        ]
        for label, vals in rows:
            print(f"{vals[0]}\t{vals[1]}\t{label}")
    else:
        def line(k, label, extra=""):
            print(f"{c[k][0]} + {c[k][1]} {label}{extra}")
        line("total", "in total (QC-passed reads + QC-failed reads)")
        for k in ["primary","secondary","supplementary","duplicates","primary duplicates"]:
            line(k, k)
        line("mapped", f"mapped ({pct(c['mapped'][0], c['total'][0])} : {pct(c['mapped'][1], c['total'][1])})")
        line("primary mapped", f"primary mapped ({pct(c['primary mapped'][0], c['primary'][0])} : {pct(c['primary mapped'][1], c['primary'][1])})")
        for k in ["paired in sequencing","read1","read2"]:
            line(k, k)
        line("properly paired", f"properly paired ({pct(c['properly paired'][0], c['paired in sequencing'][0])} : {pct(c['properly paired'][1], c['paired in sequencing'][1])})")
        line("with itself and mate mapped", "with itself and mate mapped")
        line("singletons", f"singletons ({pct(c['singletons'][0], c['paired in sequencing'][0])} : {pct(c['singletons'][1], c['paired in sequencing'][1])})")
        line("diff chr", "with mate mapped to a different chr")
        line("diff chr mapQ>=5", "with mate mapped to a different chr (mapQ>=5)")
    return 0


def cmd_depth(args):
    allpos = False
    header = False
    include_del = False
    min_mq = 0
    out_path = None
    infile = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-a":
            allpos = True
        elif a == "-aa":
            allpos = True
        elif a == "-H":
            header = True
        elif a == "-J":
            include_del = True
        elif a in ("-Q", "--min-MQ"):
            i += 1; min_mq = int(args[i])
        elif a == "-o":
            i += 1; out_path = args[i]
        elif a.startswith("-"):
            if a in ("-r", "-b", "-f", "-g", "-G", "--excl-flags", "--incl-flags", "--require-flags", "-l", "-q", "--min-BQ", "--reference", "-@", "--verbosity"):
                i += 1
        else:
            infile = a
        i += 1
    headers, records = read_sam(infile or "-")
    refs = header_refs(headers)
    depths = {n: [0] * (ln + 1) for n, ln in refs}
    touched = {n: [False] * (ln + 1) for n, ln in refs}
    for r in records:
        fl = int(r[1])
        if fl & (0x4 | 0x100 | 0x200 | 0x400) or int(r[4]) < min_mq or r[2] not in depths:
            continue
        start = int(r[3])
        end = start + cigar_ref_len(r[5])
        for p in range(start, min(end, len(touched[r[2]]))):
            if p > 0:
                touched[r[2]][p] = True
        for p in cigar_query_aligned_positions(int(r[3]), r[5], include_del):
            if 0 < p < len(depths[r[2]]):
                depths[r[2]][p] += 1
    out = open(out_path, "w") if out_path else sys.stdout
    if header:
        out.write(f"#CHROM\tPOS\t{infile or '-'}\n")
    for n, ln in refs:
        for p in range(1, ln + 1):
            d = depths[n][p]
            if allpos or d or touched[n][p]:
                out.write(f"{n}\t{p}\t{d}\n")
    if out is not sys.stdout:
        out.close()
    return 0


def cmd_dict(args):
    no_header = False
    out_path = None
    assembly = species = uri = None
    fasta = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-H", "--no-header"):
            no_header = True
        elif a in ("-o", "--output"):
            i += 1; out_path = args[i]
        elif a in ("-a", "--assembly"):
            i += 1; assembly = args[i]
        elif a in ("-s", "--species"):
            i += 1; species = args[i]
        elif a in ("-u", "--uri"):
            i += 1; uri = args[i]
        elif not a.startswith("-"):
            fasta = a
        i += 1
    out = open(out_path, "w") if out_path else sys.stdout
    if not no_header:
        out.write("@HD\tVN:1.0\tSO:unsorted\n")
    abspath = os.path.abspath(fasta)
    for name, seq in read_fasta(fasta):
        fields = ["@SQ", f"SN:{name}", f"LN:{len(seq)}", f"M5:{hashlib.md5(seq.upper().encode()).hexdigest()}", f"UR:{uri or 'file://' + abspath}"]
        if assembly: fields.append(f"AS:{assembly}")
        if species: fields.append(f"SP:{species}")
        out.write("\t".join(fields) + "\n")
    if out is not sys.stdout:
        out.close()
    return 0


def oriented_seq_qual(r):
    seq = r[9].upper()
    qual = r[10] if len(r) > 10 and r[10] != "*" else "B" * len(seq)
    if int(r[1]) & 0x10:
        seq = revcomp(seq).upper()
        qual = qual[::-1]
    return seq, qual


def read_name_for_fastx(r, mode_n=False, mode_N=False):
    name = r[0]
    fl = int(r[1])
    suffix = ""
    if mode_N or (not mode_n and (fl & 0x1)):
        if fl & 0x40 and not fl & 0x80:
            suffix = "/1"
        elif fl & 0x80 and not fl & 0x40:
            suffix = "/2"
    return name + suffix


def cmd_fastx(args, fastq=False):
    mode_n = False
    mode_N = False
    out_path = None
    infile = None
    i = 0
    while i < len(args):
        a = args[i]
        if a == "-n": mode_n = True
        elif a == "-N": mode_N = True
        elif a in ("-o", "-0", "-1", "-2", "-s"):
            i += 1
            if a == "-o": out_path = args[i]
        elif a.startswith("-"):
            if a in ("-f", "-F", "--rf", "-G", "-d", "-D", "-T", "-v", "-c", "--barcode-tag", "--quality-tag", "--index-format", "--UMI-tag", "--reference", "-@"):
                i += 1
        else:
            infile = a
        i += 1
    _, records = read_sam(infile or "-")
    out = open(out_path, "w") if out_path else sys.stdout
    processed = 0
    for r in records:
        fl = int(r[1])
        if fl & 0x900:
            continue
        seq, qual = oriented_seq_qual(r)
        name = read_name_for_fastx(r, mode_n, mode_N)
        if fastq:
            out.write(f"@{name}\n{seq}\n+\n{qual}\n")
        else:
            out.write(f">{name}\n{seq}\n")
        processed += 1
    if out is not sys.stdout:
        out.close()
    eprint("[M::bam2fq_mainloop] discarded 0 singletons")
    eprint(f"[M::bam2fq_mainloop] processed {processed} reads")
    return 0


def cmd_sort(args, argv):
    by_name = False
    out_path = None
    infile = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-n", "-N"):
            by_name = True
        elif a == "-o":
            i += 1; out_path = args[i]
        elif a.startswith("-"):
            if a in ("-O", "-T", "-m", "-l", "-@", "-t", "-I", "-K", "-w", "--reference", "--input-fmt-option", "--output-fmt-option"):
                i += 1
        else:
            infile = a
        i += 1
    headers, records = read_sam(infile or "-")
    refs = {n: i for i, (n, _) in enumerate(header_refs(headers))}
    if by_name:
        records.sort(key=lambda r: (r[0], int(r[1]) & 0xc0, r[2], int(r[3])))
        hd = "@HD\tVN:1.6\tSO:queryname\tSS:queryname:natural"
    else:
        records.sort(key=lambda r: (refs.get(r[2], 10**9), int(r[3]), r[0], int(r[1])))
        hd = "@HD\tVN:1.6\tSO:coordinate"
    out = open(out_path, "w") if out_path else sys.stdout
    had_hd = False
    out.write(hd + "\n")
    for h in headers:
        if h.startswith("@HD"):
            had_hd = True
            continue
        out.write(h + "\n")
    if not had_hd:
        pass
    out.write(pg_line(argv) + "\n")
    for r in records:
        out.write("\t".join(r) + "\n")
    if out is not sys.stdout:
        out.close()
    return 0


def cmd_coverage(args):
    infile = next((a for a in args if not a.startswith("-")), None)
    headers, records = read_sam(infile or "-")
    refs = header_refs(headers)
    depths = {n: [0] * (ln + 1) for n, ln in refs}
    reads = {n: 0 for n, _ in refs}
    bqsum = {n: 0 for n, _ in refs}
    bqcount = {n: 0 for n, _ in refs}
    mqsum = {n: 0 for n, _ in refs}
    for r in records:
        fl = int(r[1])
        if fl & (0x4 | 0x100 | 0x800) or r[2] not in depths:
            continue
        reads[r[2]] += 1
        mqsum[r[2]] += int(r[4])
        if r[10] == "*":
            bqsum[r[2]] += 255 * len(r[9])
        else:
            bqsum[r[2]] += sum(max(0, ord(c) - 33) for c in r[10])
        bqcount[r[2]] += len(r[9])
        for p in cigar_query_aligned_positions(int(r[3]), r[5], False):
            if 0 < p < len(depths[r[2]]):
                depths[r[2]][p] += 1
    print("#rname\tstartpos\tendpos\tnumreads\tcovbases\tcoverage\tmeandepth\tmeanbaseq\tmeanmapq")
    for n, ln in refs:
        covbases = sum(1 for d in depths[n][1:] if d)
        total_depth = sum(depths[n])
        coverage = (100.0 * covbases / ln) if ln else 0.0
        meandepth = (total_depth / ln) if ln else 0.0
        meanbq = (bqsum[n] / bqcount[n]) if bqcount[n] else 0.0
        meanmq = (mqsum[n] / reads[n]) if reads[n] else 0.0
        print(f"{n}\t1\t{ln}\t{reads[n]}\t{covbases}\t{coverage:.6g}\t{meandepth:.6g}\t{meanbq:.6g}\t{meanmq:.6g}")
    return 0


def cmd_stats(args, argv):
    infile = next((a for a in args if not a.startswith("-")), None)
    _, records = read_sam(infile or "-")
    primary = [r for r in records if not (int(r[1]) & (0x100 | 0x800))]
    mapped = [r for r in primary if not (int(r[1]) & 0x4)]
    paired = [r for r in primary if int(r[1]) & 0x1]
    proper = [r for r in paired if int(r[1]) & 0x2]
    lengths = [len(r[9]) for r in primary]
    cigar_bases = sum(sum(int(n) for n, op in re.findall(r"(\d+)([MIDNSHP=X])", r[5]) if op in "MI=X") for r in mapped)
    mismatches = 0
    for r in mapped:
        for tag in r[11:]:
            if tag.startswith("NM:i:"):
                try:
                    mismatches += int(tag.rsplit(":", 1)[1])
                except ValueError:
                    pass
    print(f"# This file was produced by samtools stats ({VERSION}+htslib-1.23.1) and can be plotted using plot-bamstats")
    print("# This file contains statistics for all reads.")
    print("# The command line was:  " + " ".join(argv[1:]))
    print("# Summary Numbers. Use `grep ^SN | cut -f 2-` to extract this part.")
    print(f"SN\traw total sequences:\t{len(primary)}\t# excluding supplementary and secondary reads")
    print("SN\tfiltered sequences:\t0")
    print(f"SN\tsequences:\t{len(primary)}")
    print("SN\tis sorted:\t1\t# sorted by coordinate")
    print(f"SN\t1st fragments:\t{sum(1 for r in primary if not (int(r[1]) & 0x80))}")
    print(f"SN\tlast fragments:\t{sum(1 for r in primary if int(r[1]) & 0x80)}")
    print(f"SN\treads mapped:\t{len(mapped)}")
    print(f"SN\treads mapped and paired:\t{sum(1 for r in paired if not (int(r[1]) & 0x4) and not (int(r[1]) & 0x8))}\t# paired-end technology bit set + both mates mapped")
    print(f"SN\treads unmapped:\t{len(primary) - len(mapped)}")
    print(f"SN\treads properly paired:\t{len(proper)}\t# proper-pair bit set")
    print(f"SN\treads paired:\t{len(paired)}\t# paired-end technology bit set")
    print(f"SN\treads duplicated:\t{sum(1 for r in primary if int(r[1]) & 0x400)}\t# PCR or optical duplicate bit set")
    print(f"SN\treads MQ0:\t{sum(1 for r in mapped if int(r[4]) == 0)}\t# mapped and MQ=0")
    print(f"SN\treads QC failed:\t{sum(1 for r in records if int(r[1]) & 0x200)}")
    print(f"SN\tnon-primary alignments:\t{sum(1 for r in records if int(r[1]) & 0x100)}")
    print(f"SN\tsupplementary alignments:\t{sum(1 for r in records if int(r[1]) & 0x800)}")
    print(f"SN\ttotal length:\t{sum(lengths)}\t# ignores clipping")
    print(f"SN\tbases mapped:\t{sum(len(r[9]) for r in mapped)}\t# ignores clipping")
    print(f"SN\tbases mapped (cigar):\t{cigar_bases}\t# more accurate")
    print(f"SN\tmismatches:\t{mismatches}\t# from NM fields")
    rate = (mismatches / cigar_bases) if cigar_bases else 0.0
    print(f"SN\terror rate:\t{rate:.6e}\t# mismatches / bases mapped (cigar)")
    print(f"SN\taverage length:\t{(sum(lengths)//len(lengths)) if lengths else 0}")
    print(f"SN\tmaximum length:\t{max(lengths) if lengths else 0}")
    pct_proper = 100.0 * len(proper) / len(primary) if primary else 0.0
    print(f"SN\tpercentage of properly paired reads (%):\t{pct_proper:.1f}")
    return 0


def cmd_flags(args):
    if not args:
        print_flags_help()
        return 0
    rc = 0
    for a in args:
        try:
            v = parse_flag(a)
            print(f"0x{v:x}\t{v}\t{flag_names(v)}")
        except Exception:
            eprint(f'samtools flags: Could not parse "{a}"')
            print_flags_help()
            rc = 1
    return rc


def print_flags_help():
    print("About: Convert between textual and numeric flag representation")
    print("Usage: samtools flags FLAGS...\n")
    print("Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing")
    print("a combination of the following numeric flag values, or a comma-separated string")
    print("NAME,...,NAME representing a combination of the following flag names:\n")
    for bit, name, desc in FLAGS:
        print(f"{'0x%x'%bit:>6} {bit:5d}  {name:<13} {desc}")


def cmd_quickcheck(args):
    verbose = args.count("-v") + args.count("-vv")
    files = [a for a in args if not a.startswith("-")]
    ok = True
    for f in files:
        try:
            with open_text(f) as fh:
                fh.readline()
        except Exception:
            ok = False
            if verbose:
                print(f)
            else:
                eprint(f"{f} could not be opened for reading.")
    return 0 if ok else 1


def print_main_help():
    print(f"""Program: samtools (Tools for alignments in the SAM format)
Version: {VERSION} (using htslib 1.23.1)

Usage:   samtools <command> [options]

Commands:
  -- Indexing
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment

  -- File operations
     sort           sort alignment file
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fastq          converts a BAM to a FASTQ
     fasta          converts a BAM to a FASTA

  -- Statistics
     depth          compute the depth
     flagstat       simple stats
     idxstats       BAM index stats

  -- Viewing
     flags          explain BAM flags
     head           header viewer
     view           SAM<->BAM<->CRAM conversion

  -- Misc
     help [cmd]     display this help message or help for [cmd]
     version        detailed version information""")


def cmd_version():
    print(f"""samtools {VERSION}
Using htslib 1.23.1
Copyright (C) 2025 Genome Research Ltd.""")
    return 0


def unsupported(cmd):
    eprint(f"samtools: command '{cmd}' is not implemented in this clean-room reimplementation")
    return 1


def main(argv):
    if len(argv) < 2 or argv[1] in ("--help", "-h"):
        print_main_help()
        return 0
    cmd = argv[1]
    args = argv[2:]
    if cmd == "help":
        if args:
            return main([argv[0], args[0], "--help"])
        print_main_help(); return 0
    if cmd == "version": return cmd_version()
    if cmd == "flags": return cmd_flags(args)
    if cmd == "faidx": return cmd_faidx(args, False)
    if cmd == "fqidx": return cmd_faidx(args, True)
    if cmd == "view": return cmd_view(args, argv)
    if cmd == "head": return cmd_head(args)
    if cmd == "idxstats": return cmd_idxstats(args)
    if cmd == "flagstat": return cmd_flagstat(args)
    if cmd == "depth": return cmd_depth(args)
    if cmd == "dict": return cmd_dict(args)
    if cmd == "fasta": return cmd_fastx(args, False)
    if cmd == "fastq": return cmd_fastx(args, True)
    if cmd == "quickcheck": return cmd_quickcheck(args)
    if cmd == "sort": return cmd_sort(args, argv)
    if cmd == "coverage": return cmd_coverage(args)
    if cmd == "stats": return cmd_stats(args, argv)
    return unsupported(cmd)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
