#!/usr/bin/env python3
import argparse
import json
import math
import os
import re
import sys
from urllib.parse import urlparse


VALID_TYPES = {"null", "boolean", "object", "array", "number", "integer", "string"}


class ValidationError:
    def __init__(self, message, path="", schema_path=""):
        self.message = message
        self.path = path
        self.schema_path = schema_path


def dump_value(value):
    return json.dumps(value, separators=(",", ":"), ensure_ascii=False)


def type_name(value):
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, dict):
        return "object"
    if isinstance(value, list):
        return "array"
    if isinstance(value, int) and not isinstance(value, bool):
        return "integer"
    if isinstance(value, float):
        return "number" if math.isfinite(value) else "number"
    if isinstance(value, str):
        return "string"
    return "unknown"


def is_type(value, want):
    if want == "number":
        return (isinstance(value, (int, float)) and not isinstance(value, bool))
    if want == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    return type_name(value) == want


def path_join(path, token):
    token = str(token).replace("~", "~0").replace("/", "~1")
    return path + "/" + token


def plural(n, word):
    return word if n == 1 else word + "s"


def human_list(values):
    vals = [dump_value(v) for v in values]
    if len(vals) == 1:
        return vals[0]
    if len(vals) == 2:
        return vals[0] + " or " + vals[1]
    return ", ".join(vals[:-1]) + ", or " + vals[-1]


def validate_schema(schema):
    if isinstance(schema, bool):
        return None
    if not isinstance(schema, dict):
        return "schema must be an object or boolean"
    t = schema.get("type")
    if isinstance(t, str) and t not in VALID_TYPES:
        return f'"{t}" is not valid under any of the schemas listed in the \'anyOf\' keyword'
    if isinstance(t, list):
        for item in t:
            if item not in VALID_TYPES:
                return f'"{item}" is not valid under any of the schemas listed in the \'anyOf\' keyword'
    for key in ("properties", "patternProperties", "$defs", "definitions", "dependentSchemas"):
        val = schema.get(key)
        if isinstance(val, dict):
            for sub in val.values():
                err = validate_schema(sub)
                if err:
                    return err
    for key in ("items", "additionalProperties", "contains", "propertyNames", "not", "if", "then", "else"):
        if key in schema:
            err = validate_schema(schema[key])
            if err:
                return err
    for key in ("allOf", "anyOf", "oneOf", "prefixItems"):
        val = schema.get(key)
        if isinstance(val, list):
            for sub in val:
                err = validate_schema(sub)
                if err:
                    return err
    return None


def check_format(fmt, value):
    if fmt == "email":
        return re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", value) is not None
    if fmt in ("uri", "iri"):
        p = urlparse(value)
        return bool(p.scheme)
    if fmt == "ipv4":
        parts = value.split(".")
        return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 and str(int(p)) == p for p in parts)
    if fmt == "hostname":
        return re.match(r"^[A-Za-z0-9.-]+$", value) is not None and ".." not in value
    if fmt == "date-time":
        return re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$", value) is not None
    if fmt == "date":
        return re.match(r"^\d{4}-\d{2}-\d{2}$", value) is not None
    if fmt == "time":
        return re.match(r"^\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?$", value) is not None
    return True


def resolve_pointer(root, pointer):
    if pointer in ("", "#"):
        return root
    if pointer.startswith("#"):
        pointer = pointer[1:]
    if not pointer.startswith("/"):
        return None
    cur = root
    for raw in pointer.split("/")[1:]:
        token = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, dict) and token in cur:
            cur = cur[token]
        elif isinstance(cur, list) and token.isdigit() and int(token) < len(cur):
            cur = cur[int(token)]
        else:
            return None
    return cur


def validate(schema, inst, path="", spath="", assert_format=False, root=None, seen_refs=None):
    if root is None:
        root = schema
    if seen_refs is None:
        seen_refs = set()
    errors = []
    if schema is True:
        return errors
    if schema is False:
        return [ValidationError(f"False schema does not allow {dump_value(inst)}", path, spath)]
    if not isinstance(schema, dict):
        return errors
    if "$ref" in schema and isinstance(schema["$ref"], str):
        ref = schema["$ref"]
        if ref.startswith("#") and ref not in seen_refs:
            target = resolve_pointer(root, ref)
            if target is not None:
                return validate(target, inst, path, ref[1:] or "", assert_format, root, seen_refs | {ref})

    if "const" in schema and inst != schema["const"]:
        errors.append(ValidationError(f"{dump_value(schema['const'])} was expected", path, path_join(spath, "const")))
    if "enum" in schema and inst not in schema["enum"]:
        errors.append(ValidationError(f"{dump_value(inst)} is not one of {human_list(schema['enum'])}", path, path_join(spath, "enum")))

    if "type" in schema:
        want = schema["type"]
        if isinstance(want, list):
            if not any(is_type(inst, t) for t in want):
                names = ", ".join(f'"{t}"' for t in sorted(want))
                errors.append(ValidationError(f"{dump_value(inst)} is not of types {names}", path, path_join(spath, "type")))
        elif isinstance(want, str) and not is_type(inst, want):
            errors.append(ValidationError(f"{dump_value(inst)} is not of type \"{want}\"", path, path_join(spath, "type")))

    numeric = isinstance(inst, (int, float)) and not isinstance(inst, bool)
    if numeric:
        if "multipleOf" in schema and schema["multipleOf"] != 0:
            q = inst / schema["multipleOf"]
            if abs(q - round(q)) > 1e-12:
                errors.append(ValidationError(f"{dump_value(inst)} is not a multiple of {dump_value(schema['multipleOf'])}", path, path_join(spath, "multipleOf")))
        if "minimum" in schema and inst < schema["minimum"]:
            errors.append(ValidationError(f"{dump_value(inst)} is less than the minimum of {dump_value(schema['minimum'])}", path, path_join(spath, "minimum")))
        if "maximum" in schema and inst > schema["maximum"]:
            errors.append(ValidationError(f"{dump_value(inst)} is greater than the maximum of {dump_value(schema['maximum'])}", path, path_join(spath, "maximum")))
        if "exclusiveMinimum" in schema:
            lim = schema["exclusiveMinimum"]
            bad = inst <= lim if isinstance(lim, (int, float)) else (inst <= schema.get("minimum", -math.inf) if lim else False)
            if bad:
                errors.append(ValidationError(f"{dump_value(inst)} is less than or equal to the minimum of {dump_value(lim if isinstance(lim, (int, float)) else schema.get('minimum'))}", path, path_join(spath, "exclusiveMinimum")))
        if "exclusiveMaximum" in schema:
            lim = schema["exclusiveMaximum"]
            bad = inst >= lim if isinstance(lim, (int, float)) else (inst >= schema.get("maximum", math.inf) if lim else False)
            if bad:
                errors.append(ValidationError(f"{dump_value(inst)} is greater than or equal to the maximum of {dump_value(lim if isinstance(lim, (int, float)) else schema.get('maximum'))}", path, path_join(spath, "exclusiveMaximum")))

    if isinstance(inst, str):
        if "minLength" in schema and len(inst) < schema["minLength"]:
            n = schema["minLength"]
            errors.append(ValidationError(f"{dump_value(inst)} is shorter than {n} {plural(n, 'character')}", path, path_join(spath, "minLength")))
        if "maxLength" in schema and len(inst) > schema["maxLength"]:
            n = schema["maxLength"]
            errors.append(ValidationError(f"{dump_value(inst)} is longer than {n} {plural(n, 'character')}", path, path_join(spath, "maxLength")))
        if "pattern" in schema:
            try:
                ok = re.search(schema["pattern"], inst) is not None
            except re.error:
                ok = True
            if not ok:
                errors.append(ValidationError(f"{dump_value(inst)} does not match \"{schema['pattern']}\"", path, path_join(spath, "pattern")))
        if assert_format and "format" in schema and not check_format(schema["format"], inst):
            errors.append(ValidationError(f"{dump_value(inst)} is not a \"{schema['format']}\"", path, path_join(spath, "format")))

    if isinstance(inst, list):
        if "minItems" in schema and len(inst) < schema["minItems"]:
            n = schema["minItems"]
            errors.append(ValidationError(f"{dump_value(inst)} has fewer than {n} {plural(n, 'item')}", path, path_join(spath, "minItems")))
        if "maxItems" in schema and len(inst) > schema["maxItems"]:
            n = schema["maxItems"]
            errors.append(ValidationError(f"{dump_value(inst)} has more than {n} {plural(n, 'item')}", path, path_join(spath, "maxItems")))
        if schema.get("uniqueItems") is True:
            seen = set()
            unique = True
            for item in inst:
                key = dump_value(item)
                if key in seen:
                    unique = False
                    break
                seen.add(key)
            if not unique:
                errors.append(ValidationError(f"{dump_value(inst)} has non-unique elements", path, path_join(spath, "uniqueItems")))
        if isinstance(schema.get("prefixItems"), list):
            for i, sub in enumerate(schema["prefixItems"][:len(inst)]):
                errors.extend(validate(sub, inst[i], path_join(path, i), path_join(path_join(spath, "prefixItems"), i), assert_format, root, seen_refs))
        if isinstance(schema.get("items"), dict) or isinstance(schema.get("items"), bool):
            start = len(schema.get("prefixItems", [])) if isinstance(schema.get("prefixItems"), list) else 0
            for i in range(start, len(inst)):
                errors.extend(validate(schema["items"], inst[i], path_join(path, i), path_join(spath, "items"), assert_format, root, seen_refs))
        elif isinstance(schema.get("items"), list):
            for i, sub in enumerate(schema["items"][:len(inst)]):
                errors.extend(validate(sub, inst[i], path_join(path, i), path_join(path_join(spath, "items"), i), assert_format, root, seen_refs))
        if "contains" in schema:
            if not any(not validate(schema["contains"], item, path_join(path, i), path_join(spath, "contains"), assert_format, root, seen_refs) for i, item in enumerate(inst)):
                errors.append(ValidationError(f"{dump_value(inst)} does not contain items matching the given schema", path, path_join(spath, "contains")))

    if isinstance(inst, dict):
        if "minProperties" in schema and len(inst) < schema["minProperties"]:
            n = schema["minProperties"]
            errors.append(ValidationError(f"{dump_value(inst)} has fewer than {n} {plural(n, 'property')}", path, path_join(spath, "minProperties")))
        if "maxProperties" in schema and len(inst) > schema["maxProperties"]:
            n = schema["maxProperties"]
            errors.append(ValidationError(f"{dump_value(inst)} has more than {n} {plural(n, 'property')}", path, path_join(spath, "maxProperties")))
        if isinstance(schema.get("required"), list):
            for name in schema["required"]:
                if name not in inst:
                    errors.append(ValidationError(f"\"{name}\" is a required property", path, path_join(spath, "required")))
        dep_req = {}
        if isinstance(schema.get("dependentRequired"), dict):
            dep_req.update(schema["dependentRequired"])
        if isinstance(schema.get("dependencies"), dict):
            for name, dep in schema["dependencies"].items():
                if isinstance(dep, list):
                    dep_req[name] = dep
        for name, required_names in dep_req.items():
            if name in inst and isinstance(required_names, list):
                for required_name in required_names:
                    if required_name not in inst:
                        errors.append(ValidationError(f"\"{required_name}\" is a dependency of \"{name}\"", path, path_join(spath, "dependentRequired")))
        for key in ("dependentSchemas", "dependencies"):
            if isinstance(schema.get(key), dict):
                for name, sub in schema[key].items():
                    if name in inst and isinstance(sub, (dict, bool)):
                        errors.extend(validate(sub, inst, path, path_join(path_join(spath, key), name), assert_format, root, seen_refs))
        props = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
        matched = set()
        for name in sorted(props):
            sub = props[name]
            if name in inst:
                matched.add(name)
                errors.extend(validate(sub, inst[name], path_join(path, name), path_join(path_join(spath, "properties"), name), assert_format, root, seen_refs))
        pat_props = schema.get("patternProperties") if isinstance(schema.get("patternProperties"), dict) else {}
        for patt, sub in pat_props.items():
            try:
                rx = re.compile(patt)
            except re.error:
                continue
            for name, val in inst.items():
                if rx.search(name):
                    matched.add(name)
                    errors.extend(validate(sub, val, path_join(path, name), path_join(path_join(spath, "patternProperties"), patt), assert_format, root, seen_refs))
        if "propertyNames" in schema:
            for name in inst:
                errors.extend(validate(schema["propertyNames"], name, path_join(path, name), path_join(spath, "propertyNames"), assert_format, root, seen_refs))
        if "additionalProperties" in schema:
            extra = [k for k in inst if k not in matched]
            ap = schema["additionalProperties"]
            if ap is False and extra:
                if len(extra) == 1:
                    msg = f"Additional properties are not allowed ('{extra[0]}' was unexpected)"
                else:
                    quoted = ", ".join(f"'{x}'" for x in extra)
                    msg = f"Additional properties are not allowed ({quoted} were unexpected)"
                errors.append(ValidationError(msg, path, path_join(spath, "additionalProperties")))
            elif isinstance(ap, (dict, bool)):
                for name in extra:
                    errors.extend(validate(ap, inst[name], path_join(path, name), path_join(spath, "additionalProperties"), assert_format, root, seen_refs))

    for key in ("allOf", "anyOf", "oneOf"):
        if isinstance(schema.get(key), list):
            subs = schema[key]
            counts = [not validate(sub, inst, path, path_join(path_join(spath, key), i), assert_format, root, seen_refs) for i, sub in enumerate(subs)]
            ok_count = sum(1 for x in counts if x)
            if key == "allOf" and ok_count != len(subs):
                errors.append(ValidationError(f"{dump_value(inst)} is not valid under all of the schemas listed in the 'allOf' keyword", path, path_join(spath, key)))
            elif key == "anyOf" and ok_count == 0:
                errors.append(ValidationError(f"{dump_value(inst)} is not valid under any of the schemas listed in the 'anyOf' keyword", path, path_join(spath, key)))
            elif key == "oneOf" and ok_count != 1:
                errors.append(ValidationError(f"{dump_value(inst)} is valid under {ok_count} of the schemas listed in the 'oneOf' keyword", path, path_join(spath, key)))
    if "not" in schema and not validate(schema["not"], inst, path, path_join(spath, "not"), assert_format, root, seen_refs):
        errors.append(ValidationError(f"{dump_value(schema['not'])} is not allowed for {dump_value(inst)}", path, path_join(spath, "not")))
    if "if" in schema:
        if_ok = not validate(schema["if"], inst, path, path_join(spath, "if"), assert_format, root, seen_refs)
        if if_ok and "then" in schema:
            errors.extend(validate(schema["then"], inst, path, path_join(spath, "then"), assert_format, root, seen_refs))
        if not if_ok and "else" in schema:
            errors.extend(validate(schema["else"], inst, path, path_join(spath, "else"), assert_format, root, seen_refs))

    return errors


def load_json_file(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f), None
    except FileNotFoundError:
        return None, "No such file or directory (os error 2)"
    except PermissionError:
        return None, "Permission denied (os error 13)"
    except json.JSONDecodeError as e:
        msg = e.msg.lower()
        return None, f"{msg} at line {e.lineno} column {e.colno}"
    except OSError as e:
        return None, str(e)


def schema_uri(schema_path):
    return "file://" + os.path.abspath(schema_path) + "#"


def emit_json_output(output, schema_path, instance_path, errors):
    valid = not errors
    obj = {"output": output, "payload": {"valid": valid}, "schema": schema_path}
    if instance_path is not None:
        obj = {"instance": instance_path, "output": output, "payload": {"valid": valid}, "schema": schema_path}
    if output in ("list", "hierarchical"):
        base = schema_uri(schema_path)
        details = [{"evaluationPath": "", "instanceLocation": "", "schemaLocation": base, "valid": valid}]
        for err in errors:
            details.append({
                "errors": {err.schema_path.rsplit("/", 1)[-1] or "": err.message},
                "evaluationPath": err.schema_path,
                "instanceLocation": err.path,
                "schemaLocation": base + err.schema_path,
                "valid": False,
            })
        obj["payload"] = {"details": details, "valid": valid}
    print(json.dumps(obj, separators=(",", ":")))


def make_parser():
    p = argparse.ArgumentParser(
        prog="executable",
        usage="%(prog)s [OPTIONS] [SCHEMA]",
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("schema", nargs="?")
    p.add_argument("-i", "--instance", action="append", dest="instances")
    p.add_argument("-d", "--draft", choices=["4", "6", "7", "2019", "2020"])
    p.add_argument("--assert-format", action="store_true")
    p.add_argument("--no-assert-format", action="store_true")
    p.add_argument("--output", choices=["text", "flag", "list", "hierarchical"], default="text")
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("--errors-only", action="store_true")
    p.add_argument("--connect-timeout")
    p.add_argument("--timeout")
    p.add_argument("-k", "--insecure", action="store_true")
    p.add_argument("--cacert")
    p.add_argument("-h", "--help", action="store_true")
    return p


HELP = """Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help"""


def main():
    parser = make_parser()
    try:
        args = parser.parse_args()
    except SystemExit:
        return 2
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print("Version: 0.41.0")
        return 0
    if not args.schema:
        print("error: the following required arguments were not provided:\n  <SCHEMA>\n\nUsage: executable <SCHEMA>\n\nFor more information, try '--help'.", file=sys.stderr)
        return 2

    schema, err = load_json_file(args.schema)
    if err:
        print(f"Error: {err}")
        return 1
    serr = validate_schema(schema)
    if serr:
        print(f"Schema is invalid. Error: {serr}")
        return 1
    if not args.instances:
        if args.output == "text":
            print("Schema is valid")
        else:
            emit_json_output(args.output, args.schema, None, [])
        return 0

    exit_code = 0
    assert_format = args.assert_format and not args.no_assert_format
    for inst_path in args.instances:
        inst, err = load_json_file(inst_path)
        if err:
            print(f"Error: {err}")
            exit_code = 1
            continue
        errors = validate(schema, inst, "", "", assert_format)
        if errors:
            exit_code = 1
        if args.output == "text":
            if errors:
                print(f"{inst_path} - INVALID. Errors:")
                for i, e in enumerate(errors, 1):
                    print(f"{i}. {e.message}")
            elif not args.errors_only:
                print(f"{inst_path} - VALID")
        else:
            emit_json_output(args.output, args.schema, inst_path, errors)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
