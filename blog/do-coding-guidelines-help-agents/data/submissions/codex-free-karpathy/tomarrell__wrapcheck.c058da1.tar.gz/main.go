package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

type pkgInfo struct {
	ImportPath  string
	Dir         string
	GoFiles     []string
	TestGoFiles []string
}

type config struct {
	ignoreSigs        []string
	ignoreRegexps     []*regexp.Regexp
	ignorePkgGlobs    []string
	reportInternal    bool
	hasReportInternal bool
}

type diag struct {
	Pkg     string
	Pos     token.Position
	Message string
	Line    string
}

type analyzer struct {
	pkg          pkgInfo
	fset         *token.FileSet
	cfg          config
	imports      map[*ast.File]map[string]string
	localRetErr  map[string]bool
	methodRetErr map[string]bool
}

var sigCache = map[string]map[string]string{}

var defaultIgnores = []string{
	".Errorf(",
	"errors.New(",
	"errors.Unwrap(",
	"errors.Join(",
	".Wrap(",
	".Wrapf(",
	".WithMessage(",
	".WithMessagef(",
	".WithStack(",
}

func main() {
	var (
		showVersion = flag.Bool("V", false, "print version and exit")
		_           = flag.Bool("all", false, "no effect (deprecated)")
		context     = flag.Int("c", -1, "display offending line with this many lines of context")
		_           = flag.String("cpuprofile", "", "write CPU profile to this file")
		_           = flag.String("debug", "", `debug flags, any subset of "fpstv"`)
		_           = flag.Bool("diff", false, "with -fix, don't update the files, but print a unified diff")
		_           = flag.Bool("fix", false, "apply all suggested fixes")
		showFlags   = flag.Bool("flags", false, "print analyzer flags in JSON")
		jsonOut     = flag.Bool("json", false, "emit JSON output")
		_           = flag.String("memprofile", "", "write memory profile to this file")
		_           = flag.Bool("source", false, "no effect (deprecated)")
		_           = flag.String("tags", "", "no effect (deprecated)")
		includeTest = flag.Bool("test", true, "indicates whether test files should be analyzed, too")
		_           = flag.String("trace", "", "write trace log to this file")
		_           = flag.Bool("v", false, "no effect (deprecated)")
	)
	flag.Usage = usage
	flag.Parse()

	if *showFlags {
		printFlags()
		return
	}
	if *showVersion {
		fmt.Println("wrapcheck")
		return
	}

	patterns := flag.Args()
	if len(patterns) == 0 {
		patterns = []string{"."}
	}

	pkgs, err := listPackages(patterns)
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	cfg := readConfig()
	var all []diag
	for _, p := range pkgs {
		ds, err := analyzePackage(p, cfg, *includeTest)
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		all = append(all, ds...)
	}
	sort.Slice(all, func(i, j int) bool {
		if all[i].Pos.Filename != all[j].Pos.Filename {
			return all[i].Pos.Filename < all[j].Pos.Filename
		}
		if all[i].Pos.Line != all[j].Pos.Line {
			return all[i].Pos.Line < all[j].Pos.Line
		}
		return all[i].Pos.Column < all[j].Pos.Column
	})

	if *jsonOut {
		printJSON(all)
		return
	}
	for _, d := range all {
		fmt.Printf("%s:%d:%d: %s\n", d.Pos.Filename, d.Pos.Line, d.Pos.Column, d.Message)
		if *context >= 0 {
			printContext(d, *context)
		}
	}
	if len(all) > 0 {
		os.Exit(3)
	}
}

func usage() {
	fmt.Fprint(os.Stderr, `wrapcheck: Checks that errors returned from external packages are wrapped

Usage: wrapcheck [-flag] [package]


Flags:
`)
	flag.PrintDefaults()
}

func printFlags() {
	type f struct {
		Name  string
		Bool  bool
		Usage string
	}
	flags := []f{
		{"V", true, "print version and exit"},
		{"all", true, "no effect (deprecated)"},
		{"c", false, "display offending line with this many lines of context"},
		{"diff", true, "with -fix, don't update the files, but print a unified diff"},
		{"flags", true, "print analyzer flags in JSON"},
		{"json", true, "emit JSON output"},
		{"source", true, "no effect (deprecated)"},
		{"tags", false, "no effect (deprecated)"},
		{"test", true, "indicates whether test files should be analyzed, too"},
		{"v", true, "no effect (deprecated)"},
	}
	b, _ := json.MarshalIndent(flags, "", "\t")
	fmt.Println(string(b))
}

func listPackages(patterns []string) ([]pkgInfo, error) {
	args := append([]string{"list", "-json"}, patterns...)
	cmd := exec.Command("go", args...)
	var out, errb bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &errb
	if err := cmd.Run(); err != nil {
		if errb.Len() > 0 {
			return nil, fmt.Errorf(strings.TrimSpace(errb.String()))
		}
		return nil, err
	}
	dec := json.NewDecoder(&out)
	var pkgs []pkgInfo
	for dec.More() {
		var p pkgInfo
		if err := dec.Decode(&p); err != nil {
			return nil, err
		}
		if p.Dir != "" {
			pkgs = append(pkgs, p)
		}
	}
	return pkgs, nil
}

func readConfig() config {
	cfg := config{ignoreSigs: append([]string{}, defaultIgnores...)}
	path := findConfig()
	if path == "" {
		return cfg
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return cfg
	}
	sections := parseSimpleYAML(string(data))
	if vals, ok := sections["ignoreSigs"]; ok {
		cfg.ignoreSigs = vals
	}
	if vals, ok := sections["extraIgnoreSigs"]; ok {
		cfg.ignoreSigs = append(cfg.ignoreSigs, vals...)
	}
	for _, s := range sections["ignoreSigRegexps"] {
		if re, err := regexp.Compile(s); err == nil {
			cfg.ignoreRegexps = append(cfg.ignoreRegexps, re)
		}
	}
	cfg.ignorePkgGlobs = append(cfg.ignorePkgGlobs, sections["ignorePackageGlobs"]...)
	if vals, ok := sections["reportInternalErrors"]; ok && len(vals) > 0 {
		cfg.hasReportInternal = true
		cfg.reportInternal = vals[0] == "true"
	}
	return cfg
}

func findConfig() string {
	if wd, err := os.Getwd(); err == nil {
		p := filepath.Join(wd, ".wrapcheck.yaml")
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	if home, err := os.UserHomeDir(); err == nil {
		p := filepath.Join(home, ".wrapcheck.yaml")
		if _, err := os.Stat(p); err == nil {
			return p
		}
	}
	return ""
}

func parseSimpleYAML(s string) map[string][]string {
	res := map[string][]string{}
	var key string
	for _, line := range strings.Split(s, "\n") {
		if i := strings.Index(line, "#"); i >= 0 {
			line = line[:i]
		}
		raw := strings.TrimSpace(line)
		if raw == "" {
			continue
		}
		if strings.HasSuffix(raw, ":") {
			key = strings.TrimSuffix(raw, ":")
			res[key] = nil
			continue
		}
		if strings.Contains(raw, ":") && !strings.HasPrefix(raw, "-") {
			parts := strings.SplitN(raw, ":", 2)
			key = strings.TrimSpace(parts[0])
			val := unquote(strings.TrimSpace(parts[1]))
			res[key] = []string{val}
			continue
		}
		if strings.HasPrefix(raw, "-") && key != "" {
			res[key] = append(res[key], unquote(strings.TrimSpace(strings.TrimPrefix(raw, "-"))))
		}
	}
	return res
}

func unquote(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 {
		if (s[0] == '"' && s[len(s)-1] == '"') || (s[0] == '\'' && s[len(s)-1] == '\'') {
			return s[1 : len(s)-1]
		}
	}
	return s
}

func analyzePackage(p pkgInfo, cfg config, includeTest bool) ([]diag, error) {
	fset := token.NewFileSet()
	files := append([]string{}, p.GoFiles...)
	if includeTest {
		files = append(files, p.TestGoFiles...)
	}
	a := &analyzer{
		pkg:          p,
		fset:         fset,
		cfg:          cfg,
		imports:      map[*ast.File]map[string]string{},
		localRetErr:  map[string]bool{},
		methodRetErr: map[string]bool{},
	}
	var parsed []*ast.File
	for _, name := range files {
		path := filepath.Join(p.Dir, name)
		f, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
		if err != nil {
			return nil, err
		}
		parsed = append(parsed, f)
		imp := map[string]string{}
		for _, is := range f.Imports {
			ip, _ := strconv.Unquote(is.Path.Value)
			alias := filepath.Base(ip)
			if is.Name != nil {
				alias = is.Name.Name
			}
			if alias != "." && alias != "_" {
				imp[alias] = ip
			}
		}
		a.imports[f] = imp
		for _, d := range f.Decls {
			fn, ok := d.(*ast.FuncDecl)
			if !ok || !returnsError(fn.Type.Results) {
				continue
			}
			if fn.Recv == nil {
				a.localRetErr[fn.Name.Name] = true
			} else if len(fn.Recv.List) > 0 {
				a.methodRetErr[recvName(fn.Recv.List[0].Type)+"."+fn.Name.Name] = true
			}
		}
	}
	var out []diag
	for _, f := range parsed {
		out = append(out, a.analyzeFile(f)...)
	}
	return out, nil
}

func returnsError(fl *ast.FieldList) bool {
	if fl == nil {
		return false
	}
	for _, field := range fl.List {
		if exprName(field.Type) == "error" {
			return true
		}
	}
	return false
}

func recvName(e ast.Expr) string {
	if star, ok := e.(*ast.StarExpr); ok {
		e = star.X
	}
	return exprName(e)
}

func (a *analyzer) analyzeFile(f *ast.File) []diag {
	var out []diag
	for _, decl := range f.Decls {
		fn, ok := decl.(*ast.FuncDecl)
		if !ok || fn.Body == nil || !returnsError(fn.Type.Results) {
			continue
		}
		env := map[string]string{}
		typeEnv := map[string]string{}
		ast.Inspect(fn.Body, func(n ast.Node) bool {
			switch x := n.(type) {
			case *ast.ValueSpec:
				a.recordValueSpec(f, x, env, typeEnv)
			case *ast.AssignStmt:
				a.recordAssign(f, x, env, typeEnv)
			case *ast.ReturnStmt:
				for _, d := range a.checkReturn(f, x, env, typeEnv) {
					out = append(out, d)
				}
			}
			return true
		})
	}
	return out
}

func (a *analyzer) recordValueSpec(f *ast.File, v *ast.ValueSpec, env, typeEnv map[string]string) {
	if v.Type != nil {
		if pkg := a.externalTypeName(f, v.Type); pkg != "" {
			for _, n := range v.Names {
				typeEnv[n.Name] = pkg
			}
		}
	}
	for i, val := range v.Values {
		if sig, ok := a.callSignature(f, val, typeEnv); ok {
			if len(v.Names) == 1 && i == 0 {
				env[v.Names[0].Name] = sig
			}
		}
	}
}

func (a *analyzer) recordAssign(f *ast.File, as *ast.AssignStmt, env, typeEnv map[string]string) {
	for i, rhs := range as.Rhs {
		if i < len(as.Lhs) {
			if id, ok := as.Lhs[i].(*ast.Ident); ok {
				if pkg := a.externalTypeName(f, rhs); pkg != "" {
					typeEnv[id.Name] = pkg
				}
				if sig, ok := a.callSignature(f, rhs, typeEnv); ok {
					env[id.Name] = sig
				}
			}
		}
		if sig, ok := a.callSignature(f, rhs, typeEnv); ok {
			if len(as.Rhs) == 1 {
				for _, lhs := range as.Lhs {
					if id, ok := lhs.(*ast.Ident); ok && id.Name != "_" && strings.HasPrefix(id.Name, "err") {
						env[id.Name] = sig
					}
				}
			}
		}
	}
}

func (a *analyzer) checkReturn(f *ast.File, r *ast.ReturnStmt, env, typeEnv map[string]string) []diag {
	var out []diag
	for _, e := range r.Results {
		if sig, ok := a.callSignature(f, e, typeEnv); ok && !a.ignored(sig) {
			out = append(out, a.newDiag(e.Pos(), sig))
		}
		if id, ok := e.(*ast.Ident); ok {
			if sig := env[id.Name]; sig != "" && !a.ignored(sig) {
				out = append(out, a.newDiag(e.Pos(), sig))
			}
		}
	}
	return out
}

func (a *analyzer) callSignature(f *ast.File, e ast.Expr, typeEnv map[string]string) (string, bool) {
	call, ok := e.(*ast.CallExpr)
	if !ok {
		return "", false
	}
	switch fun := call.Fun.(type) {
	case *ast.SelectorExpr:
		if id, ok := fun.X.(*ast.Ident); ok {
			if ip := a.imports[f][id.Name]; ip != "" {
				sig := lookupSignature(ip, "", fun.Sel.Name)
				if sig == "" {
					sig = fmt.Sprintf("func %s.%s() error", ip, fun.Sel.Name)
				}
				return sig, a.isExternal(ip)
			}
			if typ := typeEnv[id.Name]; typ != "" {
				ip := typ
				if i := strings.LastIndex(typ, "."); i > 0 {
					ip = typ[:i]
				}
				typeName := typ
				if i := strings.LastIndex(typ, "."); i > 0 {
					typeName = typ[i+1:]
				}
				sig := lookupSignature(ip, typeName, fun.Sel.Name)
				if sig == "" {
					sig = fmt.Sprintf("func (%s).%s() error", typ, fun.Sel.Name)
				}
				return sig, a.isExternal(ip)
			}
		}
	case *ast.Ident:
		if a.localRetErr[fun.Name] {
			return "", false
		}
	}
	return "", false
}

func (a *analyzer) externalTypeName(f *ast.File, e ast.Expr) string {
	if star, ok := e.(*ast.StarExpr); ok {
		e = star.X
	}
	switch x := e.(type) {
	case *ast.SelectorExpr:
		if id, ok := x.X.(*ast.Ident); ok {
			if ip := a.imports[f][id.Name]; ip != "" {
				return ip + "." + x.Sel.Name
			}
		}
	case *ast.CompositeLit:
		return a.externalTypeName(f, x.Type)
	}
	return ""
}

func lookupSignature(importPath, recv, name string) string {
	key := importPath
	if _, ok := sigCache[key]; !ok {
		sigCache[key] = loadSignatures(importPath)
	}
	if recv != "" {
		return sigCache[key][recv+"."+name]
	}
	return sigCache[key][name]
}

func loadSignatures(importPath string) map[string]string {
	out := map[string]string{}
	cmd := exec.Command("go", "list", "-json", importPath)
	var buf bytes.Buffer
	cmd.Stdout = &buf
	if err := cmd.Run(); err != nil {
		return out
	}
	var p pkgInfo
	if err := json.Unmarshal(buf.Bytes(), &p); err != nil {
		return out
	}
	fset := token.NewFileSet()
	for _, name := range p.GoFiles {
		f, err := parser.ParseFile(fset, filepath.Join(p.Dir, name), nil, 0)
		if err != nil {
			continue
		}
		for _, decl := range f.Decls {
			fn, ok := decl.(*ast.FuncDecl)
			if !ok {
				continue
			}
			if fn.Recv == nil {
				out[fn.Name.Name] = "func " + importPath + "." + fn.Name.Name + fieldList(fn.Type.Params) + resultList(fn.Type.Results)
				continue
			}
			if len(fn.Recv.List) == 0 {
				continue
			}
			rn := recvName(fn.Recv.List[0].Type)
			out[rn+"."+fn.Name.Name] = "func (" + importPath + "." + rn + ")." + fn.Name.Name + fieldList(fn.Type.Params) + resultList(fn.Type.Results)
		}
	}
	return out
}

func fieldList(fl *ast.FieldList) string {
	if fl == nil || len(fl.List) == 0 {
		return "()"
	}
	var parts []string
	for _, f := range fl.List {
		t := exprName(f.Type)
		n := len(f.Names)
		if n == 0 {
			n = 1
		}
		for i := 0; i < n; i++ {
			parts = append(parts, t)
		}
	}
	return "(" + strings.Join(parts, ", ") + ")"
}

func resultList(fl *ast.FieldList) string {
	if fl == nil || len(fl.List) == 0 {
		return ""
	}
	var parts []string
	for _, f := range fl.List {
		t := exprName(f.Type)
		n := len(f.Names)
		if n == 0 {
			n = 1
		}
		for i := 0; i < n; i++ {
			parts = append(parts, t)
		}
	}
	if len(parts) == 1 {
		return " " + parts[0]
	}
	return " (" + strings.Join(parts, ", ") + ")"
}

func (a *analyzer) isExternal(ip string) bool {
	if ip == "" {
		return false
	}
	if ip == a.pkg.ImportPath || strings.HasPrefix(ip, a.pkg.ImportPath+"/") {
		return a.cfg.reportInternal
	}
	for _, pat := range a.cfg.ignorePkgGlobs {
		if ok, _ := filepath.Match(pat, ip); ok {
			return false
		}
	}
	return true
}

func (a *analyzer) ignored(sig string) bool {
	for _, s := range a.cfg.ignoreSigs {
		if strings.Contains(sig, s) {
			return true
		}
	}
	for _, re := range a.cfg.ignoreRegexps {
		if re.MatchString(sig) {
			return true
		}
	}
	return false
}

func (a *analyzer) newDiag(pos token.Pos, sig string) diag {
	p := a.fset.Position(pos)
	return diag{Pkg: a.pkg.ImportPath, Pos: p, Message: "error returned from external package is unwrapped: sig: " + sig, Line: readLine(p.Filename, p.Line)}
}

func exprName(e ast.Expr) string {
	switch x := e.(type) {
	case *ast.Ident:
		return x.Name
	case *ast.SelectorExpr:
		return exprName(x.X) + "." + x.Sel.Name
	case *ast.StarExpr:
		return exprName(x.X)
	}
	return ""
}

func readLine(path string, line int) string {
	b, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	lines := strings.Split(string(b), "\n")
	if line <= 0 || line > len(lines) {
		return ""
	}
	return lines[line-1]
}

func printContext(d diag, c int) {
	if d.Line != "" {
		fmt.Printf("%d\t%s\n", d.Pos.Line, d.Line)
	}
}

func printJSON(ds []diag) {
	type jd struct {
		Posn    string `json:"posn"`
		Message string `json:"message"`
	}
	out := map[string]map[string][]jd{}
	for _, d := range ds {
		if _, ok := out[d.Pkg]; !ok {
			out[d.Pkg] = map[string][]jd{"wrapcheck": nil}
		}
		out[d.Pkg]["wrapcheck"] = append(out[d.Pkg]["wrapcheck"], jd{
			Posn:    fmt.Sprintf("%s:%d:%d", d.Pos.Filename, d.Pos.Line, d.Pos.Column),
			Message: d.Message,
		})
	}
	b, _ := json.MarshalIndent(out, "", "\t")
	fmt.Println(string(b))
}
