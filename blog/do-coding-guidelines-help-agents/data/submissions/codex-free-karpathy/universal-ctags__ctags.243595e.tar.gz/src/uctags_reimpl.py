#!/usr/bin/env python3
import json
import os
import re
import sys

VERSION = "6.2.0"

KIND_NAMES = {
    "c": "class", "C": "constant", "d": "macro", "e": "enumerator",
    "f": "function", "g": "enum", "h": "header", "i": "interface",
    "m": "member", "n": "namespace", "p": "package", "P": "method",
    "s": "struct", "t": "typedef", "u": "union", "v": "variable",
    "x": "externvar",
}

LANGS = """Abaqus
Abc
Ada
AnsiblePlaybook
Ant
Asciidoc
Asm
Asp
Autoconf
AutoIt
Automake
Awk
Basic
Bats
BETA
BibLaTeX
BibTeX
C
C#
C++
Cargo [disabled]
Clojure
CMake
Cobol
CSS
Ctags
CUDA
D
Diff
DosBatch
DTD
Elixir
Elm
EmacsLisp
Erlang
Fortran
Go
Haskell
HTML
Java
JavaScript
JSON
Julia
Kotlin
Lua
M4
Make
Man
Markdown
MatLab
Meson
ObjectiveC
OCaml
Perl
PHP
Python
R
Ruby
Rust
Scheme
Sh
SQL
Tcl
TypeScript
Vim
XML
YAML""".splitlines()


class Tag:
    __slots__ = ("name", "path", "line", "text", "kind", "scope_kind", "scope",
                 "typeref", "file_scope", "signature", "language")

    def __init__(self, name, path, line, text, kind, scope_kind=None, scope=None,
                 typeref=None, file_scope=False, signature=None, language=None):
        self.name = name
        self.path = path
        self.line = line
        self.text = text.rstrip("\n\r")
        self.kind = kind
        self.scope_kind = scope_kind
        self.scope = scope
        self.typeref = typeref
        self.file_scope = file_scope
        self.signature = signature
        self.language = language

    def pattern(self, fmt=2):
        s = self.text
        s = s.replace("\\", "\\\\").replace("/", "\\/")
        if s.endswith(" ") and s.lstrip().startswith("#"):
            return "/^" + s + ('/;"' if fmt == 2 else "/")
        suffix = '$/;"' if fmt == 2 else '$/'
        return "/^" + s + suffix


def detect_language(path, forced=None):
    if forced and forced.lower() != "auto":
        return forced
    base = os.path.basename(path)
    ext = os.path.splitext(base)[1].lower()
    if ext in (".c", ".h"): return "C"
    if ext in (".cc", ".cpp", ".cxx", ".hpp", ".hh"): return "C++"
    if ext == ".py": return "Python"
    if ext in (".js", ".mjs", ".cjs"): return "JavaScript"
    if ext in (".ts", ".tsx"): return "TypeScript"
    if ext == ".go": return "Go"
    if ext == ".rs": return "Rust"
    if ext == ".java": return "Java"
    if ext in (".sh", ".bash", ".zsh", ".ksh"): return "Sh"
    if ext in (".mk",) or base in ("Makefile", "makefile", "GNUmakefile"): return "Make"
    if ext in (".md", ".markdown"): return "Markdown"
    if ext in (".rb",): return "Ruby"
    if ext in (".php",): return "PHP"
    if ext in (".lua",): return "Lua"
    if ext in (".json",): return "JSON"
    if ext in (".yml", ".yaml"): return "YAML"
    if ext in (".html", ".htm"): return "HTML"
    if ext in (".css",): return "CSS"
    return "C" if ext in ("", ".inc") else None


def read_lines(path):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return f.readlines()
    except OSError as e:
        print(f"executable: Warning: cannot open input file \"{path}\" : {e.strerror}", file=sys.stderr)
        return []


def strip_comments_c(line, in_block):
    out = []
    i = 0
    while i < len(line):
        if in_block:
            j = line.find("*/", i)
            if j < 0:
                return "", True
            i = j + 2
            in_block = False
        elif line.startswith("/*", i):
            in_block = True
            i += 2
        elif line.startswith("//", i):
            break
        else:
            out.append(line[i])
            i += 1
    return "".join(out), in_block


def split_decl_vars(rest):
    rest = rest.strip().rstrip(";")
    out = []
    for part in rest.split(","):
        left = part.split("=")[0].strip()
        m = re.search(r"([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?$", left)
        if m:
            out.append(m.group(1))
    return out


def parse_c_like(path, lines, lang):
    tags = []
    in_block = False
    for i, raw in enumerate(lines, 1):
        text = raw.rstrip("\n\r")
        s, in_block = strip_comments_c(text, in_block)
        st = s.strip()
        if not st:
            continue
        m = re.match(r"#\s*define\s+([A-Za-z_]\w*)", st)
        if m:
            display = text
            if "(" not in st[:st.find(m.group(1)) + len(m.group(1)) + 1]:
                display = re.sub(r"(#\s*define\s+" + re.escape(m.group(1)) + r")\b.*", r"\1 ", text)
            tags.append(Tag(m.group(1), path, i, display, "d", file_scope=True, language=lang))
            continue
        m = re.match(r"typedef\s+(?:struct|union|enum)?\s*[^;{]*\s+([A-Za-z_]\w*)\s*;", st)
        if m:
            before = st[len("typedef"):st.rfind(m.group(1))].strip()
            typ = before.replace("struct ", "").replace("union ", "").replace("enum ", "").strip()
            tags.append(Tag(m.group(1), path, i, text, "t", typeref=("typename:" + typ if typ else None),
                            file_scope=True, language=lang))
            continue
        for kw, kind, scope_kind in (("struct", "s", "struct"), ("union", "u", "union"), ("enum", "g", "enum")):
            m = re.match(rf"{kw}\s+([A-Za-z_]\w*)\b(.*)", st)
            if m:
                name = m.group(1)
                tags.append(Tag(name, path, i, text, kind, file_scope=True, language=lang))
                body = ""
                if "{" in st and "}" in st:
                    body = st[st.find("{") + 1:st.rfind("}")]
                if kw == "enum" and body:
                    for e in body.split(","):
                        em = re.match(r"\s*([A-Za-z_]\w*)", e)
                        if em:
                            tags.append(Tag(em.group(1), path, i, text, "e", scope_kind, name,
                                            file_scope=True, language=lang))
                elif body:
                    for part in body.split(";"):
                        mm = re.match(r"\s*(.+?)\s+([*]*\s*[A-Za-z_]\w*)\s*(?:\[[^\]]*\])?$", part.strip())
                        if mm:
                            typ = mm.group(1).strip() + (" *" if "*" in mm.group(2) else "")
                            mem = re.sub(r"^\*+\s*", "", mm.group(2)).strip()
                            tags.append(Tag(mem, path, i, text, "m", scope_kind, name,
                                            "typename:" + typ.strip(), True, language=lang))
                continue
        proto = re.match(r"(?:(static|extern)\s+)?([A-Za-z_][\w\s\*\:<>~]*?)\s+([A-Za-z_~]\w*)\s*(\([^;]*\))\s*(?:\{|$)", st)
        if proto and not st.startswith(("if", "for", "while", "switch", "return")):
            ret, name, sig = proto.group(2).strip(), proto.group(3), proto.group(4)
            kind = "f" if "{" in st else "p"
            if kind == "f" or "--c-kinds=+p" in sys.argv or "--kinds-C=+p" in sys.argv:
                tags.append(Tag(name, path, i, text, kind, typeref="typename:" + ret.replace(" *", "*"),
                                file_scope=(proto.group(1) == "static"), signature=sig, language=lang))
            continue
        if re.search(r";\s*$", st) and "(" not in st and not st.startswith(("return", "typedef", "struct", "union", "enum")):
            vm = re.match(r"(?:(static|extern|const)\s+)*([A-Za-z_][\w\s\*]*?)\s+(.+);$", st)
            if vm:
                typ = vm.group(2).strip()
                for name in split_decl_vars(vm.group(3)):
                    tags.append(Tag(name, path, i, text, "v", typeref="typename:" + typ,
                                    file_scope=("static" in st.split()), language=lang))
    return tags


def parse_python(path, lines, lang):
    tags = []
    stack = []
    for i, raw in enumerate(lines, 1):
        text = raw.rstrip("\n\r")
        if not text.strip() or text.lstrip().startswith("#"):
            continue
        indent = len(text) - len(text.lstrip(" "))
        while stack and indent <= stack[-1][0]:
            stack.pop()
        scope = stack[-1][1] if stack else None
        m = re.match(r"\s*class\s+([A-Za-z_]\w*)\b", text)
        if m:
            name = m.group(1)
            tags.append(Tag(name, path, i, text, "c", language=lang))
            stack.append((indent, name, "class"))
            continue
        m = re.match(r"\s*(?:async\s+)?def\s+([A-Za-z_]\w*)\s*(\([^)]*\))", text)
        if m:
            if scope:
                tags.append(Tag(m.group(1), path, i, text, "m", "class", scope, signature=m.group(2), language=lang))
            else:
                tags.append(Tag(m.group(1), path, i, text, "f", signature=m.group(2), language=lang))
            continue
        m = re.match(r"\s*([A-Za-z_]\w*)\s*(?::[^=]+)?=", text)
        if m and not re.match(r"\s*(if|while|for)\b", text):
            tags.append(Tag(m.group(1), path, i, text, "v", "class" if scope else None, scope, language=lang))
    return tags


def parse_js(path, lines, lang):
    tags = []
    class_stack = []
    for i, raw in enumerate(lines, 1):
        text = raw.rstrip("\n\r")
        st = text.strip()
        if not st or st.startswith("//"):
            continue
        m = re.match(r"(?:export\s+default\s+|export\s+)?class\s+([A-Za-z_$][\w$]*)", st)
        if m:
            cname = m.group(1)
            tags.append(Tag(cname, path, i, text, "c", language=lang))
            class_stack.append(cname)
            if "{" in st and "}" in st:
                body = st[st.find("{")+1:st.rfind("}")]
                for mm in re.finditer(r"\b([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{", body):
                    tags.append(Tag(mm.group(1), path, i, text, "m", "class", cname, language=lang))
            continue
        m = re.match(r"(?:export\s+)?(?:async\s+)?function\s+([A-Za-z_$][\w$]*)\s*(\([^)]*\))", st)
        if m:
            tags.append(Tag(m.group(1), path, i, text, "f", signature=m.group(2), language=lang)); continue
        m = re.match(r"(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?function\b", st)
        if m:
            tags.append(Tag(m.group(1), path, i, text, "f" if lang == "JavaScript" else "v", language=lang)); continue
        m = re.match(r"(?:export\s+)?(?:const|let|var)\s+([A-Za-z_$][\w$]*)\b", st)
        if m:
            tags.append(Tag(m.group(1), path, i, text, "C" if st.startswith("const ") else "v", language=lang)); continue
        m = re.match(r"(module\.exports|exports\.[A-Za-z_$][\w$]*)\s*=", st)
        if m:
            tags.append(Tag(m.group(1), path, i, text, "p", language=lang))
            if m.group(1) == "module.exports" and "{" in st and "}" in st:
                body = st[st.find("{")+1:st.rfind("}")]
                for name in re.findall(r"\b([A-Za-z_$][\w$]*)\b", body):
                    tags.append(Tag(name, path, i, text, "p", "property", "module.exports", language=lang))
    return tags


def parse_go(path, lines, lang):
    tags, package = [], ""
    for i, raw in enumerate(lines, 1):
        text = raw.rstrip("\n\r"); st = text.strip()
        m = re.match(r"package\s+([A-Za-z_]\w*)", st)
        if m:
            package = m.group(1); tags.append(Tag(package, path, i, text, "p", language=lang)); continue
        m = re.match(r"(?:const|var)\s+([A-Za-z_]\w*)\s*([^=]*)", st)
        if m:
            kind = "c" if st.startswith("const") else "v"
            typ = m.group(2).strip() or None
            tags.append(Tag(m.group(1), path, i, text, kind, "package" if package else None, package or None,
                            "typename:" + typ if typ else None, language=lang)); continue
        m = re.match(r"type\s+([A-Za-z_]\w*)\s+(struct|interface)\b", st)
        if m:
            name, what = m.group(1), m.group(2)
            tags.append(Tag(name, path, i, text, "s" if what == "struct" else "i", "package" if package else None,
                            package or None, language=lang))
            if "{" in st and "}" in st:
                body = st[st.find("{")+1:st.rfind("}")]
                for part in body.split(";"):
                    mm = re.match(r"\s*([A-Za-z_]\w*)\s*(?:\([^)]*\))?\s*([A-Za-z_][\w\.\*]*)?", part.strip())
                    if mm and mm.group(1):
                        tags.append(Tag(mm.group(1), path, i, text, "m" if what == "struct" else "n",
                                        what, (package + "." if package else "") + name,
                                        "typename:" + mm.group(2) if mm.group(2) else None, language=lang))
            continue
        m = re.match(r"func\s+(?:\(([^)]*)\)\s*)?([A-Za-z_]\w*)\s*(\([^)]*\))\s*([A-Za-z_][\w\.\*]*)?", st)
        if m:
            recv, name, sig, ret = m.groups()
            sk = sc = None
            if recv:
                typ = recv.split()[-1].lstrip("*")
                sk, sc = "struct", (package + "." if package else "") + typ
            else:
                sk, sc = ("package", package) if package else (None, None)
            tags.append(Tag(name, path, i, text, "f", sk, sc, "typename:" + ret if ret else None, signature=sig, language=lang))
    return tags


def parse_rust(path, lines, lang):
    tags = []
    current_impl = current_trait = None
    for i, raw in enumerate(lines, 1):
        text = raw.rstrip("\n\r"); st = text.strip()
        for pat, kind in ((r"\bmod\s+([A-Za-z_]\w*)", "n"), (r"\bstruct\s+([A-Za-z_]\w*)", "s"),
                          (r"\benum\s+([A-Za-z_]\w*)", "g"), (r"\btrait\s+([A-Za-z_]\w*)", "i")):
            m = re.search(pat, st)
            if m: tags.append(Tag(m.group(1), path, i, text, kind, language=lang))
        m = re.search(r"\bimpl\s+([A-Za-z_]\w*)", st)
        if m:
            current_impl = m.group(1); tags.append(Tag(current_impl, path, i, text, "c", language=lang))
        m = re.search(r"\b(?:pub\s+)?fn\s+([A-Za-z_]\w*)\s*(\([^)]*\))", st)
        if m:
            sk, sc, kind = (None, None, "f")
            im = re.search(r"\bimpl\s+([A-Za-z_]\w*)", st)
            tm = re.search(r"\btrait\s+([A-Za-z_]\w*)", st)
            mm = re.search(r"\bmod\s+([A-Za-z_]\w*)", st)
            if im and st.find("impl") <= st.find("fn"):
                sk, sc, kind = "implementation", im.group(1), "P"
            elif tm and st.find("trait") <= st.find("fn"):
                sk, sc, kind = "interface", tm.group(1), "P"
            elif mm and st.find("mod") <= st.find("fn"):
                sk, sc = "module", mm.group(1)
            elif current_impl:
                sk, sc, kind = "implementation", current_impl, "P"
            elif current_trait:
                sk, sc, kind = "interface", current_trait, "P"
            tags.append(Tag(m.group(1), path, i, text, kind, sk, sc, signature=m.group(2), language=lang))
        m = re.search(r"\b(?:pub\s+)?(?:const|static)\s+([A-Za-z_]\w*)", st)
        if m: tags.append(Tag(m.group(1), path, i, text, "C" if "const" in st else "v", language=lang))
        if st.startswith("trait "):
            mt = re.match(r"trait\s+([A-Za-z_]\w*)", st); current_trait = mt.group(1) if mt else None
        if "}" in st:
            current_impl = current_trait = None
        m = re.search(r"enum\s+([A-Za-z_]\w*)\s*\{(.*)\}", st)
        if m:
            for part in m.group(2).split(","):
                em = re.match(r"\s*([A-Za-z_]\w*)", part)
                if em: tags.append(Tag(em.group(1), path, i, text, "e", "enum", m.group(1), language=lang))
    return tags


def parse_java(path, lines, lang):
    tags, scope = [], None
    for i, raw in enumerate(lines, 1):
        text = raw.rstrip("\n\r"); st = text.strip()
        m = re.match(r"package\s+([\w.]+)\s*;", st)
        if m: tags.append(Tag(m.group(1), path, i, text, "p", language=lang)); continue
        m = re.match(r"(?:public|private|protected|abstract|final|\s)*\s*(class|interface|enum)\s+([A-Za-z_]\w*)", st)
        if m:
            scope = m.group(2); tags.append(Tag(scope, path, i, text, "c" if m.group(1) == "class" else ("i" if m.group(1) == "interface" else "g"), language=lang)); continue
        m = re.match(r"(?:public|private|protected|static|final|synchronized|\s)+([A-Za-z_][\w<>\[\].]*)\s+([A-Za-z_]\w*)\s*(\([^)]*\))", st)
        if m:
            tags.append(Tag(m.group(2), path, i, text, "m", "class" if scope else None, scope,
                            "typename:" + m.group(1), signature=m.group(3), language=lang)); continue
        m = re.match(r"(?:public|private|protected|static|final|\s)+([A-Za-z_][\w<>\[\].]*)\s+([A-Za-z_]\w*)\s*(?:=|;)", st)
        if m:
            tags.append(Tag(m.group(2), path, i, text, "v", "class" if scope else None, scope,
                            "typename:" + m.group(1), language=lang))
    return tags


def parse_simple(path, lines, lang):
    tags = []
    for i, raw in enumerate(lines, 1):
        text = raw.rstrip("\n\r"); st = text.strip()
        if lang == "Sh":
            m = re.match(r"(?:function\s+)?([A-Za-z_][\w-]*)\s*(?:\(\))?\s*\{", st)
            if m: tags.append(Tag(m.group(1), path, i, text, "f", language=lang))
        elif lang == "Make":
            m = re.match(r"([A-Za-z0-9_.%/-]+)\s*:", st)
            if m and not st.startswith("\t"): tags.append(Tag(m.group(1), path, i, text, "t", language=lang))
            m = re.match(r"([A-Za-z_][\w.-]*)\s*[:+?]?=", st)
            if m: tags.append(Tag(m.group(1), path, i, text, "m", language=lang))
        elif lang == "Markdown":
            m = re.match(r"(#{1,6})\s+(.+?)\s*#*$", st)
            if m: tags.append(Tag(m.group(2).strip(), path, i, text, "s", language=lang))
        elif lang == "Ruby":
            m = re.match(r"(class|module|def)\s+([A-Za-z_:]\w*(?:::\w+)*)", st)
            if m: tags.append(Tag(m.group(2), path, i, text, {"class":"c","module":"m","def":"f"}[m.group(1)], language=lang))
        elif lang == "PHP":
            m = re.match(r"(?:final\s+|abstract\s+)?(class|interface|trait)\s+([A-Za-z_]\w*)", st)
            if m: tags.append(Tag(m.group(2), path, i, text, "c" if m.group(1) == "class" else "i", language=lang))
            m = re.match(r"(?:public|private|protected|static|\s)*function\s+([A-Za-z_]\w*)\s*(\([^)]*\))", st)
            if m: tags.append(Tag(m.group(1), path, i, text, "f", signature=m.group(2), language=lang))
        elif lang == "Lua":
            m = re.match(r"function\s+([A-Za-z_][\w.:]*)\s*(\([^)]*\))", st)
            if m: tags.append(Tag(m.group(1), path, i, text, "f", signature=m.group(2), language=lang))
        else:
            m = re.match(r'"?([A-Za-z_][\w.-]*)"?\s*[:=]', st)
            if m: tags.append(Tag(m.group(1), path, i, text, "v", language=lang))
    return tags


def parse_file(path, forced=None):
    lang = detect_language(path, forced)
    lines = read_lines(path)
    if not lang or not lines:
        return []
    if lang in ("C", "C++", "CUDA", "ObjectiveC"): return parse_c_like(path, lines, lang)
    if lang == "Python": return parse_python(path, lines, lang)
    if lang in ("JavaScript", "TypeScript"): return parse_js(path, lines, lang)
    if lang == "Go": return parse_go(path, lines, lang)
    if lang == "Rust": return parse_rust(path, lines, lang)
    if lang == "Java": return parse_java(path, lines, lang)
    return parse_simple(path, lines, lang)


def collect_files(args, recurse=False, links=True, maxdepth=None):
    files = []
    def add(p, depth=0):
        if os.path.isdir(p):
            if not recurse and depth == 0:
                return
            if maxdepth is not None and depth >= maxdepth:
                return
            try:
                entries = sorted(os.listdir(p))
            except OSError:
                return
            for e in entries:
                full = os.path.join(p, e)
                if os.path.islink(full) and not links:
                    continue
                add(full, depth + 1)
        elif os.path.isfile(p):
            files.append(p)
    for a in args:
        add(a)
    return files


def render_tag(t, fmt, fields):
    parts = [t.name, t.path, t.pattern(fmt), t.kind]
    if "n" in fields: parts.append(f"line:{t.line}")
    if t.scope and t.scope_kind: parts.append(f"{t.scope_kind}:{t.scope}")
    if t.typeref and "t" in fields: parts.append(f"typeref:{t.typeref}")
    if t.file_scope and "f" in fields: parts.append("file:")
    if "l" in fields and t.language: parts.append("language:" + t.language)
    if "S" in fields and t.signature: parts.append("signature:" + t.signature)
    return "\t".join(parts)


def render_xref(t):
    kind = KIND_NAMES.get(t.kind, t.kind)
    return f"{t.name:<16} {kind:<12} {t.line:4d} {t.path:<16} {t.text.strip()}"


def render_json(t, fields):
    obj = {"_type": "tag", "name": t.name, "path": t.path, "pattern": t.pattern(1)}
    if t.file_scope: obj["file"] = True
    if "n" in fields: obj["line"] = t.line
    if t.typeref and "t" in fields: obj["typeref"] = t.typeref
    obj["kind"] = KIND_NAMES.get(t.kind, t.kind)
    if t.scope and t.scope_kind:
        obj["scope"] = t.scope; obj["scopeKind"] = t.scope_kind
    if "l" in fields and t.language: obj["language"] = t.language
    if "S" in fields and t.signature: obj["signature"] = t.signature
    return json.dumps(obj, ensure_ascii=False)


def pseudo_tags(cwd, langs):
    out = [
        "!_TAG_EXTRA_DESCRIPTION\tanonymous\t/Include tags for non-named objects like lambda/",
        "!_TAG_EXTRA_DESCRIPTION\tfileScope\t/Include tags of file scope/",
        "!_TAG_EXTRA_DESCRIPTION\tpseudo\t/Include pseudo tags/",
        "!_TAG_FIELD_DESCRIPTION\tfile\t/File-restricted scoping/",
        "!_TAG_FIELD_DESCRIPTION\tinput\t/input file/",
        "!_TAG_FIELD_DESCRIPTION\tname\t/tag name/",
        "!_TAG_FIELD_DESCRIPTION\tpattern\t/pattern/",
        "!_TAG_FIELD_DESCRIPTION\ttyperef\t/Type and name of a variable or typedef/",
        "!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/",
        "!_TAG_FILE_SORTED\t1\t/0=unsorted, 1=sorted, 2=foldcase/",
        "!_TAG_OUTPUT_EXCMD\tmixed\t/number, pattern, mixed, or combineV2/",
        "!_TAG_OUTPUT_FILESEP\tslash\t/slash or backslash/",
        "!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/",
        "!_TAG_OUTPUT_VERSION\t1.1\t/current.age/",
        f"!_TAG_PROC_CWD\t{cwd.rstrip('/')}/\t//",
        "!_TAG_PROGRAM_AUTHOR\tUniversal Ctags Team\t//",
        "!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/",
        "!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/",
        f"!_TAG_PROGRAM_VERSION\t{VERSION}\t/d922013/",
    ]
    return out


def help_text():
    return """Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team
Universal Ctags is derived from Exuberant Ctags.
Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert
  Compiled: Apr 20 2026, 16:52:56
  URL: https://ctags.io/
  Output version: 1.1
  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript

Usage: executable [options] [file(s)]

Input/Output Options
  --filter[=(yes|no)]       Behave as a filter.
  --recurse[=(yes|no)]      Recurse into directories supplied on command line [no].
  -R                        Equivalent to --recurse.
  -L <file>                 Read input file names from <file>; - means stdin.
  -f <tagfile>              Write tags to specified <tagfile>. Value of - writes to stdout.
  -o <tagfile>              Alternative for -f.

Output Format Options
  --format=(1|2)            Force output of specified tag file format [2].
  --output-format=(u-ctags|e-ctags|etags|xref|json)
  -x                        Print a tabular cross reference file to standard output.
  --sort=(yes|no|foldcase)  Should tags be sorted [yes]?
  -u                        Equivalent to --sort=no.

Language Selection and Mapping Options
  --language-force=(<language>|auto)
  --languages=[+|-](<list>|all)

Use --list-languages, --list-kinds=<LANG>, --list-fields for introspection."""


def parse_args(argv):
    opts = {"files": [], "tagfile": "tags", "stdout": False, "xref": False, "json": False,
            "recurse": False, "links": True, "format": 2, "sort": "yes", "append": False,
            "fields": set("fkst"), "force": None, "filter": False, "terminator": None,
            "maxdepth": None}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--help", "-h"):
            print(help_text()); sys.exit(0)
        if a == "--version":
            print("Universal Ctags 6.2.0(d922013)"); sys.exit(0)
        if a == "--list-languages":
            print("\n".join(LANGS)); sys.exit(0)
        if a.startswith("--list-kinds"):
            lang = a.split("=", 1)[1] if "=" in a else (argv[i+1] if i + 1 < len(argv) else "")
            if lang.upper() == "C":
                print("d  macro definitions\nf  function definitions\ng  enumeration names\nm  struct, and union members\ns  structure names\nt  typedefs\nu  union names\nv  variable definitions")
            elif lang.lower() == "python":
                print("c  classes\nf  functions\nm  class members\nv  variables")
            else:
                print("c  classes\nf  functions\nm  members\nv  variables")
            sys.exit(0)
        if a == "--list-fields":
            print("#LETTER NAME           ENABLED LANGUAGE         JSTYPE FIXED OP VER DESCRIPTION")
            print("N       name           yes     NONE             s--    yes   rw   0 tag name")
            print("F       input          yes     NONE             s--    yes   r-   0 input file")
            print("P       pattern        yes     NONE             s-b    yes   --   0 pattern")
            print("f       file           yes     NONE             --b    no    --   0 File-restricted scoping")
            print("k       NONE           yes     NONE             s--    no    --   0 Kind of tag in one-letter form")
            print("n       line           no      NONE             -i-    no    rw   0 Line number of tag definition")
            print("s       NONE           yes     NONE             s--    no    --   0 scope of tag definition")
            print("t       typeref        yes     NONE             s-b    no    -w   0 Type and name of a variable or typedef")
            sys.exit(0)
        if a in ("-f", "-o", "-L"):
            if i + 1 >= len(argv):
                print(f"executable: Missing parameter for {a} option", file=sys.stderr); sys.exit(1)
            val = argv[i+1]; i += 2
            if a == "-L":
                if val == "-":
                    opts["files"].extend([x.strip() for x in sys.stdin if x.strip()])
                else:
                    try:
                        with open(val) as f: opts["files"].extend([x.strip() for x in f if x.strip()])
                    except OSError as e:
                        print(f"executable: cannot open list file \"{val}\" : {e.strerror}", file=sys.stderr); sys.exit(1)
            else:
                opts["tagfile"] = val; opts["stdout"] = (val == "-")
            continue
        if a == "-x": opts["xref"] = True; opts["stdout"] = True; i += 1; continue
        if a == "-R" or a.startswith("--recurse"): opts["recurse"] = not a.endswith("=no"); i += 1; continue
        if a == "-u" or a == "--sort=no": opts["sort"] = "no"; i += 1; continue
        if a == "--sort=foldcase": opts["sort"] = "foldcase"; i += 1; continue
        if a.startswith("--sort="): opts["sort"] = a.split("=",1)[1]; i += 1; continue
        if a.startswith("--format="): opts["format"] = int(a.split("=",1)[1]); i += 1; continue
        if a.startswith("--output-format="):
            val = a.split("=",1)[1]; opts["json"] = (val == "json"); opts["xref"] = (val == "xref"); opts["stdout"] = opts["json"] or opts["xref"]; i += 1; continue
        if a == "-e": i += 1; continue
        if a in ("-a", "--append", "--append=yes"): opts["append"] = True; i += 1; continue
        if a.startswith("--fields="):
            spec = a.split("=",1)[1]
            if spec.startswith("+"): opts["fields"].update(spec[1:])
            elif spec.startswith("-"): opts["fields"].difference_update(spec[1:])
            else: opts["fields"] = set(spec)
            i += 1; continue
        if a.startswith("--language-force="): opts["force"] = a.split("=",1)[1]; i += 1; continue
        if a.startswith("--filter"):
            opts["filter"] = not a.endswith("=no"); opts["stdout"] = True; i += 1; continue
        if a.startswith("--filter-terminator="): opts["terminator"] = a.split("=",1)[1]; i += 1; continue
        if a.startswith("--links="): opts["links"] = not a.endswith("=no"); i += 1; continue
        if a.startswith("--maxdepth="):
            try: opts["maxdepth"] = int(a.split("=",1)[1])
            except ValueError: opts["maxdepth"] = None
            i += 1; continue
        if a.startswith("--exclude") or a.startswith("--languages") or a.startswith("--langmap") or a.startswith("--map-") or a.startswith("--alias-") or a.startswith("--extras") or a.startswith("--kinds") or a.startswith("--kinddef") or a.startswith("--regex"):
            i += 1; continue
        if a.startswith("-") and a != "-":
            print(f"executable: Unknown option: {a}", file=sys.stderr); sys.exit(1)
        opts["files"].append(a); i += 1
    return opts


def main(argv):
    opts = parse_args(argv)
    output_lines = []
    if opts["filter"]:
        for fname in [x.strip() for x in sys.stdin if x.strip()]:
            tags = parse_file(fname, opts["force"])
            if opts["sort"] == "yes": tags.sort(key=lambda t: render_tag(t, opts["format"], opts["fields"]))
            elif opts["sort"] == "foldcase": tags.sort(key=lambda t: render_tag(t, opts["format"], opts["fields"]).lower())
            output_lines.extend(render_tag(t, opts["format"], opts["fields"]) for t in tags)
            if opts["terminator"] is not None: output_lines.append(opts["terminator"])
    else:
        files = opts["files"] or []
        files = collect_files(files, opts["recurse"], opts["links"], opts["maxdepth"])
        tags = []
        for f in files:
            tags.extend(parse_file(f, opts["force"]))
        if opts["sort"] == "yes": tags.sort(key=lambda t: render_tag(t, opts["format"], opts["fields"]))
        elif opts["sort"] == "foldcase": tags.sort(key=lambda t: render_tag(t, opts["format"], opts["fields"]).lower())
        if opts["json"]:
            output_lines = [render_json(t, opts["fields"]) for t in tags]
        elif opts["xref"]:
            output_lines = [render_xref(t) for t in tags]
        else:
            if not opts["stdout"] and opts["format"] == 2:
                output_lines.extend(pseudo_tags(os.getcwd(), sorted(set(t.language for t in tags if t.language))))
            output_lines.extend(render_tag(t, opts["format"], opts["fields"]) for t in tags)
    data = "\n".join(output_lines) + ("\n" if output_lines else "")
    if opts["stdout"]:
        sys.stdout.write(data)
    else:
        mode = "a" if opts["append"] else "w"
        with open(opts["tagfile"], mode, encoding="utf-8") as f:
            f.write(data)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
