#!/usr/bin/env python3
import math
import os
import random
import re
import sys

VERSION = "pastel 0.11.0"

NAMES = {
"aliceblue":"#f0f8ff","antiquewhite":"#faebd7","aqua":"#00ffff","aquamarine":"#7fffd4","azure":"#f0ffff",
"beige":"#f5f5dc","bisque":"#ffe4c4","black":"#000000","blanchedalmond":"#ffebcd","blue":"#0000ff",
"blueviolet":"#8a2be2","brown":"#a52a2a","burlywood":"#deb887","cadetblue":"#5f9ea0","chartreuse":"#7fff00",
"chocolate":"#d2691e","coral":"#ff7f50","cornflowerblue":"#6495ed","cornsilk":"#fff8dc","crimson":"#dc143c",
"cyan":"#00ffff","darkblue":"#00008b","darkcyan":"#008b8b","darkgoldenrod":"#b8860b","darkgray":"#a9a9a9",
"darkgreen":"#006400","darkgrey":"#a9a9a9","darkkhaki":"#bdb76b","darkmagenta":"#8b008b","darkolivegreen":"#556b2f",
"darkorange":"#ff8c00","darkorchid":"#9932cc","darkred":"#8b0000","darksalmon":"#e9967a","darkseagreen":"#8fbc8f",
"darkslateblue":"#483d8b","darkslategray":"#2f4f4f","darkslategrey":"#2f4f4f","darkturquoise":"#00ced1","darkviolet":"#9400d3",
"deeppink":"#ff1493","deepskyblue":"#00bfff","dimgray":"#696969","dimgrey":"#696969","dodgerblue":"#1e90ff",
"firebrick":"#b22222","floralwhite":"#fffaf0","forestgreen":"#228b22","fuchsia":"#ff00ff","gainsboro":"#dcdcdc",
"ghostwhite":"#f8f8ff","gold":"#ffd700","goldenrod":"#daa520","gray":"#808080","green":"#008000",
"greenyellow":"#adff2f","grey":"#808080","honeydew":"#f0fff0","hotpink":"#ff69b4","indianred":"#cd5c5c",
"indigo":"#4b0082","ivory":"#fffff0","khaki":"#f0e68c","lavender":"#e6e6fa","lavenderblush":"#fff0f5",
"lawngreen":"#7cfc00","lemonchiffon":"#fffacd","lightblue":"#add8e6","lightcoral":"#f08080","lightcyan":"#e0ffff",
"lightgoldenrodyellow":"#fafad2","lightgray":"#d3d3d3","lightgreen":"#90ee90","lightgrey":"#d3d3d3","lightpink":"#ffb6c1",
"lightsalmon":"#ffa07a","lightseagreen":"#20b2aa","lightskyblue":"#87cefa","lightslategray":"#778899","lightslategrey":"#778899",
"lightsteelblue":"#b0c4de","lightyellow":"#ffffe0","lime":"#00ff00","limegreen":"#32cd32","linen":"#faf0e6",
"magenta":"#ff00ff","maroon":"#800000","mediumaquamarine":"#66cdaa","mediumblue":"#0000cd","mediumorchid":"#ba55d3",
"mediumpurple":"#9370db","mediumseagreen":"#3cb371","mediumslateblue":"#7b68ee","mediumspringgreen":"#00fa9a","mediumturquoise":"#48d1cc",
"mediumvioletred":"#c71585","midnightblue":"#191970","mintcream":"#f5fffa","mistyrose":"#ffe4e1","moccasin":"#ffe4b5",
"navajowhite":"#ffdead","navy":"#000080","oldlace":"#fdf5e6","olive":"#808000","olivedrab":"#6b8e23",
"orange":"#ffa500","orangered":"#ff4500","orchid":"#da70d6","palegoldenrod":"#eee8aa","palegreen":"#98fb98",
"paleturquoise":"#afeeee","palevioletred":"#db7093","papayawhip":"#ffefd5","peachpuff":"#ffdab9","peru":"#cd853f",
"pink":"#ffc0cb","plum":"#dda0dd","powderblue":"#b0e0e6","purple":"#800080","rebeccapurple":"#663399",
"red":"#ff0000","rosybrown":"#bc8f8f","royalblue":"#4169e1","saddlebrown":"#8b4513","salmon":"#fa8072",
"sandybrown":"#f4a460","seagreen":"#2e8b57","seashell":"#fff5ee","sienna":"#a0522d","silver":"#c0c0c0",
"skyblue":"#87ceeb","slateblue":"#6a5acd","slategray":"#708090","slategrey":"#708090","snow":"#fffafa",
"springgreen":"#00ff7f","steelblue":"#4682b4","tan":"#d2b48c","teal":"#008080","thistle":"#d8bfd8",
"tomato":"#ff6347","turquoise":"#40e0d0","violet":"#ee82ee","wheat":"#f5deb3","white":"#ffffff",
"whitesmoke":"#f5f5f5","yellow":"#ffff00","yellowgreen":"#9acd32","transparent":"#00000000"}

FORMATS = set("rgb rgb-float rgb-r rgb-g rgb-b hex hsl hsl-hue hsl-saturation hsl-lightness hsv hsv-hue hsv-saturation hsv-value lch lch-lightness lch-chroma lch-hue oklch oklch-lightness oklch-chroma oklch-hue lab lab-a lab-b oklab oklab-l oklab-a oklab-b luminance brightness ansi-8bit ansi-24bit ansi-8bit-value ansi-8bit-escapecode ansi-24bit-escapecode cmyk name".split())

def clamp(x,a=0.0,b=1.0): return max(a,min(b,x))
def rnd(x): return int(round(x))
def pct(v):
    s=v.strip()
    if s.endswith("%"): return float(s[:-1])/100.0
    return float(s)
def num_or_pct(v, scale=255.0):
    s=v.strip()
    if s.endswith("%"): return clamp(float(s[:-1])/100.0)*scale
    return float(s)
def alpha(v):
    s=v.strip()
    if s.endswith("%"): return clamp(float(s[:-1])/100.0)
    return clamp(float(s))

class Color:
    def __init__(self,r,g,b,a=1.0):
        self.r=int(clamp(round(r),0,255)); self.g=int(clamp(round(g),0,255)); self.b=int(clamp(round(b),0,255)); self.a=clamp(a)
    def tup(self): return (self.r,self.g,self.b)
    def hsl(self):
        r,g,b=[x/255 for x in self.tup()]
        mx,mn=max(r,g,b),min(r,g,b); l=(mx+mn)/2
        if mx==mn: return (0.0,0.0,l)
        d=mx-mn
        s=d/(2-mx-mn) if l>0.5 else d/(mx+mn)
        if mx==r: h=(g-b)/d+(6 if g<b else 0)
        elif mx==g: h=(b-r)/d+2
        else: h=(r-g)/d+4
        return ((h*60)%360,s,l)
    def hsv(self):
        r,g,b=[x/255 for x in self.tup()]
        mx,mn=max(r,g,b),min(r,g,b); d=mx-mn
        if d==0: h=0
        elif mx==r: h=60*(((g-b)/d)%6)
        elif mx==g: h=60*((b-r)/d+2)
        else: h=60*((r-g)/d+4)
        return (h,0 if mx==0 else d/mx,mx)

def hsl_to_rgb(h,s,l,a=1.0):
    h=(h%360)/360
    if s<=0: v=l*255; return Color(v,v,v,a)
    def hue(p,q,t):
        if t<0: t+=1
        if t>1: t-=1
        if t<1/6: return p+(q-p)*6*t
        if t<1/2: return q
        if t<2/3: return p+(q-p)*(2/3-t)*6
        return p
    q=l*(1+s) if l<0.5 else l+s-l*s; p=2*l-q
    return Color(hue(p,q,h+1/3)*255,hue(p,q,h)*255,hue(p,q,h-1/3)*255,a)

def hsv_to_rgb(h,s,v,a=1.0):
    c=v*s; x=c*(1-abs((h/60)%2-1)); m=v-c
    hp=(h%360)/60
    if hp<1: rr,gg,bb=c,x,0
    elif hp<2: rr,gg,bb=x,c,0
    elif hp<3: rr,gg,bb=0,c,x
    elif hp<4: rr,gg,bb=0,x,c
    elif hp<5: rr,gg,bb=x,0,c
    else: rr,gg,bb=c,0,x
    return Color((rr+m)*255,(gg+m)*255,(bb+m)*255,a)

def parse_color(s):
    s=s.strip()
    low=s.lower().replace(" ","")
    if low in NAMES: return parse_color(NAMES[low])
    if low.startswith("#"): low=low[1:]
    if re.fullmatch(r"[0-9a-f]{3,4}",low):
        vals=[int(ch*2,16) for ch in low]
        return Color(vals[0],vals[1],vals[2], vals[3]/255 if len(vals)==4 else 1)
    if re.fullmatch(r"[0-9a-f]{6}([0-9a-f]{2})?",low):
        vals=[int(low[i:i+2],16) for i in range(0,len(low),2)]
        return Color(vals[0],vals[1],vals[2], vals[3]/255 if len(vals)==4 else 1)
    m=re.fullmatch(r"(rgba?|RGBA?)\((.*)\)",s.strip())
    if m:
        p=[x.strip() for x in re.split(r"\s*,\s*",m.group(2))]
        if len(p) in (3,4): return Color(num_or_pct(p[0]),num_or_pct(p[1]),num_or_pct(p[2]),alpha(p[3]) if len(p)==4 else 1)
    m=re.fullmatch(r"(hsla?|HSLA?)\((.*)\)",s.strip())
    if m:
        p=[x.strip() for x in re.split(r"\s*,\s*",m.group(2))]
        if len(p) in (3,4): return hsl_to_rgb(float(p[0]), pct(p[1]), pct(p[2]), alpha(p[3]) if len(p)==4 else 1)
    m=re.fullmatch(r"(hsva?|HSVA?)\((.*)\)",s.strip())
    if m:
        p=[x.strip() for x in re.split(r"\s*,\s*",m.group(2))]
        if len(p) in (3,4): return hsv_to_rgb(float(p[0]), pct(p[1]), pct(p[2]), alpha(p[3]) if len(p)==4 else 1)
    m=re.fullmatch(r"gray\((.*)\)",low)
    if m:
        v=pct(m.group(1)); return hsl_to_rgb(0,0,v)
    if "," in s:
        p=[x.strip() for x in s.split(",")]
        if len(p) in (3,4): return Color(num_or_pct(p[0]),num_or_pct(p[1]),num_or_pct(p[2]),alpha(p[3]) if len(p)==4 else 1)
    raise ValueError(s)

def srgb_lin(x):
    x=x/255
    return x/12.92 if x<=0.04045 else ((x+0.055)/1.055)**2.4
def lin_srgb(x):
    x=max(0,x)
    v=12.92*x if x<=0.0031308 else 1.055*(x**(1/2.4))-0.055
    return clamp(v)*255
def luminance(c):
    return 0.2126*srgb_lin(c.r)+0.7152*srgb_lin(c.g)+0.0722*srgb_lin(c.b)
def brightness(c): return (0.299*c.r+0.587*c.g+0.114*c.b)/255

def xyz(c):
    r,g,b=srgb_lin(c.r),srgb_lin(c.g),srgb_lin(c.b)
    return (0.4124564*r+0.3575761*g+0.1804375*b, 0.2126729*r+0.7151522*g+0.0721750*b, 0.0193339*r+0.1191920*g+0.9503041*b)
def lab(c):
    x,y,z=xyz(c); xn,yn,zn=0.95047,1.0,1.08883
    def f(t): return t**(1/3) if t>0.008856 else 7.787*t+16/116
    fx,fy,fz=f(x/xn),f(y/yn),f(z/zn)
    return (116*fy-16,500*(fx-fy),200*(fy-fz))
def lch(c):
    L,a,b=lab(c); C=math.hypot(a,b); H=(math.degrees(math.atan2(b,a))%360)
    return (L,C,H)
def oklab(c):
    r,g,b=srgb_lin(c.r),srgb_lin(c.g),srgb_lin(c.b)
    l=0.4122214708*r+0.5363325363*g+0.0514459929*b
    m=0.2119034982*r+0.6806995451*g+0.1073969566*b
    s=0.0883024619*r+0.2817188376*g+0.6299787005*b
    l_,m_,s_=l**(1/3),m**(1/3),s**(1/3)
    return (0.2104542553*l_+0.7936177850*m_-0.0040720468*s_, 1.9779984951*l_-2.4285922050*m_+0.4505937099*s_, 0.0259040371*l_+0.7827717662*m_-0.8086757660*s_)
def oklch(c):
    L,a,b=oklab(c); return (L, math.hypot(a,b), math.degrees(math.atan2(b,a))%360)

def ansi8(c):
    if c.r==c.g==c.b:
        if c.r<8: return 16
        if c.r>248: return 231
        return round(((c.r-8)/247)*24)+232
    return 16+36*round(c.r/255*5)+6*round(c.g/255*5)+round(c.b/255*5)

def fmt_hsl(c, compact=False):
    h,s,l=c.hsl()
    base=f"hsl({round(h)},{s*100:.1f}%,{l*100:.1f}%)" if compact else f"hsl({round(h)}, {s*100:.1f}%, {l*100:.1f}%)"
    if c.a<0.999:
        base=f"hsla({round(h)},{s*100:.1f}%,{l*100:.1f}%,{c.a:.3g})" if compact else f"hsla({round(h)}, {s*100:.1f}%, {l*100:.1f}%, {c.a:.3g})"
    return base
def fmt_hex(c):
    return f"#{c.r:02x}{c.g:02x}{c.b:02x}" + (f"{round(c.a*255):02x}" if c.a<0.999 else "")
def fmt_color(c, typ="hex", compact=False):
    h,s,l=c.hsl(); hh,ss,v=c.hsv()
    if typ=="hex": return fmt_hex(c)
    if typ=="rgb": return f"rgba({c.r}, {c.g}, {c.b}, {c.a:.3g})" if c.a<0.999 else f"rgb({c.r}, {c.g}, {c.b})"
    if typ=="rgb-float": return f"rgba({c.r/255:.3f}, {c.g/255:.3f}, {c.b/255:.3f}, {c.a:.3g})" if c.a<0.999 else f"rgb({c.r/255:.3f}, {c.g/255:.3f}, {c.b/255:.3f})"
    if typ=="rgb-r": return str(c.r)
    if typ=="rgb-g": return str(c.g)
    if typ=="rgb-b": return str(c.b)
    if typ=="hsl": return fmt_hsl(c, compact)
    if typ=="hsl-hue": return str(round(h))
    if typ=="hsl-saturation": return f"{s:.4f}"
    if typ=="hsl-lightness": return f"{l:.4f}"
    if typ=="hsv": return f"hsv({round(hh)}, {ss*100:.1f}%, {v*100:.1f}%)"
    if typ=="hsv-hue": return str(round(hh))
    if typ=="hsv-saturation": return f"{ss:.4f}"
    if typ=="hsv-value": return f"{v:.4f}"
    if typ=="luminance": return f"{luminance(c):.3f}"
    if typ=="brightness": return f"{brightness(c):.3f}"
    if typ=="lab":
        L,a,b=lab(c); return f"Lab({round(L)}, {round(a)}, {round(b)})"
    if typ=="lab-a": return f"{lab(c)[1]:.4f}"
    if typ=="lab-b": return f"{lab(c)[2]:.4f}"
    if typ=="lch":
        L,C,H=lch(c); return f"LCh({round(L)}, {round(C)}, {round(H)})"
    if typ=="lch-lightness": return f"{lch(c)[0]:.4f}"
    if typ=="lch-chroma": return f"{lch(c)[1]:.4f}"
    if typ=="lch-hue": return f"{lch(c)[2]:.4f}"
    if typ=="oklab":
        L,a,b=oklab(c); return f"OkLab({L:.4f}, {a:.4f}, {b:.4f})"
    if typ=="oklab-l": return f"{oklab(c)[0]:.4f}"
    if typ=="oklab-a": return f"{oklab(c)[1]:.4f}"
    if typ=="oklab-b": return f"{oklab(c)[2]:.4f}"
    if typ=="oklch":
        L,C,H=oklch(c); return f"OkLCh({L:.4f}, {C:.4f}, {H:.4f})"
    if typ=="oklch-lightness": return f"{oklch(c)[0]:.4f}"
    if typ=="oklch-chroma": return f"{oklch(c)[1]:.4f}"
    if typ=="oklch-hue": return f"{oklch(c)[2]:.4f}"
    if typ=="ansi-8bit-value": return str(ansi8(c))
    if typ=="ansi-8bit-escapecode": return f"\033[38;5;{ansi8(c)}m"
    if typ=="ansi-24bit-escapecode": return f"\033[38;2;{c.r};{c.g};{c.b}m"
    if typ=="ansi-8bit": return f"\033[38;5;{ansi8(c)}m{fmt_hex(c)}\033[0m"
    if typ=="ansi-24bit": return f"\033[38;2;{c.r};{c.g};{c.b}m{fmt_hex(c)}\033[0m"
    if typ=="cmyk":
        r,g,b=[x/255 for x in c.tup()]; k=1-max(r,g,b)
        if k>=1: cc=mm=yy=0
        else: cc=(1-r-k)/(1-k); mm=(1-g-k)/(1-k); yy=(1-b-k)/(1-k)
        return f"cmyk({round(cc*100)}, {round(mm*100)}, {round(yy*100)}, {round(k*100)})"
    if typ=="name":
        hx=fmt_hex(c)[:7]
        for n,hx2 in NAMES.items():
            if hx2[:7]==hx and n!="transparent": return n
        return hx
    return fmt_hex(c)

def read_colors(args):
    vals=[]
    if args:
        for a in args:
            if a=="-": vals += [x.strip() for x in sys.stdin if x.strip()]
            elif a=="pick": error("No color picker found")
            else: vals.append(a)
    else:
        vals=[x.strip() for x in sys.stdin if x.strip()]
    out=[]
    for v in vals:
        try: out.append(parse_color(v))
        except Exception: error(f"Could not parse color '{v}'")
    return out
def error(msg, code=1):
    print(f"[pastel error]: {msg}", file=sys.stderr)
    sys.exit(code)
def parse_float(s):
    try: return float(s)
    except Exception: error(f"Could not parse number '{s}'")

def print_colors(colors, typ="hsl", compact=True):
    for c in colors: print(fmt_color(c,typ,compact))
def print_hsl_values(vals):
    for h,s,l,a in vals:
        if a<0.999:
            print(f"hsla({round(h)%360},{s*100:.1f}%,{l*100:.1f}%,{a:.3g})")
        else:
            print(f"hsl({round(h)%360},{s*100:.1f}%,{l*100:.1f}%)")

def cmd_format(args):
    typ="hex"
    if args and args[0] in FORMATS:
        typ=args[0]; args=args[1:]
    elif args:
        print(f"error: invalid value '{args[0]}' for '[type]'", file=sys.stderr); sys.exit(2)
    print_colors(read_colors(args), typ, False)

def transform(args, kind):
    if kind in ("lighten","darken","saturate","desaturate","rotate"):
        if not args: error("Missing argument")
        amount=parse_float(args[0]); cols=read_colors(args[1:])
    else:
        amount=180; cols=read_colors(args)
    out=[]
    for c in cols:
        h,s,l=c.hsl()
        if kind=="lighten": l=clamp(l+amount)
        elif kind=="darken": l=clamp(l-amount)
        elif kind=="saturate": s=clamp(s+amount)
        elif kind=="desaturate": s=clamp(s-amount)
        elif kind in ("rotate","complement"): h=(h+amount)%360
        out.append((h,s,l,c.a))
    print_hsl_values(out)

def cmd_gray(args):
    if not args: error("Missing lightness")
    print_hsl_values([(0,0,clamp(parse_float(args[0])),1)])
def cmd_textcolor(args):
    out=[]
    for c in read_colors(args):
        out.append(Color(0,0,0) if luminance(c)>0.179 else Color(255,255,255))
    print_colors(out)
def cmd_togray(args):
    out=[]
    for c in read_colors(args):
        target=luminance(c)
        lo,hi=0,1
        for _ in range(32):
            mid=(lo+hi)/2
            if luminance(hsl_to_rgb(0,0,mid))<target: lo=mid
            else: hi=mid
        out.append(hsl_to_rgb(0,0,(lo+hi)/2,c.a))
    print_colors(out)

def mix_rgb(a,b,f): return Color(a.r*f+b.r*(1-f), a.g*f+b.g*(1-f), a.b*f+b.b*(1-f), a.a*f+b.a*(1-f))
def cmd_mix(args):
    frac=0.5; space="Lab"; i=0
    rest=[]
    while i<len(args):
        if args[i] in ("-f","--fraction"): frac=parse_float(args[i+1]); i+=2
        elif args[i].startswith("--fraction="): frac=parse_float(args[i].split("=",1)[1]); i+=1
        elif args[i] in ("-s","--colorspace"): space=args[i+1]; i+=2
        elif args[i].startswith("--colorspace="): space=args[i].split("=",1)[1]; i+=1
        else: rest.append(args[i]); i+=1
    if not rest: error("Missing color")
    base=parse_color(rest[0]); others=read_colors(rest[1:])
    if not others: others=read_colors([])
    print_colors([mix_rgb(base,c,frac) for c in others])

def cmd_gradient(args):
    n=10; rest=[]; i=0
    while i<len(args):
        if args[i] in ("-n","--number"): n=int(parse_float(args[i+1])); i+=2
        elif args[i].startswith("--number="): n=int(parse_float(args[i].split("=",1)[1])); i+=1
        elif args[i] in ("-s","--colorspace"): i+=2
        elif args[i].startswith("--colorspace="): i+=1
        else: rest.append(args[i]); i+=1
    stops=read_colors(rest)
    if len(stops)<2: error("At least two colors required")
    out=[]
    for k in range(n):
        t=0 if n==1 else k/(n-1); seg=min(int(t*(len(stops)-1)),len(stops)-2); local=t*(len(stops)-1)-seg
        out.append(mix_rgb(stops[seg],stops[seg+1],1-local))
    print_colors(out)

def cmd_set(args):
    if len(args)<2: error("Missing argument")
    prop,val=args[0],parse_float(args[1]); out=[]
    for c in read_colors(args[2:]):
        h,s,l=c.hsl(); r,g,b,a=c.r,c.g,c.b,c.a
        if prop in ("red","green","blue"):
            if prop=="red": r=val
            if prop=="green": g=val
            if prop=="blue": b=val
            out.append(Color(r,g,b,a))
        elif prop=="alpha": out.append(Color(r,g,b,val))
        elif prop in ("hue","hsl-hue"): out.append(hsl_to_rgb(val,s,l,a))
        elif prop in ("hsl-saturation",): out.append(hsl_to_rgb(h,clamp(val),l,a))
        elif prop in ("lightness","hsl-lightness"): out.append(hsl_to_rgb(h,s,clamp(val),a))
        else: out.append(c)
    print_colors(out)

def cmd_sort(args):
    rev=False; uniq=False; order="hue"; rest=[]
    for a in args:
        if a in ("-r","--reverse"): rev=True
        elif a in ("-u","--unique"): uniq=True
        elif a in ("brightness","luminance","hue","chroma","random"): order=a
        else: rest.append(a)
    cols=read_colors(rest)
    if uniq:
        seen=set(); tmp=[]
        for c in cols:
            if c.tup() not in seen: seen.add(c.tup()); tmp.append(c)
        cols=tmp
    if order=="brightness": key=brightness
    elif order=="luminance": key=luminance
    elif order=="chroma": key=lambda c:lch(c)[1]
    elif order=="random": random.shuffle(cols); key=None
    else: key=lambda c:c.hsl()[0]
    if key: cols=sorted(cols,key=key, reverse=rev)
    elif rev: cols=list(reversed(cols))
    print_colors(cols)

def cmd_list(args):
    order="hue"; i=0
    while i<len(args):
        if args[i] in ("-s","--sort"): order=args[i+1]; i+=2
        elif args[i].startswith("--sort="): order=args[i].split("=",1)[1]; i+=1
        else: i+=1
    cols=[(n,parse_color(h)) for n,h in NAMES.items() if n!="transparent"]
    if order=="brightness": cols.sort(key=lambda x:brightness(x[1]))
    elif order=="luminance": cols.sort(key=lambda x:luminance(x[1]))
    elif order=="chroma": cols.sort(key=lambda x:lch(x[1])[1])
    elif order=="random": random.shuffle(cols)
    else: cols.sort(key=lambda x:x[1].hsl()[0])
    for n,c in cols: print(n)

def cmd_random(args):
    n=10; strat="vivid"; i=0
    while i<len(args):
        if args[i] in ("-n","--number"): n=int(parse_float(args[i+1])); i+=2
        elif args[i].startswith("--number="): n=int(parse_float(args[i].split("=",1)[1])); i+=1
        elif args[i] in ("-s","--strategy"): strat=args[i+1]; i+=2
        elif args[i].startswith("--strategy="): strat=args[i].split("=",1)[1]; i+=1
        else: i+=1
    out=[]
    for _ in range(n):
        if strat=="gray": out.append(hsl_to_rgb(0,0,random.random()))
        elif strat=="rgb": out.append(Color(random.randrange(256),random.randrange(256),random.randrange(256)))
        elif strat=="lch_hue": out.append(hsl_to_rgb(random.random()*360,0.45,0.68))
        else: out.append(hsl_to_rgb(random.random()*360,0.3+random.random()*0.6,0.35+random.random()*0.35))
    print_colors(out)

def cmd_distinct(args):
    n=10
    if args and re.fullmatch(r"\d+",args[0]): n=int(args[0])
    base=[Color(0,0,0),Color(255,255,255),Color(255,0,0),Color(0,255,0),Color(0,0,255),Color(255,255,0),Color(255,0,255),Color(0,255,255)]
    out=(base*((n+len(base)-1)//len(base)))[:n]
    print_colors(out)

def cmd_paint(args):
    bg=None; bold=ital=under=False; newline=True; rest=[]; i=0
    while i<len(args):
        a=args[i]
        if a in ("-o","--on"): bg=parse_color(args[i+1]); i+=2
        elif a=="--on" or a.startswith("--on="): bg=parse_color(a.split("=",1)[1]); i+=1
        elif a in ("-b","--bold"): bold=True; i+=1
        elif a in ("-i","--italic"): ital=True; i+=1
        elif a in ("-u","--underline"): under=True; i+=1
        elif a in ("-n","--no-newline"): newline=False; i+=1
        else: rest.append(a); i+=1
    if not rest: error("Missing color")
    fg=parse_color(sys.stdin.readline().strip()) if rest[0]=="-" else parse_color(rest[0])
    text=" ".join(rest[1:]) if len(rest)>1 else sys.stdin.read()
    codes=[]
    if bold: codes.append("1")
    if ital: codes.append("3")
    if under: codes.append("4")
    codes.append(f"38;2;{fg.r};{fg.g};{fg.b}")
    if bg: codes.append(f"48;2;{bg.r};{bg.g};{bg.b}")
    sys.stdout.write("\033["+";".join(codes)+"m"+text+"\033[0m")
    if newline: sys.stdout.write("\n")

HELP = """A command-line tool to generate, analyze, convert and manipulate colors

Usage: executable [OPTIONS] <COMMAND>

Commands:
  color       Display information about the given color
  colorblind  Simulate a color under a certain colorblindness profile
  colorcheck  Check if your terminal emulator supports 24-bit colors.
  complement  Get the complementary color (hue rotated by 180°)
  darken      Darken color by a specified amount
  desaturate  Decrease color saturation by a specified amount
  distinct    Generate a set of visually distinct colors
  format      Convert a color to the given format
  gradient    Generate an interpolating sequence of colors
  gray        Create a gray tone from a given lightness
  help        Print this message or the help of the given subcommand(s)
  lighten     Lighten color by a specified amount
  list        Show a list of available color names
  mix         Mix two colors in the given colorspace
  paint       Print colored text using ANSI escape sequences
  pick        Interactively pick a color from the screen (pipette)
  random      Generate a list of random colors
  rotate      Rotate the hue channel by the specified angle
  saturate    Increase color saturation by a specified amount
  set         Set a color property to a specific value
  sort-by     Sort colors by the given property
  textcolor   Get a readable text color for the given background color
  to-gray     Completely desaturate a color (preserving luminance)

Options:
  -h, --help                         Print help
  -V, --version                      Print version"""

def colorblind(args):
    if not args: error("Missing type")
    mats={
      "prot":((0.567,0.433,0),(0.558,0.442,0),(0,0.242,0.758)),
      "deuter":((0.625,0.375,0),(0.7,0.3,0),(0,0.3,0.7)),
      "trit":((0.95,0.05,0),(0,0.433,0.567),(0,0.475,0.525))}
    m=mats.get(args[0]); 
    if not m: error(f"Invalid colorblindness type '{args[0]}'")
    out=[]
    for c in read_colors(args[1:]):
        out.append(Color(c.r*m[0][0]+c.g*m[0][1]+c.b*m[0][2], c.r*m[1][0]+c.g*m[1][1]+c.b*m[1][2], c.r*m[2][0]+c.g*m[2][1]+c.b*m[2][2], c.a))
    print_colors(out)

def main(argv):
    args=list(argv)
    while args and args[0] in ("-f","--force-color","--color-mode","-m","--color-picker"):
        if args[0] in ("--color-mode","-m","--color-picker"): args=args[2:]
        else: args=args[1:]
    if args and (args[0].startswith("--color-mode=") or args[0].startswith("--color-picker=")): args=args[1:]
    if not args or args[0] in ("-h","--help","help"):
        if args and args[0]=="help" and len(args)>1:
            os.execv(sys.argv[0],[sys.argv[0],args[1],"--help"])
        print(HELP); return
    if args[0] in ("-V","--version"): print(VERSION); return
    cmd=args[0]; rest=args[1:]
    if rest and rest[0] in ("-h","--help"):
        print(HELP); return
    if cmd=="format": cmd_format(rest)
    elif cmd=="color": print_colors(read_colors(rest))
    elif cmd in ("lighten","darken","saturate","desaturate","rotate","complement"): transform(rest,cmd)
    elif cmd=="gray": cmd_gray(rest)
    elif cmd=="textcolor": cmd_textcolor(rest)
    elif cmd=="to-gray": cmd_togray(rest)
    elif cmd=="mix": cmd_mix(rest)
    elif cmd=="gradient": cmd_gradient(rest)
    elif cmd=="set": cmd_set(rest)
    elif cmd=="sort-by": cmd_sort(rest)
    elif cmd=="list": cmd_list(rest)
    elif cmd=="random": cmd_random(rest)
    elif cmd=="distinct": cmd_distinct(rest)
    elif cmd=="paint": cmd_paint(rest)
    elif cmd=="colorblind": colorblind(rest)
    elif cmd=="colorcheck":
        print("24-bit color test:"); print("\033[48;2;73;39;50m  \033[48;2;16;51;30m  \033[48;2;29;54;90m  \033[0m")
    elif cmd=="pick": error("No color picker found")
    else:
        print(HELP); sys.exit(2)
if __name__=="__main__":
    main(sys.argv[1:])
