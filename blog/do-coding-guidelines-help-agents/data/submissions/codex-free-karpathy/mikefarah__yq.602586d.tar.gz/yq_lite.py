#!/usr/bin/env python3
import sys, os, json, re, csv, base64, urllib.parse, xml.etree.ElementTree as ET
from io import StringIO
try:
    import tomli
except Exception:
    tomli = None

VERSION='yq (https://github.com/mikefarah/yq/) version v4.52.5'
HELP='''yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) 
See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

Usage:
  yq [flags]
  yq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  eval        (default) Apply the expression to each document in each yaml file in sequence
  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
  help        Help about any command

Flags:
  -e, --exit-status                       set exit status if there are no matches or null or false is returned
      --expression string                 forcibly set the expression argument.
      --from-file string                  Load expression from specified file.
  -h, --help                              help for yq
  -I, --indent int                        sets indent level for output (default 2)
  -i, --inplace                           update the file in place of first file given.
  -p, --input-format string               parse format for input. (default "auto")
  -M, --no-colors                         force print with no colors
  -N, --no-doc                            Don't print document separators (---)
  -n, --null-input                        Don't read input, simply evaluate the expression given.
  -o, --output-format string              output format type. (default "auto")
  -P, --prettyPrint                       pretty print
  -r, --unwrapScalar                      unwrap scalar (default true)
  -v, --verbose                           verbose mode
  -V, --version                           Print version information and quit
'''

def strip_comments(s):
    out=[]
    for line in s.splitlines():
        inq=None; esc=False; cut=len(line)
        for i,ch in enumerate(line):
            if esc: esc=False; continue
            if ch=='\\': esc=True; continue
            if ch in ('"',"'"):
                inq = None if inq==ch else (ch if inq is None else inq)
            elif ch=='#' and inq is None and (i==0 or line[i-1].isspace()):
                cut=i; break
        out.append(line[:cut].rstrip())
    return '\n'.join(out)

def parse_scalar(v):
    v=v.strip()
    if v=='': return ''
    if v in ('null','Null','NULL','~'): return None
    if v in ('true','True','TRUE'): return True
    if v in ('false','False','FALSE'): return False
    if (v[0:1]==v[-1:] and v[:1] in ('"',"'")):
        if v[0]=='"':
            try: return json.loads(v)
            except Exception: return v[1:-1]
        return v[1:-1].replace("''", "'")
    if v.startswith('[') or v.startswith('{'):
        try: return json.loads(v)
        except Exception: pass
    try:
        if re.match(r'^[+-]?0[0-9]+$', v): return v
        return int(v)
    except Exception: pass
    try:
        return float(v)
    except Exception: return v

def parse_yaml(text):
    text=strip_comments(text).replace('\t','  ')
    docs=re.split(r'(?m)^---\s*$', text)
    if len(docs)>1:
        vals=[parse_yaml_doc(d) for d in docs if d.strip()]
        return vals[0] if len(vals)==1 else vals
    return parse_yaml_doc(text)

def parse_yaml_doc(text):
    lines=[l.rstrip('\n') for l in text.splitlines() if l.strip() and not l.lstrip().startswith('...')]
    if not lines: return None
    def indent(l): return len(l)-len(l.lstrip(' '))
    def parse_block(i, ind):
        if i>=len(lines): return None,i
        if lines[i].lstrip().startswith('- '):
            arr=[]
            while i<len(lines) and indent(lines[i])==ind and lines[i].lstrip().startswith('- '):
                rest=lines[i].lstrip()[2:].strip(); i+=1
                if rest=='':
                    val,i=parse_block(i, ind+2)
                elif re.match(r'^[^:\[\{][^:]*:\s*', rest):
                    key, valtxt=rest.split(':',1); m={}
                    if valtxt.strip(): m[key.strip()]=parse_scalar(valtxt)
                    else:
                        val,i=parse_block(i, ind+2); m[key.strip()]=val
                    while i<len(lines) and indent(lines[i])>=ind+2 and not (indent(lines[i])==ind and lines[i].lstrip().startswith('- ')):
                        if indent(lines[i])==ind+2 and ':' in lines[i].strip():
                            k,vt=lines[i].strip().split(':',1); i+=1
                            if vt.strip(): m[k.strip()]=parse_scalar(vt)
                            else:
                                val,i=parse_block(i, ind+4); m[k.strip()]=val
                        else: break
                    val=m
                else: val=parse_scalar(rest)
                arr.append(val)
            return arr,i
        mp={}
        while i<len(lines) and indent(lines[i])==ind and ':' in lines[i].strip():
            k,vt=lines[i].strip().split(':',1); k=k.strip().strip('"\'') ; i+=1
            if vt.strip(): mp[k]=parse_scalar(vt)
            else:
                val,i=parse_block(i, ind+2); mp[k]=val
        if mp: return mp,i
        return parse_scalar(lines[i].strip()), i+1
    val,_=parse_block(0, indent(lines[0]))
    return val

def yaml_scalar(v):
    if v is None: return 'null'
    if v is True: return 'true'
    if v is False: return 'false'
    if isinstance(v,(int,float)): return str(v)
    s=str(v)
    if s=='' or s.strip()!=s or s.lower() in ('null','true','false','~') or any(c in s for c in ':#{}[],&*?|<>!%@`'):
        return json.dumps(s)
    return s

def dump_yaml(v, indent=0, step=2):
    sp=' '*indent
    if isinstance(v, dict):
        if not v: return '{}\n' if indent==0 else '{}'
        lines=[]
        for k,val in v.items():
            key=str(k)
            if isinstance(val,(dict,list)) and val:
                lines.append(f'{sp}{key}:')
                lines.append(dump_yaml(val, indent+step, step).rstrip('\n'))
            else:
                lines.append(f'{sp}{key}: {dump_yaml(val,0,step).strip() if isinstance(val,(dict,list)) else yaml_scalar(val)}')
        return '\n'.join(lines)+'\n'
    if isinstance(v, list):
        if not v: return '[]\n' if indent==0 else '[]'
        lines=[]
        for item in v:
            if isinstance(item, dict) and item:
                first=True
                for k,val in item.items():
                    if first:
                        if isinstance(val,(dict,list)) and val:
                            lines.append(f'{sp}- {k}:')
                            lines.append(dump_yaml(val, indent+step*2, step).rstrip('\n'))
                        else:
                            lines.append(f'{sp}- {k}: {dump_yaml(val,0,step).strip() if isinstance(val,(dict,list)) else yaml_scalar(val)}')
                        first=False
                    else:
                        if isinstance(val,(dict,list)) and val:
                            lines.append(f'{sp}{" "*step}{k}:')
                            lines.append(dump_yaml(val, indent+step*2, step).rstrip('\n'))
                        else:
                            lines.append(f'{sp}{" "*step}{k}: {dump_yaml(val,0,step).strip() if isinstance(val,(dict,list)) else yaml_scalar(val)}')
            elif isinstance(item,(dict,list)) and item:
                lines.append(f'{sp}-')
                lines.append(dump_yaml(item, indent+step, step).rstrip('\n'))
            else:
                lines.append(f'{sp}- {dump_yaml(item,0,step).strip() if isinstance(item,(dict,list)) else yaml_scalar(item)}')
        return '\n'.join(lines)+'\n'
    return yaml_scalar(v)+'\n'

def detect_format(path, forced):
    if forced and forced not in ('auto','a'): return normfmt(forced)
    ext=os.path.splitext(path or '')[1].lower()
    return {'.json':'json','.xml':'xml','.csv':'csv','.tsv':'tsv','.toml':'toml','.properties':'props','.props':'props','.ini':'ini'}.get(ext,'yaml')

def normfmt(f):
    return {'y':'yaml','j':'json','x':'xml','p':'props','c':'csv','t':'tsv','s':'shell','l':'lua','i':'ini','h':'hcl','a':'auto'}.get(f,f)

def parse_input(text, fmt):
    fmt=normfmt(fmt)
    if fmt=='json': return json.loads(text) if text.strip() else None
    if fmt=='xml': return elem_to_obj(ET.fromstring(text)) if text.strip() else None
    if fmt in ('csv','tsv'):
        sep='\t' if fmt=='tsv' else ','; rows=list(csv.reader(StringIO(text), delimiter=sep))
        if not rows: return []
        hdr=rows[0]; return [dict(zip(hdr,[parse_scalar(x) for x in r])) for r in rows[1:]]
    if fmt in ('props','properties','ini'):
        d={}
        for line in text.splitlines():
            line=line.strip()
            if not line or line[0] in '#;[': continue
            if '=' in line: k,v=line.split('=',1)
            elif ':' in line: k,v=line.split(':',1)
            else: continue
            set_path(d, parse_path('.'+k.strip().replace('.', '.')), parse_scalar(v.strip()))
        return d
    if fmt=='toml' and tomli: return tomli.loads(text)
    if fmt=='base64': return base64.b64decode(text.strip()).decode()
    if fmt=='uri': return urllib.parse.unquote(text.strip())
    return parse_yaml(text)

def elem_value(e):
    d={}
    for k,v in e.attrib.items(): d['+@'+k]=v
    children=list(e); text=(e.text or '').strip()
    for c in children:
        val=elem_value(c)
        if c.tag in d:
            if not isinstance(d[c.tag], list): d[c.tag]=[d[c.tag]]
            d[c.tag].append(val)
        else: d[c.tag]=val
    if children:
        if text: d['+content']=text
        return d
    if d:
        if text: d['+content']=text
        return d
    return text

def elem_to_obj(e):
    return {e.tag: elem_value(e)}

def parse_path(expr):
    s=expr.strip();
    if s.startswith('.'): s=s[1:]
    toks=[]; i=0
    while i<len(s):
        if s[i]=='.': i+=1; continue
        if s[i]=='[':
            j=s.find(']',i); content=s[i+1:j]
            toks.append(None if content=='' else int(content.strip('"\''))) ; i=j+1; continue
        m=re.match(r'[A-Za-z0-9_+@-]+', s[i:])
        if m: toks.append(m.group(0)); i+=len(m.group(0)); continue
        i+=1
    return toks

def get_path(obj,toks):
    vals=[obj]
    for t in toks:
        out=[]
        for v in vals:
            if t is None:
                if isinstance(v,list): out.extend(v)
            elif isinstance(t,int):
                if isinstance(v,list) and -len(v)<=t<len(v): out.append(v[t])
                else: out.append(None)
            else:
                if isinstance(v,dict): out.append(v.get(t))
                else: out.append(None)
        vals=out
    return vals if any(t is None for t in toks) else (vals[0] if vals else None)

def set_path(obj,toks,val):
    if obj is None: obj={}
    cur=obj
    for idx,t in enumerate(toks):
        last=idx==len(toks)-1
        if isinstance(t,int):
            if not isinstance(cur,list): return obj
            while len(cur)<=t: cur.append({})
            if last: cur[t]=val
            else:
                if cur[t] is None: cur[t]={}
                cur=cur[t]
        else:
            if not isinstance(cur,dict): return obj
            if last: cur[t]=val
            else:
                nt=toks[idx+1]; default=[] if isinstance(nt,int) else {}
                if t not in cur or cur[t] is None: cur[t]=default
                cur=cur[t]
    return obj

def parse_value(s):
    s=s.strip()
    if s.startswith('strenv(') and s.endswith(')'):
        return os.environ.get(s[7:-1], '')
    if s.startswith('env(') and s.endswith(')'):
        return parse_scalar(os.environ.get(s[4:-1], ''))
    return parse_scalar(s)

def merge(a,b):
    if isinstance(a,dict) and isinstance(b,dict):
        r=dict(a)
        for k,v in b.items(): r[k]=merge(r[k],v) if k in r else v
        return r
    return b

def eval_expr(expr, data, all_docs=None):
    expr=expr.strip()
    if expr in ('','.') : return data
    if expr.startswith('load('):
        parts=[p.strip() for p in expr.split('*')]
        val=None
        for p in parts:
            m=re.match(r'load\(["\'](.+?)["\']\)', p)
            if m:
                path=m.group(1); txt=open(path).read(); d=parse_input(txt, detect_format(path,'auto'))
                val=d if val is None else merge(val,d)
        return val
    if 'ireduce' in expr and all_docs is not None:
        val={}
        for d in all_docs: val=merge(val,d)
        return val
    m=re.match(r'^(.+?)\s*\|\s*select\((.+)\)$', expr)
    if m:
        seq=eval_expr(m.group(1), data, all_docs); cond=m.group(2); out=[]
        for item in (seq if isinstance(seq,list) else [seq]):
            if truth(eval_cond(cond,item)): out.append(item)
        return out
    if expr.startswith('[') and expr.endswith(']'):
        inner=expr[1:-1].strip()
        res=eval_expr(inner, data, all_docs)
        return res if isinstance(res,list) else ([] if res is None else [res])
    am=re.match(r'^(.+?)\s*(?<![=!<>])=(?!=)\s*(.+)$', expr)
    if am:
        base={} if data is None else data
        set_path(base, parse_path(am.group(1)), parse_value(am.group(2)))
        return base
    if '|' in expr:
        cur=data
        for part in [p for p in expr.split('|') if p.strip()]: cur=eval_expr(part, cur, all_docs)
        return cur
    if expr.startswith('select(') and expr.endswith(')'):
        return data if truth(eval_cond(expr[7:-1],data)) else None
    if expr.startswith('has('):
        k=expr[4:-1].strip().strip('"\'')
        return isinstance(data,dict) and k in data
    if expr=='keys': return list(data.keys()) if isinstance(data,dict) else list(range(len(data))) if isinstance(data,list) else []
    if expr=='length': return len(data) if data is not None and hasattr(data,'__len__') else 0
    if expr.startswith('.'): return get_path(data, parse_path(expr))
    return data

def eval_cond(cond,item):
    for op in ['==','!=']:
        if op in cond:
            l,r=cond.split(op,1); lv=eval_expr(l.strip(), item); rv=parse_value(r.strip())
            return (lv==rv) if op=='==' else (lv!=rv)
    return eval_expr(cond,item)

def truth(v): return not (v is None or v is False or v==[])

def flatten_props(v,prefix=''):
    out=[]
    if isinstance(v,dict):
        for k,val in v.items(): out+=flatten_props(val, f'{prefix}.{k}' if prefix else str(k))
    elif isinstance(v,list):
        for i,val in enumerate(v): out+=flatten_props(val, f'{prefix}.{i}' if prefix else str(i))
    else: out.append((prefix, '' if v is None else str(v).lower() if isinstance(v,bool) else str(v)))
    return out

def dump_output(v, fmt, indent=2, unwrap=True):
    fmt=normfmt(fmt)
    if fmt in ('auto',''): fmt='yaml'
    if fmt=='json': return json.dumps(v, indent=indent, ensure_ascii=False)+'\n'
    if fmt in ('props','properties'): return ''.join(f'{k} = {val}\n' for k,val in flatten_props(v))
    if fmt=='shell': return ''.join(f'{re.sub("[^A-Za-z0-9_]","_",k).upper()}={json.dumps(val)}\n' for k,val in flatten_props(v))
    if fmt=='csv' or fmt=='tsv':
        sep='\t' if fmt=='tsv' else ','; out=StringIO();
        rows=v if isinstance(v,list) else [v]
        keys=list(rows[0].keys()) if rows and isinstance(rows[0],dict) else ['value']
        w=csv.writer(out, delimiter=sep); w.writerow(keys)
        for r in rows: w.writerow([r.get(k,'') if isinstance(r,dict) else r for k in keys])
        return out.getvalue()
    if fmt=='xml': return to_xml(v)+'\n'
    if fmt=='base64': return base64.b64encode(str(v).encode()).decode()+'\n'
    if fmt=='uri': return urllib.parse.quote(str(v))+'\n'
    if not isinstance(v,(dict,list)) and unwrap:
        return ('null' if v is None else str(v).lower() if isinstance(v,bool) else str(v))+'\n'
    return dump_yaml(v,0,indent)

def to_xml(v, name='root'):
    if isinstance(v,dict) and len(v)==1:
        name=list(v.keys())[0]; v=v[name]
    if isinstance(v,dict):
        attrs=''.join(f' {k[2:]}="{val}"' for k,val in v.items() if k.startswith('+@'))
        inner=''.join(to_xml(val,k) for k,val in v.items() if not k.startswith('+@') and k!='+content')
        text=str(v.get('+content',''))
        return f'<{name}{attrs}>{text}{inner}</{name}>'
    if isinstance(v,list): return ''.join(to_xml(x,name) for x in v)
    return f'<{name}>{"" if v is None else v}</{name}>'

def parse_args(argv):
    opts={'input':'auto','output':'auto','indent':2,'inplace':False,'null':False,'exit':False,'expr':None,'files':[], 'unwrap':True}
    i=0
    if argv and argv[0] in ('eval','e','eval-all','ea'): opts['cmd']=argv[0]; i=1
    else: opts['cmd']='eval'
    while i<len(argv):
        a=argv[i]
        if a in ('--help','-h','help'): print(HELP); sys.exit(0)
        if a in ('--version','-V'): print(VERSION); sys.exit(0)
        if a in ('-i','--inplace'): opts['inplace']=True; i+=1; continue
        if a in ('-n','--null-input'): opts['null']=True; i+=1; continue
        if a in ('-e','--exit-status'): opts['exit']=True; i+=1; continue
        if a in ('-P','--prettyPrint','-M','--no-colors','-C','--colors','-N','--no-doc','-c','--yaml-compact-seq-indent'): i+=1; continue
        if a in ('-r','--unwrapScalar'): opts['unwrap']=True; i+=1; continue
        if a in ('-I','--indent','-p','--input-format','-o','--output-format','--expression','--from-file'):
            val=argv[i+1]; i+=2
            if a in ('-I','--indent'): opts['indent']=int(val)
            elif a in ('-p','--input-format'): opts['input']=val
            elif a in ('-o','--output-format'): opts['output']=val
            elif a=='--expression': opts['expr']=val
            else: opts['expr']=open(val).read()
            continue
        if a.startswith('-o='): opts['output']=a[3:]; i+=1; continue
        if a.startswith('-p='): opts['input']=a[3:]; i+=1; continue
        if a.startswith('--output-format='): opts['output']=a.split('=',1)[1]; i+=1; continue
        if a.startswith('--input-format='): opts['input']=a.split('=',1)[1]; i+=1; continue
        if a.startswith('-o') and len(a)>2: opts['output']=a[2:]; i+=1; continue
        if a.startswith('-p') and len(a)>2: opts['input']=a[2:]; i+=1; continue
        if a.startswith('--'): i+=2 if i+1<len(argv) and not argv[i+1].startswith('-') else 1; continue
        if opts['expr'] is None and (a.startswith('.') or a.startswith('[') or '=' in a or a in ('keys','length') or a.startswith(('has(','select(','load(')) or 'ireduce' in a): opts['expr']=a
        else: opts['files'].append(a)
        i+=1
    if opts['expr'] is None: opts['expr']='.'
    return opts

def read_file(path, infmt):
    text=sys.stdin.read() if path=='-' else open(path).read()
    return parse_input(text, detect_format(path, infmt))

def main():
    opts=parse_args(sys.argv[1:])
    try:
        docs=[]
        if opts['null']: docs=[None]
        elif opts['files']:
            docs=[read_file(f,opts['input']) for f in opts['files']]
        else:
            txt=sys.stdin.read()
            docs=[parse_input(txt, normfmt(opts['input']) if opts['input']!='auto' else 'yaml')] if txt else [None]
        if opts['cmd'] in ('eval-all','ea'):
            result=eval_expr(opts['expr'], docs[0] if docs else None, docs)
            results=[result]
        else:
            results=[eval_expr(opts['expr'], d, docs) for d in docs]
        outfmt=normfmt(opts['output'])
        if outfmt=='auto':
            outfmt='json' if opts['files'] and detect_format(opts['files'][0],opts['input'])=='json' and opts['expr']=='.' else 'yaml'
        if opts['null'] and opts['expr'].strip()=='.':
            output='\n'
        else:
            expanded=[]
            for r in results:
                if isinstance(r,list) and '[]' in opts['expr'] and not opts['expr'].lstrip().startswith('['): expanded.extend(r)
                else: expanded.append(r)
            output=''.join(dump_output(r,outfmt,opts['indent'],opts['unwrap']) for r in expanded)
        if opts['inplace']:
            if not opts['files']: raise Exception('write in place flag only applicable when giving an expression and at least one file')
            open(opts['files'][0],'w').write(output)
        else: sys.stdout.write(output)
        if opts['exit'] and (not results or any(r is None or r is False for r in results)):
            print('Error: no matches found', file=sys.stderr); sys.exit(1)
    except BrokenPipeError: pass
    except Exception as e:
        print('Error: '+str(e), file=sys.stderr); sys.exit(1)
if __name__=='__main__': main()
