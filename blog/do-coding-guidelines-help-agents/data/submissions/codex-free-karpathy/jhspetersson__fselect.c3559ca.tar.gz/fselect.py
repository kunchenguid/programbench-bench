#!/usr/bin/env python3
import base64
import csv
import fnmatch
import hashlib
import html
import json
import math
import mimetypes
import os
import pwd
import grp
import random
import re
import shlex
import stat
import sys
import time
from collections import deque


VERSION = "0.10.0"
TYPE_EXTS = {
    "archive": {".7z", ".bz2", ".bzip2", ".gz", ".gzip", ".lz", ".rar", ".tar", ".xz", ".zip"},
    "audio": {".aac", ".aiff", ".amr", ".flac", ".gsm", ".m4a", ".m4b", ".m4p", ".mp3", ".ogg", ".wav", ".wma"},
    "book": {".azw3", ".chm", ".djv", ".djvu", ".epub", ".fb2", ".mobi", ".pdf"},
    "doc": {".accdb", ".doc", ".docm", ".docx", ".dot", ".dotm", ".dotx", ".mdb", ".odp", ".ods", ".odt", ".pdf", ".potm", ".potx", ".ppt", ".pptm", ".pptx", ".rtf", ".xlm", ".xls", ".xlsm", ".xlsx", ".xlt", ".xltm", ".xltx", ".xps"},
    "font": {".eot", ".fon", ".otc", ".otf", ".ttc", ".ttf", ".woff", ".woff2"},
    "image": {".bmp", ".exr", ".gif", ".heic", ".jpeg", ".jpg", ".jxl", ".png", ".psb", ".psd", ".svg", ".tga", ".tiff", ".webp"},
    "source": {".asm", ".awk", ".bas", ".c", ".cc", ".ceylon", ".clj", ".coffee", ".cpp", ".cs", ".d", ".dart", ".elm", ".erl", ".go", ".gradle", ".groovy", ".h", ".hh", ".hpp", ".java", ".jl", ".js", ".jsp", ".jsx", ".kt", ".kts", ".lua", ".nim", ".pas", ".php", ".pl", ".pm", ".py", ".rb", ".rs", ".scala", ".sol", ".swift", ".tcl", ".ts", ".tsx", ".vala", ".vb", ".zig"},
    "video": {".3gp", ".avi", ".flv", ".m4p", ".m4v", ".mkv", ".mov", ".mp4", ".mpeg", ".mpg", ".webm", ".wmv"},
}
ALIASES = {
    "fname": "filename", "extension": "ext", "directory": "dir", "dirname": "dir",
    "hsize": "fsize", "is_fifo": "is_pipe", "is_character": "is_char",
    "user_rwx": "user_all", "group_rwx": "group_all", "other_rwx": "other_all",
    "is_suid": "suid", "is_sgid": "sgid", "sticky": "is_sticky",
    "has_caps": "has_capabilities", "caps": "capabilities",
    "sha2_256": "sha256", "sha2_512": "sha512", "sha3_512": "sha3",
}
KNOWN_COLS = {
    "name", "filename", "ext", "path", "abspath", "dir", "absdir", "size", "fsize",
    "uid", "gid", "user", "group", "created", "accessed", "modified", "atime",
    "mtime", "ctime", "mode", "is_dir", "is_file", "is_symlink", "is_pipe",
    "is_char", "is_block", "is_socket", "device", "rdev", "inode", "blocks",
    "hardlinks", "user_read", "user_write", "user_exec", "user_all",
    "group_read", "group_write", "group_exec", "group_all", "other_read",
    "other_write", "other_exec", "other_all", "suid", "sgid", "is_sticky",
    "is_hidden", "is_empty", "is_shebang", "line_count", "is_binary",
    "is_text", "mime", "sha1", "sha256", "sha512", "sha3", "width", "height",
    "has_xattrs", "xattr_count", "extattrs", "has_extattrs", "acl", "has_acl",
    "default_acl", "has_default_acl", "has_capabilities", "capabilities",
    "is_archive", "is_audio", "is_book", "is_doc", "is_font", "is_image",
    "is_source", "is_video",
}
KNOWN_COLS |= set(ALIASES.keys())


def help_text():
    return f"""fselect {VERSION}
Find files with SQL-like queries.
https://github.com/jhspetersson/fselect

Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]

Column Options:
    name, filename, ext, path, abspath, dir, absdir, size, fsize
    uid, gid, user, group, created, accessed, modified, mode
    is_dir, is_file, is_symlink, is_hidden, is_empty, is_text, is_binary
    is_archive, is_audio, is_book, is_doc, is_font, is_image, is_source, is_video

Format:
    tabs, lines, list, csv, json, html
"""


def split_query(argv):
    args = []
    skip = False
    for i, a in enumerate(argv):
        if skip:
            skip = False
            continue
        if a in ("--help", "-h", "/?", "/h"):
            print(help_text(), end="")
            sys.exit(0)
        if a in ("--nocolor", "--no-color", "--no-errors", "--us-dates"):
            continue
        if a in ("--config", "-c", "/config"):
            skip = True
            continue
        if a in ("--interactive", "-i", "/i"):
            repl()
            sys.exit(0)
        args.append(a)
    return " ".join(args).strip()


def repl():
    while True:
        try:
            q = input("> ").strip()
        except EOFError:
            break
        if q.lower() in ("exit", "quit"):
            break
        if q.lower() == "pwd":
            print(os.getcwd())
            continue
        if q.lower().startswith("cd "):
            try:
                os.chdir(q[3:].strip())
            except OSError as e:
                print(e, file=sys.stderr)
            continue
        if q.lower() == "help":
            print(help_text(), end="")
            continue
        try:
            run_query(q)
        except Exception as e:
            print(f"query: {e}", file=sys.stderr)


TOKEN_RE = re.compile(r"\s*(>=|<=|!=~|!~=|!==|===|!=|<>|==|=~|~=|[(),{}+\-%<>]|'[^']*'|`[^`]*`|\"[^\"]*\"|[^\s(),{}+\-%<>]+)")


def tokenize(s):
    toks = []
    pos = 0
    while pos < len(s):
        m = TOKEN_RE.match(s, pos)
        if not m:
            pos += 1
            continue
        tok = m.group(1)
        pos = m.end()
        if tok:
            toks.append(tok)
    return toks


def unquote(s):
    if len(s) >= 2 and s[0] == s[-1] and s[0] in "'\"`":
        return s[1:-1]
    return s


def split_top(tokens, sep=","):
    out, cur, depth = [], [], 0
    for t in tokens:
        if t in ("(", "{"):
            depth += 1
        elif t in (")", "}"):
            depth -= 1
        if t == sep and depth == 0:
            if cur:
                out.append(cur)
            cur = []
        else:
            cur.append(t)
    if cur:
        out.append(cur)
    return out


def find_kw(tokens, words, start=0):
    lw = [t.lower() for t in tokens]
    words = [w.lower() for w in words]
    for i in range(start, len(tokens) - len(words) + 1):
        if lw[i:i + len(words)] == words:
            return i
    return -1


def parse_query(q):
    tokens = tokenize(q)
    if tokens and tokens[0].lower() == "select":
        tokens = tokens[1:]
    clause_names = [("from",), ("where",), ("group", "by"), ("order", "by"), ("limit",), ("offset",), ("into",)]
    positions = []
    for c in clause_names:
        p = find_kw(tokens, c)
        if p >= 0:
            positions.append((p, c))
    positions.sort()
    first = positions[0][0] if positions else len(tokens)
    col_tokens = tokens[:first] or ["path"]
    clauses = {}
    for idx, (p, c) in enumerate(positions):
        end = positions[idx + 1][0] if idx + 1 < len(positions) else len(tokens)
        clauses[" ".join(c)] = tokens[p + len(c):end]
    roots = parse_roots(clauses.get("from", []))
    return {
        "raw": q, "columns": parse_columns(col_tokens), "roots": roots,
        "where": clauses.get("where", []),
        "order": clauses.get("order by", []),
        "limit": int(unquote(clauses.get("limit", ["-1"])[0])) if clauses.get("limit") else None,
        "offset": int(unquote(clauses.get("offset", ["0"])[0])) if clauses.get("offset") else 0,
        "format": (unquote(clauses.get("into", ["tabs"])[0]).lower() if clauses.get("into") else "tabs"),
    }


def parse_columns(tokens):
    cols = []
    for part in split_top(tokens):
        depth = 0
        has_expr = any(t in ("(", "{", "+", "-", "%") for t in part)
        if not has_expr and len(part) > 1:
            cols.extend([[t] for t in part])
            continue
        cols.append(part)
    return cols


def parse_roots(tokens):
    if not tokens:
        return [{"path": ".", "mindepth": 0, "maxdepth": None, "follow": False, "dfs": False}]
    roots = []
    for part in split_top(tokens):
        if not part:
            continue
        root = unquote(part[0])
        opts = {"path": root, "mindepth": 0, "maxdepth": None, "follow": False, "dfs": False}
        i = 1
        while i < len(part):
            k = part[i].lower()
            if k in ("mindepth",):
                i += 1; opts["mindepth"] = int(unquote(part[i]))
            elif k in ("maxdepth", "depth"):
                i += 1; opts["maxdepth"] = int(unquote(part[i]))
            elif k in ("symlinks", "sym"):
                opts["follow"] = True
            elif k == "dfs":
                opts["dfs"] = True
            elif k == "as":
                i += 1
            i += 1
        roots.append(opts)
    return roots


def walk_root(root):
    base = os.path.abspath(root["path"])
    maxd = root["maxdepth"]
    mind = root["mindepth"]
    follow = root["follow"]
    q = deque([(base, 1)])
    while q:
        cur, depth = (q.pop() if root["dfs"] else q.popleft())
        try:
            entries = list(os.scandir(cur))
        except OSError:
            continue
        dirs = []
        for e in entries:
            rel = os.path.relpath(e.path, base)
            try:
                st_l = os.lstat(e.path)
                st = os.stat(e.path) if follow and stat.S_ISLNK(st_l.st_mode) else st_l
            except OSError:
                continue
            row = Row(base, e.path, rel, st, st_l, follow)
            if depth >= mind:
                yield row
            isdir = stat.S_ISDIR(st.st_mode)
            if isdir and (maxd is None or depth < maxd):
                if follow or not stat.S_ISLNK(st_l.st_mode):
                    dirs.append((e.path, depth + 1))
        if root["dfs"]:
            q.extend(dirs)
        else:
            q.extend(dirs)


class Row:
    def __init__(self, base, path, rel, st, lst, follow=False):
        self.base, self.path, self.rel, self.st, self.lst, self.follow = base, path, rel, st, lst, follow
        self._cache = {}

    def col(self, name):
        n = ALIASES.get(name.lower(), name.lower())
        if n in self._cache:
            return self._cache[n]
        v = self._col(n)
        self._cache[n] = v
        return v

    def _col(self, n):
        p, rel = self.path, self.rel
        bn = os.path.basename(rel)
        stem, ext = split_name(bn)
        mode = self.st.st_mode
        lmode = self.lst.st_mode
        if n == "name": return bn
        if n == "filename": return stem
        if n == "ext": return ext
        if n == "path": return rel
        if n == "abspath": return os.path.abspath(p if not stat.S_ISLNK(lmode) else os.path.realpath(p))
        if n == "dir":
            d = os.path.dirname(rel)
            return "" if d == "." else d
        if n == "absdir": return os.path.dirname(os.path.abspath(p if not stat.S_ISLNK(lmode) else os.path.realpath(p)))
        if n == "size": return self.st.st_size
        if n == "fsize": return format_size(self.st.st_size)
        if n == "uid": return self.st.st_uid
        if n == "gid": return self.st.st_gid
        if n == "user":
            try: return pwd.getpwuid(self.st.st_uid).pw_name
            except KeyError: return str(self.st.st_uid)
        if n == "group":
            try: return grp.getgrgid(self.st.st_gid).gr_name
            except KeyError: return str(self.st.st_gid)
        if n == "atime": return int(self.st.st_atime)
        if n == "mtime": return int(self.st.st_mtime)
        if n == "ctime": return int(self.st.st_ctime)
        if n == "accessed": return fmt_time(self.st.st_atime)
        if n == "modified": return fmt_time(self.st.st_mtime)
        if n == "created": return fmt_time(getattr(self.st, "st_birthtime", self.st.st_ctime))
        if n == "mode": return stat.filemode(lmode)
        if n == "is_dir": return stat.S_ISDIR(mode)
        if n == "is_file": return stat.S_ISREG(mode)
        if n == "is_symlink": return stat.S_ISLNK(lmode)
        if n == "is_pipe": return stat.S_ISFIFO(mode)
        if n == "is_char": return stat.S_ISCHR(mode)
        if n == "is_block": return stat.S_ISBLK(mode)
        if n == "is_socket": return stat.S_ISSOCK(mode)
        if n == "device": return self.st.st_dev
        if n == "rdev": return self.st.st_rdev
        if n == "inode": return self.st.st_ino
        if n == "blocks": return getattr(self.st, "st_blocks", 0) * 2
        if n == "hardlinks": return self.st.st_nlink
        if n == "is_hidden": return bn.startswith(".")
        if n == "is_empty": return is_empty(p, mode)
        if n == "is_shebang": return read_start(p, 2) == b"#!"
        if n == "line_count": return line_count(p, mode, lmode)
        if n == "is_binary": return is_binary(p, mode)
        if n == "is_text": return (stat.S_ISREG(mode) or stat.S_ISLNK(lmode)) and not is_binary(p, mode)
        if n == "mime": return mimetypes.guess_type(p)[0] or ""
        if n in ("user_read", "user_write", "user_exec", "group_read", "group_write", "group_exec", "other_read", "other_write", "other_exec"):
            bit = {"user_read": stat.S_IRUSR, "user_write": stat.S_IWUSR, "user_exec": stat.S_IXUSR, "group_read": stat.S_IRGRP, "group_write": stat.S_IWGRP, "group_exec": stat.S_IXGRP, "other_read": stat.S_IROTH, "other_write": stat.S_IWOTH, "other_exec": stat.S_IXOTH}[n]
            return bool(lmode & bit)
        if n == "user_all": return all(self.col(x) for x in ("user_read", "user_write", "user_exec"))
        if n == "group_all": return all(self.col(x) for x in ("group_read", "group_write", "group_exec"))
        if n == "other_all": return all(self.col(x) for x in ("other_read", "other_write", "other_exec"))
        if n == "suid": return bool(lmode & stat.S_ISUID)
        if n == "sgid": return bool(lmode & stat.S_ISGID)
        if n == "is_sticky": return bool(lmode & stat.S_ISVTX)
        if n.startswith("is_") and n[3:] in TYPE_EXTS: return ("." + ext.lower()) in TYPE_EXTS[n[3:]]
        if n in ("sha1", "sha256", "sha512", "sha3"): return file_hash(p, n, mode)
        if n in ("width", "height"): return image_dim(p, n)
        return ""


def split_name(bn):
    if "." in bn and not bn.startswith("."):
        a, b = bn.rsplit(".", 1)
        return a, b
    return bn, ""


def fmt_time(ts):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))


def format_size(n):
    n = int(n)
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    x = float(n)
    u = 0
    while abs(x) >= 1024 and u < len(units) - 1:
        x /= 1024.0; u += 1
    return f"{int(x)}{units[u]}" if u == 0 or x.is_integer() else f"{x:.2f}{units[u]}"


def is_empty(p, mode):
    try:
        if stat.S_ISDIR(mode):
            return len(os.listdir(p)) == 0
        return os.path.getsize(p) == 0
    except OSError:
        return False


def read_start(p, n=8192):
    try:
        with open(p, "rb") as f:
            return f.read(n)
    except OSError:
        return b""


def is_binary(p, mode):
    if not stat.S_ISREG(mode):
        return False
    data = read_start(p, 8192)
    return b"\0" in data


def line_count(p, mode, lmode=None):
    if not (stat.S_ISREG(mode) or (lmode is not None and stat.S_ISLNK(lmode))):
        return ""
    try:
        with open(p, "rb") as f:
            return sum(chunk.count(b"\n") for chunk in iter(lambda: f.read(65536), b""))
    except OSError:
        return ""


def file_hash(p, alg, mode):
    if not stat.S_ISREG(mode):
        return ""
    h = {"sha1": hashlib.sha1, "sha256": hashlib.sha256, "sha512": hashlib.sha512, "sha3": hashlib.sha3_512}[alg]()
    try:
        with open(p, "rb") as f:
            for b in iter(lambda: f.read(65536), b""):
                h.update(b)
        return h.hexdigest()
    except OSError:
        return ""


def image_dim(p, which):
    try:
        with open(p, "rb") as f:
            data = f.read(32)
        if data.startswith(b"\x89PNG\r\n\x1a\n"):
            w = int.from_bytes(data[16:20], "big"); h = int.from_bytes(data[20:24], "big")
            return w if which == "width" else h
        if data[:3] == b"GIF":
            w = int.from_bytes(data[6:8], "little"); h = int.from_bytes(data[8:10], "little")
            return w if which == "width" else h
    except OSError:
        pass
    return ""


def value_to_str(v):
    if isinstance(v, bool): return "true" if v else "false"
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else str(v)
    return "" if v is None else str(v)


def to_num(v):
    if isinstance(v, bool): return 1 if v else 0
    if isinstance(v, (int, float)): return v
    s = str(v)
    m = re.fullmatch(r"(-?\d+(?:\.\d+)?)([a-zA-Z]+)?", s)
    if not m:
        try: return float(s)
        except ValueError: return None
    x = float(m.group(1))
    mult = {"k":1024,"kib":1024,"kb":1000,"m":1024**2,"mib":1024**2,"mb":1000**2,"g":1024**3,"gib":1024**3,"gb":1000**3,"t":1024**4,"tib":1024**4,"tb":1000**4}.get((m.group(2) or "").lower(), 1)
    return int(x * mult)


class Parser:
    def __init__(self, tokens, row=None):
        self.t, self.i, self.row = tokens, 0, row
    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else None
    def pop(self):
        x = self.peek(); self.i += 1; return x
    def expr(self):
        return self.add()
    def add(self):
        v = self.mul()
        while self.peek() and self.peek().lower() in ("+", "-", "plus", "minus"):
            op = self.pop().lower(); r = self.mul()
            v = (to_num(v) or 0) + (to_num(r) or 0) if op in ("+", "plus") else (to_num(v) or 0) - (to_num(r) or 0)
        return v
    def mul(self):
        v = self.unary()
        while self.peek() and self.peek().lower() in ("*", "/", "%", "mul", "div", "mod"):
            op = self.pop().lower(); r = self.unary(); a, b = to_num(v) or 0, to_num(r) or 0
            if op in ("*", "mul"): v = a * b
            elif op in ("/", "div"): v = a / b if b else 0
            else: v = a % b if b else 0
        return v
    def unary(self):
        if self.peek() == "-":
            self.pop(); return -(to_num(self.unary()) or 0)
        return self.atom()
    def atom(self):
        tok = self.pop()
        if tok is None: return ""
        if tok in ("(", "{"):
            v = self.expr()
            if self.peek() in (")", "}"): self.pop()
            return v
        name = tok.lower()
        if self.peek() in ("(", "{"):
            self.pop()
            args = []
            cur, depth = [], 0
            while self.peek() is not None:
                p = self.peek()
                if p in (")", "}") and depth == 0:
                    self.pop(); break
                if p == "," and depth == 0:
                    args.append(Parser(cur, self.row).expr() if cur else ""); cur = []; self.pop(); continue
                if p in ("(", "{"): depth += 1
                if p in (")", "}"): depth -= 1
                cur.append(self.pop())
            if cur: args.append(Parser(cur, self.row).expr())
            return call_func(name, args, self.row)
        if name in ("true", "yes"): return True
        if name in ("false", "no"): return False
        if re.fullmatch(r"-?\d+(\.\d+)?[a-zA-Z]*", tok):
            n = to_num(tok)
            return n if n is not None else tok
        uq = unquote(tok)
        if uq != tok: return uq
        canon = ALIASES.get(name, name)
        return self.row.col(name) if self.row and canon in KNOWN_COLS else uq


def call_func(name, args, row):
    n = name.lower()
    if n in ("lower", "lowercase", "lcase"): return str(args[0]).lower() if args else ""
    if n in ("upper", "uppercase", "ucase"): return str(args[0]).upper() if args else ""
    if n in ("length", "len"): return len(str(args[0])) if args else 0
    if n == "initcap": return str(args[0]).title() if args else ""
    if n in ("to_base64", "base64"): return base64.b64encode(str(args[0]).encode()).decode()
    if n == "from_base64":
        try: return base64.b64decode(str(args[0])).decode()
        except Exception: return ""
    if n == "concat": return "".join(value_to_str(a) for a in args)
    if n == "concat_ws":
        return value_to_str(args[0]).join(value_to_str(a) for a in args[1:]) if args else ""
    if n in ("substr", "substring"):
        s = str(args[0]) if args else ""; pos = int(to_num(args[1]) or 1) if len(args) > 1 else 1
        ln = int(to_num(args[2]) or 0) if len(args) > 2 else None
        start = pos - 1 if pos > 0 else len(s) + pos
        return s[start:] if ln is None else s[start:start + ln]
    if n == "replace": return str(args[0]).replace(str(args[1]), str(args[2])) if len(args) >= 3 else ""
    if n == "trim": return str(args[0]).strip() if args else ""
    if n == "ltrim": return str(args[0]).lstrip() if args else ""
    if n == "rtrim": return str(args[0]).rstrip() if args else ""
    if n in ("locate", "position"):
        sub, s = (str(args[0]), str(args[1])) if len(args) >= 2 else ("", "")
        start = int(to_num(args[2]) or 1) - 1 if len(args) > 2 else 0
        k = s.find(sub, max(0, start)); return k + 1 if k >= 0 else 0
    if n == "bin": return bin(int(to_num(args[0]) or 0))[2:]
    if n == "hex": return hex(int(to_num(args[0]) or 0))[2:]
    if n == "oct": return oct(int(to_num(args[0]) or 0))[2:]
    if n == "abs": return abs(to_num(args[0]) or 0)
    if n in ("power", "pow"): return math.pow(to_num(args[0]) or 0, to_num(args[1]) or 0)
    if n == "sqrt": return math.sqrt(to_num(args[0]) or 0)
    if n == "ln": return math.log(to_num(args[0]) or 1)
    if n == "log": return math.log(to_num(args[0]) or 1, to_num(args[1]) or 10) if len(args) > 1 else math.log10(to_num(args[0]) or 1)
    if n == "exp": return math.exp(to_num(args[0]) or 0)
    if n == "floor": return math.floor(to_num(args[0]) or 0)
    if n in ("ceil", "ceiling"): return math.ceil(to_num(args[0]) or 0)
    if n == "round": return round(to_num(args[0]) or 0, int(to_num(args[1]) or 0) if len(args) > 1 else None)
    if n == "pi": return math.pi
    if n == "least": return min(args) if args else ""
    if n == "greatest": return max(args) if args else ""
    if n in ("rand", "random"):
        if len(args) >= 2: return random.randint(int(to_num(args[0]) or 0), int(to_num(args[1]) or 0))
        if len(args) == 1: return random.randint(0, int(to_num(args[0]) or 0))
        return random.randint(0, 2**31 - 1)
    if n in ("format_size", "format_filesize"): return format_size(to_num(args[0]) or 0)
    if n == "coalesce":
        for a in args:
            if value_to_str(a) != "": return a
        return ""
    if n in ("current_uid",): return os.getuid()
    if n in ("current_gid",): return os.getgid()
    if n in ("current_user",): return pwd.getpwuid(os.getuid()).pw_name
    if n in ("current_group",): return grp.getgrgid(os.getgid()).gr_name
    if row and not args:
        return row.col(n)
    return ""


def eval_expr(tokens, row):
    return Parser(tokens, row).expr()


def truth(v):
    if isinstance(v, bool): return v
    if isinstance(v, (int, float)): return v != 0
    return str(v).lower() not in ("", "false", "0")


def eval_where(tokens, row):
    if not tokens:
        return True
    return parse_or(tokens, row)


def strip_outer(tokens):
    while tokens and tokens[0] in ("(", "{") and tokens[-1] in (")", "}"):
        depth = 0; ok = True
        for i, t in enumerate(tokens):
            if t in ("(", "{"): depth += 1
            elif t in (")", "}"):
                depth -= 1
                if depth == 0 and i != len(tokens) - 1:
                    ok = False; break
        if ok: tokens = tokens[1:-1]
        else: break
    return tokens


def split_logic(tokens, word):
    depth = 0
    for i in range(len(tokens) - 1, -1, -1):
        t = tokens[i]
        if t in (")", "}"): depth += 1
        elif t in ("(", "{"): depth -= 1
        elif depth == 0 and t.lower() == word:
            if word == "and" and protects_between(tokens, i):
                continue
            return tokens[:i], tokens[i + 1:]
    return None


def protects_between(tokens, idx):
    depth = 0
    seen_between = False
    for t in tokens[:idx]:
        if t in ("(", "{"):
            depth += 1
        elif t in (")", "}"):
            depth -= 1
        elif depth == 0:
            if t.lower() in ("or", "and"):
                seen_between = False
            elif t.lower() == "between":
                seen_between = True
    return seen_between


def parse_or(tokens, row):
    tokens = strip_outer(tokens)
    sp = split_logic(tokens, "or")
    if sp: return parse_or(sp[0], row) or parse_and(sp[1], row)
    return parse_and(tokens, row)


def parse_and(tokens, row):
    tokens = strip_outer(tokens)
    sp = split_logic(tokens, "and")
    if sp: return parse_and(sp[0], row) and parse_cmp(sp[1], row)
    return parse_cmp(tokens, row)


OPS = {"=", "==", "eq", "!=", "<>", "ne", "===", "eeq", "!==", "ene", ">", "gt", ">=", "gte", "ge", "<", "lt", "<=", "lte", "le", "=~", "~=", "regexp", "rx", "!=~", "!~=", "notrx", "like", "notlike", "between", "in"}


def parse_cmp(tokens, row):
    tokens = strip_outer(tokens)
    depth = 0
    for i, t in enumerate(tokens):
        tl = t.lower()
        if t in ("(", "{"): depth += 1
        elif t in (")", "}"): depth -= 1
        elif depth == 0 and tl in OPS:
            left = eval_expr(tokens[:i], row)
            if tl == "between":
                try:
                    j = [x.lower() for x in tokens[i+1:]].index("and") + i + 1
                    return compare(left, ">=", eval_expr(tokens[i+1:j], row)) and compare(left, "<=", eval_expr(tokens[j+1:], row))
                except ValueError:
                    return False
            if tl == "in":
                vals = [eval_expr(x, row) for x in split_top(strip_outer(tokens[i+1:]))]
                return any(compare(left, "===", v) for v in vals)
            right = eval_expr(tokens[i+1:], row)
            return compare(left, tl, right)
    return truth(eval_expr(tokens, row))


def compare(a, op, b):
    if op in ("=", "==", "eq"):
        return match_eq(a, b, glob=True)
    if op in ("!=", "<>", "ne"):
        return not match_eq(a, b, glob=True)
    if op in ("===", "eeq"):
        return str(a) == str(b)
    if op in ("!==", "ene"):
        return str(a) != str(b)
    if op in ("=~", "~=", "regexp", "rx"):
        try: return re.search(str(b), str(a)) is not None
        except re.error: return False
    if op in ("!=~", "!~=", "notrx"):
        try: return re.search(str(b), str(a)) is None
        except re.error: return True
    if op in ("like", "notlike"):
        pat = "^" + re.escape(str(b)).replace("%", ".*").replace("_", ".") + "$"
        ok = re.match(pat, str(a)) is not None
        return not ok if op == "notlike" else ok
    na, nb = to_num(a), to_num(b)
    aa, bb = (na, nb) if na is not None and nb is not None else (str(a), str(b))
    if op in (">", "gt"): return aa > bb
    if op in (">=", "gte", "ge"): return aa >= bb
    if op in ("<", "lt"): return aa < bb
    if op in ("<=", "lte", "le"): return aa <= bb
    return False


def match_eq(a, b, glob=False):
    if isinstance(a, bool):
        return a == truth(b)
    sa, sb = str(a), str(b)
    return fnmatch.fnmatchcase(sa, sb) if glob and any(c in sb for c in "*?[]") else sa == sb


AGG = {"count", "sum", "min", "max", "avg", "stddev_pop", "stddev", "std", "stddev_samp", "var_pop", "variance", "var_samp"}


def is_agg(col):
    return col and col[0].lower() in AGG and len(col) > 1 and col[1] in ("(", "{")


def eval_agg(col, rows):
    name = col[0].lower()
    inner = col[2:-1] if len(col) >= 3 and col[1] in ("(", "{") else []
    vals = [eval_expr(inner, r) for r in rows] if inner != ["*"] else rows
    nums = [to_num(v) for v in vals if to_num(v) is not None]
    if name == "count": return len(vals)
    if not nums: return ""
    if name == "sum": return sum(nums)
    if name == "min": return min(nums)
    if name == "max": return max(nums)
    if name == "avg": return sum(nums) / len(nums)
    mean = sum(nums) / len(nums)
    if name in ("var_pop", "variance", "stddev_pop", "stddev", "std"):
        var = sum((x - mean) ** 2 for x in nums) / len(nums)
    else:
        var = sum((x - mean) ** 2 for x in nums) / (len(nums) - 1) if len(nums) > 1 else 0
    return math.sqrt(var) if name.startswith("std") else var


def col_label(tokens):
    if len(tokens) == 1:
        s = ALIASES.get(tokens[0].lower(), tokens[0].lower())
        return {"filename":"Filename","ext":"Extension","path":"Path","abspath":"AbsPath","dir":"Directory","absdir":"AbsDir","size":"Size","fsize":"FSize"}.get(s, s.capitalize())
    return "".join(tokens)


def run_query(q):
    spec = parse_query(q)
    rows = []
    for r in spec["roots"]:
        rows.extend(row for row in walk_root(r) if eval_where(spec["where"], row))
    if spec["order"]:
        orders = []
        for part in split_top(spec["order"]):
            desc = len(part) > 1 and part[-1].lower() == "desc"
            if part and part[-1].lower() in ("asc", "desc"): part = part[:-1]
            orders.append((part, desc))
        for expr, desc in reversed(orders):
            rows.sort(key=lambda row: sort_key(eval_expr(expr, row)), reverse=desc)
    values = []
    if any(is_agg(c) for c in spec["columns"]):
        values = [[value_to_str(eval_agg(c, rows) if is_agg(c) else eval_expr(c, rows[0]) if rows else "") for c in spec["columns"]]]
    else:
        selected = rows[spec["offset"]:]
        if spec["limit"] is not None and spec["limit"] >= 0:
            selected = selected[:spec["limit"]]
        values = [[value_to_str(eval_expr(c, row)) for c in spec["columns"]] for row in selected]
    emit(values, spec)


def sort_key(v):
    n = to_num(v)
    return (0, n) if n is not None else (1, str(v))


def emit(values, spec):
    fmt = spec["format"]
    if fmt == "lines":
        for row in values:
            for v in row: print(v)
    elif fmt == "list":
        sys.stdout.write("".join(v + "\0" for row in values for v in row))
    elif fmt == "csv":
        w = csv.writer(sys.stdout, lineterminator="\n")
        w.writerows(values)
    elif fmt == "json":
        labels = [col_label(c) for c in spec["columns"]]
        sys.stdout.write(json.dumps([{labels[i]: row[i] for i in range(len(labels))} for row in values], separators=(",", ":")))
    elif fmt == "html":
        title = spec["raw"]
        sys.stdout.write(f"<html><head><title>{html.escape(title)}</title></head><body><table><tr><th colspan=\"{len(spec['columns'])}\">{html.escape(title)}</th></tr>")
        for row in values:
            sys.stdout.write("<tr>" + "".join(f"<td>{html.escape(v)}</td>" for v in row) + "</tr>")
        sys.stdout.write("</table></body></html>")
    else:
        for row in values:
            print("\t".join(row))


def main():
    q = split_query(sys.argv[1:])
    if not q:
        print(help_text(), end="")
        return 0
    try:
        run_query(q)
        return 0
    except Exception as e:
        print(f"query: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
