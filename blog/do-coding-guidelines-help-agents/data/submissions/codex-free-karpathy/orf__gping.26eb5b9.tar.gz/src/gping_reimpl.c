#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

static const char *HELP =
"Ping, but with a graph.\n\n"
"Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n\n"
"Arguments:\n"
"  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1\n\n"
"Options:\n"
"      --cmd\n"
"          Graph the execution time for a list of commands rather than pinging hosts\n"
"  -n, --watch-interval <WATCH_INTERVAL>\n"
"          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5\n"
"  -b, --buffer <BUFFER>\n"
"          Determines the number of seconds to display in the graph [default: 30]\n"
"  -4\n"
"          Resolve ping targets to IPv4 address\n"
"  -6\n"
"          Resolve ping targets to IPv6 address\n"
"  -i, --interface <INTERFACE>\n"
"          Interface to use when pinging\n"
"  -s, --simple-graphics\n"
"          \n"
"      --vertical-margin <VERTICAL_MARGIN>\n"
"          Vertical margin around the graph (top and bottom) [default: 1]\n"
"      --horizontal-margin <HORIZONTAL_MARGIN>\n"
"          Horizontal margin around the graph (left and right) [default: 0]\n"
"  -c, --color <color>\n"
"          Assign color to a graph entry.\n"
"          \n"
"          This option can be defined more than once as a comma separated string, and the\n"
"          order which the colors are provided will be matched against the hosts or\n"
"          commands passed to gping.\n"
"          \n"
"          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the\n"
"          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',\n"
"          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',\n"
"          'light-blue', 'light-magenta', 'light-cyan', and 'white'\n"
"      --clear\n"
"          Clear the graph from the terminal after closing the program\n"
"      --ping-args [<PING_ARGS>...]\n"
"          Extra arguments to pass to `ping`. These are platform dependent\n"
"  -h, --help\n"
"          Print help\n"
"  -V, --version\n"
"          Print version\n";

static void version(void) {
    puts("gping 1.20.1");
    puts("commit_hash: d67d2aeb");
    puts("build_time: 2026-04-17 19:59:37 +00:00");
    puts("build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu");
}

static void no_targets(void) {
    fprintf(stderr, "Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.\n");
}

static bool valid_color_one(const char *s) {
    static const char *names[] = {"black","red","green","yellow","blue","magenta","cyan","gray","dark-gray","light-red","light-green","light-yellow","light-blue","light-magenta","light-cyan","white", NULL};
    if (s[0] == '#') {
        if (strlen(s) != 7) return false;
        for (int i = 1; i < 7; i++) if (!isxdigit((unsigned char)s[i])) return false;
        return true;
    }
    for (int i = 0; names[i]; i++) if (strcmp(s, names[i]) == 0) return true;
    return false;
}

static bool valid_colors(const char *arg, const char **bad) {
    char *copy = strdup(arg);
    if (!copy) exit(2);
    char *save = NULL;
    for (char *tok = strtok_r(copy, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        if (!valid_color_one(tok)) { *bad = arg; free(copy); return false; }
    }
    free(copy);
    return true;
}

static bool parse_uint_like(const char *s) {
    if (!*s) return false;
    for (const char *p=s; *p; p++) if (!isdigit((unsigned char)*p)) return false;
    return true;
}

static bool parse_float_like(const char *s) {
    char *end = NULL;
    errno = 0;
    strtod(s, &end);
    return errno == 0 && end && *end == '\0' && end != s;
}

static const char *needs_value_msg(const char *opt, const char *meta) {
    static char buf[256];
    snprintf(buf, sizeof(buf), "error: a value is required for '%s <%s>' but none was supplied\n\nFor more information, try '--help'.\n", opt, meta);
    return buf;
}

static void invalid_value(const char *val, const char *opt, const char *meta, bool flt) {
    fprintf(stderr, "error: invalid value '%s' for '%s <%s>': %s\n\nFor more information, try '--help'.\n", val, opt, meta, flt ? "invalid float literal" : "invalid digit found in string");
}

static void unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n\nFor more information, try '--help'.\n", arg, arg, arg);
}

static const char *aws_host(const char *s) {
    static char buf[256];
    if (strncmp(s, "aws:", 4) == 0 && s[4]) {
        snprintf(buf, sizeof(buf), "ec2.%s.amazonaws.com", s + 4);
        return buf;
    }
    return s;
}

static int detect_ping(void) {
    char *path = getenv("PATH");
    if (!path) return 0;
    char *copy = strdup(path), *save = NULL;
    if (!copy) return 0;
    for (char *dir = strtok_r(copy, ":", &save); dir; dir = strtok_r(NULL, ":", &save)) {
        char p[1024];
        snprintf(p, sizeof(p), "%s/ping", *dir ? dir : ".");
        if (access(p, X_OK) == 0) { free(copy); return 1; }
    }
    free(copy);
    return 0;
}

static double now_ms(void) {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000.0 + tv.tv_usec / 1000.0;
}

static void sleep_seconds(double seconds) {
    if (seconds < 0) seconds = 0;
    struct timespec ts;
    ts.tv_sec = (time_t)seconds;
    ts.tv_nsec = (long)((seconds - (double)ts.tv_sec) * 1000000000.0);
    if (ts.tv_nsec < 0) ts.tv_nsec = 0;
    if (ts.tv_nsec > 999999999L) ts.tv_nsec = 999999999L;
    while (nanosleep(&ts, &ts) == -1 && errno == EINTR) {
    }
}

static int run_cmd_mode(char **targets, int count, double interval) {
    if (!isatty(STDOUT_FILENO)) {
        fprintf(stderr, "Error: No such device or address (os error 6)\n");
        return 1;
    }
    while (1) {
        printf("\033[2J\033[H");
        for (int i=0; i<count; i++) {
            double start = now_ms();
            int rc = system(targets[i]);
            double elapsed = now_ms() - start;
            printf("%s %.0fms %s\n", targets[i], elapsed, rc == -1 ? "error" : "");
        }
        fflush(stdout);
        sleep_seconds(interval);
    }
}

int main(int argc, char **argv) {
    bool cmd = false, v4 = false, v6 = false;
    double interval = -1.0;
    char **targets = calloc((size_t)argc + 1, sizeof(char*));
    int ntargets = 0;
    if (!targets) return 2;

    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "--") == 0) {
            for (i++; i<argc; i++) targets[ntargets++] = argv[i];
            break;
        } else if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) {
            fputs(HELP, stdout); return 0;
        } else if (strcmp(a, "-V") == 0 || strcmp(a, "--version") == 0) {
            version(); return 0;
        } else if (strcmp(a, "--cmd") == 0) {
            cmd = true;
        } else if (strcmp(a, "-4") == 0) {
            if (v6) { fprintf(stderr, "error: the argument '-4' cannot be used with '-6'\n\nUsage: executable -4 <HOSTS_OR_COMMANDS>...\n\nFor more information, try '--help'.\n"); return 2; }
            v4 = true;
        } else if (strcmp(a, "-6") == 0) {
            if (v4) { fprintf(stderr, "error: the argument '-4' cannot be used with '-6'\n\nUsage: executable -4 <HOSTS_OR_COMMANDS>...\n\nFor more information, try '--help'.\n"); return 2; }
            v6 = true;
        } else if (strcmp(a, "-s") == 0 || strcmp(a, "--simple-graphics") == 0 || strcmp(a, "--clear") == 0) {
        } else if (strcmp(a, "-n") == 0 || strcmp(a, "--watch-interval") == 0) {
            if (i+1 >= argc) { fputs(needs_value_msg("--watch-interval", "WATCH_INTERVAL"), stderr); return 2; }
            if (argv[i+1][0] == '-') { unexpected(argv[i+1]); return 2; }
            if (!parse_float_like(argv[++i])) { invalid_value(argv[i], "--watch-interval", "WATCH_INTERVAL", true); return 2; }
            interval = atof(argv[i]);
        } else if (strncmp(a, "--watch-interval=", 17) == 0) {
            char *v = a + 17; if (!parse_float_like(v)) { invalid_value(v, "--watch-interval", "WATCH_INTERVAL", true); return 2; } interval = atof(v);
        } else if (strcmp(a, "-b") == 0 || strcmp(a, "--buffer") == 0) {
            if (i+1 >= argc) { fputs(needs_value_msg("--buffer", "BUFFER"), stderr); return 2; }
            if (argv[i+1][0] == '-') { unexpected(argv[i+1]); return 2; }
            if (!parse_uint_like(argv[++i])) { invalid_value(argv[i], "--buffer", "BUFFER", false); return 2; }
        } else if (strncmp(a, "--buffer=", 9) == 0) {
            char *v = a + 9; if (!parse_uint_like(v)) { invalid_value(v, "--buffer", "BUFFER", false); return 2; }
        } else if (strcmp(a, "--vertical-margin") == 0 || strcmp(a, "--horizontal-margin") == 0) {
            const char *meta = strstr(a, "vertical") ? "VERTICAL_MARGIN" : "HORIZONTAL_MARGIN";
            if (i+1 >= argc) { fputs(needs_value_msg(a, meta), stderr); return 2; }
            if (argv[i+1][0] == '-') { unexpected(argv[i+1]); return 2; }
            if (!parse_uint_like(argv[++i])) { invalid_value(argv[i], a, meta, false); return 2; }
        } else if (strncmp(a, "--vertical-margin=", 18) == 0 || strncmp(a, "--horizontal-margin=", 20) == 0) {
            bool vert = strncmp(a, "--vertical", 10) == 0;
            char *v = strchr(a, '=') + 1;
            if (!parse_uint_like(v)) invalid_value(v, vert ? "--vertical-margin" : "--horizontal-margin", vert ? "VERTICAL_MARGIN" : "HORIZONTAL_MARGIN", false), exit(2);
        } else if (strcmp(a, "-i") == 0 || strcmp(a, "--interface") == 0) {
            if (i+1 >= argc) { fputs(needs_value_msg("--interface", "INTERFACE"), stderr); return 2; }
            i++;
        } else if (strncmp(a, "--interface=", 12) == 0) {
        } else if (strcmp(a, "-c") == 0 || strcmp(a, "--color") == 0) {
            if (i+1 >= argc) { fputs(needs_value_msg("--color", "color"), stderr); return 2; }
            const char *bad = NULL; char *v = argv[++i];
            if (!valid_colors(v, &bad)) { fprintf(stderr, "Error: Invalid color code: `%s`\n\nCaused by:\n    Failed to parse Colors\n", bad); return 1; }
        } else if (strncmp(a, "--color=", 8) == 0) {
            const char *bad = NULL; char *v = a + 8;
            if (!valid_colors(v, &bad)) { fprintf(stderr, "Error: Invalid color code: `%s`\n\nCaused by:\n    Failed to parse Colors\n", bad); return 1; }
        } else if (strcmp(a, "--ping-args") == 0) {
            /* clap accepts zero or more values here; values that look like flags are not consumed. */
            while (i+1 < argc && argv[i+1][0] != '-') i++;
        } else if (strncmp(a, "--ping-args=", 12) == 0) {
        } else if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n\nFor more information, try '--help'.\n", a, a, a);
            return 2;
        } else {
            targets[ntargets++] = a;
        }
    }

    if (ntargets == 0) { no_targets(); return 1; }
    if (interval < 0) interval = cmd ? 0.5 : 0.2;
    if (cmd) return run_cmd_mode(targets, ntargets, interval);

    for (int i=0; i<ntargets; i++) {
        const char *host = aws_host(targets[i]);
        struct addrinfo hints, *res = NULL;
        memset(&hints, 0, sizeof(hints));
        hints.ai_family = v4 ? AF_INET : (v6 ? AF_INET6 : AF_UNSPEC);
        int rc = getaddrinfo(host, NULL, &hints, &res);
        if (rc != 0) {
            fprintf(stderr, "Error: Resolving %s\n\nCaused by:\n    failed to lookup address information: %s\n", host, gai_strerror(rc));
            return 1;
        }
        freeaddrinfo(res);
    }
    if (!detect_ping()) {
        fprintf(stderr, "Error: Could not detect ping. Stderr: []\nStdout: []\n");
        return 1;
    }
    if (!isatty(STDOUT_FILENO)) {
        fprintf(stderr, "Error: No such device or address (os error 6)\n");
        return 1;
    }
    while (1) {
        printf("\033[2J\033[H");
        for (int i=0; i<ntargets; i++) printf("%s ping unavailable in reimplementation\n", targets[i]);
        fflush(stdout);
        sleep_seconds(interval);
    }
}
