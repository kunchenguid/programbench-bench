#!/usr/bin/env python3
import os, sys, subprocess, math

VERSION = "Hush 0.1.4"

class HushError(Exception):
    pass

class ReturnSignal(Exception):
    def __init__(self, value):
        self.value = value

class Tok:
    def __init__(self, kind, val, line, col):
        self.kind, self.val, self.line, self.col = kind, val, line, col
    def __repr__(self):
        return self.val

KEYWORDS = {
    "let","function","end","if","then","else","while","do","for","in",
    "return","true","false","nil","and","or","not"
}
OPS = ["==","!=","<=",">=","++","+","-","*","/","%","<",">","=","(",")","[","]",",",":",".",";","@["]

def lex(src, name="<stdin>"):
    out=[]; i=0; line=1; col=0
    def add(k,v,l=None,c=None): out.append(Tok(k,v,line if l is None else l,col if c is None else c))
    while i < len(src):
        c=src[i]
        if c in " \t\r": i+=1; col+=1; continue
        if c == "\n": add("NL","\n"); i+=1; line+=1; col=0; continue
        if c == "#":
            while i < len(src) and src[i] != "\n": i+=1; col+=1
            continue
        if c in "\"'":
            q=c; l=line; cc=col; i+=1; col+=1; s=""
            while i < len(src) and src[i] != q:
                ch=src[i]
                if ch == "\\" and i+1 < len(src):
                    n=src[i+1]; mp={"n":"\n","t":"\t","r":"\r","0":"\0","\\":"\\","\"":"\"","'":"'"}
                    s += mp.get(n,n); i+=2; col+=2
                else:
                    s += ch; i+=1; col+=1
            if i >= len(src): raise HushError(f"{name} (line {l}, column {cc}) - unterminated string")
            i+=1; col+=1; add("STR",s,l,cc); continue
        if c.isdigit():
            l=line; cc=col; j=i
            while j < len(src) and (src[j].isalnum() or src[j] in ".+-"):
                if src[j] in "+-" and not (j>i and src[j-1] in "eE"): break
                j+=1
            txt=src[i:j]; i=j; col += len(txt); add("NUM",txt,l,cc); continue
        if c.isalpha() or c == "_":
            l=line; cc=col; j=i
            while j < len(src) and (src[j].isalnum() or src[j] == "_"): j+=1
            txt=src[i:j]; i=j; col += len(txt); add("KW" if txt in KEYWORDS else "ID",txt,l,cc); continue
        matched=None
        for op in sorted(OPS, key=len, reverse=True):
            if src.startswith(op,i): matched=op; break
        if matched:
            add("SYM",matched); i+=len(matched); col+=len(matched); continue
        if c in "{}$|&?~\\/!":
            add("SYM",c); i+=1; col+=1; continue
        raise HushError(f"{name} (line {line}, column {col}) - invalid token '{c}'")
    out.append(Tok("EOF","<eof>",line,col))
    return out

def truth(v): return not (v is False or v is None)
def hstr(v, nested=False):
    if v is None: return "nil"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v,str): return '"' + v.replace("\\","\\\\").replace('"','\\"').replace("\n","\\n") + '"' if nested else v
    if isinstance(v,float) and v.is_integer(): return str(int(v))
    if isinstance(v,list): return "[ " + ", ".join(hstr(x, True) for x in v) + " ]"
    if isinstance(v,dict): return "@[ " + ", ".join(f'"{k}": {hstr(val, True)}' for k,val in v.items()) + " ]"
    return str(v)

class Env:
    def __init__(self, parent=None):
        self.parent=parent; self.vars={}
    def define(self,k,v=None): self.vars[k]=v
    def get(self,k):
        if k in self.vars: return self.vars[k]
        if self.parent: return self.parent.get(k)
        raise HushError(f"undeclared variable '{k}'")
    def set(self,k,v):
        if k in self.vars: self.vars[k]=v; return
        if self.parent: self.parent.set(k,v); return
        raise HushError(f"undeclared variable '{k}'")

class Function:
    def __init__(self, params, body, closure):
        self.params=params; self.body=body; self.closure=closure
    def __call__(self,*args):
        env=Env(self.closure)
        return self.call_in(env, args)
    def call_with_self(self, self_obj, args):
        env=Env(self.closure); env.define("self", self_obj)
        return self.call_in(env, args)
    def call_in(self, env, args):
        for i,p in enumerate(self.params): env.define(p, args[i] if i < len(args) else None)
        try:
            return exec_block(self.body, env)
        except ReturnSignal as r:
            return r.value

class BoundFunction:
    def __init__(self, fn, self_obj):
        self.fn=fn; self.self_obj=self_obj
    def __call__(self,*args):
        return self.fn.call_with_self(self.self_obj, args)

class Parser:
    def __init__(self,toks,name):
        self.t=toks; self.i=0; self.name=name
    def peek(self): return self.t[self.i]
    def val(self): return self.peek().val
    def at(self,*v): return self.val() in v or self.peek().kind in v
    def eat_nl(self):
        while self.peek().kind=="NL" or self.at(";"): self.i+=1
    def take(self,v=None):
        tok=self.peek()
        if v is not None and tok.val != v: self.err(f"unexpected '{tok.val}', expected '{v}'")
        self.i+=1; return tok
    def err(self,msg):
        tok=self.peek(); raise HushError(f"{self.name} (line {tok.line}, column {tok.col}) - {msg}")
    def parse(self, stops=("EOF",)):
        body=[]; self.eat_nl()
        while not self.at(*stops):
            body.append(self.stmt()); self.eat_nl()
        return body
    def stmt(self):
        if self.at("{"): return self.command_block()
        if self.at("let"):
            self.take("let"); name=self.take().val; expr=("lit",None)
            if self.at("="): self.take("="); expr=self.expr()
            return ("let",name,expr)
        if self.at("function") and self.t[self.i+1].kind=="ID":
            self.take("function"); name=self.take().val; params=self.params(); body=self.parse(("end",)); self.take("end")
            return ("let",name,("fun",params,body))
        if self.at("return"):
            self.take("return")
            return ("return", None if self.at("\n",";","end","else","EOF") else self.expr())
        if self.at("if"):
            self.take("if"); cond=self.expr(); self.take("then"); tb=self.parse(("else","end"))
            eb=[]
            if self.at("else"): self.take("else"); eb=self.parse(("end",))
            self.take("end"); return ("if",cond,tb,eb)
        if self.at("while"):
            self.take("while"); cond=self.expr(); self.take("do"); body=self.parse(("end",)); self.take("end"); return ("while",cond,body)
        if self.at("for"):
            self.take("for"); name=self.take().val; self.take("in"); it=self.expr(); self.take("do"); body=self.parse(("end",)); self.take("end")
            return ("for",name,it,body)
        expr=self.expr()
        if self.at("="):
            self.take("="); return ("assign",expr,self.expr())
        return ("expr",expr)
    def command_block(self):
        self.take("{"); parts=[]; cur=[]
        depth=1
        while depth and self.peek().kind!="EOF":
            tok=self.take()
            if tok.val=="{": depth+=1
            elif tok.val=="}":
                depth-=1
                if depth==0: break
            if depth==1 and tok.val in [";","\n"]:
                s=" ".join(cur).strip()
                if s: parts.append(s)
                cur=[]
            else:
                cur.append(tok.val if tok.kind!="STR" else tok.val)
        s=" ".join(cur).strip()
        if s: parts.append(s)
        return ("cmd",parts)
    def params(self):
        self.take("("); ps=[]; self.eat_nl()
        while not self.at(")"):
            if self.at(","): self.take(","); self.eat_nl(); continue
            ps.append(self.take().val)
            self.eat_nl()
            if self.at(","): self.take(","); self.eat_nl()
        self.take(")"); return ps
    def expr(self): return self.bin(0)
    def bin(self,minp):
        left=self.unary()
        prec={"or":1,"and":2,"==":3,"!=":3,"<":4,">":4,"<=":4,">=":4,"++":5,"+":5,"-":5,"*":6,"/":6,"%":6}
        while self.val() in prec and prec[self.val()] >= minp:
            op=self.take().val; right=self.bin(prec[op]+1); left=("bin",op,left,right)
        return left
    def unary(self):
        if self.at("not","-"): op=self.take().val; return ("un",op,self.unary())
        return self.postfix(self.primary())
    def primary(self):
        tok=self.peek()
        if tok.kind=="NUM":
            self.take(); return ("lit", float(tok.val) if any(c in tok.val for c in ".eE") else int(tok.val))
        if tok.kind=="STR": self.take(); return ("lit",tok.val)
        if self.at("true","false","nil"):
            v=self.take().val; return ("lit", True if v=="true" else False if v=="false" else None)
        if tok.kind=="ID": self.take(); return ("var",tok.val)
        if self.at("("): self.take("("); e=self.expr(); self.take(")"); return e
        if self.at("["):
            self.take("["); xs=[]; self.eat_nl()
            while not self.at("]"):
                if self.at(","): self.take(","); self.eat_nl(); continue
                xs.append(self.expr())
                self.eat_nl()
                if self.at(","): self.take(","); self.eat_nl()
            self.take("]"); return ("arr",xs)
        if self.at("@["):
            self.take("@["); items=[]; self.eat_nl()
            while not self.at("]"):
                if self.at(","): self.take(","); self.eat_nl(); continue
                key=self.take().val; self.take(":"); items.append((key,self.expr()))
                self.eat_nl()
                if self.at(","): self.take(","); self.eat_nl()
            self.take("]"); return ("dict",items)
        if self.at("$"):
            self.take("$"); cmd=self.command_block()
            return ("cmdexpr",cmd[1])
        if self.at("&"):
            self.take("&"); cmd=self.command_block()
            return ("async",cmd[1])
        if self.at("function"):
            self.take("function"); params=self.params(); body=self.parse(("end",)); self.take("end"); return ("fun",params,body)
        if self.at("if"):
            self.take("if"); c=self.expr(); self.take("then")
            tb=self.parse(("else","end")); eb=[]
            if self.at("else"): self.take("else"); eb=self.parse(("end",))
            self.take("end")
            return ("ifexpr",c,tb,eb)
        self.err(f"unexpected '{tok.val}'")
    def postfix(self,e):
        while True:
            if self.at("("):
                self.take("("); args=[]; self.eat_nl()
                while not self.at(")"):
                    if self.at(","): self.take(","); self.eat_nl(); continue
                    args.append(self.expr())
                    self.eat_nl()
                    if self.at(","): self.take(","); self.eat_nl()
                self.take(")"); e=("call",e,args)
            elif self.at("."):
                self.take("."); e=("attr",e,self.take().val)
            elif self.at("["):
                self.take("["); ix=self.expr(); self.take("]"); e=("idx",e,ix)
            else: break
        return e

def eval_expr(e, env):
    k=e[0]
    if k=="lit": return e[1]
    if k=="var": return env.get(e[1])
    if k=="arr": return [eval_expr(x,env) for x in e[1]]
    if k=="dict": return {key:eval_expr(v,env) for key,v in e[1]}
    if k=="fun": return Function(e[1],e[2],env)
    if k=="ifexpr": return exec_block(e[2] if truth(eval_expr(e[1],env)) else e[3], Env(env))
    if k=="un":
        v=eval_expr(e[2],env); return (not truth(v)) if e[1]=="not" else -v
    if k=="bin":
        op=e[1]
        if op=="and":
            l=eval_expr(e[2],env); return eval_expr(e[3],env) if truth(l) else l
        if op=="or":
            l=eval_expr(e[2],env); return l if truth(l) else eval_expr(e[3],env)
        a=eval_expr(e[2],env); b=eval_expr(e[3],env)
        return {"==":a==b,"!=":a!=b,"<":a<b,">":a>b,"<=":a<=b,">=":a>=b,
                "+":a+b,"-":a-b,"*":a*b,"/":a/b,"%":a%b,"++":hstr(a)+hstr(b)}[op]
    if k=="attr":
        obj=eval_expr(e[1],env)
        if isinstance(obj,dict):
            val=obj.get(e[2])
            return BoundFunction(val,obj) if isinstance(val,Function) else val
        return getattr(obj,e[2])
    if k=="idx":
        obj=eval_expr(e[1],env); ix=eval_expr(e[2],env); return obj[int(ix)]
    if k=="call":
        fn=eval_expr(e[1],env); args=[eval_expr(a,env) for a in e[2]]
        return fn(*args)
    if k=="cmdexpr":
        out=""; err=""; status=0
        for cmd in e[1]:
            r=subprocess.run(cmd, shell=True, text=True, capture_output=True)
            out += r.stdout; err += r.stderr; status=r.returncode
        return [out, err, status]
    if k=="async":
        def join():
            status=0
            for cmd in e[1]:
                status=subprocess.run(cmd, shell=True).returncode
            return status
        return {"join": join}
    raise HushError("internal error")

def assign(target, val, env):
    if target[0]=="var": env.set(target[1],val); return
    if target[0]=="attr":
        obj=eval_expr(target[1],env)
        if isinstance(obj,dict): obj[target[2]]=val; return
    if target[0]=="idx":
        obj=eval_expr(target[1],env); ix=int(eval_expr(target[2],env)); obj[ix]=val; return
    raise HushError("invalid assignment")

def exec_stmt(s, env):
    k=s[0]
    if k=="let": env.define(s[1],eval_expr(s[2],env)); return None
    if k=="assign": assign(s[1],eval_expr(s[2],env),env); return None
    if k=="expr": return eval_expr(s[1],env)
    if k=="return": raise ReturnSignal(None if s[1] is None else eval_expr(s[1],env))
    if k=="if": return exec_block(s[2] if truth(eval_expr(s[1],env)) else s[3], Env(env))
    if k=="while":
        last=None
        while truth(eval_expr(s[1],env)): last=exec_block(s[2], Env(env))
        return last
    if k=="for":
        last=None
        for v in eval_expr(s[2],env):
            child=Env(env); child.define(s[1],v); last=exec_block(s[3],child)
        return last
    if k=="cmd":
        status=0
        for cmd in s[1]:
            r=subprocess.run(cmd, shell=True)
            status=r.returncode
        return status

def exec_block(body, env):
    last=None
    for s in body: last=exec_stmt(s,env)
    return last

def std_env(argv, base_dir=None):
    e=Env()
    base_dir = base_dir or os.getcwd()
    std={}
    std["print"] = lambda *xs: (sys.stdout.write("".join(hstr(x) for x in xs)), sys.stdout.flush(), None)[2]
    std["len"] = lambda x: len(x)
    std["range"] = lambda a,b=None,c=1: list(range(int(a), int(b if b is not None else a), int(c)))
    std["push"] = lambda arr, val: (arr.append(val), None)[1]
    std["pop"] = lambda arr: arr.pop()
    std["type"] = lambda x: "nil" if x is None else "bool" if isinstance(x,bool) else "number" if isinstance(x,(int,float)) else "string" if isinstance(x,str) else "array" if isinstance(x,list) else "dict" if isinstance(x,dict) else "function"
    def imp(path):
        full = path if os.path.isabs(path) else os.path.join(base_dir, path)
        with open(full) as f: src=f.read()
        return run_src(src,full,Env(e))
    std["import"]=imp
    e.define("std",std); e.define("args",argv)
    return e

def run_src(src, name, env=None):
    p=Parser(lex(src,name),name); body=p.parse()
    return exec_block(body, env or std_env([], os.path.dirname(os.path.abspath(name)) or os.getcwd()))

def print_help():
    print("""Hush 0.1.4
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments""")

def main():
    args=sys.argv[1:]
    if not args:
        return 0
    if args[0] in ("-h","--help"): print_help(); return 0
    if args[0] in ("-V","--version"): print(VERSION); return 0
    mode=None
    if args[0] in ("--lex","--ast","--program","--check"):
        mode=args.pop(0)
    if not args:
        return 0
    name=args[0]
    try:
        src=open(name).read()
        if mode=="--lex":
            print("-"*50)
            for t in lex(src,name):
                if t.kind!="EOF" and t.kind!="NL": print(f"{name} (line {t.line}, column {t.col}):\t{t.val}")
            print("-"*50); return 0
        body=Parser(lex(src,name),name).parse()
        if mode in ("--check","--ast","--program"):
            if mode!="--check": print("-"*50); print(("AST for " if mode=="--ast" else "PROGRAM for ")+name); print("<parsed>"); print("-"*50)
            return 0
        exec_block(body,std_env(args[1:], os.path.dirname(os.path.abspath(name)) or os.getcwd()))
        return 0
    except HushError as ex:
        msg=str(ex)
        if not ("line " in msg and "column " in msg): msg=f"Error: {msg}"
        else: msg="Error: "+msg
        print(msg,file=sys.stderr); return 2
    except FileNotFoundError:
        print(f"Error: No such file or directory: {name}",file=sys.stderr); return 2

if __name__ == "__main__":
    sys.exit(main())
