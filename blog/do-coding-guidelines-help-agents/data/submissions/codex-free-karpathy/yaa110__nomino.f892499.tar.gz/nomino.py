#!/usr/bin/env python3
import argparse
import json
import os
import re
import shutil
import sys
from pathlib import Path


HELP = """Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...
          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>
          Sets the working directory

      --depth <DEPTH>
          Optional value to overwrite inferred subdirectory depth value in 'regex' mode

  -E, --no-extension
          Does not preserve the extension of input files in 'sort' and 'regex' options

  -g, --generate <PATH>
          Stores a JSON map file in '<PATH>' after renaming files

  -h, --help
          Print help (see a summary with '-h')

  -k, --mkdir
          Recursively creates all parent directories of '<OUTPUT>' if they are missing

  -m, --map <PATH>
          Sets the path of map file to be used for renaming files

          [aliases: --from-file]

      --max-depth <DEPTH>
          Optional value to set the maximum of subdirectory depth value in 'regex' mode

  -q, --quiet
          Does not print the map table to stdout

  -r, --regex <PATTERN>
          Regex pattern to match by filenames

  -s, --sort <ORDER>
          Sets the order of natural sorting (by name) to rename files using enumerator

          Possible values:
          - asc:  Sort in ascending order
          - desc: Sort in descending order

  -t, --test
          Runs in test mode without renaming actual files

          [aliases: --dry-run]

  -V, --version
          Print version

  -w, --overwrite
          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information.
"""


def natural_key(text):
    parts = re.split(r"(\d+)", str(text))
    return [int(p) if p.isdigit() else p.lower() for p in parts]


def extension_for(path):
    name = Path(path).name
    if "." not in name or name.startswith(".") and name.count(".") == 1:
        return ""
    return "." + name.rsplit(".", 1)[1]


def entries(root, recursive=False, max_depth=None):
    root = Path(root)
    if not recursive:
        return [p for p in root.iterdir() if p.name not in (".", "..")]
    out = []
    base_depth = len(root.parts)
    for current, dirs, files in os.walk(root):
        cur = Path(current)
        depth = len(cur.parts) - base_depth
        if max_depth is not None and depth >= max_depth:
            dirs[:] = []
        for name in dirs + files:
            out.append(cur / name)
    return out


def format_value(value, pad):
    value = str(value)
    if pad and re.fullmatch(r"\d+", value):
        return value.zfill(int(pad))
    return value


def expand(pattern, match=None, index=1):
    auto = 1

    def repl(m):
        nonlocal auto
        body = m.group(1)
        if ":" in body:
            group, pad = body.split(":", 1)
        else:
            group, pad = body, ""
        if group == "":
            value = index if match is None else group_value(match, str(auto))
            auto += 1
        elif match is None and group.isdigit():
            value = index if group == "0" else group
        elif match is None:
            value = index
        else:
            value = group_value(match, group)
        return format_value(value, pad)

    return re.sub(r"\{([^{}]*)\}", repl, pattern)


def group_value(match, group):
    if group.isdigit():
        idx = int(group)
        try:
            value = match.group(idx)
        except IndexError:
            value = ""
    else:
        try:
            value = match.group(group)
        except (IndexError, KeyError):
            value = ""
    return "" if value is None else value


def parse_regex(pattern):
    # Python accepts (?P<name>...) while Rust regex also commonly accepts (?<name>...).
    pattern = re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", pattern)
    return re.compile(pattern)


def display_path(root, path):
    try:
        return str(Path(path).resolve().relative_to(Path(root).resolve()))
    except ValueError:
        return str(path)


def avoid_conflict(root, src, dst, overwrite):
    dst_path = Path(root) / dst
    src_path = Path(root) / src
    if overwrite or dst_path.resolve() == src_path.resolve():
        return dst
    parent = dst_path.parent
    name = dst_path.name
    while dst_path.exists():
        name = "_" + name
        dst_path = parent / name
    try:
        return str(dst_path.relative_to(root))
    except ValueError:
        return str(dst_path)


def table(rows):
    in_w = max([5] + [len(a) for a, _ in rows])
    out_w = max([6] + [len(b) for _, b in rows])
    line = "+" + "-" * (in_w + 2) + "+" + "-" * (out_w + 2) + "+"
    print(line)
    print(f"| {'Input'.ljust(in_w)} | {'Output'.ljust(out_w)} |")
    print(line)
    for a, b in rows:
        print(f"| {a.ljust(in_w)} | {b.ljust(out_w)} |")
    print(line)


def coalesce_targets(rows):
    by_target = {}
    order = []
    for src, dst in rows:
        if dst not in by_target:
            order.append(dst)
        by_target[dst] = src
    return [(by_target[dst], dst) for dst in order]


def load_map(path):
    with open(path, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    if isinstance(data, dict):
        return [(str(k), str(v)) for k, v in data.items()]
    if isinstance(data, list):
        rows = []
        for item in data:
            if isinstance(item, dict):
                src = item.get("input") or item.get("source") or item.get("src")
                dst = item.get("output") or item.get("target") or item.get("dst")
                if src is not None and dst is not None:
                    rows.append((str(src), str(dst)))
        return rows
    return []


def build_parser():
    p = argparse.ArgumentParser(add_help=False, prog="executable")
    p.add_argument("-d", "--dir", default=".")
    p.add_argument("--depth", type=int)
    p.add_argument("--max-depth", type=int)
    p.add_argument("-E", "--no-extension", action="store_true")
    p.add_argument("-g", "--generate")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-k", "--mkdir", action="store_true")
    p.add_argument("-m", "--map", "--from-file", dest="map")
    p.add_argument("-q", "--quiet", action="store_true")
    p.add_argument("-r", "--regex")
    p.add_argument("-s", "--sort")
    p.add_argument("-t", "--test", "--dry-run", dest="test", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-w", "--overwrite", action="store_true")
    p.add_argument("patterns", nargs="*")
    return p


def main(argv):
    parser = build_parser()
    ns, unknown = parser.parse_known_args(argv)
    if unknown:
        print(f"error: unexpected argument '{unknown[0]}' found", file=sys.stderr)
        return 2
    if ns.help:
        print(HELP)
        return 0
    if ns.version:
        print("nomino 1.6.4")
        return 0
    if ns.sort not in (None, "asc", "desc"):
        print(f"error: invalid value '{ns.sort}' for '--sort <ORDER>'", file=sys.stderr)
        print("  [possible values: asc, desc]\n", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        return 2

    root = Path(ns.dir)
    try:
        os.chdir(root)
    except OSError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    root = Path(".")

    output = None
    regex_pat = ns.regex
    pats = list(ns.patterns)
    if pats:
        if len(pats) >= 2:
            regex_pat, output = pats[-2], pats[-1]
        else:
            output = pats[-1]

    try:
        rows = []
        if ns.map:
            rows = load_map(ns.map)
            rows = [(src, avoid_conflict(root, src, dst, ns.overwrite)) for src, dst in rows]
        elif ns.sort:
            if output is None:
                print("error: OUTPUT pattern is required", file=sys.stderr)
                return 1
            files = sorted(entries(root), key=lambda p: natural_key(p.name), reverse=ns.sort == "desc")
            for i, path in enumerate(files, 1):
                rel = display_path(root, path)
                dst = expand(output, None, i)
                if not ns.no_extension:
                    dst += extension_for(path)
                rows.append((rel, avoid_conflict(root, rel, dst, ns.overwrite)))
        elif regex_pat:
            if output is None:
                print("error: OUTPUT pattern is required", file=sys.stderr)
                return 1
            rx = parse_regex(regex_pat)
            max_depth = ns.depth if ns.depth is not None else ns.max_depth
            recursive = max_depth is not None and max_depth > 0
            candidates = sorted(entries(root, recursive=recursive, max_depth=max_depth), key=lambda p: natural_key(str(p)))
            idx = 1
            for path in candidates:
                rel = display_path(root, path)
                m = rx.search(rel)
                if not m:
                    continue
                dst = expand(output, m, idx)
                if not ns.no_extension:
                    dst += extension_for(path)
                rows.append((rel, avoid_conflict(root, rel, dst, ns.overwrite)))
                idx += 1
        else:
            print("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.", file=sys.stderr)
            print(f"usage: run '{sys.argv[0]} --help' for more information.", file=sys.stderr)
            return 1

        rows = coalesce_targets(rows)

        if ns.generate:
            with open(ns.generate, "w", encoding="utf-8") as fh:
                json.dump({dst: src for src, dst in rows}, fh, indent=2)
                fh.write("\n")

        if not ns.test:
            for src, dst in rows:
                dst_path = Path(dst)
                if ns.mkdir:
                    dst_path.parent.mkdir(parents=True, exist_ok=True)
                if ns.overwrite and dst_path.exists() and Path(src).resolve() != dst_path.resolve():
                    if dst_path.is_dir():
                        shutil.rmtree(dst_path)
                    else:
                        dst_path.unlink()
                try:
                    os.rename(src, dst)
                except OSError as e:
                    print(f"[error] unable to rename '{src}': {e.strerror} (os error {e.errno})", file=sys.stderr)
                    return 1

        if not ns.quiet:
            table(rows)
        return 0
    except Exception as e:
        print(f"error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
