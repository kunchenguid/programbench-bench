module reimpl-gomplate

go 1.21
