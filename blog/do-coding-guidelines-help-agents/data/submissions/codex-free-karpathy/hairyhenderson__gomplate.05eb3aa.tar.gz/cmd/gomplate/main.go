package main

import (
	"bytes"
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"html"
	"io"
	"math"
	"net"
	"net/url"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"text/template"
	"time"
)

type multiFlag []string

func (m *multiFlag) String() string { return strings.Join(*m, ",") }
func (m *multiFlag) Set(v string) error {
	*m = append(*m, v)
	return nil
}

type app struct {
	datasources map[string]string
	tmplPath    string
	tmpl        *template.Template
}

func main() {
	var datasources, contexts, templates multiFlag
	var in, file, out, left, right, missing, config, inputDir, outputDir, outputMap, chmod string
	var help, version, verbose, experimental, execPipe bool
	var ignored multiFlag
	flag.Var(&datasources, "d", "")
	flag.Var(&datasources, "datasource", "")
	flag.Var(&contexts, "c", "")
	flag.Var(&contexts, "context", "")
	flag.Var(&ignored, "H", "")
	flag.Var(&ignored, "datasource-header", "")
	flag.Var(&ignored, "plugin", "")
	flag.Var(&ignored, "exclude", "")
	flag.Var(&ignored, "exclude-processing", "")
	flag.Var(&ignored, "include", "")
	flag.Var(&templates, "t", "")
	flag.Var(&templates, "template", "")
	flag.StringVar(&file, "f", "-", "")
	flag.StringVar(&file, "file", "-", "")
	flag.StringVar(&in, "i", "", "")
	flag.StringVar(&in, "in", "", "")
	flag.StringVar(&inputDir, "input-dir", "", "")
	flag.StringVar(&out, "o", "-", "")
	flag.StringVar(&out, "out", "-", "")
	flag.StringVar(&outputDir, "output-dir", ".", "")
	flag.StringVar(&outputMap, "output-map", "", "")
	flag.StringVar(&chmod, "chmod", "", "")
	flag.BoolVar(&execPipe, "exec-pipe", false, "")
	flag.StringVar(&left, "left-delim", getenvDefault("GOMPLATE_LEFT_DELIM", "{{"), "")
	flag.StringVar(&right, "right-delim", getenvDefault("GOMPLATE_RIGHT_DELIM", "}}"), "")
	flag.StringVar(&missing, "missing-key", "error", "")
	flag.BoolVar(&experimental, "experimental", false, "")
	flag.StringVar(&config, "config", ".gomplate.yaml", "")
	flag.BoolVar(&verbose, "V", false, "")
	flag.BoolVar(&verbose, "verbose", false, "")
	flag.BoolVar(&help, "h", false, "")
	flag.BoolVar(&help, "help", false, "")
	flag.BoolVar(&version, "v", false, "")
	flag.BoolVar(&version, "version", false, "")
	flag.Usage = usage
	flag.Parse()
	_ = inputDir
	_ = outputDir
	_ = outputMap
	_ = chmod
	_ = execPipe
	_ = experimental
	_ = config
	_ = verbose
	if help {
		usage()
		return
	}
	if version {
		fmt.Println("gomplate version 0.0.0")
		return
	}

	a := &app{datasources: map[string]string{}}
	for _, d := range datasources {
		alias, target := parseDatasourceArg(d)
		a.datasources[alias] = target
	}

	var ctx any = rootContext()
	for _, c := range contexts {
		alias, target := parseDatasourceArg(c)
		val, err := a.readDatasource(target, "")
		if err != nil {
			exitErr(err)
		}
		if alias == "." {
			ctx = val
		} else if m, ok := ctx.(map[string]any); ok {
			m[alias] = val
		}
	}
	if inputDir != "" {
		if err := a.renderDir(inputDir, outputDir, left, right, missing, templates, ctx); err != nil {
			exitErr(err)
		}
		return
	}

	text, name, err := readInput(in, file)
	if err != nil {
		exitErr(err)
	}
	a.tmplPath = ""
	if in == "" && file != "" && file != "-" {
		a.tmplPath = file
	}
	a.tmpl = template.New(name).Delims(left, right).Funcs(a.funcMap())
	switch missing {
	case "zero":
		a.tmpl = a.tmpl.Option("missingkey=zero")
	case "default", "invalid":
		a.tmpl = a.tmpl.Option("missingkey=invalid")
	default:
		a.tmpl = a.tmpl.Option("missingkey=error")
	}
	for _, tf := range templates {
		b, err := os.ReadFile(tf)
		if err != nil {
			exitErr(err)
		}
		if _, err := a.tmpl.New(filepath.Base(tf)).Parse(string(b)); err != nil {
			exitErr(fmt.Errorf("parse template %s: %w", tf, err))
		}
	}
	if _, err := a.tmpl.Parse(text); err != nil {
		exitErr(fmt.Errorf("parse template %s: %w", name, err))
	}
	var buf bytes.Buffer
	if err := a.tmpl.ExecuteTemplate(&buf, name, ctx); err != nil {
		exitErr(fmt.Errorf("renderTemplate: failed to render template %s: %w", name, err))
	}
	if out == "" || out == "-" {
		fmt.Print(buf.String())
		return
	}
	if err := os.WriteFile(out, buf.Bytes(), 0o666); err != nil {
		exitErr(err)
	}
}

func (a *app) newTemplate(name, left, right, missing string) *template.Template {
	t := template.New(name).Delims(left, right).Funcs(a.funcMap())
	switch missing {
	case "zero":
		t = t.Option("missingkey=zero")
	case "default", "invalid":
		t = t.Option("missingkey=invalid")
	default:
		t = t.Option("missingkey=error")
	}
	return t
}

func (a *app) renderDir(inputDir, outputDir, left, right, missing string, templates []string, ctx any) error {
	return filepath.WalkDir(inputDir, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		info, err := d.Info()
		if err != nil {
			return err
		}
		b, err := os.ReadFile(path)
		if err != nil {
			return err
		}
		a.tmplPath = path
		a.tmpl = a.newTemplate(path, left, right, missing)
		for _, tf := range templates {
			tb, err := os.ReadFile(tf)
			if err != nil {
				return err
			}
			if _, err := a.tmpl.New(filepath.Base(tf)).Parse(string(tb)); err != nil {
				return fmt.Errorf("parse template %s: %w", tf, err)
			}
		}
		if _, err := a.tmpl.Parse(string(b)); err != nil {
			return fmt.Errorf("parse template %s: %w", path, err)
		}
		var out bytes.Buffer
		if err := a.tmpl.ExecuteTemplate(&out, path, ctx); err != nil {
			return fmt.Errorf("renderTemplate: failed to render template %s: %w", path, err)
		}
		rel, err := filepath.Rel(inputDir, path)
		if err != nil {
			return err
		}
		dest := filepath.Join(outputDir, rel)
		if err := os.MkdirAll(filepath.Dir(dest), 0o777); err != nil {
			return err
		}
		return os.WriteFile(dest, out.Bytes(), info.Mode())
	})
}

func usage() {
	fmt.Println(`Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -H, --datasource-header header     HTTP header field in 'alias=Name: value' form to be provided on HTTP-based data sources. Multiples can be set.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias ` + "`." + ` to set the root context.
      --plugin strings               plug in an external command as a function in name=path form. Can be specified multiple times
  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])
  -i, --in string                    Template string to process (alternative to --file and --input-dir)
      --input-dir directory          directory which is examined recursively for templates (alternative to --file and --in)
      --exclude strings              glob of files to not parse
      --exclude-processing strings   glob of files to be copied without parsing
      --include strings              glob of files to parse
  -o, --out file                     output file name. Omit to use standard output. (default [-])
  -t, --template strings             Additional template file(s)
      --output-dir directory         directory to store the processed templates. Only used for --input-dir (default ".")
      --output-map string            Template string to map the input file to an output path
      --chmod string                 set the mode for output file(s). Omit to inherit from input file(s)
      --exec-pipe                    pipe the output to the post-run exec command
      --left-delim delimiter         override the default left-delimiter [$GOMPLATE_LEFT_DELIM] (default "{{")
      --right-delim delimiter        override the default right-delimiter [$GOMPLATE_RIGHT_DELIM] (default "}}")
      --missing-key string           Control the behavior during execution if a map is indexed with a key that is not present in the map. error (default) - return an error, zero - fallback to zero value, default/invalid - print <no value> (default "error")
      --experimental                 enable experimental features [$GOMPLATE_EXPERIMENTAL]
  -V, --verbose                      output extra information about what gomplate is doing
      --config string                config file (overridden by commandline flags) (default ".gomplate.yaml")
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate`)
}

func exitErr(err error) {
	fmt.Fprintf(os.Stderr, `{"time":"%s","level":"ERROR","msg":"","err":%q}`+"\n", time.Now().UTC().Format(time.RFC3339Nano), err.Error())
	os.Exit(1)
}

func readInput(in, file string) (string, string, error) {
	if in != "" {
		return in, "<arg>", nil
	}
	if file == "" || file == "-" {
		b, err := io.ReadAll(os.Stdin)
		return string(b), "-", err
	}
	b, err := os.ReadFile(file)
	return string(b), file, err
}

func parseDatasourceArg(s string) (string, string) {
	if strings.Contains(s, "=") {
		p := strings.SplitN(s, "=", 2)
		return p[0], p[1]
	}
	alias := filepath.Base(s)
	alias = strings.TrimSuffix(alias, filepath.Ext(alias))
	return alias, s
}

func getenvDefault(k, d string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return d
}

func rootContext() map[string]any {
	return map[string]any{"Env": envMap()}
}

func envMap() map[string]string {
	m := map[string]string{}
	for _, e := range os.Environ() {
		p := strings.SplitN(e, "=", 2)
		m[p[0]] = p[1]
	}
	return m
}

func (a *app) funcMap() template.FuncMap {
	fm := template.FuncMap{}
	fm["env"] = func() envNS { return envNS{} }
	fm["getenv"] = envNS{}.Getenv
	fm["add"] = add
	fm["mul"] = mul
	fm["sub"] = sub
	fm["div"] = div
	fm["math"] = func() mathNS { return mathNS{} }
	fm["seq"] = seq
	fm["dict"] = dict
	fm["slice"] = slice
	fm["coll"] = func() collNS { return collNS{} }
	fm["strings"] = func() stringsNS { return stringsNS{} }
	fm["conv"] = func() convNS { return convNS{} }
	fm["data"] = func() dataNS { return dataNS{} }
	fm["file"] = func() fileNS { return fileNS{} }
	fm["path"] = func() pathNS { return pathNS{} }
	fm["filepath"] = func() filepathNS { return filepathNS{} }
	fm["net"] = func() netNS { return netNS{} }
	fm["time"] = func() timeNS { return timeNS{} }
	fm["uuid"] = func() uuidNS { return uuidNS{} }
	fm["crypto"] = func() cryptoNS { return cryptoNS{} }
	fm["base64"] = func() base64NS { return base64NS{} }
	fm["regexp"] = func() regexpNS { return regexpNS{} }
	fm["test"] = func() testNS { return testNS{} }
	fm["assert"] = testNS{}.Assert
	fm["fail"] = testNS{}.Fail
	fm["kind"] = kind
	fm["isKind"] = isKind
	fm["datasource"] = a.datasource
	fm["ds"] = a.datasource
	fm["include"] = a.include
	fm["datasourceExists"] = func(alias string) bool { _, ok := a.datasources[alias]; return ok }
	fm["datasourceReachable"] = func(alias string) bool { _, err := a.datasource(alias); return err == nil }
	fm["listDatasources"] = func() []string {
		keys := make([]string, 0, len(a.datasources))
		for k := range a.datasources {
			keys = append(keys, k)
		}
		sort.Strings(keys)
		return keys
	}
	fm["defineDatasource"] = func(alias, target string) string {
		if _, ok := a.datasources[alias]; !ok {
			a.datasources[alias] = target
		}
		return ""
	}
	fm["tmpl"] = func() tmplNS { return tmplNS{a: a} }
	fm["tpl"] = tmplNS{a: a}.Inline
	fm["html"] = html.EscapeString
	fm["toUpper"] = strings.ToUpper
	fm["toLower"] = strings.ToLower
	fm["title"] = strings.Title
	return fm
}

func (a *app) datasource(alias string, subpath ...string) (any, error) {
	target, ok := a.datasources[alias]
	if !ok {
		target = alias
	}
	sp := ""
	if len(subpath) > 0 {
		sp = subpath[0]
	}
	return a.readDatasource(target, sp)
}

func (a *app) include(alias string, subpath ...string) (string, error) {
	target, ok := a.datasources[alias]
	if !ok {
		target = alias
	}
	if len(subpath) > 0 && subpath[0] != "" {
		target = strings.TrimRight(target, "/") + "/" + subpath[0]
	}
	b, err := readURLish(target)
	return string(b), err
}

func (a *app) readDatasource(target, subpath string) (any, error) {
	if subpath != "" {
		target = strings.TrimRight(target, "/") + "/" + subpath
	}
	b, err := readURLish(target)
	if err != nil {
		return nil, err
	}
	typ := typeHint(target)
	return parseData(b, typ)
}

func readURLish(target string) ([]byte, error) {
	u, err := url.Parse(target)
	if err == nil {
		switch u.Scheme {
		case "env":
			name := strings.TrimPrefix(u.Path, "/")
			return []byte(os.Getenv(name)), nil
		case "stdin":
			return io.ReadAll(os.Stdin)
		case "file":
			return os.ReadFile(u.Path)
		case "":
		default:
			return nil, fmt.Errorf("unsupported datasource scheme %q", u.Scheme)
		}
	}
	return os.ReadFile(target)
}

func typeHint(target string) string {
	if u, err := url.Parse(target); err == nil {
		q := u.Query().Get("type")
		if q != "" {
			return q
		}
	}
	ext := strings.ToLower(filepath.Ext(strings.Split(target, "?")[0]))
	switch ext {
	case ".json":
		return "application/json"
	case ".yaml", ".yml":
		return "application/yaml"
	case ".csv":
		return "text/csv"
	case ".env":
		return "application/x-env"
	default:
		return "text/plain"
	}
}

func parseData(b []byte, typ string) (any, error) {
	switch {
	case strings.Contains(typ, "json"):
		var v any
		err := json.Unmarshal(b, &v)
		return v, err
	case strings.Contains(typ, "csv"):
		return csv.NewReader(bytes.NewReader(b)).ReadAll()
	case strings.Contains(typ, "x-env"):
		return parseEnvFile(string(b)), nil
	case strings.Contains(typ, "yaml") || strings.Contains(typ, "yml"):
		return parseSimpleYAML(string(b)), nil
	default:
		return string(b), nil
	}
}

func parseEnvFile(s string) map[string]string {
	m := map[string]string{}
	for _, line := range strings.Split(s, "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		line = strings.TrimPrefix(line, "export ")
		p := strings.SplitN(line, "=", 2)
		if len(p) == 2 {
			m[strings.TrimSpace(p[0])] = strings.Trim(strings.TrimSpace(p[1]), `"'`)
		}
	}
	return m
}

func parseSimpleYAML(s string) any {
	root := map[string]any{}
	stack := []map[string]any{root}
	indents := []int{0}
	for _, raw := range strings.Split(s, "\n") {
		if strings.TrimSpace(raw) == "" || strings.HasPrefix(strings.TrimSpace(raw), "#") {
			continue
		}
		indent := len(raw) - len(strings.TrimLeft(raw, " "))
		line := strings.TrimSpace(raw)
		for len(indents) > 1 && indent <= indents[len(indents)-1] {
			indents = indents[:len(indents)-1]
			stack = stack[:len(stack)-1]
		}
		p := strings.SplitN(line, ":", 2)
		if len(p) != 2 {
			continue
		}
		key := strings.TrimSpace(p[0])
		val := strings.TrimSpace(p[1])
		cur := stack[len(stack)-1]
		if val == "" {
			n := map[string]any{}
			cur[key] = n
			stack = append(stack, n)
			indents = append(indents, indent)
		} else if strings.HasPrefix(val, "[") && strings.HasSuffix(val, "]") {
			body := strings.TrimSpace(val[1 : len(val)-1])
			if body == "" {
				cur[key] = []any{}
			} else {
				parts := strings.Split(body, ",")
				arr := make([]any, len(parts))
				for i, part := range parts {
					arr[i] = scalar(strings.TrimSpace(part))
				}
				cur[key] = arr
			}
		} else {
			cur[key] = scalar(val)
		}
	}
	return root
}

func scalar(s string) any {
	s = strings.Trim(s, `"'`)
	if i, err := strconv.ParseInt(s, 0, 64); err == nil {
		return i
	}
	if f, err := strconv.ParseFloat(s, 64); err == nil && strings.ContainsAny(s, ".eE") {
		return f
	}
	if s == "true" {
		return true
	}
	if s == "false" {
		return false
	}
	return s
}

type envNS struct{}

func (envNS) Getenv(name string, def ...string) string {
	if v, ok := os.LookupEnv(name); ok {
		return v
	}
	if f, ok := os.LookupEnv(name + "_FILE"); ok {
		if b, err := os.ReadFile(f); err == nil {
			return strings.TrimRight(string(b), "\r\n")
		}
	}
	if len(def) > 0 {
		return def[0]
	}
	return ""
}
func (envNS) Env() map[string]string { return envMap() }
func (envNS) HasEnv(name string) bool {
	_, ok := os.LookupEnv(name)
	return ok
}
func (e envNS) ExpandEnv(in string) string { return os.Expand(in, func(k string) string { return e.Getenv(k) }) }

func nums(args ...any) ([]float64, bool) {
	fs := make([]float64, len(args))
	allInt := true
	for i, a := range args {
		switch v := a.(type) {
		case int:
			fs[i] = float64(v)
		case int64:
			fs[i] = float64(v)
		case float64:
			fs[i] = v
			allInt = false
		case string:
			if strings.ContainsAny(v, ".eE") || strings.EqualFold(v, "nan") || strings.Contains(strings.ToLower(v), "inf") {
				f, _ := strconv.ParseFloat(v, 64)
				fs[i] = f
				allInt = false
			} else {
				n, _ := strconv.ParseInt(v, 0, 64)
				fs[i] = float64(n)
			}
		default:
			rv := reflect.ValueOf(a)
			if rv.IsValid() && rv.CanInt() {
				fs[i] = float64(rv.Int())
			} else if rv.IsValid() && rv.CanFloat() {
				fs[i] = rv.Float()
				allInt = false
			}
		}
	}
	return fs, allInt
}

func add(args ...any) any {
	ns, allInt := nums(args...)
	var r float64
	for _, n := range ns {
		r += n
	}
	if allInt {
		return int64(r)
	}
	return r
}
func mul(args ...any) any {
	ns, allInt := nums(args...)
	r := float64(1)
	for _, n := range ns {
		r *= n
	}
	if allInt {
		return int64(r)
	}
	return r
}
func sub(a, b any) any {
	ns, allInt := nums(a, b)
	r := ns[0] - ns[1]
	if allInt {
		return int64(r)
	}
	return r
}
func div(a, b any) (float64, error) {
	ns, _ := nums(a, b)
	if ns[1] == 0 {
		return 0, errors.New("division by zero")
	}
	return ns[0] / ns[1], nil
}
func seq(args ...any) []int64 {
	start, end, step := int64(1), int64(0), int64(1)
	if len(args) == 1 {
		ns, _ := nums(args[0])
		end = int64(ns[0])
	} else if len(args) >= 2 {
		ns, _ := nums(args[0], args[1])
		start, end = int64(ns[0]), int64(ns[1])
		if len(args) >= 3 {
			ns, _ = nums(args[2])
			step = int64(ns[0])
		}
	}
	if step == 0 {
		return []int64{}
	}
	if end < start && step > 0 {
		step = -step
	}
	if end > start && step < 0 {
		step = -step
	}
	end -= (end - start) % step
	out := []int64{start}
	for out[len(out)-1] != end {
		out = append(out, out[len(out)-1]+step)
	}
	return out
}

type mathNS struct{}

func (mathNS) Add(args ...any) any { return add(args...) }
func (mathNS) Mul(args ...any) any { return mul(args...) }
func (mathNS) Sub(a, b any) any    { return sub(a, b) }
func (mathNS) Div(a, b any) (float64, error) { return div(a, b) }
func (mathNS) Seq(args ...any) []int64 { return seq(args...) }
func (mathNS) Abs(v any) any {
	ns, allInt := nums(v)
	r := math.Abs(ns[0])
	if allInt {
		return int64(r)
	}
	return r
}
func (mathNS) Ceil(v any) float64 {
	ns, _ := nums(v)
	return math.Ceil(ns[0])
}
func (mathNS) Floor(v any) float64 {
	ns, _ := nums(v)
	return math.Floor(ns[0])
}
func (mathNS) Round(v any) float64 {
	ns, _ := nums(v)
	return math.Round(ns[0])
}
func (mathNS) IsInt(v any) bool {
	_, allInt := nums(v)
	if s, ok := v.(string); ok {
		_, err := strconv.ParseInt(s, 0, 64)
		return err == nil
	}
	return allInt
}
func (mathNS) IsFloat(v any) bool {
	if s, ok := v.(string); ok {
		_, err := strconv.ParseFloat(s, 64)
		return err == nil && (strings.ContainsAny(s, ".eE") || strings.EqualFold(s, "nan") || strings.Contains(strings.ToLower(s), "inf"))
	}
	switch v.(type) {
	case float32, float64:
		return true
	default:
		return false
	}
}

func dict(vals ...any) (map[string]any, error) {
	if len(vals)%2 != 0 {
		return nil, errors.New("dict expects even number of args")
	}
	m := map[string]any{}
	for i := 0; i < len(vals); i += 2 {
		m[fmt.Sprint(vals[i])] = vals[i+1]
	}
	return m, nil
}
func slice(vals ...any) []any { return vals }

type collNS struct{}

func (collNS) Slice(vals ...any) []any { return vals }
func (collNS) Dict(vals ...any) (map[string]any, error) { return dict(vals...) }
func (collNS) Has(in any, key any) bool {
	rv := reflect.ValueOf(in)
	if rv.Kind() == reflect.Map {
		return rv.MapIndex(reflect.ValueOf(key)).IsValid()
	}
	if rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array {
		for i := 0; i < rv.Len(); i++ {
			if fmt.Sprint(rv.Index(i).Interface()) == fmt.Sprint(key) {
				return true
			}
		}
	}
	return false
}

type stringsNS struct{}

func (stringsNS) Contains(substr, in string) bool  { return strings.Contains(in, substr) }
func (stringsNS) HasPrefix(prefix, in string) bool { return strings.HasPrefix(in, prefix) }
func (stringsNS) HasSuffix(suffix, in string) bool { return strings.HasSuffix(in, suffix) }
func (stringsNS) ToUpper(s string) string          { return strings.ToUpper(s) }
func (stringsNS) ToLower(s string) string          { return strings.ToLower(s) }
func (stringsNS) Title(s string) string            { return strings.Title(s) }
func (stringsNS) Trim(s string) string             { return strings.TrimSpace(s) }
func (stringsNS) Replace(old, new string, n int, s string) string {
	return strings.Replace(s, old, new, n)
}
func (stringsNS) Split(sep, s string) []string { return strings.Split(s, sep) }
func (stringsNS) Join(sep string, ss []string) string {
	return strings.Join(ss, sep)
}
func (stringsNS) Indent(args ...any) string {
	width := 4
	indent := " "
	input := ""
	if len(args) == 1 {
		input = fmt.Sprint(args[0])
	} else if len(args) == 2 {
		ns, _ := nums(args[0])
		width = int(ns[0])
		input = fmt.Sprint(args[1])
	} else if len(args) >= 3 {
		ns, _ := nums(args[0])
		width = int(ns[0])
		indent = fmt.Sprint(args[1])
		input = fmt.Sprint(args[2])
	}
	pad := strings.Repeat(indent, width)
	lines := strings.Split(input, "\n")
	for i := range lines {
		lines[i] = pad + lines[i]
	}
	return strings.Join(lines, "\n")
}

type convNS struct{}

func (convNS) ToString(v any) string { return fmt.Sprint(v) }
func (convNS) ToInt(v any) int64 {
	ns, _ := nums(v)
	return int64(ns[0])
}
func (convNS) ToFloat(v any) float64 {
	ns, _ := nums(v)
	return ns[0]
}
func (convNS) ToBool(v any) bool {
	b, _ := strconv.ParseBool(fmt.Sprint(v))
	return b
}

type dataNS struct{}

func (dataNS) JSON(s string) (any, error)       { return parseData([]byte(s), "json") }
func (dataNS) YAML(s string) (any, error)       { return parseData([]byte(s), "yaml") }
func (dataNS) CSV(s string) (any, error)        { return parseData([]byte(s), "csv") }
func (dataNS) ToJSON(v any) (string, error)     { b, e := json.Marshal(v); return string(b), e }
func (dataNS) ToJSONPretty(v any) (string, error) { b, e := json.MarshalIndent(v, "", "  "); return string(b), e }

type fileNS struct{}

func (fileNS) Read(path string) (string, error) {
	b, err := os.ReadFile(path)
	return string(b), err
}
func (fileNS) Exists(path string) bool { _, err := os.Stat(path); return err == nil }
func (fileNS) Stat(path string) (os.FileInfo, error) { return os.Stat(path) }

type pathNS struct{}

func (pathNS) Base(s string) string  { return filepath.ToSlash(filepath.Base(s)) }
func (pathNS) Dir(s string) string   { return filepath.ToSlash(filepath.Dir(s)) }
func (pathNS) Ext(s string) string   { return filepath.Ext(s) }
func (pathNS) Clean(s string) string { return filepath.ToSlash(filepath.Clean(s)) }
func (pathNS) Join(parts ...string) string {
	return filepath.ToSlash(filepath.Join(parts...))
}

type filepathNS struct{}

func (filepathNS) Base(s string) string  { return filepath.Base(s) }
func (filepathNS) Dir(s string) string   { return filepath.Dir(s) }
func (filepathNS) Ext(s string) string   { return filepath.Ext(s) }
func (filepathNS) Clean(s string) string { return filepath.Clean(s) }
func (filepathNS) Join(parts ...string) string {
	return filepath.Join(parts...)
}

type netNS struct{}

func (netNS) LookupIP(name string) (string, error) {
	ips, err := netNS{}.LookupIPs(name)
	if err != nil || len(ips) == 0 {
		return "", err
	}
	return ips[0], nil
}
func (netNS) LookupIPs(name string) ([]string, error) {
	addrs, err := net.DefaultResolver.LookupIPAddr(context.Background(), name)
	if err != nil {
		return nil, err
	}
	out := []string{}
	seen := map[string]bool{}
	for _, a := range addrs {
		if a.IP.To4() != nil {
			s := a.IP.String()
			if !seen[s] {
				seen[s] = true
				out = append(out, s)
			}
		}
	}
	return out, nil
}
func (netNS) LookupCNAME(name string) (string, error) { return net.LookupCNAME(name) }
func (netNS) LookupTXT(name string) ([]string, error) { return net.LookupTXT(name) }

type timeNS struct{}

func (timeNS) Now() time.Time                       { return time.Now() }
func (timeNS) Parse(layout, value string) (time.Time, error) { return time.Parse(layout, value) }
func (timeNS) ParseDuration(s string) (time.Duration, error) { return time.ParseDuration(s) }
func (timeNS) RFC3339() string                      { return time.RFC3339 }
func (timeNS) Kitchen() string                      { return time.Kitchen }
func (timeNS) Hour(n ...int64) time.Duration {
	if len(n) == 0 {
		return time.Hour
	}
	return time.Duration(n[0]) * time.Hour
}
func (timeNS) Minute(n ...int64) time.Duration {
	if len(n) == 0 {
		return time.Minute
	}
	return time.Duration(n[0]) * time.Minute
}

type uuidNS struct{}

func (uuidNS) Nil() string { return "00000000-0000-0000-0000-000000000000" }
func (uuidNS) V4() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	b[6] = (b[6] & 0x0f) | 0x40
	b[8] = (b[8] & 0x3f) | 0x80
	return fmt.Sprintf("%08x-%04x-%04x-%04x-%012x", b[0:4], b[4:6], b[6:8], b[8:10], b[10:]), nil
}
func (uuidNS) IsValid(s string) bool {
	ok, _ := regexp.MatchString(`^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$`, s)
	return ok
}

type cryptoNS struct{}

func (cryptoNS) SHA256(s string) string {
	sum := sha256.Sum256([]byte(s))
	return hex.EncodeToString(sum[:])
}

type base64NS struct{}

func (base64NS) Encode(s string) string { return base64.StdEncoding.EncodeToString([]byte(s)) }
func (base64NS) Decode(s string) (string, error) {
	b, err := base64.StdEncoding.DecodeString(s)
	return string(b), err
}

type regexpNS struct{}

func (regexpNS) Match(expr, s string) (bool, error) { return regexp.MatchString(expr, s) }
func (regexpNS) Replace(expr, repl, s string) (string, error) {
	r, err := regexp.Compile(expr)
	if err != nil {
		return "", err
	}
	return r.ReplaceAllString(s, repl), nil
}

type testNS struct{}

func (testNS) Assert(args ...any) (string, error) {
	msg := ""
	val := false
	if len(args) == 1 {
		val = truthy(args[0])
	} else if len(args) > 1 {
		msg = fmt.Sprint(args[0])
		val = truthy(args[1])
	}
	if !val {
		if msg != "" {
			return "", fmt.Errorf("assertion failed: %s", msg)
		}
		return "", errors.New("assertion failed")
	}
	return "", nil
}
func (testNS) Fail(msg ...any) (string, error) {
	if len(msg) > 0 {
		return "", fmt.Errorf("template generation failed: %s", fmt.Sprint(msg[0]))
	}
	return "", errors.New("template generation failed")
}
func (testNS) Kind(v any) string { return kind(v) }
func (testNS) IsKind(k string, v any) bool { return isKind(k, v) }

func truthy(v any) bool {
	if b, ok := v.(bool); ok {
		return b
	}
	return !reflect.ValueOf(v).IsZero()
}
func kind(v any) string {
	if v == nil {
		return "invalid"
	}
	return reflect.TypeOf(v).Kind().String()
}
func isKind(k string, v any) bool {
	if k == "number" {
		switch reflect.TypeOf(v).Kind() {
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Float32, reflect.Float64:
			return true
		}
		return false
	}
	return kind(v) == k
}

type tmplNS struct{ a *app }

func (t tmplNS) Exec(name string, ctx ...any) (string, error) {
	c := any(nil)
	if len(ctx) > 0 {
		c = ctx[0]
	}
	var b bytes.Buffer
	err := t.a.tmpl.ExecuteTemplate(&b, name, c)
	return b.String(), err
}
func (t tmplNS) Inline(args ...any) (string, error) {
	name := ""
	in := ""
	var ctx any = rootContext()
	if len(args) == 1 {
		in = fmt.Sprint(args[0])
	} else if len(args) == 2 {
		in = fmt.Sprint(args[0])
		ctx = map[string]any{"Value": args[1]}
	} else if len(args) >= 3 {
		name = fmt.Sprint(args[0])
		in = fmt.Sprint(args[1])
		ctx = args[2]
	}
	tm := t.a.tmpl
	if name != "" {
		var err error
		tm, err = t.a.tmpl.New(name).Parse(in)
		if err != nil {
			return "", err
		}
		var b bytes.Buffer
		err = tm.ExecuteTemplate(&b, name, ctx)
		return b.String(), err
	}
	clone, err := t.a.tmpl.Clone()
	if err != nil {
		return "", err
	}
	clone, err = clone.New("_inline").Parse(in)
	if err != nil {
		return "", err
	}
	var b bytes.Buffer
	err = clone.ExecuteTemplate(&b, "_inline", ctx)
	return b.String(), err
}
func (t tmplNS) Path() string    { return t.a.tmplPath }
func (t tmplNS) PathDir() string { return filepath.Dir(t.a.tmplPath) }

var _ = math.Abs
