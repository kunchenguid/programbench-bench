#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <pwd.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define VERSION "htop 3.5.0-dev-878e0ce"

typedef struct {
    int pid;
    int ppid;
    unsigned long utime;
    unsigned long stime;
    long priority;
    long nice;
    unsigned long long starttime;
    char state;
    uid_t uid;
    unsigned long vsize;
    long rss_pages;
    char user[32];
    char command[512];
} Proc;

typedef struct {
    Proc *items;
    size_t len;
    size_t cap;
} ProcList;

static const char *program_name = "./executable";
static bool opt_no_meters = false;
static bool opt_no_function_bar = false;
static bool opt_tree = false;
static bool opt_no_color = false;
static const char *opt_filter = NULL;
static const char *opt_pid_list = NULL;
static const char *opt_user = NULL;
static const char *opt_sort = NULL;
static int max_iterations = -1;
static int delay_tenths = 15;

static const char *sort_help =
"                PID Process/thread ID\n"
"            Command Command line (insert as last column only)\n"
"              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)\n"
"               PPID Parent process ID\n"
"               PGRP Process group ID\n"
"            SESSION Process's session ID\n"
"                TTY Controlling terminal\n"
"              TPGID Process ID of the fg process group of the controlling terminal\n"
"             MINFLT Number of minor faults which have not required loading a memory page from disk\n"
"            CMINFLT Children processes' minor faults\n"
"             MAJFLT Number of major faults which have required loading a memory page from disk\n"
"            CMAJFLT Children processes' major faults\n"
"              UTIME User CPU time - time the process spent executing in user mode\n"
"              STIME System CPU time - time the kernel spent running system calls for this process\n"
"             CUTIME Children processes' user CPU time\n"
"             CSTIME Children processes' system CPU time\n"
"           PRIORITY Kernel's internal priority for the process\n"
"               NICE Nice value (the higher the value, the more it lets other processes take priority)\n"
"          STARTTIME Time the process was started\n"
"          PROCESSOR Id of the CPU the process last executed on\n"
"             M_VIRT Total program size in virtual memory\n"
"         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage\n"
"            M_SHARE Size of the process's shared pages\n"
"              M_TRS Size of the .text segment of the process (CODE)\n"
"              M_DRS Size of the .data segment plus stack usage of the process (DATA)\n"
"              M_LRS The library size of the process (calculated from memory maps)\n"
"             ST_UID User ID of the process owner\n"
"        PERCENT_CPU Percentage of the CPU time the process used in the last sampling\n"
"        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size\n"
"               USER Username of the process owner (or user ID if name cannot be determined)\n"
"               TIME Total time the process has spent in user and system time\n"
"               NLWP Number of threads in the process\n"
"               TGID Thread group ID (i.e. process ID)\n"
"   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)\n"
"            ELAPSED Time since the process was started\n"
"    SCHEDULERPOLICY Current scheduling policy of the process\n"
"              RCHAR Number of bytes the process has read\n"
"              WCHAR Number of bytes the process has written\n"
"              SYSCR Number of read(2) syscalls for the process\n"
"              SYSCW Number of write(2) syscalls for the process\n"
"             RBYTES Bytes of read(2) I/O for the process\n"
"             WBYTES Bytes of write(2) I/O for the process\n"
"             CNCLWB Bytes of cancelled write(2) I/O\n"
"       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process\n"
"      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process\n"
"            IO_RATE Total I/O rate in bytes per second\n"
"             CGROUP Which cgroup the process is in\n"
"                OOM OOM (Out-of-Memory) killer score\n"
"        IO_PRIORITY I/O priority\n"
"              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it\n"
"             M_SWAP Size of the process's swapped pages\n"
"            M_PSSWP shows proportional swap share of this mapping, unlike \"Swap\", this does not take into account swapped out page of underlying shmem objects\n"
"               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)\n"
"            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)\n"
"               COMM comm string of the process from /proc/[pid]/comm\n"
"                EXE Basename of exe of the process from /proc/[pid]/exe\n"
"                CWD The current working directory of the process\n"
"       AUTOGROUP_ID The autogroup identifier of the process\n"
"     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup\n"
"            CCGROUP Which cgroup the process is in (condensed to essentials)\n"
"          CONTAINER Name of the container the process is in (guessed by heuristics)\n"
"             M_PRIV The private memory size of the process - resident set size minus shared memory\n"
"           GPU_TIME Total GPU time\n"
"        GPU_PERCENT Percentage of the GPU time the process used in the last sampling\n"
"        ISCONTAINER Whether the process is running inside a child container\n";

static void print_help(void) {
    printf("%s\n", VERSION);
    printf("(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.\n");
    printf("Released under the GNU GPLv2+.\n\n");
    printf("-C --no-color                   Use a monochrome color scheme\n");
    printf("-d --delay=DELAY                Set the delay between updates, in tenths of seconds\n");
    printf("-F --filter=FILTER              Show only the commands matching the given filter\n");
    printf("   --no-function-bar             Hide the function bar\n");
    printf("-h --help                       Print this help screen\n");
    printf("-H --highlight-changes[=DELAY]  Highlight new and old processes\n");
    printf("-M --no-mouse                   Disable the mouse\n");
    printf("   --no-meters                  Hide meters\n");
    printf("-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates\n");
    printf("-p --pid=PID[,PID,PID...]       Show only the given PIDs\n");
    printf("   --readonly                   Disable all system and process changing features\n");
    printf("-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)\n");
    printf("-t --tree                       Show the tree view (can be combined with -s)\n");
    printf("-u --user[=USERNAME]            Show only processes for a given user (or $USER)\n");
    printf("-U --no-unicode                 Do not use unicode but plain ASCII\n");
    printf("-V --version                    Print version info\n\n");
    printf("Press F1 inside htop for online help.\n");
    printf("See 'man htop' for more information.\n");
}

static bool parse_positive_int(const char *s, long *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !s[0] || *end) return false;
    *out = v;
    return true;
}

static bool is_valid_sort_key(const char *s) {
    const char *keys[] = {"PID","Command","STATE","PPID","PGRP","SESSION","TTY","TPGID","MINFLT","CMINFLT","MAJFLT","CMAJFLT","UTIME","STIME","CUTIME","CSTIME","PRIORITY","NICE","STARTTIME","PROCESSOR","M_VIRT","M_RESIDENT","M_SHARE","M_TRS","M_DRS","M_LRS","ST_UID","PERCENT_CPU","PERCENT_MEM","USER","TIME","NLWP","TGID","PERCENT_NORM_CPU","ELAPSED","SCHEDULERPOLICY","RCHAR","WCHAR","SYSCR","SYSCW","RBYTES","WBYTES","CNCLWB","IO_READ_RATE","IO_WRITE_RATE","IO_RATE","CGROUP","OOM","IO_PRIORITY","M_PSS","M_SWAP","M_PSSWP","CTXT","SECATTR","COMM","EXE","CWD","AUTOGROUP_ID","AUTOGROUP_NICE","CCGROUP","CONTAINER","M_PRIV","GPU_TIME","GPU_PERCENT","ISCONTAINER", NULL};
    for (int i = 0; keys[i]; i++) {
        if (strcasecmp(s, keys[i]) == 0) return true;
    }
    return false;
}

static void append_proc(ProcList *list, Proc p) {
    if (list->len == list->cap) {
        size_t nc = list->cap ? list->cap * 2 : 64;
        Proc *np = realloc(list->items, nc * sizeof(*np));
        if (!np) exit(2);
        list->items = np;
        list->cap = nc;
    }
    list->items[list->len++] = p;
}

static void trim_newline(char *s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = 0;
}

static void read_cmdline(int pid, char *buf, size_t len) {
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/cmdline", pid);
    FILE *f = fopen(path, "rb");
    if (f) {
        size_t n = fread(buf, 1, len - 1, f);
        fclose(f);
        if (n) {
            for (size_t i = 0; i < n; i++) if (buf[i] == '\0') buf[i] = ' ';
            buf[n] = 0;
            while (n && buf[n - 1] == ' ') buf[--n] = 0;
            if (buf[0]) return;
        }
    }
    snprintf(path, sizeof(path), "/proc/%d/comm", pid);
    f = fopen(path, "r");
    if (f) {
        if (fgets(buf, (int)len, f)) trim_newline(buf);
        fclose(f);
    }
}

static bool read_proc(int pid, Proc *p) {
    char path[64], line[4096];
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    FILE *f = fopen(path, "r");
    if (!f) return false;
    if (!fgets(line, sizeof(line), f)) {
        fclose(f);
        return false;
    }
    fclose(f);
    char *rp = strrchr(line, ')');
    char *lp = strchr(line, '(');
    if (!lp || !rp || rp[1] != ' ') return false;
    char *rest = rp + 2;
    char state;
    int ppid;
    unsigned long utime = 0, stime = 0;
    long priority = 0, nice = 0;
    unsigned long long starttime = 0;
    unsigned long vsize = 0;
    long rss = 0;
    int got = sscanf(rest,
        "%c %d %*d %*d %*d %*d %*u %*u %*u %*u %*u %lu %lu %*d %*d %ld %ld %*d %*d %llu %lu %ld",
        &state, &ppid, &utime, &stime, &priority, &nice, &starttime, &vsize, &rss);
    if (got < 9) return false;
    memset(p, 0, sizeof(*p));
    p->pid = pid;
    p->ppid = ppid;
    p->state = state;
    p->utime = utime;
    p->stime = stime;
    p->priority = priority;
    p->nice = nice;
    p->starttime = starttime;
    p->vsize = vsize;
    p->rss_pages = rss;
    read_cmdline(pid, p->command, sizeof(p->command));
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    f = fopen(path, "r");
    if (f) {
        while (fgets(line, sizeof(line), f)) {
            if (strncmp(line, "Uid:", 4) == 0) {
                unsigned uid = 0;
                sscanf(line + 4, "%u", &uid);
                p->uid = (uid_t)uid;
                break;
            }
        }
        fclose(f);
    }
    struct passwd *pw = getpwuid(p->uid);
    if (pw) snprintf(p->user, sizeof(p->user), "%s", pw->pw_name);
    else snprintf(p->user, sizeof(p->user), "%u", (unsigned)p->uid);
    return true;
}

static bool pid_selected(int pid) {
    if (!opt_pid_list) return true;
    const char *s = opt_pid_list;
    while (*s) {
        while (*s == ',') s++;
        char *end = NULL;
        long v = strtol(s, &end, 10);
        if (end != s && v == pid) return true;
        if (end == s) {
            while (*s && *s != ',') s++;
        } else {
            s = end;
        }
    }
    return false;
}

static bool contains_casefold(const char *hay, const char *needle) {
    if (!needle || !needle[0]) return true;
    size_t hn = strlen(hay), nn = strlen(needle);
    if (nn > hn) return false;
    for (size_t i = 0; i + nn <= hn; i++) {
        size_t j = 0;
        for (; j < nn; j++) {
            if (tolower((unsigned char)hay[i + j]) != tolower((unsigned char)needle[j])) break;
        }
        if (j == nn) return true;
    }
    return false;
}

static bool filter_selected(const char *cmd) {
    if (!opt_filter) return true;
    char *copy = strdup(opt_filter);
    if (!copy) return true;
    bool ok = false;
    for (char *tok = strtok(copy, "|"); tok; tok = strtok(NULL, "|")) {
        if (contains_casefold(cmd, tok)) {
            ok = true;
            break;
        }
    }
    free(copy);
    return ok;
}

static bool user_selected(const Proc *p) {
    if (!opt_user) return true;
    char *end = NULL;
    long uid = strtol(opt_user, &end, 10);
    if (*opt_user && !*end) return p->uid == (uid_t)uid;
    return strcmp(p->user, opt_user) == 0;
}

static ProcList collect_processes(void) {
    ProcList list = {0};
    DIR *d = opendir("/proc");
    if (!d) return list;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (!isdigit((unsigned char)de->d_name[0])) continue;
        int pid = atoi(de->d_name);
        Proc p;
        if (!read_proc(pid, &p)) continue;
        if (!pid_selected(pid) || !user_selected(&p) || !filter_selected(p.command)) continue;
        append_proc(&list, p);
    }
    closedir(d);
    return list;
}

static int cmp_pid(const void *a, const void *b) {
    const Proc *pa = a, *pb = b;
    return (pa->pid > pb->pid) - (pa->pid < pb->pid);
}

static int cmp_mem(const void *a, const void *b) {
    const Proc *pa = a, *pb = b;
    return (pb->rss_pages > pa->rss_pages) - (pb->rss_pages < pa->rss_pages);
}

static int cmp_user(const void *a, const void *b) {
    const Proc *pa = a, *pb = b;
    int c = strcmp(pa->user, pb->user);
    return c ? c : cmp_pid(a, b);
}

static void sort_processes(ProcList *list) {
    if (opt_sort && strcasecmp(opt_sort, "M_RESIDENT") == 0) qsort(list->items, list->len, sizeof(Proc), cmp_mem);
    else if (opt_sort && strcasecmp(opt_sort, "USER") == 0) qsort(list->items, list->len, sizeof(Proc), cmp_user);
    else qsort(list->items, list->len, sizeof(Proc), cmp_pid);
}

static unsigned long long read_mem_total_kb(void) {
    FILE *f = fopen("/proc/meminfo", "r");
    char key[64], unit[32];
    unsigned long long val = 0;
    if (!f) return 0;
    while (fscanf(f, "%63s %llu %31s", key, &val, unit) == 3) {
        if (strcmp(key, "MemTotal:") == 0) {
            fclose(f);
            return val;
        }
    }
    fclose(f);
    return 0;
}

static void print_size_kb(unsigned long long kb, char *out, size_t len) {
    if (kb >= 1024ULL * 1024ULL) snprintf(out, len, "%.1fG", kb / (1024.0 * 1024.0));
    else if (kb >= 1024ULL) snprintf(out, len, "%lluM", kb / 1024ULL);
    else snprintf(out, len, "%lluK", kb);
}

static void print_time_ticks(unsigned long ticks, char *out, size_t len) {
    long hz = sysconf(_SC_CLK_TCK);
    if (hz <= 0) hz = 100;
    unsigned long sec = ticks / (unsigned long)hz;
    snprintf(out, len, "%lu:%02lu.%02lu", sec / 60, sec % 60, (ticks % (unsigned long)hz) * 100 / (unsigned long)hz);
}

static void print_snapshot(void) {
    ProcList list = collect_processes();
    sort_processes(&list);
    int rows = 24, cols = 80;
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0) {
        if (ws.ws_row) rows = ws.ws_row;
        if (ws.ws_col) cols = ws.ws_col;
    }
    if (cols < 60) cols = 60;
    if (!opt_no_color) printf("\033[?1049h\033[H\033[2J\033[?25l");
    if (!opt_no_meters) {
        long cpus = sysconf(_SC_NPROCESSORS_ONLN);
        if (cpus < 1) cpus = 1;
        printf("  CPU[");
        int bars = cols > 100 ? 40 : 20;
        for (int i = 0; i < bars; i++) putchar(i < 2 ? '|' : ' ');
        printf("] 0.0%%\n");
        unsigned long long total = read_mem_total_kb();
        char mem[32];
        print_size_kb(total, mem, sizeof(mem));
        printf("  Mem[||                  ] 0K/%s   Tasks: %zu, 0 thr; 1 running\n", mem, list.len);
        double la[3] = {0,0,0};
        getloadavg(la, 3);
        printf("  Swp[                    ] 0K/0K    Load average: %.2f %.2f %.2f\n", la[0], la[1], la[2]);
        struct timespec ts;
        if (clock_gettime(CLOCK_BOOTTIME, &ts) == 0) {
            long days = ts.tv_sec / 86400;
            long h = (ts.tv_sec / 3600) % 24, m = (ts.tv_sec / 60) % 60, s = ts.tv_sec % 60;
            printf("                                   Uptime: %ld days, %02ld:%02ld:%02ld\n", days, h, m, s);
        }
        printf("\n");
    }
    printf("  [Main]%s\n", opt_tree ? " [Tree]" : "");
    printf("  PID USER       PRI  NI  VIRT   RES S  CPU%% MEM%%   TIME+  Command\n");
    long page_kb = sysconf(_SC_PAGESIZE) / 1024;
    unsigned long long memtotal = read_mem_total_kb();
    int used_rows = opt_no_meters ? 2 : 7;
    int max_rows = rows - used_rows - (opt_no_function_bar ? 1 : 2);
    if (max_rows < 1) max_rows = 1;
    for (size_t i = 0; i < list.len && (int)i < max_rows; i++) {
        Proc *p = &list.items[i];
        char virt[16], res[16], tbuf[32];
        unsigned long long reskb = (unsigned long long)(p->rss_pages > 0 ? p->rss_pages : 0) * (unsigned long long)page_kb;
        print_size_kb(p->vsize / 1024, virt, sizeof(virt));
        print_size_kb(reskb, res, sizeof(res));
        print_time_ticks(p->utime + p->stime, tbuf, sizeof(tbuf));
        double memp = memtotal ? (100.0 * (double)reskb / (double)memtotal) : 0.0;
        char user[11];
        snprintf(user, sizeof(user), "%s", p->user);
        printf("%5d %-10s %3ld %3ld %5s %5s %c %5.1f %4.1f %8s  %.*s\n",
               p->pid, user, p->priority, p->nice, virt, res, p->state, 0.0, memp, tbuf,
               cols > 65 ? cols - 65 : 20, p->command[0] ? p->command : "-");
    }
    if (!opt_no_function_bar) {
        printf("F1Help F2Setup F3Search F4Filter F5Tree F6SortBy F7Nice - F8Nice + F9Kill F10Quit\n");
    }
    if (!opt_no_color) printf("\033[?25h\033[?1049l");
    free(list.items);
}

static void validate_user_or_die(const char *u) {
    if (!u) return;
    char *end = NULL;
    long uid = strtol(u, &end, 10);
    if (*u && !*end) {
        if (getpwuid((uid_t)uid)) return;
    } else if (getpwnam(u)) {
        return;
    }
    fprintf(stderr, "Error: invalid user \"%s\".\n", u);
    exit(1);
}

int main(int argc, char **argv) {
    program_name = argv[0] ? argv[0] : "./executable";
    enum { OPT_NO_FUNCTION_BAR = 1000, OPT_NO_METERS, OPT_READONLY };
    static const struct option long_options[] = {
        {"no-color", no_argument, 0, 'C'},
        {"no-colour", no_argument, 0, 'C'},
        {"delay", required_argument, 0, 'd'},
        {"filter", required_argument, 0, 'F'},
        {"no-function-bar", no_argument, 0, OPT_NO_FUNCTION_BAR},
        {"help", no_argument, 0, 'h'},
        {"highlight-changes", optional_argument, 0, 'H'},
        {"no-mouse", no_argument, 0, 'M'},
        {"no-meters", no_argument, 0, OPT_NO_METERS},
        {"max-iterations", required_argument, 0, 'n'},
        {"pid", required_argument, 0, 'p'},
        {"readonly", no_argument, 0, OPT_READONLY},
        {"sort-key", required_argument, 0, 's'},
        {"tree", no_argument, 0, 't'},
        {"user", optional_argument, 0, 'u'},
        {"no-unicode", no_argument, 0, 'U'},
        {"version", no_argument, 0, 'V'},
        {0,0,0,0}
    };
    opterr = 1;
    int c;
    while ((c = getopt_long(argc, argv, "Cd:F:hH::Mn:p:s:tu::UV", long_options, NULL)) != -1) {
        long v;
        switch (c) {
            case 'C': opt_no_color = true; break;
            case 'd':
                if (!parse_positive_int(optarg, &v)) {
                    fprintf(stderr, "Error: invalid delay value \"%s\".\n", optarg);
                    return 1;
                }
                if (v < 1) v = 1;
                if (v > 100) v = 100;
                delay_tenths = (int)v;
                break;
            case 'F': opt_filter = optarg; break;
            case 'h': print_help(); return 0;
            case 'H':
                if (!optarg && optind < argc && argv[optind][0] != '-') optarg = argv[optind++];
                if (optarg && !parse_positive_int(optarg, &v)) {
                    fprintf(stderr, "Error: invalid highlight delay value \"%s\".\n", optarg);
                    return 1;
                }
                break;
            case 'M': break;
            case 'n':
                if (!parse_positive_int(optarg, &v)) {
                    fprintf(stderr, "Error: invalid maximum iteration count \"%s\".\n", optarg);
                    return 1;
                }
                if (v <= 0) {
                    fprintf(stderr, "Error: maximum iteration count must be positive.\n");
                    return 1;
                }
                max_iterations = (int)v;
                break;
            case 'p': opt_pid_list = optarg; break;
            case 's':
                if (strcasecmp(optarg, "help") == 0) {
                    fputs(sort_help, stdout);
                    return 0;
                }
                if (!is_valid_sort_key(optarg)) {
                    fprintf(stderr, "Error: invalid column \"%s\".\n", optarg);
                    return 1;
                }
                opt_sort = optarg;
                break;
            case 't': opt_tree = true; break;
            case 'u':
                if (!optarg && optind < argc && argv[optind][0] != '-') optarg = argv[optind++];
                opt_user = optarg ? optarg : getenv("USER");
                break;
            case 'U': break;
            case 'V': printf("%s\n", VERSION); return 0;
            case OPT_NO_FUNCTION_BAR: opt_no_function_bar = true; break;
            case OPT_NO_METERS: opt_no_meters = true; break;
            case OPT_READONLY: break;
            case '?': return 1;
            default: break;
        }
    }
    if (optind < argc) {
        fprintf(stderr, "Error: unsupported non-option ARGV-elements: %s\n", argv[optind]);
        return 1;
    }
    (void)program_name;
    validate_user_or_die(opt_user);
    const char *term = getenv("TERM");
    if (!term || !*term || strcmp(term, "unknown") == 0) {
        fprintf(stderr, "Error opening terminal: unknown.\n");
        return 1;
    }
    int iterations = max_iterations > 0 ? max_iterations : 1;
    for (int i = 0; i < iterations; i++) {
        if (i) usleep((useconds_t)delay_tenths * 100000);
        print_snapshot();
    }
    return 0;
}
