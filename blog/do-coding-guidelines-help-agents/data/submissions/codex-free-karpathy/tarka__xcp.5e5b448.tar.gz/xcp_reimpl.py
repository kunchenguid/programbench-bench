#!/usr/bin/env python3
import fnmatch
import glob as globmod
import os
import shutil
import stat
import sys

VERSION = "xcp 0.24.3"


class XcpError(Exception):
    pass


def print_help(long=False):
    if long:
        print("""A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          Path list.

Options:
  -v, --verbose...
          Verbosity.
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers.

          [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations.

          [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present.
  -g, --glob
          Expand file patterns.
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership.
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel'.

          [default: parfile]
  -T, --no-target-directory
          Target should not be a directory.
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options.

          [default: auto]
      --backup <BACKUP>
          Backup options

          [default: none]
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version""")
    else:
        print("""A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Path list

Options:
  -v, --verbose...
          Verbosity
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present
  -g, --glob
          Expand file patterns
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel' [default: parfile]
  -T, --no-target-directory
          Target should not be a directory
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options [default: auto]
      --backup <BACKUP>
          Backup options [default: none]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version""")


def parse(argv):
    opts = {
        "recursive": False, "dereference": False, "no_clobber": False,
        "force": False, "glob": False, "gitignore": False, "no_perms": False,
        "no_timestamps": False, "ownership": False, "target_directory": None,
        "no_target_directory": False, "fsync": False, "backup": "none",
        "driver": "parfile", "reflink": "auto", "paths": []
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opts["paths"].extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print_help(a == "--help")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a.startswith("--"):
            name, val = (a[2:].split("=", 1) + [None])[:2] if "=" in a else (a[2:], None)
            if name in ("workers", "block-size", "driver", "reflink", "backup", "target-directory"):
                if val is None:
                    i += 1
                    if i >= len(argv):
                        raise XcpError(f"Invalid arguments: Missing value for --{name}")
                    val = argv[i]
                if name == "driver":
                    if val not in ("parfile", "parblock", "file-parallel"):
                        print(f"error: invalid value '{val}' for '--driver <DRIVER>': Unknown driver: {val}\n\nFor more information, try '--help'.", file=sys.stderr)
                        sys.exit(2)
                    opts["driver"] = val
                elif name == "reflink":
                    if val not in ("auto", "always", "never"):
                        print(f"error: invalid value '{val}' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': {val}\n\nFor more information, try '--help'.", file=sys.stderr)
                        sys.exit(2)
                    opts["reflink"] = val
                elif name == "backup":
                    if val in ("off", "none"):
                        opts["backup"] = "none"
                    elif val in ("numbered", "auto"):
                        opts["backup"] = val
                    else:
                        raise XcpError(f"Invalid arguments: Unexpected value for 'backup': {val}")
                elif name == "target-directory":
                    opts["target_directory"] = val
                i += 1
                continue
            flags = {
                "recursive": "recursive", "dereference": "dereference",
                "no-clobber": "no_clobber", "force": "force",
                "glob": "glob", "gitignore": "gitignore",
                "no-progress": "no_progress", "no-perms": "no_perms",
                "no-timestamps": "no_timestamps", "ownership": "ownership",
                "no-target-directory": "no_target_directory", "fsync": "fsync",
            }
            if name not in flags:
                raise XcpError(f"Invalid arguments: Unknown option: --{name}")
            opts[flags[name]] = True
        elif a.startswith("-") and a != "-":
            j = 1
            while j < len(a):
                c = a[j]
                if c == "v":
                    pass
                elif c == "r":
                    opts["recursive"] = True
                elif c == "L":
                    opts["dereference"] = True
                elif c == "n":
                    opts["no_clobber"] = True
                elif c == "f":
                    opts["force"] = True
                elif c == "g":
                    opts["glob"] = True
                elif c == "o":
                    opts["ownership"] = True
                elif c == "T":
                    opts["no_target_directory"] = True
                elif c == "w":
                    if j != len(a) - 1:
                        break
                    i += 1
                    break
                else:
                    raise XcpError(f"Invalid arguments: Unknown option: -{c}")
                j += 1
        else:
            opts["paths"].append(a)
        i += 1
    if opts["force"] and opts["no_clobber"]:
        raise XcpError("Invalid arguments: --force and --noclobber cannot be set at the same time.")
    return opts


def copy_metadata(src, dst, opts, follow):
    try:
        st = os.stat(src, follow_symlinks=follow)
        if not opts["no_perms"]:
            try:
                os.chmod(dst, stat.S_IMODE(st.st_mode), follow_symlinks=follow)
            except NotImplementedError:
                pass
        if not opts["no_timestamps"]:
            try:
                os.utime(dst, ns=(st.st_atime_ns, st.st_mtime_ns), follow_symlinks=follow)
            except NotImplementedError:
                pass
        if opts["ownership"]:
            try:
                os.chown(dst, st.st_uid, st.st_gid, follow_symlinks=follow)
            except OSError as e:
                print(f"Warning: Failed to set ownership: {e}", file=sys.stderr)
    except OSError:
        pass


def numbered_backup_path(path):
    n = 1
    while os.path.exists(f"{path}.~{n}~") or os.path.islink(f"{path}.~{n}~"):
        n += 1
    return f"{path}.~{n}~"


def maybe_backup(path, mode):
    if mode == "none" or not (os.path.exists(path) or os.path.islink(path)):
        return
    if mode == "auto":
        if not globmod.glob(path + ".~[0-9]*~"):
            return
    os.rename(path, numbered_backup_path(path))


def ignore_match(rel, is_dir, patterns):
    rel = rel.strip("/")
    base = os.path.basename(rel)
    ignored = False
    for pat in patterns:
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        dir_only = pat.endswith("/")
        pat = pat.strip("/")
        if not pat or pat.startswith("#"):
            continue
        hit = False
        if dir_only and is_dir:
            hit = fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(base, pat)
        elif "/" in pat:
            hit = fnmatch.fnmatch(rel, pat)
        else:
            hit = fnmatch.fnmatch(base, pat) or fnmatch.fnmatch(rel, pat)
        if hit:
            ignored = not neg
    return ignored


def load_gitignore(src, opts):
    if not opts["gitignore"] or not os.path.isdir(src):
        return []
    path = os.path.join(src, ".gitignore")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip() and not line.lstrip().startswith("#")]
    except OSError:
        return []


def ensure_parent(path):
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)


def copy_file_data(src, dst, opts):
    ensure_parent(dst)
    maybe_backup(dst, opts["backup"])
    if opts["no_clobber"] and (os.path.exists(dst) or os.path.islink(dst)):
        raise XcpError(f"Destination Exists: Destination file exists and --no-clobber is set., {dst}")
    with open(src, "rb") as r, open(dst, "wb") as w:
        while True:
            chunk = r.read(1024 * 1024)
            if not chunk:
                break
            w.write(chunk)
        if opts["fsync"]:
            w.flush()
            os.fsync(w.fileno())
    copy_metadata(src, dst, opts, True)


def copy_symlink(src, dst, opts):
    ensure_parent(dst)
    maybe_backup(dst, opts["backup"])
    if opts["no_clobber"] and (os.path.exists(dst) or os.path.islink(dst)):
        raise XcpError(f"Destination Exists: Destination file exists and --no-clobber is set., {dst}")
    try:
        if os.path.isdir(dst) and not os.path.islink(dst):
            raise XcpError(f"Invalid target: Destination is a directory., {dst}")
        if os.path.exists(dst) or os.path.islink(dst):
            os.unlink(dst)
    except FileNotFoundError:
        pass
    os.symlink(os.readlink(src), dst)
    copy_metadata(src, dst, opts, False)


def copy_dir(src, dst, opts, patterns=None):
    patterns = load_gitignore(src, opts) if patterns is None else patterns
    if opts["no_clobber"] and os.path.exists(dst):
        raise XcpError(f"Destination Exists: Destination file exists and --no-clobber is set., {dst}")
    os.makedirs(dst, exist_ok=True)
    copy_metadata(src, dst, opts, False)
    for name in os.listdir(src):
        s = os.path.join(src, name)
        rel = os.path.relpath(s, src)
        isdir = os.path.isdir(s) if opts["dereference"] else os.path.isdir(s) and not os.path.islink(s)
        if ignore_match(rel, isdir, patterns):
            continue
        d = os.path.join(dst, name)
        copy_any(s, d, opts, patterns)
    copy_metadata(src, dst, opts, False)


def copy_special(src, dst, opts):
    mode = os.lstat(src).st_mode
    if stat.S_ISFIFO(mode):
        ensure_parent(dst)
        maybe_backup(dst, opts["backup"])
        if os.path.exists(dst):
            if opts["no_clobber"]:
                raise XcpError(f"Destination Exists: Destination file exists and --no-clobber is set., {dst}")
            os.unlink(dst)
        os.mkfifo(dst, stat.S_IMODE(mode))
        copy_metadata(src, dst, opts, False)
    else:
        raise XcpError(f"Invalid source: Unsupported file type: {src}")


def copy_any(src, dst, opts, patterns=None):
    if not os.path.exists(src) and not os.path.islink(src):
        raise XcpError("Invalid source: Source does not exist.")
    st = os.stat(src) if opts["dereference"] else os.lstat(src)
    if stat.S_ISDIR(st.st_mode):
        if not opts["recursive"]:
            raise XcpError("Invalid source: Source is directory and --recursive not specified.")
        copy_dir(src, dst, opts, patterns)
    elif stat.S_ISLNK(st.st_mode):
        copy_symlink(src, dst, opts)
    elif stat.S_ISREG(st.st_mode):
        copy_file_data(src, dst, opts)
    else:
        copy_special(src, dst, opts)


def expand_paths(paths, do_glob):
    if not do_glob:
        return paths
    out = []
    for p in paths:
        matches = globmod.glob(p)
        out.extend(matches if matches else [p])
    return out


def destinations(paths, opts):
    paths = expand_paths(paths, opts["glob"])
    if opts["target_directory"] is not None:
        return paths, opts["target_directory"], True
    if len(paths) < 2:
        raise XcpError("Invalid arguments: Insufficient arguments")
    return paths[:-1], paths[-1], False


def run(argv):
    opts = parse(argv)
    srcs, dest, explicit_target_dir = destinations(opts["paths"], opts)
    if explicit_target_dir:
        os.makedirs(dest, exist_ok=True)
    if len(srcs) > 1:
        if not os.path.isdir(dest):
            raise XcpError("Invalid target: Target is not a directory.")
        for src in srcs:
            copy_any(src, os.path.join(dest, os.path.basename(src.rstrip("/"))), opts)
        return
    src = srcs[0]
    if os.path.isdir(dest) and not opts["no_target_directory"]:
        copy_any(src, os.path.join(dest, os.path.basename(src.rstrip("/"))), opts)
    elif explicit_target_dir:
        copy_any(src, os.path.join(dest, os.path.basename(src.rstrip("/"))), opts)
    else:
        copy_any(src, dest, opts)


def main():
    try:
        run(sys.argv[1:])
    except XcpError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except BrokenPipeError:
        sys.exit(1)


if __name__ == "__main__":
    main()
