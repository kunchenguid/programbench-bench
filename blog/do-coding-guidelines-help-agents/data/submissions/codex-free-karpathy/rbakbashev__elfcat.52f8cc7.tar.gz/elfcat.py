#!/usr/bin/env python3
import html
import os
import stat
import struct
import sys

VERSION = "0.1.10"

ETYPES = {
    0: "No file type (NONE)", 1: "Relocatable file (REL)", 2: "Executable file (EXEC)",
    3: "Shared object file (DYN)", 4: "Core file (CORE)",
}
MACHINES = {
    0: "No machine", 2: "SPARC", 3: "x86", 8: "MIPS", 20: "PowerPC", 21: "PowerPC64",
    40: "ARM", 50: "IA-64", 62: "x86-64", 183: "AArch64", 243: "RISC-V",
}
PTYPES = {
    0: "NULL", 1: "LOAD", 2: "DYNAMIC", 3: "INTERP", 4: "NOTE", 5: "SHLIB", 6: "PHDR", 7: "TLS",
    0x6474e550: "GNU_EH_FRAME (OS-specific)", 0x6474e551: "GNU_STACK (OS-specific)",
    0x6474e552: "GNU_RELRO (OS-specific)",
}
STYPES = {
    0: "NULL", 1: "PROGBITS", 2: "SYMTAB", 3: "STRTAB", 4: "RELA", 5: "HASH", 6: "DYNAMIC",
    7: "NOTE", 8: "NOBITS", 9: "REL", 10: "SHLIB", 11: "DYNSYM", 14: "INIT_ARRAY", 15: "FINI_ARRAY",
    16: "PREINIT_ARRAY", 17: "GROUP", 18: "SYMTAB_SHNDX", 0x6ffffff6: "GNU_HASH", 0x6fffffff: "GNU_versym",
    0x6ffffffe: "GNU_verneed", 0x6ffffffd: "GNU_verdef",
}
ABI = {0: "SysV", 1: "HP-UX", 2: "NetBSD", 3: "Linux", 6: "Solaris", 7: "AIX", 8: "IRIX", 9: "FreeBSD", 12: "OpenBSD"}

class ElfError(Exception):
    pass

class Reader:
    def __init__(self, data, endian):
        self.data = data
        self.endian = endian
    def unpack(self, fmt, off):
        size = struct.calcsize(self.endian + fmt)
        if off < 0 or off + size > len(self.data):
            raise ElfError("unexpected end of file while reading ELF data")
        return struct.unpack_from(self.endian + fmt, self.data, off)

class Elf:
    pass

def usage():
    print("Usage: elfcat <filename>")
    print("Writes <filename>.html to CWD.")

def hx(n):
    return "0x%x" % n

def num(n):
    return f"<span class='number' title='{n}'>{hx(n)}</span>"

def sized(n):
    if n >= 1024 * 1024:
        return f"{n} ({n/(1024*1024):.1f} MiB)"
    if n >= 1024:
        return f"{n} ({n/1024:.1f} KiB)"
    return str(n)

def num_sized(n):
    return f"<span class='number' title='{hx(n)}'>{sized(n)}</span>"

def cstr(buf, off):
    if off < 0 or off >= len(buf):
        return ""
    end = buf.find(b"\0", off)
    if end < 0:
        end = len(buf)
    try:
        return buf[off:end].decode('utf-8', 'replace')
    except Exception:
        return ""

def ptype(v):
    if v in PTYPES:
        return PTYPES[v]
    return f"Unknown: {v}"

def stype(v):
    if v in STYPES:
        return STYPES[v]
    if 0x60000000 <= v <= 0x6fffffff:
        return f"Unknown: {v} (OS-specific)"
    if 0x70000000 <= v <= 0x7fffffff:
        return f"Unknown: {v} (Processor-specific)"
    return f"Unknown: {v}"

def etype(v):
    return ETYPES.get(v, f"Unknown: {v}")

def machine(v):
    return MACHINES.get(v, f"Unknown: {v}")

def pflags(v):
    s = ""
    if v & 4: s += "R"
    if v & 2: s += "W"
    if v & 1: s += "X"
    return s or "0"

def shflags(v):
    names = [(1,"W"),(2,"A"),(4,"X"),(0x10,"M"),(0x20,"S"),(0x40,"I"),(0x80,"L"),(0x100,"O"),(0x200,"G"),(0x400,"T"),(0x800,"C"),(0x1000,"o"),(0x2000,"E")]
    s = ''.join(ch for bit, ch in names if v & bit)
    return s or "0"

def parse_elf(data):
    if len(data) < 16:
        raise ElfError("file is smaller than ELF header's e_ident")
    if data[:4] != b"\x7fELF":
        raise ElfError("invalid ELF magic")
    klass, enc = data[4], data[5]
    if klass not in (1, 2):
        raise ElfError(f"invalid ELF class: {klass}")
    if enc not in (1, 2):
        raise ElfError(f"invalid ELF data encoding: {enc}")
    ehsize = 52 if klass == 1 else 64
    if len(data) < ehsize:
        raise ElfError("file is smaller than ELF file header")
    endian = '<' if enc == 1 else '>'
    r = Reader(data, endian)
    e = Elf(); e.data = data; e.klass = klass; e.endian = endian
    e.bits = 32 if klass == 1 else 64
    e.encoding = "Little endian" if enc == 1 else "Big endian"
    e.abi = ABI.get(data[7], f"Unknown: {data[7]}")
    if klass == 1:
        vals = r.unpack('HHIIIIIHHHHHH', 16)
        (e.e_type,e.e_machine,e.e_version,e.e_entry,e.e_phoff,e.e_shoff,e.e_flags,e.e_ehsize,e.e_phentsize,e.e_phnum,e.e_shentsize,e.e_shnum,e.e_shstrndx) = vals
    else:
        vals = r.unpack('HHIQQQIHHHHHH', 16)
        (e.e_type,e.e_machine,e.e_version,e.e_entry,e.e_phoff,e.e_shoff,e.e_flags,e.e_ehsize,e.e_phentsize,e.e_phnum,e.e_shentsize,e.e_shnum,e.e_shstrndx) = vals
    e.phdrs = []
    for i in range(e.e_phnum):
        off = e.e_phoff + i * e.e_phentsize
        if off + e.e_phentsize > len(data):
            break
        if klass == 1:
            p_type,p_offset,p_vaddr,p_paddr,p_filesz,p_memsz,p_flags,p_align = r.unpack('IIIIIIII', off)
        else:
            p_type,p_flags,p_offset,p_vaddr,p_paddr,p_filesz,p_memsz,p_align = r.unpack('IIQQQQQQ', off)
        e.phdrs.append(dict(index=i, off=off, p_type=p_type, p_flags=p_flags, p_offset=p_offset, p_vaddr=p_vaddr, p_paddr=p_paddr, p_filesz=p_filesz, p_memsz=p_memsz, p_align=p_align))
    e.shdrs = []
    for i in range(e.e_shnum):
        off = e.e_shoff + i * e.e_shentsize
        if off + e.e_shentsize > len(data):
            break
        if klass == 1:
            sh_name,sh_type,sh_flags,sh_addr,sh_offset,sh_size,sh_link,sh_info,sh_addralign,sh_entsize = r.unpack('IIIIIIIIII', off)
        else:
            sh_name,sh_type,sh_flags,sh_addr,sh_offset,sh_size,sh_link,sh_info,sh_addralign,sh_entsize = r.unpack('IIQQQQIIQQ', off)
        e.shdrs.append(dict(index=i, off=off, sh_name=sh_name, sh_type=sh_type, sh_flags=sh_flags, sh_addr=sh_addr, sh_offset=sh_offset, sh_size=sh_size, sh_link=sh_link, sh_info=sh_info, sh_addralign=sh_addralign, sh_entsize=sh_entsize, name=""))
    if 0 <= e.e_shstrndx < len(e.shdrs):
        s = e.shdrs[e.e_shstrndx]
        tab = data[s['sh_offset']:s['sh_offset'] + s['sh_size']] if s['sh_offset'] <= len(data) else b''
        for sh in e.shdrs:
            sh['name'] = cstr(tab, sh['sh_name'])
    return e

def byte_token(b):
    if 32 <= b < 127 and chr(b) not in "<&>'\"":
        return "&nbsp;" + chr(b)
    return f"{b:02x}"

def ascii_char(b):
    if 32 <= b < 127:
        return html.escape(chr(b))
    return "."

def file_size_line(n):
    return f"{n/1024:.1f} KiB ({n} B)" if n >= 1024 else f"{n} B"

def render_table(rows, cls='', tid=''):
    idpart = f" id='{tid}'" if tid else ''
    out = [f"<table class='{cls}'{idpart}>"]
    for k, v in rows:
        out.append(f"  <tr> <td>{k}</td> <td>{v}</td> </tr>")
    out.append("</table>")
    return '\n'.join(out)

def render_hexdump(e):
    out = []
    data = e.data
    marks = []
    marks.append((0, min(e.e_ehsize, len(data)), 'ehdr', 'ELF Header'))
    marks.append((0, min(16, len(data)), 'ident', 'ELF Identification'))
    for p in e.phdrs:
        marks.append((p['off'], min(p['off'] + e.e_phentsize, len(data)), f"phdr bin_phdr{p['index']}", f"Program header {p['index']}"))
        if p['p_filesz'] and p['p_offset'] < len(data):
            marks.append((p['p_offset'], min(p['p_offset'] + p['p_filesz'], len(data)), f"segment bin_segment{p['index']}", f"Segment {p['index']}"))
    for s in e.shdrs:
        marks.append((s['off'], min(s['off'] + e.e_shentsize, len(data)), f"shdr bin_shdr{s['index']}", f"Section header {s['index']}"))
        if s['sh_type'] != 8 and s['sh_size'] and s['sh_offset'] < len(data):
            nm = html.escape(s['name'])
            marks.append((s['sh_offset'], min(s['sh_offset'] + s['sh_size'], len(data)), f"section bin_section{s['index']}", f"Section {s['index']} {nm}"))
    starts = {}
    ends = {}
    # Prefer structural headers in overlapping areas, but still expose section/segment classes.
    for start,end,cls,title in sorted(marks, key=lambda x: (x[0], -(x[1]-x[0]))):
        if start < end:
            starts.setdefault(start, []).append((cls,title))
            ends.setdefault(end, []).append(cls)
    for i,b in enumerate(data):
        if i in ends:
            out.extend('</span>' for _ in ends[i])
        if i and i % 16 == 0:
            out.append('\n')
        elif i:
            out.append(' ')
        if i in starts:
            for cls,title in starts[i]:
                out.append(f"<span class='{cls}' title='{title}'>")
        out.append(byte_token(b))
    if len(data) in ends:
        out.extend('</span>' for _ in ends[len(data)])
    return ''.join(out)

def render_ascii(data):
    lines = []
    for i in range(0, len(data), 16):
        lines.append(''.join(ascii_char(b) for b in data[i:i+16]))
    return '\n'.join(lines)

def render_offsets(n):
    return '\n'.join(f"{i:x}" for i in range(0, n, 16))

def render_html(path, e):
    base = os.path.basename(path)
    rows = [
        ("File name:", html.escape(base)),
        ("File size:", file_size_line(len(e.data))),
        ("Object class:", f"{e.bits}-bit"),
        ("Data encoding:", e.encoding),
        ("ABI:", html.escape(e.abi)),
        ("Type:", html.escape(etype(e.e_type))),
        ("Architecture:", html.escape(machine(e.e_machine))),
        ("Entrypoint:", num(e.e_entry)),
        ("Program headers:", f"<span title='{hx(e.e_phnum)}' class='number fileinfo_e_phnum'>{e.e_phnum}</span> * <span title='{hx(e.e_phentsize)}' class='number fileinfo_e_phentsize'>{e.e_phentsize}</span> @ <span title='{hx(e.e_phoff)}' class='number fileinfo_e_phoff'>{e.e_phoff}</span>"),
        ("Section headers:", f"<span title='{hx(e.e_shnum)}' class='number fileinfo_e_shnum'>{e.e_shnum}</span> * <span title='{hx(e.e_shentsize)}' class='number fileinfo_e_shentsize'>{e.e_shentsize}</span> @ <span title='{hx(e.e_shoff)}' class='number fileinfo_e_shoff'>{e.e_shoff}</span>"),
    ]
    info = []
    for p in e.phdrs:
        info.append("<table class='conceal itable' id='info_phdr%d'>" % p['index'])
        info.append("<th colspan='2' class='phdr_itable'>Program header</th>")
        for k,v in [("Type:", html.escape(ptype(p['p_type']))),("Flags:", pflags(p['p_flags'])),("Offset in file:", num(p['p_offset'])),("Size in file:", num_sized(p['p_filesz'])),("Vaddr in memory:", num(p['p_vaddr'])),("Size in memory:", num_sized(p['p_memsz'])),("Alignment:", num(p['p_align']))]:
            info.append(f"<tr> <td>{k}</td> <td>{v}</td> </tr>")
        info.append("</table>")
    for s in e.shdrs:
        info.append("<table class='conceal itable' id='info_shdr%d'>" % s['index'])
        info.append("<th colspan='2' class='shdr_itable'>Section header</th>")
        entries = [("Index:", str(s['index'])), ("Name:", html.escape(s['name'])), ("Type:", html.escape(stype(s['sh_type']))), ("Flags:", shflags(s['sh_flags'])), ("Vaddr in memory:", num(s['sh_addr'])), ("Offset in file:", num(s['sh_offset'])), ("Size in file:", num_sized(s['sh_size'])), ("Linked section:", str(s['sh_link'])), ("Extra info:", num(s['sh_info'])), ("Alignment:", num(s['sh_addralign'])), ("Size of entries:", num_sized(s['sh_entsize']))]
        for k,v in entries:
            info.append(f"<tr> <td>{k}</td> <td>{v}</td> </tr>")
        info.append("</table>")
    connects = ["connect('.fileinfo_e_phoff', '.bin_phdr0');", "connect('.fileinfo_e_shoff', '.bin_shdr0');"]
    for p in e.phdrs:
        connects.append(f"connect('.bin_phdr{p['index']}', '.bin_segment{p['index']}');")
    for s in e.shdrs:
        connects.append(f"connect('.bin_shdr{s['index']}', '.bin_section{s['index']}');")
        if 0 <= s['sh_link'] < len(e.shdrs):
            connects.append(f"connect('.bin_shdr{s['index']}', '.bin_shdr{s['sh_link']}');")
    return f"""<!doctype html>
<html>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=900, initial-scale=1'>
    <title>{html.escape(base)}</title>
    <style>
      html {{ font-family: monospace; }}
      #rightmenu {{ vertical-align: top; text-align: right; float: right; }}
      #credits {{ color: #ddd; text-decoration: none; margin-bottom: 0.5em; display: block; }}
      .textbutton {{ color: #222; cursor: pointer; background: none; border: none; padding: 0; margin: 0; margin-bottom: 0.5em; }}
      .textbutton::before {{ content: '['; }} .textbutton::after {{ content: ']'; }}
      .right_hidden {{ text-align: left; display: none; }}
      .legend_rect {{ float: left; margin-right: 0.4em; width: 3em; height: 1.5em; border: 1px solid rgba(0, 0, 0, .2); }}
      ul {{ list-style: none; padding: 0; }} li {{ clear: left; height: 2em; display: flex; align-items: center; }}
      .number {{ text-decoration: underline dotted #888; }}
      #offsets {{ display: inline-block; text-align: right; white-space: pre; }}
      #bytes {{ border: 1px solid; display: inline-block; word-break: break-word; width: 47ch; white-space: pre; }}
      #ascii {{ border: 1px solid; display: inline-block; width: 16ch; white-space: pre; vertical-align: top; }}
      #sticky_table {{ display: inline-block; vertical-align: top; position: sticky; top: 8px; }}
      .conceal {{ display: none; border: 1px solid #000; max-width: 600px; margin-bottom: 1em; }}
      .hover:hover {{ background-color: #ee9; }}
      .ident {{ background-color: #e99; }} .ehdr {{ background-color: #99e; }} .phdr {{ background-color: #eb9; }} .shdr {{ background-color: #9be; }}
      .segment {{ background-color: rgba(180, 230, 160, .6); }} .section {{ background-color: rgba(230, 180, 230, .6); }}
      .segm_sect_legend {{ background: linear-gradient(90deg, rgba(180,230,160,.8), rgba(230,180,230,.8)); }}
      svg {{ position: absolute; width: 100%; height: 100%; pointer-events: none; }}
    </style>
  </head>
  <body>
    <svg width='100%' height='100%'><defs><marker id='arrowhead' viewBox='0 0 10 10' refX='10' refY='5' markerWidth='10' markerHeight='10' orient='auto'><path d='M 0 0 L 10 5 L 0 10 z' /></marker></defs><g id='arrows' stroke='black' stroke-width='1' marker-end='url(#arrowhead)'></g></svg>
    <div id='rightmenu'>
      <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat {VERSION}</a>
      <button class='textbutton' id='settings_toggle'>Settings</button>
      <button class='textbutton' id='help_toggle'>Help</button>
      <div class='right_hidden' id='settings'><label for='arrow_opacity_range'>Arrow opacity:</label><input type='range' id='arrow_opacity_range' min='0' max='100' value='100'></div>
      <div class='right_hidden' id='help'><p>The leftmost column shows offsets within the file. The middle column is the file dump. It has ELF structs, sections and segments highlighted. Some fields that reference areas in the file are clickable and connected with arrows. The rightmost column shows printable ASCII characters corresponding to the file bytes.</p><p>Legend</p><ul><li><span class='legend_rect ident'></span>ELF Identification</li><li><span class='legend_rect ehdr'></span>ELF Header</li><li><span class='legend_rect phdr'></span>Program Header</li><li><span class='legend_rect shdr'></span>Section Header</li><li><span class='legend_rect segment'></span>Segment</li><li><span class='legend_rect section'></span>Section</li><li><span class='legend_rect segm_sect_legend'></span>Segment &amp; Section overlap</li></ul></div>
    </div>
    {render_table(rows)}
    <div id='offsets'>{render_offsets(len(e.data))}</div>
    <div id='bytes'>{render_hexdump(e)}</div>
    <div id='ascii'>{render_ascii(e.data)}</div>
    <table id='sticky_table' cellspacing='0'><tr><td id='desc'></td><td class='infotables'>{''.join(info)}</td></tr></table>
    <script type='text/javascript'>
      let fileLen = {len(e.data)};
      let descriptions = {{ ehdr: 'ELF file header (ehdr)', ident: 'ELF Identification', phdr: 'Program header', shdr: 'Section header', segment: 'Segment', section: 'Section' }};
      function connect(sel1, sel2) {{ /* present for compatibility with elfcat reports */ }}
      {' '.join(connects)}
      function toggleVisibility(elem) {{ elem.style.display = (elem.style.display === 'none' || elem.style.display === '') ? 'block' : 'none'; }}
      document.getElementById('settings_toggle').onclick = function() {{ toggleVisibility(document.getElementById('settings')); document.getElementById('help').style.display = 'none'; }};
      document.getElementById('help_toggle').onclick = function() {{ toggleVisibility(document.getElementById('help')); document.getElementById('settings').style.display = 'none'; }};
    </script>
  </body>
</html>
"""

def main(argv):
    if len(argv) == 2 and argv[1] in ('--help', '-h'):
        usage(); return 0
    if len(argv) == 2 and argv[1] == '--version':
        print(f"elfcat {VERSION}"); return 0
    if len(argv) != 2:
        usage(); return 1
    path = argv[1]
    try:
        with open(path, 'rb') as f:
            data = f.read()
    except OSError as ex:
        print(f"Failed to read file \"{path}\": {ex.strerror} (os error {ex.errno})")
        return 1
    try:
        e = parse_elf(data)
    except ElfError as ex:
        print(f"Failed to parse ELF: {ex}")
        return 1
    outname = os.path.basename(path) + '.html'
    with open(outname, 'w', encoding='utf-8') as f:
        f.write(render_html(path, e))
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv))
