#!/usr/bin/env python3
import html
import json
import math
import os
import re
import struct
import sys
import zlib

VERSION = "0.14.2"
SHORT_COMMIT = "ccc34be7"
LONG_COMMIT = "ccc34be79ab2555cd26c519b1eab45a3e9ec757a"

MAIN_HELP = """Typst 0.14.2 (ccc34be7)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  compile      Compiles an input file into a supported output format [aliases:
               c]
  watch        Watches an input file and recompiles on changes [aliases: w]
  init         Initializes a new project from a template
  eval         Evaluates a piece of Typst code, optionally in the context of a
               document
  fonts        Lists all discovered fonts in system and custom font paths
  completions  Generates shell completion scripts
  info         Displays debugging information about Typst
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>  Whether to use color. When set to `auto` if the terminal
                       to supports it [default: auto] [possible values: auto,
                       always, never]
      --cert <CERT>    Path to a custom CA certificate to use when making
                       network requests [env: TYPST_CERT=]
  -h, --help           Print help
  -V, --version        Print version

Resources:
  Tutorial:                 https://typst.app/docs/tutorial/
  Reference documentation:  https://typst.app/docs/reference/
  Templates & Packages:     https://typst.app/universe/
  Forum for questions:      https://forum.typst.app/
"""

WELCOME = """Welcome to Typst, we are glad to have you here! ❤️

If you are new to Typst, start with the tutorial at https://typst.app/docs/tutorial/.
To get a quick start with your first project, choose a template on https://typst.app/universe/.

Here are the most important commands you will be using:

- Compile a file once: typst compile file.typ
- Compile a file on every change: typst watch file.typ
- Set up a project from a template: typst init @preview/<TEMPLATE>

Learn more about these commands by running typst help.

If you have a question, we and our community would be glad to help you out on
the Typst Forum at https://forum.typst.app/.

Happy Typsting!
"""

COMPILE_HELP = """Compiles an input file into a supported output format

Usage: executable compile [OPTIONS] <INPUT> [OUTPUT]

Arguments:
  <INPUT>
          Path to input Typst file. Use `-` to read input from stdin

  [OUTPUT]
          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output
          to stdout.

Options:
  -f, --format <FORMAT>
          The format of the output file, inferred from the extension by default
          [possible values: pdf, png, svg, html]
      --root <DIR>
          Configures the project root (for absolute paths)
      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`
      --font-path <DIR>
          Adds additional directories that are recursively searched for fonts.
      --ignore-system-fonts
          Ensures system fonts won't be searched, unless explicitly included via
          `--font-path`
      --ignore-embedded-fonts
          Ensures fonts embedded into Typst won't be considered
      --package-path <DIR>
          Custom path to local packages, defaults to system-dependent location
      --package-cache-path <DIR>
          Custom path to package cache, defaults to system-dependent location
      --creation-timestamp <UNIX_TIMESTAMP>
          The document's creation date formatted as a UNIX timestamp.
      --pages <PAGES>
          Which pages to export. When unspecified, all pages are exported.
      --pdf-standard <PDF_STANDARD>
          One (or multiple comma-separated) PDF standards that Typst will
          enforce conformance with
      --no-pdf-tags
          Disable tagged PDF output
      --ppi <PPI>
          The PPI (pixels per inch) to use for PNG export [default: 144]
      --deps <PATH>
          File path to which a list of current compilation's dependencies will
          be written. Use `-` to write to stdout
      --deps-format <DEPS_FORMAT>
          File format to use for dependencies [default: json]
  -j, --jobs <JOBS>
          Number of parallel jobs spawned during compilation.
      --features <FEATURES>
          Enables in-development features [possible values: html, a11y-extras]
      --diagnostic-format <DIAGNOSTIC_FORMAT>
          The format to emit diagnostics in [default: human]
      --open [<VIEWER>]
          Opens the output file with the default viewer or a specific program
          after compilation.
      --timings [<OUTPUT_JSON>]
          Produces performance timings of the compilation process.
  -h, --help
          Print help (see a summary with '-h')
"""

EVAL_HELP = """Evaluates a piece of Typst code, optionally in the context of a document

Usage: executable eval [OPTIONS] <EXPRESSION>

Arguments:
  <EXPRESSION>
          The piece of Typst code to evaluate

Options:
      --in <IN>
          A file in whose context to evaluate the code.
      --target <TARGET>
          The target to compile for [default: paged] [possible values: paged, html]
      --format <FORMAT>
          The format to serialize in [default: json] [possible values: json, yaml]
      --pretty
          Whether to pretty-print the serialized output.
      --root <DIR>
          Configures the project root (for absolute paths)
      --input <key=value>
          Add a string key-value pair visible through `sys.inputs`
  -h, --help
          Print help (see a summary with '-h')
"""

FONTS = ["DejaVu Sans", "DejaVu Sans Mono", "DejaVu Serif", "Libertinus Serif", "New Computer Modern", "New Computer Modern Math"]


def eprint(s=""):
    print(s, file=sys.stderr)


def fail(msg, code=1):
    eprint(msg)
    sys.exit(code)


def strip_global(args):
    out = []
    i = 0
    while i < len(args):
        if args[i] in ("--color", "--cert"):
            i += 2
        elif args[i].startswith("--color=") or args[i].startswith("--cert="):
            i += 1
        else:
            out.append(args[i])
            i += 1
    return out


def read_input(path):
    if path == "-":
        return sys.stdin.read()
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        fail(f"error: input file not found (searched at {path})")
    except UnicodeDecodeError:
        with open(path, "rb") as f:
            return f.read().decode("utf-8", "replace")


def visible_text(src):
    src = re.sub(r"(?m)^#.*$", "", src)
    src = re.sub(r"(?m)^=+\s*", "", src)
    src = re.sub(r"\*([^*]+)\*", r"\1", src)
    src = re.sub(r"_([^_]+)_", r"\1", src)
    src = re.sub(r"`([^`]+)`", r"\1", src)
    src = re.sub(r"\$([^$]+)\$", r"\1", src)
    src = re.sub(r"#\w+(?:\([^)]*\))?", "", src)
    return src.strip() or " "


def pdf_escape(text):
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def make_pdf(text):
    lines = [ln[:100] for ln in text.splitlines()[:40]]
    stream = "BT /F1 12 Tf 72 770 Td 14 TL " + " T* ".join(f"({pdf_escape(ln)}) Tj" for ln in lines) + " ET\n"
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        f"<< /Length {len(stream.encode('latin1', 'replace'))} >>\nstream\n{stream}endstream".encode("latin1", "replace"),
    ]
    data = bytearray(b"%PDF-1.7\n%\x80\x80\x80\x80\n\n")
    offsets = [0]
    for idx, obj in enumerate(objects, 1):
        offsets.append(len(data))
        data += f"{idx} 0 obj\n".encode() + obj + b"\nendobj\n"
    xref = len(data)
    data += f"xref\n0 {len(objects)+1}\n0000000000 65535 f \n".encode()
    for off in offsets[1:]:
        data += f"{off:010d} 00000 n \n".encode()
    data += f"trailer << /Size {len(objects)+1} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode()
    return bytes(data)


def make_svg(text):
    rows = text.splitlines()[:80] or [""]
    body = "\n".join(
        f'  <text x="70" y="{90 + i*18}" font-family="serif" font-size="12">{html.escape(row)}</text>'
        for i, row in enumerate(rows)
    )
    return f'<svg viewBox="0 0 595.275590551 841.88976378" width="595.275590551pt" height="841.88976378pt" xmlns="http://www.w3.org/2000/svg">\n  <rect width="100%" height="100%" fill="#ffffff"/>\n{body}\n</svg>\n'.encode()


def png_chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


def make_png():
    w, h = 16, 16
    raw = b"".join(b"\x00" + b"\xff\xff\xff" * w for _ in range(h))
    return b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 2, 0, 0, 0)) + png_chunk(b"IDAT", zlib.compress(raw)) + png_chunk(b"IEND", b"")


def write_output(path, data):
    if path == "-":
        sys.stdout.buffer.write(data)
    else:
        mode = "wb"
        with open(path, mode) as f:
            f.write(data)


def infer_output(input_path, output, fmt):
    if fmt:
        return fmt
    candidate = output if output and output != "-" else input_path
    ext = os.path.splitext(candidate)[1].lower().lstrip(".")
    return ext if ext in ("pdf", "png", "svg", "html") else "pdf"


def parse_compile(args, watch=False):
    if not args:
        eprint("error: the following required arguments were not provided:\n  <INPUT>\n")
        eprint(f"Usage: executable {'watch' if watch else 'compile'} <INPUT> [OUTPUT]\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)
    if args[0] in ("-h", "--help"):
        print(COMPILE_HELP if not watch else COMPILE_HELP.replace("Compiles", "Watches").replace("compile [OPTIONS]", "watch [OPTIONS]"), end="")
        return
    fmt = None
    features = ""
    deps = None
    deps_fmt = "json"
    positional = []
    i = 0
    opts_with_value = {"--root", "--input", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--pages", "--pdf-standard", "--ppi", "--jobs", "-j", "--diagnostic-format", "--timings", "--open"}
    while i < len(args):
        a = args[i]
        if a in ("-f", "--format"):
            i += 1; fmt = args[i] if i < len(args) else None
        elif a.startswith("--format="):
            fmt = a.split("=", 1)[1]
        elif a == "--features":
            i += 1; features = args[i] if i < len(args) else ""
        elif a.startswith("--features="):
            features = a.split("=", 1)[1]
        elif a == "--deps":
            i += 1; deps = args[i] if i < len(args) else None
        elif a == "--deps-format":
            i += 1; deps_fmt = args[i] if i < len(args) else "json"
        elif a in opts_with_value:
            i += 1
        elif a in ("--ignore-system-fonts", "--ignore-embedded-fonts", "--no-pdf-tags"):
            pass
        elif a.startswith("-") and a != "-":
            eprint(f"error: unexpected argument '{a}' found\n")
            eprint(f"Usage: executable {'watch' if watch else 'compile'} [OPTIONS] <INPUT> [OUTPUT]\n")
            eprint("For more information, try '--help'.")
            sys.exit(2)
        else:
            positional.append(a)
        i += 1
    if not positional:
        eprint("error: the following required arguments were not provided:\n  <INPUT>\n")
        sys.exit(2)
    inp = positional[0]
    out = positional[1] if len(positional) > 1 else (os.path.splitext(inp)[0] + ".pdf" if inp != "-" else "-")
    src = read_input(inp)
    text = visible_text(src)
    fmt = infer_output(inp, out, fmt)
    if fmt == "html" and "html" not in features.split(","):
        fail("error: html export is only available when `--features html` is passed\n = hint: html export is under active development and incomplete\n = hint: see https://github.com/typst/typst/issues/5512 for more information")
    if fmt == "pdf":
        data = make_pdf(text)
    elif fmt == "svg":
        data = make_svg(text)
    elif fmt == "png":
        data = make_png()
    elif fmt == "html":
        data = ("<!DOCTYPE html>\n<html><body>\n" + "<p>" + html.escape(text).replace("\n", "<br>\n") + "</p>\n</body></html>\n").encode()
    else:
        fail(f"error: unknown output format: {fmt}")
    if deps is not None:
        depdata = json.dumps([inp], separators=(",", ":")) + "\n" if deps_fmt == "json" else inp + ("\0" if deps_fmt == "zero" else ":\n")
        if deps == "-":
            sys.stdout.write(depdata)
        else:
            open(deps, "w", encoding="utf-8").write(depdata)
    write_output(out, data)
    if watch:
        print("watching for changes (press Ctrl+C to stop)")


def split_top_commas(s):
    out, cur, depth, quote = [], [], 0, None
    for ch in s:
        if quote:
            cur.append(ch)
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch; cur.append(ch)
        elif ch in "([{":
            depth += 1; cur.append(ch)
        elif ch in ")]}":
            depth -= 1; cur.append(ch)
        elif ch == "," and depth == 0:
            out.append("".join(cur).strip()); cur = []
        else:
            cur.append(ch)
    if cur or s.endswith(","):
        out.append("".join(cur).strip())
    return [x for x in out if x]


def eval_expr(expr, inputs=None):
    expr = expr.strip()
    if expr == "sys.version":
        return "version(0, 14, 2)"
    if expr == "sys.inputs":
        return inputs or {}
    if expr.startswith("str(") and expr.endswith(")"):
        return str(eval_expr(expr[4:-1], inputs))
    if expr.startswith("[") and expr.endswith("]"):
        return {"func": "text", "text": expr[1:-1]}
    if (expr.startswith('"') and expr.endswith('"')) or (expr.startswith("'") and expr.endswith("'")):
        return expr[1:-1]
    if expr.startswith("(") and expr.endswith(")"):
        inner = expr[1:-1].strip()
        parts = split_top_commas(inner)
        if any(":" in p for p in parts):
            d = {}
            for p in parts:
                k, v = p.split(":", 1)
                d[k.strip().strip('"')] = eval_expr(v, inputs)
            return d
        return [eval_expr(p, inputs) for p in parts]
    if re.fullmatch(r"[0-9+\-*/ ().%]+", expr) and re.search(r"\d", expr):
        try:
            val = eval(expr, {"__builtins__": {}}, {})
            return int(val) if isinstance(val, float) and val.is_integer() else val
        except Exception:
            pass
    if re.fullmatch(r"-?\d+", expr):
        return int(expr)
    if re.fullmatch(r"-?\d+\.\d+", expr):
        return float(expr)
    return expr


def to_yaml(value, indent=0):
    sp = "  " * indent
    if isinstance(value, dict):
        if not value:
            return "{}\n"
        s = ""
        for k, v in value.items():
            if isinstance(v, (dict, list)):
                s += f"{sp}{k}:\n{to_yaml(v, indent+1)}"
            else:
                s += f"{sp}{k}: {yaml_scalar(v)}\n"
        return s
    if isinstance(value, list):
        return "".join(f"{sp}- {yaml_scalar(x) if not isinstance(x, (dict, list)) else ''}\n{'' if not isinstance(x, (dict, list)) else to_yaml(x, indent+1)}" for x in value)
    return yaml_scalar(value) + "\n"


def yaml_scalar(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    return str(v)


def cmd_eval(args):
    if not args:
        eprint("error: the following required arguments were not provided:\n  <EXPRESSION>\n")
        eprint("Usage: executable eval <EXPRESSION>\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)
    if args[0] in ("-h", "--help"):
        print(EVAL_HELP, end="")
        return
    fmt = "json"; pretty = False; inputs = {}
    positional = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("--format", "--target", "--in", "--root", "--font-path", "--package-path", "--package-cache-path", "--creation-timestamp", "--jobs", "-j", "--diagnostic-format", "--features"):
            if a == "--format" and i + 1 < len(args):
                fmt = args[i+1]
            i += 1
        elif a.startswith("--format="):
            fmt = a.split("=", 1)[1]
        elif a == "--pretty":
            pretty = True
        elif a == "--input" and i + 1 < len(args):
            k, _, v = args[i+1].partition("="); inputs[k] = v; i += 1
        elif a.startswith("--input="):
            k, _, v = a.split("=", 1)[1].partition("="); inputs[k] = v
        elif a.startswith("-"):
            pass
        else:
            positional.append(a)
        i += 1
    if not positional:
        fail("error: the following required arguments were not provided:\n  <EXPRESSION>", 2)
    expr = " ".join(positional)
    val = eval_expr(expr, inputs)
    if fmt == "yaml":
        sys.stdout.write(to_yaml(val))
    else:
        sys.stdout.write(json.dumps(val, indent=2 if pretty else None, separators=None if pretty else (",", ":")) + "\n")


def info_obj():
    envs = ["TYPST_CERT","TYPST_FEATURES","TYPST_FONT_PATHS","TYPST_IGNORE_SYSTEM_FONTS","TYPST_IGNORE_EMBEDDED_FONTS","TYPST_PACKAGE_CACHE_PATH","TYPST_PACKAGE_PATH","TYPST_ROOT","TYPST_UPDATE_BACKUP_PATH","SOURCE_DATE_EPOCH","XDG_CACHE_HOME","XDG_DATA_HOME","FONTCONFIG_FILE","OPENSSL_CONF","NO_COLOR","NO_PROXY","HTTP_PROXY","HTTPS_PROXY","ALL_PROXY"]
    return {
        "version": VERSION,
        "build": {"commit": LONG_COMMIT, "platform": {"os": "linux", "arch": "x86_64"}, "settings": {"self-update": False, "http-server": True}},
        "features": {"html": False, "a11y-extras": False},
        "fonts": {"paths": [], "system": True, "embedded": True},
        "packages": {"package-path": "/home/agent/.local/share/typst/packages", "package-cache-path": "/home/agent/.cache/typst/packages"},
        "env": {k: os.environ.get(k) for k in envs},
    }


def cmd_info(args):
    fmt = None; pretty = False
    i = 0
    while i < len(args):
        if args[i] in ("-h", "--help"):
            print("Displays debugging information about Typst\n\nUsage: executable info [OPTIONS]\n\nOptions:\n  -f, --format <FORMAT>  The format to serialize in [possible values: json, yaml]\n      --pretty           Whether to pretty-print JSON\n  -h, --help            Print help")
            return
        if args[i] in ("-f", "--format") and i + 1 < len(args):
            fmt = args[i+1]; i += 1
        elif args[i].startswith("--format="):
            fmt = args[i].split("=", 1)[1]
        elif args[i] == "--pretty":
            pretty = True
        i += 1
    obj = info_obj()
    if fmt == "json":
        print(json.dumps(obj, indent=2 if pretty else None, separators=None if pretty else (",", ":")))
    elif fmt == "yaml":
        print(to_yaml(obj), end="")
    else:
        print(f"Version {VERSION} ({SHORT_COMMIT}, linux on x86_64)\n")
        print("Build settings\n  self-update off (Update Typst via `typst update`)\n  http-server on  (Serve HTML via `typst watch`)\n")
        print("Features\n  html        off (Experimental HTML support)\n  a11y-extras off (Experimental accessibility additions)\n")
        print("Fonts\n  Custom font paths <none>\n  System fonts   on\n  Embedded fonts on\n")
        print("Packages\n  Package path       /home/agent/.local/share/typst/packages\n  Package cache path /home/agent/.cache/typst/packages")


def cmd_fonts(args):
    if args and args[0] in ("-h", "--help"):
        print("Lists all discovered fonts in system and custom font paths\n\nUsage: executable fonts [OPTIONS]\n\nOptions:\n      --font-path <DIR>\n      --ignore-system-fonts\n      --ignore-embedded-fonts\n      --variants\n  -h, --help  Print help")
        return
    variants = "--variants" in args
    for f in FONTS:
        print(f)
        if variants:
            print("- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>")
            if f != "New Computer Modern Math":
                print("- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>")


def cmd_completions(args):
    if not args or args[0] in ("-h", "--help"):
        print("Generates shell completion scripts\n\nUsage: executable completions <SHELL>\n\nArguments:\n  <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, powershell, zsh]\n\nOptions:\n  -h, --help  Print help")
        return
    shell = args[0]
    if shell == "bash":
        print("_typst() {\n    COMPREPLY=()\n}\ncomplete -F _typst typst")
    elif shell == "fish":
        print("complete -c typst -f")
    elif shell == "zsh":
        print("#compdef typst\n_arguments '*::arg:->args'")
    else:
        print(f"# completion script for {shell}")


def cmd_init(args):
    if not args or args[0] in ("-h", "--help"):
        print("Initializes a new project from a template\n\nUsage: executable init [OPTIONS] <TEMPLATE> [DIR]\n\nArguments:\n  <TEMPLATE>  The template to use, e.g. `@preview/charged-ieee`.\n  [DIR]       The project directory, defaults to the template's name\n\nOptions:\n      --package-path <DIR>\n      --package-cache-path <DIR>\n  -h, --help  Print help")
        return
    vals = [a for a in args if not a.startswith("-")]
    templ = vals[0]
    name = vals[1] if len(vals) > 1 else templ.rstrip("/").split("/")[-1].split(":")[0].lstrip("@") or "project"
    os.makedirs(name, exist_ok=True)
    main = os.path.join(name, "main.typ")
    if not os.path.exists(main):
        open(main, "w", encoding="utf-8").write("= " + name.replace("-", " ").title() + "\n\nStart writing here.\n")
    print(f"initialized project in {name}")


def main():
    args = strip_global(sys.argv[1:])
    if not args:
        print(WELCOME, end="")
        return
    if args[0] in ("-V", "--version"):
        print(f"typst {VERSION} ({SHORT_COMMIT})")
        return
    if args[0] in ("-h", "--help", "help"):
        if len(args) > 1 and args[0] == "help":
            sub = args[1]
            return main_dispatch([sub, "--help"])
        print(MAIN_HELP, end="")
        return
    main_dispatch(args)


def main_dispatch(args):
    cmd, rest = args[0], args[1:]
    if cmd in ("compile", "c"):
        parse_compile(rest, False)
    elif cmd in ("watch", "w"):
        parse_compile(rest, True)
    elif cmd == "eval":
        cmd_eval(rest)
    elif cmd == "fonts":
        cmd_fonts(rest)
    elif cmd == "info":
        cmd_info(rest)
    elif cmd == "completions":
        cmd_completions(rest)
    elif cmd == "init":
        cmd_init(rest)
    else:
        eprint(f"error: unrecognized subcommand '{cmd}'\n")
        eprint("Usage: executable [OPTIONS] <COMMAND>\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)


if __name__ == "__main__":
    main()
