#define _XOPEN_SOURCE 700
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <unistd.h>
#include <limits.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct Node Node;
struct Node {
    char *name;
    char *path;
    off_t size;
    int is_dir;
    Node **kids;
    size_t nkids, cap;
};

typedef struct {
    int depth_limit;
    int depth_set;
    long long aggr;
    int aggr_set;
    int summary;
    int usage;
    int bytes;
    int files_only;
    int no_hidden;
    int ascii;
    char **exclude;
    int nexclude;
    char **paths;
    int npaths;
} Opt;

static void usage(const char *argv0) {
    printf("Usage: %s [options] <path> [<path>..]\n\n", argv0);
    printf("Options:\n");
    printf("    -d, --depth [DEPTH] show directories up to depth N (def 1)\n");
    printf("    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)\n");
    printf("    -s, --summary       equivalent to -da, or -d1 -a1M\n");
    printf("    -u, --usage         report real disk usage instead of file size\n");
    printf("    -b, --bytes         print sizes in bytes\n");
    printf("    -f, --files-only    skip directories for a fast local overview\n");
    printf("    -x, --exclude NAME  exclude matching files or directories\n");
    printf("    -H, --no-hidden     exclude hidden files\n");
    printf("    -A, --ascii         ASCII characters only, no colors\n");
    printf("    -h, --help          show help\n");
    printf("    -v, --version       print version number\n");
}

static char *xstrdup(const char *s) { char *r = strdup(s ? s : ""); if(!r){perror("strdup"); exit(2);} return r; }
static const char *base_name(const char *p) { const char *s = strrchr(p, '/'); return s ? s + 1 : p; }
static const char *display_name(const char *p, char *buf, size_t len) {
    if (!strcmp(p, ".")) {
        if (getcwd(buf, len)) return base_name(buf);
    }
    size_t n = strlen(p);
    while (n > 1 && p[n-1] == '/') n--;
    if (n != strlen(p)) {
        size_t m = n < len - 1 ? n : len - 1;
        memcpy(buf, p, m);
        buf[m] = '\0';
        return base_name(buf);
    }
    return base_name(p);
}
static int hidden_name(const char *n) { return n[0] == '.' && strcmp(n,".") && strcmp(n,".."); }
static int excluded(Opt *o, const char *n, const char *p) {
    (void)p;
    if (o->no_hidden && hidden_name(n)) return 1;
    for (int i=0;i<o->nexclude;i++) if (strstr(n, o->exclude[i])) return 1;
    return 0;
}
static long long parse_size(const char *s, int *ok) {
    if (!s || !*s) { *ok = 0; return 0; }
    char *end = NULL; errno = 0;
    long long v = strtoll(s, &end, 10);
    if (errno || end == s || v < 0) { *ok = 0; return 0; }
    long long mult = 1;
    if (*end) {
        if ((end[0]=='K'||end[0]=='k') && !end[1]) mult = 1024LL;
        else if ((end[0]=='M'||end[0]=='m') && !end[1]) mult = 1024LL*1024LL;
        else if ((end[0]=='G'||end[0]=='g') && !end[1]) mult = 1024LL*1024LL*1024LL;
        else { *ok = 0; return 0; }
    }
    *ok = 1; return v * mult;
}
static int parse_int(const char *s, int def) {
    if (!s || !*s) return def;
    char *end=NULL; long v=strtol(s,&end,10);
    if (end==s || v<0) return def;
    return (int)v;
}
static void add_path_arg(Opt *o, char *p) { o->paths = realloc(o->paths, sizeof(char*)*(o->npaths+1)); o->paths[o->npaths++] = p; }
static void add_excl(Opt *o, char *p) { o->exclude = realloc(o->exclude, sizeof(char*)*(o->nexclude+1)); o->exclude[o->nexclude++] = p; }

static Node *new_node(const char *name, const char *path, int is_dir) {
    Node *n = calloc(1,sizeof(Node)); if(!n){perror("calloc"); exit(2);} n->name=xstrdup(name); n->path=xstrdup(path); n->is_dir=is_dir; return n;
}
static void add_child(Node *p, Node *c) {
    if (p->nkids == p->cap) { p->cap = p->cap ? p->cap*2 : 8; p->kids = realloc(p->kids, p->cap*sizeof(Node*)); if(!p->kids){perror("realloc"); exit(2);} }
    p->kids[p->nkids++] = c;
}
static int cmp_node(const void *a, const void *b) {
    Node *x=*(Node**)a, *y=*(Node**)b;
    if (x->size < y->size) return 1;
    if (x->size > y->size) return -1;
    return strcmp(x->name, y->name);
}
static off_t stat_size(struct stat *st, Opt *o) { return o->usage ? (off_t)st->st_blocks * 512 : st->st_size; }

static Node *scan_path(const char *path, Opt *o, int root) {
    struct stat st;
    if (lstat(path, &st) != 0) return NULL;
    int isdir = S_ISDIR(st.st_mode);
    Node *n = new_node(root ? base_name(path) : base_name(path), path, isdir);
    n->size = stat_size(&st, o);
    if (isdir && !o->files_only) {
        DIR *d = opendir(path);
        if (d) {
            struct dirent *de;
            while ((de = readdir(d))) {
                if (!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
                char child[PATH_MAX];
                snprintf(child, sizeof(child), "%s/%s", path, de->d_name);
                if (excluded(o, de->d_name, child)) continue;
                Node *c = scan_path(child, o, 0);
                if (c) { n->size += c->size; add_child(n, c); }
            }
            closedir(d);
        }
        if (n->nkids) qsort(n->kids, n->nkids, sizeof(Node*), cmp_node);
    } else if (isdir && o->files_only) {
        DIR *d = opendir(path);
        if (d) {
            struct dirent *de;
            while ((de = readdir(d))) {
                if (!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
                char child[PATH_MAX]; snprintf(child,sizeof(child),"%s/%s",path,de->d_name);
                if (excluded(o, de->d_name, child)) continue;
                struct stat cs; if (lstat(child,&cs)!=0 || S_ISDIR(cs.st_mode)) continue;
                Node *c = new_node(de->d_name, child, 0); c->size = stat_size(&cs,o); n->size += c->size; add_child(n,c);
            }
            closedir(d);
        }
        if (n->nkids) qsort(n->kids, n->nkids, sizeof(Node*), cmp_node);
    }
    return n;
}

static void fmt_size(off_t sz, Opt *o, char *buf, size_t len) {
    if (o->bytes) { snprintf(buf,len,"%lld B",(long long)sz); return; }
    double v = (double)sz; const char *u="B";
    if (v >= 1024.0*1024.0*1024.0) { v/=1024.0*1024.0*1024.0; u="GiB"; }
    else if (v >= 1024.0*1024.0) { v/=1024.0*1024.0; u="MiB"; }
    else if (v >= 1024.0) { v/=1024.0; u="KiB"; }
    if (!strcmp(u,"B")) snprintf(buf,len,"%lld B",(long long)sz);
    else snprintf(buf,len,"%.2f %s",v,u);
}
static void print_bar_text(off_t size, off_t base, int ascii) {
    int fill = base>0 ? (int)((size*32LL)/base) : 0;
    if (fill > 32) fill=32;
    if (fill < 0) fill=0;
    for (int i=0;i<32;i++) {
        if (i >= 32-fill) fputs(ascii ? "#" : "█", stdout);
        else putchar(' ');
    }
}
static void line_prefix(const int *lasts, int depth, int final, int ascii) {
    (void)ascii;
    for (int i=0;i<depth-1;i++) fputs(lasts[i] ? "   " : "│  ", stdout);
    if (depth>0) fputs(final ? "└─ " : "├─ ", stdout);
}
static void print_entry(Node *n, off_t parent, off_t bar_base, int depth, int final, int *lasts, Opt *o) {
    line_prefix(lasts, depth, final, o->ascii);
    int prefix_cols = depth>0 ? (depth-1)*3 + 3 : 0;
    int namew = 26 - prefix_cols; if (namew < 1) namew = 1;
    char namebuf[256]; snprintf(namebuf,sizeof(namebuf),"%s",n->name);
    if ((int)strlen(namebuf) > namew) namebuf[namew] = '\0';
    printf("%-*s│ ", namew, namebuf);
    print_bar_text(n->size, bar_base, o->ascii);
    int pct = parent>0 ? (int)((n->size*100LL)/parent) : 0;
    char sb[64]; fmt_size(n->size,o,sb,sizeof(sb));
    printf("│ %3d%% %11s\n", pct, sb);
}
static int visible_children(Node *n, int depth, Opt *o, Node ***out, Node *ag) {
    (void)depth;
    *out = NULL; if (!n->nkids) return 0;
    int cnt=0; off_t agg=0;
    Node **arr = malloc((n->nkids+1)*sizeof(Node*));
    for (size_t i=0;i<n->nkids;i++) {
        Node *c=n->kids[i];
        if (o->aggr_set && c->size < o->aggr) { agg += c->size; continue; }
        arr[cnt++]=c;
    }
    if (agg>0) { ag->name = "<aggregated>"; ag->path=""; ag->size=agg; ag->is_dir=0; ag->kids=NULL; ag->nkids=0; arr[cnt++]=ag; }
    *out = arr; return cnt;
}
static void print_tree(Node *n, int depth, int *lasts, Opt *o) {
    if (o->depth_set && depth >= o->depth_limit) return;
    Node ag = {0}; Node **arr=NULL; int cnt = visible_children(n, depth, o, &arr, &ag);
    off_t bar_base = 0;
    for (int i=0;i<cnt;i++) if (arr[i]->size > bar_base) bar_base = arr[i]->size;
    for (int i=0;i<cnt;i++) {
        int fin = (i==cnt-1); lasts[depth]=fin;
        print_entry(arr[i], n->size, bar_base, depth+1, fin, lasts, o);
        if (arr[i] != &ag) print_tree(arr[i], depth+1, lasts, o);
    }
    free(arr);
}
static Node *make_collection(Opt *o) {
    Node *root = new_node("<collection>", "", 1);
    for (int i=0;i<o->npaths;i++) {
        struct stat st; if (lstat(o->paths[i], &st)!=0) { fprintf(stderr,"path %s doesn't exist\n", o->paths[i]); exit(1); }
        Node *c = scan_path(o->paths[i], o, 1);
        if (c) {
            free(c->name);
            char tmp[PATH_MAX];
            c->name = xstrdup(display_name(o->paths[i], tmp, sizeof(tmp)));
            root->size += c->size;
            add_child(root,c);
        }
    }
    if (root->nkids) qsort(root->kids, root->nkids, sizeof(Node*), cmp_node);
    return root;
}
static void parse_args(int argc, char **argv, Opt *o) {
    o->depth_limit = 999999; o->aggr = 1024LL*1024LL;
    for (int i=1;i<argc;i++) {
        char *a=argv[i];
        if (!strcmp(a,"-h") || !strcmp(a,"--help")) { usage(argv[0]); exit(0); }
        else if (!strcmp(a,"-v") || !strcmp(a,"--version")) { puts("dutree version 0.2.18"); exit(0); }
        else if (!strcmp(a,"-s") || !strcmp(a,"--summary")) { o->summary=1; o->depth_set=1; o->depth_limit=1; o->aggr_set=1; o->aggr=1024LL*1024LL; }
        else if (!strcmp(a,"-u") || !strcmp(a,"--usage")) o->usage=1;
        else if (!strcmp(a,"-b") || !strcmp(a,"--bytes")) o->bytes=1;
        else if (!strcmp(a,"-f") || !strcmp(a,"--files-only")) o->files_only=1;
        else if (!strcmp(a,"-H") || !strcmp(a,"--no-hidden")) o->no_hidden=1;
        else if (!strcmp(a,"-A") || !strcmp(a,"--ascii")) o->ascii=1;
        else if (!strcmp(a,"-x") || !strcmp(a,"--exclude")) { if (i+1<argc) add_excl(o, argv[++i]); }
        else if (!strcmp(a,"-d") || !strcmp(a,"--depth")) { o->depth_set=1; o->depth_limit=1; if (i+1<argc && argv[i+1][0] != '-') { char *e; long v=strtol(argv[i+1],&e,10); if(e!=argv[i+1] && v>=0){ o->depth_limit=(int)v; i++; } } }
        else if (!strncmp(a,"-d",2) && a[2]) { o->depth_set=1; o->depth_limit=parse_int(a+2,1); }
        else if (!strncmp(a,"--depth=",8)) { o->depth_set=1; o->depth_limit=parse_int(a+8,1); }
        else if (!strcmp(a,"-a") || !strcmp(a,"--aggr")) { o->aggr_set=1; o->aggr=1024LL*1024LL; if (i+1<argc && argv[i+1][0] != '-') { int ok; long long v=parse_size(argv[i+1],&ok); if(!ok){ fprintf(stderr,"invalid argument '%s'\n", argv[i+1]); exit(1);} o->aggr=v; i++; } }
        else if (!strncmp(a,"-a",2) && a[2]) { int ok; long long v=parse_size(a+2,&ok); if(!ok){ fprintf(stderr,"invalid argument '%s'\n", a+2); exit(1);} o->aggr_set=1; o->aggr=v; }
        else if (!strncmp(a,"--aggr=",7)) { int ok; long long v=parse_size(a+7,&ok); if(!ok){ fprintf(stderr,"invalid argument '%s'\n", a+7); exit(1);} o->aggr_set=1; o->aggr=v; }
        else if (a[0]=='-') { usage(argv[0]); fprintf(stderr,"Unrecognized option: '%s'\n", a+2); exit(1); }
        else add_path_arg(o,a);
    }
    if (o->npaths == 0) add_path_arg(o, ".");
}
int main(int argc, char **argv) {
    Opt o={0}; parse_args(argc,argv,&o);
    Node *root;
    if (o.npaths == 1) {
        struct stat st; if (lstat(o.paths[0], &st)!=0) { fprintf(stderr,"path %s doesn't exist\n", o.paths[0]); return 1; }
        root = scan_path(o.paths[0], &o, 1);
    } else root = make_collection(&o);
    char sb[64]; fmt_size(root->size,&o,sb,sizeof(sb));
    char tmp[PATH_MAX];
    const char *rn = o.npaths==1 ? display_name(o.paths[0], tmp, sizeof(tmp)) : "<collection>";
    if (!*rn) rn = o.paths[0];
    printf("[ %s %s ]\n", rn, sb);
    int lasts[512]={0}; print_tree(root,0,lasts,&o);
    return 0;
}
