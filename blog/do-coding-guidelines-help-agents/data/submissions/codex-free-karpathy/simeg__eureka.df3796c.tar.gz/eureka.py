#!/usr/bin/env python3
import json
import os
import subprocess
import sys
from pathlib import Path


HELP = """Input and store your ideas without leaving the terminal

Usage: executable [OPTIONS]

Options:
      --clear-config  Clear your stored configuration
  -v, --view          View ideas with your $PAGER env variable. If unset use less
  -h, --help          Print help
  -V, --version       Print version
"""

SETUP = """\033[0m\033[33m############################################################
####                  First Time Setup                  ####
############################################################

This tool requires you to have a repository with a README.md
in the root folder. The markdown file is where your ideas
will be stored.

Once first time setup has completed, simply run Eureka again
to begin writing down ideas.
        
\033[0m"""

PROMPT_PATH = "\033[0m\033[1m\033[32mAbsolute path to your idea repo\n\033[0m> "
PROMPT_SUMMARY = "\033[0m\033[1m\033[32m>> Idea summary\n\033[0m> "


def config_file() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME")
    if base:
        return Path(base) / "eureka" / "config.json"
    return Path.home() / ".config" / "eureka" / "config.json"


def runtime_error(message: str) -> int:
    print(f" ERROR eureka > {message}", file=sys.stderr)
    return 0


def load_config():
    path = config_file()
    try:
        with path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        return data.get("repo", "")
    except FileNotFoundError:
        raise
    except Exception as exc:
        raise RuntimeError(str(exc))


def first_time_setup() -> int:
    sys.stdout.write(SETUP)
    while True:
        sys.stdout.write(PROMPT_PATH)
        sys.stdout.flush()
        line = sys.stdin.readline()
        if line == "":
            continue
        repo = line.rstrip("\n")
        path = config_file()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps({"repo": repo}, separators=(",", ":")), encoding="utf-8")
        print("First time setup complete. Happy ideation!")
        return 0


def clear_config() -> int:
    try:
        config_file().unlink()
    except FileNotFoundError:
        return runtime_error("No such file or directory (os error 2)")
    return 0


def read_repo_or_setup():
    try:
        return load_config()
    except FileNotFoundError:
        first_time_setup()
        return None
    except RuntimeError as exc:
        runtime_error(str(exc))
        return None


def run_external(argv, cwd=None):
    try:
        return subprocess.run(argv, cwd=cwd).returncode
    except FileNotFoundError as exc:
        return runtime_error(f"No such file or directory (os error 2)")
    except Exception as exc:
        return runtime_error(str(exc))


def git_output(args, cwd):
    return subprocess.run(
        ["git"] + args,
        cwd=cwd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )


def git_error_text(proc, fallback: str) -> str:
    text = (proc.stderr or proc.stdout or "").strip()
    return text if text else fallback


def view() -> int:
    try:
        repo = load_config()
    except FileNotFoundError:
        return runtime_error("No such file or directory (os error 2)")
    except RuntimeError as exc:
        return runtime_error(str(exc))
    if not repo:
        return 0
    readme = str(Path(repo) / "README.md")
    pager = os.environ.get("PAGER") or "less"
    return run_external([pager, readme])


def capture() -> int:
    repo = read_repo_or_setup()
    if repo is None:
        return 0

    sys.stdout.write(PROMPT_SUMMARY)
    sys.stdout.flush()
    summary = sys.stdin.readline().rstrip("\n")

    repo_path = Path(repo)
    readme = repo_path / "README.md"
    check = git_output(["rev-parse", "--git-dir"], repo)
    if check.returncode != 0:
        return runtime_error(f"could not find repository from '{repo}'; class=Repository (6); code=NotFound (-3)")

    editor = os.environ.get("EDITOR") or "vi"
    editor_status = run_external([editor, str(readme)])
    if editor_status not in (0, None):
        return 0

    print("Adding and committing your new idea to main..", flush=True)
    add = git_output(["add", "README.md"], repo)
    if add.returncode != 0:
        return runtime_error(git_error_text(add, "failed to add README.md"))

    commit = git_output(["commit", "-m", summary], repo)
    if commit.returncode != 0:
        text = git_error_text(commit, "failed to commit")
        if "bad revision" in text or "unborn" in text.lower():
            text = "reference 'refs/heads/master' not found; class=Reference (4); code=UnbornBranch (-9)"
        return runtime_error(text)

    print("Added and committed!", flush=True)
    print("Pushing your new idea..", flush=True)
    push = git_output(["push", "origin", "HEAD"], repo)
    if push.returncode != 0:
        text = git_error_text(push, "remote 'origin' does not exist; class=Config (7); code=NotFound (-3)")
        if "does not appear to be a git repository" in text or "No configured push destination" in text or "'origin'" in text:
            text = "remote 'origin' does not exist; class=Config (7); code=NotFound (-3)"
        return runtime_error(text)
    print("Pushed!", flush=True)
    return 0


def clap_error(message: str) -> int:
    print(f"error: {message}", file=sys.stderr)
    print("", file=sys.stderr)
    print("Usage: executable [OPTIONS]", file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def main() -> int:
    args = []
    for arg in sys.argv[1:]:
        if arg.startswith("-") and not arg.startswith("--") and len(arg) > 2:
            args.extend("-" + ch for ch in arg[1:])
        else:
            args.append(arg)
    if not args:
        return capture()

    view_count = args.count("-v") + args.count("--view")
    if view_count > 1:
        return clap_error("the argument '--view' cannot be used multiple times")

    for arg in args:
        if arg in ("-h", "--help"):
            sys.stdout.write(HELP)
            return 0
        if arg in ("-V", "--version"):
            print("eureka 2.0.0")
            return 0
        if arg in ("-v", "--view", "--clear-config"):
            continue
        if arg.startswith("-"):
            return clap_error(f"unexpected argument '{arg}' found")
        return clap_error(f"unexpected argument '{arg}' found")

    if "--clear-config" in args:
        return clear_config()
    if view_count == 1:
        return view()
    return capture()


if __name__ == "__main__":
    sys.exit(main())
