#!/usr/bin/env python3
import math, os, sys, re

VERSION = "Lua 5.5"

class LuaError(Exception): pass
class ReturnEx(Exception):
    def __init__(self, vals): self.vals = vals
class BreakEx(Exception): pass

def truth(v): return v is not None and v is not False
def isnum(v): return isinstance(v, (int, float)) and not isinstance(v, bool)
def fmt(v):
    if v is None: return "nil"
    if v is True: return "true"
    if v is False: return "false"
    if isinstance(v, float) and v.is_integer(): return str(int(v))
    return str(v)
def key(v):
    if isinstance(v, float) and v.is_integer(): return int(v)
    return v

class Table:
    def __init__(self):
        self.d = {}; self.mt = None
    def get(self, k): return self.d.get(key(k), None)
    def set(self, k, v):
        k = key(k)
        if v is None: self.d.pop(k, None)
        else: self.d[k] = v
    def length(self):
        n = 0
        while self.d.get(n + 1, None) is not None: n += 1
        return n
    def items(self): return list(self.d.items())
    def __str__(self): return "table: 0x%x" % (id(self) & 0xffffffff)

class Env:
    def __init__(self, parent=None):
        self.parent, self.v = parent, {}
    def get(self, name):
        if name in self.v: return self.v[name]
        if self.parent: return self.parent.get(name)
        return None
    def set_local(self, name, val): self.v[name] = val
    def set(self, name, val):
        if name in self.v: self.v[name] = val
        elif self.parent: self.parent.set(name, val)
        else: self.v[name] = val

KEYWORDS = set("and break do else elseif end false for function goto if in local nil not or repeat return then true until while".split())

class Lexer:
    def __init__(self, s):
        if s.startswith("#!"):
            p = s.find("\n")
            s = "" if p < 0 else "\n" + s[p+1:]
        self.s, self.i, self.n, self.line = s, 0, len(s), 1
    def peekc(self, n=0):
        j = self.i + n
        return self.s[j] if j < self.n else ""
    def adv(self):
        c = self.peekc(); self.i += 1
        if c == "\n": self.line += 1
        return c
    def skip(self):
        while True:
            while self.peekc() and self.peekc().isspace(): self.adv()
            if self.peekc() == "-" and self.peekc(1) == "-":
                self.adv(); self.adv()
                if self.peekc() == "[" and self.peekc(1) == "[":
                    self.adv(); self.adv()
                    while self.peekc() and not (self.peekc() == "]" and self.peekc(1) == "]"): self.adv()
                    if self.peekc(): self.adv(); self.adv()
                else:
                    while self.peekc() and self.peekc() != "\n": self.adv()
                continue
            break
    def string(self, q):
        self.adv(); out = ""
        esc = {"n":"\n","t":"\t","r":"\r","\\":"\\","\"":"\"","'":"'","a":"\a","b":"\b","f":"\f","v":"\v"}
        while self.peekc():
            c = self.adv()
            if c == q: return out
            if c == "\\":
                e = self.adv()
                if e.isdigit():
                    digs = e
                    for _ in range(2):
                        if self.peekc().isdigit(): digs += self.adv()
                    out += chr(int(digs) & 255)
                else: out += esc.get(e, e)
            else: out += c
        raise LuaError("unfinished string")
    def long_string(self):
        self.adv(); self.adv(); out = ""
        if self.peekc() == "\n": self.adv()
        while self.peekc() and not (self.peekc() == "]" and self.peekc(1) == "]"): out += self.adv()
        if not self.peekc(): raise LuaError("unfinished long string")
        self.adv(); self.adv(); return out
    def next(self):
        self.skip()
        c = self.peekc()
        if not c: return ("eof","",self.line)
        if c.isalpha() or c == "_":
            st = self.i
            while self.peekc().isalnum() or self.peekc() == "_": self.adv()
            w = self.s[st:self.i]
            return (w if w in KEYWORDS else "name", w, self.line)
        if c.isdigit() or (c == "." and self.peekc(1).isdigit()):
            st = self.i
            if c == "0" and self.peekc(1).lower() == "x":
                self.adv(); self.adv()
                while re.match(r"[0-9a-fA-F]", self.peekc()): self.adv()
                return ("num", int(self.s[st:self.i], 16), self.line)
            while self.peekc().isdigit(): self.adv()
            if self.peekc() == "." and self.peekc(1) != ".":
                self.adv()
                while self.peekc().isdigit(): self.adv()
            if self.peekc().lower() == "e":
                self.adv()
                if self.peekc() in "+-": self.adv()
                while self.peekc().isdigit(): self.adv()
            t = self.s[st:self.i]
            return ("num", float(t) if any(x in t for x in ".eE") else int(t), self.line)
        if c in "\"'": return ("str", self.string(c), self.line)
        if c == "[" and self.peekc(1) == "[": return ("str", self.long_string(), self.line)
        for op in ("...","//","==","~=","<=",">=","..","<<",">>","::"):
            if self.s.startswith(op, self.i):
                self.i += len(op); return (op,op,self.line)
        self.adv(); return (c,c,self.line)

class Parser:
    def __init__(self, s):
        self.lex = Lexer(s); self.t = self.lex.next()
    def eat(self, typ=None):
        old = self.t
        if typ is not None and old[0] != typ: raise LuaError("syntax error near '%s'" % old[1])
        self.t = self.lex.next(); return old
    def accept(self, typ):
        if self.t[0] == typ: return self.eat(typ)
    def parse(self): return ("block", self.block(("eof",)))
    def block(self, stops):
        a = []
        while self.t[0] not in stops and self.t[0] != "eof":
            if self.accept(";"): continue
            a.append(self.stat())
        return a
    def stat(self):
        t = self.t[0]
        if t == "local":
            self.eat(); 
            if self.accept("function"):
                n = self.eat("name")[1]; body = self.funcbody(); return ("localfun", n, body)
            names = [self.eat("name")[1]]
            while self.accept(","): names.append(self.eat("name")[1])
            ex = []
            if self.accept("="): ex = self.explist()
            return ("local", names, ex)
        if t == "function":
            self.eat(); names, meth = self.funcname(); return ("setfun", names, meth, self.funcbody())
        if t == "return":
            self.eat(); ex = [] if self.t[0] in ("end","else","elseif","until","eof",";") else self.explist(); self.accept(";"); return ("return", ex)
        if t == "break": self.eat(); return ("break",)
        if t == "if":
            self.eat(); clauses=[]
            clauses.append((self.expr(), self.need_block("then", ("elseif","else","end"))))
            while self.accept("elseif"): clauses.append((self.expr(), self.need_block("then", ("elseif","else","end"))))
            els = self.block(("end",)) if self.accept("else") else []
            self.eat("end"); return ("if", clauses, els)
        if t == "do":
            self.eat(); body=self.block(("end",)); self.eat("end"); return ("do", body)
        if t == "while":
            self.eat(); cond = self.expr(); body = self.need_block("do", ("end",)); self.eat("end"); return ("while", cond, body)
        if t == "repeat":
            self.eat(); body = self.block(("until",)); self.eat("until"); return ("repeat", body, self.expr())
        if t == "for":
            self.eat(); name = self.eat("name")[1]
            if self.accept("="):
                a = self.expr(); self.eat(","); b = self.expr(); c = self.expr() if self.accept(",") else ("num",1)
                body = self.need_block("do", ("end",)); self.eat("end"); return ("fornum", name, a,b,c,body)
            names=[name]
            while self.accept(","): names.append(self.eat("name")[1])
            self.eat("in"); ex=self.explist(); body=self.need_block("do", ("end",)); self.eat("end"); return ("forin", names, ex, body)
        lhs = self.prefix()
        if lhs[0] == "call": return ("callstat", lhs)
        vars = [lhs]
        while self.accept(","): vars.append(self.prefix())
        self.eat("="); return ("assign", vars, self.explist())
    def need_block(self, kw, stops):
        self.eat(kw); return self.block(stops)
    def funcname(self):
        names = [self.eat("name")[1]]
        while self.accept("."): names.append(self.eat("name")[1])
        meth = self.eat("name")[1] if self.accept(":") else None
        return names, meth
    def funcbody(self):
        self.eat("("); params=[]; vararg=False
        if self.t[0] != ")":
            if self.accept("..."): vararg=True
            else:
                params.append(self.eat("name")[1])
                while self.accept(","):
                    if self.accept("..."): vararg=True; break
                    params.append(self.eat("name")[1])
        self.eat(")"); body=self.block(("end",)); self.eat("end"); return (params,vararg,body)
    def explist(self):
        a=[self.expr()]
        while self.accept(","): a.append(self.expr())
        return a
    def expr(self, minp=0):
        t=self.t[0]
        if t in ("not","#","-","~"):
            self.eat(); left=("un",t,self.expr(12))
        elif t == "nil": self.eat(); left=("nil",)
        elif t == "true": self.eat(); left=("bool",True)
        elif t == "false": self.eat(); left=("bool",False)
        elif t == "num": left=("num",self.eat()[1])
        elif t == "str": left=("str",self.eat()[1])
        elif t == "...": self.eat(); left=("vararg",)
        elif t == "function": self.eat(); left=("fun",self.funcbody())
        elif t == "{": left=self.table()
        else: left=self.prefix()
        prec={"or":1,"and":2,"<":3,">":3,"<=":3,">=":3,"~=":3,"==":3,"|":4,"~":5,"&":6,"<<":7,">>":7,"..":8,"+":9,"-":9,"*":10,"/":10,"//":10,"%":10,"^":13}
        right_assoc = {"..","^"}
        while self.t[0] in prec and prec[self.t[0]] >= minp:
            op=self.eat()[0]; p=prec[op]
            left=("bin",op,left,self.expr(p if op in right_assoc else p+1))
        return left
    def prefix(self):
        if self.accept("("): e=self.expr(); self.eat(")"); node=e
        else: node=("var",self.eat("name")[1])
        while True:
            if self.accept("."): node=("idx",node,("str",self.eat("name")[1]))
            elif self.accept("["): k=self.expr(); self.eat("]"); node=("idx",node,k)
            elif self.accept(":"):
                m=self.eat("name")[1]; args=self.args(); node=("call",("idx",node,("str",m)),[node]+args)
            elif self.t[0] in ("(","{","str"): node=("call",node,self.args())
            else: break
        return node
    def args(self):
        if self.accept("("):
            a=[] if self.t[0] == ")" else self.explist(); self.eat(")"); return a
        if self.t[0] == "{": return [self.table()]
        if self.t[0] == "str": return [("str",self.eat()[1])]
        raise LuaError("function arguments expected")
    def table(self):
        self.eat("{"); fields=[]
        while self.t[0] != "}":
            if self.accept("["):
                k=self.expr(); self.eat("]"); self.eat("="); v=self.expr(); fields.append((k,v))
            elif self.t[0] == "name":
                save=self.t; self.eat()
                if self.accept("="): fields.append((("str",save[1]), self.expr()))
                else: fields.append((None, self.suffix_after(("var",save[1]))))
            else: fields.append((None,self.expr()))
            if not (self.accept(",") or self.accept(";")): break
        self.eat("}"); return ("table",fields)
    def suffix_after(self, node):
        while True:
            if self.accept("."): node=("idx",node,("str",self.eat("name")[1]))
            elif self.accept("["): k=self.expr(); self.eat("]"); node=("idx",node,k)
            elif self.t[0] in ("(","{","str"): node=("call",node,self.args())
            else: return node

class LuaFunc:
    def __init__(self, params, vararg, body, env): self.params,self.vararg,self.body,self.env=params,vararg,body,env
    def __call__(self, args):
        e=Env(self.env)
        for i,p in enumerate(self.params): e.set_local(p, args[i] if i < len(args) else None)
        e.set_local("...", args[len(self.params):] if self.vararg else [])
        try: exec_block(self.body, e)
        except ReturnEx as r: return r.vals
        return []
    def __str__(self): return "function: 0x%x" % (id(self)&0xffffffff)

def values(exs, env):
    out=[]
    for i,e in enumerate(exs):
        v=eval_expr(e,env, multi=(i==len(exs)-1))
        if isinstance(v, list): out += v
        else: out.append(v)
    return out
def first(v): return v[0] if isinstance(v,list) and v else (None if isinstance(v,list) else v)

def call(fn, args):
    if isinstance(fn, LuaFunc): return fn(args)
    if callable(fn): return fn(args)
    raise LuaError("attempt to call a %s value" % lua_type(fn))

def lua_type(v):
    if v is None: return "nil"
    if isinstance(v,bool): return "boolean"
    if isnum(v): return "number"
    if isinstance(v,str): return "string"
    if isinstance(v,Table): return "table"
    if callable(v): return "function"
    return type(v).__name__

def eval_expr(e, env, multi=False):
    k=e[0]
    if k=="nil": return None
    if k=="bool" or k=="num" or k=="str": return e[1]
    if k=="var": return env.get(e[1])
    if k=="vararg": return env.get("...") if multi else first(env.get("..."))
    if k=="fun":
        p,v,b=e[1]; return LuaFunc(p,v,b,env)
    if k=="table":
        t=Table(); arr=1
        for kk,vv in e[1]:
            val=first(eval_expr(vv,env, multi=True))
            if kk is None: t.set(arr,val); arr+=1
            else: t.set(first(eval_expr(kk,env)), val)
        return t
    if k=="idx":
        obj=first(eval_expr(e[1],env)); idx=first(eval_expr(e[2],env))
        if isinstance(obj,Table):
            v=obj.get(idx)
            if v is not None: return v
            mt=obj.mt
            ind=mt.get("__index") if isinstance(mt,Table) else None
            if isinstance(ind,Table): return ind.get(idx)
            if callable(ind): return first(call(ind,[obj,idx]))
            return None
        if isinstance(obj,str) and isinstance(idx,str):
            return string_lib().get(idx)
        return None
    if k=="call":
        fn=first(eval_expr(e[1],env)); args=values(e[2],env)
        r=call(fn,args)
        return r if multi else first(r)
    if k=="un":
        op=e[1]; v=first(eval_expr(e[2],env))
        if op=="not": return not truth(v)
        if op=="#": return v.length() if isinstance(v,Table) else len(v or "")
        if op=="-": return -v
        if op=="~": return ~int(v)
    if k=="bin":
        op,a,b=e[1],e[2],e[3]
        if op=="and":
            av=first(eval_expr(a,env)); return first(eval_expr(b,env)) if truth(av) else av
        if op=="or":
            av=first(eval_expr(a,env)); return av if truth(av) else first(eval_expr(b,env))
        x=first(eval_expr(a,env)); y=first(eval_expr(b,env))
        if op=="+": return x+y
        if op=="-": return x-y
        if op=="*": return x*y
        if op=="/": return x/y
        if op=="//": return math.floor(x/y)
        if op=="%": return x%y
        if op=="^": return x**y
        if op=="..": return fmt(x)+fmt(y)
        if op=="==": return x==y
        if op=="~=": return x!=y
        if op=="<": return x<y
        if op==">": return x>y
        if op=="<=": return x<=y
        if op==">=": return x>=y
        if op=="&": return int(x)&int(y)
        if op=="|": return int(x)|int(y)
        if op=="~": return int(x)^int(y)
        if op=="<<": return int(x)<<int(y)
        if op==">>": return int(x)>>int(y)
    raise LuaError("bad expression")

def assign_var(v, val, env):
    if v[0]=="var": env.set(v[1], val)
    elif v[0]=="idx":
        obj=first(eval_expr(v[1],env)); idx=first(eval_expr(v[2],env))
        if not isinstance(obj,Table): raise LuaError("attempt to index a %s value" % lua_type(obj))
        mt=obj.mt; ni=mt.get("__newindex") if isinstance(mt,Table) else None
        if obj.get(idx) is None and ni is not None:
            if isinstance(ni,Table): ni.set(idx,val); return
            if callable(ni): call(ni,[obj,idx,val]); return
        obj.set(idx,val)
    else: raise LuaError("syntax error")

def exec_block(sts, env):
    for s in sts: exec_stat(s, env)

def exec_stat(s, env):
    k=s[0]
    if k=="local":
        vals=values(s[2],env) if s[2] else []
        for i,n in enumerate(s[1]): env.set_local(n, vals[i] if i<len(vals) else None)
    elif k=="localfun":
        env.set_local(s[1], None); env.set(s[1], LuaFunc(*s[2], env))
    elif k=="setfun":
        names,meth,body=s[1],s[2],s[3]
        params,vararg,b=body
        if meth: params=[ "self" ]+params
        fn=LuaFunc(params,vararg,b,env)
        if len(names)==1 and not meth: env.set(names[0],fn)
        else:
            obj=env.get(names[0])
            for n in names[1:-1]: obj=obj.get(n)
            obj.set(meth or names[-1],fn)
    elif k=="assign":
        vals=values(s[2],env)
        for i,v in enumerate(s[1]): assign_var(v, vals[i] if i<len(vals) else None, env)
    elif k=="callstat": eval_expr(s[1],env)
    elif k=="return": raise ReturnEx(values(s[1],env))
    elif k=="break": raise BreakEx()
    elif k=="if":
        for c,b in s[1]:
            if truth(first(eval_expr(c,env))): exec_block(b, Env(env)); return
        exec_block(s[2], Env(env))
    elif k=="do":
        exec_block(s[1], Env(env))
    elif k=="while":
        while truth(first(eval_expr(s[1],env))):
            try: exec_block(s[2], Env(env))
            except BreakEx: break
    elif k=="repeat":
        while True:
            try: exec_block(s[1], Env(env))
            except BreakEx: break
            if truth(first(eval_expr(s[2],env))): break
    elif k=="fornum":
        start,stop,step=[first(eval_expr(x,env)) for x in s[2:5]]
        i=start
        def cont(i): return i <= stop if step >= 0 else i >= stop
        while cont(i):
            le=Env(env); le.set_local(s[1], i)
            try: exec_block(s[5], le)
            except BreakEx: break
            i += step
    elif k=="forin":
        vals=values(s[2],env); gen=vals[0] if vals else None
        if isinstance(gen, list): iterable=gen
        elif callable(gen): iterable=gen(vals[1:])
        else: iterable=[]
        for row in iterable:
            if not isinstance(row,(list,tuple)): row=[row]
            le=Env(env)
            for i,n in enumerate(s[1]): le.set_local(n, row[i] if i<len(row) else None)
            try: exec_block(s[3], le)
            except BreakEx: break

def table_lib():
    t=Table()
    t.set("insert", lambda a: (a[0].set(a[0].length()+1, a[1]) or []))
    t.set("remove", lambda a: [table_remove(a[0], a[1] if len(a)>1 and a[1] is not None else a[0].length())])
    t.set("concat", lambda a: [str_join(a[0], a[1] if len(a)>1 and a[1] is not None else "", int(a[2]) if len(a)>2 and a[2] is not None else 1, int(a[3]) if len(a)>3 and a[3] is not None else a[0].length())])
    return t
def table_remove(t,pos):
    v=t.get(pos); n=t.length()
    for i in range(int(pos), n): t.set(i,t.get(i+1))
    t.set(n,None); return v
def str_join(t,sep,i,j): return sep.join(fmt(t.get(k)) for k in range(i,j+1))

_string_lib=None
def string_lib():
    global _string_lib
    if _string_lib: return _string_lib
    t=Table()
    t.set("len", lambda a: [len(a[0])])
    t.set("lower", lambda a: [a[0].lower()])
    t.set("upper", lambda a: [a[0].upper()])
    t.set("sub", lambda a: [lua_sub(a[0], int(a[1]), int(a[2]) if len(a)>2 and a[2] is not None else -1)])
    t.set("rep", lambda a: [a[0]*int(a[1])])
    t.set("reverse", lambda a: [a[0][::-1]])
    t.set("format", lambda a: [a[0] % tuple(a[1:])])
    t.set("byte", lambda a: [ord(c) for c in lua_sub(a[0], int(a[1]) if len(a)>1 else 1, int(a[2]) if len(a)>2 and a[2] is not None else (int(a[1]) if len(a)>1 else 1))])
    t.set("char", lambda a: ["".join(chr(int(x)) for x in a)])
    _string_lib=t; return t
def lua_sub(s,i,j):
    n=len(s)
    if i<0: i=n+i+1
    if j<0: j=n+j+1
    i=max(i,1); j=min(j,n)
    return "" if j<i else s[i-1:j]

def math_lib():
    t=Table()
    for n in "abs floor ceil sqrt sin cos tan asin acos atan exp log deg rad".split():
        t.set(n, lambda a, n=n: [getattr(math,n)(*a)])
    t.set("max", lambda a: [max(a)])
    t.set("min", lambda a: [min(a)])
    t.set("pi", math.pi); t.set("huge", float("inf"))
    return t
def os_lib():
    import time
    t=Table()
    t.set("clock", lambda a: [time.process_time()])
    t.set("time", lambda a: [int(time.time())])
    t.set("date", lambda a: [time.strftime(a[0] if a else "%c")])
    t.set("exit", lambda a: sys.exit(int(a[0]) if a and a[0] is not True else 0))
    t.set("getenv", lambda a: [os.environ.get(str(a[0]))])
    return t
def io_lib():
    t=Table()
    t.set("write", lambda a: (sys.stdout.write("".join(fmt(x) for x in a)) or []))
    t.set("read", lambda a: [sys.stdin.readline().rstrip("\n")])
    t.set("flush", lambda a: (sys.stdout.flush() or []))
    return t

def base_env(argv):
    e=Env(); argt=Table()
    e.set_local("_VERSION", VERSION); e.set_local("arg", argt)
    e.set_local("print", lambda a: (sys.stdout.write("\t".join(fmt(x) for x in a)+"\n") or []))
    e.set_local("type", lambda a: [lua_type(a[0] if a else None)])
    e.set_local("tostring", lambda a: [fmt(a[0] if a else None)])
    e.set_local("tonumber", lambda a: [tonumber(a[0] if a else None, a[1] if len(a)>1 else None)])
    e.set_local("assert", lambda a: a if truth(a[0] if a else None) else (_raise(a[1] if len(a)>1 else "assertion failed!")))
    e.set_local("error", lambda a: _raise(a[0] if a else "error"))
    e.set_local("select", lambda a: select_fn(a))
    e.set_local("pairs", lambda a: [[list(x) for x in a[0].items()]])
    e.set_local("ipairs", lambda a: [[ [i,a[0].get(i)] for i in range(1,a[0].length()+1) ]])
    e.set_local("next", lambda a: next_fn(a))
    e.set_local("pcall", lambda a: pcall_fn(a))
    e.set_local("require", lambda a: [require_fn(e, a[0])])
    e.set_local("dofile", lambda a: run(open(a[0]).read(), e, [a[0]]))
    e.set_local("load", lambda a: [LuaFunc([], False, Parser(str(a[0])).parse()[1], e)])
    e.set_local("loadfile", lambda a: [LuaFunc([], False, Parser(open(a[0]).read()).parse()[1], e)])
    e.set_local("rawget", lambda a: [a[0].get(a[1])])
    e.set_local("rawset", lambda a: (a[0].set(a[1], a[2]) or [a[0]]))
    e.set_local("setmetatable", lambda a: (setattr(a[0], "mt", a[1]) or [a[0]]))
    e.set_local("getmetatable", lambda a: [a[0].mt if isinstance(a[0],Table) else None])
    e.set_local("table", table_lib()); e.set_local("string", string_lib()); e.set_local("math", math_lib()); e.set_local("io", io_lib()); e.set_local("os", os_lib())
    return e
def set_arg(env, script, script_args, optargs):
    t=Table()
    t.set(0, script if script is not None else sys.argv[0])
    for i,a in enumerate(script_args, 1): t.set(i,a)
    for i,a in enumerate(reversed(optargs), 1): t.set(-i,a)
    env.set("arg", t)
    env.set("...", script_args)
def _raise(x): raise LuaError(fmt(x))
def tonumber(x, base=None):
    try:
        if base is not None: return int(str(x), int(base))
        s=str(x).strip(); return float(s) if any(c in s for c in ".eE") else int(s,10)
    except Exception: return None
def select_fn(a):
    if not a: return []
    if a[0]=="#": return [len(a)-1]
    i=int(a[0]); return a[i:] if i>0 else a[len(a)+i:]
def next_fn(a):
    t=a[0]; last=a[1] if len(a)>1 else None; ks=[k for k,_ in t.items()]
    if last is None: idx=0
    else:
        try: idx=ks.index(key(last))+1
        except ValueError: idx=0
    if idx >= len(ks): return [None]
    k=ks[idx]; return [k,t.get(k)]
def pcall_fn(a):
    try: return [True]+call(a[0], a[1:])
    except Exception as ex: return [False, str(ex)]
def require_fn(env, mod):
    name=str(mod); loaded=env.get("package").get("loaded") if isinstance(env.get("package"),Table) else None
    if isinstance(loaded,Table) and loaded.get(name): return loaded.get(name)
    path=name.replace(".","/")+".lua"
    if os.path.exists(path):
        val=run(open(path).read(), env, [path])
        res=val[0] if val else True
        if isinstance(loaded,Table): loaded.set(name,res)
        return res
    raise LuaError("module '%s' not found" % name)
def lib_chunk(spec):
    if "=" in spec:
        g,m=spec.split("=",1)
        return "%s=require(%r)" % (g,m)
    return "require(%r)" % spec

def run(src, env, argv=None):
    ast=Parser(src).parse()
    try: exec_block(ast[1], env)
    except ReturnEx as r: return r.vals
    return []

def repl(env):
    for line in sys.stdin:
        try:
            src=line
            if line.lstrip().startswith("="): src="print("+line.lstrip()[1:].rstrip()+")"
            run(src, env)
        except Exception as ex: sys.stderr.write(str(ex)+"\n")

def main(argv):
    env=base_env(argv)
    pkg=Table(); loaded=Table(); pkg.set("loaded", loaded); env.set_local("package", pkg)
    for n in ("table","string","math","io","os"): loaded.set(n, env.get(n))
    i=1; interactive=False; chunks=[]; optargs=[]; script=None
    while i < len(argv):
        a=argv[i]
        if a=="--": i+=1; break
        if a=="-": script="-"; i+=1; break
        if not a.startswith("-") or a=="": script=a; i+=1; break
        if a=="-v": print("Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio")
        elif a=="-i": interactive=True
        elif a=="-E" or a=="-W": pass
        elif a=="-e":
            i+=1
            if i>=len(argv): raise LuaError("'-e' needs argument")
            chunks.append(argv[i]); optargs.append(argv[i])
        elif a.startswith("-e") and len(a)>2: chunks.append(a[2:]); optargs.append(a[2:])
        elif a=="-l":
            i+=1; optargs.append(argv[i]); chunks.append(lib_chunk(argv[i]))
        elif a.startswith("-l") and len(a)>2: optargs.append(a[2:]); chunks.append(lib_chunk(a[2:]))
        else:
            sys.stderr.write("%s: unrecognized option '%s'\n" % (argv[0], a))
            sys.stderr.write("usage: %s [options] [script [args]]\nAvailable options are:\n  -e stat   execute string 'stat'\n  -i        enter interactive mode after executing 'script'\n  -l mod    require library 'mod' into global 'mod'\n  -l g=mod  require library 'mod' into global 'g'\n  -v        show version information\n  -E        ignore environment variables\n  -W        turn warnings on\n  --        stop handling options\n  -         stop handling options and execute stdin\n" % argv[0])
            return 1
        i+=1
    try:
        set_arg(env, script, argv[i:], optargs)
        env.set("...", [])
        for c in chunks: run(c, env)
        if script is not None:
            env.set("...", argv[i:])
            src=sys.stdin.read() if script=="-" else open(script).read()
            run(src, env, argv[i:])
        elif not chunks or interactive:
            if sys.stdin.isatty(): pass
            else:
                data=sys.stdin.read()
                if data: run(data, env)
    except Exception as ex:
        sys.stderr.write("%s: %s\n" % (argv[0], ex)); return 1
    if interactive: repl(env)
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
