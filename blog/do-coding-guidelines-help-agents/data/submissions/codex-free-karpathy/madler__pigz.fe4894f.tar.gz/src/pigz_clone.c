#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <libgen.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <time.h>
#include <unistd.h>
#include <utime.h>
#include <zlib.h>

#define IN_CHUNK 65536
#define OUT_CHUNK 65536

typedef enum { FMT_GZIP, FMT_ZLIB, FMT_ZIP } Format;

typedef struct {
    int decompress, stdout_out, keep, force, test, list, verbose, quiet;
    int recursive, no_name, name, no_time, time_flag;
    int level, processes;
    Format fmt;
    const char *suffix, *comment, *alias;
} Opts;

typedef struct {
    unsigned char *data;
    size_t len, cap;
} Buf;

typedef struct {
    char **items;
    int len, cap;
} StrList;

static const char *prog = "pigz";

static void *xmalloc(size_t n) {
    void *p = malloc(n ? n : 1);
    if (!p) { fprintf(stderr, "%s: out of memory\n", prog); exit(1); }
    return p;
}

static void buf_put(Buf *b, const void *src, size_t n) {
    if (n == 0) return;
    if (b->len + n > b->cap) {
        size_t nc = b->cap ? b->cap * 2 : 65536;
        while (nc < b->len + n) nc *= 2;
        unsigned char *p = realloc(b->data, nc);
        if (!p) { fprintf(stderr, "%s: out of memory\n", prog); exit(1); }
        b->data = p; b->cap = nc;
    }
    memcpy(b->data + b->len, src, n);
    b->len += n;
}

static void put16(Buf *b, unsigned v) {
    unsigned char x[2] = { v & 255, (v >> 8) & 255 };
    buf_put(b, x, 2);
}

static void put32(Buf *b, uint32_t v) {
    unsigned char x[4] = { v & 255, (v >> 8) & 255, (v >> 16) & 255, (v >> 24) & 255 };
    buf_put(b, x, 4);
}

static uint32_t get32(const unsigned char *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint16_t get16(const unsigned char *p) {
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static void list_add(StrList *l, const char *s) {
    if (l->len >= l->cap) {
        l->cap = l->cap ? l->cap * 2 : 32;
        l->items = realloc(l->items, (size_t)l->cap * sizeof(char *));
        if (!l->items) exit(1);
    }
    l->items[l->len++] = strdup(s);
}

static void usage(void) {
    puts("Usage: pigz [options] [files ...]\n"
         "  will compress files in place, adding the suffix '.gz'. If no files are\n"
         "  specified, stdin will be compressed to stdout. pigz does what gzip does,\n"
         "  but spreads the work over multiple processors and cores when compressing.\n\n"
         "Options:\n"
         "  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)\n"
         "  --fast, --best       Compression levels 1 and 9 respectively\n"
         "  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin\n"
         "  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)\n"
         "  -c, --stdout         Write all processed output to stdout (won't delete)\n"
         "  -C, --comment ccc    Put comment ccc in the gzip or zip header\n"
         "  -d, --decompress     Decompress the compressed input\n"
         "  -f, --force          Force overwrite, compress .gz, links, and to terminal\n"
         "  -h, --help           Display a help screen and quit\n"
         "  -H, --huffman        Use only Huffman coding for compression\n"
         "  -i, --independent    Compress blocks independently for damage recovery\n"
         "  -k, --keep           Do not delete original file after processing\n"
         "  -K, --zip            Compress to PKWare zip (.zip) single entry format\n"
         "  -l, --list           List the contents of the compressed input\n"
         "  -L, --license        Display the pigz license and quit\n"
         "  -m, --no-time        Do not store or restore mod time\n"
         "  -M, --time           Store or restore mod time\n"
         "  -n, --no-name        Do not store or restore file name or mod time\n"
         "  -N, --name           Store or restore file name and mod time\n"
         "  -p, --processes n    Allow up to n compression threads (default is the\n"
         "                       number of online processors, or 8 if unknown)\n"
         "  -q, --quiet          Print no messages, even on error\n"
         "  -r, --recursive      Process the contents of all subdirectories\n"
         "  -R, --rsyncable      Input-determined block locations for rsync\n"
         "  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)\n"
         "  -t, --test           Test the integrity of the compressed input\n"
         "  -U, --rle            Use run-length encoding for compression\n"
         "  -v, --verbose        Provide more verbose output\n"
         "  -V  --version        Show the version of pigz\n"
         "  -Y  --synchronous    Force output file write to permanent storage\n"
         "  -z, --zlib           Compress to zlib (.zz) instead of gzip format\n"
         "  --                   All arguments after \"--\" are treated as files");
}

static void license(void) {
    puts("pigz 2.8\nCopyright (C) 2007-2023 Mark Adler\nSubject to the terms of the zlib license.\nNo warranty is provided or implied.");
}

static void init_opts(Opts *o) {
    memset(o, 0, sizeof(*o));
    o->level = Z_DEFAULT_COMPRESSION;
    o->processes = 0;
    o->fmt = FMT_GZIP;
    o->suffix = ".gz";
    o->alias = "-";
    o->name = 1;
}

static void add_arg(char ***arr, int *n, int *cap, const char *s) {
    if (*n >= *cap) {
        *cap = *cap ? *cap * 2 : 32;
        *arr = realloc(*arr, (size_t)*cap * sizeof(char *));
        if (!*arr) exit(1);
    }
    (*arr)[(*n)++] = strdup(s);
}

static void split_env(char ***arr, int *n, int *cap, const char *env) {
    if (!env) return;
    const char *p = env;
    while (*p) {
        while (*p == ' ' || *p == '\t' || *p == '\n') p++;
        if (!*p) break;
        char quote = 0;
        if (*p == '\'' || *p == '"') quote = *p++;
        const char *start = p;
        while (*p && ((quote && *p != quote) || (!quote && *p != ' ' && *p != '\t' && *p != '\n'))) p++;
        size_t nlen = (size_t)(p - start);
        char *s = xmalloc(nlen + 1);
        memcpy(s, start, nlen); s[nlen] = 0;
        add_arg(arr, n, cap, s);
        free(s);
        if (quote && *p == quote) p++;
    }
}

static const char *need_value(int *i, int argc, char **argv, const char *opt) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "%s: option %s requires an argument\n", prog, opt);
        exit(1);
    }
    return argv[++*i];
}

static int parse_opts(Opts *o, int argc, char **argv, char ***files) {
    int fn = 0, fcap = 0, stop = 0;
    *files = NULL;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (stop || a[0] != '-' || strcmp(a, "-") == 0) {
            add_arg(files, &fn, &fcap, a);
            continue;
        }
        if (strcmp(a, "--") == 0) { stop = 1; continue; }
        if (strncmp(a, "--", 2) == 0) {
            if (!strcmp(a, "--fast")) o->level = 1;
            else if (!strcmp(a, "--best")) o->level = 9;
            else if (!strcmp(a, "--stdout") || !strcmp(a, "--to-stdout")) o->stdout_out = 1;
            else if (!strcmp(a, "--decompress") || !strcmp(a, "--uncompress")) o->decompress = 1;
            else if (!strcmp(a, "--force")) o->force = 1;
            else if (!strcmp(a, "--help")) { usage(); exit(0); }
            else if (!strcmp(a, "--keep")) o->keep = 1;
            else if (!strcmp(a, "--zip")) { o->fmt = FMT_ZIP; o->suffix = ".zip"; }
            else if (!strcmp(a, "--list")) { o->list = 1; o->decompress = 1; }
            else if (!strcmp(a, "--license")) { license(); exit(0); }
            else if (!strcmp(a, "--no-time")) o->no_time = 1;
            else if (!strcmp(a, "--time")) o->time_flag = 1;
            else if (!strcmp(a, "--no-name")) { o->no_name = 1; o->name = 0; }
            else if (!strcmp(a, "--name")) { o->name = 1; o->no_name = 0; }
            else if (!strcmp(a, "--quiet") || !strcmp(a, "--silent")) o->quiet = 1;
            else if (!strcmp(a, "--recursive")) o->recursive = 1;
            else if (!strcmp(a, "--test")) { o->test = 1; o->decompress = 1; }
            else if (!strcmp(a, "--verbose")) o->verbose++;
            else if (!strcmp(a, "--version")) {
                printf("pigz 2.8\n");
                if (o->verbose) printf("zlib %s\n", zlibVersion());
                exit(0);
            }
            else if (!strcmp(a, "--zlib")) { o->fmt = FMT_ZLIB; o->suffix = ".zz"; }
            else if (!strcmp(a, "--alias")) o->alias = need_value(&i, argc, argv, a);
            else if (!strcmp(a, "--blocksize") || !strcmp(a, "--processes") || !strcmp(a, "--iterations") || !strcmp(a, "--maxsplits")) (void)need_value(&i, argc, argv, a);
            else if (!strcmp(a, "--suffix")) o->suffix = need_value(&i, argc, argv, a);
            else if (!strcmp(a, "--comment")) o->comment = need_value(&i, argc, argv, a);
            else if (!strcmp(a, "--huffman") || !strcmp(a, "--independent") || !strcmp(a, "--rsyncable") || !strcmp(a, "--rle") || !strcmp(a, "--synchronous") || !strcmp(a, "--first") || !strcmp(a, "--oneblock")) {}
            else { fprintf(stderr, "%s: abort: invalid option: %s\n", prog, a); exit(1); }
            continue;
        }
        for (size_t j = 1; a[j]; j++) {
            char c = a[j];
            if (c == '1' && a[j+1] == '1') { o->level = 9; j++; }
            else if (c >= '0' && c <= '9') o->level = c - '0';
            else if (c == 'c') o->stdout_out = 1;
            else if (c == 'd') o->decompress = 1;
            else if (c == 'f') o->force = 1;
            else if (c == 'h') { usage(); exit(0); }
            else if (c == 'k') o->keep = 1;
            else if (c == 'K') { o->fmt = FMT_ZIP; o->suffix = ".zip"; }
            else if (c == 'l') { o->list = 1; o->decompress = 1; }
            else if (c == 'L') { license(); exit(0); }
            else if (c == 'm') o->no_time = 1;
            else if (c == 'M') o->time_flag = 1;
            else if (c == 'n') { o->no_name = 1; o->name = 0; }
            else if (c == 'N') { o->name = 1; o->no_name = 0; }
            else if (c == 'q') o->quiet = 1;
            else if (c == 'r') o->recursive = 1;
            else if (c == 't') { o->test = 1; o->decompress = 1; }
            else if (c == 'v') o->verbose++;
            else if (c == 'V') {
                printf("pigz 2.8\n");
                if (o->verbose) printf("zlib %s\n", zlibVersion());
                exit(0);
            }
            else if (c == 'z') { o->fmt = FMT_ZLIB; o->suffix = ".zz"; }
            else if (strchr("AbCpSIJ", c)) {
                char optname[3] = {'-', c, 0};
                const char *val = a[j+1] ? a + j + 1 : need_value(&i, argc, argv, optname);
                if (c == 'A') o->alias = val;
                else if (c == 'C') o->comment = val;
                else if (c == 'S') o->suffix = val;
                j = strlen(a) - 1;
            }
            else if (strchr("HiRFUOY", c)) {}
            else { fprintf(stderr, "%s: abort: invalid option: -%c\n", prog, c); exit(1); }
        }
    }
    return fn;
}

static int read_all(FILE *in, Buf *b, uint32_t *crc, uint64_t *size) {
    unsigned char tmp[IN_CHUNK];
    *crc = crc32(0L, Z_NULL, 0);
    *size = 0;
    for (;;) {
        size_t n = fread(tmp, 1, sizeof(tmp), in);
        if (n) {
            buf_put(b, tmp, n);
            *crc = crc32(*crc, tmp, (uInt)n);
            *size += n;
        }
        if (n < sizeof(tmp)) {
            if (ferror(in)) return -1;
            return 0;
        }
    }
}

static int write_all(FILE *out, const unsigned char *data, size_t len) {
    return fwrite(data, 1, len, out) == len ? 0 : -1;
}

static int deflate_buffer(const unsigned char *in, size_t inlen, Buf *out, int level, int window_bits, gz_header *hdr) {
    z_stream s;
    unsigned char tmp[OUT_CHUNK];
    memset(&s, 0, sizeof(s));
    if (deflateInit2(&s, level, Z_DEFLATED, window_bits, 8, Z_DEFAULT_STRATEGY) != Z_OK) return -1;
    if (hdr && deflateSetHeader(&s, hdr) != Z_OK) { deflateEnd(&s); return -1; }
    s.next_in = (Bytef *)in;
    s.avail_in = (uInt)inlen;
    int ret;
    do {
        s.next_out = tmp;
        s.avail_out = sizeof(tmp);
        ret = deflate(&s, Z_FINISH);
        if (ret != Z_OK && ret != Z_STREAM_END) { deflateEnd(&s); return -1; }
        buf_put(out, tmp, sizeof(tmp) - s.avail_out);
    } while (ret != Z_STREAM_END);
    deflateEnd(&s);
    return 0;
}

static int gzip_compress(Buf *input, Buf *out, const Opts *o, const char *name, time_t mtime) {
    gz_header hdr;
    memset(&hdr, 0, sizeof(hdr));
    hdr.os = 3;
    hdr.time = (uLong)(o->no_time ? 0 : mtime);
    if (o->name && name && strcmp(name, "-") != 0) hdr.name = (Bytef *)name;
    if (o->comment) hdr.comment = (Bytef *)o->comment;
    return deflate_buffer(input->data, input->len, out, o->level, 15 + 16, &hdr);
}

static int zlib_compress(Buf *input, Buf *out, const Opts *o) {
    return deflate_buffer(input->data, input->len, out, o->level, 15, NULL);
}

static void dos_time(time_t when, unsigned *dtime, unsigned *ddate) {
    struct tm *tm = localtime(&when);
    if (!tm) { *dtime = 0; *ddate = (1 << 5) | 1; return; }
    int year = tm->tm_year + 1900;
    if (year < 1980) year = 1980;
    *dtime = ((unsigned)tm->tm_hour << 11) | ((unsigned)tm->tm_min << 5) | ((unsigned)tm->tm_sec / 2);
    *ddate = ((unsigned)(year - 1980) << 9) | ((unsigned)(tm->tm_mon + 1) << 5) | (unsigned)tm->tm_mday;
}

static int zip_compress(Buf *input, Buf *out, const Opts *o, const char *name, time_t mtime, uint32_t crc) {
    Buf comp = {0};
    if (deflate_buffer(input->data, input->len, &comp, o->level, -15, NULL) != 0) return -1;
    const char *entry = name && *name ? name : o->alias;
    size_t nlen = strlen(entry);
    unsigned dt, dd; dos_time(o->no_time ? 0 : mtime, &dt, &dd);
    put32(out, 0x04034b50); put16(out, 20); put16(out, 0); put16(out, 8);
    put16(out, dt); put16(out, dd); put32(out, crc); put32(out, (uint32_t)comp.len); put32(out, (uint32_t)input->len);
    put16(out, (unsigned)nlen); put16(out, 0); buf_put(out, entry, nlen); buf_put(out, comp.data, comp.len);
    uint32_t cd_start = (uint32_t)out->len;
    put32(out, 0x02014b50); put16(out, 0x031e); put16(out, 20); put16(out, 0); put16(out, 8);
    put16(out, dt); put16(out, dd); put32(out, crc); put32(out, (uint32_t)comp.len); put32(out, (uint32_t)input->len);
    put16(out, (unsigned)nlen); put16(out, 0); put16(out, o->comment ? (unsigned)strlen(o->comment) : 0);
    put16(out, 0); put16(out, 0); put32(out, 0); put32(out, 0); buf_put(out, entry, nlen);
    if (o->comment) buf_put(out, o->comment, strlen(o->comment));
    uint32_t cd_len = (uint32_t)out->len - cd_start;
    put32(out, 0x06054b50); put16(out, 0); put16(out, 0); put16(out, 1); put16(out, 1);
    put32(out, cd_len); put32(out, cd_start); put16(out, 0);
    free(comp.data);
    return 0;
}

static int inflate_stream(FILE *in, FILE *out, int window_bits, int discard, uint64_t *usize, uint32_t *crc) {
    z_stream s;
    unsigned char ibuf[IN_CHUNK], obuf[OUT_CHUNK];
    memset(&s, 0, sizeof(s));
    if (inflateInit2(&s, window_bits) != Z_OK) return -1;
    *usize = 0; *crc = crc32(0L, Z_NULL, 0);
    int ret = Z_OK;
    do {
        if (s.avail_in == 0) {
            s.next_in = ibuf;
            s.avail_in = (uInt)fread(ibuf, 1, sizeof(ibuf), in);
            if (ferror(in)) { inflateEnd(&s); return -1; }
            if (s.avail_in == 0) break;
        }
        do {
            s.next_out = obuf;
            s.avail_out = sizeof(obuf);
            ret = inflate(&s, Z_NO_FLUSH);
            if (ret != Z_OK && ret != Z_STREAM_END) { inflateEnd(&s); return -1; }
            size_t have = sizeof(obuf) - s.avail_out;
            if (have) {
                if (!discard && write_all(out, obuf, have) != 0) { inflateEnd(&s); return -1; }
                *crc = crc32(*crc, obuf, (uInt)have);
                *usize += have;
            }
        } while (s.avail_out == 0);
    } while (ret != Z_STREAM_END);
    inflateEnd(&s);
    return ret == Z_STREAM_END ? 0 : -1;
}

static int inflate_mem(const unsigned char *data, size_t len, int window_bits, Buf *out, uint64_t *usize, uint32_t *crc, size_t *consumed) {
    z_stream s;
    unsigned char obuf[OUT_CHUNK];
    memset(&s, 0, sizeof(s));
    if (inflateInit2(&s, window_bits) != Z_OK) return -1;
    s.next_in = (Bytef *)data; s.avail_in = (uInt)len;
    *usize = 0; *crc = crc32(0L, Z_NULL, 0);
    int ret;
    do {
        s.next_out = obuf; s.avail_out = sizeof(obuf);
        ret = inflate(&s, Z_NO_FLUSH);
        if (ret != Z_OK && ret != Z_STREAM_END) { inflateEnd(&s); return -1; }
        size_t have = sizeof(obuf) - s.avail_out;
        if (have) {
            if (out) buf_put(out, obuf, have);
            *crc = crc32(*crc, obuf, (uInt)have);
            *usize += have;
        }
    } while (ret != Z_STREAM_END);
    if (consumed) *consumed = len - s.avail_in;
    inflateEnd(&s);
    return 0;
}

static int zip_decompress(FILE *in, FILE *out, int discard, uint64_t *usize, uint32_t *crc) {
    Buf all = {0}, decomp = {0};
    uint32_t dummy_crc; uint64_t dummy_size;
    if (read_all(in, &all, &dummy_crc, &dummy_size) != 0) return -1;
    if (all.len < 30 || get32(all.data) != 0x04034b50) { free(all.data); return -1; }
    unsigned flags = get16(all.data + 6), method = get16(all.data + 8);
    uint32_t csize = get32(all.data + 18);
    unsigned nlen = get16(all.data + 26), xlen = get16(all.data + 28);
    size_t off = 30u + nlen + xlen;
    if (off > all.len) { free(all.data); return -1; }
    size_t consumed = 0;
    int ok = -1;
    if (method == 0) {
        if (csize == 0 || off + csize > all.len) csize = (uint32_t)(all.len - off);
        if (!discard && write_all(out, all.data + off, csize) != 0) ok = -1;
        else { *crc = crc32(0L, Z_NULL, 0); *crc = crc32(*crc, all.data + off, csize); *usize = csize; ok = 0; }
    } else if (method == 8) {
        size_t avail = (csize && !(flags & 8) && off + csize <= all.len) ? csize : all.len - off;
        ok = inflate_mem(all.data + off, avail, -15, discard ? NULL : &decomp, usize, crc, &consumed);
        (void)consumed;
        if (ok == 0 && !discard) ok = write_all(out, decomp.data, decomp.len);
    }
    free(all.data); free(decomp.data);
    return ok;
}

static long gzip_payload_size(FILE *in, long total) {
    long pos = ftell(in);
    rewind(in);
    int h[10];
    for (int i = 0; i < 10; i++) h[i] = fgetc(in);
    long off = 10;
    if (h[0] != 0x1f || h[1] != 0x8b || h[2] != 8) { fseek(in, pos, SEEK_SET); return total; }
    int flg = h[3];
    if (flg & 4) {
        int lo = fgetc(in), hi = fgetc(in);
        if (lo == EOF || hi == EOF) { fseek(in, pos, SEEK_SET); return total; }
        unsigned xlen = (unsigned)lo | ((unsigned)hi << 8);
        off += 2 + xlen;
        fseek(in, (long)xlen, SEEK_CUR);
    }
    if (flg & 8) { int c; do { c = fgetc(in); off++; } while (c > 0); }
    if (flg & 16) { int c; do { c = fgetc(in); off++; } while (c > 0); }
    if (flg & 2) off += 2;
    fseek(in, pos, SEEK_SET);
    long payload = total - off - 8;
    return payload >= 0 ? payload : total;
}

static int decompress_file(FILE *in, FILE *out, int discard, uint64_t *usize, uint32_t *crc) {
    int c1 = fgetc(in), c2 = fgetc(in), c3 = fgetc(in), c4 = fgetc(in);
    if (c1 == EOF || c2 == EOF) return -1;
    ungetc(c4, in); ungetc(c3, in); ungetc(c2, in); ungetc(c1, in);
    if (c1 == 'P' && c2 == 'K' && c3 == 3 && c4 == 4) return zip_decompress(in, out, discard, usize, crc);
    return inflate_stream(in, out, 47, discard, usize, crc);
}

static char *base_name_dup(const char *path) {
    char *tmp = strdup(path);
    char *b = basename(tmp);
    char *r = strdup(b);
    free(tmp);
    return r;
}

static char *out_compress_name(const char *path, const Opts *o) {
    size_t n = strlen(path), s = strlen(o->suffix);
    char *r = xmalloc(n + s + 1);
    memcpy(r, path, n); memcpy(r + n, o->suffix, s + 1);
    return r;
}

static char *out_decompress_name(const char *path, const Opts *o) {
    size_t n = strlen(path), s = strlen(o->suffix);
    if (s && n > s && strcmp(path + n - s, o->suffix) == 0) {
        char *r = xmalloc(n - s + 1);
        memcpy(r, path, n - s); r[n - s] = 0; return r;
    }
    const char *known[] = { ".gz", ".zz", ".zip", ".tgz", NULL };
    for (int i = 0; known[i]; i++) {
        s = strlen(known[i]);
        if (n > s && strcmp(path + n - s, known[i]) == 0) {
            char *r = xmalloc(n - s + 1);
            memcpy(r, path, n - s); r[n - s] = 0; return r;
        }
    }
    char *r = xmalloc(n + 5);
    sprintf(r, "%s.out", path);
    return r;
}

static FILE *open_output(const char *path, const Opts *o) {
    if (!o->force && access(path, F_OK) == 0) {
        fprintf(stderr, "%s: skipping: %s exists\n", prog, path);
        return NULL;
    }
    return fopen(path, "wb");
}

static int process_compress(const Opts *o, const char *path) {
    FILE *in = stdin, *outf = stdout;
    char *outname = NULL, *bname = NULL;
    struct stat st;
    memset(&st, 0, sizeof(st));
    int from_stdin = !path || strcmp(path, "-") == 0;
    if (!from_stdin) {
        if (stat(path, &st) != 0 || S_ISDIR(st.st_mode)) { if (!o->quiet) fprintf(stderr, "%s: skipping: %s\n", prog, path); return 1; }
        in = fopen(path, "rb");
        if (!in) { perror(path); return 1; }
    }
    Buf input = {0}, output = {0};
    uint32_t crc; uint64_t usize;
    if (read_all(in, &input, &crc, &usize) != 0) { perror(path ? path : "stdin"); return 1; }
    if (!from_stdin) fclose(in);
    if (from_stdin) bname = strdup(o->fmt == FMT_ZIP ? o->alias : "-");
    else bname = base_name_dup(path);
    int rc;
    if (o->fmt == FMT_ZLIB) rc = zlib_compress(&input, &output, o);
    else if (o->fmt == FMT_ZIP) rc = zip_compress(&input, &output, o, bname, from_stdin ? 0 : st.st_mtime, crc);
    else rc = gzip_compress(&input, &output, o, from_stdin ? NULL : bname, from_stdin ? 0 : st.st_mtime);
    if (rc != 0) { fprintf(stderr, "%s: compression failed\n", prog); return 1; }
    if (!o->stdout_out && !from_stdin) {
        outname = out_compress_name(path, o);
        outf = open_output(outname, o);
        if (!outf) return 1;
    }
    if (write_all(outf, output.data, output.len) != 0 || fflush(outf) != 0) { perror(outname ? outname : "stdout"); return 1; }
    if (outf != stdout) {
        fclose(outf);
        chmod(outname, st.st_mode & 0777);
        struct utimbuf ut = { st.st_atime, st.st_mtime };
        utime(outname, &ut);
        if (!o->keep) unlink(path);
    }
    free(input.data); free(output.data); free(outname); free(bname);
    return 0;
}

static int process_decompress(const Opts *o, const char *path) {
    int from_stdin = !path || strcmp(path, "-") == 0;
    FILE *in = stdin, *out = stdout;
    char *outname = NULL;
    struct stat st;
    memset(&st, 0, sizeof(st));
    if (!from_stdin) {
        if (stat(path, &st) != 0) { perror(path); return 1; }
        in = fopen(path, "rb");
        if (!in) { perror(path); return 1; }
    }
    if (o->list) {
        uint64_t usize; uint32_t crc;
        int rc = decompress_file(in, stdout, 1, &usize, &crc);
        if (rc != 0) { if (!o->quiet) fprintf(stderr, "%s: skipping: %s: corrupted -- incomplete deflate data\n", prog, path ? path : "stdin"); return 1; }
        long csize = 0;
        if (!from_stdin) csize = gzip_payload_size(in, (long)st.st_size);
        if (!o->quiet) {
            printf("compressed   original reduced  name\n");
            double red = usize ? (100.0 * (1.0 - (double)csize / (double)usize)) : 0.0;
            printf("%10ld %10llu %6.1f%%  %s\n", csize, (unsigned long long)usize, red, path ? out_decompress_name(path, o) : "-");
        }
        if (!from_stdin) fclose(in);
        return 0;
    }
    if (!o->stdout_out && !o->test && !from_stdin) {
        outname = out_decompress_name(path, o);
        out = open_output(outname, o);
        if (!out) return 1;
    }
    uint64_t usize; uint32_t crc;
    int rc = decompress_file(in, out, o->test, &usize, &crc);
    if (rc != 0) { if (!o->quiet) fprintf(stderr, "%s: skipping: %s: corrupted -- incomplete deflate data\n", prog, path ? path : "stdin"); return 1; }
    if (out != stdout) {
        fclose(out);
        chmod(outname, st.st_mode & 0777);
        struct utimbuf ut = { st.st_atime, st.st_mtime };
        utime(outname, &ut);
        if (!o->keep) unlink(path);
    }
    if (o->verbose && o->test && !o->quiet) fprintf(stderr, "%s: OK\n", path ? path : "<stdin>");
    if (!from_stdin) fclose(in);
    free(outname);
    (void)usize; (void)crc;
    return 0;
}

static void collect_paths(const char *path, const Opts *o, StrList *out) {
    struct stat st;
    if (stat(path, &st) != 0) {
        list_add(out, path);
        return;
    }
    if (!S_ISDIR(st.st_mode)) {
        list_add(out, path);
        return;
    }
    if (!o->recursive) {
        if (!o->quiet) fprintf(stderr, "%s: skipping: %s is a directory\n", prog, path);
        return;
    }
    DIR *d = opendir(path);
    if (!d) {
        if (!o->quiet) perror(path);
        return;
    }
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        size_t n = strlen(path), m = strlen(e->d_name);
        char *child = xmalloc(n + m + 2);
        memcpy(child, path, n);
        child[n] = '/';
        memcpy(child + n + 1, e->d_name, m + 1);
        collect_paths(child, o, out);
        free(child);
    }
    closedir(d);
}

int main(int argc, char **argv) {
    prog = basename(argv[0]);
    Opts opts; init_opts(&opts);
    if (strstr(prog, "unpigz")) opts.decompress = 1;

    char **all = NULL; int an = 0, acap = 0;
    add_arg(&all, &an, &acap, argv[0]);
    split_env(&all, &an, &acap, getenv("GZIP"));
    split_env(&all, &an, &acap, getenv("PIGZ"));
    for (int i = 1; i < argc; i++) add_arg(&all, &an, &acap, argv[i]);

    char **files = NULL;
    int fn = parse_opts(&opts, an, all, &files);
    if (opts.list || opts.test) opts.decompress = 1;
    if (fn == 0) {
        int rc = opts.decompress ? process_decompress(&opts, NULL) : process_compress(&opts, NULL);
        return rc;
    }
    StrList paths = {0};
    for (int i = 0; i < fn; i++) collect_paths(files[i], &opts, &paths);
    int bad = 0;
    for (int i = 0; i < paths.len; i++) {
        if (opts.decompress) bad |= process_decompress(&opts, paths.items[i]);
        else bad |= process_compress(&opts, paths.items[i]);
    }
    return bad ? 1 : 0;
}
