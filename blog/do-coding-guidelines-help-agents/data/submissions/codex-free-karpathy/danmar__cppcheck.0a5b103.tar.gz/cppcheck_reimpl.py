#!/usr/bin/env python3
import os, sys, re, fnmatch, json, html
from pathlib import Path

VERSION='Cppcheck 2.19 dev'
SRC_EXT={'.cpp','.cxx','.cc','.c++','.c','.ipp','.ixx','.tpp','.txx','.h','.hpp'}
HELP='''Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    --addon=<addon>     Execute addon.
    --check-config      Check cppcheck configuration.
    --check-level=<level>
    --check-library     Show information messages when library files have incomplete info.
    --checkers-report=<file>
    -D<ID>              Define preprocessor symbol.
    -E                  Print preprocessor output on stdout and don't do any further processing.
    --enable=<severity> Enable additional checks: warning, performance, portability, information, style, unusedFunction, missingInclude, all.
    --disable=<severity> Disable checks with the given severity.
    --error-exitcode=<n> If errors are found, integer [n] is returned instead of the default '0'.
    --errorlist         Print a list of all the error messages in XML format.
    --file-list=<file>  Specify the files to check in a text file.
    -f, --force         Force checking of all configurations in files.
    -h, --help          Print this help.
    -I <dir>            Give path to search for include files.
    --include=<file>    Force inclusion of a file before the checked file.
    -i <str>            Ignore files that match <str>.
    --inconclusive      Allow that Cppcheck reports even though the analysis is inconclusive.
    --inline-suppr      Enable inline suppressions.
    -j <jobs>           Start <jobs> threads to do the checking simultaneously.
    --language=<language>, -x <language>  Forces cppcheck to check all files as c or c++.
    --library=<cfg>     Load library configuration.
    --max-configs=<limit>
    --output-file=<file> Write results to file, rather than standard error.
    --output-format=<format> Specify output format: text, sarif, xml, xmlv2, xmlv3.
    --platform=<type>   Specifies platform specific types and sizes.
    --project=<file>    Run Cppcheck on project/compile database.
    -q, --quiet         Do not show progress reports.
    --suppress=<spec>   Suppress warnings that match [error id]:[filename]:[line].
    --suppressions-list=<file>
    --template='<text>' Format the error messages.
    -U<ID>              Undefine preprocessor symbol.
    -v, --verbose       Output more detailed error information.
    --version           Print out version number.
    --xml               Write results in xml format to error stream (stderr).

Example usage:
  cppcheck . 2> err.txt
  cppcheck --quiet ../myproject/
  cppcheck --enable=all --inconclusive --library=posix test.cpp
  cppcheck -I inc1/ -I inc2/ f.cpp

For more information:
    https://cppcheck.sourceforge.io/manual.pdf
'''
ERRORLIST=[
 ('arrayIndexOutOfBounds','error',"Array 'arr[16]' accessed at index 16, which is out of bounds.",'788'),
 ('negativeIndex','error','Negative array index','786'),
 ('zerodiv','error','Division by zero.','369'),
 ('nullPointer','error','Null pointer dereference','476'),
 ('uninitvar','error','Uninitialized variable: var','457'),
 ('memleak','error','Memory leak: var','401'),
 ('unusedVariable','style','Variable var is assigned a value that is never used.','563'),
 ('unusedFunction','style','The function func is never used.','561'),
 ('missingInclude','information','Include file is not found: file','')]
class Opt:
    def __init__(self):
        self.quiet=False; self.xml=False; self.sarif=False; self.errcode=0; self.enable=set(); self.disable=set(); self.template='gcc'; self.output=None; self.suppress=[]; self.includes=[]; self.ignore=[]; self.preprocess=False; self.defs={}; self.undef=set(); self.files=[]; self.file_filters=[]; self.inline=False; self.check_config=False

def die(msg):
    sys.stderr.write('cppcheck: error: '+msg+'\n'); return 1

def parse(argv):
    o=Opt(); i=0
    noarg={'--addon','--addon-python','--cppcheck-build-dir','--check-level','--checkers-report','--clang','--config-exclude','--config-excludes-file','--disable','--enable','--error-exitcode','--exitcode-suppressions','--file-filter','--file-list','--includes-file','--include','--language','--library','--max-configs','--max-ctu-depth','--output-file','--output-format','--platform','--plist-output','--project','--project-configuration','--relative-paths','--report-type','--rule','--rule-file','--showtime','--std','--suppress','--suppressions-list','--suppress-xml','--template','--template-location','-l','-j','-x'}
    while i < len(argv):
        a=argv[i]
        if a in ('-h','--help'): print(HELP); sys.exit(0)
        if a=='--version': print(VERSION); sys.exit(0)
        if a=='--errorlist': print_errorlist(); sys.exit(0)
        if a in ('-q','--quiet'): o.quiet=True; i+=1; continue
        if a in ('--xml',): o.xml=True; i+=1; continue
        if a=='-E': o.preprocess=True; i+=1; continue
        if a=='--inline-suppr': o.inline=True; i+=1; continue
        if a=='--check-config': o.check_config=True; i+=1; continue
        if a.startswith('-D') and a!='-D':
            k,v=(a[2:].split('=',1)+['1'])[:2] if '=' in a[2:] else (a[2:],'1'); o.defs[k]=v; i+=1; continue
        if a=='-D':
            if i+1>=len(argv): return None,"argument to '-D' is missing."
            k=argv[i+1]; o.defs[k.split('=',1)[0]]=k.split('=',1)[1] if '=' in k else '1'; i+=2; continue
        if a.startswith('-U') and a!='-U': o.undef.add(a[2:]); i+=1; continue
        if a=='-U':
            if i+1>=len(argv): return None,"argument to '-U' is missing."
            o.undef.add(argv[i+1]); i+=2; continue
        if a=='-I':
            if i+1>=len(argv): return None,"argument to '-I' is missing."
            o.includes.append(argv[i+1]); i+=2; continue
        if a.startswith('-I') and len(a)>2: o.includes.append(a[2:]); i+=1; continue
        if a=='-i':
            if i+1>=len(argv): return None,"argument to '-i' is missing."
            o.ignore.append(argv[i+1]); i+=2; continue
        if a.startswith('-i') and len(a)>2: o.ignore.append(a[2:]); i+=1; continue
        if a.startswith('--') or a in ('-j','-l','-x'):
            key=a.split('=',1)[0]
            val=a.split('=',1)[1] if '=' in a else None
            if key not in noarg and key not in ('--dump','--force','-f','--fsigned-char','--funsigned-char','--inconclusive','--report-progress','--safety','--check-library'):
                return None,f'unrecognized command line option: "{a}".'
            if key in noarg and val is None:
                if i+1>=len(argv): return None,f"argument to '{a}' is missing."
                val=argv[i+1]; i+=1
            if key=='--enable': o.enable.update(filter(None,val.split(',')))
            elif key=='--disable': o.disable.update(filter(None,val.split(',')))
            elif key=='--error-exitcode':
                try: o.errcode=int(val)
                except: return None,'--error-exitcode parameter is not a number'
            elif key=='--output-file': o.output=val
            elif key=='--output-format': o.xml = val in ('xml','xmlv2','xmlv3'); o.sarif=(val=='sarif')
            elif key=='--file-list':
                try:
                    data=sys.stdin.read().splitlines() if val=='-' else open(val).read().splitlines()
                    o.files.extend([x for x in data if x.strip()])
                except OSError: return None,f'couldn\'t open the file: "{val}".'
            elif key=='--includes-file':
                try: o.includes += [x.strip() for x in open(val) if x.strip()]
                except OSError: return None,f'couldn\'t open the file: "{val}".'
            elif key=='--include': o.includes.append(os.path.dirname(val) or '.')
            elif key=='--file-filter': o.file_filters.append(val)
            elif key=='--project':
                try:
                    data=json.load(open(val))
                    if isinstance(data,list):
                        for ent in data:
                            fn=ent.get('file') if isinstance(ent,dict) else None
                            if fn:
                                base=ent.get('directory','.') if isinstance(ent,dict) else '.'
                                o.files.append(fn if os.path.isabs(fn) else os.path.join(base,fn))
                    else:
                        return None,f'couldn\'t load project file: "{val}".'
                except OSError:
                    return None,f'couldn\'t open the file: "{val}".'
                except Exception:
                    return None,f'couldn\'t load project file: "{val}".'
            elif key=='--suppress': o.suppress.append(val)
            elif key=='--suppressions-list':
                try: o.suppress += [x.strip() for x in open(val) if x.strip() and not x.lstrip().startswith('#')]
                except OSError: return None,f'couldn\'t open the file: "{val}".'
            elif key=='--template': o.template=val
            elif key=='--checkers-report':
                try: open(val,'w').write('Critical errors\n    arrayIndexOutOfBounds\n    nullPointer\n    zerodiv\n')
                except OSError as e: return None,str(e)
            i+=1; continue
        o.files.append(a); i+=1
    return o,None

def print_errorlist():
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print('<results version="2">')
    print(f'    <cppcheck version="{VERSION.split(" ",1)[1]}"/>')
    print('    <errors>')
    for eid,sev,msg,cwe in ERRORLIST:
        c=f' cwe="{cwe}"' if cwe else ''
        print(f'        <error id="{eid}" severity="{sev}" msg="{html.escape(msg,quote=True)}" verbose="{html.escape(msg,quote=True)}"{c}/>')
    print('    </errors>')
    print('</results>')

def collect(paths):
    out=[]
    for p in paths:
        if os.path.isdir(p):
            for root,dirs,files in os.walk(p):
                dirs.sort(); files.sort()
                for f in files:
                    if Path(f).suffix in SRC_EXT: out.append(os.path.join(root,f))
        else: out.append(p)
    return out

def strip_comments(s):
    s=re.sub(r'/\*.*?\*/','',s,flags=re.S)
    return re.sub(r'//.*','',s)

def preprocess(path,o):
    defs=dict(o.defs); active=[True]
    try: lines=open(path,errors='ignore').read().splitlines()
    except OSError: return []
    res=[]
    for line in lines:
        m=re.match(r'\s*#\s*(\w+)\b\s*(.*)',line); directive=m.group(1) if m else None; rest=m.group(2).strip() if m else ''
        if directive=='define' and active[-1]:
            parts=rest.split(None,1); defs[parts[0]]=parts[1] if len(parts)>1 else '1'; continue
        if directive=='undef' and active[-1]: defs.pop(rest,None); continue
        if directive=='ifdef': active.append(active[-1] and rest in defs and rest not in o.undef); continue
        if directive=='ifndef': active.append(active[-1] and not (rest in defs and rest not in o.undef)); continue
        if directive=='else':
            if len(active)>1: active[-1]=active[-2] and not active[-1]
            continue
        if directive=='endif':
            if len(active)>1: active.pop()
            continue
        if active[-1]:
            for k,v in defs.items(): line=re.sub(r'\b'+re.escape(k)+r'\b',v,line)
            res.append(line)
    return res

def add(msgs,path,line,col,sev,eid,msg): msgs.append({'file':path,'line':line,'col':col,'severity':sev,'id':eid,'msg':msg})

def analyze(path,o):
    msgs=[]
    try: text=open(path,errors='ignore').read()
    except OSError:
        add(msgs,path,0,0,'error','file','Could not open file.'); return msgs
    code=strip_comments(text); lines=code.splitlines()
    if 'all' in o.enable or 'missingInclude' in o.enable:
        search=[os.path.dirname(path) or '.']+o.includes
        for no,raw in enumerate(text.splitlines(),1):
            m=re.match(r'\s*#\s*include\s*[<"]([^>"]+)[>"]',raw)
            if m and not any(os.path.exists(os.path.join(d,m.group(1))) for d in search):
                add(msgs,path,no,1,'information','missingInclude',f"Include file is not found: {m.group(1)}")
    arrays={}
    for no,line in enumerate(lines,1):
        for m in re.finditer(r'\b(?:char|int|short|long|float|double|bool|unsigned|signed|size_t)\s+([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]',line):
            arrays[m.group(1)]=int(m.group(2))
            if int(m.group(2))<0: add(msgs,path,no,m.start()+1,'error','negativeArraySize',f"Declaration of array '{m.group(1)}' with negative size is undefined behaviour")
    for no,line in enumerate(lines,1):
        declaration_spans=[]
        for dm in re.finditer(r'\b(?:char|int|short|long|float|double|bool|unsigned|signed|size_t)\s+[A-Za-z_]\w*\s*\[\s*-?\d+\s*\]',line):
            declaration_spans.append(dm.span())
        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*\[\s*(-?\d+)\s*\]',line):
            if any(a <= m.start() and m.end() <= b for a,b in declaration_spans):
                continue
            name,idx=m.group(1),int(m.group(2))
            if name in arrays:
                if idx<0: add(msgs,path,no,m.start()+1,'error','negativeIndex','Negative array index')
                elif idx>=arrays[name]: add(msgs,path,no,m.start()+1,'error','arrayIndexOutOfBounds',f"Array '{name}[{arrays[name]}]' accessed at index {idx}, which is out of bounds.")
        if re.search(r'/(\s*0\s*)([;,)])',line) or re.search(r'%\s*0\b',line): add(msgs,path,no,line.find('/')+1 if '/' in line else 1,'error','zerodiv','Division by zero.')
        if re.search(r'\b(?:free|delete)\s*\(\s*&',line): add(msgs,path,no,1,'error','autovarInvalidDeallocation','Deallocation of an auto-variable results in undefined behaviour.')
        if re.search(r'\bmemset\s*\([^,]+,[^,]+,\s*0\s*\)',line): add(msgs,path,no,1,'warning','memsetZeroBytes','memset() called to fill 0 bytes.')
    # null pointer simple tracking
    nulls=set(); mallocs={}
    decls={}; uses={}
    for no,line in enumerate(lines,1):
        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*=\s*(?:NULL|nullptr|0)\s*;',line): nulls.add(m.group(1))
        for m in re.finditer(r'\*\s*([A-Za-z_]\w*)\s*=',line):
            if m.group(1) in nulls: add(msgs,path,no,m.start()+1,'error','nullPointer','Null pointer dereference')
        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*=\s*(?:malloc|calloc|realloc)\s*\(',line): mallocs[m.group(1)]=no
        for m in re.finditer(r'\bfree\s*\(\s*([A-Za-z_]\w*)\s*\)',line): mallocs.pop(m.group(1),None)
        dm=re.search(r'\b(?:int|char|short|long|float|double|bool|size_t)\s+(?!return\b)([A-Za-z_]\w*)\s*(?:;|=)',line)
        if dm: decls.setdefault(dm.group(1),no)
        for tok in re.findall(r'\b[A-Za-z_]\w*\b',line): uses[tok]=uses.get(tok,0)+1
    for v,no in mallocs.items(): add(msgs,path,no,1,'error','memleak',f'Memory leak: {v}')
    if 'all' in o.enable or 'style' in o.enable:
        for v,no in decls.items():
            if uses.get(v,0)<=1 and v not in ('main',): add(msgs,path,no,1,'style','unusedVariable',f"Variable '{v}' is assigned a value that is never used.")
    if 'all' in o.enable or 'unusedFunction' in o.enable:
        funcs={}
        for no,line in enumerate(lines,1):
            fm=re.match(r'\s*(?:static\s+)?(?:int|void|char|short|long|float|double|bool|size_t|[A-Za-z_]\w+\s*\*)\s+([A-Za-z_]\w*)\s*\([^;]*\)\s*\{?',line)
            if fm and fm.group(1) not in ('if','for','while','switch','main'):
                funcs.setdefault(fm.group(1),no)
        for name,no in funcs.items():
            if len(re.findall(r'\b'+re.escape(name)+r'\s*\(',code)) <= 1:
                add(msgs,path,no,1,'style','unusedFunction',f"The function '{name}' is never used.")
    # uninitialized variable in return/assignment
    assigned=set()
    for no,line in enumerate(lines,1):
        dm=re.search(r'\b(?:int|char|short|long|float|double|bool|size_t)\s+([A-Za-z_]\w*)\s*;',line)
        if dm: assigned.discard(dm.group(1))
        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*=',line): assigned.add(m.group(1))
        rm=re.search(r'\breturn\s+([A-Za-z_]\w*)\s*;',line)
        if rm and rm.group(1) in decls and rm.group(1) not in assigned: add(msgs,path,no,1,'error','uninitvar',f"Uninitialized variable: {rm.group(1)}")
    return msgs

def suppressed(m,o):
    for s in o.suppress:
        parts=s.split(':'); eid=parts[0] if parts else ''
        fn=parts[1] if len(parts)>1 else ''; ln=parts[2] if len(parts)>2 else ''
        if eid not in ('*',m['id']): continue
        if fn and not fnmatch.fnmatch(m['file'],fn): continue
        if ln and str(m['line'])!=ln: continue
        return True
    return False

def format_msg(m,o):
    if o.template=='cppcheck1': return f"[{m['file']}:{m['line']}]: ({m['severity']}) {m['msg']}"
    if o.template=='vs': return f"{m['file']}({m['line']}): {m['severity']}: {m['msg']} [{m['id']}]"
    if o.template=='edit': return f"{m['file']} +{m['line']}: {m['msg']}"
    if o.template and o.template not in ('gcc',''):
        return o.template.replace('\\n','\n').replace('\\t','\t').replace('{file}',m['file']).replace('{line}',str(m['line'])).replace('{column}',str(m['col'])).replace('{severity}',m['severity']).replace('{message}',m['msg']).replace('{id}',m['id']).replace('{cwe}','')
    return f"{m['file']}:{m['line']}:{m['col']}: {m['severity']}: {m['msg']} [{m['id']}]"

def emit(msgs,o):
    if o.sarif:
        out=json.dumps({'version':'2.1.0','$schema':'https://json.schemastore.org/sarif-2.1.0.json','runs':[{'tool':{'driver':{'name':'Cppcheck','version':VERSION}},'results':[{'ruleId':m['id'],'level':'error' if m['severity']=='error' else 'warning','message':{'text':m['msg']},'locations':[{'physicalLocation':{'artifactLocation':{'uri':m['file']},'region':{'startLine':m['line'],'startColumn':m['col']}}}]} for m in msgs]}]},indent=2)
    elif o.xml:
        lines=['<?xml version="1.0" encoding="UTF-8"?>','<results version="2">',f'    <cppcheck version="{VERSION.split(" ",1)[1]}"/>','    <errors>']
        for m in msgs:
            lines.append(f'        <error id="{m["id"]}" severity="{m["severity"]}" msg="{html.escape(m["msg"],quote=True)}" verbose="{html.escape(m["msg"],quote=True)}">')
            lines.append(f'            <location file="{html.escape(m["file"],quote=True)}" line="{m["line"]}" column="{m["col"]}"/>')
            lines.append('        </error>')
        lines += ['    </errors>','</results>']; out='\n'.join(lines)+'\n'
    else:
        out='\n'.join(format_msg(m,o) for m in msgs)+('\n' if msgs else '')
    if o.output: open(o.output,'w').write(out)
    else: sys.stderr.write(out)

def main(argv):
    o,err=parse(argv)
    if err: return die(err)
    files=collect(o.files)
    if o.file_filters: files=[f for f in files if any(fnmatch.fnmatch(f,p) for p in o.file_filters)]
    if o.ignore: files=[f for f in files if not any(fnmatch.fnmatch(f,p) or f.startswith(p.rstrip('/')+'/') for p in o.ignore)]
    files=[f for f in files if Path(f).suffix in SRC_EXT or os.path.isfile(f)]
    if not files: return die('no C or C++ source files found.')
    if o.preprocess:
        for f in files:
            for line in preprocess(f,o): print(line)
        return 0
    allmsgs=[]
    total=len(files)
    for idx,f in enumerate(files,1):
        if not o.quiet and not (o.xml or o.sarif or o.output): sys.stdout.write(f'Checking {f} ...\n')
        allmsgs += [m for m in analyze(f,o) if not suppressed(m,o)]
        if total>1 and not o.quiet and not (o.xml or o.sarif or o.output): sys.stdout.write(f'{idx}/{total} files checked {int(idx*100/total)}% done\n')
    emit(allmsgs,o)
    if allmsgs and o.errcode: return o.errcode & 255
    return 0
if __name__=='__main__': sys.exit(main(sys.argv[1:]))
