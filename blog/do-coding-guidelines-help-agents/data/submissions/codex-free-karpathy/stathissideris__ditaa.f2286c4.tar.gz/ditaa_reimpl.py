#!/usr/bin/env python3
import html
import os
import re
import struct
import sys
import zlib


HELP = """usage: java -jar ditaa.jar <INPFILE> [OUTFILE] [-A] [-b <BACKGROUND>] [-d]
       [-E] [-e <ENCODING>] [-h] [--help] [-o] [-r] [-S] [-s <SCALE>]
       [--svg] [--svg-font-url <FONT>] [-T] [-t <TABS>] [-v] [-W]
 -A,--no-antialias              Turns anti-aliasing off.
 -b,--background <BACKGROUND>   The background colour of the image. The
                                format should be a six-digit hexadecimal
                                number (as in HTML, FF0000 for red). Pass
                                an eight-digit hex to define transparency.
                                This is overridden by --transparent.
 -d,--debug                     Renders the debug grid over the resulting
                                image.
 -E,--no-separation             Prevents the separation of common edges of
                                shapes.
 -e,--encoding <ENCODING>       The encoding of the input file.
 -h,--html                      In this case the input is an HTML file.
                                The contents of the <pre
                                class="textdiagram"> tags are rendered as
                                diagrams and saved in the images directory
                                and a new HTML file is produced with the
                                appropriate <img> tags.
    --help                      Prints usage help.
 -o,--overwrite                 If the filename of the destination image
                                already exists, an alternative name is
                                chosen. If the overwrite option is
                                selected, the image file is instead
                                overwriten.
 -r,--round-corners             Causes all corners to be rendered as round
                                corners.
 -S,--no-shadows                Turns off the drop-shadow effect.
 -s,--scale <SCALE>             A natural number that determines the size
                                of the rendered image. The units are
                                fractions of the default size (2.5 renders
                                1.5 times bigger than the default).
    --svg                       Write an SVG image as destination file.
    --svg-font-url <FONT>       SVG font URL.
 -T,--transparent               Causes the diagram to be rendered on a
                                transparent background. Overrides
                                --background.
 -t,--tabs <TABS>               Tabs are normally interpreted as 8 spaces
                                but it is possible to change that using
                                this option. It is not advisable to use
                                tabs in your diagrams.
 -v,--verbose                   Makes ditaa more verbose.
 -W,--fixed-slope               Makes sides of parallelograms and
                                trapezoids fixed slope instead of fixed
                                width."""

COLORS = {
    "RED": "#ff9999",
    "GRE": "#99ff99",
    "BLU": "#9999ff",
    "PNK": "#ff99ff",
    "YEL": "#ffff99",
    "BLK": "#666666",
}

SHAPES = {"d", "s", "o", "mo", "c", "tr", "io"}


class Options:
    def __init__(self):
        self.svg = False
        self.html = False
        self.overwrite = False
        self.transparent = False
        self.no_shadows = False
        self.round = False
        self.debug = False
        self.background = "ffffff"
        self.encoding = "utf-8"
        self.tabs = 8
        self.scale = 1.0
        self.svg_font_url = None
        self.inputs = []
        self.verbose = False


def parse_args(argv):
    opt = Options()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--help":
            print(HELP)
            raise SystemExit(0)
        if a in ("-A", "--no-antialias", "-E", "--no-separation", "-r",
                 "--round-corners", "-S", "--no-shadows", "-T",
                 "--transparent", "-v", "--verbose", "-W", "--fixed-slope",
                 "-d", "--debug", "-h", "--html", "-o", "--overwrite",
                 "--svg"):
            if a in ("-S", "--no-shadows"):
                opt.no_shadows = True
            elif a in ("-T", "--transparent"):
                opt.transparent = True
            elif a in ("-r", "--round-corners"):
                opt.round = True
            elif a in ("-d", "--debug"):
                opt.debug = True
            elif a in ("-h", "--html"):
                opt.html = True
            elif a in ("-o", "--overwrite"):
                opt.overwrite = True
            elif a == "--svg":
                opt.svg = True
            elif a in ("-v", "--verbose"):
                opt.verbose = True
            i += 1
            continue
        if a in ("-b", "--background", "-e", "--encoding", "-s", "--scale",
                 "-t", "--tabs", "--svg-font-url"):
            if i + 1 >= len(argv):
                print(f"Missing argument for option: {a}")
                print(HELP)
                raise SystemExit(0)
            v = argv[i + 1]
            if a in ("-b", "--background"):
                opt.background = v.strip().lstrip("#")
            elif a in ("-e", "--encoding"):
                opt.encoding = v
            elif a in ("-s", "--scale"):
                try:
                    opt.scale = float(v)
                except ValueError:
                    opt.scale = 1.0
            elif a in ("-t", "--tabs"):
                try:
                    opt.tabs = max(1, int(v))
                except ValueError:
                    opt.tabs = 8
            else:
                opt.svg_font_url = v
            i += 2
            continue
        if a.startswith("-"):
            print(f"Unrecognized option: {a}")
            print(HELP)
            raise SystemExit(0)
        opt.inputs.append(a)
        i += 1
    if not opt.inputs:
        print(HELP)
        raise SystemExit(0)
    return opt


def banner(opt):
    print()
    print("ditaa version 0.11, Copyright (C) 2004--2017  Efstathios (Stathis) Sideris")
    print()
    print("Running with options:")
    if opt.svg:
        print("svg")


def expand_tabs(s, tabstop):
    out = []
    col = 0
    for ch in s:
        if ch == "\t":
            n = tabstop - (col % tabstop)
            out.append(" " * n)
            col += n
        else:
            out.append(ch)
            col += 1
    return "".join(out)


def read_lines(path, opt, text=None):
    if text is None:
        with open(path, "r", encoding=opt.encoding, errors="replace") as f:
            text = f.read()
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = [expand_tabs(x.rstrip("\n"), opt.tabs) for x in text.split("\n")]
    while lines and lines[-1] == "":
        lines.pop()
    return lines or [""]


def dims(lines, opt):
    cols = max((len(x) for x in lines), default=0)
    rows = len(lines)
    cw = int(round(10 * opt.scale))
    ch = int(round(14 * opt.scale))
    ox = int(round(25 * opt.scale))
    oy = int(round(35 * opt.scale))
    width = max(1, ox * 2 + max(0, cols - 1) * cw)
    height = max(1, oy * 2 + max(0, rows - 1) * ch)
    return cols, rows, cw, ch, ox, oy, width, height


def cell(lines, r, c):
    if 0 <= r < len(lines) and 0 <= c < len(lines[r]):
        return lines[r][c]
    return " "


def find_boxes(lines):
    boxes = []
    used = set()
    rows = len(lines)
    for r1 in range(rows):
        for c1, ch in enumerate(lines[r1]):
            if ch not in "+/\\*" or (r1, c1) in used:
                continue
            for c2 in range(c1 + 2, len(lines[r1])):
                if lines[r1][c2] not in "+/\\*":
                    continue
                top = lines[r1][c1 + 1:c2]
                if not top or not all(x in "-= " for x in top) or "-" not in top and "=" not in top:
                    continue
                for r2 in range(r1 + 2, rows):
                    if c2 >= len(lines[r2]) or lines[r2][c1] not in "+/\\*" or lines[r2][c2] not in "+/\\*":
                        continue
                    bottom = lines[r2][c1 + 1:c2]
                    if not bottom or not all(x in "-= " for x in bottom) or "-" not in bottom and "=" not in bottom:
                        continue
                    left_ok = all(cell(lines, rr, c1) in "|: " for rr in range(r1 + 1, r2))
                    right_ok = all(cell(lines, rr, c2) in "|: " for rr in range(r1 + 1, r2))
                    if left_ok and right_ok:
                        boxes.append((r1, c1, r2, c2))
                        for rr in range(r1, r2 + 1):
                            used.add((rr, c1)); used.add((rr, c2))
                        for cc in range(c1, c2 + 1):
                            used.add((r1, cc)); used.add((r2, cc))
                        break
                else:
                    continue
                break
    # Drop boxes contained by larger boxes with same border origin ambiguity.
    out = []
    for b in boxes:
        if not any(o != b and o[0] <= b[0] and o[1] <= b[1] and o[2] >= b[2] and o[3] >= b[3] for o in boxes):
            out.append(b)
    return out


def content_for_box(lines, box):
    r1, c1, r2, c2 = box
    raw = []
    color = None
    shape = None
    for r in range(r1 + 1, r2):
        s = lines[r][c1 + 1:c2] if c1 + 1 < len(lines[r]) else ""
        m = re.search(r"\{([a-z]+)\}", lines[r][c1 + 1:c2] if c1 + 1 < len(lines[r]) else "")
        if m and m.group(1) in SHAPES:
            shape = m.group(1)
        m = re.search(r"c(RED|GRE|BLU|PNK|YEL|BLK)", s)
        if m:
            color = COLORS[m.group(1)]
            s = s.replace("c" + m.group(1), "")
        s = re.sub(r"\{(?:d|s|o|mo|c|tr|io)\}", "", s)
        raw.append(s.rstrip())
    text = []
    for s in raw:
        stripped = s.strip()
        if stripped:
            text.append(stripped)
    return color or "white", shape, text


def svg_path_for_shape(shape, x1, y1, x2, y2, rounded=False):
    w = x2 - x1
    h = y2 - y1
    if shape == "o":
        return None
    if shape == "c":
        return f"M{(x1+x2)/2:.1f} {y1:.1f} L{x2:.1f} {(y1+y2)/2:.1f} L{(x1+x2)/2:.1f} {y2:.1f} L{x1:.1f} {(y1+y2)/2:.1f} z"
    if shape == "io":
        s = min(w * 0.18, 22)
        return f"M{x1+s:.1f} {y1:.1f} L{x2:.1f} {y1:.1f} L{x2-s:.1f} {y2:.1f} L{x1:.1f} {y2:.1f} z"
    if shape == "tr":
        s = min(w * 0.18, 22)
        return f"M{x1+s:.1f} {y1:.1f} L{x2-s:.1f} {y1:.1f} L{x2:.1f} {y2:.1f} L{x1:.1f} {y2:.1f} z"
    if shape == "mo":
        s = min(h * 0.45, 18)
        return f"M{x1:.1f} {y1+s:.1f} L{x2:.1f} {y1:.1f} L{x2:.1f} {y2:.1f} L{x1:.1f} {y2:.1f} z"
    return f"M{x1:.1f} {y1:.1f} L{x1:.1f} {y2:.1f} L{x2:.1f} {y2:.1f} L{x2:.1f} {y1:.1f} z"


def collect_text(lines, boxes):
    covered = set()
    for r1, c1, r2, c2 in boxes:
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                covered.add((r, c))
    texts = []
    for r, line in enumerate(lines):
        start = None
        buf = []
        for c, ch in enumerate(line + " "):
            markup = False
            if c < len(line):
                tail = line[c:]
                markup = bool(re.match(r"\{(?:d|s|o|mo|c|tr|io)\}|c(?:RED|GRE|BLU|PNK|YEL|BLK)", tail))
            printable = c < len(line) and ch not in "+-|/\\:=*" and (r, c) not in covered and not markup
            if printable:
                if start is None:
                    start = c
                buf.append(ch)
            else:
                if start is not None and "".join(buf).strip():
                    texts.append((r, start, "".join(buf).strip()))
                start = None
                buf = []
    return texts


def render_svg(lines, opt):
    cols, rows, cw, ch_h, ox, oy, width, height = dims(lines, opt)
    boxes = find_boxes(lines)
    bg = "none" if opt.transparent else "#" + (opt.background[:6] if len(opt.background) >= 6 else "ffffff")
    parts = ["<?xml version='1.0' encoding='UTF-8' standalone='no'?>",
             "<svg ",
             "    xmlns='http://www.w3.org/2000/svg'",
             f"    width='{width}'",
             f"    height='{height}'",
             "    shape-rendering='geometricPrecision'",
             "    version='1.0'>",
             "  <defs>",
             "    <filter id='f2' x='0' y='0' width='200%' height='200%'>",
             "      <feOffset result='offOut' in='SourceGraphic' dx='5' dy='5' />",
             "      <feGaussianBlur result='blurOut' in='offOut' stdDeviation='3' />",
             "      <feBlend in='SourceGraphic' in2='blurOut' mode='normal' />",
             "    </filter>",
             "  </defs>",
             "  <g stroke-width='1' stroke-linecap='square' stroke-linejoin='round'>"]
    if bg != "none":
        parts.append(f"    <rect x='0' y='0' width='{width}' height='{height}' style='fill: {bg}'/>")
    for box in boxes:
        r1, c1, r2, c2 = box
        x1, y1 = ox + c1 * cw, oy + r1 * ch_h
        x2, y2 = ox + c2 * cw, oy + r2 * ch_h
        fill, shape, text = content_for_box(lines, box)
        if shape == "o":
            cx, cy = (x1 + x2) / 2, (y1 + y2) / 2
            rx, ry = max(1, (x2 - x1) / 2), max(1, (y2 - y1) / 2)
            if not opt.no_shadows:
                parts.append(f"    <ellipse cx='{cx:.1f}' cy='{cy:.1f}' rx='{rx:.1f}' ry='{ry:.1f}' stroke='gray' fill='gray' filter='url(#f2)' />")
            parts.append(f"    <ellipse cx='{cx:.1f}' cy='{cy:.1f}' rx='{rx:.1f}' ry='{ry:.1f}' stroke='#000000' stroke-width='1.0' fill='{fill}' />")
        else:
            d = svg_path_for_shape(shape, x1, y1, x2, y2, opt.round)
            if not opt.no_shadows:
                parts.append(f"    <path stroke='gray' fill='gray' filter='url(#f2)' d='{d}' />")
            parts.append(f"    <path stroke='#000000' stroke-width='1.0' stroke-linecap='round' stroke-linejoin='round' fill='{fill}' d='{d}' />")
            if shape == "s":
                parts.append(f"    <path stroke='#000000' fill='none' d='M{x1:.1f} {y1+8:.1f} C{x1+10:.1f} {y1+18:.1f} {x2-10:.1f} {y1+18:.1f} {x2:.1f} {y1+8:.1f}' />")
            if shape == "d":
                parts.append(f"    <path stroke='#000000' fill='none' d='M{x1:.1f} {y2-7:.1f} C{x1+12:.1f} {y2+3:.1f} {x2-12:.1f} {y2-17:.1f} {x2:.1f} {y2-7:.1f}' />")
        for i, t in enumerate(text):
            t = re.sub(r"^o\s+", "• ", t)
            parts.append(f"    <text x='{int(x1 + 7)}' y='{int(y1 + 19 + i * 15)}' font-family='Courier' font-size='{max(1, int(15 * opt.scale))}' stroke='none' fill='#000000' ><![CDATA[{t}]]></text>")
    draw_loose_svg(parts, lines, boxes, opt, cw, ch_h, ox, oy)
    if opt.debug:
        for c in range(cols + 1):
            x = ox + c * cw
            parts.append(f"    <path stroke='#dddddd' fill='none' d='M{x} 0 L{x} {height}' />")
        for r in range(rows + 1):
            y = oy + r * ch
            parts.append(f"    <path stroke='#dddddd' fill='none' d='M0 {y} L{width} {y}' />")
    parts.append("  </g>")
    parts.append("</svg>")
    return "\n".join(parts)


def draw_loose_svg(parts, lines, boxes, opt, cw, ch, ox, oy):
    in_box = set()
    for r1, c1, r2, c2 in boxes:
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                in_box.add((r, c))
    for r, line in enumerate(lines):
        c = 0
        while c < len(line):
            char = line[c]
            if (r, c) in in_box:
                c += 1; continue
            x = ox + c * cw
            y = oy + r * ch
            if char in "-=":
                c2 = c
                while c2 < len(line) and line[c2] in "-=" and (r, c2) not in in_box:
                    c2 += 1
                dash = " stroke-dasharray='5,5'" if "=" in line[c:c2] else ""
                parts.append(f"    <path stroke='#000000' fill='none'{dash} d='M{x:.1f} {y:.1f} L{ox + c2 * cw:.1f} {y:.1f}' />")
                c = c2; continue
            if char in "|:":
                r2 = r
                while r2 < len(lines) and cell(lines, r2, c) in "|:" and (r2, c) not in in_box:
                    r2 += 1
                dash = " stroke-dasharray='5,5'" if any(cell(lines, rr, c) == ":" for rr in range(r, r2)) else ""
                parts.append(f"    <path stroke='#000000' fill='none'{dash} d='M{x:.1f} {y:.1f} L{x:.1f} {oy + r2 * ch:.1f}' />")
                c += 1; continue
            if char == ">":
                parts.append(f"    <path stroke='#000000' fill='none' d='M{x:.1f} {y-5:.1f} L{x+8:.1f} {y:.1f} L{x:.1f} {y+5:.1f}' />")
            elif char == "<":
                parts.append(f"    <path stroke='#000000' fill='none' d='M{x+8:.1f} {y-5:.1f} L{x:.1f} {y:.1f} L{x+8:.1f} {y+5:.1f}' />")
            elif char == "^":
                parts.append(f"    <path stroke='#000000' fill='none' d='M{x-5:.1f} {y+8:.1f} L{x:.1f} {y:.1f} L{x+5:.1f} {y+8:.1f}' />")
            elif char == "v":
                parts.append(f"    <path stroke='#000000' fill='none' d='M{x-5:.1f} {y:.1f} L{x:.1f} {y+8:.1f} L{x+5:.1f} {y:.1f}' />")
            elif char == "*":
                parts.append(f"    <circle cx='{x:.1f}' cy='{y:.1f}' r='{max(2, int(3*opt.scale))}' fill='#000000' />")
            c += 1
    for r, c, t in collect_text(lines, boxes):
        x = ox + c * cw
        y = oy + r * ch + int(5 * opt.scale)
        t = re.sub(r"^o\s+", "• ", t)
        parts.append(f"    <text x='{int(x)}' y='{int(y)}' font-family='Courier' font-size='{max(1, int(15 * opt.scale))}' stroke='none' fill='#000000' ><![CDATA[{t}]]></text>")


def png_chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


def write_png(path, lines, opt):
    cols, rows, cw, ch_h, ox, oy, width, height = dims(lines, opt)
    bg_hex = opt.background[:8] if opt.background else "ffffff"
    if opt.transparent:
        bg = (255, 255, 255, 0)
    else:
        bg = hex_to_rgba(bg_hex)
    pix = bytearray(bg * width * height)

    def put(x, y, color=(0, 0, 0, 255)):
        if 0 <= x < width and 0 <= y < height:
            i = (y * width + x) * 4
            pix[i:i+4] = bytes(color)

    def line(x1, y1, x2, y2, color=(0, 0, 0, 255)):
        x1 = int(round(x1)); y1 = int(round(y1)); x2 = int(round(x2)); y2 = int(round(y2))
        dx = abs(x2 - x1); dy = -abs(y2 - y1)
        sx = 1 if x1 < x2 else -1
        sy = 1 if y1 < y2 else -1
        err = dx + dy
        while True:
            for xx in range(x1 - 1, x1 + 2):
                for yy in range(y1 - 1, y1 + 2):
                    put(xx, yy, color)
            if x1 == x2 and y1 == y2:
                break
            e2 = 2 * err
            if e2 >= dy:
                err += dy; x1 += sx
            if e2 <= dx:
                err += dx; y1 += sy

    for r1, c1, r2, c2 in find_boxes(lines):
        x1, y1 = ox + c1 * cw, oy + r1 * ch_h
        x2, y2 = ox + c2 * cw, oy + r2 * ch_h
        fill, shape, _ = content_for_box(lines, (r1, c1, r2, c2))
        fc = hex_to_rgba(fill)
        for y in range(int(y1) + 1, int(y2)):
            for x in range(int(x1) + 1, int(x2)):
                put(x, y, fc)
        line(x1, y1, x2, y1); line(x2, y1, x2, y2); line(x2, y2, x1, y2); line(x1, y2, x1, y1)
    for r, line_s in enumerate(lines):
        for c, char in enumerate(line_s):
            x = ox + c * cw
            y = oy + r * ch_h
            if char in "-=":
                line(x, y, x + cw, y)
            elif char in "|:":
                line(x, y, x, y + ch_h)
            elif char == "/":
                line(x, y + ch_h, x + cw, y)
            elif char == "\\":
                line(x, y, x + cw, y + ch_h)
            elif char == "*":
                for yy in range(int(y - 3), int(y + 4)):
                    for xx in range(int(x - 3), int(x + 4)):
                        if (xx - x) ** 2 + (yy - y) ** 2 <= 10:
                            put(xx, yy)
    raw = bytearray()
    stride = width * 4
    for y in range(height):
        raw.append(0)
        raw.extend(pix[y * stride:(y + 1) * stride])
    data = b"\x89PNG\r\n\x1a\n"
    data += png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0))
    data += png_chunk(b"IDAT", zlib.compress(bytes(raw), 9))
    data += png_chunk(b"IEND", b"")
    with open(path, "wb") as f:
        f.write(data)


def hex_to_rgba(s):
    s = s.strip().lstrip("#")
    if s.lower() in ("white", ""):
        return (255, 255, 255, 255)
    if len(s) == 6:
        return tuple(int(s[i:i+2], 16) for i in (0, 2, 4)) + (255,)
    if len(s) >= 8:
        return tuple(int(s[i:i+2], 16) for i in (0, 2, 4, 6))
    return (255, 255, 255, 255)


def default_out(inp, opt):
    root, _ = os.path.splitext(inp)
    return root + (".svg" if opt.svg else ".png")


def render_file(inp, out, opt, text=None):
    print(f"Reading file: {inp}")
    if text is None and not os.path.exists(inp):
        print(f"Error: File {inp} does not exist")
        return
    lines = read_lines(inp, opt, text)
    print(f"Rendering to file: {out}")
    if opt.svg:
        with open(out, "w", encoding="utf-8") as f:
            f.write(render_svg(lines, opt))
    else:
        write_png(out, lines, opt)
    print("Done in 0sec")


def render_html(inp, out, opt):
    print(f"Reading file: {inp}")
    if not os.path.exists(inp):
        print(f"Error: File {inp} does not exist")
        return
    with open(inp, "r", encoding=opt.encoding, errors="replace") as f:
        src = f.read()
    base = os.path.dirname(os.path.abspath(out or inp)) or "."
    imgdir = os.path.join(base, "images")
    os.makedirs(imgdir, exist_ok=True)
    count = 0

    def repl(m):
        nonlocal count
        attrs = m.group(1)
        body = html.unescape(m.group(2))
        count += 1
        mid = re.search(r"""id\s*=\s*["']([^"']+)["']""", attrs)
        name = (mid.group(1) if mid else f"ditaa_diagram_{count}") + (".svg" if opt.svg else ".png")
        imgpath = os.path.join(imgdir, name)
        if opt.overwrite or not os.path.exists(imgpath):
            lines = read_lines(inp, opt, body)
            if opt.svg:
                with open(imgpath, "w", encoding="utf-8") as f:
                    f.write(render_svg(lines, opt))
            else:
                write_png(imgpath, lines, opt)
        return f'<img src="images/{html.escape(name)}" />'

    new = re.sub(r"<pre([^>]*class=[\"'][^\"']*textdiagram[^\"']*[\"'][^>]*)>(.*?)</pre>", repl, src, flags=re.I | re.S)
    if out is None:
        root, ext = os.path.splitext(inp)
        out = root + "_processed" + (ext or ".html")
    print(f"Rendering to file: {out}")
    with open(out, "w", encoding="utf-8") as f:
        f.write(new)
    print("Done in 0sec")


def main(argv):
    opt = parse_args(argv)
    banner(opt)
    inp = opt.inputs[0]
    out = opt.inputs[1] if len(opt.inputs) > 1 else default_out(inp, opt)
    if opt.html:
        render_html(inp, out if len(opt.inputs) > 1 else None, opt)
    else:
        render_file(inp, out, opt)


if __name__ == "__main__":
    main(sys.argv[1:])
