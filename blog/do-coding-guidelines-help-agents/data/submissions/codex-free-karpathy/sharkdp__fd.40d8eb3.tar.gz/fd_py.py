#!/usr/bin/env python3
import datetime as _dt
import fnmatch
import grp
import os
import pwd
import re
import shlex
import stat
import subprocess
import sys
from dataclasses import dataclass, field


VERSION = "fd 10.3.0"
HELP_SHORT = """A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
  [path]...  the root directories for the filesystem search (optional)

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search (default: smart case)
  -i, --ignore-case                Case-insensitive search (default: smart case)
  -g, --glob                       Glob-based search (default: regular expression)
  -a, --absolute-path              Show absolute instead of relative paths
  -l, --list-details               Use a long listing format with file metadata
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Search full abs. path (default: filename only)
  -d, --max-depth <depth>          Set maximum search depth (default: none)
  -E, --exclude <pattern>          Exclude entries that match the given glob pattern
  -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l),
                                   executable (x), empty (e), socket (s), pipe (p), char-device
                                   (c), block-device (b)
  -e, --extension <ext>            Filter by file extension
  -S, --size <size>                Limit results based on the size of files
      --changed-within <date|dur>  Filter by file modification time (newer than)
      --changed-before <date|dur>  Filter by file modification time (older than)
  -o, --owner <user:group>         Filter by owning user and/or group
      --format <fmt>               Print results according to template
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute a command with all search results at once
  -c, --color <when>               When to use colors [default: auto] [possible values: auto,
                                   always, never]
      --hyperlink[=<when>]         Add hyperlinks to output paths [default: never] [possible
                                   values: auto, always, never]
      --ignore-contain <name>      Ignore directories containing the named entry
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version
"""


@dataclass
class Options:
    hidden: bool = False
    no_ignore: bool = False
    case_sensitive: bool | None = None
    glob: bool = False
    fixed: bool = False
    absolute: bool = False
    list_details: bool = False
    follow: bool = False
    full_path: bool = False
    print0: bool = False
    max_depth: int | None = None
    min_depth: int = 1
    excludes: list[str] = field(default_factory=list)
    types: set[str] = field(default_factory=set)
    extensions: list[str] = field(default_factory=list)
    sizes: list[tuple[str, int]] = field(default_factory=list)
    newer: float | None = None
    older: float | None = None
    owner: str | None = None
    fmt: str | None = None
    exec_each: list[str] | None = None
    exec_batch: list[str] | None = None
    batch_size: int = 0
    color: str = "auto"
    max_results: int | None = None
    quiet: bool = False
    show_errors: bool = False
    base_directory: str | None = None
    path_separator: str = os.sep
    search_paths: list[str] = field(default_factory=list)
    strip_cwd_prefix: str = "auto"
    prune: bool = False
    and_patterns: list[str] = field(default_factory=list)
    ignore_contain: list[str] = field(default_factory=list)


def die(msg: str, code: int = 2):
    print(msg, file=sys.stderr)
    sys.exit(code)


def need(args, i, opt):
    if i + 1 >= len(args):
        die(f"error: a value is required for '{opt}' but none was supplied")
    return args[i + 1], i + 1


def parse(argv):
    opts = Options()
    pos = []
    i = 0
    stop = False
    while i < len(argv):
        a = argv[i]
        if stop:
            pos.append(a); i += 1; continue
        if a == "--":
            stop = True; i += 1; continue
        if a in ("-h", "--help"):
            print(HELP_SHORT, end=""); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a in ("-x", "--exec"):
            opts.exec_each = argv[i + 1:]
            break
        if a in ("-X", "--exec-batch"):
            opts.exec_batch = argv[i + 1:]
            break
        if a.startswith("--"):
            name, eq, val = a.partition("=")
            def val_or_next():
                nonlocal i, val
                if eq:
                    return val
                v, i2 = need(argv, i, name)
                i = i2
                return v
            if name == "--hidden": opts.hidden = True
            elif name == "--no-hidden": opts.hidden = False
            elif name == "--no-ignore": opts.no_ignore = True
            elif name in ("--ignore",): opts.no_ignore = False
            elif name in ("--unrestricted",): opts.hidden = True; opts.no_ignore = True
            elif name == "--case-sensitive": opts.case_sensitive = True
            elif name == "--ignore-case": opts.case_sensitive = False
            elif name == "--glob": opts.glob = True
            elif name == "--regex": opts.glob = False
            elif name == "--fixed-strings": opts.fixed = True
            elif name == "--absolute-path": opts.absolute = True
            elif name == "--relative-path": opts.absolute = False
            elif name == "--list-details": opts.list_details = True
            elif name == "--follow": opts.follow = True
            elif name == "--no-follow": opts.follow = False
            elif name == "--full-path": opts.full_path = True
            elif name == "--print0": opts.print0 = True
            elif name == "--max-depth": opts.max_depth = int(val_or_next())
            elif name == "--min-depth": opts.min_depth = int(val_or_next())
            elif name == "--exact-depth":
                d = int(val_or_next()); opts.min_depth = d; opts.max_depth = d
            elif name == "--exclude": opts.excludes.append(val_or_next())
            elif name == "--type": add_type(opts, val_or_next())
            elif name == "--extension": opts.extensions.append(val_or_next().lstrip(".").lower())
            elif name == "--size": opts.sizes.append(parse_size(val_or_next()))
            elif name in ("--changed-within", "--change-newer-than", "--newer", "--changed-after"):
                opts.newer = parse_time(val_or_next(), within=True)
            elif name in ("--changed-before", "--change-older-than", "--older"):
                opts.older = parse_time(val_or_next(), within=False)
            elif name == "--owner": opts.owner = val_or_next()
            elif name == "--format": opts.fmt = val_or_next()
            elif name == "--batch-size": opts.batch_size = int(val_or_next())
            elif name == "--color": opts.color = val_or_next()
            elif name == "--hyperlink":
                if not eq and i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                    i += 1
            elif name == "--max-results": opts.max_results = int(val_or_next())
            elif name in ("--quiet", "--has-results"): opts.quiet = True
            elif name == "--show-errors": opts.show_errors = True
            elif name == "--base-directory": opts.base_directory = val_or_next()
            elif name == "--path-separator": opts.path_separator = val_or_next()
            elif name == "--search-path": opts.search_paths.append(val_or_next())
            elif name == "--strip-cwd-prefix":
                opts.strip_cwd_prefix = val if eq else ("always" if i + 1 >= len(argv) or argv[i + 1].startswith("-") else argv[i + 1])
                if not eq and i + 1 < len(argv) and not argv[i + 1].startswith("-"): i += 1
            elif name in ("--prune",): opts.prune = True
            elif name == "--and": opts.and_patterns.append(val_or_next())
            elif name == "--ignore-file": pass_ignore_file(opts, val_or_next())
            elif name == "--ignore-contain": opts.ignore_contain.append(val_or_next())
            elif name in ("--no-ignore-vcs", "--no-require-git", "--no-ignore-parent", "--require-git", "--ignore-vcs", "--one-file-system", "--mount", "--xdev"):
                pass
            else:
                die(f"error: unexpected argument '{a}' found\n\nFor more information, try '--help'.")
            i += 1
            continue
        if a.startswith("-") and a != "-":
            i = parse_short(argv, i, opts, pos)
            if opts.exec_each is not None or opts.exec_batch is not None:
                break
            continue
        pos.append(a)
        i += 1

    if opts.base_directory:
        os.chdir(opts.base_directory)
    pattern = None
    paths = []
    if opts.search_paths:
        paths = opts.search_paths[:]
        if pos:
            pattern = pos[0]
            paths.extend(pos[1:])
    elif pos:
        pattern = pos[0]
        paths = pos[1:] or ["."]
    else:
        paths = ["."]
    return opts, pattern, paths


def parse_short(argv, i, opts, pos):
    a = argv[i]
    chars = a[1:]
    j = 0
    while j < len(chars):
        c = chars[j]
        rest = chars[j + 1:]
        def arg():
            nonlocal i, j
            if rest:
                j = len(chars)
                return rest
            v, i2 = need(argv, i, "-" + c)
            i = i2; j = len(chars)
            return v
        if c == "H": opts.hidden = True
        elif c == "I": opts.no_ignore = True
        elif c == "u": opts.hidden = True; opts.no_ignore = True
        elif c == "s": opts.case_sensitive = True
        elif c == "i": opts.case_sensitive = False
        elif c == "g": opts.glob = True
        elif c == "F": opts.fixed = True
        elif c == "a": opts.absolute = True
        elif c == "l": opts.list_details = True
        elif c == "L": opts.follow = True
        elif c == "p": opts.full_path = True
        elif c == "0": opts.print0 = True
        elif c == "d": opts.max_depth = int(arg())
        elif c == "E": opts.excludes.append(arg())
        elif c == "t": add_type(opts, arg())
        elif c == "e": opts.extensions.append(arg().lstrip(".").lower())
        elif c == "S": opts.sizes.append(parse_size(arg()))
        elif c == "o": opts.owner = arg()
        elif c == "c": opts.color = arg()
        elif c == "j": _ = arg()
        elif c == "1": opts.max_results = 1
        elif c == "q": opts.quiet = True
        elif c == "C": opts.base_directory = arg()
        elif c == "x":
            opts.exec_each = ([rest] if rest else argv[i + 1:])
            return len(argv)
        elif c == "X":
            opts.exec_batch = ([rest] if rest else argv[i + 1:])
            return len(argv)
        else:
            die(f"error: unexpected argument '-{c}' found\n\nFor more information, try '--help'.")
        j += 1
    return i + 1


def add_type(opts, t):
    m = {"file":"f","f":"f","dir":"d","directory":"d","d":"d","symlink":"l","l":"l",
         "executable":"x","x":"x","empty":"e","e":"e","socket":"s","s":"s","pipe":"p","p":"p",
         "block-device":"b","b":"b","char-device":"c","c":"c"}
    if t not in m:
        die(f"error: invalid value '{t}' for '--type <filetype>'")
    opts.types.add(m[t])
    if m[t] == "x":
        opts.types.add("f")


def pass_ignore_file(opts, path):
    try:
        for line in open(path, encoding="utf-8"):
            line = line.strip()
            if line and not line.startswith("#"):
                opts.excludes.append(line)
    except OSError:
        pass


def parse_size(s):
    op = "="
    if s[:1] in "+-":
        op, s = s[0], s[1:]
    m = re.fullmatch(r"(\d+)([a-zA-Z]*)", s)
    if not m: die(f"error: invalid size: {s}")
    n = int(m.group(1)); u = m.group(2).lower() or "b"
    mult = {"b":1,"k":1000,"m":1000**2,"g":1000**3,"t":1000**4,
            "ki":1024,"mi":1024**2,"gi":1024**3,"ti":1024**4}.get(u)
    if mult is None: die(f"error: invalid size unit: {u}")
    return op, n * mult


def parse_time(s, within):
    now = _dt.datetime.now().timestamp()
    if s.startswith("@"):
        return float(s[1:])
    m = re.fullmatch(r"(\d+)\s*(sec|second|seconds|s|min|minute|minutes|h|hour|hours|d|day|days|week|weeks|w)?", s)
    if m:
        n = int(m.group(1)); unit = (m.group(2) or "s").lower()
        mul = 1
        if unit.startswith("min"): mul = 60
        elif unit in ("h","hour","hours"): mul = 3600
        elif unit in ("d","day","days"): mul = 86400
        elif unit in ("w","week","weeks"): mul = 604800
        return now - n * mul
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
        try:
            return _dt.datetime.strptime(s, fmt).timestamp()
        except ValueError:
            pass
    die(f"error: invalid date or duration: {s}")


def compile_matchers(opts, pattern):
    pats = ([] if pattern in (None, "") else [pattern]) + opts.and_patterns
    cs = opts.case_sensitive
    if cs is None:
        cs = any(any(ch.isupper() for ch in p) for p in pats)
    out = []
    for p in pats:
        if opts.fixed:
            pp = p if cs else p.lower()
            out.append(lambda s, pp=pp: pp in (s if cs else s.lower()))
        elif opts.glob:
            pp = p if cs else p.lower()
            out.append(lambda s, pp=pp: fnmatch.fnmatchcase(s if cs else s.lower(), pp))
        else:
            flags = 0 if cs else re.IGNORECASE
            try:
                r = re.compile(p, flags)
            except re.error as e:
                print(f"[fd error]: regex parse error:\n    {p}\n    ^\nerror: {e}", file=sys.stderr)
                print("\nNote: You can use the '--fixed-strings' option to search for a literal string instead of a regular expression. Alternatively, you can also use the '--glob' option to match on a glob pattern.", file=sys.stderr)
                sys.exit(1)
            out.append(lambda s, r=r: bool(r.search(s)))
    if not out:
        out.append(lambda s: True)
    return out


def is_git_search(root):
    d = os.path.abspath(root)
    while True:
        if os.path.isdir(os.path.join(d, ".git")):
            return True
        nd = os.path.dirname(d)
        if nd == d:
            return False
        d = nd


def load_ignore_file(path):
    pats = []
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or line.startswith("!"):
                    continue
                pats.append(line.rstrip("/"))
    except OSError:
        pass
    return pats


def ignored(rel, name, patterns):
    rel = rel.rstrip("/")
    for p in patterns:
        q = p.lstrip("/")
        if fnmatch.fnmatchcase(name, q) or fnmatch.fnmatchcase(rel, q) or fnmatch.fnmatchcase(rel, q.rstrip("/") + "/*"):
            return True
    return False


def output_path(path, root, root_arg, opts, is_dir):
    if opts.absolute or os.path.isabs(root_arg):
        s = os.path.abspath(path)
    else:
        s = os.path.relpath(path, os.getcwd())
    if s == ".":
        s = os.path.basename(os.path.abspath(path)) or "."
    if is_dir and not s.endswith(os.sep):
        s += os.sep
    if opts.path_separator != os.sep:
        s = s.replace(os.sep, opts.path_separator)
    return s


def exec_path(out, opts):
    if os.path.isabs(out):
        return out.rstrip(os.sep)
    s = out.rstrip(os.sep)
    if opts.strip_cwd_prefix == "always":
        return s
    if opts.print0 or opts.exec_each is not None or opts.exec_batch is not None or opts.strip_cwd_prefix in ("auto", "never"):
        return "./" + s if not s.startswith("./") else s
    return s


def file_type(path, st):
    mode = st.st_mode
    if stat.S_ISLNK(mode): return "l"
    if stat.S_ISDIR(mode): return "d"
    if stat.S_ISREG(mode): return "f"
    if stat.S_ISSOCK(mode): return "s"
    if stat.S_ISFIFO(mode): return "p"
    if stat.S_ISBLK(mode): return "b"
    if stat.S_ISCHR(mode): return "c"
    return "?"


def is_empty(path, typ):
    try:
        if typ == "d":
            return not any(os.scandir(path))
        if typ == "f":
            return os.path.getsize(path) == 0
    except OSError:
        return False
    return False


def type_ok(opts, path, st, typ):
    types = set(opts.types)
    wants_empty = "e" in types
    types.discard("e")
    if wants_empty and not types:
        type_match = typ in ("f", "d")
    elif types:
        type_match = typ in types
    else:
        type_match = True
    if "x" in opts.types:
        type_match = type_match and typ == "f" and os.access(path, os.X_OK)
    if wants_empty:
        type_match = type_match and is_empty(path, typ)
    return type_match


def owner_ok(spec, st):
    if not spec:
        return True
    user, sep, group = spec.partition(":")
    def one(val, actual, lookup):
        neg = val.startswith("!")
        if neg: val = val[1:]
        if val == "": return True
        try:
            want = int(val)
        except ValueError:
            try: want = lookup(val)
            except KeyError: return False if not neg else True
        ok = actual == want
        return not ok if neg else ok
    return one(user, st.st_uid, lambda x: pwd.getpwnam(x).pw_uid) and one(group, st.st_gid, lambda x: grp.getgrnam(x).gr_gid)


def filters_ok(opts, path, out, st, typ):
    if opts.extensions:
        name = os.path.basename(path)
        ext = name.rsplit(".", 1)[1].lower() if "." in name and not name.startswith(".") else ""
        if ext not in opts.extensions:
            return False
    if opts.sizes and typ != "f":
        return False
    for op, n in opts.sizes:
        sz = st.st_size
        if op == "+" and not (sz >= n): return False
        if op == "-" and not (sz <= n): return False
        if op == "=" and not (sz == n): return False
    if opts.newer is not None and not (st.st_mtime > opts.newer): return False
    if opts.older is not None and not (st.st_mtime < opts.older): return False
    if not owner_ok(opts.owner, st): return False
    return type_ok(opts, path, st, typ)


def colorize(s, enabled):
    if not enabled:
        return s
    return "\033[0m\033[38;5;34m" + s + "\033[0m"


def substitute(args, paths):
    if not args:
        args = ["{}"]
    if not any(("{" in a and "}" in a) for a in args):
        args = args + ["{}"]
    out = []
    for a in args:
        if a == "{}":
            out.extend(paths); continue
        val = a
        if len(paths) == 1:
            p = paths[0]
            base = os.path.basename(p.rstrip(os.sep))
            parent = os.path.dirname(p.rstrip(os.sep)) or "."
            noext = os.path.splitext(p.rstrip(os.sep))[0]
            if noext.startswith("./"):
                noext = noext[2:]
            bnoext = os.path.splitext(base)[0]
            val = val.replace("{{", "\0L").replace("}}", "\0R")
            val = val.replace("{//}", parent).replace("{/.}", bnoext).replace("{/}", base).replace("{.}", noext).replace("{}", p)
            val = val.replace("\0L", "{").replace("\0R", "}")
        out.append(val)
    return out


def format_result(fmt, p):
    base = os.path.basename(p.rstrip(os.sep))
    parent = os.path.dirname(p.rstrip(os.sep)) or "."
    noext = os.path.splitext(p.rstrip(os.sep))[0]
    bnoext = os.path.splitext(base)[0]
    return fmt.replace("{{", "\0L").replace("}}", "\0R").replace("{//}", parent).replace("{/.}", bnoext).replace("{/}", base).replace("{.}", noext).replace("{}", p).replace("\0L", "{").replace("\0R", "}")


def ls_line(path, display):
    try:
        st = os.lstat(path)
    except OSError:
        return display
    perms = stat.filemode(st.st_mode)
    try: user = pwd.getpwuid(st.st_uid).pw_name
    except KeyError: user = str(st.st_uid)
    try: group = grp.getgrgid(st.st_gid).gr_name
    except KeyError: group = str(st.st_gid)
    mtime = _dt.datetime.fromtimestamp(st.st_mtime).strftime("%b %e %H:%M")
    target = ""
    if stat.S_ISLNK(st.st_mode):
        try: target = " -> " + os.readlink(path)
        except OSError: pass
    return f"{perms} {st.st_nlink:>2} {user} {group} {st.st_size:>6} {mtime} {display}{target}"


def collect(opts, pattern, roots):
    matchers = compile_matchers(opts, pattern)
    results = []
    for root_arg in roots:
        root = root_arg or "."
        use_gitignore = is_git_search(root)
        start_patterns = []
        if not opts.no_ignore:
            start_patterns += load_ignore_file(os.path.join(root, ".ignore"))
            start_patterns += load_ignore_file(os.path.join(root, ".fdignore"))
            if use_gitignore:
                start_patterns += load_ignore_file(os.path.join(root, ".gitignore"))
        stack = [(root, 0, start_patterns)]
        while stack:
            cur, depth, patterns = stack.pop()
            try:
                entries = sorted(os.scandir(cur), key=lambda e: e.name)
            except OSError as e:
                if opts.show_errors:
                    print(f"[fd error]: {e}", file=sys.stderr)
                continue
            if any(os.path.exists(os.path.join(cur, n)) for n in opts.ignore_contain):
                continue
            new_patterns = patterns[:]
            if not opts.no_ignore:
                new_patterns += load_ignore_file(os.path.join(cur, ".ignore"))
                new_patterns += load_ignore_file(os.path.join(cur, ".fdignore"))
                if use_gitignore:
                    new_patterns += load_ignore_file(os.path.join(cur, ".gitignore"))
            for ent in reversed(entries):
                name = ent.name
                path = ent.path
                rel_to_root = os.path.relpath(path, root)
                if not opts.hidden and name.startswith("."):
                    continue
                if not opts.no_ignore and ignored(rel_to_root, name, new_patterns):
                    continue
                try:
                    st = ent.stat(follow_symlinks=False)
                except OSError as e:
                    if opts.show_errors:
                        print(f"[fd error]: {e}", file=sys.stderr)
                    continue
                typ = file_type(path, st)
                is_dir = typ == "d"
                out = output_path(path, root, root_arg, opts, is_dir)
                match_target = os.path.abspath(path) if opts.full_path else name
                matched = all(m(match_target) for m in matchers)
                next_depth = depth + 1
                within_max = opts.max_depth is None or next_depth <= opts.max_depth
                if matched and within_max and next_depth >= opts.min_depth and filters_ok(opts, path, out, st, typ):
                    results.append((out, path, is_dir))
                    if opts.max_results and len(results) >= opts.max_results:
                        return results
                descend = is_dir and (opts.max_depth is None or next_depth < opts.max_depth)
                if descend and (opts.follow or not ent.is_symlink()):
                    if not (opts.prune and matched):
                        stack.append((path, next_depth, new_patterns))
    results.sort(key=lambda x: x[0].rstrip(os.sep))
    if opts.max_results:
        results = results[:opts.max_results]
    return results


def main(argv):
    opts, pattern, paths = parse(argv)
    results = collect(opts, pattern, paths)
    if opts.quiet:
        return 0 if results else 1
    display = [(exec_path(o, opts) if (opts.print0 or opts.exec_each or opts.exec_batch) else o, real, isdir) for o, real, isdir in results]
    if opts.exec_each is not None:
        code = 0
        for p, _, _ in display:
            rc = subprocess.call(substitute(opts.exec_each, [p]))
            code = code or rc
        return code
    if opts.exec_batch is not None:
        ps = [p for p, _, _ in display]
        if ps:
            chunks = [ps] if opts.batch_size <= 0 else [ps[i:i+opts.batch_size] for i in range(0, len(ps), opts.batch_size)]
            code = 0
            for ch in chunks:
                code = code or subprocess.call(substitute(opts.exec_batch, ch))
            return code
        return 0
    if opts.list_details:
        for p, real, _ in display:
            print(ls_line(real, p))
        return 0
    if opts.fmt is not None:
        for p, _, _ in display:
            print(format_result(opts.fmt, p))
        return 0
    sep = "\0" if opts.print0 else "\n"
    color = opts.color == "always"
    out = sep.join(colorize(p, color) for p, _, _ in display)
    if out:
        sys.stdout.write(out + sep)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
