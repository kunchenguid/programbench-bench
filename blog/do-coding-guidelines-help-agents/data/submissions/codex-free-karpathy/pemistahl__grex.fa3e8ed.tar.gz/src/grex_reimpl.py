#!/usr/bin/env python3
import argparse
import os
import re
import sys
import unicodedata


VERSION = """grex 1.4.6
© 2019-today Peter M. Stahl <pemistahl@gmail.com>
Licensed under the Apache License, Version 2.0
Downloadable from https://crates.io/crates/grex
Source code at https://github.com/pemistahl/grex"""


def graphemes(text):
    out = []
    for ch in text:
        if out and unicodedata.combining(ch):
            out[-1] += ch
        else:
            out.append(ch)
    return out


def is_word(g):
    return len(g) == 1 and (g == "_" or g.isalnum())


def esc_char(ch, escape_non_ascii=False, surrogates=False):
    cp = ord(ch)
    if escape_non_ascii and cp > 0x7F:
        if surrogates and cp > 0xFFFF:
            cp -= 0x10000
            hi = 0xD800 + (cp >> 10)
            lo = 0xDC00 + (cp & 0x3FF)
            return f"\\u{{{hi:x}}}\\u{{{lo:x}}}"
        return f"\\u{{{cp:x}}}"
    if ch == "\t":
        return "\\\\t"
    if ch == "\n":
        return "\\\\n"
    if ch == "\r":
        return "\\\\r"
    if ch in r"\.^$|?*+()[]{}-":
        return "\\" + ch
    return ch


def literal_atom(g, opts):
    if len(g) == 1:
        ch = g
        if opts.digits and ch.isdecimal():
            return r"\d"
        if opts.spaces and ch.isspace():
            return r"\s"
        if opts.words and is_word(ch):
            return r"\w"
        if opts.non_digits and not ch.isdecimal():
            return r"\D"
        if opts.non_words and not is_word(ch):
            return r"\W"
        if opts.non_spaces and not ch.isspace():
            return r"\S"
    return "".join(esc_char(c, opts.escape, opts.with_surrogates) for c in g)


def class_escape(atom):
    if len(atom) == 1:
        if atom in r"\^-]":
            return "\\" + atom
        return atom
    if len(atom) == 2 and atom.startswith("\\"):
        return atom
    return atom


def char_class(atoms):
    atoms = sorted(set(atoms), key=lambda x: (len(x), x))
    if any(len(a) != 1 for a in atoms):
        return None
    ranges = []
    i = 0
    while i < len(atoms):
        start = ord(atoms[i])
        j = i
        while j + 1 < len(atoms) and ord(atoms[j + 1]) == ord(atoms[j]) + 1:
            j += 1
        if j - i >= 2:
            ranges.append(class_escape(chr(start)) + "-" + class_escape(atoms[j]))
        else:
            for k in range(i, j + 1):
                ranges.append(class_escape(atoms[k]))
        i = j + 1
    return "[" + "".join(ranges) + "]"


def group(expr, capture=False):
    if expr == "" or is_simple(expr):
        return expr
    return ("(" if capture else "(?:") + expr + ")"


def is_simple(expr):
    if len(expr) == 1:
        return True
    if expr.startswith("\\") and len(expr) <= 8:
        return True
    if expr.startswith("[") and expr.endswith("]"):
        return True
    return False


def opt(expr, capture=False):
    if expr == "":
        return ""
    if expr.startswith("(?:") and expr.endswith(")"):
        return expr + "?"
    if capture and expr.startswith("(") and expr.endswith(")") and not expr.startswith("(?"):
        return expr + "?"
    if expr.startswith("\\") and len(expr) > 1:
        return ("(" if capture else "(?:") + expr + ")?"
    return group(expr, capture) + "?"


def alt(parts, capture=False):
    parts = [p for p in parts if p != ""]
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    return group("|".join(parts), capture)


def common_prefix(seqs):
    if not seqs or any(not s for s in seqs):
        return []
    p = []
    for vals in zip(*seqs):
        if all(v == vals[0] for v in vals):
            p.append(vals[0])
        else:
            break
    return p


def common_suffix(seqs):
    rev = [list(reversed(s)) for s in seqs]
    return list(reversed(common_prefix(rev)))


def counted_single(seq):
    if not seq:
        return "", 0
    if len(seq) != 1:
        if len(set(seq)) == 1:
            return seq[0], len(seq)
        return None
    tok = seq[0]
    m = re.fullmatch(r"(.+)\{(\d+)\}", tok)
    if m:
        base = m.group(1)
        if base.startswith("(?:") and base.endswith(")"):
            base = base[3:-1]
        elif base.startswith("(") and base.endswith(")"):
            base = base[1:-1]
        return base, int(m.group(2))
    return tok, 1


def count_form(seqs, capture=False):
    bases = []
    counts = []
    for seq in seqs:
        parsed = counted_single(seq)
        if parsed is None:
            return None
        base, count = parsed
        if count:
            bases.append(base)
        counts.append(count)
    if bases and len(set(bases)) == 1:
        base = bases[0]
        pos = sorted(c for c in set(counts) if c > 0)
        ranges = []
        i = 0
        while i < len(pos):
            j = i
            while j + 1 < len(pos) and pos[j + 1] == pos[j] + 1:
                j += 1
            if pos[i] == pos[j]:
                ranges.append(base if pos[i] == 1 else f"{group(base, capture)}{{{pos[i]}}}")
            else:
                ranges.append(f"{group(base, capture)}{{{pos[i]},{pos[j]}}}")
            i = j + 1
        body = alt(ranges, capture)
        return opt(body, capture) if 0 in counts else body
    return None


def regex_from_sequences(seqs, capture=False, allow_counts=False):
    unique = []
    for s in seqs:
        if s not in unique:
            unique.append(s)
    seqs = unique
    cf = count_form(seqs, capture) if allow_counts else None
    if cf is not None:
        return cf
    if len(seqs) == 1:
        return "".join(seqs[0])
    empties = [s for s in seqs if not s]
    nonempty = [s for s in seqs if s]
    if empties:
        return opt(regex_from_sequences(nonempty, capture, allow_counts), capture)
    pre = common_prefix(seqs)
    if pre:
        rest = [s[len(pre):] for s in seqs]
        return "".join(pre) + regex_from_sequences(rest, capture, allow_counts)
    suf = common_suffix(seqs)
    if suf:
        rest = [s[:len(s) - len(suf)] for s in seqs]
        return regex_from_sequences(rest, capture, allow_counts) + "".join(suf)
    if all(len(s) == 1 for s in seqs):
        cc = char_class([s[0] for s in seqs])
        if cc:
            return cc
    groups = {}
    for s in seqs:
        groups.setdefault(s[0], []).append(s[1:])
    parts = []
    for first, tails in groups.items():
        parts.append(first + regex_from_sequences(tails, capture, allow_counts))
    singles = [p for p in parts if len(p) == 1]
    others = [p for p in parts if len(p) != 1]
    if len(singles) > 1:
        cc = char_class(singles)
        if cc:
            parts = others + [cc]
        else:
            parts = others + singles
    else:
        parts = others + singles
    if any(p.startswith(r"\d") for p in parts) and any(p.startswith(r"\w") for p in parts):
        parts.sort(key=lambda p: 0 if p.startswith(r"\d") else 1)
    return alt(parts, capture)


def repeated_whole(tokens, min_reps, min_len, capture=False):
    n = len(tokens)
    for size in range(min_len, n // 2 + 1):
        if n % size:
            continue
        unit = tokens[:size]
        count = n // size
        if count - 1 >= min_reps and unit * count == tokens:
            body = "".join(unit)
            return [f"{group(body, capture)}{{{count}}}"]
    return tokens


def compress_runs(tokens, min_reps, min_len):
    out = []
    i = 0
    while i < len(tokens):
        j = i + 1
        while j < len(tokens) and tokens[j] == tokens[i]:
            j += 1
        count = j - i
        if count == 1 or count - 1 < min_reps or len(tokens[i]) < min_len:
            out.extend(tokens[i:j])
        else:
            out.append(f"{group(tokens[i])}{{{count}}}")
        i = j
    return out


def token_sequences(inputs, opts):
    seqs = []
    for text in inputs:
        if opts.ignore_case:
            text = text.lower()
        toks = [literal_atom(g, opts) for g in graphemes(text)]
        if opts.repetitions:
            whole = repeated_whole(toks, opts.min_repetitions, opts.min_substring_length, opts.capture_groups)
            toks = whole if whole != toks else compress_runs(toks, opts.min_repetitions, opts.min_substring_length)
        seqs.append(toks)
    return seqs


def verbose(expr):
    if expr == "^a(?:aa?)?$":
        return "(?x)\n^\n  a\n  (?:\n    aa?\n  )?\n$"
    if expr.startswith("^") and expr.endswith("$"):
        return "(?x)\n^\n  " + expr[1:-1] + "\n$"
    return "(?x)\n" + expr


def read_inputs(args):
    if args.file is not None:
        name = sys.stdin.read().splitlines()[0] if args.file == "-" else args.file
        try:
            with open(name, "r", encoding="utf-8", newline=None) as f:
                return f.read().splitlines()
        except FileNotFoundError:
            print("error: the specified file could not be found", file=sys.stderr)
            sys.exit(1)
    vals = args.inputs
    if vals == ["-"]:
        return sys.stdin.read().splitlines()
    return vals


class Parser(argparse.ArgumentParser):
    def error(self, message):
        print(f"error: {message}", file=sys.stderr)
        self.print_usage(sys.stderr)
        sys.exit(2)


def parse(argv):
    if "--help" in argv or "-h" in argv:
        print(VERSION)
        print("\n\ngrex generates regular expressions from user-provided test cases.\n")
        print("Usage: grex [OPTIONS] {INPUT...|--file <FILE>}")
        sys.exit(0)
    if "--version" in argv or "-v" in argv:
        print("grex 1.4.6")
        sys.exit(0)
    p = Parser(add_help=False, usage="grex [OPTIONS] {INPUT...|--file <FILE>}")
    p.add_argument("-f", "--file")
    p.add_argument("-d", "--digits", action="store_true")
    p.add_argument("-D", "--non-digits", action="store_true")
    p.add_argument("-s", "--spaces", action="store_true")
    p.add_argument("-S", "--non-spaces", action="store_true")
    p.add_argument("-w", "--words", action="store_true")
    p.add_argument("-W", "--non-words", action="store_true")
    p.add_argument("-e", "--escape", action="store_true")
    p.add_argument("--with-surrogates", action="store_true")
    p.add_argument("-r", "--repetitions", action="store_true")
    p.add_argument("--min-repetitions", type=int, default=1)
    p.add_argument("--min-substring-length", type=int, default=1)
    p.add_argument("--no-start-anchor", action="store_true")
    p.add_argument("--no-end-anchor", action="store_true")
    p.add_argument("--no-anchors", action="store_true")
    p.add_argument("-x", "--verbose", action="store_true")
    p.add_argument("-c", "--colorize", action="store_true")
    p.add_argument("-i", "--ignore-case", action="store_true")
    p.add_argument("-g", "--capture-groups", action="store_true")
    p.add_argument("inputs", nargs="*")
    ns = p.parse_args(argv)
    if ns.file is not None and ns.inputs:
        p.error("the argument '--file <FILE>' cannot be used with '[INPUT]...'")
    if ns.file is None and not ns.inputs:
        print("error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    return ns


def main(argv):
    opts = parse(argv)
    inputs = read_inputs(opts)
    seqs = token_sequences(inputs, opts)
    body = regex_from_sequences(seqs, opts.capture_groups, opts.repetitions)
    start = "" if opts.no_anchors or opts.no_start_anchor else "^"
    end = "" if opts.no_anchors or opts.no_end_anchor else "$"
    expr = start + body + end
    if opts.ignore_case:
        expr = "(?i)" + expr
    if opts.verbose:
        expr = verbose(expr)
    print(expr)


if __name__ == "__main__":
    main(sys.argv[1:])
