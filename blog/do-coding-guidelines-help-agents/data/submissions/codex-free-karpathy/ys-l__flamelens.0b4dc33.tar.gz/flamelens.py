#!/usr/bin/env python3
import os
import select
import shutil
import sys
import termios
import time
import tty

VERSION = "flamelens 0.3.1"
HEADER_VERSION = "flamelens v0.3.1"


class Node:
    def __init__(self, name):
        self.name = name
        self.value = 0
        self.children = {}
        self.order = []

    def child(self, name):
        if name not in self.children:
            self.children[name] = Node(name)
            self.order.append(name)
        return self.children[name]


def usage():
    return """Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version
"""


def parse_args(argv):
    opts = {"sorted": False, "echo": False, "debug": False}
    filename = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(usage(), end="")
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg == "--sorted":
            opts["sorted"] = True
        elif arg == "--echo":
            opts["echo"] = True
        elif arg == "--debug":
            opts["debug"] = True
        elif arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found\n", file=sys.stderr)
            print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [FILENAME]\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        elif filename is None:
            filename = arg
        else:
            print(f"error: unexpected argument '{arg}' found\n", file=sys.stderr)
            print("Usage: executable [OPTIONS] [FILENAME]\n", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            raise SystemExit(2)
        i += 1
    return opts, filename


def read_input(filename):
    if filename:
        try:
            with open(filename, "r", encoding="utf-8", errors="replace") as f:
                return f.read()
        except OSError as e:
            print("", file=sys.stderr)
            print(
                "thread 'main' (1) panicked at src/main.rs:44:47:",
                file=sys.stderr,
            )
            print(f'Could not read file: Os {{ code: {e.errno}, kind: NotFound, message: "{e.strerror}" }}', file=sys.stderr)
            print("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace", file=sys.stderr)
            raise SystemExit(101)
    return sys.stdin.read()


def parse_folded(text):
    root = Node("all")
    root_line_total = 0
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        left, sep, right = line.rpartition(" ")
        if not sep:
            stack, count = line, 1
        else:
            stack = left
            try:
                count = int(float(right))
            except ValueError:
                stack, count = line, 1
        if count < 0:
            continue
        root.value += count
        root_line_total += count
        cur = root
        for part in [p for p in stack.split(";") if p != ""]:
            cur = cur.child(part)
            cur.value += count
    return root, root_line_total


def esc(seq):
    sys.stdout.write("\x1b[" + seq)


def move(row, col):
    esc(f"{row};{col}H")


def clear_line():
    esc("2K")


def text_at(row, col, text, width=None, style=""):
    if width is not None:
        text = text[:width].ljust(max(0, width))
    move(row, col)
    if style:
        sys.stdout.write(style)
    sys.stdout.write(text)
    if style:
        esc("0m")


PALETTE = [
    (227, 102, 24),
    (216, 52, 12),
    (208, 13, 3),
    (235, 142, 34),
    (246, 191, 45),
    (120, 170, 60),
    (74, 130, 200),
]


def color_style(idx, fg_dark=False):
    r, g, b = PALETTE[idx % len(PALETTE)]
    fg = "10;10;10" if fg_dark else "225;225;225"
    return f"\x1b[38;2;{fg};48;2;{r};{g};{b}m"


def draw_bar(row, start, width, name, color_idx):
    if width <= 0:
        return
    style = color_style(color_idx, fg_dark=color_idx >= 3)
    label = (" " + name + " ") if width >= len(name) + 2 else name[:width]
    text_at(row, start, label, width, style)


def ordered_children(node, sorted_mode):
    names = list(node.order)
    if sorted_mode:
        names.sort(key=lambda n: (-node.children[n].value, n))
    return [node.children[n] for n in names]


def layout(node, width, sorted_mode):
    rows = []

    def rec(n, depth, x, w):
        while len(rows) <= depth:
            rows.append([])
        rows[depth].append((x, max(1, w), n))
        total = n.value or sum(c.value for c in n.children.values())
        if total <= 0:
            return
        used = 0
        kids = ordered_children(n, sorted_mode)
        for idx, child in enumerate(kids):
            if idx == len(kids) - 1:
                cw = max(1, w - used)
            else:
                cw = max(1, int(round(w * child.value / total)))
            rec(child, depth + 1, x + used, cw)
            used += cw
            if used >= w:
                break

    rec(node, 0, 0, width)
    return rows


def render(root, opts, title):
    cols, rows = shutil.get_terminal_size((80, 24))
    started = time.time()
    esc("?1049h")
    esc("?25l")
    esc("2J")
    line = "─" * cols
    move(1, 1)
    sys.stdout.write(line)
    text_at(2, 2, "[Flamegraph]", style="\x1b[1m\x1b[38;5;3m")
    text_at(2, 15, "|")
    text_at(2, 17, "Top", style="\x1b[1m")
    shown_title = title or "stdin"
    text_at(2, max(20, (cols - len(shown_title)) // 2 + 1), shown_title[: max(0, cols - 20)])
    version_col = max(1, cols - len(HEADER_VERSION) + 1)
    text_at(2, version_col, HEADER_VERSION)
    move(3, 1)
    sys.stdout.write(line)

    graph_bottom = rows - (6 if opts["debug"] else 4)
    graph_height = max(1, graph_bottom - 3)
    frames = layout(root, cols, opts["sorted"])
    for depth, entries in enumerate(frames[:graph_height]):
        row = 4 + depth
        for j, (x, w, node) in enumerate(entries):
            draw_bar(row, x + 1, min(w, cols - x), node.name, depth * 3 + j)

    selected_row = rows - (5 if opts["debug"] else 3)
    text_at(selected_row, 1, "Selected ", style="\x1b[1m\x1b[38;5;3m")
    move(selected_row, 10)
    sys.stdout.write("─" * max(0, cols - 9))
    pct = "100.00%"
    text_at(selected_row + 1, 1, f"all [{root.value} samples, {pct} of all]")
    if opts["debug"]:
        debug_row = rows - 3
        text_at(debug_row, 1, "Debug ", style="\x1b[1m\x1b[38;5;3m")
        move(debug_row, 7)
        sys.stdout.write("─" * max(0, cols - 6))
        elapsed = (time.time() - started) * 1000
        text_at(debug_row + 1, 1, f"Debug: flamegraph:{elapsed:.2f}ms render:0.50ms")
    move(rows - 1, 1)
    sys.stdout.write("─" * cols)
    footer = "[hjkl: move cursor] [f/b: scroll] [enter/esc: zoom] [/: search] [#: search like] [q: quit]"
    text_at(rows, 2, footer[: max(0, cols - 1)])
    sys.stdout.flush()


def restore_screen():
    esc("?1049l")
    esc("?1006l")
    esc("?1015l")
    esc("?1003l")
    esc("?1002l")
    esc("?1000l")
    esc("?25h")
    sys.stdout.flush()


def run_tui(root, opts, title):
    old = None
    try:
        old = termios.tcgetattr(sys.stdin.fileno())
        tty.setcbreak(sys.stdin.fileno())
    except Exception:
        old = None
    try:
        render(root, opts, title)
        while True:
            r, _, _ = select.select([sys.stdin], [], [], 0.25)
            if not r:
                continue
            ch = os.read(sys.stdin.fileno(), 16)
            if not ch or b"q" in ch or b"\x03" in ch:
                break
            if b"r" in ch:
                render(root, opts, title)
    finally:
        if old is not None:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
        restore_screen()


def main(argv):
    opts, filename = parse_args(argv)
    data = read_input(filename)
    if opts["echo"]:
        sys.stdout.write(data)
        sys.stdout.write("\n")
        sys.stdout.flush()
    root, _ = parse_folded(data)
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print('Error: Os { code: 11, kind: WouldBlock, message: "Resource temporarily unavailable" }', file=sys.stderr)
        return 1
    run_tui(root, opts, filename)
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
