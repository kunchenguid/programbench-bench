#!/usr/bin/env python3
import re
import sys

VERSION = "0.1.5"
RESET = "\033[0m"

LONG_HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
"""

SHORT_HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
"""


class Face:
    def __init__(self, codes=None):
        self.codes = list(codes or [])

    def seq(self):
        return "".join(f"\033[{code}m" for code in self.codes)

    def apply(self, text):
        return RESET + self.seq() + text + RESET


faces = {
    "removed": Face(["31"]),
    "added": Face(["32"]),
    "refine-removed": Face(["1", "38;2;255;255;255", "41"]),
    "refine-added": Face(["1", "38;2;255;255;255", "42"]),
}

COLOR_NAMES = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
}
ATTR_CODES = {"bold": "1", "dimmed": "2", "italic": "3", "underline": "4", "intense": "1"}


def color_code(kind, value):
    if value == "none":
        return None
    if value in COLOR_NAMES:
        return str((30 if kind == "foreground" else 40) + COLOR_NAMES[value])
    if re.fullmatch(r"\d+", value):
        n = int(value)
        if 0 <= n <= 255:
            return f"{'38' if kind == 'foreground' else '48'};5;{n}"
    if re.fullmatch(r"\d+,\d+,\d+", value):
        parts = [int(p) for p in value.split(",")]
        if all(0 <= p <= 255 for p in parts):
            return f"{'38' if kind == 'foreground' else '48'};2;{parts[0]};{parts[1]};{parts[2]}"
    print(f"unexpected color: got '{value}'", file=sys.stderr)
    sys.exit(255)


def parse_color_spec(spec):
    parts = spec.split(":")
    face = parts[0]
    if face not in faces:
        print(
            f"unexpected face name: got '{face}', expected added|refine-added|removed|refine-removed",
            file=sys.stderr,
        )
        sys.exit(255)
    i = 1
    while i < len(parts):
        attr = parts[i]
        if attr == "none":
            faces[face].codes = []
            i += 1
        elif attr in ("foreground", "background"):
            if i + 1 >= len(parts):
                print(f"expected color after {attr}", file=sys.stderr)
                sys.exit(255)
            code = color_code(attr, parts[i + 1])
            long_prefix = "38" if attr == "foreground" else "48"
            short_prefix = "3" if attr == "foreground" else "4"
            faces[face].codes = [
                c for c in faces[face].codes if not (c.startswith(long_prefix) or (len(c) == 2 and c[0] == short_prefix))
            ]
            if code:
                faces[face].codes.append(code)
            i += 2
        elif attr in ATTR_CODES:
            code = ATTR_CODES[attr]
            if code not in faces[face].codes:
                faces[face].codes.insert(0, code)
            i += 1
        elif attr.startswith("no") and attr[2:] in ATTR_CODES:
            code = ATTR_CODES[attr[2:]]
            faces[face].codes = [c for c in faces[face].codes if c != code]
            i += 1
        elif attr == "":
            i += 1
        else:
            print(
                f"unexpected attribute name: got '{attr}', expected foreground|background|italic|noitalic|bold|nobold|dimmed|nodimmed|intense|nointense|underline|nounderline|none",
                file=sys.stderr,
            )
            sys.exit(255)


def parse_args(argv):
    line_numbers = None
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "--help":
            sys.stdout.write(LONG_HELP)
            sys.exit(0)
        if arg == "-h":
            sys.stdout.write(SHORT_HELP)
            sys.exit(0)
        if arg in ("-V", "--version"):
            print(f"diffr {VERSION}")
            sys.exit(0)
        if arg == "--colors":
            if i + 1 >= len(argv):
                print("expected color specification after --colors", file=sys.stderr)
                sys.exit(255)
            parse_color_spec(argv[i + 1])
            i += 2
            continue
        if arg == "--line-numbers":
            if i + 1 < len(argv) and argv[i + 1] in ("compact", "aligned"):
                line_numbers = argv[i + 1]
                i += 2
            else:
                line_numbers = "compact"
                i += 1
            continue
        print(f"bad argument: '{arg}'", file=sys.stderr)
        sys.stderr.write(SHORT_HELP)
        sys.exit(0)
    return line_numbers


def split_keep_newline(line):
    if line.endswith("\n"):
        return line[:-1], "\n"
    return line, ""


def tokenize(text):
    if "+" not in text and "-" not in text:
        if not any(ch.isspace() for ch in text):
            return [text] if text else []
        pieces = re.findall(r"\S+|\s+", text)
        tokens = []
        i = 0
        if pieces and not pieces[0].isspace():
            tokens.append(pieces[0])
            i = 1
        while i < len(pieces):
            if i + 2 < len(pieces) and pieces[i].isspace() and not pieces[i + 1].isspace() and pieces[i + 2].isspace():
                tokens.append(pieces[i] + pieces[i + 1] + pieces[i + 2])
                i += 3
            else:
                tokens.append(pieces[i])
                i += 1
        return tokens
    tokens = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch.isspace():
            j = i
            while j < len(text) and text[j] not in "+-" and not text[j].isdigit():
                j += 1
            tokens.append(text[i:j])
            i = j
        elif ch in "+-" and i + 1 < len(text) and not text[i + 1].isspace():
            j = i + 1
            while j < len(text) and (text[j].isalnum() or text[j] == "_"):
                j += 1
            tokens.append(text[i:j])
            i = j
        elif ch.isdigit():
            j = i + 1
            while j < len(text) and text[j].isdigit():
                j += 1
            tokens.append(text[i:j])
            i = j
        else:
            j = i + 1
            while j < len(text) and text[j] not in "+-" and not text[j].isdigit():
                j += 1
            tokens.append(text[i:j])
            i = j
    return tokens


def lcs_pairs(left, right):
    n = len(left)
    m = len(right)
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n - 1, -1, -1):
        for j in range(m - 1, -1, -1):
            if left[i] == right[j]:
                dp[i][j] = dp[i + 1][j + 1] + 1
            else:
                dp[i][j] = max(dp[i + 1][j], dp[i][j + 1])
    pairs = []
    i = 0
    j = 0
    while i < n and j < m:
        if left[i] == right[j]:
            pairs.append((i, j))
            i += 1
            j += 1
        elif dp[i + 1][j] >= dp[i][j + 1]:
            i += 1
        else:
            j += 1
    return pairs


def render_pair(old, new):
    old_tokens = tokenize(old)
    new_tokens = tokenize(new)
    pairs = lcs_pairs(old_tokens, new_tokens)
    old_out = []
    new_out = []
    oi = 0
    ni = 0
    def append(out, face_name, text):
        if text:
            out.append(faces[face_name].apply(text))

    for ci, cj in pairs + [(len(old_tokens), len(new_tokens))]:
        if ci > oi:
            append(old_out, "refine-removed", "".join(old_tokens[oi:ci]))
        if cj > ni:
            append(new_out, "refine-added", "".join(new_tokens[ni:cj]))
        if ci < len(old_tokens):
            append(old_out, "removed", old_tokens[ci])
            append(new_out, "added", new_tokens[cj])
        oi = ci + 1
        ni = cj + 1
    return "".join(old_out), "".join(new_out)


HUNK_RE = re.compile(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


def main():
    line_number_style = parse_args(sys.argv[1:])
    old_no = 0
    new_no = 0
    in_hunk = False
    pending = []

    def number_prefix(kind, number):
        if line_number_style is None:
            return ""
        if kind == "del":
            text = f"{number}  "
        elif kind == "add":
            text = f"  {number}"
        else:
            text = f"  {number}"
        if line_number_style == "aligned":
            text += "\t"
        return text

    def emit_plain(raw):
        body, nl = split_keep_newline(raw)
        sys.stdout.write(RESET + body + RESET + nl)

    def flush_pending():
        nonlocal pending
        if not pending:
            return
        dels = [entry for entry in pending if entry[0] == "-"]
        adds = [entry for entry in pending if entry[0] == "+"]
        rendered_dels = []
        rendered_adds = []
        for idx in range(max(len(dels), len(adds))):
            if idx < len(dels) and idx < len(adds):
                old_text, old_num = dels[idx][1], dels[idx][2]
                new_text, new_num = adds[idx][1], adds[idx][2]
                old_rendered, new_rendered = render_pair(old_text, new_text)
                p = number_prefix("del", old_num)
                rendered_dels.append((faces["removed"].apply(p) if p else "") + faces["removed"].apply("-") + old_rendered + faces["removed"].apply(""))
                p = number_prefix("add", new_num)
                rendered_adds.append((faces["added"].apply(p) if p else "") + faces["added"].apply("+") + new_rendered + faces["added"].apply(""))
            elif idx < len(dels):
                text, num = dels[idx][1], dels[idx][2]
                p = number_prefix("del", num)
                rendered_dels.append((faces["removed"].apply(p) if p else "") + faces["removed"].apply("-") + faces["refine-removed"].apply(text) + faces["removed"].apply(""))
            else:
                text, num = adds[idx][1], adds[idx][2]
                p = number_prefix("add", num)
                rendered_adds.append((faces["added"].apply(p) if p else "") + faces["added"].apply("+") + faces["refine-added"].apply(text) + faces["added"].apply(""))
        for line in rendered_dels + rendered_adds:
            sys.stdout.write(line + "\n")
        pending = []

    for raw in sys.stdin.read().splitlines(True):
        line, nl = split_keep_newline(raw)
        match = HUNK_RE.match(line)
        if match:
            flush_pending()
            emit_plain(raw)
            in_hunk = True
            old_no = int(match.group(1))
            new_no = int(match.group(3))
            continue

        if not in_hunk:
            emit_plain(raw)
            continue

        if line.startswith("-") and not line.startswith("---"):
            pending.append(("-", line[1:], old_no))
            old_no += 1
            continue
        if line.startswith("+") and not line.startswith("+++"):
            pending.append(("+", line[1:], new_no))
            new_no += 1
            continue

        flush_pending()
        if line.startswith(" "):
            sys.stdout.write(number_prefix("ctx", new_no) + RESET + line + RESET + nl)
            old_no += 1
            new_no += 1
        elif line.startswith("\\"):
            emit_plain(raw)
        else:
            in_hunk = False
            emit_plain(raw)
    flush_pending()


if __name__ == "__main__":
    main()
