#!/usr/bin/env python3
import json, os, re, sys

VERSION = "39.2.0"

class Undefined:
    pass

UNDEFINED = Undefined()

def strip_json_comments(s):
    out = []
    i = 0
    in_str = False
    esc = False
    while i < len(s):
        c = s[i]
        if in_str:
            out.append(c)
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            i += 1
            continue
        if c == '"':
            in_str = True
            out.append(c)
            i += 1
        elif c == "/" and i + 1 < len(s) and s[i + 1] == "/":
            while i < len(s) and s[i] not in "\r\n":
                i += 1
        elif c == "/" and i + 1 < len(s) and s[i + 1] == "*":
            i += 2
            while i + 1 < len(s) and not (s[i] == "*" and s[i + 1] == "/"):
                i += 1
            i += 2
        else:
            out.append(c)
            i += 1
    s = "".join(out)
    return re.sub(r",(\s*[}\]])", r"\1", s)

def parse_values(text, strict=False, raw=False):
    if raw:
        return [text]
    src = text if strict else strip_json_comments(text)
    dec = json.JSONDecoder()
    vals = []
    i = 0
    while True:
        while i < len(src) and src[i].isspace():
            i += 1
        if i >= len(src):
            break
        try:
            v, j = dec.raw_decode(src, i)
        except Exception as e:
            print(str(e), file=sys.stderr)
            sys.exit(1)
        vals.append(v)
        i = j
    return vals

def parse_atom(s, cur=None, env=None):
    s = s.strip()
    if len(s) >= 2 and s[0] in "'\"" and s[-1] == s[0]:
        return s[1:-1]
    if s in ("true", "false"):
        return s == "true"
    if s in ("null", "None"):
        return None
    if s == "undefined":
        return UNDEFINED
    try:
        if re.match(r"^-?\d+$", s):
            return int(s)
        if re.match(r"^-?(\d+\.\d*|\.\d+)", s):
            return float(s)
    except Exception:
        pass
    if env and s in env:
        return env[s]
    if s.startswith(".") or s.startswith("this.") or s.startswith("x."):
        base = cur
        if env and s[0] != ".":
            base = env.get(s.split(".", 1)[0], cur)
            s = "." + s.split(".", 1)[1]
        return eval_path(base, s)
    return s

def tokens(path):
    if path in ("", "."):
        return []
    if path.startswith("this."):
        path = "." + path[5:]
    if path.startswith("x."):
        path = "." + path[2:]
    if path.startswith("."):
        path = path[1:]
    res, i = [], 0
    while i < len(path):
        if path[i] == ".":
            i += 1
            continue
        if path[i] == "[":
            j = path.find("]", i)
            inside = path[i + 1:j]
            if inside == "":
                res.append(("wild", None))
            elif inside[0:1] in "'\"":
                res.append(("key", inside[1:-1]))
            else:
                try:
                    res.append(("idx", int(inside)))
                except Exception:
                    res.append(("key", inside))
            i = j + 1
            continue
        j = i
        while j < len(path) and path[j] not in ".[":
            j += 1
        name = path[i:j]
        if name == "length":
            res.append(("length", None))
        elif name:
            res.append(("key", name))
        i = j
    return res

def prop(v, key):
    if isinstance(v, dict):
        return v.get(key, UNDEFINED)
    if isinstance(v, list) and isinstance(key, int):
        return v[key] if 0 <= key < len(v) else UNDEFINED
    return UNDEFINED

def eval_path(v, path):
    ts = tokens(path)
    def rec(cur, rest):
        if not rest:
            return cur
        typ, val = rest[0]
        if typ == "wild":
            if not isinstance(cur, list):
                return UNDEFINED
            return [rec(x, rest[1:]) for x in cur]
        if typ == "length":
            return len(cur) if isinstance(cur, (list, dict, str)) else UNDEFINED
        if typ == "idx":
            nxt = prop(cur, val)
        else:
            nxt = prop(cur, val)
        if nxt is UNDEFINED:
            return UNDEFINED
        return rec(nxt, rest[1:])
    return rec(v, ts)

def split_args(s):
    args, buf, depth, quote, esc = [], "", 0, None, False
    for c in s:
        if quote:
            buf += c
            if esc: esc = False
            elif c == "\\": esc = True
            elif c == quote: quote = None
        elif c in "'\"":
            quote = c; buf += c
        elif c in "([{":
            depth += 1; buf += c
        elif c in ")]}":
            depth -= 1; buf += c
        elif c == "," and depth == 0:
            args.append(buf.strip()); buf = ""
        else:
            buf += c
    if buf.strip() or s.strip():
        args.append(buf.strip())
    return args

def py_expr(expr):
    e = expr.strip()
    e = e.replace("===", "==").replace("!==", "!=")
    e = re.sub(r"\btrue\b", "True", e)
    e = re.sub(r"\bfalse\b", "False", e)
    e = re.sub(r"\bnull\b", "None", e)
    for _ in range(4):
        e = re.sub(r"\b([A-Za-z_]\w*)\.([A-Za-z_]\w*)\b", r"get_prop(\1, '\2')", e)
    return e

def eval_js_expr(expr, env):
    safe = {"len": len, "sum": sum, "min": min, "max": max, "str": str,
            "get_prop": lambda o, k: prop(o, k)}
    return eval(py_expr(expr), {"__builtins__": {}}, {**safe, **env})

def arrow(fn):
    fn = fn.strip()
    if "=>" not in fn:
        return None
    left, body = fn.split("=>", 1)
    left = left.strip()
    if left.startswith("(") and left.endswith(")"):
        names = [x.strip() for x in left[1:-1].split(",") if x.strip()]
    else:
        names = [left]
    return names, body.strip()

def apply_method(target, name, argstr):
    args = split_args(argstr)
    if name == "map":
        a = arrow(args[0]) if args else None
        return [eval_js_expr(a[1], dict(zip(a[0], [x]))) for x in (target or [])] if a else target
    if name == "filter":
        a = arrow(args[0]) if args else None
        return [x for x in (target or []) if eval_js_expr(a[1], dict(zip(a[0], [x])))] if a else target
    if name == "reduce":
        a = arrow(args[0]); acc = parse_atom(args[1]) if len(args) > 1 else (target[0] if target else None)
        seq = target if len(args) > 1 else target[1:]
        for x in seq:
            acc = eval_js_expr(a[1], dict(zip(a[0], [acc, x])))
        return acc
    if name == "sort":
        arr = list(target or [])
        if args and arrow(args[0]):
            a = arrow(args[0])
            from functools import cmp_to_key
            def cmp(p, q):
                r = eval_js_expr(a[1], dict(zip(a[0], [p, q])))
                return -1 if r < 0 else (1 if r > 0 else 0)
            arr.sort(key=cmp_to_key(cmp))
        else:
            arr.sort()
        return arr
    if name == "includes":
        return parse_atom(args[0]) in target if args else False
    if name == "toUpperCase":
        return str(target).upper()
    if name == "toLowerCase":
        return str(target).lower()
    if name == "trim":
        return str(target).strip()
    if name == "split":
        return str(target).split(parse_atom(args[0]) if args else None)
    if name == "join":
        return (parse_atom(args[0]) if args else ",").join(map(str, target or []))
    if name == "slice":
        start = int(parse_atom(args[0])) if args else 0
        end = int(parse_atom(args[1])) if len(args) > 1 else None
        return target[start:end]
    return UNDEFINED

def eval_filter(cur, expr):
    expr = expr.strip()
    if not expr or expr == ".":
        return cur
    if expr == "len":
        return len(cur) if isinstance(cur, (list, dict, str)) else UNDEFINED
    if expr == "keys":
        return list(cur.keys()) if isinstance(cur, dict) else list(range(len(cur))) if isinstance(cur, list) else []
    if expr == "values":
        return list(cur.values()) if isinstance(cur, dict) else cur if isinstance(cur, list) else []
    m = re.match(r"^(.*)\.([A-Za-z_]\w*)\((.*)\)$", expr)
    if m:
        target_expr, name, argstr = m.groups()
        target = eval_filter(cur, target_expr or ".")
        return apply_method(target, name, argstr)
    a = arrow(expr)
    if a:
        return eval_js_expr(a[1], {a[0][0]: cur})
    if expr.startswith("this."):
        return eval_path(cur, expr)
    if expr.startswith("."):
        return eval_path(cur, expr)
    try:
        return eval_js_expr(expr, {"x": cur, "this": cur})
    except Exception:
        print(f"ReferenceError: {expr} is not defined", file=sys.stderr)
        sys.exit(1)

def inline(v):
    if isinstance(v, dict):
        return "{ " + ", ".join(json.dumps(k, ensure_ascii=False) + ": " + inline(val) for k, val in v.items()) + " }"
    if isinstance(v, list):
        return "[ " + ", ".join(inline(x) for x in v) + " ]"
    return json.dumps(v, ensure_ascii=False, separators=(", ", ": "))

def fmt(v, level=0, no_inline=False):
    ind = "  " * level
    if v is UNDEFINED:
        return "undefined"
    if isinstance(v, str):
        return v if level == 0 else json.dumps(v, ensure_ascii=False)
    if v is True: return "true"
    if v is False: return "false"
    if v is None: return "null"
    if isinstance(v, (int, float)): return str(v).lower()
    if isinstance(v, list):
        if not v: return "[]"
        lines = ["["]
        inline_dicts = all(isinstance(x, dict) and all(not isinstance(y, (dict, list)) for y in x.values()) for x in v)
        for i, x in enumerate(v):
            comma = "," if i < len(v) - 1 else ""
            if inline_dicts and isinstance(x, dict) and not no_inline:
                lines.append("  " * (level + 1) + inline(x) + comma)
            else:
                parts = fmt(x, level + 1, no_inline).splitlines()
                lines.append("  " * (level + 1) + parts[0])
                for part in parts[1:-1]:
                    lines.append(part)
                if len(parts) > 1:
                    lines.append(parts[-1] + comma)
                else:
                    lines[-1] += comma
        lines.append(ind + "]")
        return "\n".join(lines)
    if isinstance(v, dict):
        if not v: return "{}"
        lines = ["{"]
        items = list(v.items())
        for i, (k, x) in enumerate(items):
            comma = "," if i < len(items) - 1 else ""
            prefix = "  " * (level + 1) + json.dumps(k, ensure_ascii=False) + ": "
            if isinstance(x, (dict, list)):
                parts = fmt(x, level + 1, no_inline).splitlines()
                lines.append(prefix + parts[0])
                for part in parts[1:-1]:
                    lines.append(part)
                if len(parts) > 1:
                    lines.append(parts[-1] + comma)
                else:
                    lines[-1] += comma
            else:
                lines.append(prefix + fmt(x, level + 1, no_inline) + comma)
        lines.append(ind + "}")
        return "\n".join(lines)
    return str(v)

def print_help():
    print("""
  fx 39.2.0
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
""")

def main():
    args = sys.argv[1:]
    raw = slurp = strict = no_inline = False
    comp = None
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print_help(); return
        if a in ("-v", "--version"):
            print(VERSION); return
        if a == "--themes":
            for n in range(10):
                print(f'export FX_THEME="{n}"')
                print('{\n  "string": "Fox jumps over the lazy dog",\n  "number": 1234567890,\n  "boolean": true,\n  "null": null,\n  "collapsed": {"preview":…}\n}')
            return
        if a == "--comp":
            comp = args[i + 1] if i + 1 < len(args) else ""; i += 2; continue
        if a in ("-r", "--raw"): raw = True
        elif a in ("-s", "--slurp"): slurp = True
        elif a == "--strict": strict = True
        elif a == "--no-inline": no_inline = True
        elif a in ("--yaml", "--toml", "--game-of-life"):
            pass
        else:
            rest.append(a)
        i += 1
    if comp is not None:
        if comp == "bash": print("complete -o filenames -C fx fx")
        elif comp == "fish": print("complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'")
        elif comp == "zsh": print("#compdef fx\n\n_fx() {\n    compadd -- ${(f)$(fx)}\n}\n")
        else: print("unknown shell type")
        return
    stdin = "" if sys.stdin.isatty() else sys.stdin.read()
    files, filters = [], []
    if stdin == "":
        for a in rest:
            if not filters and os.path.exists(a):
                files.append(a)
            else:
                filters.append(a)
        text = "".join(open(f, encoding="utf-8").read() for f in files) if files else ""
    else:
        text = stdin
        filters = rest
    vals = parse_values(text, strict=strict, raw=raw) if text != "" else []
    if slurp:
        vals = [vals]
    outs = []
    for v in vals:
        cur = v
        for f in filters:
            cur = eval_filter(cur, f)
        if cur is UNDEFINED:
            print("undefined", file=sys.stderr)
        else:
            outs.append(fmt(cur, 0, no_inline))
    if outs:
        print("\n".join(outs))

if __name__ == "__main__":
    main()
