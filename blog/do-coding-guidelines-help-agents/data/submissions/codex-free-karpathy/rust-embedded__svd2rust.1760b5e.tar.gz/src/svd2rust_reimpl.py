#!/usr/bin/env python3
import argparse, os, re, sys, xml.etree.ElementTree as ET
from copy import deepcopy
VERSION = "svd2rust 0.37.1 (e29353d 2026-03-03)"
HELP_LONG = """Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file

  -o, --output-dir <PATH>
          Directory to place generated files

  -c, --config <TOML_FILE>
          Config TOML file

      --settings <YAML_FILE>
          Target-specific settings YAML file

      --edition <YEAR>
          Rust edition of generated code

      --target <ARCH>
          Target architecture

      --atomics
          Generate atomic register modification API

      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API

      --ignore-groups
          Don't add alternateGroup name as prefix to register name

      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays

  -g, --generic-mod
          Push generic mod in separate file

      --feature-group
          Use group_name of peripherals as feature

      --feature-peripheral
          Use independent cfg feature flags for each peripheral

  -f, --ident-format <ident_format>
          Specify `-f type:prefix:case:suffix` to change default ident formatting.
          Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').
          

      --ident-formats-theme <THEME>
          A set of `ident_format` settings. `new` or `legacy`

      --field-names-for-enums
          Use field name for enumerations even when enumeratedValues has a name

      --max-cluster-size
          Use array increment for cluster size

      --impl-debug
          implement Debug for readable blocks and registers

      --impl-debug-feature <FEATURE>
          Add feature gating for block and register debug implementation

      --impl-defmt <FEATURE>
          Add automatic defmt implementation for enumerated values

  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes

      --skip-crate-attributes
          Do not generate crate attributes

  -s, --strict
          Make advanced checks due to parsing SVD

      --source-type <source_type>
          Specify file/stream format

      --reexport-core-peripherals
          For Cortex-M target reexport peripherals from cortex-m crate

      --reexport-interrupt
          Reexport interrupt macro from cortex-m-rt like crates

  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.

  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG)
          
          [possible values: off, error, warn, info, debug, trace]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""
HELP_SHORT = HELP_LONG.replace("\n\n", "\n").replace("Print help (see a summary with '-h')", "Print help (see more with '--help')")
KEYWORDS = set("as break const continue crate else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while async await dyn".split())

def strip_ns(tag): return tag.split('}',1)[-1]
def child(e,n):
    for c in list(e):
        if strip_ns(c.tag)==n: return c
    return None
def children(e,n): return [] if e is None else [c for c in list(e) if strip_ns(c.tag)==n]
def text(e,n,d=""):
    c=child(e,n)
    return (c.text or "").strip() if c is not None and c.text is not None else d
def parse_int(s,d=0):
    s=str(s or "").strip().replace("_","")
    if not s: return d
    try: return int(s[1:],2) if s.startswith('#') else int(s,0)
    except Exception:
        m=re.search(r"0x[0-9a-fA-F]+|\d+",s); return int(m.group(0),0) if m else d
def words(name):
    name=(name or "unnamed").replace("%s","")
    name=re.sub(r"([a-z0-9])([A-Z])",r"\1_\2",name)
    out=[]
    for p in re.split(r"[^A-Za-z0-9]+",name):
        if p: out += re.findall(r"[A-Z]+(?=[A-Z][a-z]|$)|[A-Z]?[a-z]+|\d+",p) or [p]
    return out or ["unnamed"]
def snake(n):
    s="_".join(w.lower() for w in words(n)); s=("_"+s if re.match(r"^\d",s) else s)
    return s+"_" if s in KEYWORDS else s
def pascal(n):
    s="".join(w[:1].upper()+w[1:].lower() for w in words(n)) or "Unnamed"
    return "N"+s if re.match(r"^\d",s) else (s+"_" if s in KEYWORDS else s)
def const_name(n): return "_".join(w.upper() for w in words(n)) or "UNNAMED"
def doc(s): return '#[doc = "'+(s or "").replace('\\','\\\\').replace('"','\\"').replace('\n','\\n')+'"]'
def reg_uint(size):
    n=parse_int(size,32)
    return "u8" if n<=8 else "u16" if n<=16 else "u32" if n<=32 else "u64"
def access_kind(reg):
    a=(text(reg,"access") or "read-write").lower()
    return a, ("read" in a), ("write" in a)
def bit_info(f):
    if text(f,"bitOffset") or text(f,"bitWidth"): return parse_int(text(f,"bitOffset"),0), max(1,parse_int(text(f,"bitWidth"),1))
    m=re.match(r"\[\s*(\d+)\s*:\s*(\d+)\s*\]", text(f,"bitRange"))
    if m:
        hi,lo=int(m.group(1)),int(m.group(2)); return min(hi,lo), abs(hi-lo)+1
    if text(f,"lsb") or text(f,"msb"):
        lo,hi=parse_int(text(f,"lsb"),0),parse_int(text(f,"msb"),0); return min(hi,lo),abs(hi-lo)+1
    return 0,1
def expand_dim(elem):
    dim=parse_int(text(elem,"dim"),0)
    if not dim: return [elem]
    inc=parse_int(text(elem,"dimIncrement"),0); di=text(elem,"dimIndex"); idx=[]
    for part in ([p.strip() for p in di.split(',')] if di else []):
        if '-' in part:
            a,b=part.split('-',1)
            if a.isdigit() and b.isdigit(): idx += [str(i) for i in range(int(a),int(b)+1)]
            elif len(a)==len(b)==1: idx += [chr(i) for i in range(ord(a),ord(b)+1)]
        elif part: idx.append(part)
    if not idx: idx=[str(i) for i in range(dim)]
    out=[]
    for pos,i in enumerate(idx[:dim]):
        e=deepcopy(elem); nc=child(e,"name"); nc.text=(nc.text or "").replace("%s",i) if "%s" in (nc.text or "") else (nc.text or "")+i
        oc=child(e,"addressOffset")
        if oc is not None: oc.text=hex(parse_int(oc.text,0)+pos*inc)
        out.append(e)
    return out
def collect_registers(periph):
    regs=child(periph,"registers"); out=[]
    def walk(parent,base=0):
        for e in list(parent or []):
            if strip_ns(e.tag)=="register":
                for r in expand_dim(e): out.append((base+parse_int(text(r,"addressOffset"),0),r))
            elif strip_ns(e.tag)=="cluster": walk(e,base+parse_int(text(e,"addressOffset"),0))
    walk(regs); by={text(r,"name"):r for _,r in out}
    for _,r in out:
        d=r.attrib.get("derivedFrom")
        if d in by:
            for c in list(by[d]):
                if strip_ns(c.tag) not in ("name","addressOffset") and child(r,strip_ns(c.tag)) is None: r.append(deepcopy(c))
    return sorted(out,key=lambda x:x[0])
def field_list(reg):
    fs=child(reg,"fields"); out=[]
    for f in children(fs,"field"): out += expand_dim(f)
    return out

def prelude(dev, attrs=True):
    head=[]
    if attrs: head=[f'#![doc = "Peripheral access API for {dev} microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))"]','#![allow(non_camel_case_types)]','#![allow(non_snake_case)]','#![allow(non_upper_case_globals)]','#![no_std]','']
    return "\n".join(head)+r'''
use core::cell::UnsafeCell;
use core::marker::PhantomData;
pub trait RawReg: Copy + From<bool> + core::ops::BitOr<Output=Self> + core::ops::BitAnd<Output=Self> + core::ops::Not<Output=Self> + core::ops::Shl<u8,Output=Self> + core::ops::Shr<u8,Output=Self> + core::ops::Sub<Output=Self> { const ZERO: Self; const ONE: Self; fn mask(width:u8)->Self; }
macro_rules! raw_reg { ($t:ty) => { impl RawReg for $t { const ZERO:Self=0; const ONE:Self=1; fn mask(width:u8)->Self { if width as usize >= core::mem::size_of::<Self>()*8 { !0 } else { ((1 as Self) << width) - 1 } } } }; }
raw_reg!(u8); raw_reg!(u16); raw_reg!(u32); raw_reg!(u64);
pub trait RegisterSpec { type Ux: RawReg; }
pub trait Readable: RegisterSpec {}
pub trait Writable: RegisterSpec { type Safety; const RESET_VALUE: Self::Ux = Self::Ux::ZERO; }
pub trait Resettable: RegisterSpec { const RESET_VALUE: Self::Ux = Self::Ux::ZERO; fn reset_value()->Self::Ux { Self::RESET_VALUE } }
pub struct Safe; pub struct Unsafe;
pub struct Reg<REG:RegisterSpec>{ register:UnsafeCell<REG::Ux>, _marker:PhantomData<REG> }
unsafe impl<REG:RegisterSpec> Sync for Reg<REG>{}
impl<REG:RegisterSpec> Reg<REG>{ pub const fn new(value:REG::Ux)->Self{Self{register:UnsafeCell::new(value),_marker:PhantomData}} pub fn as_ptr(&self)->*mut REG::Ux{self.register.get()} }
impl<REG:Readable> Reg<REG>{ pub fn read(&self)->R<REG>{ R{bits:unsafe{core::ptr::read_volatile(self.register.get())},_reg:PhantomData} } }
impl<REG:Writable> Reg<REG>{ pub fn write<F>(&self,f:F)->REG::Ux where F:FnOnce(&mut W<REG>)->&mut W<REG>{let mut w=W{bits:REG::RESET_VALUE,_reg:PhantomData}; let bits=f(&mut w).bits; unsafe{core::ptr::write_volatile(self.register.get(),bits)}; bits} pub fn write_with_zero<F>(&self,f:F)->REG::Ux where F:FnOnce(&mut W<REG>)->&mut W<REG>{let mut w=W{bits:REG::Ux::ZERO,_reg:PhantomData}; let bits=f(&mut w).bits; unsafe{core::ptr::write_volatile(self.register.get(),bits)}; bits} pub fn reset(&self){unsafe{core::ptr::write_volatile(self.register.get(),REG::RESET_VALUE)}} }
impl<REG:Readable+Writable> Reg<REG>{ pub fn modify<F>(&self,f:F)->REG::Ux where F:for<'a> FnOnce(&'a R<REG>,&'a mut W<REG>)->&'a mut W<REG>{let bits=unsafe{core::ptr::read_volatile(self.register.get())}; let r=R{bits,_reg:PhantomData}; let mut w=W{bits,_reg:PhantomData}; let bits=f(&r,&mut w).bits; unsafe{core::ptr::write_volatile(self.register.get(),bits)}; bits} }
pub struct R<REG:RegisterSpec>{ pub(crate) bits:REG::Ux, _reg:PhantomData<REG> } impl<REG:RegisterSpec> R<REG>{ pub const fn bits(&self)->REG::Ux{self.bits} }
pub struct W<REG:RegisterSpec>{ pub(crate) bits:REG::Ux, _reg:PhantomData<REG> } impl<REG:Writable> W<REG>{ pub unsafe fn bits(&mut self,bits:REG::Ux)->&mut Self{self.bits=bits; self} }
pub struct FieldReader<U=u8>{bits:U} impl<U:Copy> FieldReader<U>{pub const fn new(bits:U)->Self{Self{bits}} pub const fn bits(&self)->U{self.bits}}
pub struct BitReader{bits:bool} impl BitReader{pub const fn new(bits:bool)->Self{Self{bits}} pub const fn bit(&self)->bool{self.bits} pub const fn bit_is_set(&self)->bool{self.bits} pub const fn bit_is_clear(&self)->bool{!self.bits}}
pub struct FieldWriter<'a,REG:Writable,const WI:u8,U=u8>{w:&'a mut W<REG>,o:u8,_u:PhantomData<U>} impl<'a,REG:Writable,const WI:u8,U:Copy> FieldWriter<'a,REG,WI,U> where REG::Ux:From<U>{pub fn new(w:&'a mut W<REG>,o:u8)->Self{Self{w,o,_u:PhantomData}} pub unsafe fn bits(self,value:U)->&'a mut W<REG>{self.w.bits=(self.w.bits & !(REG::Ux::mask(WI)<<self.o)) | ((REG::Ux::from(value)&REG::Ux::mask(WI))<<self.o); self.w}}
pub struct BitWriter<'a,REG:Writable>{w:&'a mut W<REG>,o:u8} impl<'a,REG:Writable> BitWriter<'a,REG>{pub fn new(w:&'a mut W<REG>,o:u8)->Self{Self{w,o}} pub fn bit(self,value:bool)->&'a mut W<REG>{self.w.bits=(self.w.bits & !(REG::Ux::ONE<<self.o)) | ((REG::Ux::from(value)&REG::Ux::ONE)<<self.o); self.w} pub fn set_bit(self)->&'a mut W<REG>{self.bit(true)} pub fn clear_bit(self)->&'a mut W<REG>{self.bit(false)}}
pub trait PeripheralSpec{type RB; const ADDRESS:usize; const NAME:&'static str;} pub struct Periph<PER:PeripheralSpec>{_marker:PhantomData<PER>} impl<PER:PeripheralSpec> Periph<PER>{pub const PTR:*const PER::RB=PER::ADDRESS as *const _; pub const fn ptr()->*const PER::RB{Self::PTR} pub unsafe fn steal()->Self{Self{_marker:PhantomData}}} impl<PER:PeripheralSpec> core::ops::Deref for Periph<PER>{type Target=PER::RB; fn deref(&self)->&Self::Target{unsafe{&*Self::PTR}}}
'''

def generate_lib(root,o):
    dev=text(root,"name","device"); lines=[prelude(dev, not o.skip_crate_attributes and not o.make_mod)]
    periphs=children(child(root,"peripherals"),"peripheral"); by={text(p,"name"):p for p in periphs}
    for p in periphs:
        d=p.attrib.get("derivedFrom")
        if d in by:
            for c in list(by[d]):
                if strip_ns(c.tag)!="name" and child(p,strip_ns(c.tag)) is None: p.append(deepcopy(c))
    intrs=[]
    for pp in periphs:
        for intr in children(pp, "interrupt"):
            intrs.append((text(intr,"name","INTERRUPT"), parse_int(text(intr,"value"),0), text(intr,"description")))
    if intrs:
        lines.append("#[derive(Copy, Clone, Debug, PartialEq, Eq)]")
        lines.append("#[repr(u16)]")
        lines.append("pub enum Interrupt {")
        for nm,val,ds in intrs:
            lines.append(f"    {doc(ds or nm)} {pascal(nm)} = {val},")
        lines.append("}")
    plist=[]; shift=parse_int(o.base_address_shift,0)
    for p in periphs:
        pname=text(p,"name","PERIPH"); pmod=snake(pname); pty=pascal(pname); addr=parse_int(text(p,"baseAddress"),0)+shift; desc=text(p,"description",pname); plist.append((pname,pmod,pty,addr,desc))
        lines += [f"pub mod {pmod} {{", "    use super::*;", "    #[repr(C)]", "    pub struct RegisterBlock {"]
        regs=collect_registers(p); cursor=0; pad=0
        for off,r in regs:
            if off>cursor: lines.append(f"        _reserved{pad}: [u8; {off-cursor}],"); pad+=1; cursor=off
            lines.append(f"        pub {snake(text(r,'name','REG'))}: {pascal(text(r,'name','REG'))},")
            cursor=off+max(1,parse_int(text(r,"size",text(root,"width","32")),32)//8)
        lines += ["    }", "    impl RegisterBlock {"]
        for off,r in regs:
            rn=text(r,'name','REG'); rt=pascal(rn); lines += [f"        {doc(hex(off)+' - '+text(r,'description'))}", f"        pub const fn {snake(rn)}(&self)->&{rt}{{&self.{snake(rn)}}}"]
        lines.append("    }")
        for off,r in regs:
            rn=text(r,'name','REG'); rmod=snake(rn); rt=pascal(rn); spec=rt+'Spec'; ux=reg_uint(text(r,"size",text(root,"width","32"))); desc=text(r,"description"); a,rd,wr=access_kind(r)
            lines += [f"    {doc(rn+' register accessor'+(': '+desc if desc else ''))}", f"    #[doc(alias = \"{rn}\")] pub type {rt} = crate::Reg<{rmod}::{spec}>;", f"    pub mod {rmod} {{", "        use super::*;"]
            if rd: lines.append(f"        pub type R = crate::R<{spec}>;")
            if wr: lines.append(f"        pub type W = crate::W<{spec}>;")
            fs=field_list(r)
            for f in fs:
                fn=text(f,"name","FIELD"); fd=text(f,"description"); lo,wid=bit_info(f); fr=pascal(fn)+'R'; fw=pascal(fn)+'W'
                if wid==1:
                    lines.append(f"        {doc('Field `'+fn+'` reader'+(' - '+fd if fd else ''))} pub type {fr}=crate::BitReader;")
                    if wr: lines.append(f"        {doc('Field `'+fn+'` writer'+(' - '+fd if fd else ''))} pub type {fw}<'a>=crate::BitWriter<'a,{spec}>;")
                else:
                    fut=reg_uint(str(wid)); lines.append(f"        {doc('Field `'+fn+'` reader'+(' - '+fd if fd else ''))} pub type {fr}=crate::FieldReader<{fut}>;")
                    if wr: lines.append(f"        {doc('Field `'+fn+'` writer'+(' - '+fd if fd else ''))} pub type {fw}<'a>=crate::FieldWriter<'a,{spec},{wid},{fut}>;")
            if rd and fs:
                lines.append("        impl R {")
                for f in fs:
                    fn=text(f,"name","FIELD"); fd=text(f,"description"); lo,wid=bit_info(f); mask=(1<<wid)-1 if wid<64 else (1<<64)-1
                    if wid==1: lines += [f"            {doc('Bit '+str(lo)+(' - '+fd if fd else ''))}", f"            pub fn {snake(fn)}(&self)->{pascal(fn)}R{{{pascal(fn)}R::new(((self.bits >> {lo}) & 1) != 0)}}"]
                    else:
                        fut=reg_uint(str(wid)); cast=f" as {fut}" if fut!=ux else ""; lines += [f"            {doc('Bits '+str(lo)+':'+str(lo+wid-1)+(' - '+fd if fd else ''))}", f"            pub fn {snake(fn)}(&self)->{pascal(fn)}R{{{pascal(fn)}R::new(((self.bits >> {lo}) & {mask}){cast})}}"]
                lines.append("        }")
            if wr and fs:
                lines.append("        impl W {")
                for f in fs:
                    fn=text(f,"name","FIELD"); fd=text(f,"description"); lo,wid=bit_info(f); lines += [f"            {doc(('Bit '+str(lo) if wid==1 else 'Bits '+str(lo)+':'+str(lo+wid-1))+(' - '+fd if fd else ''))}", f"            pub fn {snake(fn)}(&mut self)->{pascal(fn)}W<'_>{{{pascal(fn)}W::new(self,{lo})}}"]
                lines.append("        }")
            reset=parse_int(text(r,"resetValue"),0)
            lines += [f"        {doc((desc or rn)+' Register specification')}", f"        pub struct {spec};", f"        impl crate::RegisterSpec for {spec} {{ type Ux = {ux}; }}"]
            if rd: lines.append(f"        impl crate::Readable for {spec} {{ }}")
            if wr: lines.append(f"        impl crate::Writable for {spec} {{ type Safety = crate::Unsafe; const RESET_VALUE: Self::Ux = {hex(reset)}; }}")
            lines += [f"        impl crate::Resettable for {spec} {{ const RESET_VALUE: Self::Ux = {hex(reset)}; }}", "    }"]
        lines += ["}", f"pub struct {pty}Spec;", f"impl PeripheralSpec for {pty}Spec {{ type RB={pmod}::RegisterBlock; const ADDRESS:usize=0x{addr:x}; const NAME:&'static str=\"{pname}\"; }}", f"pub type {pty}=Periph<{pty}Spec>;", ""]
    lines.append("pub struct Peripherals {")
    for pn,pm,pt,ad,de in plist: lines.append(f"    {doc(de)} pub {pm}: {pt},")
    lines += ["}", "impl Peripherals { pub unsafe fn steal()->Self{ Self {"]
    for pn,pm,pt,ad,de in plist: lines.append(f"    {pm}: {pt}::steal(),")
    lines += ["} } }"]
    return "\n".join(lines)+"\n"

def device_x(root):
    out=[]
    for p in children(child(root,"peripherals"),"peripheral"):
        for intr in children(p,"interrupt"):
            n=const_name(text(intr,"name","INTERRUPT")); out.append(f"PROVIDE({n} = DefaultHandler);")
    return "\n".join(out)+("\n" if out else "")

def parse_args(argv):
    if "--version" in argv or "-V" in argv: print(VERSION); sys.exit(0)
    if "--help" in argv: print(HELP_LONG,end=""); sys.exit(0)
    if "-h" in argv: print(HELP_SHORT,end=""); sys.exit(0)
    p=argparse.ArgumentParser(add_help=False,prog="executable")
    for flags in [("-i",),("-c","--config"),("--settings",),("--edition",),("--target",),("--atomics-feature",),("-f","--ident-format"),("--ident-formats-theme",),("--impl-debug-feature",),("--impl-defmt",),("--source-type",),("-b","--base-address-shift"),("-l","--log")]: p.add_argument(*flags)
    p.add_argument("-o","--output-dir",default=".")
    p.add_argument("--atomics", action="store_true")
    p.add_argument("--ignore-groups", action="store_true")
    p.add_argument("--keep-list", action="store_true")
    p.add_argument("-g", "--generic-mod", dest="generic_mod", action="store_true")
    p.add_argument("--feature-group", action="store_true")
    p.add_argument("--feature-peripheral", action="store_true")
    p.add_argument("--field-names-for-enums", action="store_true")
    p.add_argument("--max-cluster-size", action="store_true")
    p.add_argument("--impl-debug", action="store_true")
    p.add_argument("-m", "--make-mod", dest="make_mod", action="store_true")
    p.add_argument("--skip-crate-attributes", action="store_true")
    p.add_argument("-s", "--strict", dest="strict", action="store_true")
    p.add_argument("--reexport-core-peripherals", action="store_true")
    p.add_argument("--reexport-interrupt", action="store_true")
    p.add_argument("input_svd", nargs="?")
    p.set_defaults(base_address_shift="0")
    try: return p.parse_args(argv)
    except SystemExit: sys.exit(2)

def main(argv):
    o=parse_args(argv)
    inpath = o.i or getattr(o, "input_svd", None)
    try: data=open(inpath,"rb").read() if inpath else sys.stdin.buffer.read()
    except OSError as e:
        print("[ERROR svd2rust] Cannot open the SVD file\n    \n    Caused by:\n        "+str(e),file=sys.stderr); return 1
    print("[INFO  svd2rust] Parsing device from SVD file",file=sys.stderr)
    try: root=ET.fromstring(data)
    except Exception as e:
        print("[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        "+str(e),file=sys.stderr); return 1
    print("[INFO  svd2rust] Rendering device",file=sys.stderr)
    os.makedirs(o.output_dir,exist_ok=True); lib="mod.rs" if o.make_mod else "lib.rs"
    open(os.path.join(o.output_dir,lib),"w").write(generate_lib(root,o))
    open(os.path.join(o.output_dir,"device.x"),"w").write(device_x(root))
    open(os.path.join(o.output_dir,"build.rs"),"w").write('fn main(){println!("cargo:rerun-if-changed=build.rs");}\n')
    return 0
if __name__=="__main__": sys.exit(main(sys.argv[1:]))
