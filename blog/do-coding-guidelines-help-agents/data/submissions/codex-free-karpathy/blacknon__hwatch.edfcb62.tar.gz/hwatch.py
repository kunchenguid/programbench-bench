#!/usr/bin/env python3
import json
import os
import shlex
import signal
import subprocess
import sys
import time
from datetime import datetime


HELP = """A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: executable [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use `t` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version
"""


FLAGS = {
    "-b": "batch", "--batch": "batch",
    "-B": "beep", "--beep": "beep",
    "--border": "border", "--with-scrollbar": "scrollbar", "--mouse": "mouse",
    "-c": "color", "--color": "color",
    "-r": "reverse", "--reverse": "reverse",
    "-C": "compress", "--compress": "compress",
    "-t": "no_title", "--no-title": "no_title",
    "--enable-summary-char": "summary_char",
    "-N": "line_number", "--line-number": "line_number",
    "--no-help-banner": "no_help_banner", "--no-summary": "no_summary",
    "-x": "exec", "--exec": "exec",
    "-O": "diff_output_only", "--diff-output-only": "diff_output_only",
    "--precise": "precise",
}


def die(msg, code=2):
    sys.stderr.write(msg + "\n\nFor more information, try '--help'.\n")
    raise SystemExit(code)


def default_opts():
    return {
        "batch": False, "reverse": False, "line_number": False, "exec": False,
        "interval": 2.0, "output": "output", "differences": "none",
        "logfile": None, "aftercommand": None, "shell": "sh -c",
        "command": [],
    }


def parse_args(argv):
    opts = default_opts()
    env = os.environ.get("HWATCH")
    if env:
        argv = shlex.split(env) + argv
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print("hwatch 0.3.19")
            raise SystemExit(0)
        if a in FLAGS:
            opts[FLAGS[a]] = True
            i += 1
            continue
        if a in ("-n", "--interval"):
            i += 1
            if i >= len(argv):
                die("error: a value is required for '--interval <interval>'")
            val = argv[i].replace(",", ".")
            try:
                opts["interval"] = max(float(val), 0.001)
            except ValueError:
                die(f"error: invalid value '{argv[i]}' for '--interval <interval>': invalid float literal")
            i += 1
            continue
        if a in ("-o", "--output"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                val = argv[i + 1]
                i += 2
            else:
                val = "output"
                i += 1
            if val not in ("output", "stdout", "stderr"):
                die(f"error: invalid value '{val}' for '--output [<output>]'\n  [possible values: output, stdout, stderr]")
            opts["output"] = val
            continue
        if a in ("-d", "--differences"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                val = argv[i + 1]
                i += 2
            else:
                val = "watch"
                i += 1
            if val not in ("none", "watch", "line", "word"):
                die(f"error: invalid value '{val}' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]")
            opts["differences"] = val
            continue
        if a in ("-l", "--logfile"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                opts["logfile"] = argv[i + 1]
                i += 2
            else:
                opts["logfile"] = "hwatch.log"
                i += 1
            continue
        if a in ("-A", "--aftercommand", "-s", "--shell", "-L", "--limit", "--tab-size", "-K", "--keymap"):
            i += 1
            if i >= len(argv):
                die(f"error: a value is required for '{a}'")
            if a in ("-A", "--aftercommand"):
                opts["aftercommand"] = argv[i]
            elif a in ("-s", "--shell"):
                opts["shell"] = argv[i]
            i += 1
            continue
        opts["command"] = argv[i:]
        break
    return opts


def now_string():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def header(ts):
    return f"\033[38;5;240m=====[{ts}]=========================\033[0m"


def make_shell_command(opts):
    cmd = " ".join(opts["command"])
    shell_spec = opts["shell"]
    if "{COMMAND}" in shell_spec:
        return shell_spec.replace("{COMMAND}", cmd)
    parts = shlex.split(shell_spec)
    if len(parts) >= 2 and parts[-1] == "-c":
        return parts + [cmd]
    return parts + [cmd]


def run_once(opts):
    if not opts["command"]:
        return True, "", "", ""
    try:
        if opts["exec"]:
            proc = subprocess.run(opts["command"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        else:
            proc = subprocess.run(make_shell_command(opts), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        out = proc.stdout
        err = proc.stderr
        combined = err + out
        return proc.returncode == 0, out, err, combined
    except FileNotFoundError as e:
        return False, "", str(e) + "\n", str(e) + "\n"


def select_output(opts, stdout, stderr, output):
    if opts["output"] == "stdout":
        return stdout
    if opts["output"] == "stderr":
        return stderr
    return output


def transform(opts, text):
    lines = text.split("\n")
    if opts["reverse"]:
        lines = list(reversed(lines))
    if opts["line_number"]:
        width = len(str(max(len(lines), 1)))
        lines = [f"\033[38;5;240m{str(i + 1).rjust(width)}\033[0m\033[38;5;240m | \033[0m{line}" for i, line in enumerate(lines)]
    return "\n".join(lines)


def write_log_record(path, record):
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")


def batch(opts):
    log_path = opts["logfile"]
    if log_path and not os.path.exists(log_path):
        write_log_record(log_path, {"timestamp": "", "command": "", "status": True, "output": "", "stdout": "", "stderr": ""})
    prev = None
    prev_record = None
    first = True
    while True:
        start = time.monotonic()
        ts = now_string()
        status, stdout_s, stderr_s, output_s = run_once(opts)
        selected = select_output(opts, stdout_s, stderr_s, output_s)
        sys.stdout.write(header(ts) + "\n")
        sys.stdout.write(transform(opts, selected) + "\n")
        sys.stdout.flush()
        record = {
            "timestamp": ts, "command": " ".join(opts["command"]), "status": status,
            "output": output_s, "stdout": stdout_s, "stderr": stderr_s,
        }
        if log_path and prev is not None and selected != prev and prev_record is not None:
            write_log_record(log_path, prev_record)
        if opts["aftercommand"] and prev is not None and selected != prev:
            env = os.environ.copy()
            env["HWATCH_DATA"] = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
            subprocess.run(opts["aftercommand"], shell=True, env=env)
        prev = selected
        prev_record = record
        first = False
        elapsed = time.monotonic() - start
        time.sleep(max(opts["interval"] - elapsed, 0.0))


def main():
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    opts = parse_args(sys.argv[1:])
    if opts["batch"]:
        batch(opts)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
