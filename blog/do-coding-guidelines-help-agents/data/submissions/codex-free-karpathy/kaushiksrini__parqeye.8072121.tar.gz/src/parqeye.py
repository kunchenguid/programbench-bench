#!/usr/bin/env python3
import os
import struct
import sys


VERSION = "parqeye 0.0.2"
HELP = """Command line tool to visualize parquet files

Usage: executable <PATH>

Arguments:
  <PATH>  Path to the parquet file

Options:
  -h, --help     Print help
  -V, --version  Print version"""

T_STOP = 0
T_BOOLEAN_TRUE = 1
T_BOOLEAN_FALSE = 2
T_BYTE = 3
T_I16 = 4
T_I32 = 5
T_I64 = 6
T_DOUBLE = 7
T_BINARY = 8
T_LIST = 9
T_SET = 10
T_MAP = 11
T_STRUCT = 12

PHYSICAL = {
    0: "BOOLEAN",
    1: "INT32",
    2: "INT64",
    3: "INT96",
    4: "FLOAT",
    5: "DOUBLE",
    6: "BYTE_ARRAY",
    7: "FIXED_LEN_BYTE_ARRAY",
}
REPETITION = {0: "REQUIRED", 1: "OPTIONAL", 2: "REPEATED"}
CONVERTED = {
    0: "UTF8",
    1: "MAP",
    2: "MAP_KEY_VALUE",
    3: "LIST",
    4: "ENUM",
    5: "DECIMAL",
    6: "DATE",
    7: "TIME_MILLIS",
    8: "TIME_MICROS",
    9: "TIMESTAMP_MILLIS",
    10: "TIMESTAMP_MICROS",
    11: "UINT_8",
    12: "UINT_16",
    13: "UINT_32",
    14: "UINT_64",
    15: "INT_8",
    16: "INT_16",
    17: "INT_32",
    18: "INT_64",
    19: "JSON",
    20: "BSON",
    21: "INTERVAL",
}
CODEC = {
    0: "UNCOMPRESSED",
    1: "SNAPPY",
    2: "GZIP",
    3: "LZO",
    4: "BROTLI",
    5: "LZ4",
    6: "ZSTD",
    7: "LZ4_RAW",
}
ENCODING = {
    0: "PLAIN",
    1: "PLAIN_DICTIONARY",
    2: "RLE",
    3: "BIT_PACKED",
    4: "DELTA_BINARY_PACKED",
    5: "DELTA_LENGTH_BYTE_ARRAY",
    6: "DELTA_BYTE_ARRAY",
    7: "RLE_DICTIONARY",
    8: "BYTE_STREAM_SPLIT",
}


class CompactReader:
    def __init__(self, data):
        self.data = data
        self.i = 0
        self.stack = [0]
        self.bool_field = None

    def read_byte(self):
        if self.i >= len(self.data):
            raise EOFError("unexpected end of thrift data")
        b = self.data[self.i]
        self.i += 1
        return b

    def read_varint(self):
        shift = 0
        out = 0
        while True:
            b = self.read_byte()
            out |= (b & 0x7f) << shift
            if not (b & 0x80):
                return out
            shift += 7

    def read_zigzag(self):
        n = self.read_varint()
        return (n >> 1) ^ -(n & 1)

    def read_binary(self):
        n = self.read_varint()
        b = self.data[self.i : self.i + n]
        self.i += n
        return b

    def read_string(self):
        return self.read_binary().decode("utf-8", "replace")

    def read_field_begin(self):
        b = self.read_byte()
        if b == T_STOP:
            return T_STOP, 0
        typ = b & 0x0F
        delta = b >> 4
        if delta:
            fid = self.stack[-1] + delta
        else:
            fid = self.read_zigzag()
        self.stack[-1] = fid
        if typ in (T_BOOLEAN_TRUE, T_BOOLEAN_FALSE):
            self.bool_field = typ
            typ = T_BYTE
        return typ, fid

    def read_struct(self, parser=None):
        self.stack.append(0)
        out = {} if parser is None else parser(self)
        if parser is None:
            while True:
                typ, fid = self.read_field_begin()
                if typ == T_STOP:
                    break
                out[fid] = self.read_value(typ)
        self.stack.pop()
        return out

    def read_list_header(self):
        b = self.read_byte()
        size = b >> 4
        typ = b & 0x0F
        if size == 15:
            size = self.read_varint()
        return typ, size

    def read_value(self, typ):
        if typ == T_BOOLEAN_TRUE:
            return True
        if typ == T_BOOLEAN_FALSE:
            return False
        if typ == T_BYTE:
            if self.bool_field:
                v = self.bool_field == T_BOOLEAN_TRUE
                self.bool_field = None
                return v
            return self.read_zigzag()
        if typ in (T_I16, T_I32, T_I64):
            return self.read_zigzag()
        if typ == T_DOUBLE:
            b = self.data[self.i : self.i + 8]
            self.i += 8
            return struct.unpack("<d", b)[0]
        if typ == T_BINARY:
            return self.read_string()
        if typ in (T_LIST, T_SET):
            et, n = self.read_list_header()
            return [self.read_value(et) for _ in range(n)]
        if typ == T_MAP:
            n = self.read_varint()
            if not n:
                return {}
            ktvt = self.read_byte()
            kt, vt = ktvt >> 4, ktvt & 0x0F
            return {self.read_value(kt): self.read_value(vt) for _ in range(n)}
        if typ == T_STRUCT:
            return self.read_struct()
        return None

    def skip(self, typ):
        self.read_value(typ)


def parse_metadata(path):
    with open(path, "rb") as f:
        f.seek(0, os.SEEK_END)
        size = f.tell()
        if size < 8:
            raise ValueError("not a parquet file: file too small")
        f.seek(size - 8)
        footer_len = struct.unpack("<I", f.read(4))[0]
        magic = f.read(4)
        if magic != b"PAR1":
            raise ValueError("not a parquet file: missing PAR1 footer")
        start = size - 8 - footer_len
        if start < 4:
            raise ValueError("not a parquet file: invalid footer length")
        f.seek(start)
        footer = f.read(footer_len)
    r = CompactReader(footer)
    meta = {"schema": [], "row_groups": []}
    r.stack.append(0)
    while True:
        typ, fid = r.read_field_begin()
        if typ == T_STOP:
            break
        if fid == 1:
            meta["version"] = r.read_value(typ)
        elif fid == 2 and typ == T_LIST:
            et, n = r.read_list_header()
            meta["schema"] = [read_schema_element(r) for _ in range(n)]
        elif fid == 3:
            meta["num_rows"] = r.read_value(typ)
        elif fid == 4 and typ == T_LIST:
            et, n = r.read_list_header()
            meta["row_groups"] = [read_row_group(r) for _ in range(n)]
        elif fid == 5:
            meta["kv"] = r.read_value(typ)
        elif fid == 6:
            meta["created_by"] = r.read_value(typ)
        else:
            r.skip(typ)
    r.stack.pop()
    meta["columns"] = flatten_schema(meta["schema"])
    return meta


def read_schema_element(r):
    out = {}
    r.stack.append(0)
    while True:
        typ, fid = r.read_field_begin()
        if typ == T_STOP:
            break
        if fid == 1:
            out["type"] = r.read_value(typ)
        elif fid == 2:
            out["type_length"] = r.read_value(typ)
        elif fid == 3:
            out["rep"] = r.read_value(typ)
        elif fid == 4:
            out["name"] = r.read_value(typ)
        elif fid == 5:
            out["children"] = r.read_value(typ)
        elif fid == 6:
            out["converted"] = r.read_value(typ)
        elif fid == 7:
            out["scale"] = r.read_value(typ)
        elif fid == 8:
            out["precision"] = r.read_value(typ)
        else:
            r.skip(typ)
    r.stack.pop()
    return out


def read_row_group(r):
    out = {"columns": []}
    r.stack.append(0)
    while True:
        typ, fid = r.read_field_begin()
        if typ == T_STOP:
            break
        if fid == 1 and typ == T_LIST:
            et, n = r.read_list_header()
            out["columns"] = [read_column_chunk(r) for _ in range(n)]
        elif fid == 2:
            out["total_byte_size"] = r.read_value(typ)
        elif fid == 3:
            out["num_rows"] = r.read_value(typ)
        elif fid == 5:
            out["file_offset"] = r.read_value(typ)
        elif fid == 6:
            out["total_compressed_size"] = r.read_value(typ)
        elif fid == 7:
            out["ordinal"] = r.read_value(typ)
        else:
            r.skip(typ)
    r.stack.pop()
    return out


def read_column_chunk(r):
    out = {}
    r.stack.append(0)
    while True:
        typ, fid = r.read_field_begin()
        if typ == T_STOP:
            break
        if fid == 1:
            out["file_path"] = r.read_value(typ)
        elif fid == 2:
            out["file_offset"] = r.read_value(typ)
        elif fid == 3 and typ == T_STRUCT:
            out["meta"] = read_column_meta(r)
        else:
            r.skip(typ)
    r.stack.pop()
    return out


def read_column_meta(r):
    out = {}
    r.stack.append(0)
    while True:
        typ, fid = r.read_field_begin()
        if typ == T_STOP:
            break
        if fid == 1:
            out["type"] = r.read_value(typ)
        elif fid == 2:
            out["encodings"] = r.read_value(typ)
        elif fid == 3:
            out["path"] = r.read_value(typ)
        elif fid == 4:
            out["codec"] = r.read_value(typ)
        elif fid == 5:
            out["num_values"] = r.read_value(typ)
        elif fid == 6:
            out["uncompressed"] = r.read_value(typ)
        elif fid == 7:
            out["compressed"] = r.read_value(typ)
        elif fid == 9:
            out["data_page_offset"] = r.read_value(typ)
        elif fid == 10:
            out["index_page_offset"] = r.read_value(typ)
        elif fid == 11:
            out["dict_page_offset"] = r.read_value(typ)
        else:
            r.skip(typ)
    r.stack.pop()
    return out


def flatten_schema(schema):
    if not schema:
        return []
    cols = []

    def walk(idx, prefix, depth):
        el = schema[idx]
        name = el.get("name", "")
        children = el.get("children", 0) or 0
        cur = prefix + ([name] if depth else [])
        idx += 1
        if children:
            for _ in range(children):
                idx = walk(idx, cur, depth + 1)
        else:
            cols.append((cur, el))
        return idx

    walk(0, [], 0)
    return cols


def type_name(el):
    base = PHYSICAL.get(el.get("type"), "GROUP" if "type" not in el else str(el.get("type")))
    conv = CONVERTED.get(el.get("converted"))
    if base == "FIXED_LEN_BYTE_ARRAY" and el.get("type_length"):
        base += f"({el['type_length']})"
    if el.get("precision") is not None:
        base += f" precision={el.get('precision')}"
    if el.get("scale") is not None:
        base += f" scale={el.get('scale')}"
    return f"{base} ({conv})" if conv else base


def print_table(rows, widths):
    for row in rows:
        parts = []
        for value, width in zip(row, widths):
            s = str(value)
            if len(s) > width:
                s = s[: max(0, width - 1)] + "…"
            parts.append(s.ljust(width))
        print("  ".join(parts).rstrip())


def render(path, meta):
    print("parqeye")
    print(f"File: {path}")
    print("Tabs: Visualize | Metadata | Schema | Row Groups")
    print()
    print("Metadata")
    print(f"  Version: {meta.get('version', '')}")
    print(f"  Rows: {meta.get('num_rows', 0)}")
    print(f"  Columns: {len(meta.get('columns', []))}")
    print(f"  Row groups: {len(meta.get('row_groups', []))}")
    if meta.get("created_by"):
        print(f"  Created by: {meta['created_by']}")
    print()
    print("Schema")
    rows = [("#", "Name", "Repetition", "Type")]
    for i, (path_parts, el) in enumerate(meta.get("columns", []), 1):
        rows.append((i, ".".join(path_parts), REPETITION.get(el.get("rep"), ""), type_name(el)))
    print_table(rows, (4, 32, 10, 32))
    print()
    print("Row Groups")
    rg_rows = [("#", "Rows", "Total bytes", "Compressed", "Columns")]
    for i, rg in enumerate(meta.get("row_groups", []), 1):
        compressed = rg.get("total_compressed_size")
        if compressed is None:
            compressed = sum((c.get("meta") or {}).get("compressed", 0) for c in rg.get("columns", []))
        rg_rows.append((i, rg.get("num_rows", ""), rg.get("total_byte_size", ""), compressed, len(rg.get("columns", []))))
    print_table(rg_rows, (4, 12, 14, 14, 8))
    print()
    print("Visualize")
    headers = ["#"] + [".".join(c[0]) for c in meta.get("columns", [])[:6]]
    print_table([headers], [4] + [18] * (len(headers) - 1))
    shown = min(int(meta.get("num_rows", 0) or 0), 10)
    for i in range(shown):
        print_table([[i + 1] + ["…" for _ in headers[1:]]], [4] + [18] * (len(headers) - 1))
    if not shown:
        print("(no rows)")


def cli_error(message, tip=None):
    print(f"error: {message}", file=sys.stderr)
    print(file=sys.stderr)
    if tip:
        print(f"  tip: {tip}", file=sys.stderr)
        print(file=sys.stderr)
    print("Usage: executable <PATH>", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)


def main(argv):
    if len(argv) == 2 and argv[1] in ("-h", "--help"):
        print(HELP)
        return 0
    if len(argv) == 2 and argv[1] in ("-V", "--version"):
        print(VERSION)
        return 0
    if len(argv) == 1:
        cli_error("the following required arguments were not provided:\n  <PATH>")
        return 2
    if len(argv) > 2 or argv[1].startswith("-"):
        bad = argv[1] if len(argv) > 1 else ""
        cli_error(f"unexpected argument '{bad}' found", f"to pass '{bad}' as a value, use '-- {bad}'")
        return 2
    path = argv[1]
    try:
        meta = parse_metadata(path)
        render(path, meta)
        return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
