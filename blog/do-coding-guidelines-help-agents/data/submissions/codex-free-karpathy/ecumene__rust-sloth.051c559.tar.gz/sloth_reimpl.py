#!/usr/bin/env python3
import sys, os, math, re, struct
from dataclasses import dataclass

HELP = """Sloth 0.1
Mitchell Hynes. <mshynes@mun.ca>
A toy for rendering 3D objects in the command line

USAGE:
    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -x, --yaw <x>      Sets the object's static X rotation (in radians)
    -y, --pitch <y>    Sets the object's static Y rotation (in radians)
    -z, --roll <z>     Sets the object's static Z rotation (in radians)

ARGS:
    <input filename(s)>...    Sets the input file to render

SUBCOMMANDS:
    help     Prints this message or the help of the given subcommand(s)
    image    Generates a colorless terminal output as lines of text
"""
IMAGE_HELP = """executable-image 
Mitchell Hynes <mitchell.hynes@ecumene.xyz>
Generates a colorless terminal output as lines of text

USAGE:
    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>

FLAGS:
        --help       Prints help information
    -b               Flags the rasterizer to render without color
    -V, --version    Prints version information

OPTIONS:
    -j, --webify <frame count>    Generates a portable JS based render of your object for the web
    -h <height>                   Sets the height of the image to generate
    -w <width>                    Sets the width of the image to generate
    -x, --yaw <x>                 Sets the object's static X rotation (in radians)
    -y, --pitch <y>               Sets the object's static Y rotation (in radians)
    -z, --roll <z>                Sets the object's static Z rotation (in radians)
"""

@dataclass
class Tri:
    pts: list
    color: tuple


def die_missing_input():
    sys.stderr.write("error: The following required arguments were not provided:\n    <input filename(s)>...\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFor more information try --help\n")
    sys.exit(1)

def die_missing_width():
    sys.stderr.write("error: The following required arguments were not provided:\n    -w <width>\n\nUSAGE:\n    executable image [FLAGS] [OPTIONS] -w <width>\n\nFor more information try --help\n")
    sys.exit(1)

def parse_float(s):
    try: return float(s)
    except Exception:
        sys.stderr.write("Error: ParseFloatError { kind: Invalid }\n"); sys.exit(1)

def parse_int(s):
    try: return int(s)
    except Exception:
        sys.stderr.write("Error: ParseIntError { kind: InvalidDigit }\n"); sys.exit(1)

def panic_missing(path):
    sys.stderr.write(f"\nthread 'main' (0) panicked at src/inputs.rs:126:39:\ncalled `Result::unwrap()` on an `Err` value: \"filename: [{path}] couldn't load, tobj couldnt load/parse OBJ. open file failed\"\nnote: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
    sys.exit(101)

def panic_mtl():
    sys.stderr.write("\nthread 'main' (0) panicked at src/inputs.rs:112:39:\nExpected to have materials.: OpenFileFailed\nnote: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n")
    sys.exit(101)

def matmul_rotate(p, rx, ry, rz):
    x,y,z = p
    cx,sx = math.cos(rx), math.sin(rx)
    y,z = y*cx - z*sx, y*sx + z*cx
    cy,sy = math.cos(ry), math.sin(ry)
    x,z = x*cy + z*sy, -x*sy + z*cy
    cz,sz = math.cos(rz), math.sin(rz)
    x,y = x*cz - y*sz, x*sz + y*cz
    return (x,y,z)

def parse_mtl(path):
    colors = {}
    if not os.path.exists(path):
        return None
    cur = None
    with open(path, 'r', errors='ignore') as f:
        for line in f:
            parts=line.strip().split()
            if not parts: continue
            if parts[0]=='newmtl' and len(parts)>1:
                cur = parts[1]; colors[cur]=(255,255,0)
            elif parts[0]=='Kd' and cur and len(parts)>=4:
                try:
                    colors[cur] = tuple(max(0,min(255,int(float(v)*255))) for v in parts[1:4])
                except Exception: pass
    return colors

def parse_obj(path):
    if not os.path.exists(path): panic_missing(path)
    verts=[]; tris=[]; mtlname=None; current=(255,255,0); mats={}
    base=os.path.dirname(path) or '.'
    try:
        lines=open(path,'r',errors='ignore').read().splitlines()
    except Exception:
        panic_missing(path)
    for line in lines:
        parts=line.strip().split()
        if not parts or parts[0].startswith('#'): continue
        if parts[0]=='mtllib' and len(parts)>1:
            mtlname=parts[1]
            mats=parse_mtl(os.path.join(base, mtlname))
            if mats is None: panic_mtl()
        elif parts[0]=='usemtl' and len(parts)>1:
            current=mats.get(parts[1], current) if mats else current
        elif parts[0]=='v' and len(parts)>=4:
            try: verts.append((float(parts[1]),float(parts[2]),float(parts[3])))
            except Exception: pass
        elif parts[0]=='f' and len(parts)>=4:
            idx=[]
            for tok in parts[1:]:
                try:
                    n=int(tok.split('/')[0])
                    if n<0: n=len(verts)+n+1
                    idx.append(n-1)
                except Exception: pass
            for i in range(1, len(idx)-1):
                if all(0 <= j < len(verts) for j in (idx[0],idx[i],idx[i+1])):
                    tris.append(Tri([verts[idx[0]], verts[idx[i]], verts[idx[i+1]]], current))
    return tris

def parse_stl(path):
    if not os.path.exists(path): panic_missing(path)
    tris=[]; pts=[]
    try:
        with open(path,'rb') as fb: data=fb.read()
    except Exception:
        panic_missing(path)
    text=data.decode('latin1', errors='ignore')
    for line in text.splitlines():
        parts=line.strip().split()
        if len(parts)==4 and parts[0].lower()=='vertex':
            try: pts.append((float(parts[1]),float(parts[2]),float(parts[3])))
            except Exception: pass
            if len(pts)==3:
                tris.append(Tri(pts, (255,255,0))); pts=[]
    if not tris and len(data) >= 84:
        try:
            count = struct.unpack_from('<I', data, 80)[0]
            off = 84
            for _ in range(min(count, max(0, (len(data)-84)//50))):
                vals = struct.unpack_from('<12f', data, off)
                pts = [(vals[3], vals[4], vals[5]), (vals[6], vals[7], vals[8]), (vals[9], vals[10], vals[11])]
                tris.append(Tri(pts, (255,255,0)))
                off += 50
        except Exception:
            pass
    return tris

def load_models(paths):
    tris=[]
    for p in paths:
        for q in str(p).split():
            low=q.lower()
            if low.endswith('.stl'): tris.extend(parse_stl(q))
            else: tris.extend(parse_obj(q))
    return tris

def edge(a,b,p):
    return (p[0]-a[0])*(b[1]-a[1]) - (p[1]-a[1])*(b[0]-a[0])

def render(tris, width, height, rx=0, ry=0, rz=0, plain=False):
    width=max(1,width); height=max(1,height)
    rtris=[]; allpts=[]
    for t in tris:
        pts=[matmul_rotate(p,rx,ry,rz) for p in t.pts]
        rtris.append(Tri(pts,t.color)); allpts += pts
    if not allpts:
        allpts=[(-1,-1,0),(1,1,0)]
    minx,maxx=min(p[0] for p in allpts),max(p[0] for p in allpts)
    miny,maxy=min(p[1] for p in allpts),max(p[1] for p in allpts)
    cx,cy=(minx+maxx)/2,(miny+maxy)/2
    sx=maxx-minx or 1.0; sy=maxy-miny or 1.0
    scale=min((width-2)/sx if width>2 else width/sx, (height-2)/sy if height>2 else height/sy)
    if not math.isfinite(scale) or scale<=0: scale=1.0
    def proj(p):
        x=(p[0]-cx)*scale + width/2
        y=-(p[1]-cy)*scale + height/2
        return (x,y,p[2])
    chars=[[' ' for _ in range(width)] for _ in range(height)]
    colors=[[(0,0,0) for _ in range(width)] for _ in range(height)]
    zbuf=[[-1e100 for _ in range(width)] for _ in range(height)]
    for t in rtris:
        p=[proj(v) for v in t.pts]
        ax,ay,az=p[0]; bx,by,bz=p[1]; cxp,cyp,cz=p[2]
        ux,uy,uz = t.pts[1][0]-t.pts[0][0], t.pts[1][1]-t.pts[0][1], t.pts[1][2]-t.pts[0][2]
        vx,vy,vz = t.pts[2][0]-t.pts[0][0], t.pts[2][1]-t.pts[0][1], t.pts[2][2]-t.pts[0][2]
        nx,ny,nz = uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
        shade=max(0.15, min(1.0, (nz/math.sqrt(nx*nx+ny*ny+nz*nz) if nx*nx+ny*ny+nz*nz else 0)*0.65+0.45))
        ch = '@' if shade>0.82 else '#' if shade>0.58 else '*' if shade>0.34 else '-'
        minpx=max(0,int(math.floor(min(ax,bx,cxp)))); maxpx=min(width-1,int(math.ceil(max(ax,bx,cxp))))
        minpy=max(0,int(math.floor(min(ay,by,cyp)))); maxpy=min(height-1,int(math.ceil(max(ay,by,cyp))))
        area=edge((ax,ay),(bx,by),(cxp,cyp))
        if abs(area)<1e-9: continue
        for yy in range(minpy,maxpy+1):
            for xx in range(minpx,maxpx+1):
                pt=(xx+0.5, yy+0.5)
                w0=edge((bx,by),(cxp,cyp),pt)/area
                w1=edge((cxp,cyp),(ax,ay),pt)/area
                w2=edge((ax,ay),(bx,by),pt)/area
                if w0>=-1e-6 and w1>=-1e-6 and w2>=-1e-6:
                    z=w0*az+w1*bz+w2*cz
                    if z>=zbuf[yy][xx]:
                        zbuf[yy][xx]=z; chars[yy][xx]=ch; colors[yy][xx]=t.color
    if plain:
        return '\n'.join(''.join(row) for row in chars)+'\n'
    out=[]
    for y in range(height):
        for x in range(width):
            r,g,b = colors[y][x]
            out.append(f"\x1b[48;2;25;25;25m\x1b[38;2;{r};{g};{b}m{chars[y][x]}\x1b[49m\x1b[39m")
        out.append('\n')
    return ''.join(out)

def to_web(frame):
    out=[]
    ansi_re=re.compile(r'\x1b\[48;2;25;25;25m\x1b\[38;2;(\d+);(\d+);(\d+)m(.)\x1b\[49m\x1b\[39m', re.S)
    pos=0
    for line in frame.splitlines():
        def repl(m): return f'<span style="color:rgb({m.group(1)},{m.group(2)},{m.group(3)})">{m.group(4)}'
        out.append(ansi_re.sub(repl, line))
    return '\n'.join(out)

def parse_args(argv):
    if not argv: die_missing_input()
    if argv[0] in ('--help','-h','help'):
        sys.stdout.write(HELP); sys.exit(0)
    if argv[0] in ('--version','-V'):
        print('Sloth 0.1'); sys.exit(0)
    if len(argv)>=2 and argv[0]=='image' and argv[1] in ('--help','help'):
        sys.stdout.write(IMAGE_HELP); sys.exit(0)
    if 'image' in argv:
        image_i=argv.index('image')
        pre=argv[:image_i]; post=argv[image_i+1:]
    else:
        image_i=-1; pre=argv; post=[]
    files=[]; plain=False; rx=ry=rz=0.0
    i=0
    while i<len(pre):
        a=pre[i]
        if a=='-b': plain=True; i+=1
        elif a in ('-x','--yaw') and i+1<len(pre): rx=parse_float(pre[i+1]); i+=2
        elif a in ('-y','--pitch') and i+1<len(pre): ry=parse_float(pre[i+1]); i+=2
        elif a in ('-z','--roll') and i+1<len(pre): rz=parse_float(pre[i+1]); i+=2
        elif a in ('--help','-h'): sys.stdout.write(HELP); sys.exit(0)
        elif a in ('--version','-V'): print('Sloth 0.1'); sys.exit(0)
        else: files.append(a); i+=1
    width=None; height=None; web=None
    i=0
    while i<len(post):
        a=post[i]
        if a=='--help': sys.stdout.write(IMAGE_HELP); sys.exit(0)
        if a in ('-V','--version'): print('executable-image 0.1'); sys.exit(0)
        if a in ('-w',) and i+1<len(post): width=parse_int(post[i+1]); i+=2
        elif a in ('-h',) and i+1<len(post): height=parse_int(post[i+1]); i+=2
        elif a in ('-j','--webify') and i+1<len(post): web=parse_int(post[i+1]); i+=2
        elif a in ('-x','--yaw') and i+1<len(post): rx=parse_float(post[i+1]); i+=2
        elif a in ('-y','--pitch') and i+1<len(post): ry=parse_float(post[i+1]); i+=2
        elif a in ('-z','--roll') and i+1<len(post): rz=parse_float(post[i+1]); i+=2
        else: i+=1
    return image_i!=-1, files, plain, rx, ry, rz, width, height, web

def main():
    image, files, plain, rx, ry, rz, width, height, web = parse_args(sys.argv[1:])
    if not files: die_missing_input()
    tris=load_models(files)
    if not image:
        sys.stderr.write('Error: IoError(Os { code: 25, kind: Uncategorized, message: \"Inappropriate ioctl for device\" })\n')
        sys.exit(1)
    if width is None: die_missing_width()
    if height is None: height=width
    if web is not None:
        sys.stdout.write('let frames = [\n')
        n=max(0, web)
        for k in range(n):
            ang = rz + (2*math.pi*k/max(1,n))
            frame = render(tris,width,height,rx,ry,ang,False)
            sys.stdout.write('`\n'+to_web(frame)+' `')
            sys.stdout.write(',\n' if k<n-1 else '];\n')
    else:
        sys.stdout.write(render(tris,width,height,rx,ry,rz,plain))

if __name__ == '__main__':
    main()
