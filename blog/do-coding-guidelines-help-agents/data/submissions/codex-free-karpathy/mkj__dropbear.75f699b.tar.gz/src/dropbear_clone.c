#define _GNU_SOURCE

#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <netdb.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define VERSION "2025.89"
#define MAX_PORTS 10
#define MAX_KEYS 32

static volatile sig_atomic_t stop_requested = 0;

static void on_signal(int sig) {
    (void)sig;
    stop_requested = 1;
}

static void vlogmsg(const char *fmt, va_list ap) {
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    char tbuf[64];
    strftime(tbuf, sizeof(tbuf), "%b %e %H:%M:%S", &tmv);
    fprintf(stderr, "[%ld] %s ", (long)getpid(), tbuf);
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
}

static void logmsg(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vlogmsg(fmt, ap);
    va_end(ap);
}

static void logmsg_pid(pid_t pid, const char *fmt, ...) {
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    char tbuf[64];
    strftime(tbuf, sizeof(tbuf), "%b %e %H:%M:%S", &tmv);
    fprintf(stderr, "[%ld] %s ", (long)pid, tbuf);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
}

static void early_exit(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    char tbuf[64];
    strftime(tbuf, sizeof(tbuf), "%b %e %H:%M:%S", &tmv);
    fprintf(stderr, "[%ld] %s Early exit: ", (long)getpid(), tbuf);
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
    exit(1);
}

static void usage(const char *argv0) {
    printf("Dropbear server v%s https://matt.ucc.asn.au/dropbear/dropbear.html\n", VERSION);
    printf("Usage: %s [options]\n", argv0);
    printf("-b bannerfile\tDisplay the contents of bannerfile before user login\n");
    printf("\t\t(default: none)\n");
    printf("-r keyfile      Specify hostkeys (repeatable)\n");
    printf("\t\tdefaults: \n");
    printf("\t\t- rsa /etc/dropbear/dropbear_rsa_host_key\n");
    printf("\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key\n");
    printf("\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key\n");
    printf("-D\t\tDirectory containing authorized_keys file\n");
    printf("-R\t\tCreate hostkeys as required\n");
    printf("-F\t\tDon't fork into background\n");
    printf("-e\t\tPass on server process environment to child process\n");
    printf("(Syslog support not compiled in, using stderr)\n");
    printf("-m\t\tDon't display the motd on login\n");
    printf("-w\t\tDisallow root logins\n");
    printf("-G\t\tRestrict logins to members of specified group\n");
    printf("-s\t\tDisable password logins\n");
    printf("-g\t\tDisable password logins for root\n");
    printf("-B\t\tAllow blank password logins\n");
    printf("-t\t\tEnable two-factor authentication (both password and public key required)\n");
    printf("-T\t\tMaximum authentication tries (default 10)\n");
    printf("-j\t\tDisable local port forwarding\n");
    printf("-k\t\tDisable remote port forwarding\n");
    printf("-a\t\tAllow connections to forwarded ports from any host\n");
    printf("-c command\tForce executed command\n");
    printf("-p [address:]port\n");
    printf("\t\tListen on specified tcp port (and optionally address),\n");
    printf("\t\tup to 10 can be specified\n");
    printf("\t\t(default port is 22 if none specified)\n");
    printf("-P PidFile\tCreate pid file PidFile\n");
    printf("\t\t(default /var/run/dropbear.pid)\n");
    printf("-l <interface>\n");
    printf("\t\tinterface to bind on\n");
    printf("-i\t\tStart for inetd\n");
    printf("-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)\n");
    printf("-K <keepalive>  (0 is never, default 0, in seconds)\n");
    printf("-I <idle_timeout>  (0 is never, default 0, in seconds)\n");
    printf("-z    disable QoS\n");
    printf("-V    Version\n");
}

static bool is_number(const char *s) {
    if (!s || !*s) return false;
    for (; *s; s++) {
        if (!isdigit((unsigned char)*s)) return false;
    }
    return true;
}

static int file_readable_nonempty(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && S_ISREG(st.st_mode) && st.st_size > 0 && access(path, R_OK) == 0;
}

static int listen_one(const char *spec) {
    char host[256] = "";
    char service[64] = "";
    const char *port = spec;
    const char *colon = strrchr(spec, ':');
    if (colon) {
        size_t hlen = (size_t)(colon - spec);
        if (hlen >= sizeof(host)) hlen = sizeof(host) - 1;
        memcpy(host, spec, hlen);
        host[hlen] = '\0';
        port = colon + 1;
    }
    snprintf(service, sizeof(service), "%s", *port ? port : "22");

    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    struct addrinfo *res = NULL;
    int gai = getaddrinfo(host[0] ? host : NULL, service, &hints, &res);
    if (gai != 0) {
        logmsg("Failed listening on '%s': Error resolving: %s", service, gai_strerror(gai));
        return -1;
    }

    int fd = -1;
    for (struct addrinfo *ai = res; ai; ai = ai->ai_next) {
        fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) continue;
        int yes = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
        if (bind(fd, ai->ai_addr, ai->ai_addrlen) == 0 && listen(fd, 64) == 0) {
            break;
        }
        close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    if (fd < 0) {
        logmsg("Failed listening on '%s': %s", service, strerror(errno));
    }
    return fd;
}

static void serve_loop(int *fds, int nfds) {
    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    signal(SIGHUP, on_signal);
    while (!stop_requested) {
        fd_set rd;
        FD_ZERO(&rd);
        int maxfd = -1;
        for (int i = 0; i < nfds; i++) {
            FD_SET(fds[i], &rd);
            if (fds[i] > maxfd) maxfd = fds[i];
        }
        int r = select(maxfd + 1, &rd, NULL, NULL, NULL);
        if (r < 0) {
            if (errno == EINTR) continue;
            break;
        }
        for (int i = 0; i < nfds; i++) {
            if (FD_ISSET(fds[i], &rd)) {
                int c = accept(fds[i], NULL, NULL);
                if (c >= 0) {
                    const char banner[] = "SSH-2.0-dropbear_" VERSION "\r\n";
                    ssize_t ignored = write(c, banner, sizeof(banner) - 1);
                    (void)ignored;
                    close(c);
                }
            }
        }
    }
    early_exit("Terminated by signal");
}

int main(int argc, char **argv) {
    bool foreground = false, create_keys = false, inetd = false;
    const char *pidfile = "/var/run/dropbear.pid";
    const char *ports[MAX_PORTS];
    int nports = 0;
    const char *keys[MAX_KEYS];
    int nkeys = 0;

    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (strcmp(a, "-V") == 0) {
            printf("Dropbear v%s\n", VERSION);
            return 0;
        } else if (strcmp(a, "-h") == 0) {
            usage(argv[0]);
            return 0;
        } else if (a[0] != '-') {
            early_exit("Invalid argument: %s", a);
        } else if (strcmp(a, "-R") == 0) {
            create_keys = true;
        } else if (strcmp(a, "-F") == 0) {
            foreground = true;
        } else if (strcmp(a, "-i") == 0) {
            inetd = true;
        } else if (strcmp(a, "-e") == 0 || strcmp(a, "-m") == 0 || strcmp(a, "-w") == 0 ||
                   strcmp(a, "-s") == 0 || strcmp(a, "-g") == 0 || strcmp(a, "-B") == 0 ||
                   strcmp(a, "-t") == 0 || strcmp(a, "-j") == 0 || strcmp(a, "-k") == 0 ||
                   strcmp(a, "-a") == 0 || strcmp(a, "-z") == 0) {
            continue;
        } else if (strcmp(a, "-b") == 0 || strcmp(a, "-r") == 0 || strcmp(a, "-D") == 0 ||
                   strcmp(a, "-G") == 0 || strcmp(a, "-c") == 0 || strcmp(a, "-p") == 0 ||
                   strcmp(a, "-P") == 0 || strcmp(a, "-l") == 0 || strcmp(a, "-T") == 0 ||
                   strcmp(a, "-W") == 0 || strcmp(a, "-K") == 0 || strcmp(a, "-I") == 0) {
            if (i + 1 >= argc) early_exit("Missing argument");
            const char *v = argv[++i];
            if (strcmp(a, "-b") == 0) {
                if (access(v, R_OK) != 0) logmsg("Error opening banner file '%s'", v);
            } else if (strcmp(a, "-r") == 0) {
                if (nkeys < MAX_KEYS) keys[nkeys++] = v;
            } else if (strcmp(a, "-G") == 0) {
                if (!getgrnam(v)) early_exit("Cannot restrict logins to group '%s' as the group does not exist", v);
            } else if (strcmp(a, "-c") == 0) {
                logmsg("Forced command set to '%s'", v);
            } else if (strcmp(a, "-p") == 0) {
                if (nports < MAX_PORTS) ports[nports++] = v;
            } else if (strcmp(a, "-P") == 0) {
                pidfile = v;
            } else if (strcmp(a, "-l") == 0) {
                logmsg("Binding to interface '%s'", v);
            } else if (strcmp(a, "-T") == 0) {
                if (!is_number(v)) early_exit("Bad maxauthtries '%s'", v);
            } else if (strcmp(a, "-K") == 0) {
                if (!is_number(v)) early_exit("Bad keepalive '%s'", v);
            } else if (strcmp(a, "-I") == 0) {
                if (!is_number(v)) early_exit("Bad idle_timeout '%s'", v);
            }
        } else {
            if (strncmp(a, "--", 2) == 0) {
                fprintf(stderr, "Invalid option --\n");
            } else {
                fprintf(stderr, "Invalid option %s\n", a);
            }
            usage(argv[0]);
            return 1;
        }
    }

    if (nkeys == 0 && !create_keys) {
        const char *defaults[] = {
            "/etc/dropbear/dropbear_rsa_host_key",
            "/etc/dropbear/dropbear_ecdsa_host_key",
            "/etc/dropbear/dropbear_ed25519_host_key",
        };
        for (size_t i = 0; i < sizeof(defaults) / sizeof(defaults[0]); i++) {
            logmsg("Failed loading %s", defaults[i]);
        }
        early_exit("No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
    }
    if (!create_keys) {
        int good = 0;
        for (int i = 0; i < nkeys; i++) {
            if (file_readable_nonempty(keys[i])) {
                good++;
            } else {
                logmsg("Failed loading %s", keys[i]);
            }
        }
        if (!good) early_exit("No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
    }

    if (inetd) {
        const char banner[] = "SSH-2.0-dropbear_" VERSION "\r\n";
        ssize_t ignored = write(STDOUT_FILENO, banner, sizeof(banner) - 1);
        (void)ignored;
        return 0;
    }

    if (nports == 0) ports[nports++] = "22";
    int fds[MAX_PORTS];
    int nfds = 0;
    for (int i = 0; i < nports; i++) {
        int fd = listen_one(ports[i]);
        if (fd >= 0) fds[nfds++] = fd;
    }
    if (nfds == 0) early_exit("No listening ports available.");

    if (!foreground) {
        pid_t pid = fork();
        if (pid < 0) early_exit("fork: %s", strerror(errno));
        if (pid > 0) {
            FILE *pf = fopen(pidfile, "w");
            if (pf) {
                fprintf(pf, "%ld\n", (long)pid);
                fclose(pf);
            }
            logmsg_pid(pid, "Running in background");
            return 0;
        }
        setsid();
    } else {
        logmsg("Not backgrounding");
    }

    serve_loop(fds, nfds);
    return 0;
}
