#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys

VERSION = "0.1.8"
VERSION_LONG = "solar 0.1.8-dev (8f228ae 2026-04-17T19:59:51.519973035Z)"

EVM_VALUES = [
    "homestead", "tangerineWhistle", "spuriousDragon", "byzantium",
    "constantinople", "petersburg", "istanbul", "berlin", "london",
    "paris", "shanghai", "cancun", "prague", "osaka",
]

HELP_LONG = """Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Files to compile, or import remappings.
          
          `-` specifies standard input.
          
          Import remappings are specified as `[context:]prefix=path`. See <https://docs.soliditylang.org/en/latest/path-resolution.html#import-remapping>.

Options:
  -j, --threads <THREADS>
          Number of threads to use. Zero specifies the number of logical cores
          
          [default: 4]
          [aliases: --jobs]

      --evm-version <EVM_VERSION>
          EVM version
          
          [default: prague]
          [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]

      --stop-after <STOP_AFTER>
          Stop execution after the given compiler stage
          
          [possible values: parsing, lowering, analysis]

      --out-dir <OUT_DIR>
          Directory to write output files

      --emit <EMIT>
          Comma separated list of types of output for the compiler to emit
          
          [possible values: abi, hashes]

  -Z <FLAG>
          Unstable flags. WARNING: these are completely unstable, and may change at any time.
          
          See `-Zhelp` for more details.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Input options:
      --base-path <BASE_PATH>
          Use the given path as the root of the source tree

  -I, --include-path <INCLUDE_PATH>
          Directory to search for files.
          
          Can be used multiple times.

      --allow-paths <ALLOW_PATHS>
          Allow a given path for imports

Display options:
      --color <COLOR>
          Coloring
          
          [default: auto]
          [possible values: auto, always, never]

  -v, --verbose
          Use verbose output

      --pretty-json
          Pretty-print JSON output.
          
          Does not include errors. See `--pretty-json-err`.

      --pretty-json-err
          Pretty-print error JSON output

      --error-format <ERROR_FORMAT>
          How errors and other messages are produced
          
          [default: human]
          [possible values: human, json, rustc-json]

      --error-format-human <VALUE>
          Human-readable error message style
          
          [default: unicode]
          [possible values: ascii, unicode, short]

      --diagnostic-width <WIDTH>
          Terminal width for error message formatting

      --no-warnings
          Whether to disable warnings
"""

HELP_SHORT = """Blazingly fast Solidity compiler

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Files to compile, or import remappings

Options:
  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]
      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]
      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]
      --out-dir <OUT_DIR>          Directory to write output files
      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]
  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version

Input options:
      --base-path <BASE_PATH>        Use the given path as the root of the source tree
  -I, --include-path <INCLUDE_PATH>  Directory to search for files
      --allow-paths <ALLOW_PATHS>    Allow a given path for imports

Display options:
      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]
  -v, --verbose                      Use verbose output
      --pretty-json                  Pretty-print JSON output
      --pretty-json-err              Pretty-print error JSON output
      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]
      --error-format-human <VALUE>   Human-readable error message style [default: unicode]
      --diagnostic-width <WIDTH>     Terminal width for error message formatting
      --no-warnings                  Whether to disable warnings
"""

ZHELP = """error: List of all unstable flags.
WARNING: these are completely unstable, and may change at any time!

Options:
      -Zui-testing
          Enables UI testing mode

      -Ztrack-diagnostics
          Prints a note for every diagnostic that is emitted with the creation and emission location.
          
          This is enabled by default on debug builds.

      -Zparse-yul
          Enables parsing Yul files for testing

      -Zno-resolve-imports
          Disables import resolution

      -Zdump=<KIND[=PATHS...]>
          Print additional information about the compiler's internal state.
          
          Valid kinds are `ast` and `hir`.

      -Zast-stats
          Print AST stats

      -Zspan-visitor
          Run the span visitor after parsing

      -Zprint-max-storage-sizes
          Print contracts' max storage sizes

      -Ztypeck
          Type check the program. WIP

      -Zhelp
          Print help

Usage: solar [OPTIONS] [INPUT]...

For more information, try '--help'.
"""

def strip_comments(s):
    s = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
    return re.sub(r"//.*", "", s)

def find_matching(s, start, op="{", cl="}"):
    depth = 0
    for i in range(start, len(s)):
        if s[i] == op:
            depth += 1
        elif s[i] == cl:
            depth -= 1
            if depth == 0:
                return i
    return -1

def split_top(s, sep=","):
    out, cur, par, br = [], [], 0, 0
    for ch in s:
        if ch == "(":
            par += 1
        elif ch == ")":
            par -= 1
        elif ch == "[":
            br += 1
        elif ch == "]":
            br -= 1
        if ch == sep and par == 0 and br == 0:
            part = "".join(cur).strip()
            if part:
                out.append(part)
            cur = []
        else:
            cur.append(ch)
    part = "".join(cur).strip()
    if part:
        out.append(part)
    return out

def split_statements(body):
    res, start, par, br, brace = [], 0, 0, 0, 0
    i = 0
    while i < len(body):
        ch = body[i]
        if ch == "(":
            par += 1
        elif ch == ")":
            par -= 1
        elif ch == "[":
            br += 1
        elif ch == "]":
            br -= 1
        elif ch == "{":
            brace += 1
        elif ch == "}":
            brace -= 1
            if brace == 0 and par == 0 and br == 0:
                res.append(body[start:i+1].strip())
                start = i + 1
        elif ch == ";" and par == 0 and br == 0 and brace == 0:
            res.append(body[start:i+1].strip())
            start = i + 1
        i += 1
    return [x for x in res if x]

def compact_ws(s):
    return re.sub(r"\s+", " ", s.strip())

def canonical_base(t):
    t = compact_ws(t)
    t = re.sub(r"\s*\[\s*([0-9]*)\s*\]", lambda m: "[" + m.group(1) + "]", t)
    t = t.replace("address payable", "address")
    t = re.sub(r"\buint\b", "uint256", t)
    t = re.sub(r"\bint\b", "int256", t)
    t = re.sub(r"\bbyte\b", "bytes1", t)
    return t

def parse_structs(body, cname):
    structs = {}
    for m in re.finditer(r"\bstruct\s+(\w+)\s*\{", body):
        end = find_matching(body, m.end() - 1)
        if end < 0:
            continue
        fields = []
        for st in split_statements(body[m.end():end]):
            line = st.rstrip(";").strip()
            mm = re.match(r"(.+?)\s+(\w+)$", line)
            if mm:
                fields.append((mm.group(2), canonical_base(mm.group(1))))
        structs[m.group(1)] = {"contract": cname, "fields": fields}
    return structs

def parse_type(raw, structs):
    t = compact_ws(raw)
    t = re.sub(r"\b(memory|storage|calldata|payable)\b", "", t).strip()
    t = canonical_base(t)
    suffix = ""
    while True:
        m = re.search(r"(\[[0-9]*\])$", t)
        if not m:
            break
        suffix = m.group(1) + suffix
        t = t[:m.start()].strip()
    if t in structs:
        info = structs[t]
        comps = []
        for n, ft in info["fields"]:
            c = param_obj(n, ft, structs)
            comps.append(c)
        return "tuple" + suffix, "struct " + info["contract"] + "." + t + suffix, comps
    if t.startswith("contract "):
        t = "address"
    return canonical_base(t) + suffix, canonical_base(t) + suffix, None

def param_obj(name, typ, structs, indexed=None):
    abi_t, internal, comps = parse_type(typ, structs)
    obj = {"name": name, "type": abi_t}
    if indexed is not None:
        obj["indexed"] = indexed
    obj["internalType"] = internal
    if comps is not None:
        obj["components"] = comps
    return obj

def parse_param(p, structs, allow_indexed=False):
    p = compact_ws(p)
    indexed = False
    if allow_indexed and re.search(r"\bindexed\b", p):
        indexed = True
        p = re.sub(r"\bindexed\b", "", p).strip()
    p = re.sub(r"\b(memory|storage|calldata|payable)\b", lambda m: " " + m.group(1) + " ", p)
    toks = p.split()
    name = ""
    if len(toks) >= 2 and re.match(r"^[A-Za-z_]\w*$", toks[-1]) and toks[-1] not in ("memory", "storage", "calldata", "payable"):
        name = toks[-1]
        typ = " ".join(toks[:-1])
    else:
        typ = p
    typ = re.sub(r"\b(memory|storage|calldata|payable)\b", "", typ).strip()
    return param_obj(name, typ, structs, indexed if allow_indexed else None)

def parse_params(s, structs, allow_indexed=False):
    if not s.strip():
        return []
    return [parse_param(p, structs, allow_indexed) for p in split_top(s)]

def selector_sig(name, inputs):
    def st(o):
        t = o["type"]
        if t.startswith("tuple"):
            suf = t[5:]
            return "(" + ",".join(st(c) for c in o.get("components", [])) + ")" + suf
        return t
    return name + "(" + ",".join(st(i) for i in inputs) + ")"

def getter_for_var(stmt, structs):
    line = compact_ws(stmt.rstrip(";"))
    if " public " not in " " + line + " ":
        return None
    if re.match(r"^(using|event|error|function|constructor|modifier|struct|enum)\b", line):
        return None
    line = re.sub(r"\s+=\s+.*$", "", line)
    m = re.match(r"(.+?)\s+(\w+)$", line)
    if not m:
        return None
    typ, name = m.group(1), m.group(2)
    typ = re.sub(r"\b(public|private|internal|external|constant|immutable|override)\b", "", typ).strip()
    inputs = []
    out_type = typ
    while True:
        mm = re.match(r"mapping\s*\((.*?)\s*=>\s*(.*)\)$", out_type.strip())
        if not mm:
            break
        inputs.append(param_obj("", mm.group(1).strip(), structs))
        out_type = mm.group(2).strip()
    while re.search(r"\[[0-9]*\]$", out_type.strip()):
        inputs.append(param_obj("", "uint256", structs))
        out_type = re.sub(r"\[[0-9]*\]$", "", out_type.strip()).strip()
    outputs = [param_obj("", out_type, structs)]
    return {"type": "function", "name": name, "inputs": inputs, "outputs": outputs, "stateMutability": "view"}

def state_mut(stmt):
    for s in ("pure", "view", "payable"):
        if re.search(r"\b" + s + r"\b", stmt):
            return s
    return "nonpayable"

def parse_returns(rest, structs):
    m = re.search(r"\breturns\s*\(", rest)
    if not m:
        return []
    start = rest.find("(", m.start())
    end = find_matching(rest, start, "(", ")")
    if end < 0:
        return []
    return parse_params(rest[start+1:end], structs)

def parse_contract_members(body, cname, structs):
    abi = []
    funcs = []
    for st in split_statements(body):
        if re.match(r"^struct\b", st.strip()):
            continue
        m = re.match(r"constructor\s*\((.*?)\)(.*)", st, re.S)
        if m:
            abi.append({"type": "constructor", "inputs": parse_params(m.group(1), structs), "stateMutability": state_mut(m.group(2))})
            continue
        m = re.match(r"error\s+(\w+)\s*\((.*?)\)\s*;", st, re.S)
        if m:
            abi.append({"type": "error", "name": m.group(1), "inputs": parse_params(m.group(2), structs)})
            continue
        m = re.match(r"event\s+(\w+)\s*\((.*?)\)\s*(anonymous)?\s*;", st, re.S)
        if m:
            abi.append({"type": "event", "name": m.group(1), "inputs": parse_params(m.group(2), structs, True), "anonymous": bool(m.group(3))})
            continue
        m = re.match(r"fallback\s*\((.*?)\)(.*)", st, re.S)
        if m:
            abi.append({"type": "fallback", "stateMutability": state_mut(m.group(2))})
            continue
        m = re.match(r"receive\s*\(\s*\)(.*)", st, re.S)
        if m:
            abi.append({"type": "receive", "stateMutability": state_mut(m.group(1))})
            continue
        m = re.match(r"function\s+(\w+)\s*\((.*?)\)(.*)", st, re.S)
        if m:
            rest = m.group(3)
            funcs.append({"type": "function", "name": m.group(1), "inputs": parse_params(m.group(2), structs), "outputs": parse_returns(rest, structs), "stateMutability": state_mut(rest)})
            continue
        g = getter_for_var(st, structs)
        if g:
            funcs.append(g)
    funcs.sort(key=lambda x: x["name"])
    return abi, funcs

def parse_source(path, text):
    text = strip_comments(text)
    contracts = {}
    meta = {}
    for m in re.finditer(r"\b(contract|interface|library)\s+(\w+)([^{]*)\{", text):
        start = m.end() - 1
        end = find_matching(text, start)
        if end < 0:
            continue
        kind, name, head = m.group(1), m.group(2), m.group(3)
        body = text[start+1:end]
        bases = []
        im = re.search(r"\bis\s+(.+)$", head.strip())
        if im:
            bases = [re.split(r"\s*\(", x.strip())[0].strip() for x in split_top(im.group(1)) if x.strip()]
        meta[name] = {"kind": kind, "body": body, "bases": bases, "structs": parse_structs(body, name)}
    all_structs = {}
    for info in meta.values():
        all_structs.update(info["structs"])
    own = {}
    for name, info in meta.items():
        pre, funcs = parse_contract_members(info["body"], name, all_structs)
        own[name] = pre + funcs
    def collect(name, seen=None):
        seen = seen or set()
        if name in seen:
            return []
        seen.add(name)
        info = meta.get(name)
        if not info:
            return []
        inherited = []
        for b in info["bases"]:
            inherited += collect(b, seen)
        by_key = {}
        for item in inherited + own.get(name, []):
            if item.get("type") == "function":
                by_key[("f", item["name"], selector_sig(item["name"], item["inputs"]))] = item
            else:
                by_key[(item.get("type"), item.get("name", ""))] = item
        items = list(by_key.values())
        rank = {"constructor": 0, "error": 1, "event": 2, "fallback": 3, "function": 4, "receive": 5}
        items.sort(key=lambda x: (rank.get(x["type"], 9), x.get("name", "")))
        return items
    for name in sorted(meta):
        contracts[f"{path}:{name}"] = collect(name)
    return contracts

# Keccak-f[1600], enough for Ethereum function selectors.
RC = [0x0000000000000001,0x0000000000008082,0x800000000000808a,0x8000000080008000,0x000000000000808b,0x0000000080000001,0x8000000080008081,0x8000000000008009,0x000000000000008a,0x0000000000000088,0x0000000080008009,0x000000008000000a,0x000000008000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,0x8000000000008002,0x8000000000000080,0x000000000000800a,0x800000008000000a,0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008]
RHO = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]

def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)

def keccak256(data):
    rate = 136
    st = [0] * 25
    for off in range(0, len(data) + 1, rate):
        block = bytearray(data[off:off+rate])
        if len(block) == rate:
            pass
        else:
            zeros = rate - len(block) - 1
            block += b"\x01"
            block += b"\x00" * zeros
            block[-1] |= 0x80
        for i in range(rate // 8):
            st[i] ^= int.from_bytes(block[8*i:8*i+8], "little")
        keccak_f(st)
        if len(block) < rate or off + rate >= len(data) + 1:
            break
    out = b""
    while len(out) < 32:
        for i in range(rate // 8):
            out += st[i].to_bytes(8, "little")
        if len(out) < 32:
            keccak_f(st)
    return out[:32]

def keccak_f(a):
    mask = (1 << 64) - 1
    for rc in RC:
        c = [a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20] for x in range(5)]
        d = [c[(x-1) % 5] ^ rol(c[(x+1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                a[x + 5*y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(a[x + 5*y], RHO[x][y])
        for y in range(5):
            row = [b[x + 5*y] for x in range(5)]
            for x in range(5):
                a[x + 5*y] = (row[x] ^ ((~row[(x+1)%5]) & row[(x+2)%5])) & mask
        a[0] ^= rc

def make_output(sources, emits):
    contracts = {}
    for path, text in sources:
        for key, abi in parse_source(path, text).items():
            entry = {}
            if "abi" in emits:
                entry["abi"] = abi
            if "hashes" in emits:
                hashes = {}
                for item in abi:
                    if item.get("type") == "function":
                        sig = selector_sig(item["name"], item["inputs"])
                        hashes[sig] = keccak256(sig.encode()).hex()[:8]
                entry["hashes"] = dict(sorted(hashes.items()))
            contracts[key] = entry
    return {"contracts": dict(sorted(contracts.items())), "version": VERSION}

def die_invalid(opt, val, values):
    sys.stderr.write(f"error: invalid value '{val}' for '{opt}'\n  [possible values: {', '.join(values)}]\n\nFor more information, try '--help'.\n")
    sys.exit(2)

def main(argv):
    if "--help" in argv:
        print(HELP_LONG, end="")
        return 0
    if "-h" in argv:
        print(HELP_SHORT, end="")
        return 0
    if "--version" in argv or "-V" in argv:
        print(VERSION_LONG)
        return 0
    if "-Zhelp" in argv or ("-Z" in argv and argv[argv.index("-Z")+1:argv.index("-Z")+2] == ["help"]):
        sys.stderr.write(ZHELP)
        return 0
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-j", "--threads", "--jobs")
    p.add_argument("--evm-version", default="prague")
    p.add_argument("--stop-after")
    p.add_argument("--out-dir")
    p.add_argument("--emit")
    p.add_argument("-Z", dest="zflags", action="append")
    p.add_argument("--base-path")
    p.add_argument("-I", "--include-path", action="append")
    p.add_argument("--allow-paths")
    p.add_argument("--color", default="auto")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("--pretty-json", action="store_true")
    p.add_argument("--pretty-json-err", action="store_true")
    p.add_argument("--error-format", default="human")
    p.add_argument("--error-format-human", default="unicode")
    p.add_argument("--diagnostic-width")
    p.add_argument("--no-warnings", action="store_true")
    p.add_argument("inputs", nargs="*")
    ns = p.parse_args(argv)
    if ns.evm_version not in EVM_VALUES:
        die_invalid("--evm-version <EVM_VERSION>", ns.evm_version, EVM_VALUES)
    if ns.stop_after and ns.stop_after not in ("parsing", "lowering", "analysis"):
        die_invalid("--stop-after <STOP_AFTER>", ns.stop_after, ["parsing", "lowering", "analysis"])
    emits = []
    if ns.emit:
        for e in ns.emit.split(","):
            if e not in ("abi", "hashes"):
                die_invalid("--emit <EMIT>", e, ["abi", "hashes"])
            emits.append(e)
    if not emits:
        return 0
    sources = []
    for inp in ns.inputs:
        if "=" in inp and not os.path.exists(inp):
            continue
        if inp == "-":
            sources.append(("<stdin>", sys.stdin.read()))
        else:
            try:
                with open(inp, "r", encoding="utf-8") as f:
                    sources.append((inp, f.read()))
            except OSError as e:
                sys.stderr.write(f"error: failed to read `{inp}`: {e.strerror} (os error {e.errno})\n\nerror: aborting due to 1 previous error\n\n")
                return 1
    obj = make_output(sources, emits)
    data = json.dumps(obj, indent=2 if ns.pretty_json else None, separators=None if ns.pretty_json else (",", ":"))
    if ns.pretty_json:
        data += "\n"
    if ns.out_dir:
        try:
            with open(os.path.join(ns.out_dir, "combined.json"), "w", encoding="utf-8") as f:
                f.write(data)
        except OSError as e:
            sys.stderr.write(f"error: failed to write to output: {e.strerror} (os error {e.errno})\n\nerror: aborting due to 1 previous error\n\n")
            return 1
    else:
        print(data, end="" if data.endswith("\n") else "\n")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
