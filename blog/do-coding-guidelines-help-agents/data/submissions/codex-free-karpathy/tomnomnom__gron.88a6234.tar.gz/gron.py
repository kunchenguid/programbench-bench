#!/usr/bin/env python3
import argparse
import json
import sys


RESERVED = {
    "break", "case", "catch", "class", "const", "continue", "debugger", "default",
    "delete", "do", "else", "export", "extends", "false", "finally", "for",
    "function", "if", "import", "in", "instanceof", "new", "null", "return",
    "super", "switch", "this", "throw", "true", "try", "typeof", "var", "void",
    "while", "with", "yield", "let", "static", "enum", "await", "implements",
    "package", "protected", "interface", "private", "public",
}


def ident_start(ch):
    return ch == "$" or ch == "_" or ch.isalpha()


def ident_part(ch):
    return ident_start(ch) or ch.isdigit()


def is_ident(s):
    return bool(s) and s not in RESERVED and ident_start(s[0]) and all(ident_part(c) for c in s[1:])


def json_dumps(value, indent=None):
    return json.dumps(value, ensure_ascii=False, indent=indent, separators=(",", ": ") if indent else (",", ":"))


def path_text(path):
    out = "json"
    for part in path:
        if isinstance(part, int):
            out += f"[{part}]"
        elif is_ident(part):
            out += "." + part
        else:
            out += "[" + json_dumps(part) + "]"
    return out


def color_value(value):
    text = json_dumps(value)
    if isinstance(value, str):
        return "\033[33m" + text + "\033[0m"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return "\033[31m" + text + "\033[0m"
    if isinstance(value, (dict, list)):
        return "\033[35m" + text + "\033[0m"
    return "\033[36m" + text + "\033[0m"


def path_text_color(path):
    out = "\033[34;1mjson\033[0;22m"
    for part in path:
        if isinstance(part, int):
            out += "\033[35m[\033[0m" + "\033[31m" + str(part) + "\033[0m" + "\033[35m]\033[0m"
        elif is_ident(part):
            out += "." + "\033[34;1m" + part + "\033[0;22m"
        else:
            out += "\033[35m[\033[0m" + "\033[33m" + json_dumps(part) + "\033[0m" + "\033[35m]\033[0m"
    return out


def walk(value, path=(), sort_keys=True):
    yield list(path), value
    if isinstance(value, dict):
        keys = sorted(value.keys()) if sort_keys else value.keys()
        for key in keys:
            yield from walk(value[key], path + (key,), sort_keys)
    elif isinstance(value, list):
        for i, item in enumerate(value):
            yield from walk(item, path + (i,), sort_keys)


def collect(value, no_sort=False):
    items = list(walk(value, sort_keys=not no_sort))
    if no_sort:
        return items
    return sorted(items, key=lambda x: path_text(x[0]))


def forward(value, as_json=False, no_sort=False, color=False):
    lines = []
    for path, val in collect(value, no_sort=no_sort):
        shown = [] if isinstance(val, list) else {} if isinstance(val, dict) else val
        if as_json:
            lines.append(json_dumps([path, shown]))
        elif color:
            lines.append(f"{path_text_color(path)} = {color_value(shown)};")
        else:
            lines.append(f"{path_text(path)} = {json_dumps(shown)};")
    return "\n".join(lines) + ("\n" if lines else "")


def parse_path(s):
    s = s.strip()
    if not s.startswith("json"):
        raise ValueError("expected json")
    i = 4
    path = []
    while i < len(s):
        if s[i] == ".":
            i += 1
            start = i
            if i >= len(s) or not ident_start(s[i]):
                raise ValueError("bad path")
            i += 1
            while i < len(s) and ident_part(s[i]):
                i += 1
            path.append(s[start:i])
        elif s[i] == "[":
            if i + 1 < len(s) and s[i + 1] == '"':
                dec = json.JSONDecoder()
                part, end = dec.raw_decode(s[i + 1 :])
                j = i + 1 + end
                if j >= len(s) or s[j] != "]":
                    raise ValueError("bad path")
                path.append(part)
                i = j + 1
            else:
                j = s.find("]", i)
                if j < 0:
                    raise ValueError("bad path")
                path.append(int(s[i + 1 : j]))
                i = j + 1
        elif s[i].isspace():
            i += 1
        else:
            raise ValueError("bad path")
    return path


def parse_assignment(line):
    line = line.strip()
    if not line:
        return None
    if line.endswith(";"):
        line = line[:-1]
    if "=" not in line:
        return None
    left, right = line.split("=", 1)
    path = parse_path(left.strip())
    value = json.loads(right.strip())
    return path, value


def set_path(root_marker, path, value):
    if not path:
        root_marker[0] = value
        return
    if root_marker[0] is None:
        root_marker[0] = [] if isinstance(path[0], int) else {}
    cur = root_marker[0]
    for idx, part in enumerate(path):
        last = idx == len(path) - 1
        if isinstance(part, int):
            if not isinstance(cur, list):
                return
            while len(cur) <= part:
                cur.append(None)
            if last:
                cur[part] = value
            else:
                nxt_kind = [] if isinstance(path[idx + 1], int) else {}
                if cur[part] is None or not isinstance(cur[part], (dict, list)):
                    cur[part] = nxt_kind
                cur = cur[part]
        else:
            if not isinstance(cur, dict):
                return
            if last:
                cur[part] = value
            else:
                nxt_kind = [] if isinstance(path[idx + 1], int) else {}
                if part not in cur or cur[part] is None or not isinstance(cur[part], (dict, list)):
                    cur[part] = nxt_kind
                cur = cur[part]


def ungron(text, as_json=False):
    root = [None]
    if as_json:
        for line in text.splitlines():
            if not line.strip():
                continue
            path, value = json.loads(line)
            set_path(root, path, value)
    else:
        for line in text.splitlines():
            parsed = parse_assignment(line)
            if parsed is None:
                continue
            set_path(root, parsed[0], parsed[1])
    if root[0] is None:
        root[0] = {}
    return json_dumps(root[0], indent=2) + "\n"


def values_only(text, as_json=False):
    out = []
    if as_json:
        for line in text.splitlines():
            if not line.strip():
                continue
            _path, value = json.loads(line)
            if not isinstance(value, (dict, list)):
                out.append(json_dumps(value))
    else:
        for line in text.splitlines():
            parsed = parse_assignment(line)
            if not parsed:
                continue
            value = parsed[1]
            if not isinstance(value, (dict, list)):
                if isinstance(value, str):
                    out.append(value)
                else:
                    out.append(json_dumps(value))
    return "\n".join(out) + ("\n" if out else "")


def read_input(source):
    if source is None or source == "-":
        return sys.stdin.read()
    if source.startswith("http://") or source.startswith("https://"):
        print(f"failed to fetch URL: Get \"{source}\": network is unavailable", file=sys.stderr)
        sys.exit(4)
    try:
        with open(source, "r", encoding="utf-8") as f:
            return f.read()
    except OSError as e:
        print(f"open {source}: {e.strerror.lower()}", file=sys.stderr)
        sys.exit(1)


def load_json(text):
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        print(f"failed to form statements: {e.msg}", file=sys.stderr)
        sys.exit(3)


def main(argv):
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("-u", "--ungron", action="store_true")
    p.add_argument("-v", "--values", action="store_true")
    p.add_argument("-c", "--colorize", action="store_true")
    p.add_argument("-m", "--monochrome", action="store_true")
    p.add_argument("-s", "--stream", action="store_true")
    p.add_argument("-k", "--insecure", action="store_true")
    p.add_argument("-x", "--proxy")
    p.add_argument("--noproxy")
    p.add_argument("-j", "--json", action="store_true")
    p.add_argument("--no-sort", action="store_true")
    p.add_argument("--version", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("source", nargs="?")
    args, extra = p.parse_known_args(argv)
    if args.help:
        print(HELP)
        return 0
    if args.version:
        print("gron version dev")
        return 0
    if extra:
        print(HELP, file=sys.stderr)
        return 2
    text = read_input(args.source)
    if args.values:
        sys.stdout.write(values_only(text, args.json))
    elif args.ungron:
        try:
            sys.stdout.write(ungron(text, args.json))
        except Exception as e:
            print(f"failed to parse statements: {e}", file=sys.stderr)
            return 5
    else:
        if args.stream:
            vals = []
            for line in text.splitlines():
                if line.strip():
                    vals.append(load_json(line))
            value = vals
        else:
            value = load_json(text)
        try:
            use_color = args.colorize or (not args.monochrome and sys.stdout.isatty())
            sys.stdout.write(forward(value, args.json, args.no_sort, use_color))
        except Exception as e:
            print(f"failed to form statements: {e}", file=sys.stderr)
            return 3
    return 0


HELP = """Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable

Usage:
  gron [OPTIONS] [FILE|URL|-]

Options:
  -u, --ungron     Reverse the operation (turn assignments back into JSON)
  -v, --values     Print just the values of provided assignments
  -c, --colorize   Colorize output (default on tty)
  -m, --monochrome Monochrome (don't colorize output)
  -s, --stream     Treat each line of input as a separate JSON object
  -k, --insecure   Disable certificate validation
  -x, --proxy      Set proxy configuration
      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.
  -j, --json       Represent gron data as JSON stream
      --no-sort    Don't sort output (faster)
      --version    Print version information

Exit Codes:
  0\tOK
  1\tFailed to open file
  2\tFailed to read input
  3\tFailed to form statements
  4\tFailed to fetch URL
  5\tFailed to parse statements
  6\tFailed to encode JSON

Examples:
  gron /tmp/apiresponse.json
  gron http://jsonplaceholder.typicode.com/users/1 
  curl -s http://jsonplaceholder.typicode.com/users/1 | gron
  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron"""


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
