#!/usr/bin/env python3
import os
import re
import sys


HELP = """Shellharden: The corrective bash syntax highlighter.

Usage:
\tshellharden [options] [files]
\tcat files | shellharden [options] ''

Shellharden is a syntax highlighter and a tool to semi-automate the rewriting
of scripts to ShellCheck conformance, mainly focused on quoting.

The default mode of operation is like `cat`, but with syntax highlighting in
foreground colors and suggestive changes in background colors.

Options:
\t--suggest         Output a colored diff suggesting changes.
\t--syntax          Output syntax highlighting with ANSI colors.
\t--syntax-suggest  Diff with syntax highlighting (default mode).
\t--transform       Output suggested changes.
\t--check           No output; exit with 2 if changes are suggested.
\t--replace         Replace file contents with suggested changes.
\t--                Don't treat further arguments as options.
\t-h|--help         Show help text.
\t--version         Show version.

The changes suggested by Shellharden inhibits word splitting and indirect
pathname expansion. This will make your script ShellCheck compliant in terms of
quoting. Whether your script will work afterwards is a different question:
If your script was using those features on purpose, it obviously won't anymore!

Every script is possible to write without using word splitting or indirect
pathname expansion, but it may involve doing things differently.
See the accompanying file how_to_do_things_safely_in_bash.md or online:
https://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md
"""

VAR_START = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
VAR_BODY = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")
SPECIAL_QUOTED = set("@*-_")
SPECIAL_BARE = set("?!#$")


def is_assign_word(word):
    return re.match(r"^[A-Za-z_][A-Za-z0-9_]*(\[[^]]*\])?=", word) is not None


def split_leading_assignments(line):
    i = 0
    while i < len(line) and line[i].isspace():
        i += 1
    while i < len(line):
        start = i
        while i < len(line) and not line[i].isspace() and line[i] not in ";|&()<>":
            i += 1
        word = line[start:i]
        if not word or not is_assign_word(word):
            return start
        while i < len(line) and line[i].isspace():
            i += 1
    return len(line)


def matching_brace(s, start):
    depth = 1
    i = start + 2
    while i < len(s):
        c = s[i]
        if c == "\\":
            i += 2
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def matching_paren(s, start):
    depth = 1
    i = start + 2
    quote = None
    while i < len(s):
        c = s[i]
        if quote:
            if c == "\\" and quote == '"':
                i += 2
                continue
            if c == quote:
                quote = None
            i += 1
            continue
        if c in "'\"":
            quote = c
        elif c == "\\":
            i += 2
            continue
        elif s.startswith("$(", i):
            depth += 1
            i += 1
        elif c == ")":
            depth -= 1
            if depth == 0:
                return i
        i += 1
    return -1


def param_end(s, i):
    if i + 1 >= len(s):
        return i + 1
    c = s[i + 1]
    if c == "{":
        j = matching_brace(s, i)
        return len(s) if j < 0 else j + 1
    if c.isdigit() or c in "@*?-_!#":
        return i + 2
    if c in VAR_START:
        j = i + 2
        while j < len(s) and s[j] in VAR_BODY:
            j += 1
        return j
    return i + 1


def simple_param_name(tok):
    if tok == "$*":
        return "@"
    if tok.startswith("${") and tok.endswith("}"):
        inner = tok[2:-1]
        if inner.endswith("[*]"):
            return inner[:-3] + "[@]"
        return inner
    return None


def quote_param(tok, for_in=False, embedded=False):
    if tok in ("$?", "$!", "$$", "$#"):
        return tok
    if tok == "$*":
        return '"$@"'
    if for_in:
        if tok.startswith("${") and tok.endswith("}"):
            name = tok[2:-1]
        elif len(tok) > 1:
            name = tok[1:]
        else:
            name = ""
        if name and "[" not in name and not any(ch in name for ch in ":-=%#/"):
            return '"${' + name + '[@]}"'
    if tok.startswith("${") and tok.endswith("}"):
        inner = tok[2:-1]
        if inner.startswith("#"):
            return tok
        if inner.endswith("[*]"):
            inner = inner[:-3] + "[@]"
        if not embedded and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", inner):
            return '"$' + inner + '"'
        return '"${' + inner + '}"'
    return '"' + tok + '"'


def transform_segment(s, quote=False, for_in=False, skip_assign_prefix=False):
    out = []
    i = 0
    assign_limit = split_leading_assignments(s) if skip_assign_prefix else 0
    while i < len(s):
        c = s[i]
        if c == "\\":
            out.append(s[i:i + 2])
            i += 2
            continue
        if not quote and c == "'":
            j = s.find("'", i + 1)
            if j < 0:
                out.append(s[i:])
                break
            out.append(s[i:j + 1])
            i = j + 1
            continue
        if not quote and c == '"':
            j, inner = transform_double_quoted(s, i)
            out.append(inner)
            i = j
            continue
        if s.startswith("`", i):
            j = s.find("`", i + 1)
            if j < 0:
                out.append(s[i:])
                break
            inner = transform_text(s[i + 1:j])
            out.append('"$(' + inner + ')"')
            i = j + 1
            continue
        if s.startswith("$(", i):
            if i + 2 < len(s) and s[i + 2] == "(":
                j = s.find("))", i + 3)
                if j < 0:
                    out.append(s[i:])
                    break
                out.append(s[i:j + 2])
                i = j + 2
                continue
            j = matching_paren(s, i)
            if j < 0:
                out.append(s[i:])
                break
            inner = transform_text(s[i + 2:j])
            out.append('"$(' + inner + ')"')
            i = j + 1
            continue
        if c == "$" and i >= assign_limit:
            end = param_end(s, i)
            tok = s[i:end]
            if len(tok) > 1:
                if quote:
                    if tok == "$*":
                        out.append("$@")
                    elif tok.startswith("${") and tok.endswith("}") and tok[2:-1].endswith("[*]"):
                        out.append("${" + tok[2:-4] + "[@]}")
                    else:
                        out.append(tok)
                else:
                    prev_c = s[i - 1] if i > 0 else " "
                    next_c = s[end] if end < len(s) else " "
                    embedded = (prev_c not in " \t\n;|&()<>=:") or (next_c not in " \t\n;|&()<>=:")
                    out.append(quote_param(tok, for_in=for_in, embedded=embedded))
                i = end
                continue
        out.append(c)
        i += 1
    return "".join(out)


def transform_double_quoted(s, i):
    out = ['"']
    i += 1
    while i < len(s):
        c = s[i]
        if c == "\\":
            out.append(s[i:i + 2])
            i += 2
        elif c == '"':
            out.append('"')
            return i + 1, "".join(out)
        elif s.startswith("$(", i):
            j = matching_paren(s, i)
            if j < 0:
                out.append(s[i:])
                return len(s), "".join(out)
            out.append("$(" + transform_text(s[i + 2:j]) + ")")
            i = j + 1
        elif c == "$":
            end = param_end(s, i)
            tok = s[i:end]
            if tok == "$*":
                out.append("$@")
            elif tok.startswith("${") and tok.endswith("}") and tok[2:-1].endswith("[*]"):
                out.append("${" + tok[2:-4] + "[@]}")
            else:
                out.append(tok)
            i = end
        else:
            out.append(c)
            i += 1
    return i, "".join(out)


def protect_comments(line):
    quote = None
    esc = False
    for i, c in enumerate(line):
        if esc:
            esc = False
            continue
        if c == "\\":
            esc = True
            continue
        if quote:
            if c == quote:
                quote = None
            continue
        if c in "'\"":
            quote = c
        elif c == "#" and (i == 0 or line[i - 1].isspace()):
            return line[:i], line[i:]
    return line, ""


def transform_line(line):
    body, comment = protect_comments(line)
    stripped = body.lstrip()
    if stripped.startswith("[[") or stripped.startswith("(("):
        return line
    if re.match(r"^case\b", stripped):
        pos = body.find(")")
        if pos >= 0:
            return body[:pos + 1] + transform_segment(body[pos + 1:], skip_assign_prefix=True) + comment
        return body + comment
    if re.match(r"^select\b", stripped):
        return body + comment
    if re.search(r"(^|[;&|]\s*)for\s+\w+\s+in\s+", body):
        def repl(m):
            return m.group(1) + transform_segment(m.group(2), for_in=True)
        body = re.sub(r"((?:^|[;&|]\s*)for\s+\w+\s+in\s+)(.*?)(?=\s*;|\s+do\b|$)", repl, body)
    if re.match(r"^\s*(export|readonly|local|declare|typeset)\s+", body):
        pieces = re.split(r"(\s+)", body)
        saved = []
        for idx in range(2, len(pieces), 2):
            if is_assign_word(pieces[idx]):
                saved.append(pieces[idx])
                pieces[idx] = f"\0{len(saved) - 1}\0"
        protected = "".join(pieces)
        transformed = transform_segment(protected, skip_assign_prefix=True)
        for idx, value in enumerate(saved):
            transformed = transformed.replace(f"\0{idx}\0", value)
        return transformed + comment
    if stripped.startswith("[ ") or stripped == "[":
        body = re.sub(r"-n\s+(\$[{A-Za-z0-9_@*:-][^ \]\t;]*)", lambda m: transform_segment(m.group(1)) + " != \"\"", body)
    body = re.sub(r"\btest\s+-n\s+(\$[{A-Za-z0-9_@*:-][^ \]\t;]*)", lambda m: "test " + transform_segment(m.group(1)) + " != \"\"", body)
    return transform_segment(body, skip_assign_prefix=True) + comment


def transform_text(text):
    lines = text.splitlines(True)
    out = []
    heredoc = None
    for line in lines:
        nl = ""
        raw = line
        if raw.endswith("\n"):
            nl = "\n"
            raw = raw[:-1]
        if heredoc is not None:
            out.append(raw + nl)
            if raw == heredoc:
                heredoc = None
            continue
        m = re.search(r"<<-?\s*(['\"]?)([A-Za-z_][A-Za-z0-9_]*)\1", raw)
        out.append(transform_line(raw) + nl)
        if m:
            heredoc = m.group(2)
    return "".join(out)


def color_syntax(text):
    esc = "\033["
    reset = "\033[m"
    text = re.sub(r"(^|\n)(#![^\n]*)", lambda m: m.group(1) + esc + "0;1;3;38;2;120;144;96m" + m.group(2) + reset, text)
    text = re.sub(r"(^|\s)(#[^\n]*)", lambda m: m.group(1) + esc + "0;1;3;38;2;120;144;96m" + m.group(2) + reset, text)
    text = re.sub(r"(\$\{[^}]+\}|\$[A-Za-z_][A-Za-z0-9_]*|\$[0-9@*_?-])", esc + r"0;38;2;63;127;207m\1" + reset, text)
    return text


def color_suggest(original):
    changed = transform_text(original)
    if changed == original:
        return original
    return changed


def read_inputs(files):
    if not files:
        return [(None, sys.stdin.read())], 0
    ret = 0
    items = []
    for name in files:
        if name == "":
            items.append((None, sys.stdin.read()))
            continue
        try:
            with open(name, "r", encoding="utf-8", errors="surrogateescape") as f:
                items.append((name, f.read()))
        except OSError as e:
            print(f"{name}: {e.strerror} (os error {e.errno})", file=sys.stderr)
            ret = 1
    return items, ret


def parse_args(argv):
    mode = "syntax-suggest"
    files = []
    end_opts = False
    for arg in argv:
        if not end_opts and arg == "--":
            end_opts = True
        elif not end_opts and arg in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        elif not end_opts and arg == "--version":
            print("4.3.1")
            sys.exit(0)
        elif not end_opts and arg in ("--suggest", "--syntax", "--syntax-suggest", "--transform", "--check", "--replace"):
            mode = arg[2:]
        elif not end_opts and arg.startswith("-"):
            print(f"{arg}: No such option.", file=sys.stderr)
            sys.exit(3)
        else:
            files.append(arg)
    return mode, files


def main(argv):
    mode, files = parse_args(argv)
    inputs, err = read_inputs(files)
    if err:
        return err
    if mode == "replace":
        for name, text in inputs:
            if name is None:
                sys.stdout.write(transform_text(text))
            else:
                with open(name, "w", encoding="utf-8", errors="surrogateescape") as f:
                    f.write(transform_text(text))
        return 0
    outputs = []
    changed = False
    for _, text in inputs:
        trans = transform_text(text)
        changed = changed or (trans != text)
        if mode == "check":
            continue
        if mode == "transform":
            outputs.append(trans)
        elif mode == "syntax":
            outputs.append(color_syntax(text))
        elif mode == "suggest":
            outputs.append(color_suggest(text))
        else:
            outputs.append(color_syntax(color_suggest(text)))
    if mode == "check":
        return 2 if changed else 0
    sys.stdout.write("".join(outputs))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
