#!/usr/bin/env python3
import json
import os
import re
import shutil
import subprocess
import sys
import uuid
from datetime import datetime, timezone
from pathlib import Path

ZERO = "0001-01-01T00:00:00Z"
STATUSES = ("active", "paused", "pending", "resolved", "template")
COMMANDS = [
    "next", "add", "rm", "remove", "template", "log", "start", "note", "notes",
    "stop", "done", "resolve", "context", "modify", "edit", "undo", "sync", "open",
    "git", "show-next", "show-projects", "show-tags", "show-active", "show-paused",
    "show-open", "show-resolved", "show-templates", "show-unorganised",
    "bash-completion", "fish-completion", "zsh-completion", "help", "version",
    "_completions",
]


def repo():
    return Path(os.environ.get("DSTASK_GIT_REPO") or Path.home() / ".dstask")


def now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def init_repo():
    r = repo()
    first = not r.exists()
    r.mkdir(parents=True, exist_ok=True)
    for s in STATUSES:
        (r / s).mkdir(exist_ok=True)
    if not (r / ".git").exists() and shutil.which("git"):
        subprocess.run(["git", "-C", str(r), "init"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if first:
        print("Add a remote repository with:\n\n\tdstask git remote add origin <repo>\n", file=sys.stderr)


def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')


def read_task(path, status):
    d = {"uuid": path.stem, "status": status, "summary": "", "notes": "", "tags": [],
         "project": "", "priority": "P2", "created": ZERO, "resolved": ZERO, "due": ZERO}
    lines = path.read_text(errors="replace").splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("summary: "):
            d["summary"] = unquote(line[9:])
        elif line.startswith("notes: "):
            val = line[7:]
            if val.startswith("|"):
                buf = []
                i += 1
                while i < len(lines) and (lines[i].startswith("  ") or lines[i] == ""):
                    buf.append(lines[i][2:] if lines[i].startswith("  ") else "")
                    i += 1
                d["notes"] = "\n".join(buf).rstrip("\n")
                continue
            d["notes"] = "" if val == '""' else unquote(val)
        elif line == "tags:":
            tags = []
            i += 1
            while i < len(lines) and lines[i].startswith("- "):
                tags.append(unquote(lines[i][2:]))
                i += 1
            d["tags"] = tags
            continue
        elif line.startswith("project: "):
            d["project"] = unquote(line[9:])
        elif line.startswith("priority: "):
            d["priority"] = unquote(line[10:])
        elif line.startswith("created: "):
            d["created"] = line[9:]
        elif line.startswith("resolved: "):
            d["resolved"] = line[10:]
        elif line.startswith("due: "):
            d["due"] = line[5:]
        elif line.startswith("id: "):
            try:
                d["stored_id"] = int(line[4:])
            except ValueError:
                pass
        i += 1
    d["_path"] = path
    return d


def unquote(s):
    s = s.strip()
    if len(s) >= 2 and s[0] == s[-1] == '"':
        return bytes(s[1:-1], "utf-8").decode("unicode_escape")
    return s


def write_task(t):
    old = t.get("_path")
    p = repo() / t["status"] / (t["uuid"] + ".yml")
    p.parent.mkdir(exist_ok=True)
    if old and Path(old) != p and Path(old).exists():
        Path(old).unlink()
    lines = []
    lines.append(f"summary: {t['summary']}")
    notes = t.get("notes", "")
    if "\n" in notes:
        lines.append("notes: |-")
        lines += ["  " + x for x in notes.splitlines()]
    else:
        lines.append(f'notes: "{esc(notes)}"')
    lines.append("tags:")
    for tag in t.get("tags", []):
        lines.append(f"- {tag}")
    lines += [
        f"project: {t.get('project','')}",
        f"priority: {t.get('priority','P2')}",
        'delegatedto: ""',
        "subtasks: []",
        "dependencies: []",
        f"created: {t.get('created', ZERO)}",
        f"resolved: {t.get('resolved', ZERO)}",
        f"due: {t.get('due', ZERO)}",
        f"id: {t.get('stored_id', 0)}",
    ]
    p.write_text("\n".join(lines) + "\n")
    t["_path"] = p


def all_tasks():
    init_repo()
    out = []
    for st in STATUSES:
        for p in sorted((repo() / st).glob("*.yml")):
            out.append(read_task(p, st))
    out.sort(key=lambda x: (prio_rank(x), x.get("created", ZERO)))
    assign_ids(out)
    return out


def assign_ids(tasks):
    nextid = 1
    for t in sorted([x for x in tasks if x["status"] != "resolved"], key=lambda x: x.get("created", ZERO)):
        if not t.get("stored_id"):
            t["stored_id"] = nextid
            write_task(t)
        nextid = max(nextid, t["stored_id"] + 1)
    for t in tasks:
        t["id"] = t.get("stored_id", 0) if t["status"] != "resolved" else 0


def prio_rank(t):
    return {"P0": 0, "P1": 1, "P2": 2, "P3": 3}.get(t.get("priority", "P2"), 2)


def public(t):
    return {k: t.get(k, "" if k in ("summary", "notes", "project") else []) for k in
            ("uuid", "status", "id", "summary", "notes", "tags", "project", "priority", "created", "resolved", "due")}


def jprint(tasks):
    print(json.dumps([public(t) for t in tasks], indent=2), end="")


def parse_attrs(words, for_filter=False):
    attrs = {"tags_add": [], "tags_del": [], "project": None, "priority": None, "due": None, "text": []}
    note = []
    in_note = False
    for w in words:
        if w == "/" and not for_filter:
            in_note = True
            continue
        if in_note:
            note.append(w)
        elif re.fullmatch(r"P[0-3]", w):
            attrs["priority"] = w
        elif w.startswith("+") and len(w) > 1:
            attrs["tags_add"].append(w[1:])
        elif w.startswith("-") and len(w) > 1:
            attrs["tags_del"].append(w[1:])
        elif w.startswith("project:"):
            attrs["project"] = w[8:]
        elif w.startswith("-project:"):
            attrs["project"] = ""
        elif w.startswith("due:"):
            attrs["due"] = w[4:] + ("T00:00:00Z" if re.fullmatch(r"\d{4}-\d{2}-\d{2}", w[4:]) else "")
        else:
            attrs["text"].append(w)
    attrs["note"] = " ".join(note)
    return attrs


def context_words():
    c = os.environ.get("DSTASK_CONTEXT")
    if c is None:
        f = repo() / "context"
        c = f.read_text().strip() if f.exists() else ""
    return [] if c in ("", "none") else c.split()


def apply_context(attrs):
    c = parse_attrs(context_words(), True)
    for tag in c["tags_add"]:
        if tag not in attrs["tags_add"]:
            attrs["tags_add"].append(tag)
    if c["project"] and attrs["project"] is None:
        attrs["project"] = c["project"]


def make_task(words, status="pending", resolved=False):
    template = None
    cleaned = []
    skip = False
    existing = all_tasks()
    for i, w in enumerate(words):
        if skip:
            skip = False
            continue
        tid = None
        if w.startswith("template:"):
            tid = w[9:]
        elif w == "from-template" and i + 1 < len(words):
            tid = words[i + 1]
            skip = True
        if tid and tid.isdigit():
            matches = [t for t in existing if t["status"] == "template" and t.get("id") == int(tid)]
            if matches:
                template = matches[0]
            continue
        cleaned.append(w)
    words = cleaned
    attrs = parse_attrs(words)
    apply_context(attrs)
    summary = " ".join(attrs["text"]).strip() or (template["summary"] if template else "")
    if not summary:
        fail("task description or template required")
    base_tags = list(template["tags"]) if template else []
    base_project = template["project"] if template else ""
    base_priority = template["priority"] if template else "P2"
    base_notes = template["notes"] if template else ""
    tags = []
    for tag in base_tags + attrs["tags_add"]:
        if tag not in tags:
            tags.append(tag)
    t = {"uuid": str(uuid.uuid4()), "status": status, "summary": summary, "notes": attrs["note"],
         "tags": tags, "project": attrs["project"] if attrs["project"] is not None else base_project,
         "priority": attrs["priority"] or base_priority,
         "created": now(), "resolved": now() if resolved else ZERO, "due": attrs["due"] or ZERO}
    if not t["notes"]:
        t["notes"] = base_notes
    ids = [x.get("stored_id", 0) for x in existing if x["status"] != "resolved"]
    t["stored_id"] = (max(ids) + 1) if ids else 1
    write_task(t)
    return t


def fail(msg, code=1):
    print(f"\033[31m{msg}\033[0m", file=sys.stderr)
    sys.exit(code)


def git_commit(msg):
    if not shutil.which("git") or not (repo() / ".git").exists():
        return
    subprocess.run(["git", "-C", str(repo()), "add", "."], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    subprocess.run(["git", "-C", str(repo()), "commit", "-m", msg], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def filter_tasks(tasks, words, include_context=True):
    bypass_context = "--" in words
    words = [w for w in words if w != "--"]
    if include_context and not bypass_context:
        words = context_words() + words
    attrs = parse_attrs(words, True)
    texts = [x.lower() for x in attrs["text"]]
    res = []
    for t in tasks:
        if any(tag not in t["tags"] for tag in attrs["tags_add"]):
            continue
        if any(tag in t["tags"] for tag in attrs["tags_del"]):
            continue
        if attrs["project"] is not None and t["project"] != attrs["project"]:
            continue
        if attrs["priority"] and t["priority"] != attrs["priority"]:
            continue
        hay = (t["summary"] + "\n" + t.get("notes", "")).lower()
        if any(x not in hay for x in texts):
            continue
        res.append(t)
    return sorted(res, key=lambda x: (prio_rank(x), x.get("created", ZERO)))


def by_ids(ids):
    ts = all_tasks()
    got = []
    for i in ids:
        m = [t for t in ts if t.get("id") == i and t["status"] != "resolved"]
        if not m:
            fail(f"no open task with ID {i} exists")
        got.append(m[0])
    return got


def usage():
    print("""Usage: dstask [id...] <cmd> [task summary/filter]

Where [task summary] is text with tags/project/priority specified. Tags are
specified with + (or - for filtering) eg: +work. The project is specified with
a project:g prefix eg: project:dstask -- no quotes. Priorities run from P3
(low), P2 (default) to P1 (high) and P0 (critical). Text can also be specified
for a substring search of description and notes.

Available commands:

next              : Show most important tasks (priority, creation date -- truncated and default)
add               : Add a task
template          : Add a task template
log               : Log a task (already resolved)
start             : Change task status to active
note              : Append to or edit note for a task
stop              : Change task status to pending
done              : Resolve a task
context           : Set global context for task list and new tasks (use "none" to set no context)
modify            : Change task attributes specified on command line
remove            : Remove a task (use to remove tasks added by mistake)
show-projects     : List projects with completion status
show-tags         : List tags in use
show-active       : Show tasks that have been started
show-paused       : Show tasks that have been started then stopped
show-open         : Show all non-resolved tasks (without truncation)
show-resolved     : Show resolved tasks
show-templates    : Show task templates
version           : Show dstask version information""")


def help_cmd(args):
    if args and args[0] == "add":
        print("Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website")
    elif args and args[0] == "context":
        print('Usage: dstask context <filter>\nExample: dstask context +work -bug\nExample: dstask context none')
    else:
        usage()


def main():
    args = sys.argv[1:]
    init_repo()
    if not args:
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] != "resolved" and t["status"] != "template"], []))
    if args[0] == "--help":
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] != "resolved" and t["status"] != "template"], args))
    ids = [int(a) for a in args if a.isdigit()]
    nonids = [a for a in args if not a.isdigit()]
    cmd = next((a for a in nonids if a in COMMANDS), None)
    if cmd is None:
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] != "resolved" and t["status"] != "template"], args))
    rest = nonids[nonids.index(cmd) + 1:]
    if cmd == "help":
        return help_cmd(rest)
    if cmd == "version":
        print("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown"); return
    if cmd == "_completions":
        print("\n".join(COMMANDS[:-1] + ["P0", "P1", "P2", "P3"])); return
    if cmd.endswith("completion"):
        print("# completion script unavailable in this reimplementation"); return
    if cmd == "git":
        sys.exit(subprocess.call(["git", "-C", str(repo())] + rest))
    if cmd == "sync":
        subprocess.call(["git", "-C", str(repo()), "pull"])
        sys.exit(subprocess.call(["git", "-C", str(repo()), "push"]))
    if cmd in ("add", "template", "log"):
        st = "template" if cmd == "template" else ("resolved" if cmd == "log" else "pending")
        t = make_task(rest, st, cmd == "log")
        verb = "Added template" if cmd == "template" else ("Logged" if cmd == "log" else "Added")
        print(f"{verb} {t['stored_id']}: {t['summary']}")
        git_commit(f"{verb} {t['stored_id']}: {t['summary']}")
        return
    if cmd == "start" and not ids:
        t = make_task(rest, "active")
        print(f"Added and started {t['stored_id']}: {t['summary']}")
        git_commit(f"Added and started {t['stored_id']}: {t['summary']}")
        return
    if cmd in ("show-open", "show-next", "next"):
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] != "resolved" and t["status"] != "template"], rest))
    if cmd == "show-active":
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] == "active"], rest))
    if cmd == "show-paused":
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] == "paused"], rest))
    if cmd == "show-resolved":
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] == "resolved"], rest, False))
    if cmd == "show-templates":
        return jprint(filter_tasks([t for t in all_tasks() if t["status"] == "template"], rest, False))
    if cmd == "show-unorganised":
        return jprint([t for t in all_tasks() if t["status"] != "resolved" and not t["tags"] and not t["project"]])
    if cmd == "show-tags":
        print("\n".join(sorted({tag for t in all_tasks() if t["status"] != "resolved" for tag in t["tags"]}))); return
    if cmd == "show-projects":
        projs = []
        for name in sorted({t["project"] for t in all_tasks() if t["project"]}):
            ts = [t for t in all_tasks() if t["project"] == name]
            open_ts = [t for t in ts if t["status"] != "resolved"]
            base = sorted(open_ts or ts, key=lambda x: (prio_rank(x), x["created"]))[0]
            projs.append({"name": name, "taskCount": len(open_ts), "resolvedCount": len([t for t in ts if t["status"] == "resolved"]),
                          "active": any(t["status"] == "active" for t in open_ts), "created": base["created"],
                          "resolved": base["resolved"], "priority": base["priority"]})
        print(json.dumps(projs, indent=2), end=""); return
    if cmd == "context":
        val = " ".join(rest) if rest else " ".join(context_words())
        if val == "none":
            val = ""
        (repo() / "context").write_text(val)
        print(f"\033[33mActive context: {val}\033[0m" if val else "\033[33mNo active context\033[0m"); return
    targets = by_ids(ids) if ids else []
    if cmd in ("done", "resolve", "stop", "note", "notes", "start", "modify", "remove", "rm", "edit", "open"):
        if not targets:
            targets = filter_tasks([t for t in all_tasks() if t["status"] != "resolved"], rest)
        for t in targets:
            if cmd == "start":
                t["status"] = "active"; msg = "Started"
            elif cmd == "stop":
                append_note(t, rest); t["status"] = "paused"; msg = "Stopped"
            elif cmd in ("done", "resolve"):
                append_note(t, rest); t["status"] = "resolved"; t["resolved"] = now(); msg = "Resolved"
            elif cmd in ("note", "notes"):
                append_note(t, rest); msg = "Notes on task"
            elif cmd == "modify":
                modify(t, rest); msg = "Modified"
            elif cmd in ("remove", "rm"):
                Path(t["_path"]).unlink(); print(f"Removed {t['id']}: {t['summary']}"); continue
            elif cmd == "open":
                urls = re.findall(r"https?://\\S+", t["summary"] + "\n" + t.get("notes", ""))
                print("\n".join(urls)); continue
            else:
                msg = "Edited"
            write_task(t)
            print(f"{msg} {t.get('id', t.get('stored_id'))}: {t['summary']}")
            git_commit(f"{msg} {t.get('id', t.get('stored_id'))}: {t['summary']}")
        return
    usage()


def append_note(t, words):
    text = " ".join(words).strip()
    if text:
        t["notes"] = (t.get("notes", "") + ("\n" if t.get("notes") else "") + text)


def modify(t, words):
    attrs = parse_attrs(words, True)
    tags = [x for x in t["tags"] if x not in attrs["tags_del"]]
    for tag in attrs["tags_add"]:
        if tag not in tags:
            tags.append(tag)
    t["tags"] = tags
    if attrs["project"] is not None:
        t["project"] = attrs["project"]
    if attrs["priority"]:
        t["priority"] = attrs["priority"]
    if attrs["due"]:
        t["due"] = attrs["due"]


if __name__ == "__main__":
    main()
