#!/usr/bin/env python3
import os
import shlex
import subprocess
import sys
import tempfile


VERSION = "0.9.28rc"
VERSION_LINE = "tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)"

HELP = """Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
"""

MORE_HELP = """Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
"""

SEARCH_DIRS = """install: /usr/local/lib/tcc
include:
  /usr/local/lib/tcc/include
  /usr/local/include/x86_64-linux-gnu
  /usr/local/include
  /usr/include/x86_64-linux-gnu
  /usr/include
libraries:
  /usr/local/lib/tcc
  /usr/lib/x86_64-linux-gnu
  /usr/lib
  /lib/x86_64-linux-gnu
  /lib
  /usr/local/lib/x86_64-linux-gnu
  /usr/local/lib
libtcc1:
  /usr/local/lib/tcc/libtcc1.a
crt:
  /usr/lib/x86_64-linux-gnu
elfinterp:
  /lib64/ld-linux-x86-64.so.2
"""

TCC_MACROS = [
    "-D__TINYC__=928",
    "-D__TCC_PP__=1",
]


def fail(msg):
    print(f"tcc: error: {msg}", file=sys.stderr)
    return 1


def expand_response_files(args):
    out = []
    for arg in args:
        if arg.startswith("@") and len(arg) > 1:
            with open(arg[1:], "r", encoding="utf-8") as f:
                out.extend(shlex.split(f.read(), comments=True))
        else:
            out.append(arg)
    return out


def obj_name(src):
    if src == "-":
        return "a.o"
    return os.path.splitext(os.path.basename(src))[0] + ".o"


def read_stdin_source():
    data = sys.stdin.buffer.read()
    tmp = tempfile.NamedTemporaryFile(prefix="tcc-stdin-", suffix=".c", delete=False)
    tmp.write(data)
    tmp.close()
    return tmp.name


def strip_shebang(path):
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return path
    if not data.startswith(b"#!"):
        return path
    first = data.find(b"\n")
    body = b"\n" if first < 0 else b"\n" + data[first + 1 :]
    tmp = tempfile.NamedTemporaryFile(prefix="tcc-script-", suffix=".c", delete=False)
    tmp.write(body)
    tmp.close()
    return tmp.name


def run_cmd(cmd, stdin_file=None):
    if stdin_file:
        with open(stdin_file, "rb") as f:
            return subprocess.call(cmd, stdin=f)
    return subprocess.call(cmd)


def gcc_base():
    return ["gcc", "-fno-diagnostics-color", "-fcommon"] + TCC_MACROS


def translate(args):
    opts = []
    inputs = []
    output = None
    compile_only = False
    preprocess = False
    dep_only = False
    run_mode = False
    run_args = []
    rstdin = None
    i = 0
    while i < len(args):
        a = args[i]
        if run_mode:
            run_args = args[i:]
            break
        if a == "--":
            inputs.extend(args[i + 1 :])
            break
        if a == "-run":
            run_mode = True
            i += 1
            if i < len(args):
                inputs.append(args[i])
            i += 1
            continue
        if a == "-rstdin":
            i += 1
            if i >= len(args):
                return None, fail("argument to '-rstdin' is missing")
            rstdin = args[i]
        elif a == "-o":
            i += 1
            if i >= len(args):
                return None, fail("argument to '-o' is missing")
            output = args[i]
        elif a.startswith("-o") and len(a) > 2:
            output = a[2:]
        elif a == "-c":
            compile_only = True
            opts.append("-c")
        elif a == "-E":
            preprocess = True
            opts.append("-E")
        elif a in ("-M", "-MM"):
            dep_only = True
            opts.append(a)
        elif a in ("-MD", "-MMD", "-MF", "-MT", "-MQ"):
            opts.append(a)
            if a in ("-MF", "-MT", "-MQ"):
                i += 1
                if i >= len(args):
                    return None, fail(f"argument to '{a}' is missing")
                opts.append(args[i])
        elif a.startswith(("-MF", "-MT", "-MQ")):
            opts.append(a)
        elif a in ("-include", "-isystem", "-B", "-x", "-soname"):
            i += 1
            if i >= len(args):
                return None, fail(f"argument to '{a}' is missing")
            if a == "-soname":
                opts.append("-Wl,-soname," + args[i])
            elif a == "-x":
                lang = {"c": "c", "a": "assembler", "b": "none", "n": "none"}.get(args[i], args[i])
                opts.extend(["-x", lang])
            else:
                opts.extend([a, args[i]])
        elif a in ("-shared", "-static", "-nostdinc", "-nostdlib", "-pthread", "-g", "-rdynamic", "-r"):
            opts.append(a)
        elif a.startswith("-gdwarf"):
            opts.append("-g")
        elif a == "-b" or a.startswith("-bt"):
            opts.append("-g")
        elif a in ("-w", "-Wall", "-Werror"):
            opts.append(a)
        elif a.startswith(("-I", "-D", "-U", "-L", "-l", "-Wl,", "-Wp,", "-std=", "-m", "-f", "-O")):
            if a.startswith("-Wp,"):
                opts.extend(a[4:].split(","))
            elif a == "-flto":
                pass
            else:
                opts.append(a)
        elif a in ("-bench", "-dt", "-C", "-pipe", "-s", "-traditional", "-pedantic"):
            pass
        elif a == "-P" or a == "-P1" or a == "-dD" or a == "-dM":
            opts.append(a)
        elif a == "-":
            inputs.append(a)
        elif a.startswith("-"):
            return None, fail("no input files")
        else:
            inputs.append(a)
        i += 1

    return {
        "opts": opts,
        "inputs": inputs,
        "output": output,
        "compile_only": compile_only,
        "preprocess": preprocess,
        "dep_only": dep_only,
        "run": run_mode,
        "run_args": run_args,
        "rstdin": rstdin,
    }, 0


def main(argv):
    try:
        args = expand_response_files(argv[1:])
    except OSError as e:
        return fail(str(e))

    if not args:
        print(HELP, end="")
        return 0
    if args == ["-hh"]:
        print(MORE_HELP, end="")
        return 0
    if args in (["-h"], ["--help"]):
        print(HELP, end="")
        return 0
    if args in (["-v"], ["--version"]):
        print(VERSION_LINE)
        return 0
    if args == ["-vv"] or args == ["-print-search-dirs"]:
        print(SEARCH_DIRS, end="")
        return 0
    if args == ["-dumpversion"]:
        print(VERSION)
        return 0
    if args and args[0] == "-ar":
        if len(args) < 3:
            return fail("ar: not enough arguments")
        return subprocess.call(["ar"] + args[1:])

    filtered = []
    for arg in args:
        if arg in ("-v", "--version"):
            print(VERSION_LINE)
        elif arg == "-vv":
            print(SEARCH_DIRS, end="")
        else:
            filtered.append(arg)
    args = filtered

    spec, status = translate(args)
    if status:
        return status
    if not spec["inputs"]:
        return fail("no input files")

    cleanup = []
    inputs = []
    for path in spec["inputs"]:
        if path == "-":
            path = read_stdin_source()
            cleanup.append(path)
        if not os.path.exists(path):
            return fail(f"file '{path}' not found")
        if spec["run"]:
            new_path = strip_shebang(path)
            if new_path != path:
                cleanup.append(new_path)
            path = new_path
        inputs.append(path)

    try:
        if spec["run"]:
            exe = tempfile.NamedTemporaryFile(prefix="tcc-run-", delete=False)
            exe.close()
            cleanup.append(exe.name)
            cmd = gcc_base() + spec["opts"] + inputs[:1] + ["-o", exe.name]
            rc = run_cmd(cmd)
            if rc:
                return rc
            return run_cmd([exe.name] + spec["run_args"], spec["rstdin"])

        cmd = gcc_base() + spec["opts"] + inputs
        if spec["output"]:
            cmd += ["-o", spec["output"]]
        elif spec["compile_only"] and len(inputs) == 1:
            cmd += ["-o", obj_name(spec["inputs"][0])]
        elif not spec["compile_only"] and not spec["preprocess"] and not spec["dep_only"]:
            cmd += ["-o", "a.out"]
        return run_cmd(cmd)
    finally:
        for path in cleanup:
            try:
                os.unlink(path)
            except OSError:
                pass


if __name__ == "__main__":
    sys.exit(main(sys.argv))
