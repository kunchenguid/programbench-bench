module dupl-reimpl

go 1.20
