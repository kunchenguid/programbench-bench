package main

import (
	"bufio"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/scanner"
	"go/token"
	"html"
	"io"
	"log"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
)

const usageText = `Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    	read file names from stdin one at each line
  -html
    	output the results as HTML, including duplicate code fragments
  -plumbing
    	plumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    	minimum token sequence size as a clone (default 15)
  -vendor
    	check files in vendor directory
  -v, -verbose
    	explain what is being done

Examples:
  dupl -t 100
    	Search clones in the current directory of size at least
    	100 tokens.
  dupl $(find app/ -name '*_test.go')
    	Search for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
    	The same as above.
`

type nodeOcc struct {
	file      string
	startLine int
	endLine   int
	index     int
	size      int
	seq       string
}

type clone struct {
	file      string
	startLine int
	endLine   int
	index     int
	size      int
}

type group struct {
	clones []clone
	first  int
	length int
}

var fileLines = map[string][]string{}

func main() {
	var threshold int
	var filesFlag, htmlFlag, plumbingFlag, vendorFlag, verbose bool

	fs := flag.NewFlagSet("dupl", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	fs.IntVar(&threshold, "t", 15, "")
	fs.IntVar(&threshold, "threshold", 15, "")
	fs.BoolVar(&filesFlag, "files", false, "")
	fs.BoolVar(&htmlFlag, "html", false, "")
	fs.BoolVar(&plumbingFlag, "plumbing", false, "")
	fs.BoolVar(&vendorFlag, "vendor", false, "")
	fs.BoolVar(&verbose, "v", false, "")
	fs.BoolVar(&verbose, "verbose", false, "")
	fs.Usage = func() { fmt.Fprint(os.Stderr, usageText) }
	if err := fs.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}

	paths := fs.Args()
	var files []string
	if filesFlag {
		s := bufio.NewScanner(os.Stdin)
		for s.Scan() {
			files = append(files, s.Text())
		}
		if err := s.Err(); err != nil {
			log.Print(err)
		}
	} else {
		if len(paths) == 0 {
			paths = []string{"."}
		}
		var err error
		files, err = collectFiles(paths, vendorFlag)
		if err != nil {
			log.Fatal(err)
		}
	}

	var occs []nodeOcc
	index := 0
	for _, f := range files {
		ns, err := parseFile(f, &index)
		if err != nil {
			log.Print(err)
			continue
		}
		occs = append(occs, ns...)
	}

	if verbose {
		log.Print("Building suffix tree")
		log.Print("Searching for clones")
	}

	groups := findGroups(occs, threshold)
	if htmlFlag {
		writeHTML(os.Stdout, groups)
	} else if plumbingFlag {
		writePlumbing(os.Stdout, groups)
	} else {
		writeText(os.Stdout, groups)
	}
}

func collectFiles(paths []string, vendor bool) ([]string, error) {
	var files []string
	for _, p := range paths {
		st, err := os.Stat(p)
		if err != nil {
			return files, err
		}
		if !st.IsDir() {
			files = append(files, p)
			continue
		}
		err = filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if d.IsDir() {
				if !vendor && d.Name() == "vendor" {
					return filepath.SkipDir
				}
				return nil
			}
			if strings.HasSuffix(d.Name(), ".go") {
				files = append(files, path)
			}
			return nil
		})
		if err != nil {
			return files, err
		}
	}
	return files, nil
}

func parseFile(path string, next *int) ([]nodeOcc, error) {
	src, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	fileLines[path] = splitLines(string(src))
	fset := token.NewFileSet()
	f, err := parser.ParseFile(fset, path, src, 0)
	if err != nil {
		return nil, err
	}
	var out []nodeOcc
	ast.Inspect(f, func(n ast.Node) bool {
		if n == nil {
			return true
		}
		if !interesting(n) {
			return true
		}
		parts := serialize(n)
		if len(parts) == 0 {
			return true
		}
		start := fset.Position(n.Pos()).Line
		end := fset.Position(n.End()).Line
		seq := strings.Join(parts, "\x00")
		out = append(out, nodeOcc{file: path, startLine: start, endLine: end, index: *next, size: len(parts), seq: seq})
		*next++
		return true
	})
	return out, nil
}

func interesting(n ast.Node) bool {
	switch n.(type) {
	case *ast.File, ast.Decl, *ast.BlockStmt, *ast.IfStmt, *ast.ForStmt, *ast.RangeStmt, *ast.SwitchStmt, *ast.TypeSwitchStmt, *ast.SelectStmt, *ast.CaseClause, *ast.CommClause, *ast.ValueSpec, *ast.TypeSpec:
		return true
	default:
		return false
	}
}

func serialize(root ast.Node) []string {
	var parts []string
	ast.Inspect(root, func(n ast.Node) bool {
		if n == nil {
			parts = append(parts, ")")
			return true
		}
		if !interesting(n) {
			return true
		}
		name := reflect.TypeOf(n).String()
		switch x := n.(type) {
		case *ast.BinaryExpr:
			parts = append(parts, name+":"+x.Op.String())
		case *ast.UnaryExpr:
			parts = append(parts, name+":"+x.Op.String())
		case *ast.AssignStmt:
			parts = append(parts, name+":"+x.Tok.String())
		case *ast.BranchStmt:
			parts = append(parts, name+":"+x.Tok.String())
		case *ast.IncDecStmt:
			parts = append(parts, name+":"+x.Tok.String())
		case *ast.BasicLit:
			parts = append(parts, name+":"+x.Kind.String())
		default:
			parts = append(parts, name)
		}
		return true
	})
	return parts
}

func tokenCount(fset *token.FileSet, n ast.Node, src []byte) int {
	start := fset.Position(n.Pos()).Offset
	end := fset.Position(n.End()).Offset
	if start < 0 || end < start || end > len(src) {
		return 0
	}
	file := token.NewFileSet().AddFile("", 1, end-start)
	var s scanner.Scanner
	s.Init(file, src[start:end], nil, 0)
	count := 0
	for {
		_, tk, _ := s.Scan()
		if tk == token.EOF {
			break
		}
		if tk != token.COMMENT && tk != token.SEMICOLON {
			count++
		}
	}
	return count
}

func findGroups(occs []nodeOcc, threshold int) []group {
	if threshold < 1 {
		threshold = 1
	}
	buckets := map[string][]nodeOcc{}
	for _, o := range occs {
		if o.size >= threshold {
			buckets[o.seq] = append(buckets[o.seq], o)
		}
	}
	var groups []group
	for _, os := range buckets {
		if len(os) < 2 {
			continue
		}
		sort.Slice(os, func(i, j int) bool {
			if os[i].file != os[j].file {
				return os[i].file < os[j].file
			}
			if os[i].startLine != os[j].startLine {
				return os[i].startLine < os[j].startLine
			}
			if os[i].endLine != os[j].endLine {
				return os[i].endLine < os[j].endLine
			}
			return os[i].index < os[j].index
		})
		clones := make([]clone, 0, len(os))
		seen := map[string]bool{}
		for _, o := range os {
			key := fmt.Sprintf("%s:%d:%d", o.file, o.startLine, o.endLine)
			if seen[key] {
				continue
			}
			seen[key] = true
			clones = append(clones, clone{file: o.file, startLine: o.startLine, endLine: o.endLine, index: o.index, size: o.size})
		}
		if len(clones) >= 2 {
			groups = append(groups, group{clones: clones, first: clones[0].index, length: clones[0].size})
		}
	}
	keep := make([]bool, len(groups))
	for i := range keep {
		keep[i] = true
	}
	for i := range groups {
		for j := range groups {
			if i == j || groups[i].length >= groups[j].length {
				continue
			}
			if containedGroup(groups[i], groups[j]) {
				keep[i] = false
				break
			}
		}
	}
	out := groups[:0]
	for i, g := range groups {
		if keep[i] {
			out = append(out, g)
		}
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].first != out[j].first {
			return out[i].first < out[j].first
		}
		if out[i].length != out[j].length {
			return out[i].length > out[j].length
		}
		return len(out[i].clones) > len(out[j].clones)
	})
	return out
}

func containedGroup(a, b group) bool {
	for _, ca := range a.clones {
		found := false
		for _, cb := range b.clones {
			if ca.file == cb.file && ca.startLine >= cb.startLine && ca.endLine <= cb.endLine {
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

func writeText(w io.Writer, groups []group) {
	for _, g := range groups {
		fmt.Fprintf(w, "found %d clones:\n", len(g.clones))
		for _, c := range g.clones {
			fmt.Fprintf(w, "  %s:%d,%d\n", c.file, c.startLine, c.endLine)
		}
	}
	fmt.Fprintf(w, "\nFound total %d clone groups.\n", len(groups))
}

func writePlumbing(w io.Writer, groups []group) {
	for _, g := range groups {
		for i, c := range g.clones {
			d := g.clones[(i+1)%len(g.clones)]
			fmt.Fprintf(w, "%s:%d-%d: duplicate of %s:%d-%d\n", c.file, c.startLine, c.endLine, d.file, d.startLine, d.endLine)
		}
	}
}

func writeHTML(w io.Writer, groups []group) {
	fmt.Fprint(w, "<!DOCTYPE html>\n<meta charset=\"utf-8\"/>\n<title>Duplicates</title>\n<style>\n\tpre {\n\t\tbackground-color: #FFD;\n\t\tborder: 1px solid #E2E2E2;\n\t\tpadding: 1ex;\n\t}\n</style>\n")
	for i, g := range groups {
		fmt.Fprintf(w, "<h1>#%d found %d clones</h1>\n", i+1, len(g.clones))
		for _, c := range g.clones {
			fmt.Fprintf(w, "<h2>%s:%d</h2>\n", html.EscapeString(c.file), c.startLine)
			fmt.Fprintf(w, "<pre>%s</pre>\n", html.EscapeString(snippet(c.file, c.startLine, c.endLine)))
		}
	}
}

func snippet(file string, start, end int) string {
	lines := fileLines[file]
	if start < 1 {
		start = 1
	}
	if end > len(lines) {
		end = len(lines)
	}
	if start > end || start > len(lines) {
		return ""
	}
	return strings.Join(lines[start-1:end], "\n")
}

func splitLines(s string) []string {
	s = strings.ReplaceAll(s, "\r\n", "\n")
	s = strings.TrimSuffix(s, "\n")
	if s == "" {
		return []string{""}
	}
	return strings.Split(s, "\n")
}
