#!/usr/bin/env python3
import argparse
import difflib
import os
import re
import sys

LINTS = [
    ("W01", "bool_comparison"),
    ("W02", "empty_let_in"),
    ("W03", "manual_inherit"),
    ("W04", "manual_inherit_from"),
    ("W05", "legacy_let_syntax"),
    ("W06", "collapsible_let_in"),
    ("W07", "eta_reduction"),
    ("W08", "useless_parens"),
    ("W10", "empty_pattern"),
    ("W11", "redundant_pattern_bind"),
    ("W12", "unquoted_uri"),
    ("W14", "empty_inherit"),
    ("W17", "deprecated_to_path"),
    ("W18", "bool_simplification"),
    ("W19", "useless_has_attr"),
    ("W20", "repeated_keys"),
    ("W23", "empty_list_concat"),
]

EXPLAINS = {
    "W01": """## What it does
Checks for expressions of the form `x == true`, `x != true` and
suggests using the variable directly.

## Why is this bad?
Unnecessary code.

## Example
Instead of checking the value of `x`:

```nix
if x == true then 0 else 1
```

Use `x` directly:

```nix
if x then 0 else 1
```""",
    "W02": """## What it does
Checks for `let-in` expressions which create no new bindings.

## Why is this bad?
`let-in` expressions that create no new bindings are useless.
These are probably remnants from debugging or editing expressions.

## Example

```nix
let in pkgs.statix
```

Preserve only the body of the `let-in` expression:

```nix
pkgs.statix
```""",
}

for code, name in LINTS:
    EXPLAINS.setdefault(code, f"## {name}\n\nNo detailed explanation available.")

MESSAGES = {
    1: "Unnecessary comparison with boolean",
    2: "This let-in expression has no entries",
    3: "This assignment is better written with `inherit`",
    4: "This assignment is better written with `inherit`",
    5: "This legacy let syntax is deprecated",
    6: "This `let in` expression contains a nested `let in` expression",
    7: "Found eta-reduction",
    8: "Useless parentheses",
    10: "This empty pattern can be replaced with `_`",
    11: "This pattern bind is redundant",
    12: "Consider quoting this URI expression",
    14: "Remove this empty `inherit` statement",
    17: "`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more",
    18: "Try `!=` instead of `!(... == ...)`",
    19: "Consider using `or` instead of this `if` expression",
    20: "Repeated key in attribute set",
    23: "Concatenation with the empty list, `[]`, is a no-op",
}


def line_col(text, idx):
    line = text.count("\n", 0, idx) + 1
    prev = text.rfind("\n", 0, idx)
    col = idx + 1 if prev < 0 else idx - prev
    return line, col


def disabled_from_config(conf_path):
    paths = []
    if conf_path:
        paths.append(conf_path if os.path.isfile(conf_path) else os.path.join(conf_path, "statix.toml"))
    paths.append("statix.toml")
    for path in paths:
        try:
            data = open(path, encoding="utf-8").read()
        except OSError:
            continue
        m = re.search(r"disabled\s*=\s*\[([^\]]*)\]", data, re.S)
        if not m:
            return set()
        return {x.strip().strip("'\"").lower() for x in m.group(1).split(",") if x.strip()}
    return set()


def lint_text(text, path, disabled=None):
    disabled = disabled or set()
    diags = []

    def add(code, start, msg=None):
        cname = dict(LINTS).get(f"W{code:02d}", "").lower()
        if f"w{code:02d}" in disabled or cname in disabled:
            return
        line, col = line_col(text, start)
        diags.append((line, col, code, msg or MESSAGES[code]))

    for m in re.finditer(r"(?<![=!])\b([A-Za-z_][\w'.-]*(?:\.[A-Za-z_][\w'.-]*)*)\s*(==|!=)\s*(true|false)\b", text):
        add(1, m.start(), f"Comparing `{m.group(1)}` with boolean literal `{m.group(3)}`")
    for m in re.finditer(r"\blet\s+in\b", text):
        add(2, m.start())
    for m in re.finditer(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;", text):
        add(3, m.start(2))
    for m in re.finditer(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\.\2\s*;", text):
        add(4, m.start(2))
    for m in re.finditer(r"\blet\s*\{", text):
        add(5, m.start())
    for m in re.finditer(r"\blet\b[\s\S]{0,400}?\bin\s*\n\s*let\b", text):
        add(6, m.start())
        inner = text.find("let", text.find("in", m.start()))
        if inner >= 0:
            add(6, inner, "This `let in` expression is nested")
    for m in re.finditer(r"\(\s*([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\s*\)", text):
        add(7, m.start(), f"Found eta-reduction: `{m.group(2)}`")
    for m in re.finditer(r"=\s*\(([^()\n;]+)\)\s*;", text):
        add(8, m.start(1) - 1, "Useless parentheses around value in binding")
    for m in re.finditer(r"\b(map|filter|foldl'?|foldr)\s+\(([A-Za-z_][\w'.-]*)\)", text):
        add(8, m.start(2) - 1, "Useless parentheses around primitive expression")
    for m in re.finditer(r"(?m)^(\s*)\(([^()\n]+)\)\s*$", text):
        add(8, m.start(2) - 1, "Useless parentheses around body of `let` expression")
    for m in re.finditer(r"\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:", text):
        add(11, m.start(), f"This pattern bind is redundant, use `{m.group(1)}` instead")
    for m in re.finditer(r"(?<!@ )\{\s*\.\.\.\s*\}\s*:", text):
        add(10, m.start())
    for m in re.finditer(r"(?<![\"'])\b([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+~#-]+)", text):
        if m.group(1).startswith(("http:", "https:", "github:", "gitlab:", "sourcehut:", "ssh:", "git:")):
            add(12, m.start())
    for m in re.finditer(r"\binherit\s*;", text):
        add(14, m.start())
    for m in re.finditer(r"\bbuiltins\.toPath\b|\btoPath\b", text):
        add(17, m.start())
    for m in re.finditer(r"!\s*\(\s*([^()\n]+?)\s*==\s*([^()\n]+?)\s*\)", text):
        add(18, m.start())
    for m in re.finditer(r"\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n]+)", text):
        add(19, m.start(), f"Consider using `{m.group(1)}.{m.group(2)} or {m.group(3).strip()}` instead of this `if` expression")
    keys = {}
    for m in re.finditer(r"\b([A-Za-z_][\w'-]*)\.([A-Za-z_][\w'-]*)\s*=", text):
        keys.setdefault(m.group(1), []).append(m)
    for key, ms in keys.items():
        if len(ms) >= 2:
            add(20, ms[0].start(), f"The key `{key}` is first assigned here ...")
            for m in ms[1:]:
                add(20, m.start(), "... repeated here ...")
    for m in re.finditer(r"\[\]\s*\+\+\s*([A-Za-z_][\w'.-]*)", text):
        add(23, m.start())
    return sorted(diags)


def fix_text(text):
    out = text
    out = re.sub(r"\blet\s+in\s+", "", out)
    out = re.sub(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;", r"\1inherit \2;", out)
    out = re.sub(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\.\2\s*;", r"\1inherit (\3) \2;", out)
    out = re.sub(r"\bin\s*\n\s*let\b", "\n", out, count=1)
    out = re.sub(r"\(\s*([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\s*\)", r"\2", out)
    out = re.sub(r"=\s*\(([^()\n;]+)\)\s*;", r"= \1;", out)
    out = re.sub(r"\b(map|filter|foldl'?|foldr)\s+\(([A-Za-z_][\w'.-]*)\)", r"\1 \2", out)
    out = re.sub(r"(?m)^(\s*)\(([^()\n]+)\)\s*$", r"\1\2", out)
    out = re.sub(r"\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:", r"\1:", out)
    out = re.sub(r"\{\s*\.\.\.\s*\}\s*:", "_:", out)
    out = re.sub(r"(?<![\"'])\b((?:https?|github|gitlab|sourcehut|ssh|git):[A-Za-z0-9_./?=&%+~#-]+)", r'"\1"', out)
    out = re.sub(r"\s*\binherit\s*;", "", out)
    out = re.sub(r"!\s*\(\s*([^()\n]+?)\s*==\s*([^()\n]+?)\s*\)", r"\1 != \2", out)
    out = re.sub(r"\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n]+)", r"\1.\2 or \3", out)
    out = re.sub(r"\[\]\s*\+\+\s*", "", out)

    def bool_repl(m):
        expr, op, lit = m.group(1), m.group(2), m.group(3)
        neg = (op == "!=") ^ (lit == "false")
        return ("! " if neg else "") + expr
    out = re.sub(r"(?<![=!])\b([A-Za-z_][\w'.-]*)\s*(==|!=)\s*(true|false)\b", bool_repl, out)
    return out


def files_for_target(target):
    if target == "-":
        return []
    if os.path.isdir(target):
        res = []
        for root, dirs, files in os.walk(target):
            dirs[:] = [d for d in dirs if d not in {".git", ".direnv"}]
            for name in files:
                if name.endswith(".nix"):
                    res.append(os.path.join(root, name))
        return sorted(res)
    return [target]


def read_file(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def print_diagnostics(diags, path, fmt):
    for line, col, code, msg in diags:
        if fmt == "errfmt":
            print(f"{path}>{line}:{col}:W:{code}:{msg}")
        else:
            print(f"[W{code:02d}] Warning: {msg}\n   --> {path}:{line}:{col}")


def unified(old, new, path):
    return "".join(difflib.unified_diff(
        old.splitlines(True),
        new.splitlines(True),
        fromfile=path,
        tofile=f"{path} [fixed]",
    ))


def cmd_check(args):
    disabled = disabled_from_config(args.config)
    if args.stdin:
        text = sys.stdin.read()
        diags = lint_text(text, "<stdin>", disabled)
        print_diagnostics(diags, "<stdin>", args.format)
        return 1 if diags else 0
    all_diags = []
    for path in files_for_target(args.target):
        if not os.path.exists(path):
            print(f"config error: path error: file not found: {path}", file=sys.stderr)
            continue
        ds = lint_text(read_file(path), path, disabled)
        print_diagnostics(ds, path, args.format)
        all_diags.extend(ds)
    return 1 if all_diags else 0


def cmd_fix(args):
    if args.stdin:
        old = sys.stdin.read()
        new = fix_text(old)
        if args.dry_run:
            if new != old:
                sys.stdout.write(unified(old, new, "<stdin>"))
        else:
            sys.stdout.write(new)
        return 0
    for path in files_for_target(args.target):
        if not os.path.exists(path):
            print(f"config error: path error: file not found: {path}", file=sys.stderr)
            continue
        old = read_file(path)
        new = fix_text(old)
        if args.dry_run:
            if new != old:
                sys.stdout.write(unified(old, new, path))
        elif new != old:
            with open(path, "w", encoding="utf-8") as f:
                f.write(new)
    return 0


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        print("""statix 0.5.8

Akshay <nerdy@peppe.rs>

Lints and suggestions for the Nix programming language

USAGE:
    executable <SUBCOMMAND>

SUBCOMMANDS:
    check      Lints and suggestions for the nix programming language
    dump       Dump a sample config to stdout
    explain    Print detailed explanation for a lint warning
    fix        Find and fix issues raised by statix-check
    list       List all available lints
    single     Fix exactly one issue at provided position""")
        return 0 if argv else 2
    if argv[0] in ("-V", "--version"):
        print("statix 0.5.8")
        return 0
    sub = argv.pop(0)
    if sub == "list":
        for code, name in LINTS:
            print(code, name)
        return 0
    if sub == "dump":
        print("disabled = []\nignore = ['.direnv']\n")
        return 0
    if sub == "explain":
        code = argv[0].upper() if argv else ""
        print(EXPLAINS.get(code, "syntax error"))
        return 0

    p = argparse.ArgumentParser(prog=f"executable-{sub}", add_help=True)
    p.add_argument("-c", "--config", default=".")
    p.add_argument("-s", "--stdin", action="store_true")
    p.add_argument("-u", "--unrestricted", action="store_true")
    p.add_argument("-i", "--ignore", action="append", default=[])
    if sub == "check":
        p.add_argument("-o", "--format", default="stderr")
        p.add_argument("target", nargs="?", default=".")
        return cmd_check(p.parse_args(argv))
    if sub in ("fix", "single"):
        p.add_argument("-d", "--dry-run", action="store_true")
        if sub == "single":
            p.add_argument("-p", "--position")
        p.add_argument("target", nargs="?", default=".")
        return cmd_fix(p.parse_args(argv))
    print(f"error: unrecognized subcommand '{sub}'", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
