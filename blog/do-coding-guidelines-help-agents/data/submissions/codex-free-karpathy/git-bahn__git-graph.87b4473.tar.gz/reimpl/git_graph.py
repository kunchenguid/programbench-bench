#!/usr/bin/env python3
import argparse, os, re, shutil, subprocess, sys, html

VERSION='git-graph 0.7.0'
MODELS=['none','simple','git-flow']
HELP_LONG='''Structured Git graphs for your branching model.
    https://github.com/mlange-42/git-graph

EXAMPES:
    git-graph                   -> Show graph
    git-graph --style round     -> Show graph in a different style
    git-graph --model <model>   -> Show graph using a certain <model>
    git-graph model --list      -> List available branching models
    git-graph model             -> Show repo's current branching models
    git-graph model <model>     -> Permanently set model <model> for this repo

Usage: executable [OPTIONS] [COMMAND]

Commands:
  model  Prints or permanently sets the branching model for a repository.
  help   Print this message or the help of the given subcommand(s)

Options:
  -p, --path <path>                 Open repository from this path or above. Default '.'
      --skip-repo-owner-validation  Skip owner validation for the repository.
                                    This will turn off libgit2's owner validation, which may increase security risks.
                                    Please do not disable this validation for repositories you do not trust.
  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].
                                    Default: git-flow. 
                                    Permanently set the model for a repository with
                                    > git-graph model <model>
  -n, --max-count <n>               Maximum number of commits
      --color <color>               Specify when colors should be used. One of [auto|always|never].
                                    Default: auto.
      --no-color                    Print without colors. Missing color support should be detected
                                    automatically (e.g. when piping to a file).
                                    Overrides option '--color'
  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'
                                    Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]
                                    For examples, consult 'git-graph --help'
  -f, --format <format>             Commit format. One of [oneline|short|medium|full|"<string>"].
                                      (First character can be used as abbreviation, e.g. '-f m')
                                    Default: oneline.
                                    For placeholders supported in "<string>", consult 'git-graph --help'
  -r, --reverse                     Reverse the order of commits.
  -l, --local                       Show only local branches, no remotes.
      --svg                         Render graph as SVG instead of text-based.
  -d, --debug                       Additional debug output and graphics.
  -S, --sparse                      Print a less compact graph: merge lines point to target lines
                                    rather than merge commits.
  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].
                                      (First character can be used as abbreviation, e.g. '-s r')
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version'''
MODEL_HELP='''Prints or permanently sets the branching model for a repository.

Usage: executable model [OPTIONS] [model]

Arguments:
  [model]  The branching model to be used. Available presets are [simple|git-flow|none].
           When not given, prints the currently set model.

Options:
  -l, --list  List all available branching models.
  -h, --help  Print help'''

STYLE={
 'ascii': {'node':'*','merge':'o','v':'|','h':'-','left':"'",'right':'.','tee':'|','down':'|','merge_right':'.','merge_left':"'"},
 'normal': {'node':'●','merge':'○','v':'│','h':'─','left':'┘','right':'┐','tee':'├','down':'│','merge_right':'┐','merge_left':'┌'},
 'thin': {'node':'●','merge':'○','v':'│','h':'─','left':'┘','right':'┐','tee':'├','down':'│','merge_right':'┐','merge_left':'┌'},
 'round': {'node':'●','merge':'○','v':'│','h':'─','left':'╯','right':'╮','tee':'├','down':'│','merge_right':'╮','merge_left':'┌'},
 'bold': {'node':'●','merge':'○','v':'┃','h':'━','left':'┛','right':'┓','tee':'┣','down':'┃','merge_right':'┓','merge_left':'┏'},
 'double': {'node':'●','merge':'○','v':'║','h':'═','left':'╝','right':'╗','tee':'╠','down':'║','merge_right':'╗','merge_left':'╔'},
}

def git(args, cwd, check=True):
    p=subprocess.run(['git']+args, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode!=0:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip())
    return p.stdout

def find_repo(path):
    if not os.path.exists(path):
        print(f"ERROR: failed to resolve path '{path}': No such file or directory", file=sys.stderr)
        print("       Navigate into a repository before running git-graph, or use option --path", file=sys.stderr)
        sys.exit(1)
    p=subprocess.run(['git','-C',path,'rev-parse','--show-toplevel'], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if p.returncode!=0:
        print("ERROR: not a git repository", file=sys.stderr); sys.exit(1)
    return p.stdout.strip()

def model_file(repo): return os.path.join(repo,'.git','git-graph.toml')
def read_model(repo):
    try:
        s=open(model_file(repo)).read()
        m=re.search(r'model\s*=\s*"([^"]+)"',s)
        return m.group(1) if m else None
    except FileNotFoundError: return None

def write_model(repo, m):
    with open(model_file(repo),'w') as f: f.write(f'model = "{m}"\n')

def norm_style(s):
    if s is None: return 'normal'
    maps={'n':'normal','t':'thin','r':'round','b':'bold','d':'double','a':'ascii'}
    return maps.get(s, s) if s in STYLE or s in maps else None

def decorations(D):
    if not D: return ''
    branches=[]; tags=[]; others=[]
    for part in [x.strip() for x in D.split(',') if x.strip()]:
        if part.startswith('tag: '): tags.append('['+part[5:]+']')
        elif part.startswith('HEAD -> '): branches.append('HEAD -> '+part[8:])
        elif part=='HEAD': branches.append('HEAD')
        elif part.startswith('origin/'): branches.append(part)
        else: branches.append(part)
    out=[]
    if branches: out.append('('+', '.join(branches)+')')
    out += tags
    if others and not out: out.append('('+', '.join(others)+')')
    return ' '.join(out)

def commit_fields(repo, sha):
    fmt='%H%x1f%h%x1f%P%x1f%p%x1f%D%x1f%s%x1f%b%x1f%B%x1f%an%x1f%ae%x1f%ad%x1f%as%x1f%ar%x1f%cn%x1f%ce%x1f%cd%x1f%cs%x1f%cr'
    out=git(['show','-s','--date=default',f'--format={fmt}',sha], repo).rstrip('\n')
    parts=out.split('\x1f')
    while len(parts)<18: parts.append('')
    keys=['H','h','P','p','D','s','b','B','an','ae','ad','as','ar','cn','ce','cd','cs','cr']
    d=dict(zip(keys, parts)); d['d']=decorations(d.get('D',''))
    return d

def apply_format(fmt, f):
    if fmt in ('oneline','o'):
        return (f['h'] + ((' '+f['d']) if f['d'] else '') + ' ' + f['s']).rstrip()
    if fmt in ('short','s'):
        lines=[f"commit {f['H']}" + ((' '+f['d']) if f['d'] else '')]
        if f['P'] and len(f['P'].split())>1: lines.append('Merge: '+f['p'])
        lines += [f"Author: {f['an']} <{f['ae']}>", '', '    '+f['s'], '']
        if f['b'].strip():
            lines.append('')
            lines += ['    '+x if x else '' for x in f['b'].rstrip('\n').split('\n')]
            lines.append('')
        return '\n'.join(lines)
    if fmt in ('medium','m'):
        lines=[f"commit {f['H']}" + ((' '+f['d']) if f['d'] else '')]
        if f['P'] and len(f['P'].split())>1: lines.append('Merge: '+f['p'])
        lines += [f"Author: {f['an']} <{f['ae']}>", f"Date:   {f['ad']}", '', '    '+f['s'], '']
        if f['b'].strip(): lines += ['    '+x if x else '' for x in f['b'].rstrip('\n').split('\n')] + ['']
        return '\n'.join(lines)
    if fmt in ('full','f'):
        lines=[f"commit {f['H']}" + ((' '+f['d']) if f['d'] else '')]
        if f['P'] and len(f['P'].split())>1: lines.append('Merge: '+f['p'])
        lines += [f"Author: {f['an']} <{f['ae']}>", f"Commit: {f['cn']} <{f['ce']}>", f"Date:   {f['ad']}", '', '    '+f['s'], '']
        if f['b'].strip(): lines += ['    '+x if x else '' for x in f['b'].rstrip('\n').split('\n')] + ['']
        return '\n'.join(lines)
    vals={'H':f['H'],'h':f['h'],'P':f['P'],'p':f['p'],'d':f['d'],'s':f['s'],'b':f['b'].rstrip('\n'),'B':f['B'].rstrip('\n'),'an':f['an'],'ae':f['ae'],'ad':f['ad'],'as':f['as'],'ar':f['ar'],'cn':f['cn'],'ce':f['ce'],'cd':f['cd'],'cs':f['cs'],'cr':f['cr'],'n':'\n'}
    res=''; i=0
    names=sorted(vals.keys(), key=len, reverse=True)
    while i<len(fmt):
        if fmt[i]=='%' and i+1<len(fmt):
            mod=''; j=i+1
            if fmt[j] in '+- ': mod=fmt[j]; j+=1
            hit=None
            for name in names:
                if fmt.startswith(name,j): hit=name; break
            if hit is not None:
                val=vals[hit]
                if mod=='+' and val: res+='\n'
                elif mod==' ' and val: res+=' '
                elif mod=='-' and not val: res=res.rstrip('\n')
                res+=val; i=j+len(hit); continue
        res+=fmt[i]; i+=1
    return res

def get_commits(repo, max_count=None, local=False):
    refs=['--branches','--tags'] if local else ['--all']
    out=git(['rev-list','--date-order','--parents']+refs, repo)
    rows=[]
    for line in out.splitlines():
        ps=line.split();
        if ps: rows.append((ps[0],ps[1:]))
    if max_count: rows=rows[:max_count]
    return rows

def compute_lanes(rows, model='git-flow'):
    shown={s for s,_ in rows}; lanes=[]; result=[]; pending=[]
    for sha, parents0 in rows:
        parents=[p for p in parents0 if p in shown]
        if sha in lanes: col=lanes.index(sha)
        else:
            col=0 if model!='none' else len(lanes)
            lanes.insert(col, sha)
        before=lanes[:]
        first=parents[0] if parents else None
        join=None
        if first:
            if first in lanes and lanes.index(first) != col:
                join={'from':lanes.index(first),'to':col,'after':lanes[:]}
                lanes.pop(col)
            else:
                lanes[col]=first
        else: lanes.pop(col)
        for p in parents[1:]:
            if p not in lanes: lanes.append(p)
        after=lanes[:]
        result.append({'sha':sha,'parents':parents,'col':col,'before':before,'after':after,'join':join})
        pending.append(None)
    return result, pending

def expand_lanes(base):
    if not base: return ''
    out=[]
    for i,ch in enumerate(base):
        if i: out.append(' ')
        out.append(ch)
    return ''.join(out)

def graph_prefix(info, st):
    width=max(len(info['before']), len(info['after']), info['col']+1, 1)
    base=[]
    for i in range(width):
        if i==info['col']: base.append(st['merge'] if len(info['parents'])>1 else st['node'])
        elif i < len(info['before']) and info['before'][i] in info['after']: base.append(st['v'])
        else: base.append(' ')
    chars=list(expand_lanes(base))
    if len(info['parents'])>1 and info['parents'][1:] and not sparse_global:
        to=info['after'].index(info['parents'][1]) if info['parents'][1] in info['after'] else len(base)-1
        c=info['col']
        if to>c:
            for pos in range(2*c+1, 2*to): chars[pos]=st['h']
            chars[2*c+1]='<'
            chars[2*to]=st['merge_right']
            return ' '+''.join(chars)+'  '
        elif to<c:
            for pos in range(2*to+1, 2*c): chars[pos]=st['h']
            chars[2*to]=st['merge_left']
            chars[2*c-1]='>'
            return ' '+''.join(chars)+'  '
    return ' '+''.join(chars)+'  '

def connector_prefix(conn, st):
    if not conn: return None
    a,b=conn['from'],conn['to']; width=max(len(conn['after']),a+1,b+1,1)
    base=[]
    for i in range(width): base.append(st['v'] if i < len(conn['after']) else ' ')
    chars=list(expand_lanes(base))
    lo,hi=min(a,b),max(a,b)
    for pos in range(2*lo+1, 2*hi): chars[pos]=st['h']
    chars[2*lo]=st['tee']; chars[2*hi]=st['left'] if b>a else st['right']
    return ' '+''.join(chars)+'  '

def render_text(repo,args):
    style=norm_style(args.style) or 'normal'; st=STYLE[style]
    rows=get_commits(repo,args.max_count,args.local)
    if args.reverse: rows=list(reversed(rows))
    infos, conns=compute_lanes(rows,args.model_name)
    for idx,info in enumerate(infos):
        f=commit_fields(repo,info['sha']); text=apply_format(args.format,f)
        pref=graph_prefix(info,st)
        lines=text.split('\n')
        print(pref+lines[0])
        cont_base=[st['v'] if x in info['after'] else ' ' for x in info['before']]
        cont=' '+expand_lanes(cont_base)+'  '
        if len(cont)<len(pref): cont=cont+' '*(len(pref)-len(cont))
        conn=connector_prefix(info.get('join'),st)
        rest=lines[1:]
        if conn and rest:
            print(conn+rest[0])
            rest=rest[1:]
            conn=None
        for line in rest:
            print(cont+line)
        if conn and len(lines)==1: print(conn.rstrip())

def render_svg(repo,args):
    rows=get_commits(repo,args.max_count,args.local)
    infos,_=compute_lanes(rows,args.model_name)
    cols=max([len(i['before']) for i in infos]+[1]); w=cols*30; h=max(1,len(infos))*45
    print(f'<svg height="{h}" viewBox="0 0 {w} {h}" width="{w}" xmlns="http://www.w3.org/2000/svg">')
    for r,i in enumerate(infos):
        cx=i['col']*30+15; cy=r*45+15; color='blue' if i['col']==0 else ['orange','green','red','purple','turquoise'][i['col']%5]
        print(f'<circle cx="{cx}" cy="{cy}" fill="{color}" r="4" stroke="{color}" stroke-width="1"/>')
    print('</svg>')

sparse_global=False

def main(argv):
    global sparse_global
    if argv and argv[0]=='help':
        if len(argv)>1 and argv[1]=='model': print(MODEL_HELP)
        else: print(HELP_LONG)
        return 0
    if argv and argv[0]=='model':
        if any(x in argv for x in ['-h','--help']): print(MODEL_HELP); return 0
        if any(x in argv for x in ['-l','--list']): print('\n'.join(MODELS)); return 0
        vals=[x for x in argv[1:] if not x.startswith('-')]
        repo=find_repo('.')
        if not vals:
            m=read_model(repo); print(m if m else 'No branching model set', end=''); return 0
        m=vals[0]
        if m not in MODELS:
            print(f"ERROR: No branching model named '{m}' found in /home/agent/.config/git-graph/models", file=sys.stderr)
            print('       Available models are: none, simple, git-flow', file=sys.stderr); return 1
        write_model(repo,m); print(f"Branching model set to '{m}'", end=''); return 0
    if '-V' in argv or '--version' in argv: print(VERSION); return 0
    if '-h' in argv or '--help' in argv: print(HELP_LONG); return 0
    p=argparse.ArgumentParser(add_help=False, prog='executable')
    p.add_argument('-p','--path',default='.')
    p.add_argument('--skip-repo-owner-validation',action='store_true')
    p.add_argument('-m','--model',dest='model_name')
    p.add_argument('-n','--max-count')
    p.add_argument('--color',default='auto')
    p.add_argument('--no-color',action='store_true')
    p.add_argument('-w','--wrap',nargs='*')
    p.add_argument('-f','--format',default='oneline')
    p.add_argument('-r','--reverse',action='store_true')
    p.add_argument('-l','--local',action='store_true')
    p.add_argument('--svg',action='store_true')
    p.add_argument('-d','--debug',action='store_true')
    p.add_argument('-S','--sparse',action='store_true')
    p.add_argument('-s','--style')
    ns, extra=p.parse_known_args(argv)
    if extra:
        print(f"error: unexpected argument '{extra[0]}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.", file=sys.stderr); return 2
    if ns.color not in ('auto','always','never'):
        print(f"Unknown color mode '{ns.color}'. Supports [auto|always|never].", file=sys.stderr); return 1
    if ns.max_count is not None:
        try:
            ns.max_count=int(ns.max_count)
            if ns.max_count<=0: raise ValueError
        except ValueError:
            print(f"Option max-count must be a positive number, but got '{ns.max_count}'", file=sys.stderr); return 1
    repo=find_repo(ns.path)
    if ns.model_name is None: ns.model_name=read_model(repo) or 'git-flow'
    if ns.model_name not in MODELS:
        print(f"ERROR: No branching model named '{ns.model_name}' found in /home/agent/.config/git-graph/models", file=sys.stderr)
        print('       Available models are: none, simple, git-flow', file=sys.stderr); return 1
    if norm_style(ns.style) is None:
        print(f"Unknown style '{ns.style}'. Supports [normal/thin|round|bold|double|ascii].", file=sys.stderr); return 1
    sparse_global=ns.sparse
    try:
        if ns.svg: render_svg(repo,ns)
        else: render_text(repo,ns)
    except RuntimeError as e:
        print('ERROR: '+str(e), file=sys.stderr); return 1
    return 0
if __name__=='__main__': sys.exit(main(sys.argv[1:]))
