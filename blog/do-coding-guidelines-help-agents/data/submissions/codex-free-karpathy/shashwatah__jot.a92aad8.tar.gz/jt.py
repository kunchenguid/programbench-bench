#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys

BLUE = "\033[0;34m"
RED = "\033[0;31m"
RESET = "\033[0m"
VERSION = "0.1.2"


def home():
    return os.path.expanduser("~")


def config_dir():
    return os.path.join(home(), ".config", "jot")


def data_dir():
    return os.path.join(home(), ".local", "share", "jot")


def config_path():
    return os.path.join(config_dir(), "config")


def vaults_path():
    return os.path.join(data_dir(), "vaults")


def ensure_state():
    os.makedirs(config_dir(), exist_ok=True)
    os.makedirs(data_dir(), exist_ok=True)
    os.makedirs(os.path.join(home(), ".cache", "rosetta"), exist_ok=True)
    if not os.path.exists(config_path()):
        with open(config_path(), "w") as f:
            f.write("editor = 'nvim'\nconflict = true\n")
    if not os.path.exists(vaults_path()):
        with open(vaults_path(), "w") as f:
            f.write("[vaults]\n")


def read_config():
    ensure_state()
    cfg = {"editor": "nvim", "conflict": "true", "current": None}
    try:
        with open(config_path()) as f:
            for line in f:
                s = line.strip()
                if not s:
                    continue
                if "=" in s:
                    k, v = s.split("=", 1)
                    k = k.strip()
                    v = v.strip()
                    if v.startswith("'") and v.endswith("'"):
                        v = v[1:-1]
                    cfg[k] = v
                elif not s.startswith("["):
                    cfg["current"] = s
    except FileNotFoundError:
        pass
    return cfg


def write_config(cfg):
    with open(config_path(), "w") as f:
        f.write(f"editor = '{cfg.get('editor', 'nvim')}'\n")
        f.write(f"conflict = {cfg.get('conflict', 'true')}\n")
        if cfg.get("current"):
            f.write(f"{cfg['current']}\n")


def read_vaults():
    ensure_state()
    vaults = {}
    with open(vaults_path()) as f:
        for line in f:
            s = line.strip()
            if not s or s.startswith("[") or "=" not in s:
                continue
            k, v = s.split("=", 1)
            v = v.strip()
            if v.startswith("'") and v.endswith("'"):
                v = v[1:-1]
            vaults[k.strip()] = v
    return vaults


def write_vaults(vaults):
    with open(vaults_path(), "w") as f:
        f.write("[vaults]\n")
        for name, loc in vaults.items():
            f.write(f"{name} = '{loc}'\n")


def data_file(vault, loc):
    return os.path.join(loc, vault, ".jot", "data")


def write_vault_data(vault, loc, folder=""):
    jf = os.path.dirname(data_file(vault, loc))
    os.makedirs(jf, exist_ok=True)
    with open(data_file(vault, loc), "w") as f:
        f.write(f"name = '{vault}'\n")
        f.write(f"location = '{loc}'\n")
        f.write(f"folder = '{folder}'\n")
        f.write("history = []\n")


def read_vault_data(vault, loc):
    folder = ""
    try:
        with open(data_file(vault, loc)) as f:
            for line in f:
                s = line.strip()
                if s.startswith("folder") and "=" in s:
                    v = s.split("=", 1)[1].strip()
                    if v.startswith("'") and v.endswith("'"):
                        v = v[1:-1]
                    folder = v
    except FileNotFoundError:
        write_vault_data(vault, loc, "")
    return folder


def blue(s):
    return f"{BLUE}{s}{RESET}"


def err(s):
    print(f"{RED}error{RESET}: {s}")


def current():
    cfg = read_config()
    name = cfg.get("current")
    if not name:
        err("not inside a vault")
        return None
    vaults = read_vaults()
    if name not in vaults:
        err("not inside a vault")
        return None
    loc = vaults[name]
    folder = read_vault_data(name, loc)
    return name, loc, folder


def vault_root(name, loc):
    return os.path.join(loc, name)


def cur_dir(info):
    name, loc, folder = info
    return os.path.join(vault_root(name, loc), folder)


def normalize_note(name):
    return name if name.endswith(".md") else name + ".md"


def item_path(info, typ, name):
    if typ in ("note", "nt"):
        return os.path.join(cur_dir(info), normalize_note(name))
    if typ in ("folder", "fd"):
        return os.path.join(cur_dir(info), name)
    return None


def banner_help():
    print(f"""{BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \\  __/
____  / / /_/ / /_  
___  /  \\____/\\__/  
/___/         ᵥ{VERSION}  
{RESET}         

usage: jt <command>

{BLUE}commands:{RESET}

create items
    {BLUE}vault{RESET}, {BLUE}vl{RESET}       create a vault or list vaults
    create items in current folder
        {BLUE}note{RESET}, {BLUE}nt{RESET}        create a note 
        {BLUE}folder{RESET}, {BLUE}fd{RESET}      create a folder

interact with items
    {BLUE}enter{RESET}, {BLUE}en{RESET}       enter a vault
    {BLUE}open{RESET}, {BLUE}op{RESET}        open a note from current folder
    {BLUE}opdir{RESET}, {BLUE}od{RESET}       open current folder in file explorer
    {BLUE}chdir{RESET}, {BLUE}cd{RESET}       change folder within current vault
    {BLUE}list{RESET}, {BLUE}ls{RESET}        list items in current folder

perform fs operations on items
    {BLUE}remove{RESET}, {BLUE}rm{RESET}      remove an item 
    {BLUE}rename{RESET}, {BLUE}rn{RESET}      rename an item 
    {BLUE}move{RESET}, {BLUE}mv{RESET}        move an item to a new location
    {BLUE}vmove{RESET}, {BLUE}vm{RESET}       move an item to a different vault

config
    {BLUE}config{RESET}, {BLUE}cf{RESET}      display, set or open config

get help 
    use {BLUE}help{RESET} or {BLUE}-h{RESET} and {BLUE}--help{RESET} flags along with a command to get corresponding help""")


HELPS = {
    "vault": "executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information",
    "note": "executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
    "folder": "executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
    "enter": "executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information",
    "open": "executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information",
    "opdir": "executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information",
    "chdir": "executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information",
    "list": "executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information",
    "remove": "executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information",
    "rename": "executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information",
    "move": "executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information",
    "vmove": "executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information",
    "config": "executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information",
}


def show_cmd_help(cmd):
    base = {"vl": "vault", "nt": "note", "fd": "folder", "en": "enter", "ls": "list"}.get(cmd, cmd)
    if base in HELPS:
        print(HELPS[base])
    else:
        print(f"executable-{base} \n")


def cmd_vault(args):
    vaults = read_vaults()
    if args == ["-l"]:
        for n, loc in vaults.items():
            print(f"   {n} \t {loc}")
    elif not args:
        for n in vaults:
            print(f"   {n}")
    elif len(args) >= 2:
        name, loc = args[0], args[1]
        os.makedirs(vault_root(name, loc), exist_ok=True)
        write_vault_data(name, loc, "")
        vaults[name] = loc
        write_vaults(vaults)
        print(f"vault {blue(name)} created")
    else:
        print("error: The following required arguments were not provided:\n    <vault location>\n\nUSAGE:\n    jt vault <vault name> <vault location>\n\nFor more information try --help")
        return 2
    return 0


def cmd_enter(args):
    if not args:
        print("error: The following required arguments were not provided:\n    <vault name>")
        return 2
    vaults = read_vaults()
    name = args[0]
    if name not in vaults:
        err(f"vault {name} does not exist")
        return 0
    cfg = read_config()
    cfg["current"] = name
    write_config(cfg)
    write_vault_data(name, vaults[name], read_vault_data(name, vaults[name]))
    print(f"entered {blue(name)}")
    return 0


def cmd_note(args):
    if not args:
        print("error: The following required arguments were not provided:\n    <note name>\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nFor more information try --help")
        return 2
    info = current()
    if not info:
        return 0
    name = args[0]
    os.makedirs(cur_dir(info), exist_ok=True)
    open(os.path.join(cur_dir(info), normalize_note(name)), "a").close()
    print(f"note {blue(name)} created")
    return 0


def cmd_folder(args):
    if not args:
        print("error: The following required arguments were not provided:\n    <folder name>")
        return 2
    info = current()
    if not info:
        return 0
    name = args[0]
    os.makedirs(os.path.join(cur_dir(info), name), exist_ok=True)
    print(f"folder {blue(name)} created")
    return 0


def cmd_chdir(args):
    if not args:
        print("error: The following required arguments were not provided:\n    <folder path>")
        return 2
    info = current()
    if not info:
        return 0
    name, loc, folder = info
    root = vault_root(name, loc)
    target = args[0]
    if target.startswith("/"):
        new = os.path.normpath(target.lstrip("/"))
    else:
        new = os.path.normpath(os.path.join(folder, target))
    if new == ".":
        new = ""
    if new.startswith(".."):
        new = ""
    full = os.path.join(root, new)
    if not os.path.isdir(full):
        err("folder does not exist")
        return 0
    write_vault_data(name, loc, new)
    print("folder changed")
    return 0


def cmd_list(args):
    info = current()
    if not info:
        return 0
    name, loc, folder = info
    where = cur_dir(info)
    print(name if not folder else f"{name} > {folder.replace(os.sep, ' > ')}")
    typ = args[0] if args else None
    try:
        entries = list(os.scandir(where))
    except FileNotFoundError:
        return 0
    shown = []
    for idx, e in enumerate(entries):
        if not typ and e.name == ".jot":
            continue
        if typ in ("note", "nt") and not (e.is_file() and e.name.endswith(".md")):
            continue
        if typ in ("folder", "fd") and not e.is_dir():
            continue
        if typ not in (None, "note", "nt", "folder", "fd"):
            continue
        shown.append((idx, e))
    for idx, e in shown:
        branch = "└──" if idx == len(entries) - 1 else "├──"
        label = e.name[:-3] if e.is_file() and e.name.endswith(".md") else e.name
        if e.is_file() and e.name.endswith(".md"):
            label = blue(label)
        print(f"{branch} {label}")
    return 0


def parse_type(t):
    return {"vl": "vault", "nt": "note", "fd": "folder"}.get(t, t)


def cmd_remove(args):
    if len(args) < 2:
        print("error: The following required arguments were not provided:")
        return 2
    typ, name = parse_type(args[0]), args[1]
    if typ == "vault":
        vaults = read_vaults()
        loc = vaults.pop(name, None)
        if loc:
            shutil.rmtree(vault_root(name, loc), ignore_errors=True)
            write_vaults(vaults)
        print(f"vault {blue(name)} removed")
        return 0
    info = current()
    if not info:
        return 0
    p = item_path(info, typ, name)
    if typ == "note":
        try:
            os.remove(p)
        except FileNotFoundError:
            pass
        print(f"note {blue(name)} removed")
    elif typ == "folder":
        shutil.rmtree(p, ignore_errors=True)
        print(f"folder {blue(name)} removed")
    return 0


def cmd_rename(args):
    if len(args) < 3:
        print("error: The following required arguments were not provided:")
        return 2
    typ, name, new = parse_type(args[0]), args[1], args[2]
    if typ == "vault":
        vaults = read_vaults()
        if name in vaults:
            loc = vaults.pop(name)
            try:
                os.rename(vault_root(name, loc), vault_root(new, loc))
            except FileNotFoundError:
                pass
            vaults[new] = loc
            write_vaults(vaults)
        print(f"vault {blue(name)} renamed to {blue(new)}")
        return 0
    info = current()
    if not info:
        return 0
    src = item_path(info, typ, name)
    dst = item_path(info, typ, new)
    os.rename(src, dst)
    print(f"{typ} {blue(name)} renamed to {blue(new)}")
    return 0


def cmd_move(args):
    if len(args) < 3:
        print("error: The following required arguments were not provided:")
        return 2
    typ, name, dest = parse_type(args[0]), args[1], args[2]
    if typ == "vault":
        vaults = read_vaults()
        if name in vaults:
            old = vaults[name]
            os.makedirs(dest, exist_ok=True)
            try:
                shutil.move(vault_root(name, old), vault_root(name, dest))
            except Exception:
                pass
            vaults[name] = dest
            write_vaults(vaults)
        print(f"vault {blue(name)} moved")
        return 0
    info = current()
    if not info:
        return 0
    root = vault_root(info[0], info[1])
    base = dest.lstrip("/") if dest.startswith("/") else os.path.join(info[2], dest)
    target_dir = os.path.join(root, os.path.normpath(base))
    os.makedirs(target_dir, exist_ok=True)
    shutil.move(item_path(info, typ, name), os.path.join(target_dir, os.path.basename(item_path(info, typ, name))))
    print(f"{typ} {blue(name)} moved")
    return 0


def cmd_vmove(args):
    if len(args) < 3:
        print("error: The following required arguments were not provided:")
        return 2
    typ, name, vname = parse_type(args[0]), args[1], args[2]
    info = current()
    vaults = read_vaults()
    if not info or vname not in vaults:
        return 0
    dst_root = vault_root(vname, vaults[vname])
    shutil.move(item_path(info, typ, name), os.path.join(dst_root, os.path.basename(item_path(info, typ, name))))
    print(f"{typ} {blue(name)} moved to {blue(vname)}")
    return 0


def cmd_config(args):
    cfg = read_config()
    if not args:
        return 0
    key = args[0]
    if key not in ("editor", "conflict"):
        print(f"error: \"{key}\" isn't a valid value for '<config type>'\n\t[possible values: editor, conflict]\n\nFor more information try --help")
        return 2
    if len(args) == 1:
        print(f"{key}: {blue(cfg.get(key, ''))}")
    else:
        cfg[key] = args[1]
        write_config(cfg)
        print(f"set {blue(key)} to {blue(args[1])}")
    return 0


def cmd_open(args):
    if not args:
        return 2
    info = current()
    if not info:
        return 0
    editor = read_config().get("editor", "nvim")
    try:
        subprocess.call([editor, item_path(info, "note", args[0])])
    except Exception:
        pass
    return 0


def cmd_opdir(args):
    info = current()
    if not info:
        return 0
    for prog in ("xdg-open", "open"):
        if shutil.which(prog):
            try:
                subprocess.call([prog, cur_dir(info)])
            except Exception:
                pass
            break
    return 0


def main(argv):
    ensure_state()
    if not argv or argv[0] in ("-h", "--help"):
        banner_help()
        return 0
    if argv[0] == "help":
        if len(argv) > 1:
            show_cmd_help(argv[1])
        else:
            banner_help()
        return 0
    cmd = argv[0]
    args = argv[1:]
    if args and args[0] in ("-h", "--help"):
        show_cmd_help(cmd)
        return 0
    aliases = {
        "vl": "vault", "nt": "note", "fd": "folder", "en": "enter",
        "op": "open", "od": "opdir", "cd": "chdir", "ls": "list",
        "rm": "remove", "rn": "rename", "mv": "move", "vm": "vmove",
        "cf": "config",
    }
    cmd = aliases.get(cmd, cmd)
    table = {
        "vault": cmd_vault, "note": cmd_note, "folder": cmd_folder,
        "enter": cmd_enter, "open": cmd_open, "opdir": cmd_opdir,
        "chdir": cmd_chdir, "list": cmd_list, "remove": cmd_remove,
        "rename": cmd_rename, "move": cmd_move, "vmove": cmd_vmove,
        "config": cmd_config,
    }
    if cmd not in table:
        print(f"error: The subcommand '{argv[0]}' wasn't recognized\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help")
        return 2
    return table[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
