#!/usr/bin/env python3
import html
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

VERSION = "mdbook v0.5.0-alpha.1"
SHELLS = {"bash", "elvish", "fish", "powershell", "zsh"}


def log(level, target, message):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    print(f"{ts} [{level}] ({target}): {message}", file=sys.stderr)


def main_help():
    print("""Creates a book from markdown files

Usage: executable [COMMAND]

Commands:
  init         Creates the boilerplate structure and files for a new book
  build        Builds a book from its markdown files
  test         Tests that a book's Rust code samples compile
  clean        Deletes a built book
  completions  Generate shell completions for your shell to stdout
  watch        Watches a book's files and rebuilds it on changes
  serve        Serves a book at http://localhost:3000, and rebuilds it on changes
  help         Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version

For more information about a specific command, try `mdbook <command> --help`
The source code for mdBook is available at: https://github.com/rust-lang/mdBook""")


HELP = {
    "init": """Creates the boilerplate structure and files for a new book

Usage: executable init [OPTIONS] [dir]

Arguments:
  [dir]  Directory to create the book in
         (Defaults to the current directory when omitted)

Options:
      --theme            Copies the default theme into your source folder
      --force            Skips confirmation prompts
      --title <title>    Sets the book title
      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]
  -h, --help             Print help
  -V, --version          Print version""",
    "build": """Builds a book from its markdown files

Usage: executable build [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
  -h, --help                 Print help
  -V, --version              Print version""",
    "test": """Tests that a book's Rust code samples compile

Usage: executable test [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -c, --chapter <chapter>    
  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path
                             when building tests
  -h, --help                 Print help
  -V, --version              Print version""",
    "clean": """Deletes a built book

Usage: executable clean [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -h, --help                 Print help
  -V, --version              Print version""",
    "completions": """Generate shell completions for your shell to stdout

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,
           zsh]

Options:
  -h, --help     Print help
  -V, --version  Print version""",
    "watch": """Watches a book's files and rebuilds it on changes

Usage: executable watch [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version""",
    "serve": """Serves a book at http://localhost:3000, and rebuilds it on changes

Usage: executable serve [OPTIONS] [dir]

Arguments:
  [dir]  Root directory for the book
         (Defaults to the current directory when omitted)

Options:
  -d, --dest-dir <dest-dir>  Output directory for the book
                             Relative paths are interpreted relative to the book's root directory.
                             If omitted, mdBook uses build.build-dir from book.toml or defaults to
                             `./book`.
  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]
  -p, --port <port>          Port to use for HTTP connections [default: 3000]
  -o, --open                 Opens the compiled book in a web browser
      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:
                             poll, native]
  -h, --help                 Print help
  -V, --version              Print version""",
}


def die_cli(msg, usage="Usage: executable [COMMAND]"):
    print(f"error: {msg}\n\n{usage}\n\nFor more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse_options(args, takes_value, allowed=None, usage="Usage: executable [COMMAND]"):
    opts = {}
    pos = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            pos += args[i + 1 :]
            break
        if a.startswith("--"):
            if "=" in a:
                k, v = a[2:].split("=", 1)
            else:
                k = a[2:]
                if k in takes_value:
                    i += 1
                    if i >= len(args):
                        die_cli(f"a value is required for '--{k} <{k}>'")
                    v = args[i]
                else:
                    v = True
            if allowed is not None and k not in allowed:
                print(f"error: unexpected argument '--{k}' found\n\n{usage}\n\nFor more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            opts[k] = v
        elif a.startswith("-") and a != "-":
            chars = a[1:]
            for j, c in enumerate(chars):
                name = {"d": "dest-dir", "o": "open", "c": "chapter", "L": "library-path", "n": "hostname", "p": "port", "h": "help", "V": "version"}.get(c)
                if not name:
                    die_cli(f"unexpected argument '-{c}' found")
                if allowed is not None and name not in allowed:
                    print(f"error: unexpected argument '-{c}' found\n\n{usage}\n\nFor more information, try '--help'.", file=sys.stderr)
                    sys.exit(2)
                if name in takes_value:
                    if j != len(chars) - 1:
                        v = chars[j + 1 :]
                    else:
                        i += 1
                        if i >= len(args):
                            die_cli(f"a value is required for '-{c} <{name}>'")
                        v = args[i]
                    opts[name] = v
                    break
                else:
                    opts[name] = True
        else:
            pos.append(a)
        i += 1
    return opts, pos


def read_config(root):
    cfg = {"title": "mdBook", "src": "src", "build-dir": "book", "language": "en", "description": ""}
    path = root / "book.toml"
    if not path.exists():
        return cfg
    section = ""
    for raw in path.read_text(errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line.strip("[]")
            continue
        if "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        if "#" in v:
            v = v.split("#", 1)[0].strip()
        if v.startswith('"') and v.endswith('"'):
            v = v[1:-1]
        if section == "book" and k in ("title", "src", "language", "description"):
            cfg[k] = v
        if section == "build" and k == "build-dir":
            cfg["build-dir"] = v
    return cfg


def parse_summary(src):
    summary = src / "SUMMARY.md"
    if not summary.exists():
        log("ERROR", "mdbook_core::utils", f'Error: Couldn\'t open SUMMARY.md in "{src}" directory')
        log("ERROR", "mdbook_core::utils", "\tCaused By: No such file or directory (os error 2)")
        sys.exit(101)
    chapters = []
    parts = []
    for raw in summary.read_text(errors="replace").splitlines():
        s = raw.rstrip()
        if re.fullmatch(r"\s*-{3,}\s*", s):
            chapters.append({"type": "separator"})
            continue
        m = re.match(r"^\s*#\s+(.+?)\s*$", s)
        if m and not chapters:
            continue
        if m:
            parts.append(m.group(1))
            chapters.append({"type": "part", "title": m.group(1)})
            continue
        m = re.match(r"^(\s*)(?:[-*]\s*)?\[([^\]]+)\]\(([^)]*)\)", s)
        if m:
            indent = len(m.group(1).replace("\t", "    "))
            path = m.group(3).strip()
            chapters.append({"type": "chapter", "title": m.group(2).strip(), "path": path, "level": indent // 2})
    return chapters


def out_name(path):
    p = Path(path)
    if p.name.upper() == "README.MD":
        return str(p.with_name("index.html"))
    return str(p.with_suffix(".html"))


def md_inline(text):
    text = html.escape(text)
    text = re.sub(r"`([^`]+)`", r"<code>\1</code>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", text)
    text = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", text)
    text = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", lambda m: f'<img src="{html.escape(m.group(2))}" alt="{html.escape(m.group(1))}">', text)
    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lambda m: f'<a href="{html.escape(link_target(m.group(2)))}">{m.group(1)}</a>', text)
    return text


def link_target(link):
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*:", link) or link.startswith("#"):
        return link
    if link.endswith(".md"):
        return out_name(link)
    if ".md#" in link:
        a, b = link.split(".md#", 1)
        return out_name(a + ".md") + "#" + b
    return link


def markdown_to_html(text):
    lines = text.splitlines()
    out = []
    in_code = False
    code = []
    in_list = False
    para = []

    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + md_inline(" ".join(para).strip()) + "</p>")
            para = []

    for line in lines:
        if line.startswith("```") or line.startswith("~~~"):
            flush_para()
            if in_code:
                out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>")
                code = []
                in_code = False
            else:
                if in_list:
                    out.append("</ul>")
                    in_list = False
                in_code = True
            continue
        if in_code:
            code.append(line)
            continue
        if not line.strip():
            flush_para()
            if in_list:
                out.append("</ul>")
                in_list = False
            continue
        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if m:
            flush_para()
            if in_list:
                out.append("</ul>")
                in_list = False
            lvl = len(m.group(1))
            title = md_inline(m.group(2).strip())
            ident = re.sub(r"[^a-z0-9_-]+", "-", html.unescape(re.sub("<.*?>", "", title)).lower()).strip("-")
            out.append(f'<h{lvl} id="{ident}">{title}</h{lvl}>')
            continue
        m = re.match(r"^\s*[-*]\s+(.+)$", line)
        if m:
            flush_para()
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append("<li>" + md_inline(m.group(1).strip()) + "</li>")
            continue
        para.append(line.strip())
    flush_para()
    if in_list:
        out.append("</ul>")
    if in_code:
        out.append("<pre><code>" + html.escape("\n".join(code)) + "</code></pre>")
    return "\n".join(out)


def render_page(book_title, page_title, body, toc, relroot=""):
    nav = []
    for ch in toc:
        if ch["type"] == "chapter":
            if ch["path"]:
                href = relroot + out_name(ch["path"])
                nav.append(f'<li class="chapter-item"><a href="{html.escape(href)}">{html.escape(ch["title"])}</a></li>')
            else:
                nav.append(f'<li class="chapter-item disabled">{html.escape(ch["title"])}</li>')
        elif ch["type"] == "part":
            nav.append(f'<li class="part-title">{html.escape(ch["title"])}</li>')
        elif ch["type"] == "separator":
            nav.append("<li class=\"spacer\"></li>")
    return f"""<!DOCTYPE HTML>
<html lang="en" class="light sidebar-visible" dir="ltr">
<head>
<meta charset="UTF-8">
<title>{html.escape(page_title)} - {html.escape(book_title)}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body{{font-family:Arial, sans-serif;margin:0;display:flex;line-height:1.55;color:#222}}
nav{{width:280px;min-height:100vh;background:#f5f5f5;padding:1rem;box-sizing:border-box}}
main{{max-width:900px;padding:2rem 3rem}}
a{{color:#0969da;text-decoration:none}} pre{{background:#f6f8fa;padding:1rem;overflow:auto}}
code{{background:#f6f8fa;padding:.1rem .25rem}} pre code{{padding:0}} .part-title{{font-weight:bold;margin-top:1rem;list-style:none}} .disabled{{color:#777}}
</style>
</head>
<body>
<nav aria-label="Table of contents"><ol>{"".join(nav)}</ol></nav>
<main>
{body}
</main>
</body>
</html>
"""


def ensure_chapter_files(src, chapters):
    for ch in chapters:
        if ch.get("type") == "chapter" and ch.get("path"):
            p = src / ch["path"]
            if not p.exists():
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(f"# {ch['title']}\n", encoding="utf-8")


def copy_non_md(src, dest):
    for p in src.rglob("*"):
        if p.is_dir():
            continue
        rel = p.relative_to(src)
        if p.suffix.lower() == ".md":
            continue
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, target)


def command_init(args):
    opts, pos = parse_options(args, {"title", "ignore"}, {"theme", "force", "title", "ignore", "help", "version"}, "Usage: executable init [OPTIONS] [dir]")
    if opts.get("help"):
        print(HELP["init"]); return
    if opts.get("version"):
        print(VERSION); return
    root = Path(pos[0] if pos else ".")
    title = opts.get("title") or "My First Book"
    ignore = opts.get("ignore")
    if ignore not in (None, "none", "git"):
        print(f"error: invalid value '{ignore}' for '--ignore <ignore>'\n  [possible values: none, git]\n\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    root.mkdir(parents=True, exist_ok=True)
    src = root / "src"
    src.mkdir(exist_ok=True)
    summary = src / "SUMMARY.md"
    log("INFO", "mdbook_driver::init", "Creating a new book with stub content")
    if summary.exists():
        chapters = parse_summary(src)
        ensure_chapter_files(src, chapters)
    else:
        (src / "chapter_1.md").write_text("# Chapter 1\n", encoding="utf-8")
        summary.write_text("# Summary\n\n- [Chapter 1](./chapter_1.md)\n", encoding="utf-8")
    book = root / "book.toml"
    if not book.exists():
        book.write_text(f'[book]\nauthors = []\nlanguage = "en"\nsrc = "src"\ntitle = "{title}"\n', encoding="utf-8")
    if opts.get("theme"):
        theme = src / "theme"
        theme.mkdir(exist_ok=True)
        (theme / "index.hbs").write_text("{{ content }}\n", encoding="utf-8")
    if ignore == "git":
        (root / ".gitignore").write_text("book\n", encoding="utf-8")
    print("\nAll done, no errors...")


def get_paths(args, extra_takes=None, allowed_flags=None, usage="Usage: executable [COMMAND]"):
    takes = {"dest-dir"}
    if extra_takes:
        takes |= set(extra_takes)
    allowed = {"dest-dir", "help", "version"}
    if allowed_flags:
        allowed |= set(allowed_flags)
    if extra_takes:
        allowed |= set(extra_takes)
    opts, pos = parse_options(args, takes, allowed, usage)
    if len(pos) > 1:
        die_cli(f"unexpected argument '{pos[1]}' found")
    root = Path(pos[0] if pos else ".")
    cfg = read_config(root)
    src = root / cfg["src"]
    dest = Path(opts.get("dest-dir") or cfg["build-dir"])
    if not dest.is_absolute():
        dest = root / dest
    return opts, root, src, dest, cfg


def command_build(args, quiet=False):
    opts, root, src, dest, cfg = get_paths(args, allowed_flags={"open"}, usage="Usage: executable build [OPTIONS] [dir]")
    if opts.get("help"):
        print(HELP["build"]); return
    if opts.get("version"):
        print(VERSION); return
    log("INFO", "mdbook_driver::mdbook", "Book building has started")
    chapters = parse_summary(src)
    ensure_chapter_files(src, chapters)
    if dest.exists():
        if dest.is_dir():
            shutil.rmtree(dest)
        else:
            log("ERROR", "mdbook_core::utils", "Error: Rendering failed")
            log("ERROR", "mdbook_core::utils", "\tCaused By: Unable to remove stale HTML output")
            log("ERROR", "mdbook_core::utils", "\tCaused By: Not a directory (os error 20)")
            sys.exit(101)
    dest.mkdir(parents=True, exist_ok=True)
    copy_non_md(src, dest)
    log("INFO", "mdbook_driver::mdbook", "Running the html backend")
    written = []
    first = None
    for ch in chapters:
        if ch.get("type") != "chapter" or not ch.get("path"):
            continue
        md = src / ch["path"]
        if first is None:
            first = ch
        content = markdown_to_html(md.read_text(errors="replace"))
        rel = Path(out_name(ch["path"]))
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        relroot = "../" * (len(rel.parts) - 1)
        target.write_text(render_page(cfg["title"], ch["title"], content, chapters, relroot), encoding="utf-8")
        written.append(target)
    if first and out_name(first["path"]) != "index.html":
        srcfile = dest / out_name(first["path"])
        shutil.copy2(srcfile, dest / "index.html")
    (dest / ".nojekyll").write_text("", encoding="utf-8")
    (dest / "toc.html").write_text("<ol>" + "".join(f"<li>{html.escape(c.get('title',''))}</li>" for c in chapters if c.get("title")) + "</ol>", encoding="utf-8")
    for asset in ("book.js", "toc.js", "searchindex.js", "searcher.js", "highlight.js", "clipboard.min.js", "elasticlunr.min.js"):
        (dest / asset).write_text("// generated by mdbook reimplementation\n", encoding="utf-8")
    for css in ("highlight.css", "tomorrow-night.css", "ayu-highlight.css"):
        (dest / css).write_text("/* generated */\n", encoding="utf-8")
    for d in ("css", "fonts"):
        (dest / d).mkdir(exist_ok=True)
    for css in ("variables.css", "general.css", "chrome.css", "print.css"):
        (dest / "css" / css).write_text("/* generated */\n", encoding="utf-8")
    (dest / "404.html").write_text(render_page(cfg["title"], "404", "<h1>Page not found</h1>", chapters), encoding="utf-8")
    (dest / "print.html").write_text(render_page(cfg["title"], "Print", "\n".join(p.read_text(errors="replace") for p in written), chapters), encoding="utf-8")
    log("INFO", "mdbook_html::html_handlebars::hbs_renderer", f"HTML book written to `{dest}`")


def command_clean(args):
    opts, root, src, dest, cfg = get_paths(args, usage="Usage: executable clean [OPTIONS] [dir]")
    if opts.get("help"):
        print(HELP["clean"]); return
    if opts.get("version"):
        print(VERSION); return
    if dest.exists() and dest.is_dir():
        count = sum(1 for _ in dest.rglob("*")) + 1
        shutil.rmtree(dest)
        print(f"Removed 1 directory, {max(count,1)*4096/1024:.2f}KiB total")


def rust_blocks(text):
    blocks = []
    lines = text.splitlines()
    i = 0
    while i < len(lines):
        m = re.match(r"^```([^`]*)", lines[i])
        if m:
            info = m.group(1).strip()
            buf = []
            i += 1
            while i < len(lines) and not lines[i].startswith("```"):
                buf.append(lines[i]); i += 1
            if ("rust" in info or info == "" or info.startswith("edition")) and "ignore" not in info and "no_run" not in info:
                blocks.append("\n".join(buf))
        i += 1
    return blocks


def command_test(args):
    opts, root, src, dest, cfg = get_paths(args, {"chapter", "library-path"}, usage="Usage: executable test [OPTIONS] [dir]")
    if opts.get("help"):
        print(HELP["test"]); return
    if opts.get("version"):
        print(VERSION); return
    chapters = parse_summary(src)
    failures = 0
    with tempfile.TemporaryDirectory() as td:
        for ch in chapters:
            if ch.get("type") != "chapter" or not ch.get("path"):
                continue
            if opts.get("chapter") and opts["chapter"] not in ch["title"] and opts["chapter"] not in ch["path"]:
                continue
            log("INFO", "mdbook_driver::mdbook", f'Testing chapter \'{ch["title"]}\': "{ch["path"]}"')
            for n, code in enumerate(rust_blocks((src / ch["path"]).read_text(errors="replace"))):
                p = Path(td) / f"test_{len(str(ch['path']))}_{n}.rs"
                if "fn main" not in code and "#![crate_type" not in code:
                    code = "fn main() {\n" + code + "\n}\n"
                p.write_text(code, encoding="utf-8")
                cmd = ["rustc", "--edition=2018", str(p), "-o", str(p.with_suffix(""))]
                libs = opts.get("library-path")
                if libs:
                    for lib in libs.split(","):
                        cmd += ["-L", lib]
                if subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE).returncode != 0:
                    failures += 1
    if failures:
        sys.exit(101)


def command_completions(args):
    if not args or args[0] in ("-h", "--help"):
        print(HELP["completions"]); return
    if args[0] in ("-V", "--version"):
        print(VERSION); return
    shell = args[0]
    if shell not in SHELLS:
        print(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    print(f"# completion script for mdbook ({shell})\n# generated by mdbook reimplementation")


def command_serve(args):
    opts, root, src, dest, cfg = get_paths(args, {"hostname", "port", "watcher"}, allowed_flags={"open"}, usage="Usage: executable serve [OPTIONS] [dir]")
    if opts.get("help"):
        print(HELP["serve"]); return
    command_build([*(["--dest-dir", str(dest)] if dest else []), str(root)])
    host = opts.get("hostname", "localhost")
    port = opts.get("port", "3000")
    print(f"Serving on: http://{host}:{port}")
    os.chdir(dest)
    import http.server
    import socketserver
    with socketserver.TCPServer((host, int(port)), http.server.SimpleHTTPRequestHandler) as httpd:
        httpd.serve_forever()


def command_watch(args):
    opts, root, src, dest, cfg = get_paths(args, {"watcher"}, allowed_flags={"open"}, usage="Usage: executable watch [OPTIONS] [dir]")
    if opts.get("help"):
        print(HELP["watch"]); return
    command_build([*(["--dest-dir", str(dest)] if dest else []), str(root)])
    print("Watching for changes...")
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        return


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        main_help(); return
    if argv[0] in ("-V", "--version"):
        print(VERSION); return
    if argv[0] == "help":
        if len(argv) > 1 and argv[1] in HELP:
            print(HELP[argv[1]])
        else:
            main_help()
        return
    cmd, rest = argv[0], argv[1:]
    if cmd not in HELP:
        if cmd.startswith("-"):
            die_cli(f"unexpected argument '{cmd}' found")
        die_cli(f"unrecognized subcommand '{cmd}'")
    {
        "init": command_init,
        "build": command_build,
        "clean": command_clean,
        "test": command_test,
        "completions": command_completions,
        "serve": command_serve,
        "watch": command_watch,
    }[cmd](rest)


if __name__ == "__main__":
    main(sys.argv[1:])
