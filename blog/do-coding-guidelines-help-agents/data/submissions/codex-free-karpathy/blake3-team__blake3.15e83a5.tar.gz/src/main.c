#define _GNU_SOURCE
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BLAKE3_BLOCK_LEN 64
#define BLAKE3_CHUNK_LEN 1024
#define BLAKE3_KEY_LEN 32

enum {
  CHUNK_START = 1,
  CHUNK_END = 2,
  PARENT = 4,
  ROOT = 8,
  KEYED_HASH = 16,
  DERIVE_KEY_CONTEXT = 32,
  DERIVE_KEY_MATERIAL = 64
};

static const uint32_t IV[8] = {
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19};

static const uint8_t MSG_PERM[16] = {2, 6, 3, 10, 7, 0, 4, 13,
                                     1, 11, 12, 5, 9, 14, 15, 8};

typedef struct {
  uint32_t input_cv[8];
  uint8_t block[BLAKE3_BLOCK_LEN];
  uint8_t block_len;
  uint64_t counter;
  uint8_t flags;
} Output;

static uint32_t rotr32(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

static uint32_t load32(const uint8_t *p) {
  return ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
         ((uint32_t)p[3] << 24);
}

static void store32(uint8_t *p, uint32_t x) {
  p[0] = (uint8_t)x;
  p[1] = (uint8_t)(x >> 8);
  p[2] = (uint8_t)(x >> 16);
  p[3] = (uint8_t)(x >> 24);
}

static void words_from_key_bytes(const uint8_t key[BLAKE3_KEY_LEN], uint32_t out[8]) {
  for (int i = 0; i < 8; i++) out[i] = load32(key + 4 * i);
}

static void g(uint32_t state[16], int a, int b, int c, int d, uint32_t mx, uint32_t my) {
  state[a] = state[a] + state[b] + mx;
  state[d] = rotr32(state[d] ^ state[a], 16);
  state[c] = state[c] + state[d];
  state[b] = rotr32(state[b] ^ state[c], 12);
  state[a] = state[a] + state[b] + my;
  state[d] = rotr32(state[d] ^ state[a], 8);
  state[c] = state[c] + state[d];
  state[b] = rotr32(state[b] ^ state[c], 7);
}

static void round_fn(uint32_t state[16], const uint32_t m[16]) {
  g(state, 0, 4, 8, 12, m[0], m[1]);
  g(state, 1, 5, 9, 13, m[2], m[3]);
  g(state, 2, 6, 10, 14, m[4], m[5]);
  g(state, 3, 7, 11, 15, m[6], m[7]);
  g(state, 0, 5, 10, 15, m[8], m[9]);
  g(state, 1, 6, 11, 12, m[10], m[11]);
  g(state, 2, 7, 8, 13, m[12], m[13]);
  g(state, 3, 4, 9, 14, m[14], m[15]);
}

static void permute(uint32_t m[16]) {
  uint32_t tmp[16];
  for (int i = 0; i < 16; i++) tmp[i] = m[MSG_PERM[i]];
  memcpy(m, tmp, sizeof(tmp));
}

static void compress(const uint32_t cv[8], const uint8_t block[BLAKE3_BLOCK_LEN],
                     uint64_t counter, uint32_t block_len, uint32_t flags,
                     uint32_t out[16]) {
  uint32_t m[16];
  for (int i = 0; i < 16; i++) m[i] = load32(block + 4 * i);

  uint32_t state[16];
  for (int i = 0; i < 8; i++) state[i] = cv[i];
  state[8] = IV[0];
  state[9] = IV[1];
  state[10] = IV[2];
  state[11] = IV[3];
  state[12] = (uint32_t)counter;
  state[13] = (uint32_t)(counter >> 32);
  state[14] = block_len;
  state[15] = flags;

  for (int r = 0; r < 7; r++) {
    round_fn(state, m);
    if (r != 6) permute(m);
  }
  for (int i = 0; i < 8; i++) {
    state[i] ^= state[i + 8];
    state[i + 8] ^= cv[i];
  }
  memcpy(out, state, sizeof(state));
}

static void output_chaining_value(const Output *out, uint32_t cv[8]) {
  uint32_t words[16];
  compress(out->input_cv, out->block, out->counter, out->block_len, out->flags, words);
  memcpy(cv, words, 8 * sizeof(uint32_t));
}

static void parent_output(const uint32_t left[8], const uint32_t right[8],
                          const uint32_t key[8], uint8_t flags, Output *out) {
  memcpy(out->input_cv, key, 8 * sizeof(uint32_t));
  for (int i = 0; i < 8; i++) store32(out->block + 4 * i, left[i]);
  for (int i = 0; i < 8; i++) store32(out->block + 32 + 4 * i, right[i]);
  out->block_len = 64;
  out->counter = 0;
  out->flags = flags | PARENT;
}

static void chunk_output(const uint8_t *input, size_t len, uint64_t chunk_counter,
                         const uint32_t key[8], uint8_t flags, Output *out) {
  uint32_t cv[8];
  memcpy(cv, key, 8 * sizeof(uint32_t));

  size_t offset = 0;
  uint8_t block[64] = {0};
  if (len == 0) {
    memcpy(out->input_cv, cv, 8 * sizeof(uint32_t));
    memset(out->block, 0, 64);
    out->block_len = 0;
    out->counter = chunk_counter;
    out->flags = flags | CHUNK_START | CHUNK_END;
    return;
  }

  while (offset < len) {
    size_t take = len - offset;
    if (take > 64) take = 64;
    memset(block, 0, 64);
    memcpy(block, input + offset, take);
    uint8_t block_flags = flags;
    if (offset == 0) block_flags |= CHUNK_START;
    if (offset + take == len) {
      memcpy(out->input_cv, cv, 8 * sizeof(uint32_t));
      memcpy(out->block, block, 64);
      out->block_len = (uint8_t)take;
      out->counter = chunk_counter;
      out->flags = block_flags | CHUNK_END;
      return;
    } else {
      uint32_t words[16];
      compress(cv, block, chunk_counter, 64, block_flags, words);
      memcpy(cv, words, 8 * sizeof(uint32_t));
    }
    offset += take;
  }
}

static uint64_t next_power_of_two_less_than(uint64_t n) {
  uint64_t p = 1;
  while ((p << 1) < n) p <<= 1;
  return p;
}

static void hash_subtree(const uint8_t *input, size_t len, uint64_t chunk_counter,
                         const uint32_t key[8], uint8_t flags, Output *out) {
  if (len <= BLAKE3_CHUNK_LEN) {
    chunk_output(input, len, chunk_counter, key, flags, out);
    return;
  }

  uint64_t chunks = (len + BLAKE3_CHUNK_LEN - 1) / BLAKE3_CHUNK_LEN;
  uint64_t left_chunks = next_power_of_two_less_than(chunks);
  size_t left_len = (size_t)(left_chunks * BLAKE3_CHUNK_LEN);
  Output left_out, right_out;
  uint32_t left_cv[8], right_cv[8];
  hash_subtree(input, left_len, chunk_counter, key, flags, &left_out);
  hash_subtree(input + left_len, len - left_len, chunk_counter + left_chunks, key, flags, &right_out);
  output_chaining_value(&left_out, left_cv);
  output_chaining_value(&right_out, right_cv);
  parent_output(left_cv, right_cv, key, flags, out);
}

static void finalize_output(const Output *out, uint64_t seek, uint8_t *buf, size_t len) {
  size_t done = 0;
  uint64_t block_counter = seek / 64;
  size_t skip = (size_t)(seek % 64);
  while (done < len) {
    uint32_t words[16];
    uint8_t block[64];
    compress(out->input_cv, out->block, block_counter, out->block_len, out->flags | ROOT, words);
    for (int i = 0; i < 16; i++) store32(block + 4 * i, words[i]);
    size_t take = 64 - skip;
    if (take > len - done) take = len - done;
    memcpy(buf + done, block + skip, take);
    done += take;
    skip = 0;
    block_counter++;
  }
}

static void blake3_hash(const uint8_t *input, size_t len, const uint32_t key[8],
                        uint8_t flags, uint64_t seek, uint8_t *out, size_t out_len) {
  Output root;
  hash_subtree(input, len, 0, key, flags, &root);
  finalize_output(&root, seek, out, out_len);
}

static void derive_key_words(const char *context, uint32_t out_key[8]) {
  uint8_t tmp[32];
  blake3_hash((const uint8_t *)context, strlen(context), IV, DERIVE_KEY_CONTEXT, 0, tmp, 32);
  words_from_key_bytes(tmp, out_key);
}

typedef struct {
  int keyed, derive, no_names, raw, tag, check, quiet;
  size_t length;
  uint64_t seek;
  const char *context;
  const char **files;
  int file_count;
} Options;

static void print_help(void) {
  printf("Usage: executable [OPTIONS] [FILE]...\n\n");
  printf("Arguments:\n  [FILE]...\n          Files to hash, or checkfiles to check\n\n");
  printf("Options:\n      --keyed\n          Use the keyed mode, reading the 32-byte key from stdin\n\n");
  printf("      --derive-key <CONTEXT>\n          Use the key derivation mode, with the given context string\n\n");
  printf("  -l, --length <LEN>\n          The number of output bytes, before hex encoding\n\n");
  printf("      --seek <SEEK>\n          The starting output byte offset, before hex encoding\n\n");
  printf("      --num-threads <NUM>\n          The maximum number of threads to use\n\n");
  printf("      --no-mmap\n          Disable memory mapping\n\n");
  printf("      --no-names\n          Omit filenames in the output\n\n");
  printf("      --raw\n          Write raw output bytes to stdout, rather than hex\n\n");
  printf("      --tag\n          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n\n");
  printf("  -c, --check\n          Read BLAKE3 sums from the [FILE]s and check them\n\n");
  printf("      --quiet\n          Skip printing OK for each checked file\n\n");
  printf("  -h, --help\n          Print help (see a summary with '-h')\n\n");
  printf("  -V, --version\n          Print version\n");
}

static int parse_u64(const char *s, uint64_t *out) {
  char *end = NULL;
  errno = 0;
  unsigned long long v = strtoull(s, &end, 10);
  if (errno || !s[0] || *end) return 0;
  *out = (uint64_t)v;
  return 1;
}

static int read_all_stream(FILE *f, uint8_t **out, size_t *out_len) {
  size_t cap = 8192, len = 0;
  uint8_t *buf = malloc(cap);
  if (!buf) return 0;
  for (;;) {
    if (len == cap) {
      cap *= 2;
      uint8_t *n = realloc(buf, cap);
      if (!n) {
        free(buf);
        return 0;
      }
      buf = n;
    }
    size_t nread = fread(buf + len, 1, cap - len, f);
    len += nread;
    if (nread == 0) {
      if (ferror(f)) {
        free(buf);
        return 0;
      }
      break;
    }
  }
  *out = buf;
  *out_len = len;
  return 1;
}

static int read_file_or_stdin(const char *name, uint8_t **buf, size_t *len, char *errbuf, size_t errlen) {
  if (strcmp(name, "-") == 0) {
    if (!read_all_stream(stdin, buf, len)) {
      snprintf(errbuf, errlen, "failed to read stdin");
      return 0;
    }
    return 1;
  }
  FILE *f = fopen(name, "rb");
  if (!f) {
    snprintf(errbuf, errlen, "%s", strerror(errno));
    return 0;
  }
  int ok = read_all_stream(f, buf, len);
  if (!ok) snprintf(errbuf, errlen, "%s", strerror(errno));
  fclose(f);
  return ok;
}

static void hex_encode(const uint8_t *bytes, size_t len, char *hex) {
  static const char table[] = "0123456789abcdef";
  for (size_t i = 0; i < len; i++) {
    hex[2 * i] = table[bytes[i] >> 4];
    hex[2 * i + 1] = table[bytes[i] & 15];
  }
  hex[2 * len] = 0;
}

static int hash_one(const char *name, const Options *opt, const uint32_t key[8], uint8_t flags) {
  uint8_t *input = NULL;
  size_t input_len = 0;
  char err[256];
  if (!read_file_or_stdin(name, &input, &input_len, err, sizeof(err))) {
    fprintf(stderr, "Error: %s: %s\n", name, err);
    return 1;
  }
  uint8_t *out = malloc(opt->length ? opt->length : 1);
  if (!out) {
    free(input);
    return 1;
  }
  blake3_hash(input, input_len, key, flags, opt->seek, out, opt->length);
  if (opt->raw) {
    fwrite(out, 1, opt->length, stdout);
  } else {
    char *hex = malloc(opt->length * 2 + 1);
    if (!hex) {
      free(input);
      free(out);
      return 1;
    }
    hex_encode(out, opt->length, hex);
    if (opt->no_names) {
      printf("%s\n", hex);
    } else if (opt->tag) {
      printf("BLAKE3 (%s) = %s\n", name, hex);
    } else {
      printf("%s  %s\n", hex, name);
    }
    free(hex);
  }
  free(input);
  free(out);
  return 0;
}

static int parse_hex_byte(char a, char b, uint8_t *out) {
  int hi = (a >= '0' && a <= '9') ? a - '0' : (a >= 'a' && a <= 'f') ? a - 'a' + 10 : (a >= 'A' && a <= 'F') ? a - 'A' + 10 : -1;
  int lo = (b >= '0' && b <= '9') ? b - '0' : (b >= 'a' && b <= 'f') ? b - 'a' + 10 : (b >= 'A' && b <= 'F') ? b - 'A' + 10 : -1;
  if (hi < 0 || lo < 0) return 0;
  *out = (uint8_t)((hi << 4) | lo);
  return 1;
}

static int check_line(char *line, const uint32_t key[8], uint8_t flags, int quiet, int *failed) {
  size_t n = strlen(line);
  while (n && (line[n - 1] == '\n' || line[n - 1] == '\r')) line[--n] = 0;
  if (n == 0) return 0;

  char *hex = line;
  char *name = NULL;
  if (strncmp(line, "BLAKE3 (", 8) == 0) {
    char *mid = strstr(line, ") = ");
    if (!mid) return 0;
    *mid = 0;
    name = line + 8;
    hex = mid + 4;
  } else {
    char *sep = strstr(line, "  ");
    if (!sep) sep = strstr(line, " *");
    if (!sep) return 0;
    *sep = 0;
    name = sep + 2;
  }
  size_t hex_len = strlen(hex);
  if (hex_len == 0 || (hex_len & 1)) return 0;
  size_t out_len = hex_len / 2;
  uint8_t *expected = malloc(out_len);
  uint8_t *actual = malloc(out_len ? out_len : 1);
  if (!expected || !actual) {
    free(expected);
    free(actual);
    return 1;
  }
  for (size_t i = 0; i < out_len; i++) {
    if (!parse_hex_byte(hex[2 * i], hex[2 * i + 1], &expected[i])) {
      free(expected);
      free(actual);
      return 0;
    }
  }

  uint8_t *input = NULL;
  size_t input_len = 0;
  char err[256];
  if (!read_file_or_stdin(name, &input, &input_len, err, sizeof(err))) {
    printf("%s: FAILED (%s (os error %d))\n", name, err, errno ? errno : 2);
    *failed = 1;
    free(expected);
    free(actual);
    return 0;
  }
  blake3_hash(input, input_len, key, flags, 0, actual, out_len);
  if (memcmp(expected, actual, out_len) == 0) {
    if (!quiet) printf("%s: OK\n", name);
  } else {
    printf("%s: FAILED\n", name);
    *failed = 1;
  }
  free(input);
  free(expected);
  free(actual);
  return 0;
}

static int check_file(const char *name, const uint32_t key[8], uint8_t flags, int quiet) {
  FILE *f = strcmp(name, "-") == 0 ? stdin : fopen(name, "r");
  if (!f) {
    fprintf(stderr, "Error: %s: %s\n", name, strerror(errno));
    return 1;
  }
  char *line = NULL;
  size_t cap = 0;
  int failed = 0;
  while (getline(&line, &cap, f) != -1) check_line(line, key, flags, quiet, &failed);
  free(line);
  if (f != stdin) fclose(f);
  if (failed) {
    fflush(stdout);
    fprintf(stderr, "b3sum: WARNING: 1 computed checksum did NOT match\n");
    return 1;
  }
  return 0;
}

static int parse_args(int argc, char **argv, Options *opt) {
  memset(opt, 0, sizeof(*opt));
  opt->length = 32;
  opt->files = malloc(sizeof(char *) * (size_t)argc);
  if (!opt->files) return 0;
  for (int i = 1; i < argc; i++) {
    const char *a = argv[i];
    if (strcmp(a, "--") == 0) {
      while (++i < argc) opt->files[opt->file_count++] = argv[i];
      break;
    }
    if (strcmp(a, "--keyed") == 0) opt->keyed = 1;
    else if (strcmp(a, "--derive-key") == 0) {
      if (++i >= argc) {
        fprintf(stderr, "error: a value is required for '--derive-key <CONTEXT>'\n");
        return 0;
      }
      opt->derive = 1;
      opt->context = argv[i];
    } else if (strncmp(a, "--derive-key=", 13) == 0) {
      opt->derive = 1;
      opt->context = a + 13;
    } else if (strcmp(a, "-l") == 0 || strcmp(a, "--length") == 0) {
      uint64_t v;
      if (++i >= argc || !parse_u64(argv[i], &v)) return 0;
      opt->length = (size_t)v;
    } else if (strncmp(a, "--length=", 9) == 0) {
      uint64_t v;
      if (!parse_u64(a + 9, &v)) return 0;
      opt->length = (size_t)v;
    } else if (strcmp(a, "--seek") == 0) {
      if (++i >= argc || !parse_u64(argv[i], &opt->seek)) return 0;
    } else if (strncmp(a, "--seek=", 7) == 0) {
      if (!parse_u64(a + 7, &opt->seek)) return 0;
    } else if (strcmp(a, "--num-threads") == 0) {
      if (++i >= argc) return 0;
    } else if (strncmp(a, "--num-threads=", 14) == 0) {
    } else if (strcmp(a, "--no-mmap") == 0) {
    } else if (strcmp(a, "--no-names") == 0) opt->no_names = 1;
    else if (strcmp(a, "--raw") == 0) opt->raw = opt->no_names = 1;
    else if (strcmp(a, "--tag") == 0) opt->tag = 1;
    else if (strcmp(a, "-c") == 0 || strcmp(a, "--check") == 0) opt->check = 1;
    else if (strcmp(a, "--quiet") == 0) opt->quiet = 1;
    else if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) {
      print_help();
      exit(0);
    } else if (strcmp(a, "-V") == 0 || strcmp(a, "--version") == 0) {
      printf("b3sum 1.8.4\n");
      exit(0);
    } else if (a[0] == '-' && a[1] != 0) {
      fprintf(stderr, "error: unexpected argument '%s'\n", a);
      return 0;
    } else {
      opt->files[opt->file_count++] = a;
    }
  }
  return 1;
}

int main(int argc, char **argv) {
  Options opt;
  if (!parse_args(argc, argv, &opt)) return 2;
  if (opt.keyed && opt.derive) {
    fprintf(stderr, "Error: Cannot use --derive-key with --keyed\n");
    return 1;
  }
  if (opt.raw && opt.file_count > 1) {
    fprintf(stderr, "Error: Only one filename can be provided when using --raw\n");
    return 1;
  }

  uint32_t key[8];
  memcpy(key, IV, sizeof(key));
  uint8_t flags = 0;
  if (opt.keyed) {
    uint8_t key_bytes[32];
    size_t got = fread(key_bytes, 1, 32, stdin);
    if (got != 32) {
      fprintf(stderr, "Error: expected 32 key bytes from stdin, found %zu\n", got);
      return 1;
    }
    words_from_key_bytes(key_bytes, key);
    flags = KEYED_HASH;
  } else if (opt.derive) {
    derive_key_words(opt.context, key);
    flags = DERIVE_KEY_MATERIAL;
  }

  int status = 0;
  if (opt.check) {
    if (opt.file_count == 0) status |= check_file("-", key, flags, opt.quiet);
    for (int i = 0; i < opt.file_count; i++) status |= check_file(opt.files[i], key, flags, opt.quiet);
  } else {
    if (opt.file_count == 0) status |= hash_one("-", &opt, key, flags);
    for (int i = 0; i < opt.file_count; i++) status |= hash_one(opt.files[i], &opt, key, flags);
  }
  free(opt.files);
  return status ? 1 : 0;
}
