#!/usr/bin/env python3
import json
import os
import re
import shutil
import sys
import unicodedata
from datetime import datetime
from pathlib import Path

VERSION = "rnr 0.5.1"

TOP_HELP = """RnR is a command-line tool to rename multiple files and directories that
supports regular expressions


Usage: executable <COMMAND>

Commands:
  regex      Rename files and directories using a regular expression
  from-file  Read operations from a dump file
  to-ascii   Replace file name UTF-8 chars with ASCII chars representation
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
"""
REGEX_HELP = """Rename files and directories using a regular expression

Usage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...

Arguments:
  <EXPRESSION>   Expression to match (can be a regex)
  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)
  <PATH(S)>...   Target paths

Options:
  -n, --dry-run
          Only show what would be done (default mode)
  -f, --force
          Make actual changes to files
  -b, --backup
          Generate file backups before renaming
  -s, --silent
          Do not print any information
      --color <COLOR>
          Set color output mode [default: auto] [possible values: always, never, auto]
      --dump
          Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>
          Set the dump file prefix [default: rnr-]
      --no-dump
          Do not dump operations into a file
  -l, --replace-limit <LIMIT>
          Limit of replacements, all matches if set to 0
  -t, --replace-transform <REPLACE_TRANSFORM>
          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]
  -D, --include-dirs
          Rename matching directories
  -r, --recursive
          Recursive mode
  -d, --max-depth <LEVEL>
          Set max depth in recursive mode
  -x, --hidden
          Include hidden files and directories
  -h, --help
          Print help
"""
FROM_HELP = """Read operations from a dump file

Usage: executable from-file [OPTIONS] <DUMPFILE>

Arguments:
  <DUMPFILE>  

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -u, --undo                       Undo the operations from the dump file
  -h, --help                       Print help
"""
ASCII_HELP = """Replace file name UTF-8 chars with ASCII chars representation

Usage: executable to-ascii [OPTIONS] <PATH(S)>...

Arguments:
  <PATH(S)>...  Target paths

Options:
  -n, --dry-run                    Only show what would be done (default mode)
  -f, --force                      Make actual changes to files
  -b, --backup                     Generate file backups before renaming
  -s, --silent                     Do not print any information
      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]
      --dump                       Force dumping operations into a file even in dry-run mode
      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]
      --no-dump                    Do not dump operations into a file
  -D, --include-dirs               Rename matching directories
  -r, --recursive                  Recursive mode
  -d, --max-depth <LEVEL>          Set max depth in recursive mode
  -x, --hidden                     Include hidden files and directories
  -h, --help                       Print help
"""

def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)

def ascii_name(s):
    out = unicodedata.normalize('NFKD', s).encode('ascii', 'ignore').decode('ascii')
    return out

def repl_to_python(rep):
    # Convert Rust/CLI style $1 and ${1} captures to Python match expansion.
    rep = re.sub(r"\$\{(\d+)\}", r"\\g<\1>", rep)
    rep = re.sub(r"\$(\d+)", r"\\g<\1>", rep)
    return rep

def parse_common(args, allow_regex=False, allow_tree=False, allow_undo=False):
    opts = {'force': False, 'backup': False, 'silent': False, 'dump': False,
            'no_dump': False, 'dump_prefix': 'rnr-', 'replace_limit': 1,
            'transform': None, 'include_dirs': False, 'recursive': False,
            'max_depth': None, 'hidden': False, 'undo': False}
    pos = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ('-h', '--help'):
            opts['help'] = True
        elif a in ('-n', '--dry-run'):
            opts['force'] = False
        elif a in ('-f', '--force'):
            opts['force'] = True
        elif a in ('-b', '--backup'):
            opts['backup'] = True
        elif a in ('-s', '--silent'):
            opts['silent'] = True
        elif a == '--dump':
            opts['dump'] = True
        elif a == '--no-dump':
            opts['no_dump'] = True
        elif a == '--dump-prefix':
            i += 1
            if i >= len(args): die("error: a value is required for '--dump-prefix <DUMP_PREFIX>'")
            opts['dump_prefix'] = args[i]
        elif a == '--color':
            i += 1
            if i >= len(args): die("error: a value is required for '--color <COLOR>'")
            if args[i] not in ('always','never','auto'): die("error: invalid value for '--color <COLOR>'")
        elif allow_regex and a in ('-l', '--replace-limit'):
            i += 1
            if i >= len(args): die("error: a value is required for '--replace-limit <LIMIT>'")
            try: opts['replace_limit'] = int(args[i])
            except ValueError: die("error: invalid value for '--replace-limit <LIMIT>'")
        elif allow_regex and a in ('-t', '--replace-transform'):
            i += 1
            if i >= len(args): die("error: a value is required for '--replace-transform <REPLACE_TRANSFORM>'")
            if args[i] not in ('upper','lower','ascii'): die("error: invalid value for '--replace-transform <REPLACE_TRANSFORM>'")
            opts['transform'] = args[i]
        elif allow_tree and a in ('-D', '--include-dirs'):
            opts['include_dirs'] = True
        elif allow_tree and a in ('-r', '--recursive'):
            opts['recursive'] = True
        elif allow_tree and a in ('-d', '--max-depth'):
            i += 1
            if i >= len(args): die("error: a value is required for '--max-depth <LEVEL>'")
            try: opts['max_depth'] = int(args[i])
            except ValueError: die("error: invalid value for '--max-depth <LEVEL>'")
        elif allow_tree and a in ('-x', '--hidden'):
            opts['hidden'] = True
        elif allow_undo and a in ('-u', '--undo'):
            opts['undo'] = True
        elif a.startswith('-') and a != '-':
            die(f"error: unexpected argument '{a}' found")
        else:
            pos.append(a)
        i += 1
    return opts, pos

def is_hidden_path(p):
    return any(part.startswith('.') and part not in ('.','..') for part in Path(p).parts)

def collect_targets(paths, recursive=False, include_dirs=False, hidden=False, max_depth=None):
    items = []
    for pstr in paths:
        p = Path(pstr)
        if recursive and p.is_dir():
            root_depth = len(p.parts)
            for root, dirs, files in os.walk(p):
                rootp = Path(root)
                if not hidden:
                    dirs[:] = [d for d in dirs if not d.startswith('.')]
                    files = [f for f in files if not f.startswith('.')]
                depth = len(rootp.parts) - root_depth
                if max_depth is not None and depth >= max_depth:
                    dirs[:] = []
                for f in files:
                    fp = rootp / f
                    if hidden or not is_hidden_path(fp):
                        items.append(fp)
                if include_dirs:
                    for d in dirs:
                        dp = rootp / d
                        if hidden or not is_hidden_path(dp):
                            items.append(dp)
        else:
            if p.exists() and (p.is_file() or (include_dirs and p.is_dir())):
                if hidden or not is_hidden_path(p):
                    items.append(p)
    # The reference has nontrivial ordering; stable reverse lexicographic handles many visible cases.
    items.sort(key=lambda x: str(x), reverse=True)
    return items

def make_regex_op(path, pattern, replacement, limit, transform):
    name = path.name
    try:
        rx = re.compile(pattern)
    except re.error as e:
        die(f"Error: {e}")
    pyrep = repl_to_python(replacement)
    count = 0 if limit == 0 else limit
    def fun(m):
        try:
            r = m.expand(pyrep)
        except re.error:
            r = replacement
        if transform == 'upper': r = r.upper()
        elif transform == 'lower': r = r.lower()
        elif transform == 'ascii': r = ascii_name(r)
        return r
    newname = rx.sub(fun, name, count=count)
    if newname == name:
        return None
    return (str(path), str(path.with_name(newname)))

def make_ascii_op(path):
    newname = ascii_name(path.name)
    if newname == path.name:
        return None
    return (str(path), str(path.with_name(newname)))

def backup_path(src):
    cand = src + '.bak'
    if not os.path.exists(cand): return cand
    n = 1
    while True:
        cand = src + f'.bak{n}'
        if not os.path.exists(cand): return cand
        n += 1

def apply_ops(ops, opts):
    if not opts['force'] and not opts['silent']:
        print("This is a DRY-RUN")
    for src, dst in ops:
        if not opts['silent']:
            print(f"{src} -> {dst}")
    if opts['force']:
        for src, dst in ops:
            if os.path.exists(dst):
                print(f"Error: Conflict with existing path {src} -> {dst}", file=sys.stderr)
                return 1
        for src, dst in ops:
            if not os.path.exists(src):
                print(f"Error: Cannot rename {src} -> {dst}", file=sys.stderr)
                print("No such file or directory (os error 2)", file=sys.stderr)
                return 1
            if opts.get('backup'):
                b = backup_path(src)
                if os.path.isdir(src): shutil.copytree(src, b)
                else: shutil.copy2(src, b)
            os.rename(src, dst)
    return 0

def maybe_dump(ops, opts):
    if not ops or opts.get('no_dump'):
        return
    if not (opts.get('force') or opts.get('dump')):
        return
    now = datetime.now()
    fname = f"{opts.get('dump_prefix','rnr-')}{now.strftime('%Y-%m-%d_%H%M%S')}.json"
    data = {"date": now.strftime('%Y-%m-%d %H:%M:%S'),
            "operations": [{"source": s, "target": t} for s,t in ops]}
    with open(fname, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)

def cmd_regex(args):
    if any(a in ('-h','--help') for a in args):
        print(REGEX_HELP, end=''); return 0
    opts, pos = parse_common(args, allow_regex=True, allow_tree=True)
    if len(pos) < 3:
        print(REGEX_HELP, end=''); return 2
    pattern, replacement, paths = pos[0], pos[1], pos[2:]
    ops = []
    for p in collect_targets(paths, opts['recursive'], opts['include_dirs'], opts['hidden'], opts['max_depth']):
        op = make_regex_op(p, pattern, replacement, opts['replace_limit'], opts['transform'])
        if op: ops.append(op)
    rc = apply_ops(ops, opts)
    if rc == 0: maybe_dump(ops, opts)
    return rc

def cmd_ascii(args):
    if any(a in ('-h','--help') for a in args):
        print(ASCII_HELP, end=''); return 0
    opts, pos = parse_common(args, allow_tree=True)
    if len(pos) < 1:
        print(ASCII_HELP, end=''); return 2
    ops = []
    for p in collect_targets(pos, opts['recursive'], opts['include_dirs'], opts['hidden'], opts['max_depth']):
        op = make_ascii_op(p)
        if op: ops.append(op)
    rc = apply_ops(ops, opts)
    if rc == 0: maybe_dump(ops, opts)
    return rc

def cmd_from_file(args):
    if any(a in ('-h','--help') for a in args):
        print(FROM_HELP, end=''); return 0
    opts, pos = parse_common(args, allow_undo=True)
    if len(pos) != 1:
        print(FROM_HELP, end=''); return 2
    try:
        with open(pos[0], encoding='utf-8') as f: data = json.load(f)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr); return 1
    ops = [(o.get('source',''), o.get('target','')) for o in data.get('operations', [])]
    if opts.get('undo'):
        ops = [(t, s) for s,t in reversed(ops)]
    rc = apply_ops(ops, opts)
    if rc == 0: maybe_dump(ops, opts)
    return rc

def main(argv):
    if len(argv) == 0 or argv[0] in ('-h','--help'):
        print(TOP_HELP, end=''); return 0
    if argv[0] in ('-V','--version'):
        print(VERSION); return 0
    if argv[0] == 'help':
        if len(argv) == 1: print(TOP_HELP, end=''); return 0
        if argv[1] == 'regex': print(REGEX_HELP, end=''); return 0
        if argv[1] == 'from-file': print(FROM_HELP, end=''); return 0
        if argv[1] == 'to-ascii': print(ASCII_HELP, end=''); return 0
        print(TOP_HELP, end=''); return 0
    if argv[0] == 'regex': return cmd_regex(argv[1:])
    if argv[0] == 'from-file': return cmd_from_file(argv[1:])
    if argv[0] == 'to-ascii': return cmd_ascii(argv[1:])
    die(f"error: unrecognized subcommand '{argv[0]}'", 2)

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
