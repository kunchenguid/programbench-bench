#!/usr/bin/env python3
import html.parser
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.sax.saxutils


VERSION = "2.11.1"


HELP = """Usage:
  executable [options] <url>

Application Options:
      --accepted-status-codes=<codes>       Accepted HTTP response status codes
                                            (e.g. '200..300,403') (default:
                                            200..300)
  -b, --buffer-size=<size>                  HTTP response buffer size in bytes
                                            (default: 4096)
  -c, --max-connections=<count>             Maximum number of HTTP connections
                                            (default: 512)
      --max-connections-per-host=<count>    Maximum number of HTTP connections
                                            per host (default: 512)
      --max-response-body-size=<size>       Maximum response body size to read
                                            (default: 10000000)
  -e, --exclude=<pattern>...                Exclude URLs matched with given
                                            regular expressions
  -i, --include=<pattern>...                Include URLs matched with given
                                            regular expressions
      --follow-robots-txt                   Follow robots.txt when scraping
                                            pages
      --follow-sitemap-xml                  Scrape only pages listed in
                                            sitemap.xml (deprecated)
      --header=<header>...                  Custom headers
  -f, --ignore-fragments                    Ignore URL fragments
      --max-retries=<count>                 Maximum retry count for network
                                            errors (default: 0)
      --dns-resolver=<address>              Custom DNS resolver
      --format=[text|json|junit]            Output format (default: text)
      --json                                Output results in JSON (deprecated)
      --experimental-verbose-json           Include successful results in JSON
                                            (deprecated)
      --junit                               Output results as JUnit XML file
                                            (deprecated)
  -r, --max-redirections=<count>            Maximum number of redirections
                                            (default: 64)
      --rate-limit=<rate>                   Max requests per second
  -t, --timeout=<seconds>                   Timeout for HTTP requests in
                                            seconds (default: 10)
  -v, --verbose                             Show successful results too
      --proxy=<host>                        HTTP proxy host
      --skip-tls-verification               Skip TLS certificate verification
      --one-page-only                       Only check links found in the given
                                            URL
      --color=[auto|always|never]           Color output (default: auto)
  -h, --help                                Show this help
      --version                             Show version
"""


class LinkParser(html.parser.HTMLParser):
    ATTRS = {
        "a": ("href",),
        "area": ("href",),
        "audio": ("src",),
        "embed": ("src",),
        "iframe": ("src",),
        "img": ("src", "srcset"),
        "input": ("src",),
        "link": ("href",),
        "object": ("data",),
        "script": ("src",),
        "source": ("src", "srcset"),
        "track": ("src",),
        "video": ("src", "poster"),
    }

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.links = []
        self.ids = set()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "id" in attrs:
            self.ids.add(attrs["id"])
        if "name" in attrs and tag == "a":
            self.ids.add(attrs["name"])
        for name in self.ATTRS.get(tag, ()):
            value = attrs.get(name)
            if not value:
                continue
            if name == "srcset":
                for part in value.split(","):
                    url = part.strip().split(" ")[0]
                    if url:
                        self.links.append(url)
            else:
                self.links.append(value)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def parse_args(argv):
    opts = {
        "accepted": "200..300",
        "buffer": 4096,
        "max_body": 10000000,
        "excludes": [],
        "includes": [],
        "headers": [],
        "ignore_fragments": False,
        "format": "text",
        "verbose": False,
        "timeout": 10.0,
        "one_page": False,
        "max_retries": 0,
        "rate": None,
        "proxy": None,
        "max_redir": 64,
    }
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a == "--version":
            print(VERSION)
            sys.exit(0)
        if a == "--json":
            opts["format"] = "json"
        elif a == "--junit":
            opts["format"] = "junit"
        elif a == "--experimental-verbose-json":
            opts["format"] = "json"
            opts["verbose"] = True
        elif a in ("-v", "--verbose"):
            opts["verbose"] = True
        elif a in ("-f", "--ignore-fragments"):
            opts["ignore_fragments"] = True
        elif a == "--one-page-only":
            opts["one_page"] = True
        elif a in ("--follow-robots-txt", "--follow-sitemap-xml", "--skip-tls-verification"):
            pass
        elif a.startswith("--format="):
            opts["format"] = a.split("=", 1)[1]
        elif a == "--format":
            i += 1
            opts["format"] = argv[i] if i < len(argv) else ""
        elif a.startswith("--accepted-status-codes="):
            opts["accepted"] = a.split("=", 1)[1]
        elif a == "--accepted-status-codes":
            i += 1
            opts["accepted"] = argv[i] if i < len(argv) else ""
        elif a.startswith("--max-response-body-size="):
            opts["max_body"] = int(a.split("=", 1)[1])
        elif a == "--max-response-body-size":
            i += 1
            opts["max_body"] = int(argv[i])
        elif a in ("-t", "--timeout"):
            i += 1
            opts["timeout"] = float(argv[i])
        elif a.startswith("--timeout="):
            opts["timeout"] = float(a.split("=", 1)[1])
        elif a in ("-b", "--buffer-size", "-c", "--max-connections", "--max-connections-per-host", "--dns-resolver"):
            i += 1
        elif any(a.startswith(p + "=") for p in ("--buffer-size", "--max-connections", "--max-connections-per-host", "--dns-resolver", "--color")):
            pass
        elif a in ("-r", "--max-redirections"):
            i += 1
            opts["max_redir"] = int(argv[i])
        elif a.startswith("--max-redirections="):
            opts["max_redir"] = int(a.split("=", 1)[1])
        elif a == "--max-retries":
            i += 1
            opts["max_retries"] = int(argv[i])
        elif a.startswith("--max-retries="):
            opts["max_retries"] = int(a.split("=", 1)[1])
        elif a == "--rate-limit":
            i += 1
            opts["rate"] = float(argv[i])
        elif a.startswith("--rate-limit="):
            opts["rate"] = float(a.split("=", 1)[1])
        elif a in ("-e", "--exclude"):
            i += 1
            opts["excludes"].append(argv[i])
        elif a.startswith("--exclude="):
            opts["excludes"].append(a.split("=", 1)[1])
        elif a in ("-i", "--include"):
            i += 1
            opts["includes"].append(argv[i])
        elif a.startswith("--include="):
            opts["includes"].append(a.split("=", 1)[1])
        elif a == "--header":
            i += 1
            opts["headers"].append(argv[i])
        elif a.startswith("--header="):
            opts["headers"].append(a.split("=", 1)[1])
        elif a == "--proxy":
            i += 1
            opts["proxy"] = argv[i]
        elif a.startswith("--proxy="):
            opts["proxy"] = a.split("=", 1)[1]
        elif a.startswith("-"):
            print(f"unknown flag `{a.lstrip('-')}'")
            sys.exit(1)
        else:
            args.append(a)
        i += 1
    if opts["format"] not in ("text", "json", "junit"):
        print(f"Invalid value `{opts['format']}' for option `--format'. Allowed values are: text, json or junit")
        sys.exit(1)
    if len(args) != 1:
        print("invalid number of arguments")
        sys.exit(1)
    opts["url"] = normalize_start_url(args[0])
    return opts


def normalize_start_url(url):
    parsed = urllib.parse.urlsplit(url)
    if not parsed.scheme:
        url = "http://" + url
    return url


def accepted_set(spec):
    accepted = set()
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        if ".." in part:
            lo, hi = part.split("..", 1)
            accepted.update(range(int(lo), int(hi)))
        else:
            accepted.add(int(part))
    return accepted


def allowed_by_filters(url, opts):
    for pat in opts["excludes"]:
        if re.search(pat, url):
            return False
    if opts["includes"]:
        return any(re.search(pat, url) for pat in opts["includes"])
    return True


def clean_link(base, raw, ignore_fragments):
    raw = raw.strip()
    if not raw or raw.startswith(("mailto:", "tel:", "javascript:", "data:")):
        return None
    url = urllib.parse.urljoin(base, raw)
    p = urllib.parse.urlsplit(url)
    if p.scheme not in ("http", "https"):
        return None
    if ignore_fragments:
        p = p._replace(fragment="")
    return urllib.parse.urlunsplit(p)


def same_site(a, b):
    pa = urllib.parse.urlsplit(a)
    pb = urllib.parse.urlsplit(b)
    return (pa.scheme, pa.netloc) == (pb.scheme, pb.netloc)


def url_without_fragment(url):
    p = urllib.parse.urlsplit(url)
    return urllib.parse.urlunsplit(p._replace(fragment=""))


def request_url(url, opts):
    headers = {"User-Agent": "muffet/2.11.1"}
    for header in opts["headers"]:
        if ":" in header:
            k, v = header.split(":", 1)
            headers[k.strip()] = v.strip()
    handlers = []
    if opts["proxy"]:
        handlers.append(urllib.request.ProxyHandler({"http": opts["proxy"], "https": opts["proxy"]}))
    opener = urllib.request.build_opener(*handlers)
    req = urllib.request.Request(url, headers=headers)
    last = None
    for attempt in range(opts["max_retries"] + 1):
        try:
            with opener.open(req, timeout=opts["timeout"]) as resp:
                body = resp.read(opts["max_body"])
                ctype = resp.headers.get("Content-Type", "")
                final = resp.geturl()
                return resp.getcode(), body, ctype, final, None
        except urllib.error.HTTPError as e:
            body = e.read(opts["max_body"])
            ctype = e.headers.get("Content-Type", "")
            return e.code, body, ctype, e.geturl(), None
        except Exception as e:
            last = e
            if attempt < opts["max_retries"]:
                time.sleep(0.1)
    return None, b"", "", url, str(last)


def parse_html(body):
    parser = LinkParser()
    try:
        text = body.decode("utf-8", "replace")
        parser.feed(text)
    except Exception:
        pass
    return parser.links, parser.ids


def is_html(ctype, body):
    return "html" in ctype.lower() or body.lstrip()[:20].lower().startswith((b"<!doctype html", b"<html"))


def crawl(opts):
    accepted = accepted_set(opts["accepted"])
    queue = [url_without_fragment(opts["url"])]
    seen_pages = set()
    checked = {}
    page_ids = {}
    groups = []
    last_request = 0.0

    while queue:
        page = queue.pop(0)
        if page in seen_pages:
            continue
        seen_pages.add(page)
        if opts["rate"]:
            delay = max(0.0, 1.0 / opts["rate"] - (time.time() - last_request))
            if delay:
                time.sleep(delay)
        last_request = time.time()
        status, body, ctype, final, err = request_url(page, opts)
        links = []
        ids = set()
        page_fetch_error = None
        if err:
            page_fetch_error = err
        elif status not in accepted:
            page_fetch_error = str(status)
        if status is not None and is_html(ctype, body):
            raw_links, ids = parse_html(body)
            links = [clean_link(page, x, opts["ignore_fragments"]) for x in raw_links]
            links = [x for x in links if x and allowed_by_filters(x, opts)]
        page_ids[page] = ids

        records = []
        if page_fetch_error and not links:
            records.append({"url": page, "error": page_fetch_error})
        for link in links:
            target = url_without_fragment(link)
            frag = urllib.parse.urlsplit(link).fragment
            if target not in checked:
                if opts["rate"]:
                    delay = max(0.0, 1.0 / opts["rate"] - (time.time() - last_request))
                    if delay:
                        time.sleep(delay)
                last_request = time.time()
                checked[target] = request_url(target, opts)
                if checked[target][0] is not None and is_html(checked[target][2], checked[target][1]):
                    _, tb, _, _, _ = checked[target]
                    _, tids = parse_html(tb)
                    page_ids[target] = tids
            st, _b, _ct, _final, reqerr = checked[target]
            rec = {"url": link}
            if reqerr:
                rec["error"] = reqerr
            elif st not in accepted:
                rec["error"] = str(st)
            elif frag and not opts["ignore_fragments"]:
                if target not in page_ids:
                    page_ids[target] = parse_html(_b)[1] if _b else set()
                if frag not in page_ids.get(target, set()):
                    rec["error"] = "id #" + frag + " not found"
                else:
                    rec["status"] = st
            else:
                rec["status"] = st
            records.append(rec)

            if not opts["one_page"] and same_site(opts["url"], target):
                if target not in seen_pages and target not in queue:
                    st2, b2, ct2, _f2, e2 = checked.get(target, (None, b"", "", target, None))
                    if e2 is None and st2 in accepted and is_html(ct2, b2):
                        queue.append(target)
        if records:
            groups.append({"url": page, "links": records})
    return groups


def has_failures(groups):
    return any("error" in link for g in groups for link in g["links"])


def filtered_groups(groups, verbose):
    out = []
    for g in groups:
        links = [l for l in g["links"] if verbose or "error" in l]
        if links:
            out.append({"url": g["url"], "links": links})
    return out


def print_text(groups, verbose):
    for g in filtered_groups(groups, verbose):
        print(g["url"])
        for link in g["links"]:
            value = link.get("error", str(link.get("status", "")))
            print(f"\t{value}\t{link['url']}")


def print_json(groups, verbose):
    print(json.dumps(filtered_groups(groups, verbose), separators=(",", ":")))


def print_junit(groups):
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print("<testsuites>")
    for g in groups:
        failures = sum(1 for l in g["links"] if "error" in l)
        print(f'  <testsuite name="{xml.sax.saxutils.escape(g["url"])}" tests="{len(g["links"])}" failures="{failures}" skipped="0">')
        for l in g["links"]:
            name = xml.sax.saxutils.escape(l["url"])
            cls = xml.sax.saxutils.escape(g["url"])
            if "error" in l:
                msg = xml.sax.saxutils.escape(l["error"])
                print(f'    <testcase name="{name}" classname="{cls}">')
                print(f'      <failure message="{msg}"></failure>')
                print("    </testcase>")
            else:
                print(f'    <testcase name="{name}" classname="{cls}"></testcase>')
        print("  </testsuite>")
    print("</testsuites>")


def main(argv):
    opts = parse_args(argv)
    groups = crawl(opts)
    failed = has_failures(groups)
    if opts["format"] == "json":
        print_json(groups, opts["verbose"])
    elif opts["format"] == "junit":
        print_junit(groups)
    else:
        print_text(groups, opts["verbose"])
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
