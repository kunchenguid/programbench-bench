#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#define MAX_COMMITS 512
#define MAX_FILES 128

typedef struct {
    char hash[64];
    char short_hash[16];
    char decorations[256];
    char label[128];
    char date[32];
    char author[128];
    char subject[512];
} Commit;

typedef struct {
    char path[512];
    char status[8];
    int added;
    int deleted;
    bool binary;
} FileStat;

static struct termios saved_termios;
static bool raw_enabled = false;

static void print_help(void) {
    puts("A TUI tool to visualize Git commit graphs with branch genealogy\n");
    puts("Usage: executable\n");
    puts("Options:");
    puts("  -h, --help     Print help");
    puts("  -V, --version  Print version");
}

static void print_version(void) {
    puts("keifu 0.2.3");
}

static void unexpected_arg(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "Usage: executable\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
}

static void trim_newline(char *s) {
    size_t n = strlen(s);
    while (n && (s[n - 1] == '\n' || s[n - 1] == '\r')) {
        s[--n] = '\0';
    }
}

static void copy_field(char *dst, size_t dstsz, const char *src) {
    if (dstsz == 0) return;
    if (!src) src = "";
    snprintf(dst, dstsz, "%s", src);
}

static FILE *run_git(const char *fmt, ...) {
    char cmd[2048];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(cmd, sizeof(cmd), fmt, ap);
    va_end(ap);
    return popen(cmd, "r");
}

static int command_status(const char *cmd) {
    int rc = system(cmd);
    if (rc == -1) return 127;
    if (WIFEXITED(rc)) return WEXITSTATUS(rc);
    return 128;
}

static bool read_first_line(const char *cmd, char *buf, size_t bufsz) {
    FILE *fp = popen(cmd, "r");
    if (!fp) return false;
    bool ok = fgets(buf, (int)bufsz, fp) != NULL;
    int st = pclose(fp);
    if (!ok || st == -1 || !WIFEXITED(st) || WEXITSTATUS(st) != 0) return false;
    trim_newline(buf);
    return true;
}

static const char *base_name(const char *path) {
    const char *slash = strrchr(path, '/');
    return slash ? slash + 1 : path;
}

static void derive_label(Commit *c, const char *current_branch) {
    c->label[0] = '\0';
    char tmp[256];
    copy_field(tmp, sizeof(tmp), c->decorations);
    char *save = NULL;
    for (char *tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        while (*tok == ' ') tok++;
        if (strcmp(tok, "HEAD") == 0) continue;
        if (strncmp(tok, "HEAD -> ", 8) == 0) tok += 8;
        if (strncmp(tok, "tag: ", 5) == 0) tok += 5;
        if (strncmp(tok, "origin/", 7) == 0 && c->label[0]) continue;
        copy_field(c->label, sizeof(c->label), tok);
        break;
    }
    if (!c->label[0] && current_branch && current_branch[0]) {
        copy_field(c->label, sizeof(c->label), current_branch);
    }
}

static int load_commits(Commit commits[], int max, const char *current_branch) {
    FILE *fp = run_git("git log --all --date=short --pretty=format:'%%H%%x1f%%h%%x1f%%D%%x1f%%ad%%x1f%%an%%x1f%%s' -n %d 2>/dev/null", max);
    if (!fp) return 0;
    char line[2048];
    int count = 0;
    while (count < max && fgets(line, sizeof(line), fp)) {
        trim_newline(line);
        char *fields[6] = {0};
        char *p = line;
        for (int i = 0; i < 6; i++) {
            fields[i] = p;
            char *sep = strchr(p, '\x1f');
            if (!sep) {
                if (i < 5) fields[i + 1] = "";
                break;
            }
            *sep = '\0';
            p = sep + 1;
        }
        Commit *c = &commits[count++];
        memset(c, 0, sizeof(*c));
        copy_field(c->hash, sizeof(c->hash), fields[0]);
        copy_field(c->short_hash, sizeof(c->short_hash), fields[1]);
        copy_field(c->decorations, sizeof(c->decorations), fields[2]);
        copy_field(c->date, sizeof(c->date), fields[3]);
        copy_field(c->author, sizeof(c->author), fields[4]);
        copy_field(c->subject, sizeof(c->subject), fields[5]);
        derive_label(c, current_branch);
    }
    pclose(fp);
    return count;
}

static void load_commit_detail(const char *hash, char *author, size_t author_sz,
                               char *date, size_t date_sz, char *message, size_t message_sz) {
    FILE *fp = run_git("git show -s --date=format:'%%Y-%%m-%%d %%H:%%M:%%S' --pretty=format:'%%an <%%ae>%%x1f%%ad%%x1f%%B' '%s' 2>/dev/null", hash);
    if (!fp) return;
    char *buf = NULL;
    size_t cap = 0;
    ssize_t len = getdelim(&buf, &cap, '\0', fp);
    pclose(fp);
    if (len <= 0 || !buf) {
        free(buf);
        return;
    }
    char *a = buf;
    char *sep1 = strchr(a, '\x1f');
    if (!sep1) {
        free(buf);
        return;
    }
    *sep1 = '\0';
    char *d = sep1 + 1;
    char *sep2 = strchr(d, '\x1f');
    if (!sep2) {
        free(buf);
        return;
    }
    *sep2 = '\0';
    char *m = sep2 + 1;
    trim_newline(m);
    copy_field(author, author_sz, a);
    copy_field(date, date_sz, d);
    copy_field(message, message_sz, m);
    free(buf);
}

static int load_file_stats(const char *hash, FileStat files[], int max, int *total_add, int *total_del) {
    *total_add = 0;
    *total_del = 0;
    FILE *fp = run_git("git show --numstat --format= '%s' 2>/dev/null", hash);
    if (!fp) return 0;
    char line[1024];
    int count = 0;
    while (count < max && fgets(line, sizeof(line), fp)) {
        trim_newline(line);
        if (!line[0]) continue;
        char a[32], d[32], path[512];
        if (sscanf(line, "%31s\t%31s\t%511[^\n]", a, d, path) == 3) {
            FileStat *f = &files[count++];
            memset(f, 0, sizeof(*f));
            copy_field(f->path, sizeof(f->path), path);
            copy_field(f->status, sizeof(f->status), "M");
            if (strcmp(a, "-") == 0 || strcmp(d, "-") == 0) {
                f->binary = true;
            } else {
                f->added = atoi(a);
                f->deleted = atoi(d);
                *total_add += f->added;
                *total_del += f->deleted;
            }
        }
    }
    pclose(fp);

    fp = run_git("git show --name-status --format= '%s' 2>/dev/null", hash);
    if (fp) {
        int idx = 0;
        while (idx < count && fgets(line, sizeof(line), fp)) {
            trim_newline(line);
            if (!line[0]) continue;
            char status[8], path[512];
            if (sscanf(line, "%7s\t%511[^\n]", status, path) == 2) {
                copy_field(files[idx].status, sizeof(files[idx].status), status);
                idx++;
            }
        }
        pclose(fp);
    }
    return count;
}

static int term_width(void) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 20) return ws.ws_col;
    char *cols = getenv("COLUMNS");
    if (cols && atoi(cols) > 20) return atoi(cols);
    return 100;
}

static int term_height(void) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 8) return ws.ws_row;
    char *rows = getenv("LINES");
    if (rows && atoi(rows) > 8) return atoi(rows);
    return 30;
}

static int visible_len(const char *s) {
    int n = 0;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if ((*p & 0xc0) != 0x80) n++;
    }
    return n;
}

static void print_fit(const char *s, int width) {
    int used = 0;
    for (const unsigned char *p = (const unsigned char *)s; *p && used < width; ) {
        int bytes = 1;
        if ((*p & 0xe0) == 0xc0) bytes = 2;
        else if ((*p & 0xf0) == 0xe0) bytes = 3;
        else if ((*p & 0xf8) == 0xf0) bytes = 4;
        if (used + 1 > width) break;
        fwrite(p, 1, bytes, stdout);
        p += bytes;
        used++;
    }
    while (used++ < width) putchar(' ');
}

static void border_top(const char *title, int width) {
    printf("┌ %s ", title);
    int rem = width - visible_len(title) - 4;
    for (int i = 0; i < rem; i++) printf("─");
    printf("┐\n");
}

static void border_bottom(int width) {
    printf("└");
    for (int i = 0; i < width - 2; i++) printf("─");
    printf("┘\n");
}

static void render(const char *repo, const char *branch, Commit commits[], int n, int selected) {
    int w = term_width();
    int h = term_height();
    if (w < 60) w = 60;
    if (h < 12) h = 12;
    int list_h = h * 2 / 3 - 1;
    if (list_h < 5) list_h = 5;
    int detail_h = h - list_h - 2;
    if (detail_h < 4) detail_h = 4;

    char author[256] = "", date[64] = "", message[1024] = "";
    FileStat files[MAX_FILES];
    int file_count = 0, total_add = 0, total_del = 0;
    if (n > 0) {
        load_commit_detail(commits[selected].hash, author, sizeof(author), date, sizeof(date), message, sizeof(message));
        file_count = load_file_stats(commits[selected].hash, files, MAX_FILES, &total_add, &total_del);
    }

    printf("\033[?1049h\033[?25l\033[H");
    border_top("Commits", w);
    for (int i = 0; i < list_h - 2; i++) {
        printf("│");
        if (i < n) {
            char row[2048];
            char label[180] = "";
            if (commits[i].label[0]) snprintf(label, sizeof(label), "[%s] ", commits[i].label);
            snprintf(row, sizeof(row), "%s %s%s  %s  %s  %s",
                     i == selected ? "◉" : "│",
                     label,
                     commits[i].subject,
                     commits[i].date,
                     commits[i].author,
                     commits[i].short_hash);
            if (i == selected) printf("\033[1m\033[48;5;8m ");
            else printf(" ");
            print_fit(row, w - 3);
            if (i == selected) printf("\033[0m");
        } else {
            for (int j = 0; j < w - 2; j++) putchar(' ');
        }
        printf("│\n");
    }
    border_bottom(w);

    int left = w / 2;
    int right = w - left;
    printf("┌ Commit Detail ");
    for (int i = 0; i < left - 17; i++) printf("─");
    printf("┐┌ Changed Files ");
    for (int i = 0; i < right - 17; i++) printf("─");
    printf("┐\n");

    for (int line = 0; line < detail_h - 2; line++) {
        char lbuf[1024] = "", rbuf[1024] = "";
        if (n == 0) {
            if (line == 0) snprintf(lbuf, sizeof(lbuf), "No commits found");
        } else if (line == 0) {
            snprintf(lbuf, sizeof(lbuf), "Commit: %s", commits[selected].hash);
            snprintf(rbuf, sizeof(rbuf), "%d files changed  +%d -%d", file_count, total_add, total_del);
        } else if (line == 1) {
            snprintf(lbuf, sizeof(lbuf), "Author: %s", author[0] ? author : commits[selected].author);
        } else if (line == 2) {
            snprintf(lbuf, sizeof(lbuf), "Date:   %s", date[0] ? date : commits[selected].date);
        } else if (line == 4) {
            snprintf(lbuf, sizeof(lbuf), "%s", message[0] ? message : commits[selected].subject);
        }
        if (line >= 2 && line - 2 < file_count) {
            FileStat *f = &files[line - 2];
            if (f->binary) snprintf(rbuf, sizeof(rbuf), " %s %s", f->status, f->path);
            else snprintf(rbuf, sizeof(rbuf), " %s %s +%d -%d", f->status, f->path, f->added, f->deleted);
        }
        printf("│");
        print_fit(lbuf, left - 2);
        printf("││");
        print_fit(rbuf, right - 2);
        printf("│\n");
    }
    printf("└");
    for (int i = 0; i < left - 2; i++) printf("─");
    printf("┘└");
    for (int i = 0; i < right - 2; i++) printf("─");
    printf("┘\n");

    char status[1024];
    snprintf(status, sizeof(status), " %s  %s   j/k move  Enter checkout  b branch  f fetch  ? help  q quit",
             repo && repo[0] ? repo : "workspace",
             branch && branch[0] ? branch : "HEAD");
    print_fit(status, w);
    fflush(stdout);
}

static void restore_terminal(void) {
    if (raw_enabled) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &saved_termios);
        raw_enabled = false;
    }
    printf("\033[?1049l\033[?25h");
    fflush(stdout);
}

static void enable_raw(void) {
    if (tcgetattr(STDIN_FILENO, &saved_termios) == 0) {
        struct termios raw = saved_termios;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 1;
        if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) == 0) {
            raw_enabled = true;
            atexit(restore_terminal);
        }
    }
}

static void checkout_selected(const Commit *c) {
    if (!c) return;
    if (c->label[0] && strncmp(c->label, "origin/", 7) != 0) {
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "git checkout '%s' >/dev/null 2>&1", c->label);
        command_status(cmd);
    } else {
        char cmd[512];
        snprintf(cmd, sizeof(cmd), "git checkout '%s' >/dev/null 2>&1", c->hash);
        command_status(cmd);
    }
}

static int run_tui(void) {
    char root[1024] = "";
    if (!read_first_line("git rev-parse --show-toplevel 2>/dev/null", root, sizeof(root))) {
        fprintf(stderr, "Error: Git repository not found. Please run inside a Git repository.\n\n");
        fprintf(stderr, "Caused by:\n");
        fprintf(stderr, "    could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n");
        return 1;
    }

    char branch[128] = "";
    read_first_line("git branch --show-current 2>/dev/null", branch, sizeof(branch));
    if (!branch[0]) read_first_line("git rev-parse --short HEAD 2>/dev/null", branch, sizeof(branch));

    Commit commits[MAX_COMMITS];
    int n = load_commits(commits, MAX_COMMITS, branch);
    int selected = 0;
    const char *repo = base_name(root);

    bool interactive = isatty(STDIN_FILENO);
    if (interactive) enable_raw();
    render(repo, branch, commits, n, selected);

    if (!interactive) {
        int ch;
        while ((ch = getchar()) != EOF) {
            if (ch == 'q' || ch == 27) break;
        }
        restore_terminal();
        return 0;
    }

    for (;;) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(STDIN_FILENO, &rfds);
        struct timeval tv = {1, 0};
        int rc = select(STDIN_FILENO + 1, &rfds, NULL, NULL, &tv);
        if (rc < 0 && errno == EINTR) continue;
        if (rc <= 0) continue;
        unsigned char ch;
        if (read(STDIN_FILENO, &ch, 1) != 1) continue;
        if (ch == 'q' || ch == 27) break;
        if ((ch == 'j' || ch == 'B') && selected + 1 < n) selected++;
        else if ((ch == 'k' || ch == 'A') && selected > 0) selected--;
        else if (ch == 'g') selected = 0;
        else if (ch == 'G' && n > 0) selected = n - 1;
        else if (ch == 'f') command_status("git fetch origin >/dev/null 2>&1");
        else if (ch == '\r' || ch == '\n') checkout_selected(n > 0 ? &commits[selected] : NULL);
        if (ch == 'f' || ch == '\r' || ch == '\n') {
            read_first_line("git branch --show-current 2>/dev/null", branch, sizeof(branch));
            n = load_commits(commits, MAX_COMMITS, branch);
            if (selected >= n) selected = n ? n - 1 : 0;
        }
        render(repo, branch, commits, n, selected);
    }
    restore_terminal();
    return 0;
}

int main(int argc, char **argv) {
    signal(SIGPIPE, SIG_IGN);
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--") == 0) {
            continue;
        }
        if (strcmp(argv[i], "-h") == 0 || strcmp(argv[i], "--help") == 0) {
            print_help();
            return 0;
        }
        if (strcmp(argv[i], "-V") == 0 || strcmp(argv[i], "--version") == 0) {
            print_version();
            return 0;
        }
        unexpected_arg(argv[i]);
        return 2;
    }
    return run_tui();
}
