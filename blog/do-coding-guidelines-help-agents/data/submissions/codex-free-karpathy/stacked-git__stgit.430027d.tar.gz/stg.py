#!/usr/bin/env python3
import json
import os
import re
import shutil
import subprocess
import sys


VERSION = """Stacked Git 2.5.5
Copyright (C) 2005-2025 StGit authors
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
SPDX-License-Identifier: GPL-2.0-only"""

MAIN_HELP = """Maintain a stack of patches on top of a Git branch.

Usage: stg [OPTIONS] <command> [...]
       stg [OPTIONS] <-h|--help>
       stg --version

Patch inspection commands:
  diff   Show a diff
  files  Show files modified by a patch
  id     Print git hash of a StGit revision
  log    Display or optionally clear the stack changelog
  name   Print patch name of a StGit revision
  show   Show patch commits

Patch manipulation commands:
  edit     Edit a patch
  fold     Fold diff file into the current patch
  new      Create a new patch at top of the stack
  refresh  Incorporate worktree changes into current patch
  rename   Rename a patch
  spill    Spill changes from the topmost patch
  sync     Synchronize patches with a branch or a series

Stack inspection commands:
  email    Format and send patches as email
  export   Export patches to a directory
  next     Print the name of the next patch
  patches  Show patches that modify files
  prev     Print the name of the previous patch
  series   Display the patch series
  top      Print the name of the top patch

Stack manipulation commands:
  branch    Branch operations: switch, list, create, rename, delete, ...
  clean     Delete empty patches from the series
  commit    Finalize patches to the stack base
  delete    Delete patches
  float     Push patches to the top, even if applied
  goto      Go to patch by pushing or popping as necessary
  hide      Hide patches in the series
  import    Import patches to stack
  init      Initialize a StGit stack on a branch
  pick      Import a patch from another branch or a commit object
  pop       Pop (unapply) one or more applied patches
  pull      Pull changes from a remote repository
  push      Push (apply) one or more unapplied patches
  rebase    Move the stack base to another point in history
  redo      Undo the last undo operation
  repair    Repair stack after branch is modified with git commands
  reset     Reset the patch stack to an earlier state
  sink      Move patches deeper in the stack
  squash    Squash two or more patches into one
  uncommit  Convert regular Git commits into StGit patches
  undo      Undo the last command
  unhide    Unhide hidden patches

Administration commands:
  completion  Support for shell completions
  version     Print version information and exit

Aliases:
  add       Alias for shell command `git -C "$GIT_PREFIX" add`
  mv        Alias for shell command `git -C "$GIT_PREFIX" mv`
  resolved  Alias for shell command `git -C "$GIT_PREFIX" add`
  rm        Alias for shell command `git -C "$GIT_PREFIX" rm`
  status    Alias for shell command `git status -s`

Help:
  help  Print this message or the help of the given subcommand(s)

Options:
      --version
          Print version information

  -C <path>
          Run as if stg was started in '<path>' instead of the current working
          directory.

      --color <when>
          Specify when to colorize the output.

  -h, --help
          Print help (see a summary with '-h')"""

HELPS = {
    "init": """Initialize a StGit stack on a branch.

Usage: stg init [OPTIONS]

Options:
  -b, --branch <branch>
          Use <branch> instead of current branch

  -h, --help
          Print help (see a summary with '-h')""",
    "series": """Show all the patches in the series, or just those in the given range, ordered from
bottom to top.

The topmost applied patch is prefixed with '>'. All other applied patches are prefixed
with '+'. Unapplied patches are prefixed with '-' and hidden patches with '!'.

Usage: stg series [OPTIONS] [-A] [-U] [-H]
       stg series [OPTIONS] --all
       stg series [OPTIONS] --short
       stg series [OPTIONS] [patch]...

Options:
  -a, --all
          Select all patches, including hidden patches
  -A, --applied
          Select the applied patches only
  -U, --unapplied
          Select the unapplied patches only
  -c, --count
          Display the number of selected patches and exit
  -h, --help
          Print help (see a summary with '-h')""",
    "new": """Create a new, empty patch on the current stack.

Usage: stg new [OPTIONS] [patchname] [-- <path>...]
       stg new [OPTIONS] [--name <patchname>] [-- <path>...]

Options:
  -n, --name <name>
          Alternative to the [patchname] argument for specifying the name of the new
          patch.
  -m, --message <message>
          Use message instead of invoking the editor
  -r, --refresh
          Refresh the new patch with changes from work tree.
  -h, --help
          Print help (see a summary with '-h')""",
    "top": "Print the name of the top patch.\n\nUsage: stg top [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
    "next": "Print the name of the next patch.\n\nUsage: stg next [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
    "prev": "Print the name of the previous patch.\n\nUsage: stg prev [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
    "diff": "Show the diff.\n\nUsage: stg diff [OPTIONS] [path]...\n\nOptions:\n  -r, --range <revspec>\n          Show diff between specified revisions.\n  -s, --stat\n          Show the stat instead of the diff\n  -h, --help\n          Print help (see a summary with '-h')",
    "files": "Show the files modified by a patch.\n\nUsage: stg files [OPTIONS] [revision]\n\nOptions:\n  -s, --stat\n          Show patch's diffstat\n      --bare\n          Print bare file names.\n  -h, --help\n          Print help (see a summary with '-h')",
    "id": "Print the hash (object id) of a StGit revision.\n\nUsage: stg id [OPTIONS] [revision]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
    "name": "Print the patch name of a StGit revision.\n\nUsage: stg name [OPTIONS] [revision]\n\nOptions:\n      --showbranch\n          Display the branch name with the patch\n  -h, --help\n          Print help (see a summary with '-h')",
    "show": "Show the commit log and diff corresponding to the given patches.\n\nUsage: stg show [OPTIONS] [patch-or-rev]... [-- <path>...]\n\nOptions:\n  -s, --stat\n          Show a diffstat summary instead of the full diff\n  -h, --help\n          Print help (see a summary with '-h')",
    "push": "Push one or more unapplied patches from the series onto the stack.\n\nUsage: stg push [OPTIONS] [patch]...\n       stg push [OPTIONS] -n <number>\n       stg push [OPTIONS] --all\n\nOptions:\n  -a, --all\n          Push all unapplied patches\n  -n, --number <n>\n          Push the specified number of patches.\n  -h, --help\n          Print help (see a summary with '-h')",
    "pop": "Pop (unapply) one or more applied patches.\n\nUsage: stg pop [OPTIONS] [patch]...\n       stg pop [OPTIONS] --all\n       stg pop [OPTIONS] -n <number>\n\nOptions:\n  -a, --all\n          Pop all applied patches\n  -n, --number <number>\n          Pop the specified <number> of patches.\n  -h, --help\n          Print help (see a summary with '-h')",
    "refresh": "Include the latest work tree and index changes in the current patch.\n\nUsage: stg refresh [OPTIONS] [path]...\n\nOptions:\n  -i, --index\n          Use the current contents of the index.\n  -h, --help\n          Print help (see a summary with '-h')",
    "delete": "Delete patches\n\nUsage: stg delete [OPTIONS] [<patch>...]\n       stg delete [OPTIONS] --all\n       stg delete [OPTIONS] --top\n\nOptions:\n  -a, --all\n          Delete all patches\n  -t, --top\n          Delete topmost patch\n  -h, --help\n          Print help (see a summary with '-h')",
    "branch": "Create, clone, switch, rename, or delete StGit-enabled branches.\n\nUsage: stg branch\n       stg branch [--merge] <branch>\n       stg branch {--list,-l}\n       stg branch {--create,-c} <new-branch> [committish]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
    "rename": "Rename a patch.\n\nUsage: stg rename [oldpatch] <newpatch>\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
    "pick": "Import a patch from another branch or a commit object.\n\nUsage: stg pick [OPTIONS] <commit-ish>...\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
    "uncommit": "Convert regular Git commits into StGit patches.\n\nUsage: stg uncommit [OPTIONS] [commit]...\n\nOptions:\n  -n, --number <n>\n          Uncommit the specified number of patches\n  -h, --help\n          Print help (see a summary with '-h')",
    "clean": "Delete empty patches from the series.\n\nUsage: stg clean [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')",
}


def eprint(msg):
    print(msg, file=sys.stderr)


def run_git(args, check=True, capture=True):
    p = subprocess.run(["git"] + args, text=True, stdout=subprocess.PIPE if capture else None,
                       stderr=subprocess.PIPE if capture else None)
    if check and p.returncode != 0:
        if capture and p.stderr:
            sys.stderr.write(p.stderr)
        raise SystemExit(p.returncode)
    return p


def ensure_repo():
    p = run_git(["rev-parse", "--git-dir"], check=False)
    if p.returncode != 0:
        eprint("error: Could not find a git repository in '.' or in any of its parents")
        raise SystemExit(2)
    return p.stdout.strip()


def branch():
    ensure_repo()
    p = run_git(["symbolic-ref", "--quiet", "--short", "HEAD"], check=False)
    if p.returncode != 0:
        eprint("error: not on a branch")
        raise SystemExit(2)
    return p.stdout.strip()


def state_path(br=None):
    gd = ensure_repo()
    br = br or branch()
    return os.path.join(gd, "stgit-lite", br.replace("/", "__") + ".json")


def load_state(init=False):
    br = branch()
    path = state_path(br)
    if not os.path.exists(path):
        if init:
            st = {"branch": br, "base": git_stdout(["rev-parse", "HEAD"]), "patches": []}
            save_state(st)
            return st
        return {"branch": br, "base": git_stdout(["rev-parse", "HEAD"]), "patches": []}
    with open(path) as f:
        return json.load(f)


def save_state(st):
    path = state_path(st.get("branch") or branch())
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(st, f, indent=2, sort_keys=True)


def git_stdout(args):
    return run_git(args).stdout.strip()


def applied(st):
    return [p for p in st["patches"] if p.get("applied", True)]


def unapplied(st):
    return [p for p in st["patches"] if not p.get("applied", True)]


def find_patch(st, name):
    for p in st["patches"]:
        if p["name"] == name:
            return p
    return None


def top_patch(st):
    a = applied(st)
    return a[-1] if a else None


def slug(s):
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9._-]+", "-", s).strip("-")
    return s or "patch"


def parse_message(args):
    msg = None
    name = None
    refresh = False
    index = False
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-m", "--message"):
            i += 1
            if i >= len(args):
                eprint("error: a value is required for '--message <message>'")
                raise SystemExit(2)
            msg = args[i]
        elif a.startswith("--message="):
            msg = a.split("=", 1)[1]
        elif a in ("-n", "--name"):
            i += 1
            name = args[i]
        elif a.startswith("--name="):
            name = a.split("=", 1)[1]
        elif a in ("-r", "--refresh"):
            refresh = True
        elif a in ("-i", "--index"):
            index = True
        elif a == "--":
            rest.extend(args[i + 1:])
            break
        elif a.startswith("-"):
            pass
        elif name is None:
            name = a
        else:
            rest.append(a)
        i += 1
    if msg is None:
        msg = name or "New patch"
    if name is None:
        name = slug(msg.splitlines()[0])
    return name, msg, refresh or bool(rest), index, rest


def cmd_init(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["init"])
        return 0
    st = load_state(init=True)
    save_state(st)
    return 0


def cmd_new(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["new"])
        return 0
    st = load_state(init=True)
    name, msg, do_refresh, index, paths = parse_message(args)
    if "/" in name or name in ("", ".", "..") or find_patch(st, name):
        eprint(f"error: invalid or duplicate patch name `{name}`")
        return 2
    if do_refresh:
        add_args = paths if paths else ["-A"]
        run_git(["add"] + add_args)
        run_git(["commit", "--allow-empty", "-m", msg])
    else:
        run_git(["commit", "--allow-empty", "-m", msg])
    oid = git_stdout(["rev-parse", "HEAD"])
    st["patches"].append({"name": name, "commit": oid, "message": msg, "applied": True})
    save_state(st)
    print(f"> {name} (new)")
    return 0


def cmd_series(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["series"])
        return 0
    st = load_state()
    count = any(a in ("-c", "--count") for a in args)
    only_a = any(a in ("-A", "--applied") for a in args)
    only_u = any(a in ("-U", "--unapplied") for a in args)
    arr = st["patches"]
    if only_a:
        arr = applied(st)
    if only_u:
        arr = unapplied(st)
    if count:
        print(len(arr))
        return 0
    top = top_patch(st)
    for p in arr:
        pref = ">" if top and p["name"] == top["name"] else ("+" if p.get("applied", True) else "-")
        print(f"{pref} {p['name']}")
    return 0


def cmd_top(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["top"])
        return 0
    p = top_patch(load_state())
    if not p:
        eprint("error: no patches applied")
        return 2
    print(p["name"])
    return 0


def cmd_next(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["next"])
        return 0
    u = unapplied(load_state())
    if not u:
        eprint("error: no unapplied patches")
        return 2
    print(u[0]["name"])
    return 0


def cmd_prev(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["prev"])
        return 0
    a = applied(load_state())
    if len(a) < 2:
        eprint("error: not enough patches applied")
        return 2
    print(a[-2]["name"])
    return 0


def patch_or_rev(st, rev):
    if not rev:
        p = top_patch(st)
        return p["commit"] if p else "HEAD"
    p = find_patch(st, rev)
    if p:
        return p["commit"]
    if rev == "{base}":
        return st["base"]
    return rev


def cmd_id(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["id"])
        return 0
    rev = next((a for a in args if not a.startswith("-")), None)
    print(git_stdout(["rev-parse", patch_or_rev(load_state(), rev)]))
    return 0


def cmd_name(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["name"])
        return 0
    st = load_state()
    rev = next((a for a in args if not a.startswith("-")), None)
    if not rev:
        p = top_patch(st)
        if not p:
            eprint("error: no patches applied")
            return 2
        print(p["name"])
        return 0
    p = find_patch(st, rev)
    if p:
        print(p["name"])
        return 0
    oid = git_stdout(["rev-parse", rev])
    for p in st["patches"]:
        if git_stdout(["rev-parse", p["commit"]]) == oid:
            print(p["name"])
            return 0
    eprint(f"error: no patch for revision `{rev}`")
    return 2


def cmd_files(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["files"])
        return 0
    stat = any(a in ("-s", "--stat") for a in args)
    rev = next((a for a in args if not a.startswith("-")), None)
    target = patch_or_rev(load_state(), rev)
    ga = ["show", "--stat", "--oneline", "--summary", target] if stat else ["diff-tree", "--no-commit-id", "--name-status", "-r", target]
    p = run_git(ga, check=False)
    sys.stdout.write(p.stdout.replace("\t", " "))
    if p.stderr:
        sys.stderr.write(p.stderr)
    return p.returncode


def cmd_show(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["show"])
        return 0
    stat = any(a in ("-s", "--stat") for a in args)
    revs = [a for a in args if not a.startswith("-")]
    st = load_state()
    if not revs:
        revs = [patch_or_rev(st, None)]
    revs = [patch_or_rev(st, r) for r in revs]
    ga = ["show"] + (["--stat"] if stat else []) + revs
    return subprocess.call(["git"] + ga)


def cmd_diff(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["diff"])
        return 0
    stat = any(a in ("-s", "--stat") for a in args)
    paths = [a for a in args if not a.startswith("-")]
    ga = ["diff"] + (["--stat"] if stat else []) + (["--"] + paths if paths else [])
    return subprocess.call(["git"] + ga)


def cmd_refresh(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["refresh"])
        return 0
    st = load_state()
    p = top_patch(st)
    if not p:
        eprint("error: no patches applied")
        return 2
    paths = [a for a in args if not a.startswith("-")]
    run_git(["add"] + (paths if paths else ["-A"]))
    msg = p.get("message") or git_stdout(["log", "-1", "--format=%B", p["commit"]])
    run_git(["commit", "--amend", "--allow-empty", "-m", msg])
    p["commit"] = git_stdout(["rev-parse", "HEAD"])
    p["message"] = msg
    save_state(st)
    print(f"> {p['name']}")
    return 0


def cmd_pop(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["pop"])
        return 0
    st = load_state()
    a = applied(st)
    if not a:
        eprint("error: no patches applied")
        return 2
    n = 1
    if any(x in ("-a", "--all") for x in args):
        n = len(a)
    if "-n" in args:
        n = int(args[args.index("-n") + 1])
    for p in reversed(a[-n:]):
        run_git(["reset", "--hard", "HEAD^"])
        p["applied"] = False
        print(f"- {p['name']}")
    save_state(st)
    return 0


def cmd_push(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["push"])
        return 0
    st = load_state()
    u = unapplied(st)
    if not u:
        eprint("error: no unapplied patches")
        return 2
    names = [a for a in args if not a.startswith("-")]
    if any(x in ("-a", "--all") for x in args):
        todo = u
    elif names:
        todo = [find_patch(st, n) for n in names]
    else:
        todo = [u[0]]
    for p in todo:
        if not p:
            eprint("error: patch not found")
            return 2
        r = run_git(["cherry-pick", p["commit"]], check=False)
        if r.stderr:
            sys.stderr.write(r.stderr)
        if r.returncode != 0:
            return r.returncode
        p["commit"] = git_stdout(["rev-parse", "HEAD"])
        p["applied"] = True
        print(f"> {p['name']}")
    save_state(st)
    return 0


def cmd_delete(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["delete"])
        return 0
    st = load_state()
    names = [a for a in args if not a.startswith("-")]
    if any(a in ("-a", "--all") for a in args):
        names = [p["name"] for p in st["patches"]]
    elif any(a in ("-t", "--top") for a in args) or not names:
        p = top_patch(st)
        if not p:
            eprint("error: no patches applied")
            return 2
        names = [p["name"]]
    for name in names:
        p = find_patch(st, name)
        if not p:
            eprint(f"error: patch `{name}` not found")
            return 2
        if p.get("applied", True) and top_patch(st) and top_patch(st)["name"] == name:
            run_git(["reset", "--hard", "HEAD^"])
        st["patches"].remove(p)
        print(f"- {name}")
    save_state(st)
    return 0


def cmd_rename(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["rename"])
        return 0
    st = load_state()
    vals = [a for a in args if not a.startswith("-")]
    if len(vals) == 1:
        p = top_patch(st)
        new = vals[0]
    elif len(vals) >= 2:
        p = find_patch(st, vals[0])
        new = vals[1]
    else:
        eprint("error: missing patch name")
        return 2
    if not p:
        eprint("error: patch not found")
        return 2
    if find_patch(st, new):
        eprint(f"error: patch `{new}` already exists")
        return 2
    old = p["name"]
    p["name"] = new
    save_state(st)
    print(f"{old} -> {new}")
    return 0


def cmd_pick(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["pick"])
        return 0
    st = load_state(init=True)
    revs = [a for a in args if not a.startswith("-")]
    if not revs:
        eprint("error: missing commit")
        return 2
    for rev in revs:
        r = run_git(["cherry-pick", rev], check=False)
        if r.returncode != 0:
            if r.stderr:
                sys.stderr.write(r.stderr)
            return r.returncode
        oid = git_stdout(["rev-parse", "HEAD"])
        msg = git_stdout(["log", "-1", "--format=%s", oid])
        name = slug(msg)
        base = name
        n = 2
        while find_patch(st, name):
            name = f"{base}-{n}"
            n += 1
        st["patches"].append({"name": name, "commit": oid, "message": msg, "applied": True})
        print(f"> {name}")
    save_state(st)
    return 0


def cmd_uncommit(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["uncommit"])
        return 0
    st = load_state(init=True)
    n = 1
    if "-n" in args:
        n = int(args[args.index("-n") + 1])
    elif "--number" in args:
        n = int(args[args.index("--number") + 1])
    commits = list(reversed(git_stdout(["rev-list", f"--max-count={n}", "HEAD"]).splitlines()))
    for oid in commits:
        msg = git_stdout(["log", "-1", "--format=%s", oid])
        name = slug(msg)
        base = name
        i = 2
        while find_patch(st, name):
            name = f"{base}-{i}"
            i += 1
        st["patches"].append({"name": name, "commit": oid, "message": msg, "applied": True})
        print(f"> {name}")
    save_state(st)
    return 0


def cmd_clean(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["clean"])
        return 0
    st = load_state()
    removed = []
    for p in list(st["patches"]):
        r = run_git(["diff-tree", "--quiet", p["commit"]], check=False)
        if r.returncode == 0:
            removed.append(p["name"])
            st["patches"].remove(p)
    save_state(st)
    for name in removed:
        print(f"- {name}")
    return 0


def cmd_branch(args):
    if any(a in ("-h", "--help") for a in args):
        print(HELPS["branch"])
        return 0
    ensure_repo()
    if not args:
        print(branch())
        return 0
    if args[0] in ("-l", "--list"):
        return subprocess.call(["git", "branch"])
    if args[0] in ("-c", "--create") and len(args) >= 2:
        base = args[2] if len(args) > 2 else "HEAD"
        return subprocess.call(["git", "checkout", "-b", args[1], base])
    return subprocess.call(["git", "checkout"] + args)


def git_alias(cmd, args):
    if cmd == "status":
        return subprocess.call(["git", "status", "-s"] + args)
    if cmd in ("add", "resolved"):
        return subprocess.call(["git", "add"] + args)
    if cmd == "rm":
        return subprocess.call(["git", "rm"] + args)
    if cmd == "mv":
        return subprocess.call(["git", "mv"] + args)
    return 1


def parse_global(argv):
    out = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-C":
            i += 1
            os.chdir(argv[i])
        elif a.startswith("-C") and len(a) > 2:
            os.chdir(a[2:])
        elif a == "--color":
            i += 1
        elif a.startswith("--color="):
            pass
        else:
            out.append(a)
        i += 1
    return out


def main(argv):
    argv = parse_global(argv)
    if not argv or argv[0] in ("-h", "--help", "help"):
        if len(argv) > 1 and argv[0] == "help":
            cmd = argv[1]
            print(HELPS.get(cmd, MAIN_HELP))
        else:
            print(MAIN_HELP)
        return 0
    if argv[0] == "--version" or argv[0] == "version":
        print(VERSION)
        gv = subprocess.run(["git", "--version"], text=True, stdout=subprocess.PIPE)
        print(gv.stdout.strip())
        return 0
    cmd, args = argv[0], argv[1:]
    if args and args[0] in ("-h", "--help"):
        print(HELPS.get(cmd, f"{cmd}\n\nUsage: stg {cmd} [OPTIONS]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')"))
        return 0
    if cmd in ("status", "add", "resolved", "rm", "mv"):
        return git_alias(cmd, args)
    table = {
        "init": cmd_init, "new": cmd_new, "series": cmd_series, "top": cmd_top,
        "next": cmd_next, "prev": cmd_prev, "id": cmd_id, "name": cmd_name,
        "files": cmd_files, "show": cmd_show, "diff": cmd_diff, "refresh": cmd_refresh,
        "pop": cmd_pop, "push": cmd_push, "delete": cmd_delete, "branch": cmd_branch,
        "rename": cmd_rename, "pick": cmd_pick, "uncommit": cmd_uncommit, "clean": cmd_clean,
    }
    if cmd in table:
        return table[cmd](args)
    eprint(f"error: unrecognized subcommand '{cmd}'")
    eprint("\nUsage: stg [OPTIONS] <command> [...]")
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
