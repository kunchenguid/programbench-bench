#!/usr/bin/env python3
import fnmatch
import glob as globmod
import os
import re
import sys
import unicodedata

VERSION = "srgn 0.14.1"

SHORT = {
    "u": "upper",
    "l": "lower",
    "t": "titlecase",
    "n": "normalize",
    "g": "german",
    "S": "symbols",
    "d": "delete",
    "s": "squeeze",
    "i": "invert",
    "L": "literal",
    "j": "join",
    "H": "hidden",
    "v": "verbose",
    "G": "glob",
    "h": "help",
    "V": "version",
}

LANG_OPTS = {
    "c", "csharp", "cs", "go", "hcl", "python", "py", "rust", "rs",
    "typescript", "ts",
}

EXTS = {
    "python": [".py"], "py": [".py"],
    "rust": [".rs"], "rs": [".rs"],
    "go": [".go"],
    "typescript": [".ts", ".tsx"], "ts": [".ts", ".tsx"],
    "c": [".c", ".h"], "csharp": [".cs"], "cs": [".cs"],
    "hcl": [".tf", ".hcl"],
}


def help_text(long=False):
    if not long:
        return """A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell. [possible values: bash, elvish, fish, powershell, zsh]
  -h, --help                 Print help (see more with '--help')
  -V, --version              Print version

Composable Actions:
  -u, --upper        Uppercase anything in scope. [env: UPPER=]
  -l, --lower        Lowercase anything in scope. [env: LOWER=]
  -t, --titlecase    Titlecase anything in scope. [env: TITLECASE=]
  -n, --normalize    Normalize (Normalization Form D) anything in scope, and throw away marks. [env: NORMALIZE=]
  -g, --german       Perform substitutions on German words, such as 'Abenteuergruesse' to 'Abenteuergrüße', for anything in scope.
  -S, --symbols      Perform substitutions on symbols, such as '!=' to '≠', '->' to '→', on anything in scope.
  [REPLACEMENT]  Replace anything in scope with this value. [env: REPLACE=]

Standalone Actions (only usable alone):
  -d, --delete   Delete anything in scope.
  -s, --squeeze  Squeeze consecutive occurrences of scope into one. [env: SQUEEZE=]

Options (global):
  -G, --glob <GLOB>          Glob of files to work on (instead of reading stdin).
      --fail-no-files        Fail if working on files but none are found.
      --dry-run              Do not destructively overwrite files, instead print rich diff only.
  -i, --invert               Undo the effects of passed actions, where applicable. [env: INVERT=]
  -L, --literal-string       Do not interpret the scope as a regex. [env: LITERAL_STRING=]
      --fail-any             If anything at all is found to be in scope, fail.
      --fail-none            If nothing is found to be in scope, fail.
      --line-numbers         Include line numbers in search output.
      --only-matching        Print matching line records.
"""
    return help_text(False) + """
Language scopes:
      --python <PYTHON>      Scope Python code using a prepared query.
      --rust <RUST>          Scope Rust code using a prepared query.
      --go <GO>              Scope Go code using a prepared query.
      --typescript <TS>      Scope TypeScript code using a prepared query.
      --c <C>                Scope C code using a prepared query.
      --csharp <CSHARP>      Scope C# code using a prepared query.
      --hcl <HCL>            Scope HCL code using a prepared query.

Options (german):
      --german-prefer-original
      --german-naive
"""


def parse(argv):
    opts = {
        "upper": bool(os.getenv("UPPER")),
        "lower": bool(os.getenv("LOWER")),
        "titlecase": bool(os.getenv("TITLECASE")),
        "normalize": bool(os.getenv("NORMALIZE")),
        "german": bool(os.getenv("GERMAN")),
        "symbols": bool(os.getenv("SYMBOLS")),
        "delete": bool(os.getenv("DELETE")),
        "squeeze": bool(os.getenv("SQUEEZE")),
        "invert": bool(os.getenv("INVERT")),
        "literal": bool(os.getenv("LITERAL_STRING")),
        "fail_any": False,
        "fail_none": False,
        "fail_no_files": False,
        "dry_run": False,
        "line_numbers": False,
        "only_matching": False,
        "hidden": False,
        "sorted": False,
        "german_naive": bool(os.getenv("GERMAN_NAIVE")),
        "glob": None,
        "langs": [],
        "scope": None,
        "replacement": os.getenv("REPLACE"),
    }
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            if i + 1 < len(argv):
                opts["replacement"] = argv[i + 1]
            break
        if a in ("-h", "--help"):
            print(help_text(long=a == "--help"))
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a == "--completions":
            print("")
            sys.exit(0)
        if a.startswith("--"):
            name = a[2:].replace("-", "_")
            raw = a[2:]
            if raw in LANG_OPTS:
                if i + 1 >= len(argv):
                    die(f"error: a value is required for '--{raw} <{raw.upper()}>' but none was supplied", 2)
                lang = {"py": "python", "rs": "rust", "ts": "typescript", "cs": "csharp"}.get(raw, raw)
                opts["langs"].append((lang, argv[i + 1]))
                i += 2
                continue
            if raw.endswith("-query") or raw.endswith("-query-file"):
                i += 2
                continue
            if name in ("literal_string",):
                opts["literal"] = True
            elif name in ("german_naive", "german_prefer_original", "fail_any", "fail_none",
                          "fail_no_files", "dry_run", "line_numbers", "only_matching",
                          "hidden", "gitignored", "sorted", "join_language_scopes"):
                key = {"literal_string": "literal", "join_language_scopes": "join"}.get(name, name)
                opts[key] = True
            elif name in ("upper", "lower", "titlecase", "normalize", "german",
                          "symbols", "delete", "squeeze", "invert"):
                opts[name] = True
            elif name in ("glob", "stdin_detection", "stdout_detection", "threads"):
                if i + 1 >= len(argv):
                    die(f"error: a value is required for '{a}' but none was supplied", 2)
                if name == "glob":
                    opts["glob"] = argv[i + 1]
                i += 2
                continue
            else:
                die(f"error: unexpected argument '{a}' found", 2)
            i += 1
            continue
        if a.startswith("-") and a != "-":
            j = 1
            while j < len(a):
                c = a[j]
                if c not in SHORT:
                    die(f"error: unexpected argument '-{c}' found", 2)
                key = SHORT[c]
                if key == "glob":
                    val = a[j + 1:] or (argv[i + 1] if i + 1 < len(argv) else None)
                    if val is None:
                        die("error: a value is required for '--glob <GLOB>' but none was supplied", 2)
                    opts["glob"] = val
                    if not a[j + 1:]:
                        i += 1
                    break
                if key == "help":
                    print(help_text(False)); sys.exit(0)
                if key == "version":
                    print(VERSION); sys.exit(0)
                opts[key] = True
                j += 1
            i += 1
            continue
        pos.append(a)
        i += 1
    if pos:
        opts["scope"] = pos[0]
        if len(pos) > 1 and opts["replacement"] is None:
            opts["replacement"] = pos[1]
    if opts["scope"] is None:
        opts["scope"] = ".*"
    return opts


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def compile_pat(scope, literal=False):
    pat = re.escape(scope) if literal else scope
    try:
        return re.compile(pat, re.MULTILINE)
    except re.error as e:
        die(f"Error: {e}", 1)


def strip_marks(s):
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


def germanize(s, naive=False):
    reps = [
        ("UE", "Ü"), ("Ue", "Ü"), ("ue", "ü"),
        ("AE", "Ä"), ("Ae", "Ä"), ("ae", "ä"),
        ("Aeu", "Äu"), ("Ueu", "Üu"),
        ("Aussi", "Außi"), ("auss", "auß"),
        ("ss", "ß"), ("SS", "ẞ"),
    ]
    if naive:
        reps = [("OE", "Ö"), ("Oe", "Ö"), ("oe", "ö"), ("Oeu", "Öu")] + reps
    for a, b in reps:
        s = s.replace(a, b)
    return s


SYM = [
    ("!=", "≠"), ("<=", "≤"), (">=", "≥"), ("->", "→"), ("<-", "←"), ("=>", "⇒"),
]
RSYM = [(b, a) for a, b in SYM]


def symbolize(s, invert=False):
    for a, b in (RSYM if invert else SYM):
        s = s.replace(a, b)
    return s


def titlecase(s):
    return re.sub(r"\b(\w)(\w*)", lambda m: m.group(1).upper() + m.group(2).lower(), s)


def expand_repl(template, m):
    def braced(x):
        key = x.group(1)
        return group_value(m, key)
    def bare(x):
        key = x.group(1)
        return group_value(m, key)
    out = re.sub(r"\$\{([A-Za-z_][A-Za-z0-9_]*|\d+)\}", braced, template)
    out = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*|\d+)", bare, out)
    return out


def group_value(m, key):
    try:
        if key.isdigit():
            return m.group(int(key)) or ""
        return m.group(key) or ""
    except Exception:
        return ""


def apply_actions_to_text(s, opts):
    if opts["upper"]:
        s = s.upper()
    if opts["lower"]:
        s = s.lower()
    if opts["titlecase"]:
        s = titlecase(s)
    if opts["normalize"]:
        s = strip_marks(s)
    if opts["german"]:
        s = germanize(s, opts["german_naive"])
    if opts["symbols"]:
        s = symbolize(s, opts["invert"])
    return s


def transform(data, opts):
    pat = compile_pat(opts["scope"], opts["literal"])
    found = False
    if opts["delete"]:
        out, n = pat.subn("", data)
        return out, n > 0
    if opts["squeeze"]:
        return squeeze(data, pat)

    def repl(m):
        nonlocal found
        found = True
        text = expand_repl(opts["replacement"], m) if opts["replacement"] is not None else m.group(0)
        return apply_actions_to_text(text, opts)
    out = pat.sub(repl, data)
    return out, found


def squeeze(data, pat):
    out = []
    pos = 0
    found = False
    n = len(data)
    while pos < n:
        m = pat.search(data, pos)
        if not m or m.end() == m.start():
            out.append(data[pos:])
            break
        out.append(data[pos:m.start()])
        first = m.group(0)
        end = m.end()
        found = True
        while True:
            m2 = pat.match(data, end)
            if not m2 or m2.end() == m2.start():
                break
            end = m2.end()
        out.append(first)
        pos = end
    return "".join(out), found


def blocks_by_indent(data, keyword):
    spans = []
    lines = list(iter_lines(data))
    for idx, start, line in lines:
        stripped = line.lstrip(" ")
        if re.match(keyword, stripped):
            indent = len(line) - len(stripped)
            end = start + len(line)
            for _, st2, line2 in lines[idx + 1:]:
                if line2.strip() and len(line2) - len(line2.lstrip(" ")) <= indent:
                    break
                end = st2 + len(line2)
            spans.append((start, end))
    return spans


def brace_blocks(data, regex):
    spans = []
    for m in re.finditer(regex, data, re.MULTILINE):
        b = data.find("{", m.end())
        if b < 0:
            end = data.find("\n", m.end())
            spans.append((m.start(), len(data) if end < 0 else end + 1))
        else:
            spans.append((m.start(), matching_brace(data, b) + 1))
    return spans


def matching_brace(data, pos):
    depth = 0
    for i in range(pos, len(data)):
        if data[i] == "{":
            depth += 1
        elif data[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return len(data) - 1


def iter_lines(data):
    start = 0
    idx = 0
    for part in data.splitlines(True):
        yield idx, start, part
        start += len(part)
        idx += 1
    if data and not data.endswith(("\n", "\r")):
        pass


def regex_spans(data, pattern, flags=0, group=0):
    return [(m.start(group), m.end(group)) for m in re.finditer(pattern, data, flags)]


def lang_spans(data, lang, query):
    q = query.split("~", 1)[0]
    if lang == "python":
        if q == "class":
            return blocks_by_indent(data, r"class\s+\w+")
        if q in ("def", "methods", "class-methods", "static-methods", "async-def"):
            return blocks_by_indent(data, r"(async\s+)?def\s+\w+")
        if q == "function-names":
            return regex_spans(data, r"\bdef\s+([A-Za-z_]\w*)", re.MULTILINE, 1)
        if q == "function-calls":
            return regex_spans(data, r"\b([A-Za-z_]\w*)\s*\(", 0, 1)
        if q == "comments":
            return regex_spans(data, r"#[^\n]*")
        if q in ("strings", "doc-strings"):
            return regex_spans(data, r"(?s)([rubfRUBF]*'''[\s\S]*?'''|[rubfRUBF]*\"\"\"[\s\S]*?\"\"\"|[rubfRUBF]*'[^'\n]*'|[rubfRUBF]*\"[^\"\n]*\")")
        if q == "imports":
            return regex_spans(data, r"(?m)^\s*(?:from\s+([A-Za-z_][\w.]*)|import\s+([A-Za-z_][\w.]*))")
        if q in ("identifiers", "variable-identifiers", "types", "globals"):
            return regex_spans(data, r"\b[A-Za-z_]\w*\b")
    if lang == "rust":
        if q in ("fn", "priv-fn", "pub-fn", "const-fn", "async-fn", "unsafe-fn", "extern-fn", "test-fn", "impl-fn"):
            return brace_blocks(data, r"(?m)^\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+|const\s+|unsafe\s+|extern\s+)*fn\s+\w+")
        if q.startswith("struct") or q.endswith("struct"):
            return brace_blocks(data, r"(?m)^\s*(?:pub(?:\([^)]*\))?\s+)?struct\s+\w+")
        if q.startswith("enum") or q.endswith("enum"):
            return brace_blocks(data, r"(?m)^\s*(?:pub(?:\([^)]*\))?\s+)?enum\s+\w+")
        if q in ("comments", "doc-comments"):
            return regex_spans(data, r"//[^\n]*|/\*[\s\S]*?\*/")
        if q == "strings":
            return regex_spans(data, r'r#*".*?"#*|".*?"')
        if q in ("uses", "identifier", "type-identifier", "unsafe", "attribute"):
            return regex_spans(data, r"\b[A-Za-z_]\w*\b|#\[[^\]]+\]")
    if lang in ("go", "typescript", "c", "csharp", "hcl"):
        if q in ("comments",):
            return regex_spans(data, r"//[^\n]*|#[^\n]*|/\*[\s\S]*?\*/")
        if q in ("strings", "struct-tags"):
            return regex_spans(data, r"`[^`]*`|'[^'\n]*'|\"[^\"\n]*\"")
        if q in ("func", "function", "method", "free-func", "function-def"):
            return brace_blocks(data, r"(?m)^\s*(?:func|function|[A-Za-z_][\w\s*]+\s+[A-Za-z_]\w+\s*\()")
        if q in ("class", "struct", "enum", "interface", "type-def", "impl", "resource", "variable", "data", "output", "provider", "module", "locals", "terraform"):
            return brace_blocks(data, r"(?m)^\s*(?:type\s+\w+\s+struct|class\s+\w+|struct\s+\w+|enum\s+\w+|interface\s+\w+|%s\s+\"?[A-Za-z_]\w*\"?)" % re.escape(q))
        return regex_spans(data, r"\b[A-Za-z_]\w*\b")
    return [(0, len(data))]


def intersect(a, b):
    out = []
    for x1, x2 in a:
        for y1, y2 in b:
            s, e = max(x1, y1), min(x2, y2)
            if s < e:
                out.append((s, e))
    return out


def scoped_matches(data, opts):
    spans = [(0, len(data))]
    if opts["langs"]:
        if opts.get("join"):
            spans = []
            for lang, q in opts["langs"]:
                spans.extend(lang_spans(data, lang, q))
        else:
            for lang, q in opts["langs"]:
                spans = intersect(spans, lang_spans(data, lang, q))
    pat = compile_pat(opts["scope"], opts["literal"])
    matches = []
    for s, e in spans:
        for m in pat.finditer(data, s, e):
            if m.end() > e or m.end() == m.start():
                continue
            matches.append((m.start(), m.end()))
    return sorted(matches)


def search_output(data, name, opts):
    matches = scoped_matches(data, opts)
    if not matches and (opts["langs"] or not opts["line_numbers"]):
        return "", False
    by_line = []
    for _, ls, line in iter_lines(data):
        le = ls + len(line.rstrip("\n"))
        parts = [(max(a, ls) - ls, min(b, le) - ls) for a, b in matches if a < le and b > ls]
        if parts or (opts["line_numbers"] and not opts["langs"]):
            by_line.append((line, ls, parts))
    out = []
    for line, ls, parts in by_line:
        line_no = data.count("\n", 0, ls) + 1
        ranges = ";".join(f"{a}-{b}" for a, b in parts)
        text = line.rstrip("\n")
        if opts["langs"] or opts["line_numbers"]:
            out.append(f"{name}:{line_no}:{ranges}:{text}")
        else:
            out.append(f"{name}:{ranges}:{text}")
    return "\n".join(out) + ("\n" if out else ""), True


def discover_files(opts):
    if opts["glob"]:
        files = globmod.glob(opts["glob"], recursive=True)
    else:
        exts = []
        for lang, _ in opts["langs"]:
            exts.extend(EXTS.get(lang, []))
        files = []
        for root, dirs, names in os.walk("."):
            if not opts["hidden"]:
                dirs[:] = [d for d in dirs if not d.startswith(".")]
                names = [n for n in names if not n.startswith(".")]
            for n in names:
                if not exts or os.path.splitext(n)[1] in exts:
                    files.append(os.path.join(root, n).removeprefix("./"))
    files = [f for f in files if os.path.isfile(f)]
    if opts["sorted"]:
        files.sort()
    return files


def has_actions(opts):
    return any(opts[k] for k in ("upper", "lower", "titlecase", "normalize", "german", "symbols", "delete", "squeeze")) or opts["replacement"] is not None


def process_stdin(opts):
    data = sys.stdin.read()
    if opts["langs"] or opts["line_numbers"] or opts["only_matching"]:
        out, found = search_output(data, "(stdin)", opts)
        sys.stdout.write(out if out else (data if not opts["langs"] else ""))
    elif has_actions(opts):
        out, found = transform(data, opts)
        sys.stdout.write(out)
    else:
        print("[2026-06-15T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.", file=sys.stderr)
        found = bool(scoped_matches(data, opts))
        sys.stdout.write(data)
    finish_fail(opts, found)


def process_files(opts):
    files = discover_files(opts)
    if not files and opts["fail_no_files"]:
        die("Error: No files found", 1)
    any_found = False
    for path in files:
        with open(path, "r", encoding="utf-8", errors="surrogateescape") as f:
            data = f.read()
        if has_actions(opts):
            new, found = transform(data, opts)
            any_found = any_found or found
            if found:
                if opts["dry_run"]:
                    old_lines, _ = search_output(data, path, {**opts, "langs": [], "line_numbers": True})
                    new_lines, _ = search_output(new, path, {**opts, "langs": [], "line_numbers": True})
                    sys.stdout.write(old_lines)
                    sys.stdout.write(new_lines)
                else:
                    with open(path, "w", encoding="utf-8", errors="surrogateescape") as f:
                        f.write(new)
                    print(path)
        elif opts["langs"] or opts["line_numbers"] or opts["only_matching"]:
            out, found = search_output(data, path, opts)
            any_found = any_found or found
            sys.stdout.write(out)
        else:
            print("[2026-06-15T00:00:00Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.", file=sys.stderr)
            any_found = any_found or bool(scoped_matches(data, opts))
    finish_fail(opts, any_found)


def finish_fail(opts, found):
    if opts["fail_any"] and found:
        die("Error: Error applying: Some input was in scope", 1)
    if opts["fail_none"] and not found:
        die("Error: Error applying: No input was in scope", 1)


def main():
    opts = parse(sys.argv[1:])
    if opts["glob"] or (opts["langs"] and sys.stdin.isatty()):
        process_files(opts)
    else:
        process_stdin(opts)


if __name__ == "__main__":
    main()
