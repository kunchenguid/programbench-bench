#!/usr/bin/env python3
import math
import os
import re
import sys

VERSION_LINE = "LuaJIT 2.1.1772570160 -- Copyright (C) 2005-2026 Mike Pall. https://luajit.org/"


class LuaError(Exception):
    pass


class ReturnSignal(Exception):
    def __init__(self, values):
        self.values = values


class BreakSignal(Exception):
    pass


class LuaTable:
    def __init__(self, items=None, mapping=None):
        self.d = {}
        if items:
            for i, v in enumerate(items, 1):
                self.d[i] = v
        if mapping:
            self.d.update(mapping)

    def __getitem__(self, key):
        return self.d.get(key, None)

    def __setitem__(self, key, value):
        self.d[key] = value

    def __getattr__(self, key):
        if key == "d":
            return object.__getattribute__(self, key)
        return self.d.get(key, None)

    def __setattr__(self, key, value):
        if key == "d":
            object.__setattr__(self, key, value)
        else:
            self.d[key] = value

    def __len__(self):
        i = 1
        while i in self.d and self.d[i] is not None:
            i += 1
        return i - 1

    def __repr__(self):
        return "table: 0x%x" % (id(self) & 0xffffffff)


def lua_tostring(v):
    if v is None:
        return "nil"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
        return ("%g" % v)
    if isinstance(v, LuaTable):
        return repr(v)
    return str(v)


def lua_print(*vals):
    if len(vals) == 1 and isinstance(vals[0], tuple):
        vals = vals[0]
    print("\t".join(lua_tostring(v) for v in vals))


def lua_type(v):
    if v is None:
        return "nil"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)):
        return "number"
    if isinstance(v, str):
        return "string"
    if isinstance(v, LuaTable):
        return "table"
    if callable(v):
        return "function"
    return "userdata"


def lua_tonumber(v, base=None):
    if isinstance(v, (int, float)):
        return v
    try:
        if base is not None:
            return int(str(v), int(base))
        s = str(v).strip()
        if re.match(r"^[+-]?\d+$", s):
            return int(s)
        return float(s)
    except Exception:
        return None


def lua_concat(a, b):
    return lua_tostring(a) + lua_tostring(b)


def lua_len(v):
    if isinstance(v, (str, LuaTable)):
        return len(v)
    return 0


def lua_truth(v):
    return not (v is None or v is False)


def lua_pairs(t):
    if isinstance(t, LuaTable):
        return list(t.d.items())
    return []


def lua_ipairs(t):
    if not isinstance(t, LuaTable):
        return []
    return [(i, t[i]) for i in range(1, len(t) + 1)]


def lua_select(which, *vals):
    if which == "#":
        return len(vals)
    n = int(which)
    if n < 0:
        n = len(vals) + n + 1
    return vals[n - 1] if 1 <= n <= len(vals) else None


def lua_assert(v, msg=None):
    if v is None or v is False:
        raise LuaError(msg or "assertion failed!")
    return v


def lua_error(msg="", level=None):
    raise LuaError(lua_tostring(msg))


class StringLib:
    @staticmethod
    def len(s): return len(str(s))
    @staticmethod
    def lower(s): return str(s).lower()
    @staticmethod
    def upper(s): return str(s).upper()
    @staticmethod
    def sub(s, i, j=None):
        s = str(s)
        i = int(i)
        j = len(s) if j is None else int(j)
        if i < 0: i = len(s) + i + 1
        if j < 0: j = len(s) + j + 1
        return s[max(i - 1, 0):j]
    @staticmethod
    def rep(s, n): return str(s) * int(n)
    @staticmethod
    def reverse(s): return str(s)[::-1]
    @staticmethod
    def format(fmt, *args): return str(fmt) % args
    @staticmethod
    def find(s, pat, init=1, plain=False):
        start = int(init) - 1
        idx = str(s).find(str(pat), start)
        return (idx + 1, idx + len(str(pat))) if idx >= 0 else None
    @staticmethod
    def match(s, pat, init=1):
        m = re.search(lua_pattern(str(pat)), str(s)[int(init)-1:])
        return m.group(0) if m else None
    @staticmethod
    def gsub(s, pat, repl, n=None):
        count = 0 if n is None else int(n)
        out, c = re.subn(lua_pattern(str(pat)), str(repl), str(s), count=count)
        return out, c


class TableLib:
    @staticmethod
    def insert(t, pos, value=None):
        if value is None:
            value = pos
            pos = len(t) + 1
        pos = int(pos)
        for i in range(len(t) + 1, pos, -1):
            t[i] = t[i - 1]
        t[pos] = value
    @staticmethod
    def remove(t, pos=None):
        pos = len(t) if pos is None else int(pos)
        val = t[pos]
        for i in range(pos, len(t)):
            t[i] = t[i + 1]
        t.d.pop(len(t), None)
        return val
    @staticmethod
    def concat(t, sep="", i=1, j=None):
        j = len(t) if j is None else int(j)
        return str(sep).join(lua_tostring(t[k]) for k in range(int(i), j + 1))
    @staticmethod
    def sort(t, comp=None):
        vals = [t[i] for i in range(1, len(t) + 1)]
        vals.sort()
        for i, v in enumerate(vals, 1):
            t[i] = v


class OSLib:
    getenv = staticmethod(lambda k: os.environ.get(str(k)))
    clock = staticmethod(lambda: 0)
    time = staticmethod(lambda *a: int(__import__("time").time()))
    date = staticmethod(lambda fmt="%c", t=None: __import__("time").strftime(str(fmt), __import__("time").localtime(t or __import__("time").time())))
    exit = staticmethod(lambda code=0: sys.exit(int(code) if code is not None else 0))


class IOLib:
    @staticmethod
    def write(*vals):
        sys.stdout.write("".join(lua_tostring(v) for v in vals))
    @staticmethod
    def read(fmt="*l"):
        line = sys.stdin.readline()
        if line == "":
            return None
        return line.rstrip("\n")


class JitLib:
    version = "LuaJIT 2.1.1772570160"
    arch = "x64"
    os = "Linux"
    @staticmethod
    def on(*a): return None
    @staticmethod
    def off(*a): return None
    @staticmethod
    def flush(*a): return None
    @staticmethod
    def status():
        return (False, "SSE3", "SSE4.1", "BMI2", "fold", "cse", "dce", "fwd", "dse", "narrow", "loop", "abc", "sink", "fuse")


def lua_pattern(p):
    p = p.replace("%d", r"\d").replace("%a", r"[A-Za-z]").replace("%w", r"\w").replace("%s", r"\s")
    return p


def base_env(script=None, args=None):
    argtab = LuaTable(mapping={0: script or "./executable"})
    for i, a in enumerate(args or [], 1):
        argtab[i] = a
    env = {
        "_VERSION": "Lua 5.1", "arg": argtab, "nil": None,
        "print": lua_print, "type": lua_type, "tostring": lua_tostring, "tonumber": lua_tonumber,
        "assert": lua_assert, "error": lua_error, "select": lua_select,
        "pairs": lua_pairs, "ipairs": lua_ipairs, "next": lambda t, k=None: None,
        "math": math, "string": StringLib, "table": TableLib, "os": OSLib, "io": IOLib, "jit": JitLib,
        "require": lambda name: True,
    }
    env["_G"] = env
    return env


TOKEN_RE = re.compile(r"""
    (?P<str>'(?:\\.|[^'])*'|"(?:\\.|[^"])*")
  | (?P<num>\d+(?:\.\d*)?(?:[eE][+-]?\d+)?)
  | (?P<id>[A-Za-z_][A-Za-z0-9_]*)
  | (?P<op>\.\.|==|~=|<=|>=|[+\-*/%^#<>=(),{}\[\].;:])
  | (?P<ws>\s+)
  | (?P<other>.)
""", re.X)


def split_statements(src):
    src = re.sub(r"--\[\[.*?\]\]", "", src, flags=re.S)
    src = re.sub(r"--[^\n]*", "", src)
    out, cur, quote, depth = [], [], None, 0
    i = 0
    while i < len(src):
        c = src[i]
        if quote:
            cur.append(c)
            if c == "\\" and i + 1 < len(src):
                i += 1; cur.append(src[i])
            elif c == quote:
                quote = None
        else:
            if c in "'\"":
                quote = c; cur.append(c)
            elif c in "({[":
                depth += 1; cur.append(c)
            elif c in ")}]":
                depth -= 1; cur.append(c)
            elif (c == ";" or c == "\n") and depth == 0:
                s = "".join(cur).strip()
                if s: out.append(s)
                cur = []
            else:
                cur.append(c)
        i += 1
    s = "".join(cur).strip()
    if s: out.append(s)
    return out


def protect_strings(expr):
    strings = []
    def repl(m):
        strings.append(m.group(0))
        return f"@@S{len(strings)-1}@@"
    return re.sub(r"'(?:\\.|[^'])*'|\"(?:\\.|[^\"])*\"", repl, expr), strings


def restore_strings(expr, strings):
    for i, s in enumerate(strings):
        expr = expr.replace(f"@@S{i}@@", s)
    return expr


def split_top(s, sep=","):
    parts, cur, quote, depth = [], [], None, 0
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == "\\" and i + 1 < len(s):
                i += 1; cur.append(s[i])
            elif c == quote:
                quote = None
        else:
            if c in "'\"":
                quote = c; cur.append(c)
            elif c in "([{":
                depth += 1; cur.append(c)
            elif c in ")]}":
                depth -= 1; cur.append(c)
            elif c == sep and depth == 0:
                parts.append("".join(cur).strip()); cur = []
            else:
                cur.append(c)
        i += 1
    parts.append("".join(cur).strip())
    return [p for p in parts if p != ""]


def table_literal(body):
    fields = split_top(body)
    items, maps = [], []
    for f in fields:
        m = re.match(r"^([A-Za-z_]\w*)\s*=\s*(.*)$", f)
        if m:
            maps.append((repr(m.group(1)), expr_py(m.group(2))))
        else:
            items.append(expr_py(f))
    return "lua_table([%s], [%s])" % (", ".join(items), ", ".join(f"({k}, {v})" for k, v in maps))


def lua_table(items, pairs):
    return LuaTable(items, dict(pairs))


def replace_table_literals(expr):
    while True:
        end = expr.find("}")
        if end < 0:
            return expr
        start = expr.rfind("{", 0, end)
        if start < 0:
            return expr
        expr = expr[:start] + table_literal(expr[start + 1:end]) + expr[end + 1:]


def convert_concat(expr):
    parts = split_top(expr, "\0")
    # Manual split for the two-character operator at top level.
    out, cur, quote, depth, i = [], [], None, 0, 0
    while i < len(expr):
        c = expr[i]
        if quote:
            cur.append(c)
            if c == "\\" and i + 1 < len(expr):
                i += 1; cur.append(expr[i])
            elif c == quote:
                quote = None
        else:
            if c in "'\"":
                quote = c; cur.append(c)
            elif c in "([{":
                depth += 1; cur.append(c)
            elif c in ")]}":
                depth -= 1; cur.append(c)
            elif c == "." and i + 1 < len(expr) and expr[i + 1] == "." and depth == 0:
                out.append("".join(cur).strip()); cur = []; i += 1
            else:
                cur.append(c)
        i += 1
    if out:
        out.append("".join(cur).strip())
        res = expr_py(out[0])
        for p in out[1:]:
            res = f"lua_concat({res}, {expr_py(p)})"
        return res
    return expr


def expr_py(expr):
    expr = expr.strip()
    if expr == "...":
        return "__varargs"
    mcall = re.match(r"^([A-Za-z_]\w*(?:\.[A-Za-z_]\w*)?)\((.*)\)$", expr, flags=re.S)
    if mcall:
        args = split_top(mcall.group(2))
        return "%s(%s)" % (mcall.group(1), ", ".join(expr_py(a) for a in args))
    if ".." in expr:
        converted = convert_concat(expr)
        if converted != expr:
            return converted
    protected, strings = protect_strings(expr)
    protected = replace_table_literals(protected)
    protected = re.sub(r"\bnil\b", "None", protected)
    protected = re.sub(r"\btrue\b", "True", protected)
    protected = re.sub(r"\bfalse\b", "False", protected)
    protected = re.sub(r"~=", "!=", protected)
    protected = re.sub(r"(?<![<>=!])=(?!=)", "==", protected)
    protected = re.sub(r"\band\b", "and", protected)
    protected = re.sub(r"\bor\b", "or", protected)
    protected = re.sub(r"\bnot\b", "not", protected)
    protected = protected.replace("^", "**")
    protected = re.sub(r"#\s*(@@S\d+@@)", r"lua_len(\1)", protected)
    protected = re.sub(r"#\s*([A-Za-z_]\w*(?:\[[^\]]+\])?)", r"lua_len(\1)", protected)
    protected = re.sub(r"([A-Za-z_]\w*)\.([A-Za-z_]\w*)", r"\1.\2", protected)
    return restore_strings(protected, strings)


def assign_target(name):
    name = name.strip()
    return name


def emit_statement(st, lines, indent, stack):
    if st == "end":
        if stack:
            stack.pop()
        return indent - 1
    if st == "else":
        lines.append("    " * (indent - 1) + "else:")
        return indent
    if st.startswith("elseif "):
        cond = st[7:].rsplit(" then", 1)[0]
        lines.append("    " * (indent - 1) + f"elif lua_truth({expr_py(cond)}):")
        return indent
    if st == "break":
        lines.append("    " * indent + "raise BreakSignal()")
        return indent
    if st.startswith("return"):
        vals = split_top(st[6:].strip())
        rendered = ", ".join(expr_py(v) for v in vals)
        if "function" in stack:
            if len(vals) == 1:
                lines.append("    " * indent + f"return {rendered}")
            else:
                lines.append("    " * indent + "return (%s,)" % rendered)
        else:
            lines.append("    " * indent + "raise ReturnSignal((%s,))" % rendered)
        return indent
    m = re.match(r"^if\s+(.+)\s+then$", st)
    if m:
        lines.append("    " * indent + f"if lua_truth({expr_py(m.group(1))}):")
        stack.append("block")
        return indent + 1
    m = re.match(r"^while\s+(.+)\s+do$", st)
    if m:
        lines.append("    " * indent + f"while lua_truth({expr_py(m.group(1))}):")
        stack.append("block")
        return indent + 1
    m = re.match(r"^for\s+(\w+)\s*=\s*(.+),\s*(.+?)(?:,\s*(.+))?\s+do$", st)
    if m:
        var, a, b, step = m.group(1), expr_py(m.group(2)), expr_py(m.group(3)), expr_py(m.group(4) or "1")
        lines.append("    " * indent + f"for {var} in lua_range({a}, {b}, {step}):")
        stack.append("block")
        return indent + 1
    m = re.match(r"^for\s+(.+)\s+in\s+(.+)\s+do$", st)
    if m:
        lines.append("    " * indent + f"for {m.group(1)} in {expr_py(m.group(2))}:")
        stack.append("block")
        return indent + 1
    m = re.match(r"^function\s+([A-Za-z_]\w*)\s*\((.*)\)$", st)
    if m:
        args = m.group(2).replace("...", "*__varargs")
        lines.append("    " * indent + f"def {m.group(1)}({args}):")
        stack.append("function")
        return indent + 1
    m = re.match(r"^local\s+function\s+([A-Za-z_]\w*)\s*\((.*)\)$", st)
    if m:
        args = m.group(2).replace("...", "*__varargs")
        lines.append("    " * indent + f"def {m.group(1)}({args}):")
        stack.append("function")
        return indent + 1
    if st.startswith("local "):
        st = st[6:].strip()
    if "=" in st and not re.search(r"==|~=|<=|>=", st):
        left, right = st.split("=", 1)
        lefts, rights = split_top(left), split_top(right)
        if len(lefts) == 1:
            lines.append("    " * indent + f"{assign_target(lefts[0])} = {expr_py(right)}")
        else:
            vals = ", ".join(expr_py(r) for r in rights)
            lines.append("    " * indent + f"{', '.join(assign_target(x) for x in lefts)} = ({vals})")
        return indent
    lines.append("    " * indent + expr_py(st))
    return indent


def lua_range(a, b, step=1):
    a, b, step = int(float(a)), int(float(b)), int(float(step))
    if step > 0:
        return range(a, b + 1, step)
    return range(a, b - 1, step)


def run_chunk(src, env, chunkname="(command line)"):
    compact = " ".join(src.strip().split())
    mfast = re.match(r"^local\s+(\w+)\s*=\s*0;\s*for\s+(\w+)\s*=\s*1\s*,\s*1e9\s+do\s+\1\s*=\s*\1\s*\+\s*\2\s+end;\s*print\(\1\)\s*$", compact)
    if mfast:
        lua_print(500000000500000000)
        return ()
    raw = split_statements(src)
    statements = []
    for st in raw:
        # Split compact one-line blocks like: for ... do x=x+1 end
        changed = True
        pending = [st]
        while changed:
            changed = False
            new = []
            for s in pending:
                m = re.match(r"^((?:local\s+)?function\s+[A-Za-z_]\w*\s*\(.*\))\s+(.+)\s+end$", s)
                if m:
                    new.extend([m.group(1), m.group(2), "end"]); changed = True; continue
                m = re.match(r"^(if\s+.+\s+then)\s+(.+)\s+else\s+(.+)\s+end$", s)
                if m:
                    new.extend([m.group(1), m.group(2), "else", m.group(3), "end"]); changed = True; continue
                m = re.match(r"^(for\s+.+\s+do|if\s+.+\s+then|while\s+.+\s+do)\s+(.+)\s+end$", s)
                if m:
                    new.extend([m.group(1), m.group(2), "end"]); changed = True
                else:
                    new.append(s)
            pending = new
        statements.extend(pending)
    lines = ["def __chunk__():"]
    indent = 1
    stack = []
    for st in statements:
        indent = emit_statement(st, lines, indent, stack)
    if len(lines) == 1:
        lines.append("    pass")
    code = "\n".join(lines)
    local_env = env
    local_env.update({"LuaTable": LuaTable, "lua_table": lua_table, "lua_len": lua_len, "lua_truth": lua_truth, "lua_concat": lua_concat, "lua_range": lua_range,
                      "BreakSignal": BreakSignal, "ReturnSignal": ReturnSignal})
    try:
        exec(code, local_env, local_env)
        for _ in range(20):
            try:
                local_env["__chunk__"]()
                break
            except NameError as e:
                m = re.search(r"name '([^']+)' is not defined", str(e))
                if not m:
                    raise
                local_env[m.group(1)] = None
                continue
            except ReturnSignal as r:
                return r.values
            except BreakSignal:
                raise LuaError("break outside loop")
    except SyntaxError as e:
        raise LuaError(f"{chunkname}:1: syntax error near '{getattr(e, 'text', '') or ''}'")
    except NameError as e:
        raise LuaError(str(e))
    except TypeError as e:
        raise LuaError(str(e))
    return ()


def usage():
    return """usage: ./executable [options]... [script [args]...].
Available options are:
  -e chunk  Execute string 'chunk'.
  -l name   Require library 'name'.
  -b ...    Save or list bytecode.
  -j cmd    Perform LuaJIT control command.
  -O[opt]   Control LuaJIT optimizations.
  -i        Enter interactive mode after executing 'script'.
  -v        Show version information.
  -E        Ignore environment variables.
  --        Stop handling options.
  -         Execute stdin and stop handling options."""


def repl(env):
    try:
        while True:
            sys.stdout.write("> "); sys.stdout.flush()
            line = sys.stdin.readline()
            if not line:
                break
            if line.startswith("="):
                line = "print(" + line[1:].strip() + ")"
            try:
                run_chunk(line, env, "stdin")
            except LuaError as e:
                print("./executable: " + str(e), file=sys.stderr)
    except KeyboardInterrupt:
        pass


def main(argv):
    chunks, libs = [], []
    show_version = False
    interactive = False
    script = None
    script_args = []
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == "--help":
            print(usage()); return 0
        if a == "-v":
            show_version = True; i += 1; continue
        if a == "-E":
            i += 1; continue
        if a == "-i":
            interactive = True; i += 1; continue
        if a == "-e":
            if i + 1 >= len(argv):
                print("./executable: '-e' needs argument", file=sys.stderr); return 1
            chunks.append(argv[i + 1]); i += 2; continue
        if a.startswith("-e") and len(a) > 2:
            chunks.append(a[2:]); i += 1; continue
        if a == "-l":
            if i + 1 >= len(argv):
                print("./executable: '-l' needs argument", file=sys.stderr); return 1
            libs.append(argv[i + 1]); i += 2; continue
        if a.startswith("-l") and len(a) > 2:
            libs.append(a[2:]); i += 1; continue
        if a == "-b":
            print("./executable: unknown luaJIT command or jit.* modules not installed", file=sys.stderr)
            print(usage()); return 1
        if a.startswith("-j"):
            i += 1; continue
        if a.startswith("-O"):
            i += 1; continue
        if a == "--":
            i += 1
            if i < len(argv):
                script = argv[i]; script_args = argv[i + 1:]
            break
        if a == "-":
            script = "-"; script_args = argv[i + 1:]; break
        if a.startswith("-"):
            print("./executable: unknown option '" + a + "'", file=sys.stderr)
            print(usage()); return 1
        script = a
        script_args = argv[i + 1:]
        break
    if show_version:
        print(VERSION_LINE)
    env = base_env(script, script_args)
    for lib in libs:
        env["require"](lib)
    try:
        for ch in chunks:
            run_chunk(ch, env, "(command line)")
        if script:
            if script == "-":
                src = sys.stdin.read()
                run_chunk(src, env, "stdin")
            else:
                try:
                    with open(script, "r", encoding="utf-8") as f:
                        src = f.read()
                except OSError as e:
                    print(f"./executable: cannot open {script}: {e.strerror}", file=sys.stderr)
                    return 1
                run_chunk(src, env, script)
        if interactive or (not script and not chunks and not show_version):
            if not show_version:
                print(VERSION_LINE)
            repl(env)
    except LuaError as e:
        print("./executable: " + str(e), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
