#!/usr/bin/env python3
import argparse
import csv
import os
import sys
import unicodedata


VERSION = "csview 1.3.4"
STYLES = {"none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid"}
ALIGNS = {"left", "center", "right"}


def char_width(ch):
    if unicodedata.combining(ch):
        return 0
    cp = ord(ch)
    if cp == 0:
        return 0
    if cp < 32 or 0x7F <= cp < 0xA0:
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    if 0x1F000 <= cp <= 0x1FAFF or 0x2600 <= cp <= 0x27BF:
        return 2
    return 1


def text_width(s):
    return sum(char_width(ch) for ch in s)


def truncate_width(s, limit):
    out = []
    used = 0
    for ch in s:
        w = char_width(ch)
        if used + w > limit:
            break
        out.append(ch)
        used += w
    return "".join(out)


def align_text(s, width, align):
    s = truncate_width(s, width)
    pad = width - text_width(s)
    if align == "right":
        return " " * pad + s
    if align == "center":
        left = pad // 2
        return " " * left + s + " " * (pad - left)
    return s + " " * pad


def die_arg(message):
    print(message, file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print_help()
        sys.exit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        sys.exit(0)

    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("-H", "--no-headers", action="store_true")
    parser.add_argument("-n", "--number", action="store_true")
    parser.add_argument("-t", "--tsv", action="store_true")
    parser.add_argument("-d", "--delimiter", default=",")
    parser.add_argument("-s", "--style", default="sharp")
    parser.add_argument("-p", "--padding", default="1")
    parser.add_argument("-i", "--indent", default="0")
    parser.add_argument("--sniff", default="1000")
    parser.add_argument("--header-align", default="center")
    parser.add_argument("--body-align", default="left")
    parser.add_argument("-P", "--disable-pager", action="store_true")
    parser.add_argument("file", nargs="?")
    try:
        ns, extra = parser.parse_known_args(argv)
    except SystemExit:
        sys.exit(2)
    if extra:
        die_arg(f"error: unexpected argument '{extra[0]}' found")
    if ns.style not in STYLES:
        die_arg(
            f"error: invalid value '{ns.style}' for '--style <STYLE>'\n"
            "  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]"
        )
    if ns.header_align not in ALIGNS:
        die_arg(
            f"error: invalid value '{ns.header_align}' for '--header-align <HEADER_ALIGN>'\n"
            "  [possible values: left, center, right]"
        )
    if ns.body_align not in ALIGNS:
        die_arg(
            f"error: invalid value '{ns.body_align}' for '--body-align <BODY_ALIGN>'\n"
            "  [possible values: left, center, right]"
        )
    if len(ns.delimiter) != 1:
        die_arg(f"error: invalid value '{ns.delimiter}' for '--delimiter <DELIMITER>': too many characters in string")
    for name in ("padding", "indent", "sniff"):
        val = getattr(ns, name)
        try:
            iv = int(val)
        except ValueError:
            opt = "--" + name
            die_arg(f"error: invalid value '{val}' for '{opt} <{name.upper()}>': invalid digit found in string")
        if iv < 0:
            opt = "--" + name
            die_arg(f"error: invalid value '{val}' for '{opt} <{name.upper()}>': invalid digit found in string")
        setattr(ns, name.replace("-", "_"), iv)
    if ns.tsv:
        ns.delimiter = "\t"
    return ns


def print_help():
    print("""A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version""")


def read_rows(ns):
    try:
        if ns.file:
            f = open(ns.file, newline="")
        else:
            f = sys.stdin
        with f:
            rows = list(csv.reader(f, delimiter=ns.delimiter))
    except FileNotFoundError as e:
        print(f"csview: {e.strerror} (os error {e.errno})", file=sys.stderr)
        sys.exit(1)
    except csv.Error as e:
        print(f"csview: CSV error: {e}", file=sys.stderr)
        sys.exit(1)

    if rows:
        expected = len(rows[0])
        byte_pos = len(ns.delimiter.join(rows[0]).encode()) + 1
        for i, row in enumerate(rows[1:], 1):
            if len(row) != expected:
                print(
                    f"csview: CSV error: record {i} (line: {i + 1}, byte: {byte_pos}): "
                    f"found record with {len(row)} fields, but the previous record has {expected} fields",
                    file=sys.stderr,
                )
                sys.exit(1)
            byte_pos += len(ns.delimiter.join(row).encode()) + 1
    return rows


def split_rows(rows, no_headers, numbered):
    header = None
    body = rows
    if rows and not no_headers:
        header = rows[0]
        body = rows[1:]
    if numbered:
        if header is not None:
            header = ["#"] + header
            body = [[str(i + 1)] + r for i, r in enumerate(body)]
        else:
            body = [[str(i + 1)] + r for i, r in enumerate(body)]
    return header, body


def widths_for(header, body, sniff):
    all_rows = []
    if header is not None:
        all_rows.append(header)
    if sniff == 0:
        all_rows.extend(body)
    else:
        all_rows.extend(body[:sniff])
    cols = max((len(r) for r in all_rows), default=0)
    widths = [0] * cols
    for row in all_rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], text_width(cell))
    return widths


def border_chars(style):
    if style in ("sharp", "grid"):
        return ("┌", "┬", "┐", "├", "┼", "┤", "└", "┴", "┘", "─", "│")
    if style == "rounded":
        return ("╭", "┬", "╮", "├", "┼", "┤", "╰", "┴", "╯", "─", "│")
    if style == "reinforced":
        return ("┏", "┬", "┓", "├", "┼", "┤", "┗", "┴", "┛", "─", "│")
    if style == "ascii":
        return ("+", "+", "+", "+", "+", "+", "+", "+", "+", "-", "|")
    return None


def fmt_row(row, widths, padding, align, style):
    pad = " " * padding
    cells = [pad + align_text(row[i] if i < len(row) else "", w, align) + pad for i, w in enumerate(widths)]
    if style == "none":
        return "".join(cells)
    if style in ("ascii2", "markdown"):
        return ("|" if style == "markdown" else " ") + "|".join(cells) + ("|" if style == "markdown" else " ")
    vc = border_chars(style)[10]
    return vc + vc.join(cells) + vc


def fmt_border(widths, padding, style, part):
    total = [w + 2 * padding for w in widths]
    if style == "ascii2":
        return " " + "+".join("-" * w for w in total) + " "
    if style == "markdown":
        return "|" + "|".join("-" * w for w in total) + "|"
    chars = border_chars(style)
    if part == "top":
        l, j, r = chars[0], chars[1], chars[2]
    elif part == "mid":
        l, j, r = chars[3], chars[4], chars[5]
    else:
        l, j, r = chars[6], chars[7], chars[8]
    return l + j.join(chars[9] * w for w in total) + r


def render(header, body, widths, ns):
    style = ns.style
    lines = []
    indent = " " * ns.indent
    has_header = header is not None
    if not widths and not has_header and not body:
        widths = []
        body = [[]]

    if style == "none":
        rows = []
        if header is not None:
            rows.append((header, ns.header_align))
        rows.extend((r, ns.body_align) for r in body)
        return "\n".join(indent + fmt_row(r, widths, ns.padding, a, style) for r, a in rows)

    if style == "ascii2":
        if header is not None:
            lines.append(fmt_row(header, widths, ns.padding, ns.header_align, style))
            if body:
                lines.append(fmt_border(widths, ns.padding, style, "mid"))
        lines.extend(fmt_row(r, widths, ns.padding, ns.body_align, style) for r in body)
        return "\n".join(indent + line for line in lines)

    if style == "markdown":
        if header is not None:
            lines.append(fmt_row(header, widths, ns.padding, ns.header_align, style))
            lines.append(fmt_border(widths, ns.padding, style, "mid"))
            lines.extend(fmt_row(r, widths, ns.padding, ns.body_align, style) for r in body)
        else:
            lines.extend(fmt_row(r, widths, ns.padding, ns.body_align, style) for r in body)
        return "\n".join(indent + line for line in lines)

    lines.append(fmt_border(widths, ns.padding, style, "top"))
    if header is not None:
        lines.append(fmt_row(header, widths, ns.padding, ns.header_align, style))
        if body:
            lines.append(fmt_border(widths, ns.padding, style, "mid"))
    for idx, row in enumerate(body):
        lines.append(fmt_row(row, widths, ns.padding, ns.body_align, style))
        if style == "grid" and idx != len(body) - 1:
            lines.append(fmt_border(widths, ns.padding, style, "mid"))
    lines.append(fmt_border(widths, ns.padding, style, "bottom"))
    return "\n".join(indent + line for line in lines)


def main(argv):
    ns = parse_args(argv)
    rows = read_rows(ns)
    header, body = split_rows(rows, ns.no_headers, ns.number)
    widths = widths_for(header, body, ns.sniff)
    out = render(header, body, widths, ns)
    if out:
        print(out)


if __name__ == "__main__":
    main(sys.argv[1:])
