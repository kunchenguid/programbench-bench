#!/usr/bin/env python3
import argparse
import csv
import fnmatch
import hashlib
import html
import json
import math
import os
import re
import stat
import sys
from dataclasses import dataclass, field

VERSION = "3.7.0"
BORDER = "─" * 79
BORDER_WIDE = "─" * 109
DASH = "-" * 79

LANGS = {
    "go": ("Go", "//", [("/*", "*/")]), "py": ("Python", "#", [('"""', '"""'), ("'''", "'''")]),
    "sh": ("Shell", "#", []), "bash": ("BASH", "#", []), "zsh": ("Zsh", "#", []),
    "c": ("C", "//", [("/*", "*/")]), "h": ("C Header", "//", [("/*", "*/")]),
    "cpp": ("C++", "//", [("/*", "*/")]), "cc": ("C++", "//", [("/*", "*/")]), "cxx": ("C++", "//", [("/*", "*/")]),
    "hpp": ("C++ Header", "//", [("/*", "*/")]), "hh": ("C++ Header", "//", [("/*", "*/")]),
    "java": ("Java", "//", [("/*", "*/")]), "js": ("JavaScript", "//", [("/*", "*/")]),
    "cjs": ("JavaScript", "//", [("/*", "*/")]), "mjs": ("JavaScript", "//", [("/*", "*/")]),
    "ts": ("TypeScript", "//", [("/*", "*/")]), "tsx": ("TypeScript JSX", "//", [("/*", "*/")]),
    "jsx": ("JSX", "//", [("/*", "*/")]), "cs": ("C#", "//", [("/*", "*/")]),
    "rs": ("Rust", "//", [("/*", "*/")]), "rb": ("Ruby", "#", []), "pl": ("Perl", "#", []),
    "php": ("PHP", "//", [("/*", "*/")]), "swift": ("Swift", "//", [("/*", "*/")]),
    "kt": ("Kotlin", "//", [("/*", "*/")]), "kts": ("Kotlin", "//", [("/*", "*/")]),
    "scala": ("Scala", "//", [("/*", "*/")]), "r": ("R", "#", []), "lua": ("Lua", "--", [("--[[", "]]")]),
    "sql": ("SQL", "--", [("/*", "*/")]), "html": ("HTML", None, [("<!--", "-->")]),
    "htm": ("HTML", None, [("<!--", "-->")]), "xml": ("XML", None, [("<!--", "-->")]),
    "xhtml": ("XML", None, [("<!--", "-->")]), "css": ("CSS", None, [("/*", "*/")]),
    "scss": ("Sass", "//", [("/*", "*/")]), "less": ("Less", "//", [("/*", "*/")]),
    "md": ("Markdown", None, []), "markdown": ("Markdown", None, []), "txt": ("Plain Text", None, []),
    "json": ("JSON", None, []), "yaml": ("YAML", "#", []), "yml": ("YAML", "#", []),
    "toml": ("TOML", "#", []), "ini": ("INI", "#", []), "csv": ("CSV", None, []),
    "makefile": ("Makefile", "#", []), "mk": ("Makefile", "#", []), "cmake": ("CMake", "#", []),
    "dockerfile": ("Dockerfile", "#", []), "vim": ("Vim Script", '"', []), "el": ("Emacs Lisp", ";", []),
    "clj": ("Clojure", ";", []), "hs": ("Haskell", "--", [("{-", "-}")]), "erl": ("Erlang", "%", []),
    "ex": ("Elixir", "#", []), "exs": ("Elixir", "#", []), "dart": ("Dart", "//", [("/*", "*/")]),
    "vue": ("Vue", None, [("<!--", "-->")]), "svelte": ("Svelte", None, [("<!--", "-->")]),
}

NAME_ALIASES = {v[0].lower(): v[0] for v in LANGS.values()}
NAME_ALIASES.update({"c header": "C Header", "c++ header": "C++ Header", "shell": "Shell"})

COMPLEXITY_WORDS = [
    "if", "for", "while", "case", "catch", "except", "elif", "else if", "switch",
    "&&", "||", "?", "foreach", "when", "guard", "loop",
]

@dataclass
class FileStat:
    language: str
    filename: str
    extension: str
    location: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    uloc: int = 0
    max_line: int = 0
    mean_line: int = 0
    code_lines: set = field(default_factory=set)
    all_lines: set = field(default_factory=set)

@dataclass
class LangStat:
    name: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    count: int = 0
    files: list = field(default_factory=list)
    code_lines: set = field(default_factory=set)
    all_lines: set = field(default_factory=set)
    max_line: int = 0
    mean_sum: int = 0

def ext_for(path):
    base = os.path.basename(path)
    low = base.lower()
    if low in ("makefile", "gnumakefile"):
        return "makefile"
    if low.startswith("dockerfile"):
        return "dockerfile"
    if "." in base:
        return base.rsplit(".", 1)[1].lower()
    return ""

def detect_language(path, count_as):
    ext = ext_for(path)
    if ext in count_as:
        return count_as[ext], ext
    if ext in LANGS:
        return LANGS[ext][0], ext
    base = os.path.basename(path).lower()
    if base in LANGS:
        return LANGS[base][0], base
    try:
        with open(path, "rb") as f:
            first = f.readline(200).decode("utf-8", "ignore").lower()
        if first.startswith("#!"):
            if "python" in first:
                return "Python", ext
            if "bash" in first:
                return "BASH", ext
            if "sh" in first:
                return "Shell", ext
            if "ruby" in first:
                return "Ruby", ext
            if "perl" in first:
                return "Perl", ext
    except OSError:
        pass
    return None, ext

def spec_for(lang):
    for _, v in LANGS.items():
        if v[0] == lang:
            return v[1], v[2]
    if lang in ("Python", "Ruby", "Shell", "BASH", "YAML", "TOML", "Makefile", "Dockerfile"):
        return "#", []
    if lang in ("C", "C Header", "C++", "C++ Header", "Go", "Java", "JavaScript", "TypeScript", "Rust"):
        return "//", [("/*", "*/")]
    return None, []

def is_binary(data):
    return b"\0" in data[:4096]

def count_complexity(line, lang):
    s = re.sub(r"(['\"]).*?\1", "", line)
    total = 0
    for w in COMPLEXITY_WORDS:
        if w in ("&&", "||", "?"):
            total += s.count(w)
        elif " " in w:
            total += len(re.findall(r"\b" + re.escape(w).replace("\\ ", r"\s+") + r"\b", s))
        else:
            total += len(re.findall(r"\b" + re.escape(w) + r"\b", s))
    return total

def analyze(path, root, lang, ext):
    st = FileStat(lang, os.path.basename(path), ext, os.path.relpath(path, root))
    try:
        data = open(path, "rb").read()
    except OSError:
        return None
    if is_binary(data):
        return None
    st.bytes = len(data)
    text = data.decode("utf-8", "ignore")
    lines = text.splitlines()
    if text and (text.endswith("\n") or text.endswith("\r")):
        pass
    st.lines = len(lines)
    line_lengths = [len(x.rstrip("\r")) for x in lines]
    st.all_lines = set(lines)
    st.max_line = max(line_lengths) if line_lengths else 0
    st.mean_line = int(sum(line_lengths) / len(line_lengths)) if line_lengths else 0
    single, blocks = spec_for(lang)
    in_block = None
    for raw in lines:
        line = raw.rstrip("\r")
        stripped = line.strip()
        if stripped == "":
            st.blank += 1
            continue
        code_part = stripped
        comment_only = False
        if in_block:
            end = stripped.find(in_block)
            st.comment += 1
            if end >= 0:
                rest = stripped[end + len(in_block):].strip()
                in_block = None
                if rest:
                    st.code += 1
                    st.code_lines.add(rest)
                    st.complexity += count_complexity(rest, lang)
            continue
        for start, endtok in blocks:
            pos = code_part.find(start)
            if pos >= 0:
                before = code_part[:pos].strip()
                after = code_part[pos + len(start):]
                endpos = after.find(endtok)
                if before:
                    code_part = before
                else:
                    comment_only = True
                if endpos < 0:
                    in_block = endtok
                if comment_only:
                    st.comment += 1
                    if endpos >= 0:
                        rest = after[endpos + len(endtok):].strip()
                        if rest:
                            st.code += 1
                            st.code_lines.add(rest)
                            st.complexity += count_complexity(rest, lang)
                    code_part = ""
                break
        if code_part:
            if single and code_part.startswith(single):
                st.comment += 1
            else:
                st.code += 1
                st.code_lines.add(code_part)
                st.complexity += count_complexity(code_part, lang)
    st.uloc = len(set(lines))
    return st

def parse_csv(v):
    out = set()
    for part in v or []:
        for x in str(part).split(","):
            x = x.strip().lower().lstrip(".")
            if x:
                out.add(x)
    return out

def parse_count_as(v):
    m = {}
    if not v:
        return m
    for item in v.split(","):
        if ":" not in item:
            continue
        a, b = item.split(":", 1)
        a = a.strip().lower().lstrip(".")
        b = b.strip().strip('"').strip("'")
        if b.lower() in LANGS:
            lang = LANGS[b.lower()][0]
        else:
            lang = NAME_ALIASES.get(b.lower(), b)
        if a:
            m[a] = lang
    return m

def discover(paths, args, count_as):
    exclude_dirs = set(args.exclude_dir or [".git", ".hg", ".svn"])
    exclude_files = set(args.exclude_file or ["package-lock.json", "Cargo.lock", "yarn.lock", "pubspec.lock", "Podfile.lock", "pnpm-lock.yaml"])
    include = parse_csv(args.include_ext)
    exclude = parse_csv(args.exclude_ext)
    if not paths:
        paths = ["."]
    files = []
    for p in paths:
        if os.path.isfile(p):
            files.append(p)
        elif os.path.isdir(p):
            for dirpath, dirnames, filenames in os.walk(p, followlinks=args.include_symlinks):
                dirnames[:] = [d for d in dirnames if d not in exclude_dirs]
                for name in sorted(filenames):
                    full = os.path.join(dirpath, name)
                    try:
                        mode = os.lstat(full).st_mode
                        if stat.S_ISLNK(mode) and not args.include_symlinks:
                            continue
                    except OSError:
                        continue
                    files.append(full)
    out = []
    regexes = [re.compile(x) for x in args.not_match or []]
    ignore_files = []
    if not args.no_gitignore:
        ignore_files.append(".gitignore")
    if not args.no_ignore:
        ignore_files.append(".ignore")
    if not args.no_scc_ignore:
        ignore_files.append(".sccignore")

    def load_patterns(d):
        pats = []
        for ign in ignore_files:
            p = os.path.join(d, ign)
            if not os.path.exists(p):
                continue
            try:
                for line in open(p, "r", encoding="utf-8", errors="ignore"):
                    line = line.strip()
                    if not line or line.startswith("#") or line.startswith("!"):
                        continue
                    pats.append(line)
            except OSError:
                pass
        return pats

    root_patterns = load_patterns(".")

    def ignored(rel, is_dir=False):
        rel = rel.replace(os.sep, "/")
        base = os.path.basename(rel)
        for pat in root_patterns:
            p = pat.strip("/")
            if pat.endswith("/") and not is_dir:
                continue
            if fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(base, p) or rel.startswith(p.rstrip("/") + "/"):
                return True
        return False

    for f in sorted(files):
        name = os.path.basename(f)
        if name in exclude_files and not args.count_ignore:
            continue
        rel = os.path.relpath(f, ".")
        if ignored(rel, False):
            continue
        if any(r.search(rel) for r in regexes):
            continue
        lang, ext = detect_language(f, count_as)
        if not lang:
            continue
        if include and ext not in include:
            continue
        if exclude and ext in exclude:
            continue
        out.append((f, lang, ext))
    if args.no_duplicates:
        seen = set()
        deduped = []
        for f, lang, ext in out:
            try:
                h = hashlib.sha1(open(f, "rb").read()).hexdigest()
            except OSError:
                continue
            if h in seen:
                continue
            seen.add(h)
            deduped.append((f, lang, ext))
        out = deduped
    return out

def aggregate(files, root):
    langs = {}
    all_files = []
    for path, lang, ext in files:
        fs = analyze(path, root, lang, ext)
        if not fs:
            continue
        all_files.append(fs)
        ls = langs.setdefault(lang, LangStat(lang))
        ls.bytes += fs.bytes; ls.lines += fs.lines; ls.code += fs.code; ls.comment += fs.comment
        ls.blank += fs.blank; ls.complexity += fs.complexity; ls.count += 1; ls.files.append(fs)
        ls.code_lines.update(fs.code_lines); ls.all_lines.update(fs.all_lines); ls.max_line = max(ls.max_line, fs.max_line); ls.mean_sum += fs.mean_line
    return langs, all_files

def sort_langs(langs, key):
    vals = list(langs.values())
    if key == "name":
        return sorted(vals, key=lambda x: x.name.lower())
    attr = {"files": "count", "lines": "lines", "blanks": "blank", "code": "code", "comments": "comment", "complexity": "complexity"}.get(key, "count")
    return sorted(vals, key=lambda x: (-getattr(x, attr), x.name.lower()))

def commas(n):
    return f"{int(n):,}"

def row(name, files, lines, blank, comment, code, complexity, no_complexity=False):
    if no_complexity:
        return f"{name:<24}{files:>9}{lines:>12}{blank:>11}{comment:>12}{code:>11}"
    return f"{name:<18}{files:>7}{lines:>12}{blank:>10}{comment:>10}{code:>11}{complexity:>11}"

def print_tabular(langs, args):
    no_complexity = args.no_complexity
    print(BORDER)
    if no_complexity:
        print(f"{'Language':<24}{'Files':>9}{'Lines':>12}{'Blanks':>11}{'Comments':>12}{'Code':>11}")
    else:
        print(f"{'Language':<18}{'Files':>7}{'Lines':>12}{'Blanks':>10}{'Comments':>10}{'Code':>11}{'Complexity':>11}")
    print(BORDER)
    total = LangStat("Total")
    ordered = sort_langs(langs, args.sort)
    for ls in ordered:
        total.bytes += ls.bytes; total.lines += ls.lines; total.blank += ls.blank; total.comment += ls.comment
        total.code += ls.code; total.complexity += ls.complexity; total.count += ls.count
        print(row(ls.name, ls.count, ls.lines, ls.blank, ls.comment, ls.code, ls.complexity, no_complexity))
        if args.by_file:
            print(BORDER)
            for fs in sorted(ls.files, key=lambda f: f.location):
                print(row(fs.location, "", fs.lines, fs.blank, fs.comment, fs.code, fs.complexity, no_complexity))
            print(BORDER)
        if args.uloc or args.dryness:
            print(f"{'(ULOC)':<18}{'':>7}{len(ls.all_lines):>12}")
            if ls != ordered[-1]:
                print(DASH)
        if args.character:
            mean = int(ls.mean_sum / ls.count) if ls.count else 0
            print(f"{'MaxLine / MeanLine':<18}{ls.max_line:>7}{mean:>12}")
            if ls != ordered[-1]:
                print(DASH)
        if args.percent:
            def pct(a, b): return "0.0%" if b == 0 else f"{(a / b * 100):.1f}%"
            print(f"{'Percentage':<18}{pct(ls.count,total_count(langs)):>7}{pct(ls.lines,total_lines(langs)):>12}{pct(ls.blank,total_blank(langs)):>10}{pct(ls.comment,total_comment(langs)):>10}{pct(ls.code,total_code(langs)):>11}{pct(ls.complexity,total_complexity(langs)):>11}")
            if ls != ordered[-1]:
                print(DASH)
    if not (args.by_file and ordered):
        print(BORDER)
    print(row("Total", total.count, total.lines, total.blank, total.comment, total.code, total.complexity, no_complexity))
    print(BORDER)
    if args.uloc or args.dryness:
        u = len(set().union(*(ls.all_lines for ls in langs.values()))) if langs else 0
        print(f"{'Unique Lines of Code (ULOC)':<30}{u:>8}")
        if args.dryness:
            print(f"{'DRYness %':<30}{(u / total.lines if total.lines else 0):>8.2f}")
        print(BORDER)
    if not args.no_cocomo:
        cost, sched, people = cocomo(total.code, args)
        symbol = args.currency_symbol
        print(f"Estimated Cost to Develop (organic) {symbol}{int(cost):,}")
        print(f"Estimated Schedule Effort (organic) {sched:.2f} months")
        print(f"Estimated People Required (organic) {people:.2f}")
        print(BORDER)
    if not args.no_size:
        mb = total.bytes / 1_000_000
        print(f"Processed {total.bytes} bytes, {mb:.3f} megabytes (SI)")
        print(BORDER)

def total_count(langs): return sum(x.count for x in langs.values())
def total_lines(langs): return sum(x.lines for x in langs.values())
def total_blank(langs): return sum(x.blank for x in langs.values())
def total_comment(langs): return sum(x.comment for x in langs.values())
def total_code(langs): return sum(x.code for x in langs.values())
def total_complexity(langs): return sum(x.complexity for x in langs.values())

def cocomo(code, args):
    kloc = max(code, 1) / 1000.0
    effort = 2.4 * (kloc ** 1.05) * args.eaf
    sched = 2.5 * (effort ** 0.38)
    people = effort / sched if sched else 0
    cost = effort * args.avg_wage / 12.0 * args.overhead
    return cost, sched, people

def obj_lang(ls, by_file=False, include_uloc=False):
    files = []
    if by_file:
        for f in sorted(ls.files, key=lambda x: x.location):
            files.append({"Language": f.language, "PossibleLanguages": [f.language], "Filename": f.filename, "Extension": f.extension,
                          "Location": f.location, "Symlocation": "", "Bytes": f.bytes, "Lines": f.lines, "Code": f.code,
                          "Comment": f.comment, "Blank": f.blank, "Complexity": f.complexity, "WeightedComplexity": 0,
                          "Hash": None, "Binary": False, "Minified": False, "Generated": False, "EndPoint": 0, "Uloc": f.uloc})
    return {"Name": ls.name, "Bytes": ls.bytes, "CodeBytes": 0, "Lines": ls.lines, "Code": ls.code, "Comment": ls.comment,
            "Blank": ls.blank, "Complexity": ls.complexity, "Count": ls.count, "WeightedComplexity": 0,
            "Files": files, "LineLength": None, "ULOC": (len(ls.all_lines) if include_uloc else 0)}

def emit_json(langs, args, wrap=False):
    arr = [obj_lang(x, args.by_file, args.uloc) for x in sort_langs(langs, args.sort)]
    if wrap:
        code = total_code(langs)
        cost, sched, people = cocomo(code, args)
        print(json.dumps({"languageSummary": arr, "estimatedCost": cost, "estimatedScheduleMonths": sched, "estimatedPeople": people}, separators=(",", ":")))
    else:
        print(json.dumps(arr, separators=(",", ":")))

def emit_csv(langs, args):
    w = csv.writer(sys.stdout, lineterminator="\n")
    w.writerow(["Language", "Lines", "Code", "Comments", "Blanks", "Complexity", "Bytes", "Files", "ULOC"])
    for ls in sort_langs(langs, args.sort):
        w.writerow([ls.name, ls.lines, ls.code, ls.comment, ls.blank, ls.complexity, ls.bytes, ls.count, len(ls.code_lines) if args.uloc else 0])

def emit_yaml(langs):
    print("# https://github.com/boyter/scc/")
    print("header:")
    print("  url: https://github.com/boyter/scc/")
    print(f"  version: {VERSION}")
    print("  elapsed_seconds: 0.001")
    print(f"  n_files: {total_count(langs)}")
    print(f"  n_lines: {total_lines(langs)}")
    for ls in sort_langs(langs, "name"):
        print(f"{ls.name}:")
        print(f"  name: {ls.name}")
        print(f"  code: {ls.code}")
        print(f"  comment: {ls.comment}")
        print(f"  blank: {ls.blank}")
        print(f"  nFiles: {ls.count}")
    print("SUM:")
    print(f"  code: {total_code(langs)}")
    print(f"  comment: {total_comment(langs)}")
    print(f"  blank: {total_blank(langs)}")
    print(f"  nFiles: {total_count(langs)}")

def emit_openmetrics(langs):
    metrics = [("files", "Number of sourcecode files."), ("lines", "Number of lines."), ("code", "Number of lines of actual code."),
               ("comments", "Number of comments."), ("blanks", "Number of blank lines."), ("complexity", "Code complexity."), ("bytes", "Size in bytes.")]
    for m, helptext in metrics:
        print(f"# TYPE scc_{m} gauge")
        if m == "bytes":
            print("# UNIT scc_bytes bytes")
        print(f"# HELP scc_{m} {helptext}")
    for ls in sort_langs(langs, "name"):
        vals = {"files": ls.count, "lines": ls.lines, "code": ls.code, "comments": ls.comment, "blanks": ls.blank, "complexity": ls.complexity, "bytes": ls.bytes}
        for k, v in vals.items():
            print(f'scc_{k}{{language="{ls.name}"}} {v}')

def emit_html(langs, table_only=False):
    rows = "".join(f"<tr><td>{html.escape(ls.name)}</td><td>{ls.count}</td><td>{ls.lines}</td><td>{ls.blank}</td><td>{ls.comment}</td><td>{ls.code}</td><td>{ls.complexity}</td></tr>" for ls in sort_langs(langs, "name"))
    table = "<table><tr><th>Language</th><th>Files</th><th>Lines</th><th>Blanks</th><th>Comments</th><th>Code</th><th>Complexity</th></tr>" + rows + "</table>"
    print(table if table_only else "<!doctype html><html><body>" + table + "</body></html>")

def emit_sql(langs, project="", inserts_only=False):
    if not inserts_only:
        print("CREATE TABLE metadata (project TEXT, language TEXT, files INTEGER, lines INTEGER, blanks INTEGER, comments INTEGER, code INTEGER, complexity INTEGER, bytes INTEGER);")
    project = (project or "").replace("'", "''")
    for ls in sort_langs(langs, "name"):
        name = ls.name.replace("'", "''")
        print(f"INSERT INTO metadata(project, language, files, lines, blanks, comments, code, complexity, bytes) VALUES ('{project}', '{name}', {ls.count}, {ls.lines}, {ls.blank}, {ls.comment}, {ls.code}, {ls.complexity}, {ls.bytes});")

def print_wide(langs, args):
    print(BORDER_WIDE)
    print(f"{'Language':<34}{'Files':>7}{'Lines':>10}{'Blanks':>9}{'Comments':>10}{'Code':>9}{'Complexity':>11}{'Complexity/Lines':>17}")
    print(BORDER_WIDE)
    tot = LangStat("Total")
    for ls in sort_langs(langs, args.sort):
        for a in ("bytes","lines","blank","comment","code","complexity","count"):
            setattr(tot, a, getattr(tot, a) + getattr(ls, a))
        ratio = (ls.complexity / ls.code * 100) if ls.code else 0
        print(f"{ls.name:<34}{ls.count:>7}{ls.lines:>10}{ls.blank:>9}{ls.comment:>10}{ls.code:>9}{ls.complexity:>11}{ratio:>17.2f}")
    print(BORDER_WIDE)
    ratio = (tot.complexity / tot.code * 100) if tot.code else 0
    print(f"{'Total':<34}{tot.count:>7}{tot.lines:>10}{tot.blank:>9}{tot.comment:>10}{tot.code:>9}{tot.complexity:>11}{ratio:>17.2f}")
    print(BORDER_WIDE)

HELP = """Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version 3.7.0
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
      --by-file                            display output for every file
  -m, --character                          calculate max and mean characters per line
  -a, --dryness                            calculate the DRYness of the project (implies --uloc)
  -x, --exclude-ext strings                ignore file extensions
  -n, --exclude-file strings               ignore files with matching names
  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
  -h, --help                               help for scc
  -i, --include-ext strings                limit to file extensions
  -l, --languages                          print supported languages and extensions
      --no-cocomo                          remove COCOMO calculation output
  -c, --no-complexity                      skip calculation of code complexity
  -d, --no-duplicates                      remove duplicate files from stats and output
      --no-size                            remove size calculation output
  -o, --output string                      output filename (default stdout)
  -p, --percent                            include percentage values in output
  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
  -v, --verbose                            verbose output
      --version                            version for scc
  -w, --wide                               wider output with additional statistics
"""

def build_parser():
    p = argparse.ArgumentParser(add_help=False)
    for opt in ["--by-file", "--ci", "--count-ignore", "--debug", "--gen", "--include-symlinks", "--min", "--no-cocomo", "--no-complexity", "--no-duplicates", "--no-gen", "--no-gitignore", "--no-gitmodule", "--no-hborder", "--no-ignore", "--no-large", "--no-min", "--no-min-gen", "--no-scc-ignore", "--no-size", "--sloccount-format", "--trace", "--verbose", "--wide", "--percent", "--character", "--dryness", "--uloc", "--languages", "--version", "--help", "--binary", "--locomo", "--cost-comparison", "--mcp"]:
        p.add_argument(opt, action="store_true")
    p.add_argument("-h", action="store_true", dest="help_short")
    p.add_argument("-l", action="store_true", dest="languages_short")
    p.add_argument("-v", action="store_true", dest="verbose_short")
    p.add_argument("-w", action="store_true", dest="wide_short")
    p.add_argument("-p", action="store_true", dest="percent_short")
    p.add_argument("-m", action="store_true", dest="character_short")
    p.add_argument("-a", action="store_true", dest="dryness_short")
    p.add_argument("-u", action="store_true", dest="uloc_short")
    p.add_argument("-c", action="store_true", dest="no_complexity_short")
    p.add_argument("-d", action="store_true", dest="no_duplicates_short")
    p.add_argument("-f", "--format", default="tabular")
    p.add_argument("-o", "--output", default="")
    p.add_argument("-s", "--sort", default="files")
    p.add_argument("-i", "--include-ext", action="append")
    p.add_argument("-x", "--exclude-ext", action="append")
    p.add_argument("-n", "--exclude-file", action="append")
    p.add_argument("-M", "--not-match", action="append")
    p.add_argument("--exclude-dir", action="append")
    p.add_argument("--count-as", default="")
    p.add_argument("--avg-wage", type=int, default=56286)
    p.add_argument("--eaf", type=float, default=1.0)
    p.add_argument("--overhead", type=float, default=2.4)
    p.add_argument("--currency-symbol", default="$")
    for opt in ["--cocomo-project-type", "--format-multi", "--generated-markers", "--large-byte-count", "--large-line-count", "--locomo-config", "--locomo-cycles", "--locomo-input-price", "--locomo-output-price", "--locomo-preset", "--locomo-review", "--locomo-tps", "--min-gen-line-length", "--remap-all", "--remap-unknown", "--size-unit", "--sql-project", "--directory-walker-job-workers", "--file-gc-count", "--file-list-queue-size", "--file-process-job-workers", "--file-summary-job-queue-size"]:
        p.add_argument(opt)
    p.add_argument("-z", "--min-gen", action="store_true")
    p.add_argument("paths", nargs="*")
    return p

def main():
    parser = build_parser()
    try:
        args = parser.parse_args()
    except SystemExit as e:
        return e.code
    for a, b in [("help_short", "help"), ("languages_short", "languages"), ("wide_short", "wide"), ("percent_short", "percent"), ("character_short", "character"), ("dryness_short", "dryness"), ("uloc_short", "uloc"), ("no_complexity_short", "no_complexity")]:
        if getattr(args, a, False):
            setattr(args, b, True)
    if args.help:
        print(HELP.rstrip())
        return 0
    if args.version:
        print(f"scc version {VERSION}")
        return 0
    if args.languages:
        seen = []
        for ext, (name, _, _) in sorted(LANGS.items(), key=lambda x: (x[1][0], x[0])):
            if name not in seen:
                exts = ",".join(k for k, v in LANGS.items() if v[0] == name)
                print(f"{name} ({exts})")
                seen.append(name)
        return 0
    if args.dryness:
        args.uloc = True
    if args.wide:
        args.format = "wide"
    count_as = parse_count_as(args.count_as)
    files = discover(args.paths, args, count_as)
    langs, _ = aggregate(files, ".")
    def write():
        fmt = (args.format or "tabular").lower()
        if fmt == "json":
            emit_json(langs, args)
        elif fmt == "json2":
            emit_json(langs, args, True)
        elif fmt in ("csv", "csv-stream"):
            emit_csv(langs, args)
        elif fmt == "cloc-yaml":
            emit_yaml(langs)
        elif fmt == "openmetrics":
            emit_openmetrics(langs)
        elif fmt == "html":
            emit_html(langs)
        elif fmt == "html-table":
            emit_html(langs, True)
        elif fmt == "sql":
            emit_sql(langs, args.sql_project, False)
        elif fmt == "sql-insert":
            emit_sql(langs, args.sql_project, True)
        elif fmt == "wide":
            print_wide(langs, args)
        else:
            print_tabular(langs, args)
    if args.output:
        old = sys.stdout
        with open(args.output, "w", newline="") as f:
            sys.stdout = f
            write()
            sys.stdout = old
    else:
        write()
    return 0

if __name__ == "__main__":
    sys.exit(main())
