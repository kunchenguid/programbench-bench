#!/usr/bin/env python3
import sys, argparse, json, re, math, os, shlex, glob
from collections import OrderedDict

class Row(dict):
    pass

def conv(s):
    if s is None or isinstance(s, (int, float, bool, list, dict)):
        return s
    if not isinstance(s, str) or s == "":
        return s
    if re.fullmatch(r"[-+]?\d+", s):
        try:
            return int(s)
        except Exception:
            return s
    if re.fullmatch(r"[-+]?(?:\d+\.\d*|\d*\.\d+)(?:[eE][-+]?\d+)?", s) or re.fullmatch(r"[-+]?\d+[eE][-+]?\d+", s):
        try:
            return float(s)
        except Exception:
            return s
    if s == "true":
        return True
    if s == "false":
        return False
    if s == "null":
        return None
    return s

def valstr(v):
    if v is None:
        return "None"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if v.is_integer():
            return str(int(v))
        return ("%.6f" % v).rstrip("0").rstrip(".")
    if isinstance(v, list):
        return "[" + ", ".join(valstr(x) for x in v) + "]"
    if isinstance(v, dict):
        return json.dumps(v, separators=(",", ":"))
    return str(v)

def get_path(row, path):
    if path is None:
        return None
    path = path.strip()
    if path.startswith('["') and path.endswith('"]'):
        return row.get(path[2:-2])
    cur = row
    parts = []
    buf = ""
    i = 0
    while i < len(path):
        c = path[i]
        if c == ".":
            if buf:
                parts.append(buf)
                buf = ""
            i += 1
        elif c == "[":
            if buf:
                parts.append(buf)
                buf = ""
            j = path.find("]", i)
            tok = path[i + 1:j]
            if tok.startswith('"') and tok.endswith('"'):
                tok = tok[1:-1]
            else:
                try:
                    tok = int(tok)
                except Exception:
                    pass
            parts.append(tok)
            i = j + 1
        else:
            buf += c
            i += 1
    if buf:
        parts.append(buf)
    for p in parts:
        try:
            if isinstance(cur, dict):
                cur = cur.get(p)
            elif isinstance(cur, list) and isinstance(p, int):
                cur = cur[p]
            else:
                return None
        except Exception:
            return None
    return cur

def set_flat(row, obj, prefix=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            key = f"{prefix}.{k}" if prefix else k
            if isinstance(v, dict):
                set_flat(row, v, key)
            else:
                row[key] = v
    else:
        row[prefix or "_json"] = obj

def split_top(s, sep=","):
    out, buf, quote, depth = [], "", None, 0
    for i, c in enumerate(s):
        if quote:
            buf += c
            if c == quote and (i == 0 or s[i - 1] != "\\"):
                quote = None
        else:
            if c in "\"'":
                quote = c
                buf += c
            elif c in "([":
                depth += 1
                buf += c
            elif c in ")]":
                depth -= 1
                buf += c
            elif c == sep and depth == 0:
                out.append(buf.strip())
                buf = ""
            else:
                buf += c
    if buf.strip() or s.endswith(sep):
        out.append(buf.strip())
    return out

def parse_logfmt(text):
    try:
        toks = shlex.split(text)
    except Exception:
        return None
    d = Row()
    for t in toks:
        if "=" not in t:
            continue
        k, v = t.split("=", 1)
        d[k] = conv(v)
    return d if d else None

def make_parse_re(pattern):
    regex, i = "", 0
    while i < len(pattern):
        if pattern[i] == "*":
            regex += "(.*)"
            i += 1
        elif pattern[i].isspace():
            while i < len(pattern) and pattern[i].isspace():
                i += 1
            regex += r"\s+"
        else:
            regex += re.escape(pattern[i])
            i += 1
    return re.compile("^" + regex + "$")

class ExprEval:
    def __init__(self, row):
        self.row = row

    def eval(self, e):
        e = e.strip()
        env = {}
        for k, v in self.row.items():
            if re.fullmatch(r"[A-Za-z_]\w*", k):
                env[k] = v
        env.update({
            "abs": abs, "ceil": math.ceil, "floor": math.floor, "round": round,
            "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan,
            "log": math.log, "log10": math.log10, "exp": math.exp,
            "concat": lambda *a: "".join(valstr(x) for x in a),
            "contains": lambda h, n: valstr(n) in valstr(h),
            "length": lambda x: len(valstr(x)),
            "num": lambda x: float(x) if "." in valstr(x) else int(x),
            "parseHex": lambda x: int(str(x), 16),
            "substring": lambda s, a, b=None: valstr(s)[int(a):None if b is None else int(b)],
            "toLowerCase": lambda s: valstr(s).lower(),
            "toUpperCase": lambda s: valstr(s).upper(),
            "isNull": lambda x: x is None,
            "isEmpty": lambda x: x is None or valstr(x) == "",
            "isBlank": lambda x: x is None or valstr(x).strip() == "",
            "isNumeric": lambda x: bool(re.fullmatch(r"[-+]?(\d+(\.\d*)?|\.\d+)", valstr(x))),
            "if_": lambda c, a, b: a if c else b,
            "__get__": lambda p: get_path(self.row, p),
        })
        code = e.replace("<>", "!=").replace("&&", " and ").replace("||", " or ")
        code = re.sub(r"\btrue\b", "True", code, flags=re.I)
        code = re.sub(r"\bfalse\b", "False", code, flags=re.I)
        code = re.sub(r"\bnull\b", "None", code, flags=re.I)
        code = re.sub(r"\bif\s*\(", "if_(", code)
        code = re.sub(r'(?<!["\'])\b[A-Za-z_]\w*(?:\.[A-Za-z_]\w*|\[[^\]]+\])+',
                      lambda m: f'__get__("{m.group(0)}")', code)
        try:
            return eval(code, {"__builtins__": {}}, env)
        except NameError:
            return get_path(self.row, e)
        except Exception:
            return None

def match_filter(line, filt):
    f = filt.strip()
    if not f or f == "*":
        return True
    def repl(m):
        tok = m.group(0)
        up = tok.upper()
        if up in ("AND", "OR", "NOT"):
            return {"AND": " and ", "OR": " or ", "NOT": " not "}[up]
        if tok in ("(", ")"):
            return tok
        if tok.startswith('"'):
            return repr(tok[1:-1] in line)
        pat = tok.lower().replace("*", ".*")
        return repr(re.search(pat, line.lower()) is not None)
    try:
        rx = r'"[^"\\]*(?:\\.[^"\\]*)*"|\(|\)|\bAND\b|\bOR\b|\bNOT\b|[^\s()]+'
        expr = re.sub(rx, repl, f, flags=re.I)
        return bool(eval(expr, {"__builtins__": {}}, {}))
    except Exception:
        return f.lower().replace("*", "") in line.lower()

def apply_op(rows, op):
    op = op.strip()
    if not op:
        return rows, False
    low = op.lower()
    if low.startswith("json"):
        m = re.search(r"\bfrom\s+(.+)$", op, re.I)
        field = m.group(1).strip() if m else None
        out = []
        for r in rows:
            txt = valstr(get_path(r, field)) if field else r.get("_line", "")
            try:
                obj = json.loads(txt)
            except Exception:
                continue
            nr = Row(r)
            nr.pop("_line", None)
            set_flat(nr, obj)
            out.append(nr)
        return out, False
    if low.startswith("logfmt"):
        m = re.search(r"\bfrom\s+(.+)$", op, re.I)
        field = m.group(1).strip() if m else None
        out = []
        for r in rows:
            txt = valstr(get_path(r, field)) if field else r.get("_line", "")
            d = parse_logfmt(txt)
            if d is None:
                continue
            nr = Row(r)
            nr.pop("_line", None)
            nr.update(d)
            out.append(nr)
        return out, False
    if low.startswith("parse regex"):
        m = re.search(r'parse\s+regex\s+"(.*?)"(?:\s+from\s+(\S+))?', op, re.I)
        if not m:
            return rows, False
        rg = re.compile(m.group(1))
        field = m.group(2)
        nodrop = "nodrop" in low
        out = []
        for r in rows:
            txt = valstr(get_path(r, field)) if field else r.get("_line", "")
            mm = rg.search(txt)
            nr = Row(r)
            if mm:
                nr.pop("_line", None)
                nr.update({k: conv(v) for k, v in mm.groupdict().items()})
                out.append(nr)
            elif nodrop:
                out.append(nr)
        return out, False
    if low.startswith("parse "):
        m = re.search(r'parse\s+"(.*?)"(?:\s+from\s+(\S+))?\s+as\s+(.+)$', op, re.I)
        if not m:
            return rows, False
        pat, field, names = m.group(1), m.group(2), m.group(3)
        nodrop = "nodrop" in low
        noconv = "noconvert" in low
        names = re.sub(r"\b(nodrop|noconvert)\b", "", names, flags=re.I)
        cols = [x.strip() for x in names.split(",") if x.strip()]
        rg = make_parse_re(pat)
        out = []
        for r in rows:
            txt = valstr(get_path(r, field)) if field else r.get("_line", "")
            mm = rg.match(txt)
            nr = Row(r)
            if mm:
                nr.pop("_line", None)
                for c, v in zip(cols, mm.groups()):
                    nr[c] = v if noconv else conv(v)
                out.append(nr)
            elif nodrop:
                nr.pop("_line", None)
                for c in cols:
                    nr.setdefault(c, None)
                out.append(nr)
        return out, False
    if low.startswith("split"):
        m = re.match(r'split(?:\(([^)]+)\))?(?:\s+on\s+"(.*?)")?(?:\s+as\s+(\S+))?', op, re.I)
        field = m.group(1) if m else None
        sep = m.group(2) if m and m.group(2) is not None else ","
        new = m.group(3) if m else None
        out = []
        for r in rows:
            nr = Row(r)
            txt = valstr(get_path(r, field)) if field else r.get("_line", "")
            nr[new or field or "_split"] = [conv(x.strip()) for x in txt.split(sep)]
            nr.pop("_line", None)
            out.append(nr)
        return out, False
    if low.startswith("fields"):
        rest = op[6:].strip()
        mode = "only"
        if rest.lower().startswith("except "):
            mode, rest = "except", rest[7:].strip()
        elif rest.startswith("-"):
            mode, rest = "except", rest[1:].strip()
        elif rest.startswith("+") or rest.lower().startswith("only "):
            rest = re.sub(r"^(\+|only\s+)", "", rest, flags=re.I).strip()
        cols = [x.strip() for x in rest.split(",") if x.strip()]
        out = []
        for r in rows:
            if mode == "only":
                nr = Row({c: get_path(r, c) for c in cols if c in r or get_path(r, c) is not None})
            else:
                nr = Row({k: v for k, v in r.items() if k not in cols and k != "_line"})
            out.append(nr)
        return out, False
    if low.startswith("where "):
        expr = op[6:].strip()
        return [r for r in rows if ExprEval(r).eval(expr)], False
    if low.startswith("limit "):
        n = int(op.split()[1])
        return (rows[:n] if n >= 0 else rows[n:]), False
    if low.startswith("sort by "):
        rest = op[8:].strip()
        desc = False
        if rest.lower().endswith(" desc"):
            desc, rest = True, rest[:-5].strip()
        elif rest.lower().endswith(" asc"):
            rest = rest[:-4].strip()
        keys = split_top(rest)
        return sorted(rows, key=lambda r: tuple(ExprEval(r).eval(k) for k in keys), reverse=desc), False
    if low.startswith("total("):
        m = re.match(r"total\(([^)]+)\)(?:\s+as\s+(\S+))?", op, re.I)
        field, name, tot = m.group(1), m.group(2) or "_total", 0.0
        out = []
        for r in rows:
            try:
                tot += float(ExprEval(r).eval(field))
            except Exception:
                pass
            nr = Row(r)
            nr[name] = int(tot) if tot.is_integer() else tot
            out.append(nr)
        return out, False
    if re.search(r"\s+as\s+\S+$", op, re.I):
        m = re.match(r"(.+?)\s+as\s+(\S+)$", op, re.I)
        expr, name = m.group(1), m.group(2)
        out = []
        for r in rows:
            nr = Row(r)
            nr.pop("_line", None)
            nr[name] = ExprEval(nr).eval(expr)
            out.append(nr)
        return out, False
    if is_aggregate(op):
        return aggregate(rows, op), True
    return rows, False

def is_aggregate(op):
    return bool(re.match(r"\s*(count(?:\(|\b)|sum\(|average\(|avg\(|min\(|max\(|p\d+\(|pct\d+\(|count_distinct\()", op, re.I))

def aggregate(rows, op):
    parts = re.split(r"\s+by\s+", op, 1, flags=re.I)
    aggpart = parts[0].strip()
    bys = split_top(parts[1]) if len(parts) > 1 else []
    specs = split_top(aggpart)
    if not rows:
        return []
    groups = OrderedDict()
    for r in rows:
        key = tuple(ExprEval(r).eval(b) for b in bys)
        groups.setdefault(key, []).append(r)
    if not groups:
        groups[tuple()] = []
    out = []
    for key, rs in groups.items():
        nr = Row()
        for b, v in zip(bys, key):
            nr[b.strip()] = v
        for spec in specs:
            m_as = re.match(r"(.+?)\s+as\s+(\S+)$", spec, re.I)
            base = m_as.group(1).strip() if m_as else spec.strip()
            name = m_as.group(2) if m_as else None
            lb = base.lower()
            if lb == "count":
                nr[name or "_count"] = len(rs)
            elif lb.startswith("count("):
                cond = base[6:-1]
                nr[name or "_count"] = sum(1 for r in rs if ExprEval(r).eval(cond))
            elif lb.startswith("sum("):
                vals = []
                for r in rs:
                    try:
                        vals.append(float(ExprEval(r).eval(base[4:-1])))
                    except Exception:
                        pass
                s = sum(vals)
                nr[name or "_sum"] = int(s) if float(s).is_integer() else s
            elif lb.startswith(("average(", "avg(")):
                expr = base[base.find("(") + 1:-1]
                vals = []
                for r in rs:
                    try:
                        vals.append(float(ExprEval(r).eval(expr)))
                    except Exception:
                        pass
                a = sum(vals) / len(vals) if vals else None
                nr[name or "_average"] = int(a) if isinstance(a, float) and a.is_integer() else a
            elif lb.startswith("min(") or lb.startswith("max("):
                expr = base[4:-1]
                vals = [ExprEval(r).eval(expr) for r in rs if ExprEval(r).eval(expr) is not None]
                nr[name or ("_min" if lb.startswith("min") else "_max")] = (min(vals) if lb.startswith("min") and vals else max(vals) if vals else None)
            elif lb.startswith("count_distinct("):
                nr[name or "_countDistinct"] = len(set(valstr(ExprEval(r).eval(base[15:-1])) for r in rs))
            else:
                mm = re.match(r"(?:p|pct)(\d+)\((.*)\)", base, re.I)
                if mm:
                    pct, expr, vals = int(mm.group(1)), mm.group(2), []
                    for r in rs:
                        try:
                            vals.append(float(ExprEval(r).eval(expr)))
                        except Exception:
                            pass
                    vals.sort()
                    res = None
                    if vals:
                        idx = max(0, min(math.ceil((pct / 100) * len(vals)) - 1, len(vals) - 1))
                        res = vals[idx]
                        if res.is_integer():
                            res = int(res)
                    nr[name or ("p" + str(pct))] = res
        out.append(nr)
    return out

def render_legacy(rows, aggregate_mode=False):
    if aggregate_mode:
        if not rows:
            print("No data")
            return
        cols = []
        for r in rows:
            for k in r.keys():
                if k not in cols:
                    cols.append(k)
        def aggstr(v):
            if isinstance(v, float):
                return "%.2f" % v
            return valstr(v)
        widths = [max([len(c)] + [len(aggstr(r.get(c))) for r in rows]) + 8 for c in cols]
        if cols:
            print("".join(c.ljust(w) for c, w in zip(cols, widths)).rstrip())
            print("-" * sum(widths))
        for r in rows:
            print("".join(aggstr(r.get(c)).ljust(w) for c, w in zip(cols, widths)).rstrip())
    else:
        cols = []
        for r in rows:
            for k in sorted(k for k in r.keys() if k != "_line"):
                if k not in cols:
                    cols.append(k)
        widths = []
        for c in cols:
            widths.append(max(len(f"[{c}={valstr(r.get(c))}]") for r in rows) + 8)
        for r in rows:
            parts = [f"[{c}={valstr(r.get(c))}]" for c in cols]
            print("".join(p.ljust(w) for p, w in zip(parts, widths)).rstrip())

def render(rows, fmt, aggregate_mode=False):
    if fmt == "json":
        if aggregate_mode:
            print(json.dumps([{k: v for k, v in r.items() if k != "_line"} for r in rows], separators=(",", ":")))
        else:
            for r in rows:
                print(json.dumps({k: v for k, v in r.items() if k != "_line"}, separators=(",", ":")))
    elif fmt == "logfmt":
        for r in rows:
            parts = []
            for k in sorted(k for k in r.keys() if k != "_line"):
                v = valstr(r[k])
                if not isinstance(r[k], list) and re.search(r"\s", v):
                    v = '"' + v.replace('"', '\\"') + '"'
                parts.append(f"{k}={v}")
            print(" ".join(parts))
    elif fmt.startswith("format="):
        templ = fmt[7:]
        for r in rows:
            print(re.sub(r"\{([^{}]+)\}", lambda m: valstr(get_path(r, m.group(1))), templ))
    else:
        render_legacy(rows, aggregate_mode)

def load_aliases(alias_dir):
    aliases = {}
    dirs = []
    if alias_dir:
        dirs = [alias_dir]
    else:
        cur = os.getcwd()
        while True:
            dirs.append(os.path.join(cur, ".agrind-aliases"))
            parent = os.path.dirname(cur)
            if parent == cur:
                break
            cur = parent
    for d in dirs:
        for fn in glob.glob(os.path.join(d, "*")):
            try:
                txt = open(fn).read()
            except Exception:
                continue
            km = re.search(r'keyword\s*=\s*"([^"]+)"', txt)
            tm = re.search(r'template\s*=\s*"""(.*?)"""', txt, re.S)
            if km and tm:
                aliases[km.group(1)] = tm.group(1).strip()
    return aliases

def main():
    if "-h" in sys.argv[1:] or "--help" in sys.argv[1:]:
        print("""Usage: executable [OPTIONS] [QUERY]

Arguments:
  [QUERY]
          The query

Options:
  -f, --file <FILE>
          Optionally reads from a file instead of Stdin

  -m, --format <FORMAT>
          DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output

  -o, --output <OUTPUT>
          Set output format. Options:
          - `json`,
          - `logfmt`
          - `format=<rust format string>` (eg. -o format='{src} => {dst}'
          - `legacy` The original output format, auto aligning [k=v]

  -a, --alias-dir <ALIAS_DIR>
          Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.

      --no-alias
          Disables aliases

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

For more details + docs, see https://github.com/rcoh/angle-grinder""")
        return 0
    ap = argparse.ArgumentParser(prog="executable")
    ap.add_argument("-f", "--file")
    ap.add_argument("-m", "--format", dest="deprecated_format")
    ap.add_argument("-o", "--output", default="legacy")
    ap.add_argument("-a", "--alias-dir")
    ap.add_argument("--no-alias", action="store_true")
    ap.add_argument("-V", "--version", action="store_true")
    ap.add_argument("query", nargs="?")
    args = ap.parse_args()
    if args.version:
        print("ag 0.19.6")
        return 0
    fmt = args.output
    if args.deprecated_format:
        fmt = "format=" + args.deprecated_format
    q = args.query or "*"
    if not args.no_alias:
        for k, v in load_aliases(args.alias_dir).items():
            q = re.sub(r"(?<=\|)\s*" + re.escape(k) + r"\s*(?=\||$)", " " + v + " ", q)
    try:
        lines = open(args.file).read().splitlines() if args.file else sys.stdin.read().splitlines()
    except OSError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    stages = [s.strip() for s in q.split("|")]
    rows = [Row({"_line": ln}) for ln in lines if match_filter(ln, stages[0] if stages else "*")]
    aggregate_mode = False
    for op in stages[1:]:
        rows, agg = apply_op(rows, op)
        aggregate_mode = aggregate_mode or agg
    render(rows, fmt, aggregate_mode)
    return 0

if __name__ == "__main__":
    sys.exit(main())
