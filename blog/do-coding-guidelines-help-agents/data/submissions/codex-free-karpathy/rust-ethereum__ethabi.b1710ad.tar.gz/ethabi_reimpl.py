#!/usr/bin/env python3
import json
import sys

VERSION = "ethabi-cli 18.0.0"

RC = [
    0x0000000000000001,0x0000000000008082,0x800000000000808a,0x8000000080008000,
    0x000000000000808b,0x0000000080000001,0x8000000080008081,0x8000000000008009,
    0x000000000000008a,0x0000000000000088,0x0000000080008009,0x000000008000000a,
    0x000000008000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,
    0x8000000000008002,0x8000000000000080,0x000000000000800a,0x800000008000000a,
    0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008,
]
R = [
    [0,36,3,41,18],
    [1,44,10,45,2],
    [62,6,43,15,61],
    [28,55,25,21,56],
    [27,20,39,8,14],
]

def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)

def keccak256(data):
    rate = 136
    state = [0] * 25
    for off in range(0, len(data), rate):
        block = bytearray(data[off:off+rate])
        if len(block) < rate:
            block.append(0x01)
            block.extend(b"\x00" * (rate - len(block)))
            block[-1] ^= 0x80
        for i in range(rate // 8):
            state[i] ^= int.from_bytes(block[i*8:i*8+8], "little")
        keccak_f(state)
        if len(block) == rate and off + rate < len(data):
            continue
        if off + rate >= len(data):
            break
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out.extend(state[i].to_bytes(8, "little"))
            if len(out) >= 32:
                break
        if len(out) < 32:
            keccak_f(state)
    return bytes(out[:32])

def keccak_f(a):
    for rc in RC:
        c = [a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20] for x in range(5)]
        d = [c[(x-1)%5] ^ rol(c[(x+1)%5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                a[x + 5*y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5*((2*x + 3*y) % 5)] = rol(a[x + 5*y], R[x][y])
        for x in range(5):
            for y in range(5):
                a[x + 5*y] = b[x + 5*y] ^ ((~b[((x+1)%5) + 5*y]) & b[((x+2)%5) + 5*y])
        a[0] ^= rc

class AbiType:
    def __init__(self, base, sub=None, arr=None):
        self.base, self.sub, self.arr = base, sub, arr
    def __str__(self):
        if self.arr is not None:
            n = "" if self.arr < 0 else str(self.arr)
            return f"{self.sub}[{n}]"
        return self.base

def parse_type(s):
    if s.endswith("]"):
        i = s.rfind("[")
        n = s[i+1:-1]
        return AbiType(None, parse_type(s[:i]), -1 if n == "" else int(n))
    return AbiType(s)

def is_dynamic(t):
    if t.arr is not None:
        return t.arr < 0 or is_dynamic(t.sub)
    return t.base in ("string", "bytes")

def clean_hex(s):
    return s[2:] if s.startswith(("0x", "0X")) else s

def hex_to_bytes(s):
    s = clean_hex(s)
    if len(s) % 2:
        raise ValueError("Odd number of digits")
    return bytes.fromhex(s)

def word(n):
    if n < 0:
        n = (1 << 256) + n
    return n.to_bytes(32, "big")

def parse_int_value(v, lenient):
    if lenient:
        return int(v, 10)
    h = clean_hex(v)
    if len(h) % 2:
        raise ValueError("Odd number of digits")
    return int(h or "0", 16)

def split_array(v):
    v = v.strip()
    if not (v.startswith("[") and v.endswith("]")):
        raise ValueError("Invalid data")
    inner = v[1:-1].strip()
    if not inner:
        return []
    res, cur, depth, quote = [], "", 0, None
    for ch in inner:
        if quote:
            cur += ch
            if ch == quote:
                quote = None
        elif ch in "'\"":
            quote = ch; cur += ch
        elif ch == "[":
            depth += 1; cur += ch
        elif ch == "]":
            depth -= 1; cur += ch
        elif ch == "," and depth == 0:
            res.append(cur.strip()); cur = ""
        else:
            cur += ch
    res.append(cur.strip())
    return [x[1:-1] if len(x) >= 2 and x[0] in "'\"" and x[-1] == x[0] else x for x in res]

def enc_single(t, v, lenient=False):
    if t.arr is not None:
        vals = split_array(v) if isinstance(v, str) else v
        if t.arr >= 0 and len(vals) != t.arr:
            raise ValueError("Invalid data")
        elems = encode_args([t.sub] * len(vals), vals, lenient)
        return (word(len(vals)) + elems) if t.arr < 0 else elems
    b = t.base
    if b == "bool":
        return word(1 if str(v).lower() in ("1", "true") else 0)
    if b.startswith("uint"):
        return word(parse_int_value(str(v), lenient))
    if b.startswith("int"):
        return word(parse_int_value(str(v), lenient))
    if b == "address":
        raw = hex_to_bytes(str(v))
        if len(raw) != 20:
            raise ValueError("Invalid data")
        return b"\x00" * 12 + raw
    if b == "string":
        raw = str(v).encode()
        return word(len(raw)) + raw + b"\x00" * ((32 - len(raw) % 32) % 32)
    if b == "bytes":
        raw = hex_to_bytes(str(v))
        return word(len(raw)) + raw + b"\x00" * ((32 - len(raw) % 32) % 32)
    if b.startswith("bytes"):
        n = int(b[5:])
        raw = hex_to_bytes(str(v))
        if len(raw) != n:
            raise ValueError("Invalid data")
        return raw + b"\x00" * (32 - n)
    raise ValueError("Invalid type")

def encode_args(types, vals, lenient=False):
    head, tail = [], []
    offset = 32 * len(types)
    for t, v in zip(types, vals):
        e = enc_single(t, v, lenient)
        if is_dynamic(t):
            head.append(word(offset)); tail.append(e); offset += len(e)
        else:
            head.append(e)
    return b"".join(head + tail)

def read_word(data, off):
    if off + 32 > len(data):
        raise ValueError("Invalid data")
    return data[off:off+32]

def dec_single(t, data, off=0):
    if t.arr is not None:
        if t.arr < 0:
            start = int.from_bytes(read_word(data, off), "big")
            n = int.from_bytes(read_word(data, start), "big")
            base = start + 32
        else:
            n, base = t.arr, off
        vals = []
        for i in range(n):
            pos = base + i * 32
            vals.append(dec_single(t.sub, data, pos)[0])
        return "[" + ",".join(vals) + "]", (32 if t.arr < 0 else 32*n)
    b = t.base
    if is_dynamic(t):
        start = int.from_bytes(read_word(data, off), "big")
        n = int.from_bytes(read_word(data, start), "big")
        raw = data[start+32:start+32+n]
        return (raw.decode(errors="replace") if b == "string" else raw.hex()), 32
    w = read_word(data, off)
    if b == "bool":
        return ("true" if int.from_bytes(w, "big") else "false"), 32
    if b.startswith("uint"):
        return format(int.from_bytes(w, "big"), "x"), 32
    if b.startswith("int"):
        x = int.from_bytes(w, "big")
        if x >= (1 << 255): x -= (1 << 256)
        return str(x) if x < 0 else format(x, "x"), 32
    if b == "address":
        return w[-20:].hex(), 32
    if b.startswith("bytes"):
        n = int(b[5:])
        return w[:n].hex(), 32
    raise ValueError("Invalid type")

def decode_args(types, data):
    return [dec_single(t, data, i * 32)[0] for i, t in enumerate(types)]

def load_abi(path):
    with open(path) as f:
        return json.load(f)

def canonical(item):
    return item.get("name", "") + "(" + ",".join(x["type"] for x in item.get("inputs", [])) + ")"

def find_item(abi, kind, name):
    items = [x for x in abi if x.get("type") == kind]
    for x in items:
        if canonical(x) == name:
            return x
    for x in items:
        if x.get("name", "") == name:
            return x
    raise ValueError("Invalid name: please ensure the contract and method you're calling exist!")

def parse_pairs(args):
    vals, i = [], 0
    while i < len(args):
        if args[i] == "-v" and i + 2 < len(args):
            vals.append((args[i+1], args[i+2])); i += 3
        else:
            i += 1
    return vals

def collect_opt(args, opt):
    out, rest, i = [], [], 0
    while i < len(args):
        if args[i] == opt and i + 1 < len(args):
            out.append(args[i+1]); i += 2
        else:
            rest.append(args[i]); i += 1
    return out, rest

def print_help(argv):
    if len(argv) <= 1 or argv[1] in ("-h", "--help", "help"):
        print(f"{VERSION}\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    decode    Decode ABI call result\n    encode    Encode ABI call\n    help      Prints this message or the help of the given subcommand(s)")
    elif argv[1] == "encode":
        print(f"executable-encode 18.0.0\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    params      Specify types of input params inline")
    elif argv[1] == "decode":
        print(f"executable-decode 18.0.0\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    log         Decode event log\n    params      Specify types of input params inline")

def main(argv):
    if len(argv) == 1 or argv[1] in ("-h", "--help", "help"):
        print_help(argv); return 0
    if "-h" in argv or "--help" in argv:
        print_help(argv); return 0
    if argv[1] in ("-V", "--version"):
        print(VERSION); return 0
    try:
        if argv[1:3] == ["encode", "params"]:
            lenient = "-l" in argv or "--lenient" in argv
            pairs = parse_pairs([a for a in argv[3:] if a not in ("-l", "--lenient")])
            data = encode_args([parse_type(t) for t, _ in pairs], [v for _, v in pairs], lenient)
            print(data.hex()); return 0
        if argv[1:3] == ["decode", "params"]:
            ts, rest = collect_opt(argv[3:], "-t")
            data = hex_to_bytes(rest[-1] if rest else "")
            vals = decode_args([parse_type(t) for t in ts], data)
            for t, v in zip(ts, vals):
                print(f"{t} {v}")
            return 0
        if argv[1:3] == ["encode", "function"]:
            args = argv[3:]
            lenient = "-l" in args or "--lenient" in args
            args = [a for a in args if a not in ("-l", "--lenient")]
            params, rest = collect_opt(args, "-p")
            item = find_item(load_abi(rest[0]), "function", rest[1])
            types = [parse_type(x["type"]) for x in item.get("inputs", [])]
            sig = canonical(item).encode()
            print((keccak256(sig)[:4] + encode_args(types, params, lenient)).hex()); return 0
        if argv[1:3] == ["decode", "function"]:
            item = find_item(load_abi(argv[3]), "function", argv[4])
            types = [parse_type(x["type"]) for x in item.get("outputs", [])]
            data = hex_to_bytes(argv[5])
            vals = decode_args(types, data)
            for inp, v in zip(item.get("outputs", []), vals):
                print(f"{inp['type']} {v}")
            return 0
        if argv[1:3] == ["decode", "log"]:
            topics, rest = collect_opt(argv[3:], "-l")
            item = find_item(load_abi(rest[0]), "event", rest[1])
            data = hex_to_bytes(rest[2])
            indexed = [x for x in item.get("inputs", []) if x.get("indexed")]
            plain = [x for x in item.get("inputs", []) if not x.get("indexed")]
            out = []
            if not item.get("anonymous", False):
                if len(topics) < len(indexed) + 1:
                    raise ValueError("Invalid data")
                topic_vals = topics[1:1+len(indexed)]
            else:
                if len(topics) < len(indexed):
                    raise ValueError("Invalid data")
                topic_vals = topics[:len(indexed)]
            for inp, top in zip(indexed, topic_vals):
                typ = parse_type(inp["type"])
                if is_dynamic(typ):
                    val = clean_hex(top)
                else:
                    val = dec_single(typ, hex_to_bytes(top), 0)[0]
                out.append((inp.get("name", ""), val))
            vals = decode_args([parse_type(x["type"]) for x in plain], data)
            out.extend((x.get("name", ""), v) for x, v in zip(plain, vals))
            for name, v in out:
                print(f"{name} {v}".strip())
            return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    print_help(argv)
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv))
