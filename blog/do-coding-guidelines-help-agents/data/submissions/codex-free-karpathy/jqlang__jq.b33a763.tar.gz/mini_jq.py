#!/usr/bin/env python3
import sys, json, re, math

class JQErr(Exception): pass

def jdump(v, compact=False, ascii_only=False, sort_keys=False, indent=2, tab=False):
    if compact:
        return json.dumps(v, ensure_ascii=ascii_only, sort_keys=sort_keys, separators=(',', ':'))
    return json.dumps(v, ensure_ascii=ascii_only, sort_keys=sort_keys, indent=('\t' if tab else indent))

def parse_many(text):
    dec = json.JSONDecoder()
    i, out, n = 0, [], len(text)
    while True:
        while i < n and text[i].isspace(): i += 1
        if i >= n: break
        try:
            v, j = dec.raw_decode(text, i)
        except Exception as e:
            raise JQErr("parse error: " + str(e))
        out.append(v); i = j
    return out

class Tok:
    def __init__(self, s):
        self.s=s; self.i=0; self.toks=[]; self.lex()
    def lex(self):
        s=self.s; i=0; n=len(s)
        ops=['==','!=','<=','>=','//','+=','-=','*=','/=','%=','|=']
        one=set('{}[](),:;|.+-*/%<>?')
        while i<n:
            c=s[i]
            if c.isspace(): i+=1; continue
            if c=='#':
                while i<n and s[i]!='\n': i+=1
                continue
            if c=='"':
                j=i+1; esc=False
                while j<n:
                    if esc: esc=False
                    elif s[j]=='\\': esc=True
                    elif s[j]=='"': break
                    j+=1
                if j>=n: raise JQErr("Unterminated string")
                self.toks.append(('STR', json.loads(s[i:j+1]))); i=j+1; continue
            if c=="'":
                j=s.find("'", i+1)
                if j<0: raise JQErr("Unterminated string")
                self.toks.append(('STR', s[i+1:j])); i=j+1; continue
            if c.isdigit() or (c=='-' and i+1<n and s[i+1].isdigit()):
                m=re.match(r'-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?', s[i:])
                val=m.group(0); self.toks.append(('NUM', float(val) if any(x in val for x in '.eE') else int(val))); i+=len(val); continue
            if c=='$':
                m=re.match(r'\$[A-Za-z_][A-Za-z0-9_]*', s[i:])
                if not m: raise JQErr("Bad variable")
                self.toks.append(('VAR', m.group(0)[1:])); i+=len(m.group(0)); continue
            m=re.match(r'[A-Za-z_][A-Za-z0-9_]*', s[i:])
            if m:
                self.toks.append(('ID', m.group(0))); i+=len(m.group(0)); continue
            two=s[i:i+2]
            if two in ops: self.toks.append((two,two)); i+=2; continue
            if c in one: self.toks.append((c,c)); i+=1; continue
            raise JQErr("Unexpected character " + c)
        self.toks.append(('EOF', None))
    def peek(self): return self.toks[self.i][0]
    def val(self): return self.toks[self.i][1]
    def eat(self, k=None):
        if k is not None and self.peek()!=k: raise JQErr("Expected " + k + ", got " + self.peek())
        t=self.toks[self.i]; self.i+=1; return t
    def match(self,k):
        if self.peek()==k: self.i+=1; return True
        return False

class Node:
    def eval(self, x, env): return []

class Id(Node):
    def eval(self,x,env): return [x]
class Lit(Node):
    def __init__(self,v): self.v=v
    def eval(self,x,env): return [self.v]
class Var(Node):
    def __init__(self,n): self.n=n
    def eval(self,x,env): return [env.get(self.n)]
class Pipe(Node):
    def __init__(self,a,b): self.a=a; self.b=b
    def eval(self,x,env):
        out=[]
        for v in self.a.eval(x,env): out += self.b.eval(v,env)
        return out
class Comma(Node):
    def __init__(self,a,b): self.a=a; self.b=b
    def eval(self,x,env): return self.a.eval(x,env)+self.b.eval(x,env)
class Field(Node):
    def __init__(self,base,key,opt=False): self.base=base; self.key=key; self.opt=opt
    def eval(self,x,env):
        out=[]
        for v in self.base.eval(x,env):
            try:
                if isinstance(v,dict): out.append(v.get(self.key))
                else:
                    if self.opt: out.append(None)
                    else: raise JQErr("Cannot index %s with string \"%s\"" % (jtype(v), self.key))
            except JQErr: raise
        return out
class Index(Node):
    def __init__(self,base,idx,opt=False): self.base=base; self.idx=idx; self.opt=opt
    def eval(self,x,env):
        out=[]
        for v in self.base.eval(x,env):
            idxs=self.idx.eval(x,env) if self.idx else [None]
            for ix in idxs:
                try:
                    if ix is None:
                        if isinstance(v,dict): out += list(v.values())
                        elif isinstance(v,list): out += v
                        else:
                            if not self.opt: raise JQErr("Cannot iterate over %s" % jtype(v))
                    elif isinstance(ix,str) and isinstance(v,dict): out.append(v.get(ix))
                    elif isinstance(ix,int) and isinstance(v,list):
                        out.append(v[ix] if -len(v) <= ix < len(v) else None)
                    else:
                        if self.opt: out.append(None)
                        else: raise JQErr("Cannot index %s" % jtype(v))
                except JQErr: raise
        return out
class Slice(Node):
    def __init__(self,base,a,b): self.base=base; self.a=a; self.b=b
    def eval(self,x,env):
        out=[]
        for v in self.base.eval(x,env):
            a=self.a.eval(x,env)[0] if self.a else None
            b=self.b.eval(x,env)[0] if self.b else None
            out.append(v[a:b])
        return out
class Arr(Node):
    def __init__(self,e): self.e=e
    def eval(self,x,env): return [self.e.eval(x,env) if self.e else []]
class Obj(Node):
    def __init__(self,pairs): self.pairs=pairs
    def eval(self,x,env):
        outs=[{}]
        for kexpr,vexpr in self.pairs:
            new=[]
            keys = kexpr.eval(x,env) if isinstance(kexpr,Node) else [kexpr]
            vals = vexpr.eval(x,env)
            for o in outs:
                for k in keys:
                    for v in vals:
                        oo=dict(o); oo[str(k)]=v; new.append(oo)
            outs=new
        return outs
class Bin(Node):
    def __init__(self,op,a,b): self.op=op; self.a=a; self.b=b
    def eval(self,x,env):
        out=[]
        for av in self.a.eval(x,env):
            for bv in self.b.eval(x,env):
                out.append(binop(self.op,av,bv))
        return out
class Un(Node):
    def __init__(self,op,a): self.op=op; self.a=a
    def eval(self,x,env):
        return [(-v if self.op=='-' else (not truth(v))) for v in self.a.eval(x,env)]
class Call(Node):
    def __init__(self,name,args): self.name=name; self.args=args
    def eval(self,x,env): return builtin(self.name, self.args, x, env)
class If(Node):
    def __init__(self,c,t,e): self.c=c; self.t=t; self.e=e
    def eval(self,x,env):
        out=[]
        for cv in self.c.eval(x,env):
            out += (self.t if truth(cv) else self.e).eval(x,env)
        return out
class As(Node):
    def __init__(self,e,n,r): self.e=e; self.n=n; self.r=r
    def eval(self,x,env):
        out=[]
        for v in self.e.eval(x,env):
            ee=dict(env); ee[self.n]=v
            out += self.r.eval(x,ee)
        return out
class Update(Node):
    def __init__(self,path,expr): self.path=path; self.expr=expr
    def eval(self,x,env):
        import copy
        y=copy.deepcopy(x)
        if isinstance(self.path,Field) and isinstance(self.path.base,Id) and isinstance(y,dict):
            vals=self.expr.eval(y.get(self.path.key),env)
            y[self.path.key]=vals[-1] if vals else None
            return [y]
        return [y]

def jtype(v):
    if v is None: return 'null'
    if isinstance(v,bool): return 'boolean'
    if isinstance(v,(int,float)): return 'number'
    if isinstance(v,str): return 'string'
    if isinstance(v,list): return 'array'
    if isinstance(v,dict): return 'object'
def truth(v): return not (v is False or v is None)

def binop(op,a,b):
    if op=='+':
        if a is None: return b
        if b is None: return a
        if isinstance(a,list) and isinstance(b,list): return a+b
        if isinstance(a,dict) and isinstance(b,dict): z=dict(a); z.update(b); return z
        return a+b
    if op=='-':
        if isinstance(a,list) and isinstance(b,list): return [x for x in a if x not in b]
        return a-b
    if op=='*':
        if isinstance(a,dict) and isinstance(b,dict): z=dict(a); z.update(b); return z
        return a*b
    if op=='/': return a/b
    if op=='%': return a%b
    if op=='==': return a==b
    if op=='!=': return a!=b
    if op=='<': return a<b
    if op=='>': return a>b
    if op=='<=': return a<=b
    if op=='>=': return a>=b
    if op=='and': return truth(a) and truth(b)
    if op=='or': return truth(a) or truth(b)
    if op=='//': return a if a is not None and a is not False else b
    raise JQErr("op")

def builtin(name,args,x,env):
    def vals(n=0, inp=x): return args[n].eval(inp,env)
    if name=='empty': return []
    if name=='length':
        if x is None: return [0]
        if isinstance(x,(str,list,dict)): return [len(x)]
        if isinstance(x,(int,float)): return [abs(x)]
    if name=='type': return [jtype(x)]
    if name=='keys' or name=='keys_unsorted':
        if isinstance(x,dict): return [list(x.keys()) if name=='keys_unsorted' else sorted(x.keys())]
        if isinstance(x,list): return [list(range(len(x)))]
        return [[]]
    if name=='has':
        k=vals()[0]; return [k in x if isinstance(x,(dict,list)) else False]
    if name=='map':
        if not isinstance(x,list): raise JQErr("Cannot iterate over %s" % jtype(x))
        return [[y for it in x for y in args[0].eval(it,env)]]
    if name=='select': return [x] if vals()[0] not in (False,None) else []
    if name=='add':
        if not x: return [None]
        r=x[0]
        for v in x[1:]: r=binop('+',r,v)
        return [r]
    if name=='reverse': return [list(reversed(x)) if isinstance(x,list) else x[::-1]]
    if name=='sort': return [sorted(x)]
    if name=='unique':
        out=[]
        for v in sorted(x):
            if v not in out: out.append(v)
        return [out]
    if name=='min': return [min(x)]
    if name=='max': return [max(x)]
    if name=='flatten':
        def fl(a):
            r=[]
            for v in a:
                if isinstance(v,list): r+=fl(v)
                else: r.append(v)
            return r
        return [fl(x)]
    if name=='tostring': return [x if isinstance(x,str) else jdump(x, compact=True)]
    if name=='tonumber': return [float(x) if (isinstance(x,str) and any(c in x for c in '.eE')) else int(x)]
    if name=='tojson': return [jdump(x, compact=True)]
    if name=='fromjson': return [json.loads(x)]
    if name=='contains':
        q=vals()[0]
        if isinstance(x,str): return [str(q) in x]
        if isinstance(x,list): return [all(v in x for v in q)]
        if isinstance(x,dict): return [all(k in x and x[k]==v for k,v in q.items())]
    if name=='startswith': return [isinstance(x,str) and x.startswith(vals()[0])]
    if name=='endswith': return [isinstance(x,str) and x.endswith(vals()[0])]
    if name=='split': return [x.split(vals()[0])]
    if name=='join': return [str(vals()[0]).join(map(lambda v: '' if v is None else str(v), x))]
    if name=='to_entries':
        if isinstance(x,dict): return [[{'key':k,'value':v} for k,v in x.items()]]
        if isinstance(x,list): return [[{'key':i,'value':v} for i,v in enumerate(x)]]
    if name=='from_entries':
        return [{str(e.get('key', e.get('Key'))): e.get('value', e.get('Value')) for e in x}]
    if name=='with_entries':
        entries=builtin('to_entries',[],x,env)[0]
        mapped=[y for e in entries for y in args[0].eval(e,env)]
        return builtin('from_entries',[],mapped,env)
    if name=='range':
        av=[a.eval(x,env)[0] for a in args]
        if len(av)==1: start,end,step=0,av[0],1
        elif len(av)==2: start,end,step=av[0],av[1],1
        else: start,end,step=av[0],av[1],av[2]
        return list(range(start,end,step))
    if name=='inputs':
        vals=env.get('_inputs', [])
        env['_inputs']=[]
        return vals
    if name=='ascii_downcase': return [x.lower()]
    if name=='ascii_upcase': return [x.upper()]
    if name=='floor': return [math.floor(x)]
    if name=='ceil': return [math.ceil(x)]
    if name=='sqrt': return [math.sqrt(x)]
    if name=='abs': return [abs(x)]
    if name=='not': return [not truth(x)]
    if name=='values': return [] if x is None else [x]
    if name=='arrays': return [x] if isinstance(x,list) else []
    if name=='objects': return [x] if isinstance(x,dict) else []
    if name=='numbers': return [x] if isinstance(x,(int,float)) and not isinstance(x,bool) else []
    if name=='strings': return [x] if isinstance(x,str) else []
    if name=='booleans': return [x] if isinstance(x,bool) else []
    if name=='nulls': return [x] if x is None else []
    if name=='del':
        return [x]
    raise JQErr(name + " is not defined")

class Parser:
    def __init__(self,s): self.t=Tok(s)
    def parse(self):
        n=self.comma()
        if self.t.peek()!='EOF': raise JQErr("Unexpected token " + self.t.peek())
        return n
    def comma(self):
        n=self.pipe()
        while self.t.match(','): n=Comma(n,self.pipe())
        return n
    def pipe(self):
        n=self.orx()
        if self.t.peek()=='ID' and self.t.val()=='as':
            self.t.eat()
            var=self.t.eat('VAR')[1]
            self.t.eat('|')
            return As(n,var,self.pipe())
        if self.t.match('|='):
            return Update(n,self.orx())
        while self.t.match('|'): n=Pipe(n,self.orx())
        return n
    def orx(self):
        n=self.andx()
        while self.t.peek()=='ID' and self.t.val()=='or': self.t.eat(); n=Bin('or',n,self.andx())
        return n
    def andx(self):
        n=self.alt()
        while self.t.peek()=='ID' and self.t.val()=='and': self.t.eat(); n=Bin('and',n,self.alt())
        return n
    def alt(self):
        n=self.cmp()
        while self.t.match('//'): n=Bin('//',n,self.cmp())
        return n
    def cmp(self):
        n=self.add()
        while self.t.peek() in ('==','!=','<','>','<=','>='):
            op=self.t.eat()[0]; n=Bin(op,n,self.add())
        return n
    def add(self):
        n=self.mul()
        while self.t.peek() in ('+','-'):
            op=self.t.eat()[0]; n=Bin(op,n,self.mul())
        return n
    def mul(self):
        n=self.unary()
        while self.t.peek() in ('*','/','%'):
            op=self.t.eat()[0]; n=Bin(op,n,self.unary())
        return n
    def unary(self):
        if self.t.match('-'): return Un('-',self.unary())
        if self.t.peek()=='ID' and self.t.val()=='not': self.t.eat(); return Un('not',self.unary())
        return self.postfix()
    def postfix(self):
        n=self.primary()
        while True:
            opt=False
            if self.t.match('.'):
                if self.t.peek()=='ID':
                    key=self.t.eat()[1]
                    if self.t.match('?'): opt=True
                    n=Field(n,key,opt)
                elif self.t.peek()=='STR':
                    key=self.t.eat()[1]; n=Field(n,key)
                else:
                    continue
            elif self.t.match('['):
                if self.t.match(']'):
                    if self.t.match('?'): opt=True
                    n=Index(n,None,opt)
                else:
                    first=None if self.t.peek()==':' else self.comma()
                    if self.t.match(':'):
                        second=None if self.t.peek()==']' else self.comma()
                        self.t.eat(']'); n=Slice(n,first,second)
                    else:
                        self.t.eat(']')
                        if self.t.match('?'): opt=True
                        n=Index(n,first,opt)
            elif self.t.match('?'):
                pass
            else: break
        return n
    def primary(self):
        p=self.t.peek()
        if p=='.':
            self.t.eat()
            if self.t.peek()=='ID' and self.t.val() not in ('as','then','else','end','or','and'):
                return Field(Id(), self.t.eat()[1])
            if self.t.peek()=='STR':
                return Field(Id(), self.t.eat()[1])
            return Id()
        if p=='NUM': return Lit(self.t.eat()[1])
        if p=='STR': return Lit(self.t.eat()[1])
        if p=='VAR': return Var(self.t.eat()[1])
        if p=='ID':
            v=self.t.eat()[1]
            if v=='if':
                c=self.comma()
                if not (self.t.peek()=='ID' and self.t.val()=='then'): raise JQErr("Expected then")
                self.t.eat()
                t=self.comma()
                if not (self.t.peek()=='ID' and self.t.val()=='else'): raise JQErr("Expected else")
                self.t.eat()
                e=self.comma()
                if not (self.t.peek()=='ID' and self.t.val()=='end'): raise JQErr("Expected end")
                self.t.eat()
                return If(c,t,e)
            if v=='null': return Lit(None)
            if v=='true': return Lit(True)
            if v=='false': return Lit(False)
            args=[]
            if self.t.match('('):
                if not self.t.match(')'):
                    args.append(self.comma())
                    while self.t.match(';'): args.append(self.comma())
                    self.t.eat(')')
            return Call(v,args)
        if self.t.match('('):
            n=self.comma(); self.t.eat(')'); return n
        if self.t.match('['):
            if self.t.match(']'): return Arr(None)
            e=self.comma(); self.t.eat(']'); return Arr(e)
        if self.t.match('{'):
            pairs=[]
            if self.t.match('}'): return Obj(pairs)
            while True:
                if self.t.peek()=='ID':
                    key=self.t.eat()[1]
                    if self.t.match(':'): val=self.pipe()
                    else: val=Field(Id(),key)
                elif self.t.peek()=='STR':
                    key=self.t.eat()[1]; self.t.eat(':'); val=self.pipe()
                elif self.t.match('('):
                    key=self.comma(); self.t.eat(')'); self.t.eat(':'); val=self.pipe()
                else: raise JQErr("Bad object")
                pairs.append((key,val))
                if self.t.match('}'): break
                self.t.eat(',')
            return Obj(pairs)
        raise JQErr("Unexpected token " + p)

def usage():
    print("""jq - commandline JSON processor [version build-2b77eb1]

Usage:\tjq [options] <jq filter> [file...]
\tjq [options] --args <jq filter> [strings...]
\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]
""")

def main(argv):
    opts={'null':False,'rawin':False,'slurp':False,'compact':False,'rawout':False,'join':False,'ascii':False,'sort':False,'indent':2,'tab':False,'exit':False}
    env={'ARGS':{'named':{},'positional':[]}}
    filt=None; files=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a in ('-h','--help'): usage(); return 0
        if a in ('-V','--version'): print('jq-build-2b77eb1'); return 0
        if a=='--build-configuration': print('--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local'); return 0
        if a=='--': i+=1; break
        if a in ('-n','--null-input'): opts['null']=True; i+=1; continue
        if a in ('-R','--raw-input'): opts['rawin']=True; i+=1; continue
        if a in ('-s','--slurp'): opts['slurp']=True; i+=1; continue
        if a in ('-c','--compact-output'): opts['compact']=True; i+=1; continue
        if a in ('-r','--raw-output'): opts['rawout']=True; i+=1; continue
        if a in ('-j','--join-output'): opts['rawout']=True; opts['join']=True; i+=1; continue
        if a in ('-a','--ascii-output'): opts['ascii']=True; i+=1; continue
        if a in ('-S','--sort-keys'): opts['sort']=True; i+=1; continue
        if a=='--tab': opts['tab']=True; i+=1; continue
        if a=='--indent': opts['indent']=int(argv[i+1]); i+=2; continue
        if a in ('-e','--exit-status'): opts['exit']=True; i+=1; continue
        if a=='--arg': env[argv[i+1]]=argv[i+2]; env['ARGS']['named'][argv[i+1]]=argv[i+2]; i+=3; continue
        if a=='--argjson': env[argv[i+1]]=json.loads(argv[i+2]); env['ARGS']['named'][argv[i+1]]=env[argv[i+1]]; i+=3; continue
        if a=='--rawfile':
            env[argv[i+1]]=open(argv[i+2]).read(); env['ARGS']['named'][argv[i+1]]=env[argv[i+1]]; i+=3; continue
        if a=='--slurpfile':
            env[argv[i+1]]=parse_many(open(argv[i+2]).read()); env['ARGS']['named'][argv[i+1]]=env[argv[i+1]]; i+=3; continue
        if a=='-f' or a=='--from-file':
            filt=open(argv[i+1]).read(); i+=2; continue
        if a=='--args':
            if filt is None: filt=argv[i+1]; i+=2
            env['ARGS']['positional']=argv[i:]; break
        if a=='--jsonargs':
            if filt is None: filt=argv[i+1]; i+=2
            env['ARGS']['positional']=[json.loads(z) for z in argv[i:]]; break
        if a.startswith('-') and a!='-':
            for ch in a[1:]:
                if ch=='n': opts['null']=True
                elif ch=='R': opts['rawin']=True
                elif ch=='s': opts['slurp']=True
                elif ch=='c': opts['compact']=True
                elif ch=='r': opts['rawout']=True
                elif ch=='j': opts['rawout']=True; opts['join']=True
                elif ch=='a': opts['ascii']=True
                elif ch=='S': opts['sort']=True
                elif ch=='e': opts['exit']=True
                elif ch=='M' or ch=='C': pass
                else: raise JQErr('Unknown option ' + a)
            i+=1; continue
        if filt is None: filt=a
        else: files.append(a)
        i+=1
    files += argv[i:]
    if filt is None: usage(); return 2
    prog=Parser(filt).parse()
    texts=[]
    if files: data=''.join(open(f).read() for f in files)
    else: data=sys.stdin.read()
    if opts['null']:
        if opts['rawin']:
            env['_inputs'] = data.splitlines()
        else:
            env['_inputs'] = parse_many(data) if data.strip() else []
        inputs=[None]
    else:
        if opts['rawin']:
            inputs=[data] if opts['slurp'] else data.splitlines()
        else:
            inputs=parse_many(data)
            if opts['slurp']: inputs=[inputs]
    outs=[]
    for inp in inputs: outs += prog.eval(inp,env)
    last=None
    sep='' if opts['join'] else '\n'
    for v in outs:
        last=v
        if opts['rawout'] and isinstance(v,str): s=v
        else: s=jdump(v, opts['compact'], opts['ascii'], opts['sort'], opts['indent'], opts['tab'])
        sys.stdout.write(s+sep)
    if opts['exit']:
        if not outs: return 4
        return 0 if truth(last) else 1
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
    except Exception as e:
        print('jq: error: ' + str(e), file=sys.stderr)
        sys.exit(3)
