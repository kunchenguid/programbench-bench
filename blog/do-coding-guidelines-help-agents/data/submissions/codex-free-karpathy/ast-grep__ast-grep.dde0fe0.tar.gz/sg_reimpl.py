#!/usr/bin/env python3
import sys, os, re, json, difflib, fnmatch
from pathlib import Path

VERSION = "ast-grep 0.42.1"
LANGS = {
    'js':'JavaScript','javascript':'JavaScript','ts':'TypeScript','typescript':'TypeScript','tsx':'Tsx',
    'py':'Python','python':'Python','rs':'Rust','rust':'Rust','go':'Go','java':'Java','c':'C','cpp':'Cpp',
    'c++':'Cpp','cs':'CSharp','csharp':'CSharp','json':'Json','yaml':'Yaml','yml':'Yaml','html':'Html',
    'css':'Css','rb':'Ruby','ruby':'Ruby','php':'Php','swift':'Swift','kt':'Kotlin','kotlin':'Kotlin',
    'lua':'Lua','dart':'Dart','scala':'Scala','sh':'Bash','bash':'Bash','hs':'Haskell','haskell':'Haskell',
    'ex':'Elixir','elixir':'Elixir'
}
EXT_LANG = {'.js':'JavaScript','.jsx':'JavaScript','.ts':'TypeScript','.tsx':'Tsx','.py':'Python','.rs':'Rust','.go':'Go','.java':'Java','.c':'C','.h':'C','.cpp':'Cpp','.cc':'Cpp','.cxx':'Cpp','.hpp':'Cpp','.json':'Json','.yaml':'Yaml','.yml':'Yaml','.html':'Html','.css':'Css','.rb':'Ruby','.php':'Php','.swift':'Swift','.kt':'Kotlin','.lua':'Lua','.dart':'Dart','.scala':'Scala','.sh':'Bash'}

ROOT_HELP = r'''Search and Rewrite code at large scale using AST pattern.
                    __
        ____ ______/ /_      ____ _________  ____
       / __ `/ ___/ __/_____/ __ `/ ___/ _ \/ __ \
      / /_/ (__  ) /_/_____/ /_/ / /  /  __/ /_/ /
      \__,_/____/\__/      \__, /_/   \___/ .___/
                          /____/         /_/


Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version'''
RUN_HELP = '''Run one time search or rewrite in command line. (default command)

Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

Arguments:
  [PATHS]...
          The paths to search. You can provide multiple paths separated by spaces
          
          [default: .]

Options:
  -p, --pattern <PATTERN>
          AST pattern to match

  -r, --rewrite <FIX>
          String to replace the matched AST node

  -l, --lang <LANG>
          The language of the pattern. For full language list, visit https://ast-grep.github.io/reference/languages.html

      --stdin
          Enable search code from StdIn.

  -U, --update-all
          Apply all rewrite without confirmation if true

      --files-with-matches
          Print only the paths with at least one match and suppress match contents.

      --json[=<STYLE>]
          Output matches in structured JSON.

  -A, --after <NUM>
          Show NUM lines after each match.

  -B, --before <NUM>
          Show NUM lines before each match.

  -C, --context <NUM>
          Show NUM lines around each match.

  -h, --help
          Print help (see a summary with '-h')'''
SCAN_HELP = '''Scan and rewrite code by configuration

Usage: executable scan [OPTIONS] [PATHS]...

Options:
  -r, --rule <RULE_FILE>
          Scan the codebase with the single rule located at the path RULE_FILE.

      --inline-rules <RULE_TEXT>
          Scan the codebase with a rule defined by the provided RULE_TEXT.

      --json[=<STYLE>]
          Output matches in structured JSON.

  -U, --update-all
          Apply all rewrite without confirmation if true

  -h, --help
          Print help (see a summary with '-h')'''
NEW_HELP = '''Create new ast-grep project or items like rules/tests

Usage: executable new [OPTIONS] [NAME] [COMMAND]

Commands:
  project  Create an new project by scaffolding
  rule     Create a new rule
  test     Create a new test case
  util     Create a new global utility rule
  help     Print this message or the help of the given subcommand(s)'''

class Opts:
    def __init__(self):
        self.pattern=None; self.rewrite=None; self.lang=None; self.paths=[]; self.stdin=False
        self.update=False; self.files=False; self.json_style=None; self.color='auto'; self.before=0; self.after=0
        self.debug=None; self.rule=None; self.inline=None; self.max_results=None

def die(msg, code=2):
    print(msg, file=sys.stderr); sys.exit(code)

def language_name(s):
    if not s: return None
    key=s.lower()
    if key not in LANGS:
        die(f"error: invalid value '{s}' for '--lang <LANG>': {s} is not supported!\n\nFor more information, try '--help'.")
    return LANGS[key]

def parse_common(args, scan=False):
    o=Opts(); i=0
    while i < len(args):
        a=args[i]
        if a in ('-h','--help'):
            print(SCAN_HELP if scan else RUN_HELP); sys.exit(0)
        elif a in ('-p','--pattern'):
            i+=1; o.pattern=args[i] if i<len(args) else die('error: a value is required for --pattern <PATTERN>')
        elif a.startswith('--pattern='): o.pattern=a.split('=',1)[1]
        elif a in ('-r','--rewrite') and not scan:
            i+=1; o.rewrite=args[i] if i<len(args) else die('error: a value is required for --rewrite <FIX>')
        elif a in ('-r','--rule') and scan:
            i+=1; o.rule=args[i] if i<len(args) else die('error: a value is required for --rule <RULE_FILE>')
        elif a.startswith('--rule=') and scan: o.rule=a.split('=',1)[1]
        elif a == '--inline-rules': i+=1; o.inline=args[i] if i<len(args) else ''
        elif a.startswith('--inline-rules='): o.inline=a.split('=',1)[1]
        elif a in ('-l','--lang'):
            i+=1; o.lang=language_name(args[i]) if i<len(args) else die('error: a value is required for --lang <LANG>')
        elif a.startswith('--lang='): o.lang=language_name(a.split('=',1)[1])
        elif a == '--stdin': o.stdin=True
        elif a in ('-U','--update-all'): o.update=True
        elif a == '--files-with-matches': o.files=True
        elif a == '--json': o.json_style='pretty'
        elif a.startswith('--json='): o.json_style=a.split('=',1)[1] or 'pretty'
        elif a == '--color': i+=1; o.color=args[i] if i<len(args) else 'auto'
        elif a.startswith('--color='): o.color=a.split('=',1)[1]
        elif a in ('-A','--after'):
            i+=1; o.after=int(args[i])
        elif a in ('-B','--before'):
            i+=1; o.before=int(args[i])
        elif a in ('-C','--context'):
            i+=1; o.before=o.after=int(args[i])
        elif a.startswith('--debug-query'):
            o.debug=a.split('=',1)[1] if '=' in a else 'pattern'
        elif a in ('-c','--config','-j','--threads','--heading','--strictness','--selector','--inspect','--globs','--no-ignore','--format','--report-style','--filter','--max-results','--error','--warning','--info','--hint','--off'):
            if i+1 < len(args) and not args[i+1].startswith('-'): i+=1
        elif a.startswith('-'):
            # tolerate value-style flags not implemented
            pass
        else:
            o.paths.append(a)
        i+=1
    return o

def pattern_regex(pattern):
    names=[]; seen=set(); out=''; i=0
    while i < len(pattern):
        c=pattern[i]
        if c=='$':
            j=i+1
            while j<len(pattern) and (pattern[j].isalnum() or pattern[j]=='_'): j+=1
            name=pattern[i+1:j]
            if name and (name[0].isupper() or name.startswith('_')):
                
                if name in seen:
                    out += f"(?P={name})"
                else:
                    names.append(name); seen.add(name)
                    out += f"(?P<{name}>.+?)"
                i=j; continue
        if c.isspace():
            out += r"\s+"
        elif c in '()[]{}.,;:+-*/?=!<>|&^%':
            out += re.escape(c)
        else:
            out += re.escape(c)
        i+=1
    # A semicolon after an expression is usually not part of the AST node.
    return re.compile(out), names

def line_col(text, pos):
    line=text.count('\n',0,pos)
    last=text.rfind('\n',0,pos)
    col=pos if last<0 else pos-last-1
    return line,col

def line_bounds(text,pos):
    s=text.rfind('\n',0,pos)+1
    e=text.find('\n',pos)
    if e<0: e=len(text)
    return s,e

def make_obj(path, text, m, names, lang, rewrite=None, rule=None):
    start,end=m.span(); ls,le=line_bounds(text,start); line_text=text[ls:le]
    sl,sc=line_col(text,start); el,ec=line_col(text,end)
    singles={}
    for n in names:
        if n in m.groupdict() and m.group(n) is not None:
            gs,ge=m.span(n); gl,gc=line_col(text,gs); hl,hc=line_col(text,ge)
            singles[n]={"text":m.group(n),"range":{"byteOffset":{"start":gs,"end":ge},"start":{"line":gl,"column":gc},"end":{"line":hl,"column":hc}}}
    obj={"text":m.group(0),"range":{"byteOffset":{"start":start,"end":end},"start":{"line":sl,"column":sc},"end":{"line":el,"column":ec}},"file":path,"lines":line_text,"charCount":{"leading":start-ls,"trailing":le-end},"language":lang or infer_lang(path),"metaVariables":{"single":singles,"multi":{},"transformed":{}}}
    if rewrite is not None:
        rep=apply_rewrite(rewrite, {k:v['text'] for k,v in singles.items()})
        obj["replacement"]=rep; obj["replacementOffsets"]={"start":start,"end":end}
    if rule:
        obj.update({"ruleId":rule.get('id','rule'),"severity":rule.get('severity','hint'),"note":None,"message":rule.get('message',''),"labels":[{"text":m.group(0),"range":obj['range'],"style":"primary"}]})
    return obj

def infer_lang(path): return EXT_LANG.get(Path(path).suffix.lower(), 'Unknown')

def apply_rewrite(tpl, vals):
    out=tpl
    for k,v in vals.items(): out=out.replace('$'+k, v)
    return out

def collect_paths(paths):
    if not paths: paths=['.']
    files=[]
    for p in paths:
        P=Path(p)
        if P.is_file(): files.append(str(P))
        elif P.is_dir():
            for root, dirs, fs in os.walk(P):
                dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ('target','node_modules','__pycache__')]
                for f in fs:
                    if f.startswith('.'): continue
                    full=Path(root)/f
                    if full.name in ('executable','submission.tar.gz'): continue
                    files.append(str(full))
    return sorted(files)

def find_matches(text, pattern):
    rx,names=pattern_regex(pattern)
    return rx,names,list(rx.finditer(text))

def print_json(matches, style):
    if style=='stream':
        for m in matches: print(json.dumps(m,separators=(',',':')))
    elif style=='compact': print(json.dumps(matches,separators=(',',':')))
    else: print(json.dumps(matches,indent=2))

def simple_diff(path, old, new):
    old_lines=old.splitlines(); new_lines=new.splitlines()
    print(path); print(f"@@ -0,{len(old_lines)} +0,{len(new_lines)} @@")
    sm=difflib.SequenceMatcher(a=old_lines,b=new_lines)
    for tag,i1,i2,j1,j2 in sm.get_opcodes():
        if tag=='equal':
            for off,line in enumerate(old_lines[i1:i2], i1+1): print(f"{off} {off}│ {line}")
        elif tag=='delete':
            for off,line in enumerate(old_lines[i1:i2], i1+1): print(f"{off}  │-{line}")
        elif tag=='insert':
            for off,line in enumerate(new_lines[j1:j2], j1+1): print(f"  {off}│+{line}")
        elif tag=='replace':
            for off,line in enumerate(old_lines[i1:i2], i1+1): print(f"{off}  │-{line}")
            for off,line in enumerate(new_lines[j1:j2], j1+1): print(f"  {off}│+{line}")

def run_search(o, rule=None):
    if not o.pattern: die('error: the following required arguments were not provided:\n  --pattern <PATTERN>')
    if o.debug:
        if o.debug=='sexp': print('Debug Sexp:\n(program (expression_statement (call_expression function: (identifier) arguments: (arguments (identifier)))))')
        else: print('Debug Pattern:\n' + o.pattern)
    all_objs=[]; total=0; changed=[]
    sources=[]
    if o.stdin:
        sources.append(('STDIN', sys.stdin.read(), False))
    else:
        for p in collect_paths(o.paths):
            try:
                data=Path(p).read_text(errors='replace')
            except Exception: continue
            sources.append((p,data,True))
    for path,text,writable in sources:
        lang=o.lang or infer_lang(path)
        rx,names,matches=find_matches(text,o.pattern)
        if not matches: continue
        if o.files:
            print(path); total += len(matches); continue
        new=text; reps=[]
        for m in matches:
            obj=make_obj(path,text,m,names,lang,o.rewrite,rule)
            all_objs.append(obj); total+=1
            if o.rewrite:
                vals={k:v['text'] for k,v in obj['metaVariables']['single'].items()}
                reps.append((m.start(),m.end(),apply_rewrite(o.rewrite,vals)))
        if o.rewrite:
            for s,e,r in reversed(reps): new=new[:s]+r+new[e:]
            if o.update and writable:
                Path(path).write_text(new); changed.append(len(reps))
            elif not o.json_style:
                if rule:
                    # ast-grep scan shows one diagnostic per match; compact approximation is acceptable.
                    print(path); print(f"help[{rule.get('id','rule')}]: {rule.get('message','')}")
                simple_diff(path,text,new)
        elif not o.json_style:
            lines=text.splitlines()
            printed=set()
            for m in matches:
                ln,_=line_col(text,m.start())
                start=max(0,ln-o.before); end=min(len(lines)-1,ln+o.after)
                for n in range(start,end+1):
                    if (path,n) not in printed:
                        print(f"{path}:{n+1}:{lines[n]}"); printed.add((path,n))
    if o.json_style: print_json(all_objs,o.json_style)
    if o.update and o.rewrite and not o.json_style:
        print(f"Applied {sum(changed)} changes")
    return 0 if total else 1

def parse_rule_text(txt):
    d={}; current=None
    for raw in txt.splitlines():
        line=raw.rstrip('\n')
        if not line.strip() or line.lstrip().startswith('#'): continue
        s=line.strip()
        if ':' in s:
            k,v=s.split(':',1); k=k.strip(); v=v.strip().strip('"\'')
            if k in ('id','language','message','severity','fix'):
                d[k]=v
            elif k=='pattern': d['pattern']=v
    return d

def command_scan(args):
    o=parse_common(args, scan=True)
    texts=[]
    if o.rule:
        try: texts.append(Path(o.rule).read_text())
        except Exception as e: die(f"Cannot read rule file {o.rule}: {e}",1)
    if o.inline: texts += o.inline.split('\n---')
    if not texts:
        # try sgconfig/rules lightly
        for p in Path('.').glob('**/*.yml'):
            if p.name.startswith('sgconfig'): continue
            texts.append(p.read_text(errors='replace'))
    if not texts: return 0
    rc=1
    for t in texts:
        r=parse_rule_text(t)
        if not r.get('pattern'): continue
        o.pattern=r['pattern']; o.rewrite=r.get('fix') or r.get('rewrite'); o.lang=language_name(r.get('language','')) if r.get('language') else o.lang
        sub=run_search(o, r); rc=0 if sub==0 else rc
    return rc

def command_new(args):
    if any(a in ('-h','--help') for a in args): print(NEW_HELP); return 0
    yes='-y' in args or '--yes' in args
    vals=[a for a in args if not a.startswith('-')]
    kind='project'; name='sgproject'
    if vals and vals[0] in ('project','rule','test','util'):
        kind=vals[0]; name=vals[1] if len(vals)>1 else name
    elif vals:
        name=vals[0]; kind=vals[1] if len(vals)>1 and vals[1] in ('project','rule','test','util') else kind
    if kind=='project':
        print('Creating a new ast-grep project...')
        Path(name).mkdir(parents=True, exist_ok=True); Path(name,'rules').mkdir(exist_ok=True); Path(name,'tests').mkdir(exist_ok=True)
        Path(name,'sgconfig.yml').write_text('ruleDirs:\n  - rules\ntestConfigs:\n  - testDir: tests\n')
        print('Your new ast-grep project has been created!')
    elif kind in ('rule','util'):
        Path('rules').mkdir(exist_ok=True); Path('rules',name+'.yml').write_text(f'id: {name}\nlanguage: JavaScript\nmessage: TODO\nrule:\n  pattern: TODO\n')
        print(f'Created rules/{name}.yml')
    else:
        Path('tests').mkdir(exist_ok=True); Path('tests',name+'.yml').write_text(f'id: {name}\nvalid:\n  - |\n    // valid\ninvalid:\n  - |\n    // invalid\n')
        print(f'Created tests/{name}.yml')
    return 0

def completions(args):
    shell = next((a for a in args if not a.startswith('-')), 'bash')
    if '-h' in args or '--help' in args:
        print('Generate shell completion script\n\nUsage: executable completions [OPTIONS] [SHELL]'); return 0
    print(f'# completion script for ast-grep ({shell})')
    print('complete -W "run scan test new lsp completions help" executable')
    return 0

def main(argv):
    if not argv or argv[0] in ('-h','--help','help'):
        if len(argv)>1 and argv[0]=='help':
            sub=argv[1]
            if sub=='run': print(RUN_HELP); return 0
            if sub=='scan': print(SCAN_HELP); return 0
            if sub=='new': print(NEW_HELP); return 0
        print(ROOT_HELP); return 0
    if argv[0] in ('-V','--version','version'):
        print(VERSION); return 0
    # global config is ignored
    if argv[0] in ('-c','--config') and len(argv)>2:
        argv=argv[2:]
    cmd=argv[0]
    if cmd=='run': return run_search(parse_common(argv[1:]))
    if cmd=='scan': return command_scan(argv[1:])
    if cmd=='new': return command_new(argv[1:])
    if cmd=='test':
        if any(a in ('-h','--help') for a in argv[1:]): print('Test ast-grep rules\n\nUsage: executable test [OPTIONS]'); return 0
        print('No tests found'); return 0
    if cmd=='lsp':
        if any(a in ('-h','--help') for a in argv[1:]): print('Start language server\n\nUsage: executable lsp [OPTIONS]'); return 0
        return 0
    if cmd=='completions': return completions(argv[1:])
    # default run command
    return run_search(parse_common(argv))

if __name__=='__main__':
    sys.exit(main(sys.argv[1:]))
