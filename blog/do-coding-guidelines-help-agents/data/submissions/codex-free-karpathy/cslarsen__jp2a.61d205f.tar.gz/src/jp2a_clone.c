#include <errno.h>
#include <math.h>
#include <setjmp.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <jpeglib.h>

typedef struct {
  int width, height;
  int border, invert, flipx, flipy, colors, html, html_raw, fill, grayscale;
  int html_no_bold, clear, verbose;
  int term_fit, term_width, term_height, term_zoom;
  int html_fontsize;
  double red, green, blue;
  const char *chars, *output, *html_title;
} Options;

typedef struct {
  int width, height, comp;
  unsigned char *px;
} Image;

struct JpegError {
  struct jpeg_error_mgr pub;
  jmp_buf setjmp_buffer;
  char message[JMSG_LENGTH_MAX];
};

static void jpeg_error_exit(j_common_ptr cinfo) {
  struct JpegError *err = (struct JpegError *)cinfo->err;
  (*cinfo->err->format_message)(cinfo, err->message);
  longjmp(err->setjmp_buffer, 1);
}

static const char *help_text =
"jp2a 1.0.8\n"
"Copyright 2006-2016 Christian Stigen Larsen\n"
"Distributed under the GNU General Public License (GPL) v2.\n"
"\n"
"Usage: jp2a [ options ] [ file(s) | URL(s) ]\n"
"\n"
"Convert files or URLs from JPEG format to ASCII.\n"
"\n"
"OPTIONS\n"
"  -                 Read images from standard input.\n"
"      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145\n"
"  -b, --border      Print a border around the output image.\n"
"      --chars=...   Select character palette used to paint the image.\n"
"                    Leftmost character corresponds to black pixel, right-\n"
"                    most to white.  Minimum two characters must be specified.\n"
"      --clear       Clears screen before drawing each output image.\n"
"      --colors      Use ANSI colors in output.\n"
"  -d, --debug       Print additional debug information.\n"
"      --fill        When used with --color and/or --html, color each character's\n"
"                    background color.\n"
"  -x, --flipx       Flip image in X direction.\n"
"  -y, --flipy       Flip image in Y direction.\n"
"  -f, --term-fit    Use the largest image dimension that fits in your terminal\n"
"                    display with correct aspect ratio.\n"
"      --term-height Use terminal display height.\n"
"      --term-width  Use terminal display width.\n"
"  -z, --term-zoom   Use terminal display dimension for output.\n"
"      --grayscale   Convert image to grayscale when using --html or --colors\n"
"      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866\n"
"      --height=N    Set output height, calculate width from aspect ratio.\n"
"  -h, --help        Print program help.\n"
"      --html        Produce strict XHTML 1.0 output.\n"
"      --html-fill   Same as --fill (will be phased out)\n"
"      --html-fontsize=N   Set fontsize to N pt, default is 4.\n"
"      --html-no-bold      Do not use bold characters with HTML output\n"
"      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.\n"
"      --html-title=...  Set HTML output title\n"
"  -i, --invert      Invert output image.  Use if your display has a dark\n"
"                    background.\n"
"      --background=dark   These are just mnemonics whether to use --invert\n"
"      --background=light  or not.  If your console has light characters on\n"
"                    a dark background, use --background=dark.\n"
"      --output=...  Write output to file.\n"
"      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.\n"
"      --size=WxH    Set output width and height.\n"
"  -v, --verbose     Verbose output.\n"
"  -V, --version     Print program version.\n"
"      --width=N     Set output width, calculate height from ratio.\n"
"\n"
"  The default mode is `jp2a --term-fit --background=dark'.\n"
"  See the man-page for jp2a for more detailed help text.\n"
"\n"
"Project homepage on https://github.com/cslarsen/jp2a\n"
"Report bugs to <csl@csl.name>\n";

static void init_options(Options *o) {
  memset(o, 0, sizeof(*o));
  o->chars = "   ...',;:clodxkO0KXNWM";
  o->red = 0.2989;
  o->green = 0.5866;
  o->blue = 0.1145;
  o->html_fontsize = 8;
  o->html_title = "jp2a converted image";
  o->term_fit = 1;
}

static int parse_int(const char *s, int *out) {
  char *end = NULL;
  long v;
  if (!s || !*s) return 0;
  errno = 0;
  v = strtol(s, &end, 10);
  if (errno || *end || v <= 0 || v > 100000) return 0;
  *out = (int)v;
  return 1;
}

static int parse_double(const char *s, double *out) {
  char *end = NULL;
  errno = 0;
  double v = strtod(s, &end);
  if (errno || !s || !*s || *end) return 0;
  *out = v;
  return 1;
}

static void version(void) {
  fputs("jp2a 1.0.8\n"
        "Copyright 2006-2016 Christian Stigen Larsen\n"
        "Distributed under the GNU General Public License (GPL) v2.\n", stdout);
}

static int unknown(const char *arg) {
  fprintf(stderr, "Unknown option %s\n\n%s", arg, help_text);
  return 1;
}

static int parse_size(const char *s, int *w, int *h) {
  char *x = strchr(s, 'x');
  char left[64], right[64];
  if (!x || x == s || !x[1] || (size_t)(x - s) >= sizeof(left)) return 0;
  memcpy(left, s, (size_t)(x - s));
  left[x - s] = 0;
  snprintf(right, sizeof(right), "%s", x + 1);
  return parse_int(left, w) && parse_int(right, h);
}

static int is_prefix(const char *s, const char *p) {
  return strncmp(s, p, strlen(p)) == 0;
}

static int parse_args(int argc, char **argv, Options *o, char ***files, int *nfiles) {
  *files = calloc((size_t)argc + 1, sizeof(char *));
  if (!*files) return 1;
  for (int i = 1; i < argc; i++) {
    char *a = argv[i];
    if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
      fputs(help_text, stdout);
      exit(0);
    } else if (!strcmp(a, "-V") || !strcmp(a, "--version")) {
      version();
      exit(0);
    } else if (!strcmp(a, "-")) {
      (*files)[(*nfiles)++] = a;
    } else if (!strcmp(a, "-b") || !strcmp(a, "--border")) o->border = 1;
    else if (!strcmp(a, "-i") || !strcmp(a, "--invert")) o->invert = 1;
    else if (!strcmp(a, "-x") || !strcmp(a, "--flipx")) o->flipx = 1;
    else if (!strcmp(a, "-y") || !strcmp(a, "--flipy")) o->flipy = 1;
    else if (!strcmp(a, "-v") || !strcmp(a, "--verbose")) o->verbose = 1;
    else if (!strcmp(a, "-d") || !strcmp(a, "--debug")) {}
    else if (!strcmp(a, "-f") || !strcmp(a, "--term-fit")) o->term_fit = 1;
    else if (!strcmp(a, "-z") || !strcmp(a, "--term-zoom") || !strcmp(a, "--zoom")) o->term_zoom = 1;
    else if (!strcmp(a, "--term-width")) o->term_width = 1;
    else if (!strcmp(a, "--term-height")) o->term_height = 1;
    else if (!strcmp(a, "--colors") || !strcmp(a, "--color")) o->colors = 1;
    else if (!strcmp(a, "--html")) o->html = 1;
    else if (!strcmp(a, "--html-raw")) o->html_raw = 1;
    else if (!strcmp(a, "--html-no-bold")) o->html_no_bold = 1;
    else if (!strcmp(a, "--fill") || !strcmp(a, "--html-fill")) o->fill = 1;
    else if (!strcmp(a, "--grayscale")) o->grayscale = 1;
    else if (!strcmp(a, "--clear")) o->clear = 1;
    else if (is_prefix(a, "--width=")) { if (!parse_int(a + 8, &o->width)) return unknown(a); o->term_fit = 0; }
    else if (is_prefix(a, "--height=")) { if (!parse_int(a + 9, &o->height)) return unknown(a); o->term_fit = 0; }
    else if (is_prefix(a, "--size=")) { if (!parse_size(a + 7, &o->width, &o->height)) return unknown(a); o->term_fit = 0; }
    else if (is_prefix(a, "--chars=")) o->chars = a + 8;
    else if (is_prefix(a, "--output=")) o->output = a + 9;
    else if (is_prefix(a, "--html-title=")) o->html_title = a + 13;
    else if (is_prefix(a, "--html-fontsize=")) { if (!parse_int(a + 16, &o->html_fontsize)) return unknown(a); }
    else if (is_prefix(a, "--red=")) { if (!parse_double(a + 6, &o->red)) return unknown(a); }
    else if (is_prefix(a, "--green=")) { if (!parse_double(a + 8, &o->green)) return unknown(a); }
    else if (is_prefix(a, "--blue=")) { if (!parse_double(a + 7, &o->blue)) return unknown(a); }
    else if (!strcmp(a, "--background=dark")) o->invert = 0;
    else if (!strcmp(a, "--background=light")) o->invert = 1;
    else if (a[0] == '-') return unknown(a);
    else (*files)[(*nfiles)++] = a;
  }
  if (*nfiles == 0) {
    fprintf(stderr, "No files specified.\n\n%s", help_text);
    return 1;
  }
  return 0;
}

static unsigned char *read_stdin(size_t *len) {
  size_t cap = 65536, n = 0;
  unsigned char *buf = malloc(cap);
  if (!buf) return NULL;
  for (;;) {
    if (n == cap) {
      cap *= 2;
      unsigned char *tmp = realloc(buf, cap);
      if (!tmp) { free(buf); return NULL; }
      buf = tmp;
    }
    size_t got = fread(buf + n, 1, cap - n, stdin);
    n += got;
    if (got == 0) break;
  }
  *len = n;
  return buf;
}

static int load_jpeg(const char *path, Image *img, char *errbuf, size_t errlen) {
  FILE *fp = NULL;
  unsigned char *mem = NULL;
  size_t memlen = 0;
  struct jpeg_decompress_struct cinfo;
  struct JpegError jerr;
  memset(img, 0, sizeof(*img));
  memset(&cinfo, 0, sizeof(cinfo));
  cinfo.err = jpeg_std_error(&jerr.pub);
  jerr.pub.error_exit = jpeg_error_exit;
  if (setjmp(jerr.setjmp_buffer)) {
    snprintf(errbuf, errlen, "%s", jerr.message);
    jpeg_destroy_decompress(&cinfo);
    if (fp) fclose(fp);
    free(mem);
    return 1;
  }
  jpeg_create_decompress(&cinfo);
  if (!strcmp(path, "-")) {
    mem = read_stdin(&memlen);
    if (!mem || memlen == 0) {
      snprintf(errbuf, errlen, "Could not read standard input");
      jpeg_destroy_decompress(&cinfo);
      free(mem);
      return 1;
    }
    jpeg_mem_src(&cinfo, mem, memlen);
  } else {
    fp = fopen(path, "rb");
    if (!fp) {
      snprintf(errbuf, errlen, "%s: %s", path, strerror(errno));
      jpeg_destroy_decompress(&cinfo);
      return 1;
    }
    jpeg_stdio_src(&cinfo, fp);
  }
  jpeg_read_header(&cinfo, TRUE);
  cinfo.out_color_space = JCS_RGB;
  jpeg_start_decompress(&cinfo);
  img->width = (int)cinfo.output_width;
  img->height = (int)cinfo.output_height;
  img->comp = (int)cinfo.output_components;
  size_t row_stride = (size_t)img->width * (size_t)img->comp;
  img->px = malloc(row_stride * (size_t)img->height);
  if (!img->px) {
    snprintf(errbuf, errlen, "out of memory");
    jpeg_destroy_decompress(&cinfo);
    if (fp) fclose(fp);
    free(mem);
    return 1;
  }
  while (cinfo.output_scanline < cinfo.output_height) {
    unsigned char *row = img->px + (size_t)cinfo.output_scanline * row_stride;
    jpeg_read_scanlines(&cinfo, &row, 1);
  }
  jpeg_finish_decompress(&cinfo);
  jpeg_destroy_decompress(&cinfo);
  if (fp) fclose(fp);
  free(mem);
  return 0;
}

static int terminal_size(int *w, int *h) {
  struct winsize ws;
  const char *term = getenv("TERM");
  if (!term || !*term) {
    fprintf(stderr, "Environment variable TERM not set.\n");
    return 1;
  }
  if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col && ws.ws_row) {
    *w = ws.ws_col;
    *h = ws.ws_row;
  } else {
    *w = 80;
    *h = 24;
  }
  return 0;
}

static void dimensions(const Options *o, const Image *img, int *ow, int *oh) {
  *ow = o->width;
  *oh = o->height;
  if (*ow && !*oh) *oh = (int)floor((*ow * (double)img->height / img->width) * 0.5);
  if (*oh && !*ow) *ow = (int)floor((*oh * (double)img->width / img->height) * 2.0);
  if (*ow < 1) *ow = img->width;
  if (*oh < 1) *oh = img->height;
}

static double luminance_at(const Image *img, const Options *o, int x, int y) {
  const unsigned char *p = img->px + ((size_t)y * img->width + x) * img->comp;
  if (img->comp >= 3) return o->red * p[0] + o->green * p[1] + o->blue * p[2];
  return p[0];
}

static double block_luminance(const Image *img, const Options *o, int ox, int oy, int ow, int oh) {
  int x0 = (int)floor(ox * (double)img->width / ow);
  int x1 = (int)floor((ox + 1) * (double)img->width / ow);
  int y0 = (int)floor(oy * (double)img->height / oh);
  int y1 = (int)floor((oy + 1) * (double)img->height / oh);
  if (x1 <= x0) x1 = x0 + 1;
  if (y1 <= y0) y1 = y0 + 1;
  if (x1 > img->width) x1 = img->width;
  if (y1 > img->height) y1 = img->height;
  double sum = 0.0;
  int n = 0;
  for (int y = y0; y < y1; y++)
    for (int x = x0; x < x1; x++, n++)
      sum += luminance_at(img, o, x, y);
  return n ? sum / n : 0.0;
}

static char ascii_for(double lum, const Options *o) {
  size_t n = strlen(o->chars);
  if (n < 2) n = 2;
  if (lum < 0) lum = 0;
  if (lum > 255) lum = 255;
  if (o->invert) lum = 255 - lum;
  int idx = (int)floor(lum * (double)(n - 1) / 255.0);
  if (idx < 0) idx = 0;
  if ((size_t)idx >= n) idx = (int)n - 1;
  return o->chars[idx];
}

static void html_escape_char(FILE *out, char c) {
  if (c == '&') fputs("&amp;", out);
  else if (c == '<') fputs("&lt;", out);
  else if (c == '>') fputs("&gt;", out);
  else if (c == '"') fputs("&quot;", out);
  else putc(c, out);
}

static void render_text(FILE *out, const Options *o, const Image *img, int ow, int oh) {
  if (o->clear) fputs("\033[H\033[J", out);
  if (o->border) {
    putc('+', out);
    for (int i = 0; i < ow; i++) putc('-', out);
    fputs("+\n", out);
  }
  for (int yy = 0; yy < oh; yy++) {
    int y = o->flipy ? oh - 1 - yy : yy;
    if (o->border) putc('|', out);
    for (int xx = 0; xx < ow; xx++) {
      int x = o->flipx ? ow - 1 - xx : xx;
      double lum = block_luminance(img, o, x, y, ow, oh);
      char c = ascii_for(lum, o);
      if (o->colors) {
        int v = (int)(o->invert ? 255 - lum : lum);
        if (v < 0) v = 0;
        if (v > 255) v = 255;
        if (o->grayscale || img->comp < 3) {
          if (v > 240) fprintf(out, "\033[1m%c\033[0m", c);
          else putc(c, out);
        } else {
          fprintf(out, "\033[38;5;%dm%c\033[0m", 232 + (v * 23 / 255), c);
        }
      } else {
        putc(c, out);
      }
    }
    if (o->border) putc('|', out);
    putc('\n', out);
  }
  if (o->border) {
    putc('+', out);
    for (int i = 0; i < ow; i++) putc('-', out);
    fputs("+\n", out);
  }
}

static void render_html(FILE *out, const Options *o, const Image *img, int ow, int oh) {
  if (!o->html_raw) {
    fprintf(out, "<?xml version='1.0' encoding='ISO-8859-1'?>\n"
                 "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n"
                 "<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>\n"
                 "<head>\n<title>");
    for (const char *p = o->html_title; *p; p++) html_escape_char(out, *p);
    fprintf(out, "</title>\n<style type='text/css'>\nbody {\nbackground-color: %s;\n}\n.ascii {\n"
                 "   font-family: Courier;\n   color: %s;\n   font-size:%dpt;\n",
            o->invert ? "white" : "black", o->invert ? "black" : "white", o->html_fontsize);
    if (!o->html_no_bold) fputs("   font-weight: bold;\n", out);
    fputs("}\n</style>\n</head>\n<body>\n<div class='ascii'><pre>\n", out);
  }
  for (int yy = 0; yy < oh; yy++) {
    int y = o->flipy ? oh - 1 - yy : yy;
    for (int xx = 0; xx < ow; xx++) {
      int x = o->flipx ? ow - 1 - xx : xx;
      double lum = block_luminance(img, o, x, y, ow, oh);
      char c = ascii_for(lum, o);
      int v = (int)(o->invert ? 255 - lum : lum);
      if (v < 0) v = 0;
      if (v > 255) v = 255;
      if (o->colors) {
        fprintf(out, "<span style='color:#%02x%02x%02x;'>", v, v, v);
        html_escape_char(out, c);
        fputs("</span>", out);
      } else {
        html_escape_char(out, c);
      }
    }
    fputs(o->html_raw && o->colors ? "<br/>" : "\n", out);
  }
  if (!o->html_raw) fputs("</pre>\n</div>\n</body>\n</html>\n", out);
}

int main(int argc, char **argv) {
  Options opt;
  char **files = NULL;
  int nfiles = 0, status = 0;
  init_options(&opt);
  if (parse_args(argc, argv, &opt, &files, &nfiles)) return 1;
  FILE *out = stdout;
  if (opt.output && strcmp(opt.output, "-")) {
    out = fopen(opt.output, "w");
    if (!out) {
      fprintf(stderr, "%s: %s\n", opt.output, strerror(errno));
      free(files);
      return 1;
    }
  }
  for (int i = 0; i < nfiles; i++) {
    Image img;
    char err[256];
    int ow, oh;
    if (load_jpeg(files[i], &img, err, sizeof(err))) {
      fprintf(stderr, "%s\n", err);
      status = 1;
      continue;
    }
    if (opt.verbose) {
      fprintf(stderr, "File: %s\nSource width: %d\nSource height: %d\nSource color components: %d\n",
              files[i], img.width, img.height, img.comp == 3 ? 3 : 1);
    }
    if (opt.term_zoom || opt.term_width || opt.term_height || (opt.term_fit && !opt.width && !opt.height)) {
      int tw = 0, th = 0;
      if (terminal_size(&tw, &th)) { free(img.px); status = 1; continue; }
      if (opt.term_zoom) { opt.width = tw; opt.height = th; }
      else if (opt.term_width || (opt.term_fit && !opt.width && !opt.height)) opt.width = tw;
      else if (opt.term_height) opt.height = th;
    }
    dimensions(&opt, &img, &ow, &oh);
    if (opt.verbose) {
      fprintf(stderr, "Output width: %d\nOutput height: %d\nOutput palette (%zu chars): '%s'\n",
              ow, oh, strlen(opt.chars), opt.chars);
    }
    if (opt.html) render_html(out, &opt, &img, ow, oh);
    else render_text(out, &opt, &img, ow, oh);
    free(img.px);
  }
  if (out != stdout) fclose(out);
  free(files);
  return status;
}
