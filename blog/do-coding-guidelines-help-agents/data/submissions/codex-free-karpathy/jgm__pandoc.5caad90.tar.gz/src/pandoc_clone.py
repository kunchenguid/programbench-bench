#!/usr/bin/env python3
import html
import json
import os
import re
import sys

INPUT_FORMATS = """asciidoc
biblatex
bibtex
bits
commonmark
commonmark_x
creole
csljson
csv
djot
docbook
docx
dokuwiki
endnotexml
epub
fb2
gfm
haddock
html
ipynb
jats
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
mdoc
mediawiki
muse
native
odt
opml
org
pod
pptx
ris
rst
rtf
t2t
textile
tikiwiki
tsv
twiki
typst
vimwiki
xlsx
xml""".splitlines()

OUTPUT_FORMATS = """ansi
asciidoc
asciidoc_legacy
asciidoctor
bbcode
bbcode_fluxbb
bbcode_hubzilla
bbcode_phpbb
bbcode_steam
bbcode_xenforo
beamer
biblatex
bibtex
chunkedhtml
commonmark
commonmark_x
context
csljson
djot
docbook
docbook4
docbook5
docx
dokuwiki
dzslides
epub
epub2
epub3
fb2
gfm
haddock
html
html4
html5
icml
ipynb
jats
jats_archiving
jats_articleauthoring
jats_publishing
jira
json
latex
man
markdown
markdown_github
markdown_mmd
markdown_phpextra
markdown_strict
markua
mediawiki
ms
muse
native
odt
opendocument
opml
org
pdf
plain
pptx
revealjs
rst
rtf
s5
slideous
slidy
tei
texinfo
textile
typst
vimdoc
xml
xwiki
zimwiki""".splitlines()

EXTENSIONS = """-abbreviations
-alerts
+all_symbols_escapable
-angle_brackets_escapable
-ascii_identifiers
+auto_identifiers
-autolink_bare_uris
+backtick_code_blocks
+blank_before_blockquote
+blank_before_header
+bracketed_spans
+citations
+definition_lists
-east_asian_line_breaks
-emoji
+escaped_line_breaks
+example_lists
+fancy_lists
+fenced_code_attributes
+fenced_code_blocks
+fenced_divs
+footnotes
-four_space_rule
-gfm_auto_identifiers
+grid_tables
-gutenberg
-hard_line_breaks
+header_attributes
+table_attributes
-ignore_line_breaks
+implicit_figures
+implicit_header_references
+inline_code_attributes
+inline_notes
+intraword_underscores
+latex_macros
+line_blocks
+link_attributes
-lists_without_preceding_blankline
-literate_haskell
-mark
-markdown_attribute
+markdown_in_html_blocks
-mmd_header_identifiers
-mmd_link_attributes
-mmd_title_block
+multiline_tables
+native_divs
+native_spans
-old_dashes
+pandoc_title_block
+pipe_tables
+raw_attribute
+raw_html
+raw_tex
-rebase_relative_paths
-short_subsuperscripts
+shortcut_reference_links
+simple_tables
+smart
+space_in_atx_header
-spaced_reference_links
+startnum
+strikeout
+subscript
+superscript
+task_lists
+table_captions
+tex_math_dollars
-tex_math_double_backslash
-tex_math_single_backslash
-wikilinks_title_after_pipe
-wikilinks_title_before_pipe
+yaml_metadata_block""".splitlines()

HIGHLIGHT_STYLES = "pygments tango espresso zenburn kate monochrome breezedark haddock".split()
HIGHLIGHT_LANGS = """abc actionscript ada agda apache asn1 asp ats awk bash bibtex boo c changelog clojure cmake coffee coldfusion comments commonlisp cpp crystal cs css curry d dart debiancontrol default diff djangotemplate dockerfile dosbat dot doxygen doxygenlua dtd eiffel elixir elm email erlang fsharp fortran gcc go haskell html ini java javascript json julia kotlin latex lex lilypond lua makefile mandoc markdown mathematica matlab maxima mediawiki metafont mips modelines modula2 modula3 monobasic mustache nasm noweb objectivec objectivecpp ocaml octave pascal perl php pike postscript prolog python r relaxng relaxngcompact rest rhtml roff ruby rust scala scheme sci sed sgml sql sqlmysql sqlpostgresql tcl texinfo toml typescript verilog vhdl xml xorg yaml zsh""".split()


class Block:
    def __init__(self, kind, **kw):
        self.kind = kind
        self.__dict__.update(kw)


def usage():
    return """executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT
  -o FILE               --output=FILE
                        --data-dir=DIRECTORY
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]
                        --metadata-file=FILE
  -d FILE               --defaults=FILE
                        --file-scope[=true|false]
                        --sandbox[=true|false]
  -s[true|false]        --standalone[=true|false]
  -V KEY[:VALUE]        --variable=KEY[:VALUE]
  -v                    --version
  -h                    --help
"""


def version():
    return """pandoc 3.9.0.2
Features: +server +lua
Scripting engine: Lua 5.4
User data directory: /home/agent/.local/share/pandoc
Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
This is free software; see the source for copying conditions. There is no
warranty, not even for merchantability or fitness for a particular purpose.
"""


def slugify(s):
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"`([^`]*)`", r"\1", s)
    s = re.sub(r"[*_~\[\]\(\)]", "", s).strip().lower()
    s = re.sub(r"[^\w\s.-]", "", s, flags=re.UNICODE)
    s = re.sub(r"\s+", "-", s)
    return s or "section"


def split_meta(text):
    meta = {}
    lines = text.splitlines()
    i = 0
    if lines and lines[0].strip() == "---":
        i = 1
        while i < len(lines) and lines[i].strip() not in ("---", "..."):
            m = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", lines[i])
            if m:
                meta[m.group(1)] = m.group(2).strip().strip('"')
            i += 1
        if i < len(lines):
            return meta, "\n".join(lines[i + 1 :]) + ("\n" if text.endswith("\n") else "")
    titles = []
    while i < len(lines) and lines[i].startswith("%"):
        titles.append(lines[i][1:].strip())
        i += 1
    if titles:
        if titles[0]:
            meta["title"] = titles[0]
        if len(titles) > 1 and titles[1]:
            meta["author"] = titles[1]
        if len(titles) > 2 and titles[2]:
            meta["date"] = titles[2]
        return meta, "\n".join(lines[i:]) + ("\n" if text.endswith("\n") else "")
    return meta, text


def parse_blocks(text):
    meta, text = split_meta(text.replace("\r\n", "\n").replace("\r", "\n"))
    lines = text.split("\n")
    blocks = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip():
            i += 1
            continue
        m = re.match(r"^(#{1,6})\s+(.*?)(?:\s+\{#([^}]+)\})?\s*$", line)
        if m:
            txt = m.group(2).strip()
            ident = m.group(3) or slugify(txt)
            blocks.append(Block("Header", level=len(m.group(1)), text=txt, ident=ident))
            i += 1
            continue
        if i + 1 < len(lines) and lines[i + 1].strip() and re.match(r"^[=-]{3,}\s*$", lines[i + 1]):
            level = 1 if lines[i + 1].lstrip()[0] == "=" else 2
            blocks.append(Block("Header", level=level, text=line.strip(), ident=slugify(line)))
            i += 2
            continue
        fm = re.match(r"^(```+|~~~+)\s*([^`]*)$", line)
        if fm:
            fence = fm.group(1)
            lang = fm.group(2).strip().split()[0] if fm.group(2).strip() else ""
            code = []
            i += 1
            while i < len(lines) and not lines[i].startswith(fence):
                code.append(lines[i])
                i += 1
            if i < len(lines):
                i += 1
            blocks.append(Block("CodeBlock", text="\n".join(code), lang=lang))
            continue
        if re.match(r"^ {4,}\S", line):
            code = []
            while i < len(lines) and (lines[i].startswith("    ") or not lines[i].strip()):
                code.append(lines[i][4:] if lines[i].startswith("    ") else "")
                i += 1
            blocks.append(Block("CodeBlock", text="\n".join(code).rstrip("\n"), lang=""))
            continue
        if re.match(r"^\s{0,3}([-*_])(?:\s*\1){2,}\s*$", line):
            blocks.append(Block("HorizontalRule"))
            i += 1
            continue
        if re.match(r"^\s{0,3}>\s?", line):
            q = []
            while i < len(lines) and (re.match(r"^\s{0,3}>\s?", lines[i]) or not lines[i].strip()):
                q.append(re.sub(r"^\s{0,3}>\s?", "", lines[i]))
                i += 1
            blocks.append(Block("BlockQuote", blocks=parse_blocks("\n".join(q))[1]))
            continue
        if re.match(r"^\s{0,3}([-+*])\s+", line):
            items = []
            while i < len(lines):
                m = re.match(r"^\s{0,3}([-+*])\s+(.*)$", lines[i])
                if not m:
                    break
                items.append(m.group(2).strip())
                i += 1
            blocks.append(Block("BulletList", items=items))
            continue
        if re.match(r"^\s{0,3}\d+[.)]\s+", line):
            items = []
            start = None
            while i < len(lines):
                m = re.match(r"^\s{0,3}(\d+)[.)]\s+(.*)$", lines[i])
                if not m:
                    break
                if start is None:
                    start = int(m.group(1))
                items.append(m.group(2).strip())
                i += 1
            blocks.append(Block("OrderedList", items=items, start=start or 1))
            continue
        if line.lstrip().startswith("<") and line.rstrip().endswith(">"):
            raw = []
            while i < len(lines) and lines[i].strip():
                raw.append(lines[i])
                i += 1
            blocks.append(Block("RawBlock", text="\n".join(raw)))
            continue
        para = [line.strip()]
        i += 1
        while i < len(lines) and lines[i].strip():
            if re.match(r"^(#{1,6})\s+", lines[i]) or re.match(r"^\s{0,3}([-+*]|\d+[.)])\s+", lines[i]) or re.match(r"^\s{0,3}>\s?", lines[i]) or re.match(r"^(```+|~~~+)", lines[i]):
                break
            para.append(lines[i].strip())
            i += 1
        blocks.append(Block("Para", text=" ".join(para)))
    return meta, blocks


def inline_tokens(s):
    out = []
    pos = 0
    pat = re.compile(r"(!?\[([^\]]*)\]\(([^)\s]+)(?:\s+\"([^\"]*)\")?\))|(`([^`]+)`)|(\*\*([^*]+)\*\*)|(__([^_]+)__)|(\*([^*]+)\*)|(_([^_]+)_)|(\$([^$]+)\$)")
    for m in pat.finditer(s):
        if m.start() > pos:
            add_text_tokens(out, s[pos:m.start()])
        if m.group(1):
            out.append(("Image" if m.group(1).startswith("!") else "Link", m.group(2), m.group(3), m.group(4) or ""))
        elif m.group(5):
            out.append(("Code", m.group(6)))
        elif m.group(7):
            out.append(("Strong", m.group(8)))
        elif m.group(9):
            out.append(("Strong", m.group(10)))
        elif m.group(11):
            out.append(("Emph", m.group(12)))
        elif m.group(13):
            out.append(("Emph", m.group(14)))
        elif m.group(15):
            out.append(("Math", m.group(16)))
        pos = m.end()
    if pos < len(s):
        add_text_tokens(out, s[pos:])
    return out


def add_text_tokens(out, s):
    parts = re.split(r"(\s+)", s)
    for p in parts:
        if not p:
            continue
        if p.isspace():
            if out and out[-1] != ("Space",):
                out.append(("Space",))
        else:
            out.append(("Str", p))


def inlines_plain(s):
    vals = []
    for t in inline_tokens(s):
        if t[0] == "Space":
            vals.append(" ")
        elif t[0] in ("Str", "Code", "Emph", "Strong", "Math"):
            vals.append(t[1])
        elif t[0] in ("Link", "Image"):
            vals.append(t[1])
    return "".join(vals)


def html_inline(s):
    vals = []
    for t in inline_tokens(s):
        k = t[0]
        if k == "Space":
            vals.append(" ")
        elif k == "Str":
            vals.append(html.escape(t[1]))
        elif k == "Code":
            vals.append("<code>" + html.escape(t[1]) + "</code>")
        elif k == "Emph":
            vals.append("<em>" + html_inline(t[1]) + "</em>")
        elif k == "Strong":
            vals.append("<strong>" + html_inline(t[1]) + "</strong>")
        elif k == "Math":
            vals.append('<span class="math inline">' + html.escape(t[1]) + "</span>")
        elif k == "Link":
            vals.append('<a href="' + html.escape(t[2], quote=True) + '">' + html_inline(t[1]) + "</a>")
        elif k == "Image":
            vals.append('<img src="' + html.escape(t[2], quote=True) + '" alt="' + html.escape(t[1], quote=True) + '" />')
    return "".join(vals)


def latex_escape(s):
    reps = [("\\", r"\textbackslash{}"), ("&", r"\&"), ("%", r"\%"), ("$", r"\$"), ("#", r"\#"), ("_", r"\_"), ("{", r"\{"), ("}", r"\}"), ("~", r"\textasciitilde{}"), ("^", r"\textasciicircum{}")]
    for a, b in reps:
        s = s.replace(a, b)
    return s


def latex_inline(s):
    vals = []
    for t in inline_tokens(s):
        k = t[0]
        if k == "Space":
            vals.append(" ")
        elif k == "Str":
            vals.append(latex_escape(t[1]))
        elif k == "Code":
            vals.append(r"\texttt{" + latex_escape(t[1]) + "}")
        elif k == "Emph":
            vals.append(r"\emph{" + latex_inline(t[1]) + "}")
        elif k == "Strong":
            vals.append(r"\textbf{" + latex_inline(t[1]) + "}")
        elif k == "Math":
            vals.append("$" + t[1] + "$")
        elif k == "Link":
            vals.append(r"\href{" + latex_escape(t[2]) + "}{" + latex_inline(t[1]) + "}")
        elif k == "Image":
            vals.append(r"\includegraphics{" + latex_escape(t[2]) + "}")
    return "".join(vals)


def md_inline(s, fmt="markdown"):
    vals = []
    for t in inline_tokens(s):
        k = t[0]
        if k == "Space":
            vals.append(" ")
        elif k == "Str":
            vals.append(t[1])
        elif k == "Code":
            vals.append("`" + t[1] + "`")
        elif k == "Emph":
            vals.append("*" + t[1] + "*")
        elif k == "Strong":
            vals.append("**" + t[1] + "**")
        elif k == "Math":
            vals.append("$" + t[1] + "$")
        elif k == "Link":
            vals.append("[" + t[1] + "](" + t[2] + ((' "' + t[3] + '"') if t[3] else "") + ")")
        elif k == "Image":
            vals.append("![" + t[1] + "](" + t[2] + ")")
    return "".join(vals)


def org_inline(s):
    vals = []
    for t in inline_tokens(s):
        k = t[0]
        if k == "Space":
            vals.append(" ")
        elif k == "Str":
            vals.append(t[1])
        elif k == "Code":
            vals.append("~" + t[1] + "~")
        elif k == "Emph":
            vals.append("/" + org_inline(t[1]) + "/")
        elif k == "Strong":
            vals.append("*" + org_inline(t[1]) + "*")
        elif k == "Math":
            vals.append("$" + t[1] + "$")
        elif k == "Link":
            vals.append("[[" + t[2] + "][" + org_inline(t[1]) + "]]")
        elif k == "Image":
            vals.append("[[" + t[2] + "]]")
    return "".join(vals)


def asciidoc_inline(s):
    vals = []
    for t in inline_tokens(s):
        k = t[0]
        if k == "Space":
            vals.append(" ")
        elif k == "Str":
            vals.append(t[1])
        elif k == "Code":
            vals.append("`" + t[1] + "`")
        elif k == "Emph":
            vals.append("_" + asciidoc_inline(t[1]) + "_")
        elif k == "Strong":
            vals.append("*" + asciidoc_inline(t[1]) + "*")
        elif k == "Math":
            vals.append("stem:[" + t[1] + "]")
        elif k == "Link":
            vals.append(t[2] + "[" + asciidoc_inline(t[1]) + "]")
        elif k == "Image":
            vals.append("image::" + t[2] + "[" + asciidoc_inline(t[1]) + "]")
    return "".join(vals)


def write_html(blocks, meta, standalone=False, title=None):
    out = []
    for b in blocks:
        if b.kind == "Header":
            out.append(f'<h{b.level} id="{html.escape(b.ident, quote=True)}">{html_inline(b.text)}</h{b.level}>')
        elif b.kind == "Para":
            out.append("<p>" + html_inline(b.text) + "</p>")
        elif b.kind == "CodeBlock":
            cls = f' class="{html.escape(b.lang)}"' if b.lang else ""
            out.append("<pre><code" + cls + ">" + html.escape(b.text) + "\n</code></pre>")
        elif b.kind == "BulletList":
            out.append("<ul>")
            out += ["<li>" + html_inline(x) + "</li>" for x in b.items]
            out.append("</ul>")
        elif b.kind == "OrderedList":
            attr = ' type="1"'
            if b.start != 1:
                attr += f' start="{b.start}"'
            out.append("<ol" + attr + ">")
            out += ["<li>" + html_inline(x) + "</li>" for x in b.items]
            out.append("</ol>")
        elif b.kind == "BlockQuote":
            out.append("<blockquote>")
            out.append(write_html(b.blocks, {}, False).rstrip())
            out.append("</blockquote>")
        elif b.kind == "RawBlock":
            out.append(b.text)
        elif b.kind == "HorizontalRule":
            out.append("<hr />")
    body = "\n".join(out) + ("\n" if out else "")
    if not standalone:
        return body
    doc_title = title or meta.get("title") or "-"
    return f"""<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8" />
  <meta name="generator" content="pandoc" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
  <title>{html.escape(doc_title)}</title>
</head>
<body>
{body}</body>
</html>
"""


def write_plain(blocks):
    parts = []
    for b in blocks:
        if b.kind == "Header":
            parts.append(inlines_plain(b.text))
        elif b.kind == "Para":
            parts.append(inlines_plain(b.text))
        elif b.kind == "CodeBlock":
            parts.append(b.text)
        elif b.kind == "BulletList":
            parts.append("\n".join("- " + inlines_plain(x) for x in b.items))
        elif b.kind == "OrderedList":
            parts.append("\n".join(f"{i + b.start}.  {inlines_plain(x)}" for i, x in enumerate(b.items)))
        elif b.kind == "BlockQuote":
            q = write_plain(b.blocks).rstrip().splitlines()
            parts.append("\n".join("  " + x if x else "" for x in q))
        elif b.kind == "RawBlock":
            parts.append(re.sub(r"<[^>]+>", "", b.text))
        elif b.kind == "HorizontalRule":
            parts.append("* * * * *")
    return "\n\n".join(p for p in parts if p != "") + ("\n" if parts else "")


def write_markdown(blocks, fmt="markdown"):
    parts = []
    for b in blocks:
        if b.kind == "Header":
            parts.append("#" * b.level + " " + md_inline(b.text, fmt))
        elif b.kind == "Para":
            parts.append(md_inline(b.text, fmt))
        elif b.kind == "CodeBlock":
            parts.append("```" + (b.lang if b.lang else "") + "\n" + b.text + "\n```")
        elif b.kind == "BulletList":
            parts.append("\n".join("- " + md_inline(x, fmt) for x in b.items))
        elif b.kind == "OrderedList":
            parts.append("\n".join(f"{i + b.start}.  {md_inline(x, fmt)}" for i, x in enumerate(b.items)))
        elif b.kind == "BlockQuote":
            q = write_markdown(b.blocks, fmt).rstrip().splitlines()
            parts.append("\n".join("> " + x if x else ">" for x in q))
        elif b.kind == "RawBlock":
            parts.append(b.text)
        elif b.kind == "HorizontalRule":
            parts.append("* * * * *")
    return "\n\n".join(parts) + ("\n" if parts else "")


def write_latex(blocks, standalone=False, meta=None):
    heads = ["section", "subsection", "subsubsection", "paragraph", "subparagraph", "subparagraph"]
    parts = []
    for b in blocks:
        if b.kind == "Header":
            parts.append("\\" + heads[min(b.level, 6) - 1] + "{" + latex_inline(b.text) + "}\\label{" + b.ident + "}")
        elif b.kind == "Para":
            parts.append(latex_inline(b.text))
        elif b.kind == "CodeBlock":
            parts.append("\\begin{verbatim}\n" + b.text + "\n\\end{verbatim}")
        elif b.kind == "BulletList":
            parts.append("\\begin{itemize}\n\\tightlist\n" + "\n".join("\\item\n  " + latex_inline(x) for x in b.items) + "\n\\end{itemize}")
        elif b.kind == "OrderedList":
            parts.append("\\begin{enumerate}\n\\def\\labelenumi{\\arabic{enumi}.}\n\\tightlist\n" + "\n".join("\\item\n  " + latex_inline(x) for x in b.items) + "\n\\end{enumerate}")
        elif b.kind == "BlockQuote":
            parts.append("\\begin{quote}\n" + write_latex(b.blocks).rstrip() + "\n\\end{quote}")
        elif b.kind == "RawBlock":
            parts.append(b.text)
        elif b.kind == "HorizontalRule":
            parts.append("\\begin{center}\\rule{0.5\\linewidth}{0.5pt}\\end{center}")
    body = "\n\n".join(parts) + ("\n" if parts else "")
    if not standalone:
        return body
    title = latex_escape((meta or {}).get("title", ""))
    head = "\\documentclass{article}\n\\usepackage{hyperref}\n"
    if title:
        head += "\\title{" + title + "}\n"
    return head + "\\begin{document}\n" + ("\\maketitle\n\n" if title else "") + body + "\\end{document}\n"


def write_rst(blocks):
    parts = []
    for b in blocks:
        if b.kind == "Header":
            ch = "=-~^\""[min(b.level, 5) - 1]
            txt = inlines_plain(b.text)
            parts.append(txt + "\n" + ch * len(txt))
        elif b.kind == "Para":
            parts.append(md_inline(b.text).replace("[", "`").replace("](", " <").replace(")", ">`__"))
        elif b.kind == "BulletList":
            parts.append("\n".join("- " + inlines_plain(x) for x in b.items))
        elif b.kind == "OrderedList":
            parts.append("\n".join(f"{i + b.start}. {inlines_plain(x)}" for i, x in enumerate(b.items)))
        elif b.kind == "BlockQuote":
            parts.append("..\n\n" + "\n".join("   " + x for x in write_rst(b.blocks).rstrip().splitlines()))
        elif b.kind == "CodeBlock":
            parts.append("::\n\n" + "\n".join("   " + x for x in b.text.splitlines()))
    return "\n\n".join(parts) + ("\n" if parts else "")


def write_org(blocks):
    parts = []
    for b in blocks:
        if b.kind == "Header":
            parts.append("*" * b.level + " " + inlines_plain(b.text) + f"\n:PROPERTIES:\n:CUSTOM_ID: {b.ident}\n:END:")
        elif b.kind == "Para":
            parts.append(org_inline(b.text))
        elif b.kind == "BulletList":
            parts.append("\n".join("- " + inlines_plain(x) for x in b.items))
        elif b.kind == "OrderedList":
            parts.append("\n".join(f"{i + b.start}. {inlines_plain(x)}" for i, x in enumerate(b.items)))
        elif b.kind == "BlockQuote":
            parts.append("#+begin_quote\n" + write_plain(b.blocks).rstrip() + "\n#+end_quote")
        elif b.kind == "CodeBlock":
            parts.append("#+begin_src " + b.lang + "\n" + b.text + "\n#+end_src")
    return "\n\n".join(parts) + ("\n" if parts else "")


def write_asciidoc(blocks):
    parts = []
    for b in blocks:
        if b.kind == "Header":
            parts.append("=" * (b.level + 1) + " " + inlines_plain(b.text))
        elif b.kind == "Para":
            parts.append(asciidoc_inline(b.text))
        elif b.kind == "BulletList":
            parts.append("\n".join("* " + inlines_plain(x) for x in b.items))
        elif b.kind == "OrderedList":
            parts.append("[arabic]\n" + "\n".join(". " + inlines_plain(x) for x in b.items))
        elif b.kind == "BlockQuote":
            parts.append("____\n" + write_asciidoc(b.blocks).rstrip() + "\n____")
        elif b.kind == "CodeBlock":
            parts.append("----\n" + b.text + "\n----")
    return "\n\n".join(parts) + ("\n" if parts else "")


def ast_inlines(s):
    arr = []
    for t in inline_tokens(s):
        k = t[0]
        if k == "Space":
            arr.append({"t": "Space"})
        elif k == "Str":
            arr.append({"t": "Str", "c": t[1]})
        elif k == "Code":
            arr.append({"t": "Code", "c": [["", [], []], t[1]]})
        elif k == "Emph":
            arr.append({"t": "Emph", "c": ast_inlines(t[1])})
        elif k == "Strong":
            arr.append({"t": "Strong", "c": ast_inlines(t[1])})
        elif k == "Math":
            arr.append({"t": "Math", "c": [{"t": "InlineMath"}, t[1]]})
        elif k == "Link":
            arr.append({"t": "Link", "c": [["", [], []], ast_inlines(t[1]), [t[2], t[3]]]})
        elif k == "Image":
            arr.append({"t": "Image", "c": [["", [], []], ast_inlines(t[1]), [t[2], t[3]]]})
    return arr


def ast_blocks(blocks):
    arr = []
    for b in blocks:
        if b.kind == "Header":
            arr.append({"t": "Header", "c": [b.level, [b.ident, [], []], ast_inlines(b.text)]})
        elif b.kind == "Para":
            arr.append({"t": "Para", "c": ast_inlines(b.text)})
        elif b.kind == "CodeBlock":
            arr.append({"t": "CodeBlock", "c": [["", [b.lang] if b.lang else [], []], b.text]})
        elif b.kind == "BulletList":
            arr.append({"t": "BulletList", "c": [[{"t": "Plain", "c": ast_inlines(x)}] for x in b.items]})
        elif b.kind == "OrderedList":
            arr.append({"t": "OrderedList", "c": [[b.start, {"t": "Decimal"}, {"t": "Period"}], [[{"t": "Plain", "c": ast_inlines(x)}] for x in b.items]]})
        elif b.kind == "BlockQuote":
            arr.append({"t": "BlockQuote", "c": ast_blocks(b.blocks)})
        elif b.kind == "HorizontalRule":
            arr.append({"t": "HorizontalRule"})
        elif b.kind == "RawBlock":
            arr.append({"t": "RawBlock", "c": ["html", b.text]})
    return arr


def meta_json(meta):
    res = {}
    for k, v in meta.items():
        res[k] = {"t": "MetaInlines", "c": ast_inlines(str(v))}
    return res


def native_inline(s):
    chunks = []
    for t in ast_inlines(s):
        if t["t"] == "Str":
            chunks.append('Str "' + t["c"].replace('"', '\\"') + '"')
        elif t["t"] == "Space":
            chunks.append("Space")
        elif t["t"] == "Emph":
            chunks.append("Emph [ " + native_inline_from_ast(t["c"]) + " ]")
        elif t["t"] == "Strong":
            chunks.append("Strong [ " + native_inline_from_ast(t["c"]) + " ]")
        elif t["t"] == "Link":
            chunks.append('Link ( "" , [] , [] ) [ ' + native_inline_from_ast(t["c"][1]) + f' ] ( "{t["c"][2][0]}" , "{t["c"][2][1]}" )')
        elif t["t"] == "Code":
            chunks.append('Code ( "" , [] , [] ) "' + t["c"][1].replace('"', '\\"') + '"')
    return " , ".join(chunks)


def native_inline_from_ast(arr):
    vals = []
    for x in arr:
        if x["t"] == "Str":
            vals.append('Str "' + x["c"].replace('"', '\\"') + '"')
        elif x["t"] == "Space":
            vals.append("Space")
    return " , ".join(vals)


def write_native(blocks):
    parts = []
    for b in blocks:
        if b.kind == "Header":
            parts.append(f'Header {b.level} ( "{b.ident}" , [] , [] ) [ {native_inline(b.text)} ]')
        elif b.kind == "Para":
            parts.append("Para [ " + native_inline(b.text) + " ]")
        elif b.kind == "BulletList":
            items = " , ".join("[ Plain [ " + native_inline(x) + " ] ]" for x in b.items)
            parts.append("BulletList [ " + items + " ]")
        elif b.kind == "OrderedList":
            items = " , ".join("[ Plain [ " + native_inline(x) + " ] ]" for x in b.items)
            parts.append(f"OrderedList ( {b.start} , Decimal , Period ) [ " + items + " ]")
        elif b.kind == "BlockQuote":
            parts.append("BlockQuote " + write_native(b.blocks).strip())
        elif b.kind == "CodeBlock":
            parts.append('CodeBlock ( "" , ' + (f'["{b.lang}"]' if b.lang else "[]") + ' , [] ) "' + b.text.replace('"', '\\"') + '"')
    return "[ " + "\n, ".join(parts) + "\n]\n"


def html_to_text(text):
    text = re.sub(r"(?is)<(script|style).*?</\1>", "", text)
    text = re.sub(r"(?i)<br\s*/?>", "\n", text)
    text = re.sub(r"(?i)</(p|div|h[1-6]|li|blockquote|tr)>", "\n\n", text)
    text = re.sub(r"(?i)<li[^>]*>", "- ", text)
    text = re.sub(r"<[^>]+>", "", text)
    return html.unescape(text)


def infer_format(path, default):
    if not path:
        return default
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    return {
        "md": "markdown",
        "markdown": "markdown",
        "html": "html",
        "htm": "html",
        "txt": "plain",
        "tex": "latex",
        "json": "json",
        "rst": "rst",
        "adoc": "asciidoc",
        "org": "org",
    }.get(ext, default)


def parse_args(argv):
    opts = {"from": None, "to": None, "output": None, "standalone": False, "metadata": {}, "variables": {}, "files": []}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-v", "--version"):
            opts["version"] = True
        elif a in ("-f", "-r", "--from", "--read"):
            i += 1; opts["from"] = argv[i]
        elif a.startswith("--from=") or a.startswith("--read="):
            opts["from"] = a.split("=", 1)[1]
        elif a in ("-t", "-w", "--to", "--write"):
            i += 1; opts["to"] = argv[i]
        elif a.startswith("--to=") or a.startswith("--write="):
            opts["to"] = a.split("=", 1)[1]
        elif a == "-o" or a == "--output":
            i += 1; opts["output"] = argv[i]
        elif a.startswith("--output="):
            opts["output"] = a.split("=", 1)[1]
        elif a == "-s" or a == "--standalone" or a.startswith("-s") or a.startswith("--standalone="):
            val = a.split("=", 1)[1] if "=" in a else (a[2:] if a.startswith("-s") and len(a) > 2 else "true")
            opts["standalone"] = val.lower() != "false"
        elif a in ("-M", "--metadata"):
            i += 1; set_keyval(opts["metadata"], argv[i])
        elif a.startswith("--metadata="):
            set_keyval(opts["metadata"], a.split("=", 1)[1])
        elif a in ("-V", "--variable"):
            i += 1; set_keyval(opts["variables"], argv[i])
        elif a.startswith("--variable="):
            set_keyval(opts["variables"], a.split("=", 1)[1])
        elif a in ("--list-input-formats", "--list-output-formats", "--list-highlight-styles", "--list-highlight-languages", "--bash-completion"):
            opts[a[2:]] = True
        elif a.startswith("--list-extensions"):
            opts["list-extensions"] = True
        elif a in ("-D", "--print-default-template"):
            i += 1; opts["print-default-template"] = argv[i]
        elif a.startswith("--print-default-template="):
            opts["print-default-template"] = a.split("=", 1)[1]
        elif a.startswith("--print-default-data-file="):
            opts["print-default-data-file"] = a.split("=", 1)[1]
        elif a in ("--dump-args", "--ignore-args"):
            opts[a[2:]] = True
        elif a.startswith("-") and a not in ("-",):
            if a in ("--toc", "--table-of-contents", "--number-sections", "-N", "--mathjax", "--mathml", "--citeproc", "-C", "--no-highlight", "--verbose", "--quiet"):
                pass
            elif "=" in a or a in ("--wrap", "--columns", "--toc-depth", "--css", "-c", "-H", "-B", "-A", "--template"):
                if "=" not in a and i + 1 < len(argv):
                    i += 1
            else:
                pass
        else:
            opts["files"].append(a)
        i += 1
    return opts


def set_keyval(d, s):
    if ":" in s:
        k, v = s.split(":", 1)
    elif "=" in s:
        k, v = s.split("=", 1)
    else:
        k, v = s, "true"
    d[k] = v


def read_inputs(files):
    if not files:
        return sys.stdin.read()
    chunks = []
    for f in files:
        if f == "-":
            chunks.append(sys.stdin.read())
        else:
            with open(f, "r", encoding="utf-8", errors="replace") as fh:
                chunks.append(fh.read())
    return "\n".join(chunks)


def convert(text, frm, to, standalone=False, meta_extra=None, variables=None):
    meta_extra = meta_extra or {}
    variables = variables or {}
    base_to = (to or "html").split("+", 1)[0].split("-", 1)[0]
    base_from = (frm or "markdown").split("+", 1)[0].split("-", 1)[0]
    if base_from in ("html", "html4", "html5"):
        text = html_to_text(text)
    if base_from == "json":
        try:
            doc = json.loads(text)
            return json.dumps(doc, separators=(",", ":")) + "\n" if base_to == "json" else json_to_plain(doc)
        except Exception:
            pass
    meta, blocks = parse_blocks(text)
    meta.update(meta_extra)
    title = variables.get("title") or meta.get("title")
    if base_to in ("html", "html4", "html5", "chunkedhtml", "dzslides", "revealjs", "s5", "slideous", "slidy"):
        return write_html(blocks, meta, standalone, title)
    if base_to in ("plain", "ansi"):
        return write_plain(blocks)
    if base_to in ("markdown", "markdown_strict", "markdown_mmd", "markdown_phpextra", "markdown_github", "gfm", "commonmark", "commonmark_x"):
        return write_markdown(blocks, base_to)
    if base_to in ("latex", "beamer", "context", "pdf"):
        return write_latex(blocks, standalone, meta)
    if base_to == "json":
        return json.dumps({"pandoc-api-version": [1, 23, 1, 1], "meta": meta_json(meta), "blocks": ast_blocks(blocks)}, separators=(",", ":")) + "\n"
    if base_to == "native":
        return write_native(blocks)
    if base_to == "rst":
        return write_rst(blocks)
    if base_to == "org":
        return write_org(blocks)
    if base_to in ("asciidoc", "asciidoctor", "asciidoc_legacy"):
        return write_asciidoc(blocks)
    if base_to in ("docbook", "docbook4", "docbook5", "xml", "tei", "jats", "jats_archiving", "jats_articleauthoring", "jats_publishing", "opendocument"):
        return "<article>\n" + write_html(blocks, meta, False) + "</article>\n"
    if base_to in ("rtf",):
        return "{\\rtf1\\ansi\n" + write_plain(blocks).replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}") + "}\n"
    return write_plain(blocks)


def json_to_plain(doc):
    vals = []
    for b in doc.get("blocks", []):
        if b.get("t") in ("Para", "Plain"):
            vals.append(ast_plain_inlines(b.get("c", [])))
        elif b.get("t") == "Header":
            vals.append(ast_plain_inlines(b.get("c", [None, None, []])[2]))
    return "\n\n".join(vals) + ("\n" if vals else "")


def ast_plain_inlines(arr):
    out = []
    for x in arr:
        t = x.get("t")
        if t == "Str":
            out.append(x.get("c", ""))
        elif t == "Space":
            out.append(" ")
        elif t in ("Emph", "Strong"):
            out.append(ast_plain_inlines(x.get("c", [])))
        elif t == "Link":
            out.append(ast_plain_inlines(x.get("c", [None, [], None])[1]))
    return "".join(out)


def main(argv):
    opts = parse_args(argv)
    if opts.get("help"):
        sys.stdout.write(usage())
        return 0
    if opts.get("version"):
        sys.stdout.write(version())
        return 0
    if opts.get("list-input-formats"):
        sys.stdout.write("\n".join(INPUT_FORMATS) + "\n"); return 0
    if opts.get("list-output-formats"):
        sys.stdout.write("\n".join(OUTPUT_FORMATS) + "\n"); return 0
    if opts.get("list-extensions"):
        sys.stdout.write("\n".join(EXTENSIONS) + "\n"); return 0
    if opts.get("list-highlight-styles"):
        sys.stdout.write("\n".join(HIGHLIGHT_STYLES) + "\n"); return 0
    if opts.get("list-highlight-languages"):
        sys.stdout.write("\n".join(HIGHLIGHT_LANGS) + "\n"); return 0
    if "print-default-template" in opts:
        fmt = opts["print-default-template"]
        if fmt.startswith("html"):
            sys.stdout.write("$for(header-includes)$\n$header-includes$\n$endfor$\n$body$\n")
        else:
            sys.stdout.write("$body$\n")
        return 0
    if "print-default-data-file" in opts:
        return 1
    if opts.get("dump-args"):
        sys.stdout.write("\n".join(opts["files"]) + "\n")
        return 0
    if opts.get("ignore-args"):
        return 0
    outfmt = opts["to"] or infer_format(opts["output"], "html")
    infmt = opts["from"] or (infer_format(opts["files"][0], "markdown") if opts["files"] else "markdown")
    try:
        text = read_inputs(opts["files"])
        out = convert(text, infmt, outfmt, opts["standalone"], opts["metadata"], opts["variables"])
        if opts["output"]:
            mode = "w"
            with open(opts["output"], mode, encoding="utf-8") as fh:
                fh.write(out)
        else:
            sys.stdout.write(out)
        return 0
    except BrokenPipeError:
        return 0
    except Exception as e:
        sys.stderr.write("executable: " + str(e) + "\n")
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
