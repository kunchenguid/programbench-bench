module reimpl-gocritic

go 1.20
