package main

import (
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
)

const version = "v0.0.0-SNAPSHOT"

var checkerTags = []struct {
	name string
	tags string
}{
	{"appendAssign", "diagnostic"}, {"appendCombine", "performance"}, {"argOrder", "diagnostic"},
	{"assignOp", "style"}, {"badCall", "diagnostic"}, {"badCond", "diagnostic"},
	{"badLock", "diagnostic experimental"}, {"badRegexp", "diagnostic experimental"},
	{"badSorting", "diagnostic experimental"}, {"badSyncOnceFunc", "diagnostic experimental"},
	{"boolExprSimplify", "style experimental"}, {"builtinShadow", "style opinionated"},
	{"builtinShadowDecl", "diagnostic experimental"}, {"captLocal", "style"},
	{"caseOrder", "diagnostic"}, {"codegenComment", "diagnostic"}, {"commentFormatting", "style"},
	{"commentedOutCode", "diagnostic experimental"}, {"commentedOutImport", "style experimental"},
	{"defaultCaseOrder", "style"}, {"deferInLoop", "diagnostic experimental"},
	{"deferUnlambda", "style experimental"}, {"deprecatedComment", "diagnostic"},
	{"docStub", "style experimental"}, {"dupArg", "diagnostic"}, {"dupBranchBody", "diagnostic"},
	{"dupCase", "diagnostic"}, {"dupImport", "style experimental"}, {"dupOption", "diagnostic experimental"},
	{"dupSubExpr", "diagnostic"}, {"dynamicFmtString", "diagnostic experimental"}, {"elseif", "style"},
	{"emptyDecl", "diagnostic experimental"}, {"emptyFallthrough", "style experimental"},
	{"emptyStringTest", "style experimental"}, {"equalFold", "performance experimental"},
	{"evalOrder", "diagnostic experimental"}, {"exitAfterDefer", "diagnostic"},
	{"exposedSyncMutex", "style experimental"}, {"externalErrorReassign", "diagnostic experimental"},
	{"filepathJoin", "diagnostic experimental"}, {"flagDeref", "diagnostic"}, {"flagName", "diagnostic"},
	{"hexLiteral", "style experimental"}, {"httpNoBody", "style experimental"}, {"hugeParam", "performance"},
	{"ifElseChain", "style"}, {"importShadow", "style opinionated"}, {"indexAlloc", "performance"},
	{"initClause", "style opinionated experimental"}, {"mapKey", "diagnostic"},
	{"methodExprCall", "style experimental"}, {"nestingReduce", "style opinionated experimental"},
	{"newDeref", "style"}, {"nilValReturn", "diagnostic experimental"},
	{"octalLiteral", "style experimental opinionated"}, {"offBy1", "diagnostic"},
	{"paramTypeCombine", "style opinionated"}, {"preferDecodeRune", "performance experimental"},
	{"preferFilepathJoin", "style experimental"}, {"preferFprint", "performance experimental"},
	{"preferStringWriter", "performance experimental"}, {"preferWriteByte", "performance experimental opinionated"},
	{"ptrToRefParam", "style opinionated experimental"}, {"rangeAppendAll", "diagnostic experimental"},
	{"rangeExprCopy", "performance"}, {"rangeValCopy", "performance"}, {"redundantSprint", "style experimental"},
	{"regexpMust", "style"}, {"regexpPattern", "diagnostic experimental"},
	{"regexpSimplify", "style experimental opinionated"}, {"returnAfterHttpError", "diagnostic experimental"},
	{"ruleguard", "style experimental"}, {"singleCaseSwitch", "style"}, {"sliceClear", "performance experimental"},
	{"sloppyLen", "diagnostic"}, {"sloppyReassign", "diagnostic experimental"},
	{"sloppyTypeAssert", "diagnostic"}, {"sortSlice", "diagnostic experimental"},
	{"sprintfQuotedString", "diagnostic experimental"}, {"sqlQuery", "diagnostic experimental"},
	{"stringConcatSimplify", "style experimental"}, {"stringXbytes", "performance"},
	{"stringsCompare", "style experimental"}, {"switchTrue", "style"},
	{"syncMapLoadAndDelete", "diagnostic experimental"}, {"timeExprSimplify", "style experimental"},
	{"todoCommentWithoutDetail", "style opinionated experimental"},
	{"tooManyResultsChecker", "style opinionated experimental"}, {"truncateCmp", "diagnostic experimental"},
	{"typeAssertChain", "style experimental"}, {"typeDefFirst", "style experimental"},
	{"typeSwitchVar", "style"}, {"typeUnparen", "style opinionated"},
	{"uncheckedInlineErr", "diagnostic experimental"}, {"underef", "style"},
	{"unlabelStmt", "style experimental"}, {"unlambda", "style"},
	{"unnamedResult", "style opinionated experimental"}, {"unnecessaryBlock", "style opinionated experimental"},
	{"unnecessaryDefer", "diagnostic experimental"}, {"unslice", "style"}, {"valSwap", "style"},
	{"weakCond", "diagnostic experimental"}, {"whyNoLint", "style experimental"},
	{"wrapperFunc", "style"}, {"yodaStyleExpr", "style experimental"}, {"zeroByteRepeat", "performance"},
}

var defaultEnabled = []string{"appendAssign", "argOrder", "assignOp", "badCall", "badCond", "captLocal", "caseOrder", "codegenComment", "commentFormatting", "defaultCaseOrder", "deprecatedComment", "dupArg", "dupBranchBody", "dupCase", "dupSubExpr", "elseif", "exitAfterDefer", "flagDeref", "flagName", "ifElseChain", "mapKey", "newDeref", "offBy1", "regexpMust", "singleCaseSwitch", "sloppyLen", "sloppyTypeAssert", "switchTrue", "typeSwitchVar", "underef", "unlambda", "unslice", "valSwap", "wrapperFunc"}

type diag struct {
	pos     token.Position
	checker string
	msg     string
}

func main() {
	args := os.Args[1:]
	if len(args) == 0 {
		fmt.Println("no args provided")
		return
	}
	switch args[0] {
	case "help":
		printHelp()
	case "version":
		fmt.Printf("go-critic version: %s\n", version)
	case "doc":
		doc(args[1:])
	case "check":
		os.Exit(check(args[1:]))
	default:
		if strings.HasPrefix(args[0], "-") {
			fmt.Printf("%q unknown command, did you mean \"help\"?\nRun \"go-critic help\" for usage.\n\nno such command %q\n", args[0], args[0])
		} else {
			fmt.Printf("%q unknown command\nRun \"go-critic help\" for usage.\n\nno such command %q\n", args[0], args[0])
		}
	}
}

func printHelp() {
	fmt.Printf(`Usage:

    go-critic <command> [arguments...]

The commands are:

    check             run linter over specified targets
    doc               get installed checkers documentation
    help              shows help message
    version           shows version of the application

Version: %s

`, version)
}

func doc(args []string) {
	if len(args) == 0 {
		for _, x := range checkerTags {
			fmt.Printf("%s [%s]\n", x.name, x.tags)
		}
		return
	}
	name := args[0]
	for _, x := range checkerTags {
		if x.name == name {
			fmt.Printf("%s checker documentation\nURL: https://github.com/go-critic/go-critic/checkers\nTags: [%s]\n\n", name, strings.ReplaceAll(x.tags, " ", " "))
			switch name {
			case "elseif":
				fmt.Print("Detects else with nested if statement that can be replaced with else-if.\n\nChecker parameters:\n  -@elseif.skipBalanced bool\n    \twhether to skip balanced if-else pairs (default true)\n")
			case "assignOp":
				fmt.Print("Detects assignments that can be simplified by using assignment operators.\n")
			case "unslice":
				fmt.Print("Detects expressions like s[:] that can be simplified to s.\n")
			case "regexpMust":
				fmt.Print("Detects regexp.Compile calls with constant patterns that can use regexp.MustCompile.\n")
			default:
				fmt.Printf("%s checker.\n", name)
			}
			return
		}
	}
	fmt.Printf("checker with name %q not found\n", name)
	os.Exit(1)
}

func check(args []string) int {
	fs := flag.NewFlagSet("go-critic", flag.ContinueOnError)
	fs.SetOutput(os.Stdout)
	enable := fs.String("enable", strings.Join(defaultEnabled, ","), "comma-separated list of enabled checkers. Can include #tags")
	disable := fs.String("disable", "", "comma-separated list of checkers to be disabled. Can include #tags")
	enableAll := fs.Bool("enableAll", false, "identical to -enable with all checkers listed. If true, -enable is ignored")
	exitCode := fs.Int("exitCode", 1, "exit code to be used when lint issues are found")
	_ = fs.Bool("checkGenerated", false, "whether to check generated files")
	_ = fs.Bool("checkTests", true, "whether to check test files")
	_ = fs.Int("concurrency", 12, "how many concurrent checkers to run (default is runtime.GOMAXPROCS(0))")
	_ = fs.String("cpuprofile", "", "write CPU profile to the specified file")
	_ = fs.String("go", "", "select the Go version to target. Leave as string for the latest")
	_ = fs.String("memprofile", "", "write memory profile to the specified file")
	_ = fs.Bool("shorterErrLocation", true, "whether to replace error location prefix with $GOROOT and $GOPATH")
	_ = fs.Bool("v", false, "whether to print output useful during linter debugging")
	addCheckerParamFlags(fs)
	if err := fs.Parse(args); err != nil {
		fmt.Printf("parse args: %v\n", err)
		return 1
	}
	targets := fs.Args()
	if len(targets) == 0 {
		fmt.Println("check: no targets specified")
		return 1
	}
	enabled := selectCheckers(*enable, *disable, *enableAll)
	if len(enabled) == 0 {
		fmt.Println("init checkers: empty checkers set selected")
		return 1
	}
	files := collectFiles(targets)
	var all []diag
	for _, f := range files {
		all = append(all, lintFile(f, enabled)...)
	}
	sort.SliceStable(all, func(i, j int) bool {
		a, b := all[i].pos, all[j].pos
		if a.Filename != b.Filename {
			return a.Filename < b.Filename
		}
		if a.Line != b.Line {
			return a.Line < b.Line
		}
		if a.Column != b.Column {
			return a.Column < b.Column
		}
		return all[i].checker < all[j].checker
	})
	for _, d := range all {
		fmt.Printf("%s:%d:%d: %s: %s\n", displayPath(d.pos.Filename), d.pos.Line, d.pos.Column, d.checker, d.msg)
	}
	if len(all) != 0 {
		return *exitCode
	}
	return 0
}

func addCheckerParamFlags(fs *flag.FlagSet) {
	_ = fs.Bool("@captLocal.paramsOnly", true, "whether to restrict checker to params only")
	_ = fs.Int("@commentedOutCode.minLength", 15, "min length of the comment that triggers a warning")
	_ = fs.Bool("@elseif.skipBalanced", true, "whether to skip balanced if-else pairs")
	_ = fs.Int("@hugeParam.sizeThreshold", 80, "size in bytes that makes the warning trigger")
	_ = fs.Int("@ifElseChain.minThreshold", 2, "min number of if-else blocks that makes the warning trigger")
	_ = fs.Int("@nestingReduce.bodyWidth", 5, "min number of statements inside a branch to trigger a warning")
	_ = fs.Int("@rangeExprCopy.sizeThreshold", 512, "size in bytes that makes the warning trigger")
	_ = fs.Bool("@rangeExprCopy.skipTestFuncs", true, "whether to check test functions")
	_ = fs.Int("@rangeValCopy.sizeThreshold", 128, "size in bytes that makes the warning trigger")
	_ = fs.Bool("@rangeValCopy.skipTestFuncs", true, "whether to check test functions")
	_ = fs.String("@ruleguard.debug", "", "enable debug for the specified named rules group")
	_ = fs.String("@ruleguard.disable", "", "comma-separated list of disabled groups or skip empty to enable everything")
	_ = fs.String("@ruleguard.enable", "<all>", "comma-separated list of enabled groups or skip empty to enable everything")
	_ = fs.String("@ruleguard.failOn", "", "Determines the behavior when an error occurs while parsing ruleguard files.")
	_ = fs.Bool("@ruleguard.failOnError", false, "deprecated, use failOn param")
	_ = fs.String("@ruleguard.rules", "", "comma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified")
	_ = fs.Int("@tooManyResultsChecker.maxResults", 5, "maximum number of results")
	_ = fs.Bool("@truncateCmp.skipArchDependent", true, "whether to skip int/uint/uintptr types")
	_ = fs.Bool("@underef.skipRecvDeref", true, "whether to skip (*x).method() calls where x is a pointer receiver")
	_ = fs.Bool("@unnamedResult.checkExported", false, "whether to check exported functions")
}

func selectCheckers(enable, disable string, all bool) map[string]bool {
	out := map[string]bool{}
	known := map[string]bool{}
	for _, x := range checkerTags {
		known[x.name] = true
	}
	if all {
		for _, x := range checkerTags {
			out[x.name] = true
		}
	} else {
		for _, n := range expandList(enable) {
			if known[n] {
				out[n] = true
			}
		}
	}
	for _, n := range expandList(disable) {
		delete(out, n)
	}
	return out
}

func expandList(s string) []string {
	var out []string
	for _, part := range strings.Split(s, ",") {
		part = strings.TrimSpace(part)
		if part == "" {
			continue
		}
		if strings.HasPrefix(part, "#") {
			tag := strings.TrimPrefix(part, "#")
			for _, x := range checkerTags {
				for _, t := range strings.Fields(x.tags) {
					if t == tag {
						out = append(out, x.name)
					}
				}
			}
			continue
		}
		out = append(out, part)
	}
	return out
}

func collectFiles(targets []string) []string {
	var files []string
	for _, t := range targets {
		if strings.HasSuffix(t, "/...") {
			root := strings.TrimSuffix(t, "/...")
			if root == "" {
				root = "."
			}
			filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
				if err != nil || d.IsDir() && strings.HasPrefix(d.Name(), ".") && path != root {
					if d != nil && d.IsDir() {
						return filepath.SkipDir
					}
					return nil
				}
				if !d.IsDir() && strings.HasSuffix(path, ".go") {
					files = append(files, path)
				}
				return nil
			})
			continue
		}
		info, err := os.Stat(t)
		if err != nil {
			continue
		}
		if info.IsDir() {
			ents, _ := os.ReadDir(t)
			for _, e := range ents {
				if !e.IsDir() && strings.HasSuffix(e.Name(), ".go") {
					files = append(files, filepath.Join(t, e.Name()))
				}
			}
		} else if strings.HasSuffix(t, ".go") {
			files = append(files, t)
		}
	}
	sort.Strings(files)
	return files
}

func lintFile(path string, enabled map[string]bool) []diag {
	fset := token.NewFileSet()
	f, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
	if err != nil {
		pos := fset.Position(token.NoPos)
		pos.Filename = path
		return []diag{{pos: pos, checker: "parse", msg: err.Error()}}
	}
	var out []diag
	add := func(pos token.Pos, checker, msg string) {
		if enabled[checker] {
			out = append(out, diag{pos: fset.Position(pos), checker: checker, msg: msg})
		}
	}
	for _, cg := range f.Comments {
		for _, c := range cg.List {
			txt := strings.TrimSpace(strings.TrimPrefix(strings.TrimPrefix(c.Text, "//"), "/*"))
			if enabled["commentFormatting"] && strings.HasPrefix(c.Text, "//") && len(txt) > 0 && txt[0] >= 'a' && txt[0] <= 'z' {
				add(c.Pos(), "commentFormatting", "put a space between `//` and comment text")
			}
			if enabled["deprecatedComment"] && strings.HasPrefix(txt, "Deprecated:") == false && strings.Contains(strings.ToLower(txt), "deprecated") {
				add(c.Pos(), "deprecatedComment", "deprecated comment should be formatted as \"Deprecated: ...\"")
			}
		}
	}
	ast.Inspect(f, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.AssignStmt:
			checkAssign(fset, add, x)
		case *ast.IfStmt:
			if b, ok := x.Else.(*ast.BlockStmt); ok && len(b.List) == 1 {
				if _, ok := b.List[0].(*ast.IfStmt); ok {
					add(b.Pos(), "elseif", "can replace 'else {if cond {}}' with 'else if cond {}'")
				}
			}
		case *ast.SwitchStmt:
			if len(x.Body.List) == 1 {
				add(x.Switch, "singleCaseSwitch", "should rewrite switch statement to if statement")
			}
			if id, ok := x.Tag.(*ast.Ident); ok && id.Name == "true" {
				add(x.Switch, "switchTrue", "replace 'switch true {}' with 'switch {}'")
			}
			seen := map[string]token.Pos{}
			for _, st := range x.Body.List {
				cc := st.(*ast.CaseClause)
				for _, e := range cc.List {
					s := exprString(fset, e)
					if p, ok := seen[s]; ok {
						add(p, "dupCase", "duplicate case in switch")
					} else {
						seen[s] = e.Pos()
					}
				}
			}
		case *ast.CallExpr:
			checkCall(fset, add, x)
		case *ast.SliceExpr:
			if x.Low == nil && x.High == nil && x.Max == nil {
				add(x.Pos(), "unslice", fmt.Sprintf("could simplify %s[:] to %s", exprString(fset, x.X), exprString(fset, x.X)))
			}
		case *ast.UnaryExpr:
			if x.Op == token.MUL {
				if c, ok := x.X.(*ast.CallExpr); ok {
					if id, ok := c.Fun.(*ast.Ident); ok && id.Name == "new" {
						add(x.Pos(), "newDeref", "replace `*new(T)` with `T{}`")
					}
				}
			}
		case *ast.BinaryExpr:
			checkBinary(fset, add, x)
		case *ast.TypeSwitchStmt:
			if as, ok := x.Assign.(*ast.AssignStmt); ok && len(as.Lhs) == 1 {
				if id, ok := as.Lhs[0].(*ast.Ident); ok && id.Name == "_" {
					add(as.Pos(), "typeSwitchVar", "assigning the variable in type switch makes it more useful")
				}
			}
		}
		return true
	})
	return out
}

func checkAssign(fset *token.FileSet, add func(token.Pos, string, string), x *ast.AssignStmt) {
	if len(x.Lhs) == 2 && len(x.Rhs) == 2 && exprString(fset, x.Lhs[0]) == exprString(fset, x.Rhs[1]) && exprString(fset, x.Lhs[1]) == exprString(fset, x.Rhs[0]) {
		add(x.Pos(), "valSwap", "replace 3-way assignment with swap")
	}
	if x.Tok != token.ASSIGN || len(x.Lhs) != 1 || len(x.Rhs) != 1 {
		return
	}
	lhs := exprString(fset, x.Lhs[0])
	if b, ok := x.Rhs[0].(*ast.BinaryExpr); ok {
		left, right := exprString(fset, b.X), exprString(fset, b.Y)
		if lhs == left {
			if b.Op == token.ADD && right == "1" {
				add(x.Pos(), "assignOp", fmt.Sprintf("replace `%s = %s + 1` with `%s++`", lhs, lhs, lhs))
			} else {
				add(x.Pos(), "assignOp", fmt.Sprintf("replace `%s = %s %s %s` with `%s %s= %s`", lhs, lhs, b.Op.String(), right, lhs, b.Op.String(), right))
			}
		} else if lhs == right && (b.Op == token.ADD || b.Op == token.MUL || b.Op == token.AND || b.Op == token.OR || b.Op == token.XOR) {
			add(x.Pos(), "assignOp", fmt.Sprintf("replace `%s = %s %s %s` with `%s %s= %s`", lhs, left, b.Op.String(), lhs, lhs, b.Op.String(), left))
		}
	}
}

func checkCall(fset *token.FileSet, add func(token.Pos, string, string), x *ast.CallExpr) {
	if sel, ok := x.Fun.(*ast.SelectorExpr); ok {
		pkg := exprString(fset, sel.X)
		if pkg == "regexp" && sel.Sel.Name == "Compile" && len(x.Args) > 0 {
			if _, ok := x.Args[0].(*ast.BasicLit); ok {
				add(x.Pos(), "regexpMust", fmt.Sprintf("for const patterns like %s, use regexp.MustCompile", exprString(fset, x.Args[0])))
			}
		}
		if pkg == "strings" && sel.Sel.Name == "Compare" {
			add(x.Pos(), "stringsCompare", "should use strings.Compare only when required")
		}
		if pkg == "fmt" && (sel.Sel.Name == "Sprint" || sel.Sel.Name == "Sprintf") && len(x.Args) == 1 {
			add(x.Pos(), "redundantSprint", "redundant fmt.Sprint call")
		}
	}
	if id, ok := x.Fun.(*ast.Ident); ok && id.Name == "append" && len(x.Args) >= 2 {
		a0 := exprString(fset, x.Args[0])
		for _, arg := range x.Args[1:] {
			if se, ok := arg.(*ast.SliceExpr); ok && exprString(fset, se.X) == a0 && se.Low == nil && se.High == nil {
				add(x.Pos(), "appendAssign", "append result not assigned to the same slice")
			}
		}
		return
	}
	seen := map[string]token.Pos{}
	for _, a := range x.Args {
		s := exprString(fset, a)
		if p, ok := seen[s]; ok && s != "_" && s != "nil" {
			add(p, "dupArg", "suspicious duplicated argument")
			break
		}
		seen[s] = a.Pos()
	}
}

func checkBinary(fset *token.FileSet, add func(token.Pos, string, string), x *ast.BinaryExpr) {
	l, r := exprString(fset, x.X), exprString(fset, x.Y)
	if l == r && (x.Op == token.EQL || x.Op == token.NEQ || x.Op == token.LAND || x.Op == token.LOR) {
		add(x.Pos(), "dupSubExpr", "suspicious duplicated expression")
	}
	if call, ok := x.X.(*ast.CallExpr); ok && isLenCall(fset, call) {
		if lit, ok := x.Y.(*ast.BasicLit); ok && lit.Value == "0" && (x.Op == token.EQL || x.Op == token.NEQ) {
			add(x.Pos(), "sloppyLen", "should use len() comparison with 0 carefully")
		}
	}
	if call, ok := x.Y.(*ast.CallExpr); ok && isLenCall(fset, call) {
		if lit, ok := x.X.(*ast.BasicLit); ok && lit.Value == "0" && (x.Op == token.EQL || x.Op == token.NEQ) {
			add(x.Pos(), "sloppyLen", "should use len() comparison with 0 carefully")
		}
	}
}

func isLenCall(fset *token.FileSet, c *ast.CallExpr) bool {
	id, ok := c.Fun.(*ast.Ident)
	return ok && id.Name == "len" && len(c.Args) == 1 && fset != nil
}

func exprString(fset *token.FileSet, e ast.Expr) string {
	var b strings.Builder
	if err := format.Node(&b, fset, e); err != nil {
		return ""
	}
	return b.String()
}

func displayPath(p string) string {
	wd, _ := os.Getwd()
	if abs, err := filepath.Abs(p); err == nil {
		if rel, err := filepath.Rel(wd, abs); err == nil && !strings.HasPrefix(rel, "..") {
			return "./" + filepath.ToSlash(rel)
		}
	}
	if n, err := strconv.Unquote(strconv.Quote(p)); err == nil {
		return n
	}
	return p
}
