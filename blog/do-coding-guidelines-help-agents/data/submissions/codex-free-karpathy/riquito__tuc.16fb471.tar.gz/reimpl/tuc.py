#!/usr/bin/env python3
import sys, re, json, os
from dataclasses import dataclass

VERSION = "tuc 1.3.0"
HELP = """tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\0), not LF (\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text [default: \t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text. Implies --join
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are left, right, both
        --fallback-oob <fallback> Generic fallback output for missing fields
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
"""

@dataclass
class Sel:
    kind: str
    a: int | None
    b: int | None
    fallback: str | None = None

class TucError(Exception): pass
class ParseError(Exception): pass

def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)

def parse_int(s, raw):
    try:
        v = int(s)
    except ValueError:
        raise ParseError(f"failed to parse '{raw}': Field format error")
    if v == 0:
        raise ParseError(f"failed to parse '{raw}': Zero is not a valid field")
    return v

def has_format(spec):
    i = 0
    while i < len(spec):
        if spec[i] == '{':
            if i + 1 < len(spec) and spec[i+1] == '{':
                i += 2; continue
            return True
        i += 1
    return False

def parse_selections(spec):
    sels = []
    for raw in spec.split(','):
        if raw == '':
            raise ParseError(f"failed to parse '{raw}': Field format error")
        part, fb = (raw.split('=', 1) + [None])[:2] if '=' in raw else (raw, None)
        if ':' in part:
            if part.count(':') != 1:
                raise ParseError(f"failed to parse '{raw}': Field format error")
            left, right = part.split(':')
            if left == '' and right == '':
                raise ParseError(f"failed to parse '{raw}': Field format error, no numbers next to `:`")
            a = parse_int(left, raw) if left else None
            b = parse_int(right, raw) if right else None
            if a is not None and b is not None and a > b:
                raise ParseError(f"failed to parse '{raw}': Field left value cannot be greater than right value")
            sels.append(Sel('range', a, b, fb))
        else:
            sels.append(Sel('single', parse_int(part, raw), None, fb))
    return sels

def resolve(v, n):
    return v if v > 0 else n + v + 1

def sel_range(sel, n):
    if sel.kind == 'single':
        i = resolve(sel.a, n); return i, i
    a = resolve(sel.a, n) if sel.a is not None else 1
    b = resolve(sel.b, n) if sel.b is not None else n
    return a, b

def spans_for(sels, n, fallback=None, complement=False):
    if complement:
        chosen = set()
        for sel in sels:
            a, b = sel_range(sel, n)
            for i in range(max(1, a), min(n, b) + 1): chosen.add(i)
        spans=[]; i=1
        while i <= n:
            if i in chosen:
                i += 1; continue
            start = i
            while i + 1 <= n and i + 1 not in chosen: i += 1
            spans.append((start, i, None)); i += 1
        return spans
    spans=[]
    for sel in sels:
        a, b = sel_range(sel, n)
        fb = sel.fallback if sel.fallback is not None else fallback
        if sel.kind == 'single':
            if a < 1 or a > n:
                if fb is None: raise TucError(f"Error: Out of bounds: {sel.a}")
                spans.append((a, a, fb))
            else: spans.append((a, a, None))
        else:
            if a < 1 or a > n:
                if fb is None: raise TucError(f"Error: Out of bounds: {sel.a if sel.a is not None else a}")
                spans.append((a, b, fb))
            else: spans.append((a, min(b, n), None))
    return spans

def trim_literal(s, d, mode):
    if not mode or d == '': return s
    m = mode.lower()
    if m.startswith('l') or m.startswith('b'):
        while s.startswith(d): s = s[len(d):]
    if m.startswith('r') or m.startswith('b'):
        while s.endswith(d): s = s[:-len(d)]
    return s

def compress_literal(s, d):
    return re.sub(re.escape(d) + '+', d, s) if d else s

def split_literal(s, d, greedy=False):
    if d == '': raise TucError("Error: The delimiter cannot be empty")
    fields=[]; delims=[]; i=0
    while True:
        j = s.find(d, i)
        if j < 0:
            fields.append(s[i:]); break
        fields.append(s[i:j])
        k = j + len(d)
        if greedy:
            while s.startswith(d, k): k += len(d)
        delims.append(s[j:k]); i = k
    return fields, delims

def split_regex(s, pat, greedy=False):
    ms = [m for m in re.finditer(pat, s) if m.end() > m.start()]
    fields=[]; delims=[]; pos=0; i=0
    while i < len(ms):
        start, end = ms[i].start(), ms[i].end()
        fields.append(s[pos:start])
        if greedy:
            i += 1
            while i < len(ms) and ms[i].start() == end:
                end = ms[i].end(); i += 1
        else:
            i += 1
        delims.append(s[start:end]); pos = end
    fields.append(s[pos:])
    return fields, delims

def chunk(fields, delims, a, b):
    if a == b: return fields[a-1]
    out = [fields[a-1]]
    for i in range(a-1, b-1): out += [delims[i], fields[i+1]]
    return ''.join(out)

def select_chunks(fields, delims, sels, opts):
    out=[]
    for a,b,fb in spans_for(sels, len(fields), opts.get('fallback_oob'), opts.get('complement')):
        out.append(fb if fb is not None else chunk(fields, delims, a, b))
    return out

def render_format(fmt, fields, delims, opts):
    out=[]; i=0
    while i < len(fmt):
        if fmt[i] == '{':
            if i+1 < len(fmt) and fmt[i+1] == '{': out.append('{'); i += 2; continue
            j = fmt.find('}', i+1)
            if j < 0: raise ParseError(f"failed to parse '{fmt}': Field format error")
            out.append(''.join(select_chunks(fields, delims, parse_selections(fmt[i+1:j]), opts)))
            i = j + 1
        elif fmt[i] == '}' and i+1 < len(fmt) and fmt[i+1] == '}':
            out.append('}'); i += 2
        else:
            out.append(fmt[i]); i += 1
    return ''.join(out)

def records(text, sep):
    out=[]; start=0
    while True:
        i = text.find(sep, start)
        if i < 0:
            if start < len(text): out.append((text[start:], sep))
            return out
        out.append((text[start:i], sep)); start = i + len(sep)

def process_fields(text, opts):
    sep = '\0' if opts['zero'] else '\n'
    fmt = has_format(opts['bounds'])
    sels = None if fmt else parse_selections(opts['bounds'])
    out=[]
    for rec, term in records(text, sep):
        s = rec; d = opts['delimiter']
        if opts.get('regex') is None:
            s = trim_literal(s, d, opts.get('trim'))
            if opts.get('compress'): s = compress_literal(s, d)
            fields, delims = split_literal(s, d, opts.get('greedy'))
        else:
            fields, delims = split_regex(s, opts['regex'], opts.get('greedy'))
        if opts.get('only_delimited') and not delims: continue
        if fmt:
            rendered = render_format(opts['bounds'], fields, delims, opts)
        else:
            chunks = select_chunks(fields, delims, sels, opts)
            if opts.get('json'):
                rendered = json.dumps(chunks, ensure_ascii=False, separators=(',', ':'))
            else:
                if opts.get('regex') is not None and opts.get('join') and opts.get('replace') is None:
                    raise TucError("tuc: runtime error. Cannot use --regex and --join without --replace-delimiter")
                joiner = opts['replace'] if opts.get('replace') is not None else (d if opts.get('join') else None)
                rendered = joiner.join(chunks) if joiner is not None else ''.join(chunks)
        out.append(rendered + term)
    return ''.join(out).encode('utf-8', 'surrogateescape')

def select_units(units, opts):
    sels = parse_selections(opts['bounds'])
    out=[]
    for a,b,fb in spans_for(sels, len(units), opts.get('fallback_oob'), opts.get('complement')):
        if fb is not None: out.append(fb)
        else: out.append(units[a-1:b])
    return out

def process_bytes(data, opts):
    units = [bytes([b]) for b in data]
    chunks = select_units(units, opts)
    chunks = [c if isinstance(c, str) else b''.join(c) for c in chunks]
    return b''.join(c.encode() if isinstance(c, str) else c for c in chunks)

def process_chars(data, opts):
    text = data.decode('utf-8', 'surrogateescape')
    sep = '\0' if opts['zero'] else '\n'
    sels = parse_selections(opts['bounds'])
    out=[]
    for rec, term in records(text, sep):
        units=list(rec)
        chunks=[]
        for a,b,fb in spans_for(sels, len(units), opts.get('fallback_oob'), opts.get('complement')):
            chunks.append(fb if fb is not None else ''.join(units[a-1:b]))
        if opts.get('json'):
            rendered = json.dumps(chunks, ensure_ascii=False, separators=(',', ':'))
        else:
            joiner = opts['replace'] if opts.get('replace') is not None else (opts['delimiter'] if opts.get('join') else '')
            rendered = joiner.join(chunks)
        out.append(rendered + term)
    return ''.join(out).encode('utf-8', 'surrogateescape')

def process_lines(data, opts):
    if opts.get('json'):
        raise TucError("tuc: runtime error. --json support is available only for --fields and --characters")
    text = data.decode('utf-8', 'surrogateescape')
    sep = '\0' if opts['zero'] else '\n'
    units=[r+t for r,t in records(text, sep) if r or t]
    chunks=[]
    for a,b,fb in spans_for(parse_selections(opts['bounds']), len(units), opts.get('fallback_oob'), opts.get('complement')):
        chunks.append(fb if fb is not None else ''.join(units[a-1:b]))
    return ''.join(chunks).encode('utf-8', 'surrogateescape')

def normalize_argv(argv):
    value_longs = {'--fields','--bytes','--characters','--lines','--delimiter','--regex','--replace-delimiter','--trim','--fallback-oob','--fixed-memory'}
    value_shorts = {'-f','-b','-c','-l','-d','-e','-r','-t','-M'}
    out=[]
    for a in argv:
        if a.startswith('--') and '=' in a:
            k, v = a.split('=', 1)
            if k in value_longs:
                out += [k, v]; continue
        if a.startswith('-') and not a.startswith('--') and len(a) > 2:
            k = a[:2]
            if k in value_shorts:
                out += [k, a[2:]]; continue
        out.append(a)
    return out

def parse_args(argv):
    argv = normalize_argv(argv)
    opts={'delimiter':'\t','bounds':'1:','mode':'fields','join':False,'replace':None,'zero':False,'greedy':False,'compress':False,'only_delimited':False,'complement':False,'json':False,'trim':None,'fallback_oob':None,'regex':None}
    files=[]; i=0
    while i < len(argv):
        a=argv[i]
        def need():
            nonlocal i
            if i+1 >= len(argv): die(f"the '{a}' option doesn't have an associated value")
            i += 1; return argv[i]
        if a in ('-h','--help'): print(HELP, end=''); sys.exit(0)
        elif a in ('-V','--version'): print(VERSION); sys.exit(0)
        elif a in ('-g','--greedy-delimiter'): opts['greedy']=True
        elif a in ('-p','--compress-delimiter'): opts['compress']=True
        elif a in ('-s','--only-delimited'): opts['only_delimited']=True
        elif a in ('-z','--zero-terminated'): opts['zero']=True
        elif a in ('-m','--complement'): opts['complement']=True
        elif a in ('-j','--join'): opts['join']=True
        elif a == '--no-join': opts['join']=False
        elif a == '--json': opts['json']=True
        elif a == '--no-mmap': pass
        elif a in ('-M','--fixed-memory'): need()
        elif a in ('-f','--fields'): opts['mode']='fields'; opts['bounds']=need()
        elif a in ('-b','--bytes'): opts['mode']='bytes'; opts['bounds']=need()
        elif a in ('-c','--characters'): opts['mode']='chars'; opts['bounds']=need()
        elif a in ('-l','--lines'): opts['mode']='lines'; opts['bounds']=need(); opts['join']=True
        elif a in ('-d','--delimiter'): opts['delimiter']=need()
        elif a in ('-e','--regex'): opts['regex']=need()
        elif a in ('-r','--replace-delimiter'): opts['replace']=need(); opts['join']=True
        elif a in ('-t','--trim'): opts['trim']=need()
        elif a == '--fallback-oob': opts['fallback_oob']=need()
        elif a.startswith('-') and len(a) > 1: die(f"tuc: unexpected arguments: [\"{a}\"]\nTry 'tuc --help' for more information.")
        else: files.append(a)
        i += 1
    if len(files) > 1: die(f"tuc: unexpected arguments: {files[1:]}")
    opts['file'] = files[0] if files else None
    return opts

def main():
    opts=parse_args(sys.argv[1:])
    try:
        if opts['file']:
            if not os.path.exists(opts['file']): raise TucError(f'tuc: runtime error. The file "{opts["file"]}" does not exist')
            data=open(opts['file'],'rb').read()
        else:
            data=sys.stdin.buffer.read()
        if opts['mode'] == 'bytes': out = process_bytes(data, opts)
        elif opts['mode'] == 'chars': out = process_chars(data, opts)
        elif opts['mode'] == 'lines': out = process_lines(data, opts)
        else: out = process_fields(data.decode('utf-8','surrogateescape'), opts)
        sys.stdout.buffer.write(out)
    except (TucError, ParseError) as e:
        die(str(e))
    except re.error as e:
        die(f"tuc: runtime error. {e}")

if __name__ == '__main__': main()
