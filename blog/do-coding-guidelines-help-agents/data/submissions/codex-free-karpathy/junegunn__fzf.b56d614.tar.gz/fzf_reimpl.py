#!/usr/bin/env python3
import os
import re
import shlex
import sys

VERSION = "0.68.0 (5676da4a)"

HELP = """fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
    --scheme=SCHEME          Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
    --with-nth=N[,..]        Transform the presentation of each line
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters
    --ansi                   Enable processing of ANSI color codes

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page
"""

SHELL_SNIPPETS = {
    "--bash": """### key-bindings.bash ###
# fzf shell integration
if [[ $- =~ i ]]; then
  __fzf_select__() { fzf "$@"; }
fi
""",
    "--zsh": """### key-bindings.zsh ###
# fzf shell integration
__fzf_select__() { fzf "$@"; }
""",
    "--fish": """### key-bindings.fish ###
# fzf shell integration
function __fzf_select__
    fzf $argv
end
""",
}


class Opts:
    def __init__(self):
        self.filter = None
        self.query = ""
        self.exact = False
        self.extended = True
        self.case = "smart"
        self.sort = True
        self.read0 = False
        self.print0 = False
        self.print_query = False
        self.expect = False
        self.nth = None
        self.with_nth = None
        self.accept_nth = None
        self.delimiter = None
        self.tac = False
        self.tail = None
        self.header_lines = 0


def die(msg):
    print(msg, file=sys.stderr)
    raise SystemExit(2)


def opt_value(args, i, name):
    if i + 1 >= len(args):
        if name == "--filter" or name == "-f":
            die("query string required")
        die(f"{name} option requires an argument")
    return args[i + 1], i + 1


VALUE_OPTS = {
    "--filter", "-f", "--query", "-q", "--nth", "-n", "--with-nth",
    "--accept-nth", "--delimiter", "-d", "--expect", "--scheme",
    "--tiebreak", "--height", "--min-height", "--tmux", "--layout",
    "--margin", "--padding", "--border", "--border-label",
    "--border-label-pos", "--multi", "-m", "--preview", "--preview-window",
    "--preview-border", "--preview-label", "--preview-label-pos", "--header",
    "--header-lines", "--footer", "--bind", "--color", "--style", "--tail",
    "--walker", "--walker-root", "--walker-skip", "--history",
    "--history-size", "--prompt", "--info", "--info-command", "--separator",
    "--ghost", "--pointer", "--marker", "--marker-multi-line", "--ellipsis",
    "--tabstop", "--scrollbar", "--gap", "--gap-line", "--gutter",
    "--gutter-raw", "--jump-labels", "--freeze-left", "--freeze-right",
    "--scroll-off", "--hscroll-off", "--list-border", "--list-label",
    "--list-label-pos", "--input-border", "--input-label",
    "--input-label-pos", "--header-border", "--header-label",
    "--header-label-pos", "--header-lines-border", "--footer-border",
    "--footer-label", "--footer-label-pos", "--with-shell", "--listen",
    "--algo",
}

FLAG_OPTS = {
    "--exact", "-e", "--no-extended", "+x", "--ignore-case", "-i",
    "--no-ignore-case", "+i", "--smart-case", "--no-sort", "+s",
    "--read0", "--print0", "--ansi", "--sync", "--disabled", "--literal",
    "--no-color", "--no-bold", "--select-1", "-1", "--exit-0", "-0",
    "--print-query", "--bash", "--zsh", "--fish", "--tac", "--no-multi",
    "--highlight-line", "--cycle", "--wrap", "--no-multi-line", "--raw",
    "--track", "--keep-right", "--no-hscroll", "--no-scrollbar",
    "--no-input", "--filepath-word", "--header-first", "--version", "--help",
    "--man", "--no-tty-default",
}


def split_default_opts():
    out = []
    path = os.environ.get("FZF_DEFAULT_OPTS_FILE")
    if path:
        try:
            with open(os.path.expanduser(path), "r", encoding="utf-8") as f:
                out += shlex.split(f.read(), comments=False, posix=True)
        except OSError:
            pass
    env = os.environ.get("FZF_DEFAULT_OPTS")
    if env:
        out += shlex.split(env, comments=False, posix=True)
    return out


def parse_args(argv):
    args = split_default_opts() + argv
    opts = Opts()
    passthrough_actions = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            break
        if a == "--version":
            print(VERSION)
            raise SystemExit(0)
        if a == "--help":
            print(HELP, end="")
            raise SystemExit(0)
        if a in SHELL_SNIPPETS:
            print(SHELL_SNIPPETS[a], end="")
            raise SystemExit(0)
        if a == "--man":
            print("This system has been minimized by removing packages and content that are")
            print("not required on a system that users do not log into.")
            raise SystemExit(0)
        if a in ("--filter", "-f"):
            v, i = opt_value(args, i, a)
            opts.filter = v
        elif a.startswith("--filter="):
            opts.filter = a.split("=", 1)[1]
        elif a in ("--query", "-q"):
            opts.query, i = opt_value(args, i, a)
        elif a.startswith("--query="):
            opts.query = a.split("=", 1)[1]
        elif a in ("--exact", "-e"):
            opts.exact = True
        elif a in ("+x", "--no-extended"):
            opts.extended = False
        elif a in ("--ignore-case", "-i"):
            opts.case = "ignore"
        elif a in ("+i", "--no-ignore-case"):
            opts.case = "respect"
        elif a == "--smart-case":
            opts.case = "smart"
        elif a in ("+s", "--no-sort"):
            opts.sort = False
        elif a == "--read0":
            opts.read0 = True
        elif a == "--print0":
            opts.print0 = True
        elif a == "--print-query":
            opts.print_query = True
        elif a == "--tac":
            opts.tac = True
        elif a in ("--nth", "-n"):
            opts.nth, i = opt_value(args, i, a)
        elif a.startswith("--nth="):
            opts.nth = a.split("=", 1)[1]
        elif a in ("--with-nth",):
            opts.with_nth, i = opt_value(args, i, a)
        elif a.startswith("--with-nth="):
            opts.with_nth = a.split("=", 1)[1]
        elif a == "--accept-nth":
            opts.accept_nth, i = opt_value(args, i, a)
        elif a.startswith("--accept-nth="):
            opts.accept_nth = a.split("=", 1)[1]
        elif a in ("--delimiter", "-d"):
            opts.delimiter, i = opt_value(args, i, a)
        elif a.startswith("--delimiter="):
            opts.delimiter = a.split("=", 1)[1]
        elif a == "--expect" or a.startswith("--expect="):
            if a == "--expect":
                _, i = opt_value(args, i, a)
            opts.expect = True
        elif a == "--tail" or a.startswith("--tail="):
            if a == "--tail":
                v, i = opt_value(args, i, a)
            else:
                v = a.split("=", 1)[1]
            try:
                opts.tail = int(v)
            except ValueError:
                pass
        elif a == "--header-lines" or a.startswith("--header-lines="):
            if a == "--header-lines":
                v, i = opt_value(args, i, a)
            else:
                v = a.split("=", 1)[1]
            try:
                opts.header_lines = max(0, int(v))
            except ValueError:
                opts.header_lines = 0
        elif a.startswith("--") and "=" in a and a.split("=", 1)[0] in VALUE_OPTS:
            pass
        elif a in VALUE_OPTS:
            _, i = opt_value(args, i, a)
        elif a in FLAG_OPTS:
            pass
        elif a.startswith("-") or a.startswith("+"):
            die(f"unknown option: {a}")
        else:
            passthrough_actions.append(a)
        i += 1
    return opts


def strip_ansi(s):
    return re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", s)


def split_items(data, read0):
    sep = "\0" if read0 else "\n"
    if data == "":
        return []
    parts = data.split(sep)
    if parts and parts[-1] == "":
        parts.pop()
    return parts


def fields(line, delim):
    if delim is None:
        return re.findall(r"\S+", line), " "
    if delim == "":
        return [line], ""
    try:
        return re.split(delim, line), delim
    except re.error:
        return line.split(delim), delim


def parse_index(x, n):
    try:
        v = int(x)
    except ValueError:
        return None
    if v == 0:
        return None
    return v - 1 if v > 0 else n + v


def eval_expr(line, expr, delim, ordinal, strip_last=False):
    expr = expr.strip()
    if expr == "n":
        return str(ordinal)
    fs, joiner = fields(line, delim)
    n = len(fs)
    if ".." in expr:
        left, right = expr.split("..", 1)
        start = 0 if left == "" else parse_index(left, n)
        end = n - 1 if right == "" else parse_index(right, n)
        if start is None or end is None:
            return ""
        start = max(0, start)
        end = min(n - 1, end)
        vals = fs[start:end + 1] if start <= end else []
    else:
        idx = parse_index(expr, n)
        vals = [fs[idx]] if idx is not None and 0 <= idx < n else []
    return joiner.join(vals)


def transform_line(line, spec, delim, ordinal):
    if not spec:
        return line
    if "{" in spec and "}" in spec:
        def repl(m):
            return eval_expr(line, m.group(1), delim, ordinal, True)
        return re.sub(r"\{([^{}]+)\}", repl, spec)
    joiner = " " if delim is None else delim
    return joiner.join(filter(lambda x: x != "", [eval_expr(line, e, delim, ordinal) for e in spec.split(",")]))


def search_text(line, opts, ordinal):
    display = transform_line(line, opts.with_nth, opts.delimiter, ordinal) if opts.with_nth else line
    if opts.nth:
        return " ".join(eval_expr(display, e, opts.delimiter, ordinal) for e in opts.nth.split(","))
    return display


def fuzzy_positions(needle, hay):
    pos = []
    j = 0
    for i, ch in enumerate(hay):
        if j < len(needle) and ch == needle[j]:
            pos.append(i)
            j += 1
            if j == len(needle):
                return pos
    return None


def split_query(q):
    terms = []
    cur = []
    esc = False
    for ch in q:
        if esc:
            cur.append(ch)
            esc = False
        elif ch == "\\":
            esc = True
        elif ch.isspace():
            if cur:
                terms.append("".join(cur))
                cur = []
        else:
            cur.append(ch)
    if cur:
        terms.append("".join(cur))
    return terms


def one_term(term, text, opts, ignore_case):
    neg = term.startswith("!")
    if neg:
        term = term[1:]
    exact = opts.exact or neg or not opts.extended
    prefix = suffix = False
    if opts.extended and term.startswith("'"):
        term = term[1:]
        exact = not opts.exact
    if opts.extended and term.startswith("^"):
        prefix = True
        exact = True
        term = term[1:]
    if opts.extended and term.endswith("$"):
        suffix = True
        exact = True
        term = term[:-1]
    a = text
    b = term
    if ignore_case:
        a = a.lower()
        b = b.lower()
    if b == "":
        ok = True
        positions = []
    elif prefix:
        ok = a.startswith(b)
        positions = list(range(len(b))) if ok else None
    elif suffix:
        ok = a.endswith(b)
        positions = list(range(len(a) - len(b), len(a))) if ok else None
    elif exact:
        p = a.find(b)
        ok = p >= 0
        positions = list(range(p, p + len(b))) if ok else None
    else:
        positions = fuzzy_positions(b, a)
        ok = positions is not None
    if neg:
        return (not ok), []
    return ok, positions or []


def match_query(query, text, opts):
    if query == "":
        return True, (0, 0, len(text))
    ignore = opts.case == "ignore" or (opts.case == "smart" and not any(c.isupper() for c in query))
    terms = split_query(query)
    if "|" in terms:
        groups = []
        cur = []
        for t in terms:
            if t == "|":
                groups.append(cur)
                cur = []
            else:
                cur.append(t)
        groups.append(cur)
    else:
        groups = [terms]
    best = None
    for group in groups:
        all_pos = []
        ok = True
        for term in group:
            good, pos = one_term(term, text, opts, ignore)
            if not good:
                ok = False
                break
            all_pos += pos
        if ok:
            if all_pos:
                span = max(all_pos) - min(all_pos) + 1
                begin = min(all_pos)
            else:
                span = 0
                begin = 0
            score = (span, begin, len(text))
            best = score if best is None or score < best else best
    return (best is not None), (best or (0, 0, len(text)))


def output_line(line, opts, ordinal):
    if opts.accept_nth:
        return transform_line(line, opts.accept_nth, opts.delimiter, ordinal)
    return line


def main():
    opts = parse_args(sys.argv[1:])
    query = opts.filter if opts.filter is not None else opts.query
    if opts.filter is None:
        if "-0" in sys.argv or "--exit-0" in sys.argv:
            data = sys.stdin.read()
            items = split_items(data, opts.read0)
            if not any(match_query(query, search_text(x, opts, i), opts)[0] for i, x in enumerate(items)):
                return 1
        print("inappropriate ioctl for device", file=sys.stderr)
        return 2

    data = sys.stdin.read()
    items = split_items(data, opts.read0)
    if opts.tac:
        items = list(reversed(items))
    if opts.tail is not None and opts.tail >= 0:
        items = items[-opts.tail:]

    headers = items[:opts.header_lines]
    body = items[opts.header_lines:]
    matches = []
    for i, line in enumerate(body):
        text = strip_ansi(search_text(line, opts, i))
        ok, score = match_query(query, text, opts)
        if ok:
            matches.append((score, i, line))
    if opts.sort:
        matches.sort(key=lambda x: (x[0][0], x[0][1], x[0][2], x[1]))

    out = []
    if opts.print_query:
        out.append(query)
    if opts.expect and opts.filter is None:
        out.append("")
    for i, h in enumerate(headers):
        out.append(output_line(h, opts, i))
    for _, i, line in matches:
        out.append(output_line(line, opts, i))

    sep = "\0" if opts.print0 else "\n"
    if out:
        sys.stdout.write(sep.join(out) + sep)
    return 0 if matches or query == "" or headers or opts.print_query or opts.expect else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        raise SystemExit(0)
