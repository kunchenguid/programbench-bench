package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"flag"
	"fmt"
	"image"
	"image/color"
	_ "image/gif"
	_ "image/jpeg"
	_ "image/png"
	"io"
	"math"
	"net/http"
	"os"
	"strconv"
	"strings"
)

const banner = `   ___  _____  ____
  / _ \/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
 / ___// /_>  </ __/ -_) __/  ' \ https://github.com/eliukblau/pixterm
/_/  /___/_/|_|\__/\__/_/ /_/_/_/                1.3.2
`

const helpText = banner + `
USAGE:

  executable [options] image/url

  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
  Supported URL protocols: HTTP, HTTPS.

OPTIONS:

  -credits
    	show some love to contributors <3
  -d mode
    	dithering mode:
    	   0 - no dithering (default)
    	   1 - with blocks
    	   2 - with chars
  -go
    	output Go code to 'fmt.Print()' the image
  -m color
    	matte color for transparency or background
    	(optional, hex format, default: 000000)
  -nobg
    	disable background color
    	(optional, only in dithering mode, ignores matte color)
  -s method
    	scale method:
    	   0 - resize (default)
    	   1 - fill
    	   2 - fit
  -tc columns
    	terminal columns (optional, >=2; when piping, default: 80)
  -tr rows
    	terminal rows (optional, >=2; when piping, default: 24)
  -version
    	show PIXterm version
  -help
	prints this message :D LOL

`

const creditsText = banner + `
CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.

`

type options struct {
	dither  int
	scale   int
	cols    int
	rows    int
	goCode  bool
	noBg    bool
	matte   color.RGBA
	version bool
	credits bool
}

func main() {
	opts, path, ok := parseArgs()
	if !ok {
		fmt.Print(helpText)
		return
	}
	if opts.version {
		fmt.Println("1.3.2")
		return
	}
	if opts.credits {
		fmt.Print(creditsText)
		return
	}
	if path == "" {
		fmt.Print(helpText)
		return
	}
	img, err := loadImage(path)
	if err != nil {
		fmt.Println(banner)
		fmt.Printf("[PIXTERM ERROR] %s\n", err)
		return
	}
	var out string
	if opts.dither == 0 {
		out = renderBlocks(img, opts)
	} else {
		out = renderDither(img, opts)
	}
	if opts.goCode {
		for _, line := range strings.SplitAfter(out, "\n") {
			if line != "" {
				fmt.Printf("fmt.Print(\"%s\")\n", goString(line))
			}
		}
	} else {
		fmt.Print(out)
	}
}

func goString(s string) string {
	var b strings.Builder
	for _, r := range s {
		switch r {
		case '\033':
			b.WriteString(`\033`)
		case '\n':
			b.WriteString(`\n`)
		case '\t':
			b.WriteString(`\t`)
		case '\\':
			b.WriteString(`\\`)
		case '"':
			b.WriteString(`\"`)
		default:
			b.WriteRune(r)
		}
	}
	return b.String()
}

func parseArgs() (options, string, bool) {
	o := options{cols: 80, rows: 24, matte: color.RGBA{0, 0, 0, 255}}
	fs := flag.NewFlagSet(os.Args[0], flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.IntVar(&o.dither, "d", 0, "")
	fs.IntVar(&o.scale, "s", 0, "")
	fs.IntVar(&o.cols, "tc", 80, "")
	fs.IntVar(&o.rows, "tr", 24, "")
	fs.BoolVar(&o.goCode, "go", false, "")
	fs.BoolVar(&o.noBg, "nobg", false, "")
	fs.BoolVar(&o.version, "version", false, "")
	fs.BoolVar(&o.credits, "credits", false, "")
	help := fs.Bool("help", false, "")
	matte := fs.String("m", "000000", "")
	if err := fs.Parse(os.Args[1:]); err != nil || *help {
		return o, "", false
	}
	if o.dither < 0 || o.dither > 2 || o.scale < 0 || o.scale > 2 || o.cols < 2 || o.rows < 2 {
		return o, "", false
	}
	c, err := parseHexColor(*matte)
	if err != nil {
		fmt.Println(banner)
		fmt.Printf("[PIXTERM ERROR] matte color : %s is not a hex-color\n", *matte)
		os.Exit(0)
	}
	o.matte = c
	if fs.NArg() > 0 {
		return o, fs.Arg(0), true
	}
	return o, "", true
}

func parseHexColor(s string) (color.RGBA, error) {
	s = strings.TrimPrefix(s, "#")
	if len(s) != 6 {
		return color.RGBA{}, errors.New("bad color")
	}
	v, err := strconv.ParseUint(s, 16, 32)
	if err != nil {
		return color.RGBA{}, err
	}
	return color.RGBA{uint8(v >> 16), uint8(v >> 8), uint8(v), 255}, nil
}

func loadImage(path string) (image.Image, error) {
	var data []byte
	var err error
	if strings.HasPrefix(path, "http://") || strings.HasPrefix(path, "https://") {
		resp, e := http.Get(path)
		if e != nil {
			return nil, e
		}
		defer resp.Body.Close()
		data, err = io.ReadAll(resp.Body)
	} else {
		data, err = os.ReadFile(path)
	}
	if err != nil {
		return nil, err
	}
	if len(data) >= 2 && data[0] == 'B' && data[1] == 'M' {
		return decodeBMP(data)
	}
	img, _, err := image.Decode(bytes.NewReader(data))
	return img, err
}

func renderBlocks(img image.Image, o options) string {
	w, h := outputPixels(img.Bounds(), o, o.cols, o.rows*2)
	var b strings.Builder
	for y := 0; y < h; y += 2 {
		for x := 0; x < w; x++ {
			top := sample(img, x, y, w, h, o.matte)
			bot := top
			if y+1 < h {
				bot = sample(img, x, y+1, w, h, o.matte)
			}
			fmt.Fprintf(&b, "\033[48;2;%d;%d;%dm\033[38;2;%d;%d;%dm▄", top.R, top.G, top.B, bot.R, bot.G, bot.B)
		}
		b.WriteString("\033[0m\n")
	}
	return b.String()
}

func renderDither(img image.Image, o options) string {
	w, h := outputPixels(img.Bounds(), o, o.cols, o.rows)
	blocks := []rune{' ', '░', '▒', '▓', '█'}
	chars := []rune(" .:-=+*#%@&")
	var b strings.Builder
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			c := sample(img, x, y, w, h, o.matte)
			lum := (int(c.R)*299 + int(c.G)*587 + int(c.B)*114) / 1000
			if o.dither == 1 {
				idx := int(math.Round(float64(lum) / 255 * float64(len(blocks)-1)))
				if !o.noBg {
					fmt.Fprintf(&b, "\033[48;2;%d;%d;%dm", o.matte.R, o.matte.G, o.matte.B)
				}
				fmt.Fprintf(&b, "\033[38;2;%d;%d;%dm%c", c.R, c.G, c.B, blocks[idx])
			} else {
				idx := int(math.Round(float64(lum) / 255 * float64(len(chars)-1)))
				if !o.noBg {
					fmt.Fprintf(&b, "\033[48;2;%d;%d;%dm", o.matte.R, o.matte.G, o.matte.B)
				}
				fmt.Fprintf(&b, "\033[38;2;%d;%d;%dm%c", c.R, c.G, c.B, chars[idx])
			}
		}
		b.WriteString("\033[0m\n")
	}
	return b.String()
}

func outputPixels(src image.Rectangle, o options, maxW, maxH int) (int, int) {
	if o.scale == 0 {
		return maxW, maxH
	}
	sw, sh := src.Dx(), src.Dy()
	if sw <= 0 || sh <= 0 {
		return maxW, maxH
	}
	rw, rh := float64(maxW)/float64(sw), float64(maxH)/float64(sh)
	r := rw
	if o.scale == 1 {
		if rh > r {
			r = rh
		}
	} else if rh < r {
		r = rh
	}
	w := int(math.Round(float64(sw) * r))
	h := int(math.Round(float64(sh) * r))
	if w < 1 {
		w = 1
	}
	if h < 1 {
		h = 1
	}
	if w > maxW {
		w = maxW
	}
	if h > maxH {
		h = maxH
	}
	return w, h
}

func sample(img image.Image, x, y, ow, oh int, matte color.RGBA) color.RGBA {
	b := img.Bounds()
	sx := b.Min.X + int(float64(x)*float64(b.Dx())/float64(ow))
	sy := b.Min.Y + int(float64(y)*float64(b.Dy())/float64(oh))
	if sx >= b.Max.X {
		sx = b.Max.X - 1
	}
	if sy >= b.Max.Y {
		sy = b.Max.Y - 1
	}
	r, g, bl, a := img.At(sx, sy).RGBA()
	aa := int(a >> 8)
	rr := (int(r>>8)*aa + int(matte.R)*(255-aa)) / 255
	gg := (int(g>>8)*aa + int(matte.G)*(255-aa)) / 255
	bb := (int(bl>>8)*aa + int(matte.B)*(255-aa)) / 255
	return color.RGBA{uint8(rr), uint8(gg), uint8(bb), 255}
}

func decodeBMP(data []byte) (image.Image, error) {
	if len(data) < 54 {
		return nil, errors.New("invalid BMP")
	}
	off := int(binary.LittleEndian.Uint32(data[10:14]))
	dib := binary.LittleEndian.Uint32(data[14:18])
	if dib < 40 || len(data) < 14+int(dib) {
		return nil, errors.New("unsupported BMP")
	}
	w := int(int32(binary.LittleEndian.Uint32(data[18:22])))
	hraw := int(int32(binary.LittleEndian.Uint32(data[22:26])))
	bpp := int(binary.LittleEndian.Uint16(data[28:30]))
	comp := binary.LittleEndian.Uint32(data[30:34])
	if w <= 0 || hraw == 0 || comp != 0 || (bpp != 24 && bpp != 32) {
		return nil, errors.New("unsupported BMP")
	}
	topDown := hraw < 0
	h := hraw
	if h < 0 {
		h = -h
	}
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	row := ((w*bpp + 31) / 32) * 4
	for y := 0; y < h; y++ {
		srcY := h - 1 - y
		if topDown {
			srcY = y
		}
		p := off + srcY*row
		if p+row > len(data) {
			return nil, errors.New("invalid BMP")
		}
		for x := 0; x < w; x++ {
			q := p + x*(bpp/8)
			a := uint8(255)
			if bpp == 32 {
				a = data[q+3]
			}
			img.SetRGBA(x, y, color.RGBA{data[q+2], data[q+1], data[q], a})
		}
	}
	return img, nil
}
