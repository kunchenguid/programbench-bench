module pixterm-reimpl

go 1.20
