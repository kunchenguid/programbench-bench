#!/usr/bin/env python3
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

VERSION = "2.37.1"


def exe_path():
    return os.path.abspath(sys.argv[0])


def eprint(msg):
    print(f"\033[31mdirenv: error {msg}\033[0m", file=sys.stderr)


def log(msg):
    print(f"\033[0mdirenv: {msg}", file=sys.stderr)


def xdg_config():
    return Path(os.environ.get("DIRENV_CONFIG") or Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "direnv")


def xdg_data():
    return Path(os.environ.get("XDG_DATA_HOME", str(Path.home() / ".local/share"))) / "direnv"


def xdg_cache():
    return Path(os.environ.get("XDG_CACHE_HOME", str(Path.home() / ".cache"))) / "direnv"


def resolve_rc(arg=None, start=None):
    base = Path(start or os.getcwd())
    if arg:
        p = Path(arg).expanduser()
        if not p.is_absolute():
            p = (base / p)
        if p.is_dir():
            for name in (".envrc", ".env"):
                q = p / name
                if q.exists():
                    return q.resolve()
            return (p / ".envrc").resolve()
        return p.resolve()
    cur = base.resolve()
    while True:
        envrc = cur / ".envrc"
        if envrc.exists():
            return envrc
        if load_dotenv_enabled():
            dotenv = cur / ".env"
            if dotenv.exists():
                return dotenv
        if cur.parent == cur:
            return None
        cur = cur.parent


def load_dotenv_enabled():
    cfg = xdg_config() / "direnv.toml"
    try:
        text = cfg.read_text()
    except OSError:
        return False
    in_global = False
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            in_global = line == "[global]"
        elif in_global and re.match(r"load_dotenv\s*=\s*true\b", line):
            return True
    return False


def allow_key(rc):
    data = str(rc).encode() + b"\0"
    try:
        data += Path(rc).read_bytes()
    except OSError:
        pass
    return hashlib.sha256(data).hexdigest()


def allow_path(rc):
    return xdg_data() / "allow" / allow_key(rc)


def deny_path(rc):
    return xdg_data() / "deny" / allow_key(rc)


def is_allowed(rc):
    p = allow_path(rc)
    try:
        return p.read_text().strip() == str(rc)
    except OSError:
        return False


HELP = f"""direnv v{VERSION}
Usage: direnv COMMAND [...ARGS]

Available commands
------------------
allow [PATH_TO_RC]:
  aliases: permit, grant
  Grants direnv permission to load the given .envrc or .env file.
block [PATH_TO_RC]:
  aliases: deny, disallow, revoke
  Revokes the authorization of a given .envrc or .env file.
edit [PATH_TO_RC]:
  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow
  the file to be loaded afterwards.
exec DIR COMMAND [...ARGS]:
  Executes a command after loading the first .envrc or .env found in DIR
export SHELL:
  Loads an .envrc or .env and prints the diff in terms of exports.
  Supported SHELL values are: [systemd, json, tcsh, vim, zsh, gzenv, murex, pwsh, bash, elvish, fish, gha]
fetchurl <url> [<integrity-hash>]:
  Fetches a given URL into direnv's CAS
help [SHOW_PRIVATE]:
  Shows this help
hook SHELL:
  Used to setup the shell hook
prune:
  Removes old allowed and required files
reload:
  Triggers an env reload
status [--json]:
  Prints some debug status information
stdlib:
  Displays the stdlib available in the .envrc execution context
version [VERSION_AT_LEAST]:
  prints the version or checks that direnv is older than VERSION_AT_LEAST.
log [--status | --error] <message>:
  Logs a given message
"""


STDLIB = r'''#!/usr/bin/env bash
shopt -s nullglob extglob
export DIRENV_IN_ENVRC=1

has() { type "$1" >/dev/null 2>&1; }

expand_path() {
  local rel="$1" base="${2:-$PWD}"
  case "$rel" in
    ~*) eval "rel=$rel" ;;
  esac
  if [[ "$rel" = /* ]]; then
    (cd "$(dirname "$rel")" 2>/dev/null && printf "%s/%s\n" "$PWD" "$(basename "$rel")")
  else
    (cd "$base" 2>/dev/null && cd "$(dirname "$rel")" 2>/dev/null && printf "%s/%s\n" "$PWD" "$(basename "$rel")")
  fi
}

user_rel_path() {
  case "$1" in
    "$HOME") printf "~\n" ;;
    "$HOME"/*) printf "~/%s\n" "${1#"$HOME"/}" ;;
    *) printf "%s\n" "$1" ;;
  esac
}

find_up() {
  local name="$1" dir="$PWD"
  while true; do
    if [[ -e "$dir/$name" ]]; then printf "%s\n" "$dir/$name"; return 0; fi
    [[ "$dir" = / ]] && return 1
    dir="$(dirname "$dir")"
  done
}

dotenv() {
  local file="${1:-.env}"
  [[ -f "$file" ]] || return 1
  set -a
  source "$file"
  set +a
}

dotenv_if_exists() {
  local file="${1:-.env}"
  [[ -f "$file" ]] && dotenv "$file" || true
}

source_env() {
  local p="$1"
  [[ -d "$p" ]] && p="$p/.envrc"
  source "$p"
}

source_env_if_exists() {
  [[ -f "$1" ]] && source "$1" || true
}

source_up() {
  local f="${1:-.envrc}" p
  p="$(find_up "$f")" || return 1
  source "$p"
}

source_up_if_exists() { source_up "${1:-.envrc}" || true; }

env_vars_required() {
  local missing=0 name
  for name in "$@"; do
    if [[ -z "${!name:-}" ]]; then
      echo "direnv: error $name is required" >&2
      missing=1
    fi
  done
  return "$missing"
}

path_add() {
  local var="$1" val
  val="$(expand_path "$2")"
  if [[ -n "${!var:-}" ]]; then
    export "$var=$val:${!var}"
  else
    export "$var=$val"
  fi
}

PATH_add() { path_add PATH "$1"; }
MANPATH_add() { path_add MANPATH "$1"; }

PATH_rm() {
  local old="$PATH" out="" item pat keep
  IFS=: read -r -a __parts <<< "$old"
  for item in "${__parts[@]}"; do
    keep=1
    for pat in "$@"; do [[ "$item" == $pat ]] && keep=0; done
    [[ "$keep" = 1 ]] && out="${out:+$out:}$item"
  done
  export PATH="$out"
}

load_prefix() {
  local p
  p="$(expand_path "$1")"
  PATH_add "$p/bin"
  path_add CPATH "$p/include"
  path_add LD_LIBRARY_PATH "$p/lib"
  path_add LIBRARY_PATH "$p/lib"
  MANPATH_add "$p/share/man"
  path_add PKG_CONFIG_PATH "$p/lib/pkgconfig"
}

direnv_layout_dir() {
  local hash
  hash="$(printf "%s" "$PWD" | sha1sum | cut -d" " -f1)"
  local d="${XDG_CACHE_HOME:-$HOME/.cache}/direnv/layouts/$hash"
  mkdir -p "$d"
  printf "%s\n" "$d"
}

layout() {
  case "$1" in
    go) export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin ;;
    node) PATH_add node_modules/.bin ;;
    julia) export JULIA_PROJECT="$PWD" ;;
    php) PATH_add vendor/bin ;;
    python|python3)
      local venv="${2:-$(direnv_layout_dir)/python}"
      export VIRTUAL_ENV="$venv"
      PATH_add "$venv/bin"
      ;;
    *) echo "direnv: error unknown layout $1" >&2; return 1 ;;
  esac
}

semver_search() {
  local dir="$1" prefix="$2" partial="$3"
  find "$dir" -maxdepth 1 -type d -name "$prefix$partial*" -printf "%f\n" 2>/dev/null |
    sed "s/^$prefix//" | sort -V | tail -n1
}

watch_file() { :; }
watch_dir() { :; }
strict_env() { if (($#)); then "$@"; else set -euo pipefail; fi; }
unstrict_env() { if (($#)); then set +e +u +o pipefail; "$@"; else set +e +u +o pipefail; fi; }
log_status() { echo "direnv: $*" >&2; }
log_error() { echo "direnv: error $*" >&2; }
'''


def bash_quote(s):
    return "$'" + s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\t", "\\t") + "'"


def fish_quote(s):
    return "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"


def eval_env(rc):
    before = dict(os.environ)
    script = STDLIB + "\n"
    cfg = xdg_config()
    script += f'direnv={bash_quote(exe_path())}\n'
    script += f'direnv_config_dir={bash_quote(str(cfg))}\n'
    script += f'cd {bash_quote(str(rc.parent))} || exit 1\n'
    script += f'[[ -f {bash_quote(str(cfg / "direnvrc"))} ]] && source {bash_quote(str(cfg / "direnvrc"))}\n'
    script += f'for f in {bash_quote(str(cfg / "lib"))}/*.sh; do source "$f"; done\n'
    if rc.name == ".env":
        script += f'dotenv {bash_quote(str(rc))}\n'
    else:
        script += f'source {bash_quote(str(rc))}\n'
    marker = "__DIRENV_PY_ENV_START__"
    script += f'printf "\\n{marker}\\n"\n'
    script += "env -0\n"
    proc = subprocess.run(["/usr/bin/bash", "-c", script], env=before, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.stderr:
        sys.stderr.buffer.write(proc.stderr)
    if proc.returncode != 0:
        return None, proc.returncode
    out = proc.stdout
    mb = ("\n" + marker + "\n").encode()
    if mb in out:
        out = out.split(mb, 1)[1]
    after = {}
    for part in out.split(b"\0"):
        if b"=" in part:
            k, v = part.split(b"=", 1)
            try:
                after[k.decode()] = v.decode()
            except UnicodeDecodeError:
                after[k.decode(errors="ignore")] = v.decode(errors="ignore")
    after.pop("DIRENV_IN_ENVRC", None)
    for ignored in ("PWD", "OLDPWD", "SHLVL", "_"):
        if ignored in before and ignored in after:
            after[ignored] = before[ignored]
    after["DIRENV_FILE"] = str(rc)
    after["DIRENV_DIR"] = "-" + str(rc.parent)
    return after, 0


def env_diff(after):
    before = dict(os.environ)
    changes = {}
    for k, v in after.items():
        if before.get(k) != v:
            changes[k] = v
    for k in before:
        if k not in after and not k.startswith("_"):
            changes[k] = None
    return changes


def format_export(shell, changes):
    if shell in ("json", "elvish", "murex"):
        print(json.dumps(changes, separators=(",", ":")))
    elif shell in ("bash", "zsh"):
        out = []
        for k, v in changes.items():
            if v is None:
                out.append(f"unset {k};")
            else:
                out.append(f"export {k}={bash_quote(v)};")
        print("".join(out), end="")
    elif shell == "fish":
        for k, v in changes.items():
            if v is None:
                print(f"set -e {k};")
            else:
                print(f"set -gx {k} {fish_quote(v)};")
    elif shell == "tcsh":
        for k, v in changes.items():
            if v is None:
                print(f"unsetenv {k};")
            else:
                print(f"setenv {k} {sh_quote_plain(v)};")
    elif shell == "pwsh":
        for k, v in changes.items():
            if v is None:
                print(f"Remove-Item Env:{k} -ErrorAction SilentlyContinue;")
            else:
                print(f"$Env:{k} = {json.dumps(v)};")
    elif shell == "vim":
        for k, v in changes.items():
            if v is not None:
                print(f"let ${k} = {json.dumps(v)}")
    elif shell == "gha":
        envfile = os.environ.get("GITHUB_ENV")
        if envfile:
            with open(envfile, "a") as f:
                for k, v in changes.items():
                    if v is not None:
                        f.write(f"{k}={v}\n")
    elif shell == "systemd":
        for k, v in changes.items():
            if v is not None:
                print(f"{k}={v}")
    elif shell == "gzenv":
        for k, v in changes.items():
            if v is not None:
                print(f"{k}\0{v}\0", end="")
    else:
        eprint(f"unknown target shell '{shell}'")
        return 1
    return 0


def sh_quote_plain(s):
    return "'" + s.replace("'", "'\\''") + "'"


def cmd_export(args):
    if len(args) != 1:
        eprint("invalid arguments")
        return 1
    shell = args[0]
    rc = resolve_rc()
    if not rc:
        return 0
    if not is_allowed(rc):
        marker = {
            "DIRENV_FILE": str(rc),
            "DIRENV_DIR": "-" + str(rc.parent),
            "DIRENV_WATCHES": "",
            "DIRENV_DIFF": "",
        }
        format_export(shell, marker)
        eprint(f"{rc} is blocked. Run `direnv allow` to approve its content")
        return 0
    log(f"loading {rc}")
    after, code = eval_env(rc)
    if code:
        return code
    changes = env_diff(after)
    added = sorted(k for k, v in changes.items() if v is not None and k not in os.environ and not k.startswith("DIRENV_"))
    removed = sorted(k for k, v in changes.items() if v is None)
    changed = sorted(k for k, v in changes.items() if v is not None and k in os.environ and os.environ.get(k) != v and not k.startswith("DIRENV_"))
    parts = [f"+{k}" for k in added] + [f"~{k}" for k in changed] + [f"-{k}" for k in removed]
    if parts:
        log("export " + " ".join(parts))
    return format_export(shell, changes)


def cmd_allow(args):
    rc = resolve_rc(args[0] if args else None)
    if not rc or not rc.exists():
        eprint(".envrc not found")
        return 1
    p = allow_path(rc)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(str(rc) + "\n")
    dp = deny_path(rc)
    if dp.exists():
        dp.unlink()
    return 0


def cmd_block(args):
    rc = resolve_rc(args[0] if args else None)
    if not rc:
        eprint(".envrc not found")
        return 1
    ap = allow_path(rc)
    if ap.exists():
        ap.unlink()
    dp = deny_path(rc)
    dp.parent.mkdir(parents=True, exist_ok=True)
    dp.write_text(str(rc) + "\n")
    return 0


def cmd_status(args):
    if args == ["--json"]:
        rc = resolve_rc()
        print(json.dumps({"config": str(xdg_config()), "foundRC": str(rc) if rc else None, "allowed": bool(rc and is_allowed(rc))}))
        return 0
    print(f"direnv exec path {exe_path()}")
    print(f"DIRENV_CONFIG {xdg_config()}")
    print(f"bash_path {shutil.which('bash') or '/usr/bin/bash'}")
    print("disable_stdin false")
    print("warn_timeout 5s")
    print("whitelist.prefix []")
    print("whitelist.exact map[]")
    print("No .envrc or .env loaded")
    rc = resolve_rc()
    if rc:
        print(f"Found RC path {rc}")
        print(f"Found RC allowed {str(is_allowed(rc)).lower()}")
        print(f"Found RC allowPath {allow_path(rc)}")
    else:
        print("No .envrc or .env found")
    return 0


def cmd_exec(args):
    if len(args) < 2:
        eprint("invalid arguments")
        return 1
    directory, command = args[0], args[1:]
    rc = resolve_rc(start=directory)
    env = dict(os.environ)
    if rc:
        if not is_allowed(rc):
            eprint(f"{rc} is blocked. Run `direnv allow` to approve its content")
            return 1
        after, code = eval_env(rc)
        if code:
            return code
        env.update(after)
    proc = subprocess.run(command, env=env)
    return proc.returncode


def cmd_hook(args):
    if len(args) != 1:
        eprint("invalid arguments")
        return 1
    shell = args[0]
    p = exe_path()
    hooks = {
        "bash": f'''\n_direnv_hook() {{\n  local previous_exit_status=$?;\n  vars="$("{p}" export bash)";\n  trap -- '' SIGINT;\n  eval "$vars";\n  trap - SIGINT;\n  return $previous_exit_status;\n}};\nif [[ ";${{PROMPT_COMMAND[*]:-}};" != *";_direnv_hook;"* ]]; then\n  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then\n    PROMPT_COMMAND=(_direnv_hook "${{PROMPT_COMMAND[@]}}")\n  else\n    PROMPT_COMMAND="_direnv_hook${{PROMPT_COMMAND:+;$PROMPT_COMMAND}}"\n  fi\nfi''',
        "zsh": f'''\n_direnv_hook() {{\n  vars="$("{p}" export zsh)"\n  trap -- '' SIGINT\n  eval "$vars"\n  trap - SIGINT\n}}\ntypeset -ag precmd_functions\nif (( ! ${{precmd_functions[(I)_direnv_hook]}} )); then\n  precmd_functions=(_direnv_hook $precmd_functions)\nfi\ntypeset -ag chpwd_functions\nif (( ! ${{chpwd_functions[(I)_direnv_hook]}} )); then\n  chpwd_functions=(_direnv_hook $chpwd_functions)\nfi''',
        "fish": f'''\n    function __direnv_export_eval --on-event fish_prompt;\n        "{p}" export fish | source;\n    end;''',
        "tcsh": f"alias precmd 'eval `{p} export tcsh`'",
        "pwsh": f'Invoke-Expression "$({p} export pwsh)"',
        "elvish": f'var m = [("{p}" export elvish | from-json)]',
        "murex": f'event: onPrompt direnv_hook=before {{ "{p}" export murex -> set exports }}',
    }
    if shell in hooks:
        print(hooks[shell], end="")
        return 0
    messages = {
        "vim": "this feature is not supported. Install the direnv.vim plugin instead",
        "gha": "Hook not implemented for GitHub Actions shell",
        "gzenv": "the gzenv shell doesn't support hooking",
        "json": "this feature is not supported",
        "systemd": "this feature is not supported",
    }
    eprint(messages.get(shell, f"unknown target shell '{shell}'"))
    return 1


def cmd_version(args):
    if not args:
        print(VERSION)
        return 0
    m = re.match(r"^v?(\d+)\.(\d+)\.(\d+)$", args[0])
    if not m:
        eprint(f"v{args[0]} is not a valid semver version")
        return 1
    want = tuple(map(int, m.groups()))
    have = tuple(map(int, VERSION.split(".")))
    if have < want:
        eprint(f"current version v{VERSION} is older than the desired version v{args[0]}")
        return 1
    return 0


def cmd_fetchurl(args):
    eprint("Get \"{}\": dial tcp: lookup failed".format(args[0] if args else ""))
    return 1


def cmd_prune(args):
    base = xdg_data() / "allow"
    if not base.exists():
        eprint(f"open {base}: no such file or directory")
        return 1
    for f in base.iterdir():
        try:
            target = Path(f.read_text().strip())
            if not target.exists():
                f.unlink()
        except OSError:
            pass
    return 0


def main():
    args = sys.argv[1:]
    if not args or args[0] in ("help", "--help", "-h"):
        print(HELP, end="")
        return 0
    cmd, rest = args[0], args[1:]
    if cmd in ("allow", "permit", "grant"):
        return cmd_allow(rest)
    if cmd in ("block", "deny", "disallow", "revoke"):
        return cmd_block(rest)
    if cmd == "export":
        return cmd_export(rest)
    if cmd == "exec":
        return cmd_exec(rest)
    if cmd == "hook":
        return cmd_hook(rest)
    if cmd == "status":
        return cmd_status(rest)
    if cmd == "stdlib":
        print(STDLIB.replace('direnv="/workspace/executable"', f'direnv="{exe_path()}"'))
        return 0
    if cmd == "version":
        return cmd_version(rest)
    if cmd == "reload":
        rc = resolve_rc()
        if not rc:
            eprint(".envrc not found")
            return 1
        return 0
    if cmd == "prune":
        return cmd_prune(rest)
    if cmd == "fetchurl":
        return cmd_fetchurl(rest)
    if cmd == "edit":
        return cmd_allow(rest)
    if cmd == "log":
        if len(rest) >= 2 and rest[0] == "--error":
            eprint(" ".join(rest[1:]))
            return 0
        if len(rest) >= 2 and rest[0] == "--status":
            log(" ".join(rest[1:]))
            return 0
        if rest:
            log(" ".join(rest))
            return 0
        eprint("invalid arguments")
        return 1
    eprint(f'command "{sys.argv[0]} {cmd}" not found')
    return 1


if __name__ == "__main__":
    sys.exit(main())
