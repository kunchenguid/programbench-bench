module reerrcheck

go 1.21
