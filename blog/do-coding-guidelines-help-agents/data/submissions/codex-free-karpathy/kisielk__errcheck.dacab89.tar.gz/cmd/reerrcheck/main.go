package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/importer"
	"go/parser"
	"go/token"
	"go/types"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
)

type listFlag []string

func (l *listFlag) String() string { return strings.Join(*l, ",") }
func (l *listFlag) Set(s string) error {
	*l = append(*l, s)
	return nil
}

type config struct {
	abspath         bool
	asserts         bool
	blank           bool
	exclude         string
	excludeOnly     bool
	ignoreGenerated bool
	ignoreTests     bool
	mod             string
	tags            listFlag
	ignores         listFlag
	ignorePkg       string
	verbose         bool
}

type goPackage struct {
	ImportPath        string
	Dir               string
	GoFiles           []string
	TestGoFiles       []string
	XTestGoFiles      []string
	IgnoredGoFiles    []string
	Error             *pkgError
	DepsErrors        []*pkgError
}

type pkgError struct {
	Err string
}

type finding struct {
	file string
	line int
	col  int
	text string
}

type ignoreRule struct {
	pkg string
	re  *regexp.Regexp
}

func main() {
	flag.CommandLine = flag.NewFlagSet(os.Args[0], flag.ContinueOnError)
	flag.CommandLine.SetOutput(os.Stderr)
	var cfg config
	flag.BoolVar(&cfg.abspath, "abspath", false, "print absolute paths to files")
	flag.BoolVar(&cfg.asserts, "asserts", false, "if true, check for ignored type assertion results")
	flag.BoolVar(&cfg.blank, "blank", false, "if true, check for errors assigned to blank identifier")
	flag.StringVar(&cfg.exclude, "exclude", "", "Path to a file containing a list of functions to exclude from checking")
	flag.BoolVar(&cfg.excludeOnly, "excludeonly", false, "Use only excludes from -exclude file")
	flag.Var(&cfg.ignores, "ignore", "[deprecated] comma-separated list of pairs of the form pkg:regex\n            the regex is used to ignore names within pkg.")
	flag.BoolVar(&cfg.ignoreGenerated, "ignoregenerated", false, "if true, checking of files with generated code is disabled")
	flag.StringVar(&cfg.ignorePkg, "ignorepkg", "", "comma-separated list of package paths to ignore")
	flag.BoolVar(&cfg.ignoreTests, "ignoretests", false, "if true, checking of _test.go files is disabled")
	flag.StringVar(&cfg.mod, "mod", "", "module download mode to use: readonly or vendor. See 'go help modules' for more.")
	flag.Var(&cfg.tags, "tags", "comma or space-separated list of build tags to include")
	flag.BoolVar(&cfg.verbose, "verbose", false, "produce more verbose logging")
	if err := flag.CommandLine.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}

	patterns := flag.Args()
	if len(patterns) == 0 {
		return
	}

	excludes, err := loadExcludes(cfg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(2)
	}
	ignores, err := loadIgnores(cfg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(2)
	}

	pkgs, stderr, err := listPackages(cfg, patterns)
	if err != nil || packageErrors(pkgs) != "" {
		msg := strings.TrimSpace(stderr)
		if msg == "" {
			msg = packageErrors(pkgs)
		}
		if msg == "" && err != nil {
			msg = err.Error()
		}
		fmt.Fprintf(os.Stderr, "error: failed to check packages: %s\n", msg)
		os.Exit(2)
	}

	var all []finding
	for _, pkg := range pkgs {
		if ignoredPackage(pkg.ImportPath, cfg.ignorePkg) {
			continue
		}
		if cfg.verbose {
			fmt.Fprintf(os.Stderr, "checking %s\n", pkg.ImportPath)
		}
		fs, err := analyzePackage(pkg, cfg, excludes, ignores)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: failed to check packages: %v\n", err)
			os.Exit(2)
		}
		all = append(all, fs...)
	}
	for _, f := range all {
		fmt.Printf("%s:%d:%d:\t%s\n", f.file, f.line, f.col, f.text)
	}
	if len(all) > 0 {
		os.Exit(1)
	}
}

func listPackages(cfg config, patterns []string) ([]goPackage, string, error) {
	args := []string{"list", "-json"}
	if cfg.mod != "" {
		args = append(args, "-mod="+cfg.mod)
	}
	if len(cfg.tags) > 0 {
		args = append(args, "-tags="+joinTags(cfg.tags))
	}
	args = append(args, patterns...)
	cmd := exec.Command("go", args...)
	var out, serr bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &serr
	err := cmd.Run()
	dec := json.NewDecoder(&out)
	var pkgs []goPackage
	for dec.More() {
		var p goPackage
		if e := dec.Decode(&p); e != nil {
			break
		}
		pkgs = append(pkgs, p)
	}
	return pkgs, serr.String(), err
}

func packageErrors(pkgs []goPackage) string {
	var parts []string
	for _, p := range pkgs {
		if p.Error != nil && p.Error.Err != "" {
			parts = append(parts, p.Error.Err)
		}
		for _, e := range p.DepsErrors {
			if e != nil && e.Err != "" {
				parts = append(parts, e.Err)
			}
		}
	}
	return strings.Join(parts, "\n")
}

func analyzePackage(pkg goPackage, cfg config, excludes map[string]bool, ignores []ignoreRule) ([]finding, error) {
	files := append([]string{}, pkg.GoFiles...)
	if !cfg.ignoreTests {
		files = append(files, pkg.TestGoFiles...)
	}
	if len(files) == 0 {
		return nil, nil
	}

	fset := token.NewFileSet()
	var astFiles []*ast.File
	lines := map[string][]string{}
	for _, name := range files {
		path := filepath.Join(pkg.Dir, name)
		src, err := os.ReadFile(path)
		if err != nil {
			return nil, err
		}
		if cfg.ignoreGenerated && isGenerated(src) {
			continue
		}
		f, err := parser.ParseFile(fset, path, src, parser.ParseComments)
		if err != nil {
			return nil, err
		}
		astFiles = append(astFiles, f)
		lines[path] = strings.Split(string(src), "\n")
	}
	if len(astFiles) == 0 {
		return nil, nil
	}

	info := &types.Info{
		Types:      map[ast.Expr]types.TypeAndValue{},
		Defs:       map[*ast.Ident]types.Object{},
		Uses:       map[*ast.Ident]types.Object{},
		Selections: map[*ast.SelectorExpr]*types.Selection{},
	}
	tc := types.Config{Importer: importer.Default(), Error: func(error) {}}
	if _, err := tc.Check(pkg.ImportPath, fset, astFiles, info); err != nil {
		return nil, err
	}

	var findings []finding
	for _, file := range astFiles {
		ast.Inspect(file, func(n ast.Node) bool {
			switch s := n.(type) {
			case *ast.ExprStmt:
				if call, ok := s.X.(*ast.CallExpr); ok && returnsError(info.TypeOf(call)) && !excludedCall(call, info, excludes, ignores) {
					findings = append(findings, makeFinding(fset, call.Lparen, lines, cfg.abspath))
				}
				if cfg.asserts {
					if ta, ok := s.X.(*ast.TypeAssertExpr); ok {
						findings = append(findings, makeFinding(fset, ta.X.Pos(), lines, cfg.abspath))
					}
				}
			case *ast.AssignStmt:
				if cfg.blank {
					findings = append(findings, blankFindings(s, info, fset, lines, cfg.abspath, excludes, ignores)...)
				}
				if cfg.asserts {
					findings = append(findings, assertFindings(s, fset, lines, cfg.abspath)...)
				}
			}
			return true
		})
	}
	return findings, nil
}

func blankFindings(s *ast.AssignStmt, info *types.Info, fset *token.FileSet, lines map[string][]string, abspath bool, excludes map[string]bool, ignores []ignoreRule) []finding {
	var out []finding
	if len(s.Rhs) == 1 {
		call, ok := s.Rhs[0].(*ast.CallExpr)
		if !ok || excludedCall(call, info, excludes, ignores) {
			return nil
		}
		if tup, ok := info.TypeOf(call).(*types.Tuple); ok {
			for i := 0; i < tup.Len() && i < len(s.Lhs); i++ {
				if isBlank(s.Lhs[i]) && isErrorType(tup.At(i).Type()) {
					out = append(out, makeFinding(fset, s.Lhs[i].Pos(), lines, abspath))
				}
			}
			return out
		}
		if len(s.Lhs) > 0 && isBlank(s.Lhs[0]) && returnsError(info.TypeOf(call)) {
			out = append(out, makeFinding(fset, s.Lhs[0].Pos(), lines, abspath))
		}
		return out
	}
	for i, rhs := range s.Rhs {
		call, ok := rhs.(*ast.CallExpr)
		if !ok || i >= len(s.Lhs) || !isBlank(s.Lhs[i]) || excludedCall(call, info, excludes, ignores) {
			continue
		}
		if returnsError(info.TypeOf(call)) {
			out = append(out, makeFinding(fset, s.Lhs[i].Pos(), lines, abspath))
		}
	}
	return out
}

func assertFindings(s *ast.AssignStmt, fset *token.FileSet, lines map[string][]string, abspath bool) []finding {
	if len(s.Rhs) == 1 {
		ta, ok := s.Rhs[0].(*ast.TypeAssertExpr)
		if !ok {
			return nil
		}
		if len(s.Lhs) == 2 {
			return nil
		}
		return []finding{makeFinding(fset, ta.X.Pos(), lines, abspath)}
	}
	var out []finding
	for _, rhs := range s.Rhs {
		if ta, ok := rhs.(*ast.TypeAssertExpr); ok {
			out = append(out, makeFinding(fset, ta.X.Pos(), lines, abspath))
		}
	}
	return out
}

func returnsError(t types.Type) bool {
	if t == nil {
		return false
	}
	if isErrorType(t) {
		return true
	}
	if tup, ok := t.(*types.Tuple); ok {
		for i := 0; i < tup.Len(); i++ {
			if isErrorType(tup.At(i).Type()) {
				return true
			}
		}
	}
	return false
}

func isErrorType(t types.Type) bool {
	if t == nil {
		return false
	}
	return t.String() == "error"
}

func isBlank(e ast.Expr) bool {
	id, ok := e.(*ast.Ident)
	return ok && id.Name == "_"
}

func makeFinding(fset *token.FileSet, pos token.Pos, lines map[string][]string, abspath bool) finding {
	p := fset.Position(pos)
	file := p.Filename
	display := file
	if !abspath {
		if rel, err := filepath.Rel(mustCwd(), file); err == nil && !strings.HasPrefix(rel, "..") {
			display = rel
		}
	}
	text := ""
	if ls := lines[file]; p.Line >= 1 && p.Line <= len(ls) {
		text = strings.TrimLeft(ls[p.Line-1], " \t")
	}
	return finding{file: display, line: p.Line, col: p.Column, text: text}
}

func mustCwd() string {
	wd, err := os.Getwd()
	if err != nil {
		return "."
	}
	return wd
}

func loadExcludes(cfg config) (map[string]bool, error) {
	ex := map[string]bool{}
	if !cfg.excludeOnly {
		ex["fmt.Print"] = true
		ex["fmt.Printf"] = true
		ex["fmt.Println"] = true
		ex["fmt.Fprint"] = true
		ex["fmt.Fprintf"] = true
		ex["fmt.Fprintln"] = true
		ex["fmt.Sprint"] = true
		ex["fmt.Sprintf"] = true
		ex["fmt.Sprintln"] = true
		ex["bytes.(*Buffer).Write"] = true
		ex["bytes.(*Buffer).WriteByte"] = true
		ex["bytes.(*Buffer).WriteRune"] = true
		ex["bytes.(*Buffer).WriteString"] = true
		ex["strings.(*Builder).Write"] = true
		ex["strings.(*Builder).WriteByte"] = true
		ex["strings.(*Builder).WriteRune"] = true
		ex["strings.(*Builder).WriteString"] = true
	}
	if cfg.exclude == "" {
		return ex, nil
	}
	data, err := os.ReadFile(cfg.exclude)
	if err != nil {
		return nil, err
	}
	for _, line := range strings.Split(string(data), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "//") {
			continue
		}
		ex[line] = true
	}
	return ex, nil
}

func loadIgnores(cfg config) ([]ignoreRule, error) {
	var rules []ignoreRule
	for _, item := range cfg.ignores {
		for _, part := range strings.Split(item, ",") {
			if strings.TrimSpace(part) == "" {
				continue
			}
			pkg, expr, ok := strings.Cut(part, ":")
			if !ok {
				pkg, expr = "", part
			}
			re, err := regexp.Compile(expr)
			if err != nil {
				return nil, err
			}
			rules = append(rules, ignoreRule{pkg: pkg, re: re})
		}
	}
	return rules, nil
}

func ignoredPackage(path, list string) bool {
	for _, p := range strings.Split(list, ",") {
		if strings.TrimSpace(p) == path {
			return true
		}
	}
	return false
}

func excludedCall(call *ast.CallExpr, info *types.Info, excludes map[string]bool, ignores []ignoreRule) bool {
	pkg, name, full := callName(call, info)
	if full == "" {
		return false
	}
	if excludes[full] || excludes[pkg+"."+name] {
		return true
	}
	for _, r := range ignores {
		if (r.pkg == "" || r.pkg == pkg) && r.re.MatchString(name) {
			return true
		}
	}
	return false
}

func callName(call *ast.CallExpr, info *types.Info) (string, string, string) {
	var obj types.Object
	switch fn := call.Fun.(type) {
	case *ast.Ident:
		obj = info.Uses[fn]
	case *ast.SelectorExpr:
		if sel := info.Selections[fn]; sel != nil {
			obj = sel.Obj()
		} else {
			obj = info.Uses[fn.Sel]
		}
	}
	if obj == nil || obj.Pkg() == nil {
		return "", "", ""
	}
	pkg := obj.Pkg().Path()
	name := obj.Name()
	full := pkg + "." + name
	if fn, ok := obj.(*types.Func); ok {
		if sig, ok := fn.Type().(*types.Signature); ok && sig.Recv() != nil {
			recv := sig.Recv().Type().String()
			full = "(" + recv + ")." + name
		}
	}
	return pkg, name, full
}

func isGenerated(src []byte) bool {
	re := regexp.MustCompile(`(?m)^// Code generated .* DO NOT EDIT\.$`)
	return re.Find(src) != nil
}

func joinTags(tags []string) string {
	var out []string
	for _, t := range tags {
		for _, p := range strings.FieldsFunc(t, func(r rune) bool { return r == ',' || r == ' ' || r == '\t' || r == '\n' }) {
			if p != "" {
				out = append(out, p)
			}
		}
	}
	return strings.Join(out, ",")
}
