#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char n_value[512];
    int top;
    int combi;
    int rep;
    int wpm;
    int acc;
    char emu_in[64];
    char emu_out[64];
    bool show_ortho;
    bool nokb;
    bool cat;
} Options;

static const char *bigrams[] = {
    "th","he","in","er","an","re","on","at","en","nd","ti","es","or","te","of","ed","is","it","al","ar",
    "st","to","nt","ng","se","ha","as","ou","io","le","ve","co","me","de","hi","ri","ro","ic","ne","ea",
    "ra","ce","li","ch","ll","be","ma","si","om","ur","ca","el","ta","la","ns","di","fo","ho","pe","ec",
    "pr","no","ct","us","ac","ot","il","tr","ly","nc","et","ut","ss","so","rs","un","lo","wa","ge","ie",
    "wh","ee","wi","em","ad","ol","rt","po","we","na","ul","ni","ts","mo","ow","pa","im","mi","ai","sh"
};

static const char *trigrams[] = {
    "the","and","ing","ion","ent","her","tha","nth","was","eth","for","dth","hat","his","ere","tio","ter","est","ers","ati",
    "all","ate","ver","ati","res","int","rea","ons","sto","pro","con","com","men","ess","not","ive","but","you","ith","ted"
};

static const char *tetragrams[] = {
    "tion","ther","that","with","ment","ions","this","here","ould","ight","have","hich","whic","tive","ough","ance","were","ally","ated","ring",
    "ever","from","ting","ents","atio","othe","ture","some","hand","they","will","over","more","able","down","into","only","than","them","been"
};

static const char *words[] = {
    "the","be","to","of","and","a","in","that","have","i","it","for","not","on","with","he","as","you","do","at",
    "this","but","his","by","from","they","we","say","her","she","or","an","will","my","one","all","would","there","their","what"
};

static void print_help(void) {
    puts("Usage: executable [OPTIONS]\n");
    puts("Options:");
    puts("  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]");
    puts("  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]");
    puts("  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]");
    puts("  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]");
    puts("  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]");
    puts("  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]");
    puts("      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --show-ortho        show keyboard in ortholinear format");
    puts("      --nokb              pass this flag to disable the keyboard layout display.");
    puts("      --cat               the most important flag. don't practice alone.");
    puts("  -h, --help              Print help");
}

static void usage_error_unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
}

static void usage_error_missing(const char *flag, const char *meta) {
    fprintf(stderr, "error: a value is required for '%s <%s>' but none was supplied\n\n", flag, meta);
    fprintf(stderr, "For more information, try '--help'.\n");
}

static bool parse_int_value(const char *s, const char *flag, const char *meta, int *out) {
    if (*s == '\0') {
        fprintf(stderr, "error: invalid value '' for '%s <%s>': cannot parse integer from empty string\n\n", flag, meta);
        fprintf(stderr, "For more information, try '--help'.\n");
        exit(2);
    }
    for (const char *p = s; *p; ++p) {
        if (!isdigit((unsigned char)*p)) {
            fprintf(stderr, "error: invalid value '%s' for '%s <%s>': invalid digit found in string\n\n", s, flag, meta);
            fprintf(stderr, "For more information, try '--help'.\n");
            exit(2);
        }
    }
    errno = 0;
    long v = strtol(s, NULL, 10);
    if (errno || v > 2147483647L) v = 2147483647L;
    *out = (int)v;
    return true;
}

static bool file_exists(const char *path) {
    struct stat st;
    return stat(path, &st) == 0 && S_ISREG(st.st_mode);
}

static bool looks_like_option(const char *s) {
    return s[0] == '-' && s[1] != '\0' && !isdigit((unsigned char)s[1]);
}

static const char *need_value(int argc, char **argv, int *i, const char *flag, const char *meta) {
    if (*i + 1 >= argc || looks_like_option(argv[*i + 1])) {
        usage_error_missing(flag, meta);
        exit(2);
    }
    (*i)++;
    return argv[*i];
}

static Options parse_args(int argc, char **argv) {
    Options o;
    memset(&o, 0, sizeof(o));
    strcpy(o.n_value, "2");
    o.top = 50;
    o.combi = 2;
    o.rep = 3;
    o.wpm = 40;
    o.acc = 94;

    for (int i = 1; i < argc; ++i) {
        const char *a = argv[i];
        const char *eq = strchr(a, '=');
        char optbuf[64];
        const char *inline_value = NULL;
        if (eq && strncmp(a, "--", 2) == 0) {
            size_t optlen = (size_t)(eq - a);
            if (optlen < sizeof(optbuf)) {
                memcpy(optbuf, a, optlen);
                optbuf[optlen] = '\0';
                a = optbuf;
                inline_value = eq + 1;
            }
        }
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            print_help();
            exit(0);
        } else if (!strcmp(a, "-n") || !strcmp(a, "--n")) {
            const char *v = inline_value ? inline_value : need_value(argc, argv, &i, a, "2|3|4|w|file");
            snprintf(o.n_value, sizeof(o.n_value), "%s", v);
        } else if (!strcmp(a, "-t") || !strcmp(a, "--top")) {
            parse_int_value(inline_value ? inline_value : need_value(argc, argv, &i, a, "1-200"), a, "1-200", &o.top);
        } else if (!strcmp(a, "-c") || !strcmp(a, "--combi")) {
            parse_int_value(inline_value ? inline_value : need_value(argc, argv, &i, a, "1-200"), a, "1-200", &o.combi);
        } else if (!strcmp(a, "-r") || !strcmp(a, "--rep")) {
            parse_int_value(inline_value ? inline_value : need_value(argc, argv, &i, a, "number"), a, "number", &o.rep);
        } else if (!strcmp(a, "-w") || !strcmp(a, "--wpm")) {
            parse_int_value(inline_value ? inline_value : need_value(argc, argv, &i, a, "number"), a, "number", &o.wpm);
        } else if (!strcmp(a, "-a") || !strcmp(a, "--acc")) {
            parse_int_value(inline_value ? inline_value : need_value(argc, argv, &i, a, "0-100"), a, "0-100", &o.acc);
        } else if (!strcmp(a, "--emu-in")) {
            snprintf(o.emu_in, sizeof(o.emu_in), "%s", inline_value ? inline_value : need_value(argc, argv, &i, a, "layout"));
        } else if (!strcmp(a, "--emu-out")) {
            snprintf(o.emu_out, sizeof(o.emu_out), "%s", inline_value ? inline_value : need_value(argc, argv, &i, a, "layout"));
        } else if (!strcmp(a, "--show-ortho")) {
            o.show_ortho = true;
        } else if (!strcmp(a, "--nokb")) {
            o.nokb = true;
        } else if (!strcmp(a, "--cat")) {
            o.cat = true;
        } else {
            usage_error_unexpected(a);
            exit(2);
        }
    }

    if (strcmp(o.n_value, "2") && strcmp(o.n_value, "3") && strcmp(o.n_value, "4") && strcmp(o.n_value, "w")) {
        if (!file_exists(o.n_value)) {
            fprintf(stderr, "File not found: %s\n", o.n_value);
            exit(1);
        }
    }
    if (o.top < 1 || o.top > 200) {
        fprintf(stderr, "Invalid argument for top. Use a number between 1 and 200.\n");
        exit(1);
    }
    if (o.combi < 1 || o.combi > 200) {
        fprintf(stderr, "Invalid argument for combi. Use a number between 1 and 200.\n");
        exit(1);
    }
    if (o.rep < 1 || o.rep > 200) {
        fprintf(stderr, "Invalid argument for rep. Use a number between 1 and 200.\n");
        exit(1);
    }
    if (o.wpm < 1 || o.wpm > 200) {
        fprintf(stderr, "Invalid argument for wpm. Use a number between 1 and 200.\n");
        exit(1);
    }
    if (o.acc < 0 || o.acc > 100) {
        fprintf(stderr, "Invalid argument for acc. Use a number between 0 and 100.\n");
        exit(1);
    }
    if ((o.emu_in[0] && !o.emu_out[0]) || (!o.emu_in[0] && o.emu_out[0])) {
        fprintf(stderr, "You need to specify both emu_in and emu_out.\n");
        exit(1);
    }
    return o;
}

static char **load_file_words(const char *path, int *count) {
    FILE *f = fopen(path, "r");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = calloc((size_t)n + 1, 1);
    if (!buf) {
        fclose(f);
        return NULL;
    }
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = '\0';
    fclose(f);

    int cap = 32;
    char **items = calloc((size_t)cap, sizeof(char *));
    char *tok = strtok(buf, ", \r\n\t");
    while (tok) {
        if (*count >= cap) {
            cap *= 2;
            items = realloc(items, (size_t)cap * sizeof(char *));
        }
        items[*count] = strdup(tok);
        (*count)++;
        tok = strtok(NULL, ", \r\n\t");
    }
    free(buf);
    return items;
}

static const char *pick_item(const Options *o, int index, char ***owned, int *owned_count) {
    const char **list = bigrams;
    int count = (int)(sizeof(bigrams) / sizeof(bigrams[0]));
    if (!strcmp(o->n_value, "3")) {
        list = trigrams;
        count = (int)(sizeof(trigrams) / sizeof(trigrams[0]));
    } else if (!strcmp(o->n_value, "4")) {
        list = tetragrams;
        count = (int)(sizeof(tetragrams) / sizeof(tetragrams[0]));
    } else if (!strcmp(o->n_value, "w")) {
        list = words;
        count = (int)(sizeof(words) / sizeof(words[0]));
    } else if (strcmp(o->n_value, "2")) {
        if (!*owned) *owned = load_file_words(o->n_value, owned_count);
        if (*owned && *owned_count > 0) return (*owned)[index % *owned_count];
        return "";
    }
    int limit = o->top < count ? o->top : count;
    if (limit < 1) limit = 1;
    return list[index % limit];
}

static void draw_keyboard(bool ortho, bool cat) {
    if (cat) {
        puts("        /\\_/\\\\");
        puts("       ( o.o )");
        puts("        > ^ <");
        return;
    }
    if (ortho) {
        puts("  q w e r t y u i o p");
        puts("  a s d f g h j k l ;");
        puts("  z x c v b n m , . /");
    } else {
        puts("  q w e r t y u i o p");
        puts("   a s d f g h j k l ;");
        puts("    z x c v b n m , . /");
    }
}

static void draw_screen(const Options *o, const char *target, int lesson, int ok, int bad, int pos, int total) {
    printf("\033[2J\033[1;1H");
    puts("╭─────────────────────────────────────────────────────────────────Quit \033[1m\033[38;5;4m<esc> \033[22m\033[39m╮");
    puts("│                    \033[1m               ngrrram!\033[22m\033[3m\033[38;5;7m   by winterveil\033[23m\033[39m│");
    puts("│─────────────────────────────────────────────────────────────────────────────│");
    printf("│     Lesson  #%d                                                   \033[38;5;2m✔: %d, \033[38;5;1m✘: %d    \033[39m│\n", lesson, ok, bad);
    puts("│─────────────────────────────────────────────────────────────────────────────│");
    puts("│                                                                             │");
    printf("│                                      \033[1m%s\033[22m\n", target);
    printf("│                                      \033[3m\033[38;5;7m%*s\033[23m\033[39m\n", pos + 1, "^");
    puts("│                                                                             │");
    puts("│─────────────────────────────────────────────────────────────────────────────│");
    printf("│\033[38;5;7m  need >= %3dWPM,   avg. \033[39m0WPM\033[38;5;7m,   last\033[39m0WPM                         │\n", o->wpm);
    printf("│\033[38;5;7m  need >= %3d%% Acc, avg. \033[39m%d%% Acc\033[38;5;7m, last\033[39m%d%% Acc                       │\n", o->acc, total ? ok * 100 / total : 0, total ? ok * 100 / total : 0);
    puts("╰─────────────────────────────────────────────────────────────────────────────╯\033[39m\033[49m\033[0m");
    if (!o->nokb) draw_keyboard(o->show_ortho, o->cat);
    fflush(stdout);
}

static void terminal_error(void) {
    fprintf(stderr, "\033[?1049hError: Os { code: 6, kind: Uncategorized, message: \"No such device or address\" }\n");
}

static volatile sig_atomic_t stop_now = 0;
static void on_signal(int sig) {
    (void)sig;
    stop_now = 1;
}

static int run_tui(const Options *o) {
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        terminal_error();
        return 1;
    }
    struct termios oldt, raw;
    if (tcgetattr(STDIN_FILENO, &oldt) != 0) {
        terminal_error();
        return 1;
    }
    raw = oldt;
    raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    printf("\033[?1049h\033[?25h");
    int lesson = 1, ok = 0, bad = 0, total = 0, pos = 0;
    char **owned = NULL;
    int owned_count = 0;
    int item_index = 0;
    char target[4096];

    while (!stop_now) {
        target[0] = '\0';
        int used = o->combi * o->rep;
        if (used < 1) used = 1;
        for (int i = 0; i < used; ++i) {
            const char *item = pick_item(o, item_index + (i % o->combi), &owned, &owned_count);
            strncat(target, item, sizeof(target) - strlen(target) - 2);
            strncat(target, " ", sizeof(target) - strlen(target) - 1);
        }
        size_t len = strlen(target);
        if (len && target[len - 1] == ' ') target[len - 1] = '\0';
        if (!target[0]) strcpy(target, "the");
        pos = 0;
        draw_screen(o, target, lesson, ok, bad, pos, total);
        while (!stop_now && target[pos]) {
            unsigned char ch;
            ssize_t r = read(STDIN_FILENO, &ch, 1);
            if (r <= 0) {
                draw_screen(o, target, lesson, ok, bad, pos, total);
                continue;
            }
            if (ch == 27 || ch == 3) {
                stop_now = 1;
                break;
            }
            if (ch == '\r') ch = '\n';
            if (ch == (unsigned char)target[pos]) ok++; else bad++;
            total++;
            pos++;
            draw_screen(o, target, lesson, ok, bad, pos, total);
        }
        lesson++;
        item_index += o->combi;
    }

    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    printf("\033[?1049l\033[?25h");
    fflush(stdout);
    if (owned) {
        for (int i = 0; i < owned_count; ++i) free(owned[i]);
        free(owned);
    }
    return 0;
}

int main(int argc, char **argv) {
    Options options = parse_args(argc, argv);
    return run_tui(&options);
}
