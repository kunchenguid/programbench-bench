#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/wait.h>
#include <unistd.h>

static const char *version = "2.6.0-g87c9c25";

static void print_help(void) {
    printf("tig %s \n\n", version);
    puts("Usage: tig        [options] [revs] [--] [paths]");
    puts("   or: tig log    [options] [revs] [--] [paths]");
    puts("   or: tig show   [options] [revs] [--] [paths]");
    puts("   or: tig reflog [options] [revs]");
    puts("   or: tig blame  [options] [rev] [--] path");
    puts("   or: tig grep   [options] [pattern]");
    puts("   or: tig refs   [options]");
    puts("   or: tig stash  [options]");
    puts("   or: tig status");
    puts("   or: tig <      [git command output]");
    puts("");
    puts("Options:");
    puts("  +<number>       Select line <number> in the first view");
    puts("  -v, --version   Show version and exit");
    puts("  -h, --help      Show help message and exit");
    puts("  -C <path>       Start in <path>");
}

static void print_version(void) {
    printf("tig version %s\n", version);
    puts("ncursesw version 6.3.20211021");
}

static int is_command(const char *s) {
    const char *cmds[] = {"log", "show", "reflog", "blame", "grep", "refs", "stash", "status", NULL};
    for (int i = 0; cmds[i]; i++) {
        if (strcmp(s, cmds[i]) == 0)
            return 1;
    }
    return 0;
}

static int stdin_has_data(void) {
    if (isatty(STDIN_FILENO))
        return 0;
    fd_set set;
    struct timeval tv;
    FD_ZERO(&set);
    FD_SET(STDIN_FILENO, &set);
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    int r = select(STDIN_FILENO + 1, &set, NULL, NULL, &tv);
    return r > 0 && FD_ISSET(STDIN_FILENO, &set);
}

static int copy_stdin(void) {
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), stdin)) > 0) {
        if (fwrite(buf, 1, n, stdout) != n)
            return 1;
    }
    return ferror(stdin) ? 1 : 0;
}

static char *shell_quote(const char *s) {
    size_t len = 3;
    for (const char *p = s; *p; p++)
        len += (*p == '\'') ? 4 : 1;
    char *out = malloc(len);
    if (!out) {
        perror("tig");
        exit(1);
    }
    char *q = out;
    *q++ = '\'';
    for (const char *p = s; *p; p++) {
        if (*p == '\'') {
            memcpy(q, "'\\''", 4);
            q += 4;
        } else {
            *q++ = *p;
        }
    }
    *q++ = '\'';
    *q = '\0';
    return out;
}

static int append(char **cmd, size_t *cap, const char *text) {
    size_t need = strlen(*cmd) + strlen(text) + 1;
    if (need > *cap) {
        while (need > *cap)
            *cap *= 2;
        char *next = realloc(*cmd, *cap);
        if (!next)
            return 0;
        *cmd = next;
    }
    strcat(*cmd, text);
    return 1;
}

static int run_git(int argc, char **argv, const char *subcmd) {
    const char *gitcmd = "log --oneline --decorate --graph";
    int start = 0;
    if (subcmd) {
        start = 1;
        if (strcmp(subcmd, "log") == 0)
            gitcmd = "log --stat";
        else if (strcmp(subcmd, "show") == 0)
            gitcmd = "show --stat --patch";
        else if (strcmp(subcmd, "reflog") == 0)
            gitcmd = "reflog";
        else if (strcmp(subcmd, "blame") == 0)
            gitcmd = "blame";
        else if (strcmp(subcmd, "grep") == 0)
            gitcmd = "grep -n";
        else if (strcmp(subcmd, "refs") == 0)
            gitcmd = "show-ref --head";
        else if (strcmp(subcmd, "stash") == 0)
            gitcmd = "stash list";
        else if (strcmp(subcmd, "status") == 0)
            gitcmd = "status --short --branch";
    }

    size_t cap = 256;
    char *cmd = malloc(cap);
    if (!cmd)
        return 1;
    snprintf(cmd, cap, "git %s", gitcmd);

    for (int i = start; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            print_help();
            free(cmd);
            return 0;
        }
        if (argv[i][0] == '+' && argv[i][1]) {
            char *end = NULL;
            strtol(argv[i] + 1, &end, 10);
            if (end && *end == '\0')
                continue;
        }
        char *q = shell_quote(argv[i]);
        if (!append(&cmd, &cap, " ") || !append(&cmd, &cap, q)) {
            free(q);
            free(cmd);
            return 1;
        }
        free(q);
    }

    int rc = system(cmd);
    free(cmd);
    if (rc == -1)
        return 1;
    if (WIFEXITED(rc))
        return WEXITSTATUS(rc);
    return 1;
}

int main(int argc, char **argv) {
    int outc = 0;
    char **outv = calloc((size_t)argc + 1, sizeof(char *));
    if (!outv)
        return 1;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-C") == 0) {
            if (i + 1 < argc) {
                if (chdir(argv[++i]) != 0) {
                    fprintf(stderr, "tig: Failed to change directory to %s\n", argv[i]);
                    free(outv);
                    return 1;
                }
            }
            continue;
        }
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            print_help();
            free(outv);
            return 0;
        }
        if (strcmp(argv[i], "--version") == 0 || strcmp(argv[i], "-v") == 0) {
            print_version();
            free(outv);
            return 0;
        }
        outv[outc++] = argv[i];
    }

    const char *subcmd = outc > 0 && is_command(outv[0]) ? outv[0] : NULL;
    if (subcmd && strcmp(subcmd, "status") == 0 && outc > 1) {
        fprintf(stderr, "tig: No revisions match the given arguments.\n");
        free(outv);
        return 1;
    }
    if (outc > 0 && !subcmd && outv[0][0] != '-') {
        fprintf(stderr, "tig: No revisions match the given arguments.\n");
        free(outv);
        return 1;
    }

    if (!isatty(STDIN_FILENO)) {
        fprintf(stderr, "tig: Failed to open tty for input\n");
        free(outv);
        return 1;
    }

    if (stdin_has_data() && outc == 0) {
        int rc = copy_stdin();
        free(outv);
        return rc;
    }

    int rc = run_git(outc, outv, subcmd);
    int had_plain_args = outc > 0 && !subcmd;
    free(outv);
    if (rc != 0 && had_plain_args) {
        fprintf(stderr, "tig: No revisions match the given arguments.\n");
        return 1;
    }
    return rc;
}
