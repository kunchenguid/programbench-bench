#!/usr/bin/env python3
import os
import re
import shlex
import sys


EDITORS = [
    "vim", "neovim", "nvim", "nano", "code", "vscode", "code-insiders",
    "emacs", "emacsclient", "hx", "helix", "subl", "sublime-text",
    "micro", "intellij", "goland", "pycharm", "less", "fresh",
]
THEMES = ["light", "dark"]
VIEWERS = ["none", "vertical", "horizontal"]
SORTS = ["path", "modified", "created", "accessed"]


HELP = """Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
"""


def load_type_list():
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "type-list.txt"), "r", encoding="utf-8") as f:
        return f.read()


def type_names():
    return {line.split(":", 1)[0] for line in load_type_list().splitlines() if ":" in line}


def eprint(msg):
    sys.stderr.write(msg)
    if not msg.endswith("\n"):
        sys.stderr.write("\n")


def clap_error(message, usage=True, tip=None):
    eprint(f"error: {message}\n\n")
    if tip:
        eprint(f"  tip: {tip}\n\n")
    if usage:
        eprint("Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\n")
    eprint("For more information, try '--help'.")
    return 2


def invalid_value(opt, meta, value, possibles):
    eprint(f"error: invalid value '{value}' for '{opt} <{meta}>'")
    eprint(f"  [possible values: {', '.join(possibles)}]\n\n")
    eprint("For more information, try '--help'.")
    return 2


def need_value(opt, meta):
    eprint(f"error: a value is required for '{opt} <{meta}>' but none was supplied\n\n")
    eprint("For more information, try '--help'.")
    return 2


def validate_custom(command):
    if command is None:
        command = os.environ.get("IGREP_CUSTOM_EDITOR")
    if not command:
        return None
    try:
        parts = shlex.split(command)
    except ValueError:
        parts = command.split()
    reason = None
    if len(parts) < 2:
        reason = "Expected program and its arguments"
    elif command.count("{file_name}") != 1 or parts[0] == "{file_name}":
        reason = "Expected one occurrence of '{file_name}'."
    elif command.count("{line_number}") != 1:
        reason = "Expected one occurrence of '{line_number}'."
    if reason:
        eprint(f"Error: Incorrect editor command: '{command}'\n\n")
        eprint("Caused by:")
        eprint(f"    {reason}")
        return 1
    return None


def parse(argv):
    opts = {
        "type_list": False,
        "custom": None,
        "types": [],
        "type_nots": [],
    }
    positionals = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            positionals.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print(HELP, end="")
            return None, 0
        if a in ("-V", "--version"):
            print("igrep 1.3.0")
            return None, 0
        if a == "--type-list":
            opts["type_list"] = True
        elif a in ("--editor", "--theme", "--custom-command", "-g", "--glob",
                   "-t", "--type", "-T", "--type-not", "--context-viewer",
                   "--sort", "--sortr"):
            metas = {
                "--editor": "EDITOR", "--theme": "THEME",
                "--custom-command": "CUSTOM_COMMAND", "-g": "GLOB",
                "--glob": "GLOB", "-t": "TYPE_MATCHING",
                "--type": "TYPE_MATCHING", "-T": "TYPE_NOT",
                "--type-not": "TYPE_NOT", "--context-viewer": "CONTEXT_VIEWER",
                "--sort": "SORT_BY", "--sortr": "SORT_BY_REVERSE",
            }
            if i + 1 >= len(argv):
                return None, need_value(a, metas[a])
            val = argv[i + 1]
            i += 1
            if a == "--editor" and val not in EDITORS:
                return None, invalid_value("--editor", "EDITOR", val, EDITORS)
            if a == "--theme" and val not in THEMES:
                return None, invalid_value("--theme", "THEME", val, THEMES)
            if a == "--context-viewer" and val not in VIEWERS:
                return None, invalid_value("--context-viewer", "CONTEXT_VIEWER", val, VIEWERS)
            if a == "--sort" and val not in SORTS:
                return None, invalid_value("--sort", "SORT_BY", val, SORTS)
            if a == "--sortr" and val not in SORTS:
                return None, invalid_value("--sortr", "SORT_BY_REVERSE", val, SORTS)
            if a == "--custom-command":
                opts["custom"] = val
            if a in ("-t", "--type"):
                opts["types"].append(val)
            if a in ("-T", "--type-not"):
                opts["type_nots"].append(val)
        elif a.startswith("--"):
            if "=" in a:
                name, val = a.split("=", 1)
                expanded = [name, val]
                rest = expanded + argv[i + 1:]
                return parse(argv[:i] + rest)
            return None, clap_error(
                f"unexpected argument '{a}' found",
                tip=f"to pass '{a}' as a value, use '-- {a}'",
            )
        elif a.startswith("-") and a != "-":
            for ch in a[1:]:
                if ch not in "iS.LwFU":
                    return None, clap_error(f"unexpected argument '-{ch}' found")
        else:
            positionals.append(a)
        i += 1
    opts["positionals"] = positionals
    return opts, None


def main():
    opts, early = parse(sys.argv[1:])
    if early is not None:
        return early
    assert opts is not None

    if opts["type_list"] and opts["positionals"]:
        first = "--type-list" if sys.argv[1:2] == ["--type-list"] else "<PATTERN>"
        second = "<PATTERN>" if first == "--type-list" else "--type-list"
        eprint(f"error: the argument '{first}' cannot be used with '{second}'\n\n")
        eprint("Usage: executable --type-list <PATTERN> [PATHS]...\n\n")
        eprint("For more information, try '--help'.")
        return 2
    if opts["type_list"]:
        print(load_type_list(), end="")
        return 0
    if not opts["positionals"]:
        eprint("error: the following required arguments were not provided:")
        eprint("  --type-list")
        eprint("  <PATTERN>\n\n")
        eprint("Usage: executable --type-list <PATTERN> [PATHS]...\n\n")
        eprint("For more information, try '--help'.")
        return 2

    custom_status = validate_custom(opts["custom"])
    if custom_status is not None:
        return custom_status
    known = type_names()
    for t in opts["types"] + opts["type_nots"]:
        if t not in known:
            eprint(f"Error: unrecognized file type: {t}")
            return 1

    eprint("Error: Resource temporarily unavailable (os error 11)")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
