#!/usr/bin/env python3
import json
import os
import random
import socket
import struct
import sys
import time


HELP = """dog ● command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information"""

VERSION = """dog ● command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
mhttps://dns.lookup.dog/"""

TYPE_BY_NAME = {
    "A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "PTR": 12, "HINFO": 13, "MX": 15,
    "TXT": 16, "AAAA": 28, "SRV": 33, "NAPTR": 35, "CAA": 257, "SSHFP": 44,
    "TLSA": 52, "LOC": 29, "OPT": 41, "ANY": 255, "IXFR": 251, "AXFR": 252,
    "AFSDB": 18,
}
NAME_BY_TYPE = {v: k for k, v in TYPE_BY_NAME.items()}
CLASS_BY_NAME = {"IN": 1, "CH": 3, "HS": 4}
NAME_BY_CLASS = {v: k for k, v in CLASS_BY_NAME.items()}


class DogError(Exception):
    def __init__(self, msg, status=3):
        super().__init__(msg)
        self.status = status


def die_invalid(msg):
    raise DogError("dog: Invalid options: " + msg, 3)


def pop_value(args, i, opt):
    if i + 1 >= len(args):
        die_invalid(f"Argument to option '{opt}' missing")
    return args[i + 1], i + 2


def parse_args(argv):
    cfg = {
        "queries": [], "types": [], "classes": [], "nameservers": [],
        "transport": "udp", "short": False, "json": False, "seconds": False,
        "time": False, "edns": "hide", "txid": None, "tweaks": [], "color": "automatic",
    }
    positional = []
    i = 0
    literal = False
    while i < len(argv):
        a = argv[i]
        if literal:
            positional.append(a); i += 1; continue
        if a == "--":
            literal = True; i += 1; continue
        if a in ("-?", "--help"):
            print(HELP); sys.exit(0)
        if a in ("-v", "--version"):
            print(VERSION); sys.exit(0)
        if a in ("-q", "--query"):
            v, i = pop_value(argv, i, a.lstrip("-")); cfg["queries"].append(v); continue
        if a.startswith("--query="):
            cfg["queries"].append(a.split("=", 1)[1]); i += 1; continue
        if a in ("-t", "--type"):
            v, i = pop_value(argv, i, a.lstrip("-")); cfg["types"].append(parse_type(v)); continue
        if a.startswith("--type="):
            cfg["types"].append(parse_type(a.split("=", 1)[1])); i += 1; continue
        if a in ("-n", "--nameserver"):
            v, i = pop_value(argv, i, a.lstrip("-")); cfg["nameservers"].append(v); continue
        if a.startswith("--nameserver="):
            cfg["nameservers"].append(a.split("=", 1)[1]); i += 1; continue
        if a == "--class":
            v, i = pop_value(argv, i, "class"); cfg["classes"].append(parse_class(v)); continue
        if a.startswith("--class="):
            cfg["classes"].append(parse_class(a.split("=", 1)[1])); i += 1; continue
        if a == "--edns":
            v, i = pop_value(argv, i, "edns"); cfg["edns"] = parse_edns(v); continue
        if a.startswith("--edns="):
            cfg["edns"] = parse_edns(a.split("=", 1)[1]); i += 1; continue
        if a == "--txid":
            v, i = pop_value(argv, i, "txid"); cfg["txid"] = parse_txid(v); continue
        if a.startswith("--txid="):
            cfg["txid"] = parse_txid(a.split("=", 1)[1]); i += 1; continue
        if a == "-Z":
            v, i = pop_value(argv, i, "Z"); cfg["tweaks"].append(parse_tweak(v)); continue
        if a.startswith("-Z="):
            cfg["tweaks"].append(parse_tweak(a.split("=", 1)[1])); i += 1; continue
        if a.startswith("-Z") and len(a) > 2:
            cfg["tweaks"].append(parse_tweak(a[2:])); i += 1; continue
        if a in ("-U", "--udp"):
            cfg["transport"] = "udp"; i += 1; continue
        if a in ("-T", "--tcp"):
            cfg["transport"] = "tcp"; i += 1; continue
        if a in ("-S", "--tls"):
            cfg["transport"] = "tls"; i += 1; continue
        if a in ("-H", "--https"):
            cfg["transport"] = "https"; i += 1; continue
        if a in ("-1", "--short"):
            cfg["short"] = True; i += 1; continue
        if a in ("-J", "--json"):
            cfg["json"] = True; i += 1; continue
        if a == "--seconds":
            cfg["seconds"] = True; i += 1; continue
        if a == "--time":
            cfg["time"] = True; i += 1; continue
        if a in ("--color", "--colour"):
            v, i = pop_value(argv, i, a[2:]); cfg["color"] = v; continue
        if a.startswith("--color=") or a.startswith("--colour="):
            cfg["color"] = a.split("=", 1)[1]; i += 1; continue
        if a.startswith("-"):
            die_invalid(f"Unrecognized option: '{a.lstrip('-')}'")
        positional.append(a); i += 1

    for p in positional:
        up = p.upper()
        if p.startswith("@") and len(p) > 1:
            cfg["nameservers"].append(p[1:])
        elif up in TYPE_BY_NAME:
            cfg["types"].append(TYPE_BY_NAME[up])
        elif up in CLASS_BY_NAME:
            cfg["classes"].append(CLASS_BY_NAME[up])
        else:
            cfg["queries"].append(p)
    if not cfg["queries"]:
        print(HELP)
        sys.exit(3)
    if not cfg["types"]:
        cfg["types"] = [1]
    if not cfg["classes"]:
        cfg["classes"] = [1]
    if not cfg["nameservers"]:
        cfg["nameservers"] = system_nameservers()
    return cfg


def parse_type(s):
    up = s.upper()
    if up in TYPE_BY_NAME:
        return TYPE_BY_NAME[up]
    if up.startswith("TYPE") and up[4:].isdigit():
        return int(up[4:])
    die_invalid(f"Invalid query type \"{s}\"")


def parse_class(s):
    up = s.upper()
    if up in CLASS_BY_NAME:
        return CLASS_BY_NAME[up]
    die_invalid(f"Invalid query class \"{s}\"")


def parse_edns(s):
    if s not in ("disable", "hide", "show"):
        die_invalid(f"Invalid EDNS setting \"{s}\"")
    return s


def parse_txid(s):
    try:
        n = int(s, 0)
    except ValueError:
        die_invalid(f"Invalid transaction ID \"{s}\"")
    if not 0 <= n <= 65535:
        die_invalid(f"Invalid transaction ID \"{s}\"")
    return n


def parse_tweak(s):
    if s in ("aa", "ad", "cd"):
        return s
    if s.startswith("bufsize="):
        try:
            int(s.split("=", 1)[1])
            return s
        except ValueError:
            pass
    die_invalid(f"Invalid protocol tweak \"{s}\"")


def system_nameservers():
    servers = []
    try:
        with open("/etc/resolv.conf", "r", encoding="utf-8") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[0] == "nameserver":
                    servers.append(parts[1])
    except OSError as e:
        raise DogError(f"Error [system]: {e}", 4)
    return servers or ["127.0.0.53"]


def encode_name(name):
    name = name.rstrip(".")
    if not name:
        return b"\0"
    out = bytearray()
    for part in name.split("."):
        b = part.encode("idna")
        out.append(len(b)); out.extend(b)
    out.append(0)
    return bytes(out)


def read_name(data, off, seen=None):
    if seen is None:
        seen = set()
    labels = []
    jumped = False
    start = off
    while True:
        if off >= len(data):
            raise ValueError("name out of range")
        l = data[off]
        if l & 0xC0 == 0xC0:
            ptr = ((l & 0x3F) << 8) | data[off + 1]
            if ptr in seen:
                raise ValueError("compression loop")
            seen.add(ptr)
            sub, _ = read_name(data, ptr, seen)
            labels.append(sub.rstrip("."))
            off += 2
            jumped = True
            break
        off += 1
        if l == 0:
            break
        part = data[off:off + l]
        try:
            labels.append(part.decode("ascii"))
        except UnicodeDecodeError:
            labels.append(part.decode("utf-8", "replace"))
        off += l
    name = ".".join(x for x in labels if x)
    return (name + "." if name else "."), off


def make_query(name, qtype, qclass, txid, cfg):
    flags = 0x0100
    q = encode_name(name) + struct.pack("!HH", qtype, qclass)
    ar = b""
    arcount = 0
    if cfg["edns"] != "disable":
        size = 4096
        for t in cfg["tweaks"]:
            if t.startswith("bufsize="):
                try:
                    size = int(t.split("=", 1)[1])
                except ValueError:
                    pass
        ar = b"\0" + struct.pack("!HHIH", 41, size, 0, 0)
        arcount = 1
    for t in cfg["tweaks"]:
        if t == "aa": flags |= 0x0400
        elif t == "ad": flags |= 0x0020
        elif t == "cd": flags |= 0x0010
    return struct.pack("!HHHHHH", txid, flags, 1, 0, 0, arcount) + q + ar


def split_host_port(ns, default_port):
    if ns.startswith("["):
        end = ns.find("]")
        host = ns[1:end]
        port = int(ns[end + 2:]) if end != -1 and ns[end + 1:end + 2] == ":" else default_port
        return host, port
    if ns.count(":") == 1 and ns.rsplit(":", 1)[1].isdigit():
        h, p = ns.rsplit(":", 1)
        return h, int(p)
    return ns, default_port


def send_dns(packet, ns, transport):
    if transport in ("tls", "https"):
        raise OSError("Network is unreachable")
    host, port = split_host_port(ns, 53)
    if transport == "tcp":
        with socket.create_connection((host, port), timeout=4) as s:
            s.sendall(struct.pack("!H", len(packet)) + packet)
            hdr = recv_exact(s, 2)
            size = struct.unpack("!H", hdr)[0]
            return recv_exact(s, size)
    family = socket.AF_INET6 if ":" in host and not host.replace(":", "").isdigit() else socket.AF_INET
    with socket.socket(family, socket.SOCK_DGRAM) as s:
        s.settimeout(4)
        s.connect((host, port))
        s.send(packet)
        return s.recv(65535)


def recv_exact(s, n):
    b = b""
    while len(b) < n:
        c = s.recv(n - len(b))
        if not c:
            raise OSError("unexpected EOF")
        b += c
    return b


def parse_response(data):
    if len(data) < 12:
        raise ValueError("short packet")
    tid, flags, qd, an, ns, ar = struct.unpack("!HHHHHH", data[:12])
    off = 12
    queries = []
    for _ in range(qd):
        name, off = read_name(data, off)
        qtype, qclass = struct.unpack("!HH", data[off:off + 4]); off += 4
        queries.append({"name": name, "class": class_name(qclass), "type": type_name(qtype)})
    def rr():
        nonlocal off
        name, off = read_name(data, off)
        typ, cls, ttl, rdlen = struct.unpack("!HHIH", data[off:off + 10]); off += 10
        rdata_off = off
        raw = data[off:off + rdlen]; off += rdlen
        return {"name": name, "class": class_name(cls), "ttl": ttl, "type": type_name(typ),
                "data": decode_rdata(typ, data, rdata_off, raw)}
    return {
        "queries": queries,
        "answers": [rr() for _ in range(an)],
        "authorities": [rr() for _ in range(ns)],
        "additionals": [rr() for _ in range(ar)],
        "rcode": flags & 0xF,
    }


def type_name(t):
    return NAME_BY_TYPE.get(t, f"TYPE{t}")


def class_name(c):
    return NAME_BY_CLASS.get(c, f"CLASS{c}")


def decode_rdata(typ, packet, off, raw):
    try:
        if typ == 1 and len(raw) == 4:
            return {"address": socket.inet_ntop(socket.AF_INET, raw)}
        if typ == 28 and len(raw) == 16:
            return {"address": socket.inet_ntop(socket.AF_INET6, raw)}
        if typ in (2, 5, 12):
            n, _ = read_name(packet, off); return {"domain": n}
        if typ == 15:
            pref = struct.unpack("!H", raw[:2])[0]; n, _ = read_name(packet, off + 2)
            return {"preference": pref, "exchange": n}
        if typ == 16:
            vals = []; i = 0
            while i < len(raw):
                l = raw[i]; i += 1; vals.append(raw[i:i + l].decode("utf-8", "replace")); i += l
            return {"texts": vals}
        if typ == 6:
            m, p = read_name(packet, off); r, p = read_name(packet, p)
            nums = struct.unpack("!IIIII", packet[p:p + 20])
            return {"mname": m, "rname": r, "serial": nums[0], "refresh": nums[1], "retry": nums[2], "expire": nums[3], "minimum": nums[4]}
        if typ == 33:
            pr, weight, port = struct.unpack("!HHH", raw[:6]); target, _ = read_name(packet, off + 6)
            return {"priority": pr, "weight": weight, "port": port, "target": target}
    except Exception:
        pass
    return {"bytes": list(raw)}


def ttl_text(ttl, seconds=False):
    if seconds:
        return str(ttl)
    if ttl < 60:
        return f"{ttl}s"
    m, s = divmod(ttl, 60)
    if m < 60:
        return f"{m}m{s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m{s:02d}s"


def human_data(rr):
    d = rr["data"]; typ = rr["type"]
    if "address" in d: return d["address"]
    if typ in ("NS", "CNAME", "PTR") and "domain" in d: return d["domain"]
    if typ == "MX" and "exchange" in d: return f'{d["preference"]} "{d["exchange"]}"'
    if typ == "TXT" and "texts" in d: return " ".join(json.dumps(t) for t in d["texts"])
    if typ == "SOA" and "mname" in d: return f'{d["mname"]} {d["rname"]} {d["serial"]}'
    if typ == "SRV" and "target" in d: return f'{d["priority"]} {d["weight"]} {d["port"]} {d["target"]}'
    if "bytes" in d: return " ".join(str(x) for x in d["bytes"])
    return json.dumps(d, separators=(",", ":"))


def print_table(responses, cfg):
    rows = []
    for resp in responses:
        for section in ("answers", "authorities", "additionals"):
            for rr in resp[section]:
                if rr["type"] == "OPT" and cfg["edns"] != "show":
                    continue
                rows.append((rr["type"], rr["name"], ttl_text(rr["ttl"], cfg["seconds"]), human_data(rr)))
    if cfg["short"]:
        if rows:
            print(rows[0][3])
            return 0
        print("No results")
        return 2
    if not rows:
        return 0
    w = max(len(r[0]) for r in rows)
    for typ, name, ttl, data in rows:
        print(f"{typ.rjust(w)} {name} {ttl:<7} {data}")
    return 0


def main(argv):
    try:
        cfg = parse_args(argv)
    except DogError as e:
        print(str(e), file=sys.stderr)
        return e.status
    responses = []
    status = 0
    first_error = None
    start_all = time.time()
    for q in cfg["queries"]:
        for typ in cfg["types"]:
            for cls in cfg["classes"]:
                for ns in cfg["nameservers"]:
                    txid = cfg["txid"] if cfg["txid"] is not None else random.randrange(65536)
                    pkt = make_query(q, typ, cls, txid, cfg)
                    try:
                        data = send_dns(pkt, ns, cfg["transport"])
                        responses.append(parse_response(data))
                    except Exception as e:
                        first_error = e
                        status = 1
                        break
                if first_error: break
            if first_error: break
        if first_error: break
    if first_error:
        msg = os.strerror(first_error.errno) + f" (os error {first_error.errno})" if isinstance(first_error, OSError) and first_error.errno else str(first_error)
        if cfg["json"]:
            print(json.dumps({"error": True, "error_phase": "network", "error_message": msg}, separators=(",", ":")))
        else:
            print(f"Error [network]: {msg}", file=sys.stderr)
    if cfg["json"]:
        print(json.dumps({"responses": json_ready(responses)}, separators=(",", ":")))
    else:
        st = print_table(responses, cfg)
        if st:
            status = st
    if cfg["time"]:
        elapsed = time.time() - start_all
        print(f"Time: {elapsed:.3f}s")
    return status


def json_ready(responses):
    out = []
    for r in responses:
        rr = {k: r[k] for k in ("queries", "answers", "authorities", "additionals")}
        out.append(rr)
    return out


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
