#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    bool seconds, screensaver, box, center, bold, twelve, utc, rebound;
    bool noquit, hide_date, blink;
    int color;
    int delay_s;
    long delay_ns;
    const char *date_fmt;
} Options;

static struct termios saved_term;
static bool term_saved = false;
static volatile sig_atomic_t running = 1;

static const char *digits[10][5] = {
    {"111111", "11  11", "11  11", "11  11", "111111"},
    {"  11  ", "1111  ", "  11  ", "  11  ", "111111"},
    {"111111", "    11", "111111", "11    ", "111111"},
    {"111111", "    11", "111111", "    11", "111111"},
    {"11  11", "11  11", "111111", "    11", "    11"},
    {"111111", "11    ", "111111", "    11", "111111"},
    {"111111", "11    ", "111111", "11  11", "111111"},
    {"111111", "    11", "    11", "    11", "    11"},
    {"111111", "11  11", "111111", "11  11", "111111"},
    {"111111", "11  11", "111111", "    11", "111111"},
};

static void usage(FILE *out) {
    fprintf(out, "usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] \n");
    fprintf(out, "    -s            Show seconds                                   \n");
    fprintf(out, "    -S            Screensaver mode                               \n");
    fprintf(out, "    -x            Show box                                       \n");
    fprintf(out, "    -c            Set the clock at the center of the terminal    \n");
    fprintf(out, "    -C [0-7]      Set the clock color                            \n");
    fprintf(out, "    -b            Use bold colors                                \n");
    fprintf(out, "    -t            Set the hour in 12h format                     \n");
    fprintf(out, "    -u            Use UTC time                                   \n");
    fprintf(out, "    -T tty        Display the clock on the specified terminal    \n");
    fprintf(out, "    -r            Do rebound the clock                           \n");
    fprintf(out, "    -f format     Set the date format                            \n");
    fprintf(out, "    -n            Don't quit on keypress                         \n");
    fprintf(out, "    -v            Show tty-clock version                         \n");
    fprintf(out, "    -i            Show some info about tty-clock                 \n");
    fprintf(out, "    -h            Show this page                                 \n");
    fprintf(out, "    -D            Hide date                                      \n");
    fprintf(out, "    -B            Enable blinking colon                          \n");
    fprintf(out, "    -d delay      Set the delay between two redraws of the clock. Default 1s. \n");
    fprintf(out, "    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.\n");
}

static void restore(void) {
    if (term_saved) {
        tcsetattr(STDIN_FILENO, TCSANOW, &saved_term);
    }
    printf("\033[?25h\033[0m\033[?1049l");
    fflush(stdout);
}

static void on_signal(int sig) {
    (void)sig;
    running = 0;
}

static void raw_mode(void) {
    struct termios t;
    if (tcgetattr(STDIN_FILENO, &saved_term) == 0) {
        term_saved = true;
        t = saved_term;
        t.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        t.c_cc[VMIN] = 0;
        t.c_cc[VTIME] = 0;
        tcsetattr(STDIN_FILENO, TCSANOW, &t);
    }
}

static int need_arg(int argc, char **argv, int *i, char opt) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "%s: option requires an argument -- '%c'\n", argv[0], opt);
        usage(stderr);
        exit(0);
    }
    (*i)++;
    return *i;
}

static void check_tty(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) {
        fprintf(stderr, "tty-clock: error: couldn't stat '%s': %s.\n", path, strerror(errno));
        exit(1);
    }
    if (!S_ISCHR(st.st_mode)) {
        fprintf(stderr, "tty-clock: error: '%s' doesn't appear to be a tty.\n", path);
        exit(1);
    }
    if (access(path, R_OK | W_OK) != 0) {
        fprintf(stderr, "tty-clock: error: couldn't access '%s': %s.\n", path, strerror(errno));
        exit(1);
    }
}

static Options parse(int argc, char **argv) {
    Options o = {0};
    o.color = 2;
    o.delay_s = 1;
    o.delay_ns = 0;
    o.date_fmt = "%F";

    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (a[0] != '-' || strcmp(a, "-") == 0) {
            continue;
        }
        if (a[1] == '-') {
            fprintf(stderr, "%s: invalid option -- '-'\n", argv[0]);
            usage(stderr);
            exit(0);
        }
        for (int j = 1; a[j]; j++) {
            switch (a[j]) {
            case 's': o.seconds = true; break;
            case 'S': o.screensaver = true; break;
            case 'x': o.box = true; break;
            case 'c': o.center = true; break;
            case 'b': o.bold = true; break;
            case 't': o.twelve = true; break;
            case 'u': o.utc = true; break;
            case 'r': o.rebound = true; break;
            case 'n': o.noquit = true; break;
            case 'D': o.hide_date = true; break;
            case 'B': o.blink = true; break;
            case 'v':
                puts("TTY-Clock 2 © devel version");
                exit(0);
            case 'i':
                puts("TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)");
                exit(0);
            case 'h':
                usage(stdout);
                exit(0);
            case 'C': {
                int k = need_arg(argc, argv, &i, 'C');
                o.color = isdigit((unsigned char)argv[k][0]) ? atoi(argv[k]) : 0;
                if (o.color < 0 || o.color > 7) o.color = 2;
                j = (int)strlen(a) - 1;
                break;
            }
            case 'f': {
                int k = need_arg(argc, argv, &i, 'f');
                o.date_fmt = argv[k];
                j = (int)strlen(a) - 1;
                break;
            }
            case 'd': {
                int k = need_arg(argc, argv, &i, 'd');
                o.delay_s = atoi(argv[k]);
                if (o.delay_s < 0) o.delay_s = 0;
                j = (int)strlen(a) - 1;
                break;
            }
            case 'a': {
                int k = need_arg(argc, argv, &i, 'a');
                o.delay_ns = atol(argv[k]);
                if (o.delay_ns < 0) o.delay_ns = 0;
                j = (int)strlen(a) - 1;
                break;
            }
            case 'T': {
                int k = need_arg(argc, argv, &i, 'T');
                check_tty(argv[k]);
                j = (int)strlen(a) - 1;
                break;
            }
            default:
                fprintf(stderr, "%s: invalid option -- '%c'\n", argv[0], a[j]);
                usage(stderr);
                exit(0);
            }
        }
    }
    return o;
}

static void term_size(int *rows, int *cols) {
    struct winsize ws;
    *rows = 24;
    *cols = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row && ws.ws_col) {
        *rows = ws.ws_row;
        *cols = ws.ws_col;
    }
}

static void move_to(int y, int x) {
    printf("\033[%d;%dH", y, x);
}

static void color_on(const Options *o) {
    if (o->bold) printf("\033[1m");
    printf("\033[%dm", 40 + o->color);
}

static void color_text(const Options *o) {
    if (o->bold) printf("\033[1m");
    printf("\033[%dm", 30 + o->color);
}

static void draw_digit(int y, int x, int d, const Options *o) {
    for (int r = 0; r < 5; r++) {
        move_to(y + r, x);
        for (int c = 0; c < 6; c++) {
            if (digits[d][r][c] == '1') {
                color_on(o);
                putchar(' ');
            } else {
                printf("\033[0m ");
            }
        }
        printf("\033[0m");
    }
}

static void draw_colon(int y, int x, const Options *o, bool visible) {
    for (int r = 0; r < 5; r++) {
        move_to(y + r, x);
        if (visible && (r == 1 || r == 3)) {
            color_on(o);
            printf("  \033[0m");
        } else {
            printf("  ");
        }
    }
}

static void draw_box(int y, int x, int h, int w) {
    move_to(y, x);
    putchar('+');
    for (int i = 0; i < w - 2; i++) putchar('-');
    putchar('+');
    for (int r = 1; r < h - 1; r++) {
        move_to(y + r, x);
        putchar('|');
        move_to(y + r, x + w - 1);
        putchar('|');
    }
    move_to(y + h - 1, x);
    putchar('+');
    for (int i = 0; i < w - 2; i++) putchar('-');
    putchar('+');
}

static int read_key(const Options *o) {
    fd_set set;
    struct timeval tv = {0, 0};
    FD_ZERO(&set);
    FD_SET(STDIN_FILENO, &set);
    if (select(STDIN_FILENO + 1, &set, NULL, NULL, &tv) > 0) {
        unsigned char ch;
        if (read(STDIN_FILENO, &ch, 1) == 1) {
            if (o->screensaver && !o->noquit) return 'q';
            return tolower(ch);
        }
    }
    return 0;
}

static void render(const Options *o, int *py, int *px, int *dy, int *dx, bool colon) {
    int rows, cols;
    term_size(&rows, &cols);

    time_t now = time(NULL);
    struct tm tmv;
    if (o->utc) {
        gmtime_r(&now, &tmv);
    } else {
        localtime_r(&now, &tmv);
    }

    char tbuf[16];
    int hour = tmv.tm_hour;
    if (o->twelve) {
        hour %= 12;
        if (hour == 0) hour = 12;
    }
    if (o->seconds) {
        snprintf(tbuf, sizeof(tbuf), "%02d:%02d:%02d", hour, tmv.tm_min, tmv.tm_sec);
    } else {
        snprintf(tbuf, sizeof(tbuf), "%02d:%02d", hour, tmv.tm_min);
    }

    int glyphs = o->seconds ? 6 : 4;
    int colons = o->seconds ? 2 : 1;
    int clock_w = glyphs * 6 + colons * 2 + (glyphs + colons - 1);
    int clock_h = 5;
    int total_h = clock_h + (o->hide_date ? 0 : 2);
    int total_w = clock_w;
    int base_y = *py, base_x = *px;
    if (o->center) {
        base_y = (rows - total_h) / 2 + 1;
        base_x = (cols - total_w) / 2 + 1;
    } else if (o->rebound) {
        base_y += *dy;
        base_x += *dx;
        if (base_y < 1 || base_y + total_h + (o->box ? 2 : 0) > rows) {
            *dy = -*dy;
            base_y += 2 * *dy;
        }
        if (base_x < 1 || base_x + total_w + (o->box ? 2 : 0) > cols) {
            *dx = -*dx;
            base_x += 2 * *dx;
        }
        *py = base_y;
        *px = base_x;
    }
    if (base_y < 1) base_y = 1;
    if (base_x < 1) base_x = 1;

    int inner_y = base_y, inner_x = base_x;
    printf("\033[H\033[2J");
    if (o->box) {
        draw_box(base_y, base_x, total_h + 2, total_w + 2);
        inner_y++;
        inner_x++;
    }

    int x = inner_x;
    for (size_t i = 0; i < strlen(tbuf); i++) {
        if (isdigit((unsigned char)tbuf[i])) {
            draw_digit(inner_y, x, tbuf[i] - '0', o);
            x += 7;
        } else if (tbuf[i] == ':') {
            draw_colon(inner_y, x, o, colon);
            x += 3;
        }
    }

    if (!o->hide_date) {
        char dbuf[256];
        if (strftime(dbuf, sizeof(dbuf), o->date_fmt, &tmv) == 0) dbuf[0] = '\0';
        color_text(o);
        move_to(inner_y + 6, inner_x + (total_w - (int)strlen(dbuf)) / 2);
        fputs(dbuf, stdout);
        printf("\033[0m");
    }
    fflush(stdout);
}

int main(int argc, char **argv) {
    Options o = parse(argc, argv);
    const char *term = getenv("TERM");
    if (!term || strcmp(term, "unknown") == 0 || term[0] == '\0') {
        fprintf(stderr, "Error opening terminal: unknown.\n");
        return 1;
    }

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    atexit(restore);
    raw_mode();
    printf("\033[?1049h\033[?25l");

    int y = 1, x = 1, dy = 1, dx = 1;
    bool colon = true;
    while (running) {
        render(&o, &y, &x, &dy, &dx, colon);
        if (o.blink) colon = !colon;

        long total_ns = (long)o.delay_s * 1000000000L + o.delay_ns;
        if (total_ns <= 0) total_ns = 10000000L;
        struct timespec step = {0, 50000000L};
        long waited = 0;
        while (running && waited < total_ns) {
            int ch = read_key(&o);
            if (ch) {
                if (ch == 'q' && !o.noquit) running = 0;
                else if (ch == 's') o.seconds = !o.seconds;
                else if (ch == 'x') o.box = !o.box;
                else if (ch == 'c') o.center = !o.center;
                else if (ch == 'r') o.rebound = !o.rebound;
                else if (ch == 't') o.twelve = !o.twelve;
                else if (ch == 'b') o.bold = !o.bold;
                else if (ch >= '0' && ch <= '7') o.color = ch - '0';
                else if (!o.center && ch == 'h') x--;
                else if (!o.center && ch == 'l') x++;
                else if (!o.center && ch == 'k') y--;
                else if (!o.center && ch == 'j') y++;
                break;
            }
            nanosleep(&step, NULL);
            waited += 50000000L;
        }
    }
    return 0;
}
