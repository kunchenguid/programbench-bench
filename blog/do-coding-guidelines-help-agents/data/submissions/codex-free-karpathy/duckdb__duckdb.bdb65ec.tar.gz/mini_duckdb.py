#!/usr/bin/env python3
import csv
import html
import json
import math
import os
import re
import sys

VERSION = "v0.0.1 (Unknown Version) 780a7396"
MAGIC = "__mini_duckdb__"


def strip_ansi(s):
    return re.sub(r"\x1b\[[0-9;]*m", "", s)


def split_top(s, sep=","):
    out, cur, depth, quote = [], [], 0, None
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == quote:
                if i + 1 < len(s) and s[i + 1] == quote:
                    cur.append(s[i + 1])
                    i += 1
                else:
                    quote = None
        else:
            if c in "'\"":
                quote = c
                cur.append(c)
            elif c == "(":
                depth += 1
                cur.append(c)
            elif c == ")":
                depth -= 1
                cur.append(c)
            elif c == sep and depth == 0:
                out.append("".join(cur).strip())
                cur = []
            else:
                cur.append(c)
        i += 1
    if cur or s.strip():
        out.append("".join(cur).strip())
    return out


def split_sql(text):
    out, cur, quote = [], [], None
    i = 0
    while i < len(text):
        c = text[i]
        if quote:
            cur.append(c)
            if c == quote:
                if i + 1 < len(text) and text[i + 1] == quote:
                    cur.append(text[i + 1])
                    i += 1
                else:
                    quote = None
        else:
            if c in "'\"":
                quote = c
                cur.append(c)
            elif c == ";":
                stmt = "".join(cur).strip()
                if stmt:
                    out.append(stmt)
                cur = []
            else:
                cur.append(c)
        i += 1
    rest = "".join(cur).strip()
    if rest:
        out.append(rest)
    return out


def unquote(s):
    s = s.strip()
    if len(s) >= 2 and s[0] in "'\"" and s[-1] == s[0]:
        return s[1:-1].replace(s[0] * 2, s[0])
    return s


def sql_value(s):
    s = s.strip()
    if re.fullmatch(r"NULL", s, re.I):
        return None
    if re.fullmatch(r"true", s, re.I):
        return True
    if re.fullmatch(r"false", s, re.I):
        return False
    if len(s) >= 2 and s[0] in "'\"" and s[-1] == s[0]:
        return unquote(s)
    try:
        if re.search(r"[.eE]", s):
            return float(s)
        return int(s)
    except ValueError:
        return s


def parse_rows(values):
    rows, i = [], 0
    while i < len(values):
        if values[i].isspace() or values[i] == ",":
            i += 1
            continue
        if values[i] != "(":
            break
        depth, quote, start = 1, None, i + 1
        i += 1
        while i < len(values) and depth:
            c = values[i]
            if quote:
                if c == quote:
                    if i + 1 < len(values) and values[i + 1] == quote:
                        i += 1
                    else:
                        quote = None
            else:
                if c in "'\"":
                    quote = c
                elif c == "(":
                    depth += 1
                elif c == ")":
                    depth -= 1
            i += 1
        rows.append([sql_value(x) for x in split_top(values[start : i - 1])])
    return rows


def infer_type(v):
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, int):
        return "int32" if -2147483648 <= v <= 2147483647 else "int64"
    if isinstance(v, float):
        return "double"
    if v is None:
        return "int32"
    return "varchar"


def render_value(v, nullvalue="NULL"):
    if v is None:
        return nullvalue
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


class MiniDuck:
    def __init__(self, filename):
        self.filename = filename or ":memory:"
        self.mode = "duckbox"
        self.headers = True
        self.separator = "|"
        self.newline = "\n"
        self.nullvalue = "NULL"
        self.echo = False
        self.bail = False
        self.db = {MAGIC: True, "tables": {}}
        self.dirty = False
        self.load()

    def load(self):
        if self.filename in (":memory:", ""):
            return
        if not os.path.exists(self.filename):
            return
        if os.path.getsize(self.filename) == 0:
            print(f'IO Error: The file "{self.filename}" exists, but it is not a valid DuckDB database file!', file=sys.stderr)
            sys.exit(1)
        try:
            with open(self.filename) as f:
                data = json.load(f)
            if not data.get(MAGIC):
                raise ValueError
            self.db = data
        except Exception:
            print(f'IO Error: The file "{self.filename}" exists, but it is not a valid DuckDB database file!', file=sys.stderr)
            sys.exit(1)

    def save(self):
        if self.dirty and self.filename not in (":memory:", ""):
            with open(self.filename, "w") as f:
                json.dump(self.db, f)

    def execute_script(self, text):
        rc = 0
        buf = ""
        for raw in text.splitlines():
            line = raw.strip()
            if not line:
                continue
            if line.startswith(".") and not buf:
                try:
                    self.dot(line)
                except SystemExit as e:
                    raise e
                except Exception as e:
                    rc = 1
                    print(str(e), file=sys.stderr)
                    if self.bail:
                        break
                continue
            buf += raw + "\n"
            if ";" in raw:
                for stmt in split_sql(buf):
                    if self.echo:
                        print(stmt + ";")
                    try:
                        self.sql(stmt)
                    except Exception as e:
                        rc = 1
                        print(str(e), file=sys.stderr)
                        if self.bail:
                            self.save()
                            return rc
                buf = ""
        if buf.strip():
            try:
                self.sql(buf.strip())
            except Exception as e:
                rc = 1
                print(str(e), file=sys.stderr)
        self.save()
        return rc

    def dot(self, line):
        parts = line.split()
        cmd = parts[0][1:]
        args = parts[1:]
        if cmd in ("quit", "exit"):
            self.save()
            raise SystemExit(int(args[0]) if args and args[0].isdigit() else 0)
        if cmd in ("help", "?"):
            print(".help ?-all? ?PATTERN?                   Show help text for PATTERN")
            print(".mode MODE ?TABLE?                       Set output mode")
            print(".headers on|off                          Turn display of headers on or off")
            print(".tables ?TABLE?                          List names of tables matching LIKE pattern TABLE")
            print(".schema ?PATTERN?                        Show the CREATE statements matching PATTERN")
            print(".read FILE                               Read input from FILE")
            print(".quit                                    Exit this program")
            return
        if cmd == "version":
            print(VERSION)
            return
        if cmd == "about":
            print("DuckDB " + VERSION)
            return
        if cmd == "mode":
            if not args:
                print(f"current output mode: {self.mode}")
            else:
                self.mode = args[0].lower()
            return
        if cmd in ("headers", "header"):
            if args:
                self.headers = args[0].lower() in ("on", "yes", "true", "1")
            return
        if cmd == "separator":
            if args:
                self.separator = unquote(args[0])
            if len(args) > 1:
                self.newline = unquote(args[1])
            return
        if cmd == "nullvalue":
            if args:
                self.nullvalue = " ".join(args)
            return
        if cmd == "bail":
            if args:
                self.bail = args[0].lower() in ("on", "yes", "true", "1")
            return
        if cmd == "echo":
            if args:
                self.echo = args[0].lower() in ("on", "yes", "true", "1")
            return
        if cmd == "print":
            print(line.partition(" ")[2])
            return
        if cmd == "tables":
            names = sorted(self.db["tables"])
            if args:
                pat = args[0].replace("%", ".*")
                names = [n for n in names if re.search(pat, n)]
            if names:
                print(" ".join(names))
            return
        if cmd == "schema":
            for name in sorted(self.db["tables"]):
                print(self.db["tables"][name].get("create_sql") or self.create_sql(name) + ";")
            return
        if cmd == "read":
            with open(unquote(" ".join(args))) as f:
                self.execute_script(f.read())
            return
        if cmd == "show":
            print(f"mode: {self.mode}")
            print(f"headers: {'on' if self.headers else 'off'}")
            print(f"separator: {self.separator}")
            return
        if cmd == "import" and len(args) >= 2:
            self.import_csv(unquote(args[0]), args[1])
            return
        if cmd == "databases":
            self.output(["seq", "name", "file"], [[0, "memory" if self.filename == ":memory:" else "main", self.filename]], ["int32", "varchar", "varchar"])
            return
        raise Exception(f"Error: unknown command or invalid arguments:  \"{line}\". Enter \".help\" for help")

    def create_sql(self, name):
        t = self.db["tables"][name]
        cols = ", ".join(f"{c} {typ.upper()}" for c, typ in zip(t["columns"], t["types"]))
        return f"CREATE TABLE {name}({cols})"

    def import_csv(self, path, table):
        with open(path, newline="") as f:
            rows = list(csv.reader(f))
        if not rows:
            return
        cols = rows[0]
        data = [[sql_value(x) for x in r] for r in rows[1:]]
        types = [infer_type(data[0][i]) if data else "varchar" for i in range(len(cols))]
        self.db["tables"][table] = {"columns": cols, "types": types, "rows": data, "create_sql": self.create_sql_text(table, cols, types)}
        self.dirty = True

    def create_sql_text(self, table, cols, types):
        return "CREATE TABLE " + table + "(" + ", ".join(f"{c} {t.upper()}" for c, t in zip(cols, types)) + ");"

    def sql(self, stmt):
        s = stmt.strip().rstrip(";").strip()
        if not s:
            return
        low = s.lower()
        if low.startswith("select ") or low.startswith("with "):
            cols, rows, types = self.select(s)
            self.output(cols, rows, types)
            return
        if low.startswith("create table"):
            self.create_table(s)
            return
        if low.startswith("insert into"):
            self.insert(s)
            return
        if low.startswith("drop table"):
            m = re.search(r"drop\s+table\s+(?:if\s+exists\s+)?([A-Za-z_][\w]*)", s, re.I)
            if m:
                self.db["tables"].pop(m.group(1), None)
                self.dirty = True
            return
        if low.startswith("delete from"):
            m = re.search(r"delete\s+from\s+([A-Za-z_][\w]*)", s, re.I)
            if m and m.group(1) in self.db["tables"]:
                self.db["tables"][m.group(1)]["rows"] = []
                self.dirty = True
            return
        if low.startswith("pragma ") or low.startswith("set ") or low.startswith("load ") or low.startswith("install "):
            return
        raise Exception(f"Parser Error: syntax error at or near \"{s.split()[0]}\"")

    def create_table(self, s):
        m = re.search(r"create\s+(?:or\s+replace\s+)?table\s+([A-Za-z_][\w]*)\s*(?:as\s+(select .+)|\((.*)\))\s*$", s, re.I | re.S)
        if not m:
            raise Exception("Parser Error: syntax error at or near \"CREATE\"")
        name = m.group(1)
        if m.group(2):
            cols, rows, types = self.select(m.group(2))
            create_sql = self.create_sql_text(name, cols, types)
        else:
            specs = split_top(m.group(3))
            cols, types = [], []
            for spec in specs:
                bits = spec.split()
                if not bits:
                    continue
                cols.append(bits[0].strip('"'))
                types.append((bits[1] if len(bits) > 1 else "varchar").lower().replace("integer", "int32"))
            rows = []
            create_sql = self.create_sql_text(name, cols, types)
        self.db["tables"][name] = {"columns": cols, "types": types, "rows": rows, "create_sql": create_sql}
        self.dirty = True

    def insert(self, s):
        m = re.search(r"insert\s+into\s+([A-Za-z_][\w]*)(?:\s*\((.*?)\))?\s+values\s*(.*)$", s, re.I | re.S)
        if not m:
            raise Exception("Parser Error: syntax error at or near \"INSERT\"")
        name = m.group(1)
        if name not in self.db["tables"]:
            raise Exception(f"Catalog Error: Table with name {name} does not exist!")
        rows = parse_rows(m.group(3))
        table = self.db["tables"][name]
        if m.group(2):
            cols = [c.strip() for c in split_top(m.group(2))]
            idxs = [table["columns"].index(c) for c in cols]
            for r in rows:
                full = [None] * len(table["columns"])
                for i, v in zip(idxs, r):
                    full[i] = v
                table["rows"].append(full)
        else:
            table["rows"].extend(rows)
        self.dirty = True

    def select(self, s):
        s = s.strip()
        if s.lower().startswith("with "):
            raise Exception("Not implemented Error: WITH queries are not supported by this reimplementation")
        body = s[6:].strip()
        limit = None
        m = re.search(r"\s+limit\s+(\d+)\s*$", body, re.I)
        if m:
            limit = int(m.group(1))
            body = body[: m.start()].strip()
        order_by = None
        m = re.search(r"\s+order\s+by\s+(.+)$", body, re.I)
        if m:
            order_by = m.group(1).strip()
            body = body[: m.start()].strip()
        where = None
        m = re.search(r"\s+where\s+(.+)$", body, re.I)
        if m:
            where = m.group(1).strip()
            body = body[: m.start()].strip()
        from_part = None
        m = re.search(r"\s+from\s+(.+)$", body, re.I)
        if m:
            select_part = body[: m.start()].strip()
            from_part = m.group(1).strip()
        else:
            select_part = body
        rows, src_cols, src_types = self.source_rows(from_part)
        if where:
            rows = [r for r in rows if self.eval_expr(where, r)]
        exprs = split_top(select_part)
        if len(exprs) == 1 and exprs[0] == "*":
            out_cols, out_rows, out_types = src_cols, [[r.get(c) for c in src_cols] for r in rows], src_types
        elif any(re.search(r"\b(count|sum|min|max|avg)\s*\(", e, re.I) for e in exprs):
            out_cols, out_rows, out_types = [], [[]], []
            for e in exprs:
                expr, alias = self.alias(e)
                out_cols.append(alias or self.clean_name(expr))
                out_rows[0].append(self.aggregate(expr, rows))
                out_types.append(infer_type(out_rows[0][-1]))
        else:
            out_cols, out_rows, out_types = [], [], []
            parsed = [self.alias(e) for e in exprs]
            out_cols = [a or self.clean_name(e) for e, a in parsed]
            for r in rows:
                vals = [self.eval_expr(e, r) for e, _ in parsed]
                out_rows.append(vals)
            if not rows and from_part is None:
                vals = [self.eval_expr(e, {}) for e, _ in parsed]
                out_rows.append(vals)
            out_types = [infer_type(out_rows[0][i]) if out_rows else "varchar" for i in range(len(out_cols))]
        if order_by:
            key = order_by.split()[0]
            reverse = " desc" in order_by.lower()
            if key in out_cols:
                idx = out_cols.index(key)
                out_rows.sort(key=lambda r: (r[idx] is None, r[idx]), reverse=reverse)
        if limit is not None:
            out_rows = out_rows[:limit]
        return out_cols, out_rows, out_types

    def source_rows(self, part):
        if not part:
            return ([{}], [], [])
        part = part.strip()
        if part.startswith("(") and part.lower().startswith("(values"):
            inner = part[1:-1].strip()
            rows = parse_rows(inner[6:].strip())
            cols = [f"col{i}" for i in range(len(rows[0]) if rows else 0)]
            types = [infer_type(rows[0][i]) if rows else "varchar" for i in range(len(cols))]
            return [dict(zip(cols, r)) for r in rows], cols, types
        m = re.match(r"range\s*\((.*?)\)", part, re.I)
        if m:
            args = [int(sql_value(x)) for x in split_top(m.group(1)) if x]
            if len(args) == 1:
                start, stop, step = 0, args[0], 1
            elif len(args) == 2:
                start, stop, step = args[0], args[1], 1
            else:
                start, stop, step = args[0], args[1], args[2]
            vals = list(range(start, stop, step))
            return [{"range": v} for v in vals], ["range"], ["int64"]
        if len(part) >= 2 and part[0] in "'\"" and part[-1] == part[0]:
            path = unquote(part)
            with open(path, newline="") as f:
                data = list(csv.reader(f))
            if not data:
                return [], [], []
            cols = data[0]
            rows = [[sql_value(x) for x in r] for r in data[1:]]
            types = [infer_type(rows[0][i]) if rows else "varchar" for i in range(len(cols))]
            return [dict(zip(cols, r)) for r in rows], cols, types
        name = part.split()[0].strip('"')
        if name not in self.db["tables"]:
            raise Exception(f"Catalog Error: Table with name {name} does not exist!")
        t = self.db["tables"][name]
        return [dict(zip(t["columns"], r)) for r in t["rows"]], t["columns"], t["types"]

    def alias(self, e):
        m = re.match(r"(.+?)\s+as\s+([A-Za-z_][\w]*)$", e, re.I | re.S)
        if m:
            return m.group(1).strip(), m.group(2)
        parts = e.rsplit(None, 1)
        if len(parts) == 2 and re.match(r"^[A-Za-z_]\w*$", parts[1]) and not re.search(r"[)+\-*/<>=]$", parts[0]):
            return parts[0], parts[1]
        return e, None

    def clean_name(self, e):
        e = e.strip()
        if len(e) >= 2 and e[0] in "'\"" and e[-1] == e[0]:
            return unquote(e)
        return e

    def aggregate(self, expr, rows):
        m = re.match(r"(count|sum|min|max|avg)\s*\((.*?)\)$", expr.strip(), re.I | re.S)
        if not m:
            return self.eval_expr(expr, rows[0] if rows else {})
        fn, arg = m.group(1).lower(), m.group(2).strip()
        if fn == "count":
            if arg == "*":
                return len(rows)
            return sum(1 for r in rows if self.eval_expr(arg, r) is not None)
        vals = [self.eval_expr(arg, r) for r in rows]
        vals = [v for v in vals if v is not None]
        if not vals:
            return None
        if fn == "sum":
            return sum(vals)
        if fn == "min":
            return min(vals)
        if fn == "max":
            return max(vals)
        if fn == "avg":
            return sum(vals) / len(vals)

    def eval_expr(self, expr, row):
        expr = expr.strip()
        if expr in row:
            return row[expr]
        if re.fullmatch(r"[A-Za-z_]\w*", expr) and expr.lower() not in ("true", "false", "null"):
            if expr not in row:
                raise Exception(f'Binder Error: Referenced column "{expr}" was not found')
        py = expr
        py = re.sub(r"(?<![<>=!])=(?!=)", "==", py)
        py = py.replace("<>", "!=")
        py = re.sub(r"\bAND\b", " and ", py, flags=re.I)
        py = re.sub(r"\bOR\b", " or ", py, flags=re.I)
        py = re.sub(r"\bNOT\b", " not ", py, flags=re.I)
        py = re.sub(r"\bNULL\b", "None", py, flags=re.I)
        py = re.sub(r"\bTRUE\b", "True", py, flags=re.I)
        py = re.sub(r"\bFALSE\b", "False", py, flags=re.I)
        py = py.replace("||", "+")
        env = {k: v for k, v in row.items()}
        env.update({
            "upper": lambda x: None if x is None else str(x).upper(),
            "lower": lambda x: None if x is None else str(x).lower(),
            "length": lambda x: None if x is None else len(str(x)),
            "len": len,
            "abs": abs,
            "round": round,
            "sqrt": math.sqrt,
            "coalesce": lambda *xs: next((x for x in xs if x is not None), None),
        })
        try:
            return eval(py, {"__builtins__": {}}, env)
        except SyntaxError:
            return sql_value(expr)
        except NameError:
            return sql_value(expr)

    def output(self, cols, rows, types):
        mode = self.mode
        if mode in ("duckbox", "box"):
            self.out_box(cols, rows, types if mode == "duckbox" else None)
        elif mode in ("list",):
            self.out_delim(cols, rows, self.separator)
        elif mode == "csv":
            self.out_csv(cols, rows)
        elif mode == "json":
            print(json.dumps([dict(zip(cols, r)) for r in rows], separators=(",", ":")))
        elif mode == "jsonlines":
            for r in rows:
                print(json.dumps(dict(zip(cols, r)), separators=(",", ":")))
        elif mode == "line":
            for r in rows:
                for c, v in zip(cols, r):
                    print(f"{c:>5} = {render_value(v, self.nullvalue)}")
        elif mode == "quote":
            if self.headers:
                print("|".join("'" + c.replace("'", "''") + "'" for c in cols))
            for r in rows:
                print("|".join("NULL" if v is None else ("'" + str(v).replace("'", "''") + "'" if isinstance(v, str) else render_value(v, self.nullvalue)) for v in r))
        elif mode == "html":
            if self.headers:
                print("<tr>" + "\n".join(f"<th>{html.escape(c)}</th>" for c in cols) + "\n</tr>")
            for r in rows:
                print("<tr>" + "\n".join(f"<td>{html.escape(render_value(v, self.nullvalue))}</td>" for v in r) + "\n</tr>")
        elif mode == "markdown":
            self.out_markdown(cols, rows)
        elif mode == "ascii":
            if self.headers:
                for c in cols:
                    print(c)
            for r in rows:
                for v in r:
                    print(render_value(v, self.nullvalue))
        else:
            self.out_table(cols, rows)

    def out_delim(self, cols, rows, sep):
        if self.headers:
            print(sep.join(cols))
        for r in rows:
            print(sep.join(render_value(v, self.nullvalue) for v in r))

    def out_csv(self, cols, rows):
        w = csv.writer(sys.stdout, lineterminator="\n")
        if self.headers:
            w.writerow(cols)
        for r in rows:
            w.writerow([render_value(v, self.nullvalue) for v in r])

    def widths(self, cols, rows, types=None):
        vals = []
        if self.headers:
            vals.append(cols)
        if types:
            vals.append(types)
        vals += [[render_value(v, self.nullvalue) for v in r] for r in rows]
        return [max(len(str(row[i])) for row in vals) if vals else len(c) for i, c in enumerate(cols)]

    def out_box(self, cols, rows, types=None):
        widths = self.widths(cols, rows, types)
        top = "┌" + "┬".join("─" * (w + 2) for w in widths) + "┐"
        mid = "├" + "┼".join("─" * (w + 2) for w in widths) + "┤"
        bot = "└" + "┴".join("─" * (w + 2) for w in widths) + "┘"
        print(top)
        if self.headers:
            print("│" + "│".join(f" {c:^{w}} " for c, w in zip(cols, widths)) + "│")
        if types:
            print("│" + "│".join(f" {t:^{w}} " for t, w in zip(types, widths)) + "│")
        print(mid)
        for r in rows:
            cells = []
            for v, w in zip(r, widths):
                text = render_value(v, self.nullvalue)
                cells.append(f" {text:>{w}} " if isinstance(v, (int, float)) or v is None else f" {text:<{w}} ")
            print("│" + "│".join(cells) + "│")
        print(bot)

    def out_table(self, cols, rows):
        widths = self.widths(cols, rows)
        line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
        print(line)
        if self.headers:
            print("|" + "|".join(f" {c:^{w}} " for c, w in zip(cols, widths)) + "|")
            print(line)
        for r in rows:
            print("|" + "|".join(f" {render_value(v, self.nullvalue):<{w}} " for v, w in zip(r, widths)) + "|")
        print(line)

    def out_markdown(self, cols, rows):
        widths = self.widths(cols, rows)
        print("| " + " | ".join(f"{c:^{w}}" for c, w in zip(cols, widths)) + " |")
        print("|" + "|".join("-" * (w + 2) for w in widths) + "|")
        for r in rows:
            print("| " + " | ".join(f"{render_value(v, self.nullvalue):<{w}}" for v, w in zip(r, widths)) + " |")


def usage():
    print("\033[1mUsage: \033[00m\033[32m./executable\033[00m\033[33m [OPTIONS] FILENAME [SQL]\n\033[00m")
    print("\033[1mFILENAME\033[00m is the name of a DuckDB database. A new database is created")
    print("if the file does not previously exist.\n")
    print("\033[1mOPTIONS:\033[00m")
    opts = [
        ("-ascii", "set output mode to 'ascii'"), ("-bail", "stop after hitting an error"),
        ("-batch", "force batch I/O'"), ("-box", "set output mode to 'box'"),
        ("-column", "set output mode to 'column'"), ("-cmd COMMAND", 'run "COMMAND" before reading stdin'),
        ("-csv", "set output mode to 'csv'"), ("-c COMMAND", 'run "COMMAND" and exit'),
        ("-echo", "print commands before execution"), ("-f FILENAME", "read/process named file and exit"),
        ("-format", "format SQL from stdin, writing result to stdout"), ("-format-file FILENAME", "format SQL in file, writing result to stdout"),
        ("-header", "turn headers on"), ("-h", "show help message"), ("-help", "show help message"),
        ("-html", "set output mode to HTML"), ("-json", "set output mode to 'json'"), ("-jsonlines", "set output mode to 'jsonlines'"),
        ("-line", "set output mode to 'line'"), ("-list", "set output mode to 'list'"), ("-markdown", "set output mode to 'markdown'"),
        ("-noheader", "turn headers off"), ("-nullvalue TEXT", "set text string for NULL values. Default 'NULL'"),
        ("-quote", "set output mode to 'quote'"), ("-readonly", "open the database read-only"),
        ("-s COMMAND", 'run "COMMAND" and exit'), ("-separator SEP", "set output column separator. Default: '|'"),
        ("-table", "set output mode to 'table'"), ("-version", "show DuckDB version")
    ]
    for a, b in opts:
        print(f"\033[32m  {a:<24}\033[00m {b}")


def main(argv):
    if not argv:
        usage()
        return 0
    filename = None
    sqls = []
    pre = []
    mode = None
    no_stdin = False
    headers = None
    separator = None
    nullvalue = None
    bail = False
    echo = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-help", "--help"):
            usage()
            return 0
        if a == "-version":
            print(VERSION)
            return 0
        if a in ("-ascii", "-box", "-column", "-csv", "-html", "-json", "-jsonlines", "-line", "-list", "-markdown", "-quote", "-table"):
            mode = a[1:]
        elif a in ("-header",):
            headers = True
        elif a in ("-noheader",):
            headers = False
        elif a == "-separator":
            i += 1
            separator = argv[i]
        elif a == "-newline":
            i += 1
        elif a == "-nullvalue":
            i += 1
            nullvalue = argv[i]
        elif a == "-bail":
            bail = True
        elif a == "-echo":
            echo = True
        elif a in ("-batch", "-interactive", "-readonly", "-safe", "-unsigned", "-unredacted", "-no-init", "-ui"):
            pass
        elif a == "-no-stdin":
            no_stdin = True
        elif a in ("-cmd",):
            i += 1
            pre.append(argv[i])
        elif a in ("-c", "-s"):
            i += 1
            sqls.append(argv[i])
            no_stdin = True
        elif a == "-f":
            i += 1
            with open(argv[i]) as f:
                sqls.append(f.read())
            no_stdin = True
        elif a == "-init":
            i += 1
            with open(argv[i]) as f:
                pre.append(f.read())
        elif a == "-format":
            print(sys.stdin.read().strip())
            return 0
        elif a == "-format-file":
            i += 1
            with open(argv[i]) as f:
                print(f.read().strip())
            return 0
        elif a.startswith("-"):
            pass
        elif filename is None:
            filename = a
        else:
            sqls.append(a)
            no_stdin = True
        i += 1
    shell = MiniDuck(filename or ":memory:")
    if mode:
        shell.mode = mode
    if headers is not None:
        shell.headers = headers
    if separator is not None:
        shell.separator = separator
    if nullvalue is not None:
        shell.nullvalue = nullvalue
    shell.bail = bail
    shell.echo = echo
    rc = 0
    for p in pre:
        rc |= shell.execute_script(p if p.strip().startswith(".") else p + ";")
    for q in sqls:
        rc |= shell.execute_script(q)
    if not no_stdin and not sqls and not sys.stdin.isatty():
        rc |= shell.execute_script(sys.stdin.read())
    shell.save()
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
