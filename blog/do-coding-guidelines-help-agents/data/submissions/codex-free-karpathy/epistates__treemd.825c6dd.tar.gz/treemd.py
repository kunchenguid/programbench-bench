#!/usr/bin/env python3
import json
import os
import re
import sys

VERSION = "treemd 0.5.7"


HELP = """treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.

Launch without flags for interactive mode with dual-pane interface, vim-style navigation,
syntax highlighting, and real-time search. Use flags for CLI mode to extract, filter,
and analyze markdown structure.

Usage: executable [OPTIONS] [FILE]... [COMMAND]

Commands:
  at-line  Show heading at specific line number
  help     Print this message or the help of the given subcommand(s)

Options:
  -l, --list                 List all headings in the document (non-interactive)
      --tree                 Show heading tree structure with box-drawing characters
      --filter <PATTERN>     Filter headings by text pattern (case-insensitive)
  -L, --level <LEVEL>        Show only headings at specific level (1-6)
  -o, --output <OUTPUT>      Output format for --list and --tree modes [default: plain]
  -s, --section <HEADING>    Extract specific section by heading name
      --count                Count headings by level (shows statistics)
      --setup-completions    Set up shell completions interactively
      --theme <THEME>        Set theme for TUI mode
      --color-mode <MODE>    Force color mode (auto, rgb, 256)
      --no-images            Disable image rendering in TUI mode
      --images               Enable image rendering in TUI mode
  -q, --query <EXPR>         Query expression for selecting/filtering document elements
      --query-help           Show query language documentation and examples
      --query-output <FORMAT> Output format for query results
  -h, --help                 Print help
  -V, --version              Print version
"""

QUERY_HELP = """treemd Query Language (tql)

A jq-like query language for navigating and extracting markdown structure.

ELEMENT SELECTORS
    .h, .heading    All headings (any level)
    .h1 - .h6       Headings by level
    .code           All code blocks
    .code[rust]     Code blocks by language
    .link, .a       All links
    .img            All images
    .table          All tables
    .list           All lists
    .blockquote     All blockquotes

PIPES
    .h2 | text          Get heading text (strips ##)
    [.h2] | count       Count all h2s
    .code | lang        Get code block languages
    .link | url         Get link URLs

For more details, see: https://github.com/epistates/treemd
"""


def slugify(s):
    s = s.strip().lower()
    s = re.sub(r"[^a-z0-9\s-]", "", s)
    s = re.sub(r"[\s-]+", "-", s).strip("-")
    return s


def heading_match(line):
    m = re.match(r"^(#{1,6})[ \t]+(.+?)\s*$", line)
    if not m:
        return None
    text = re.sub(r"\s+#+\s*$", "", m.group(2)).strip()
    return len(m.group(1)), text


def read_input(files):
    if not files or files == ["-"]:
        return sys.stdin.read(), None
    chunks = []
    for path in files:
        if path == "-":
            chunks.append(sys.stdin.read())
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                chunks.append(f.read())
        except OSError as e:
            print(f"Error reading input: I/O error: {e.strerror} (os error {getattr(e, 'errno', 1)})", file=sys.stderr)
            sys.exit(1)
    return "\n".join(chunks), files[0] if len(files) == 1 and files[0] != "-" else None


def parse_doc(text):
    lines = text.splitlines()
    headings = []
    in_code = False
    offset = 0
    for i, line in enumerate(lines, 1):
        if line.lstrip().startswith("```") or line.lstrip().startswith("~~~"):
            in_code = not in_code
        if not in_code:
            hm = heading_match(line)
            if hm:
                level, title = hm
                headings.append({"type": "heading", "level": level, "text": title, "line": i, "offset": offset, "children": []})
        offset += len(line) + 1
    for idx, h in enumerate(headings):
        end = len(lines) + 1
        for nxt in headings[idx + 1:]:
            if nxt["level"] <= h["level"]:
                end = nxt["line"]
                break
        direct_end = end
        for nxt in headings[idx + 1:]:
            if nxt["line"] > h["line"] and nxt["level"] > h["level"]:
                direct_end = nxt["line"]
                break
        h["section_end"] = end
        h["direct_end"] = direct_end
    roots, stack = [], []
    for h in headings:
        h["children"] = []
        while stack and stack[-1]["level"] >= h["level"]:
            stack.pop()
        if stack:
            stack[-1]["children"].append(h)
        else:
            roots.append(h)
        stack.append(h)
    return {"text": text, "lines": lines, "headings": headings, "roots": roots}


def heading_line(h):
    return "#" * h["level"] + " " + h["text"]


def filtered_headings(doc, level=None, pattern=None):
    hs = doc["headings"]
    if level is not None:
        hs = [h for h in hs if h["level"] == level]
    if pattern:
        p = pattern.lower()
        hs = [h for h in hs if p in h["text"].lower()]
    return hs


def print_plain_headings(hs):
    for h in hs:
        print(heading_line(h))


def render_tree_nodes(nodes, prefix=""):
    out = []
    for i, h in enumerate(nodes):
        last = i == len(nodes) - 1
        branch = "└──" if last else "├──"
        out.append(prefix + branch + heading_line(h))
        child_prefix = prefix + ("   " if last else "│  ")
        out.extend(render_tree_nodes(h["children"], child_prefix))
    return out


def print_tree(doc, hs=None):
    if hs is None:
        lines = render_tree_nodes(doc["roots"])
    else:
        lines = []
        for i, h in enumerate(hs):
            lines.append(("└──" if i == len(hs) - 1 else "├──") + heading_line(h))
    print("\n".join(lines))


def section_text(doc, h, include_heading=True, direct=False):
    start = h["line"] if include_heading else h["line"] + 1
    end = h["direct_end"] if direct else h["section_end"]
    return "\n".join(doc["lines"][start - 1:end - 1]).rstrip()


def word_count(text):
    return len(text.split())


def code_blocks(doc):
    blocks = []
    lines = doc["lines"]
    i = 0
    while i < len(lines):
        m = re.match(r"^\s*(```|~~~)\s*([^\s`]*)", lines[i])
        if not m:
            i += 1
            continue
        fence, lang = m.group(1), m.group(2)
        start = i + 1
        i += 1
        body = []
        while i < len(lines) and not lines[i].lstrip().startswith(fence):
            body.append(lines[i])
            i += 1
        end = i + 1 if i < len(lines) else i
        blocks.append({"type": "code", "lang": lang, "content": "\n".join(body), "line": start, "end": end})
        i += 1
    return blocks


def links(doc):
    vals = []
    pat = re.compile(r"(?<!!)\[([^\]]+)\]\(([^)\s]+)(?:\s+\"[^\"]*\")?\)")
    for i, line in enumerate(doc["lines"], 1):
        for m in pat.finditer(line):
            vals.append({"type": "link", "text": m.group(1), "url": m.group(2), "line": i})
    return vals


def images(doc):
    return []


def tables(doc):
    vals = []
    lines = doc["lines"]
    i = 0
    while i + 1 < len(lines):
        if "|" in lines[i] and re.match(r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", lines[i + 1]):
            start = i
            rows = [lines[i], re.sub(r":?-{3,}:?", "---", lines[i + 1])]
            i += 2
            while i < len(lines) and "|" in lines[i] and lines[i].strip():
                rows.append(lines[i])
                i += 1
            vals.append({"type": "table", "md": "\n".join(rows), "line": start + 1})
        else:
            i += 1
    return vals


def lists(doc):
    vals = []
    cur = []
    start = 0
    for i, line in enumerate(doc["lines"], 1):
        if re.match(r"^\s*(?:[-*+]\s+|\d+\.\s+)", line):
            if not cur:
                start = i
            cur.append(line)
        elif cur:
            vals.append({"type": "list", "md": "\n".join(cur), "line": start})
            cur = []
    if cur:
        vals.append({"type": "list", "md": "\n".join(cur), "line": start})
    return vals


def blockquotes(doc):
    vals = []
    cur = []
    start = 0
    for i, line in enumerate(doc["lines"], 1):
        if line.startswith(">"):
            if not cur:
                start = i
            cur.append(line)
        elif cur:
            vals.append({"type": "blockquote", "md": "\n".join(cur), "line": start})
            cur = []
    if cur:
        vals.append({"type": "blockquote", "md": "\n".join(cur), "line": start})
    return vals


def element_md(doc, el):
    if el.get("type") == "heading":
        return heading_line(el)
    if el.get("type") == "code":
        lang = el.get("lang", "")
        return "```" + lang + "\n" + el.get("content", "") + "\n```"
    if el.get("type") == "link":
        return f"[{el['text']}]({el['url']})"
    if el.get("type") == "image":
        return f"![{el['alt']}]({el['src']})"
    return el.get("md", el.get("text", ""))


def json_obj(el):
    if isinstance(el, (int, float, str, bool)) or el is None:
        return el
    t = el.get("type")
    if t == "heading":
        return {"type": "heading", "level": el["level"], "text": el["text"], "line": el["line"]}
    if t == "code":
        return {"type": "code", "language": el.get("lang", ""), "content": el.get("content", ""), "line": el.get("line")}
    if t == "link":
        return {"type": "link", "text": el["text"], "url": el["url"], "line": el["line"]}
    if t == "image":
        return {"type": "image", "alt": el["alt"], "src": el["src"], "line": el["line"]}
    return dict(el)


def select_query(doc, selector):
    selector = selector.strip()
    filt = None
    m = re.match(r"^(\.[a-zA-Z0-9_]+)(?:\[(.*?)\])?$", selector)
    if m:
        selector, filt = m.group(1), m.group(2)
    if selector in (".", ""):
        vals = [{"type": "document"}]
    elif selector in (".h", ".heading"):
        vals = list(doc["headings"])
    elif re.match(r"^\.h[1-6]$", selector):
        vals = [h for h in doc["headings"] if h["level"] == int(selector[2])]
    elif selector == ".code":
        vals = code_blocks(doc)
    elif selector in (".link", ".a"):
        vals = links(doc)
    elif selector == ".img":
        vals = images(doc)
    elif selector == ".table":
        vals = tables(doc)
    elif selector == ".list":
        vals = lists(doc)
    elif selector == ".blockquote":
        vals = blockquotes(doc)
    else:
        vals = []
    if filt is not None:
        f = filt.strip().strip("\"'")
        if re.match(r"^-?\d+$", f):
            idx = int(f)
            vals = [vals[idx]] if -len(vals) <= idx < len(vals) else []
        elif ":" in f and re.match(r"^-?\d*:-?\d*$", f):
            a, b = f.split(":", 1)
            vals = vals[int(a) if a else None:int(b) if b else None]
        elif selector == ".code":
            vals = [v for v in vals if v.get("lang", "").lower() == f.lower()]
        elif selector == ".link" and f == "external":
            vals = [v for v in vals if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", v.get("url", ""))]
        else:
            vals = [v for v in vals if f.lower() in element_md(doc, v).lower()]
    return vals


def apply_func(doc, vals, func):
    func = func.strip()
    if func in ("count", "length", "len", "size"):
        return [len(vals)]
    if func in ("first", "head"):
        return vals[:1]
    if func == "last":
        return vals[-1:] if vals else []
    m = re.match(r"^(?:limit|take)\((\d+)\)$", func)
    if m:
        return vals[:int(m.group(1))]
    m = re.match(r"^(?:skip|drop)\((\d+)\)$", func)
    if m:
        return vals[int(m.group(1)):]
    m = re.match(r"^nth\((-?\d+)\)$", func)
    if m:
        idx = int(m.group(1))
        return [vals[idx]] if -len(vals) <= idx < len(vals) else []
    if func == "reverse":
        return list(reversed(vals))
    if func == "sort":
        return sorted(vals, key=lambda v: element_md(doc, v) if isinstance(v, dict) else str(v))
    if func == "unique":
        out, seen = [], set()
        for v in vals:
            k = json.dumps(json_obj(v), sort_keys=True)
            if k not in seen:
                seen.add(k); out.append(v)
        return out
    if func == "text":
        return [v["text"] if isinstance(v, dict) and v.get("type") == "heading" else element_md(doc, v) for v in vals]
    if func in ("url", "href", "src"):
        return [v.get("url", v.get("src", "")) for v in vals if isinstance(v, dict)]
    if func == "lang":
        return [v.get("lang", "") for v in vals if isinstance(v, dict)]
    if func == "content":
        return [section_text(doc, v, include_heading=False) if isinstance(v, dict) and v.get("type") == "heading" else (v.get("content", "") if isinstance(v, dict) else str(v)) for v in vals]
    if func == "md":
        return [section_text(doc, v) if isinstance(v, dict) and v.get("type") == "heading" else element_md(doc, v) for v in vals]
    if func in ("upper", "lower", "trim", "slugify", "lines", "words", "chars"):
        out = []
        for v in vals:
            s = v if isinstance(v, str) else element_md(doc, v)
            if func == "upper": out.append(s.upper())
            elif func == "lower": out.append(s.lower())
            elif func == "trim": out.append(s.strip())
            elif func == "slugify": out.append(slugify(s))
            elif func == "lines": out.append(len(s.splitlines()))
            elif func == "words": out.append(word_count(s))
            else: out.append(len(s))
        return out
    m = re.match(r"^select\((?:contains|includes)\([\"'](.+)[\"']\)\)$", func)
    if not m:
        m = re.match(r"^(?:where|filter)\((?:contains|includes)\([\"'](.+)[\"']\)\)$", func)
    if m:
        needle = m.group(1).lower()
        return [v for v in vals if needle in element_md(doc, v).lower()]
    if func == "stats":
        return [stats_lines(doc)]
    if func == "levels":
        return [levels_lines(doc)]
    return vals


def eval_query(doc, query):
    q = query.strip()
    parts = [p.strip() for p in q.split("|")]
    first = parts[0]
    if first.startswith("[") and first.endswith("]"):
        first = first[1:-1].strip()
    vals = select_query(doc, first)
    for f in parts[1:]:
        vals = apply_func(doc, vals, f)
    return vals


def stats_lines(doc):
    return {
        "headings": len(doc["headings"]),
        "code_blocks": len(code_blocks(doc)),
        "links": len(links(doc)),
        "images": len(images(doc)),
        "tables": len(tables(doc)),
        "lists": len(lists(doc)),
        "words": word_count(doc["text"]),
    }


def levels_lines(doc):
    d = {}
    for h in doc["headings"]:
        d[f"h{h['level']}"] = d.get(f"h{h['level']}", 0) + 1
    return d


def output_query(doc, vals, fmt):
    if fmt == "jsonp":
        print("Error: Unknown output format: jsonp")
        return
    if fmt in ("json", "json-pretty"):
        indent = 2 if fmt == "json-pretty" else None
        print(json.dumps([json_obj(v) for v in vals], ensure_ascii=False, indent=indent, separators=None if indent else (",", ":")))
    elif fmt == "jsonl":
        for v in vals:
            print(json.dumps(json_obj(v), ensure_ascii=False, separators=(",", ":")))
    elif fmt == "md":
        for v in vals:
            if isinstance(v, dict) and v.get("type") == "heading":
                print(section_text(doc, v))
                print()
            elif isinstance(v, dict):
                print(element_md(doc, v))
            else:
                print(v)
    elif fmt == "tree":
        hs = [v for v in vals if isinstance(v, dict) and v.get("type") == "heading"]
        print_tree(doc, hs)
    else:
        for v in vals:
            if isinstance(v, dict):
                if set(v.keys()) == {"headings", "code_blocks", "links", "images", "tables", "lists", "words"}:
                    for k in ["headings", "code_blocks", "links", "images", "tables", "lists", "words"]:
                        print(f"{k}: {v[k]}")
                elif all(k.startswith("h") for k in v):
                    for k in sorted(v, key=lambda x: int(x[1:])):
                        print(f"{k}: {v[k]}")
                else:
                    print(element_md(doc, v))
            else:
                print(v)


def structural_json(doc, source):
    def node(h):
        raw = section_text(doc, h, include_heading=False, direct=True)
        return {
            "id": slugify(h["text"]),
            "level": h["level"],
            "title": h["text"],
            "slug": slugify(h["text"]),
            "position": {"line": h["line"], "offset": h["offset"]},
            "content": {"raw": raw, "blocks": []},
            "children": [node(c) for c in h["children"]],
        }
    data = {"document": {"metadata": {"source": source, "headingCount": len(doc["headings"]), "maxDepth": max([h["level"] for h in doc["headings"]] or [0]), "wordCount": word_count(doc["text"])}, "sections": [node(h) for h in doc["roots"]]}}
    print(json.dumps(data, ensure_ascii=False, indent=2))


def parse_args(argv):
    opts = {"files": [], "list": False, "tree": False, "count": False, "filter": None, "level": None, "output": "plain", "section": None, "query": None, "query_output": "plain"}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a == "--query-help":
            print(QUERY_HELP); sys.exit(0)
        if a in ("-l", "--list"):
            opts["list"] = True
        elif a == "--tree":
            opts["tree"] = True
        elif a == "--count":
            opts["count"] = True
        elif a in ("--filter",):
            i += 1; opts["filter"] = argv[i] if i < len(argv) else ""
        elif a in ("-L", "--level"):
            i += 1
            try: opts["level"] = int(argv[i])
            except Exception: opts["level"] = None
        elif a in ("-o", "--output"):
            i += 1; opts["output"] = argv[i] if i < len(argv) else "plain"
        elif a in ("-s", "--section"):
            i += 1; opts["section"] = argv[i] if i < len(argv) else ""
        elif a in ("-q", "--query"):
            i += 1; opts["query"] = argv[i] if i < len(argv) else ""
        elif a == "--query-output":
            i += 1; opts["query_output"] = argv[i] if i < len(argv) else "plain"
        elif a in ("--setup-completions", "--no-images", "--images"):
            pass
        elif a in ("--theme", "--color-mode"):
            i += 1
        elif a == "at-line":
            i += 1
            line = int(argv[i]) if i < len(argv) and argv[i].isdigit() else 0
            text, source = read_input(["-"])
            doc = parse_doc(text)
            prior = None
            for h in doc["headings"]:
                if h["line"] <= line:
                    prior = h
                else:
                    break
            if prior:
                print(heading_line(prior))
            sys.exit(0)
        else:
            opts["files"].append(a)
        i += 1
    return opts


def main():
    opts = parse_args(sys.argv[1:])
    if not any([opts["list"], opts["tree"], opts["count"], opts["section"], opts["query"]]):
        print("Failed to enable raw mode: Cannot open /dev/tty: No such device or address (os error 6). Interactive mode requires a terminal.", file=sys.stderr)
        sys.exit(1)
    text, source = read_input(opts["files"] or ["-"])
    doc = parse_doc(text)
    if opts["query"] is not None:
        vals = eval_query(doc, opts["query"])
        output_query(doc, vals, opts["query_output"])
        return
    hs = filtered_headings(doc, opts["level"], opts["filter"])
    if opts["section"] is not None:
        target = next((h for h in doc["headings"] if h["text"].lower() == opts["section"].lower()), None)
        if not target:
            print(f"Section '{opts['section']}' not found", file=sys.stderr)
            sys.exit(1)
        print(section_text(doc, target))
        return
    if opts["count"]:
        print("Heading counts:")
        counts = {}
        for h in hs:
            counts[h["level"]] = counts.get(h["level"], 0) + 1
        for lvl in sorted(counts):
            print(f"  {'#' * lvl}: {counts[lvl]}")
        print()
        print(f"Total: {sum(counts.values())}")
        return
    out = opts["output"]
    if out == "json":
        structural_json(doc, None)
    elif out == "tree" or opts["tree"]:
        print_tree(doc, hs if (opts["level"] or opts["filter"]) else None)
    else:
        print_plain_headings(hs)


if __name__ == "__main__":
    main()
