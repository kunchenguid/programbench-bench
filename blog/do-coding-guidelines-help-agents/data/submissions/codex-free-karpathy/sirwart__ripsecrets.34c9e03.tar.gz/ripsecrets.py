#!/usr/bin/env python3
import math
import os
import re
import stat
import sys

VERSION = "ripsecrets 0.1.11"
SHORT_HELP = """A command-line tool to prevent committing secret keys into your source code

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...  Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided
      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit
      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line
      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""
LONG_HELP = """ripsecrets searches files and directories recursively for secret API keys.
It's primarily designed to be used as a pre-commit to prevent committing
secrets into version control.

Usage: executable [OPTIONS] [Source files]...

Arguments:
  [Source files]...
          Source files. Can be files or directories. Defaults to '.'

Options:
      --install-pre-commit
          Install `ripsecrets` as a pre-commit hook automatically in git directory provided

      --strict-ignore
          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit

      --only-matching
          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line

      --additional-pattern <ADDITIONAL_PATTERNS>
          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

# Translated from the observable regex in the reference error message, split into
# alternatives so generic captured values can receive a randomness check.
RAW_PATTERNS = [
    r"[A-Za-z]+://\S{3,50}:(\S{8,50})@[\dA-Za-z#%&+./:=?_~-]+",
    r"\beyJ[\dA-Za-z=_-]+(?:\.[\dA-Za-z=_-]{3,}){1,4}",
    r"(?:gh[oprsu]|github_pat)_[\dA-Za-z_]{36}",
    r"glpat-[\dA-Za-z_=-]{20,22}",
    r"[rs]k_live_[\dA-Za-z]{24,247}",
    r"sq0i[a-z]{2}-[\dA-Za-z_-]{22,43}",
    r"sq0c[a-z]{2}-[\dA-Za-z_-]{40,50}",
    r"EAAA[\dA-Za-z+=-]{60}",
    r"AccountKey=[\d+/=A-Za-z]{88}",
    r"AIzaSy[\dA-Za-z_-]{33}",
    r"npm_[\dA-Za-z]{36}",
    r"//.+/:_authToken=[\dA-Za-z_-]+",
    r"xox[aboprs]-(?:\d+-)+[\da-z]+",
    r"<master>\{[\dA-Za-z]+\\}</master>",
    r"https://hooks\.slack\.com/services/T[\dA-Za-z_]+/B[\dA-Za-z_]+/[\dA-Za-z_]+",
    r"SG\.[\dA-Za-z_-]{22}\.[\dA-Za-z_-]{43}",
    r"(?:AC|SK)[\da-z]{32}",
    r"[\da-f]{32}-us\d{1,2}",
    r"s-s4t2(?:af|ud)-[\da-f]{64}",
    r"PuTTY-User-Key-File-2",
    r"AGE-SECRET-KEY-1[\dA-Z]{58}",
    r"-{5}BEGIN DSA PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)",
    r"-{5}BEGIN EC PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)",
    r"-{5}BEGIN OPENSSH PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)",
    r"-{5}BEGIN PGP PRIVATE KEY BLOCK-{5}(?:$|[^-]{63,}-{5}END)",
    r"-{5}BEGIN PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)",
    r"-{5}BEGIN RSA PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)",
    r"-{5}BEGIN SSH2 ENCRYPTED PRIVATE KEY-{5}(?:$|[^-]{63,}-{5}END)",
]
GENERIC_PATTERN = re.compile(r"(?i:key|token|secret|password)\w*[\"']?]?\s*(?:[:=]|:=|=>|<-|>)\s*[\t \"'`]?([\w+./=~\-\\`^]{15,90})(?:[\t\n \"'`]|</|$)")
COMPILED = [(re.compile(p), bool(re.compile(p).groups)) for p in RAW_PATTERNS]

class Options:
    def __init__(self):
        self.strict_ignore = False
        self.only_matching = False
        self.install = False
        self.additional = []
        self.sources = []

def print_err(msg):
    sys.stderr.write(msg + "\n")

def parse_args(argv):
    opts = Options()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            sys.stdout.write(SHORT_HELP if a == "-h" else LONG_HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--strict-ignore":
            opts.strict_ignore = True
        elif a == "--only-matching":
            opts.only_matching = True
        elif a == "--install-pre-commit":
            opts.install = True
        elif a == "--additional-pattern":
            i += 1
            if i >= len(argv):
                print_err("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>'")
                raise SystemExit(2)
            opts.additional.append(argv[i])
        elif a.startswith("--additional-pattern="):
            opts.additional.append(a.split("=", 1)[1])
        elif a.startswith("-"):
            print_err(f"error: unexpected argument '{a}' found")
            raise SystemExit(2)
        else:
            opts.sources.append(a)
        i += 1
    if not opts.sources:
        opts.sources = ["."]
    return opts

def entropy(s):
    if not s:
        return 0.0
    return -sum((s.count(c) / len(s)) * math.log2(s.count(c) / len(s)) for c in set(s))

def random_enough(s):
    t = s.strip(" \t\r\n'\"`")
    if len(t) < 15:
        return False
    classes = sum(bool(re.search(p, t)) for p in [r"[a-z]", r"[A-Z]", r"\d", r"[^A-Za-z0-9]"])
    if re.fullmatch(r"[A-Za-z]+", t):
        return False
    if re.fullmatch(r"\d+", t):
        return False
    if re.fullmatch(r"[A-Za-z]+\d+", t):
        return False
    if classes >= 2 and entropy(t) >= 2.45:
        return True
    return False

def load_ignore(root):
    patterns, secrets = [], set()
    path = os.path.join(root, ".secretsignore")
    in_secrets = False
    try:
        lines = open(path, "r", encoding="utf-8", errors="ignore").read().splitlines()
    except OSError:
        return patterns, secrets
    for line in lines:
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s == "[secrets]":
            in_secrets = True
            continue
        if in_secrets:
            secrets.add(s)
        else:
            patterns.append(s)
    return patterns, secrets

def rel_for_ignore(path):
    return os.path.relpath(path, os.getcwd()).replace(os.sep, "/")

def path_ignored(path, patterns, is_dir=False):
    rel = rel_for_ignore(path)
    base = os.path.basename(path)
    for pat in patterns:
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        dir_pat = pat.endswith("/")
        core = pat.strip("/") if dir_pat else pat
        hit = False
        if dir_pat:
            hit = rel == core or rel.startswith(core + "/")
        elif "/" in core:
            hit = rel == core or rel.startswith(core.rstrip("/") + "/")
        else:
            parts = rel.split("/")
            hit = core in parts or base == core
        if hit:
            return not neg
    return False

def display_path(path, source):
    if os.path.isfile(source):
        return source
    rel = os.path.relpath(path, os.getcwd())
    if source == "." or source == "./":
        return "./" + rel if not rel.startswith("./") else rel
    return rel

def iter_files(sources, patterns, strict):
    for src in sources:
        if not os.path.exists(src):
            continue
        explicit_ignored = path_ignored(src, patterns, os.path.isdir(src))
        if strict and explicit_ignored:
            continue
        if os.path.isfile(src):
            yield src, src
            continue
        for root, dirs, files in os.walk(src):
            bypass_ignore = explicit_ignored and not strict
            dirs[:] = [d for d in dirs if d != ".git" and (bypass_ignore or not path_ignored(os.path.join(root, d), patterns, True))]
            for name in files:
                p = os.path.join(root, name)
                if not bypass_ignore and path_ignored(p, patterns, False):
                    continue
                yield p, src

def line_matches(line, add_res):
    out = []
    for regex, has_group in COMPILED:
        for m in regex.finditer(line):
            secret = next((g for g in m.groups() if g), m.group(0)) if has_group else m.group(0)
            out.append((m.group(0), secret))
    for m in GENERIC_PATTERN.finditer(line):
        secret = m.group(1)
        if random_enough(secret):
            out.append((m.group(0).rstrip(), secret))
    for regex in add_res:
        for m in regex.finditer(line):
            if m.groups():
                secret = next((g for g in m.groups() if g), "")
                if secret and random_enough(secret):
                    out.append((m.group(0), secret))
            else:
                out.append((m.group(0), m.group(0)))
    return out

def scan(opts):
    add_res = []
    try:
        for p in opts.additional:
            add_res.append(re.compile(p))
    except re.error as e:
        print_err("Error: regex parse error:")
        print_err(str(e))
        return 2
    patterns, ignored_secrets = load_ignore(os.getcwd())
    found = False
    for path, src in iter_files(opts.sources, patterns, opts.strict_ignore):
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                for lineno, line in enumerate(f, 1):
                    clean = line.rstrip("\n")
                    for whole, secret in line_matches(line, add_res):
                        if secret in ignored_secrets or whole in ignored_secrets:
                            continue
                        found = True
                        shown = secret if opts.only_matching else clean
                        print(f"{display_path(path, src)}:{lineno}:{shown}")
                        break
        except OSError:
            pass
    return 1 if found else 0

def install_hook():
    gitdir = os.path.join(os.getcwd(), ".git")
    if not os.path.isdir(gitdir):
        print_err("Error: .git directory not found")
        return 2
    hooks = os.path.join(gitdir, "hooks")
    os.makedirs(hooks, exist_ok=True)
    hook = os.path.join(hooks, "pre-commit")
    with open(hook, "w", encoding="utf-8") as f:
        f.write("ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n")
    os.chmod(hook, os.stat(hook).st_mode | stat.S_IXUSR)
    return 0

def main(argv):
    opts = parse_args(argv)
    if opts.install:
        return install_hook()
    return scan(opts)

if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
