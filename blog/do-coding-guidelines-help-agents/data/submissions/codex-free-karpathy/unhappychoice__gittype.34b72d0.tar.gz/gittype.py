#!/usr/bin/env python3
import os
import sys
import time
from pathlib import Path

VERSION = "gittype 0.8.0"
LANGS_LOWER = "rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig"
LANGS_TITLE = "C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig"

ROOT_HELP_LONG = f"""GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            {LANGS_LOWER}
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

ROOT_HELP_SHORT = """A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version
"""

HELP = {
    "history": """Show session history

Usage: executable history

Options:
  -h, --help  Print help
""",
    "stats": """Show analytics

Usage: executable stats

Options:
  -h, --help  Print help
""",
    "export": """Export session data

Usage: executable export [OPTIONS]

Options:
      --format <FORMAT>  Export format [default: json]
      --output <OUTPUT>  Output file path
  -h, --help             Print help
""",
    "cache": """Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
""",
    "repo": """Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
""",
    "trending_long": f"""Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: {LANGS_TITLE}

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')
""",
    "trending_short": """Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]   Programming language to filter trending repositories
  [REPO_NAME]  Specific repository name to select from trending list

Options:
      --period <PERIOD>  Time period for trending (daily, weekly, monthly) [default: daily]
  -h, --help             Print help (see more with '--help')
""",
    "cache_stats": """Show cache statistics

Usage: executable cache stats

Options:
  -h, --help  Print help
""",
    "cache_clear": """Clear all cached challenges

Usage: executable cache clear

Options:
  -h, --help  Print help
""",
    "cache_list": """List cached repository keys

Usage: executable cache list

Options:
  -h, --help  Print help
""",
    "repo_list": """List all cached repositories

Usage: executable repo list

Options:
  -h, --help  Print help
""",
    "repo_clear": """Clear all cached repositories

Usage: executable repo clear [OPTIONS]

Options:
      --force  Force clear without confirmation
  -h, --help   Print help
""",
    "repo_play": """Play a cached repository interactively

Usage: executable repo play

Options:
  -h, --help  Print help
""",
}

SUBS = {"history", "stats", "export", "cache", "repo", "trending", "help"}


def out(text=""):
    sys.stdout.write(text)
    if text and not text.endswith("\n"):
        sys.stdout.write("\n")


def err(text=""):
    if text == "":
        sys.stderr.write("\n")
        return
    sys.stderr.write(text)
    if not text.endswith("\n"):
        sys.stderr.write("\n")


def die_parse(message, usage=None, tip=None):
    err(f"error: {message}")
    err()
    if tip:
        err(f"  tip: {tip}")
        err()
    if usage:
        err(usage)
        err()
    err("For more information, try '--help'.")
    return 2


def print_help(key):
    if key == "root_long":
        out(ROOT_HELP_LONG)
    elif key == "root_short":
        out(ROOT_HELP_SHORT)
    else:
        out(HELP[key])
    return 0


def not_implemented(name, fmt=None, output=None):
    out(f"❌ {name} command is not yet implemented")
    if fmt is not None:
        out(f"💡 Requested format: {fmt}")
    if output is not None:
        out(f"💡 Requested output: {output}")
    out("💡 This feature is planned for a future release")
    return 1


def log_terminal_error(argv):
    stamp = time.strftime("%Y%m%d_%H%M%S", time.gmtime())
    human = time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())
    name = f"gittype_error_{stamp}.log"
    args = ["./executable"] + argv
    body = (
        f"ERROR OCCURRED AT: {human}\n"
        'ERROR TYPE: "gittype::domain::error::GitTypeError"\n'
        "ERROR MESSAGE: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)\n"
        'EXECUTABLE: "/workspace/executable"\n'
        f'WORKING_DIR: "{os.getcwd()}"\n'
        f"COMMAND_ARGS: {repr(args).replace(chr(39), chr(34))}\n"
        "OS: linux\nARCH: x86_64\n\n"
    )
    try:
        with open(name, "a", encoding="utf-8") as f:
            f.write(body)
    except OSError:
        pass
    out(f"💾 Error details written to: {name}")
    out("Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)")
    return 1


def cache_dir():
    home = Path(os.environ.get("HOME", "."))
    return home / ".gittype" / "cache"


def repo_dir():
    home = Path(os.environ.get("HOME", "."))
    return home / ".gittype" / "repositories"


def dir_size(path):
    total = 0
    if path.exists():
        for p in path.rglob("*"):
            try:
                if p.is_file():
                    total += p.stat().st_size
            except OSError:
                pass
    return total


def cache_count(path):
    if not path.exists():
        return 0
    try:
        return sum(1 for p in path.iterdir() if not p.name.startswith('.'))
    except OSError:
        return 0


def remove_contents(path):
    if not path.exists():
        return
    for p in sorted(path.iterdir(), reverse=True):
        try:
            if p.is_dir():
                for child in sorted(p.rglob("*"), reverse=True):
                    if child.is_file() or child.is_symlink():
                        child.unlink()
                    elif child.is_dir():
                        child.rmdir()
                p.rmdir()
            else:
                p.unlink()
        except OSError:
            pass


def handle_cache(args):
    if not args or args[0] in ("-h", "--help", "help"):
        return print_help("cache")
    cmd = args[0]
    rest = args[1:]
    subhelps = {"stats": "cache_stats", "clear": "cache_clear", "list": "cache_list"}
    if cmd in subhelps and rest and rest[0] in ("-h", "--help"):
        return print_help(subhelps[cmd])
    if cmd not in {"stats", "clear", "list"}:
        return die_parse(f"unrecognized subcommand '{cmd}'", "Usage: executable cache <COMMAND>")
    if rest:
        return die_parse(f"unexpected argument '{rest[0]}' found", f"Usage: executable cache {cmd}")
    cd = cache_dir()
    if cmd == "stats":
        out("Challenge Cache Statistics:")
        out(f"  Cached repositories: {cache_count(cd)}")
        out(f"  Total size: {dir_size(cd)} bytes")
        return 0
    if cmd == "clear":
        remove_contents(cd)
        out("Challenge cache cleared successfully.")
        return 0
    if not cd.exists() or cache_count(cd) == 0:
        out("No cached challenges found.")
    else:
        for p in sorted(cd.iterdir()):
            if not p.name.startswith('.'):
                out(p.name)
    return 0


def handle_repo(args):
    if not args or args[0] in ("-h", "--help", "help"):
        return print_help("repo")
    cmd = args[0]
    rest = args[1:]
    subhelps = {"list": "repo_list", "clear": "repo_clear", "play": "repo_play"}
    if cmd in subhelps and rest and rest[0] in ("-h", "--help"):
        return print_help(subhelps[cmd])
    if cmd not in {"list", "clear", "play"}:
        return die_parse(f"unrecognized subcommand '{cmd}'", "Usage: executable repo <COMMAND>")
    if cmd == "clear":
        allowed = []
        if rest == ["--force"]:
            allowed = rest
        elif rest:
            return die_parse(f"unexpected argument '{rest[0]}' found", "Usage: executable repo clear [OPTIONS]")
        rd = repo_dir()
        if not rd.exists():
            out("No cached repositories directory found.")
        else:
            remove_contents(rd)
            out("Cached repositories cleared successfully.")
        return 0
    if rest:
        return die_parse(f"unexpected argument '{rest[0]}' found", f"Usage: executable repo {cmd}")
    return log_terminal_error(["repo", cmd])


def handle_export(args):
    fmt = "json"
    output_path = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            return print_help("export")
        if a == "--format":
            if i + 1 >= len(args):
                return die_parse("a value is required for '--format <FORMAT>' but none was supplied")
            fmt = args[i + 1]
            i += 2
        elif a == "--output":
            if i + 1 >= len(args):
                return die_parse("a value is required for '--output <OUTPUT>' but none was supplied")
            output_path = args[i + 1]
            i += 2
        else:
            return die_parse(f"unexpected argument '{a}' found", "Usage: executable export [OPTIONS]")
    return not_implemented("Export", fmt, output_path)


def handle_trending(args):
    if args and args[0] == "-h":
        return print_help("trending_short")
    if args and args[0] == "--help":
        return print_help("trending_long")
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--period":
            if i + 1 >= len(args):
                return die_parse("a value is required for '--period <PERIOD>' but none was supplied")
            i += 2
        elif a.startswith("--"):
            return die_parse(f"unexpected argument '{a}' found", "Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]")
        else:
            rest.append(a)
            i += 1
    if len(rest) >= 2 and "/" not in rest[1]:
        out("⚠️ Repository name must be in format 'owner/repo'")
        return 0
    return log_terminal_error(["trending"] + args)


def handle_help(args):
    if not args:
        return print_help("root_long")
    if args[0] in ("-h", "--help"):
        return die_parse(f"unrecognized subcommand '{args[0]}'", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]")
    topic = args[0]
    tail = args[1:]
    if topic == "trending":
        return print_help("trending_long" if not tail else "trending_long")
    if topic == "cache":
        if tail and tail[0] in {"stats", "clear", "list"}:
            return print_help("cache_" + tail[0])
        return print_help("cache")
    if topic == "repo":
        if tail and tail[0] in {"list", "clear", "play"}:
            return print_help("repo_" + tail[0])
        return print_help("repo")
    if topic in {"history", "stats", "export"}:
        return print_help(topic)
    return die_parse(f"unrecognized subcommand '{topic}'", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]")


def main(argv):
    if not argv:
        return log_terminal_error([])
    if argv[0] == "-h":
        return print_help("root_short")
    if argv[0] == "--help":
        return print_help("root_long")
    if argv[0] in ("-V", "--version"):
        out(VERSION)
        return 0

    positional = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in SUBS:
            break
        if a == "--repo":
            if i + 1 >= len(argv):
                return die_parse("a value is required for '--repo <REPO>' but none was supplied")
            i += 2
        elif a == "--langs":
            if i + 1 >= len(argv):
                return die_parse("a value is required for '--langs <LANGS>' but none was supplied")
            i += 2
        elif a.startswith("--"):
            return die_parse(f"unexpected argument '{a}' found", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]", f"to pass '{a}' as a value, use '-- {a}'")
        elif a.startswith("-"):
            return die_parse(f"unexpected argument '{a}' found", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]")
        else:
            positional.append(a)
            i += 1
            if i < len(argv) and argv[i] not in SUBS:
                # Clap would reject an extra positional for this interface.
                if argv[i].startswith("-"):
                    continue
                return die_parse(f"unexpected argument '{argv[i]}' found", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]")
    if i >= len(argv):
        return log_terminal_error(argv)
    cmd = argv[i]
    rest = argv[i + 1:]
    if cmd == "history":
        if rest and rest[0] in ("-h", "--help"):
            return print_help("history")
        if rest:
            return die_parse(f"unexpected argument '{rest[0]}' found", "Usage: executable history")
        return not_implemented("History")
    if cmd == "stats":
        if rest and rest[0] in ("-h", "--help"):
            return print_help("stats")
        if rest:
            return die_parse(f"unexpected argument '{rest[0]}' found", "Usage: executable stats")
        return not_implemented("Stats")
    if cmd == "export":
        return handle_export(rest)
    if cmd == "cache":
        return handle_cache(rest)
    if cmd == "repo":
        return handle_repo(rest)
    if cmd == "trending":
        return handle_trending(rest)
    if cmd == "help":
        return handle_help(rest)
    return die_parse(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]")

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
