package main

import (
	"bytes"
	"crypto/tls"
	"encoding/base64"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"
)

const version = "0.1.0"

type options struct {
	auth     string
	bench    bool
	benchN   int
	benchC   int
	body     string
	form     bool
	json     bool
	pretty   bool
	insecure bool
	proxy    string
	print    string
	version  bool
	download bool
}

type item struct {
	key string
	val string
}

func usage() {
	fmt.Fprint(os.Stderr, `bat is a Go implemented CLI cURL-like tool for humans.

Usage:

	bat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

	bat beego.me

more help information please refer to https://github.com/astaxie/bat

`)
}

func main() {
	log.SetFlags(log.LstdFlags | log.Lmicroseconds | log.Lshortfile)
	var opt options
	fs := flag.NewFlagSet("bat", flag.ContinueOnError)
	fs.Usage = usage
	fs.StringVar(&opt.auth, "auth", "", "")
	fs.StringVar(&opt.auth, "a", "", "")
	fs.BoolVar(&opt.bench, "bench", false, "")
	fs.BoolVar(&opt.bench, "b", false, "")
	fs.IntVar(&opt.benchN, "b.N", 1000, "")
	fs.IntVar(&opt.benchC, "b.C", 100, "")
	fs.StringVar(&opt.body, "body", "", "")
	fs.BoolVar(&opt.form, "form", false, "")
	fs.BoolVar(&opt.form, "f", false, "")
	fs.BoolVar(&opt.json, "json", true, "")
	fs.BoolVar(&opt.json, "j", true, "")
	fs.BoolVar(&opt.pretty, "pretty", true, "")
	fs.BoolVar(&opt.pretty, "p", true, "")
	fs.BoolVar(&opt.insecure, "insecure", false, "")
	fs.BoolVar(&opt.insecure, "i", false, "")
	fs.StringVar(&opt.proxy, "proxy", "", "")
	fs.StringVar(&opt.print, "print", "A", "")
	fs.BoolVar(&opt.version, "version", false, "")
	fs.BoolVar(&opt.version, "v", false, "")
	fs.BoolVar(&opt.download, "download", false, "")
	if err := fs.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}
	if opt.version {
		fmt.Println("Version: 0.1.0")
		os.Exit(2)
	}
	args := fs.Args()
	if len(args) == 0 {
		usage()
		return
	}
	method, target, rest := parseCommand(args)
	if target == "" {
		usage()
		return
	}
	u, err := normalizeURL(target)
	if err != nil {
		log.Fatal(err)
	}
	headers, values, files := parseItems(rest)
	if method == "" {
		if len(values) > 0 || len(files) > 0 {
			method = "POST"
		} else {
			method = "GET"
		}
	}
	if strings.EqualFold(method, "GET") && len(values) > 0 {
		q := u.Query()
		for _, v := range values {
			q.Add(v.key, v.val)
		}
		u.RawQuery = q.Encode()
		values = nil
	}
	client := makeClient(opt)
	if opt.bench {
		runBench(client, method, u.String(), headers, values, files, opt)
		return
	}
	req, err := makeRequest(method, u.String(), headers, values, files, opt)
	if err != nil {
		log.Fatal(err)
	}
	resp, err := client.Do(req)
	if err != nil {
		log.Fatalf("can't get the url %v", err)
	}
	defer resp.Body.Close()
	if opt.download {
		if err := downloadResponse(resp, u); err != nil {
			log.Fatal(err)
		}
		return
	}
	out, _ := io.ReadAll(resp.Body)
	printBody(out, resp.Header.Get("Content-Type"), opt.pretty)
}

func parseCommand(args []string) (string, string, []string) {
	if len(args) >= 2 && isMethod(args[0]) {
		return strings.ToUpper(args[0]), args[1], args[2:]
	}
	return "", args[0], args[1:]
}

func isMethod(s string) bool {
	switch strings.ToUpper(s) {
	case "GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS":
		return true
	}
	return false
}

func normalizeURL(raw string) (*url.URL, error) {
	if !strings.Contains(raw, "://") {
		raw = "http://" + raw
	}
	return url.Parse(raw)
}

func parseItems(args []string) (http.Header, []item, []item) {
	headers := http.Header{}
	var values, files []item
	for _, a := range args {
		if i := strings.Index(a, ":"); i > 0 && !strings.Contains(a[:i], "=") {
			headers.Set(a[:i], a[i+1:])
			continue
		}
		if i := strings.Index(a, "@"); i > 0 && !strings.Contains(a[:i], "=") {
			files = append(files, item{a[:i], a[i+1:]})
			continue
		}
		if i := strings.Index(a, "="); i > 0 {
			values = append(values, item{a[:i], a[i+1:]})
		}
	}
	return headers, values, files
}

func makeClient(opt options) *http.Client {
	tr := &http.Transport{}
	if opt.insecure {
		tr.TLSClientConfig = &tls.Config{InsecureSkipVerify: true}
	}
	if opt.proxy != "" {
		p, err := url.Parse(opt.proxy)
		if err == nil {
			tr.Proxy = http.ProxyURL(p)
		}
	}
	return &http.Client{Transport: tr}
}

func makeRequest(method, target string, headers http.Header, values, files []item, opt options) (*http.Request, error) {
	body, contentType, err := requestBody(values, files, opt)
	if err != nil {
		return nil, err
	}
	req, err := http.NewRequest(method, target, body)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "bat/0.1.0")
	req.Header.Set("Accept", "application/json")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	for k, vals := range headers {
		for _, v := range vals {
			req.Header.Set(k, v)
		}
	}
	if contentType != "" {
		req.Header.Set("Content-Type", contentType)
	}
	if opt.auth != "" {
		user, pass, _ := strings.Cut(opt.auth, ":")
		req.Header.Set("Authorization", "Basic "+base64.StdEncoding.EncodeToString([]byte(user+":"+pass)))
	}
	return req, nil
}

func requestBody(values, files []item, opt options) (io.Reader, string, error) {
	if opt.body != "" {
		return strings.NewReader(opt.body), "", nil
	}
	if len(files) > 0 && !opt.form {
		return strings.NewReader(""), "", nil
	}
	if opt.form {
		if len(files) > 0 {
			var buf bytes.Buffer
			w := multipart.NewWriter(&buf)
			for _, v := range values {
				_ = w.WriteField(v.key, v.val)
			}
			for _, f := range files {
				fh, err := os.Open(f.val)
				if err != nil {
					continue
				}
				part, err := w.CreateFormFile(f.key, filepath.Base(f.val))
				if err == nil {
					_, _ = io.Copy(part, fh)
				}
				_ = fh.Close()
			}
			_ = w.Close()
			return &buf, w.FormDataContentType(), nil
		}
		form := url.Values{}
		for _, v := range values {
			form.Add(v.key, v.val)
		}
		return strings.NewReader(form.Encode()), "application/x-www-form-urlencoded", nil
	}
	if len(values) > 0 {
		m := map[string]string{}
		keys := make([]string, 0, len(values))
		for _, v := range values {
			if _, ok := m[v.key]; !ok {
				keys = append(keys, v.key)
			}
			m[v.key] = v.val
		}
		sort.Strings(keys)
		var buf bytes.Buffer
		buf.WriteByte('{')
		for i, k := range keys {
			if i > 0 {
				buf.WriteByte(',')
			}
			kb, _ := json.Marshal(k)
			vb, _ := json.Marshal(m[k])
			buf.Write(kb)
			buf.WriteByte(':')
			buf.Write(vb)
		}
		buf.WriteString("}\n")
		return &buf, "application/json", nil
	}
	return nil, "", nil
}

func printBody(body []byte, contentType string, pretty bool) {
	if pretty && strings.Contains(strings.ToLower(contentType), "json") {
		var v any
		if json.Unmarshal(body, &v) == nil {
			var buf bytes.Buffer
			enc := json.NewEncoder(&buf)
			enc.SetEscapeHTML(false)
			enc.SetIndent("", "  ")
			if err := enc.Encode(v); err == nil {
				fmt.Println()
				fmt.Print(buf.String())
				return
			}
		}
	}
	fmt.Println()
	fmt.Print(string(body))
}

func downloadResponse(resp *http.Response, u *url.URL) error {
	fmt.Printf("\x1b[95m%s\x1b[0m \x1b[92m%s\x1b[0m\n", resp.Proto, resp.Status)
	keys := make([]string, 0, len(resp.Header))
	for k := range resp.Header {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		fmt.Printf("\x1b[90m%s\x1b[0m : \x1b[96m%s\x1b[0m\n", k, strings.Join(resp.Header[k], ", "))
	}
	fmt.Println()
	name := filepath.Base(u.Path)
	if name == "." || name == "/" || name == "" {
		name = "index.html"
	}
	fmt.Printf("Downloading to \"%s\"\n", name)
	f, err := os.Create(name)
	if err != nil {
		return err
	}
	defer f.Close()
	n, err := io.Copy(f, resp.Body)
	if err != nil {
		return err
	}
	fmt.Printf("\r%d B / %d B [====================================================================================] 100.00 %%\n", n, n)
	return nil
}

func runBench(client *http.Client, method, target string, headers http.Header, values, files []item, opt options) {
	if opt.benchN <= 0 {
		opt.benchN = 1
	}
	if opt.benchC <= 0 {
		opt.benchC = 1
	}
	start := time.Now()
	jobs := make(chan int)
	var wg sync.WaitGroup
	var mu sync.Mutex
	codes := map[int]int{}
	var totalBytes int64
	var fastest, slowest, total time.Duration
	for i := 0; i < opt.benchC; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for range jobs {
				req, err := makeRequest(method, target, headers, values, files, opt)
				if err != nil {
					continue
				}
				t0 := time.Now()
				resp, err := client.Do(req)
				d := time.Since(t0)
				if err != nil {
					continue
				}
				b, _ := io.Copy(io.Discard, resp.Body)
				resp.Body.Close()
				mu.Lock()
				codes[resp.StatusCode]++
				totalBytes += b
				total += d
				if fastest == 0 || d < fastest {
					fastest = d
				}
				if d > slowest {
					slowest = d
				}
				mu.Unlock()
			}
		}()
	}
	for i := 0; i < opt.benchN; i++ {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	elapsed := time.Since(start)
	avg := time.Duration(0)
	done := 0
	for _, n := range codes {
		done += n
	}
	if done > 0 {
		avg = total / time.Duration(done)
	}
	fmt.Println()
	fmt.Println("Summary:")
	fmt.Printf("  Total:\t%.4f secs.\n", elapsed.Seconds())
	fmt.Printf("  Slowest:\t%.4f secs.\n", slowest.Seconds())
	fmt.Printf("  Fastest:\t%.4f secs.\n", fastest.Seconds())
	fmt.Printf("  Average:\t%.4f secs.\n", avg.Seconds())
	if elapsed.Seconds() > 0 {
		fmt.Printf("  Requests/sec:\t%.4f\n", float64(done)/elapsed.Seconds())
	}
	fmt.Printf("  Total Data Received:\t%d bytes.\n", totalBytes)
	if done > 0 {
		fmt.Printf("  Response Size per Request:\t%d bytes.\n", totalBytes/int64(done))
	}
	fmt.Println()
	fmt.Println("Status code distribution:")
	keys := make([]int, 0, len(codes))
	for k := range codes {
		keys = append(keys, k)
	}
	sort.Ints(keys)
	for _, k := range keys {
		fmt.Printf("  [%d]\t%d responses\n", k, codes[k])
	}
}
