module bat-reimplementation

go 1.20
