#!/usr/bin/env python3
import os
import sys
import re
import subprocess
from datetime import datetime, date, timedelta

VERSION = "bartib 1.1.0"
UNDER = "\033[4m"
BOLD = "\033[1m"
DIM = "\033[2m"
ITALIC = "\033[3m"
GREEN = "\033[32m"
RESET = "\033[0m"


class Activity:
    def __init__(self, start, end, project, desc, line=0):
        self.start = start
        self.end = end
        self.project = project
        self.desc = desc
        self.line = line

    def running(self):
        return self.end is None


def usage_top():
    print("""bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run `bartib [SUBCOMMAND] --help`.
To get started, view the `start` help with `bartib start --help`""")


HELP = {
    "start": """executable-start 
starts a new activity

USAGE:
    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)""",
    "stop": """executable-stop 
stops all currently running activities

USAGE:
    executable stop [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -t, --time <TIME>    the time for changing the activity status (HH:MM)""",
    "cancel": """executable-cancel 
cancels all currently running activities

USAGE:
    executable cancel

FLAGS:
    -h, --help    Prints help information""",
    "change": """executable-change 
changes the current activity

USAGE:
    executable change [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)""",
    "continue": """executable-continue 
continues a previous activity

USAGE:
    executable continue [OPTIONS] [NUMBER]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -d, --description <DESCRIPTION>    the description of the new activity
    -p, --project <PROJECT>            the project to which the new activity belongs
    -t, --time <TIME>                  the time for changing the activity status (HH:MM)

ARGS:
    <NUMBER>    the number of the activity to continue (see subcommand `last`) [default: 0]""",
    "current": """executable-current 
lists all currently running activities

USAGE:
    executable current

FLAGS:
    -h, --help    Prints help information""",
    "edit": """executable-edit 
opens the activity log in an editor

USAGE:
    executable edit [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -e <editor>        the command to start your preferred text editor [env: EDITOR=]""",
    "last": """executable-last 
displays the descriptions and projects of recent activities

USAGE:
    executable last [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -n, --number <NUMBER>    maximum number of lines to display [default: 10]""",
    "list": """executable-list 
list recent activities

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --no_grouping     do not group activities by date in list
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -n, --number <NUMBER>      maximum number of activities to display
    -p, --project <PROJECT>    do list activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or
                               hours. E.g. 15m or 4h
        --to <TO_DATE>         end of date range (inclusive)""",
    "projects": """executable-projects 
list all projects

USAGE:
    executable projects [FLAGS]

FLAGS:
    -c, --current      prints currently running projects only
    -h, --help         Prints help information
    -n, --no-quotes    prints projects without quotes""",
    "report": """executable-report 
reports duration of tracked activities

USAGE:
    executable report [FLAGS] [OPTIONS]

FLAGS:
        --current_week    show activities of the current week
    -h, --help            Prints help information
        --last_week       show activities of the last week
        --today           show activities of the current day
        --yesterday       show yesterdays' activities

OPTIONS:
    -d, --date <DATE>          show activities of a certain date only
        --from <FROM_DATE>     begin of date range (inclusive)
    -p, --project <PROJECT>    do report activities for this project only
        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or
                               hours. E.g. 15m or 4h
        --to <TO_DATE>         end of date range (inclusive)""",
    "search": """executable-search 
search for existing descriptions and projects

USAGE:
    executable search <SEARCH_TERM>

FLAGS:
    -h, --help    Prints help information

ARGS:
    <SEARCH_TERM>    the search term [default: '']""",
    "status": """executable-status 
shows current status and time reports for today, current week, and current month

USAGE:
    executable status [OPTIONS]

FLAGS:
    -h, --help    Prints help information

OPTIONS:
    -p, --project <PROJECT>    show status for this project only""",
    "check": """executable-check 
checks file and reports parsing errors

USAGE:
    executable check

FLAGS:
    -h, --help    Prints help information""",
    "sanity": """executable-sanity 
checks sanity of bartib log

USAGE:
    executable sanity

FLAGS:
    -h, --help    Prints help information""",
}


def simple_help(cmd):
    if cmd in HELP:
        print(HELP[cmd])
    else:
        usage_top()


def fail_read(path):
    print(f"Error: Could not read from file: {path}\n\nCaused by:\n    No such file or directory (os error 2)")
    sys.exit(1)


def parse_dt(s):
    return datetime.strptime(s, "%Y-%m-%d %H:%M")


LINE_RE = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2})(?: - (\d{4}-\d{2}-\d{2} \d{2}:\d{2}))? \| (.*?) \| (.*)$")


def read_file(path, allow_missing=False):
    if not os.path.exists(path):
        if allow_missing:
            return [], []
        fail_read(path)
    acts, errors = [], []
    with open(path, "r", encoding="utf-8") as f:
        for i, raw in enumerate(f, 1):
            line = raw.rstrip("\n")
            if not line:
                continue
            m = LINE_RE.match(line)
            if not m:
                errors.append((i, line))
                continue
            try:
                start = parse_dt(m.group(1))
                end = parse_dt(m.group(2)) if m.group(2) else None
                acts.append(Activity(start, end, m.group(3), m.group(4), i))
            except Exception:
                errors.append((i, line))
    return acts, errors


def write_file(path, acts):
    with open(path, "w", encoding="utf-8") as f:
        for a in acts:
            if a.end:
                f.write(f"{fmt_dt(a.start)} - {fmt_dt(a.end)} | {a.project} | {a.desc}\n")
            else:
                f.write(f"{fmt_dt(a.start)} | {a.project} | {a.desc}\n")


def fmt_dt(d):
    return d.strftime("%Y-%m-%d %H:%M")


def fmt_time(d):
    return d.strftime("%H:%M")


def duration_min(a, now=None):
    if now is None:
        now = datetime.now().replace(second=0, microsecond=0)
    end = a.end or now
    return max(0, int((end - a.start).total_seconds() // 60))


def fmt_dur(minutes):
    minutes = int(minutes)
    if minutes < 1:
        return "<1m"
    h, m = divmod(minutes, 60)
    if h:
        return f"{h}h {m:02d}m"
    return f"{m}m"


def parse_time_arg(t):
    now = datetime.now().replace(second=0, microsecond=0)
    if not t:
        return now
    try:
        hh, mm = t.split(":", 1)
        hh, mm = int(hh), int(mm)
        if not (0 <= hh <= 23 and 0 <= mm <= 59):
            raise ValueError()
        return now.replace(hour=hh, minute=mm)
    except Exception:
        print(f'Can not parse "{t}" as time. Argument for -t/--time is ignored (input is out of range)')
        return now


def opt_value(args, *names, default=None):
    for i, a in enumerate(args):
        if a in names and i + 1 < len(args):
            return args[i + 1]
        for n in names:
            if a.startswith(n + "="):
                return a.split("=", 1)[1]
    return default


def has(args, *names):
    return any(a in names for a in args)


def strip_opts(args):
    out, skip = [], False
    valued = {"-d", "--description", "-p", "--project", "-t", "--time", "-n", "--number", "--from", "--to", "--round", "-e", "--editor", "--date"}
    for i, a in enumerate(args):
        if skip:
            skip = False
            continue
        if a in valued:
            skip = True
        elif any(a.startswith(v + "=") for v in valued):
            continue
        elif a.startswith("-"):
            continue
        else:
            out.append(a)
    return out


def stop_running(acts, when, messages=False):
    stopped = []
    for a in acts:
        if a.running():
            a.end = when
            stopped.append(a)
            if messages:
                print(f'Stopped activity: "{a.desc}" ({a.project}) started at {fmt_dt(a.start)} ({fmt_dur(duration_min(a, when))})')
    return stopped


def cmd_start(path, args, change_word="Started"):
    desc = opt_value(args, "-d", "--description")
    proj = opt_value(args, "-p", "--project")
    if desc is None or proj is None:
        if desc is None:
            print("error: The following required arguments were not provided:\n    --description <DESCRIPTION>")
        else:
            print("error: The following required arguments were not provided:\n    --project <PROJECT>")
        sys.exit(1)
    when = parse_time_arg(opt_value(args, "-t", "--time"))
    acts, _ = read_file(path, allow_missing=True)
    stop_running(acts, when, messages=(change_word == "Started"))
    a = Activity(when, None, proj, desc)
    acts.append(a)
    write_file(path, acts)
    print(f'{change_word} activity: "{desc}" ({proj}) at {fmt_dt(when)}' if change_word == "Started" else f'Changed activity: "{desc}" ({proj}) started at {fmt_dt(when)}')


def cmd_stop(path, args):
    when = parse_time_arg(opt_value(args, "-t", "--time"))
    acts, _ = read_file(path)
    stop_running(acts, when, messages=True)
    write_file(path, acts)


def cmd_cancel(path):
    acts, _ = read_file(path)
    kept = []
    for a in acts:
        if a.running():
            print(f'Canceled activity: "{a.desc}" ({a.project}) started at {fmt_dt(a.start)}')
        else:
            kept.append(a)
    write_file(path, kept)


def cmd_change(path, args):
    desc = opt_value(args, "-d", "--description")
    proj = opt_value(args, "-p", "--project")
    acts, _ = read_file(path)
    running = [a for a in acts if a.running()]
    if desc is None and running:
        desc = running[-1].desc
    if proj is None and running:
        proj = running[-1].project
    if desc is None or proj is None:
        return
    when = parse_time_arg(opt_value(args, "-t", "--time"))
    acts = [a for a in acts if not a.running()]
    acts.append(Activity(when, None, proj, desc))
    write_file(path, acts)
    print(f'Changed activity: "{desc}" ({proj}) started at {fmt_dt(when)}')


def recent_unique(acts):
    seen, out = set(), []
    for a in reversed(acts):
        key = (a.desc, a.project)
        if key not in seen:
            seen.add(key)
            out.append(a)
    return out


def cmd_continue(path, args):
    acts, _ = read_file(path)
    desc = opt_value(args, "-d", "--description")
    proj = opt_value(args, "-p", "--project")
    plain = strip_opts(args)
    num = 0
    if plain:
        try:
            num = int(plain[0])
        except Exception:
            num = 0
    if desc is None or proj is None:
        rec = recent_unique(acts)
        if rec and 0 <= num < len(rec):
            desc = desc or rec[num].desc
            proj = proj or rec[num].project
    if desc is None or proj is None:
        return
    cmd_start(path, ["-d", desc, "-p", proj, "-t", opt_value(args, "-t", "--time", default="")])


def filtered(acts, args):
    today = date.today()
    start = end = None
    if has(args, "--today"):
        start = end = today
    elif has(args, "--yesterday"):
        start = end = today - timedelta(days=1)
    elif has(args, "--current_week"):
        start = today - timedelta(days=today.weekday())
        end = start + timedelta(days=6)
    elif has(args, "--last_week"):
        end = today - timedelta(days=today.weekday() + 1)
        start = end - timedelta(days=6)
    if opt_value(args, "-d", "--date"):
        start = end = datetime.strptime(opt_value(args, "-d", "--date"), "%Y-%m-%d").date()
    if opt_value(args, "--from"):
        start = datetime.strptime(opt_value(args, "--from"), "%Y-%m-%d").date()
    if opt_value(args, "--to"):
        end = datetime.strptime(opt_value(args, "--to"), "%Y-%m-%d").date()
    proj = opt_value(args, "-p", "--project")
    out = []
    for a in acts:
        if proj is not None and a.project != proj:
            continue
        d = a.start.date()
        if start and d < start:
            continue
        if end and d > end:
            continue
        out.append(a)
    return out, bool(start and end and start == end)


def round_dt(dt, spec):
    if not spec:
        return dt
    m = re.match(r"^(\d+)([mh])$", spec)
    if not m:
        return dt
    mins = int(m.group(1)) * (60 if m.group(2) == "h" else 1)
    if mins <= 0:
        return dt
    base = dt.replace(hour=0, minute=0, second=0, microsecond=0)
    offset = int((dt - base).total_seconds() // 60)
    rounded = int((offset + mins / 2) // mins) * mins
    return base + timedelta(minutes=rounded)


def display_activity(a, show_date=False, round_spec=None, color=False):
    s = round_dt(a.start, round_spec)
    e = round_dt(a.end, round_spec) if a.end else None
    mins = max(0, int(((e or datetime.now().replace(second=0, microsecond=0)) - s).total_seconds() // 60))
    start = fmt_dt(s) if show_date else fmt_time(s)
    stop = fmt_time(e) if e else "-"
    line = f"{start:<16} {stop:<7} {a.desc:<11} {a.project:<7} {fmt_dur(mins):<8} "
    if color or a.running():
        return GREEN + line + RESET
    return line


def cmd_list(path, args):
    acts, _ = read_file(path)
    acts, single_day = filtered(acts, args)
    n = opt_value(args, "-n", "--number")
    if n:
        acts = acts[-int(n):]
    nogroup = has(args, "--no_grouping")
    r = opt_value(args, "--round")
    print(f"\n{UNDER}Started{RESET} {UNDER}Stopped{RESET} {UNDER}Description{RESET} {UNDER}Project{RESET} {UNDER}Duration{RESET} ")
    if nogroup or single_day:
        for a in acts:
            print(display_activity(a, show_date=nogroup, round_spec=r))
        return
    by = {}
    for a in acts:
        by.setdefault(a.start.date(), []).append(a)
    for d in sorted(by):
        total = sum(duration_min(x) for x in by[d] if not x.running())
        if any(x.running() for x in by[d]):
            total += sum(duration_min(x) for x in by[d] if x.running())
        print(f"\n{BOLD}{d.isoformat()}\t{fmt_dur(total)}{RESET}")
        for a in by[d]:
            print(display_activity(a, round_spec=r))
    print()


def cmd_current(path):
    acts, _ = read_file(path)
    cur = [a for a in acts if a.running()]
    if not cur:
        print("No Activity is currently running")
        return
    print(f"\n{UNDER}Started At      {RESET} {UNDER}Description{RESET} {UNDER}Project{RESET} {UNDER}Duration{RESET} ")
    for a in cur:
        print(display_activity(a, show_date=True))


def cmd_projects(path, args):
    acts, _ = read_file(path)
    if has(args, "-c", "--current"):
        projects = sorted({a.project for a in acts if a.running()})
    else:
        projects = sorted({a.project for a in acts})
    for p in projects:
        print(p if has(args, "-n", "--no-quotes") else f'"{p}"')


def cmd_last(path, args, search=None):
    acts, _ = read_file(path)
    rec = recent_unique(acts)
    if search is not None:
        s = search.lower()
        rec = [a for a in rec if s in a.desc.lower() or s in a.project.lower()]
    n = int(opt_value(args, "-n", "--number", default="10"))
    rec = rec[:n]
    print(f"\n{UNDER} # {RESET} {UNDER}Description{RESET} {UNDER}Project{RESET} ")
    for i, a in enumerate(rec):
        print(f"[{i}] {a.desc:<11} {a.project:<7} ")
    print()


def cmd_report(path, args):
    acts, _ = read_file(path)
    acts, _ = filtered(acts, args)
    r = opt_value(args, "--round")
    projects = {}
    for a in acts:
        s = round_dt(a.start, r)
        e = round_dt(a.end, r) if a.end else datetime.now().replace(second=0, microsecond=0)
        mins = max(0, int((e - s).total_seconds() // 60))
        projects.setdefault(a.project, {}).setdefault(a.desc, 0)
        projects[a.project][a.desc] += mins
    total = 0
    print()
    for p in sorted(projects):
        ptotal = sum(projects[p].values())
        total += ptotal
        print(f"{BOLD}{p} {fmt_dur(ptotal)}{RESET}")
        for d in sorted(projects[p]):
            print(f"    {d} {fmt_dur(projects[p][d])}")
        print()
    print(f"{BOLD}Total {fmt_dur(total)}{RESET}\n")


def cmd_status(path, args):
    acts, _ = read_file(path)
    proj = opt_value(args, "-p", "--project")
    if proj:
        acts = [a for a in acts if a.project == proj]
    cur = [a for a in acts if a.running()]
    today = date.today()
    week_start = today - timedelta(days=today.weekday())
    month_start = today.replace(day=1)
    def sum_since(d):
        return sum(duration_min(a) for a in acts if a.start.date() >= d)
    print(f"{DIM}\n ======={RESET}{ITALIC} Status for {RESET}{BOLD}{proj or 'ALL'}{RESET}{ITALIC} projects {RESET}{DIM} ======= ")
    nowtxt = ", ".join(f"{a.desc} ({a.project})" for a in cur) if cur else "NO Activity"
    print(f"{RESET}{DIM}{ITALIC}\n  NOW: {RESET}{BOLD} {nowtxt}\n")
    print(f"{RESET}{ITALIC} {RESET}{DIM}{ITALIC} Today......................... {RESET}{BOLD}{fmt_dur(sum_since(today))}{RESET}")
    print(f"{RESET}{ITALIC} {RESET}{DIM}{ITALIC} Current week.................. {RESET}{BOLD}{fmt_dur(sum_since(week_start))}{RESET}")
    print(f"{RESET}{ITALIC} {RESET}{DIM}{ITALIC} Current month................. {RESET}{BOLD}{fmt_dur(sum_since(month_start))}{RESET}\n{RESET}")


def cmd_check(path):
    _, errors = read_file(path)
    if errors:
        print(f"Found {len(errors)} line(s) with parsing errors\n")
        for i, line in errors:
            print(line)
            print(f"  -> could not parse activity (Line: {i})")
    else:
        print("No parsing errors found")


def cmd_sanity(path):
    acts, _ = read_file(path)
    for a in acts:
        if a.end is None or a.end < a.start:
            ended = fmt_dt(a.end) if a.end else "--"
            print("Activity has negative duration")
            print(f"{a.desc} (Started: {fmt_dt(a.start)}, Ended: {ended}, Line: {a.line})\n")


def main():
    args = sys.argv[1:]
    if not args or args in (["--help"], ["-h"]):
        usage_top()
        return
    if args in (["--version"], ["-V"]):
        print(VERSION)
        return
    file = os.environ.get("BARTIB_FILE", "")
    i = 0
    rest = []
    while i < len(args):
        if args[i] == "-f" and i + 1 < len(args):
            file = args[i + 1]
            i += 2
        elif args[i].startswith("-f="):
            file = args[i].split("=", 1)[1]
            i += 1
        else:
            rest = args[i:]
            break
    if not rest:
        usage_top()
        return
    cmd, cargs = rest[0], rest[1:]
    if cmd == "help":
        simple_help(cargs[0] if cargs else "")
        return
    if has(cargs, "-h", "--help"):
        simple_help(cmd)
        return
    if cmd == "start":
        cmd_start(file, cargs)
    elif cmd == "stop":
        cmd_stop(file, cargs)
    elif cmd == "cancel":
        cmd_cancel(file)
    elif cmd == "change":
        cmd_change(file, cargs)
    elif cmd == "continue":
        cmd_continue(file, cargs)
    elif cmd == "current":
        cmd_current(file)
    elif cmd == "projects":
        cmd_projects(file, cargs)
    elif cmd == "last":
        cmd_last(file, cargs)
    elif cmd == "search":
        terms = strip_opts(cargs)
        cmd_last(file, ["-n", "100000"], search=(terms[0] if terms else ""))
    elif cmd == "list":
        cmd_list(file, cargs)
    elif cmd == "report":
        cmd_report(file, cargs)
    elif cmd == "status":
        cmd_status(file, cargs)
    elif cmd == "check":
        cmd_check(file)
    elif cmd == "sanity":
        cmd_sanity(file)
    elif cmd == "edit":
        editor = opt_value(cargs, "-e", "--editor", default=os.environ.get("EDITOR", "vi"))
        subprocess.call([editor, file])
    else:
        print(f"error: Found argument '{cmd}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable -f <FILE>\n\nFor more information try --help")
        sys.exit(1)


if __name__ == "__main__":
    main()
