#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static const char *VERSION = "xplr 1.1.0";

static void print_help(void) {
  puts("xplr 1.1.0");
  puts("Arijit Basu <hi@arijitbasu.in>");
  puts("A hackable, minimal, fast TUI file explorer");
  puts("");
  puts("USAGE:");
  puts("    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...");
  puts("");
  puts("FLAGS:");
  puts("  -                            Reads new-line (\\n) separated paths from stdin");
  puts("  --                           Denotes the end of command-line flags and options");
  puts("      --force-focus            Focuses on the given <PATH>, even if it is a directory");
  puts("  -h, --help                   Prints help information");
  puts("  -m, --pipe-msg-in            Helps safely passing messages to the active xplr");
  puts("                                 session, use %%, %s and %q as the placeholders");
  puts("  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of");
  puts("                                 passing to the active xplr session");
  puts("      --print-pwd-as-result    Prints the present working directory when quitting");
  puts("                                 with `PrintResultAndQuit`");
  puts("      --read-only              Enables read-only mode (config.general.read_only)");
  puts("      --read0                  Reads paths separated using the null character (\\0)");
  puts("      --write0                 Prints paths separated using the null character (\\0)");
  puts("  -0  --null                   Combines --read0 and --write0");
  puts("  -V, --version                Prints version information");
  puts("");
  puts("OPTIONS:");
  puts("  -c, --config <PATH>             Specifies a custom config file (default is");
  puts("                                    \"$HOME/.config/xplr/init.lua\")");
  puts("  -C, --extra-config <PATH>...    Specifies extra config files to load");
  puts("      --on-load <MESSAGE>...      Sends messages when xplr loads");
  puts("      --vroot <PATH>              Treats the specified path as the virtual root");
  puts("");
  puts("ARGS:");
  puts("  <PATH>            Path to focus on, or enter if directory, (default is `.`)");
  puts("  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly");
}

struct Str {
  char *p;
  size_t n, cap;
};

static void die_oom(void) {
  fputs("error: out of memory\n", stderr);
  exit(1);
}

static void addch(struct Str *s, char c) {
  if (s->n + 2 > s->cap) {
    size_t nc = s->cap ? s->cap * 2 : 128;
    char *p = realloc(s->p, nc);
    if (!p) die_oom();
    s->p = p;
    s->cap = nc;
  }
  s->p[s->n++] = c;
  s->p[s->n] = 0;
}

static void adds(struct Str *s, const char *t) {
  while (*t) addch(s, *t++);
}

static void json_string(struct Str *s, const char *v) {
  addch(s, '"');
  for (const unsigned char *p = (const unsigned char *)v; *p; p++) {
    switch (*p) {
      case '"': adds(s, "\\\""); break;
      case '\\': adds(s, "\\\\"); break;
      case '\b': adds(s, "\\b"); break;
      case '\f': adds(s, "\\f"); break;
      case '\n': adds(s, "\\n"); break;
      case '\r': adds(s, "\\r"); break;
      case '\t': adds(s, "\\t"); break;
      default:
        if (*p < 0x20) {
          char buf[8];
          snprintf(buf, sizeof(buf), "\\u%04x", *p);
          adds(s, buf);
        } else {
          addch(s, (char)*p);
        }
    }
  }
  addch(s, '"');
}

static void yaml_quote(struct Str *s, const char *v) {
  json_string(s, v);
}

static void format_template(struct Str *out, const char *fmt, int argc, char **argv) {
  int ai = 0;
  for (size_t i = 0; fmt[i]; i++) {
    if (fmt[i] != '%') {
      addch(out, fmt[i]);
      continue;
    }
    size_t col = i + 1;
    char next = fmt[++i];
    if (!next) {
      fprintf(stderr, "error: xplr -m: invalid placeholder '%%' at column %zu, use one of '%%s' or '%%q', or escape it using '%%%%'\n", col);
      exit(1);
    }
    bool splat = false;
    if (next == '*') {
      splat = true;
      next = fmt[++i];
    }
    if (next == '%') {
      if (splat) {
        fprintf(stderr, "error: xplr -m: invalid placeholder '%%*%%' at column %zu, use one of '%%s' or '%%q', or escape it using '%%%%'\n", col);
        exit(1);
      }
      addch(out, '%');
    } else if (next == 's' || next == 'q') {
      if (splat) {
        bool first = true;
        for (; ai < argc; ai++) {
          if (!first) addch(out, ',');
          first = false;
          yaml_quote(out, argv[ai]);
        }
      } else {
        if (ai >= argc) {
          fprintf(stderr, "error: xplr -m: placeholder missing value at column %zu\n", col);
          exit(1);
        }
        if (next == 'q') yaml_quote(out, argv[ai]);
        else adds(out, argv[ai]);
        ai++;
      }
    } else {
      fprintf(stderr, "error: xplr -m: invalid placeholder '%%%c' at column %zu, use one of '%%s' or '%%q', or escape it using '%%%%'\n", next, col);
      exit(1);
    }
  }
  if (ai < argc) {
    fputs("error: xplr -m: too many positional values, not enough positional placeholders\n", stderr);
    exit(1);
  }
}

static char *trim(char *s) {
  while (isspace((unsigned char)*s)) s++;
  char *e = s + strlen(s);
  while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
  return s;
}

static void json_from_value(struct Str *out, char *v);

static void json_from_scalar(struct Str *out, char *v) {
  v = trim(v);
  size_t n = strlen(v);
  if (!n) {
    adds(out, "null");
  } else if ((v[0] == '"' && v[n - 1] == '"') || (v[0] == '\'' && v[n - 1] == '\'')) {
    v[n - 1] = 0;
    json_string(out, v + 1);
  } else if (!strcmp(v, "true") || !strcmp(v, "false") || !strcmp(v, "null")) {
    adds(out, v);
  } else {
    bool num = true;
    for (size_t i = 0; i < n; i++) {
      if (!isdigit((unsigned char)v[i]) && v[i] != '-' && v[i] != '+') num = false;
    }
    if (num && n) adds(out, v);
    else json_string(out, v);
  }
}

static char *find_top(char *s, char target) {
  int brace = 0, bracket = 0;
  char quote = 0;
  for (char *p = s; *p; p++) {
    if (quote) {
      if (*p == '\\' && p[1]) p++;
      else if (*p == quote) quote = 0;
      continue;
    }
    if (*p == '"' || *p == '\'') quote = *p;
    else if (*p == '{') brace++;
    else if (*p == '}') brace--;
    else if (*p == '[') bracket++;
    else if (*p == ']') bracket--;
    else if (*p == target && brace == 0 && bracket == 0) return p;
  }
  return NULL;
}

static void json_from_map(struct Str *out, char *body) {
  addch(out, '{');
  bool first = true;
  char *p = body;
  while (*trim(p)) {
    char *comma = find_top(p, ',');
    if (comma) *comma = 0;
    char *colon = find_top(p, ':');
    if (!colon) {
      json_from_scalar(out, p);
    } else {
      *colon = 0;
      char *k = trim(p);
      size_t kn = strlen(k);
      if ((k[0] == '"' || k[0] == '\'') && kn > 1) {
        k[kn - 1] = 0;
        k++;
      }
      if (!first) addch(out, ',');
      first = false;
      json_string(out, k);
      addch(out, ':');
      json_from_value(out, colon + 1);
    }
    if (!comma) break;
    p = comma + 1;
  }
  addch(out, '}');
}

static void json_from_list(struct Str *out, char *body) {
  addch(out, '[');
  bool first = true;
  char *p = body;
  while (*trim(p)) {
    char *comma = find_top(p, ',');
    if (comma) *comma = 0;
    if (!first) addch(out, ',');
    first = false;
    json_from_value(out, p);
    if (!comma) break;
    p = comma + 1;
  }
  addch(out, ']');
}

static void json_from_value(struct Str *out, char *v) {
  v = trim(v);
  size_t n = strlen(v);
  if (n >= 2 && v[0] == '{' && v[n - 1] == '}') {
    v[n - 1] = 0;
    json_from_map(out, v + 1);
  } else if (n >= 2 && v[0] == '[' && v[n - 1] == ']') {
    v[n - 1] = 0;
    json_from_list(out, v + 1);
  } else {
    json_from_scalar(out, v);
  }
}

static char *render_message(const char *templ, int argc, char **argv) {
  struct Str y = {0}, out = {0};
  format_template(&y, templ, argc, argv);
  char *text = trim(y.p ? y.p : "");
  char *colon = find_top(text, ':');
  if (!colon) {
    json_from_scalar(&out, text);
  } else {
    *colon = 0;
    addch(&out, '{');
    json_string(&out, trim(text));
    addch(&out, ':');
    json_from_value(&out, colon + 1);
    addch(&out, '}');
  }
  free(y.p);
  if (!out.p) {
    out.p = malloc(1);
    if (!out.p) die_oom();
    out.p[0] = 0;
  }
  return out.p;
}

static int path_exists(const char *path) {
  struct stat st;
  return stat(path, &st) == 0;
}

int main(int argc, char **argv) {
  if (argc == 1) {
    fputs("error: No such device or address (os error 6)\n", stderr);
    return 1;
  }
  bool end_opts = false, read_stdin = false;
  const char *path = NULL;
  for (int i = 1; i < argc; i++) {
    const char *a = argv[i];
    if (!end_opts && (!strcmp(a, "-h") || !strcmp(a, "--help"))) {
      print_help();
      return 0;
    } else if (!end_opts && (!strcmp(a, "-V") || !strcmp(a, "--version"))) {
      puts(VERSION);
      return 0;
    } else if (!end_opts && (!strcmp(a, "-M") || !strcmp(a, "--print-msg-in"))) {
      if (i + 1 >= argc) {
        fputs("error: The argument '--print-msg-in <FORMAT>' requires a value but none was supplied\n", stderr);
        return 1;
      }
      char *msg = render_message(argv[i + 1], argc - i - 2, argv + i + 2);
      fputs(msg, stdout);
      free(msg);
      return 0;
    } else if (!end_opts && (!strcmp(a, "-m") || !strcmp(a, "--pipe-msg-in"))) {
      if (i + 1 >= argc) {
        fputs("error: The argument '--pipe-msg-in <FORMAT>' requires a value but none was supplied\n", stderr);
        return 1;
      }
      char *msg = render_message(argv[i + 1], argc - i - 2, argv + i + 2);
      const char *pipe = getenv("XPLR_PIPE_MSG_IN");
      if (!pipe) pipe = getenv("XPLR_PIPE_MSG_IN_");
      if (!pipe) {
        fputs("error: XPLR_PIPE_MSG_IN not set\n", stderr);
        free(msg);
        return 1;
      }
      FILE *f = fopen(pipe, "a");
      if (!f) {
        fprintf(stderr, "error: %s (os error %d)\n", strerror(errno), errno);
        free(msg);
        return 1;
      }
      fprintf(f, "%s\n", msg);
      fclose(f);
      free(msg);
      return 0;
    } else if (!end_opts && !strcmp(a, "--")) {
      end_opts = true;
    } else if (!end_opts && !strcmp(a, "-")) {
      read_stdin = true;
    } else if (!end_opts && (!strcmp(a, "--read0") || !strcmp(a, "--write0") || !strcmp(a, "-0") || !strcmp(a, "--null") || !strcmp(a, "--read-only") || !strcmp(a, "--print-pwd-as-result") || !strcmp(a, "--force-focus"))) {
    } else if (!end_opts && (!strcmp(a, "-c") || !strcmp(a, "--config") || !strcmp(a, "--vroot"))) {
      if (i + 1 >= argc) {
        fprintf(stderr, "error: The argument '%s <PATH>' requires a value but none was supplied\n", a);
        return 1;
      }
      if (!path_exists(argv[i + 1])) {
        fprintf(stderr, "error: path doesn't exist: %s\n", argv[i + 1]);
        return 1;
      }
      i++;
    } else if (!end_opts && (!strcmp(a, "-C") || !strcmp(a, "--extra-config") || !strcmp(a, "--on-load"))) {
      if (i + 1 >= argc) {
        fprintf(stderr, "error: The argument '%s <VALUE>' requires a value but none was supplied\n", a);
        return 1;
      }
      i++;
    } else if (!end_opts && a[0] == '-') {
      fprintf(stderr, "error: invalid argument: \"%s\", try `-- \"%s\"` or `--help`\n", a, a);
      return 1;
    } else if (!path) {
      path = a;
    }
  }
  if (read_stdin) {
    int c;
    struct Str line = {0};
    while ((c = getchar()) != EOF) {
      if (c == '\n' || c == '\0') {
        if (line.n && !path_exists(line.p)) {
          char cwd[4096];
          if (getcwd(cwd, sizeof(cwd))) fprintf(stderr, "error: path doesn't exist: %s/%s\n", cwd, line.p);
          else fprintf(stderr, "error: path doesn't exist: %s\n", line.p);
          free(line.p);
          return 1;
        }
        line.n = 0;
        if (line.p) line.p[0] = 0;
      } else addch(&line, (char)c);
    }
    free(line.p);
  }
  if (path && !path_exists(path)) {
    if (path[0] == '/') fprintf(stderr, "error: path doesn't exist: %s\n", path);
    else {
      char cwd[4096];
      if (getcwd(cwd, sizeof(cwd))) fprintf(stderr, "error: path doesn't exist: %s/%s\n", cwd, path);
      else fprintf(stderr, "error: path doesn't exist: %s\n", path);
    }
    return 1;
  }
  fputs("error: No such device or address (os error 6)\n", stderr);
  return 1;
}
