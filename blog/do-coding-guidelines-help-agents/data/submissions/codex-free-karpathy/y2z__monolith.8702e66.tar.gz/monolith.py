#!/usr/bin/env python3
import argparse
import base64
import mimetypes
import os
import re
import sys
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse, unquote
from urllib.request import Request, urlopen

VERSION = "2.11.0"
BANNER = r""" _____    _____________   __________     ___________________    ___
|     \  /             \ |          |   |                   |  |   |
|      \/       __      \|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \__/ |          |\                    |   |   |   |   |  |   |
|___|      |__________| \___________________|   |___|   |___|  |___|"""
HELP = BANNER + """

monolith 2.11.0

CLI tool and library for saving web pages as a single HTML file

Usage: executable [OPTIONS] <TARGET>

Arguments:
  <TARGET>  URL or file path, use - for STDIN

Options:
  -a, --no-audio                      Remove audio sources
  -b, --base-url <http://localhost/>  Set custom base URL
  -B, --blacklist-domains             Treat specified domains as blacklist
  -c, --no-css                        Remove CSS
  -C, --cookie-file <cookies.txt>     Specify cookie file
  -d, --domain <example.com>          Specify domains to use for white/black-listing
  -e, --ignore-errors                 Ignore network errors
  -E, --encoding <UTF-8>              Enforce custom charset
  -f, --no-frames                     Remove frames and iframes
  -F, --no-fonts                      Remove fonts
  -i, --no-images                     Remove images
  -I, --isolate                       Cut off document from the Internet
  -j, --no-js                         Remove JavaScript
  -k, --insecure                      Allow invalid X.509 (TLS) certificates
  -m, --mhtml                         Use MHTML as output format
  -M, --no-metadata                   Exclude timestamp and source information
  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents
  -o, --output <result.html>          File to write to, use - for STDOUT
  -q, --quiet                         Suppress verbosity
  -t, --timeout <60>                  Adjust network request timeout
  -u, --user-agent <Firefox>          Set custom User-Agent string
  -v, --no-video                      Remove video sources
  -h, --help                          Print help
  -V, --version                       Print version"""
TRANSPARENT_PNG = "data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0D%00%00%00%0D%08%04%00%00%00%D8%E2%2C%F7%00%00%00%11IDATx%DAcd%C0%09%18G%A5%28%96%02%00%0A%F8%00%0E%CB%8A%EB%16%00%00%00%00IEND%AEB%60%82"


class OptParser(argparse.ArgumentParser):
    def error(self, message):
        if message.startswith("the following arguments are required"):
            sys.stderr.write(
                "error: the following required arguments were not provided:\n"
                "  <TARGET>\n\nUsage: executable <TARGET>\n\n"
                "For more information, try '--help'.\n"
            )
        else:
            sys.stderr.write(
                f"error: {message}\n\nUsage: executable [OPTIONS] <TARGET>\n\n"
                "For more information, try '--help'.\n"
            )
        raise SystemExit(2)


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print(HELP)
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print(f"monolith {VERSION}")
        raise SystemExit(0)

    p = OptParser(add_help=False, prog="executable", allow_abbrev=False)
    flags = [
        ("-a", "--no-audio", "no_audio"),
        ("-B", "--blacklist-domains", "blacklist"),
        ("-c", "--no-css", "no_css"),
        ("-e", "--ignore-errors", "ignore_errors"),
        ("-f", "--no-frames", "no_frames"),
        ("-F", "--no-fonts", "no_fonts"),
        ("-i", "--no-images", "no_images"),
        ("-I", "--isolate", "isolate"),
        ("-j", "--no-js", "no_js"),
        ("-k", "--insecure", "insecure"),
        ("-m", "--mhtml", "mhtml"),
        ("-M", "--no-metadata", "no_metadata"),
        ("-n", "--unwrap-noscript", "unwrap_noscript"),
        ("-q", "--quiet", "quiet"),
        ("-v", "--no-video", "no_video"),
    ]
    for short, long, dest in flags:
        p.add_argument(short, long, action="store_true", dest=dest)
    p.add_argument("-b", "--base-url", dest="base_url")
    p.add_argument("-C", "--cookie-file", dest="cookie_file")
    p.add_argument("-d", "--domain", action="append", default=[])
    p.add_argument("-E", "--encoding", dest="encoding")
    p.add_argument("-o", "--output", dest="output")
    p.add_argument("-t", "--timeout", type=float, default=60)
    p.add_argument("-u", "--user-agent", dest="user_agent", default="Mozilla/5.0")
    p.add_argument("target")
    return p.parse_args(argv)


def log(opts, msg):
    if not opts.quiet:
        print(msg, file=sys.stderr)


def mime_for(url, default="text/plain"):
    path = urlparse(url).path if "://" in url else url
    mt = mimetypes.guess_type(path)[0]
    lower = path.lower()
    if lower.endswith((".html", ".htm")):
        mt = "text/html"
    if lower.endswith(".css"):
        mt = "text/css"
    if lower.endswith(".js"):
        mt = "text/javascript"
    return mt or default


def to_file_url(path):
    return "file://" + os.path.abspath(path)


def read_url(url, opts, binary=True):
    parsed = urlparse(url)
    try:
        if parsed.scheme in ("", "file"):
            path = unquote(parsed.path if parsed.scheme == "file" else url)
            if not os.path.isabs(path):
                path = os.path.abspath(path)
            log(opts, "file://" + path)
            mode = "rb" if binary else "r"
            kwargs = {} if binary else {"encoding": opts.encoding or "utf-8", "errors": "replace"}
            with open(path, mode, **kwargs) as f:
                return f.read()
        req = Request(url, headers={"User-Agent": opts.user_agent})
        log(opts, url)
        with urlopen(req, timeout=opts.timeout) as r:
            return r.read() if binary else r.read().decode(opts.encoding or "utf-8", "replace")
    except Exception as e:
        log(opts, f"{url} ({e})")
        return b"" if binary else ""


def resolve(base, ref):
    if not ref or ref.startswith(("data:", "mailto:", "javascript:", "#")):
        return None
    return urljoin(base, ref) if base else ref


def local_missing(url):
    if not url:
        return False
    parsed = urlparse(url)
    if parsed.scheme not in ("", "file"):
        return False
    path = unquote(parsed.path if parsed.scheme == "file" else url)
    if not os.path.isabs(path):
        path = os.path.abspath(path)
    return not os.path.exists(path)


def data_uri(url, opts, default="text/plain", transform_css=False):
    if not url:
        return ""
    data = read_url(url, opts, True)
    mt = mime_for(url, default)
    if transform_css:
        text = data.decode(opts.encoding or "utf-8", "replace")
        text = embed_css_urls(text, url, opts)
        data = text.encode("utf-8")
        mt = "text/css"
    return f"data:{mt};base64," + base64.b64encode(data).decode("ascii")


def embed_css_urls(css, base, opts):
    def repl(m):
        ref = m.group(2).strip()
        if ref.startswith(("data:", "#")):
            return m.group(0)
        u = resolve(base, ref)
        if not u:
            return m.group(0)
        mt = mime_for(u)
        if opts.no_fonts and ("font" in mt or re.search(r"\.(woff2?|ttf|otf|eot)$", u, re.I)):
            return 'url("")'
        if opts.no_images and mt.startswith("image"):
            return f'url("{TRANSPARENT_PNG}")'
        return f'url("{data_uri(u, opts)}")'

    return re.sub(r"""url\(\s*(["']?)(.*?)\1\s*\)""", repl, css, flags=re.I)


def parse_attrs(s):
    attrs = []
    for m in re.finditer(r"""([:\w-]+)(?:\s*=\s*("[^"]*"|'[^']*'|[^\s"'>/]+))?""", s):
        name = m.group(1).lower()
        val = m.group(2)
        if val is None:
            attrs.append((name, None))
        else:
            attrs.append((name, val[1:-1] if val[:1] in ('"', "'") else val))
    return attrs


def attrs_to_str(attrs):
    out = []
    for k, v in attrs:
        if v is None:
            out.append(k)
        else:
            escaped = str(v).replace("&", "&amp;").replace('"', "&quot;")
            out.append(f'{k}="{escaped}"')
    return (" " + " ".join(out)) if out else ""


def set_attr(attrs, name, val):
    name = name.lower()
    done = False
    res = []
    for k, v in attrs:
        if k.lower() == name:
            if val is not None:
                res.append((k, val))
            done = True
        else:
            res.append((k, v))
    if not done and val is not None:
        res.append((name, val))
    return res


def get_attr(attrs, name):
    for k, v in attrs:
        if k.lower() == name:
            return v or ""
    return None


def has_rel_stylesheet(attrs):
    rel = get_attr(attrs, "rel") or ""
    return "stylesheet" in rel.lower()


def csp_content(opts):
    if opts.isolate:
        return "default-src 'unsafe-eval' 'unsafe-inline' data:;"
    parts = []
    if opts.no_css:
        parts.append("style-src 'none';")
    if opts.no_fonts:
        parts.append("font-src 'none';")
    if opts.no_frames:
        parts.extend(["frame-src 'none';", "child-src 'none';"])
    if opts.no_js or opts.mhtml:
        parts.append("script-src 'none';")
    if opts.no_images:
        parts.append("img-src data:;")
    return " ".join(parts)


def insert_head_meta(html, opts):
    head_start = []
    head_end = []
    csp = csp_content(opts)
    if csp:
        head_start.append(f'<meta http-equiv="Content-Security-Policy" content="{csp}"></meta>')
    if opts.base_url:
        head_end.append(f'<base href="{opts.base_url}"></base>')
    head_end.append('<meta name="robots" content="none"></meta>')
    m = re.search(r"<head\b[^>]*>", html, flags=re.I)
    if m:
        html = html[: m.end()] + "".join(head_start) + html[m.end() :]
        end = re.search(r"</head\s*>", html, flags=re.I)
        if end:
            return html[: end.start()] + "".join(head_end) + html[end.start() :]
        return html + "".join(head_end)
    m = re.search(r"<html\b[^>]*>", html, flags=re.I)
    if m:
        return html[: m.end()] + "<head>" + "".join(head_start + head_end) + "</head>" + html[m.end() :]
    return "".join(head_start + head_end) + html


def transform(html, base, opts):
    def link_repl(m):
        attrs = parse_attrs(m.group(1))
        href = get_attr(attrs, "href")
        if has_rel_stylesheet(attrs):
            if opts.no_css:
                attrs = set_attr(attrs, "href", None)
            elif href:
                attrs = set_attr(attrs, "href", data_uri(resolve(base, href), opts, "text/css", True))
        return "<link" + attrs_to_str(attrs) + ">"

    html = re.sub(r"<link\b([^>]*)>", link_repl, html, flags=re.I)

    def style_repl(m):
        attrs, body = m.group(1), m.group(2)
        body = "" if opts.no_css else embed_css_urls(body, base, opts)
        return "<style" + attrs + ">" + body + "</style>"

    html = re.sub(r"<style\b([^>]*)>(.*?)</style>", style_repl, html, flags=re.I | re.S)

    def script_repl(m):
        attrs = parse_attrs(m.group(1))
        body = m.group(2)
        src = get_attr(attrs, "src")
        if opts.no_js or opts.mhtml:
            attrs = set_attr(attrs, "src", None)
            body = ""
        elif src:
            body = read_url(resolve(base, src), opts, False)
            attrs = set_attr(attrs, "src", None)
        return "<script" + attrs_to_str(attrs) + ">" + body + "</script>"

    html = re.sub(r"<script\b([^>]*)>(.*?)</script>", script_repl, html, flags=re.I | re.S)

    def tag_repl(m):
        tag = m.group(1).lower()
        attrs = parse_attrs(m.group(2))
        end = "/" if m.group(3) else ""

        def embed_attr(name, default="text/plain"):
            nonlocal attrs
            val = get_attr(attrs, name)
            if val:
                attrs = set_attr(attrs, name, data_uri(resolve(base, val), opts, default))

        if tag == "img":
            if opts.no_images:
                attrs = set_attr(attrs, "src", TRANSPARENT_PNG)
            else:
                embed_attr("src", "image/png")
        elif tag in ("audio", "source"):
            if opts.no_audio:
                attrs = set_attr(attrs, "src", None)
            else:
                val = get_attr(attrs, "src")
                if local_missing(resolve(base, val)):
                    attrs = set_attr(attrs, "src", None)
                else:
                    embed_attr("src")
        elif tag == "video":
            if opts.no_video:
                attrs = set_attr(attrs, "src", None)
                attrs = set_attr(attrs, "poster", None)
            else:
                val = get_attr(attrs, "src")
                if local_missing(resolve(base, val)):
                    attrs = set_attr(attrs, "src", None)
                else:
                    embed_attr("src")
                embed_attr("poster", "image/png")
        elif tag in ("iframe", "frame"):
            if opts.no_frames:
                attrs = set_attr(attrs, "src", "")
            else:
                val = get_attr(attrs, "src")
                if val:
                    u = resolve(base, val)
                    data = read_url(u, opts, True)
                    text = data.decode(opts.encoding or "utf-8", "replace")
                    if not re.search(r"<html\b", text, flags=re.I):
                        text = f"<html><head></head><body>{text}</body></html>"
                    uri = "data:text/html;base64," + base64.b64encode(text.encode("utf-8")).decode("ascii")
                    attrs = set_attr(attrs, "src", uri)
        return "<" + tag + attrs_to_str(attrs) + end + ">"

    html = re.sub(r"<(img|audio|video|source|iframe|frame)\b([^>]*?)(/?)>", tag_repl, html, flags=re.I)
    if opts.unwrap_noscript:
        html = re.sub(r"<noscript\b[^>]*>(.*?)</noscript>", r"<!--noscript-->\1<!--/noscript-->", html, flags=re.I | re.S)
    return insert_head_meta(html, opts)


def read_target(opts):
    if opts.target == "-":
        data = sys.stdin.buffer.read()
        return data.decode(opts.encoding or "utf-8", "replace"), opts.base_url or "", "standard input"
    parsed = urlparse(opts.target)
    if parsed.scheme in ("http", "https", "file"):
        url = opts.target
        return read_url(url, opts, False), opts.base_url or url, url
    return read_url(opts.target, opts, False), opts.base_url or to_file_url(opts.target), "local source"


def apply_output_template(path, html):
    if not path or path == "-":
        return path
    title = ""
    m = re.search(r"<title[^>]*>(.*?)</title>", html, flags=re.I | re.S)
    if m:
        title = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", m.group(1))).strip()
    ts = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")
    safe = re.sub(r"[^A-Za-z0-9._ -]+", "_", title) or "untitled"
    return path.replace("%title%", safe).replace("%timestamp%", ts)


def wrap_mhtml(html):
    return (
        'MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary="----=_NextPart_000_0000"\r\n\r\n'
        "------=_NextPart_000_0000\r\nContent-Type: text/html; charset=\"utf-8\"\r\n"
        "Content-Location: http://example.com/\r\n\r\n"
        + html
        + "\r\n------=_NextPart_000_0000--\r\n"
    )


def main(argv):
    opts = parse_args(argv)
    html, base, source_label = read_target(opts)
    out = transform(html, base, opts)
    if not opts.no_metadata and not opts.mhtml:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        out = f"<!-- Saved from {source_label} at {now} using monolith v{VERSION} -->\n" + out
    if opts.mhtml:
        out = wrap_mhtml(out)
    outpath = apply_output_template(opts.output, out)
    if outpath and outpath != "-":
        with open(outpath, "w", encoding=opts.encoding or "utf-8", newline="") as f:
            f.write(out)
    else:
        sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
