#!/usr/bin/env python3
import fnmatch
import fcntl
import os
import re
import select
import stat
import sys
import time


VERSION = """ag version 2.2.0

Features:
  +jit +lzma +zlib
"""

HELP = """
Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
     --[no]color          Print color codes in results (Enabled by default)
     --column             Print column numbers in results
     --[no]filename       Print file names (Enabled unless searching a single file)
  -H --[no]heading        Print file names before each file's matches
                          (Enabled by default)
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -l --files-with-matches Only print filenames that contain matches
  -L --files-without-matches
                          Only print filenames that don't contain matches
     --[no]numbers        Print line numbers.
  -o --only-matching      Prints only the matching part of the lines
     --passthrough        When searching a stream, print all lines even if they
                          don't match
     --silent             Suppress all log messages, including errors
     --stats              Print stats (files scanned, time taken, etc.)
     --stats-only         Print stats and nothing else.
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files
  -D --debug              Ridiculous debugging (probably not useful)
     --depth NUM          Search up to NUM directories deep (Default: 25)
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files (obeys .*ignore files)
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
  -m --max-count NUM      Skip the rest of a file after NUM matches
  -n --norecurse          Don't recurse into directories
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
     --search-binary      Search binary files for matches
  -t --all-text           Search all text files
  -u --unrestricted       Search all files
  -U --skip-vcs-ignores   Ignore VCS ignore files
  -v --invert-match
  -w --word-regexp        Only match whole words
  -W --width NUM          Truncate match lines after NUM characters
  -z --search-zip         Search contents of compressed files

File Types:
The search can be restricted to certain types of files. Example:
  ag --html needle

For a list of supported file types run:
  ag --list-file-types

ag was originally created by Geoff Greer. More information (and the latest release)
can be found at http://geoff.greer.fm/ag
"""

FILE_TYPES = {
    "actionscript": ["as", "mxml"],
    "ada": ["ada", "adb", "ads"],
    "asciidoc": ["adoc", "ad", "asc", "asciidoc"],
    "asm": ["asm", "s"],
    "asp": ["asp", "asa", "aspx", "asax", "ashx", "ascx", "asmx"],
    "aspx": ["asp", "asa", "aspx", "asax", "ashx", "ascx", "asmx"],
    "batch": ["bat", "cmd"],
    "bazel": ["bazel"],
    "cc": ["c", "h", "xs"],
    "clojure": ["clj", "cljs", "cljc", "edn"],
    "coffee": ["coffee", "cjsx"],
    "config": ["config"],
    "cpp": ["cpp", "cc", "C", "cxx", "m", "hpp", "hh", "h", "H", "hxx", "tpp"],
    "csharp": ["cs"],
    "css": ["css"],
    "elisp": ["el"],
    "erlang": ["erl", "hrl"],
    "go": ["go"],
    "haskell": ["hs", "lhs"],
    "html": ["htm", "html", "shtml", "xhtml"],
    "java": ["java", "properties"],
    "js": ["js", "jsx", "vue"],
    "json": ["json"],
    "less": ["less"],
    "lua": ["lua"],
    "make": ["Makefile", "mk", "mak"],
    "markdown": ["md", "markdown", "mkd"],
    "objc": ["m", "h"],
    "objcpp": ["mm", "h"],
    "perl": ["pl", "pm", "pod", "t"],
    "php": ["php", "phpt", "php3", "php4", "php5", "phtml"],
    "python": ["py"],
    "r": ["R", "r"],
    "ruby": ["rb", "rhtml", "rjs", "rxml", "erb", "rake", "gemspec"],
    "rust": ["rs"],
    "scala": ["scala", "sbt"],
    "shell": ["sh", "bash", "csh", "tcsh", "ksh", "zsh", "fish"],
    "sql": ["sql"],
    "swift": ["swift"],
    "ts": ["ts", "tsx"],
    "txt": ["txt"],
    "vim": ["vim"],
    "xml": ["xml", "dtd", "xsl", "xslt", "ent"],
    "yaml": ["yaml", "yml"],
}


class Options:
    def __init__(self):
        self.after = 0
        self.before = 0
        self.count = False
        self.column = False
        self.filename = None
        self.heading = False
        self.breaks = True
        self.file_name_pattern = None
        self.filename_only = False
        self.file_search_regex = None
        self.files_with_matches = False
        self.files_without_matches = False
        self.only_matching = False
        self.numbers = True
        self.passthrough = False
        self.stats = False
        self.stats_only = False
        self.vimgrep = False
        self.null = False
        self.all_types = False
        self.depth = 25
        self.follow = False
        self.hidden = False
        self.ignore_case = None
        self.ignore_patterns = []
        self.max_count = 10000
        self.recurse = True
        self.literal = False
        self.smart_case = True
        self.search_binary = False
        self.unrestricted = False
        self.skip_vcs_ignores = False
        self.invert = False
        self.word = False
        self.width = None
        self.silent = False
        self.type_filters = []
        self.paths = []
        self.pattern = None
        self.stdin_data = None


def eprint(opts, msg):
    if not opts.silent:
        print(msg, file=sys.stderr)


def parse_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def parse_args(argv):
    opts = Options()
    positional = []
    i = 0
    stop_opts = False
    while i < len(argv):
        arg = argv[i]
        if stop_opts:
            positional.append(arg)
            i += 1
            continue
        if arg == "--":
            stop_opts = True
            i += 1
            continue
        if arg in ("--help", "-h"):
            print(HELP)
            sys.exit(0)
        if arg in ("--version", "-V"):
            print(VERSION)
            sys.exit(0)
        if arg == "--list-file-types":
            print("The following file types are supported:")
            for name in sorted(FILE_TYPES):
                print(f"  --{name}")
                print("      " + "  ".join("." + x for x in FILE_TYPES[name]))
                print()
            sys.exit(0)
        if arg.startswith("--") and arg[2:] in FILE_TYPES:
            opts.type_filters.append(arg[2:])
            i += 1
            continue
        if not arg.startswith("-") or arg == "-":
            positional.append(arg)
            i += 1
            continue
        if len(arg) > 2 and arg[:2] in ("-A", "-B", "-C", "-m", "-W", "-G", "-g"):
            opt = arg[:2]
            val = arg[2:]
            if opt == "-A":
                opts.after = parse_int(val, 2)
            elif opt == "-B":
                opts.before = parse_int(val, 2)
            elif opt == "-C":
                opts.after = opts.before = parse_int(val, 2)
            elif opt == "-m":
                opts.max_count = parse_int(val, opts.max_count)
            elif opt == "-W":
                opts.width = parse_int(val, 0)
            elif opt == "-G":
                opts.file_search_regex = val
            elif opt == "-g":
                opts.file_name_pattern = val
            i += 1
            continue
        if arg in ("--ackmate", "--parallel", "--pager", "--nopager", "--mmap", "--nommap",
                   "--multiline", "--nomultiline", "--affinity", "--noaffinity",
                   "--one-device", "--print-long-lines", "--search-zip", "-z", "-D",
                   "--debug", "--workers"):
            if arg in ("--pager", "--workers") and i + 1 < len(argv):
                i += 2
            else:
                i += 1
            continue
        if arg in ("-A", "--after", "-B", "--before", "-C", "--context"):
            val = 2
            if i + 1 < len(argv) and re.fullmatch(r"-?\d+", argv[i + 1]):
                val = int(argv[i + 1])
                i += 1
            if arg in ("-A", "--after"):
                opts.after = val
            elif arg in ("-B", "--before"):
                opts.before = val
            else:
                opts.after = opts.before = val
            i += 1
            continue
        takes_value = {
            "-G": "file_search_regex", "--file-search-regex": "file_search_regex",
            "-g": "file_name_pattern", "--filename-pattern": "file_name_pattern",
            "--ignore": "ignore", "--ignore-dir": "ignore", "-m": "max_count",
            "--max-count": "max_count", "--depth": "depth", "-W": "width",
            "--width": "width", "-p": "path_ignore", "--path-to-ignore": "path_ignore",
            "--color-line-number": "dummy", "--color-match": "dummy", "--color-path": "dummy",
        }
        if arg in takes_value:
            if i + 1 >= len(argv):
                print(f"ERR: option requires an argument: {arg}", file=sys.stderr)
                sys.exit(2)
            val = argv[i + 1]
            key = takes_value[arg]
            if key == "ignore":
                opts.ignore_patterns.append(val)
            elif key == "max_count":
                opts.max_count = parse_int(val, opts.max_count)
            elif key == "depth":
                opts.depth = parse_int(val, opts.depth)
            elif key == "width":
                opts.width = parse_int(val, 0)
            elif key != "dummy" and key != "path_ignore":
                setattr(opts, key, val)
            elif key == "path_ignore":
                opts.ignore_patterns.extend(read_ignore_file(val))
            i += 2
            continue
        long_flags = {
            "--break": ("breaks", True), "--nobreak": ("breaks", False),
            "--color": ("color", True), "--nocolor": ("color", False),
            "--filename": ("filename", True), "--nofilename": ("filename", False),
            "--heading": ("heading", True), "--noheading": ("heading", False),
            "--group": ("group", True), "--nogroup": ("group", False),
            "--numbers": ("numbers", True), "--nonumbers": ("numbers", False),
            "--all-types": ("all_types", True), "--follow": ("follow", True),
            "--nofollow": ("follow", False), "--hidden": ("hidden", True),
            "--ignore-case": ("ignore_case", True), "--case-sensitive": ("ignore_case", False),
            "--fixed-strings": ("literal", True), "--literal": ("literal", True),
            "--smart-case": ("smart_case", True), "--search-binary": ("search_binary", True),
            "--silent": ("silent", True), "--stats": ("stats", True),
            "--stats-only": ("stats_only", True), "--all-text": ("all_text", True),
            "--unrestricted": ("unrestricted", True), "--skip-vcs-ignores": ("skip_vcs_ignores", True),
            "--invert-match": ("invert", True), "--word-regexp": ("word", True),
            "--passthrough": ("passthrough", True), "--passthru": ("passthrough", True),
            "--only-matching": ("only_matching", True), "--column": ("column", True),
            "--vimgrep": ("vimgrep", True), "--files-with-matches": ("files_with_matches", True),
            "--files-without-matches": ("files_without_matches", True),
            "--null": ("null", True), "--print0": ("null", True),
        }
        if arg in long_flags:
            key, val = long_flags[arg]
            if key == "group":
                opts.heading = val
                opts.breaks = val
            elif key == "all_text":
                opts.search_binary = False
                opts.all_types = True
            else:
                setattr(opts, key, val)
            i += 1
            continue
        if arg.startswith("-") and len(arg) > 1:
            handled = True
            for ch in arg[1:]:
                if ch == "a":
                    opts.all_types = True
                elif ch == "c":
                    opts.count = True
                elif ch == "f":
                    opts.follow = True
                elif ch == "F" or ch == "Q":
                    opts.literal = True
                elif ch == "H":
                    opts.heading = True
                elif ch == "i":
                    opts.ignore_case = True
                elif ch == "l":
                    opts.files_with_matches = True
                elif ch == "L":
                    opts.files_without_matches = True
                elif ch == "n":
                    opts.recurse = False
                elif ch == "o":
                    opts.only_matching = True
                elif ch == "r":
                    opts.recurse = True
                elif ch == "s":
                    opts.ignore_case = False
                elif ch == "S":
                    opts.smart_case = True
                elif ch == "t":
                    opts.all_types = True
                elif ch == "u":
                    opts.unrestricted = True
                    opts.hidden = True
                    opts.search_binary = True
                    opts.all_types = True
                elif ch == "U":
                    opts.skip_vcs_ignores = True
                elif ch == "v":
                    opts.invert = True
                elif ch == "w":
                    opts.word = True
                elif ch == "0":
                    opts.null = True
                else:
                    handled = False
                    break
            if handled:
                i += 1
                continue
        positional.append(arg)
        i += 1
    if opts.stats_only:
        opts.stats = True
    if opts.file_name_pattern is not None:
        opts.filename_only = True
        opts.paths = positional or []
        opts.pattern = opts.file_name_pattern
        return opts
    if not positional:
        print(HELP, file=sys.stderr)
        sys.exit(1)
    opts.pattern = positional[0]
    opts.paths = positional[1:] or []
    return opts


def read_ignore_file(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [x.strip() for x in f if x.strip() and not x.lstrip().startswith("#")]
    except OSError:
        return []


def is_hidden_path(path):
    return any(part.startswith(".") and part not in (".", "..") for part in path.split(os.sep))


def match_ignore(rel, base, patterns):
    name = os.path.basename(rel)
    for pat in patterns:
        pat = pat.strip()
        if not pat or pat.startswith("#"):
            continue
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        pat = pat.rstrip("/")
        matched = fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel, pat) or name == pat or rel == pat
        if matched:
            return not neg
    return False


def discover(paths, opts):
    if not paths:
        paths = ["."]
    files = []
    for start in paths:
        if start == "-":
            files.append("-")
            continue
        if not os.path.exists(start):
            eprint(opts, f"ERR: Error stat()ing: {start}")
            eprint(opts, f"ERR: Error opening directory {start}: No such file or directory")
            continue
        if os.path.isfile(start):
            files.append(start[2:] if start.startswith("./") else start)
            continue
        if not os.path.isdir(start):
            continue
        root_abs = os.path.abspath(start)
        base_ignores = [] if opts.unrestricted else opts.ignore_patterns[:]
        for root, dirs, names in os.walk(start, followlinks=opts.follow):
            rel_dir = os.path.relpath(root, start)
            depth = 0 if rel_dir == "." else rel_dir.count(os.sep) + 1
            if opts.depth >= 0 and depth >= opts.depth:
                dirs[:] = []
            ignores = base_ignores[:]
            if not opts.unrestricted:
                ignores.extend(read_ignore_file(os.path.join(root, ".ignore")))
                if not opts.skip_vcs_ignores:
                    ignores.extend(read_ignore_file(os.path.join(root, ".gitignore")))
                    ignores.extend(read_ignore_file(os.path.join(root, ".hgignore")))
            new_dirs = []
            for d in sorted(dirs):
                p = os.path.join(root, d)
                rel = os.path.relpath(p, start)
                if (not opts.hidden and is_hidden_path(rel)) or (not opts.unrestricted and match_ignore(rel, root_abs, ignores)):
                    continue
                new_dirs.append(d)
            dirs[:] = new_dirs if opts.recurse else []
            for name in sorted(names):
                p = os.path.join(root, name)
                rel = os.path.relpath(p, start)
                if not opts.hidden and is_hidden_path(rel):
                    continue
                if not opts.unrestricted and match_ignore(rel, root_abs, ignores):
                    continue
                if start == "." and p.startswith("./"):
                    p = p[2:]
                files.append(p)
    return files


def file_type_ok(path, opts):
    if not opts.type_filters:
        return True
    base = os.path.basename(path)
    ext = base.rsplit(".", 1)[1] if "." in base else base
    for t in opts.type_filters:
        for e in FILE_TYPES.get(t, []):
            if e == base or e == ext:
                return True
    return False


def filename_filters_ok(path, opts):
    if opts.file_name_pattern:
        try:
            if not re.search(opts.file_name_pattern, path):
                return False
        except re.error:
            if opts.file_name_pattern not in path:
                return False
    if opts.file_search_regex:
        try:
            if not re.search(opts.file_search_regex, path):
                return False
        except re.error:
            if opts.file_search_regex not in path:
                return False
    return file_type_ok(path, opts)


def compile_pattern(opts):
    pat = re.escape(opts.pattern) if opts.literal else opts.pattern
    if opts.word:
        pat = r"\b(?:" + pat + r")\b"
    flags = re.MULTILINE
    if opts.ignore_case is True:
        flags |= re.IGNORECASE
    elif opts.ignore_case is None and opts.smart_case and not any(c.isupper() for c in opts.pattern):
        flags |= re.IGNORECASE
    try:
        return re.compile(pat, flags)
    except re.error as ex:
        print(f"ERR: Bad regex! {ex}", file=sys.stderr)
        sys.exit(1)


def read_file(path, opts):
    if path == "-":
        data = opts.stdin_data if opts.stdin_data is not None else sys.stdin.buffer.read()
    else:
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError as ex:
            eprint(opts, f"ERR: Error opening file {path}: {ex.strerror}")
            return None
    if not opts.search_binary and b"\0" in data[:4096]:
        return None
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="replace")


def split_lines(text):
    return [line.rstrip("\n").rstrip("\r") for line in text.splitlines(True)]


def find_matches(text, regex, opts):
    lines = text.splitlines(True)
    if text and (not lines or not lines[-1].endswith(("\n", "\r"))):
        pass
    results = []
    for idx, line in enumerate(lines or ([] if text else []), 1):
        body = line.rstrip("\n").rstrip("\r")
        matches = list(regex.finditer(body))
        line_matches = bool(matches)
        if opts.invert:
            if not line_matches:
                results.append((idx, body, []))
        elif line_matches:
            results.append((idx, body, matches))
    if opts.pattern == "" and not opts.invert:
        results = [(idx, line.rstrip("\n").rstrip("\r"), [re.match("", "")]) for idx, line in enumerate(lines, 1)]
    return results, len(lines)


def match_count(results, opts):
    if opts.invert:
        return len(results)
    total = 0
    for _, _, matches in results:
        total += max(1, len(matches))
    return total


def sep(opts):
    return "\0" if opts.null else "\n"


def print_name(path, opts):
    end = "\0" if opts.null else "\n"
    sys.stdout.write(path + end)


def format_prefix(path, line_no, col, opts, show_filename, delim=":"):
    parts = []
    if show_filename:
        parts.append(path)
    if opts.numbers:
        parts.append(str(line_no))
    if opts.column or opts.vimgrep:
        parts.append(str(col))
    if parts:
        return ":".join(parts) + delim
    return ""


def col_of(match):
    if match is None:
        return 1
    return match.start() + 1


def truncate(s, opts):
    if opts.width and opts.width > 0 and len(s) > opts.width:
        return s[:opts.width]
    return s


def output_matches(path, results, line_texts, opts, show_filename):
    line_count = len(line_texts)
    if opts.count:
        c = match_count(results, opts)
        if c:
            prefix = f"{path}:" if show_filename else ""
            print(f"{prefix}{c}")
        return c
    if opts.files_with_matches:
        if results or opts.pattern == "":
            print_name(path, opts)
            return 1
        return 0
    if opts.files_without_matches:
        if not results:
            print_name(path, opts)
            return 1
        return 0
    if opts.heading and show_filename and results and not opts.only_matching:
        print(path)
        show_filename = False
    printed = 0
    result_by_line = {ln: (text, matches) for ln, text, matches in results}
    selected = set(result_by_line)
    if (opts.before or opts.after) and results:
        for ln, _, _ in results:
            for n in range(max(1, ln - opts.before), min(line_count, ln + opts.after) + 1):
                selected.add(n)
    if opts.only_matching and not opts.invert:
        for ln, text, matches in results:
            for m in matches:
                out = m.group(0)
                prefix = format_prefix(path, ln, col_of(m), opts, show_filename)
                print(prefix + truncate(out, opts))
                printed += 1
        return printed
    if selected != set(result_by_line):
        for ln in sorted(selected):
            text, matches = result_by_line.get((ln), (line_texts[ln - 1], []))
            is_match = ln in result_by_line
            m = matches[0] if matches else None
            delim = ":" if is_match else "-"
            print(format_prefix(path, ln, col_of(m), opts, show_filename, delim) + truncate(text, opts))
            printed += 1
    else:
        for ln, text, matches in results:
            if opts.vimgrep and not opts.invert:
                for m in matches:
                    print(format_prefix(path, ln, col_of(m), opts, show_filename) + truncate(text, opts))
                    printed += 1
            else:
                m = matches[0] if matches else None
                print(format_prefix(path, ln, col_of(m), opts, show_filename) + truncate(text, opts))
                printed += 1
    return printed


def search_stream(path, text, regex, opts, show_filename):
    results, line_count = find_matches(text, regex, opts)
    if opts.max_count and opts.max_count > 0 and match_count(results, opts) > opts.max_count:
        eprint(opts, f"ERR: Too many matches in {path}. Skipping the rest of this file.")
        limited = []
        total = 0
        for r in results:
            n = max(1, len(r[2]))
            limited.append(r)
            total += n
            if total >= opts.max_count:
                break
        results = limited
    return results, line_count


def main(argv):
    start = time.time()
    opts = parse_args(argv)
    if opts.unrestricted:
        opts.hidden = True
        opts.search_binary = True
    stdin_mode = False
    if not opts.paths:
        try:
            r, _, _ = select.select([sys.stdin.buffer], [], [], 0)
            if r:
                fd = sys.stdin.fileno()
                old = fcntl.fcntl(fd, fcntl.F_GETFL)
                fcntl.fcntl(fd, fcntl.F_SETFL, old | os.O_NONBLOCK)
                chunks = []
                try:
                    while True:
                        try:
                            chunk = os.read(fd, 65536)
                        except BlockingIOError:
                            break
                        if not chunk:
                            break
                        chunks.append(chunk)
                finally:
                    fcntl.fcntl(fd, fcntl.F_SETFL, old)
                data = b"".join(chunks)
                if data:
                    opts.stdin_data = data
                    stdin_mode = True
        except Exception:
            stdin_mode = False
    files = ["-"] if stdin_mode else discover(opts.paths, opts)
    files = [f for f in files if f == "-" or filename_filters_ok(f, opts)]
    if opts.filename_only:
        for f in files:
            print_name(f, opts)
        return 0
    regex = compile_pattern(opts)
    explicit_paths = opts.paths
    single_file = len(explicit_paths) == 1 and explicit_paths[0] != "-" and os.path.isfile(explicit_paths[0])
    if stdin_mode:
        single_file = True
        if opts.filename is None:
            opts.filename = False
        if "--numbers" not in argv and opts.numbers:
            opts.numbers = False
    show_filename = opts.filename if opts.filename is not None else not single_file
    any_match = False
    searched = 0
    bytes_searched = 0
    files_with = 0
    first_heading = True
    for f in files:
        text = read_file(f, opts)
        if text is None:
            continue
        searched += 1
        bytes_searched += len(text.encode("utf-8", errors="ignore"))
        results, line_count = search_stream(f, text, regex, opts, show_filename)
        if results:
            any_match = True
            files_with += 1
        if opts.stats_only:
            continue
        if opts.heading and show_filename and results:
            if opts.breaks and not first_heading:
                print()
            first_heading = False
        output_matches(f, results, split_lines(text), opts, show_filename)
        if opts.passthrough and f == "-":
            for line in text.splitlines():
                print(line)
    if opts.stats:
        matches = 0
        for f in files:
            text = read_file(f, opts)
            if text is None:
                continue
            res, _ = find_matches(text, regex, opts)
            matches += match_count(res, opts)
        print(f"{matches} matches")
        print(f"{files_with} files contained matches")
        print(f"{searched} files searched")
        print(f"{bytes_searched} bytes searched")
        print(f"{time.time() - start:.6f} seconds")
    return 0 if any_match or (opts.files_without_matches and searched != files_with) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
