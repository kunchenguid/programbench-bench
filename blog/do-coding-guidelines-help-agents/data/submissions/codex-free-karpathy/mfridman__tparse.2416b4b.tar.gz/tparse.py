#!/usr/bin/env python3
import json
import os
import re
import sys


USAGE = """Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display."""


class Opts:
    def __init__(self):
        self.show_all = False
        self.show_pass = False
        self.show_skip = False
        self.notests = False
        self.smallscreen = False
        self.slow = 0
        self.sort = "name"
        self.nocolor = False
        self.format = "basic"
        self.file = None
        self.follow = False
        self.follow_output = None
        self.include_timestamp = False
        self.progress = False
        self.compare = None
        self.trimpath = None


def parse_args(argv):
    opts = Opts()
    i = 0
    while i < len(argv):
        arg = argv[i]
        key, eq, val = arg.partition("=")
        def need_value():
            nonlocal i, val
            if eq:
                return val
            i += 1
            if i >= len(argv):
                print(f"flag needs an argument: {arg}", file=sys.stderr)
                print(USAGE, file=sys.stderr)
                sys.exit(2)
            return argv[i]
        if arg in ("-h", "--help"):
            print(USAGE)
            sys.exit(0)
        elif arg == "-v":
            print("tparse version: (devel)")
            sys.exit(0)
        elif key == "-all":
            opts.show_all = True
        elif key == "-pass":
            opts.show_pass = True
        elif key == "-skip":
            opts.show_skip = True
        elif key == "-notests":
            opts.notests = True
        elif key == "-smallscreen":
            opts.smallscreen = True
        elif key == "-slow":
            try:
                opts.slow = int(need_value())
            except ValueError:
                opts.slow = 0
        elif key == "-sort":
            opts.sort = need_value()
        elif key == "-nocolor":
            opts.nocolor = True
        elif key == "-format":
            opts.format = need_value()
        elif key == "-file":
            opts.file = need_value()
        elif key == "-follow":
            opts.follow = True
        elif key == "-follow-output":
            opts.follow_output = need_value()
        elif key == "-include-timestamp":
            opts.include_timestamp = True
        elif key == "-progress":
            opts.progress = True
        elif key == "-compare":
            opts.compare = need_value()
        elif key == "-trimpath":
            opts.trimpath = need_value()
        else:
            print(f"flag provided but not defined: {arg}", file=sys.stderr)
            print(USAGE, file=sys.stderr)
            sys.exit(2)
        i += 1
    return opts


class Test:
    def __init__(self, pkg, name):
        self.pkg = pkg
        self.name = name
        self.status = ""
        self.elapsed = 0.0
        self.output = []


class Package:
    def __init__(self, name):
        self.name = name
        self.status = ""
        self.elapsed = 0.0
        self.output = []
        self.all_output = []
        self.tests = {}
        self.cover = "--"
        self.notest = False
        self.panic = False
        self.panic_test = ""


def trim_pkg(pkg, prefix):
    if prefix and pkg.startswith(prefix):
        return pkg[len(prefix):]
    return pkg


def status_text(action):
    if action == "pass":
        return "PASS"
    if action == "fail":
        return "FAIL"
    if action == "skip":
        return "SKIP"
    return action.upper()


def read_events(opts):
    if opts.file:
        data = open(opts.file, "r", encoding="utf-8", errors="replace").read().splitlines()
    else:
        data = sys.stdin.read().splitlines()
    follow_out = None
    if opts.follow_output:
        follow_out = open(opts.follow_output, "w", encoding="utf-8")
    packages = {}
    parsed = 0
    for line in data:
        if not line.strip():
            continue
        try:
            ev = json.loads(line)
        except Exception:
            continue
        if not isinstance(ev, dict) or "Action" not in ev or "Package" not in ev:
            continue
        parsed += 1
        pkg_name = ev.get("Package", "")
        pkg = packages.setdefault(pkg_name, Package(pkg_name))
        action = ev.get("Action", "")
        test_name = ev.get("Test", "")
        out = ev.get("Output", "")
        if test_name:
            test = pkg.tests.setdefault(test_name, Test(pkg_name, test_name))
            if action in ("pass", "fail", "skip"):
                test.status = status_text(action)
                test.elapsed = float(ev.get("Elapsed", 0) or 0)
            if action == "output":
                test.output.append(out)
                pkg.all_output.append(out)
                if "panic:" in out:
                    pkg.panic = True
                    pkg.panic_test = test_name
        else:
            if action in ("pass", "fail", "skip"):
                pkg.status = status_text(action)
                pkg.elapsed = float(ev.get("Elapsed", 0) or 0)
            if action == "output":
                pkg.output.append(out)
                pkg.all_output.append(out)
        if out:
            if opts.follow_output:
                follow_out.write(format_follow(ev, opts, out))
            elif opts.follow:
                sys.stdout.write(format_follow(ev, opts, out))
            if "[no test files]" in out or "[no tests to run]" in out:
                pkg.notest = True
            m = re.search(r"coverage:\s+([0-9.]+%)", out)
            if m:
                pkg.cover = m.group(1)
    if follow_out:
        follow_out.close()
    return packages, parsed


def format_follow(ev, opts, out):
    if opts.include_timestamp and ev.get("Time"):
        return ev.get("Time") + " " + out
    return out


def elapsed_test(x):
    return f"{x:.2f}"


def elapsed_pkg(x):
    return f"{x:.2f}s"


def clean_test_output(test):
    fail_lines = []
    other_lines = []
    for chunk in test.output:
        for line in chunk.splitlines(True):
            s = line.rstrip("\n")
            if s.startswith("=== RUN"):
                continue
            if s.startswith("--- PASS:") or s.startswith("--- SKIP:"):
                continue
            if s.startswith("--- FAIL:"):
                fail_lines.append(s)
            else:
                other_lines.append(s)
    return "\n".join(fail_lines + other_lines).rstrip()


def clean_panic_output(pkg):
    lines = []
    take = False
    for chunk in pkg.all_output:
        for line in chunk.splitlines():
            if "panic:" in line:
                take = True
            if take or line.startswith("FAIL\t") or line == "FAIL":
                lines.append(line)
    return "\n".join(lines).rstrip()


def center(s, w):
    s = str(s)
    if len(s) >= w:
        return s
    left = (w - len(s)) // 2
    right = w - len(s) - left
    return " " * left + s + " " * right


def basic_table(headers, rows):
    widths = [len(h) for h in headers]
    split_rows = []
    for row in rows:
        parts = []
        height = 1
        for cell in row:
            lines = str(cell).split("\n")
            parts.append(lines)
            height = max(height, len(lines))
            for line in lines:
                widths[len(parts)-1] = max(widths[len(parts)-1], len(line))
        split_rows.append((parts, height))
    top = "╭" + "┬".join("─" * (w + 2) for w in widths) + "╮"
    mid = "├" + "┼".join("─" * (w + 2) for w in widths) + "┤"
    bot = "╰" + "┴".join("─" * (w + 2) for w in widths) + "╯"
    out = [top, "│ " + " │ ".join(center(h, widths[i]) for i, h in enumerate(headers)) + " │", mid]
    for parts, height in split_rows:
        for n in range(height):
            vals = []
            for i, lines in enumerate(parts):
                vals.append(center(lines[n] if n < len(lines) else "", widths[i]))
            out.append("│ " + " │ ".join(vals) + " │")
    out.append(bot)
    return "\n".join(out)


def plain_table(headers, rows):
    widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            for line in str(cell).split("\n"):
                widths[i] = max(widths[i], len(line))
    out = ["  " + "   ".join(center(h, widths[i]) for i, h in enumerate(headers)) + "  ",
           "  " + "   ".join(" " * widths[i] for i in range(len(headers))) + "  "]
    for row in rows:
        cells = [str(c).split("\n") for c in row]
        height = max(len(c) for c in cells)
        for n in range(height):
            vals = [center((cells[i][n] if n < len(cells[i]) else ""), widths[i]) for i in range(len(headers))]
            out.append("  " + "   ".join(vals) + "  ")
    return "\n".join(out)


def markdown_table(headers, rows):
    widths = [len(h) for h in headers]
    one_rows = []
    for row in rows:
        vals = [str(c).replace("\n", "<br>") for c in row]
        one_rows.append(vals)
        for i, val in enumerate(vals):
            widths[i] = max(widths[i], len(val))
    def row(vals):
        return "| " + " | ".join(center(vals[i], widths[i]) for i in range(len(vals))) + " |"
    out = [row(headers), "|" + "|".join("-" * (w + 2) for w in widths) + "|"]
    for vals in one_rows:
        out.append(row(vals))
    return "\n".join(out)


def render_table(headers, rows, fmt):
    if not rows:
        return ""
    if fmt == "plain":
        return plain_table(headers, rows)
    if fmt == "markdown":
        return markdown_table(headers, rows)
    return basic_table(headers, rows)


def box(title):
    w = len(title) + 6
    return "\n".join(["┏" + "━" * w + "┓", "┃   " + title + "   ┃", "┗" + "━" * w + "┛"])


def collect_tests(packages, opts):
    tests = []
    if not (opts.show_all or opts.show_pass or opts.show_skip):
        return tests
    for pkg in packages.values():
        if pkg.panic:
            continue
        for test in pkg.tests.values():
            if not test.status:
                continue
            show = test.status == "FAIL"
            show = show or (opts.show_all and test.status in ("PASS", "SKIP"))
            show = show or (opts.show_pass and test.status == "PASS")
            show = show or (opts.show_skip and test.status == "SKIP")
            if show:
                tests.append(test)
    if opts.sort == "elapsed":
        tests.sort(key=lambda t: (-t.elapsed, t.pkg, t.name))
    else:
        order = {"PASS": 0, "SKIP": 1, "FAIL": 2}
        tests.sort(key=lambda t: (order.get(t.status, 9), t.pkg, t.name))
    if opts.slow > 0:
        tests = sorted(tests, key=lambda t: -t.elapsed)[:opts.slow]
    return tests


def package_rows(packages, opts):
    rows = []
    all_pkgs = list(packages.values())
    has_regular = any(pkg_status(p) != "NOTEST" for p in all_pkgs)
    pkgs = [p for p in all_pkgs if opts.notests or pkg_status(p) != "NOTEST" or not has_regular]
    def pkg_order(p):
        rank = {"PANIC": 0, "FAIL": 1, "PASS": 2, "NOTEST": 3, "SKIP": 4}.get(pkg_status(p), 9)
        if opts.sort == "elapsed":
            return (rank, -p.elapsed, p.name)
        if opts.sort == "cover":
            try:
                cov = -float(p.cover.rstrip("%"))
            except Exception:
                cov = 9999
            return (rank, cov, p.name)
        return (rank, p.name)
    for pkg in sorted(pkgs, key=pkg_order):
        st = pkg_status(pkg)
        passc = sum(1 for t in pkg.tests.values() if t.status == "PASS")
        failc = sum(1 for t in pkg.tests.values() if t.status == "FAIL")
        skipc = sum(1 for t in pkg.tests.values() if t.status == "SKIP")
        name = trim_pkg(pkg.name, opts.trimpath)
        if st == "NOTEST":
            label = "[no test files]"
            if any("[no tests to run]" in x for x in pkg.output):
                label = "[no tests to run]"
            rows.append([st, elapsed_pkg(pkg.elapsed), name + "\n" + label, "--", "--", "--", "--"])
        elif st == "PANIC":
            elapsed = pkg.elapsed
            if pkg.panic_test and pkg.panic_test in pkg.tests:
                elapsed = pkg.tests[pkg.panic_test].elapsed
            rows.append([st, elapsed_pkg(elapsed), name, "--", "--", "--", "--"])
        else:
            rows.append([st, elapsed_pkg(pkg.elapsed), name, pkg.cover, str(passc), str(failc), str(skipc)])
    return rows


def pkg_status(pkg):
    if pkg.panic:
        return "PANIC"
    if pkg.notest and not pkg.tests:
        return "NOTEST"
    if pkg.status:
        return pkg.status
    if any(t.status == "FAIL" for t in pkg.tests.values()):
        return "FAIL"
    if any(t.status == "PASS" for t in pkg.tests.values()):
        return "PASS"
    if pkg.notest:
        return "NOTEST"
    return "SKIP"


def render_markdown(packages, opts):
    out = []
    for pkg in packages.values():
        tests = [t for t in pkg.tests.values() if t.status]
        if tests:
            passc = sum(1 for t in tests if t.status == "PASS")
            failc = sum(1 for t in tests if t.status == "FAIL")
            skipc = sum(1 for t in tests if t.status == "SKIP")
            out.append(f"## 📦 Package **`{trim_pkg(pkg.name, opts.trimpath)}`**\n")
            out.append(f"Tests: ✓ {passc} passed | {skipc} skipped | {failc} failed\n")
            selected = [t for t in collect_tests({pkg.name: pkg}, opts)]
            if selected:
                rows = [[t.status, elapsed_test(t.elapsed), t.name] for t in selected]
                out.append("<details>\n\n<summary>Click for test summary</summary>\n")
                out.append(render_table(["Status", "Elapsed", "Test"], rows, "markdown"))
                out.append("</details>\n")
        if pkg_status(pkg) == "FAIL":
            out.append(f"\n## FAIL • {trim_pkg(pkg.name, opts.trimpath)}\n\n```\n")
            for t in tests:
                if t.status == "FAIL":
                    text = clean_test_output(t)
                    if text:
                        out.append(text + "\n\n")
            out.append("```\n")
        elif pkg_status(pkg) == "PANIC":
            title = f"PANIC • {trim_pkg(pkg.name, opts.trimpath)}"
            if pkg.panic_test:
                title += f" • {pkg.panic_test}"
            out.append(f"\n## {title}\n\n```\n{clean_panic_output(pkg)}\n```\n")
    rows = package_rows(packages, opts)
    if rows:
        out.append(render_table(["Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"], rows, "markdown"))
    return "\n".join(x.rstrip("\n") for x in out if x is not None).rstrip() + "\n"


def render(packages, opts):
    if opts.format == "markdown":
        return render_markdown(packages, opts)
    out = []
    tests = collect_tests(packages, opts)
    if tests:
        rows = [[t.status, elapsed_test(t.elapsed), t.name, trim_pkg(t.pkg, opts.trimpath)] for t in tests]
        out.append(render_table(["Status", "Elapsed", "Test", "Package"], rows, opts.format))
    for pkg in packages.values():
        st = pkg_status(pkg)
        name = trim_pkg(pkg.name, opts.trimpath)
        if st == "FAIL":
            out.append(box(f"FAIL  package: {name}"))
            body = []
            first = True
            for test in sorted(pkg.tests.values(), key=lambda t: t.name):
                if test.status == "FAIL":
                    txt = clean_test_output(test)
                    if txt:
                        if not first:
                            body.append("────────────────────────────────────────────────────────────────────────────────────────────────")
                        body.append(txt)
                        first = False
            if body:
                out.append("\n\n" + "\n\n".join(body))
        elif st == "PANIC":
            title = f"PANIC  package: {name}"
            if pkg.panic_test:
                title += f" • {pkg.panic_test}"
            out.append(box(title))
            txt = clean_panic_output(pkg)
            if txt:
                out.append(txt)
    rows = package_rows(packages, opts)
    if rows:
        out.append(render_table(["Status", "Elapsed", "Package", "Cover", "Pass", "Fail", "Skip"], rows, opts.format))
    return "\n".join(out).rstrip() + "\n"


def main():
    opts = parse_args(sys.argv[1:])
    if opts.format not in ("basic", "plain", "markdown"):
        print(f'invalid option:"{opts.format}". The -format flag must be one of: basic, plain or markdown')
        return 0
    packages, parsed = read_events(opts)
    if parsed == 0:
        print("no parsable events: Make sure to run go test with -json flag", file=sys.stderr)
        return 1
    if opts.progress:
        for pkg in packages.values():
            print(f"[{pkg_status(pkg)}]\t{elapsed_pkg(pkg.elapsed):>9}\t{trim_pkg(pkg.name, opts.trimpath)}")
    sys.stdout.write(render(packages, opts))
    return 1 if any(pkg_status(p) in ("FAIL", "PANIC") for p in packages.values()) else 0


if __name__ == "__main__":
    sys.exit(main())
