#!/usr/bin/env python3
import base64
import csv
import http.client
import json
import math
import os
import random
import re
import ssl
import sys
import threading
import time
from queue import Queue
from urllib.parse import urlsplit, urlunsplit

VERSION = "oha 1.12.1"

HELP = """Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
          You can change this behavior with `-w` option.
          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. `-w` option is ignored.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
          Note: If qps is specified, burst will be ignored
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
          Note: If qps is specified, burst will be ignored
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
          Note: if used several times for the same host:port:target_host:target_port, a random choice is made
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version"""


class Opt:
    def __init__(self):
        self.n = 200
        self.c = 50
        self.p = 1
        self.duration = None
        self.qps = None
        self.burst_delay = None
        self.burst_rate = 1
        self.rand_regex_url = False
        self.urls_from_file = False
        self.max_repeat = 4
        self.dump_urls = None
        self.no_tui = False
        self.method = "GET"
        self.headers = []
        self.proxy_headers = []
        self.timeout = None
        self.connect_timeout = 5.0
        self.accept = None
        self.body = None
        self.body_path = None
        self.body_path_lines = None
        self.forms = []
        self.content_type = None
        self.basic_auth = None
        self.host = None
        self.redirect = 10
        self.disable_keepalive = False
        self.insecure = False
        self.output = None
        self.output_format = "text"
        self.time_unit = None
        self.debug = False
        self.url = None


TAKES_VALUE = {
    "-n", "-c", "-p", "-z", "-q", "--burst-delay", "--burst-rate",
    "--max-repeat", "--dump-urls", "-m", "--method", "-H", "--proxy-header",
    "-t", "--connect-timeout", "-A", "-d", "-D", "-Z", "-F", "--form",
    "-T", "-a", "--aws-session", "--aws-sigv4", "-x", "--proxy-http-version",
    "--http-version", "--host", "-r", "--redirect", "--cacert", "--cert",
    "--key", "--connect-to", "--unix-socket", "--db-url", "-o", "--output",
    "--output-format", "-u", "--time-unit", "--fps",
}

IGNORED_FLAGS = {
    "-w", "--wait-ongoing-requests-after-deadline", "--latency-correction",
    "--no-tui", "--proxy-http2", "--http2", "--disable-compression",
    "--disable-keepalive", "--no-pre-lookup", "--ipv6", "--ipv4",
    "--insecure", "--no-color", "--stats-success-breakdown", "--debug",
    "--rand-regex-url", "--urls-from-file",
}


def die(msg, code=2):
    sys.stderr.write(msg + "\n")
    raise SystemExit(code)


def invalid_value(val, flag, reason=None):
    if reason is None:
        reason = "invalid digit found in string"
    die(f"error: invalid value '{val}' for '{flag}': {reason}\n\nFor more information, try '--help'.")


def parse_count(s, flag):
    try:
        if s.lower().endswith("k"):
            return int(float(s[:-1]) * 1000)
        if s.lower().endswith("m"):
            return int(float(s[:-1]) * 1000000)
        return int(s)
    except Exception:
        invalid_value(s, flag)


def parse_duration(s, flag):
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)(ns|us|µs|ms|s|m|h)?", s)
    if not m:
        invalid_value(s, flag, "expected a duration like 10s or 3m")
    val = float(m.group(1))
    unit = m.group(2) or "s"
    mult = {"ns": 1e-9, "us": 1e-6, "µs": 1e-6, "ms": 1e-3, "s": 1, "m": 60, "h": 3600}[unit]
    return val * mult


def parse_args(argv):
    opt = Opt()
    i = 0
    positional = []
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--":
            positional += argv[i + 1:]
            break
        if a.startswith("--") and "=" in a:
            a, val = a.split("=", 1)
            argv = argv[:i + 1] + [val] + argv[i + 1:]
        if a in TAKES_VALUE:
            if i + 1 >= len(argv):
                die(f"error: a value is required for '{a} <VALUE>' but none was supplied\n\nFor more information, try '--help'.")
            v = argv[i + 1]
            if a == "-n":
                opt.n = parse_count(v, "-n <N_REQUESTS>")
            elif a == "-c":
                opt.c = parse_count(v, "-c <N_CONNECTIONS>")
            elif a == "-p":
                opt.p = parse_count(v, "-p <N_HTTP2_PARALLEL>")
            elif a == "-z":
                opt.duration = parse_duration(v, "-z <DURATION>")
            elif a == "-q":
                try:
                    opt.qps = float(v)
                except Exception:
                    invalid_value(v, "-q <QUERY_PER_SECOND>", "invalid float literal")
            elif a == "--burst-delay":
                opt.burst_delay = parse_duration(v, "--burst-delay <BURST_DURATION>")
            elif a == "--burst-rate":
                opt.burst_rate = parse_count(v, "--burst-rate <BURST_REQUESTS>")
            elif a == "--max-repeat":
                opt.max_repeat = parse_count(v, "--max-repeat <MAX_REPEAT>")
            elif a == "--dump-urls":
                opt.dump_urls = parse_count(v, "--dump-urls <DUMP_URLS>")
            elif a in ("-m", "--method"):
                opt.method = v.upper()
            elif a == "-H":
                opt.headers.append(v)
            elif a == "--proxy-header":
                opt.proxy_headers.append(v)
            elif a == "-t":
                opt.timeout = parse_duration(v, "-t <TIMEOUT>")
            elif a == "--connect-timeout":
                opt.connect_timeout = parse_duration(v, "--connect-timeout <CONNECT_TIMEOUT>")
            elif a == "-A":
                opt.accept = v
            elif a == "-d":
                opt.body = v.encode()
            elif a == "-D":
                opt.body_path = v
            elif a == "-Z":
                opt.body_path_lines = v
            elif a in ("-F", "--form"):
                opt.forms.append(v)
            elif a == "-T":
                opt.content_type = v
            elif a == "-a":
                opt.basic_auth = v
            elif a == "--host":
                opt.host = v
            elif a in ("-r", "--redirect"):
                opt.redirect = parse_count(v, f"{a} <REDIRECT>")
            elif a in ("-o", "--output"):
                opt.output = v
            elif a == "--output-format":
                if v not in ("text", "json", "csv", "quiet"):
                    die(f"error: invalid value '{v}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: text, json, csv, quiet]\n\nFor more information, try '--help'.")
                opt.output_format = v
            elif a in ("-u", "--time-unit"):
                if v not in ("ns", "us", "ms", "s", "m", "h"):
                    die(f"error: invalid value '{v}' for '--time-unit <TIME_UNIT>'\n  [possible values: ns, us, ms, s, m, h]\n\nFor more information, try '--help'.")
                opt.time_unit = v
            i += 2
            continue
        if a in IGNORED_FLAGS:
            if a == "--no-tui":
                opt.no_tui = True
            elif a == "--debug":
                opt.debug = True
            elif a == "--rand-regex-url":
                opt.rand_regex_url = True
            elif a == "--urls-from-file":
                opt.urls_from_file = True
            elif a == "--disable-keepalive":
                opt.disable_keepalive = True
            elif a == "--insecure":
                opt.insecure = True
            i += 1
            continue
        if a.startswith("-"):
            die(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.")
        positional.append(a)
        i += 1
    if len(positional) != 1:
        print(HELP)
        raise SystemExit(2 if len(positional) == 0 else 1)
    opt.url = positional[0]
    if opt.body_path:
        with open(opt.body_path, "rb") as f:
            opt.body = f.read()
    if opt.forms and opt.body is None:
        boundary = "------------------------oha"
        parts = []
        for form in opt.forms:
            name, _, val = form.partition("=")
            parts.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{val}\r\n".encode())
        parts.append(f"--{boundary}--\r\n".encode())
        opt.body = b"".join(parts)
        opt.content_type = f"multipart/form-data; boundary={boundary}"
    return opt


def expand_regex(pattern, max_repeat=4):
    out = []
    i = 0
    while i < len(pattern):
        if pattern[i] == "[":
            j = pattern.find("]", i + 1)
            if j > i:
                spec = pattern[i + 1:j]
                chars = []
                k = 0
                while k < len(spec):
                    if k + 2 < len(spec) and spec[k + 1] == "-":
                        chars.extend(chr(c) for c in range(ord(spec[k]), ord(spec[k + 2]) + 1))
                        k += 3
                    else:
                        chars.append(spec[k])
                        k += 1
                out.append(random.choice(chars or [""]))
                i = j + 1
                continue
        out.append(pattern[i])
        i += 1
    return "".join(out)


def build_headers(opt, parsed):
    headers = {
        "Accept": opt.accept if opt.accept is not None else "*/*",
        "Accept-Encoding": "gzip, compress, deflate, br",
        "User-Agent": "oha/1.12.1",
    }
    if opt.host:
        headers["Host"] = opt.host
    else:
        headers["Host"] = parsed.netloc
    if opt.disable_keepalive:
        headers["Connection"] = "close"
    if opt.content_type:
        headers["Content-Type"] = opt.content_type
    if opt.basic_auth:
        headers["Authorization"] = "Basic " + base64.b64encode(opt.basic_auth.encode()).decode()
    for h in opt.headers:
        name, sep, value = h.partition(":")
        if sep:
            headers[name.strip()] = value.strip()
    return headers


def request_once(url, opt, body_override=None):
    start = time.perf_counter()
    parsed = urlsplit(url)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("relative URL without a base")
    body = opt.body if body_override is None else body_override
    cur_url = url
    redirects = opt.redirect
    dns_time = 0.0
    dial_time = 0.0
    while True:
        parsed = urlsplit(cur_url)
        if parsed.scheme not in ("http", "https"):
            raise ValueError("unsupported URL scheme")
        path = urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
        timeout = opt.timeout if opt.timeout is not None else None
        context = None
        if parsed.scheme == "https":
            context = ssl._create_unverified_context() if opt.insecure else None
            conn = http.client.HTTPSConnection(parsed.hostname, parsed.port or 443, timeout=timeout, context=context)
        else:
            conn = http.client.HTTPConnection(parsed.hostname, parsed.port or 80, timeout=timeout)
        headers = build_headers(opt, parsed)
        t0 = time.perf_counter()
        conn.connect()
        dial_time += time.perf_counter() - t0
        t_req = time.perf_counter()
        conn.request(opt.method, path, body=body, headers=headers)
        resp = conn.getresponse()
        data = resp.read()
        status = resp.status
        resp_headers = resp.getheaders()
        if status in (301, 302, 303, 307, 308) and redirects > 0:
            loc = dict((k.lower(), v) for k, v in resp_headers).get("location")
            conn.close()
            if loc:
                if loc.startswith("/"):
                    cur_url = urlunsplit((parsed.scheme, parsed.netloc, loc, "", ""))
                else:
                    cur_url = loc
                redirects -= 1
                continue
        end = time.perf_counter()
        conn.close()
        return {
            "start": start, "dns": dns_time, "dial": dial_time,
            "response_delay": max(0.0, end - t_req), "duration": end - start,
            "bytes": len(data), "status": status, "error": None, "body": data,
            "headers": resp_headers, "url": cur_url,
        }


def percentile(vals, p):
    if not vals:
        return 0.0
    vals = sorted(vals)
    idx = int(math.ceil((p / 100.0) * len(vals))) - 1
    idx = max(0, min(idx, len(vals) - 1))
    return vals[idx]


def fmt_time(sec, unit=None):
    if unit is None:
        unit = "ms" if sec < 1 else "s"
    mult = {"ns": 1e9, "us": 1e6, "ms": 1e3, "s": 1, "m": 1 / 60, "h": 1 / 3600}[unit]
    suffix = {"us": "µs"}.get(unit, unit)
    return f"{sec * mult:.4f} {suffix}"


def summarize(results, total_elapsed):
    ok = [r for r in results if r.get("error") is None]
    durations = [r["duration"] for r in ok]
    total_data = sum(r["bytes"] for r in ok)
    n = len(results)
    avg = sum(durations) / len(durations) if durations else 0.0
    return {
        "successRate": (len(ok) / n) if n else 0.0,
        "total": total_elapsed,
        "slowest": max(durations) if durations else 0.0,
        "fastest": min(durations) if durations else 0.0,
        "average": avg,
        "requestsPerSec": (len(ok) / total_elapsed) if total_elapsed > 0 else 0.0,
        "totalData": total_data,
        "sizePerRequest": int(total_data / len(ok)) if ok else 0,
        "sizePerSec": (total_data / total_elapsed) if total_elapsed > 0 else 0.0,
    }


def histogram(durations):
    if not durations:
        return [(0.0, 0)]
    mn, mx = min(durations), max(durations)
    if mn == mx:
        return [(mn, len(durations))]
    step = (mx - mn) / 10.0
    bins = []
    for i in range(11):
        upper = mn + step * i
        if i == 0:
            count = sum(1 for d in durations if d <= upper)
        else:
            low = mn + step * (i - 1)
            count = sum(1 for d in durations if low < d <= upper)
        bins.append((upper, count))
    return bins


def text_output(results, total_elapsed, opt):
    s = summarize(results, total_elapsed)
    ok = [r for r in results if r.get("error") is None]
    durations = [r["duration"] for r in ok]
    out = []
    out.append("Summary:")
    out.append(f"  Success rate:\t{s['successRate'] * 100:.2f}%")
    out.append(f"  Total:\t{fmt_time(s['total'], opt.time_unit)}")
    out.append(f"  Slowest:\t{fmt_time(s['slowest'], opt.time_unit)}")
    out.append(f"  Fastest:\t{fmt_time(s['fastest'], opt.time_unit)}")
    out.append(f"  Average:\t{fmt_time(s['average'], opt.time_unit)}")
    out.append(f"  Requests/sec:\t{s['requestsPerSec']:.4f}")
    out.append("")
    out.append(f"  Total data:\t{s['totalData']} B")
    out.append(f"  Size/request:\t{s['sizePerRequest']} B")
    out.append(f"  Size/sec:\t{int(s['sizePerSec'])} B")
    out.append("")
    out.append("Response time histogram:")
    hist = histogram(durations)
    maxc = max((c for _, c in hist), default=1) or 1
    for upper, count in hist:
        bar = "■" * int(round((count / maxc) * 32)) if count else ""
        out.append(f"  {upper * 1000:.3f} ms [{count}] |{bar}")
    out.append("")
    out.append("Response time distribution:")
    for p in (10, 25, 50, 75, 90, 95, 99, 99.9, 99.99):
        out.append(f"  {p:.2f}% in {fmt_time(percentile(durations, p), opt.time_unit)}")
    out.append("")
    out.append("")
    dials = [r["dial"] for r in ok if r.get("dial", 0) > 0]
    if dials:
        avg = sum(dials) / len(dials)
        out.append("Details (average, fastest, slowest):")
        out.append(f"  DNS+dialup:\t{fmt_time(avg, opt.time_unit)}, {fmt_time(min(dials), opt.time_unit)}, {fmt_time(max(dials), opt.time_unit)}")
        out.append("")
    status = {}
    errors = {}
    for r in results:
        if r.get("error"):
            errors[r["error"]] = errors.get(r["error"], 0) + 1
        else:
            status[r["status"]] = status.get(r["status"], 0) + 1
    if status:
        out.append("Status code distribution:")
        for k in sorted(status):
            out.append(f"  [{k}] {status[k]} responses")
    if errors:
        out.append("")
        out.append("Error distribution:")
        for k, v in sorted(errors.items()):
            out.append(f"  [{v}] {k}")
    return "\n".join(out) + "\n"


def json_output(results, total_elapsed):
    s = summarize(results, total_elapsed)
    ok = [r for r in results if r.get("error") is None]
    durations = [r["duration"] for r in ok]
    status = {}
    errors = {}
    for r in results:
        if r.get("error"):
            errors[r["error"]] = errors.get(r["error"], 0) + 1
        else:
            status[str(r["status"])] = status.get(str(r["status"]), 0) + 1
    hist = {str(k): v for k, v in histogram(durations)}
    percs = {"p10": percentile(durations, 10), "p25": percentile(durations, 25),
             "p50": percentile(durations, 50), "p75": percentile(durations, 75),
             "p90": percentile(durations, 90), "p95": percentile(durations, 95),
             "p99": percentile(durations, 99), "p99.9": percentile(durations, 99.9),
             "p99.99": percentile(durations, 99.99)}
    dials = [r["dial"] for r in ok if r.get("dial", 0) > 0]
    details = {}
    if dials:
        details["DNSDialup"] = {"average": sum(dials) / len(dials), "fastest": min(dials), "slowest": max(dials)}
    obj = {
        "summary": s,
        "responseTimeHistogram": hist,
        "latencyPercentiles": percs,
        "rps": {"mean": s["requestsPerSec"], "stddev": 0.0, "max": s["requestsPerSec"], "min": s["requestsPerSec"], "percentiles": percs},
        "details": details,
        "statusCodeDistribution": status,
        "errorDistribution": errors,
    }
    return json.dumps(obj, indent=2) + "\n"


def csv_output(results):
    import io
    f = io.StringIO()
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["request-start", "DNS", "DNS+dialup", "Response-delay", "request-duration", "bytes", "status"])
    base = min((r["start"] for r in results), default=time.perf_counter())
    for r in results:
        w.writerow([f"{r['start'] - base:.9g}", f"{r.get('dns', 0):.9g}", f"{r.get('dial', 0):.9g}",
                    f"{r.get('response_delay', 0):.9g}", f"{r.get('duration', 0):.9g}",
                    r.get("bytes", 0), r.get("status", 0) if not r.get("error") else ""])
    return f.getvalue()


def debug(opt):
    url = opt.url
    parsed = urlsplit(url)
    if not parsed.scheme or not parsed.netloc:
        die("Error: relative URL without a base", 1)
    headers = build_headers(opt, parsed)
    path = urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    print("Request {")
    print(f"    method: {opt.method},")
    print(f"    uri: {path},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in headers.items():
        print(f'        "{k.lower()}": "{v}",')
    print("    },")
    if opt.body is not None:
        print("    body: Full {")
        print("        data: Some(")
        print(f"            b\"{opt.body.decode(errors='backslashreplace')}\",")
        print("        ),")
        print("    },")
    else:
        print("    body: Empty,")
    print("}")
    try:
        r = request_once(url, opt)
    except Exception as e:
        die("Error: " + str(e), 1)
    print("Response {")
    print(f"    status: {r['status']},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in r["headers"]:
        print(f'        "{k.lower()}": "{v}",')
    print("    },")
    body = r["body"].decode(errors="backslashreplace")
    print(f"    body: b\"{body}\",")
    print("}")


def main():
    opt = parse_args(sys.argv[1:])
    if opt.debug:
        debug(opt)
        return
    if opt.urls_from_file:
        try:
            with open(opt.url) as f:
                urls = [line.strip() for line in f if line.strip()]
        except Exception as e:
            die("Error: " + str(e), 1)
    else:
        urls = [opt.url]
    if opt.dump_urls is not None:
        for _ in range(opt.dump_urls):
            u = random.choice(urls)
            print(expand_regex(u, opt.max_repeat) if opt.rand_regex_url else u)
        return
    for u in urls[:1]:
        p = urlsplit(u)
        if not p.scheme or not p.netloc:
            die("Error: relative URL without a base", 1)
    if opt.duration is not None:
        target_n = 10 ** 9
        end_time = time.perf_counter() + opt.duration
    else:
        target_n = opt.n
        end_time = None
    q = Queue()
    results = []
    lock = threading.Lock()
    next_lock = threading.Lock()
    counter = {"i": 0}
    start_all = time.perf_counter()

    if opt.output_format == "csv":
        csv_rows = []

    def next_job():
        with next_lock:
            if end_time is not None and time.perf_counter() >= end_time:
                return None
            if counter["i"] >= target_n:
                return None
            idx = counter["i"]
            counter["i"] += 1
        if opt.qps:
            due = start_all + idx / opt.qps
            delay = due - time.perf_counter()
            if delay > 0:
                time.sleep(delay)
        elif opt.burst_delay and idx and idx % max(1, opt.burst_rate) == 0:
            time.sleep(opt.burst_delay)
        u = random.choice(urls)
        if opt.rand_regex_url:
            u = expand_regex(u, opt.max_repeat)
        body = opt.body
        if opt.body_path_lines:
            try:
                with open(opt.body_path_lines, "rb") as f:
                    lines = [line.rstrip(b"\n") for line in f]
                if lines:
                    body = lines[idx % len(lines)]
            except Exception:
                body = b""
        return u, body

    def worker():
        while True:
            job = next_job()
            if job is None:
                return
            u, body = job
            try:
                r = request_once(u, opt, body)
            except Exception as e:
                now = time.perf_counter()
                r = {"start": now, "duration": 0.0, "bytes": 0, "status": 0, "error": str(e), "dns": 0.0, "dial": 0.0, "response_delay": 0.0}
            with lock:
                results.append(r)

    threads = []
    for _ in range(max(1, opt.c * max(1, opt.p))):
        t = threading.Thread(target=worker)
        t.start()
        threads.append(t)
    for t in threads:
        t.join()
    total_elapsed = max(time.perf_counter() - start_all, 1e-9)
    if opt.output_format == "quiet":
        out = ""
    elif opt.output_format == "json":
        out = json_output(results, total_elapsed)
    elif opt.output_format == "csv":
        out = csv_output(results)
    else:
        out = text_output(results, total_elapsed, opt)
    if opt.output:
        with open(opt.output, "w") as f:
            f.write(out)
    else:
        sys.stdout.write(out)


if __name__ == "__main__":
    main()
