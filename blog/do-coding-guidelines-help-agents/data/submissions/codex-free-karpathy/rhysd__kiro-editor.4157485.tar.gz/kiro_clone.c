#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

static const char *HELP =
"./executable: A tiny UTF-8 terminal text editor\n"
"\n"
"Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.\n"
"Specify file paths to edit as a command argument or run without argument to\n"
"start to write a new text.\n"
"Help can show up with key mapping Ctrl-?.\n"
"\n"
"Usage:\n"
"    ./executable [options] [FILES...]\n"
"\n"
"Mappings:\n"
"    Ctrl-Q                        : Quit\n"
"    Ctrl-S                        : Save to file\n"
"    Ctrl-O                        : Open text buffer\n"
"    Ctrl-X                        : Next text buffer\n"
"    Alt-X                         : Previous text buffer\n"
"    Ctrl-P or UP                  : Move cursor up\n"
"    Ctrl-N or DOWN                : Move cursor down\n"
"    Ctrl-F or RIGHT               : Move cursor right\n"
"    Ctrl-B or LEFT                : Move cursor left\n"
"    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line\n"
"    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line\n"
"    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page\n"
"    Ctrl-] or Alt-V or PAGE UP    : Previous page\n"
"    Alt-F or Ctrl-RIGHT           : Move cursor to next word\n"
"    Alt-B or Ctrl-LEFT            : Move cursor to previous word\n"
"    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph\n"
"    Alt-P or Ctrl-UP              : Move cursor to previous paragraph\n"
"    Alt-<                         : Move cursor to top of file\n"
"    Alt->                         : Move cursor to bottom of file\n"
"    Ctrl-H or BACKSPACE           : Delete character\n"
"    Ctrl-D or DELETE              : Delete next character\n"
"    Ctrl-W                        : Delete a word\n"
"    Ctrl-J                        : Delete until head of line\n"
"    Ctrl-K                        : Delete until end of line\n"
"    Ctrl-U                        : Undo last change\n"
"    Ctrl-R                        : Redo last undo change\n"
"    Ctrl-G                        : Search text\n"
"    Ctrl-M                        : New line\n"
"    Ctrl-L                        : Refresh screen\n"
"    Ctrl-?                        : Show this help\n"
"\n"
"Options:\n"
"    -v, --version       Print version\n"
"    -h, --help          Print this help\n";

struct Buffer {
    char *path;
    unsigned char *data;
    size_t len;
    size_t cap;
    size_t cursor;
    bool dirty;
};

static struct termios orig_termios;
static bool raw_enabled = false;

static void write_all(int fd, const void *buf, size_t len) {
    const char *p = buf;
    while (len) {
        ssize_t n = write(fd, p, len);
        if (n <= 0) return;
        p += n;
        len -= (size_t)n;
    }
}

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    fputs("Error: ", stderr);
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
}

static void disable_raw(void) {
    if (raw_enabled) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &orig_termios);
        raw_enabled = false;
        write_all(STDOUT_FILENO, "\x1b[?25h\x1b[0m\x1b[2J\x1b[H", sizeof("\x1b[?25h\x1b[0m\x1b[2J\x1b[H") - 1);
    }
}

static int enable_raw(void) {
    if (tcgetattr(STDIN_FILENO, &orig_termios) == -1) return -1;
    atexit(disable_raw);
    struct termios raw = orig_termios;
    raw.c_iflag &= (tcflag_t)~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
    raw.c_oflag &= (tcflag_t)~(OPOST);
    raw.c_cflag |= CS8;
    raw.c_lflag &= (tcflag_t)~(ECHO | ICANON | IEXTEN | ISIG);
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) == -1) return -1;
    raw_enabled = true;
    return 0;
}

static void append_bytes(struct Buffer *b, const unsigned char *s, size_t n) {
    if (b->len + n + 1 > b->cap) {
        size_t nc = b->cap ? b->cap : 1024;
        while (nc < b->len + n + 1) nc *= 2;
        unsigned char *p = realloc(b->data, nc);
        if (!p) exit(2);
        b->data = p;
        b->cap = nc;
    }
    memmove(b->data + b->cursor + n, b->data + b->cursor, b->len - b->cursor);
    memcpy(b->data + b->cursor, s, n);
    b->cursor += n;
    b->len += n;
    b->data[b->len] = 0;
    b->dirty = true;
}

static void delete_before(struct Buffer *b) {
    if (b->cursor == 0) return;
    size_t start = b->cursor - 1;
    while (start > 0 && (b->data[start] & 0xc0) == 0x80) start--;
    memmove(b->data + start, b->data + b->cursor, b->len - b->cursor);
    b->len -= b->cursor - start;
    b->cursor = start;
    b->data[b->len] = 0;
    b->dirty = true;
}

static void delete_at(struct Buffer *b) {
    if (b->cursor >= b->len) return;
    size_t end = b->cursor + 1;
    while (end < b->len && (b->data[end] & 0xc0) == 0x80) end++;
    memmove(b->data + b->cursor, b->data + end, b->len - end);
    b->len -= end - b->cursor;
    b->data[b->len] = 0;
    b->dirty = true;
}

static void move_left(struct Buffer *b) {
    if (b->cursor == 0) return;
    b->cursor--;
    while (b->cursor > 0 && (b->data[b->cursor] & 0xc0) == 0x80) b->cursor--;
}

static void move_right(struct Buffer *b) {
    if (b->cursor >= b->len) return;
    b->cursor++;
    while (b->cursor < b->len && (b->data[b->cursor] & 0xc0) == 0x80) b->cursor++;
}

static void load_file(struct Buffer *b, const char *path) {
    b->path = strdup(path);
    FILE *f = fopen(path, "rb");
    if (!f) return;
    unsigned char tmp[4096];
    size_t n;
    while ((n = fread(tmp, 1, sizeof(tmp), f)) > 0) {
        size_t old = b->cursor;
        b->cursor = b->len;
        append_bytes(b, tmp, n);
        b->cursor = old;
        b->dirty = false;
    }
    fclose(f);
    b->cursor = 0;
    b->dirty = false;
}

static int save_file(struct Buffer *b) {
    const char *path = b->path ? b->path : "kiro.txt";
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    if (b->len && fwrite(b->data, 1, b->len, f) != b->len) {
        fclose(f);
        return -1;
    }
    if (fclose(f) != 0) return -1;
    b->dirty = false;
    return 0;
}

static void draw(struct Buffer *b, const char *message) {
    struct winsize ws = {0};
    int rows = 24, cols = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row) {
        rows = ws.ws_row;
        cols = ws.ws_col ? ws.ws_col : 80;
    }
    dprintf(STDOUT_FILENO, "\x1b[?25l\x1b[H");
    int row = 0, col = 0;
    for (size_t i = 0; i < b->len && row < rows - 2; i++) {
        unsigned char c = b->data[i];
        if (c == '\n') {
            dprintf(STDOUT_FILENO, "\x1b[K\r\n");
            row++;
            col = 0;
        } else {
            write_all(STDOUT_FILENO, &c, 1);
            if (++col >= cols) {
                row++;
                col = 0;
            }
        }
    }
    while (row < rows - 2) {
        dprintf(STDOUT_FILENO, "\x1b[K\r\n~");
        row++;
    }
    const char *name = b->path ? b->path : "[No Name]";
    dprintf(STDOUT_FILENO, "\x1b[7m %-20.20s %s%zu bytes \x1b[m\x1b[K\r\n",
            name, b->dirty ? "(modified) " : "", b->len);
    dprintf(STDOUT_FILENO, "%.*s\x1b[K", cols, message ? message : "");

    int cy = 0, cx = 0;
    for (size_t i = 0; i < b->cursor && i < b->len; i++) {
        if (b->data[i] == '\n') {
            cy++;
            cx = 0;
        } else if (++cx >= cols) {
            cy++;
            cx = 0;
        }
    }
    if (cy > rows - 3) cy = rows - 3;
    dprintf(STDOUT_FILENO, "\x1b[%d;%dH\x1b[?25h", cy + 1, cx + 1);
}

static int parse_escape(struct Buffer *b) {
    unsigned char seq[8];
    ssize_t n = read(STDIN_FILENO, seq, sizeof(seq));
    if (n <= 0) return 0;
    if (n >= 2 && seq[0] == '[') {
        if (seq[1] == 'D') move_left(b);
        else if (seq[1] == 'C') move_right(b);
        else if (seq[1] == 'H') b->cursor = 0;
        else if (seq[1] == 'F') b->cursor = b->len;
        else if (seq[1] == '3') delete_at(b);
    } else if (n >= 1 && seq[0] == '<') {
        b->cursor = 0;
    } else if (n >= 1 && seq[0] == '>') {
        b->cursor = b->len;
    } else if (n >= 1 && (seq[0] == 'b' || seq[0] == 'B')) {
        move_left(b);
    } else if (n >= 1 && (seq[0] == 'f' || seq[0] == 'F')) {
        move_right(b);
    }
    return 0;
}

static int editor(const char *path) {
    struct winsize ws;
    if (ioctl(STDIN_FILENO, TIOCGWINSZ, &ws) == -1) {
        die("%s (os error %d)", strerror(errno), errno);
        return 1;
    }
    if (enable_raw() == -1) {
        die("%s (os error %d)", strerror(errno), errno);
        return 1;
    }

    struct Buffer b = {0};
    if (path) load_file(&b, path);
    const char *msg = "HELP: Ctrl-S = save | Ctrl-Q = quit | Ctrl-? = help";
    draw(&b, msg);
    for (;;) {
        unsigned char c;
        ssize_t n = read(STDIN_FILENO, &c, 1);
        if (n <= 0) break;
        msg = "";
        if (c == 17) break;
        else if (c == 19) msg = save_file(&b) == 0 ? "Saved" : strerror(errno);
        else if (c == 127 || c == 8) delete_before(&b);
        else if (c == 4) delete_at(&b);
        else if (c == 1) b.cursor = 0;
        else if (c == 5) b.cursor = b.len;
        else if (c == 2) move_left(&b);
        else if (c == 6) move_right(&b);
        else if (c == 13 || c == 10) {
            unsigned char nl = '\n';
            append_bytes(&b, &nl, 1);
        } else if (c == 12) {
            write_all(STDOUT_FILENO, "\x1b[2J", 4);
        } else if (c == 27) {
            parse_escape(&b);
        } else if (c == 31 || c == 127) {
            disable_raw();
            fputs(HELP, stdout);
            return 0;
        } else if (c >= 32) {
            append_bytes(&b, &c, 1);
        }
        draw(&b, msg);
    }
    disable_raw();
    free(b.path);
    free(b.data);
    return 0;
}

static int option_name(const char *arg, char *out, size_t outsz) {
    if (arg[0] != '-') return 0;
    if (arg[1] == '-') {
        if (!arg[2]) return -1;
        size_t i = 2, j = 0;
        while (arg[i] && arg[i] != '=' && j + 1 < outsz) out[j++] = arg[i++];
        out[j] = 0;
        return 1;
    }
    if (!arg[1]) return -1;
    out[0] = arg[1];
    out[1] = 0;
    return 1;
}

int main(int argc, char **argv) {
    bool want_help = false, want_version = false;
    const char *first_file = NULL;
    char bad[128] = {0};
    for (int i = 1; i < argc; i++) {
        char opt[128] = {0};
        int r = option_name(argv[i], opt, sizeof(opt));
        if (r == 0) {
            if (!first_file) first_file = argv[i];
            continue;
        }
        if (r < 0) return 1;
        if (strcmp(opt, "v") == 0 || strcmp(opt, "version") == 0) want_version = true;
        else if (strcmp(opt, "h") == 0 || strcmp(opt, "help") == 0) want_help = true;
        else if (!bad[0]) snprintf(bad, sizeof(bad), "%s", opt);
    }
    if (bad[0]) {
        die("Unrecognized option: '%s'. Please see --help for more details", bad);
        return 1;
    }
    if (want_version) {
        puts("0.4.3");
        return 0;
    }
    if (want_help) {
        fputs(HELP, stdout);
        return 0;
    }
    return editor(first_file);
}
