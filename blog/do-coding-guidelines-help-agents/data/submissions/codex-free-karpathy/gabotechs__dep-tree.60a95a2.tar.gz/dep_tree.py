#!/usr/bin/env python3
import argparse
import fnmatch
import glob
import json
import os
import re
import sys
from collections import OrderedDict

VERSION = "dep-tree version v0.23.4"
DEFAULT_CONFIG = """.dep-tree.yml sample configuration for dep-tree.

exclude:
  - 'some-glob-pattern/**/*.ts'

only:
  - 'some-glob-pattern/**/*.ts'

unwrapExports: false

check:
  entrypoints:
    - src/index.ts
  allowCircularDependencies: false
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
  deny:
    'src/products/**':
      - 'src/users/**'
  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false
"""

HELP = r"""
      ____         _ __       _
     |  _ \   ___ |  _ \    _| |_  _ __  ___   ___
     | | | | / _ \| |_) |  |_   _||  __|/ _ \ / _ \
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \__| |_|        | \__|_|   \___| \___|

Usage:
  dep-tree [command]

Examples:
$ dep-tree src/index.ts
$ dep-tree entropy src/index.ts
$ dep-tree tree package/main.py --unwrap-exports
$ dep-tree check

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree

Use "dep-tree [command] --help" for more information about a command.
""".strip("\n")

CMD_HELP = {
    "tree": """Render the dependency tree starting from the provided entrypoint

Usage:
  dep-tree tree [flags]

Flags:
  -h, --help   help for tree
      --json   render the dependency tree in a machine readable json format""",
    "explain": """Shows all the dependencies between two parts of the code

Usage:
  dep-tree explain [flags]

Flags:
  -h, --help            help for explain
  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left
  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right""",
    "check": """Checks that the dependency rules defined in the configuration file are not broken

Usage:
  dep-tree check [flags]

Flags:
  -h, --help   help for check""",
    "config": """Generates a sample config in case that there's not already one present

Usage:
  dep-tree config [flags]

Aliases:
  config, init

Flags:
  -h, --help   help for config""",
    "entropy": """(default) Renders a 3d force-directed graph in the browser

Usage:
  dep-tree entropy [flags]

Flags:
      --enable-gui           Enables a GUI for changing rendering settings
  -h, --help                 help for entropy
      --no-browser-open      Disable the automatic browser open while rendering entropy
      --render-path string   Sets the output path of the rendered html file""",
}

GLOBAL_HELP = """

Global Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
"""

def clean_scalar(s):
    s = s.strip()
    if not s:
        return ""
    if (s[0], s[-1]) in [("'", "'"), ('"', '"')]:
        return s[1:-1]
    if s.lower() == "true":
        return True
    if s.lower() == "false":
        return False
    return s

def parse_simple_yaml(path):
    if not os.path.exists(path):
        return {}
    root = {}
    stack = [(-1, root)]
    last_key = {}
    with open(path, encoding="utf-8") as f:
        for raw in f:
            if not raw.strip() or raw.lstrip().startswith("#"):
                continue
            line = raw.split("#", 1)[0].rstrip("\n")
            indent = len(line) - len(line.lstrip(" "))
            text = line.strip()
            while stack and indent <= stack[-1][0]:
                stack.pop()
            parent = stack[-1][1]
            if text.startswith("- "):
                val = text[2:].strip()
                if isinstance(parent, list):
                    if ":" in val and not val.startswith(("'", '"')):
                        k, v = val.split(":", 1)
                        item = {clean_scalar(k): clean_scalar(v)}
                        parent.append(item)
                        stack.append((indent, item))
                    else:
                        parent.append(clean_scalar(val))
                continue
            if ":" in text:
                key, val = text.split(":", 1)
                key = clean_scalar(key)
                val = val.strip()
                if val:
                    parent[key] = clean_scalar(val)
                else:
                    parent[key] = {}
                    last_key[id(parent)] = key
                    stack.append((indent, parent[key]))
            # Convert empty dicts to lists when the first child is a dash.
            nxt = None
    # Second pass handles common key:\n  - item lists.
    lines = []
    with open(path, encoding="utf-8") as f:
        lines = [ln.rstrip("\n") for ln in f if ln.strip() and not ln.lstrip().startswith("#")]
    def build(i, indent):
        obj = {}
        arr = None
        while i < len(lines):
            line = lines[i].split("#", 1)[0].rstrip()
            if not line.strip():
                i += 1; continue
            ind = len(line) - len(line.lstrip(" "))
            if ind < indent:
                break
            if ind > indent:
                i += 1; continue
            text = line.strip()
            if text.startswith("- "):
                if arr is None: arr = []
                val = text[2:].strip()
                if ":" in val and not val.startswith(("'", '"')):
                    k, v = val.split(":", 1)
                    item = {clean_scalar(k): clean_scalar(v)}
                    j, child = build(i + 1, ind + 2)
                    if isinstance(child, dict): item.update(child)
                    arr.append(item); i = j
                else:
                    arr.append(clean_scalar(val)); i += 1
            elif ":" in text:
                k, v = text.split(":", 1)
                k = clean_scalar(k); v = v.strip()
                if v:
                    obj[k] = clean_scalar(v); i += 1
                else:
                    j, child = build(i + 1, ind + 2)
                    obj[k] = [] if child is None else child
                    i = j
            else:
                i += 1
        return i, arr if arr is not None else obj
    return build(0, 0)[1] or {}

def project_root_for(path):
    p = os.path.abspath(os.path.dirname(path) or ".")
    cur = p
    while True:
        if any(os.path.exists(os.path.join(cur, x)) for x in ("go.mod", "package.json", "pyproject.toml", "Cargo.toml")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    cur = os.getcwd()
    while True:
        if os.path.isdir(os.path.join(cur, ".git")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            return os.getcwd()
        cur = parent

def rel(path, root):
    try:
        return os.path.relpath(os.path.abspath(path), root).replace(os.sep, "/")
    except ValueError:
        return os.path.abspath(path).replace(os.sep, "/")

def candidates(base, spec, exts):
    out = []
    if spec.startswith("."):
        p = os.path.normpath(os.path.join(os.path.dirname(base), spec))
        out.append(p)
        for e in exts:
            out.append(p + e)
        for e in exts:
            out.append(os.path.join(p, "index" + e))
    return out

def py_module_paths(base, mod):
    parts = mod.split(".")
    roots = [os.path.dirname(base), os.getcwd(), project_root_for(base)]
    out = []
    for r in roots:
        p = os.path.join(r, *parts)
        out.append(p + ".py")
        out.append(os.path.join(p, "__init__.py"))
    return out

def first_file(paths):
    for p in paths:
        if os.path.isfile(p):
            return os.path.abspath(p)
    return None

def parse_deps(path, opts):
    ext = os.path.splitext(path)[1].lower()
    try:
        txt = open(path, encoding="utf-8").read()
    except UnicodeDecodeError:
        txt = open(path, errors="ignore").read()
    deps = []
    if ext in (".py",):
        exclude_cond = opts.get("python_exclude_conditional_imports", False)
        for line in txt.splitlines():
            raw = line
            s = line.strip()
            if not s or s.startswith("#"):
                continue
            if exclude_cond and (len(raw) - len(raw.lstrip(" ")) > 0):
                continue
            m = re.match(r"import\s+([A-Za-z_][\w.]*)", s)
            if m:
                f = first_file(py_module_paths(path, m.group(1)))
                if f: deps.append(f)
            m = re.match(r"from\s+([.\w]+)\s+import\s+(.+)", s)
            if m:
                mod, names = m.group(1), m.group(2)
                if mod.startswith("."):
                    dots = len(mod) - len(mod.lstrip("."))
                    rest = mod[dots:]
                    d = os.path.dirname(path)
                    for _ in range(max(0, dots - 1)):
                        d = os.path.dirname(d)
                    if rest:
                        base = os.path.join(d, *rest.split("."))
                        f = first_file([base + ".py", os.path.join(base, "__init__.py")])
                        if f: deps.append(f)
                    else:
                        for name in [x.strip().split()[0] for x in names.split(",")]:
                            f = first_file([os.path.join(d, name + ".py"), os.path.join(d, name, "__init__.py")])
                            if f: deps.append(f)
                else:
                    f = None
                    for name in [x.strip().split()[0] for x in names.split(",")]:
                        if name != "*":
                            f = first_file(py_module_paths(path, mod + "." + name))
                            if f: break
                    if not f:
                        f = first_file(py_module_paths(path, mod))
                    if f: deps.append(f)
    elif ext in (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"):
        specs = re.findall(r"(?:import|export)\s+(?:[^'\"]*?\s+from\s+)?['\"]([^'\"]+)['\"]", txt)
        specs += re.findall(r"require\(\s*['\"]([^'\"]+)['\"]\s*\)", txt)
        for spec in specs:
            f = first_file(candidates(path, spec, [".ts", ".tsx", ".js", ".jsx", ".mjs", ".cjs"]))
            if f: deps.append(f)
    elif ext == ".go":
        specs = []
        for block in re.findall(r"import\s*\((.*?)\)", txt, flags=re.S):
            specs += re.findall(r'"([^"]+)"', block)
        specs += re.findall(r'import\s+(?:\w+\s+)?\"([^\"]+)\"', txt)
        root = project_root_for(path)
        mod = ""
        gomod = os.path.join(root, "go.mod")
        if os.path.exists(gomod):
            mm = re.search(r"^module\s+(\S+)", open(gomod, encoding="utf-8").read(), re.M)
            if mm: mod = mm.group(1)
        for spec in specs:
            if mod and spec.startswith(mod):
                sub = spec[len(mod):].lstrip("/")
                d = os.path.join(root, sub)
                files = sorted(glob.glob(os.path.join(d, "*.go")))
                if files: deps.append(os.path.abspath(files[0]))
            elif spec.startswith("./") or spec.startswith("../"):
                d = os.path.normpath(os.path.join(os.path.dirname(path), spec))
                files = sorted(glob.glob(os.path.join(d, "*.go")))
                if files: deps.append(os.path.abspath(files[0]))
    elif ext == ".rs":
        for m in re.finditer(r"\bmod\s+([A-Za-z_]\w*)\s*;", txt):
            name = m.group(1)
            f = first_file([os.path.join(os.path.dirname(path), name + ".rs"), os.path.join(os.path.dirname(path), name, "mod.rs")])
            if f: deps.append(f)
    seen, res = set(), []
    for d in deps:
        if d != os.path.abspath(path) and d not in seen:
            seen.add(d); res.append(d)
    return res

def filtered(path, root, opts):
    r = rel(path, root)
    only = opts.get("only") or []
    excl = opts.get("exclude") or []
    if only and not any(fnmatch.fnmatch(r, p) for p in only):
        return True
    if any(fnmatch.fnmatch(r, p) for p in excl):
        return True
    return False

def build_graph(entries, opts):
    abs_entries = [os.path.abspath(e) for e in entries]
    root = project_root_for(abs_entries[0]) if abs_entries else os.getcwd()
    graph, errors = OrderedDict(), {}
    visiting, visited, cycles = [], set(), []
    def dfs(p):
        p = os.path.abspath(p)
        if not os.path.exists(p):
            errors[rel(p, root)] = "file does not exist"; return
        if filtered(p, root, opts):
            return
        if p in visiting:
            cyc = visiting[visiting.index(p):] + [p]
            cycles.append([rel(x, root) for x in cyc])
            return
        if p in visited:
            return
        visiting.append(p)
        deps = [d for d in parse_deps(p, opts) if not filtered(d, root, opts)]
        graph[p] = deps
        for d in deps:
            dfs(d)
        visiting.pop(); visited.add(p)
    for e in abs_entries:
        dfs(e)
    return root, graph, cycles, errors

def nested_tree(p, graph, root, seen=None):
    if seen is None: seen = set()
    if p in seen:
        return None
    seen.add(p)
    deps = graph.get(p, [])
    if not deps:
        return None
    od = OrderedDict()
    for d in sorted(deps, key=lambda x: rel(x, root)):
        od[rel(d, root)] = nested_tree(d, graph, root, set(seen))
    return od

def cmd_tree(args, opts):
    entries = args.entries
    if not entries:
        print("Error: accepts 1 arg(s), received 0", file=sys.stderr); return 1
    root, graph, cycles, errors = build_graph(entries, opts)
    if args.json:
        t = OrderedDict()
        for e in entries:
            ae = os.path.abspath(e)
            t[rel(ae, root)] = nested_tree(ae, graph, root)
        print(json.dumps({"tree": t, "circularDependencies": cycles, "errors": errors}, indent=2))
    else:
        def show(p, pref=""):
            print(pref + rel(p, root))
            for d in sorted(graph.get(p, []), key=lambda x: rel(x, root)):
                show(d, pref + "  ")
        for e in entries:
            show(os.path.abspath(e))
    return 0

def expand_pattern(pat):
    matches = glob.glob(pat, recursive=True)
    return sorted(os.path.abspath(m) for m in matches if os.path.isfile(m))

def cmd_explain(args, opts):
    left, right = expand_pattern(args.left), expand_pattern(args.right)
    if not left:
        print(f"Error: {args.left} does not match with any existing file", file=sys.stderr); return 1
    if not right:
        print(f"Error: {args.right} does not match with any existing file", file=sys.stderr); return 1
    if args.overlap_left:
        rs = set(right) - set(left); right = sorted(rs)
    if args.overlap_right:
        ls = set(left) - set(right); left = sorted(ls)
    root = project_root_for(left[0])
    rightset = set(right)
    for l in left:
        for d in parse_deps(l, opts):
            if d in rightset:
                print(f"{rel(l, root)} -> {rel(d, root)}")
    return 0

def norm_rule(v):
    if isinstance(v, dict):
        return v.get("to", []), v.get("reason")
    if isinstance(v, list):
        return v, None
    return [], None

def expand_alias(patterns, aliases):
    out = []
    for p in patterns:
        if isinstance(p, dict):
            p = p.get("to", "")
        if p in aliases:
            out += aliases[p]
        else:
            out.append(p)
    return out

def cmd_check(args, opts):
    cfg = parse_simple_yaml(args.config)
    check = cfg.get("check", {}) if isinstance(cfg, dict) else {}
    entries = check.get("entrypoints") or []
    if not entries:
        print("Error: no entrypoints defined in config", file=sys.stderr); return 1
    root, graph, cycles, errors = build_graph(entries, opts)
    rule_root = os.getcwd()
    aliases = check.get("aliases") or {}
    violations = []
    allow = check.get("allow") or {}
    deny = check.get("deny") or {}
    for src, deps in graph.items():
        sr = rel(src, rule_root)
        for pat, val in allow.items():
            pats, reason = norm_rule(val)
            pats = expand_alias(pats, aliases)
            if fnmatch.fnmatch(sr, pat):
                for d in deps:
                    dr = rel(d, rule_root)
                    if not any(fnmatch.fnmatch(dr, p) for p in pats):
                        violations.append((sr, dr, reason))
        for pat, val in deny.items():
            rules = val if isinstance(val, list) else []
            if fnmatch.fnmatch(sr, pat):
                for rule in rules:
                    reason = None
                    pats = [rule]
                    if isinstance(rule, dict):
                        pats = [rule.get("to", "")]
                        reason = rule.get("reason")
                    pats = expand_alias(pats, aliases)
                    for d in deps:
                        dr = rel(d, rule_root)
                        if any(fnmatch.fnmatch(dr, p) for p in pats):
                            violations.append((sr, dr, reason))
    if cycles and not check.get("allowCircularDependencies", False):
        for cyc in cycles:
            violations.append((" -> ".join(cyc[:-1]), cyc[-1], "circular dependency"))
    if violations:
        print("Error: Check failed, the following dependencies are not allowed:", file=sys.stderr)
        for s, d, reason in violations:
            print(f"- {s} -> {d}" + (f": {reason}" if reason else ""), file=sys.stderr)
        return 1
    return 0

def load_opts(ns):
    cfg = parse_simple_yaml(getattr(ns, "config", ".dep-tree.yml"))
    opts = {}
    if isinstance(cfg, dict):
        opts["only"] = list(cfg.get("only") or [])
        opts["exclude"] = list(cfg.get("exclude") or [])
        py = cfg.get("python") or {}
        if isinstance(py, dict):
            opts["python_exclude_conditional_imports"] = bool(py.get("excludeConditionalImports", False))
    opts["only"] = opts.get("only", []) + (getattr(ns, "only", None) or [])
    opts["exclude"] = opts.get("exclude", []) + (getattr(ns, "exclude", None) or [])
    if getattr(ns, "python_exclude_conditional_imports", False):
        opts["python_exclude_conditional_imports"] = True
    return opts

def add_globals(p):
    p.add_argument("-c", "--config", default=".dep-tree.yml")
    p.add_argument("--unwrap-exports", action="store_true")
    p.add_argument("--js-tsconfig-paths", action="store_true", default=True)
    p.add_argument("--js-workspaces", action="store_true", default=True)
    p.add_argument("--python-exclude-conditional-imports", action="store_true")
    p.add_argument("--only", action="append")
    p.add_argument("--exclude", action="append")

def main(argv):
    if not argv or argv[0] in ("--help", "-h", "help"):
        if len(argv) >= 2 and argv[0] == "help" and argv[1] in CMD_HELP:
            print(CMD_HELP[argv[1]] + GLOBAL_HELP); return 0
        print(HELP); return 0
    if argv[0] in ("--version", "-v"):
        print(VERSION); return 0
    if argv[0] == "version":
        print("Error: version does not match with any existing file", file=sys.stderr); return 1
    cmd = argv[0]
    if cmd not in ("tree", "explain", "check", "config", "init", "entropy"):
        if os.path.exists(cmd):
            argv = ["entropy"] + argv
            cmd = "entropy"
        else:
            print(f"Error: {cmd} does not match with any existing file", file=sys.stderr); return 1
    if "--help" in argv or "-h" in argv:
        print(CMD_HELP["config" if cmd == "init" else cmd] + GLOBAL_HELP); return 0
    if cmd in ("config", "init"):
        ap = argparse.ArgumentParser(add_help=False); add_globals(ap)
        ns, _ = ap.parse_known_args(argv[1:])
        if os.path.exists(ns.config):
            print(f"Error: cannot generate config file, as one already exists in {ns.config}", file=sys.stderr); return 1
        with open(ns.config, "w", encoding="utf-8") as f:
            f.write(DEFAULT_CONFIG)
        os.chmod(ns.config, 0o600)
        return 0
    if cmd == "tree":
        ap = argparse.ArgumentParser(add_help=False); add_globals(ap)
        ap.add_argument("--json", action="store_true"); ap.add_argument("entries", nargs="*")
        ns = ap.parse_args(argv[1:]); return cmd_tree(ns, load_opts(ns))
    if cmd == "explain":
        ap = argparse.ArgumentParser(add_help=False); add_globals(ap)
        ap.add_argument("-l", "--overlap-left", action="store_true"); ap.add_argument("-r", "--overlap-right", action="store_true")
        ap.add_argument("left"); ap.add_argument("right")
        ns = ap.parse_args(argv[1:]); return cmd_explain(ns, load_opts(ns))
    if cmd == "check":
        ap = argparse.ArgumentParser(add_help=False); add_globals(ap)
        ns = ap.parse_args(argv[1:]); return cmd_check(ns, load_opts(ns))
    if cmd == "entropy":
        ap = argparse.ArgumentParser(add_help=False); add_globals(ap)
        ap.add_argument("--enable-gui", action="store_true"); ap.add_argument("--no-browser-open", action="store_true")
        ap.add_argument("--render-path", default="dep-tree.html"); ap.add_argument("entries", nargs="*")
        ns = ap.parse_args(argv[1:])
        root, graph, cycles, errors = build_graph(ns.entries, load_opts(ns)) if ns.entries else (os.getcwd(), {}, [], {})
        nodes = sorted({rel(k, root) for k in graph} | {rel(d, root) for v in graph.values() for d in v})
        links = [(rel(s, root), rel(d, root)) for s, ds in graph.items() for d in ds]
        html = "<html><body><h1>dep-tree</h1><script>var nodes=%s;var links=%s;</script></body></html>" % (json.dumps(nodes), json.dumps(links))
        with open(ns.render_path, "w", encoding="utf-8") as f: f.write(html)
        print(ns.render_path)
        return 0
    return 1

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
