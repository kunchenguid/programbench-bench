#define _XOPEN_SOURCE 700

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <termios.h>
#include <unistd.h>

static const char *HELP_TEXT =
    "A simple terminal UI for search and replace, ala VS Code\n"
    "\n"
    "Usage: executable [OPTIONS]\n"
    "\n"
    "Options:\n"
    "  -p, --project-root <PATH>  Path to the project root [default: .]\n"
    "  -h, --help                 Print help\n"
    "  -V, --version              Print version\n";

static void print_version(void) {
    const char *xdg = getenv("XDG_CONFIG_HOME");
    const char *home = getenv("HOME");
    char config[PATH_MAX];

    if (xdg && *xdg) {
        snprintf(config, sizeof(config), "%s/serpl", xdg);
    } else if (home && *home) {
        snprintf(config, sizeof(config), "%s/.config/serpl", home);
    } else {
        snprintf(config, sizeof(config), ".config/serpl");
    }

    printf("serpl 0.3.4- (2026-04-20)\n\n");
    printf("Authors: Yassine Bridi <ybridi@gmail.com>\n\n");
    printf("Config directory: %s\n", config);
}

static int clap_error(const char *msg) {
    fprintf(stderr, "error: %s\n\n", msg);
    fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int value_required(const char *flag) {
    fprintf(stderr, "error: a value is required for '%s <PATH>' but none was supplied\n\n", flag);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

struct app_args {
    const char *project_root;
};

static int parse_args(int argc, char **argv, struct app_args *args, int *handled) {
    int seen_project_root = 0;
    args->project_root = ".";
    *handled = 0;

    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];

        if (strcmp(arg, "-h") == 0 || strcmp(arg, "--help") == 0) {
            fputs(HELP_TEXT, stdout);
            *handled = 1;
            return 0;
        }
        if (strcmp(arg, "-V") == 0 || strcmp(arg, "--version") == 0) {
            print_version();
            *handled = 1;
            return 0;
        }

        if (strcmp(arg, "-p") == 0 || strcmp(arg, "--project-root") == 0) {
            if (seen_project_root) {
                return clap_error("the argument '--project-root <PATH>' cannot be used multiple times");
            }
            if (i + 1 >= argc || argv[i + 1][0] == '-') {
                return value_required(strcmp(arg, "-p") == 0 ? "--project-root" : "--project-root");
            }
            args->project_root = argv[++i];
            seen_project_root = 1;
            continue;
        }

        if (strncmp(arg, "--project-root=", 15) == 0) {
            if (seen_project_root) {
                return clap_error("the argument '--project-root <PATH>' cannot be used multiple times");
            }
            if (arg[15] == '\0') {
                return value_required("--project-root");
            }
            args->project_root = arg + 15;
            seen_project_root = 1;
            continue;
        }

        if (strncmp(arg, "-p", 2) == 0 && arg[2] != '\0') {
            if (seen_project_root) {
                return clap_error("the argument '--project-root <PATH>' cannot be used multiple times");
            }
            args->project_root = arg + 2;
            seen_project_root = 1;
            continue;
        }

        {
            char msg[512];
            snprintf(msg, sizeof(msg), "unexpected argument '%s' found", arg);
            return clap_error(msg);
        }
    }

    return 0;
}

static int contains_bytes(const unsigned char *buf, size_t len, const char *needle) {
    size_t nlen = strlen(needle);
    if (nlen == 0 || len < nlen) return 0;
    for (size_t i = 0; i + nlen <= len; i++) {
        if (memcmp(buf + i, needle, nlen) == 0) return 1;
    }
    return 0;
}

static void search_file(const char *path, const char *needle, int *count) {
    FILE *f = fopen(path, "rb");
    if (!f) return;
    unsigned char buf[8192];
    size_t n = fread(buf, 1, sizeof(buf), f);
    if (memchr(buf, '\0', n)) {
        fclose(f);
        return;
    }
    fseek(f, 0, SEEK_SET);

    char *line = NULL;
    size_t cap = 0;
    ssize_t got;
    int line_no = 1;
    while ((got = getline(&line, &cap, f)) != -1) {
        if (contains_bytes((unsigned char *)line, (size_t)got, needle)) {
            printf("\033[%d;27H\033[38;5;15m%-50.50s\033[39m", 8 + (*count % 14), path);
            (*count)++;
        }
        line_no++;
        if (*count >= 14) break;
    }
    free(line);
    fclose(f);
}

static void search_tree(const char *root, const char *needle, int *count, int depth) {
    if (depth > 8 || *count >= 14) return;
    DIR *dir = opendir(root);
    if (!dir) return;

    struct dirent *ent;
    while ((ent = readdir(dir)) != NULL && *count < 14) {
        if (strcmp(ent->d_name, ".") == 0 || strcmp(ent->d_name, "..") == 0) continue;
        if (strcmp(ent->d_name, ".git") == 0) continue;

        char path[PATH_MAX];
        snprintf(path, sizeof(path), "%s/%s", root, ent->d_name);

        struct stat st;
        if (stat(path, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) {
            search_tree(path, needle, count, depth + 1);
        } else if (S_ISREG(st.st_mode)) {
            search_file(path, needle, count);
        }
    }
    closedir(dir);
}

static void draw_screen(const char *search, const char *replace, int mode, const char *root) {
    (void)replace;
    printf("\033[?1049h\033[?25l\033[1;1H\033[2J");
    printf("\033[1;1H\033[1m\033[38;5;2m╭Search────────[%s]╮\033[22m\033[39m", mode ? "Regex " : "Simple");
    printf("\033[2;1H\033[1m\033[38;5;2m│\033[22m\033[38;5;15m%-22.22s\033[1m\033[38;5;2m│\033[22m\033[39m", search);
    printf("\033[3;1H\033[1m\033[38;5;2m╰──────────────────────╯\033[22m\033[39m");
    printf("\033[4;1H\033[38;5;15m╭Replace───────[Simple]╮");
    printf("\033[5;1H│                      │");
    printf("\033[6;1H╰──────────────────────╯");
    printf("\033[7;1H╭Result List───────────╮");
    for (int r = 8; r <= 22; r++) printf("\033[%d;1H│                      │", r);
    printf("\033[23;1H╰──────────────────────╯");
    printf("\033[1;26H╭Preview───────────────────────────────────────────────╮");
    for (int r = 2; r <= 22; r++) printf("\033[%d;26H│\033[%d;80H│", r, r);
    printf("\033[23;26H╰──────────────────────────────────────────────────────╯");
    printf("\033[24;1H\033[38;5;4mHelp: <Ctrl-b> | Search: <Enter> | Toggle search mode: <Ctrl-r>\033[39m");

    if (search[0]) {
        int count = 0;
        search_tree(root, search, &count, 0);
        if (count == 0) printf("\033[8;3H\033[38;5;15mNo results\033[39m");
    }
    printf("\033[2;2H\033[?25h");
    fflush(stdout);
}

static int run_tui(const char *root) {
    if (!isatty(STDIN_FILENO) || !isatty(STDOUT_FILENO)) {
        fprintf(stderr, "serpl error: Something went wrong\n");
        fprintf(stderr, "Error: \n");
        fprintf(stderr, "   0: \033[91mResource temporarily unavailable (os error 11)\033[0m\n");
        return 1;
    }

    struct termios oldt, raw;
    if (tcgetattr(STDIN_FILENO, &oldt) != 0) return 1;
    raw = oldt;
    raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &raw);

    char search[256] = "";
    int mode = 0;
    draw_screen(search, "", mode, root);

    for (;;) {
        unsigned char ch;
        if (read(STDIN_FILENO, &ch, 1) != 1) break;
        if (ch == 3 || ch == 4 || ch == 'q') break;
        if (ch == 18) mode = !mode;
        if (ch == 127 || ch == 8) {
            size_t len = strlen(search);
            if (len) search[len - 1] = '\0';
        } else if (isprint(ch) && strlen(search) + 1 < sizeof(search)) {
            size_t len = strlen(search);
            search[len] = (char)ch;
            search[len + 1] = '\0';
        }
        draw_screen(search, "", mode, root);
    }

    printf("\033[1;1H\033[2J\033[?1049l\033[?25h");
    fflush(stdout);
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    return 0;
}

int main(int argc, char **argv) {
    struct app_args args;
    int handled = 0;
    int rc = parse_args(argc, argv, &args, &handled);
    if (rc != 0 || handled) return rc;
    return run_tui(args.project_root);
}
