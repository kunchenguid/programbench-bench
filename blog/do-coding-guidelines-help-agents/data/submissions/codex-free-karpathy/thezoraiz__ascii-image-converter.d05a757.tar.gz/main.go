package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/gif"
	_ "image/gif"
	"image/jpeg"
	_ "image/jpeg"
	"image/png"
	_ "image/png"
	"io"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const helpText = `This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
                          If 24-bit colors aren't supported, uses 8-bit
                          (Inverts with --negative flag)
                          (Overrides --grayscale and --font-color flags)
                          
      --color-bg          If some color flag is passed, use that color
                          on character background instead of foreground
                          (Inverts with --negative flag)
                          (Only applicable for terminal display)
                          
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                          e.g. -d 60,30 (defaults to terminal height)
                          (Overrides --width and --height flags)
                          
  -W, --width int         Set width for ascii art in CHARACTER length
                          Height is kept to aspect ratio
                          e.g. -W 60
                          
  -H, --height int        Set height for ascii art in CHARACTER length
                          Width is kept to aspect ratio
                          e.g. -H 60
                          
  -m, --map string        Give custom ascii characters to map against
                          Ordered from darkest to lightest
                          e.g. -m " .-+#@" (Quotation marks excluded from map)
                          (Overrides --complex flag)
                          
  -b, --braille           Use braille characters instead of ascii
                          Terminal must support braille patterns properly
                          (Overrides --complex and --map flags)
                          
      --threshold int     Threshold for braille art
                          Value between 0-255 is accepted
                          e.g. --threshold 170
                          (Defaults to 128)
                          
      --dither            Apply dithering on image for braille
                          art conversion
                          (Only applicable with --braille flag)
                          (Negates --threshold flag)
                          
  -g, --grayscale         Display grayscale ascii art
                          (Inverts with --negative flag)
                          (Overrides --font-color flag)
                          
  -c, --complex           Display ascii characters in a larger range
                          May result in higher quality
                          
  -f, --full              Use largest dimensions for ascii art
                          that fill the terminal width
                          (Overrides --dimensions, --width and --height flags)
                          
  -n, --negative          Display ascii art in negative colors
                          
  -x, --flipX             Flip ascii art horizontally
                          
  -y, --flipY             Flip ascii art vertically
                          
  -s, --save-img string   Save ascii art as a .png file
                          Format: <image-name>-ascii-art.png
                          Image will be saved in passed path
                          (pass . for current directory)
                          
      --save-txt string   Save ascii art as a .txt file
                          Format: <image-name>-ascii-art.txt
                          File will be saved in passed path
                          (pass . for current directory)
                          
      --save-gif string   If input is a gif, save it as a .gif file
                          Format: <gif-name>-ascii-art.gif
                          Gif will be saved in passed path
                          (pass . for current directory)
                          
      --save-bg ints      Set background color for --save-img
                          and --save-gif flags
                          Pass an RGBA value
                          e.g. --save-bg 255,255,255,100
                          (Defaults to 0,0,0,100)
                          
      --font string       Set font for --save-img and --save-gif flags
                          Pass file path to font .ttf file
                          e.g. --font ./RobotoMono-Regular.ttf
                          (Defaults to Hack-Regular for ascii and
                           DejaVuSans-Oblique for braille)
                          
      --font-color ints   Set font color for terminal as well as
                          --save-img and --save-gif flags
                          Pass an RGB value
                          e.g. --font-color 0,0,0
                          (Defaults to 255,255,255)
                          
      --only-save         Don't print ascii art on terminal
                          if some saving flag is passed
                          
      --formats           Display supported input formats
                          
  -h, --help              Help for ascii-image-converter
                          
  -v, --version           Version for ascii-image-converter

Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
Distributed under the Apache License Version 2.0 (Apache-2.0)
For further details, visit https://github.com/TheZoraiz/ascii-image-converter`

type opts struct {
	width, height      int
	dimSet             bool
	customMap          string
	complex, braille   bool
	negative           bool
	flipX, flipY       bool
	threshold          int
	saveTxt, saveImg   string
	saveGif            string
	onlySave           bool
	color, gray, fontc bool
	colorBG            bool
	paths              []string
}

func main() {
	image.RegisterFormat("bmp", "BM", decodeBMP, decodeBMPConfig)
	o := opts{threshold: 128}
	if err := parse(os.Args[1:], &o); err != nil {
		fmt.Fprintln(os.Stderr, err.Error())
		if strings.Contains(err.Error(), "unknown flag") || strings.Contains(err.Error(), "invalid argument") {
			fmt.Fprintln(os.Stderr, "Usage:")
			fmt.Fprintln(os.Stderr, "  ascii-image-converter [image paths/urls or piped stdin] [flags]")
			fmt.Fprintln(os.Stderr)
			fmt.Fprintln(os.Stderr, "Flags:")
			fmt.Fprintln(os.Stderr, "  -C, --color             Display ascii art with original colors")
		}
		os.Exit(1)
	}
	if len(o.paths) == 0 && stdinIsTerminal() {
		fmt.Fprintln(os.Stderr, "Error: Need at least 1 input path/url or piped input")
		fmt.Fprintln(os.Stderr, "Use the -h flag for more info")
		fmt.Fprintln(os.Stderr)
		os.Exit(1)
	}
	if o.color || o.gray || o.fontc {
		fmt.Fprintln(os.Stderr, "Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available")
		fmt.Fprintln(os.Stderr)
		os.Exit(1)
	}
	if len(o.paths) == 0 {
		data, _ := io.ReadAll(os.Stdin)
		if err := handle(bytes.NewReader(data), "stdin", &o); err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
		return
	}
	for _, p := range o.paths {
		f, err := os.Open(p)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: unable to open file: open %s: %s\n\n", p, err.Error())
			os.Exit(1)
		}
		err = handle(f, p, &o)
		f.Close()
		if err != nil {
			fmt.Fprintln(os.Stderr, err)
			os.Exit(1)
		}
	}
}

func parse(args []string, o *opts) error {
	for i := 0; i < len(args); i++ {
		a := args[i]
		val := func() (string, error) {
			if i+1 >= len(args) {
				return "", fmt.Errorf("Error: flag needs an argument: %s", a)
			}
			i++
			return args[i], nil
		}
		switch a {
		case "-h", "--help":
			fmt.Println(helpText)
			os.Exit(0)
		case "-v", "--version":
			fmt.Println("v1.13.1")
			os.Exit(0)
		case "--formats":
			fmt.Println("Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF")
			os.Exit(0)
		case "-C", "--color":
			o.color = true
		case "--color-bg":
			o.colorBG = true
		case "-g", "--grayscale":
			o.gray = true
		case "-c", "--complex":
			o.complex = true
		case "-b", "--braille":
			o.braille = true
		case "--dither":
		case "-n", "--negative":
			o.negative = true
		case "-x", "--flipX":
			o.flipX = true
		case "-y", "--flipY":
			o.flipY = true
		case "-f", "--full":
			o.width = 80
		case "--only-save":
			o.onlySave = true
		case "-d", "--dimensions":
			s, e := val()
			if e != nil {
				return e
			}
			parts := strings.Split(s, ",")
			if len(parts) >= 1 {
				n, err := strconv.Atoi(parts[0])
				if err != nil {
					return fmt.Errorf("Error: invalid argument %q for \"-d, --dimensions\" flag: %v", s, err)
				}
				o.width = n
			}
			if len(parts) >= 2 {
				n, err := strconv.Atoi(parts[1])
				if err != nil {
					return fmt.Errorf("Error: invalid argument %q for \"-d, --dimensions\" flag: %v", s, err)
				}
				o.height = n
			}
			o.dimSet = true
		case "-W", "--width":
			s, e := val()
			if e != nil {
				return e
			}
			n, err := strconv.Atoi(s)
			if err != nil {
				return fmt.Errorf("Error: invalid argument %q for \"-W, --width\" flag: %v", s, err)
			}
			o.width = n
		case "-H", "--height":
			s, e := val()
			if e != nil {
				return e
			}
			n, err := strconv.Atoi(s)
			if err != nil {
				return fmt.Errorf("Error: invalid argument %q for \"-H, --height\" flag: %v", s, err)
			}
			o.height = n
		case "-m", "--map":
			s, e := val()
			if e != nil {
				return e
			}
			o.customMap = s
		case "--threshold":
			s, e := val()
			if e != nil {
				return e
			}
			n, err := strconv.Atoi(s)
			if err != nil {
				return fmt.Errorf("Error: invalid argument %q for \"--threshold\" flag: %v", s, err)
			}
			if n < 0 || n > 255 {
				return fmt.Errorf("Error: threshold must be between 0 and 255\n")
			}
			o.threshold = n
		case "-s", "--save-img":
			s, e := val()
			if e != nil {
				return e
			}
			o.saveImg = s
		case "--save-txt":
			s, e := val()
			if e != nil {
				return e
			}
			o.saveTxt = s
		case "--save-gif":
			s, e := val()
			if e != nil {
				return e
			}
			o.saveGif = s
		case "--font", "--font-color", "--save-bg":
			_, e := val()
			if e != nil {
				return e
			}
			if a == "--font-color" {
				o.fontc = true
			}
		default:
			if strings.HasPrefix(a, "-") {
				return fmt.Errorf("Error: unknown flag: %s", a)
			}
			o.paths = append(o.paths, a)
		}
	}
	return nil
}

func stdinIsTerminal() bool {
	st, err := os.Stdin.Stat()
	return err != nil || (st.Mode()&os.ModeCharDevice) != 0
}

func handle(r io.Reader, name string, o *opts) error {
	img, format, err := image.Decode(r)
	if err != nil {
		return fmt.Errorf("Error: %v\n", err)
	}
	_ = format
	art := convert(img, o)
	if o.saveTxt != "" {
		if err := os.MkdirAll(o.saveTxt, 0755); err != nil {
			return err
		}
		path := filepath.Join(o.saveTxt, base(name)+"-ascii-art.txt")
		if err := os.WriteFile(path, []byte(strings.Join(art, "\n")), 0644); err != nil {
			return err
		}
		if o.onlySave {
			fmt.Println("Saved " + path)
		}
	}
	if o.saveImg != "" {
		if err := os.MkdirAll(o.saveImg, 0755); err != nil {
			return err
		}
		path := filepath.Join(o.saveImg, base(name)+"-ascii-art.png")
		if err := savePNG(path, art); err != nil {
			return err
		}
	}
	if o.saveGif != "" {
		if err := os.MkdirAll(o.saveGif, 0755); err != nil {
			return err
		}
		path := filepath.Join(o.saveGif, base(name)+"-ascii-art.gif")
		if err := saveGIF(path, art); err != nil {
			return err
		}
	}
	if !(o.onlySave && (o.saveTxt != "" || o.saveImg != "" || o.saveGif != "")) {
		fmt.Print(strings.Join(art, "\n"))
		if len(art) > 0 {
			fmt.Println()
		}
	}
	return nil
}

func base(p string) string {
	b := filepath.Base(p)
	ext := filepath.Ext(b)
	if ext != "" {
		b = strings.TrimSuffix(b, ext)
	}
	if b == "" || b == "." {
		return "stdin"
	}
	return b
}

func convert(img image.Image, o *opts) []string {
	b := img.Bounds()
	sw, sh := b.Dx(), b.Dy()
	w, h := o.width, o.height
	if w <= 0 && h <= 0 {
		w = 80
	}
	if w <= 0 {
		w = int(math.Max(1, math.Round(float64(h)*float64(sw)/float64(sh)*2)))
	}
	if h <= 0 {
		ratio := 0.5
		if o.braille {
			ratio = 0.25
		}
		h = int(math.Max(1, math.Round(float64(w)*float64(sh)/float64(sw)*ratio)))
	}
	if w < 1 {
		w = 1
	}
	if h < 1 {
		h = 1
	}
	if o.braille {
		return braille(img, w, h, o)
	}
	chars := []rune(" .:-=+*#%@")
	if o.complex {
		chars = []rune(" .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$")
	}
	if o.customMap != "" {
		chars = []rune(o.customMap)
	}
	if len(chars) == 0 {
		chars = []rune(" ")
	}
	lines := make([]string, h)
	for y := 0; y < h; y++ {
		var sb strings.Builder
		for x := 0; x < w; x++ {
			sx := b.Min.X + int((float64(x)+0.5)*float64(sw)/float64(w))
			sy := b.Min.Y + int((float64(y)+0.5)*float64(sh)/float64(h))
			if sx >= b.Max.X {
				sx = b.Max.X - 1
			}
			if sy >= b.Max.Y {
				sy = b.Max.Y - 1
			}
			l := lum(img.At(sx, sy))
			if o.negative {
				l = 255 - l
			}
			idx := int(float64(l) / 256.0 * float64(len(chars)))
			if idx >= len(chars) {
				idx = len(chars) - 1
			}
			sb.WriteRune(chars[idx])
		}
		lines[y] = sb.String()
	}
	flip(lines, o.flipX, o.flipY)
	return lines
}

func braille(img image.Image, w, h int, o *opts) []string {
	b := img.Bounds()
	sw, sh := b.Dx(), b.Dy()
	dots := [8]int{0x01, 0x02, 0x04, 0x40, 0x08, 0x10, 0x20, 0x80}
	lines := make([]string, h)
	for y := 0; y < h; y++ {
		var sb strings.Builder
		for x := 0; x < w; x++ {
			mask := 0
			for dy := 0; dy < 4; dy++ {
				for dx := 0; dx < 2; dx++ {
					sx := b.Min.X + int((float64(x*2+dx)+0.5)*float64(sw)/float64(w*2))
					sy := b.Min.Y + int((float64(y*4+dy)+0.5)*float64(sh)/float64(h*4))
					if sx >= b.Max.X {
						sx = b.Max.X - 1
					}
					if sy >= b.Max.Y {
						sy = b.Max.Y - 1
					}
					l := lum(img.At(sx, sy))
					if o.negative {
						l = 255 - l
					}
					if l >= o.threshold {
						mask |= dots[dy+dx*4]
					}
				}
			}
			sb.WriteRune(rune(0x2800 + mask))
		}
		lines[y] = sb.String()
	}
	flip(lines, o.flipX, o.flipY)
	return lines
}

func flip(lines []string, fx, fy bool) {
	if fx {
		for i, s := range lines {
			r := []rune(s)
			for l, h := 0, len(r)-1; l < h; l, h = l+1, h-1 {
				r[l], r[h] = r[h], r[l]
			}
			lines[i] = string(r)
		}
	}
	if fy {
		for l, h := 0, len(lines)-1; l < h; l, h = l+1, h-1 {
			lines[l], lines[h] = lines[h], lines[l]
		}
	}
}

func lum(c color.Color) int {
	r, g, b, _ := c.RGBA()
	return int((299*r + 587*g + 114*b) / 1000 / 257)
}

func savePNG(path string, lines []string) error {
	w, h := 1, len(lines)
	for _, s := range lines {
		if n := len([]rune(s)); n > w {
			w = n
		}
	}
	cellW, cellH := 8, 12
	img := image.NewRGBA(image.Rect(0, 0, w*cellW, max(1, h)*cellH))
	draw.Draw(img, img.Bounds(), &image.Uniform{color.RGBA{0, 0, 0, 100}}, image.Point{}, draw.Src)
	for y, s := range lines {
		for x, r := range []rune(s) {
			if r != ' ' && r != 0x2800 {
				draw.Draw(img, image.Rect(x*cellW+2, y*cellH+2, x*cellW+6, y*cellH+10), &image.Uniform{color.White}, image.Point{}, draw.Src)
			}
		}
	}
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	return png.Encode(f, img)
}

func saveGIF(path string, lines []string) error {
	w, h := 1, max(1, len(lines))
	img := image.NewPaletted(image.Rect(0, 0, w, h), []color.Color{color.Black, color.White})
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	return gif.Encode(f, img, nil)
}

func max(a, b int) int {
	if a > b {
		return a
	}
	return b
}

var _ = jpeg.DefaultQuality

func decodeBMPConfig(r io.Reader) (image.Config, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return image.Config{}, err
	}
	img, err := parseBMP(data)
	if err != nil {
		return image.Config{}, err
	}
	return image.Config{ColorModel: color.RGBAModel, Width: img.Bounds().Dx(), Height: img.Bounds().Dy()}, nil
}

func decodeBMP(r io.Reader) (image.Image, error) {
	data, err := io.ReadAll(r)
	if err != nil {
		return nil, err
	}
	return parseBMP(data)
}

func parseBMP(data []byte) (image.Image, error) {
	if len(data) < 54 || string(data[:2]) != "BM" {
		return nil, fmt.Errorf("invalid BMP")
	}
	off := int(binary.LittleEndian.Uint32(data[10:14]))
	header := int(binary.LittleEndian.Uint32(data[14:18]))
	if header < 40 || len(data) < 14+header {
		return nil, fmt.Errorf("unsupported BMP")
	}
	w := int(int32(binary.LittleEndian.Uint32(data[18:22])))
	hraw := int(int32(binary.LittleEndian.Uint32(data[22:26])))
	topDown := hraw < 0
	h := hraw
	if h < 0 {
		h = -h
	}
	planes := binary.LittleEndian.Uint16(data[26:28])
	bpp := int(binary.LittleEndian.Uint16(data[28:30]))
	comp := binary.LittleEndian.Uint32(data[30:34])
	if planes != 1 || comp != 0 || w <= 0 || h <= 0 || (bpp != 24 && bpp != 32) {
		return nil, fmt.Errorf("unsupported BMP")
	}
	stride := ((w*bpp + 31) / 32) * 4
	if off+stride*h > len(data) {
		return nil, fmt.Errorf("truncated BMP")
	}
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	for y := 0; y < h; y++ {
		srcY := y
		if !topDown {
			srcY = h - 1 - y
		}
		row := off + srcY*stride
		for x := 0; x < w; x++ {
			p := row + x*(bpp/8)
			b, g, r := data[p], data[p+1], data[p+2]
			a := byte(255)
			if bpp == 32 {
				a = data[p+3]
			}
			img.SetRGBA(x, y, color.RGBA{r, g, b, a})
		}
	}
	return img, nil
}
