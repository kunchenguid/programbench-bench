module reimpl

go 1.20
