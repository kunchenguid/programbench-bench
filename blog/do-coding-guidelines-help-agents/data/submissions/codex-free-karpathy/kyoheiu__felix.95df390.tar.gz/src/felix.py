#!/usr/bin/env python3
import gzip
import os
import shutil
import stat
import subprocess
import sys
import tarfile
import termios
import time
import tty
import zipfile
from pathlib import Path

HELP = """# felix v2.16.1
A simple TUI file manager with vim-like keymapping.

## Usage
`fx` => Show items in the current directory.
`fx <directory path>` => Show items in the path.
Both relative and absolute path available.

## Options
`--help` | `-h`   => Print help.
`--log`  | `-l`   => Launch the app, automatically generating a log file.
`--init`          => Returns a shell script that can be sourcedfor
                     for shell integration.

## Manual
j / <Down>         :Go down.
k / <Up>           :Go up.
<C-d>              :Go down 1/2 page.
<C-u>>             :Go up 1/2 page.
h / <Left>         :Go to the parent directory if exists.
l / <Right> / <CR> :Open item or change directory.
gg                 :Go to the top.
G                  :Go to the bottom.
z<CR>              :Go to the home directory.
z {keyword}<CR>    :Jump to a directory that matches the keyword.
                    (zoxide required)
<C-o>              :Jump backward.
<C-i>              :Jump forward.
i{file name}<CR>   :Create a new empty file.
I{dir name}<CR>    :Create a new empty directory.
o                  :Open item in a new window.
e                  :Unpack archive/compressed file.
dd                 :Delete and yank item.
yy                 :Yank item.
p                  :Put yanked item(s) from register zero
                    in the current directory.
:reg               :Show registers. To hide it, press v.
"ayy               :Yank item to register a.
"add               :Delete and yank item to register a.
"Ayy               :Append item to register a.
"Add               :Delete and append item to register a.
"ap                :Put item(s) from register a.
V                  :Switch to the linewise visual mode.
  - y              :In the visual mode, yank selected item(s).
  - d              :In the visual mode, delete and yank selected item(s).
  - "ay            :In the visual mode, yank items to register a.
  - "ad            :In the visual mode, delete and yank items to register a.
  - "Ay            :In the visual mode, append items to register a.
  - "Ad            :In the visual mode, delete and append items to register a.
  - c              :Rename selected items in default editor.
u                  :Undo put/delete/rename.
<C-r>              :Redo put/delete/rename.
v                  :Toggle whether to show the preview.
s                  :Toggle between vertical / horizontal split in the preview mode.
<Alt-j>
 / <Alt-<Down>>    :Scroll down the preview text.
<Alt-k> 
 / <Alt-<Up>>      :Scroll up the preview text.
<BS>               :Toggle whether to show hidden items.
t                  :Toggle the sort order (name <-> modified time).
c                  :Switch to the rename mode.
/{keyword}         :Search items by a keyword.
n                  :Go forward to the item that matches the keyword.
N                  :Go backward to the item that matches the keyword.
:                  :Switch to the command line.
  - <C-r>a         :In the command line, paste item name in register a.
:cd<CR>            :Go to the home directory.
:cd {path}<CR>     :Go to the path.
:e<CR>             :Reload the current directory.
:config<CR>        :Go to the directory that contains the config file if exists.
:trash<CR>         :Go to the trash directory.
:empty<CR>         :Empty the trash directory.
:h<CR>             :Show help.
:q<CR>             :Exit.
:{command}         :Execute a command e.g. :zip test *.md
<Esc>              :Return to the normal mode.
<C-h>              :Works as Backspace after `i`, `I`, `c`, `/`, `:` and `z`.
ZZ                 :Exit without cd to last working directory
                    (if `match_vim_exit_behavior` is `false`).
ZQ                 :cd into the last working directory and exit
                    (if shell setting is ready and `match_vim_exit_behavior is `false`).

## Preview feature
By default, text files and directories can be previewed.
To preview images, you need to install chafa (>= v1.10.0).
Please see https://hpjansson.org/chafa/

## Configuration

*Both `config.yaml` and `config.yml` work.*

### Linux
config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
trash directory: $XDG_DATA_HOME/felix/trash
log files      : $XDG_DATA_HOME/felix/log

### macOS
On macOS, felix looks for the config file in the following locations:

1. `$HOME/Library/Application Support/felix/config.yaml(config.yml)`
2. `$HOME/.config/felix/config.yaml`

trash directory: $HOME/Library/Application Support/felix/trash
log files      : $HOME/Library/Application Support/felix/log

### Windows
config file     : $PROFILE\\\\AppData\\\\Roaming\\\\felix\\\\config.yaml(config.yml)
trash directory : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\trash
log files       : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\log

For more details, visit https://github.com/kyoheiu/felix
"""

INIT = """# To be eval'ed in the calling shell
  eval "$(
    if [ -n "$XDG_RUNTIME_DIR" ]; then
      runtime_dir="$XDG_RUNTIME_DIR/felix"
    elif [ -n "$TMPDIR" ]; then
      runtime_dir="$TMPDIR/felix"
    else
      runtime_dir=/tmp/felix
    fi

    mkdir -p "$runtime_dir"

    # Clean up leftover LWD files
    find "$runtime_dir" -type f -and -mmin +1 -delete

    cat << EOF
fx() {
  local RUNTIME_DIR="$runtime_dir"
  SHELL_PID=\\$\\$ command fx "\\$@"

  if [ -f "\\$RUNTIME_DIR/\\$\\$" ]; then
    cd "\\$(cat "\\$RUNTIME_DIR/\\$\\$")"
    rm "\\$RUNTIME_DIR/\\$\\$"
  fi
}
EOF
  )"
"""


def data_home() -> Path:
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))


def runtime_dir() -> Path:
    base = os.environ.get("XDG_RUNTIME_DIR") or os.environ.get("TMPDIR") or "/tmp"
    return Path(base) / "felix"


def log_start() -> None:
    d = data_home() / "felix" / "log"
    d.mkdir(parents=True, exist_ok=True)
    now = time.strftime("%Y-%m-%d-%H-%M-%S")
    (d / f"{now}.log").write_text(time.strftime("%H:%M:%S [INFO] ===START===\n"))


def invalid_path(path: str) -> int:
    print(f"Invalid path: {path}", file=sys.stderr)
    print("`fx -h` shows help.", file=sys.stderr)
    return 0


def path_should_be_dir() -> int:
    print("Path should be directory.", file=sys.stderr)
    print("`fx -h` shows help.", file=sys.stderr)
    return 0


class App:
    def __init__(self, cwd: Path):
        self.cwd = cwd.resolve()
        self.cursor = 0
        self.show_hidden = False
        self.sort_mtime = False
        self.message = ""
        self.register = []
        self.cut = False
        self.undo = []

    def entries(self):
        try:
            items = list(self.cwd.iterdir())
        except OSError as e:
            self.message = str(e)
            return []
        if not self.show_hidden:
            items = [p for p in items if not p.name.startswith(".")]
        if self.sort_mtime:
            items.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        else:
            items.sort(key=lambda p: (not p.is_dir(), p.name.lower(), p.name))
        self.cursor = max(0, min(self.cursor, max(0, len(items) - 1)))
        return items

    def draw(self):
        rows, cols = shutil.get_terminal_size((80, 24))
        items = self.entries()
        sys.stdout.write("\x1b[?25l\x1b[2J\x1b[1;1H")
        title = f" {self.cwd}"
        sys.stdout.write("\x1b[38;5;6m" + title[:cols] + "\x1b[0m")
        limit = max(0, rows - 3)
        start = 0
        if self.cursor >= limit and limit:
            start = self.cursor - limit + 1
        for line, p in enumerate(items[start:start + limit], 3):
            name = p.name + ("/" if p.is_dir() else "")
            color = "14" if p.is_dir() else "15"
            marker = ">" if start + line - 3 == self.cursor else " "
            try:
                mtime = time.strftime("%Y-%m-%d %H:%M", time.localtime(p.stat().st_mtime))
            except OSError:
                mtime = ""
            left = f"{marker} {name}"
            right = mtime
            sys.stdout.write(f"\x1b[{line};1H{marker}\x1b[38;5;{color}m {name[:max(1, cols-3)]}\x1b[0m")
            if cols > len(right) + 5:
                sys.stdout.write(f"\x1b[{line};{max(1, cols-len(right)+1)}H{right}")
        status = f" {self.cursor + 1 if items else 0}/{len(items)} {self.message}"
        sys.stdout.write(f"\x1b[{rows};1H\x1b[7m{status[:cols].ljust(cols)}\x1b[0m")
        sys.stdout.flush()

    def prompt(self, prefix):
        rows, cols = shutil.get_terminal_size((80, 24))
        buf = ""
        sys.stdout.write(f"\x1b[{rows-1};1H\x1b[2K{prefix}\x1b[?25h")
        sys.stdout.flush()
        while True:
            ch = sys.stdin.read(1)
            if ch in ("\r", "\n"):
                sys.stdout.write("\x1b[?25l")
                return buf
            if ch == "\x1b":
                sys.stdout.write("\x1b[?25l")
                return None
            if ch in ("\x7f", "\b", "\x08"):
                buf = buf[:-1]
            else:
                buf += ch
            sys.stdout.write(f"\x1b[{rows-1};1H\x1b[2K{prefix}{buf[:max(0, cols-len(prefix))]}")
            sys.stdout.flush()

    def selected(self):
        items = self.entries()
        return items[self.cursor] if items else None

    def open_selected(self):
        p = self.selected()
        if not p:
            return
        if p.is_dir():
            self.cwd = p.resolve()
            self.cursor = 0
        else:
            self.message = p.name

    def go_parent(self):
        parent = self.cwd.parent
        if parent != self.cwd:
            old = self.cwd.name
            self.cwd = parent
            names = [p.name for p in self.entries()]
            if old in names:
                self.cursor = names.index(old)

    def create_file(self):
        name = self.prompt("New file: ")
        if name:
            p = self.cwd / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.touch(exist_ok=True)
            self.message = f"created {name}"

    def create_dir(self):
        name = self.prompt("New directory: ")
        if name:
            (self.cwd / name).mkdir(parents=True, exist_ok=True)
            self.message = f"created {name}"

    def rename(self):
        p = self.selected()
        if not p:
            return
        name = self.prompt("Rename: ")
        if name:
            target = self.cwd / name
            p.rename(target)
            self.message = f"renamed to {name}"

    def delete(self):
        p = self.selected()
        if not p:
            return
        trash = data_home() / "felix" / "trash"
        trash.mkdir(parents=True, exist_ok=True)
        target = trash / f"{int(time.time()*1000)}-{p.name}"
        shutil.move(str(p), str(target))
        self.register = [target]
        self.cut = True
        self.undo.append(("move", target, p))
        self.message = f"deleted {p.name}"

    def yank(self):
        p = self.selected()
        if p:
            self.register = [p]
            self.cut = False
            self.message = f"yanked {p.name}"

    def paste(self):
        for src in self.register:
            if not Path(src).exists():
                continue
            dest = self.unique_dest(self.cwd / Path(src).name.split("-", 1)[-1] if self.cut else self.cwd / Path(src).name)
            if self.cut:
                shutil.move(str(src), str(dest))
                self.undo.append(("move", dest, src))
            elif Path(src).is_dir():
                shutil.copytree(src, dest)
            else:
                shutil.copy2(src, dest)
        self.message = "pasted"
        self.cut = False

    def unique_dest(self, p: Path):
        if not p.exists():
            return p
        stem, suffix = p.stem, p.suffix
        for i in range(1, 1000):
            q = p.with_name(f"{stem}_{i}{suffix}")
            if not q.exists():
                return q
        return p.with_name(f"{stem}_{int(time.time())}{suffix}")

    def extract(self):
        p = self.selected()
        if not p or not p.is_file():
            return
        try:
            n = p.name.lower()
            if tarfile.is_tarfile(p):
                with tarfile.open(p) as tf:
                    tf.extractall(self.cwd)
            elif zipfile.is_zipfile(p):
                with zipfile.ZipFile(p) as zf:
                    zf.extractall(self.cwd)
            elif n.endswith(".gz"):
                out = self.cwd / p.name[:-3]
                with gzip.open(p, "rb") as fin, open(out, "wb") as fout:
                    shutil.copyfileobj(fin, fout)
            else:
                self.message = "unsupported archive"
                return
            self.message = f"unpacked {p.name}"
        except Exception as e:
            self.message = str(e)

    def command(self):
        cmd = self.prompt(":")
        if cmd is None:
            return False
        cmd = cmd.strip()
        if cmd in ("q", "quit"):
            return True
        if cmd == "h":
            self.message = "help"
        elif cmd in ("e", "reload"):
            self.message = ""
        elif cmd == "reg":
            self.message = " ".join(str(p) for p in self.register)
        elif cmd == "trash":
            self.cwd = data_home() / "felix" / "trash"
            self.cwd.mkdir(parents=True, exist_ok=True)
            self.cursor = 0
        elif cmd == "empty":
            trash = data_home() / "felix" / "trash"
            if trash.exists():
                for p in trash.iterdir():
                    shutil.rmtree(p) if p.is_dir() else p.unlink()
            self.message = "trash emptied"
        elif cmd == "config":
            cfg = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "felix"
            cfg.mkdir(parents=True, exist_ok=True)
            self.cwd = cfg
            self.cursor = 0
        elif cmd.startswith("cd"):
            arg = cmd[2:].strip()
            target = Path.home() if not arg else (self.cwd / arg).expanduser()
            if target.is_dir():
                self.cwd = target.resolve()
                self.cursor = 0
            else:
                self.message = f"Invalid path: {arg}"
        elif cmd:
            subprocess.run(cmd, shell=True, cwd=self.cwd)
        return False

    def search(self):
        key = self.prompt("/")
        if key:
            for i, p in enumerate(self.entries()):
                if key.lower() in p.name.lower():
                    self.cursor = i
                    break

    def write_lwd(self):
        pid = os.environ.get("SHELL_PID")
        if not pid:
            return
        d = runtime_dir()
        d.mkdir(parents=True, exist_ok=True)
        (d / pid).write_text(str(self.cwd))

    def loop(self):
        last = ""
        try:
            old = termios.tcgetattr(sys.stdin)
            tty.setcbreak(sys.stdin)
        except termios.error:
            old = None
        try:
            while True:
                self.draw()
                ch = sys.stdin.read(1)
                if ch == "\x1b":
                    seq = sys.stdin.read(2)
                    if seq == "[A":
                        ch = "k"
                    elif seq == "[B":
                        ch = "j"
                    elif seq == "[C":
                        ch = "l"
                    elif seq == "[D":
                        ch = "h"
                    else:
                        continue
                if ch in ("j", "\x0e"):
                    self.cursor = min(self.cursor + 1, max(0, len(self.entries()) - 1))
                elif ch in ("k", "\x10"):
                    self.cursor = max(0, self.cursor - 1)
                elif ch == "\x04":
                    self.cursor = min(self.cursor + max(1, shutil.get_terminal_size((80, 24)).lines // 2), max(0, len(self.entries()) - 1))
                elif ch == "\x15":
                    self.cursor = max(0, self.cursor - max(1, shutil.get_terminal_size((80, 24)).lines // 2))
                elif ch in ("l", "\r", "\n"):
                    self.open_selected()
                elif ch == "h":
                    self.go_parent()
                elif ch == "G":
                    self.cursor = max(0, len(self.entries()) - 1)
                elif ch == "g":
                    if last == "g":
                        self.cursor = 0
                        last = ""
                        continue
                elif ch == "i":
                    self.create_file()
                elif ch == "I":
                    self.create_dir()
                elif ch == "c":
                    self.rename()
                elif ch == "e":
                    self.extract()
                elif ch == "d":
                    if last == "d":
                        self.delete()
                        last = ""
                        continue
                elif ch == "y":
                    if last == "y":
                        self.yank()
                        last = ""
                        continue
                elif ch == "p":
                    self.paste()
                elif ch == "u" and self.undo:
                    typ, a, b = self.undo.pop()
                    if typ == "move" and Path(a).exists():
                        shutil.move(str(a), str(b))
                elif ch == "v":
                    self.message = ""
                elif ch == "s":
                    self.message = ""
                elif ch == "\x7f":
                    self.show_hidden = not self.show_hidden
                elif ch == "t":
                    self.sort_mtime = not self.sort_mtime
                elif ch == "/":
                    self.search()
                elif ch == ":":
                    if self.command():
                        break
                elif ch == "Z":
                    if last == "Z":
                        break
                    last = "Z"
                    continue
                elif ch == "Q" and last == "Z":
                    self.write_lwd()
                    break
                elif ch == "q":
                    break
                last = ch
        finally:
            if old:
                termios.tcsetattr(sys.stdin, termios.TCSADRAIN, old)
            sys.stdout.write("\x1b[?25h\x1b[0m\x1b[2J\x1b[1;1H")
            sys.stdout.flush()


def run_app(path: Path):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("Error: Cannot detect terminal size", file=sys.stderr)
        return 0
    size = shutil.get_terminal_size((0, 0))
    if size.lines < 10 or size.columns < 40:
        print("Error: Too small window size", file=sys.stderr)
        return 0
    App(path).loop()
    return 0


def main(argv):
    if len(argv) > 1 and argv[1] in ("-h", "--help"):
        print(HELP)
        return 0
    if len(argv) > 1 and argv[1] == "--init":
        print(INIT, end="")
        return 0
    args = argv[1:]
    if args and args[0] in ("-l", "--log"):
        log_start()
        args = args[1:]
    path = Path(args[0]).expanduser() if args else Path.cwd()
    if len(args) > 1:
        return invalid_path(args[1])
    if not path.exists():
        return invalid_path(str(args[0] if args else path))
    if not path.is_dir():
        return path_should_be_dir()
    return run_app(path)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
