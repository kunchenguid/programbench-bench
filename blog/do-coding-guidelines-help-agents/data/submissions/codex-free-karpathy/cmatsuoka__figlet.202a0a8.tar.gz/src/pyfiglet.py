#!/usr/bin/env python3
import os
import sys
import shutil

USAGE = ("Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n"
         "              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n"
         "              [ -C controlfile ] [ -I infocode ] [ message ]")

VERSION_TEXT = """FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,
Christiaan Keet and Claudio Matsuoka
Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012

FIGlet, along with the various FIGlet fonts and documentation, may be
freely copied and distributed.

If you use FIGlet, please send an e-mail message to <info@figlet.org>.

The latest version of FIGlet is available from the web site,
\thttp://www.figlet.org/

""" + USAGE


class Font:
    def __init__(self, path):
        self.path = path
        with open(path, "r", encoding="latin-1") as f:
            lines = f.read().splitlines()
        if not lines or not lines[0].startswith("flf2a"):
            raise ValueError("bad font")
        head = lines[0].split()
        self.hardblank = head[0][5]
        self.height = int(head[1])
        self.old_layout = int(head[4])
        self.comment_lines = int(head[5])
        self.print_dir = int(head[6]) if len(head) > 6 else 0
        self.full_layout = int(head[7]) if len(head) > 7 else self.old_layout
        body = lines[1 + self.comment_lines:]
        self.chars = {}
        idx = 0
        for code in range(32, 127):
            if idx + self.height > len(body):
                break
            raw = body[idx:idx + self.height]
            idx += self.height
            self.chars[chr(code)] = [self._strip_endmark(x) for x in raw]
        self.blank = self.chars.get(" ", [""] * self.height)

    @staticmethod
    def _strip_endmark(s):
        if not s:
            return s
        marker = s[-1]
        while s.endswith(marker):
            s = s[:-1]
        return s


def error(msg):
    sys.stderr.write("executable: " + msg + "\n")


def resolve_font(fontdir, name):
    names = [name]
    if not (name.endswith(".flf") or name.endswith(".tlf")):
        names.append(name + ".flf")
        names.append(name + ".tlf")
    dirs = []
    if os.path.isabs(name) or "/" in name:
        dirs.append("")
    else:
        dirs.extend([fontdir, "."])
    for d in dirs:
        for n in names:
            p = os.path.join(d, n) if d else n
            if os.path.exists(p):
                return p
    return None


def glyph_for(font, ch):
    if ch in font.chars:
        return font.chars[ch][:]
    return font.blank[:]


def pad_rows(rows):
    w = max((len(r) for r in rows), default=0)
    return [r + " " * (w - len(r)) for r in rows], w


def smush_pair(a, b, mode, hardblank):
    if a == " ":
        return b
    if b == " ":
        return a
    if mode == "overlap":
        return b
    if mode != "smush":
        return None
    if a == hardblank and b == hardblank:
        return None
    if a == b and a != hardblank:
        return a
    if b == "_":
        a, b = b, a
    if a == "_" and b in "|/\\[]{}()<>" and b != hardblank:
        return b
    hierarchy = "|/\\[]{}()<>"
    if a in hierarchy and b in hierarchy:
        return a if hierarchy.index(a) > hierarchy.index(b) else b
    pairs = {("[", "]"): "|", ("{", "}"): "|", ("(", ")"): "|"}
    if (a, b) in pairs:
        return pairs[(a, b)]
    if (b, a) in pairs:
        return pairs[(b, a)]
    if a == "/" and b == "\\":
        return "|"
    if a == "\\" and b == "/":
        return "Y"
    if a == ">" and b == "<":
        return "X"
    return None


def row_fit(left, right, mode, hardblank):
    li = len(left.rstrip(" ")) - 1
    ri = len(right) - len(right.lstrip(" "))
    if li < 0:
        return len(left)
    kern = len(left) - li - 1 + ri
    if mode == "kern":
        return kern
    if mode == "overlap":
        return kern + (1 if len(right.strip(" ")) > 0 else 0)
    if mode == "smush" and ri < len(right):
        if smush_pair(left[li], right[ri], mode, hardblank) is not None:
            return kern + 1
    return kern


def join_glyph(left, right, mode, hardblank):
    if not left:
        return right[:]
    if mode == "full":
        overlap = 0
    else:
        lpad, lw = pad_rows(left)
        rpad, rw = pad_rows(right)
        overlap = min(row_fit(lpad[i], rpad[i], mode, hardblank) for i in range(len(lpad)))
        overlap = max(0, min(overlap, lw, rw))
    lpad, lw = pad_rows(left)
    rpad, rw = pad_rows(right)
    out = []
    for row in range(len(lpad)):
        chars = list(lpad[row])
        for i in range(rw):
            pos = lw - overlap + i
            b = rpad[row][i]
            if pos < len(chars):
                a = chars[pos]
                chars[pos] = smush_pair(a, b, mode, hardblank) or a or b
            else:
                chars.extend(" " * (pos - len(chars)))
                chars.append(b)
        out.append("".join(chars))
    return out


def render_word(font, text, mode):
    rows = []
    for ch in text:
        rows = join_glyph(rows, glyph_for(font, ch), mode, font.hardblank)
    return [r.replace(font.hardblank, " ") for r in rows]


def render_line(font, text, mode):
    rows = []
    for ch in text:
        rows = join_glyph(rows, glyph_for(font, ch), mode, font.hardblank)
    return [r.replace(font.hardblank, " ") for r in rows]


def justify(rows, width, how):
    if how == "left":
        return rows
    out = []
    for r in rows:
        n = len(r)
        if n >= width:
            out.append(r)
        elif how == "right":
            out.append(" " * (width - n) + r)
        else:
            out.append(" " * ((width - n) // 2) + r)
    return out


def emit_paragraph(font, text, mode, width, justify_mode):
    if width == 1:
        pieces = []
        for ch in text:
            if ch == " ":
                pieces.extend([""] * font.height)
            else:
                pieces.extend(justify(render_line(font, ch, mode), width, justify_mode))
        return pieces
    if width <= 0:
        width = 80
    words = text.split(" ")
    rendered_lines = []
    current = ""
    for word in words:
        trial = word if current == "" else current + " " + word
        if current and max(map(len, render_line(font, trial, mode))) > width:
            rendered_lines.extend(justify(render_line(font, current, mode), width, justify_mode))
            current = word
        else:
            current = trial
    rendered_lines.extend(justify(render_line(font, current, mode), width, justify_mode))
    return rendered_lines


def parse_args(argv):
    opts = {
        "fontdir": "./fonts",
        "font": "standard",
        "width": 80,
        "justify": "left",
        "mode": None,
        "info": -1,
        "paragraph": False,
        "rtl": False,
    }
    msg = []
    i = 0
    takes_arg = set("dfmwCI")
    while i < len(argv):
        a = argv[i]
        if a == "--":
            msg.extend(argv[i + 1:])
            break
        if a.startswith("-") and a != "-":
            j = 1
            while j < len(a):
                c = a[j]
                if c not in "cklnoprstvxDELNRSWXdfmwCI":
                    sys.stderr.write("./executable: invalid option -- '%s'\n" % c)
                    sys.stderr.write(USAGE + "\n")
                    sys.exit(1)
                val = None
                if c in takes_arg:
                    if j + 1 < len(a):
                        val = a[j + 1:]
                        j = len(a)
                    else:
                        i += 1
                        if i >= len(argv):
                            error("option requires an argument -- '%s'" % c)
                            sys.exit(1)
                        val = argv[i]
                if c == "d":
                    opts["fontdir"] = val
                elif c == "f":
                    opts["font"] = val
                elif c == "w":
                    try:
                        opts["width"] = int(val)
                    except ValueError:
                        opts["width"] = 80
                elif c == "I":
                    try:
                        opts["info"] = int(val)
                    except ValueError:
                        opts["info"] = 0
                elif c == "m":
                    try:
                        m = int(val)
                    except ValueError:
                        m = -2
                    if m == -1:
                        opts["mode"] = "full"
                    elif m == 0:
                        opts["mode"] = "kern"
                    else:
                        opts["mode"] = "smush"
                elif c == "c":
                    opts["justify"] = "center"
                elif c == "l":
                    opts["justify"] = "left"
                elif c == "r":
                    opts["justify"] = "right"
                elif c == "t":
                    opts["width"] = shutil.get_terminal_size((80, 24)).columns
                elif c == "p":
                    opts["paragraph"] = True
                elif c == "n":
                    opts["paragraph"] = False
                elif c == "k":
                    opts["mode"] = "kern"
                elif c == "W":
                    opts["mode"] = "full"
                elif c in ("s", "S"):
                    opts["mode"] = "smush"
                elif c == "o":
                    opts["mode"] = "overlap"
                elif c == "R":
                    opts["rtl"] = True
                elif c == "L":
                    opts["rtl"] = False
                elif c == "v":
                    opts["info"] = 0
                j += 1
            i += 1
        else:
            msg.extend(argv[i:])
            break
    return opts, msg


def main():
    opts, msg = parse_args(sys.argv[1:])
    if opts["info"] >= 0:
        if opts["info"] == 0:
            print(VERSION_TEXT)
        elif opts["info"] == 1:
            print("20205")
        elif opts["info"] == 2:
            print(opts["fontdir"] if opts["fontdir"] != "./fonts" else "/usr/local/share/figlet")
        elif opts["info"] == 3:
            base = os.path.basename(opts["font"])
            print(os.path.splitext(base)[0])
        elif opts["info"] == 4:
            print(opts["width"])
        elif opts["info"] == 5:
            print("flf2 tlf2")
        return 0
    path = resolve_font(opts["fontdir"], opts["font"])
    if not path:
        error("%s: Unable to open font file" % opts["font"])
        return 1
    try:
        font = Font(path)
    except Exception:
        error("%s: Unable to open font file" % opts["font"])
        return 1
    mode = opts["mode"]
    if mode is None:
        if font.old_layout < 0:
            mode = "full"
        elif font.old_layout == 0:
            mode = "kern"
        else:
            mode = "smush"
    if msg:
        text = "\n".join(" ".join(msg).split("\0"))
    else:
        text = sys.stdin.read()
        if text.endswith("\n"):
            text = text[:-1]
    if opts["paragraph"]:
        text = text.replace("\n", " ")
    for line_no, line in enumerate(text.split("\n")):
        if opts["rtl"]:
            line = line[::-1]
        rows = emit_paragraph(font, line, mode, opts["width"], opts["justify"])
        for r in rows:
            print(r)
    return 0


if __name__ == "__main__":
    sys.exit(main())
