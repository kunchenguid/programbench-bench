#!/usr/bin/env python3
import sys, os, gzip, math, random, statistics, signal
from collections import defaultdict, Counter

VERSION = "bedtools v2.31.1"
signal.signal(signal.SIGPIPE, signal.SIG_DFL)

class Rec:
    __slots__ = ("f","chrom","start","end","line","idx")
    def __init__(self, f, idx=0):
        f = [str(x) for x in f]
        self.f = f
        self.chrom = f[0] if len(f) > 0 else ""
        self.start = int(float(f[1])) if len(f) > 1 and is_num(f[1]) else 0
        self.end = int(float(f[2])) if len(f) > 2 and is_num(f[2]) else self.start
        self.line = "\t".join(f)
        self.idx = idx
    def copy(self):
        return Rec(list(self.f), self.idx)

def is_num(s):
    try:
        float(s); return True
    except Exception:
        return False

def die(msg, code=1):
    sys.stderr.write(msg.rstrip()+"\n")
    sys.exit(code)

def open_text(path):
    if path in ("-", "stdin", None):
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt")
    return open(path, "rt")

def read_rows(path, keep_header=False):
    rows=[]; headers=[]
    with open_text(path) as fh:
        for line in fh:
            line=line.rstrip("\n")
            if not line: continue
            if line.startswith(("#","track","browser")):
                if keep_header: headers.append(line)
                continue
            f=line.split("\t") if "\t" in line else line.split()
            if len(f) < 3 or not is_num(f[1]) or not is_num(f[2]):
                if keep_header: headers.append(line)
                continue
            rows.append(Rec(f, len(rows)))
    return headers, rows

def read_bed(path): return read_rows(path)[1]

def read_genome(path):
    out=[]; sizes={}
    with open_text(path) as fh:
        for line in fh:
            if not line.strip() or line.startswith("#"): continue
            f=line.split()
            if len(f)>=2 and is_num(f[1]):
                sizes[f[0]]=int(float(f[1])); out.append((f[0], sizes[f[0]]))
    return out, sizes

def emit(fields):
    print("\t".join(map(str, fields)))

def overlap(a,b):
    if a.chrom != b.chrom: return 0
    return max(0, min(a.end,b.end)-max(a.start,b.start))

def dist(a,b):
    if a.chrom != b.chrom: return None
    ov=overlap(a,b)
    if ov>0: return 0
    if a.end <= b.start: return b.start-a.end+1
    return a.start-b.end+1

def strand_ok(a,b,same=False,opp=False):
    if not same and not opp: return True
    sa = a.f[5] if len(a.f)>5 else "."
    sb = b.f[5] if len(b.f)>5 else "."
    return (sa==sb) if same else (sa!=sb)

def pass_frac(a,b,ov,f=1e-9,F=1e-9,recip=False,either=False):
    if ov <= 0: return False
    al=max(1,a.end-a.start); bl=max(1,b.end-b.start)
    pa = ov / al >= f
    pb = ov / bl >= F
    if recip: return pa and pb
    return (pa or pb) if either else (pa and pb)

def parse_opts(args, multi=None, flags=None):
    multi=set(multi or []); flags=set(flags or [])
    opts={}; pos=[]; i=0
    while i < len(args):
        a=args[i]
        if a in flags:
            opts[a]=True; i+=1
        elif a in multi:
            vals=[]; i+=1
            while i < len(args) and not args[i].startswith("-"):
                vals.append(args[i]); i+=1
            opts[a]=vals
        elif a.startswith("-"):
            if i+1 < len(args) and not args[i+1].startswith("-"):
                opts[a]=args[i+1]; i+=2
            else:
                opts[a]=True; i+=1
        else:
            pos.append(a); i+=1
    return opts,pos

def get_path(opts, key, default=None): return opts.get(key, default)

def parse_cols(s):
    return [int(x)-1 for x in str(s).split(",") if x!=""]

def parse_ops(s):
    return [x for x in str(s).split(",") if x!=""]

def fmt_num(x, prec=5):
    if isinstance(x, str): return x
    if abs(x-round(x)) < 1e-10: return str(int(round(x)))
    return f"{x:.{prec}g}"

def aggregate(records, cols, ops, delim=",", prec=5):
    if len(cols)==1 and len(ops)>1: cols=cols*len(ops)
    if len(ops)==1 and len(cols)>1: ops=ops*len(cols)
    out=[]
    for c,op in zip(cols,ops):
        vals=[r.f[c] if c < len(r.f) else "" for r in records]
        nums=[float(v) for v in vals if is_num(v)]
        if op=="count": out.append(str(len(vals)))
        elif op=="count_distinct": out.append(str(len(set(vals))))
        elif op=="sum": out.append(fmt_num(sum(nums),prec))
        elif op=="min": out.append(fmt_num(min(nums) if nums else ".",prec))
        elif op=="max": out.append(fmt_num(max(nums) if nums else ".",prec))
        elif op=="absmin": out.append(fmt_num(min(nums,key=lambda x:abs(x)) if nums else ".",prec))
        elif op=="absmax": out.append(fmt_num(max(nums,key=lambda x:abs(x)) if nums else ".",prec))
        elif op=="mean": out.append(fmt_num(sum(nums)/len(nums) if nums else ".",prec))
        elif op=="median": out.append(fmt_num(statistics.median(nums) if nums else ".",prec))
        elif op in ("stdev","sstdev"): out.append(fmt_num(statistics.stdev(nums) if len(nums)>1 else 0,prec))
        elif op=="collapse": out.append(delim.join(vals))
        elif op=="concat": out.append("".join(vals))
        elif op in ("distinct","distinct_only"):
            seen=[]; [seen.append(v) for v in vals if v not in seen]
            out.append(delim.join(seen))
        elif op=="distinct_sort_num":
            out.append(delim.join(fmt_num(x,prec) for x in sorted(set(nums))))
        elif op=="distinct_sort_num_desc":
            out.append(delim.join(fmt_num(x,prec) for x in sorted(set(nums), reverse=True)))
        elif op=="mode":
            out.append(Counter(vals).most_common(1)[0][0] if vals else ".")
        elif op=="antimode":
            out.append(sorted(Counter(vals).items(), key=lambda kv:(kv[1], vals.index(kv[0])))[0][0] if vals else ".")
        elif op=="freqdesc" or op=="freqasc":
            items=list(Counter(vals).items())
            items.sort(key=lambda kv:(kv[1],kv[0]), reverse=(op=="freqdesc"))
            out.append(delim.join(f"{k}:{v}" for k,v in items))
        elif op=="first": out.append(vals[0] if vals else ".")
        elif op=="last": out.append(vals[-1] if vals else ".")
        else: out.append(".")
    return out

def cmd_intersect(args):
    opts,pos=parse_opts(args, multi={"-b","-names","-filenames"}, flags={"-wa","-wb","-loj","-wo","-wao","-u","-c","-C","-v","-s","-S","-r","-e","-sorted","-header","-split","-nonamecheck"})
    a_path=opts.get("-a") or (pos[0] if pos else None)
    b_paths=opts.get("-b") or ([pos[1]] if len(pos)>1 else [])
    if not a_path or not b_paths: die("***** ERROR: -a and -b are required. *****")
    headers,A=read_rows(a_path, keep_header=bool(opts.get("-header")))
    Bsets=[read_bed(p) for p in b_paths]
    names=opts.get("-names", []) if "-names" in opts else []
    if "-filenames" in opts:
        names=b_paths
    f=float(opts.get("-f",1e-9)); F=float(opts.get("-F",1e-9))
    def null_b():
        n=max((len(b.f) for B in Bsets for b in B), default=3)
        vals=[]
        for i in range(n):
            if i == 0: vals.append(".")
            elif i in (1,2): vals.append("-1")
            elif i == 4: vals.append("-1")
            else: vals.append(".")
        return vals
    for h in headers: print(h)
    for a in A:
        hits=[]
        for bi,B in enumerate(Bsets):
            for b in B:
                ov=overlap(a,b)
                if strand_ok(a,b,opts.get("-s"),opts.get("-S")) and pass_frac(a,b,ov,f,F,opts.get("-r"),opts.get("-e")):
                    hits.append((bi,b,ov))
        if opts.get("-c"):
            emit(a.f+[len(hits)]); continue
        if opts.get("-C"):
            for bi,B in enumerate(Bsets):
                emit(a.f+[bi+1, sum(1 for h in hits if h[0]==bi)])
            continue
        if opts.get("-v"):
            if not hits: print(a.line)
            continue
        if opts.get("-u"):
            if hits: print(a.line)
            continue
        if not hits:
            if opts.get("-wao") or opts.get("-loj"):
                emit(a.f+null_b()+([0] if opts.get("-wao") else []))
            continue
        for bi,b,ov in hits:
            prefix=[]
            if len(Bsets)>1 and (opts.get("-wb") or opts.get("-wo") or opts.get("-wao")):
                prefix=[names[bi] if bi < len(names) else bi+1]
            if opts.get("-wo") or opts.get("-wao"):
                emit(a.f+prefix+b.f+[ov])
            elif opts.get("-loj"):
                emit(a.f+prefix+b.f)
            elif opts.get("-wa") and opts.get("-wb"):
                emit(a.f+prefix+b.f)
            elif opts.get("-wa"):
                print(a.line)
            elif opts.get("-wb"):
                emit(prefix+b.f)
            else:
                emit([a.chrom, max(a.start,b.start), min(a.end,b.end)] + a.f[3:])

def merged_groups(rows, d=0, same=False, strand_filter=None):
    rows=sorted(rows, key=lambda r:(r.chrom,r.start,r.end))
    cur=None; group=[]
    for r in rows:
        if strand_filter and (len(r.f)<6 or r.f[5] != strand_filter): continue
        if cur is None:
            cur=r.copy(); group=[r]; continue
        same_strand = (not same) or (len(cur.f)>5 and len(r.f)>5 and cur.f[5]==r.f[5])
        if r.chrom==cur.chrom and same_strand and r.start <= cur.end + d:
            cur.end=max(cur.end,r.end); cur.f[2]=str(cur.end); group.append(r)
        else:
            yield cur,group
            cur=r.copy(); group=[r]
    if cur is not None: yield cur,group

def cmd_merge(args):
    opts,pos=parse_opts(args, flags={"-s","-header","-bed"})
    headers,rows=read_rows(opts.get("-i") or (pos[0] if pos else "-"), keep_header=bool(opts.get("-header")))
    for h in headers: print(h)
    cols=parse_cols(opts["-c"]) if "-c" in opts else []
    ops=parse_ops(opts.get("-o","sum")) if cols else []
    for cur,grp in merged_groups(rows, int(opts.get("-d",0)), bool(opts.get("-s")), opts.get("-S")):
        out=[cur.chrom,cur.start,cur.end]
        if cols: out += aggregate(grp, cols, ops, opts.get("-delim",","), int(opts.get("-prec",5)))
        emit(out)

def cmd_sort(args):
    opts,pos=parse_opts(args, flags={"-sizeA","-sizeD","-chrThenSizeA","-chrThenSizeD","-chrThenScoreA","-chrThenScoreD","-header"})
    headers,rows=read_rows(opts.get("-i") or (pos[0] if pos else "-"), keep_header=bool(opts.get("-header")))
    order=None
    if "-g" in opts or "-faidx" in opts:
        genome,_=read_genome(opts.get("-g") or opts.get("-faidx")); order={c:i for i,(c,_) in enumerate(genome)}
    def chromkey(r): return order.get(r.chrom, 10**9) if order else r.chrom
    if opts.get("-sizeA"): key=lambda r:(r.end-r.start,r.chrom,r.start)
    elif opts.get("-sizeD"): key=lambda r: (-(r.end-r.start),r.chrom,r.start)
    elif opts.get("-chrThenSizeA"): key=lambda r:(chromkey(r),r.end-r.start,r.start)
    elif opts.get("-chrThenSizeD"): key=lambda r:(chromkey(r),-(r.end-r.start),r.start)
    elif opts.get("-chrThenScoreA"): key=lambda r:(chromkey(r),float(r.f[4]) if len(r.f)>4 and is_num(r.f[4]) else 0)
    elif opts.get("-chrThenScoreD"): key=lambda r:(chromkey(r),-(float(r.f[4]) if len(r.f)>4 and is_num(r.f[4]) else 0))
    else: key=lambda r:(chromkey(r),r.start,r.end)
    for h in headers: print(h)
    for r in sorted(rows,key=key): print(r.line)

def cmd_complement(args):
    opts,pos=parse_opts(args, flags={"-L"})
    rows=read_bed(opts.get("-i") or (pos[0] if pos else "-"))
    genome,_=read_genome(opts.get("-g"))
    by=defaultdict(list)
    for r in rows: by[r.chrom].append(r)
    for chrom,size in genome:
        if opts.get("-L") and chrom not in by: continue
        pos0=0
        for cur,grp in merged_groups(by.get(chrom,[])):
            if cur.start>pos0: emit([chrom,pos0,cur.start])
            pos0=max(pos0,cur.end)
        if pos0<size: emit([chrom,pos0,size])

def cmd_makewindows(args):
    opts,pos=parse_opts(args, flags={"-reverse"})
    intervals=[]
    if "-g" in opts:
        intervals=[Rec([c,0,s,c]) for c,s in read_genome(opts["-g"])[0]]
    else:
        intervals=read_bed(opts.get("-b") or "-")
    for r in intervals:
        L=r.end-r.start; wins=[]
        if "-n" in opts:
            n=int(opts["-n"])
            for i in range(n):
                s=r.start + (L*i)//n; e=r.start + (L*(i+1))//n
                wins.append((s,e,i+1))
        else:
            w=int(opts.get("-w",L)); step=int(opts.get("-s",w))
            i=1; s=r.start
            while s < r.end:
                wins.append((s,min(s+w,r.end),i)); i+=1; s+=step
        if opts.get("-reverse"): wins=[(s,e,len(wins)-i+1) for s,e,i in wins]
        for s,e,i in wins:
            out=[r.chrom,s,e]
            if opts.get("-i")=="src": out.append(r.f[3] if len(r.f)>3 else r.chrom)
            elif opts.get("-i")=="winnum": out.append(i)
            elif opts.get("-i")=="srcwinnum": out.append((r.f[3] if len(r.f)>3 else r.chrom)+"_"+str(i))
            emit(out)

def cmd_closest(args):
    opts,pos=parse_opts(args, multi={"-b"}, flags={"-d","-io","-s","-S","-N","-header"})
    headers,A=read_rows(opts.get("-a") or "-", keep_header=bool(opts.get("-header")))
    B=[b for p in (opts.get("-b") or []) for b in read_bed(p)]
    k=int(opts.get("-k",1)); tie=opts.get("-t","all")
    for h in headers: print(h)
    nullb=["."]*max((len(b.f) for b in B), default=3)
    if len(nullb)>=3: nullb[0],nullb[1],nullb[2]=".","-1","-1"
    for a in A:
        cand=[]
        for b in B:
            if a.chrom!=b.chrom or not strand_ok(a,b,opts.get("-s"),opts.get("-S")): continue
            if opts.get("-N") and len(a.f)>3 and len(b.f)>3 and a.f[3]==b.f[3]: continue
            d=dist(a,b)
            if opts.get("-io") and d==0: continue
            cand.append((d,b.idx,b))
        if not cand:
            emit(a.f+nullb+([ -1 ] if opts.get("-d") or "-D" in opts else [])); continue
        cand.sort(key=lambda x:(x[0],x[1]))
        chosen=[]; kth=None
        for d,idx,b in cand:
            if len(chosen)<k:
                chosen.append((d,b)); kth=d
            elif tie=="all" and d==kth:
                chosen.append((d,b))
            else: break
        if tie=="first" and chosen: chosen=chosen[:k]
        if tie=="last":
            bydist=defaultdict(list)
            for d,idx,b in cand: bydist[d].append((idx,b))
            d0=cand[0][0]; chosen=[(d0, bydist[d0][-1][1])]
        for d,b in chosen:
            emit(a.f+b.f+([d] if opts.get("-d") or "-D" in opts else []))

def cmd_slop(args, flank=False):
    opts,pos=parse_opts(args, flags={"-s","-pct","-header"})
    headers,rows=read_rows(opts.get("-i") or "-", keep_header=bool(opts.get("-header")))
    _,sizes=read_genome(opts.get("-g"))
    for h in headers: print(h)
    for r in rows:
        L=r.end-r.start
        l=float(opts.get("-l", opts.get("-b",0))); rr=float(opts.get("-r", opts.get("-b",0)))
        if opts.get("-pct"): l=int(L*l); rr=int(L*rr)
        else: l=int(l); rr=int(rr)
        if opts.get("-s") and len(r.f)>5 and r.f[5]=="-": l,rr=rr,l
        chromlen=sizes.get(r.chrom, 10**18)
        if flank:
            left=[r.chrom,max(0,r.start-l),r.start]+r.f[3:]
            right=[r.chrom,r.end,min(chromlen,r.end+rr)]+r.f[3:]
            if left[1] < left[2]: emit(left)
            if right[1] < right[2]: emit(right)
        else:
            f=list(r.f); f[1]=str(max(0,r.start-l)); f[2]=str(min(chromlen,r.end+rr)); emit(f)

def cmd_subtract(args):
    opts,pos=parse_opts(args, flags={"-A","-N","-s","-S","-r","-e"})
    A=read_bed(opts.get("-a") or "-"); B=read_bed(opts.get("-b") or "-")
    f=float(opts.get("-f",1e-9)); F=float(opts.get("-F",1e-9))
    for a in A:
        segs=[(a.start,a.end)]; total=0; anyhit=False
        for b in B:
            ov=overlap(a,b)
            if not strand_ok(a,b,opts.get("-s"),opts.get("-S")) or not pass_frac(a,b,ov,f,F,opts.get("-r"),opts.get("-e")): continue
            anyhit=True; total += ov
            new=[]
            for s,e in segs:
                if b.end<=s or b.start>=e: new.append((s,e))
                else:
                    if s < b.start: new.append((s,b.start))
                    if b.end < e: new.append((b.end,e))
            segs=new
        if opts.get("-A") and anyhit: continue
        if opts.get("-N") and total >= f*max(1,a.end-a.start): continue
        for s,e in segs:
            if s<e:
                flds=list(a.f); flds[1]=str(s); flds[2]=str(e); emit(flds)

def coverage_segments(rows):
    by=defaultdict(list)
    for r in rows:
        by[r.chrom].append((r.start,1)); by[r.chrom].append((r.end,-1))
    segs={}
    for c,events in by.items():
        events.sort(); depth=0; last=None; out=[]
        for x,delta in events:
            if last is not None and x>last and depth>0: out.append((last,x,depth))
            depth += delta; last=x
        segs[c]=out
    return segs

def cmd_genomecov(args):
    opts,pos=parse_opts(args, flags={"-bg","-bga","-d","-dz"})
    rows=read_bed(opts.get("-i") or "-")
    genome,sizes=read_genome(opts.get("-g"))
    segs=coverage_segments(rows)
    scale=float(opts.get("-scale",1.0))
    if opts.get("-bg") or opts.get("-bga"):
        for c,size in genome:
            last=0
            for s,e,d in segs.get(c,[]):
                if opts.get("-bga") and last<s: emit([c,last,s,fmt_num(0)])
                emit([c,s,e,fmt_num(d*scale)])
                last=e
            if opts.get("-bga") and last<size: emit([c,last,size,fmt_num(0)])
        return
    hist=Counter(); total=0
    for c,size in genome:
        total += size; covered=0
        for s,e,d in segs.get(c,[]):
            hist[d]+=e-s; covered+=e-s
        hist[0]+=size-covered
    for d in sorted(hist):
        emit(["genome",d,hist[d],total,fmt_num(hist[d]/total if total else 0,6)])

def bases_covered(a, Bs):
    intervals=[]
    for b in Bs:
        s=max(a.start,b.start); e=min(a.end,b.end)
        if a.chrom==b.chrom and s<e: intervals.append((s,e))
    intervals.sort(); cov=0; last=None
    for s,e in intervals:
        if last is None or s>last:
            cov += e-s; last=e
        elif e>last:
            cov += e-last; last=e
    return cov

def cmd_coverage(args):
    opts,pos=parse_opts(args, flags={"-counts","-mean","-s","-S","-r","-e","-sorted"})
    A=read_bed(opts.get("-a") or "-"); B=read_bed(opts.get("-b") or "-")
    f=float(opts.get("-f",1e-9)); F=float(opts.get("-F",1e-9))
    for a in A:
        hits=[b for b in B if strand_ok(a,b,opts.get("-s"),opts.get("-S")) and pass_frac(a,b,overlap(a,b),f,F,opts.get("-r"),opts.get("-e"))]
        cnt=len(hits); cov=bases_covered(a,hits); L=max(1,a.end-a.start)
        if opts.get("-counts"): emit(a.f+[cnt])
        elif opts.get("-mean"): emit(a.f+[fmt_num(sum(overlap(a,b) for b in hits)/L,5)])
        else: emit(a.f+[cnt,cov,L,f"{cov/L:.7f}"])

def cmd_map(args):
    opts,pos=parse_opts(args, flags={"-s","-S","-r","-e"})
    A=read_bed(opts.get("-a") or "-"); B=read_bed(opts.get("-b") or "-")
    cols=parse_cols(opts.get("-c","5")); ops=parse_ops(opts.get("-o","sum"))
    f=float(opts.get("-f",1e-9)); F=float(opts.get("-F",1e-9))
    for a in A:
        hits=[b for b in B if strand_ok(a,b,opts.get("-s"),opts.get("-S")) and pass_frac(a,b,overlap(a,b),f,F,opts.get("-r"),opts.get("-e"))]
        emit(a.f+(aggregate(hits,cols,ops,opts.get("-delim",","),int(opts.get("-prec",5))) if hits else ["."]*max(len(cols),len(ops))))

def cmd_groupby(args):
    opts,pos=parse_opts(args, flags={"-full","-inheader","-outheader","-header","-ignorecase"})
    rows=[]
    with open_text(opts.get("-i") or (pos[0] if pos else "-")) as fh:
        header=None
        for line in fh:
            line=line.rstrip("\n")
            if not line: continue
            if (opts.get("-inheader") or opts.get("-header")) and header is None:
                header=line.split(); continue
            rows.append(line.split("\t") if "\t" in line else line.split())
    gcols=parse_cols(opts.get("-g", opts.get("-grp","1,2,3")))
    cols=parse_cols(opts.get("-c", opts.get("-opCols","")))
    ops=parse_ops(opts.get("-o", opts.get("-ops","sum")))
    groups=[]; curkey=None; cur=[]
    for f in rows:
        key=tuple((f[i].lower() if opts.get("-ignorecase") and i<len(f) else (f[i] if i<len(f) else "")) for i in gcols)
        if curkey is None or key==curkey: cur.append(f); curkey=key
        else: groups.append(cur); cur=[f]; curkey=key
    if cur: groups.append(cur)
    if opts.get("-outheader") or opts.get("-header"):
        emit([f"col_{i+1}" for i in gcols]+[f"{op}_col_{c+1}" for c,op in zip(cols,ops if len(ops)==len(cols) else ops*len(cols))])
    for grp in groups:
        recs=[Rec(f) for f in grp]
        base=grp[0] if opts.get("-full") else [grp[0][i] if i<len(grp[0]) else "" for i in gcols]
        emit(base+aggregate(recs,cols,ops,opts.get("-delim",","),int(opts.get("-prec",5))))

def cmd_jaccard(args):
    opts,pos=parse_opts(args, flags={"-s","-S","-r","-e","-header"})
    A=list(merged_groups(read_bed(opts.get("-a") or "-"))); B=list(merged_groups(read_bed(opts.get("-b") or "-")))
    arows=[x[0] for x in A]; brows=[x[0] for x in B]
    alen=sum(r.end-r.start for r in arows); blen=sum(r.end-r.start for r in brows)
    inter=0; n=0
    for a in arows:
        for b in brows:
            ov=overlap(a,b)
            if ov>0: inter+=ov; n+=1
    union=alen+blen-inter
    print("intersection\tunion\tjaccard\tn_intersections")
    emit([inter,union,fmt_num(inter/union if union else 0,6),n])

def cmd_window(args):
    opts,pos=parse_opts(args, flags={"-u","-c","-v","-sm","-Sm","-sw"})
    A=read_bed(opts.get("-a") or "-"); B=read_bed(opts.get("-b") or "-")
    w=int(opts.get("-w",1000)); l=int(opts.get("-l",w)); r=int(opts.get("-r",w))
    for a in A:
        ll,rr=l,r
        if opts.get("-sw") and len(a.f)>5 and a.f[5]=="-": ll,rr=rr,ll
        win=Rec([a.chrom,max(0,a.start-ll),a.end+rr])
        hits=[b for b in B if overlap(win,b)>0 and strand_ok(a,b,opts.get("-sm"),opts.get("-Sm"))]
        if opts.get("-c"): emit(a.f+[len(hits)])
        elif opts.get("-u"):
            if hits: print(a.line)
        elif opts.get("-v"):
            if not hits: print(a.line)
        else:
            for b in hits: emit(a.f+b.f)

def cmd_spacing(args):
    opts,pos=parse_opts(args)
    rows=read_bed(opts.get("-i") or (pos[0] if pos else "-"))
    last={}
    for r in rows:
        if r.chrom not in last: gap="."
        else:
            prev=last[r.chrom]
            gap=-1 if r.start < prev.end else r.start-prev.end
        emit(r.f+[gap]); last[r.chrom]=r

def cmd_shift(args):
    opts,pos=parse_opts(args, flags={"-pct","-header"})
    headers,rows=read_rows(opts.get("-i") or "-", keep_header=bool(opts.get("-header")))
    _,sizes=read_genome(opts.get("-g"))
    for h in headers: print(h)
    for r in rows:
        L=r.end-r.start
        val=float(opts.get("-s", opts.get("-p",0) if (len(r.f)<6 or r.f[5] != "-") else opts.get("-m",0)))
        sh=int(L*val) if opts.get("-pct") else int(val)
        chromlen=sizes.get(r.chrom,10**18); width=r.end-r.start
        s=max(0,min(r.start+sh,chromlen-width)); e=s+width
        f=list(r.f); f[1]=str(s); f[2]=str(e); emit(f)

def help_main():
    print("""bedtools is a powerful toolset for genome arithmetic.

Version:   b2e3657
Usage:     bedtools <subcommand> [options]

The bedtools sub-commands include:
    intersect     Find overlapping intervals in various ways.
    window        Find overlapping intervals within a window around an interval.
    closest       Find the closest, potentially non-overlapping interval.
    coverage      Compute the coverage over defined intervals.
    map           Apply a function to a column for each overlapping interval.
    genomecov     Compute the coverage over an entire genome.
    merge         Combine overlapping/nearby intervals into a single interval.
    complement    Extract intervals not represented by an interval file.
    shift         Adjust the position of intervals.
    subtract      Remove intervals based on overlaps b/w two files.
    slop          Adjust the size of intervals.
    flank         Create new intervals from the flanks of existing intervals.
    sort          Order the intervals in a file.
    makewindows   Make interval windows across a genome.
    groupby       Group by common cols. and summarize other cols.
    spacing       Report the gap lengths between intervals in a file.
    jaccard       Calculate the Jaccard statistic b/w two sets of intervals.
""")

def main():
    if len(sys.argv)<2 or sys.argv[1] in ("--help","-h","help"):
        help_main(); return
    if sys.argv[1]=="--version":
        print(VERSION); return
    if sys.argv[1]=="--contact":
        print("For help, see http://bedtools.readthedocs.io/"); return
    cmd=sys.argv[1]; args=sys.argv[2:]
    if args and args[0] in ("-h","--help"):
        print(f"Tool:    bedtools {cmd}\nVersion: b2e3657\n"); return
    table={
        "intersect":cmd_intersect, "intersectBed":cmd_intersect,
        "merge":cmd_merge, "mergeBed":cmd_merge,
        "sort":cmd_sort, "sortBed":cmd_sort,
        "complement":cmd_complement, "complementBed":cmd_complement,
        "makewindows":cmd_makewindows,
        "closest":cmd_closest, "closestBed":cmd_closest,
        "slop":lambda a: cmd_slop(a,False), "slopBed":lambda a: cmd_slop(a,False),
        "flank":lambda a: cmd_slop(a,True), "flankBed":lambda a: cmd_slop(a,True),
        "subtract":cmd_subtract, "subtractBed":cmd_subtract,
        "coverage":cmd_coverage, "coverageBed":cmd_coverage,
        "genomecov":cmd_genomecov, "genomeCoverageBed":cmd_genomecov,
        "map":cmd_map, "mapBed":cmd_map,
        "groupby":cmd_groupby, "groupBy":cmd_groupby,
        "jaccard":cmd_jaccard,
        "window":cmd_window, "windowBed":cmd_window,
        "spacing":cmd_spacing,
        "shift":cmd_shift, "shiftBed":cmd_shift,
    }
    if cmd in ("random","shuffle","sample"):
        random.seed(1); return
    if cmd not in table: die(f"*****ERROR: Unrecognized command: {cmd} *****")
    table[cmd](args)

if __name__ == "__main__":
    main()
