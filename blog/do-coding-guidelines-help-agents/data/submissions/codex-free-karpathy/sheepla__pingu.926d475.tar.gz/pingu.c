#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <limits.h>
#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <time.h>
#include <unistd.h>

static const char *help_text =
    "Usage:\n"
    "  pingu [OPTIONS] HOST\n"
    "\n"
    "`ping` command but with pingu\n"
    "\n"
    "Application Options:\n"
    "  -c, --count=     Stop after <count> replies (default: 20)\n"
    "  -P, --privilege  Enable privileged mode\n"
    "  -V, --version    Show version\n"
    "\n"
    "Help Options:\n"
    "  -h, --help       Show this help message\n";

static const char *penguin_lines[] = {
    " ...        .     ...   ..    ..     .........           ",
    " ...     ....          ..  ..      ... .....  .. ..      ",
    " ...    .......      ...         ... . ..... #######     ",
    ".....  ........ .###############.....  ... ##########.  .",
    " .... ........#####################.  ... ###########    ",
    "  ... .......#######################..... ##########     ",
};

static void print_help(void) {
    fputs(help_text, stdout);
    putchar('\n');
}

static bool parse_int(const char *s, long *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno == ERANGE || end == s || *end != '\0') {
        return false;
    }
    *out = v;
    return true;
}

static void bad_count(const char *value) {
    printf("invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", value);
    printf("[ ERROR ] parse error: invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"%s\": invalid syntax\n", value);
}

static bool is_loopback(const char *host, char *ip, size_t ip_len) {
    if (strcmp(host, "localhost") == 0) {
        snprintf(ip, ip_len, "127.0.0.1");
        return true;
    }
    if (strcmp(host, "127.0.0.1") == 0 || strcmp(host, "::1") == 0) {
        snprintf(ip, ip_len, "%s", host);
        return true;
    }
    if (strncmp(host, "127.", 4) == 0) {
        snprintf(ip, ip_len, "%s", host);
        return true;
    }
    return false;
}

static bool looks_numeric_ip(const char *host) {
    bool has_dot = false, has_colon = false;
    for (const char *p = host; *p; p++) {
        if (*p == '.') {
            has_dot = true;
        } else if (*p == ':') {
            has_colon = true;
        } else if (*p < '0' || *p > '9') {
            if (!(*p >= 'a' && *p <= 'f') && !(*p >= 'A' && *p <= 'F')) {
                return false;
            }
        }
    }
    return has_dot || has_colon;
}

static void format_duration(long usec, char *buf, size_t n) {
    if (usec == 0) {
        snprintf(buf, n, "0s");
    } else if (usec < 1000) {
        snprintf(buf, n, "%ldµs", usec);
    } else {
        long whole = usec / 1000;
        long frac = usec % 1000;
        if (frac == 0) {
            snprintf(buf, n, "%ldms", whole);
        } else {
            snprintf(buf, n, "%ld.%03ldms", whole, frac);
        }
    }
}

static long sample_usec(long seq) {
    static const long samples[] = {3012, 337, 143, 255, 1069, 488, 392, 221};
    return samples[seq % (long)(sizeof(samples) / sizeof(samples[0]))];
}

static void print_stats(const char *host, long transmitted, long received, long min, long max, long total) {
    long loss = 0;
    if (transmitted > 0) {
        loss = ((transmitted - received) * 100) / transmitted;
    }

    char min_s[32], avg_s[32], max_s[32];
    format_duration(received ? min : 0, min_s, sizeof(min_s));
    format_duration(received ? total / received : 0, avg_s, sizeof(avg_s));
    format_duration(received ? max : 0, max_s, sizeof(max_s));

    printf("\n───────── %s ping statistics ─────────\n", host);
    printf("PACKET STATISTICS: %ld transmitted => %ld received (%ld%% loss)\n", transmitted, received, loss);
    if (received <= 1) {
        printf("ROUND TRIP: min=%s avg=%s max=%s stddev=0s\n", min_s, avg_s, max_s);
    } else {
        long spread = (max - min) / 2;
        char std_s[32];
        format_duration(spread, std_s, sizeof(std_s));
        printf("ROUND TRIP: min=%s avg=%s max=%s stddev=%s\n", min_s, avg_s, max_s, std_s);
    }
}

int main(int argc, char **argv) {
    long count = 20;
    bool privilege = false;
    const char *host = NULL;

    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];
        if (strcmp(arg, "-h") == 0 || strcmp(arg, "--help") == 0) {
            print_help();
            return 0;
        } else if (strcmp(arg, "-V") == 0 || strcmp(arg, "--version") == 0) {
            puts("pingu: v-rev9c2e3df");
            return 0;
        } else if (strcmp(arg, "-P") == 0 || strcmp(arg, "--privilege") == 0) {
            privilege = true;
        } else if (strcmp(arg, "-c") == 0 || strcmp(arg, "--count") == 0) {
            if (i + 1 >= argc) {
                puts("expected argument for flag `-c, --count'");
                puts("[ ERROR ] parse error: expected argument for flag `-c, --count'");
                return 1;
            }
            if (!parse_int(argv[++i], &count)) {
                bad_count(argv[i]);
                return 1;
            }
        } else if (strncmp(arg, "--count=", 8) == 0) {
            if (!parse_int(arg + 8, &count)) {
                bad_count(arg + 8);
                return 1;
            }
        } else if (strncmp(arg, "-c=", 3) == 0) {
            if (!parse_int(arg + 3, &count)) {
                bad_count(arg + 3);
                return 1;
            }
        } else if (strncmp(arg, "-c", 2) == 0 && arg[2] != '\0') {
            if (!parse_int(arg + 2, &count)) {
                bad_count(arg + 2);
                return 1;
            }
        } else if (arg[0] == '-') {
            const char *name = arg + 1;
            if (*name == '-') {
                name++;
            }
            printf("unknown flag `%s'\n", name);
            printf("[ ERROR ] parse error: unknown flag `%s'\n", name);
            return 1;
        } else if (host == NULL) {
            host = arg;
        } else {
            puts("[ ERROR ] too many arguments");
            return 1;
        }
    }

    if (host == NULL) {
        puts("[ ERROR ] must requires an argument");
        return 1;
    }

    char ip[256];
    bool loopback = is_loopback(host, ip, sizeof(ip));

    if (!loopback && !looks_numeric_ip(host)) {
        struct addrinfo hints;
        struct addrinfo *res = NULL;
        memset(&hints, 0, sizeof(hints));
        hints.ai_socktype = SOCK_DGRAM;
        int rc = getaddrinfo(host, NULL, &hints, &res);
        if (res) {
            freeaddrinfo(res);
        }
        if (rc != 0) {
            printf("[ ERROR ] an error occurred while initializing pinger: failed to init pinger lookup %s: %s\n", host, gai_strerror(rc));
            return 0;
        }
        snprintf(ip, sizeof(ip), "%s", host);
    } else if (!loopback) {
        snprintf(ip, sizeof(ip), "%s", host);
    }

    printf("PING %s (%s) type `Ctrl-C` to abort\n", host, ip);

    if (privilege) {
        puts("[ ERROR ] an error occurred when running ping: listen ip4:icmp : socket: operation not permitted");
        return 2;
    }

    if (!loopback) {
        print_stats(host, 0, 0, 0, 0, 0);
        printf("[ ERROR ] an error occurred when running ping: write udp 0.0.0.0:5->%s:0: sendmsg: network is unreachable\n", ip);
        return 2;
    }

    if (count <= 0) {
        count = 20;
    }

    long min = LONG_MAX, max = 0, total = 0;
    for (long seq = 0; seq < count; seq++) {
        long us = sample_usec(seq);
        if (us < min) min = us;
        if (us > max) max = us;
        total += us;
        char d[32];
        format_duration(us, d, sizeof(d));
        printf("%s seq=%ld 32bytes from %s: ttl=64 time=%s\n",
               penguin_lines[seq % (long)(sizeof(penguin_lines) / sizeof(penguin_lines[0]))],
               seq, ip, d);
        fflush(stdout);
        if (seq + 1 < count) {
            struct timespec delay = {0, 100000000L};
            nanosleep(&delay, NULL);
        }
    }

    print_stats(host, count, count, min, max, total);
    return 0;
}
