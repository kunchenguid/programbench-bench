#!/usr/bin/env python3
import argparse
import os
import re
import stat
import sys
import time
from pathlib import Path

VERSION = "ambr 0.6.0"
HELP = """ambr 0.6.0

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
"""

class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\n")
        sys.stderr.write("USAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\n")
        sys.stderr.write("For more information try --help\n")
        raise SystemExit(1)


def parse_bool_config(name):
    vals = {}
    candidates = []
    home = os.path.expanduser("~")
    xdg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    candidates.append(os.path.join(home, ".ambr.toml"))
    candidates.append(os.path.join(xdg, "amber", "ambr.toml"))
    candidates.append("/etc/amber/ambr.toml")
    for fn in candidates:
        try:
            with open(fn, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.split("#", 1)[0].strip()
                    if "=" not in line:
                        continue
                    k, v = [x.strip() for x in line.split("=", 1)]
                    if v.lower() in ("true", "false"):
                        vals[k] = (v.lower() == "true")
        except OSError:
            pass
    return vals


def build_parser():
    p = Parser(add_help=False)
    for opt in ["key-from-file", "rep-from-file", "verbose", "column", "row", "binary", "statistics", "skipped", "preserve-time", "tbm", "sse"]:
        p.add_argument("--" + opt, action="store_true", dest=opt.replace("-", "_"))
    p.add_argument("-r", "--regex", action="store_true")
    for opt in ["interactive", "recursive", "symlink", "color", "file", "skip-vcs", "skip-gitignore", "fixed-order", "parent-ignore"]:
        p.add_argument("--no-" + opt, action="store_false", dest=opt.replace("-", "_"), default=None)
    p.add_argument("--max-threads", default="4")
    p.add_argument("--size-per-thread", default="1048576")
    p.add_argument("--bin-check-bytes", default="256")
    p.add_argument("--mmap-bytes", default="1048576")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("keyword", nargs="?")
    p.add_argument("replacement", nargs="?")
    p.add_argument("paths", nargs="*")
    return p


def apply_defaults(a):
    cfg = parse_bool_config("ambr")
    defaults = {
        "regex": False, "column": False, "row": False, "binary": False,
        "statistics": False, "skipped": False, "interactive": True,
        "recursive": True, "symlink": True, "color": True, "file": True,
        "skip_vcs": True, "skip_gitignore": True, "fixed_order": True,
        "parent_ignore": True, "line_by_match": False,
    }
    for k, v in defaults.items():
        cur = getattr(a, k, None)
        if cur is None or cur is False and k in cfg and defaults[k] is False:
            pass
        if cur is None:
            setattr(a, k, cfg.get(k, v))
        elif k in ("regex", "column", "row", "binary", "statistics", "skipped") and not cur:
            setattr(a, k, cfg.get(k, v))
    return a


def is_binary(path, n):
    try:
        with open(path, "rb") as f:
            return b"\0" in f.read(n)
    except OSError:
        return False


def read_ignore_file(dirpath):
    pats = []
    for name in (".gitignore", ".ignore", ".amberignore"):
        fn = os.path.join(dirpath, name)
        try:
            with open(fn, "r", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    s = line.strip()
                    if not s or s.startswith("#") or s.startswith("!"):
                        continue
                    pats.append(s.rstrip("/"))
        except OSError:
            pass
    return pats


def ignored(path, root, patterns):
    rel = os.path.relpath(path, root)
    base = os.path.basename(path)
    for pat in patterns:
        if pat == base or pat == rel or rel.startswith(pat.rstrip("/") + os.sep):
            return True
        if "*" in pat:
            import fnmatch
            if fnmatch.fnmatch(base, pat) or fnmatch.fnmatch(rel, pat):
                return True
    return False


def collect_files(paths, args):
    out = []
    vcs = {".git", ".hg", ".svn", ".bzr"}
    for start in paths:
        if os.path.isfile(start) or (os.path.islink(start) and os.path.exists(start) and not os.path.isdir(start)):
            out.append(start)
            continue
        if not os.path.isdir(start):
            if args.skipped:
                print(f"Skip: {start}")
            continue
        root = start
        root_ign = read_ignore_file(root) if args.skip_gitignore else []
        if not args.recursive:
            try:
                for name in os.listdir(start):
                    p = os.path.join(start, name)
                    if os.path.isfile(p):
                        out.append(p)
            except OSError:
                pass
            continue
        for dirpath, dirnames, filenames in os.walk(start, followlinks=args.symlink):
            if args.skip_vcs:
                dirnames[:] = [d for d in dirnames if d not in vcs]
            if not args.symlink:
                dirnames[:] = [d for d in dirnames if not os.path.islink(os.path.join(dirpath, d))]
            pats = list(root_ign)
            if args.skip_gitignore and dirpath != root:
                pats += read_ignore_file(dirpath)
            if args.skip_gitignore:
                dirnames[:] = [d for d in dirnames if not ignored(os.path.join(dirpath, d), root, pats)]
            for name in filenames:
                p = os.path.join(dirpath, name)
                if not args.symlink and os.path.islink(p):
                    continue
                if args.skip_gitignore and ignored(p, root, pats):
                    continue
                out.append(p)
    if args.fixed_order:
        out.sort()
    return out


def regex_repl_func(rep):
    def conv(m):
        s = rep
        def braced(x):
            key = x.group(1)
            try:
                return m.group(int(key)) or ""
            except (IndexError, ValueError):
                try:
                    return m.group(key) or ""
                except IndexError:
                    return ""
        s2 = re.sub(r"\$\{([^}]+)\}", braced, s)
        def plain(x):
            key = x.group(1)
            try:
                return m.group(int(key)) or ""
            except (IndexError, ValueError):
                try:
                    return m.group(key) or ""
                except IndexError:
                    return ""
        s2 = re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*|[0-9]+)", plain, s2)
        return s2
    return conv


def line_col(text, idx):
    line = text.count("\n", 0, idx) + 1
    last = text.rfind("\n", 0, idx)
    col = idx if last < 0 else idx - last - 1
    return line, col


def line_text(text, idx):
    start = text.rfind("\n", 0, idx) + 1
    end = text.find("\n", idx)
    if end < 0:
        end = len(text)
    return text[start:end], start


def display_path(p):
    try:
        return os.path.relpath(p)
    except ValueError:
        return p


def find_matches(text, args, keyword):
    if args.regex:
        try:
            return list(re.finditer(keyword, text, flags=re.MULTILINE))
        except re.error as e:
            sys.stderr.write(str(e) + "\n")
            raise SystemExit(1)
    if keyword == "":
        return []
    res = []
    pos = 0
    while True:
        i = text.find(keyword, pos)
        if i < 0:
            break
        res.append((i, i + len(keyword)))
        pos = i + max(1, len(keyword))
    return res


def span_of(m):
    return m.span() if hasattr(m, "span") else m


def replacement_for(args, replacement, m):
    if args.regex and hasattr(m, "group"):
        return regex_repl_func(replacement)(m)
    return replacement


def preview_line(text, m, args, replacement):
    a, b = span_of(m)
    line, start = line_text(text, a)
    ra = a - start
    rb = b - start
    return line[:ra] + replacement_for(args, replacement, m) + line[rb:]


def process_file(path, args, keyword, replacement, all_mode):
    try:
        st = os.stat(path)
        if not args.binary and is_binary(path, int(args.bin_check_bytes)):
            if args.skipped:
                print(f"Skip: {display_path(path)}")
            return False, all_mode
        data = Path(path).read_bytes()
    except OSError:
        if args.skipped:
            print(f"Skip: {display_path(path)}")
        return False, all_mode
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        if args.binary:
            text = data.decode("latin-1")
        else:
            if args.skipped:
                print(f"Skip: {display_path(path)}")
            return False, all_mode
    matches = find_matches(text, args, keyword)
    if not matches:
        return False, all_mode
    replace_flags = [False] * len(matches)
    if not args.interactive or all_mode:
        replace_flags = [True] * len(matches)
    else:
        for i, m in enumerate(matches):
            a, _ = span_of(m)
            ln, col = line_col(text, a)
            orig, _ = line_text(text, a)
            pref = display_path(path) if args.file else ""
            loc = ""
            if args.row and args.column:
                loc = f" {ln}:{col}:"
            elif args.row:
                loc = f" {ln}:"
            elif args.column:
                loc = f" {col}:"
            if pref:
                print(f"{pref}:{loc}{orig}")
            else:
                print(f"{loc}{orig}".lstrip())
            indent = "        " if (args.row or args.column) else "    "
            print(f"{indent}-> {preview_line(text, m, args, replacement)}")
            sys.stdout.write("Replace keyword? [Y]es/[n]o/[a]ll/[q]uit: ")
            sys.stdout.flush()
            ans = sys.stdin.readline()
            if ans == "":
                print("")
                ans = ""
            elif not sys.stdin.isatty():
                print(ans.rstrip("\n"))
            ans = ans.strip().lower()
            if ans in ("q", "quit"):
                break
            if ans in ("a", "all"):
                replace_flags[i:] = [True] * (len(matches) - i)
                all_mode = True
                break
            if ans in ("", "y", "yes"):
                replace_flags[i] = True
    if not any(replace_flags):
        return False, all_mode
    pieces = []
    last = 0
    for flag, m in zip(replace_flags, matches):
        a, b = span_of(m)
        pieces.append(text[last:a])
        pieces.append(replacement_for(args, replacement, m) if flag else text[a:b])
        last = b
    pieces.append(text[last:])
    newtext = "".join(pieces)
    if newtext != text:
        try:
            Path(path).write_text(newtext, encoding="utf-8")
            if args.preserve_time:
                os.utime(path, (st.st_atime, st.st_mtime))
        except OSError:
            return False, all_mode
    return True, all_mode


def stats(args):
    print("\nStatistics")
    print(f"  Max threads: {args.max_threads}\n")
    print("  Consumed time ( busy / total )")
    for name in ["Find", "Match00", "Match01", "Match02", "Match03", "Sort", "Replace"]:
        print(f"    {name:<8}: 0s / 0.000000001s")
    print("")


def main(argv):
    if any(x in ("--help", "-h") for x in argv):
        sys.stdout.write(HELP)
        return 0
    if any(x in ("--version", "-V") for x in argv):
        print(VERSION)
        return 0
    p = build_parser()
    args = apply_defaults(p.parse_args(argv))
    if args.keyword is None or args.replacement is None:
        sys.stderr.write("error: The following required arguments were not provided:\n")
        if args.keyword is None:
            sys.stderr.write("    <KEYWORD>\n")
        if args.replacement is None:
            sys.stderr.write("    <REPLACEMENT>\n")
        sys.stderr.write("\nUSAGE:\n    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>\n\nFor more information try --help\n")
        return 1
    # The reference ambr initializes terminal output before replacing; when stdout
    # is not a terminal, ordinary replace invocations exit unsuccessfully and do nothing.
    if not sys.stdout.isatty():
        return 1
    keyword = args.keyword
    replacement = args.replacement
    if args.key_from_file:
        keyword = Path(keyword).read_text(encoding="utf-8")
    if args.rep_from_file:
        replacement = Path(replacement).read_text(encoding="utf-8")
    paths = args.paths if args.paths else ["."]
    files = collect_files(paths, args)
    changed = False
    all_mode = False
    for f in files:
        ch, all_mode = process_file(f, args, keyword, replacement, all_mode)
        changed = changed or ch
    if args.statistics:
        stats(args)
    # term crate leaves reset sequences on TTY; harmless but improves diff fidelity.
    sys.stdout.write("\x1b(B\x1b[m\x1b(B\x1b[m")
    return 0

if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
