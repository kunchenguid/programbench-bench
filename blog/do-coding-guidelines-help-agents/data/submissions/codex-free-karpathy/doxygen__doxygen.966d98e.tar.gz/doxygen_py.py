#!/usr/bin/env python3
import html
import os
import re
import shutil
import sys
from pathlib import Path

VERSION = "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)"
COPYRIGHT = "Copyright Dimitri van Heesch 1997-2025"
ROOT = Path(__file__).resolve().parent
TEMPLATES = ROOT / "templates"


def prog():
    return sys.argv[0] if sys.argv and sys.argv[0] else "./executable"


def usage():
    p = prog()
    return f"""Doxygen version {VERSION}
{COPYRIGHT}

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    {p} [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    {p} [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    {p} [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    {p} -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        {p} -w rtf styleSheetFile
    HTML:       {p} -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      {p} -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    {p} -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    {p} -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    {p} -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    {p} -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
{p} -d prints additional usage flags for debugging purposes
"""


DEBUG_HELP = """Developer parameters:
  -m          dump symbol map
  -b          making messages output unbuffered
  -c <file>   process input file as a comment block and produce HTML output
  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
\talias
\tcite
\tcommentcnv
\tcommentscan
\tentries
\textcmd
\tfilteroutput
\tformula
\tfortranfixed2free
\tlayout
\tlex
\tlex:code
\tlex:commentcnv
\tlex:commentscan
\tlex:configimpl
\tlex:constexp
\tlex:declinfo
\tlex:defargs
\tlex:doctokenizer
\tlex:fortrancode
\tlex:fortranscanner
\tlex:lexcode
\tlex:lexscanner
\tlex:pre
\tlex:pycode
\tlex:pyscanner
\tlex:scanner
\tlex:sqlcode
\tlex:vhdlcode
\tlex:xml
\tlex:xmlcode
\tmarkdown
\tnolineno
\tplantuml
\tpreprocessor
\tprinttree
\tqhp
\trtf
\tsections
\tstderr
\ttag
\ttime
"""


def read_template(name):
    return (TEMPLATES / name).read_text(encoding="utf-8")


def write_dest(dest, data):
    if dest == "-":
        sys.stdout.write(data)
    else:
        Path(dest).write_text(data, encoding="utf-8")


def generate_config(path, strip_comments):
    name = "small.cfg" if strip_comments else "full.cfg"
    data = read_template(name)
    if path == "-":
        sys.stdout.write(data)
        return
    Path(path).write_text(data, encoding="utf-8")
    print(f"\n\nConfiguration file '{path}' created.\n")
    arg = "" if path == "Doxyfile" else f" {path}"
    print(f"Now edit the configuration file and enter\n\n  doxygen{arg}\n\nto generate the documentation for your project\n")


def parse_config_text(text):
    cfg = {}
    known = set()
    for line in read_template("full.cfg").splitlines():
        m = re.match(r"^([A-Z][A-Z0-9_]+)\s*=", line)
        if m:
            known.add(m.group(1))
    unknown = []
    for idx, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        m = re.match(r"^([A-Za-z][A-Za-z0-9_]*)\s*(\+?=)\s*(.*)$", line)
        if not m:
            continue
        key, op, value = m.groups()
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] == '"':
            value = value[1:-1]
        if key.upper() not in known and key.upper() not in {"INPUT", "OUTPUT_DIRECTORY"}:
            unknown.append((idx, key))
        if op == "+=" and key in cfg and cfg[key]:
            cfg[key] += " " + value
        else:
            cfg[key] = value
    return cfg, unknown


def update_config(path, strip_comments):
    p = Path(path)
    if not p.exists():
        print(f"error: configuration file {path} not found!", file=sys.stderr)
        sys.stderr.write(usage())
        sys.exit(1)
    old = p.read_text(encoding="utf-8", errors="replace") if p.exists() else ""
    cfg, unknown = parse_config_text(old)
    text = read_template("small.cfg" if strip_comments else "full.cfg")
    for key, value in cfg.items():
        if not re.match(r"^[A-Z][A-Z0-9_]*$", key):
            continue
        pattern = re.compile(rf"^({re.escape(key)}\s*=).*$", re.M)
        if pattern.search(text):
            text = pattern.sub(lambda m, v=value: f"{m.group(1)} {v}", text)
    p.write_text(text, encoding="utf-8")
    print(f"\n\nConfiguration file '{path}' updated.\n")
    for line, key in unknown:
        print(f"warning: ignoring unsupported tag '{key}' at line {line}, file {path}", file=sys.stderr)


def config_diff(path):
    print(f"# Difference with default Doxyfile {VERSION}")
    if not path or path == "Doxyfile":
        return
    p = Path(path)
    if not p.exists():
        print(f"error: configuration file '{path}' not found!", file=sys.stderr)
        sys.exit(1)
    cfg, _ = parse_config_text(p.read_text(encoding="utf-8", errors="replace"))
    defaults, _ = parse_config_text(read_template("full.cfg"))
    for key in sorted(cfg):
        if cfg[key] and cfg.get(key) != defaults.get(key):
            print(f"{key:<24} = {cfg[key]}")


def html_page(title, project, body):
    return f"""<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8"/>
<meta name="generator" content="Doxygen 1.17.0"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{html.escape(project)}: {html.escape(title)}</title>
<link href="doxygen.css" rel="stylesheet" type="text/css" />
</head>
<body>
<div id="titlearea"><div id="projectname">{html.escape(project)}</div></div>
<div id="main-nav"><a href="index.html">Main Page</a> | <a href="files.html">Files</a> | <a href="annotated.html">Classes</a></div>
<div class="contents">
{body}
</div>
<hr class="footer"/><address class="footer">Generated by Doxygen 1.17.0</address>
</body>
</html>
"""


def sanitize_file_name(path):
    name = Path(path).name
    return re.sub(r"[^A-Za-z0-9]", "_", name) + ".html"


def class_file_name(name):
    return "class" + re.sub(r"[^A-Za-z0-9_]", "_", name) + ".html"


def strip_comment_marks(text):
    text = re.sub(r"^\s*/\*\*?", "", text)
    text = re.sub(r"\*/\s*$", "", text)
    lines = [re.sub(r"^\s*\* ?", "", l).strip() for l in text.splitlines()]
    return " ".join(l for l in lines if l).strip()


def scan_source(path):
    text = Path(path).read_text(encoding="utf-8", errors="replace")
    comments = []
    for m in re.finditer(r"/\*\*.*?\*/", text, re.S):
        comments.append((m.start(), m.end(), strip_comment_marks(m.group(0))))
    def doc_before(pos):
        prev = ""
        for _, end, doc in comments:
            if end <= pos:
                prev = doc
            else:
                break
        return prev
    code = re.sub(r"/\*.*?\*/", lambda m: " " * (m.end() - m.start()), text, flags=re.S)
    code = re.sub(r"//.*", "", code)
    classes = []
    for m in re.finditer(r"\b(class|struct)\s+([A-Za-z_][A-Za-z0-9_]*)", code):
        classes.append({"kind": m.group(1), "name": m.group(2), "doc": doc_before(m.start())})
    funcs = []
    rx = re.compile(r"(?m)^\s*(?:[A-Za-z_][\w:<>\*&\s]+?\s+)+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^;{}()]*)\)\s*(?:;|\{)")
    for m in rx.finditer(code):
        name = m.group(1)
        if name in {"if", "for", "while", "switch"}:
            continue
        funcs.append({"name": name, "args": m.group(2).strip(), "doc": doc_before(m.start())})
    return text, classes, funcs


def copy_assets(out):
    for name in ["custom.css"]:
        data = read_template(name)
        if name == "custom.css":
            (out / "doxygen.css").write_text(data, encoding="utf-8")
    placeholders = {
        "tabs.css": "body{font-family:sans-serif}\n",
        "navtree.css": "",
        "dynsections.js": "",
        "clipboard.js": "",
        "cookie.js": "",
        "menu.js": "",
        "menudata.js": "var menudata=[];\n",
        "navtree.js": "",
        "navtreedata.js": "var NAVTREE=[];\n",
        "navtreeindex0.js": "",
        "doxygen.svg": "<svg xmlns='http://www.w3.org/2000/svg'></svg>\n",
        "doxygen_crawl.html": "<!DOCTYPE html><html><body></body></html>\n",
    }
    for name, data in placeholders.items():
        (out / name).write_text(data, encoding="utf-8")


def run_docs(config_path, quiet=False):
    if not Path(config_path).exists():
        print(f"error: configuration file {config_path} not found!", file=sys.stderr)
        sys.stderr.write(usage())
        sys.exit(1)
    text = Path(config_path).read_text(encoding="utf-8", errors="replace")
    cfg, unknown = parse_config_text(text)
    for line, key in unknown:
        print(f"warning: ignoring unsupported tag '{key}' at line {line}, file {config_path}", file=sys.stderr)
    project = cfg.get("PROJECT_NAME") or "My Project"
    outdir = Path(cfg.get("OUTPUT_DIRECTORY") or ".")
    html_dir = outdir / "html"
    html_dir.mkdir(parents=True, exist_ok=True)
    copy_assets(html_dir)
    inputs = cfg.get("INPUT", "").split()
    if not inputs:
        candidates = [p for p in Path(".").iterdir() if p.suffix.lower() in {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".java", ".py", ".md"}]
    else:
        candidates = []
        for item in inputs:
            p = Path(item)
            if p.is_dir():
                candidates.extend([x for x in p.rglob("*") if x.suffix.lower() in {".c", ".cc", ".cpp", ".cxx", ".h", ".hpp", ".java", ".py", ".md"}])
            elif p.exists():
                candidates.append(p)
    all_classes = []
    all_funcs = []
    file_links = []
    for src in candidates:
        try:
            source, classes, funcs = scan_source(src)
        except OSError:
            continue
        fname = sanitize_file_name(src)
        file_links.append((src, fname))
        all_classes.extend([(c, src) for c in classes])
        all_funcs.extend([(f, src) for f in funcs])
        body = f"<h1>{html.escape(str(src))} File Reference</h1><pre>{html.escape(source)}</pre>"
        (html_dir / fname).write_text(html_page(str(src), project, body), encoding="utf-8")
        (html_dir / (fname.replace(".html", "_source.html"))).write_text(html_page(str(src) + " Source", project, body), encoding="utf-8")
    for c, src in all_classes:
        body = f"<h1>{html.escape(c['name'])} {html.escape(c['kind'])} Reference</h1>"
        if c["doc"]:
            body += f"<p>{html.escape(c['doc'])}</p>"
        body += f"<p>Declared in <a href='{sanitize_file_name(src)}'>{html.escape(str(src))}</a>.</p>"
        (html_dir / class_file_name(c["name"])).write_text(html_page(c["name"], project, body), encoding="utf-8")
        (html_dir / (class_file_name(c["name"]).replace(".html", "-members.html"))).write_text(html_page(c["name"] + " Members", project, body), encoding="utf-8")
    index_body = f"<h1>{html.escape(project)} Documentation</h1><a href='doxygen_crawl.html'></a>"
    (html_dir / "index.html").write_text(html_page("Main Page", project, index_body), encoding="utf-8")
    files_body = "<h1>File List</h1><ul>" + "".join(f"<li><a href='{fn}'>{html.escape(str(src))}</a></li>" for src, fn in file_links) + "</ul>"
    (html_dir / "files.html").write_text(html_page("File List", project, files_body), encoding="utf-8")
    class_body = "<h1>Class List</h1><ul>" + "".join(f"<li><a href='{class_file_name(c['name'])}'>{html.escape(c['name'])}</a></li>" for c, _ in all_classes) + "</ul>"
    (html_dir / "annotated.html").write_text(html_page("Class List", project, class_body), encoding="utf-8")
    funcs_body = "<h1>Functions</h1><ul>" + "".join(f"<li>{html.escape(f['name'])}({html.escape(f['args'])})</li>" for f, _ in all_funcs) + "</ul>"
    for name in ["functions.html", "functions_func.html", "globals.html", "globals_func.html"]:
        (html_dir / name).write_text(html_page("Functions", project, funcs_body), encoding="utf-8")
    for name in ["annotated_dup.js", "files_dup.js"]:
        (html_dir / name).write_text("var data=[];\n", encoding="utf-8")
    if not candidates and not quiet and cfg.get("QUIET", "NO").upper() != "YES":
        print("warning: No files to be processed, please check your settings, in particular INPUT, FILE_PATTERNS, and RECURSIVE")


def write_comment_html(path):
    data = Path(path).read_text(encoding="utf-8", errors="replace")
    print("<p>" + html.escape(strip_comment_marks(data)) + "</p>")


def main(argv):
    args = list(argv)
    if not args:
        cfg = "Doxyfile"
        if not Path(cfg).exists():
            print("error: Doxyfile not found and no input file specified!", file=sys.stderr)
            sys.stderr.write(usage())
            return 1
        run_docs(cfg)
        return 0
    if args[0] in ("-h", "-?", "--help"):
        sys.stdout.write(usage())
        return 0
    if args[0] == "-v":
        print(VERSION)
        return 0
    if args[0] == "-V":
        print(VERSION)
        print("    with sqlite3 3.42.0.")
        return 0
    if args[0] == "-d" and len(args) == 1:
        sys.stdout.write(DEBUG_HELP)
        return 0
    if args[0] == "-c" and len(args) > 1:
        write_comment_html(args[1])
        return 0
    strip = False
    if args and args[0] == "-s":
        strip = True
        args = args[1:]
    if args and args[0] == "-g":
        generate_config(args[1] if len(args) > 1 else "Doxyfile", strip)
        return 0
    if args and args[0] == "-u":
        update_config(args[1] if len(args) > 1 else "Doxyfile", strip)
        return 0
    if args[0] == "-l":
        write_dest(args[1] if len(args) > 1 else "DoxygenLayout.xml", read_template("layout.xml"))
        return 0
    if args[0] == "-e":
        if len(args) < 2:
            print('error: option "-e" is missing format specifier rtf', file=sys.stderr)
            return 1
        if args[1] != "rtf":
            print('error: option "-e" has invalid format specifier', file=sys.stderr)
            return 1
        write_dest(args[2] if len(args) > 2 else "-", read_template("ext.rtf"))
        return 0
    if args[0] == "-f":
        if len(args) < 2:
            print('error: option "-f" is missing list specifier.', file=sys.stderr)
            return 1
        if args[1] != "emoji":
            print('error: option "-f" has invalid list specifier.', file=sys.stderr)
            return 1
        write_dest(args[2] if len(args) > 2 else "-", read_template("emoji.txt"))
        return 0
    if args[0] == "-w":
        if len(args) < 2:
            print('error: option "-w" is missing format specifier rtf, html or latex', file=sys.stderr)
            return 1
        fmt = args[1]
        if fmt == "rtf":
            if len(args) < 3:
                print('error: option "-w rtf" does not have enough arguments', file=sys.stderr)
                return 1
            write_dest(args[2], read_template("rtfstyle.rtf"))
            return 0
        if fmt == "html":
            if len(args) < 5:
                print('error: option "-w html" does not have enough arguments', file=sys.stderr)
                return 1
            for dest, name in zip(args[2:5], ["header.html", "footer.html", "custom.css"]):
                write_dest(dest, read_template(name))
            return 0
        if fmt == "latex":
            if len(args) < 5:
                print('error: option "-w latex" does not have enough arguments', file=sys.stderr)
                return 1
            for dest, name in zip(args[2:5], ["header.tex", "footer.tex", "style.sty"]):
                write_dest(dest, read_template(name))
            return 0
        print(f'error: option "-w" has invalid format specifier {fmt}', file=sys.stderr)
        return 1
    if args[0] in ("-x", "-x_noenv"):
        config_diff(args[1] if len(args) > 1 else "Doxyfile")
        return 0
    if args[0] == "-q":
        cfg = args[1] if len(args) > 1 else "Doxyfile"
        run_docs(cfg, quiet=True)
        return 0
    if args[0].startswith("-"):
        print(f'error: Unknown option "{args[0]}"', file=sys.stderr)
        sys.stderr.write(usage())
        return 1
    run_docs(args[0])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
