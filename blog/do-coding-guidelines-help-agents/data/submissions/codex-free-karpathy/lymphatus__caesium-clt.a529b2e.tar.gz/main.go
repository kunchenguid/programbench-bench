package main

import (
    "bytes"
    "fmt"
    "image"
    "image/color"
    "image/draw"
    "image/gif"
    "image/jpeg"
    "image/png"
    _ "image/gif"
    _ "image/jpeg"
    _ "image/png"
    "math"
    "os"
    "path/filepath"
    "sort"
    "strconv"
    "strings"
    "time"
)

type opts struct {
    qualitySet bool
    quality int
    lossless bool
    maxSizeSet bool
    maxSize int64
    width, height int
    longEdge, shortEdge int
    noUpscale bool
    output string
    sameFolder bool
    format string
    pngLevel int
    suffix string
    recursive bool
    keepStructure bool
    dryRun bool
    threads int
    overwrite string
    minSavingsSet bool
    minSavings string
    quiet bool
    verbose int
    keepDates bool
    files []string
}

const helpLong = `A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...
          Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality

      --lossless
          Use lossless compression (may increase file size for some formats)

      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)

      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)

      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image

      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image

      --no-upscale
          Prevents upscaling of the image when resizing

  -o, --output <OUTPUT>
          Output directory path

      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)

      --format <FORMAT>
          Convert to the selected output format or keep the original
          
          [default: original]
          [possible values: jpeg, png, gif, webp, tiff, original]

      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression
          
          [default: 3]

      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files
          
          [default: auto]
          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)

      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)

  -e, --exif
          Keep EXIF metadata during compression

      --keep-dates
          Preserve original file timestamps

      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag

      --suffix <SUFFIX>
          Add suffix to output filenames

  -R, --recursive
          Scan subfolders recursively when input is a directory

  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)

  -d, --dry-run
          Simulate compression without writing files

      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors)
          
          [default: 0]

  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files

          Possible values:
          - all:    Always overwrite existing files
          - never:  Never overwrite existing files
          - bigger: Overwrite only if the existing file is bigger
          
          [default: all]

      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

  -Q, --quiet
          Suppress all output

      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
          
          [default: 1]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version`

func main() {
    o, code := parseArgs(os.Args[1:])
    if code >= 0 { os.Exit(code) }
    inputs := collectInputs(o)
    var totalIn, totalOut int64
    success, skipped, errs := 0,0,0
    for _, in := range inputs {
        orig, err := os.ReadFile(in)
        if err != nil { errs++; continue }
        outPath := outputPath(o, in)
        candidate, err := transform(orig, in, o)
        if err != nil { errs++; continue }
        writeIt := true
        if o.overwrite == "never" {
            if _, err := os.Stat(outPath); err == nil { writeIt = false }
        } else if o.overwrite == "bigger" {
            if st, err := os.Stat(outPath); err == nil && st.Size() <= int64(len(candidate)) { writeIt = false }
        }
        if writeIt && o.minSavingsSet && !meetsMinSavings(int64(len(orig)), int64(len(candidate)), o.minSavings) { writeIt = false }
        totalIn += int64(len(orig))
        if writeIt { totalOut += int64(len(candidate)); success++ } else { totalOut += int64(len(orig)); skipped++ }
        if writeIt && !o.dryRun {
            os.MkdirAll(filepath.Dir(outPath), 0755)
            if err := os.WriteFile(outPath, candidate, 0644); err != nil { success--; errs++; continue }
            if o.keepDates { if st, err := os.Stat(in); err == nil { os.Chtimes(outPath, time.Now(), st.ModTime()) } }
        }
    }
    if !o.quiet && o.verbose > 0 {
        fmt.Printf("Compressed %d files (%d success, %d skipped, %d errors)\n", len(inputs), success, skipped, errs)
        delta := totalOut-totalIn
        sign := "-"; val := -delta
        if delta > 0 { sign = "+"; val = delta }
        pct := 0.0
        if totalIn > 0 { pct = float64(delta)*100/float64(totalIn) }
        fmt.Printf("%s -> %s [%s%s | %+.2f%%]\n", human(totalIn), human(totalOut), sign, human(val), pct)
    }
    if errs > 0 && success == 0 { os.Exit(1) }
}

func parseArgs(args []string) (opts, int) {
    o := opts{format:"original", pngLevel:3, overwrite:"all", verbose:1}
    for i:=0; i<len(args); i++ {
        a:=args[i]
        need := func(name string) string { if i+1>=len(args){ cliErr(fmt.Sprintf("a value is required for '%s <VALUE>' but none was supplied", name)); os.Exit(2)}; i++; return args[i] }
        switch a {
        case "-h": fmt.Println(strings.Replace(helpLong, "Print help (see a summary with '-h')", "Print help (see more with '--help')", 1)); return o,0
        case "--help": fmt.Println(helpLong); return o,0
        case "-V", "--version": fmt.Println("caesiumclt 1.3.0"); return o,0
        case "-q", "--quality":
            if o.lossless { conflict("--quality <QUALITY>", "--lossless") }
            if o.maxSizeSet { conflict("--quality <QUALITY>", "--max-size <MAX_SIZE>") }
            s:=need("--quality"); n,err:=strconv.Atoi(s); if err!=nil { cliErr(fmt.Sprintf("invalid value '%s' for '--quality <QUALITY>': '%s' is not a valid number", s,s)); return o,2 }
            if n<0 || n>100 { cliErr(fmt.Sprintf("invalid value '%s' for '--quality <QUALITY>': Quality must be between 0 and 100, but got %d", s,n)); return o,2 }
            o.qualitySet=true; o.quality=n
        case "--lossless": if o.qualitySet { conflict("--quality <QUALITY>", "--lossless") }; if o.maxSizeSet { conflict("--lossless", "--max-size <MAX_SIZE>") }; o.lossless=true
        case "--max-size": if o.qualitySet { conflict("--quality <QUALITY>", "--max-size <MAX_SIZE>") }; if o.lossless { conflict("--lossless", "--max-size <MAX_SIZE>") }; s:=need("--max-size"); n,err:=parseSize(s); if err!=nil { cliErr(fmt.Sprintf("invalid value '%s' for '--max-size <MAX_SIZE>': Invalid size format: couldn't parse \"%s\" into a ByteSize, cannot parse float from empty string", s,s)); return o,2 }; o.maxSizeSet=true; o.maxSize=n
        case "--width": if o.longEdge>0 { conflict("--width <WIDTH>", "--long-edge <LONG_EDGE>") }; if o.shortEdge>0 { conflict("--width <WIDTH>", "--short-edge <SHORT_EDGE>") }; o.width=atoiFlag(a, need(a))
        case "--height": if o.longEdge>0 { conflict("--height <HEIGHT>", "--long-edge <LONG_EDGE>") }; if o.shortEdge>0 { conflict("--height <HEIGHT>", "--short-edge <SHORT_EDGE>") }; o.height=atoiFlag(a, need(a))
        case "--long-edge": if o.width>0 { conflict("--width <WIDTH>", "--long-edge <LONG_EDGE>") }; if o.height>0 { conflict("--height <HEIGHT>", "--long-edge <LONG_EDGE>") }; if o.shortEdge>0 { conflict("--long-edge <LONG_EDGE>", "--short-edge <SHORT_EDGE>") }; o.longEdge=atoiFlag(a, need(a))
        case "--short-edge": if o.width>0 { conflict("--width <WIDTH>", "--short-edge <SHORT_EDGE>") }; if o.height>0 { conflict("--height <HEIGHT>", "--short-edge <SHORT_EDGE>") }; if o.longEdge>0 { conflict("--long-edge <LONG_EDGE>", "--short-edge <SHORT_EDGE>") }; o.shortEdge=atoiFlag(a, need(a))
        case "--no-upscale": o.noUpscale=true
        case "-o", "--output": if o.sameFolder { conflict("--output <OUTPUT>", "--same-folder-as-input") }; o.output=need("--output")
        case "--same-folder-as-input": if o.output!="" { conflict("--output <OUTPUT>", "--same-folder-as-input") }; o.sameFolder=true
        case "--format": s:=need("--format"); if !in(s, []string{"jpeg","png","gif","webp","tiff","original"}) { cliErr(fmt.Sprintf("invalid value '%s' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]", s)); return o,2 }; o.format=s
        case "--png-opt-level": o.pngLevel=atoiFlag(a, need(a)); if o.pngLevel<0 || o.pngLevel>6 { cliErr(fmt.Sprintf("invalid value for '%s'", a)); return o,2 }
        case "--jpeg-chroma-subsampling": _ = need(a)
        case "--threads": o.threads=atoiFlag(a, need(a))
        case "--verbose": o.verbose=atoiFlag(a, need(a))
        case "--jpeg-baseline", "--zopfli", "-e", "--exif", "--strip-icc":
        case "--keep-dates": o.keepDates=true
        case "--suffix": o.suffix=need("--suffix")
        case "-R", "--recursive": o.recursive=true
        case "-S", "--keep-structure": o.keepStructure=true
        case "-d", "--dry-run": o.dryRun=true
        case "-O", "--overwrite": s:=need("--overwrite"); if !in(s, []string{"all","never","bigger"}) { cliErr(fmt.Sprintf("invalid value '%s' for '--overwrite <OVERWRITE>'", s)); return o,2 }; o.overwrite=s
        case "--min-savings": o.minSavingsSet=true; o.minSavings=need("--min-savings")
        case "-Q", "--quiet": o.quiet=true; o.verbose=0
        default:
            if strings.HasPrefix(a,"-") { cliErr(fmt.Sprintf("unexpected argument '%s' found", a)); return o,2 }
            o.files=append(o.files,a)
        }
    }
    if !(o.qualitySet || o.lossless || o.maxSizeSet) || !(o.output!="" || o.sameFolder) { required(o); return o,2 }
    return o,-1
}

func cliErr(s string){ fmt.Fprintf(os.Stderr,"error: %s\n\nFor more information, try '--help'.\n", s) }
func conflict(a,b string){ fmt.Fprintf(os.Stderr,"error: the argument '%s' cannot be used with '%s'\n\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...\n\nFor more information, try '--help'.\n", a,b); os.Exit(2) }
func required(o opts){ fmt.Fprintln(os.Stderr,"error: the following required arguments were not provided:"); if !(o.qualitySet||o.lossless||o.maxSizeSet){ fmt.Fprintln(os.Stderr,"  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>") }; if !(o.output!=""||o.sameFolder){ fmt.Fprintln(os.Stderr,"  <--output <OUTPUT>|--same-folder-as-input>") }; fmt.Fprintln(os.Stderr,"\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...\n\nFor more information, try '--help'.") }
func atoiFlag(name,s string) int { n,err:=strconv.Atoi(s); if err!=nil { cliErr(fmt.Sprintf("invalid value '%s' for '%s': '%s' is not a valid number", s,name,s)); os.Exit(2) }; return n }
func in(s string, xs []string) bool { for _,x:= range xs { if s==x { return true } }; return false }

func collectInputs(o opts) []string {
    var out []string
    for _, p := range o.files {
        st, err := os.Stat(p); if err!=nil { continue }
        if st.IsDir() {
            if o.recursive {
                filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error { if err==nil && !d.IsDir() && supportedInput(path) { out=append(out,path) }; return nil })
            } else {
                ents,_:=os.ReadDir(p); for _,e:=range ents { q:=filepath.Join(p,e.Name()); if !e.IsDir() && supportedInput(q) { out=append(out,q) } }
            }
        } else if supportedInput(p) { out=append(out,p) }
    }
    sort.Strings(out)
    return out
}
func supportedInput(p string) bool { e:=strings.ToLower(filepath.Ext(p)); return in(e, []string{".jpg",".jpeg",".png",".gif",".webp"}) }

func outputPath(o opts, in string) string {
    dir := o.output; if o.sameFolder { dir=filepath.Dir(in) }
    if !o.sameFolder && o.keepStructure && o.recursive {
        relDir := filepath.Dir(in)
        if filepath.IsAbs(relDir) {
            relDir = strings.TrimPrefix(relDir, string(filepath.Separator))
        }
        if relDir != "." {
            dir = filepath.Join(dir, relDir)
        }
    }
    base:=filepath.Base(in); ext:=filepath.Ext(base); stem:=strings.TrimSuffix(base, ext)
    outExt:=ext
    switch o.format { case "jpeg": outExt=".jpg"; case "png": outExt=".png"; case "gif": outExt=".gif"; case "webp": outExt=".webp"; case "tiff": outExt=".tiff" }
    return filepath.Join(dir, stem+o.suffix+outExt)
}

func transform(data []byte, path string, o opts) ([]byte,error) {
    ext := strings.ToLower(filepath.Ext(path))
    target := o.format
    if target=="original" { if ext==".jpg"||ext==".jpeg" {target="jpeg"} else if ext==".png" {target="png"} else if ext==".gif" {target="gif"} else { return data,nil } }
    if o.lossless && o.format=="original" && o.width==0 && o.height==0 && o.longEdge==0 && o.shortEdge==0 {
        return data, nil
    }
    img, _, err := image.Decode(bytes.NewReader(data))
    if err != nil { return data,nil }
    img = resizeIfNeeded(img, o)
    if o.qualitySet && !o.lossless && (target=="png" || target=="gif") {
        img = palettize(img, o.quality)
    }
    var b bytes.Buffer
    switch target {
    case "jpeg":
        q:=o.quality; if o.lossless { q=100 }; if o.maxSizeSet { q=75 }; if q<=0 && !o.qualitySet { q=80 }; if q<1 { q=1 }
        rgb := image.NewRGBA(img.Bounds()); draw.Draw(rgb, rgb.Bounds(), image.NewUniform(color.White), image.Point{}, draw.Src); draw.Draw(rgb, rgb.Bounds(), img, img.Bounds().Min, draw.Over)
        jpeg.Encode(&b, rgb, &jpeg.Options{Quality:q})
    case "png":
        enc := png.Encoder{CompressionLevel: png.DefaultCompression}
        if o.lossless { enc.CompressionLevel = png.BestCompression }
        if o.pngLevel <= 1 { enc.CompressionLevel = png.BestSpeed } else if o.pngLevel >= 5 { enc.CompressionLevel = png.BestCompression }
        enc.Encode(&b, img)
    case "gif":
        gif.Encode(&b, img, nil)
    case "webp":
        png.Encode(&b, img)
    case "tiff":
        png.Encode(&b, img)
    default:
        b.Write(data)
    }
    if b.Len()==0 { return data,nil }
    if o.maxSizeSet && int64(b.Len()) > o.maxSize && (target=="jpeg") {
        for q:=70; q>=5; q-=10 { b.Reset(); jpeg.Encode(&b, img, &jpeg.Options{Quality:q}); if int64(b.Len()) <= o.maxSize { break } }
    }
    return b.Bytes(), nil
}

func resizeIfNeeded(img image.Image, o opts) image.Image {
    b:=img.Bounds(); w,h:=b.Dx(),b.Dy(); nw,nh:=w,h
    if o.width>0 && o.height>0 { nw,nh=o.width,o.height
    } else if o.width>0 { nw=o.width; nh=int(math.Round(float64(h)*float64(nw)/float64(w)))
    } else if o.height>0 { nh=o.height; nw=int(math.Round(float64(w)*float64(nh)/float64(h)))
    } else if o.longEdge>0 { if w>=h { nw=o.longEdge; nh=int(math.Round(float64(h)*float64(nw)/float64(w))) } else { nh=o.longEdge; nw=int(math.Round(float64(w)*float64(nh)/float64(h))) }
    } else if o.shortEdge>0 { if w<=h { nw=o.shortEdge; nh=int(math.Round(float64(h)*float64(nw)/float64(w))) } else { nh=o.shortEdge; nw=int(math.Round(float64(w)*float64(nh)/float64(h))) } }
    if nw<1 {nw=1}; if nh<1 {nh=1}
    if o.noUpscale && (nw>w || nh>h) { return img }
    if nw==w && nh==h { return img }
    dst:=image.NewRGBA(image.Rect(0,0,nw,nh))
    for y:=0;y<nh;y++{ sy:=b.Min.Y + y*h/nh; for x:=0;x<nw;x++{ sx:=b.Min.X + x*w/nw; dst.Set(x,y,img.At(sx,sy)) } }
    return dst
}

func palettize(img image.Image, quality int) image.Image {
    b := img.Bounds()
    maxColors := 64
    if quality >= 90 {
        maxColors = 256
    } else if quality >= 70 {
        maxColors = 128
    } else if quality < 35 {
        maxColors = 32
    }
    palette := make(color.Palette, 0, maxColors)
    index := map[uint32]uint8{}
    dst := image.NewPaletted(image.Rect(0, 0, b.Dx(), b.Dy()), nil)
    for y := 0; y < b.Dy(); y++ {
        for x := 0; x < b.Dx(); x++ {
            r, g, bb, a := img.At(b.Min.X+x, b.Min.Y+y).RGBA()
            if a < 0x8000 {
                r, g, bb = 0xffff, 0xffff, 0xffff
            }
            key := uint32((r>>13)<<5 | (g>>13)<<2 | (bb>>14))
            idx, ok := index[key]
            if !ok {
                if len(palette) < maxColors {
                    cr := uint8(((key >> 5) & 7) * 255 / 7)
                    cg := uint8(((key >> 2) & 7) * 255 / 7)
                    cb := uint8((key & 3) * 255 / 3)
                    palette = append(palette, color.RGBA{cr, cg, cb, 255})
                    idx = uint8(len(palette)-1)
                    index[key] = idx
                } else {
                    idx = uint8(key % uint32(maxColors))
                }
            }
            dst.Pix[y*dst.Stride+x] = idx
        }
    }
    dst.Palette = palette
    return dst
}

func parseSize(s string)(int64,error){
    lower:=strings.ToLower(strings.TrimSpace(s)); mult:=float64(1); num:=lower
    units:=[]struct{u string;m float64}{{"kib",1024},{"mib",1024*1024},{"gib",1024*1024*1024},{"kb",1000},{"mb",1000*1000},{"gb",1000*1000*1000},{"b",1}}
    for _,u:=range units{ if strings.HasSuffix(lower,u.u){ mult=u.m; num=strings.TrimSpace(strings.TrimSuffix(lower,u.u)); break } }
    f,err:=strconv.ParseFloat(num,64); if err!=nil {return 0,err}; return int64(f*mult),nil
}
func meetsMinSavings(orig,out int64,s string) bool{
    saved:=orig-out; if saved<0 { saved=0 }
    if strings.HasSuffix(s,"%") { f,err:=strconv.ParseFloat(strings.TrimSuffix(s,"%"),64); if err!=nil {return true}; if orig==0 {return false}; return float64(saved)*100/float64(orig) >= f }
    n,err:=parseSize(s); if err!=nil { return true }; return saved>=n
}
func human(n int64) string{ if n<1024 { return fmt.Sprintf("%d B", n) }; if n<1024*1024 { return fmt.Sprintf("%.1f KiB", float64(n)/1024) }; return fmt.Sprintf("%.1f MiB", float64(n)/(1024*1024)) }
