#!/usr/bin/env python3
import base64
import calendar
import datetime as _dt
import hashlib
import hmac
import os
import re
import sys
from pathlib import Path

VERSION = "commit-93cc85d16ab60ba8d646458fe0233778317b22a3"
DEFAULT_CONFIG = os.path.expanduser("~/.caps-log/config.ini")
DEFAULT_LOG_DIR = os.path.expanduser("~/.caps-log/day/")
DEFAULT_LOG_FORMAT = "d%y_%m_%d.md"
MAGIC = b"CAPSLOG1\n"

HELP = f"""Captain's Log (caps-log)! A CLI journalig tool.
Version: {VERSION}
Allowed options:
  -h [ --help ]         show this message
  -c [ --config ] arg   override the default config file path 
                        ({DEFAULT_CONFIG})
  --log-dir-path arg    path where log files are stored
  --log-name-format arg format in which log entry markdown files are saved
  --sunday-start        have the calendar display sunday as first day of the 
                        week
  --first-line-section  override the default behaviour of ignoring sections 
                        (lines starting with `#`) in the first line of a log 
                        entry file
  --password arg        password for encrypted log repositories or to be used 
                        with --encrypt/--decrypt
  --encrypt             apply encryption to all logs in log dir path (needs 
                        --password)
  --decrypt             apply decryption to all logs in log dir path (needs 
                        --password)
"""

TAKES_VALUE = {
    "-c": "--config",
    "--config": "--config",
    "--log-dir-path": "--log-dir-path",
    "--log-name-format": "--log-name-format",
    "--password": "--password",
}
FLAGS = {"-h", "--help", "--sunday-start", "--first-line-section", "--encrypt", "--decrypt"}


def fail(msg, code=1):
    print("Captain's log encountered an error: ")
    print(f" {msg}")
    return code


def parse_args(argv):
    opts = {
        "--config": DEFAULT_CONFIG,
        "--log-dir-path": None,
        "--log-name-format": None,
        "--password": None,
        "--help": False,
        "--sunday-start": False,
        "--first-line-section": False,
        "--encrypt": False,
        "--decrypt": False,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            opts["--help"] = True
            i += 1
        elif arg in TAKES_VALUE:
            canonical = TAKES_VALUE[arg]
            if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                return None, f"the required argument for option '{canonical}' is missing"
            opts[canonical] = argv[i + 1]
            i += 2
        elif arg in FLAGS:
            opts[arg] = True
            i += 1
        else:
            return None, f"unrecognised option '{arg}'"
    return opts, None


def read_config(path):
    data = {}
    section = ""
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    for raw in p.read_text(errors="replace").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or line.startswith(";"):
            continue
        if line.startswith("[") and line.endswith("]"):
            section = line[1:-1].strip()
            continue
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.split("#", 1)[0].strip()
        full_key = f"{section}.{key}" if section else key
        data[full_key] = value
        data[key] = value
    return data


def bool_value(v):
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def expand_path(s):
    return os.path.expandvars(os.path.expanduser(s))


def marker_path(log_dir):
    return Path(log_dir) / ".cle"


def key_stream(password, n):
    out = bytearray()
    counter = 0
    seed = password.encode()
    while len(out) < n:
        out.extend(hashlib.sha256(seed + counter.to_bytes(8, "big")).digest())
        counter += 1
    return bytes(out[:n])


def crypt_bytes(data, password):
    ks = key_stream(password, len(data))
    return bytes(a ^ b for a, b in zip(data, ks))


def log_regex(fmt):
    escaped = re.escape(fmt)
    escaped = escaped.replace("%Y", r"(?P<Y>\d{4})")
    escaped = escaped.replace("%y", r"(?P<y>\d{2})")
    escaped = escaped.replace("%m", r"(?P<m>\d{1,2})")
    escaped = escaped.replace("%d", r"(?P<d>\d{1,2})")
    return re.compile("^" + escaped + "$")


def date_from_name(name, fmt):
    m = log_regex(fmt).match(name)
    if not m:
        return None
    gd = m.groupdict()
    try:
        year = int(gd.get("Y") or (2000 + int(gd.get("y", "0"))))
        return _dt.date(year, int(gd.get("m") or 1), int(gd.get("d") or 1))
    except ValueError:
        return None


def iter_log_files(log_dir, fmt):
    root = Path(log_dir)
    if not root.exists():
        return []
    files = []
    for p in root.iterdir():
        if p.is_file() and date_from_name(p.name, fmt):
            files.append(p)
    return sorted(files)


def apply_crypto(log_dir, fmt, password, decrypt=False):
    print("Applying crypto...")
    if not password:
        return fail("--password is required")
    root = Path(log_dir)
    root.mkdir(parents=True, exist_ok=True)
    marker = marker_path(root)
    files = iter_log_files(root, fmt)
    if decrypt:
        if not marker.exists():
            return fail("Already applied")
        raw = marker.read_bytes()
        if not raw.startswith(MAGIC):
            return fail("Wrong password")
        body = raw[len(MAGIC):]
        mac, payload = body[:32], body[32:]
        expected = hmac.new(password.encode(), payload, hashlib.sha256).digest()
        if not hmac.compare_digest(mac, expected):
            return fail("Wrong password")
        decoded = base64.b64decode(crypt_bytes(payload, password))
        entries = decoded.split(b"\0\0")
        for entry in entries:
            if not entry:
                continue
            name, content = entry.split(b"\0", 1)
            (root / name.decode()).write_bytes(content)
        marker.unlink()
        return 0
    if marker.exists():
        return fail("Already applied")
    packed = bytearray()
    for p in files:
        packed.extend(p.name.encode() + b"\0" + p.read_bytes() + b"\0\0")
    payload = crypt_bytes(base64.b64encode(bytes(packed)), password)
    mac = hmac.new(password.encode(), payload, hashlib.sha256).digest()
    marker.write_bytes(MAGIC + mac + payload)
    return 0


def parse_sections_tags(text, first_line_section):
    sections = []
    tags = []
    current = "<root section>"
    for idx, raw in enumerate(text.splitlines()):
        line = raw.strip()
        if line.startswith("#") and (idx != 0 or first_line_section):
            current = line.lstrip("#").strip() or "<root section>"
            if current not in sections:
                sections.append(current)
        elif line.startswith("*"):
            tag = line.lstrip("*").strip()
            tag = tag.split(":", 1)[0].strip()
            tag = re.sub(r"\s*\([^)]*\)\s*$", "", tag).strip()
            if tag and tag not in tags:
                tags.append(tag)
            if current not in sections:
                sections.append(current)
    return sections, tags


def normal_view(log_dir, fmt, sunday_start, first_line_section):
    today = _dt.date.today()
    files = iter_log_files(log_dir, fmt)
    this_year = [p for p in files if date_from_name(p.name, fmt).year == today.year]
    sections = []
    tags = []
    preview = ""
    todays_file = None
    for p in files:
        if date_from_name(p.name, fmt) == today:
            todays_file = p
            break
    for p in files:
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        ss, tt = parse_sections_tags(text, first_line_section)
        for s in ss:
            if s not in sections:
                sections.append(s)
        for t in tt:
            if t not in tags:
                tags.append(t)
    if todays_file:
        preview = todays_file.read_text(errors="replace")
    print(f"       Today is: {today.day:02d}. {today.month:02d}. {today.year}.  | There are {len(this_year)} log entries for year {today.year}.")
    print("Sections:")
    print("> <select none>")
    for s in sections:
        print(f"  {s}")
    print("Tags:")
    print("> <select none>")
    for t in tags:
        print(f"  {t}")
    first = 6 if sunday_start else 0
    print(calendar.TextCalendar(firstweekday=first).formatyear(today.year, 2, 1, 1, 3).rstrip())
    print(f"log preview for {today.day:02d}. {today.month:02d}. {today.year % 100:02d}.")
    if preview:
        print(preview, end="" if preview.endswith("\n") else "\n")
    return 0


def main(argv):
    opts, err = parse_args(argv)
    if err:
        return fail(err)
    if opts["--help"]:
        print(HELP, end="")
        return 0
    try:
        cfg = read_config(opts["--config"])
    except FileNotFoundError:
        return fail(f"Failed to open file: {opts['--config']}")
    if bool_value(cfg.get("enable-git-log-repo", "false")):
        if not cfg.get("ssh-key-path"):
            return fail("SSH key path can not be empty!")
        if not cfg.get("ssh-pub-key-path"):
            return fail("SSH pub key path can not be empty!")
    log_dir = expand_path(opts["--log-dir-path"] or cfg.get("log-dir-path", DEFAULT_LOG_DIR))
    fmt = opts["--log-name-format"] or cfg.get("log-filename-format") or cfg.get("log-name-format") or DEFAULT_LOG_FORMAT
    sunday = opts["--sunday-start"] or bool_value(cfg.get("sunday-start", "false"))
    first_line = opts["--first-line-section"] or bool_value(cfg.get("first-line-section", "false"))
    password = opts["--password"] if opts["--password"] is not None else cfg.get("password")
    if opts["--encrypt"] or opts["--decrypt"]:
        return apply_crypto(log_dir, fmt, password, decrypt=opts["--decrypt"])
    return normal_view(log_dir, fmt, sunday, first_line)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
