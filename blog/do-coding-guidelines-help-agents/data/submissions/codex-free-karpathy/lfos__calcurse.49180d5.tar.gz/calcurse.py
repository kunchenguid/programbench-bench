#!/usr/bin/env python3
import sys, os, re, hashlib, calendar
from datetime import datetime, date, time, timedelta

VERSION = "calcurse 4.8.2 -- text-based organizer\n\nCopyright (c) 2004-2023 calcurse Development Team.\nThis is free software; see the source for copying conditions.\n"
HELP = """Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Note that filter, format and day-range options affect input or output:
  --filter-*              Filter items loaded by -Q, -G, -P and -x
  --format-*              Rewrite output from -Q, -G and --dump-imported
  --from <date>           Limit day range of -Q.
  --to <date>             Limit day range of -Q.
  --days <number>         Limit day range of -Q.

  --limit, -l <number>    Limit number of query results
  --search, -S <regexp>   Match regular expression in queries
Consult the man page for details.

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>.
"""

class Item:
    def __init__(self, typ, raw, msg="", start=None, end=None, days=1, prio=1, note="", recur=None):
        self.typ, self.raw, self.msg, self.start, self.end = typ, raw.rstrip("\n"), msg, start, end
        self.days, self.prio, self.note, self.recur = days, prio, note, recur
    def hash(self):
        return hashlib.sha1((self.raw + "\n").encode()).hexdigest()

def today():
    return date.today()

def parse_date(s, fmt=1):
    s = s.strip().lower()
    base = today()
    if s in ("today", "now"): return base
    if s == "tomorrow": return base + timedelta(days=1)
    if s == "yesterday": return base - timedelta(days=1)
    wds = ["mon","tue","wed","thu","fri","sat","sun"]
    if s[:3] in wds:
        target = wds.index(s[:3]); delta = (target - base.weekday()) % 7
        return base + timedelta(days=delta)
    nums = list(map(int, re.findall(r"\d+", s)))
    if len(nums) < 3: raise ValueError("invalid date")
    if fmt == 4 or "-" in s and re.match(r"\d{4}-", s): y,m,d = nums[0],nums[1],nums[2]
    elif fmt == 3: y,m,d = nums[0],nums[1],nums[2]
    elif fmt == 2: d,m,y = nums[0],nums[1],nums[2]
    else: m,d,y = nums[0],nums[1],nums[2]
    return date(y,m,d)

def parse_dt(d, hm, fmt=1):
    h, m = map(int, hm.split(":"))
    return datetime.combine(parse_date(d, fmt), time(h, m))

def date_s(d, full=False):
    return d.strftime("%m/%d/%Y" if full else "%m/%d/%y")
def dt_s(dt):
    return dt.strftime("%m/%d/%Y @ %H:%M")

APT_RE = re.compile(r"^(.+?) @ (\d\d?:\d\d) -> (.+?) @ (\d\d?:\d\d)(?:\s+(\{[^}]+\}))?(?:>([0-9a-fA-F]+)\s*)?\|(.*)$")
EV_RE = re.compile(r"^(.+?) \[(\d+)\](?:\s+(\{[^}]+\}))?(?:\s+>([0-9a-fA-F]+))?\s*(.*)$")
TODO_RE = re.compile(r"^\[(-?\d+)\]\s*(.*)$")

def parse_recur(txt):
    if not txt: return None
    inner = txt.strip("{} ")
    parts = inner.split()
    m = re.match(r"(\d+)([DWMY])", parts[0])
    if not m: return None
    r = {"n": int(m.group(1)), "unit": m.group(2), "until": None, "except": set(), "w": []}
    i = 1
    while i < len(parts):
        p = parts[i]
        if p == "->" and i + 1 < len(parts):
            r["until"] = parse_date(parts[i+1]); i += 2; continue
        if p.startswith("!"):
            try: r["except"].add(parse_date(p[1:]))
            except Exception: pass
        elif p.startswith("w") and p[1:].lstrip("-").isdigit():
            r["w"].append(int(p[1:]))
        i += 1
    return r

def read_items(datadir, calfile=None, inputfmt=1):
    items = []
    ap = calfile or os.path.join(datadir, "apts")
    if os.path.exists(ap):
        for line in open(ap, encoding="utf-8", errors="replace"):
            line=line.rstrip("\n")
            if not line: continue
            m=APT_RE.match(line)
            if m:
                st=parse_dt(m.group(1),m.group(2),inputfmt); en=parse_dt(m.group(3),m.group(4),inputfmt)
                items.append(Item("recur-apt" if m.group(5) else "apt", line, m.group(7), st, en, note=m.group(6) or "", recur=parse_recur(m.group(5))))
                continue
            m=EV_RE.match(line)
            if m:
                st=datetime.combine(parse_date(m.group(1),inputfmt), time())
                items.append(Item("recur-event" if m.group(3) else "event", line, m.group(5), st, st+timedelta(days=int(m.group(2))), int(m.group(2)), note=m.group(4) or "", recur=parse_recur(m.group(3))))
    tp = os.path.join(datadir, "todo")
    if os.path.exists(tp):
        for line in open(tp, encoding="utf-8", errors="replace"):
            line=line.rstrip("\n")
            m=TODO_RE.match(line)
            if m: items.append(Item("todo", line, m.group(2), prio=int(m.group(1))))
    return items

def add_month(d, n):
    m = d.month - 1 + n; y = d.year + m // 12; mo = m % 12 + 1
    return date(y, mo, min(d.day, calendar.monthrange(y, mo)[1]))

def occurrences(item, frm, to):
    if item.typ == "todo": return []
    dur = item.end - item.start
    starts = [item.start]
    if item.recur:
        starts=[]; r=item.recur; cur=item.start.date(); endlim=r["until"] or to
        hard = min(endlim, to + timedelta(days=3660))
        if r["unit"] == "W" and r["w"]:
            cur = item.start.date()
            while cur <= hard:
                if cur >= item.start.date() and ((cur - item.start.date()).days // 7) % r["n"] == 0:
                    # calcurse uses Sunday=0; Python Monday=0.
                    cw = (cur.weekday() + 1) % 7
                    if cw in r["w"] and cur not in r["except"]:
                        starts.append(datetime.combine(cur, item.start.time()))
                cur += timedelta(days=1)
        else:
            while cur <= hard:
                if cur not in r["except"]:
                    starts.append(datetime.combine(cur, item.start.time()))
                if r["unit"] == "D": cur += timedelta(days=r["n"])
                elif r["unit"] == "W": cur += timedelta(weeks=r["n"])
                elif r["unit"] == "M": cur = add_month(cur, r["n"])
                else:
                    try: cur = date(cur.year + r["n"], cur.month, cur.day)
                    except ValueError: cur = date(cur.year + r["n"], cur.month, 28)
    out=[]
    for st in starts:
        en=st+dur
        d=frm
        while d<=to:
            if st.date() <= d <= en.date() and not (en.time()==time() and d==en.date() and d!=st.date()):
                if item.typ.endswith("event"):
                    if d == st.date(): out.append((d, st, en))
                else:
                    day0=datetime.combine(d,time()); day1=day0+timedelta(days=1)
                    if st < day1 and en > day0: out.append((d, st, en))
            d += timedelta(days=1)
    return out

def decode_fmt(s):
    return s.replace("\\n","\n").replace("\\t","\t")

def apply_fmt(fmt, item, st=None, en=None, day=None, notes_dir=None):
    fmt=decode_fmt(fmt)
    def ext(m):
        name=m.group(1).split(":",1)[0]
        arg=m.group(1).split(":",1)[1] if ":" in m.group(1) else ""
        if name == "raw": return item.raw + "\n"
        if name == "hash": return item.hash()
        if name == "start": return str(int((st or item.start).timestamp())) if arg in ("","epoch") else (st or item.start).strftime(arg)
        if name == "end": return str(int((en or item.end).timestamp())) if arg in ("","epoch") else (en or item.end).strftime(arg)
        if name == "duration": return str(int((item.end-item.start).total_seconds()))
        return m.group(0)
    fmt=re.sub(r"%\(([^)]+)\)", ext, fmt)
    note_text=""
    if item.note and notes_dir:
        try: note_text=open(os.path.join(notes_dir,item.note), encoding="utf-8").read()
        except Exception: note_text=""
    vals = {
        "%m": item.msg, "%n": item.note, "%N": note_text, "%p": str(abs(item.prio)),
        "%d": str(int((item.end-item.start).total_seconds())) if item.start else "",
        "%s": str(int((st or item.start).timestamp())) if item.start else "",
        "%e": str(int((en or item.end).timestamp())) if item.end else "",
    }
    if st and en and day:
        vals["%S"] = "..:.." if st.date() < day else st.strftime("%H:%M")
        vals["%E"] = "..:.." if en.date() > day else en.strftime("%H:%M")
    elif item.start:
        vals["%S"], vals["%E"] = item.start.strftime("%H:%M"), item.end.strftime("%H:%M")
    for k,v in vals.items(): fmt=fmt.replace(k,v)
    return fmt

def type_match(item, spec):
    if not spec: return True
    want=set()
    for p in spec.split(","):
        if p=="cal": want.update(["event","apt","recur-event","recur-apt"])
        elif p=="recur": want.update(["recur-event","recur-apt"])
        else: want.add(p)
    return item.typ in want

def filtered(items, opts):
    res=[]
    pat = re.compile(opts.get("pattern","")) if opts.get("pattern") else None
    for it in items:
        ok=type_match(it, opts.get("type"))
        if pat and not pat.search(it.msg): ok=False
        if opts.get("prio") is not None and abs(it.prio)!=opts["prio"]: ok=False
        if opts.get("completed") and not (it.typ=="todo" and it.prio<0): ok=False
        if opts.get("uncompleted") and not (it.typ=="todo" and it.prio>0): ok=False
        h=opts.get("hash")
        if h:
            neg=h.startswith("!"); s=h[1:] if neg else h
            ok = ok and (not it.hash().startswith(s) if neg else it.hash().startswith(s))
        if opts.get("invert"): ok=not ok
        if ok: res.append(it)
    return res

def query(items, frm, to, opts, datadir, only_cal=False, only_todo=False, t_header=None):
    out=[]; limit=opts.get("limit"); count=0
    todos=[i for i in items if i.typ=="todo"]
    if not only_cal and todos:
        out.append(("completed tasks:" if t_header=="completed" else "to do:")+"\n")
        for it in todos:
            if limit is not None and count >= limit: break
            out.append(apply_fmt(opts.get("fmt_todo","%p. %m\n"), it, notes_dir=os.path.join(datadir,"notes"))); count+=1
        out.append("\n")
    if not only_todo:
        d=frm
        while d<=to:
            occ=[]
            for it in items:
                if it.typ!="todo": occ += [(it,)+o for o in occurrences(it,d,d)]
            occ.sort(key=lambda x:(0 if x[0].typ.endswith("event") else 1, x[1], x[0].msg))
            if occ:
                out.append(date_s(d)+":\n")
                for it, day, st, en in occ:
                    fmt=opts.get("fmt_event"," * %m\n") if it.typ.endswith("event") else opts.get("fmt_apt"," - %S -> %E\n\t%m\n")
                    out.append(apply_fmt(fmt,it,st,en,d,os.path.join(datadir,"notes")))
                out.append("\n")
            d += timedelta(days=1)
    sys.stdout.write("".join(out).rstrip("\n") + ("\n" if out else ""))

def export_ical(items):
    print("BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//calcurse//NONSGML v4.8.2//EN")
    for it in items:
        if it.typ.endswith("event"):
            print("BEGIN:VEVENT"); print("DTSTART;VALUE=DATE:"+it.start.strftime("%Y%m%d")); print("SUMMARY:"+it.msg); print("END:VEVENT")
        elif it.typ.endswith("apt"):
            print("BEGIN:VEVENT"); print("DTSTART:"+it.start.strftime("%Y%m%dT%H%M%S")); print("DTEND:"+it.end.strftime("%Y%m%dT%H%M%S")); print("SUMMARY:"+it.msg); print("END:VEVENT")
        elif it.typ=="todo":
            print("BEGIN:VTODO"); print("SUMMARY:"+it.msg); print("PRIORITY:"+str(abs(it.prio))); print("END:VTODO")
    print("END:VCALENDAR")

def unfold_ics(path):
    lines=[]
    for l in open(path, encoding="utf-8", errors="replace"):
        l=l.rstrip("\r\n")
        if l.startswith((" ","\t")) and lines: lines[-1]+=l[1:]
        else: lines.append(l)
    return lines

def parse_ics_dt(v):
    v=v.split(":",1)[-1].strip()
    if "T" in v:
        return datetime.strptime(v.replace("Z","")[:15], "%Y%m%dT%H%M%S")
    return datetime.combine(datetime.strptime(v[:8], "%Y%m%d").date(), time())

def parse_ics_duration(v):
    m=re.match(r"P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$", v.strip())
    if not m: return timedelta()
    d,h,mi,s=[int(x or 0) for x in m.groups()]
    return timedelta(days=d, hours=h, minutes=mi, seconds=s)

def import_ical(path, datadir, quiet=False):
    os.makedirs(datadir, exist_ok=True); os.makedirs(os.path.join(datadir,"notes"), exist_ok=True)
    blocks=[]; cur=None
    for l in unfold_ics(path):
        if l in ("BEGIN:VEVENT","BEGIN:VTODO"): cur={"kind":l[6:]}
        elif l.startswith("END:") and cur: blocks.append(cur); cur=None
        elif cur is not None and ":" in l:
            k,v=l.split(":",1); base=k.split(";",1)[0].upper(); cur[base]=v; cur[base+"_RAW"]=k
    apts=[]; todos=[]
    for b in blocks:
        msg=b.get("SUMMARY","")
        if b["kind"]=="VTODO": todos.append(f"[{b.get('PRIORITY','1')}] {msg}")
        else:
            ds=b.get("DTSTART"); de=b.get("DTEND") or b.get("DUE")
            if not ds: continue
            st=parse_ics_dt(ds)
            if "VALUE=DATE" in b.get("DTSTART_RAW","") or ("T" not in ds and len(ds.strip())<=8):
                days=1
                if de: days=max(1,(parse_ics_dt(de).date()-st.date()).days)
                apts.append(f"{date_s(st.date(),True)} [{days}] {msg}")
            else:
                en=parse_ics_dt(de) if de else st + parse_ics_duration(b.get("DURATION",""))
                apts.append(f"{dt_s(st)} -> {dt_s(en)}|{msg}")
    if apts: open(os.path.join(datadir,"apts"),"a",encoding="utf-8").write("\n".join(apts)+"\n")
    if todos: open(os.path.join(datadir,"todo"),"a",encoding="utf-8").write("\n".join(todos)+"\n")
    if not quiet: print(f"Import process report: {len(apts)} appointments, {len(todos)} todos")

def main(argv):
    datadir=os.path.expanduser("~/.calcurse") if os.path.isdir(os.path.expanduser("~/.calcurse")) else os.path.expanduser("~/.local/share/calcurse")
    calfile=None; mode=None; from_d=today(); to_d=today(); inputfmt=1; opts={}; quiet=False; import_file=None; export=False; only_cal=False; only_todo=False; t_header=None
    i=0
    while i < len(argv):
        a=argv[i]
        def val():
            nonlocal i
            if i+1>=len(argv): return ""
            i+=1; return argv[i]
        if a in ("-h","--help"): print(HELP, end=""); return 0
        elif a in ("-v","--version"): print(VERSION, end=""); return 0
        elif a=="--status": print("calcurse is not running"); return 0
        elif a=="--daemon": return 0
        elif a in ("-D","--datadir"): datadir=val()
        elif a in ("-c","--calendar"): calfile=val()
        elif a in ("-C","--confdir","--output-datefmt"): val()
        elif a=="--input-datefmt": inputfmt=int(val())
        elif a in ("-q","--quiet","--read-only"): quiet=True
        elif a in ("-Q","--query"): mode="query"
        elif a in ("-G","--grep"): mode="grep"
        elif a in ("-P","--purge","-F","--filter"): mode="purge"
        elif a in ("-a","--appointment"): mode="query"; opts["type"]="cal"; only_cal=True
        elif a in ("-d","--day"):
            mode="query"; opts["type"]="cal"; only_cal=True; v=val()
            if re.fullmatch(r"-?\d+", v):
                n=int(v); from_d=today()+(timedelta(days=n+1) if n<0 else timedelta()); to_d=today()+timedelta(days=n-1 if n>0 else 0)
            else: from_d=to_d=parse_date(v,inputfmt)
        elif a.startswith("-d") and len(a)>2:
            argv.insert(i+1,a[2:]); argv[i]="-d"; i-=1
        elif a in ("-r","--range") or a.startswith("-r"):
            mode="query"; opts["type"]="cal"; only_cal=True; v=a[2:] if a.startswith("-r") and len(a)>2 else ("1" if a=="-r" else val())
            n=int(v or "1"); from_d=today()+(timedelta(days=n+1) if n<0 else timedelta()); to_d=today()+timedelta(days=n-1 if n>0 else 0)
        elif a in ("-s","--startday") or a.startswith("-s"):
            mode="query"; opts["type"]="cal"; only_cal=True; v=a[2:] if a.startswith("-s") and len(a)>2 else None
            from_d=to_d=parse_date(v,inputfmt) if v else today()
        elif a in ("-t","--todo") or (a.startswith("-t") and len(a)>2):
            mode="query"; opts["type"]="todo"; only_todo=True; v=a[2:] if a.startswith("-t") and len(a)>2 else None
            if v is None and i+1 < len(argv) and re.fullmatch(r"\d+", argv[i+1]): v=val()
            if v is None: opts["uncompleted"]=True
            elif int(v)==0: opts["completed"]=True; t_header="completed"
            else: opts["uncompleted"]=True; opts["prio"]=int(v)
        elif a in ("-n","--next"): mode="next"
        elif a in ("-i","--import"): import_file=val()
        elif a.startswith("-x") and a != "-x": export=True
        elif a in ("-x","--export"): export=True
        elif a=="--from": from_d=parse_date(val(),inputfmt); to_d=from_d
        elif a=="--to": to_d=parse_date(val(),inputfmt)
        elif a=="--days":
            n=int(val()); from_d = from_d if from_d else today(); to_d=from_d+timedelta(days=n-1 if n>0 else 0)
            if n<0: from_d,to_d=to_d,from_d
        elif a in ("-l","--limit"): opts["limit"]=int(val())
        elif a in ("-S","--search","--filter-pattern"): opts["pattern"]=val()
        elif a=="--filter-type": opts["type"]=val()
        elif a=="--filter-priority": opts["prio"]=int(val())
        elif a=="--filter-completed": opts["completed"]=True
        elif a=="--filter-uncompleted": opts["uncompleted"]=True
        elif a=="--filter-invert": opts["invert"]=True
        elif a=="--filter-hash": opts["hash"]=val()
        elif a=="--format-apt": opts["fmt_apt"]=val()
        elif a=="--format-recur-apt": opts["fmt_apt"]=val()
        elif a=="--format-event": opts["fmt_event"]=val()
        elif a=="--format-recur-event": opts["fmt_event"]=val()
        elif a=="--format-todo": opts["fmt_todo"]=val()
        elif a=="-g" or a=="--gc": return 0
        else:
            sys.stderr.write(f"{os.path.basename(sys.argv[0])}: invalid option -- '{a.lstrip('-')[:1]}'\n")
            print(HELP, end=""); return 1
        i+=1
    if import_file: import_ical(import_file, datadir, quiet); return 0
    items=filtered(read_items(datadir,calfile,inputfmt), opts)
    if export: export_ical(items); return 0
    if mode=="grep":
        fmt_default="%(raw)"
        order = {"todo": 0, "apt": 1, "recur-apt": 1, "event": 2, "recur-event": 2}
        def gkey(pair):
            idx, x = pair
            return (order.get(x.typ, 9), idx if x.typ == "todo" else 0, x.start or datetime.min, idx)
        for _, it in sorted(enumerate(items), key=gkey):
            fmt=opts.get("fmt_todo" if it.typ=="todo" else "fmt_event" if it.typ.endswith("event") else "fmt_apt", fmt_default)
            sys.stdout.write(apply_fmt(fmt,it,notes_dir=os.path.join(datadir,"notes")))
        return 0
    if mode=="purge":
        # Keep the nonmatching records. This mirrors the destructive option well enough for scripts.
        allitems=read_items(datadir,calfile,inputfmt); matched=filtered(allitems, opts); remove=set(id(x) for x in matched)
        kept=[x.raw for x in allitems if id(x) not in remove and x.typ!="todo"]
        keptt=[x.raw for x in allitems if id(x) not in remove and x.typ=="todo"]
        open(calfile or os.path.join(datadir,"apts"),"w").write("\n".join(kept)+("\n" if kept else ""))
        open(os.path.join(datadir,"todo"),"w").write("\n".join(keptt)+("\n" if keptt else ""))
        return 0
    if mode=="next":
        future=[]
        now=datetime.now()
        for it in items:
            if it.typ!="todo":
                for _,st,en in occurrences(it, now.date(), (now+timedelta(days=1)).date()):
                    if st>=now: future.append((st,it))
        if future:
            st,it=min(future); delta=st-now; mins=int(delta.total_seconds()//60)
            print(f"{mins//60:02d}:{mins%60:02d}\t{it.msg}")
        return 0
    if mode=="query":
        query(items, from_d, to_d, opts, datadir, only_cal, only_todo, t_header); return 0
    print(HELP, end="")
    return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
