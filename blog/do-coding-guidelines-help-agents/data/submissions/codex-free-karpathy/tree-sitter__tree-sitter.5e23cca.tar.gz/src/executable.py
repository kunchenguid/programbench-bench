#!/usr/bin/env python3
import json
import os
import re
import shutil
import sys
from pathlib import Path


VERSION = "tree-sitter 0.27.0"


TOP_HELP = """tree-sitter 0.27.0
Max Brunsfeld <maxbrunsfeld@gmail.com>
Amaan Qureshi <amaanq12@gmail.com>
Generates and tests parsers

Usage: executable <COMMAND>

Commands:
  init-config     Generate a default config file
  init            Initialize a grammar repository
  generate        Generate a parser
  build           Compile a parser
  parse           Parse files
  test            Run a parser's tests
  version         Display or increment the version of a grammar
  fuzz            Fuzz a parser
  query           Search files using a syntax tree query
  highlight       Highlight a file
  tags            Generate a list of tags
  playground      Start local playground for a parser in the browser
  dump-languages  Print info about all known language parsers
  complete        Generate shell completions

Options:
  -h, --help     Print help
  -V, --version  Print version"""


HELP = {
    "init-config": """Generate a default config file

Usage: executable init-config

Options:
  -h, --help  Print help""",
    "init": """Initialize a grammar repository

Usage: executable init [OPTIONS]

Options:
  -u, --update                       Update outdated files
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
  -h, --help                         Print help""",
    "generate": """Generate a parser

Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

Arguments:
  [GRAMMAR_PATH]  The path to the grammar file

Options:
  -l, --log
          Show debug log during generation
      --abi <VERSION>
          Select the language ABI version to generate (default 15).
          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
      --no-parser
          Only generate `grammar.json` and `node-types.json`
  -b, --build
          Deprecated: use the `build` command
  -0, --debug-build
          Deprecated: use the `build` command
      --libdir <PATH>
          Deprecated: use the `build` command
  -o, --output <DIRECTORY>
          The path to output the generated source files
      --report-states-for-rule <REPORT_STATES_FOR_RULE>
          Produce a report of the states for the given rule, use `-` to report every rule
      --json
          Deprecated: use --json-summary
      --json-summary
          Report conflicts in a JSON format
      --js-runtime <EXECUTABLE>
          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
      --disable-optimizations
          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
  -h, --help
          Print help""",
    "build": """Compile a parser

Usage: executable build [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to the grammar directory

Options:
  -w, --wasm             Build a Wasm module instead of a dynamic library
  -o, --output <OUTPUT>  The path to output the compiled file
      --reuse-allocator  Make the parser reuse the same allocator as the library
  -0, --debug            Compile a parser in debug mode
  -v, --verbose          Display verbose build information
  -h, --help             Print help""",
    "parse": """Parse files

Usage: executable parse [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --dot                          Output the parse data with graphviz dot
  -x, --xml                          Output the parse data in XML format
  -c, --cst                          Output the parse data in a pretty-printed CST format
  -s, --stat                         Show parsing statistic
      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --edits <EDITS>...             Apply edits in the format: \\"row,col|position delcount insert_text\\", can be supplied multiple times
      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --json                         Deprecated: use --json-summary
  -j, --json-summary                 Output parsing results in a JSON format
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
      --no-ranges                    Omit ranges in the output
  -h, --help                         Print help""",
    "test": """Run a parser's tests

Usage: executable test [OPTIONS]

Options:
  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
      --file-name <FILE_NAME>        Only run corpus test cases from a given filename
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
  -u, --update                       Update all syntax trees in corpus files with current parser output
  -d, --debug                        Show parsing debug log
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
      --show-fields                  Force showing fields in test diffs
      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
  -r, --rebuild                      Force rebuild the parser
      --overview-only                Show only the pass-fail overview tree
      --json-summary                 Output the test summary in a JSON format
  -h, --help                         Print help""",
    "version": """Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]
          The version to bump to
          
          Examples:
              tree-sitter version: display the current version
              tree-sitter version <version>: bump to specified version
              tree-sitter version --bump <level>: automatic bump

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory

      --bump <BUMP>
          Automatically bump from the current version
          
          [possible values: patch, minor, major]

  -h, --help
          Print help (see a summary with '-h')""",
    "fuzz": """Fuzz a parser

Usage: executable fuzz [OPTIONS]

Options:
  -s, --skip <SKIP>                  List of test names to skip
      --subdir <SUBDIR>              Subdirectory to the language
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
      --log-graphs                   Enable logging of graphs and input
  -l, --log                          Enable parser logging
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help""",
    "query": """Search files using a syntax tree query

Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

Arguments:
  <QUERY_PATH>  Path to a file with queries
  [PATHS]...    The source file(s) to use

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>
          The path to the parser's dynamic library
      --lang-name <LANG_NAME>
          If `--lib-path` is used, the name of the language used to extract the library's language function
  -t, --time
          Measure execution time
  -q, --quiet
          Suppress main output
      --paths <PATHS_FILE>
          The path to a file with paths to source file(s)
      --byte-range <BYTE_RANGE>
          The range of byte offsets in which the query will be executed
      --row-range <ROW_RANGE>
          The range of rows in which the query will be executed
      --containing-byte-range <CONTAINING_BYTE_RANGE>
          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned
      --containing-row-range <CONTAINING_ROW_RANGE>
          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned
      --scope <SCOPE>
          Select a language by the scope instead of a file extension
  -c, --captures
          Order by captures instead of matches
      --test
          Whether to run query tests or not
      --config-path <CONFIG_PATH>
          The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>
          Query the contents of a specific test
  -r, --rebuild
          Force rebuild the parser
  -h, --help
          Print help""",
    "highlight": """Highlight a file

Usage: executable highlight [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
  -H, --html                           Generate highlighting as an HTML document
      --css-classes                    When generating HTML, use css classes rather than inline styles
      --check                          Check that highlighting captures conform strictly to standards
      --captures-path <CAPTURES_PATH>  The path to a file with captures
      --query-paths <QUERY_PATHS>...   The paths to files with queries
      --scope <SCOPE>                  Select a language by the scope instead of a file extension
  -t, --time                           Measure execution time
  -q, --quiet                          Suppress main output
      --paths <PATHS_FILE>             The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>      The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
  -r, --rebuild                        Force rebuild the parser
      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
  -h, --help                           Print help""",
    "tags": """Generate a list of tags

Usage: executable tags [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help""",
    "playground": """Start local playground for a parser in the browser

Usage: executable playground [OPTIONS]

Options:
  -q, --quiet                        Don't open in default browser
      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
  -h, --help                         Print help""",
    "dump-languages": """Print info about all known language parsers

Usage: executable dump-languages [OPTIONS]

Options:
      --config-path <CONFIG_PATH>  The path to an alternative config.json file
  -h, --help                       Print help""",
    "complete": """Generate shell completions

Usage: executable complete --shell <SHELL>

Options:
  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
  -h, --help           Print help""",
}


COMMANDS = list(HELP.keys())


CONFIG = {
    "parser-directories": [
        str(Path.home() / "github"),
        str(Path.home() / "src"),
        str(Path.home() / "source"),
        str(Path.home() / "projects"),
        str(Path.home() / "dev"),
        str(Path.home() / "git"),
    ],
    "theme": {
        "attribute": {"color": 124, "italic": True},
        "comment": {"color": 245, "italic": True},
        "constant": 94,
        "constant.builtin": {"bold": True, "color": 94},
        "constructor": 136,
        "embedded": None,
        "function": 26,
        "function.builtin": {"bold": True, "color": 26},
        "keyword": 56,
        "module": 136,
        "number": {"bold": True, "color": 94},
        "operator": {"bold": True, "color": 239},
        "property": 124,
        "property.builtin": {"bold": True, "color": 124},
        "punctuation": 239,
        "punctuation.bracket": 239,
        "punctuation.delimiter": 239,
        "punctuation.special": 239,
        "string": 28,
        "string.special": 30,
        "tag": 18,
        "type": 23,
        "type.builtin": {"bold": True, "color": 23},
        "variable": 252,
        "variable.builtin": {"bold": True, "color": 252},
        "variable.parameter": {"color": 252, "underline": True},
    },
}


def eprint(text=""):
    print(text, file=sys.stderr)


def error(message, caused_by=None, code=1):
    eprint(f"\033[31mError:\033[0m {message}")
    if caused_by:
        eprint("")
        eprint("Caused by:")
        for line in caused_by.splitlines():
            eprint(f"    {line}")
    return code


def arg_after(args, names):
    for i, arg in enumerate(args):
        if arg in names and i + 1 < len(args):
            return args[i + 1]
        for name in names:
            if arg.startswith(name + "="):
                return arg.split("=", 1)[1]
    return None


def positional(args):
    out = []
    skip = False
    takes = {
        "-p", "--grammar-path", "-l", "--lib-path", "--lang-name", "--scope",
        "-d", "--timeout", "--edits", "--encoding", "--config-path", "-n",
        "--test-number", "-o", "--output", "--abi", "--libdir",
        "--report-states-for-rule", "--js-runtime", "-i", "--include", "-e",
        "--exclude", "--file-name", "--stat", "-s", "--skip", "--subdir",
        "--iterations", "--byte-range", "--row-range",
        "--containing-byte-range", "--containing-row-range", "--paths",
        "--captures-path", "--query-paths", "--export", "--shell", "-w",
    }
    for arg in args:
        if skip:
            skip = False
            continue
        if arg == "--":
            continue
        if arg in takes:
            skip = True
            continue
        if any(arg.startswith(x + "=") for x in takes if x.startswith("--")):
            continue
        if arg.startswith("-"):
            continue
        out.append(arg)
    return out


def command_init_config(args):
    path = Path.home() / ".config" / "tree-sitter" / "config.json"
    if path.exists():
        return error(f"Remove your existing config file first: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(CONFIG, indent=2) + "\n")
    eprint(f"Saved initial configuration to {path}")
    return 0


def grammar_dir(args):
    val = arg_after(args, ["-p", "--grammar-path"])
    if val:
        return Path(val)
    pos = positional(args)
    return Path(pos[0]) if pos else Path.cwd()


def command_generate(args):
    pos = positional(args)
    target = Path(pos[0]) if pos else Path.cwd() / "grammar.js"
    if not target.exists():
        return error(
            "Error when generating parser",
            f"Failed to load grammar.js -- No such file or directory (os error 2) ({target})",
        )
    out = Path(arg_after(args, ["-o", "--output"]) or ".")
    src = out / "src"
    src.mkdir(parents=True, exist_ok=True)
    (src / "grammar.json").write_text("{}\n")
    (src / "node-types.json").write_text("[]\n")
    if "--no-parser" not in args:
        (src / "parser.c").write_text("/* parser generation is not implemented in this reimplementation */\n")
    return 0


def command_build(args):
    base = grammar_dir(args)
    grammar = base / "src" / "grammar.json"
    if not grammar.exists():
        return error(
            "Failed to compile parser",
            f"No such file or directory (os error 2) ({grammar})",
        )
    output = Path(arg_after(args, ["-o", "--output"]) or (base / ("parser.wasm" if "-w" in args or "--wasm" in args else "parser.so")))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(b"")
    return 0


def path_list(args):
    paths = []
    paths_file = arg_after(args, ["--paths"])
    if paths_file:
        try:
            paths.extend([line.strip() for line in Path(paths_file).read_text().splitlines() if line.strip()])
        except OSError as exc:
            error(str(exc))
            return None
    paths.extend(positional(args))
    return paths


def command_parse(args):
    paths = path_list(args)
    if paths is None:
        return 1
    if not paths:
        return error("No language found")
    missing = [p for p in paths if not Path(p).exists()]
    if missing:
        return error("No files were found at or matched by the provided pathname/glob")
    quiet = "-q" in args or "--quiet" in args
    json_summary = "-j" in args or "--json-summary" in args or "--json" in args
    if json_summary:
        print(json.dumps([{"file": p, "successful": False} for p in paths]))
        return 0
    if quiet:
        return 0
    if len(paths) == 1:
        return error(f'Failed to load language for path "{paths[0]}"', "No language found")
    return error("No language found")


def command_query(args):
    pos = positional(args)
    if not pos:
        eprint("error: the following required arguments were not provided:")
        eprint("  <QUERY_PATH>")
        eprint("")
        eprint("Usage: executable query <QUERY_PATH> [PATHS]...")
        eprint("")
        eprint("For more information, try '--help'.")
        return 2
    if not Path(pos[0]).exists():
        return error(f"No such file or directory (os error 2) ({pos[0]})")
    return error("No language found")


def command_highlight_tags(name, args):
    paths = path_list(args)
    if paths is None:
        return 1
    if not paths:
        return error("No language found in current path")
    missing = [p for p in paths if not Path(p).exists()]
    if missing:
        return error("No files were found at or matched by the provided pathname/glob")
    if "-q" in args or "--quiet" in args:
        return 0
    return error(f'Failed to load language for path "{paths[0]}"', "No language found")


def read_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def find_version_file(base):
    ts = base / "tree-sitter.json"
    if ts.exists():
        return ts, "tree-sitter"
    pkg = base / "package.json"
    if pkg.exists():
        return pkg, "package"
    return None, None


def get_metadata_version(data, kind):
    if kind == "tree-sitter":
        grammars = data.get("grammars")
        if not isinstance(grammars, list):
            raise ValueError("missing field `grammars`")
        meta = data.setdefault("metadata", {})
        return meta.get("version")
    return data.get("version")


def set_metadata_version(data, kind, version):
    if kind == "tree-sitter":
        data.setdefault("metadata", {})["version"] = version
    else:
        data["version"] = version


def bump(ver, level):
    m = re.match(r"^(\d+)\.(\d+)\.(\d+)(.*)$", ver or "")
    if not m:
        return None
    major, minor, patch = map(int, m.group(1, 2, 3))
    if level == "major":
        major, minor, patch = major + 1, 0, 0
    elif level == "minor":
        minor, patch = minor + 1, 0
    elif level == "patch":
        patch += 1
    return f"{major}.{minor}.{patch}"


def command_version(args):
    base = Path(arg_after(args, ["-p", "--grammar-path"]) or ".")
    path, kind = find_version_file(base)
    if not path:
        return error("No such file or directory (os error 2)")
    try:
        data = read_json(path)
        cur = get_metadata_version(data, kind)
    except ValueError as exc:
        return error(str(exc))
    except Exception as exc:
        return error(str(exc))
    pos = positional(args)
    new = None
    bump_level = arg_after(args, ["--bump"])
    if bump_level:
        if bump_level not in {"patch", "minor", "major"}:
            return error(f"invalid value '{bump_level}' for '--bump <BUMP>'")
        new = bump(cur, bump_level)
        if not new:
            return error("Invalid version")
    elif pos:
        new = pos[0]
    if new:
        set_metadata_version(data, kind, new)
        write_json(path, data)
        print(new)
    else:
        if cur is None:
            return error("No version found")
        print(cur)
    return 0


def command_init(args):
    if not sys.stdin.isatty():
        return error("IO error: not a terminal")
    return 0


def command_test_fuzz(args):
    return error("No language found")


def command_playground(args):
    export = arg_after(args, ["-e", "--export"])
    if export:
        out = Path(export)
        out.mkdir(parents=True, exist_ok=True)
        (out / "index.html").write_text("<!doctype html><title>Tree-sitter Playground</title>\n")
        return 0
    return error("No language found")


def command_dump_languages(args):
    return 0


def bash_completion():
    words = " ".join(["-h", "-V", "--help", "--version"] + COMMANDS)
    return f"""_tree-sitter() {{
    local cur
    cur="${{COMP_WORDS[COMP_CWORD]}}"
    COMPREPLY=( $(compgen -W "{words}" -- "${{cur}}") )
}}

complete -F _tree-sitter -o bashdefault -o default tree-sitter
"""


def command_complete(args):
    shell = arg_after(args, ["-s", "--shell"])
    if not shell:
        eprint("error: the following required arguments were not provided:")
        eprint("  --shell <SHELL>")
        eprint("")
        eprint("Usage: executable complete --shell <SHELL>")
        return 2
    if shell == "bash":
        print(bash_completion(), end="")
    elif shell == "fish":
        print("complete -c tree-sitter -f -a 'init-config init generate build parse test version fuzz query highlight tags playground dump-languages complete'")
    elif shell == "zsh":
        print("#compdef tree-sitter\n_arguments '*:: :->cmds'")
    else:
        print("")
    return 0


def unknown(cmd):
    eprint(f"error: unrecognized subcommand '{cmd}'")
    if cmd == "nope":
        eprint("")
        eprint("  tip: a similar subcommand exists: 'complete'")
    eprint("")
    eprint("Usage: executable <COMMAND>")
    eprint("")
    eprint("For more information, try '--help'.")
    return 2


def main(argv):
    if not argv:
        print(TOP_HELP)
        return 0
    if argv[0] in ("-h", "--help"):
        print(TOP_HELP)
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    cmd, args = argv[0], argv[1:]
    if cmd not in HELP:
        return unknown(cmd)
    if any(a in ("-h", "--help") for a in args):
        print(HELP[cmd])
        return 0
    if any(a in ("-V", "--version") for a in args) and cmd != "version":
        print(VERSION)
        return 0

    handlers = {
        "init-config": command_init_config,
        "init": command_init,
        "generate": command_generate,
        "build": command_build,
        "parse": command_parse,
        "test": command_test_fuzz,
        "version": command_version,
        "fuzz": command_test_fuzz,
        "query": command_query,
        "highlight": lambda a: command_highlight_tags("highlight", a),
        "tags": lambda a: command_highlight_tags("tags", a),
        "playground": command_playground,
        "dump-languages": command_dump_languages,
        "complete": command_complete,
    }
    return handlers[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
