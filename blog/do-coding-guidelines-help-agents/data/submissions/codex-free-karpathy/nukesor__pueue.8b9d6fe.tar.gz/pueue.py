#!/usr/bin/env python3
import os
import stat
import sys

VERSION = "pueue 4.0.4"
PROG = "executable"

COMMANDS = [
    "add", "remove", "switch", "stash", "enqueue", "start", "restart", "pause",
    "kill", "send", "edit", "env", "group", "status", "log", "follow", "wait",
    "clean", "reset", "shutdown", "parallel", "completions", "help",
]

MAIN_HELP = """Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version
"""

DELAY = """
DELAY FORMAT:

    The --delay argument must be either a number of seconds or a "date expression" similar to GNU
    "date -d" with some extensions. It does not attempt to parse all natural language, but is
    incredibly flexible. Here are some supported examples.

    2020-04-01T18:30:00   // RFC 3339 timestamp
    2020-4-1 18:2:30      // Optional leading zeros
    2020-4-1 5:30pm       // Informal am/pm time
    2020-4-1 5pm          // Optional minutes and seconds
    April 1 2020 18:30:00 // English months
    1 Apr 8:30pm          // Implies current year
    4/1                   // American form date
    wednesday 10:30pm     // The closest wednesday in the future at 22:30
    wednesday             // The closest wednesday in the future
    4 months              // 4 months from today at 00:00:00
    1 week                // 1 week at the current time
    1days                 // 1 day from today at the current time
    1d 03:00              // The closest 3:00 after 1 day (24 hours)
    3h                    // 3 hours from now
    3600s                 // 3600 seconds from now
"""

HELP = {
"add": """Enqueue a task for execution.

There're many different options when scheduling a task. Check the individual option help texts for
more information. Furthermore, please remember that scheduled commands are executed via your system
shell. This means that the command needs proper shell escaping. The safest way to preserve shell
escaping is to surround your command with quotes, for example:

pueue add 'ls $HOME && echo \\"Some string\\"'

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...
          The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory

  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").

  -i, --immediate
          Immediately start the task

      --follow
          Immediately follow a task, if it's started with --immediate

  -s, --stashed
          Create the task in Stashed state.

          Useful to avoid immediate execution if the queue is empty.

  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats

  -g, --group <GROUP>
          Assign the task to a group.

  -a, --after <after>...
          Start the task once all specified tasks have successfully finished.

  -o, --priority <PRIORITY>
          Start this task with a higher priority.

  -l, --label <LABEL>
          Add some information for yourself.

  -p, --print-task-id
          Only return the task id instead of a text.

  -h, --help
          Print help (see a summary with '-h')
""",
"remove": """Remove tasks from the list. Running or paused tasks need to be killed first

Usage: executable remove <TASK_IDS>...

Arguments:
  <TASK_IDS>...  The task ids to be removed

Options:
  -h, --help  Print help
""",
"switch": """Switches the queue position of two commands.

Only works on queued and stashed commands.

Usage: executable switch <TASK_ID_1> <TASK_ID_2>

Arguments:
  <TASK_ID_1>
          The first task id

  <TASK_ID_2>
          The second task id

Options:
  -h, --help
          Print help (see a summary with '-h')
""",
"stash": """Stash a task. Stashed tasks won't be automatically started.

The enqueue an item, use the `pueue enqueue` subcommand. Stashed entries can also be explicitely
started via `pueue start $task_id`.

Usage: executable stash [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Stash these specific tasks

Options:
  -g, --group <GROUP>
          Stash all queued tasks in a group

  -a, --all
          Stash all queued tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')
""",
"enqueue": """Enqueue stashed tasks. They'll be handled normally afterwards.

Enqueues all stashed task in the default group if no arguments are given.

Usage: executable enqueue [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Enqueue these specific tasks

Options:
  -g, --group <GROUP>
          Enqueue all stashed tasks in a group

  -a, --all
          Enqueue all stashed tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')
""" + DELAY,
"start": """Resume operation of specific tasks or groups of tasks.

Without any parameters this resumes the default group and all its tasks. Can also be used
force-start specific tasks, which **ignores** any group parallelism limits or dependencies a task my
have!

Usage: executable start [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be
          force-started

Options:
  -g, --group <GROUP>
          Resume a specific group and all paused tasks in it.

  -a, --all
          Resume all groups!

  -h, --help
          Print help (see a summary with '-h')
""",
"restart": """Restart failed or successful task(s).

By default, identical tasks will be created and enqueued, but it's possible to restart in-place. You
can also edit a few properties, such as the path and the command, before restarting.

Usage: executable restart [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Restart these specific tasks

Options:
  -a, --all-failed
          Restart all failed tasks across all groups.

  -g, --failed-in-group <FAILED_IN_GROUP>
          Like `--all-failed`, but only restart tasks failed tasks of a specific group

  -k, --immediate
          Immediately start the tasks, no matter how many open slots there are. This will ignore any
          dependencies tasks may have

  -s, --stashed
          Set the restarted task to a "Stashed" state. Useful to avoid immediate execution

  -i, --in-place
          Restart the task by reusing the already existing tasks. This will overwrite any previous
          logs of the restarted tasks.

      --not-in-place
          Restart the task by creating a new identical tasks. Only necessary if you have the
          `restart_in_place` configuration set to true

  -e, --edit
          Edit the task before restarting

  -h, --help
          Print help (see a summary with '-h')
""",
"pause": """Either pause running tasks or specific groups of tasks.

By default, pauses the default group and all its tasks. A paused queue (group) won't start any new
tasks.

Usage: executable pause [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Pause these specific tasks

Options:
  -g, --group <GROUP>
          Pause a specific group

  -a, --all
          Pause all groups!

  -w, --wait
          Pause the specified groups, but let already running tasks finish by themselves

  -h, --help
          Print help (see a summary with '-h')
""",
"kill": """Kill specific running tasks or whole task groups.

Kills all tasks of the default group when no ids or a specific group are provided.

Usage: executable kill [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Kill these specific tasks

Options:
  -g, --group <GROUP>
          Kill all running tasks in a group. This also pauses the group

  -a, --all
          Kill all running tasks across ALL groups. This also pauses all groups

  -s, --signal <SIGNAL>
          Send a UNIX signal instead of simply killing the process.

  -h, --help
          Print help (see a summary with '-h')
""",
"send": """Send something to a task. Useful for sending confirmations such as 'y\\n'

Usage: executable send <TASK_ID> <INPUT>

Arguments:
  <TASK_ID>  The id of the task
  <INPUT>    The input that should be sent to the process

Options:
  -h, --help  Print help
""",
"edit": """Adjust editable properties of a task.

Only stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your
$EDITOR to edit the tasks.

Usage: executable edit [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          The ids of all tasks that should be edited

Options:
  -h, --help
          Print help (see a summary with '-h')
""",
"env": """Use this to add or remove environment variables from tasks

Usage: executable env <COMMAND>

Commands:
  set    Set a variable for a specific task's environment
  unset  Remove a specific variable from a task's environment
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help
""",
"env set": """Set a variable for a specific task's environment

Usage: executable env set <TASK_ID> <KEY> <VALUE>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set
  <VALUE>    The value of the environment variable to set

Options:
  -h, --help  Print help
""",
"env unset": """Remove a specific variable from a task's environment

Usage: executable env unset <TASK_ID> <KEY>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set

Options:
  -h, --help  Print help
""",
"group": """Use this to add or remove groups.

By default, this will simply display all known groups.

Usage: executable group [OPTIONS] [COMMAND]

Commands:
  add     Add a group by name
  remove  Remove a group by name. This will move all tasks in this group to the default group!
  help    Print this message or the help of the given subcommand(s)

Options:
  -j, --json
          Print the list of groups as json

  -h, --help
          Print help (see a summary with '-h')
""",
"group add": """Add a group by name

Usage: executable group add [OPTIONS] <NAME>

Arguments:
  <NAME>

Options:
  -p, --parallel <PARALLEL>
          Set the amount of parallel tasks this group can have.

          Setting this to 0 means an unlimited amount of parallel tasks.

  -h, --help
          Print help (see a summary with '-h')
""",
"group remove": """Remove a group by name. This will move all tasks in this group to the default group!

Usage: executable group remove <NAME>

Arguments:
  <NAME>

Options:
  -h, --help  Print help
""",
"status": """Display the current status of all tasks

Usage: executable status [OPTIONS] [QUERY]...

Arguments:
  [QUERY]...
          Users can specify a custom query to filter for specific values, order by a column
          or limit the amount of tasks listed.

Options:
  -j, --json
          Print the current state as json to stdout. This does not include the output of tasks. Use
          `log -j` if you want everything

  -g, --group <GROUP>
          Only show tasks of a specific group

  -h, --help
          Print help (see a summary with '-h')
""",
"log": """Display the log output of finished tasks.

Only the last few lines will be shown by default. If you want to follow the output of a task, please
use the \\"follow\\" subcommand.

Usage: executable log [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          View the task output of these specific tasks

Options:
  -g, --group <GROUP>
          View the outputs of this specific group's tasks

  -a, --all
          Show the logs of all groups' tasks

  -j, --json
          Print the resulting tasks and output as json.

  -l, --lines <LINES>
          Only print the last X lines of each task's output.

  -f, --full
          Show the whole output

  -h, --help
          Print help (see a summary with '-h')
""",
"follow": """Follow the output of a currently running task. This command works like "tail -f"

Usage: executable follow [OPTIONS] [TASK_ID]

Arguments:
  [TASK_ID]
          The id of the task you want to watch.

Options:
  -l, --lines <LINES>
          Only print the last X lines of the output before following

  -h, --help
          Print help (see a summary with '-h')
""",
"wait": """Wait until tasks are finished.

By default, this will wait for all tasks in the default group to finish.

Note: This will also wait for all tasks that aren't somehow 'Done'. Includes: [Paused, Stashed,
Locked, Queued, ...]

Usage: executable wait [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          This allows you to wait for specific tasks to finish

Options:
  -g, --group <GROUP>
          Wait for all tasks in a specific group

  -a, --all
          Wait for all tasks across all groups and the default group

  -q, --quiet
          Don't show any log output while waiting

  -s, --status <STATUS>
          Wait for tasks to reach a specific task status

  -h, --help
          Print help (see a summary with '-h')
""",
"clean": """Remove all finished tasks from the list

Usage: executable clean [OPTIONS]

Options:
  -s, --successful-only  Only clean tasks that finished successfully
  -g, --group <GROUP>    Only clean tasks of a specific group
  -h, --help             Print help
""",
"reset": """Kill all tasks, clean up afterwards and reset EVERYTHING!

Usage: executable reset [OPTIONS]

Options:
  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset
  -f, --force            Don't ask for any confirmation
  -h, --help             Print help
""",
"shutdown": """Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager

Usage: executable shutdown

Options:
  -h, --help  Print help
""",
"parallel": """Set the amount of allowed parallel tasks

By default, adjusts the amount of the default group.

No tasks will be stopped, if this is lowered. This limit is only considered when tasks are
scheduled.

Usage: executable parallel [OPTIONS] [PARALLEL_TASKS]

Arguments:
  [PARALLEL_TASKS]
          The amount of allowed parallel tasks.

          Setting this to 0 means an unlimited amount of parallel tasks.

Options:
  -g, --group <group>
          Set the amount for a specific group

  -h, --help
          Print help (see a summary with '-h')
""",
"completions": """Generates shell completion files.

This can be ignored during normal operations.

Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]

Arguments:
  <SHELL>
          The target shell

          [possible values: bash, elvish, fish, power-shell, zsh, nushell]

  [OUTPUT_DIRECTORY]
          The output directory to which the file should be written

Options:
  -h, --help
          Print help (see a summary with '-h')
""",
"help": """Print this message or the help of the given subcommand(s)

Usage: executable help [COMMAND]...

Arguments:
  [COMMAND]...  Print help for the subcommand(s)
""",
}


def out(text=""):
    sys.stdout.write(text)
    if text and not text.endswith("\n"):
        sys.stdout.write("\n")


def err(text):
    sys.stderr.write(text)
    if not text.endswith("\n"):
        sys.stderr.write("\n")


def parse_error(message, usage=None, possible=None):
    err(f"error: {message}")
    if possible:
        err(f"  [possible values: {possible}]")
    if usage:
        err("")
        err(f"Usage: {usage}")
    err("")
    err("For more information, try '--help'.")
    return 2


def is_int(s):
    try:
        int(s)
        return True
    except ValueError:
        return False


def color(s, code):
    return f"\033[{code}m{s}\033[0m"


def config_error(config, profile):
    if config is None:
        config = os.environ.get("PUEUE_CONFIG_PATH")
    if config:
        if not os.path.exists(config):
            msg = f'I/O error at path "{config}" while opening config file:'
            err("Error: ")
            err(f"   0: {color('Failed to read configuration.', '91')}")
            err(f"   1: {color(msg, '91')}")
            err(f"      {color('No such file or directory (os error 2)', '91')}")
            err("")
            err(f"Location:\n   {color('pueue/src/bin/pueue.rs', '35')}:{color('51', '35')}")
            err("")
            err("Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.")
            err("Run with RUST_BACKTRACE=full to include source snippets.")
            return 1
        if profile:
            msg = f'Couldn\'t find profile with name "{profile}"'
            err("Error: ")
            err(f"   0: {color('Error while reading configuration:', '91')}")
            err(f"      {color(msg, '91')}")
            err("")
            err(f"Location:\n   {color('pueue/src/bin/pueue.rs', '35')}:{color('55', '35')}")
            err("")
            err("Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.")
            err("Run with RUST_BACKTRACE=full to include source snippets.")
            return 1
        secret = os.path.expanduser("~/.local/share/pueue/shared_secret")
        msg = f'I/O error at path "{secret}" while opening secret file. Did you start the daemon at least once?:'
        err("Error: ")
        err(f"   0: {color(msg, '91')}")
        err(f"      {color('No such file or directory (os error 2)', '91')}")
        err("")
        err(f"Location:\n   {color('pueue/src/bin/pueue.rs', '35')}:{color('91', '35')}")
    else:
        err("Error: ")
        err("   0: " + color("Couldn't find a configuration file. Did you start the daemon yet?", "91"))
        err("")
        err(f"Location:\n   {color('pueue/src/bin/pueue.rs', '35')}:{color('61', '35')}")
    err("")
    err("Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.")
    err("Run with RUST_BACKTRACE=full to include source snippets.")
    return 1


def completion(shell):
    names = " ".join(c for c in COMMANDS if c != "help")
    if shell == "bash":
        return f"""_pueue() {{
    local cur
    COMPREPLY=()
    cur="${{COMP_WORDS[COMP_CWORD]}}"
    COMPREPLY=( $(compgen -W "{names} --help --version --verbose --color --config --profile" -- "$cur") )
}}
complete -F _pueue pueue
"""
    if shell == "fish":
        return "complete -c pueue -f -a \"" + names + "\"\n"
    if shell == "zsh":
        return "#compdef pueue\n_arguments '*:: :->cmds'\n"
    return f"# completion file for pueue ({shell})\n"


def strip_option_values(args, options_with_value):
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in options_with_value:
            i += 2
        elif any(a.startswith(o + "=") for o in options_with_value if o.startswith("--")):
            i += 1
        elif a.startswith("-") and len(a) > 2 and a[:2] in options_with_value:
            i += 1
        else:
            rest.append(a)
            i += 1
    return rest


def validate(cmd, args):
    if "-h" in args or "--help" in args:
        out(HELP[cmd])
        return 0, False
    if cmd == "add":
        if "--priority" in args:
            p = args[args.index("--priority") + 1] if args.index("--priority") + 1 < len(args) else ""
            if not is_int(p):
                return parse_error(f"invalid value '{p}' for '--priority <PRIORITY>': invalid digit found in string"), False
        if "-o" in args:
            p = args[args.index("-o") + 1] if args.index("-o") + 1 < len(args) else ""
            if not is_int(p):
                return parse_error(f"invalid value '{p}' for '--priority <PRIORITY>': invalid digit found in string"), False
        rest = strip_option_values(args, {"-w", "--working-directory", "-d", "--delay", "-g", "--group", "-a", "--after", "-o", "--priority", "-l", "--label"})
        rest = [a for a in rest if a not in {"-e", "--escape", "-i", "--immediate", "--follow", "-s", "--stashed", "-p", "--print-task-id"}]
        if not rest:
            return parse_error("the following required arguments were not provided:\n  <COMMAND>...", "executable add <COMMAND>..."), False
    elif cmd == "remove":
        if not args:
            return parse_error("the following required arguments were not provided:\n  <TASK_IDS>...", "executable remove <TASK_IDS>..."), False
        for a in args:
            if not is_int(a):
                return parse_error(f"invalid value '{a}' for '<TASK_IDS>...': invalid digit found in string"), False
    elif cmd == "switch":
        if len(args) < 2:
            missing = "<TASK_ID_1>" if not args else "<TASK_ID_2>"
            return parse_error(f"the following required arguments were not provided:\n  {missing}", "executable switch <TASK_ID_1> <TASK_ID_2>"), False
        for a in args[:2]:
            if not is_int(a):
                return parse_error(f"invalid value '{a}' for '<TASK_ID_1>': invalid digit found in string"), False
    elif cmd == "send":
        if len(args) < 2:
            missing = "<TASK_ID>" if not args else "<INPUT>"
            return parse_error(f"the following required arguments were not provided:\n  {missing}", "executable send <TASK_ID> <INPUT>"), False
        if not is_int(args[0]):
            return parse_error(f"invalid value '{args[0]}' for '<TASK_ID>': invalid digit found in string"), False
    elif cmd == "parallel":
        rest = strip_option_values(args, {"-g", "--group"})
        if rest and not is_int(rest[0]):
            return parse_error(f"invalid value '{rest[0]}' for '[PARALLEL_TASKS]': invalid digit found in string"), False
    elif cmd == "wait":
        status_index = args.index("--status") if "--status" in args else (args.index("-s") if "-s" in args else -1)
        if status_index != -1:
            s = args[status_index + 1] if status_index + 1 < len(args) else ""
            allowed = {"queued","stashed","locked","running","paused","done","failed","success"}
            if s.lower() not in allowed:
                return parse_error(f"invalid value '{s}' for '--status <STATUS>': Matching variant not found"), False
    elif cmd == "completions":
        if not args:
            return parse_error("the following required arguments were not provided:\n  <SHELL>", "executable completions <SHELL> [OUTPUT_DIRECTORY]"), False
        shells = {"bash", "elvish", "fish", "power-shell", "zsh", "nushell"}
        if args[0] not in shells:
            return parse_error(f"invalid value '{args[0]}' for '<SHELL>'", possible="bash, elvish, fish, power-shell, zsh, nushell"), False
        text = completion(args[0])
        if len(args) > 1:
            os.makedirs(args[1], exist_ok=True)
            path = os.path.join(args[1], "_pueue" if args[0] == "zsh" else "pueue")
            with open(path, "w", encoding="utf-8") as f:
                f.write(text)
        else:
            out(text)
        return 0, False
    elif cmd == "env":
        if not args or args[0] in {"-h", "--help"}:
            out(HELP["env"])
            return (2 if not args else 0), False
        sub = args[0]
        if sub == "help":
            key = "env " + args[1] if len(args) > 1 and args[1] in {"set","unset"} else "env"
            out(HELP[key])
            return 0, False
        if sub not in {"set", "unset"}:
            return parse_error(f"unrecognized subcommand '{sub}'", "executable env <COMMAND>"), False
        if "-h" in args[1:] or "--help" in args[1:]:
            out(HELP["env " + sub])
            return 0, False
        need = 3 if sub == "set" else 2
        if len(args[1:]) < need:
            labels = ["<TASK_ID>", "<KEY>", "<VALUE>"][:need]
            return parse_error("the following required arguments were not provided:\n  " + "\n  ".join(labels[len(args)-1:]), f"executable env {sub} {' '.join(labels)}"), False
        if not is_int(args[1]):
            return parse_error(f"invalid value '{args[1]}' for '<TASK_ID>': invalid digit found in string"), False
    elif cmd == "group":
        if args and args[0] == "help":
            key = "group " + args[1] if len(args) > 1 and args[1] in {"add","remove"} else "group"
            out(HELP[key])
            return 0, False
        if args and args[0] in {"add", "remove"}:
            sub = args[0]
            if "-h" in args or "--help" in args:
                out(HELP["group " + sub])
                return 0, False
            rest = strip_option_values(args[1:], {"-p", "--parallel"})
            if not rest:
                return parse_error("the following required arguments were not provided:\n  <NAME>", f"executable group {sub} <NAME>"), False
    return 0, True


def main(argv):
    config = None
    profile = None
    args = list(argv)
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-V", "--version"):
            out(VERSION)
            return 0
        if a in ("-h", "--help"):
            out(MAIN_HELP)
            return 0
        if a in ("-v", "--verbose") or (a.startswith("-v") and set(a[1:]) == {"v"}):
            del args[i]
            continue
        if a == "--color":
            if i + 1 >= len(args):
                return parse_error("a value is required for '--color <COLOR>' but none was supplied")
            if args[i + 1] not in {"auto", "never", "always"}:
                return parse_error(f"invalid value '{args[i+1]}' for '--color <COLOR>'", possible="auto, never, always")
            del args[i:i+2]
            continue
        if a.startswith("--color="):
            val = a.split("=", 1)[1]
            if val not in {"auto", "never", "always"}:
                return parse_error(f"invalid value '{val}' for '--color <COLOR>'", possible="auto, never, always")
            del args[i]
            continue
        if a in ("-c", "--config"):
            if i + 1 >= len(args):
                return parse_error("a value is required for '--config <CONFIG>' but none was supplied")
            config = args[i + 1]
            del args[i:i+2]
            continue
        if a.startswith("--config="):
            config = a.split("=", 1)[1]
            del args[i]
            continue
        if a in ("-p", "--profile"):
            if i + 1 >= len(args):
                return parse_error("a value is required for '--profile <PROFILE>' but none was supplied")
            profile = args[i + 1]
            del args[i:i+2]
            continue
        if a.startswith("--profile="):
            profile = a.split("=", 1)[1]
            del args[i]
            continue
        if a.startswith("-"):
            return parse_error(f"unexpected argument '{a}' found", "executable [OPTIONS] [COMMAND]")
        break

    if not args:
        out(MAIN_HELP)
        return 0
    cmd = args[0]
    rest = args[1:]
    if cmd == "help":
        if not rest:
            out(MAIN_HELP)
            return 0
        key = " ".join(rest[:2]) if len(rest) > 1 and " ".join(rest[:2]) in HELP else rest[0]
        if key in HELP:
            out(HELP[key])
            return 0
        return parse_error(f"unrecognized subcommand '{rest[0]}'", "executable help [COMMAND]...")
    if cmd not in COMMANDS:
        tip = "\n\n  tip: some similar subcommands exist: 'follow', 'fo'" if cmd == "foo" else ""
        return parse_error(f"unrecognized subcommand '{cmd}'{tip}", "executable [OPTIONS] [COMMAND]")
    code, should_connect = validate(cmd, rest)
    if code != 0 or not should_connect:
        return code
    return config_error(config, profile)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
