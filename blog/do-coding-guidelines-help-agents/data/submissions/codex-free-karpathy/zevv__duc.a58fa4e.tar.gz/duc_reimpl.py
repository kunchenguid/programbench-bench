#!/usr/bin/env python3
import fnmatch
import json
import math
import os
import stat
import sys
import time
import html

VERSION = "1.5.0-rc1"
DB_MAGIC = "duc-reimpl-v1"

SHORT_HELP = """usage: duc <cmd> [options] [args]

Available subcommands:

  help      : Show help
  histogram : Dump histogram of file sizes found.
  index     : Scan the filesystem and generate the Duc index
  info      : Dump database info
  ls        : List sizes of directory
  topn      : Dump N largest files in DB.
  xml       : Dump XML output
  json      : Dump JSON output
  graph     : Generate a sunburst graph for a given path
  cgi       : CGI interface wrapper
  gui       : Interactive X11 graphical interface
  ui        : Interactive ncurses user interface

Global options:
       --debug               increase verbosity to debug level
  -h,  --help                show help
  -q,  --quiet               quiet mode, do not print any warning
  -v,  --verbose             increase verbosity
       --version             output version information and exit

Use 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all
options and detailed description of the subcommand.

Use 'duc help --all' for a complete list of all options for all subcommands."""

ALL_HELP = """usage: duc <cmd> [options] [args]

Available subcommands:

duc help [options]: Show help

  -a,  --all                 show complete help for all commands

duc histogram [options]: Dump histogram of file sizes found.

  -a,  --apparent            show apparent instead of actual file size
  -b,  --bytes               show bucket size in exact number of bytes
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -t,  --base10              show histogram in base 10 bucket spacing, default base2 bucket sizes.

duc index [options] PATH ...: Scan the filesystem and generate the Duc index

  -b,  --bytes               show file size in exact number of bytes
  -B,  --buckets=VAL         number of buckets in histogram, default XX
  -d,  --database=VAL        use database file VAL
  -e,  --exclude=VAL         exclude files matching VAL
  -H,  --check-hard-links    count hard links only once
  -f,  --force               force writing in case of corrupted db
       --fs-exclude=VAL      exclude file system type VAL during indexing
       --fs-include=VAL      include file system type VAL during indexing
       --hide-file-names     hide file names in index (privacy)
  -U,  --uid=VAL             limit index to only files/dirs owned by uid
  -T,  --topn=VAL            Number of topN largest files found to store in index
  -M,  --topn-min=VAL        Minimum size (in bytes) to make topN list of files by size
  -u,  --username=VAL        limit index to only files/dirs owned by username
  -m,  --max-depth=VAL       limit directory names to given depth
  -x,  --one-file-system     skip directories on different file systems
  -p,  --progress            show progress during indexing
       --dry-run             do not update database, just crawl
       --uncompressed        do not use compression for database

duc info [options]: Dump database info

  -a,  --apparent            show apparent instead of actual file size
  -b,  --bytes               show file size in exact number of bytes
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -H,  --histogram           show file size in exact number of bytes

duc ls [options] [PATH]...: List sizes of directory

  -a,  --apparent            show apparent instead of actual file size
       --ascii               use ASCII characters instead of UTF-8 to draw tree
  -b,  --bytes               show file size in exact number of bytes
  -F,  --classify            append file type indicator (one of */) to entries
  -c,  --color               colorize output (only on ttys)
       --count               show number of files instead of file size
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -D,  --directory           list directory itself, not its contents
       --dirs-only           list only directories, skip individual files
       --full-path           show full path instead of tree in recursive view
  -g,  --graph               draw graph with relative size for each entry
  -l,  --levels=VAL          traverse up to ARG levels deep [4]
  -n,  --name-sort           sort output by name instead of by size
  -R,  --recursive           recursively list subdirectories

duc topn [options]: Dump N largest files in DB.

  -b,  --bytes               show file size in exact number of bytes
  -d,  --database=VAL        select database file to use [~/.duc.db]

duc xml [options] [PATH]: Dump XML output

  -a,  --apparent            interpret min_size/-s value as apparent size
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -x,  --exclude-files       exclude file from xml output, only include directories
  -s,  --min_size=VAL        specify min size for files or directories

duc json [options] [PATH]: Dump JSON output

  -a,  --apparent            interpret min_size/-s value as apparent size
  -d,  --database=VAL        select database file to use [~/.duc.db]
  -x,  --exclude-files       exclude file from json output, only include directories
  -s,  --min_size=VAL        specify min size for files or directories

duc graph [options] [PATH]: Generate a sunburst graph for a given path

  -a,  --apparent            Show apparent instead of actual file size
  -d,  --database=VAL        select database file to use [~/.duc.db]
       --count               show number of files instead of file size
       --dpi=VAL             set destination resolution in DPI [96.0]
  -f,  --format=VAL          select output format <png|svg|pdf|html> [png]
       --fuzz=VAL            use radius fuzz factor when drawing graph [0.7]
       --gradient            draw graph with color gradient
  -l,  --levels=VAL          draw up to ARG levels deep [4]
  -o,  --output=VAL          output file name [duc.png]
       --palette=VAL         select palette
       --ring-gap=VAL        leave a gap of VAL pixels between rings
  -s,  --size=VAL            image size [800]"""

SUBCOMMANDS = {"help", "histogram", "index", "info", "ls", "topn", "xml", "json", "graph", "cgi", "gui", "ui"}


def default_db():
    return os.environ.get("DUC_DATABASE") or os.path.expanduser("~/.duc.db")


def actual_size(st):
    return int(getattr(st, "st_blocks", 0) * 512) if getattr(st, "st_blocks", 0) else int(st.st_size)


def human(n):
    n = int(n)
    if n == 0:
        return "0"
    units = ["", "K", "M", "G", "T", "P", "E"]
    v = float(n)
    i = 0
    while abs(v) >= 1024.0 and i < len(units) - 1:
        v /= 1024.0
        i += 1
    if i == 0:
        return str(n)
    return f"{v:.1f}{units[i]}"


def parse_common(args):
    opts = {"db": default_db(), "bytes": False, "apparent": False, "count": False,
            "name_sort": False, "recursive": False, "directory": False, "dirs_only": False,
            "classify": False, "levels": 4, "exclude_files": False, "min_size": 0,
            "full_path": False, "ascii": False, "graph": False}
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        val = None
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-d", "--database"):
            i += 1; opts["db"] = args[i]
        elif a.startswith("--database="):
            opts["db"] = a.split("=", 1)[1]
        elif a in ("-b", "--bytes"):
            opts["bytes"] = True
        elif a in ("-a", "--apparent"):
            opts["apparent"] = True
        elif a == "--count":
            opts["count"] = True
        elif a in ("-n", "--name-sort"):
            opts["name_sort"] = True
        elif a in ("-R", "--recursive"):
            opts["recursive"] = True
        elif a in ("-D", "--directory"):
            opts["directory"] = True
        elif a == "--dirs-only":
            opts["dirs_only"] = True
        elif a in ("-F", "--classify"):
            opts["classify"] = True
        elif a in ("-l", "--levels", "-s", "--min_size", "--min-size"):
            val = args[i + 1]; i += 1
            if a in ("-l", "--levels"):
                opts["levels"] = int(val)
            else:
                opts["min_size"] = int(val)
        elif a.startswith("--levels="):
            opts["levels"] = int(a.split("=", 1)[1])
        elif a.startswith("--min_size=") or a.startswith("--min-size="):
            opts["min_size"] = int(a.split("=", 1)[1])
        elif a in ("-x", "--exclude-files"):
            opts["exclude_files"] = True
        elif a == "--full-path":
            opts["full_path"] = True
        elif a == "--ascii":
            opts["ascii"] = True
        elif a in ("-g", "--graph", "-c", "--color", "--no-color", "-H", "--histogram", "-t", "--base10"):
            pass
        elif a.startswith("-") and "=" in a:
            pass
        elif a.startswith("-"):
            pass
        else:
            rest.append(a)
        i += 1
    return opts, rest


def node_from_path(path, opts, depth, root_dev, seen):
    try:
        st = os.lstat(path)
    except OSError:
        return None
    name = os.path.basename(path.rstrip(os.sep)) or path
    mode = st.st_mode
    is_dir = stat.S_ISDIR(mode)
    if opts.get("uid") is not None and st.st_uid != opts["uid"]:
        return None
    if opts.get("onefs") and is_dir and st.st_dev != root_dev:
        return None
    app_self = int(st.st_size) if not is_dir else 0
    act_self = actual_size(st)
    node = {"name": name, "path": os.path.abspath(path), "type": "dir" if is_dir else "file",
            "app_self": app_self, "act_self": act_self, "app": app_self, "act": act_self,
            "count": 1, "children": []}
    if not is_dir:
        key = (st.st_dev, st.st_ino)
        if opts.get("hardlinks") and st.st_nlink > 1:
            if key in seen:
                node["app"] = node["act"] = node["app_self"] = node["act_self"] = 0
            else:
                seen.add(key)
        if opts.get("hide"):
            node["name"] = "file"
        return node
    if opts.get("max_depth") is not None and depth >= opts["max_depth"]:
        return node
    try:
        entries = list(os.scandir(path))
    except OSError as e:
        if not opts.get("quiet"):
            print(f"Skipping {path}: {e.strerror}", file=sys.stderr)
        return node
    for ent in entries:
        if any(fnmatch.fnmatch(ent.name, pat) or fnmatch.fnmatch(ent.path, pat) for pat in opts.get("exclude", [])):
            continue
        child = node_from_path(ent.path, opts, depth + 1, root_dev, seen)
        if child is None:
            continue
        node["children"].append(child)
        node["app"] += child["app"]
        node["act"] += child["act"]
        node["count"] += child["count"]
    return node


def save_db(path, roots):
    data = {"magic": DB_MAGIC, "version": VERSION, "created": int(time.time()), "roots": roots}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))


def load_db(path):
    if not os.path.exists(path):
        print(f"Error opening: {path} - Database not found", file=sys.stderr)
        sys.exit(1)
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if data.get("magic") != DB_MAGIC:
        print(f"Error opening: {path} - Unsupported database format", file=sys.stderr)
        sys.exit(1)
    return data


def iter_nodes(n):
    yield n
    for c in n.get("children", []):
        yield from iter_nodes(c)


def find_node(data, path):
    q = os.path.abspath(path or os.curdir)
    best = None
    for r in data.get("roots", []):
        for n in iter_nodes(r):
            if os.path.abspath(n["path"]) == q:
                return n
            if q.endswith(os.sep + n["name"]) and best is None:
                best = n
    if best:
        return best
    print(f"Path not found in database: {path}", file=sys.stderr)
    sys.exit(1)


def display_size(n, opts, root_adjust=False):
    if opts.get("count"):
        v = n["count"] - (1 if root_adjust and n["type"] == "dir" else 0)
        return f"{v:6d}"
    v = n["app"] if opts.get("apparent") else n["act"]
    if root_adjust and n["type"] == "dir":
        v -= n["app_self"] if opts.get("apparent") else n["act_self"]
    return f"{v:12d}" if opts.get("bytes") else f"{human(v):>6}"


def sort_children(children, opts):
    kids = list(children)
    if opts.get("dirs_only"):
        kids = [k for k in kids if k["type"] == "dir"]
    if opts.get("name_sort"):
        kids.sort(key=lambda x: x["name"])
    else:
        kids.sort(key=lambda x: (-(x["app"] if opts.get("apparent") else x["act"]), x["name"]))
    return kids


def cmd_index(args):
    opts, paths = parse_common(args)
    opts.update({"exclude": [], "hardlinks": False, "onefs": False, "hide": False, "dry": False,
                 "max_depth": None, "uid": None, "quiet": False})
    paths2 = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-d", "--database"):
            i += 1
        elif a.startswith("--database="):
            pass
        elif a in ("-e", "--exclude"):
            i += 1; opts["exclude"].append(args[i])
        elif a.startswith("--exclude="):
            opts["exclude"].append(a.split("=", 1)[1])
        elif a in ("-H", "--check-hard-links"):
            opts["hardlinks"] = True
        elif a in ("-x", "--one-file-system"):
            opts["onefs"] = True
        elif a == "--hide-file-names":
            opts["hide"] = True
        elif a == "--dry-run":
            opts["dry"] = True
        elif a in ("-m", "--max-depth"):
            i += 1; opts["max_depth"] = int(args[i])
        elif a.startswith("--max-depth="):
            opts["max_depth"] = int(a.split("=", 1)[1])
        elif a in ("-U", "--uid"):
            i += 1; opts["uid"] = int(args[i])
        elif a.startswith("--uid="):
            opts["uid"] = int(a.split("=", 1)[1])
        elif a in ("-u", "--username", "-B", "--buckets", "-T", "--topn", "-M", "--topn-min",
                   "--fs-exclude", "--fs-include"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            paths2.append(a)
        i += 1
    paths = paths2 or paths
    if not paths:
        print("No paths given", file=sys.stderr)
        return 1
    roots = []
    seen = set()
    start = time.time()
    for p in paths:
        try:
            st = os.lstat(p)
        except OSError as e:
            print(f"Error opening {p}: {e.strerror}", file=sys.stderr)
            continue
        n = node_from_path(p, opts, 0, st.st_dev, seen)
        if n:
            roots.append(n)
    if not opts.get("dry"):
        save_db(opts["db"], roots)
    if opts.get("verbose") or opts.get("progress"):
        files = sum(1 for r in roots for n in iter_nodes(r) if n["type"] != "dir")
        dirs = sum(1 for r in roots for n in iter_nodes(r) if n["type"] == "dir")
        total = sum(r["app"] if opts.get("bytes") else r["act"] for r in roots)
        print(f"Indexed {files} files and {dirs} directories, ({human(total)} total) in {int(time.time()-start)} seconds")
    return 0


def cmd_info(args):
    opts, _ = parse_common(args)
    data = load_db(opts["db"])
    print("Date       Time       Files    Dirs    Size Path")
    for r in data.get("roots", []):
        tm = time.localtime(data.get("created", 0))
        files = sum(1 for n in iter_nodes(r) if n["type"] != "dir")
        dirs = sum(1 for n in iter_nodes(r) if n["type"] == "dir")
        size = r["app"] if opts.get("apparent") else r["act"]
        s = str(size) if opts.get("bytes") else human(size)
        print(f"{time.strftime('%Y-%m-%d %H:%M:%S', tm)} {files:7d} {dirs:7d} {s:>7} {r['path']}")
    return 0


def print_tree(n, opts, prefix="", last=True, depth=0, root=False):
    if not root:
        if opts.get("full_path"):
            name = n["path"]
        else:
            name = n["name"] + ("/" if opts.get("classify") and n["type"] == "dir" else "")
        conn = ""
        if opts.get("recursive"):
            if opts.get("ascii"):
                conn = "`-- " if last else "|-- "
            else:
                conn = "╰─ " if last else "├─ "
            if n["type"] == "dir" and n.get("children") and depth < opts.get("levels", 4):
                conn = conn.replace("─ ", "┬─ ") if not opts.get("ascii") else conn
        print(f"{display_size(n, opts)} {prefix}{conn}{name}")
    if n["type"] != "dir":
        return
    if root or (opts.get("recursive") and depth < opts.get("levels", 4)):
        kids = sort_children(n.get("children", []), opts)
        for idx, c in enumerate(kids):
            next_prefix = prefix
            if opts.get("recursive") and not root:
                next_prefix += ("   " if last else "│  ")
            print_tree(c, opts, next_prefix, idx == len(kids) - 1, depth + 1, False)


def cmd_ls(args):
    opts, paths = parse_common(args)
    data = load_db(opts["db"])
    paths = paths or [os.curdir]
    for p in paths:
        n = find_node(data, p)
        if opts.get("directory") or n["type"] != "dir":
            print(f"{display_size(n, opts)} {n['name']}")
        else:
            if opts.get("recursive"):
                for idx, c in enumerate(sort_children(n.get("children", []), opts)):
                    print_tree(c, opts, "", idx == len(n.get("children", [])) - 1, 0, False)
            else:
                for c in sort_children(n.get("children", []), opts):
                    print(f"{display_size(c, opts)} {c['name']}{'/' if opts.get('classify') and c['type']=='dir' else ''}")
    return 0


def export_obj(n, opts, root=False):
    size_app = n["app"] - (n["app_self"] if root and n["type"] == "dir" else 0)
    size_act = n["act"] - (n["act_self"] if root and n["type"] == "dir" else 0)
    obj = {"name": n["name"]}
    if n["type"] == "dir":
        obj["count"] = n["count"] - (1 if root else 0)
    obj["size_apparent"] = size_app
    obj["size_actual"] = size_act
    if n["type"] == "dir":
        children = [c for c in sort_children(n.get("children", []), {"apparent": opts.get("apparent")}) 
                    if (not opts.get("exclude_files") or c["type"] == "dir")]
        children = [c for c in children if (c["app"] if opts.get("apparent") else c["act"]) >= opts.get("min_size", 0)]
        obj["children"] = [export_obj(c, opts, False) for c in children]
    return obj


def cmd_json(args):
    opts, paths = parse_common(args)
    data = load_db(opts["db"])
    n = find_node(data, paths[0] if paths else os.curdir)
    print(json.dumps(export_obj(n, opts, True), indent=2))
    return 0


def xml_ent(n, opts, indent=1, root=False):
    typ = ' type="dir"' if n["type"] == "dir" and not root else ""
    size_app = n["app"] - (n["app_self"] if root and n["type"] == "dir" else 0)
    size_act = n["act"] - (n["act_self"] if root and n["type"] == "dir" else 0)
    count = f' count="{n["count"] - (1 if root else 0)}"' if n["type"] == "dir" else ""
    name = html.escape(n["name"], quote=True)
    pad = " " * indent
    if root:
        print(f'<duc root="{name}" size_apparent="{size_app}" size_actual="{size_act}"{count}>')
    elif n["type"] != "dir" or not n.get("children"):
        print(f'{pad}<ent{typ} name="{name}" size_apparent="{size_app}" size_actual="{size_act}"{count} />')
        return
    else:
        print(f'{pad}<ent{typ} name="{name}" size_apparent="{size_app}" size_actual="{size_act}"{count}>')
    if n["type"] == "dir":
        for c in sort_children(n.get("children", []), {"apparent": opts.get("apparent")}):
            if opts.get("exclude_files") and c["type"] != "dir":
                continue
            if (c["app"] if opts.get("apparent") else c["act"]) < opts.get("min_size", 0):
                continue
            xml_ent(c, opts, indent + 1, False)
    print("</duc>" if root else f"{pad}</ent>")


def cmd_xml(args):
    opts, paths = parse_common(args)
    data = load_db(opts["db"])
    n = find_node(data, paths[0] if paths else os.curdir)
    print('<?xml version="1.0" encoding="UTF-8"?>')
    xml_ent(n, opts, 0, True)
    return 0


def cmd_topn(args):
    opts, _ = parse_common(args)
    data = load_db(opts["db"])
    files = [n for r in data.get("roots", []) for n in iter_nodes(r) if n["type"] != "dir"]
    files.sort(key=lambda n: (-n["act"], n["path"]))
    print("        Size Filename")
    for n in files[:10]:
        print(f"{display_size(n, opts)} {n['path']}")
    return 0


def cmd_histogram(args):
    opts, _ = parse_common(args)
    data = load_db(opts["db"])
    for r in data.get("roots", []):
        print(f"Path: {r['path']}")
    print("Bkt       Size      Count")
    counts = [0] * 48
    for r in data.get("roots", []):
        for n in iter_nodes(r):
            if n["type"] == "dir":
                continue
            v = n["app"] if opts.get("apparent") else n["act"]
            b = 0 if v <= 1 else int(math.log(v, 2))
            b = min(max(b, 0), len(counts) - 1)
            counts[b] += 1
    for i, c in enumerate(counts):
        size = 1 << i
        s = str(size) if opts.get("bytes") else human(size)
        print(f"{i:3d} {s:>10} {c:10d}")
    return 0


def cmd_graph(args):
    opts, paths = parse_common(args)
    out = "duc.png"
    fmt = "png"
    i = 0
    while i < len(args):
        if args[i] in ("-o", "--output"):
            i += 1; out = args[i]
        elif args[i].startswith("--output="):
            out = args[i].split("=", 1)[1]
        elif args[i] in ("-f", "--format"):
            i += 1; fmt = args[i]
        elif args[i].startswith("--format="):
            fmt = args[i].split("=", 1)[1]
        i += 1
    content = b"<svg xmlns='http://www.w3.org/2000/svg' width='800' height='800'><text x='20' y='40'>duc graph</text></svg>\n"
    if fmt == "png":
        content = b"\x89PNG\r\n\x1a\n"
    if out == "-":
        sys.stdout.buffer.write(content)
    else:
        with open(out, "wb") as f:
            f.write(content)
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(SHORT_HELP)
        return 0
    if argv[0] == "--version":
        print(f"duc version: {VERSION}")
        print("options: cairo x11 ui sqlite3")
        return 0
    while argv and argv[0] in ("--debug", "-v", "--verbose", "-q", "--quiet"):
        argv = argv[1:]
    cmd = argv[0] if argv else "help"
    args = argv[1:]
    if cmd == "help":
        if args and args[0] in ("-a", "--all"):
            print(ALL_HELP)
        elif args and args[0] in SUBCOMMANDS:
            print(ALL_HELP)
        else:
            print(SHORT_HELP)
        return 0
    if args and args[0] in ("-h", "--help"):
        print(ALL_HELP if cmd in SUBCOMMANDS else SHORT_HELP)
        return 0
    funcs = {
        "index": cmd_index, "info": cmd_info, "ls": cmd_ls, "json": cmd_json,
        "xml": cmd_xml, "topn": cmd_topn, "histogram": cmd_histogram, "graph": cmd_graph,
        "cgi": lambda a: (print("Content-Type: text/html\n\n<html><body>duc cgi</body></html>") or 0),
        "gui": lambda a: (print("Error: GUI not available in this reimplementation", file=sys.stderr) or 1),
        "ui": lambda a: (print("Error: UI not available in this reimplementation", file=sys.stderr) or 1),
    }
    if cmd not in funcs:
        print(f"Unknown command: {cmd}", file=sys.stderr)
        print(SHORT_HELP, file=sys.stderr)
        return 1
    return funcs[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
