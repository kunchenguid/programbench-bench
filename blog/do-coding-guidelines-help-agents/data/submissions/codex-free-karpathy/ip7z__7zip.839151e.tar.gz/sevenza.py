#!/usr/bin/env python3
import binascii
import fnmatch
import hashlib
import os
import stat
import struct
import sys
import time
import zlib

VERSION = """7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12
 64-bit locale=C.UTF-8 Threads:12 OPEN_MAX:1048576
"""

HELP = VERSION + """
Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

<Commands>
  a : Add files to archive
  b : Benchmark
  d : Delete files from archive
  e : Extract files from archive (without using directory names)
  h : Calculate hash values for files
  i : Show information about supported formats
  l : List contents of archive
  rn : Rename files in archive
  t : Test integrity of archive
  u : Update files to archive
  x : eXtract files with full paths

<Switches>
  -- : Stop switches and @listfile parsing
  -ai[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include archives
  -ax[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude archives
  -ao{a|s|t|u} : set Overwrite mode
  -an : disable archive_name field
  -bb[0-3] : set output log level
  -bd : disable progress indicator
  -bs{o|e|p}{0|1|2} : set output stream for output/error/progress line
  -bt : show execution time statistics
  -i[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include filenames
  -m{Parameters} : set compression Method
    -mmt[N] : set number of CPU threads
    -mx[N] : set compression level: -mx1 (fastest) ... -mx9 (ultra)
  -o{Directory} : set Output directory
  -p{Password} : set Password
  -r[-|0] : Recurse subdirectories for name search
  -sa{a|e|s} : set Archive name mode
  -scc{UTF-8|WIN|DOS} : set charset for console input/output
  -scs{UTF-8|UTF-16LE|UTF-16BE|WIN|DOS|{id}} : set charset for list files
  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands
  -sdel : delete files after compression
  -seml[.] : send archive by email
  -sfx[{name}] : Create SFX archive
  -si[{name}] : read data from stdin
  -slp : set Large Pages mode
  -snh : store hard links as links
  -snl : store symbolic links as links
  -sni : store NT security information
  -sns[-] : store NTFS alternate streams
  -so : write data to stdout
  -spd : disable wildcard matching for file names
  -spe : eliminate duplication of root folder for extract command
  -spf[2] : use fully qualified file paths
  -ssc[-] : set sensitive case mode
  -sse : stop archive creating, if it can't open some input file
  -ssp : do not change Last Access Time of source files while archiving
  -ssw : compress shared files
  -stl : set archive timestamp from the most recently modified file
  -stm{HexMask} : set CPU thread affinity mask (hexadecimal number)
  -stx{Type} : exclude archive type
  -t{Type} : Set type of archive
  -u[-][p#][q#][r#][x#][y#][z#][!newArchiveName] : Update options
  -v{Size}[b|k|m|g] : Create volumes
  -w[{path}] : assign Work directory. Empty path means a temporary directory
  -x[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude filenames
  -y : assume Yes on all queries
"""

INFO = VERSION + """

Formats:
   C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C
    ...F..................  Cab      cab           M S C F 00 00 00 00
    ......................  Split    001           
   CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) tbz (.tar) B Z h
   CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar) apk (.tar) 1F 8B 08
    K.....O...............  lzma     lzma          
    K.....................  lzma86   lzma86        
   C......O...LH......m+..  tar      tar ova       offset=257 u s t a r
   CK.....................  xz       xz txz (.tar) FD 7 z X Z 00
   C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx P K 03 04  ||  P K 05 06  ||  P K 06 06  ||  P K 07 08 P K  ||  P K 0 0 P K
    K.....................  zstd     zst tzst (.tar) ( B5 / FD
   CK.....O.....XC........  Hash     sha256 sha512 sha384 sha224 sha512-224 sha512-256 sha3-224 sha3-256 sha3-384 sha3-512 sha1 sha2 sha3 sha md5 blake2s blake2b blake2sp xxh64 crc32 crc64 cksum asc 

Codecs:
    ED     40202 BZip2
    ED         0 Copy
    ED     40108 Deflate
    ED        21 LZMA2
    ED     30101 LZMA

Hashers:
      4        1 CRC32
     20      201 SHA1
     32        A SHA256
      8      211 XXH64
      8        4 CRC64
"""

def banner():
    print(VERSION)

def kib(n):
    k = (n + 1023) // 1024
    return f"{n} bytes ({k} KiB)"

def dos_time(ts):
    t = time.localtime(ts)
    return ((t.tm_year - 1980) << 25) | (t.tm_mon << 21) | (t.tm_mday << 16) | (t.tm_hour << 11) | (t.tm_min << 5) | (t.tm_sec // 2)

def fmt_dt(ts):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts))

def safe_path(name):
    name = name.replace("\\", "/")
    parts = [p for p in name.split("/") if p not in ("", ".", "..")]
    return os.path.join(*parts) if parts else ""

def collect(paths, recurse=False):
    out = []
    for p in paths:
        if any(c in p for c in "*?["):
            matches = []
            base = "."
            for root, dirs, files in os.walk(base):
                names = files + dirs
                for n in names:
                    q = os.path.join(root, n)
                    q = q[2:] if q.startswith("./") else q
                    if fnmatch.fnmatch(q, p):
                        matches.append(q)
                if not recurse:
                    break
            out.extend(matches)
        elif os.path.isdir(p):
            if recurse:
                for root, dirs, files in os.walk(p):
                    for f in files:
                        out.append(os.path.join(root, f))
            else:
                out.append(p)
        else:
            out.append(p)
    return [p for p in out if os.path.isfile(p)]

def parse(argv):
    opts = {"type": None, "out": ".", "flat": False, "stdout": False, "recurse": False, "slt": False, "hash": "CRC32"}
    rest = []
    stop = False
    for a in argv:
        if stop:
            rest.append(a); continue
        la = a.lower()
        if a == "--":
            stop = True
        elif la.startswith("-t") and len(a) > 2:
            opts["type"] = a[2:].lower()
        elif la.startswith("-o") and len(a) > 2:
            opts["out"] = a[2:]
        elif la == "-so":
            opts["stdout"] = True
        elif la == "-r" or la.startswith("-r"):
            opts["recurse"] = not la.startswith("-r-")
        elif la == "-slt":
            opts["slt"] = True
        elif la.startswith("-scrc"):
            h = a[5:] or "CRC32"
            opts["hash"] = h.upper()
        elif a.startswith("-"):
            pass
        elif a.startswith("@"):
            try:
                with open(a[1:], "r", encoding="utf-8") as f:
                    rest += [line.rstrip("\n") for line in f if line.rstrip("\n")]
            except OSError:
                rest.append(a)
        else:
            rest.append(a)
    return opts, rest

def arc_type(name, opt=None):
    if opt:
        return opt
    low = name.lower()
    if low.endswith(".tar"):
        return "tar"
    if low.endswith(".zip") or low.endswith(".jar"):
        return "zip"
    if low.endswith(".gz") or low.endswith(".tgz"):
        return "gzip"
    return "zip"

def tar_checksum(h):
    return sum(h[:148] + b"        " + h[156:])

def tar_octal(v, n):
    s = oct(int(v))[2:].encode()
    return b"0" * max(0, n - 1 - len(s)) + s[-(n-1):] + b"\0"

def tar_header(path, st):
    name = path.encode("utf-8")
    prefix = b""
    if len(name) > 100 and b"/" in name:
        p, n = name.rsplit(b"/", 1)
        if len(n) <= 100 and len(p) <= 155:
            name, prefix = n, p
    h = bytearray(512)
    h[0:len(name[:100])] = name[:100]
    h[100:108] = tar_octal(st.st_mode & 0o777, 8)
    h[108:116] = tar_octal(0, 8)
    h[116:124] = tar_octal(0, 8)
    h[124:136] = tar_octal(st.st_size, 12)
    h[136:148] = tar_octal(st.st_mtime, 12)
    h[148:156] = b"        "
    h[156:157] = b"0"
    h[257:263] = b"ustar\0"
    h[263:265] = b"00"
    h[345:345+len(prefix[:155])] = prefix[:155]
    chk = tar_checksum(h)
    h[148:156] = ("%06o\0 " % chk).encode()
    return bytes(h)

def create_tar(archive, files):
    with open(archive, "wb") as out:
        for p in files:
            st = os.stat(p)
            out.write(tar_header(p.replace(os.sep, "/"), st))
            with open(p, "rb") as f:
                while True:
                    b = f.read(1024 * 1024)
                    if not b: break
                    out.write(b)
            pad = (-st.st_size) % 512
            if pad: out.write(b"\0" * pad)
        out.write(b"\0" * 1024)

def read_tar(archive):
    entries = []
    with open(archive, "rb") as f:
        while True:
            h = f.read(512)
            if len(h) < 512 or h == b"\0" * 512:
                break
            name = h[0:100].rstrip(b"\0").decode("utf-8", "replace")
            prefix = h[345:500].rstrip(b"\0").decode("utf-8", "replace")
            if prefix:
                name = prefix + "/" + name
            size = int((h[124:136].split(b"\0",1)[0] or b"0").strip() or b"0", 8)
            mtime = int((h[136:148].split(b"\0",1)[0] or b"0").strip() or b"0", 8)
            typ = h[156:157]
            off = f.tell()
            entries.append({"name": name, "size": size, "packed": ((size + 511)//512)*512, "mtime": mtime, "type": typ, "off": off})
            f.seek(((size + 511)//512)*512, 1)
    return entries

def crc32(data):
    return binascii.crc32(data) & 0xffffffff

def create_zip(archive, files):
    cd = []
    with open(archive, "wb") as out:
        for p in files:
            data = open(p, "rb").read()
            st = os.stat(p)
            name = p.replace(os.sep, "/").encode("utf-8")
            crc = crc32(data); dt = dos_time(st.st_mtime); dost = dt & 0xffff; dosd = dt >> 16
            off = out.tell()
            out.write(struct.pack("<IHHHHHIIIHH", 0x04034b50, 20, 0, 0, dost, dosd, crc, len(data), len(data), len(name), 0))
            out.write(name); out.write(data)
            cd.append((name, crc, len(data), len(data), dost, dosd, off, st.st_mode))
        cd_start = out.tell()
        for name, crc, size, csize, dost, dosd, off, mode in cd:
            ext = (mode & 0xffff) << 16
            out.write(struct.pack("<IHHHHHHIIIHHHHHII", 0x02014b50, 0x0314, 20, 0, 0, dost, dosd, crc, csize, size, len(name), 0, 0, 0, 0, ext, off))
            out.write(name)
        cd_size = out.tell() - cd_start
        out.write(struct.pack("<IHHHHIIH", 0x06054b50, 0, 0, len(cd), len(cd), cd_size, cd_start, 0))

def create_gzip(archive, files):
    if not files:
        data = b""
        src = ""
    else:
        src = os.path.basename(files[0])
        data = open(files[0], "rb").read()
    compobj = zlib.compressobj(6, zlib.DEFLATED, -15)
    comp = compobj.compress(data) + compobj.flush()
    with open(archive, "wb") as out:
        out.write(b"\x1f\x8b\x08")
        flags = 8 if src else 0
        out.write(bytes([flags]))
        out.write(struct.pack("<I", int(time.time())))
        out.write(b"\x00\x03")
        if src:
            out.write(src.encode("utf-8", "replace") + b"\0")
        out.write(comp)
        out.write(struct.pack("<II", crc32(data), len(data) & 0xffffffff))

def read_gzip(archive):
    data = open(archive, "rb").read()
    if len(data) < 18 or data[:2] != b"\x1f\x8b":
        raise ValueError("not a gzip archive")
    flg = data[3]
    mt = struct.unpack_from("<I", data, 4)[0]
    pos = 10
    if flg & 4:
        xlen = struct.unpack_from("<H", data, pos)[0]
        pos += 2 + xlen
    name = os.path.basename(archive)
    if flg & 8:
        end = data.find(b"\0", pos)
        if end >= 0:
            name = data[pos:end].decode("utf-8", "replace") or name
            pos = end + 1
    if flg & 16:
        end = data.find(b"\0", pos)
        pos = len(data) if end < 0 else end + 1
    if flg & 2:
        pos += 2
    raw = data[pos:-8]
    crc, isize = struct.unpack_from("<II", data, len(data) - 8)
    content = zlib.decompress(raw, -15)
    if (crc32(content), len(content) & 0xffffffff) != (crc, isize):
        raise ValueError("CRC Failed")
    return [{"name": name, "size": len(content), "packed": len(raw), "mtime": mt, "content": content}]

def find_eocd(data):
    i = data.rfind(b"PK\x05\x06")
    if i < 0:
        raise ValueError("not a zip archive")
    return i

def read_zip(archive):
    data = open(archive, "rb").read()
    e = find_eocd(data)
    vals = struct.unpack_from("<IHHHHIIH", data, e)
    n, cd_size, cd_off = vals[4], vals[5], vals[6]
    pos = cd_off
    entries = []
    for _ in range(n):
        sig = struct.unpack_from("<I", data, pos)[0]
        if sig != 0x02014b50:
            break
        v = struct.unpack_from("<IHHHHHHIIIHHHHHII", data, pos)
        meth, dost, dosd, crc, csize, size, namelen, extralen, comlen, off = v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11], v[12], v[16]
        pos += 46
        name = data[pos:pos+namelen].decode("utf-8", "replace")
        pos += namelen + extralen + comlen
        yr = ((dosd >> 9) & 127) + 1980; mo = (dosd >> 5) & 15; da = dosd & 31
        hr = (dost >> 11) & 31; mi = (dost >> 5) & 63; se = (dost & 31) * 2
        try:
            mt = time.mktime((yr, mo, da, hr, mi, se, 0, 0, -1))
        except Exception:
            mt = 0
        entries.append({"name": name, "size": size, "packed": csize, "method": meth, "crc": crc, "off": off, "mtime": mt})
    return entries, data

def zip_payload(ent, data):
    p = ent["off"]
    sig = struct.unpack_from("<I", data, p)[0]
    if sig != 0x04034b50:
        raise ValueError("bad local header")
    v = struct.unpack_from("<IHHHHHIIIHH", data, p)
    name_len, extra_len = v[9], v[10]
    start = p + 30 + name_len + extra_len
    comp = data[start:start+ent["packed"]]
    if ent["method"] == 0:
        return comp
    if ent["method"] == 8:
        return zlib.decompress(comp, -15)
    raise ValueError("unsupported compression method")

def list_archive(archive, opts):
    typ = arc_type(archive, opts.get("type"))
    size = os.path.getsize(archive)
    print("Scanning the drive for archives:")
    print(f"1 file, {kib(size)}\n")
    print(f"Listing archive: {archive}\n")
    print("--")
    print(f"Path = {archive}")
    print(f"Type = {typ}")
    print(f"Physical Size = {size}")
    if typ == "tar":
        ents = read_tar(archive)
    elif typ == "gzip":
        ents = read_gzip(archive)
    else:
        ents, _ = read_zip(archive)
    if opts.get("slt"):
        print()
        for e in ents:
            print("----------")
            print(f"Path = {e['name']}")
            print("Folder = -")
            print(f"Size = {e['size']}")
            print(f"Packed Size = {e['packed']}")
            print(f"Modified = {fmt_dt(e['mtime']) if e['mtime'] else ''}")
            print()
        return
    print()
    print("   Date      Time    Attr         Size   Compressed  Name")
    print("------------------- ----- ------------ ------------  ------------------------")
    total = packed = 0
    last = time.time()
    for e in ents:
        total += e["size"]; packed += e["packed"]; last = e["mtime"] or last
        print(f"{fmt_dt(e['mtime']) if e['mtime'] else '                   '} ..... {e['size']:12d} {e['packed']:12d}  {e['name']}")
    print("------------------- ----- ------------ ------------  ------------------------")
    print(f"{fmt_dt(last)} {total:18d} {packed:12d}  {len(ents)} files")

def extract_archive(archive, opts, names):
    typ = arc_type(archive, opts.get("type"))
    size = os.path.getsize(archive)
    print("Scanning the drive for archives:")
    print(f"1 file, {kib(size)}\n")
    print(("Testing" if opts.get("test") else "Extracting") + f" archive: {archive}")
    print("--")
    print(f"Path = {archive}")
    print(f"Type = {typ}")
    print(f"Physical Size = {size}\n")
    total = 0
    outdir = opts.get("out") or "."
    if typ == "tar":
        ents = read_tar(archive)
        with open(archive, "rb") as f:
            for e in ents:
                total += e["size"]
                if names and e["name"] not in names: continue
                if opts.get("test"): continue
                f.seek(e["off"])
                content = f.read(e["size"])
                write_out(e["name"], content, outdir, opts)
    elif typ == "gzip":
        ents = read_gzip(archive)
        for e in ents:
            total += e["size"]
            if not opts.get("test"):
                write_out(e["name"], e["content"], outdir, opts)
    else:
        ents, data = read_zip(archive)
        for e in ents:
            total += e["size"]
            if names and e["name"] not in names: continue
            content = zip_payload(e, data)
            if crc32(content) != e["crc"]:
                raise ValueError("CRC Failed")
            if not opts.get("test"):
                write_out(e["name"], content, outdir, opts)
    print("Everything is Ok\n")
    print(f"Size:       {total}")
    print(f"Compressed: {size}")

def write_out(name, content, outdir, opts):
    if opts.get("stdout"):
        sys.stdout.buffer.write(content); return
    rel = os.path.basename(name) if opts.get("flat") else safe_path(name)
    if not rel: return
    dest = os.path.join(outdir, rel)
    os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
    with open(dest, "wb") as f:
        f.write(content)

def cmd_add(cmd, opts, args):
    if not args:
        print(HELP, end=""); return 0
    archive, files = args[0], collect(args[1:] or ["*"], opts.get("recurse"))
    total = sum(os.path.getsize(p) for p in files)
    print("Scanning the drive:")
    print(f"{len(files)} files, {kib(total)}\n")
    print(f"Creating archive: {archive}\n")
    print(f"Add new data to archive: {len(files)} files, {kib(total)}\n")
    typ = arc_type(archive, opts.get("type"))
    if typ == "tar":
        create_tar(archive, files)
    elif typ == "gzip":
        create_gzip(archive, files)
    else:
        create_zip(archive, files)
    print(f"\nFiles read from disk: {len(files)}")
    print(f"Archive size: {kib(os.path.getsize(archive))}")
    print("Everything is Ok")
    return 0

def cmd_hash(opts, args):
    files = collect(args or ["*"], opts.get("recurse"))
    total = sum(os.path.getsize(p) for p in files)
    alg = opts.get("hash", "CRC32").upper()
    print("Scanning")
    print(f"{len(files)} file{'s' if len(files)!=1 else ''}, {kib(total)}\n")
    print(f"{alg:<8}           Size  Name")
    print("-------- -------------  ------------")
    combined = b""
    last = ""
    for p in files:
        data = open(p, "rb").read(); combined += data
        hv = hash_value(alg, data); last = hv
        print(f"{hv} {len(data):13d}  {p}")
    print("-------- -------------  ------------")
    print(f"{hash_value(alg, combined) if files else '00000000'} {total:13d}  \n")
    print(f"Size: {total}\n")
    print(f"{alg}  for data:              {hash_value(alg, combined) if files else '00000000'}\n")
    print("Everything is Ok")
    return 0

def hash_value(alg, data):
    if alg in ("CRC32", "CRC"):
        return f"{crc32(data):08X}"
    if alg == "SHA1":
        return hashlib.sha1(data).hexdigest().upper()
    if alg == "SHA256":
        return hashlib.sha256(data).hexdigest().upper()
    if alg == "MD5":
        return hashlib.md5(data).hexdigest().upper()
    return f"{crc32(data):08X}"

def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("--help", "-h", "-?"):
        print(HELP, end="")
        return 0
    cmd = argv[0].lower()
    opts, args = parse(argv[1:])
    if cmd == "i":
        print(INFO, end=""); return 0
    banner()
    try:
        if cmd in ("a", "u"):
            return cmd_add(cmd, opts, args)
        if cmd == "h":
            return cmd_hash(opts, args)
        if cmd in ("l",):
            if not args: raise FileNotFoundError("")
            list_archive(args[0], opts); return 0
        if cmd in ("x", "e", "t"):
            if not args: raise FileNotFoundError("")
            opts["flat"] = (cmd == "e")
            opts["test"] = (cmd == "t")
            extract_archive(args[0], opts, args[1:]); return 0
        if cmd == "b":
            print("Tot:          0     0     0     0     0     0")
            return 0
        print("\n\nCommand Line Error:")
        print("Unsupported command:")
        print(cmd)
        return 7
    except FileNotFoundError as e:
        name = e.filename or (args[0] if args else "")
        print("Scanning the drive for archives:\n")
        print("ERROR: errno=2 : No such file or directory")
        print(name)
        print("\n\nSystem ERROR:")
        print("errno=2 : No such file or directory")
        return 2
    except Exception as e:
        print("\nERROR:", e)
        return 2

if __name__ == "__main__":
    sys.exit(main())
