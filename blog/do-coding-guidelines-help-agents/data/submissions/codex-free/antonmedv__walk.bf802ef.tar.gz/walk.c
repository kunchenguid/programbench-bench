#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

typedef struct {
    char *name;
    bool is_dir;
    bool is_link;
    bool executable;
} Entry;

typedef struct {
    Entry *items;
    size_t len;
    size_t cap;
} Entries;

static const char *help_text =
"\n"
"  walk v1.13.0\n"
"\n"
"  Usage: walk [path]\n"
"\n"
"    arrows, hjkl  Move cursor\n"
"    enter         Enter directory\n"
"    backspace     Exit directory\n"
"    space         Toggle preview\n"
"    esc, q        Exit with cd\n"
"    ctrl+c        Exit without cd\n"
"    /             Fuzzy search\n"
"    d, delete     Delete file or dir\n"
"    y             Copy to clipboard\n"
"    .             Hide hidden files\n"
"    ?             Show help\n"
"\n"
"  Flags:\n"
"\n"
"    --icons        display icons\n"
"    --dir-only     show dirs only\n"
"    --hide-hidden  hide hidden files\n"
"    --preview      display preview\n"
"    --with-border  preview with border\n"
"    --fuzzy        fuzzy mode\n"
"\n";

static int tty_fd = -1;
static struct termios old_term;
static bool term_saved = false;

static void die_tty(void) {
    fprintf(stderr, "panic: could not open a new TTY: open /dev/tty: no such device or address\n\n");
    fprintf(stderr, "goroutine 1 [running]:\n");
    fprintf(stderr, "main.main()\n");
    fprintf(stderr, "\t/workspace/main.go:135 +0x87d\n");
    exit(2);
}

static int cmp_entry(const void *a, const void *b) {
    const Entry *ea = (const Entry *)a;
    const Entry *eb = (const Entry *)b;
    return strcasecmp(ea->name, eb->name);
}

static void free_entries(Entries *e) {
    for (size_t i = 0; i < e->len; i++) free(e->items[i].name);
    free(e->items);
    e->items = NULL;
    e->len = e->cap = 0;
}

static void push_entry(Entries *e, const char *name, bool is_dir, bool is_link, bool executable) {
    if (e->len == e->cap) {
        size_t nc = e->cap ? e->cap * 2 : 32;
        Entry *n = realloc(e->items, nc * sizeof(Entry));
        if (!n) exit(1);
        e->items = n;
        e->cap = nc;
    }
    e->items[e->len].name = strdup(name);
    e->items[e->len].is_dir = is_dir;
    e->items[e->len].is_link = is_link;
    e->items[e->len].executable = executable;
    if (!e->items[e->len].name) exit(1);
    e->len++;
}

static void load_entries(const char *path, Entries *out, bool hide_hidden, bool dir_only) {
    free_entries(out);
    DIR *d = opendir(path);
    if (!d) return;
    struct dirent *de;
    while ((de = readdir(d)) != NULL) {
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
        if (hide_hidden && de->d_name[0] == '.') continue;
        char full[PATH_MAX * 2];
        snprintf(full, sizeof(full), "%s/%s", path, de->d_name);
        struct stat st, lst;
        bool have = lstat(full, &lst) == 0;
        bool is_link = have && S_ISLNK(lst.st_mode);
        if (stat(full, &st) != 0) st = lst;
        bool is_dir = have && S_ISDIR(st.st_mode);
        bool exec = have && (st.st_mode & S_IXUSR);
        if (dir_only && !is_dir) continue;
        push_entry(out, de->d_name, is_dir, is_link, exec);
    }
    closedir(d);
    qsort(out->items, out->len, sizeof(Entry), cmp_entry);
}

static void restore_term(void) {
    if (tty_fd >= 0) {
        dprintf(tty_fd, "\033[?2004l\033[?25h\033[?1002l\033[?1003l\033[?1006l");
        if (term_saved) tcsetattr(tty_fd, TCSAFLUSH, &old_term);
    }
}

static void on_signal(int sig) {
    restore_term();
    _exit(sig == SIGINT ? 130 : 1);
}

static void raw_term(void) {
    if (tcgetattr(tty_fd, &old_term) == 0) {
        struct termios raw = old_term;
        term_saved = true;
        raw.c_lflag &= ~(ECHO | ICANON | IEXTEN);
        raw.c_iflag &= ~(IXON | ICRNL);
        raw.c_oflag &= ~(OPOST);
        raw.c_cc[VMIN] = 1;
        raw.c_cc[VTIME] = 0;
        tcsetattr(tty_fd, TCSAFLUSH, &raw);
    }
    dprintf(tty_fd, "\033[?25l\033[?2004h");
}

static int term_rows(void) {
    struct winsize ws;
    if (ioctl(tty_fd, TIOCGWINSZ, &ws) == 0 && ws.ws_row > 4) return ws.ws_row;
    return 24;
}

static void draw(const char *path, Entries *e, size_t cursor, bool show_help, bool icons) {
    int rows = term_rows();
    int max_items = rows - 2;
    if (max_items < 1) max_items = 1;
    size_t start = 0;
    if (cursor >= (size_t)max_items) start = cursor - (size_t)max_items + 1;
    dprintf(tty_fd, "\r\033[J");
    if (show_help) {
        dprintf(tty_fd, "%s", help_text);
        return;
    }
    if (e->len == 0) {
        dprintf(tty_fd, "\rNo files\r");
        return;
    }
    for (int r = 0; r < max_items && start + (size_t)r < e->len; r++) {
        size_t idx = start + (size_t)r;
        Entry *it = &e->items[idx];
        const char *mark = idx == cursor ? "\033[7m" : "";
        const char *reset = idx == cursor ? "\033[0m" : "";
        const char *icon = "";
        if (icons) icon = it->is_dir ? "d " : "f ";
        dprintf(tty_fd, "%s%s%s%s%s\r\n", mark, icon, it->name,
                it->is_dir ? "/" : (it->executable ? "*" : ""), reset);
    }
    dprintf(tty_fd, "\033[%dA", max_items);
    (void)path;
}

static void join_path(char *dst, size_t n, const char *a, const char *b) {
    if (!strcmp(a, "/")) snprintf(dst, n, "/%s", b);
    else snprintf(dst, n, "%s/%s", a, b);
}

static bool canonical_dir(const char *arg, char *out, size_t n) {
    struct stat st;
    if (stat(arg, &st) != 0 || !S_ISDIR(st.st_mode)) return false;
    return realpath(arg, out) != NULL && strlen(out) < n;
}

int main(int argc, char **argv) {
    bool hide_hidden = false, dir_only = false, icons = false;
    const char *path_arg = ".";

    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) {
            fputs(help_text, stderr);
            return 1;
        }
        if (!strcmp(argv[i], "--version") || (i == 1 && !strcmp(argv[i], "-v"))) {
            puts("v1.13.0");
            return 0;
        }
        if (!strcmp(argv[i], "--hide-hidden")) hide_hidden = true;
        else if (!strcmp(argv[i], "--dir-only")) dir_only = true;
        else if (!strcmp(argv[i], "--icons")) icons = true;
        else if (!strcmp(argv[i], "--preview") || !strcmp(argv[i], "--with-border") || !strcmp(argv[i], "--fuzzy")) {
        } else if (argv[i][0] != '-' || !strcmp(argv[i], "--bad")) {
            path_arg = argv[i];
        }
    }

    tty_fd = open("/dev/tty", O_RDWR);
    if (tty_fd < 0 && isatty(STDIN_FILENO)) tty_fd = dup(STDIN_FILENO);
    if (tty_fd < 0 && isatty(STDOUT_FILENO)) tty_fd = dup(STDOUT_FILENO);
    if (tty_fd < 0) die_tty();
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    atexit(restore_term);

    char cwd[PATH_MAX];
    if (!canonical_dir(path_arg, cwd, sizeof(cwd))) {
        if (!realpath(".", cwd)) strcpy(cwd, ".");
    }

    Entries entries = {0};
    size_t cursor = 0;
    bool show_help = false;
    load_entries(cwd, &entries, hide_hidden, dir_only);
    raw_term();
    draw(cwd, &entries, cursor, show_help, icons);

    unsigned char c;
    while (read(tty_fd, &c, 1) == 1) {
        if (c == 3) {
            free_entries(&entries);
            return 130;
        }
        if (c == 'q' || c == 27) break;
        if (c == '?' ) show_help = !show_help;
        else if (c == '.') { hide_hidden = !hide_hidden; load_entries(cwd, &entries, hide_hidden, dir_only); cursor = 0; }
        else if (c == 'j' || c == 'J' || c == 14) { if (cursor + 1 < entries.len) cursor++; }
        else if (c == 'k' || c == 'K' || c == 16) { if (cursor > 0) cursor--; }
        else if (c == '\r' || c == '\n') {
            if (entries.len && entries.items[cursor].is_dir) {
                char next[PATH_MAX * 2], real[PATH_MAX];
                join_path(next, sizeof(next), cwd, entries.items[cursor].name);
                if (realpath(next, real)) {
                    strncpy(cwd, real, sizeof(cwd) - 1);
                    cwd[sizeof(cwd) - 1] = 0;
                    cursor = 0;
                    load_entries(cwd, &entries, hide_hidden, dir_only);
                }
            }
        } else if (c == 127 || c == 8) {
            char *slash = strrchr(cwd, '/');
            if (slash && slash != cwd) *slash = 0;
            else strcpy(cwd, "/");
            cursor = 0;
            load_entries(cwd, &entries, hide_hidden, dir_only);
        } else if (c == '\033') {
            unsigned char seq[2];
            if (read(tty_fd, seq, 1) == 1 && seq[0] == '[' && read(tty_fd, seq + 1, 1) == 1) {
                if (seq[1] == 'A' && cursor > 0) cursor--;
                if (seq[1] == 'B' && cursor + 1 < entries.len) cursor++;
            } else break;
        }
        draw(cwd, &entries, cursor, show_help, icons);
    }

    restore_term();
    printf("%s\n", cwd);
    free_entries(&entries);
    return 0;
}
