#define _GNU_SOURCE
#include <sys/inotify.h>
#include <sys/poll.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <unistd.h>

typedef struct {
    char *path;
    int wd;
    int is_dir_watch;
} Watch;

static int opt_a, opt_c, opt_d, opt_n, opt_p, opt_r, opt_s, opt_x, opt_z;
static char **cmdv;
static int cmdc;
static Watch *watches;
static size_t nwatches, capwatches;
static char *first_file;
static char *trigger_file;
static volatile sig_atomic_t got_int;
static pid_t child_pid = -1;

static void on_int(int sig) {
    (void)sig;
    got_int = 1;
    if (child_pid > 0)
        kill(-child_pid, SIGTERM);
}

static void usage(FILE *out, int summary) {
    fprintf(out, "release: 5.7\n");
    fprintf(out, "usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames\n");
    if (summary) {
        fprintf(out, "summary:\n");
        fprintf(out, "    -a  Do not consolidate events\n");
        fprintf(out, "    -c  Clear screen before execution\n");
        fprintf(out, "    -d  Track files added or removed from directories\n");
        fprintf(out, "    -n  Non-interactive mode\n");
        fprintf(out, "    -p  Wait for first event\n");
        fprintf(out, "    -r  Run as a background process, use signal to restart\n");
        fprintf(out, "    -s  Evaluate using a shell\n");
        fprintf(out, "    -x  Format exit status\n");
        fprintf(out, "    -z  Exit after the utility completes\n");
        fprintf(out, "docs:\n");
        fprintf(out, "    man entr\n");
    } else {
        fprintf(out, "hint: use -h to display option summary\n");
    }
}

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n);
    if (!q) {
        perror("executable");
        exit(1);
    }
    return q;
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) {
        perror("executable");
        exit(1);
    }
    return r;
}

static char *dirname_dup(const char *path) {
    const char *slash = strrchr(path, '/');
    if (!slash)
        return xstrdup(".");
    if (slash == path)
        return xstrdup("/");
    size_t n = (size_t)(slash - path);
    char *d = malloc(n + 1);
    if (!d) exit(1);
    memcpy(d, path, n);
    d[n] = '\0';
    return d;
}

static bool watch_exists(const char *path, int is_dir) {
    for (size_t i = 0; i < nwatches; i++)
        if (watches[i].is_dir_watch == is_dir && strcmp(watches[i].path, path) == 0)
            return true;
    return false;
}

static void add_watch_record(const char *path, int is_dir) {
    if (watch_exists(path, is_dir))
        return;
    if (nwatches == capwatches) {
        capwatches = capwatches ? capwatches * 2 : 16;
        watches = xrealloc(watches, capwatches * sizeof(*watches));
    }
    watches[nwatches].path = xstrdup(path);
    watches[nwatches].wd = -1;
    watches[nwatches].is_dir_watch = is_dir;
    nwatches++;
}

static int signal_from_env(void) {
    const char *s = getenv("ENTR_RESTART_SIGNAL");
    if (!s || !*s) return SIGTERM;
    if (!strcmp(s, "HUP") || !strcmp(s, "SIGHUP")) return SIGHUP;
    if (!strcmp(s, "INT") || !strcmp(s, "SIGINT")) return SIGINT;
    if (!strcmp(s, "QUIT") || !strcmp(s, "SIGQUIT")) return SIGQUIT;
    if (!strcmp(s, "TERM") || !strcmp(s, "SIGTERM")) return SIGTERM;
    if (!strcmp(s, "USR1") || !strcmp(s, "SIGUSR1")) return SIGUSR1;
    if (!strcmp(s, "USR2") || !strcmp(s, "SIGUSR2")) return SIGUSR2;
    return SIGTERM;
}

static void clear_screen(void) {
    if (opt_c == 1)
        fputs("\033[2J\033[H", stdout);
    else if (opt_c > 1)
        fputs("\033[3J\033[2J\033[H", stdout);
    fflush(stdout);
}

static char **build_argv(void) {
    char **av;
    char *file = trigger_file ? trigger_file : first_file;
    if (opt_s) {
        av = calloc(5, sizeof(char *));
        if (!av) exit(1);
        av[0] = (char *)(getenv("SHELL") && *getenv("SHELL") ? getenv("SHELL") : "/bin/sh");
        av[1] = (char *)"-c";
        av[2] = cmdv[0];
        av[3] = file;
        av[4] = NULL;
        return av;
    }
    av = calloc((size_t)cmdc + 1, sizeof(char *));
    if (!av) exit(1);
    for (int i = 0; i < cmdc; i++)
        av[i] = (strcmp(cmdv[i], "/_") == 0) ? file : cmdv[i];
    av[cmdc] = NULL;
    return av;
}

static int run_child_sync(void) {
    clear_screen();
    char **av = build_argv();
    pid_t p = fork();
    if (p < 0) {
        perror("executable");
        free(av);
        return 1;
    }
    if (p == 0) {
        setenv("PAGER", getenv("PAGER") ? getenv("PAGER") : "/bin/cat", 0);
        execvp(av[0], av);
        fprintf(stderr, "executable: exec %s: %s\n", av[0], strerror(errno));
        _exit(127);
    }
    child_pid = p;
    int st = 0;
    while (waitpid(p, &st, 0) < 0 && errno == EINTR) {
        if (got_int) break;
    }
    child_pid = -1;
    free(av);
    if (WIFEXITED(st)) return WEXITSTATUS(st);
    if (WIFSIGNALED(st)) return 128 + WTERMSIG(st);
    return 1;
}

static int start_persistent(void) {
    clear_screen();
    char **av = build_argv();
    pid_t p = fork();
    if (p < 0) {
        perror("executable");
        free(av);
        return 1;
    }
    if (p == 0) {
        setpgid(0, 0);
        setenv("PAGER", getenv("PAGER") ? getenv("PAGER") : "/bin/cat", 0);
        execvp(av[0], av);
        fprintf(stderr, "executable: exec %s: %s\n", av[0], strerror(errno));
        _exit(127);
    }
    setpgid(p, p);
    child_pid = p;
    free(av);
    return 0;
}

static void stop_persistent(void) {
    if (child_pid <= 0) return;
    kill(-child_pid, signal_from_env());
    int st;
    while (waitpid(child_pid, &st, 0) < 0 && errno == EINTR) {}
    child_pid = -1;
}

static int reap_if_done(int *status_out) {
    if (child_pid <= 0) return 0;
    int st;
    pid_t r = waitpid(child_pid, &st, WNOHANG);
    if (r == child_pid) {
        child_pid = -1;
        if (WIFEXITED(st)) *status_out = WEXITSTATUS(st);
        else if (WIFSIGNALED(st)) *status_out = 128 + WTERMSIG(st);
        else *status_out = 1;
        return 1;
    }
    return 0;
}

static int add_inotify_watches(int fd) {
    uint32_t fmask = IN_CLOSE_WRITE | IN_MODIFY | IN_ATTRIB | IN_MOVED_TO | IN_MOVED_FROM | IN_DELETE_SELF | IN_MOVE_SELF;
    uint32_t dmask = IN_CREATE | IN_DELETE | IN_MOVED_TO | IN_MOVED_FROM;
    for (size_t i = 0; i < nwatches; i++) {
        watches[i].wd = inotify_add_watch(fd, watches[i].path, watches[i].is_dir_watch ? dmask : fmask);
        if (watches[i].wd < 0) {
            fprintf(stderr, "executable: unable to watch '%s'\n", watches[i].path);
            return -1;
        }
    }
    return 0;
}

static Watch *by_wd(int wd) {
    for (size_t i = 0; i < nwatches; i++)
        if (watches[i].wd == wd)
            return &watches[i];
    return NULL;
}

static int consume_events(int fd) {
    char buf[16384] __attribute__((aligned(__alignof__(struct inotify_event))));
    int dir_altered = 0, changed = 0;
    for (;;) {
        ssize_t n = read(fd, buf, sizeof(buf));
        if (n < 0) {
            if (errno == EAGAIN || errno == EWOULDBLOCK) break;
            if (errno == EINTR) continue;
            return -1;
        }
        if (n == 0) break;
        for (char *p = buf; p < buf + n; ) {
            struct inotify_event *ev = (struct inotify_event *)p;
            Watch *w = by_wd(ev->wd);
            if (w) {
                if (w->is_dir_watch) {
                    if (ev->len && opt_d == 1 && ev->name[0] == '.') {
                        p += sizeof(*ev) + ev->len;
                        continue;
                    }
                    dir_altered = 1;
                } else if (!trigger_file) {
                    trigger_file = xstrdup(w->path);
                    changed = 1;
                } else {
                    changed = 1;
                }
                if (getenv("EV_TRACE"))
                    fprintf(stderr, "%zu/%zu: fflags: 0x%x %s\n", (size_t)(w - watches), nwatches, ev->mask, w->path);
            }
            p += sizeof(*ev) + ev->len;
        }
    }
    if (dir_altered) return 2;
    return changed ? 1 : 0;
}

static int watch_loop(void) {
    int fd = inotify_init1(IN_NONBLOCK | IN_CLOEXEC);
    if (fd < 0) {
        perror("executable");
        return 1;
    }
    if (getenv("EV_TRACE"))
        fprintf(stderr, "open_max: %ld\n", sysconf(_SC_OPEN_MAX));
    if (add_inotify_watches(fd) < 0) {
        close(fd);
        return 1;
    }
    struct pollfd pfd[2];
    pfd[0].fd = fd;
    pfd[0].events = POLLIN;
    pfd[1].fd = opt_n ? -1 : STDIN_FILENO;
    pfd[1].events = POLLIN;
    for (;;) {
        if (got_int) {
            stop_persistent();
            close(fd);
            return 0;
        }
        int child_status = 0;
        if (reap_if_done(&child_status) && opt_z) {
            close(fd);
            return child_status;
        }
        int pr = poll(pfd, 2, 200);
        if (pr < 0) {
            if (errno == EINTR) continue;
            perror("executable");
            close(fd);
            return 1;
        }
        if (pr == 0) continue;
        if (pfd[1].revents & POLLIN) {
            char c;
            if (read(STDIN_FILENO, &c, 1) == 1) {
                if (c == 'q') {
                    stop_persistent();
                    close(fd);
                    return 0;
                }
                if (c == ' ') {
                    if (opt_r) {
                        stop_persistent();
                        start_persistent();
                    } else {
                        int rc = run_child_sync();
                        if (opt_z) { close(fd); return rc; }
                    }
                }
            }
        }
        if (pfd[0].revents & POLLIN) {
            int ev = consume_events(fd);
            if (ev == 2) {
                if (opt_r) {
                    stop_persistent();
                    start_persistent();
                } else {
                    run_child_sync();
                }
                fprintf(stderr, "executable: directory altered\n");
                stop_persistent();
                close(fd);
                return 2;
            }
            if (ev == 0)
                continue;
            if (opt_r) {
                stop_persistent();
                start_persistent();
                if (opt_z && child_pid <= 0) { close(fd); return 0; }
            } else {
                int rc = run_child_sync();
                free(trigger_file);
                trigger_file = NULL;
                if (opt_z) { close(fd); return rc; }
                if (!opt_a) {
                    char tmp[4096];
                    while (read(fd, tmp, sizeof(tmp)) > 0) {}
                }
            }
        }
    }
}

static void parse_opts(int argc, char **argv) {
    opterr = 0;
    int ch;
    while ((ch = getopt(argc, argv, "+acdnprsxzh")) != -1) {
        switch (ch) {
        case 'a': opt_a++; break;
        case 'c': opt_c++; break;
        case 'd': opt_d++; break;
        case 'n': opt_n++; break;
        case 'p': opt_p++; break;
        case 'r': opt_r++; break;
        case 's': opt_s++; break;
        case 'x': opt_x++; break;
        case 'z': opt_z++; break;
        case 'h': usage(stdout, 1); exit(0);
        default:
            fprintf(stderr, "%s: invalid option -- '%c'\n", argv[0], optopt ? optopt : ch);
            usage(stderr, 0);
            exit(1);
        }
    }
    cmdv = &argv[optind];
    cmdc = argc - optind;
    if (cmdc <= 0) {
        usage(stderr, 0);
        exit(1);
    }
    if (opt_s && cmdc != 1) {
        fprintf(stderr, "executable: -s requires commands to be formatted as a single argument\n");
        exit(1);
    }
    (void)opt_x;
}

static int read_files(void) {
    char *line = NULL;
    size_t n = 0;
    ssize_t len;
    int regulars = 0;
    while ((len = getline(&line, &n, stdin)) >= 0) {
        while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r'))
            line[--len] = '\0';
        if (len == 0) continue;
        struct stat st;
        if (stat(line, &st) < 0) {
            fprintf(stderr, "executable: unable to stat '%s'\n", line);
            continue;
        }
        if (S_ISREG(st.st_mode)) {
            if (!first_file) first_file = xstrdup(line);
            add_watch_record(line, 0);
            regulars++;
            if (opt_d) {
                char *d = dirname_dup(line);
                add_watch_record(d, 1);
                free(d);
            }
        } else if (S_ISDIR(st.st_mode)) {
            if (!first_file) first_file = xstrdup(line);
            if (opt_d)
                add_watch_record(line, 1);
        }
    }
    free(line);
    return regulars;
}

int main(int argc, char **argv) {
    signal(SIGINT, on_int);
    signal(SIGTERM, on_int);
    parse_opts(argc, argv);
    int regulars = read_files();
    if (regulars == 0) {
        fprintf(stderr, "executable: No regular files to watch\n");
        return 1;
    }
    if (!opt_n) {
        struct termios t;
        int ttyfd = open("/dev/tty", O_RDONLY);
        if (ttyfd < 0 || tcgetattr(ttyfd, &t) < 0) {
            if (ttyfd >= 0) close(ttyfd);
            fprintf(stderr, "executable: unable to get terminal attributes, use '-n' to run non-interactively\n");
            return 1;
        }
        close(ttyfd);
    }
    if (!opt_p) {
        if (opt_r) {
            int rc = start_persistent();
            if (rc) return rc;
        } else {
            int rc = run_child_sync();
            if (opt_z) return rc;
        }
    }
    return watch_loop();
}
