#!/usr/bin/env python3
import datetime as _dt
import json
import os
import shlex
import signal
import subprocess
import sys
import time


HELP = """A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: executable [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use `t` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version
"""


class Opts:
    def __init__(self):
        self.batch = False
        self.reverse = False
        self.line_number = False
        self.exec_direct = False
        self.interval = 2.0
        self.shell = "sh -c"
        self.output = "output"
        self.logfile = None
        self.after = None
        self.command = []
        self.differences = None
        self.precise = False


def die(msg, status=2, usage=False):
    print(msg, file=sys.stderr)
    if usage:
        print("\nUsage: hwatch [OPTIONS] [command]...\n", file=sys.stderr)
    else:
        print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    raise SystemExit(status)


def parse(argv):
    env = os.environ.get("HWATCH")
    if env:
        argv = shlex.split(env) + argv
    opts = Opts()
    i = 0
    command_started = False
    while i < len(argv):
        a = argv[i]
        if command_started:
            opts.command.append(a)
            i += 1
            continue
        if a == "--":
            command_started = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print("hwatch 0.3.19")
            raise SystemExit(0)
        if a in ("-b", "--batch"):
            opts.batch = True
        elif a in ("-r", "--reverse"):
            opts.reverse = True
        elif a in ("-N", "--line-number"):
            opts.line_number = True
        elif a in ("-x", "--exec", "-e"):
            opts.exec_direct = True
        elif a in ("--precise",):
            opts.precise = True
        elif a in ("-B", "--beep", "--border", "--with-scrollbar", "--mouse", "-c", "--color",
                   "-C", "--compress", "-t", "--no-title", "--enable-summary-char",
                   "--no-help-banner", "--no-summary", "-O", "--diff-output-only"):
            pass
        elif a in ("-n", "--interval"):
            if i + 1 >= len(argv):
                die("error: a value is required for '--interval <interval>' but none was supplied")
            i += 1
            val = argv[i].replace(",", ".")
            try:
                opts.interval = max(0.001, float(val))
            except ValueError:
                die(f"error: invalid value '{argv[i]}' for '--interval <interval>': invalid float literal")
        elif a in ("-s", "--shell"):
            if i + 1 >= len(argv):
                die("error: a value is required for '--shell <shell_command>' but none was supplied")
            i += 1
            opts.shell = argv[i]
        elif a in ("-A", "--aftercommand"):
            if i + 1 >= len(argv):
                die("error: a value is required for '--aftercommand <after_command>' but none was supplied")
            i += 1
            opts.after = argv[i]
        elif a in ("-l", "--logfile"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                opts.logfile = argv[i]
            else:
                opts.logfile = ""
        elif a in ("-L", "--limit", "--tab-size", "-K", "--keymap"):
            if i + 1 >= len(argv):
                die(f"error: a value is required for '{a}' but none was supplied")
            i += 1
        elif a in ("-d", "--differences"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                val = argv[i]
                if val not in ("none", "watch", "line", "word"):
                    tip = "\n\n  tip: a similar value exists: 'none'" if val and val[0] == "n" else ""
                    die(f"error: invalid value '{val}' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]{tip}")
                opts.differences = val
            else:
                opts.differences = "watch"
        elif a in ("-o", "--output"):
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                val = argv[i]
                if val not in ("output", "stdout", "stderr"):
                    die(f"error: invalid value '{val}' for '--output [<output>]'\n  [possible values: output, stdout, stderr]")
                opts.output = val
            else:
                # The reference panics here; exit non-zero with a close message.
                print("\nthread 'main' panicked at src/main.rs:537:65:", file=sys.stderr)
                print("called `Option::unwrap()` on a `None` value", file=sys.stderr)
                raise SystemExit(101)
        elif a.startswith("-"):
            command_started = True
            opts.command.append(a)
        else:
            command_started = True
            opts.command.append(a)
        i += 1
    return opts


def timestamp():
    return _dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]


def banner(ts):
    return f"\033[38;5;240m=====[{ts}]=========================\033[0m"


def run_command(opts):
    if opts.exec_direct:
        if not opts.command:
            return 127, "", ""
        p = subprocess.run(opts.command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return p.returncode, p.stdout, p.stderr
    cmd = " ".join(opts.command)
    shell_words = shlex.split(opts.shell)
    if "{COMMAND}" in opts.shell:
        cmdline = [w.replace("{COMMAND}", cmd) for w in shell_words]
    else:
        cmdline = shell_words + [cmd]
    p = subprocess.run(cmdline, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return p.returncode, p.stdout, p.stderr


def selected_output(opts, stdout, stderr):
    if opts.output == "stdout":
        return stdout
    if opts.output == "stderr":
        return stderr
    return stderr + stdout


def transform(opts, data):
    if opts.reverse:
        lines = data.split("\n")
        data = "\n".join(reversed(lines))
    if opts.line_number:
        lines = data.split("\n")
        width = len(str(len(lines)))
        data = "\n".join(
            f"\033[38;5;240m{str(i).rjust(width)}\033[0m\033[38;5;240m | \033[0m{line}"
            for i, line in enumerate(lines, 1)
        )
    return data


def append_log(path, ts, opts, status, out, stdout, stderr):
    if path is None:
        return
    rec = {
        "timestamp": ts,
        "command": " ".join(opts.command),
        "status": status == 0,
        "output": out,
        "stdout": stdout,
        "stderr": stderr,
    }
    target = path or "hwatch.log"
    with open(target, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")


def batch(opts):
    previous = None
    while True:
        start = time.time()
        ts = timestamp()
        status, stdout, stderr = run_command(opts)
        out = selected_output(opts, stdout, stderr)
        if previous is None or out != previous:
            text = transform(opts, out)
            print(banner(ts))
            print(text)
            sys.stdout.flush()
            append_log(opts.logfile, ts, opts, status, out, stdout, stderr)
            if opts.after and previous is not None:
                data = json.dumps({"timestamp": ts, "output": out, "stdout": stdout, "stderr": stderr})
                env = os.environ.copy()
                env["HWATCH_DATA"] = data
                subprocess.run(opts.after, shell=True, env=env)
        previous = out
        delay = opts.interval
        if opts.precise:
            delay = max(0.0, opts.interval - (time.time() - start))
        time.sleep(delay)


def main(argv):
    opts = parse(argv)
    if not opts.command:
        die("error: command not specified and logfile is empty.", usage=True)
    if opts.batch:
        batch(opts)
    else:
        return


if __name__ == "__main__":
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    try:
        main(sys.argv[1:])
    except KeyboardInterrupt:
        pass
