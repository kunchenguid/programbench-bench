#!/usr/bin/env python3
import json
import os
import re
import sys
from pathlib import Path

VERSION = "tree-sitter 0.27.0"
RED = "\x1b[31m"
YELLOW = "\x1b[33m"
RESET = "\x1b[0m"

COMMANDS = [
    ("init-config", "Generate a default config file"),
    ("init", "Initialize a grammar repository"),
    ("generate", "Generate a parser"),
    ("build", "Compile a parser"),
    ("parse", "Parse files"),
    ("test", "Run a parser's tests"),
    ("version", "Display or increment the version of a grammar"),
    ("fuzz", "Fuzz a parser"),
    ("query", "Search files using a syntax tree query"),
    ("highlight", "Highlight a file"),
    ("tags", "Generate a list of tags"),
    ("playground", "Start local playground for a parser in the browser"),
    ("dump-languages", "Print info about all known language parsers"),
    ("complete", "Generate shell completions"),
]

HELP = {
    "main": """tree-sitter 0.27.0
Max Brunsfeld <maxbrunsfeld@gmail.com>
Amaan Qureshi <amaanq12@gmail.com>
Generates and tests parsers

Usage: executable <COMMAND>

Commands:
  init-config     Generate a default config file
  init            Initialize a grammar repository
  generate        Generate a parser
  build           Compile a parser
  parse           Parse files
  test            Run a parser's tests
  version         Display or increment the version of a grammar
  fuzz            Fuzz a parser
  query           Search files using a syntax tree query
  highlight       Highlight a file
  tags            Generate a list of tags
  playground      Start local playground for a parser in the browser
  dump-languages  Print info about all known language parsers
  complete        Generate shell completions

Options:
  -h, --help     Print help
  -V, --version  Print version""",
    "init-config": """Generate a default config file

Usage: executable init-config

Options:
  -h, --help  Print help""",
    "init": """Initialize a grammar repository

Usage: executable init [OPTIONS]

Options:
  -u, --update                       Update outdated files
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory
  -h, --help                         Print help""",
    "generate": """Generate a parser

Usage: executable generate [OPTIONS] [GRAMMAR_PATH]

Arguments:
  [GRAMMAR_PATH]  The path to the grammar file

Options:
  -l, --log
          Show debug log during generation
      --abi <VERSION>
          Select the language ABI version to generate (default 15).
          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]
      --no-parser
          Only generate `grammar.json` and `node-types.json`
  -b, --build
          Deprecated: use the `build` command
  -0, --debug-build
          Deprecated: use the `build` command
      --libdir <PATH>
          Deprecated: use the `build` command
  -o, --output <DIRECTORY>
          The path to output the generated source files
      --report-states-for-rule <REPORT_STATES_FOR_RULE>
          Produce a report of the states for the given rule, use `-` to report every rule
      --json
          Deprecated: use --json-summary
      --json-summary
          Report conflicts in a JSON format
      --js-runtime <EXECUTABLE>
          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]
      --disable-optimizations
          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states
  -h, --help
          Print help""",
    "build": """Compile a parser

Usage: executable build [OPTIONS] [PATH]

Arguments:
  [PATH]  The path to the grammar directory

Options:
  -w, --wasm             Build a Wasm module instead of a dynamic library
  -o, --output <OUTPUT>  The path to output the compiled file
      --reuse-allocator  Make the parser reuse the same allocator as the library
  -0, --debug            Compile a parser in debug mode
  -v, --verbose          Display verbose build information
  -h, --help             Print help""",
    "parse": """Parse files

Usage: executable parse [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --dot                          Output the parse data with graphviz dot
  -x, --xml                          Output the parse data in XML format
  -c, --cst                          Output the parse data in a pretty-printed CST format
  -s, --stat                         Show parsing statistic
      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --edits <EDITS>...             Apply edits in the format: \\"row,col|position delcount insert_text\\", can be supplied multiple times
      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --json                         Deprecated: use --json-summary
  -j, --json-summary                 Output parsing results in a JSON format
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
      --no-ranges                    Omit ranges in the output
  -h, --help                         Print help""",
    "complete": """Generate shell completions

Usage: executable complete --shell <SHELL>

Options:
  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]
  -h, --help           Print help""",
}

HELP["test"] = """Run a parser's tests

Usage: executable test [OPTIONS]

Options:
  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex
      --file-name <FILE_NAME>        Only run corpus test cases from a given filename
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
  -u, --update                       Update all syntax trees in corpus files with current parser output
  -d, --debug                        Show parsing debug log
  -0, --debug-build                  Compile a parser in debug mode
  -D, --debug-graph                  Produce the log.html file with debug graphs
      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
      --show-fields                  Force showing fields in test diffs
      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]
  -r, --rebuild                      Force rebuild the parser
      --overview-only                Show only the pass-fail overview tree
      --json-summary                 Output the test summary in a JSON format
  -h, --help                         Print help"""

HELP["version"] = """Display or increment the version of a grammar

Usage: executable version [OPTIONS] [VERSION]

Arguments:
  [VERSION]
          The version to bump to
          
          Examples:
              tree-sitter version: display the current version
              tree-sitter version <version>: bump to specified version
              tree-sitter version --bump <level>: automatic bump

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory

      --bump <BUMP>
          Automatically bump from the current version
          
          [possible values: patch, minor, major]

  -h, --help
          Print help (see a summary with '-h')"""

HELP["fuzz"] = """Fuzz a parser

Usage: executable fuzz [OPTIONS]

Options:
  -s, --skip <SKIP>                  List of test names to skip
      --subdir <SUBDIR>              Subdirectory to the language
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --lib-path <LIB_PATH>          The path to the parser's dynamic library
      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function
      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)
      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)
  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex
  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex
      --log-graphs                   Enable logging of graphs and input
  -l, --log                          Enable parser logging
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help"""

HELP["query"] = """Search files using a syntax tree query

Usage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...

Arguments:
  <QUERY_PATH>  Path to a file with queries
  [PATHS]...    The source file(s) to use

Options:
  -p, --grammar-path <GRAMMAR_PATH>
          The path to the tree-sitter grammar directory, implies --rebuild
  -l, --lib-path <LIB_PATH>
          The path to the parser's dynamic library
      --lang-name <LANG_NAME>
          If `--lib-path` is used, the name of the language used to extract the library's language function
  -t, --time
          Measure execution time
  -q, --quiet
          Suppress main output
      --paths <PATHS_FILE>
          The path to a file with paths to source file(s)
      --byte-range <BYTE_RANGE>
          The range of byte offsets in which the query will be executed
      --row-range <ROW_RANGE>
          The range of rows in which the query will be executed
      --containing-byte-range <CONTAINING_BYTE_RANGE>
          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned
      --containing-row-range <CONTAINING_ROW_RANGE>
          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned
      --scope <SCOPE>
          Select a language by the scope instead of a file extension
  -c, --captures
          Order by captures instead of matches
      --test
          Whether to run query tests or not
      --config-path <CONFIG_PATH>
          The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>
          Query the contents of a specific test
  -r, --rebuild
          Force rebuild the parser
  -h, --help
          Print help"""

HELP["highlight"] = """Highlight a file

Usage: executable highlight [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
  -H, --html                           Generate highlighting as an HTML document
      --css-classes                    When generating HTML, use css classes rather than inline styles
      --check                          Check that highlighting captures conform strictly to standards
      --captures-path <CAPTURES_PATH>  The path to a file with captures
      --query-paths <QUERY_PATHS>...   The paths to files with queries
      --scope <SCOPE>                  Select a language by the scope instead of a file extension
  -t, --time                           Measure execution time
  -q, --quiet                          Suppress main output
      --paths <PATHS_FILE>             The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>      The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test
  -r, --rebuild                        Force rebuild the parser
      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]
  -h, --help                           Print help"""

HELP["tags"] = """Generate a list of tags

Usage: executable tags [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  The source file(s) to use

Options:
      --scope <SCOPE>                Select a language by the scope instead of a file extension
  -t, --time                         Measure execution time
  -q, --quiet                        Suppress main output
      --paths <PATHS_FILE>           The path to a file with paths to source file(s)
  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild
      --config-path <CONFIG_PATH>    The path to an alternative config.json file
  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test
  -r, --rebuild                      Force rebuild the parser
  -h, --help                         Print help"""

HELP["playground"] = """Start local playground for a parser in the browser

Usage: executable playground [OPTIONS]

Options:
  -q, --quiet                        Don't open in default browser
      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files
  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them
  -h, --help                         Print help"""

HELP["dump-languages"] = """Print info about all known language parsers

Usage: executable dump-languages [OPTIONS]

Options:
      --config-path <CONFIG_PATH>  The path to an alternative config.json file
  -h, --help                       Print help"""


def eprint(msg=""):
    print(msg, file=sys.stderr)


def die(msg, code=1, clap=False):
    if clap:
        eprint(msg)
    else:
        eprint(f"{RED}Error:{RESET} {msg}")
    return code


def home_config():
    return Path.home() / ".config" / "tree-sitter" / "config.json"


def default_config():
    return {
        "parser-directories": [
            str(Path.home() / "github"),
            str(Path.home() / "src"),
            str(Path.home() / "source"),
            str(Path.home() / "projects"),
            str(Path.home() / "dev"),
            str(Path.home() / "git"),
        ],
        "theme": {
            "attribute": {"color": 124, "italic": True},
            "comment": {"color": 245, "italic": True},
            "constant": 94,
            "constant.builtin": {"bold": True, "color": 94},
            "constructor": 136,
            "embedded": None,
            "function": 26,
            "function.builtin": {"bold": True, "color": 26},
            "keyword": 56,
            "module": 136,
            "number": {"bold": True, "color": 94},
            "operator": {"bold": True, "color": 239},
            "property": 124,
            "property.builtin": {"bold": True, "color": 124},
            "punctuation": 239,
            "punctuation.bracket": 239,
            "punctuation.delimiter": 239,
            "punctuation.special": 239,
            "string": 28,
            "string.special": 30,
            "tag": 18,
            "type": 23,
            "type.builtin": {"bold": True, "color": 23},
            "variable": 252,
            "variable.builtin": {"bold": True, "color": 252},
            "variable.parameter": {"color": 252, "underline": True},
        },
    }


def load_config(path=None):
    p = Path(path) if path else home_config()
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            return default_config()
    return default_config()


def find_project_file(root, name):
    p = Path(root) / name
    if p.exists():
        return p
    return None


def read_ts_json(root):
    p = find_project_file(root, "tree-sitter.json")
    if not p:
        raise FileNotFoundError("No such file or directory (os error 2)")
    return p, json.loads(p.read_text())


def extract_version(data):
    meta = data.get("metadata") if isinstance(data, dict) else None
    if isinstance(meta, dict) and isinstance(meta.get("version"), str):
        return meta["version"]
    if isinstance(data.get("version"), str):
        return data["version"]
    return "0.0.0"


def set_version(data, version):
    if isinstance(data.get("metadata"), dict):
        data["metadata"]["version"] = version
    else:
        data["version"] = version


def bump_version(ver, level):
    nums = [int(x) for x in re.findall(r"\d+", ver)[:3]]
    while len(nums) < 3:
        nums.append(0)
    if level == "major":
        nums = [nums[0] + 1, 0, 0]
    elif level == "minor":
        nums = [nums[0], nums[1] + 1, 0]
    elif level == "patch":
        nums = [nums[0], nums[1], nums[2] + 1]
    return "{}.{}.{}".format(*nums)


def command_help(cmd):
    text = HELP.get(cmd)
    if text:
        print(text)
        return 0
    return 2


def init_config(args):
    if args and args[0] in ("-h", "--help"):
        return command_help("init-config")
    if args:
        return die(f"error: unexpected argument '{args[0]}' found\n\nUsage: executable init-config\n\nFor more information, try '--help'.", 2, True)
    p = home_config()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(default_config(), indent=2) + "\n")
    eprint(f"Saved initial configuration to {p}")
    return 0


def init_repo(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("init")
    if not sys.stdin.isatty():
        return die("IO error: not a terminal")
    root = Path(".")
    (root / "grammar.js").write_text("module.exports = grammar({\n  name: 'example',\n  rules: { source_file: $ => repeat($.word), word: $ => /[a-zA-Z_]+/ }\n});\n")
    (root / "tree-sitter.json").write_text(json.dumps({"grammars": [{"name": "example", "scope": "source.example", "path": "."}], "metadata": {"version": "0.0.1"}}, indent=2) + "\n")
    (root / "src").mkdir(exist_ok=True)
    return 0


def generate(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("generate")
    out = Path("src")
    grammar = Path("grammar.js")
    i = 0
    no_parser = False
    while i < len(args):
        a = args[i]
        if a in ("-o", "--output") and i + 1 < len(args):
            out = Path(args[i + 1])
            i += 2
            continue
        if a == "--no-parser":
            no_parser = True
        elif not a.startswith("-"):
            grammar = Path(a)
        i += 1
    if not grammar.exists():
        return die(f"Error when generating parser\n\nCaused by:\n    Failed to load grammar.js -- No such file or directory (os error 2) ({Path.cwd() / grammar})")
    out.mkdir(parents=True, exist_ok=True)
    grammar_json = {"name": "unknown", "rules": {}}
    m = re.search(r"name\s*:\s*['\"]([^'\"]+)", grammar.read_text(errors="ignore"))
    if m:
        grammar_json["name"] = m.group(1)
    (out / "grammar.json").write_text(json.dumps(grammar_json, indent=2) + "\n")
    (out / "node-types.json").write_text("[]\n")
    if not no_parser:
        (out / "parser.c").write_text("#include <stddef.h>\nvoid *tree_sitter_unknown(void) { return NULL; }\n")
    return 0


def build(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("build")
    path = Path(".")
    output = None
    i = 0
    while i < len(args):
        if args[i] in ("-o", "--output") and i + 1 < len(args):
            output = Path(args[i + 1])
            i += 2
            continue
        if not args[i].startswith("-"):
            path = Path(args[i])
        i += 1
    if not (path / "src" / "grammar.json").exists():
        return die(f"Failed to compile parser\n\nCaused by:\n    No such file or directory (os error 2) ({path.resolve()}/src/grammar.json)")
    out = output or (path / ("parser.wasm" if "-w" in args or "--wasm" in args else "parser.so"))
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(b"")
    return 0


def collect_paths(args):
    paths = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--paths" and i + 1 < len(args):
            try:
                paths += [line.strip() for line in Path(args[i + 1]).read_text().splitlines() if line.strip()]
            except OSError:
                pass
            i += 2
            continue
        if a in ("-p", "--grammar-path", "-l", "--lib-path", "--lang-name", "--scope", "--timeout", "--encoding", "--config-path", "-n", "--test-number", "--byte-range", "--row-range", "--containing-byte-range", "--containing-row-range", "--captures-path"):
            i += 2
            continue
        if a in ("--query-paths", "--edits"):
            i += 1
            while i < len(args) and not args[i].startswith("-"):
                i += 1
            continue
        if not a.startswith("-"):
            paths.append(a)
        i += 1
    return paths


def parse_cmd(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("parse")
    quiet = "-q" in args or "--quiet" in args
    json_summary = "-j" in args or "--json-summary" in args or "--json" in args
    paths = collect_paths(args)
    if not paths:
        if json_summary:
            print("[]")
        else:
            print()
        return die("No language found")
    first = paths[0]
    if "--lib-path" not in args and "-l" not in args and "--scope" not in args:
        return die(f"Failed to load language for path \"{first}\"\n\nCaused by:\n    No language found")
    if json_summary:
        print(json.dumps([{"path": p, "successful": True} for p in paths]))
    elif not quiet:
        for p in paths:
            print(f"(source_file [0, 0] - [0, 0]) {p}")
    return 0


def highlight_cmd(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("highlight")
    paths = collect_paths(args)
    html = "-H" in args or "--html" in args
    quiet = "-q" in args or "--quiet" in args
    if not paths:
        return 0
    if "--scope" not in args and "-p" not in args and "--grammar-path" not in args:
        cfg = load_config()
        dirs = cfg.get("parser-directories", default_config()["parser-directories"])
        p = paths[0]
        eprint(f"{YELLOW}Warning:{RESET} No language found for path `{p}`\n")
        eprint(f"If a language should be associated with this file extension, please ensure the path to `{p}` is inside one of the following directories as specified by your 'config.json':\n")
        for n, d in enumerate(dirs, 1):
            eprint(f"  {n}. {d}  ")
        eprint(f"\nIf the directory that contains the relevant grammar for `{p}` is not listed above, please add the directory to the list of directories in your config file, located at {home_config()}\n")
        return 0
    if quiet:
        return 0
    for p in paths:
        text = Path(p).read_text(errors="ignore") if Path(p).exists() else ""
        if html:
            print("<!doctype html><html><body><pre>")
            print(text.replace("&", "&amp;").replace("<", "&lt;"), end="")
            print("</pre></body></html>")
        else:
            print(text, end="")
    return 0


def query_cmd(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("query")
    paths = collect_paths(args)
    if not paths:
        return die("the following required arguments were not provided:\n  <QUERY_PATH>\n\nUsage: executable query <QUERY_PATH> [PATHS]...\n\nFor more information, try '--help'.", 2, True)
    if len(paths) == 1:
        return 0
    return parse_cmd(["--scope", "dummy"] + paths[1:])


def tags_cmd(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("tags")
    return 0


def test_cmd(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("test")
    if "--json-summary" in args:
        print('{"total":0,"passed":0,"failed":0}')
    return 0


def fuzz_cmd(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("fuzz")
    return die("No corpus directory found")


def version_cmd(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("version")
    root = Path(".")
    i = 0
    bump = None
    explicit = None
    while i < len(args):
        if args[i] in ("-p", "--grammar-path") and i + 1 < len(args):
            root = Path(args[i + 1])
            i += 2
            continue
        if args[i] == "--bump" and i + 1 < len(args):
            bump = args[i + 1]
            i += 2
            continue
        if not args[i].startswith("-"):
            explicit = args[i]
        i += 1
    try:
        p, data = read_ts_json(root)
    except Exception as ex:
        return die(str(ex))
    cur = extract_version(data)
    if not bump and not explicit:
        eprint(f"Current version: {cur}")
        return 0
    new = explicit or bump_version(cur, bump)
    eprint(f"Bumping version {cur} to {new}")
    set_version(data, new)
    p.write_text(json.dumps(data, separators=(",", ":")) + "\n")
    makefile = root / "Makefile"
    if not makefile.exists():
        return die(f"Failed to update one or more files:\n\nFailed to update {makefile.resolve()}:\nNo such file or directory (os error 2)")
    txt = makefile.read_text()
    txt = re.sub(r"VERSION\\s*[:?]?=\\s*[^\\n]+", f"VERSION = {new}", txt)
    makefile.write_text(txt)
    return 0


def dump_languages(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("dump-languages")
    cfg_path = None
    if "--config-path" in args:
        i = args.index("--config-path")
        if i + 1 < len(args):
            cfg_path = args[i + 1]
    cfg = load_config(cfg_path)
    dirs = cfg.get("parser-directories", [])
    for d in dirs:
        base = Path(d)
        if not base.exists():
            continue
        for tsj in base.glob("*/tree-sitter.json"):
            try:
                data = json.loads(tsj.read_text())
            except Exception:
                continue
            print(json.dumps(data, separators=(",", ":")))
    return 0


def complete(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("complete")
    shell = None
    for i, a in enumerate(args):
        if a in ("-s", "--shell") and i + 1 < len(args):
            shell = args[i + 1]
        elif a.startswith("--shell="):
            shell = a.split("=", 1)[1]
    values = ["bash", "elvish", "fish", "power-shell", "zsh", "nushell"]
    if not shell:
        return die("error: the following required arguments were not provided:\n  --shell <SHELL>\n\nUsage: executable complete --shell <SHELL>\n\nFor more information, try '--help'.", 2, True)
    if shell not in values:
        tip = "\n\n  tip: a similar value exists: 'bash'" if shell and shell[0:1] == "b" else ""
        return die(f"error: invalid value '{shell}' for '--shell <SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]{tip}\n\nFor more information, try '--help'.", 2, True)
    if shell == "fish":
        print("function __fish_tree_sitter_global_optspecs")
        print("\tstring join \\n h/help V/version")
        print("end\n")
        for c, desc in COMMANDS:
            print(f"complete -c tree-sitter -f -a \"{c}\" -d '{desc}'")
    elif shell == "bash":
        print("_tree-sitter() {")
        print("    local i cur prev opts cmd")
        print("    COMPREPLY=()")
        print("    opts=\"init-config init generate build parse test version fuzz query highlight tags playground dump-languages complete -h --help -V --version\"")
        print("    COMPREPLY=( $(compgen -W \"${opts}\" -- \"${COMP_WORDS[COMP_CWORD]}\") )")
        print("}\ncomplete -F _tree-sitter -o bashdefault -o default tree-sitter")
    else:
        print(f"# {shell} completions for tree-sitter")
        for c, _ in COMMANDS:
            print(c)
    return 0


def playground(args):
    if any(a in ("-h", "--help") for a in args):
        return command_help("playground")
    if "-e" in args or "--export" in args:
        flag = "-e" if "-e" in args else "--export"
        i = args.index(flag)
        if i + 1 < len(args):
            out = Path(args[i + 1])
            out.mkdir(parents=True, exist_ok=True)
            (out / "index.html").write_text("<!doctype html><title>Tree-sitter Playground</title>\n")
            return 0
    return die("Failed to start playground")


def main(argv):
    if not argv:
        print(HELP["main"], file=sys.stderr)
        return 2
    if argv[0] in ("-h", "--help"):
        print(HELP["main"])
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    cmd, args = argv[0], argv[1:]
    handlers = {
        "init-config": init_config,
        "init": init_repo,
        "generate": generate,
        "build": build,
        "parse": parse_cmd,
        "test": test_cmd,
        "version": version_cmd,
        "fuzz": fuzz_cmd,
        "query": query_cmd,
        "highlight": highlight_cmd,
        "tags": tags_cmd,
        "playground": playground,
        "dump-languages": dump_languages,
        "complete": complete,
    }
    if cmd not in handlers:
        eprint(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.")
        return 2
    return handlers[cmd](args)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
