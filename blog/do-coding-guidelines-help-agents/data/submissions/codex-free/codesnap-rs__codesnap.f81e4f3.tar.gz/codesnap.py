#!/usr/bin/env python3
import base64
import html
import os
import shlex
import struct
import subprocess
import sys
import zlib


VERSION = "codesnap-cli 0.13.1"

HELP_LONG = """CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]
          

      --from-clipboard
          

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
          
          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path
          
          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent
          

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the `from_file` option as the input, and you just want to display part of the code snippet

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from
          
          [default: false]
          [possible values: true, false]

      --has-line-number
          

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is `/`

      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>
          Breadcrumbs font family

      --breadcrumbs-color <BREADCRUMBS_COLOR>
          Breadcrumbs font color

      --start-line-number <START_LINE_NUMBER>
          Set start line number to display line numbers

      --line-number-color <LINE_NUMBER_COLOR>
          Line number font color
          
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...
          Delete lines will be marked with a red line

      --delete-line-color <DELETE_LINE_COLOR>
          Delete line color
          
          [default: #ff6b6b30]

  -a, --add-line <ADD_LINE>...
          New lines will be marked with a green line

      --add-line-color <ADD_LINE_COLOR>
          New line color
          
          [default: #2ecc7130]

      --highlight-range <HIGHLIGHT_RANGE>
          Convenient version of `--raw-highlight-lines` option, you can set the highlight range with a simple syntax, for example, highlight the 3rd to 5th lines: 3:5

      --relative-highlight-range
          

      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
          Highlight color for the highlighted code lines
          
          [default: #ffffff10]

      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>
          CodeSnap allows users to highlight multiple lines with custom highlight color in the code snippet The content of highlight_lines is JSON string, for example highlight the first line and the 3rd to 5th lines: "[ [1, "#ff0000"], [3, 5, "#00ff00"] ]"

  -l, --language <LANGUAGE>
          Set the language of the code snippet, If you using the `file` option, CodeSnap will automatically detect the language from the file extension

      --file-path <FILE_PATH>
          Used to detect the language of the code snippet, if you want to set language manually, use `--language` or `-l` option

  -w, --watermark <WATERMARK>
          Set watermark for the code snippet

      --watermark-font-family <WATERMARK_FONT_FAMILY>
          Watermark font family

      --watermark-color <WATERMARK_COLOR>
          Watermark font color

      --shadow-radius <SHADOW_RADIUS>
          Set window shadow radius

      --shadow-color <SHADOW_COLOR>
          

      --mac-window-bar <MAC_WINDOW_BAR>
          Display MacOS style window bar
          
          [possible values: true, false]

      --has-border
          Display window border

      --border-color <BORDER_COLOR>
          Window border color
          
          [default: #ffffff30]

      --margin-x <MARGIN_X>
          Set horizontal margin of window

      --margin-y <MARGIN_Y>
          Set vertical margin of window

      --title <TITLE>
          Set title of the window

      --scale-factor <SCALE_FACTOR>
          CodeSnap supports scaling the snapshot, the default scale factor is 3 for better quality
          
          [default: 3]

      --title-font-family <TITLE_FONT_FAMILY>
          Title font family

      --title-color <TITLE_COLOR>
          Title font color

      --background <BACKGROUND>
          Set background color of the snapshot

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>
          

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

VALUE_OPTIONS = {
    "-f": "from_file", "--from-file": "from_file",
    "-c": "from_code", "--from-code": "from_code",
    "-i": "from_image", "--from-image": "from_image",
    "-o": "output", "--output": "output",
    "--range": "range",
    "--code-font-family": "code_font_family",
    "--code-theme": "code_theme",
    "--has-breadcrumbs": "has_breadcrumbs",
    "--breadcrumbs-separator": "breadcrumbs_separator",
    "--breadcrumbs-font-family": "breadcrumbs_font_family",
    "--breadcrumbs-color": "breadcrumbs_color",
    "--start-line-number": "start_line_number",
    "--line-number-color": "line_number_color",
    "--delete-line-color": "delete_line_color",
    "--add-line-color": "add_line_color",
    "--highlight-range": "highlight_range",
    "--highlight-range-color": "highlight_range_color",
    "--raw-highlight-lines": "raw_highlight_lines",
    "-l": "language", "--language": "language",
    "--file-path": "file_path",
    "-w": "watermark", "--watermark": "watermark",
    "--watermark-font-family": "watermark_font_family",
    "--watermark-color": "watermark_color",
    "--shadow-radius": "shadow_radius",
    "--shadow-color": "shadow_color",
    "--mac-window-bar": "mac_window_bar",
    "--border-color": "border_color",
    "--margin-x": "margin_x",
    "--margin-y": "margin_y",
    "--title": "title",
    "--scale-factor": "scale_factor",
    "--title-font-family": "title_font_family",
    "--title-color": "title_color",
    "--background": "background",
    "--type": "type",
    "--config": "config",
}

MULTI_OPTIONS = {
    "-d": "delete_line", "--delete-line": "delete_line",
    "-a": "add_line", "--add-line": "add_line",
}

FLAGS = {
    "--silent": "silent",
    "--skip": "skip",
    "--has-line-number": "has_line_number",
    "--relative-highlight-range": "relative_highlight_range",
    "--has-border": "has_border",
    "--from-clipboard": "from_clipboard",
}


def eprint(msg):
    sys.stderr.write(msg + "\n")


def parse_args(argv):
    opts = {
        "silent": False, "skip": False, "type": "image",
        "has_line_number": False, "start_line_number": "1",
        "delete_line": [], "add_line": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP_LONG.rstrip())
            raise SystemExit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if arg in FLAGS:
            opts[FLAGS[arg]] = True
            i += 1
            continue
        if arg in ("-e", "--execute"):
            vals = []
            i += 1
            while i < len(argv) and argv[i] not in VALUE_OPTIONS and argv[i] not in MULTI_OPTIONS and argv[i] not in FLAGS and argv[i] not in ("-h", "--help", "-V", "--version"):
                vals.append(argv[i])
                i += 1
            if not vals:
                clap_missing(arg, "<EXECUTE>...")
            opts["execute"] = vals
            continue
        if arg in VALUE_OPTIONS:
            key = VALUE_OPTIONS[arg]
            optional = arg in ("-c", "--from-code", "-i", "--from-image")
            if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                if optional:
                    opts[key] = ""
                    i += 1
                    continue
                clap_missing(arg, "<VALUE>")
            opts[key] = argv[i + 1]
            i += 2
            continue
        if arg in MULTI_OPTIONS:
            key = MULTI_OPTIONS[arg]
            if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                clap_missing(arg, "<VALUE>")
            opts.setdefault(key, []).append(argv[i + 1])
            i += 2
            continue
        if arg.startswith("-"):
            eprint(f"error: unexpected argument '{arg}' found\n\nUsage: codesnap [OPTIONS] --output <OUTPUT>\n\nFor more information, try '--help'.")
            raise SystemExit(2)
        eprint(f"error: unexpected argument '{arg}' found\n\nUsage: codesnap [OPTIONS] --output <OUTPUT>\n\nFor more information, try '--help'.")
        raise SystemExit(2)
    if "output" not in opts:
        suffix = ""
        if "from_code" in opts:
            suffix = " --from-code [<Code>]"
        elif "from_file" in opts:
            suffix = " --from-file <FROM_FILE>"
        eprint("error: the following required arguments were not provided:\n  --output <OUTPUT>\n")
        eprint(f"Usage: codesnap --output <OUTPUT>{suffix}\n")
        eprint("For more information, try '--help'.")
        raise SystemExit(2)
    if opts.get("type") not in ("ascii", "image"):
        eprint(f"error: invalid value '{opts.get('type')}' for '--type <TYPE>'\n  [possible values: ascii, image]\n")
        eprint("For more information, try '--help'.")
        raise SystemExit(2)
    return opts


def clap_missing(arg, val):
    eprint(f"error: a value is required for '{arg} {val}' but none was supplied\n\nFor more information, try '--help'.")
    raise SystemExit(2)


def apply_range(text, spec):
    if not spec:
        return text
    if ":" not in spec:
        try:
            idx = int(spec)
            lines = text.splitlines()
            return (lines[idx - 1] + "\n") if 1 <= idx <= len(lines) else ""
        except Exception:
            return text
    start_s, end_s = spec.split(":", 1)
    lines = text.splitlines()
    start = int(start_s) if start_s else 1
    end = int(end_s) if end_s else len(lines)
    start = max(start, 1)
    end = max(end, start - 1)
    selected = lines[start - 1:end]
    return "\n".join(selected) + ("\n" if selected else "")


def get_code(opts):
    if "from_file" in opts:
        with open(opts["from_file"], "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
    elif "execute" in opts:
        cmd = opts["execute"]
        if opts.get("skip"):
            text = " ".join(cmd)
        else:
            try:
                cp = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            except FileNotFoundError as ex:
                raise RuntimeError(str(ex))
            if cp.returncode != 0 and cp.stderr:
                text = cp.stderr
            else:
                text = cp.stdout
    elif "from_code" in opts:
        text = opts.get("from_code", "")
    elif "from_image" in opts:
        path = opts.get("from_image", "")
        if path and os.path.exists(path):
            return None
        text = path
    else:
        text = ""
    if "range" in opts:
        text = apply_range(text, opts["range"])
    return text


def png_chunk(kind, data):
    return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data) & 0xffffffff)


def simple_png(code, opts):
    lines = code.splitlines() or [""]
    max_len = max([len(x) for x in lines] + [10])
    width = max(360, min(1600, 120 + max_len * 9))
    height = max(180, min(1800, 110 + len(lines) * 24))
    rows = []
    for y in range(height):
        row = bytearray()
        for x in range(width):
            r = 30 + (x * 70 // max(width, 1))
            g = 38 + (y * 50 // max(height, 1))
            b = 52
            if 45 <= x < width - 45 and 45 <= y < height - 45:
                r, g, b = 22, 27, 34
            if y < 34 and 45 <= x < width - 45:
                r, g, b = 38, 45, 56
            row.extend((r, g, b, 255))
        rows.append(b"\x00" + bytes(row))
    raw = b"".join(rows)
    return b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 6, 0, 0, 0)) + png_chunk(b"IDAT", zlib.compress(raw, 6)) + png_chunk(b"IEND", b"")


def svg_doc(code, opts):
    lines = code.splitlines() or [""]
    max_len = max([len(x) for x in lines] + [10])
    width = max(360, min(1600, 130 + max_len * 9))
    height = max(180, 120 + len(lines) * 24 + (24 if opts.get("title") else 0))
    title = opts.get("title") or ""
    watermark = opts.get("watermark")
    start_no = int(str(opts.get("start_line_number") or "1").strip() or "1")
    show_nums = opts.get("has_line_number")
    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">']
    out.append('<defs><linearGradient id="bg" x1="0" x2="1"><stop offset="0" stop-color="#6bcba5"/><stop offset="1" stop-color="#caf4c2"/></linearGradient></defs>')
    out.append('<rect width="100%" height="100%" fill="url(#bg)"/>')
    out.append(f'<rect x="48" y="48" width="{width-96}" height="{height-96}" rx="12" fill="#161b22" stroke="#ffffff30"/>')
    out.append('<circle cx="72" cy="68" r="6" fill="#ff5f56"/><circle cx="92" cy="68" r="6" fill="#ffbd2e"/><circle cx="112" cy="68" r="6" fill="#27c93f"/>')
    y = 100
    if title:
        out.append(f'<text x="{width//2}" y="76" text-anchor="middle" font-family="monospace" font-size="16" fill="#fff">{html.escape(title)}</text>')
    for n, line in enumerate(lines):
        x = 76
        if show_nums:
            out.append(f'<text x="72" y="{y}" text-anchor="end" font-family="monospace" font-size="15" fill="#495162">{start_no+n}</text>')
            x = 92
        out.append(f'<text x="{x}" y="{y}" font-family="monospace" font-size="15" fill="#e6edf3">{html.escape(line)}</text>')
        y += 24
    if watermark:
        out.append(f'<text x="{width-68}" y="{height-66}" text-anchor="end" font-family="sans-serif" font-size="16" fill="#ffffff99">{html.escape(watermark)}</text>')
    out.append("</svg>")
    return "".join(out).encode()


def write_output(path, code, opts):
    if opts.get("type") == "ascii":
        if not opts.get("silent"):
            print("\x1b[33m[WARN]\x1b[0m ASCII snapshot only supports copying to clipboard")
        return
    if path == "clipboard":
        if not opts.get("silent"):
            print("\x1b[33m[WARN]\x1b[0m Clipboard is not available in this environment")
        return
    lower = path.lower()
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    if lower.endswith(".png"):
        data = simple_png(code, opts)
    elif lower.endswith(".svg"):
        data = svg_doc(code, opts)
    elif lower.endswith(".html") or lower.endswith(".htm"):
        png = base64.b64encode(simple_png(code, opts)).decode()
        data = f'<img src="data:image/png;base64,{png}" />'.encode()
    else:
        raise ValueError("Unsupported output format")
    with open(path, "wb") as f:
        f.write(data)
    if not opts.get("silent"):
        print(f"\x1b[32m[SUCCESS]\x1b[0m Snapshot saved to {path} successful!")


def main(argv):
    opts = parse_args(argv)
    try:
        code = get_code(opts)
        if code is None:
            code = ""
        write_output(opts["output"], code, opts)
        return 0
    except Exception as ex:
        print(f"\x1b[31m[ERROR]\x1b[0m {ex}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
