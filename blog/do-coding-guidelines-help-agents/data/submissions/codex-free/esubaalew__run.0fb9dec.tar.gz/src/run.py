#!/usr/bin/env python3
import os
import shutil
import subprocess
import sys
import tempfile


VERSION = """run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)"""

LANGS = [
    "bash", "c", "cpp", "crystal", "csharp", "dart", "elixir", "go",
    "groovy", "haskell", "java", "javascript", "julia", "kotlin", "lua",
    "nim", "perl", "php", "python", "r", "ruby", "rust", "swift",
    "typescript", "zig",
]

ALIASES = {
    "sh": "bash", "shell": "bash",
    "cc": "c",
    "c++": "cpp", "cxx": "cpp",
    "js": "javascript", "node": "javascript",
    "ts": "typescript",
    "py": "python", "python3": "python",
    "rb": "ruby",
    "rs": "rust",
    "golang": "go",
    "pl": "perl",
}

EXTS = {
    ".sh": "bash", ".bash": "bash",
    ".c": "c", ".h": "c",
    ".cc": "cpp", ".cpp": "cpp", ".cxx": "cpp", ".hpp": "cpp",
    ".go": "go",
    ".java": "java",
    ".js": "javascript", ".mjs": "javascript", ".cjs": "javascript",
    ".ts": "typescript",
    ".py": "python",
    ".rb": "ruby",
    ".rs": "rust",
    ".pl": "perl",
    ".php": "php",
    ".lua": "lua",
    ".r": "r", ".R": "r",
}


def help_text(prog):
    return f"""Universal multi-language runner and REPL

Usage: {prog} [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help"""


def fail(msg, code=1):
    print(msg, file=sys.stderr)
    return code


def clap_missing(flag, value):
    print(f"error: a value is required for '{flag} <{value}>' but none was supplied", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def clap_unexpected(arg, prog):
    print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
    print(file=sys.stderr)
    print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'", file=sys.stderr)
    print(file=sys.stderr)
    print(f"Usage: {prog} [OPTIONS] [ARGS]...", file=sys.stderr)
    print(file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def parse(argv):
    prog = os.path.basename(argv[0]) if argv else "executable"
    lang = None
    file_path = None
    code = None
    no_detect = False
    args = []
    i = 1
    passthrough = False
    while i < len(argv):
        a = argv[i]
        if passthrough:
            args.append(a)
        elif a == "--":
            passthrough = True
        elif a in ("-h", "--help"):
            print(help_text(prog))
            return None, 0
        elif a in ("-V", "--version"):
            print(VERSION)
            return None, 0
        elif a in ("-l", "--lang"):
            if i + 1 >= len(argv):
                return None, clap_missing("--lang", "LANG")
            i += 1
            lang = argv[i]
        elif a.startswith("--lang="):
            lang = a.split("=", 1)[1]
        elif a in ("-f", "--file"):
            if i + 1 >= len(argv):
                return None, clap_missing("--file", "PATH")
            i += 1
            file_path = argv[i]
        elif a.startswith("--file="):
            file_path = a.split("=", 1)[1]
        elif a in ("-c", "--code"):
            if i + 1 >= len(argv):
                return None, clap_missing("--code", "CODE")
            i += 1
            code = argv[i]
        elif a.startswith("--code="):
            code = a.split("=", 1)[1]
        elif a == "--no-detect":
            no_detect = True
        elif a.startswith("-"):
            return None, clap_unexpected(a, prog)
        else:
            args.append(a)
        i += 1
    return {"prog": prog, "lang": lang, "file": file_path, "code": code, "args": args, "no_detect": no_detect}, None


def normalize(lang):
    if not lang:
        return None
    l = lang.lower()
    return ALIASES.get(l, l)


def language_from_file(path):
    return EXTS.get(os.path.splitext(path)[1])


def detect_code(code, no_detect=False):
    if no_detect:
        return "python"
    s = code.lstrip()
    if s.startswith("console.") or "console.log" in s:
        return "javascript"
    if s.startswith("puts ") or s.startswith("p "):
        return "ruby"
    if s.startswith("echo ") or s.startswith("#!/bin/sh") or s.startswith("#!/usr/bin/env bash"):
        return "bash"
    if s.startswith("print(") or s.startswith("print "):
        return "lua"
    return "python"


def run_cmd(cmd, cwd=None):
    try:
        p = subprocess.run(cmd, cwd=cwd)
        return p.returncode
    except FileNotFoundError:
        return 127


def missing_tool(lang):
    messages = {
        "lua": "Error: Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH.",
        "php": "Error: PHP support requires the `php` CLI executable. Install PHP and ensure it is on your PATH.",
    }
    if lang in messages:
        return fail(messages[lang])
    return fail(f"Error: {lang} support requires an external executable that was not found.")


def ensure_tool(exe, lang):
    if shutil.which(exe):
        return True
    missing_tool(lang)
    return False


def run_interpreted(lang, code=None, file_path=None):
    if lang == "python":
        return run_cmd(["python3", file_path] if file_path else ["python3", "-c", code or ""])
    if lang == "javascript":
        return run_cmd(["node", file_path] if file_path else ["node", "-e", code or ""])
    if lang == "typescript":
        exe = shutil.which("ts-node") or shutil.which("ts-node-script")
        if not exe:
            return 127
        return run_cmd([exe, file_path] if file_path else [exe, "-e", code or ""])
    if lang == "bash":
        return run_cmd(["/usr/bin/bash", file_path] if file_path else ["/usr/bin/bash", "-c", code or ""])
    if lang == "ruby":
        return run_cmd(["ruby", file_path] if file_path else ["ruby", "-e", code or ""])
    if lang == "perl":
        return run_cmd(["perl", file_path] if file_path else ["perl", "-e", code or ""])
    if lang == "php":
        if not ensure_tool("php", "php"):
            return 1
        return run_cmd(["php", file_path] if file_path else ["php", "-r", code or ""])
    if lang == "lua":
        if not ensure_tool("lua", "lua"):
            return 1
        return run_cmd(["lua", file_path] if file_path else ["lua", "-e", code or ""])
    if lang == "r":
        exe = shutil.which("Rscript")
        if not exe:
            return missing_tool("r")
        return run_cmd([exe, file_path] if file_path else [exe, "-e", code or ""])
    return None


def read_file(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def c_source(code):
    if "main" in code:
        return code
    return "#include <stdio.h>\n#include <stdlib.h>\n#include <string.h>\nint main(){\n    " + code + "\n    return 0;\n}\n"


def cpp_source(code):
    if "main" in code or "#include" in code:
        return code
    return "#include <bits/stdc++.h>\nusing namespace std;\nint main(){\n    " + code + "\n    return 0;\n}\n"


def java_source(code):
    if "class " in code:
        return code
    return "public class Main {\n    public static void main(String[] args) throws Exception {\n        " + code + "\n    }\n}\n"


def compile_run(lang, code=None, file_path=None):
    with tempfile.TemporaryDirectory(prefix=f"run-{lang}") as td:
        if lang == "c":
            src = os.path.join(td, "main.c")
            open(src, "w", encoding="utf-8").write(read_file(file_path) if file_path else c_source(code or ""))
            out = os.path.join(td, "main")
            rc = run_cmd(["gcc", src, "-o", out])
            return rc if rc else run_cmd([out])
        if lang == "cpp":
            src = os.path.join(td, "main.cpp")
            open(src, "w", encoding="utf-8").write(read_file(file_path) if file_path else cpp_source(code or ""))
            out = os.path.join(td, "main")
            rc = run_cmd(["g++", src, "-o", out])
            return rc if rc else run_cmd([out])
        if lang == "java":
            src = os.path.join(td, "Main.java")
            open(src, "w", encoding="utf-8").write(read_file(file_path) if file_path else java_source(code or ""))
            rc = run_cmd(["javac", src], cwd=td)
            return rc if rc else run_cmd(["java", "-cp", td, "Main"])
        if lang == "go":
            src = os.path.join(td, "main.go")
            open(src, "w", encoding="utf-8").write(read_file(file_path) if file_path else (code or ""))
            return run_cmd(["go", "run", src])
        if lang == "rust":
            src = os.path.join(td, "main.rs")
            open(src, "w", encoding="utf-8").write(read_file(file_path) if file_path else (code or ""))
            out = os.path.join(td, "main")
            rc = run_cmd(["rustc", src, "-o", out])
            return rc if rc else run_cmd([out])
    return 1


def main(argv):
    opts, exit_code = parse(argv)
    if exit_code is not None:
        return exit_code

    lang = normalize(opts["lang"])
    file_path = opts["file"]
    code = opts["code"]
    args = opts["args"]

    if code is not None and args:
        if lang is None and len(args) == 1 and (normalize(args[0]) in LANGS or args[0].lower() in ALIASES):
            lang = normalize(args[0])
            args = []
        else:
            return fail("Error: Unexpected positional arguments after specifying --code")
    if file_path is not None and args:
        if lang is None and len(args) == 1 and (normalize(args[0]) in LANGS or args[0].lower() in ALIASES):
            lang = normalize(args[0])
            args = []
        else:
            return fail("Error: Unexpected positional arguments when --file is present")

    if lang is None and args:
        first = args[0]
        first_lang = normalize(first)
        if first_lang in LANGS or first.lower() in ALIASES:
            lang = first_lang
            code = " ".join(args[1:]) if len(args) > 1 else None
        elif len(args) == 1 and os.path.exists(first):
            file_path = first
            lang = None if opts["no_detect"] else language_from_file(first)
        else:
            code = " ".join(args)

    if file_path and lang is None:
        lang = "python" if opts["no_detect"] else (language_from_file(file_path) or "python")
    if code is not None and lang is None:
        lang = detect_code(code, opts["no_detect"])
    if lang is None:
        return 0

    lang = normalize(lang)
    if lang not in LANGS:
        return fail(f"Error: Unknown language '{opts['lang'] or lang}'. Available languages: {', '.join(LANGS)}")

    rc = run_interpreted(lang, code, file_path)
    if rc is not None:
        return rc
    if lang in ("c", "cpp", "java", "go", "rust"):
        return compile_run(lang, code, file_path)
    return missing_tool(lang)


if __name__ == "__main__":
    sys.exit(main(sys.argv))
