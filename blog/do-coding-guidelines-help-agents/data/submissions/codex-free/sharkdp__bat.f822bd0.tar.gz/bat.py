#!/usr/bin/env python3
import os
import sys
import re
import shlex

VERSION = "bat 0.26.1 (610b77c)"

THEMES = """1337
Catppuccin Frappe
Catppuccin Latte
Catppuccin Macchiato
Catppuccin Mocha
Coldark-Cold
Coldark-Dark
DarkNeon
Dracula
GitHub
Monokai Extended
Monokai Extended Bright
Monokai Extended Light
Monokai Extended Origin
Nord
OneHalfDark
OneHalfLight
Solarized (dark)
Solarized (light)
Sublime Snazzy
TwoDark
Visual Studio Dark+
ansi
base16
base16-256
gruvbox-dark
gruvbox-light
zenburn
"""

LANGUAGES = """ActionScript:as
Ada:adb,ads,gpr
Apache Conf:envvars,htaccess,HTACCESS,htgroups,HTGROUPS,htpasswd,HTPASSWD,.htaccess,.HTACCESS,.htgroups,.HTGROUPS,.htpasswd,.HTPASSWD,httpd.conf
AppleScript:applescript,script editor
ARM Assembly:s,S
AsciiDoc (Asciidoctor):adoc,ad,asciidoc
ASP:asa
Authorized Keys:authorized_keys,pub,authorized_keys2
AWK:awk
Batch File:bat,cmd
BibTeX:bib
Bourne Again Shell (bash):sh,bash,zsh,ash,.bashrc,.profile,PKGBUILD
C:c
C#:cs,csx
C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h
Cabal:cabal
CFML:cfml,cfm,cfc
Clojure:clj,cljc,cljs,edn
CMake:CMakeLists.txt,cmake
CoffeeScript:coffee,Cakefile,coffee.erb,cson
Command Help:cmd-help,help
Crontab:tab,crontab,cron.d
Crystal:cr
CSS:css,css.erb,css.liquid
D:d,di
Dart:dart
Diff:diff,patch,*.debdiff
Dockerfile:Dockerfile,dockerfile,.Dockerfile,Containerfile
DotENV:.env,.env.dist,.env.local,.env.sample,.env.example,.env.template
Elixir:ex,exs
Elm:elm
Erlang:erl,hrl,Emakefile,emakefile,escript
Fish:fish
Fortran (Fixed Form):f,F,f77,F77,for,FOR
Fortran (Modern):f90,F90,f95,F95,f03,F03,f08,F08
Git Attributes:attributes,gitattributes,.gitattributes
Git Commit:COMMIT_EDITMSG,MERGE_MSG,TAG_EDITMSG
Git Config:gitconfig,.gitconfig,.gitmodules
Git Ignore:exclude,gitignore,.gitignore,.gcloudignore
Git Log:gitlog
Go:go
Gomod:go.mod,go.work
Gosum:go.sum
GraphQL:graphql,graphqls,gql
Graphviz (DOT):dot,DOT,gv
Groff/troff:groff,troff,1,2,3,4,5,6,7,8,9
Groovy:groovy,gvy,gradle,Jenkinsfile
Haskell:hs
Hosts File:hosts
HTML:html,htm,shtml,xhtml
INI:ini,INI,inf,INF,reg,REG,cfg,CFG,.editorconfig
Java:java,bsh
JavaScript:js,jsx,mjs,cjs
JSON:json,sublime-settings,sublime-menu,sublime-keymap
Julia:jl
Kotlin:kt,kts
LaTeX:tex,ltx
Less:less
Lisp:lisp,lsp,cl,el
Lua:lua
Makefile:Makefile,makefile,GNUmakefile,mak,mk
Markdown:md,mdown,markdown,markdn
Nim:nim
Nix:nix
Objective-C:m,h
OCaml:ml,mli
Org Mode:org
Pascal:pas,p
Perl:pl,pm,pod,t
PHP:php,php3,php4,php5,php7,phps,phpt,phtml
Plain Text:txt
PowerShell:ps1,psm1,psd1
Protocol Buffer:proto
Python:py,py3,pyw,pyi,SConstruct,SConscript
R:r,R,Rprofile
Ruby:rb,rbx,rjs,Rakefile,Gemfile,gemspec
Rust:rs
Scala:scala,sbt
SQL:sql,ddl,dml
Swift:swift
TOML:toml,Cargo.lock
TypeScript:ts,tsx
XML:xml,xsd,xsl,xslt,svg
YAML:yaml,yml
"""

def read_help(long_help):
    name = "long-help.txt" if long_help else "short-help.txt"
    path = os.path.join(os.path.dirname(__file__), "doc", name)
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except OSError:
        return ("A cat(1) clone with wings.\n\n"
                "Usage: bat [OPTIONS] [FILE]...\n       bat <COMMAND>\n")

def eprint(s):
    sys.stderr.write(s)

def error(msg, status=1):
    eprint(f"\033[31m[bat error]\033[0m: {msg}\n")
    return status

def parse_value(argv, i, arg):
    if "=" in arg:
        return arg.split("=", 1)[1], i
    if i + 1 >= len(argv):
        raise ValueError(f"a value is required for '{arg}' but none was supplied")
    return argv[i + 1], i + 1

def expand_short(arg):
    # Accept common clustered forms like -pp and -pljson.
    if arg == "-" or not arg.startswith("-") or arg.startswith("--") or len(arg) <= 2:
        return [arg]
    if len(arg) > 1 and arg[1].isdigit():
        return [arg]
    out = []
    j = 1
    valopts = set("lHr")
    while j < len(arg):
        ch = arg[j]
        if ch in valopts:
            out.append("-" + ch)
            if j + 1 < len(arg):
                out.append(arg[j+1:])
            return out
        out.append("-" + ch)
        j += 1
    return out

def parse_args(argv):
    expanded = []
    for a in argv:
        expanded.extend(expand_short(a))
    opts = {
        "files": [], "number": False, "plain_count": 0, "show_all": False,
        "notation": "unicode", "tabs": int(os.environ.get("BAT_TABS", "4") or "4"),
        "squeeze": False, "squeeze_limit": None, "ranges": [], "quiet_empty": False,
        "decorations": "auto", "color": "auto", "style": None, "binary": "no-printing",
        "strip_ansi": "never", "unbuffered": False, "file_name": None,
        "terminal_width": None, "wrap": "auto",
    }
    i = 0
    while i < len(expanded):
        a = expanded[i]
        key = a.split("=", 1)[0] if a.startswith("--") else a
        if a == "--":
            opts["files"].extend(expanded[i+1:])
            break
        if not a.startswith("-") or a == "-":
            opts["files"].append(a); i += 1; continue
        try:
            if key in ("-h", "--help"):
                print(read_help(key == "--help"), end=""); sys.exit(0)
            if key in ("-V", "--version"):
                print(VERSION); sys.exit(0)
            if key in ("-L", "--list-languages"):
                print(LANGUAGES, end=""); sys.exit(0)
            if key == "--list-themes":
                print(THEMES, end=""); sys.exit(0)
            if key == "--config-file":
                print(os.path.expanduser("~/.config/bat/config")); sys.exit(0)
            if key == "--config-dir":
                print(os.path.expanduser("~/.config/bat")); sys.exit(0)
            if key == "--cache-dir":
                print(os.path.expanduser("~/.cache/bat")); sys.exit(0)
            if key == "--diagnostic":
                print_diagnostic(); sys.exit(0)
            if key == "--acknowledgements":
                print_acknowledgements(); sys.exit(0)
            if key == "--completion":
                val, i = parse_value(expanded, i, a); print_completion(val); sys.exit(0)
            if key in ("-A", "--show-all"):
                opts["show_all"] = True
            elif key == "-n" or key == "--number":
                opts["number"] = True
            elif key == "-p" or key == "--plain":
                opts["plain_count"] += 1
            elif key == "-P":
                opts["paging"] = "never"
            elif key in ("-s", "--squeeze-blank"):
                opts["squeeze"] = True
                if opts["squeeze_limit"] is None:
                    opts["squeeze_limit"] = 1
            elif key in ("-S", "--chop-long-lines"):
                opts["wrap"] = "never"
            elif key in ("-u", "--unbuffered"):
                opts["unbuffered"] = True
            elif key in ("-E", "--quiet-empty"):
                opts["quiet_empty"] = True
            elif key in ("-d", "--diff", "--set-terminal-title"):
                pass
            elif key in ("-l", "--language", "--fallback-syntax", "--fallback-language", "-m",
                       "--map-syntax", "--theme", "--theme-light", "--theme-dark", "--pager",
                       "--ignored-suffix", "-H", "--highlight-line", "--diff-context",
                       "--italic-text"):
                _, i = parse_value(expanded, i, a)
            elif key in ("--tabs",):
                val, i = parse_value(expanded, i, a); opts["tabs"] = max(0, int(val))
            elif key in ("--squeeze-limit",):
                val, i = parse_value(expanded, i, a); opts["squeeze_limit"] = max(0, int(val))
            elif key in ("-r", "--line-range"):
                val, i = parse_value(expanded, i, a); opts["ranges"].append(val)
            elif key == "--file-name":
                val, i = parse_value(expanded, i, a); opts["file_name"] = val
            elif key == "--nonprintable-notation":
                val, i = parse_value(expanded, i, a); opts["notation"] = val
            elif key == "--binary":
                val, i = parse_value(expanded, i, a); opts["binary"] = val
            elif key == "--strip-ansi":
                val, i = parse_value(expanded, i, a); opts["strip_ansi"] = val
            elif key == "--style":
                val, i = parse_value(expanded, i, a); opts["style"] = val
            elif key == "--decorations":
                val, i = parse_value(expanded, i, a); opts["decorations"] = val
            elif key == "--color":
                val, i = parse_value(expanded, i, a); opts["color"] = val
            elif key == "--paging":
                _, i = parse_value(expanded, i, a)
            elif key == "--wrap":
                val, i = parse_value(expanded, i, a); opts["wrap"] = val
            elif key == "--terminal-width":
                val, i = parse_value(expanded, i, a); opts["terminal_width"] = val
            elif key == "-f" or key == "--force-colorization":
                opts["decorations"] = "always"; opts["color"] = "always"
            else:
                sys.stderr.write(f"error: unexpected argument '{a}' found\n\n")
                sys.stderr.write("Usage: executable [OPTIONS] [FILE]...\n       executable <COMMAND>\n")
                sys.exit(2)
        except ValueError as ex:
            sys.stderr.write(f"error: {ex}\n")
            sys.exit(2)
        i += 1
    if not opts["files"]:
        opts["files"] = ["-"]
    return opts

def split_keep(data):
    if not data:
        return []
    return data.splitlines(True) if data.endswith((b"\n", b"\r")) else data.splitlines(True)

def apply_ranges(lines, specs):
    if not specs:
        return lines
    n = len(lines)
    selected = []
    for spec in specs:
        start, end = parse_range(spec, n)
        if start is None:
            continue
        selected.extend(lines[start-1:end])
    return selected

def parse_range(spec, n):
    if "::" in spec:
        mid, ctx = spec.split("::", 1)
        try:
            m = int(mid); c = int(ctx)
        except ValueError:
            return None, None
        return max(1, m-c), min(n, m+c)
    parts = spec.split(":")
    try:
        if len(parts) == 1:
            v = int(parts[0])
            if v < 0:
                return max(1, n + v + 1), n
            return v, v
        if len(parts) >= 3 and parts[2]:
            ctx = int(parts[2])
            base_s, base_e = parse_range(parts[0] + ":" + parts[1], n)
            return max(1, base_s - ctx), min(n, base_e + ctx)
        s, e = parts[0], parts[1]
        if s.startswith("-") and e == "":
            count = abs(int(s)); return max(1, n - count + 1), n
        start = 1 if s == "" else int(s)
        if e == "":
            end = n
        elif e.startswith("+"):
            end = start + int(e)
        else:
            end = int(e)
        start = max(1, start); end = min(n, end)
        if end < start or start > n:
            return None, None
        return start, end
    except Exception:
        return None, None

ansi_re = re.compile(rb"\x1b\[[0-?]*[ -/]*[@-~]")

def squeeze_lines(lines, limit):
    if limit is None:
        return lines
    out, blank_count = [], 0
    for line in lines:
        content = line.rstrip(b"\r\n")
        if content == b"":
            blank_count += 1
            if blank_count <= limit:
                out.append(line)
        else:
            blank_count = 0
            out.append(line)
    return out

def transform_show_all(line, tabs, notation):
    has_nl = line.endswith(b"\n")
    body = line[:-1] if has_nl else line
    if body.endswith(b"\r"):
        body = body[:-1] + b"\r"
    s = []
    col = 0
    for b in body:
        if b == 9:
            if tabs <= 0:
                s.append("\t")
                col += 1
                continue
            step = tabs - (col % tabs)
            tabmark = "├" + ("─" * max(0, step - 2)) + "┤"
            s.append(tabmark)
            col += step
        elif b == 32:
            s.append("·")
            col += 1
        elif b == 13:
            s.append("^M" if notation == "caret" else "␍")
            col += 2
        elif b == 10:
            s.append("^J" if notation == "caret" else "␊")
            col += 2
        elif b < 32:
            if notation == "caret":
                s.append("^" + chr(b + 64) if b else "^@")
            else:
                s.append(chr(0x2400 + b))
            col += 2 if notation == "caret" else 1
        elif b == 127:
            s.append("^?" if notation == "caret" else "␡")
            col += 2 if notation == "caret" else 1
        elif b == 27:
            s.append("^[" if notation == "caret" else "␛")
            col += 2 if notation == "caret" else 1
        else:
            s.append(bytes([b]).decode("utf-8", "replace"))
            col += 1
    if has_nl:
        s.append("^J" if notation == "caret" else "␊")
        s.append("\n")
    return "".join(s).encode("utf-8")

def expand_tabs_bytes(line, tabs):
    if tabs <= 0:
        return line
    return line.replace(b"\t", b" " * tabs)

def format_lines(lines, opts, filename):
    lines = apply_ranges(lines, opts["ranges"])
    lines = squeeze_lines(lines, opts["squeeze_limit"])
    show_all = opts["show_all"]
    numbered = opts["number"] and not opts["unbuffered"]
    out = []
    width = max(4, len(str(len(lines))))
    for idx, line in enumerate(lines, 1):
        if opts["strip_ansi"] == "always":
            line = ansi_re.sub(b"", line)
        if show_all:
            rendered = transform_show_all(line, opts["tabs"], opts["notation"])
        else:
            rendered = expand_tabs_bytes(line, opts["tabs"]) if numbered else line
        if numbered:
            rendered = f"{idx:>{width}} ".encode() + rendered
        out.append(rendered)
    return b"".join(out)

def print_decorated(data, opts, filename):
    lines = apply_ranges(split_keep(data), opts["ranges"])
    lines = squeeze_lines(lines, opts["squeeze_limit"])
    width = int(os.environ.get("COLUMNS", "80") or "80")
    rule = "─" * 5
    print(rule + "┬" + "─" * max(0, width - 6))
    print("     │ File: " + filename)
    if opts["style"] and "header-filesize" in opts["style"] or opts["style"] == "full":
        print("     │ Size: " + human_size(len(data)))
    print(rule + "┼" + "─" * max(0, width - 6))
    w = max(4, len(str(len(lines))))
    for i, line in enumerate(lines, 1):
        text = line.decode("utf-8", "replace").rstrip("\n")
        text = text.replace("\t", " " * opts["tabs"])
        print(f"{i:>{w}} │ {text}")
    print(rule + "┴" + "─" * max(0, width - 6))

def human_size(n):
    if n < 1000:
        return f"{n} B"
    return f"{n/1000:.1f} KB"

def read_input(path):
    if path == "-":
        return sys.stdin.buffer.read(), "<stdin>", None
    try:
        with open(path, "rb") as f:
            return f.read(), path, None
    except OSError as e:
        return b"", path, e

def run_files(opts):
    status = 0
    for path in opts["files"]:
        data, name, err = read_input(path)
        display_name = opts["file_name"] if path == "-" and opts["file_name"] else name
        if err:
            if getattr(err, "errno", None) == 21:
                status = error(f"'{path}' is a directory.")
            else:
                status = error(f"'{path}': {err.strerror} (os error {err.errno})")
            continue
        if opts["quiet_empty"] and data == b"":
            continue
        decorated = (opts["decorations"] == "always" and not opts["number"]
                     and opts["plain_count"] == 0 and not opts["show_all"])
        if decorated:
            print_decorated(data, opts, display_name)
        else:
            sys.stdout.buffer.write(format_lines(split_keep(data), opts, display_name))
    return status

def print_diagnostic():
    print("#### Software version\n")
    print(VERSION)
    print("\n#### Operating system\n")
    print("- OS: Linux (Ubuntu 22.04)")
    print("\n#### Command-line\n")
    print("```bash")
    print(" ".join(sys.argv))
    print("```")
    print("\n#### Environment variables\n")
    print("```bash")
    for k in ["BAT_CACHE_PATH","BAT_CONFIG_PATH","BAT_OPTS","BAT_PAGER","BAT_PAGING","BAT_STYLE","BAT_TABS","BAT_THEME","BAT_WIDTH","BAT_THEME_DARK","BAT_THEME_LIGHT","COLORTERM","LANG","LC_ALL","LESS","MANPAGER","NO_COLOR","PAGER","SHELL","TERM","XDG_CACHE_HOME","XDG_CONFIG_HOME"]:
        print(f"{k}={os.environ.get(k, '<not set>')}")
    print("```")

def print_acknowledgements():
    print("""Copyright (c) 2018-2021 bat-developers (https://github.com/sharkdp/bat).

bat is made available under the terms of either the MIT License or the Apache
License 2.0, at your option.

See the LICENSE-APACHE and LICENSE-MIT files for license details.
""")

def print_completion(shell):
    if shell == "bash":
        print("_bat() { :; }\ncomplete -F _bat bat")
    elif shell == "fish":
        print("complete -c bat")
    elif shell == "zsh":
        print("#compdef bat")
    else:
        print("")

def handle_cache(argv):
    if "-h" in argv or "--help" in argv:
        print("""Modify the syntax-definition and theme cache

Usage: executable cache [OPTIONS]

Options:
  -h, --help
          Print help

  -b, --build
          Initialize (or update) the syntax/theme cache by loading from the source directory
          (default: the configuration directory).

  -c, --clear
          Remove the cached syntax definitions and themes.

      --source <dir>
          Use a different directory to load syntaxes and themes from.

      --target <dir>
          Use a different directory to store the cached syntax and theme set.

      --blank
          Create completely new syntax and theme sets (instead of appending to the default sets).

      --acknowledgements
          Build acknowledgements.bin.
""")
        return 0
    print("No syntaxes or themes were loaded")
    return 0

def main():
    argv = sys.argv[1:]
    if os.environ.get("BAT_OPTS"):
        try:
            argv = shlex.split(os.environ["BAT_OPTS"]) + argv
        except ValueError:
            pass
    if argv and argv[0] == "cache":
        sys.exit(handle_cache(argv[1:]))
    opts = parse_args(argv)
    sys.exit(run_files(opts))

if __name__ == "__main__":
    main()
