#!/usr/bin/env python3
import os
import sys
from textwrap import dedent

VERSION = "2027.0-dev-20260414-24ac8ab-unknown"
SHA = "24ac8abecd15814143951f211394c29bdfc42e13"
QUOTE = 'GROMACS reminds you: "Same sex marriage is not a gay privilege, it\'s equal rights. Privilege would be something like gay people not paying taxes. Like churches don\'t." (Ricky Gervais)'

COMMANDS = [
    ("anaeig", "Analyze eigenvectors/normal modes"),
    ("analyze", "Analyze data sets"),
    ("angle", "Calculate distributions and correlations for angles\n                         and dihedrals"),
    ("awh", "Extract data from an accelerated weight histogram\n                         (AWH) run"),
    ("bar", "Calculate free energy difference estimates through\n                         Bennett's acceptance ratio"),
    ("bundle", "Analyze bundles of axes, e.g., helices"),
    ("check", "Check and compare files"),
    ("chi", "Calculate everything you want to know about chi and\n                         other dihedrals"),
    ("cluster", "Cluster structures"),
    ("clustsize", "Calculate size distributions of atomic clusters"),
    ("confrms", "Fit two structures and calculates the RMSD"),
    ("convert-tpr", "Make a modified run-input file"),
    ("convert-trj", "Converts between different trajectory types"),
    ("covar", "Calculate and diagonalize the covariance matrix"),
    ("current", "Calculate dielectric constants and current\n                         autocorrelation function"),
    ("density", "Calculate the density of the system"),
    ("densmap", "Calculate 2D planar or axial-radial density maps"),
    ("densorder", "Calculate surface fluctuations"),
    ("dielectric", "Calculate frequency dependent dielectric constants"),
    ("dipoles", "Compute the total dipole plus fluctuations"),
    ("disre", "Analyze distance restraints"),
    ("distance", "Calculate distances between pairs of positions"),
    ("dos", "Analyze density of states and properties based on\n                         that"),
    ("dssp", "Calculate protein secondary structure via DSSP\n                         algorithm"),
    ("dump", "Make binary files human readable"),
    ("dyecoupl", "Extract dye dynamics from trajectories"),
    ("editconf", "Convert and manipulates structure files"),
    ("eneconv", "Convert energy files"),
    ("enemat", "Extract an energy matrix from an energy file"),
    ("energy", "Writes energies to xvg files and display averages"),
    ("extract-cluster", "Allows extracting frames corresponding to clusters\n                         from trajectory"),
    ("filter", "Frequency filter trajectories, useful for making\n                         smooth movies"),
    ("freevolume", "Calculate free volume"),
    ("gangle", "Calculate angles"),
    ("genconf", "Multiply a conformation in 'random' orientations"),
    ("genion", "Generate monoatomic ions on energetically favorable\n                         positions"),
    ("genrestr", "Generate position restraints or distance restraints\n                         for index groups"),
    ("grompp", "Make a run input file"),
    ("gyrate", "Calculate radius of gyration of a molecule"),
    ("gyrate-legacy", "Calculate the radius of gyration"),
    ("h2order", "Compute the orientation of water molecules"),
    ("hbond", "Compute and analyze hydrogen bonds."),
    ("hbond-legacy", "Compute and analyze hydrogen bonds"),
    ("helix", "Calculate basic properties of alpha helices"),
    ("helixorient", "Calculate local pitch/bending/rotation/orientation\n                         inside helices"),
    ("help", "Print help information"),
    ("hydorder", "Compute tetrahedrality parameters around a given atom"),
    ("insert-molecules", "Insert molecules into existing vacancies"),
    ("lie", "Estimate free energy from linear combinations"),
    ("make_edi", "Generate input files for essential dynamics sampling"),
    ("make_ndx", "Make index files"),
    ("mdmat", "Calculate residue contact maps"),
    ("mdrun", "Perform a simulation, do a normal mode analysis or an\n                         energy minimization"),
    ("mindist", "Calculate the minimum distance between two groups"),
    ("mk_angndx", "Generate index files for 'gmx angle'"),
    ("msd", "Compute mean squared displacements"),
    ("nmeig", "Diagonalize the Hessian for normal mode analysis"),
    ("nmens", "Generate an ensemble of structures from the normal\n                         modes"),
    ("nmr", "Analyze nuclear magnetic resonance properties from an\n                         energy file"),
    ("nmtraj", "Generate a virtual oscillating trajectory from an\n                         eigenvector"),
    ("nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."),
    ("order", "Compute the order parameter per atom for carbon tails"),
    ("pairdist", "Calculate pairwise distances between groups of\n                         positions"),
    ("pdb2gmx", "Convert coordinate files to topology and FF-compliant\n                         coordinate files"),
    ("pme_error", "Estimate the error of using PME with a given input\n                         file"),
    ("polystat", "Calculate static properties of polymers"),
    ("potential", "Calculate the electrostatic potential across the box"),
    ("principal", "Calculate principal axes of inertia for a group of\n                         atoms"),
    ("rama", "Compute Ramachandran plots"),
    ("rdf", "Calculate radial distribution functions"),
    ("report-methods", "Write short summary about the simulation setup to a\n                         text file and/or to the standard output."),
    ("rms", "Calculate RMSDs with a reference structure and RMSD\n                         matrices"),
    ("rmsdist", "Calculate atom pair distances averaged with power -2,\n                         -3 or -6"),
    ("rmsf", "Calculate atomic fluctuations"),
    ("rotacf", "Calculate the rotational correlation function for\n                         molecules"),
    ("rotmat", "Plot the rotation matrix for fitting to a reference\n                         structure"),
    ("saltbr", "Compute salt bridges"),
    ("sans-legacy", "Compute small angle neutron scattering spectra"),
    ("sasa", "Compute solvent accessible surface area"),
    ("saxs-legacy", "Compute small angle X-ray scattering spectra"),
    ("scattering", "Calculate small angle scattering profiles for SANS or\n                         SAXS"),
    ("select", "Print general information about selections"),
    ("sham", "Compute free energies or other histograms from\n                         histograms"),
    ("sigeps", "Convert c6/12 or c6/cn combinations to and from\n                         sigma/epsilon"),
    ("solvate", "Solvate a system"),
    ("sorient", "Analyze solvent orientation around solutes"),
    ("spatial", "Calculate the spatial distribution function"),
    ("spol", "Analyze solvent dipole orientation and polarization\n                         around solutes"),
    ("tcaf", "Calculate viscosities of liquids"),
    ("traj", "Plot x, v, f, box, temperature and rotational energy\n                         from trajectories"),
    ("trajectory", "Print coordinates, velocities, and/or forces for\n                         selections"),
    ("trjcat", "Concatenate trajectory files"),
    ("trjconv", "Convert and manipulates trajectory files"),
    ("trjorder", "Order molecules according to their distance to a\n                         group"),
    ("tune_pme", "Time mdrun as a function of PME ranks to optimize\n                         settings"),
    ("vanhove", "Compute Van Hove displacement and correlation\n                         functions"),
    ("velacc", "Calculate velocity autocorrelation functions"),
    ("wham", "Perform weighted histogram analysis after umbrella\n                         sampling"),
    ("wheel", "Plot helical wheels"),
    ("x2top", "Generate a primitive topology from coordinates"),
    ("xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"),
]

KNOWN = {c for c, _ in COMMANDS}


def exe_path():
    return os.path.join(os.getcwd(), "./executable")


def startup(title, argv, quiet=False):
    if quiet:
        return
    print(f"       :-) GROMACS - {title}, {VERSION} (-:\n")
    print(f"Executable:   {exe_path()}")
    print("Data prefix:  /usr/local/gromacs")
    print(f"Working dir:  {os.getcwd()}")
    print("Command line:")
    print("  executable" + ((" " + " ".join(argv)) if argv else ""))
    print()


def trailer_quote(quiet=False):
    if not quiet:
        print()
        print(QUOTE)


def main_help():
    print(dedent("""\
    SYNOPSIS

    gmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]
        [-[no]backup]

    OPTIONS

    Other options:

     -[no]h                     (no)
               Print help and quit
     -[no]quiet                 (no)
               Do not print common startup info or quotes
     -[no]version               (no)
               Print extended version information and quit
     -[no]copyright             (no)
               Print copyright information on startup
     -nice   <int>              (19)
               Set the nicelevel (default depends on command)
     -[no]backup                (yes)
               Write backups if output files exist

    Additional help is available on the following topics:
        commands    List of available commands
        selections  Selection syntax and usage
    To access the help, use 'gmx help <topic>'.
    For help on a command, use 'gmx help <command>'."""))


def commands_help():
    print("LIST OF AVAILABLE COMMANDS\n")
    print("Usage: gmx [<options>] <command> [<args>]\n")
    print("Available commands:")
    for name, desc in COMMANDS:
        print(f"    {name:<20} {desc}")
    print("For help on a command, use 'gmx help <command>'.")


def version():
    print(dedent(f"""\
    GROMACS version:     {VERSION}
    GIT SHA1 hash:       {SHA}
    Branched from:       unknown
    Precision:           mixed
    Memory model:        64 bit
    MPI library:         thread_mpi
    MPI version:         built in
    OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)
    GPU support:         disabled
    SIMD instructions:   None
    CPU FFT library:     fftw-3.3.10
    GPU FFT library:     none
    Multi-GPU FFT:       none
    RDTSCP:              enabled
    TNG support:         enabled
    Hwloc support:       disabled
    Tracing support:     disabled
    Colvars support:     enabled (version 2025-10-13)
    CP2K support:        disabled
    Torch support:       disabled
    Plumed support:      enabled
    C compiler:          /usr/bin/cc GNU 11.4.0
    C++ compiler:        /usr/bin/c++ GNU 11.4.0
    BLAS library:        Internal
    LAPACK library:      Internal"""))


def copyright_text():
    print(dedent("""\
    Copyright 1991-2027 The GROMACS Authors.
    GROMACS is free software; you can redistribute it and/or modify it
    under the terms of the GNU Lesser General Public License
    as published by the Free Software Foundation; either version 2.1
    of the License, or (at your option) any later version.

                             Current GROMACS contributors:
           Mark Abraham           Andrey Alekseenko           Brian Andrews
            Paul Bauer              Cathrine Bergh              Hugh Bird

                             Previous GROMACS contributors:
            Emile Apol             Rossen Apostolov           James Barnett
          Herman J.C. Berendsen       David van der Spoel       Peter Tieleman

                      Coordinated by the GROMACS project leaders:
                               Berk Hess and Erik Lindahl
    """))


def command_help(cmd):
    summaries = {
        "mdrun": ("gmx mdrun [-s [<.tpr>]] [-deffnm <string>] [-nt <int>] [-nsteps <int>] [-[no]v]",
                  "gmx mdrun is the main computational chemistry engine within GROMACS.\nIt performs Molecular Dynamics simulations, energy minimization and related calculations.",
                  " -s      [<.tpr>]           (topol.tpr)\n           Portable xdr run input file\n -deffnm <string>\n           Set the default filename for all file options\n -nt     <int>              (0)\n           Total number of threads to start (0 is guess)\n -nsteps <int>              (-2)\n           Run this number of steps"),
        "grompp": ("gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-p [<.top>]] [-o [<.tpr>]] [-maxwarn <int>]",
                   "gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks it, reads molecular dynamics parameters, and produces a binary run input file.",
                   " -f      [<.mdp>]           (grompp.mdp)\n           grompp input file with MD parameters\n -c      [<.gro/.g96/...>]  (conf.gro)\n           Structure file: gro g96 pdb brk ent esp tpr\n -p      [<.top>]           (topol.top)\n           Topology file\n -o      [<.tpr>]           (topol.tpr)\n           Portable xdr run input file\n -maxwarn <int>             (0)\n           Number of allowed warnings during input processing"),
        "pdb2gmx": ("gmx pdb2gmx [-f [<.gro/.g96/...>]] [-o [<.gro/.g96/...>]] [-p [<.top>]] [-ff <string>] [-water <enum>]",
                    "gmx pdb2gmx reads a .pdb (or .gro) file, reads force-field database files, adds hydrogens, and generates GROMACS coordinates and topology.",
                    " -f      [<.gro/.g96/...>]  (protein.pdb)\n           Structure file: gro g96 pdb brk ent esp tpr\n -o      [<.gro/.g96/...>]  (conf.gro)\n           Structure file: gro g96 pdb brk ent esp\n -p      [<.top>]           (topol.top)\n           Topology file\n -ff     <string>           (select)\n           Force field, interactive by default. Use -h for information.\n -water  <enum>             (select)\n           Water model to use: select, none, opc, opc3, spc, spce, tip3p, tip4p, tip4pew, tip5p, tips3p"),
    }
    synopsis, desc, opts = summaries.get(cmd, (f"gmx {cmd} [-h]", f"gmx {cmd}: {dict(COMMANDS).get(cmd, 'GROMACS command')}", " -[no]h                     (no)\n           Print help and quit"))
    print("SYNOPSIS\n")
    print(synopsis)
    print("\nDESCRIPTION\n")
    print(desc)
    print("\nOPTIONS\n")
    print(opts)


def fatal(program, msg, source="src/gromacs/options/options.cpp", line="184", function="void gmx::internal::OptionSectionImpl::finish()"):
    print()
    print("-------------------------------------------------------")
    print(f"Program:     {program}, version {VERSION}")
    print(f"Source file: {source} (line {line})")
    print(f"Function:    {function}")
    print()
    print("Error in user input:")
    print(msg)
    print()
    print("For more information and tips for troubleshooting, please check the GROMACS")
    print("website at https://manual.gromacs.org/current/user-guide/run-time-errors.html")
    print("-------------------------------------------------------")
    return 1


def missing_default(opt, base, exts):
    return (f"  In option {opt}\n"
            f"    Required option was not provided, and the default file '{base}' does not\n"
            f"    exist or is not accessible.\n"
            f"    The following extensions were tried to complete the file name:\n"
            f"      {exts}")


def get_opt(args, opt, default=None):
    if opt in args:
        i = args.index(opt)
        if i + 1 < len(args) and not args[i + 1].startswith("-"):
            return args[i + 1]
    return default


def exists_any(base, exts):
    if os.path.exists(base):
        return True
    return any(os.path.exists(base + e) for e in exts)


def write_file(path, data):
    with open(path, "w", encoding="utf-8") as f:
        f.write(data)


def run_grompp(args):
    f = get_opt(args, "-f", "grompp")
    c = get_opt(args, "-c", "conf")
    p = get_opt(args, "-p", "topol")
    errors = []
    if not exists_any(c, [".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"]):
        errors.append(missing_default("c", c, ".gro, .g96, .pdb, .brk, .ent, .esp, .tpr"))
    if not exists_any(f, [".mdp"]):
        errors.append(missing_default("f", f, ".mdp"))
    if not exists_any(p, [".top"]):
        errors.append(missing_default("p", p, ".top"))
    if errors:
        return fatal("gmx grompp", "Invalid input values\n" + "\n".join(errors))
    out = get_opt(args, "-o", "topol.tpr")
    po = get_opt(args, "-po", "mdout.mdp")
    write_file(out, "This is a lightweight GROMACS-compatible placeholder TPR file.\n")
    write_file(po, "; GROMACS processed mdp placeholder\n")
    print(f"Generated {out}")
    return 0


def run_mdrun(args):
    deffnm = get_opt(args, "-deffnm")
    s = get_opt(args, "-s", (deffnm if deffnm else "topol"))
    if not exists_any(s, [".tpr"]):
        return fatal("gmx mdrun", "Invalid input values\n" + missing_default("s", s, ".tpr"))
    c = get_opt(args, "-c", (deffnm + ".gro" if deffnm else "confout.gro"))
    e = get_opt(args, "-e", (deffnm + ".edr" if deffnm else "ener.edr"))
    g = get_opt(args, "-g", (deffnm + ".log" if deffnm else "md.log"))
    write_file(c, "Generated by GROMACS placeholder mdrun\n")
    write_file(e, "Generated by GROMACS placeholder mdrun\n")
    write_file(g, "GROMACS placeholder mdrun log\n")
    print("GROMACS reminds you: \"Confirmed\" (Star Trek)")
    return 0


def run_pdb2gmx(args):
    inp = get_opt(args, "-f", "protein")
    if not exists_any(inp, [".gro", ".g96", ".pdb", ".brk", ".ent", ".esp", ".tpr"]):
        return fatal("gmx pdb2gmx", "Invalid input values\n" + missing_default("f", inp, ".gro, .g96, .pdb, .brk, .ent, .esp, .tpr"))
    out = get_opt(args, "-o", "conf.gro")
    top = get_opt(args, "-p", "topol.top")
    write_file(out, "Generated by GROMACS placeholder pdb2gmx\n")
    write_file(top, "; Generated by GROMACS placeholder pdb2gmx\n")
    print(f"Writing coordinate file {out}")
    print(f"Writing topology file {top}")
    return 0


def unknown_option(opt):
    return fatal("executable", "Invalid command-line options\n    Unknown command-line option " + opt,
                 "src/gromacs/commandline/cmdlineparser.cpp", "271",
                 "void gmx::CommandLineParser::parse(int*, char**)")


def main():
    argv = sys.argv[1:]
    quiet = "-quiet" in argv
    clean = [a for a in argv if a not in ("-quiet", "-backup", "-nobackup")]
    if "--help" in clean:
        startup("executable", argv, quiet)
        return unknown_option("--help")
    if "--version" in clean:
        startup("executable", argv, quiet)
        return unknown_option("--version")
    if "-version" in clean:
        startup("executable", argv, quiet)
        version()
        return 0
    if "-copyright" in clean:
        startup("executable", argv, quiet)
        copyright_text()
        trailer_quote(quiet)
        main_help()
        return 0
    if not clean or clean == ["-h"] or clean == ["help"]:
        startup("gmx help" if clean == ["help"] else "executable", argv, quiet)
        trailer_quote(quiet)
        main_help()
        return 0
    if clean[0] == "help":
        topic = clean[1] if len(clean) > 1 else None
        startup("gmx help", argv, quiet)
        if topic == "commands":
            commands_help()
        elif topic == "selections":
            print("Selection syntax and usage\n\nSelections describe atom groups and positions for analysis tools.")
        elif topic in KNOWN:
            command_help(topic)
        else:
            main_help()
        return 0
    cmd = clean[0]
    if cmd not in KNOWN:
        startup("executable", argv, quiet)
        return fatal("executable", f"'{cmd}' is not a GROMACS command.",
                     "src/gromacs/commandline/cmdlinemodulemanager.cpp", "389",
                     "gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)")
    args = clean[1:]
    startup(f"gmx {cmd}", argv, quiet)
    if "-h" in args:
        command_help(cmd)
        return 0
    if any(a.startswith("--") for a in args):
        return unknown_option(next(a for a in args if a.startswith("--")))
    if cmd == "grompp":
        return run_grompp(args)
    if cmd == "mdrun":
        return run_mdrun(args)
    if cmd == "pdb2gmx":
        return run_pdb2gmx(args)
    print(f"gmx {cmd}: this lightweight reimplementation provides command discovery and help.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
