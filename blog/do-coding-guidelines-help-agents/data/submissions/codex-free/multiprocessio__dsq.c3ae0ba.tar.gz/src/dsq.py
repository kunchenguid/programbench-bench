#!/usr/bin/env python3
import sys, os, csv, json, re
from collections import OrderedDict

HELP = '''dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq'''

class InputData:
    def __init__(self, rows, source_kind):
        self.rows = rows
        self.source_kind = source_kind
        self.columns = []
        for r in rows:
            if isinstance(r, dict):
                for k in r.keys():
                    if k not in self.columns:
                        self.columns.append(k)
        if not self.columns and rows and not isinstance(rows[0], dict):
            self.columns = ['value']
            self.rows = [{'value': x} for x in rows]


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)

def mimetype_for(path):
    ext = os.path.splitext(path.lower())[1]
    if ext == '.csv': return 'csv'
    if ext in ('.tsv', '.tab'): return 'tsv'
    if ext == '.json': return 'json'
    if ext in ('.ndjson', '.jsonl'): return 'ndjson'
    die(f'Unknown mimetype for file: {path}.')

def load_csv_text(text, delim=','):
    rdr = csv.reader(text.splitlines(), delimiter=delim)
    try:
        header = next(rdr)
    except StopIteration:
        return InputData([], 'csv')
    rows = []
    for rec in rdr:
        if len(rec) < len(header):
            rec += [''] * (len(header)-len(rec))
        row = OrderedDict()
        for i, h in enumerate(header):
            row[str(h)] = rec[i] if i < len(rec) else ''
        rows.append(row)
    return InputData(rows, 'csv')

def load_json_text(text, kind='json'):
    s = text.strip()
    if not s:
        return InputData([], kind)
    if kind == 'ndjson':
        rows = [json.loads(line) for line in text.splitlines() if line.strip()]
        return InputData(rows, kind)
    try:
        obj = json.loads(s)
    except Exception:
        rows = [json.loads(line) for line in text.splitlines() if line.strip()]
        return InputData(rows, 'ndjson')
    if isinstance(obj, list):
        rows = obj
    else:
        rows = [obj]
    return InputData(rows, kind)

def load_path(path):
    mt = mimetype_for(path)
    with open(path, 'r', encoding='utf-8', newline='') as f:
        text = f.read()
    if mt == 'csv': return load_csv_text(text, ',')
    if mt == 'tsv': return load_csv_text(text, '\t')
    if mt == 'json': return load_json_text(text, 'json')
    if mt == 'ndjson': return load_json_text(text, 'ndjson')
    die(f'Unsupported mimetype: {mt}.')

def load_stdin(fmt):
    text = sys.stdin.read()
    fmt = (fmt or '').lower()
    if fmt == 'csv': return load_csv_text(text, ',')
    if fmt == 'tsv': return load_csv_text(text, '\t')
    if fmt in ('json','application/json'): return load_json_text(text, 'json')
    if fmt in ('ndjson','jsonl'): return load_json_text(text, 'ndjson')
    die(f'Unsupported stdin mimetype: {fmt}.')

def sql_value(v):
    if isinstance(v, (dict, list)):
        return json.dumps(v, separators=(',', ':'))
    if isinstance(v, bool):
        return 1 if v else 0
    return v


def split_csv_expr(s):
    out=[]; cur=''; depth=0; quote=None
    for ch in s:
        if quote:
            cur += ch
            if ch == quote: quote = None
        elif ch in ('"', "'"):
            quote = ch; cur += ch
        elif ch == '(':
            depth += 1; cur += ch
        elif ch == ')':
            depth -= 1; cur += ch
        elif ch == ',' and depth == 0:
            out.append(cur.strip()); cur=''
        else:
            cur += ch
    if cur.strip(): out.append(cur.strip())
    return out

def tokenize_clause(q):
    # locate top-level SQL-ish clauses; sufficient for documented dsq examples.
    low=q.lower()
    keys=[' from ',' where ',' group by ',' order by ',' limit ']
    pos={}
    for k in keys:
        i=low.find(k)
        if i>=0: pos[k.strip()]=i
    return pos

def parse_literal(s):
    s=s.strip()
    if (s.startswith("'") and s.endswith("'")) or (s.startswith('"') and s.endswith('"')):
        return s[1:-1]
    if s.lower() == 'null': return None
    if s.lower() == 'true': return True
    if s.lower() == 'false': return False
    try:
        if re.match(r'^-?\d+$', s): return int(s)
        return float(s)
    except Exception:
        return s

def row_get(row, name):
    name=name.strip().strip('`"')
    if name in row: return row[name]
    if '.' in name:
        return row.get(name)
    matches=[v for k,v in row.items() if k.endswith('.'+name)]
    if len(matches)==1: return matches[0]
    return row.get(name)

def cmp_vals(a, op, b):
    if isinstance(a, str) and not isinstance(b, str): b = str(b)
    if not isinstance(a, str) and isinstance(b, str): a = str(a)
    if op in ('=','=='): return a == b
    if op in ('!=','<>'): return a != b
    try:
        if op == '>': return a > b
        if op == '<': return a < b
        if op == '>=': return a >= b
        if op == '<=': return a <= b
    except Exception:
        return False
    return False

def eval_cond(row, cond):
    parts=re.split(r'\s+and\s+', cond, flags=re.I)
    for part in parts:
        part=part.strip().strip('()')
        m=re.match(r'(.+?)\s*(>=|<=|<>|!=|=|>|<)\s*(.+)$', part)
        if not m: continue
        left,op,right=m.groups()
        lv=row_get(row,left)
        rv=row_get(row,right) if re.match(r'^[A-Za-z_]\w*(\.[A-Za-z_]\w*)?$', right.strip()) else parse_literal(right)
        if not cmp_vals(lv,op,rv): return False
    return True

def base_rows(data, table):
    rows=[]
    for r in data.rows:
        nr=OrderedDict()
        for c in data.columns:
            v=r.get(c) if isinstance(r,dict) else None
            nr[f'{table}.{c}']=v
            nr[c]=v
        rows.append(nr)
    return rows

def make_tables(inputs):
    return {f't{i}': data for i,data in enumerate(inputs)}

def parse_sources(src):
    # returns base table and simple inner joins: (table, left, right)
    tokens=src.strip()
    m=re.match(r'^(t\d+)\b(.*)$', tokens, flags=re.I|re.S)
    if not m: die('unsupported query')
    base=m.group(1); rest=m.group(2).strip(); joins=[]
    while rest:
        jm=re.match(r'^join\s+(t\d+)\s+on\s+(.+?)\s*=\s*(.+?)(?=\s+join\s+|$)', rest, flags=re.I|re.S)
        if not jm: break
        joins.append((jm.group(1), jm.group(2).strip(), jm.group(3).strip()))
        rest=rest[jm.end():].strip()
    return base, joins

def execute_query(tables, q):
    q=q.strip().rstrip(';')
    if not q.lower().startswith('select '): die('unsupported query')
    pos=tokenize_clause(q)
    if 'from' not in pos: die('unsupported query')
    sel=q[7:pos['from']].strip()
    clause_order=sorted((v,k) for k,v in pos.items() if k!='from')
    from_end=clause_order[0][0] if clause_order else len(q)
    src=q[pos['from']+6:from_end].strip()
    clauses={}
    for idx,(p,k) in enumerate(clause_order):
        start=p+len(k)+2
        end=clause_order[idx+1][0] if idx+1 < len(clause_order) else len(q)
        clauses[k]=q[start:end].strip()
    base, joins=parse_sources(src)
    if base not in tables: die('no such table: '+base)
    rows=base_rows(tables[base], base)
    for jt,left,right in joins:
        if jt not in tables: die('no such table: '+jt)
        joined=[]
        for a in rows:
            for b in base_rows(tables[jt], jt):
                comb=OrderedDict(a); comb.update(b)
                if cmp_vals(row_get(comb,left),'=',row_get(comb,right)):
                    joined.append(comb)
        rows=joined
    if 'where' in clauses:
        rows=[r for r in rows if eval_cond(r, clauses['where'])]
    group_expr=clauses.get('group by')
    exprs=split_csv_expr(sel)
    if group_expr:
        groups=OrderedDict()
        for r in rows:
            key=row_get(r, group_expr)
            groups.setdefault(key, []).append(r)
        rows2=[]
        for key, members in groups.items():
            rows2.append(project_row(members[0], exprs, members))
        rows=rows2
    else:
        rows=[project_row(r, exprs, None) for r in rows]
    if 'order by' in clauses:
        ob=clauses['order by'].strip()
        desc=False
        if ob.lower().endswith(' desc'):
            desc=True; ob=ob[:-5].strip()
        elif ob.lower().endswith(' asc'):
            ob=ob[:-4].strip()
        rows.sort(key=lambda r: row_get(r, ob), reverse=desc)
    if 'limit' in clauses:
        try: rows=rows[:int(clauses['limit'].split()[0])]
        except Exception: pass
    return rows

def alias_for(expr):
    m=re.match(r'(.+?)\s+as\s+([A-Za-z_]\w*)$', expr, flags=re.I)
    if m: return m.group(1).strip(), m.group(2)
    parts=expr.split()
    if len(parts)==2: return parts[0], parts[1]
    if '.' in expr: return expr.split('.')[-1]
    return expr

def project_row(r, exprs, group_members=None):
    out=OrderedDict()
    if len(exprs)==1 and exprs[0]=='*':
        for k,v in r.items():
            if '.' not in k: out[k]=v
        return out
    for ex in exprs:
        parsed=alias_for(ex)
        if isinstance(parsed, tuple): raw,name=parsed
        else: raw=ex; name=parsed
        if raw.strip().lower().startswith('count('):
            out[name]=len(group_members) if group_members is not None else 1
        else:
            out[name]=row_get(r, raw)
    return out

def convert_out(v):
    if isinstance(v, str):
        ss = v.strip()
        if ss and ss[0] in '[{' and ss[-1:] in ']}':
            try: return json.loads(ss)
            except Exception: return v
    return v

def rewrite_query(q):
    q = q.replace('{}', '{0}')
    return re.sub(r'\{(\d+)\}', lambda m: 't' + m.group(1), q)

def default_query(n):
    return 'SELECT * FROM t0'

def emit_json(rows, multi_line=True):
    parts = [json.dumps(r, separators=(',', ':')) for r in rows]
    if not parts:
        print('[]')
    elif len(parts) == 1:
        print('[' + parts[0] + ']')
    elif multi_line:
        print('[' + ',\n'.join(parts) + ']')
    else:
        print('[' + ','.join(parts) + ']')

def cell_str(v):
    if v is None: return 'null'
    if isinstance(v, bool): return 'true' if v else 'false'
    if isinstance(v, (dict, list)): return json.dumps(v, separators=(',', ':'))
    return str(v)

def emit_pretty(rows):
    if not rows:
        print('(0 rows)'); return
    cols = list(rows[0].keys())
    widths = []
    for c in cols:
        w = len(str(c))
        for r in rows:
            w = max(w, len(cell_str(r.get(c))))
        widths.append(w)
    border = '+' + '+'.join('-'*(w+2) for w in widths) + '+'
    print(border)
    print('|' + '|'.join(' ' + str(c).ljust(widths[i]) + ' ' for i,c in enumerate(cols)) + '|')
    print(border)
    for r in rows:
        cells = []
        for i,c in enumerate(cols):
            s = cell_str(r.get(c))
            if isinstance(r.get(c), (int, float)) and not isinstance(r.get(c), bool):
                cells.append(' ' + s.rjust(widths[i]) + ' ')
            else:
                cells.append(' ' + s.ljust(widths[i]) + ' ')
        print('|' + '|'.join(cells) + '|')
    print(border)
    print(f'({len(rows)} row' + ('' if len(rows)==1 else 's') + ')')

def kind_of(v):
    if v is None: return {'kind':'scalar','scalar':'null'}
    if isinstance(v, bool): return {'kind':'scalar','scalar':'boolean'}
    if isinstance(v, (int,float)): return {'kind':'scalar','scalar':'number'}
    if isinstance(v, str): return {'kind':'scalar','scalar':'string'}
    if isinstance(v, list):
        kinds = [kind_of(x) for x in v]
        return {'kind':'array','array': merge_kinds(kinds) if kinds else {'kind':'unknown'}}
    if isinstance(v, dict):
        keys = []
        for val in [v]:
            for k in val.keys():
                if k not in keys: keys.append(k)
        return {'kind':'object','object': OrderedDict((k, kind_of(v.get(k))) for k in keys)}
    return {'kind':'scalar','scalar':'string'}

def merge_kinds(kinds):
    if not kinds: return {'kind':'unknown'}
    def canon(k): return json.dumps(k, sort_keys=True)
    uniq = []
    for k in kinds:
        if canon(k) not in [canon(u) for u in uniq]: uniq.append(k)
    if len(uniq) == 1: return uniq[0]
    return {'kind':'varied','varied': uniq}

def schema_for(data):
    obj = OrderedDict()
    for c in data.columns:
        ks = []
        for r in data.rows:
            v = r.get(c) if isinstance(r, dict) else None
            if v is None and c not in r:
                ks.append({'kind':'unknown'})
            else:
                ks.append(kind_of(v))
        obj[c] = merge_kinds(ks)
    return {'kind':'array','array':{'kind':'object','object':obj}}

def pretty_schema(k, indent=0):
    sp='  '*indent
    if k.get('kind') == 'array':
        print(sp+'Array of'); pretty_schema(k.get('array', {'kind':'unknown'}), indent+1)
    elif k.get('kind') == 'object':
        print(sp+'Object of')
        for name, sub in k.get('object', {}).items():
            print('  '*(indent+1)+str(name)+' of'); pretty_schema(sub, indent+2)
    elif k.get('kind') == 'scalar':
        print(sp+k.get('scalar','unknown'))
    elif k.get('kind') == 'varied':
        print(sp+'One of')
        for sub in k.get('varied',[]): pretty_schema(sub, indent+1)
    else:
        print(sp+'unknown')

def parse(argv):
    pretty=False; schema=False; stdin_fmt=None; qfile=None; files=[]; query=None
    i=0
    while i < len(argv):
        a=argv[i]
        if a in ('--help','-h'):
            print(HELP); sys.exit(0)
        if a == '--version':
            print('dsq latest'); sys.exit(0)
        if a in ('-p','--pretty'):
            pretty=True; i+=1; continue
        if a == '--schema':
            schema=True; i+=1; continue
        if a in ('-C','--cache','-i','--interactive'):
            i+=1; continue
        if a == '-s':
            if i+1 >= len(argv): die('Must specify stdin mimetype.')
            stdin_fmt=argv[i+1]; i+=2; continue
        if a == '-f':
            if i+1 >= len(argv): die('Must specify a SQL file.')
            qfile=argv[i+1]; i+=2; continue
        # query heuristic: existing/known data files are files; otherwise last arg can be query
        mt_ok = os.path.exists(a) and os.path.splitext(a.lower())[1] in ('.csv','.tsv','.tab','.json','.ndjson','.jsonl')
        if mt_ok:
            files.append(a)
        else:
            if query is None and (('select' in a.lower()) or a.strip().startswith('with') or a.strip().startswith('pragma')):
                query=a
            else:
                # If it is the final arg and we already have a file, treat as query; otherwise file for error behavior.
                if i == len(argv)-1 and (files or stdin_fmt): query=a
                else: files.append(a)
        i+=1
    if qfile:
        try:
            with open(qfile, 'r', encoding='utf-8') as f: query=f.read().strip()
        except Exception as e: die(str(e))
    return pretty, schema, stdin_fmt, files, query

def main():
    pretty, schema, stdin_fmt, files, query = parse(sys.argv[1:])
    inputs=[]
    if stdin_fmt:
        inputs.append(load_stdin(stdin_fmt))
    for f in files:
        inputs.append(load_path(f))
    if not inputs:
        die('No input files.')
    if schema:
        sch = schema_for(inputs[0])
        if pretty: pretty_schema(sch)
        else: print(json.dumps(sch, indent=2))
        return
    tables = make_tables(inputs)
    q = rewrite_query(query or default_query(len(inputs)))
    try:
        rows = execute_query(tables, q)
        rows = [OrderedDict((k, convert_out(v)) for k,v in r.items()) for r in rows]
    except Exception as e:
        die(str(e))
    if pretty: emit_pretty(rows)
    else: emit_json(rows, multi_line=True)

if __name__ == '__main__': main()
