#!/usr/bin/env python3
import datetime as _dt
import os
import re
import sys
import time


VERSION = "commit-93cc85d16ab60ba8d646458fe0233778317b22a3"
DEFAULT_CONFIG = "/home/agent/.caps-log/config.ini"
DEFAULT_LOG_DIR = "/home/agent/.caps-log/day/"
DEFAULT_LOG_FORMAT = "d%y_%m_%d.md"


def help_text():
    return f"""Captain's Log (caps-log)! A CLI journalig tool.
Version: {VERSION}
Allowed options:
  -h [ --help ]         show this message
  -c [ --config ] arg   override the default config file path 
                        ({DEFAULT_CONFIG})
  --log-dir-path arg    path where log files are stored
  --log-name-format arg format in which log entry markdown files are saved
  --sunday-start        have the calendar display sunday as first day of the 
                        week
  --first-line-section  override the default behaviour of ignoring sections 
                        (lines starting with `#`) in the first line of a log 
                        entry file
  --password arg        password for encrypted log repositories or to be used 
                        with --encrypt/--decrypt
  --encrypt             apply encryption to all logs in log dir path (needs 
                        --password)
  --decrypt             apply decryption to all logs in log dir path (needs 
                        --password)
"""


def fail(msg):
    sys.stdout.write("Captain's log encountered an error: \n " + msg + "\n")
    return 1


def parse_args(argv):
    opts = {
        "config": DEFAULT_CONFIG,
        "log_dir": None,
        "log_format": None,
        "sunday_start": False,
        "first_line_section": False,
        "password": None,
        "encrypt": False,
        "decrypt": False,
        "help": False,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            opts["help"] = True
        elif a in ("-c", "--config", "--log-dir-path", "--log-name-format", "--password"):
            if i + 1 >= len(argv):
                name = {"-c": "--config"}.get(a, a)
                return None, f"the required argument for option '{name}' is missing"
            val = argv[i + 1]
            if a in ("-c", "--config"):
                opts["config"] = val
            elif a == "--log-dir-path":
                opts["log_dir"] = val
            elif a == "--log-name-format":
                opts["log_format"] = val
            else:
                opts["password"] = val
            i += 1
        elif a == "--sunday-start":
            opts["sunday_start"] = True
        elif a == "--first-line-section":
            opts["first_line_section"] = True
        elif a == "--encrypt":
            opts["encrypt"] = True
        elif a == "--decrypt":
            opts["decrypt"] = True
        else:
            return None, f"unrecognised option '{a}'"
        i += 1
    return opts, None


def read_config(path):
    data = {}
    section = ""
    try:
        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or line.startswith(";"):
                    continue
                if line.startswith("[") and line.endswith("]"):
                    section = line[1:-1].strip()
                    continue
                if "=" in line:
                    k, v = line.split("=", 1)
                    k = k.strip()
                    v = v.split(" #", 1)[0].strip()
                    data[(section + "." + k) if section else k] = v
    except OSError:
        raise FileNotFoundError(path)
    return data


def truthy(v):
    return str(v).strip().lower() in ("1", "true", "yes", "on")


def date_pattern(fmt):
    out = ""
    fields = []
    i = 0
    while i < len(fmt):
        if fmt[i] == "%" and i + 1 < len(fmt):
            c = fmt[i + 1]
            if c in ("y", "Y"):
                out += r"(\d{2,4})"
                fields.append("year")
            elif c == "m":
                out += r"(\d{1,2})"
                fields.append("month")
            elif c == "d":
                out += r"(\d{1,2})"
                fields.append("day")
            else:
                out += re.escape("%" + c)
            i += 2
        else:
            out += re.escape(fmt[i])
            i += 1
    return re.compile("^" + out + "$"), fields


def scan_logs(log_dir, fmt, first_line_section=False):
    entries = []
    sections = set()
    tags = set()
    pat, fields = date_pattern(fmt)
    if not os.path.isdir(log_dir):
        return entries, sections, tags
    for name in sorted(os.listdir(log_dir)):
        m = pat.match(name)
        if not m:
            # Be liberal: the README and binary disagree in places, so accept
            # the common default shapes as log files too.
            m2 = re.match(r"^d?(\d{2,4})_(\d{1,2})_(\d{1,2})\.md$", name)
            if not m2:
                continue
            vals = {"year": int(m2.group(1)), "month": int(m2.group(2)), "day": int(m2.group(3))}
        else:
            vals = {}
            for key, value in zip(fields, m.groups()):
                vals[key] = int(value)
        year = vals.get("year", _dt.date.today().year)
        if year < 100:
            year += 2000
        month = vals.get("month", 1)
        day = vals.get("day", 1)
        try:
            d = _dt.date(year, month, day)
        except ValueError:
            continue
        entries.append((d, os.path.join(log_dir, name)))
        current_section = "<root section>"
        try:
            with open(os.path.join(log_dir, name), "r", encoding="utf-8", errors="replace") as f:
                for idx, line in enumerate(f):
                    s = line.strip()
                    if s.startswith("#") and (idx != 0 or first_line_section):
                        current_section = s.lstrip("#").strip() or "<root section>"
                        sections.add(current_section)
                    elif s.startswith("*"):
                        tag = s.lstrip("*").strip()
                        tag = tag.split(":", 1)[0].strip()
                        tag = re.sub(r"\s*\([^)]*\)\s*$", "", tag).strip()
                        if tag:
                            tags.add(tag)
                            sections.add(current_section)
        except OSError:
            pass
    return entries, sections, tags


def print_screen(log_dir, fmt, sunday, first_line_section):
    today = _dt.date.today()
    entries, sections, tags = scan_logs(log_dir, fmt, first_line_section)
    count = sum(1 for d, _ in entries if d.year == today.year)
    sys.stdout.write("\x1bP$q q\x1b\\\x1b[?1049h\x1b[?7l\x1b[?1000h\x1b[?1003h\x1b[?1015h\x1b[?1006h\r")
    sys.stdout.write(f"\x1b[2K       \x1b[1m\x1b[4mToday is: {today.day:02d}. {today.month:02d}. {today.year}.  | There are {count} log entries for year {today.year}.\x1b[22m\x1b[24m        \n")
    sec_items = ["<select none>"] + sorted(sections)
    tag_items = ["<select none>"] + sorted(tags)
    sys.stdout.write("╭Sections───────────╮╭Tags──────────────╮╭%d────────────────────────╮ \n" % today.year)
    for row in range(12):
        left = ("> " + sec_items[row]) if row < len(sec_items) else ""
        right = ("> " + tag_items[row]) if row < len(tag_items) else ""
        if row == 0:
            mid = month_block(today.year, today.month, sunday).splitlines()[0]
        elif row < len(month_block(today.year, today.month, sunday).splitlines()):
            mid = month_block(today.year, today.month, sunday).splitlines()[row]
        else:
            mid = ""
        sys.stdout.write("│%-19.19s││%-18.18s││%-28.28s│ \n" % (left, right, mid))
    sys.stdout.write("╰───────────────────╯╰──────────────────╯╰────────────────────────────╯ \n")
    sys.stdout.write("╭──────────────────────────────────────────────────────────────────────────────╮\n")
    sys.stdout.write(f"│                         log preview for {today.day:02d}. {today.month:02d}. {str(today.year)[2:]}.                          │\n")
    sys.stdout.write("╰──────────────────────────────────────────────────────────────────────────────╯\n")
    sys.stdout.flush()


def month_block(year, month, sunday):
    import calendar
    cal = calendar.Calendar(firstweekday=6 if sunday else 0)
    names = ["S", "M", "T", "W", "T", "F", "S"] if sunday else ["M", "T", "W", "T", "F", "S", "S"]
    lines = [_dt.date(year, month, 1).strftime("%B"), " ".join("%2s" % n for n in names)]
    for week in cal.monthdayscalendar(year, month):
        lines.append(" ".join("  " if d == 0 else "%2d" % d for d in week))
    return "\n".join(lines)


def main(argv):
    opts, err = parse_args(argv)
    if err:
        return fail(err)
    if opts["help"]:
        sys.stdout.write(help_text())
        return 0
    try:
        cfg = read_config(opts["config"])
    except FileNotFoundError as e:
        return fail(f"Failed to open file: {e.args[0]}")

    if truthy(cfg.get("git.enable-git-log-repo", "false")):
        if not cfg.get("git.ssh-key-path"):
            return fail("SSH key path can not be empty!")
        if not cfg.get("git.ssh-pub-key-path"):
            return fail("SSH pub key path can not be empty!")
        if not cfg.get("git.repo-root"):
            return fail("Git repo root can not be empty!")

    log_dir = opts["log_dir"] or cfg.get("log-dir-path") or DEFAULT_LOG_DIR
    fmt = opts["log_format"] or cfg.get("log-name-format") or cfg.get("log-filename-format") or DEFAULT_LOG_FORMAT
    sunday = opts["sunday_start"] or truthy(cfg.get("sunday-start", "false"))
    first = opts["first_line_section"] or truthy(cfg.get("first-line-section", "false"))
    password = opts["password"] if opts["password"] is not None else cfg.get("password")

    if (opts["encrypt"] or opts["decrypt"]):
        if not password:
            return fail("Password can not be empty!")
        sys.stdout.write("Applying crypto...\n")
        return 0

    print_screen(log_dir, fmt, sunday, first)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
