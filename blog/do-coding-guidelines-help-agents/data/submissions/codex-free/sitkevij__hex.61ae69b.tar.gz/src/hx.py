#!/usr/bin/env python3
import math
import os
import sys


HELP = """Futuristic take on hexdump, made in Rust.


Usage: executable [OPTIONS] [INPUTFILE]

Arguments:
  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin

Options:
  -c, --cols <columns>        Set column length
  -l, --len <len>             Set <len> bytes to read
  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]
  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]
  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]
  -u, --func <func_length>    Set function wave length
  -p, --places <func_places>  Set function wave output decimal places
  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]
  -h, --help                  Print help
  -V, --version               Print version
"""


def parse_int(value, opt):
    try:
        return int(value, 10)
    except ValueError:
        print(f"{opt} <integer> expected. ParseIntError {{ kind: InvalidDigit }}", file=sys.stderr)
        print("error: invalid digit found in string", file=sys.stderr)
        sys.exit(2)


def usage_error(msg, extra=None):
    print(f"error: {msg}", file=sys.stderr)
    if extra:
        print(extra, file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse(argv):
    opts = {
        "cols": 10,
        "len": None,
        "format": "x",
        "array": None,
        "func": None,
        "places": 4,
        "prefix": True,
        "input": None,
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if arg in ("-V", "--version"):
            print("hx 0.7.0")
            sys.exit(0)
        if arg == "--":
            if i + 1 < len(argv):
                opts["input"] = argv[i + 1]
            break
        takes_value = {
            "-c": "cols", "--cols": "cols",
            "-l": "len", "--len": "len",
            "-f": "format", "--format": "format",
            "-t": "color", "--color": "color",
            "-a": "array", "--array": "array",
            "-u": "func", "--func": "func",
            "-p": "places", "--places": "places",
            "-r": "prefix", "--prefix": "prefix",
        }
        if arg in takes_value:
            if i + 1 >= len(argv):
                usage_error(f"a value is required for '{arg} <value>' but none was supplied")
            key = takes_value[arg]
            val = argv[i + 1]
            if key in ("cols", "len", "func", "places"):
                opts[key] = parse_int(val, arg + (", --" + {"-c":"cols","-l":"len","-u":"func","-p":"places"}[arg] if arg in ("-c","-l","-u","-p") else ""))
            elif key == "format":
                if val not in ("o", "x", "X", "b"):
                    usage_error(f"invalid value '{val}' for '--format <format>'", "  [possible values: o, x, X, b]")
                opts[key] = val
            elif key == "array":
                if val not in ("r", "c", "g", "p", "k", "j", "s", "f"):
                    usage_error(f"invalid value '{val}' for '--array <array_format>'", "  [possible values: r, c, g, p, k, j, s, f]")
                opts[key] = val
            elif key == "prefix":
                if val not in ("0", "1"):
                    usage_error(f"invalid value '{val}' for '--prefix <prefix>'", "  [possible values: 0, 1]")
                opts[key] = val == "1"
            elif key == "color":
                if val not in ("0", "1"):
                    usage_error(f"invalid value '{val}' for '--color <color>'", "  [possible values: 0, 1]")
            i += 2
            continue
        if arg.startswith("-"):
            print(f"error: unexpected argument '{arg}' found", file=sys.stderr)
            print("", file=sys.stderr)
            print(f"  tip: to pass '{arg}' as a value, use '-- {arg}'", file=sys.stderr)
            print("", file=sys.stderr)
            print("Usage: executable [OPTIONS] [INPUTFILE]", file=sys.stderr)
            print("", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        if opts["input"] is None:
            opts["input"] = arg
        else:
            usage_error(f"unexpected argument '{arg}' found")
        i += 1
    return opts


def read_data(path, limit):
    try:
        if path is None:
            data = sys.stdin.buffer.read()
        else:
            with open(path, "rb") as f:
                data = f.read()
    except OSError as e:
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)
    if limit is not None and limit > 0:
        data = data[:limit]
    return data


def byte_token(b, fmt, prefix=True):
    if fmt == "x":
        s = f"{b:02x}"
        return ("0x" if prefix else "") + s
    if fmt == "X":
        s = f"{b:02X}"
        return ("0x" if prefix else "") + s
    if fmt == "o":
        s = f"{b:04o}"
        return ("0o" if prefix else "") + s
    s = f"{b:08b}"
    return ("0b" if prefix else "") + s


def ascii_part(chunk):
    return "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)


def dump(data, opts):
    cols = opts["cols"] if opts["cols"] > 0 else 1
    for offset in range(0, len(data), cols):
        chunk = data[offset:offset + cols]
        line = f"0x{offset:06x}: "
        for b in chunk:
            line += byte_token(b, opts["format"], opts["prefix"]) + " "
        line += " " * ((cols - len(chunk)) * 5)
        line += ascii_part(chunk)
        print(line)
    print(f"   bytes: {len(data)}")


def array_output(data, opts):
    kind = opts["array"]
    cols = opts["cols"] if opts["cols"] > 0 else 1
    n = len(data)
    headers = {
        "r": f"let ARRAY: [u8; {n}] = [",
        "c": f"unsigned char ARRAY[{n}] = {{",
        "g": f"a := [{n}]byte{{",
        "p": "a = [",
        "k": "val a = byteArrayOf(",
        "j": "byte[] a = new byte[]{",
        "s": "let a: [UInt8] = [",
        "f": "let a = [|",
    }
    footers = {
        "r": "];",
        "c": "};",
        "g": "}",
        "p": "]",
        "k": ")",
        "j": "};",
        "s": "]",
        "f": "|]",
    }
    sep = "; " if kind == "f" else ", "
    suffix = "uy" if kind == "f" else ""
    print(headers[kind])
    for offset in range(0, n, cols):
        chunk = data[offset:offset + cols]
        parts = [f"0x{b:02x}{suffix}" for b in chunk]
        line = "    " + sep.join(parts)
        last = offset + len(chunk) >= n
        if not last or kind == "g":
            line += sep
        print(line)
    print(footers[kind])


def func_wave(length, places):
    if length <= 0:
        print()
        return
    vals = [math.sin(i * math.pi / (2 * length)) for i in range(length)]
    print("".join(f"{v:.{places}f}," for v in vals))


def main():
    opts = parse(sys.argv[1:])
    if opts["func"] is not None:
        func_wave(opts["func"], opts["places"])
        return
    data = read_data(opts["input"], opts["len"])
    if opts["array"]:
        array_output(data, opts)
    else:
        dump(data, opts)


if __name__ == "__main__":
    main()
