#!/usr/bin/env python3
import os
import signal
import sys

signal.signal(signal.SIGPIPE, signal.SIG_DFL)

HELP = '''ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
'''

BOOL_LONG = {
    'align','alternate-rows','case-sensitive','column-mode','column-rainbow','column-width',
    'debug','disable-column-cycle','disable-mouse','exec','exit-write','follow-all','follow-mode',
    'follow-name','follow-section','force-screen','help','help-key','hide-other-section',
    'incsearch','line-number','list-view-modes','notify-eof','plain','quit-if-one-screen','raw','regexp-search','ruler',
    'section-header','set-terminal-title','skip-extract','smart-case-sensitive','status-line','version','wrap'
}
ARG_LONG = {
    'caption','column-delimiter','completion','config','converter','exit-write-after','exit-write-before',
    'filter','header','header-column','hscroll-width','jump-target','memory-limit','memory-limit-file',
    'multi-color','non-match-filter','pattern','section-delimiter','section-header-num',
    'section-start','skip-lines','tab-width','vertical-header','view-mode','watch'
}
BOOL_SHORT = set('lCiceXAfnpFrvwh')
ARG_SHORT = set('dabHYjMxymT')

INT_LONG_DISPLAY = {
    'exit-write-after': '-a, --exit-write-after',
    'exit-write-before': '-b, --exit-write-before',
    'header': '-H, --header',
    'header-column': '-Y, --header-column',
    'memory-limit': '--memory-limit',
    'memory-limit-file': '--memory-limit-file',
    'section-header-num': '--section-header-num',
    'section-start': '--section-start',
    'skip-lines': '--skip-lines',
    'tab-width': '-x, --tab-width',
    'vertical-header': '-y, --vertical-header',
    'watch': '-T, --watch',
}
INT_SHORT_DISPLAY = {
    'a': '-a, --exit-write-after',
    'b': '-b, --exit-write-before',
    'H': '-H, --header',
    'Y': '-Y, --header-column',
    'x': '-x, --tab-width',
    'y': '-y, --vertical-header',
    'T': '-T, --watch',
}

def static_text(name):
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', name)
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()

def err(msg):
    print(msg, file=sys.stderr)
    return 1

def flag_error(msg):
    return err('Error: ' + msg)

def need_value(args, i, name, short=None):
    if i + 1 >= len(args):
        if short:
            print(f"Error: flag needs an argument: '{short}' in -{short}", file=sys.stderr)
        else:
            print(f'Error: flag needs an argument: {name}', file=sys.stderr)
        sys.exit(1)
    return args[i + 1], i + 1

def validate_int(value, display):
    try:
        int(value, 10)
    except ValueError:
        print(f'Error: invalid argument "{value}" for "{display}" flag: strconv.ParseInt: parsing "{value}": invalid syntax', file=sys.stderr)
        sys.exit(1)

def copy_file(path):
    try:
        with open(path, 'rb') as f:
            while True:
                b = f.read(1024 * 1024)
                if not b:
                    break
                sys.stdout.buffer.write(b)
        return 0
    except OSError as e:
        return err(f'Error: open {path}: {e.strerror.lower()}')

def copy_stdin():
    while True:
        b = sys.stdin.buffer.read(1024 * 1024)
        if not b:
            break
        sys.stdout.buffer.write(b)
    return 0

def main(argv):
    files = []
    completion = None
    config = None
    list_modes = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '--':
            files.extend(argv[i+1:])
            break
        if a.startswith('--') and len(a) > 2:
            body = a[2:]
            val = None
            if '=' in body:
                body, val = body.split('=', 1)
            if body in ARG_LONG:
                if val is None:
                    val, i = need_value(argv, i, '--' + body)
                if body in INT_LONG_DISPLAY:
                    validate_int(val, INT_LONG_DISPLAY[body])
                if body == 'completion':
                    completion = val
                elif body == 'config':
                    config = val
            elif body in BOOL_LONG:
                if body == 'help':
                    print(HELP, end='')
                    return 0
                if body == 'version':
                    print('ov version dev rev:HEAD')
                    return 0
                if body == 'help-key':
                    print(static_text('help_key.txt'), end='')
                    return 0
                if body == 'list-view-modes':
                    list_modes = True
                # Optional bool values are accepted and ignored.
            else:
                return flag_error('unknown flag: --' + body)
        elif a.startswith('-') and len(a) > 1:
            body = a[1:]
            # Cobra accepts forms such as -w=false for bool shorthand flags.
            if '=' in body:
                key, _ = body.split('=', 1)
                if len(key) == 1 and key in BOOL_SHORT:
                    if key == 'h':
                        print(HELP, end='')
                        return 0
                    if key == 'v':
                        print('ov version dev rev:HEAD')
                        return 0
                elif len(key) == 1 and key in ARG_SHORT:
                    val = body.split('=', 1)[1]
                    if key in INT_SHORT_DISPLAY:
                        validate_int(val, INT_SHORT_DISPLAY[key])
                else:
                    return flag_error("unknown shorthand flag: '" + key[0] + "' in -" + body)
            elif len(body) == 1:
                ch = body
                if ch in ARG_SHORT:
                    val, i = need_value(argv, i, '-' + ch, ch)
                    if ch in INT_SHORT_DISPLAY:
                        validate_int(val, INT_SHORT_DISPLAY[ch])
                    if ch == 'm':
                        pass
                elif ch in BOOL_SHORT:
                    if ch == 'h':
                        print(HELP, end='')
                        return 0
                    if ch == 'v':
                        print('ov version dev rev:HEAD')
                        return 0
                else:
                    return flag_error("unknown shorthand flag: '" + ch + "' in -" + ch)
            else:
                ch = body[0]
                rest = body[1:]
                if ch in ARG_SHORT:
                    if ch in INT_SHORT_DISPLAY:
                        validate_int(rest, INT_SHORT_DISPLAY[ch])
                elif ch in BOOL_SHORT:
                    for ch2 in body:
                        if ch2 not in BOOL_SHORT:
                            return flag_error("unknown shorthand flag: '" + ch2 + "' in -" + body)
                        if ch2 == 'h':
                            print(HELP, end='')
                            return 0
                        if ch2 == 'v':
                            print('ov version dev rev:HEAD')
                            return 0
                else:
                    return flag_error("unknown shorthand flag: '" + ch + "' in -" + body)
        else:
            files.append(a)
        i += 1

    if completion is not None:
        if completion not in ('bash', 'zsh', 'fish', 'powershell'):
            return flag_error('requires one of the arguments bash/zsh/fish/powershell')
        print(static_text('completion_' + completion + '.txt'), end='')
        return 0

    if config is not None and config:
        if '.' not in os.path.basename(config):
            print('failed to read config file: Unsupported Config Type ""', file=sys.stderr)
        elif not os.path.exists(config):
            print(f'failed to read config file: open {config}: no such file or directory', file=sys.stderr)

    if list_modes:
        modes = ['general']
        if config and os.path.basename(config) in ('ov.yaml', 'ov-less.yaml'):
            modes += ['markdown', 'mysql', 'psql']
        print('\n'.join(modes))
        return 0

    if files:
        return copy_file(files[0])
    return copy_stdin()

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
