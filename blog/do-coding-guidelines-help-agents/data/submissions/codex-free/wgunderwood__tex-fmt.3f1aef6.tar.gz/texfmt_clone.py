#!/usr/bin/env python3
import os, sys, re
from pathlib import Path

VERSION = "0.5.6"
DEFAULT_LISTS = ["itemize", "enumerate", "description", "inlineroman", "inventory"]
DEFAULT_VERBATIMS = ["verbatim", "Verbatim", "lstlisting", "minted", "comment"]
DEFAULT_NO_INDENT = ["document"]
EXTS = {".tex", ".bib", ".cls", ".sty"}

HELP = """tex-fmt 0.5.6

LaTeX formatter written in Rust

Usage: executable [OPTIONS] [files]...

Arguments:
  [files]...  List of files to be formatted

Options:
  -c, --check               Check formatting, do not modify files
  -p, --print               Print to stdout, do not modify files
  -f, --fail-on-change      Format files and return non-zero exit code if files are modified
  -n, --nowrap              Do not wrap long lines
  -l, --wraplen <N>         Line length for wrapping [default: 80]
  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]
      --usetabs             Use tabs instead of spaces for indentation
  -s, --stdin               Process stdin as a single file, output to stdout
      --config <PATH>       Path to config file
      --noconfig            Do not read any config file
  -v, --verbose             Show info messages
  -q, --quiet               Hide warning messages
      --trace               Show trace messages
      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]
      --man                 Generate man page
      --args                Print arguments passed to tex-fmt and exit
  -r, --recursive           Recursively search for files to format
  -h, --help                Print help
  -V, --version             Print version
"""

MAN = r'''.ie \n(.g .ds Aq \(aq
.el .ds Aq '
.TH tex-fmt 1  "tex-fmt 0.5.6" 
.SH NAME
tex\-fmt \- LaTeX formatter written in Rust
.SH SYNOPSIS
\fBtex\-fmt\fR [\fB\-c\fR|\fB\-\-check\fR] [\fB\-p\fR|\fB\-\-print\fR] [\fB\-f\fR|\fB\-\-fail\-on\-change\fR] [\fB\-n\fR|\fB\-\-nowrap\fR] [\fB\-l\fR|\fB\-\-wraplen\fR] [\fB\-t\fR|\fB\-\-tabsize\fR] [\fB\-\-usetabs\fR] [\fB\-s\fR|\fB\-\-stdin\fR] [\fB\-\-config\fR] [\fB\-\-noconfig\fR] [\fB\-v\fR|\fB\-\-verbose\fR] [\fB\-q\fR|\fB\-\-quiet\fR] [\fB\-\-trace\fR] [\fB\-\-completion\fR] [\fB\-\-man\fR] [\fB\-\-args\fR] [\fB\-r\fR|\fB\-\-recursive\fR] [\fB\-h\fR|\fB\-\-help\fR] [\fB\-V\fR|\fB\-\-version\fR] [\fIfiles\fR] 
.SH DESCRIPTION
LaTeX formatter written in Rust
.SH OPTIONS
.TP
\fB\-c\fR, \fB\-\-check\fR
Check formatting, do not modify files
.TP
\fB\-p\fR, \fB\-\-print\fR
Print to stdout, do not modify files
.TP
\fB\-f\fR, \fB\-\-fail\-on\-change\fR
Format files and return non\-zero exit code if files are modified
.TP
\fB\-n\fR, \fB\-\-nowrap\fR
Do not wrap long lines
.TP
\fB\-l\fR, \fB\-\-wraplen\fR \fI<N>\fR
Line length for wrapping [default: 80]
.TP
\fB\-t\fR, \fB\-\-tabsize\fR \fI<N>\fR
Number of characters to use as tab size [default: 2]
.TP
\fB\-\-usetabs\fR
Use tabs instead of spaces for indentation
.TP
\fB\-s\fR, \fB\-\-stdin\fR
Process stdin as a single file, output to stdout
.TP
\fB\-\-config\fR \fI<PATH>\fR
Path to config file
.TP
\fB\-\-noconfig\fR
Do not read any config file
.TP
\fB\-v\fR, \fB\-\-verbose\fR
Show info messages
.TP
\fB\-q\fR, \fB\-\-quiet\fR
Hide warning messages
.TP
\fB\-\-trace\fR
Show trace messages
.TP
\fB\-\-completion\fR \fI<SHELL>\fR
Generate shell completion script
.br

.br
[\fIpossible values: \fRbash, elvish, fish, powershell, zsh]
.TP
\fB\-\-man\fR
Generate man page
.TP
\fB\-\-args\fR
Print arguments passed to tex\-fmt and exit
.TP
\fB\-r\fR, \fB\-\-recursive\fR
Recursively search for files to format
.TP
\fB\-h\fR, \fB\-\-help\fR
Print help
.TP
\fB\-V\fR, \fB\-\-version\fR
Print version
.TP
[\fIfiles\fR]
List of files to be formatted
.SH VERSION
v0.5.6
.SH AUTHORS
William George Underwood, wg.underwood13@gmail.com
'''

BASH_COMPLETION = '''_tex-fmt() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="-c -p -f -n -l -t -s -v -q -r -h -V --check --print --fail-on-change --nowrap --wraplen --tabsize --usetabs --stdin --config --noconfig --verbose --quiet --trace --completion --man --args --recursive --help --version [files]..."
    case "${prev}" in
        --completion) COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "${cur}")); return 0;;
        --wraplen|-l|--tabsize|-t|--config) COMPREPLY=($(compgen -f "${cur}")); return 0;;
    esac
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}
complete -F _tex-fmt -o bashdefault -o default tex-fmt
'''

class Opt:
    def __init__(self):
        self.check=False; self.print=False; self.fail=False; self.wrap=True
        self.wraplen=80; self.wrapmin=70; self.tabsize=2; self.tabchar='space'
        self.stdin=False; self.config=None; self.noconfig=False; self.verbosity='warn'
        self.lists=list(DEFAULT_LISTS); self.verbatims=list(DEFAULT_VERBATIMS)
        self.no_indent_envs=list(DEFAULT_NO_INDENT); self.wrap_chars=[]
        self.recursive=False; self.files=[]

def die_arg(msg):
    sys.stderr.write(msg + "\n\nFor more information, try '--help'.\n")
    sys.exit(2)

def parse_value(s):
    s=s.strip()
    if s in ('true','false'): return s=='true'
    if re.fullmatch(r'-?\d+', s): return int(s)
    if s.startswith('"') and s.endswith('"'): return s[1:-1]
    if s.startswith('[') and s.endswith(']'):
        inner=s[1:-1].strip()
        if not inner: return []
        vals=[]
        for m in re.finditer(r'"([^"]*)"', inner): vals.append(m.group(1))
        return vals
    return s

def apply_config(o, path):
    try: data=Path(path).read_text()
    except Exception: return
    for raw in data.splitlines():
        line=raw.split('#',1)[0].strip()
        if '=' not in line: continue
        k,v=[x.strip() for x in line.split('=',1)]
        val=parse_value(v)
        if k=='check': o.check=bool(val)
        elif k=='print': o.print=bool(val)
        elif k=='fail-on-change': o.fail=bool(val)
        elif k=='wrap': o.wrap=bool(val)
        elif k=='wraplen': o.wraplen=int(val)
        elif k=='wrapmin': o.wrapmin=int(val)
        elif k=='tabsize': o.tabsize=int(val)
        elif k=='tabchar': o.tabchar=str(val)
        elif k=='stdin': o.stdin=bool(val)
        elif k=='verbosity': o.verbosity=str(val)
        elif k=='lists' and isinstance(val,list): o.lists=list(DEFAULT_LISTS)+val
        elif k=='verbatims' and isinstance(val,list): o.verbatims=list(DEFAULT_VERBATIMS)+val
        elif k=='no-indent-envs' and isinstance(val,list): o.no_indent_envs=list(DEFAULT_NO_INDENT)+val
        elif k=='wrap-chars' and isinstance(val,list): o.wrap_chars=val

def parse(argv):
    o=Opt(); i=0; overrides=[]; special=None
    while i < len(argv):
        a=argv[i]
        if a=='--':
            o.files += argv[i+1:]; break
        if a in ('-h','--help'): special=('help',None); i+=1; continue
        if a in ('-V','--version'): special=('version',None); i+=1; continue
        if a=='--man': special=('man',None); i+=1; continue
        if a=='--completion':
            if i+1>=len(argv): die_arg("error: a value is required for '--completion <SHELL>'")
            special=('completion',argv[i+1]); i+=2; continue
        if a=='--args': special=('args',None); i+=1; continue
        if a in ('-c','--check'): overrides.append(('check',True)); i+=1; continue
        if a in ('-p','--print'): overrides.append(('print',True)); i+=1; continue
        if a in ('-f','--fail-on-change'): overrides.append(('fail',True)); i+=1; continue
        if a in ('-n','--nowrap'): overrides.append(('wrap',False)); i+=1; continue
        if a in ('-s','--stdin'): overrides.append(('stdin',True)); i+=1; continue
        if a in ('-r','--recursive'): overrides.append(('recursive',True)); i+=1; continue
        if a in ('-v','--verbose'): overrides.append(('verbosity','info')); i+=1; continue
        if a in ('-q','--quiet'): overrides.append(('verbosity','error')); i+=1; continue
        if a=='--trace': overrides.append(('verbosity','trace')); i+=1; continue
        if a=='--usetabs': overrides.append(('tabchar','tab')); i+=1; continue
        if a in ('-l','--wraplen','-t','--tabsize','--config'):
            if i+1>=len(argv): die_arg(f"error: a value is required for '{a}'")
            val=argv[i+1]
            if a in ('-l','--wraplen'):
                try: val=int(val)
                except Exception: die_arg(f"error: invalid value '{argv[i+1]}' for '--wraplen <N>': invalid digit found in string")
                overrides.append(('wraplen',val))
            elif a in ('-t','--tabsize'):
                try: val=int(val)
                except Exception: die_arg(f"error: invalid value '{argv[i+1]}' for '--tabsize <N>': invalid digit found in string")
                overrides.append(('tabsize',val))
            else:
                o.config=val
            i+=2; continue
        if a=='--noconfig': o.noconfig=True; i+=1; continue
        if a.startswith('-'):
            sys.stderr.write(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [files]...\n\nFor more information, try '--help'.\n")
            sys.exit(2)
        o.files.append(a); i+=1
    if not o.noconfig:
        if o.config: apply_config(o, o.config)
        elif Path('tex-fmt.toml').exists(): apply_config(o, 'tex-fmt.toml')
    for k,v in overrides: setattr(o,k,v)
    return o, special

def indent_str(o, level):
    if level <= 0: return ''
    return ('\t' if o.tabchar=='tab' else ' ' * o.tabsize) * level

def begin_env(line):
    m=re.match(r'\\begin\{([^}]+)\}', line.strip())
    return m.group(1) if m else None

def end_env(line):
    m=re.match(r'\\end\{([^}]+)\}', line.strip())
    return m.group(1) if m else None

def is_item(line):
    return re.match(r'\\item(\[[^]]*\])?(\s|$)', line.strip()) is not None

def wrap_line(text, prefix, cont_prefix, o, comment=False):
    if not o.wrap or len(prefix + text) <= o.wraplen or not text.strip():
        return [prefix + text]
    words=text.split()
    if not words: return [prefix]
    out=[]; cur=''
    p=prefix
    for w in words:
        limit=o.wraplen - len(p)
        if cur and len(cur)+1+len(w) > max(10, limit):
            out.append(p+cur)
            p=cont_prefix
            cur=w
        else:
            cur = w if not cur else cur+' '+w
    if cur: out.append(p+cur)
    return out

def format_text(src, o):
    lines=src.splitlines()
    out=[]; level=0; env_stack=[]; item_depth={}; verbatim=None; off=False; prev_blank=False
    for raw in lines:
        no_nl=raw.rstrip('\r')
        stripped=no_nl.strip()
        if '% tex-fmt: skip' in no_nl:
            out.append(no_nl.rstrip()); prev_blank=False; continue
        if off:
            out.append(no_nl.rstrip()); prev_blank=False
            if '% tex-fmt: on' in no_nl: off=False
            continue
        if '% tex-fmt: off' in no_nl:
            out.append(no_nl.rstrip()); off=True; prev_blank=False; continue
        if verbatim:
            out.append(no_nl.rstrip()); prev_blank=False
            if end_env(stripped)==verbatim: verbatim=None
            continue
        if stripped=='':
            if not prev_blank:
                out.append(''); prev_blank=True
            continue
        prev_blank=False
        env_e=end_env(stripped)
        def active_item():
            return any(item_depth.values())
        if env_e:
            if env_stack:
                # Pop through the matching environment when possible.
                while env_stack:
                    top, inc = env_stack.pop()
                    if inc: level=max(0, level-1)
                    item_depth.pop(len(env_stack)+1, None)
                    if top==env_e: break
            line_level=level + (1 if active_item() else 0)
        elif stripped in (r'\]', r'\)', '$$'):
            level=max(0, level-1); line_level=level + (1 if active_item() else 0)
        else:
            line_level=level + (1 if active_item() and not is_item(stripped) else 0)
        if is_item(stripped):
            line_level=level + (1 if any(d < len(env_stack) and v for d, v in item_depth.items()) else 0)
            if env_stack: item_depth[len(env_stack)] = True
        prefix=indent_str(o,line_level)
        comment = stripped.startswith('%')
        if comment:
            body=stripped[1:].lstrip()
            first=prefix + '%'
            if body: first += ' '
            cont=prefix + '% '
            out.extend(wrap_line(body, first, cont, o, True))
        else:
            cont_prefix=prefix
            if is_item(stripped): cont_prefix=indent_str(o,line_level+1)
            out.extend(wrap_line(stripped, prefix, cont_prefix, o))
        env_b=begin_env(stripped)
        if env_b:
            inc = env_b not in o.no_indent_envs
            env_stack.append((env_b, inc))
            if inc: level += 1
            if env_b in o.verbatims: verbatim=env_b
        elif stripped in (r'\[', r'\(', '$$'):
            level += 1
    return '\n'.join(out) + ('\n' if src.endswith('\n') or out else '')

def log(o, msg, kind='INFO'):
    levels={'trace':3,'info':2,'warn':1,'error':0}
    need={'INFO':2,'WARN':1,'ERROR':0}.get(kind,1)
    if levels.get(o.verbosity,1) >= need:
        sys.stderr.write(msg + "\n")

def process_file(path, o):
    try:
        src=Path(path).read_text()
    except Exception:
        sys.stderr.write(f"ERROR: tex-fmt {path}: Could not open file. \n")
        return 1, False
    log(o, f"INFO: tex-fmt {path}: Formatting started. ", 'INFO')
    dst=format_text(src,o); changed=(dst!=src)
    if o.print:
        sys.stdout.write(dst)
    elif o.check:
        if changed:
            sys.stderr.write(f"ERROR: tex-fmt {path}: Incorrect formatting. \n")
    else:
        if changed: Path(path).write_text(dst)
    log(o, f"INFO: tex-fmt {path}: Formatting complete. ", 'INFO')
    return (1 if (changed and (o.check or o.fail)) else 0), changed

def collect_recursive(files):
    roots=files or ['.']; res=[]
    for root in roots:
        p=Path(root)
        if p.is_file():
            if p.suffix in EXTS: res.append(str(p))
            continue
        for dirpath, dirnames, filenames in os.walk(p):
            dirnames[:] = [d for d in dirnames if d not in ('.git','target')]
            for f in sorted(filenames):
                q=Path(dirpath)/f
                if q.suffix in EXTS: res.append(str(q))
    return sorted(res)

def print_args(o):
    print('tex-fmt')
    rows=[('check:',str(o.check).lower()),('print:',str(o.print).lower()),('fail-on-change:',str(o.fail).lower()),('wrap:',str(o.wrap).lower()),('wraplen:',str(o.wraplen)),('wrapmin:',str(o.wrapmin)),('tabsize:',str(o.tabsize)),('tabchar:', 'tab' if o.tabchar=='tab' else 'space'),('stdin:',str(o.stdin).lower()),('config:', 'None' if not o.config else f'Some("{o.config}")'),('verbosity:',o.verbosity)]
    for k,v in rows: print(f"  {k:<24} {v}")
    for name, vals in [('lists:',o.lists),('verbatims:',o.verbatims),('no-indent-envs:',o.no_indent_envs),('wrap-chars:',o.wrap_chars),('files:',o.files)]:
        if vals:
            print(f"  {name:<24} {vals[0]}")
            for x in vals[1:]: print(f"  {'':<24} {x}")
        else:
            print(f"  {name:<24} ")

def main(argv):
    o,special=parse(argv)
    if special:
        typ,val=special
        if typ=='help': sys.stdout.write(HELP); return 0
        if typ=='version': print('tex-fmt 0.5.6'); return 0
        if typ=='man': sys.stdout.write(MAN); return 0
        if typ=='completion':
            if val not in ('bash','elvish','fish','powershell','zsh'):
                sys.stderr.write(f"error: invalid value '{val}' for '--completion <SHELL>'\n"); return 2
            sys.stdout.write(BASH_COMPLETION if val=='bash' else f"# completion for {val}\n")
            return 0
        if typ=='args': print_args(o); return 0
    if o.stdin:
        sys.stdout.write(format_text(sys.stdin.read(), o)); return 0
    if o.recursive: o.files=collect_recursive(o.files)
    if not o.files:
        sys.stderr.write('ERROR: tex-fmt : No files specified. Provide filenames, or pass --recursive or --stdin. \n')
        return 1
    status=0
    for f in o.files:
        s,_=process_file(f,o)
        if s: status=1
    return status

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
