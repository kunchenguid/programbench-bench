#!/usr/bin/env python3
import sys, os, re, json, fnmatch
from dataclasses import dataclass, field

VERSION = """Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team
Universal Ctags is derived from Exuberant Ctags.
Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert
  Compiled: Apr 20 2026, 16:52:56
  URL: https://ctags.io/
  Output version: 1.1
  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript"""

HELP = VERSION + r'''

Usage: executable [options] [file(s)]

Input/Output Options
  --exclude=<pattern>              Exclude files and directories matching <pattern>.
  --filter[=(yes|no)]              Read file names from stdin and write tags to stdout [no].
  --links[=(yes|no)]               Indicate whether symbolic links should be followed [yes].
  --maxdepth=<N>                   Specify maximum recursion depth.
  --recurse[=(yes|no)]; -R         Recurse into directories supplied on command line [no].
  -L <file>                        Read a list of input file names from <file>, or stdin for -.
  --append[=(yes|no)]; -a          Append to existing tag file [no].
  -f <tagfile>; -o <tagfile>        Write tags to specified <tagfile>; - writes stdout.

Output Format Options
  --format=(1|2)                   Force output of specified tag file format [2].
  --output-format=(u-ctags|e-ctags|etags|xref|json)
  -e                               Output tag file for use with Emacs.
  -x                               Print a tabular cross reference file to stdout.
  --sort=(yes|no|foldcase); -u     Sort tags [yes].
  --fields=[+|-][<flags>|*]        Include selected extension fields [fks].
  -n                               Equivalent to --excmd=number.
  -N                               Equivalent to --excmd=pattern.

Language Selection and Mapping Options
  --language-force=(<language>|auto)
  --languages=[+|-](<list>|all)
  --langmap=<map>

Listing Options
  --list-features
  --list-languages
  --list-kinds[=(<language>|all)]
  --list-fields[=(<language>|all)]
  --list-output-formats
  --list-extras[=(<language>|all)]
  --list-pseudo-tags
  --machinable[=(yes|no)]
  --help                           Print this help message.
  --version                        Print version identifier.
'''

LANGS = ["Abaqus","Abc","Ada","AnsiblePlaybook","Ant","Asciidoc","Asm","Asp","Autoconf","Automake","Awk","Basic","Bats","C","C#","C++","CMake","CSS","Ctags","CUDA","Diff","DosBatch","DTD","DTS","Elixir","EmacsLisp","Erlang","Fortran","Go","GoMod","Haskell","HTML","Iniconf","Java","JavaScript","JSON","Kotlin","Lua","Make","Markdown","MatLab","ObjectiveC","OCaml","Pascal","Perl","PHP","Python","R","Ruby","Rust","Scala","Scheme","Sh","SQL","Tcl","Tex","TypeScript","Vim","XML","YAML"]
KIND_NAMES = {'c':'class','f':'function','m':'member','v':'variable','d':'macro','s':'struct','g':'enum','e':'enumerator','t':'typedef','i':'interface','p':'package','n':'namespace','M':'module','C':'constant','F':'field','r':'method','u':'union','T':'trait'}
XREF_NAMES = {'c':'class','f':'function','m':'member','v':'variable','d':'macro','s':'struct','g':'enum','e':'enumerator','t':'typedef','i':'interface','p':'package','n':'namespace','M':'module','C':'constant','F':'field','r':'method','u':'union','T':'trait'}

@dataclass
class Tag:
    name: str
    path: str
    line: int
    text: str
    kind: str
    fields: list = field(default_factory=list)
    file_scope: bool = False

    def pattern(self, excmd='pattern'):
        if excmd == 'number':
            return str(self.line)
        s = self.text.rstrip('\n').replace('\\', '\\\\').replace('/', '\\/')
        if self.kind == 'd' and s.startswith('#define ') and len(s.split()) >= 2:
            name = self.name.replace('/', '\\/')
            return f'/^#define {name} /'
        return f'/^{s}$/'


def detect_lang(path, forced=None):
    if forced and forced.lower() != 'auto': return forced.lower()
    base = os.path.basename(path).lower(); ext = os.path.splitext(base)[1].lower()
    if ext in ('.c','.h'): return 'c'
    if ext in ('.cc','.cpp','.cxx','.hpp','.hh','.hxx'): return 'c'
    if ext == '.py': return 'python'
    if ext == '.java': return 'java'
    if ext in ('.js','.mjs','.cjs','.ts','.tsx','.jsx'): return 'javascript'
    if ext == '.go': return 'go'
    if ext == '.rs': return 'rust'
    if ext in ('.rb','.rake') or base == 'gemfile': return 'ruby'
    if ext in ('.sh','.bash','.zsh'): return 'sh'
    if ext in ('.html','.htm'): return 'html'
    if ext in ('.php',): return 'php'
    return 'text'

def clean_type(t):
    t = re.sub(r'\b(static|extern|inline|const|volatile|register|public|private|protected|final|virtual|constexpr|unsigned|signed)\b', '', t)
    return ' '.join(t.replace('*',' ').replace('&',' ').split()) or 'int'

def add(tags, name, path, i, line, kind, fields=None, file_scope=False):
    if name and not name.startswith('__anon'):
        tags.append(Tag(name, path, i, line.rstrip('\n'), kind, fields or [], file_scope))

def parse_c(path, lines):
    tags=[]
    for i,line in enumerate(lines,1):
        s=line.strip()
        if not s or s.startswith('//'): continue
        m=re.match(r'#\s*define\s+([A-Za-z_]\w*)', s)
        if m: add(tags,m.group(1),path,i,line,'d',file_scope=True); continue
        m=re.search(r'\b(struct|union)\s+([A-Za-z_]\w*)\s*\{([^}]*)\}\s*;', s)
        if m:
            kind='s' if m.group(1)=='struct' else 'u'; nm=m.group(2); add(tags,nm,path,i,line,kind,file_scope=True)
            for typ,n in re.findall(r'([A-Za-z_][\w\s\*]*?)\s+([A-Za-z_]\w*)\s*(?:\[[^]]*\])?\s*;', m.group(3)):
                add(tags,n,path,i,line,'m',[f'{m.group(1)}:{nm}',f'typeref:typename:{clean_type(typ)}'],True)
            continue
        m=re.search(r'\benum\s+([A-Za-z_]\w*)\s*\{([^}]*)\}', s)
        if m:
            nm=m.group(1); add(tags,nm,path,i,line,'g',file_scope=True)
            for part in m.group(2).split(','):
                em=re.match(r'\s*([A-Za-z_]\w*)', part)
                if em: add(tags,em.group(1),path,i,line,'e',[f'enum:{nm}'],True)
            continue
        m=re.match(r'typedef\s+(?:struct|enum|union)?\s*([A-Za-z_]\w*)?\s*.*?\b([A-Za-z_]\w*)\s*;', s)
        if m:
            ref=m.group(1) or ''
            fields=[f'typeref:struct:{ref}'] if ref else []
            add(tags,m.group(2),path,i,line,'t',fields,True); continue
        if '(' in s and not s.startswith(('if','for','while','switch','return')):
            m=re.match(r'([~A-Za-z_][\w:\<\>\s\*&]+?)\s+([A-Za-z_~][\w:]*)\s*\([^;{}]*\)\s*(?:\{|$)', s)
            if m and not re.search(r'\b(operator|typedef)\b', m.group(1)):
                typ=clean_type(m.group(1)); fs=s.startswith('static ')
                add(tags,m.group(2).split('::')[-1],path,i,line,'f',[f'typeref:typename:{typ}'],fs); continue
        m=re.match(r'(?:static\s+)?([A-Za-z_][\w\s\*]+?)\s+([A-Za-z_]\w*)\s*(?:=[^;]*)?;', s)
        if m and not any(w in s for w in ('typedef','return')):
            add(tags,m.group(2),path,i,line,'v',[f'typeref:typename:{clean_type(m.group(1))}'],s.startswith('static '))
    return tags

def parse_python(path, lines):
    tags=[]; stack=[]
    for i,line in enumerate(lines,1):
        stripped=line.strip(); indent=len(line)-len(line.lstrip(' '))
        while stack and indent <= stack[-1][0]: stack.pop()
        m=re.match(r'class\s+([A-Za-z_]\w*)', stripped)
        if m: add(tags,m.group(1),path,i,line,'c'); stack.append((indent,m.group(1),'class')); continue
        m=re.match(r'def\s+([A-Za-z_]\w*)\s*\(', stripped)
        if m:
            cls=next((x[1] for x in reversed(stack) if x[2]=='class'), None)
            add(tags,m.group(1),path,i,line,'m' if cls else 'f', [f'class:{cls}'] if cls else [])
            continue
        m=re.match(r'([A-Z_][A-Z0-9_]*)\s*=', stripped)
        if m and not stack: add(tags,m.group(1),path,i,line,'v')
    return tags

def parse_java(path, lines):
    tags=[]; stack=[]
    for i,line in enumerate(lines,1):
        s=line.strip()
        m=re.match(r'package\s+([\w.]+)\s*;', s)
        if m: add(tags,m.group(1),path,i,line,'p'); continue
        declared=[]
        for mm in re.finditer(r'\b(class|interface|enum)\s+([A-Za-z_]\w*)', s):
            k={'class':'c','interface':'i','enum':'g'}[mm.group(1)]; scope=stack[-1][1] if stack else None
            add(tags,mm.group(2),path,i,line,k,[f'class:{scope}'] if scope and k=='c' else [])
            declared.append((mm.group(2), mm.group(1)))
            if '{' in s and not s.rstrip().endswith('}'): stack.append((s.count('{')-s.count('}'),mm.group(2),mm.group(1)))
        scope=stack[-1][1] if stack else (declared[-1][0] if declared else None)
        scope_kind=stack[-1][2] if stack else (declared[-1][1] if declared else 'class')
        if scope and declared and '}' in s:
            body=s[s.find('{')+1:s.rfind('}')]
            for im in re.finditer(r'\b(?:public|private|protected|static|final|abstract|default|\s)*[A-Za-z_][\w<>\[\]]*\s+([A-Za-z_]\w*)\s*\(', body):
                if im.group(1) not in ('if','for','while','switch'):
                    add(tags,im.group(1),path,i,line,'m',[f'{scope_kind}:{scope}'])
        if scope:
            m=re.match(r'(?:public|private|protected|static|final|abstract|synchronized|native|\s)+\s*([\w<>\[\]]+)?\s*([A-Za-z_]\w*)\s*\([^;{}]*\)', s)
            if m: add(tags,m.group(2),path,i,line,'m',[f'{scope_kind}:{scope}']); continue
            m=re.match(r'(?:public|private|protected|static|final|transient|volatile|\s)+\s*([\w<>\[\]]+)\s+([A-Za-z_]\w*)\s*(?:=.*)?;', s)
            if m: add(tags,m.group(2),path,i,line,'f',[f'{scope_kind}:{scope}'], 'private' in s); continue
        if '}' in s and stack:
            stack.pop()
    return tags

def parse_javascript(path, lines):
    tags=[]; cls=None; depth=0
    for i,line in enumerate(lines,1):
        s=line.strip()
        m=re.match(r'(?:export\s+default\s+|export\s+)?class\s+([A-Za-z_$][\w$]*)', s)
        if m: add(tags,m.group(1),path,i,line,'c'); cls=m.group(1); depth=1; continue
        m=re.match(r'(?:export\s+)?function\s+([A-Za-z_$][\w$]*)\s*\(', s)
        if m: add(tags,m.group(1),path,i,line,'f'); continue
        m=re.match(r'(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?(?:function\b|\([^)]*\)\s*=>|[A-Za-z_$][\w$]*\s*=>)', s)
        if m: add(tags,m.group(1),path,i,line,'f'); continue
        m=re.match(r'(?:const|let|var)\s+([A-Za-z_$][\w$]*)\b', s)
        if m: add(tags,m.group(1),path,i,line,'v'); continue
        if cls:
            m=re.match(r'(?:static\s+)?([A-Za-z_$][\w$]*)\s*\([^)]*\)\s*\{?', s)
            if m and m.group(1) not in ('if','for','while','switch'):
                add(tags,m.group(1),path,i,line,'m',[f'class:{cls}'])
            depth += s.count('{')-s.count('}')
            if depth<=0: cls=None
    return tags

def parse_go(path, lines):
    tags=[]
    for i,line in enumerate(lines,1):
        s=line.strip()
        m=re.match(r'package\s+(\w+)', s)
        if m: add(tags,m.group(1),path,i,line,'p'); continue
        m=re.match(r'func\s+(?:\([^)]*\)\s*)?([A-Za-z_]\w*)\s*\(', s)
        if m: add(tags,m.group(1),path,i,line,'f'); continue
        m=re.match(r'type\s+([A-Za-z_]\w*)\s+(struct|interface|enum)?', s)
        if m: add(tags,m.group(1),path,i,line,'s' if m.group(2)=='struct' else 'i' if m.group(2)=='interface' else 't'); continue
        m=re.match(r'(?:var|const)\s+([A-Za-z_]\w*)', s)
        if m: add(tags,m.group(1),path,i,line,'v')
    return tags

def parse_rust(path, lines):
    tags=[]
    for i,line in enumerate(lines,1):
        s=line.strip()
        for pat,k in [(r'(?:pub\s+)?fn\s+(\w+)','f'),(r'(?:pub\s+)?struct\s+(\w+)','s'),(r'(?:pub\s+)?enum\s+(\w+)','g'),(r'(?:pub\s+)?trait\s+(\w+)','T'),(r'(?:pub\s+)?mod\s+(\w+)','M'),(r'(?:pub\s+)?(?:const|static)\s+(\w+)','v')]:
            m=re.match(pat,s)
            if m: add(tags,m.group(1),path,i,line,k); break
    return tags

def parse_ruby(path, lines):
    tags=[]; stack=[]
    for i,line in enumerate(lines,1):
        s=line.strip()
        m=re.match(r'class\s+([A-Za-z_]\w*)', s)
        if m: add(tags,m.group(1),path,i,line,'c'); stack.append(m.group(1)); continue
        m=re.match(r'module\s+([A-Za-z_]\w*)', s)
        if m: add(tags,m.group(1),path,i,line,'M'); stack.append(m.group(1)); continue
        m=re.match(r'def\s+(?:self\.)?([A-Za-z_]\w*[!?=]?)', s)
        if m: add(tags,m.group(1),path,i,line,'m' if stack else 'f', [f'class:{stack[-1]}'] if stack else [])
        if s=='end' and stack: stack.pop()
    return tags

def parse_sh(path, lines):
    tags=[]
    for i,line in enumerate(lines,1):
        s=line.strip(); m=re.match(r'(?:function\s+)?([A-Za-z_]\w*)\s*\(\)\s*\{?', s)
        if m: add(tags,m.group(1),path,i,line,'f')
    return tags

def parse_html(path, lines):
    tags=[]
    for i,line in enumerate(lines,1):
        for m in re.finditer(r'\bid=["\']([^"\']+)', line): add(tags,m.group(1),path,i,line,'m')
    return tags

def parse_php(path, lines):
    return parse_javascript(path, lines) + [t for t in parse_python(path, [])]

PARSERS={'c':parse_c,'python':parse_python,'java':parse_java,'javascript':parse_javascript,'go':parse_go,'rust':parse_rust,'ruby':parse_ruby,'sh':parse_sh,'html':parse_html,'php':parse_javascript}

def read_tags_for_file(path, forced=None):
    try:
        with open(path, encoding='utf-8', errors='replace') as f: lines=f.readlines()
    except Exception:
        return []
    lang=detect_lang(path, forced); return PARSERS.get(lang, lambda p,l: [])(path, lines)

def pseudo_tags(files, sorted_mode):
    return [
        '!_TAG_EXTRA_DESCRIPTION\tanonymous\t/Include tags for non-named objects like lambda/',
        '!_TAG_EXTRA_DESCRIPTION\tfileScope\t/Include tags of file scope/',
        '!_TAG_EXTRA_DESCRIPTION\tpseudo\t/Include pseudo tags/',
        '!_TAG_FIELD_DESCRIPTION\tfile\t/File-restricted scoping/',
        '!_TAG_FIELD_DESCRIPTION\tname\t/tag name/',
        '!_TAG_FIELD_DESCRIPTION\tpattern\t/pattern/',
        '!_TAG_FIELD_DESCRIPTION\ttyperef\t/Type and name of a variable or typedef/',
        '!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;" to lines/',
        f'!_TAG_FILE_SORTED\t{2 if sorted_mode=="foldcase" else 1 if sorted_mode!="no" else 0}\t/0=unsorted, 1=sorted, 2=foldcase/',
        '!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags/',
        '!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/',
        '!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/',
    ]

def format_tag(t, opts):
    if opts['outfmt']=='json':
        obj={'_type':'tag','name':t.name,'path':t.path,'pattern':t.pattern(opts['excmd']),'kind':KIND_NAMES.get(t.kind,t.kind)}
        for f in t.fields:
            if f.startswith('typeref:'): obj['typeref']=f.split(':',1)[1]
            elif ':' in f:
                sk,sv=f.split(':',1); obj['scope']=sv; obj['scopeKind']=KIND_NAMES.get(sk,sk)
        if t.file_scope: obj['file']=True
        if opts['line_field']: obj['line']=t.line
        return json.dumps(obj, ensure_ascii=False)
    if opts['outfmt']=='xref':
        return f"{t.name:<16} {XREF_NAMES.get(t.kind,t.kind):<12} {t.line:4d} {t.path:<16} {t.text.strip()}"
    parts=[t.name,t.path,t.pattern(opts['excmd']) + ';"',t.kind]
    if opts['kind_long']: parts[-1]='kind:'+KIND_NAMES.get(t.kind,t.kind)
    if opts['line_field']: parts.append(f'line:{t.line}')
    parts.extend(t.fields)
    if t.file_scope: parts.append('file:')
    return '\t'.join(parts)

def collect_files(paths, recurse=False, maxdepth=None, excludes=None):
    out=[]; excludes=excludes or []
    def excluded(p): return any(fnmatch.fnmatch(os.path.basename(p), e) or fnmatch.fnmatch(p, e) for e in excludes)
    for p in paths:
        if excluded(p): continue
        if os.path.isdir(p):
            if recurse:
                root_depth=p.rstrip(os.sep).count(os.sep)
                for root, dirs, files in os.walk(p):
                    if maxdepth is not None and root.count(os.sep)-root_depth >= maxdepth: dirs[:] = []
                    dirs[:] = [d for d in dirs if not excluded(os.path.join(root,d))]
                    for f in files:
                        fp=os.path.join(root,f)
                        if not excluded(fp): out.append(fp)
        else: out.append(p)
    return out

def listing(arg):
    if arg.startswith('--list-features'):
        return "#NAME             DESCRIPTION\niconv             can convert input/output encodings\ninteractive       accepts source code from stdin\njson              supports json format output\noption-directory  TO BE WRITTEN\noptscript         can use the interpreter\npackcc            has peg based parser(s)\nregex             can use regular expression based pattern matching\nsandbox           linked with code for system call level sandbox\nwildcards         can use glob matching\nxpath             linked with library for parsing xml input\nyaml              linked with library for parsing yaml input\n"
    if arg.startswith('--list-languages'):
        return '\n'.join(LANGS)+'\n'
    if arg.startswith('--list-output-formats'):
        return "#OFORMAT DEFAULT AVAILABLE NULLTAG \ne-ctags       no       yes      no \netags         no       yes      no \njson          no       yes     yes \nu-ctags      yes       yes      no \nxref          no       yes     yes \n"
    if arg.startswith('--list-kinds'):
        lang = arg.split('=',1)[1].lower() if '=' in arg else 'all'
        common = {'python':[('c','classes'),('f','functions'),('m','class members'),('v','variables')], 'c':[('d','macro definitions'),('e','enumerators'),('f','function definitions'),('g','enumeration names'),('m','members'),('s','structure names'),('t','typedefs'),('u','union names'),('v','variable definitions')], 'java':[('c','classes'),('f','fields'),('i','interfaces'),('m','methods'),('p','packages')]} 
        rows=common.get(lang, [('c','classes'),('f','functions'),('m','members'),('v','variables')])
        return ''.join(f'{a}  {b}\n' for a,b in rows)
    if arg.startswith('--list-fields'):
        return "#LETTER NAME           ENABLED LANGUAGE         JSTYPE FIXED OP VER DESCRIPTION\nN       name           yes     NONE             s--    yes   rw   0 tag name\nF       input          yes     NONE             s--    yes   r-   0 input file\nP       pattern        yes     NONE             s-b    yes   --   0 pattern\nf       file           yes     NONE             --b    no    --   0 File-restricted scoping\nk       NONE           yes     NONE             s--    no    --   0 Kind of tag in one-letter form\nn       line           no      NONE             -i-    no    rw   0 Line number of tag definition\ns       NONE           yes     NONE             s--    no    --   0 scope (kind:name) of tag definition\nt       typeref        yes     NONE             s--    no    rw   0 Type and name of a variable or typedef\nz       kind           no      NONE             s--    no    r-   0 kind in long-name form\n"
    if arg.startswith('--list-extras'):
        return "#LETTER NAME         ENABLED LANGUAGE DESCRIPTION\nF       fileScope    yes     NONE     Include tags of file scope\np       pseudo       yes     NONE     Include pseudo tags\n"
    if arg.startswith('--list-pseudo-tags'):
        return "#NAME ENABLED DESCRIPTION\nTAG_FILE_FORMAT yes extended format\nTAG_FILE_SORTED yes sorted\nTAG_PROGRAM_NAME yes program name\nTAG_PROGRAM_VERSION yes program version\n"
    return None

def main(argv):
    opts={'tagfile':'tags','append':False,'outfmt':'u-ctags','sort':'yes','line_field':False,'kind_long':False,'excmd':'pattern','recurse':False,'filter':False,'forced':None,'exclude':[],'maxdepth':None}
    files=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a in ('--help','-?'): print(HELP); return 0
        if a=='--version': print(VERSION); return 0
        if a.startswith('--list-'):
            s=listing(a)
            if s is not None: sys.stdout.write(s); return 0
        if a in ('-f','-o'):
            i+=1; opts['tagfile']=argv[i] if i<len(argv) else 'tags'
        elif a.startswith('-f') and len(a)>2: opts['tagfile']=a[2:]
        elif a == '-x': opts['outfmt']='xref'; opts['tagfile']='-'
        elif a == '-e': opts['outfmt']='etags'; opts['tagfile']='TAGS'
        elif a == '-a' or a.startswith('--append'): opts['append']= not a.endswith('=no')
        elif a == '-R' or a.startswith('--recurse'): opts['recurse']= not a.endswith('=no')
        elif a == '-u' or a == '--sort=no': opts['sort']='no'
        elif a == '--sort=foldcase': opts['sort']='foldcase'
        elif a == '-n' or a == '--excmd=number': opts['excmd']='number'; opts['line_field']=True
        elif a == '-N' or a == '--excmd=pattern': opts['excmd']='pattern'
        elif a.startswith('--output-format='):
            opts['outfmt']=a.split('=',1)[1]
            if opts['outfmt'] in ('json','xref'): opts['tagfile']='-'
        elif a.startswith('--fields='):
            val=a.split('=',1)[1]
            if 'n' in val or '*' in val: opts['line_field']= not val.startswith('-')
            if 'K' in val or 'z' in val: opts['kind_long']=True
        elif a.startswith('--language-force='): opts['forced']=a.split('=',1)[1]
        elif a.startswith('--exclude='): opts['exclude'].append(a.split('=',1)[1])
        elif a.startswith('--maxdepth='):
            try: opts['maxdepth']=int(a.split('=',1)[1])
            except ValueError: pass
        elif a.startswith('--filter'):
            opts['filter']= not a.endswith('=no'); opts['tagfile']='-'
        elif a == '-L':
            i+=1; src=argv[i]
            data=sys.stdin.read().splitlines() if src=='-' else open(src, errors='replace').read().splitlines()
            files.extend([x for x in data if x.strip()])
        elif a.startswith('-'):
            pass
        else:
            files.append(a)
        i+=1
    if opts['filter']:
        files.extend([x for x in sys.stdin.read().splitlines() if x.strip()])
    if not files:
        print('executable: No files specified. Try "executable --help".', file=sys.stderr); return 1
    files=collect_files(files, opts['recurse'], opts['maxdepth'], opts['exclude'])
    tags=[]
    for f in files: tags.extend(read_tags_for_file(f, opts['forced']))
    if opts['sort']=='foldcase': tags.sort(key=lambda t:(t.name.lower(), t.path, t.line))
    elif opts['sort']!='no': tags.sort(key=lambda t:(t.name, t.path, t.line))
    lines=[]
    if opts['tagfile']!='-' and not opts['append'] and opts['outfmt']=='u-ctags': lines.extend(pseudo_tags(files, opts['sort']))
    lines.extend(format_tag(t, opts) for t in tags)
    data='\n'.join(lines)+('\n' if lines else '')
    if opts['tagfile']=='-': sys.stdout.write(data)
    else:
        mode='a' if opts['append'] else 'w'
        with open(opts['tagfile'], mode, encoding='utf-8') as f: f.write(data)
    return 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
