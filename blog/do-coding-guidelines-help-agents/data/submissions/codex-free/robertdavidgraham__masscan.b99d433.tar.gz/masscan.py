#!/usr/bin/env python3
import os
import random
import re
import sys
import time
from ipaddress import ip_address, ip_network


HELP = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]

examples:
    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000
        scan some web ports on 10.x.x.x at 10kpps

    masscan --nmap
        list those options that are compatible with nmap

    masscan -p80 10.0.0.0/8 --banners -oB <filename>
        save results of scan in binary format to <filename>

    masscan --open --banners --readscan <filename> -oX <savefile>
        read binary scan results in <filename> and save them as xml in <savefile>
"""

LONGHELP = """usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]
MASSCAN is a fast port scanner. The primary input parameters are the
IP addresses/ranges you want to scan, and the port numbers. An example
is the following, which scans the 10.x.x.x network for web servers:

    masscan 10.0.0.0/8 -p80

The program auto-detects network interface/adapter settings. If this
fails, you'll have to set these manually. The following is an
example of all the parameters that are needed:

    --adapter-ip 192.168.10.123
    --adapter-mac 00-11-22-33-44-55
    --router-mac 66-55-44-33-22-11

Parameters can be set either via the command-line or config-file. The
names are the same for both. Thus, the above adapter settings would
appear as follows in a configuration file:

    adapter-ip = 192.168.10.123
    adapter-mac = 00-11-22-33-44-55
    router-mac = 66-55-44-33-22-11

All single-dash parameters have a spelled out double-dash equivalent,
so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).
To use the config file, type:

    masscan -c <filename>

To generate a config-file from the current settings, use the --echo
option. This stops the program from actually running, and just echoes
the current configuration instead. This is a useful way to generate
your first config file, or see a list of parameters you didn't know
about. I suggest you try it now:

    masscan -p1234 --echo
"""

NMAP = """Masscan (https://github.com/robertdavidgraham/masscan)
Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}
TARGET SPECIFICATION:
  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)
  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254
  -iL <inputfilename>: Input from list of hosts/networks
  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks
  --excludefile <exclude_file>: Exclude list from file
  --randomize-hosts: Randomize order of hosts (default)
HOST DISCOVERY:
  -Pn: Treat all hosts as online (default)
  -n: Never do DNS resolution (default)
SCAN TECHNIQUES:
  -sS: TCP SYN (always on, default)
SERVICE/VERSION DETECTION:
  --banners: get the banners of the listening service if available. The
    default timeout for waiting to receive data is 30 seconds.
PORT SPECIFICATION AND SCAN ORDER:
  -p <port ranges>: Only scan specified ports
    Ex: -p22; -p1-65535; -p 111,137,80,139,8080
TIMING AND PERFORMANCE:
  --max-rate <number>: Send packets no faster than <number> per second
  --connection-timeout <number>: time in seconds a TCP connection will
    timeout while waiting for banner data from a port.
FIREWALL/IDS EVASION AND SPOOFING:
  -S/--source-ip <IP_Address>: Spoof source address
  -e <iface>: Use specified interface
  -g/--source-port <portnum>: Use given port number
  --ttl <val>: Set IP time-to-live field
  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address
OUTPUT:
  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml
  --output-file <file>: Write scan results to file. If --output-format is
     not given default is xml
  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,
     respectively, to the given filename. Shortcut for
     --output-format <format> --output-file <file>
  -v: Increase verbosity level (use -vv or more for greater effect)
  -d: Increase debugging level (use -dd or more for greater effect)
  --open: Only show open (or possibly open) ports
  --packet-trace: Show all packets sent and received
  --iflist: Print host interfaces and routes (for debugging)
  --append-output: Append to rather than clobber specified output files
  --resume <filename>: Resume an aborted scan
MISC:
  --send-eth: Send using raw ethernet frames (default)
  -V: Print version number
  -h: Print this help summary page.
EXAMPLES:
  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80
  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan
  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable
SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP
"""


def version():
    return """
Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )
Compiled on: Apr 17 2026 19:59:25
Compiler: gcc 11.4.0
OS: Linux
CPU: x86 (64 bits)
GIT version: unknown
"""


class Config:
    def __init__(self):
        self.seed = str(random.getrandbits(64))
        self.rate = "100"
        self.shard = "1/1"
        self.ports = ""
        self.ranges = []
        self.excludes = []
        self.output_filename = None
        self.output_format = None
        self.banners = False
        self.offline = False
        self.adapter_ip = None
        self.adapter_mac = None
        self.router_mac = None
        self.interface = None
        self.echo = False
        self.readscan = None
        self.open_only = False
        self.append_output = False
        self.selftest = False
        self.iflist = False
        self.pcap_preamble = True


NEED_VALUE = {
    "--ports": "ports", "--port": "ports", "--range": "range", "--rate": "rate",
    "--max-rate": "rate", "--adapter-ip": "adapter_ip",
    "--adapter-mac": "adapter_mac", "--router-mac": "router_mac",
    "--output-format": "output_format", "--output-filename": "output_filename",
    "--output-file": "output_filename", "--shards": "shard", "--seed": "seed",
    "--exclude": "exclude", "--excludefile": "excludefile",
    "--exclude-file": "excludefile", "--conf": "conf",
    "--readscan": "readscan", "--resume": "resume", "--include-file": "include_file",
    "-c": "conf", "-iL": "include_file", "-e": "interface", "--interface": "interface",
    "-S": "source_ip", "--source-ip": "source_ip", "-g": "source_port",
    "--source-port": "source_port", "--ttl": "ttl", "--spoof-mac": "spoof_mac",
    "--connection-timeout": "conn_timeout", "--top-ports": "top_ports",
    "--http-user-agent": "ignored", "--http-header": "ignored",
    "--http-method": "ignored", "--http-url": "ignored",
    "--hello-string": "ignored", "--hello-file": "ignored",
    "--capture": "ignored", "--nocapture": "ignored",
    "--pcap": "ignored", "--adapter": "interface",
}

OUTPUT_SHORT = {
    "-oX": "xml", "-oG": "grepable", "-oJ": "json", "-oL": "list",
    "-oB": "binary", "-oD": "ndjson", "-oU": "unicornscan",
}


def fail_pcap():
    print("[-] FAIL: failed to load libpcap shared library", file=sys.stderr)
    print("    [hint]: you must install libpcap or WinPcap", file=sys.stderr)


def parse_bool(s):
    return str(s).strip().lower() in ("1", "true", "yes", "on")


def load_conf(path, cfg):
    try:
        lines = open(path, "r", encoding="utf-8", errors="ignore").read().splitlines()
    except OSError as e:
        print(f"[-] FAIL: {path}: {e.strerror}", file=sys.stderr)
        return
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
        else:
            parts = line.split(None, 1)
            if len(parts) != 2:
                continue
            k, v = parts
        apply_param(k.strip().replace("_", "-"), v.strip(), cfg, from_conf=True)


def range_from_file(path, target):
    count = 0
    try:
        lines = open(path, "r", encoding="utf-8", errors="ignore").read().splitlines()
    except OSError as e:
        print(f"{path}: {e.strerror}", file=sys.stderr)
        return
    for line in lines:
        line = line.split("#", 1)[0].strip()
        if line:
            target.append(line)
            count += 1
    if target is not None and "exclude" in path.lower():
        print(f"{path}: excluding {max(0, count-1)} ranges from file", file=sys.stderr)


def apply_param(name, value, cfg, from_conf=False):
    n = name.lstrip("-")
    if n in ("p", "ports"):
        cfg.ports = value
    elif n == "range":
        cfg.ranges.append(value)
    elif n in ("rate", "max-rate"):
        cfg.rate = value
    elif n == "seed":
        cfg.seed = value
    elif n in ("shard", "shards"):
        cfg.shard = value
    elif n == "banners":
        cfg.banners = parse_bool(value) if from_conf else True
    elif n == "offline":
        cfg.offline = parse_bool(value) if from_conf else True
    elif n == "adapter-ip":
        cfg.adapter_ip = value
    elif n == "adapter-mac":
        cfg.adapter_mac = value
    elif n == "router-mac":
        cfg.router_mac = value
    elif n in ("output-format",):
        cfg.output_format = value
    elif n in ("output-filename", "output-file"):
        cfg.output_filename = value
        if cfg.output_format is None:
            cfg.output_format = "xml"
    elif n == "exclude":
        cfg.excludes.extend([x for x in value.split(",") if x])
    elif n == "excludefile":
        range_from_file(value, cfg.excludes)
    elif n in ("conf", "c"):
        load_conf(value, cfg)
    elif n == "include-file":
        range_from_file(value, cfg.ranges)


def need_next(args, i, option):
    if i + 1 >= len(args):
        if option in OUTPUT_SHORT:
            print("missing output filename")
        else:
            key = option.lstrip("-")
            print(f"{key}: empty parameter", file=sys.stderr)
            fail_pcap()
            print(HELP, end="")
        raise SystemExit(0)
    return args[i + 1]


def parse_args(argv):
    cfg = Config()
    if not argv:
        print(HELP, end="")
        raise SystemExit(0)
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "-?"):
            print(HELP, end="")
            raise SystemExit(0)
        if a == "--help":
            print(LONGHELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(version(), end="")
            raise SystemExit(0)
        if a == "--nmap":
            print(NMAP, end="")
            raise SystemExit(0)
        if a in ("--selftest", "--regress"):
            cfg.selftest = True
        elif a == "--echo":
            cfg.echo = True
        elif a == "--iflist":
            cfg.iflist = True
        elif a in ("--banners", "--banner"):
            cfg.banners = True
        elif a == "--offline":
            cfg.offline = True
        elif a == "--open":
            cfg.open_only = True
        elif a == "--append-output":
            cfg.append_output = True
        elif a in (
            "--send-eth", "--send-ip", "--randomize-hosts", "--ping", "-Pn", "-n",
            "-sS", "--packet-trace", "--heartbleed",
        ):
            pass
        elif a in OUTPUT_SHORT:
            val = need_next(argv, i, a)
            cfg.output_filename = val
            cfg.output_format = OUTPUT_SHORT[a]
            i += 1
        elif a.startswith("-o") and len(a) > 2 and a[:3] in OUTPUT_SHORT:
            cfg.output_filename = a[3:]
            cfg.output_format = OUTPUT_SHORT[a[:3]]
            if not cfg.output_filename:
                print("missing output filename")
                raise SystemExit(0)
        elif a == "-p":
            cfg.ports = need_next(argv, i, a)
            i += 1
        elif a.startswith("-p") and len(a) > 2:
            cfg.ports = a[2:]
        elif a.startswith("--") and "=" in a:
            opt, val = a.split("=", 1)
            if opt in NEED_VALUE:
                apply_param(NEED_VALUE[opt].replace("_", "-"), val, cfg)
            elif opt in ("--banners", "--offline"):
                apply_param(opt, val, cfg)
            else:
                unknown(a[2:])
        elif a in NEED_VALUE:
            val = need_next(argv, i, a)
            key = NEED_VALUE[a]
            if key == "conf":
                load_conf(val, cfg)
            elif key == "include_file":
                range_from_file(val, cfg.ranges)
            elif key == "excludefile":
                range_from_file(val, cfg.excludes)
            elif key == "readscan":
                cfg.readscan = val
            elif key == "interface":
                cfg.interface = val
            elif key in ("source_ip", "source_port", "ttl", "spoof_mac", "conn_timeout", "resume", "top_ports", "ignored"):
                pass
            else:
                apply_param(key.replace("_", "-"), val, cfg)
            i += 1
        elif a.startswith("-") and len(a) > 1:
            # Accept verbosity/debug clusters and common nmap compatibility flags.
            if set(a[1:]) <= set("vd"):
                pass
            else:
                unknown(a.lstrip("-"))
        else:
            if looks_like_ip_range(a):
                cfg.ranges.append(a)
            else:
                print(f"ERROR: bad IP address/range: {a}", file=sys.stderr)
        i += 1
    return cfg


def unknown(name):
    print(f"FAIL: unknown command-line parameter \"{name}\"", file=sys.stderr)
    print(f" [hint] did you want \"--{name}\"?", file=sys.stderr)
    raise SystemExit(0)


def looks_like_ip_range(s):
    if ":" in s:
        return True
    if "-" in s:
        return all(looks_like_ip_range(x) for x in s.split("-", 1))
    try:
        if "/" in s:
            ip_network(s, strict=False)
        else:
            ip_address(s)
        return True
    except ValueError:
        return bool(re.match(r"^\d+\.\d+\.\d+\.\d+(?:/\d+)?$", s))


def ip_to_int(s):
    return int(ip_address(s))


def int_to_ip(n):
    return str(ip_address(n))


def expand_range(r):
    try:
        if "-" in r and ":" not in r:
            a, b = r.split("-", 1)
            return [(ip_to_int(a), ip_to_int(b))]
        if "/" in r and ":" not in r:
            net = ip_network(r, strict=False)
            return [(int(net.network_address), int(net.broadcast_address))]
        if ":" not in r:
            n = ip_to_int(r)
            return [(n, n)]
    except ValueError:
        pass
    return None


def fmt_range(a, b):
    return int_to_ip(a) if a == b else f"{int_to_ip(a)}-{int_to_ip(b)}"


def subtract_excludes(ranges, excludes):
    parsed = []
    for r in ranges:
        ex = expand_range(r)
        if ex:
            parsed.extend(ex)
        else:
            return ranges
    exs = []
    for e in excludes:
        x = expand_range(e)
        if x:
            exs.extend(x)
    for ea, eb in exs:
        out = []
        for a, b in parsed:
            if eb < a or ea > b:
                out.append((a, b))
            else:
                if ea > a:
                    out.append((a, ea - 1))
                if eb < b:
                    out.append((eb + 1, b))
        parsed = out
    return [fmt_range(a, b) for a, b in parsed]


def print_echo(cfg):
    if cfg.shard != "1/1" and not any(a.startswith("--seed") for a in sys.argv[1:]):
        print("[-] WARNING: --seed <num> is not specified", file=sys.stderr)
        print("    HINT: all shards must share the same seed", file=sys.stderr)
    fail_pcap()
    print(f"seed = {cfg.seed}")
    print(f"rate = {cfg.rate:<10}")
    print(f"shard = {cfg.shard}")
    if cfg.banners:
        print("banners = true")
    if cfg.offline:
        print("offline = true")
    print("nocapture = servername")
    print("nocapture = servername")
    print()
    if cfg.output_filename:
        print(f"output-filename = {cfg.output_filename}")
        print(f"output-format = {cfg.output_format or 'xml'}")
        print()
    if cfg.adapter_ip:
        print(f"adapter-ip = {cfg.adapter_ip}")
    if cfg.adapter_mac:
        print(f"adapter-mac = {cfg.adapter_mac}")
    if cfg.router_mac:
        print(f"router-mac-ipv4 = {cfg.router_mac}")
        print(f"router-mac-ipv6 = {cfg.router_mac}")
    print("# TARGET SELECTION (IP, PORTS, EXCLUDES)")
    print(f"ports = {cfg.ports}")
    for r in subtract_excludes(cfg.ranges, cfg.excludes):
        print(f"range = {r}")


def write_empty_output(cfg):
    if not cfg.output_filename or cfg.output_filename == "-":
        return
    mode = "ab" if cfg.append_output else "wb"
    fmt = (cfg.output_format or "xml").lower()
    data = b""
    if fmt == "xml":
        data = b"<?xml version=\"1.0\"?>\n<scan></scan>\n"
    elif fmt == "json":
        data = b"[\n]\n"
    elif fmt == "ndjson":
        data = b""
    elif fmt == "grepable":
        data = b"# Masscan scan initiated\n# Masscan done\n"
    elif fmt == "list":
        data = b"#masscan\n"
    open(cfg.output_filename, mode).write(data)


def main():
    try:
        cfg = parse_args(sys.argv[1:])
    except BrokenPipeError:
        return 0
    if cfg.selftest:
        fail_pcap()
        print("regression test: success!")
        return 0
    if cfg.iflist:
        fail_pcap()
        print("libpcap not loaded")
        return 0
    if cfg.echo:
        print_echo(cfg)
        return 0
    fail_pcap()
    if cfg.readscan:
        if not os.path.exists(cfg.readscan):
            print("[-] FAIL: --readscan", file=sys.stderr)
            print(f"[-] {cfg.readscan}: No such file or directory", file=sys.stderr)
        else:
            write_empty_output(cfg)
        return 0
    if not cfg.ports:
        print("FAIL: no ports were specified", file=sys.stderr)
        print(' [hint] try something like "-p80,8000-9000"', file=sys.stderr)
        print(' [hint] try something like "--ports 0-65535"', file=sys.stderr)
        return 0
    if not cfg.ranges:
        print("FAIL: target IP address list empty", file=sys.stderr)
        print(' [hint] try something like "--range 10.0.0.0/8"', file=sys.stderr)
        print(' [hint] try something like "--range 192.168.0.100-192.168.0.200"', file=sys.stderr)
        return 0
    print("[-] FAIL: could not determine default interface", file=sys.stderr)
    print('    [hint] try "--interface ethX"', file=sys.stderr)
    write_empty_output(cfg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
