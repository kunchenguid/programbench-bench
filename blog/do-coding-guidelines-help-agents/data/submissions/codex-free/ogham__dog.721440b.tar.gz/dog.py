#!/usr/bin/env python3
import base64
import json
import os
import random
import socket
import ssl
import struct
import sys
import time
import urllib.parse
import urllib.request

HELP = """dog \u25cf command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information"""

VERSION = """dog \u25cf command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
mhttps://dns.lookup.dog/"""

TYPE = {
    "A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "PTR": 12, "HINFO": 13, "MX": 15,
    "TXT": 16, "AAAA": 28, "LOC": 29, "SRV": 33, "NAPTR": 35, "CAA": 257,
    "SSHFP": 44, "TLSA": 52, "OPT": 41, "ANY": 255, "AFSDB": 18, "IXFR": 251,
}
RTYPE = {v: k for k, v in TYPE.items()}
CLASS = {"IN": 1, "CH": 3, "HS": 4}
RCLASS = {v: k for k, v in CLASS.items()}


class DogError(Exception):
    def __init__(self, msg, status=3):
        super().__init__(msg)
        self.status = status


def eprint(s):
    print(s, file=sys.stderr)


def ttl_fmt(ttl, seconds=False):
    if seconds:
        return str(ttl)
    if ttl >= 3600 and ttl % 3600 == 0:
        return f"{ttl//3600}h00m"
    if ttl >= 3600:
        h = ttl // 3600
        m = (ttl % 3600) // 60
        return f"{h}h{m:02d}m"
    if ttl >= 60:
        return f"{ttl//60}m{ttl%60:02d}s"
    return f"{ttl}s"


def enc_name(n):
    n = n.rstrip(".")
    if not n:
        return b"\0"
    out = bytearray()
    for p in n.split("."):
        b = p.encode()
        if len(b) > 63:
            raise DogError(f'dog: Invalid options: Invalid domain name "{n}"')
        out.append(len(b))
        out += b
    out.append(0)
    return bytes(out)


def read_name(data, off, depth=0):
    labels = []
    jumped = False
    end = off
    while True:
        if off >= len(data):
            raise ValueError("bad name")
        l = data[off]
        if l & 0xC0 == 0xC0:
            ptr = ((l & 0x3F) << 8) | data[off + 1]
            if not jumped:
                end = off + 2
            if depth > 20:
                raise ValueError("loop")
            sub, _ = read_name(data, ptr, depth + 1)
            labels.append(sub.rstrip("."))
            return ".".join([x for x in labels if x]) + ".", end
        off += 1
        if l == 0:
            if not jumped:
                end = off
            return ".".join(labels) + "." if labels else ".", end
        labels.append(data[off:off + l].decode("utf-8", "replace"))
        off += l


def build_query(qname, qtype, qclass, txid, edns=True, tweaks=None, bufsize=512):
    flags = 0x0100
    tweaks = tweaks or set()
    if "aa" in tweaks:
        flags |= 0x0400
    if "ad" in tweaks:
        flags |= 0x0020
    if "cd" in tweaks:
        flags |= 0x0010
    q = enc_name(qname) + struct.pack("!HH", qtype, qclass)
    ar = 1 if edns else 0
    pkt = struct.pack("!HHHHHH", txid, flags, 1, 0, 0, ar) + q
    if edns:
        pkt += b"\0" + struct.pack("!HHIH", 41, bufsize, 0, 0)
    return pkt


def split_host_port(s, default):
    if s.startswith("[") and "]" in s:
        host, rest = s[1:].split("]", 1)
        return host, int(rest[1:]) if rest.startswith(":") else default
    if s.count(":") == 1 and s.rsplit(":", 1)[1].isdigit():
        h, p = s.rsplit(":", 1)
        return h, int(p)
    return s, default


def system_nameservers():
    out = []
    try:
        with open("/etc/resolv.conf") as f:
            for line in f:
                parts = line.split()
                if len(parts) >= 2 and parts[0] == "nameserver":
                    out.append(parts[1])
    except OSError:
        pass
    if not out:
        raise DogError("Error [system]: No nameservers found", 4)
    return out


def udp_query(pkt, ns):
    host, port = split_host_port(ns, 53)
    family = socket.AF_INET6 if ":" in host and not host.count(".") == 3 else socket.AF_INET
    s = socket.socket(family, socket.SOCK_DGRAM)
    s.settimeout(5)
    try:
        s.sendto(pkt, (host, port))
        return s.recvfrom(65535)[0]
    finally:
        s.close()


def tcp_query(pkt, ns, tls=False):
    host, port = split_host_port(ns, 853 if tls else 53)
    raw = socket.create_connection((host, port), timeout=5)
    try:
        s = ssl.create_default_context().wrap_socket(raw, server_hostname=host) if tls else raw
        s.sendall(struct.pack("!H", len(pkt)) + pkt)
        hdr = recvn(s, 2)
        ln = struct.unpack("!H", hdr)[0]
        return recvn(s, ln)
    finally:
        raw.close()


def recvn(s, n):
    b = bytearray()
    while len(b) < n:
        c = s.recv(n - len(b))
        if not c:
            raise OSError("unexpected EOF")
        b += c
    return bytes(b)


def https_query(pkt, url):
    if not (url.startswith("https://") or url.startswith("http://")):
        raise DogError("Error [network]: HTTPS transport requires a URL", 1)
    u = url + ("&" if "?" in url else "?") + "dns=" + base64.urlsafe_b64encode(pkt).rstrip(b"=").decode()
    req = urllib.request.Request(u, headers={"accept": "application/dns-message"})
    with urllib.request.urlopen(req, timeout=5) as r:
        return r.read()


def parse_rr(data, off):
    name, off = read_name(data, off)
    typ, cls, ttl, ln = struct.unpack("!HHIH", data[off:off + 10])
    off += 10
    r0 = off
    rdata = data[off:off + ln]
    off += ln
    text, jdata = rr_text(data, r0, rdata, typ)
    return {"name": name, "type": typ, "class": cls, "ttl": ttl, "text": text, "data": jdata, "raw": list(rdata)}, off


def rr_text(data, r0, r, typ):
    try:
        if typ == 1 and len(r) == 4:
            a = socket.inet_ntop(socket.AF_INET, r)
            return a, {"address": a}
        if typ == 28 and len(r) == 16:
            a = socket.inet_ntop(socket.AF_INET6, r)
            return a, {"address": a}
        if typ in (2, 5, 12):
            n, _ = read_name(data, r0)
            return f'"{n}"', {"domain": n}
        if typ == 15:
            pref = struct.unpack("!H", r[:2])[0]
            n, _ = read_name(data, r0 + 2)
            return f'{pref} "{n}"', {"preference": pref, "exchange": n}
        if typ == 16:
            parts = []
            i = 0
            while i < len(r):
                l = r[i]; i += 1
                parts.append(r[i:i + l].decode("utf-8", "replace")); i += l
            joined = " ".join(parts)
            return '"' + joined.replace('"', '\\"') + '"', {"strings": parts}
        if typ == 6:
            m, p = read_name(data, r0)
            rname, p = read_name(data, p)
            nums = struct.unpack("!IIIII", data[p:p+20])
            return f'"{m}" "{rname}" ' + " ".join(map(str, nums)), {"mname": m, "rname": rname}
        if typ == 33:
            pr, wt, port = struct.unpack("!HHH", r[:6])
            target, _ = read_name(data, r0 + 6)
            return f'{pr} {wt} {port} "{target}"', {"priority": pr, "weight": wt, "port": port, "target": target}
        if typ == 257 and len(r) >= 2:
            flags = r[0]; taglen = r[1]
            tag = r[2:2+taglen].decode("ascii", "replace")
            val = r[2+taglen:].decode("utf-8", "replace")
            return f'{flags} {tag} "{val}"', {"flags": flags, "tag": tag, "value": val}
    except Exception:
        pass
    return " ".join(str(x) for x in r), {"bytes": list(r)}


def parse_response(data):
    if len(data) < 12:
        raise DogError("Error [network]: Truncated response", 1)
    tid, flags, qd, an, ns, ar = struct.unpack("!HHHHHH", data[:12])
    off = 12
    queries = []
    for _ in range(qd):
        n, off = read_name(data, off)
        qt, qc = struct.unpack("!HH", data[off:off + 4]); off += 4
        queries.append({"name": n, "type": qt, "class": qc})
    sections = []
    for count in (an, ns, ar):
        arr = []
        for _ in range(count):
            rr, off = parse_rr(data, off)
            arr.append(rr)
        sections.append(arr)
    return {"txid": tid, "flags": flags, "rcode": flags & 15, "queries": queries,
            "answers": sections[0], "authorities": sections[1], "additionals": sections[2]}


def parse_args(argv):
    cfg = {"queries": [], "types": [], "classes": [], "nameservers": [], "proto": "udp",
           "short": False, "json": False, "color": "automatic", "seconds": False, "time": False,
           "edns": "hide", "txid": None, "tweaks": set(), "bufsize": 512}
    plain = []
    i = 0
    while i < len(argv):
        a = argv[i]
        def need():
            nonlocal i
            if "=" in a:
                return a.split("=", 1)[1]
            i += 1
            if i >= len(argv):
                raise DogError(f"dog: Invalid options: Argument to option '{a.lstrip('-')}' missing")
            return argv[i]
        if a == "--":
            plain += argv[i+1:]; break
        elif a in ("-?", "--help"):
            print(HELP); sys.exit(0)
        elif a in ("-v", "--version"):
            print(VERSION); sys.exit(0)
        elif a in ("-q", "--query") or a.startswith("--query="):
            cfg["queries"].append(need())
        elif a in ("-t", "--type") or a.startswith("--type="):
            cfg["types"].append(parse_type(need()))
        elif a in ("-n", "--nameserver") or a.startswith("--nameserver="):
            cfg["nameservers"].append(need())
        elif a == "--class" or a.startswith("--class="):
            raw = need()
            v = raw.upper()
            if v not in CLASS:
                raise DogError(f'dog: Invalid options: Invalid query class "{raw}"')
            cfg["classes"].append(CLASS[v])
        elif a == "--edns" or a.startswith("--edns="):
            v = need()
            if v not in ("disable", "hide", "show"):
                raise DogError(f'dog: Invalid options: Invalid EDNS setting "{v}"')
            cfg["edns"] = v
        elif a == "--txid" or a.startswith("--txid="):
            v = need()
            try:
                n = int(v, 0)
            except ValueError:
                raise DogError(f'dog: Invalid options: Invalid transaction ID "{v}"')
            if not 0 <= n <= 65535:
                raise DogError(f'dog: Invalid options: Invalid transaction ID "{v}"')
            cfg["txid"] = n
        elif a == "-Z" or a.startswith("-Z="):
            v = need() if a == "-Z" else a[3:]
            parse_tweak(cfg, v)
        elif a in ("-U", "--udp"):
            cfg["proto"] = "udp"
        elif a in ("-T", "--tcp"):
            cfg["proto"] = "tcp"
        elif a in ("-S", "--tls"):
            cfg["proto"] = "tls"
        elif a in ("-H", "--https"):
            cfg["proto"] = "https"
        elif a in ("-1", "--short"):
            cfg["short"] = True
        elif a in ("-J", "--json"):
            cfg["json"] = True
        elif a == "--seconds":
            cfg["seconds"] = True
        elif a == "--time":
            cfg["time"] = True
        elif a in ("--color", "--colour") or a.startswith("--color=") or a.startswith("--colour="):
            v = need()
            if v not in ("always", "automatic", "never"):
                print(HELP)
                sys.exit(3)
            cfg["color"] = v
        elif a.startswith("-"):
            raise DogError(f"dog: Invalid options: Unrecognized option: '{a.lstrip('-')}'")
        else:
            plain.append(a)
        i += 1
    for a in plain:
        if a.startswith("@"):
            cfg["nameservers"].append(a[1:])
        else:
            u = a.upper()
            if u in TYPE:
                cfg["types"].append(TYPE[u])
            elif u in CLASS:
                cfg["classes"].append(CLASS[u])
            else:
                cfg["queries"].append(a)
    if not cfg["queries"]:
        print(HELP)
        sys.exit(3)
    if not cfg["types"]:
        cfg["types"] = [1]
    if not cfg["classes"]:
        cfg["classes"] = [1]
    if not cfg["nameservers"]:
        cfg["nameservers"] = system_nameservers()
    return cfg


def parse_type(v):
    u = v.upper()
    if u in TYPE:
        return TYPE[u]
    if u.startswith("TYPE") and u[4:].isdigit():
        return int(u[4:])
    if v.isdigit():
        return int(v)
    raise DogError(f'dog: Invalid options: Invalid query type "{v}"')


def parse_tweak(cfg, v):
    if v in ("aa", "ad", "cd"):
        cfg["tweaks"].add(v)
    elif v.startswith("bufsize="):
        try:
            n = int(v.split("=", 1)[1])
        except ValueError:
            raise DogError(f'dog: Invalid options: Invalid protocol tweak "{v}"')
        if not 0 <= n <= 65535:
            raise DogError(f'dog: Invalid options: Invalid protocol tweak "{v}"')
        cfg["bufsize"] = n
    else:
        raise DogError(f'dog: Invalid options: Invalid protocol tweak "{v}"')


def type_name(n):
    return RTYPE.get(n, f"TYPE{n}")


def class_name(n):
    return RCLASS.get(n, f"CLASS{n}")


def json_rr(rr):
    return {"name": rr["name"], "class": class_name(rr["class"]), "ttl": rr["ttl"],
            "type": type_name(rr["type"]), "data": rr["data"]}


def output_table(responses, cfg):
    rows = []
    for r in responses:
        for rr in r["answers"]:
            if rr["type"] == 41 and cfg["edns"] != "show":
                continue
            rows.append((type_name(rr["type"]), rr["name"], ttl_fmt(rr["ttl"], cfg["seconds"]), rr["text"]))
    if cfg["short"]:
        if rows:
            print(rows[0][3].strip('"'))
            return 0
        return 2
    if not rows:
        return 0
    w1 = max(len(r[0]) for r in rows)
    w2 = max(len(r[1]) for r in rows)
    w3 = max(len(r[2]) for r in rows)
    for t, n, ttl, val in rows:
        print(f"{t:>{w1}} {n:<{w2}} {ttl:>{w3}}   {val}")
    return 0


def output_json(responses):
    obj = {"responses": []}
    for r in responses:
        obj["responses"].append({
            "queries": [{"name": q["name"], "class": class_name(q["class"]), "type": type_name(q["type"])} for q in r["queries"]],
            "answers": [json_rr(x) for x in r["answers"]],
            "authorities": [json_rr(x) for x in r["authorities"]],
            "additionals": [json_rr(x) for x in r["additionals"]],
        })
    print(json.dumps(obj, separators=(",", ":")))
    return 0


def main(argv):
    try:
        cfg = parse_args(argv)
        responses = []
        start = time.time()
        for q in cfg["queries"]:
            for typ in cfg["types"]:
                for cls in cfg["classes"]:
                    for ns in cfg["nameservers"]:
                        txid = cfg["txid"] if cfg["txid"] is not None else random.randrange(65536)
                        pkt = build_query(q, typ, cls, txid, cfg["edns"] != "disable", cfg["tweaks"], cfg["bufsize"])
                        if os.environ.get("DOG_DEBUG"):
                            eprint(f"Sending {type_name(typ)} query for {q} to {ns}")
                        try:
                            if cfg["proto"] == "tcp":
                                data = tcp_query(pkt, ns)
                            elif cfg["proto"] == "tls":
                                data = tcp_query(pkt, ns, True)
                            elif cfg["proto"] == "https":
                                data = https_query(pkt, ns)
                            else:
                                data = udp_query(pkt, ns)
                                if len(data) >= 4 and (data[2] & 2):
                                    data = tcp_query(pkt, ns)
                        except Exception as ex:
                            raise DogError(f"Error [network]: {ex}", 1)
                        responses.append(parse_response(data))
        code = output_json(responses) if cfg["json"] else output_table(responses, cfg)
        if cfg["time"]:
            elapsed = max(0, int(round((time.time() - start) * 1000)))
            print(f"Ran in {elapsed}ms")
        return code
    except DogError as ex:
        eprint(str(ex))
        return ex.status
    except KeyboardInterrupt:
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
