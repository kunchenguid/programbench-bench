#!/usr/bin/env python3
import os, sys, struct, time, math, fnmatch, subprocess, tempfile, shutil
from pathlib import Path

VERSION='0.9.9'
AUTHOR="Ajeet D'Souza <98ajeet@gmail.com>"
URL='https://github.com/ajeetdsouza/zoxide'
ENV_LINES='''Environment variables:
  _ZO_DATA_DIR          Path for zoxide data files
  _ZO_ECHO              Print the matched directory before navigating to it when set to 1
  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded
  _ZO_FZF_OPTS          Custom flags to pass to fzf
  _ZO_MAXAGE            Maximum total age after which entries start getting deleted
  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths'''

class Entry:
    __slots__=('path','score','time')
    def __init__(self,path,score,ts=None): self.path=path; self.score=float(score); self.time=int(ts if ts is not None else time.time())

def eprint(*a): print(*a,file=sys.stderr)

def data_dir():
    d=os.environ.get('_ZO_DATA_DIR')
    if d: return d
    x=os.environ.get('XDG_DATA_HOME') or os.path.join(os.environ.get('HOME','.'),'.local','share')
    return os.path.join(x,'zoxide')

def db_path(): return os.path.join(data_dir(),'db.zo')

def load_db():
    p=db_path(); out=[]
    try: data=open(p,'rb').read()
    except FileNotFoundError: return []
    except Exception as ex: eprint(f'zoxide: could not open database: {p}\n\nCaused by:\n    {ex}'); sys.exit(1)
    try:
        off=0
        ver,=struct.unpack_from('<I',data,off); off+=4
        n,=struct.unpack_from('<Q',data,off); off+=8
        for _ in range(n):
            ln,=struct.unpack_from('<Q',data,off); off+=8
            path=data[off:off+ln].decode('utf-8','surrogateescape'); off+=ln
            score,=struct.unpack_from('<d',data,off); off+=8
            ts,=struct.unpack_from('<q',data,off); off+=8
            out.append(Entry(path,score,ts))
        return out
    except Exception as ex:
        eprint(f'zoxide: invalid database: {p}\n\nCaused by:\n    {ex}'); sys.exit(1)

def save_db(entries):
    d=data_dir(); os.makedirs(d,exist_ok=True); p=db_path(); tmp=p+'.tmp'
    b=bytearray(); b+=struct.pack('<I',3); b+=struct.pack('<Q',len(entries))
    for ent in entries:
        pb=ent.path.encode('utf-8','surrogateescape')
        b+=struct.pack('<Q',len(pb)); b+=pb; b+=struct.pack('<d',float(ent.score)); b+=struct.pack('<q',int(ent.time))
    open(tmp,'wb').write(b); os.replace(tmp,p)

def norm_path(p, must_dir=True):
    if p=='--': return p
    q=os.path.abspath(os.path.expanduser(p))
    if os.environ.get('_ZO_RESOLVE_SYMLINKS')=='1': q=os.path.realpath(q)
    if must_dir and not os.path.isdir(q):
        eprint(f'zoxide: not a directory: {p}'); sys.exit(1)
    return q

def excluded(path):
    pats=os.environ.get('_ZO_EXCLUDE_DIRS')
    if pats is None: pats=os.environ.get('HOME','')
    if not pats: return False
    for pat in pats.split(os.pathsep):
        if pat and (fnmatch.fnmatch(path,pat) or path==pat.rstrip('/')): return True
    return False

def age_entries(entries):
    try: maxage=float(os.environ.get('_ZO_MAXAGE','10000'))
    except: maxage=10000.0
    total=sum(e.score for e in entries)
    if maxage>0 and total>maxage:
        f=0.9*maxage/total
        for e in entries: e.score*=f

def add_cmd(argv):
    score=1.0; paths=[]; i=0; stop=False
    while i<len(argv):
        a=argv[i]
        if not stop and a=='--': stop=True; i+=1; continue
        if not stop and a in ('-h','--help'): print_help('add'); return 0
        if not stop and a in ('-V','--version'): print('zoxide-add '+VERSION); return 0
        if not stop and a in ('-s','--score'):
            if i+1>=len(argv): eprint("error: a value is required for '--score <SCORE>'"); return 2
            try: score=float(argv[i+1])
            except Exception:
                eprint(f"error: invalid value '{argv[i+1]}' for '--score <SCORE>': invalid float literal\n\nFor more information, try '--help'."); return 2
            i+=2; continue
        paths.append(a); i+=1
    if not paths:
        eprint('error: the following required arguments were not provided:\n  <PATHS>...\n\nUsage: executable add <PATHS>...\n\nFor more information, try \'--help\'.'); return 2
    entries=load_db(); by={e.path:e for e in entries}; inc=score*4.0; now=int(time.time())
    for p in paths:
        q=norm_path(p)
        if excluded(q): continue
        if q in by: by[q].score+=inc; by[q].time=now
        else:
            ent=Entry(q,inc,now); entries.append(ent); by[q]=ent
    age_entries(entries); save_db(entries); return 0

def remove_cmd(argv):
    if any(a in ('-h','--help') for a in argv): print_help('remove'); return 0
    if any(a in ('-V','--version') for a in argv): print('zoxide-remove '+VERSION); return 0
    paths=[a for a in argv if a!='--']
    entries=load_db(); by={e.path:e for e in entries}
    ok=True
    for p in paths:
        q=os.path.abspath(os.path.expanduser(p))
        if q not in by:
            eprint(f'zoxide: path not found in database: {p}'); ok=False
        else: del by[q]
    if ok: save_db(list(by.values()))
    return 0 if ok else 1

def basename_match(path, kw):
    return kw.lower() in os.path.basename(path).lower()

def path_match(path, kw):
    p=path.lower(); k=kw.lower()
    if '/' in k: return k in p
    return basename_match(path,k)

def matches(path, kws):
    return all(path_match(path,k) for k in kws)

def rank(ent, kws):
    # zoxide sorts primarily by query match, then score, then recency. This approximation
    # intentionally favors later path components for short basename queries.
    return (ent.score, ent.time, ent.path)

def query_cmd(argv):
    show_all=False; inter=False; listmode=False; showscore=False; exclude=None; base=None; kws=[]; i=0; stop=False
    while i<len(argv):
        a=argv[i]
        if not stop and a=='--': stop=True; i+=1; continue
        if not stop and a in ('-h','--help'): print_help('query'); return 0
        if not stop and a in ('-V','--version'): print('zoxide-query '+VERSION); return 0
        if not stop and a.startswith('--') and a not in ('--all','--interactive','--list','--score','--exclude','--base-dir'):
            eprint(f"error: unexpected argument '{a}' found\n\nUsage: executable query [OPTIONS] [KEYWORDS]...\n\nFor more information, try '--help'."); return 2
        if not stop and a in ('-a','--all'): show_all=True; i+=1; continue
        if not stop and a in ('-i','--interactive'): inter=True; i+=1; continue
        if not stop and a in ('-l','--list'): listmode=True; i+=1; continue
        if not stop and a in ('-s','--score'): showscore=True; i+=1; continue
        if not stop and a.startswith('-') and len(a)>2:
            handled=True
            for ch in a[1:]:
                if ch=='a': show_all=True
                elif ch=='i': inter=True
                elif ch=='l': listmode=True
                elif ch=='s': showscore=True
                else: handled=False
            if handled: i+=1; continue
        if not stop and a=='--exclude':
            if i+1>=len(argv): eprint("error: a value is required for '--exclude <path>'"); return 2
            exclude=os.path.abspath(os.path.expanduser(argv[i+1])); i+=2; continue
        if not stop and a=='--base-dir':
            if i+1>=len(argv): eprint("error: a value is required for '--base-dir <path>'"); return 2
            base=os.path.abspath(os.path.expanduser(argv[i+1])); i+=2; continue
        kws.append(a); i+=1
    entries=[]
    for e in load_db():
        if exclude and e.path==exclude: continue
        if base and not (e.path==base or e.path.startswith(base.rstrip('/')+'/')): continue
        if not show_all and not os.path.isdir(e.path): continue
        if kws and not matches(e.path,kws): continue
        entries.append(e)
    entries.sort(key=lambda e: rank(e,kws), reverse=True)
    if inter:
        # fzf-compatible enough: fall back to best match if fzf is unavailable.
        pass
    if not entries:
        if listmode and not kws: return 0
        eprint('zoxide: no match found'); return 1
    out=entries if listmode or showscore else entries[:1]
    for e in out:
        if showscore: print(f'{e.score:6.1f} {e.path}')
        else: print(e.path)
    return 0

def import_cmd(argv):
    frm=None; merge=False; path=None; i=0
    while i<len(argv):
        a=argv[i]
        if a in ('-h','--help'): print_help('import'); return 0
        if a in ('-V','--version'): print('zoxide-import '+VERSION); return 0
        if a=='--merge': merge=True; i+=1; continue
        if a=='--from': frm=argv[i+1] if i+1<len(argv) else None; i+=2; continue
        if a.startswith('--from='): frm=a.split('=',1)[1]; i+=1; continue
        path=a; i+=1
    if frm not in ('z','autojump') or not path:
        eprint('error: the following required arguments were not provided:\n  --from <FROM>\n  <PATH>\n\nUsage: executable import --from <FROM> <PATH>\n\nFor more information, try \'--help\'.'); return 2
    try: lines=open(path,encoding='utf-8',errors='surrogateescape').read().splitlines()
    except Exception as ex:
        eprint(f'zoxide: could not open database for importing: {path}\n\nCaused by:\n    {ex}'); return 1
    entries=load_db() if merge else []
    by={e.path:e for e in entries}; now=int(time.time())
    try:
        for line in lines:
            if not line.strip(): continue
            if frm=='z':
                parts=line.rsplit('|',2)
                if len(parts)!=3: raise ValueError('invalid entry')
                p,rank_s,ts_s=parts; sc=float(rank_s)/4.0; ts=int(float(ts_s))
            else:
                # autojump stores rank first, then path, separated by whitespace.
                rank_s,p=line.split(None,1); sc=float(rank_s)/50.0; ts=now
            q=os.path.abspath(os.path.expanduser(p))
            if not os.path.isdir(q) or excluded(q): continue
            if q in by: by[q].score+=sc; by[q].time=max(by[q].time,ts)
            else:
                ent=Entry(q,sc,ts); entries.append(ent); by[q]=ent
    except Exception as ex:
        eprint(f'zoxide: import error\n\nCaused by:\n    {ex}'); return 1
    save_db(entries); return 0

def edit_cmd(argv):
    if any(a in ('-h','--help') for a in argv): print_help('edit'); return 0
    if any(a in ('-V','--version') for a in argv): print('zoxide-edit '+VERSION); return 0
    editor=os.environ.get('EDITOR') or os.environ.get('VISUAL')
    if not editor:
        eprint('zoxide: editor not set'); return 1
    entries=load_db(); fd,tmp=tempfile.mkstemp(prefix='zoxide-',suffix='.txt'); os.close(fd)
    with open(tmp,'w') as f:
        for e in sorted(entries,key=lambda x:x.path): f.write(f'{e.score}\t{e.path}\n')
    rc=subprocess.call(editor.split()+[tmp])
    if rc==0:
        new=[]
        for line in open(tmp):
            line=line.rstrip('\n')
            if not line: continue
            try: s,p=line.split(None,1); new.append(Entry(p,float(s)))
            except: pass
        save_db(new)
    os.unlink(tmp); return rc

def init_script(shell, cmd='z', hook='pwd', no_cmd=False):
    zi=cmd+'i'
    if shell in ('bash','zsh','posix'):
        lines=['# shellcheck shell=bash' if shell!='posix' else '# shellcheck shell=sh','',
'__zoxide_pwd() {\n    \\command pwd -L\n}',
'__zoxide_cd() {\n    \\command cd "$@"\n}',
'__zoxide_z() {\n    if [ "$#" -eq 0 ]; then __zoxide_cd ~;\n    elif [ "$#" -eq 1 ] && [ -d "$1" ]; then __zoxide_cd "$1";\n    elif [ "$#" -eq 1 ] && [ "$1" = "-" ]; then __zoxide_cd -;\n    else __zoxide_result="$(\\command zoxide query --exclude "$(__zoxide_pwd)" -- "$@")" && __zoxide_cd "$__zoxide_result"; fi\n}',
'__zoxide_zi() {\n    __zoxide_result="$(\\command zoxide query --interactive -- "$@")" && __zoxide_cd "$__zoxide_result"\n}']
        if hook!='none': lines.insert(3,'__zoxide_hook() { \\command zoxide add -- "$(__zoxide_pwd)"; }')
        if not no_cmd: lines += [f'{cmd}() {{ __zoxide_z "$@"; }}', f'{zi}() {{ __zoxide_zi "$@"; }}']
        return '\n\n'.join(lines)+'\n'
    if shell=='fish':
        s='function __zoxide_pwd\n    builtin pwd -L\nend\nfunction __zoxide_z\n    set -l result (command zoxide query -- $argv); and cd $result\nend\nfunction __zoxide_zi\n    set -l result (command zoxide query --interactive -- $argv); and cd $result\nend\n'
        if hook!='none': s+='function __zoxide_hook --on-variable PWD\n    command zoxide add -- (__zoxide_pwd)\nend\n'
        if not no_cmd: s+=f'alias {cmd}=__zoxide_z\nalias {zi}=__zoxide_zi\n'
        return s
    if shell=='powershell':
        s='function global:__zoxide_z { $result = zoxide query -- $args; if ($?) { Set-Location $result } }\nfunction global:__zoxide_zi { $result = zoxide query --interactive -- $args; if ($?) { Set-Location $result } }\n'
        if not no_cmd: s+=f'Set-Alias -Name {cmd} -Value __zoxide_z\nSet-Alias -Name {zi} -Value __zoxide_zi\n'
        return s
    if shell=='nushell':
        return ('' if no_cmd else f'alias {cmd} = __zoxide_z\nalias {zi} = __zoxide_zi\n')
    if shell=='elvish':
        return ('' if no_cmd else f'edit:add-var {cmd}~ $__zoxide_z~\nedit:add-var {zi}~ $__zoxide_zi~\n')
    if shell=='tcsh':
        return ('' if no_cmd else f'alias {cmd} __zoxide_z\nalias {zi} __zoxide_zi\n')
    if shell=='xonsh':
        return '# pylint: disable=missing-module-docstring\n'
    return ''

def init_cmd(argv):
    cmd='z'; hook='pwd'; no_cmd=False; shell=None; i=0
    shells='bash elvish fish nushell posix powershell tcsh xonsh zsh'.split(); hooks='none prompt pwd'.split()
    while i<len(argv):
        a=argv[i]
        if a in ('-h','--help'): print_help('init'); return 0
        if a in ('-V','--version'): print('zoxide-init '+VERSION); return 0
        if a=='--no-cmd': no_cmd=True; i+=1; continue
        if a=='--cmd': cmd=argv[i+1]; i+=2; continue
        if a.startswith('--cmd='): cmd=a.split('=',1)[1]; i+=1; continue
        if a=='--hook': hook=argv[i+1]; i+=2; continue
        if a.startswith('--hook='): hook=a.split('=',1)[1]; i+=1; continue
        shell=a; i+=1
    if shell not in shells:
        eprint(f"error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nFor more information, try '--help'."); return 2
    if hook not in hooks:
        eprint(f"error: invalid value '{hook}' for '--hook <HOOK>'\n  [possible values: none, prompt, pwd]\n\nFor more information, try '--help'."); return 2
    sys.stdout.write(init_script(shell,cmd,hook,no_cmd)); return 0

def print_help(cmd=None):
    if cmd is None:
        print(f'''zoxide {VERSION}\n{AUTHOR}\n{URL}\n\nA smarter cd command for your terminal\n\nUsage:\n  executable <COMMAND>\n\nCommands:\n  add     Add a new directory or increment its rank\n  edit    Edit the database\n  import  Import entries from another application\n  init    Generate shell configuration\n  query   Search for a directory in the database\n  remove  Remove a directory from the database\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n\n{ENV_LINES}''')
    else:
        desc={'add':'Add a new directory or increment its rank','edit':'Edit the database','import':'Import entries from another application','init':'Generate shell configuration','query':'Search for a directory in the database','remove':'Remove a directory from the database'}[cmd]
        usages={'add':'executable add [OPTIONS] <PATHS>...','edit':'executable edit','import':'executable import [OPTIONS] --from <FROM> <PATH>','init':'executable init [OPTIONS] <SHELL>','query':'executable query [OPTIONS] [KEYWORDS]...','remove':'executable remove [PATHS]...'}
        print(f'zoxide-{cmd} {VERSION}\n{AUTHOR}\n{URL}\n\n{desc}\n\nUsage:\n  {usages[cmd]}')
        if cmd=='add':
            print('\nArguments:\n  <PATHS>...  \n\nOptions:\n  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn\'t\n  -h, --help           Print help\n  -V, --version        Print version')
        elif cmd=='import':
            print('\nArguments:\n  <PATH>  \n\nOptions:\n      --from <FROM>  Application to import from [possible values: autojump, z]\n      --merge        Merge into existing database\n  -h, --help         Print help\n  -V, --version      Print version')
        elif cmd=='init':
            print('\nArguments:\n  <SHELL>  [possible values: bash, elvish, fish, nushell, posix, powershell, tcsh, xonsh, zsh]\n\nOptions:\n      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands\n      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]\n      --hook <HOOK>  Changes how often zoxide increments a directory\'s score [default: pwd] [possible values: none, prompt, pwd]\n  -h, --help         Print help\n  -V, --version      Print version')
        elif cmd=='query':
            print('\nArguments:\n  [KEYWORDS]...  \n\nOptions:\n  -a, --all              Show unavailable directories\n  -i, --interactive      Use interactive selection\n  -l, --list             List all matching directories\n  -s, --score            Print score with results\n      --exclude <path>   Exclude the current directory\n      --base-dir <path>  Only search within this directory\n  -h, --help             Print help\n  -V, --version          Print version')
        elif cmd=='remove':
            print('\nArguments:\n  [PATHS]...  \n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version')
        else:
            print('\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version')
        print('\n'+ENV_LINES)

def main():
    argv=sys.argv[1:]
    if not argv or argv[0] in ('-h','--help'): print_help(); return 0
    if argv[0] in ('-V','--version'): print('zoxide '+VERSION); return 0
    cmd=argv[0]; rest=argv[1:]
    if cmd=='add': return add_cmd(rest)
    if cmd=='remove': return remove_cmd(rest)
    if cmd=='query': return query_cmd(rest)
    if cmd=='import': return import_cmd(rest)
    if cmd=='edit': return edit_cmd(rest)
    if cmd=='init': return init_cmd(rest)
    eprint(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'."); return 2
if __name__=='__main__': sys.exit(main())
