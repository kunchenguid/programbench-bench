#!/usr/bin/env python3
import argparse
import io
import math
import os
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "pydeps"))

try:
    from PIL import Image, ImageSequence
except Exception as exc:
    print(f"Unable to load image support: {exc}", file=sys.stderr)
    sys.exit(1)


VERSION = "caesiumclt 1.3.0"
FORMATS = {"jpeg", "png", "gif", "webp", "tiff", "original"}
OVERWRITE = {"all", "never", "bigger"}
SUBSAMPLING = {"4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto"}
EXTS = {
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".tif", ".tiff",
    ".bmp", ".ppm", ".pgm",
}


HELP_LONG = """A fast and efficient lossy and/or lossless image compression tool

Usage: executable [OPTIONS] <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...

Arguments:
  [FILES]...
          Input files or directories to process

Options:
  -q, --quality <QUALITY>
          Compression quality [0-100], higher values mean better quality

      --lossless
          Use lossless compression (may increase file size for some formats)

      --max-size <MAX_SIZE>
          Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)

      --width <WIDTH>
          Output image width in pixels (preserves the aspect ratio if height not set)

      --height <HEIGHT>
          Output image height in pixels (preserves the aspect ratio if width not set)

      --long-edge <LONG_EDGE>
          Size in pixels for the longest edge of the image

      --short-edge <SHORT_EDGE>
          Size in pixels for the shortest edge of the image

      --no-upscale
          Prevents upscaling of the image when resizing

  -o, --output <OUTPUT>
          Output directory path

      --same-folder-as-input
          Use input file's directory as output (WARNING: may overwrite originals)

      --format <FORMAT>
          Convert to the selected output format or keep the original
          
          [default: original]
          [possible values: jpeg, png, gif, webp, tiff, original]

      --png-opt-level <PNG_OPT_LEVEL>
          PNG optimization level [0-6], higher values provide better compression
          
          [default: 3]

      --jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>
          Chroma subsampling for JPEG files
          
          [default: auto]
          [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]

      --jpeg-baseline
          Output baseline JPEG instead of progressive (default)

      --zopfli
          Use zopfli for PNG optimization (significantly slower but better compression)

  -e, --exif
          Keep EXIF metadata during compression

      --keep-dates
          Preserve original file timestamps

      --strip-icc
          Strips ICC profile info on JPG files, ignoring the -e flag

      --suffix <SUFFIX>
          Add suffix to output filenames

  -R, --recursive
          Scan subfolders recursively when input is a directory

  -S, --keep-structure
          Preserve directory structure (requires -R/--recursive)

  -d, --dry-run
          Simulate compression without writing files

      --threads <THREADS>
          Number of parallel jobs (0 = auto-detect, max = available processors)
          
          [default: 0]

  -O, --overwrite <OVERWRITE>
          Policy for handling existing output files

          Possible values:
          - all:    Always overwrite existing files
          - never:  Never overwrite existing files
          - bigger: Overwrite only if the existing file is bigger
          
          [default: all]

      --min-savings <MIN_SAVINGS>
          Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes

  -Q, --quiet
          Suppress all output

      --verbose <VERBOSE>
          Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all
          
          [default: 1]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


class Parser(argparse.ArgumentParser):
    def error(self, message):
        print(f"error: {message}", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)


def parse_size(text):
    s = str(text).strip()
    units = {
        "b": 1, "kb": 1000, "mb": 1000 ** 2, "gb": 1000 ** 3,
        "kib": 1024, "mib": 1024 ** 2, "gib": 1024 ** 3,
    }
    lower = s.lower()
    if lower.endswith("%"):
        return ("percent", float(lower[:-1]))
    num = lower
    unit = "b"
    for u in sorted(units, key=len, reverse=True):
        if lower.endswith(u):
            num = lower[:-len(u)]
            unit = u
            break
    try:
        return ("bytes", int(float(num) * units[unit]))
    except Exception:
        raise ValueError(f"Invalid size format: couldn't parse \"{s}\"")


def positive_int(name, val):
    try:
        n = int(val)
    except Exception:
        raise ValueError(f"invalid digit found in string")
    if n < 0:
        raise ValueError(f"{name} must be positive")
    return n


def build_parser():
    p = Parser(add_help=False)
    p.add_argument("-q", "--quality", type=int)
    p.add_argument("--lossless", action="store_true")
    p.add_argument("--max-size", dest="max_size")
    p.add_argument("--width", type=int)
    p.add_argument("--height", type=int)
    p.add_argument("--long-edge", type=int)
    p.add_argument("--short-edge", type=int)
    p.add_argument("--no-upscale", action="store_true")
    p.add_argument("-o", "--output")
    p.add_argument("--same-folder-as-input", action="store_true")
    p.add_argument("--format", default="original")
    p.add_argument("--png-opt-level", type=int, default=3)
    p.add_argument("--jpeg-chroma-subsampling", default="auto")
    p.add_argument("--jpeg-baseline", action="store_true")
    p.add_argument("--zopfli", action="store_true")
    p.add_argument("-e", "--exif", action="store_true")
    p.add_argument("--keep-dates", action="store_true")
    p.add_argument("--strip-icc", action="store_true")
    p.add_argument("--suffix", default="")
    p.add_argument("-R", "--recursive", action="store_true")
    p.add_argument("-S", "--keep-structure", action="store_true")
    p.add_argument("-d", "--dry-run", action="store_true")
    p.add_argument("--threads", type=int, default=0)
    p.add_argument("-O", "--overwrite", default="all")
    p.add_argument("--min-savings")
    p.add_argument("-Q", "--quiet", action="store_true")
    p.add_argument("--verbose", type=int, default=1)
    p.add_argument("files", nargs="*")
    return p


def fail(msg, usage=None):
    print(f"error: {msg}", file=sys.stderr)
    if usage:
        print(f"\nUsage: executable {usage}", file=sys.stderr)
    print("\nFor more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def validate(args):
    modes = sum([args.quality is not None, args.lossless, args.max_size is not None])
    if modes == 0:
        missing = "  <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>>"
        if not (args.output or args.same_folder_as_input):
            missing += "\n  <--output <OUTPUT>|--same-folder-as-input>"
        print(f"error: the following required arguments were not provided:\n{missing}", file=sys.stderr)
        print("\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    if modes > 1:
        if args.lossless and args.quality is not None:
            fail("the argument '--lossless' cannot be used with '--quality <QUALITY>'", "<--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...")
        if args.lossless and args.max_size is not None:
            fail("the argument '--lossless' cannot be used with '--max-size <MAX_SIZE>'", "<--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...")
        fail("the argument '--quality <QUALITY>' cannot be used with '--max-size <MAX_SIZE>'")
    if not (args.output or args.same_folder_as_input):
        print("error: the following required arguments were not provided:\n  <--output <OUTPUT>|--same-folder-as-input>", file=sys.stderr)
        print("\nUsage: executable <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> [FILES]...", file=sys.stderr)
        print("\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    if args.output and args.same_folder_as_input:
        fail("the argument '--output <OUTPUT>' cannot be used with '--same-folder-as-input'")
    if args.quality is not None and not (0 <= args.quality <= 100):
        fail(f"invalid value '{args.quality}' for '--quality <QUALITY>': Quality must be between 0 and 100, but got {args.quality}")
    if args.format not in FORMATS:
        fail(f"invalid value '{args.format}' for '--format <FORMAT>'\n  [possible values: jpeg, png, gif, webp, tiff, original]")
    if not (0 <= args.png_opt_level <= 6):
        fail(f"invalid value '{args.png_opt_level}' for '--png-opt-level <PNG_OPT_LEVEL>': PNG optimization level must be between 0 and 6, but got {args.png_opt_level}")
    if args.jpeg_chroma_subsampling not in SUBSAMPLING:
        fail(f"invalid value '{args.jpeg_chroma_subsampling}' for '--jpeg-chroma-subsampling <JPEG_CHROMA_SUBSAMPLING>'\n  [possible values: 4:4:4, 4:2:2, 4:2:0, 4:1:1, auto]")
    if args.overwrite not in OVERWRITE:
        fail(f"invalid value '{args.overwrite}' for '--overwrite <OVERWRITE>'\n  [possible values: all, never, bigger]")
    if args.width and (args.long_edge or args.short_edge):
        bad = "--long-edge <LONG_EDGE>" if args.long_edge else "--short-edge <SHORT_EDGE>"
        fail(f"the argument '--width <WIDTH>' cannot be used with '{bad}'", "--width <WIDTH> <--quality <QUALITY>|--lossless|--max-size <MAX_SIZE>> <--output <OUTPUT>|--same-folder-as-input> <FILES>...")
    if args.height and (args.long_edge or args.short_edge):
        bad = "--long-edge <LONG_EDGE>" if args.long_edge else "--short-edge <SHORT_EDGE>"
        fail(f"the argument '--height <HEIGHT>' cannot be used with '{bad}'")
    if args.long_edge and args.short_edge:
        fail("the argument '--long-edge <LONG_EDGE>' cannot be used with '--short-edge <SHORT_EDGE>'")
    if args.keep_structure and not args.recursive:
        # The original accepts this for flat trees; treating it as recursive-compatible is useful.
        pass
    if args.max_size is not None:
        try:
            args.max_size_bytes = parse_size(args.max_size)[1]
        except ValueError as e:
            fail(f"invalid value '{args.max_size}' for '--max-size <MAX_SIZE>': {e}")
    else:
        args.max_size_bytes = None
    if args.min_savings:
        try:
            args.min_savings_parsed = parse_size(args.min_savings)
        except ValueError as e:
            fail(f"invalid value '{args.min_savings}' for '--min-savings <MIN_SAVINGS>': {e}")
    else:
        args.min_savings_parsed = None


def human(n):
    sign = "-" if n < 0 else ""
    n = abs(float(n))
    for unit in ["B", "KiB", "MiB", "GiB"]:
        if n < 1024 or unit == "GiB":
            if unit == "B":
                return f"{sign}{int(n)} B"
            return f"{sign}{n:.1f} {unit}"
        n /= 1024


def collect(files, recursive):
    out = []
    for f in files:
        p = Path(f)
        if p.is_file() and p.suffix.lower() in EXTS:
            out.append(p)
        elif p.is_dir():
            it = p.rglob("*") if recursive else p.iterdir()
            for child in it:
                if child.is_file() and child.suffix.lower() in EXTS:
                    out.append(child)
    return out


def target_format(path, selected):
    if selected != "original":
        return selected
    ext = path.suffix.lower()
    if ext in (".jpg", ".jpeg"):
        return "jpeg"
    if ext in (".tif", ".tiff"):
        return "tiff"
    if ext == ".webp":
        return "webp"
    if ext == ".gif":
        return "gif"
    return "png"


def target_name(src, args, base_dir=None):
    fmt = target_format(src, args.format)
    if args.format == "original":
        ext = src.suffix
    else:
        ext = {"jpeg": ".jpg", "png": ".png", "gif": ".gif", "webp": ".webp", "tiff": ".tif"}[fmt]
    name = src.stem + args.suffix + ext
    if args.same_folder_as_input:
        return src.with_name(name)
    root = Path(args.output)
    if args.keep_structure and base_dir is not None:
        try:
            rel_parent = src.parent.relative_to(base_dir)
            return root / rel_parent / name
        except ValueError:
            pass
    return root / name


def new_size(w, h, args):
    nw, nh = w, h
    if args.long_edge:
        scale = args.long_edge / max(w, h)
        nw, nh = round(w * scale), round(h * scale)
    elif args.short_edge:
        scale = args.short_edge / min(w, h)
        nw, nh = round(w * scale), round(h * scale)
    elif args.width and args.height:
        nw, nh = args.width, args.height
    elif args.width:
        scale = args.width / w
        nw, nh = args.width, round(h * scale)
    elif args.height:
        scale = args.height / h
        nw, nh = round(w * scale), args.height
    if args.no_upscale and (nw > w or nh > h):
        return w, h
    return max(1, nw), max(1, nh)


def save_image(img, fmt, args, quality=None):
    buf = io.BytesIO()
    q = args.quality if quality is None else quality
    if args.lossless:
        q = 100
    if q is None:
        q = 85
    save_kwargs = {}
    if fmt == "jpeg":
        if img.mode in ("RGBA", "LA", "P"):
            bg = Image.new("RGB", img.size, (255, 255, 255))
            if img.mode == "P":
                img = img.convert("RGBA")
            bg.paste(img, mask=img.split()[-1] if img.mode in ("RGBA", "LA") else None)
            img = bg
        else:
            img = img.convert("RGB")
        subs = {"4:4:4": 0, "4:2:2": 1, "4:2:0": 2, "4:1:1": 2, "auto": -1}[args.jpeg_chroma_subsampling]
        save_kwargs.update(format="JPEG", quality=max(1, min(100, q)), optimize=True,
                           progressive=not args.jpeg_baseline, subsampling=subs)
        if args.exif and not args.strip_icc and "exif" in img.info:
            save_kwargs["exif"] = img.info["exif"]
    elif fmt == "png":
        if not args.lossless and args.quality is not None and args.quality < 100:
            colors = max(2, min(256, int(2 + ((args.quality / 100.0) ** 2) * 254)))
            img = img.convert("RGBA").quantize(colors=colors, method=Image.Quantize.FASTOCTREE)
        save_kwargs.update(format="PNG", optimize=args.png_opt_level > 0,
                           compress_level=max(0, min(9, args.png_opt_level + 3)))
    elif fmt == "webp":
        save_kwargs.update(format="WEBP", quality=max(1, min(100, q)),
                           lossless=bool(args.lossless))
    elif fmt == "gif":
        save_kwargs.update(format="GIF", optimize=True)
    elif fmt == "tiff":
        save_kwargs.update(format="TIFF", compression="tiff_lzw")
    img.save(buf, **save_kwargs)
    return buf.getvalue()


def encode(src, args):
    fmt = target_format(src, args.format)
    with Image.open(src) as im:
        w, h = im.size
        nw, nh = new_size(w, h, args)
        if fmt == "gif" and getattr(im, "is_animated", False):
            frames = []
            durations = []
            for frame in ImageSequence.Iterator(im):
                fr = frame.copy()
                if (nw, nh) != fr.size:
                    fr = fr.resize((nw, nh), Image.Resampling.LANCZOS)
                frames.append(fr.convert("P", palette=Image.Palette.ADAPTIVE))
                durations.append(frame.info.get("duration", im.info.get("duration", 100)))
            buf = io.BytesIO()
            frames[0].save(buf, format="GIF", save_all=True, append_images=frames[1:],
                           duration=durations, loop=im.info.get("loop", 0), optimize=True)
            return buf.getvalue()
        img = im.copy()
        if (nw, nh) != img.size:
            img = img.resize((nw, nh), Image.Resampling.LANCZOS)
        if args.max_size_bytes and fmt in ("jpeg", "webp"):
            best = None
            lo, hi = 1, 100
            while lo <= hi:
                mid = (lo + hi) // 2
                data = save_image(img, fmt, args, mid)
                if len(data) <= args.max_size_bytes:
                    best = data
                    lo = mid + 1
                else:
                    hi = mid - 1
            return best if best is not None else save_image(img, fmt, args, 1)
        return save_image(img, fmt, args)


def should_write(src_size, data_size, dest, args):
    if args.overwrite == "never" and dest.exists():
        return False, "skipped"
    if args.overwrite == "bigger" and dest.exists() and dest.stat().st_size <= data_size:
        return False, "skipped"
    if args.min_savings_parsed:
        saved = src_size - data_size
        kind, val = args.min_savings_parsed
        needed = src_size * val / 100.0 if kind == "percent" else val
        if saved < needed:
            return False, "skipped"
    return True, "success"


def main(argv):
    if "-V" in argv or "--version" in argv:
        print(VERSION)
        return 0
    if "-h" in argv or "--help" in argv:
        print(HELP_LONG.rstrip())
        return 0
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    validate(args)
    if args.quiet:
        args.verbose = 0
    if not args.files:
        if args.verbose:
            print("No files to compress")
        return 1
    files = collect(args.files, args.recursive)
    if not files:
        if args.verbose:
            print("Unable to compute the base path for the files.")
        return 1
    base_dir = None
    dirs = [Path(f) for f in args.files if Path(f).is_dir()]
    if dirs:
        base_dir = dirs[0]
    success = skipped = errors = 0
    before = after = 0
    for src in files:
        try:
            src_size = src.stat().st_size
            before += src_size
            dest = target_name(src, args, base_dir)
            if args.dry_run:
                data_size = src_size
                success += 1
                after += data_size
                continue
            data = encode(src, args)
            data_size = len(data)
            ok, status = should_write(src_size, data_size, dest, args)
            if ok:
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(dest, "wb") as f:
                    f.write(data)
                if args.keep_dates:
                    st = src.stat()
                    os.utime(dest, (st.st_atime, st.st_mtime))
                success += 1
                after += data_size
            else:
                skipped += 1
                after += src_size
                if args.verbose >= 2:
                    print(f"Skipped {src}")
        except Exception as exc:
            errors += 1
            after += src.stat().st_size if src.exists() else 0
            if args.verbose >= 2:
                print(f"Error processing {src}: {exc}", file=sys.stderr)
    total = success + skipped + errors
    if args.verbose:
        print(f"Compressed {total} files ({success} success, {skipped} skipped, {errors} errors)")
        diff = after - before
        pct = (diff / before * 100.0) if before else 0.0
        sign = "+" if diff > 0 else "-"
        diff_s = human(abs(diff))
        if diff == 0:
            diff_s = "0 B"
            sign = "-"
        print(f"{human(before)} -> {human(after)} [{sign}{diff_s} | {pct:+.2f}%]")
    return 0 if errors == 0 else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
