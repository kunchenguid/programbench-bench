#!/usr/bin/env python3
import difflib
import re
import sys

VERSION = "diffr 0.1.5"

HELP = """diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
"""

RESET = "\033[0m"
FACES = ("added", "removed", "refine-added", "refine-removed")
NAMED = {
    "black": 0, "red": 1, "green": 2, "yellow": 3,
    "blue": 4, "magenta": 5, "cyan": 6, "white": 7,
}


class Face:
    def __init__(self, fg=None, bg=None, bold=False, intense=False, underline=False, italic=False):
        self.fg = fg
        self.bg = bg
        self.bold = bold
        self.intense = intense
        self.underline = underline
        self.italic = italic

    def copy(self):
        return Face(self.fg, self.bg, self.bold, self.intense, self.underline, self.italic)

    def clear(self):
        self.fg = self.bg = None
        self.bold = self.intense = self.underline = self.italic = False

    def ansi(self):
        parts = []
        if self.bold:
            parts.append("\033[1m")
        if self.italic:
            parts.append("\033[3m")
        if self.underline:
            parts.append("\033[4m")
        if self.intense:
            parts.append("\033[1m")
        if self.fg is not None:
            parts.append(color_code(self.fg, True))
        if self.bg is not None:
            parts.append(color_code(self.bg, False))
        return "".join(parts)


def color_code(c, fg):
    base = 38 if fg else 48
    if isinstance(c, tuple):
        return f"\033[{base};2;{c[0]};{c[1]};{c[2]}m"
    if c < 8:
        return f"\033[{(30 if fg else 40) + c}m"
    return f"\033[{base};5;{c}m"


def default_faces():
    return {
        "added": Face(fg=NAMED["green"]),
        "removed": Face(fg=NAMED["red"]),
        "refine-added": Face(fg=(255, 255, 255), bg=NAMED["green"], bold=True),
        "refine-removed": Face(fg=(255, 255, 255), bg=NAMED["red"], bold=True),
    }


def fail(msg, code=255):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse_color(text):
    if text == "none":
        return None
    if text in NAMED:
        return NAMED[text]
    if "," in text:
        vals = text.split(",")
        if len(vals) != 3:
            fail(f"unexpected color: '{text}'")
        try:
            rgb = tuple(int(v) for v in vals)
        except ValueError:
            fail(f"unexpected color: '{text}'")
        if any(v < 0 or v > 255 for v in rgb):
            fail(f"unexpected color: '{text}'")
        return rgb
    try:
        n = int(text)
    except ValueError:
        fail(f"unexpected color: '{text}'")
    if n < 0 or n > 255:
        fail(f"unexpected color: '{text}'")
    return n


def apply_color_spec(spec, faces):
    parts = spec.split(":")
    face = parts[0]
    if face not in FACES:
        fail(f"unexpected face name: got '{face}', expected added|refine-added|removed|refine-removed")
    if len(parts) == 1:
        fail(f"empty attributes for face '{face}'")
    f = faces[face]
    i = 1
    while i < len(parts):
        p = parts[i]
        if p == "none":
            f.clear()
            i += 1
        elif p in ("foreground", "background"):
            if i + 1 >= len(parts):
                fail(f"missing color after '{p}'")
            val = parse_color(parts[i + 1])
            if p == "foreground":
                f.fg = val
            else:
                f.bg = val
            i += 2
        else:
            neg = p.startswith("no")
            name = p[2:] if neg else p
            if name not in ("italic", "bold", "intense", "underline"):
                fail(f"unexpected attribute: '{p}'")
            setattr(f, name, not neg)
            i += 1


def parse_args(argv):
    faces = default_faces()
    line_numbers = None
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            sys.stdout.write(HELP)
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a == "--colors":
            if i + 1 >= len(argv):
                print("option requires an argument: '--colors'", file=sys.stderr)
                sys.exit(2)
            i += 1
            apply_color_spec(argv[i], faces)
        elif a == "--line-numbers":
            if i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
                style = argv[i]
                if style not in ("compact", "aligned", "fixed"):
                    fail(f"unexpected line number style: got '{style}', expected aligned|compact|fixed")
                line_numbers = style
            else:
                line_numbers = "compact"
        else:
            print(f"bad argument: '{a}'", file=sys.stderr)
            sys.stderr.write(HELP)
            sys.exit(2)
        i += 1
    return faces, line_numbers


TOKEN_RE = re.compile(r"[A-Za-z0-9_]+|\s+|.")
HUNK_RE = re.compile(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@")


def split_keep_newline(line):
    if line.endswith("\n"):
        return line[:-1], "\n"
    return line, ""


def tokens(s):
    return TOKEN_RE.findall(s)


def render_refined(text, peer, common_face, refine_face):
    ts = tokens(text)
    ps = tokens(peer)
    out = []
    sm = difflib.SequenceMatcher(None, ts, ps, autojunk=False)
    for tag, i1, i2, _j1, _j2 in sm.get_opcodes():
        seg = "".join(ts[i1:i2])
        if not seg:
            continue
        if tag == "equal":
            out.append(common_face.ansi() + seg + RESET)
        else:
            out.append(refine_face.ansi() + seg + RESET)
    return "".join(out)


def similarity(a, b):
    return difflib.SequenceMatcher(None, tokens(a), tokens(b), autojunk=False).ratio()


def pair_changes(lines):
    removed = [(i, line[1:]) for i, line in enumerate(lines) if line.startswith("-")]
    added = [(i, line[1:]) for i, line in enumerate(lines) if line.startswith("+")]
    pairs = {}
    used_add = set()
    candidates = []
    for ri, rt in removed:
        for ai, at in added:
            candidates.append((similarity(rt, at), ri, ai))
    for score, ri, ai in sorted(candidates, reverse=True):
        if score <= 0.34 or ri in pairs or ai in used_add:
            continue
        pairs[ri] = ai
        pairs[ai] = ri
        used_add.add(ai)
    return pairs


def number_prefix(kind, oldno, newno, style, face):
    if style is None:
        return ""
    if kind == "-":
        raw = f"{oldno}  "
        colored = face.ansi() + raw + RESET
    elif kind == "+":
        raw = f"  {newno}"
        colored = face.ansi() + raw + RESET
    else:
        colored = f"  {newno}"
    if style == "aligned":
        return colored + "\t"
    return colored


def render_line(line, faces, peer=None, oldno=None, newno=None, number_style=None):
    body, nl = split_keep_newline(line)
    if body.startswith("-") and not body.startswith("---"):
        face = faces["removed"]
        prefix = number_prefix("-", oldno, newno, number_style, face)
        text = body[1:]
        if peer is None:
            content = faces["refine-removed"].ansi() + text + RESET
        else:
            content = render_refined(text, peer[1:], face, faces["refine-removed"])
        return RESET + prefix + face.ansi() + "-" + RESET + RESET + content + face.ansi() + RESET + nl
    if body.startswith("+") and not body.startswith("+++"):
        face = faces["added"]
        prefix = number_prefix("+", oldno, newno, number_style, face)
        text = body[1:]
        if peer is None:
            content = faces["refine-added"].ansi() + text + RESET
        else:
            content = render_refined(text, peer[1:], face, faces["refine-added"])
        return RESET + prefix + face.ansi() + "+" + RESET + RESET + content + face.ansi() + RESET + nl
    if body.startswith(" "):
        prefix = number_prefix(" ", oldno, newno, number_style, faces["added"])
        return prefix + RESET + body + RESET + nl
    return RESET + body + RESET + nl


def parse_hunk_start(line):
    m = HUNK_RE.search(line)
    if not m:
        return None
    return int(m.group(1)), int(m.group(3))


def process_hunk(chunk, faces, number_style, old_start, new_start):
    pairs = pair_changes(chunk)
    out = []
    oldno = old_start
    newno = new_start
    for i, line in enumerate(chunk):
        body = line[:-1] if line.endswith("\n") else line
        peer = chunk[pairs[i]] if i in pairs else None
        if body.startswith("-") and not body.startswith("---"):
            out.append(render_line(line, faces, peer, oldno=oldno, newno=None, number_style=number_style))
            oldno += 1
        elif body.startswith("+") and not body.startswith("+++"):
            out.append(render_line(line, faces, peer, oldno=None, newno=newno, number_style=number_style))
            newno += 1
        elif body.startswith(" "):
            out.append(render_line(line, faces, None, oldno=oldno, newno=newno, number_style=number_style))
            oldno += 1
            newno += 1
        else:
            out.append(render_line(line, faces, None, number_style=None))
    return out


def main():
    faces, number_style = parse_args(sys.argv[1:])
    lines = sys.stdin.readlines()
    out = []
    hunk = []
    in_hunk = False
    old_start = new_start = 0
    for line in lines:
        starts = parse_hunk_start(line)
        if starts:
            if hunk:
                out.extend(process_hunk(hunk, faces, number_style, old_start, new_start))
                hunk = []
            in_hunk = True
            old_start, new_start = starts
            out.append(render_line(line, faces, None, number_style=None))
        elif in_hunk:
            if line.startswith((" ", "+", "-", "\\")):
                hunk.append(line)
            else:
                out.extend(process_hunk(hunk, faces, number_style, old_start, new_start))
                hunk = []
                in_hunk = False
                out.append(render_line(line, faces, None, number_style=None))
        else:
            out.append(render_line(line, faces, None, number_style=None))
    if hunk:
        out.extend(process_hunk(hunk, faces, number_style, old_start, new_start))
    sys.stdout.write("".join(out))


if __name__ == "__main__":
    main()
