#!/usr/bin/env python3
import os, sys, shutil, subprocess
from pathlib import Path

BLUE='\033[0;34m'; RED='\033[0;31m'; RESET='\033[0m'
LOGO=f"""{BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \  __/
____  / / /_/ / /_  
___  /  \____/\__/  
/___/         ᵥ₀.₁.₂  
{RESET}         

usage: jt <command>

{BLUE}commands:{RESET}

create items
    {BLUE}vault{RESET}, {BLUE}vl{RESET}       create a vault or list vaults
    create items in current folder
        {BLUE}note{RESET}, {BLUE}nt{RESET}        create a note 
        {BLUE}folder{RESET}, {BLUE}fd{RESET}      create a folder

interact with items
    {BLUE}enter{RESET}, {BLUE}en{RESET}       enter a vault
    {BLUE}open{RESET}, {BLUE}op{RESET}        open a note from current folder
    {BLUE}opdir{RESET}, {BLUE}od{RESET}       open current folder in file explorer
    {BLUE}chdir{RESET}, {BLUE}cd{RESET}       change folder within current vault
    {BLUE}list{RESET}, {BLUE}ls{RESET}        list items in current folder

perform fs operations on items
    {BLUE}remove{RESET}, {BLUE}rm{RESET}      remove an item 
    {BLUE}rename{RESET}, {BLUE}rn{RESET}      rename an item 
    {BLUE}move{RESET}, {BLUE}mv{RESET}        move an item to a new location
    {BLUE}vmove{RESET}, {BLUE}vm{RESET}       move an item to a different vault

config
    {BLUE}config{RESET}, {BLUE}cf{RESET}      display, set or open config

get help 
    use {BLUE}help{RESET} or {BLUE}-h{RESET} and {BLUE}--help{RESET} flags along with a command to get corresponding help"""

HELPS={
'vault':"""executable-vault 
create a vault or list vaults

USAGE:
    jt vault
    jt vault -l
    jt vault <vault name> <vault location>

ARGS:
    <vault name>        name for new vault
    <vault location>    absolute path to location of new vault

OPTIONS:
    -l            show vaults' location
    -h, --help    Print help information""",
'note':"""executable-note 
create a note

USAGE:
    jt note
    jt note [note name]

ARGS:
    <note name>    name for new note (to be created in the current folder)

OPTIONS:
    -h, --help    Print help information""",
'folder':"""executable-folder 
create a folder

USAGE:
    jt folder
    jt folder [folder name]

ARGS:
    <folder name>    name for new folder (to be created in the current folder)

OPTIONS:
    -h, --help    Print help information""",
'enter':"""executable-enter 
enter a vault

USAGE:
    executable enter <vault name>

ARGS:
    <vault name>    name of the vault to enter

OPTIONS:
    -h, --help    Print help information""",
'open':"""executable-open 
open a note (from the current folder)

USAGE:
    executable open <note name>

ARGS:
    <note name>    name of note to be opened

OPTIONS:
    -h, --help    Print help information""",
'opdir':"""executable-opdir 
open current folder in file explorer

USAGE:
    executable opdir

OPTIONS:
    -h, --help    Print help information""",
'chdir':"""executable-chdir 
change folder within current vault

USAGE:
    executable chdir <folder path>

ARGS:
    <folder path>    path to folder to switch to (from current folder)

OPTIONS:
    -h, --help    Print help information""",
'list':"""executable-list 
list items in current folder

USAGE:
    executable list [item type]

ARGS:
    <item type>    

OPTIONS:
    -h, --help    Print help information""",
'remove':"""executable-remove 
remove an item

USAGE:
    executable remove <item type> <name>

ARGS:
    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)
    <name>         name of item to be removed

OPTIONS:
    -h, --help    Print help information""",
'rename':"""executable-rename 
rename an item

USAGE:
    executable rename <item type> <name> <new name>

ARGS:
    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)
    <name>         name of item to be renamed
    <new name>     new name of item

OPTIONS:
    -h, --help    Print help information""",
'move':"""executable-move 
move an item

USAGE:
    executable move <item type> <name> <new location>

ARGS:
    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)
    <name>            name of item to be moved
    <new location>    path to new location of item (current folder as root in case of note or
                      folder)

OPTIONS:
    -h, --help    Print help information""",
'vmove':"""executable-vmove 
move notes and folders to a different vault

USAGE:
    executable vmove <item type> <name> <vault name>

ARGS:
    <item type>     move a note (or nt) | folder (or fd)
    <name>          name of item to be moved
    <vault name>    name of vault to move the item to

OPTIONS:
    -h, --help    Print help information""",
'config':"""executable-config 
display, set or open config

USAGE:
    jt config <config type>
    jt config <config type> [config value]

ARGS:
    <config type>     name of config item to display or set
    <config value>    pass a value if config needs to be updated

OPTIONS:
    -h, --help    Print help information"""
}
ALIASES={'vl':'vault','nt':'note','fd':'folder','en':'enter','op':'open','od':'opdir','cd':'chdir','ls':'list','rm':'remove','rn':'rename','mv':'move','vm':'vmove','cf':'config'}

def home(): return Path(os.environ.get('HOME','/tmp'))
def cfg_path(): return home()/'.config/jot/config'
def vaults_path(): return home()/'.local/share/jot/vaults'
def init_files():
    cfg_path().parent.mkdir(parents=True, exist_ok=True); vaults_path().parent.mkdir(parents=True, exist_ok=True)
    if not cfg_path().exists(): cfg_path().write_text("editor = 'nvim'\nconflict = true\n")
    if not vaults_path().exists(): vaults_path().write_text('[vaults]\n')

def parse_simple(p):
    init_files(); d={}; section=None
    for line in p.read_text().splitlines():
        s=line.strip()
        if not s: continue
        if s.startswith('['): section=s.strip('[]'); continue
        if '=' in s:
            k,v=s.split('=',1); k=k.strip(); v=v.strip()
            if v.startswith("'") and v.endswith("'"): v=v[1:-1]
            if section: d.setdefault(section,{})[k]=v
            else: d[k]=v
    return d

def write_vaults(current, vaults):
    out=[]
    if current: out.append(f"current = '{current}'\n")
    out.append('[vaults]')
    for k,v in vaults.items(): out.append(f"{k} = '{v}'")
    vaults_path().write_text('\n'.join(out)+'\n')

def get_state():
    d=parse_simple(vaults_path()); return d.get('current',''), d.get('vaults',{})
def config(): return parse_simple(cfg_path())
def write_config(c): cfg_path().write_text(f"editor = '{c.get('editor','nvim')}'\nconflict = {str(c.get('conflict','true')).lower()}\n")
def err(msg): print(f"{RED}error{RESET}: {msg}")
def blue(s): return f"{BLUE}{s}{RESET}"

def vault_root(name, loc): return Path(loc)/name
def data_path(name, loc): return vault_root(name,loc)/'.jot/data'
def read_vdata(name, loc):
    p=data_path(name,loc); folder=''
    if p.exists():
        for line in p.read_text().splitlines():
            if line.startswith('folder = '): folder=line.split('=',1)[1].strip().strip("'")
    return folder

def write_vdata(name, loc, folder=''):
    p=data_path(name,loc); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(f"name = '{name}'\nlocation = '{loc}'\nfolder = '{folder}'\nhistory = []\n")

def current_vault():
    cur, vs=get_state()
    if not cur or cur not in vs:
        err('not inside a vault'); return None
    return cur, vs[cur], read_vdata(cur,vs[cur])

def curdir():
    st=current_vault()
    if not st: return None
    name,loc,folder=st; return st, vault_root(name,loc)/folder

def note_file(base, name):
    return base/(name if name.endswith('.md') else name+'.md')

def item_path(base, typ, name):
    if typ in ('note','nt'): return note_file(base,name)
    if typ in ('folder','fd'): return base/name
    return None

def valid_type(t, vault=False):
    vals=('vault','vl','note','nt','folder','fd') if vault else ('note','nt','folder','fd')
    return t in vals

def cmd_vault(args):
    cur,vs=get_state()
    if args==['-l']:
        for k,v in reversed(list(vs.items())):
            prefix = "👉 " if k == cur else "   "
            nm = blue(k) if k == cur else k
            print(f"{prefix}{nm} \t {v}")
    elif not args:
        for k in vs: print(f"   {k}")
    elif len(args)<2:
        print('error: The following required arguments were not provided:\n    <vault location>\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nFor more information try --help', file=sys.stderr); sys.exit(2)
    else:
        name,loc=args[0],args[1]
        if not os.path.isabs(loc): err("specified path isn't absolute"); return
        if not Path(loc).exists(): err("couldn't find the path specified"); return
        if name in vs: err(f'vault {name} already exists'); return
        root=vault_root(name,loc); root.mkdir(exist_ok=True); (root/'.jot').mkdir(exist_ok=True); write_vdata(name,loc,'')
        vs[name]=loc; write_vaults(cur,vs); print(f"vault {blue(name)} created")

def cmd_enter(args):
    if len(args)<1: sys.exit(2)
    cur,vs=get_state(); name=args[0]
    if name not in vs: err(f"vault {name} doesn't exist"); return
    write_vaults(name,vs); print(f"entered {blue(name)}")

def cmd_note(args):
    if len(args)<1:
        print('error: The following required arguments were not provided:\n    <note name>\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nFor more information try --help', file=sys.stderr); sys.exit(2)
    got=curdir();
    if not got: return
    (_,_,_),base=got; base.mkdir(parents=True,exist_ok=True); p=note_file(base,args[0])
    if p.exists(): err(f'a note named {args[0]} already exists in this location'); return
    p.write_text(''); print(f"note {blue(args[0])} created")

def cmd_folder(args):
    if len(args)<1:
        print('error: The following required arguments were not provided:\n    <folder name>\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nFor more information try --help', file=sys.stderr); sys.exit(2)
    got=curdir();
    if not got: return
    (_,_,_),base=got; p=base/args[0]
    if p.exists(): err(f'a folder named {args[0]} already exists in this location'); return
    p.mkdir(parents=True); print(f"folder {blue(args[0])} created")

def tree_lines(base, prefix='', only=None):
    entries=[]
    try: raw=sorted(base.iterdir(), key=lambda p:p.name.lower())
    except FileNotFoundError: raw=[]
    for p in raw:
        if p.name=='.jot' and only!='folder': continue
        is_note=p.is_file() and p.suffix=='.md'; is_dir=p.is_dir()
        if only in ('note','nt') and not is_note: continue
        if only in ('folder','fd') and not is_dir: continue
        entries.append(p)
    lines=[]
    for i,p in enumerate(entries):
        last=i==len(entries)-1; branch='└── ' if last else '├── '
        name=p.stem if p.is_file() and p.suffix=='.md' else p.name
        text=blue(name) if p.is_file() and p.suffix=='.md' else name
        lines.append(prefix+branch+text)
        if p.is_dir() and only not in ('note','nt') and p.name!='.jot':
            lines += tree_lines(p, prefix+('    ' if last else '│   '), only)
    return lines

def cmd_list(args):
    only=args[0] if args else None
    if only and only not in ('note','nt','folder','fd'):
        print(f'error: "{only}" isn\'t a valid value for \'<item type>\'\n\t[possible values: note, nt, folder, fd]\n\nFor more information try --help', file=sys.stderr); sys.exit(2)
    got=curdir();
    if not got: return
    (name,loc,folder),base=got
    print(name + ((' > '+folder.replace('/', ' > ')) if folder else ''))
    for l in tree_lines(base, only=only): print(l)

def cmd_chdir(args):
    if len(args)<1: sys.exit(2)
    st=current_vault();
    if not st: return
    name,loc,folder=st; root=vault_root(name,loc); target=args[0]
    p=(root/target.lstrip('/')) if target.startswith('/') else (root/folder/target)
    try: p=p.resolve(); rootr=root.resolve()
    except Exception: err("couldn't find the path specified"); return
    if not p.exists() or not p.is_dir() or rootr not in [p,*p.parents]: err("couldn't find the path specified"); return
    rel='' if p==rootr else str(p.relative_to(rootr))
    write_vdata(name,loc,rel); print('folder changed')

def cmd_remove(args):
    if len(args)<2: sys.exit(2)
    typ,name=args[0],args[1]
    if not valid_type(typ, True): sys.exit(2)
    cur,vs=get_state()
    if typ in ('vault','vl'):
        if name not in vs: err(f"vault {name} doesn't exist"); return
        root=vault_root(name,vs[name]);
        if root.exists(): shutil.rmtree(root)
        del vs[name]; write_vaults('' if cur==name else cur,vs); print(f"vault {blue(name)} removed"); return
    got=curdir();
    if not got: return
    (_,_,_),base=got; p=item_path(base,typ,name)
    if not p.exists(): err('no such file or directory (os error 2)'); return
    shutil.rmtree(p) if p.is_dir() else p.unlink(); print(f"{'note' if typ in ('note','nt') else 'folder'} {blue(name)} removed")

def cmd_rename(args):
    if len(args)<3: sys.exit(2)
    typ,name,new=args[0],args[1],args[2]; cur,vs=get_state()
    if typ in ('vault','vl'):
        if name not in vs: err(f"vault {name} doesn't exist"); return
        root=vault_root(name,vs[name]); newroot=vault_root(new,vs[name]); root.rename(newroot); loc=vs[name]; del vs[name]; vs[new]=loc; write_vdata(new,loc,read_vdata(new,loc)); write_vaults(new if cur==name else cur,vs); print(f"vault {blue(name)} renamed to {blue(new)}"); return
    got=curdir();
    if not got: return
    (_,_,_),base=got; p=item_path(base,typ,name); q=item_path(base,typ,new)
    if not p.exists(): err('no such file or directory (os error 2)'); return
    p.rename(q); print(f"{'note' if typ in ('note','nt') else 'folder'} {blue(name)} renamed to {blue(new)}")

def cmd_move(args):
    if len(args)<3: sys.exit(2)
    typ,name,dest=args[0],args[1],args[2]; cur,vs=get_state()
    if typ in ('vault','vl'):
        if name not in vs: err(f"vault {name} doesn't exist"); return
        if not os.path.isabs(dest): err("specified path isn't absolute"); return
        if not Path(dest).exists(): err("couldn't find the path specified"); return
        shutil.move(str(vault_root(name,vs[name])), str(Path(dest)/name)); vs[name]=dest; write_vdata(name,dest,read_vdata(name,dest)); write_vaults(cur,vs); print(f"vault {blue(name)} moved"); return
    got=curdir();
    if not got: return
    (v,loc,folder),base=got; p=item_path(base,typ,name); root=vault_root(v,loc)
    targetdir=(root/dest.lstrip('/')) if dest.startswith('/') else (base/dest)
    if not targetdir.exists() or not targetdir.is_dir(): err("couldn't find the path specified"); return
    shutil.move(str(p), str(targetdir/p.name)); print(f"{'note' if typ in ('note','nt') else 'folder'} {blue(name)} moved")

def cmd_vmove(args):
    if len(args)<3: sys.exit(2)
    typ,name,vname=args[0],args[1],args[2]
    if typ not in ('note','nt','folder','fd'):
        print(f'error: "{typ}" isn\'t a valid value for \'<item type>\'\n\t[possible values: note, nt, folder, fd]\n\nFor more information try --help', file=sys.stderr); sys.exit(2)
    got=curdir();
    if not got: return
    cur,vs=get_state()
    if vname not in vs: err(f"vault {vname} doesn't exist"); return
    (_,_,_),base=got; p=item_path(base,typ,name); dest=vault_root(vname,vs[vname])
    try: shutil.move(str(p), str(dest/p.name)); print(f"{'note' if typ in ('note','nt') else 'folder'} {blue(name)} moved")
    except Exception as e: err(str(e))

def cmd_config(args):
    c=config()
    if not args:
        ed=c.get('editor','nvim')
        try: subprocess.call([ed, str(cfg_path())])
        except Exception: pass
        return
    if args[0] not in ('editor','conflict'):
        print(f'error: "{args[0]}" isn\'t a valid value for \'<config type>\'\n\t[possible values: editor, conflict]\n\nFor more information try --help', file=sys.stderr); sys.exit(2)
    if len(args)==1: print(f"{args[0]}: {blue(str(c.get(args[0], '')) .lower() if args[0]=='conflict' else c.get(args[0],''))}")
    else:
        c[args[0]]=args[1]; write_config(c); print(f"set {blue(args[0])} to {blue(args[1])}")

def cmd_open(args, dironly=False):
    got=curdir();
    if not got: return
    (_,_,_),base=got; c=config(); ed=c.get('editor','nvim')
    target=base if dironly else note_file(base,args[0] if args else '')
    try: subprocess.call([ed, str(target)])
    except Exception as e: err(str(e))

def main():
    init_files(); args=sys.argv[1:]
    if not args:
        print(LOGO, file=sys.stderr); sys.exit(2)
    if args[0] in ('--help','-h'):
        print(LOGO); return
    if args[0]=='help':
        if len(args)>1:
            c=ALIASES.get(args[1],args[1]); print(HELPS.get(c, LOGO))
        else: print(LOGO)
        return
    cmd=ALIASES.get(args[0],args[0]); rest=args[1:]
    if '--help' in rest or '-h' in rest:
        if cmd in HELPS: print(HELPS[cmd]); return
    if cmd not in HELPS:
        print(f"error: Found argument '{cmd}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help", file=sys.stderr); sys.exit(2)
    {'vault':cmd_vault,'enter':cmd_enter,'note':cmd_note,'folder':cmd_folder,'list':cmd_list,'chdir':cmd_chdir,'remove':cmd_remove,'rename':cmd_rename,'move':cmd_move,'vmove':cmd_vmove,'config':cmd_config,'open':cmd_open,'opdir':lambda a:cmd_open(a,True)}[cmd](rest)
if __name__=='__main__': main()
