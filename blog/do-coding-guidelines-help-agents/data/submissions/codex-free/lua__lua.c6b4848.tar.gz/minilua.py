#!/usr/bin/env python3
import sys, os, math, time, random, re

class LuaError(Exception): pass
class Return(Exception):
    def __init__(self, vals): self.vals=vals
class Break(Exception): pass

class NilType:
    def __repr__(self): return 'nil'
NIL=NilType()

def isnil(x): return x is NIL or x is None
def truthy(x): return not (x is NIL or x is None or x is False)
def lua_tostring(x):
    if x is NIL or x is None: return 'nil'
    if x is True: return 'true'
    if x is False: return 'false'
    if isinstance(x, float):
        if math.isfinite(x) and x.is_integer(): return str(int(x))
        return (('%g' % x).replace('e+0','e+').replace('e-0','e-'))
    if isinstance(x, int): return str(x)
    if isinstance(x, str): return x
    if isinstance(x, LuaTable): return f'table: 0x{id(x):x}'
    if isinstance(x, LuaFunction): return f'function: 0x{id(x):x}'
    if callable(x): return f'function: 0x{id(x):x}'
    return str(x)

def lua_type(x):
    if x is NIL or x is None: return 'nil'
    if isinstance(x, bool): return 'boolean'
    if isinstance(x, (int,float)): return 'number'
    if isinstance(x, str): return 'string'
    if isinstance(x, LuaTable): return 'table'
    if isinstance(x, LuaFunction) or callable(x): return 'function'
    return 'userdata'

def to_number(x):
    if isinstance(x,(int,float)) and not isinstance(x,bool): return x
    if isinstance(x,str):
        s=x.strip()
        try:
            if re.match(r'^[+-]?0[xX]',s): return int(s,16)
            v=float(s)
            return int(v) if v.is_integer() else v
        except Exception: return NIL
    return NIL

def num(x):
    v=to_number(x)
    if v is NIL: raise LuaError(f"attempt to perform arithmetic on a {lua_type(x)} value")
    return v

class LuaIter:
    def __init__(self, items): self.items=items
    def __iter__(self): return iter(self.items)

class LuaTable:
    def __init__(self): self.d={}
    def get(self,k): return self.d.get(k,NIL)
    def set(self,k,v):
        if v is NIL or v is None: self.d.pop(k,None)
        else: self.d[k]=v
    def length(self):
        i=1
        while self.get(i) is not NIL: i+=1
        return i-1
    def keys(self): return list(self.d.keys())

class Env:
    def __init__(self,parent=None): self.parent=parent; self.vars={}
    def get(self,k):
        if k in self.vars: return self.vars[k]
        if self.parent: return self.parent.get(k)
        return NIL
    def set_local(self,k,v): self.vars[k]=v
    def set(self,k,v):
        if k in self.vars: self.vars[k]=v
        elif self.parent: self.parent.set(k,v)
        else: self.vars[k]=v

KEY={'and','break','do','else','elseif','end','false','for','function','if','in','local','nil','not','or','repeat','return','then','true','until','while'}
class Tok:
    def __init__(self,t,v,line): self.t=t; self.v=v; self.line=line
    def __repr__(self): return f'{self.t}:{self.v}'

def lex(src):
    toks=[]; i=0; line=1; n=len(src)
    while i<n:
        c=src[i]
        if c in ' \t\r\f\v': i+=1; continue
        if c=='\n': line+=1; i+=1; continue
        if src.startswith('--[[',i):
            j=src.find(']]',i+4); block=src[i+4:j if j>=0 else n]; line+=block.count('\n'); i=(j+2 if j>=0 else n); continue
        if src.startswith('--',i):
            j=src.find('\n',i); i=n if j<0 else j; continue
        if c in '"\'':
            q=c; i+=1; out=''
            while i<n and src[i]!=q:
                if src[i]=='\\' and i+1<n:
                    i+=1; e=src[i]
                    maps={'n':'\n','t':'\t','r':'\r','\\':'\\','"':'"',"'":"'"}
                    out+=maps.get(e,e); i+=1
                else:
                    if src[i]=='\n': line+=1
                    out+=src[i]; i+=1
            i+=1; toks.append(Tok('str',out,line)); continue
        if c=='[' and src.startswith('[[',i):
            j=src.find(']]',i+2); out=src[i+2:j if j>=0 else n]; line+=out.count('\n'); i=(j+2 if j>=0 else n); toks.append(Tok('str',out,line)); continue
        if c.isdigit() or (c=='.' and i+1<n and src[i+1].isdigit()):
            j=i
            if src.startswith(('0x','0X'),i):
                j+=2
                while j<n and re.match(r'[0-9a-fA-F.]',src[j]): j+=1
                s=src[i:j]
                try: v=int(s,16)
                except Exception: v=float.fromhex(s)
            else:
                while j<n and re.match(r'[0-9.]',src[j]): j+=1
                if j<n and src[j] in 'eE':
                    j+=1
                    if j<n and src[j] in '+-': j+=1
                    while j<n and src[j].isdigit(): j+=1
                s=src[i:j]; v=float(s) if any(ch in s for ch in '.eE') else int(s)
            i=j; toks.append(Tok('num',v,line)); continue
        if c.isalpha() or c=='_':
            j=i+1
            while j<n and (src[j].isalnum() or src[j]=='_'): j+=1
            s=src[i:j]; toks.append(Tok(s if s in KEY else 'id',s,line)); i=j; continue
        three=src[i:i+3]; two=src[i:i+2]
        if three=='...': toks.append(Tok('...',three,line)); i+=3; continue
        if two in ('==','~=','<=','>=','..','//'):
            toks.append(Tok(two,two,line)); i+=2; continue
        toks.append(Tok(c,c,line)); i+=1
    toks.append(Tok('eof','eof',line)); return toks

class Parser:
    def __init__(self,toks): self.toks=toks; self.i=0
    def peek(self): return self.toks[self.i]
    def at(self,*ts): return self.peek().t in ts
    def eat(self,t=None):
        tok=self.peek()
        if t and tok.t!=t: raise LuaError(f"syntax error near '{tok.v}'")
        self.i+=1; return tok
    def block(self,stops=('eof',)):
        ss=[]
        while not self.at(*stops):
            if self.at(';'): self.eat(';'); continue
            ss.append(self.stat())
        return ss
    def stat(self):
        if self.at('local'):
            self.eat('local')
            if self.at('function'):
                self.eat('function'); name=self.eat('id').v; params,body=self.funcbody(); return ('localfunc',name,params,body)
            names=[self.eat('id').v]
            while self.at(','): self.eat(','); names.append(self.eat('id').v)
            vals=[]
            if self.at('='): self.eat('='); vals=self.explist()
            return ('local',names,vals)
        if self.at('function'):
            self.eat('function'); target=self.prefix_name(); params,body=self.funcbody(); return ('funcdef',target,params,body)
        if self.at('return'):
            self.eat('return'); vals=[] if self.at('end','else','elseif','until','eof',';') else self.explist(); return ('return',vals)
        if self.at('break'): self.eat('break'); return ('break',)
        if self.at('if'):
            self.eat('if'); branches=[]; cond=self.expr(); self.eat('then'); branches.append((cond,self.block(('elseif','else','end'))))
            while self.at('elseif'):
                self.eat('elseif'); cond=self.expr(); self.eat('then'); branches.append((cond,self.block(('elseif','else','end'))))
            els=[]
            if self.at('else'): self.eat('else'); els=self.block(('end',))
            self.eat('end'); return ('if',branches,els)
        if self.at('while'):
            self.eat('while'); cond=self.expr(); self.eat('do'); body=self.block(('end',)); self.eat('end'); return ('while',cond,body)
        if self.at('repeat'):
            self.eat('repeat'); body=self.block(('until',)); self.eat('until'); cond=self.expr(); return ('repeat',body,cond)
        if self.at('for'):
            self.eat('for'); name=self.eat('id').v
            if self.at('='):
                self.eat('='); a=self.expr(); self.eat(','); b=self.expr(); c=('num',1)
                if self.at(','): self.eat(','); c=self.expr()
                self.eat('do'); body=self.block(('end',)); self.eat('end'); return ('fornum',name,a,b,c,body)
            names=[name]
            while self.at(','): self.eat(','); names.append(self.eat('id').v)
            self.eat('in'); exps=self.explist(); self.eat('do'); body=self.block(('end',)); self.eat('end'); return ('forin',names,exps,body)
        lhs=[self.prefix()]
        if self.at('=') or self.at(','):
            while self.at(','): self.eat(','); lhs.append(self.prefix())
            self.eat('='); vals=self.explist(); return ('assign',lhs,vals)
        return ('callstat',lhs[0])
    def prefix_name(self):
        e=('var',self.eat('id').v)
        while self.at('.'):
            self.eat('.'); e=('index',e,('strlit',self.eat('id').v))
        if self.at(':'):
            self.eat(':'); e=('methodtarget',e,self.eat('id').v)
        return e
    def funcbody(self):
        self.eat('('); params=[]; vararg=False
        if not self.at(')'):
            if self.at('...'): self.eat('...'); vararg=True
            else:
                params.append(self.eat('id').v)
                while self.at(','):
                    self.eat(',')
                    if self.at('...'): self.eat('...'); vararg=True; break
                    params.append(self.eat('id').v)
        self.eat(')'); body=self.block(('end',)); self.eat('end'); return ((params,vararg),body)
    def explist(self):
        xs=[self.expr()]
        while self.at(','): self.eat(','); xs.append(self.expr())
        return xs
    def expr(self,minp=0):
        t=self.peek()
        if t.t in ('nil','false','true'): self.eat(); left=(t.t,)
        elif t.t=='num': left=('num',self.eat().v)
        elif t.t=='str': left=('strlit',self.eat().v)
        elif t.t=='...': self.eat(); left=('vararg',)
        elif t.t in ('not','#','-'):
            op=self.eat().t; left=('un',op,self.expr(9))
        elif t.t=='function': self.eat(); params,body=self.funcbody(); left=('funcexpr',params,body)
        elif t.t=='{': left=self.table()
        else: left=self.prefix()
        prec={'or':1,'and':2,'==':3,'~=':3,'<':3,'>':3,'<=':3,'>=':3,'..':4,'+':5,'-':5,'*':6,'/':6,'//':6,'%':6,'^':8}
        right_assoc={'..','^'}
        while self.peek().t in prec and prec[self.peek().t]>=minp:
            op=self.eat().t; p=prec[op]; nxt=p if op in right_assoc else p+1
            right=self.expr(nxt); left=('bin',op,left,right)
        return left
    def table(self):
        self.eat('{'); fields=[]
        while not self.at('}'):
            if self.at('['): self.eat('['); k=self.expr(); self.eat(']'); self.eat('='); v=self.expr(); fields.append((k,v))
            elif self.at('id') and self.toks[self.i+1].t=='=':
                k=('strlit',self.eat('id').v); self.eat('='); v=self.expr(); fields.append((k,v))
            else: fields.append((None,self.expr()))
            if self.at(',',';'): self.eat()
            else: break
        self.eat('}'); return ('table',fields)
    def prefix(self):
        if self.at('id'): e=('var',self.eat('id').v)
        elif self.at('('): self.eat('('); e=self.expr(); self.eat(')')
        else: raise LuaError(f"syntax error near '{self.peek().v}'")
        while True:
            if self.at('.'):
                self.eat('.'); e=('index',e,('strlit',self.eat('id').v))
            elif self.at('['):
                self.eat('['); k=self.expr(); self.eat(']'); e=('index',e,k)
            elif self.at(':'):
                self.eat(':'); name=self.eat('id').v; args=self.args(); e=('methodcall',e,name,args)
            elif self.at('(', '{', 'str'):
                args=self.args(); e=('call',e,args)
            else: break
        return e
    def args(self):
        if self.at('('):
            self.eat('('); args=[] if self.at(')') else self.explist(); self.eat(')'); return args
        if self.at('{'): return [self.table()]
        if self.at('str'): return [('strlit',self.eat('str').v)]
        raise LuaError('bad args')

def norm(vals,n):
    vals=list(vals)
    return vals[:n]+[NIL]*(n-len(vals))

class LuaFunction:
    def __init__(self,params,body,env): self.params,self.vararg=params; self.body=body; self.env=env
    def __call__(self,*args):
        e=Env(self.env)
        for i,p in enumerate(self.params): e.set_local(p,args[i] if i<len(args) else NIL)
        e.set_local('...', list(args[len(self.params):]) if self.vararg else [])
        try: exec_block(self.body,e)
        except Return as r: return r.vals
        return []

def eval_expr(e,env):
    k=e[0]
    if k=='nil': return NIL
    if k=='false': return False
    if k=='true': return True
    if k in ('num','strlit'): return e[1]
    if k=='var': return env.get(e[1])
    if k=='vararg': return env.get('...')
    if k=='un':
        op,v=e[1],eval_expr(e[2],env)
        if op=='not': return not truthy(v)
        if op=='-': return -num(v)
        if op=='#': return v.length() if isinstance(v,LuaTable) else len(v) if isinstance(v,str) else 0
    if k=='bin':
        op=e[1]
        if op=='and':
            l=eval_expr(e[2],env); return eval_expr(e[3],env) if truthy(l) else l
        if op=='or':
            l=eval_expr(e[2],env); return l if truthy(l) else eval_expr(e[3],env)
        a=eval_expr(e[2],env); b=eval_expr(e[3],env)
        if op=='+': return num(a)+num(b)
        if op=='-': return num(a)-num(b)
        if op=='*': return num(a)*num(b)
        if op=='/': return num(a)/num(b)
        if op=='//': return math.floor(num(a)/num(b))
        if op=='%': return num(a)%num(b)
        if op=='^': return num(a)**num(b)
        if op=='..': return lua_tostring(a)+lua_tostring(b)
        if op=='==': return a==b
        if op=='~=': return a!=b
        if op=='<': return a<b
        if op=='>': return a>b
        if op=='<=': return a<=b
        if op=='>=': return a>=b
    if k=='index':
        obj=eval_expr(e[1],env); key=eval_expr(e[2],env)
        if isinstance(obj,LuaTable): return obj.get(key)
        if isinstance(obj,str) and isinstance(key,str): return stringlib().get(key)
        return NIL
    if k=='table':
        t=LuaTable(); idx=1
        for ke,ve in e[1]:
            v=eval_expr(ve,env)
            if ke is None: t.set(idx,v); idx+=1
            else: t.set(eval_expr(ke,env),v)
        return t
    if k=='funcexpr': return LuaFunction(e[1],e[2],env)
    if k=='call':
        f=eval_expr(e[1],env); args=eval_list(e[2],env); return first(call(f,args))
    if k=='methodcall':
        obj=eval_expr(e[1],env); f=NIL
        if isinstance(obj,LuaTable): f=obj.get(e[2])
        elif isinstance(obj,str): f=stringlib().get(e[2])
        return first(call(f,[obj]+eval_list(e[3],env)))
    raise LuaError('unsupported expression')

def eval_list(es,env):
    out=[]
    for i,x in enumerate(es):
        if x[0]=='call' or x[0]=='methodcall' or x[0]=='vararg':
            v = env.get('...') if x[0]=='vararg' else call(eval_expr(x[1],env), eval_list(x[2],env)) if x[0]=='call' else [eval_expr(x,env)]
            if i==len(es)-1 and isinstance(v,list): out.extend(v)
            elif isinstance(v,list): out.append(v[0] if v else NIL)
            else: out.append(v)
        else: out.append(eval_expr(x,env))
    return out

def first(vals): return vals[0] if isinstance(vals,list) and vals else (vals if not isinstance(vals,list) else NIL)
def call(f,args):
    if f is NIL: raise LuaError('attempt to call a nil value')
    r=f(*args)
    return r if isinstance(r,list) else [r]

def assign_target(t,v,env):
    if t[0]=='var': env.set(t[1],v); return
    if t[0]=='index':
        obj=eval_expr(t[1],env); key=eval_expr(t[2],env)
        if not isinstance(obj,LuaTable): raise LuaError('attempt to index a non-table value')
        obj.set(key,v); return
    raise LuaError('bad assignment')

def exec_block(ss,env):
    for s in ss: exec_stat(s,env)

def exec_stat(s,env):
    k=s[0]
    if k=='local':
        vals=norm(eval_list(s[2],env),len(s[1])) if s[2] else [NIL]*len(s[1])
        for n,v in zip(s[1],vals): env.set_local(n,v)
    elif k=='localfunc': env.set_local(s[1],LuaFunction(s[2],s[3],env))
    elif k=='funcdef':
        target=s[1]; params=s[2]; body=s[3]
        if target[0]=='methodtarget':
            plist,vararg=params; fn=LuaFunction((['self']+plist,vararg),body,env)
            assign_target(('index',target[1],('strlit',target[2])),fn,env)
        else:
            assign_target(target,LuaFunction(params,body,env),env)
    elif k=='assign':
        vals=norm(eval_list(s[2],env),len(s[1]))
        for t,v in zip(s[1],vals): assign_target(t,v,env)
    elif k=='callstat': eval_expr(s[1],env)
    elif k=='return': raise Return(eval_list(s[1],env))
    elif k=='break': raise Break()
    elif k=='if':
        for c,b in s[1]:
            if truthy(eval_expr(c,env)): exec_block(b,Env(env)); return
        exec_block(s[2],Env(env))
    elif k=='while':
        while truthy(eval_expr(s[1],env)):
            try: exec_block(s[2],Env(env))
            except Break: break
    elif k=='repeat':
        while True:
            try: exec_block(s[1],Env(env))
            except Break: break
            if truthy(eval_expr(s[2],env)): break
    elif k=='fornum':
        a,b,c=num(eval_expr(s[2],env)),num(eval_expr(s[3],env)),num(eval_expr(s[4],env)); i=a
        cond=(lambda x: x<=b) if c>=0 else (lambda x: x>=b)
        while cond(i):
            e=Env(env); e.set_local(s[1],i)
            try: exec_block(s[5],e)
            except Break: break
            i+=c
    elif k=='forin':
        vals=eval_list(s[2],env); iterator=vals[0]
        for item in iterator:
            e=Env(env); arr=item if isinstance(item,(list,tuple)) else [item]
            arr=norm(arr,len(s[1]))
            for n,v in zip(s[1],arr): e.set_local(n,v)
            try: exec_block(s[3],e)
            except Break: break

def stringlib():
    t=LuaTable()
    t.set('len', lambda s: len(str(s)))
    t.set('lower', lambda s: str(s).lower())
    t.set('upper', lambda s: str(s).upper())
    t.set('sub', lambda s,i,j=None: str(s)[int(i)-1:(int(j) if j is not None and j is not NIL else len(str(s)))])
    t.set('reverse', lambda s: str(s)[::-1])
    t.set('rep', lambda s,n,sep='': str(sep).join([str(s)]*int(n)))
    t.set('find', lambda s,p,init=1,plain=False: ([str(s).find(str(p),int(init)-1)+1] if str(s).find(str(p),int(init)-1)>=0 else [NIL]))
    t.set('format', lambda fmt,*a: fmt % tuple(a))
    t.set('byte', lambda s,i=1,j=None: [ord(c) for c in str(s)[int(i)-1:(int(j) if j is not None and j is not NIL else int(i))]])
    t.set('char', lambda *a: ''.join(chr(int(x)) for x in a))
    t.set('match', lambda s,p,*a: (re.search(str(p).replace('%d','\\d').replace('%w','\\w').replace('%s','\\s'), str(s)).group(0) if re.search(str(p).replace('%d','\\d').replace('%w','\\w').replace('%s','\\s'), str(s)) else NIL))
    t.set('gsub', lambda s,p,r,n=None: [re.sub(str(p), str(r), str(s), 0 if n is None or n is NIL else int(n))])
    return t

def lua_pcall(f,*a):
    try:
        return [True]+call(f,list(a))
    except Exception as ex:
        return [False, str(ex)]

def base_env(argv):
    e=Env(); g=LuaTable(); e.set_local('_G',g); e.set_local('_VERSION','Lua 5.5')
    def setg(k,v): e.set_local(k,v); g.set(k,v)
    setg('print', lambda *a: sys.stdout.write('\t'.join(lua_tostring(x) for x in a)+'\n'))
    setg('type', lua_type); setg('tostring', lua_tostring); setg('tonumber', lambda x,base=10: (int(str(x),int(base)) if base!=10 else to_number(x)))
    setg('assert', lambda x,*m: ([x]+list(m) if truthy(x) else (_ for _ in ()).throw(LuaError(lua_tostring(m[0]) if m else 'assertion failed!'))))
    setg('error', lambda msg='': (_ for _ in ()).throw(LuaError(lua_tostring(msg))))
    setg('pcall', lua_pcall)
    setg('select', lambda w,*a: len(a) if w=='#' else list(a[int(w)-1:]))
    setg('pairs', lambda t: LuaIter([(k,t.get(k)) for k in t.keys()]) if isinstance(t,LuaTable) else LuaIter([]))
    setg('ipairs', lambda t: LuaIter([(i,t.get(i)) for i in range(1,t.length()+1)]) if isinstance(t,LuaTable) else LuaIter([]))
    setg('next', lambda t,k=NIL: next_pair(t,k))
    setg('rawget', lambda t,k: t.get(k) if isinstance(t,LuaTable) else NIL); setg('rawset', lambda t,k,v: (t.set(k,v) or t))
    mt=LuaTable(); setg('math',mt)
    for name in ['acos','asin','atan','ceil','cos','exp','floor','log','sin','sqrt','tan']:
        mt.set(name,getattr(math,name))
    mt.set('abs', abs); mt.set('max', lambda *a: max(a)); mt.set('min', lambda *a: min(a)); mt.set('deg', math.degrees); mt.set('rad', math.radians)
    mt.set('pi',math.pi); mt.set('huge',math.inf); mt.set('random', lambda a=None,b=None: random.random() if a is None or a is NIL else random.randint(1,int(a)) if b is None or b is NIL else random.randint(int(a),int(b))); mt.set('randomseed', lambda s: random.seed(s))
    st=stringlib(); setg('string',st)
    tt=LuaTable(); setg('table',tt)
    tt.set('insert', lambda t,*a: table_insert(t,*a)); tt.set('remove', lambda t,pos=NIL: table_remove(t,pos)); tt.set('concat', lambda t,sep='',i=1,j=NIL: str(sep).join(lua_tostring(t.get(k)) for k in range(int(i), (t.length() if j is NIL else int(j))+1)))
    tt.set('sort', lambda t: table_sort(t))
    ot=LuaTable(); setg('os',ot); ot.set('time', lambda *a: int(time.time())); ot.set('getenv', lambda k: os.environ.get(k,NIL)); ot.set('exit', lambda code=0: sys.exit(int(code) if code is not True else 0)); ot.set('date', lambda fmt='%c',*a: time.strftime(fmt))
    argt=LuaTable();
    if argv and isinstance(argv[0], tuple):
        for i,a in argv: argt.set(i,a)
    else:
        for i,a in enumerate(argv): argt.set(i,a)
    setg('arg',argt)
    setg('dofile', lambda path=None: (run_src(sys.stdin.read(), e) if path is None or path is NIL else run_file(path, e)))
    setg('loadfile', lambda path: (lambda *a: run_file(path,e)))
    iot=LuaTable(); setg('io',iot)
    iot.set('write', lambda *a: (sys.stdout.write(''.join(lua_tostring(x) for x in a)) or True))
    iot.set('read', lambda what='l': sys.stdin.read() if what=='a' or what=='*a' else (sys.stdin.readline().rstrip('\n') or NIL))
    setg('require', lambda mod: require_mod(mod,e))
    return e

def next_pair(t,k):
    if not isinstance(t,LuaTable): return [NIL]
    ks=t.keys(); start=0
    if k is not NIL:
        try: start=ks.index(k)+1
        except ValueError: start=len(ks)
    if start>=len(ks): return [NIL]
    kk=ks[start]; return [kk,t.get(kk)]
def table_insert(t,*a):
    if len(a)==1: pos=t.length()+1; val=a[0]
    else: pos=int(a[0]); val=a[1]
    n=t.length()
    for i in range(n+1,pos,-1): t.set(i,t.get(i-1))
    t.set(pos,val)
def table_remove(t,pos=NIL):
    pos=t.length() if pos is NIL else int(pos); v=t.get(pos); n=t.length()
    for i in range(pos,n): t.set(i,t.get(i+1))
    t.set(n,NIL); return v
def table_sort(t):
    arr=[t.get(i) for i in range(1,t.length()+1)]; arr.sort()
    for i,v in enumerate(arr,1): t.set(i,v)

def require_mod(mod,env):
    paths=[mod+'.lua', mod.replace('.','/')+'.lua']
    for p in paths:
        if os.path.exists(p):
            run_file(p,env); return True
    raise LuaError(f"module '{mod}' not found")

def run_src(src,env,name='stdin'):
    if src.startswith('#'):
        src = '\n' + src.split('\n', 1)[1] if '\n' in src else ''
    try:
        p=Parser(lex(src)); ss=p.block(); exec_block(ss,env); return 0
    except Return: return 0
    except LuaError as ex:
        sys.stderr.write(f"{sys.argv[0]}: {ex}\n"); return 1

def run_file(path,env):
    try:
        with open(path,'r') as f: src=f.read()
    except OSError as ex:
        sys.stderr.write(f"{sys.argv[0]}: cannot open {path}: {ex.strerror}\n"); return 1
    return run_src(src,env,path)

def main(argv):
    interactive=False; ignore_env=False; chunks=[]; libs=[]; script=None; sargs=[]; i=1
    while i<len(argv):
        a=argv[i]
        if a=='--': i+=1; break
        if a=='-': script='-'; i+=1; break
        if not a.startswith('-') or a=='': break
        if a=='-v': print('Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio')
        elif a=='-i': interactive=True
        elif a=='-E': ignore_env=True
        elif a=='-W': pass
        elif a=='-e': i+=1; chunks.append(argv[i])
        elif a.startswith('-e') and len(a)>2: chunks.append(a[2:])
        elif a=='-l': i+=1; libs.append(argv[i])
        elif a.startswith('-l') and len(a)>2: libs.append(a[2:])
        else:
            sys.stderr.write(f"{argv[0]}: unrecognized option '{a}'\nusage: {argv[0]} [options] [script [args]]\nAvailable options are:\n  -e stat   execute string 'stat'\n  -i        enter interactive mode after executing 'script'\n  -l mod    require library 'mod' into global 'mod'\n  -l g=mod  require library 'mod' into global 'g'\n  -v        show version information\n  -E        ignore environment variables\n  -W        turn warnings on\n  --        stop handling options\n  -         stop handling options and execute stdin\n")
            return 1
        i+=1
    if script is None and i<len(argv): script=argv[i]; sargs=argv[i+1:]
    elif script=='-': sargs=argv[i:]
    relbase = 0
    if script:
        try: relbase = argv.index(script)
        except ValueError: relbase = i-1
    argpairs=[(j-relbase,a) for j,a in enumerate(argv)]
    env=base_env(argpairs)
    for lib in libs:
        if '=' in lib: g,m=lib.split('=',1)
        else: g=m=lib
        try: env.set(g, require_mod(m,env))
        except LuaError as ex: sys.stderr.write(f"{argv[0]}: {ex}\n"); return 1
    for c in chunks:
        rc=run_src(c,env,'=(command line)')
        if rc: return rc
    if script:
        rc=run_src(sys.stdin.read(),env,'stdin') if script=='-' else run_file(script,env)
        if rc: return rc
    if interactive or (not chunks and not script and sys.stdin.isatty()):
        print('Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio')
        for line in sys.stdin:
            if line.strip() in ('quit','exit'): break
            run_src(line,env,'stdin')
    elif not chunks and not script:
        return run_src(sys.stdin.read(),env,'stdin')
    return 0
if __name__=='__main__': sys.exit(main(sys.argv))
