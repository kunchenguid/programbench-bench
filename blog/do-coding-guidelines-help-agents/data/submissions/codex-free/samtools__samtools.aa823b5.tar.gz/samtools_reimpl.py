#!/usr/bin/env python3
import gzip
import hashlib
import os
import re
import sys
from collections import OrderedDict

VERSION = "be7a51c"
HTS_VERSION = "1.23.1"

TOP_HELP = f"""
Program: samtools (Tools for alignments in the SAM format)
Version: {VERSION} (using htslib {HTS_VERSION})

Usage:   samtools <command> [options]

Commands:
  -- Indexing
     dict           create a sequence dictionary file
     faidx          index/extract FASTA
     fqidx          index/extract FASTQ
     index          index alignment

  -- Editing
     calmd          recalculate MD/NM tags and '=' bases
     fixmate        fix mate information
     reheader       replace BAM header
     targetcut      cut fosmid regions (for fosmid pool only)
     addreplacerg   adds or replaces RG tags
     markdup        mark duplicates
     ampliconclip   clip oligos from the end of reads

  -- File operations
     collate        shuffle and group alignments by name
     cat            concatenate BAMs
     consensus      produce a consensus Pileup/FASTA/FASTQ
     merge          merge sorted alignments
     mpileup        multi-way pileup
     sort           sort alignment file
     split          splits a file by read group
     quickcheck     quickly check if SAM/BAM/CRAM file appears intact
     fastq          converts a BAM to a FASTQ
     fasta          converts a BAM to a FASTA
     import         Converts FASTA or FASTQ files to SAM/BAM/CRAM
     reference      Generates a reference from aligned data
     reset          Reverts aligner changes in reads

  -- Statistics
     bedcov         read depth per BED region
     coverage       alignment depth and percent coverage
     depth          compute the depth
     flagstat       simple stats
     idxstats       BAM index stats
     cram-size      list CRAM Content-ID and Data-Series sizes
     phase          phase heterozygotes
     stats          generate stats (former bamcheck)
     ampliconstats  generate amplicon specific stats
     checksum       produce order-agnostic checksums of sequence content

  -- Viewing
     flags          explain BAM flags
     head           header viewer
     tview          text alignment viewer
     view           SAM<->BAM<->CRAM conversion
     depad          convert padded BAM to unpadded BAM
     samples        list the samples in a set of SAM/BAM/CRAM files

  -- Misc
     help [cmd]     display this help message or help for [cmd]
     version        detailed version information
"""

FLAG_INFO = [
    (0x1, "PAIRED", "paired-end / multiple-segment sequencing technology"),
    (0x2, "PROPER_PAIR", "each segment properly aligned according to aligner"),
    (0x4, "UNMAP", "segment unmapped"),
    (0x8, "MUNMAP", "next segment in the template unmapped"),
    (0x10, "REVERSE", "SEQ is reverse complemented"),
    (0x20, "MREVERSE", "SEQ of next segment in template is rev.complemented"),
    (0x40, "READ1", "the first segment in the template"),
    (0x80, "READ2", "the last segment in the template"),
    (0x100, "SECONDARY", "secondary alignment"),
    (0x200, "QCFAIL", "not passing quality controls or other filters"),
    (0x400, "DUP", "PCR or optical duplicate"),
    (0x800, "SUPPLEMENTARY", "supplementary alignment"),
]
FLAG_BY_NAME = {name: val for val, name, _ in FLAG_INFO}


def eprint(*a):
    print(*a, file=sys.stderr)


def open_text(path):
    if path == "-" or path is None:
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt", errors="replace")
    return open(path, "r", errors="replace")


def output_to(path):
    return sys.stdout if not path or path == "-" else open(path, "w")


def version():
    print(f"""samtools {VERSION}
Using htslib {HTS_VERSION}
Copyright (C) 2025 Genome Research Ltd.

Samtools compilation details:
    Features:       build=configure curses=yes 
    CC:             gcc
    CPPFLAGS:       
    CFLAGS:         -Wall -g -O2
    LDFLAGS:        
    HTSDIR:         htslib
    LIBS:           
    CURSES_LIB:     -lncursesw

HTSlib compilation details:
    Features:       build=Makefile libcurl=yes S3=no GCS=no libdeflate=no lzma=yes bzip2=yes plugins=no htscodecs=1.6.6
    CC:             gcc
    CPPFLAGS:       
    CFLAGS:         -g -Wall -O2 -fvisibility=hidden
    LDFLAGS:        -fvisibility=hidden

HTSlib URL scheme handlers present:
    built-in:\t file, preload, data
    libcurl:\t gophers, smtp, ldaps, smb, rtsp, tftp, pop3, smbs, imaps, pop3s, ftps, https, http, ftp, gopher, imap, sftp, ldap, smtps, scp, dict, mqtt, telnet, rtmp
    crypt4gh-needed:\t crypt4gh
    mem:\t mem""")


def parse_fasta(path):
    seqs = OrderedDict()
    name = None
    desc = ""
    parts = []
    with open_text(path) as fh:
        for line in fh:
            line = line.rstrip("\n\r")
            if line.startswith(">"):
                if name is not None:
                    seqs[name] = (desc, "".join(parts))
                desc = line[1:]
                name = desc.split()[0]
                parts = []
            elif name is not None:
                parts.append(line.strip())
    if name is not None:
        seqs[name] = (desc, "".join(parts))
    return seqs


def parse_fastq(path):
    reads = OrderedDict()
    with open_text(path) as fh:
        while True:
            h = fh.readline()
            if not h:
                break
            s = fh.readline()
            p = fh.readline()
            q = fh.readline()
            if not q:
                break
            desc = h.rstrip()[1:] if h.startswith("@") else h.rstrip()
            name = desc.split()[0]
            reads[name] = (desc, s.rstrip(), q.rstrip())
    return reads


def write_fai(path, fastq=False, outidx=None):
    idx = outidx or (path + ".fai")
    offset = 0
    rows = []
    with open(path, "rb") as fh:
        if fastq:
            while True:
                hpos = offset
                h = fh.readline(); offset += len(h)
                if not h: break
                s = fh.readline(); spos = offset; offset += len(s)
                p = fh.readline(); offset += len(p)
                q = fh.readline(); qpos = offset; offset += len(q)
                name = h[1:].decode(errors="replace").strip().split()[0]
                seq = s.rstrip(b"\r\n")
                rows.append(f"{name}\t{len(seq)}\t{spos}\t{len(seq)}\t{len(s)}\t{qpos}")
        else:
            name = None; length = 0; seq_offset = 0; line_bases = 0; line_width = 0
            for raw in fh:
                start = offset; offset += len(raw)
                if raw.startswith(b">"):
                    if name is not None:
                        rows.append(f"{name}\t{length}\t{seq_offset}\t{line_bases}\t{line_width}")
                    name = raw[1:].decode(errors="replace").strip().split()[0]
                    length = 0; seq_offset = offset; line_bases = 0; line_width = 0
                else:
                    bases = raw.rstrip(b"\r\n")
                    if name is not None:
                        if line_bases == 0 and len(bases) > 0:
                            line_bases = len(bases); line_width = len(raw)
                        length += len(bases)
            if name is not None:
                rows.append(f"{name}\t{length}\t{seq_offset}\t{line_bases}\t{line_width}")
    with open(idx, "w") as out:
        out.write("\n".join(rows))
        if rows:
            out.write("\n")


def parse_region(reg):
    rev = reg.endswith("-") and ":" in reg
    if rev:
        reg = reg[:-1]
    if ":" not in reg:
        return reg, None, None, rev
    name, rest = reg.rsplit(":", 1)
    rest = rest.replace(",", "")
    if "-" in rest:
        a, b = rest.split("-", 1)
        start = int(a) if a else 1
        end = int(b) if b else None
    else:
        start = int(rest); end = start
    return name, start, end, rev


def revcomp(s):
    return s.translate(str.maketrans("ACGTNacgtn", "TGCANtgcan"))[::-1]


def wrap(s, n):
    if n <= 0:
        return s + "\n"
    return "".join(s[i:i+n] + "\n" for i in range(0, len(s), n))


def cmd_faidx(argv, fastq=False):
    if not argv or "-h" in argv or "--help" in argv:
        print(("Usage: samtools fqidx <file.fq|file.fq.gz> [<reg> [...]]" if fastq else "Usage: samtools faidx <file.fa|file.fa.gz> [<reg> [...]]"))
        print("Option: \n  -o, --output FILE        Write FASTA to file.\n  -n, --length INT         Length of FASTA sequence line. [60]\n  -c, --continue           Continue after trying to retrieve missing region.\n  -r, --region-file FILE   File of regions.  Format is chr:from-to. One per line.\n  -i, --reverse-complement Reverse complement sequences.\n      --mark-strand TYPE   Add strand indicator to sequence name\n  -f, --fastq              File and index in FASTQ format.\n  -h, --help               This message.")
        return 0
    out = None; line_len = 60; cont = False; rc_all = False; region_file = None; fai_idx = None
    args = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-o","--output"): i += 1; out = argv[i]
        elif a in ("-n","--length"): i += 1; line_len = int(argv[i])
        elif a in ("-c","--continue"): cont = True
        elif a in ("-i","--reverse-complement"): rc_all = True
        elif a in ("-r","--region-file"): i += 1; region_file = argv[i]
        elif a == "--fai-idx": i += 1; fai_idx = argv[i]
        elif a == "-f": fastq = True
        elif a.startswith("-@") or a in ("--threads","--output-fmt-option","--write-index","--gzi-idx","--mark-strand"):
            if a in ("--threads","--output-fmt-option","--gzi-idx","--mark-strand") and i + 1 < len(argv): i += 1
        else: args.append(a)
        i += 1
    if not args:
        eprint("Usage: samtools faidx <file.fa|file.fa.gz> [<reg> [...]]")
        return 1
    path, regs = args[0], args[1:]
    if region_file:
        with open(region_file) as fh:
            regs += [x.strip() for x in fh if x.strip()]
    if not regs:
        write_fai(path, fastq=fastq, outidx=fai_idx)
        return 0
    data = parse_fastq(path) if fastq else parse_fasta(path)
    hout = output_to(out)
    ok = True
    for reg in regs:
        name, st, en, rev = parse_region(reg)
        if name not in data:
            eprint(f"[W::fai_get_val] Reference {name} not found in FASTA file, returning empty sequence")
            eprint(f"[faidx] Failed to fetch sequence in {reg}")
            ok = False
            if not cont: break
            continue
        if fastq:
            desc, seq, qual = data[name]
        else:
            desc, seq = data[name]
        start = 1 if st is None else max(1, st)
        end = len(seq) if en is None else min(len(seq), en)
        sub = seq[start-1:end] if end >= start else ""
        if rc_all or rev:
            sub = revcomp(sub)
            title = reg + "/rc"
        else:
            title = reg if st is not None else name
        if fastq:
            qsub = qual[start-1:end] if end >= start else ""
            if rc_all or rev:
                qsub = qsub[::-1]
            hout.write(f"@{title}\n{sub}\n+\n{qsub}\n")
        else:
            hout.write(f">{title}\n")
            hout.write(wrap(sub, line_len))
    if hout is not sys.stdout:
        hout.close()
    return 0 if ok else 1


def cmd_dict(argv):
    if not argv or "-h" in argv or "--help" in argv:
        print("\nAbout:   Create a sequence dictionary file from a fasta file\nUsage:   samtools dict [options] <file.fa|file.fa.gz>\n\nOptions: -a, --assembly STR    assembly\n         -A, --alias, --alternative-name\n                               add AN tag by adding/removing 'chr'\n         -H, --no-header       do not print @HD line\n         -l, --alt FILE        add AH:* tag to alternate locus sequences\n         -o, --output FILE     file to write out dict file [stdout]\n         -s, --species STR     species\n         -u, --uri STR         URI [file:///abs/path/to/file.fa]\n")
        return 0
    out = None; nohead = False; assembly = species = uri = None; files = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-o","--output"): i += 1; out = argv[i]
        elif a in ("-H","--no-header"): nohead = True
        elif a in ("-a","--assembly"): i += 1; assembly = argv[i]
        elif a in ("-s","--species"): i += 1; species = argv[i]
        elif a in ("-u","--uri"): i += 1; uri = argv[i]
        elif a.startswith("-"): pass
        else: files.append(a)
        i += 1
    if not files:
        eprint("Usage:   samtools dict [options] <file.fa|file.fa.gz>")
        return 1
    path = files[0]; uri = uri or ("file://" + os.path.abspath(path))
    hout = output_to(out)
    if not nohead:
        hout.write("@HD\tVN:1.0\tSO:unsorted\n")
    for name, (_, seq) in parse_fasta(path).items():
        fields = [f"@SQ", f"SN:{name}", f"LN:{len(seq)}", f"M5:{hashlib.md5(seq.upper().encode()).hexdigest()}", f"UR:{uri}"]
        if assembly: fields.append(f"AS:{assembly}")
        if species: fields.append(f"SP:{species}")
        hout.write("\t".join(fields) + "\n")
    if hout is not sys.stdout: hout.close()
    return 0


def sam_records(path):
    headers, recs = [], []
    with open_text(path) as fh:
        for line in fh:
            line = line.rstrip("\n")
            if not line: continue
            if line.startswith("@"): headers.append(line)
            else: recs.append(line)
    return headers, recs


def ref_lengths_from_header(headers):
    d = OrderedDict()
    for h in headers:
        if h.startswith("@SQ"):
            vals = {}
            for x in h.split("\t")[1:]:
                if ":" in x:
                    k, v = x.split(":", 1); vals[k] = v
            if "SN" in vals:
                d[vals["SN"]] = int(vals.get("LN", "0"))
    return d


def read_fai_lengths(path):
    d = OrderedDict()
    with open(path) as fh:
        for line in fh:
            p = line.split("\t")
            if len(p) >= 2: d[p[0]] = int(p[1])
    return d


def aln_end(pos, cigar):
    if cigar == "*": return pos
    ref = 0
    for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
        if op in "MDN=X": ref += int(n)
    return pos + max(0, ref - 1)


def rec_overlaps(rec, reg):
    name, st, en, _ = parse_region(reg)
    f = rec.split("\t")
    if len(f) < 6 or f[2] != name: return False
    if st is None: return True
    pos = int(f[3])
    end = aln_end(pos, f[5])
    return end >= st and pos <= (en if en is not None else st)


def parse_flag_value(s):
    try:
        return int(s, 0)
    except ValueError:
        v = 0
        for part in re.split(r"[,|+]+", s.upper()):
            if not part: continue
            if part not in FLAG_BY_NAME:
                raise ValueError(part)
            v |= FLAG_BY_NAME[part]
        return v


def filter_records(recs, regions=None, min_mq=None, req=0, excl=0, incl=0):
    out = []
    for r in recs:
        f = r.split("\t")
        if len(f) < 11: continue
        flag = int(f[1]); mq = int(f[4])
        if min_mq is not None and mq < min_mq: continue
        if req and (flag & req) != req: continue
        if excl and (flag & excl) != 0: continue
        if incl and (flag & incl) == 0: continue
        if regions and not any(rec_overlaps(r, x) for x in regions): continue
        out.append(r)
    return out


def norm_sam(r):
    f = r.split("\t")
    if len(f) > 9 and f[9] != "*":
        f[9] = f[9].upper()
        return "\t".join(f)
    return r


def cmd_view(argv):
    if not argv or "-?" in argv or "--help" in argv:
        print("Usage: samtools view [options] <in.bam>|<in.sam>|<in.cram> [region ...]\n\nOutput options:\n  -b, --bam                  Output BAM\n  -h, --with-header          Include header in SAM output\n  -H, --header-only          Print SAM header only (no alignments)\n  -c, --count                Print only the count of matching records\n  -o, --output FILE          Write output to FILE [standard output]\nFiltering options:\n  -q, --min-MQ INT           ...have mapping quality >= INT\n  -f, --require-flags FLAG   ...have all of the FLAGs present\n  -F, --exclude-flags FLAG   ...have none of the FLAGs present\nGeneral options:\n  -?, --help   Print long help")
        return 0
    include_header = False; header_only = False; count = False; out = None; fai = None; bamout = False
    min_mq = None; req = excl = incl = 0; no_pg = False; files = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h","--with-header"): include_header = True
        elif a in ("-H","--header-only"): header_only = True
        elif a in ("--no-header",): include_header = False
        elif a in ("-c","--count"): count = True
        elif a in ("-o","--output"): i += 1; out = argv[i]
        elif a in ("-t","--fai-reference"): i += 1; fai = argv[i]
        elif a in ("-q","--min-MQ"): i += 1; min_mq = int(argv[i])
        elif a in ("-f","--require-flags"): i += 1; req = parse_flag_value(argv[i])
        elif a in ("-F","--exclude-flags","--excl-flags"): i += 1; excl = parse_flag_value(argv[i])
        elif a in ("--rf","--incl-flags","--include-flags"): i += 1; incl = parse_flag_value(argv[i])
        elif a == "--no-PG": no_pg = True
        elif a in ("-b","-u","-1"):
            bamout = True
            include_header = True
        elif a == "-S": pass
        elif a in ("-@","-O","--output-fmt","--input-fmt-option","--output-fmt-option","-T","--reference"):
            i += 1
        elif a.startswith("-"): pass
        else: files.append(a)
        i += 1
    if not files:
        eprint("[main_samview] fail to read the header from \"-\".")
        return 1
    path, regions = files[0], files[1:]
    if regions and (path.endswith(".sam") or path.endswith(".sam.gz")):
        eprint(f"[E::idx_find_and_load] Could not retrieve index file for '{path}'")
        eprint("samtools view: Random alignment retrieval only works for indexed SAM.gz, BAM or CRAM files.")
        return 1
    headers, recs = sam_records(path)
    if not headers and fai:
        headers = [f"@SQ\tSN:{k}\tLN:{v}" for k, v in read_fai_lengths(fai).items()]
    recs = filter_records(recs, regions, min_mq, req, excl, incl)
    hout = output_to(out)
    if count:
        hout.write(str(len(recs)) + "\n")
    else:
        if include_header or header_only:
            for h in headers:
                hout.write(h + "\n")
            if not no_pg:
                hout.write(f"@PG\tID:samtools\tPN:samtools\tVN:{VERSION}\tCL:{' '.join(sys.argv)}\n")
        if not header_only:
            for r in recs:
                hout.write(norm_sam(r) + "\n")
    if hout is not sys.stdout: hout.close()
    return 0


def cmd_index(argv):
    if not argv or any(a in ("-h", "--help") for a in argv):
        print("Usage: samtools index -M [-bc] [-m INT] <in1.bam> <in2.bam>...")
        print("   or: samtools index [-bc] [-m INT] <in.bam> [out.index]")
        print("Options:\n  -b, --bai            Generate BAI-format index for BAM files [default]\n  -c, --csi            Generate CSI-format index for BAM files\n  -m, --min-shift INT  Set minimum interval size for CSI indices to 2^INT [14]\n  -M                   Interpret all filename arguments as files to be indexed\n  -o, --output FILE    Write index to FILE [alternative to <out.index> in args]\n  -@, --threads INT    Sets the number of additional threads [0]")
        return 0 if argv else 1
    multi = False; out = None; files = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-M": multi = True
        elif a in ("-o", "--output"): i += 1; out = argv[i]
        elif a in ("-m", "--min-shift", "-@","--threads"): i += 1
        elif a.startswith("-"): pass
        else: files.append(a)
        i += 1
    if not files:
        eprint("Usage: samtools index [-bc] [-m INT] <in.bam> [out.index]")
        return 1
    targets = files if multi else [files[0]]
    for f in targets:
        idx = out if out and len(targets) == 1 else (f + ".bai")
        with open(idx, "wb") as fh:
            fh.write(b"CSI\1cleanroom\n")
    return 0


def cmd_head(argv):
    nrec = 0; nhead = None; files = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-n","--records"): i += 1; nrec = int(argv[i])
        elif a in ("-h","--headers"): i += 1; nhead = int(argv[i])
        elif a.startswith("-@") or a in ("--input-fmt-option","-T","--reference","--verbosity"):
            if i + 1 < len(argv): i += 1
        elif a.startswith("-"): pass
        else: files.append(a)
        i += 1
    if not files:
        eprint("Usage: samtools head [OPTION]... [FILE]")
        return 1
    h, r = sam_records(files[0])
    for x in (h if nhead is None else h[:nhead]): print(x)
    for x in r[:nrec]: print(norm_sam(x))
    return 0


def cmd_flags(argv):
    def flag_help(file=sys.stdout):
        print("About: Convert between textual and numeric flag representation", file=file)
        print("Usage: samtools flags FLAGS...\n", file=file)
        print("Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing", file=file)
        print("a combination of the following numeric flag values, or a comma-separated string", file=file)
        print("NAME,...,NAME representing a combination of the following flag names:\n", file=file)
        for val, name, desc in FLAG_INFO:
            print(f"{val:#6x} {val:5d}  {name:<15} {desc}", file=file)
    if not argv:
        flag_help()
        return 0
    rc = 0
    for a in argv:
        try:
            v = parse_flag_value(a)
            names = ",".join(name for val, name, _ in FLAG_INFO if v & val)
            print(f"0x{v:x}\t{v}\t{names}")
        except ValueError:
            eprint(f"samtools flags: Could not parse \"{a}\"")
            flag_help(sys.stderr)
            rc = 1
    return rc


def cmd_idxstats(argv):
    files = [a for a in argv if not a.startswith("-")]
    if not files:
        eprint("Usage: samtools idxstats [options] <in.bam>")
        return 1
    h, recs = sam_records(files[-1])
    lens = ref_lengths_from_header(h)
    mapped = {k: 0 for k in lens}; unmapped = {k: 0 for k in lens}; star_un = 0
    for r in recs:
        f = r.split("\t"); 
        if len(f) < 3: continue
        flag = int(f[1]); ref = f[2]
        if ref in lens:
            if flag & 4: unmapped[ref] += 1
            else: mapped[ref] += 1
        elif flag & 4: star_un += 1
    for k, ln in lens.items():
        print(f"{k}\t{ln}\t{mapped[k]}\t{unmapped[k]}")
    print(f"*\t0\t0\t{star_un}")
    return 0


def pct(a, b):
    return "N/A" if b == 0 else f"{(100.0*a/b):.2f}%"


def cmd_flagstat(argv):
    files = [a for a in argv if not a.startswith("-")]
    if not files:
        eprint("Usage: samtools flagstat [options] <in.bam>")
        return 1
    _, recs = sam_records(files[-1])
    qc = [0, 0]
    def c(pred):
        p = f = 0
        for r in recs:
            fl = int(r.split("\t")[1]); bad = 1 if fl & 0x200 else 0
            if pred(fl):
                if bad: f += 1
                else: p += 1
        return p, f
    total = c(lambda fl: True); primary = c(lambda fl: not fl & 0x900); secondary = c(lambda fl: fl & 0x100)
    supp = c(lambda fl: fl & 0x800); dup = c(lambda fl: fl & 0x400); pdup = c(lambda fl: (fl & 0x400) and not (fl & 0x900))
    mapped = c(lambda fl: not fl & 0x4); pmapped = c(lambda fl: (not fl & 0x4) and not (fl & 0x900))
    paired = c(lambda fl: fl & 0x1); read1 = c(lambda fl: fl & 0x40); read2 = c(lambda fl: fl & 0x80)
    proper = c(lambda fl: fl & 0x2); mate_mapped = c(lambda fl: (fl & 0x1) and not (fl & 0x4) and not (fl & 0x8))
    singleton = c(lambda fl: (fl & 0x1) and not (fl & 0x4) and (fl & 0x8))
    def line(pair, text, denom=None):
        if denom is None: print(f"{pair[0]} + {pair[1]} {text}")
        else: print(f"{pair[0]} + {pair[1]} {text} ({pct(pair[0], denom[0])} : {pct(pair[1], denom[1])})")
    line(total, "in total (QC-passed reads + QC-failed reads)")
    line(primary, "primary"); line(secondary, "secondary"); line(supp, "supplementary")
    line(dup, "duplicates"); line(pdup, "primary duplicates")
    line(mapped, "mapped", total); line(pmapped, "primary mapped", primary)
    line(paired, "paired in sequencing"); line(read1, "read1"); line(read2, "read2")
    line(proper, "properly paired", paired); line(mate_mapped, "with itself and mate mapped")
    line(singleton, "singletons", paired)
    line((0,0), "with mate mapped to a different chr")
    line((0,0), "with mate mapped to a different chr (mapQ>=5)")
    return 0


def cmd_sort(argv):
    out = None; by_name = False; files = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-o": i += 1; out = argv[i]
        elif a in ("-n","-N"): by_name = True
        elif a in ("-T","-m","-l","-O","--output-fmt","--reference","-@"):
            i += 1
        elif a.startswith("-"): pass
        else: files.append(a)
        i += 1
    if not files:
        eprint("Usage: samtools sort [options...] [in.bam]")
        return 1
    h, recs = sam_records(files[0])
    if by_name:
        recs.sort(key=lambda r: r.split("\t")[0])
    else:
        order = {k:i for i,k in enumerate(ref_lengths_from_header(h).keys())}
        recs.sort(key=lambda r: (order.get(r.split("\t")[2], 10**9), int(r.split("\t")[3]) if len(r.split("\t")) > 3 and r.split("\t")[3].isdigit() else 0, r.split("\t")[0]))
    hout = output_to(out)
    for x in h: hout.write(x + "\n")
    for x in recs: hout.write(norm_sam(x) + "\n")
    if hout is not sys.stdout: hout.close()
    return 0


def cmd_quickcheck(argv):
    verbose = 0; quiet = False; files = []
    for a in argv:
        if a.startswith("-v"): verbose += a.count("v")
        elif a == "-q": quiet = True
        elif a.startswith("-"): pass
        else: files.append(a)
    ok = True
    for f in files:
        try:
            with open_text(f) as fh:
                first = fh.readline()
            good = bool(first)
        except Exception:
            good = False
        if not good:
            ok = False
            if verbose: print(f)
            if not quiet: eprint(f"{f} was not identified as sequence data.")
    return 0 if ok else 1


def cmd_depth(argv):
    out = None; allpos = False; files = []; reg = None; i = 0
    while i < len(argv):
        a = argv[i]
        if a == "-o": i += 1; out = argv[i]
        elif a == "-a": allpos = True
        elif a == "-r": i += 1; reg = argv[i]
        elif a.startswith("-"): 
            if a in ("-b","-f","-q","-Q","-l","-G","-g","--excl-flags","--incl-flags","--require-flags","-@","--reference"): i += 1
        else: files.append(a)
        i += 1
    if not files: eprint("Usage: samtools depth [options] in.bam [in.bam ...]"); return 1
    h, recs = sam_records(files[0]); lens = ref_lengths_from_header(h); counts = {}
    for r in filter_records(recs, [reg] if reg else None, None, 0, 0x704, 0):
        f = r.split("\t"); ref = f[2]; pos = int(f[3]); cigar = f[5]
        refpos = pos
        for n, op in re.findall(r"(\d+)([MIDNSHP=X])", cigar):
            n = int(n)
            if op in "M=X":
                for p in range(refpos, refpos+n): counts[(ref,p)] = counts.get((ref,p),0)+1
                refpos += n
            elif op in "DN": refpos += n
    hout = output_to(out)
    if allpos:
        for ref, ln in lens.items():
            for p in range(1, ln+1):
                if reg and not rec_overlaps(f"x\t0\t{ref}\t{p}\t0\t1M\t*\t0\t0\tA\t*", reg): continue
                hout.write(f"{ref}\t{p}\t{counts.get((ref,p),0)}\n")
    else:
        for ref in lens:
            ps = [p for (r, p) in counts if r == ref]
            if not ps:
                continue
            for p in range(min(ps), max(ps) + 1):
                hout.write(f"{ref}\t{p}\t{counts.get((ref,p),0)}\n")
        for ref, p in sorted((k for k in counts if k[0] not in lens), key=lambda x: (x[0], x[1])):
            hout.write(f"{ref}\t{p}\t{counts[(ref,p)]}\n")
    if hout is not sys.stdout: hout.close()
    return 0


def cmd_bam2fq(argv, fasta=False):
    if not argv or any(a in ("-h", "--help") for a in argv):
        print(f"Usage: samtools {'fasta' if fasta else 'fastq'} [options...] <in.bam>")
        print("  -o FILE    write reads to FILE")
        return 0 if argv else 1
    out = None; files = []; i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-o", "-0"):
            i += 1; out = argv[i]
        elif a in ("-1","-2","-s","-O","-t","-T","-@","--threads"):
            i += 1
        elif a.startswith("-"):
            pass
        else:
            files.append(a)
        i += 1
    if not files:
        eprint(f"Usage: samtools {'fasta' if fasta else 'fastq'} [options...] <in.bam>")
        return 1
    _, recs = sam_records(files[0])
    hout = output_to(out)
    n = 0
    for r in recs:
        f = r.split("\t")
        if len(f) < 11:
            continue
        qname = f[0]; flag = int(f[1]); seq = f[9].upper(); qual = f[10]
        if flag & 0x10:
            seq = revcomp(seq)
            if qual != "*": qual = qual[::-1]
        if qual == "*":
            qual = "B" * len(seq)
        suffix = "/1" if flag & 0x40 else ("/2" if flag & 0x80 else "")
        if fasta:
            hout.write(f">{qname}{suffix}\n{seq}\n")
        else:
            hout.write(f"@{qname}{suffix}\n{seq}\n+\n{qual}\n")
        n += 1
    if hout is not sys.stdout:
        hout.close()
    eprint("[M::bam2fq_mainloop] discarded 0 singletons")
    eprint(f"[M::bam2fq_mainloop] processed {n} reads")
    return 0


def unsupported(cmd, argv):
    if argv and argv[0] in ("-h","--help"):
        print(f"Usage: samtools {cmd} [options]")
        return 0
    eprint(f"[samtools] command '{cmd}' is not implemented in this clean-room reimplementation")
    return 1


def main():
    argv = sys.argv[1:]
    if not argv or argv[0] in ("--help", "-h", "help"):
        if len(argv) >= 2 and argv[0] == "help":
            return dispatch(argv[1], ["--help"])
        print(TOP_HELP)
        return 0 if argv else 1
    if argv[0] in ("--version", "version"):
        version(); return 0
    return dispatch(argv[0], argv[1:])


def dispatch(cmd, args):
    table = {
        "flags": cmd_flags, "faidx": lambda a: cmd_faidx(a, False), "fqidx": lambda a: cmd_faidx(a, True),
        "dict": cmd_dict, "view": cmd_view, "head": cmd_head, "idxstats": cmd_idxstats,
        "flagstat": cmd_flagstat, "sort": cmd_sort, "quickcheck": cmd_quickcheck, "depth": cmd_depth,
        "index": cmd_index,
    }
    if cmd == "fasta":
        return cmd_bam2fq(args, True)
    if cmd == "fastq":
        return cmd_bam2fq(args, False)
    return table.get(cmd, lambda a: unsupported(cmd, a))(args)


if __name__ == "__main__":
    sys.exit(main())
