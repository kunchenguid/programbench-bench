#!/usr/bin/env python3
import sys, gzip, math, random, os
from collections import defaultdict, Counter

VERSION = "1.5-r133"

def main_usage():
    sys.stderr.write(f"""
Usage:   seqtk <command> <arguments>
Version: {VERSION}

Command: seq       common transformation of FASTA/Q
         size      report the number sequences and bases
         comp      get the nucleotide composition of FASTA/Q
         sample    subsample sequences
         subseq    extract subsequences from FASTA/Q
         fqchk     fastq QC (base/quality summary)
         mergepe   interleave two PE FASTA/Q files
         split     split one file into multiple smaller files
         trimfq    trim FASTQ using the Phred algorithm

         hety      regional heterozygosity
         gc        identify high- or low-GC regions
         mutfa     point mutate FASTA at specified positions
         mergefa   merge two FASTA/Q files
         famask    apply a X-coded FASTA to a source FASTA
         dropse    drop unpaired from interleaved PE FASTA/Q
         rename    rename sequence names
         randbase  choose a random base from hets
         cutN      cut sequence at long N
         gap       get the gap locations
         listhet   extract the position of each het
         hpc       homopolyer-compressed sequence
         telo      identify telomere repeats in asm or long reads

""")

def open_text(path):
    if path == "-" or path is None:
        return sys.stdin
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="latin1")
    return open(path, "rt", encoding="latin1")

class Record:
    __slots__ = ("name","comment","seq","qual")
    def __init__(self, name, comment, seq, qual=None):
        self.name, self.comment, self.seq, self.qual = name, comment, seq, qual
    @property
    def header(self):
        return self.name + ((" " + self.comment) if self.comment else "")

def parse_records(path):
    fh = open_text(path)
    first = fh.readline()
    if not first:
        return
    first = first.rstrip("\n\r")
    if first.startswith(">"):
        name, comment = split_head(first[1:])
        chunks = []
        for line in fh:
            line = line.rstrip("\n\r")
            if line.startswith(">"):
                yield Record(name, comment, "".join(chunks), None)
                name, comment = split_head(line[1:])
                chunks = []
            else:
                chunks.append(line.strip())
        yield Record(name, comment, "".join(chunks), None)
    elif first.startswith("@"):
        head = first
        while head:
            name, comment = split_head(head[1:].rstrip("\n\r"))
            seq_chunks = []
            for line in fh:
                line = line.rstrip("\n\r")
                if line.startswith("+"):
                    break
                seq_chunks.append(line.strip())
            seq = "".join(seq_chunks)
            q = []
            n = 0
            while n < len(seq):
                line = fh.readline()
                if not line: break
                s = line.rstrip("\n\r")
                q.append(s); n += len(s)
            yield Record(name, comment, seq, "".join(q)[:len(seq)])
            head = fh.readline()
            if head: head = head.rstrip("\n\r")
    else:
        return

def split_head(s):
    parts = s.split(None, 1)
    return (parts[0], parts[1] if len(parts) > 1 else "")

COMP = str.maketrans("ACGTRYMKWSBDHVNacgtrymkwsbdhvn",
                     "TGCAYRKMWSVHDBNtgcayrkmwsvhdbn")
def revcomp(s): return s.translate(COMP)[::-1]

def wrap(s, l):
    if not l or l <= 0:
        return s + "\n"
    return "".join(s[i:i+l] + "\n" for i in range(0, len(s), l))

def emit(rec, fasta=False, line_len=0, no_comment=False, tab=False, start=1):
    head = rec.name if no_comment else rec.header
    if tab:
        sys.stdout.write(f"{rec.name}\t{start}\t{rec.seq}\n")
    elif fasta or rec.qual is None:
        sys.stdout.write(">" + head + "\n" + wrap(rec.seq, line_len))
    else:
        sys.stdout.write("@" + head + "\n" + wrap(rec.seq, line_len).rstrip("\n") + "\n+\n" + wrap(rec.qual or "", line_len))

def cmd_seq(argv):
    fasta=False; line_len=0; rc=False; no_comment=False; qmask=None; nchar=None; qoff=33; upper=False; lower=False
    mask_bed=None
    files=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a == "-a" or a == "-A": fasta=True
        elif a.startswith("-a") or a.startswith("-A"):
            fasta=True
            rest=a[2:]
            if rest.startswith("Q") and len(rest)>1: qoff=int(rest[1:])
        elif a == "-r": rc=True
        elif a == "-C": no_comment=True
        elif a.startswith("-C"):
            no_comment=True
            rest=a[2:]
            if rest.startswith("l") and len(rest)>1: line_len=int(rest[1:])
        elif a == "-U": upper=True
        elif a == "-L": lower=True
        elif a.startswith("-l"): line_len = int(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-q"): qmask = int(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-Q"): qoff = int(a[2:] or argv[(i:=i+1)])
        elif a == "-n": i+=1; nchar=argv[i]
        elif a.startswith("-n") and len(a)>2: nchar=a[2:]
        elif a == "-M": i+=1; mask_bed=argv[i]
        elif a.startswith("-M") and len(a)>2: mask_bed=a[2:]
        elif a in ("-1","-2"): pass
        elif a.startswith("-"): pass
        else: files.append(a)
        i+=1
    masks = load_bed(mask_bed) if mask_bed else {}
    for path in files or ["-"]:
        for r in parse_records(path):
            seq = r.seq
            qual = r.qual
            if qmask is not None and qual is not None:
                arr=list(seq)
                for j,ch in enumerate(qual):
                    if ord(ch)-qoff < qmask:
                        arr[j] = nchar if nchar is not None else arr[j].lower()
                seq="".join(arr)
            if r.name in masks:
                arr=list(seq)
                for s,e,strand in masks[r.name]:
                    for j in range(max(0,s), min(len(arr),e)):
                        arr[j] = nchar if nchar is not None else arr[j].lower()
                seq="".join(arr)
            if upper: seq=seq.upper()
            if lower: seq=seq.lower()
            if rc:
                seq=revcomp(seq)
                if qual is not None: qual=qual[::-1]
            emit(Record(r.name,r.comment,seq,qual), fasta=fasta, line_len=line_len, no_comment=no_comment)

def cmd_size(argv):
    n=b=0
    for path in argv or ["-"]:
        for r in parse_records(path):
            n+=1; b+=len(r.seq)
    print(f"{n}\t{b}")

def cmd_comp(argv):
    for path in argv or ["-"]:
        for r in parse_records(path):
            counts=[0]*11
            for ch in r.seq:
                u=ch.upper()
                if ch.islower(): counts[7]+=1
                if u=="A": counts[0]+=1
                elif u=="C": counts[1]+=1
                elif u=="G": counts[2]+=1
                elif u=="T": counts[3]+=1
                elif u=="2": counts[4]+=1
                elif u=="3": counts[5]+=1
                elif u=="4": counts[5]+=1
                elif u=="N": counts[6]+=1
                else: counts[9]+=1
            print(r.name + "\t" + str(len(r.seq)) + "\t" + "\t".join(map(str,counts)))

def load_bed(path):
    d=defaultdict(list)
    if not path: return d
    for line in open_text(path):
        if not line.strip() or line.startswith("#"): continue
        f=line.rstrip("\n").split("\t")
        if len(f) >= 3 and is_int(f[1]) and is_int(f[2]):
            strand = f[5] if len(f)>5 else "+"
            d[f[0]].append((int(f[1]), int(f[2]), strand))
    return d

def is_int(s):
    try: int(s); return True
    except: return False

def cmd_subseq(argv):
    tab=False; strand_aware=False; line_len=0; args=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a=="-t": tab=True
        elif a=="-s": strand_aware=True
        elif a.startswith("-l"): line_len=int(a[2:] or argv[(i:=i+1)])
        else: args.append(a)
        i+=1
    if len(args)<2:
        sys.stderr.write("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>\nOptions:\n  -t       TAB delimited output\n  -s       strand aware\n  -l INT   sequence line length [0]\nNote: Use 'samtools faidx' if only a few regions are intended.\n"); return 1
    seqs={r.name:r for r in parse_records(args[0])}
    lines=[l.rstrip("\n") for l in open_text(args[1]) if l.strip() and not l.startswith("#")]
    bed = any(len(l.split("\t"))>=3 and is_int(l.split("\t")[1]) and is_int(l.split("\t")[2]) for l in lines)
    if not bed:
        wanted=set(l.split()[0] for l in lines)
        for r in seqs.values():
            if r.name in wanted: emit(r, fasta=(r.qual is None), tab=tab)
    else:
        for l in lines:
            f=l.split("\t")
            if len(f)<3 or f[0] not in seqs: continue
            r=seqs[f[0]]; s=int(f[1]); e=int(f[2]); sub=r.seq[s:e]; qual=r.qual[s:e] if r.qual else None
            if strand_aware and len(f)>5 and f[5]=="-":
                sub=revcomp(sub); qual=qual[::-1] if qual else None
            nr=Record(f"{r.name}:{s+1}-{e}", r.comment, sub, qual)
            if tab: emit(Record(r.name,"",sub,qual), tab=True, start=s+1)
            else: emit(nr, fasta=(qual is None), line_len=line_len)

def cmd_mergepe(argv):
    if len(argv)<2:
        sys.stderr.write("Usage: seqtk mergepe <in1.fq> <in2.fq>\n"); return 1
    for a,b in zip(parse_records(argv[0]), parse_records(argv[1])):
        emit(a); emit(b)

def cmd_trimfq(argv):
    q=0.05; minlen=30; b=e=L=0; force=False; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a.startswith("-q"): q=float(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-l"): minlen=int(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-b"): b=int(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-e"): e=int(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-L") and a != "-L": L=int(a[2:])
        elif a=="-L": i+=1; L=int(argv[i])
        elif a=="-Q": force=True
        else: args.append(a)
        i+=1
    if not args:
        sys.stderr.write("\nUsage:   seqtk trimfq [options] <in.fq>\n\nOptions: -q FLOAT    error rate threshold (disabled by -b/-e) [0.05]\n         -l INT      maximally trim down to INT bp (disabled by -b/-e) [30]\n         -b INT      trim INT bp from left (non-zero to disable -q/-l) [0]\n         -e INT      trim INT bp from right (non-zero to disable -q/-l) [0]\n         -L INT      retain at most INT bp from the 5'-end (non-zero to disable -q/-l) [0]\n         -Q          force FASTQ output\n\n"); return 1
    for path in args:
        for r in parse_records(path):
            s=0; t=len(r.seq)
            if b or e or L:
                s=b; t=max(s, len(r.seq)-e)
                if L and t-s>L: t=s+L
            seq=r.seq[s:t]; qual=r.qual[s:t] if r.qual else None
            emit(Record(r.name,r.comment,seq,qual), fasta=(qual is None and not force))

def cmd_fqchk(argv):
    qcut=20; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a.startswith("-q"): qcut=int(a[2:] or argv[(i:=i+1)])
        else: args.append(a)
        i+=1
    if not args:
        sys.stderr.write("Usage: seqtk fqchk [-q 20] <in.fq>\nNote: use -q0 to get the distribution of all quality values\n"); return 1
    rows=[]; minl=10**9; maxl=0; total=0; qvals=set()
    allc=Counter(); allq=[]; pos=[]
    for path in args:
        for r in parse_records(path):
            minl=min(minl,len(r.seq)); maxl=max(maxl,len(r.seq)); total+=len(r.seq)
            while len(pos)<len(r.seq): pos.append([Counter(),[]])
            for j,ch in enumerate(r.seq):
                u=ch.upper(); allc[u]+=1; pos[j][0][u]+=1
            for j,ch in enumerate(r.qual or ""):
                v=ord(ch)-33; qvals.add(v); allq.append(v); pos[j][1].append(v)
    if minl==10**9: minl=0
    avg= total/(sum(sum(c.values()) for c,q in pos[:1]) or 1)
    nseq = 0
    if total: nseq = sum(pos[0][0].values())
    sys.stdout.write(f"min_len: {minl}; max_len: {maxl}; avg_len: {(total/nseq if nseq else 0):.2f}; {len(qvals)} distinct quality values\n")
    sys.stdout.write("POS\t#bases\t%A\t%C\t%G\t%T\t%N\tavgQ\terrQ\t%low\t%high\n")
    print_qrow("ALL", allc, allq, qcut)
    for i,(c,qs) in enumerate(pos,1): print_qrow(str(i), c, qs, qcut)

def print_qrow(label,c,qs,qcut):
    n=sum(c.values())
    def pct(x): return 100.0*x/n if n else 0.0
    aq=sum(qs)/len(qs) if qs else 0.0
    # Phred of mean error probability.
    ep=sum(10**(-v/10) for v in qs)/len(qs) if qs else 1
    eq=-10*math.log10(ep) if ep>0 else 99
    low=sum(1 for v in qs if v<qcut)
    sys.stdout.write(f"{label}\t{n}\t{pct(c['A']):.1f}\t{pct(c['C']):.1f}\t{pct(c['G']):.1f}\t{pct(c['T']):.1f}\t{pct(c['N']):.1f}\t{aq:.1f}\t{eq:.1f}\t{(100*low/len(qs) if qs else 0):.1f}\t{(100*(len(qs)-low)/len(qs) if qs else 0):.1f}\n")

def cmd_sample(argv):
    seed=11; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a=="-2": pass
        elif a.startswith("-s"): seed=int(a[2:] or argv[(i:=i+1)])
        else: args.append(a)
        i+=1
    if len(args)<2:
        sys.stderr.write("\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>\n\nOptions: -s INT       RNG seed [11]\n         -2           2-pass mode: twice as slow but with much reduced memory\n\n"); return 1
    recs=list(parse_records(args[0])); x=float(args[1]); random.seed(seed)
    if x<1:
        chosen=[r for r in recs if random.random()<x]
    else:
        n=int(x); chosen=random.sample(recs, min(n,len(recs))) if n<len(recs) else recs
    for r in chosen: emit(r, fasta=(r.qual is None))

def cmd_split(argv):
    n=10; l=0; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a.startswith("-n"): n=int(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-l"): l=int(a[2:] or argv[(i:=i+1)])
        else: args.append(a)
        i+=1
    if len(args)<2:
        sys.stderr.write("Usage: seqtk split [options] <prefix> <in.fa>\nOptions:\n  -n INT    number of files [10]\n  -l INT    line length [0]\n"); return 1
    recs=list(parse_records(args[1])); per=max(1, math.ceil(len(recs)/n))
    for k in range(n):
        chunk=recs[k*per:(k+1)*per]
        if not chunk: break
        with open(f"{args[0]}.{k}", "w") as old:
            save=sys.stdout; sys.stdout=old
            for r in chunk: emit(r, fasta=(r.qual is None), line_len=l)
            sys.stdout=save

def cmd_hpc(argv):
    for path in argv or ["-"]:
        for r in parse_records(path):
            out=[]; last=None
            for ch in r.seq:
                if ch.upper()!=last:
                    out.append(ch); last=ch.upper()
            emit(Record(r.name,"","".join(out),None), fasta=True)

def cmd_gap(argv):
    minl=50; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a.startswith("-l"): minl=int(a[2:] or argv[(i:=i+1)])
        else: args.append(a)
        i+=1
    if not args:
        sys.stderr.write("Usage: seqtk gap [-l 50] <in.fa>\n"); return 1
    for path in args:
        for r in parse_records(path):
            for s,e in n_runs(r.seq,minl):
                print(f"{r.name}\t{s}\t{e}")

def n_runs(seq,minl):
    i=0
    while i<len(seq):
        if seq[i].upper()=="N":
            j=i
            while j<len(seq) and seq[j].upper()=="N": j+=1
            if j-i>=minl: yield i,j
            i=j
        else: i+=1

def cmd_cutN(argv):
    n=1000; gaps=False; args=[]; i=0
    while i<len(argv):
        a=argv[i]
        if a=="-g": gaps=True
        elif a.startswith("-n"): n=int(a[2:] or argv[(i:=i+1)])
        elif a.startswith("-p"): _=a
        else: args.append(a)
        i+=1
    if not args:
        sys.stderr.write("\nUsage:   seqtk cutN [options] <in.fa>\n\nOptions: -n INT    min size of N tract [1000]\n         -p INT    penalty for a non-N [10]\n         -g        print gaps only, no sequence\n\n"); return 1
    for path in args:
        for r in parse_records(path):
            last=0
            runs=list(n_runs(r.seq,n))
            if gaps:
                for s,e in runs: print(f"{r.name}\t{s}\t{e}")
            else:
                for s,e in runs+[(len(r.seq),len(r.seq))]:
                    if s>last: emit(Record(f"{r.name}:{last+1}-{s}","",r.seq[last:s],None), fasta=True)
                    last=e

IUPAC = {"R":"AG","Y":"CT","M":"AC","K":"GT","W":"AT","S":"CG"}
def cmd_listhet(argv):
    if not argv:
        sys.stderr.write("Usage: seqtk listhet <in.fa>\n"); return 1
    for path in argv:
        for r in parse_records(path):
            for i,ch in enumerate(r.seq,1):
                if ch.upper() in IUPAC: print(f"{r.name}\t{i}\t{ch}")

def cmd_randbase(argv):
    if not argv:
        sys.stderr.write("Usage: seqtk randbase <in.fa>\n"); return 1
    random.seed(11)
    for path in argv:
        for r in parse_records(path):
            seq="".join(random.choice(IUPAC.get(ch.upper(), ch)) if ch.upper() in IUPAC else ch for ch in r.seq)
            emit(Record(r.name,r.comment,seq,r.qual), fasta=(r.qual is None))

def cmd_rename(argv):
    start=1
    for path in argv or ["-"]:
        for r in parse_records(path):
            emit(Record(str(start), r.comment, r.seq, r.qual), fasta=(r.qual is None)); start+=1

def cmd_dropse(argv):
    buf=None
    for r in parse_records(argv[0] if argv else "-"):
        base=r.name.split("/")[0]
        if buf is None: buf=(base,r)
        else:
            if buf[0]==base:
                emit(buf[1], fasta=(buf[1].qual is None)); emit(r, fasta=(r.qual is None))
            buf=None

def cmd_mutfa(argv):
    if len(argv)<2:
        sys.stderr.write("Usage: seqtk mutfa <in.fa> <in.snp>\n\nNote: <in.snp> contains at least four columns per line which are:\n      'chr  1-based-pos  any  base-changed-to'.\n"); return 1
    muts=defaultdict(dict)
    for l in open_text(argv[1]):
        f=l.split()
        if len(f)>=4 and is_int(f[1]): muts[f[0]][int(f[1])-1]=f[3]
    for r in parse_records(argv[0]):
        arr=list(r.seq)
        for p,b in muts.get(r.name,{}).items():
            if 0<=p<len(arr): arr[p]=b
        emit(Record(r.name,r.comment,"".join(arr),r.qual), fasta=(r.qual is None))

def cmd_famask(argv):
    if len(argv)<2:
        sys.stderr.write("Usage: seqtk famask <src.fa> <mask.fa>\n"); return 1
    masks={r.name:r.seq for r in parse_records(argv[1])}
    for r in parse_records(argv[0]):
        m=masks.get(r.name,""); arr=list(r.seq)
        for i,ch in enumerate(m[:len(arr)]):
            if ch.upper()=="X": arr[i]=arr[i].lower()
        emit(Record(r.name,r.comment,"".join(arr),r.qual), fasta=(r.qual is None))

def cmd_mergefa(argv):
    args=[a for a in argv if not a.startswith("-")]
    if len(args)<2:
        sys.stderr.write("\nUsage: seqtk mergefa [options] <in1.fa> <in2.fa>\n\nOptions: -q INT   quality threshold [0]\n         -i       take intersection\n         -m       convert to lowercase when one of the input base is N\n         -r       pick a random allele from het\n         -h       suppress hets in the input\n\n"); return 1
    d2={r.name:r for r in parse_records(args[1])}
    for r in parse_records(args[0]):
        s2=d2.get(r.name)
        if not s2: continue
        out=[]
        for a,b in zip(r.seq,s2.seq):
            out.append(a if a.upper()==b.upper() else "N")
        emit(Record(r.name,r.comment,"".join(out),None), fasta=True)

def cmd_gc(argv):
    if not argv:
        sys.stderr.write("Usage: seqtk gc [options] <in.fa>\nOptions:\n  -w         identify high-AT regions\n  -f FLOAT   min GC fraction (or AT fraction for -w) [0.60]\n  -l INT     min region length to output [20]\n  -x FLOAT   X-dropoff [10.0]\n"); return 1
    args=[a for a in argv if not a.startswith("-")]
    for path in args:
        for r in parse_records(path):
            gc=sum(1 for c in r.seq.upper() if c in "GC")
            n=sum(1 for c in r.seq.upper() if c in "ACGT")
            print(f"{r.name}\t0\t{len(r.seq)}\t{(gc/n if n else 0):.3f}")

def cmd_telo(argv):
    total=hits=0
    for path in argv:
        for r in parse_records(path):
            total+=1
            s=r.seq.upper()
            if "TTAGGGTTAGGG" in s or "CCCTAACCCTAA" in s:
                hits+=1; print(f"{r.name}\t0\t{len(r.seq)}")
    sys.stderr.write(f"{total}\t{hits}\n")

def cmd_hety(argv):
    if not [a for a in argv if not a.startswith("-")]:
        sys.stderr.write("\nUsage:   seqtk hety [options] <in.fa>\n\nOptions: -w INT   window size [50000]\n         -t INT   # start positions in a window [5]\n         -m       treat lowercases as masked\n\n"); return 1

def dispatch():
    if len(sys.argv)<2:
        main_usage(); return 1
    cmd=sys.argv[1]; argv=sys.argv[2:]
    table={"seq":cmd_seq,"size":cmd_size,"comp":cmd_comp,"subseq":cmd_subseq,"mergepe":cmd_mergepe,
           "trimfq":cmd_trimfq,"fqchk":cmd_fqchk,"sample":cmd_sample,"split":cmd_split,"hpc":cmd_hpc,
           "gap":cmd_gap,"cutN":cmd_cutN,"listhet":cmd_listhet,"randbase":cmd_randbase,"rename":cmd_rename,
           "dropse":cmd_dropse,"mutfa":cmd_mutfa,"famask":cmd_famask,"mergefa":cmd_mergefa,"gc":cmd_gc,
           "telo":cmd_telo,"hety":cmd_hety}
    if cmd not in table:
        sys.stderr.write(f"[main] unrecognized command '{cmd}'. Abort!\n"); return 1
    r=table[cmd](argv)
    return 0 if r is None else r

if __name__ == "__main__":
    sys.exit(dispatch())
