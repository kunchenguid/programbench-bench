#!/usr/bin/env python3
import sys, csv, argparse, re, os, random, math, statistics, shutil
from collections import Counter, defaultdict

COMMANDS = [
('cat','Concatenate by row or column'),('count','Count records'),('fixlengths','Makes all records have same length'),('flatten','Show one field per line'),('fmt','Format CSV output (change field delimiter)'),('frequency','Show frequency tables'),('headers','Show header names'),('help','Show this usage message.'),('index','Create CSV index for faster access'),('input','Read CSV data with special quoting rules'),('join','Join CSV files'),('partition','Partition CSV data based on a column value'),('sample','Randomly sample CSV data'),('reverse','Reverse rows of CSV data'),('search','Search CSV data with regexes'),('select','Select columns from CSV'),('slice','Slice records from CSV'),('sort','Sort CSV data'),('split','Split CSV data into many files'),('stats','Compute basic statistics'),('table','Align CSV data into columns')]

def die(msg, code=1):
    sys.stderr.write(msg.rstrip()+"\n"); sys.exit(code)

def top_help():
    print("Usage:\n    xsv <command> [<args>...]\n    xsv [options]\n\nOptions:\n    --list        List all commands available.\n    -h, --help    Display this message\n    <command> -h  Display the command help message\n    --version     Print version info and exit\n\nCommands:")
    for c,d in COMMANDS: print(f"    {c:<11} {d}")

def list_cmds():
    print('Installed commands:')
    for c,d in COMMANDS: print(f"    {c:<11} {d}")

class Dialect(csv.excel): pass

def make_dialect(delim=',', quote='"', escape=None, no_quoting=False):
    class D(csv.Dialect):
        delimiter = delim
        quotechar = quote if not no_quoting else None
        escapechar = escape
        doublequote = escape is None
        skipinitialspace = False
        lineterminator = '\n'
        quoting = csv.QUOTE_NONE if no_quoting else csv.QUOTE_MINIMAL
        strict = False
    return D

def open_in(path):
    if not path or path == '-': return sys.stdin
    return open(path, newline='')

def read_rows(path=None, delim=',', quote='"', escape=None, no_quoting=False):
    f = open_in(path)
    try:
        return [row for row in csv.reader(f, dialect=make_dialect(delim,quote,escape,no_quoting))]
    finally:
        if f is not sys.stdin: f.close()

def writer_for(path=None, delim=',', quote='"', escape=None, quote_always=False, crlf=False, no_quoting=False, lineterminator=None):
    f = sys.stdout if not path or path == '-' else open(path, 'w', newline='')
    quoting = csv.QUOTE_ALL if quote_always else (csv.QUOTE_NONE if no_quoting else csv.QUOTE_MINIMAL)
    lt = lineterminator if lineterminator is not None else ('\r\n' if crlf else '\n')
    w = csv.writer(f, delimiter=delim, quotechar=(None if no_quoting else quote), escapechar=escape, doublequote=(escape is None), lineterminator=lt, quoting=quoting)
    return f,w

def write_rows(rows, path=None, delim=',', **kw):
    f,w = writer_for(path, delim=delim, **kw)
    for r in rows: w.writerow(r)
    if f is not sys.stdout: f.close()

def split_selection(s):
    out=[]; cur=''; q=False; i=0
    while i < len(s):
        ch=s[i]
        if ch=='"': q=not q; cur+=ch
        elif ch==',' and not q: out.append(cur); cur=''
        else: cur+=ch
        i+=1
    out.append(cur)
    return [x.strip() for x in out if x.strip()!='']

def unquote(x):
    x=x.strip()
    if len(x)>=2 and x[0]=='"' and x[-1]=='"': return x[1:-1].replace('""','"')
    return x

def col_index(tok, headers, ncols):
    tok=unquote(tok.strip())
    m=re.match(r'^(.*)\[(\d+)\]$', tok)
    nth=1
    if m: tok=m.group(1); nth=int(m.group(2))
    if tok=='': return None
    if re.match(r'^\d+$', tok):
        i=int(tok)-1
        if i<0: die('Could not select column 0')
        return i
    if headers is None: die(f"Cannot select column '{tok}' without headers")
    hits=[i for i,h in enumerate(headers) if h==tok]
    if len(hits) >= nth: return hits[nth-1]
    die(f"Selector '{tok}' did not match any columns")

def parse_select(sel, headers, ncols):
    invert=False
    if sel.startswith('!'):
        invert=True; sel=sel[1:]
    idx=[]
    for part in split_selection(sel):
        if '-' in part and not (part.startswith('"') and part.endswith('"')):
            a,b=part.split('-',1)
            start = 0 if a.strip()=='' else col_index(a,headers,ncols)
            end = ncols-1 if b.strip()=='' else col_index(b,headers,ncols)
            step = 1 if start<=end else -1
            idx.extend(range(start, end+step, step))
        else:
            idx.append(col_index(part,headers,ncols))
    if invert:
        s=set(idx); idx=[i for i in range(ncols) if i not in s]
    return idx

def common_parser(add_output=True, add_headers=True):
    p=argparse.ArgumentParser(add_help=False)
    p.add_argument('-h','--help',action='store_true')
    if add_output: p.add_argument('-o','--output')
    if add_headers: p.add_argument('-n','--no-headers',action='store_true')
    p.add_argument('-d','--delimiter',default=',')
    return p

def clean_delim(d):
    if d == r'\t': return '\t'
    if d == '\\t': return '\t'
    if len(d)!=1: die('delimiter must be a single character')
    return d

def maybe_help(argv, text):
    if any(a in ('-h','--help') for a in argv): print(text); sys.exit(0)

def cmd_count(argv):
    maybe_help(argv, 'Usage:\n    xsv count [options] [<input>]')
    p=common_parser(False, True); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); n=len(rows) if a.no_headers else max(0,len(rows)-1); print(n)

def cmd_headers(argv):
    maybe_help(argv, 'Usage:\n    xsv headers [options] [<input>...]')
    p=common_parser(False, False); p.add_argument('-j','--just-names',action='store_true'); p.add_argument('--intersect',action='store_true'); p.add_argument('inputs', nargs='*'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    inputs=a.inputs or [None]
    heads=[]
    for inp in inputs:
        r=read_rows(inp,d); heads.append(r[0] if r else [])
    if a.intersect:
        vals=[h for h in heads[0] if all(h in x for x in heads[1:])]
    elif len(heads)>1:
        vals=[]
        for h in heads: vals.extend(h)
    else: vals=heads[0]
    just=a.just_names or len(inputs)>1 or a.intersect
    for i,h in enumerate(vals,1): print(h if just else f"{i}   {h}")

def cmd_select(argv):
    maybe_help(argv, 'Usage:\n    xsv select [options] [--] <selection> [<input>]')
    p=common_parser(True, True); p.add_argument('selection'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); 
    if not rows: return
    headers=None if a.no_headers else rows[0]
    n=max(len(r) for r in rows) if rows else 0
    idx=parse_select(a.selection, headers, n)
    out=[]
    for r in rows: out.append([r[i] if i < len(r) else '' for i in idx])
    write_rows(out,a.output,d)

def cmd_slice(argv):
    maybe_help(argv, 'Usage:\n    xsv slice [options] [<input>]')
    p=common_parser(True, True); p.add_argument('-s','--start',type=int); p.add_argument('-e','--end',type=int); p.add_argument('-l','--len',type=int); p.add_argument('-i','--index',type=int); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    start=0 if a.start is None else a.start
    end=a.end
    if a.index is not None: start=a.index; end=start+1
    if a.len is not None: end=start+a.len
    out=head+data[start:end]
    write_rows(out,a.output,d)

def cmd_reverse(argv):
    maybe_help(argv, 'Usage:\n    xsv reverse [options] [<input>]')
    p=common_parser(True, True); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); out=list(reversed(rows)) if a.no_headers or not rows else [rows[0]]+list(reversed(rows[1:])); write_rows(out,a.output,d)

def cmd_sort(argv):
    maybe_help(argv, 'Usage:\n    xsv sort [options] [<input>]')
    p=common_parser(True, True); p.add_argument('-s','--select'); p.add_argument('-N','--numeric',action='store_true'); p.add_argument('-R','--reverse',action='store_true'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    n=max([len(r) for r in rows], default=0); idx=parse_select(a.select, None if a.no_headers or not rows else rows[0], n) if a.select else list(range(n))
    def key(r):
        vals=[r[i] if i<len(r) else '' for i in idx]
        if a.numeric:
            return [float(v) if re.match(r'^[-+]?\d+(\.\d+)?([eE][-+]?\d+)?$', v) else math.nan for v in vals]
        return vals
    data=sorted(data,key=key,reverse=a.reverse); write_rows(head+data,a.output,d)

def cmd_search(argv):
    maybe_help(argv, 'Usage:\n    xsv search [options] <regex> [<input>]')
    p=common_parser(True, True); p.add_argument('-i','--ignore-case',action='store_true'); p.add_argument('-s','--select'); p.add_argument('-v','--invert-match',action='store_true'); p.add_argument('regex'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); flags=re.I if a.ignore_case else 0; rx=re.compile(a.regex, flags)
    head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    n=max([len(r) for r in rows], default=0); idx=parse_select(a.select, None if a.no_headers or not rows else rows[0], n) if a.select else list(range(n))
    out=head[:]
    for r in data:
        m=any(rx.search(r[i] if i<len(r) else '') for i in idx)
        if m ^ a.invert_match: out.append(r)
    write_rows(out,a.output,d)

def cmd_fmt(argv):
    maybe_help(argv, 'Usage:\n    xsv fmt [options] [<input>]')
    p=common_parser(True, False); p.add_argument('-t','--out-delimiter',default=','); p.add_argument('--crlf',action='store_true'); p.add_argument('--ascii',action='store_true'); p.add_argument('--quote',default='"'); p.add_argument('--quote-always',action='store_true'); p.add_argument('--escape'); p.add_argument('input', nargs='?'); a=p.parse_args(argv)
    ind=clean_delim(a.delimiter); outd='\x1f' if a.ascii else clean_delim(a.out_delimiter)
    rows=read_rows(a.input,ind); write_rows(rows,a.output,outd,quote=a.quote,escape=a.escape,quote_always=a.quote_always,crlf=a.crlf,lineterminator=('\x1e' if a.ascii else None))

def cmd_input(argv):
    maybe_help(argv, 'Usage:\n    xsv input [options] [<input>]')
    p=common_parser(True, False); p.add_argument('--quote',default='"'); p.add_argument('--escape'); p.add_argument('--no-quoting',action='store_true'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d,a.quote,a.escape,a.no_quoting); write_rows(rows,a.output,',')

def cmd_fixlengths(argv):
    maybe_help(argv, 'Usage:\n    xsv fixlengths [options] [<input>]')
    p=common_parser(True, False); p.add_argument('-l','--length',type=int); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); L=a.length if a.length is not None else max([max(1,len([x for x in r if x!=''])) if r else 1 for r in rows], default=0)
    out=[(r[:L]+['']*max(0,L-len(r))) for r in rows]; write_rows(out,a.output,d)

def cmd_flatten(argv):
    maybe_help(argv, 'Usage:\n    xsv flatten [options] [<input>]')
    p=common_parser(False, True); p.add_argument('-c','--condense',type=int); p.add_argument('-s','--separator',default='#'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); 
    if not rows: return
    if a.no_headers: headers=[str(i) for i in range(max(len(r) for r in rows))]; data=rows
    else: headers=rows[0]; data=rows[1:]
    width=max([len(h) for h in headers], default=0)
    for ri,r in enumerate(data):
        for i,h in enumerate(headers):
            v=r[i] if i<len(r) else ''
            if a.condense is not None and len(v)>a.condense: v=v[:a.condense]
            print(f"{h:<{width}}   {v}")
        if a.separator!='' and ri != len(data)-1: print(a.separator)

def cmd_table(argv):
    maybe_help(argv, 'Usage:\n    xsv table [options] [<input>]')
    p=common_parser(True, False); p.add_argument('-w','--width',type=int,default=2); p.add_argument('-p','--pad',type=int,default=2); p.add_argument('-c','--condense',type=int); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); 
    if a.condense is not None: rows=[[v[:a.condense] if len(v)>a.condense else v for v in r] for r in rows]
    n=max([len(r) for r in rows], default=0); widths=[a.width]*n
    for r in rows:
        for i,v in enumerate(r): widths[i]=max(widths[i],len(v))
    lines=[]
    for r in rows:
        vals=[(r[i] if i<len(r) else '').ljust(widths[i]) for i in range(n)]
        lines.append((' '*a.pad).join(vals).rstrip())
    out='\n'.join(lines)+('\n' if lines else '')
    if a.output: open(a.output,'w').write(out)
    else: sys.stdout.write(out)

def type_name(vals):
    non=[v for v in vals if v!='']
    if not non: return 'NULL'
    if all(re.match(r'^[-+]?\d+$',v) for v in non): return 'Integer'
    if all(is_num(v) for v in non): return 'Float'
    return 'Unicode'

def is_num(v):
    try: float(v); return v!=''
    except: return False

def fmt_num(x):
    if x=='' or x is None: return ''
    if isinstance(x,float) and (math.isnan(x) or math.isinf(x)): return ''
    if abs(x-round(x))<1e-12: return str(int(round(x)))
    return str(float(x))

def cmd_stats(argv):
    maybe_help(argv, 'Usage:\n    xsv stats [options] [<input>]')
    p=common_parser(True, True); p.add_argument('-s','--select'); p.add_argument('--everything',action='store_true'); p.add_argument('--mode',action='store_true'); p.add_argument('--cardinality',action='store_true'); p.add_argument('--median',action='store_true'); p.add_argument('--nulls',action='store_true'); p.add_argument('-j','--jobs'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); 
    if not rows: return
    headers=None if a.no_headers else rows[0]; data=rows if a.no_headers else rows[1:]; n=max(len(r) for r in rows)
    idx=parse_select(a.select, headers, n) if a.select else list(range(n))
    cols=['field','type','sum','min','max','min_length','max_length','mean','stddev']
    if a.everything or a.median: cols.append('median')
    if a.everything or a.mode: cols.append('mode')
    if a.everything or a.cardinality: cols.append('cardinality')
    out=[cols]
    for i in idx:
        vals=[r[i] if i<len(r) else '' for r in data]
        t=type_name(vals)
        nums=[float(v) for v in vals if is_num(v)] if t in ('Integer','Float') else []
        pop=len(vals) if (a.nulls and nums) else len(nums)
        s=sum(nums) if nums else 0
        mean=s/pop if pop else None
        sd=math.sqrt(sum((x-(mean or 0))**2 for x in nums)/pop) if pop else None
        nonlens=[len(v) for v in vals if v!='']
        if nums and t in ('Integer','Float'):
            mn, mx = fmt_num(min(nums)), fmt_num(max(nums))
        else:
            non=[v for v in vals if v!='']; mn=min(non) if non else ''; mx=max(non) if non else ''
        row=[headers[i] if headers and i<len(headers) else str(i), t, fmt_num(s) if nums else '', mn, mx, str(min(nonlens) if nonlens else 0), str(max(nonlens) if nonlens else 0), fmt_num(mean), fmt_num(sd)]
        if a.everything or a.median: row.append(fmt_num(statistics.median(nums)) if nums else '')
        if a.everything or a.mode:
            c=Counter(vals); row.append(c.most_common(1)[0][0] if vals else '')
        if a.everything or a.cardinality: row.append(str(len(set(vals))))
        out.append(row)
    write_rows(out,a.output,',')

def cmd_frequency(argv):
    maybe_help(argv, 'Usage:\n    xsv frequency [options] [<input>]')
    p=common_parser(True, True); p.add_argument('-s','--select'); p.add_argument('-l','--limit',type=int,default=10); p.add_argument('-a','--asc',action='store_true'); p.add_argument('--no-nulls',action='store_true'); p.add_argument('-j','--jobs'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    rows=read_rows(a.input,d); 
    if not rows: return
    headers=None if a.no_headers else rows[0]; data=rows if a.no_headers else rows[1:]; n=max(len(r) for r in rows)
    idx=parse_select(a.select, headers, n) if a.select else list(range(n)); out=[['field','value','count']]
    for i in idx:
        vals=[r[i] if i<len(r) else '' for r in data]
        if a.no_nulls: vals=[v for v in vals if v!='']
        items=list(Counter(vals).items()); items.sort(key=lambda kv:(kv[1],kv[0]), reverse=not a.asc)
        if a.limit: items=items[:a.limit]
        field=headers[i] if headers and i<len(headers) else str(i+1)
        for v,c in items: out.append([field,v,str(c)])
    write_rows(out,a.output,',')

def cmd_cat(argv):
    maybe_help(argv, 'Usage:\n    xsv cat rows    [options] [<input>...]\n    xsv cat columns [options] [<input>...]')
    if not argv: die('Usage: xsv cat rows|columns')
    mode=argv[0]; p=common_parser(True, True); p.add_argument('-p','--pad',action='store_true'); p.add_argument('inputs', nargs='*'); a=p.parse_args(argv[1:]); d=clean_delim(a.delimiter)
    allrows=[read_rows(inp,d) for inp in (a.inputs or [None])]
    if mode=='rows':
        out=[]
        for k,rs in enumerate(allrows): out.extend(rs if (a.no_headers or k==0) else rs[1:])
    elif mode=='columns':
        L=(max if a.pad else min)([len(r) for r in allrows] or [0]); out=[]
        for j in range(L):
            row=[]
            for rs in allrows: row += (rs[j] if j<len(rs) else ['']*(max([len(x) for x in rs],default=1)))
            out.append(row)
    else: die('Usage: xsv cat rows|columns')
    write_rows(out,a.output,d)

def cmd_join(argv):
    maybe_help(argv, 'Usage:\n    xsv join [options] <columns1> <input1> <columns2> <input2>')
    p=common_parser(True, True); p.add_argument('--no-case',action='store_true'); p.add_argument('--left',action='store_true'); p.add_argument('--right',action='store_true'); p.add_argument('--full',action='store_true'); p.add_argument('--cross',action='store_true'); p.add_argument('--nulls',action='store_true'); p.add_argument('c1'); p.add_argument('i1'); p.add_argument('c2'); p.add_argument('i2'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    r1=read_rows(a.i1,d); r2=read_rows(a.i2,d); h1=None if a.no_headers else (r1[0] if r1 else []); h2=None if a.no_headers else (r2[0] if r2 else []); data1=r1 if a.no_headers else r1[1:]; data2=r2 if a.no_headers else r2[1:]
    if a.cross:
        out=[] if a.no_headers else [h1+h2]
        for x in data1:
            for y in data2: out.append(x+y)
        write_rows(out,a.output,d); return
    n1=max([len(r) for r in r1],default=0); n2=max([len(r) for r in r2],default=0); ix1=parse_select(a.c1,h1,n1); ix2=parse_select(a.c2,h2,n2)
    def key(r,ix):
        vals=[(r[i] if i<len(r) else '').strip() for i in ix]
        if not a.nulls and any(v=='' for v in vals): return None
        if a.no_case: vals=[v.lower() for v in vals]
        return tuple(vals)
    mp=defaultdict(list)
    for j,y in enumerate(data2):
        k=key(y,ix2)
        if k is not None: mp[k].append((j,y))
    out=[] if a.no_headers else [h1+h2]; matched=set()
    for x in data1:
        k=key(x,ix1); hits=mp.get(k,[]) if k is not None else []
        if hits:
            for j,y in hits: out.append(x+y); matched.add(j)
        elif a.left or a.full: out.append(x+['']*n2)
    if a.right or a.full:
        for j,y in enumerate(data2):
            if j not in matched: out.append(['']*n1+y)
    write_rows(out,a.output,d)

def sanitize(v):
    return re.sub(r'[^A-Za-z0-9_.-]+','_',v) or '_'

def cmd_split(argv):
    maybe_help(argv, 'Usage:\n    xsv split [options] <outdir> [<input>]')
    p=common_parser(False, True); p.add_argument('-s','--size',type=int,default=500); p.add_argument('-j','--jobs'); p.add_argument('--filename',default='{}.csv'); p.add_argument('outdir'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    os.makedirs(a.outdir,exist_ok=True); rows=read_rows(a.input,d); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    for start in range(0,len(data),a.size):
        path=os.path.join(a.outdir,a.filename.replace('{}',str(start))); write_rows(head+data[start:start+a.size],path,d)

def cmd_partition(argv):
    maybe_help(argv, 'Usage:\n    xsv partition [options] <column> <outdir> [<input>]')
    p=common_parser(False, True); p.add_argument('--filename',default='{}.csv'); p.add_argument('-p','--prefix-length',type=int); p.add_argument('--drop',action='store_true'); p.add_argument('column'); p.add_argument('outdir'); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter)
    os.makedirs(a.outdir,exist_ok=True); rows=read_rows(a.input,d); h=None if a.no_headers or not rows else rows[0]; data=rows if a.no_headers else rows[1:]; n=max([len(r) for r in rows],default=0); ix=parse_select(a.column,h,n)[0]
    groups=defaultdict(list)
    for r in data:
        v=r[ix] if ix<len(r) else ''; name=sanitize(v[:a.prefix_length] if a.prefix_length else v); rr=[x for j,x in enumerate(r) if not(a.drop and j==ix)]; groups[name].append(rr)
    head=[] if a.no_headers else [[x for j,x in enumerate(h) if not(a.drop and j==ix)]]
    for name,rs in groups.items(): write_rows(head+rs,os.path.join(a.outdir,a.filename.replace('{}',name)),d)

def cmd_sample(argv):
    maybe_help(argv, 'Usage:\n    xsv sample [options] <sample-size> [<input>]')
    p=common_parser(True, True); p.add_argument('--seed',type=int); p.add_argument('size',type=int); p.add_argument('input', nargs='?'); a=p.parse_args(argv); d=clean_delim(a.delimiter); rng=random.Random(a.seed)
    rows=read_rows(a.input,d); head=[]; data=rows
    if not a.no_headers and rows: head=[rows[0]]; data=rows[1:]
    samp=rng.sample(data,min(a.size,len(data))) if a.size < len(data) else data[:]
    write_rows(head+samp,a.output,d)

def cmd_index(argv):
    maybe_help(argv, 'Usage:\n    xsv index [options] <input>')
    p=common_parser(False, False); p.add_argument('-o','--output'); p.add_argument('input'); a=p.parse_args(argv)
    rows=read_rows(a.input,clean_delim(a.delimiter)); out=a.output or (a.input+'.idx')
    with open(out,'wb') as f: f.write(b'XSVIDX\0')

def main():
    argv=sys.argv[1:]
    if not argv or argv[0] in ('-h','--help','help'): top_help(); return
    if argv[0]=='--version': print('0.13.0'); return
    if argv[0]=='--list': list_cmds(); return
    cmd=argv[0].replace('-','_'); fn=globals().get('cmd_'+cmd)
    if not fn: die(f"Unrecognized command: {argv[0]}")
    fn(argv[1:])
if __name__=='__main__': main()
