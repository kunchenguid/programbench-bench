#!/usr/bin/env python3
import datetime
import json
import os
import re
import shutil
import sys

BANNER = """##################################################################
# Content under this line is handled by hostctl. DO NOT EDIT.
##################################################################"""

ROOT_HELP = """
hostctl is a CLI tool to manage your hosts file with ease.
You can have multiple profiles, enable/disable exactly what
you need each time with a simple interface.

Usage:
  hostctl [command]

Available Commands:
  add         Add content to a profile in your hosts file.
  backup      Creates a backup copy of your hosts file
  disable     Disable a profile from your hosts file.
  enable      Enable a profile on your hosts file.
  help        Help about any command
  list        Shows a detailed list of profiles on your hosts file.
  remove      Remove a profile from your hosts file.
  replace     Replace content to a profile in your hosts file.
  restore     Restore hosts file content from a backup file.
  status      Shows a list of profile names and statuses on your hosts file.
  sync        Sync some system IPs with a profile.
  toggle      Change status of a profile on your hosts file.

Flags:
  -c, --column strings     Column names to show on lists. comma separated
  -h, --help               help for hostctl
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
  -v, --version            version for hostctl

Use "hostctl [command] --help" for more information about a command.
""".strip()

HELPS = {
    "add": """Reads from a file and set content to a profile in your hosts file.
If the profile already exists it will be added to it.

Usage:
  hostctl add [profiles] [flags]
  hostctl add [command]

Available Commands:
  domains     Add content in your hosts file.

Flags:
  -f, --from string     file to read
  -h, --help            help for add
  -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)

Global Flags:
  -c, --column strings     Column names to show on lists. comma separated
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)

Use "hostctl add [command] --help" for more information about a command.""",
    "add domains": """Set content in your hosts file.
If the profile already exists it will be added to it.

Usage:
  hostctl add domains [profile] [domains] [flags]

Aliases:
  domains, domain [profile] [domains] [flags]

Flags:
  -h, --help        help for domains
      --ip string   domains ip (default "127.0.0.1")

Global Flags:
  -c, --column strings     Column names to show on lists. comma separated
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)
  -w, --wait duration      Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)""",
    "list": """Shows a detailed list of profiles on your hosts file with name, ip and host name.
You can filter by profile name.

The "default" profile is all the content that is not handled by hostctl tool.

Usage:
  hostctl list [profiles] [flags]
  hostctl list [command]

Available Commands:
  disabled    Shows list of disabled profiles on your hosts file.
  enabled     Shows list of enabled profiles on your hosts file.

Flags:
  -h, --help   help for list

Global Flags:
  -c, --column strings     Column names to show on lists. comma separated
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)

Use "hostctl list [command] --help" for more information about a command.""",
    "status": """Shows a list of unique profile names on your hosts file with its status.

The "default" profile is always on and will be skipped.

Usage:
  hostctl status [profiles] [flags]

Flags:
  -h, --help   help for status

Global Flags:
  -c, --column strings     Column names to show on lists. comma separated
      --host-file string   Hosts file path (default "/etc/hosts")
      --no-color           force colorless output
  -o, --out string         Output type (table|raw|markdown|json) (default "table")
  -q, --quiet              Run command without output
      --raw                Output without borders (same as -o raw)""",
}

def short_help(cmd):
    return {
        "backup": "Creates a backup copy of your hosts file with the date in .YYYYMMDD\nas extension.\n\nUsage:\n  hostctl backup [flags]\n\nFlags:\n  -h, --help          help for backup\n      --path string   A path to save the backup (default \"/workspace\")",
        "disable": "Disable a profile from your hosts file without removing it.\nIt will be listed as \"off\" while it is disabled.\n\nUsage:\n  hostctl disable [profiles] [flags]\n\nFlags:\n      --all             Disable all profiles\n  -h, --help            help for disable\n      --only            Enable all other profiles\n  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)",
        "enable": "Enables an existing profile.\nIt will be listed as \"on\" while it is enabled.\n\nUsage:\n  hostctl enable [profiles] [flags]\n\nFlags:\n      --all             Enable all profiles\n  -h, --help            help for enable\n      --only            Disable all other profiles\n  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)",
        "remove": "Completely remove a profile content from your hosts file.\nIt cannot be undone unless you have a backup and restore it.\n\nIf you want to remove a profile but would like to use it later,\nuse 'hosts disable' instead.\n\nUsage:\n  hostctl remove [profiles] [flags]\n  hostctl remove [command]\n\nAliases:\n  remove, rm [profiles] [flags]\n\nAvailable Commands:\n  domains     Remove domains from your hosts file.\n\nFlags:\n      --all    Remove all profiles\n  -h, --help   help for remove",
        "replace": "Reads from a file and set content to a profile in your hosts file.\nIf the profile already exists it will be overwritten.\n\nUsage:\n  hostctl replace [profile] [flags]\n\nFlags:\n  -f, --from string   file to read\n  -h, --help          help for replace",
        "restore": "Reads from a file and replace the content of your hosts file.\n\nWARNING: the complete hosts file will be overwritten with the backup data.\n\nUsage:\n  hostctl restore [flags]\n\nFlags:\n      --from string   The file to restore from\n  -h, --help          help for restore",
        "toggle": "Alternates between on/off status of an existing profile.\n\nUsage:\n  hostctl toggle [flags]\n\nFlags:\n  -h, --help            help for toggle\n  -w, --wait duration   Toggles a profile for a specific amount of time (default -1ns)",
        "sync": "Reads IPs and names from some local system and sync it with a profile in your hosts file.\n\nUsage:\n  hostctl sync [command]\n\nAvailable Commands:\n  docker         Sync your Docker containers IPs with a profile.\n  docker-compose Sync your docker-compose containers IPs with a profile.\n\nFlags:\n  -h, --help            help for sync\n  -w, --wait duration   Enables a profile for a specific amount of time (default -1ns)",
    }.get(cmd, ROOT_HELP)

def parse_global(argv):
    opts = {"host_file": "/etc/hosts", "out": "table", "quiet": False, "columns": None}
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("--host-file",):
            i += 1; opts["host_file"] = argv[i] if i < len(argv) else ""
        elif a.startswith("--host-file="):
            opts["host_file"] = a.split("=", 1)[1]
        elif a in ("-o", "--out"):
            i += 1; opts["out"] = argv[i] if i < len(argv) else "table"
        elif a.startswith("--out="):
            opts["out"] = a.split("=", 1)[1]
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True
        elif a == "--raw":
            opts["out"] = "raw"
        elif a in ("-c", "--column"):
            i += 1; opts["columns"] = argv[i] if i < len(argv) else ""
        elif a.startswith("--column="):
            opts["columns"] = a.split("=", 1)[1]
        elif a == "--no-color":
            pass
        elif a in ("-v", "--version"):
            print("hostctl version dev"); sys.exit(0)
        elif a in ("-h", "--help"):
            rest.append(a)
        else:
            rest.append(a)
        i += 1
    return opts, rest

def info(opts):
    if not opts["quiet"] and opts["out"] != "json":
        print(f"[ℹ] Using hosts file: {opts['host_file']}\n")

def success(opts, msg):
    if not opts["quiet"] and opts["out"] != "json":
        print(f"[✔] {msg}\n")

def err(msg, code=1):
    print(f"[✖] error: {msg}", file=sys.stderr)
    sys.exit(code)

def ensure_file(path):
    if not os.path.exists(path):
        open(path, "a").close()

def read_hosts(path):
    ensure_file(path)
    text = open(path).read()
    if BANNER in text:
        before, after = text.split(BANNER, 1)
    else:
        before, after = text, ""
    defaults = []
    for line in before.splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split()
        if len(parts) >= 2:
            for h in parts[1:]:
                defaults.append({"Profile": "default", "Status": "on", "IP": parts[0], "Host": h})
    profiles = []
    cur = None
    for raw in after.splitlines():
        line = raw.rstrip("\n")
        m = re.match(r"\s*#\s*profile\.(on|off)\s+(.+?)\s*$", line)
        if m:
            cur = {"name": m.group(2), "status": m.group(1), "entries": []}
            profiles.append(cur)
            continue
        if re.match(r"\s*#\s*end\s*$", line):
            cur = None
            continue
        if cur is None:
            continue
        s = line.strip()
        if cur["status"] == "off" and s.startswith("#"):
            s = s[1:].strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split()
        if len(parts) >= 2:
            for h in parts[1:]:
                cur["entries"].append((parts[0], h))
    return before, profiles, defaults

def write_hosts(path, before, profiles):
    before = before.rstrip("\n")
    chunks = []
    if before:
        chunks.append(before)
        chunks.append("")
    chunks.append(BANNER)
    chunks.append("")
    for p in profiles:
        chunks.append(f"# profile.{p['status']} {p['name']}")
        for ip, host in p["entries"]:
            prefix = "# " if p["status"] == "off" else ""
            chunks.append(f"{prefix}{ip} {host}")
        chunks.append("# end")
    data = "\n".join(chunks)
    if profiles:
        data += "\n"
    else:
        data += "\n"
    open(path, "w").write(data)

def rows_for(defaults, profiles, include_default=True, names=None, status=None):
    rows = []
    if include_default and not status:
        rows.extend(defaults)
    for p in profiles:
        if names and p["name"] not in names:
            continue
        if status and p["status"] != status:
            continue
        for ip, host in p["entries"]:
            rows.append({"Profile": p["name"], "Status": p["status"], "IP": ip, "Host": host})
    return rows

def status_rows(profiles, names=None):
    out = []
    seen = set()
    for p in profiles:
        if p["name"] in seen or (names and p["name"] not in names):
            continue
        seen.add(p["name"])
        out.append({"Profile": p["name"], "Status": p["status"]})
    return out

def selected(row, cols):
    mapping = {"profile": "Profile", "status": "Status", "ip": "IP", "domain": "Host", "host": "Host"}
    keys = [mapping.get(c.strip().lower(), c.strip()) for c in cols] if cols else list(row.keys())
    return keys

def print_rows(rows, opts, kind="list"):
    if opts["quiet"]:
        return
    if kind == "status":
        default_keys = ["Profile", "Status"]
        heads = {"Profile": "PROFILE", "Status": "STATUS"}
    else:
        default_keys = ["Profile", "Status", "IP", "Host"]
        heads = {"Profile": "PROFILE", "Status": "STATUS", "IP": "IP", "Host": "DOMAIN"}
    keys = [k for k in (selected({k:k for k in default_keys}, opts["columns"].split(",")) if opts["columns"] else default_keys) if k in default_keys]
    if opts["out"] == "json":
        print(json.dumps([{k: r.get(k, "") for k in keys} for r in rows], separators=(",", ":")))
        return
    table = [[r.get(k, "") for k in keys] for r in rows]
    headers = [heads[k] for k in keys]
    widths = [len(h) for h in headers]
    for r in table:
        for i, v in enumerate(r):
            widths[i] = max(widths[i], len(v))
    def cell(v, w, head=False):
        if head:
            return v.center(w)
        return v.ljust(w)
    def hcell(v, w):
        pad = max(0, w + 2 - len(v))
        return (" " * (pad // 2)) + v + (" " * ((pad + 1) // 2))
    def rcell(v, w):
        return " " + v.ljust(w) + " "
    if opts["out"] == "raw":
        print("\t".join(headers[i].ljust(widths[i] + (1 if i == len(keys) - 1 else 0)) for i in range(len(keys))))
        for r in table:
            print("\t".join(cell(r[i], widths[i]) for i in range(len(keys))) + "\t")
    elif opts["out"] == "markdown":
        print("|" + "|".join(hcell(headers[i], widths[i]) for i in range(len(keys))) + "|")
        sep = "|-" + "-|-".join("-" * widths[i] for i in range(len(keys))) + "-|"
        print(sep)
        last_prof = None
        for r in table:
            if last_prof is not None and kind == "list" and r[0] != last_prof:
                print(sep)
            print("|" + "|".join(rcell(r[i], widths[i]) for i in range(len(keys))) + "|")
            last_prof = r[0] if r else None
    else:
        border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
        print(border)
        print("|" + "|".join(hcell(headers[i], widths[i]) for i in range(len(keys))) + "|")
        print(border)
        last_prof = None
        for r in table:
            if last_prof is not None and kind == "list" and r[0] != last_prof:
                print(border)
            print("|" + "|".join(rcell(r[i], widths[i]) for i in range(len(keys))) + "|")
            last_prof = r[0] if r else None
        print(border)
    if opts["out"] == "table":
        print()

def read_entries_file(path):
    if not path:
        err("required flag(s) \"from\" not set")
    entries = []
    for line in open(path):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        parts = s.split()
        if len(parts) >= 2:
            for h in parts[1:]:
                entries.append((parts[0], h))
    return entries

def find_profile(profiles, name):
    for p in profiles:
        if p["name"] == name:
            return p
    return None

def parse_local(args, flags_with_vals):
    vals, rest = {}, []
    skip = {"--wait", "-w"}
    i = 0
    while i < len(args):
        a = args[i]
        if a in flags_with_vals:
            i += 1; vals[a.lstrip("-")] = args[i] if i < len(args) else ""
        elif a.startswith("--") and "=" in a and a.split("=",1)[0] in flags_with_vals:
            k, v = a.split("=", 1); vals[k.lstrip("-")] = v
        elif a in skip:
            i += 1
        elif a in ("--all", "--only", "--prefix"):
            vals[a.lstrip("-")] = True
        elif a in ("-h", "--help"):
            vals["help"] = True
        else:
            rest.append(a)
        i += 1
    return vals, rest

def add_domains(opts, args):
    vals, rest = parse_local(args, {"--ip"})
    if vals.get("help"):
        print(HELPS["add domains"]); return
    if len(rest) < 2:
        err("accepts 2 arg(s), received %d" % len(rest))
    before, profiles, defaults = read_hosts(opts["host_file"])
    p = find_profile(profiles, rest[0])
    if not p:
        p = {"name": rest[0], "status": "on", "entries": []}; profiles.append(p)
    ip = vals.get("ip", "127.0.0.1")
    for h in rest[1:]:
        p["entries"].append((ip, h))
    write_hosts(opts["host_file"], before, profiles)
    info(opts); success(opts, "Domains '%s' added." % ", ".join(rest[1:]))
    print_rows(rows_for([], [p], include_default=False), opts)

def cmd_add(opts, args, replace=False):
    if args and args[0] in ("domains", "domain"):
        return add_domains(opts, args[1:])
    if "-h" in args or "--help" in args:
        print(HELPS["add"]); return
    vals, rest = parse_local(args, {"-f", "--from"})
    if not rest:
        err("missing profile name")
    if len(rest) > 1:
        err("specify only one profile")
    src = vals.get("f") or vals.get("from") or ""
    if not src:
        info(opts)
        err("open : no such file or directory")
    entries = read_entries_file(src)
    before, profiles, defaults = read_hosts(opts["host_file"])
    p = find_profile(profiles, rest[0])
    if not p:
        p = {"name": rest[0], "status": "on", "entries": []}; profiles.append(p)
    if replace:
        p["entries"] = []
    p["entries"].extend(entries)
    write_hosts(opts["host_file"], before, profiles)
    info(opts)
    print_rows(rows_for([], [p], include_default=False), opts)

def cmd_list(opts, args):
    if "-h" in args or "--help" in args:
        print(HELPS["list"]); return
    status = None
    if args and args[0] in ("enabled", "on"):
        status = "on"; args = args[1:]
    elif args and args[0] in ("disabled", "off"):
        status = "off"; args = args[1:]
    before, profiles, defaults = read_hosts(opts["host_file"])
    info(opts)
    print_rows(rows_for(defaults, profiles, include_default=(status is None), names=set(args) if args else None, status=status), opts)

def cmd_status(opts, args):
    if "-h" in args or "--help" in args:
        print(HELPS["status"]); return
    before, profiles, defaults = read_hosts(opts["host_file"])
    info(opts)
    print_rows(status_rows(profiles, set(args) if args else None), opts, "status")

def cmd_enable_disable(opts, args, newstatus):
    if "-h" in args or "--help" in args:
        print(short_help("enable" if newstatus == "on" else "disable")); return
    vals, rest = parse_local(args, set())
    before, profiles, defaults = read_hosts(opts["host_file"])
    targets = [p["name"] for p in profiles] if vals.get("all") else rest
    if not targets:
        err("missing profile name")
    existing = {p["name"] for p in profiles}
    if any(t not in existing for t in targets):
        info(opts)
        err("unknown profile name")
    for p in profiles:
        if vals.get("only"):
            p["status"] = newstatus if p["name"] in targets else ("off" if newstatus == "on" else "on")
        elif p["name"] in targets:
            p["status"] = newstatus
    write_hosts(opts["host_file"], before, profiles)
    info(opts)
    print_rows(rows_for([], profiles, include_default=False, names=set(targets) if targets else None), opts)

def cmd_toggle(opts, args):
    if "-h" in args or "--help" in args:
        print(short_help("toggle")); return
    before, profiles, defaults = read_hosts(opts["host_file"])
    targets = set(args)
    if not targets:
        err("missing profile name")
    existing = {p["name"] for p in profiles}
    if any(t not in existing for t in targets):
        info(opts)
        err("unknown profile name")
    for p in profiles:
        if not targets or p["name"] in targets:
            p["status"] = "off" if p["status"] == "on" else "on"
    write_hosts(opts["host_file"], before, profiles)
    info(opts)
    print_rows(rows_for([], profiles, include_default=False, names=targets if targets else None), opts)

def cmd_remove(opts, args):
    if args and args[0] in ("domains", "domain"):
        vals, rest = parse_local(args[1:], set())
        if len(rest) < 2: err("accepts at least 2 arg(s), received %d" % len(rest))
        before, profiles, defaults = read_hosts(opts["host_file"])
        p = find_profile(profiles, rest[0])
        if p:
            remove = set(rest[1:])
            p["entries"] = [(ip,h) for ip,h in p["entries"] if h not in remove]
        write_hosts(opts["host_file"], before, profiles)
        info(opts); success(opts, "Domains '%s' removed." % ", ".join(rest[1:]))
        if p: print_rows(rows_for([], [p], include_default=False), opts)
        return
    if "-h" in args or "--help" in args:
        print(short_help("remove")); return
    vals, rest = parse_local(args, set())
    before, profiles, defaults = read_hosts(opts["host_file"])
    names = [p["name"] for p in profiles] if vals.get("all") else rest
    if not names:
        err("missing profile name")
    existing = {p["name"] for p in profiles}
    if any(n not in existing for n in names):
        info(opts)
        err("unknown profile name")
    profiles = [p for p in profiles if p["name"] not in set(names)]
    write_hosts(opts["host_file"], before, profiles)
    info(opts); success(opts, "Profile(s) '%s' removed." % ", ".join(names))

def cmd_backup(opts, args):
    if "-h" in args or "--help" in args:
        print(short_help("backup")); return
    vals, rest = parse_local(args, {"--path"})
    path = vals.get("path", "/workspace")
    os.makedirs(path, exist_ok=True)
    dst = os.path.join(path, os.path.basename(opts["host_file"]) + "." + datetime.datetime.now().strftime("%Y%m%d"))
    shutil.copyfile(opts["host_file"], dst)
    if not opts["quiet"]:
        print(dst)

def cmd_restore(opts, args):
    if "-h" in args or "--help" in args:
        print(short_help("restore")); return
    vals, rest = parse_local(args, {"--from"})
    src = vals.get("from")
    if not src:
        err("required flag(s) \"from\" not set")
    shutil.copyfile(src, opts["host_file"])

def main():
    opts, args = parse_global(sys.argv[1:])
    if not args:
        print(ROOT_HELP); return
    if args[0] == "help":
        args = args[1:] + ["--help"]
        if not args or args == ["--help"]:
            print(ROOT_HELP); return
    cmd = "remove" if args[0] == "rm" else args[0]
    rest = args[1:]
    if cmd in ("-h", "--help"):
        print(ROOT_HELP)
    elif cmd == "add":
        cmd_add(opts, rest)
    elif cmd == "replace":
        if "-h" in rest or "--help" in rest:
            print(short_help("replace"))
        else:
            cmd_add(opts, rest, replace=True)
    elif cmd == "list":
        cmd_list(opts, rest)
    elif cmd == "status":
        cmd_status(opts, rest)
    elif cmd == "enable":
        cmd_enable_disable(opts, rest, "on")
    elif cmd == "disable":
        cmd_enable_disable(opts, rest, "off")
    elif cmd == "toggle":
        cmd_toggle(opts, rest)
    elif cmd == "remove":
        cmd_remove(opts, rest)
    elif cmd == "backup":
        cmd_backup(opts, rest)
    elif cmd == "restore":
        cmd_restore(opts, rest)
    elif cmd == "sync":
        if "-h" in rest or "--help" in rest or not rest:
            print(short_help("sync"))
        else:
            err("sync backend is unavailable")
    else:
        err(f'unknown command "{cmd}" for "hostctl"')

if __name__ == "__main__":
    main()
