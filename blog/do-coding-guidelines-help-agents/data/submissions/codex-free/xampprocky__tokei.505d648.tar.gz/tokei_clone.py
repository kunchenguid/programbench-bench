#!/usr/bin/env python3
import argparse
import fnmatch
import json
import os
import sys
from collections import OrderedDict, defaultdict


VERSION = "tokei 14.0.0 compiled with serialization support: json"

LANGS = {
    "py": ("Python", "#", None, None),
    "pyw": ("Python", "#", None, None),
    "rs": ("Rust", "//", "/*", "*/"),
    "c": ("C", "//", "/*", "*/"),
    "h": ("C Header", "//", "/*", "*/"),
    "cc": ("C++", "//", "/*", "*/"),
    "cpp": ("C++", "//", "/*", "*/"),
    "cxx": ("C++", "//", "/*", "*/"),
    "hpp": ("C++ Header", "//", "/*", "*/"),
    "hxx": ("C++ Header", "//", "/*", "*/"),
    "java": ("Java", "//", "/*", "*/"),
    "js": ("JavaScript", "//", "/*", "*/"),
    "jsx": ("JSX", "//", "/*", "*/"),
    "ts": ("TypeScript", "//", "/*", "*/"),
    "tsx": ("TSX", "//", "/*", "*/"),
    "go": ("Go", "//", "/*", "*/"),
    "cs": ("C#", "//", "/*", "*/"),
    "css": ("CSS", None, "/*", "*/"),
    "scss": ("Sass", "//", "/*", "*/"),
    "php": ("PHP", "//", "/*", "*/"),
    "swift": ("Swift", "//", "/*", "*/"),
    "kt": ("Kotlin", "//", "/*", "*/"),
    "kts": ("Kotlin", "//", "/*", "*/"),
    "scala": ("Scala", "//", "/*", "*/"),
    "sql": ("SQL", "--", "/*", "*/"),
    "sh": ("Shell", "#", None, None),
    "bash": ("BASH", "#", None, None),
    "zsh": ("Zsh", "#", None, None),
    "fish": ("Fish", "#", None, None),
    "rb": ("Ruby", "#", None, None),
    "pl": ("Perl", "#", None, None),
    "pm": ("Perl", "#", None, None),
    "r": ("R", "#", None, None),
    "lua": ("Lua", "--", "--[[", "]]"),
    "hs": ("Haskell", "--", "{-", "-}"),
    "ex": ("Elixir", "#", None, None),
    "exs": ("Elixir", "#", None, None),
    "erl": ("Erlang", "%", None, None),
    "hrl": ("Erlang", "%", None, None),
    "vim": ("Vim script", '"', None, None),
    "md": ("Markdown", None, None, None),
    "markdown": ("Markdown", None, None, None),
    "txt": ("Text", None, None, None),
    "json": ("JSON", None, None, None),
    "jsonc": ("JSON", "//", "/*", "*/"),
    "toml": ("TOML", "#", None, None),
    "yaml": ("YAML", "#", None, None),
    "yml": ("YAML", "#", None, None),
    "xml": ("XML", None, "<!--", "-->"),
    "svg": ("SVG", None, "<!--", "-->"),
    "html": ("HTML", None, "<!--", "-->"),
    "htm": ("HTML", None, "<!--", "-->"),
    "vue": ("Vue", "//", "<!--", "-->"),
    "svelte": ("Svelte", "//", "<!--", "-->"),
    "dockerfile": ("Dockerfile", "#", None, None),
    "makefile": ("Makefile", "#", None, None),
    "mk": ("Makefile", "#", None, None),
    "cmake": ("CMake", "#", None, None),
    "gradle": ("Groovy", "//", "/*", "*/"),
    "dart": ("Dart", "//", "/*", "*/"),
    "zig": ("Zig", "//", "/*", "*/"),
    "nim": ("Nim", "#", None, None),
    "jl": ("Julia", "#", "#=", "=#"),
}

SPECIAL_NAMES = {
    "Dockerfile": LANGS["dockerfile"],
    "Makefile": LANGS["makefile"],
    "CMakeLists.txt": LANGS["cmake"],
    "Rakefile": ("Rakefile", "#", None, None),
    "Gemfile": ("Ruby", "#", None, None),
    "Cargo.lock": ("TOML", "#", None, None),
}

FENCE_LANGS = {
    "rust": "rs", "python": "py", "py": "py", "javascript": "js", "js": "js",
    "typescript": "ts", "ts": "ts", "c": "c", "cpp": "cpp", "c++": "cpp",
    "java": "java", "go": "go", "shell": "sh", "sh": "sh", "bash": "bash",
    "json": "json", "toml": "toml", "yaml": "yaml", "html": "html", "css": "css",
}


class Stat:
    def __init__(self):
        self.blanks = 0
        self.code = 0
        self.comments = 0
        self.files = 0
        self.reports = []
        self.children = defaultdict(list)

    @property
    def lines(self):
        return self.blanks + self.code + self.comments + sum(
            r["stats"]["blanks"] + r["stats"]["code"] + r["stats"]["comments"]
            for reports in self.children.values()
            for r in reports
        )

    def own_lines(self):
        return self.blanks + self.code + self.comments


def strip_strings(s):
    out = []
    quote = None
    esc = False
    for ch in s:
        if quote:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == quote:
                quote = None
            out.append(" ")
        else:
            if ch in ("'", '"', "`"):
                quote = ch
                out.append(" ")
            else:
                out.append(ch)
    return "".join(out)


def count_lines(text, lang, line_comment, block_start, block_end):
    stat = Stat()
    in_block = False
    for raw in text.splitlines():
        line = raw.rstrip("\r")
        if not line.strip():
            stat.blanks += 1
            continue
        if lang in ("Markdown", "Text"):
            stat.comments += 1 if lang == "Markdown" else 0
            stat.code += 1 if lang == "Text" else 0
            continue
        if lang in ("JSON",):
            stat.code += 1
            continue

        scan = strip_strings(line)
        has_code = False
        only_comment = False
        i = 0
        while i < len(scan):
            if in_block:
                end = scan.find(block_end, i) if block_end else -1
                only_comment = True
                if end < 0:
                    i = len(scan)
                    break
                in_block = False
                i = end + len(block_end)
                continue
            if scan[i].isspace():
                i += 1
                continue
            if line_comment and scan.startswith(line_comment, i):
                if not has_code:
                    only_comment = True
                break
            if block_start and scan.startswith(block_start, i):
                if not has_code:
                    only_comment = True
                end = scan.find(block_end, i + len(block_start)) if block_end else -1
                if end < 0:
                    in_block = True
                    break
                i = end + len(block_end)
                continue
            has_code = True
            i += 1
        if has_code:
            stat.code += 1
        elif only_comment or in_block:
            stat.comments += 1
        else:
            stat.code += 1
    return stat


def html_with_embeds(text):
    parent_text = []
    js_text = []
    in_script = False
    for line in text.splitlines():
        lower = line.lower()
        if "<script" in lower:
            in_script = True
            parent_text.append(line)
            continue
        if "</script" in lower:
            in_script = False
            parent_text.append(line)
            continue
        if in_script:
            js_text.append(line)
        else:
            parent_text.append(line)
    html = count_lines("\n".join(parent_text), "HTML", None, "<!--", "-->")
    blobs = {}
    if js_text:
        blobs["JavaScript"] = count_lines("\n".join(js_text), "JavaScript", "//", "/*", "*/")
    return html, blobs


def markdown_with_embeds(text):
    parent = []
    child_lang = None
    child_lines = []
    blobs = {}
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            marker_parts = stripped[3:].strip().split(None, 1)
            marker_lang = marker_parts[0].lower() if marker_parts else ""
            if child_lang:
                spec = LANGS.get(FENCE_LANGS.get(child_lang, child_lang))
                if spec:
                    lang, lc, bs, be = spec
                    blobs[lang] = count_lines("\n".join(child_lines), lang, lc, bs, be)
                child_lang = None
                child_lines = []
            elif marker_lang:
                child_lang = marker_lang
            parent.append(line)
            continue
        if child_lang:
            child_lines.append(line)
        else:
            parent.append(line)
    stat = count_lines("\n".join(parent), "Markdown", None, None, None)
    return stat, blobs


def detect(path):
    name = os.path.basename(path)
    if name in SPECIAL_NAMES:
        return SPECIAL_NAMES[name]
    ext = name.rsplit(".", 1)[-1] if "." in name else name
    return LANGS.get(ext.lower())


def should_skip(path, root, args, ignore_patterns):
    name = os.path.basename(path)
    rel = os.path.relpath(path, root)
    if not args.hidden and name.startswith("."):
        return True
    if name in (".git", ".hg", ".svn"):
        return True
    for pat in args.exclude:
        if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(path, pat):
            return True
    for pat in ignore_patterns:
        if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(rel, pat):
            return True
    return False


def read_ignore_file(path):
    pats = []
    try:
        with open(path, encoding="utf-8", errors="ignore") as f:
            for line in f:
                s = line.strip()
                if s and not s.startswith("#") and not s.startswith("!"):
                    pats.append(s.rstrip("/"))
    except OSError:
        pass
    return pats


def iter_files(inputs, args):
    roots = inputs or ["."]
    files = []
    for root in roots:
        if not os.path.exists(root):
            print(f"Error: '{root}' not found.", file=sys.stderr)
            sys.exit(1)
        if os.path.isfile(root):
            files.append(root)
            continue
        base = root
        inherited = []
        if not args.no_ignore and not args.no_ignore_dot:
            inherited += read_ignore_file(os.path.join(base, ".ignore"))
            inherited += read_ignore_file(os.path.join(base, ".tokeignore"))
        if not args.no_ignore and not args.no_ignore_vcs:
            inherited += read_ignore_file(os.path.join(base, ".gitignore"))
        for cur, dirs, names in os.walk(root):
            dirs[:] = [d for d in dirs if not should_skip(os.path.join(cur, d), base, args, inherited)]
            for name in names:
                p = os.path.join(cur, name)
                if not should_skip(p, base, args, inherited):
                    files.append(p)
    return sorted(dict.fromkeys(files))


def analyze(paths, args):
    langs = OrderedDict()
    streaming = []
    unknown = []
    type_filter = set()
    if args.types:
        type_filter = {x.strip() for x in args.types.split(",") if x.strip()}
    for path in paths:
        spec = detect(path)
        if not spec:
            unknown.append(path)
            continue
        lang, line, bstart, bend = spec
        if type_filter and lang not in type_filter:
            continue
        try:
            with open(path, encoding="utf-8", errors="ignore") as f:
                text = f.read()
        except OSError:
            continue
        blobs = {}
        if lang in ("HTML", "Vue", "Svelte"):
            stat, blobs = html_with_embeds(text)
        elif lang == "Markdown":
            stat, blobs = markdown_with_embeds(text)
        else:
            stat = count_lines(text, lang, line, bstart, bend)
        stat.files = 1
        report = {"stats": stat, "name": path}
        if lang not in langs:
            langs[lang] = Stat()
        agg = langs[lang]
        agg.files += 1
        agg.blanks += stat.blanks
        agg.code += stat.code
        agg.comments += stat.comments
        agg.reports.append(report)
        for child_lang, child_stat in blobs.items():
            child_report = {"stats": child_stat, "name": path}
            agg.children[child_lang].append(child_report)
            streaming.append((child_lang, path, child_stat))
        streaming.append((lang, path, stat))
    if args.verbose and unknown:
        for p in unknown:
            print(f"Unknown extension: {p}", file=sys.stderr)
    return langs, streaming


def sort_langs(langs, args):
    items = list(langs.items())
    if args.sort or args.rsort:
        key = args.sort or args.rsort
        def val(item):
            s = item[1]
            return s.files if key == "files" else getattr(s, key)
        items.sort(key=lambda it: (val(it), it[0]), reverse=bool(args.rsort))
    else:
        items.sort(key=lambda it: it[0])
    return items


def fmt_num(n, style):
    s = str(n)
    sep = {"commas": ",", "dots": ".", "underscores": "_"}.get(style)
    if not sep:
        return s
    parts = []
    while len(s) > 3:
        parts.append(s[-3:])
        s = s[:-3]
    parts.append(s)
    return sep.join(reversed(parts))


def print_table(langs, args):
    width = args.columns or 81
    heavy = "━" * width
    light = "─" * width
    print(heavy)
    print(f" {'Language':<20}{'Files':>8}{'Lines':>13}{'Code':>13}{'Comments':>13}{'Blanks':>13}")
    print(heavy)
    total_files = total_lines = total_code = total_comments = total_blanks = 0
    for lang, s in sort_langs(langs, args):
        child_lines = sum(r["stats"].own_lines() for rs in s.children.values() for r in rs)
        child_code = sum(r["stats"].code for rs in s.children.values() for r in rs)
        child_comments = sum(r["stats"].comments for rs in s.children.values() for r in rs)
        child_blanks = sum(r["stats"].blanks for rs in s.children.values() for r in rs)
        display_lines = s.own_lines() + child_lines
        display_code = s.code + child_code
        display_comments = s.comments + child_comments
        display_blanks = s.blanks + child_blanks
        print_row(lang, s.files, s.own_lines(), s.code, s.comments, s.blanks, args)
        if s.children and not args.compact:
            for cl, reports in sorted(s.children.items()):
                cs = Stat()
                cs.files = len(reports)
                for r in reports:
                    st = r["stats"]; cs.blanks += st.blanks; cs.code += st.code; cs.comments += st.comments
                print_row("|- " + cl, cs.files, cs.own_lines(), cs.code, cs.comments, cs.blanks, args)
            print_row("(Total)", "", display_lines, display_code, display_comments, display_blanks, args)
        if args.files:
            print(light)
            for r in s.reports:
                st = r["stats"]
                print_row(r["name"], "", st.own_lines(), st.code, st.comments, st.blanks, args)
            if s.children and not args.compact:
                for cl, reports in sorted(s.children.items()):
                    for r in reports:
                        st = r["stats"]
                        print_row("|- " + cl, "", st.own_lines(), st.code, st.comments, st.blanks, args)
        total_files += s.files
        total_lines += display_lines
        total_code += display_code
        total_comments += display_comments
        total_blanks += display_blanks
    print(heavy)
    print_row("Total", total_files, total_lines, total_code, total_comments, total_blanks, args)
    print(heavy)


def print_row(name, files, lines, code, comments, blanks, args):
    def n(x):
        return "" if x == "" else fmt_num(x, args.num_format)
    print(f" {name:<20}{n(files):>8}{n(lines):>13}{n(code):>13}{n(comments):>13}{n(blanks):>13}")


def stat_json(st):
    return OrderedDict([("blanks", st.blanks), ("code", st.code), ("comments", st.comments), ("blobs", OrderedDict())])


def report_json(report, blobs=None):
    data = stat_json(report["stats"])
    if blobs:
        data["blobs"] = OrderedDict((k, stat_json(v)) for k, v in sorted(blobs.items()))
    return OrderedDict([("stats", data), ("name", report["name"])])


def print_json(langs):
    out = OrderedDict()
    total = Stat()
    total_children = OrderedDict()
    for lang, s in sorted(langs.items()):
        reports = []
        for r in s.reports:
            blobs = {cl: cr["stats"] for cl, rs in s.children.items() for cr in rs if cr["name"] == r["name"]}
            reports.append(report_json(r, blobs))
        children = OrderedDict()
        for cl, rs in sorted(s.children.items()):
            children[cl] = [report_json(r) for r in rs]
        out[lang] = OrderedDict([
            ("blanks", s.blanks), ("code", s.code), ("comments", s.comments),
            ("reports", reports), ("children", children), ("inaccurate", False)
        ])
        child_code = sum(r["stats"].code for rs in s.children.values() for r in rs)
        child_comments = sum(r["stats"].comments for rs in s.children.values() for r in rs)
        child_blanks = sum(r["stats"].blanks for rs in s.children.values() for r in rs)
        total.files += s.files
        total.blanks += s.blanks + child_blanks
        total.code += s.code + child_code
        total.comments += s.comments + child_comments
        total_children[lang] = reports
    out["Total"] = OrderedDict([
        ("blanks", total.blanks), ("code", total.code), ("comments", total.comments),
        ("reports", []), ("children", total_children), ("inaccurate", False)
    ])
    print(json.dumps(out, separators=(",", ":")))


def print_stream(streaming, mode):
    if mode == "simple":
        print("# language                                        path                                          lines         code       comments      blanks   ")
        print("########## ################################################################################ ############ ############ ############ ############")
        for lang, path, st in sorted(streaming, key=lambda x: (x[0], x[1])):
            print(f"{lang:>10} {path:<80}{st.own_lines():>12}{st.code:>13}{st.comments:>13}{st.blanks:>13}")
    else:
        for lang, path, st in sorted(streaming, key=lambda x: (x[0], x[1])):
            obj = {"language": lang, "stats": {"name": path, "stats": stat_json(st)}}
            print(json.dumps(obj, separators=(",", ":")))


def parse_json_langs(data):
    obj = json.loads(data)
    langs = OrderedDict()
    for lang, v in obj.items():
        if lang == "Total":
            continue
        s = Stat()
        s.blanks = int(v.get("blanks", 0))
        s.code = int(v.get("code", 0))
        s.comments = int(v.get("comments", 0))
        for rr in v.get("reports", []):
            stj = rr.get("stats", {})
            st = Stat()
            st.blanks = int(stj.get("blanks", 0))
            st.code = int(stj.get("code", 0))
            st.comments = int(stj.get("comments", 0))
            s.reports.append({"stats": st, "name": rr.get("name", "")})
        s.files = len(s.reports)
        for cl, reports in v.get("children", {}).items():
            for rr in reports:
                stj = rr.get("stats", {})
                st = Stat()
                st.blanks = int(stj.get("blanks", 0))
                st.code = int(stj.get("code", 0))
                st.comments = int(stj.get("comments", 0))
                s.children[cl].append({"stats": st, "name": rr.get("name", "")})
        langs[lang] = s
    return langs


def merge_langs(dst, src):
    for lang, s in src.items():
        if lang not in dst:
            dst[lang] = s
            continue
        d = dst[lang]
        d.files += s.files
        d.blanks += s.blanks
        d.code += s.code
        d.comments += s.comments
        d.reports.extend(s.reports)
        for cl, reports in s.children.items():
            d.children[cl].extend(reports)


def print_languages():
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
    print("┃ Language                              Extensions                     ┃")
    print("┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃")
    rows = [
        ("BASH", "bash"), ("C", "c, ec, pgc"), ("C Header", "h"),
        ("C++", "cc, cpp, cxx, c++"), ("CSS", "css"), ("Go", "go"),
        ("HTML", "html, htm"), ("Java", "java"), ("JavaScript", "js"),
        ("JSON", "json"), ("Markdown", "md, markdown"), ("Python", "py, pyw"),
        ("Rust", "rs"), ("Shell", "sh"), ("TOML", "toml"),
        ("TypeScript", "ts"), ("XML", "xml"), ("YAML", "yaml, yml"),
    ]
    for lang, exts in rows:
        print(f"┃ {lang:<37} {exts:<30} ┃")
    print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")


def build_parser():
    p = argparse.ArgumentParser(
        prog="executable",
        description="Count your code, quickly.\nSupport this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky",
        formatter_class=argparse.RawTextHelpFormatter,
        add_help=False,
    )
    p.add_argument("-c", "--columns", type=int)
    p.add_argument("-e", "--exclude", action="append", default=[])
    p.add_argument("-f", "--files", action="store_true")
    p.add_argument("-i", "--input", dest="file_input")
    p.add_argument("--hidden", action="store_true")
    p.add_argument("-l", "--languages", action="store_true")
    p.add_argument("--no-ignore", action="store_true")
    p.add_argument("--no-ignore-parent", action="store_true")
    p.add_argument("--no-ignore-dot", action="store_true")
    p.add_argument("--no-ignore-vcs", action="store_true")
    p.add_argument("-o", "--output")
    p.add_argument("--streaming", choices=["simple", "json"])
    p.add_argument("-s", "--sort", choices=["files", "lines", "blanks", "code", "comments"])
    p.add_argument("-r", "--rsort", choices=["files", "lines", "blanks", "code", "comments"])
    p.add_argument("-t", "--types")
    p.add_argument("-C", "--compact", action="store_true")
    p.add_argument("-n", "--num-format", dest="num_format", choices=["commas", "dots", "plain", "underscores"], default="plain")
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("input", nargs="*")
    return p


def print_help():
    print("""Count your code, quickly.
Support this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky

Usage: executable [OPTIONS] [input]...

Arguments:
  [input]...  The path(s) to the file or directory to be counted. (default current directory)

Options:
  -c, --columns <columns>              Sets a strict column width of the output, only available for
                                       terminal output.
  -e, --exclude <exclude>              Ignore all files & directories matching the pattern.
  -f, --files                          Will print out statistics on individual files.
  -i, --input <file_input>             Gives statistics from a previous tokei run. Can be given a
                                       file path, or "stdin" to read from stdin.
      --hidden                         Count hidden files.
  -l, --languages                      Prints out supported languages and their extensions.
      --no-ignore                      Don't respect ignore files (.gitignore, .ignore, etc.).
  -o, --output <output>                Outputs Tokei in a specific format.
      --streaming <streaming>          prints records as simple lines or as Json for batch processing
                                       [possible values: simple, json]
  -s, --sort <sort>                    Sort languages based on column [possible values: files,
                                       lines, blanks, code, comments]
  -r, --rsort <rsort>                  Reverse sort languages based on column [possible values:
                                       files, lines, blanks, code, comments]
  -t, --types <types>                  Filters output by language type, separated by a comma.
  -C, --compact                        Do not print statistics about embedded languages.
  -n, --num-format <num_format_style>  Format of printed numbers.
  -v, --verbose...                     Set log output level
  -h, --help                           Print help
  -V, --version                        Print version""")


def main():
    parser = build_parser()
    args = parser.parse_args()
    if args.help:
        print_help(); return 0
    if args.version:
        print(VERSION); return 0
    if args.languages:
        print_languages(); return 0
    if args.output and args.output != "json":
        print(f"error: invalid value '{args.output}' for '--output <output>': This version of tokei was compiled without any '{args.output}' serialization support, to enable serialization, reinstall tokei with the features flag.", file=sys.stderr)
        return 2
    prior = None
    if args.file_input:
        data = sys.stdin.read() if args.file_input == "stdin" else open(args.file_input, encoding="utf-8", errors="ignore").read()
        try:
            prior = parse_json_langs(data)
        except Exception:
            if not args.input:
                print(data.strip())
                return 0
    paths = iter_files(args.input, args)
    langs, streaming = analyze(paths, args)
    if prior is not None:
        merge_langs(prior, langs)
        langs = prior
    if args.streaming:
        print_stream(streaming, args.streaming)
    elif args.output == "json":
        print_json(langs)
    else:
        print_table(langs, args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
