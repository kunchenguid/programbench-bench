#!/usr/bin/env python3
import glob
import html
import os
import sys


HELP = """svgbob 0.7.6
SvgBobRus is an ascii to svg converter

USAGE:
    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]

FLAGS:
    -h, --help       Prints help information
    -s               parse an inline string
    -V, --version    Prints version information

OPTIONS:
        --background <background>        backdrop background will be filled with this color (default: 'white')
        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')
        --font-family <font-family>      text will be rendered with this font (default: 'arial')
        --font-size <font-size>          text will be rendered with this font size (default: 14)
    -o, --output <output>                where to write svg output [default: STDOUT]
        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor
                                         (default: 1)
        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')
        --stroke-width <stroke-width>    stroke width for all lines (default: 2)

ARGS:
    <input>    svgbob text file or inline string to parse [default: STDIN]

SUBCOMMANDS:
    build    Batch convert files to svg.
    help     Prints this message or the help of the given subcommand(s)
"""

BUILD_HELP = """executable-build 0.0.1
Batch convert files to svg.

USAGE:
    executable build [OPTIONS]

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob
    -o, --outdir <outdir>    set dir of svg files
"""


class Opts:
    def __init__(self):
        self.background = "white"
        self.fill = "black"
        self.stroke = "black"
        self.font_family = "Iosevka Fixed, monospace"
        self.font_size = 14.0
        self.stroke_width = 2.0
        self.scale = 1.0
        self.output = None
        self.inline = False
        self.input = None


def fmt(n):
    if abs(n - round(n)) < 1e-9:
        return str(int(round(n)))
    return ("%g" % n)


def esc(s):
    return html.escape(s, quote=False)


def style(opts):
    sw = fmt(opts.stroke_width * opts.scale)
    fs = fmt(opts.font_size * opts.scale)
    return f"""  <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {{
  stroke: {opts.stroke};
  stroke-width: {sw};
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}}

.svgbob text {{
  white-space: pre;
  fill: {opts.stroke};
  font-family: {opts.font_family};
  font-size: {fs}px;
}}

.svgbob rect.backdrop {{
  stroke: none;
  fill: {opts.background};
}}

.svgbob .broken {{
  stroke-dasharray: 8;
}}

.svgbob .filled {{
  fill: {opts.fill};
}}

.svgbob .bg_filled {{
  fill: {opts.background};
  stroke-width: 1;
}}

.svgbob .nofill {{
  fill: {opts.background};
}}

.svgbob .end_marked_arrow {{
  marker-end: url(#arrow);
}}

.svgbob .start_marked_arrow {{
  marker-start: url(#arrow);
}}

.svgbob .end_marked_diamond {{
  marker-end: url(#diamond);
}}

.svgbob .start_marked_diamond {{
  marker-start: url(#diamond);
}}

.svgbob .end_marked_circle {{
  marker-end: url(#circle);
}}

.svgbob .start_marked_circle {{
  marker-start: url(#circle);
}}

.svgbob .end_marked_open_circle {{
  marker-end: url(#open_circle);
}}

.svgbob .start_marked_open_circle {{
  marker-start: url(#open_circle);
}}

.svgbob .end_marked_big_open_circle {{
  marker-end: url(#big_open_circle);
}}

.svgbob .start_marked_big_open_circle {{
  marker-start: url(#big_open_circle);
}}

</style>"""


DEFS = """  <defs>
    <marker id="arrow" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,0 0,4 4,2 0,0"></polygon>
    </marker>
    <marker id="diamond" viewBox="-2 -2 8 8" refX="4" refY="2" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <polygon points="0,2 2,0 4,2 2,4 0,2"></polygon>
    </marker>
    <marker id="circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="filled"></circle>
    </marker>
    <marker id="open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="2" class="bg_filled"></circle>
    </marker>
    <marker id="big_open_circle" viewBox="0 0 8 8" refX="4" refY="4" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
      <circle cx="4" cy="4" r="3" class="bg_filled"></circle>
    </marker>
  </defs>"""


def cell(lines, r, c):
    if r < 0 or r >= len(lines) or c < 0 or c >= len(lines[r]):
        return " "
    return lines[r][c]


def is_h(ch):
    return ch in "-=+<>o*."


def is_v(ch):
    return ch in "|+^v*o."


def render_text_run(row, start, text, s):
    return f'  <text x="{fmt((start*8+2)*s)}" y="{fmt((row*16+12)*s)}" >{esc(text)}</text>'


def render(input_text, opts):
    raw_lines = input_text.splitlines()
    if input_text.endswith("\n") and raw_lines and raw_lines[-1] == "":
        raw_lines = raw_lines[:-1]
    if not raw_lines:
        raw_lines = [""]
    lines = [line.rstrip("\n") for line in raw_lines]
    rows = len(lines)
    cols = max([len(x) for x in lines] + [1])
    s = opts.scale
    width = (cols * 8 + 8) * s
    height = (rows * 16 + 16) * s
    consumed = set()
    elems = []

    # Rectangles made from +---+ / | | / +---+.
    for r1, line in enumerate(lines):
        for c1, ch in enumerate(line):
            if ch not in "+./\\":
                continue
            for c2 in range(c1 + 2, len(line)):
                if cell(lines, r1, c2) not in "+.\\":
                    continue
                mid = line[c1 + 1:c2]
                if mid and all(ch in "-=." for ch in mid):
                    for r2 in range(r1 + 2, rows):
                        if cell(lines, r2, c1) in "+\\/" and cell(lines, r2, c2) in "+/\\": 
                            bottom = "".join(cell(lines, r2, c) for c in range(c1 + 1, c2))
                            if bottom and all(ch in "-=." for ch in bottom):
                                ok = True
                                for rr in range(r1 + 1, r2):
                                    if cell(lines, rr, c1) != "|" or cell(lines, rr, c2) != "|":
                                        ok = False
                                        break
                                if ok:
                                    x = (c1 * 8 + 4) * s
                                    y = (r1 * 16 + 8) * s
                                    w = (c2 - c1) * 8 * s
                                    h = (r2 - r1) * 16 * s
                                    elems.append(f'  <rect x="{fmt(x)}" y="{fmt(y)}" width="{fmt(w)}" height="{fmt(h)}" class="solid nofill" rx="0"></rect>')
                                    for rr in range(r1, r2 + 1):
                                        for cc in range(c1, c2 + 1):
                                            if rr in (r1, r2) or cc in (c1, c2):
                                                consumed.add((rr, cc))
                                    break

    # Horizontal arrows/lines.
    for r, line in enumerate(lines):
        c = 0
        while c < len(line):
            if (line[c] in "<o" or line[c] in "-=") and (r, c) not in consumed:
                start = c
                left = False
                open_left = False
                if line[c] == "<":
                    left = True
                    c += 1
                elif line[c] == "o" and c + 1 < len(line) and line[c + 1] in "-=":
                    open_left = True
                    c += 1
                if c < len(line) and line[c] in "-=":
                    while c < len(line) and line[c] in "-=":
                        c += 1
                    right = c < len(line) and line[c] == ">"
                    open_right = c < len(line) and line[c] == "o"
                    if right or open_right:
                        c += 1
                    if c - start >= 2:
                        y = (r * 16 + 8) * s
                        x1 = (start * 8 + (8 if left else 4 if open_left else 0)) * s
                        x2 = ((c - 1) * 8 if right else (c - 1) * 8 + 4 if open_right else c * 8) * s
                        if left:
                            elems.append(f'  <polygon points="{fmt((start*8+8)*s)},{fmt((r*16+4)*s)} {fmt(start*8*s)},{fmt(y)} {fmt((start*8+8)*s)},{fmt((r*16+12)*s)}" class="filled"></polygon>')
                        cls = "solid"
                        if open_left:
                            cls += " end_marked_open_circle"
                            x1 = ((start + 2) * 8) * s
                            elems.append(f'  <line x1="{fmt(x1)}" y1="{fmt(y)}" x2="{fmt((start*8+4)*s)}" y2="{fmt(y)}" class="{cls}"></line>')
                            cls = "solid"
                            x1 = ((start + 2) * 8) * s
                        if x2 > x1:
                            elems.append(f'  <line x1="{fmt(x1)}" y1="{fmt(y)}" x2="{fmt(x2)}" y2="{fmt(y)}" class="{cls}"></line>')
                        if right:
                            x = (c - 1) * 8
                            elems.append(f'  <polygon points="{fmt(x*s)},{fmt((r*16+4)*s)} {fmt((x+8)*s)},{fmt(y)} {fmt(x*s)},{fmt((r*16+12)*s)}" class="filled"></polygon>')
                        for cc in range(start, c):
                            consumed.add((r, cc))
                        continue
                c = start + 1
            else:
                c += 1

    # Plain horizontal line runs not already part of rectangles/arrows.
    for r, line in enumerate(lines):
        c = 0
        while c < len(line):
            if line[c] in "-=+" and (r, c) not in consumed:
                start = c
                while c < len(line) and line[c] in "-=+" and (r, c) not in consumed:
                    c += 1
                if c - start >= 2:
                    elems.append(f'  <line x1="{fmt(start*8*s)}" y1="{fmt((r*16+8)*s)}" x2="{fmt(c*8*s)}" y2="{fmt((r*16+8)*s)}" class="solid"></line>')
                    for cc in range(start, c):
                        consumed.add((r, cc))
            else:
                c += 1

    # Vertical arrows/lines.
    for c in range(cols):
        r = 0
        while r < rows:
            ch = cell(lines, r, c)
            if ch in "^|" and (r, c) not in consumed:
                start = r
                up = ch == "^"
                if up:
                    r += 1
                while r < rows and cell(lines, r, c) in "|+" and (r, c) not in consumed:
                    r += 1
                down = r < rows and cell(lines, r, c) == "v"
                if down:
                    r += 1
                if r - start >= 1 and (up or down or r - start >= 2):
                    x = (c * 8 + 4) * s
                    if up:
                        elems.append(f'  <polygon points="{fmt(c*8*s)},{fmt((start*16+12)*s)} {fmt(x)},{fmt(start*16*s)} {fmt((c*8+8)*s)},{fmt((start*16+12)*s)}" class="filled"></polygon>')
                    y1 = (start * 16 + (12 if up else 0)) * s
                    y2 = ((r - 1) * 16 + (4 if down else 8)) * s
                    elems.append(f'  <line x1="{fmt(x)}" y1="{fmt(y1)}" x2="{fmt(x)}" y2="{fmt(y2)}" class="solid"></line>')
                    if down:
                        rr = r - 1
                        elems.append(f'  <polygon points="{fmt(c*8*s)},{fmt((rr*16+4)*s)} {fmt((c*8+8)*s)},{fmt((rr*16+4)*s)} {fmt(x)},{fmt((rr*16+16)*s)}" class="filled"></polygon>')
                    for rr in range(start, r):
                        consumed.add((rr, c))
                    continue
            r += 1

    # Remaining text, grouped over non-space, non-consumed cells.
    for r, line in enumerate(lines):
        c = 0
        while c < len(line):
            if line[c] != " " and (r, c) not in consumed:
                start = c
                txt = []
                while c < len(line) and line[c] != " " and (r, c) not in consumed:
                    txt.append(line[c])
                    c += 1
                elems.append(render_text_run(r, start, "".join(txt), s))
            else:
                c += 1

    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{fmt(width)}" height="{fmt(height)}" class="svgbob">']
    out.append(style(opts))
    out.append(DEFS)
    out.append(f'  <rect class="backdrop" x="0" y="0" width="{fmt(width)}" height="{fmt(height)}"></rect>')
    out.extend(elems)
    out.append("</svg>")
    return "\n".join(out) + "\n"


def parse_value(args, i):
    if i + 1 >= len(args):
        print(f"error: The argument '{args[i]}' requires a value but none was supplied", file=sys.stderr)
        sys.exit(1)
    return args[i + 1], i + 2


def parse_args(args):
    opts = Opts()
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print("svgbob 0.7.6")
            sys.exit(0)
        if a == "-s" or a == "--inline":
            opts.inline = True
            i += 1
        elif a in ("-o", "--output"):
            opts.output, i = parse_value(args, i)
        elif a == "--background":
            opts.background, i = parse_value(args, i)
        elif a == "--fill-color":
            opts.fill, i = parse_value(args, i)
        elif a == "--stroke-color":
            opts.stroke, i = parse_value(args, i)
        elif a == "--font-family":
            opts.font_family, i = parse_value(args, i)
        elif a == "--font-size":
            v, i = parse_value(args, i)
            opts.font_size = float(v)
        elif a == "--stroke-width":
            v, i = parse_value(args, i)
            opts.stroke_width = float(v)
        elif a == "--scale":
            v, i = parse_value(args, i)
            opts.scale = float(v)
        elif a == "help":
            if i + 1 < len(args) and args[i + 1] == "build":
                print(BUILD_HELP, end="")
            else:
                print(HELP, end="")
            sys.exit(0)
        elif opts.input is None:
            opts.input = a
            i += 1
        else:
            i += 1
    return opts


def run_build(args):
    if any(a in ("-h", "--help") for a in args):
        print(BUILD_HELP, end="")
        return 0
    if any(a in ("-V", "--version") for a in args):
        print("executable-build 0.0.1")
        return 0
    inp = None
    outdir = None
    i = 0
    while i < len(args):
        if args[i] in ("-i", "--input") and i + 1 < len(args):
            inp = args[i + 1]
            i += 2
        elif args[i] in ("-o", "--outdir") and i + 1 < len(args):
            outdir = args[i + 1]
            i += 2
        else:
            i += 1
    if not inp:
        return 0
    outdir = outdir or "."
    os.makedirs(outdir, exist_ok=True)
    opts = Opts()
    for path in glob.glob(inp):
        with open(path, "r", encoding="utf-8") as f:
            data = f.read()
        base = os.path.splitext(os.path.basename(path))[0] + ".svg"
        with open(os.path.join(outdir, base), "w", encoding="utf-8") as f:
            f.write(render(data, opts))
    return 0


def main():
    args = sys.argv[1:]
    if args and args[0] == "build":
        return run_build(args[1:])
    opts = parse_args(args)
    if opts.inline:
        data = opts.input or ""
    elif opts.input:
        with open(opts.input, "r", encoding="utf-8") as f:
            data = f.read()
    else:
        data = sys.stdin.read()
    output = render(data, opts)
    if opts.output:
        with open(opts.output, "w", encoding="utf-8") as f:
            f.write(output)
    else:
        sys.stdout.write(output)
    return 0


if __name__ == "__main__":
    sys.exit(main())
