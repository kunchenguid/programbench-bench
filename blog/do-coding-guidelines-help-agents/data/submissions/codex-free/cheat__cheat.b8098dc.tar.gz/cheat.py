#!/usr/bin/env python3
import os
import re
import sys
import subprocess
import glob
from pathlib import Path

VERSION = "5.1.0"
DESC = """cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember."""

HELP = DESC + """

Usage:
  cheat [cheatsheet] [flags]

Examples:
  To initialize a config file:
    mkdir -p ~/.config/cheat && cheat --init > ~/.config/cheat/conf.yml

  To view the tar cheatsheet:
    cheat tar

  To edit (or create) the foo cheatsheet:
    cheat -e foo

  To edit (or create) the foo/bar cheatsheet on the "work" cheatpath:
    cheat -p work -e foo/bar

  To view all cheatsheet directories:
    cheat -d

  To list all available cheatsheets:
    cheat -l

  To briefly list all cheatsheets whose titles match "apt":
    cheat -b apt

  To list all tags in use:
    cheat -T

  To list available cheatsheets that are tagged as "personal":
    cheat -l -t personal

  To search for "ssh" among all cheatsheets, and colorize matches:
    cheat -c -s ssh

  To search (by regex) for cheatsheets that contain an IP address:
    cheat -c -r -s '(?:[0-9]{1,3}\\.){3}[0-9]{1,3}'

  To remove (delete) the foo/bar cheatsheet:
    cheat --rm foo/bar

  To update all git-backed cheatpaths:
    cheat --update

  To view the configuration file path:
    cheat --conf

  To generate shell completions (bash, zsh, fish, powershell):
    cheat --completion bash

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number
"""


def default_config():
    home = str(Path.home())
    return f"""---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: EDITOR_PATH

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
# Options are available here:
#   https://github.com/alecthomas/chroma/tree/master/styles
style: monokai

# Which 'chroma' "formatter" should be applied?
# One of: "terminal", "terminal256", "terminal16m"
formatter: terminal256

# Through which pager should output be piped?
# 'less -FRX' is recommended on Unix systems
# 'more' is recommended on Windows
pager: /usr/bin/pager

# The paths at which cheatsheets are available. Tags associated with a cheatpath
# are automatically attached to all cheatsheets residing on that path.
#
# Whenever cheatsheets share the same title (like 'tar'), the most local
# cheatsheets (those which come later in this file) take precedence over the
# less local sheets. This allows you to create your own "overides" for
# "upstream" cheatsheets.
#
# But what if you want to view the "upstream" cheatsheets instead of your own?
# Cheatsheets may be filtered by 'tags' in combination with the '--tag' flag.
# 
# Example: 'cheat tar --tag=community' will display the 'tar' cheatsheet that
# is tagged as 'community' rather than your own.
#
# Paths that come earlier are considered to be the most "global", and paths
# that come later are considered to be the most "local". The most "local" paths
# take precedence.
#
# See: https://github.com/cheat/cheat/blob/master/doc/cheat.1.md#cheatpaths
cheatpaths:

  # Cheatsheets that are tagged "personal" are stored here by default:
  - name: personal
    path: {home}/.config/cheat/cheatsheets/personal
    tags: [ personal ]
    readonly: false

  # Cheatsheets that are tagged "work" are stored here by default:
  - name: work
    path: {home}/.config/cheat/cheatsheets/work
    tags: [ work ]
    readonly: false

  # Community cheatsheets (https://github.com/cheat/cheatsheets):
  # To install: git clone https://github.com/cheat/cheatsheets {home}/.config/cheat/cheatsheets/community
  #- name: community
  #  path: {home}/.config/cheat/cheatsheets/community
  #  tags: [ community ]
  #  readonly: true

  # You can also use glob patterns to automatically load cheatsheets from all
  # directories that match.
  #
  # Example: overload cheatsheets for projects under ~/src/github.com/example/*/
  #- name: example-projects
  #  path: ~/src/github.com/example/**/.cheat
  #  tags: [ example ]
  #  readonly: true
"""


def parse_list(val):
    val = val.strip()
    if val.startswith("[") and val.endswith("]"):
        inner = val[1:-1].strip()
        if not inner:
            return []
        return [x.strip().strip("'\"") for x in inner.split(",") if x.strip()]
    return [val.strip("'\"")] if val else []


def find_config():
    if os.environ.get("CHEAT_CONFIG_PATH"):
        return os.path.expanduser(os.environ["CHEAT_CONFIG_PATH"])
    xdg = os.environ.get("XDG_CONFIG_HOME")
    candidates = []
    if xdg:
        candidates.append(os.path.join(xdg, "cheat", "conf.yml"))
    home = str(Path.home())
    candidates += [
        os.path.join(home, ".config", "cheat", "conf.yml"),
        os.path.join(home, ".cheat", "conf.yml"),
        "/etc/cheat/conf.yml",
    ]
    for c in candidates:
        if os.path.exists(os.path.expanduser(c)):
            return os.path.expanduser(c)
    return candidates[0] if candidates else os.path.join(str(Path.home()), ".config/cheat/conf.yml")


def load_config(path):
    cfg = {"editor": "vi", "pager": "", "colorize": "false", "cheatpaths": []}
    if not os.path.exists(path):
        print("A config file was not found. Would you like to create one now? [Y/n]: failed to create config: failed to prompt: EOF")
        sys.exit(1)
    current = None
    in_cheatpaths = False
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.rstrip("\n")
            stripped = line.strip()
            if not stripped or stripped == "---" or stripped.startswith("#"):
                continue
            if stripped == "cheatpaths:":
                in_cheatpaths = True
                continue
            if not in_cheatpaths:
                if ":" in stripped:
                    k, v = stripped.split(":", 1)
                    cfg[k.strip()] = v.strip().strip("'\"")
                continue
            indent = len(line) - len(line.lstrip(" "))
            if stripped.startswith("- ") and indent <= 2:
                current = {"name": "", "path": "", "tags": [], "readonly": False}
                cfg["cheatpaths"].append(current)
                rest = stripped[2:].strip()
                if rest and ":" in rest:
                    k, v = rest.split(":", 1)
                    current[k.strip()] = v.strip().strip("'\"")
            elif current is not None and ":" in stripped:
                k, v = stripped.split(":", 1)
                k = k.strip()
                v = v.strip()
                if k == "tags":
                    if v.strip() == "":
                        current[k] = []
                    else:
                        current[k] = parse_list(v)
                elif k == "readonly":
                    current[k] = v.lower() == "true"
                else:
                    current[k] = os.path.expanduser(os.path.expandvars(v.strip("'\"")))
            elif current is not None and stripped.startswith("-") and isinstance(current.get("tags"), list):
                item = stripped[1:].strip().strip("'\"")
                if item and "tags" in current:
                    current["tags"].append(item)
    return cfg


def nearest_dotcheat():
    p = Path.cwd().resolve()
    for cur in [p] + list(p.parents):
        c = cur / ".cheat"
        if c.is_dir():
            return {"name": "", "path": str(c), "tags": [], "readonly": False}
    return None


def strip_frontmatter(text):
    tags, syntax = [], ""
    if text.startswith("---\n") or text == "---":
        lines = text.splitlines(True)
        end = None
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                end = i
                break
        if end is not None:
            for l in lines[1:end]:
                s = l.strip()
                if ":" in s:
                    k, v = s.split(":", 1)
                    if k.strip() == "tags":
                        tags = parse_list(v)
                    elif k.strip() == "syntax":
                        syntax = v.strip().strip("'\"")
            text = "".join(lines[end + 1:])
    return text, tags, syntax


def iter_sheets(paths):
    sheets = []
    for idx, cp in enumerate(paths):
        root = cp.get("path", "")
        if not root or not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.startswith(".")]
            for fn in filenames:
                if fn.startswith(".") or "." in fn:
                    continue
                full = os.path.join(dirpath, fn)
                rel = os.path.relpath(full, root).replace(os.sep, "/")
                try:
                    text = Path(full).read_text(encoding="utf-8", errors="replace")
                except Exception:
                    text = ""
                body, ftags, syntax = strip_frontmatter(text)
                tags = sorted(set(cp.get("tags", []) + ftags))
                sheets.append({"title": rel, "file": full, "body": body, "tags": tags, "cp": cp, "idx": idx, "syntax": syntax})
    sheets.sort(key=lambda s: (s["title"], s["file"]))
    return sheets


def filtered_sheets(cfg, path_name=None, tag=None):
    paths = []
    for p in cfg["cheatpaths"]:
        path = p.get("path", "")
        if any(ch in path for ch in "*?["):
            for expanded in glob.glob(path, recursive=True):
                q = dict(p)
                q["path"] = expanded
                paths.append(q)
        else:
            paths.append(p)
    local = nearest_dotcheat()
    if local:
        paths.append(local)
    if path_name:
        found = [p for p in paths if p.get("name") == path_name]
        if not found:
            print(f"invalid option --path: cheatpath does not exist: {path_name}")
            sys.exit(1)
        paths = found
    sheets = iter_sheets(paths)
    if tag:
        sheets = [s for s in sheets if tag in s["tags"]]
    return sheets, paths


def print_table(rows, headers):
    widths = []
    for i, h in enumerate(headers):
        widths.append(max([len(h)] + [len(r[i]) for r in rows]))
    print(" ".join(headers[i].ljust(widths[i]) for i in range(len(headers))).rstrip())
    for r in rows:
        print(" ".join(r[i].ljust(widths[i]) for i in range(len(headers))).rstrip())


def list_sheets(cfg, brief=False, term=None, path_name=None, tag=None):
    sheets, _ = filtered_sheets(cfg, path_name, tag)
    if term:
        sheets = [s for s in sheets if term in s["title"]]
    if brief:
        rows = [[s["title"], ",".join(s["tags"])] for s in sheets]
        print_table(rows, ["title:", "tags:"])
    else:
        rows = [[s["title"], s["file"], ",".join(s["tags"])] for s in sheets]
        print_table(rows, ["title:", "file:", "tags:"])


def select_sheet(cfg, title, path_name=None, tag=None):
    sheets, _ = filtered_sheets(cfg, path_name, tag)
    matches = [s for s in sheets if s["title"] == title]
    if not matches:
        return None
    return sorted(matches, key=lambda s: s["idx"])[-1]


def write_body(body):
    sys.stdout.write(body)


def list_dirs(cfg, path_name=None):
    _, paths = filtered_sheets(cfg, path_name, None)
    pairs = [(p.get("name", ""), p.get("path", "")) for p in paths]
    w = max([len(x[0]) for x in pairs] + [0])
    for name, path in pairs:
        if name:
            print(f"{name + ':':<{w+1}} {path}")
        else:
            print(f"{path}")


def search(cfg, phrase, regex=False, path_name=None, tag=None):
    sheets, _ = filtered_sheets(cfg, path_name, tag)
    pat = None
    if regex:
        try:
            pat = re.compile(phrase)
        except re.error as e:
            print(f"invalid regex: {e}")
            return 1
    for s in sheets:
        ok = bool(pat.search(s["body"])) if pat else (phrase in s["body"])
        if ok:
            name = s["title"]
            cpname = s["cp"].get("name", "")
            if cpname:
                name += f" ({cpname})"
            print(name)
            for line in s["body"].splitlines():
                print("\t" + line)
    return 0


def edit_sheet(cfg, title, path_name=None):
    _, paths = filtered_sheets(cfg, path_name, None)
    target = None
    if path_name:
        candidates = paths
    else:
        candidates = list(reversed(paths))
    for p in candidates:
        if not p.get("readonly"):
            target = p
            break
    if not target:
        print("failed to get writeable path: no writeable cheatpaths found")
        return 1
    existing = select_sheet(cfg, title, path_name, None)
    dest = os.path.join(target["path"], title)
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    if existing and existing["file"] != dest and not os.path.exists(dest):
        Path(dest).write_text(Path(existing["file"]).read_text(encoding="utf-8", errors="replace"), encoding="utf-8")
    elif not os.path.exists(dest):
        Path(dest).write_text("", encoding="utf-8")
    editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or cfg.get("editor") or "vi"
    try:
        return subprocess.call([editor, dest])
    except Exception as e:
        print(f"failed to open editor: {e}")
        return 1


def remove_sheet(cfg, title, path_name=None):
    s = select_sheet(cfg, title, path_name, None)
    if not s:
        print(f"No cheatsheet found for '{title}'.")
        return 2
    if s["cp"].get("readonly"):
        print(f"cannot remove readonly cheatsheet: {title}")
        return 1
    os.remove(s["file"])
    return 0


def update(cfg, path_name=None):
    _, paths = filtered_sheets(cfg, path_name, None)
    for p in paths:
        name = p.get("name", "")
        root = p.get("path", "")
        prefix = f"{name}: " if name else ""
        if not os.path.isdir(os.path.join(root, ".git")):
            print(prefix + "skipped (not a git repository)")
        else:
            try:
                subprocess.call(["git", "-C", root, "pull", "--ff-only"])
            except Exception:
                print(prefix + "failed")
    return 0


def completion(shell):
    if shell not in ("bash", "zsh", "fish", "powershell"):
        print(f"unsupported shell: {shell} (valid: bash, zsh, fish, powershell)")
        return 1
    if shell == "bash":
        print("# bash completion V2 for cheat                                -*- shell-script -*-")
        print("complete -o default -F __start_cheat cheat")
    elif shell == "zsh":
        print("#compdef cheat")
    elif shell == "fish":
        print("complete -c cheat")
    else:
        print("Register-ArgumentCompleter -CommandName cheat -ScriptBlock {}")
    return 0


def parse_args(argv):
    opts = {"args": []}
    takes = {"-e": "edit", "--edit": "edit", "-p": "path", "--path": "path", "-s": "search", "--search": "search", "-t": "tag", "--tag": "tag", "--rm": "rm", "--completion": "completion"}
    bools = {"-a": "all", "--all": "all", "-b": "brief", "--brief": "brief", "-c": "colorize", "--colorize": "colorize", "-d": "directories", "--directories": "directories", "-h": "help", "--help": "help", "--init": "init", "-l": "list", "--list": "list", "-r": "regex", "--regex": "regex", "-T": "tags", "--tags": "tags", "-u": "update", "--update": "update", "-v": "version", "--version": "version", "--conf": "conf"}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in takes:
            if i + 1 >= len(argv):
                print(f"flag needs an argument: {a}")
                sys.exit(1)
            opts[takes[a]] = argv[i + 1]
            i += 2
        elif any(a.startswith(k + "=") for k in takes if k.startswith("--")):
            k, v = a.split("=", 1)
            opts[takes[k]] = v
            i += 1
        elif a in bools:
            opts[bools[a]] = True
            i += 1
        elif a.startswith("-") and not a.startswith("--") and len(a) > 2:
            for ch in a[1:]:
                flag = "-" + ch
                if flag not in bools:
                    print(f"unknown shorthand flag: '{ch}' in {a}")
                    sys.exit(1)
                opts[bools[flag]] = True
            i += 1
        elif a.startswith("-"):
            print(f"unknown flag: {a}")
            sys.exit(1)
        else:
            opts["args"].append(a)
            i += 1
    return opts


def main(argv):
    opts = parse_args(argv)
    if opts.get("help"):
        print(HELP)
        return 0
    if opts.get("version"):
        print(VERSION)
        return 0
    if opts.get("init"):
        sys.stdout.write(default_config())
        return 0
    if opts.get("completion") is not None:
        return completion(opts["completion"])
    conf = find_config()
    if opts.get("conf"):
        print(conf)
        return 0
    cfg = load_config(conf)
    path_name = opts.get("path")
    tag = opts.get("tag")
    if opts.get("directories"):
        list_dirs(cfg, path_name)
        return 0
    if opts.get("tags"):
        sheets, _ = filtered_sheets(cfg, path_name, tag)
        for t in sorted(set(x for s in sheets for x in s["tags"])):
            print(t)
        return 0
    if opts.get("update"):
        return update(cfg, path_name)
    if opts.get("rm"):
        return remove_sheet(cfg, opts["rm"], path_name)
    if opts.get("edit"):
        return edit_sheet(cfg, opts["edit"], path_name)
    if opts.get("search") is not None:
        return search(cfg, opts["search"], bool(opts.get("regex")), path_name, tag)
    if opts.get("list") or opts.get("brief"):
        term = opts["args"][0] if opts["args"] else None
        list_sheets(cfg, bool(opts.get("brief")), term, path_name, tag)
        return 0
    if opts["args"]:
        title = opts["args"][0]
        s = select_sheet(cfg, title, path_name, tag)
        if not s:
            print(f"No cheatsheet found for '{title}'.")
            return 2
        write_body(s["body"])
        return 0
    print(HELP)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
