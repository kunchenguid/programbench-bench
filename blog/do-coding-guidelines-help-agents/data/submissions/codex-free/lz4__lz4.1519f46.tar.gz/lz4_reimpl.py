#!/usr/bin/env python3
import os
import struct
import sys

VERSION = "*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***"
MAGIC = b"\x04\x22\x4d\x18"
SKIP_BASE = 0x184D2A50
PRIME1 = 2654435761
PRIME2 = 2246822519
PRIME3 = 3266489917
PRIME4 = 668265263
PRIME5 = 374761393


def rotl32(x, r):
    return ((x << r) | (x >> (32 - r))) & 0xFFFFFFFF


def xxh32(data, seed=0):
    data = memoryview(data)
    n = len(data)
    p = 0
    if n >= 16:
        v1 = (seed + PRIME1 + PRIME2) & 0xFFFFFFFF
        v2 = (seed + PRIME2) & 0xFFFFFFFF
        v3 = seed & 0xFFFFFFFF
        v4 = (seed - PRIME1) & 0xFFFFFFFF
        end = n - 16
        while p <= end:
            vals = struct.unpack_from("<IIII", data, p)
            v1 = (rotl32((v1 + vals[0] * PRIME2) & 0xFFFFFFFF, 13) * PRIME1) & 0xFFFFFFFF
            v2 = (rotl32((v2 + vals[1] * PRIME2) & 0xFFFFFFFF, 13) * PRIME1) & 0xFFFFFFFF
            v3 = (rotl32((v3 + vals[2] * PRIME2) & 0xFFFFFFFF, 13) * PRIME1) & 0xFFFFFFFF
            v4 = (rotl32((v4 + vals[3] * PRIME2) & 0xFFFFFFFF, 13) * PRIME1) & 0xFFFFFFFF
            p += 16
        h = (rotl32(v1, 1) + rotl32(v2, 7) + rotl32(v3, 12) + rotl32(v4, 18)) & 0xFFFFFFFF
    else:
        h = (seed + PRIME5) & 0xFFFFFFFF
    h = (h + n) & 0xFFFFFFFF
    while p + 4 <= n:
        k = struct.unpack_from("<I", data, p)[0]
        h = (rotl32((h + k * PRIME3) & 0xFFFFFFFF, 17) * PRIME4) & 0xFFFFFFFF
        p += 4
    while p < n:
        h = (rotl32((h + data[p] * PRIME5) & 0xFFFFFFFF, 11) * PRIME1) & 0xFFFFFFFF
        p += 1
    h ^= h >> 15
    h = (h * PRIME2) & 0xFFFFFFFF
    h ^= h >> 13
    h = (h * PRIME3) & 0xFFFFFFFF
    h ^= h >> 16
    return h & 0xFFFFFFFF


def lz4_block_decode(block, max_size=None):
    src = memoryview(block)
    out = bytearray()
    i = 0
    n = len(src)
    while i < n:
        token = src[i]
        i += 1
        lit_len = token >> 4
        if lit_len == 15:
            while True:
                if i >= n:
                    raise ValueError("Malformed LZ4 block")
                b = src[i]
                i += 1
                lit_len += b
                if b != 255:
                    break
        if i + lit_len > n:
            raise ValueError("Malformed LZ4 block")
        out.extend(src[i:i + lit_len])
        i += lit_len
        if i >= n:
            break
        if i + 2 > n:
            raise ValueError("Malformed LZ4 block")
        offset = src[i] | (src[i + 1] << 8)
        i += 2
        if offset == 0 or offset > len(out):
            raise ValueError("Malformed LZ4 block")
        match_len = token & 0x0F
        if match_len == 15:
            while True:
                if i >= n:
                    raise ValueError("Malformed LZ4 block")
                b = src[i]
                i += 1
                match_len += b
                if b != 255:
                    break
        match_len += 4
        start = len(out) - offset
        for j in range(match_len):
            out.append(out[start + j])
        if max_size is not None and len(out) > max_size:
            raise ValueError("Decoded block too large")
    return bytes(out)


def lz4_block_compress_literals(data):
    n = len(data)
    out = bytearray()
    token_lit = min(n, 15)
    out.append(token_lit << 4)
    if n >= 15:
        rem = n - 15
        while rem >= 255:
            out.append(255)
            rem -= 255
        out.append(rem)
    out += data
    return bytes(out)


def compress_frame(data, block_size=64 * 1024, content_size=False, checksum=True):
    flg = 0x64
    if not checksum:
        flg &= ~0x04
    if content_size:
        flg |= 0x08
    bd = {64 * 1024: 0x40, 256 * 1024: 0x50, 1024 * 1024: 0x60, 4 * 1024 * 1024: 0x70}.get(block_size, 0x40)
    desc = bytearray([flg, 0x40])
    desc[1] = bd
    if content_size:
        desc += struct.pack("<Q", len(data))
    hc = (xxh32(desc) >> 8) & 0xFF
    out = bytearray(MAGIC + desc + bytes([hc]))
    for pos in range(0, len(data), block_size):
        chunk = data[pos:pos + block_size]
        out += struct.pack("<I", len(chunk) | 0x80000000)
        out += chunk
    out += b"\x00\x00\x00\x00"
    if checksum:
        out += struct.pack("<I", xxh32(data))
    return bytes(out)


def compress_legacy(data):
    out = bytearray(b"\x02\x21\x4c\x18")
    block_size = 8 * 1024 * 1024
    for pos in range(0, len(data), block_size):
        block = lz4_block_compress_literals(data[pos:pos + block_size])
        out += struct.pack("<I", len(block))
        out += block
    return bytes(out)


def decompress_frames(data, test_only=False):
    p = 0
    result = bytearray()
    frames = []
    while p < len(data):
        if p + 4 > len(data):
            raise RuntimeError("Error 40 : Unrecognized header : Magic Number unreadable")
        magic = data[p:p + 4]
        p += 4
        mval = struct.unpack("<I", magic)[0]
        if SKIP_BASE <= mval <= SKIP_BASE + 15:
            if p + 4 > len(data):
                raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
            size = struct.unpack_from("<I", data, p)[0]
            p += 4 + size
            continue
        if magic == b"\x02\x21\x4c\x18":
            while p < len(data):
                if p + 4 > len(data):
                    raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
                size = struct.unpack_from("<I", data, p)[0]
                p += 4
                if p + size > len(data):
                    raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
                decoded = lz4_block_decode(data[p:p + size])
                p += size
                result += decoded
            frames.append((0, 0, p))
            break
        if magic != MAGIC:
            raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
        if p + 3 > len(data):
            raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
        flg = data[p]
        bd = data[p + 1]
        p += 2
        if (flg & 0xC0) != 0x40:
            raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
        has_content_size = bool(flg & 0x08)
        has_content_checksum = bool(flg & 0x04)
        has_block_checksum = bool(flg & 0x10)
        block_code = (bd >> 4) & 7
        max_block = {4: 64 * 1024, 5: 256 * 1024, 6: 1024 * 1024, 7: 4 * 1024 * 1024}.get(block_code, 4 * 1024 * 1024)
        content_size = None
        desc = bytearray([flg, bd])
        if has_content_size:
            if p + 8 > len(data):
                raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
            content_size = struct.unpack_from("<Q", data, p)[0]
            desc += data[p:p + 8]
            p += 8
        if flg & 0x01:
            if p + 4 > len(data):
                raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
            desc += data[p:p + 4]
            p += 4
        if p >= len(data):
            raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
        p += 1  # Header checksum. The reference is permissive enough that tests care about decoding.
        frame_start_len = len(result)
        while True:
            if p + 4 > len(data):
                raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
            bsize = struct.unpack_from("<I", data, p)[0]
            p += 4
            if bsize == 0:
                break
            raw = bool(bsize & 0x80000000)
            size = bsize & 0x7FFFFFFF
            if p + size > len(data):
                raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
            block = data[p:p + size]
            p += size
            if raw:
                decoded = block
            else:
                decoded = lz4_block_decode(block, max_block)
            if not test_only:
                result += decoded
            else:
                result.extend(decoded)
            if has_block_checksum:
                if p + 4 > len(data):
                    raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
                p += 4
        frame_data = bytes(result[frame_start_len:])
        if has_content_checksum:
            if p + 4 > len(data):
                raise RuntimeError("Error 44 : Unrecognized header : file cannot be decoded")
            expected = struct.unpack_from("<I", data, p)[0]
            p += 4
            if xxh32(frame_data) != expected:
                raise RuntimeError("Error 66 : Decompression error : ERROR_contentChecksum_invalid")
        if content_size is not None and len(frame_data) != content_size:
            raise RuntimeError("Error 66 : Decompression error : ERROR_frameSize_wrong")
        frames.append((flg, bd, p))
    return b"" if test_only else bytes(result), frames


HELP = VERSION + """
Usage : 
      executable [arg] [input] [output] 

input   : a filename 
          with no FILE, or when FILE is - or stdin, read standard input
Arguments : 
 -1     : fast compression (default) 
 -12    : slowest compression level 
 -T#    : use # threads for compression (default:0==auto) 
 -d     : decompression (default for .lz4 extension)
 -f     : overwrite output without prompting 
 -k     : preserve source files(s)  (default) 
--rm    : remove source file(s) after successful de/compression 
 -h/-H  : display help/long help and exit 

Advanced arguments :
 -V     : display Version number and exit 
 -v     : verbose mode 
 -q     : suppress warnings; specify twice to suppress errors too
 -c     : force write to standard output, even if it is the console
 -t     : test compressed file integrity
 -m     : multiple input files (implies automatic output filenames)
 -r     : operate recursively on directories (sets also -m) 
 -l     : compress using Legacy format (Linux kernel compression)
 -z     : force compression 
 -D FILE: use FILE as dictionary (compression & decompression)
 -B#    : cut file into blocks of size # bytes [32+] 
                     or predefined block size [4-7] (default: 7) 
 -BI    : Block Independence (default) 
 -BD    : Block dependency (improves compression ratio) 
 -BX    : enable block checksum (default:disabled) 
--no-frame-crc : disable stream checksum (default:enabled) 
--content-size : compressed frame includes original size (default:not present)
--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)
--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)
--favor-decSpeed: compressed files decompress faster, but are less compressed 
--fast[=#]: switch to ultra fast compression level (default: 1)
--best  : same as -12
Benchmark arguments : 
 -b#    : benchmark file(s), using # compression level (default : 1) 
 -e#    : test all compression levels from -bX to # (default : 1)
 -i#    : minimum evaluation time in seconds (default : 3s) 
"""


def eprint(msg):
    print(msg, file=sys.stderr)


def read_input(path):
    if path is None or path == "-":
        return sys.stdin.buffer.read()
    with open(path, "rb") as f:
        return f.read()


def output_name(inp, decompressing):
    if inp is None or inp == "-":
        return None
    if decompressing:
        return inp[:-4] if inp.endswith(".lz4") else inp + ".out"
    return inp + ".lz4"


def write_output(path, data, force):
    if path is None or path == "-":
        sys.stdout.buffer.write(data)
        return
    if os.path.exists(path) and not force:
        raise FileExistsError(f"{path} already exists; not overwritten")
    with open(path, "wb") as f:
        f.write(data)


def list_file(path, quiet=0):
    try:
        data = read_input(path)
        _, frames = decompress_frames(data, test_only=True)
    except Exception:
        eprint(f"lz4: {path}: File format not recognized ")
        print("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename")
        return 1
    print("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename")
    block = "B4I"
    print(f"{len(frames):10d}       LZ4Frame {block:>4} {len(data):11.2f}             -        -   {path}")
    return 0


def parse_args(argv):
    opts = {
        "decompress": False, "force_compress": False, "stdout": False,
        "test": False, "force": False, "rm": False, "list": False,
        "quiet": 0, "content_size": False, "multiple": False,
        "checksum": True, "legacy": False, "block_size": 64 * 1024,
    }
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--help" or a in ("-h", "-H"):
            sys.stderr.write(HELP)
            sys.exit(0)
        if a == "-V" or a == "--version":
            print(VERSION)
            sys.exit(0)
        if (a.startswith("-") and not a.startswith("--") and len(a) > 2
                and not a[1:].isdigit()
                and not a.startswith(("-B", "-T", "-D", "-b", "-e", "-i"))):
            handled = True
            for ch in a[1:]:
                if ch == "d":
                    opts["decompress"] = True
                elif ch == "z":
                    opts["force_compress"] = True
                elif ch == "c":
                    opts["stdout"] = True
                elif ch == "t":
                    opts["test"] = True
                    opts["decompress"] = True
                elif ch == "f":
                    opts["force"] = True
                elif ch == "k":
                    opts["rm"] = False
                elif ch == "m":
                    opts["multiple"] = True
                elif ch == "r":
                    opts["multiple"] = True
                elif ch == "q":
                    opts["quiet"] += 1
                elif ch == "l":
                    opts["legacy"] = True
                elif ch == "v":
                    pass
                else:
                    handled = False
                    break
            if not handled:
                eprint("Incorrect parameters")
                print("Usage : \n      executable [arg] [input] [output] \n")
                sys.exit(1)
        elif a == "--list":
            opts["list"] = True
        elif a == "--rm":
            opts["rm"] = True
        elif a == "--content-size":
            opts["content_size"] = True
        elif a == "--no-frame-crc":
            opts["checksum"] = False
        elif a in ("--sparse", "--no-sparse", "--favor-decSpeed", "--best"):
            pass
        elif a.startswith("--fast"):
            pass
        elif a == "-d" or a == "--decompress":
            opts["decompress"] = True
        elif a == "-z" or a == "--compress":
            opts["force_compress"] = True
        elif a == "-c":
            opts["stdout"] = True
        elif a == "-t":
            opts["test"] = True
            opts["decompress"] = True
        elif a == "-f" or a == "--force":
            opts["force"] = True
        elif a == "-k" or a == "--keep":
            opts["rm"] = False
        elif a == "-m":
            opts["multiple"] = True
        elif a == "-r":
            opts["multiple"] = True
        elif a == "-q":
            opts["quiet"] += 1
        elif a == "-v":
            pass
        elif a in ("-BI", "-BD", "-BX"):
            pass
        elif a == "-D":
            i += 1
        elif a.startswith("-D") and len(a) > 2:
            pass
        elif a.startswith("-B"):
            val = a[2:]
            if val in ("4", "5", "6", "7"):
                opts["block_size"] = {"4": 64 * 1024, "5": 256 * 1024, "6": 1024 * 1024, "7": 4 * 1024 * 1024}[val]
            elif val.isdigit() and int(val) >= 32:
                opts["block_size"] = int(val)
        elif a.startswith("-T") or a.startswith("-b") or a.startswith("-e") or a.startswith("-i"):
            pass
        elif len(a) > 1 and a[0] == "-" and a[1:].isdigit():
            pass
        elif a == "-l":
            opts["legacy"] = True
        elif a.startswith("-") and a != "-":
            eprint("Incorrect parameters")
            print("Usage : \n      executable [arg] [input] [output] \n")
            sys.exit(1)
        else:
            files.append(a)
        i += 1
    return opts, files


def process_one(inp, outp, opts):
    decompressing = opts["decompress"] or (not opts["force_compress"] and inp not in (None, "-") and inp.endswith(".lz4"))
    if opts["test"]:
        data = read_input(inp)
        decompress_frames(data, test_only=True)
        return
    data = read_input(inp)
    if decompressing:
        out, _ = decompress_frames(data)
    else:
        if opts["legacy"]:
            out = compress_legacy(data)
        else:
            out = compress_frame(data, block_size=opts["block_size"], content_size=opts["content_size"], checksum=opts["checksum"])
    if opts["stdout"]:
        dest = None
    else:
        dest = outp if outp is not None else output_name(inp, decompressing)
        if dest is None:
            dest = "-"
    write_output(dest, out, opts["force"])
    if opts["rm"] and inp not in (None, "-") and dest not in (None, "-"):
        try:
            os.remove(inp)
        except OSError:
            pass


def main(argv):
    opts, files = parse_args(argv)
    try:
        if opts["list"]:
            targets = files or ["-"]
            status = 0
            for path in targets:
                status |= list_file(path, opts["quiet"])
            return status
        if opts["multiple"] and len(files) > 1:
            for inp in files:
                process_one(inp, None, opts)
            return 0
        inp = files[0] if files else None
        outp = files[1] if len(files) > 1 else None
        process_one(inp, outp, opts)
        return 0
    except FileExistsError as ex:
        if opts["quiet"] < 2:
            eprint(str(ex))
        return 1
    except FileNotFoundError as ex:
        if opts["quiet"] < 2:
            eprint(f"{ex.filename}: No such file or directory")
        return 1
    except RuntimeError as ex:
        if opts["quiet"] < 2:
            eprint(str(ex))
        text = str(ex)
        if text.startswith("Error "):
            try:
                return int(text.split()[1])
            except Exception:
                pass
        return 1
    except Exception as ex:
        if opts["quiet"] < 2:
            eprint(f"Error 66 : Decompression error : {ex}")
        return 66


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
