#include <ctype.h>
#include <locale.h>
#include <ncurses.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    int async_scroll;
    int bold_mode; /* 0 none, 1 random, 2 all */
    int japanese;
    int force_linux;
    int linux_mode;
    int lock_mode;
    int old_style;
    int screensaver;
    int x_mode;
    int rainbow;
    int lambda;
    int change;
    int delay;
    int color;
    const char *message;
    const char *tty;
} Options;

static volatile sig_atomic_t stop_requested = 0;

static const char *usage_text =
" Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n"
" -a: Asynchronous scroll\n"
" -b: Bold characters on\n"
" -B: All bold characters (overrides -b)\n"
" -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n"
" -f: Force the linux $TERM type to be on\n"
" -l: Linux mode (uses matrix console font)\n"
" -L: Lock mode (can be closed from another terminal)\n"
" -o: Use old-style scrolling\n"
" -h: Print usage and exit\n"
" -n: No bold characters (overrides -b and -B, default)\n"
" -s: \"Screensaver\" mode, exits on first keystroke\n"
" -x: X window mode, use if your xterm is using mtx.pcf\n"
" -V: Print version information and exit\n"
" -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n"
" -u delay (0 - 10, default 4): Screen update delay\n"
" -C [color]: Use this color for matrix (default green)\n"
" -r: rainbow mode\n"
" -m: lambda mode\n"
" -k: Characters change while scrolling. (Works without -o opt.)\n"
" -t [tty]: Set tty to use\n";

static void usage(void) {
    fputs(usage_text, stdout);
}

static void version(void) {
    puts(" CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)");
    puts("Email: abishekvashok@gmail.com");
    puts("Web: https://github.com/abishekvashok/cmatrix");
}

static int color_from_name(const char *name) {
    if (!name) return -1;
    if (!strcasecmp(name, "green")) return COLOR_GREEN;
    if (!strcasecmp(name, "red")) return COLOR_RED;
    if (!strcasecmp(name, "blue")) return COLOR_BLUE;
    if (!strcasecmp(name, "white")) return COLOR_WHITE;
    if (!strcasecmp(name, "yellow")) return COLOR_YELLOW;
    if (!strcasecmp(name, "cyan")) return COLOR_CYAN;
    if (!strcasecmp(name, "magenta")) return COLOR_MAGENTA;
    if (!strcasecmp(name, "black")) return COLOR_BLACK;
    return -1;
}

static void invalid_color(void) {
    fputs(" Invalid color selection\n", stderr);
    fputs(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.\n", stderr);
}

static void on_signal(int sig) {
    (void)sig;
    stop_requested = 1;
}

static char matrix_char(const Options *opt) {
    static const char normal[] =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        "@#$%^&*+=-;:<>?/[]{}";
    static const unsigned char kana[] = {
        0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad,
        0xae, 0xaf, 0xb1, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6,
        0xb7, 0xb8, 0xb9, 0xba, 0xbb, 0xbc, 0xbd, 0xbe
    };
    if (opt->lambda) return 'L';
    if (opt->japanese || opt->x_mode || opt->linux_mode) {
        return (char)kana[rand() % (int)(sizeof(kana) / sizeof(kana[0]))];
    }
    return normal[rand() % (int)(sizeof(normal) - 1)];
}

static int pair_for_color(int color) {
    switch (color) {
        case COLOR_RED: return 1;
        case COLOR_GREEN: return 2;
        case COLOR_YELLOW: return 3;
        case COLOR_BLUE: return 4;
        case COLOR_MAGENTA: return 5;
        case COLOR_CYAN: return 6;
        case COLOR_WHITE: return 7;
        case COLOR_BLACK: return 8;
        default: return 2;
    }
}

static void setup_colors(void) {
    if (!has_colors()) return;
    start_color();
    use_default_colors();
    init_pair(1, COLOR_RED, -1);
    init_pair(2, COLOR_GREEN, -1);
    init_pair(3, COLOR_YELLOW, -1);
    init_pair(4, COLOR_BLUE, -1);
    init_pair(5, COLOR_MAGENTA, -1);
    init_pair(6, COLOR_CYAN, -1);
    init_pair(7, COLOR_WHITE, -1);
    init_pair(8, COLOR_BLACK, -1);
}

static void draw_center_message(const Options *opt) {
    const char *msg = opt->message;
    if (!msg && opt->lock_mode) msg = "Computer locked.";
    if (!msg || !*msg) return;
    int y = LINES / 2;
    int x = (COLS - (int)strlen(msg)) / 2;
    if (x < 0) x = 0;
    attr_t old = 0;
    short pair = 0;
    attr_get(&old, &pair, NULL);
    attron(A_BOLD);
    if (has_colors()) attron(COLOR_PAIR(7));
    mvaddnstr(y, x, msg, COLS - x);
    attr_set(old, pair, NULL);
}

static void apply_key(Options *opt, int ch, int *running) {
    switch (ch) {
        case ERR:
            return;
        case 'q':
            if (!opt->lock_mode) *running = 0;
            return;
        case 'a': opt->async_scroll = !opt->async_scroll; return;
        case 'b': opt->bold_mode = 1; return;
        case 'B': opt->bold_mode = 2; return;
        case 'n': opt->bold_mode = 0; return;
        case '!': opt->color = COLOR_RED; return;
        case '@': opt->color = COLOR_GREEN; return;
        case '#': opt->color = COLOR_YELLOW; return;
        case '$': opt->color = COLOR_BLUE; return;
        case '%': opt->color = COLOR_MAGENTA; return;
        case '^': opt->color = COLOR_CYAN; return;
        case '&': opt->color = COLOR_WHITE; return;
        case ')': opt->color = COLOR_BLACK; return;
        default:
            if (isdigit((unsigned char)ch)) opt->delay = ch - '0';
            if (opt->screensaver) *running = 0;
            return;
    }
}

static int run_matrix(Options opt) {
    if (opt.linux_mode) {
        fputs(" Unable to use both \"setfont\" and \"consolechars\".\n", stderr);
    }

    setlocale(LC_ALL, "");
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    if (initscr() == NULL) {
        return 1;
    }
    cbreak();
    noecho();
    nonl();
    nodelay(stdscr, TRUE);
    keypad(stdscr, TRUE);
    curs_set(0);
    setup_colors();
    clear();

    int cols = COLS > 0 ? COLS : 80;
    int *heads = calloc((size_t)cols, sizeof(int));
    int *lengths = calloc((size_t)cols, sizeof(int));
    int *speeds = calloc((size_t)cols, sizeof(int));
    if (!heads || !lengths || !speeds) {
        endwin();
        free(heads); free(lengths); free(speeds);
        return 1;
    }
    for (int i = 0; i < cols; ++i) {
        heads[i] = -(rand() % (LINES + 1));
        lengths[i] = 4 + rand() % 18;
        speeds[i] = 1 + rand() % 3;
    }

    int running = 1;
    int tick = 0;
    while (running && !stop_requested) {
        int ch;
        while ((ch = getch()) != ERR) apply_key(&opt, ch, &running);
        if (!running) break;

        if (COLS != cols) {
            int old_cols = cols;
            cols = COLS > 0 ? COLS : 80;
            heads = realloc(heads, (size_t)cols * sizeof(int));
            lengths = realloc(lengths, (size_t)cols * sizeof(int));
            speeds = realloc(speeds, (size_t)cols * sizeof(int));
            if (!heads || !lengths || !speeds) {
                endwin();
                free(heads); free(lengths); free(speeds);
                return 1;
            }
            for (int i = old_cols; i < cols; ++i) {
                heads[i] = -(rand() % (LINES + 1));
                lengths[i] = 4 + rand() % 18;
                speeds[i] = 1 + rand() % 3;
            }
            clear();
        }

        if (!opt.old_style) erase();
        for (int x = 0; x < cols; x += 2) {
            if (!opt.async_scroll || tick % speeds[x] == 0) heads[x]++;
            if (heads[x] - lengths[x] > LINES) {
                heads[x] = -(rand() % (LINES + 1));
                lengths[x] = 4 + rand() % 18;
                speeds[x] = 1 + rand() % 3;
            }
            for (int j = 0; j < lengths[x]; ++j) {
                int y = heads[x] - j;
                if (y < 0 || y >= LINES) continue;
                int pair = opt.rainbow ? (1 + rand() % 7) : pair_for_color(opt.color);
                if (has_colors()) attron(COLOR_PAIR(pair));
                if (j == 0 || opt.bold_mode == 2 || (opt.bold_mode == 1 && rand() % 4 == 0)) attron(A_BOLD);
                char c = (j == 0 || opt.change) ? matrix_char(&opt) : matrix_char(&opt);
                mvaddch(y, x, (unsigned char)c);
                attroff(A_BOLD);
                if (has_colors()) attroff(COLOR_PAIR(pair));
            }
        }
        draw_center_message(&opt);
        refresh();
        tick++;

        int ms = 20 + opt.delay * 15;
        if (opt.delay <= 0) ms = 10;
        napms(ms);
    }

    curs_set(1);
    endwin();
    free(heads);
    free(lengths);
    free(speeds);
    return 0;
}

int main(int argc, char **argv) {
    Options opt;
    memset(&opt, 0, sizeof(opt));
    opt.delay = 4;
    opt.color = COLOR_GREEN;

    opterr = 0;
    int c;
    while ((c = getopt(argc, argv, "abBcfhlLosmVxnu:C:M:rkt:")) != -1) {
        switch (c) {
            case 'a': opt.async_scroll = 1; break;
            case 'b': opt.bold_mode = 1; break;
            case 'B': opt.bold_mode = 2; break;
            case 'c': opt.japanese = 1; break;
            case 'f': opt.force_linux = 1; break;
            case 'h': usage(); return 0;
            case 'l': opt.linux_mode = 1; break;
            case 'L': opt.lock_mode = 1; break;
            case 'o': opt.old_style = 1; break;
            case 's': opt.screensaver = 1; break;
            case 'm': opt.lambda = 1; break;
            case 'V': version(); return 0;
            case 'x': opt.x_mode = 1; break;
            case 'n': opt.bold_mode = 0; break;
            case 'u': opt.delay = atoi(optarg); break;
            case 'C': {
                int col = color_from_name(optarg);
                if (col < 0) {
                    invalid_color();
                    return 0;
                }
                opt.color = col;
                break;
            }
            case 'M': opt.message = optarg; break;
            case 'r': opt.rainbow = 1; break;
            case 'k': opt.change = 1; break;
            case 't': opt.tty = optarg; (void)opt.tty; break;
            case '?':
            default:
                usage();
                return 0;
        }
    }

    srand((unsigned int)(time(NULL) ^ getpid()));
    return run_matrix(opt);
}
