#!/usr/bin/env python3
import os
import re
import shutil
import signal
import socket
import subprocess
import sys
import time


HELP = """Ping, but with a graph.

Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...

Arguments:
  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1

Options:
      --cmd
          Graph the execution time for a list of commands rather than pinging hosts
  -n, --watch-interval <WATCH_INTERVAL>
          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5
  -b, --buffer <BUFFER>
          Determines the number of seconds to display in the graph [default: 30]
  -4
          Resolve ping targets to IPv4 address
  -6
          Resolve ping targets to IPv6 address
  -i, --interface <INTERFACE>
          Interface to use when pinging
  -s, --simple-graphics
          
      --vertical-margin <VERTICAL_MARGIN>
          Vertical margin around the graph (top and bottom) [default: 1]
      --horizontal-margin <HORIZONTAL_MARGIN>
          Horizontal margin around the graph (left and right) [default: 0]
  -c, --color <color>
          Assign color to a graph entry.
          
          This option can be defined more than once as a comma separated string, and the
          order which the colors are provided will be matched against the hosts or
          commands passed to gping.
          
          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the
          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',
          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',
          'light-blue', 'light-magenta', 'light-cyan', and 'white'
      --clear
          Clear the graph from the terminal after closing the program
      --ping-args [<PING_ARGS>...]
          Extra arguments to pass to `ping`. These are platform dependent
  -h, --help
          Print help
  -V, --version
          Print version
"""

LONG_VERSION = """gping 1.20.1
commit_hash: d67d2aeb
build_time: 2026-04-17 19:59:37 +00:00
build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu
"""

COLORS = {
    "black", "red", "green", "yellow", "blue", "magenta", "cyan", "gray",
    "dark-gray", "light-red", "light-green", "light-yellow", "light-blue",
    "light-magenta", "light-cyan", "white",
}


class CliError(Exception):
    def __init__(self, message, code=2):
        super().__init__(message)
        self.code = code


def usage_for_conflict(flag):
    return f"Usage: executable {flag} <HOSTS_OR_COMMANDS>..."


def unexpected(arg):
    return (
        f"error: unexpected argument '{arg}' found\n\n"
        f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
        "Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n\n"
        "For more information, try '--help'."
    )


def missing_value(name, value_name):
    return (
        f"error: a value is required for '{name} <{value_name}>' but none was supplied\n\n"
        "For more information, try '--help'."
    )


def invalid_value(name, value_name, value, reason):
    return (
        f"error: invalid value '{value}' for '{name} <{value_name}>': {reason}\n\n"
        "For more information, try '--help'."
    )


def validate_color(value):
    for item in value.split(","):
        if item in COLORS:
            continue
        if re.fullmatch(r"#[0-9a-fA-F]{6}", item):
            continue
        print(f"Error: Invalid color code: `{item}`\n\nCaused by:\n    Failed to parse Colors", file=sys.stderr)
        sys.exit(1)


def parse(argv):
    opts = {
        "cmd": False,
        "ipv4": False,
        "ipv6": False,
        "watch": None,
        "buffer": 30,
        "interface": None,
        "simple": False,
        "vertical": 1,
        "horizontal": 0,
        "clear": False,
        "ping_args": [],
        "hosts": [],
    }
    i = 0
    stop_options = False
    while i < len(argv):
        arg = argv[i]
        if stop_options:
            opts["hosts"].append(arg)
            i += 1
            continue
        if arg == "--":
            stop_options = True
            i += 1
            continue
        if arg in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if arg == "-V":
            print("gping 1.20.1")
            sys.exit(0)
        if arg == "--version":
            print(LONG_VERSION, end="")
            sys.exit(0)
        if arg == "--cmd":
            opts["cmd"] = True
        elif arg == "-4":
            if opts["ipv6"]:
                raise CliError("error: the argument '-4' cannot be used with '-6'\n\n" + usage_for_conflict("-4") + "\n\nFor more information, try '--help'.")
            opts["ipv4"] = True
        elif arg == "-6":
            if opts["ipv4"]:
                raise CliError("error: the argument '-4' cannot be used with '-6'\n\n" + usage_for_conflict("-4") + "\n\nFor more information, try '--help'.")
            opts["ipv6"] = True
        elif arg in ("-s", "--simple-graphics"):
            opts["simple"] = True
        elif arg == "--clear":
            opts["clear"] = True
        elif arg in ("-n", "--watch-interval"):
            i += 1
            if i >= len(argv):
                raise CliError(missing_value("--watch-interval", "WATCH_INTERVAL"))
            val = argv[i]
            if val.startswith("-"):
                raise CliError(unexpected(val))
            try:
                opts["watch"] = float(val)
            except ValueError:
                raise CliError(invalid_value("--watch-interval", "WATCH_INTERVAL", val, "invalid float literal"))
        elif arg.startswith("--watch-interval="):
            val = arg.split("=", 1)[1]
            try:
                opts["watch"] = float(val)
            except ValueError:
                raise CliError(invalid_value("--watch-interval", "WATCH_INTERVAL", val, "invalid float literal"))
        elif arg in ("-b", "--buffer"):
            i += 1
            if i >= len(argv):
                raise CliError(missing_value("--buffer", "BUFFER"))
            val = argv[i]
            if val.startswith("-"):
                raise CliError(unexpected(val))
            if not val.isdigit():
                raise CliError(invalid_value("--buffer", "BUFFER", val, "invalid digit found in string"))
            opts["buffer"] = int(val)
        elif arg.startswith("--buffer="):
            val = arg.split("=", 1)[1]
            if not val.isdigit():
                raise CliError(invalid_value("--buffer", "BUFFER", val, "invalid digit found in string"))
            opts["buffer"] = int(val)
        elif arg in ("-i", "--interface"):
            i += 1
            if i >= len(argv):
                raise CliError(missing_value("--interface", "INTERFACE"))
            opts["interface"] = argv[i]
        elif arg.startswith("--interface="):
            opts["interface"] = arg.split("=", 1)[1]
        elif arg == "--vertical-margin":
            i += 1
            if i >= len(argv):
                raise CliError(missing_value("--vertical-margin", "VERTICAL_MARGIN"))
            val = argv[i]
            if val.startswith("-"):
                raise CliError(unexpected(val))
            if not val.isdigit():
                raise CliError(invalid_value("--vertical-margin", "VERTICAL_MARGIN", val, "invalid digit found in string"))
            opts["vertical"] = int(val)
        elif arg.startswith("--vertical-margin="):
            val = arg.split("=", 1)[1]
            if not val.isdigit():
                raise CliError(invalid_value("--vertical-margin", "VERTICAL_MARGIN", val, "invalid digit found in string"))
            opts["vertical"] = int(val)
        elif arg == "--horizontal-margin":
            i += 1
            if i >= len(argv):
                raise CliError(missing_value("--horizontal-margin", "HORIZONTAL_MARGIN"))
            val = argv[i]
            if val.startswith("-"):
                raise CliError(unexpected(val))
            if not val.isdigit():
                raise CliError(invalid_value("--horizontal-margin", "HORIZONTAL_MARGIN", val, "invalid digit found in string"))
            opts["horizontal"] = int(val)
        elif arg.startswith("--horizontal-margin="):
            val = arg.split("=", 1)[1]
            if not val.isdigit():
                raise CliError(invalid_value("--horizontal-margin", "HORIZONTAL_MARGIN", val, "invalid digit found in string"))
            opts["horizontal"] = int(val)
        elif arg in ("-c", "--color"):
            i += 1
            if i >= len(argv):
                raise CliError(missing_value("--color", "color"))
            validate_color(argv[i])
        elif arg.startswith("--color="):
            validate_color(arg.split("=", 1)[1])
        elif arg == "--ping-args":
            opts["ping_args"].extend(argv[i + 1:])
            break
        elif arg.startswith("--ping-args="):
            opts["ping_args"].append(arg.split("=", 1)[1])
        elif arg.startswith("-"):
            raise CliError(unexpected(arg))
        else:
            opts["hosts"].append(arg)
        i += 1
    return opts


def expand_host(host):
    if host.startswith("aws:") and len(host) > 4:
        return "ec2." + host[4:] + ".amazonaws.com"
    return host


def gai_message(exc):
    text = str(exc)
    if "Temporary failure" in text or getattr(exc, "errno", None) == socket.EAI_AGAIN:
        return "Temporary failure in name resolution"
    if "Name or service not known" in text or getattr(exc, "errno", None) == socket.EAI_NONAME:
        return "Name or service not known"
    return text.split("] ", 1)[-1]


def preflight_ping(opts):
    family = socket.AF_UNSPEC
    if opts["ipv4"]:
        family = socket.AF_INET
    elif opts["ipv6"]:
        family = socket.AF_INET6
    for raw in opts["hosts"]:
        host = expand_host(raw)
        try:
            socket.getaddrinfo(host, None, family, socket.SOCK_STREAM)
        except socket.gaierror as exc:
            print(f"Error: Resolving {host}\n\nCaused by:\n    failed to lookup address information: {gai_message(exc)}", file=sys.stderr)
            sys.exit(1)
    ping = shutil.which("ping")
    if ping is None:
        print("Error: Could not detect ping. Stderr: []\nStdout: []", file=sys.stderr)
        sys.exit(1)


def draw_header(names):
    sys.stdout.write("\x1b[8;0;0t\x1b[2J\x1b[39m\x1b[49m\x1b[0m\x1b[?25l")
    sys.stdout.flush()
    cols = shutil.get_terminal_size((80, 24)).columns
    title = " | ".join(names)[: max(1, cols - 1)]
    if title:
        sys.stdout.write(title + "\n")
        sys.stdout.flush()


def run_cmd_loop(opts):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("Error: No such device or address (os error 6)", file=sys.stderr)
        sys.exit(1)
    interval = opts["watch"] if opts["watch"] is not None else 0.5
    commands = opts["hosts"]
    draw_header(commands)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(124))
    while True:
        for cmd in commands:
            start = time.time()
            subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elapsed = (time.time() - start) * 1000.0
            sys.stdout.write(f"{cmd}: {elapsed:.0f}ms\n")
            sys.stdout.flush()
        time.sleep(max(0.0, interval))


def run_ping_loop(opts):
    preflight_ping(opts)
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        print("Error: No such device or address (os error 6)", file=sys.stderr)
        sys.exit(1)
    interval = opts["watch"] if opts["watch"] is not None else 0.2
    draw_header(opts["hosts"])
    while True:
        for host in opts["hosts"]:
            sys.stdout.write(f"{host}: -- ms\n")
        sys.stdout.flush()
        time.sleep(max(0.0, interval))


def main():
    try:
        opts = parse(sys.argv[1:])
    except CliError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(exc.code)
    if not opts["hosts"]:
        print("Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.", file=sys.stderr)
        sys.exit(1)
    if opts["cmd"]:
        run_cmd_loop(opts)
    else:
        run_ping_loop(opts)


if __name__ == "__main__":
    main()
