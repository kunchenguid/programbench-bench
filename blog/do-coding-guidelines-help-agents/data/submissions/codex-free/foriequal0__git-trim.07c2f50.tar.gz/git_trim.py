#!/usr/bin/env python3
import fnmatch
import os
import subprocess
import sys
import time


DESCRIPTION = "Automatically trims your tracking branches whose upstream branches are merged or stray."
SKIP_LOCAL = "Set an upstream to make it a tracking branch or add `--delete 'local'` flag."
SKIP_MERGED_ALL = "Add `--delete 'merged:*'` flag."

HELP_SHORT = """Automatically trims your tracking branches whose upstream branches are merged or stray.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]
      --no-update
          Do not update remotes [config: trim.update]
      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]
      --no-confirm
          Do not ask confirm [config: trim.confirm]
      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]
  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
      --dry-run
          Do not delete branches, show what branches will be deleted
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

HELP_LONG = """Automatically trims your tracking branches whose upstream branches are merged or stray.
`git-trim` is a missing companion to the `git fetch --prune` and a proper, safer, faster alternative to your `<bash oneliner HERE>`.

Usage: executable [OPTIONS]

Options:
  -b, --bases <BASES>
          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]
          
          The default value is a branch that tracks `git symbolic-ref refs/remotes/*/HEAD`. They might not be reflected correctly when the HEAD branch of your remote repository is changed. You can see the changed HEAD branch name with `git remote show <remote>` and apply it to your local repository with `git remote set-head <remote> --auto`.

  -p, --protected <PROTECTED>
          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]

      --no-update
          Do not update remotes [config: trim.update]

      --update-interval <UPDATE_INTERVAL>
          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]

      --no-confirm
          Do not ask confirm [config: trim.confirm]

      --no-detach
          Do not detach when HEAD is about to be deleted [config: trim.detach]

  -d, --delete <DELETE>
          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]
          
          `merged` implies `merged-local,merged-remote`.
          
          `merged-local` will delete merged tracking local branches. `merged-remote:<remote>` will delete merged upstream branches from `<remote>`. `stray` will delete tracking local branches, which is not merged, but the upstream is gone. `diverged:<remote>` will delete merged tracking local branches, and their upstreams from `<remote>` even if the upstreams are not merged and diverged from local ones. `local` will delete non-tracking merged local branches. `remote:<remote>` will delete non-upstream merged remote tracking branches. Use with caution when you are using other than `merged`. It might lose changes, and even nuke repositories.

      --dry-run
          Do not delete branches, show what branches will be deleted

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


class GitError(Exception):
    pass


def run(args, check=False, capture=True):
    p = subprocess.run(args, text=True, stdout=subprocess.PIPE if capture else None,
                       stderr=subprocess.PIPE if capture else None)
    if check and p.returncode != 0:
        msg = (p.stderr or p.stdout or "").strip()
        raise GitError(msg)
    return p


def git(args, check=False):
    return run(["git"] + args, check=check)


def git_config(name):
    p = git(["config", "--get", name])
    return p.stdout.strip() if p.returncode == 0 else None


def split_csv(value):
    if not value:
        return []
    return [x.strip() for x in value.split(",") if x.strip()]


def parse_args(argv):
    opts = {
        "bases": None, "protected": None, "delete": None, "dry_run": False,
        "update": None, "update_interval": None, "confirm": None, "detach": None,
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--help":
            print(HELP_LONG, end="")
            sys.exit(0)
        if a == "-h":
            print(HELP_SHORT, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print("git-trim 0.4.4")
            sys.exit(0)
        if a in ("--dry-run",):
            opts["dry_run"] = True
        elif a == "--no-update":
            opts["update"] = False
        elif a == "--update":
            opts["update"] = True
        elif a == "--no-confirm":
            opts["confirm"] = False
        elif a == "--confirm":
            opts["confirm"] = True
        elif a == "--no-detach":
            opts["detach"] = False
        elif a == "--detach":
            opts["detach"] = True
        elif a in ("-b", "--bases", "-p", "--protected", "-d", "--delete", "--update-interval"):
            if i + 1 >= len(argv):
                print(f"error: a value is required for '{a} <VALUE>' but none was supplied", file=sys.stderr)
                sys.exit(2)
            val = argv[i + 1]
            if a in ("-b", "--bases"):
                opts["bases"] = val
            elif a in ("-p", "--protected"):
                opts["protected"] = val
            elif a in ("-d", "--delete"):
                opts["delete"] = val
            else:
                opts["update_interval"] = val
            i += 1
        elif a.startswith("--bases="):
            opts["bases"] = a.split("=", 1)[1]
        elif a.startswith("--protected="):
            opts["protected"] = a.split("=", 1)[1]
        elif a.startswith("--delete="):
            opts["delete"] = a.split("=", 1)[1]
        elif a.startswith("--update-interval="):
            opts["update_interval"] = a.split("=", 1)[1]
        else:
            print(f"error: unexpected argument '{a}' found\n\nFor more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        i += 1
    return opts


def bool_config(name, default):
    v = git_config(name)
    if v is None:
        return default
    return v.lower() not in ("false", "0", "no", "off")


def ensure_repo():
    p = git(["rev-parse", "--git-dir"])
    if p.returncode != 0:
        print("Error: could not find repository at '.'; class=Repository (6); code=NotFound (-3)", file=sys.stderr)
        sys.exit(1)


def for_each_ref(prefix):
    fmt = "%(refname:short)%09%(objectname)%09%(upstream:short)"
    p = git(["for-each-ref", f"--format={fmt}", prefix], check=True)
    out = []
    for line in p.stdout.splitlines():
        parts = line.split("\t")
        while len(parts) < 3:
            parts.append("")
        out.append({"name": parts[0], "sha": parts[1], "upstream": parts[2]})
    return out


def ref_exists(short):
    return git(["rev-parse", "--verify", "--quiet", short]).returncode == 0


def ref_sha(short):
    p = git(["rev-parse", "--verify", short])
    return p.stdout.strip() if p.returncode == 0 else None


def is_ancestor(a, b):
    if not a or not b:
        return False
    return git(["merge-base", "--is-ancestor", a, b]).returncode == 0


def current_branch():
    p = git(["symbolic-ref", "--quiet", "--short", "HEAD"])
    return p.stdout.strip() if p.returncode == 0 else None


def detect_bases():
    bases = []
    remotes = git(["for-each-ref", "--format=%(refname:short)", "refs/remotes"])
    for name in remotes.stdout.splitlines():
        if not name.endswith("/HEAD"):
            continue
        p = git(["symbolic-ref", "-q", f"refs/remotes/{name}"])
        if p.returncode != 0:
            continue
        target = p.stdout.strip()
        short = target.replace("refs/remotes/", "", 1)
        for br in for_each_ref("refs/heads"):
            if br["upstream"] == short:
                bases.append(br["name"])
    return sorted(set(bases))


def no_base_error():
    print("I can't detect base branch! Try following any resolution:", file=sys.stderr)
    print(" * `git remote set-head origin --auto` will help `git-trim` to automatically", file=sys.stderr)
    print("   detect the base branch.", file=sys.stderr)
    print("   If you see `origin/HEAD set to <base branch>` in the output of the previous", file=sys.stderr)
    print("   command, then `git branch --set-upstream origin/<base branch> <base branch>`", file=sys.stderr)
    print("   to set an upstream branch for <base branch> if exists.", file=sys.stderr)
    print("You also can set bases manually with any of following commands:", file=sys.stderr)
    print(" * `git config trim.bases develop,master` for a repository.", file=sys.stderr)
    print(" * `git config --global trim.bases develop,master` to set globally.", file=sys.stderr)
    print(" * `git trim --bases develop,master` to set temporarily.", file=sys.stderr)
    print("Error: No base branch is found!", file=sys.stderr)
    sys.exit(1)


def parse_delete(spec):
    local_ranges = set()
    remote_ranges = []
    valid = {"merged", "merged-local", "merged-remote", "stray", "diverged", "local", "remote"}
    for raw in split_csv(spec):
        if ":" in raw:
            kind, remote = raw.split(":", 1)
        else:
            kind, remote = raw, None
        if kind not in valid or (kind in ("merged-remote", "diverged", "remote") and not remote):
            print(f"error: invalid value '{spec}' for '--delete <DELETE>': Invalid delete range format `{raw}`\n\nFor more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        if kind == "merged":
            local_ranges.add("merged-local")
            if remote:
                remote_ranges.append(("merged-remote", remote))
        elif kind in ("merged-local", "stray", "local"):
            local_ranges.add(kind)
        else:
            remote_ranges.append((kind, remote))
    return local_ranges, remote_ranges


def remote_match(remote, wanted):
    return wanted == "*" or remote == wanted


def protect_reason(name, patterns):
    for pat in patterns:
        if fnmatch.fnmatchcase(name, pat):
            return pat
    return None


def classify(opts):
    cfg_bases = git_config("trim.bases")
    cfg_protected = git_config("trim.protected")
    cfg_delete = git_config("trim.delete")
    bases = split_csv(opts["bases"] if opts["bases"] is not None else cfg_bases)
    if not bases:
        bases = detect_bases()
    if not bases:
        no_base_error()

    protected = split_csv(opts["protected"] if opts["protected"] is not None else cfg_protected)
    delete_spec = opts["delete"] if opts["delete"] is not None else (cfg_delete or "merged:origin")
    local_ranges, remote_ranges = parse_delete(delete_spec)
    local_only_scan = local_ranges == {"local"} and not remote_ranges

    locals_ = sorted(for_each_ref("refs/heads"), key=lambda x: x["name"])
    remotes_ = [r for r in for_each_ref("refs/remotes") if not r["name"].endswith("/HEAD")]
    remotes_ = sorted(remotes_, key=lambda x: x["name"])

    base_upstreams = {}
    base_shas = []
    for b in bases:
        br = next((x for x in locals_ if x["name"] == b), None)
        if br and br["upstream"] and ref_exists(br["upstream"]):
            sha = ref_sha(br["upstream"])
            base_upstreams[br["upstream"]] = b
            base_shas.append(sha)
    if not base_shas:
        no_base_error()

    local_delete = {"merged-local": [], "stray": [], "local": []}
    remote_delete = {"merged-remote": [], "remote": [], "diverged": []}
    remain_local = []
    remain_remote = []
    skipped = {}

    def add_skip(msg):
        if msg not in skipped:
            if msg == SKIP_LOCAL and not local_only_scan and SKIP_MERGED_ALL not in skipped:
                skipped[msg] = 2
            else:
                skipped[msg] = len(skipped) + 1
        return skipped[msg]

    for br in locals_:
        name, sha, up = br["name"], br["sha"], br["upstream"]
        is_base = name in bases
        pat = protect_reason(name, protected)
        upstream_exists = bool(up and ref_exists(up))
        merged = any(is_ancestor(sha, bsha) for bsha in base_shas)
        note = None
        if is_base:
            if local_only_scan:
                note = f"*{add_skip(SKIP_MERGED_ALL)}"
            elif not upstream_exists:
                note = "[stray, but: base]"
            else:
                note = "[base]"
        elif pat:
            kind = "stray" if up and not upstream_exists else "merged" if merged else None
            note = f"[{kind}, but: protected by a pattern `{pat}`]" if kind else f"[protected by a pattern `{pat}`]"
        elif up and not upstream_exists:
            if local_only_scan:
                note = f"*{add_skip(SKIP_MERGED_ALL)}"
            elif "stray" in local_ranges:
                local_delete["stray"].append(name)
                continue
            else:
                note = "[stray, but: delete range `stray` was not given]"
        elif up:
            if local_only_scan:
                note = f"*{add_skip(SKIP_MERGED_ALL)}"
            elif merged:
                if "merged-local" in local_ranges:
                    local_delete["merged-local"].append(name)
                    continue
                note = "[merged, but: delete range `merged-local` was not given]"
        else:
            if merged:
                if "local" in local_ranges:
                    local_delete["local"].append(name)
                    continue
                note = f"*{add_skip(SKIP_LOCAL)}"
            else:
                note = f"*{add_skip(SKIP_LOCAL)}"
        remain_local.append((name, note))

    for rr in remotes_:
        name, sha = rr["name"], rr["sha"]
        remote, rest = name.split("/", 1) if "/" in name else ("", name)
        is_base = name in base_upstreams
        pat = protect_reason(name, protected)
        merged = any(is_ancestor(sha, bsha) for bsha in base_shas)
        note = None
        upstream_of_local = any(br["upstream"] == name for br in locals_)
        if local_only_scan:
            note = f"*{add_skip(SKIP_MERGED_ALL)}"
        elif is_base:
            note = "[base]"
        elif pat:
            kind = "merged" if merged else None
            note = f"[{kind}, but: protected by a pattern `{pat}`]" if kind else f"[protected by a pattern `{pat}`]"
        elif merged:
            matched = False
            for kind, want in remote_ranges:
                if kind in ("merged-remote", "diverged", "remote") and remote_match(remote, want):
                    if kind == "remote" and upstream_of_local:
                        continue
                    remote_delete[kind].append((remote, f"refs/heads/{rest}", name))
                    matched = True
                    break
            if matched:
                continue
            note = f"[merged, but: delete range `merged-remote:{remote}` was not given]"
        else:
            note = None
        if not upstream_of_local and not is_base and not merged:
            note = f"*{add_skip(SKIP_MERGED_ALL)}"
        remain_remote.append((name, note))

    return remain_local, remain_remote, skipped, local_delete, remote_delete


def print_report(remain_local, remain_remote, skipped, local_delete, remote_delete):
    print("Branches that will remain:")
    print("  local branches:")
    for name, note in remain_local:
        print(f"    {name}" + (f" {note}" if note else ""))
    print("  remote references:")
    for name, note in remain_remote:
        print(f"    {name}" + (f" {note}" if note else ""))
    if skipped:
        print("  Some branches are skipped. Consider following to scan them:")
        for msg, n in sorted(skipped.items(), key=lambda kv: kv[1]):
            print(f"    *{n}: {msg}")
    print()


def confirm_or_fail():
    if not sys.stdin.isatty():
        print("Error: IO error: not a terminal", file=sys.stderr)
        print("\nCaused by:\n    not a terminal", file=sys.stderr)
        sys.exit(1)
    ans = input("Are you sure? [y/N] ")
    return ans.lower().startswith("y")


def delete_actions(local_delete, remote_delete, dry_run, confirm):
    groups = [
        ("merged-local", "Delete merged local branches:", "Delete branch {name}"),
        ("stray", "Delete stray local branches:", "Delete branch {name}"),
        ("local", "Delete merged local branches:", "Delete branch {name}"),
    ]
    any_delete = any(local_delete[k] for k, _, _ in groups) or any(remote_delete[k] for k in remote_delete)
    postponed = []
    has_remote = any(remote_delete[k] for k in remote_delete)
    for key, title, action in groups:
        if not local_delete[key]:
            continue
        print(title)
        for name in local_delete[key]:
            suffix = " (non-tracking)" if key == "local" else ""
            print(f"  - {name}{suffix}")
        if not dry_run and confirm and not confirm_or_fail():
            continue
        for name in local_delete[key]:
            if dry_run:
                line = action.format(name=name) + " (dry run)."
                if has_remote:
                    postponed.append(line)
                else:
                    print(line)
            else:
                subprocess.run(["git", "branch", "-D", name], text=True)
    for key in ("merged-remote", "diverged", "remote"):
        if not remote_delete[key]:
            continue
        print("Delete merged remote refs:")
        for remote, ref, _ in remote_delete[key]:
            print(f"  - {remote}, {ref}")
        if not dry_run and confirm and not confirm_or_fail():
            continue
        for remote, ref, _ in remote_delete[key]:
            if dry_run:
                sys.stdout.flush()
                subprocess.run(["git", "push", "--dry-run", remote, f":{ref}"], text=True)
            else:
                sys.stdout.flush()
                subprocess.run(["git", "push", remote, f":{ref}"], text=True)
    for line in postponed:
        print(line)
    return any_delete


def maybe_update(update, interval):
    if not update:
        return
    git_dir = git(["rev-parse", "--git-dir"]).stdout.strip()
    stamp = os.path.join(git_dir, "git-trim-fetch")
    try:
        sec = int(interval)
    except Exception:
        sec = 5
    if sec > 0 and os.path.exists(stamp) and time.time() - os.path.getmtime(stamp) < sec:
        return
    subprocess.run(["git", "fetch", "--prune", "--all"], text=True)
    try:
        with open(stamp, "w") as f:
            f.write(str(int(time.time())))
    except OSError:
        pass


def main():
    opts = parse_args(sys.argv[1:])
    ensure_repo()
    update = opts["update"] if opts["update"] is not None else bool_config("trim.update", True)
    confirm = opts["confirm"] if opts["confirm"] is not None else bool_config("trim.confirm", True)
    interval = opts["update_interval"] if opts["update_interval"] is not None else (git_config("trim.updateInterval") or "5")
    maybe_update(update, interval)
    data = classify(opts)
    print_report(*data[:3], data[3], data[4])
    delete_actions(data[3], data[4], opts["dry_run"], confirm)


if __name__ == "__main__":
    try:
        main()
    except GitError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
