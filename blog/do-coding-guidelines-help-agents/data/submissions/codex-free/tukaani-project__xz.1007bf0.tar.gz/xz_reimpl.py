#!/usr/bin/env python3
import argparse
import binascii
import os
import stat
import sys


VERSION = "xz (XZ Utils) 5.8.2\nliblzma 5.8.2"

SHORT_HELP = """Usage: ./executable [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files
  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -h, --help          display this short help and exit
  -H, --long-help     display the long help (lists also the advanced options)
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
"""

LONG_HELP = """Usage: ./executable [OPTION]... [FILE]...
Compress or decompress FILEs in the .xz format.

Mandatory arguments to long options are mandatory for short options too.

 Operation mode:

  -z, --compress      force compression
  -d, --decompress    force decompression
  -t, --test          test compressed file integrity
  -l, --list          list information about .xz files

 Operation modifiers:

  -k, --keep          keep (don't delete) input files
  -f, --force         force overwrite of output file and (de)compress links
  -c, --stdout        write to standard output and don't delete input files
      --no-sync       don't synchronize the output file to the storage device
                      before removing the input file
      --single-stream decompress only the first stream, and silently ignore
                      possible remaining input data
      --no-sparse     do not create sparse files when decompressing
  -S, --suffix=.SUF   use the suffix '.SUF' on compressed files
      --files[=FILE]  read filenames to process from FILE; if FILE is omitted,
                      filenames are read from the standard input; filenames
                      must be terminated with the newline character
      --files0[=FILE] like --files but use the null character as terminator

 Basic file format and compression options:

  -F, --format=FORMAT file format to encode or decode; possible values are
                      'auto' (default), 'xz', 'lzma', 'lzip', and 'raw'
  -C, --check=NAME    integrity check type: 'none' (use with caution), 'crc32',
                      'crc64' (default), or 'sha256'
      --ignore-check  don't verify the integrity check when decompressing
  -0 ... -9           compression preset; default is 6; take compressor *and*
                      decompressor memory usage into account before using 7-9!
  -e, --extreme       try to improve compression ratio by using more CPU time;
                      does not affect decompressor memory requirements
  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as
                      many threads as there are processor cores
      --block-size=SIZE
                      start a new .xz block after every SIZE bytes of input;
                      use this to set the block size for threaded compression
      --block-list=BLOCKS
                      start a new .xz block after the given comma-separated
                      intervals of uncompressed data; optionally, specify a
                      filter chain number (0-9) followed by a ':' before the
                      uncompressed data size
      --flush-timeout=NUM
                      when compressing, if more than NUM milliseconds has
                      passed since the previous flush and reading more input
                      would block, all pending data is flushed out
      --memlimit-compress=LIMIT
      --memlimit-decompress=LIMIT
      --memlimit-mt-decompress=LIMIT
  -M, --memlimit=LIMIT
                      set memory usage limit for compression, decompression,
                      threaded decompression, or all of these; LIMIT is in
                      bytes, % of RAM, or 0 for defaults
      --no-adjust     if compression settings exceed the memory usage limit,
                      give an error instead of adjusting the settings downwards

 Custom filter chain for compression (an alternative to using presets):

  --filters=FILTERS   set the filter chain using the liblzma filter string
                      syntax; use --filters-help for more information
  --filters1=FILTERS ... --filters9=FILTERS
                      set additional filter chains using the liblzma filter
                      string syntax to use with --block-list
  --filters-help      display more information about the liblzma filter string
                      syntax and exit

 Other options:

  -q, --quiet         suppress warnings; specify twice to suppress errors too
  -v, --verbose       be verbose; specify twice for even more verbose
  -Q, --no-warn       make warnings not affect the exit status
      --robot         use machine-parsable messages (useful for scripts)

      --info-memory   display the total amount of RAM and the currently active
                      memory usage limits, and exit
  -h, --help          display the short help (lists only the basic options)
  -H, --long-help     display this long help and exit
  -V, --version       display the version number and exit

With no FILE, or when FILE is -, read standard input.

Report bugs to <xz@tukaani.org> (in English or Finnish).
XZ Utils home page: <https://tukaani.org/xz/>
"""


class XZError(Exception):
    pass


def prog():
    return sys.argv[0]


def err(msg, quiet=0):
    if quiet < 2:
        print(f"{prog()}: {msg}", file=sys.stderr)


def parse_size(s):
    try:
        return int(s)
    except ValueError:
        units = {"k": 1024, "m": 1024**2, "g": 1024**3, "ki": 1024, "mi": 1024**2, "gi": 1024**3}
        lower = s.lower().rstrip("b")
        for u, mult in units.items():
            if lower.endswith(u):
                return int(float(lower[:-len(u)]) * mult)
    raise XZError(f"Invalid integer '{s}'")


def normalize_args(argv):
    out = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            out.extend(argv[i:])
            break
        if a.startswith("-") and not a.startswith("--") and len(a) > 2:
            j = 1
            while j < len(a):
                ch = a[j]
                if ch in "0123456789zdtlkfcqveQhHV":
                    out.append("-" + ch)
                    j += 1
                elif ch in "TSFCM":
                    out.append("-" + ch)
                    if j + 1 < len(a):
                        out.append(a[j + 1:])
                    elif i + 1 < len(argv):
                        i += 1
                        out.append(argv[i])
                    break
                else:
                    out.append("-" + ch)
                    j += 1
        else:
            out.append(a)
        i += 1
    return out


def parse(argv):
    ns = argparse.Namespace(mode="compress", keep=False, force=False, stdout=False,
                            preset=6, extreme=False, suffix=".xz", fmt="auto",
                            check="crc64", quiet=0, verbose=0, robot=False,
                            files=[], single_stream=False, ignore_check=False,
                            no_warn=False, info_memory=False)
    args = []
    argv = normalize_args(argv)
    i = 0
    while i < len(argv):
        a = argv[i]
        def need():
            nonlocal i
            if "=" in a:
                return a.split("=", 1)[1]
            i += 1
            if i >= len(argv):
                raise XZError(f"{a}: option requires an argument")
            return argv[i]
        if a == "--":
            args.extend(argv[i + 1:])
            break
        elif a in ("-z", "--compress"):
            ns.mode = "compress"
        elif a in ("-d", "--decompress", "--uncompress"):
            ns.mode = "decompress"
        elif a in ("-t", "--test"):
            ns.mode = "test"
        elif a in ("-l", "--list"):
            ns.mode = "list"
        elif a in ("-k", "--keep"):
            ns.keep = True
        elif a in ("-f", "--force"):
            ns.force = True
        elif a in ("-c", "--stdout", "--to-stdout"):
            ns.stdout = True
            ns.keep = True
        elif a in ("-e", "--extreme"):
            ns.extreme = True
        elif a in ("-q", "--quiet"):
            ns.quiet += 1
        elif a in ("-v", "--verbose"):
            ns.verbose += 1
        elif a in ("-Q", "--no-warn"):
            ns.no_warn = True
        elif a in ("-h", "--help"):
            print(SHORT_HELP, end="")
            raise SystemExit(0)
        elif a in ("-H", "--long-help"):
            print(LONG_HELP, end="")
            raise SystemExit(0)
        elif a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        elif a == "--robot":
            ns.robot = True
        elif a == "--single-stream":
            ns.single_stream = True
        elif a in ("--ignore-check", "--no-sparse", "--no-sync", "--no-adjust"):
            pass
        elif a == "--info-memory":
            ns.info_memory = True
        elif a.startswith("-") and len(a) == 2 and a[1].isdigit():
            ns.preset = int(a[1])
        elif a == "-S" or a.startswith("--suffix"):
            ns.suffix = need()
        elif a == "-F" or a.startswith("--format"):
            ns.fmt = need()
        elif a == "-C" or a.startswith("--check"):
            ns.check = need()
        elif a == "-T" or a.startswith("--threads") or a.startswith("--block-size") or a.startswith("--block-list") or a.startswith("--flush-timeout") or a.startswith("--memlimit") or a == "-M":
            if "=" not in a and a not in ("--memlimit-compress", "--memlimit-decompress", "--memlimit-mt-decompress"):
                _ = need()
            elif a in ("--memlimit-compress", "--memlimit-decompress", "--memlimit-mt-decompress"):
                _ = need()
        elif a.startswith("--files0"):
            val = a.split("=", 1)[1] if "=" in a else None
            ns.files.extend(read_file_list(val, b"\0"))
        elif a.startswith("--files"):
            val = a.split("=", 1)[1] if "=" in a else None
            ns.files.extend(read_file_list(val, b"\n"))
        elif a.startswith("--filters-help"):
            print("Filter chains are not supported by this reimplementation.")
            raise SystemExit(0)
        elif a.startswith("--filters") or a.startswith("--lzma") or a.startswith("--x86") or a.startswith("--arm") or a.startswith("--powerpc") or a.startswith("--ia64") or a.startswith("--sparc") or a.startswith("--riscv") or a.startswith("--delta"):
            if "=" not in a and a in ("--filters", "--filters1", "--filters2", "--filters3", "--filters4", "--filters5", "--filters6", "--filters7", "--filters8", "--filters9"):
                _ = need()
            pass
        elif a.startswith("-"):
            err(f"unrecognized option '{a}'")
            err(f"Try '{prog()} --help' for more information.")
            raise SystemExit(1)
        else:
            args.append(a)
        i += 1
    args.extend(ns.files)
    if not args:
        args = ["-"]
        ns.stdout = True
        ns.keep = True
    return ns, args


def read_file_list(path, sep):
    data = sys.stdin.buffer.read() if path in (None, "-") else open(path, "rb").read()
    return [x.decode() for x in data.split(sep) if x]


def fmt_const(fmt, compress=False):
    if fmt in ("auto", "xz"):
        return "xz"
    if fmt == "lzma":
        return "lzma"
    raise XZError(f"Unsupported file format '{fmt}'")


def check_const(name):
    table = {"none": 0, "crc32": 1, "crc64": 4, "sha256": 10}
    if name not in table:
        raise XZError(f"Unsupported check '{name}'")
    return table[name]


def compressed_name(path, suffix):
    return path + suffix


def decompressed_name(path, suffix, fmt):
    endings = [suffix]
    if suffix != ".xz":
        endings.append(".xz")
    endings += [".txz", ".lzma", ".tlz"]
    for e in endings:
        if path.endswith(e):
            if e in (".txz", ".tlz"):
                return path[:-len(e)] + ".tar"
            return path[:-len(e)]
    raise XZError(f"{path}: Filename has an unknown suffix, skipping")


def open_input(path):
    if path == "-":
        return sys.stdin.buffer.read(), None
    try:
        st = os.lstat(path)
        if stat.S_ISDIR(st.st_mode):
            raise IsADirectoryError(path)
        with open(path, "rb") as f:
            return f.read(), st
    except FileNotFoundError:
        raise XZError(f"{path}: No such file or directory")
    except PermissionError:
        raise XZError(f"{path}: Permission denied")
    except IsADirectoryError:
        raise XZError(f"{path}: Is a directory")


def write_output(path, data, force, st=None):
    if path == "-":
        sys.stdout.buffer.write(data)
        return
    if os.path.exists(path) and not force:
        raise XZError(f"{path}: File exists")
    with open(path, "wb") as f:
        f.write(data)
    if st is not None:
        try:
            os.chmod(path, stat.S_IMODE(st.st_mode))
            os.utime(path, (st.st_atime, st.st_mtime))
        except OSError:
            pass


def crc32(data):
    return binascii.crc32(data) & 0xffffffff


def le32(n):
    return n.to_bytes(4, "little")


def encode_vli(n):
    if n < 0:
        raise XZError("Internal error")
    out = bytearray()
    while True:
        b = n & 0x7f
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def decode_vli(buf, pos):
    shift = 0
    val = 0
    while pos < len(buf):
        b = buf[pos]
        pos += 1
        val |= (b & 0x7f) << shift
        if not (b & 0x80):
            return val, pos
        shift += 7
        if shift > 63:
            break
    raise XZError("File format not recognized")


def lzma2_uncompressed(data):
    out = bytearray()
    first = True
    for off in range(0, len(data), 65536):
        chunk = data[off:off + 65536]
        out.append(0x01 if first else 0x02)
        first = False
        n = len(chunk) - 1
        out.extend([(n >> 8) & 0xff, n & 0xff])
        out.extend(chunk)
    out.append(0x00)
    return bytes(out)


def parse_lzma2_uncompressed(data):
    out, used = parse_lzma2_stream(data)
    if any(data[used:]):
        raise XZError("File format not recognized")
    return out


def parse_lzma2_stream(data):
    pos = 0
    out = bytearray()
    while pos < len(data):
        control = data[pos]
        pos += 1
        if control == 0:
            return bytes(out), pos
        if control not in (0x01, 0x02):
            raise XZError("Unsupported options")
        if pos + 2 > len(data):
            raise XZError("Compressed data is corrupt")
        size = ((data[pos] << 8) | data[pos + 1]) + 1
        pos += 2
        if pos + size > len(data):
            raise XZError("Compressed data is corrupt")
        out.extend(data[pos:pos + size])
        pos += size
    raise XZError("Compressed data is corrupt")


def check_bytes(check_id, data):
    if check_id == 0:
        return b""
    if check_id == 1:
        return le32(crc32(data))
    raise XZError("Unsupported check type")


def make_block(data, check_id):
    payload = lzma2_uncompressed(data)
    header = bytearray([0, 0xC0])
    header.extend(encode_vli(len(payload)))
    header.extend(encode_vli(len(data)))
    header.extend([0x21, 0x01, 22])
    while (len(header) + 4) % 4 != 0:
        header.append(0)
    header[0] = len(header) // 4
    header.extend(le32(crc32(header)))
    check = check_bytes(check_id, data)
    unpadded = len(header) + len(payload) + len(check)
    block = bytes(header) + payload
    while len(block) % 4 != 0:
        block += b"\0"
    block += check
    return block, unpadded, len(data)


def make_index(records):
    idx = bytearray([0])
    idx.extend(encode_vli(len(records)))
    for unpadded, uncomp in records:
        idx.extend(encode_vli(unpadded))
        idx.extend(encode_vli(uncomp))
    while (len(idx) + 4) % 4 != 0:
        idx.append(0)
    idx.extend(le32(crc32(idx)))
    return bytes(idx)


def make_xz(data, requested_check):
    check_id = requested_check
    if check_id not in (0, 1):
        check_id = 1
    flags = bytes([0, check_id])
    stream = bytearray(b"\xfd7zXZ\x00")
    stream.extend(flags)
    stream.extend(le32(crc32(flags)))
    block, unpadded, uncomp = make_block(data, check_id)
    stream.extend(block)
    index = make_index([(unpadded, uncomp)])
    stream.extend(index)
    footer_fields = le32(len(index) // 4 - 1) + flags
    stream.extend(le32(crc32(footer_fields)))
    stream.extend(footer_fields)
    stream.extend(b"YZ")
    return bytes(stream)


def parse_block(buf, pos, check_id):
    if pos >= len(buf) or buf[pos] == 0:
        raise XZError("File format not recognized")
    header_size = (buf[pos] + 1) * 4
    if pos + header_size > len(buf):
        raise XZError("Compressed data is corrupt")
    header = buf[pos:pos + header_size]
    if crc32(header[:-4]) != int.from_bytes(header[-4:], "little"):
        raise XZError("Compressed data is corrupt")
    hpos = 1
    flags = header[hpos]
    hpos += 1
    if flags & 0x3c:
        raise XZError("Unsupported options")
    has_csize = bool(flags & 0x40)
    has_usize = bool(flags & 0x80)
    filters = (flags & 0x03) + 1
    comp_size = None
    uncomp_size = None
    if has_csize:
        comp_size, hpos = decode_vli(header, hpos)
    if has_usize:
        uncomp_size, hpos = decode_vli(header, hpos)
    for _ in range(filters):
        fid, hpos = decode_vli(header, hpos)
        plen, hpos = decode_vli(header, hpos)
        props = header[hpos:hpos + plen]
        hpos += plen
    if filters != 1 or fid != 0x21 or plen != 1:
        raise XZError("Unsupported options")
    data_start = pos + header_size
    if comp_size is None:
        plain, comp_size = parse_lzma2_stream(buf[data_start:])
        payload = buf[data_start:data_start + comp_size]
    else:
        payload = buf[data_start:data_start + comp_size]
        plain = parse_lzma2_uncompressed(payload)
    if uncomp_size is not None and uncomp_size != len(plain):
        raise XZError("Compressed data is corrupt")
    check_len = {0: 0, 1: 4}.get(check_id)
    if check_len is None:
        raise XZError("Unsupported check type")
    after = data_start + comp_size
    while (after - pos) % 4 != 0:
        if after >= len(buf) or buf[after] != 0:
            raise XZError("Compressed data is corrupt")
        after += 1
    if after + check_len > len(buf):
        raise XZError("Compressed data is corrupt")
    if buf[after:after + check_len] != check_bytes(check_id, plain):
        raise XZError("Compressed data is corrupt")
    after += check_len
    return plain, after


def parse_xz(data, single_stream=False):
    if len(data) < 24 or data[:6] != b"\xfd7zXZ\x00" or data[-2:] != b"YZ":
        raise XZError("File format not recognized")
    flags = data[6:8]
    if crc32(flags) != int.from_bytes(data[8:12], "little"):
        raise XZError("Compressed data is corrupt")
    if flags[0] != 0:
        raise XZError("Unsupported options")
    check_id = flags[1] & 0x0f
    if check_id not in (0, 1):
        raise XZError("Unsupported check type")
    footer_fields = data[-8:-2]
    if crc32(footer_fields) != int.from_bytes(data[-12:-8], "little"):
        raise XZError("Compressed data is corrupt")
    out, pos = parse_block(data, 12, check_id)
    return out


def compress_data(data, ns):
    fmt = fmt_const(ns.fmt if ns.fmt != "auto" else "xz", True)
    if fmt != "xz":
        raise XZError(f"Unsupported file format '{ns.fmt}'")
    return make_xz(data, check_const(ns.check))


def decompress_data(data, ns):
    fmt = fmt_const(ns.fmt)
    if fmt != "xz":
        raise XZError("File format not recognized")
    return parse_xz(data, ns.single_stream)


def process_one(path, ns):
    data, st = open_input(path)
    if ns.mode == "compress":
        out = compress_data(data, ns)
        outpath = "-" if ns.stdout else compressed_name(path, ns.suffix)
        write_output(outpath, out, ns.force, st)
    elif ns.mode == "decompress":
        out = decompress_data(data, ns)
        outpath = "-" if ns.stdout else decompressed_name(path, ns.suffix, ns.fmt)
        write_output(outpath, out, ns.force, st)
    elif ns.mode == "test":
        _ = decompress_data(data, ns)
    elif ns.mode == "list":
        list_one(path, data, ns)
    if path != "-" and not ns.keep and ns.mode in ("compress", "decompress"):
        try:
            os.unlink(path)
        except OSError:
            pass


def human(n):
    if n < 1024:
        return f"{n} B"
    units = ["KiB", "MiB", "GiB", "TiB"]
    v = float(n)
    for u in units:
        v /= 1024.0
        if v < 1024:
            return f"{v:.1f} {u}"
    return f"{v:.1f} PiB"


def ratio(comp, uncomp):
    if uncomp == 0:
        return "---"
    r = comp / uncomp
    return "---" if r > 9.999 else f"{r:.3f}"


def list_one(path, data, ns):
    try:
        plain = parse_xz(data)
    except XZError:
        raise XZError(f"{path}: File format not recognized")
    c = len(data)
    u = len(plain)
    r = ratio(c, u)
    check = "CRC32" if len(data) > 8 and (data[7] & 0x0f) == 1 else "None"
    if ns.robot:
        print(f"name\t{path}")
        print(f"file\t1\t1\t{c}\t{u}\t{r}\t{check}\t0")
        if ns.verbose:
            print(f"stream\t1\t1\t0\t0\t{c}\t{u}\t{r}\t{check}\t0")
            print(f"block\t1\t1\t1\t12\t0\t{max(0, c - 32)}\t{u}\t{r}\t{check}")
        print(f"totals\t1\t1\t{c}\t{u}\t{r}\t{check}\t0\t1")
        return
    if ns.verbose:
        print(f"{path} (1/1)")
        print("  Streams:           1")
        print("  Blocks:            1")
        print(f"  Compressed size:   {human(c)}")
        print(f"  Uncompressed size: {human(u)}")
        print(f"  Ratio:             {r}")
        print(f"  Check:             {check}")
        print("  Stream Padding:    0 B")
    else:
        print("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename")
        print(f"{1:5d} {1:7d} {human(c):>10s} {human(u):>12s} {r:>6s}  {check:<6s}  {path}")


def main(argv):
    try:
        ns, files = parse(argv)
        if ns.info_memory:
            print("Total amount of physical memory (RAM): 0 B")
            return 0
        status = 0
        for p in files:
            try:
                process_one(p, ns)
            except XZError as e:
                err(str(e), ns.quiet)
                status = 1
        return 0 if ns.no_warn else status
    except XZError as e:
        err(str(e))
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
