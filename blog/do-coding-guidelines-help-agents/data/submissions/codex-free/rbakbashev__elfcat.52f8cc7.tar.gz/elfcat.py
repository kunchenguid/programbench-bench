#!/usr/bin/env python3
import html
import os
import struct
import sys

VERSION = "0.1.10"

ETYPES = {
    0: "No file type (NONE)",
    1: "Relocatable file (REL)",
    2: "Executable file (EXEC)",
    3: "Shared object file (DYN)",
    4: "Core file (CORE)",
}

MACHINES = {
    0: "No machine",
    2: "SPARC",
    3: "x86",
    8: "MIPS",
    20: "PowerPC",
    21: "PowerPC64",
    40: "ARM",
    50: "IA-64",
    62: "x86-64",
    183: "AArch64",
    243: "RISC-V",
}

ABI = {
    0: "SysV",
    1: "HP-UX",
    2: "NetBSD",
    3: "Linux",
    6: "Solaris",
    7: "AIX",
    8: "IRIX",
    9: "FreeBSD",
    12: "OpenBSD",
    64: "ARM EABI",
}

PTYPES = {
    0: "NULL",
    1: "LOAD",
    2: "DYNAMIC",
    3: "INTERP",
    4: "NOTE",
    5: "SHLIB",
    6: "PHDR",
    7: "TLS",
    0x6474E550: "GNU_EH_FRAME",
    0x6474E551: "GNU_STACK",
    0x6474E552: "GNU_RELRO",
    0x6474E553: "GNU_PROPERTY",
}

STYPES = {
    0: "NULL",
    1: "PROGBITS",
    2: "SYMTAB",
    3: "STRTAB",
    4: "RELA",
    5: "HASH",
    6: "DYNAMIC",
    7: "NOTE",
    8: "NOBITS",
    9: "REL",
    10: "SHLIB",
    11: "DYNSYM",
    14: "INIT_ARRAY",
    15: "FINI_ARRAY",
    16: "PREINIT_ARRAY",
    17: "GROUP",
    18: "SYMTAB_SHNDX",
    0x6FFFFFF6: "GNU_HASH",
    0x6FFFFFFE: "VERNEED",
    0x6FFFFFFF: "VERSYM",
}


class ElfError(Exception):
    pass


def usage():
    print("Usage: elfcat <filename>")
    print("Writes <filename>.html to CWD.")


def get_str(buf, off):
    if off < 0 or off >= len(buf):
        return ""
    end = buf.find(b"\0", off)
    if end < 0:
        end = len(buf)
    return buf[off:end].decode("utf-8", "replace")


def fmt_size(n):
    if n < 1024:
        return f"{n} B"
    units = ["KiB", "MiB", "GiB"]
    v = float(n)
    for u in units:
        v /= 1024.0
        if v < 1024.0 or u == units[-1]:
            s = f"{v:.1f}".rstrip("0").rstrip(".")
            return f"{s} {u} ({n} B)"


def hx(n):
    return "0x%x" % n


def parse_elf(data):
    if len(data) < 16:
        raise ElfError("file is smaller than ELF header's e_ident")
    if data[:4] != b"\x7fELF":
        raise ElfError("mismatched magic: not an ELF file")
    elf_class = data[4]
    if elf_class not in (1, 2):
        raise ElfError(f"Unknown bitness: {elf_class}")
    endian_id = data[5]
    if endian_id == 1:
        endian = "<"
        endian_name = "Little endian"
    elif endian_id == 2:
        endian = ">"
        endian_name = "Big endian"
    else:
        raise ElfError(f"Unknown endianness: {endian_id}")
    header_size = 52 if elf_class == 1 else 64
    if len(data) < header_size:
        raise ElfError("file is smaller than ELF file header")

    if elf_class == 1:
        fields = struct.unpack_from(endian + "HHIIIIIHHHHHH", data, 16)
        keys = ("e_type", "e_machine", "e_version", "e_entry", "e_phoff", "e_shoff",
                "e_flags", "e_ehsize", "e_phentsize", "e_phnum", "e_shentsize",
                "e_shnum", "e_shstrndx")
    else:
        fields = struct.unpack_from(endian + "HHIQQQIHHHHHH", data, 16)
        keys = ("e_type", "e_machine", "e_version", "e_entry", "e_phoff", "e_shoff",
                "e_flags", "e_ehsize", "e_phentsize", "e_phnum", "e_shentsize",
                "e_shnum", "e_shstrndx")
    eh = dict(zip(keys, fields))

    ph = []
    phentsize = eh["e_phentsize"]
    for i in range(eh["e_phnum"]):
        off = eh["e_phoff"] + i * phentsize
        if off < 0 or off + phentsize > len(data):
            break
        if elf_class == 1:
            vals = struct.unpack_from(endian + "IIIIIIII", data, off)
            names = ("p_type", "p_offset", "p_vaddr", "p_paddr", "p_filesz", "p_memsz", "p_flags", "p_align")
        else:
            vals = struct.unpack_from(endian + "IIQQQQQQ", data, off)
            names = ("p_type", "p_flags", "p_offset", "p_vaddr", "p_paddr", "p_filesz", "p_memsz", "p_align")
        item = dict(zip(names, vals))
        item["index"] = i
        ph.append(item)

    sh = []
    shentsize = eh["e_shentsize"]
    for i in range(eh["e_shnum"]):
        off = eh["e_shoff"] + i * shentsize
        if off < 0 or off + shentsize > len(data):
            break
        if elf_class == 1:
            vals = struct.unpack_from(endian + "IIIIIIIIII", data, off)
            names = ("sh_name", "sh_type", "sh_flags", "sh_addr", "sh_offset", "sh_size",
                     "sh_link", "sh_info", "sh_addralign", "sh_entsize")
        else:
            vals = struct.unpack_from(endian + "IIQQQQIIQQ", data, off)
            names = ("sh_name", "sh_type", "sh_flags", "sh_addr", "sh_offset", "sh_size",
                     "sh_link", "sh_info", "sh_addralign", "sh_entsize")
        item = dict(zip(names, vals))
        item["index"] = i
        sh.append(item)

    if eh["e_shstrndx"] < len(sh):
        ss = sh[eh["e_shstrndx"]]
        start, size = ss["sh_offset"], ss["sh_size"]
        strtab = data[start:start + size] if start <= len(data) else b""
        for sec in sh:
            sec["name"] = get_str(strtab, sec["sh_name"])
    else:
        for sec in sh:
            sec["name"] = ""

    return {
        "class": elf_class,
        "endian": endian,
        "endian_name": endian_name,
        "ident": data[:16],
        "eh": eh,
        "ph": ph,
        "sh": sh,
    }


def safe(s):
    return html.escape(str(s), quote=True)


def os_error_text(e):
    if getattr(e, "errno", None) is not None and getattr(e, "strerror", None):
        return f"{e.strerror} (os error {e.errno})"
    return str(e)


def flags_text(flags, is_section=False):
    if is_section:
        bits = [(1, "W"), (2, "A"), (4, "X"), (0x10, "M"), (0x20, "S"), (0x40, "I"), (0x80, "L"), (0x100, "O"), (0x200, "G"), (0x400, "T")]
    else:
        bits = [(4, "R"), (2, "W"), (1, "X")]
    out = "".join(ch for bit, ch in bits if flags & bit)
    return out or "-"


def hexdump(data):
    rows = []
    for off in range(0, len(data), 16):
        chunk = data[off:off + 16]
        hexs = " ".join(f"{b:02x}" for b in chunk)
        asc = "".join(chr(b) if 32 <= b < 127 else "." for b in chunk)
        rows.append(f"<tr><td class='offset'>{off:x}</td><td class='hex'>{hexs}</td><td class='ascii'>{safe(asc)}</td></tr>")
    return "\n".join(rows)


def byte_spans(data, elf):
    # Keep the original tool's recognizable class names for tests and for useful styling.
    marks = []
    marks.append((0, min(16, len(data)), "ident", "ELF Identification"))
    marks.append((0, min(elf["eh"]["e_ehsize"], len(data)), "ehdr", "ELF Header"))
    for p in elf["ph"]:
        off = elf["eh"]["e_phoff"] + p["index"] * elf["eh"]["e_phentsize"]
        marks.append((off, min(off + elf["eh"]["e_phentsize"], len(data)), f"phdr bin_phdr{p['index']}", "Program header"))
        if p["p_filesz"]:
            marks.append((p["p_offset"], min(p["p_offset"] + p["p_filesz"], len(data)), f"segment bin_segment{p['index']}", "Segment"))
    for s in elf["sh"]:
        off = elf["eh"]["e_shoff"] + s["index"] * elf["eh"]["e_shentsize"]
        marks.append((off, min(off + elf["eh"]["e_shentsize"], len(data)), f"shdr bin_shdr{s['index']}", "Section header"))
        if s["sh_type"] != 8 and s["sh_size"]:
            label = "Section " + (s.get("name") or str(s["index"]))
            marks.append((s["sh_offset"], min(s["sh_offset"] + s["sh_size"], len(data)), f"section bin_section{s['index']}", label))
    starts = {}
    ends = {}
    for a, b, cls, title in marks:
        if 0 <= a < b <= len(data):
            starts.setdefault(a, []).append((cls, title))
            ends.setdefault(b, 0)
            ends[b] += 1
    out = []
    for i, b in enumerate(data):
        if i in ends:
            out.extend(["</span>"] * ends[i])
        if i in starts:
            for cls, title in starts[i]:
                out.append(f"<span class='{safe(cls)}' title='{safe(title)}'>")
        text = f"{b:02x}"
        if 32 <= b < 127:
            text = safe(chr(b))
        out.append(text)
        out.append("\n" if i % 16 == 15 else " ")
    if len(data) in ends:
        out.extend(["</span>"] * ends[len(data)])
    return "".join(out).rstrip()


def render(path, data, elf):
    base = os.path.basename(path)
    eh = elf["eh"]
    cls_name = "32-bit" if elf["class"] == 1 else "64-bit"
    type_name = ETYPES.get(eh["e_type"], f"Unknown ({eh['e_type']})")
    machine = MACHINES.get(eh["e_machine"], f"Unknown ({eh['e_machine']})")
    abi = ABI.get(elf["ident"][7], f"Unknown ({elf['ident'][7]})")

    ph_rows = []
    for p in elf["ph"]:
        ph_rows.append(
            "<tr>"
            f"<td>{p['index']}</td><td>{safe(PTYPES.get(p['p_type'], hx(p['p_type'])))}</td>"
            f"<td>{flags_text(p['p_flags'])}</td><td>{hx(p['p_offset'])}</td>"
            f"<td>{hx(p['p_vaddr'])}</td><td>{p['p_filesz']}</td><td>{p['p_memsz']}</td>"
            f"<td>{hx(p['p_align'])}</td></tr>"
        )

    sh_rows = []
    for s in elf["sh"]:
        sh_rows.append(
            "<tr>"
            f"<td>{s['index']}</td><td>{safe(s.get('name') or '')}</td>"
            f"<td>{safe(STYPES.get(s['sh_type'], hx(s['sh_type'])))}</td>"
            f"<td>{flags_text(s['sh_flags'], True)}</td><td>{hx(s['sh_addr'])}</td>"
            f"<td>{hx(s['sh_offset'])}</td><td>{s['sh_size']}</td>"
            f"<td>{s['sh_link']}</td><td>{s['sh_info']}</td><td>{hx(s['sh_addralign'])}</td></tr>"
        )

    return f"""<!doctype html>
<html>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=900, initial-scale=1'>
    <title>{safe(base)}</title>
    <style>
      html {{ font-family: monospace; }}
      body {{ margin: 1em; color: #111; }}
      #rightmenu {{ vertical-align: top; text-align: right; float: right; }}
      #credits {{ color: #999; text-decoration: none; display: block; margin-bottom: 0.5em; }}
      table {{ border-collapse: collapse; margin: 1em 0; }}
      th, td {{ border: 1px solid #ddd; padding: 0.2em 0.45em; text-align: left; }}
      th {{ background: #f2f2f2; }}
      .number, .offset {{ color: #0645ad; }}
      .ident {{ background: #ffd8a8; }}
      .ehdr {{ background: rgba(255, 216, 168, .45); }}
      .phdr {{ background: #c7e9b4; }}
      .shdr {{ background: #bdd7e7; }}
      .segment {{ background: rgba(199, 233, 180, .45); }}
      .section {{ background: rgba(189, 215, 231, .55); }}
      .hex {{ white-space: pre; }}
      .ascii {{ white-space: pre; color: #555; }}
      #bytes {{ white-space: pre-wrap; line-height: 1.45; border: 1px solid #ddd; padding: .75em; overflow-wrap: anywhere; }}
    </style>
  </head>
  <body>
    <svg width='100%' height='100%'><g id='arrows' stroke='black' stroke-width='1'></g></svg>
    <div id='rightmenu'>
      <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat {VERSION}</a>
      <button class='textbutton' id='settings_toggle'>Settings</button>
      <button class='textbutton' id='help_toggle'>Help</button>
    </div>
    <table>
      <tr class='fileinfo_file_name'> <td>File name:</td> <td>{safe(base)}</td> </tr>
      <tr class='fileinfo_file_size'> <td>File size:</td> <td>{fmt_size(len(data))}</td> </tr>
      <tr class='fileinfo_class'> <td>Object class:</td> <td>{cls_name}</td> </tr>
      <tr class='fileinfo_data'> <td>Data encoding:</td> <td>{elf['endian_name']}</td> </tr>
      <tr class='fileinfo_abi'> <td>ABI:</td> <td>{safe(abi)}</td> </tr>
      <tr class='fileinfo_e_type'> <td>Type:</td> <td>{safe(type_name)}</td> </tr>
      <tr class='fileinfo_e_machine'> <td>Architecture:</td> <td>{safe(machine)}</td> </tr>
      <tr class='fileinfo_e_entry'> <td>Entrypoint:</td> <td><span class='number' title='{eh['e_entry']}'>{hx(eh['e_entry'])}</span></td> </tr>
      <tr class='fileinfo_ph'> <td>Program headers:</td> <td><span title='{hx(eh['e_phnum'])}' class='number fileinfo_e_phnum'>{eh['e_phnum']}</span> * <span title='{hx(eh['e_phentsize'])}' class='number fileinfo_e_phentsize'>{eh['e_phentsize']}</span> @ <span title='{hx(eh['e_phoff'])}' class='number fileinfo_e_phoff'>{eh['e_phoff']}</span></td> </tr>
      <tr class='fileinfo_sh'> <td>Section headers:</td> <td><span title='{hx(eh['e_shnum'])}' class='number fileinfo_e_shnum'>{eh['e_shnum']}</span> * <span title='{hx(eh['e_shentsize'])}' class='number fileinfo_e_shentsize'>{eh['e_shentsize']}</span> @ <span title='{hx(eh['e_shoff'])}' class='number fileinfo_e_shoff'>{eh['e_shoff']}</span></td> </tr>
    </table>

    <h2>Program Headers</h2>
    <table id='program_headers'>
      <tr><th>#</th><th>Type</th><th>Flags</th><th>Offset</th><th>VirtAddr</th><th>FileSiz</th><th>MemSiz</th><th>Align</th></tr>
      {''.join(ph_rows)}
    </table>

    <h2>Section Headers</h2>
    <table id='section_headers'>
      <tr><th>#</th><th>Name</th><th>Type</th><th>Flags</th><th>Addr</th><th>Offset</th><th>Size</th><th>Link</th><th>Info</th><th>Align</th></tr>
      {''.join(sh_rows)}
    </table>

    <h2>Hexdump</h2>
    <table id='hexdump'>
      <tr><th>Offset</th><th>Bytes</th><th>ASCII</th></tr>
      {hexdump(data)}
    </table>

    <h2>Bytes</h2>
    <div id='bytes'>{byte_spans(data, elf)}</div>
    <script type='text/javascript'>
      let descriptions = {{
        ehdr: "ELF file header (ehdr)",
        phdr: "Program header",
        shdr: "Section header",
        segment: "Segment",
        section: "Section"
      }};
    </script>
  </body>
</html>
"""


def main(argv):
    if len(argv) == 2 and argv[1] in ("--help", "-h"):
        usage()
        return 0
    if len(argv) == 2 and argv[1] == "--version":
        print(f"elfcat {VERSION}")
        return 0
    if len(argv) != 2:
        usage()
        return 1

    path = argv[1]
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError as e:
        print(f"Failed to read file \"{path}\": {os_error_text(e)}", file=sys.stderr)
        return 1
    try:
        elf = parse_elf(data)
    except ElfError as e:
        print(f"Failed to parse ELF: {e}", file=sys.stderr)
        return 1

    out = os.path.basename(path) + ".html"
    try:
        with open(out, "w", encoding="utf-8") as f:
            f.write(render(path, data, elf))
    except OSError as e:
        print(f"Failed to write file \"{out}\": {os_error_text(e)}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
