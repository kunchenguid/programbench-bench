#!/usr/bin/env python3
import sys, re, json

HELP = r'''tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\0), not LF (\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
                                  Implies --join
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
'''

class Opt:
    def __init__(self):
        self.greedy=False; self.compress=False; self.only_delimited=False
        self.zero=False; self.complement=False; self.join=None; self.json=False
        self.mode='fields'; self.bounds='1:'; self.delim='\t'; self.regex=None
        self.replace=None; self.trim=None; self.fallback=None; self.file=None

def need(args,i,opt):
    if i+1>=len(args):
        sys.stderr.write(f"the '{opt}' option doesn't have an associated value\n"); sys.exit(1)
    return args[i+1]

def parse(argv):
    o=Opt(); i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-h','--help'):
            print(HELP); sys.exit(0)
        if a in ('-V','--version'):
            print('tuc 1.3.0'); sys.exit(0)
        if a in ('-g','--greedy-delimiter'): o.greedy=True
        elif a in ('-p','--compress-delimiter'): o.compress=True
        elif a in ('-s','--only-delimited'): o.only_delimited=True
        elif a in ('-z','--zero-terminated'): o.zero=True
        elif a in ('-m','--complement'): o.complement=True
        elif a in ('-j','--join'): o.join=True
        elif a == '--no-join': o.join=False
        elif a == '--json': o.json=True
        elif a == '--no-mmap': pass
        elif a == '-M' or a == '--fixed-memory': i+=1
        elif a.startswith('-M') and a != '-M': pass
        elif a in ('-f','--fields','-b','--bytes','-c','--characters','-l','--lines'):
            if a in ('-b','--bytes'): o.mode='bytes'
            elif a in ('-c','--characters'): o.mode='chars'
            elif a in ('-l','--lines'): o.mode='lines'; o.join = True if o.join is None else o.join
            else: o.mode='fields'
            o.bounds=need(argv,i,a); i+=1
        elif a.startswith('--fields='): o.mode='fields'; o.bounds=a.split('=',1)[1]
        elif a.startswith('--bytes='): o.mode='bytes'; o.bounds=a.split('=',1)[1]
        elif a.startswith('--characters='): o.mode='chars'; o.bounds=a.split('=',1)[1]
        elif a.startswith('--lines='): o.mode='lines'; o.bounds=a.split('=',1)[1]; o.join=True if o.join is None else o.join
        elif a.startswith('-f') and a!='-f': o.mode='fields'; o.bounds=a[2:]
        elif a.startswith('-b') and a!='-b': o.mode='bytes'; o.bounds=a[2:]
        elif a.startswith('-c') and a!='-c': o.mode='chars'; o.bounds=a[2:]
        elif a.startswith('-l') and a!='-l': o.mode='lines'; o.bounds=a[2:]; o.join=True if o.join is None else o.join
        elif a in ('-d','--delimiter'): o.delim=need(argv,i,a); i+=1
        elif a.startswith('--delimiter='): o.delim=a.split('=',1)[1]
        elif a == '-e' or a == '--regex': o.regex=need(argv,i,a); i+=1
        elif a.startswith('--regex='): o.regex=a.split('=',1)[1]
        elif a in ('-r','--replace-delimiter'):
            o.replace=need(argv,i,a); o.join=True; i+=1
        elif a.startswith('-r') and a!='-r': o.replace=a[2:]; o.join=True
        elif a.startswith('--replace-delimiter='): o.replace=a.split('=',1)[1]; o.join=True
        elif a in ('-t','--trim'): o.trim=need(argv,i,a).lower()[0]; i+=1
        elif a.startswith('--trim='): o.trim=a.split('=',1)[1].lower()[0]
        elif a == '--fallback-oob': o.fallback=need(argv,i,a); i+=1
        elif a.startswith('--fallback-oob='): o.fallback=a.split('=',1)[1]
        elif a.startswith('-'):
            sys.stderr.write(f"error: Found argument '{a}' which wasn't expected\n"); sys.exit(1)
        else:
            o.file=a
        i+=1
    if o.join is None: o.join=False
    return o

def split_commas(s):
    res=[]; cur=''; depth=0
    for ch in s:
        if ch==',' and depth==0:
            res.append(cur); cur=''
        else: cur+=ch
    res.append(cur)
    return res

def resolve(n, total):
    return total+n+1 if n<0 else n

def parse_piece(p):
    fb=None
    if '=' in p and not p.strip().startswith('='):
        p,fb=p.split('=',1)
    if ':' in p:
        a,b=p.split(':',1)
        return ('range', int(a) if a else 1, int(b) if b else None, fb)
    return ('one', int(p), None, fb)

def is_format(s):
    return '{' in s or '}' in s

def split_fields(line,o):
    delim=o.delim
    if o.regex:
        pat=o.regex
        parts=[]; delims=[]; last=0
        for m in re.finditer(pat,line):
            parts.append(line[last:m.start()]); delims.append(m.group(0)); last=m.end()
        parts.append(line[last:]); return parts,delims
    s=line
    if o.trim:
        if o.trim in ('l','b'):
            while s.startswith(delim) and delim!='': s=s[len(delim):]
        if o.trim in ('r','b'):
            while s.endswith(delim) and delim!='': s=s[:-len(delim)]
    if (o.greedy or o.compress) and delim:
        pat=re.escape(delim)+r'+'
        parts=re.split(pat,s)
        delims=[delim]*(len(parts)-1)
        return parts,delims
    if delim=='': return list(s), ['']*max(0,len(s)-1)
    parts=s.split(delim); delims=[delim]*(len(parts)-1)
    return parts,delims

def err_oob(idx):
    sys.stderr.write(f"Error: Out of bounds: {idx}\n")
    raise IndexError

def collect(parts, delims, bounds, o):
    total=len(parts); pieces=parse_bounds(bounds)
    if o.complement:
        selected=set()
        for kind,a,b,fb in pieces:
            if kind=='one': selected.add(resolve(a,total))
            else:
                start=resolve(a,total); end=resolve(b,total) if b is not None else total
                lo,hi=(start,end) if start<=end else (end,start)
                selected.update(range(lo,hi+1))
        pieces=[]; start=None; prev=None
        for idx in range(1,total+1):
            if idx not in selected:
                if start is None: start=prev=idx
                elif idx==prev+1: prev=idx
                else: pieces.append(('range',start,prev,None) if start!=prev else ('one',start,None,None)); start=prev=idx
        if start is not None: pieces.append(('range',start,prev,None) if start!=prev else ('one',start,None,None))
    out=[]; json_fields=[]
    for kind,a,b,fb in pieces:
        if kind=='one':
            idx=resolve(a,total)
            if idx<1 or idx>total:
                val=fb if fb is not None else o.fallback
                if val is None: err_oob(idx)
                out.append(val); json_fields.append(val)
            else:
                out.append(parts[idx-1]); json_fields.append(parts[idx-1])
        else:
            start=resolve(a,total); end=resolve(b,total) if b is not None else total
            step=1 if start<=end else -1
            vals=[]
            for idx in range(start,end+step,step):
                if idx<1 or idx>total:
                    val=fb if fb is not None else o.fallback
                    if val is None: err_oob(idx)
                    vals.append(val); json_fields.append(val)
                else:
                    vals.append(parts[idx-1]); json_fields.append(parts[idx-1])
            if o.join:
                out.extend(vals)
            elif step==1 and start>=1 and end<=total:
                seg=''
                for pos,idx in enumerate(range(start,end+1)):
                    if pos: seg += delims[idx-2] if idx-2 < len(delims) else o.delim
                    seg += parts[idx-1]
                out.append(seg)
            else:
                out.append(''.join(vals))
    if o.json: return json.dumps(json_fields, ensure_ascii=False, separators=(',',':'))
    if o.join:
        jd = o.replace if o.replace is not None else o.delim
        return jd.join(out)
    return ''.join(out)

def parse_bounds(bounds):
    return [parse_piece(p) for p in split_commas(bounds) if p!='']

def apply_format(parts, bounds, o):
    s=bounds; res=''; i=0
    while i<len(s):
        if s.startswith('{{',i): res+='{'; i+=2
        elif s.startswith('}}',i): res+='}'; i+=2
        elif s[i]=='{':
            j=s.find('}',i+1)
            if j<0: res+=s[i]; i+=1; continue
            key=s[i+1:j]
            try:
                tmp=collect(parts, ['']*(len(parts)-1), key, o)
            except Exception:
                raise
            res+=tmp; i=j+1
        else:
            res+=s[i]; i+=1
    return res

def process_records(text,o):
    sep='\0' if o.zero else '\n'
    had_final=text.endswith(sep)
    records=text.split(sep)
    if had_final: records=records[:-1]
    outs=[]
    try:
        for rec in records:
            if rec == '':
                outs.append('')
                continue
            parts,delims=split_fields(rec,o)
            if o.only_delimited and len(parts)<2: continue
            if is_format(o.bounds) and o.mode=='fields' and not o.json:
                outs.append(apply_format(parts,o.bounds,o))
            else:
                outs.append(collect(parts,delims,o.bounds,o))
    except IndexError:
        return None,1
    return sep.join(outs) + (sep if outs or had_final else ''),0

def process_sequence(text,o, units):
    arr = list(text) if units!='bytes' else list(text.encode())
    # Drop one trailing line delimiter for byte/char mode, mirroring line-wise use.
    if arr and ((units!='bytes' and arr[-1]=='\n') or (units=='bytes' and arr[-1]==10)):
        arr=arr[:-1]; trail='\n'
    else: trail=''
    parts=[chr(x) for x in arr] if units=='bytes' else arr
    try: out=collect(parts, ['']*(max(0,len(parts)-1)), o.bounds, o)
    except IndexError: return None,1
    if units=='bytes':
        return out.encode('latin1'),0
    return out + ("\n" if units=='chars' and text != '' else ''),0

def main():
    o=parse(sys.argv[1:])
    if o.file:
        with open(o.file,'rb') as f: data=f.read()
    else:
        data=sys.stdin.buffer.read()
    if o.mode=='bytes':
        text=data.decode('latin1')
        out,rc=process_sequence(text,o,'bytes')
        if out is not None: sys.stdout.buffer.write(out)
        sys.exit(rc)
    text=data.decode('utf-8',errors='surrogateescape')
    if o.mode=='chars': out,rc=process_sequence(text,o,'chars')
    elif o.mode=='lines':
        m = re.search(r'(^|,)(-?\d+):-\d+', o.bounds)
        if m:
            sys.stderr.write(f"Error: Out of bounds: {m.group(2)}\n")
            sys.exit(1)
        lo=Opt(); lo.__dict__.update(o.__dict__); lo.delim='\n'; lo.regex=None; lo.mode='fields'; lo.join=True if o.join is None else o.join
        parts=text.split('\n')
        if parts and parts[-1]=='': parts=parts[:-1]
        try: out=collect(parts, ['\n']*(max(0,len(parts)-1)), o.bounds, lo) + ('\n' if parts else '')
        except IndexError: out=None; rc=1
        else: rc=0
    else: out,rc=process_records(text,o)
    if out is not None: sys.stdout.write(out)
    sys.exit(rc)
if __name__=='__main__': main()
