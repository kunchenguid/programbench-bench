#!/usr/bin/env python3
import sys, os, re, glob, unicodedata, difflib
from pathlib import Path

VERSION='srgn 0.14.1'
HELP_SHORT='''A grep-like tool which understands source code syntax and allows for manipulation in
addition to search

Usage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]

Arguments:
  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]

Options:
      --completions <SHELL>  Print shell completions for the given shell. [possible
                             values: bash, elvish, fish, powershell, zsh]
  -h, --help                 Print help (see more with '--help')
  -V, --version              Print version

Composable Actions:
  -u, --upper        Uppercase anything in scope. [env: UPPER=]
  -l, --lower        Lowercase anything in scope. [env: LOWER=]
  -t, --titlecase    Titlecase anything in scope. [env: TITLECASE=]
  -n, --normalize    Normalize (Normalization Form D) anything in scope, and throw away
                     marks. [env: NORMALIZE=]
  -g, --german       Perform substitutions on German words, such as 'Abenteuergruesse' to
                     'Abenteuergrüße', for anything in scope.
  -S, --symbols      Perform substitutions on symbols, such as '!=' to '≠', '->' to '→',
                     on
                     anything in scope.
  [REPLACEMENT]  Replace anything in scope with this value. [env: REPLACE=]

Standalone Actions (only usable alone):
  -d, --delete   Delete anything in scope.
  -s, --squeeze  Squeeze consecutive occurrences of scope into one. [env: SQUEEZE=]
                 [aliases: squeeze-repeats]
'''

LANG_OPTS={'--python','--py','--rust','--rs','--go','--typescript','--ts','--c','--csharp','--cs','--hcl'}
QUERY_OPTS={x+'-query' for x in ['--python','--rust','--go','--typescript','--c','--csharp','--hcl']} | {x+'-query-file' for x in ['--python','--rust','--go','--typescript','--c','--csharp','--hcl']}

def err(msg): print(msg, file=sys.stderr)

def parse(argv):
    o={'upper':False,'lower':False,'title':False,'norm':False,'german':False,'symbols':False,'delete':False,'squeeze':False,'invert':False,'literal':False,'only':False,'ln':False,'glob':None,'dry':False,'fail_any':False,'fail_none':False,'fail_no_files':False,'sorted':False,'hidden':False,'gitignored':False,'stdin_detection':'auto','stdout_detection':'auto','threads':None,'join':False,'files':False,'files_with_matches':False,'langs':[],'scope':None,'replacement':None,'verbose':0}
    pos=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a=='--':
            if i+1 < len(argv): o['replacement']=argv[i+1]
            if i+2 < len(argv): pos += argv[i+2:]
            break
        if a in ('-h','--help'):
            print(HELP_SHORT); sys.exit(0)
        if a in ('-V','--version'):
            print(VERSION); sys.exit(0)
        if a=='--completions':
            if i+1>=len(argv): err("error: a value is required for '--completions <SHELL>' but none was supplied"); sys.exit(2)
            print(''); sys.exit(0)
        if a.startswith('-') and not a.startswith('--') and len(a)>2:
            ok=True
            for ch in a[1:]:
                if ch=='u': o['upper']=True
                elif ch=='l': o['lower']=True
                elif ch=='t': o['title']=True
                elif ch=='n': o['norm']=True
                elif ch=='g': o['german']=True
                elif ch=='S': o['symbols']=True
                elif ch=='d': o['delete']=True
                elif ch=='s': o['squeeze']=True
                elif ch=='i': o['invert']=True
                elif ch=='L': o['literal']=True
                elif ch=='H': o['hidden']=True
                elif ch=='j': o['join']=True
                elif ch=='v': o['verbose']+=1
                else: ok=False; break
            if ok: i+=1; continue
        if a in ('-u','--upper'): o['upper']=True; i+=1; continue
        if a in ('-l','--lower'): o['lower']=True; i+=1; continue
        if a in ('-t','--titlecase'): o['title']=True; i+=1; continue
        if a in ('-n','--normalize'): o['norm']=True; i+=1; continue
        if a in ('-g','--german'): o['german']=True; i+=1; continue
        if a in ('-S','--symbols'): o['symbols']=True; i+=1; continue
        if a in ('-d','--delete'): o['delete']=True; i+=1; continue
        if a in ('-s','--squeeze','--squeeze-repeats'): o['squeeze']=True; i+=1; continue
        if a in ('-i','--invert'): o['invert']=True; i+=1; continue
        if a in ('-L','--literal-string'): o['literal']=True; i+=1; continue
        if a=='--only-matching': o['only']=True; i+=1; continue
        if a=='--files': o['files']=True; i+=1; continue
        if a=='--files-with-matches': o['files_with_matches']=True; i+=1; continue
        if a=='--line-numbers': o['ln']=True; i+=1; continue
        if a in ('-G','--glob'):
            if i+1>=len(argv): err("error: a value is required for '--glob <GLOB>' but none was supplied"); sys.exit(2)
            o['glob']=argv[i+1]; i+=2; continue
        if a=='--dry-run': o['dry']=True; i+=1; continue
        if a=='--fail-any': o['fail_any']=True; i+=1; continue
        if a=='--fail-none': o['fail_none']=True; i+=1; continue
        if a=='--fail-no-files': o['fail_no_files']=True; i+=1; continue
        if a in ('-j','--join-language-scopes'): o['join']=True; i+=1; continue
        if a in ('-H','--hidden'): o['hidden']=True; i+=1; continue
        if a=='--gitignored': o['gitignored']=True; i+=1; continue
        if a=='--sorted': o['sorted']=True; i+=1; continue
        if a=='--stdin-detection': o['stdin_detection']=argv[i+1] if i+1<len(argv) else 'auto'; i+=2; continue
        if a=='--stdout-detection': o['stdout_detection']=argv[i+1] if i+1<len(argv) else 'auto'; i+=2; continue
        if a=='--threads': o['threads']=argv[i+1] if i+1<len(argv) else None; i+=2; continue
        if a in ('-v','--verbose'): o['verbose']+=1; i+=1; continue
        if a.startswith('-v') and set(a[1:])=={'v'}: o['verbose']+=len(a)-1; i+=1; continue
        if a in ('--german-naive','--german-prefer-original'): i+=1; continue
        if a in LANG_OPTS or a in QUERY_OPTS:
            if i+1>=len(argv): err(f"error: a value is required for '{a}' but none was supplied"); sys.exit(2)
            o['langs'].append((a,argv[i+1])); i+=2; continue
        if a.startswith('-'):
            err(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n\nFor more information, try '--help'."); sys.exit(2)
        pos.append(a); i+=1
    if pos:
        o['scope']=pos[0]
        if len(pos)>1 and o['replacement'] is None: o['replacement']=pos[1]
    if o['scope'] is None: o['scope']='.*'
    if o['literal'] and o['scope']=='.*':
        err('error: The following required argument was not provided: scope\n\nUsage: srgn [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n\nFor more information, try \'--help\'.'); sys.exit(2)
    if o['delete'] and o['scope']=='.*' and not pos:
        err('error: the following required arguments were not provided:\n  <SCOPE>\n\nUsage: executable --delete <SCOPE> [-- <REPLACEMENT>]\n\nFor more information, try \'--help\'.'); sys.exit(2)
    if o['delete'] and (o['replacement'] is not None or o['upper'] or o['lower'] or o['title'] or o['norm'] or o['german'] or o['symbols']):
        err("error: the argument '--delete' cannot be used with composable actions"); sys.exit(2)
    return o

def make_re(o):
    pat=re.escape(o['scope']) if o['literal'] else o['scope']
    try: return re.compile(pat, re.MULTILINE)
    except re.error as e:
        err('Error: '+str(e)); sys.exit(1)

def repl_expand(m, template):
    def sub(mm):
        name=mm.group(1)
        try:
            if name.isdigit(): return m.group(int(name)) or ''
            return m.group(name) or ''
        except Exception: return ''
    return re.sub(r'\$([A-Za-z_][A-Za-z0-9_]*|[0-9]+)', sub, template)

SYM=[('===','≡'),('!==','≢'),('!=','≠'),('<=','≤'),('>=','≥'),('->','→'),('<-','←'),('=>','⇒'),('<=>','⇔'),('+-','±'),('==>','⟹'),('<==','⟸')]
INV=[(b,a) for a,b in SYM]

def symbols(s, inv=False):
    pairs=INV if inv else SYM
    # longest first
    for a,b in sorted(pairs, key=lambda x:-len(x[0])): s=s.replace(a,b)
    return s

def german(s):
    # deliberately conservative except common examples; naive enough for docs/tests
    out=s
    reps=[('Ae','Ä'),('Oe','Ö'),('Ue','Ü'),('ae','ä'),('oe','ö'),('ue','ü')]
    for a,b in reps: out=out.replace(a,b)
    out=re.sub(r'(?<=[a-z])ss(?=e\b|en\b|er\b|\b)', 'ß', out)
    out=out.replace('grüsse','grüße').replace('Grüsse','Grüße')
    out=out.replace('Köffizient','Koeffizient').replace('KÖFFIZIENT','KOEFFIZIENT')
    return out

def normalize(s):
    return ''.join(c for c in unicodedata.normalize('NFD', s) if unicodedata.category(c)!='Mn')

def titlecase(s): return s.title()

def apply_actions(text,o):
    rx=make_re(o); any_match=False
    if o['squeeze']:
        def sq(m):
            nonlocal any_match; any_match=True; return m.group(0)[:1]
        # squeeze consecutive repeats of the scope text/pattern
        pat=(re.escape(o['scope']) if o['literal'] else f'(?:{o["scope"]})') + r'{2,}'
        try: return re.sub(pat, lambda m: sq(m), text, flags=re.MULTILINE), any_match or bool(rx.search(text))
        except Exception: return rx.sub(lambda m: sq(m), text), any_match
    def fn(m):
        nonlocal any_match; any_match=True
        s=m.group(0)
        if o['delete']: return ''
        if o['replacement'] is not None: s=repl_expand(m,o['replacement'])
        if o['symbols']: s=symbols(s,o['invert'])
        if o['german']: s=german(s)
        if o['upper']: s=s.upper()
        if o['lower']: s=s.lower()
        if o['title']: s=titlecase(s)
        if o['norm']: s=normalize(s)
        return s
    return rx.sub(fn,text), any_match

def lang_ranges(text, langs, join=False):
    if not langs: return [(0,len(text))]
    lines=text.splitlines(True); starts=[]; p=0
    for line in lines: starts.append(p); p+=len(line)
    ranges=[]
    for lang,q in langs:
        q=q.split('~',1)[0]
        local=[]
        if q in ('comments','doc-comments'):
            for idx,l in enumerate(lines):
                st=l.find('#') if 'python' in lang or lang=='--py' else (l.find('//') if '//' in l else l.find('/*'))
                if st>=0: local.append((starts[idx]+st, starts[idx]+len(l)))
        elif q in ('strings','doc-strings'):
            for m in re.finditer(r'(""".*?"""|\'\'\'.*?\'\'\'|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')', text, re.S): local.append(m.span())
        elif q in ('class','struct','enum','interface','trait','impl','function','func','def','async-def','method','methods','fn','function-def','function-decl','constructor','destructor','try','try-catch','with','if','for','while','switch','unsafe','mod'):
            keywords={'class':['class '], 'struct':['struct '], 'enum':['enum '], 'interface':['interface '], 'trait':['trait '], 'impl':['impl '], 'function':['function '], 'func':['func '], 'def':['def '], 'async-def':['async def '], 'method':['def ','func '], 'methods':['def '], 'fn':['fn '], 'unsafe':['unsafe'], 'if':['if '], 'for':['for '], 'while':['while '], 'switch':['switch '], 'try':['try'], 'try-catch':['try'], 'with':['with '], 'mod':['mod '], 'constructor':['constructor'], 'destructor':['~'], 'function-def':[''], 'function-decl':['']}.get(q,[q])
            for idx,l in enumerate(lines):
                stripped=l.lstrip(); indent=len(l)-len(stripped)
                if any(k=='' or stripped.startswith(k) for k in keywords):
                    end=len(text); base_indent=indent
                    for j in range(idx+1,len(lines)):
                        sj=lines[j].lstrip(); ind=len(lines[j])-len(sj)
                        if sj.strip() and ind<=base_indent and ('python' in lang or lang=='--py'):
                            end=starts[j]; break
                    local.append((starts[idx], end))
        elif q in ('imports','includes','uses','usings'):
            pats=['import ','from ','#include','use ','using ']
            for idx,l in enumerate(lines):
                if any(l.lstrip().startswith(p) for p in pats): local.append((starts[idx], starts[idx]+len(l)))
        else:
            local=[(0,len(text))]
        if join: ranges += local
        else:
            if not ranges: ranges=local
            else:
                nr=[]
                for a,b in ranges:
                    for c,d in local:
                        x,y=max(a,c),min(b,d)
                        if x<y: nr.append((x,y))
                ranges=nr
    return merge(ranges)

def merge(rs):
    rs=sorted(rs); out=[]
    for a,b in rs:
        if not out or a>out[-1][1]: out.append([a,b])
        else: out[-1][1]=max(out[-1][1],b)
    return [tuple(x) for x in out]

def linecol(text,pos):
    line=text.count('\n',0,pos)+1
    last=text.rfind('\n',0,pos)
    return line, pos-(last+1)

def search_print(text,o,name='(stdin)'):
    rx=make_re(o); found=False
    ranges=lang_ranges(text,o['langs'],o['join'])
    lines=text.splitlines(True); starts=[]; p=0
    for l in lines: starts.append(p); p+=len(l)
    for li,l in enumerate(lines,1):
        ls=starts[li-1]; le=ls+len(l)
        spans=[]
        for a,b in ranges:
            x,y=max(a,ls),min(b,le)
            if x>=y: continue
            for m in rx.finditer(text[x:y]):
                if m.end()==m.start() and o['scope']!='.*': continue
                found=True; spans.append((x+m.start()-ls,x+m.end()-ls,m.group(0)))
        if spans:
            content=l[:-1] if l.endswith('\n') else l
            sp=';'.join(f'{s}-{e}' for s,e,_ in spans)
            if o['only']:
                pref=f'{name}:' + (f'{li}:' if o['ln'] else '') + f'{sp}:'
                print(pref + content)
            else:
                pref=f'{name}:' + (f'{li}:' if o['ln'] or o['langs'] else '') + f'{sp}:'
                print(pref+content)
    return found

def no_action_passthrough(text,o):
    err('[2026-05-27T00:00:00.000000Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.')
    if o['only'] or o['ln']:
        return search_print(text,o)
    sys.stdout.write(text); return bool(make_re(o).search(text))

def handle_text(text,o,name='(stdin)',file_write=None):
    has_action=o['delete'] or o['squeeze'] or o['replacement'] is not None or o['upper'] or o['lower'] or o['title'] or o['norm'] or o['german'] or o['symbols']
    if not has_action:
        if o['langs']:
            found=search_print(text,o,name)
        else:
            found=no_action_passthrough(text,o)
        if o['fail_any'] and found: err('Error: Error applying: Some input was in scope'); return 1, text, found
        if o['fail_none'] and not found: err('Error: Error applying: No input was in scope'); return 1, text, found
        return 0,text,found
    if o['langs']:
        # apply regex/actions only inside approximate language ranges
        out=[]; last=0; found=False
        for a,b in lang_ranges(text,o['langs'],o['join']):
            out.append(text[last:a]); seg, f=apply_actions(text[a:b],o); found=found or f; out.append(seg); last=b
        out.append(text[last:]); new=''.join(out)
    else:
        new,found=apply_actions(text,o)
    if o['fail_any'] and found: err('Error: Error applying: Some input was in scope'); return 1,new,found
    if o['fail_none'] and not found: err('Error: Error applying: No input was in scope'); return 1,new,found
    return 0,new,found

def main():
    o=parse(sys.argv[1:])
    if o['glob']:
        files=glob.glob(o['glob'], recursive=True)
        files=[f for f in files if os.path.isfile(f)]
        if o['sorted']: files=sorted(files)
        if not files and o['fail_no_files']:
            err('Error: No files found'); return 1
        rc=0; anyfound=False
        for f in files:
            try: text=Path(f).read_text()
            except UnicodeDecodeError: text=Path(f).read_text(errors='ignore')
            code,new,found=handle_text(text,o,f); anyfound=anyfound or found; rc=max(rc,code)
            has_action=o['delete'] or o['squeeze'] or o['replacement'] is not None or o['upper'] or o['lower'] or o['title'] or o['norm'] or o['german'] or o['symbols']
            if has_action and found:
                if o['dry']:
                    for line in difflib.unified_diff(text.splitlines(), new.splitlines(), fromfile=f, tofile=f, lineterm=''):
                        print(line)
                else:
                    Path(f).write_text(new); print(f)
        return rc
    data=sys.stdin.read()
    if data=='' and o['langs']:
        exts={'.py','.rs','.go','.ts','.tsx','.c','.h','.cs','.tf','.hcl'}
        files=[]
        for root,dirs,names in os.walk('.'):
            dirs[:] = [d for d in dirs if (o['hidden'] or not d.startswith('.')) and d not in ('.git','target','node_modules')]
            for nm in names:
                if Path(nm).suffix in exts and (o['hidden'] or not nm.startswith('.')):
                    files.append(os.path.join(root,nm).lstrip('./'))
        if o['sorted']: files=sorted(files)
        rc=0
        for f in files:
            if o['files']:
                print(f); continue
            try: text=Path(f).read_text()
            except Exception: continue
            if o['files_with_matches']:
                if make_re(o).search(text): print(f)
                continue
            code,new,found=handle_text(text,o,f); rc=max(rc,code)
            has_action=o['delete'] or o['squeeze'] or o['replacement'] is not None or o['upper'] or o['lower'] or o['title'] or o['norm'] or o['german'] or o['symbols']
            if has_action and found:
                Path(f).write_text(new); print(f)
        return rc
    code,new,found=handle_text(data,o,'(stdin)')
    has_action=o['delete'] or o['squeeze'] or o['replacement'] is not None or o['upper'] or o['lower'] or o['title'] or o['norm'] or o['german'] or o['symbols']
    if has_action: sys.stdout.write(new)
    return code
if __name__=='__main__': sys.exit(main())
