import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.geom.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.util.regex.*;

public class DitaaLite {
    static final String USAGE =
"usage: java -jar ditaa.jar <INPFILE> [OUTFILE] [-A] [-b <BACKGROUND>] [-d]\n"+
"       [-E] [-e <ENCODING>] [-h] [--help] [-o] [-r] [-S] [-s <SCALE>]\n"+
"       [--svg] [--svg-font-url <FONT>] [-T] [-t <TABS>] [-v] [-W]\n"+
" -A,--no-antialias              Turns anti-aliasing off.\n"+
" -b,--background <BACKGROUND>   The background colour of the image. The\n"+
"                                format should be a six-digit hexadecimal\n"+
"                                number (as in HTML, FF0000 for red). Pass\n"+
"                                an eight-digit hex to define transparency.\n"+
"                                This is overridden by --transparent.\n"+
" -d,--debug                     Renders the debug grid over the resulting\n"+
"                                image.\n"+
" -E,--no-separation             Prevents the separation of common edges of\n"+
"                                shapes.\n"+
" -e,--encoding <ENCODING>       The encoding of the input file.\n"+
" -h,--html                      In this case the input is an HTML file.\n"+
"                                The contents of the <pre\n"+
"                                class=\"textdiagram\"> tags are rendered as\n"+
"                                diagrams and saved in the images directory\n"+
"                                and a new HTML file is produced with the\n"+
"                                appropriate <img> tags.\n"+
"    --help                      Prints usage help.\n"+
" -o,--overwrite                 If the filename of the destination image\n"+
"                                already exists, an alternative name is\n"+
"                                chosen. If the overwrite option is\n"+
"                                selected, the image file is instead\n"+
"                                overwriten.\n"+
" -r,--round-corners             Causes all corners to be rendered as round\n"+
"                                corners.\n"+
" -S,--no-shadows                Turns off the drop-shadow effect.\n"+
" -s,--scale <SCALE>             A natural number that determines the size\n"+
"                                of the rendered image. The units are\n"+
"                                fractions of the default size (2.5 renders\n"+
"                                1.5 times bigger than the default).\n"+
"    --svg                       Write an SVG image as destination file.\n"+
"    --svg-font-url <FONT>       SVG font URL.\n"+
" -T,--transparent               Causes the diagram to be rendered on a\n"+
"                                transparent background. Overrides\n"+
"                                --background.\n"+
" -t,--tabs <TABS>               Tabs are normally interpreted as 8 spaces\n"+
"                                but it is possible to change that using\n"+
"                                this option. It is not advisable to use\n"+
"                                tabs in your diagrams.\n"+
" -v,--verbose                   Makes ditaa more verbose.\n"+
" -W,--fixed-slope               Makes sides of parallelograms and\n"+
"                                trapezoids fixed slope instead of fixed\n"+
"                                width.";

    static class Opt {
        boolean html, svg, overwrite, verbose, debug, round, transparent, shadows=true, antialias=true;
        String background = "FFFFFF", encoding = "UTF-8", svgFontUrl = null;
        double scale = 1.0;
        int tabs = 8;
        List<String> files = new ArrayList<>();
    }

    public static void main(String[] args) {
        try {
            Opt o = parse(args);
            if (o == null) return;
            if (o.files.isEmpty()) { System.out.println(USAGE); return; }
            banner(o);
            Path in = Paths.get(o.files.get(0));
            if (o.html) htmlMode(o, in, o.files.size() > 1 ? Paths.get(o.files.get(1)) : defaultOut(in, false, o));
            else {
                Path out = o.files.size() > 1 ? Paths.get(o.files.get(1)) : defaultOut(in, o.svg, o);
                out = chooseName(out, o.overwrite);
                System.out.println("Reading file: " + o.files.get(0));
                if (!Files.exists(in)) { System.out.println("Error: File " + o.files.get(0) + " does not exist"); System.exit(1); }
                System.out.println("Rendering to file: " + out);
                String text = readText(in, o);
                if (o.svg) writeSvg(text, out, o); else writePng(text, out, o);
                System.out.println("Done in 0sec");
            }
        } catch (BadArgs b) {
            System.out.println((b.raw ? "" : "Error: ") + b.getMessage());
            if (b.showUsage) System.out.println(USAGE);
            System.exit(2);
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    static class BadArgs extends Exception {
        boolean showUsage;
        boolean raw;
        BadArgs(String m, boolean u) { this(m, u, false); }
        BadArgs(String m, boolean u, boolean r) { super(m); showUsage = u; raw = r; }
    }

    static Opt parse(String[] args) throws BadArgs {
        Opt o = new Opt();
        for (int i=0;i<args.length;i++) {
            String a = args[i];
            switch (a) {
                case "--help": System.out.println(USAGE); return null;
                case "-h": case "--html": o.html = true; break;
                case "--svg": o.svg = true; break;
                case "-o": case "--overwrite": o.overwrite = true; break;
                case "-v": case "--verbose": o.verbose = true; break;
                case "-d": case "--debug": o.debug = true; break;
                case "-r": case "--round-corners": o.round = true; break;
                case "-S": case "--no-shadows": o.shadows = false; break;
                case "-A": case "--no-antialias": o.antialias = false; break;
                case "-E": case "--no-separation": break;
                case "-W": case "--fixed-slope": break;
                case "-T": case "--transparent": o.transparent = true; break;
                case "-b": case "--background":
                    o.background = need(args, ++i, a);
                    if (!o.background.matches("[0-9a-fA-F]{6}([0-9a-fA-F]{2})?"))
                        throw new BadArgs("Cannot interpret \""+o.background+"\" as background colour. It needs to be a 6- or 8-digit hex number, depending on whether you have transparency or not (same as HTML).", true);
                    break;
                case "-e": case "--encoding":
                    o.encoding = need(args, ++i, a);
                    if (!Charset.isSupported(o.encoding)) throw new BadArgs(o.encoding, false);
                    break;
                case "-s": case "--scale":
                    String s = need(args, ++i, a);
                    try { o.scale = Double.parseDouble(s); } catch (NumberFormatException n) { throw new BadArgs("For input string: \""+s+"\"", true); }
                    break;
                case "-t": case "--tabs":
                    String t = need(args, ++i, a);
                    try { o.tabs = Integer.parseInt(t); } catch (NumberFormatException n) { throw new BadArgs("For input string: \""+t+"\"", true); }
                    break;
                case "--svg-font-url": o.svgFontUrl = need(args, ++i, a); break;
                default:
                    if (a.startsWith("-")) throw new BadArgs("Unrecognized option: " + a, true, true);
                    o.files.add(a);
            }
        }
        return o;
    }

    static String need(String[] a, int i, String opt) throws BadArgs {
        if (i >= a.length) throw new BadArgs("Missing argument for option: " + opt, true);
        return a[i];
    }

    static void banner(Opt o) {
        System.out.println();
        System.out.println("ditaa version 0.11, Copyright (C) 2004--2017  Efstathios (Stathis) Sideris");
        System.out.println();
        System.out.println("Running with options:");
        if (o.verbose) System.out.println("verbose");
        if (o.html) System.out.println("html");
        if (o.svg) System.out.println("svg");
        if (o.overwrite) System.out.println("overwrite");
        if (o.transparent) System.out.println("transparent");
        if (!"FFFFFF".equals(o.background)) System.out.println("background = " + o.background);
        if (o.scale != 1.0) System.out.println("scale = " + fmt(o.scale));
        if (o.tabs != 8) System.out.println("tabs = " + o.tabs);
    }

    static String fmt(double d) { return d == Math.rint(d) ? Long.toString((long)d) : Double.toString(d); }

    static Path defaultOut(Path in, boolean svg, Opt o) {
        String n = in.getFileName().toString();
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        n += svg ? ".svg" : ".png";
        Path p = in.getParent();
        return p == null ? Paths.get(n) : p.resolve(n);
    }

    static Path chooseName(Path p, boolean overwrite) {
        if (overwrite || !Files.exists(p)) return p;
        String name = p.getFileName().toString(), base = name, ext = "";
        int dot = name.lastIndexOf('.');
        if (dot > 0) { base = name.substring(0, dot); ext = name.substring(dot); }
        Path dir = p.getParent();
        for (int i=2;;i++) {
            Path q = (dir == null ? Paths.get(base+"_"+i+ext) : dir.resolve(base+"_"+i+ext));
            if (!Files.exists(q)) return q;
        }
    }

    static String readText(Path p, Opt o) throws IOException {
        String raw = Files.readString(p, Charset.forName(o.encoding));
        String spaces = " ".repeat(Math.max(0, o.tabs));
        return raw.replace("\t", spaces);
    }

    static String[] lines(String text) {
        String[] a = text.replace("\r\n","\n").replace('\r','\n').split("\n", -1);
        int n = a.length;
        while (n > 1 && a[n-1].isEmpty()) n--;
        return Arrays.copyOf(a, n);
    }

    static int cols(String[] ls) { int m=0; for (String s:ls) m=Math.max(m, s.length()); return m; }

    static Color bgColor(Opt o) {
        if (o.transparent) return new Color(255,255,255,0);
        String h = o.background;
        int r=Integer.parseInt(h.substring(0,2),16), g=Integer.parseInt(h.substring(2,4),16), b=Integer.parseInt(h.substring(4,6),16);
        int a=h.length()==8?Integer.parseInt(h.substring(6,8),16):255;
        return new Color(r,g,b,a);
    }

    static Color codeColor(String code) {
        switch (code) {
            case "RED": return new Color(255,160,160);
            case "GRE": return new Color(170,220,170);
            case "BLU": return new Color(170,190,245);
            case "PNK": return new Color(245,180,220);
            case "YEL": return new Color(255,240,150);
            case "BLK": return new Color(60,60,60);
            default: return new Color(245,245,245);
        }
    }

    static void writePng(String text, Path out, Opt o) throws IOException {
        String[] ls = lines(text);
        int cw=10, ch=14, mx=20, my=28;
        int w = Math.max(1, (int)Math.round((cols(ls)*cw + 40) * o.scale));
        int h = Math.max(1, (int)Math.round((ls.length*ch + 56) * o.scale));
        BufferedImage img = new BufferedImage(w,h,BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        if (o.antialias) g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setColor(bgColor(o)); g.fillRect(0,0,w,h);
        g.scale(o.scale, o.scale);
        renderDiagram(g, ls, cw, ch, mx, my, o);
        g.dispose();
        ImageIO.write(img, "png", out.toFile());
    }

    static void renderDiagram(Graphics2D g, String[] ls, int cw, int ch, int mx, int my, Opt o) {
        g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        fillRectangles(g, ls, cw, ch, mx, my, o);
        g.setColor(new Color(50,50,50));
        for (int y=0;y<ls.length;y++) {
            String s=ls[y];
            for (int x=0;x<s.length();x++) {
                char c=s.charAt(x);
                int cx=mx+x*cw+cw/2, cy=my+y*ch+ch/2;
                if (c=='-' || c=='=') line(g,cx-cw/2,cy,cx+cw/2,cy,c=='=');
                else if (c=='|' || c==':') line(g,cx,cy-ch/2,cx,cy+ch/2,c==':');
                else if (c=='+') { line(g,cx-cw/2,cy,cx+cw/2,cy,false); line(g,cx,cy-ch/2,cx,cy+ch/2,false); }
                else if (c=='/') g.draw(new Line2D.Double(cx+cw/2,cy-ch/2,cx-cw/2,cy+ch/2));
                else if (c=='\\') g.draw(new Line2D.Double(cx-cw/2,cy-ch/2,cx+cw/2,cy+ch/2));
                else if (c=='*') { g.fill(new Ellipse2D.Double(cx-3,cy-3,6,6)); }
                else if (c=='>' || c=='<' || c=='^' || c=='v') drawArrow(g,c,cx,cy,cw,ch);
            }
        }
        if (o.debug) {
            g.setColor(new Color(200,200,255,120)); g.setStroke(new BasicStroke(1));
            for (int x=0;x<=cols(ls);x++) g.drawLine(mx+x*cw,my-ch/2,mx+x*cw,my+ls.length*ch);
            for (int y=0;y<=ls.length;y++) g.drawLine(mx-cw/2,my+y*ch,mx+cols(ls)*cw,my+y*ch);
        }
        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g.setColor(Color.BLACK);
        for (int y=0;y<ls.length;y++) drawTextRuns(g, ls[y], mx, my+y*ch+10, cw);
    }

    static void line(Graphics2D g,int x1,int y1,int x2,int y2,boolean dash) {
        Stroke old = g.getStroke();
        if (dash) g.setStroke(new BasicStroke(2f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 1, new float[]{5,5}, 0));
        g.drawLine(x1,y1,x2,y2);
        if (dash) g.setStroke(old);
    }

    static void drawArrow(Graphics2D g, char c, int x, int y, int cw, int ch) {
        Polygon p = new Polygon();
        if (c=='>') { p.addPoint(x+4,y); p.addPoint(x-4,y-5); p.addPoint(x-4,y+5); }
        if (c=='<') { p.addPoint(x-4,y); p.addPoint(x+4,y-5); p.addPoint(x+4,y+5); }
        if (c=='^') { p.addPoint(x,y-5); p.addPoint(x-5,y+4); p.addPoint(x+5,y+4); }
        if (c=='v') { p.addPoint(x,y+5); p.addPoint(x-5,y-4); p.addPoint(x+5,y-4); }
        g.fillPolygon(p);
    }

    static void fillRectangles(Graphics2D g, String[] ls, int cw, int ch, int mx, int my, Opt o) {
        int rows=ls.length;
        for (int y=0;y<rows;y++) for (int x=0;x<ls[y].length();x++) if (charAt(ls,x,y)=='+') {
            for (int x2=x+2;x2<ls[y].length();x2++) if (charAt(ls,x2,y)=='+') {
                if (!allH(ls[y],x+1,x2)) continue;
                for (int y2=y+2;y2<rows;y2++) if (charAt(ls,x,y2)=='+' && charAt(ls,x2,y2)=='+') {
                    if (allH(ls[y2],x+1,x2) && allV(ls,x,y+1,y2) && allV(ls,x2,y+1,y2)) {
                        String inside = collect(ls,x+1,y+1,x2,y2);
                        Matcher m = Pattern.compile("c([A-Z]{3})").matcher(inside);
                        Color fill = m.find()?codeColor(m.group(1)):new Color(250,250,250);
                        g.setColor(fill);
                        int rx=mx+x*cw+cw/2, ry=my+y*ch+ch/2, rw=(x2-x)*cw, rh=(y2-y)*ch;
                        if (o.shadows) { g.setColor(new Color(0,0,0,35)); g.fillRoundRect(rx+5,ry+5,rw,rh,o.round?14:3,o.round?14:3); g.setColor(fill); }
                        if (o.round) g.fillRoundRect(rx,ry,rw,rh,14,14); else g.fillRect(rx,ry,rw,rh);
                        return;
                    }
                }
            }
        }
    }

    static boolean allH(String s,int a,int b){ for(int i=a;i<b;i++){ char c=s.charAt(i); if(c!='-'&&c!='=') return false;} return true; }
    static boolean allV(String[] ls,int x,int a,int b){ for(int i=a;i<b;i++){ char c=charAt(ls,x,i); if(c!='|'&&c!=':') return false;} return true; }
    static char charAt(String[] ls,int x,int y){ return y>=0&&y<ls.length&&x>=0&&x<ls[y].length()?ls[y].charAt(x):' '; }
    static String collect(String[] ls,int x1,int y1,int x2,int y2){ StringBuilder b=new StringBuilder(); for(int y=y1;y<y2;y++) for(int x=x1;x<x2;x++) b.append(charAt(ls,x,y)); return b.toString(); }

    static void drawTextRuns(Graphics2D g, String s, int mx, int baseline, int cw) {
        StringBuilder run = new StringBuilder(); int start=-1;
        for (int i=0;i<=s.length();i++) {
            char c = i<s.length()?s.charAt(i):'\0';
            boolean text = i<s.length() && "-=|:+/\\<>^v*".indexOf(c)<0;
            if (text) { if (start<0) start=i; run.append(c); }
            else if (start>=0) {
                String r = run.toString().replaceAll("\\{[a-z]+\\}", "").replaceAll("c[A-Z]{3}", "");
                if (r.trim().length()>0) {
                    r = r.replaceFirst("^ o ", " • ");
                    g.drawString(r, mx+start*cw, baseline);
                }
                run.setLength(0); start=-1;
            }
        }
    }

    static void writeSvg(String text, Path out, Opt o) throws IOException {
        String[] ls=lines(text); int cw=10,ch=14,mx=20,my=28;
        int w=(int)Math.round((cols(ls)*cw+40)*o.scale), h=(int)Math.round((ls.length*ch+56)*o.scale);
        StringBuilder sb=new StringBuilder();
        sb.append("<?xml version='1.0' encoding='UTF-8' standalone='no'?>\n");
        sb.append("<svg xmlns='http://www.w3.org/2000/svg' width='").append(w).append("' height='").append(h).append("' shape-rendering='geometricPrecision' version='1.0'>\n");
        if (o.svgFontUrl != null) sb.append("<defs><style>@import url('").append(esc(o.svgFontUrl)).append("');</style></defs>\n");
        Color bg=bgColor(o);
        if (!o.transparent) sb.append("<rect width='100%' height='100%' fill='").append(hex(bg)).append("' fill-opacity='").append(bg.getAlpha()/255.0).append("'/>\n");
        sb.append("<g transform='scale(").append(fmt(o.scale)).append(")' stroke='#333' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' fill='none'>\n");
        for(int y=0;y<ls.length;y++) for(int x=0;x<ls[y].length();x++){ char c=ls[y].charAt(x); int cx=mx+x*cw+cw/2, cy=my+y*ch+ch/2;
            if(c=='-'||c=='=') sb.append("<line x1='"+(cx-cw/2)+"' y1='"+cy+"' x2='"+(cx+cw/2)+"' y2='"+cy+"'"+(c=='='?" stroke-dasharray='5,5'":"")+"/>\n");
            else if(c=='|'||c==':') sb.append("<line x1='"+cx+"' y1='"+(cy-ch/2)+"' x2='"+cx+"' y2='"+(cy+ch/2)+"'"+(c==':'?" stroke-dasharray='5,5'":"")+"/>\n");
            else if(c=='+') sb.append("<path d='M"+(cx-cw/2)+" "+cy+" L"+(cx+cw/2)+" "+cy+" M"+cx+" "+(cy-ch/2)+" L"+cx+" "+(cy+ch/2)+"'/>\n");
            else if(c=='/') sb.append("<line x1='"+(cx+cw/2)+"' y1='"+(cy-ch/2)+"' x2='"+(cx-cw/2)+"' y2='"+(cy+ch/2)+"'/>\n");
            else if(c=='\\') sb.append("<line x1='"+(cx-cw/2)+"' y1='"+(cy-ch/2)+"' x2='"+(cx+cw/2)+"' y2='"+(cy+ch/2)+"'/>\n");
        }
        sb.append("</g><g transform='scale(").append(fmt(o.scale)).append(")' font-family='Sans-Serif' font-size='12' fill='black' stroke='none'>\n");
        for(int y=0;y<ls.length;y++) svgText(sb, ls[y], mx, my+y*ch+10, cw);
        sb.append("</g>\n</svg>\n");
        Files.writeString(out,sb.toString());
    }

    static void svgText(StringBuilder sb,String s,int mx,int baseline,int cw){
        StringBuilder run=new StringBuilder(); int start=-1;
        for(int i=0;i<=s.length();i++){ char c=i<s.length()?s.charAt(i):0; boolean text=i<s.length()&&"-=|:+/\\<>^v*".indexOf(c)<0;
            if(text){ if(start<0)start=i; run.append(c); } else if(start>=0){ String r=run.toString().replaceAll("\\{[a-z]+\\}","").replaceAll("c[A-Z]{3}","");
                if(r.trim().length()>0) sb.append("<text x='").append(mx+start*cw).append("' y='").append(baseline).append("'>").append(esc(r.replaceFirst("^ o "," • "))).append("</text>\n");
                run.setLength(0); start=-1; }}
    }

    static String esc(String s){ return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("'","&apos;"); }
    static String hex(Color c){ return String.format("#%02x%02x%02x",c.getRed(),c.getGreen(),c.getBlue()); }

    static void htmlMode(Opt o, Path in, Path out) throws IOException {
        System.out.print("Converting HTML file ("+in+" -> "+out+")... ");
        String html = readText(in,o);
        Pattern p = Pattern.compile("(?is)<pre\\b([^>]*)class=[\"'][^\"']*textdiagram[^\"']*[\"']([^>]*)>(.*?)</pre>");
        Matcher m = p.matcher(html);
        StringBuffer result = new StringBuffer();
        List<String[]> diagrams = new ArrayList<>();
        int idx=1;
        while(m.find()){
            String attrs=m.group(1)+" "+m.group(2), body=unhtml(m.group(3));
            Matcher idm=Pattern.compile("id=[\"']([^\"']+)[\"']",Pattern.CASE_INSENSITIVE).matcher(attrs);
            boolean hasId = idm.find();
            String name=(hasId?idm.group(1):"ditaa_diagram_"+idx)+".png";
            if (!hasId) idx++;
            diagrams.add(new String[]{name, body});
            m.appendReplacement(result, Matcher.quoteReplacement("<img src=\"images/"+name+"\" />"));
        }
        m.appendTail(result);
        Files.writeString(out,result.toString(),Charset.forName(o.encoding));
        System.out.println("done");
        System.out.println("Generating diagrams... ");
        Path imgDir = (out.getParent()==null?Paths.get("images"):out.getParent().resolve("images"));
        try { Files.createDirectories(imgDir); } catch (IOException e) { System.out.println("Could not create directory images"); return; }
        for(String[] d: diagrams){
            Path img=imgDir.resolve(d[0]);
            if(Files.exists(img)&&!o.overwrite) continue;
            writePng(trimEdgeNewline(d[1]), img, o);
        }
        System.out.println("Done in 0sec");
    }

    static String trimEdgeNewline(String s){ if(s.startsWith("\n"))s=s.substring(1); if(s.endsWith("\n"))s=s.substring(0,s.length()-1); return s; }
    static String unhtml(String s){ return s.replace("&lt;","<").replace("&gt;",">").replace("&amp;","&"); }
}
