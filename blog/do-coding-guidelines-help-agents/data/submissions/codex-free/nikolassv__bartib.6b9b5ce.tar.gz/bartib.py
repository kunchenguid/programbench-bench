#!/usr/bin/env python3
import os, sys, re, subprocess
from datetime import datetime, date, time, timedelta
from collections import defaultdict, OrderedDict

VERSION = "bartib 1.1.0"
DATE_FMT = "%Y-%m-%d"
DT_FMT = "%Y-%m-%d %H:%M"

RESET="\033[0m"; BOLD="\033[1m"; UNDER="\033[4m"; GREEN="\033[32m"; DIM="\033[2m"; IT="\033[3m"

def eprint(s=""):
    print(s, file=sys.stderr)

def die(s, code=1):
    eprint(s); sys.exit(code)

def now_dt():
    return datetime.now().replace(second=0, microsecond=0)

def fmt_dur(minutes):
    minutes = int(round(minutes))
    h, m = divmod(abs(minutes), 60)
    sign = "-" if minutes < 0 else ""
    if h and m: return f"{sign}{h}h {m:02d}m"
    if h: return f"{sign}{h}h 00m"
    return f"{sign}{m}m"

def parse_hhmm(s):
    try:
        h, m = map(int, s.split(":"))
        if not (0 <= h <= 23 and 0 <= m <= 59): raise ValueError
        n = now_dt()
        return datetime.combine(n.date(), time(h, m))
    except Exception:
        die(f'Error: "{s}" is not a valid time. Use format HH:MM')

def parse_date(s):
    try: return datetime.strptime(s, DATE_FMT).date()
    except Exception: die(f'Error: "{s}" is not a valid date. Use format YYYY-MM-DD')

def round_dt(dt, spec):
    if not spec: return dt
    m = re.fullmatch(r"(\d+)([mh])", spec)
    if not m: die(f'Error: "{spec}" is not a valid duration')
    step = int(m.group(1)) * (60 if m.group(2) == "h" else 1)
    if step <= 0: return dt
    epoch = datetime(1970,1,1)
    mins = int((dt - epoch).total_seconds() // 60)
    rem = mins % step
    if rem * 2 >= step: mins += step - rem
    else: mins -= rem
    return epoch + timedelta(minutes=mins)

class Activity:
    def __init__(self, start, end, project, desc, line=0, raw=""):
        self.start=start; self.end=end; self.project=project; self.desc=desc; self.line=line; self.raw=raw
    @property
    def running(self): return self.end is None
    def end_or_now(self): return self.end or now_dt()
    def minutes(self): return int((self.end_or_now() - self.start).total_seconds() // 60)
    def key(self): return (self.desc, self.project)
    def line_text(self):
        left = self.start.strftime(DT_FMT)
        if self.end: left += " - " + self.end.strftime(DT_FMT)
        return f"{left} | {self.project} | {self.desc}"

def parse_line(line, n):
    raw=line.rstrip("\n")
    pat = r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2})(?: - (\d{4}-\d{2}-\d{2} \d{2}:\d{2}))? \| (.*) \| (.*)$"
    m=re.match(pat, raw)
    if not m: return None
    try:
        st=datetime.strptime(m.group(1), DT_FMT)
        en=datetime.strptime(m.group(2), DT_FMT) if m.group(2) else None
    except Exception:
        return None
    return Activity(st,en,m.group(3),m.group(4),n,raw)

def need_file(path):
    if not path:
        die("Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable")
    return path

def read_file(path, warn=True):
    acts=[]; bad=[]
    try:
        with open(path) as f:
            for i,line in enumerate(f,1):
                if line.strip()=="":
                    continue
                a=parse_line(line,i)
                if a: acts.append(a)
                else: bad.append((i,line.rstrip("\n")))
    except FileNotFoundError:
        die(f"Error: Could not read from file: {path}\n\nCaused by:\n    No such file or directory (os error 2)")
    if bad and warn:
        for i,_ in bad:
            eprint(f"Warning: Ignoring line {i}. Please see `bartib check` for further information")
        eprint()
    return acts,bad

def write_file(path, acts):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path,"w") as f:
        for a in acts:
            f.write(a.line_text()+"\n")

def maybe_read_existing(path):
    if os.path.exists(path): return read_file(path)[0]
    return []

def start_activity(path, desc, project, when):
    acts=maybe_read_existing(path)
    for a in acts:
        if a.running:
            a.end=when
            print(f'Stopped activity: "{a.desc}" ({a.project}) started at {a.start.strftime(DT_FMT)} ({fmt_dur(a.minutes())})')
    a=Activity(when,None,project,desc)
    acts.append(a); write_file(path,acts)
    print(f'Started activity: "{desc}" ({project}) at {when.strftime(DT_FMT)}')

def stop_activity(path, when):
    acts=read_file(path)[0]; found=False
    for a in acts:
        if a.running:
            a.end=when; found=True
            print(f'Stopped activity: "{a.desc}" ({a.project}) started at {a.start.strftime(DT_FMT)} ({fmt_dur(a.minutes())})')
    if not found: print("No Activity is currently running")
    write_file(path,acts)

def cancel_activity(path):
    acts=read_file(path)[0]; keep=[]; found=False
    for a in acts:
        if a.running:
            found=True; print(f'Canceled activity: "{a.desc}" ({a.project}) started at {a.start.strftime(DT_FMT)}')
        else: keep.append(a)
    if not found: print("No Activity is currently running")
    write_file(path,keep)

def change_activity(path, desc, project, when):
    acts=read_file(path)[0]; running=[a for a in acts if a.running]
    if not running: print("No Activity is currently running"); return
    for a in running:
        if when and when != a.start:
            a.end=when
            print(f'Stopped activity: "{a.desc}" ({a.project}) started at {a.start.strftime(DT_FMT)} ({fmt_dur(a.minutes())})')
            na=Activity(when,None,project or a.project,desc or a.desc); acts.append(na)
            print(f'Started activity: "{na.desc}" ({na.project}) at {when.strftime(DT_FMT)}')
        else:
            if desc: a.desc=desc
            if project: a.project=project
            print(f'Changed activity: "{a.desc}" ({a.project}) started at {a.start.strftime(DT_FMT)}')
    write_file(path,acts)

def unique_recent(acts):
    out=[]; seen=set()
    for a in reversed(acts):
        k=a.key()
        if k not in seen:
            seen.add(k); out.append(a)
    return out

def continue_activity(path, num, desc, project, when):
    acts=read_file(path)[0]
    recent=unique_recent([a for a in acts if not a.running])
    if not recent:
        die("Error: No Activity to continue")
    try: base=recent[int(num)]
    except Exception: die(f"Error: There is no activity with number {num}")
    start_activity(path, desc or base.desc, project or base.project, when)

def filter_acts(acts,args):
    today=date.today()
    frm=to=None
    if flag(args,"--today"): frm=to=today
    if flag(args,"--yesterday"): frm=to=today-timedelta(days=1)
    if flag(args,"--current_week"):
        frm=today-timedelta(days=today.weekday()); to=frm+timedelta(days=6)
    if flag(args,"--last_week"):
        this=today-timedelta(days=today.weekday()); frm=this-timedelta(days=7); to=this-timedelta(days=1)
    if opt(args,"-d","--date"): frm=to=parse_date(opt(args,"-d","--date"))
    if opt(args,None,"--from"): frm=parse_date(opt(args,None,"--from"))
    if opt(args,None,"--to"): to=parse_date(opt(args,None,"--to"))
    proj=opt(args,"-p","--project")
    res=[]
    for a in acts:
        if proj and a.project!=proj: continue
        d=a.start.date()
        if frm and d<frm: continue
        if to and d>to: continue
        res.append(a)
    n=opt(args,"-n","--number")
    if n:
        try: res=res[-int(n):]
        except Exception: pass
    return res

def pad_rows(rows):
    widths=[0]*len(rows[0])
    for r in rows:
        for i,c in enumerate(r): widths[i]=max(widths[i],len(c))
    return [" ".join(c.ljust(widths[i]) for i,c in enumerate(r))+" " for r in rows]

def print_list(acts,args):
    rnd=opt(args,None,"--round")
    no_group=flag(args,None,"--no_grouping")
    print()
    if no_group: print(f"{UNDER}Started          {RESET} {UNDER}Stopped{RESET} {UNDER}Description{RESET} {UNDER}Project{RESET} {UNDER}Duration{RESET} ")
    else: print(f"{UNDER}Started{RESET} {UNDER}Stopped{RESET} {UNDER}Description{RESET} {UNDER}Project{RESET} {UNDER}Duration{RESET} ")
    if no_group:
        rows=[]
        for a in acts:
            st=round_dt(a.start,rnd); en=round_dt(a.end_or_now(),rnd)
            rows.append([st.strftime(DT_FMT), en.strftime("%H:%M") if a.end else "-", a.desc, a.project, fmt_dur((en-st).total_seconds()/60)])
        for line in pad_rows(rows) if rows else []: print(line)
    else:
        by=OrderedDict()
        for a in acts: by.setdefault(a.start.date(),[]).append(a)
        for d,items in by.items():
            print()
            total=0; rows=[]
            for a in items:
                st=round_dt(a.start,rnd); en=round_dt(a.end_or_now(),rnd)
                mins=int((en-st).total_seconds()//60); total+=mins
                rows.append([st.strftime("%H:%M"), en.strftime("%H:%M") if a.end else "-", a.desc, a.project, fmt_dur(mins)])
            print(f"{BOLD}{d.isoformat()}\t{fmt_dur(total)}{RESET}")
            for line in pad_rows(rows):
                if any(a.running for a in items) and "-" in line.split():
                    print(GREEN+line+RESET)
                else: print(line)
    print()

def print_report(acts,args):
    rnd=opt(args,None,"--round")
    data=OrderedDict(); total=0
    for a in acts:
        st=round_dt(a.start,rnd); en=round_dt(a.end_or_now(),rnd)
        mins=int((en-st).total_seconds()//60); total+=mins
        data.setdefault(a.project,OrderedDict())
        data[a.project][a.desc]=data[a.project].get(a.desc,0)+mins
    print()
    for p,descs in data.items():
        pt=sum(descs.values())
        print(f"{BOLD}{p}{'.' * max(0, 5-len(p))} {fmt_dur(pt)}{RESET}")
        w=max([len(d) for d in descs] or [0])
        for d,m in descs.items():
            print(f"    {d.ljust(w)} {fmt_dur(m)}")
        print()
    print(f"{BOLD}Total {fmt_dur(total)}{RESET}\n")

def print_last(acts,n=10, search=None):
    recent=unique_recent(acts)
    if search is not None:
        s=search.lower(); recent=[a for a in recent if s in a.desc.lower() or s in a.project.lower()]
    recent=recent[:int(n)]
    print()
    print(f"{UNDER} # {RESET} {UNDER}Description{RESET} {UNDER}Project{RESET} ")
    if not recent: return
    dw=max(11,max(len(a.desc) for a in recent)); pw=max(7,max(len(a.project) for a in recent))
    for i,a in enumerate(recent):
        idx=unique_recent(acts).index(a)
        print(f"[{idx}] {a.desc.ljust(dw)} {a.project.ljust(pw)} ")
    print()

def print_current(acts):
    run=[a for a in acts if a.running]
    if not run: print("No Activity is currently running"); return
    print()
    print(f"{UNDER}Started At      {RESET} {UNDER}Description{RESET} {UNDER}Project{RESET} {UNDER}Duration{RESET} ")
    dw=max(11,max(len(a.desc) for a in run)); pw=max(7,max(len(a.project) for a in run))
    for a in run:
        print(f"{a.start.strftime(DT_FMT)} {a.desc.ljust(dw)} {a.project.ljust(pw)} {fmt_dur(a.minutes()).ljust(8)} ")
    print()

def cmd_status(acts, project=None):
    flt=[a for a in acts if not project or a.project==project]
    today=date.today(); week=today-timedelta(days=today.weekday()); month=today.replace(day=1)
    def sum_since(d): return sum(a.minutes() for a in flt if a.start.date()>=d)
    print(f"{DIM}\n ======={RESET}{IT} Status for {RESET}{BOLD}{project or 'ALL'}{RESET}{IT} projects {RESET}{DIM} ======= {RESET}")
    run=[a for a in flt if a.running]
    if run:
        for a in run: print(f"{DIM+IT}\n  NOW: {RESET}{BOLD}{a.desc} ({a.project}) {fmt_dur(a.minutes())}{RESET}")
    else: print(f"{DIM+IT}\n  NOW: {RESET}{BOLD} NO Activity\n{RESET}", end="")
    print(f"{IT} {RESET}{DIM+IT} Today......................... {RESET}{BOLD}{fmt_dur(sum_since(today))}{RESET}{IT}")
    print(f"{RESET}{IT} {RESET}{DIM+IT} Current week.................. {RESET}{BOLD}{fmt_dur(sum_since(week))}{RESET}{IT}")
    print(f"{RESET}{IT} {RESET}{DIM+IT} Current month................. {RESET}{BOLD}{fmt_dur(sum_since(month))}{RESET}{IT}\n{RESET}")

def opt(args, short=None, long=None, default=None):
    for key in [short,long]:
        if not key: continue
        if key in args:
            i=args.index(key)
            if i+1 < len(args): return args[i+1]
    return default

def flag(args, short=None, long=None):
    return (short and short in args) or (long and long in args)

def rest_without_opts(args):
    out=[]; skip=False
    valopts={"-f","-d","--description","-p","--project","-t","--time","-n","--number","--date","--from","--to","--round","-e"}
    for i,a in enumerate(args):
        if skip: skip=False; continue
        if a in valopts: skip=True; continue
        if a.startswith("-"): continue
        out.append(a)
    return out

HELP_MAIN = """bartib 1.1.0
Nikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>
A simple timetracker

USAGE:
    executable [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]

SUBCOMMANDS:
    cancel      cancels all currently running activities
    change      changes the current activity
    check       checks file and reports parsing errors
    continue    continues a previous activity
    current     lists all currently running activities
    edit        opens the activity log in an editor
    help        Prints this message or the help of the given subcommand(s)
    last        displays the descriptions and projects of recent activities
    list        list recent activities
    projects    list all projects
    report      reports duration of tracked activities
    sanity      checks sanity of bartib log
    search      search for existing descriptions and projects
    start       starts a new activity
    status      shows current status and time reports for today, current week, and current month
    stop        stops all currently running activities

To get help for a specific subcommand, run `bartib [SUBCOMMAND] --help`.
To get started, view the `start` help with `bartib start --help`"""

def subhelp(cmd):
    helps={
"start": "executable-start \nstarts a new activity\n\nUSAGE:\n    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)",
"stop": "executable-stop \nstops all currently running activities\n\nUSAGE:\n    executable stop [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -t, --time <TIME>    the time for changing the activity status (HH:MM)",
"cancel": "executable-cancel \ncancels all currently running activities\n\nUSAGE:\n    executable cancel\n\nFLAGS:\n    -h, --help    Prints help information",
"change": "executable-change \nchanges the current activity\n\nUSAGE:\n    executable change [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)",
"check": "executable-check \nchecks file and reports parsing errors\n\nUSAGE:\n    executable check\n\nFLAGS:\n    -h, --help    Prints help information",
"continue": "executable-continue \ncontinues a previous activity\n\nUSAGE:\n    executable continue [OPTIONS] [NUMBER]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)\n\nARGS:\n    <NUMBER>    the number of the activity to continue (see subcommand `last`) [default: 0]",
"current": "executable-current \nlists all currently running activities\n\nUSAGE:\n    executable current\n\nFLAGS:\n    -h, --help    Prints help information",
"edit": "executable-edit \nopens the activity log in an editor\n\nUSAGE:\n    executable edit [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -e <editor>        the command to start your preferred text editor [env: EDITOR=]",
"last": "executable-last \ndisplays the descriptions and projects of recent activities\n\nUSAGE:\n    executable last [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -n, --number <NUMBER>    maximum number of lines to display [default: 10]",
"list": "executable-list \nlist recent activities\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --no_grouping     do not group activities by date in list\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -n, --number <NUMBER>      maximum number of activities to display\n    -p, --project <PROJECT>    do list activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or\n                               hours. E.g. 15m or 4h\n        --to <TO_DATE>         end of date range (inclusive)",
"projects": "executable-projects \nlist all projects\n\nUSAGE:\n    executable projects [FLAGS]\n\nFLAGS:\n    -c, --current      prints currently running projects only\n    -h, --help         Prints help information\n    -n, --no-quotes    prints projects without quotes",
"report": "executable-report \nreports duration of tracked activities\n\nUSAGE:\n    executable report [FLAGS] [OPTIONS]\n\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -p, --project <PROJECT>    do report activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or\n                               hours. E.g. 15m or 4h\n        --to <TO_DATE>         end of date range (inclusive)",
"sanity": "executable-sanity \nchecks sanity of bartib log\n\nUSAGE:\n    executable sanity\n\nFLAGS:\n    -h, --help    Prints help information",
"search": "executable-search \nsearch for existing descriptions and projects\n\nUSAGE:\n    executable search <SEARCH_TERM>\n\nFLAGS:\n    -h, --help    Prints help information\n\nARGS:\n    <SEARCH_TERM>    the search term [default: '']",
"status": "executable-status \nshows current status and time reports for today, current week, and current month\n\nUSAGE:\n    executable status [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -p, --project <PROJECT>    show status for this project only",
}
    if cmd in helps: print(helps[cmd])
    else: print(HELP_MAIN)

def main():
    args=sys.argv[1:]
    if not args or args[0] in ("--help","-h"):
        print(HELP_MAIN); return
    if "--version" in args or "-V" in args: print(VERSION); return
    path=opt(args,"-f","--file",os.environ.get("BARTIB_FILE"))
    if "-f" in args:
        i=args.index("-f"); del args[i:i+2]
    if "--file" in args:
        i=args.index("--file"); del args[i:i+2]
    cmd=args[0]; cargs=args[1:]
    if cmd=="help":
        if cargs: subhelp(cargs[0])
        else: print(HELP_MAIN)
        return
    if "--help" in cargs or "-h" in cargs: subhelp(cmd); return
    path=need_file(path)
    when=parse_hhmm(opt(cargs,"-t","--time")) if opt(cargs,"-t","--time") else now_dt()
    if cmd=="start":
        d=opt(cargs,"-d","--description"); p=opt(cargs,"-p","--project")
        if not d or not p: die("error: The following required arguments were not provided:\n    --description <DESCRIPTION> and/or --project <PROJECT>")
        start_activity(path,d,p,when)
    elif cmd=="stop": stop_activity(path,when)
    elif cmd=="cancel": cancel_activity(path)
    elif cmd=="change": change_activity(path,opt(cargs,"-d","--description"),opt(cargs,"-p","--project"),when if opt(cargs,"-t","--time") else None)
    elif cmd=="continue":
        nums=rest_without_opts(cargs); num=nums[0] if nums else "0"
        continue_activity(path,num,opt(cargs,"-d","--description"),opt(cargs,"-p","--project"),when)
    elif cmd=="current": print_current(read_file(path)[0])
    elif cmd=="list": print_list(filter_acts(read_file(path)[0],cargs),cargs)
    elif cmd=="report": print_report(filter_acts(read_file(path)[0],cargs),cargs)
    elif cmd=="last": print_last(read_file(path)[0], opt(cargs,"-n","--number","10"))
    elif cmd=="search":
        terms=rest_without_opts(cargs); print_last(read_file(path)[0], 10, terms[0] if terms else "")
    elif cmd=="projects":
        acts=read_file(path)[0]
        ps=sorted(set(a.project for a in acts if (not flag(cargs,"-c","--current") or a.running)))
        for p in ps: print(p if flag(cargs,"-n","--no-quotes") else f'"{p}"')
    elif cmd=="check":
        _,bad=read_file(path, warn=False)
        if not bad: print("All lines in the file have been successfully parsed as activities.")
        else:
            print(f"Found {len(bad)} line(s) with parsing errors\n")
            for i,line in bad: print(f"{line}\n  -> could not parse activity (Line: {i})")
    elif cmd=="sanity": read_file(path); print("No unusual activities.")
    elif cmd=="status": cmd_status(read_file(path)[0], opt(cargs,"-p","--project"))
    elif cmd=="edit":
        editor=opt(cargs,"-e",None,os.environ.get("EDITOR"))
        if not editor: die("Error: No editor specified")
        subprocess.call([editor,path])
    else:
        die(f"error: Found argument '{cmd}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [OPTIONS] <SUBCOMMAND>\n\nFor more information try --help")

if __name__ == "__main__":
    main()
