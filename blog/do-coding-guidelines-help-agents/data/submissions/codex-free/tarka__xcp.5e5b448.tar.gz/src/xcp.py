#!/usr/bin/env python3
import argparse
import fnmatch
import glob as globmod
import os
import shutil
import stat
import sys


VERSION = "xcp 0.24.3"
DESC = "A (partial) clone of the Unix `cp` command with progress and pluggable drivers."


class XcpError(Exception):
    pass


def make_parser():
    p = argparse.ArgumentParser(
        prog="executable",
        description=DESC,
        allow_abbrev=False,
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter,
    )
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-r", "--recursive", action="store_true")
    p.add_argument("-L", "--dereference", action="store_true")
    p.add_argument("-w", "--workers", default="4")
    p.add_argument("--block-size", default="1MB")
    p.add_argument("-n", "--no-clobber", action="store_true")
    p.add_argument("-f", "--force", action="store_true")
    p.add_argument("--gitignore", action="store_true")
    p.add_argument("-g", "--glob", action="store_true")
    p.add_argument("--no-progress", action="store_true")
    p.add_argument("--no-perms", action="store_true")
    p.add_argument("--no-timestamps", action="store_true")
    p.add_argument("-o", "--ownership", action="store_true")
    p.add_argument("--driver", default="parfile")
    p.add_argument("-T", "--no-target-directory", action="store_true")
    p.add_argument("--target-directory")
    p.add_argument("--fsync", action="store_true")
    p.add_argument("--reflink", default="auto")
    p.add_argument("--backup", default="none")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("paths", nargs="*")
    return p


def print_short_help():
    print(DESC)
    print()
    print("Usage: executable [OPTIONS] [PATHS]...")
    print()
    print("Arguments:")
    print("  [PATHS]...  Path list")
    print()
    print("Options:")
    rows = [
        ("  -v, --verbose...", "Verbosity"),
        ("  -r, --recursive", "Copy directories recursively"),
        ("  -L, --dereference", "Dereference symlinks in source"),
        ("  -w, --workers <WORKERS>", "Number of parallel workers [default: 4]"),
        ("      --block-size <BLOCK_SIZE>", "Block size for operations [default: 1MB]"),
        ("  -n, --no-clobber", "Do not overwrite an existing file"),
        ("  -f, --force", "Force (compatability only)"),
        ("      --gitignore", "Use .gitignore if present"),
        ("  -g, --glob", "Expand file patterns"),
        ("      --no-progress", "Disable progress bar"),
        ("      --no-perms", "Do not copy the file permissions"),
        ("      --no-timestamps", "Do not copy the file timestamps"),
        ("  -o, --ownership", "Copy ownership"),
        ("      --driver <DRIVER>", "Driver to use, defaults to 'file-parallel' [default: parfile]"),
        ("  -T, --no-target-directory", "Target should not be a directory"),
        ("      --target-directory <TARGET_DIRECTORY>", "Copy into a subdirectory of the target"),
        ("      --fsync", "Sync each file to disk after writing"),
        ("      --reflink <REFLINK>", "Reflink options [default: auto]"),
        ("      --backup <BACKUP>", "Backup options [default: none]"),
        ("  -h, --help", "Print help (see more with '--help')"),
        ("  -V, --version", "Print version"),
    ]
    for left, right in rows:
        print(f"{left:<32}{right}")


def print_long_help():
    print(DESC)
    print()
    print("Usage: executable [OPTIONS] [PATHS]...")
    print()
    print("Arguments:")
    print("  [PATHS]...")
    print("          Path list.")
    print("          ")
    print("          Source and destination files, or multiple source(s) to a directory.")
    print()
    print("Options:")
    print("  -v, --verbose...")
    print("          Verbosity.")
    print("          ")
    print("          Can be specified multiple times to increase logging.")
    print()
    print("  -r, --recursive")
    print("          Copy directories recursively")
    print()
    print("  -L, --dereference")
    print("          Dereference symlinks in source")
    print("          ")
    print("          Follow symlinks, possibly recursively, when copying source files.")
    print()
    print("  -w, --workers <WORKERS>")
    print("          Number of parallel workers.")
    print("          ")
    print("          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.")
    print("          ")
    print("          [default: 4]")
    print()
    print("      --block-size <BLOCK_SIZE>")
    print("          Block size for operations.")
    print("          ")
    print("          Accepts standard size modifiers like \"M\" and \"GB\". Actual usage internally depends on the driver.")
    print("          ")
    print("          [default: 1MB]")
    print()
    print("  -n, --no-clobber")
    print("          Do not overwrite an existing file")
    print()
    print("  -f, --force")
    print("          Force (compatability only)")
    print("          ")
    print("          Overwrite files; this is the default behaviour, this flag is for compatibility with `cp` only. See `--no-clobber` for the inverse flag. Using this in conjunction with `--no-clobber` will cause an error.")
    print()
    print("      --gitignore")
    print("          Use .gitignore if present.")
    print("          ")
    print("          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.")
    print()
    print("  -g, --glob")
    print("          Expand file patterns.")
    print("          ")
    print("          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)")
    print()
    print("      --no-progress")
    print("          Disable progress bar")
    print()
    print("      --no-perms")
    print("          Do not copy the file permissions")
    print()
    print("      --no-timestamps")
    print("          Do not copy the file timestamps")
    print()
    print("  -o, --ownership")
    print("          Copy ownership.")
    print("          ")
    print("          Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.")
    print()
    print("      --driver <DRIVER>")
    print("          Driver to use, defaults to 'file-parallel'.")
    print("          ")
    print("          Currently there are 2; the default \"parfile\", which parallelises copies across workers at the file level, and an experimental \"parblock\" driver, which parellelises at the block level. See also '--block-size'.")
    print("          ")
    print("          [default: parfile]")
    print()
    print("  -T, --no-target-directory")
    print("          Target should not be a directory.")
    print("          ")
    print("          Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.")
    print()
    print("      --target-directory <TARGET_DIRECTORY>")
    print("          Copy into a subdirectory of the target")
    print()
    print("      --fsync")
    print("          Sync each file to disk after writing")
    print()
    print("      --reflink <REFLINK>")
    print("          Reflink options.")
    print("          ")
    print("          Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.")
    print("          ")
    print("          Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.")
    print("          ")
    print("          [default: auto]")
    print()
    print("      --backup <BACKUP>")
    print("          Backup options")
    print("          ")
    print("          Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of `cp` numbered backups (e.g. `file.txt.~123~`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.")
    print("          ")
    print("          [default: none]")
    print()
    print("  -h, --help")
    print("          Print help (see a summary with '-h')")
    print()
    print("  -V, --version")
    print("          Print version")


def fail(message):
    raise XcpError(message)


def dest_exists(path):
    return os.path.exists(path) or os.path.islink(path)


def backup_path(path):
    i = 1
    while True:
        candidate = f"{path}.~{i}~"
        if not dest_exists(candidate):
            return candidate
        i += 1


def previous_backup_exists(path):
    parent = os.path.dirname(path) or "."
    base = os.path.basename(path)
    try:
        names = os.listdir(parent)
    except OSError:
        return False
    return any(name.startswith(base + ".~") and name.endswith("~") for name in names)


def prepare_overwrite(path, opts):
    if not dest_exists(path):
        return
    if opts.no_clobber:
        fail(f"Destination Exists: Destination file exists and --no-clobber is set., {path}")
    backup = opts.backup.lower()
    if backup in ("numbered", "t"):
        shutil.move(path, backup_path(path))
    elif backup == "auto" and previous_backup_exists(path):
        shutil.move(path, backup_path(path))
    elif backup in ("none", "off", "never", "simple"):
        remove_any(path)
    else:
        remove_any(path)


def remove_any(path):
    if os.path.isdir(path) and not os.path.islink(path):
        shutil.rmtree(path)
    else:
        os.unlink(path)


def fsync_file(path):
    try:
        with open(path, "rb") as f:
            os.fsync(f.fileno())
    except OSError:
        pass


def copy_metadata(src, dst, opts, follow=True):
    if not opts.no_perms:
        try:
            shutil.copymode(src, dst, follow_symlinks=follow)
        except OSError:
            pass
    if not opts.no_timestamps:
        try:
            shutil.copystat(src, dst, follow_symlinks=follow)
        except OSError:
            pass
    if opts.ownership:
        try:
            st = os.stat(src) if follow else os.lstat(src)
            os.chown(dst, st.st_uid, st.st_gid, follow_symlinks=follow)
        except OSError as e:
            if opts.verbose:
                print(f"Warning: Could not copy ownership: {e}", file=sys.stderr)


def copy_file(src, dst, opts):
    parent = os.path.dirname(dst)
    if parent:
        os.makedirs(parent, exist_ok=True)
    prepare_overwrite(dst, opts)
    if opts.no_perms and opts.no_timestamps:
        shutil.copyfile(src, dst, follow_symlinks=True)
    else:
        shutil.copy2(src, dst, follow_symlinks=True)
        if opts.no_perms or opts.no_timestamps:
            copy_metadata(src, dst, opts, follow=True)
    if opts.fsync:
        fsync_file(dst)


def copy_symlink(src, dst, opts):
    parent = os.path.dirname(dst)
    if parent:
        os.makedirs(parent, exist_ok=True)
    prepare_overwrite(dst, opts)
    os.symlink(os.readlink(src), dst)
    copy_metadata(src, dst, opts, follow=False)


def load_gitignore(root):
    patterns = []
    path = os.path.join(root, ".gitignore")
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                patterns.append(line)
    except OSError:
        pass
    return patterns


def ignored(rel, is_dir, patterns):
    rel = rel.replace(os.sep, "/")
    name = os.path.basename(rel)
    for pat in patterns:
        neg = pat.startswith("!")
        if neg:
            pat = pat[1:]
        dir_only = pat.endswith("/")
        if dir_only:
            pat = pat[:-1]
        if dir_only and not is_dir:
            continue
        anchored = pat.startswith("/")
        if anchored:
            pat = pat[1:]
        matched = fnmatch.fnmatch(rel, pat) if (anchored or "/" in pat) else fnmatch.fnmatch(name, pat)
        if matched:
            return not neg
    return False


def copy_dir_contents(src, dst, opts, patterns=None):
    os.makedirs(dst, exist_ok=True)
    copy_metadata(src, dst, opts, follow=opts.dereference)
    if patterns is None and opts.gitignore:
        patterns = load_gitignore(src)
    elif patterns is None:
        patterns = []

    with os.scandir(src) as it:
        for entry in it:
            s = entry.path
            rel = os.path.relpath(s, src)
            is_dir_entry = entry.is_dir(follow_symlinks=opts.dereference)
            if ignored(rel, is_dir_entry, patterns):
                continue
            d = os.path.join(dst, entry.name)
            copy_entry(s, d, opts, patterns)


def copy_entry(src, dst, opts, patterns=None):
    if not os.path.lexists(src):
        fail(f"Invalid source: Source file not found: {src}")
    if os.path.islink(src) and not opts.dereference:
        copy_symlink(src, dst, opts)
        return
    try:
        mode = os.stat(src).st_mode
    except OSError as e:
        fail(f"Invalid source: {e}")
    if stat.S_ISDIR(mode):
        if not opts.recursive:
            fail("Invalid source: Source is directory and --recursive not specified.")
        if dest_exists(dst) and not os.path.isdir(dst):
            prepare_overwrite(dst, opts)
        os.makedirs(dst, exist_ok=True)
        copy_dir_contents(src, dst, opts, patterns)
    elif stat.S_ISREG(mode):
        if os.path.isdir(dst):
            fail(f"Invalid destination: Destination is a directory: {dst}")
        copy_file(src, dst, opts)
    else:
        if os.path.isdir(dst):
            fail(f"Invalid destination: Destination is a directory: {dst}")
        # Good enough for FIFOs/devices in a cleanroom: copy regular contents if openable.
        copy_file(src, dst, opts)


def expand_paths(paths, use_glob):
    if not use_glob:
        return paths
    out = []
    for p in paths:
        matches = globmod.glob(p)
        if matches:
            out.extend(matches)
    return out


def run(opts):
    opts.backup = opts.backup.lower()
    if opts.force and opts.no_clobber:
        fail("Invalid arguments: --force and --noclobber cannot be set at the same time.")
    if opts.reflink not in ("auto", "always", "never"):
        fail(f"Invalid arguments: invalid reflink option: {opts.reflink}")
    if opts.driver not in ("parfile", "parblock", "file-parallel", "block-parallel"):
        fail(f"Invalid arguments: invalid driver: {opts.driver}")
    if opts.target_directory and opts.no_target_directory:
        fail("Invalid arguments: --target-directory and --no-target-directory cannot be used together.")

    paths = expand_paths(opts.paths, opts.glob)
    if opts.target_directory:
        if not paths:
            fail("Invalid arguments: Insufficient arguments")
        dest = opts.target_directory
        if not os.path.isdir(dest):
            fail("Invalid destination: Multiple sources and destination is not a directory.")
        sources = paths
    else:
        if len(paths) < 2:
            fail("Invalid arguments: Insufficient arguments")
        dest = paths[-1]
        sources = paths[:-1]

    if not sources:
        fail("Invalid source: No source files found.")
    multiple = len(sources) > 1
    if multiple and not os.path.isdir(dest):
        fail("Invalid destination: Multiple sources and destination is not a directory.")

    for src in sources:
        if not os.path.lexists(src):
            fail(f"Invalid source: Source file not found: {src}")
        if opts.target_directory or multiple:
            target = os.path.join(dest, os.path.basename(src.rstrip(os.sep)))
        elif opts.no_target_directory:
            target = dest
        elif os.path.isdir(dest):
            target = os.path.join(dest, os.path.basename(src.rstrip(os.sep)))
        else:
            target = dest
        copy_entry(src, target, opts)


def main(argv):
    if argv == ["--help"]:
        print_long_help()
        return 0
    if argv == ["-h"]:
        print_short_help()
        return 0
    if argv == ["--version"] or argv == ["-V"]:
        print(VERSION)
        return 0
    parser = make_parser()
    try:
        opts = parser.parse_args(argv)
    except SystemExit as e:
        return e.code
    if opts.help:
        print_short_help()
        return 0
    if opts.version:
        print(VERSION)
        return 0
    try:
        run(opts)
        return 0
    except XcpError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except BrokenPipeError:
        return 1
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
