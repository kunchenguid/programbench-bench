#!/usr/bin/env python3
import argparse
import os
import re
import sys
import textwrap
import xml.etree.ElementTree as ET

VERSION = "svd2rust 0.37.1 (e29353d 2026-03-03)"

LONG_HELP = """Generate a Rust API from SVD files

Usage: executable [OPTIONS]

Options:
  -i <FILE>
          Input SVD file

  -o, --output-dir <PATH>
          Directory to place generated files

  -c, --config <TOML_FILE>
          Config TOML file

      --settings <YAML_FILE>
          Target-specific settings YAML file

      --edition <YEAR>
          Rust edition of generated code

      --target <ARCH>
          Target architecture

      --atomics
          Generate atomic register modification API

      --atomics-feature <FEATURE>
          add feature gating for atomic register modification API

      --ignore-groups
          Don't add alternateGroup name as prefix to register name

      --keep-list
          Keep lists when generating code of dimElement, instead of trying to generate arrays

  -g, --generic-mod
          Push generic mod in separate file

      --feature-group
          Use group_name of peripherals as feature

      --feature-peripheral
          Use independent cfg feature flags for each peripheral

  -f, --ident-format <ident_format>
          Specify `-f type:prefix:case:suffix` to change default ident formatting.
          Allowed values of `type` are ["register_spec", "enum_value_accessor", "register_accessor", "enum_name", "peripheral", "field_writer", "cluster_accessor", "peripheral_singleton", "peripheral_mod", "peripheral_feature", "enum_write_name", "enum_value", "field_reader", "enum_read_name", "register_mod", "register", "cluster", "field_accessor", "cluster_mod", "interrupt", "peripheral_spec"].
          Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').
          

      --ident-formats-theme <THEME>
          A set of `ident_format` settings. `new` or `legacy`

      --field-names-for-enums
          Use field name for enumerations even when enumeratedValues has a name

      --max-cluster-size
          Use array increment for cluster size

      --impl-debug
          implement Debug for readable blocks and registers

      --impl-debug-feature <FEATURE>
          Add feature gating for block and register debug implementation

      --impl-defmt <FEATURE>
          Add automatic defmt implementation for enumerated values

  -m, --make-mod
          Create mod.rs instead of lib.rs, without inner attributes

      --skip-crate-attributes
          Do not generate crate attributes

  -s, --strict
          Make advanced checks due to parsing SVD

      --source-type <source_type>
          Specify file/stream format

      --reexport-core-peripherals
          For Cortex-M target reexport peripherals from cortex-m crate

      --reexport-interrupt
          Reexport interrupt macro from cortex-m-rt like crates

  -b, --base-address-shift <base_address_shift>
          Add offset to all base addresses on all peripherals in the SVD file.
          Useful for soft-cores where the peripheral address range isn't necessarily fixed.
          Ignore this option if you are not building your own FPGA based soft-cores.

  -l, --log <log_level>
          Choose which messages to log (overrides RUST_LOG)
          
          [possible values: off, error, warn, info, debug, trace]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

SHORT_HELP = LONG_HELP.replace("\n\n", "\n")

def log(level, msg):
    print(f"[{level:<5} svd2rust] {msg}", file=sys.stderr)

def err(msg, cause=None, code=1):
    print(f"[ERROR svd2rust] {msg}", file=sys.stderr)
    if cause:
        print("    \n    Caused by:", file=sys.stderr)
        print(f"        {cause}", file=sys.stderr)
    sys.exit(code)

def clean_name(s):
    s = (s or "").strip()
    s = s.replace("%s", "")
    s = re.sub(r"\[[^\]]+\]", "", s)
    s = re.sub(r"[^0-9A-Za-z_]+", "_", s)
    return s.strip("_") or "unnamed"

def words(s):
    s = clean_name(s)
    parts = []
    for p in re.split(r"_+", s):
        parts += re.findall(r"[A-Z]+(?=[A-Z][a-z]|$)|[A-Z]?[a-z]+|\d+|[A-Z]+", p)
    return [p.lower() for p in parts if p]

def snake(s):
    out = "_".join(words(s))
    if not out:
        out = "unnamed"
    if out[0].isdigit():
        out = "_" + out
    if out in {"type","match","mod","crate","self","super","fn","struct","enum","use","pub","const","static","ref","move","async","await","loop","where","unsafe","impl"}:
        out += "_"
    return out

def pascal(s):
    out = "".join(w[:1].upper() + w[1:] for w in words(s))
    if not out:
        out = "Unnamed"
    if out[0].isdigit():
        out = "_" + out
    return out

def const_ident(s):
    out = "_".join(w.upper() for w in words(s))
    if not out:
        out = "UNNAMED"
    if out[0].isdigit():
        out = "_" + out
    return out

def local(tag):
    return tag.split("}", 1)[-1]

def child(e, name):
    for c in list(e):
        if local(c.tag) == name:
            return c
    return None

def children(e, name):
    return [c for c in list(e) if local(c.tag) == name]

def text(e, name, default=""):
    c = child(e, name)
    return (c.text or "").strip() if c is not None and c.text is not None else default

def parse_int(v, default=0):
    v = (v or "").strip().replace("_", "")
    if not v:
        return default
    try:
        if v.lower().startswith("#"):
            return int(v[1:], 2)
        return int(v, 0)
    except ValueError:
        m = re.search(r"0x[0-9a-fA-F]+|\d+", v)
        return int(m.group(0), 0) if m else default

def fmt_hex(n):
    h = f"{n:x}"
    groups = []
    while h:
        groups.append(h[-4:])
        h = h[:-4]
    return "0x" + "_".join(reversed(groups))

def escape_doc(s):
    return (s or "").replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")

def access_kind(reg, inherited="read-write"):
    a = text(reg, "access", inherited or "read-write").lower()
    if a in {"read-only", "read"}:
        return "r"
    if a in {"write-only", "write"}:
        return "w"
    return "rw"

def bit_range(field):
    if text(field, "bitOffset") or text(field, "bitWidth"):
        off = parse_int(text(field, "bitOffset"), 0)
        width = parse_int(text(field, "bitWidth"), 1)
        return off, width
    rng = text(field, "bitRange")
    m = re.match(r"\[(\d+):(\d+)\]", rng)
    if m:
        hi, lo = int(m.group(1)), int(m.group(2))
        return lo, hi - lo + 1
    lsb = text(field, "lsb")
    msb = text(field, "msb")
    if lsb or msb:
        lo, hi = parse_int(lsb), parse_int(msb)
        return lo, hi - lo + 1
    return 0, 1

def expand_dim(e):
    dim = parse_int(text(e, "dim"), 0)
    if dim <= 1:
        return [(text(e, "name"), parse_int(text(e, "addressOffset")), e)]
    base = text(e, "name")
    inc = parse_int(text(e, "dimIncrement"), 4)
    indexes = [x.strip() for x in text(e, "dimIndex").split(",") if x.strip()]
    if not indexes:
        indexes = [str(i) for i in range(dim)]
    out = []
    for i in range(dim):
        idx = indexes[i] if i < len(indexes) else str(i)
        name = base.replace("%s", idx).replace("[%s]", idx)
        if name == base:
            name = f"{base}{idx}"
        out.append((name, parse_int(text(e, "addressOffset")) + i * inc, e))
    return out

def collect_registers(periph):
    regs = child(periph, "registers")
    out = []
    if regs is None:
        return out
    for r in children(regs, "register"):
        for name, offset, node in expand_dim(r):
            out.append({"name": name, "offset": offset, "node": node})
    out.sort(key=lambda x: x["offset"])
    return out

def generic_code():
    return """#[allow(unused_imports)] use generic::*;
pub mod generic {
    use core::marker;
    pub struct Periph<PER: PeripheralSpec> { _marker: marker::PhantomData<PER> }
    pub trait PeripheralSpec { type RB; const ADDRESS: usize; const NAME: &'static str; }
    unsafe impl<PER: PeripheralSpec> Send for Periph<PER> {}
    impl<PER: PeripheralSpec> Periph<PER> {
        pub const PTR: *const PER::RB = PER::ADDRESS as *const _;
        #[inline(always)] pub const fn ptr() -> *const PER::RB { Self::PTR }
        #[inline(always)] pub unsafe fn steal() -> Self { Self { _marker: marker::PhantomData } }
    }
    impl<PER: PeripheralSpec> core::ops::Deref for Periph<PER> {
        type Target = PER::RB;
        #[inline(always)] fn deref(&self) -> &Self::Target { unsafe { &*Self::PTR } }
    }
    pub trait RegisterSpec { type Ux: Copy; }
    pub trait Readable: RegisterSpec {}
    pub trait Writable: RegisterSpec { type Safety; }
    pub trait Resettable: RegisterSpec { const RESET_VALUE: Self::Ux; }
    pub struct Safe; pub struct Unsafe;
    pub struct Reg<REG: RegisterSpec> { _marker: marker::PhantomData<REG> }
    pub struct R<REG: RegisterSpec> { bits: REG::Ux }
    pub struct W<REG: RegisterSpec> { bits: REG::Ux }
    pub struct FieldReader<FI = u8> { bits: FI }
    pub struct BitReader<FI = bool> { bits: bool, _marker: marker::PhantomData<FI> }
    pub struct FieldWriter<'a, REG: Writable + RegisterSpec, const WI: u8, FI = u8> { w: &'a mut W<REG>, o: u8, _marker: marker::PhantomData<FI> }
    pub struct BitWriter<'a, REG: Writable + RegisterSpec, FI = bool> { w: &'a mut W<REG>, o: u8, _marker: marker::PhantomData<FI> }
    impl<REG: RegisterSpec> R<REG> { #[inline(always)] pub const fn bits(&self) -> REG::Ux { self.bits } }
    impl<REG: Writable + RegisterSpec> W<REG> { #[inline(always)] pub unsafe fn bits(&mut self, bits: REG::Ux) -> &mut Self { self.bits = bits; self } }
    impl<FI: Copy> FieldReader<FI> { #[inline(always)] pub const fn new(bits: FI) -> Self { Self { bits } } #[inline(always)] pub const fn bits(&self) -> FI { self.bits } }
    impl<FI> BitReader<FI> { #[inline(always)] pub const fn new(bits: bool) -> Self { Self { bits, _marker: marker::PhantomData } } #[inline(always)] pub const fn bit(&self) -> bool { self.bits } #[inline(always)] pub const fn bit_is_set(&self) -> bool { self.bits } #[inline(always)] pub const fn bit_is_clear(&self) -> bool { !self.bits } }
    impl<'a, REG: Writable + RegisterSpec, const WI: u8, FI> FieldWriter<'a, REG, WI, FI> { #[inline(always)] pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o, _marker: marker::PhantomData } } #[inline(always)] pub unsafe fn bits(self, _value: u8) -> &'a mut W<REG> { self.w } }
    impl<'a, REG: Writable + RegisterSpec, FI> BitWriter<'a, REG, FI> { #[inline(always)] pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o, _marker: marker::PhantomData } } #[inline(always)] pub fn set_bit(self) -> &'a mut W<REG> { self.w } #[inline(always)] pub fn clear_bit(self) -> &'a mut W<REG> { self.w } #[inline(always)] pub fn bit(self, _value: bool) -> &'a mut W<REG> { self.w } }
}
pub use generic::{BitReader, BitWriter, FieldReader, FieldWriter, Periph, PeripheralSpec, R, Readable, Reg, RegisterSpec, Resettable, W, Writable};
"""

def generic_mod_code():
    code = generic_code()
    start = code.index("pub mod generic {\n") + len("pub mod generic {\n")
    end = code.rindex("\n}\npub use")
    return code[start:end] + "\n"

def render_register_module(reg):
    node = reg["node"]
    rname = reg["name"]
    modn = snake(rname)
    spec = pascal(rname) + "Spec"
    desc = text(node, "description")
    size = parse_int(text(node, "size"), 32)
    ux = "u64" if size > 32 else "u32" if size > 16 else "u16" if size > 8 else "u8"
    acc = access_kind(node)
    reset = parse_int(text(node, "resetValue"), 0)
    fields_node = child(node, "fields")
    fields = children(fields_node, "field") if fields_node is not None else []
    lines = [f'#[doc = "{escape_doc(desc)}"] pub mod {modn} {{',
             f'    #[doc = "Register `{rname}` reader"] pub type R = crate::R<{spec}>;']
    if acc != "r":
        lines.append(f'    #[doc = "Register `{rname}` writer"] pub type W = crate::W<{spec}>;')
    for f in fields:
        fname = text(f, "name")
        fdesc = text(f, "description")
        off, width = bit_range(f)
        typ = pascal(fname)
        if width == 1:
            lines.append(f'    #[doc = "Field `{fname}` reader - {escape_doc(fdesc)}"] pub type {typ}R = crate::BitReader;')
            if acc != "r":
                lines.append(f"    #[doc = \"Field `{fname}` writer - {escape_doc(fdesc)}\"] pub type {typ}W<'a, REG> = crate::BitWriter<'a, REG>;")
        else:
            lines.append(f'    #[doc = "Field `{fname}` reader - {escape_doc(fdesc)}"] pub type {typ}R = crate::FieldReader;')
            if acc != "r":
                lines.append(f"    #[doc = \"Field `{fname}` writer - {escape_doc(fdesc)}\"] pub type {typ}W<'a, REG> = crate::FieldWriter<'a, REG, {width}>;")
    if fields:
        lines.append("    impl R {")
        for f in fields:
            fname = text(f, "name")
            fdesc = text(f, "description")
            off, width = bit_range(f)
            mn = snake(fname)
            typ = pascal(fname) + "R"
            mask = (1 << width) - 1 if width < 64 else (1 << 64) - 1
            docbits = f"Bit {off}" if width == 1 else f"Bits {off}:{off+width-1}"
            lines.append(f'        #[doc = "{docbits} - {escape_doc(fdesc)}"]')
            if width == 1:
                lines.append(f'        #[inline(always)] pub fn {mn}(&self) -> {typ} {{ {typ}::new((self.bits() & (1 << {off})) != 0) }}')
            else:
                lines.append(f'        #[inline(always)] pub fn {mn}(&self) -> {typ} {{ {typ}::new(((self.bits() >> {off}) & {mask}) as u8) }}')
        lines.append("    }")
        if acc != "r":
            lines.append("    impl W {")
            for f in fields:
                fname = text(f, "name")
                fdesc = text(f, "description")
                off, width = bit_range(f)
                mn = snake(fname)
                typ = pascal(fname) + "W"
                docbits = f"Bit {off}" if width == 1 else f"Bits {off}:{off+width-1}"
                lines.append(f'        #[doc = "{docbits} - {escape_doc(fdesc)}"]')
                lines.append(f"        #[inline(always)] pub fn {mn}(&mut self) -> {typ}<'_, {spec}> {{ {typ}::new(self, {off}) }}")
            lines.append("    }")
    lines.append(f'    #[doc = "{escape_doc(desc)}"] pub struct {spec};')
    lines.append(f'    impl crate::RegisterSpec for {spec} {{ type Ux = {ux}; }}')
    if acc != "w":
        lines.append(f'    impl crate::Readable for {spec} {{ }}')
    if acc != "r":
        lines.append(f'    impl crate::Writable for {spec} {{ type Safety = crate::generic::Unsafe; }}')
    if reset:
        lines.append(f'    impl crate::Resettable for {spec} {{ const RESET_VALUE: {ux} = {fmt_hex(reset)}; }}')
    else:
        lines.append(f'    impl crate::Resettable for {spec} {{ const RESET_VALUE: {ux} = 0; }}')
    lines.append("}")
    return "\n".join(lines)

def render_peripheral(periph, shift=0, feature_peripheral=False):
    pname = text(periph, "name")
    pdoc = text(periph, "description")
    pmod = snake(pname)
    ptype = pascal(pname)
    pspec = ptype + "Spec"
    base = parse_int(text(periph, "baseAddress"), 0) + shift
    regs = collect_registers(periph)
    lines = []
    if feature_peripheral:
        lines.append(f'#[cfg(feature = "{snake(pname)}")]')
    lines.append(f'#[doc = "{escape_doc(pdoc)}"] pub type {ptype} = crate::Periph<{pspec}>;')
    lines.append(f"pub struct {pspec}; impl crate::PeripheralSpec for {pspec} {{ type RB = {pmod}::RegisterBlock; const ADDRESS: usize = {fmt_hex(base)}; const NAME: &'static str = \"{ptype}\"; }}")
    lines.append(f'#[doc = "{escape_doc(pdoc)}"] pub mod {pmod} {{')
    lines.append('    #[repr(C)]')
    lines.append('    #[doc = "Register block"] pub struct RegisterBlock {')
    cur = 0
    reserved = 0
    for r in regs:
        off = r["offset"]
        if off > cur:
            lines.append(f'        _reserved{reserved}: [u8; {off-cur}],')
            reserved += 1
        rn = snake(r["name"])
        rt = pascal(r["name"])
        lines.append(f'        {rn}: {rt},')
        size = parse_int(text(r["node"], "size"), 32) // 8
        cur = max(cur, off + max(size, 1))
    lines.append('    }')
    lines.append('    impl RegisterBlock {')
    for r in regs:
        rn = snake(r["name"])
        rt = pascal(r["name"])
        desc = text(r["node"], "description")
        lines.append(f'        #[doc = "{fmt_hex(r["offset"])} - {escape_doc(desc)}"] #[inline(always)] pub const fn {rn}(&self) -> &{rt} {{ &self.{rn} }}')
    lines.append('    }')
    for r in regs:
        rn = snake(r["name"])
        rt = pascal(r["name"])
        desc = text(r["node"], "description")
        alias = r["name"]
        acc = access_kind(r["node"])
        acc_text = {"r":"r", "w":"w", "rw":"rw"}[acc]
        lines.append(f'    #[doc = "{alias} ({acc_text}) register accessor: {escape_doc(desc)}"]')
        lines.append(f'    #[doc(alias = "{alias}")] pub type {rt} = crate::Reg<{rn}::{rt}Spec>;')
        lines.append(textwrap.indent(render_register_module(r), "    "))
    lines.append('}')
    return "\n".join(lines)

def render(device, args):
    name = text(device, "name", "DEVICE")
    nvic = text(child(device, "cpu") or ET.Element("x"), "nvicPrioBits", "")
    periph_root = child(device, "peripherals")
    peripherals = children(periph_root, "peripheral") if periph_root is not None else []
    shift = parse_int(args.base_address_shift, 0)
    out = []
    if not args.skip_crate_attributes and not args.make_mod:
        out.append(f'#![doc = "Peripheral access API for {escape_doc(name)} microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))"]')
        out.append('#![allow(non_camel_case_types)]')
        out.append('#![allow(non_snake_case)]')
        out.append('#![no_std]')
    if nvic:
        out.append(f'#[doc = r"Number available in the NVIC for configuring priority"] pub const NVIC_PRIO_BITS: u8 = {parse_int(nvic)};')
    if args.generic_mod:
        out.append('mod generic;')
        out.append('pub use generic::{BitReader, BitWriter, FieldReader, FieldWriter, Periph, PeripheralSpec, R, Readable, Reg, RegisterSpec, Resettable, W, Writable};')
    else:
        out.append(generic_code())
    interrupts = []
    for p in peripherals:
        for intr in children(p, "interrupt"):
            interrupts.append((text(intr, "name"), parse_int(text(intr, "value")), text(intr, "description")))
    out.append('#[derive(Copy, Clone, Debug, PartialEq, Eq)] pub enum Interrupt {')
    for nm, val, desc in sorted(interrupts, key=lambda x: x[1]):
        out.append(f'    #[doc = "{escape_doc(desc)}"] {pascal(nm)} = {val},')
    out.append('}')
    for p in peripherals:
        out.append(render_peripheral(p, shift, args.feature_peripheral))
    out.append('#[allow(non_snake_case)] pub struct Peripherals {')
    for p in peripherals:
        out.append(f'    #[doc = "{escape_doc(text(p, "description"))}"] pub {snake(text(p, "name"))}: {pascal(text(p, "name"))},')
    out.append('}')
    out.append('impl Peripherals { #[inline] pub unsafe fn steal() -> Self { Self {')
    for p in peripherals:
        pn = text(p, "name")
        out.append(f'    {snake(pn)}: {pascal(pn)}::steal(),')
    out.append('} } }')
    return "\n".join(out) + "\n"

def build_rs():
    return '#![doc = r" Builder file for Peripheral access crate generated by svd2rust tool"] fn main() { println!("cargo:rerun-if-changed=build.rs"); }\n'

def parse_args(argv):
    if "--help" in argv:
        print(LONG_HELP, end="")
        sys.exit(0)
    if "-h" in argv:
        print(SHORT_HELP, end="")
        sys.exit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        sys.exit(0)
    p = argparse.ArgumentParser(add_help=False, prog="executable")
    p.add_argument("-i", dest="input")
    p.add_argument("-o", "--output-dir", default=".")
    p.add_argument("-c", "--config")
    p.add_argument("--settings")
    p.add_argument("--edition")
    p.add_argument("--target")
    p.add_argument("--atomics", action="store_true")
    p.add_argument("--atomics-feature")
    p.add_argument("--ignore-groups", action="store_true")
    p.add_argument("--keep-list", action="store_true")
    p.add_argument("-g", "--generic-mod", action="store_true")
    p.add_argument("--feature-group", action="store_true")
    p.add_argument("--feature-peripheral", action="store_true")
    p.add_argument("-f", "--ident-format", action="append")
    p.add_argument("--ident-formats-theme")
    p.add_argument("--field-names-for-enums", action="store_true")
    p.add_argument("--max-cluster-size", action="store_true")
    p.add_argument("--impl-debug", action="store_true")
    p.add_argument("--impl-debug-feature")
    p.add_argument("--impl-defmt")
    p.add_argument("-m", "--make-mod", action="store_true")
    p.add_argument("--skip-crate-attributes", action="store_true")
    p.add_argument("-s", "--strict", action="store_true")
    p.add_argument("--source-type")
    p.add_argument("--reexport-core-peripherals", action="store_true")
    p.add_argument("--reexport-interrupt", action="store_true")
    p.add_argument("-b", "--base-address-shift", default="0")
    p.add_argument("-l", "--log")
    try:
        args, rest = p.parse_known_args(argv)
    except SystemExit:
        sys.exit(2)
    if rest:
        print(f"error: unexpected argument '{rest[0]}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", file=sys.stderr)
        sys.exit(2)
    return args

def main():
    args = parse_args(sys.argv[1:])
    try:
        if args.input:
            data = open(args.input, "rb").read()
        else:
            data = sys.stdin.buffer.read()
    except OSError as e:
        err("Cannot open the SVD file", str(e))
    log("INFO", "Parsing device from SVD file")
    try:
        root = ET.fromstring(data)
    except Exception as e:
        err("Error parsing SVD XML file", "the document does not have a root node" if not data.strip() else str(e))
    if local(root.tag) != "device":
        err("Error parsing SVD XML file", "missing field `device`")
    log("INFO", "Rendering device")
    try:
        os.makedirs(args.output_dir, exist_ok=False) if False else None
        main_name = "mod.rs" if args.make_mod else "lib.rs"
        with open(os.path.join(args.output_dir, main_name), "w", encoding="utf-8") as f:
            f.write(render(root, args))
        with open(os.path.join(args.output_dir, "build.rs"), "w", encoding="utf-8") as f:
            f.write(build_rs())
        with open(os.path.join(args.output_dir, "device.x"), "w", encoding="utf-8") as f:
            f.write("\n")
        if args.generic_mod:
            with open(os.path.join(args.output_dir, "generic.rs"), "w", encoding="utf-8") as f:
                f.write(generic_mod_code())
    except OSError as e:
        err("Error rendering device", str(e))

if __name__ == "__main__":
    main()
