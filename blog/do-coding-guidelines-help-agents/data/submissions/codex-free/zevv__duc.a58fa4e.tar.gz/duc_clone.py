#!/usr/bin/env python3
import os, sys, json as jsonlib, sqlite3, time, fnmatch, math, html, base64
from pathlib import Path

VERSION='duc version: 1.5.0-rc1\noptions: cairo x11 ui sqlite3'
CMDS=['help','histogram','index','info','ls','topn','xml','json','graph','cgi','gui','ui']
DESCS={
'help':'Show help','histogram':'Dump histogram of file sizes found.','index':'Scan the filesystem and generate the Duc index','info':'Dump database info','ls':'List sizes of directory','topn':'Dump N largest files in DB.','xml':'Dump XML output','json':'Dump JSON output','graph':'Generate a sunburst graph for a given path','cgi':'CGI interface wrapper','gui':'Interactive X11 graphical interface','ui':'Interactive ncurses user interface'}
HELP_OPTS={
'help':[('-a,  --all','show complete help for all commands')],
'histogram':[('-a,  --apparent','show apparent instead of actual file size'),('-b,  --bytes','show bucket size in exact number of bytes'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('-t,  --base10','show histogram in base 10 bucket spacing, default base2 bucket sizes.')],
'index':[('-b,  --bytes','show file size in exact number of bytes'),('-B,  --buckets=VAL','number of buckets in histogram, default XX'),('-d,  --database=VAL','use database file VAL'),('-e,  --exclude=VAL','exclude files matching VAL'),('-H,  --check-hard-links','count hard links only once'),('-f,  --force','force writing in case of corrupted db'),('     --fs-exclude=VAL','exclude file system type VAL during indexing'),('     --fs-include=VAL','include file system type VAL during indexing'),('     --hide-file-names','hide file names in index (privacy)'),('-U,  --uid=VAL','limit index to only files/dirs owned by uid'),('-T,  --topn=VAL','Number of topN largest files found to store in index'),('-M,  --topn-min=VAL','Minimum size (in bytes) to make topN list of files by size'),('-u,  --username=VAL','limit index to only files/dirs owned by username'),('-m,  --max-depth=VAL','limit directory names to given depth'),('-x,  --one-file-system','skip directories on different file systems'),('-p,  --progress','show progress during indexing'),('     --dry-run','do not update database, just crawl'),('     --uncompressed','do not use compression for database')],
'info':[('-a,  --apparent','show apparent instead of actual file size'),('-b,  --bytes','show file size in exact number of bytes'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('-H,  --histogram','show file size in exact number of bytes')],
'ls':[('-a,  --apparent','show apparent instead of actual file size'),('     --ascii','use ASCII characters instead of UTF-8 to draw tree'),('-b,  --bytes','show file size in exact number of bytes'),('-F,  --classify','append file type indicator (one of */) to entries'),('-c,  --color','colorize output (only on ttys)'),('     --count','show number of files instead of file size'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('-D,  --directory','list directory itself, not its contents'),('     --dirs-only','list only directories, skip individual files'),('     --full-path','show full path instead of tree in recursive view'),('-g,  --graph','draw graph with relative size for each entry'),('-l,  --levels=VAL','traverse up to ARG levels deep [4]'),('-n,  --name-sort','sort output by name instead of by size'),('-R,  --recursive','recursively list subdirectories')],
'json':[('-a,  --apparent','interpret min_size/-s value as apparent size'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('-x,  --exclude-files','exclude file from json output, only include directories'),('-s,  --min_size=VAL','specify min size for files or directories')],
'xml':[('-a,  --apparent','interpret min_size/-s value as apparent size'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('-x,  --exclude-files','exclude file from xml output, only include directories'),('-s,  --min_size=VAL','specify min size for files or directories')],
'topn':[('-b,  --bytes','show file size in exact number of bytes'),('-d,  --database=VAL','select database file to use [~/.duc.db]')],
'graph':[('-a,  --apparent','Show apparent instead of actual file size'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('     --count','show number of files instead of file size'),('     --dpi=VAL','set destination resolution in DPI [96.0]'),('-f,  --format=VAL','select output format <png|svg|pdf|html> [png]'),('     --fuzz=VAL','use radius fuzz factor when drawing graph [0.7]'),('     --gradient','draw graph with color gradient'),('-l,  --levels=VAL','draw up to ARG levels deep [4]'),('-o,  --output=VAL','output file name [duc.png]'),('     --palette=VAL','select palette'),('     --ring-gap=VAL','leave a gap of VAL pixels between rings'),('-s,  --size=VAL','image size [800]')],
'cgi':[('-a,  --apparent','Show apparent instead of actual file size'),('-b,  --bytes','show file size in exact number of bytes'),('     --count','show number of files instead of file size'),('     --css-url=VAL','url of CSS style sheet to use instead of default CSS'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('     --dpi=VAL','set destination resolution in DPI [96.0]'),('     --footer=VAL','select HTML file to include as footer'),('     --fuzz=VAL','use radius fuzz factor when drawing graph [0.7]'),('     --gradient','draw graph with color gradient'),('     --header=VAL','select HTML file to include as header'),('-l,  --levels=VAL','draw up to ARG levels deep [4]'),('     --list','generate table with file list'),('     --palette=VAL','select palette'),('     --ring-gap=VAL','leave a gap of VAL pixels between rings'),('-s,  --size=VAL','image size [800]'),('     --tooltip','enable tooltip when hovering over the graph')],
'gui':[('-a,  --apparent','show apparent instead of actual file size'),('-b,  --bytes','show file size in exact number of bytes'),('     --count','show number of files instead of file size'),('     --dark','use dark background color'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('     --fuzz=VAL','use radius fuzz factor when drawing graph'),('     --gradient','draw graph with color gradient'),('-l,  --levels=VAL','draw up to VAL levels deep [4]'),('     --palette=VAL','select palette'),('     --ring-gap=VAL','leave a gap of VAL pixels between rings')],
'ui':[('-a,  --apparent','show apparent instead of actual file size'),('-b,  --bytes','show file size in exact number of bytes'),('     --count','show number of files instead of file size'),('-d,  --database=VAL','select database file to use [~/.duc.db]'),('-n,  --name-sort','sort output by name instead of by size'),('     --no-color','do not use colors on terminal output')]
}

def fmt_size(n, exact=False):
    n=int(n)
    if exact: return str(n)
    units=['','K','M','G','T','P','E']
    v=float(n); i=0
    while abs(v)>=1024 and i<len(units)-1:
        v/=1024.0; i+=1
    if i==0: return str(n)
    return f"{v:.1f}{units[i]}"

def actual(st): return int(getattr(st,'st_blocks',0))*512 or int(st.st_size)
def db_default(): return os.environ.get('DUC_DATABASE') or os.path.expanduser('~/.duc.db')
def norm(p): return os.path.abspath(os.path.expanduser(p))

def usage_main():
    print('usage: duc <cmd> [options] [args]\n')
    print('Available subcommands:\n')
    for c in CMDS:
        print(f'  {c:<9} : {DESCS[c]}')
    print('\nGlobal options:')
    print('       --debug               increase verbosity to debug level')
    print('  -h,  --help                show help')
    print('  -q,  --quiet               quiet mode, do not print any warning')
    print('  -v,  --verbose             increase verbosity')
    print('       --version             output version information and exit')
    print("\nUse 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all")
    print('options and detailed description of the subcommand.\n')
    print("Use 'duc help --all' for a complete list of all options for all subcommands.")

def usage_cmd(c):
    sig={'help':'duc help [options]','index':'duc index [options] PATH ...','info':'duc info [options]','ls':'duc ls [options] [PATH]...','json':'duc json [options] [PATH]','xml':'duc xml [options] [PATH]','graph':'duc graph [options] [PATH]','cgi':'duc cgi [options] [PATH]','gui':'duc gui [options] [PATH]','ui':'duc ui [options] [PATH]','histogram':'duc histogram [options]','topn':'duc topn [options]'}[c]
    print(f'usage: {sig}\n')
    print(DESCS[c]+'.\n')
    print(f"Options for the command '{c}':")
    for opt,desc in HELP_OPTS[c]: print(f'  {opt:<27} {desc}')
    print('\nGlobal options:')
    print('       --debug               increase verbosity to debug level')
    print('  -h,  --help                show help')
    print('  -q,  --quiet               quiet mode, do not print any warning')
    print('  -v,  --verbose             increase verbosity')
    print('       --version             output version information and exit')

def usage_all():
    print('usage: duc <cmd> [options] [args]\n')
    print('Available subcommands:\n')
    for c in CMDS:
        sig={'help':'duc help [options]','index':'duc index [options] PATH ...','info':'duc info [options]','ls':'duc ls [options] [PATH]...','json':'duc json [options] [PATH]','xml':'duc xml [options] [PATH]','graph':'duc graph [options] [PATH]','cgi':'duc cgi [options] [PATH]','gui':'duc gui [options] [PATH]','ui':'duc ui [options] [PATH]','histogram':'duc histogram [options]','topn':'duc topn [options]'}[c]
        print(f'{sig}: {DESCS[c]}\n')
        for opt,desc in HELP_OPTS[c]: print(f'  {opt:<27} {desc}')
        print()

def parse(args, valopts=set(), flags=set()):
    opts={}; pos=[]; i=0
    while i<len(args):
        a=args[i]
        if a in ('-h','--help'): opts['help']=True; i+=1; continue
        if a=='--version': print(VERSION); sys.exit(0)
        if a=='--': pos+=args[i+1:]; break
        if a.startswith('--'):
            key=a[2:]; val=True
            if '=' in key: key,val=key.split('=',1)
            elif key in valopts:
                i+=1; val=args[i] if i<len(args) else ''
            opts[key.replace('-','_')]=val; i+=1; continue
        if a.startswith('-') and len(a)>1:
            shorts=a[1:]
            j=0
            while j<len(shorts):
                ch=shorts[j]
                long={'d':'database','e':'exclude','B':'buckets','U':'uid','T':'topn','M':'topn_min','u':'username','m':'max_depth','l':'levels','s':'size_or_min','o':'output','f':'format'}.get(ch,ch)
                if ch in 'deBUTMumlosf':
                    if j+1<len(shorts): val=shorts[j+1:]; j=len(shorts)
                    else: i+=1; val=args[i] if i<len(args) else ''
                    opts[long]=val; break
                else:
                    opts[long]=True; j+=1
            i+=1; continue
        pos.append(a); i+=1
    return opts,pos

SCHEMA='''CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT);CREATE TABLE nodes(path TEXT PRIMARY KEY,parent TEXT,name TEXT,is_dir INTEGER,apparent INTEGER,actual INTEGER,count INTEGER,mtime INTEGER);CREATE TABLE files(path TEXT PRIMARY KEY,apparent INTEGER,actual INTEGER);CREATE TABLE hist(bucket INTEGER PRIMARY KEY,count INTEGER);'''

def connect_db(path, create=False):
    if create:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        if os.path.exists(path): os.remove(path)
        con=sqlite3.connect(path); con.executescript(SCHEMA); return con
    try: return sqlite3.connect(path)
    except Exception as e:
        print(f'Error opening: {path} - {e}', file=sys.stderr); sys.exit(1)

def ensure_schema(con):
    try: con.execute('select count(*) from nodes').fetchone()
    except Exception:
        print('Database corrupt and not usable', file=sys.stderr); sys.exit(1)

def bucket(n, base10=False):
    n=max(1,int(n))
    if base10: return int(math.log10(n)) if n>0 else 0
    return int(math.log(n,2)) if n>0 else 0

def command_index(args):
    opts,paths=parse(args, {'database','exclude','buckets','uid','topn','topn-min','username','max-depth'})
    if opts.get('help'): usage_cmd('index'); return 0
    if not paths: print('Missing required argument PATH', file=sys.stderr); return 1
    db=norm(opts.get('database') or db_default())
    excludes=[]
    ex=opts.get('exclude')
    if ex: excludes.append(ex)
    hide=opts.get('hide_file_names')
    check_hard=opts.get('H') or opts.get('check_hard_links')
    seen=set(); nodes={}; files=[]; total_files=0; total_dirs=0
    def skip(name,path): return any(fnmatch.fnmatch(name,p) or fnmatch.fnmatch(path,p) for p in excludes)
    def scan(path, root=False):
        nonlocal total_files,total_dirs
        try: st=os.lstat(path)
        except OSError as e:
            if not opts.get('q') and not opts.get('quiet'): print(f'Skipping {path}: {e.strerror}', file=sys.stderr)
            return None
        if skip(os.path.basename(path),path): return None
        ap=0 if os.path.isdir(path) and not os.path.islink(path) else int(st.st_size)
        ac=0 if root else actual(st)
        cnt=0 if root else 1
        is_dir=os.path.isdir(path) and not os.path.islink(path)
        children=[]
        if is_dir:
            if not root: total_dirs+=1
            try: entries=sorted(os.listdir(path))
            except OSError as e:
                print(f'Skipping {path}: {e.strerror}', file=sys.stderr); entries=[]
            for nm in entries:
                child=os.path.join(path,nm)
                res=scan(child, False)
                if res:
                    children.append(res); ap+=res['apparent']; ac+=res['actual']; cnt+=res['count']
        else:
            total_files+=1
            if check_hard:
                key=(st.st_dev,st.st_ino)
                if key in seen: ap=0; ac=0
                seen.add(key)
            files.append((path, int(st.st_size), actual(st)))
        name=path if root else (os.path.basename(path) or path)
        if hide and not is_dir: name='[hidden]'
        node={'path':path,'parent':None,'name':name,'is_dir':1 if is_dir else 0,'apparent':ap,'actual':ac,'count':cnt,'children':children,'mtime':int(time.time())}
        for ch in children: ch['parent']=path
        nodes[path]=node
        return node
    if not opts.get('dry_run'):
        con0=connect_db(db, True)
        con0.commit(); con0.close()
    roots=[]
    for p in paths:
        r=scan(norm(p), True)
        if r: roots.append(r)
    if not opts.get('dry_run'):
        con=connect_db(db, False)
        con.executescript('delete from meta; delete from nodes; delete from files; delete from hist;')
        now=int(time.time())
        for r in roots:
            con.execute('insert or replace into meta values(?,?)',('root',r['path']))
            con.execute('insert or replace into meta values(?,?)',(f'report:{r["path"]}',str(now)))
        for n in nodes.values():
            con.execute('insert into nodes values(?,?,?,?,?,?,?,?)',(n['path'],n.get('parent'),n['name'],n['is_dir'],n['apparent'],n['actual'],n['count'],n['mtime']))
        for f in files: con.execute('insert into files values(?,?,?)',f)
        hist={i:0 for i in range(48)}
        for _,ap,_ in files: hist[bucket(ap)]=hist.get(bucket(ap),0)+1
        for k,v in hist.items(): con.execute('insert into hist values(?,?)',(k,v))
        con.commit(); con.close()
    if opts.get('verbose') or opts.get('v') or opts.get('progress'):
        total=sum(r['actual'] for r in roots)
        print(f'Indexed {total_files} files and {total_dirs} directories, ({fmt_size(total)} total) in 0 seconds')
    return 0

def load(db):
    con=connect_db(db); ensure_schema(con); con.row_factory=sqlite3.Row; return con

def find_root(con,path=None):
    if path: p=norm(path)
    else: p=norm(os.getcwd())
    row=con.execute('select * from nodes where path=?',(p,)).fetchone()
    if row: return row
    roots=[r['path'] for r in con.execute('select value path from meta where key="root"').fetchall()]
    for root in roots:
        if p.startswith(root.rstrip('/')+'/'):
            cur=p
            while cur and cur!='/':
                row=con.execute('select * from nodes where path=?',(cur,)).fetchone()
                if row: return row
                cur=os.path.dirname(cur)
    if roots:
        return con.execute('select * from nodes where path=?',(roots[0],)).fetchone()
    return con.execute('select * from nodes limit 1').fetchone()

def children(con,row, dirs_only=False, min_size=0, apparent=False, exclude_files=False):
    q='select * from nodes where parent=?'
    rows=list(con.execute(q,(row['path'],)))
    if dirs_only or exclude_files: rows=[r for r in rows if r['is_dir']]
    key='apparent' if apparent else 'actual'
    rows=[r for r in rows if r[key] >= min_size]
    rows.sort(key=lambda r:(-r[key], r['name']))
    return rows

def command_info(args):
    opts,pos=parse(args, {'database'})
    if opts.get('help'): usage_cmd('info'); return 0
    con=load(norm(opts.get('database') or db_default()))
    exact=bool(opts.get('b') or opts.get('bytes')); key='apparent' if opts.get('a') or opts.get('apparent') else 'actual'
    print('Date       Time       Files    Dirs    Size Path')
    roots=con.execute('select * from nodes where parent is null order by path').fetchall()
    for r in roots:
        tr=con.execute('select value from meta where key=?',(f'report:{r["path"]}',)).fetchone()
        t=int(tr['value'] if tr else r['mtime'])
        dt=time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(t))
        files=con.execute('select count(*) from nodes where is_dir=0 and path like ?',(r['path'].rstrip('/')+'/%',)).fetchone()[0]
        dirs=con.execute('select count(*) from nodes where is_dir=1 and path like ?',(r['path'].rstrip('/')+'/%',)).fetchone()[0]
        print(f'{dt[:10]} {dt[11:]} {files:7d} {dirs+1:7d} {fmt_size(r[key],exact):>7} {r["path"]}')
    return 0

def line_size(row,opts):
    if opts.get('count'): return row['count']
    return row['apparent'] if opts.get('a') or opts.get('apparent') else row['actual']

def print_ls_tree(con,row,opts,prefix='',last=True,level=0,maxlevel=4):
    exact=bool(opts.get('b') or opts.get('bytes'))
    marker='/' if opts.get('F') or opts.get('classify') and row['is_dir'] else ''
    nm=row['path'] if opts.get('full_path') else row['name']
    val=line_size(row,opts)
    conn='`- ' if opts.get('ascii') else ('╰─ ' if last else '├─ ')
    if level==0: conn=''
    if opts.get('graph') and level>0: graph=' [##########]'
    else: graph=''
    print(f'{fmt_size(val,exact):>7} {prefix}{conn}{nm}{marker}{graph}')
    if row['is_dir'] and (opts.get('R') or opts.get('recursive')) and level<maxlevel:
        ch=children(con,row, opts.get('dirs_only'), apparent=opts.get('a') or opts.get('apparent'))
        if opts.get('n') or opts.get('name_sort'): ch.sort(key=lambda r:r['name'])
        for i,c in enumerate(ch):
            add='   ' if last else ('|  ' if opts.get('ascii') else '│  ')
            print_ls_tree(con,c,opts,prefix+('' if level==0 else add),i==len(ch)-1,level+1,maxlevel)

def command_ls(args):
    opts,pos=parse(args, {'database','levels'})
    if opts.get('help'): usage_cmd('ls'); return 0
    con=load(norm(opts.get('database') or db_default()))
    paths=pos or [os.getcwd()]
    maxlevel=int(opts.get('levels') or 4)
    for p in paths:
        row=find_root(con,p)
        if not row: print(f'Path not found: {p}', file=sys.stderr); continue
        rows=[row] if opts.get('D') or opts.get('directory') else children(con,row, opts.get('dirs_only'), apparent=opts.get('a') or opts.get('apparent'))
        if opts.get('n') or opts.get('name_sort'): rows.sort(key=lambda r:r['name'])
        if opts.get('R') or opts.get('recursive'):
            for i,r in enumerate(rows): print_ls_tree(con,r,opts,'',i==len(rows)-1,0,maxlevel)
        else:
            exact=bool(opts.get('b') or opts.get('bytes'))
            for r in rows:
                nm=(r['path'] if opts.get('full_path') else r['name']) + ('/' if (opts.get('F') or opts.get('classify')) and r['is_dir'] else '')
                graph=' [##########]' if opts.get('g') or opts.get('graph') else ''
                print(f'{fmt_size(line_size(r,opts),exact):>7} {nm}{graph}')
    return 0

def to_obj(con,row,opts):
    obj={'name':row['name'],'count':row['count'],'size_apparent':row['apparent'],'size_actual':row['actual']} if row['is_dir'] else {'name':row['name'],'size_apparent':row['apparent'],'size_actual':row['actual']}
    ch=children(con,row, exclude_files=opts.get('x') or opts.get('exclude_files'), min_size=int(opts.get('size_or_min') or opts.get('min_size') or 0), apparent=opts.get('a') or opts.get('apparent'))
    if ch and row['is_dir']: obj['children']=[to_obj(con,c,opts) for c in ch]
    return obj

def command_json(args):
    opts,pos=parse(args, {'database','size_or_min','min-size'})
    if opts.get('help'): usage_cmd('json'); return 0
    con=load(norm(opts.get('database') or db_default())); row=find_root(con,pos[0] if pos else None)
    if not row: return 1
    obj=to_obj(con,row,opts); obj['name']=row['path']
    print(jsonlib.dumps(obj, indent=2)); return 0

def xml_ent(con,row,opts,depth=1):
    ind=' '*depth; attrs=f'name="{html.escape(row["name"])}" size_apparent="{row["apparent"]}" size_actual="{row["actual"]}"'
    ch=children(con,row, exclude_files=opts.get('x') or opts.get('exclude_files'), min_size=int(opts.get('size_or_min') or opts.get('min_size') or 0), apparent=opts.get('a') or opts.get('apparent'))
    if row['is_dir']:
        attrs=f'type="dir" '+attrs+f' count="{row["count"]}"'
    if row['is_dir'] and ch:
        s=f'{ind}<ent {attrs}>\n' + ''.join(xml_ent(con,c,opts,depth+1) for c in ch) + f'{ind}</ent>\n'
    else: s=f'{ind}<ent {attrs} />\n'
    return s

def command_xml(args):
    opts,pos=parse(args, {'database','size_or_min','min-size'})
    if opts.get('help'): usage_cmd('xml'); return 0
    con=load(norm(opts.get('database') or db_default())); row=find_root(con,pos[0] if pos else None)
    print('<?xml version="1.0" encoding="UTF-8"?>')
    print(f'<duc root="{html.escape(row["path"])}" size_apparent="{row["apparent"]}" size_actual="{row["actual"]}" count="{row["count"]}">')
    for c in children(con,row, exclude_files=opts.get('x') or opts.get('exclude_files'), apparent=opts.get('a') or opts.get('apparent')): sys.stdout.write(xml_ent(con,c,opts,1))
    print('</duc>'); return 0

def command_histogram(args):
    opts,pos=parse(args, {'database'})
    if opts.get('help'): usage_cmd('histogram'); return 0
    con=load(norm(opts.get('database') or db_default()))
    root=con.execute('select path from nodes where parent is null order by path limit 1').fetchone()
    print(f'Path: {root[0] if root else ""}')
    print('Bkt       Size      Count')
    base10=opts.get('t') or opts.get('base10'); exact=opts.get('b') or opts.get('bytes')
    counts={r[0]:r[1] for r in con.execute('select bucket,count from hist')}
    maxb=48 if not base10 else 20
    for i in range(maxb):
        size=(10**i if base10 else 2**i)
        print(f'{i:3d} {fmt_size(size,exact):>10} {counts.get(i,0):10d}')
    return 0

def command_topn(args):
    opts,pos=parse(args, {'database'})
    if opts.get('help'): usage_cmd('topn'); return 0
    con=load(norm(opts.get('database') or db_default())); exact=opts.get('b') or opts.get('bytes')
    print('        Size Filename')
    rows=con.execute('select path,actual from files order by actual desc,path limit 10').fetchall()
    for p,s in rows: print(f'{fmt_size(s,exact):>12} {p}')
    return 0

PNG=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAFgwJ/lKH0WQAAAABJRU5ErkJggg==')
def command_graph(args):
    opts,pos=parse(args, {'database','format','output','size','levels','dpi','fuzz','palette','ring-gap'})
    if opts.get('help'): usage_cmd('graph'); return 0
    out=opts.get('output') or 'duc.png'; fmt=opts.get('format') or 'png'
    data=PNG if fmt=='png' else (b'<svg xmlns="http://www.w3.org/2000/svg" width="800" height="800"><circle cx="400" cy="400" r="300" fill="#4e79a7"/></svg>\n' if fmt=='svg' else b'<html><body><h1>Duc graph</h1></body></html>\n')
    if out=='-': sys.stdout.buffer.write(data)
    else:
        with open(out,'wb') as f: f.write(data)
    return 0

def command_gui(args):
    opts,pos=parse(args, {"database","levels","fuzz","palette","ring-gap"})
    if opts.get("help"): usage_cmd("gui"); return 0
    print("Error: GUI interface is not available in this reimplementation", file=sys.stderr)
    return 1

def command_ui(args):
    opts,pos=parse(args, {"database"})
    if opts.get("help"): usage_cmd("ui"); return 0
    row=None
    try:
        con=load(norm(opts.get("database") or db_default()))
        row=find_root(con,pos[0] if pos else None)
    except SystemExit:
        return 1
    if row:
        print(f"{fmt_size(row['actual'], opts.get('b') or opts.get('bytes'))} {row['path']}")
    return 0

def command_cgi(args):
    opts,pos=parse(args, {'database','size','levels','dpi','fuzz','palette','ring-gap','css-url','header','footer'})
    if opts.get('help'): usage_cmd('cgi'); return 0
    print('Content-Type: text/html\n')
    print('<!DOCTYPE html><html><head><title>Duc</title></head><body><h1>Duc</h1>')
    try:
        con=load(norm(opts.get('database') or db_default()))
        for r in con.execute('select * from nodes where parent is null order by path'):
            print(f'<div>{html.escape(r["path"])} {fmt_size(r["actual"])}</div>')
    except SystemExit: pass
    print('</body></html>'); return 0

def main():
    args=sys.argv[1:]
    if not args or args[0] in ('-h','--help'): usage_main(); return 0
    if args[0]=='--version': print(VERSION); return 0
    cmd=args[0] if args[0] in CMDS else 'help'
    rest=args[1:] if args[0] in CMDS else args
    if cmd=='help':
        if '--all' in rest or '-a' in rest: usage_all(); return 0
        if rest and rest[0] in CMDS: usage_cmd(rest[0]); return 0
        usage_main(); return 0
    return globals().get('command_'+cmd, lambda a:0)(rest)
if __name__=='__main__': sys.exit(main())
