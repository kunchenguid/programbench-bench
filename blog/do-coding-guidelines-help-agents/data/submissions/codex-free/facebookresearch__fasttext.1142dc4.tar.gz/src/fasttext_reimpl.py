#!/usr/bin/env python3
import json
import math
import os
import random
import sys
from collections import Counter, defaultdict


VERSION = 1


MAIN_HELP = """usage: fasttext <command> <args>

The commands supported by fasttext are:

  supervised              train a supervised classifier
  quantize                quantize a model to reduce the memory usage
  test                    evaluate a supervised classifier
  test-label              print labels with precision and recall scores
  predict                 predict most likely labels
  predict-prob            predict most likely labels with probabilities
  skipgram                train a skipgram model
  cbow                    train a cbow model
  print-word-vectors      print word vectors given a trained model
  print-sentence-vectors  print sentence vectors given a trained model
  print-ngrams            print ngrams given a trained model and word
  nn                      query for nearest neighbors
  analogies               query for analogies
  dump                    dump arguments,dictionary,input/output vectors
"""


def train_help(kind, prefix="Empty input or output path."):
    supervised = kind == "supervised"
    min_count = 1 if supervised else 5
    minn = 0 if supervised else 3
    maxn = 0 if supervised else 6
    lr = "0.1" if supervised else "0.05"
    loss = "softmax" if supervised else "ns"
    return f"""{prefix}

The following arguments are mandatory:
  -input              training file path
  -output             output file path

The following arguments are optional:
  -verbose            verbosity level [2]

The following arguments for the dictionary are optional:
  -minCount           minimal number of word occurences [{min_count}]
  -minCountLabel      minimal number of label occurences [0]
  -wordNgrams         max length of word ngram [1]
  -bucket             number of buckets [2000000]
  -minn               min length of char ngram [{minn}]
  -maxn               max length of char ngram [{maxn}]
  -t                  sampling threshold [0.0001]
  -label              labels prefix [__label__]

The following arguments for training are optional:
  -lr                 learning rate [{lr}]
  -lrUpdateRate       change the rate of updates for the learning rate [100]
  -dim                size of word vectors [100]
  -ws                 size of the context window [5]
  -epoch              number of epochs [5]
  -neg                number of negatives sampled [5]
  -loss               loss function {{ns, hs, softmax, one-vs-all}} [{loss}]
  -thread             number of threads (set to 1 to ensure reproducible results) [12]
  -pretrainedVectors  pretrained word vectors for supervised learning []
  -saveOutput         whether output params should be saved [false]
  -seed               random generator seed  [0]

The following arguments are for autotune:
  -autotune-validation            validation file to be used for evaluation
  -autotune-metric                metric objective {{f1, f1:labelname}} [f1]
  -autotune-predictions           number of predictions used for evaluation  [1]
  -autotune-duration              maximum duration in seconds [300]
  -autotune-modelsize             constraint model file size [] (empty = do not quantize)

The following arguments for quantization are optional:
  -cutoff             number of words and ngrams to retain [0]
  -retrain            whether embeddings are finetuned if a cutoff is applied [false]
  -qnorm              whether the norm is quantized separately [false]
  -qout               whether the classifier is quantized [false]
  -dsub               size of each sub-vector [2]
"""


USAGE = {
    "predict": """usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename (if -, read from stdin)
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold
""",
    "test": """usage: fasttext test <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename (if -, read from stdin)
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold
""",
    "test-label": """usage: fasttext test-label <model> <test-data> [<k>] [<th>]

  <model>      model filename
  <test-data>  test data filename
  <k>          (optional; 1 by default) predict top k labels
  <th>         (optional; 0.0 by default) probability threshold
""",
    "dump": """usage: fasttext dump <model> <option>

  <model>      model filename
  <option>     option from args,dict,input,output
""",
    "print-word-vectors": """usage: fasttext print-word-vectors <model>

  <model>      model filename
""",
    "print-sentence-vectors": """usage: fasttext print-sentence-vectors <model>

  <model>      model filename
""",
    "print-ngrams": """usage: fasttext print-ngrams <model> <word>

  <model>      model filename
  <word>       word to print
""",
    "nn": """usage: fasttext nn <model> <k>

  <model>      model filename
  <k>          (optional; 10 by default) predict top k labels
""",
    "analogies": """usage: fasttext analogies <model> <k>

  <model>      model filename
  <k>          (optional; 10 by default) predict top k labels
""",
}


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse_opts(argv, mode):
    supervised = mode == "supervised"
    opts = {
        "input": "",
        "output": "",
        "verbose": "2",
        "minCount": "1" if supervised else "5",
        "minCountLabel": "0",
        "wordNgrams": "1",
        "bucket": "2000000",
        "minn": "0" if supervised else "3",
        "maxn": "0" if supervised else "6",
        "t": "0.0001",
        "label": "__label__",
        "lr": "0.1" if supervised else "0.05",
        "lrUpdateRate": "100",
        "dim": "100",
        "ws": "5",
        "epoch": "5",
        "neg": "5",
        "loss": "softmax" if supervised else "ns",
        "thread": "12",
        "pretrainedVectors": "",
        "saveOutput": "false",
        "seed": "0",
        "cutoff": "0",
        "retrain": "false",
        "qnorm": "false",
        "qout": "false",
        "dsub": "2",
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if not a.startswith("-"):
            die(f"Unknown argument: {a}")
        key = a[1:]
        if key in opts or key.startswith("autotune-"):
            if i + 1 >= len(argv):
                die(f"Missing value for argument: {a}")
            opts[key] = argv[i + 1]
            i += 2
        else:
            die(f"Unknown argument: {a}")
    return opts


def tokenize(text, label_prefix="__label__"):
    words = []
    labels = []
    for tok in text.strip().split():
        if tok.startswith(label_prefix):
            labels.append(tok)
        else:
            words.append(tok)
    return labels, words


def word_ngrams(words, maxn):
    if maxn <= 1:
        return list(words)
    out = list(words)
    for n in range(2, maxn + 1):
        for i in range(0, max(0, len(words) - n + 1)):
            out.append("_".join(words[i:i + n]))
    return out


def stable_vec(word, dim):
    rnd = random.Random(2166136261)
    h = 2166136261
    for ch in word:
        h ^= ord(ch)
        h = (h * 16777619) & 0xffffffff
    rnd.seed(h)
    vals = [rnd.uniform(-0.5, 0.5) / max(1, dim) for _ in range(dim)]
    norm = math.sqrt(sum(v * v for v in vals)) or 1.0
    return [v / norm for v in vals]


def fmt(x):
    if abs(x) < 0.0000005:
        x = 0.0
    return f"{x:.6f}"


def save_model(path, model):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(model, f, separators=(",", ":"), sort_keys=True)


def load_model(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            model = json.load(f)
    except Exception:
        die(f"{path} has wrong file format!")
    if not isinstance(model, dict) or model.get("format") != "fasttext-reimplementation":
        die(f"{path} has wrong file format!")
    return model


def open_input(path):
    if path == "-":
        return sys.stdin
    return open(path, "r", encoding="utf-8", errors="replace")


def train(mode, argv):
    opts = parse_opts(argv, mode)
    if not opts.get("input") or not opts.get("output"):
        print(train_help(mode), end="", file=sys.stderr)
        return 1
    label_prefix = opts.get("label", "__label__")
    dim = int(opts.get("dim", "100"))
    max_word_ngrams = int(opts.get("wordNgrams", "1"))
    min_count = int(opts.get("minCount", "1" if mode == "supervised" else "5"))
    min_count_label = int(opts.get("minCountLabel", "0"))
    lines = []
    vocab = Counter()
    label_counts = Counter()
    label_word_counts = defaultdict(Counter)
    try:
        with open(opts["input"], "r", encoding="utf-8", errors="replace") as f:
            for raw in f:
                labels, words = tokenize(raw, label_prefix)
                feats = word_ngrams(words, max_word_ngrams)
                for w in words:
                    vocab[w] += 1
                if mode == "supervised":
                    for lab in labels:
                        label_counts[lab] += 1
                        label_word_counts[lab].update(feats)
                lines.append({"labels": labels, "words": words})
    except OSError as e:
        die(str(e))
    vocab = Counter({w: c for w, c in vocab.items() if c >= min_count})
    label_counts = Counter({l: c for l, c in label_counts.items() if c >= min_count_label})
    model = {
        "format": "fasttext-reimplementation",
        "version": VERSION,
        "model": mode,
        "args": opts,
        "dim": dim,
        "label_prefix": label_prefix,
        "vocab": dict(vocab),
        "labels": dict(label_counts),
        "label_words": {k: dict(v) for k, v in label_word_counts.items() if k in label_counts},
    }
    save_model(opts["output"] + ".bin", model)
    with open(opts["output"] + ".vec", "w", encoding="utf-8") as f:
        words = sorted(vocab)
        f.write(f"{len(words)} {dim}\n")
        for w in words:
            f.write(w + " " + " ".join(fmt(x) for x in stable_vec(w, dim)) + "\n")
    return 0


def predict_scores(model, words):
    labels = model.get("labels", {})
    if not labels:
        return []
    feats = word_ngrams(words, int(model.get("args", {}).get("wordNgrams", "1")))
    vocab_size = max(1, len(model.get("vocab", {})))
    total_docs = sum(labels.values()) or 1
    raw = []
    for lab, cnt in labels.items():
        wc = Counter(model.get("label_words", {}).get(lab, {}))
        denom = sum(wc.values()) + vocab_size
        score = math.log((cnt + 1.0) / (total_docs + len(labels)))
        for w in feats:
            score += math.log((wc.get(w, 0) + 1.0) / denom)
        raw.append((lab, score))
    m = max(s for _, s in raw)
    probs = [(l, math.exp(s - m)) for l, s in raw]
    z = sum(p for _, p in probs) or 1.0
    return sorted([(l, p / z) for l, p in probs], key=lambda x: (-x[1], x[0]))


def cmd_predict(name, argv):
    if len(argv) < 2:
        print(USAGE["predict"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    k = int(argv[2]) if len(argv) > 2 else 1
    th = float(argv[3]) if len(argv) > 3 else 0.0
    with open_input(argv[1]) as f:
        for line in f:
            labels, words = tokenize(line, model.get("label_prefix", "__label__"))
            del labels
            preds = [(l, p) for l, p in predict_scores(model, words) if p >= th][:k]
            if name == "predict-prob":
                print(" ".join(f"{l} {p:.6f}" for l, p in preds))
            else:
                print(" ".join(l for l, _ in preds))
    return 0


def cmd_test(argv, by_label=False):
    if len(argv) < 2:
        print(USAGE["test-label" if by_label else "test"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    k = int(argv[2]) if len(argv) > 2 else 1
    th = float(argv[3]) if len(argv) > 3 else 0.0
    n = 0
    pred_count = 0
    truth_count = 0
    correct = 0
    per = defaultdict(lambda: [0, 0, 0])
    with open_input(argv[1]) as f:
        for line in f:
            labs, words = tokenize(line, model.get("label_prefix", "__label__"))
            if not labs:
                continue
            preds = [(l, p) for l, p in predict_scores(model, words) if p >= th][:k]
            ps = [l for l, _ in preds]
            n += 1
            pred_count += len(ps)
            truth_count += len(labs)
            for p in ps:
                per[p][1] += 1
            for l in labs:
                per[l][2] += 1
            for p in ps:
                if p in labs:
                    correct += 1
                    per[p][0] += 1
    if by_label:
        if not per:
            print("F1-Score : 0.000000  Precision : 0.000000  Recall : 0.000000")
        for lab in sorted(per):
            c, pc, tc = per[lab]
            p = c / pc if pc else 0.0
            r = c / tc if tc else 0.0
            f1 = 2 * p * r / (p + r) if p + r else 0.0
            print(f"{lab} : F1-Score : {f1:.6f}  Precision : {p:.6f}  Recall : {r:.6f}")
    else:
        p = correct / pred_count if pred_count else float("nan")
        r = correct / truth_count if truth_count else float("nan")
        print(f"N\t{n}")
        print(f"P@{k}\t{p:.3f}")
        print(f"R@{k}\t{r:.3f}")
    return 0


def get_word_vec(model, word):
    return stable_vec(word, int(model.get("dim", 100)))


def cmd_print_word_vectors(argv):
    if len(argv) < 1:
        print(USAGE["print-word-vectors"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    for line in sys.stdin:
        for word in line.strip().split():
            v = get_word_vec(model, word)
            print(word + " " + " ".join(fmt(x) for x in v))
    return 0


def cmd_print_sentence_vectors(argv):
    if len(argv) < 1:
        print(USAGE["print-sentence-vectors"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    dim = int(model.get("dim", 100))
    for line in sys.stdin:
        words = line.strip().split()
        vec = [0.0] * dim
        if words:
            for w in words:
                for i, x in enumerate(get_word_vec(model, w)):
                    vec[i] += x
            vec = [x / len(words) for x in vec]
        print(" ".join(fmt(x) for x in vec))
    return 0


def subwords(word, minn, maxn):
    wrapped = "<" + word + ">"
    out = [word]
    for n in range(minn, maxn + 1):
        for i in range(0, max(0, len(wrapped) - n + 1)):
            out.append(wrapped[i:i + n])
    return out


def cmd_print_ngrams(argv):
    if len(argv) < 2:
        print(USAGE["print-ngrams"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    args = model.get("args", {})
    for ng in subwords(argv[1], int(args.get("minn", 3)), int(args.get("maxn", 6))):
        print(ng)
    return 0


def cosine(a, b):
    da = math.sqrt(sum(x * x for x in a)) or 1.0
    db = math.sqrt(sum(x * x for x in b)) or 1.0
    return sum(x * y for x, y in zip(a, b)) / (da * db)


def nearest(model, vec, k):
    words = sorted(model.get("vocab", {}) or {})
    scored = [(w, cosine(vec, get_word_vec(model, w))) for w in words]
    return sorted(scored, key=lambda x: (-x[1], x[0]))[:k]


def cmd_nn(argv):
    if len(argv) < 1:
        print(USAGE["nn"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    k = int(argv[1]) if len(argv) > 1 else 10
    for line in sys.stdin:
        q = line.strip().split()
        if not q:
            continue
        for w, s in nearest(model, get_word_vec(model, q[0]), k):
            print(f"{w} {s:.6f}")
    return 0


def cmd_analogies(argv):
    if len(argv) < 1:
        print(USAGE["analogies"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    k = int(argv[1]) if len(argv) > 1 else 10
    for line in sys.stdin:
        q = line.strip().split()
        if len(q) < 3:
            continue
        a, b, c = (get_word_vec(model, x) for x in q[:3])
        target = [bb - aa + cc for aa, bb, cc in zip(a, b, c)]
        for w, s in nearest(model, target, k):
            if w not in q[:3]:
                print(f"{w} {s:.6f}")
    return 0


def cmd_dump(argv):
    if len(argv) < 2:
        print(USAGE["dump"], end="", file=sys.stderr)
        return 1
    model = load_model(argv[0])
    opt = argv[1]
    if opt == "args":
        for k in sorted(model.get("args", {})):
            print(f"{k} {model['args'][k]}")
    elif opt == "dict":
        for w, c in sorted(model.get("vocab", {}).items(), key=lambda x: (-x[1], x[0])):
            print(f"{w} {c}")
        for l, c in sorted(model.get("labels", {}).items(), key=lambda x: (-x[1], x[0])):
            print(f"{l} {c}")
    elif opt in ("input", "output"):
        for w in sorted(model.get("vocab", {})):
            print(w + " " + " ".join(fmt(x) for x in get_word_vec(model, w)))
    else:
        die("Unknown option for dump.")
    return 0


def cmd_quantize(argv):
    opts = parse_opts(argv, "skipgram")
    if not opts.get("input") or not opts.get("output"):
        print(train_help("skipgram", "usage: fasttext quantize <args>"), end="", file=sys.stderr)
        return 1
    model = load_model(opts["input"])
    model["quantized"] = True
    model["args"].update(opts)
    save_model(opts["output"] + ".ftz", model)
    return 0


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(MAIN_HELP, end="")
        return 0
    cmd = argv[0]
    rest = argv[1:]
    if cmd in ("supervised", "skipgram", "cbow"):
        return train(cmd, rest)
    if cmd == "quantize":
        return cmd_quantize(rest)
    if cmd in ("predict", "predict-prob"):
        return cmd_predict(cmd, rest)
    if cmd == "test":
        return cmd_test(rest)
    if cmd == "test-label":
        return cmd_test(rest, True)
    if cmd == "print-word-vectors":
        return cmd_print_word_vectors(rest)
    if cmd == "print-sentence-vectors":
        return cmd_print_sentence_vectors(rest)
    if cmd == "print-ngrams":
        return cmd_print_ngrams(rest)
    if cmd == "nn":
        return cmd_nn(rest)
    if cmd == "analogies":
        return cmd_analogies(rest)
    if cmd == "dump":
        return cmd_dump(rest)
    print(MAIN_HELP, end="", file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
