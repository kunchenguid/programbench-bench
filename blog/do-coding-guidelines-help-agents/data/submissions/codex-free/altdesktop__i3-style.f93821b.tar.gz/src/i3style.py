#!/usr/bin/env python3
import os, sys, re, shutil, time

THEME_DESCS = [
("slate", "Slate theme by Jody Ribton <jody@ribton.me>"),
("alphare", "A beige theme by Alphare"),
("ubuntu", "Ubuntu theme by lasers"),
("flat-gray", "flat gray based theme"),
("purple", "Purple theme by AAlakkad <http://aalakkad.me>"),
("archlinux", "Archlinux theme by okraits <http://okraits.de>"),
("default", "Default theme for i3wm <http://i3wm.org>"),
("debian", "Debian theme by lasers"),
("oceanic-next", "Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)"),
("base16-tomorrow", "Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)"),
("okraits", "A simple theme by okraits <http://okraits.de>"),
("icelines", "icelines theme by mbfraga"),
("solarized", "Solarized theme by lasers"),
("deep-purple", "Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>"),
("tomorrow-night-80s", "Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>"),
("seti", "seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui"),
("lime", "Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>"),
("gruvbox", "Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>"),
("mate", "Theme for blending i3 into MATE"),
]

def T(bar, clients): return {"bar": bar, "client": clients}
THEMES = {
"slate": T({"separator":"#586e75","background":"#002b36","statusline":"#aea79f","focused_workspace":["#586e75","#586e75","#ffffff"],"active_workspace":["#073642","#073642","#ffffff"],"inactive_workspace":["#002b36","#002b36","#aea79f"],"urgent_workspace":["#77216f","#77216f","#ffffff"]},{"focused":["#586e75","#586e75","#fdf6e3","#268bd2"],"focused_inactive":["#073642","#073642","#93a1a1","#002b36"],"unfocused":["#002b36","#002b36","#586e75","#002b36"],"urgent":["#dc322f","#dc322f","#fdf6e3","#dc322f"]}),
"alphare": T({"separator":"#000000","background":"#FDF6E3","statusline":"#002B36","focused_workspace":["#000000","#268BD2","#FFFFFF"],"active_workspace":["#333333","#222222","#FFFFFF"],"inactive_workspace":["#333333","#222222","#888888"],"urgent_workspace":["#2F343A","#900000","#FFFFFF"]},{"focused":["#000000","#FDF6E3","#002B36","#000000"],"focused_inactive":["#000000","#5F676A","#FDF6E3","#484E50"],"unfocused":["#000000","#000000","#FDF6E3","#000000"],"urgent":["#000000","#DC322F","#FDF6E3","#DC322F"]}),
"ubuntu": T({"separator":"#333333","background":"#2c001e","statusline":"#aea79f","focused_workspace":["#dd4814","#dd4814","#ffffff"],"active_workspace":["#902a07","#902a07","#aea79f"],"inactive_workspace":["#902a07","#902a07","#aea79f"],"urgent_workspace":["#77216f","#77216f","#ffffff"]},{"focused":["#dd4814","#dd4814","#ffffff","#902a07"],"focused_inactive":["#5e2750","#5e2750","#aea79f","#5e2750"],"unfocused":["#5e2750","#5e2750","#aea79f","#5e2750"],"urgent":["#77216f","#77216f","#ffffff","#efb73e"]}),
"flat-gray": T({"background":"#333333","statusline":"#AAAAAA","focused_workspace":["#282828","#282828","#FFFFFF"],"inactive_workspace":["#333333","#333333","#AAAAAA"]},{"focused":["#000000","#000000","#FFFFFF","#000000"],"focused_inactive":["#333333","#333333","#FFFFFF","#000000"],"unfocused":["#333333","#333333","#FFFFFF","#333333"]}),
"purple": T({"separator":"#AAAAAA","background":"#222133","statusline":"#FFFFFF","focused_workspace":["#664477","#664477","#cccccc"],"active_workspace":["#DCCD69","#DCCD69","#181715"],"inactive_workspace":["#222133","#222133","#AAAAAA"],"urgent_workspace":["#CE4045","#CE4045","#FFFFFF"]},{"focused":["#664477","#664477","#cccccc","#e7d8b1"],"focused_inactive":["#e7d8b1","#e7d8b1","#181715","#A074C4"],"unfocused":["#222133","#222133","#AAAAAA","#A074C4"],"urgent":["#CE4045","#CE4045","#e7d8b1","#DCCD69"]}),
"archlinux": T({"separator":"#666666","background":"#222222","statusline":"#dddddd","focused_workspace":["#0088CC","#0088CC","#ffffff"],"active_workspace":["#333333","#333333","#ffffff"],"inactive_workspace":["#333333","#333333","#888888"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},{"focused":["#0088CC","#0088CC","#ffffff","#dddddd"],"focused_inactive":["#333333","#333333","#888888","#292d2e"],"unfocused":["#333333","#333333","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
"default": T({"separator":"#666666","background":"#000000","statusline":"#ffffff","focused_workspace":["#4c7899","#285577","#ffffff"],"active_workspace":["#333333","#5f676a","#ffffff"],"inactive_workspace":["#333333","#222222","#888888"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},{"focused":["#4c7899","#285577","#ffffff","#2e9ef4"],"focused_inactive":["#333333","#5f676a","#ffffff","#484e50"],"unfocused":["#333333","#222222","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
"debian": T({"separator":"#444444","background":"#222222","statusline":"#666666","focused_workspace":["#d70a53","#d70a53","#ffffff"],"active_workspace":["#333333","#333333","#888888"],"inactive_workspace":["#333333","#333333","#888888"],"urgent_workspace":["#eb709b","#eb709b","#ffffff"]},{"focused":["#d70a53","#d70a53","#ffffff","#8c0333"],"focused_inactive":["#333333","#333333","#888888","#333333"],"unfocused":["#333333","#333333","#888888","#333333"],"urgent":["#eb709b","#eb709b","#ffffff","#eb709b"]}),
"oceanic-next": T({"separator":"#65737E","background":"#1B2B34","statusline":"#D8DEE9","focused_workspace":["#6699CC","#6699CC","#1B2B34"],"active_workspace":["#5FB3B3","#5FB3B3","#1B2B34"],"inactive_workspace":["#343D46","#343D46","#D8DEE9"],"urgent_workspace":["#EC5f67","#EC5f67","#1B2B34"]},{"focused":["#6699CC","#6699CC","#1B2B34","#6699CC"],"focused_inactive":["#5FB3B3","#5FB3B3","#D8DEE9","#A7ADBA"],"unfocused":["#343D46","#343D46","#D8DEE9","#343D46"],"urgent":["#EC5f67","#EC5f67","#1B2B34","#EC5f67"]}),
"base16-tomorrow": T({"separator":"#969896","background":"#1d1f21","statusline":"#c5c8c6","focused_workspace":["#81a2be","#81a2be","#1d1f21"],"active_workspace":["#373b41","#373b41","#ffffff"],"inactive_workspace":["#282a2e","#282a2e","#969896"],"urgent_workspace":["#cc6666","#cc6666","#ffffff"]},{"focused":["#81a2be","#81a2be","#1d1f21","#282a2e"],"focused_inactive":["#373b41","#373b41","#969896","#282a2e"],"unfocused":["#282a2e","#282a2e","#969896","#282a2e"],"urgent":["#373b41","#cc6666","#ffffff","#cc6666"]}),
"okraits": T({"separator":"#666666","background":"#333333","statusline":"#bbbbbb","focused_workspace":["#888888","#dddddd","#222222"],"active_workspace":["#333333","#555555","#bbbbbb"],"inactive_workspace":["#333333","#555555","#bbbbbb"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},{"focused":["#888888","#dddddd","#222222","#2e9ef4"],"focused_inactive":["#333333","#555555","#bbbbbb","#484e50"],"unfocused":["#333333","#333333","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
"icelines": T({"separator":"#7d7d7d","background":"#141414","statusline":"#00b0ef","focused_workspace":["#00b0ef","#141414","#00b0ef"],"active_workspace":["#141414","#141414","#00b0ef"],"inactive_workspace":["#141414","#141414","#7d7d7d"],"urgent_workspace":["#ff7066","#141414","#ff7066"]},{"focused":["#00b0ef","#00b0ef","#141414","#ff7066"],"focused_inactive":["#141414","#141414","#00b0ef","#472b2a"],"unfocused":["#141414","#141414","#7d7d7d","#141414"],"urgent":["#ff7066","#ff7066","#141414","#ff7066"]}),
"solarized": T({"separator":"#dc322f","background":"#002b36","statusline":"#268bd2","focused_workspace":["#fdf6e3","#859900","#fdf6e3"],"active_workspace":["#fdf6e3","#6c71c4","#fdf6e3"],"inactive_workspace":["#586e75","#93a1a1","#002b36"],"urgent_workspace":["#d33682","#d33682","#fdf6e3"]},{"focused":["#859900","#859900","#fdf6e3","#6c71c4"],"focused_inactive":["#073642","#073642","#eee8d5","#6c71c4"],"unfocused":["#073642","#073642","#93a1a1","#586e75"],"urgent":["#d33682","#d33682","#fdf6e3","#dc322f"]}),
"deep-purple": T({"separator":"#666666","background":"#000000","statusline":"#ffffff","focused_workspace":["#551a8b","#551a8b","#ffffff"],"active_workspace":["#333333","#5f676a","#ffffff"],"inactive_workspace":["#000000","#000000","#888888"],"urgent_workspace":["#2f343a","#900000","#ffffff"]},{"focused":["#3b1261","#3b1261","#ffffff","#662b9c"],"focused_inactive":["#333333","#5f676a","#ffffff","#484e50"],"unfocused":["#222222","#222222","#888888","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
"tomorrow-night-80s": T({"separator":"#515151","background":"#2d2d2d","statusline":"#cccccc","focused_workspace":["#99cc99","#99cc99","#000000"],"active_workspace":["#333333","#333333","#ffffff"],"inactive_workspace":["#2d2d2d","#2d2d2d","#999999"],"urgent_workspace":["#f2777a","#f2777a","#ffffff"]},{"focused":["#99cc99","#99cc99","#000000","#2d2d2d"],"focused_inactive":["#393939","#393939","#888888","#292d2e"],"unfocused":["#2d2d2d","#2d2d2d","#999999","#292d2e"],"urgent":["#2f343a","#900000","#ffffff","#900000"]}),
"seti": T({"separator":"#AAAAAA","background":"#1f2326","statusline":"#FFFFFF","focused_workspace":["#9FCA56","#9FCA56","#151718"],"active_workspace":["#DCCD69","#DCCD69","#151718"],"inactive_workspace":["#1f2326","#1f2326","#AAAAAA"],"urgent_workspace":["#CE4045","#CE4045","#FFFFFF"]},{"focused":["#4F99D3","#4F99D3","#151718","#9FCA56"],"focused_inactive":["#9FCA56","#9FCA56","#151718","#A074C4"],"unfocused":["#1f2326","#1f2326","#AAAAAA","#A074C4"],"urgent":["#CE4045","#CE4045","#FFFFFF","#DCCD69"]}),
"lime": T({"separator":"#888888","background":"#333333","statusline":"#FFFFFF","focused_workspace":["#4E9C00","#4E9C00","#FFFFFF"],"active_workspace":["#333333","#333333","#FFFFFF"],"inactive_workspace":["#333333","#333333","#888888"],"urgent_workspace":["#C20000","#C20000","#FFFFFF"]},{"focused":["#4E9C00","#4E9C00","#FFFFFF","#FFFFFF"],"focused_inactive":["#1B3600","#1B3600","#888888","#FFFFFF"],"unfocused":["#333333","#333333","#888888","#FFFFFF"],"urgent":["#C20000","#C20000","#FFFFFF","#FFFFFF"]}),
"gruvbox": T({"separator":"#928374","background":"#282828","statusline":"#ebdbb2","focused_workspace":["#689d6a","#689d6a","#282828"],"active_workspace":["#1d2021","#1d2021","#928374"],"inactive_workspace":["#32302f","#32302f","#928374"],"urgent_workspace":["#cc241d","#cc241d","#ebdbb2"]},{"focused":["#689d6a","#689d6a","#282828","#282828"],"focused_inactive":["#1d2021","#1d2021","#928374","#282828"],"unfocused":["#32302f","#32302f","#928374","#282828"],"urgent":["#cc241d","#cc241d","#ebdbb2","#282828"]}),
"mate": T({"separator":"#ffffff","background":"#3c3b37","statusline":"#ffffff","focused_workspace":["#526532","#526532","#ffffff"],"active_workspace":["#aea79f","#aea79f","#3c3b37"],"inactive_workspace":["#3c3b37","#3c3b37","#aea79f"],"urgent_workspace":["#FF0000","#FF0000","#ffffff"]},{"focused":["#526532","#526532","#ffffff","#a4cb64"],"focused_inactive":["#aea79f","#aea79f","#3c3b37","#aea79f"],"unfocused":["#3c3b37","#3c3b37","#aea79f","#3c3b37"],"urgent":["#FF0000","#FF0000","#ffffff","#FF0000"]}),
}

HELP = """i3-style 1.0
Make your i3 config a bit more stylish

USAGE:
    executable [FLAGS] [OPTIONS] [theme]

FLAGS:
    -h, --help        Prints help information
    -l, --list-all    Print a list of all available themes
    -r, --reload      Apply the theme by reloading the config
    -s, --save        Set the output file to the path of the input file
    -V, --version     Prints version information

OPTIONS:
    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.
    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>
    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others
                             [default: ]

ARGS:
    <theme>    The theme to use
"""

def list_all():
    print("\nAvailable themes:\n")
    for n,d in THEME_DESCS:
        print(f"  {n:<18} - {d}")

def parse_args(argv):
    opts={"list":False,"reload":False,"save":False,"config":None,"output":None,"to_theme":None,"theme":None}
    i=0
    while i < len(argv):
        a=argv[i]
        if a in ("-h","--help"): print(HELP, end=""); sys.exit(0)
        if a in ("-V","--version"): print("i3-style 1.0"); sys.exit(0)
        if a in ("-l","--list-all"): opts["list"]=True; i+=1; continue
        if a in ("-r","--reload"): opts["reload"]=True; i+=1; continue
        if a in ("-s","--save"): opts["save"]=True; i+=1; continue
        if a in ("-c","--config","-o","--output","-t","--to-theme"):
            if i+1>=len(argv): print(f"error: The argument '{a} <file>' requires a value", file=sys.stderr); sys.exit(1)
            key={"-c":"config","--config":"config","-o":"output","--output":"output","-t":"to_theme","--to-theme":"to_theme"}[a]
            opts[key]=argv[i+1]; i+=2; continue
        if a.startswith("--config="): opts["config"]=a.split("=",1)[1]; i+=1; continue
        if a.startswith("--output="): opts["output"]=a.split("=",1)[1]; i+=1; continue
        if a.startswith("--to-theme="): opts["to_theme"]=a.split("=",1)[1]; i+=1; continue
        if opts["theme"] is None: opts["theme"]=a; i+=1; continue
        print(f"error: Found argument '{a}' which wasn't expected", file=sys.stderr); sys.exit(1)
    return opts

def default_config():
    home=os.path.expanduser("~")
    for p in (os.path.join(home,'.config/i3/config'), os.path.join(home,'.i3/config')):
        if os.path.exists(p): return p
    return os.path.join(home,'.config/i3/config')

def colors_block(bar):
    order=["separator","background","statusline","focused_workspace","active_workspace","inactive_workspace","urgent_workspace"]
    out=["  colors {\n"]
    for k in order:
        if k not in bar: continue
        v=bar[k]
        if isinstance(v, list): out.append(f"    {k} {v[0]} {v[1]} {v[2]}\n")
        else: out.append(f"    {k} {v}\n")
    out.append("  }\n")
    return out

def client_lines(client):
    order=["focused","focused_inactive","unfocused","urgent"]
    return [f"client.{k} {' '.join(client[k])}\n" for k in order if k in client]

def skip_block(lines, i):
    depth=lines[i].count('{')-lines[i].count('}')
    i+=1
    while i<len(lines) and depth>0:
        depth += lines[i].count('{')-lines[i].count('}')
        i+=1
    return i

def apply_theme_text(text, theme):
    lines=text.splitlines(True)
    lines=[ln for ln in lines if not re.match(r'^\s*client\.(focused|focused_inactive|unfocused|urgent)\b', ln)]
    out=[]; i=0; inserted=False
    while i<len(lines):
        ln=lines[i]
        if re.match(r'^\s*bar\s*{', ln):
            out.append(ln); i+=1; depth=1; pending=[]
            while i<len(lines) and depth>0:
                cur=lines[i]
                if re.match(r'^\s*colors\s*{', cur):
                    i=skip_block(lines,i); continue
                nd=depth + cur.count('{') - cur.count('}')
                if depth==1 and cur.strip()=='}':
                    out.extend(colors_block(theme['bar'])); out.append(cur); inserted=True; i+=1; depth=nd; break
                out.append(cur); i+=1; depth=nd
            continue
        out.append(ln); i+=1
    if not inserted:
        if out and not out[-1].endswith('\n'): out[-1]+='\n'
        out.extend(["bar {\n"]+colors_block(theme['bar'])+["}\n"])
    if out and out[-1].strip():
        pass
    out.extend(client_lines(theme['client']))
    return ''.join(out)

def unquote(v):
    v=v.strip()
    if '#' in v and not v.lstrip().startswith(('"#',"'#")):
        v=v.split('#',1)[0].strip()
    return v.strip('"\'')

def load_theme(path_or_name):
    if path_or_name in THEMES: return THEMES[path_or_name]
    if not path_or_name or not os.path.exists(path_or_name):
        print("Could not find i3 config", file=sys.stderr); sys.exit(1)
    return parse_theme_file(open(path_or_name).read())

def parse_theme_file(s):
    colors={}; bar={}; client={}; section=None; current=None
    for raw in s.splitlines():
        if not raw.strip() or raw.lstrip().startswith('#') or raw.strip()=='---': continue
        indent=len(raw)-len(raw.lstrip(' ')); line=raw.strip()
        if indent==0 and line.endswith(':'):
            section=line[:-1]; current=None; continue
        if section=='colors' and indent==2 and ':' in line:
            k,v=line.split(':',1); colors[k.strip()]=unquote(v); continue
        if section in ('window_colors','client','bar_colors','bar'):
            if indent==2 and line.endswith(':'):
                current=line[:-1]; continue
            if ':' in line:
                k,v=line.split(':',1); key=k.strip(); val=unquote(v); val=colors.get(val,val)
                target = client if section in ('window_colors','client') else bar
                names4=['border','background','text','indicator']; names3=['border','background','text']
                if current:
                    arr=target.setdefault(current, [None]*(4 if section in ('window_colors','client') else 3))
                    names=names4 if section in ('window_colors','client') else names3
                    if key in names: arr[names.index(key)]=val
                else:
                    target[key]=val
    for d in (bar, client):
        for k,v in list(d.items()):
            if isinstance(v,list): d[k]=[x or '#000000' for x in v]
    return {"bar":bar,"client":client}

def extract_theme_text(text):
    # Generate a simple shareable theme from colors found in an i3 config.
    vals={}
    for line in text.splitlines():
        parts=line.split()
        if not parts: continue
        if parts[0].startswith('client.') and len(parts)>=5:
            vals[parts[0]]=parts[1:5]
        elif parts[0] in ('separator','background','statusline') and len(parts)>=2:
            vals['bar.'+parts[0]]=[parts[1]]
        elif parts[0].endswith('_workspace') and len(parts)>=4:
            vals['bar.'+parts[0]]=parts[1:4]
    print('---')
    print('meta:')
    print('  description: AUTOMATICALLY GENERATED THEME')
    print('window_colors:')
    for k in ['focused','focused_inactive','unfocused','urgent']:
        a=vals.get('client.'+k)
        if a:
            print(f'  {k}:\n    border: "{a[0]}"\n    background: "{a[1]}"\n    text: "{a[2]}"\n    indicator: "{a[3]}"')
    print('bar_colors:')
    for k in ['background','statusline','separator']:
        a=vals.get('bar.'+k)
        if a: print(f'  {k}: "{a[0]}"')
    for k in ['focused_workspace','active_workspace','inactive_workspace','urgent_workspace']:
        a=vals.get('bar.'+k)
        if a: print(f'  {k}:\n    border: "{a[0]}"\n    background: "{a[1]}"\n    text: "{a[2]}"')

def main():
    opts=parse_args(sys.argv[1:])
    if opts['list']:
        list_all(); return
    cfg=opts['config'] or default_config()
    if opts['to_theme'] is not None:
        if not os.path.exists(opts['to_theme']): print('Could not find i3 config', file=sys.stderr); sys.exit(1)
        extract_theme_text(open(opts['to_theme']).read()); return
    if not opts['theme']:
        print('USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n')
        print('Select a theme as the first argument. Use `--list-all` to see the themes.')
        sys.exit(1)
    if not os.path.exists(cfg): print('Could not find i3 config', file=sys.stderr); sys.exit(1)
    theme=load_theme(opts['theme'])
    result=apply_theme_text(open(cfg).read(), theme)
    out=opts['output'] or (cfg if opts['save'] else None)
    if out:
        if opts['save']:
            backup=f"/tmp/i3-style/{int(time.time())}/config-input"; os.makedirs(os.path.dirname(backup), exist_ok=True)
            try: shutil.copyfile(cfg, backup); print(f"saving config at {cfg} to {backup}")
            except Exception: pass
        os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
        open(out,'w').write(result)
    else:
        print(result, end='')
    if opts['reload']:
        os.system('i3-msg reload >/dev/null 2>&1')
if __name__=='__main__': main()
