package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"io/fs"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

const version = "3.0.0-20260303205914-9926ea38658f"

type options struct {
	applyGenerated bool
	company        string
	excludes       string
	filePath       string
	format         bool
	order          string
	listDiff       bool
	local          string
	output         string
	project        string
	recursive      bool
	rmUnused       bool
	separateNamed  bool
	setAlias       bool
	setExitStatus  bool
	useCache       bool
	version        bool
	versionOnly    bool
}

type imp struct {
	Alias   string
	Path    string
	Comment string
	Group   string
	Named   bool
}

var stdPkgs = map[string]bool{}

func init() {
	for _, p := range strings.Fields(`archive/tar archive/zip bufio bytes cmp compress/bzip2 compress/flate compress/gzip compress/lzw compress/zlib container/heap container/list container/ring context crypto crypto/aes crypto/cipher crypto/des crypto/dsa crypto/ecdh crypto/ecdsa crypto/ed25519 crypto/elliptic crypto/hmac crypto/md5 crypto/rand crypto/rc4 crypto/rsa crypto/sha1 crypto/sha256 crypto/sha512 crypto/subtle crypto/tls crypto/x509 crypto/x509/pkix database/sql database/sql/driver debug/buildinfo debug/dwarf debug/elf debug/gosym debug/macho debug/pe debug/plan9obj embed encoding encoding/ascii85 encoding/asn1 encoding/base32 encoding/base64 encoding/binary encoding/csv encoding/gob encoding/hex encoding/json encoding/pem encoding/xml errors expvar flag fmt go/ast go/build go/build/constraint go/constant go/doc go/doc/comment go/format go/importer go/parser go/printer go/scanner go/token go/types hash hash/adler32 hash/crc32 hash/crc64 hash/fnv hash/maphash html html/template image image/color image/color/palette image/draw image/gif image/jpeg image/png index/suffixarray io io/fs iter log log/slog math math/big math/bits math/cmplx math/rand math/rand/v2 mime mime/multipart mime/quotedprintable net net/http net/http/cgi net/http/cookiejar net/http/fcgi net/http/httptest net/http/httptrace net/http/httputil net/http/pprof net/mail net/netip net/rpc net/rpc/jsonrpc net/smtp net/textproto net/url os os/exec os/signal os/user path path/filepath plugin reflect regexp regexp/syntax runtime runtime/cgo runtime/coverage runtime/debug runtime/metrics runtime/pprof runtime/race runtime/trace slices sort strconv strings struct util sync sync/atomic syscall testing testing/fstest testing/iotest testing/quick text/scanner text/tabwriter text/template text/template/parse time unicode unicode/utf16 unicode/utf8 unsafe unique weak`) {
		stdPkgs[p] = true
	}
}

func main() {
	log.SetFlags(log.LstdFlags)
	var o options
	flag.BoolVar(&o.applyGenerated, "apply-to-generated-files", false, "Apply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.")
	flag.StringVar(&o.company, "company-prefixes", "", "Company package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.")
	flag.StringVar(&o.excludes, "excludes", "", "Exclude files or dirs, example: '.git/,proto/*.go'.")
	flag.StringVar(&o.filePath, "file-path", "", "Deprecated. Put file name as an argument(last item) of command line.")
	flag.BoolVar(&o.format, "format", false, "Option will perform additional formatting. Optional parameter.")
	flag.StringVar(&o.order, "imports-order", "std,general,company,project", "Your imports groups can be sorted in your way. \nstd - std import group; \ngeneral - libs for general purpose; \ncompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); \nproject - your local project dependencies;\nblanked - imports with \"_\" alias;\ndotted - imports with \".\" alias.\nOptional parameter.")
	flag.BoolVar(&o.listDiff, "list-diff", false, "Option will list files whose formatting differs from goimports-reviser. Optional parameter.")
	flag.StringVar(&o.local, "local", "", "Deprecated")
	flag.StringVar(&o.output, "output", "file", "Can be \"file\", \"write\" or \"stdout\". Whether to write the formatted content back to the file or to stdout. When \"write\" together with \"-list-diff\" will list the file name and write back to the file. Optional parameter.")
	flag.StringVar(&o.project, "project-name", "", "Your project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.")
	flag.BoolVar(&o.recursive, "recursive", false, "Apply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.")
	flag.BoolVar(&o.rmUnused, "rm-unused", false, "Remove unused imports. Optional parameter.")
	flag.BoolVar(&o.separateNamed, "separate-named", false, "Option will separate named imports from the rest of the imports, per group. Optional parameter.")
	flag.BoolVar(&o.setAlias, "set-alias", false, "Set alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg \"github.com/go-pg/pg/v9\"'. Optional parameter.")
	flag.BoolVar(&o.setExitStatus, "set-exit-status", false, "set the exit status to 1 if a change is needed/made. Optional parameter.")
	flag.BoolVar(&o.useCache, "use-cache", false, "Use cache to improve performance. Optional parameter.")
	flag.BoolVar(&o.version, "version", false, "Show version information")
	flag.BoolVar(&o.versionOnly, "version-only", false, "Show only the version string")
	flag.Parse()

	if o.versionOnly {
		fmt.Println(version)
		return
	}
	if o.version {
		fmt.Printf("version: %s\nbuilt with: go1.26.0\ntag: v%s\ncommit: n/a\nsource: github.com/incu6us/goimports-reviser/v3\n", version, version)
		return
	}

	targets := flag.Args()
	if o.filePath != "" {
		targets = append(targets, o.filePath)
	}
	if len(targets) == 0 {
		flag.Usage()
		log.Fatal("no file(s) or directory(ies) specified on input")
	}
	if o.project == "" {
		o.project = findModuleName(".")
	}
	files, err := collectFiles(targets, o)
	if err != nil {
		flag.Usage()
		log.Fatal(err)
	}
	log.Printf("Paths: %v", targets)
	changed := false
	for _, p := range files {
		log.Printf("Processing %s", p)
		ok, err := processFile(p, o)
		if err != nil {
			flag.Usage()
			log.Fatal(err)
		}
		changed = changed || ok
	}
	if changed && o.setExitStatus {
		os.Exit(1)
	}
}

func collectFiles(targets []string, o options) ([]string, error) {
	var out []string
	for _, t := range targets {
		recur := o.recursive
		if strings.HasSuffix(t, "/...") {
			t = strings.TrimSuffix(t, "/...")
			if t == "." {
				t = "."
			}
			recur = true
		}
		info, err := os.Stat(t)
		if err != nil {
			return nil, err
		}
		if !info.IsDir() {
			if strings.HasSuffix(t, ".go") && !isExcluded(t, o.excludes) {
				out = append(out, t)
			}
			continue
		}
		if recur {
			filepath.WalkDir(t, func(path string, d fs.DirEntry, err error) error {
				if err != nil {
					return nil
				}
				if d.IsDir() && (d.Name() == ".git" || isExcluded(path+"/", o.excludes)) {
					return filepath.SkipDir
				}
				if !d.IsDir() && strings.HasSuffix(path, ".go") && !isExcluded(path, o.excludes) {
					out = append(out, path)
				}
				return nil
			})
		}
	}
	sort.Strings(out)
	return out, nil
}

func isExcluded(path, patterns string) bool {
	for _, p := range strings.Split(patterns, ",") {
		p = strings.TrimSpace(p)
		if p == "" {
			continue
		}
		if strings.HasSuffix(p, "/") && strings.Contains(path, strings.TrimSuffix(p, "/")) {
			return true
		}
		if ok, _ := filepath.Match(p, path); ok {
			return true
		}
		if ok, _ := filepath.Match(p, filepath.Base(path)); ok {
			return true
		}
	}
	return false
}

func findModuleName(start string) string {
	dir, _ := filepath.Abs(start)
	for {
		b, err := os.ReadFile(filepath.Join(dir, "go.mod"))
		if err == nil {
			for _, line := range strings.Split(string(b), "\n") {
				f := strings.Fields(line)
				if len(f) >= 2 && f[0] == "module" {
					return f[1]
				}
			}
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return ""
		}
		dir = parent
	}
}

func processFile(path string, o options) (bool, error) {
	src, err := os.ReadFile(path)
	if err != nil {
		return false, err
	}
	if isGenerated(src) && !o.applyGenerated {
		if o.output == "stdout" {
			os.Stdout.Write(src)
		}
		return false, nil
	}
	if o.project == "" {
		return false, fmt.Errorf("Could not determine project name for path %s: open go.mod: no such file or directory", path)
	}
	newSrc, err := revise(src, o)
	if err != nil {
		return false, fmt.Errorf("Failed to fix file: err: %v", err)
	}
	diff := !bytes.Equal(src, newSrc)
	if o.listDiff && diff {
		fmt.Println(path)
	}
	switch o.output {
	case "stdout":
		os.Stdout.Write(newSrc)
	case "write", "file", "":
		if diff && (!o.listDiff || o.output == "write" || o.output == "file") {
			err = os.WriteFile(path, newSrc, 0644)
		}
	default:
		err = fmt.Errorf("unsupported output: %s", o.output)
	}
	return diff, err
}

func isGenerated(src []byte) bool {
	s := strings.TrimLeft(string(src), "\ufeff \t\r\n")
	return strings.HasPrefix(s, "// Code generated")
}

func revise(src []byte, o options) ([]byte, error) {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "", src, parser.ParseComments)
	if err != nil {
		return nil, err
	}
	imports := extractImports(file, o)
	if o.rmUnused {
		used := usedIdentifiers(file)
		var kept []imp
		for _, im := range imports {
			name := importName(im)
			if im.Alias == "_" || im.Alias == "." || used[name] {
				kept = append(kept, im)
			}
		}
		imports = kept
	}
	if o.setAlias {
		for i := range imports {
			if imports[i].Alias == "" {
				if a := versionAlias(imports[i].Path); a != "" {
					imports[i].Alias = a
					imports[i].Named = true
				}
			}
		}
	}
	for i := range imports {
		imports[i].Group = classify(imports[i], o)
	}
	formatted, err := format.Source(src)
	if err != nil {
		formatted = src
	}
	return replaceImportBlock(formatted, imports, o)
}

func extractImports(file *ast.File, o options) []imp {
	var imports []imp
	for _, s := range file.Imports {
		p, _ := strconv.Unquote(s.Path.Value)
		im := imp{Path: p}
		if s.Name != nil {
			im.Alias = s.Name.Name
			im.Named = im.Alias != "_" && im.Alias != "."
		}
		if s.Comment != nil {
			var parts []string
			for _, c := range s.Comment.List {
				parts = append(parts, strings.TrimSpace(c.Text))
			}
			im.Comment = strings.Join(parts, " ")
		}
		imports = append(imports, im)
	}
	return imports
}

func usedIdentifiers(file *ast.File) map[string]bool {
	used := map[string]bool{}
	ast.Inspect(file, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.ImportSpec:
			return false
		case *ast.SelectorExpr:
			if id, ok := x.X.(*ast.Ident); ok {
				used[id.Name] = true
			}
		case *ast.Ident:
			used[x.Name] = true
		}
		return true
	})
	return used
}

func importName(im imp) string {
	if im.Alias != "" && im.Alias != "_" && im.Alias != "." {
		return im.Alias
	}
	base := pathBase(im.Path)
	if regexp.MustCompile(`^v[0-9]+$`).MatchString(base) {
		parts := strings.Split(im.Path, "/")
		if len(parts) > 1 {
			base = parts[len(parts)-2]
		}
	}
	return sanitizeIdent(base)
}

func versionAlias(path string) string {
	parts := strings.Split(path, "/")
	if len(parts) < 2 {
		return ""
	}
	if regexp.MustCompile(`^v[0-9]+$`).MatchString(parts[len(parts)-1]) {
		return sanitizeIdent(parts[len(parts)-2])
	}
	return ""
}

func pathBase(p string) string {
	parts := strings.Split(p, "/")
	return parts[len(parts)-1]
}

func sanitizeIdent(s string) string {
	s = strings.ReplaceAll(s, "-", "")
	s = strings.ReplaceAll(s, ".", "")
	return s
}

func classify(im imp, o options) string {
	if im.Alias == "_" {
		return "blanked"
	}
	if im.Alias == "." {
		return "dotted"
	}
	if stdPkgs[im.Path] {
		return "std"
	}
	for _, p := range strings.Split(o.company, ",") {
		p = strings.TrimSpace(p)
		if p != "" && strings.HasPrefix(im.Path, p) {
			return "company"
		}
	}
	if o.project != "" && strings.HasPrefix(im.Path, o.project) {
		return "project"
	}
	return "general"
}

func replaceImportBlock(src []byte, imports []imp, o options) ([]byte, error) {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, "", src, parser.ParseComments)
	if err != nil {
		return nil, err
	}
	var decl *ast.GenDecl
	for _, d := range file.Decls {
		if gd, ok := d.(*ast.GenDecl); ok && gd.Tok == token.IMPORT {
			decl = gd
			break
		}
	}
	block := buildImportBlock(imports, o)
	if decl == nil {
		if len(imports) == 0 {
			return src, nil
		}
		insert := fset.Position(file.Name.End()).Offset
		var out []byte
		out = append(out, src[:insert]...)
		out = append(out, "\n\n"...)
		out = append(out, block...)
		out = append(out, src[insert:]...)
		return out, nil
	}
	start := fset.Position(decl.Pos()).Offset
	end := fset.Position(decl.End()).Offset
	if len(imports) == 0 {
		for end < len(src) && (src[end] == '\n' || src[end] == '\r') {
			end++
			if end < len(src) && src[end-1] == '\n' && src[end] == '\n' {
				end++
				break
			}
		}
		return append(src[:start], src[end:]...), nil
	}
	out := append([]byte{}, src[:start]...)
	out = append(out, block...)
	out = append(out, src[end:]...)
	return out, nil
}

func buildImportBlock(imports []imp, o options) []byte {
	sort.SliceStable(imports, func(i, j int) bool {
		if imports[i].Path == imports[j].Path {
			return imports[i].Alias < imports[j].Alias
		}
		return imports[i].Path < imports[j].Path
	})
	order := []string{}
	seen := map[string]bool{}
	for _, g := range strings.Split(o.order, ",") {
		g = strings.TrimSpace(g)
		if g != "" {
			order = append(order, g)
			seen[g] = true
		}
	}
	for _, g := range []string{"std", "general", "company", "project", "blanked", "dotted"} {
		if !seen[g] {
			order = append(order, g)
		}
	}
	var groups [][]imp
	for _, g := range order {
		var normal, named []imp
		for _, im := range imports {
			if im.Group == g {
				if o.separateNamed && im.Named {
					named = append(named, im)
				} else {
					normal = append(normal, im)
				}
			}
		}
		if len(normal) > 0 {
			groups = append(groups, normal)
		}
		if len(named) > 0 {
			groups = append(groups, named)
		}
	}
	if len(imports) == 1 {
		return []byte("import " + importLine(imports[0], false) + "\n")
	}
	var b strings.Builder
	b.WriteString("import (\n")
	for gi, group := range groups {
		if gi > 0 {
			b.WriteByte('\n')
		}
		for _, im := range group {
			b.WriteString("\t")
			b.WriteString(importLine(im, true))
			b.WriteByte('\n')
		}
	}
	b.WriteString(")")
	return []byte(b.String())
}

func importLine(im imp, inBlock bool) string {
	var b strings.Builder
	if im.Alias != "" {
		b.WriteString(im.Alias)
		b.WriteByte(' ')
	}
	b.WriteString(strconv.Quote(im.Path))
	if im.Comment != "" {
		b.WriteByte(' ')
		b.WriteString(im.Comment)
	}
	return b.String()
}
