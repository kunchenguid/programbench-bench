#!/usr/bin/env python3
import argparse
import fnmatch
import json
import os
import re
import stat
import sys
import select

VERSION = """ripgrep 14.1.1 (rev 719e15af5e)
Andrew Gallant <jamslam@gmail.com>"""

SHORT_HELP = VERSION + """

ripgrep (rg) recursively searches the current directory for lines matching
a regex pattern. By default, ripgrep will respect gitignore rules and
automatically skip hidden files/directories and binary files.

Use -h for short descriptions and --help for more details.

Project home page: https://github.com/BurntSushi/ripgrep

USAGE:
  rg [OPTIONS] PATTERN [PATH ...]

INPUT OPTIONS:
  -e, --regexp=PATTERN            A pattern to search for.
  -f, --file=PATTERNFILE          Search for patterns from the given file.
  -z, --search-zip                Search in compressed files.

SEARCH OPTIONS:
  -s, --case-sensitive            Search case sensitively (default).
  -F, --fixed-strings             Treat all patterns as literals.
  -i, --ignore-case               Case insensitive search.
  -v, --invert-match              Invert matching.
  -x, --line-regexp               Show matches surrounded by line boundaries.
  -m, --max-count=NUM             Limit the number of matching lines.
  -P, --pcre2                     Enable PCRE2 matching.
  -S, --smart-case                Smart case search.
  -a, --text                      Search binary files as if they were text.
  -w, --word-regexp               Show matches surrounded by word boundaries.

FILTER OPTIONS:
  --binary                        Search binary files.
  -L, --follow                    Follow symbolic links.
  -g, --glob=GLOB                 Include or exclude file paths.
  -., --hidden                    Search hidden files and directories.
  -d, --max-depth=NUM             Descend at most NUM directories.
  --no-ignore                     Don't use ignore files.
  -t, --type=TYPE                 Only search files matching TYPE.
  -T, --type-not=TYPE             Do not search files matching TYPE.
  -u, --unrestricted              Reduce the level of "smart" filtering.

OUTPUT OPTIONS:
  -A, --after-context=NUM         Show NUM lines after each match.
  -B, --before-context=NUM        Show NUM lines before each match.
  -b, --byte-offset               Print the byte offset for each matching line.
  --column                        Show column numbers.
  -C, --context=NUM               Show NUM lines before and after each match.
  --heading                       Print matches grouped by each file.
  -h, --help                      Show help output.
  -n, --line-number               Show line numbers.
  -N, --no-line-number            Suppress line numbers.
  -0, --null                      Print a NUL byte after file paths.
  -o, --only-matching             Print only matched parts of a line.
  -p, --pretty                    Alias for colors, headings and line numbers.
  -q, --quiet                     Do not print anything to stdout.
  -r, --replace=TEXT              Replace matches with the given text.
  --sort=SORTBY                   Sort results in ascending order.
  --trim                          Trim prefix whitespace from matches.
  --vimgrep                       Print results in a vim compatible format.
  -H, --with-filename             Print the file path with each matching line.
  -I, --no-filename               Never print the path with each matching line.

OUTPUT MODES:
  -c, --count                     Show count of matching lines for each file.
  --count-matches                 Show count of every match for each file.
  -l, --files-with-matches        Print the paths with at least one match.
  --files-without-match           Print the paths that contain zero matches.
  --json                          Show search results in a JSON Lines format.

OTHER BEHAVIORS:
  --files                         Print each file that would be searched.
  --pcre2-version                 Print the version of PCRE2 that ripgrep uses.
  --type-list                     Show all supported file types.
  -V, --version                   Print ripgrep's version.
"""

TYPE_GLOBS = {
    "c": ["*.c", "*.h"],
    "cpp": ["*.cpp", "*.cc", "*.cxx", "*.hpp", "*.hh", "*.hxx"],
    "go": ["*.go"],
    "html": ["*.html", "*.htm"],
    "java": ["*.java"],
    "js": ["*.js", "*.jsx", "*.mjs", "*.cjs"],
    "json": ["*.json"],
    "md": ["*.md", "*.markdown"],
    "py": ["*.py", "*.pyw"],
    "python": ["*.py", "*.pyw"],
    "rs": ["*.rs"],
    "rust": ["*.rs"],
    "sh": ["*.sh", "*.bash", "*.zsh"],
    "toml": ["*.toml"],
    "ts": ["*.ts", "*.tsx"],
    "txt": ["*.txt", "*.text"],
    "xml": ["*.xml"],
    "yaml": ["*.yaml", "*.yml"],
}

STDIN_CACHE = None


def expand_short_args(argv):
    out = []
    takes_value = set("efmABCdjEMrg")
    for arg in argv:
        if arg.startswith("-") and not arg.startswith("--") and len(arg) > 2:
            body = arg[1:]
            if body and all(ch == "u" for ch in body):
                out.extend(["-u"] * len(body))
            elif body and body[0] in takes_value and len(body) > 1:
                out.append("-" + body[0])
                out.append(body[1:])
            elif all(ch in "inNclHoFwsvUahILpqu0." for ch in body):
                out.extend(["-" + ch for ch in body])
            else:
                out.append(arg)
        else:
            out.append(arg)
    return out


def parse(argv):
    p = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("--type-list", action="store_true")
    p.add_argument("--pcre2-version", action="store_true")
    p.add_argument("--files", action="store_true")
    p.add_argument("--generate")
    p.add_argument("-e", "--regexp", action="append", dest="patterns")
    p.add_argument("-f", "--file", action="append", dest="pattern_files")
    p.add_argument("-i", "--ignore-case", action="store_true")
    p.add_argument("-s", "--case-sensitive", action="store_true")
    p.add_argument("-S", "--smart-case", action="store_true")
    p.add_argument("-F", "--fixed-strings", action="store_true")
    p.add_argument("-w", "--word-regexp", action="store_true")
    p.add_argument("-x", "--line-regexp", action="store_true")
    p.add_argument("-v", "--invert-match", action="store_true")
    p.add_argument("-m", "--max-count", type=int)
    p.add_argument("-U", "--multiline", action="store_true")
    p.add_argument("--multiline-dotall", action="store_true")
    p.add_argument("-P", "--pcre2", action="store_true")
    p.add_argument("--engine")
    p.add_argument("-a", "--text", action="store_true")
    p.add_argument("--binary", action="store_true")
    p.add_argument("-u", "--unrestricted", action="count", default=0)
    p.add_argument("-.", "--hidden", action="store_true")
    p.add_argument("--no-ignore", action="store_true")
    p.add_argument("--no-require-git", action="store_true")
    p.add_argument("-L", "--follow", action="store_true")
    p.add_argument("-g", "--glob", action="append", dest="globs")
    p.add_argument("--iglob", action="append", dest="iglobs")
    p.add_argument("-t", "--type", action="append", dest="types")
    p.add_argument("-T", "--type-not", action="append", dest="not_types")
    p.add_argument("--type-add", action="append")
    p.add_argument("-d", "--max-depth", type=int)
    p.add_argument("--max-filesize")
    p.add_argument("-n", "--line-number", action="store_true")
    p.add_argument("-N", "--no-line-number", action="store_true")
    p.add_argument("-H", "--with-filename", action="store_true")
    p.add_argument("-I", "--no-filename", action="store_true")
    p.add_argument("-o", "--only-matching", action="store_true")
    p.add_argument("-c", "--count", action="store_true")
    p.add_argument("--count-matches", action="store_true")
    p.add_argument("-l", "--files-with-matches", action="store_true")
    p.add_argument("--files-without-match", action="store_true")
    p.add_argument("-q", "--quiet", action="store_true")
    p.add_argument("-A", "--after-context", type=int, default=0)
    p.add_argument("-B", "--before-context", type=int, default=0)
    p.add_argument("-C", "--context", type=int)
    p.add_argument("--context-separator", default="--")
    p.add_argument("--field-match-separator", default=":")
    p.add_argument("--field-context-separator", default="-")
    p.add_argument("-b", "--byte-offset", action="store_true")
    p.add_argument("--column", action="store_true")
    p.add_argument("-0", "--null", action="store_true", dest="nul")
    p.add_argument("--json", action="store_true")
    p.add_argument("--color", default="never")
    p.add_argument("--colors", action="append")
    p.add_argument("--heading", action="store_true")
    p.add_argument("--vimgrep", action="store_true")
    p.add_argument("--passthru", action="store_true")
    p.add_argument("-p", "--pretty", action="store_true")
    p.add_argument("-r", "--replace")
    p.add_argument("--trim", action="store_true")
    p.add_argument("--sort")
    p.add_argument("--sortr")
    p.add_argument("--sort-files", action="store_true")
    p.add_argument("--stats", action="store_true")
    p.add_argument("--debug", action="store_true")
    p.add_argument("--no-messages", action="store_true")
    p.add_argument("--no-ignore-messages", action="store_true")
    p.add_argument("--pre")
    p.add_argument("--pre-glob", action="append")
    p.add_argument("-z", "--search-zip", action="store_true")
    p.add_argument("--crlf", action="store_true")
    p.add_argument("--null-data", action="store_true")
    p.add_argument("-E", "--encoding", default="utf-8")
    p.add_argument("-j", "--threads")
    p.add_argument("--mmap", action="store_true")
    p.add_argument("--dfa-size-limit")
    p.add_argument("--regex-size-limit")
    p.add_argument("--max-columns", type=int)
    p.add_argument("--max-columns-preview", action="store_true")
    p.add_argument("--block-buffered", action="store_true")
    p.add_argument("--line-buffered", action="store_true")
    p.add_argument("--include-zero", action="store_true")
    p.add_argument("--path-separator")
    p.add_argument("--glob-case-insensitive", action="store_true")
    p.add_argument("--ignore-file", action="append")
    p.add_argument("--ignore-file-case-insensitive", action="store_true")
    p.add_argument("--no-ignore-dot", action="store_true")
    p.add_argument("--no-ignore-exclude", action="store_true")
    p.add_argument("--no-ignore-files", action="store_true")
    p.add_argument("--no-ignore-global", action="store_true")
    p.add_argument("--no-ignore-parent", action="store_true")
    p.add_argument("--no-ignore-vcs", action="store_true")
    p.add_argument("--one-file-system", action="store_true")
    p.add_argument("--auto-hybrid-regex", action="store_true")
    p.add_argument("--no-pcre2-unicode", action="store_true")
    p.add_argument("--no-unicode", action="store_true")
    p.add_argument("--stop-on-nonmatch", action="store_true")
    p.add_argument("rest", nargs="*")
    return p.parse_args(expand_short_args(argv))


def load_patterns(ns):
    pats = list(ns.patterns or [])
    for pf in ns.pattern_files or []:
        try:
            if pf == "-":
                lines = sys.stdin.read().splitlines()
            else:
                with open(pf, "r", encoding="utf-8", errors="replace") as f:
                    lines = f.read().splitlines()
            pats.extend(lines)
        except OSError as e:
            eprint(f"rg: {pf}: {e.strerror} (os error {e.errno})")
            raise SystemExit(2)
    rest = list(ns.rest)
    if not pats:
        if not rest and not ns.files:
            eprint("rg: ripgrep requires at least one pattern to execute a search")
            raise SystemExit(2)
        if rest and not ns.files:
            pats.append(rest.pop(0))
    return pats, rest


def eprint(msg):
    print(msg, file=sys.stderr)


def compile_regex(patterns, ns):
    flags = re.MULTILINE
    if ns.ignore_case or (ns.smart_case and not any(any(c.isupper() for c in p) for p in patterns)):
        flags |= re.IGNORECASE
    if ns.multiline_dotall:
        flags |= re.DOTALL
    pieces = []
    for pat in patterns:
        if ns.fixed_strings:
            pat = re.escape(pat)
        if ns.word_regexp:
            pat = r"\b(?:" + pat + r")\b"
        if ns.line_regexp:
            pat = r"^(?:" + pat + r")$"
        pieces.append(pat)
    try:
        return re.compile("|".join("(?:" + p + ")" for p in pieces), flags)
    except re.error as e:
        eprint("rg: regex parse error:")
        eprint("    (?:" + (patterns[0] if patterns else "") + ")")
        msg = str(e)
        if "unterminated character set" in msg:
            eprint("       ^")
            msg = "unclosed character class"
        eprint("error: " + msg)
        raise SystemExit(2)


def is_hidden(path):
    return any(part.startswith(".") and part not in (".", "..") for part in path.split(os.sep))


def looks_binary(data):
    return b"\0" in data[:8192]


def parse_size(s):
    if not s:
        return None
    mult = 1
    last = s[-1].lower()
    if last in "kmgt":
        mult = {"k": 1024, "m": 1024**2, "g": 1024**3, "t": 1024**4}[last]
        s = s[:-1]
    try:
        return int(float(s) * mult)
    except ValueError:
        return None


def add_custom_types(specs):
    if not specs:
        return
    for spec in specs:
        if ":" not in spec:
            continue
        name, rest = spec.split(":", 1)
        if rest.startswith("glob:"):
            TYPE_GLOBS.setdefault(name, []).append(rest[5:])


def match_type(path, names):
    if not names:
        return True
    base = os.path.basename(path)
    for name in names:
        for glob in TYPE_GLOBS.get(name, []):
            if fnmatch.fnmatch(base, glob):
                return True
    return False


def glob_allowed(path, ns):
    rel = path.replace(os.sep, "/")
    base = os.path.basename(path)
    include_seen = False
    allowed = True
    for glob in ns.globs or []:
        neg = glob.startswith("!")
        g = glob[1:] if neg else glob
        hit = fnmatch.fnmatch(rel, g) or fnmatch.fnmatch(base, g)
        if not neg:
            include_seen = True
            if hit:
                allowed = True
        elif hit:
            allowed = False
    if include_seen and ns.globs:
        allowed = any(fnmatch.fnmatch(rel, g) or fnmatch.fnmatch(base, g) for g in ns.globs if not g.startswith("!"))
        for g in ns.globs:
            if g.startswith("!") and (fnmatch.fnmatch(rel, g[1:]) or fnmatch.fnmatch(base, g[1:])):
                allowed = False
    for glob in ns.iglobs or []:
        neg = glob.startswith("!")
        g = (glob[1:] if neg else glob).lower()
        hit = fnmatch.fnmatch(rel.lower(), g) or fnmatch.fnmatch(base.lower(), g)
        if neg and hit:
            allowed = False
        elif hit:
            allowed = True
    return allowed


def read_ignore_file(path):
    pats = []
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    pats.append(line)
    except OSError:
        pass
    return pats


def ignored_by_patterns(rel, pats):
    base = os.path.basename(rel)
    ignored = False
    for pat in pats:
        neg = pat.startswith("!")
        p = pat[1:] if neg else pat
        p = p.rstrip("/")
        hit = fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(base, p)
        if hit:
            ignored = not neg
    return ignored


def iter_files(paths, ns):
    paths = paths or ["."]
    max_size = parse_size(ns.max_filesize)
    use_ignores = not ns.no_ignore and ns.unrestricted < 2
    show_hidden = ns.hidden or ns.unrestricted >= 3
    for root_path in paths:
        if root_path == "-":
            yield "-"
            continue
        if not os.path.exists(root_path):
            eprint(f"rg: {root_path}: No such file or directory (os error 2)")
            yield None
            continue
        if os.path.isfile(root_path) or (os.path.islink(root_path) and not os.path.isdir(root_path)):
            yield root_path
            continue
        base_depth = root_path.rstrip(os.sep).count(os.sep)
        for dirpath, dirnames, filenames in os.walk(root_path, followlinks=ns.follow):
            rel_dir = os.path.relpath(dirpath, root_path)
            depth = 0 if rel_dir == "." else rel_dir.count(os.sep) + 1
            if ns.max_depth is not None and depth >= ns.max_depth:
                dirnames[:] = []
            ignore_pats = []
            if use_ignores:
                ignore_pats += read_ignore_file(os.path.join(dirpath, ".ignore"))
                ignore_pats += read_ignore_file(os.path.join(dirpath, ".rgignore"))
                if os.path.isdir(os.path.join(root_path, ".git")) or ns.no_require_git:
                    ignore_pats += read_ignore_file(os.path.join(dirpath, ".gitignore"))
            keep_dirs = []
            for d in dirnames:
                full = os.path.join(dirpath, d)
                rel = os.path.relpath(full, root_path)
                if not show_hidden and is_hidden(rel):
                    continue
                if use_ignores and ignored_by_patterns(rel, ignore_pats):
                    continue
                keep_dirs.append(d)
            dirnames[:] = keep_dirs
            for name in filenames:
                full = os.path.join(dirpath, name)
                rel = os.path.relpath(full, ".")
                rel_root = os.path.relpath(full, root_path)
                if not show_hidden and is_hidden(rel_root):
                    continue
                if use_ignores and ignored_by_patterns(rel_root, ignore_pats):
                    continue
                if max_size is not None:
                    try:
                        if os.path.getsize(full) > max_size:
                            continue
                    except OSError:
                        pass
                if ns.types and not match_type(full, ns.types):
                    continue
                if ns.not_types and match_type(full, ns.not_types):
                    continue
                if not glob_allowed(rel, ns):
                    continue
                yield rel


def read_file(path, ns):
    global STDIN_CACHE
    if path == "-":
        if STDIN_CACHE is None:
            data = sys.stdin.buffer.read()
        else:
            data = STDIN_CACHE
    else:
        with open(path, "rb") as f:
            data = f.read()
    enc = ns.encoding or "utf-8"
    if enc.lower() in ("none", "auto"):
        enc = "utf-8"
    return data, data.decode(enc, errors="replace")


def split_lines(text, ns):
    if ns.null_data:
        parts = text.split("\0")
        return [(p, "\0") for p in parts[:-1]] + ([(parts[-1], "")] if parts[-1] else [])
    return [(m.group(0).rstrip("\n"), "\n" if m.group(0).endswith("\n") else "") for m in re.finditer(r".*?(?:\n|$)", text) if m.group(0) != ""]


def prefix(path, line_no, col, byte, ns, with_filename, sep):
    fields = []
    if with_filename:
        p = path
        if ns.path_separator:
            p = p.replace(os.sep, ns.path_separator)
        fields.append(p)
    if ns.line_number or ns.vimgrep or ns.column:
        fields.append(str(line_no))
    if ns.column or ns.vimgrep:
        fields.append(str(col))
    if ns.byte_offset:
        fields.append(str(byte))
    return (sep.join(fields) + sep) if fields else ""


def print_json(kind, data):
    print(json.dumps({"type": kind, "data": data}, separators=(",", ":")))


def search_file(path, rx, ns, with_filename):
    try:
        loaded = read_file(path, ns)
    except OSError as e:
        if not ns.no_messages:
            eprint(f"rg: {path}: {e.strerror} (os error {e.errno})")
        return "error", 0, 0
    data, text = loaded
    if not (ns.text or ns.binary or ns.unrestricted >= 1) and looks_binary(data):
        if rx.search(text):
            off = data.find(b"\0")
            msg = f"binary file matches (found \"\\0\" byte around offset {off})"
            print((path + ": " if with_filename else "") + msg)
            return "match", 1, 1
        return "none", 0, 0
    if ns.json and path != "-":
        print_json("begin", {"path": {"text": path}})
    lines = split_lines(text, ns)
    before = ns.before_context
    after = ns.after_context
    if ns.context is not None:
        before = after = ns.context
    matched_lines = 0
    match_count = 0
    emitted = False
    after_left = 0
    prev = []
    byte_pos = 0
    for idx, (line, term) in enumerate(lines, 1):
        matches = list(rx.finditer(line))
        is_match = bool(matches)
        if ns.invert_match:
            is_match = not is_match
            matches = [re.match(r".*", line)] if is_match else []
        if ns.passthru:
            is_match = True
        if is_match:
            if ns.stop_on_nonmatch and matched_lines:
                break
            matched_lines += 1
            match_count += len(matches) if matches else 1
            if ns.max_count is not None and matched_lines > ns.max_count:
                break
            if ns.quiet:
                return "match", matched_lines, match_count
            if ns.files_with_matches:
                print(path, end="\0" if ns.nul else "\n")
                return "match", matched_lines, match_count
            if ns.count or ns.count_matches or ns.files_without_match:
                byte_pos += len((line + term).encode("utf-8", errors="replace"))
                continue
            if before and prev:
                for pidx, pline, pbyte in prev[-before:]:
                    print(prefix(path, pidx, 1, pbyte, ns, with_filename, ns.field_context_separator) + pline)
            if ns.only_matching and not ns.invert_match:
                for m in matches:
                    out = m.group(0)
                    if ns.replace is not None:
                        out = rx.sub(ns.replace, out)
                    if ns.trim:
                        out = out.lstrip()
                    print(prefix(path, idx, m.start() + 1, byte_pos + m.start(), ns, with_filename, ns.field_match_separator) + out)
            else:
                out = line
                if ns.replace is not None and not ns.invert_match:
                    out = rx.sub(ns.replace, out)
                if ns.trim:
                    out = out.lstrip()
                if ns.json:
                    print_json("match", {"path": {"text": path}, "lines": {"text": line + term}, "line_number": idx, "absolute_offset": byte_pos, "submatches": [{"match": {"text": m.group(0)}, "start": m.start(), "end": m.end()} for m in matches]})
                else:
                    print(prefix(path, idx, matches[0].start() + 1 if matches else 1, byte_pos + (matches[0].start() if matches else 0), ns, with_filename, ns.field_match_separator) + out)
            emitted = True
            after_left = after
        elif after_left:
            print(prefix(path, idx, 1, byte_pos, ns, with_filename, ns.field_context_separator) + line)
            after_left -= 1
        if not is_match and ns.stop_on_nonmatch and matched_lines:
            break
        prev.append((idx, line, byte_pos))
        if len(prev) > before:
            prev.pop(0)
        byte_pos += len((line + term).encode("utf-8", errors="replace"))
    if ns.count or ns.count_matches:
        n = match_count if ns.count_matches else matched_lines
        if n or ns.include_zero or with_filename:
            print(prefix(path, 0, 0, 0, argparse.Namespace(line_number=False, vimgrep=False, column=False, byte_offset=False, path_separator=ns.path_separator), with_filename, ns.field_match_separator) + str(n))
    if ns.files_without_match and matched_lines == 0:
        print(path, end="\0" if ns.nul else "\n")
    if ns.json and path != "-":
        print_json("end", {"path": {"text": path}, "binary_offset": None, "stats": {"elapsed": {"secs": 0, "nanos": 0, "human": "0s"}, "searches": 1, "searches_with_match": 1 if matched_lines else 0, "bytes_searched": len(text), "bytes_printed": 0, "matched_lines": matched_lines, "matches": match_count}})
    return ("match" if matched_lines else "none"), matched_lines, match_count


def main(argv):
    global STDIN_CACHE
    ns = parse(argv)
    add_custom_types(ns.type_add)
    if ns.help:
        print(SHORT_HELP)
        return 0
    if ns.version:
        print(VERSION)
        return 0
    if ns.pcre2_version:
        print("PCRE2 10.42 is available")
        return 0
    if ns.type_list:
        for k in sorted(TYPE_GLOBS):
            print(f"{k}: " + ", ".join(TYPE_GLOBS[k]))
        return 0
    patterns, paths = load_patterns(ns)
    files = list(iter_files(paths, ns))
    had_error = any(f is None for f in files)
    files = [f for f in files if f is not None]
    if ns.files:
        if ns.sort or ns.sort_files:
            files.sort()
        if ns.sortr:
            files.sort(reverse=True)
        for f in files:
            print(f, end="\0" if ns.nul else "\n")
        return 2 if had_error else 0
    rx = compile_regex(patterns, ns)
    explicit_stdin = paths == ["-"]
    if not paths and not sys.stdin.isatty():
        try:
            ready, _, _ = select.select([sys.stdin.buffer], [], [], 0)
            if ready:
                data = os.read(0, 1 << 20)
                chunks = [data]
                while data:
                    ready, _, _ = select.select([sys.stdin.buffer], [], [], 0)
                    if not ready:
                        break
                    data = os.read(0, 1 << 20)
                    chunks.append(data)
                STDIN_CACHE = b"".join(chunks)
                explicit_stdin = bool(STDIN_CACHE)
        except Exception:
            explicit_stdin = False
    if not paths and not explicit_stdin:
        paths = ["."]
        files = list(iter_files(paths, ns))
    elif not paths and explicit_stdin:
        files = ["-"]
    with_filename = ns.with_filename or ns.vimgrep or (not ns.no_filename and (len(files) > 1 or any(os.path.isdir(p) for p in paths if p != "-")))
    if ns.no_filename:
        with_filename = False
    if ns.sort or ns.sort_files:
        files.sort()
    if ns.sortr:
        files.sort(reverse=True)
    any_match = False
    total_matches = 0
    total_lines = 0
    for f in files:
        status, lines, matches = search_file(f, rx, ns, with_filename and f != "-")
        if status == "error":
            had_error = True
        if status == "match":
            any_match = True
        total_lines += lines
        total_matches += matches
    if ns.stats:
        print(f"{total_matches} matches")
        print(f"{total_lines} matched lines")
        print(f"{len(files)} files searched")
    if had_error:
        return 2
    return 0 if any_match else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        raise SystemExit(0)
