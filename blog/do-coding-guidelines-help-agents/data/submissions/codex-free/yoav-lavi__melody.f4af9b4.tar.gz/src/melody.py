#!/usr/bin/env python3
import argparse, os, re, sys

VERSION = "melody_cli 0.20.0"

SYMBOLS = {
    "char": ".", "space": " ", "whitespace": r"\s", "digit": r"\d", "word": r"\w",
    "start": "^", "end": "$", "newline": r"\n", "tab": r"\t", "boundary": r"\b",
    "backspace": r"[\b]", "alphabetic": "[a-zA-Z]", "alphanumeric": "[a-zA-Z0-9]",
}
NEG_SYMBOLS = {"digit": r"\D", "whitespace": r"\S", "word": r"\W", "space": "[^ ]"}
META = set(r".\^$*+?{}[]|()")

class MelodyError(Exception):
    pass

class Token:
    def __init__(self, typ, val, line, col):
        self.typ, self.val, self.line, self.col = typ, val, line, col
    def __repr__(self):
        return f"Token({self.typ!r},{self.val!r})"


def esc_lit(s):
    return ''.join(('\\' + c) if c in META else c for c in s)


def tokenize(src):
    toks=[]; i=0; line=1; col=1; n=len(src)
    def adv(ch):
        nonlocal line,col
        if ch=='\n': line+=1; col=1
        else: col+=1
    while i<n:
        c=src[i]
        if c.isspace(): adv(c); i+=1; continue
        if c=='/' and i+1<n and src[i+1]=='/':
            while i<n and src[i]!='\n': adv(src[i]); i+=1
            continue
        l,c0=line,col
        if c in '{};=':
            toks.append(Token(c,c,l,c0)); adv(c); i+=1; continue
        if c in ('"',"'"):
            quote=c; i+=1; adv(c); buf=''
            while i<n:
                ch=src[i]
                if ch==quote: i+=1; adv(ch); break
                if ch=='\\' and i+1<n:
                    nxt=src[i+1]
                    maps={'n':'\n','t':'\t','r':'\r'}
                    buf += maps.get(nxt, nxt)
                    adv(ch); adv(nxt); i+=2; continue
                buf += ch; adv(ch); i+=1
            else: raise MelodyError(f"unterminated string at {l}:{c0}")
            toks.append(Token('STRING',buf,l,c0)); continue
        if c=='`':
            i+=1; adv(c); buf=''
            while i<n:
                ch=src[i]
                if ch=='`': i+=1; adv(ch); break
                buf += ch; adv(ch); i+=1
            else: raise MelodyError(f"unterminated raw at {l}:{c0}")
            toks.append(Token('RAW',buf,l,c0)); continue
        if c=='<':
            i+=1; adv(c); buf=''
            while i<n and src[i]!='>': buf+=src[i]; adv(src[i]); i+=1
            if i>=n: raise MelodyError(f"unterminated symbol at {l}:{c0}")
            adv('>'); i+=1; toks.append(Token('SYMBOL',buf,l,c0)); continue
        if c.isdigit():
            buf=''
            while i<n and src[i].isdigit(): buf+=src[i]; adv(src[i]); i+=1
            toks.append(Token('NUMBER',buf,l,c0)); continue
        if c.isalpha() or c=='_':
            buf=''
            while i<n and (src[i].isalnum() or src[i] in '_-'):
                buf+=src[i]; adv(src[i]); i+=1
            toks.append(Token('IDENT',buf,l,c0)); continue
        raise MelodyError(f"unexpected character {c!r} at {l}:{c0}")
    toks.append(Token('EOF','',line,col))
    return toks

class Parser:
    def __init__(self, toks):
        self.toks=toks; self.i=0; self.vars={}; self.last_block=False
    def peek(self): return self.toks[self.i]
    def pop(self): t=self.toks[self.i]; self.i+=1; return t
    def accept(self, typ, val=None):
        t=self.peek()
        if t.typ==typ and (val is None or t.val==val): self.i+=1; return t
        return None
    def expect(self, typ, val=None):
        t=self.accept(typ,val)
        if not t: raise MelodyError(f"expected {val or typ} at {self.peek().line}:{self.peek().col}")
        return t
    def is_kw(self, word):
        return self.peek().typ=='IDENT' and self.peek().val==word
    def take_kw(self, word):
        if self.is_kw(word): return self.pop()
        return None
    def parse(self, stop=None):
        parts=[]
        while self.peek().typ!='EOF' and self.peek().typ!=stop:
            parts.append(self.statement())
        return ''.join(parts)
    def statement(self):
        # loose support for variable declarations: name = expression;
        if self.peek().typ=='IDENT' and self.i+1 < len(self.toks) and self.toks[self.i+1].typ=='=':
            name=self.pop().val; self.pop(); val=self.expr(); self.expect(';'); self.vars[name]=val; return ''
        val=self.expr()
        block_ended = self.last_block
        self.last_block = False
        if self.peek().typ==";": self.pop()
        elif self.peek().typ not in ("EOF","}") and not block_ended:
            raise MelodyError(f"expected ; at {self.peek().line}:{self.peek().col}")
        return val
    def expr(self):
        if self.peek().typ=='NUMBER' or self.is_kw('some') or self.is_kw('any') or self.is_kw('option'):
            return self.quantifier()
        if self.is_kw('not'):
            return self.not_expr()
        if self.is_kw('ahead') or self.is_kw('behind'):
            return self.assertion(False)
        if self.is_kw('match') or self.is_kw('either') or self.is_kw('capture'):
            return self.group()
        return self.atom()
    def atom(self):
        t=self.peek()
        if t.typ=='STRING': self.pop(); return esc_lit(t.val)
        if t.typ=='RAW': self.pop(); return t.val
        if t.typ=='SYMBOL':
            self.pop()
            if t.val not in SYMBOLS: raise MelodyError(f"unknown symbol <{t.val}>")
            return SYMBOLS[t.val]
        if t.typ=='IDENT' and t.val in self.vars:
            self.pop(); return self.vars[t.val]
        raise MelodyError(f"expected root at {t.line}:{t.col}")
    def block(self):
        self.expect('{'); body=self.parse('}'); self.expect('}'); return body
    def group(self):
        if self.take_kw('match'):
            body=self.block()
            self.last_block=True
            return '(?:' + body + ')'
        if self.take_kw('either'):
            self.expect('{'); alts=[]
            while self.peek().typ!='EOF' and self.peek().typ!='}':
                alts.append(self.statement())
            self.expect('}')
            self.last_block=True
            return '(?:' + '|'.join(alts) + ')'
        if self.take_kw('capture'):
            name=None
            if self.peek().typ=='IDENT': name=self.pop().val
            body=self.block()
            self.last_block=True
            return f"(?<{name}>{body})" if name else '('+body+')'
        raise MelodyError('bad group')
    def assertion(self, neg):
        if self.take_kw('ahead'):
            body=self.block()
            self.last_block=True
            return ('(?!' if neg else '(?=') + body + ')'
        if self.take_kw('behind'):
            body=self.block()
            self.last_block=True
            return ('(?<!' if neg else '(?<=') + body + ')'
        raise MelodyError(f"expected assertion_type at {self.peek().line}:{self.peek().col}")
    def not_expr(self):
        self.take_kw('not')
        if self.is_kw('ahead') or self.is_kw('behind'):
            return self.assertion(True)
        if self.peek().typ=='SYMBOL':
            s=self.pop().val
            if s in NEG_SYMBOLS: return NEG_SYMBOLS[s]
            raise MelodyError('negative char not allowed')
        raise MelodyError(f"expected assertion_type at {self.peek().line}:{self.peek().col}")
    def quantifier(self):
        if self.peek().typ=='NUMBER':
            lo=int(self.pop().val); hi=None
            if self.take_kw('to'):
                hi=int(self.expect('NUMBER').val)
                self.take_kw('of') or self.expect('IDENT','of')
                atom=self.expr(); q=f"{{{lo},{hi}}}"
            else:
                self.take_kw('of') or self.expect('IDENT','of')
                atom=self.expr(); q=f"{{{lo}}}"
        else:
            word=self.pop().val
            self.take_kw('of') or self.expect('IDENT','of')
            atom=self.expr(); q={'some':'+','any':'*','option':'?'}[word]
        return self.wrap(atom)+q
    def wrap(self, atom):
        if atom.startswith('(?:') or atom.startswith('(?=') or atom.startswith('(?!') or atom.startswith('(?<') or atom.startswith('(') and atom.endswith(')'):
            return atom
        if atom.startswith('\\') and len(atom)==2: return atom
        if len(atom)==1: return atom
        return '(?:'+atom+')'

def compile_src(src):
    return Parser(tokenize(src)).parse()

def read_input(path):
    if path is None or path=='-': return sys.stdin.read()
    with open(path, 'r', encoding='utf-8') as f: return f.read()

def py_regex(rx):
    return re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", rx)

def completion(shell):
    if shell == 'bash':
        return """_melody() {\n    local cur\n    COMPREPLY=()\n    cur=\"${COMP_WORDS[COMP_CWORD]}\"\n    COMPREPLY=( $(compgen -W \"--help --version --no-color --repl --output --test --test-file --generate-completions\" -- \"$cur\") )\n}\ncomplete -F _melody melody\n"""
    return "# completions for melody\n"

def repl():
    while True:
        try: s=input('melody> ')
        except EOFError: break
        if s.strip() in ('exit','quit'): break
        try: print(compile_src(s))
        except Exception as e: print('Error:', e, file=sys.stderr)

def main(argv=None):
    p=argparse.ArgumentParser(prog='executable', description='A CLI wrapping the Melody language compiler', add_help=False, formatter_class=argparse.RawTextHelpFormatter)
    p.add_argument('input_file_path', nargs='?')
    p.add_argument('-o','--output', dest='output_file_path')
    p.add_argument('-n','--no-color', action='store_true')
    p.add_argument('-r','--repl', action='store_true')
    p.add_argument('--generate-completions')
    p.add_argument('-t','--test')
    p.add_argument('-f','--test-file')
    p.add_argument('-h','--help', action='store_true')
    p.add_argument('-V','--version', action='store_true')
    args=p.parse_args(argv)
    if args.help:
        print('A CLI wrapping the Melody language compiler\n')
        print('Usage: executable [OPTIONS] [INPUT_FILE_PATH]\n')
        print('Arguments:\n  [INPUT_FILE_PATH]  Read from a file\n                     Use \'-\' and or pipe input to read from stdin\n')
        print('Options:\n  -o, --output <OUTPUT_FILE_PATH>           Write to a file\n  -n, --no-color                            Print output with no color\n  -r, --repl                                Start the Melody REPL\n      --generate-completions <completions>  Outputs completions for the selected shell\n                                            To use, write the output to the appropriate location for your shell\n  -t, --test <test>                         Test the compiled regex against a string\n  -f, --test-file <test-file>               Test the compiled regex against the contents of a file\n  -h, --help                                Print help\n  -V, --version                             Print version')
        return 0
    if args.version:
        print(VERSION); return 0
    if args.generate_completions:
        print(completion(args.generate_completions), end=''); return 0
    if args.repl:
        repl(); return 0
    try:
        src=read_input(args.input_file_path)
        rx=compile_src(src)
    except Exception as e:
        print('Error:', e, file=sys.stderr); return 65
    if args.output_file_path:
        with open(args.output_file_path,'w',encoding='utf-8') as f: f.write(rx)
    elif args.test is None and args.test_file is None:
        print(rx)
    if args.test is not None:
        ok = re.search(py_regex(rx), args.test, re.S) is not None
        print(f"'{args.test}' {'matched' if ok else 'did not match'}")
    if args.test_file is not None:
        try:
            data=open(args.test_file,'r',encoding='utf-8').read()
            ok = re.search(py_regex(rx), data, re.S) is not None
            print(f"{args.test_file} {'matched' if ok else 'did not match'}")
        except Exception as e:
            print('Error:', e, file=sys.stderr); return 1
    return 0
if __name__ == '__main__':
    sys.exit(main())
