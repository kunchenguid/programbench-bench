#!/usr/bin/env python3
import os
import re
import sys
from datetime import datetime

VERSION = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z"

COMMANDS = {
    "add-environment": "Add a new named environment to an existing host directory",
    "diff": "Compare a DB server's schemas to the filesystem",
    "format": "Normalize format of filesystem representation of database objects",
    "help": "Display usage information",
    "init": "Save a DB server's schemas to the filesystem",
    "lint": "Check for problems in filesystem representation of database objects",
    "pull": "Update the filesystem representation of schemas",
    "push": "Alter objects on DBs to reflect the filesystem representation",
    "version": "Display program version",
}

GLOBAL_OPTIONS = """Global Options:
  -o, --connect-options value  Comma-separated session options to set upon connecting to each database server
      --debug                  Enable debug logging
  -?, --help[=value]           Display usage information for the specified command
  -H, --host-wrapper value     External bin to shell out to for host lookup; see manual for template vars
      --ignore-func value      Ignore functions that match regex
      --ignore-proc value      Ignore stored procedures that match regex
      --ignore-schema value    Ignore schemas that match regex
      --ignore-table value     Ignore tables that match regex
      --[skip-]my-cnf          Parse ~/.my.cnf for configuration (enabled by default; disable with --skip-my-cnf)
  -p, --password[=value]       Password for database user; omit value to prompt from TTY (default "$MYSQL_PWD")
      --ssl-mode value         Specify desired connection security SSL/TLS usage (valid values: "disabled", "preferred", "required")
  -u, --user value             Username to connect to database host (default "root")
      --version                Display program version"""

MAIN_HELP = """
Usage:  skeema [<options>] <command>

Skeema is a declarative schema management system for MySQL and MariaDB. It
allows you to export a database schema to the filesystem, and apply online
schema changes by modifying CREATE statements in .sql files.

Commands:
      add-environment  Add a new named environment to an existing host directory
      diff             Compare a DB server's schemas to the filesystem
      format           Normalize format of filesystem representation of database objects
      help             Display usage information
      init             Save a DB server's schemas to the filesystem
      lint             Check for problems in filesystem representation of database objects
      pull             Update the filesystem representation of schemas
      push             Alter objects on DBs to reflect the filesystem representation
      version          Display program version

""" + GLOBAL_OPTIONS + """

Complete documentation for this command suite is available online:
https://www.skeema.io/docs/commands

"""

ADD_ENV_HELP = """
Usage:  skeema add-environment [<options>] <environment>

Modifies the .skeema file in an existing host directory to add a new named
environment. For example, if `skeema init` was previously used to create a dir
for a host with the default "production" environment, `skeema add-environment`
could be used to define a "staging" or "development" environment pointing at a
different host and port, or perhaps a "local" environment pointing at localhost
and a socket path.

This command currently only handles very simple cases. For many situations,
editing .skeema files directly is a better approach.

Add-Environment Options:
  -d, --dir value              Base dir for this host's schemas (default ".")
  -h, --host value             Database hostname or IP address
  -P, --port value             Port to use for database host (default "3306")
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")

""" + GLOBAL_OPTIONS + """

Complete documentation for this command is available online:
https://www.skeema.io/docs/commands/add-environment

"""

WORKSPACE_OPTIONS = """Workspace Options:
      --docker-cleanup value       With --workspace=docker, specifies how to clean up containers (valid values: "none", "stop", "destroy") (default "none")
  -t, --temp-schema value          Name of temporary schema for intermediate operations, created and dropped each run (default "_skeema_tmp")
      --temp-schema-binlog value   Controls whether temp schema DDL operations are replicated (valid values: "on", "off", "auto") (default "auto")
      --temp-schema-mode value     Tunes workspace load with workspace=temp-schema; heavier load makes Skeema faster but may disrupt other workloads on the database (valid values: "serial", "light", "regular", "heavy", "extreme") (default "regular")
      --temp-schema-threads value  Deprecated manner of controlling workspace load with workspace=temp-schema (default "5")
  -w, --workspace value            Specifies where to run intermediate operations (valid values: "temp-schema", "docker") (default "temp-schema")"""

LINTER_OPTIONS = """Linter Rule Options:
      --allow-auto-inc value       List of allowed auto_increment column data types for --lint-auto-inc (default "int unsigned, bigint unsigned")
      --allow-charset value        List of allowed character sets for --lint-charset (default "latin1,utf8mb4")
      --allow-compression value    List of allowed compression settings for --lint-compression (default "none,4kb,8kb")
      --allow-definer value        List of allowed definer users for --lint-definer (default "%@%")
      --allow-engine value         List of allowed storage engines for --lint-engine (default "innodb")
      --allow-pk-type value        List of allowed data types for --lint-pk-type
      --lint-auto-inc value        Only allow auto_increment column data types listed in --allow-auto-inc (valid values: "ignore", "warning", "error") (default "warning")
      --lint-charset value         Only allow character sets listed in --allow-charset (valid values: "ignore", "warning", "error") (default "warning")
      --lint-compression value     Only allow compression settings listed in --allow-compression (valid values: "ignore", "warning", "error") (default "warning")
      --lint-definer value         Only allow definer users listed in --allow-definer for stored objects (valid values: "ignore", "warning", "error") (default "error")
      --lint-display-width value   Only allow default display width for int types (valid values: "ignore", "warning", "error") (default "warning")
      --lint-dupe-index value      Flag redundant secondary indexes (valid values: "ignore", "warning", "error") (default "warning")
      --lint-engine value          Only allow storage engines listed in --allow-engine (valid values: "ignore", "warning", "error") (default "warning")
      --lint-fk-parent value       Flag foreign keys where same-schema parent table is missing or lacks unique key on referenced columns (valid values: "ignore", "warning", "error") (default "warning")
      --lint-has-enum value        Flag columns using ENUM or SET data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-fk value          Flag any use of foreign keys; intended for environments that restrict their presence (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-float value       Flag columns using FLOAT or DOUBLE data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-routine value     Flag any use of stored procs or funcs; intended for environments that restrict their presence (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-has-time value        Flag columns using TIMESTAMP, DATETIME, or TIME data types (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-name-case value       Flag tables that have uppercase letters in their names (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-pk value              Flag tables that lack a primary key (valid values: "ignore", "warning", "error") (default "warning")
      --lint-pk-type value         Only allow primary keys to have types listed in --allow-pk-type (valid values: "ignore", "warning", "error") (default "ignore")
      --lint-reserved-word value   Flag names of tables, columns, or routines that used reserved words (valid values: "ignore", "warning", "error") (default "warning")
      --lint-zero-date value       Flag DATE, DATETIME, and TIMESTAMP columns that have zero-date default values (valid values: "ignore", "warning", "error") (default "warning")"""


def log(level, msg):
    ts = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    gap = " " if level == "ERROR" else "  "
    print(f"{ts} [{level}]{gap}{msg}", file=sys.stderr)


def err(msg, code=78):
    log("ERROR", msg)
    return code


def command_help(cmd):
    if cmd == "add-environment":
        return ADD_ENV_HELP
    if cmd == "version":
        return VERSION + "\n"
    if cmd == "init":
        body = """Usage:  skeema init [<options>] [<environment>]

Creates a filesystem representation of the schemas on a database server. For
each schema on the DB server (or just the single schema specified by --schema),
a subdir with a .skeema config file will be created. Each directory will be
populated with .sql files containing CREATE statements for every table and
routine in the schema.

Init Options:
  -d, --dir value              Subdir name to use for this host's schemas (default "<hostname>")
  -h, --host value             Database hostname or IP address
      --include-auto-inc       Include starting auto-inc values in table files
  -P, --port value             Port to use for database host (default "3306")
      --schema value           Only import the one specified schema; skip creation of subdirs for each schema
  -S, --socket value           Absolute path to Unix socket file used if host is localhost (default "/tmp/mysql.sock")
      --strip-partitioning     Omit PARTITION BY clause when writing partitioned tables to filesystem"""
    elif cmd == "pull":
        body = """Usage:  skeema pull [<options>] [<environment>]

Updates the existing filesystem representation of the schemas on a DB server.
Use this command when changes have been applied to the database manually or
outside of Skeema, in order to make the filesystem representation reflect those
changes.

Pull Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --include-auto-inc           Include starting auto-inc values in new table files, and update in existing files
      --[skip-]new-schemas         Detect any new schemas and populate new dirs for them (enabled by default; disable with --skip-new-schemas)
      --strip-partitioning         Omit PARTITION BY clause when writing partitioned tables to filesystem
      --update-partitioning        Update PARTITION BY clauses in existing table files

""" + WORKSPACE_OPTIONS
    elif cmd == "format":
        body = """Usage:  skeema format [<options>] [<environment>]

Reformats the filesystem representation of database objects to match the
canonical format shown in SHOW CREATE.

Format Options:
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files
      --[skip-]write               Update files to correct format (enabled by default; disable with --skip-write)

""" + WORKSPACE_OPTIONS
    elif cmd == "lint":
        body = """Usage:  skeema lint [<options>] [<environment>]

Checks for problems in filesystem representation of database objects. A set of
linter rules are run against all objects. Each rule may be configured to
generate an error, a warning, or be ignored entirely. Statements that contain
invalid SQL, or otherwise return an error from the database, are always flagged
as linter errors.

By default, this command also reformats CREATE statements to their canonical
form, just like `skeema format`.

Format Options:
      --[skip-]format              Reformat SQL statements to match canonical SHOW CREATE (enabled by default; disable with --skip-format)
      --strip-partitioning         Remove PARTITION BY clauses from *.sql files

""" + LINTER_OPTIONS + "\n\n" + WORKSPACE_OPTIONS
    elif cmd in ("diff", "push"):
        usage = f"Usage:  skeema {cmd} [<options>] [<environment>]"
        action = "Output DDL but don't run it; equivalent to `skeema diff`" if cmd == "push" else "Don't output DDL to STDOUT; instead output list of database servers with at least one difference"
        body = f"""{usage}

Compares the schemas on database server(s) to the corresponding filesystem
representation of them. The output is a series of DDL commands that, if run on
the DB server, would cause its schemas to now match the definitions from the
filesystem.

External Tool Options:
  -x, --alter-wrapper value           External bin to shell out to for ALTER TABLE; see manual for template vars
      --alter-wrapper-min-size value  Ignore --alter-wrapper for tables smaller than this size in bytes (default "0")
  -X, --ddl-wrapper value             Like --alter-wrapper, but applies to all DDL types (CREATE, DROP, ALTER)

SQL Generation Options:
      --alter-algorithm value         Apply an ALGORITHM clause to all ALTER TABLEs (valid values: "inplace", "copy", "instant", "nocopy")
      --alter-lock value              Apply a LOCK clause to all ALTER TABLEs (valid values: "none", "shared", "exclusive")
      --exact-match                   Follow *.sql table definitions exactly, even for differences with no functional impact
      --partitioning value            Specify handling of partitioning status on the database side (valid values: "keep", "remove", "modify") (default "keep")

""" + LINTER_OPTIONS.replace("      --", "      --[skip-]lint                   Check modified objects for problems before proceeding (enabled by default; disable with --skip-lint)\n      --", 1) + f"""

Safety Options:
      --allow-unsafe                  Permit running ALTER or DROP operations that are potentially destructive
      --dry-run                       {action}
      --safe-below-size value         Always permit destructive operations for tables below this size in bytes (default "0")
      --[skip-]verify                 Test all generated ALTER statements on temp schema to verify correctness (enabled by default; disable with --skip-verify)

""" + WORKSPACE_OPTIONS
    else:
        return None
    return "\n" + body + "\n\n" + GLOBAL_OPTIONS + f"\n\nComplete documentation for this command is available online:\nhttps://www.skeema.io/docs/commands/{cmd}\n"


def parse_opts(argv):
    opts = {}
    pos = []
    takes = {"-d": "dir", "--dir": "dir", "-h": "host", "--host": "host", "-P": "port", "--port": "port", "-S": "socket", "--socket": "socket", "-u": "user", "--user": "user", "-p": "password", "--password": "password"}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos.extend(argv[i + 1:])
            break
        if a in ("-?", "--help") or a.startswith("--help="):
            opts["help"] = a.split("=", 1)[1] if "=" in a else True
            i += 1
            continue
        if a == "--version":
            opts["version"] = True
            i += 1
            continue
        if a.startswith("--") and "=" in a:
            k, v = a.split("=", 1)
            if k in takes:
                opts[takes[k]] = v
            else:
                opts[k[2:]] = v
            i += 1
            continue
        if a in takes:
            if i + 1 >= len(argv):
                raise ValueError(f'Option "{a.lstrip("-")}" requires a value')
            opts[takes[a]] = argv[i + 1]
            i += 2
            continue
        if a.startswith("-"):
            # Most options are accepted and ignored; unknown --bad is reported.
            known_prefix = any(a.startswith(p) for p in ("--skip-", "--lint-", "--allow-", "--ignore-", "--alter-", "--temp-", "--docker-", "--connect-", "--ssl-", "--safe-", "--workspace", "--debug", "--dry-run", "--format", "--write", "--schema", "--include", "--strip", "--update", "--exact", "--lax", "--partitioning", "--verify", "--my-cnf", "--brief", "--first-only", "-o", "-H", "-x", "-X", "-t", "-w", "-c", "-1", "-q"))
            if not known_prefix:
                name = a[2:] if a.startswith("--") else a[1:]
                raise ValueError(f'Unknown option "{name}"')
            if a in ("-o", "-H", "-x", "-X", "-t", "-w", "-c") and i + 1 < len(argv):
                i += 2
            else:
                i += 1
            continue
        pos.append(a)
        i += 1
    return opts, pos


def read_config(path):
    try:
        return open(path, encoding="utf-8").read()
    except FileNotFoundError:
        return None


def config_host_port(path):
    text = read_config(path) or ""
    host = "localhost"
    port = "3306"
    in_section = False
    for line in text.splitlines():
        s = line.strip()
        if s.startswith("["):
            in_section = True
        if in_section:
            continue
        if s.startswith("host="):
            host = s.split("=", 1)[1].strip()
        elif s.startswith("port="):
            port = s.split("=", 1)[1].strip()
    return host, port


def add_environment(args):
    try:
        opts, pos = parse_opts(args)
    except ValueError as e:
        return err("CLI: " + str(e))
    if opts.get("help"):
        print(ADD_ENV_HELP, end="")
        return 0
    if len(pos) < 1:
        return err("Too few positional args supplied on command line; command add-environment requires at least 1 args")
    env = pos[0]
    base = opts.get("dir", ".")
    cfg = os.path.abspath(os.path.join(base, ".skeema"))
    text = read_config(cfg)
    if text is None:
        return err(f"Dir {os.path.abspath(base)} does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`")
    if re.search(r"(?m)^\[" + re.escape(env) + r"\]\s*$", text):
        return err(f'Environment name "{env}" already defined in {cfg}')
    host = opts.get("host", "localhost")
    port = opts.get("port", "3306")
    sock = opts.get("socket", "/tmp/mysql.sock")
    addition = f"\n[{env}]\nhost={host}\n"
    if host in ("localhost", "127.0.0.1") and "port" not in opts:
        addition += f"socket={sock}\n"
    else:
        addition += f"port={port}\n"
    with open(cfg, "a", encoding="utf-8") as f:
        if not text.endswith("\n"):
            f.write("\n")
        f.write(addition)
    log("WARN", f'Unable to automatically determine database server\'s vendor/version. To set manually, use the "flavor" option in {cfg}')
    log("INFO", f"Added environment [{env}] to {cfg}")
    return 0


def find_skeema_dirs(root):
    dirs = []
    for cur, subdirs, files in os.walk(root):
        if ".git" in subdirs:
            subdirs.remove(".git")
        if ".skeema" in files:
            dirs.append(cur)
    return dirs


def db_command(cmd, args):
    try:
        opts, pos = parse_opts(args)
    except ValueError as e:
        return err("CLI: " + str(e))
    if opts.get("help"):
        print(command_help(cmd), end="")
        return 0
    cwd = os.getcwd()
    if cmd == "format":
        log("INFO", f"Reformatting {cwd}")
    elif cmd == "lint":
        log("INFO", f"Linting {cwd}")
    if cmd == "init":
        host = opts.get("host", "localhost")
        port = opts.get("port", "3306")
        return err(f"Unable to connect to {host}:{port}: dial tcp {host}:{port}: connect: connection refused")
    dirs = find_skeema_dirs(cwd)
    if not dirs:
        return 0
    failed = 0
    for d in dirs:
        if d != cwd and cmd in ("lint", "format"):
            log("INFO", f"{'Linting' if cmd == 'lint' else 'Reformatting'} {d}")
        host, port = config_host_port(os.path.join(d, ".skeema"))
        if host not in ("", "localhost"):
            log("ERROR", f"Skipping directory {os.path.basename(os.path.dirname(d))}/{os.path.basename(d)} due to error: Unable to connect to {host}:{port} for {d}: dial tcp {host}:{port}: connect: connection refused")
            failed += 1
    if failed:
        log("ERROR", f"Skipped {failed} operation due to fatal errors")
        return 78
    return 0


def main(argv):
    if not argv:
        print(MAIN_HELP, end="")
        return 0
    if argv[0].startswith("--help="):
        cmd = argv[0].split("=", 1)[1]
        if cmd in COMMANDS:
            print(command_help(cmd) if cmd != "help" else MAIN_HELP, end="")
            return 0
        return err(f'Unknown command "{cmd}"', 2)
    if argv[0] in ("--help", "-?"):
        if len(argv) > 1 and argv[1] in COMMANDS and argv[1] != "help":
            print(command_help(argv[1]), end="")
        else:
            print(MAIN_HELP, end="")
        return 0
    if argv[0] == "--version":
        print(VERSION)
        return 0
    cmd = argv[0]
    if cmd == "help":
        if len(argv) == 1:
            print(MAIN_HELP, end="")
            return 0
        if argv[1] not in COMMANDS:
            return err(f'Unknown command "{argv[1]}"', 2)
        print(command_help(argv[1]) if argv[1] != "help" else MAIN_HELP, end="")
        return 0
    if cmd == "version":
        print(VERSION)
        return 0
    if cmd not in COMMANDS:
        if cmd.startswith("-"):
            name = cmd[2:] if cmd.startswith("--") else cmd[1:]
            return err(f'CLI: Unknown option "{name}"')
        return err(f'Unknown command "{cmd}"')
    if "--version" in argv[1:]:
        print(VERSION)
        return 0
    if cmd == "add-environment":
        return add_environment(argv[1:])
    if cmd in ("diff", "format", "init", "lint", "pull", "push"):
        return db_command(cmd, argv[1:])
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
