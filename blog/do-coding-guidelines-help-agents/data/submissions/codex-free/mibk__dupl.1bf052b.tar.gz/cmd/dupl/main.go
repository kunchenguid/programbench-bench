package main

import (
	"bufio"
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/printer"
	"go/scanner"
	"go/token"
	"html"
	"io"
	"log"
	"os"
	"path/filepath"
	"sort"
	"strings"
)

const usageText = `Usage: dupl [flags] [paths]

Paths:
  If the given path is a file, dupl will use it regardless of
  the file extension. If it is a directory, it will recursively
  search for *.go files in that directory.

  If no path is given, dupl will recursively search for *.go
  files in the current directory.

Flags:
  -files
    	read file names from stdin one at each line
  -html
    	output the results as HTML, including duplicate code fragments
  -plumbing
    	plumbing (easy-to-parse) output for consumption by scripts or tools
  -t, -threshold size
    	minimum token sequence size as a clone (default 15)
  -vendor
    	check files in vendor directory
  -v, -verbose
    	explain what is being done

Examples:
  dupl -t 100
    	Search clones in the current directory of size at least
    	100 tokens.
  dupl $(find app/ -name '*_test.go')
    	Search for clones in tests in the app directory.
  find app/ -name '*_test.go' |dupl -files
    	The same as above.
`

type options struct {
	files     bool
	html      bool
	plumbing  bool
	threshold int
	vendor    bool
	verbose   bool
}

type fragment struct {
	file      string
	startLine int
	endLine   int
	startOff  int
	endOff    int
	size      int
	key       string
}

type cloneGroup struct {
	frags []fragment
	size  int
}

type sourceFile struct {
	path string
	src  []byte
}

func main() {
	log.SetFlags(log.LstdFlags)
	var opt options
	fs := flag.NewFlagSet("dupl", flag.ContinueOnError)
	fs.BoolVar(&opt.files, "files", false, "read file names from stdin one at each line")
	fs.BoolVar(&opt.html, "html", false, "output the results as HTML, including duplicate code fragments")
	fs.BoolVar(&opt.plumbing, "plumbing", false, "plumbing (easy-to-parse) output for consumption by scripts or tools")
	fs.IntVar(&opt.threshold, "threshold", 15, "minimum token sequence size as a clone")
	fs.IntVar(&opt.threshold, "t", 15, "minimum token sequence size as a clone")
	fs.BoolVar(&opt.vendor, "vendor", false, "check files in vendor directory")
	fs.BoolVar(&opt.verbose, "verbose", false, "explain what is being done")
	fs.BoolVar(&opt.verbose, "v", false, "explain what is being done")
	fs.Usage = func() { fmt.Fprint(fs.Output(), usageText) }
	if err := fs.Parse(os.Args[1:]); err != nil {
		os.Exit(2)
	}

	paths, err := collectPaths(fs.Args(), opt)
	if err != nil {
		log.Fatal(err)
	}
	if opt.verbose {
		log.Print("Building suffix tree")
	}
	groups := findClones(paths, opt.threshold)
	if opt.verbose {
		log.Print("Searching for clones")
	}
	writeOutput(os.Stdout, groups, opt)
}

func collectPaths(args []string, opt options) ([]string, error) {
	if opt.files {
		var paths []string
		sc := bufio.NewScanner(os.Stdin)
		for sc.Scan() {
			p := strings.TrimSpace(sc.Text())
			if p != "" {
				paths = append(paths, p)
			}
		}
		sort.Strings(paths)
		return paths, sc.Err()
	}
	if len(args) == 0 {
		args = []string{"."}
	}
	var paths []string
	for _, p := range args {
		info, err := os.Lstat(p)
		if err != nil {
			return nil, err
		}
		if !info.IsDir() {
			paths = append(paths, p)
			continue
		}
		err = filepath.WalkDir(p, func(path string, d os.DirEntry, err error) error {
			if err != nil {
				return err
			}
			if d.IsDir() {
				if !opt.vendor && d.Name() == "vendor" {
					return filepath.SkipDir
				}
				return nil
			}
			if strings.HasSuffix(path, ".go") {
				paths = append(paths, path)
			}
			return nil
		})
		if err != nil {
			return nil, err
		}
	}
	sort.Strings(paths)
	return paths, nil
}

func findClones(paths []string, threshold int) []cloneGroup {
	fset := token.NewFileSet()
	var files []sourceFile
	byKey := map[string][]fragment{}
	for _, path := range paths {
		src, err := os.ReadFile(path)
		if err != nil {
			log.Print(err)
			continue
		}
		files = append(files, sourceFile{path: path, src: src})
		file, err := parser.ParseFile(fset, path, src, 0)
		if err != nil {
			log.Print(err)
			if file == nil {
				continue
			}
		}
		ast.Inspect(file, func(n ast.Node) bool {
			if n == nil {
				return true
			}
			switch n.(type) {
			case *ast.Ident, *ast.BasicLit, *ast.Field, *ast.FieldList, *ast.ImportSpec:
				return true
			}
			start := fset.Position(n.Pos())
			end := fset.Position(n.End())
			if start.Filename == "" || end.Filename == "" || start.Filename != path || start.Line <= 0 || end.Line <= 0 {
				return true
			}
			if end.Offset <= start.Offset || start.Offset < 0 || end.Offset > len(src) {
				return true
			}
			size := tokenCount(src[start.Offset:end.Offset])
			if size < threshold {
				return true
			}
			key := normNode(fset, n)
			if key == "" {
				return true
			}
			byKey[key] = append(byKey[key], fragment{
				file: path, startLine: start.Line, endLine: end.Line,
				startOff: start.Offset, endOff: end.Offset, size: size, key: key,
			})
			return true
		})
	}
	_ = files
	var groups []cloneGroup
	for _, frags := range byKey {
		if len(frags) < 2 {
			continue
		}
		frags = uniqueFragments(frags)
		if len(frags) < 2 {
			continue
		}
		sort.Slice(frags, func(i, j int) bool {
			if frags[i].file != frags[j].file {
				return frags[i].file < frags[j].file
			}
			if frags[i].startLine != frags[j].startLine {
				return frags[i].startLine < frags[j].startLine
			}
			return frags[i].endLine < frags[j].endLine
		})
		groups = append(groups, cloneGroup{frags: frags, size: frags[0].size})
	}
	groups = filterContained(groups)
	sort.Slice(groups, func(i, j int) bool {
		if groups[i].size != groups[j].size {
			return groups[i].size > groups[j].size
		}
		a, b := groups[i].frags[0], groups[j].frags[0]
		if a.file != b.file {
			return a.file < b.file
		}
		if a.startLine != b.startLine {
			return a.startLine < b.startLine
		}
		return a.endLine < b.endLine
	})
	return groups
}

func tokenCount(src []byte) int {
	var s scanner.Scanner
	fset := token.NewFileSet()
	file := fset.AddFile("", -1, len(src))
	s.Init(file, src, nil, scanner.ScanComments)
	n := 0
	for {
		_, tok, _ := s.Scan()
		if tok == token.EOF {
			break
		}
		if tok != token.COMMENT && tok != token.SEMICOLON {
			n++
		}
	}
	return n
}

func normNode(fset *token.FileSet, n ast.Node) string {
	var b strings.Builder
	writeNorm(&b, n)
	return b.String()
}

func writeNorm(b *strings.Builder, n ast.Node) {
	if n == nil {
		b.WriteString("nil")
		return
	}
	switch x := n.(type) {
	case *ast.File:
		b.WriteString("File(")
		for _, d := range x.Decls {
			writeNorm(b, d)
			b.WriteByte(';')
		}
		b.WriteByte(')')
	case *ast.Ident:
		b.WriteString("id")
	case *ast.BasicLit:
		b.WriteString("lit:")
		b.WriteString(x.Kind.String())
	case *ast.FuncDecl:
		b.WriteString("FuncDecl(")
		if x.Recv != nil {
			b.WriteString("recv")
		}
		writeFieldList(b, x.Type.Params)
		writeFieldList(b, x.Type.Results)
		writeNorm(b, x.Body)
		b.WriteByte(')')
	case *ast.BlockStmt:
		b.WriteString("Block[")
		for _, s := range x.List {
			writeNorm(b, s)
			b.WriteByte(';')
		}
		b.WriteByte(']')
	case *ast.GenDecl:
		fmt.Fprintf(b, "Gen:%s[", x.Tok)
		for _, s := range x.Specs {
			writeNorm(b, s)
		}
		b.WriteByte(']')
	case *ast.ValueSpec:
		b.WriteString("Value(")
		for range x.Names {
			b.WriteString("id,")
		}
		for _, v := range x.Values {
			writeNorm(b, v)
		}
		b.WriteByte(')')
	case *ast.TypeSpec:
		b.WriteString("Type(")
		writeNorm(b, x.Type)
		b.WriteByte(')')
	case *ast.AssignStmt:
		fmt.Fprintf(b, "Assign:%s(", x.Tok)
		writeList(b, x.Lhs)
		writeList(b, x.Rhs)
		b.WriteByte(')')
	case *ast.ExprStmt:
		b.WriteString("Expr(")
		writeNorm(b, x.X)
		b.WriteByte(')')
	case *ast.ReturnStmt:
		b.WriteString("Return(")
		writeList(b, x.Results)
		b.WriteByte(')')
	case *ast.IfStmt:
		b.WriteString("If(")
		writeNorm(b, x.Init)
		writeNorm(b, x.Cond)
		writeNorm(b, x.Body)
		writeNorm(b, x.Else)
		b.WriteByte(')')
	case *ast.ForStmt:
		b.WriteString("For(")
		writeNorm(b, x.Init)
		writeNorm(b, x.Cond)
		writeNorm(b, x.Post)
		writeNorm(b, x.Body)
		b.WriteByte(')')
	case *ast.RangeStmt:
		fmt.Fprintf(b, "Range:%s(", x.Tok)
		writeNorm(b, x.Key)
		writeNorm(b, x.Value)
		writeNorm(b, x.X)
		writeNorm(b, x.Body)
		b.WriteByte(')')
	case *ast.SwitchStmt:
		b.WriteString("Switch(")
		writeNorm(b, x.Init)
		writeNorm(b, x.Tag)
		writeNorm(b, x.Body)
		b.WriteByte(')')
	case *ast.TypeSwitchStmt:
		b.WriteString("TypeSwitch(")
		writeNorm(b, x.Init)
		writeNorm(b, x.Assign)
		writeNorm(b, x.Body)
		b.WriteByte(')')
	case *ast.SelectStmt:
		b.WriteString("Select(")
		writeNorm(b, x.Body)
		b.WriteByte(')')
	case *ast.CaseClause:
		b.WriteString("Case(")
		writeList(b, x.List)
		for _, s := range x.Body {
			writeNorm(b, s)
		}
		b.WriteByte(')')
	case *ast.CommClause:
		b.WriteString("Comm(")
		writeNorm(b, x.Comm)
		for _, s := range x.Body {
			writeNorm(b, s)
		}
		b.WriteByte(')')
	case *ast.BranchStmt:
		fmt.Fprintf(b, "Branch:%s", x.Tok)
	case *ast.IncDecStmt:
		fmt.Fprintf(b, "IncDec:%s(", x.Tok)
		writeNorm(b, x.X)
		b.WriteByte(')')
	case *ast.DeferStmt:
		b.WriteString("Defer(")
		writeNorm(b, x.Call)
		b.WriteByte(')')
	case *ast.GoStmt:
		b.WriteString("Go(")
		writeNorm(b, x.Call)
		b.WriteByte(')')
	case *ast.SendStmt:
		b.WriteString("Send(")
		writeNorm(b, x.Chan)
		writeNorm(b, x.Value)
		b.WriteByte(')')
	case *ast.DeclStmt:
		b.WriteString("Decl(")
		writeNorm(b, x.Decl)
		b.WriteByte(')')
	case *ast.CallExpr:
		b.WriteString("Call(")
		writeNorm(b, x.Fun)
		writeList(b, x.Args)
		b.WriteByte(')')
	case *ast.SelectorExpr:
		b.WriteString("Sel(")
		writeNorm(b, x.X)
		b.WriteString(".id)")
	case *ast.BinaryExpr:
		fmt.Fprintf(b, "Bin:%s(", x.Op)
		writeNorm(b, x.X)
		writeNorm(b, x.Y)
		b.WriteByte(')')
	case *ast.UnaryExpr:
		fmt.Fprintf(b, "Unary:%s(", x.Op)
		writeNorm(b, x.X)
		b.WriteByte(')')
	case *ast.ParenExpr:
		writeNorm(b, x.X)
	case *ast.CompositeLit:
		b.WriteString("Comp(")
		writeNorm(b, x.Type)
		writeList(b, x.Elts)
		b.WriteByte(')')
	case *ast.KeyValueExpr:
		b.WriteString("KV(")
		writeNorm(b, x.Key)
		writeNorm(b, x.Value)
		b.WriteByte(')')
	case *ast.IndexExpr:
		b.WriteString("Index(")
		writeNorm(b, x.X)
		writeNorm(b, x.Index)
		b.WriteByte(')')
	case *ast.IndexListExpr:
		b.WriteString("IndexList(")
		writeNorm(b, x.X)
		writeList(b, x.Indices)
		b.WriteByte(')')
	case *ast.SliceExpr:
		b.WriteString("Slice(")
		writeNorm(b, x.X)
		writeNorm(b, x.Low)
		writeNorm(b, x.High)
		writeNorm(b, x.Max)
		b.WriteByte(')')
	case *ast.StarExpr:
		b.WriteString("Star(")
		writeNorm(b, x.X)
		b.WriteByte(')')
	case *ast.ArrayType:
		b.WriteString("Array(")
		writeNorm(b, x.Len)
		writeNorm(b, x.Elt)
		b.WriteByte(')')
	case *ast.MapType:
		b.WriteString("Map(")
		writeNorm(b, x.Key)
		writeNorm(b, x.Value)
		b.WriteByte(')')
	case *ast.ChanType:
		fmt.Fprintf(b, "Chan:%d(", x.Dir)
		writeNorm(b, x.Value)
		b.WriteByte(')')
	case *ast.StructType:
		b.WriteString("Struct")
	case *ast.InterfaceType:
		b.WriteString("Interface")
	case *ast.FuncType:
		b.WriteString("FuncType(")
		writeFieldList(b, x.Params)
		writeFieldList(b, x.Results)
		b.WriteByte(')')
	case *ast.TypeAssertExpr:
		b.WriteString("Assert(")
		writeNorm(b, x.X)
		writeNorm(b, x.Type)
		b.WriteByte(')')
	case *ast.Ellipsis:
		b.WriteString("Ellipsis(")
		writeNorm(b, x.Elt)
		b.WriteByte(')')
	default:
		fmt.Fprintf(b, "%T", n)
	}
}

func writeFieldList(b *strings.Builder, fl *ast.FieldList) {
	b.WriteByte('(')
	if fl != nil {
		for _, f := range fl.List {
			if len(f.Names) == 0 {
				b.WriteString("anon:")
			} else {
				for range f.Names {
					b.WriteString("id:")
				}
			}
			writeNorm(b, f.Type)
			b.WriteByte(',')
		}
	}
	b.WriteByte(')')
}

func writeList[T ast.Node](b *strings.Builder, xs []T) {
	b.WriteByte('[')
	for _, x := range xs {
		writeNorm(b, x)
		b.WriteByte(',')
	}
	b.WriteByte(']')
}

func uniqueFragments(frags []fragment) []fragment {
	seen := map[string]bool{}
	var out []fragment
	for _, f := range frags {
		k := fmt.Sprintf("%s:%d:%d", f.file, f.startLine, f.endLine)
		if !seen[k] {
			seen[k] = true
			out = append(out, f)
		}
	}
	return out
}

func filterContained(groups []cloneGroup) []cloneGroup {
	drop := make([]bool, len(groups))
	for i := range groups {
		for j := range groups {
			if i == j || drop[i] || groups[j].size < groups[i].size {
				continue
			}
			if groups[j].size == groups[i].size && sameFragments(groups[i].frags, groups[j].frags) {
				if j < i {
					drop[i] = true
				}
				continue
			}
			if sameOrContained(groups[i].frags, groups[j].frags) {
				drop[i] = true
			}
		}
	}
	var out []cloneGroup
	for i, g := range groups {
		if !drop[i] {
			out = append(out, g)
		}
	}
	return out
}

func sameFragments(a, b []fragment) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i].file != b[i].file || a[i].startLine != b[i].startLine || a[i].endLine != b[i].endLine {
			return false
		}
	}
	return true
}

func sameOrContained(a, b []fragment) bool {
	if len(a) != len(b) {
		return false
	}
	used := make([]bool, len(b))
	for _, x := range a {
		found := false
		for i, y := range b {
			if used[i] || x.file != y.file {
				continue
			}
			if x.startOff >= y.startOff && x.endOff <= y.endOff && (x.startOff != y.startOff || x.endOff != y.endOff) {
				used[i] = true
				found = true
				break
			}
		}
		if !found {
			return false
		}
	}
	return true
}

func writeOutput(w io.Writer, groups []cloneGroup, opt options) {
	if opt.html {
		writeHTML(w, groups)
		return
	}
	if opt.plumbing {
		for _, g := range groups {
			for i, f := range g.frags {
				for j, other := range g.frags {
					if i == j {
						continue
					}
					fmt.Fprintf(w, "%s:%d-%d: duplicate of %s:%d-%d\n", f.file, f.startLine, f.endLine, other.file, other.startLine, other.endLine)
				}
			}
		}
		return
	}
	for _, g := range groups {
		fmt.Fprintf(w, "found %d clones:\n", len(g.frags))
		for _, f := range g.frags {
			fmt.Fprintf(w, "  %s:%d,%d\n", f.file, f.startLine, f.endLine)
		}
		fmt.Fprintln(w)
	}
	fmt.Fprintf(w, "Found total %d clone groups.\n", len(groups))
}

func writeHTML(w io.Writer, groups []cloneGroup) {
	fmt.Fprint(w, `<!DOCTYPE html>
<meta charset="utf-8"/>
<title>Duplicates</title>
<style>
	pre {
		background-color: #FFD;
		border: 1px solid #E2E2E2;
		padding: 1ex;
	}
</style>
`)
	for i, g := range groups {
		fmt.Fprintf(w, "<h1>#%d found %d clones</h1>\n", i+1, len(g.frags))
		for _, f := range g.frags {
			fmt.Fprintf(w, "<h2>%s:%d</h2>\n", html.EscapeString(f.file), f.startLine)
			src, err := os.ReadFile(f.file)
			if err != nil {
				fmt.Fprint(w, "<pre></pre>\n")
				continue
			}
			text := fragmentText(src, f.startLine, f.endLine)
			fmt.Fprintf(w, "<pre>%s</pre>\n", html.EscapeString(text))
		}
	}
}

func fragmentText(src []byte, startLine, endLine int) string {
	lines := bytes.Split(src, []byte{'\n'})
	if startLine < 1 {
		startLine = 1
	}
	if endLine > len(lines) {
		endLine = len(lines)
	}
	if startLine > endLine {
		return ""
	}
	return string(bytes.Join(lines[startLine-1:endLine], []byte{'\n'}))
}

func printable(fset *token.FileSet, n ast.Node) string {
	var b bytes.Buffer
	_ = printer.Fprint(&b, fset, n)
	return b.String()
}

var _ = printable
