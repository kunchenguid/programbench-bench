#!/usr/bin/env python3
import os
import re
import stat
import sys
import time
from dataclasses import dataclass


VERSION = "ambr 0.6.0"
HELP = """ambr 0.6.0

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
"""


@dataclass
class Opt:
    regex: bool = False
    column: bool = False
    row: bool = False
    binary: bool = False
    statistics: bool = False
    skipped: bool = False
    preserve_time: bool = False
    interactive: bool = True
    recursive: bool = True
    symlink: bool = True
    color: bool = True
    file: bool = True
    skip_vcs: bool = True
    skip_gitignore: bool = True
    fixed_order: bool = True
    parent_ignore: bool = True
    key_from_file: bool = False
    rep_from_file: bool = False
    verbose: bool = False
    bin_check_bytes: int = 256


def die(msg, code=1):
    sys.stderr.write(msg)
    if not msg.endswith("\n"):
        sys.stderr.write("\n")
    return code


def parse_args(argv):
    opt = Opt()
    positionals = []
    takes_value = {
        "--max-threads",
        "--size-per-thread",
        "--bin-check-bytes",
        "--mmap-bytes",
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            raise SystemExit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            raise SystemExit(0)
        if a == "--":
            positionals.extend(argv[i + 1 :])
            break
        if a.startswith("--") and a in takes_value:
            if i + 1 >= len(argv):
                return None, f"error: The argument '{a} <value>' requires a value\n"
            if a == "--bin-check-bytes":
                try:
                    opt.bin_check_bytes = int(argv[i + 1])
                except ValueError:
                    pass
            i += 2
            continue
        if a in ("-r", "--regex"):
            opt.regex = True
        elif a == "--column":
            opt.column = True
        elif a == "--row":
            opt.row = True
        elif a == "--binary":
            opt.binary = True
        elif a == "--statistics":
            opt.statistics = True
        elif a == "--skipped":
            opt.skipped = True
        elif a == "--preserve-time":
            opt.preserve_time = True
        elif a == "--no-interactive":
            opt.interactive = False
        elif a == "--no-recursive":
            opt.recursive = False
        elif a == "--no-symlink":
            opt.symlink = False
        elif a == "--no-color":
            opt.color = False
        elif a == "--no-file":
            opt.file = False
        elif a == "--no-skip-vcs":
            opt.skip_vcs = False
        elif a == "--no-skip-gitignore":
            opt.skip_gitignore = False
        elif a == "--no-fixed-order":
            opt.fixed_order = False
        elif a == "--no-parent-ignore":
            opt.parent_ignore = False
        elif a == "--key-from-file":
            opt.key_from_file = True
        elif a == "--rep-from-file":
            opt.rep_from_file = True
        elif a == "--verbose":
            opt.verbose = True
        elif a in ("--tbm", "--sse"):
            pass
        elif a.startswith("-"):
            return None, f"error: Found argument '{a}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\nFor more information try --help\n"
        else:
            positionals.append(a)
        i += 1
    if len(positionals) < 2:
        return None, "error: The following required arguments were not provided:\n    <KEYWORD>\n    <REPLACEMENT>\n\nUSAGE:\n    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>\n\nFor more information try --help\n"
    return (opt, positionals[0], positionals[1], positionals[2:] or ["."]), None


def read_text_file(path):
    with open(path, "r", encoding="utf-8", errors="surrogateescape") as f:
        return f.read()


def load_ignore_file(path):
    rules = []
    try:
        for line in read_text_file(path).splitlines():
            s = line.strip()
            if not s or s.startswith("#") or s.startswith("!"):
                continue
            rules.append(s.rstrip("/"))
    except OSError:
        pass
    return rules


def ignored_by_rules(rel, name, rules):
    rel = rel.replace(os.sep, "/")
    for rule in rules:
        r = rule.strip("/")
        if not r:
            continue
        if "/" in r:
            if rel == r or rel.startswith(r + "/"):
                return True
        elif name == r or rel.startswith(r + "/"):
            return True
        elif r.startswith("*") and name.endswith(r[1:]):
            return True
    return False


def iter_files(paths, opt):
    vcs = {".git", ".hg", ".svn", ".bzr"}
    for p in paths:
        if os.path.isfile(p) or (os.path.islink(p) and opt.symlink and os.path.isfile(p)):
            yield p
            continue
        if not os.path.isdir(p):
            if opt.skipped:
                print(f"{p}: skipped")
            continue
        if not opt.recursive:
            try:
                for name in sorted(os.listdir(p)):
                    fp = os.path.join(p, name)
                    if os.path.isfile(fp):
                        yield fp
            except OSError:
                pass
            continue
        root_rules = load_ignore_file(os.path.join(p, ".gitignore")) if opt.skip_gitignore else []
        for root, dirs, files in os.walk(p, followlinks=opt.symlink):
            relroot = os.path.relpath(root, p)
            local_rules = list(root_rules)
            if opt.skip_gitignore:
                local_rules.extend(load_ignore_file(os.path.join(root, ".gitignore")))
            keep_dirs = []
            for d in sorted(dirs):
                rel = d if relroot == "." else os.path.join(relroot, d)
                if opt.skip_vcs and d in vcs:
                    if opt.skipped:
                        print(f"{os.path.join(root, d)}: skipped")
                    continue
                if opt.skip_gitignore and ignored_by_rules(rel, d, local_rules):
                    if opt.skipped:
                        print(f"{os.path.join(root, d)}: skipped")
                    continue
                keep_dirs.append(d)
            dirs[:] = keep_dirs
            for f in sorted(files):
                rel = f if relroot == "." else os.path.join(relroot, f)
                if opt.skip_gitignore and ignored_by_rules(rel, f, local_rules):
                    if opt.skipped:
                        print(f"{os.path.join(root, f)}: skipped")
                    continue
                fp = os.path.join(root, f)
                if os.path.isfile(fp):
                    yield fp


def is_binary(path, n):
    try:
        with open(path, "rb") as f:
            return b"\0" in f.read(max(1, n))
    except OSError:
        return False


def rust_repl_to_python(rep):
    out = []
    i = 0
    while i < len(rep):
        c = rep[i]
        if c != "$":
            out.append(c)
            i += 1
            continue
        if i + 1 < len(rep) and rep[i + 1] == "$":
            out.append("$")
            i += 2
            continue
        if i + 1 < len(rep) and rep[i + 1] == "{":
            j = rep.find("}", i + 2)
            if j != -1:
                name = rep[i + 2 : j]
                out.append("\\" + ("g<" + name + ">" if not name.isdigit() else name))
                i = j + 1
                continue
        j = i + 1
        while j < len(rep) and (rep[j].isalnum() or rep[j] == "_"):
            j += 1
        if j > i + 1:
            name = rep[i + 1 : j]
            out.append("\\" + ("g<" + name + ">" if not name.isdigit() else name))
            i = j
        else:
            out.append("$")
            i += 1
    return "".join(out)


def rust_regex_to_python(expr):
    # Rust regex names captures as (?<name>...), while Python uses (?P<name>...).
    return re.sub(r"\(\?<([A-Za-z_][A-Za-z0-9_]*)>", r"(?P<\1>", expr)


def line_col(text, idx):
    row = text.count("\n", 0, idx) + 1
    last = text.rfind("\n", 0, idx)
    col = idx + 1 if last < 0 else idx - last
    return row, col


def print_match(path, text, start, opt):
    if not (opt.row or opt.column or opt.verbose):
        return
    row, col = line_col(text, start)
    prefix = []
    if opt.file:
        prefix.append(path)
    if opt.row:
        prefix.append(str(row))
    if opt.column:
        prefix.append(str(col))
    print(":".join(prefix))


def confirm(path, text, start, opt):
    print_match(path, text, start, opt)
    sys.stdout.write("Replace keyword? ( Yes[Y], No[N], All[A], Quit[Q] ):")
    sys.stdout.flush()
    ans = sys.stdin.readline()
    if not ans:
        return "n"
    ans = ans.strip().lower()
    if ans in ("y", "yes"):
        return "y"
    if ans in ("a", "all"):
        return "a"
    if ans in ("q", "quit"):
        return "q"
    return "n"


def replace_literal(path, text, key, rep, opt, all_mode):
    out = []
    pos = 0
    count = 0
    changed = False
    while True:
        idx = text.find(key, pos)
        if idx < 0:
            out.append(text[pos:])
            break
        do = all_mode or not opt.interactive
        if opt.interactive and not all_mode:
            ans = confirm(path, text, idx, opt)
            if ans == "q":
                raise KeyboardInterrupt
            if ans == "a":
                all_mode = True
                do = True
            elif ans == "y":
                do = True
        else:
            print_match(path, text, idx, opt)
        out.append(text[pos:idx])
        if do:
            out.append(rep)
            changed = True
            count += 1
        else:
            out.append(key)
        pos = idx + len(key)
    return "".join(out), changed, count, all_mode


def replace_regex(path, text, pattern, rep, opt, all_mode):
    repl = rust_repl_to_python(rep)
    out = []
    pos = 0
    count = 0
    changed = False
    for m in pattern.finditer(text):
        do = all_mode or not opt.interactive
        if opt.interactive and not all_mode:
            ans = confirm(path, text, m.start(), opt)
            if ans == "q":
                raise KeyboardInterrupt
            if ans == "a":
                all_mode = True
                do = True
            elif ans == "y":
                do = True
        else:
            print_match(path, text, m.start(), opt)
        out.append(text[pos : m.start()])
        if do:
            out.append(m.expand(repl))
            changed = True
            count += 1
        else:
            out.append(m.group(0))
        pos = m.end()
    out.append(text[pos:])
    return "".join(out), changed, count, all_mode


def process_file(path, key, rep, opt, pattern, all_mode):
    if not opt.binary and is_binary(path, opt.bin_check_bytes):
        if opt.skipped:
            print(f"{path}: skipped")
        return 0, 0, all_mode
    try:
        st = os.stat(path)
        text = read_text_file(path)
    except OSError:
        if opt.skipped:
            print(f"{path}: skipped")
        return 0, 0, all_mode
    try:
        if opt.regex:
            new, changed, n, all_mode = replace_regex(path, text, pattern, rep, opt, all_mode)
        else:
            if key == "":
                return 0, 0, all_mode
            new, changed, n, all_mode = replace_literal(path, text, key, rep, opt, all_mode)
    except re.error as e:
        raise e
    if changed:
        with open(path, "w", encoding="utf-8", errors="surrogateescape") as f:
            f.write(new)
        if opt.preserve_time:
            os.utime(path, (st.st_atime, st.st_mtime))
    return n, 1 if changed else 0, all_mode


def main(argv):
    parsed, err = parse_args(argv)
    if err:
        return die(err, 1)
    opt, key, rep, paths = parsed
    try:
        if opt.key_from_file:
            key = read_text_file(key)
        if opt.rep_from_file:
            rep = read_text_file(rep)
    except OSError as e:
        return die(str(e), 1)
    pattern = None
    if opt.regex:
        try:
            pattern = re.compile(rust_regex_to_python(key), re.MULTILINE)
        except re.error as e:
            return die(f"regex parse error: {e}", 1)
    files = list(iter_files(paths, opt)) if opt.fixed_order else list(iter_files(paths, opt))
    total = 0
    changed_files = 0
    searched = 0
    all_mode = False
    try:
        for fp in files:
            searched += 1
            n, c, all_mode = process_file(fp, key, rep, opt, pattern, all_mode)
            total += n
            changed_files += c
    except KeyboardInterrupt:
        pass
    except re.error as e:
        return die(f"regex replacement error: {e}", 1)
    if opt.statistics:
        print(f"{searched} files searched")
        print(f"{changed_files} files changed")
        print(f"{total} replacements")
    return 0 if total > 0 else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
