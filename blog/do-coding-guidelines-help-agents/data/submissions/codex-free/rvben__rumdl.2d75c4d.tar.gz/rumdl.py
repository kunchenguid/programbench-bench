#!/usr/bin/env python3
import argparse
import fnmatch
import json
import os
import re
import sys
import time
from pathlib import Path

VERSION = "0.1.13"

RULES = [
("MD001","heading-increment","Heading levels should only increment by one level at a time","heading",False,"Sometimes"),
("MD003","heading-style","Heading style","heading",True,"Sometimes"),
("MD004","ul-style","Use consistent style for unordered list markers","list",True,"Sometimes"),
("MD005","list-indent","List indentation should be consistent","list",False,"Sometimes"),
("MD007","ul-indent","Unordered list indentation","list",True,"Sometimes"),
("MD009","no-trailing-spaces","Trailing spaces should be removed","whitespace",True,"Always"),
("MD010","no-hard-tabs","No tabs","whitespace",True,"Always"),
("MD011","no-reversed-links","Reversed link syntax","link",True,"Always"),
("MD012","no-multiple-blanks","Multiple consecutive blank lines","whitespace",True,"Always"),
("MD013","line-length","Line length should not be excessive","whitespace",True,"Always"),
("MD014","commands-show-output","Commands in code blocks should show output","code-block",False,"Never"),
("MD018","no-missing-space-atx","No space after hash in heading","heading",True,"Always"),
("MD019","no-multiple-space-atx","Multiple spaces after hash in heading","heading",True,"Always"),
("MD020","no-missing-space-closed-atx","No space inside hashes on closed heading","heading",True,"Always"),
("MD021","no-multiple-space-closed-atx","Multiple spaces inside hashes on closed heading","heading",True,"Always"),
("MD022","blanks-around-headings","Headings should be surrounded by blank lines","heading",True,"Always"),
("MD023","heading-start-left","Headings must start at the beginning of the line","heading",True,"Always"),
("MD024","no-duplicate-heading","Multiple headings with the same content","heading",False,"Never"),
("MD025","single-title","Multiple top-level headings in the same document","heading",False,"Never"),
("MD026","no-trailing-punctuation","Trailing punctuation in heading","heading",True,"Always"),
("MD027","no-multiple-space-blockquote","Multiple spaces after quote marker (>)","blockquote",True,"Always"),
("MD028","no-blanks-blockquote","Blank line inside blockquote","blockquote",False,"Never"),
("MD029","ol-prefix","Ordered list marker value","list",True,"Sometimes"),
("MD030","list-marker-space","Spaces after list markers should be consistent","list",True,"Always"),
("MD031","blanks-around-fences","Fenced code blocks should be surrounded by blank lines","code-block",True,"Always"),
("MD032","blanks-around-lists","Lists should be surrounded by blank lines","list",True,"Always"),
("MD033","no-inline-html","Inline HTML is not allowed","html",False,"Never"),
("MD034","no-bare-urls","No bare URLs - wrap URLs in angle brackets","link",True,"Always"),
("MD035","hr-style","Horizontal rule style","other",True,"Sometimes"),
("MD036","no-emphasis-as-heading","Emphasis should not be used instead of a heading","emphasis",False,"Never"),
("MD037","no-space-in-emphasis","Spaces inside emphasis markers","emphasis",True,"Always"),
("MD038","no-space-in-code","Spaces inside code span elements","code-block",True,"Always"),
("MD039","no-space-in-links","Spaces inside link text","link",True,"Always"),
("MD040","fenced-code-language","Code blocks should have a language specified","code-block",False,"Never"),
("MD041","first-line-heading","First line in file should be a top level heading","heading",False,"Never"),
("MD042","no-empty-links","No empty links","link",False,"Never"),
("MD043","required-headings","Required heading structure","heading",False,"Never"),
("MD044","proper-names","Proper names should have the correct capitalization","other",True,"Sometimes"),
("MD045","no-alt-text","Images should have alternate text (alt text)","link",False,"Never"),
("MD046","code-block-style","Code blocks should use a consistent style","code-block",True,"Sometimes"),
("MD047","single-trailing-newline","Files should end with a single newline character","whitespace",True,"Always"),
("MD048","code-fence-style","Code fence style should be consistent","code-block",True,"Sometimes"),
("MD049","emphasis-style","Emphasis style should be consistent","emphasis",True,"Sometimes"),
("MD050","strong-style","Strong emphasis style should be consistent","emphasis",True,"Sometimes"),
("MD051","link-fragments","Link fragments should reference valid headings","link",False,"Never"),
("MD052","reference-links-images","Reference links and images should use a reference that exists","link",False,"Never"),
("MD053","link-image-reference-definitions","Link and image reference definitions should be needed","link",True,"Always"),
("MD054","link-image-style","Link and image style should be consistent","link",False,"Never"),
("MD055","table-pipe-style","Table pipe style should be consistent","other",True,"Always"),
("MD056","table-column-count","Table column count should be consistent","other",False,"Never"),
("MD057","no-missing-file","Relative links should point to existing files","link",False,"Never"),
("MD058","blanks-around-tables","Tables should be surrounded by blank lines","other",True,"Always"),
("MD059","descriptive-link-text","Link text should be descriptive","link",False,"Never"),
("MD060","table-format","Table columns should be consistently aligned","other",True,"Always"),
("MD061","forbidden-terms","Forbidden terms","other",False,"Never"),
("MD062","link-destination-whitespace","Link destination should not have leading or trailing whitespace","link",True,"Always"),
("MD063","heading-capitalization","Heading capitalization","heading",True,"Always"),
("MD064","no-multiple-spaces","Multiple consecutive spaces","whitespace",True,"Always"),
("MD065","blanks-around-hr","Horizontal rules should be surrounded by blank lines","other",True,"Always"),
("MD066","footnote-valid","Footnote validation","other",False,"Never"),
("MD067","footnote-order","Footnote definitions should appear in order of first reference","other",False,"Never"),
("MD068","footnote-empty","Footnote definitions should not be empty","other",False,"Never"),
("MD069","no-duplicate-list-markers","Duplicate list markers","list",True,"Always"),
("MD070","nested-code-fence","Nested code fence collision - use longer fence to avoid premature closure","code-block",False,"Never"),
("MD071","blanks-after-frontmatter","Blank line after frontmatter","front-matter",True,"Always"),
("MD072","frontmatter-sort","Frontmatter keys should be sorted alphabetically","front-matter",True,"Always"),
("MD073","toc","Table of Contents should match document headings","other",True,"Always"),
]
RULEMAP = {r[0]: r for r in RULES}
ERROR_RULES = {"MD001","MD011","MD024","MD025","MD042","MD045","MD051","MD057","MD066","MD068"}
OPT_IN = {"MD060","MD063","MD072","MD073"}

def norm_rule(s):
    s = s.strip().upper()
    if re.fullmatch(r"\d+", s): s = "MD" + s.zfill(3)
    return s

class Issue:
    def __init__(self, file, line, col, rule, msg, fixable=False):
        self.file=file; self.line=line; self.col=col; self.rule=rule; self.msg=msg; self.fixable=fixable
    def sev(self): return "error" if self.rule in ERROR_RULES else "warning"
    def obj(self):
        return {"file":self.file,"line":self.line,"column":self.col,"rule":self.rule,"message":self.msg,
                "severity":self.sev(),"fixable":bool(self.fixable),"fix":None}

def strip_frontmatter(lines):
    if lines and lines[0].strip() in ("---","+++"):
        endmark = lines[0].strip()
        for i in range(1,len(lines)):
            if lines[i].strip()==endmark:
                return i+1
    return 0

def is_fence(line):
    m = re.match(r"^\s*(`{3,}|~{3,})(.*)$", line)
    return m

def is_heading(line):
    m = re.match(r"^(#{1,6})(?:\s+|$)(.*?)(?:\s+#+\s*)?$", line)
    if m: return len(m.group(1)), m.group(2).strip()
    return None

def slug(s):
    s = re.sub(r"`([^`]*)`", r"\1", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"[^\w\s-]", "", s.lower(), flags=re.UNICODE)
    return re.sub(r"\s+", "-", s.strip())

def is_blank(line): return line.strip()==""
def is_list(line): return re.match(r"^\s*(?:[-+*]|\d+[.)])\s+", line) is not None
def is_hr(line): return re.match(r"^\s{0,3}(([-*_])\s*){3,}$", line.strip()) is not None
def is_table(line): return "|" in line and not is_fence(line) and not re.match(r"^\s*```", line)

def parse_config(path):
    cfg={"disable":set(),"enable":set(),"line_length":80,"exclude":[],"include":[]}
    if not path:
        for p in [".rumdl.toml","rumdl.toml","pyproject.toml"]:
            if os.path.exists(p): path=p; break
    if not path or not os.path.exists(path): return cfg
    text = Path(path).read_text(errors="ignore")
    cur = ""
    for raw in text.splitlines():
        line = raw.split("#",1)[0].strip()
        if not line: continue
        m = re.match(r"\[([^\]]+)\]", line)
        if m: cur=m.group(1); continue
        if "=" not in line: continue
        k,v = [x.strip() for x in line.split("=",1)]
        arr = re.findall(r'"([^"]+)"', v)
        if k in ("disable","disabled") and (cur in ("global","tool.rumdl","") or cur.endswith("rumdl")):
            cfg["disable"].update(norm_rule(x) for x in arr)
        if k == "enable" and (cur in ("global","tool.rumdl","") or cur.endswith("rumdl")):
            cfg["enable"].update(norm_rule(x) for x in arr)
        if k in ("exclude","include") and arr:
            cfg[k].extend(arr)
        if k in ("line-length","line_length"):
            try: cfg["line_length"] = int(re.search(r"\d+", v).group(0))
            except Exception: pass
    return cfg

def lint_text(text, filename, enabled, cfg):
    lines = text.splitlines(True)
    pure = [l[:-1] if l.endswith("\n") else l for l in lines]
    issues=[]; in_code=False; fence_char=None; headings=[]; ids=set(); top=0
    start = strip_frontmatter(pure)
    if "MD071" in enabled and start and start < len(pure) and pure[start].strip():
        issues.append(Issue(filename,start+1,1,"MD071","Missing blank line after front matter",True))
    if "MD041" in enabled:
        i = start
        while i < len(pure) and is_blank(pure[i]): i += 1
        if i >= len(pure) or not ((is_heading(pure[i]) and is_heading(pure[i])[0]==1) or re.match(r"^#(?!#)", pure[i])):
            issues.append(Issue(filename,i+1 if i<len(pure) else 1,1,"MD041","First line in a file should be a top-level heading"))
    prev_heading = 0
    blank_run = 0
    list_markers_by_indent = {}
    ol_expected = {}
    refs_defined=set(); refs_used=[]; links=[]
    for idx,line in enumerate(pure, start=1):
        raw = line
        fm = is_fence(raw)
        if fm:
            if not in_code:
                in_code=True; fence_char=fm.group(1)[0]
                if "MD031" in enabled:
                    if idx>1 and pure[idx-2].strip() and not is_list(pure[idx-2]):
                        issues.append(Issue(filename,idx,1,"MD031","Fenced code blocks should be surrounded by blank lines",True))
                if "MD040" in enabled and not fm.group(2).strip():
                    issues.append(Issue(filename,idx,len(fm.group(1))+1,"MD040","Fenced code blocks should have a language specified"))
            else:
                in_code=False
                if "MD031" in enabled and idx < len(pure) and pure[idx].strip() and not is_list(pure[idx]):
                    issues.append(Issue(filename,idx,1,"MD031","Fenced code blocks should be surrounded by blank lines",True))
            continue
        if in_code:
            continue
        if "MD009" in enabled and re.search(r"[ \t]+$", raw):
            spaces=len(re.search(r"[ \t]+$", raw).group(0))
            if spaces != 2:
                issues.append(Issue(filename,idx,len(raw)-spaces+1,"MD009","Trailing spaces",True))
        if "MD010" in enabled and "\t" in raw:
            issues.append(Issue(filename,idx,raw.index("\t")+1,"MD010","Hard tabs",True))
        if is_blank(raw): blank_run += 1
        else:
            if "MD012" in enabled and blank_run > 1:
                issues.append(Issue(filename,idx-1,1,"MD012","Multiple consecutive blank lines between content",True))
            blank_run = 0
        if "MD018" in enabled:
            m=re.match(r"^(#{1,6})([^#\s].*)$", raw)
            if m: issues.append(Issue(filename,idx,len(m.group(1))+1,"MD018",f"No space after {m.group(1)} in heading",True))
        if "MD019" in enabled:
            m=re.match(r"^(#{1,6}) {2,}\S", raw)
            if m: issues.append(Issue(filename,idx,len(m.group(1))+1,"MD019",f"Multiple spaces after {m.group(1)} in heading",True))
        if "MD023" in enabled and re.match(r"^\s+#{1,6}\s+", raw):
            issues.append(Issue(filename,idx,1,"MD023","Headings must start at the beginning of the line",True))
        h = is_heading(raw)
        if h:
            level,txt=h; headings.append((level,txt,idx)); sid=slug(txt)
            if "MD001" in enabled and prev_heading and level > prev_heading + 1:
                issues.append(Issue(filename,idx,1,"MD001",f"Heading level incremented by more than one level (expected H{prev_heading+1}, got H{level})"))
            prev_heading=level
            if level==1: top += 1
            if "MD022" in enabled:
                if idx>1 and pure[idx-2].strip():
                    issues.append(Issue(filename,idx,1,"MD022","Headings should be surrounded by blank lines",True))
                if idx < len(pure) and pure[idx].strip():
                    issues.append(Issue(filename,idx,1,"MD022","Headings should be surrounded by blank lines",True))
            if "MD026" in enabled and txt and txt[-1] in ".,;:!":
                issues.append(Issue(filename,idx,len(raw.rstrip()),"MD026",f"Trailing punctuation in heading: {txt[-1]}",True))
            if "MD024" in enabled:
                if sid in ids: issues.append(Issue(filename,idx,1,"MD024",f"Multiple headings with the same content: {txt}"))
                ids.add(sid)
        if "MD025" in enabled and top > 1 and h and h[0]==1:
            issues.append(Issue(filename,idx,1,"MD025","Multiple top-level headings in the same document"))
        if "MD013" in enabled and len(raw.expandtabs(4)) > cfg.get("line_length",80) and not re.match(r"^\s*\|", raw):
            issues.append(Issue(filename,idx,cfg.get("line_length",80)+1,"MD013",f"Line length [{len(raw.expandtabs(4))}] exceeds configured limit [{cfg.get('line_length',80)}]",False))
        lm=re.match(r"^(\s*)([-+*])(\s+)(.*)$", raw)
        if lm:
            ind=len(lm.group(1)); mark=lm.group(2)
            if "MD004" in enabled:
                old=list_markers_by_indent.setdefault(ind,mark)
                if old != mark: issues.append(Issue(filename,idx,ind+1,"MD004",f"Unordered list style should be consistent ({old})",True))
            if "MD030" in enabled and len(lm.group(3)) != 1:
                issues.append(Issue(filename,idx,ind+2,"MD030","Spaces after list markers should be consistent",True))
            if "MD069" in enabled and re.match(r"\s*[-+*]\s+[-+*]\s+", raw):
                issues.append(Issue(filename,idx,ind+1,"MD069","Duplicate list markers",True))
        om=re.match(r"^(\s*)(\d+)([.)])(\s+)", raw)
        if om:
            ind=len(om.group(1)); num=int(om.group(2))
            exp=ol_expected.get(ind, 1)
            if "MD029" in enabled and num not in (1, exp):
                issues.append(Issue(filename,idx,ind+1,"MD029",f"Ordered list item prefix [{num}]; expected [{exp}]",True))
            ol_expected[ind]=num+1
        if "MD032" in enabled and is_list(raw):
            if idx>1 and pure[idx-2].strip() and not is_list(pure[idx-2]):
                issues.append(Issue(filename,idx,1,"MD032","Lists should be surrounded by blank lines",True))
            if idx<len(pure) and pure[idx].strip() and not is_list(pure[idx]):
                issues.append(Issue(filename,idx,1,"MD032","Lists should be surrounded by blank lines",True))
        if "MD033" in enabled:
            m=re.search(r"</?[A-Za-z][^>]*>", raw)
            if m and not re.match(r"^\s*<!--", raw):
                issues.append(Issue(filename,idx,m.start()+1,"MD033",f"Inline HTML [{m.group(0)}]"))
        if "MD034" in enabled:
            for m in re.finditer(r"(?<![<(])(https?://[^\s>)]+)", raw):
                issues.append(Issue(filename,idx,m.start()+1,"MD034",f"URL without angle brackets or link formatting: '{m.group(1)}'",True))
        if "MD042" in enabled:
            for m in re.finditer(r"!?\[[^\]]*\]\(\s*\)", raw):
                if not m.group(0).startswith("!"):
                    issues.append(Issue(filename,idx,m.start()+1,"MD042",f"Empty link found: {m.group(0)}"))
        if "MD045" in enabled:
            for m in re.finditer(r"!\[\s*\]\([^)]+\)", raw):
                issues.append(Issue(filename,idx,m.start()+1,"MD045","Images should have alternate text (alt text)"))
        if "MD039" in enabled:
            for m in re.finditer(r"\[\s+[^]]*]|\[[^]]*?\s+]", raw):
                issues.append(Issue(filename,idx,m.start()+1,"MD039","Spaces inside link text",True))
        if "MD038" in enabled:
            for m in re.finditer(r"`\s+[^`]*`|`[^`]*?\s+`", raw):
                issues.append(Issue(filename,idx,m.start()+1,"MD038","Spaces inside code span elements",True))
        if "MD037" in enabled:
            if re.search(r"(\*\s+[^*]|\s+\*)|(_\s+[^_]|\s+_)", raw):
                issues.append(Issue(filename,idx,1,"MD037","Spaces inside emphasis markers",True))
        if "MD027" in enabled and re.match(r"^>\s{2,}\S", raw):
            issues.append(Issue(filename,idx,2,"MD027","Multiple spaces after blockquote symbol",True))
        if "MD065" in enabled and is_hr(raw):
            if idx>1 and pure[idx-2].strip(): issues.append(Issue(filename,idx,1,"MD065","Horizontal rules should be surrounded by blank lines",True))
            if idx<len(pure) and pure[idx].strip(): issues.append(Issue(filename,idx,1,"MD065","Horizontal rules should be surrounded by blank lines",True))
        for m in re.finditer(r"!?\[([^\]]+)\]\(([^)#][^)]*)\)", raw):
            links.append((idx,m.group(1),m.group(2).strip()))
        for m in re.finditer(r"\[([^\]]+)\]\(#([^)]+)\)", raw):
            if "MD051" in enabled and m.group(2) not in ids:
                issues.append(Issue(filename,idx,m.start()+1,"MD051",f"Link fragment does not match any heading: #{m.group(2)}"))
        dm=re.match(r"^\s*\[([^\]]+)\]:", raw)
        if dm: refs_defined.add(dm.group(1).lower())
        for m in re.finditer(r"!?\[[^\]]+\]\[([^\]]*)\]", raw):
            ref=m.group(1).lower()
            if ref: refs_used.append((idx,m.start()+1,ref))
    if "MD047" in enabled and text and not text.endswith("\n"):
        issues.append(Issue(filename,len(pure),len(pure[-1])+1,"MD047","Files should end with a single newline character",True))
    if "MD052" in enabled:
        for ln,col,ref in refs_used:
            if ref not in refs_defined: issues.append(Issue(filename,ln,col,"MD052",f"Reference link/image uses undefined reference: {ref}"))
    if "MD053" in enabled:
        used={r for _,_,r in refs_used}
        for ref in refs_defined-used:
            issues.append(Issue(filename,1,1,"MD053",f"Link and image reference definitions should be needed: {ref}",True))
    if "MD057" in enabled:
        base=Path(filename).parent
        for ln,txt,dest in links:
            if re.match(r"^[a-z]+:", dest) or dest.startswith("#") or dest.startswith("mailto:"): continue
            target=dest.split("#",1)[0]
            if target and not (base/target).exists():
                issues.append(Issue(filename,ln,1,"MD057",f"Relative link points to non-existent file: {target}"))
    return issues

def fix_text(text):
    lines = text.splitlines(True)
    out=[]; blank=0; in_code=False
    for l in lines:
        nl = "\n" if l.endswith("\n") else ""
        s = l[:-1] if nl else l
        fm=is_fence(s)
        if fm: in_code=not in_code
        if not in_code:
            s = re.sub(r"^(#{1,6})([^\s#].*)$", r"\1 \2", s)
            s = re.sub(r"^(#{1,6}) {2,}", r"\1 ", s)
            hm = re.match(r"^(#{1,6}\s+.*?)([.,;:!])(\s*#*\s*)$", s)
            if hm:
                s = hm.group(1) + hm.group(3)
            s = re.sub(r"^(>\s*)\s+", r"\1", s)
            s = re.sub(r"^(\s*[-+*])\s{2,}", r"\1 ", s)
            s = re.sub(r"(?<![<(])(https?://[^\s>)]+)", r"<\1>", s)
            s = re.sub(r"[ \t]+$", "", s)
        if s.strip()=="":
            blank += 1
            if blank > 1: continue
        else:
            blank = 0
        out.append(s+nl)
    # Add missing blank lines around common block elements.
    spaced=[]
    for line in out:
        s=line.rstrip("\n")
        block = is_heading(s) or is_hr(s) or is_fence(s)
        if block and spaced and spaced[-1].strip():
            spaced.append("\n")
        spaced.append(line)
    out2=[]
    for i,line in enumerate(spaced):
        out2.append(line)
        s=line.rstrip("\n")
        block = is_heading(s) or is_hr(s) or is_fence(s)
        if block and i+1 < len(spaced) and spaced[i+1].strip():
            out2.append("\n")
    res="".join(out2)
    if res and not res.endswith("\n"): res += "\n"
    return res

def collect_paths(paths, include, exclude):
    if not paths: paths=["."]
    result=[]
    for p in paths:
        if p=="-": result.append("-"); continue
        pp=Path(p)
        if pp.is_dir():
            for f in pp.rglob("*"):
                if f.is_file() and f.suffix.lower() in (".md",".markdown",".mdown",".mkd",".qmd",".mdx"):
                    result.append(str(f))
        elif pp.exists():
            result.append(str(pp))
    def ok(p):
        sp=str(p)
        if include and not any(fnmatch.fnmatch(sp,pat) for pat in include): return False
        if any(fnmatch.fnmatch(sp,pat) or fnmatch.fnmatch(Path(sp).name,pat) for pat in exclude): return False
        return True
    return [p for p in result if p=="-" or ok(p)]

def enabled_rules(args, cfg):
    allr={r[0] for r in RULES} - OPT_IN
    en=set(norm_rule(x) for x in re.split(r",", args.enable or "") if x.strip()) or set(cfg["enable"])
    if en: allr = en
    dis=set(cfg["disable"])
    for val in [getattr(args,"disable",None), getattr(args,"extend_disable",None)]:
        if val: dis.update(norm_rule(x) for x in re.split(r",",val) if x.strip())
    if getattr(args,"extend_enable",None):
        allr.update(norm_rule(x) for x in re.split(r",",args.extend_enable) if x.strip())
    return {r for r in allr if r not in dis and r in RULEMAP}

def print_issues(issues, outfmt, quiet=False, stats=False, stream=sys.stdout):
    if outfmt in ("json",):
        print(json.dumps([i.obj() for i in issues], indent=2), file=stream); return
    if outfmt == "json-lines":
        for i in issues: print(json.dumps(i.obj()), file=stream)
        return
    if outfmt == "github":
        for i in issues: print(f"::{i.sev()} file={i.file},line={i.line},col={i.col},title={i.rule}::{i.msg}", file=stream)
        return
    if outfmt == "pylint":
        for i in issues: print(f"{i.file}:{i.line}:{i.col}: {i.rule}: {i.msg}", file=stream)
        return
    for i in issues:
        suffix = " [*]" if i.fixable and outfmt not in ("concise",) else ""
        print(f"{i.file}:{i.line}:{i.col}: [{i.rule}] {i.msg}{suffix}", file=stream)
    if issues and not quiet:
        files=len({i.file for i in issues})
        fix=sum(1 for i in issues if i.fixable)
        print(file=stream)
        print(f"Issues: Found {len(issues)} issue{'s' if len(issues)!=1 else ''} in {files} file{'s' if files!=1 else ''} (0ms)", file=stream)
        if fix: print(f"Run `rumdl fmt` to automatically fix {fix} of the {len(issues)} issues", file=stream)
    if stats and issues:
        counts={}
        for i in issues: counts[i.rule]=counts.get(i.rule,0)+1
        print("\nRule statistics:", file=stream)
        for k in sorted(counts): print(f"  {k}: {counts[k]}", file=stream)

def cmd_check(argv, fmt_alias=False):
    p=argparse.ArgumentParser(prog=f"executable {'fmt' if fmt_alias else 'check'}", description="Format Markdown files (alias for check --fix)" if fmt_alias else "Lint Markdown files and print warnings/errors")
    p.add_argument("paths", nargs="*"); p.add_argument("-f","--fix", action="store_true"); p.add_argument("--diff", action="store_true"); p.add_argument("--check", action="store_true")
    p.add_argument("-l","--list-rules", action="store_true"); p.add_argument("-d","--disable"); p.add_argument("-e","--enable", "--rules", dest="enable")
    p.add_argument("--extend-enable"); p.add_argument("--extend-disable"); p.add_argument("--exclude"); p.add_argument("--include"); p.add_argument("--no-exclude", action="store_true")
    p.add_argument("--respect-gitignore", nargs="?"); p.add_argument("-v","--verbose", action="store_true"); p.add_argument("--color", default="auto"); p.add_argument("--profile", action="store_true")
    p.add_argument("--config"); p.add_argument("--statistics", action="store_true"); p.add_argument("--no-config", action="store_true"); p.add_argument("-q","--quiet", action="store_true")
    p.add_argument("--isolated", action="store_true"); p.add_argument("-o","--output", default="text"); p.add_argument("--output-format", default=None); p.add_argument("--show-full-path", action="store_true")
    p.add_argument("--flavor"); p.add_argument("--stdin", action="store_true"); p.add_argument("--stdin-filename", default="stdin.md"); p.add_argument("--stderr", action="store_true")
    p.add_argument("-s","--silent", action="store_true"); p.add_argument("-w","--watch", action="store_true"); p.add_argument("--force-exclude", action="store_true")
    p.add_argument("--no-cache", action="store_true"); p.add_argument("--cache-dir"); p.add_argument("--fail-on", default="any", choices=["any","warning","error","never"])
    args=p.parse_args(argv)
    if fmt_alias: args.fix=True
    if args.list_rules:
        list_rules(); return 0
    cfg=parse_config(None if (args.no_config or args.isolated) else args.config)
    if args.exclude and not args.no_exclude: cfg["exclude"].extend([x for x in args.exclude.split(",") if x])
    if args.include: cfg["include"].extend([x for x in args.include.split(",") if x])
    rules=enabled_rules(args,cfg)
    paths=["-"] if args.stdin else collect_paths(args.paths, cfg["include"], [] if args.no_exclude else cfg["exclude"])
    issues=[]; file_texts={}
    for path in paths:
        name=args.stdin_filename if path=="-" else (str(Path(path).resolve()) if args.show_full_path else path)
        try:
            text=sys.stdin.read() if path=="-" else Path(path).read_text(errors="ignore")
        except Exception as e:
            print(f"error: {path}: {e}", file=sys.stderr); continue
        file_texts[path]=text
        issues.extend(lint_text(text,name,rules,cfg))
    if args.silent:
        pass
    elif args.fix:
        fixed=0
        for path,text in file_texts.items():
            new=fix_text(text)
            if new!=text:
                fixed += 1
                if path!="-" and not args.check and not args.diff:
                    Path(path).write_text(new)
        for i in issues:
            suffix=" [fixed]" if i.fixable else ""
            print(f"{i.file}:{i.line}:{i.col}: [{i.rule}] {i.msg}{suffix}", file=sys.stderr if args.stderr else sys.stdout)
        if issues and not args.quiet:
            print(file=sys.stderr if args.stderr else sys.stdout)
            print(f"Fixed: Fixed {sum(1 for i in issues if i.fixable)}/{len(issues)} issues in {len(set(i.file for i in issues))} file (0ms)", file=sys.stderr if args.stderr else sys.stdout)
    else:
        print_issues(issues, args.output_format or args.output, args.quiet, args.statistics, sys.stderr if args.stderr else sys.stdout)
    if args.fail_on=="never": return 0
    if args.fail_on=="error": return 1 if any(i.sev()=="error" for i in issues) else 0
    return 1 if issues else 0

def list_rules():
    print("Available rules:")
    for code,name,summary,cat,fix,fa in RULES:
        print(f"  {code} - {summary}")
    print(f"\nTotal: {len(RULES)} rules")

def cmd_rule(argv):
    p=argparse.ArgumentParser(prog="executable rule", description="Show information about a rule or list all rules")
    p.add_argument("rule", nargs="?"); p.add_argument("-o","--output-format", default="text", dest="fmt"); p.add_argument("-f","--fixable", action="store_true")
    p.add_argument("-c","--category"); p.add_argument("--explain", action="store_true"); p.add_argument("--list-categories", action="store_true")
    p.add_argument("--color", default="auto"); p.add_argument("--config"); p.add_argument("--no-config", action="store_true"); p.add_argument("--isolated", action="store_true")
    a=p.parse_args(argv)
    if a.list_categories:
        cats={}
        for r in RULES: cats[r[3]]=cats.get(r[3],0)+1
        print("Available categories:")
        for c in sorted(cats): print(f"  {c} ({cats[c]} rules)")
        return 0
    rows=RULES
    if a.rule:
        rr=norm_rule(a.rule)
        rows=[r for r in RULES if r[0]==rr or r[1].lower()==a.rule.lower()]
        if not rows:
            print(f"Error: Unknown rule '{a.rule}'", file=sys.stderr); return 1
    if a.fixable: rows=[r for r in rows if r[4]]
    if a.category: rows=[r for r in rows if r[3]==a.category]
    if a.fmt=="json":
        data=[rule_obj(r,a.explain) for r in rows]
        print(json.dumps(data[0] if a.rule and data else data, indent=2)); return 0
    if a.fmt=="json-lines":
        for r in rows: print(json.dumps(rule_obj(r,a.explain)))
        return 0
    if a.rule and rows:
        r=rows[0]
        print(f"{r[0]} - {r[2]}\n")
        print(f"Name: {r[1]}")
        print(f"Category: {r[3]}")
        print(f"Fix: {'Fix is always available.' if r[4] else 'Fix is not available.'}")
        print(f"Documentation: https://rumdl.dev/{r[0].lower()}/")
    else:
        list_rules()
    return 0

def rule_obj(r, explain=False):
    d={"code":r[0],"name":r[1],"aliases":[],"summary":r[2],"category":r[3],
       "fix":"Fix is always available." if r[4] else "Fix is not available.",
       "fix_availability":r[5],"url":f"https://rumdl.dev/{r[0].lower()}/"}
    if explain: d["explanation"]=f"{r[0]} checks: {r[2]}"
    return d

def cmd_explain(argv):
    if not argv: print("error: a rule is required", file=sys.stderr); return 2
    rr=norm_rule(argv[0]); r=RULEMAP.get(rr)
    if not r: print(f"Error: Unknown rule '{argv[0]}'", file=sys.stderr); return 1
    print(f"{r[0]} - {r[2]}\n\nAliases: `{r[1]}`\n\nWhat this rule does\n\nChecks Markdown for: {r[2]}.\n\nConfiguration\n\n```toml\n[{r[0]}]\n# rule-specific options may be configured here\n```")
    return 0

def cmd_config(argv):
    if argv and argv[0]=="file":
        for p in [".rumdl.toml","rumdl.toml","pyproject.toml"]:
            if Path(p).exists(): print(str(Path(p).resolve())); return 0
        return 1
    if argv and argv[0]=="get":
        key=argv[1] if len(argv)>1 else ""
        defaults={"global.exclude":"[]","global.enable":"[]","global.disable":"[]","MD013.line_length":"80","MD013.line-length":"80"}
        print(defaults.get(key,"null")); return 0
    print("[global]\nenable = []\ndisable = []\nexclude = []\ninclude = []\nrespect_gitignore = true\nflavor = Standard\n\n[MD013]\nline-length = 80\n")
    return 0

def cmd_init(argv):
    py="--pyproject" in argv
    path=Path("pyproject.toml" if py else ".rumdl.toml")
    if path.exists():
        print(f"Configuration file already exists: {path}", file=sys.stderr); return 1
    content='[tool.rumdl]\n' if py else '[global]\n'
    content += 'disable = []\nexclude = []\n\n[MD013]\nline-length = 80\n'
    path.write_text(content)
    print(f"Created configuration file: {path}")
    return 0

def cmd_schema(argv):
    schema={"$schema":"http://json-schema.org/draft-07/schema#","title":"rumdl configuration","type":"object"}
    if argv and argv[0]=="print": print(json.dumps(schema,indent=2)); return 0
    if argv and argv[0]=="check": print("Schema is up to date"); return 0
    if argv and argv[0]=="generate":
        Path("rumdl.schema.json").write_text(json.dumps(schema,indent=2)); print("Generated rumdl.schema.json"); return 0
    print("Usage: executable schema <generate|check|print>"); return 2

def main():
    argv=sys.argv[1:]
    if not argv or argv[0] in ("-h","--help","help"):
        print("""A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)

Usage: executable [OPTIONS] <COMMAND>

Commands:
  check        Lint Markdown files and print warnings/errors
  fmt          Format Markdown files (alias for check --fix)
  init         Initialize a new configuration file
  rule         Show information about a rule or list all rules
  explain      Explain a rule with detailed information and examples
  config       Show configuration or query a specific key
  server       Start the Language Server Protocol server
  schema       Generate or check JSON schema for rumdl.toml
  import       Import and convert markdownlint configuration files
  vscode       Install the rumdl VS Code extension
  completions  Generate shell completion scripts
  clean        Clear the cache
  version      Show version information
  help         Print this message or the help of the given subcommand(s)

Options:
      --color <COLOR>    Control colored output: auto, always, never [default: auto]
      --config <CONFIG>  Path to configuration file
      --no-config        Ignore all configuration files and use built-in defaults
      --isolated         Ignore all configuration files (alias for --no-config)
  -h, --help             Print help
  -V, --version          Print version"""); return 0
    if argv[0] in ("-V","--version","version"): print(f"rumdl {VERSION}"); return 0
    # swallow global options
    while argv and argv[0] in ("--color","--config"):
        argv=argv[2:]
    while argv and argv[0] in ("--no-config","--isolated"):
        argv=argv[1:]
    cmd=argv[0]; rest=argv[1:]
    if cmd=="check": return cmd_check(rest,False)
    if cmd=="fmt": return cmd_check(rest,True)
    if cmd=="rule": return cmd_rule(rest)
    if cmd=="explain": return cmd_explain(rest)
    if cmd=="config": return cmd_config(rest)
    if cmd=="init": return cmd_init(rest)
    if cmd=="schema": return cmd_schema(rest)
    if cmd=="clean": print("Cache cleared"); return 0
    if cmd=="completions":
        if "-l" in rest or "--list" in rest: print("bash\nelvish\nfish\npowershell\nzsh")
        else: print("# completion script")
        return 0
    if cmd in ("server","vscode","import"):
        print(f"{cmd} command is not available in this reimplementation", file=sys.stderr); return 1
    print(f"error: unrecognized subcommand '{cmd}'", file=sys.stderr); return 2

if __name__ == "__main__":
    sys.exit(main())
