#!/usr/bin/env python3
import fnmatch
import grp
import os
import pwd
import re
import shlex
import shutil
import stat
import subprocess
import sys
import time
from datetime import datetime


VERSION = "fd 10.3.0"


HELP = """A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)
  [path]...  the root directories for the filesystem search (optional)

Options:
  -H, --hidden                     Search hidden files and directories
  -I, --no-ignore                  Do not respect .(git|fd)ignore files
  -s, --case-sensitive             Case-sensitive search (default: smart case)
  -i, --ignore-case                Case-insensitive search (default: smart case)
  -g, --glob                       Glob-based search (default: regular expression)
  -a, --absolute-path              Show absolute instead of relative paths
  -l, --list-details               Use a long listing format with file metadata
  -L, --follow                     Follow symbolic links
  -p, --full-path                  Search full abs. path (default: filename only)
  -0, --print0                     Separate results by the null character
  -d, --max-depth <depth>          Set maximum search depth (default: none)
      --min-depth <depth>          Only show results starting at this depth
      --exact-depth <depth>        Only show results at this depth
  -E, --exclude <pattern>          Exclude entries that match the given glob pattern
  -t, --type <filetype>            Filter by type: file, directory, symlink, executable, empty, ...
  -e, --extension <ext>            Filter by file extension
  -x, --exec <cmd>...              Execute a command for each search result
  -X, --exec-batch <cmd>...        Execute a command once with all results
  -c, --color <when>               When to use colors: auto, always, never
  -j, --threads <num>              Set number of threads
  -q, --quiet                      Exit 0 if there is a result, otherwise 1
  -h, --help                       Print help
  -V, --version                    Print version
"""


LONG_HELP = """A program to find entries in your filesystem

Usage: executable [OPTIONS] [pattern] [path]...

Arguments:
  [pattern]
          the search pattern which is either a regular expression (default) or a glob pattern (if
          --glob is used). If no pattern has been specified, every entry is considered a match.

  [path]...
          The directory where the filesystem search is rooted (optional). If omitted, search the
          current working directory.

Options:
  -H, --hidden
          Include hidden directories and files in the search results.
  -I, --no-ignore
          Show search results from files and directories that would otherwise be ignored.
  -u, --unrestricted...
          Perform an unrestricted search, including ignored and hidden files.
  -s, --case-sensitive
          Perform a case-sensitive search.
  -i, --ignore-case
          Perform a case-insensitive search.
  -g, --glob
          Perform a glob-based search instead of a regular expression search.
      --regex
          Perform a regular-expression based search (default).
  -F, --fixed-strings
          Treat the pattern as a literal string.
      --and <pattern>
          Add additional required search patterns.
  -a, --absolute-path
          Shows the full path starting from the root.
  -l, --list-details
          Use a detailed listing format like 'ls -l'.
  -L, --follow
          Traverse symbolic links to directories.
  -p, --full-path
          Match the pattern against the full path.
  -0, --print0
          Separate search results by the null character.
  -d, --max-depth <depth>
          Limit the directory traversal to a given depth.
      --min-depth <depth>
          Only show search results starting at the given depth.
      --exact-depth <depth>
          Only show search results at the exact given depth.
  -E, --exclude <pattern>
          Exclude files/directories that match the given glob pattern.
      --prune
          Do not traverse into directories that match the search criteria.
  -t, --type <filetype>
          Filter the search by type.
  -e, --extension <ext>
          Filter search results by their file extension.
  -S, --size <size>
          Limit results based on the size of files.
      --changed-within <date|dur>
          Filter results based on modification time.
      --changed-before <date|dur>
          Filter results based on modification time.
  -x, --exec <cmd>...
          Execute the given command for each search result.
  -X, --exec-batch <cmd>...
          Execute the given command once, with all search results as arguments.
  -q, --quiet
          Do not print anything, exit status indicates if there was a match.
  -C, --base-directory <path>
          Change the current working directory of fd to the provided path.
      --search-path <search-path>
          Provide paths to search as an alternative to the positional path argument.
      --path-separator <separator>
          Set the path separator to use when printing file paths.
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version

Bugs can be reported on GitHub: https://github.com/sharkdp/fd/issues
"""


class Options:
    def __init__(self):
        self.hidden = False
        self.ignore = True
        self.ignore_vcs = True
        self.case = "smart"
        self.glob = False
        self.fixed = False
        self.absolute = False
        self.list_details = False
        self.follow = False
        self.full_path = False
        self.print0 = False
        self.max_depth = None
        self.min_depth = 1
        self.excludes = []
        self.types = []
        self.extensions = []
        self.size_filters = []
        self.changed_within = None
        self.changed_before = None
        self.owner = None
        self.prune = False
        self.max_results = None
        self.quiet = False
        self.search_paths = []
        self.base_directory = None
        self.path_separator = os.sep
        self.strip_cwd_prefix = "auto"
        self.format = None
        self.execs = []
        self.exec_batches = []
        self.batch_size = 0
        self.patterns = []
        self.positional = []
        self.color = "auto"
        self.hyperlink = "never"
        self.show_errors = False


def die(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)


def need_arg(argv, i, opt):
    if i + 1 >= len(argv):
        die(f"error: a value is required for '{opt}' but none was supplied\n\nFor more information, try '--help'.")
    return argv[i + 1], i + 1


def parse_int(s, opt):
    try:
        n = int(s)
        if n < 0:
            raise ValueError
        return n
    except ValueError:
        die(f"error: invalid value '{s}' for '{opt} <depth>': invalid digit found in string\n\nFor more information, try '--help'.")


def read_command(argv, i):
    cmd = []
    while i < len(argv):
        if argv[i] == ";":
            return cmd, i
        cmd.append(argv[i])
        i += 1
    return cmd, i


def parse_args(argv):
    opt = Options()
    i = 0
    stop_opts = False
    while i < len(argv):
        a = argv[i]
        if stop_opts:
            opt.positional.append(a)
            i += 1
            continue
        if a == "--":
            stop_opts = True
            i += 1
            continue
        if a in ("-h", "--help"):
            print(HELP if a == "-h" else LONG_HELP)
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-x", "--exec"):
            cmd, i = read_command(argv, i + 1)
            if not cmd:
                die("error: a value is required for '--exec <cmd>...' but none was supplied")
            opt.execs.append(cmd)
            if i < len(argv) and argv[i] == ";":
                i += 1
            continue
        if a in ("-X", "--exec-batch"):
            cmd, i = read_command(argv, i + 1)
            if not cmd:
                die("error: a value is required for '--exec-batch <cmd>...' but none was supplied")
            opt.exec_batches.append(cmd)
            if i < len(argv) and argv[i] == ";":
                i += 1
            continue
        if a.startswith("--"):
            name, eq, val = a.partition("=")
            def value():
                nonlocal i, val
                if eq:
                    return val
                val, i = need_arg(argv, i, name)
                return val
            if name == "--hidden":
                opt.hidden = True
            elif name == "--no-hidden":
                opt.hidden = False
            elif name in ("--no-ignore",):
                opt.ignore = False
            elif name == "--ignore":
                opt.ignore = True
            elif name == "--no-ignore-vcs":
                opt.ignore_vcs = False
            elif name == "--ignore-vcs":
                opt.ignore_vcs = True
            elif name in ("--no-require-git", "--require-git", "--no-ignore-parent", "--one-file-system", "--mount", "--xdev"):
                pass
            elif name in ("--unrestricted",):
                opt.hidden = True; opt.ignore = False
            elif name == "--case-sensitive":
                opt.case = "sensitive"
            elif name == "--ignore-case":
                opt.case = "insensitive"
            elif name == "--glob":
                opt.glob = True; opt.fixed = False
            elif name == "--regex":
                opt.glob = False
            elif name == "--fixed-strings":
                opt.fixed = True; opt.glob = False
            elif name == "--and":
                opt.patterns.append(value())
            elif name == "--absolute-path":
                opt.absolute = True
            elif name == "--relative-path":
                opt.absolute = False
            elif name == "--list-details":
                opt.list_details = True
            elif name == "--follow":
                opt.follow = True
            elif name == "--no-follow":
                opt.follow = False
            elif name == "--full-path":
                opt.full_path = True
            elif name == "--print0":
                opt.print0 = True
            elif name == "--max-depth":
                opt.max_depth = parse_int(value(), "--max-depth")
            elif name == "--min-depth":
                opt.min_depth = parse_int(value(), "--min-depth")
            elif name == "--exact-depth":
                d = parse_int(value(), "--exact-depth"); opt.min_depth = d; opt.max_depth = d
            elif name == "--exclude":
                opt.excludes.append(value())
            elif name == "--prune":
                opt.prune = True
            elif name == "--type":
                opt.types.append(normal_type(value()))
            elif name == "--extension":
                opt.extensions.append(value().lower().lstrip("."))
            elif name == "--size":
                opt.size_filters.append(parse_size(value()))
            elif name in ("--changed-within", "--change-newer-than", "--newer", "--changed-after"):
                opt.changed_within = parse_time_filter(value())
            elif name in ("--changed-before", "--change-older-than", "--older"):
                opt.changed_before = parse_time_filter(value())
            elif name == "--owner":
                opt.owner = value()
            elif name == "--color":
                opt.color = value()
            elif name == "--hyperlink":
                opt.hyperlink = val if eq else "auto"
            elif name == "--threads":
                value()
            elif name == "--max-results":
                opt.max_results = parse_int(value(), "--max-results")
            elif name == "--quiet" or name == "--has-results":
                opt.quiet = True; opt.max_results = 1
            elif name == "--show-errors":
                opt.show_errors = True
            elif name == "--base-directory":
                opt.base_directory = value()
            elif name == "--search-path":
                opt.search_paths.append(value())
            elif name == "--path-separator":
                opt.path_separator = value()
            elif name == "--strip-cwd-prefix":
                opt.strip_cwd_prefix = val if eq else "always"
            elif name == "--format":
                opt.format = value()
            elif name == "--batch-size":
                opt.batch_size = int(value())
            elif name in ("--ignore-file", "--ignore-contain"):
                # Implemented as best effort elsewhere only for ignore-file.
                if name == "--ignore-file":
                    opt.excludes.extend(load_ignore_file(value()))
                else:
                    value()
            else:
                die(f"error: unexpected argument '{a}' found\n\nFor more information, try '--help'.")
            i += 1
            continue
        if a.startswith("-") and a != "-":
            # short options, including -tf and -d3 forms
            j = 1
            while j < len(a):
                ch = a[j]
                rest = a[j + 1:]
                if ch == "H": opt.hidden = True
                elif ch == "I": opt.ignore = False
                elif ch == "u": opt.hidden = True; opt.ignore = False
                elif ch == "s": opt.case = "sensitive"
                elif ch == "i": opt.case = "insensitive"
                elif ch == "g": opt.glob = True; opt.fixed = False
                elif ch == "F": opt.fixed = True; opt.glob = False
                elif ch == "a": opt.absolute = True
                elif ch == "l": opt.list_details = True
                elif ch == "L": opt.follow = True
                elif ch == "p": opt.full_path = True
                elif ch == "0": opt.print0 = True
                elif ch == "q": opt.quiet = True; opt.max_results = 1
                elif ch == "1": opt.max_results = 1
                elif ch in "dEtTeSCo cj":
                    if ch == " ":
                        pass
                    arg = rest
                    if not arg:
                        arg, i = need_arg(argv, i, "-" + ch)
                    if ch == "d": opt.max_depth = parse_int(arg, "--max-depth")
                    elif ch == "E": opt.excludes.append(arg)
                    elif ch == "t": opt.types.append(normal_type(arg))
                    elif ch == "e": opt.extensions.append(arg.lower().lstrip("."))
                    elif ch == "S": opt.size_filters.append(parse_size(arg))
                    elif ch == "C": opt.base_directory = arg
                    elif ch == "o": opt.owner = arg
                    elif ch in ("c", "j"): pass
                    j = len(a)
                    break
                elif ch == "x":
                    cmd, i = read_command(([rest] if rest else []) + argv[i + 1:], 0)
                    if rest:
                        opt.execs.append(cmd); i = len(argv)
                    else:
                        cmd, ni = read_command(argv, i + 1); opt.execs.append(cmd); i = ni
                        if i < len(argv) and argv[i] == ";": i += 1
                    j = len(a); break
                elif ch == "X":
                    cmd, ni = read_command(argv, i + 1); opt.exec_batches.append(cmd); i = ni
                    if i < len(argv) and argv[i] == ";": i += 1
                    j = len(a); break
                else:
                    die(f"error: unexpected argument '-{ch}' found\n\nFor more information, try '--help'.")
                j += 1
            i += 1
            continue
        opt.positional.append(a)
        i += 1

    if opt.positional:
        opt.patterns.insert(0, opt.positional[0])
        paths = opt.positional[1:]
    else:
        paths = []
    if opt.search_paths:
        paths = opt.search_paths
    opt.search_paths = paths or ["."]
    return opt


def normal_type(s):
    m = {
        "f": "file", "file": "file",
        "d": "dir", "dir": "dir", "directory": "dir",
        "l": "symlink", "symlink": "symlink",
        "x": "executable", "executable": "executable",
        "e": "empty", "empty": "empty",
        "s": "socket", "socket": "socket",
        "p": "pipe", "fifo": "pipe",
        "b": "block-device", "block-device": "block-device",
        "c": "char-device", "char-device": "char-device",
    }
    if s not in m:
        die(f"error: invalid value '{s}' for '--type <filetype>'\n  [possible values: file, directory, symlink, block-device, char-device, executable, empty, socket, pipe]\n\nFor more information, try '--help'.")
    return m[s]


def parse_size(s):
    m = re.match(r"^([+-]?)(\d+)([A-Za-z]*)$", s)
    if not m:
        die(f"error: invalid value '{s}' for '--size <size>'")
    sign, num, unit = m.groups()
    mults = {"": 1, "b": 1, "k": 1000, "m": 1000**2, "g": 1000**3, "t": 1000**4,
             "ki": 1024, "mi": 1024**2, "gi": 1024**3, "ti": 1024**4}
    unit = unit.lower()
    if unit not in mults:
        die(f"error: invalid value '{s}' for '--size <size>'")
    return sign or "=", int(num) * mults[unit]


def parse_time_filter(s):
    now = time.time()
    if s.startswith("@") and s[1:].isdigit():
        return float(s[1:])
    m = re.match(r"^(\d+)\s*([A-Za-z]+)$", s)
    if m:
        n = int(m.group(1)); u = m.group(2).lower()
        factors = {
            "s": 1, "sec": 1, "secs": 1, "second": 1, "seconds": 1,
            "m": 60, "min": 60, "mins": 60, "minute": 60, "minutes": 60,
            "h": 3600, "hr": 3600, "hour": 3600, "hours": 3600,
            "d": 86400, "day": 86400, "days": 86400,
            "w": 604800, "week": 604800, "weeks": 604800,
        }
        return now - n * factors.get(u, 1)
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s, fmt).timestamp()
        except ValueError:
            pass
    die(f"error: invalid value '{s}' for time filter")


def has_upper(s):
    return any(c.isupper() for c in s)


def compile_patterns(opt):
    compiled = []
    flags = 0
    pats = opt.patterns or []
    if opt.case == "insensitive" or (opt.case == "smart" and not any(has_upper(p) for p in pats)):
        flags = re.IGNORECASE
    for p in pats:
        if opt.fixed:
            compiled.append(("fixed", p, flags))
        elif opt.glob:
            compiled.append(("glob", p, flags))
        else:
            try:
                compiled.append(("regex", re.compile(p, flags), flags))
            except re.error as e:
                print("[fd error]: regex parse error:", file=sys.stderr)
                print(f"    {p}", file=sys.stderr)
                print(f"error: {e}", file=sys.stderr)
                print("\nNote: You can use the '--fixed-strings' option to search for a literal string instead of a regular expression. Alternatively, you can also use the '--glob' option to match on a glob pattern.", file=sys.stderr)
                sys.exit(1)
    return compiled


def load_ignore_file(path):
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return [ln.strip() for ln in f if ln.strip() and not ln.lstrip().startswith("#")]
    except OSError:
        return []


def find_git_root(path):
    cur = os.path.abspath(path)
    if os.path.isfile(cur):
        cur = os.path.dirname(cur)
    while True:
        if os.path.isdir(os.path.join(cur, ".git")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            return None
        cur = parent


def load_ignores_for_dir(path, opt):
    pats = []
    if not opt.ignore:
        return pats
    for name in (".fdignore", ".ignore"):
        pats.extend(load_ignore_file(os.path.join(path, name)))
    if opt.ignore_vcs:
        pats.extend(load_ignore_file(os.path.join(path, ".gitignore")))
    return pats


def inherited_ignores_for_root(root, opt):
    if not opt.ignore:
        return []
    root_abs = os.path.abspath(root)
    cwd = os.path.abspath(os.getcwd())
    dirs = []
    try:
        common = os.path.commonpath([cwd, root_abs])
    except ValueError:
        common = ""
    if common == cwd:
        cur = cwd
        dirs.append(cur)
        rel = os.path.relpath(root_abs, cwd)
        if rel != ".":
            for part in rel.split(os.sep)[:-1]:
                cur = os.path.join(cur, part)
                dirs.append(cur)
        if root_abs not in dirs:
            dirs.append(root_abs)
    else:
        dirs.append(root_abs)
    pats = []
    for d in dirs:
        pats.extend(load_ignores_for_dir(d, opt))
    return pats


def ignore_match(rel, name, pats):
    rel = rel.strip("/")
    matched = False
    for raw in pats:
        neg = raw.startswith("!")
        p = raw[1:] if neg else raw
        if not p:
            continue
        p = p.rstrip("/")
        hit = False
        if p.startswith("/"):
            p = p.lstrip("/")
            if fnmatch.fnmatch(rel, p) or rel.startswith(p + "/"):
                hit = True
        elif "/" in p:
            if fnmatch.fnmatch(rel, p) or rel.startswith(p + "/"):
                hit = True
        else:
            if fnmatch.fnmatch(name, p) or name == p:
                hit = True
        if hit:
            matched = not neg
    return matched


def is_hidden_path(rel):
    return any(part.startswith(".") and part not in ("", ".", "..") for part in rel.split(os.sep))


def depth_of(rel):
    if rel in ("", "."):
        return 0
    return len([p for p in rel.split(os.sep) if p])


def display_path(root, full, is_dir, opt, for_exec=False, force_absolute=False):
    if opt.absolute or force_absolute:
        out = os.path.abspath(full)
    else:
        out = os.path.relpath(full, os.getcwd())
        if out == ".":
            out = os.path.basename(os.path.abspath(full))
    if is_dir and not out.endswith(os.sep):
        out += os.sep
    if for_exec or opt.print0:
        if not opt.absolute and not out.startswith("."):
            if opt.strip_cwd_prefix in ("auto", "never"):
                out = "." + os.sep + out
    if not for_exec and not opt.print0 and opt.strip_cwd_prefix == "always" and out.startswith("." + os.sep):
        out = out[2:]
    if opt.path_separator != os.sep:
        out = out.replace(os.sep, opt.path_separator)
    return out


def match_one(kind, pat, flags, text):
    if kind == "fixed":
        return (pat.lower() in text.lower()) if flags & re.IGNORECASE else (pat in text)
    if kind == "regex":
        return pat.search(text) is not None
    # fd glob without slash matches basename exactly; with slash, path.
    if flags & re.IGNORECASE:
        return fnmatch.fnmatchcase(text.lower(), pat.lower())
    return fnmatch.fnmatchcase(text, pat)


def matches_patterns(path, name, opt, compiled):
    if not compiled:
        return True
    target = os.path.abspath(path) if opt.full_path else name
    if opt.full_path and not opt.absolute:
        target = os.path.relpath(path, os.getcwd())
    for kind, pat, flags in compiled:
        t = target
        if kind == "glob" and "/" not in pat:
            t = name
        if not match_one(kind, pat, flags, t):
            return False
    return True


def matches_exclude(rel, name, opt):
    return ignore_match(rel, name, opt.excludes)


def stat_type(path, st, is_link):
    mode = st.st_mode
    if is_link:
        return "symlink"
    if stat.S_ISDIR(mode):
        return "dir"
    if stat.S_ISREG(mode):
        return "file"
    if stat.S_ISSOCK(mode):
        return "socket"
    if stat.S_ISFIFO(mode):
        return "pipe"
    if stat.S_ISBLK(mode):
        return "block-device"
    if stat.S_ISCHR(mode):
        return "char-device"
    return "other"


def is_empty(path, typ):
    try:
        if typ == "dir":
            return not any(os.scandir(path))
        if typ == "file":
            return os.path.getsize(path) == 0
    except OSError:
        return False
    return False


def matches_filters(path, st, typ, opt):
    types = set(opt.types)
    if types:
        normal_types = types - {"empty", "executable"}
        ok = False
        if normal_types and typ in normal_types:
            ok = True
        if "executable" in types and typ == "file" and os.access(path, os.X_OK):
            ok = True
        if "empty" in types:
            if normal_types:
                ok = ok and is_empty(path, typ)
            elif is_empty(path, typ):
                ok = True
        if not ok:
            return False
    if opt.extensions:
        if typ not in ("file", "symlink"):
            return False
        ext = os.path.basename(path).rsplit(".", 1)
        e = ext[1].lower() if len(ext) == 2 else ""
        if e not in opt.extensions:
            return False
    for sign, size in opt.size_filters:
        if typ == "dir" or (typ == "symlink" and os.path.isdir(path)):
            return False
        actual = st.st_size
        if sign == "+" and actual < size:
            return False
        if sign == "-" and actual > size:
            return False
        if sign == "=" and actual != size:
            return False
    if opt.changed_within is not None and st.st_mtime <= opt.changed_within:
        return False
    if opt.changed_before is not None and st.st_mtime >= opt.changed_before:
        return False
    if opt.owner and not owner_matches(st, opt.owner):
        return False
    return True


def owner_matches(st, spec):
    user_spec, sep, group_spec = spec.partition(":")
    def check_user(token):
        neg = token.startswith("!")
        token = token[1:] if neg else token
        try:
            uid = int(token)
        except ValueError:
            try:
                uid = pwd.getpwnam(token).pw_uid
            except KeyError:
                return False
        res = st.st_uid == uid
        return not res if neg else res
    def check_group(token):
        neg = token.startswith("!")
        token = token[1:] if neg else token
        try:
            gid = int(token)
        except ValueError:
            try:
                gid = grp.getgrnam(token).gr_gid
            except KeyError:
                return False
        res = st.st_gid == gid
        return not res if neg else res
    if user_spec and not check_user(user_spec):
        return False
    if sep and group_spec and not check_group(group_spec):
        return False
    return True


def traverse(root, opt, compiled):
    results = []
    force_absolute = os.path.isabs(root)
    root = os.path.abspath(root)
    if not os.path.exists(root):
        print(f"[fd error]: Search path '{root}' is not a directory.", file=sys.stderr)
        return results
    def walk(cur, relcur, inherited_ignores):
        try:
            entries = list(os.scandir(cur))
        except OSError as e:
            if opt.show_errors:
                print(f"[fd error]: {e}", file=sys.stderr)
            return True
        entries.sort(key=lambda e: e.name)
        for ent in entries:
            name = ent.name
            rel = os.path.join(relcur, name) if relcur else name
            d = depth_of(rel)
            try:
                is_link = ent.is_symlink()
                st = ent.stat(follow_symlinks=opt.follow)
                lst = ent.stat(follow_symlinks=False)
            except OSError as e:
                if opt.show_errors:
                    print(f"[fd error]: {e}", file=sys.stderr)
                continue
            typ = stat_type(ent.path, lst if is_link and not opt.follow else st, is_link and not opt.follow)
            if not opt.hidden and is_hidden_path(rel):
                if typ == "dir":
                    continue
                continue
            if opt.ignore and ignore_match(rel, name, inherited_ignores):
                if typ == "dir":
                    continue
                continue
            if matches_exclude(rel, name, opt):
                if typ == "dir":
                    continue
                continue
            is_dir_for_walk = False
            try:
                is_dir_for_walk = ent.is_dir(follow_symlinks=opt.follow)
            except OSError:
                pass
            show = d >= opt.min_depth
            if opt.max_depth is not None and d > opt.max_depth:
                show = False
            matched = matches_patterns(ent.path, name, opt, compiled)
            if show and matched and matches_filters(ent.path, st, typ, opt):
                results.append((ent.path, typ == "dir", st, typ, force_absolute))
                if opt.max_results and len(results) >= opt.max_results:
                    return False
            if is_dir_for_walk and (opt.max_depth is None or d < opt.max_depth):
                if opt.prune and matched:
                    continue
                child_ignores = inherited_ignores + load_ignores_for_dir(ent.path, opt)
                if not walk(ent.path, rel, child_ignores):
                    return False
        return True
    walk(root, "", inherited_ignores_for_root(root, opt))
    return results


def format_replace(fmt, path):
    no_slash = path[:-1] if path.endswith(os.sep) else path
    parent = os.path.dirname(no_slash) or "."
    base = os.path.basename(no_slash)
    root, ext = os.path.splitext(no_slash)
    baseroot, _ = os.path.splitext(base)
    out = fmt.replace("{{", "\0LB\0").replace("}}", "\0RB\0")
    out = out.replace("{//}", parent).replace("{/.}", baseroot).replace("{/}", base).replace("{.}", root).replace("{}", path)
    return out.replace("\0LB\0", "{").replace("\0RB\0", "}")


def ls_line(path, st, typ, opt):
    mode = stat.filemode(st.st_mode)
    try:
        user = pwd.getpwuid(st.st_uid).pw_name
    except KeyError:
        user = str(st.st_uid)
    try:
        group = grp.getgrgid(st.st_gid).gr_name
    except KeyError:
        group = str(st.st_gid)
    mtime = time.strftime("%b %e %H:%M", time.localtime(st.st_mtime))
    target = ""
    raw = path[:-1] if path.endswith(os.sep) else path
    if os.path.islink(raw):
        try:
            target = " -> " + os.readlink(raw)
        except OSError:
            pass
    return f"{mode} {st.st_nlink} {user} {group} {st.st_size} {mtime} {path}{target}"


def command_args(cmd, path):
    has_placeholder = any(("{}" in c or "{/" in c or "{//}" in c or "{.}" in c or "{/." in c) for c in cmd)
    if not has_placeholder:
        return cmd + [path]
    args = []
    for c in cmd:
        args.append(format_replace(c, path))
    return args


def main():
    opt = parse_args(sys.argv[1:])
    if opt.base_directory:
        try:
            os.chdir(opt.base_directory)
        except OSError as e:
            die(f"[fd error]: {e}")
    compiled = compile_patterns(opt)
    all_results = []
    for root in opt.search_paths:
        all_results.extend(traverse(root, opt, compiled))
        if opt.max_results and len(all_results) >= opt.max_results:
            all_results = all_results[:opt.max_results]
            break
    if opt.quiet:
        sys.exit(0 if all_results else 1)
    if opt.list_details:
        for path, isdir, st, typ, force_abs in all_results:
            p = display_path(None, path, isdir, opt, for_exec=True, force_absolute=force_abs)
            print(ls_line(p, st, typ, opt))
        return
    if opt.execs:
        sep = "\0" if opt.print0 else None
        for path, isdir, st, typ, force_abs in all_results:
            p = display_path(None, path, isdir, opt, for_exec=True, force_absolute=force_abs)
            for cmd in opt.execs:
                subprocess.run(command_args(cmd, p))
            if opt.print0:
                sys.stdout.write("\0")
        return
    if opt.exec_batches:
        paths = [display_path(None, p, isdir, opt, for_exec=True, force_absolute=force_abs) for p, isdir, st, typ, force_abs in all_results]
        for cmd in opt.exec_batches:
            if any(("{}" in c or "{/" in c or "{//}" in c or "{.}" in c or "{/." in c) for c in cmd):
                args = []
                for p in paths:
                    args.extend(command_args(cmd, p))
            else:
                args = cmd + paths
            if args:
                subprocess.run(args)
        return
    out_sep = "\0" if opt.print0 else "\n"
    for path, isdir, st, typ, force_abs in all_results:
        p = display_path(None, path, isdir, opt, for_exec=False, force_absolute=force_abs)
        if opt.format:
            p = format_replace(opt.format, p)
        sys.stdout.write(p + out_sep)
    if opt.print0:
        sys.stdout.flush()


if __name__ == "__main__":
    main()
