package main

import (
	"bytes"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
)

const version = "v0.0.0-SNAPSHOT"

type checkerInfo struct {
	name string
	tags []string
}

var checkers = []checkerInfo{
	{"appendAssign", []string{"diagnostic"}}, {"appendCombine", []string{"performance"}}, {"argOrder", []string{"diagnostic"}},
	{"assignOp", []string{"style"}}, {"badCall", []string{"diagnostic"}}, {"badCond", []string{"diagnostic"}},
	{"badLock", []string{"diagnostic", "experimental"}}, {"badRegexp", []string{"diagnostic", "experimental"}},
	{"badSorting", []string{"diagnostic", "experimental"}}, {"badSyncOnceFunc", []string{"diagnostic", "experimental"}},
	{"boolExprSimplify", []string{"style", "experimental"}}, {"builtinShadow", []string{"style", "opinionated"}},
	{"builtinShadowDecl", []string{"diagnostic", "experimental"}}, {"captLocal", []string{"style"}},
	{"caseOrder", []string{"diagnostic"}}, {"codegenComment", []string{"diagnostic"}}, {"commentFormatting", []string{"style"}},
	{"commentedOutCode", []string{"diagnostic", "experimental"}}, {"commentedOutImport", []string{"style", "experimental"}},
	{"defaultCaseOrder", []string{"style"}}, {"deferInLoop", []string{"diagnostic", "experimental"}},
	{"deferUnlambda", []string{"style", "experimental"}}, {"deprecatedComment", []string{"diagnostic"}},
	{"docStub", []string{"style", "experimental"}}, {"dupArg", []string{"diagnostic"}}, {"dupBranchBody", []string{"diagnostic"}},
	{"dupCase", []string{"diagnostic"}}, {"dupImport", []string{"style", "experimental"}}, {"dupOption", []string{"diagnostic", "experimental"}},
	{"dupSubExpr", []string{"diagnostic"}}, {"dynamicFmtString", []string{"diagnostic", "experimental"}}, {"elseif", []string{"style"}},
	{"emptyDecl", []string{"diagnostic", "experimental"}}, {"emptyFallthrough", []string{"style", "experimental"}}, {"emptyStringTest", []string{"style", "experimental"}},
	{"equalFold", []string{"performance", "experimental"}}, {"evalOrder", []string{"diagnostic", "experimental"}}, {"exitAfterDefer", []string{"diagnostic"}},
	{"exposedSyncMutex", []string{"style", "experimental"}}, {"externalErrorReassign", []string{"diagnostic", "experimental"}},
	{"filepathJoin", []string{"diagnostic", "experimental"}}, {"flagDeref", []string{"diagnostic"}}, {"flagName", []string{"diagnostic"}},
	{"hexLiteral", []string{"style", "experimental"}}, {"httpNoBody", []string{"style", "experimental"}}, {"hugeParam", []string{"performance"}},
	{"ifElseChain", []string{"style"}}, {"importShadow", []string{"style", "opinionated"}}, {"indexAlloc", []string{"performance"}},
	{"initClause", []string{"style", "opinionated", "experimental"}}, {"mapKey", []string{"diagnostic"}}, {"methodExprCall", []string{"style", "experimental"}},
	{"nestingReduce", []string{"style", "opinionated", "experimental"}}, {"newDeref", []string{"style"}}, {"nilValReturn", []string{"diagnostic", "experimental"}},
	{"octalLiteral", []string{"style", "experimental", "opinionated"}}, {"offBy1", []string{"diagnostic"}}, {"paramTypeCombine", []string{"style", "opinionated"}},
	{"preferDecodeRune", []string{"performance", "experimental"}}, {"preferFilepathJoin", []string{"style", "experimental"}},
	{"preferFprint", []string{"performance", "experimental"}}, {"preferStringWriter", []string{"performance", "experimental"}},
	{"preferWriteByte", []string{"performance", "experimental", "opinionated"}}, {"ptrToRefParam", []string{"style", "opinionated", "experimental"}},
	{"rangeAppendAll", []string{"diagnostic", "experimental"}}, {"rangeExprCopy", []string{"performance"}}, {"rangeValCopy", []string{"performance"}},
	{"redundantSprint", []string{"style", "experimental"}}, {"regexpMust", []string{"style"}}, {"regexpPattern", []string{"diagnostic", "experimental"}},
	{"regexpSimplify", []string{"style", "experimental", "opinionated"}}, {"returnAfterHttpError", []string{"diagnostic", "experimental"}},
	{"ruleguard", []string{"style", "experimental"}}, {"singleCaseSwitch", []string{"style"}}, {"sliceClear", []string{"performance", "experimental"}},
	{"sloppyLen", []string{"diagnostic"}}, {"sloppyReassign", []string{"diagnostic", "experimental"}}, {"sloppyTypeAssert", []string{"diagnostic"}},
	{"sortSlice", []string{"diagnostic", "experimental"}}, {"sprintfQuotedString", []string{"diagnostic", "experimental"}}, {"sqlQuery", []string{"diagnostic", "experimental"}},
	{"stringConcatSimplify", []string{"style", "experimental"}}, {"stringXbytes", []string{"performance"}}, {"stringsCompare", []string{"style", "experimental"}},
	{"switchTrue", []string{"style"}}, {"syncMapLoadAndDelete", []string{"diagnostic", "experimental"}}, {"timeExprSimplify", []string{"style", "experimental"}},
	{"todoCommentWithoutDetail", []string{"style", "opinionated", "experimental"}}, {"tooManyResultsChecker", []string{"style", "opinionated", "experimental"}},
	{"truncateCmp", []string{"diagnostic", "experimental"}}, {"typeAssertChain", []string{"style", "experimental"}}, {"typeDefFirst", []string{"style", "experimental"}},
	{"typeSwitchVar", []string{"style"}}, {"typeUnparen", []string{"style", "opinionated"}}, {"uncheckedInlineErr", []string{"diagnostic", "experimental"}},
	{"underef", []string{"style"}}, {"unlabelStmt", []string{"style", "experimental"}}, {"unlambda", []string{"style"}},
	{"unnamedResult", []string{"style", "opinionated", "experimental"}}, {"unnecessaryBlock", []string{"style", "opinionated", "experimental"}},
	{"unnecessaryDefer", []string{"diagnostic", "experimental"}}, {"unslice", []string{"style"}}, {"valSwap", []string{"style"}},
	{"weakCond", []string{"diagnostic", "experimental"}}, {"whyNoLint", []string{"style", "experimental"}}, {"wrapperFunc", []string{"style"}},
	{"yodaStyleExpr", []string{"style", "experimental"}}, {"zeroByteRepeat", []string{"performance"}},
}

var defaultEnabled = strings.Split("appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc", ",")

type diag struct {
	pos     token.Position
	checker string
	msg     string
}

func main() {
	if len(os.Args) == 1 {
		fmt.Println("no args provided")
		return
	}
	switch os.Args[1] {
	case "help":
		printHelp()
	case "version":
		fmt.Printf("go-critic version: %s\n", version)
	case "doc":
		runDoc(os.Args[2:])
	case "check":
		runCheck(os.Args[2:])
	default:
		fmt.Printf("%q unknown command, did you mean \"help\"?\n", os.Args[1])
		fmt.Println("Run \"go-critic help\" for usage.")
		fmt.Printf("\nno such command %q\n", os.Args[1])
	}
}

func printHelp() {
	fmt.Printf(`Usage:

    go-critic <command> [arguments...]

The commands are:

    check             run linter over specified targets
    doc               get installed checkers documentation
    help              shows help message
    version           shows version of the application

Version: %s
`, version)
}

func runDoc(args []string) {
	if len(args) > 0 && args[0] == "-help" {
		fmt.Fprintln(os.Stderr, "Usage of go-critic:")
		fmt.Fprintln(os.Stderr, "flag: help requested")
		return
	}
	if len(args) == 0 {
		for _, c := range checkers {
			fmt.Printf("%s [%s]\n", c.name, strings.Join(c.tags, " "))
		}
		return
	}
	name := args[0]
	for _, c := range checkers {
		if c.name == name {
			printCheckerDoc(c)
			return
		}
	}
	fmt.Fprintf(os.Stderr, "checker with name %q not found\n", name)
	os.Exit(1)
}

func printCheckerDoc(c checkerInfo) {
	fmt.Printf("%s checker documentation\n", c.name)
	fmt.Println("URL: https://github.com/go-critic/go-critic/checkers")
	fmt.Printf("Tags: [%s]\n\n", strings.Join(c.tags, " "))
	switch c.name {
	case "appendAssign":
		fmt.Println("Detects suspicious append result assignments.\n")
		fmt.Println("Non-compliant code:")
		fmt.Println("p.positives = append(p.negatives, x)")
		fmt.Println("p.negatives = append(p.negatives, y)\n")
		fmt.Println("Compliant code:")
		fmt.Println("p.positives = append(p.positives, x)")
		fmt.Println("p.negatives = append(p.negatives, y)")
	case "badCall":
		fmt.Println("Detects suspicious function calls.\n")
		fmt.Println("Non-compliant code:")
		fmt.Println("strings.Replace(s, from, to, 0)\n")
		fmt.Println("Compliant code:")
		fmt.Println("strings.Replace(s, from, to, -1)")
	default:
		fmt.Printf("%s checker.\n", c.name)
	}
}

func runCheck(args []string) {
	fs := flag.NewFlagSet("go-critic", flag.ContinueOnError)
	fs.SetOutput(os.Stderr)
	enable := fs.String("enable", strings.Join(defaultEnabled, ","), "comma-separated list of enabled checkers. Can include #tags")
	disable := fs.String("disable", "", "comma-separated list of checkers to be disabled. Can include #tags")
	enableAll := fs.Bool("enableAll", false, "identical to -enable with all checkers listed. If true, -enable is ignored")
	exitCode := fs.Int("exitCode", 1, "exit code to be used when lint issues are found")
	checkTests := fs.Bool("checkTests", true, "whether to check test files")
	fs.Bool("checkGenerated", false, "whether to check generated files")
	fs.Int("concurrency", runtime.GOMAXPROCS(0), "how many concurrent checkers to run (default is runtime.GOMAXPROCS(0))")
	fs.String("cpuprofile", "", "write CPU profile to the specified file")
	fs.String("memprofile", "", "write memory profile to the specified file")
	fs.String("go", "", "select the Go version to target. Leave as string for the latest")
	fs.Bool("shorterErrLocation", true, "whether to replace error location prefix with $GOROOT and $GOPATH")
	fs.Bool("v", false, "whether to print output useful during linter debugging")
	addParamFlags(fs)
	if err := fs.Parse(args); err != nil {
		fmt.Fprintf(os.Stderr, "parse args: %v\n", err)
		os.Exit(1)
	}
	enabled := computeEnabled(*enable, *disable, *enableAll)
	files := collectFiles(fs.Args(), *checkTests)
	var out []diag
	for _, file := range files {
		out = append(out, lintFile(file, enabled)...)
	}
	sort.Slice(out, func(i, j int) bool {
		if out[i].checker != out[j].checker {
			return out[i].checker < out[j].checker
		}
		if out[i].pos.Filename != out[j].pos.Filename {
			return out[i].pos.Filename < out[j].pos.Filename
		}
		if out[i].pos.Line != out[j].pos.Line {
			return out[i].pos.Line < out[j].pos.Line
		}
		return out[i].pos.Column < out[j].pos.Column
	})
	for _, d := range out {
		fmt.Printf("%s:%d:%d: %s: %s\n", d.pos.Filename, d.pos.Line, d.pos.Column, d.checker, d.msg)
	}
	if len(out) != 0 {
		os.Exit(*exitCode)
	}
}

func addParamFlags(fs *flag.FlagSet) {
	fs.Bool("@captLocal.paramsOnly", true, "whether to restrict checker to params only")
	fs.Int("@commentedOutCode.minLength", 15, "min length of the comment that triggers a warning")
	fs.Bool("@elseif.skipBalanced", true, "whether to skip balanced if-else pairs")
	fs.Int("@hugeParam.sizeThreshold", 80, "size in bytes that makes the warning trigger")
	fs.Int("@ifElseChain.minThreshold", 2, "min number of if-else blocks that makes the warning trigger")
	fs.Int("@nestingReduce.bodyWidth", 5, "min number of statements inside a branch to trigger a warning")
	fs.Int("@rangeExprCopy.sizeThreshold", 512, "size in bytes that makes the warning trigger")
	fs.Bool("@rangeExprCopy.skipTestFuncs", true, "whether to check test functions")
	fs.Int("@rangeValCopy.sizeThreshold", 128, "size in bytes that makes the warning trigger")
	fs.Bool("@rangeValCopy.skipTestFuncs", true, "whether to check test functions")
	fs.String("@ruleguard.debug", "", "enable debug for the specified named rules group")
	fs.String("@ruleguard.disable", "", "comma-separated list of disabled groups or skip empty to enable everything")
	fs.String("@ruleguard.enable", "<all>", "comma-separated list of enabled groups or skip empty to enable everything")
	fs.String("@ruleguard.failOn", "", "Determines the behavior when an error occurs while parsing ruleguard files.")
	fs.Bool("@ruleguard.failOnError", false, "deprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''")
	fs.String("@ruleguard.rules", "", "comma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified")
	fs.Int("@tooManyResultsChecker.maxResults", 5, "maximum number of results")
	fs.Bool("@truncateCmp.skipArchDependent", true, "whether to skip int/uint/uintptr types")
	fs.Bool("@underef.skipRecvDeref", true, "whether to skip (*x).method() calls where x is a pointer receiver")
	fs.Bool("@unnamedResult.checkExported", false, "whether to check exported functions")
}

func computeEnabled(enable, disable string, all bool) map[string]bool {
	res := map[string]bool{}
	if all {
		for _, c := range checkers {
			res[c.name] = true
		}
	} else {
		for _, p := range splitCSV(enable) {
			addSelector(res, p, true)
		}
	}
	for _, p := range splitCSV(disable) {
		addSelector(res, p, false)
	}
	return res
}

func addSelector(m map[string]bool, sel string, val bool) {
	if strings.HasPrefix(sel, "#") {
		tag := strings.TrimPrefix(sel, "#")
		for _, c := range checkers {
			for _, t := range c.tags {
				if t == tag {
					m[c.name] = val
				}
			}
		}
		return
	}
	if sel != "" {
		m[sel] = val
	}
}

func splitCSV(s string) []string {
	var r []string
	for _, p := range strings.Split(s, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			r = append(r, p)
		}
	}
	return r
}

func collectFiles(args []string, checkTests bool) []string {
	seen := map[string]bool{}
	var files []string
	add := func(p string) {
		if !checkTests && strings.HasSuffix(p, "_test.go") {
			return
		}
		if !seen[p] {
			seen[p] = true
			files = append(files, p)
		}
	}
	for _, arg := range args {
		if strings.HasSuffix(arg, "/...") {
			root := strings.TrimSuffix(arg, "/...")
			if root == "" {
				root = "."
			}
			filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
				if err != nil {
					return nil
				}
				if d.IsDir() && (d.Name() == ".git" || d.Name() == "vendor") {
					return filepath.SkipDir
				}
				if !d.IsDir() && strings.HasSuffix(path, ".go") {
					add(path)
				}
				return nil
			})
			continue
		}
		st, err := os.Stat(arg)
		if err != nil {
			continue
		}
		if st.IsDir() {
			ents, _ := os.ReadDir(arg)
			for _, e := range ents {
				if !e.IsDir() && strings.HasSuffix(e.Name(), ".go") {
					add(filepath.Join(arg, e.Name()))
				}
			}
		} else if strings.HasSuffix(arg, ".go") {
			add(arg)
		}
	}
	sort.Strings(files)
	return files
}

func lintFile(path string, enabled map[string]bool) []diag {
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, nil, parser.ParseComments)
	if err != nil {
		return nil
	}
	src, _ := os.ReadFile(path)
	var out []diag
	emit := func(pos token.Pos, checker, msg string) {
		if enabled[checker] {
			out = append(out, diag{fset.Position(pos), checker, msg})
		}
	}
	ast.Inspect(file, func(n ast.Node) bool {
		switch x := n.(type) {
		case *ast.AssignStmt:
			checkAssign(x, emit)
		case *ast.CallExpr:
			checkCall(x, emit)
		case *ast.BinaryExpr:
			checkDupSubExpr(x, emit)
		case *ast.IfStmt:
			checkIf(x, src, fset, emit)
		case *ast.SwitchStmt:
			if len(x.Body.List) == 1 {
				emit(x.Switch, "singleCaseSwitch", "should rewrite switch statement to if statement")
			}
			if id, ok := x.Tag.(*ast.Ident); ok && id.Name == "true" {
				emit(x.Switch, "switchTrue", "replace 'switch true {}' with 'switch {}'")
			}
		case *ast.SliceExpr:
			if x.Low == nil && x.High == nil && x.Max == nil {
				emit(x.Lbrack, "unslice", fmt.Sprintf("could simplify %s to %s", exprString(fset, x), exprString(fset, x.X)))
			}
		case *ast.FuncDecl:
			checkParamTypeCombine(x.Type.Params, x.Pos(), fset, emit)
		case *ast.FuncLit:
			checkParamTypeCombine(x.Type.Params, x.Pos(), fset, emit)
		}
		return true
	})
	return out
}

func checkAssign(x *ast.AssignStmt, emit func(token.Pos, string, string)) {
	if len(x.Lhs) == 1 && len(x.Rhs) == 1 {
		if call, ok := x.Rhs[0].(*ast.CallExpr); ok && funName(call.Fun) == "append" && len(call.Args) > 0 {
			if exprString(nil, x.Lhs[0]) != exprString(nil, call.Args[0]) {
				emit(x.Rhs[0].Pos(), "appendAssign", "append result not assigned to the same slice")
			}
		}
	}
	if len(x.Lhs) == 1 && len(x.Rhs) == 1 && x.Tok == token.ASSIGN {
		if b, ok := x.Rhs[0].(*ast.BinaryExpr); ok {
			lhs := exprString(nil, x.Lhs[0])
			left := exprString(nil, b.X)
			right := exprString(nil, b.Y)
			if lhs == left {
				if op := assignOp(b.Op); op != "" {
					emit(x.Pos(), "assignOp", fmt.Sprintf("replace `%s = %s %s %s` with `%s %s= %s`", lhs, left, b.Op, right, lhs, op, right))
				}
			}
		}
	}
}

func assignOp(op token.Token) string {
	switch op {
	case token.ADD, token.SUB, token.MUL, token.QUO, token.REM, token.AND, token.OR, token.XOR, token.SHL, token.SHR:
		return op.String()
	}
	return ""
}

func checkCall(x *ast.CallExpr, emit func(token.Pos, string, string)) {
	name := funName(x.Fun)
	if name == "append" && len(x.Args) == 1 {
		emit(x.Pos(), "badCall", "no-op append call, probably missing arguments")
	}
	if (name == "strings.Replace" || name == "bytes.Replace") && len(x.Args) == 4 {
		if lit, ok := x.Args[3].(*ast.BasicLit); ok && lit.Value == "0" {
			emit(x.Args[3].Pos(), "badCall", "suspicious arg 0, probably meant -1")
		}
	}
}

func checkDupSubExpr(x *ast.BinaryExpr, emit func(token.Pos, string, string)) {
	switch x.Op {
	case token.EQL, token.NEQ, token.LSS, token.GTR, token.LEQ, token.GEQ, token.LAND, token.LOR:
		if exprString(nil, x.X) == exprString(nil, x.Y) {
			emit(x.OpPos, "dupSubExpr", fmt.Sprintf("suspicious identical LHS and RHS for `%s` operator", x.Op))
		}
	}
}

func checkIf(x *ast.IfStmt, src []byte, fset *token.FileSet, emit func(token.Pos, string, string)) {
	if x.Else != nil {
		if eb, ok := x.Else.(*ast.BlockStmt); ok && blockString(src, fset, x.Body) == blockString(src, fset, eb) {
			emit(x.If, "dupBranchBody", "both branches in if statement have same body")
		}
		if _, ok := x.Else.(*ast.IfStmt); ok {
			emit(x.Else.Pos(), "elseif", "can replace 'else {if cond {}}' with 'else if cond {}'")
		}
	}
}

func checkParamTypeCombine(fields *ast.FieldList, pos token.Pos, fset *token.FileSet, emit func(token.Pos, string, string)) {
	if fields == nil {
		return
	}
	for i := 0; i+1 < len(fields.List); i++ {
		a, b := fields.List[i], fields.List[i+1]
		if len(a.Names) == 1 && len(b.Names) == 1 && exprString(fset, a.Type) == exprString(fset, b.Type) {
			emit(pos, "paramTypeCombine", "func parameters can be combined with the same type")
			return
		}
	}
}

func blockString(src []byte, fset *token.FileSet, b *ast.BlockStmt) string {
	if b == nil || len(src) == 0 {
		return ""
	}
	start := fset.Position(b.Lbrace).Offset + 1
	end := fset.Position(b.Rbrace).Offset
	if start < 0 || end < start || end > len(src) {
		return ""
	}
	return strings.TrimSpace(string(src[start:end]))
}

func funName(e ast.Expr) string {
	switch x := e.(type) {
	case *ast.Ident:
		return x.Name
	case *ast.SelectorExpr:
		return exprString(nil, x.X) + "." + x.Sel.Name
	}
	return exprString(nil, e)
}

func exprString(_ *token.FileSet, e ast.Node) string {
	var b bytes.Buffer
	if e == nil {
		return ""
	}
	if err := format.Node(&b, token.NewFileSet(), e); err == nil {
		return b.String()
	}
	return fmt.Sprint(e)
}
