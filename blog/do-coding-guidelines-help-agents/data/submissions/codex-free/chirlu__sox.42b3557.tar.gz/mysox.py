#!/usr/bin/env python3
import sys, os, math, struct, random, re

VERSION = "SoX v14.4.2"

HELP = """./executable:      SoX v14.4.2

Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...

SPECIAL FILENAMES (infile, outfile):
-                        Pipe/redirect input/output (stdin/stdout); may need -t
-d, --default-device     Use the default audio device (where available)
-n, --null               Use the `null' file handler; e.g. with synth effect
-p, --sox-pipe           Alias for `-t sox -'

GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):
--buffer BYTES           Set the size of all processing buffers (default 8192)
--clobber                Don't prompt to overwrite output file (default)
--combine concatenate    Concatenate all input files (default for sox, rec)
--combine sequence       Sequence all input files (default for play)
-D, --no-dither          Don't dither automatically
-G, --guard              Use temporary files to guard against clipping
-h, --help               Display version number and usage information
--help-effect NAME       Show usage of effect NAME, or NAME=all for all
--help-format NAME       Show info on format NAME, or NAME=all for all
--i, --info              Behave as soxi(1)
-m, --combine mix        Mix multiple input files (instead of concatenating)
-M, --combine merge      Merge multiple input files (instead of concatenating)
-q, --no-show-progress   Run in quiet mode; opposite of -S
--version                Display version number of SoX and exit
-V[LEVEL]                Increment or set verbosity level (default 2)
FORMAT OPTIONS (fopts):
-v|--volume FACTOR       Input file volume adjustment factor (real number)
-t|--type FILETYPE       File type of audio
-e|--encoding ENCODING   Set encoding
-b|--bits BITS           Encoded sample size in bits
-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo
-r|--rate RATE           Sample rate of audio

AUDIO FILE FORMATS: aif aiff au dat f32 f64 raw s16 s24 s32 s8 u8 wav wavpcm
EFFECTS: channels fade gain norm pad rate repeat reverse silence speed stat stats synth trim vol
"""

EFFECT_HELP = {
 "trim":"trim {position}",
 "channels":"channels number",
 "rate":"rate [-q|-l|-m|-h|-v] [override-options] RATE[k]",
 "gain":"gain [-e|-b|-B|-r] [-n] [-l|-h] [gain-dB]",
 "vol":"vol gain [type [limitergain]]",
 "synth":"synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}",
 "stat":"stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]",
 "stats":"stats [-b bits|-x bits|-s scale] [-w window-time]",
 "reverse":"reverse",
 "repeat":"repeat count",
 "pad":"pad {length[@position]}",
 "fade":"fade [ type ] fade-in-length [ stop-time [ fade-out-length ] ]",
 "speed":"speed factor[c]",
 "norm":"norm [dB-level]",
}

class Audio:
    def __init__(self, rate=8000, channels=1, samples=None, bits=16, encoding="Signed Integer PCM"):
        self.rate = int(rate); self.channels = int(channels)
        self.samples = samples or []  # interleaved floats -1..1
        self.bits = int(bits); self.encoding = encoding
    @property
    def frames(self): return len(self.samples)//max(1,self.channels)
    @property
    def duration(self): return self.frames / self.rate if self.rate else 0.0

def prog(): return sys.argv[0] or "./executable"
def banner(): return f"{prog()}:      {VERSION}"
def fail(msg, code=1):
    print(f"{prog()} FAIL {msg}", file=sys.stderr); sys.exit(code)
def warn(msg): print(f"{prog()} WARN {msg}", file=sys.stderr)

def parse_num(s, rate=None):
    s=str(s).strip()
    if not s: return 0.0
    neg=s.startswith('-')
    if neg: s=s[1:]
    if ':' in s:
        parts=[float(x or 0) for x in s.split(':')]
        v=0
        for p in parts: v=v*60+p
    else:
        mul=1.0
        if s[-1:].lower()=='k': mul=1000.0; s=s[:-1]
        elif s[-1:]=='s': mul=1.0; s=s[:-1]
        v=float(s or 0)*mul
    return -v if neg else v

def time_to_frames(s, rate):
    v=parse_num(s, rate)
    return max(0, int(round(v*rate)))

def ext_type(path):
    if path == "-": return "raw"
    e=os.path.splitext(path.lower())[1].lstrip(".")
    if e in ("wav","wave"): return "wav"
    if e in ("raw","s16","s32","s8","u8","f32","f64"): return "raw"
    if e in ("dat",): return "dat"
    return e or "wav"

def read_wav(path):
    data = sys.stdin.buffer.read() if path=="-" else open(path,"rb").read()
    if data[:4] != b"RIFF" or data[8:12] != b"WAVE": fail(f"formats: can't open input file `{path}': WAVE: RIFF header not found")
    pos=12; fmt=None; pcm=b""
    while pos+8 <= len(data):
        cid=data[pos:pos+4]; size=struct.unpack_from("<I",data,pos+4)[0]; pos+=8
        chunk=data[pos:pos+size]; pos += size + (size&1)
        if cid==b"fmt ": fmt=chunk
        elif cid==b"data": pcm=chunk
    if not fmt: fail(f"formats: can't open input file `{path}': missing fmt chunk")
    tag,ch,rate,br,align,bits=struct.unpack_from("<HHIIHH",fmt,0)
    if tag == 0xfffe and len(fmt) >= 40:
        sub = fmt[24:40]
        if sub == bytes.fromhex("0100000000001000800000aa00389b71"):
            tag = 1
        elif sub == bytes.fromhex("0300000000001000800000aa00389b71"):
            tag = 3
    samples=[]
    if tag == 3 and bits in (32,64):
        step=bits//8; fm="<f" if bits==32 else "<d"
        for i in range(0,len(pcm)-step+1,step): samples.append(float(struct.unpack(fm,pcm[i:i+step])[0]))
        enc="Floating Point PCM"
    elif tag == 1:
        if bits==8:
            samples=[(b-128)/128.0 for b in pcm]; enc="Unsigned Integer PCM"
        elif bits==16:
            samples=[x/32768.0 for (x,) in struct.iter_unpack("<h", pcm[:len(pcm)//2*2])]; enc="Signed Integer PCM"
        elif bits==24:
            for i in range(0,len(pcm)-2,3):
                x=int.from_bytes(pcm[i:i+3]+(b"\xff" if pcm[i+2]&128 else b"\x00"),"little",signed=True)
                samples.append(x/8388608.0)
            enc="Signed Integer PCM"
        elif bits==32:
            samples=[x/2147483648.0 for (x,) in struct.iter_unpack("<i", pcm[:len(pcm)//4*4])]; enc="Signed Integer PCM"
        else: fail(f"formats: can't open input file `{path}': unsupported WAVE bits")
    else: fail(f"formats: can't open input file `{path}': unsupported WAVE encoding")
    return Audio(rate,ch,samples,bits,enc)

def read_raw(path, opts):
    data = sys.stdin.buffer.read() if path=="-" else open(path,"rb").read()
    ch=int(opts.get("channels",1)); rate=int(opts.get("rate",8000)); bits=int(opts.get("bits",16))
    enc=opts.get("encoding","signed-integer")
    samples=[]
    if enc in ("floating-point","float") or opts.get("type") in ("f32","f4","f64","f8"):
        bits = 64 if opts.get("type") in ("f64","f8") or bits==64 else 32
        step=bits//8; fm="<f" if bits==32 else "<d"
        for i in range(0,len(data)-step+1,step): samples.append(float(struct.unpack(fm,data[i:i+step])[0]))
        name="Floating Point PCM"
    elif bits==8 and enc.startswith("unsigned") or opts.get("type") in ("u8","ub"):
        bits=8; samples=[(b-128)/128.0 for b in data]; name="Unsigned Integer PCM"
    elif bits==8:
        samples=[struct.unpack("b",bytes([b]))[0]/128.0 for b in data]; name="Signed Integer PCM"
    elif bits==16:
        samples=[x/32768.0 for (x,) in struct.iter_unpack("<h",data[:len(data)//2*2])]; name="Signed Integer PCM"
    elif bits==24:
        for i in range(0,len(data)-2,3):
            samples.append(int.from_bytes(data[i:i+3]+(b"\xff" if data[i+2]&128 else b"\x00"),"little",signed=True)/8388608.0)
        name="Signed Integer PCM"
    else:
        bits=32; samples=[x/2147483648.0 for (x,) in struct.iter_unpack("<i",data[:len(data)//4*4])]; name="Signed Integer PCM"
    return Audio(rate,ch,samples,bits,name)

def read_audio(path, opts):
    if path == "-n": return Audio(int(opts.get("rate",48000)), int(opts.get("channels",1)), [], int(opts.get("bits",32)))
    if path != "-":
        try:
            with open(path, "rb") as f:
                if f.read(12)[:4] == b"RIFF":
                    return read_wav(path)
        except FileNotFoundError:
            raise
    t=opts.get("type") or ext_type(path)
    if t in ("wav","wavpcm","wave"): return read_wav(path)
    return read_raw(path, opts)

def clamp(x): return max(-1.0, min(1.0, x))

def pack_samples(a, bits, encoding="signed"):
    out=bytearray()
    if bits==8 and encoding.startswith("unsigned"):
        for x in a.samples: out.append(max(0,min(255,int(round(clamp(x)*127+128)))))
    elif bits==8:
        for x in a.samples: out += struct.pack("b", max(-128,min(127,int(round(clamp(x)*127)))))
    elif bits==16:
        for x in a.samples: out += struct.pack("<h", max(-32768,min(32767,int(round(clamp(x)*32767)))))
    elif bits==24:
        for x in a.samples:
            v=max(-8388608,min(8388607,int(round(clamp(x)*8388607))))
            out += int(v).to_bytes(3,"little",signed=True)
    else:
        for x in a.samples: out += struct.pack("<i", max(-2147483648,min(2147483647,int(round(clamp(x)*2147483647)))))
    return bytes(out)

def write_wav(path, a, bits=None):
    bits=int(bits or a.bits or 16)
    enc = "unsigned" if bits==8 and a.encoding.startswith("Unsigned") else "signed"
    pcm=pack_samples(a,bits,enc)
    ch=max(1,a.channels); align=ch*bits//8; br=a.rate*align
    if bits > 16:
        # SoX writes high precision integer WAVs as WAVE_FORMAT_EXTENSIBLE
        # with a fact chunk; matching that keeps sizes and metadata familiar.
        guid = bytes.fromhex("0100000000001000800000aa00389b71")
        fmt = struct.pack("<HHIIHHHHI", 0xfffe, ch, a.rate, br, align, bits, 22, bits, 0) + guid
        header = b"RIFF"+struct.pack("<I",72+len(pcm))+b"WAVE"
        header += b"fmt "+struct.pack("<I",40)+fmt
        header += b"fact"+struct.pack("<II",4,a.frames)
        header += b"data"+struct.pack("<I",len(pcm))
    else:
        header = b"RIFF"+struct.pack("<I",36+len(pcm))+b"WAVE"
        header += b"fmt "+struct.pack("<IHHIIHH",16,1,ch,a.rate,br,align,bits)
        header += b"data"+struct.pack("<I",len(pcm))
    data=header+pcm
    if path=="-": sys.stdout.buffer.write(data)
    else:
        with open(path,"wb") as f: f.write(data)

def write_raw(path,a,bits=None,encoding="signed"):
    data=pack_samples(a,int(bits or a.bits or 16),encoding)
    if path=="-": sys.stdout.buffer.write(data)
    else: open(path,"wb").write(data)

def write_dat(path,a):
    out=[f"; Sample Rate {a.rate}\\n", "; Channels 1\\n"]
    for i in range(a.frames):
        vals=a.samples[i*a.channels:(i+1)*a.channels]
        out.append(f"{i/a.rate:.8f} " + " ".join(f"{v:.8f}" for v in vals) + "\n")
    text="".join(out)
    if path=="-": sys.stdout.write(text)
    else: open(path,"w").write(text)

def resample(a,newrate):
    newrate=int(newrate)
    if newrate==a.rate or a.frames==0: a.rate=newrate; return a
    frames=int(round(a.frames*newrate/a.rate)); out=[]
    for i in range(frames):
        src=i*a.rate/newrate; j=int(src); frac=src-j
        for c in range(a.channels):
            x0=a.samples[min(j,a.frames-1)*a.channels+c]
            x1=a.samples[min(j+1,a.frames-1)*a.channels+c]
            out.append(x0+(x1-x0)*frac)
    a.samples=out; a.rate=newrate; return a

def change_channels(a,n):
    n=int(n)
    if n==a.channels: return a
    out=[]
    for i in range(a.frames):
        frame=a.samples[i*a.channels:(i+1)*a.channels]
        if n==1: out.append(sum(frame)/len(frame))
        else:
            for c in range(n): out.append(frame[c] if c<len(frame) else frame[-1])
    a.channels=n; a.samples=out; return a

def synth(rate,ch,bits,args):
    dur=1.0
    if args and re.match(r"^[0-9:.+-]", args[0]):
        dur=parse_num(args.pop(0))
    typ="sine"; freq=440.0
    if args: typ=args.pop(0).lower()
    if args:
        if args[0] in ("sine","sin","square","sawtooth","triangle","noise","whitenoise","pinknoise"):
            typ=args.pop(0).lower()
    if args:
        m=re.match(r"%?([-+]?[0-9.]+)(k?)", args[0])
        if m: freq=float(m.group(1))*(1000 if m.group(2) else 1)
    frames=max(0,int(round(dur*rate))); out=[]
    for i in range(frames):
        t=i/rate
        if typ in ("noise","whitenoise"): v=random.uniform(-1,1)
        elif typ.startswith("square"): v=1.0 if math.sin(2*math.pi*freq*t)>=0 else -1.0
        elif typ.startswith("tri"): v=2*abs(2*((freq*t)%1)-1)-1
        elif typ.startswith("saw"): v=2*((freq*t)%1)-1
        else: v=math.sin(2*math.pi*freq*t)
        for _ in range(ch): out.append(v*0.705)
    return Audio(rate,ch,out,bits)

def apply_effects(a,effects):
    i=0
    while i < len(effects):
        e=effects[i].lower(); i+=1
        if e=="channels" and i<len(effects): a=change_channels(a,int(effects[i])); i+=1
        elif e=="rate":
            while i<len(effects) and effects[i].startswith("-"): i+=1
            if i<len(effects): a=resample(a,parse_num(effects[i])); i+=1
        elif e=="speed" and i<len(effects):
            fac=parse_num(effects[i]); i+=1
            if fac: a=resample(a, int(round(a.rate*fac))); a.rate=int(round(a.rate/fac))
        elif e in ("vol","gain","norm"):
            db=False; val=0 if e=="norm" else 1
            while i<len(effects) and effects[i].startswith("-"): i+=1
            if i<len(effects) and re.match(r"^-?[0-9.]+$",effects[i]):
                val=float(effects[i]); i+=1
            mul=10**(val/20.0) if e in ("gain","norm") else val
            if e=="norm":
                peak=max([abs(x) for x in a.samples] or [1]); mul=(10**(val/20.0))/peak if peak else 1
            a.samples=[clamp(x*mul) for x in a.samples]
        elif e=="trim" and i<len(effects):
            start=time_to_frames(effects[i],a.rate); i+=1
            length=None
            if i<len(effects) and re.match(r"^[0-9:.+-]",effects[i]):
                length=time_to_frames(effects[i],a.rate); i+=1
            end=start+length if length is not None else a.frames
            a.samples=a.samples[start*a.channels:end*a.channels]
        elif e=="reverse": 
            frames=[a.samples[j*a.channels:(j+1)*a.channels] for j in range(a.frames)]
            a.samples=[x for fr in reversed(frames) for x in fr]
        elif e=="repeat" and i<len(effects):
            n=int(float(effects[i])); i+=1; a.samples=a.samples*(n+1)
        elif e=="pad":
            pads=[]
            while i<len(effects) and re.match(r"^[0-9:.]+",effects[i]):
                pads.append(time_to_frames(effects[i].split("@")[0],a.rate)); i+=1
            if pads:
                z=[0.0]*(pads[0]*a.channels); a.samples=z+a.samples
                if len(pads)>1: a.samples += [0.0]*(pads[1]*a.channels)
        elif e=="fade":
            vals=[]
            if i<len(effects) and effects[i] in ("q","h","t","l","p"): i+=1
            while i<len(effects) and re.match(r"^[0-9:.]+$",effects[i]):
                vals.append(time_to_frames(effects[i],a.rate)); i+=1
            fin=vals[0] if vals else 0; stop=vals[1] if len(vals)>1 else a.frames; fout=vals[2] if len(vals)>2 else 0
            if stop and stop<a.frames: a.samples=a.samples[:stop*a.channels]
            for f in range(min(fin,a.frames)):
                g=f/max(1,fin)
                for c in range(a.channels): a.samples[f*a.channels+c]*=g
            for k in range(min(fout,a.frames)):
                f=a.frames-1-k; g=k/max(1,fout)
                for c in range(a.channels): a.samples[f*a.channels+c]*=g
        elif e in ("stat","stats"):
            print_stats(a)
        elif e=="synth":
            pass
        else:
            # skip unknown effect arguments conservatively
            pass
    return a

def print_stats(a):
    vals=a.samples or [0.0]; mn=min(vals); mx=max(vals); mean=sum(vals)/len(vals)
    rms=math.sqrt(sum(x*x for x in vals)/len(vals)); scale=(2**(a.bits-1))
    err=sys.stderr
    print(f"Samples read:          {a.frames}", file=err)
    print(f"Length (seconds):      {a.duration:.6f}", file=err)
    print(f"Scaled by:         {scale:12.1f}", file=err)
    print(f"Maximum amplitude:     {mx:.6f}", file=err)
    print(f"Minimum amplitude:     {mn:.6f}", file=err)
    print(f"Midline amplitude:     {(mx+mn)/2:.6f}", file=err)
    print(f"Mean    norm:          {abs(mean):.6f}", file=err)
    print(f"RMS     amplitude:     {rms:.6f}", file=err)

def fmt_duration(sec):
    h=int(sec//3600); m=int((sec%3600)//60); s=sec-h*3600-m*60
    return f"{h:02d}:{m:02d}:{s:05.2f}"

def bitrate_str(a, size):
    if a.duration<=0: return "0"
    bps=size*8/a.duration
    if bps>=1e6: return f"{bps/1e6:.2g}M"
    if bps>=1e3: return f"{bps/1e3:.0f}k"
    return f"{bps:.0f}"

def soxi(path, flags):
    a=read_audio(path,{})
    if flags:
        for fl in flags:
            if fl=="-t": print(ext_type(path))
            elif fl=="-r": print(a.rate)
            elif fl=="-c": print(a.channels)
            elif fl=="-s": print(a.frames)
            elif fl=="-d": print(fmt_duration(a.duration))
            elif fl=="-D": print(f"{a.duration:.6f}")
            elif fl=="-b": print(a.bits)
            elif fl=="-B": print(bitrate_str(a, os.path.getsize(path)))
            elif fl=="-p": print(a.bits)
            elif fl=="-e": print(f"{a.bits}-bit {a.encoding}")
        return
    size=os.path.getsize(path) if path!="-" else 0
    sectors=a.duration*75
    print(f"\nInput File     : '{path}'")
    print(f"Channels       : {a.channels}")
    print(f"Sample Rate    : {a.rate}")
    print(f"Precision      : {a.bits}-bit")
    print(f"Duration       : {fmt_duration(a.duration)} = {a.frames} samples ~ {sectors:.2g} CDDA sectors")
    print(f"File Size      : {size}")
    print(f"Bit Rate       : {bitrate_str(a,size)}")
    print(f"Sample Encoding: {a.bits}-bit {a.encoding}")
    print()

def help_effect(name):
    print(banner()+"\n\nEffect usage:\n")
    if name=="all":
        for k in sorted(EFFECT_HELP): print(EFFECT_HELP[k]+"\n")
    else: print(EFFECT_HELP.get(name, f"{name}")+"\n")

def help_format(name):
    print(banner()+"\n")
    n=name.lower()
    if n in ("wav","wavpcm"):
        print("""Format: wav
Description: Microsoft audio format
Also handles: wavpcm amb
Reads: yes
Writes:
  16-bit Signed Integer PCM (16-bit precision)
  24-bit Signed Integer PCM (24-bit precision)
  32-bit Signed Integer PCM (32-bit precision)
   8-bit Unsigned Integer PCM (8-bit precision)""")
    else:
        print(f"Format: {name}\nReads: yes\nWrites: yes")

def main(argv):
    if not argv:
        print(f"{prog()} FAIL sox: No input filenames specified", file=sys.stderr)
        print()
        print(HELP.replace("./executable", prog()), end="")
        sys.exit(1)
    if argv[0] in ("--help","-h"): print(HELP.replace("./executable", prog()), end=""); return
    if argv[0]=="--version": print(banner()); return
    if argv[0]=="--help-effect" and len(argv)>1: help_effect(argv[1]); return
    if argv[0]=="--help-format" and len(argv)>1: help_format(argv[1]); return
    if argv[0] in ("--i","--info") or prog().startswith("soxi"):
        rest=argv[1:] if argv[0].startswith("--") else argv
        flags=[x for x in rest if x.startswith("-") and x!="-" and x!="-n"]
        files=[x for x in rest if not (x.startswith("-") and x!="-" and x!="-n")]
        if not files: fail("soxi: missing filename")
        for f in files: soxi(f, flags)
        return
    opts={}; files=[]; effects=[]; i=0
    known_effects=set(EFFECT_HELP.keys())|{"synth","stat","stats"}
    while i<len(argv):
        x=argv[i]
        if x in ("-q","-S","-D","-G","--clobber","--no-clobber","-V","-V0","-V1","-V2","-V3"): i+=1; continue
        if x in ("-t","--type"): opts["type"]=argv[i+1]; i+=2; continue
        if x in ("-r","--rate"): opts["rate"]=int(parse_num(argv[i+1])); i+=2; continue
        if x in ("-c","--channels"): opts["channels"]=int(argv[i+1]); i+=2; continue
        if x in ("-b","--bits"): opts["bits"]=int(argv[i+1]); i+=2; continue
        if x in ("-e","--encoding"): opts["encoding"]=argv[i+1]; i+=2; continue
        if x in ("-v","--volume"): opts["volume"]=float(argv[i+1]); i+=2; continue
        if x in ("-n","--null"): files.append("-n"); i+=1; continue
        if x in known_effects:
            effects=argv[i:]; break
        if x.startswith("--"):
            warn(f"getopt: parameter not recognized from `{x}'")
            print(f"{prog()} FAIL sox: invalid option", file=sys.stderr)
            print()
            print(HELP.replace("./executable", prog()), end="")
            sys.exit(1)
        files.append(x); i+=1
    if len(files)<2: fail("sox: Not enough input filenames specified")
    infiles=files[:-1]; outfile=files[-1]
    outopts=opts.copy()
    if infiles==["-n"] or (effects and effects[0]=="synth"):
        rate=int(opts.get("rate",48000)); ch=int(opts.get("channels",1)); bits=int(opts.get("bits",32))
        synargs=effects[1:] if effects and effects[0]=="synth" else []
        a=synth(rate,ch,bits,synargs[:])
        effects=[]
    else:
        audios=[read_audio(f,opts) for f in infiles]
        a=audios[0]
        for b in audios[1:]:
            if b.rate!=a.rate: b=resample(b,a.rate)
            if b.channels!=a.channels: b=change_channels(b,a.channels)
            a.samples += b.samples
    if "volume" in opts: a.samples=[clamp(x*opts["volume"]) for x in a.samples]
    a=apply_effects(a,effects)
    if "channels" in outopts and int(outopts["channels"])!=a.channels: a=change_channels(a,int(outopts["channels"]))
    if "rate" in outopts and int(outopts["rate"])!=a.rate and not (infiles==["-n"]): a=resample(a,int(outopts["rate"]))
    bits=int(outopts.get("bits", a.bits))
    if outfile == "-n":
        return
    # In common SoX usage, headerless input options precede the input file;
    # prefer a recognizable output extension over those carried options.
    t=ext_type(outfile)
    if t not in ("wav","dat","raw"):
        t=outopts.get("type") or t
    if t in ("wav","wavpcm","wave"): write_wav(outfile,a,bits)
    elif t=="dat": write_dat(outfile,a)
    else: write_raw(outfile,a,bits, "unsigned" if outopts.get("encoding","").startswith("unsigned") or t in ("u8","ub") else "signed")

if __name__ == "__main__":
    try: main(sys.argv[1:])
    except BrokenPipeError: pass
    except FileNotFoundError as e: fail(f"formats: can't open input file `{e.filename}': No such file or directory")
    except Exception as e: fail(str(e))
