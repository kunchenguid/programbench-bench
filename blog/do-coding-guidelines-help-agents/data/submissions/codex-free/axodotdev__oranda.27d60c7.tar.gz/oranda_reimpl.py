#!/usr/bin/env python3
import html
import json
import os
import re
import shutil
import sys
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

VERSION = "oranda 0.6.5"
TAGLINE = "🎁 generate beautiful landing pages for your projects"
TOP_FIELDS = {"project", "build", "marketing", "styles", "components", "workspace", "$schema"}
BUILD_FIELDS = {"dist_dir", "static_dir", "path_prefix", "additional_pages"}


def print_top_help(long=False):
    if long:
        print(f"""{TAGLINE}

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output""")
    else:
        print(f"""{TAGLINE}

Usage: executable [OPTIONS] <COMMAND>

Commands:
  build     Build an oranda site
  dev       Start a local development server that recompiles your oranda site if a file changes
  serve     Start a file server to access your oranda site in a browser
  generate  Generate infrastructure files for oranda sites
  help      Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]""")


def print_build_help(long=False):
    if long:
        print("""Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only
          Only build the artifacts JSON file (if applicable) and other files that may be used to
          support it, such as installer source files

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output""")
    else:
        print("""Build an oranda site

Usage: executable build [OPTIONS]

Options:
      --json-only  Only build the artifacts JSON file (if applicable) and other files that may be
                   used to support it, such as installer source files
  -h, --help       Print help (see more with '--help')

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]""")


def print_dev_help(long=False):
    if long:
        print("""Start a local development server that recompiles your oranda site if a file changes

Usage: executable dev [OPTIONS]

Options:
      --port <PORT>
          The port for the file server to be launched on

      --no-first-build
          Skip the first build before starting to watch for changes

  -i, --include-paths <INCLUDE_PATHS>
          List of extra paths to watch

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output""")
    else:
        print("""Start a local development server that recompiles your oranda site if a file changes

Usage: executable dev [OPTIONS]

Options:
      --port <PORT>                    The port for the file server to be launched on
      --no-first-build                 Skip the first build before starting to watch for changes
  -i, --include-paths <INCLUDE_PATHS>  List of extra paths to watch
  -h, --help                           Print help (see more with '--help')

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]""")


def print_serve_help(long=False):
    if long:
        print("""Start a file server to access your oranda site in a browser

Usage: executable serve [OPTIONS]

Options:
      --port <PORT>
          [default: 7979]

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output""")
    else:
        print("""Start a file server to access your oranda site in a browser

Usage: executable serve [OPTIONS]

Options:
      --port <PORT>  [default: 7979]
  -h, --help         Print help (see more with '--help')

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]""")


def print_generate_help(long=False):
    if long:
        print("""Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output""")
    else:
        print("""Generate infrastructure files for oranda sites

Usage: executable generate [OPTIONS] <COMMAND>

Commands:
  ci    Generates a CI file that can be used to deploy your site
  help  Print this message or the help of the given subcommand(s)

Options:
  -o, --output-path <OUTPUT_PATH>  Path to the output file
  -s, --site-path <SITE_PATH>      Path to your oranda site
  -h, --help                       Print help (see more with '--help')

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]""")


def print_ci_help(long=False):
    if long:
        print("""Generates a CI file that can be used to deploy your site

Usage: executable generate ci [OPTIONS]

Options:
      --ci <CI>
          What CI to generate a file for
          
          [default: github]

          Possible values:
          - github: Deploy to GitHub Pages using GitHub Actions

  -o, --output-path <OUTPUT_PATH>
          Path to the output file

  -s, --site-path <SITE_PATH>
          Path to your oranda site

  -h, --help
          Print help (see a summary with '-h')

GLOBAL OPTIONS:
  -v, --verbose
          Whether to output more detailed debug information

      --output-format <OUTPUT_FORMAT>
          The format of the output
          
          [default: human]

          Possible values:
          - human: Human-readable output
          - json:  Machine-readable JSON output""")
    else:
        print("""Generates a CI file that can be used to deploy your site

Usage: executable generate ci [OPTIONS]

Options:
      --ci <CI>                    What CI to generate a file for [default: github] [possible
                                   values: github]
  -o, --output-path <OUTPUT_PATH>  Path to the output file
  -s, --site-path <SITE_PATH>      Path to your oranda site
  -h, --help                       Print help (see more with '--help')

GLOBAL OPTIONS:
  -v, --verbose                        Whether to output more detailed debug information
      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:
                                       human, json]""")


def clap_error(msg, usage=None):
    print(f"error: {msg}", file=sys.stderr)
    if usage:
        print("", file=sys.stderr)
        print(usage, file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    return 2


def success(msg):
    print(f"✓ >o_o< SUCCESS: {msg}")


def warn(msg):
    print(f"  ⚠ {msg}")


def fail(msg, causes=None, help_msg=None, output_json=False):
    if output_json:
        diag = {"diagnostic": {"message": msg, "severity": "error", "causes": causes or [], "help": help_msg, "labels": [], "related": []}}
        print(json.dumps(diag))
    print(f"  × {msg}", file=sys.stderr)
    if causes:
        for i, c in enumerate(causes):
            prefix = "╰─▶" if i == len(causes) - 1 else "├─▶"
            print(f"  {prefix} {c}", file=sys.stderr)
    if help_msg:
        print(f"  help: {help_msg}", file=sys.stderr)
    return 255


def load_config():
    path = "oranda.json"
    if not os.path.exists(path):
        return {}
    text = open(path, encoding="utf-8").read()
    try:
        cfg = json.loads(text)
    except json.JSONDecodeError as e:
        return ("ERR", f"failed to parse JSON", [f"{e.msg} at line {e.lineno} column {e.colno}"])
    if not isinstance(cfg, dict):
        return ("ERR", "failed to parse JSON", ["invalid type: expected a map"])
    for k in cfg:
        if k not in TOP_FIELDS:
            return ("ERR", "failed to parse JSON", [f"unknown field `{k}`, expected one of `project`, `build`, `marketing`, `styles`, `components`, `workspace`, `$schema`"])
    if isinstance(cfg.get("build"), dict):
        for k in cfg["build"]:
            if k not in BUILD_FIELDS:
                return ("ERR", "failed to parse JSON", [f"unknown field `{k}`, expected one of `dist_dir`, `static_dir`, `path_prefix`, `additional_pages`"])
    return cfg


def read_project(cfg):
    project = cfg.get("project") if isinstance(cfg.get("project"), dict) else {}
    name = project.get("name") or os.path.basename(os.getcwd()) or "oranda"
    desc = project.get("description") or ""
    version = project.get("version") or ""
    if os.path.exists("Cargo.toml"):
        try:
            cargo = open("Cargo.toml", encoding="utf-8").read()
            m = re.search(r'(?m)^name\s*=\s*"([^"]+)"', cargo)
            if m and not project.get("name"):
                name = m.group(1)
            m = re.search(r'(?m)^description\s*=\s*"([^"]*)"', cargo)
            if m and not project.get("description"):
                desc = m.group(1)
            m = re.search(r'(?m)^version\s*=\s*"([^"]*)"', cargo)
            if m:
                version = m.group(1)
        except OSError:
            pass
    if os.path.exists("README.md"):
        try:
            readme = open("README.md", encoding="utf-8").read()
            m = re.search(r"(?m)^#\s+(.+?)\s*$", readme)
            if m and not project.get("name"):
                name = m.group(1).strip()
            if not desc:
                paras = [p.strip() for p in re.split(r"\n\s*\n", readme) if p.strip()]
                for p in paras:
                    if not p.startswith("#"):
                        desc = re.sub(r"\s+", " ", re.sub(r"[`*_]", "", p)).strip()
                        break
        except OSError:
            pass
    return name, desc, version


def markdown_to_html(text):
    out = []
    in_list = False
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line:
            if in_list:
                out.append("</ul>")
                in_list = False
            continue
        if line.startswith("# "):
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<h1>{html.escape(line[2:].strip())}</h1>")
        elif line.startswith("## "):
            if in_list:
                out.append("</ul>")
                in_list = False
            out.append(f"<h2>{html.escape(line[3:].strip())}</h2>")
        elif line.startswith("- "):
            if not in_list:
                out.append("<ul>")
                in_list = True
            out.append(f"<li>{html.escape(line[2:].strip())}</li>")
        else:
            if in_list:
                out.append("</ul>")
                in_list = False
            line = re.sub(r"`([^`]+)`", r"<code>\1</code>", html.escape(line))
            out.append(f"<p>{line}</p>")
    if in_list:
        out.append("</ul>")
    return "\n".join(out)


def build_site(args, output_json=False):
    cfg = load_config()
    if isinstance(cfg, tuple) and cfg[0] == "ERR":
        return fail(cfg[1], cfg[2], output_json=output_json)
    build = cfg.get("build") if isinstance(cfg.get("build"), dict) else {}
    dist = build.get("dist_dir") or "public"
    os.makedirs(dist, exist_ok=True)
    if args.get("json_only"):
        success(f"Your site build is located in `{dist}`.")
        return 0
    static = build.get("static_dir")
    if static and os.path.isdir(static):
        for root, dirs, files in os.walk(static):
            rel = os.path.relpath(root, static)
            target_dir = dist if rel == "." else os.path.join(dist, rel)
            os.makedirs(target_dir, exist_ok=True)
            for f in files:
                shutil.copy2(os.path.join(root, f), os.path.join(target_dir, f))
    name, desc, version = read_project(cfg)
    readme_html = ""
    if os.path.exists("README.md"):
        readme_html = markdown_to_html(open("README.md", encoding="utf-8").read())
    if not readme_html:
        readme_html = f"<h1>{html.escape(name)}</h1>"
        if desc:
            readme_html += f"\n<p>{html.escape(desc)}</p>"
    css = """body{font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;margin:0;color:#202124;background:#fafafa}main{max-width:860px;margin:0 auto;padding:56px 24px}.hero{border-bottom:1px solid #ddd;margin-bottom:32px;padding-bottom:24px}h1{font-size:44px;margin:0 0 12px}h2{margin-top:32px}p,li{line-height:1.6}code{background:#eee;padding:2px 5px;border-radius:4px}"""
    open(os.path.join(dist, "oranda.css"), "w", encoding="utf-8").write(css)
    html_doc = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{html.escape(name)}</title>
  <meta name="description" content="{html.escape(desc)}">
  <link rel="stylesheet" href="oranda.css">
</head>
<body>
<main>
  <section class="hero">
    <h1>{html.escape(name)}</h1>
    {'<p>'+html.escape(desc)+'</p>' if desc else ''}
    {'<p><code>'+html.escape(version)+'</code></p>' if version else ''}
  </section>
  <section class="content">
{readme_html}
  </section>
</main>
</body>
</html>
"""
    open(os.path.join(dist, "index.html"), "w", encoding="utf-8").write(html_doc)
    if not os.path.exists(os.path.join(dist, "favicon.ico")):
        open(os.path.join(dist, "favicon.ico"), "wb").write(b"\0")
    success(f"Your site build is located in `{dist}`.")
    return 0


def parse_value(argv, i, name):
    if i + 1 >= len(argv):
        print(f"error: a value is required for '{name} <{name.lstrip('-').replace('-', '_').upper()}>' but none was supplied", file=sys.stderr)
        return None, i
    return argv[i + 1], i + 1


def parse_common(argv):
    outfmt = "human"
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--output-format":
            val, i = parse_value(argv, i, a)
            if val is None:
                sys.exit(2)
            if val not in ("human", "json"):
                sys.exit(clap_error(f"invalid value '{val}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]"))
            outfmt = val
        elif a == "-v" or a == "--verbose":
            pass
        else:
            rest.append(a)
        i += 1
    return rest, outfmt


def generate_ci(args):
    output = args.get("output_path")
    site = args.get("site_path") or "."
    if not output:
        output = ".github/workflows/web.yml"
    os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
    content = f"""name: Deploy oranda site

on:
  push:
    branches: [main, master]
  workflow_dispatch:

permissions:
  contents: read
  pages: write
  id-token: write

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Install oranda
        run: curl --proto '=https' --tlsv1.2 -LsSf https://github.com/axodotdev/oranda/releases/download/v0.6.5/oranda-installer.sh | sh
      - name: Build
        run: oranda build
        working-directory: {site}
      - uses: actions/upload-pages-artifact@v3
        with:
          path: {site}/public
      - uses: actions/deploy-pages@v4
"""
    open(output, "w", encoding="utf-8").write(content)
    success(f"Generated GitHub Actions workflow at `{output}`.")
    return 0


def serve_dir(port):
    if not os.path.isdir("public"):
        return fail("Could not find a build in public", help_msg="Did you remember to run `oranda build`?")
    os.chdir("public")
    print(f"Serving at http://127.0.0.1:{port}")
    server = ThreadingHTTPServer(("0.0.0.0", port), SimpleHTTPRequestHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        return 0


def main():
    argv, outfmt = parse_common(sys.argv[1:])
    if not argv:
        print_top_help(False)
        return 0
    if argv[0] in ("-h", "--help"):
        print_top_help(argv[0] == "--help")
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if argv[0] == "help":
        if len(argv) == 1:
            print_top_help(True)
        elif argv[1] == "build":
            print_build_help(True)
        elif argv[1] == "dev":
            print_dev_help(True)
        elif argv[1] == "serve":
            print_serve_help(True)
        elif argv[1] == "generate":
            if len(argv) > 2 and argv[2] == "ci":
                print_ci_help(True)
            else:
                print_generate_help(True)
        else:
            return clap_error(f"unrecognized subcommand '{argv[1]}'", "Usage: executable help [COMMAND]...")
        return 0
    cmd = argv[0]
    if cmd not in ("build", "dev", "serve", "generate"):
        if cmd.startswith("-"):
            return clap_error(f"unexpected argument '{cmd}' found", "Usage: executable [OPTIONS] <COMMAND>")
        return clap_error(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] <COMMAND>")
    sub = argv[1:]
    if cmd == "build":
        if "-h" in sub or "--help" in sub:
            print_build_help("--help" in sub)
            return 0
        for a in sub:
            if a != "--json-only":
                return clap_error(f"unexpected argument '{a}' found", "Usage: executable build [OPTIONS]")
        return build_site({"json_only": "--json-only" in sub}, outfmt == "json")
    if cmd == "serve":
        if "-h" in sub or "--help" in sub:
            print_serve_help("--help" in sub)
            return 0
        port = 7979
        i = 0
        while i < len(sub):
            if sub[i] == "--port":
                val, i = parse_value(sub, i, "--port")
                port = int(val)
            else:
                return clap_error(f"unexpected argument '{sub[i]}' found", "Usage: executable serve [OPTIONS]")
            i += 1
        return serve_dir(port)
    if cmd == "dev":
        if "-h" in sub or "--help" in sub:
            print_dev_help("--help" in sub)
            return 0
        port = 7979
        no_first = False
        i = 0
        while i < len(sub):
            if sub[i] == "--port":
                val, i = parse_value(sub, i, "--port")
                port = int(val)
            elif sub[i] == "--no-first-build":
                no_first = True
            elif sub[i] in ("-i", "--include-paths"):
                _, i = parse_value(sub, i, sub[i])
            else:
                return clap_error(f"unexpected argument '{sub[i]}' found", "Usage: executable dev [OPTIONS]")
            i += 1
        if not no_first:
            rc = build_site({"json_only": False}, outfmt == "json")
            if rc:
                return rc
        return serve_dir(port)
    if cmd == "generate":
        if not sub or sub[0] in ("-h", "--help"):
            print_generate_help(sub and sub[0] == "--help")
            return 0
        gen_opts = {"output_path": None, "site_path": None}
        i = 0
        while i < len(sub) and sub[i] != "ci":
            if sub[i] in ("-o", "--output-path"):
                gen_opts["output_path"], i = parse_value(sub, i, sub[i])
            elif sub[i] in ("-s", "--site-path"):
                gen_opts["site_path"], i = parse_value(sub, i, sub[i])
            else:
                return clap_error(f"unrecognized subcommand '{sub[i]}'", "Usage: executable generate [OPTIONS] <COMMAND>")
            i += 1
        if i >= len(sub):
            return clap_error("a subcommand is required but one was not provided", "Usage: executable generate [OPTIONS] <COMMAND>")
        rest = sub[i + 1:]
        if "help" == sub[i]:
            print_generate_help(True)
            return 0
        if sub[i] != "ci":
            return clap_error(f"unrecognized subcommand '{sub[i]}'", "Usage: executable generate [OPTIONS] <COMMAND>")
        if "-h" in rest or "--help" in rest:
            print_ci_help("--help" in rest)
            return 0
        ci = "github"
        j = 0
        while j < len(rest):
            if rest[j] == "--ci":
                ci, j = parse_value(rest, j, "--ci")
                if ci != "github":
                    return clap_error(f"invalid value '{ci}' for '--ci <CI>'\n  [possible values: github]")
            elif rest[j] in ("-o", "--output-path"):
                gen_opts["output_path"], j = parse_value(rest, j, rest[j])
            elif rest[j] in ("-s", "--site-path"):
                gen_opts["site_path"], j = parse_value(rest, j, rest[j])
            else:
                return clap_error(f"unexpected argument '{rest[j]}' found", "Usage: executable generate ci [OPTIONS]")
            j += 1
        print("↪ >o_o< INFO: Generating a CI deploy workflow for your site...")
        return generate_ci(gen_opts)


if __name__ == "__main__":
    sys.exit(main())
