#!/usr/bin/env python3
import base64
import copy
import csv
import json
import os
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET

for p in (
    "/opt/deps/python/wheels/pyyaml-6.0.3-cp311-cp311-manylinux2014_x86_64.manylinux_2_17_x86_64.manylinux_2_28_x86_64.whl",
    "/opt/deps/python/wheels/pyyaml-6.0.3-cp310-cp310-manylinux2014_x86_64.manylinux_2_17_x86_64.manylinux_2_28_x86_64.whl",
):
    if os.path.exists(p) and p not in sys.path:
        sys.path.insert(0, p)

try:
    import yaml
except Exception as e:
    sys.stderr.write("Error: PyYAML is required: %s\n" % e)
    sys.exit(1)


VERSION = "yq (https://github.com/mikefarah/yq/) version v4.52.5"


class Dumper(yaml.SafeDumper):
    def increase_indent(self, flow=False, indentless=False):
        return super().increase_indent(flow, False)


def str_representer(dumper, data):
    if data == "":
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style='""')
    if data in ("true", "false", "null", "~") or data.strip() != data or "\n" in data:
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style='"')
    if re.match(r"^-?\d+(\.\d+)?$", data):
        return dumper.represent_scalar("tag:yaml.org,2002:str", data, style='"')
    return dumper.represent_scalar("tag:yaml.org,2002:str", data)


Dumper.add_representer(str, str_representer)


def usage():
    return """yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) 
See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.

Usage:
  yq [flags]
  yq [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  eval        (default) Apply the expression to each document in each yaml file in sequence
  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once
  help        Help about any command

Flags:
  -C, --colors                            force print with colors
  -e, --exit-status                       set exit status if there are no matches or null or false is returned
      --expression string                 forcibly set the expression argument. Useful when yq argument detection thinks your expression is a file.
      --from-file string                  Load expression from specified file.
  -h, --help                              help for yq
  -I, --indent int                        sets indent level for output (default 2)
  -i, --inplace                           update the file in place of first file given.
  -n, --null-input                        Don't read input, simply evaluate the expression given.
  -o, --output-format string              output format type. (default "auto")
  -p, --input-format string               parse format for input. (default "auto")
  -P, --prettyPrint                       pretty print, shorthand for '... style = ""'
  -r, --unwrapScalar                      unwrap scalar, print the value with no quotes, colours or comments. Defaults to true for yaml (default true)
  -V, --version                           Print version information and quit
"""


def parse_args(argv):
    opts = {
        "cmd": "eval", "input": "auto", "output": "auto", "indent": 2,
        "inplace": False, "null": False, "exit_status": False,
        "unwrap": True, "no_doc": False, "nul": False, "expr": None,
        "from_file": None, "split": None, "props_sep": " = ",
        "shell_sep": "_", "pretty": False,
    }
    rest = []
    i = 0
    if argv and argv[0] in ("eval", "e", "eval-all", "ea"):
        opts["cmd"] = "eval-all" if argv[0] in ("eval-all", "ea") else "eval"
        i = 1
    elif argv and argv[0] == "help":
        print(usage(), end="")
        sys.exit(0)
    elif argv and argv[0] == "completion":
        shell = argv[1] if len(argv) > 1 else ""
        print("# %s completion is not implemented in this cleanroom build" % shell)
        sys.exit(0)
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(usage(), end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a in ("-i", "--inplace"):
            opts["inplace"] = True
        elif a in ("-n", "--null-input"):
            opts["null"] = True
        elif a in ("-e", "--exit-status"):
            opts["exit_status"] = True
        elif a in ("-N", "--no-doc"):
            opts["no_doc"] = True
        elif a in ("-0", "--nul-output"):
            opts["nul"] = True
        elif a in ("-P", "--prettyPrint"):
            opts["pretty"] = True
        elif a in ("-r", "--unwrapScalar"):
            opts["unwrap"] = True
        elif a in ("-C", "--colors", "-M", "--no-colors", "-v", "--verbose",
                   "--debug-node-info", "--csv-auto-parse", "--tsv-auto-parse",
                   "--lua-globals", "--lua-unquoted", "--xml-keep-namespace",
                   "--xml-raw-token", "--xml-skip-directives", "--xml-skip-proc-inst",
                   "--xml-strict-mode", "--security-disable-env-ops",
                   "--security-disable-file-ops", "--security-enable-system-operator",
                   "--header-preprocess", "--string-interpolation",
                   "-c", "--yaml-compact-seq-indent", "--yaml-fix-merge-anchor-to-spec"):
            pass
        elif a in ("-p", "--input-format"):
            i += 1; opts["input"] = argv[i]
        elif a.startswith("-p="):
            opts["input"] = a.split("=", 1)[1]
        elif a.startswith("-p") and len(a) > 2:
            opts["input"] = a[2:]
        elif a.startswith("--input-format="):
            opts["input"] = a.split("=", 1)[1]
        elif a in ("-o", "--output-format"):
            i += 1; opts["output"] = argv[i]
        elif a.startswith("-o="):
            opts["output"] = a.split("=", 1)[1]
        elif a.startswith("-o") and len(a) > 2:
            opts["output"] = a[2:]
        elif a.startswith("--output-format="):
            opts["output"] = a.split("=", 1)[1]
        elif a in ("-I", "--indent"):
            i += 1; opts["indent"] = int(argv[i])
        elif a.startswith("-I") and len(a) > 2:
            opts["indent"] = int(a[2:])
        elif a in ("--expression",):
            i += 1; opts["expr"] = argv[i]
        elif a.startswith("--expression="):
            opts["expr"] = a.split("=", 1)[1]
        elif a == "--from-file":
            i += 1; opts["from_file"] = argv[i]
        elif a.startswith("--from-file="):
            opts["from_file"] = a.split("=", 1)[1]
        elif a in ("-s", "--split-exp"):
            i += 1; opts["split"] = argv[i]
        elif a == "--properties-separator":
            i += 1; opts["props_sep"] = argv[i]
        elif a == "--shell-key-separator":
            i += 1; opts["shell_sep"] = argv[i]
        elif a in ("--csv-separator", "--xml-attribute-prefix", "--xml-content-name",
                   "--xml-directive-name", "--xml-proc-inst-prefix", "--lua-prefix",
                   "--lua-suffix", "--front-matter", "-f", "--split-exp-file"):
            i += 1
        elif a.startswith("-") and a not in ("-",):
            # Unknown compatibility flag with optional value is ignored.
            pass
        else:
            rest.append(a)
        i += 1
    if opts["from_file"]:
        with open(opts["from_file"], "r", encoding="utf-8") as f:
            opts["expr"] = f.read()
    if opts["expr"] is None:
        if rest and (rest[0].startswith(".") or rest[0].startswith("[") or "=" in rest[0] or
                     rest[0].startswith("load(") or "ireduce" in rest[0] or rest[0] in ("true", "false", "null")):
            opts["expr"] = rest.pop(0)
        elif rest and (rest[0] in ("keys", "length") or rest[0].startswith("has(")):
            opts["expr"] = rest.pop(0)
        elif opts["null"] and rest:
            opts["expr"] = rest.pop(0)
        else:
            opts["expr"] = "."
    opts["files"] = rest
    return opts


def norm_fmt(f):
    m = {"y": "yaml", "a": "auto", "j": "json", "p": "props", "c": "csv",
         "t": "tsv", "x": "xml", "s": "shell", "l": "lua", "i": "ini", "h": "hcl"}
    return m.get((f or "auto").lower(), (f or "auto").lower())


def detect_format(path, requested, text=None):
    requested = norm_fmt(requested)
    if requested != "auto":
        return requested
    ext = os.path.splitext(path or "")[1].lower()
    return {
        ".json": "json", ".yaml": "yaml", ".yml": "yaml", ".xml": "xml",
        ".csv": "csv", ".tsv": "tsv", ".properties": "props", ".props": "props",
        ".ini": "ini",
    }.get(ext, "yaml")


def scalar_auto(s):
    s = s.strip()
    if s == "":
        return ""
    if s == "null":
        return None
    if s == "true":
        return True
    if s == "false":
        return False
    if re.match(r"^-?\d+$", s):
        try: return int(s)
        except Exception: pass
    if re.match(r"^-?\d+\.\d+$", s):
        try: return float(s)
        except Exception: pass
    return s


def parse_props(text):
    root = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("!"):
            continue
        if "=" in line:
            k, v = line.split("=", 1)
        elif ":" in line:
            k, v = line.split(":", 1)
        else:
            k, v = line, ""
        set_path(root, parse_path("." + k.strip().replace("[", ".").replace("]", "")), scalar_auto(v.strip()))
    return root


def parse_ini(text):
    root = {}
    section = root
    for line in text.splitlines():
        line = line.strip()
        if not line or line[0] in "#;":
            continue
        if line.startswith("[") and line.endswith("]"):
            name = line[1:-1]
            root.setdefault(name, {})
            section = root[name]
        elif "=" in line:
            k, v = line.split("=", 1)
            section[k.strip()] = scalar_auto(v.strip())
    return root


def xml_node(elem):
    obj = {}
    for k, v in elem.attrib.items():
        obj["+@" + k] = v
    children = list(elem)
    text = (elem.text or "").strip()
    if children:
        groups = {}
        for c in children:
            groups.setdefault(c.tag, []).append(xml_node(c))
        for k, vals in groups.items():
            obj[k] = vals[0] if len(vals) == 1 else vals
        if text:
            obj["+content"] = text
        return obj
    if obj:
        if text:
            obj["+content"] = text
        return obj
    return text


def parse_text(text, fmt):
    fmt = norm_fmt(fmt)
    if fmt == "json":
        return listify(json.loads(text))
    if fmt in ("yaml", "kyaml", "auto"):
        docs = list(yaml.safe_load_all(text))
        return docs if len(docs) > 1 else (docs[0] if docs else None)
    if fmt == "csv" or fmt == "tsv":
        dialect = "excel-tab" if fmt == "tsv" else "excel"
        rows = list(csv.DictReader(text.splitlines(), dialect=dialect))
        return [{k: scalar_auto(v) for k, v in r.items()} for r in rows]
    if fmt in ("props", "properties"):
        return parse_props(text)
    if fmt == "ini":
        return parse_ini(text)
    if fmt == "xml":
        root = ET.fromstring(text)
        return {root.tag: xml_node(root)}
    if fmt == "base64":
        return base64.b64decode(text.strip()).decode()
    if fmt == "uri":
        return urllib.parse.unquote(text.strip())
    return yaml.safe_load(text)


def listify(x):
    return x


def load_file(path, input_fmt):
    if path == "-":
        text = sys.stdin.read()
        fmt = detect_format("", input_fmt, text)
    else:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
        fmt = detect_format(path, input_fmt, text)
    return parse_text(text, fmt), fmt


def split_top(expr, sep="|"):
    out, cur, q, depth = [], [], None, 0
    i = 0
    while i < len(expr):
        ch = expr[i]
        if q:
            cur.append(ch)
            if ch == q and (i == 0 or expr[i - 1] != "\\"):
                q = None
        else:
            if ch in "\"'":
                q = ch; cur.append(ch)
            elif ch in "([{":
                depth += 1; cur.append(ch)
            elif ch in ")]}":
                depth -= 1; cur.append(ch)
            elif ch == sep and depth == 0:
                out.append("".join(cur).strip()); cur = []
            else:
                cur.append(ch)
        i += 1
    out.append("".join(cur).strip())
    return [x for x in out if x]


def split_assign(expr):
    q, depth = None, 0
    for i, ch in enumerate(expr):
        if q:
            if ch == q and expr[i - 1] != "\\":
                q = None
        else:
            if ch in "\"'":
                q = ch
            elif ch in "([{":
                depth += 1
            elif ch in ")]}":
                depth -= 1
            elif ch == "=" and depth == 0:
                if i + 1 < len(expr) and expr[i + 1] == "=":
                    continue
                return expr[:i].strip(), expr[i + 1:].strip()
    return None, None


def parse_path(expr):
    expr = expr.strip()
    if expr == ".":
        return []
    if expr.startswith("."):
        expr = expr[1:]
    toks, cur, i = [], "", 0
    while i < len(expr):
        ch = expr[i]
        if ch == ".":
            if cur:
                toks.append(cur); cur = ""
        elif ch == "[":
            if cur:
                toks.append(cur); cur = ""
            j = expr.find("]", i)
            inside = expr[i + 1:j]
            if inside == "":
                toks.append("*")
            elif (inside.startswith('"') and inside.endswith('"')) or (inside.startswith("'") and inside.endswith("'")):
                toks.append(inside[1:-1])
            else:
                try: toks.append(int(inside))
                except Exception: toks.append(inside)
            i = j
        else:
            cur += ch
        i += 1
    if cur:
        toks.append(cur)
    return toks


def get_path_one(obj, toks):
    vals = [obj]
    for t in toks:
        nxt = []
        for v in vals:
            if t == "*":
                if isinstance(v, list):
                    nxt.extend(v)
                elif isinstance(v, dict):
                    nxt.extend(v.values())
            elif isinstance(t, int):
                if isinstance(v, list) and -len(v) <= t < len(v):
                    nxt.append(v[t])
                else:
                    nxt.append(None)
            else:
                if isinstance(v, dict) and t in v:
                    nxt.append(v[t])
                else:
                    nxt.append(None)
        vals = nxt
    return vals


def ensure_container(parent, key, next_key):
    new = [] if isinstance(next_key, int) else {}
    if isinstance(parent, list) and isinstance(key, int):
        while len(parent) <= key:
            parent.append(None)
        parent[key] = new
    elif isinstance(parent, dict):
        parent[key] = new
    return new


def set_path(obj, toks, value):
    if not toks:
        return value
    if obj is None:
        obj = [] if isinstance(toks[0], int) else {}
    cur = obj
    for i, t in enumerate(toks[:-1]):
        nt = toks[i + 1]
        if isinstance(cur, list) and isinstance(t, int):
            while len(cur) <= t:
                cur.append(None)
            if cur[t] is None or not isinstance(cur[t], (dict, list)):
                cur[t] = [] if isinstance(nt, int) else {}
            cur = cur[t]
        elif isinstance(cur, dict):
            if t not in cur or cur[t] is None or not isinstance(cur[t], (dict, list)):
                cur[t] = [] if isinstance(nt, int) else {}
            cur = cur[t]
        else:
            return obj
    last = toks[-1]
    if isinstance(cur, list) and isinstance(last, int):
        while len(cur) <= last:
            cur.append(None)
        cur[last] = value
    elif isinstance(cur, dict):
        cur[last] = value
    return obj


def deep_merge(a, b):
    if isinstance(a, dict) and isinstance(b, dict):
        res = copy.deepcopy(a)
        for k, v in b.items():
            res[k] = deep_merge(res[k], v) if k in res else copy.deepcopy(v)
        return res
    return copy.deepcopy(b)


def eval_value(expr, ctx):
    expr = expr.strip()
    if expr.startswith('"') and expr.endswith('"'):
        return bytes(expr[1:-1], "utf-8").decode("unicode_escape")
    if expr.startswith("'") and expr.endswith("'"):
        return expr[1:-1]
    if expr.startswith("strenv(") and expr.endswith(")"):
        return os.environ.get(expr[7:-1], "")
    if expr.startswith("env(") and expr.endswith(")"):
        return scalar_auto(os.environ.get(expr[4:-1], ""))
    if expr == "null":
        return None
    if expr == "true":
        return True
    if expr == "false":
        return False
    if re.match(r"^-?\d+$", expr):
        return int(expr)
    if re.match(r"^-?\d+\.\d+$", expr):
        return float(expr)
    if expr.startswith("."):
        vals = eval_pipeline(ctx, expr)
        return vals[0] if len(vals) == 1 else vals
    return expr


def select_filter(items, cond):
    m = re.match(r"select\((.+)\)$", cond.strip())
    if not m:
        return items
    c = m.group(1).strip()
    op = "==" if "==" in c else ("!=" if "!=" in c else None)
    if not op:
        return items
    left, right = [x.strip() for x in c.split(op, 1)]
    rv = eval_value(right, None)
    out = []
    for it in items:
        lv = eval_value(left, it)
        ok = (lv == rv)
        if op == "!=":
            ok = not ok
        if ok:
            out.append(it)
    return out


def eval_pipeline(data, expr):
    expr = expr.strip()
    if expr.startswith("[") and expr.endswith("]") and not expr.startswith("[\""):
        inner = expr[1:-1].strip()
        return [eval_pipeline(data, inner)]
    left, right = split_assign(expr)
    if left is not None:
        target = copy.deepcopy(data)
        for part in split_top(expr):
            l, r = split_assign(part)
            if l is not None:
                target = set_path(target, parse_path(l), eval_value(r, target))
            else:
                vals = eval_pipeline(target, part)
                target = vals[0] if len(vals) == 1 else vals
        return [target]
    parts = split_top(expr)
    items = [data]
    for part in parts:
        if part == ".":
            continue
        if part == "keys":
            items = [list(it.keys()) if isinstance(it, dict) else list(range(len(it))) if isinstance(it, list) else [] for it in items]
            continue
        if part == "length":
            items = [len(it) if isinstance(it, (dict, list, str)) else 0 if it is None else 1 for it in items]
            continue
        if part.startswith("has(") and part.endswith(")"):
            key = eval_value(part[4:-1], None)
            out = []
            for it in items:
                if isinstance(it, dict):
                    out.append(key in it)
                elif isinstance(it, list):
                    try:
                        idx = int(key)
                        out.append(0 <= idx < len(it))
                    except Exception:
                        out.append(False)
                else:
                    out.append(False)
            items = out
            continue
        if part.startswith("select("):
            items = select_filter(items, part)
        else:
            new = []
            for it in items:
                new.extend(get_path_one(it, parse_path(part)))
            items = new
    return items


def eval_expr(data, expr, input_fmt="auto"):
    expr = expr.strip()
    m = re.findall(r'load\("([^"]+)"\)', expr)
    if m and "*" in expr:
        acc = None
        for path in m:
            d, _ = load_file(path, input_fmt)
            acc = d if acc is None else deep_merge(acc, d)
        return [acc]
    return eval_pipeline(data, expr)


def yaml_dump(data, indent=2):
    text = yaml.dump(data, Dumper=Dumper, default_flow_style=False, sort_keys=False,
                     allow_unicode=True, indent=indent)
    return text.replace("...\n", "")


def flatten_props(obj, prefix=""):
    rows = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            rows.extend(flatten_props(v, f"{prefix}.{k}" if prefix else str(k)))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            rows.extend(flatten_props(v, f"{prefix}.{i}" if prefix else str(i)))
    else:
        rows.append((prefix, scalar_str(obj)))
    return rows


def scalar_str(x):
    if x is None:
        return "null"
    if x is True:
        return "true"
    if x is False:
        return "false"
    return str(x)


def shell_key(k):
    return re.sub(r"[^A-Za-z0-9_]", "_", k)


def to_csv(rows, sep=","):
    if not isinstance(rows, list):
        rows = [rows]
    keys = []
    for r in rows:
        if isinstance(r, dict):
            for k in r:
                if k not in keys:
                    keys.append(k)
    import io
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=keys, delimiter=sep, lineterminator="\n")
    w.writeheader()
    for r in rows:
        w.writerow({k: scalar_str(r.get(k, "")) if isinstance(r, dict) else scalar_str(r) for k in keys})
    return buf.getvalue()


def format_one(data, fmt, opts):
    fmt = norm_fmt(fmt)
    if fmt in ("auto", "yaml", "kyaml"):
        if opts["unwrap"] and not isinstance(data, (dict, list)):
            return scalar_str(data) + "\n"
        return yaml_dump(data, opts["indent"])
    if fmt == "json":
        return json.dumps(data, indent=opts["indent"], ensure_ascii=False) + "\n"
    if fmt in ("props", "properties"):
        return "".join(k + opts["props_sep"] + v + "\n" for k, v in flatten_props(data))
    if fmt == "shell":
        return "".join(shell_key(k.replace(".", opts["shell_sep"])) + "=" + json.dumps(v) + "\n"
                       for k, v in flatten_props(data))
    if fmt == "csv":
        return to_csv(data, ",")
    if fmt == "tsv":
        return to_csv(data, "\t")
    if fmt == "base64":
        return base64.b64encode(scalar_str(data).encode()).decode() + "\n"
    if fmt == "uri":
        return urllib.parse.quote(scalar_str(data), safe="") + "\n"
    return format_one(data, "yaml", opts)


def choose_output(opts, first_file, input_fmt):
    out = norm_fmt(opts["output"])
    if out != "auto":
        return out
    if first_file:
        ext_fmt = detect_format(first_file, "auto")
        if ext_fmt in ("json",):
            return ext_fmt
    if opts["pretty"]:
        return "yaml" if input_fmt == "json" else input_fmt
    return "yaml"


def main(argv):
    opts = parse_args(argv)
    opts["input"] = norm_fmt(opts["input"])
    opts["output"] = norm_fmt(opts["output"])
    if opts["cmd"] == "eval-all":
        docs = []
        fmts = []
        for f in opts["files"] or ["-"]:
            d, fmt = load_file(f, opts["input"])
            fmts.append(fmt)
            if isinstance(d, list) and fmt in ("yaml", "auto"):
                docs.extend(d)
            else:
                docs.append(d)
        if "ireduce" in opts["expr"] and "*" in opts["expr"]:
            res = {}
            for d in docs:
                res = deep_merge(res, d)
            results = [res]
        else:
            results = eval_expr(docs, opts["expr"], opts["input"])
        out_fmt = choose_output(opts, opts["files"][0] if opts["files"] else "", fmts[0] if fmts else "yaml")
    else:
        if opts["null"]:
            data, fmt = None, "yaml"
            results = eval_expr(data, opts["expr"], opts["input"])
        else:
            files = opts["files"] or (["-"] if not sys.stdin.isatty() else [])
            if not files:
                data, fmt = None, "yaml"
                results = eval_expr(data, opts["expr"], opts["input"])
            else:
                all_results = []
                first_data = None
                first_fmt = None
                for f in files:
                    d, fmt = load_file(f, opts["input"])
                    if first_data is None:
                        first_data, first_fmt = d, fmt
                    all_results.extend(eval_expr(d, opts["expr"], opts["input"]))
                data, fmt, results = first_data, first_fmt, all_results
        out_fmt = choose_output(opts, opts["files"][0] if opts["files"] else "", fmt)
        if opts["inplace"]:
            if not opts["files"]:
                sys.stderr.write("Error: write in place flag only applicable when giving an expression and at least one file\n")
                return 1
            content = format_one(results[0] if len(results) == 1 else results, detect_format(opts["files"][0], "auto"), opts)
            with open(opts["files"][0], "w", encoding="utf-8") as f:
                f.write(content)
            return 0
    sep = "\0" if opts["nul"] else ""
    pieces = []
    for idx, r in enumerate(results):
        if idx and not sep and out_fmt in ("auto", "yaml", "kyaml") and isinstance(r, (dict, list)):
            pieces.append("---\n")
        pieces.append(format_one(r, out_fmt, opts))
    sys.stdout.write(sep.join(pieces))
    bad = not results or any(x is None or x is False for x in results)
    if opts["exit_status"] and bad:
        sys.stderr.write("Error: no matches found\n")
        return 1
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
    except Exception as e:
        sys.stderr.write("Error: %s\n" % e)
        sys.exit(1)
