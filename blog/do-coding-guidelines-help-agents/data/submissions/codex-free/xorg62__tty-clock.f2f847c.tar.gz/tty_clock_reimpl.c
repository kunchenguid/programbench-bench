#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    bool seconds, screensaver, box, center, bold, twelve, utc, rebound;
    bool no_quit, hide_date, blink;
    int color;
    int delay_s;
    long delay_ns;
    const char *date_fmt;
    int x, y;
    int dx, dy;
} Options;

static volatile sig_atomic_t running = 1;
static struct termios saved_termios;
static bool have_saved_termios = false;

static const char *usage_text =
"usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] \n"
"    -s            Show seconds                                   \n"
"    -S            Screensaver mode                                \n"
"    -x            Show box                                        \n"
"    -c            Set the clock at the center of the terminal    \n"
"    -C [0-7]      Set the clock color                            \n"
"    -b            Use bold colors                                \n"
"    -t            Set the hour in 12h format                     \n"
"    -u            Use UTC time                                   \n"
"    -T tty        Display the clock on the specified terminal    \n"
"    -r            Do rebound the clock                           \n"
"    -f format     Set the date format                            \n"
"    -n            Don't quit on keypress                         \n"
"    -v            Show tty-clock version                         \n"
"    -i            Show some info about tty-clock                 \n"
"    -h            Show this page                                 \n"
"    -D            Hide date                                      \n"
"    -B            Enable blinking colon                          \n"
"    -d delay      Set the delay between two redraws of the clock. Default 1s. \n"
"    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.\n";

static const char *digits[10][5] = {
    {" ### ", "#   #", "#   #", "#   #", " ### "},
    {"  #  ", " ##  ", "  #  ", "  #  ", " ### "},
    {" ### ", "#   #", "   # ", "  #  ", "#####"},
    {"#### ", "    #", " ### ", "    #", "#### "},
    {"#   #", "#   #", "#####", "    #", "    #"},
    {"#####", "#    ", "#### ", "    #", "#### "},
    {" ### ", "#    ", "#### ", "#   #", " ### "},
    {"#####", "    #", "   # ", "  #  ", "  #  "},
    {" ### ", "#   #", " ### ", "#   #", " ### "},
    {" ### ", "#   #", " ####", "    #", " ### "}
};

static void on_signal(int sig) {
    (void)sig;
    running = 0;
}

static void cleanup(void) {
    printf("\033[0m\033[?25h\033[?1049l");
    fflush(stdout);
    if (have_saved_termios) {
        tcsetattr(STDIN_FILENO, TCSANOW, &saved_termios);
    }
}

static void print_usage(void) {
    fputs(usage_text, stdout);
}

static void die_tty(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    exit(1);
}

static void setup_terminal(void) {
    const char *term = getenv("TERM");
    if (term == NULL || *term == '\0') {
        die_tty("Error opening terminal: unknown.\n");
    }

    if (isatty(STDIN_FILENO) && tcgetattr(STDIN_FILENO, &saved_termios) == 0) {
        struct termios raw = saved_termios;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 0;
        if (tcsetattr(STDIN_FILENO, TCSANOW, &raw) == 0) {
            have_saved_termios = true;
        }
    }
    atexit(cleanup);
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    printf("\033[?1049h\033[?25l\033[0m\033[H\033[2J");
}

static void term_size(int *rows, int *cols) {
    struct winsize ws;
    *rows = 24;
    *cols = 80;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_row && ws.ws_col) {
        *rows = ws.ws_row;
        *cols = ws.ws_col;
    }
}

static int clock_width(const char *s) {
    int w = 0;
    for (const char *p = s; *p; ++p) {
        if (isdigit((unsigned char)*p)) w += 11;
        else if (*p == ':') w += 2;
        else w += 4;
    }
    return w ? w - 1 : 0;
}

static void put_at(int y, int x, const char *text) {
    printf("\033[%d;%dH%s", y, x, text);
}

static void draw_clock(const Options *opt, const char *timebuf, const char *datebuf) {
    int rows, cols;
    term_size(&rows, &cols);
    int w = clock_width(timebuf);
    int h = 5 + (opt->hide_date ? 0 : 2);
    int left = opt->center ? (cols - w) / 2 + 1 : opt->x;
    int top = opt->center ? (rows - h) / 2 + 1 : opt->y;
    if (left < 1) left = 1;
    if (top < 1) top = 1;

    static const int ansi_colors[8] = {30, 31, 32, 33, 34, 35, 36, 37};
    int attr = ansi_colors[opt->color & 7];
    printf("\033[H\033[2J\033[%d;%dm", opt->bold ? 1 : 0, attr);
    if (opt->blink) printf("\033[5m");

    if (opt->box) {
        char line[256];
        int bw = w + 4;
        if (bw > 250) bw = 250;
        memset(line, '-', (size_t)bw);
        line[bw] = '\0';
        put_at(top, left, line);
        for (int r = 1; r <= h; ++r) {
            put_at(top + r, left, "|");
            put_at(top + r, left + bw - 1, "|");
        }
        put_at(top + h + 1, left, line);
        top += 2;
        left += 2;
    }

    for (int row = 0; row < 5; ++row) {
        printf("\033[%d;%dH", top + row, left);
        for (const char *p = timebuf; *p; ++p) {
            if (isdigit((unsigned char)*p)) {
                const char *pat = digits[*p - '0'][row];
                for (int i = 0; pat[i]; ++i) {
                    if (pat[i] == '#') {
                        printf("\033[%dm  \033[0;%dm", 40 + (opt->color & 7), attr);
                    } else {
                        printf("  ");
                    }
                }
                putchar(' ');
            } else if (*p == ':') {
                if (row == 1 || row == 3) {
                    printf("\033[%dm  \033[0;%dm", 40 + (opt->color & 7), attr);
                } else {
                    printf("  ");
                }
            } else {
                printf(" %c  ", *p);
            }
        }
    }
    if (!opt->hide_date) {
        int dl = left + (w - (int)strlen(datebuf)) / 2;
        if (dl < 1) dl = 1;
        printf("\033[0;%dm", attr);
        put_at(top + 6, dl, datebuf);
    }
    fflush(stdout);
}

static int key_ready(void) {
    fd_set rfds;
    struct timeval tv = {0, 0};
    FD_ZERO(&rfds);
    FD_SET(STDIN_FILENO, &rfds);
    return select(STDIN_FILENO + 1, &rfds, NULL, NULL, &tv) > 0;
}

static void handle_key(Options *opt) {
    unsigned char ch;
    while (key_ready() && read(STDIN_FILENO, &ch, 1) == 1) {
        int c = toupper(ch);
        if (opt->screensaver && !opt->no_quit) running = 0;
        if (c == 'Q' && !opt->no_quit) running = 0;
        else if (c == 'S') opt->seconds = !opt->seconds;
        else if (c == 'T') opt->twelve = !opt->twelve;
        else if (c == 'B') opt->bold = !opt->bold;
        else if (c == 'X') opt->box = !opt->box;
        else if (c == 'C') opt->center = !opt->center;
        else if (c == 'R') opt->rebound = !opt->rebound;
        else if (ch >= '0' && ch <= '7') opt->color = ch - '0';
        else if (!opt->center && c == 'H' && opt->x > 1) opt->x--;
        else if (!opt->center && c == 'L') opt->x++;
        else if (!opt->center && c == 'K' && opt->y > 1) opt->y--;
        else if (!opt->center && c == 'J') opt->y++;
    }
}

static void update_rebound(Options *opt, const char *timebuf) {
    if (!opt->rebound || opt->center) return;
    int rows, cols;
    term_size(&rows, &cols);
    int maxx = cols - clock_width(timebuf);
    int maxy = rows - 7;
    if (maxx < 1) maxx = 1;
    if (maxy < 1) maxy = 1;
    opt->x += opt->dx;
    opt->y += opt->dy;
    if (opt->x <= 1 || opt->x >= maxx) {
        opt->dx = -opt->dx;
        if (opt->x < 1) opt->x = 1;
        if (opt->x > maxx) opt->x = maxx;
    }
    if (opt->y <= 1 || opt->y >= maxy) {
        opt->dy = -opt->dy;
        if (opt->y < 1) opt->y = 1;
        if (opt->y > maxy) opt->y = maxy;
    }
}

static void run_clock(Options opt) {
    setup_terminal();
    while (running) {
        time_t now = time(NULL);
        struct tm tmv;
        if (opt.utc) gmtime_r(&now, &tmv);
        else localtime_r(&now, &tmv);
        char timebuf[32], datebuf[128];
        const char *tfmt = opt.seconds ? (opt.twelve ? "%I:%M:%S" : "%H:%M:%S")
                                       : (opt.twelve ? "%I:%M" : "%H:%M");
        strftime(timebuf, sizeof(timebuf), tfmt, &tmv);
        strftime(datebuf, sizeof(datebuf), opt.date_fmt, &tmv);
        draw_clock(&opt, timebuf, datebuf);
        update_rebound(&opt, timebuf);
        handle_key(&opt);
        struct timespec ts = { opt.delay_s, opt.delay_ns };
        if (ts.tv_sec == 0 && ts.tv_nsec == 0) ts.tv_nsec = 10000000L;
        nanosleep(&ts, NULL);
    }
}

static void use_tty(const char *path) {
    struct stat st;
    if (stat(path, &st) != 0) {
        fprintf(stderr, "tty-clock: error: couldn't stat '%s': %s.\n", path, strerror(errno));
        exit(1);
    }
    if (!S_ISCHR(st.st_mode)) {
        fprintf(stderr, "tty-clock: error: '%s' is not a character device.\n", path);
        exit(1);
    }
    int fd = open(path, O_RDWR);
    if (fd < 0) {
        fprintf(stderr, "tty-clock: error: couldn't open '%s': %s.\n", path, strerror(errno));
        exit(1);
    }
    dup2(fd, STDIN_FILENO);
    dup2(fd, STDOUT_FILENO);
    if (fd > STDERR_FILENO) close(fd);
}

int main(int argc, char **argv) {
    Options opt = {0};
    opt.color = 2;
    opt.delay_s = 1;
    opt.delay_ns = 0;
    opt.date_fmt = "%F";
    opt.x = 1;
    opt.y = 1;
    opt.dx = 1;
    opt.dy = 1;

    opterr = 1;
    int ch;
    while ((ch = getopt(argc, argv, "iuvsScbtrahDBxnC:f:d:a:T:")) != -1) {
        switch (ch) {
            case 's': opt.seconds = true; break;
            case 'S': opt.screensaver = true; break;
            case 'x': opt.box = true; break;
            case 'c': opt.center = true; break;
            case 'C': opt.color = atoi(optarg); break;
            case 'b': opt.bold = true; break;
            case 't': opt.twelve = true; break;
            case 'u': opt.utc = true; break;
            case 'T': use_tty(optarg); break;
            case 'r': opt.rebound = true; break;
            case 'f': opt.date_fmt = optarg; break;
            case 'n': opt.no_quit = true; break;
            case 'D': opt.hide_date = true; break;
            case 'B': opt.blink = true; break;
            case 'd': opt.delay_s = atoi(optarg); if (opt.delay_s < 0) opt.delay_s = 0; break;
            case 'a': opt.delay_ns = atol(optarg); if (opt.delay_ns < 0) opt.delay_ns = 0; break;
            case 'v':
                puts("TTY-Clock 2 © devel version");
                return 0;
            case 'i':
                puts("TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)");
                return 0;
            case 'h':
            case '?':
            default:
                print_usage();
                return 0;
        }
    }
    run_clock(opt);
    return 0;
}
