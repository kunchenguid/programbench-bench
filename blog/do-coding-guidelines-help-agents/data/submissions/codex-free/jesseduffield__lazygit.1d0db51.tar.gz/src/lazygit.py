#!/usr/bin/env python3
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path


VERSION = (
    "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, "
    "build date=2026-03-03T20:51:57Z, build source=unknown, "
    "version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1\n"
)

VALUE_FLAGS = {
    "-p": "path",
    "--path": "path",
    "-f": "filter",
    "--filter": "filter",
    "-ucd": "use_config_dir",
    "--use-config-dir": "use_config_dir",
    "-w": "work_tree",
    "--work-tree": "work_tree",
    "-g": "git_dir",
    "--git-dir": "git_dir",
    "-ucf": "use_config_file",
    "--use-config-file": "use_config_file",
    "-sm": "screen_mode",
    "--screen-mode": "screen_mode",
}

BOOL_FLAGS = {
    "-h": "help",
    "--help": "help",
    "-v": "version",
    "--version": "version",
    "-d": "debug",
    "--debug": "debug",
    "-l": "logs",
    "--logs": "logs",
    "--profile": "profile",
    "-c": "config",
    "--config": "config",
    "-cd": "print_config_dir",
    "--print-config-dir": "print_config_dir",
}


def resource(name: str) -> str:
    return (Path(__file__).resolve().parent / name).read_text()


def stamp() -> str:
    return datetime.now().strftime("%Y/%m/%d %H:%M:%S")


def default_config_dir() -> str:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    if xdg:
        return os.path.join(xdg, "lazygit")
    return os.path.join(os.path.expanduser("~"), ".config", "lazygit")


def log_dir() -> str:
    xdg = os.environ.get("XDG_STATE_HOME")
    if xdg:
        return os.path.join(xdg, "lazygit")
    return os.path.join(os.path.expanduser("~"), ".local", "state", "lazygit")


def print_help() -> None:
    sys.stderr.write(resource("help.txt"))


def parse_args(argv):
    opts = {
        "help": False,
        "version": False,
        "debug": False,
        "logs": False,
        "profile": False,
        "config": False,
        "print_config_dir": False,
        "path": None,
        "filter": None,
        "use_config_dir": None,
        "work_tree": None,
        "git_dir": None,
        "use_config_file": None,
        "screen_mode": None,
        "positionals": [],
    }
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg == "help":
            opts["help"] = True
            i += 1
            continue
        key = None
        val = None
        if "=" in arg:
            left, right = arg.split("=", 1)
            if left in VALUE_FLAGS:
                key = left
                val = right
        if key is None and arg in VALUE_FLAGS:
            key = arg
            if i + 1 >= len(argv):
                print_help()
                sys.stderr.write(f"Expected a following arg for flag {arg.lstrip('-')}, but it did not exist.\n")
                return opts, 2
            i += 1
            val = argv[i]
        if key is not None:
            opts[VALUE_FLAGS[key]] = val
            i += 1
            continue
        if arg in BOOL_FLAGS:
            opts[BOOL_FLAGS[arg]] = True
            i += 1
            continue
        if arg.startswith("-"):
            print_help()
            sys.stderr.write(f"Expected a following arg for flag {arg.lstrip('-')}, but it did not exist.\n")
            return opts, 2
        opts["positionals"].append(arg)
        i += 1
    return opts, 0


def git_ok(cwd: str, opts) -> bool:
    cmd = ["git"]
    if opts.get("work_tree"):
        cmd += [f"--work-tree={opts['work_tree']}"]
    if opts.get("git_dir"):
        cmd += [f"--git-dir={opts['git_dir']}"]
    cmd += ["rev-parse", "--is-inside-work-tree"]
    try:
        result = subprocess.run(cmd, cwd=cwd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return result.returncode == 0
    except Exception:
        return False


def valid_git_path(path: str) -> bool:
    return subprocess.run(
        ["git", "--work-tree", path, "--git-dir", os.path.join(path, ".git"), "rev-parse", "--is-inside-work-tree"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0


def terminal_error() -> None:
    sys.stderr.write(f"{stamp()} An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n\n")
    sys.stderr.write("*fmt.wrapError terminal entry not found: term not set\n")
    sys.stderr.write("/workspace/pkg/app/app.go:55 (0xc91c3f)\n")
    sys.stderr.write("/workspace/pkg/app/entry_point.go:177 (0xc93eb6)\n")
    sys.stderr.write("/workspace/main.go:23 (0xc95258)\n")
    sys.stderr.write("/root/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.25.0.linux-amd64/src/runtime/asm_amd64.s:1693 (0x4888a1)\n")
    sys.stderr.write("\tgoexit: BYTE\t$0x90\t// NOP\n")


def main(argv) -> int:
    opts, parse_code = parse_args(argv)
    if parse_code:
        return parse_code

    if opts["help"]:
        print_help()
        return 0

    config_dir = opts["use_config_dir"] or default_config_dir()

    if opts["path"] and not valid_git_path(opts["path"]):
        sys.stderr.write(f"{stamp()} {opts['path']} is not a valid git repository.\n")
        return 1

    if opts["logs"]:
        log_file = os.path.join(log_dir(), "development.log")
        sys.stdout.write(f"Tailing log file {log_file}\n\n")
        sys.stdout.flush()
        if not os.path.exists(log_file):
            sys.stderr.write(f"{stamp()} Log file does not exist. Run `lazygit --debug` first to create the log file\n")
            return 1
        with open(log_file, "r", errors="replace") as fh:
            sys.stdout.write(fh.read())
        return 0

    if opts["version"]:
        sys.stdout.write(VERSION)
        return 0

    if opts["config"]:
        sys.stdout.write(resource("default_config.yml"))
        return 0

    if opts["print_config_dir"]:
        sys.stdout.write(config_dir + "\n")
        return 0

    if opts["screen_mode"] and opts["screen_mode"] not in {"normal", "half", "full"}:
        # The reference reaches terminal setup before validating this in the non-tty harness.
        terminal_error()
        return 1

    if len(opts["positionals"]) > 1:
        bad = opts["positionals"][1]
    elif opts["positionals"] and opts["positionals"][0] not in {"status", "branch", "log", "stash"}:
        bad = opts["positionals"][0]
    else:
        bad = None
    if bad is not None:
        sys.stderr.write(
            f"{stamp()} Invalid git arg value: '{bad}'. Must be one of the following values: "
            "status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.\n"
        )
        return 1

    cwd = opts["path"] or os.getcwd()
    if not git_ok(cwd, opts):
        sys.stdout.write("Not in a git repository. Create a new git repository? (y/N): ")
        sys.stdout.flush()
        sys.stderr.write("Must open lazygit in a git repository. No valid recent repositories. Exiting.\n")
        return 1

    if os.environ.get("TERM") in (None, ""):
        terminal_error()
        return 1

    sys.stdout.write("lazygit is a terminal UI for git. This reimplementation supports non-interactive CLI behavior.\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
