#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static const char *version = "2.6.0-g87c9c25";

static void print_help(void) {
    printf("tig %s \n\n", version);
    printf("Usage: tig        [options] [revs] [--] [paths]\n");
    printf("   or: tig log    [options] [revs] [--] [paths]\n");
    printf("   or: tig show   [options] [revs] [--] [paths]\n");
    printf("   or: tig reflog [options] [revs]\n");
    printf("   or: tig blame  [options] [rev] [--] path\n");
    printf("   or: tig grep   [options] [pattern]\n");
    printf("   or: tig refs   [options]\n");
    printf("   or: tig stash  [options]\n");
    printf("   or: tig status\n");
    printf("   or: tig <      [git command output]\n\n");
    printf("Options:\n");
    printf("  +<number>       Select line <number> in the first view\n");
    printf("  -v, --version   Show version and exit\n");
    printf("  -h, --help      Show help message and exit\n");
    printf("  -C <path>       Start in <path>\n");
}

static void print_version(void) {
    printf("tig version %s\n", version);
    printf("ncursesw version 6.3.20211021\n");
}

static int is_subcommand(const char *s) {
    return !strcmp(s, "log") || !strcmp(s, "show") || !strcmp(s, "reflog") ||
           !strcmp(s, "blame") || !strcmp(s, "grep") || !strcmp(s, "refs") ||
           !strcmp(s, "stash") || !strcmp(s, "status");
}

static int is_number(const char *s) {
    if (!s || !*s)
        return 0;
    for (; *s; s++)
        if (*s < '0' || *s > '9')
            return 0;
    return 1;
}

static int path_exists(const char *s) {
    struct stat st;
    return stat(s, &st) == 0;
}

static int git_rev_exists(const char *rev) {
    char cmd[4096];
    int n;
    if (!rev || !*rev)
        return 0;
    n = snprintf(cmd, sizeof(cmd),
                 "git rev-parse --verify --quiet '%s' >/dev/null 2>&1", rev);
    if (n < 0 || (size_t)n >= sizeof(cmd))
        return 0;
    return system(cmd) == 0;
}

static void no_revisions(void) {
    fprintf(stderr, "tig: No revisions match the given arguments.\n");
}

static int validate_revisions(int argc, char **argv) {
    int i = 1;
    int command_seen = 0;
    int after_dashdash = 0;
    const char *first_rev = NULL;

    while (i < argc) {
        const char *arg = argv[i];

        if (!strcmp(arg, "--")) {
            after_dashdash = 1;
            i++;
            continue;
        }
        if (!strcmp(arg, "-C")) {
            i += 2;
            continue;
        }
        if (!strncmp(arg, "-C", 2) && arg[2]) {
            i++;
            continue;
        }
        if (arg[0] == '+' && is_number(arg + 1)) {
            i++;
            continue;
        }
        if (!command_seen && is_subcommand(arg)) {
            command_seen = 1;
            i++;
            continue;
        }
        if (arg[0] == '-' && !after_dashdash) {
            i++;
            continue;
        }
        if (!after_dashdash && !first_rev) {
            first_rev = arg;
            break;
        }
        i++;
    }

    if (!first_rev)
        return 1;

    if (path_exists(first_rev))
        return 1;

    if (!git_rev_exists(first_rev)) {
        no_revisions();
        return 0;
    }

    return 1;
}

static int handle_global_options(int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        const char *arg = argv[i];

        if (!strcmp(arg, "-C")) {
            if (i + 1 < argc) {
                if (chdir(argv[i + 1]) != 0) {
                    fprintf(stderr, "tig: Failed to change directory to %s\n", argv[i + 1]);
                    exit(1);
                }
                i++;
            }
            continue;
        }

        if (!strncmp(arg, "-C", 2) && arg[2]) {
            if (chdir(arg + 2) != 0) {
                fprintf(stderr, "tig: Failed to change directory to %s\n", arg + 2);
                exit(1);
            }
            continue;
        }

        if (!strcmp(arg, "-h") || !strcmp(arg, "--help")) {
            print_help();
            exit(0);
        }

        if (!strcmp(arg, "-v") || !strcmp(arg, "--version")) {
            print_version();
            exit(0);
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    (void)argv;
    handle_global_options(argc, argv);

    if (!validate_revisions(argc, argv))
        return 1;

    int tty = open("/dev/tty", O_RDONLY);
    if (tty < 0) {
        fprintf(stderr, "tig: Failed to open tty for input\n");
        return 1;
    }
    close(tty);

    fprintf(stderr, "tig: Failed to open tty for input\n");
    return 1;
}
