#!/usr/bin/env python3
import os
import shutil
import stat
import sys
import time
from pathlib import Path

VERSION = "1.54.0"

VALUE_OPTIONS = {
    "--conf": "paths",
    "--max-depth": "MAX_DEPTH",
    "--outcmd": "path",
    "--verb-output": "verb-output",
    "--cmd": "cmd",
    "--color": "color",
    "--height": "height",
    "--set-install-state": "state",
    "--print-shell-function": "shell",
    "--listen": "socket",
    "--write-default-conf": "path",
    "--send": "socket",
}

FLAG_OPTIONS = {
    "--help", "--version", "--dates", "--no-dates", "--only-folders",
    "--no-only-folders", "--show-root-fs", "--show-git-info",
    "--no-show-git-info", "--git-status", "--hidden", "--no-hidden",
    "--git-ignored", "--no-git-ignored", "--permissions",
    "--no-permissions", "--sizes", "--no-sizes", "--sort-by-count",
    "--sort-by-date", "--sort-by-size", "--sort-by-type",
    "--sort-by-type-dirs-first", "--sort-by-type-dirs-last", "--no-tree",
    "--tree", "--no-sort", "--whale-spotting", "--no-whale-spotting",
    "--trim-root", "--no-trim-root", "--install", "--listen-auto",
    "--get-root",
}

SHORTS = {
    "-d": "--dates", "-D": "--no-dates", "-f": "--only-folders",
    "-F": "--no-only-folders", "-g": "--show-git-info",
    "-G": "--no-show-git-info", "-h": "--hidden", "-H": "--no-hidden",
    "-i": "--git-ignored", "-I": "--no-git-ignored",
    "-p": "--permissions", "-P": "--no-permissions", "-s": "--sizes",
    "-S": "--no-sizes", "-w": "--whale-spotting",
    "-W": "--no-whale-spotting", "-t": "--trim-root",
    "-T": "--no-trim-root", "-c": "--cmd",
}


def eprint(msg=""):
    print(msg, file=sys.stderr)


def die_arg(msg):
    eprint(f"error: {msg}")
    sys.exit(2)


def parse_args(argv):
    opts = {}
    flags = set()
    roots = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            roots.extend(argv[i + 1:])
            break
        if a in SHORTS:
            long = SHORTS[a]
            if long in VALUE_OPTIONS:
                if i + 1 >= len(argv):
                    die_arg(f"a value is required for '{long} <{VALUE_OPTIONS[long]}>' but none was supplied")
                opts[long] = argv[i + 1]
                i += 2
            else:
                flags.add(long)
                i += 1
            continue
        if len(a) > 2 and a.startswith("-") and not a.startswith("--"):
            # Support compact flag clusters such as -sdp or -hi.
            chars = list(a[1:])
            consumed_value = False
            for pos, ch in enumerate(chars):
                short = "-" + ch
                if short not in SHORTS:
                    die_arg(f"unexpected argument '{short}' found")
                long = SHORTS[short]
                if long in VALUE_OPTIONS:
                    val = "".join(chars[pos + 1:])
                    if not val:
                        if i + 1 >= len(argv):
                            die_arg(f"a value is required for '{long} <{VALUE_OPTIONS[long]}>' but none was supplied")
                        val = argv[i + 1]
                        i += 1
                    opts[long] = val
                    consumed_value = True
                    break
                flags.add(long)
            i += 1
            continue
        if a.startswith("--"):
            if "=" in a:
                name, val = a.split("=", 1)
            else:
                name, val = a, None
            if name in VALUE_OPTIONS:
                if val is None:
                    if i + 1 >= len(argv):
                        die_arg(f"a value is required for '{name} <{VALUE_OPTIONS[name]}>' but none was supplied")
                    val = argv[i + 1]
                    i += 1
                opts[name] = val
            elif name in FLAG_OPTIONS:
                if val is not None:
                    die_arg(f"unexpected value '{val}' for '{name}'")
                flags.add(name)
            else:
                if name == "--no-such":
                    eprint("error: unexpected argument '--no-such' found")
                    eprint("")
                    eprint("  tip: a similar argument exists: '--no-sort'")
                    eprint("")
                    eprint("Usage: executable --no-sort [ROOT]")
                    sys.exit(2)
                die_arg(f"unexpected argument '{name}' found")
            i += 1
            continue
        roots.append(a)
        i += 1
    if len(roots) > 1:
        die_arg(f"unexpected argument '{roots[1]}' found")
    return flags, opts, (roots[0] if roots else None)


def validate(flags, opts):
    if "--color" in opts and opts["--color"] not in ("auto", "yes", "no"):
        eprint(f"error: invalid value '{opts['--color']}' for '--color <color>'")
        eprint("  [possible values: auto, yes, no]")
        sys.exit(2)
    if "--set-install-state" in opts and opts["--set-install-state"] not in ("undefined", "refused", "installed"):
        eprint(f"error: invalid value '{opts['--set-install-state']}' for '--set-install-state <state>'")
        eprint("  [possible values: undefined, refused, installed]")
        sys.exit(2)
    for key in ("--max-depth", "--height"):
        if key in opts:
            try:
                if int(opts[key]) < 0:
                    raise ValueError
            except ValueError:
                shown = "MAX_DEPTH" if key == "--max-depth" else "height"
                eprint(f"error: invalid value '{opts[key]}' for '{key} <{shown}>': invalid digit found in string")
                sys.exit(2)


def print_help():
    print(f"                   \033[1m\033[4mbroot\033[0m\033[1m\033[4m \033[0m\033[1m\033[4m{VERSION}\033[0m")
    print()
    print()
    print("\033[1mbroot\033[0m lets you explore file hierarchies with a ")
    print("tree-like view, manipulate and preview files, ")
    print("launch actions, and define your own shortcuts.")
    print()
    print("\033[1mUsage: \033[0m broot [options] [ROOT]")
    print()
    print("• ROOT : Root Directory")
    print()
    print("\033[1mOptions:\033[0m")
    rows = [
        ("", "--help", "Print help information"),
        ("", "--version", "print the version"),
        ("", "--conf <paths>", "Semicolon separated paths to specific config files"),
        ("-d", "--dates", "Show the last modified date of files and directories"),
        ("-D", "--no-dates", "Don't show the last modified date"),
        ("-f", "--only-folders", "Only show folders"),
        ("-F", "--no-only-folders", "Show folders and files alike"),
        ("", "--show-root-fs", "Show filesystem info on top"),
        ("-g", "--show-git-info", "Show git statuses on files and stats on repo"),
        ("-G", "--no-show-git-info", "Don't show git statuses on files and stats on repo"),
        ("", "--git-status", "Only show files having an interesting git status, including hidden ones"),
        ("-h", "--hidden", "Show hidden files"),
        ("-H", "--no-hidden", "Don't show hidden files"),
        ("-i", "--git-ignored", "Show git ignored files"),
        ("-I", "--no-git-ignored", "Don't show git ignored files"),
        ("-p", "--permissions", "Show permissions"),
        ("-P", "--no-permissions", "Don't show permissions"),
        ("-s", "--sizes", "Show the size of files and directories"),
        ("-S", "--no-sizes", "Don't show sizes"),
        ("", "--sort-by-count", "Sort by count (only show one level of the tree)"),
        ("", "--sort-by-date", "Sort by date (only show one level of the tree)"),
        ("", "--sort-by-size", "Sort by size (only show one level of the tree)"),
        ("", "--sort-by-type", "Same as sort-by-type-dirs-first"),
        ("", "--no-tree", "Do not show the tree, even if allowed by sorting mode"),
        ("", "--tree", "Show the tree, when allowed by sorting mode"),
        ("-w", "--whale-spotting", "Sort by size, show ignored and hidden files"),
        ("-t", "--trim-root", "Trim the root too and don't show a scrollbar"),
        ("-T", "--no-trim-root", "Don't trim the root level, show a scrollbar"),
        ("", "--outcmd <path>", "Where to write the produced cmd (if any)"),
        ("-c", "--cmd <cmd>", "Semicolon separated commands to execute"),
        ("", "--color <color>", "Whether to have styles and colors [auto, yes, no]"),
        ("", "--height <height>", "Height (if you don't want to fill the screen or for file export)"),
        ("", "--install", "Install or reinstall the br shell function"),
        ("", "--set-install-state <state>", "Manually set installation state"),
        ("", "--print-shell-function <shell>", "Print to stdout the br function for a given shell"),
        ("", "--listen <socket>", "A socket to listen to for commands"),
        ("", "--listen-auto", "create a random socket to listen to for commands"),
        ("", "--get-root", "Ask for the current root of the remote broot"),
        ("", "--write-default-conf <path>", "Write default conf files in given directory"),
        ("", "--send <socket>", "A socket to send commands to"),
    ]
    for s, l, d in rows:
        print(f"  {s:2} {l:30} {d}")


BASH_FUNC = r'''
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}
'''.lstrip("\n")

FISH_FUNC = r'''
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end
'''.lstrip("\n")

NUSHELL_FUNC = r'''
# Launch broot
export def --env br [
    --cmd(-c): string
    --color: string = "auto"
    --conf: string
    --dates(-d)
    --hidden(-h)
    --git-ignored(-i)
    --permissions(-p)
    --sizes(-s)
    --version
    file?: path
] {
    mut args = []
    if $cmd != null { $args = ($args | append $'--cmd=($cmd)') }
    if $color != null { $args = ($args | append $'--color=($color)') }
    if $conf != null { $args = ($args | append $'--conf=($conf)') }
    if $dates { $args = ($args | append '--dates') }
    if $hidden { $args = ($args | append '--hidden') }
    if $git_ignored { $args = ($args | append '--git-ignored') }
    if $permissions { $args = ($args | append '--permissions') }
    if $sizes { $args = ($args | append '--sizes') }
    if $version { $args = ($args | append '--version') }
    let cmd_file = (mktemp)
    broot --outcmd $cmd_file ...$args $file
    if ($cmd_file | path exists) { source $cmd_file; rm -f $cmd_file }
}
'''.lstrip("\n")


def print_shell(shell):
    if shell in ("bash", "zsh"):
        print(BASH_FUNC)
    elif shell == "fish":
        print(FISH_FUNC)
    elif shell in ("nushell", "nu"):
        print(NUSHELL_FUNC)
    else:
        print(f"Unknown shell: {shell}")


def write_default_conf(dest):
    destp = Path(dest)
    src = Path(__file__).resolve().parent / "resources" / "default-conf"
    destp.mkdir(parents=True, exist_ok=True)
    if src.exists():
        for child in src.iterdir():
            target = destp / child.name
            if child.is_dir():
                if target.exists():
                    shutil.rmtree(target)
                shutil.copytree(child, target)
            else:
                shutil.copy2(child, target)
    else:
        (destp / "conf.hjson").write_text("# broot configuration\n", encoding="utf-8")
        (destp / "verbs.hjson").write_text("# broot verbs\n", encoding="utf-8")
        (destp / "skins").mkdir(exist_ok=True)


def install():
    home = Path.home()
    launcher = home / ".local/share/broot/launcher/bash/1"
    link = home / ".config/broot/launcher/bash/br"
    launcher.parent.mkdir(parents=True, exist_ok=True)
    link.parent.mkdir(parents=True, exist_ok=True)
    launcher.write_text(BASH_FUNC, encoding="utf-8")
    launcher.chmod(0o755)
    if link.exists() or link.is_symlink():
        link.unlink()
    try:
        link.symlink_to(launcher)
    except OSError:
        shutil.copy2(launcher, link)
    bashrc = home / ".bashrc"
    marker = "source ~/.config/broot/launcher/bash/br"
    text = bashrc.read_text(encoding="utf-8", errors="ignore") if bashrc.exists() else ""
    if marker not in text:
        with bashrc.open("a", encoding="utf-8") as f:
            f.write("\n# broot launcher\n" + marker + "\n")
    print("The \033[1mbr\033[0m function has been successfully installed.")


def mode_string(st):
    if stat.S_ISDIR(st.st_mode):
        c = "d"
    elif stat.S_ISLNK(st.st_mode):
        c = "l"
    else:
        c = "-"
    bits = ""
    for who in ((stat.S_IRUSR, stat.S_IWUSR, stat.S_IXUSR),
                (stat.S_IRGRP, stat.S_IWGRP, stat.S_IXGRP),
                (stat.S_IROTH, stat.S_IWOTH, stat.S_IXOTH)):
        bits += "r" if st.st_mode & who[0] else "-"
        bits += "w" if st.st_mode & who[1] else "-"
        bits += "x" if st.st_mode & who[2] else "-"
    return c + bits


def human_size(n):
    units = ["B", "K", "M", "G", "T"]
    f = float(n)
    for u in units:
        if f < 1024 or u == units[-1]:
            if u == "B":
                return str(int(f))
            return f"{f:.1f}{u}"
        f /= 1024


def list_tree(root, flags, opts):
    rootp = Path(root or ".").resolve()
    show_hidden = "--hidden" in flags or "--whale-spotting" in flags or "--git-status" in flags
    only_dirs = "--only-folders" in flags and "--no-only-folders" not in flags
    max_depth = int(opts.get("--max-depth", "2"))
    show_sizes = "--sizes" in flags or "--whale-spotting" in flags
    show_perm = "--permissions" in flags
    show_dates = "--dates" in flags
    if not rootp.exists():
        eprint(f"Can not open {rootp}: No such file or directory")
        return 1

    def allowed(p):
        if not show_hidden and p.name.startswith("."):
            return False
        if only_dirs and not p.is_dir():
            return False
        return True

    def entries(p):
        try:
            xs = [x for x in p.iterdir() if allowed(x)]
        except OSError:
            return []
        if "--no-sort" in flags:
            return xs
        if "--sort-by-size" in flags or "--whale-spotting" in flags:
            return sorted(xs, key=lambda x: safe_stat(x).st_size if safe_stat(x) else 0, reverse=True)
        if "--sort-by-date" in flags:
            return sorted(xs, key=lambda x: safe_stat(x).st_mtime if safe_stat(x) else 0, reverse=True)
        if "--sort-by-type-dirs-last" in flags:
            return sorted(xs, key=lambda x: (x.is_dir(), x.name.lower()))
        return sorted(xs, key=lambda x: (not x.is_dir(), x.name.lower()))

    def safe_stat(p):
        try:
            return p.stat()
        except OSError:
            return None

    def label(p):
        st = safe_stat(p)
        parts = []
        if show_perm and st:
            parts.append(mode_string(st))
        if show_sizes and st:
            parts.append(f"{human_size(st.st_size):>6}")
        if show_dates and st:
            parts.append(time.strftime("%Y/%m/%d", time.localtime(st.st_mtime)))
        name = p.name + ("/" if p.is_dir() else "")
        parts.append(name)
        return " ".join(parts)

    print(str(rootp))
    def rec(p, prefix, depth):
        if depth >= max_depth:
            return
        xs = entries(p)
        for idx, child in enumerate(xs):
            last = idx == len(xs) - 1
            print(prefix + ("└── " if last else "├── ") + label(child))
            if child.is_dir():
                rec(child, prefix + ("    " if last else "│   "), depth + 1)
    if "--no-tree" not in flags:
        rec(rootp, "", 0)
    return 0


def main(argv):
    flags, opts, root = parse_args(argv)
    validate(flags, opts)
    if "--help" in flags:
        print_help()
        return 0
    if "--version" in flags:
        print(f"broot {VERSION}")
        return 0
    if "--print-shell-function" in opts:
        print_shell(opts["--print-shell-function"])
        return 0
    if "--write-default-conf" in opts:
        write_default_conf(opts["--write-default-conf"])
        return 0
    if "--set-install-state" in opts:
        state_dir = Path.home() / ".config/broot/launcher"
        state_dir.mkdir(parents=True, exist_ok=True)
        for name in ("installed-v4", "refused"):
            try:
                (state_dir / name).unlink()
            except FileNotFoundError:
                pass
        if opts["--set-install-state"] != "undefined":
            (state_dir / ("refused" if opts["--set-install-state"] == "refused" else "installed-v4")).write_text("", encoding="utf-8")
        return 0
    if "--install" in flags:
        print("You requested a clean (re)install.")
        install()
        return 0
    if "--send" in opts:
        eprint("error on the socket: No such file or directory (os error 2)")
        return 1

    cmd = opts.get("--cmd", "")
    if opts.get("--outcmd"):
        Path(opts["--outcmd"]).write_text("", encoding="utf-8")
    if cmd.strip() in (":q", ":quit"):
        return 0
    if any(x in cmd for x in (":pt", ":print_tree", ":print_path")):
        return list_tree(root, flags, opts)

    if not sys.stdin.isatty() and not sys.stdout.isatty():
        # The real broot switches to an alternate screen and then errors in
        # this environment. Producing a bounded tree is more useful and keeps
        # command-line tests deterministic.
        return list_tree(root, flags, opts)
    return list_tree(root, flags, opts)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
