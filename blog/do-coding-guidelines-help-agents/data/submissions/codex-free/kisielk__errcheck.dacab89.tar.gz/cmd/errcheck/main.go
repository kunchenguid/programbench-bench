package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/importer"
	"go/parser"
	"go/token"
	"go/types"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strings"
)

type listFlag []string

func (f *listFlag) String() string { return strings.Join(*f, ",") }
func (f *listFlag) Set(s string) error {
	for _, p := range strings.FieldsFunc(s, func(r rune) bool { return r == ',' || r == ' ' }) {
		if p != "" {
			*f = append(*f, p)
		}
	}
	return nil
}

type pkgInfo struct {
	ImportPath      string
	Dir             string
	GoFiles         []string
	CgoFiles        []string
	IgnoredGoFiles  []string
	CompiledGoFiles []string
	TestGoFiles     []string
	XTestGoFiles    []string
	DepOnly         bool
	Error           *struct{ Err string }
}

type issue struct {
	pos  token.Position
	line string
}

var errorType = types.Universe.Lookup("error").Type().Underlying().(*types.Interface)

func main() {
	var (
		abspath         = flag.Bool("abspath", false, "print absolute paths to files")
		asserts         = flag.Bool("asserts", false, "if true, check for ignored type assertion results")
		blank           = flag.Bool("blank", false, "if true, check for errors assigned to blank identifier")
		excludeFile     = flag.String("exclude", "", "Path to a file containing a list of functions to exclude from checking")
		excludeOnly     = flag.Bool("excludeonly", false, "Use only excludes from -exclude file")
		ignoreGenerated = flag.Bool("ignoregenerated", false, "if true, checking of files with generated code is disabled")
		ignoreTests     = flag.Bool("ignoretests", false, "if true, checking of _test.go files is disabled")
		ignorePkg       = flag.String("ignorepkg", "", "comma-separated list of package paths to ignore")
		mod             = flag.String("mod", "", "module download mode to use: readonly or vendor. See 'go help modules' for more.")
		verbose         = flag.Bool("verbose", false, "produce more verbose logging")
		tags            listFlag
		ignore          listFlag
	)
	flag.Var(&ignore, "ignore", "[deprecated] comma-separated list of pairs of the form pkg:regex\n            the regex is used to ignore names within pkg.")
	flag.Var(&tags, "tags", "comma or space-separated list of build tags to include")
	flag.Parse()

	excludes := map[string]bool{}
	if !*excludeOnly {
		addDefaultExcludes(excludes)
	}
	if *excludeFile != "" {
		if err := loadExcludeFile(*excludeFile, excludes); err != nil {
			fmt.Fprintf(os.Stderr, "error: failed to read exclude file: %v\n", err)
			os.Exit(2)
		}
	}

	ignores, err := parseIgnores(ignore, *ignorePkg)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: %v\n", err)
		os.Exit(2)
	}
	if _, ok := ignores["fmt"]; !ok && !*excludeOnly {
		ignores["fmt"] = regexp.MustCompile(".*")
	}
	if *verbose {
		for e := range excludes {
			fmt.Fprintf(os.Stderr, "excluding %s\n", e)
		}
	}

	args := flag.Args()
	if len(args) == 0 {
		args = []string{"."}
	}
	pkgs, err := goList(args, tags, *mod)
	if err != nil {
		fmt.Fprintf(os.Stderr, "error: failed to check packages: %v\n", err)
		os.Exit(2)
	}

	hadIssue := false
	sigs := collectSigs(pkgs)
	for _, p := range pkgs {
		if p.DepOnly {
			continue
		}
		if p.Error != nil {
			fmt.Fprintf(os.Stderr, "error: failed to check packages: %s\n", p.Error.Err)
			os.Exit(2)
		}
		issues, err := checkPackage(p, *abspath, *asserts, *blank, *ignoreGenerated, *ignoreTests, excludes, ignores, sigs)
		if err != nil {
			fmt.Fprintf(os.Stderr, "error: failed to check packages: %v\n", err)
			os.Exit(2)
		}
		for _, is := range issues {
			fmt.Printf("%s:%d:%d:\t%s\n", is.pos.Filename, is.pos.Line, is.pos.Column, is.line)
			hadIssue = true
		}
	}
	if hadIssue {
		os.Exit(1)
	}
}

func goList(patterns []string, tags []string, mod string) ([]pkgInfo, error) {
	args := []string{"list", "-e", "-deps", "-json"}
	if len(tags) > 0 {
		args = append(args, "-tags="+strings.Join(tags, " "))
	}
	if mod != "" {
		args = append(args, "-mod="+mod)
	}
	args = append(args, patterns...)
	cmd := exec.Command("go", args...)
	out, err := cmd.CombinedOutput()
	if err != nil && len(out) == 0 {
		return nil, fmt.Errorf("%s", strings.TrimSpace(string(out)))
	}
	dec := json.NewDecoder(bytes.NewReader(out))
	var pkgs []pkgInfo
	for {
		var p pkgInfo
		if err := dec.Decode(&p); err != nil {
			if err.Error() == "EOF" {
				break
			}
			return nil, err
		}
		pkgs = append(pkgs, p)
	}
	return pkgs, nil
}

func checkPackage(p pkgInfo, abspath, asserts, blank, ignoreGenerated, ignoreTests bool, excludes map[string]bool, ignores map[string]*regexp.Regexp, sigs map[string][]bool) ([]issue, error) {
	var files []string
	files = append(files, p.GoFiles...)
	files = append(files, p.CgoFiles...)
	if !ignoreTests {
		files = append(files, p.TestGoFiles...)
	}
	fset := token.NewFileSet()
	lineText := map[string][]string{}
	generated := map[string]bool{}
	var astFiles []*ast.File
	for _, name := range files {
		path := filepath.Join(p.Dir, name)
		src, err := os.ReadFile(path)
		if err != nil {
			return nil, err
		}
		lineText[path] = splitLines(src)
		if ignoreGenerated && isGenerated(src) {
			generated[path] = true
			continue
		}
		f, err := parser.ParseFile(fset, path, src, parser.ParseComments)
		if err != nil {
			return nil, err
		}
		astFiles = append(astFiles, f)
	}
	if len(astFiles) == 0 {
		return nil, nil
	}
	info := &types.Info{
		Types:      map[ast.Expr]types.TypeAndValue{},
		Uses:       map[*ast.Ident]types.Object{},
		Selections: map[*ast.SelectorExpr]*types.Selection{},
	}
	conf := types.Config{
		Importer: importer.Default(),
		Error:    func(error) {},
	}
	_, _ = conf.Check(p.ImportPath, fset, astFiles, info)

	var out []issue
	add := func(filePos token.Position) {
		if filePos.Filename == "" || generated[filePos.Filename] {
			return
		}
		lines := lineText[filePos.Filename]
		line := ""
		if filePos.Line > 0 && filePos.Line <= len(lines) {
			line = lines[filePos.Line-1]
		}
		if !abspath {
			if rel, err := filepath.Rel(p.Dir, filePos.Filename); err == nil && !strings.HasPrefix(rel, "..") {
				filePos.Filename = rel
			}
		}
		out = append(out, issue{pos: filePos, line: line})
	}

	ast.Inspect(astFiles[0], func(ast.Node) bool { return true })
	for _, f := range astFiles {
		imports := fileImports(f)
		ast.Inspect(f, func(n ast.Node) bool {
			switch x := n.(type) {
			case *ast.ExprStmt:
				if c, ok := x.X.(*ast.CallExpr); ok && callReturnsError(c, info, sigs, imports, p.ImportPath) && !isIgnored(c, info, excludes, ignores) {
					add(fset.Position(c.Lparen))
				}
			case *ast.GoStmt:
				if x.Call != nil && callReturnsError(x.Call, info, sigs, imports, p.ImportPath) && !isIgnored(x.Call, info, excludes, ignores) {
					add(fset.Position(x.Call.Lparen))
				}
			case *ast.DeferStmt:
				if x.Call != nil && callReturnsError(x.Call, info, sigs, imports, p.ImportPath) && !isIgnored(x.Call, info, excludes, ignores) {
					add(fset.Position(x.Call.Lparen))
				}
			case *ast.AssignStmt:
				if blankPos, ok := assignmentBlanksError(x, info, sigs, imports, p.ImportPath); blank && ok {
					add(fset.Position(blankPos))
				}
				if assertPos, ok := assignmentBlanksAssert(x); asserts && ok {
					add(fset.Position(assertPos))
				}
			case *ast.ValueSpec:
				if blankPos, ok := valueSpecBlanksError(x, info, sigs, imports, p.ImportPath); blank && ok {
					add(fset.Position(blankPos))
				}
			}
			return true
		})
	}
	return out, nil
}

func splitLines(src []byte) []string {
	s := strings.ReplaceAll(string(src), "\r\n", "\n")
	if strings.HasSuffix(s, "\n") {
		s = strings.TrimSuffix(s, "\n")
	}
	if s == "" {
		return nil
	}
	return strings.Split(s, "\n")
}

func isGenerated(src []byte) bool {
	for _, line := range strings.Split(string(src), "\n") {
		if strings.Contains(line, "Code generated") && strings.Contains(line, "DO NOT EDIT.") {
			return true
		}
	}
	return false
}

func collectSigs(pkgs []pkgInfo) map[string][]bool {
	out := map[string][]bool{}
	for _, p := range pkgs {
		files := append([]string{}, p.GoFiles...)
		files = append(files, p.CgoFiles...)
		files = append(files, p.TestGoFiles...)
		for _, name := range files {
			path := filepath.Join(p.Dir, name)
			f, err := parser.ParseFile(token.NewFileSet(), path, nil, 0)
			if err != nil {
				continue
			}
			for _, d := range f.Decls {
				fd, ok := d.(*ast.FuncDecl)
				if !ok || fd.Type.Results == nil {
					continue
				}
				results := fieldListErrorResults(fd.Type.Results)
				if !hasTrue(results) {
					continue
				}
				if fd.Recv == nil {
					out[p.ImportPath+"."+fd.Name.Name] = results
				}
			}
		}
	}
	return out
}

func fieldListErrorResults(fl *ast.FieldList) []bool {
	if fl == nil {
		return nil
	}
	var out []bool
	for _, f := range fl.List {
		n := 1
		if len(f.Names) > 0 {
			n = len(f.Names)
		}
		for i := 0; i < n; i++ {
			out = append(out, exprIsError(f.Type))
		}
	}
	return out
}

func hasTrue(v []bool) bool {
	for _, b := range v {
		if b {
			return true
		}
	}
	return false
}

func exprIsError(e ast.Expr) bool {
	switch x := e.(type) {
	case *ast.Ident:
		return x.Name == "error"
	case *ast.SelectorExpr:
		return x.Sel.Name == "error" || x.Sel.Name == "Error"
	}
	return false
}

func fileImports(f *ast.File) map[string]string {
	out := map[string]string{}
	for _, im := range f.Imports {
		path := strings.Trim(im.Path.Value, "\"")
		name := filepath.Base(path)
		if im.Name != nil {
			name = im.Name.Name
		}
		if name != "." && name != "_" {
			out[name] = path
		}
	}
	return out
}

func fallbackNames(c *ast.CallExpr, imports map[string]string, currentPkg string) []string {
	switch f := c.Fun.(type) {
	case *ast.Ident:
		return []string{currentPkg + "." + f.Name}
	case *ast.SelectorExpr:
		if id, ok := f.X.(*ast.Ident); ok {
			if path := imports[id.Name]; path != "" {
				return []string{path + "." + f.Sel.Name}
			}
		}
	}
	return nil
}

func callReturnsError(c *ast.CallExpr, info *types.Info, sigs map[string][]bool, imports map[string]string, currentPkg string) bool {
	t := info.Types[c].Type
	for _, rt := range resultTypes(t) {
		if isError(rt) {
			return true
		}
	}
	for _, name := range fallbackNames(c, imports, currentPkg) {
		if hasTrue(sigs[name]) {
			return true
		}
	}
	return false
}

func fallbackResults(c *ast.CallExpr, sigs map[string][]bool, imports map[string]string, currentPkg string) []bool {
	for _, name := range fallbackNames(c, imports, currentPkg) {
		if r := sigs[name]; len(r) > 0 {
			return r
		}
	}
	return nil
}

func resultTypes(t types.Type) []types.Type {
	if t == nil {
		return nil
	}
	if tup, ok := t.(*types.Tuple); ok {
		var r []types.Type
		for i := 0; i < tup.Len(); i++ {
			r = append(r, tup.At(i).Type())
		}
		return r
	}
	return []types.Type{t}
}

func isError(t types.Type) bool {
	if t == nil {
		return false
	}
	return types.Implements(t, errorType) || types.AssignableTo(t, errorType)
}

func assignmentBlanksError(a *ast.AssignStmt, info *types.Info, sigs map[string][]bool, imports map[string]string, currentPkg string) (token.Pos, bool) {
	if len(a.Rhs) == 1 {
		if c, ok := a.Rhs[0].(*ast.CallExpr); ok {
			res := resultTypes(info.Types[c].Type)
			fallback := fallbackResults(c, sigs, imports, currentPkg)
			for i, lhs := range a.Lhs {
				if ident, ok := lhs.(*ast.Ident); ok && ident.Name == "_" {
					if i < len(res) && isError(res[i]) {
						return ident.Pos(), true
					}
					if len(res) == 0 && i < len(fallback) && fallback[i] {
						return ident.Pos(), true
					}
				}
			}
		}
		return token.NoPos, false
	}
	for i, rhs := range a.Rhs {
		c, ok := rhs.(*ast.CallExpr)
		if !ok || i >= len(a.Lhs) {
			continue
		}
		if ident, ok := a.Lhs[i].(*ast.Ident); ok && ident.Name == "_" && callReturnsError(c, info, sigs, imports, currentPkg) {
			return ident.Pos(), true
		}
	}
	return token.NoPos, false
}

func valueSpecBlanksError(v *ast.ValueSpec, info *types.Info, sigs map[string][]bool, imports map[string]string, currentPkg string) (token.Pos, bool) {
	for i, name := range v.Names {
		if name.Name != "_" || i >= len(v.Values) {
			continue
		}
		if c, ok := v.Values[i].(*ast.CallExpr); ok && callReturnsError(c, info, sigs, imports, currentPkg) {
			return name.Pos(), true
		}
	}
	return token.NoPos, false
}

func assignmentBlanksAssert(a *ast.AssignStmt) (token.Pos, bool) {
	if len(a.Rhs) != 1 {
		return token.NoPos, false
	}
	if _, ok := a.Rhs[0].(*ast.TypeAssertExpr); !ok {
		return token.NoPos, false
	}
	if len(a.Lhs) >= 2 {
		if id, ok := a.Lhs[1].(*ast.Ident); ok && id.Name == "_" {
			return id.Pos(), true
		}
	}
	return token.NoPos, false
}

func addDefaultExcludes(m map[string]bool) {
	for _, s := range []string{
		"fmt.Errorf", "fmt.Print", "fmt.Printf", "fmt.Println", "fmt.Fprint", "fmt.Fprintf", "fmt.Fprintln",
		"fmt.Sprint", "fmt.Sprintf", "fmt.Sprintln",
		"(bytes.Buffer).Write", "(*bytes.Buffer).Write", "(strings.Builder).Write", "(*strings.Builder).Write",
		"(hash.Hash).Write", "(hash.Hash32).Write", "(hash.Hash64).Write",
	} {
		m[s] = true
	}
}

func loadExcludeFile(path string, m map[string]bool) error {
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "//") {
			continue
		}
		m[line] = true
	}
	return nil
}

func parseIgnores(vals []string, pkgs string) (map[string]*regexp.Regexp, error) {
	out := map[string]*regexp.Regexp{}
	for _, v := range vals {
		for _, part := range strings.Split(v, ",") {
			part = strings.TrimSpace(part)
			if part == "" {
				continue
			}
			pkg := ""
			pat := part
			if i := strings.Index(part, ":"); i >= 0 {
				pkg, pat = part[:i], part[i+1:]
			}
			re, err := regexp.Compile(pat)
			if err != nil {
				return nil, err
			}
			out[pkg] = re
		}
	}
	for _, p := range strings.Split(pkgs, ",") {
		p = strings.TrimSpace(p)
		if p != "" {
			out[p] = regexp.MustCompile(".*")
		}
	}
	return out, nil
}

func isIgnored(c *ast.CallExpr, info *types.Info, excludes map[string]bool, ignores map[string]*regexp.Regexp) bool {
	names := callNames(c, info)
	for _, name := range names {
		if excludes[name] {
			return true
		}
		pkg, fn := splitName(name)
		if re, ok := ignores[pkg]; ok && re.MatchString(fn) {
			return true
		}
		if re, ok := ignores[""]; ok && re.MatchString(fn) {
			return true
		}
	}
	return false
}

func callNames(c *ast.CallExpr, info *types.Info) []string {
	switch f := c.Fun.(type) {
	case *ast.Ident:
		if obj := info.Uses[f]; obj != nil {
			if sig, ok := obj.Type().(*types.Signature); ok && sig.Recv() == nil {
				if pkg := obj.Pkg(); pkg != nil {
					return []string{pkg.Path() + "." + obj.Name(), obj.Name()}
				}
				return []string{obj.Name()}
			}
		}
		return []string{f.Name}
	case *ast.SelectorExpr:
		var out []string
		if sel := info.Selections[f]; sel != nil {
			obj := sel.Obj()
			if obj != nil {
				if pkg := obj.Pkg(); pkg != nil {
					out = append(out, pkg.Path()+"."+obj.Name())
				}
				if sig, ok := obj.Type().(*types.Signature); ok && sig.Recv() != nil {
					out = append(out, recvName(sig.Recv().Type())+"."+obj.Name())
				}
			}
		}
		if obj := info.Uses[f.Sel]; obj != nil {
			if pkg := obj.Pkg(); pkg != nil {
				out = append(out, pkg.Path()+"."+obj.Name())
			}
		}
		out = append(out, f.Sel.Name)
		return out
	}
	return nil
}

func recvName(t types.Type) string {
	switch x := t.(type) {
	case *types.Pointer:
		return "(*" + recvName(x.Elem())[1:]
	case *types.Named:
		if pkg := x.Obj().Pkg(); pkg != nil {
			return "(" + pkg.Path() + "." + x.Obj().Name() + ")"
		}
		return "(" + x.Obj().Name() + ")"
	default:
		return "(" + t.String() + ")"
	}
}

func splitName(name string) (string, string) {
	i := strings.LastIndex(name, ".")
	if i < 0 {
		return "", name
	}
	return name[:i], name[i+1:]
}
