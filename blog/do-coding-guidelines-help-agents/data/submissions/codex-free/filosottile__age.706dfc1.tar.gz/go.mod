module reimpl-age

go 1.21

require (
	golang.org/x/crypto v0.48.0
	golang.org/x/sys v0.41.0
)

replace golang.org/x/crypto => ./xcrypto

replace golang.org/x/sys => ./xsys
