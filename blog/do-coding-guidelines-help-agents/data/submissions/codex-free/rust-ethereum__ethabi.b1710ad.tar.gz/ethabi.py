#!/usr/bin/env python3
import argparse
import json
import re
import sys


VERSION = "18.0.0"


RC = [
    0x0000000000000001, 0x0000000000008082, 0x800000000000808A,
    0x8000000080008000, 0x000000000000808B, 0x0000000080000001,
    0x8000000080008081, 0x8000000000008009, 0x000000000000008A,
    0x0000000000000088, 0x0000000080008009, 0x000000008000000A,
    0x000000008000808B, 0x800000000000008B, 0x8000000000008089,
    0x8000000000008003, 0x8000000000008002, 0x8000000000000080,
    0x000000000000800A, 0x800000008000000A, 0x8000000080008081,
    0x8000000000008080, 0x0000000080000001, 0x8000000080008008,
]
R = [
    [0, 36, 3, 41, 18],
    [1, 44, 10, 45, 2],
    [62, 6, 43, 15, 61],
    [28, 55, 25, 21, 56],
    [27, 20, 39, 8, 14],
]


def rol(x, n):
    return ((x << n) | (x >> (64 - n))) & ((1 << 64) - 1)


def keccak_f(st):
    for rc in RC:
        c = [st[x] ^ st[x + 5] ^ st[x + 10] ^ st[x + 15] ^ st[x + 20] for x in range(5)]
        d = [c[(x - 1) % 5] ^ rol(c[(x + 1) % 5], 1) for x in range(5)]
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] ^= d[x]
        b = [0] * 25
        for x in range(5):
            for y in range(5):
                b[y + 5 * ((2 * x + 3 * y) % 5)] = rol(st[x + 5 * y], R[x][y])
        for x in range(5):
            for y in range(5):
                st[x + 5 * y] = b[x + 5 * y] ^ ((~b[((x + 1) % 5) + 5 * y]) & b[((x + 2) % 5) + 5 * y])
        st[0] ^= rc


def keccak256(data):
    rate = 136
    st = [0] * 25
    msg = bytearray(data)
    msg.append(0x01)
    while len(msg) % rate != rate - 1:
        msg.append(0)
    msg.append(0x80)
    for off in range(0, len(msg), rate):
        block = msg[off:off + rate]
        for i in range(rate // 8):
            st[i] ^= int.from_bytes(block[8 * i:8 * i + 8], "little")
        keccak_f(st)
    out = bytearray()
    while len(out) < 32:
        for i in range(rate // 8):
            out += st[i].to_bytes(8, "little")
        if len(out) < 32:
            keccak_f(st)
    return bytes(out[:32])


class AbiError(Exception):
    pass


def die(msg, code=1):
    print("Error: " + msg)
    sys.exit(code)


def strip0x(s):
    return s[2:] if isinstance(s, str) and s.startswith(("0x", "0X")) else s


def parse_hex(s, *, even=True):
    h = strip0x(s)
    if even and len(h) % 2:
        raise AbiError("Hex parsing error: Odd number of digits\n\nCaused by:\n    Odd number of digits")
    if h == "":
        return b""
    if not re.fullmatch(r"[0-9a-fA-F]+", h):
        raise AbiError("Invalid data")
    return bytes.fromhex(h)


def word(n):
    return int(n).to_bytes(32, "big", signed=False)


def zpad32(b):
    return b + b"\x00" * ((32 - len(b) % 32) % 32)


def split_array_value(s):
    if not (s.startswith("[") and s.endswith("]")):
        raise AbiError("Invalid data")
    inner = s[1:-1]
    if inner == "":
        return []
    out, cur, depth = [], [], 0
    for ch in inner:
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        if ch == "," and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(ch)
    out.append("".join(cur).strip())
    return out


class Typ:
    def __init__(self, base, sub=None, arr=None):
        self.base, self.sub, self.arr = base, sub, arr

    @staticmethod
    def parse(s):
        m = re.match(r"^(.*)\[([0-9]*)\]$", s)
        if m:
            n = None if m.group(2) == "" else int(m.group(2))
            return Typ("array", Typ.parse(m.group(1)), n)
        return Typ(s)

    def canonical(self):
        if self.base == "array":
            return self.sub.canonical() + "[" + ("" if self.arr is None else str(self.arr)) + "]"
        return self.base

    def is_dynamic(self):
        if self.base in ("string", "bytes"):
            return True
        if self.base == "array":
            return self.arr is None or self.sub.is_dynamic()
        return False

    def static_words(self):
        if self.is_dynamic():
            return 1
        if self.base == "array":
            return self.arr * self.sub.static_words()
        return 1


def parse_uint_value(s, bits, lenient):
    if lenient:
        n = int(s, 10)
    else:
        raw = parse_hex(s)
        if len(raw) > 32:
            raise AbiError("Invalid data")
        n = int.from_bytes(raw, "big")
    if n < 0 or n >= 1 << bits:
        raise AbiError("Invalid data")
    return n


def encode_primitive(t, v, lenient):
    base = t.base
    if base == "bool":
        if str(v).lower() in ("true", "1"):
            return word(1)
        if str(v).lower() in ("false", "0"):
            return word(0)
        raise AbiError("Invalid data")
    m = re.fullmatch(r"uint([0-9]*)", base)
    if m:
        bits = int(m.group(1) or "256")
        return word(parse_uint_value(v, bits, lenient))
    m = re.fullmatch(r"int([0-9]*)", base)
    if m:
        bits = int(m.group(1) or "256")
        if lenient:
            n = int(v, 10)
        else:
            raw = parse_hex(v)
            if len(raw) > 32:
                raise AbiError("Invalid data")
            n = int.from_bytes(raw, "big")
        if n < 0:
            n = (1 << 256) + n
        return word(n)
    if base == "address":
        raw = parse_hex(v)
        if len(raw) != 20:
            raise AbiError("Invalid data")
        return b"\x00" * 12 + raw
    m = re.fullmatch(r"bytes([0-9]+)", base)
    if m:
        size = int(m.group(1))
        raw = parse_hex(v, even=False)
        if len(raw) != size:
            raise AbiError("Invalid data")
        return raw + b"\x00" * (32 - size)
    raise AbiError("Invalid data")


def encode_value(t, v, lenient=False):
    if t.base == "string":
        raw = v.encode()
        return word(len(raw)) + zpad32(raw)
    if t.base == "bytes":
        raw = parse_hex(v, even=False)
        return word(len(raw)) + zpad32(raw)
    if t.base == "array":
        vals = split_array_value(v)
        if t.arr is not None and len(vals) != t.arr:
            raise AbiError("Invalid data")
        return encode_array(t, vals, lenient)
    return encode_primitive(t, v, lenient)


def encode_array(t, vals, lenient):
    elems = [encode_value(t.sub, v, lenient) for v in vals]
    if t.sub.is_dynamic():
        head_size = 32 * len(vals)
        head, tail, off = b"", b"", head_size
        for enc in elems:
            head += word(off)
            tail += enc
            off += len(enc)
        body = head + tail
    else:
        body = b"".join(elems)
    if t.arr is None:
        return word(len(vals)) + body
    return body


def encode_params(types, vals, lenient=False):
    if len(types) != len(vals):
        raise AbiError("Invalid data")
    ts = [Typ.parse(x) for x in types]
    encs = [encode_value(t, v, lenient) for t, v in zip(ts, vals)]
    head_size = 32 * sum(t.static_words() for t in ts)
    head, tail, off = b"", b"", head_size
    for t, enc in zip(ts, encs):
        if t.is_dynamic():
            head += word(off)
            tail += enc
            off += len(enc)
        else:
            head += enc
    return (head + tail).hex()


def read_word(data, off):
    if off < 0 or off + 32 > len(data):
        raise AbiError("Invalid data")
    return data[off:off + 32]


def decode_value(t, data, off, base=0):
    if t.base == "string":
        start = base + int.from_bytes(read_word(data, off), "big")
        ln = int.from_bytes(read_word(data, start), "big")
        raw = data[start + 32:start + 32 + ln]
        return raw.decode(errors="replace")
    if t.base == "bytes":
        start = base + int.from_bytes(read_word(data, off), "big")
        ln = int.from_bytes(read_word(data, start), "big")
        return data[start + 32:start + 32 + ln].hex()
    if t.base == "array":
        if t.arr is None:
            start = base + int.from_bytes(read_word(data, off), "big")
            ln = int.from_bytes(read_word(data, start), "big")
            return decode_array(t.sub, ln, data, start + 32, start + 32)
        return decode_array(t.sub, t.arr, data, off, off)
    w = read_word(data, off)
    base = t.base
    if base == "bool":
        return "true" if int.from_bytes(w, "big") != 0 else "false"
    if re.fullmatch(r"uint([0-9]*)", base):
        return format(int.from_bytes(w, "big"), "x")
    if re.fullmatch(r"int([0-9]*)", base):
        n = int.from_bytes(w, "big")
        if n >= 1 << 255:
            n -= 1 << 256
        return format(n, "x") if n >= 0 else str(n)
    if base == "address":
        return w[-20:].hex()
    m = re.fullmatch(r"bytes([0-9]+)", base)
    if m:
        return w[:int(m.group(1))].hex()
    raise AbiError("Invalid data")


def decode_array(sub, ln, data, off, base):
    vals = []
    step = 32 * sub.static_words()
    for i in range(ln):
        vals.append(decode_value(sub, data, off + i * step, base))
    return "[" + ",".join(vals) + "]"


def decode_params(types, data_hex):
    data = parse_hex(data_hex)
    ts = [Typ.parse(x) for x in types]
    outs, off = [], 0
    for t in ts:
        outs.append((t.canonical(), decode_value(t, data, off)))
        off += 32 * t.static_words()
    return outs


def load_abi(path):
    with open(path) as f:
        return json.load(f)


def sig(item):
    return item.get("name", "") + "(" + ",".join(x["type"] for x in item.get("inputs", [])) + ")"


def event_sig(item):
    return item.get("name", "") + "(" + ",".join(x["type"] for x in item.get("inputs", [])) + ")"


def choose(items, kind, name):
    cand = [x for x in items if x.get("type") == kind]
    if "(" in name or ")" in name:
        # The original 18.0.0 CLI only accepts bare names in practice in this build.
        raise AbiError(f"invalid {kind} signature `{name}`")
    cand = [x for x in cand if x.get("name", "") == name]
    if not cand:
        raise AbiError(f"{kind} `{name}` not found")
    if len(cand) > 1:
        raise AbiError(f"More than one {kind} found for name `{name}`, try providing the full signature")
    return cand[0]


def make_parser():
    p = argparse.ArgumentParser(prog="executable", description="Ethereum ABI coder", add_help=False)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("args", nargs="*")
    return p


def print_help(args):
    if not args:
        print(f"ethabi-cli {VERSION}\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    decode    Decode ABI call result\n    encode    Encode ABI call\n    help      Prints this message or the help of the given subcommand(s)")
    elif args == ["encode"]:
        print(f"executable-encode {VERSION}\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    help        Prints this message or the help of the given subcommand(s)\n    params      Specify types of input params inline")
    elif args == ["decode"]:
        print(f"executable-decode {VERSION}\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    help        Prints this message or the help of the given subcommand(s)\n    log         Decode event log\n    params      Specify types of input params inline")
    elif args == ["encode", "params"]:
        print(f"executable-encode-params {VERSION}\nSpecify types of input params inline\n\nUSAGE:\n    executable encode params [FLAGS] [OPTIONS]\n\nFLAGS:\n    -h, --help       \n            Prints help information\n\n    -l, --lenient    \n            Allow short representation of input params (numbers are in decimal form)\n\n    -V, --version    \n            Prints version information\n\n\nOPTIONS:\n    -v <type-or-param> <type-or-param>        \n            Pairs of types directly followed by params in the form:\n            \n            -v <type1> <param1> -v <type2> <param2> ...")
    elif args == ["encode", "function"]:
        print(f"executable-encode-function {VERSION}\nLoad function from JSON ABI file\n\nUSAGE:\n    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>\n\nFLAGS:\n    -h, --help       Prints help information\n    -l, --lenient    Allow short representation of input params\n    -V, --version    Prints version information\n\nOPTIONS:\n    -p <params>...        \n\nARGS:\n    <abi-path>                      \n    <function-name-or-signature>    ")
    elif args == ["decode", "params"]:
        print(f"executable-decode-params {VERSION}\nSpecify types of input params inline\n\nUSAGE:\n    executable decode params [OPTIONS] <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -t <type>...        \n\nARGS:\n    <data>    ")
    elif args == ["decode", "function"]:
        print(f"executable-decode-function {VERSION}\nLoad function from JSON ABI file\n\nUSAGE:\n    executable decode function <abi-path> <function-name-or-signature> <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <abi-path>                      \n    <function-name-or-signature>    \n    <data>                          ")
    elif args == ["decode", "log"]:
        print(f"executable-decode-log {VERSION}\nDecode event log\n\nUSAGE:\n    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -l <topic>...        \n\nARGS:\n    <abi-path>                   \n    <event-name-or-signature>    \n    <data>                       ")
    else:
        print("ethabi-cli 18.0.0")


def parse_opts(argv, opt_names):
    flags, opts, pos = set(), {k: [] for k in opt_names}, []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            flags.add("help"); i += 1
        elif a in ("-V", "--version"):
            flags.add("version"); i += 1
        elif a in ("-l", "--lenient") and "lenient" in opt_names:
            flags.add("lenient"); i += 1
        elif a in ("-v", "-p", "-t", "-l") and a in opt_names:
            cnt = 2 if a == "-v" else 1
            if i + cnt >= len(argv) + 1:
                raise AbiError("Invalid data")
            opts[a].append(argv[i + 1:i + 1 + cnt])
            i += 1 + cnt
        else:
            pos.append(a); i += 1
    return flags, opts, pos


def main():
    argv = sys.argv[1:]
    try:
        if not argv or argv[0] in ("-h", "--help", "help"):
            print_help([]); return
        if argv[0] in ("-V", "--version"):
            print(f"ethabi-cli {VERSION}"); return
        if len(argv) >= 3 and argv[2] in ("-h", "--help", "help"):
            print_help([argv[0], argv[1]]); return
        if len(argv) >= 3 and argv[2] in ("-V", "--version"):
            print(f"executable-{argv[0]}-{argv[1]} {VERSION}"); return
        if len(argv) >= 2 and argv[1] in ("-h", "--help", "help"):
            print_help([argv[0]]); return
        if len(argv) >= 2 and argv[1] in ("-V", "--version"):
            print(f"executable-{argv[0]} {VERSION}"); return
        if argv[0] == "encode" and len(argv) >= 2:
            sub, rest = argv[1], argv[2:]
            if sub == "params":
                if any(x in rest for x in ("-h", "--help")):
                    print(f"executable-encode-params {VERSION}\nSpecify types of input params inline\n\nUSAGE:\n    executable encode params [FLAGS] [OPTIONS]")
                    return
                flags, opts, pos = parse_opts(rest, {"-v": [], "lenient": []})
                pairs = opts["-v"]
                print(encode_params([p[0] for p in pairs], [p[1] for p in pairs], "lenient" in flags))
                return
            if sub == "function":
                flags, opts, pos = parse_opts(rest, {"-p": [], "lenient": []})
                if len(pos) != 2:
                    raise AbiError("Invalid data")
                fn = choose(load_abi(pos[0]), "function", pos[1])
                types = [x["type"] for x in fn.get("inputs", [])]
                vals = [x[0] for x in opts["-p"]]
                selector = keccak256(sig(fn).encode())[:4].hex()
                print(selector + encode_params(types, vals, "lenient" in flags))
                return
        if argv[0] == "decode" and len(argv) >= 2:
            sub, rest = argv[1], argv[2:]
            if sub == "params":
                flags, opts, pos = parse_opts(rest, {"-t": []})
                if len(pos) != 1:
                    raise AbiError("Invalid data")
                for typ, val in decode_params([x[0] for x in opts["-t"]], pos[0]):
                    print(typ, val)
                return
            if sub == "function":
                if len(rest) != 3:
                    raise AbiError("Invalid data")
                fn = choose(load_abi(rest[0]), "function", rest[1])
                for typ, val in decode_params([x["type"] for x in fn.get("outputs", [])], rest[2]):
                    print(typ, val)
                return
            if sub == "log":
                flags, opts, pos = parse_opts(rest, {"-l": []})
                if len(pos) != 3:
                    raise AbiError("Invalid data")
                ev = choose(load_abi(pos[0]), "event", pos[1])
                topics = [x[0] for x in opts["-l"]]
                if not ev.get("anonymous", False) and topics:
                    topics = topics[1:]
                indexed = [x for x in ev.get("inputs", []) if x.get("indexed")]
                non = [x for x in ev.get("inputs", []) if not x.get("indexed")]
                data_vals = decode_params([x["type"] for x in non], pos[2])
                out = []
                di = ti = 0
                for inp in ev.get("inputs", []):
                    if inp.get("indexed"):
                        val = decode_params([inp["type"]], topics[ti])[0][1]; ti += 1
                    else:
                        val = data_vals[di][1]; di += 1
                    out.append((inp.get("name", ""), val))
                for name, val in out:
                    print(name, val)
                return
        raise AbiError("Invalid data")
    except AbiError as e:
        die(str(e))
    except Exception as e:
        die(str(e))


if __name__ == "__main__":
    main()
