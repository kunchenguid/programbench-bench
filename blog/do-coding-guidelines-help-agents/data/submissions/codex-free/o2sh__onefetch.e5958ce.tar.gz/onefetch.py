#!/usr/bin/env python3
import argparse
import json
import os
import re
import subprocess
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone

VERSION = "onefetch 2.25.0"

LANGUAGES = [
    "ABNF","ABAP","Ada","Agda","Arduino C++","Assembly","ATS","AutoHotKey","BASH","C","CMake","C#",
    "Ceylon","Clojure","CoffeeScript","ColdFusion","Coq","C++","Crystal","CSS","CUDA","D","Dart",
    "Dockerfile","Emacs Lisp","Elixir","Elm","Emojicode","Erlang","F#","Fish","Forth","FORTRAN Legacy",
    "FORTRAN Modern","GDScript","GLSL","Go","GraphQL","Groovy","Haskell","Haxe","HCL","HLSL","HolyC",
    "HTML","Idris","Java","JavaScript","JSON","Jsonnet","JSX","Julia","Jupyter Notebooks","Kotlin",
    "LLVM","Lean","Common Lisp","Lua","Makefile","Markdown","Modelica","Nim","Nix","OCaml","Objective-C",
    "Odin","OpenSCAD","Org","Oz","Pascal","Perl","PHP","PowerShell","Processing","Prolog",
    "Protocol Buffers","PureScript","Python","QML","R","Racket","Raku","Razor","Ren'Py","Ruby","Rust",
    "Sass","Scala","Scheme","Shell","Solidity","SQL","Svelte","SVG","Swift","SystemVerilog","TCL","TeX",
    "Plain Text","TOML","TSX","TypeScript","Typst","Vala","Verilog","VHDL","Vim Script","Visual Basic",
    "Vue","WebAssembly","Wolfram","XSL","XAML","XML","YAML","Zig","Zsh",
]

PACKAGE_MANAGERS = ["Npm", "Cargo"]

EXT_LANG = {
    ".py": ("Python", "programming"), ".rs": ("Rust", "programming"), ".c": ("C", "programming"),
    ".h": ("C", "programming"), ".cpp": ("C++", "programming"), ".cc": ("C++", "programming"),
    ".hpp": ("C++", "programming"), ".go": ("Go", "programming"), ".java": ("Java", "programming"),
    ".js": ("JavaScript", "programming"), ".jsx": ("JSX", "programming"), ".ts": ("TypeScript", "programming"),
    ".tsx": ("TSX", "programming"), ".rb": ("Ruby", "programming"), ".php": ("PHP", "programming"),
    ".sh": ("Shell", "programming"), ".bash": ("BASH", "programming"), ".zsh": ("Zsh", "programming"),
    ".fish": ("Fish", "programming"), ".pl": ("Perl", "programming"), ".pm": ("Perl", "programming"),
    ".r": ("R", "programming"), ".R": ("R", "programming"), ".kt": ("Kotlin", "programming"),
    ".swift": ("Swift", "programming"), ".scala": ("Scala", "programming"), ".cs": ("C#", "programming"),
    ".dart": ("Dart", "programming"), ".lua": ("Lua", "programming"), ".hs": ("Haskell", "programming"),
    ".ex": ("Elixir", "programming"), ".exs": ("Elixir", "programming"), ".erl": ("Erlang", "programming"),
    ".fs": ("F#", "programming"), ".clj": ("Clojure", "programming"), ".zig": ("Zig", "programming"),
    ".html": ("HTML", "markup"), ".htm": ("HTML", "markup"), ".css": ("CSS", "markup"),
    ".scss": ("Sass", "markup"), ".sass": ("Sass", "markup"), ".xml": ("XML", "markup"),
    ".svg": ("SVG", "markup"), ".md": ("Markdown", "prose"), ".markdown": ("Markdown", "prose"),
    ".rst": ("Plain Text", "prose"), ".txt": ("Plain Text", "prose"), ".json": ("JSON", "data"),
    ".yaml": ("YAML", "data"), ".yml": ("YAML", "data"), ".toml": ("TOML", "data"), ".sql": ("SQL", "data"),
}

FIELD_MAP = {
    "project": "ProjectInfo", "description": "DescriptionInfo", "head": "HeadInfo", "pending": "PendingInfo",
    "version": "VersionInfo", "created": "CreatedInfo", "languages": "LanguagesInfo",
    "dependencies": "DependenciesInfo", "authors": "AuthorsInfo", "last-change": "LastChangeInfo",
    "contributors": "ContributorsInfo", "url": "UrlInfo", "commits": "CommitsInfo", "churn": "ChurnInfo",
    "lines-of-code": "LocInfo", "size": "SizeInfo", "license": "LicenseInfo",
}

def run(cmd, cwd, check=False):
    try:
        p = subprocess.run(cmd, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=check)
        return p.stdout.strip()
    except Exception:
        return ""

def git(cwd, *args):
    return run(["git", *args], cwd)

def in_git(cwd):
    return git(cwd, "rev-parse", "--is-inside-work-tree") == "true"

def repo_root(cwd):
    return git(cwd, "rev-parse", "--show-toplevel") or cwd

def short_time(epoch, iso=False):
    if not epoch:
        return ""
    try:
        dt = datetime.fromtimestamp(int(epoch), timezone.utc)
    except Exception:
        return ""
    if iso:
        return dt.isoformat().replace("+00:00", "Z")
    now = datetime.now(timezone.utc)
    sec = max(0, int((now - dt).total_seconds()))
    units = [(365*86400, "year"), (30*86400, "month"), (7*86400, "week"), (86400, "day"), (3600, "hour"), (60, "minute")]
    for size, name in units:
        if sec >= size:
            n = sec // size
            return f"{n} {name}{'' if n == 1 else 's'} ago"
    return "now"

def format_num(n, sep):
    s = str(n)
    if sep == "comma":
        return f"{n:,}"
    if sep == "underscore":
        return f"{n:_}"
    if sep == "space":
        return f"{n:,}".replace(",", " ")
    return s

def human_size(n):
    if n < 1024:
        return f"{n} B"
    val = n / 1024.0
    if val < 1024:
        return f"{val:.2f} KiB"
    return f"{val/1024.0:.2f} MiB"

def lang_for(path):
    name = os.path.basename(path)
    if name == "Dockerfile":
        return ("Dockerfile", "programming")
    if name in ("Makefile", "makefile", "GNUmakefile"):
        return ("Makefile", "programming")
    return EXT_LANG.get(os.path.splitext(name)[1], (None, None))

def list_files(root, include_hidden=False, excludes=None):
    excludes = excludes or []
    out = []
    for base, dirs, files in os.walk(root):
        relbase = os.path.relpath(base, root)
        parts = [] if relbase == "." else relbase.split(os.sep)
        dirs[:] = [d for d in dirs if d != ".git" and (include_hidden or not d.startswith("."))]
        dirs[:] = [d for d in dirs if not any(re.fullmatch(pat.replace("*", ".*"), d) for pat in excludes)]
        for f in files:
            if not include_hidden and f.startswith("."):
                continue
            rel = f if relbase == "." else os.path.join(relbase, f)
            if any(re.fullmatch(pat.replace("*", ".*"), rel) or pat in rel for pat in excludes):
                continue
            out.append(rel)
    return sorted(out)

def file_stats(root, args):
    total_size = 0
    file_count = 0
    loc_by_lang = Counter()
    total_loc = 0
    wanted = set(args.types or ["programming", "markup"])
    for rel in list_files(root, args.include_hidden, args.exclude):
        path = os.path.join(root, rel)
        try:
            st = os.stat(path)
            if not os.path.isfile(path):
                continue
            data = open(path, "rb").read()
        except Exception:
            continue
        total_size += st.st_size
        file_count += 1
        lang, typ = lang_for(rel)
        if not lang or typ not in wanted:
            continue
        try:
            text = data.decode("utf-8", "ignore")
        except Exception:
            continue
        loc = sum(1 for line in text.splitlines() if is_code_line(line, lang))
        if loc:
            loc_by_lang[lang] += loc
            total_loc += loc
    return total_size, file_count, loc_by_lang, total_loc

def is_code_line(line, lang):
    s = line.strip()
    if not s:
        return False
    comment_prefixes = {
        "Python": ("#",), "Ruby": ("#",), "Shell": ("#",), "BASH": ("#",), "Zsh": ("#",),
        "Rust": ("//",), "C": ("//", "/*", "*", "*/"), "C++": ("//", "/*", "*", "*/"),
        "Java": ("//", "/*", "*", "*/"), "JavaScript": ("//", "/*", "*", "*/"),
        "TypeScript": ("//", "/*", "*", "*/"), "Go": ("//", "/*", "*", "*/"),
        "CSS": ("/*", "*", "*/"), "HTML": ("<!--",), "XML": ("<!--",), "Markdown": ("<!--",),
    }
    return not s.startswith(comment_prefixes.get(lang, ()))

def status_counts(root):
    added = deleted = modified = 0
    for line in git(root, "status", "--porcelain").splitlines():
        if not line:
            continue
        x, y = line[0], line[1] if len(line) > 1 else " "
        if line.startswith("??"):
            added += 1
        elif "D" in (x, y):
            deleted += 1
        elif "A" in (x, y):
            added += 1
        elif x != " " or y != " ":
            modified += 1
    return added, deleted, modified

def authors(root, show_email=False, no_bots=None, no_merges=False):
    fmt = "%an%x00%ae"
    cmd = ["log", "--reverse", f"--format={fmt}"]
    if no_merges:
        cmd.insert(1, "--no-merges")
    counts = Counter()
    email_for = {}
    pattern = re.compile(no_bots or r"\[bot\]|bot@", re.I) if no_bots is not None else None
    for line in git(root, *cmd).splitlines():
        if "\x00" in line:
            name, email = line.split("\x00", 1)
        else:
            name, email = line, ""
        if pattern and (pattern.search(name) or pattern.search(email)):
            continue
        counts[name] += 1
        email_for[name] = email
    total = sum(counts.values()) or 1
    items = []
    for name, n in counts.most_common():
        items.append({"name": name, "email": email_for.get(name) if show_email else None,
                      "nbrOfCommits": n, "contribution": round(n * 100 / total)})
    return items

def churn(root, n=3, pool=None):
    revs = pool or 1
    out = git(root, "log", f"-n{revs}", "--name-only", "--pretty=format:")
    c = Counter(line.strip() for line in out.splitlines() if line.strip())
    return [{"filePath": p, "nbrOfCommits": v} for p, v in c.most_common(n)], revs

def license_name(root):
    for name in ("LICENSE", "LICENSE.md", "COPYING"):
        p = os.path.join(root, name)
        if os.path.exists(p):
            txt = open(p, "r", errors="ignore").read(3000).lower()
            if "permission is hereby granted" in txt:
                return "MIT"
            if "apache license" in txt:
                return "Apache-2.0"
            if "gnu general public license" in txt:
                return "GPL"
            return ""
    return ""

def repo_url(root, http=False, hide_token=False):
    url = git(root, "config", "--get", "remote.origin.url")
    if http and url.startswith("git@") and ":" in url:
        host = url.split("@", 1)[1].split(":", 1)[0]
        path = url.split(":", 1)[1]
        url = f"https://{host}/{path}"
    if hide_token:
        url = re.sub(r"(https?://)[^/@]+@", r"\1", url)
    return url

def dependencies(root):
    vals = []
    if os.path.exists(os.path.join(root, "package.json")):
        vals.append("Npm")
    if os.path.exists(os.path.join(root, "Cargo.toml")):
        vals.append("Cargo")
    return ", ".join(vals)

def build_info(root, args):
    gitver = run(["git", "--version"], root)
    username = git(root, "config", "--get", "user.name")
    head = git(root, "rev-parse", "--short", "HEAD")
    branch = git(root, "branch", "--show-current") or "HEAD"
    first = git(root, "log", "--reverse", "--format=%ct", "-1")
    last = git(root, "log", "--format=%ct", "-1")
    commits = int(git(root, "rev-list", "--count", "HEAD") or "0")
    added, deleted, modified = status_counts(root)
    total_size, file_count, loc_by_lang, total_loc = file_stats(root, args)
    total_lang = sum(loc_by_lang.values())
    langs = [{"language": k, "percentage": v * 100.0 / total_lang} for k, v in loc_by_lang.most_common(args.number_of_languages) if total_lang]
    auths = authors(root, args.email, args.no_bots, args.no_merges)[:args.number_of_authors]
    ch, pool = churn(root, args.number_of_file_churns, args.churn_pool_size)
    fields = [
        {"ProjectInfo": {"repoName": "", "numberOfBranches": 0, "numberOfTags": 0}},
        {"DescriptionInfo": {"description": None}},
        {"HeadInfo": {"headRefs": {"shortCommitId": head, "refs": [branch] if branch else []}}},
        {"PendingInfo": {"added": added, "deleted": deleted, "modified": modified}},
        {"VersionInfo": {"version": ""}},
        {"CreatedInfo": {"creationDate": short_time(first, args.iso_time)}},
    ]
    if langs:
        fields.append({"LanguagesInfo": {"languagesWithPercentage": langs}})
    fields.extend([
        {"DependenciesInfo": {"dependencies": dependencies(root)}},
        {"AuthorsInfo": {"authors": auths}},
        {"LastChangeInfo": {"lastChange": short_time(last, args.iso_time)}},
        {"ContributorsInfo": {"totalNumberOfAuthors": len(authors(root, args.email, args.no_bots, args.no_merges))}},
        {"UrlInfo": {"repoUrl": repo_url(root, args.http_url, args.hide_token)}},
        {"CommitsInfo": {"numberOfCommits": commits, "isShallow": git(root, "rev-parse", "--is-shallow-repository") == "true"}},
        {"ChurnInfo": {"file_churns": ch, "churn_pool_size": pool}},
    ])
    if total_loc:
        fields.append({"LocInfo": {"linesOfCode": total_loc}})
    fields.extend([
        {"SizeInfo": {"repoSize": human_size(total_size), "fileCount": file_count}},
        {"LicenseInfo": {"license": license_name(root)}},
    ])
    disabled = set(args.disabled_fields or [])
    fields = [f for f in fields if next(iter(f.keys())) not in {FIELD_MAP.get(x, x) for x in disabled}]
    return {"title": {"gitUsername": username, "gitVersion": gitver}, "infoFields": fields}

def field_name(obj):
    return next(iter(obj.keys()))

def print_text(info, args):
    title = info["title"]
    if not args.no_art:
        art = args.ascii_input or ""
        if art:
            for line in art.splitlines():
                print(line)
    if not args.no_title:
        left = title["gitUsername"]
        if left:
            print(f"{left} ~ {title['gitVersion']}")
            print("-" * (len(left) + len(title["gitVersion"]) + 3))
        else:
            print(title["gitVersion"])
            print("-" * len(title["gitVersion"]))
    for f in info["infoFields"]:
        name = field_name(f); val = f[name]
        if name == "HeadInfo":
            refs = val["headRefs"]["refs"]
            suffix = f" ({', '.join(refs)})" if refs else ""
            print(f"HEAD: {val['headRefs']['shortCommitId']}{suffix}")
        elif name == "PendingInfo":
            bits = []
            if val["added"]: bits.append(f"{val['added']}+")
            if val["deleted"]: bits.append(f"{val['deleted']}-")
            if val["modified"]: bits.append(f"{val['modified']}~")
            if bits: print(f"Pending: {' '.join(bits)}")
        elif name == "CreatedInfo":
            print(f"Created: {val['creationDate']}")
        elif name == "LanguagesInfo":
            parts = [f"{x['language']} ({x['percentage']:.1f} %)" for x in val["languagesWithPercentage"]]
            print("Languages: " + " ".join(parts))
        elif name == "DependenciesInfo" and val["dependencies"]:
            print(f"Dependencies: {val['dependencies']}")
        elif name == "AuthorsInfo" and val["authors"]:
            label = "Author" if len(val["authors"]) == 1 else "Authors"
            for i, a in enumerate(val["authors"]):
                who = a["name"] + (f" <{a['email']}>" if a.get("email") else "")
                prefix = f"{label}: " if i == 0 else " " * (len(label) + 2)
                print(f"{prefix}{a['contribution']}% {who} {a['nbrOfCommits']}")
        elif name == "LastChangeInfo":
            print(f"Last change: {val['lastChange']}")
        elif name == "UrlInfo" and val["repoUrl"]:
            print(f"URL: {val['repoUrl']}")
        elif name == "CommitsInfo":
            print(f"Commits: {format_num(val['numberOfCommits'], args.number_separator)}")
        elif name == "ChurnInfo" and val["file_churns"]:
            for i, c in enumerate(val["file_churns"]):
                prefix = f"Churn ({val['churn_pool_size']}): " if i == 0 else " " * (len(f"Churn ({val['churn_pool_size']}): "))
                print(f"{prefix}{c['filePath']} {c['nbrOfCommits']}")
        elif name == "LocInfo":
            print(f"Lines of code: {format_num(val['linesOfCode'], args.number_separator)}")
        elif name == "SizeInfo":
            print(f"Size: {val['repoSize']} ({val['fileCount']} files)")
        elif name == "LicenseInfo" and val["license"]:
            print(f"License: {val['license']}")

def dump_yaml(obj):
    def emit(v, indent=0):
        sp = "  " * indent
        if isinstance(v, dict):
            lines = []
            for k, val in v.items():
                if isinstance(val, dict):
                    lines.append(f"{sp}{k}:")
                    lines.extend(emit(val, indent + 1))
                elif isinstance(val, list):
                    lines.append(f"{sp}{k}:")
                    lines.extend(emit(val, indent))
                else:
                    lines.append(f"{sp}{k}: {scalar(val)}")
            return lines
        if isinstance(v, list):
            lines = []
            for item in v:
                if isinstance(item, dict):
                    first = True
                    for k, val in item.items():
                        if first:
                            if isinstance(val, (dict, list)):
                                lines.append(f"{sp}- {k}:")
                                lines.extend(emit(val, indent + 2))
                            else:
                                lines.append(f"{sp}- {k}: {scalar(val)}")
                            first = False
                        else:
                            if isinstance(val, (dict, list)):
                                lines.append(f"{sp}  {k}:")
                                lines.extend(emit(val, indent + 2))
                            else:
                                lines.append(f"{sp}  {k}: {scalar(val)}")
                else:
                    lines.append(f"{sp}- {scalar(item)}")
            return lines
        return [f"{sp}{scalar(v)}"]
    def scalar(x):
        if x is None: return "null"
        if x is True: return "true"
        if x is False: return "false"
        if x == "": return "''"
        return str(x)
    print("\n".join(emit(obj)))

def parse(argv):
    if "--help" in argv:
        print("""Command-line Git information tool

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Run as if onefetch was started in <input> instead of the current working directory

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version
""")
        sys.exit(0)
    if "-h" in argv:
        print("Command-line Git information tool\n\nUsage: executable [OPTIONS] [INPUT]\n\nOptions:\n  -h, --help     Print help (see more with '--help')\n  -V, --version  Print version")
        sys.exit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION); sys.exit(0)
    if "--languages" in argv or "-l" in argv:
        print("\n".join(LANGUAGES)); sys.exit(0)
    if "--package-managers" in argv or "-p" in argv:
        print("\n".join(PACKAGE_MANAGERS)); sys.exit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("input", nargs="?", default=".")
    p.add_argument("-d", "--disabled-fields", nargs="+", default=[])
    p.add_argument("--no-title", action="store_true")
    p.add_argument("--number-of-authors", type=int, default=3)
    p.add_argument("--number-of-languages", type=int, default=6)
    p.add_argument("--number-of-file-churns", type=int, default=3)
    p.add_argument("--churn-pool-size", type=int)
    p.add_argument("-e", "--exclude", nargs="+", default=[])
    p.add_argument("--no-bots", nargs="?", const=r"\[bot\]|bot@", default=None)
    p.add_argument("--no-merges", action="store_true")
    p.add_argument("-E", "--email", action="store_true")
    p.add_argument("--http-url", action="store_true")
    p.add_argument("--hide-token", action="store_true")
    p.add_argument("--include-hidden", action="store_true")
    p.add_argument("-T", "--type", dest="types", nargs="+", choices=["programming", "markup", "prose", "data"], default=["programming", "markup"])
    p.add_argument("-z", "--iso-time", action="store_true")
    p.add_argument("--number-separator", choices=["plain", "comma", "space", "underscore"], default="plain")
    p.add_argument("--no-bold", action="store_true")
    p.add_argument("--ascii-input")
    p.add_argument("--ascii-colors", "-c", nargs="+")
    p.add_argument("--ascii-language", "-a")
    p.add_argument("--true-color", choices=["auto", "never", "always"], default="auto")
    p.add_argument("--image", "-i")
    p.add_argument("--image-protocol")
    p.add_argument("--color-resolution", default="64")
    p.add_argument("--no-color-palette", action="store_true")
    p.add_argument("--no-art", action="store_true")
    p.add_argument("--nerd-fonts", action="store_true")
    p.add_argument("-o", "--output", choices=["json", "yaml"])
    p.add_argument("--generate", choices=["bash", "elvish", "fish", "powershell", "zsh"])
    ns, unknown = p.parse_known_args(argv)
    if unknown:
        print(f"error: unexpected argument '{unknown[0]}' found", file=sys.stderr)
        sys.exit(2)
    return ns

def main():
    args = parse(sys.argv[1:])
    if args.generate:
        print(f"# completion for {args.generate}")
        return
    path = os.path.abspath(args.input)
    if not os.path.isdir(path):
        print(f"Error: Failed to access a directory, or path is not a directory: '{args.input}'", file=sys.stderr)
        sys.exit(1)
    if not in_git(path):
        print("Error: Not a git repository", file=sys.stderr)
        sys.exit(1)
    root = repo_root(path)
    info = build_info(root, args)
    if args.output == "json":
        print(json.dumps(info, indent=2))
    elif args.output == "yaml":
        dump_yaml(info)
    else:
        print_text(info, args)

if __name__ == "__main__":
    main()
