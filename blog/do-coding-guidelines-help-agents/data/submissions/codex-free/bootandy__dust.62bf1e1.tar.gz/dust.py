#!/usr/bin/env python3
import argparse
import json
import os
import re
import stat
import sys
import time
from dataclasses import dataclass, field


VERSION = "Dust 1.2.3"

HELP_LONG = """Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...
          Input files or directories

Options:
  -d, --depth <DEPTH>
          Depth to show

  -T, --threads <THREADS>
          Number of threads to use

      --config <FILE>
          Specify a config file to use

  -n, --number-of-lines <NUMBER>
          Number of lines of output to show. (Default is terminal_height - 10)

  -p, --full-paths
          Subdirectories will not have their path shortened

  -X, --ignore-directory <PATH>
          Exclude any file or directory with this path

  -I, --ignore-all-in-file <FILE>
          Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter

  -L, --dereference-links
          dereference sym links - Treat sym links as directories and go into them

  -x, --limit-filesystem
          Only count the files and directories on the same filesystem as the supplied directory

  -s, --apparent-size
          Use file length instead of blocks

  -r, --reverse
          Print tree upside down (biggest highest)

  -c, --no-colors
          No colors will be printed (Useful for commands like: watch)

  -C, --force-colors
          Force colors print

  -b, --no-percent-bars
          No percent bars or percentages will be displayed

  -B, --bars-on-right
          percent bars moved to right side of screen

  -z, --min-size <MIN_SIZE>
          Minimum size file to include in output

  -R, --screen-reader
          For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)

      --skip-total
          No total row will be displayed

  -f, --filecount
          Directory 'size' is number of child files instead of disk size

  -i, --ignore-hidden
          Do not display hidden files

  -v, --invert-filter <REGEX>
          Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"

  -e, --filter <REGEX>
          Only include filepaths matching this regex. For png files type: -e "\\.png$"

  -t, --file-types
          show only these file types

  -w, --terminal-width <WIDTH>
          Specify width of output overriding the auto detection of terminal width

  -P, --no-progress
          Disable the progress indication

      --print-errors
          Print path with errors

  -D, --only-dir
          Only directories will be displayed

  -F, --only-file
          Only files will be displayed. (Finds your largest files)

  -o, --output-format <FORMAT>
          Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size

          Possible values:
          - si: SI prefix (powers of 1000)
          - b:  byte (B)
          - k:  kibibyte (KiB)
          - m:  mebibyte (MiB)
          - g:  gibibyte (GiB)
          - t:  tebibyte (TiB)
          - kb: kilobyte (kB)
          - mb: megabyte (MB)
          - gb: gigabyte (GB)
          - tb: terabyte (TB)

  -S, --stack-size <STACK_SIZE>
          Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)

  -j, --output-json
          Output the directory tree as json to the current directory

  -M, --mtime <MTIME>
          +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)

  -A, --atime <ATIME>
          just like -mtime, but based on file access time

  -y, --ctime <CTIME>
          just like -mtime, but based on file change time

      --files0-from <FILES0_FROM>
          Read NUL-terminated paths from FILE (use `-` for stdin)

      --files-from <FILES_FROM>
          Read newline-terminated paths from FILE (use `-` for stdin)

      --collapse <COLLAPSE>
          Keep these directories collapsed

  -m, --filetime <FILETIME>
          Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time

          Possible values:
          - a: last accessed time
          - c: last changed time
          - m: last modified time

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""


HELP_SHORT = """Like du but more intuitive

Usage: executable [OPTIONS] [PATH]...

Arguments:
  [PATH]...  Input files or directories

Options:
  -d, --depth <DEPTH>              Depth to show
  -T, --threads <THREADS>          Number of threads to use
      --config <FILE>              Specify a config file to use
  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)
  -p, --full-paths                 Subdirectories will not have their path shortened
  -X, --ignore-directory <PATH>    Exclude any file or directory with this path
  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter
  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them
  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory
  -s, --apparent-size              Use file length instead of blocks
  -r, --reverse                    Print tree upside down (biggest highest)
  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)
  -C, --force-colors               Force colors print
  -b, --no-percent-bars            No percent bars or percentages will be displayed
  -B, --bars-on-right              percent bars moved to right side of screen
  -z, --min-size <MIN_SIZE>        Minimum size file to include in output
  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)
      --skip-total                 No total row will be displayed
  -f, --filecount                  Directory 'size' is number of child files instead of disk size
  -i, --ignore-hidden              Do not display hidden files
  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v "\\.png$"
  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e "\\.png$"
  -t, --file-types                 show only these file types
  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width
  -P, --no-progress                Disable the progress indication
      --print-errors               Print path with errors
  -D, --only-dir                   Only directories will be displayed
  -F, --only-file                  Only files will be displayed. (Finds your largest files)
  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]
  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: 'fatal runtime error: stack overflow' (default low memory=1048576, high memory=1073741824)
  -j, --output-json                Output the directory tree as json to the current directory
  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago , and n matches files modified exactly n days ago, days are rounded down.That is +n => (−∞, curr−(n+1)), n => [curr−(n+1), curr−n), and -n => (𝑐𝑢𝑟𝑟−𝑛, +∞)
  -A, --atime <ATIME>              just like -mtime, but based on file access time
  -y, --ctime <CTIME>              just like -mtime, but based on file change time
      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use `-` for stdin)
      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use `-` for stdin)
      --collapse <COLLAPSE>        Keep these directories collapsed
  -m, --filetime <FILETIME>        Directory 'size' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time [possible values: a, c, m]
  -h, --help                       Print help (see more with '--help')
  -V, --version                    Print version"""


@dataclass
class Node:
    path: str
    name: str
    is_dir: bool
    size: int
    file_count: int = 0
    file_time: float = 0.0
    children: list = field(default_factory=list)


class Options:
    def __init__(self):
        self.paths = []
        self.config = None
        self.depth = None
        self.number = None
        self.full_paths = False
        self.ignore_dirs = []
        self.ignore_file = None
        self.follow = False
        self.apparent = False
        self.reverse = False
        self.no_bars = False
        self.min_size = None
        self.screen_reader = False
        self.skip_total = False
        self.filecount = False
        self.ignore_hidden = False
        self.exclude = []
        self.include = []
        self.file_types = False
        self.width = 80
        self.only_dir = False
        self.only_file = False
        self.output_format = None
        self.output_json = False
        self.files_from = None
        self.files0_from = None
        self.collapse = []
        self.filetime = None
        self.mtime = None
        self.atime = None
        self.ctime = None
        self.print_errors = False
        self.limit_filesystem = False


def die_arg(msg):
    print(f"error: {msg}\n\nFor more information, try '--help'.", file=sys.stderr)
    sys.exit(2)


def parse_args(argv):
    opt = Options()
    i = 0
    needs = {
        "-d": "depth", "--depth": "depth",
        "-T": None, "--threads": None,
        "--config": "config",
        "-n": "number", "--number-of-lines": "number",
        "-X": "ignore_dirs", "--ignore-directory": "ignore_dirs",
        "-I": "ignore_file", "--ignore-all-in-file": "ignore_file",
        "-z": "min_size", "--min-size": "min_size",
        "-v": "exclude", "--invert-filter": "exclude",
        "-e": "include", "--filter": "include",
        "-w": "width", "--terminal-width": "width",
        "-o": "output_format", "--output-format": "output_format",
        "-S": None, "--stack-size": None,
        "-M": "mtime", "--mtime": "mtime",
        "-A": "atime", "--atime": "atime",
        "-y": "ctime", "--ctime": "ctime",
        "--files-from": "files_from",
        "--files0-from": "files0_from",
        "--collapse": "collapse",
        "-m": "filetime", "--filetime": "filetime",
    }
    flags = {
        "-p": "full_paths", "--full-paths": "full_paths",
        "-L": "follow", "--dereference-links": "follow",
        "-x": "limit_filesystem", "--limit-filesystem": "limit_filesystem",
        "-s": "apparent", "--apparent-size": "apparent",
        "-r": "reverse", "--reverse": "reverse",
        "-c": None, "--no-colors": None,
        "-C": None, "--force-colors": None,
        "-b": "no_bars", "--no-percent-bars": "no_bars",
        "-B": None, "--bars-on-right": None,
        "-R": "screen_reader", "--screen-reader": "screen_reader",
        "--skip-total": "skip_total",
        "-f": "filecount", "--filecount": "filecount",
        "-i": "ignore_hidden", "--ignore-hidden": "ignore_hidden",
        "-t": "file_types", "--file-types": "file_types",
        "-P": None, "--no-progress": None,
        "--print-errors": "print_errors",
        "-D": "only_dir", "--only-dir": "only_dir",
        "-F": "only_file", "--only-file": "only_file",
        "-j": "output_json", "--output-json": "output_json",
    }
    while i < len(argv):
        a = argv[i]
        if a == "--":
            opt.paths.extend(argv[i + 1:])
            break
        if a in ("--help",):
            print(HELP_LONG)
            sys.exit(0)
        if a == "-h":
            print(HELP_SHORT)
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a.startswith("--") and "=" in a:
            a, val = a.split("=", 1)
            argv = argv[:i + 1] + [val] + argv[i + 1:]
        if a in needs:
            if i + 1 >= len(argv) or (argv[i + 1].startswith("-") and a not in ("-M", "-A", "-y")):
                die_arg(f"a value is required for '{long_name(a)}' but none was supplied")
            val = argv[i + 1]
            attr = needs[a]
            if attr == "depth":
                opt.depth = int(val)
            elif attr == "number":
                opt.number = int(val)
            elif attr == "ignore_dirs":
                opt.ignore_dirs.append(val)
            elif attr == "ignore_file":
                opt.ignore_file = val
            elif attr == "min_size":
                opt.min_size = parse_size(val)
            elif attr == "exclude":
                opt.exclude.append(re.compile(val))
            elif attr == "include":
                opt.include.append(re.compile(val))
            elif attr == "width":
                opt.width = int(val)
            elif attr == "output_format":
                if val not in ("si", "b", "k", "m", "g", "t", "kb", "mb", "gb", "tb"):
                    print(f"error: invalid value '{val}' for '--output-format <FORMAT>'\n  [possible values: si, b, k, m, g, t, kb, mb, gb, tb]\n\nFor more information, try '--help'.", file=sys.stderr)
                    sys.exit(2)
                opt.output_format = val
            elif attr == "files_from":
                opt.files_from = val
            elif attr == "files0_from":
                opt.files0_from = val
            elif attr == "config":
                opt.config = val
            elif attr == "collapse":
                opt.collapse.append(val)
            elif attr == "filetime":
                opt.filetime = val
            elif attr in ("mtime", "atime", "ctime"):
                setattr(opt, attr, val)
            i += 2
            continue
        if a in flags:
            attr = flags[a]
            if attr:
                setattr(opt, attr, True)
            i += 1
            continue
        if a.startswith("-"):
            print(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [PATH]...\n\nFor more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        opt.paths.append(a)
        i += 1

    apply_config(opt)
    if opt.ignore_file:
        try:
            with open(opt.ignore_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line:
                        opt.exclude.append(re.compile(line))
        except OSError as e:
            print(str(e), file=sys.stderr)
            sys.exit(1)
    if opt.files_from:
        opt.paths.extend(read_paths_file(opt.files_from, "\n"))
    if opt.files0_from:
        opt.paths.extend(read_paths_file(opt.files0_from, "\0"))
    if not opt.paths:
        opt.paths = ["."]
    return opt


def apply_config(opt):
    paths = []
    if opt.config:
        paths.append(opt.config)
    else:
        home = os.path.expanduser("~")
        paths.extend([os.path.join(home, ".config", "dust", "config.toml"), os.path.join(home, ".dust.toml")])
    cfg = None
    for p in paths:
        try:
            with open(p, "r", encoding="utf-8") as f:
                cfg = f.read()
            break
        except OSError:
            continue
    if cfg is None:
        return
    for raw in cfg.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or "=" not in line:
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        v = v.strip('"').strip("'")
        truth = v.lower() == "true"
        if k == "reverse":
            opt.reverse = truth
        elif k == "display-full-paths":
            opt.full_paths = truth
        elif k == "display-apparent-size":
            opt.apparent = truth
        elif k == "no-bars":
            opt.no_bars = truth
        elif k == "skip-total":
            opt.skip_total = truth
        elif k == "ignore-hidden":
            opt.ignore_hidden = truth
        elif k == "output-format":
            opt.output_format = v
        elif k == "number-of-lines":
            try:
                opt.number = int(v)
            except ValueError:
                pass


def long_name(a):
    names = {"-d": "--depth <DEPTH>", "-n": "--number-of-lines <NUMBER>"}
    return names.get(a, a)


def read_paths_file(path, sep):
    data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
    text = data.decode("utf-8", "surrogateescape")
    return [p for p in text.split(sep) if p]


def parse_size(s):
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)([A-Za-z]*)", s.strip())
    if not m:
        return 0
    n = float(m.group(1))
    unit = m.group(2).lower()
    mult = {
        "": 1, "b": 1,
        "k": 1024, "kb": 1024, "kib": 1024,
        "m": 1024**2, "mb": 1024**2, "mib": 1024**2,
        "g": 1024**3, "gb": 1024**3, "gib": 1024**3,
        "t": 1024**4, "tb": 1024**4, "tib": 1024**4,
    }.get(unit, 1)
    return int(n * mult)


def raw_size(st, apparent):
    return int(st.st_size if apparent else getattr(st, "st_blocks", 0) * 512)


def path_excluded(path, name, opt):
    if opt.ignore_hidden and name.startswith("."):
        return True
    for x in opt.ignore_dirs:
        if x == name or x == path or path.endswith(os.sep + x):
            return True
    for rx in opt.exclude:
        if rx.search(path):
            return True
    return False


def time_match(st, opt):
    checks = [("mtime", st.st_mtime), ("atime", st.st_atime), ("ctime", st.st_ctime)]
    now = time.time()
    for attr, value in checks:
        spec = getattr(opt, attr)
        if not spec:
            continue
        try:
            if spec[0] in "+-":
                sign, n = spec[0], int(spec[1:])
            else:
                sign, n = "", int(spec)
        except Exception:
            return True
        age_days = int((now - value) // 86400)
        if sign == "+" and not (age_days > n):
            return False
        if sign == "-" and not (age_days < n):
            return False
        if sign == "" and not (age_days == n):
            return False
    return True


def scan(path, opt, root_dev=None):
    try:
        st = os.stat(path) if opt.follow else os.lstat(path)
    except OSError as e:
        print(f"{e.strerror}: {path}", file=sys.stderr)
        return None
    name = os.path.basename(path.rstrip(os.sep)) or path
    if path_excluded(path, name, opt):
        return None
    if root_dev is not None and opt.limit_filesystem and st.st_dev != root_dev:
        return None
    mode = st.st_mode
    is_dir = stat.S_ISDIR(mode)
    is_file = stat.S_ISREG(mode) or stat.S_ISLNK(mode) or not is_dir
    if not time_match(st, opt):
        return None
    own = 0 if (opt.include and is_dir) else raw_size(st, opt.apparent)
    node = Node(path=os.path.abspath(path) if path != "." else ".", name=name, is_dir=is_dir, size=own)
    node.file_time = max(st.st_atime if opt.filetime == "a" else st.st_ctime if opt.filetime == "c" else st.st_mtime, 0)
    if is_dir and (name not in opt.collapse and path not in opt.collapse):
        try:
            entries = sorted(os.listdir(path))
        except OSError as e:
            if opt.print_errors:
                print(f"{e.strerror}: {path}", file=sys.stderr)
            entries = []
        for ent in entries:
            child = scan(os.path.join(path, ent), opt, root_dev if root_dev is not None else st.st_dev)
            if child is not None:
                node.children.append(child)
                node.size += child.size
                node.file_count += child.file_count
                node.file_time = max(node.file_time, child.file_time)
    if is_file:
        node.file_count = 1
    if opt.include and is_file and not any(rx.search(path) for rx in opt.include):
        return None
    return node


def display_value(node, opt):
    if opt.filecount:
        return node.file_count
    if opt.filetime:
        return int(node.file_time)
    return node.size


def visible_nodes(node, opt, depth=0, out=None):
    if out is None:
        out = []
    for ch in sorted(node.children, key=lambda n: (display_value(n, opt), n.name), reverse=opt.reverse):
        if opt.depth is None or depth < opt.depth:
            visible_nodes(ch, opt, depth + 1, out)
    show = True
    if opt.only_dir and not node.is_dir:
        show = False
    if opt.only_file and node.is_dir and depth != 0:
        show = False
    if opt.min_size is not None and display_value(node, opt) <= opt.min_size and depth != 0:
        show = False
    if opt.include and display_value(node, opt) == 0 and depth != 0:
        show = False
    if show:
        out.append((node, depth))
    return out


def fmt_size(n, fmt=None):
    if fmt == "b":
        return f"{n}B"
    fixed = {
        "k": (1024, "K"), "m": (1024**2, "M"), "g": (1024**3, "G"), "t": (1024**4, "T"),
        "kb": (1000, "K"), "mb": (1000**2, "M"), "gb": (1000**3, "G"), "tb": (1000**4, "T"),
    }
    if fmt in fixed:
        div, suf = fixed[fmt]
        return f"{int(n / div)}{suf}"
    base = 1000 if fmt == "si" else 1024
    suffix = ["B", "K", "M", "G", "T", "P"]
    v = float(n)
    idx = 0
    while abs(v) >= base and idx < len(suffix) - 1:
        v /= base
        idx += 1
    if idx == 0:
        return f"{int(v)}B"
    if v < 10:
        return f"{v:.1f}{suffix[idx]}"
    return f"{int(round(v))}{suffix[idx]}"


def node_label(node, opt):
    return node.path if opt.full_paths or opt.output_json else node.name


def print_tree(root, opt):
    nodes = visible_nodes(root, opt)
    if opt.skip_total and nodes and nodes[-1][0] is root:
        nodes = nodes[:-1]
    if opt.number:
        nodes = nodes[-opt.number:]
    total = max(display_value(root, opt), 1)
    size_strings = [str(display_value(n, opt)) if opt.filecount or opt.filetime else fmt_size(display_value(n, opt), opt.output_format) for n, _ in nodes]
    sw = max([len(s) for s in size_strings] + [1])
    if opt.reverse:
        nodes = list(reversed(nodes))
        size_strings = list(reversed(size_strings))
    for (node, depth), s in zip(nodes, size_strings):
        pct = int(round(display_value(node, opt) * 100 / total))
        label = node_label(node, opt)
        if opt.screen_reader:
            print(f"{label:<20} {depth} {s:>{sw}} {pct:>3}%")
            continue
        indent = "│ " * max(depth - 1, 0)
        branch = "┌── " if not node.is_dir else "┌─┴ " if depth == 0 else "├─┴ "
        if opt.no_bars:
            print(f"{s:>{sw}}   {indent}{branch}{label}")
        else:
            bar_len = max(1, min(40, int(pct * 40 / 100)))
            bar = "█" * bar_len
            print(f"{s:>{sw}}   {indent}{branch}{label:<20} │{bar:<40}│ {pct:>3}%")


def json_node(node, opt):
    children = sorted(node.children, key=lambda n: display_value(n, opt), reverse=True)
    if opt.include:
        children = [c for c in children if display_value(c, opt) != 0]
    return {
        "size": str(display_value(node, opt)) if opt.filecount or opt.filetime else fmt_size(display_value(node, opt), opt.output_format),
        "name": node.path,
        "children": [json_node(c, opt) for c in children],
    }


def file_type_report(paths, opt):
    totals = {}
    for root in paths:
        for dirpath, dirnames, filenames in os.walk(root, followlinks=opt.follow):
            if opt.ignore_hidden:
                dirnames[:] = [d for d in dirnames if not d.startswith(".")]
                filenames = [f for f in filenames if not f.startswith(".")]
            for f in filenames:
                p = os.path.join(dirpath, f)
                if path_excluded(p, f, opt):
                    continue
                if opt.include and not any(rx.search(p) for rx in opt.include):
                    continue
                try:
                    st = os.stat(p) if opt.follow else os.lstat(p)
                except OSError:
                    continue
                if not time_match(st, opt):
                    continue
                ext = os.path.splitext(f)[1] or "(no extension)"
                totals[ext] = totals.get(ext, 0) + (1 if opt.filecount else raw_size(st, opt.apparent))
    root = Node("(total)", "(total)", True, sum(totals.values()))
    for ext, sz in sorted(totals.items(), key=lambda kv: kv[1]):
        root.children.append(Node(ext, ext, False, sz, file_count=sz if opt.filecount else 0))
    if opt.filecount:
        root.file_count = root.size
    return root


def main(argv):
    opt = parse_args(argv)
    if opt.file_types:
        root = file_type_report(opt.paths, opt)
    else:
        roots = []
        for p in opt.paths:
            n = scan(p, opt)
            if n is not None:
                roots.append(n)
        if not roots:
            return 1
        if len(roots) == 1:
            root = roots[0]
        else:
            root = Node("(total)", "(total)", True, sum(n.size for n in roots), children=roots)
            root.file_count = sum(n.file_count for n in roots)
            root.file_time = max([n.file_time for n in roots] + [0])
    if opt.output_json:
        print(json.dumps(json_node(root, opt), separators=(",", ":")))
    else:
        print_tree(root, opt)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
