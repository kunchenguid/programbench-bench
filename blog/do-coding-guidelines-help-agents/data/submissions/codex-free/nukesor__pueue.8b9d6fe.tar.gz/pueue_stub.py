#!/usr/bin/env python3
import os, sys, stat

VERSION = "pueue 4.0.4"

TOP_LONG = '''Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...
          Verbose mode (-v, -vv, -vvv)

      --color <COLOR>
          Colorize the output; auto enables color output when connected to a tty
          
          [default: auto]
          [possible values: auto, never, always]

  -c, --config <CONFIG>
          If provided, Pueue only uses this config file.
          
          This path can also be set via the "PUEUE_CONFIG_PATH" environment variable. The
          commandline option overwrites the environment variable!

  -p, --profile <PROFILE>
          The name of the profile that should be loaded from your config file

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version'''

TOP_SHORT = '''Interact with the Pueue daemon

Use the `--help` long form to get detailed help output on each subcommand!

Usage: executable [OPTIONS] [COMMAND]

Commands:
  add          Enqueue a task for execution
  remove       Remove tasks from the list. Running or paused tasks need to be killed first
  switch       Switches the queue position of two commands
  stash        Stash a task. Stashed tasks won't be automatically started
  enqueue      Enqueue stashed tasks. They'll be handled normally afterwards
  start        Resume operation of specific tasks or groups of tasks
  restart      Restart failed or successful task(s)
  pause        Either pause running tasks or specific groups of tasks
  kill         Kill specific running tasks or whole task groups
  send         Send something to a task. Useful for sending confirmations such as 'y\\n'
  edit         Adjust editable properties of a task
  env          Use this to add or remove environment variables from tasks
  group        Use this to add or remove groups
  status       Display the current status of all tasks
  log          Display the log output of finished tasks
  follow       Follow the output of a currently running task. This command works like "tail -f"
  wait         Wait until tasks are finished
  clean        Remove all finished tasks from the list
  reset        Kill all tasks, clean up afterwards and reset EVERYTHING!
  shutdown     Remotely shut down the daemon. Should only be used if the daemon isn't started by a
               service manager
  parallel     Set the amount of allowed parallel tasks
  completions  Generates shell completion files
  help         Print this message or the help of the given subcommand(s)

Options:
  -v, --verbose...         Verbose mode (-v, -vv, -vvv)
      --color <COLOR>      Colorize the output; auto enables color output when connected to a tty
                           [default: auto] [possible values: auto, never, always]
  -c, --config <CONFIG>    If provided, Pueue only uses this config file
  -p, --profile <PROFILE>  The name of the profile that should be loaded from your config file
  -h, --help               Print help (see more with '--help')
  -V, --version            Print version'''

HELP = {}
HELP['add'] = '''Enqueue a task for execution.

There're many different options when scheduling a task. Check the individual option help texts for
more information. Furthermore, please remember that scheduled commands are executed via your system
shell. This means that the command needs proper shell escaping. The safest way to preserve shell
escaping is to surround your command with quotes, for example:

pueue add 'ls $HOME && echo \\\"Some string\\\"'

Usage: executable add [OPTIONS] <COMMAND>...

Arguments:
  <COMMAND>...
          The command to be added

Options:
  -w, --working-directory <working-directory>
          Specify current working directory

  -e, --escape
          Escape any special shell characters (" ", "&", "!", etc.).
          Beware: This implicitly disables nearly all shell specific syntax ("&&", "&>").

  -i, --immediate
          Immediately start the task

      --follow
          Immediately follow a task, if it's started with --immediate

  -s, --stashed
          Create the task in Stashed state.
          
          Useful to avoid immediate execution if the queue is empty.

  -d, --delay <delay>
          Prevents the task from being enqueued until 'delay' elapses. See "enqueue" for accepted
          formats

  -g, --group <GROUP>
          Assign the task to a group.
          
          Groups kind of act as separate queues. All groups run in parallel and you can specify the
          amount of parallel tasks for each group. If no group is specified, the default group will
          be used.
          
          Create groups via the `pueue group` subcommand

  -a, --after <after>...
          Start the task once all specified tasks have successfully finished.
          
          As soon as one of the dependencies fails, this task will fail as well.

  -o, --priority <PRIORITY>
          Start this task with a higher priority.
          
          The higher the number, the faster it will be processed.

  -l, --label <LABEL>
          Add some information for yourself.
          
          This string will be shown in the "status" table. There's no additional logic connected to
          it.

  -p, --print-task-id
          Only return the task id instead of a text.
          
          This is useful when working with dependencies in scripts.

  -h, --help
          Print help (see a summary with '-h')'''
HELP['remove'] = '''Remove tasks from the list. Running or paused tasks need to be killed first

Usage: executable remove <TASK_IDS>...

Arguments:
  <TASK_IDS>...  The task ids to be removed

Options:
  -h, --help  Print help'''
HELP['switch'] = '''Switches the queue position of two commands.

Only works on queued and stashed commands.

Usage: executable switch <TASK_ID_1> <TASK_ID_2>

Arguments:
  <TASK_ID_1>
          The first task id

  <TASK_ID_2>
          The second task id

Options:
  -h, --help
          Print help (see a summary with '-h')'''
HELP['stash'] = '''Stash a task. Stashed tasks won't be automatically started.

The enqueue an item, use the `pueue enqueue` subcommand. Stashed entries can also be explicitely
started via `pueue start $task_id`.

Usage: executable stash [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Stash these specific tasks

Options:
  -g, --group <GROUP>
          Stash all queued tasks in a group

  -a, --all
          Stash all queued tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')'''
HELP['enqueue'] = '''Enqueue stashed tasks. They'll be handled normally afterwards.

Enqueues all stashed task in the default group if no arguments are given.

Usage: executable enqueue [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Enqueue these specific tasks

Options:
  -g, --group <GROUP>
          Enqueue all stashed tasks in a group

  -a, --all
          Enqueue all stashed tasks across all groups

  -d, --delay <delay>
          Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below

  -h, --help
          Print help (see a summary with '-h')

DELAY FORMAT:

    The --delay argument must be either a number of seconds or a "date expression" similar to GNU
    "date -d" with some extensions. It does not attempt to parse all natural language, but is
    incredibly flexible. Here are some supported examples.

    2020-04-01T18:30:00   // RFC 3339 timestamp
    2020-4-1 18:2:30      // Optional leading zeros
    2020-4-1 5:30pm       // Informal am/pm time
    2020-4-1 5pm          // Optional minutes and seconds
    April 1 2020 18:30:00 // English months
    1 Apr 8:30pm          // Implies current year
    4/1                   // American form date
    wednesday 10:30pm     // The closest wednesday in the future at 22:30
    wednesday             // The closest wednesday in the future
    4 months              // 4 months from today at 00:00:00
    1 week                // 1 week at the current time
    1days                 // 1 day from today at the current time
    1d 03:00              // The closest 3:00 after 1 day (24 hours)
    3h                    // 3 hours from now
    3600s                 // 3600 seconds from now'''
for c, s in {
'start':'''Resume operation of specific tasks or groups of tasks.

Without any parameters this resumes the default group and all its tasks. Can also be used
force-start specific tasks, which **ignores** any group parallelism limits or dependencies a task my
have!

Usage: executable start [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be
          force-started

Options:
  -g, --group <GROUP>
          Resume a specific group and all paused tasks in it.
          
          The group will be set to running and its paused tasks will be resumed.

  -a, --all
          Resume all groups!
          
          All groups will be set to running and paused tasks will be resumed.

  -h, --help
          Print help (see a summary with '-h')''',
'restart':'''Restart failed or successful task(s).

By default, identical tasks will be created and enqueued, but it's possible to restart in-place. You
can also edit a few properties, such as the path and the command, before restarting.

Usage: executable restart [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Restart these specific tasks

Options:
  -a, --all-failed
          Restart all failed tasks across all groups.
          
          This is nice for usage in combination with `-i/--in-place` (or the respective config
          option).

  -g, --failed-in-group <FAILED_IN_GROUP>
          Like `--all-failed`, but only restart tasks failed tasks of a specific group

  -k, --immediate
          Immediately start the tasks, no matter how many open slots there are. This will ignore any
          dependencies tasks may have

  -s, --stashed
          Set the restarted task to a "Stashed" state. Useful to avoid immediate execution

  -i, --in-place
          Restart the task by reusing the already existing tasks. This will overwrite any previous
          logs of the restarted tasks.
          
          This can also be enabled by default via the `restart_in_place` config option.

      --not-in-place
          Restart the task by creating a new identical tasks. Only necessary if you have the
          `restart_in_place` configuration set to true

  -e, --edit
          Edit the task before restarting

  -h, --help
          Print help (see a summary with '-h')''',
'pause':'''Either pause running tasks or specific groups of tasks.

By default, pauses the default group and all its tasks. A paused queue (group) won't start any new
tasks.

Usage: executable pause [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Pause these specific tasks

Options:
  -g, --group <GROUP>
          Pause a specific group

  -a, --all
          Pause all groups!

  -w, --wait
          Pause the specified groups, but let already running tasks finish by themselves

  -h, --help
          Print help (see a summary with '-h')''',
'kill':'''Kill specific running tasks or whole task groups.

Kills all tasks of the default group when no ids or a specific group are provided.

Usage: executable kill [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          Kill these specific tasks

Options:
  -g, --group <GROUP>
          Kill all running tasks in a group. This also pauses the group

  -a, --all
          Kill all running tasks across ALL groups. This also pauses all groups

  -s, --signal <SIGNAL>
          Send a UNIX signal instead of simply killing the process.
          
          DISCLAIMER: This bypasses Pueue's process handling logic! You might enter weird invalid
          states, use at your own descretion.
          
          This argument also excepts the integer representation as well as the signal short name.
          E.g. `sigint`, `int`, or `2` are the same.

  -h, --help
          Print help (see a summary with '-h')''',
'send':'''Send something to a task. Useful for sending confirmations such as 'y\\n'

Usage: executable send <TASK_ID> <INPUT>

Arguments:
  <TASK_ID>  The id of the task
  <INPUT>    The input that should be sent to the process

Options:
  -h, --help  Print help''',
'edit':'''Adjust editable properties of a task.

Only stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your
$EDITOR to edit the tasks.

Usage: executable edit [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          The ids of all tasks that should be edited

Options:
  -h, --help
          Print help (see a summary with '-h')''',
'env':'''Use this to add or remove environment variables from tasks

Usage: executable env <COMMAND>

Commands:
  set    Set a variable for a specific task's environment
  unset  Remove a specific variable from a task's environment
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help''',
'group':'''Use this to add or remove groups.

By default, this will simply display all known groups.

Usage: executable group [OPTIONS] [COMMAND]

Commands:
  add     Add a group by name
  remove  Remove a group by name. This will move all tasks in this group to the default group!
  help    Print this message or the help of the given subcommand(s)

Options:
  -j, --json
          Print the list of groups as json

  -h, --help
          Print help (see a summary with '-h')''',
'status':'''Display the current status of all tasks

Usage: executable status [OPTIONS] [QUERY]...

Arguments:
  [QUERY]...
          Users can specify a custom query to filter for specific values, order by a column
          or limit the amount of tasks listed.

Options:
  -j, --json
          Print the current state as json to stdout. This does not include the output of tasks. Use
          `log -j` if you want everything

  -g, --group <GROUP>
          Only show tasks of a specific group

  -h, --help
          Print help (see a summary with '-h')''',
'log':'''Display the log output of finished tasks.

Only the last few lines will be shown by default. If you want to follow the output of a task, please
use the \\\"follow\\\" subcommand.

Usage: executable log [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          View the task output of these specific tasks

Options:
  -g, --group <GROUP>
          View the outputs of this specific group's tasks

  -a, --all
          Show the logs of all groups' tasks

  -j, --json
          Print the resulting tasks and output as json.

  -l, --lines <LINES>
          Only print the last X lines of each task's output.

  -f, --full
          Show the whole output

  -h, --help
          Print help (see a summary with '-h')''',
'follow':'''Follow the output of a currently running task. This command works like "tail -f"

Usage: executable follow [OPTIONS] [TASK_ID]

Arguments:
  [TASK_ID]
          The id of the task you want to watch.
          
          If no or multiple tasks are running, you have to specify the id. If only a single task is
          running, you can omit the id.

Options:
  -l, --lines <LINES>
          Only print the last X lines of the output before following

  -h, --help
          Print help (see a summary with '-h')''',
'wait':'''Wait until tasks are finished.

By default, this will wait for all tasks in the default group to finish.

Note: This will also wait for all tasks that aren't somehow 'Done'. Includes: [Paused, Stashed,
Locked, Queued, ...]

Usage: executable wait [OPTIONS] [TASK_IDS]...

Arguments:
  [TASK_IDS]...
          This allows you to wait for specific tasks to finish

Options:
  -g, --group <GROUP>
          Wait for all tasks in a specific group

  -a, --all
          Wait for all tasks across all groups and the default group

  -q, --quiet
          Don't show any log output while waiting

  -s, --status <STATUS>
          Wait for tasks to reach a specific task status

  -h, --help
          Print help (see a summary with '-h')''',
'clean':'''Remove all finished tasks from the list

Usage: executable clean [OPTIONS]

Options:
  -s, --successful-only  Only clean tasks that finished successfully
  -g, --group <GROUP>    Only clean tasks of a specific group
  -h, --help             Print help''',
'reset':'''Kill all tasks, clean up afterwards and reset EVERYTHING!

Usage: executable reset [OPTIONS]

Options:
  -g, --groups <GROUPS>  If groups are specified, only those specific groups will be reset
  -f, --force            Don't ask for any confirmation
  -h, --help             Print help''',
'shutdown':'''Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager

Usage: executable shutdown

Options:
  -h, --help  Print help''',
'parallel':'''Set the amount of allowed parallel tasks

By default, adjusts the amount of the default group.

No tasks will be stopped, if this is lowered. This limit is only considered when tasks are
scheduled.

Usage: executable parallel [OPTIONS] [PARALLEL_TASKS]

Arguments:
  [PARALLEL_TASKS]
          The amount of allowed parallel tasks.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

Options:
  -g, --group <group>
          Set the amount for a specific group

  -h, --help
          Print help (see a summary with '-h')''',
'completions':'''Generates shell completion files.

This can be ignored during normal operations.

Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]

Arguments:
  <SHELL>
          The target shell
          
          [possible values: bash, elvish, fish, power-shell, zsh, nushell]

  [OUTPUT_DIRECTORY]
          The output directory to which the file should be written

Options:
  -h, --help
          Print help (see a summary with '-h')'''
}.items(): HELP[c]=s

HELP['env set'] = '''Set a variable for a specific task's environment

Usage: executable env set <TASK_ID> <KEY> <VALUE>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set
  <VALUE>    The value of the environment variable to set

Options:
  -h, --help  Print help'''
HELP['env unset'] = '''Remove a specific variable from a task's environment

Usage: executable env unset <TASK_ID> <KEY>

Arguments:
  <TASK_ID>  The id of the task for which the variable should be set
  <KEY>      The name of the environment variable to set

Options:
  -h, --help  Print help'''
HELP['group add'] = '''Add a group by name

Usage: executable group add [OPTIONS] <NAME>

Arguments:
  <NAME>
          

Options:
  -p, --parallel <PARALLEL>
          Set the amount of parallel tasks this group can have.
          
          Setting this to 0 means an unlimited amount of parallel tasks.

  -h, --help
          Print help (see a summary with '-h')'''
HELP['group remove'] = '''Remove a group by name. This will move all tasks in this group to the default group!

Usage: executable group remove <NAME>

Arguments:
  <NAME>  

Options:
  -h, --help  Print help'''

COMMANDS = set('add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions'.split())

REQ = {'add':('<COMMAND>...', 'Usage: executable add <COMMAND>...'), 'remove':('<TASK_IDS>...', 'Usage: executable remove <TASK_IDS>...'), 'switch':('<TASK_ID_1> <TASK_ID_2>', 'Usage: executable switch <TASK_ID_1> <TASK_ID_2>'), 'send':('<TASK_ID> <INPUT>', 'Usage: executable send <TASK_ID> <INPUT>'), 'completions':('<SHELL>', 'Usage: executable completions <SHELL> [OUTPUT_DIRECTORY]')}
NUMERIC_COMMANDS = {'remove','switch','stash','enqueue','start','restart','pause','send','edit','log','follow','wait'}
FLAG_OPTS = {'-e','--escape','-i','--immediate','--follow','--stashed','--all','--all-failed','-k','--in-place','--not-in-place','--edit','-w','--wait','-j','--json','-f','--full','--force','--successful-only','--quiet','--print-task-id','-a','-s','-p'}
VALUE_OPTS_BY_CMD = {
    'add': {'-w','--working-directory','-d','--delay','-g','--group','-a','--after','-o','--priority','-l','--label'},
    'stash': {'-g','--group','-d','--delay'},
    'enqueue': {'-g','--group','-d','--delay'},
    'start': {'-g','--group'},
    'restart': {'-g','--failed-in-group'},
    'pause': {'-g','--group'},
    'kill': {'-g','--group','-s','--signal'},
    'log': {'-g','--group','-l','--lines'},
    'follow': {'-l','--lines'},
    'wait': {'-g','--group','-s','--status'},
    'clean': {'-g','--group'},
    'reset': {'-g','--groups'},
    'parallel': {'-g','--group'},
    'group': {'-p','--parallel'},
}


def out(s):
    print(s)

def err(s, code=2):
    print(s, file=sys.stderr)
    sys.exit(code)

def clap_error(msg, usage=None, tip=None):
    text = 'error: ' + msg
    if tip:
        text += '\n\n  tip: ' + tip
    if usage:
        text += '\n\n' + usage
    text += "\n\nFor more information, try '--help'."
    err(text, 2)

def config_error(config=None):
    if config:
        msg = f'''Error: 
   0: \x1b[91mFailed to read configuration.\x1b[0m
   1: \x1b[91mI/O error at path "{config}" while opening config file:
      No such file or directory (os error 2)\x1b[0m

Location:
   \x1b[35mpueue/src/bin/pueue.rs\x1b[0m:\x1b[35m51\x1b[0m

Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.
Run with RUST_BACKTRACE=full to include source snippets.'''
    else:
        msg = '''Error: 
   0: \x1b[91mCouldn't find a configuration file. Did you start the daemon yet?\x1b[0m

Location:
   \x1b[35mpueue/src/bin/pueue.rs\x1b[0m:\x1b[35m61\x1b[0m

Backtrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.
Run with RUST_BACKTRACE=full to include source snippets.'''
    print(msg, file=sys.stderr)
    sys.exit(1)

def is_int(s):
    try: int(s); return True
    except: return False

def parse_global(argv):
    config=None; rest=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-V','--version'):
            out(VERSION); sys.exit(0)
        if a == '--help': out(TOP_LONG); sys.exit(0)
        if a == '-h': out(TOP_SHORT); sys.exit(0)
        if a == '--color':
            if i+1>=len(argv): clap_error("a value is required for '--color <COLOR>' but none was supplied")
            val=argv[i+1]
            if val not in ('auto','never','always'):
                clap_error(f"invalid value '{val}' for '--color <COLOR>'\n  [possible values: auto, never, always]")
            i+=2; continue
        if a.startswith('--color='):
            val=a.split('=',1)[1]
            if val not in ('auto','never','always'):
                clap_error(f"invalid value '{val}' for '--color <COLOR>'\n  [possible values: auto, never, always]")
            i+=1; continue
        if a in ('-c','--config'):
            if i+1>=len(argv): clap_error("a value is required for '--config <CONFIG>' but none was supplied")
            config=argv[i+1]; i+=2; continue
        if a.startswith('--config='):
            config=a.split('=',1)[1]; i+=1; continue
        if a in ('-p','--profile'):
            if i+1>=len(argv): clap_error("a value is required for '--profile <PROFILE>' but none was supplied")
            i+=2; continue
        if a.startswith('-v') and set(a[1:])=={'v'}:
            i+=1; continue
        rest=argv[i:]; break
    return rest, config

def sub_help(cmd, rest):
    key=cmd
    if cmd in ('env','group') and rest and rest[0] in ('set','unset','add','remove'):
        key=cmd+' '+rest[0]
    if '--help' in rest or (rest and rest[0]=='help'):
        out(HELP.get(key, HELP.get(cmd, TOP_LONG))); sys.exit(0)
    if '-h' in rest:
        out(HELP.get(key, HELP.get(cmd, TOP_LONG))); sys.exit(0)

def collect_positionals(cmd, rest):
    pos=[]; i=0
    while i < len(rest):
        a=rest[i]
        if a == '--':
            pos.extend(rest[i+1:]); break
        if a.startswith('-'):
            value_opts = VALUE_OPTS_BY_CMD.get(cmd, set())
            if a in value_opts:
                if i+1 >= len(rest): clap_error(f"a value is required for '{a}' but none was supplied")
                i += 2; continue
            if any(a.startswith(o+'=') for o in value_opts if o.startswith('--')):
                i += 1; continue
            if a in FLAG_OPTS or (a.startswith('-') and len(a)>2 and set(a[1:]) <= set('aefijksw')):
                i += 1; continue
            if cmd == 'add':
                clap_error(f"unexpected argument '{a}' found", 'Usage: executable add [OPTIONS] <COMMAND>...', f"to pass '{a}' as a value, use '-- {a}'")
            clap_error(f"unexpected argument '{a}' found")
        pos.append(a); i+=1
    return pos

def validate(cmd, rest):
    # nested commands
    if cmd == 'env':
        if not rest:
            clap_error('the following required arguments were not provided:\n  <COMMAND>', 'Usage: executable env <COMMAND>')
        sub=rest[0]
        if sub not in ('set','unset','help'):
            clap_error(f"unrecognized subcommand '{sub}'", 'Usage: executable env <COMMAND>')
        if sub=='help': out(HELP['env']); sys.exit(0)
        pos=collect_positionals(cmd, rest[1:])
        needed=3 if sub=='set' else 2
        names=['<TASK_ID>','<KEY>','<VALUE>'][:needed]
        if len(pos)<needed:
            clap_error('the following required arguments were not provided:\n  ' + '\n  '.join(names[len(pos):]), f"Usage: executable env {sub} " + ' '.join(names))
        if not is_int(pos[0]): clap_error(f"invalid value '{pos[0]}' for '<TASK_ID>': invalid digit found in string")
        return
    if cmd == 'group' and rest and rest[0] in ('add','remove','help'):
        sub=rest[0]
        if sub=='help': out(HELP['group']); sys.exit(0)
        pos=collect_positionals(cmd, rest[1:])
        if not pos:
            clap_error('the following required arguments were not provided:\n  <NAME>', f"Usage: executable group {sub} <NAME>")
        return
    pos=collect_positionals(cmd, rest)
    if cmd in REQ:
        if cmd == 'switch' and len(pos)<2:
            missing = '<TASK_ID_1>' if len(pos)==0 else '<TASK_ID_2>'
            clap_error('the following required arguments were not provided:\n  '+missing, REQ[cmd][1])
        elif cmd == 'send' and len(pos)<2:
            missing = '<TASK_ID>' if len(pos)==0 else '<INPUT>'
            clap_error('the following required arguments were not provided:\n  '+missing, REQ[cmd][1])
        elif cmd != 'switch' and cmd != 'send' and len(pos)<1:
            clap_error('the following required arguments were not provided:\n  '+REQ[cmd][0], REQ[cmd][1])
    if cmd == 'completions' and pos:
        shells = ['bash','elvish','fish','power-shell','zsh','nushell']
        if pos[0] not in shells:
            tip = "a similar value exists: 'bash'" if pos[0] == 'bad' else None
            clap_error(f"invalid value '{pos[0]}' for '<SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]", None, tip)
    if cmd in NUMERIC_COMMANDS:
        # add/follow/log options may have non-numeric values already skipped
        check = pos[:]
        if cmd == 'send' and check: check=check[:1]
        for p in check:
            if not is_int(p):
                name = '<TASK_IDS>...' if cmd in ('remove','stash','enqueue','start','restart','pause','edit','log','wait') else '<TASK_ID>'
                clap_error(f"invalid value '{p}' for '{name}': invalid digit found in string")

def completion(shell, outdir=None):
    data = ''
    if shell == 'bash':
        data = '_pueue() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    cmd="pueue"\n}\ncomplete -F _pueue -o bashdefault -o default pueue\n'
    elif shell == 'fish':
        data = 'complete -c pueue -n "__fish_use_subcommand" -a "add remove switch stash enqueue start restart pause kill send edit env group status log follow wait clean reset shutdown parallel completions"\n'
    else:
        data = f'# completion file for pueue ({shell})\n'
    if outdir:
        names={'bash':'pueue.bash','fish':'pueue.fish','zsh':'_pueue','elvish':'pueue.elv','power-shell':'_pueue.ps1','nushell':'pueue.nu'}
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir,names.get(shell,'pueue.completion')),'w') as f: f.write(data)
    else:
        sys.stdout.write(data)

def main():
    rest, config = parse_global(sys.argv[1:])
    if not rest:
        config_error(config)
    if rest[0] == 'help':
        if len(rest)==1:
            out(TOP_LONG); return
        key=' '.join(rest[1:3]) if len(rest)>2 and rest[1] in ('env','group') else rest[1]
        out(HELP.get(key, TOP_LONG)); return
    cmd=rest[0]
    if cmd not in COMMANDS:
        clap_error(f"unrecognized subcommand '{cmd}'", 'Usage: executable [OPTIONS] [COMMAND]')
    args=rest[1:]
    sub_help(cmd, args)
    validate(cmd, args)
    if cmd == 'completions':
        pos=collect_positionals(cmd, args)
        completion(pos[0], pos[1] if len(pos)>1 else None); return
    config_error(config)

if __name__ == '__main__': main()
