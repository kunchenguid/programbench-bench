#!/usr/bin/env python3
import argparse
import datetime as dt
import hashlib
import json
import os
import re
import sqlite3
import sys
from pathlib import Path


DB_NAME = "hashcards.db"
VERSION = "hashcards 0.3.0"


class ParseError(Exception):
    def __init__(self, message, path, line):
        super().__init__(message)
        self.message = message
        self.path = path
        self.line = line


def digest(value):
    if not isinstance(value, str):
        value = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def trim_block(lines):
    while lines and lines[0] == "":
        lines.pop(0)
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines)


def is_marker(line):
    return line.startswith("Q:") or line.startswith("C:")


def md_files(root):
    root = Path(root)
    if root.is_file() and root.suffix.lower() == ".md":
        return [root]
    files = []
    for p in root.rglob("*.md"):
        if DB_NAME in p.parts:
            continue
        if any(part.startswith(".") for part in p.relative_to(root).parts):
            continue
        files.append(p)
    return sorted(files, key=lambda p: str(p))


def parse_collection(root):
    root = Path(root).resolve()
    cards = []
    seen = set()
    for path in md_files(root):
        cards.extend(parse_file(path, seen))
    cards.sort(key=lambda c: c["hash"])
    return cards


def parse_file(path, seen):
    text = path.read_text(encoding="utf-8")
    raw_lines = text.splitlines()
    deck = path.stem
    cards = []
    i = 0
    while i < len(raw_lines):
        line = raw_lines[i]
        if line.startswith("Q:"):
            start = i
            question_lines = [line[2:].lstrip()]
            i += 1
            while i < len(raw_lines) and not raw_lines[i].startswith("A:"):
                if is_marker(raw_lines[i]):
                    raise ParseError("Basic card is missing an answer.", path, start + 1)
                question_lines.append(raw_lines[i])
                i += 1
            if i >= len(raw_lines):
                raise ParseError("Basic card is missing an answer.", path, start + 1)
            answer_lines = [raw_lines[i][2:].lstrip()]
            i += 1
            while i < len(raw_lines) and not is_marker(raw_lines[i]):
                answer_lines.append(raw_lines[i])
                i += 1
            end = i if i < len(raw_lines) else max(start, len(raw_lines) - 1)
            question = trim_block(question_lines)
            answer = trim_block(answer_lines)
            content = {"basic": {"question": question, "answer": answer}}
            h = digest(content)
            if h not in seen:
                seen.add(h)
                cards.append(card_obj(h, None, deck, path, start, end, content))
            continue
        if line.startswith("C:"):
            start = i
            cloze_lines = [line[2:].lstrip()]
            i += 1
            while i < len(raw_lines) and not is_marker(raw_lines[i]):
                cloze_lines.append(raw_lines[i])
                i += 1
            end = i - 1 if i > start + 1 else start
            original = trim_block(cloze_lines)
            clozes = extract_clozes(original, path, start + 1)
            text_without_marks = clozes[0]
            spans = clozes[1]
            family_hash = digest({"cloze_family": text_without_marks})
            for span in spans:
                content = {"cloze": {"text": text_without_marks, "start": span[0], "end": span[1]}}
                h = digest(content)
                if h not in seen:
                    seen.add(h)
                    cards.append(card_obj(h, family_hash, deck, path, start, end, content))
            continue
        i += 1
    return cards


def extract_clozes(s, path, line):
    out = []
    spans = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch == "!" and i + 1 < len(s) and s[i + 1] == "[":
            j = s.find("]", i + 2)
            if j != -1:
                out.append(s[i:j + 1])
                i = j + 1
                continue
        if ch == "\\" and i + 1 < len(s):
            out.append(ch)
            out.append(s[i + 1])
            i += 2
            continue
        if ch == "[":
            j = s.find("]", i + 1)
            if j == -1:
                out.append(ch)
                i += 1
                continue
            inner = s[i + 1:j]
            if inner == "":
                out.append(s[i:j + 1])
                i = j + 1
                continue
            prefix = "".join(out)
            start = len(prefix.encode("utf-8"))
            out.append(inner)
            end = start + len(inner.encode("utf-8")) - 1
            spans.append((start, end))
            i = j + 1
            continue
        out.append(ch)
        i += 1
    if not spans:
        raise ParseError("Cloze card must contain at least one cloze deletion.", path, line)
    return "".join(out), spans


def card_obj(h, family_hash, deck, path, start, end, content):
    return {
        "hash": h,
        "familyHash": family_hash,
        "deckName": deck,
        "location": {
            "filePath": str(Path(path).resolve()),
            "lineStart": start,
            "lineEnd": end,
        },
        "content": content,
        "performance": None,
    }


def db_path(root):
    return Path(root).resolve() / DB_NAME


def connect_db(root):
    p = db_path(root)
    if not p.exists():
        return None
    return sqlite3.connect(str(p))


def add_performance(root, cards):
    con = connect_db(root)
    if con is None:
        return []
    rows = {}
    try:
        for row in con.execute(
            "select card_hash, added_at, last_reviewed_at, stability, difficulty, "
            "interval_raw, interval_days, due_date, review_count from cards"
        ):
            rows[row[0]] = row
    except sqlite3.Error:
        return []
    for c in cards:
        row = rows.get(c["hash"])
        if not row:
            continue
        c["performance"] = {
            "addedAt": row[1],
            "lastReviewedAt": row[2],
            "stability": row[3],
            "difficulty": row[4],
            "intervalRaw": row[5],
            "intervalDays": row[6],
            "dueDate": row[7],
            "reviewCount": row[8],
        }
    sessions = []
    try:
        for row in con.execute("select session_id, started_at, ended_at from sessions order by session_id"):
            sessions.append({"sessionId": row[0], "startedAt": row[1], "endedAt": row[2]})
    except sqlite3.Error:
        pass
    return sessions


def count_db_cards(root):
    con = connect_db(root)
    if con is None:
        return 0
    try:
        return int(con.execute("select count(*) from cards").fetchone()[0])
    except sqlite3.Error:
        return 0


def reviewed_today(root):
    con = connect_db(root)
    if con is None:
        return 0
    today = dt.datetime.utcnow().date().isoformat()
    try:
        return int(con.execute("select count(*) from reviews where substr(reviewed_at,1,10)=?", (today,)).fetchone()[0])
    except sqlite3.Error:
        return 0


def tex_macro_count(root):
    root = Path(root)
    count = 0
    for name in ("macros.tex", "preamble.tex"):
        p = root / name
        if p.exists():
            data = p.read_text(encoding="utf-8", errors="ignore")
            count += len(re.findall(r"\\(?:newcommand|def|DeclareMathOperator)\b", data))
            if count == 0:
                count += len([ln for ln in data.splitlines() if ln.strip()])
    return count


def ensure_db(root):
    p = db_path(root)
    con = sqlite3.connect(str(p))
    con.executescript(
        """
        create table if not exists cards (
            card_hash text primary key,
            added_at text not null,
            last_reviewed_at text,
            stability real,
            difficulty real,
            interval_raw real,
            interval_days integer,
            due_date text,
            review_count integer not null
        ) strict;
        create table if not exists sessions (
            session_id integer primary key,
            started_at text not null,
            ended_at text not null
        ) strict;
        create table if not exists reviews (
            review_id integer primary key,
            session_id integer not null references sessions (session_id)
                on update cascade on delete cascade,
            card_hash text not null references cards (card_hash)
                on update cascade on delete cascade,
            reviewed_at text not null,
            grade text not null,
            stability real not null,
            difficulty real not null,
            interval_raw real not null,
            interval_days integer not null,
            due_date text not null
        ) strict;
        """
    )
    con.commit()
    return con


def orphan_hashes(root, cards):
    con = connect_db(root)
    if con is None:
        return []
    live = {c["hash"] for c in cards}
    try:
        db_hashes = [r[0] for r in con.execute("select card_hash from cards order by card_hash")]
    except sqlite3.Error:
        return []
    return [h for h in db_hashes if h not in live]


def cmd_export(args):
    cards = parse_collection(args.directory)
    sessions = add_performance(args.directory, cards)
    payload = {"cards": cards, "sessions": sessions}
    out = json.dumps(payload, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        Path(args.output).write_text(out, encoding="utf-8")
    else:
        sys.stdout.write(out)


def cmd_stats(args):
    cards = parse_collection(args.directory)
    data = {
        "cardsInDeckCount": len(cards),
        "cardsInDbCount": count_db_cards(args.directory),
        "texMacroCount": tex_macro_count(args.directory),
        "cardsReviewedTodayCount": reviewed_today(args.directory),
    }
    if args.format == "json":
        print(json.dumps(data, indent=2))
    else:
        print("HTML output is not implemented yet.")


def cmd_check(args):
    parse_collection(args.directory)
    ensure_db(args.directory).close()
    print("ok")


def cmd_orphans_list(args):
    cards = parse_collection(args.directory)
    for h in orphan_hashes(args.directory, cards):
        print(h)


def cmd_orphans_delete(args):
    cards = parse_collection(args.directory)
    hashes = orphan_hashes(args.directory, cards)
    con = connect_db(args.directory)
    if con is not None:
        for h in hashes:
            con.execute("delete from cards where card_hash=?", (h,))
        con.commit()
    print(f"Deleted {len(hashes)} orphan cards.")


def cmd_drill(args):
    parse_collection(args.directory)
    ensure_db(args.directory).close()
    print(f"Starting server on http://{args.host}:{args.port}")
    print("Drill web interface is not implemented in this reimplementation.")


def build_parser():
    p = argparse.ArgumentParser(description="A plain text-based spaced repetition system.", prog="executable")
    p.add_argument("-V", "--version", action="version", version=VERSION)
    sub = p.add_subparsers(dest="command", metavar="<COMMAND>")

    drill = sub.add_parser("drill", help="Drill cards through a web interface", description="Drill cards through a web interface")
    drill.add_argument("directory", nargs="?", default=".")
    drill.add_argument("--card-limit")
    drill.add_argument("--new-card-limit")
    drill.add_argument("--host", default="127.0.0.1")
    drill.add_argument("--port", default="8000")
    drill.add_argument("--from-deck")
    drill.add_argument("--open-browser", choices=["true", "false"], default="true")
    drill.add_argument("--answer-controls", choices=["full", "binary"], default="full")
    drill.add_argument("--bury-siblings", choices=["true", "false"], default="true")
    drill.set_defaults(func=cmd_drill)

    check = sub.add_parser("check", help="Check the integrity of a collection", description="Check the integrity of a collection")
    check.add_argument("directory", nargs="?", default=".")
    check.set_defaults(func=cmd_check)

    stats = sub.add_parser("stats", help="Print collection statistics", description="Print collection statistics")
    stats.add_argument("directory", nargs="?", default=".")
    stats.add_argument("--format", choices=["html", "json"], default="html")
    stats.set_defaults(func=cmd_stats)

    orphans = sub.add_parser("orphans", help="Commands relating to orphan cards", description="Commands relating to orphan cards")
    osub = orphans.add_subparsers(dest="orphan_command")
    olist = osub.add_parser("list", help="List the hashes of all orphan cards in the collection")
    olist.add_argument("directory", nargs="?", default=".")
    olist.set_defaults(func=cmd_orphans_list)
    odel = osub.add_parser("delete", help="Remove all orphan cards from the database")
    odel.add_argument("directory", nargs="?", default=".")
    odel.set_defaults(func=cmd_orphans_delete)

    exp = sub.add_parser("export", help="Export a collection", description="Export a collection")
    exp.add_argument("directory", nargs="?", default=".")
    exp.add_argument("--output")
    exp.set_defaults(func=cmd_export)
    return p


def main():
    if len(sys.argv) >= 2 and sys.argv[1] in ("--help", "-h"):
        print_main_help(Path(sys.argv[0]).name)
        return 0
    if len(sys.argv) >= 2 and sys.argv[1] in ("--version", "-V"):
        print(VERSION)
        return 0
    if len(sys.argv) >= 2 and sys.argv[1] == "help":
        topic = sys.argv[2:] if len(sys.argv) > 2 else []
        print_help_topic(Path(sys.argv[0]).name, topic)
        return 0
    if any(a in ("--help", "-h") for a in sys.argv[2:]):
        topic = [a for a in sys.argv[1:] if a not in ("--help", "-h")]
        print_help_topic(Path(sys.argv[0]).name, topic)
        return 0
    parser = build_parser()
    args = parser.parse_args()
    if not hasattr(args, "func"):
        parser.print_help()
        return 0
    try:
        args.func(args)
        return 0
    except ParseError as e:
        print(f"hashcards: error: Parse error: {e.message} Location: {Path(e.path).resolve()}:{e.line}", file=sys.stderr)
        return 1
    except BrokenPipeError:
        return 0
    except Exception as e:
        print(f"hashcards: error: {e}", file=sys.stderr)
        return 1


def print_main_help(prog):
    print(f"""A plain text-based spaced repetition system.

Usage: {prog} <COMMAND>

Commands:
  drill    Drill cards through a web interface
  check    Check the integrity of a collection
  stats    Print collection statistics
  orphans  Commands relating to orphan cards
  export   Export a collection
  help     Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version""")


def print_help_topic(prog, topic):
    key = " ".join(topic)
    texts = {
        "drill": f"""Drill cards through a web interface

Usage: {prog} drill [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --card-limit <CARD_LIMIT>
          Maximum number of cards to drill in a session. By default, all cards due today are drilled

      --new-card-limit <NEW_CARD_LIMIT>
          Maximum number of new cards to drill in a session

      --host <HOST>
          The host address to bind to. Default is 127.0.0.1
          
          [default: 127.0.0.1]

      --port <PORT>
          The port to use for the web server. Default is 8000
          
          [default: 8000]

      --from-deck <FROM_DECK>
          Only drill cards from this deck

      --open-browser <OPEN_BROWSER>
          Whether to open the browser automatically. Default is true
          
          [possible values: true, false]

      --answer-controls <ANSWER_CONTROLS>
          Which answer controls to show:

          Possible values:
          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)
          - binary: Show only two rating buttons (Forgot/Good)
          
          [default: full]

      --bury-siblings <BURY_SIBLINGS>
          Whether or not to bury siblings. Default is true
          
          [possible values: true, false]

  -h, --help
          Print help (see a summary with '-h')""",
        "check": f"""Check the integrity of a collection

Usage: {prog} check [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help""",
        "stats": f"""Print collection statistics

Usage: {prog} stats [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]
          Path to the collection directory. By default, the current working directory is used

Options:
      --format <FORMAT>
          Which output format to use

          Possible values:
          - html: HTML output
          - json: JSON output
          
          [default: html]

  -h, --help
          Print help (see a summary with '-h')""",
        "orphans": f"""Commands relating to orphan cards

Usage: {prog} orphans <COMMAND>

Commands:
  list    List the hashes of all orphan cards in the collection
  delete  Remove all orphan cards from the database
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help""",
        "orphans list": f"""List the hashes of all orphan cards in the collection

Usage: {prog} orphans list [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help""",
        "orphans delete": f"""Remove all orphan cards from the database

Usage: {prog} orphans delete [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
  -h, --help  Print help""",
        "export": f"""Export a collection

Usage: {prog} export [OPTIONS] [DIRECTORY]

Arguments:
  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used

Options:
      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout
  -h, --help             Print help""",
    }
    if not topic:
        print_main_help(prog)
    else:
        print(texts.get(key, f"error: unrecognized subcommand '{key}'"))


if __name__ == "__main__":
    raise SystemExit(main())
