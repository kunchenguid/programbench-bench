#!/usr/bin/env python3
import argparse, csv, fnmatch, hashlib, json, math, os, re, stat, sys
from dataclasses import dataclass, field

VERSION = "3.7.0"
BORDER = "─" * 79
BORDER_WIDE = "─" * 109

LANG_LINES = """ABAP (abap)
ABNF (abnf)
ActionScript (as)
Ada (ada,adb,ads,pad)
Agda (agda)
Alchemist (crn)
Alex (x)
Algol 68 (a68)
Alloy (als)
Amber (ab)
Android Interface Definition Language (aidl)
Apex (apex,trigger)
APL (apl,aplf,apln,aplc,dyalog)
AppleScript (applescript)
ArkTs (ets)
Arturo (art)
AsciiDoc (adoc)
ASP (asa,asp)
ASP.NET (asax,ascx,asmx,aspx,master,sitemap,webinfo)
Assembly (s,asm)
Astro (astro)
ATS (dats,sats,ats,hats)
Autoconf (in)
AutoHotKey (ahk)
Avro (avdl,avpr,avsc)
AWK (awk)
BASH (bash,bash_login,bash_logout,bash_profile,bashrc,.bash_login,.bash_logout,.bash_profile,.bashrc)
Basic (bas)
Batch (bat,btm,cmd)
Bazel (bzl,build.bazel,build,workspace)
C (c,ec,pgc)
C Header (h)
C# (cs,csx)
C++ (cc,cpp,cxx,c++,pcc,ino,ccm,cppm,cxxm,c++m,mxx)
C++ Header (hh,hpp,hxx,h++,inl,ipp,ixx,tpp)
Clojure (clj,cljc)
CMake (cmake,cmakelists.txt)
COBOL (cob,cbl,ccp,cobol,cpy)
CoffeeScript (coffee)
Coq (v)
Crystal (cr)
CSS (css)
CSV (csv)
D (d)
Dart (dart)
Dockerfile (dockerfile,dockerfile)
Elixir (ex,exs)
Elm (elm)
Erlang (erl,hrl)
F# (fs,fsi,fsx,fsscript)
Fish (fish)
FORTRAN Legacy (f,for,ftn,f77,pfo)
Fortran Modern (f03,f08,f90,f95)
Go (go)
Go Template (tmpl,gohtml,gotxt)
Gradle (gradle)
GraphQL (graphql)
Groovy (groovy,grt,gtpl,gvy)
Haskell (hs)
HTML (html,htm)
INI (ini)
Java (java)
JavaScript (js,cjs,mjs)
JSON (json)
JSX (jsx)
Julia (jl)
Kotlin (kt,kts)
LaTeX (tex)
LESS (less)
License (license,licence,copying,copying3,unlicense,unlicence,license-apache,licence-apache,license-mit,licence-mit,copyright)
Lua (lua)
m4 (m4)
Makefile (makefile,mak,mk,bp,gnumakefile)
Markdown (md,markdown)
MATLAB (m)
MSBuild (csproj,vbproj,fsproj,vcproj,vcxproj,vcxproj.filters,ilproj,myapp,props,rdlc,resx,settings,sln,targets)
Nim (nim)
Nix (nix)
Objective C (m)
Objective C++ (mm)
OCaml (ml,mli)
Org (org)
Pascal (pas)
Patch (patch)
Perl (pl,plx,pm)
PHP (php)
Plain Text (text,txt)
Powershell (ps1,psm1)
Protocol Buffers (proto)
Python (py,pyw,pyi)
R (r)
Racket (rkt)
Rakefile (rake,rakefile)
Ruby (rb)
Rust (rs)
Sass (sass,scss)
Scala (sc,scala)
Scheme (scm,ss)
Shell (sh)
SQL (sql,dml,ddl,dql)
SVG (svg)
Swift (swift)
Systemd (automount,device,link,mount,path,scope,service,slice,socket,swap,target,timer)
TCL (tcl)
TOML (toml)
TypeScript (ts,tsx,cts,mts)
TypeScript Typings (d.ts)
Vim Script (vim,vimrc,gvimrc,_vimrc,.vimrc,_gvimrc,.gvimrc)
Visual Basic (vb)
Vue (vue)
XML (xml)
YAML (yaml,yml)
Zig (zig)
Zsh (zsh,zshenv,zlogin,zlogout,zprofile,zshrc,.zshenv,.zlogin,zlogout,zprofile,zshrc)"""

def build_maps():
    ext, exact = {}, {}
    for line in LANG_LINES.splitlines():
        if " (" not in line: continue
        name, rest = line.split(" (", 1)
        for e in rest.rstrip(")").split(","):
            e = e.strip()
            if not e: continue
            if "." in e or e in {"makefile","gnumakefile","dockerfile","build","workspace","rakefile"}:
                exact[e.lower()] = name
            ext[e.lower().lstrip(".")] = name
    ext.update({
        "md":"Markdown","markdown":"Markdown","go":"Go","py":"Python","java":"Java",
        "js":"JavaScript","ts":"TypeScript","tsx":"TypeScript","jsx":"JSX","c":"C","h":"C Header",
        "cpp":"C++","cc":"C++","cxx":"C++","hpp":"C++ Header","rs":"Rust","rb":"Ruby",
        "php":"PHP","sh":"Shell","bash":"BASH","zsh":"Zsh","css":"CSS","scss":"Sass",
        "html":"HTML","htm":"HTML","xml":"XML","json":"JSON","yaml":"YAML","yml":"YAML",
        "toml":"TOML","sql":"SQL","txt":"Plain Text","text":"Plain Text","csv":"CSV",
        "makefile":"Makefile","mk":"Makefile","cmake":"CMake","swift":"Swift","kt":"Kotlin",
    })
    exact.update({"readme.md":"Markdown","makefile":"Makefile","gnumakefile":"Makefile","dockerfile":"Dockerfile","license":"License","licence":"License","copying":"License"})
    return ext, exact
EXT_LANG, EXACT_LANG = build_maps()

LINE_COMMENT = {
    "Python":["#"], "Ruby":["#"], "Shell":["#"], "BASH":["#"], "Zsh":["#"], "Makefile":["#"],
    "YAML":["#"], "TOML":["#"], "INI":[";","#"], "Rust":["//"], "Go":["//"], "Java":["//"],
    "JavaScript":["//"], "TypeScript":["//"], "JSX":["//"], "C":["//"], "C Header":["//"],
    "C++":["//"], "C++ Header":["//"], "C#":["//"], "Swift":["//"], "Kotlin":["//"],
    "PHP":["//","#"], "CSS":[], "SQL":["--"], "Lua":["--"], "Haskell":["--"], "R":["#"],
}
BLOCK_COMMENT = {
    "Go":[("/*","*/")], "Rust":[("/*","*/")], "Java":[("/*","*/")], "JavaScript":[("/*","*/")],
    "TypeScript":[("/*","*/")], "JSX":[("/*","*/")], "C":[("/*","*/")], "C Header":[("/*","*/")],
    "C++":[("/*","*/")], "C++ Header":[("/*","*/")], "C#":[("/*","*/")], "Swift":[("/*","*/")],
    "Kotlin":[("/*","*/")], "PHP":[("/*","*/")], "CSS":[("/*","*/")], "HTML":[("<!--","-->")],
    "XML":[("<!--","-->")], "SVG":[("<!--","-->")], "SQL":[("/*","*/")],
    "Python":[('"""','"""'), ("'''","'''")], "Ruby":[("=begin","=end")],
}
COMPLEX_RE = re.compile(r"\b(if|for|while|case|catch|except|elif|else\s+if|switch|foreach|when|unless|and|or)\b|&&|\|\||\?")

@dataclass
class Stat:
    name: str
    bytes: int = 0
    lines: int = 0
    code: int = 0
    comment: int = 0
    blank: int = 0
    complexity: int = 0
    count: int = 0
    files: list = field(default_factory=list)
    ulines: set = field(default_factory=set)

    def obj(self, include_files=False, char=False, dryness=False):
        o = {"Name":self.name,"Bytes":self.bytes,"CodeBytes":0,"Lines":self.lines,"Code":self.code,
             "Comment":self.comment,"Blank":self.blank,"Complexity":self.complexity,"Count":self.count,
             "WeightedComplexity":0,"Files":self.files if include_files else [],"LineLength":None,"ULOC":len(self.ulines) if self.ulines else 0}
        return o

def detect(path, count_as):
    base = os.path.basename(path).lower()
    if base in count_as: return count_as[base]
    if base in EXACT_LANG: return EXACT_LANG[base]
    if base.endswith(".d.ts"): return "TypeScript Typings"
    e = base.rsplit(".", 1)[1] if "." in base else base
    if e in count_as: return count_as[e]
    return EXT_LANG.get(e)

def split_lines(data):
    text = data.decode("utf-8", "replace")
    return text.splitlines()

def strip_strings(s):
    # Rough masking keeps comment markers inside ordinary strings from dominating simple cases.
    return re.sub(r'("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\')', '""', s)

def count_file(path, lang, want_uloc=False, want_char=False):
    data = open(path, "rb").read()
    lines = split_lines(data)
    st = Stat(lang, bytes=len(data), lines=len(lines), count=1)
    in_block = None
    maxlen = total_len = 0
    for line in lines:
        total_len += len(line); maxlen = max(maxlen, len(line))
        raw = line.rstrip("\r")
        stripped = raw.strip()
        if stripped == "":
            st.blank += 1
            continue
        work = strip_strings(raw)
        if in_block:
            st.comment += 1
            end = in_block[1]
            if end in work:
                after = work.split(end,1)[1].strip()
                in_block = None
                if after:
                    st.comment -= 1; st.code += 1
                    st.complexity += complexity(raw, lang)
                    if want_uloc: st.ulines.add(stripped)
            continue
        is_comment = False
        for a,b in BLOCK_COMMENT.get(lang, []):
            pos = work.find(a)
            if pos >= 0:
                before = work[:pos].strip()
                rest = work[pos+len(a):]
                if b not in rest:
                    in_block = (a,b)
                    if before:
                        st.code += 1; st.complexity += complexity(raw, lang)
                        if want_uloc: st.ulines.add(stripped)
                    else:
                        st.comment += 1
                    is_comment = True
                    break
                elif not before and rest.split(b,1)[1].strip()=="":
                    st.comment += 1; is_comment = True; break
        if is_comment: continue
        for marker in LINE_COMMENT.get(lang, []):
            if stripped.startswith(marker):
                st.comment += 1; is_comment = True; break
        if is_comment: continue
        st.code += 1
        st.complexity += complexity(raw, lang)
        if want_uloc: st.ulines.add(stripped)
    if want_char:
        st.line_len = {"Max": maxlen, "Mean": (total_len / len(lines) if lines else 0)}
    return st

def complexity(line, lang):
    if lang in {"Markdown","Plain Text","JSON","YAML","TOML","XML","HTML","CSV","License"}:
        return 0
    return len(COMPLEX_RE.findall(strip_strings(line)))

def parse_csv_list(s):
    if not s: return set()
    out = set()
    for part in s:
        for x in part.split(","):
            x=x.strip().lower().lstrip(".")
            if x: out.add(x)
    return out

def parse_count_as(s):
    out = {}
    if not s: return out
    for item in s.split(","):
        if ":" in item:
            k,v = item.split(":",1)
            lang = EXT_LANG.get(v.lower().strip().strip('"').lstrip("."), v.strip().strip('"'))
            out[k.strip().lower().lstrip(".")] = lang
    return out

def load_ignore(root):
    pats = []
    for name in (".gitignore",".ignore",".sccignore"):
        p = os.path.join(root, name)
        if os.path.exists(p):
            for l in open(p, errors="ignore"):
                l=l.strip()
                if l and not l.startswith("#"): pats.append(l)
    return pats

def ignored(rel, base, pats, exclude_dirs, exclude_files, not_match):
    parts = rel.split(os.sep)
    if any(p in exclude_dirs for p in parts[:-1]): return True
    if os.path.basename(rel) in exclude_files: return True
    if any(re.search(r, rel) for r in not_match): return True
    for pat in pats:
        pp = pat.rstrip("/")
        if fnmatch.fnmatch(rel, pp) or fnmatch.fnmatch(os.path.basename(rel), pp) or rel.startswith(pp + os.sep):
            return True
    return False

def collect(paths, args, count_as):
    files, errors = [], []
    exclude_dirs = set(sum([x.split(",") for x in args.exclude_dir], [])) if args.exclude_dir else {".git",".hg",".svn"}
    exclude_files = {"package-lock.json","Cargo.lock","yarn.lock","pubspec.lock","Podfile.lock","pnpm-lock.yaml"}
    for xs in args.exclude_file:
        exclude_files.update([x for x in xs.split(",") if x])
    include = parse_csv_list(args.include_ext)
    exclude = parse_csv_list(args.exclude_ext)
    for p in paths or ["."]:
        if not os.path.exists(p):
            errors.append(f"file or directory could not be read: {p}")
            continue
        if os.path.isfile(p):
            files.append(p); continue
        root = p
        pats = [] if args.no_gitignore and args.no_ignore and args.no_scc_ignore else load_ignore(root)
        for dirpath, dirnames, filenames in os.walk(root, followlinks=args.include_symlinks):
            rel_dir = os.path.relpath(dirpath, root)
            dirnames[:] = [d for d in dirnames if d not in exclude_dirs and not ignored(os.path.normpath(os.path.join(rel_dir,d)), root, pats, exclude_dirs, exclude_files, args.not_match)]
            for f in filenames:
                full = os.path.join(dirpath, f)
                if os.path.islink(full) and not args.include_symlinks: continue
                rel = os.path.normpath(os.path.join(rel_dir, f)) if rel_dir != "." else f
                if ignored(rel, root, pats, exclude_dirs, exclude_files, args.not_match): continue
                files.append(full)
    out = []
    seen = set()
    for f in files:
        lang = detect(f, count_as)
        if not lang: continue
        ext = os.path.basename(f).lower().rsplit(".",1)[-1] if "." in os.path.basename(f) else os.path.basename(f).lower()
        if include and ext not in include: continue
        if exclude and ext in exclude: continue
        if args.no_duplicates:
            try:
                h = hashlib.sha1(open(f,"rb").read()).hexdigest()
                if h in seen: continue
                seen.add(h)
            except OSError:
                pass
        out.append((f,lang))
    return sorted(out), errors

def aggregate(file_langs, args):
    langs = {}
    byfiles = []
    for path, lang in file_langs:
        try:
            st = count_file(path, lang, args.uloc or args.dryness, args.character)
        except Exception:
            continue
        st.files = [file_obj(path, st)] if args.by_file else []
        byfiles.append((path, st))
        agg = langs.setdefault(lang, Stat(lang))
        agg.bytes += st.bytes; agg.lines += st.lines; agg.code += st.code; agg.comment += st.comment
        agg.blank += st.blank; agg.complexity += st.complexity; agg.count += 1; agg.ulines |= st.ulines
    return langs, byfiles

def file_obj(path, st):
    return {"Name":path,"Bytes":st.bytes,"CodeBytes":0,"Lines":st.lines,"Code":st.code,"Comment":st.comment,"Blank":st.blank,"Complexity":st.complexity,"WeightedComplexity":0,"LineLength":None,"ULOC":len(st.ulines) if st.ulines else 0}

def sorted_stats(langs, sort):
    arr = list(langs.values())
    keymap = {"name":lambda s:s.name.lower(),"files":lambda s:(-s.count,s.name.lower()),"lines":lambda s:(-s.lines,s.name.lower()),"code":lambda s:(-s.code,s.name.lower()),"comments":lambda s:(-s.comment,s.name.lower()),"blanks":lambda s:(-s.blank,s.name.lower()),"complexity":lambda s:(-s.complexity,s.name.lower())}
    return sorted(arr, key=keymap.get(sort, keymap["files"]))

def fmt(n): return f"{int(n):,}"

def table(langs, byfiles, args):
    arr = sorted_stats(langs, args.sort)
    total = Stat("Total")
    for s in arr:
        total.bytes += s.bytes; total.lines += s.lines; total.blank += s.blank; total.comment += s.comment; total.code += s.code; total.complexity += s.complexity; total.count += s.count; total.ulines |= s.ulines
    ascii_border = "-" * (109 if args.wide else 79)
    if args.wide:
        border = ascii_border if args.ci else BORDER_WIDE
        lines = [border, f"{'Language':<34}{'Files':>7}{'Lines':>10}{'Blanks':>9}{'Comments':>10}{'Code':>9}{'Complexity':>11}{'Complexity/Lines':>17}", border]
        for s in arr:
            pct = (s.complexity / s.code * 100) if s.code else 0
            lines.append(f"{s.name[:34]:<34}{fmt(s.count):>7}{fmt(s.lines):>10}{fmt(s.blank):>9}{fmt(s.comment):>10}{fmt(s.code):>9}{fmt(s.complexity):>11}{pct:>17.2f}")
        pct = sum((s.complexity / s.code * 100) if s.code else 0 for s in arr)
        lines += [border, f"{'Total':<34}{fmt(total.count):>7}{fmt(total.lines):>10}{fmt(total.blank):>9}{fmt(total.comment):>10}{fmt(total.code):>9}{fmt(total.complexity):>11}{pct:>17.2f}", border]
    else:
        border = ascii_border if args.ci else BORDER
        lines = [border, f"{'Language':<18}{'Files':>8}{'Lines':>12}{'Blanks':>10}{'Comments':>10}{'Code':>11}{'Complexity':>11}", border]
        bylang = {}
        for p, st in byfiles: bylang.setdefault(st.name, []).append((p, st))
        for s in arr:
            lines.append(f"{s.name[:18]:<18}{fmt(s.count):>8}{fmt(s.lines):>12}{fmt(s.blank):>10}{fmt(s.comment):>10}{fmt(s.code):>11}{fmt(s.complexity):>11}")
            if args.by_file:
                lines.append(border)
                for p, fs in sorted(bylang.get(s.name, [])):
                    lines.append(f"{p[:34]:<34}{fmt(fs.lines):>8}{fmt(fs.blank):>10}{fmt(fs.comment):>10}{fmt(fs.code):>11}{fmt(fs.complexity):>11}")
                lines.append(border)
        lines += [border, f"{'Total':<18}{fmt(total.count):>8}{fmt(total.lines):>12}{fmt(total.blank):>10}{fmt(total.comment):>10}{fmt(total.code):>11}{fmt(total.complexity):>11}", border]
    if not args.no_cocomo:
        cost, sched, people = cocomo(total.code, args)
        kind = args.cocomo_project_type.split(",",1)[0]
        lines += [f"Estimated Cost to Develop ({kind}) {args.currency_symbol}{fmt(round(cost))}", f"Estimated Schedule Effort ({kind}) {sched:.2f} months", f"Estimated People Required ({kind}) {people:.2f}", border]
    if not args.no_size:
        mb = total.bytes / 1000000
        lines += [f"Processed {total.bytes} bytes, {mb:.3f} megabytes (SI)", border]
    if args.no_hborder:
        lines = [l for l in lines if set(l) not in ({"─"}, {"-"})]
    return "\n".join(lines) + "\n"

def cocomo(code, args):
    kloc = max(code, 1) / 1000.0
    typ = args.cocomo_project_type
    vals = {"organic":(2.4,1.05,2.5,0.38), "semi-detached":(3.0,1.12,2.5,0.35), "embedded":(3.6,1.20,2.5,0.32)}
    a,b,c,d = vals.get(typ, vals["organic"])
    effort = a * (kloc ** b) * args.eaf
    sched = c * (effort ** d)
    people = effort / sched if sched else 0
    cost = effort * args.avg_wage / 12.0 * args.overhead
    return cost, sched, people

def emit_csv(langs, args):
    arr = sorted_stats(langs, args.sort)
    import io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(["Language","Lines","Code","Comments","Blanks","Complexity","Bytes","Files","ULOC"])
    for s in arr:
        w.writerow([s.name,s.lines,s.code,s.comment,s.blank,s.complexity,s.bytes,s.count,len(s.ulines) if s.ulines else 0])
    return buf.getvalue()

def emit_yaml(langs, args):
    out = []
    total = Stat("SUM")
    for s in sorted_stats(langs, args.sort):
        out.append(f"{s.name}:")
        out.append(f"  nFiles: {s.count}")
        out.append(f"  blank: {s.blank}")
        out.append(f"  comment: {s.comment}")
        out.append(f"  code: {s.code}")
        total.count += s.count; total.blank += s.blank; total.comment += s.comment; total.code += s.code
    out += ["SUM:", f"  blank: {total.blank}", f"  comment: {total.comment}", f"  code: {total.code}", f"  nFiles: {total.count}"]
    return "\n".join(out) + "\n"

def make_parser():
    p = argparse.ArgumentParser(prog="scc", add_help=False, usage="scc [flags] [files or directories]")
    bools = "binary by-file ci count-ignore debug format-multi-line gen include-symlinks locomo mcp min no-cocomo no-gen no-gitignore no-gitmodule no-hborder no-ignore no-large no-min no-min-gen no-scc-ignore no-size sloccount-format version cost-comparison size-unit-binary size-unit-mixed size-unit-xkcd size-unit-si".split()
    for b in bools:
        p.add_argument("--"+b, action="store_true", dest=b.replace("-","_"))
    p.add_argument("-h", "--help", action="store_true", dest="help")
    p.add_argument("-l", "--languages", action="store_true", dest="languages")
    p.add_argument("-u", "--uloc", action="store_true")
    p.add_argument("-a", "--dryness", action="store_true")
    p.add_argument("-d", "--no-duplicates", action="store_true", dest="no_duplicates")
    p.add_argument("-c", "--no-complexity", action="store_true", dest="no_complexity")
    p.add_argument("-w", "--wide", action="store_true")
    p.add_argument("-m", "--character", action="store_true")
    p.add_argument("-t", "--trace", action="store_true")
    p.add_argument("-v", "--verbose", action="store_true")
    p.add_argument("-p", "--percent", action="store_true")
    p.add_argument("-z", "--min-gen", action="store_true", dest="min_gen")
    p.add_argument("-f", "--format", default="tabular")
    p.add_argument("-o", "--output", default="")
    p.add_argument("-s", "--sort", default="files")
    p.add_argument("-i", "--include-ext", action="append", default=[])
    p.add_argument("-x", "--exclude-ext", action="append", default=[])
    p.add_argument("-n", "--exclude-file", action="append", default=[])
    p.add_argument("-M", "--not-match", action="append", default=[])
    p.add_argument("--exclude-dir", action="append", default=[])
    for name, default, typ in [("avg-wage",56286,int),("directory-walker-job-workers",8,int),("file-gc-count",10000,int),("file-list-queue-size",14,int),("file-process-job-workers",14,int),("file-summary-job-queue-size",14,int),("large-byte-count",1000000,int),("large-line-count",40000,int),("min-gen-line-length",255,int)]:
        p.add_argument("--"+name, default=default, type=typ)
    for name, default in [("cocomo-project-type","organic"),("count-as",""),("currency-symbol","$"),("format-multi",""),("generated-markers",""),("locomo-config",""),("locomo-preset","medium"),("output",""),("remap-all",""),("remap-unknown",""),("size-unit","si"),("sql-project","")]:
        if name != "output": p.add_argument("--"+name, default=default)
    for name, default in [("eaf",1.0),("locomo-cycles",0.0),("locomo-input-price",0.0),("locomo-output-price",0.0),("locomo-review",0.01),("locomo-tps",0.0),("overhead",2.4)]:
        p.add_argument("--"+name, default=default, type=float)
    p.add_argument("paths", nargs="*")
    return p

HELP = """Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.
Version 3.7.0
Ben Boyter <ben@boyter.org> + Contributors

Usage:
  scc [flags] [files or directories]

Flags:
      --avg-wage int                       average wage value used for basic COCOMO calculation (default 56286)
      --binary                             disable binary file detection
      --by-file                            display output for every file
  -m, --character                          calculate max and mean characters per line
      --ci                                 enable CI output settings where stdout is ASCII
      --cocomo-project-type string         change COCOMO model type [organic, semi-detached, embedded, "custom,1,1,1,1"] (default "organic")
      --count-as string                    count extension as language [e.g. jsp:htm,chead:"C Header" maps extension jsp to html and chead to C Header]
      --exclude-dir strings                directories to exclude (default [.git,.hg,.svn])
  -x, --exclude-ext strings                ignore file extensions (overrides include-ext) [comma separated list: e.g. go,java,js]
  -n, --exclude-file strings               ignore files with matching names (default [package-lock.json,Cargo.lock,yarn.lock,pubspec.lock,Podfile.lock,pnpm-lock.yaml])
  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default "tabular")
  -h, --help                               help for scc
  -i, --include-ext strings                limit to file extensions [comma separated list: e.g. go,java,js]
  -l, --languages                          print supported languages and extensions
      --no-cocomo                          remove COCOMO calculation output
  -c, --no-complexity                      skip calculation of code complexity
  -d, --no-duplicates                      remove duplicate files from stats and output
      --no-size                            remove size calculation output
  -o, --output string                      output filename (default stdout)
  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default "files")
  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project
  -v, --verbose                            verbose output
      --version                            version for scc
  -w, --wide                               wider output with additional statistics (implies --complexity)
"""

def main(argv):
    parser = make_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit:
        return 1
    if args.help:
        sys.stdout.write(HELP); return 0
    if args.version:
        print(f"scc version {VERSION}"); return 0
    if args.languages:
        print(LANG_LINES); return 0
    count_as = parse_count_as(args.count_as)
    file_langs, errors = collect(args.paths, args, count_as)
    for e in errors:
        print(e, file=sys.stderr)
    langs, byfiles = aggregate(file_langs, args)
    if args.no_complexity:
        for s in langs.values(): s.complexity = 0
        for _,s in byfiles: s.complexity = 0
    fmtname = args.format
    objs = [s.obj(args.by_file) for s in sorted_stats(langs, args.sort)]
    if fmtname == "wide":
        args.wide = True
        out = table(langs, byfiles, args)
    elif fmtname in ("json","json-stream"):
        out = json.dumps(objs, separators=(",",":"))
    elif fmtname == "json2":
        total = Stat("Total")
        for s in langs.values(): total.code += s.code; total.complexity += s.complexity
        cost, sched, people = cocomo(total.code, args)
        out = json.dumps({"languageSummary":objs,"estimatedCost":cost,"estimatedScheduleMonths":sched,"estimatedPeople":people}, separators=(",",":"))
    elif fmtname in ("csv","csv-stream"):
        out = emit_csv(langs, args)
    elif fmtname == "cloc-yaml":
        out = emit_yaml(langs, args)
    elif fmtname in ("html","html-table"):
        out = "<table>\n" + "\n".join(f"<tr><td>{s.name}</td><td>{s.lines}</td><td>{s.code}</td></tr>" for s in sorted_stats(langs,args.sort)) + "\n</table>\n"
    elif fmtname in ("sql","sql-insert"):
        rows = [f"INSERT INTO t VALUES ('{s.name}',{s.lines},{s.code},{s.comment},{s.blank});" for s in sorted_stats(langs,args.sort)]
        out = ("" if fmtname=="sql-insert" else "CREATE TABLE t (language text, lines int, code int, comments int, blanks int);\n") + "\n".join(rows) + ("\n" if rows else "")
    elif fmtname == "openmetrics":
        out = "".join(f'scc_code{{language="{s.name}"}} {s.code}\n' for s in sorted_stats(langs,args.sort))
    else:
        out = table(langs, byfiles, args)
    if args.output:
        open(args.output, "w").write(out)
    else:
        sys.stdout.write(out)
    return 1 if errors and not file_langs else 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
