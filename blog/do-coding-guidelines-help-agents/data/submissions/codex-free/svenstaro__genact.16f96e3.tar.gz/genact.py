#!/usr/bin/env python3
import os
import random
import re
import shutil
import sys
import time

VERSION = "1.5.1"
MODULES = [
    "ansible", "bootlog", "botnet", "bruteforce", "cargo", "cc", "composer",
    "cryptomining", "docker_build", "docker_image_rm", "download", "julia",
    "kernel_compile", "memdump", "mkinitcpio", "rkhunter", "simcity",
    "terraform", "uv", "weblog", "wpt",
]
SHELLS = ["bash", "elvish", "fish", "powershell", "zsh"]
GREEN = "\033[1;32m"
BOLD = "\033[1m"
RESET = "\033[0m"
YELLOW = "\033[33m"


def usage_name():
    return os.path.basename(sys.argv[0]) or "executable"


def possible(vals):
    return ", ".join(vals)


def err(msg):
    sys.stderr.write(f"error: {msg}\n\nFor more information, try '--help'.\n")
    raise SystemExit(2)


def invalid_value(opt, meta, val, reason=None, vals=None, tip=None):
    s = f"error: invalid value '{val}' for '{opt} <{meta}>'"
    if reason:
        s += f": {reason}"
    s += "\n"
    if vals:
        s += f"  [possible values: {possible(vals)}]\n"
    if tip:
        s += f"\n  tip: a similar value exists: '{tip}'\n"
    s += "\nFor more information, try '--help'.\n"
    sys.stderr.write(s)
    raise SystemExit(2)


def print_help():
    print(f"""A nonsense activity generator

Usage: {usage_name()} [OPTIONS]

Options:
  -l, --list-modules
          List available modules
  -m, --modules <MODULES>
          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,
          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,
          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]
  -s, --speed-factor <SPEED_FACTOR>
          Global speed factor [default: 1]
  -i, --instant-print-lines <INSTANT_PRINT_LINES>
          Instantly print this many lines [default: 0]
      --inhibit
          Keep the computer awake and the display on while genact is running
      --exit-after-time <EXIT_AFTER_TIME>
          Exit after running for this long (format example: 2h10min)
      --exit-after-modules <EXIT_AFTER_MODULES>
          Exit after running this many modules
      --print-completions <shell>
          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,
          zsh]
      --print-manpage
          Generate man page
  -h, --help
          Print help
  -V, --version
          Print version""")


def print_modules():
    print("Available modules:")
    for m in MODULES:
        print(f"  {m}")


def manpage():
    print(r""".ie \n(.g .ds Aq \(aq
.el .ds Aq '
.TH genact 1  "genact 1.5.1" 
.SH NAME
genact \- A nonsense activity generator
.SH SYNOPSIS
\fBgenact\fR [\fB\-l\fR|\fB\-\-list\-modules\fR] [\fB\-m\fR|\fB\-\-modules\fR] [\fB\-s\fR|\fB\-\-speed\-factor\fR] [\fB\-i\fR|\fB\-\-instant\-print\-lines\fR] [\fB\-\-inhibit\fR] [\fB\-\-exit\-after\-time\fR] [\fB\-\-exit\-after\-modules\fR] [\fB\-\-print\-completions\fR] [\fB\-\-print\-manpage\fR] [\fB\-h\fR|\fB\-\-help\fR] [\fB\-V\fR|\fB\-\-version\fR] 
.SH DESCRIPTION
A nonsense activity generator
.SH OPTIONS
.TP
\fB\-l\fR, \fB\-\-list\-modules\fR
List available modules
.TP
\fB\-m\fR, \fB\-\-modules\fR \fI<MODULES>\fR
Run only these modules
.br

.br
\fIPossible values:\fR""")
    print(".RS 14")
    for m in MODULES:
        print(f".IP \\(bu 2\n{m}")
    print(r""".RE
.TP
\fB\-s\fR, \fB\-\-speed\-factor\fR \fI<SPEED_FACTOR>\fR [default: 1]
Global speed factor
.TP
\fB\-i\fR, \fB\-\-instant\-print\-lines\fR \fI<INSTANT_PRINT_LINES>\fR [default: 0]
Instantly print this many lines
.TP
\fB\-\-inhibit\fR
Keep the computer awake and the display on while genact is running
.TP
\fB\-\-exit\-after\-time\fR \fI<EXIT_AFTER_TIME>\fR
Exit after running for this long (format example: 2h10min)
.TP
\fB\-\-exit\-after\-modules\fR \fI<EXIT_AFTER_MODULES>\fR
Exit after running this many modules
.TP
\fB\-\-print\-completions\fR \fI<shell>\fR
Generate completion file for a shell
.br

.br
\fIPossible values:\fR
.RS 14
.IP \(bu 2
bash
.IP \(bu 2
elvish
.IP \(bu 2
fish
.IP \(bu 2
powershell
.IP \(bu 2
zsh
.RE
.TP
\fB\-\-print\-manpage\fR
Generate man page
.TP
\fB\-h\fR, \fB\-\-help\fR
Print help
.TP
\fB\-V\fR, \fB\-\-version\fR
Print version
.SH VERSION
v1.5.1
.SH AUTHORS
Sven\-Hendrik Haase <svenstaro@gmail.com>""")


def completions(shell):
    if shell == "fish":
        print("complete -c genact -s m -l modules -d 'Run only these modules' -r -f -a \"" + "\\n".join(f"{m}\\t''" for m in MODULES) + "\"")
        print("complete -c genact -s s -l speed-factor -d 'Global speed factor' -r")
        print("complete -c genact -s i -l instant-print-lines -d 'Instantly print this many lines' -r")
        print("complete -c genact -l inhibit -d 'Keep the computer awake and the display on while genact is running'")
        print("complete -c genact -l exit-after-time -d 'Exit after running for this long (format example: 2h10min)' -r")
        print("complete -c genact -l exit-after-modules -d 'Exit after running this many modules' -r")
    elif shell == "zsh":
        print("#compdef genact\n\n_genact() {\n    _arguments : \\")
        print("'-m[Run only these modules]:MODULES:(" + " ".join(MODULES) + ")' \\")
        print("'--modules[Run only these modules]:MODULES:(" + " ".join(MODULES) + ")' \\")
        print("'-s[Global speed factor]:SPEED_FACTOR:_default' '--speed-factor[Global speed factor]:SPEED_FACTOR:_default' \\")
        print("'-i[Instantly print this many lines]:INSTANT_PRINT_LINES:_default' '--instant-print-lines[Instantly print this many lines]:INSTANT_PRINT_LINES:_default' \\")
        print("'--inhibit[Keep the computer awake and the display on while genact is running]' '--print-manpage[Generate man page]' '-h[Print help]' '-V[Print version]'\n}\n_genact \"$@\"")
    elif shell == "bash":
        print("_genact() {\n    local cur opts\n    COMPREPLY=()\n    cur=\"${COMP_WORDS[COMP_CWORD]}\"\n    opts=\"-l --list-modules -m --modules -s --speed-factor -i --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage -h --help -V --version\"\n    COMPREPLY=( $(compgen -W \"$opts\" -- \"$cur\") )\n}\ncomplete -F _genact genact")
    elif shell == "elvish":
        print("use builtin;\nuse str;\nset edit:completion:arg-completer[genact] = {|@words|\n  var opts = [ -l --list-modules -m --modules -s --speed-factor -i --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage -h --help -V --version ]\n  put $@opts\n}")
    else:
        print("using namespace System.Management.Automation")
        print("Register-ArgumentCompleter -Native -CommandName 'genact' -ScriptBlock {")
        print("    param($wordToComplete, $commandAst, $cursorPosition)")
        print("    '-l','--list-modules','-m','--modules','-s','--speed-factor','-i','--instant-print-lines','--inhibit','--exit-after-time','--exit-after-modules','--print-completions','--print-manpage','-h','--help','-V','--version' | Where-Object { $_ -like \"$wordToComplete*\" } | ForEach-Object { [CompletionResult]::new($_, $_, [CompletionResultType]::ParameterName, $_) }")
        print("}")


def parse_duration(s):
    if s.isdigit():
        return int(s)
    units = {"h": 3600, "hour": 3600, "hours": 3600, "min": 60, "m": 60, "s": 1, "sec": 1, "second": 1, "seconds": 1}
    pos = 0
    total = 0
    for m in re.finditer(r"(\d+)(hours?|h|min|m|seconds?|sec|s)", s):
        if m.start() != pos:
            return None
        total += int(m.group(1)) * units[m.group(2)]
        pos = m.end()
    return total if pos == len(s) and total > 0 else None


def parse(argv):
    opts = {"modules": [], "speed": 1.0, "instant": 0, "exit_time": None, "exit_modules": None, "inhibit": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print_help(); raise SystemExit(0)
        if a in ("-V", "--version"):
            print(f"genact {VERSION}"); raise SystemExit(0)
        if a in ("-l", "--list-modules"):
            opts["list"] = True; i += 1; continue
        if a == "--print-manpage":
            manpage(); raise SystemExit(0)
        if a == "--inhibit":
            opts["inhibit"] = True; i += 1; continue
        if a in ("-m", "--modules", "-s", "--speed-factor", "-i", "--instant-print-lines", "--exit-after-time", "--exit-after-modules", "--print-completions"):
            if i + 1 >= len(argv):
                err(f"a value is required for '{a} <...>' but none was supplied")
            v = argv[i + 1]
            if a in ("-m", "--modules"):
                if v not in MODULES:
                    invalid_value("--modules", "MODULES", v, vals=MODULES, tip="composer" if "po" in v or v == "nope" else None)
                opts["modules"].append(v)
            elif a in ("-s", "--speed-factor"):
                try:
                    opts["speed"] = float(v)
                except ValueError:
                    invalid_value("--speed-factor", "SPEED_FACTOR", v, "invalid float literal")
            elif a in ("-i", "--instant-print-lines"):
                try:
                    opts["instant"] = int(v)
                except ValueError:
                    invalid_value("--instant-print-lines", "INSTANT_PRINT_LINES", v, "invalid digit found in string")
            elif a == "--exit-after-modules":
                try:
                    opts["exit_modules"] = int(v)
                except ValueError:
                    invalid_value("--exit-after-modules", "EXIT_AFTER_MODULES", v, "invalid digit found in string")
            elif a == "--exit-after-time":
                dur = parse_duration(v)
                if dur is None:
                    invalid_value("--exit-after-time", "EXIT_AFTER_TIME", v)
                opts["exit_time"] = dur
            else:
                if v not in SHELLS:
                    invalid_value("--print-completions", "shell", v, vals=SHELLS, tip="bash" if v == "bad" else None)
                completions(v); raise SystemExit(0)
            i += 2
            continue
        if a.startswith("-"):
            sys.stderr.write(f"error: unexpected argument '{a}' found\n\nUsage: {usage_name()} [OPTIONS]\n\nFor more information, try '--help'.\n")
            raise SystemExit(2)
        sys.stderr.write(f"error: unexpected argument '{a}' found\n\nUsage: {usage_name()} [OPTIONS]\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)
    return opts


WORDS = "adapter analyzer api backend builder cache client compiler controller decoder device driver engine fetcher gateway indexer kernel manager module parser provider renderer scanner scheduler service state storage stream worker".split()
PATHS = ["arch/arm/kernel", "arch/x86/net", "drivers/net/ethernet", "drivers/gpu/drm", "fs/ext4", "kernel/sched", "net/ipv4", "sound/pci", "tools/testing/selftests", "src/lib"]
CRATES = "serde rand clap tokio regex anyhow hyper reqwest chrono rayon log env_logger syn quote libc bytes futures parking_lot crossbeam".split()
PKGS = "symfony/process paragonie/random_compat yiisoft/yii2-faker phpunit/phpunit guzzlehttp/psr7 twig/twig sebastian/diff psr/http-message doctrine/lexer".split()


def rname():
    return random.choice(WORDS) + random.choice(["", "_core", "-sys", "_test", "-cli"])


def line_for(module, n):
    if module == "cargo":
        return f"{GREEN} Downloading{RESET} {random.choice(CRATES)} v{random.randint(0,3)}.{random.randint(0,80)}.{random.randint(0,30)}"
    if module == "cc":
        return f"gcc -c -O3 -Wall -Wextra -Wundef -fPIC -mtune=generic -pipe -I{random.choice(PATHS)} -DDEBUG -DNAMESPACE=lib -o {random.choice(PATHS)}/{rname()}.o"
    if module == "kernel_compile":
        return f"  {random.choice(['CC','AR','LD','AS','HOSTCC','OBJCOPY'])}      {random.choice(PATHS)}/{rname()}.o"
    if module == "composer":
        if n == 0: return "\033[32mLoading composer repositories with package information\033[0m"
        if n == 1: return "\033[32mUpdating dependencies (including require-dev)\033[0m"
        return f"  - Installing \033[32m{random.choice(PKGS)}\033[0m (\033[33m{random.randint(0,60)}.{random.randint(0,20)}.{random.randint(0,60)}\033[0m): Loading from cache"
    if module == "docker_build":
        if n < 8: return f"\rSending build context to Docker daemon  {n * random.uniform(8,25):.2f}MB"
        return f"Step {n-7}/35 : RUN {random.choice(['apt-get update','cargo build --release','uv sync','wget -i downloads.txt','ansible-playbook'])}\n ---> {random.choice(['Using cache', 'Running in ' + ''.join(random.choice('0123456789abcdef') for _ in range(12))])}"
    if module == "docker_image_rm":
        return random.choice(["Untagged", "Deleted"]) + ": sha256:" + "".join(random.choice("0123456789abcdef") for _ in range(64))
    if module == "terraform":
        if n == 0: return "Acquiring state lock. This may take a few moments..."
        res = "aws_" + random.choice(["s3_bucket", "iam_role", "lambda_function", "appsync_type", "vpc_security_group_ingress_rule", "ec2_transit_gateway_vpc_attachment"])
        action = random.choice(["Refreshing state...", "Creating...", "Modifying...", "Destroying...", "Creation complete after 0s", "Still creating... [0s elapsed]"])
        return f"{BOLD}{res}.{rname().replace('-', '_')}: {action}{RESET}"
    if module == "uv":
        return random.choice(["Resolved", "Prepared", "Installed", "Downloaded"]) + f" {random.randint(1,80)} packages in {random.randint(10,900)}ms"
    if module == "weblog":
        return f'{random.choice(["10.0.0.1","192.168.1.42","172.16.3.5"])} - - [01/Jun/2026:10:{random.randint(0,59):02d}:{random.randint(0,59):02d} +0000] "GET /{rname()} HTTP/1.1" {random.choice([200,200,301,404,500])} {random.randint(120,90000)}'
    if module == "download":
        pct = min(100, n * random.randint(2,8))
        return f"Downloading {rname()}.tar.gz [{pct:3d}%] {random.randint(50,9999)} KiB/s"
    if module == "memdump":
        data = " ".join(f"{random.randrange(256):02x}" for _ in range(16))
        asc = "".join(random.choice("abcdefghijklmnopqrstuvwxyz0123456789.") for _ in range(16))
        return f"{n*16:08x}: {data}  |{asc}|"
    if module == "bootlog":
        return random.choice([
            "ACPI: HPET id: 0x8086a301 base: 0xfed00000",
            "CPU0: Thermal monitoring enabled (TM1)",
            "smp: Brought up 1 node, 4 CPUs",
            "clocksource: refined-jiffies: mask: 0xffffffff max_cycles: 0xffffffff",
            "en1: 802.11d country code set to 'US'.",
        ])
    if module == "ansible":
        return random.choice([
            f"TASK [{rname()} : {random.choice(['install packages','template config','restart service','create user'])}]",
            f"ok: [{random.choice(['web01','db01','cache02','worker03'])}]",
            f"changed: [{random.choice(['web01','db01','cache02','worker03'])}]",
        ])
    if module == "bruteforce":
        return f"Trying {random.choice(['root','admin','postgres','oracle'])}@{random.choice(['10.0.0.5','mail.local','db.internal'])} password={rname()} ... {random.choice(['failed','failed','failed','timeout'])}"
    if module == "botnet":
        return f"[{random.randint(1000,9999)}] {random.choice(['Connecting to','Received beacon from','Pushing task to'])} {random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,255)}"
    if module == "cryptomining":
        return f"accepted: {random.randint(1,999)}/{random.randint(1000,9999)} ({random.uniform(20,180):.2f} H/s) diff {random.uniform(0.01,9.99):.3f}"
    if module == "julia":
        return f"Precompiling {random.choice(['DataFrames','Flux','Plots','DifferentialEquations','JuMP'])} [{random.randint(100000,999999)}]"
    if module == "mkinitcpio":
        return f"==> {random.choice(['Building image from preset','Starting build','Generating module dependencies','Creating gzip-compressed initcpio image'])}: {random.choice(['linux','fallback','/boot/initramfs-linux.img'])}"
    if module == "rkhunter":
        return f"Checking {random.choice(['system commands','kernel modules','network interfaces','startup files'])}... {random.choice(['[ OK ]','[ None found ]','[ Warning ]'])}"
    if module == "simcity":
        return f"{random.choice(['Building road','Zoning residential','Dispatching fire department','Collecting taxes'])} at tile ({random.randint(0,128)}, {random.randint(0,128)})"
    if module == "wpt":
        return f"Test {random.choice(['Chrome','Firefox','Edge'])} / {random.choice(['First View','Repeat View'])}: {random.choice(['Running','Uploading results','Waiting in queue'])} ({random.randint(1,9)}/{random.randint(10,20)})"
    return f"{module}: {rname()} {random.choice(['started','running','finished','waiting'])}"


def run_module(module, opts, start):
    count = max(opts["instant"], 60 if opts["exit_modules"] else 10**9)
    delay = 0 if opts["speed"] <= 0 else min(0.2, 0.02 / max(opts["speed"], 0.001))
    for n in range(count):
        if opts["exit_time"] is not None and time.time() - start >= opts["exit_time"]:
            return False
        print(line_for(module, n), flush=True)
        if n >= opts["instant"] and delay:
            time.sleep(delay)
    return True


def main():
    random.seed()
    opts = parse(sys.argv[1:])
    if opts.get("list"):
        print_modules()
        return
    selected = opts["modules"] or MODULES[:]
    start = time.time()
    done = 0
    while True:
        for m in selected:
            if opts["exit_time"] is not None and time.time() - start >= opts["exit_time"]:
                return
            if opts["exit_modules"] is not None and done >= opts["exit_modules"]:
                return
            if not run_module(m, opts, start):
                return
            done += 1
        if opts["exit_modules"] is not None:
            return


if __name__ == "__main__":
    try:
        main()
    except BrokenPipeError:
        try:
            sys.stdout.close()
        finally:
            raise SystemExit(0)
    except KeyboardInterrupt:
        raise SystemExit(0)
