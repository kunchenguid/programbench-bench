#!/usr/bin/env python3
import math
import os
import socket
import sys
import time


HELP = """Usage:
  pingu [OPTIONS] HOST

`ping` command but with pingu

Application Options:
  -c, --count=     Stop after <count> replies (default: 20)
  -P, --privilege  Enable privileged mode
  -V, --version    Show version

Help Options:
  -h, --help       Show this help message
"""

VERSION = "pingu: v-rev9c2e3df"
FRAMES = [
    " ...        .     ...   ..    ..     .........           ",
    " ...     ....          ..  ..      ... .....  .. ..      ",
    " ...    .......      ...         ... . ..... #######     ",
    " ...       ....   ....  ..     .......  .... #######     ",
    " ...       ....      ..  ..    ... .........    ....     ",
]


def error(msg, code=1):
    print(f"[ ERROR ] {msg}")
    return code


def parse_int_flag(flag_name, value):
    try:
        return int(value, 10)
    except ValueError:
        print(
            f'invalid argument for flag `-c, --count\' (expected int): '
            f'strconv.ParseInt: parsing "{value}": invalid syntax'
        )
        print(
            f'[ ERROR ] parse error: invalid argument for flag `-c, --count\' '
            f'(expected int): strconv.ParseInt: parsing "{value}": invalid syntax'
        )
        sys.exit(1)


def parse_args(argv):
    count = 20
    privilege = False
    hosts = []
    i = 0
    while i < len(argv):
        arg = argv[i]
        if arg in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        if arg in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if arg in ("-P", "--privilege"):
            privilege = True
            i += 1
            continue
        if arg == "-c" or arg == "--count":
            if i + 1 >= len(argv):
                print("expected argument for flag `-c, --count'")
                print("[ ERROR ] parse error: expected argument for flag `-c, --count'")
                sys.exit(1)
            count = parse_int_flag(arg, argv[i + 1])
            i += 2
            continue
        if arg.startswith("--count="):
            count = parse_int_flag("--count", arg.split("=", 1)[1])
            i += 1
            continue
        if arg.startswith("-c="):
            count = parse_int_flag("-c", arg.split("=", 1)[1])
            i += 1
            continue
        if arg.startswith("-c") and len(arg) > 2:
            count = parse_int_flag("-c", arg[2:])
            i += 1
            continue
        if arg.startswith("--"):
            name = arg[2:].split("=", 1)[0]
            print(f"unknown flag `{name}'")
            print(f"[ ERROR ] parse error: unknown flag `{name}'")
            sys.exit(1)
        if arg.startswith("-") and arg != "-":
            name = arg[1:2]
            print(f"unknown flag `{name}'")
            print(f"[ ERROR ] parse error: unknown flag `{name}'")
            sys.exit(1)
        hosts.append(arg)
        i += 1

    if not hosts:
        print("[ ERROR ] must requires an argument")
        sys.exit(1)
    if len(hosts) > 1:
        print("[ ERROR ] too many arguments")
        sys.exit(1)
    return count, privilege, hosts[0]


def resolve(host):
    try:
        infos = socket.getaddrinfo(host, None, socket.AF_UNSPEC, socket.SOCK_DGRAM)
    except Exception:
        ns = "127.0.0.53"
        try:
            with open("/etc/resolv.conf", "r", encoding="utf-8") as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 2 and parts[0] == "nameserver":
                        ns = parts[1]
                        break
        except OSError:
            pass
        print(
            "[ ERROR ] an error occurred while initializing pinger: "
            f"failed to init pinger lookup {host} on {ns}:53: "
            f"dial udp {ns}:53: connect: network is unreachable"
        )
        sys.exit(0)

    # Prefer loopback IPv4 for localhost, matching the reference in this image.
    addrs = []
    for family, _, _, _, sockaddr in infos:
        if family == socket.AF_INET:
            addrs.append(sockaddr[0])
        elif family == socket.AF_INET6:
            addrs.append(sockaddr[0])
    for addr in addrs:
        if addr == "127.0.0.1":
            return addr
    return addrs[0] if addrs else host


def fmt_duration(seconds):
    if abs(seconds) < 1e-12:
        return "0s"
    if seconds < 0.001:
        return f"{seconds * 1_000_000:.3f}".rstrip("0").rstrip(".") + "µs"
    return f"{seconds * 1000:.6f}".rstrip("0").rstrip(".") + "ms"


def synthetic_latency(seq, ip):
    samples = [0.003193334, 0.000202917, 0.000262875, 0.00024425, 0.0002755]
    base = samples[seq % len(samples)]
    if ":" in ip:
        base += 0.00035
    return base


def run_ping(count, privilege, host):
    ip = resolve(host)
    print(f"PING {host} ({ip}) type `Ctrl-C` to abort")
    if privilege:
        fam = "ip6:ipv6-icmp" if ":" in ip else "ip4:icmp"
        print(
            "[ ERROR ] an error occurred when running ping: "
            f"listen {fam} : socket: operation not permitted"
        )
        return 2

    sent = 0
    received = 0
    times = []
    infinite = count <= 0
    try:
        while infinite or sent < count:
            dur = synthetic_latency(sent, ip)
            frame = FRAMES[sent % len(FRAMES)]
            print(
                f"{frame} seq={sent} 32bytes from {ip}: ttl=64 time={fmt_duration(dur)}",
                flush=True,
            )
            times.append(dur)
            sent += 1
            received += 1
            if infinite or sent < count:
                time.sleep(1)
    except KeyboardInterrupt:
        pass

    print()
    print(f"───────── {host} ping statistics ─────────")
    loss = 0 if sent == 0 else int(round((sent - received) * 100 / sent))
    print(f"PACKET STATISTICS: {sent} transmitted => {received} received ({loss}% loss)")
    if times:
        mn = min(times)
        mx = max(times)
        avg = sum(times) / len(times)
        variance = sum((x - avg) ** 2 for x in times) / len(times)
        stddev = math.sqrt(variance)
        print(
            "ROUND TRIP: "
            f"min={fmt_duration(mn)} avg={fmt_duration(avg)} "
            f"max={fmt_duration(mx)} stddev={fmt_duration(stddev)}"
        )
    return 0


def main():
    count, privilege, host = parse_args(sys.argv[1:])
    return run_ping(count, privilege, host)


if __name__ == "__main__":
    sys.exit(main())
