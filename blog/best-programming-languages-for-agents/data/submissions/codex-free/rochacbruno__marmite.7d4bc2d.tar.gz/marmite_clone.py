#!/usr/bin/env python3
import argparse
import datetime as dt
import email.utils
import html
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

VERSION = "0.2.7"
DEFAULT_FOOTER = '<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>'

HELP = """Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]

Options:
  -v, --verbose...          Verbosity level (0-4)
  -w, --watch               Detect changes and rebuild the site automatically
      --serve               Serve the site with a built-in HTTP server
      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]
      --init-templates      Initialize templates in the project
      --start-theme <START_THEME>
      --set-theme <SET_THEME>
      --generate-config     Generate the configuration file
      --init-site           Init a new site with sample content and default configuration
      --force               Force the rebuild of the site even if no changes detected
      --shortcodes          List all available shortcodes
      --show-urls           Show all site URLs organized by content type
      --new <NEW>           Create a new post with the given title
  -e                        Edit the file in the default editor
  -p                        Set the new content as a page
  -t <TAGS>                 Set the tags for the new content
      --name <NAME>         Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>   Site tagline
      --url <URL>           Site url
      --https <HTTPS>       Whether to use HTTPS or not
      --footer <FOOTER>     Site footer
      --language <LANGUAGE> Site main language 2 letter code
      --pagination <PAGINATION>
      --enable-search <ENABLE_SEARCH>
      --enable-related-content <ENABLE_RELATED_CONTENT>
      --content-path <CONTENT_PATH>
      --templates-path <TEMPLATES_PATH>
      --static-path <STATIC_PATH>
      --media-path <MEDIA_PATH>
      --default-date-format <DEFAULT_DATE_FORMAT>
      --colorscheme <COLORSCHEME>
      --toc <TOC>
      --json-feed <JSON_FEED>
      --show-next-prev-links <SHOW_NEXT_PREV_LINKS>
      --publish-md <PUBLISH_MD>
      --source-repository <SOURCE_REPOSITORY>
      --image-provider <IMAGE_PROVIDER>
      --theme <THEME>
      --build-sitemap <BUILD_SITEMAP>
      --publish-urls-json <PUBLISH_URLS_JSON>
      --enable-shortcodes <ENABLE_SHORTCODES>
      --shortcode-pattern <SHORTCODE_PATTERN>
      --skip-image-resize <SKIP_IMAGE_RESIZE>
  -h, --help                Print help
  -V, --version             Print version"""

CONFIG_TEMPLATE = """name: Home
tagline: ''
url: ''
https: null
footer: <div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>
language: ''
pagination: 10
pages_title: Pages
tags_title: Tags
tags_content_title: Posts tagged with '$tag'
archives_title: Archive
archives_content_title: Posts from '$year'
streams_title: Streams
streams_content_title: Posts from '$stream'
series_title: Series
series_content_title: Posts from '$series' series
default_author: ''
authors_title: Authors
enable_search: false
enable_related_content: false
search_title: ''
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
card_image: ''
banner_image: ''
logo_image: ''
default_date_format: '%b %e, %Y'
menu:
- - Tags
  - tags.html
- - Archive
  - archive.html
- - Authors
  - authors.html
extra: null
authors: {}
streams: {}
series: {}
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
source_repository: null
image_provider: null
markdown_parser: null
theme: null
file_mapping: []
enable_shortcodes: true
shortcode_pattern: null
build_sitemap: true
publish_urls_json: true
gallery_path: gallery
gallery_create_thumbnails: true
gallery_thumb_size: 50
skip_image_resize: false
"""

def slugify(value):
    value = str(value).strip().lower()
    value = re.sub(r"[^a-z0-9]+", "-", value)
    return value.strip("-") or "untitled"

def truthy(v):
    return str(v).lower() in ("1", "true", "yes", "on")

def clean_scalar(v):
    v = v.strip()
    if (v.startswith("'") and v.endswith("'")) or (v.startswith('"') and v.endswith('"')):
        return v[1:-1]
    if v.lower() == "null":
        return None
    if v.lower() in ("true", "false"):
        return v.lower() == "true"
    if re.fullmatch(r"-?\d+", v):
        return int(v)
    if v.startswith("[") and v.endswith("]"):
        inner = v[1:-1].strip()
        if not inner:
            return []
        return [clean_scalar(x.strip()) for x in inner.split(",")]
    return v

def parse_simple_yaml(path):
    cfg = {}
    if not path.exists():
        return cfg
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line.strip() or line.lstrip().startswith("#") or ":" not in line:
            i += 1
            continue
        key, val = line.split(":", 1)
        key = key.strip()
        val = val.strip()
        if val:
            cfg[key] = clean_scalar(val)
            i += 1
            continue
        arr = []
        j = i + 1
        while j < len(lines) and lines[j].startswith("-"):
            arr.append(lines[j].strip("- ").strip())
            j += 1
        cfg[key] = arr
        i = max(j, i + 1)
    return cfg

def split_frontmatter(text):
    if text.startswith("---\n") or text.startswith("---\r\n"):
        parts = re.split(r"\r?\n---\r?\n", text, maxsplit=1)
        if len(parts) == 2:
            meta = {}
            for line in parts[0].splitlines()[1:]:
                if ":" in line:
                    k, v = line.split(":", 1)
                    meta[k.strip()] = clean_scalar(v.strip())
            return meta, parts[1]
    return {}, text

def parse_date(value, fallback_mtime=None):
    if not value:
        if fallback_mtime:
            return dt.datetime.fromtimestamp(fallback_mtime, dt.timezone.utc)
        return dt.datetime.now(dt.timezone.utc)
    s = str(value).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%Y/%m/%d"):
        try:
            d = dt.datetime.strptime(s[:19], fmt)
            return d.replace(tzinfo=dt.timezone.utc)
        except ValueError:
            pass
    try:
        d = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
        return d if d.tzinfo else d.replace(tzinfo=dt.timezone.utc)
    except ValueError:
        return dt.datetime.now(dt.timezone.utc)

def inline_md(s):
    s = html.escape(s)
    s = re.sub(r"!\[([^\]]*)\]\(([^)]+)\)", r'<img src="\2" alt="\1">', s)
    s = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', s)
    s = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", s)
    s = re.sub(r"\*([^*]+)\*", r"<em>\1</em>", s)
    s = re.sub(r"`([^`]+)`", r"<code>\1</code>", s)
    return s

def markdown_to_html(md):
    out, para, in_ul, in_ol, in_code = [], [], False, False, False
    code_lang = ""
    def flush_para():
        nonlocal para
        if para:
            out.append("<p>" + inline_md(" ".join(para).strip()) + "</p>")
            para = []
    def close_lists():
        nonlocal in_ul, in_ol
        if in_ul:
            out.append("</ul>"); in_ul = False
        if in_ol:
            out.append("</ol>"); in_ol = False
    for raw in md.splitlines():
        line = raw.rstrip()
        if line.startswith("```"):
            if in_code:
                out.append("</code></pre>")
                in_code = False
            else:
                flush_para(); close_lists()
                code_lang = html.escape(line[3:].strip())
                cls = f' class="language-{code_lang}"' if code_lang else ""
                out.append(f"<pre><code{cls}>")
                in_code = True
            continue
        if in_code:
            out.append(html.escape(raw))
            continue
        if not line.strip():
            flush_para(); close_lists(); continue
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush_para(); close_lists()
            level = len(m.group(1)); text = inline_md(m.group(2).strip())
            aid = slugify(re.sub(r"<[^>]+>", "", m.group(2)))
            out.append(f'<h{level}><a href="#{aid}" aria-hidden="true" class="anchor" id="{aid}"></a>{text}</h{level}>')
            continue
        if re.match(r"^\s*[-*+]\s+", line):
            flush_para()
            if not in_ul:
                close_lists(); out.append("<ul>"); in_ul = True
            out.append("<li>" + inline_md(re.sub(r"^\s*[-*+]\s+", "", line)) + "</li>")
            continue
        if re.match(r"^\s*\d+\.\s+", line):
            flush_para()
            if not in_ol:
                close_lists(); out.append("<ol>"); in_ol = True
            out.append("<li>" + inline_md(re.sub(r"^\s*\d+\.\s+", "", line)) + "</li>")
            continue
        if line.startswith(">"):
            flush_para(); close_lists()
            out.append("<blockquote><p>" + inline_md(line.lstrip("> ").strip()) + "</p></blockquote>")
            continue
        para.append(line.strip())
    flush_para(); close_lists()
    if in_code:
        out.append("</code></pre>")
    return "\n".join(out)

def strip_md(md):
    md = re.sub(r"```[\s\S]*?```", "", md)
    md = re.sub(r"!\[[^\]]*\]\([^)]+\)", "", md)
    md = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", md)
    md = re.sub(r"[#*_`>~-]", "", md)
    md = re.sub(r"\n{3,}", "\n\n", md)
    return md.strip()

class Content:
    pass

def discover(input_dir, cfg):
    base = input_dir / str(cfg.get("content_path") or "content")
    if not base.exists():
        base = input_dir
    items = []
    for p in sorted(base.rglob("*.md")):
        if p.name.startswith("_"):
            continue
        text = p.read_text(encoding="utf-8", errors="replace")
        meta, body = split_frontmatter(text)
        c = Content()
        c.path = p; c.body = body; c.meta = meta
        title = meta.get("title")
        if not title:
            h = re.search(r"^#\s+(.+)$", body, re.M)
            title = h.group(1).strip() if h else p.stem
        c.title = str(title)
        c.slug = slugify(meta.get("slug") or title)
        c.url = f"/{c.slug}.html"
        c.file = f"{c.slug}.html"
        c.date = parse_date(meta.get("date"), p.stat().st_mtime)
        c.tags = parse_list(meta.get("tags"))
        c.authors = parse_list(meta.get("authors") or meta.get("author") or cfg.get("default_author"))
        c.series = str(meta.get("series") or "").strip()
        c.stream = str(meta.get("stream") or "").strip()
        c.page = truthy(meta.get("page", False)) or truthy(meta.get("is_page", False))
        c.description = str(meta.get("description") or strip_md(body))[:300]
        c.html = markdown_to_html(body)
        items.append(c)
    items.sort(key=lambda x: x.date, reverse=True)
    return items

def parse_list(v):
    if not v:
        return []
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    return [x.strip() for x in str(v).split(",") if x.strip()]

def base_path(cfg):
    url = str(cfg.get("url") or "")
    if not url:
        return ""
    path = urlparse(url).path.rstrip("/")
    return path

def href(path, cfg):
    bp = base_path(cfg)
    if path.startswith("/"):
        return bp + path
    return bp + "/" + path

def page_shell(title, body, cfg, description="", kind="website"):
    name = html.escape(str(cfg.get("name") or "Home"))
    lang = html.escape(str(cfg.get("language") or "en") or "en")
    tagline = html.escape(str(cfg.get("tagline") or ""))
    full_title = name if title == str(cfg.get("name") or "Home") else f"{html.escape(title)} | {name}"
    search = ""
    if cfg.get("enable_search") is True:
        search = '<li><a href="#" id="search-toggle" class="secondary" title="Search (Ctrl + Shift + F)"> <span class="search-txt">Search</span><span class="search-magnifier"></span></a></li>'
    return f"""<!DOCTYPE html>
<html lang="{lang}">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="{href('/static/favicon.ico', cfg)}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark" />
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="{html.escape(title)}">
    <meta property="og:description" content="{html.escape(description)}">
    <meta property="og:type" content="{kind}">
    <meta property="og:site_name" content="{name}">
    <title>{full_title}</title>
    <link rel="stylesheet" type="text/css" href="{href('/static/pico.min.css', cfg)}">
    <link rel="stylesheet" type="text/css" href="{href('/static/marmite.css', cfg)}">
    <link rel="stylesheet" type="text/css" href="{href('/static/custom.css', cfg)}">
</head>
<body>
<main class="container">
<header class="header-content"><nav class="header-nav"><ul class="header-name"><li><hgroup class="h-card"><h2><a href="{href('/', cfg)}" class="contrast p-name u-url">{name}</a></h2><p>{tagline}</p></hgroup></li></ul><ul class="header-menu"><li><a class="menu-item secondary" href="{href('/tags.html', cfg)}">Tags</a></li><li><a class="menu-item secondary" href="{href('/archive.html', cfg)}">Archive</a></li><li><a class="menu-item secondary" href="{href('/authors.html', cfg)}">Authors</a></li>{search}</ul></nav></header>
<section class="main-content">
{body}
</section>
<footer class="footer-content grid">{cfg.get('footer') or DEFAULT_FOOTER}</footer>
</main>
<script src="{href('/static/marmite.js', cfg)}"></script>
<script src="{href('/static/custom.js', cfg)}"></script>
</body>
</html>
"""

def date_text(d):
    return d.strftime("%b %e, %Y") if sys.platform != "win32" else d.strftime("%b %d, %Y").replace(" 0", "  ")

def content_list(items, cfg, heading=None):
    chunks = []
    if heading:
        chunks.append(f'<h1 class="list-title">{html.escape(heading)}</h1>')
    chunks.append('<div class="content-list h-feed">')
    for c in items:
        tags = "".join(f'<li><a href="{href("/tag-"+slugify(t)+".html", cfg)}" class="p-category">{html.escape(t)}</a></li>' for t in c.tags)
        chunks.append(f"""<article class="content-list-item h-entry">
<h2 class="p-name" style="display: none;">{html.escape(c.title)}</h2>
<a class="u-url" href="{href(c.url, cfg)}" style="display: none;"></a>
<time class="dt-published" datetime="{c.date.isoformat()}" style="display: none;">{date_text(c.date)}</time>
<div class="content-title-wrapper"><h2 class="content-title"><a href="{href(c.url, cfg)}">{html.escape(c.title)}</a></h2></div>
<p class="content-excerpt p-summary">{html.escape(c.description)} <a class="secondary" href="{href(c.url, cfg)}">read more &rarr;</a></p>
<footer class="data-tags-footer"><span class="content-date"><a class="secondary" href="{href(c.url, cfg)}">{date_text(c.date)}</a></span><ul class="content-tags overflow-auto">{tags}</ul></footer>
</article>""")
    chunks.append("</div>")
    return "\n".join(chunks)

def write_static(out):
    s = out / "static"; s.mkdir(parents=True, exist_ok=True)
    files = {
        "pico.min.css": "body{font-family:system-ui,sans-serif;max-width:70rem;margin:auto;padding:1rem}a{color:#2563eb}.container{width:100%}",
        "marmite.css": ".header-nav{display:flex;justify-content:space-between;gap:1rem}.header-menu,.content-tags{display:flex;gap:.75rem;list-style:none}.content-html img{max-width:100%}",
        "custom.css": "",
        "marmite.js": "",
        "custom.js": "",
        "search.js": "",
        "robots.txt": "User-agent: *\nAllow: /\n",
        "favicon.ico": "",
        "logo.png": "",
        "avatar-placeholder.png": "",
    }
    for name, data in files.items():
        (s / name).write_text(data, encoding="utf-8")

def rss(path, title, items, cfg):
    site = str(cfg.get("url") or "")
    rows = []
    for c in items:
        rows.append(f"<item><title>{html.escape(c.title)}</title><link>{html.escape(site + c.url)}</link><description>{html.escape(c.description)}</description><pubDate>{email.utils.format_datetime(c.date)}</pubDate></item>")
    path.write_text(f'<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>{html.escape(title)}</title><link>{html.escape(site)}</link>{"".join(rows)}</channel></rss>', encoding="utf-8")

def generate(input_dir, output_dir, cfg):
    t0 = time.time()
    output_dir.mkdir(parents=True, exist_ok=True)
    write_static(output_dir)
    items = discover(input_dir, cfg)
    posts = [x for x in items if not x.page]
    pages = [x for x in items if x.page]
    for c in items:
        tag_html = "".join(f'<li><a href="{href("/tag-"+slugify(t)+".html", cfg)}" class="p-category">{html.escape(t)}</a></li>' for t in c.tags)
        authors = ", ".join(html.escape(a) for a in c.authors)
        body = f"""<article class="h-entry">
<data class="p-name" value="{html.escape(c.title)}"></data>
<a class="u-url" href="{href(c.url, cfg)}" style="display: none;"></a>
<time class="dt-published" datetime="{c.date.isoformat()}" style="display: none;">{date_text(c.date)}</time>
<div class="content-html e-content">{c.html}</div>
<footer class="data-tags-footer"><div class="content-authors-full">{authors}</div><span class="content-date"><small> {date_text(c.date)} - &#10710; 1 min</small></span><ul class="content-tags">{tag_html}</ul></footer>
</article>"""
        (output_dir / c.file).write_text(page_shell(c.title, body, cfg, c.description, "article"), encoding="utf-8")
        if cfg.get("publish_md") is True:
            shutil.copyfile(c.path, output_dir / (c.slug + ".md"))
    (output_dir / "index.html").write_text(page_shell(str(cfg.get("name") or "Home"), content_list(posts, cfg), cfg), encoding="utf-8")
    (output_dir / "index-1.html").write_text((output_dir / "index.html").read_text(encoding="utf-8"), encoding="utf-8")
    (output_dir / "pages.html").write_text(page_shell(str(cfg.get("pages_title") or "Pages"), content_list(pages, cfg, str(cfg.get("pages_title") or "Pages")), cfg), encoding="utf-8")
    (output_dir / "pages-1.html").write_text((output_dir / "pages.html").read_text(encoding="utf-8"), encoding="utf-8")
    all_tags = sorted({t for c in posts for t in c.tags}, key=str.lower)
    tag_links = [f'<li><a href="{href("/tag-"+slugify(t)+".html", cfg)}">{html.escape(t)}</a></li>' for t in all_tags]
    (output_dir / "tags.html").write_text(page_shell(str(cfg.get("tags_title") or "Tags"), "<h1>Tags</h1><ul>" + "".join(tag_links) + "</ul>", cfg), encoding="utf-8")
    for tag in all_tags:
        subset = [c for c in posts if tag in c.tags]
        name = "tag-" + slugify(tag)
        html_body = content_list(subset, cfg, str(cfg.get("tags_content_title") or "Posts tagged with '$tag'").replace("$tag", tag))
        (output_dir / f"{name}.html").write_text(page_shell(tag, html_body, cfg), encoding="utf-8")
        (output_dir / f"{name}-1.html").write_text((output_dir / f"{name}.html").read_text(encoding="utf-8"), encoding="utf-8")
        rss(output_dir / f"{name}.rss", f"tag: {tag}", subset, cfg)
    years = sorted({c.date.year for c in posts}, reverse=True)
    arch = ["<h1>Archive</h1><ul>"]
    for y in years:
        arch.append(f'<li><a href="{href("/archive-"+str(y)+".html", cfg)}">{y}</a></li>')
        subset = [c for c in posts if c.date.year == y]
        (output_dir / f"archive-{y}.html").write_text(page_shell(f"Posts from '{y}'", content_list(subset, cfg, f"Posts from '{y}'"), cfg), encoding="utf-8")
        (output_dir / f"archive-{y}-1.html").write_text((output_dir / f"archive-{y}.html").read_text(encoding="utf-8"), encoding="utf-8")
        rss(output_dir / f"archive-{y}.rss", f"year: {y}", subset, cfg)
    arch.append("</ul>")
    (output_dir / "archive.html").write_text(page_shell(str(cfg.get("archives_title") or "Archive"), "".join(arch), cfg), encoding="utf-8")
    authors = sorted({a for c in posts for a in c.authors if a}, key=str.lower)
    (output_dir / "authors.html").write_text(page_shell(str(cfg.get("authors_title") or "Authors"), "<h1>Authors</h1><ul>" + "".join(f'<li><a href="{href("/author-"+slugify(a)+".html", cfg)}">{html.escape(a)}</a></li>' for a in authors) + "</ul>", cfg), encoding="utf-8")
    for a in authors:
        subset = [c for c in posts if a in c.authors]
        name = "author-" + slugify(a)
        (output_dir / f"{name}.html").write_text(page_shell(a, content_list(subset, cfg, a), cfg), encoding="utf-8")
        (output_dir / f"{name}-1.html").write_text((output_dir / f"{name}.html").read_text(encoding="utf-8"), encoding="utf-8")
        rss(output_dir / f"{name}.rss", f"author: {a}", subset, cfg)
    for fname, title in [("streams.html", "Streams"), ("series.html", "Series"), ("404.html", "Page not found")]:
        (output_dir / fname).write_text(page_shell(title, f"<h1>{title}</h1>", cfg), encoding="utf-8")
    rss(output_dir / "index.rss", "index", posts, cfg)
    urls = build_urls(posts, pages, all_tags, years, authors)
    if cfg.get("publish_urls_json", True) is not False:
        (output_dir / "urls.json").write_text(json.dumps(urls, indent=2), encoding="utf-8")
    (output_dir / "marmite.json").write_text(json.dumps({"marmite_version": VERSION, "posts": len(posts), "pages": len(pages), "generated_at": str(dt.datetime.now(dt.timezone.utc)), "timestamp": int(time.time()), "elapsed_time": time.time()-t0, "config": cfg}, indent=2, default=str), encoding="utf-8")
    locs = ["/index.html"] + [c.url for c in items]
    (output_dir / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?><urlset>' + "".join(f"<url><loc>{html.escape(str(cfg.get('url') or '') + u)}</loc></url>" for u in locs) + "</urlset>", encoding="utf-8")
    (output_dir / "robots.txt").write_text("User-agent: *\nAllow: /\nSitemap: /sitemap.xml\n", encoding="utf-8")
    return urls

def build_urls(posts, pages, tags, years, authors):
    feeds = ["/index.rss"] + [f"/tag-{slugify(t)}.rss" for t in tags] + [f"/archive-{y}.rss" for y in years] + [f"/author-{slugify(a)}.rss" for a in authors]
    pagination = ["/index-1.html"] + [f"/tag-{slugify(t)}-1.html" for t in tags] + [f"/archive-{y}-1.html" for y in years] + [f"/author-{slugify(a)}-1.html" for a in authors]
    data = {
        "posts": [c.url for c in posts],
        "pages": [c.url for c in pages],
        "tags": [f"/tag-{slugify(t)}.html" for t in tags] + ["/tags.html"],
        "authors": [f"/author-{slugify(a)}.html" for a in authors] + (["/authors.html"] if authors else []),
        "series": [],
        "streams": ["/streams.html"],
        "archives": [f"/archive-{y}.html" for y in years] + ["/archive.html"],
        "feeds": feeds,
        "pagination": pagination,
        "file_mappings": [],
        "misc": ["/index.html"],
    }
    summary = {k: len(v) for k, v in data.items()}
    summary["total"] = sum(summary.values())
    summary["meta"] = {"url": "", "absolute_urls": False}
    data["summary"] = summary
    return data

def generate_config(input_dir):
    input_dir.mkdir(parents=True, exist_ok=True)
    path = input_dir / "marmite.yaml"
    path.write_text(CONFIG_TEMPLATE, encoding="utf-8")
    print(f"Config file generated: {path}")

def init_site(input_dir):
    generate_config(input_dir)
    content = input_dir / "content"
    content.mkdir(parents=True, exist_ok=True)
    today = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
    samples = {
        f"{today}-welcome.md": f"---\ntitle: Welcome\ndate: {today}\ntags: marmite\n---\n# Welcome\n\nThis is your first Marmite post.\n",
        "about.md": "---\ntitle: About\npage: true\n---\n# About\n\nWrite about this site.\n",
        "_404.md": "# Page not found\n",
        "_announce.md": "",
        "_comments.md": "",
        "_hero.md": "",
        "_markdown_footer.md": "",
        "_markdown_header.md": "",
        "_references.md": "",
        "_sidebar.example.md": "",
    }
    for name, data in samples.items():
        (content / name).write_text(data, encoding="utf-8")
    (input_dir / "custom.css").write_text("", encoding="utf-8")
    (input_dir / "custom.js").write_text("", encoding="utf-8")
    print(f"Site initialized in {input_dir}")

def new_content(input_dir, title, tags="", page=False):
    input_dir.mkdir(parents=True, exist_ok=True)
    prefix = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d-%H-%M-%S")
    path = input_dir / f"{prefix}-{slugify(title)}.md"
    front = "---\n"
    if page:
        front += "page: true\n"
    if tags:
        front += f"tags: {tags}\n"
    front += "---\n"
    path.write_text(front + f"# {title}\n", encoding="utf-8")
    print(path)

def shortcodes():
    print("""Available shortcodes:
  youtube      Embed a YouTube video
  vimeo        Embed a Vimeo video
  gist         Embed a GitHub gist
  image        Render an image
  gallery      Render a gallery
  toc          Table of contents""")

def parse_args(argv):
    if not argv or "--help" in argv or "-h" in argv:
        print(HELP)
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print(f"marmite {VERSION}")
        raise SystemExit(0)
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("input_folder", nargs="?")
    p.add_argument("output_folder", nargs="?")
    p.add_argument("-v", "--verbose", action="count", default=0)
    p.add_argument("-w", "--watch", action="store_true")
    p.add_argument("--serve", action="store_true")
    p.add_argument("--bind", default="0.0.0.0:8000")
    p.add_argument("-c", "--config", default="marmite.yaml")
    p.add_argument("--init-templates", action="store_true")
    p.add_argument("--start-theme")
    p.add_argument("--set-theme")
    p.add_argument("--generate-config", action="store_true")
    p.add_argument("--init-site", action="store_true")
    p.add_argument("--force", action="store_true")
    p.add_argument("--shortcodes", action="store_true")
    p.add_argument("--show-urls", action="store_true")
    p.add_argument("--new")
    p.add_argument("-e", action="store_true")
    p.add_argument("-p", action="store_true")
    p.add_argument("-t", dest="tags", default="")
    for name in ["name","tagline","url","https","footer","language","pagination","enable-search","enable-related-content","content-path","templates-path","static-path","media-path","default-date-format","colorscheme","toc","json-feed","show-next-prev-links","publish-md","source-repository","image-provider","theme","build-sitemap","publish-urls-json","enable-shortcodes","shortcode-pattern","skip-image-resize"]:
        p.add_argument("--" + name)
    ns, _ = p.parse_known_args(argv)
    if not ns.input_folder:
        print("error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.", file=sys.stderr)
        raise SystemExit(2)
    return ns

def main(argv):
    ns = parse_args(argv)
    input_dir = Path(ns.input_folder)
    if ns.shortcodes:
        shortcodes(); return
    if ns.generate_config:
        generate_config(input_dir); return
    if ns.init_site:
        init_site(input_dir); return
    if ns.new:
        new_content(input_dir, ns.new, ns.tags, ns.p); return
    if ns.init_templates:
        (input_dir / "templates").mkdir(parents=True, exist_ok=True)
        print(f"Templates initialized in {input_dir / 'templates'}")
        return
    cfg = {
        "name": "Home", "tagline": "", "url": "", "https": None, "footer": DEFAULT_FOOTER,
        "language": "en", "pagination": 10, "pages_title": "Pages", "tags_title": "Tags",
        "tags_content_title": "Posts tagged with '$tag'", "archives_title": "Archive",
        "archives_content_title": "Posts from '$year'", "streams_title": "Streams",
        "series_title": "Series", "default_author": "", "authors_title": "Authors",
        "enable_search": False, "enable_related_content": True, "content_path": "content",
        "templates_path": "templates", "static_path": "static", "media_path": "media",
        "default_date_format": "%b %e, %Y", "toc": False, "json_feed": False,
        "show_next_prev_links": True, "publish_md": False, "build_sitemap": True,
        "publish_urls_json": True, "enable_shortcodes": True, "skip_image_resize": False,
    }
    cfg.update(parse_simple_yaml(input_dir / ns.config))
    for k, v in vars(ns).items():
        key = k.replace("-", "_")
        if v is not None and key in cfg and k not in ("input_folder", "output_folder"):
            if isinstance(cfg[key], bool):
                cfg[key] = truthy(v)
            elif isinstance(cfg[key], int):
                try: cfg[key] = int(v)
                except Exception: cfg[key] = v
            else:
                cfg[key] = v
    out = Path(ns.output_folder) if ns.output_folder else input_dir / "site"
    urls = generate(input_dir, out, cfg)
    if ns.show_urls:
        print(json.dumps(urls, indent=2))
    if ns.serve:
        print(f"Serving {out} at http://{ns.bind}")
    else:
        print(f"Site generated at {out}/")

if __name__ == "__main__":
    main(sys.argv[1:])
