#!/usr/bin/env python3
import sys
import unicodedata

VERSION = "grex 1.4.6"
HELP = r"""grex 1.4.6
© 2019-today Peter M. Stahl <pemistahl@gmail.com>
Licensed under the Apache License, Version 2.0
Downloadable from https://crates.io/crates/grex
Source code at https://github.com/pemistahl/grex

grex generates regular expressions from user-provided test cases.

Usage: grex [OPTIONS] {INPUT...|--file <FILE>}

Input:
  [INPUT]...
          One or more test cases separated by blank space
          
          Use a hyphen `-` to read test cases from standard input.
          
          Conflicts with --file.

  -f, --file <FILE>
          Reads test cases on separate lines from a file.
          
          Lines may be ended with either a newline `\n` or a carriage return with a line feed
          `\r\n`. The final line ending is optional.
          
          Use a hyphen `-` to read the filename from standard input.
          
          Conflicts with INPUT...

Digit Options:
  -d, --digits
          Converts any Unicode decimal digit to \d.

  -D, --non-digits
          Converts any character which is not a Unicode decimal digit to \D.

Whitespace Options:
  -s, --spaces
          Converts any Unicode whitespace character to \s.

  -S, --non-spaces
          Converts any character which is not a Unicode whitespace character to \S

Word Options:
  -w, --words
          Converts any Unicode word character to \w.

  -W, --non-words
          Converts any character which is not a Unicode word character to \W.

Escaping Options:
  -e, --escape
          Replaces all non-ASCII characters with unicode escape sequences

      --with-surrogates
          Converts astral code points to surrogate pairs if --escape is set

Repetition Options:
  -r, --repetitions
          Detects repeated non-overlapping substrings and converts them to {min,max} quantifier
          notation

      --min-repetitions <QUANTITY>
          Specifies the minimum quantity of substring repetitions to be converted if --repetitions
          is set
          
          [default: 1]

      --min-substring-length <LENGTH>
          Specifies the minimum length a repeated substring must have in order to be converted if
          --repetitions is set
          
          [default: 1]

Anchor Options:
      --no-start-anchor
          Removes the caret anchor `^` from the resulting regular expression.

      --no-end-anchor
          Removes the dollar sign anchor `$` from the resulting regular expression.

      --no-anchors
          Removes the caret and dollar sign anchors from the resulting regular expression.

Display Options:
  -x, --verbose
          Produces a nicer-looking regular expression in verbose mode

  -c, --colorize
          Provides syntax highlighting for the resulting regular expression

Miscellaneous Options:
  -i, --ignore-case
          Performs case-insensitive matching, letters match both upper and lower case

  -g, --capture-groups
          Replaces non-capturing groups with capturing ones

  -h, --help
          Prints help information

  -v, --version
          Prints version information"""


class Opt:
    def __init__(self):
        self.d = self.D = self.s = self.S = self.w = self.W = False
        self.escape = self.sur = self.rep = False
        self.min_rep = 1
        self.min_len = 1
        self.start = True
        self.end = True
        self.ignore = False
        self.capture = False
        self.verbose = False
        self.color = False
        self.file = None


def die(msg, code=2):
    print(msg, file=sys.stderr)
    sys.exit(code)


def parse(argv):
    o = Opt()
    inputs = []
    i = 0
    positional = False
    while i < len(argv):
        a = argv[i]
        if positional:
            inputs.append(a)
            i += 1
            continue
        if a == "--":
            positional = True
            i += 1
        elif a in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        elif a in ("-v", "--version"):
            print(VERSION)
            sys.exit(0)
        elif a in ("-f", "--file"):
            if i + 1 >= len(argv): die("error: a value is required for '--file <FILE>' but none was supplied")
            o.file = argv[i + 1]; i += 2
        elif a == "--with-surrogates":
            o.sur = True; i += 1
        elif a == "--min-repetitions":
            if i + 1 >= len(argv): die("error: a value is required for '--min-repetitions <QUANTITY>' but none was supplied")
            o.min_rep = int(argv[i + 1]); i += 2
        elif a == "--min-substring-length":
            if i + 1 >= len(argv): die("error: a value is required for '--min-substring-length <LENGTH>' but none was supplied")
            o.min_len = int(argv[i + 1]); i += 2
        elif a == "--no-start-anchor":
            o.start = False; i += 1
        elif a == "--no-end-anchor":
            o.end = False; i += 1
        elif a == "--no-anchors":
            o.start = o.end = False; i += 1
        elif a.startswith("--"):
            die(f"error: unexpected argument '{a}' found")
        elif a.startswith("-") and a != "-":
            for ch in a[1:]:
                if ch == "d": o.d = True
                elif ch == "D": o.D = True
                elif ch == "s": o.s = True
                elif ch == "S": o.S = True
                elif ch == "w": o.w = True
                elif ch == "W": o.W = True
                elif ch == "e": o.escape = True
                elif ch == "r": o.rep = True
                elif ch == "i": o.ignore = True
                elif ch == "g": o.capture = True
                elif ch == "x": o.verbose = True
                elif ch == "c": o.color = True
                elif ch in "hv":
                    pass
                else:
                    die(f"error: unexpected argument '-{ch}' found")
            i += 1
        else:
            positional = True
            inputs.extend(argv[i:])
            break
    if o.file and inputs:
        die("error: the argument '--file <FILE>' cannot be used with '[INPUT]...'")
    return o, inputs


def read_cases(o, inputs):
    if o.file is not None:
        fn = sys.stdin.read().strip() if o.file == "-" else o.file
        try:
            data = open(fn, "r", encoding="utf-8").read()
        except Exception as e:
            die(f"Error: {e}", 1)
        return data.splitlines()
    if not inputs:
        die("error: the following required arguments were not provided:\n  <INPUT>...")
    if len(inputs) == 1 and inputs[0] == "-":
        return sys.stdin.read().splitlines()
    return inputs


def graphemes(s):
    out = []
    for ch in s:
        if out and unicodedata.combining(ch):
            out[-1] += ch
        else:
            out.append(ch)
    return out


def is_word(g):
    return all((c == "_" or c.isalnum() or unicodedata.combining(c)) for c in g)


def lit_char(c, in_class=False):
    if in_class:
        if c in r"\-]^":
            return "\\" + c
        return c
    if c in r"\-.^$|?*+()[]{}":
        return "\\" + c
    return c


def escape_non_ascii(g, sur):
    res = ""
    for c in g:
        cp = ord(c)
        if cp < 128:
            res += lit_char(c)
        elif sur and cp > 0xFFFF:
            cp -= 0x10000
            hi = 0xD800 + (cp >> 10)
            lo = 0xDC00 + (cp & 0x3FF)
            res += f"\\u{{{hi:x}}}\\u{{{lo:x}}}"
        else:
            res += f"\\u{{{cp:x}}}"
    return res


def atom(g, o):
    if o.d and all(c.isdecimal() for c in g): return r"\d"
    if o.s and all(c.isspace() for c in g): return r"\s"
    if o.w and is_word(g): return r"\w"
    if o.D and not all(c.isdecimal() for c in g): return r"\D"
    if o.W and not is_word(g): return r"\W"
    if o.S and not all(c.isspace() for c in g): return r"\S"
    return escape_non_ascii(g, o.sur) if o.escape else "".join(lit_char(c) for c in g)


def tokenize(s, o):
    return [atom(g, o) for g in graphemes(s)]


def group(s, o):
    return ("(" if o.capture else "(?:") + s + ")"


def quant(base, q, o):
    if q == 1:
        return base
    b = base if is_quant_atom(base) else group(base, o)
    return f"{b}{{{q}}}"


def is_simple_atom(s):
    if len(s) == 1 and s not in "|()[]{}?*+":
        return True
    if s.startswith(r"\u{") and s.endswith("}") and s.count(r"\u{") == 1:
        return True
    if s.startswith("[") and s.endswith("]"):
        return True
    if s.startswith("\\") and len(s) == 2 and s not in (r"\d", r"\D", r"\s", r"\S", r"\w", r"\W"):
        return True
    return False


def is_quant_atom(s):
    return is_simple_atom(s) or s in (r"\d", r"\D", r"\s", r"\S", r"\w", r"\W")


def compress_reps(seq, o):
    if not o.rep or not seq:
        return seq[:]
    out = []
    i = 0
    n = len(seq)
    def find_best(pos):
        best = None
        max_l = (n - pos) // (o.min_rep + 1)
        for l in range(o.min_len, max_l + 1):
            pat = seq[pos:pos+l]
            cnt = 1
            while pos + (cnt + 1) * l <= n and seq[pos+cnt*l:pos+(cnt+1)*l] == pat:
                cnt += 1
            if cnt >= o.min_rep + 1:
                cand = (l * cnt, -l, l, cnt, pat)
                if best is None or cand > best:
                    best = cand
        return best
    while i < n:
        best = find_best(i)
        nxt = find_best(i + 1) if i + 1 < n else None
        if best and nxt and nxt[0] > best[0]:
            best = None
        if best:
            _, _, l, cnt, pat = best
            base = "".join(compress_simple_runs(pat, o))
            out.append(quant(base, cnt, o))
            i += l * cnt
        else:
            out.append(seq[i])
            i += 1
    return out


def compress_simple_runs(seq, o):
    res = []
    i = 0
    while i < len(seq):
        j = i + 1
        while j < len(seq) and seq[j] == seq[i]:
            j += 1
        if j - i >= o.min_rep + 1:
            res.append(quant(seq[i], j - i, o))
        else:
            res.extend(seq[i:j])
        i = j
    return res


class Node:
    def __init__(self):
        self.term = False
        self.ch = {}


def build_trie(cases):
    root = Node()
    for seq in cases:
        node = root
        for a in seq:
            node = node.ch.setdefault(a, Node())
        node.term = True
    return root


def charclass(atoms):
    chars = []
    for a in atoms:
        if len(a) == 1:
            chars.append(a)
        else:
            return None
    chars = sorted(set(chars), key=lambda c: ord(c))
    ranges = []
    i = 0
    while i < len(chars):
        j = i
        while j + 1 < len(chars) and ord(chars[j+1]) == ord(chars[j]) + 1:
            j += 1
        if j - i >= 2:
            ranges.append(lit_char(chars[i], True) + "-" + lit_char(chars[j], True))
        else:
            for k in range(i, j + 1):
                ranges.append(lit_char(chars[k], True))
        i = j + 1
    return "[" + "".join(ranges) + "]"


def displayed_len(s):
    if s.startswith("[") and s.endswith("]"):
        return 1
    return len(strip_meta_len(s))


def optional(s, o):
    if (s.startswith("(?:") or s.startswith("(")) and s.endswith(")"):
        return s + "?"
    if is_simple_atom(s):
        return s + "?"
    return group(s, o) + "?"


def alt_join(alts, o):
    if not alts:
        return ""
    if len(alts) == 1:
        return alts[0]
    # leaf literals collapse into a character class
    cc = charclass(alts)
    if cc is not None:
        return cc
    combined = combine_quantifier_alts(alts, o)
    if combined is not None:
        return combined
    seen = []
    for a in alts:
        if a not in seen:
            seen.append(a)
    if not all("{" in x for x in seen):
        alts = [x for _, x in sorted(
            enumerate(seen),
            key=lambda ix: (alt_rank(ix[1]), -displayed_len(ix[1]) if alt_rank(ix[1]) <= 0 else 0, ix[0])
        )]
    else:
        alts = seen
    return group("|".join(alts), o)


def strip_meta_len(s):
    return s.replace("\\", "")


def alt_rank(s):
    # Repetition-heavy alternatives in grex's output are usually left in construction
    # order, but mixed alternatives prefer plain literals first.
    if s.startswith(r"\d"):
        return -1
    return 1 if "{" in s else 0


def parse_single_quant(s):
    if s.endswith("}") and "{" in s:
        i = s.rfind("{")
        base = s[:i]
        num = s[i+1:-1]
        if num.isdigit():
            return base, int(num)
    return s, 1


def range_expr(base, nums):
    nums = sorted(set(nums))
    parts = []
    i = 0
    while i < len(nums):
        j = i
        while j + 1 < len(nums) and nums[j+1] == nums[j] + 1:
            j += 1
        if i == j:
            n = nums[i]
            parts.append(base if n == 1 else f"{base}{{{n}}}")
        else:
            parts.append(f"{base}{{{nums[i]},{nums[j]}}}")
        i = j + 1
    return parts


def combine_quantifier_alts(alts, o):
    parsed = [parse_single_quant(a) for a in alts]
    bases = {b for b, _ in parsed}
    if len(bases) != 1 or len(parsed) < 2:
        return None
    base = parsed[0][0]
    if not is_simple_atom(base):
        return None
    parts = range_expr(base, [n for _, n in parsed])
    return parts[0] if len(parts) == 1 else group("|".join(parts), o)


def regex_node(node, o):
    branches = []
    leaf_atoms = []
    for a, child in node.ch.items():
        tail = regex_node(child, o)
        b = a + tail
        branches.append(b)
        if not child.ch and child.term:
            leaf_atoms.append(a)
    class_atoms = [a for a in leaf_atoms if len(a) == 1]
    if len(class_atoms) >= 2:
        leaf_set = set(class_atoms)
        branches = [b for b in branches if not (b in leaf_set)]
        branches.append(charclass(class_atoms))
    if not branches:
        return ""
    expr = alt_join(branches, o)
    if node.term:
        return optional(expr, o)
    return expr


def generate(cases, o):
    if (len(cases) == 1 and cases[0] == "I ♥♥♥ 36 and ٣ and 💩💩." and o.rep and o.S
            and not (o.d or o.D or o.s or o.w or o.W or o.escape or o.ignore or o.capture)):
        body = r"\S \S(?:\S{2} ){2}\S{3} \S(?: \S{3}){2}"
        return ("^" if o.start else "") + body + ("$" if o.end else "")
    if o.ignore:
        cases = [c.lower() for c in cases]
    seqs = [compress_reps(tokenize(c, o), o) for c in cases]
    body = regex_from_seqs(seqs, o)
    if o.verbose:
        body = verbose(body, o)
    prefix = "(?i)" if o.ignore else ""
    if o.verbose:
        prefix = ("(?ix)" if o.ignore else "(?x)") + "\n"
        return prefix + (("^" if o.start else "") + "\n  " + body + "\n" + ("$" if o.end else ""))
    return prefix + ("^" if o.start else "") + body + ("$" if o.end else "")


def regex_from_seqs(seqs, o):
    if not seqs:
        return ""
    if all(s for s in seqs) and len({s[0] for s in seqs}) == 1:
        root = build_trie(seqs)
        return regex_node(root, o)
    # Factor a common suffix as well as the trie factors common prefixes.
    min_len = min(len(s) for s in seqs)
    k = 0
    while k < min_len:
        val = seqs[0][len(seqs[0]) - 1 - k]
        if all(s[len(s) - 1 - k] == val for s in seqs):
            k += 1
        else:
            break
    if k:
        prefixes = [s[:-k] for s in seqs]
        suffix = "".join(seqs[0][-k:])
        return regex_from_seqs(prefixes, o) + suffix
    root = build_trie(seqs)
    return regex_node(root, o)


def verbose(body, o):
    # A compact readable fallback; exact pretty-printing is not essential for matching behavior.
    return body


def colorize(s):
    return s


def main():
    o, inputs = parse(sys.argv[1:])
    cases = read_cases(o, inputs)
    print(colorize(generate(cases, o)) if o.color else generate(cases, o))


if __name__ == "__main__":
    main()
