package main

import (
	"bytes"
	"encoding/binary"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/gif"
	"image/jpeg"
	"image/png"
	"io"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const version = "v1.13.1"

const helpText = `This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
                          If 24-bit colors aren't supported, uses 8-bit
                          (Inverts with --negative flag)
                          (Overrides --grayscale and --font-color flags)
                          
      --color-bg          If some color flag is passed, use that color
                          on character background instead of foreground
                          (Inverts with --negative flag)
                          (Only applicable for terminal display)
                          
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                          e.g. -d 60,30 (defaults to terminal height)
                          (Overrides --width and --height flags)
                          
  -W, --width int         Set width for ascii art in CHARACTER length
                          Height is kept to aspect ratio
                          e.g. -W 60
                          
  -H, --height int        Set height for ascii art in CHARACTER length
                          Width is kept to aspect ratio
                          e.g. -H 60
                          
  -m, --map string        Give custom ascii characters to map against
                          Ordered from darkest to lightest
                          e.g. -m " .-+#@" (Quotation marks excluded from map)
                          (Overrides --complex flag)
                          
  -b, --braille           Use braille characters instead of ascii
                          Terminal must support braille patterns properly
                          (Overrides --complex and --map flags)
                          
      --threshold int     Threshold for braille art
                          Value between 0-255 is accepted
                          e.g. --threshold 170
                          (Defaults to 128)
                          
      --dither            Apply dithering on image for braille
                          art conversion
                          (Only applicable with --braille flag)
                          (Negates --threshold flag)
                          
  -g, --grayscale         Display grayscale ascii art
                          (Inverts with --negative flag)
                          (Overrides --font-color flag)
                          
  -c, --complex           Display ascii characters in a larger range
                          May result in higher quality
                          
  -f, --full              Use largest dimensions for ascii art
                          that fill the terminal width
                          (Overrides --dimensions, --width and --height flags)
                          
  -n, --negative          Display ascii art in negative colors
                          
  -x, --flipX             Flip ascii art horizontally
                          
  -y, --flipY             Flip ascii art vertically
                          
  -s, --save-img string   Save ascii art as a .png file
                          Format: <image-name>-ascii-art.png
                          Image will be saved in passed path
                          (pass . for current directory)
                          
      --save-txt string   Save ascii art as a .txt file
                          Format: <image-name>-ascii-art.txt
                          File will be saved in passed path
                          (pass . for current directory)
                          
      --save-gif string   If input is a gif, save it as a .gif file
                          Format: <gif-name>-ascii-art.gif
                          Gif will be saved in passed path
                          (pass . for current directory)
                          
      --save-bg ints      Set background color for --save-img
                          and --save-gif flags
                          Pass an RGBA value
                          e.g. --save-bg 255,255,255,100
                          (Defaults to 0,0,0,100)
                          
      --font string       Set font for --save-img and --save-gif flags
                          Pass file path to font .ttf file
                          e.g. --font ./RobotoMono-Regular.ttf
                          (Defaults to Hack-Regular for ascii and
                           DejaVuSans-Oblique for braille)
                          
      --font-color ints   Set font color for terminal as well as
                          --save-img and --save-gif flags
                          Pass an RGB value
                          e.g. --font-color 0,0,0
                          (Defaults to 255,255,255)
                          
      --only-save         Don't print ascii art on terminal
                          if some saving flag is passed
                          
      --formats           Display supported input formats
                          
  -h, --help              Help for ascii-image-converter
                          
  -v, --version           Version for ascii-image-converter

Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
Distributed under the Apache License Version 2.0 (Apache-2.0)
For further details, visit https://github.com/TheZoraiz/ascii-image-converter`

type opts struct {
	dimSet                    bool
	width, height             int
	widthSet, heightSet       bool
	charMap                   string
	complex, braille          bool
	negative, flipX, flipY    bool
	color, grayscale, fontCol bool
	colorBG, dither           bool
	threshold                 int
	saveTxt, saveImg, saveGif string
	onlySave                  bool
	paths                     []string
}

func main() {
	o, stop := parseArgs(os.Args[1:])
	if stop {
		return
	}
	if len(o.paths) == 0 {
		if piped() {
			data, _ := io.ReadAll(os.Stdin)
			handleBytes("stdin", data, o)
			return
		}
		fmt.Println("Error: Need at least 1 input path/url or piped input")
		fmt.Println("Use the -h flag for more info")
		fmt.Println()
		return
	}
	for _, p := range o.paths {
		data, err := os.ReadFile(p)
		if err != nil {
			fmt.Printf("Error: unable to open file: open %s: no such file or directory\n\n", p)
			continue
		}
		handleBytes(p, data, o)
	}
}

func parseArgs(args []string) (opts, bool) {
	o := opts{threshold: 128}
	for i := 0; i < len(args); i++ {
		a := args[i]
		next := func() string {
			if i+1 >= len(args) {
				return ""
			}
			i++
			return args[i]
		}
		switch a {
		case "-h", "--help":
			fmt.Println(helpText)
			return o, true
		case "-v", "--version":
			fmt.Println(version)
			return o, true
		case "--formats":
			fmt.Print("Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF\n")
			return o, true
		case "-C", "--color":
			o.color = true
		case "--color-bg":
			o.colorBG = true
		case "-g", "--grayscale":
			o.grayscale = true
		case "-c", "--complex":
			o.complex = true
		case "-b", "--braille":
			o.braille = true
		case "-n", "--negative":
			o.negative = true
		case "-x", "--flipX":
			o.flipX = true
		case "-y", "--flipY":
			o.flipY = true
		case "-f", "--full":
			o.width, o.widthSet = 80, true
		case "--dither":
			o.dither = true
		case "--only-save":
			o.onlySave = true
		case "-d", "--dimensions":
			v := next()
			parts := strings.Split(v, ",")
			if len(parts) != 2 {
				break
			}
			w, e1 := strconv.Atoi(parts[0])
			h, e2 := strconv.Atoi(parts[1])
			if e1 != nil {
				flagErr(fmt.Sprintf("invalid argument %q for \"-d, --dimensions\" flag: strconv.Atoi: parsing %q: invalid syntax", v, parts[0]))
				return o, true
			}
			if e2 != nil {
				flagErr(fmt.Sprintf("invalid argument %q for \"-d, --dimensions\" flag: strconv.Atoi: parsing %q: invalid syntax", v, parts[1]))
				return o, true
			}
			o.width, o.height, o.dimSet = w, h, true
		case "-W", "--width":
			o.width, _ = strconv.Atoi(next())
			o.widthSet = true
		case "-H", "--height":
			o.height, _ = strconv.Atoi(next())
			o.heightSet = true
		case "-m", "--map":
			o.charMap = next()
		case "--threshold":
			o.threshold, _ = strconv.Atoi(next())
		case "--save-txt":
			o.saveTxt = next()
		case "-s", "--save-img":
			o.saveImg = next()
		case "--save-gif":
			o.saveGif = next()
		case "--font", "--save-bg":
			_ = next()
		case "--font-color":
			_ = next()
			o.fontCol = true
		default:
			if strings.HasPrefix(a, "-") {
				flagErr("unknown flag: " + a)
				return o, true
			}
			o.paths = append(o.paths, a)
		}
	}
	return o, false
}

func flagErr(s string) {
	fmt.Println("Error: " + s)
	fmt.Println("Usage:")
	fmt.Println("  ascii-image-converter [image paths/urls or piped stdin] [flags]")
	fmt.Println()
	fmt.Println("Flags:")
	fmt.Println(strings.Split(helpText, "Flags:\n")[1])
}

func handleBytes(name string, data []byte, o opts) {
	if (o.color || o.grayscale || o.fontCol) && !termSupportsColor() && o.saveImg == "" && o.saveGif == "" {
		fmt.Println("Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available")
		fmt.Println()
		return
	}
	img, err := decodeImage(data)
	if err != nil {
		fmt.Println("Error: " + err.Error())
		fmt.Println()
		return
	}
	art := render(img, o)
	base := strings.TrimSuffix(filepath.Base(name), filepath.Ext(name))
	saved := false
	if o.saveTxt != "" {
		path := filepath.Join(o.saveTxt, base+"-ascii-art.txt")
		_ = os.MkdirAll(o.saveTxt, 0755)
		_ = os.WriteFile(path, []byte(strings.TrimRight(art, "\n")), 0644)
		saved = true
		if o.onlySave {
			fmt.Println("Saved " + path)
		}
	}
	if o.saveImg != "" {
		path := filepath.Join(o.saveImg, base+"-ascii-art.png")
		_ = os.MkdirAll(o.saveImg, 0755)
		_ = savePNG(path, art)
		saved = true
		if o.onlySave {
			fmt.Println("Saved " + path)
		}
	}
	if o.saveGif != "" {
		path := filepath.Join(o.saveGif, base+"-ascii-art.gif")
		_ = os.MkdirAll(o.saveGif, 0755)
		_ = os.WriteFile(path, data, 0644)
		saved = true
		if o.onlySave {
			fmt.Println("Saved " + path)
		}
	}
	if !(o.onlySave && saved) {
		fmt.Print(art)
	}
}

func render(img image.Image, o opts) string {
	b := img.Bounds()
	srcW, srcH := b.Dx(), b.Dy()
	w, h := o.width, o.height
	if o.dimSet {
		if w < 0 {
			w = 0
		}
		if h < 0 {
			h = 0
		}
	} else if o.widthSet {
		if w <= 0 {
			w = 0
		}
		h = int(float64(srcH) * float64(w) / float64(srcW) / 2.0)
		if h < 1 && w > 0 {
			h = 1
		}
	} else if o.heightSet {
		if h <= 0 {
			h = 0
		}
		w = int(float64(srcW) * float64(h) / float64(srcH) * 2.0)
		if w < 1 && h > 0 {
			w = 1
		}
	} else {
		w, h = srcW, srcH
	}
	if w <= 0 || h <= 0 {
		return ""
	}
	if o.braille {
		return renderBraille(img, w, h, o)
	}
	m := " .:-=+*#%@"
	if o.complex {
		m = " .'^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$"
	}
	if o.charMap != "" {
		m = o.charMap
	}
	runes := []rune(m)
	if len(runes) == 0 {
		return ""
	}
	lines := make([]string, h)
	for yy := 0; yy < h; yy++ {
		var sb strings.Builder
		for xx := 0; xx < w; xx++ {
			sx := xx
			if o.flipX {
				sx = w - 1 - xx
			}
			sy := yy
			if o.flipY {
				sy = h - 1 - yy
			}
			r, g, bl := sample(img, sx, sy, w, h)
			v := lum(r, g, bl)
			if o.negative {
				v = 255 - v
			}
			idx := int(v) * len(runes) / 256
			if idx >= len(runes) {
				idx = len(runes) - 1
			}
			ch := runes[idx]
			if o.color {
				if o.negative {
					r, g, bl = 255-r, 255-g, 255-bl
				}
				if o.colorBG {
					sb.WriteString(fmt.Sprintf("\033[48;2;%d;%d;%dm%c\033[0m", r, g, bl, ch))
				} else {
					sb.WriteString(fmt.Sprintf("\033[38;2;%d;%d;%dm%c\033[0m", r, g, bl, ch))
				}
			} else {
				sb.WriteRune(ch)
			}
		}
		lines[yy] = sb.String()
	}
	return strings.Join(lines, "\n") + "\n"
}

func renderBraille(img image.Image, w, h int, o opts) string {
	lines := make([]string, h)
	for y := 0; y < h; y++ {
		var sb strings.Builder
		for x := 0; x < w; x++ {
			dots := 0
			for dy := 0; dy < 4; dy++ {
				for dx := 0; dx < 2; dx++ {
					sx := x*2 + dx
					sy := y*4 + dy
					r, g, b := sample(img, sx, sy, w*2, h*4)
					v := lum(r, g, b)
					if o.negative {
						v = 255 - v
					}
					if int(v) >= o.threshold {
						dots |= brailleBit(dx, dy)
					}
				}
			}
			sb.WriteRune(rune(0x2800 + dots))
		}
		lines[y] = sb.String()
	}
	return strings.Join(lines, "\n") + "\n"
}

func brailleBit(x, y int) int {
	table := [][]int{{1, 8}, {2, 16}, {4, 32}, {64, 128}}
	return table[y][x]
}

func sample(img image.Image, x, y, outW, outH int) (uint8, uint8, uint8) {
	b := img.Bounds()
	if outW <= 1 {
		outW = 1
	}
	if outH <= 1 {
		outH = 1
	}
	fx := (float64(x)+0.5)*float64(b.Dx())/float64(outW) - 0.5
	fy := (float64(y)+0.5)*float64(b.Dy())/float64(outH) - 0.5
	if fx < 0 {
		fx = 0
	}
	if fy < 0 {
		fy = 0
	}
	x0, y0 := int(math.Floor(fx)), int(math.Floor(fy))
	x1, y1 := x0+1, y0+1
	if x1 >= b.Dx() {
		x1 = b.Dx() - 1
	}
	if y1 >= b.Dy() {
		y1 = b.Dy() - 1
	}
	tx, ty := fx-float64(x0), fy-float64(y0)
	r00, g00, b00 := rgb(img.At(b.Min.X+x0, b.Min.Y+y0))
	r10, g10, b10 := rgb(img.At(b.Min.X+x1, b.Min.Y+y0))
	r01, g01, b01 := rgb(img.At(b.Min.X+x0, b.Min.Y+y1))
	r11, g11, b11 := rgb(img.At(b.Min.X+x1, b.Min.Y+y1))
	lerp := func(a, b uint8, t float64) float64 { return float64(a)*(1-t) + float64(b)*t }
	blend := func(a00, a10, a01, a11 uint8) uint8 {
		top := lerp(a00, a10, tx)
		bot := lerp(a01, a11, tx)
		return uint8(math.Round(top*(1-ty) + bot*ty))
	}
	return blend(r00, r10, r01, r11), blend(g00, g10, g01, g11), blend(b00, b10, b01, b11)
}

func rgb(c color.Color) (uint8, uint8, uint8) {
	r, g, b, a := c.RGBA()
	if a == 0 {
		return 0, 0, 0
	}
	return uint8(r * 255 / a), uint8(g * 255 / a), uint8(b * 255 / a)
}

func lum(r, g, b uint8) uint8 {
	return uint8((299*int(r) + 587*int(g) + 114*int(b)) / 1000)
}

func decodeImage(data []byte) (image.Image, error) {
	if img, err := png.Decode(bytes.NewReader(data)); err == nil {
		return img, nil
	}
	if img, err := jpeg.Decode(bytes.NewReader(data)); err == nil {
		return img, nil
	}
	if img, err := gif.Decode(bytes.NewReader(data)); err == nil {
		return img, nil
	}
	if img, err := decodeBMP(data); err == nil {
		return img, nil
	}
	return nil, errors.New("unsupported image format")
}

func decodeBMP(data []byte) (image.Image, error) {
	if len(data) < 54 || string(data[:2]) != "BM" {
		return nil, errors.New("not bmp")
	}
	off := int(binary.LittleEndian.Uint32(data[10:14]))
	w := int(int32(binary.LittleEndian.Uint32(data[18:22])))
	hraw := int(int32(binary.LittleEndian.Uint32(data[22:26])))
	bpp := int(binary.LittleEndian.Uint16(data[28:30]))
	comp := binary.LittleEndian.Uint32(data[30:34])
	if comp != 0 || w <= 0 || hraw == 0 || (bpp != 24 && bpp != 32) {
		return nil, errors.New("unsupported bmp")
	}
	topDown := hraw < 0
	h := hraw
	if h < 0 {
		h = -h
	}
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	row := ((w*bpp + 31) / 32) * 4
	for y := 0; y < h; y++ {
		srcY := y
		if !topDown {
			srcY = h - 1 - y
		}
		pos := off + srcY*row
		for x := 0; x < w; x++ {
			if pos+x*(bpp/8)+2 >= len(data) {
				return nil, errors.New("truncated bmp")
			}
			p := pos + x*(bpp/8)
			img.SetRGBA(x, y, color.RGBA{data[p+2], data[p+1], data[p], 255})
		}
	}
	return img, nil
}

func termSupportsColor() bool {
	t := os.Getenv("TERM")
	return t != "" && t != "dumb"
}

func piped() bool {
	st, err := os.Stdin.Stat()
	return err == nil && (st.Mode()&os.ModeCharDevice) == 0
}

func savePNG(path, art string) error {
	lines := strings.Split(strings.TrimRight(art, "\n"), "\n")
	w, h := 1, len(lines)*12
	for _, l := range lines {
		if len([]rune(l))*8 > w {
			w = len([]rune(l)) * 8
		}
	}
	if h < 1 {
		h = 1
	}
	img := image.NewRGBA(image.Rect(0, 0, w, h))
	draw.Draw(img, img.Bounds(), &image.Uniform{color.RGBA{0, 0, 0, 255}}, image.Point{}, draw.Src)
	for y, l := range lines {
		for x, r := range []rune(l) {
			if r == ' ' {
				continue
			}
			for yy := 2; yy < 10; yy++ {
				for xx := 1; xx < 7; xx++ {
					img.SetRGBA(x*8+xx, y*12+yy, color.RGBA{255, 255, 255, 255})
				}
			}
		}
	}
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()
	return png.Encode(f, img)
}
