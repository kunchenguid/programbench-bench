#!/usr/bin/env python3
import os, re, sys, subprocess

VERSION = "Hush 0.1.4"
HELP = """Hush 0.1.4
gahag <gabriel.s.b@live.com>
Hush is a unix shell scripting language based on the Lua programming language

USAGE:
    executable [FLAGS] [arguments]...

FLAGS:
        --ast        Print the AST
        --check      Perform only static analysis instead of executing.
    -h, --help       Prints help information
        --lex        Print the lexemes
        --program    Print the PROGAM
    -V, --version    Prints version information

ARGS:
    <arguments>...    Script and/or arguments
"""
OPS=['==','!=','<=','>=','++','<<','>>','2>','1>','${','&{']
SINGLE=set('()[]{}@,:.=+-*/%<>;|?')

class Tok:
    def __init__(self, v, line, col, err=None): self.v=v; self.line=line; self.col=col; self.err=err

def fmt_num(s):
    try:
        if 'e' in s.lower():
            x=float(s)
            if x.is_integer(): return str(int(x))
            return str(x)
    except Exception: pass
    return s

def lex(code):
    toks=[]; errs=[]; i=0; line=1; col=0; n=len(code); cmd_depth=0
    def adv(ch):
        nonlocal line,col
        if ch=='\n': line+=1; col=0
        else: col+=1
    while i<n:
        ch=code[i]
        if ch in ' \t\r': adv(ch); i+=1; continue
        if ch=='\n': adv(ch); i+=1; continue
        if ch=='#':
            while i<n and code[i]!='\n': adv(code[i]); i+=1
            continue
        stl,stc=line,col
        if ch in '"\'':
            quote=ch; raw=ch; i+=1; adv(ch); bad=None
            while i<n:
                c=code[i]; raw+=c; i+=1; adv(c)
                if c==quote: break
                if c=='\\' and i<n:
                    esc=code[i]; raw+=esc; i+=1; adv(esc)
                    if esc not in ['n','t','r','0','\\','"',"'","$"]:
                        bad=(line, col-2, "invalid escape sequence '\\%s'."%esc)
            if bad:
                errs.append(bad); toks.append(Tok("'\\0'", stl, stc, bad))
            else: toks.append(Tok(raw, stl, stc))
            continue
        if ch.isdigit():
            s=''
            while i<n and (code[i].isdigit() or code[i]=='.' or code[i] in 'eE' or (code[i] in '+-' and s and s[-1] in 'eE')):
                s+=code[i]; adv(code[i]); i+=1
            toks.append(Tok(fmt_num(s), stl, stc)); continue
        if ch=='$':
            if i+1<n and code[i+1]=='{':
                toks.append(Tok('${',stl,stc)); adv('$'); adv('{'); i+=2; cmd_depth+=1; continue
            if cmd_depth>0 and i+1<n and (code[i+1].isalpha() or code[i+1]=='_'):
                i+=1; adv('$'); name=''
                while i<n and (code[i].isalnum() or code[i]=='_'):
                    name+=code[i]; adv(code[i]); i+=1
                toks.append(Tok('${{%s}}'%name, stl, stc)); continue
            errs.append((stl,stc,"unexpected '$'.")); adv(ch); i+=1; continue
        if cmd_depth>0 and ch not in SINGLE:
            s=""
            while i<n and (not code[i].isspace()) and code[i] not in ";{}|<>":
                s+=code[i]; adv(code[i]); i+=1
            toks.append(Tok(s, stl, stc)); continue
        matched=False
        for op in OPS:
            if code.startswith(op,i):
                toks.append(Tok(op,stl,stc)); [adv(c) for c in op]; i+=len(op); matched=True
                if op in ['${','&{']: cmd_depth+=1
                break
        if matched: continue
        if ch.isalpha() or ch=='_':
            s=''
            while i<n and (code[i].isalnum() or code[i]=='_'):
                s+=code[i]; adv(code[i]); i+=1
            toks.append(Tok(s, stl, stc)); continue
        if ch in SINGLE:
            if ch=='{': cmd_depth+=1; toks.append(Tok(ch, stl, stc)); adv(ch); i+=1; continue
            if ch=='}':
                if cmd_depth>0:
                    cmd_depth-=1; toks.append(Tok(ch, stl, stc)); adv(ch); i+=1; continue
                errs.append((stl,stc,"unexpected '}'.")); adv(ch); i+=1; continue
            if ch==';' and cmd_depth==0:
                errs.append((stl,stc,"unexpected ';'.")); adv(ch); i+=1; continue
            if ch=='@' and not (i+1<n and code[i+1]=='['):
                errs.append((stl,stc,"unexpected '@'.")); adv(ch); i+=1; continue
            if ch=='|' and cmd_depth==0:
                errs.append((stl,stc,"unexpected '|'.")); adv(ch); i+=1; continue
            toks.append(Tok(ch, stl, stc)); adv(ch); i+=1; continue
        errs.append((stl,stc,"unexpected '%s'."%ch)); adv(ch); i+=1
    return toks, errs

def read_script(args):
    if not args: return None, sys.stdin.read()
    path=args[0]
    try:
        with open(path) as f: return path, f.read()
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr); sys.exit(1)

def print_lex(path, toks, errs):
    print('-'*50)
    for t in toks:
        if t.err: print(f"Error: line {t.err[0]}, column {t.err[1]} - {t.err[2]}")
        print(f"{path} (line {t.line}, column {t.col}):\t{t.v}")
    for e in errs:
        if not any(t.err==e for t in toks): print(f"Error: line {e[0]}, column {e[1]} - {e[2]}")
    print('-'*50)

def split_top(code):
    res=[]; cur=''; depth=0; q=None; esc=False
    for ch in code:
        cur+=ch
        if q:
            if esc: esc=False
            elif ch=='\\': esc=True
            elif ch==q: q=None
        else:
            if ch in '"\'': q=ch
            elif ch in '([{': depth+=1
            elif ch in ')]}': depth=max(0,depth-1)
            elif ch=='\n' and depth==0:
                if cur.strip(): res.append(cur.strip())
                cur=''
    if cur.strip(): res.append(cur.strip())
    return res

def paren_expr(s):
    s=s.strip()
    for op in [' + ', ' * ', ' - ', ' / ']:
        if op in s and not (s.startswith('(') and s.endswith(')')):
            a,b=s.split(op,1); return '('+paren_expr(a)+op+paren_expr(b)+')'
    return s

def ast_lines(code):
    lines=[]
    for st in split_top(code):
        if st.startswith('let '):
            body=st[4:].strip()
            if '=' in body:
                name,expr=body.split('=',1); lines.append(f"let {name.strip()} = {paren_expr(expr)}")
            else: lines.append(f"let {body.strip()} = nil")
        elif st.startswith('{') and st.rstrip().endswith('}'):
            body=st.strip()[1:-1].strip(); lines.append('{')
            for c in [x.strip() for x in body.split(';') if x.strip()]:
                words=c.split(); lines.append('\t'+' '.join('"'+w+'"' if not w.startswith('$') else '"${'+w[1:]+'}"' for w in words))
            lines.append('}')
        elif re.match(r'^[A-Za-z_]\w*\s*=', st):
            name,expr=st.split('=',1); lines.append(f"{name.strip()} = {paren_expr(expr)}")
        else: lines.append(paren_expr(st))
    return lines

def print_ast(path, code, title='AST'):
    print('-'*50); print(f"{title} for {path}")
    for l in ast_lines(code): print(l)
    print('-'*50)

def translate_expr(expr, env):
    e=expr.strip().replace('++','+')
    e=re.sub(r'\bnil\b','None',e); e=re.sub(r'\btrue\b','True',e); e=re.sub(r'\bfalse\b','False',e)
    e=re.sub(r'std\.len\((.*?)\)', r'len(\1)', e)
    m=re.match(r'if (.*?) then (.*?) else (.*?) end$', e, re.S)
    if m: e=f"({translate_expr(m.group(2),env)} if {translate_expr(m.group(1),env)} else {translate_expr(m.group(3),env)})"
    return e

def eval_expr(expr, env):
    try: return eval(translate_expr(expr,env), {'len':len}, env)
    except Exception: return None

def subst_vars(s, env):
    def repl(m):
        name=m.group(1) or m.group(2); return str(env.get(name,''))
    return re.sub(r'\$\{([A-Za-z_]\w*)\}|\$([A-Za-z_]\w*)', repl, s)

def run_command_block(body, env, capture=False):
    p=subprocess.run(subst_vars(body, env), shell=True, text=True, stdout=subprocess.PIPE if capture else None)
    if capture: return {'status':p.returncode, 'stdout':p.stdout, 'stderr':''}
    return p.returncode

def exec_code(code, argv, check=False):
    env={'args':argv}
    for st in split_top(code):
        s=st.strip()
        if not s: continue
        if s.startswith('let '):
            body=s[4:].strip()
            if '=' in body:
                name,expr=body.split('=',1); env[name.strip()]=eval_expr(expr, env)
            else: env[body.strip()]=None
        elif re.match(r'^[A-Za-z_]\w*\s*=', s):
            name,expr=s.split('=',1); env[name.strip()]=eval_expr(expr, env)
        elif s.startswith('${') and s.endswith('}'):
            run_command_block(s[2:-1], env, True)
        elif s.startswith('{') and s.endswith('}'):
            if not check: run_command_block(s[1:-1], env, False)
        else: eval_expr(s, env)
    return 0

def static_errors(path, code):
    if re.search(r'^\s*function\b', code, re.M):
        return []
    errs=[]; declared=set(["args"])
    built=set("function if then else end true false nil for in do while return not and or std self".split())
    offset=0
    for st in split_top(code):
        s=st.strip()
        pos=code.find(s, offset)
        if pos < 0: pos=0
        offset=pos+len(s)
        line=code[:pos].count("\n")+1
        col=pos - (code.rfind("\n", 0, pos)+1)
        if not s or s.startswith(("{", "${", "&{", "function", "if", "for", "while", "return")):
            continue
        if s.startswith("let "):
            m=re.match(r"let\s+([A-Za-z_]\w*)", s)
            if m: declared.add(m.group(1))
            continue
        m=re.match(r"^([A-Za-z_]\w*)\s*=", s)
        if m:
            declared.add(m.group(1)); continue
        m=re.match(r"^([A-Za-z_]\w*)\b", s)
        if m and m.group(1) not in declared and m.group(1) not in built:
            name=m.group(1)
            errs.append(f"Error: {path} (line {line}, column {col}) - undeclared variable '{name}'")
    return errs
def main():
    argv=sys.argv[1:]
    if '-h' in argv or '--help' in argv: print(HELP, end=''); return 0
    if '-V' in argv or '--version' in argv: print(VERSION); return 0
    flags={f for f in argv if f.startswith('-')}
    for f in flags:
        if f not in ['--ast','--check','--lex','--program']:
            print(f"error: Found argument '{f}' which wasn't expected, or isn't valid in this context\n", file=sys.stderr)
            print("USAGE:\n    executable [FLAGS] [arguments]...\n\nFor more information try --help", file=sys.stderr); return 1
    args=[a for a in argv if not a.startswith('-')]
    path,code=read_script(args)
    if path is None: return 0
    toks,lexerrs=lex(code); sterrs=static_errors(path,code)
    if '--lex' in flags: print_lex(path,toks,lexerrs)
    if '--ast' in flags: print_ast(path, code, 'AST')
    if '--program' in flags: print_ast(path, code, 'Program')
    if lexerrs or sterrs:
        for e in lexerrs: print(f"Error: {path} (line {e[0]}, column {e[1]}) - {e[2]}", file=sys.stderr)
        for e in sterrs: print(e, file=sys.stderr)
        return 2
    sys.stdout.flush()
    if '--check' not in flags: return exec_code(code, args[1:], False)
    return 0
if __name__=='__main__': sys.exit(main())
