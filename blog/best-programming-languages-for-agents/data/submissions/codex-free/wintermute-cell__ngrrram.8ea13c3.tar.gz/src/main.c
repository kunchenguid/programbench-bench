#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char n[256];
    int top, combi, rep, wpm, acc;
    char emu_in[64], emu_out[64];
    int show_ortho, nokb, cat;
} Opts;

static const char *bigrams[] = {
    "th","he","in","er","an","re","on","at","en","nd","ti","es","or","te","of","ed","is","it","al","ar",
    "st","to","nt","ng","se","ha","as","ou","io","le","ve","co","me","de","hi","ri","ro","ic","ne","ea",
    "ra","ce","li","ch","ll","be","ma","si","om","ur","ca","el","ta","la","ns","di","fo","ho","pe","ec"
};
static const char *trigrams[] = {
    "the","and","ing","ion","ent","her","for","tha","nth","int","ere","tio","ter","est","ers","ati","hat","ate","all","eth",
    "hes","ver","his","oft","ith","fth","sth","oth","res","ont","rea","pro","con","com","men","sta","ara","our","red","lin"
};
static const char *tetras[] = {
    "tion","ther","that","with","ment","ions","this","here","ould","ight","have","hich","whic","from","they","atio","ever","ough","were","hing",
    "ance","inte","tive","over","dthe","pres","nter","comp","able","heir"
};
static const char *words[] = {
    "the","of","and","to","in","a","is","that","for","it","as","was","with","be","by","on","not","he","i","this",
    "are","or","his","from","at","which","but","have","an","had","they","you","were","their","one","all","we","can","her","has"
};

static void print_help(void) {
    puts("Usage: executable [OPTIONS]\n");
    puts("Options:");
    puts("  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]");
    puts("  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]");
    puts("  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]");
    puts("  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]");
    puts("  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]");
    puts("  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]");
    puts("      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    puts("      --show-ortho        show keyboard in ortholinear format");
    puts("      --nokb              pass this flag to disable the keyboard layout display.");
    puts("      --cat               the most important flag. don't practice alone.");
    puts("  -h, --help              Print help");
}

static int parse_num(const char *s, const char *flag, const char *shown, int *out) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !s[0] || *end) {
        fprintf(stderr, "error: invalid value '%s' for '%s <%s>': invalid digit found in string\n\nFor more information, try '--help'.\n", s, flag, shown);
        return 2;
    }
    *out = (int)v;
    return 0;
}

static int need_value(int i, int argc, const char *flag, const char *shown) {
    if (i + 1 < argc) return 0;
    fprintf(stderr, "error: a value is required for '%s <%s>' but none was supplied\n\nFor more information, try '--help'.\n", flag, shown);
    return 2;
}

static int valid_layout(const char *s) {
    const char *v[] = {"qwerty","qwertz","azerty","dvorak","colemak","colemakdh",NULL};
    for (int i = 0; v[i]; i++) if (!strcmp(s, v[i])) return 1;
    return 0;
}

static int parse_args(int argc, char **argv, Opts *o) {
    strcpy(o->n, "2"); o->top = 50; o->combi = 2; o->rep = 3; o->wpm = 40; o->acc = 94;
    o->emu_in[0] = o->emu_out[0] = 0; o->show_ortho = o->nokb = o->cat = 0;
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { print_help(); exit(0); }
        else if (!strcmp(a, "-n") || !strcmp(a, "--n")) { int e=need_value(i,argc,"--n","2|3|4|w|file"); if(e)return e; strncpy(o->n, argv[++i], sizeof(o->n)-1); }
        else if (!strcmp(a, "-t") || !strcmp(a, "--top")) { int e=need_value(i,argc,"--top","1-200"); if(e)return e; if((e=parse_num(argv[++i],"--top","1-200",&o->top)))return e; }
        else if (!strcmp(a, "-c") || !strcmp(a, "--combi")) { int e=need_value(i,argc,"--combi","1-200"); if(e)return e; if((e=parse_num(argv[++i],"--combi","1-200",&o->combi)))return e; }
        else if (!strcmp(a, "-r") || !strcmp(a, "--rep")) { int e=need_value(i,argc,"--rep","number"); if(e)return e; if((e=parse_num(argv[++i],"--rep","number",&o->rep)))return e; }
        else if (!strcmp(a, "-w") || !strcmp(a, "--wpm")) { int e=need_value(i,argc,"--wpm","number"); if(e)return e; if((e=parse_num(argv[++i],"--wpm","number",&o->wpm)))return e; }
        else if (!strcmp(a, "-a") || !strcmp(a, "--acc")) { int e=need_value(i,argc,"--acc","0-100"); if(e)return e; if((e=parse_num(argv[++i],"--acc","0-100",&o->acc)))return e; }
        else if (!strcmp(a, "--emu-in")) { int e=need_value(i,argc,"--emu-in","layout"); if(e)return e; strncpy(o->emu_in, argv[++i], sizeof(o->emu_in)-1); }
        else if (!strcmp(a, "--emu-out")) { int e=need_value(i,argc,"--emu-out","layout"); if(e)return e; strncpy(o->emu_out, argv[++i], sizeof(o->emu_out)-1); }
        else if (!strcmp(a, "--show-ortho")) o->show_ortho = 1;
        else if (!strcmp(a, "--nokb")) o->nokb = 1;
        else if (!strcmp(a, "--cat")) o->cat = 1;
        else {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n", a);
            if (!strcmp(a, "--version"))
                fprintf(stderr, "Usage: executable [OPTIONS]\n\n");
            else
                fprintf(stderr, "Usage: executable <--n <2|3|4|w|file>|--top <1-200>|--combi <1-200>|--rep <number>|--wpm <number>|--acc <0-100>|--emu-in <layout>|--emu-out <layout>|--show-ortho|--nokb|--cat>\n\n");
            fprintf(stderr, "For more information, try '--help'.\n");
            return 2;
        }
    }
    if (o->top < 1 || o->top > 200) { puts("Invalid argument for top. Use a number between 1 and 200."); return 1; }
    if (o->combi < 1 || o->combi > 200) { puts("Invalid argument for combi. Use a number between 1 and 200."); return 1; }
    if (o->acc < 0 || o->acc > 100) { puts("Invalid argument for acc. Use a number between 0 and 100."); return 1; }
    if ((o->emu_in[0] && !o->emu_out[0]) || (!o->emu_in[0] && o->emu_out[0])) { puts("You need to specify both emu_in and emu_out."); return 1; }
    if (o->emu_in[0] && (!valid_layout(o->emu_in) || !valid_layout(o->emu_out))) { puts("Unsupported layout. Supported layouts: qwerty, qwertz, azerty, dvorak, colemak, colemakdh."); return 1; }
    return 0;
}

static char **file_words(const char *path, int *count) {
    FILE *f = fopen(path, "rb");
    if (!f) { printf("File not found: %s\n", path); exit(1); }
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    rewind(f);
    char *buf = calloc((size_t)n + 2, 1);
    if (!buf) exit(1);
    size_t got = fread(buf, 1, (size_t)n, f);
    (void)got;
    fclose(f);
    char **list = calloc(256, sizeof(char*));
    int cap = 256, c = 0;
    for (char *p = strtok(buf, ",\n\r\t "); p; p = strtok(NULL, ",\n\r\t ")) {
        if (c >= cap) { cap *= 2; list = realloc(list, (size_t)cap * sizeof(char*)); }
        list[c++] = strdup(p);
    }
    if (!c) { list[c++] = strdup(""); }
    *count = c;
    return list;
}

static const char **builtin_list(const Opts *o, int *count) {
    if (!strcmp(o->n, "2")) { *count = (int)(sizeof(bigrams)/sizeof(bigrams[0])); return bigrams; }
    if (!strcmp(o->n, "3")) { *count = (int)(sizeof(trigrams)/sizeof(trigrams[0])); return trigrams; }
    if (!strcmp(o->n, "4")) { *count = (int)(sizeof(tetras)/sizeof(tetras[0])); return tetras; }
    if (!strcmp(o->n, "w")) { *count = (int)(sizeof(words)/sizeof(words[0])); return words; }
    return NULL;
}

static char *make_lesson(const Opts *o, const char **built, char **custom, int count, int lesson_no) {
    int top = o->top < count ? o->top : count;
    if (top < 1) top = 1;
    size_t cap = 8192, used = 0;
    char *s = calloc(cap, 1);
    for (int r = 0; r < o->rep; r++) {
        for (int c = 0; c < o->combi; c++) {
            int idx = (lesson_no * o->combi + c) % top;
            const char *w = built ? built[idx] : custom[idx];
            size_t len = strlen(w);
            if (used + len + 2 >= cap) { cap *= 2; s = realloc(s, cap); }
            if (used) s[used++] = ' ';
            memcpy(s + used, w, len);
            used += len;
            s[used] = 0;
        }
    }
    return s;
}

static struct termios oldt;
static int raw_on = 0;
static void restore(void) {
    if (raw_on) tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    printf("\033[?25h\033[?1049l");
    fflush(stdout);
}
static void sigint_handler(int sig) { (void)sig; restore(); _exit(130); }

static void draw_keyboard(const Opts *o) {
    if (o->nokb) {
        puts("│                                                                            │");
        puts("│                                                                            │");
        return;
    }
    if (o->show_ortho) {
        puts("│┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐                           │");
        puts("││ q │ w │ e │ r │ t │ y │ u │ i │ o │ p │ [ │ ] │                           │");
        puts("│├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                           │");
        puts("││ a │ s │ d │ f │ g │ h │ j │ k │ l │ ; │ ' │   │                           │");
        puts("│├───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┼───┤                           │");
        puts("││ z │ x │ c │ v │ b │ n │ m │ , │ . │ / │   │   │                           │");
        puts("│└───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘                           │");
    } else {
        puts("│┌───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┬───┐                           │");
        puts("││ q │ w │ e │ r │ t │ y │ u │ i │ o │ p │ [ │ ] │                           │");
        puts("│└┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┘                           │");
        puts("│ │ a │ s │ d │ f │ g │ h │ j │ k │ l │ ; │ ' │                              │");
        puts("│ └┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┴┬──┘                              │");
        puts("│  │ z │ x │ c │ v │ b │ n │ m │ , │ . │ / │                                 │");
        puts("│  └───┴───┴───┴───┴───┴───┴───┴───┴───┴───┘                                 │");
    }
}

static void draw(const Opts *o, const char *lesson, int pos, int lesson_no, int ok, int bad, int last_wpm, int last_acc) {
    printf("\033[2J\033[H\033[?25l");
    puts("╭─────────────────────────────────────────────────────────────────Quit<esc> ╮");
    puts("│               ngrrram!   by winterveil                                    │");
    puts("│─────────────────────────────────────────────────────────────────────────────│");
    printf("│Lesson#%d✔: %d, ✘: %d    %-50s│\n", lesson_no, ok, bad, "");
    puts("│─────────────────────────────────────────────────────────────────────────────│");
    char line[73]; memset(line, ' ', sizeof(line)); line[72] = 0;
    int max = (int)strlen(lesson); if (max > 62) max = 62;
    memcpy(line, lesson, (size_t)max);
    printf("│%s│\n", line);
    memset(line, ' ', sizeof(line)); line[72] = 0;
    if (pos >= 0 && pos < 62) line[pos] = '^';
    printf("│%s│\n", line);
    if (o->cat) puts("│        /\\_/\\\\                                                              │\n│       ( o.o )   meow                                                       │\n│        > ^ <                                                               │");
    draw_keyboard(o);
    puts("│─────────────────────────────────────────────────────────────────────────────│");
    printf("│  need >=  %dWPM,   avg. %dWPM,   last%dWPM%*s│\n", o->wpm, last_wpm ? last_wpm : 0, last_wpm, 33, "");
    printf("│  need >=  %d%% Acc, avg. %d%%Acc, last%d%%Acc%*s│\n", o->acc, last_acc ? last_acc : 0, last_acc, 31, "");
    puts("╰─────────────────────────────────────────────────────────────────────────────╯");
    printf("%d%s    %c", lesson_no + 1, lesson, lesson[pos] ? lesson[pos] : ' ');
    fflush(stdout);
}

static int run_tui(const Opts *o, const char **built, char **custom, int count) {
    if (isatty(STDIN_FILENO)) {
        tcgetattr(STDIN_FILENO, &oldt);
        struct termios t = oldt;
        t.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        t.c_cc[VMIN] = 0; t.c_cc[VTIME] = 1;
        tcsetattr(STDIN_FILENO, TCSANOW, &t);
        raw_on = 1;
    }
    signal(SIGINT, sigint_handler);
    atexit(restore);
    printf("\033[?1049h");
    int lesson_no = 0, ok = 0, bad = 0, last_wpm = 0, last_acc = 0;
    char *lesson = make_lesson(o, built, custom, count, lesson_no);
    int pos = 0, typed = 0, wrong = 0;
    struct timespec start = {0,0};
    for (;;) {
        draw(o, lesson, pos, lesson_no, ok, bad, last_wpm, last_acc);
        unsigned char ch;
        fd_set rfds; FD_ZERO(&rfds); FD_SET(STDIN_FILENO, &rfds);
        struct timeval tv = {0, 120000};
        int r = select(STDIN_FILENO + 1, &rfds, NULL, NULL, &tv);
        if (r <= 0) continue;
        if (read(STDIN_FILENO, &ch, 1) != 1) continue;
        if (ch == 27 || ch == 3) break;
        if (!lesson[pos]) continue;
        if (!typed) clock_gettime(CLOCK_MONOTONIC, &start);
        typed++;
        if (ch == (unsigned char)lesson[pos]) pos++;
        else { wrong++; bad++; }
        if (!lesson[pos]) {
            struct timespec end; clock_gettime(CLOCK_MONOTONIC, &end);
            double secs = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec)/1000000000.0;
            if (secs < 0.01) secs = 0.01;
            last_wpm = (int)(((double)strlen(lesson) / 5.0) / (secs / 60.0) + 0.5);
            last_acc = typed ? (int)(((typed - wrong) * 100.0) / typed + 0.5) : 0;
            if (last_wpm >= o->wpm && last_acc >= o->acc) ok++; else bad++;
            free(lesson);
            lesson_no++; lesson = make_lesson(o, built, custom, count, lesson_no);
            pos = typed = wrong = 0;
        }
    }
    free(lesson);
    restore();
    return 0;
}

int main(int argc, char **argv) {
    Opts o;
    int e = parse_args(argc, argv, &o);
    if (e) return e;
    int count = 0;
    const char **built = builtin_list(&o, &count);
    char **custom = NULL;
    if (!built) custom = file_words(o.n, &count);
    return run_tui(&o, built, custom, count);
}
