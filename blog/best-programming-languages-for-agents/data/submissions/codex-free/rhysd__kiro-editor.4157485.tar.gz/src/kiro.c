#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#define _GNU_SOURCE

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#define KI_VERSION "0.4.3"
#define CTRL_KEY(k) ((k)&0x1f)

enum editorKey {
  ARROW_LEFT = 1000,
  ARROW_RIGHT,
  ARROW_UP,
  ARROW_DOWN,
  DEL_KEY,
  HOME_KEY,
  END_KEY,
  PAGE_UP,
  PAGE_DOWN
};

typedef struct erow {
  int size;
  char *chars;
} erow;

typedef struct buffer {
  char *filename;
  erow *row;
  int numrows;
  int dirty;
} buffer;

struct editorConfig {
  int cx, cy;
  int rowoff, coloff;
  int screenrows, screencols;
  int curbuf, numbufs;
  buffer *bufs;
  char statusmsg[256];
  time_t statusmsg_time;
  struct termios orig_termios;
} E;

static const char *help_text =
"./executable: A tiny UTF-8 terminal text editor\n"
"\n"
"Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.\n"
"Specify file paths to edit as a command argument or run without argument to\n"
"start to write a new text.\n"
"Help can show up with key mapping Ctrl-?.\n"
"\n"
"Usage:\n"
"    ./executable [options] [FILES...]\n"
"\n"
"Mappings:\n"
"    Ctrl-Q                        : Quit\n"
"    Ctrl-S                        : Save to file\n"
"    Ctrl-O                        : Open text buffer\n"
"    Ctrl-X                        : Next text buffer\n"
"    Alt-X                         : Previous text buffer\n"
"    Ctrl-P or UP                  : Move cursor up\n"
"    Ctrl-N or DOWN                : Move cursor down\n"
"    Ctrl-F or RIGHT               : Move cursor right\n"
"    Ctrl-B or LEFT                : Move cursor left\n"
"    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line\n"
"    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line\n"
"    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page\n"
"    Ctrl-] or Alt-V or PAGE UP    : Previous page\n"
"    Alt-F or Ctrl-RIGHT           : Move cursor to next word\n"
"    Alt-B or Ctrl-LEFT            : Move cursor to previous word\n"
"    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph\n"
"    Alt-P or Ctrl-UP              : Move cursor to previous paragraph\n"
"    Alt-<                         : Move cursor to top of file\n"
"    Alt->                         : Move cursor to bottom of file\n"
"    Ctrl-H or BACKSPACE           : Delete character\n"
"    Ctrl-D or DELETE              : Delete next character\n"
"    Ctrl-W                        : Delete a word\n"
"    Ctrl-J                        : Delete until head of line\n"
"    Ctrl-K                        : Delete until end of line\n"
"    Ctrl-U                        : Undo last change\n"
"    Ctrl-R                        : Redo last undo change\n"
"    Ctrl-G                        : Search text\n"
"    Ctrl-M                        : New line\n"
"    Ctrl-L                        : Refresh screen\n"
"    Ctrl-?                        : Show this help\n"
"\n"
"Options:\n"
"    -v, --version       Print version\n"
"    -h, --help          Print this help\n";

struct abuf { char *b; int len; };
#define ABUF_INIT {NULL, 0}

static buffer *B(void) { return &E.bufs[E.curbuf]; }
static void editorMoveCursor(int key);

static void abAppend(struct abuf *ab, const char *s, int len) {
  char *new = realloc(ab->b, ab->len + len);
  if (!new) return;
  memcpy(&new[ab->len], s, len);
  ab->b = new;
  ab->len += len;
}
static void abFree(struct abuf *ab) { free(ab->b); }

static void die(const char *s) {
  write(STDOUT_FILENO, "\x1b[?1049l\x1b[H", 12);
  perror(s);
  exit(1);
}

static void disableRawMode(void) {
  tcsetattr(STDIN_FILENO, TCSAFLUSH, &E.orig_termios);
}

static void enableRawMode(void) {
  if (tcgetattr(STDIN_FILENO, &E.orig_termios) == -1) {
    fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
    exit(1);
  }
  atexit(disableRawMode);
  struct termios raw = E.orig_termios;
  raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
  raw.c_oflag &= ~(OPOST);
  raw.c_cflag |= (CS8);
  raw.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);
  raw.c_cc[VMIN] = 0;
  raw.c_cc[VTIME] = 1;
  if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) == -1) die("tcsetattr");
}

static int editorReadKey(void) {
  int nread;
  char c;
  while ((nread = read(STDIN_FILENO, &c, 1)) != 1) {
    if (nread == -1 && errno != EAGAIN) die("read");
  }
  if (c == '\x1b') {
    char seq[3];
    if (read(STDIN_FILENO, &seq[0], 1) != 1) return '\x1b';
    if (read(STDIN_FILENO, &seq[1], 1) != 1) return '\x1b';
    if (seq[0] == '[') {
      if (seq[1] >= '0' && seq[1] <= '9') {
        if (read(STDIN_FILENO, &seq[2], 1) != 1) return '\x1b';
        if (seq[2] == '~') {
          switch (seq[1]) {
            case '1': case '7': return HOME_KEY;
            case '3': return DEL_KEY;
            case '4': case '8': return END_KEY;
            case '5': return PAGE_UP;
            case '6': return PAGE_DOWN;
          }
        }
      } else {
        switch (seq[1]) {
          case 'A': return ARROW_UP;
          case 'B': return ARROW_DOWN;
          case 'C': return ARROW_RIGHT;
          case 'D': return ARROW_LEFT;
          case 'H': return HOME_KEY;
          case 'F': return END_KEY;
        }
      }
    } else if (seq[0] == 'O') {
      switch (seq[1]) { case 'H': return HOME_KEY; case 'F': return END_KEY; }
    }
    return '\x1b';
  }
  return c;
}

static int getWindowSize(int *rows, int *cols) {
  struct winsize ws;
  if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == -1 || ws.ws_col == 0) return -1;
  *cols = ws.ws_col; *rows = ws.ws_row;
  return 0;
}

static void editorSetStatusMessage(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(E.statusmsg, sizeof(E.statusmsg), fmt, ap);
  va_end(ap);
  E.statusmsg_time = time(NULL);
}

static void rowInsertChar(erow *row, int at, int c) {
  if (at < 0 || at > row->size) at = row->size;
  row->chars = realloc(row->chars, row->size + 2);
  memmove(&row->chars[at + 1], &row->chars[at], row->size - at + 1);
  row->size++;
  row->chars[at] = c;
}
static void rowAppendString(erow *row, char *s, size_t len) {
  row->chars = realloc(row->chars, row->size + len + 1);
  memcpy(&row->chars[row->size], s, len);
  row->size += len;
  row->chars[row->size] = '\0';
}
static void rowDelChar(erow *row, int at) {
  if (at < 0 || at >= row->size) return;
  memmove(&row->chars[at], &row->chars[at + 1], row->size - at);
  row->size--;
}
static void editorInsertRow(buffer *b, int at, char *s, size_t len) {
  if (at < 0 || at > b->numrows) return;
  b->row = realloc(b->row, sizeof(erow) * (b->numrows + 1));
  memmove(&b->row[at + 1], &b->row[at], sizeof(erow) * (b->numrows - at));
  b->row[at].size = (int)len;
  b->row[at].chars = malloc(len + 1);
  memcpy(b->row[at].chars, s, len);
  b->row[at].chars[len] = '\0';
  b->numrows++;
}
static void editorFreeRows(buffer *b) {
  for (int j = 0; j < b->numrows; j++) free(b->row[j].chars);
  free(b->row);
}
static void editorDelRow(buffer *b, int at) {
  if (at < 0 || at >= b->numrows) return;
  free(b->row[at].chars);
  memmove(&b->row[at], &b->row[at + 1], sizeof(erow) * (b->numrows - at - 1));
  b->numrows--;
}

static void editorInsertChar(int c) {
  buffer *b = B();
  if (E.cy == b->numrows) editorInsertRow(b, b->numrows, "", 0);
  rowInsertChar(&b->row[E.cy], E.cx, c);
  E.cx++; b->dirty++;
}
static void editorInsertNewline(void) {
  buffer *b = B();
  if (E.cx == 0) {
    editorInsertRow(b, E.cy, "", 0);
  } else {
    erow *row = &b->row[E.cy];
    editorInsertRow(b, E.cy + 1, &row->chars[E.cx], row->size - E.cx);
    row = &b->row[E.cy];
    row->size = E.cx;
    row->chars[row->size] = '\0';
  }
  E.cy++; E.cx = 0; b->dirty++;
}
static void editorDelChar(void) {
  buffer *b = B();
  if (E.cy == b->numrows) return;
  if (E.cx == 0 && E.cy == 0) return;
  erow *row = &b->row[E.cy];
  if (E.cx > 0) { rowDelChar(row, E.cx - 1); E.cx--; }
  else {
    E.cx = b->row[E.cy - 1].size;
    rowAppendString(&b->row[E.cy - 1], row->chars, row->size);
    editorDelRow(b, E.cy);
    E.cy--;
  }
  b->dirty++;
}
static void editorDelForward(void) {
  int oldcx = E.cx, oldcy = E.cy;
  editorMoveCursor(ARROW_RIGHT);
  if (oldcx != E.cx || oldcy != E.cy) editorDelChar();
}

static void editorOpenInto(buffer *b, const char *filename) {
  free(b->filename);
  b->filename = strdup(filename);
  FILE *fp = fopen(filename, "r");
  if (!fp) {
    b->dirty = 0;
    return;
  }
  char *line = NULL;
  size_t linecap = 0;
  ssize_t linelen;
  while ((linelen = getline(&line, &linecap, fp)) != -1) {
    while (linelen > 0 && (line[linelen - 1] == '\n' || line[linelen - 1] == '\r')) linelen--;
    editorInsertRow(b, b->numrows, line, linelen);
  }
  free(line);
  fclose(fp);
  b->dirty = 0;
}
static char *editorRowsToString(buffer *b, int *buflen) {
  int totlen = 0;
  for (int j = 0; j < b->numrows; j++) totlen += b->row[j].size + 1;
  *buflen = totlen;
  char *buf = malloc(totlen ? totlen : 1), *p = buf;
  for (int j = 0; j < b->numrows; j++) {
    memcpy(p, b->row[j].chars, b->row[j].size);
    p += b->row[j].size;
    *p = '\n'; p++;
  }
  return buf;
}
static void editorSave(void) {
  buffer *b = B();
  if (b->filename == NULL) return;
  int len;
  char *buf = editorRowsToString(b, &len);
  int fd = open(b->filename, O_RDWR | O_CREAT, 0644);
  if (fd != -1) {
    if (ftruncate(fd, len) != -1 && write(fd, buf, len) == len) {
      close(fd);
      free(buf);
      b->dirty = 0;
      editorSetStatusMessage("%d bytes written to %s", len, b->filename);
      return;
    }
    close(fd);
  }
  free(buf);
  editorSetStatusMessage("Can't save! I/O error: %s", strerror(errno));
}

static void editorScroll(void) {
  if (E.cy < E.rowoff) E.rowoff = E.cy;
  if (E.cy >= E.rowoff + E.screenrows) E.rowoff = E.cy - E.screenrows + 1;
  if (E.cx < E.coloff) E.coloff = E.cx;
  if (E.cx >= E.coloff + E.screencols) E.coloff = E.cx - E.screencols + 1;
}
static void editorDrawRows(struct abuf *ab) {
  buffer *b = B();
  for (int y = 0; y < E.screenrows; y++) {
    int filerow = y + E.rowoff;
    if (filerow >= b->numrows) {
      abAppend(ab, "\x1b[37m~\x1b[39;0m", 13);
      if (b->numrows == 0 && y == E.screenrows / 3) {
        char welcome[80];
        int welcomelen = snprintf(welcome, sizeof(welcome), "Kiro editor -- version %s", KI_VERSION);
        int padding = (E.screencols - welcomelen) / 2;
        if (padding) { abAppend(ab, " ", 1); padding--; }
        while (padding-- > 0) abAppend(ab, " ", 1);
        abAppend(ab, welcome, welcomelen);
      }
    } else {
      int len = b->row[filerow].size - E.coloff;
      if (len < 0) len = 0;
      if (len > E.screencols) len = E.screencols;
      abAppend(ab, &b->row[filerow].chars[E.coloff], len);
      abAppend(ab, "\x1b[39;0m", 7);
    }
    abAppend(ab, "\x1b[K", 3);
    abAppend(ab, "\r\n", 2);
  }
}
static void editorDrawStatusBar(struct abuf *ab) {
  buffer *b = B();
  abAppend(ab, "\x1b[7m", 4);
  char status[256], rstatus[80];
  const char *name = b->filename ? b->filename : "[No Name]";
  int len = snprintf(status, sizeof(status), "\"%s\" - %d/%d%s", name, E.curbuf + 1, E.numbufs, b->dirty ? " (modified)" : "");
  int rlen = snprintf(rstatus, sizeof(rstatus), "plain %d/%d", E.cy + 1, b->numrows ? b->numrows : 1);
  if (len > E.screencols) len = E.screencols;
  abAppend(ab, status, len);
  while (len < E.screencols) {
    if (E.screencols - len == rlen) { abAppend(ab, rstatus, rlen); break; }
    abAppend(ab, " ", 1); len++;
  }
  abAppend(ab, "\x1b[39;0m", 7);
  abAppend(ab, "\r\n", 2);
}
static void editorDrawMessageBar(struct abuf *ab) {
  abAppend(ab, "\x1b[K", 3);
  int msglen = strlen(E.statusmsg);
  if (msglen > E.screencols) msglen = E.screencols;
  if (msglen && time(NULL) - E.statusmsg_time < 5) abAppend(ab, E.statusmsg, msglen);
}
static void editorRefreshScreen(void) {
  editorScroll();
  struct abuf ab = ABUF_INIT;
  abAppend(&ab, "\x1b[?25l", 6);
  abAppend(&ab, "\x1b[39;0m", 7);
  abAppend(&ab, "\x1b[H", 3);
  editorDrawRows(&ab);
  editorDrawStatusBar(&ab);
  editorDrawMessageBar(&ab);
  char buf[32];
  snprintf(buf, sizeof(buf), "\x1b[%d;%dH", (E.cy - E.rowoff) + 1, (E.cx - E.coloff) + 1);
  abAppend(&ab, buf, strlen(buf));
  abAppend(&ab, "\x1b[?25h", 6);
  write(STDOUT_FILENO, ab.b, ab.len);
  abFree(&ab);
}

static char *editorPrompt(const char *prompt) {
  size_t bufsz = 128, len = 0;
  char *buf = malloc(bufsz);
  buf[0] = '\0';
  while (1) {
    editorSetStatusMessage(prompt, buf);
    editorRefreshScreen();
    int c = editorReadKey();
    if (c == '\r') {
      if (len != 0) { E.statusmsg[0] = '\0'; return buf; }
    } else if (c == '\x1b' || c == CTRL_KEY('g')) {
      E.statusmsg[0] = '\0'; free(buf); return NULL;
    } else if (c == DEL_KEY || c == CTRL_KEY('h') || c == 127) {
      if (len != 0) buf[--len] = '\0';
    } else if (!iscntrl(c) && c < 128) {
      if (len == bufsz - 1) { bufsz *= 2; buf = realloc(buf, bufsz); }
      buf[len++] = c; buf[len] = '\0';
    }
  }
}

static void editorOpenPrompt(void) {
  char *filename = editorPrompt("Open: %s (^G or ESC to cancel)");
  if (!filename) return;
  E.bufs = realloc(E.bufs, sizeof(buffer) * (E.numbufs + 1));
  E.curbuf = E.numbufs++;
  E.bufs[E.curbuf] = (buffer){0};
  editorOpenInto(B(), filename);
  free(filename);
  E.cx = E.cy = E.rowoff = E.coloff = 0;
}

static void editorSavePrompt(void) {
  if (B()->filename == NULL) {
    char *filename = editorPrompt("Save as: %s (^G or ESC to cancel)");
    if (!filename) { editorSetStatusMessage("Save aborted"); return; }
    B()->filename = filename;
  }
  editorSave();
}

static void editorMoveCursor(int key) {
  buffer *b = B();
  erow *row = (E.cy >= b->numrows) ? NULL : &b->row[E.cy];
  switch (key) {
    case ARROW_LEFT: case CTRL_KEY('b'):
      if (E.cx != 0) E.cx--;
      else if (E.cy > 0) { E.cy--; E.cx = b->row[E.cy].size; }
      break;
    case ARROW_RIGHT: case CTRL_KEY('f'):
      if (row && E.cx < row->size) E.cx++;
      else if (row && E.cx == row->size) { E.cy++; E.cx = 0; }
      break;
    case ARROW_UP: case CTRL_KEY('p'):
      if (E.cy != 0) E.cy--;
      break;
    case ARROW_DOWN: case CTRL_KEY('n'):
      if (E.cy < b->numrows) E.cy++;
      break;
  }
  row = (E.cy >= b->numrows) ? NULL : &b->row[E.cy];
  int rowlen = row ? row->size : 0;
  if (E.cx > rowlen) E.cx = rowlen;
}

static int anyDirty(void) {
  for (int i = 0; i < E.numbufs; i++) if (E.bufs[i].dirty) return 1;
  return 0;
}

static void editorShowHelp(void) {
  editorSetStatusMessage("Help is available with --help");
}

static void editorProcessKeypress(void) {
  static int quit_times = 1;
  int c = editorReadKey();
  switch (c) {
    case CTRL_KEY('q'):
      if (anyDirty() && quit_times > 0) {
        editorSetStatusMessage("\x1b[97m\x1b[41mAt least one file has unsaved changes! Press ^Q again to quit or ^S to save\x1b[39;0m");
        quit_times--;
        return;
      }
      write(STDOUT_FILENO, "\x1b[?1049l\x1b[H", 12);
      exit(0);
    case CTRL_KEY('s'): editorSavePrompt(); break;
    case CTRL_KEY('o'): editorOpenPrompt(); break;
    case CTRL_KEY('x'):
      if (E.numbufs > 1) { E.curbuf = (E.curbuf + 1) % E.numbufs; E.cx = E.cy = E.rowoff = E.coloff = 0; }
      break;
    case CTRL_KEY('m'): editorInsertNewline(); break;
    case CTRL_KEY('h'): case 127: editorDelChar(); break;
    case CTRL_KEY('d'): case DEL_KEY: editorDelForward(); break;
    case CTRL_KEY('a'): case HOME_KEY: E.cx = 0; break;
    case CTRL_KEY('e'): case END_KEY:
      if (E.cy < B()->numrows) E.cx = B()->row[E.cy].size;
      break;
    case PAGE_UP:
      E.cy = E.rowoff;
      for (int times = E.screenrows; times--;) editorMoveCursor(ARROW_UP);
      break;
    case PAGE_DOWN:
      E.cy = E.rowoff + E.screenrows - 1;
      if (E.cy > B()->numrows) E.cy = B()->numrows;
      for (int times = E.screenrows; times--;) editorMoveCursor(ARROW_DOWN);
      break;
    case ARROW_UP: case ARROW_DOWN: case ARROW_LEFT: case ARROW_RIGHT:
    case CTRL_KEY('p'): case CTRL_KEY('n'): case CTRL_KEY('b'): case CTRL_KEY('f'):
      editorMoveCursor(c);
      break;
    case CTRL_KEY('l'): break;
    case 127 & 0x1f: editorShowHelp(); break;
    case CTRL_KEY('g'): editorSetStatusMessage("Search is not available in this build"); break;
    default:
      if (!iscntrl(c) && c < 256) editorInsertChar(c);
      break;
  }
  quit_times = 1;
}

static void initEditor(void) {
  E.cx = E.cy = E.rowoff = E.coloff = 0;
  E.numbufs = 1; E.curbuf = 0;
  E.bufs = calloc(1, sizeof(buffer));
  if (getWindowSize(&E.screenrows, &E.screencols) == -1) die("getWindowSize");
  E.screenrows -= 2;
  editorSetStatusMessage("Ctrl-? for help");
}

static void usage_version_or_errors(int argc, char **argv, int *first_file) {
  *first_file = argc;
  int after_dashdash = 0;
  for (int i = 1; i < argc; i++) {
    if (after_dashdash || argv[i][0] != '-' || !argv[i][1]) {
      if (*first_file == argc) *first_file = i;
      continue;
    }
    if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { fputs(help_text, stdout); exit(0); }
    if (!strcmp(argv[i], "-v") || !strcmp(argv[i], "--version")) { puts(KI_VERSION); exit(0); }
    if (!strcmp(argv[i], "--")) { after_dashdash = 1; continue; }
    const char *opt = argv[i] + 1;
    if (opt[0] == '-') opt++;
    fprintf(stderr, "Error: Unrecognized option: '%s'. Please see --help for more details\n", opt);
    exit(1);
  }
}

int main(int argc, char **argv) {
  int first_file;
  usage_version_or_errors(argc, argv, &first_file);
  enableRawMode();
  initEditor();
  if (first_file < argc) {
    E.numbufs = argc - first_file;
    free(E.bufs);
    E.bufs = calloc(E.numbufs, sizeof(buffer));
    for (int i = first_file; i < argc; i++) editorOpenInto(&E.bufs[i - first_file], argv[i]);
  }
  write(STDOUT_FILENO, "\x1b[?1049h", 8);
  while (1) {
    editorRefreshScreen();
    editorProcessKeypress();
  }
}
