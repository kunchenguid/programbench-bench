#!/usr/bin/env python3
import base64
import gzip
import http.client
import json
import socket
import ssl
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

VERSION = "0.1.0"

HELP = """bat is a Go implemented CLI cURL-like tool for humans.

Usage:

\tbat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

\tbat beego.me

more help information please refer to https://github.com/astaxie/bat
"""

METHODS = {"GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"}


def parse_bool(v):
    if v is None:
        return True
    return str(v).lower() not in ("0", "false", "f", "no", "n")


def parse_args(argv):
    opts = {
        "auth": "",
        "bench": False,
        "bench_n": 1000,
        "bench_c": 100,
        "body": "",
        "form": False,
        "json": True,
        "pretty": True,
        "insecure": False,
        "proxy": "",
        "print": "A",
        "download": False,
    }
    rest = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help", "-help"):
            print(HELP)
            sys.exit(0)
        if not a.startswith("-") or a == "-":
            rest.extend(argv[i:])
            break
        nameval = a[1:]
        if nameval.startswith("-"):
            nameval = nameval[1:]
        if "=" in nameval:
            name, val = nameval.split("=", 1)
        else:
            name, val = nameval, None
        if name in ("v", "version"):
            print(f"Version: {VERSION}")
            sys.exit(0)
        elif name in ("a", "auth"):
            if val is None:
                i += 1
                val = argv[i] if i < len(argv) else ""
            opts["auth"] = val
        elif name in ("b", "bench"):
            opts["bench"] = parse_bool(val)
        elif name == "b.N":
            opts["bench_n"] = int(val or "1000")
        elif name == "b.C":
            opts["bench_c"] = int(val or "100")
        elif name == "body":
            if val is None:
                i += 1
                val = argv[i] if i < len(argv) else ""
            opts["body"] = val
        elif name in ("f", "form"):
            opts["form"] = parse_bool(val)
        elif name in ("j", "json"):
            opts["json"] = parse_bool(val)
        elif name in ("p", "pretty"):
            opts["pretty"] = parse_bool(val)
        elif name in ("i", "insecure"):
            opts["insecure"] = parse_bool(val)
        elif name == "proxy":
            if val is None:
                i += 1
                val = argv[i] if i < len(argv) else ""
            opts["proxy"] = val
        elif name == "print":
            if val is None:
                i += 1
                val = argv[i] if i < len(argv) else "A"
            opts["print"] = val
        elif name == "download":
            opts["download"] = parse_bool(val)
        else:
            sys.stderr.write(f"flag provided but not defined: -{name}\n")
            sys.stderr.write(HELP + "\n")
            sys.exit(2)
        i += 1
    return opts, rest


def normalize_url(u):
    if not (u.startswith("http://") or u.startswith("https://")):
        u = "http://" + u
    return u


def split_invocation(rest):
    if not rest:
        print(HELP)
        sys.exit(0)
    if len(rest) >= 2 and rest[0].upper() in METHODS:
        return rest[0].upper(), normalize_url(rest[1]), rest[2:], True
    items = rest[1:]
    method = "POST" if items else "GET"
    return method, normalize_url(rest[0]), items, False


def build_request(method, url, items, explicit_method, opts):
    extra_headers = []
    data = []
    query = []
    for item in items:
        if ":" in item and item.find(":") > 0 and (("=" not in item) or item.find(":") < item.find("=")):
            k, v = item.split(":", 1)
            extra_headers.append((k, v))
        elif "@" in item and item.find("@") > 0 and "=" not in item:
            # The original largely ignores file upload arguments unless multipart support is used.
            continue
        elif "=" in item:
            k, v = item.split("=", 1)
            if explicit_method and method == "GET":
                query.append((k, v))
            else:
                data.append((k, v))
    if query:
        parts = urllib.parse.urlsplit(url)
        q = urllib.parse.urlencode(query)
        old = parts.query
        nq = (old + "&" + q) if old else q
        url = urllib.parse.urlunsplit((parts.scheme, parts.netloc, parts.path, nq, parts.fragment))
    body = None
    if opts["body"] != "":
        body = opts["body"].encode()
    elif data:
        if opts["form"]:
            body = urllib.parse.urlencode(data).encode()
            extra_headers.append(("Content-Type", "application/x-www-form-urlencoded"))
        else:
            obj = {k: v for k, v in data}
            body = (json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n").encode()
            extra_headers.append(("Content-Type", "application/json"))
    if opts["auth"]:
        auth = opts["auth"] if ":" in opts["auth"] else opts["auth"] + ":"
        extra_headers.append(("Authorization", "Basic " + base64.b64encode(auth.encode()).decode()))
    headers = [("User-Agent", f"bat/{VERSION}")]
    if body is not None:
        headers.append(("Content-Length", str(len(body))))
    elif method in ("POST", "PUT", "PATCH"):
        headers.append(("Content-Length", "0"))
    headers.extend([("Accept", "application/json"), ("Accept-Encoding", "gzip, deflate")])
    # Content-Type follows Accept-Encoding in the original; custom headers trail it.
    content_headers = [h for h in extra_headers if h[0].lower() == "content-type"]
    other_headers = [h for h in extra_headers if h[0].lower() != "content-type"]
    headers.extend(content_headers)
    headers.extend(other_headers)
    return method, url, headers, body


def request_once(method, url, headers, body, insecure=False, proxy=""):
    parts = urllib.parse.urlsplit(url)
    scheme = parts.scheme or "http"
    host = parts.hostname or ""
    port = parts.port
    path = urllib.parse.urlunsplit(("", "", parts.path or "/", parts.query, parts.fragment))
    conn_host, conn_port = host, port
    use_scheme = scheme
    if proxy:
        pp = urllib.parse.urlsplit(normalize_url(proxy))
        conn_host, conn_port = pp.hostname, pp.port
        path = url
        use_scheme = pp.scheme or "http"
    port = conn_port or (443 if use_scheme == "https" else 80)
    sock = socket.create_connection((conn_host, port), timeout=30)
    if use_scheme == "https":
        ctx = ssl._create_unverified_context() if insecure else ssl.create_default_context()
        sock = ctx.wrap_socket(sock, server_hostname=conn_host)
    req = [f"{method} {path} HTTP/1.0", f"Host: {parts.netloc}"]
    req.extend([f"{k}: {v}" for k, v in headers])
    req.append("")
    req.append("")
    payload = "\r\n".join(req).encode() + (body or b"")
    sock.sendall(payload)
    chunks = []
    while True:
        chunk = sock.recv(65536)
        if not chunk:
            break
        chunks.append(chunk)
    sock.close()
    data = b"".join(chunks)
    head, _, raw = data.partition(b"\r\n\r\n")
    lines = head.decode("iso-8859-1", "replace").split("\r\n")
    try:
        status = int(lines[0].split()[1])
    except Exception:
        status = 0
    resp_headers = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            resp_headers[k.strip()] = v.strip()
    if resp_headers.get("Transfer-Encoding", "").lower() == "chunked":
        raw = decode_chunked(raw)
    if resp_headers.get("Content-Encoding", "") == "gzip":
        raw = gzip.decompress(raw)
    return status, resp_headers, raw


def decode_chunked(data):
    out = b""
    i = 0
    while True:
        j = data.find(b"\r\n", i)
        if j < 0:
            break
        line = data[i:j].split(b";", 1)[0]
        try:
            n = int(line, 16)
        except ValueError:
            break
        i = j + 2
        if n == 0:
            break
        out += data[i:i+n]
        i += n + 2
    return out


def print_response(raw, pretty):
    text = raw.decode("utf-8", "replace")
    if pretty:
        try:
            parsed = json.loads(text)
            text = json.dumps(parsed, indent=2)
        except Exception:
            pass
    sys.stdout.write("\n")
    sys.stdout.write(text)
    if not text.endswith("\n"):
        sys.stdout.write("\n")


def bench(method, url, headers, body, opts):
    n = max(1, opts["bench_n"])
    c = max(1, opts["bench_c"])
    times = []
    statuses = {}
    sizes = []
    start = time.time()
    def one():
        t = time.time()
        try:
            st, _, raw = request_once(method, url, headers, body, opts["insecure"], opts["proxy"])
            return time.time() - t, st, len(raw)
        except Exception:
            return time.time() - t, 0, 0
    with ThreadPoolExecutor(max_workers=c) as ex:
        futs = [ex.submit(one) for _ in range(n)]
        for fut in as_completed(futs):
            dt, st, sz = fut.result()
            times.append(dt); statuses[st] = statuses.get(st, 0) + 1; sizes.append(sz)
    total = max(time.time() - start, 0.000001)
    slow = max(times) if times else 0
    fast = min(times) if times else 0
    avg = sum(times) / len(times) if times else 0
    total_bytes = sum(sizes)
    per = sizes[0] if sizes else 0
    print("Summary:")
    print(f"  Total:\t{total:.4f} secs.")
    print(f"  Slowest:\t{slow:.4f} secs.")
    print(f"  Fastest:\t{fast:.4f} secs.")
    print(f"  Average:\t{avg:.4f} secs.")
    print(f"  Requests/sec:\t{(n/total):.4f}")
    print(f"  Total Data Received:\t{total_bytes} bytes.")
    print(f"  Response Size per Request:\t{per} bytes.")
    print()
    print("Status code distribution:")
    for st in sorted(statuses):
        print(f"  [{st}]\t{statuses[st]} responses")


def main():
    opts, rest = parse_args(sys.argv[1:])
    method, url, items, explicit = split_invocation(rest)
    method, url, headers, body = build_request(method, url, items, explicit, opts)
    if opts["bench"]:
        bench(method, url, headers, body, opts)
        return
    try:
        _, _, raw = request_once(method, url, headers, body, opts["insecure"], opts["proxy"])
    except Exception as e:
        sys.stderr.write(f"can't get the url {e}\n")
        sys.exit(1)
    print_response(raw, opts["pretty"])


if __name__ == "__main__":
    main()
