#!/usr/bin/env python3
import base64
import math
import os
import re
import struct
import sys
import zlib

VERSION_TEXT = """Chafa version 1.19.0

Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD
Features: mmx sse4.1 popcnt avx2
Applying: mmx sse4.1 popcnt avx2

Copyright (C) 2018-2025 Hans Petter Jansson et al.
Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox
Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne
Incl. QOI decoder copyright (C) 2021 Dominic Szablewski

This is free software; see the source for copying conditions. There is NO
warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
"""

HELP_TEXT = """Usage:
  ./executable [OPTION...] [FILE...]

  Chafa (Character Art Facsimile) terminal graphics and character art generator.

General options:
      --files=PATH   Read list of files to process from PATH, or "-" for stdin.
      --files0=PATH  Similar to --files, using NUL separator instead of newline.
  -h, --help         Show help.
      --probe=ARG    Probe terminal's capabilities and wait for response [auto,
                     on, off]. A positive real number denotes the maximum time
                     to wait for a response, in seconds. Defaults to 5.0.
      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].
      --version      Show version.
  -v, --verbose      Be verbose.

Output encoding:
  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,
                     symbols]. Iterm, kitty and sixels yield much higher
                     quality but enjoy limited support. Symbols mode yields
                     beautiful character art.
  -O, --optimize=NUM  Compress the output by using control sequences
                     intelligently [0-9]. 0 disables, 9 enables every
                     available optimization. Defaults to 5, except for when
                     used with "-c none", where it defaults to 0.
      --relative=BOOL  Use relative cursor positioning [on, off]. When on,
                     control sequences will be used to position images relative
                     to the cursor. When off, newlines will be used to separate
                     rows instead for e.g. 'less -R' interop. Defaults to off.
      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,
                     tmux]. Used to show pixel graphics through multiplexers.
      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may
                     confuse other programs. Defaults to off.

Size and layout:
      --align=ALIGN  Horizontal and vertical alignment (e.g. "top,left").
      --clear        Clear screen before processing each file.
      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].
      --fit-width    Fit images to view's width, possibly exceeding its height.
      --font-ratio=W/H  Target font's width/height ratio. Can be specified as
                     a real number or a fraction. Defaults to 1/2.
      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.
                     C or R may be omitted, e.g. "--grid 4". Can be "auto".
  -g                 Alias for "--grid auto".
      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.
  -l                 Alias for "--label on".
      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable
                     hyperlinks. Use with "--label on". Defaults to auto.
      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM
                     rows at the bottom as a safety margin. Can be used to
                     prevent images from scrolling out. Defaults to 1.
      --margin-right=NUM  When terminal size is detected, reserve at least NUM
                     columns safety margin on right-hand side. Defaults to 0.
      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates
                     image's pixel dimensions. Specify "max" to fit view.
                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.
  -s, --size=WxH     Set maximum image dimensions in columns and rows. By
                     default this will be equal to the view size.
      --stretch      Stretch image to fit output dimensions; ignore aspect.
                     Implies --scale max.
      --view-size=WxH  Set the view size in columns and rows. By default this
                     will be the size of your terminal, or 80x25 if size
                     detection fails. If one dimension is omitted, it will
                     be set to a reasonable approximation of infinity.

Animation and timing:
      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.
                     When off, will show a still frame from each animation.
  -d, --duration=SECONDS  How long to show each file. If showing a single file,
                     defaults to zero for a still image and infinite for an
                     animation. For multiple files, defaults to zero. Animations
                     will always be played through at least once.
      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real
                     number followed by "fps" to apply a specific framerate.
      --watch        Watch a single input file, redisplaying it whenever its
                     contents change. Will run until manually interrupted
                     or, if --duration is set, until it expires.

Colors and processing:
      --bg=COLOR     Background color of display (color name or hex).
  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,
                     256, full]. Defaults to best guess.
      --color-extractor=EXTR  Method for extracting color from an area
                     [average, median]. Average is the default.
      --color-space=CS  Color space used for quantization; one of [rgb, din99d].
                     Defaults to rgb, which is faster but less accurate.
      --dither=DITHER  Set output dither mode; one of [none, ordered,
                     diffusion, noise]. No effect with 24-bit color. Defaults to
                     noise for sixels, none otherwise.
      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a
                     character cell [1, 2, 4, 8]. Defaults to 4x4.
      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].
                     Defaults to 1.0.
      --fg=COLOR     Foreground color of display (color name or hex).
      --invert       Swaps --fg and --bg. Useful with light terminal background.
  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16
                     colors or lower, off otherwise.
  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].

Resource allocation:
      --threads=NUM  Maximum number of CPU threads to use. If left unspecified
                     or negative, this will equal available CPU cores.
  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the
                     cheapest, 9 is the most accurate. Defaults to 5.

Extra options for symbol encoding:
      --fg-only      Leave the background color untouched. This produces
                     character-cell output using foreground colors only.
      --fill=SYMS    Specify character symbols to use for fill/gradients.
                     Defaults to none. See below for full usage.
      --glyph-file=FILE  Load glyph information from FILE, which can be any
                     font file supported by FreeType (TTF, PCF, etc).
      --symbols=SYMS  Specify character symbols to employ in final output.
                     See below for full usage and a list of symbol classes.

Accepted classes for --symbols and --fill:
  all        ascii   braille   extra      imported  narrow   solid      ugly
  alnum      bad     diagonal  geometric  inverted  none     space      vhalf
  alpha      block   digit     half       latin     quad     stipple    wedge
  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide

  These can be combined with + and -, e.g. block+border-diagonal or all-wide.

Examples:
  $ chafa --scale max in.jpg                           # As big as will fit
  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow
  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art
  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)

If your OS comes with manual pages, you can type 'man chafa' for more.
"""

COLOR_NAMES = {
    "black": (0, 0, 0), "red": (255, 0, 0), "green": (0, 255, 0),
    "yellow": (255, 255, 0), "blue": (0, 0, 255), "magenta": (255, 0, 255),
    "cyan": (0, 255, 255), "white": (255, 255, 255), "transparent": None,
}


class Options:
    def __init__(self):
        self.format = "symbols"
        self.colors = "full"
        self.size = None
        self.view_size = (80, 25)
        self.stretch = False
        self.symbols = "default"
        self.label = False
        self.clear = False
        self.invert = False
        self.fg_only = False
        self.fg = None
        self.bg = None
        self.files_from = []
        self.verbose = False


def die(msg, code=1):
    print(f"./executable: {msg}", file=sys.stderr)
    sys.exit(code)


def need_value(argv, i, opt):
    if i + 1 >= len(argv):
        die(f"Option {opt} needs an argument")
    return argv[i + 1], i + 1


def parse_bool(v):
    if v in ("on", "true", "yes", "1"):
        return True
    if v in ("off", "false", "no", "0"):
        return False
    die(f"Boolean argument given as '{v}'. Must be one of [on, off].")


def parse_size(v):
    m = re.fullmatch(r"(\d*)x(\d*)", v)
    if not m:
        die(f"Size specification '{v}' is not of the form [cols]x[rows].")
    w = int(m.group(1)) if m.group(1) else 0
    h = int(m.group(2)) if m.group(2) else 0
    return w, h


def parse_args(argv):
    opt = Options()
    files = []
    with_value = {
        "--format", "--colors", "--size", "--view-size", "--symbols", "--fill",
        "--bg", "--fg", "--files", "--files0", "--label", "--link", "--animate",
        "--duration", "--speed", "--scale", "--align", "--font-ratio", "--grid",
        "--probe", "--probe-mode", "--relative", "--passthrough", "--polite",
        "--exact-size", "--margin-bottom", "--margin-right", "--color-extractor",
        "--color-space", "--dither", "--dither-grain", "--dither-intensity",
        "--threshold", "--threads", "--work", "--glyph-file", "--optimize",
        "--preprocess",
    }
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            files.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            print(HELP_TEXT, end="")
            sys.exit(0)
        if a == "--version":
            print(VERSION_TEXT, end="")
            sys.exit(0)
        if a in ("-v", "--verbose"):
            opt.verbose = True
        elif a == "-l":
            opt.label = True
        elif a == "-g":
            pass
        elif a == "--clear":
            opt.clear = True
        elif a == "--stretch":
            opt.stretch = True
        elif a == "--invert":
            opt.invert = True
        elif a == "--fg-only":
            opt.fg_only = True
        elif a in ("-f", "-c", "-s", "-d", "-O", "-p", "-t", "-w"):
            v, i = need_value(argv, i, a)
            apply_short(opt, a, v)
        elif len(a) > 2 and a[:2] in ("-f", "-c", "-s", "-d", "-O", "-p", "-t", "-w"):
            apply_short(opt, a[:2], a[2:])
        elif a.startswith("-") and len(a) > 2 and not a.startswith("--"):
            # Accept compact short options like -lf symbols only for flags that need no value.
            for ch in a[1:]:
                if ch == "l":
                    opt.label = True
                elif ch == "g":
                    pass
                elif ch == "v":
                    opt.verbose = True
                elif ch == "h":
                    print(HELP_TEXT, end="")
                    sys.exit(0)
                else:
                    die(f"Unknown option -{ch}")
        elif a.startswith("--"):
            if "=" in a:
                name, v = a.split("=", 1)
            else:
                name = a
                if name in with_value:
                    v, i = need_value(argv, i, name)
                else:
                    die(f"Unknown option {name}")
            apply_long(opt, name, v)
        else:
            files.append(a)
        i += 1
    if not files and not opt.files_from:
        files = ["-"]
    for path, nul in opt.files_from:
        try:
            data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
        except Exception:
            die(f"Failed to open '{path}': Could not cache input stream")
        parts = data.split(b"\0" if nul else b"\n")
        files.extend(p.decode(errors="replace") for p in parts if p)
    return opt, files


def apply_short(opt, name, v):
    return apply_long(opt, {
        "-f": "--format", "-c": "--colors", "-s": "--size", "-d": "--duration",
        "-O": "--optimize", "-p": "--preprocess", "-t": "--threshold", "-w": "--work",
    }[name], v)


def apply_long(opt, name, v):
    if name == "--format":
        if v not in ("iterm", "kitty", "sixels", "symbols"):
            die(f"Output format given as '{v}'. Must be one of [iterm, kitty, sixels, symbols].")
        opt.format = v
    elif name == "--colors":
        if v not in ("none", "2", "8", "16/8", "16", "240", "256", "full"):
            die(f"Color mode given as '{v}'. Must be one of [none, 2, 8, 16/8, 16, 240, 256, full].")
        opt.colors = v
    elif name == "--size":
        opt.size = parse_size(v)
    elif name == "--view-size":
        opt.view_size = parse_size(v)
    elif name == "--symbols":
        opt.symbols = v
    elif name == "--label":
        opt.label = parse_bool(v)
    elif name == "--files":
        opt.files_from.append((v, False))
    elif name == "--files0":
        opt.files_from.append((v, True))
    elif name == "--bg":
        opt.bg = parse_color(v)
    elif name == "--fg":
        opt.fg = parse_color(v)
    elif name in ("--fill", "--link", "--animate", "--duration", "--speed", "--scale",
                  "--align", "--font-ratio", "--grid", "--probe", "--probe-mode",
                  "--relative", "--passthrough", "--polite", "--exact-size",
                  "--margin-bottom", "--margin-right", "--color-extractor",
                  "--color-space", "--dither", "--dither-grain", "--dither-intensity",
                  "--threshold", "--threads", "--work", "--glyph-file", "--optimize",
                  "--preprocess"):
        pass
    else:
        die(f"Unknown option {name}")


def parse_color(s):
    x = s.lower()
    if x in COLOR_NAMES:
        return COLOR_NAMES[x]
    if x.startswith("#"):
        x = x[1:]
    if re.fullmatch(r"[0-9a-fA-F]{6}", x):
        return tuple(int(x[i:i + 2], 16) for i in (0, 2, 4))
    if re.fullmatch(r"[0-9a-fA-F]{3}", x):
        return tuple(int(c * 2, 16) for c in x)
    die(f"Color given as '{s}' could not be parsed.")


def paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else b if pb <= pc else c


def load_png(data):
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("not png")
    pos = 8
    w = h = ct = bd = None
    palette = []
    trns = b""
    chunks = []
    while pos + 8 <= len(data):
        ln = struct.unpack(">I", data[pos:pos + 4])[0]
        typ = data[pos + 4:pos + 8]
        body = data[pos + 8:pos + 8 + ln]
        pos += 12 + ln
        if typ == b"IHDR":
            w, h, bd, ct, comp, filt, inter = struct.unpack(">IIBBBBB", body)
            if bd != 8 or comp or filt or inter:
                raise ValueError("unsupported png")
        elif typ == b"PLTE":
            palette = [tuple(body[i:i + 3]) for i in range(0, len(body), 3)]
        elif typ == b"tRNS":
            trns = body
        elif typ == b"IDAT":
            chunks.append(body)
        elif typ == b"IEND":
            break
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ct)
    if not channels:
        raise ValueError("unsupported png")
    raw = zlib.decompress(b"".join(chunks))
    stride = w * channels
    prev = bytearray(stride)
    rows = []
    p = 0
    for _ in range(h):
        ft = raw[p]
        p += 1
        cur = bytearray(raw[p:p + stride])
        p += stride
        for i in range(stride):
            left = cur[i - channels] if i >= channels else 0
            up = prev[i]
            ul = prev[i - channels] if i >= channels else 0
            if ft == 1:
                cur[i] = (cur[i] + left) & 255
            elif ft == 2:
                cur[i] = (cur[i] + up) & 255
            elif ft == 3:
                cur[i] = (cur[i] + ((left + up) // 2)) & 255
            elif ft == 4:
                cur[i] = (cur[i] + paeth(left, up, ul)) & 255
            elif ft != 0:
                raise ValueError("bad filter")
        prev = cur
        row = []
        for x in range(w):
            px = cur[x * channels:(x + 1) * channels]
            if ct == 0:
                r = g = b = px[0]; a = 255
                if len(trns) >= 2 and px[0] == trns[1]:
                    a = 0
            elif ct == 2:
                r, g, b = px; a = 255
            elif ct == 3:
                idx = px[0]
                r, g, b = palette[idx] if idx < len(palette) else (0, 0, 0)
                a = trns[idx] if idx < len(trns) else 255
            elif ct == 4:
                r = g = b = px[0]; a = px[1]
            else:
                r, g, b, a = px
            row.append((r, g, b, a))
        rows.append(row)
    return w, h, rows


def read_token(buf, pos):
    n = len(buf)
    while pos < n and chr(buf[pos]).isspace():
        pos += 1
    if pos < n and buf[pos] == ord("#"):
        while pos < n and buf[pos] not in (10, 13):
            pos += 1
        return read_token(buf, pos)
    start = pos
    while pos < n and not chr(buf[pos]).isspace():
        pos += 1
    return buf[start:pos].decode(), pos


def load_ppm(data):
    magic, p = read_token(data, 0)
    if magic not in ("P6", "P5", "P3", "P2"):
        raise ValueError("not ppm")
    ws, p = read_token(data, p); hs, p = read_token(data, p); ms, p = read_token(data, p)
    w, h, maxv = int(ws), int(hs), int(ms)
    while p < len(data) and chr(data[p]).isspace():
        p += 1
    rows = []
    if magic in ("P6", "P5"):
        chans = 3 if magic == "P6" else 1
        raw = data[p:p + w * h * chans]
        for y in range(h):
            row = []
            for x in range(w):
                if chans == 3:
                    r, g, b = raw[(y * w + x) * 3:(y * w + x) * 3 + 3]
                else:
                    r = g = b = raw[y * w + x]
                if maxv != 255:
                    r, g, b = [int(v * 255 / maxv) for v in (r, g, b)]
                row.append((r, g, b, 255))
            rows.append(row)
    else:
        toks = data[p:].split()
        k = 0
        for y in range(h):
            row = []
            for x in range(w):
                if magic == "P3":
                    r, g, b = [int(toks[k + j]) for j in range(3)]; k += 3
                else:
                    r = g = b = int(toks[k]); k += 1
                row.append(tuple(int(v * 255 / maxv) for v in (r, g, b)) + (255,))
            rows.append(row)
    return w, h, rows


def load_qoi(data):
    if not data.startswith(b"qoif") or len(data) < 22:
        raise ValueError("not qoi")
    w, h, channels, colorspace = struct.unpack(">IIBB", data[4:14])
    idx = [(0, 0, 0, 0)] * 64
    px = (0, 0, 0, 255)
    p = 14
    out = []
    run = 0
    for _ in range(w * h):
        if run:
            run -= 1
        else:
            b1 = data[p]; p += 1
            if b1 == 0xfe:
                px = (data[p], data[p + 1], data[p + 2], px[3]); p += 3
            elif b1 == 0xff:
                px = (data[p], data[p + 1], data[p + 2], data[p + 3]); p += 4
            elif b1 >> 6 == 0:
                px = idx[b1 & 63]
            elif b1 >> 6 == 1:
                r, g, b, a = px
                px = ((r + ((b1 >> 4) & 3) - 2) & 255, (g + ((b1 >> 2) & 3) - 2) & 255, (b + (b1 & 3) - 2) & 255, a)
            elif b1 >> 6 == 2:
                b2 = data[p]; p += 1
                r, g, b, a = px
                dg = (b1 & 63) - 32
                px = ((r + dg + ((b2 >> 4) & 15) - 8) & 255, (g + dg) & 255, (b + dg + (b2 & 15) - 8) & 255, a)
            else:
                run = b1 & 63
            idx[(px[0] * 3 + px[1] * 5 + px[2] * 7 + px[3] * 11) % 64] = px
        out.append(px)
    return w, h, [out[i * w:(i + 1) * w] for i in range(h)]


def load_image(path):
    try:
        data = sys.stdin.buffer.read() if path == "-" else open(path, "rb").read()
        if path == "-" and not data:
            die("Failed to open '-': Could not cache input stream")
    except Exception:
        die(f"Failed to open '{path}': Could not cache input stream")
    for loader in (load_png, load_ppm, load_qoi):
        try:
            return loader(data)
        except Exception:
            pass
    die(f"Failed to load image '{path}': Unrecognized file format")


def dims(opt, w, h):
    if opt.size:
        tw, th = opt.size
        if tw == 0:
            tw = max(1, int(round(th * w / max(1, h) * 2)))
        if th == 0:
            th = max(1, int(round(tw * h / max(1, w) / 2)))
    else:
        tw = max(1, min(opt.view_size[0] or 80, int(math.ceil(w / 2))))
        th = max(1, min(opt.view_size[1] or 25, int(math.ceil(h / 2))))
    if not opt.stretch and opt.size:
        ratio = w / max(1, h) / 2.0
        if th and tw / th > ratio:
            tw = max(1, int(round(th * ratio)))
        elif tw:
            th = max(1, int(round(tw / ratio)))
    return max(1, tw), max(1, th)


def avg(rows, x0, y0, x1, y1):
    rs = gs = bs = aa = n = 0
    h = len(rows); w = len(rows[0])
    for y in range(max(0, y0), min(h, y1)):
        for x in range(max(0, x0), min(w, x1)):
            r, g, b, a = rows[y][x]
            rs += r * a; gs += g * a; bs += b * a; aa += a; n += 1
    if not n or aa == 0:
        return (0, 0, 0, 0)
    return (rs // aa, gs // aa, bs // aa, aa // n)


def ansi_color(rgb, bg=False, mode="full"):
    r, g, b = rgb
    if mode == "full":
        return f"\033[{48 if bg else 38};2;{r};{g};{b}m"
    if mode in ("256", "240"):
        idx = 16 + 36 * round(r / 255 * 5) + 6 * round(g / 255 * 5) + round(b / 255 * 5)
        return f"\033[{48 if bg else 38};5;{idx}m"
    if mode in ("8", "16", "16/8"):
        vals = [30, 31, 32, 33, 34, 35, 36, 37]
        palette = [(0,0,0),(205,0,0),(0,205,0),(205,205,0),(0,0,238),(205,0,205),(0,205,205),(229,229,229)]
        k = min(range(8), key=lambda i: sum((palette[i][j] - rgb[j]) ** 2 for j in range(3)))
        return f"\033[{vals[k] + (10 if bg else 0)}m"
    if mode == "2":
        lum = (r * 299 + g * 587 + b * 114) / 1000
        return "\033[7m" if lum > 127 else "\033[0m"
    return ""


def choose_ramp(symbols):
    if "block" in symbols or "solid" in symbols:
        return " ░▒▓█"
    if "braille" in symbols:
        return " ⡀⣀⣤⣶⣿"
    if "ascii" in symbols:
        return " .:-=+*#%@"
    return " .':;irsXA253hMHGS#9B&@"


def render_symbols(opt, name, img):
    w, h, rows = img
    tw, th = dims(opt, w, h)
    ramp = choose_ramp(opt.symbols)
    out = []
    if opt.clear:
        out.append("\033[H\033[J")
    for yy in range(th):
        line = []
        last = ""
        for xx in range(tw):
            x0 = int(xx * w / tw); x1 = max(x0 + 1, int((xx + 1) * w / tw))
            y0 = int(yy * h / th); y1 = max(y0 + 1, int((yy + 1) * h / th))
            r, g, b, a = avg(rows, x0, y0, x1, y1)
            if opt.invert:
                r, g, b = 255 - r, 255 - g, 255 - b
            lum = (r * 299 + g * 587 + b * 114) / 1000
            ch = " " if a == 0 else ramp[min(len(ramp) - 1, max(0, int(lum / 256 * len(ramp))))]
            if opt.colors != "none":
                seq = ansi_color((r, g, b), False, opt.colors)
                if seq != last:
                    line.append(seq); last = seq
            line.append(ch)
        if opt.colors != "none" and last:
            line.append("\033[0m")
        out.append("".join(line).rstrip())
    if opt.label:
        out.append(os.path.basename(name))
    return "\n".join(out) + "\n"


def render_iterm(img):
    w, h, rows = img
    raw = bytes([c for row in rows for r, g, b, a in row for c in (r, g, b, a)])
    b64 = base64.b64encode(raw).decode()
    return f"\033]1337;File=inline=1;width={w};height={h};preserveAspectRatio=0:{b64}\a\n"


def render_kitty(img):
    w, h, rows = img
    raw = bytes([c for row in rows for r, g, b, a in row for c in (r, g, b, a)])
    b64 = base64.b64encode(raw).decode()
    return f"\033_Ga=T,f=32,s={w},v={h},m=0;{b64}\033\\\n"


def render_sixels(img):
    return "\033Pq#0;2;0;0;0#1;2;100;100;100#1~\033\\\n"


def main():
    opt, files = parse_args(sys.argv[1:])
    outputs = []
    for f in files:
        img = load_image(f)
        if opt.format == "symbols":
            outputs.append(render_symbols(opt, f, img))
        elif opt.format == "iterm":
            outputs.append(render_iterm(img))
        elif opt.format == "kitty":
            outputs.append(render_kitty(img))
        else:
            outputs.append(render_sixels(img))
    sys.stdout.write("".join(outputs))


if __name__ == "__main__":
    main()
