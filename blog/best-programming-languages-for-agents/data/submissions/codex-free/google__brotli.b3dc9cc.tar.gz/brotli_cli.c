#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

typedef void* (*brotli_alloc_func)(void*, size_t);
typedef void (*brotli_free_func)(void*, void*);
typedef struct BrotliDecoderStateStruct BrotliDecoderState;
extern size_t BrotliEncoderMaxCompressedSize(size_t input_size);
extern int BrotliEncoderCompress(int quality, int lgwin, int mode, size_t input_size,
                                 const uint8_t input_buffer[], size_t* encoded_size,
                                 uint8_t encoded_buffer[]);
extern BrotliDecoderState* BrotliDecoderCreateInstance(brotli_alloc_func, brotli_free_func, void*);
extern void BrotliDecoderDestroyInstance(BrotliDecoderState*);
extern int BrotliDecoderDecompressStream(BrotliDecoderState*, size_t*, const uint8_t**,
                                         size_t*, uint8_t**, size_t*);
extern const char* BrotliDecoderErrorString(int);
extern int BrotliDecoderGetErrorCode(const BrotliDecoderState*);

enum { DEC_ERROR = 0, DEC_SUCCESS = 1, DEC_NEEDS_MORE_INPUT = 2, DEC_NEEDS_MORE_OUTPUT = 3 };

typedef struct {
  int decompress, test, force, remove_src, copy_stat, stdout_out, verbose;
  int quality, lgwin, large_window, concatenated, squash;
  char *output, *suffix, *dict;
  uint8_t comment[81];
  size_t comment_len;
  char **files;
  int nfiles, capfiles;
} Options;

static const char help_text[] =
"Usage: executable [OPTION]... [FILE]...\n"
"Options:\n"
"  -#                          compression level (0-9)\n"
"  -c, --stdout                write on standard output\n"
"  -d, --decompress            decompress\n"
"  -f, --force                 force output file overwrite\n"
"  -h, --help                  display this help and exit\n"
"  -j, --rm                    remove source file(s)\n"
"  -s, --squash                remove destination file if larger than source\n"
"  -k, --keep                  keep source file(s) (default)\n"
"  -n, --no-copy-stat          do not copy source file(s) attributes\n"
"  -o FILE, --output=FILE      output file (only if 1 input file)\n"
"  -q NUM, --quality=NUM       compression level (0-11)\n"
"  -t, --test                  test compressed file integrity\n"
"  -v, --verbose               verbose mode\n"
"  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)\n"
"                              window size = 2**NUM - 16\n"
"                              0 lets compressor choose the optimal value\n"
"  --large_window=NUM          use incompatible large-window brotli\n"
"                              bitstream with window size (0, 10-30)\n"
"                              WARNING: this format is not compatible\n"
"                              with brotli RFC 7932 and may not be\n"
"                              decodable with regular brotli decoders\n"
"  -C B64, --comment=B64       set comment; argument is base64-decoded first;\n"
"                              (maximal decoded length: 80)\n"
"                              when decoding: check stream comment;\n"
"                              when encoding: embed comment (fingerprint)\n"
"  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary\n"
"  -K, --concatenated          allows concatenated brotli streams as input\n"
"  -S SUF, --suffix=SUF        output file suffix (default:'.br')\n"
"  -V, --version               display version and exit\n"
"  -Z, --best                  use best compression level (11) (default)\n"
"Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.\n"
"With no FILE, or when FILE is -, read standard input.\n"
"All arguments after '--' are treated as files.\n";

static void usage_err(const char *fmt, const char *arg) {
  if (arg) fprintf(stderr, fmt, arg); else fputs(fmt, stderr);
  fputc('\n', stderr);
  fputs(help_text, stderr);
}

static int add_file(Options *o, char *s) {
  if (o->nfiles == o->capfiles) {
    int nc = o->capfiles ? o->capfiles * 2 : 8;
    char **nf = realloc(o->files, (size_t)nc * sizeof(char*));
    if (!nf) return 0;
    o->files = nf; o->capfiles = nc;
  }
  o->files[o->nfiles++] = s;
  return 1;
}

static int parse_int(const char *s, int *out) {
  char *e = NULL; long v;
  if (!s || !*s) return 0;
  errno = 0; v = strtol(s, &e, 10);
  if (errno || *e) return 0;
  *out = (int)v; return 1;
}

static int b64val(int c) {
  if (c >= 'A' && c <= 'Z') return c - 'A';
  if (c >= 'a' && c <= 'z') return c - 'a' + 26;
  if (c >= '0' && c <= '9') return c - '0' + 52;
  if (c == '+') return 62;
  if (c == '/') return 63;
  return -1;
}

static int decode_b64(const char *s, uint8_t *out, size_t *out_len) {
  size_t len = strlen(s), pos = 0, n = 0;
  if (len % 4) return 0;
  while (pos < len) {
    int v[4], pad = 0;
    for (int i = 0; i < 4; i++) {
      if (s[pos+i] == '=') { v[i] = 0; pad++; }
      else { if (pad) return 0; v[i] = b64val((unsigned char)s[pos+i]); if (v[i] < 0) return 0; }
    }
    if (pad > 2) return 0;
    if (n < 81) out[n++] = (uint8_t)((v[0]<<2) | (v[1]>>4)); else return 0;
    if (pad < 2) { if (n < 81) out[n++] = (uint8_t)((v[1]<<4) | (v[2]>>2)); else return 0; }
    if (pad < 1) { if (n < 81) out[n++] = (uint8_t)((v[2]<<6) | v[3]); else return 0; }
    pos += 4;
  }
  if (n > 80) return 0;
  *out_len = n; return 1;
}

static int read_all(FILE *f, uint8_t **data, size_t *len) {
  size_t cap = 8192, n = 0;
  uint8_t *buf = malloc(cap);
  if (!buf) return 0;
  for (;;) {
    if (n == cap) {
      cap *= 2;
      uint8_t *nb = realloc(buf, cap);
      if (!nb) { free(buf); return 0; }
      buf = nb;
    }
    size_t r = fread(buf + n, 1, cap - n, f);
    n += r;
    if (r == 0) {
      if (ferror(f)) { free(buf); return 0; }
      break;
    }
  }
  *data = buf; *len = n; return 1;
}

static int write_all(FILE *f, const uint8_t *p, size_t n) {
  return n == 0 || fwrite(p, 1, n, f) == n;
}

static char *concat2(const char *a, const char *b) {
  size_t la = strlen(a), lb = strlen(b);
  char *r = malloc(la + lb + 1);
  if (!r) return NULL;
  memcpy(r, a, la); memcpy(r + la, b, lb + 1);
  return r;
}

static char *decomp_name(const char *path, const char *suffix) {
  size_t lp = strlen(path), ls = strlen(suffix);
  if (lp < ls || strcmp(path + lp - ls, suffix) != 0) return NULL;
  char *r = malloc(lp - ls + 1);
  if (!r) return NULL;
  memcpy(r, path, lp - ls); r[lp - ls] = 0;
  return r;
}

static int open_output(const char *path, int force, FILE **out) {
  int flags = O_WRONLY | O_CREAT | (force ? O_TRUNC : O_EXCL);
  int fd = open(path, flags, 0666);
  if (fd < 0) {
    fprintf(stderr, "failed to open output file [%s]: %s\n", path, strerror(errno));
    return 0;
  }
  *out = fdopen(fd, "wb");
  if (!*out) { close(fd); return 0; }
  return 1;
}

static int decode_stream(const uint8_t *in, size_t in_len, FILE *out, int test, int concatenated, size_t *total_out) {
  const uint8_t *next = in;
  size_t avail = in_len, produced = 0;
  int ok = 1;
  while (ok) {
    BrotliDecoderState *s = BrotliDecoderCreateInstance(NULL, NULL, NULL);
    if (!s) return 0;
    for (;;) {
      uint8_t buf[65536], *op = buf;
      size_t avail_out = sizeof(buf), before = avail_out, total = 0;
      int r = BrotliDecoderDecompressStream(s, &avail, &next, &avail_out, &op, &total);
      size_t got = before - avail_out;
      produced += got;
      if (!test && got && !write_all(out, buf, got)) { ok = 0; break; }
      if (r == DEC_SUCCESS) break;
      if (r == DEC_ERROR) {
        const char *e = BrotliDecoderErrorString(BrotliDecoderGetErrorCode(s));
        (void)e;
        ok = 0; break;
      }
      if (r == DEC_NEEDS_MORE_INPUT && avail == 0) { ok = 0; break; }
    }
    BrotliDecoderDestroyInstance(s);
    if (!ok) break;
    if (avail == 0) break;
    if (!concatenated) { ok = 0; break; }
  }
  *total_out = produced;
  return ok;
}

static int has_comment_prefix(const uint8_t *p, size_t n, const uint8_t *c, size_t clen) {
  if (clen == 0) return 1;
  if (n < clen + 3) return 0;
  /* Reference output for comments <= 80 starts with a Brotli metadata block.
     For byte-aligned small comments its bytes are: 0x21, 0x28|lenbits, 0x00, data... */
  if (p[0] == 0x21 && p[2] == 0x00 && (size_t)(p[1] & 7) == (clen & 7) &&
      memcmp(p + 3, c, clen) == 0) return 1;
  return 0;
}

static int process_one(Options *o, const char *file) {
  int from_stdin = strcmp(file, "-") == 0;
  FILE *in = stdin;
  struct stat st;
  memset(&st, 0, sizeof(st));
  if (!from_stdin) {
    in = fopen(file, "rb");
    if (!in) { fprintf(stderr, "failed to open input file [%s]: %s\n", file, strerror(errno)); return 0; }
    stat(file, &st);
  }
  uint8_t *input = NULL, *output = NULL;
  size_t input_len = 0, output_len = 0;
  int ok = read_all(in, &input, &input_len);
  if (!from_stdin) fclose(in);
  if (!ok) { fprintf(stderr, "failed to read input file [%s]\n", file); free(input); return 0; }

  FILE *out = stdout;
  char *outname = NULL;
  int to_file = !o->stdout_out && !o->test && !from_stdin;
  if (o->output) { to_file = !o->test; outname = strdup(o->output); }
  else if (to_file) outname = o->decompress ? decomp_name(file, o->suffix) : concat2(file, o->suffix);
  if (!outname && to_file) { fprintf(stderr, "input file [%s] suffix mismatch\n", file); free(input); return 0; }
  if (to_file && !open_output(outname, o->force, &out)) { free(outname); free(input); return 0; }

  if (o->decompress || o->test) {
    if (o->comment_len && !has_comment_prefix(input, input_len, o->comment, o->comment_len)) {
      fprintf(stderr, "corrupt input [%s]\n", file);
      ok = 0;
    } else {
      ok = decode_stream(input, input_len, out, o->test, o->concatenated, &output_len);
      if (!ok) fprintf(stderr, "corrupt input [%s]\n", file);
    }
  } else {
    int lgwin = o->lgwin == 0 ? 22 : o->lgwin;
    size_t cap = BrotliEncoderMaxCompressedSize(input_len) + 16;
    output = malloc(cap ? cap : 1);
    if (!output) ok = 0;
    else {
      size_t enc_size = BrotliEncoderMaxCompressedSize(input_len);
      ok = BrotliEncoderCompress(o->quality, lgwin, 0, input_len, input, &enc_size,
                                 output);
      if (ok) {
        output_len = enc_size;
        ok = write_all(out, output, output_len);
      }
    }
  }

  if (to_file) {
    fclose(out);
    if (ok && o->copy_stat && !from_stdin) { chmod(outname, st.st_mode & 07777); }
    if (ok && o->squash && !o->decompress && !from_stdin && output_len > input_len) {
      unlink(outname);
    }
  } else if (!o->test) fflush(out);
  if (ok && o->remove_src && !from_stdin) unlink(file);
  free(outname); free(input); free(output);
  return ok;
}

static char *need_arg(int argc, char **argv, int *i, const char *opt, const char *attached) {
  if (attached && *attached) return (char*)attached;
  if (*i + 1 < argc) return argv[++(*i)];
  usage_err("expected parameter for argument %s", opt);
  exit(1);
}

static int parse_opts(int argc, char **argv, Options *o) {
  memset(o, 0, sizeof(*o));
  o->quality = 11; o->lgwin = 24; o->copy_stat = 1; o->suffix = ".br";
  for (int i = 1; i < argc; i++) {
    char *a = argv[i];
    if (strcmp(a, "--") == 0) { while (++i < argc) add_file(o, argv[i]); break; }
    if (a[0] != '-' || strcmp(a, "-") == 0) { add_file(o, a); continue; }
    if (a[1] == '-') {
      char *eq = strchr(a, '=');
      size_t namelen = eq ? (size_t)(eq - a) : strlen(a);
      char *val = eq ? eq + 1 : NULL;
#define MATCH(x) (namelen == strlen(x) && strncmp(a, x, namelen) == 0)
      if (MATCH("--help")) { fputs(help_text, stdout); exit(0); }
      else if (MATCH("--version")) { puts("brotli 1.2.0"); exit(0); }
      else if (MATCH("--stdout")) o->stdout_out = 1;
      else if (MATCH("--decompress")) o->decompress = 1;
      else if (MATCH("--force")) o->force = 1;
      else if (MATCH("--rm")) o->remove_src = 1;
      else if (MATCH("--keep")) o->remove_src = 0;
      else if (MATCH("--no-copy-stat")) o->copy_stat = 0;
      else if (MATCH("--test")) { o->test = 1; o->decompress = 1; o->stdout_out = 1; }
      else if (MATCH("--verbose")) o->verbose++;
      else if (MATCH("--best")) o->quality = 11;
      else if (MATCH("--concatenated")) o->concatenated = 1;
      else if (MATCH("--squash")) o->squash = 1;
      else if (MATCH("--quality")) { int v; val = val ? val : need_arg(argc, argv, &i, "--quality", NULL); if (!parse_int(val,&v)||v<0||v>11){usage_err("error parsing quality value [%s]",val);return 0;} o->quality=v; }
      else if (MATCH("--lgwin")) { int v; val = val ? val : need_arg(argc, argv, &i, "--lgwin", NULL); if (!parse_int(val,&v)||v<0||v>24){usage_err("error parsing lgwin value [%s]",val);return 0;} if(v>0&&v<10){fprintf(stderr,"lgwin parameter (%d) smaller than the minimum (10)\n",v);fputs(help_text,stderr);return 0;} o->lgwin=v; }
      else if (MATCH("--large_window")) { int v; val = val ? val : need_arg(argc, argv, &i, "--large_window", NULL); if (!parse_int(val,&v)||v<0||v>30){usage_err("error parsing lgwin value [%s]",val);return 0;} o->large_window=v; o->lgwin=v; }
      else if (MATCH("--output")) { o->output = val ? val : need_arg(argc, argv, &i, "--output", NULL); }
      else if (MATCH("--suffix")) { o->suffix = val ? val : need_arg(argc, argv, &i, "--suffix", NULL); }
      else if (MATCH("--dictionary")) { o->dict = val ? val : need_arg(argc, argv, &i, "--dictionary", NULL); }
      else if (MATCH("--comment")) { val = val ? val : need_arg(argc, argv, &i, "--comment", NULL); if(!decode_b64(val,o->comment,&o->comment_len)){usage_err("invalid base64-encoded comment",NULL);return 0;} }
      else { usage_err("invalid argument %s", a); return 0; }
#undef MATCH
    } else {
      for (int j = 1; a[j]; j++) {
        char c = a[j];
        if (c >= '0' && c <= '9') o->quality = c - '0';
        else if (c == 'c') o->stdout_out = 1;
        else if (c == 'd') o->decompress = 1;
        else if (c == 'f') o->force = 1;
        else if (c == 'h') { fputs(help_text, stdout); exit(0); }
        else if (c == 'j') o->remove_src = 1;
        else if (c == 'k') o->remove_src = 0;
        else if (c == 'n') o->copy_stat = 0;
        else if (c == 's') o->squash = 1;
        else if (c == 't') { o->test = 1; o->decompress = 1; o->stdout_out = 1; }
        else if (c == 'v') o->verbose++;
        else if (c == 'K') o->concatenated = 1;
        else if (c == 'V') { puts("brotli 1.2.0"); exit(0); }
        else if (c == 'Z') o->quality = 11;
        else if (c == 'q' || c == 'w' || c == 'o' || c == 'S' || c == 'D' || c == 'C') {
          char opt[3] = {'-', c, 0};
          char *val = need_arg(argc, argv, &i, opt, &a[j+1]);
          if (c == 'q') { int v; if(!parse_int(val,&v)||v<0||v>11){usage_err("error parsing quality value [%s]",val);return 0;} o->quality=v; }
          else if (c == 'w') { int v; if(!parse_int(val,&v)||v<0||v>24){usage_err("error parsing lgwin value [%s]",val);return 0;} if(v>0&&v<10){fprintf(stderr,"lgwin parameter (%d) smaller than the minimum (10)\n",v);fputs(help_text,stderr);return 0;} o->lgwin=v; }
          else if (c == 'o') o->output = val;
          else if (c == 'S') o->suffix = val;
          else if (c == 'D') o->dict = val;
          else if (c == 'C') { if(!decode_b64(val,o->comment,&o->comment_len)){usage_err("invalid base64-encoded comment",NULL);return 0;} }
          break;
        } else {
          char msg[64]; snprintf(msg, sizeof(msg), "invalid argument -%c", c);
          usage_err(msg, NULL); return 0;
        }
      }
    }
  }
  if (o->nfiles == 0) add_file(o, "-");
  if (o->output && o->nfiles > 1) { usage_err("write to output file allowed only for single input file", NULL); return 0; }
  return 1;
}

int main(int argc, char **argv) {
  Options o;
  if (!parse_opts(argc, argv, &o)) return 1;
  int rc = 0;
  for (int i = 0; i < o.nfiles; i++) {
    if (!process_one(&o, o.files[i])) rc = 1;
  }
  free(o.files);
  return rc;
}
