#!/usr/bin/env python3
import os, sys, subprocess, time, re, signal
from datetime import datetime, timezone

HELP = '''loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing `loop` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. "2018-04-20 04:20:00" (Times in UTC.)

ARGS:
    <input>...    The command to be looped
'''

class Opt:
    def __init__(self):
        self.error_duration=False; self.only_last=False; self.stdin=False; self.summary=False
        self.until_changes=False; self.until_fail=False; self.until_same=False; self.until_success=False
        self.count_by=1; self.every='1us'; self.ffor=None; self.for_duration=None; self.num=None; self.offset=0
        self.until_contains=None; self.until_error=None; self.until_match=None; self.until_time=None; self.input=[]

def parse_duration(s):
    if not s: return 0.0
    total=0.0; pos=0
    for m in re.finditer(r'(\d+(?:\.\d+)?)(us|ms|s|m|h|d)?', s):
        if m.start()!=pos: break
        val=float(m.group(1)); unit=m.group(2) or 's'
        total += val * {'us':1e-6,'ms':1e-3,'s':1,'m':60,'h':3600,'d':86400}[unit]
        pos=m.end()
    if pos != len(s):
        try: return float(s)
        except Exception: return 0.0
    return total

def err(msg):
    sys.stderr.write(msg + '\n')
    sys.exit(1)

def need(argv, i, optname):
    if i+1 >= len(argv):
        err("error: The argument '%s <val>' requires a value but none was supplied" % optname)
    return argv[i+1]

def parse(argv):
    o=Opt(); i=0; after=False
    while i < len(argv):
        a=argv[i]
        if after:
            o.input.append(a); i+=1; continue
        if a == '--': after=True; i+=1; continue
        if a in ('-h','--help'):
            print(HELP, end=''); sys.exit(0)
        if a in ('-V','--version'):
            print('loop 0.6.1'); sys.exit(0)
        flagmap={'-D':'error_duration','--error-duration':'error_duration','-l':'only_last','--only-last':'only_last','-i':'stdin','--stdin':'stdin','--summary':'summary','-C':'until_changes','--until-changes':'until_changes','-f':'until_fail','--until-fail':'until_fail','-S':'until_same','--until-same':'until_same','-s':'until_success','--until-success':'until_success'}
        if a in flagmap:
            setattr(o, flagmap[a], True); i+=1; continue
        optmap={'-b':'count_by','--count-by':'count_by','-e':'every','--every':'every','--for':'ffor','-d':'for_duration','--for-duration':'for_duration','-n':'num','--num':'num','-o':'offset','--offset':'offset','-c':'until_contains','--until-contains':'until_contains','-r':'until_error','--until-error':'until_error','-m':'until_match','--until-match':'until_match','-t':'until_time','--until-time':'until_time'}
        if a in optmap:
            v=need(argv,i,a); name=optmap[a]
            if name in ('count_by','offset','until_error'):
                try: v=int(v)
                except Exception: err("error: Invalid value for '%s <%s>': invalid digit found in string" % (a, name))
            elif name == 'num':
                try: v=int(float(v))
                except Exception: err("error: Invalid value for '--num <num>': invalid float literal")
            setattr(o,name,v); i+=2; continue
        if a.startswith('-'):
            sys.stderr.write("error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help\n" % a)
            sys.exit(1)
        o.input = argv[i:]
        break
    return o

def target_time(s):
    if not s: return None
    for fmt in ('%Y-%m-%d %H:%M:%S','%Y-%m-%d %H:%M','%H:%M:%S','%H:%M'):
        try:
            dt=datetime.strptime(s,fmt)
            now=datetime.now(timezone.utc)
            if fmt.startswith('%H'):
                dt=dt.replace(year=now.year,month=now.month,day=now.day,tzinfo=timezone.utc)
                if dt.timestamp() < now.timestamp(): dt=dt.replace(day=dt.day+1)
            else:
                dt=dt.replace(tzinfo=timezone.utc)
            return dt.timestamp()
        except Exception: pass
    return None

def main():
    signal.signal(signal.SIGPIPE, signal.SIG_DFL)
    o=parse(sys.argv[1:])
    if not o.input:
        print('No command supplied, exiting.'); return 0
    cmd=' '.join(o.input)
    items=None
    if o.stdin:
        items=sys.stdin.read().splitlines()
    if o.ffor is not None:
        items=o.ffor.split(',')
    start=time.time(); end=None
    if o.for_duration: end=start+parse_duration(str(o.for_duration))
    tt=target_time(o.until_time) if o.until_time else None
    if tt is not None: end=tt
    maxn=o.num
    if maxn is None and items is not None:
        maxn=len(items)
    total=succ=fail=0; fail_codes=[]; last_out=''; prev_out=None; i=0
    sleep_s=parse_duration(o.every)
    while True:
        if maxn is not None and i >= maxn: break
        if end is not None and time.time() >= end: break
        env=os.environ.copy(); env['ACTUALCOUNT']=str(i); env['COUNT']=str(o.offset + i*o.count_by)
        if items is not None and items:
            env['ITEM']=items[i] if i < len(items) else items[-1]
        elif items is not None:
            env['ITEM']=''
        p=subprocess.run(['sh', '-c', cmd], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out=p.stdout.decode(errors='replace'); er=p.stderr.decode(errors='replace')
        total+=1
        if p.returncode == 0: succ+=1
        else: fail+=1; fail_codes.append(p.returncode)
        if not o.only_last:
            sys.stdout.write(out); sys.stdout.flush()
            sys.stderr.write(er); sys.stderr.flush()
        else:
            last_out=out+er
        stop=False
        if o.until_success and p.returncode == 0: stop=True
        if o.until_fail and p.returncode != 0: stop=True
        if o.until_error is not None and p.returncode == o.until_error: stop=True
        if o.until_contains is not None and o.until_contains in out: stop=True
        if o.until_match is not None:
            try:
                if re.search(o.until_match, out): stop=True
            except re.error:
                pass
        if o.until_changes and prev_out is not None and out != prev_out: stop=True
        if o.until_same and prev_out is not None and out == prev_out: stop=True
        prev_out=out
        i+=1
        if stop: break
        if maxn is None and end is None and not any([o.until_success,o.until_fail,o.until_error is not None,o.until_contains,o.until_match,o.until_changes,o.until_same]):
            # default mode is intentionally infinite; continue until interrupted
            pass
        if sleep_s > 0:
            time.sleep(min(sleep_s, 0.1) if sleep_s < 1 else sleep_s)
    if o.only_last and last_out:
        sys.stdout.write(last_out); sys.stdout.flush()
    if o.summary:
        print('Total runs:\t%d' % total)
        print('Successes:\t%d' % succ)
        if fail_codes:
            print('Failures:\t%d (%s)' % (fail, ', '.join(str(x) for x in fail_codes)))
        else:
            print('Failures:\t0')
    if o.error_duration and end is not None and time.time() >= end:
        return 124
    return 0

if __name__ == '__main__':
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        sys.exit(130)
