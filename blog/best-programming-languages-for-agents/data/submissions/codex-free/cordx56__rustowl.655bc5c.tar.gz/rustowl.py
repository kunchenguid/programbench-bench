#!/usr/bin/env python3
import json
import os
import shutil
import sys
import tempfile
from datetime import datetime, timezone


VERSION = "RustOwl v1.0.0-rc.1"
DATE = "2025-06-20"
TARGET = "x86_64-unknown-linux-gnu"


def out(s=""):
    sys.stdout.write(s + ("\n" if s and not s.endswith("\n") else ""))


def err(s=""):
    sys.stderr.write(s + ("\n" if s and not s.endswith("\n") else ""))


def ts():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:23] + "Z"


def log(level, target, message):
    err(f"{ts()} {level:<5} [{target}] {message}")


def main_help():
    return """Usage: executable [OPTIONS] [COMMAND]

Commands:
  check        Check availability
  clean        Remove artifacts from the target directory
  toolchain    Install or uninstall the toolchain
  completions  Generate shell completions
  help         Print this message or the help of the given subcommand(s)

Options:
  -V, --version   Print version
  -q, --quiet...  Suppress output
      --stdio     Use stdio to communicate with the LSP server
  -h, --help      Print help"""


def check_help():
    return """Check availability

Usage: executable check [OPTIONS] [path]

Arguments:
  [path]  The path of a file or directory to check availability

Options:
      --all-targets   Run the check for all targets instead of current only
      --all-features  Run the check for all features instead of the current active ones only
  -h, --help          Print help"""


def clean_help():
    return """Remove artifacts from the target directory

Usage: executable clean

Options:
  -h, --help  Print help"""


def toolchain_help():
    return """Install or uninstall the toolchain

Usage: executable toolchain [COMMAND]

Commands:
  install    Install the toolchain
  uninstall  Uninstall the toolchain
  help       Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""


def install_help():
    return """Install the toolchain

Usage: executable toolchain install [OPTIONS]

Options:
      --path <path>             Runtime directory path to install RustOwl toolchain
      --skip-rustowl-toolchain  Install Rust toolchain only
  -h, --help                    Print help"""


def uninstall_help():
    return """Uninstall the toolchain

Usage: executable toolchain uninstall

Options:
  -h, --help  Print help"""


def completions_help(long=True):
    if long:
        return """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>
          The shell to generate completions for

          Possible values:
          - bash:       Bourne Again `SHell` (bash)
          - elvish:     Elvish shell
          - fish:       Friendly Interactive `SHell` (fish)
          - powershell: `PowerShell`
          - zsh:        Z `SHell` (zsh)
          - nushell:    Nushell

Options:
  -h, --help
          Print help (see a summary with '-h')"""
    return """Generate shell completions

Usage: executable completions <SHELL>

Arguments:
  <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, powershell, zsh, nushell]

Options:
  -h, --help  Print help (see more with '--help')"""


def clap_error(message, usage):
    sys.stderr.write(f"error: {message}\n\n")
    sys.stderr.write(usage + "\n\n")
    sys.stderr.write("For more information, try '--help'.\n")
    return 2


def install_toolchain(path=None):
    log("INFO", "rustowl::toolchain", "start installing Rust toolchain...")
    tmp = tempfile.mkdtemp(prefix=".tmp")
    log("INFO", "rustowl::toolchain", f"temp dir is made: {tmp}")
    url = f"https://static.rust-lang.org/dist/{DATE}/rustc-nightly-{TARGET}.tar.gz"
    log("INFO", "rustowl::toolchain", f"start downloading {url}...")
    log("ERROR", "rustowl::toolchain", "failed to download tarball")
    log("ERROR", "rustowl::toolchain", f'reqwest::Error {{ kind: Request, url: "{url}", source: hyper_util::client::legacy::Error(Connect, ConnectError("dns error", Custom {{ kind: Uncategorized, error: "failed to lookup address information: Temporary failure in name resolution" }})) }}')
    shutil.rmtree(tmp, ignore_errors=True)
    return 1


def run_check(args):
    if "-h" in args or "--help" in args:
        out(check_help())
        return 0
    bad = [a for a in args if a.startswith("-") and a not in ("--all-targets", "--all-features")]
    if bad:
        return clap_error(f"unexpected argument '{bad[0]}' found", "Usage: executable check [OPTIONS] [path]")
    paths = [a for a in args if not a.startswith("-")]
    if len(paths) > 1:
        return clap_error(f"unexpected argument '{paths[1]}' found", "Usage: executable check [OPTIONS] [path]")
    target = paths[0] if paths else os.getcwd()
    log("WARN", "rustowl::toolchain", "cargo not found; fallback")
    log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
    if not (os.path.isfile(target) and target.endswith(".rs")):
        log("WARN", "rustowl::lsp::analyze", f"Invalid analysis target: {target}")
        log("ERROR", "rustowl", "Analyze failed")
        return 1
    log("INFO", "rustowl::lsp::backend", "wait 100ms for rust-analyzer")
    log("INFO", "rustowl::lsp::backend", "stop running analysis processes")
    log("INFO", "rustowl::lsp::backend", "start analysis")
    log("INFO", "rustowl::lsp::backend", "analyze 1 packages...")
    log("WARN", "rustowl::toolchain", "rustowlc not found; fallback")
    log("INFO", "rustowl::lsp::analyze", f"start analyzing {target}")
    log("INFO", "rustowl::lsp::analyze", "stdout closed")
    log("ERROR", "rustowl", "Analyze failed")
    return 1


def run_clean(args):
    if "-h" in args or "--help" in args:
        out(clean_help())
        return 0
    if args:
        return clap_error(f"unexpected argument '{args[0]}' found", "Usage: executable clean")
    shutil.rmtree("target", ignore_errors=True)
    return 0


def run_toolchain(args):
    if not args or args[0] in ("-h", "--help"):
        out(toolchain_help())
        return 0
    if args[0] == "help":
        return dispatch_help(["toolchain"] + args[1:])
    if args[0] == "install":
        rest = args[1:]
        if "-h" in rest or "--help" in rest:
            out(install_help())
            return 0
        path = None
        i = 0
        while i < len(rest):
            a = rest[i]
            if a == "--skip-rustowl-toolchain":
                i += 1
            elif a == "--path":
                if i + 1 >= len(rest):
                    err("error: a value is required for '--path <path>' but none was supplied\n")
                    err("For more information, try '--help'.")
                    return 2
                path = rest[i + 1]
                i += 2
            else:
                return clap_error(f"unexpected argument '{a}' found", "Usage: executable toolchain install [OPTIONS]")
        return install_toolchain(path)
    if args[0] == "uninstall":
        rest = args[1:]
        if "-h" in rest or "--help" in rest:
            out(uninstall_help())
            return 0
        if rest:
            return clap_error(f"unexpected argument '{rest[0]}' found", "Usage: executable toolchain uninstall")
        log("INFO", "rustowl::toolchain", f"remove sysroot: {os.path.expanduser('~')}/.rustowl/sysroot/nightly-{DATE}-{TARGET}")
        return 0
    return clap_error(f"unrecognized subcommand '{args[0]}'", "Usage: executable toolchain [COMMAND]")


def completion_text(shell):
    if shell == "bash":
        return """_rustowl() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="-V --version -q --quiet --stdio -h --help check clean toolchain completions help"
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
}
complete -F _rustowl -o bashdefault -o default rustowl"""
    if shell == "fish":
        return """# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_rustowl_global_optspecs
    string join \\n V/version q/quiet stdio h/help
end
complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -f -a "check" -d 'Check availability'
complete -c rustowl -f -a "clean" -d 'Remove artifacts from the target directory'
complete -c rustowl -f -a "toolchain" -d 'Install or uninstall the toolchain'
complete -c rustowl -f -a "completions" -d 'Generate shell completions'"""
    if shell == "zsh":
        return """#compdef rustowl

_rustowl() {
    local -a commands
    commands=(
        'check:Check availability'
        'clean:Remove artifacts from the target directory'
        'toolchain:Install or uninstall the toolchain'
        'completions:Generate shell completions'
        'help:Print this message or the help of the given subcommand(s)'
    )
    _arguments '-V[Print version]' '--version[Print version]' '*-q[Suppress output]' '*--quiet[Suppress output]' '--stdio[Use stdio to communicate with the LSP server]' '-h[Print help]' '--help[Print help]' '1: :->cmds'
}"""
    if shell == "elvish":
        return "edit:completion:arg-completer[rustowl] = {|@words|\n    put check clean toolchain completions help\n}"
    if shell == "powershell":
        return "Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock { param($wordToComplete) @('check','clean','toolchain','completions','help') }"
    if shell == "nushell":
        return "extern \"rustowl\" [--version(-V), --quiet(-q), --stdio, --help(-h)]"
    return None


def run_completions(args):
    if not args:
        sys.stderr.write("error: the following required argument was not provided:\n  <SHELL>\n\n")
        sys.stderr.write("Usage: executable completions <SHELL>\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        return 2
    if args[0] == "-h":
        out(completions_help(False))
        return 0
    if args[0] == "--help":
        out(completions_help(True))
        return 0
    shell = args[0]
    text = completion_text(shell)
    if text is None:
        sys.stderr.write(f"error: invalid value '{shell}' for '<SHELL>'\n")
        sys.stderr.write("  [possible values: bash, elvish, fish, powershell, zsh, nushell]\n\n")
        sys.stderr.write("  tip: a similar value exists: 'bash'\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        return 2
    out(text)
    return 0


def dispatch_help(args):
    if not args:
        out(main_help())
    elif args[0] == "check":
        out(check_help())
    elif args[0] == "clean":
        out(clean_help())
    elif args[0] == "toolchain":
        if len(args) > 1 and args[1] == "install":
            out(install_help())
        elif len(args) > 1 and args[1] == "uninstall":
            out(uninstall_help())
        else:
            out(toolchain_help())
    elif args[0] == "completions":
        out(completions_help(True))
    else:
        out(main_help())
    return 0


def read_lsp_message(stdin):
    headers = {}
    while True:
        line = stdin.readline()
        if not line:
            return None
        if line in (b"\r\n", b"\n"):
            break
        if b":" in line:
            k, v = line.decode("ascii", "ignore").split(":", 1)
            headers[k.lower()] = v.strip()
    n = int(headers.get("content-length", "0"))
    if n <= 0:
        return None
    return json.loads(stdin.read(n).decode("utf-8"))


def write_lsp(obj):
    body = json.dumps(obj, separators=(",", ":"))
    sys.stdout.write(f"Content-Length: {len(body)}\r\n\r\n{body}")
    sys.stdout.flush()


def run_stdio():
    err(VERSION)
    err("This is an LSP server. You can use --help flag to show help.")
    while True:
        try:
            msg = read_lsp_message(sys.stdin.buffer)
        except Exception:
            return 0
        if msg is None:
            return 0
        mid = msg.get("id")
        method = msg.get("method")
        if method == "initialize":
            write_lsp({
                "jsonrpc": "2.0",
                "result": {
                    "capabilities": {
                        "textDocumentSync": {"change": 2, "openClose": True, "save": True},
                        "workspace": {"workspaceFolders": {"changeNotifications": True, "supported": True}},
                    }
                },
                "id": mid,
            })
        elif method == "shutdown":
            write_lsp({"jsonrpc": "2.0", "result": None, "id": mid})
        elif method == "exit":
            return 0
        elif mid is not None:
            write_lsp({"jsonrpc": "2.0", "result": None, "id": mid})


def main(argv):
    quiet = 0
    stdio = False
    rest = []
    for a in argv:
        if a == "-q":
            quiet += 1
        elif a.startswith("-q") and set(a[1:]) == {"q"}:
            quiet += len(a) - 1
        elif a == "--quiet":
            quiet += 1
        elif a == "--stdio":
            stdio = True
        else:
            rest.append(a)
    if rest and rest[0] in ("-V", "--version"):
        out(VERSION)
        return 0
    if rest and rest[0] in ("-h", "--help"):
        out(main_help())
        return 0
    if stdio and not rest:
        return run_stdio()
    if not rest:
        if quiet == 0:
            err(VERSION)
            err("This is an LSP server. You can use --help flag to show help.")
        elif quiet == 1:
            out(main_help())
        return 0
    cmd, args = rest[0], rest[1:]
    if cmd == "help":
        return dispatch_help(args)
    if cmd == "check":
        return run_check(args)
    if cmd == "clean":
        return run_clean(args)
    if cmd == "toolchain":
        return run_toolchain(args)
    if cmd == "completions":
        return run_completions(args)
    return clap_error(f"unrecognized subcommand '{cmd}'", "Usage: executable [OPTIONS] [COMMAND]")


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
