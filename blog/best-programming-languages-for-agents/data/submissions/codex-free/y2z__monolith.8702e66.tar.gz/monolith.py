#!/usr/bin/env python3
import base64
import datetime as _dt
import mimetypes
import os
import posixpath
import re
import sys
from urllib.parse import urlparse, unquote, quote

VERSION = "monolith 2.11.0"
BANNER = r""" _____    _____________   __________     ___________________    ___
|     \  /             \ |          |   |                   |  |   |
|      \/       __      \|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \__/ |          |\                    |   |   |   |   |  |   |
|___|      |__________| \___________________|   |___|   |___|  |___|"""

HELP = BANNER + """

monolith 2.11.0

CLI tool and library for saving web pages as a single HTML file

Usage: executable [OPTIONS] <TARGET>

Arguments:
  <TARGET>  URL or file path, use - for STDIN

Options:
  -a, --no-audio                      Remove audio sources
  -b, --base-url <http://localhost/>  Set custom base URL
  -B, --blacklist-domains             Treat specified domains as blacklist
  -c, --no-css                        Remove CSS
  -C, --cookie-file <cookies.txt>     Specify cookie file
  -d, --domain <example.com>          Specify domains to use for white/black-listing
  -e, --ignore-errors                 Ignore network errors
  -E, --encoding <UTF-8>              Enforce custom charset
  -f, --no-frames                     Remove frames and iframes
  -F, --no-fonts                      Remove fonts
  -i, --no-images                     Remove images
  -I, --isolate                       Cut off document from the Internet
  -j, --no-js                         Remove JavaScript
  -k, --insecure                      Allow invalid X.509 (TLS) certificates
  -m, --mhtml                         Use MHTML as output format
  -M, --no-metadata                   Exclude timestamp and source information
  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents
  -o, --output <result.html>          File to write to, use - for STDOUT
  -q, --quiet                         Suppress verbosity
  -t, --timeout <60>                  Adjust network request timeout
  -u, --user-agent <Firefox>          Set custom User-Agent string
  -v, --no-video                      Remove video sources
  -h, --help                          Print help
  -V, --version                       Print version
"""

BOOLS = {
    "-a": "no_audio", "--no-audio": "no_audio",
    "-B": "blacklist_domains", "--blacklist-domains": "blacklist_domains",
    "-c": "no_css", "--no-css": "no_css",
    "-e": "ignore_errors", "--ignore-errors": "ignore_errors",
    "-f": "no_frames", "--no-frames": "no_frames",
    "-F": "no_fonts", "--no-fonts": "no_fonts",
    "-i": "no_images", "--no-images": "no_images",
    "-I": "isolate", "--isolate": "isolate",
    "-j": "no_js", "--no-js": "no_js",
    "-k": "insecure", "--insecure": "insecure",
    "-m": "mhtml", "--mhtml": "mhtml",
    "-M": "no_metadata", "--no-metadata": "no_metadata",
    "-n": "unwrap_noscript", "--unwrap-noscript": "unwrap_noscript",
    "-q": "quiet", "--quiet": "quiet",
    "-v": "no_video", "--no-video": "no_video",
}
VALUES = {
    "-b": "base_url", "--base-url": "base_url",
    "-C": "cookie_file", "--cookie-file": "cookie_file",
    "-d": "domains", "--domain": "domains",
    "-E": "encoding", "--encoding": "encoding",
    "-o": "output", "--output": "output",
    "-t": "timeout", "--timeout": "timeout",
    "-u": "user_agent", "--user-agent": "user_agent",
}

class Opt:
    pass

def die(msg, usage="Usage: executable [OPTIONS] <TARGET>", code=2):
    print(msg, file=sys.stderr)
    print("", file=sys.stderr)
    print(usage, file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(code)

def parse_args(argv):
    o = Opt()
    for v in set(BOOLS.values()):
        setattr(o, v, False)
    o.base_url = None; o.cookie_file = None; o.domains = []
    o.encoding = None; o.output = None; o.timeout = None; o.user_agent = None
    targets = []
    i = 0
    stop = False
    while i < len(argv):
        a = argv[i]
        if stop or not a.startswith("-") or a == "-":
            targets.append(a); i += 1; continue
        if a == "--":
            stop = True; i += 1; continue
        if a in ("-h", "--help"):
            print(HELP, end=""); sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION); sys.exit(0)
        if a in VALUES:
            if i + 1 >= len(argv):
                die(f"error: a value is required for '{a} <...>' but none was supplied")
            val = argv[i+1]; key = VALUES[a]
            if key == "domains":
                o.domains.append(val)
            elif key == "timeout":
                try:
                    int(val)
                except ValueError as e:
                    print(f"error: invalid value '{val}' for '--timeout <60>': {e}", file=sys.stderr)
                    print("", file=sys.stderr)
                    print("For more information, try '--help'.", file=sys.stderr)
                    sys.exit(2)
                o.timeout = val
            else:
                setattr(o, key, val)
            i += 2; continue
        if a in BOOLS:
            setattr(o, BOOLS[a], True); i += 1; continue
        if a.startswith("--"):
            print(f"error: unexpected argument '{a}' found", file=sys.stderr)
            print("", file=sys.stderr)
            print(f"  tip: to pass '{a}' as a value, use '-- {a}'", file=sys.stderr)
            print("", file=sys.stderr)
            print("Usage: executable [OPTIONS] <TARGET>", file=sys.stderr)
            print("", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        # short option cluster, e.g. -aIiFfcMv
        if len(a) > 2:
            chars = a[1:]
            consumed_value = False
            for idx, ch in enumerate(chars):
                opt = "-" + ch
                if opt in BOOLS:
                    setattr(o, BOOLS[opt], True)
                elif opt in VALUES:
                    rest = chars[idx+1:]
                    if rest:
                        val = rest
                        i += 1
                    else:
                        if i + 1 >= len(argv):
                            die(f"error: a value is required for '{opt} <...>' but none was supplied")
                        val = argv[i+1]; i += 2
                    key = VALUES[opt]
                    if key == "domains": o.domains.append(val)
                    else: setattr(o, key, val)
                    consumed_value = True
                    break
                else:
                    die(f"error: unexpected argument '{opt}' found")
            if not consumed_value:
                i += 1
            continue
        die(f"error: unexpected argument '{a}' found")
    if len(targets) == 0:
        die("error: the following required arguments were not provided:\n  <TARGET>", "Usage: executable <TARGET>")
    if len(targets) > 1:
        die(f"error: unexpected argument '{targets[1]}' found")
    o.target = targets[0]
    return o

def file_url(path):
    return "file://" + quote(os.path.abspath(path))

def mime_for(path, default="text/plain"):
    mt = mimetypes.guess_type(path)[0]
    return mt or default

def b64(data):
    return base64.b64encode(data).decode("ascii")

def data_url(path, data, default="text/plain"):
    return "data:%s;base64,%s" % (mime_for(path, default), b64(data))

def log(o, s):
    if not o.quiet:
        print(s, file=sys.stderr)

def resolve_to_path(base_url, ref):
    if not ref or ref.startswith(("data:", "mailto:", "javascript:", "#")):
        return None
    p = urlparse(ref)
    if p.scheme == "file":
        return unquote(p.path)
    if p.scheme in ("http", "https"):
        return None
    b = urlparse(base_url or "")
    if b.scheme == "file":
        base_path = unquote(b.path)
        if not base_path.endswith("/"):
            base_path = os.path.dirname(base_path) + "/"
        return os.path.normpath(os.path.join(base_path, ref.split("#",1)[0].split("?",1)[0]))
    if base_url and not urlparse(base_url).scheme:
        return os.path.normpath(os.path.join(base_url, ref))
    return None

def read_asset(o, base_url, ref):
    path = resolve_to_path(base_url, ref)
    if not path:
        return None
    log(o, file_url(path))
    try:
        with open(path, "rb") as f:
            return path, f.read()
    except OSError:
        if o.ignore_errors:
            return path, b""
        return None

def process_css(o, css, base_url):
    if o.no_fonts:
        css = re.sub(r"@font-face\s*\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}", "", css, flags=re.I|re.S)
    def repl(m):
        raw = m.group(1).strip().strip('"\'')
        if o.no_images and not re.search(r"\.(woff2?|ttf|otf|eot)(?:[?#].*)?$", raw, re.I):
            return "url(\"data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0D%00%00%00%0D%08%04%00%00%00%D8%E2%2C%F7%00%00%00%11IDATx%DAcd%C0%09%18G%A5%28%96%02%00%0A%F8%00%0E%CB%8A%EB%16%00%00%00%00IEND%AEB%60%82\")"
        if o.no_fonts and re.search(r"\.(woff2?|ttf|otf|eot)(?:[?#].*)?$", raw, re.I):
            return "url(\"\")"
        got = read_asset(o, base_url, raw)
        if not got:
            return m.group(0)
        path, data = got
        return 'url("%s")' % data_url(path, data)
    return re.sub(r"url\(\s*([^)]+?)\s*\)", repl, css, flags=re.I)

def set_attr(tag, name, value):
    qv = '"' + value.replace("&", "&amp;").replace('"', "&quot;") + '"'
    if re.search(r"\s" + re.escape(name) + r"\s*=", tag, flags=re.I):
        return re.sub(r"(\s" + re.escape(name) + r"\s*=\s*)(\"[^\"]*\"|'[^']*'|[^\s>]+)", r"\1" + qv, tag, flags=re.I)
    return tag[:-1] + f' {name}={qv}>'

def del_attr(tag, name):
    return re.sub(r"\s" + re.escape(name) + r"\s*=\s*(\"[^\"]*\"|'[^']*'|[^\s>]+)", "", tag, flags=re.I)

def get_attr(tag, name):
    m = re.search(r"\s" + re.escape(name) + r"\s*=\s*(\"([^\"]*)\"|'([^']*)'|([^\s>]+))", tag, flags=re.I)
    return None if not m else (m.group(2) or m.group(3) or m.group(4) or "")

def ensure_document(html):
    s = html.strip()
    if not re.search(r"<html\b", s, re.I):
        s = "<html><head></head><body>" + s + "</body></html>"
    if not re.search(r"<head\b", s, re.I):
        s = re.sub(r"<html([^>]*)>", r"<html\1><head></head>", s, count=1, flags=re.I)
    if not re.search(r"<body\b", s, re.I):
        s = re.sub(r"</head>", r"</head><body>", s, count=1, flags=re.I)
        s = re.sub(r"</html>", r"</body></html>", s, count=1, flags=re.I)
    return s

def add_head(html, snippet):
    if re.search(r"<head\b[^>]*>", html, re.I):
        return re.sub(r"(<head\b[^>]*>)", r"\1" + snippet, html, count=1, flags=re.I)
    return snippet + html

def before_head_end(html, snippet):
    if re.search(r"</head>", html, re.I):
        return re.sub(r"</head>", snippet + "</head>", html, count=1, flags=re.I)
    return snippet + html

def transform(o, html, base_url, source_kind):
    html = ensure_document(html)
    if o.encoding:
        html = re.sub(r'(<meta\b[^>]*charset\s*=\s*)(["\']?)[^"\'\s>]+(\2)', r"\1\2" + o.encoding + r"\3", html, flags=re.I)
    if o.base_url and o.target == "-":
        html = add_head(html, f'<base href="{o.base_url}"></base>')
    csp = []
    if o.isolate: csp.append("default-src 'unsafe-eval' 'unsafe-inline' data:;")
    if o.no_js or o.mhtml: csp.append("script-src 'none';")
    if o.no_css: csp.append("style-src 'none';")
    if o.no_fonts: csp.append("font-src 'none';")
    if o.no_images: csp.append("img-src data:;")
    if o.no_frames: csp.append("frame-src 'none'; child-src 'none';")
    for c in reversed(csp):
        html = add_head(html, f'<meta http-equiv="Content-Security-Policy" content="{c}"></meta>')

    def link_repl(m):
        tag = m.group(0); href = get_attr(tag, "href")
        rel = (get_attr(tag, "rel") or "").lower()
        if "stylesheet" not in rel:
            return tag
        if o.no_css:
            return del_attr(tag, "href")
        got = read_asset(o, base_url, href)
        if not got:
            return tag
        path, data = got
        css = process_css(o, data.decode("utf-8", "replace"), os.path.dirname(path) + "/")
        return set_attr(tag, "href", data_url(path, css.encode()))
    html = re.sub(r"<link\b[^>]*>", link_repl, html, flags=re.I)

    if o.no_css:
        html = re.sub(r"<style\b([^>]*)>.*?</style>", r"<style\1></style>", html, flags=re.I|re.S)

    def script_repl(m):
        opentag = m.group(1)
        if o.no_js or o.mhtml:
            return del_attr(opentag, "src") + "</script>"
        src = get_attr(opentag, "src")
        if not src:
            return m.group(0)
        got = read_asset(o, base_url, src)
        if not got:
            return m.group(0)
        return del_attr(opentag, "src") + got[1].decode("utf-8", "replace") + "</script>"
    html = re.sub(r"(<script\b[^>]*>).*?</script>", script_repl, html, flags=re.I|re.S)

    for tagname, attr, flag, default_mime in [
        ("img", "src", o.no_images, "image/png"),
        ("audio", "src", o.no_audio, "audio/mpeg"),
        ("video", "src", o.no_video, "video/mp4"),
        ("iframe", "src", o.no_frames, "text/html"),
        ("frame", "src", o.no_frames, "text/html"),
        ("source", "src", o.no_audio or o.no_video, "application/octet-stream"),
    ]:
        def repl(m, tagname=tagname, attr=attr, flag=flag, default_mime=default_mime):
            tag = m.group(0); src = get_attr(tag, attr)
            if not src:
                return tag
            if flag:
                return set_attr(tag, attr, "")
            got = read_asset(o, base_url, src)
            if not got:
                return tag
            path, data = got
            if tagname in ("iframe", "frame"):
                text = data.decode("utf-8", "replace")
                if not re.search(r"<html\b", text, re.I):
                    text = "<html><head></head><body>" + text + "</body></html>"
                data = text.encode()
            return set_attr(tag, attr, data_url(path, data, default_mime))
        html = re.sub(r"<" + tagname + r"\b[^>]*>", repl, html, flags=re.I)

    if o.unwrap_noscript:
        html = re.sub(r"<noscript\b[^>]*>(.*?)</noscript>", r"<!--noscript-->\1<!--/noscript-->", html, flags=re.I|re.S)

    html = before_head_end(html, '<meta name="robots" content="none"></meta>')
    if not o.no_metadata:
        ts = _dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
        label = "local source" if source_kind in ("file", "stdin") else base_url
        html = f"<!-- Saved from {label} at {ts} using monolith v2.11.0 -->\n" + html
    return html if html.endswith("\n") else html + "\n"

def target_as_url_for_error(target):
    if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", target):
        return target
    if target.startswith("/"):
        parts = [p for p in target.split("/") if p]
        if parts:
            return "http://" + parts[0] + "/" + "/".join(parts[1:])
    return "http://" + target.rstrip("/") + "/"

def main():
    o = parse_args(sys.argv[1:])
    if o.target == "-":
        raw = sys.stdin.buffer.read()
        html = raw.decode(o.encoding or "utf-8", "replace")
        base = o.base_url or ""
        source_kind = "stdin"
    elif os.path.exists(o.target) or urlparse(o.target).scheme == "file":
        input_path = unquote(urlparse(o.target).path) if urlparse(o.target).scheme == "file" else o.target
        log(o, file_url(input_path))
        with open(input_path, "rb") as f:
            raw = f.read()
        html = raw.decode(o.encoding or "utf-8", "replace")
        base = o.base_url or ("file://" + quote(os.path.dirname(os.path.abspath(input_path)) + "/"))
        source_kind = "file"
    else:
        u = target_as_url_for_error(o.target)
        print(f"{u} (error sending request for url ({u}))", file=sys.stderr)
        print("Error: could not retrieve target document", file=sys.stderr)
        sys.exit(1)
    out = transform(o, html, base, source_kind)
    if o.mhtml:
        out = ('MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary="----=_NextPart_000_0000"\r\n\r\n'
               '------=_NextPart_000_0000\r\nContent-Type: text/html; charset="utf-8"\r\n'
               'Content-Location: http://example.com/\r\n\r\n' + out + '\r\n------=_NextPart_000_0000--\r\n')
    if o.output and o.output != "-":
        with open(o.output, "w", encoding=o.encoding or "utf-8", newline="") as f:
            f.write(out)
    else:
        sys.stdout.write(out)

if __name__ == "__main__":
    main()
