#define _POSIX_C_SOURCE 200809L

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

typedef struct {
    bool sorted;
    bool echo;
    bool debug;
    const char *filename;
} Options;

static const char *HELP =
"Usage: executable [OPTIONS] [FILENAME]\n"
"\n"
"Arguments:\n"
"  [FILENAME]  Profile data filename\n"
"\n"
"Options:\n"
"      --sorted   Whether to sort the stacks by time spent\n"
"      --echo     Print data to stdout on exit. Useful when piping to other tools\n"
"      --debug    Show debug info\n"
"  -h, --help     Print help\n"
"  -V, --version  Print version\n";

static void print_help(void) {
    fputs(HELP, stdout);
}

static void print_usage(FILE *f) {
    fputs("Usage: executable [OPTIONS] [FILENAME]\n", f);
}

static void unexpected_arg(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    if (arg[0] == '-') {
        fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    }
    print_usage(stderr);
    fputs("\nFor more information, try '--help'.\n", stderr);
}

static void unexpected_help_value(const char *value) {
    fprintf(stderr, "error: unexpected value '%s' for '--help' found; no more were expected\n\n", value);
    fputs("Usage: executable --help [FILENAME]\n", stderr);
    fputs("\nFor more information, try '--help'.\n", stderr);
}

static int parse_args(int argc, char **argv, Options *opt) {
    memset(opt, 0, sizeof(*opt));
    bool positional_only = false;
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (!positional_only && strcmp(a, "--") == 0) {
            positional_only = true;
            continue;
        }
        if (!positional_only && strcmp(a, "--sorted") == 0) {
            opt->sorted = true;
        } else if (!positional_only && strcmp(a, "--echo") == 0) {
            opt->echo = true;
        } else if (!positional_only && strcmp(a, "--debug") == 0) {
            opt->debug = true;
        } else if (!positional_only && (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0)) {
            print_help();
            exit(0);
        } else if (!positional_only && strcmp(a, "-V") == 0) {
            fputs("flamelens 0.3.1\n", stdout);
            exit(0);
        } else if (!positional_only && strcmp(a, "--version") == 0) {
            fputs("flamelens 0.3.1\n", stdout);
            exit(0);
        } else if (!positional_only && strncmp(a, "--help=", 7) == 0) {
            unexpected_help_value(a + 7);
            return 2;
        } else if (!positional_only && a[0] == '-') {
            unexpected_arg(a);
            return 2;
        } else {
            if (opt->filename != NULL) {
                unexpected_arg(a);
                return 2;
            }
            opt->filename = a;
        }
    }
    (void)opt->sorted;
    (void)opt->debug;
    return 0;
}

static char *read_stream(FILE *fp, size_t *out_len) {
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap + 1);
    if (!buf) return NULL;
    for (;;) {
        if (len == cap) {
            cap *= 2;
            char *nb = realloc(buf, cap + 1);
            if (!nb) {
                free(buf);
                return NULL;
            }
            buf = nb;
        }
        size_t n = fread(buf + len, 1, cap - len, fp);
        len += n;
        if (n == 0) {
            if (ferror(fp)) {
                free(buf);
                return NULL;
            }
            break;
        }
    }
    buf[len] = '\0';
    *out_len = len;
    return buf;
}

static char *read_file_or_stdin(const char *filename, size_t *len) {
    if (!filename) return read_stream(stdin, len);
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        fprintf(stderr,
                "\nthread 'main' (%ld) panicked at src/main.rs:44:47:\n"
                "Could not read file: Os { code: %d, kind: NotFound, message: \"%s\" }\n"
                "note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace\n",
                (long)getpid(), errno, strerror(errno));
        exit(101);
    }
    char *data = read_stream(fp, len);
    fclose(fp);
    return data;
}

static int non_tty_error(void) {
    fputs("Error: Os { code: 11, kind: WouldBlock, message: \"Resource temporarily unavailable\" }\n", stderr);
    return 1;
}

static void draw_minimal_ui(const char *data, size_t len, bool debug, bool sorted) {
    (void)sorted;
    printf("\033[2J\033[H");
    printf("flamelens\n");
    printf("Rows: ");
    size_t rows = 0;
    for (size_t i = 0; i < len; i++) if (data[i] == '\n') rows++;
    if (len && data[len - 1] != '\n') rows++;
    printf("%zu", rows);
    if (debug) printf("  Debug: on");
    printf("\n\n");
    size_t shown = 0, col = 0;
    for (size_t i = 0; i < len && shown < 20; i++) {
        char c = data[i];
        if (c == '\n') {
            putchar('\n');
            shown++;
            col = 0;
        } else if (col < 120) {
            putchar(c);
            col++;
        }
    }
    printf("\n\nq: quit");
    fflush(stdout);
}

static int run_tui(const char *data, size_t len, bool debug, bool sorted) {
    struct termios oldt, raw;
    bool have_termios = tcgetattr(STDIN_FILENO, &oldt) == 0;
    if (have_termios) {
        raw = oldt;
        raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 1;
        tcsetattr(STDIN_FILENO, TCSANOW, &raw);
    }
    printf("\033[?1049h\033[?25l");
    draw_minimal_ui(data, len, debug, sorted);
    for (;;) {
        unsigned char c;
        ssize_t n = read(STDIN_FILENO, &c, 1);
        if (n == 1 && (c == 'q' || c == 3)) break;
        if (n < 0 && errno != EAGAIN && errno != EINTR) break;
        struct timeval tv;
        tv.tv_sec = 0;
        tv.tv_usec = 50000;
        select(0, NULL, NULL, NULL, &tv);
    }
    printf("\033[?1049l\033[?1006l\033[?1015l\033[?1003l\033[?1002l\033[?1000l\033[?25h");
    fflush(stdout);
    if (have_termios) tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    return 0;
}

int main(int argc, char **argv) {
    Options opt;
    int rc = parse_args(argc, argv, &opt);
    if (rc != 0) return rc;

    size_t len = 0;
    char *data = read_file_or_stdin(opt.filename, &len);
    if (!data) return 1;

    if (opt.echo) {
        fwrite(data, 1, len, stdout);
        fputc('\n', stdout);
        fflush(stdout);
    }

    if (!isatty(STDOUT_FILENO) || !isatty(STDIN_FILENO)) {
        free(data);
        return non_tty_error();
    }
    int ret = run_tui(data, len, opt.debug, opt.sorted);
    free(data);
    return ret;
}
