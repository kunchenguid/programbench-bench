#!/usr/bin/env python3
import argparse
import json
import math
import os
import re
import sys
from urllib.parse import quote

VERSION = "0.41.0"
VALID_DRAFTS = {"4", "6", "7", "2019", "2020"}
VALID_OUTPUTS = {"text", "flag", "list", "hierarchical"}


class CliParser(argparse.ArgumentParser):
    def error(self, message):
        if message.startswith("the following arguments are required: SCHEMA"):
            sys.stderr.write("error: the following required arguments were not provided:\n  <SCHEMA>\n\n")
            sys.stderr.write("Usage: executable <SCHEMA>\n\nFor more information, try '--help'.\n")
            raise SystemExit(2)
        sys.stderr.write(f"error: {message}\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        raise SystemExit(2)


class Err:
    def __init__(self, message, path="", schema_path="", keyword=""):
        self.message = message
        self.path = path
        self.schema_path = schema_path
        self.keyword = keyword


def compact(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"))


def pretty(v):
    if isinstance(v, str):
        return json.dumps(v, ensure_ascii=False)
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    return json.dumps(v, ensure_ascii=False, separators=(",", ":"))


def plural(n, word):
    return word if n == 1 else word + "s"


def path_join(base, token):
    token = str(token).replace("~", "~0").replace("/", "~1")
    return base + "/" + token if base else "/" + token


def type_ok(inst, typ):
    if typ == "null":
        return inst is None
    if typ == "boolean":
        return isinstance(inst, bool)
    if typ == "object":
        return isinstance(inst, dict)
    if typ == "array":
        return isinstance(inst, list)
    if typ == "number":
        return (isinstance(inst, int) or isinstance(inst, float)) and not isinstance(inst, bool)
    if typ == "integer":
        return isinstance(inst, int) and not isinstance(inst, bool)
    if typ == "string":
        return isinstance(inst, str)
    return True


def type_name(inst):
    if inst is None:
        return "null"
    if isinstance(inst, bool):
        return "boolean"
    if isinstance(inst, dict):
        return "object"
    if isinstance(inst, list):
        return "array"
    if isinstance(inst, str):
        return "string"
    if isinstance(inst, int):
        return "integer"
    if isinstance(inst, float):
        return "number"
    return type(inst).__name__


def enum_list(vals):
    parts = [pretty(v) for v in vals]
    if len(parts) <= 1:
        return "".join(parts)
    if len(parts) == 2:
        return parts[0] + " or " + parts[1]
    return ", ".join(parts[:-1]) + " or " + parts[-1]


def types_list(vals):
    parts = sorted(json.dumps(v) for v in vals)
    if len(parts) <= 1:
        return "".join(parts)
    return ", ".join(parts[:-1]) + " or " + parts[-1]


def add_err(errors, msg, path, spath, kw):
    errors.append(Err(msg, path, spath, kw))


def check_format(fmt, value):
    if not isinstance(value, str):
        return True
    if fmt == "email":
        return re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", value) is not None
    if fmt == "ipv4":
        parts = value.split(".")
        return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 and str(int(p)) == p for p in parts)
    if fmt == "uri":
        return re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", value) is not None
    if fmt in ("date-time", "date", "time"):
        return bool(value)
    return True


def resolve_ref(root, ref):
    if not isinstance(ref, str) or not ref.startswith("#"):
        return None
    cur = root
    pointer = ref[1:]
    if pointer == "":
        return cur
    if not pointer.startswith("/"):
        return None
    for raw in pointer[1:].split("/"):
        token = raw.replace("~1", "/").replace("~0", "~")
        if isinstance(cur, dict) and token in cur:
            cur = cur[token]
        elif isinstance(cur, list) and token.isdigit() and int(token) < len(cur):
            cur = cur[int(token)]
        else:
            return None
    return cur


def validate(schema, inst, path="", spath="", assert_format=False, root=None):
    errors = []
    if root is None:
        root = schema
    if isinstance(schema, bool):
        if not schema:
            add_err(errors, f"False schema does not allow {pretty(inst)}", path, spath, "")
        return errors
    if not isinstance(schema, dict):
        return errors

    if "$ref" in schema:
        target = resolve_ref(root, schema["$ref"])
        if target is not None:
            errors.extend(validate(target, inst, path, schema["$ref"][1:] or "", assert_format, root))
            return errors

    if "type" in schema:
        t = schema["type"]
        ok = any(type_ok(inst, x) for x in t) if isinstance(t, list) else type_ok(inst, t)
        if not ok:
            if isinstance(t, list):
                add_err(errors, f"{pretty(inst)} is not of types {types_list(t)}", path, path_join(spath, "type"), "type")
            else:
                add_err(errors, f"{pretty(inst)} is not of type {json.dumps(t)}", path, path_join(spath, "type"), "type")

    if "const" in schema and inst != schema["const"]:
        add_err(errors, f"{pretty(schema['const'])} was expected", path, path_join(spath, "const"), "const")
    if "enum" in schema and inst not in schema["enum"]:
        add_err(errors, f"{pretty(inst)} is not one of {enum_list(schema['enum'])}", path, path_join(spath, "enum"), "enum")

    if isinstance(inst, (int, float)) and not isinstance(inst, bool):
        for key, text in (("minimum", "less than the minimum of"), ("maximum", "greater than the maximum of")):
            if key in schema:
                lim = schema[key]
                if (key == "minimum" and inst < lim) or (key == "maximum" and inst > lim):
                    add_err(errors, f"{pretty(inst)} is {text} {pretty(lim)}", path, path_join(spath, key), key)
        if "exclusiveMinimum" in schema:
            lim = schema["exclusiveMinimum"]
            if inst <= lim:
                add_err(errors, f"{pretty(inst)} is less than or equal to the minimum of {pretty(lim)}", path, path_join(spath, "exclusiveMinimum"), "exclusiveMinimum")
        if "exclusiveMaximum" in schema:
            lim = schema["exclusiveMaximum"]
            if inst >= lim:
                add_err(errors, f"{pretty(inst)} is greater than or equal to the maximum of {pretty(lim)}", path, path_join(spath, "exclusiveMaximum"), "exclusiveMaximum")
        if "multipleOf" in schema:
            m = schema["multipleOf"]
            q = inst / m if m else math.inf
            if abs(q - round(q)) > 1e-10:
                add_err(errors, f"{pretty(inst)} is not a multiple of {pretty(m)}", path, path_join(spath, "multipleOf"), "multipleOf")

    if isinstance(inst, str):
        if "minLength" in schema and len(inst) < schema["minLength"]:
            n = schema["minLength"]
            add_err(errors, f"{pretty(inst)} is shorter than {n} {plural(n, 'character')}", path, path_join(spath, "minLength"), "minLength")
        if "maxLength" in schema and len(inst) > schema["maxLength"]:
            n = schema["maxLength"]
            add_err(errors, f"{pretty(inst)} is longer than {n} {plural(n, 'character')}", path, path_join(spath, "maxLength"), "maxLength")
        if "pattern" in schema:
            try:
                if re.search(schema["pattern"], inst) is None:
                    add_err(errors, f"{pretty(inst)} does not match {pretty(schema['pattern'])}", path, path_join(spath, "pattern"), "pattern")
            except re.error:
                pass
        if assert_format and "format" in schema and not check_format(schema["format"], inst):
            add_err(errors, f"{pretty(inst)} is not a {pretty(schema['format'])}", path, path_join(spath, "format"), "format")

    if isinstance(inst, list):
        if "minItems" in schema and len(inst) < schema["minItems"]:
            n = schema["minItems"]
            add_err(errors, f"{pretty(inst)} has less than {n} {plural(n, 'item')}", path, path_join(spath, "minItems"), "minItems")
        if "maxItems" in schema and len(inst) > schema["maxItems"]:
            n = schema["maxItems"]
            add_err(errors, f"{pretty(inst)} has more than {n} {plural(n, 'item')}", path, path_join(spath, "maxItems"), "maxItems")
        if schema.get("uniqueItems") is True:
            seen = []
            for item in inst:
                if item in seen:
                    add_err(errors, f"{pretty(inst)} has non-unique elements", path, path_join(spath, "uniqueItems"), "uniqueItems")
                    break
                seen.append(item)
        if "items" in schema:
            items = schema["items"]
            if isinstance(items, list):
                for i, sub in enumerate(items[:len(inst)]):
                    errors.extend(validate(sub, inst[i], path_join(path, i), path_join(path_join(spath, "items"), i), assert_format, root))
            else:
                for i, item in enumerate(inst):
                    errors.extend(validate(items, item, path_join(path, i), path_join(spath, "items"), assert_format, root))

    if isinstance(inst, dict):
        props = schema.get("properties", {}) if isinstance(schema.get("properties", {}), dict) else {}
        matched = set()
        if "required" in schema:
            for req in schema["required"]:
                if req not in inst:
                    add_err(errors, f"{pretty(req)} is a required property", path, path_join(spath, "required"), "required")
        for key, sub in props.items():
            if key in inst:
                matched.add(key)
                errors.extend(validate(sub, inst[key], path_join(path, key), path_join(path_join(spath, "properties"), key), assert_format, root))
        if isinstance(schema.get("patternProperties"), dict):
            for pat, sub in schema["patternProperties"].items():
                try:
                    rx = re.compile(pat)
                except re.error:
                    continue
                for key in inst.keys():
                    if rx.search(key):
                        matched.add(key)
                        errors.extend(validate(sub, inst[key], path_join(path, key), path_join(path_join(spath, "patternProperties"), pat), assert_format, root))
        if "additionalProperties" in schema:
            extra = [k for k in inst.keys() if k not in matched and k not in props]
            ap = schema["additionalProperties"]
            if ap is False and extra:
                names = ", ".join(repr(k) for k in extra)
                was = "was" if len(extra) == 1 else "were"
                add_err(errors, f"Additional properties are not allowed ({names} {was} unexpected)", path, path_join(spath, "additionalProperties"), "additionalProperties")
            elif isinstance(ap, dict):
                for k in extra:
                    errors.extend(validate(ap, inst[k], path_join(path, k), path_join(spath, "additionalProperties"), assert_format, root))
        deps = schema.get("dependentRequired", schema.get("dependencies"))
        if isinstance(deps, dict):
            for key, reqs in deps.items():
                if key in inst:
                    if isinstance(reqs, list):
                        for req in reqs:
                            if req not in inst:
                                add_err(errors, f"{pretty(req)} is a required property", path, path_join(spath, "dependentRequired" if "dependentRequired" in schema else "dependencies"), "dependentRequired")
                    elif isinstance(reqs, dict):
                        errors.extend(validate(reqs, inst, path, path_join(path_join(spath, "dependencies"), key), assert_format, root))
        if isinstance(schema.get("propertyNames"), dict):
            for key in inst.keys():
                errors.extend(validate(schema["propertyNames"], key, path, path_join(spath, "propertyNames"), assert_format, root))
        if "minProperties" in schema and len(inst) < schema["minProperties"]:
            n = schema["minProperties"]
            add_err(errors, f"{pretty(inst)} has less than {n} {plural(n, 'property')}", path, path_join(spath, "minProperties"), "minProperties")
        if "maxProperties" in schema and len(inst) > schema["maxProperties"]:
            n = schema["maxProperties"]
            add_err(errors, f"{pretty(inst)} has more than {n} {plural(n, 'property')}", path, path_join(spath, "maxProperties"), "maxProperties")

    for key in ("allOf", "anyOf", "oneOf"):
        if key in schema and isinstance(schema[key], list):
            subs = [validate(s, inst, path, path_join(path_join(spath, key), i), assert_format, root) for i, s in enumerate(schema[key])]
            passes = sum(1 for e in subs if not e)
            if key == "allOf":
                for e in subs:
                    errors.extend(e)
            elif key == "anyOf" and passes == 0:
                add_err(errors, f"{pretty(inst)} is not valid under any of the schemas listed in the 'anyOf' keyword", path, path_join(spath, key), key)
            elif key == "oneOf" and passes != 1:
                if passes == 0:
                    add_err(errors, f"{pretty(inst)} is not valid under any of the schemas listed in the 'oneOf' keyword", path, path_join(spath, key), key)
                else:
                    add_err(errors, f"{pretty(inst)} is valid under more than one of the schemas listed in the 'oneOf' keyword", path, path_join(spath, key), key)
    if "not" in schema and not validate(schema["not"], inst, path, path_join(spath, "not"), assert_format, root):
        add_err(errors, f"{pretty(inst)} should not be valid under {pretty(schema['not'])}", path, path_join(spath, "not"), "not")
    if "if" in schema:
        cond_ok = not validate(schema["if"], inst, path, path_join(spath, "if"), assert_format, root)
        branch = "then" if cond_ok else "else"
        if branch in schema:
            errors.extend(validate(schema[branch], inst, path, path_join(spath, branch), assert_format, root))

    return errors


def file_uri(path):
    return "file://" + quote(os.path.abspath(path))


def output_json(schema_path, inst_path, mode, errors, schema):
    valid = not errors
    root = {"evaluationPath": "", "instanceLocation": "", "schemaLocation": file_uri(schema_path) + "#", "valid": valid}
    if mode == "flag":
        payload = {"valid": valid}
    else:
        details = []
        if mode == "list":
            details.append(root.copy())
        if errors:
            for e in errors:
                d = {"errors": {e.keyword or "": e.message}, "evaluationPath": e.schema_path, "instanceLocation": e.path, "schemaLocation": file_uri(schema_path) + "#" + e.schema_path, "valid": False}
                details.append(d)
        else:
            for key in schema.keys() if isinstance(schema, dict) else []:
                details.append({"evaluationPath": "/" + key, "instanceLocation": "", "schemaLocation": file_uri(schema_path) + "#/" + key, "valid": True})
        if mode == "list":
            payload = {"details": details, "valid": valid}
        else:
            payload = root.copy()
            payload["details"] = details
    return compact({"instance": inst_path, "output": mode, "payload": payload, "schema": schema_path})


def read_json(path):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print("Error: No such file or directory (os error 2)", file=sys.stderr)
        raise SystemExit(1)
    except json.JSONDecodeError as e:
        print(f"Error: {e.msg.lower()} at line {e.lineno} column {e.colno}", file=sys.stderr)
        raise SystemExit(1)


HELP = """Usage: executable [OPTIONS] [SCHEMA]

Arguments:
  [SCHEMA]  The JSON Schema to validate with (i.e. schema.json)

Options:
  -i, --instance <INSTANCES>       A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)
  -d, --draft <DRAFT>              Enforce a specific JSON Schema draft [possible values: 4, 6, 7, 2019, 2020]
      --assert-format              Turn ON format validation
      --no-assert-format           Turn OFF format validation
      --output <OUTPUT>            Select output style: text (default), flag, list, hierarchical [default: text] [possible values: text, flag, list, hierarchical]
  -v, --version                    Show program's version number and exit
      --errors-only                Only show validation errors
      --connect-timeout <SECONDS>  Timeout for establishing connections (in seconds)
      --timeout <SECONDS>          Total timeout for HTTP requests (in seconds)
  -k, --insecure                   Skip TLS certificate verification (dangerous!)
      --cacert <FILE>              Path to a custom CA certificate file (PEM format)
  -h, --help                       Print help"""


def parse_args(argv):
    if "-h" in argv or "--help" in argv:
        print(HELP)
        raise SystemExit(0)
    if "-v" in argv or "--version" in argv:
        print(f"Version: {VERSION}")
        raise SystemExit(0)
    p = CliParser(prog="executable", add_help=False, allow_abbrev=False)
    p.add_argument("-i", "--instance", action="append", dest="instances")
    p.add_argument("-d", "--draft")
    p.add_argument("--assert-format", action="store_true")
    p.add_argument("--no-assert-format", action="store_true")
    p.add_argument("--output", default="text")
    p.add_argument("--errors-only", action="store_true")
    p.add_argument("--connect-timeout")
    p.add_argument("--timeout")
    p.add_argument("-k", "--insecure", action="store_true")
    p.add_argument("--cacert")
    p.add_argument("schema", nargs="?")
    ns, extras = p.parse_known_args(argv)
    if extras:
        arg = extras[0]
        sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n")
        sys.stderr.write("Usage: executable [OPTIONS] [SCHEMA]\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)
    if ns.output not in VALID_OUTPUTS:
        sys.stderr.write(f"error: invalid value '{ns.output}' for '--output <OUTPUT>'\n  [possible values: text, flag, list, hierarchical]\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)
    if ns.draft is not None and ns.draft not in VALID_DRAFTS:
        sys.stderr.write(f"error: invalid value '{ns.draft}' for '--draft <DRAFT>'\n  [possible values: 4, 6, 7, 2019, 2020]\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)
    if not ns.schema:
        p.error("the following arguments are required: SCHEMA")
    return ns


def main(argv):
    ns = parse_args(argv)
    schema = read_json(ns.schema)
    if not ns.instances:
        print("Schema is valid")
        return 0
    any_invalid = False
    assert_fmt = ns.assert_format and not ns.no_assert_format
    for inst_path in ns.instances:
        inst = read_json(inst_path)
        errors = validate(schema, inst, assert_format=assert_fmt)
        if errors:
            any_invalid = True
        if ns.output == "text":
            if not errors:
                if not ns.errors_only:
                    print(f"{inst_path} - VALID")
            else:
                print(f"{inst_path} - INVALID. Errors:")
                for i, e in enumerate(errors, 1):
                    print(f"{i}. {e.message}")
        else:
            if ns.errors_only and not errors:
                continue
            print(output_json(ns.schema, inst_path, ns.output, errors, schema))
    return 1 if any_invalid else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
