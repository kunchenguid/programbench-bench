#!/usr/bin/env python3
import csv
import itertools
import json
import math
import os
import shlex
import statistics
import subprocess
import sys
import time
import resource

VERSION = "hyperfine 1.20.0"

HELP = """A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test". The latter is only available if the shell is not
          explicitly disabled via '--shell=none'. If multiple commands are
          given, hyperfine will show a comparison of the respective runtimes.

Options:
  -w, --warmup <NUM>
          Perform NUM warmup runs before the actual benchmark.
  -m, --min-runs <NUM>
          Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>
          Perform at most NUM runs for each command.
  -r, --runs <NUM>
          Perform exactly NUM runs for each command.
  -s, --setup <CMD>
          Execute CMD before each set of timing runs.
      --reference <CMD>
          The reference command for the relative comparison of results.
      --reference-name <CMD>
          Give a meaningful name to the reference command.
  -p, --prepare <CMD>
          Execute CMD before each timing run.
  -C, --conclude <CMD>
          Execute CMD after each timing run.
  -c, --cleanup <CMD>
          Execute CMD after the completion of all benchmarking runs.
  -P, --parameter-scan <VAR> <MIN> <MAX>
          Perform benchmark runs for each value in the range MIN..MAX.
  -D, --parameter-step-size <DELTA>
          This argument requires --parameter-scan to be specified as well.
  -L, --parameter-list <VAR> <VALUES>
          Perform benchmark runs for each value in the comma-separated list.
  -S, --shell <SHELL>
          Set the shell to use for executing benchmarked commands.
  -N
          An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]
          Ignore failures of the benchmarked programs.
      --style <TYPE>
          Set output style type (default: auto).
      --sort <METHOD>
          Specify the sort order of the speed comparison summary.
  -u, --time-unit <UNIT>
          Set the time unit to be used. Possible values: microsecond,
          millisecond, second.
      --export-asciidoc <FILE>
          Export the timing summary statistics as an AsciiDoc table.
      --export-csv <FILE>
          Export the timing summary statistics as CSV.
      --export-json <FILE>
          Export the timing summary statistics and timings as JSON.
      --export-markdown <FILE>
          Export the timing summary statistics as a Markdown table.
      --export-orgmode <FILE>
          Export the timing summary statistics as an Emacs org-mode table.
      --show-output
          Print the stdout and stderr of the benchmark instead of suppressing it.
      --output <WHERE>
          Control where the output of the benchmark is redirected.
      --input <WHERE>
          Control where the input of the benchmark comes from.
  -n, --command-name <NAME>
          Give a meaningful name to a command.
  -h, --help
          Print help
  -V, --version
          Print version
"""


class Opts:
    def __init__(self):
        self.warmup = 0
        self.min_runs = 10
        self.max_runs = None
        self.runs = None
        self.setup = []
        self.prepare = []
        self.conclude = []
        self.cleanup = []
        self.param_scan = None
        self.param_step = None
        self.param_lists = []
        self.shell = "default"
        self.ignore_failure = None
        self.style = "auto"
        self.sort = "auto"
        self.time_unit = None
        self.exports = {}
        self.show_output = False
        self.outputs = []
        self.inputs = []
        self.names = []
        self.reference = None
        self.reference_name = None
        self.commands = []


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def need(args, i, n, opt):
    if i + n >= len(args):
        die(f"error: a value is required for '{opt}' but none was supplied", 2)
    return args[i + 1:i + 1 + n]


def parse(argv):
    o = Opts()
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            o.commands.extend(argv[i + 1:])
            break
        if not a.startswith("-") or a == "-":
            o.commands.append(a)
            i += 1
            continue
        name, eq, val = a.partition("=")
        def value():
            nonlocal i, val, eq
            if eq:
                return val
            v = need(argv, i, 1, a)[0]
            i += 1
            return v
        if a in ("-h", "--help"):
            print(HELP.rstrip())
            sys.exit(0)
        elif a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        elif name in ("-w", "--warmup"):
            o.warmup = int(value())
        elif name in ("-m", "--min-runs"):
            o.min_runs = int(value())
        elif name in ("-M", "--max-runs"):
            o.max_runs = int(value())
        elif name in ("-r", "--runs"):
            o.runs = int(value())
        elif name in ("-s", "--setup"):
            o.setup.append(value())
        elif name == "--reference":
            o.reference = value()
        elif name == "--reference-name":
            o.reference_name = value()
        elif name in ("-p", "--prepare"):
            o.prepare.append(value())
        elif name in ("-C", "--conclude"):
            o.conclude.append(value())
        elif name in ("-c", "--cleanup"):
            o.cleanup.append(value())
        elif name in ("-P", "--parameter-scan"):
            vals = need(argv, i, 3, a)
            o.param_scan = (vals[0], vals[1], vals[2])
            i += 3
        elif name in ("-D", "--parameter-step-size"):
            o.param_step = value()
        elif name in ("-L", "--parameter-list"):
            vals = need(argv, i, 2, a)
            o.param_lists.append((vals[0], vals[1]))
            i += 2
        elif name in ("-S", "--shell"):
            o.shell = value()
        elif a == "-N":
            o.shell = "none"
        elif name in ("-i", "--ignore-failure"):
            o.ignore_failure = val if eq else "all-non-zero"
        elif name == "--style":
            o.style = value()
        elif name == "--sort":
            o.sort = value()
        elif name in ("-u", "--time-unit"):
            o.time_unit = value()
        elif name == "--export-asciidoc":
            o.exports["asciidoc"] = value()
        elif name == "--export-csv":
            o.exports["csv"] = value()
        elif name == "--export-json":
            o.exports["json"] = value()
        elif name == "--export-markdown":
            o.exports["markdown"] = value()
        elif name == "--export-orgmode":
            o.exports["orgmode"] = value()
        elif name == "--show-output":
            o.show_output = True
        elif name == "--output":
            o.outputs.append(value())
        elif name == "--input":
            o.inputs.append(value())
        elif name in ("-n", "--command-name"):
            o.names.append(value())
        else:
            die(f"error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] <command>...\n\nFor more information, try '--help'.", 2)
        i += 1
    if o.show_output and o.style != "auto":
        die("error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\nUsage: executable --style <TYPE> <command>...\n\nFor more information, try '--help'.", 2)
    if not o.commands:
        die("error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable [OPTIONS] <command>...\n\nFor more information, try '--help'.", 2)
    return o


def decimal_values(start_s, end_s, step_s):
    start, end, step = float(start_s), float(end_s), float(step_s)
    vals = []
    x = start
    decimals = max(*(len(s.split(".")[1]) if "." in s else 0 for s in (start_s, end_s, step_s)), 0)
    while x <= end + abs(step) / 1e6:
        if decimals:
            vals.append(f"{x:.{decimals}f}".rstrip("0").rstrip("."))
        else:
            vals.append(str(int(round(x))))
        x += step
    return vals


def expand_commands(o):
    params = []
    if o.param_scan:
        var, lo, hi = o.param_scan
        step = o.param_step or "1"
        params.append((var, decimal_values(lo, hi, step)))
    for var, values in o.param_lists:
        params.append((var, values.split(",")))
    commands = o.commands[:]
    if params:
        expanded = []
        for combo in itertools.product(*[v for _, v in params]):
            repl = dict(zip([k for k, _ in params], combo))
            for c in commands:
                s = c
                for k, v in repl.items():
                    s = s.replace("{" + k + "}", v)
                expanded.append(s)
        commands = expanded
    names = o.names[:]
    if names and len(names) != len(commands):
        die("Error: The number of command names has to match the number of commands.", 1)
    return [(names[i] if i < len(names) else c, c) for i, c in enumerate(commands)]


def shell_args(o, command):
    if o.shell == "none":
        return shlex.split(command), False
    if o.shell in ("default", ""):
        return command, True
    parts = shlex.split(o.shell)
    return parts + ["-c", command], False


def run_cmd(o, command, timed=False, iteration=None, output_mode=None, input_mode=None):
    env = os.environ.copy()
    if iteration is not None:
        env["HYPERFINE_ITERATION"] = str(iteration)
    stdin = subprocess.DEVNULL
    infile = None
    if input_mode and input_mode != "null":
        infile = open(input_mode, "rb")
        stdin = infile
    stdout = subprocess.DEVNULL
    stderr = subprocess.DEVNULL
    outfile = None
    if o.show_output or output_mode == "inherit":
        stdout = None
        stderr = None
    elif output_mode == "pipe":
        stdout = subprocess.PIPE
        stderr = subprocess.PIPE
    elif output_mode and output_mode != "null":
        outfile = open(output_mode, "ab")
        stdout = outfile
        stderr = outfile
    args, use_shell = shell_args(o, command)
    ru0 = resource.getrusage(resource.RUSAGE_CHILDREN)
    t0 = time.perf_counter()
    try:
        p = subprocess.run(args, shell=use_shell, stdin=stdin, stdout=stdout, stderr=stderr, env=env)
    except FileNotFoundError as e:
        if infile: infile.close()
        if outfile: outfile.close()
        raise e
    elapsed = time.perf_counter() - t0
    ru1 = resource.getrusage(resource.RUSAGE_CHILDREN)
    if infile:
        infile.close()
    if outfile:
        outfile.close()
    user = max(0.0, ru1.ru_utime - ru0.ru_utime)
    system = max(0.0, ru1.ru_stime - ru0.ru_stime)
    mem = max(0, int(ru1.ru_maxrss) * 1024)
    return p.returncode, elapsed, user, system, mem


def calibrate_shell(o):
    if o.shell == "none":
        return 0.0
    samples = []
    for _ in range(3):
        code, elapsed, *_ = run_cmd(o, "", output_mode="null", input_mode="null")
        if code == 0:
            samples.append(elapsed)
    return min(samples) if samples else 0.0


def selector(lst, idx, n, what):
    if not lst:
        return None
    if len(lst) == 1:
        return lst[0]
    if len(lst) == n:
        return lst[idx]
    die(f"Error: The --{what} option can be specified once, or exactly once per command.", 1)


def ignore_code(o, code):
    if code == 0:
        return True
    if o.ignore_failure is None:
        return False
    if o.ignore_failure in ("", "all-non-zero"):
        return True
    try:
        return code in [int(x) for x in o.ignore_failure.split(",") if x]
    except ValueError:
        return False


def summarize(name, command, times, users, systems, mems, codes):
    mean = statistics.fmean(times)
    stddev = statistics.stdev(times) if len(times) > 1 else 0.0
    med = statistics.median(times)
    return {
        "name": name, "command": command, "mean": mean, "stddev": stddev,
        "median": med, "user": statistics.fmean(users) if users else 0.0,
        "system": statistics.fmean(systems) if systems else 0.0,
        "min": min(times), "max": max(times), "times": times,
        "memory_usage_byte": mems, "exit_codes": codes
    }


def unit_for(o, seconds):
    u = o.time_unit
    if not u:
        if seconds < 0.001:
            u = "microsecond"
        elif seconds < 1:
            u = "millisecond"
        else:
            u = "second"
    if u in ("microsecond", "us", "µs"):
        return "µs", 1e6
    if u in ("millisecond", "ms"):
        return "ms", 1e3
    return "s", 1.0


def fmt_time(v, unit, scale, pad=False):
    x = v * scale
    if unit == "s":
        s = f"{x:.3f}"
    elif x >= 10:
        s = f"{x:.1f}"
    else:
        s = f"{x:.1f}"
    return s


def print_result(o, idx, res):
    if o.style == "none":
        return
    print(f"Benchmark {idx}: {res['name']}")
    unit, scale = unit_for(o, res["mean"])
    if len(res["times"]) == 1:
        print(f"  Time (abs ≡):       {fmt_time(res['mean'], unit, scale):>8} {unit:<2}               [User: {fmt_time(res['user'], unit, scale)} {unit}, System: {fmt_time(res['system'], unit, scale)} {unit}]")
    else:
        print(f"  Time (mean ± σ):    {fmt_time(res['mean'], unit, scale):>8} {unit} ± {fmt_time(res['stddev'], unit, scale):>5} {unit}    [User: {fmt_time(res['user'], unit, scale)} {unit}, System: {fmt_time(res['system'], unit, scale)} {unit}]")
        print(f"  Range (min … max):  {fmt_time(res['min'], unit, scale):>8} {unit} … {fmt_time(res['max'], unit, scale):>5} {unit}    {len(res['times'])} runs")
    if res["mean"] < 0.005 and o.shell != "none":
        print(" ")
        print("  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.")
    if any(c != 0 for c in res["exit_codes"]) and o.ignore_failure is not None:
        print("  Warning: Ignoring non-zero exit code.")
    print(" ")


def ordered(results, sort):
    if sort == "command":
        return list(results)
    return sorted(results, key=lambda r: r["mean"])


def print_summary(o, results):
    if o.style == "none" or len(results) < 2:
        return
    rows = ordered(results, "mean-time" if o.sort == "auto" else o.sort)
    fastest = rows[0]
    print("Summary")
    print(f"  {fastest['name']} ran")
    for r in rows[1:]:
        ratio = r["mean"] / fastest["mean"] if fastest["mean"] else 0.0
        print(f"    {ratio:.2f} times faster than {r['name']}")


def quote_csv(s):
    return s


def export_json(path, results):
    out = []
    for r in results:
        out.append({k: r[k] for k in ["command","mean","stddev","median","user","system","min","max","times","memory_usage_byte","exit_codes"]})
    with open(path, "w") as f:
        json.dump({"results": out}, f, indent=2)
        f.write("\n")


def export_csv(path, results):
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["command","mean","stddev","median","user","system","min","max"])
        for r in results:
            w.writerow([r["command"], r["mean"], r["stddev"], r["median"], r["user"], r["system"], r["min"], r["max"]])


def table_rows(o, results):
    rows = results if o.sort in ("auto", "command") else ordered(results, o.sort)
    ref = min(results, key=lambda r: r["mean"])
    if o.reference:
        for r in results:
            if r["command"] == o.reference or r["name"] == o.reference:
                ref = r
                break
    unit, scale = unit_for(o, min(r["mean"] for r in results))
    data = []
    for r in rows:
        rel = r["mean"] / ref["mean"] if ref["mean"] else 0.0
        relsd = rel * math.sqrt((r["stddev"]/r["mean"])**2 + (ref["stddev"]/ref["mean"])**2) if r["mean"] and ref["mean"] and (r is not ref) else 0.0
        rels = "1.00" if r is ref else f"{rel:.2f} ± {relsd:.2f}"
        data.append((r, unit, scale, rels))
    return unit, data


def export_markdown(path, o, results):
    unit, data = table_rows(o, results)
    with open(path, "w") as f:
        f.write(f"| Command | Mean [{unit}] | Min [{unit}] | Max [{unit}] | Relative |\n")
        f.write("|:---|---:|---:|---:|---:|\n")
        for r, _, scale, rel in data:
            f.write(f"| `{r['command']}` | {fmt_time(r['mean'], unit, scale)} ± {fmt_time(r['stddev'], unit, scale)} | {fmt_time(r['min'], unit, scale)} | {fmt_time(r['max'], unit, scale)} | {rel} |\n")


def export_asciidoc(path, o, results):
    unit, data = table_rows(o, results)
    with open(path, "w") as f:
        f.write('[cols="<,>,>,>,>"]\n|===\n')
        f.write(f"| Command \n| Mean [{unit}] \n| Min [{unit}] \n| Max [{unit}] \n| Relative \n\n")
        for r, _, scale, rel in data:
            f.write(f"| `{r['command']}` \n| {fmt_time(r['mean'], unit, scale)} ± {fmt_time(r['stddev'], unit, scale)} \n| {fmt_time(r['min'], unit, scale)} \n| {fmt_time(r['max'], unit, scale)} \n| {rel} \n")
        f.write("|===\n")


def export_org(path, o, results):
    unit, data = table_rows(o, results)
    with open(path, "w") as f:
        f.write(f"| Command  |  Mean [{unit}] |  Min [{unit}] |  Max [{unit}] |  Relative |\n")
        f.write("|--+--+--+--+--|\n")
        for r, _, scale, rel in data:
            f.write(f"| ={r['command']}=  |  {fmt_time(r['mean'], unit, scale)} ± {fmt_time(r['stddev'], unit, scale)} |  {fmt_time(r['min'], unit, scale)} |  {fmt_time(r['max'], unit, scale)} |  {rel} |\n")


def main(argv):
    o = parse(argv)
    commands = expand_commands(o)
    ncmd = len(commands)
    results = []
    runs = o.runs if o.runs is not None else o.min_runs
    if o.max_runs is not None:
        runs = min(runs, o.max_runs)
    runs = max(1, runs)
    shell_offset = calibrate_shell(o)

    for ci, (name, command) in enumerate(commands):
        prep = selector(o.prepare, ci, ncmd, "prepare")
        concl = selector(o.conclude, ci, ncmd, "conclude")
        outmode = selector(o.outputs, ci, ncmd, "output") or ("inherit" if o.show_output else "null")
        inmode = selector(o.inputs, ci, ncmd, "input") or "null"
        if o.style != "none":
            print(f"Benchmark {ci + 1}: {name}")
            sys.stdout.flush()
        for s in o.setup:
            code, *_ = run_cmd(o, s, output_mode="inherit" if o.show_output else "null")
            if code != 0:
                die(f"Error: Setup command terminated with non-zero exit code {code}.", 1)
        for _ in range(o.warmup):
            code, *_ = run_cmd(o, command, output_mode=outmode, input_mode=inmode)
            if not ignore_code(o, code):
                die(f"Error: Command terminated with non-zero exit code {code} during warmup run.", 1)
        times = []
        users = []
        systems = []
        mems = []
        codes = []
        for ri in range(1, runs + 1):
            if prep:
                code, *_ = run_cmd(o, prep, iteration=ri, output_mode="inherit" if o.show_output else "null")
                if code != 0:
                    die(f"Error: Preparation command terminated with non-zero exit code {code}.", 1)
            try:
                code, elapsed, user, system, mem = run_cmd(o, command, timed=True, iteration=ri, output_mode=outmode, input_mode=inmode)
                elapsed = max(0.000001, elapsed - shell_offset)
            except FileNotFoundError as e:
                die(f"Error: No such file or directory: {e.filename}", 1)
            if concl:
                ccode, *_ = run_cmd(o, concl, iteration=ri, output_mode="inherit" if o.show_output else "null")
                if ccode != 0:
                    die(f"Error: Conclude command terminated with non-zero exit code {ccode}.", 1)
            if not ignore_code(o, code):
                die(f"Error: Command terminated with non-zero exit code {code} in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.", 1)
            times.append(elapsed)
            users.append(user)
            systems.append(system)
            mems.append(mem)
            codes.append(code)
        for c in o.cleanup:
            code, *_ = run_cmd(o, c, output_mode="inherit" if o.show_output else "null")
            if code != 0:
                die(f"Error: Cleanup command terminated with non-zero exit code {code}.", 1)
        res = summarize(name, command, times, users, systems, mems, codes)
        results.append(res)
        if o.style != "none":
            # Avoid printing the benchmark header twice; rewrite by emitting only detail lines.
            unit, scale = unit_for(o, res["mean"])
            if len(res["times"]) == 1:
                print(f"  Time (abs ≡):       {fmt_time(res['mean'], unit, scale):>8} {unit:<2}               [User: {fmt_time(res['user'], unit, scale)} {unit}, System: {fmt_time(res['system'], unit, scale)} {unit}]")
            else:
                print(f"  Time (mean ± σ):    {fmt_time(res['mean'], unit, scale):>8} {unit} ± {fmt_time(res['stddev'], unit, scale):>5} {unit}    [User: {fmt_time(res['user'], unit, scale)} {unit}, System: {fmt_time(res['system'], unit, scale)} {unit}]")
                print(f"  Range (min … max):  {fmt_time(res['min'], unit, scale):>8} {unit} … {fmt_time(res['max'], unit, scale):>5} {unit}    {len(res['times'])} runs")
            if res["mean"] < 0.005 and o.shell != "none":
                print(" ")
                print("  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.")
            if any(c != 0 for c in res["exit_codes"]) and o.ignore_failure is not None:
                print("  Warning: Ignoring non-zero exit code.")
            print(" ")
    print_summary(o, results)
    if "json" in o.exports:
        export_json(o.exports["json"], results)
    if "csv" in o.exports:
        export_csv(o.exports["csv"], results)
    if "markdown" in o.exports:
        export_markdown(o.exports["markdown"], o, results)
    if "asciidoc" in o.exports:
        export_asciidoc(o.exports["asciidoc"], o, results)
    if "orgmode" in o.exports:
        export_org(o.exports["orgmode"], o, results)


if __name__ == "__main__":
    try:
        main(sys.argv[1:])
    except BrokenPipeError:
        pass
