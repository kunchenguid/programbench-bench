#!/usr/bin/env python3
import difflib
import fnmatch
import os
import re
import sys

VERSION = "statix 0.5.8"

LINTS = [
    ("W01", "bool_comparison"),
    ("W02", "empty_let_in"),
    ("W03", "manual_inherit"),
    ("W04", "manual_inherit_from"),
    ("W05", "legacy_let_syntax"),
    ("W06", "collapsible_let_in"),
    ("W07", "eta_reduction"),
    ("W08", "useless_parens"),
    ("W10", "empty_pattern"),
    ("W11", "redundant_pattern_bind"),
    ("W12", "unquoted_uri"),
    ("W14", "empty_inherit"),
    ("W17", "deprecated_to_path"),
    ("W18", "bool_simplification"),
    ("W19", "useless_has_attr"),
    ("W20", "repeated_keys"),
    ("W23", "empty_list_concat"),
]

EXPLAINS = {
1: """## What it does
Checks for expressions of the form `x == true`, `x != true` and
suggests using the variable directly.

## Why is this bad?
Unnecessary code.

## Example
Instead of checking the value of `x`:

```nix
if x == true then 0 else 1
```

Use `x` directly:

```nix
if x then 0 else 1
```""",
2: """## What it does
Checks for `let-in` expressions which create no new bindings.

## Why is this bad?
`let-in` expressions that create no new bindings are useless.
These are probably remnants from debugging or editing expressions.

## Example

```nix
let in pkgs.statix
```

Preserve only the body of the `let-in` expression:

```nix
pkgs.statix
```""",
3: """## What it does
Checks for bindings of the form `a = a`.

## Why is this bad?
If the aim is to bring attributes from a larger scope into
the current scope, prefer an inherit statement.

## Example

```nix
let
  a = 2;
in
  { a = a; b = 3; }
```

Try `inherit` instead:

```nix
let
  a = 2;
in
  { inherit a; b = 3; }
```""",
4: """## What it does
Checks for bindings of the form `a = someAttr.a`.

## Why is this bad?
If the aim is to extract or bring attributes of an attrset into
scope, prefer an inherit statement.

## Example

```nix
let
  mtl = pkgs.haskellPackages.mtl;
in
  null
```

Try `inherit` instead:

```nix
let
  inherit (pkgs.haskellPackages) mtl;
in
  null
```""",
5: """## What it does
Checks for legacy-let syntax that was never formalized.

## Why is this bad?
This syntax construct is undocumented, refrain from using it.

## Example

Legacy let syntax makes use of an attribute set annotated with
`let` and expects a `body` attribute.
```nix
let {
  body = x + y;
  x = 2;
  y = 3;
}
```

This is trivially representible via `rec`, which is documented
and more widely known:

```nix
rec {
  body = x + y;
  x = 2;
  y = 3;
}.body
```""",
6: """## What it does
Checks for `let-in` expressions whose body is another `let-in`
expression.

## Why is this bad?
Unnecessary code, the `let-in` expressions can be merged.

## Example

```nix
let
  a = 2;
in
let
  b = 3;
in
  a + b
```

Merge both `let-in` expressions:

```nix
let
  a = 2;
  b = 3;
in
  a + b
```""",
7: """## What it does
Checks for eta-reducible functions, i.e.: converts lambda
expressions into free standing functions where applicable.

## Why is this bad?
Oftentimes, eta-reduction results in code that is more natural
to read.

## Example

```nix
let
  double = i: 2 * i;
in
map (x: double x) [ 1 2 3 ]
```

The lambda passed to the `map` function is eta-reducible, and the
result reads more naturally:

```nix
let
  double = i: 2 * i;
in
map double [ 1 2 3 ]
```""",
8: """## What it does
Checks for unnecessary parentheses.

## Why is this bad?
Unnecessarily parenthesized code is hard to read.

## Example

```nix
let
  double = (x: 2 * x);
  ls = map (double) [ 1 2 3 ];
in
  (2 + 3)
```

Remove unnecessary parentheses:

```nix
let
  double = x: 2 * x;
  ls = map double [ 1 2 3 ];
in
  2 + 3
```""",
10: """## What it does
Checks for an empty variadic pattern: `{...}`, in a function
argument.

## Why is this bad?
The intention with empty patterns is not instantly obvious. Prefer
an underscore identifier instead, to indicate that the argument
is being ignored.

## Example

```nix
client = { ... }: {
  services.irmaseal-pkg.enable = true;
};
```

Replace the empty variadic pattern with `_` to indicate that you
intend to ignore the argument:

```nix
client = _: {
  services.irmaseal-pkg.enable = true;
};
```""",
11: """## What it does
Checks for binds of the form `inputs @ { ... }` in function
arguments.

## Why is this bad?
The variadic pattern here is redundant, as it does not capture
anything.

## Example

```nix
inputs @ { ... }: inputs.nixpkgs
```

Remove the pattern altogether:

```nix
inputs: inputs.nixpkgs
```""",
12: """## What it does
Checks for URI expressions that are not quoted.

## Why is this bad?
The Nix language has a special syntax for URLs even though quoted
strings can also be used to represent them. Unlike paths, URLs do
not have any special properties in the Nix expression language
that would make the difference useful. Moreover, using variable
expansion in URLs requires some URLs to be quoted strings anyway.
So the most consistent approach is to always use quoted strings to
represent URLs. Additionally, a semicolon immediately after the
URL can be mistaken for a part of URL by language-agnostic tools
such as terminal emulators.

See RFC 00045 [1] for more.

[1]: https://github.com/NixOS/rfcs/blob/master/rfcs/0045-deprecate-url-syntax.md

## Example

```nix
inputs = {
  gitignore.url = github:hercules-ci/gitignore.nix;
}
```

Quote the URI expression:

```nix
inputs = {
  gitignore.url = "github:hercules-ci/gitignore.nix";
}
```""",
14: """## What it does
Checks for empty `inherit` statements.

## Why is this bad?
An empty inherit statement has no effect.

## Example

```nix
let inherit ; in 1
```

Remove the empty inherit statement.
""",
17: """## What it does
Checks for usages of the deprecated `builtins.toPath` builtin.

## Why is this bad?
The builtin is deprecated in Nix.
""",
18: """## What it does
Checks for boolean `if` expressions that can be simplified.

## Why is this bad?
Returning boolean literals from a boolean condition is unnecessary.
""",
19: """## What it does
Checks for `if` expressions that test an attribute before reading it.

## Why is this bad?
Nix supports the shorter `or` form for this pattern.
""",
20: """## What it does
Checks for repeated keys in attribute sets.

## Why is this bad?
Repeated keys are easy to miss and can make code misleading.
""",
23: """## What it does
Checks for list concatenations with the empty list.

## Why is this bad?
Concatenating with `[]` has no effect.
""",
}

TOP_HELP = """statix 0.5.8

Akshay <nerdy@peppe.rs>

Lints and suggestions for the Nix programming language

USAGE:
    executable <SUBCOMMAND>

OPTIONS:
    -h, --help       Print help information
    -V, --version    Print version information

SUBCOMMANDS:
    check      Lints and suggestions for the nix programming language
    dump       Dump a sample config to stdout
    explain    Print detailed explanation for a lint warning
    fix        Find and fix issues raised by statix-check
    help       Print this message or the help of the given subcommand(s)
    list       List all available lints
    single     Fix exactly one issue at provided position"""

HELP = {
"check": """executable-check 

Lints and suggestions for the nix programming language

USAGE:
    executable check [OPTIONS] [--] [TARGET]

ARGS:
    <TARGET>    File or directory to run check on [default: .]

OPTIONS:
    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]
    -h, --help                  Print help information
    -i, --ignore <IGNORE>...    Globs of file patterns to skip
    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]
    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on
                                stdout
    -u, --unrestricted          Don't respect .gitignore files""",
"fix": """executable-fix 

Find and fix issues raised by statix-check

USAGE:
    executable fix [OPTIONS] [--] [TARGET]

ARGS:
    <TARGET>    File or directory to run fix on [default: .]

OPTIONS:
    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]
    -d, --dry-run               Do not fix files in place, display a diff instead
    -h, --help                  Print help information
    -i, --ignore <IGNORE>...    Globs of file patterns to skip
    -s, --stdin                 Enable "streaming" mode, accept file on stdin, output diagnostics on
                                stdout
    -u, --unrestricted          Don't respect .gitignore files""",
"single": """executable-single 

Fix exactly one issue at provided position

USAGE:
    executable single [OPTIONS] --position <POSITION> [TARGET]

ARGS:
    <TARGET>    File to run single-fix on

OPTIONS:
    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]
    -d, --dry-run                Do not fix files in place, display a diff instead
    -h, --help                   Print help information
    -p, --position <POSITION>    Position to attempt a fix at
    -s, --stdin                  Enable "streaming" mode, accept file on stdin, output diagnostics
                                 on stdout""",
"dump": "executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information",
"explain": "executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information",
"list": "executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information",
}

class Diag:
    def __init__(self, code, line, col, msg):
        self.code = code
        self.line = line
        self.col = col
        self.msg = msg

def lc_at(text, idx):
    line = text.count("\n", 0, idx) + 1
    start = text.rfind("\n", 0, idx)
    col = idx + 1 if start < 0 else idx - start
    return line, col

def disabled_from_config(path):
    disabled, ignores = set(), [".direnv"]
    candidates = []
    if path:
        candidates.append(path if path.endswith(".toml") else os.path.join(path, "statix.toml"))
    candidates.append("statix.toml")
    for p in candidates:
        try:
            s = open(p, encoding="utf-8").read()
        except OSError:
            continue
        m = re.search(r"disabled\s*=\s*\[([^\]]*)\]", s, re.S)
        if m:
            for item in re.findall(r"['\"]([^'\"]+)['\"]", m.group(1)):
                disabled.add(item)
                if item.startswith("W") and item[1:].isdigit():
                    disabled.add(str(int(item[1:])))
        m = re.search(r"ignore\s*=\s*\[([^\]]*)\]", s, re.S)
        if m:
            ignores += re.findall(r"['\"]([^'\"]+)['\"]", m.group(1))
        break
    return disabled, ignores

def add(diags, disabled, code, idx, text, msg):
    n = int(code[1:])
    name = dict(LINTS).get(code, "")
    if code in disabled or str(n) in disabled or name in disabled:
        return
    line, col = lc_at(text, idx)
    diags.append(Diag(n, line, col, msg))

def analyze(text, disabled=None):
    disabled = disabled or set()
    diags = []
    for m in re.finditer(r"\b([A-Za-z_][\w'.-]*(?:\.[A-Za-z_][\w'.-]*)*)\s*(==|!=)\s*(true|false)\b", text):
        add(diags, disabled, "W01", m.start(), text, f"Comparing `{m.group(1)}` with boolean literal `{m.group(3)}`")
    for m in re.finditer(r"\blet\s+in\s+", text):
        add(diags, disabled, "W02", m.start(), text, "This let-in expression has no entries")
    for m in re.finditer(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;", text):
        add(diags, disabled, "W03", m.start(2), text, "This assignment is better written with `inherit`")
    if re.search(r"^\s*let\s*\{", text):
        add(diags, disabled, "W05", re.search(r"let", text).start(), text, "Prefer `rec` over undocumented `let` syntax")
    for m in re.finditer(r"\bin\s*\n\s*let\b", text):
        add(diags, disabled, "W06", m.start(), text, "This `let in` expression is nested")
    for m in re.finditer(r"\(\s*([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\s*\)", text):
        add(diags, disabled, "W07", m.start(), text, f"Found eta-reduction: `{m.group(2)}`")
    for m in re.finditer(r"=\s*\(([^()\n;]+)\)\s*;", text):
        add(diags, disabled, "W08", m.start(1)-1, text, "Useless parentheses around value in binding")
    for m in re.finditer(r"\{\s*\.\.\.\s*\}\s*:", text):
        prefix = text[max(0, m.start()-20):m.start()]
        if re.search(r"@\s*$", prefix):
            continue
        add(diags, disabled, "W10", m.start(), text, "This pattern is empty, use `_` instead")
    for m in re.finditer(r"\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:", text):
        add(diags, disabled, "W11", m.start(), text, f"This pattern bind is redundant, use `{m.group(1)}` instead")
    for m in re.finditer(r"(?<![\"'])\b([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+#~-]+)", text):
        if m.group(1) not in ("http:", "https:"):
            add(diags, disabled, "W12", m.start(), text, "Consider quoting this URI expression")
    for m in re.finditer(r"\binherit\s*;", text):
        add(diags, disabled, "W14", m.start(), text, "Remove this empty `inherit` statement")
    for m in re.finditer(r"\bbuiltins\.toPath\b", text):
        add(diags, disabled, "W17", m.start(), text, "`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more")
    for m in re.finditer(r"\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n}]+)", text):
        add(diags, disabled, "W19", m.start(), text, f"Consider using `{m.group(1)}.{m.group(2)} or ({m.group(3).strip()})` instead of this `if` expression")
    for m in re.finditer(r"(\[\s*\]\s*\+\+|(\+\+\s*\[\s*\]))", text):
        add(diags, disabled, "W23", m.start(), text, "Concatenation with the empty list, `[]`, is a no-op")
    diags.sort(key=lambda d: (d.line, d.col, d.code))
    return diags

def fix_text(text, single_pos=None):
    old = None
    while old != text:
        old = text
        text = re.sub(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*\2\s*;", r"\1inherit \2;", text)
        text = re.sub(r"\b([A-Za-z_][\w'.-]*)\s*==\s*true\b", r"\1", text)
        text = re.sub(r"\b([A-Za-z_][\w'.-]*)\s*!=\s*false\b", r"\1", text)
        text = re.sub(r"\b([A-Za-z_][\w'.-]*)\s*==\s*false\b", r"! \1", text)
        text = re.sub(r"\b([A-Za-z_][\w'.-]*)\s*!=\s*true\b", r"! \1", text)
        text = re.sub(r"\blet\s+in\s+", "", text)
        text = re.sub(r"\bin\s*\n\s*let\s*\n", "\n", text)
        text = re.sub(r"\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:", r"\1:", text)
        text = re.sub(r"\{\s*\.\.\.\s*\}\s*:", "_:", text)
        text = re.sub(r"(?<![\"'])\b([A-Za-z][A-Za-z0-9+.-]*:[A-Za-z0-9_./?=&%+#~-]+)", r'"\1"', text)
        text = re.sub(r"=\s*\(([^()\n;]+)\)\s*;", r"= \1;", text)
        text = re.sub(r"\(\s*([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+\1\s*\)", r"\2", text)
        text = re.sub(r"\binherit\s*;\s*", "", text)
        text = re.sub(r"\bif\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+\1\.\2\s+else\s+([^;\n}]+)", lambda m: f"{m.group(1)}.{m.group(2)} or ({m.group(3).strip()})", text)
        text = re.sub(r"\[\s*\]\s*\+\+\s*", "", text)
        text = re.sub(r"\s*\+\+\s*\[\s*\]", "", text)
    m = re.match(r"\s*let\s*\{(.*)\}\s*$", text, re.S)
    if m and "body" in m.group(1):
        entries = [x.strip() for x in m.group(1).split(";") if x.strip()]
        text = "rec {\n" + "\n".join("  " + e + ";" for e in entries) + "\n}.body\n"
    return text

def print_diag(path, d, fmt):
    if fmt == "errfmt":
        print(f"{path}>{d.line}:{d.col}:W:{d.code}:{d.msg}")
    else:
        print(f"[W{d.code:02d}] Warning: {d.msg}\n   --> {path}:{d.line}:{d.col}")

def iter_files(target, ignores):
    if os.path.isfile(target):
        return [target]
    out = []
    for root, dirs, files in os.walk(target):
        dirs[:] = [d for d in dirs if d != ".git" and not any(fnmatch.fnmatch(d, pat) for pat in ignores)]
        for f in files:
            p = os.path.join(root, f)
            rel = os.path.relpath(p, ".")
            if f.endswith(".nix") and not any(fnmatch.fnmatch(rel, pat) or fnmatch.fnmatch(f, pat) for pat in ignores):
                out.append(p)
    return sorted(out)

def parse_common(args):
    opts = {"stdin": False, "dry": False, "fmt": "stderr", "config": ".", "ignore": [], "target": "."}
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-s", "--stdin"):
            opts["stdin"] = True
        elif a in ("-d", "--dry-run"):
            opts["dry"] = True
        elif a in ("-u", "--unrestricted"):
            pass
        elif a in ("-o", "--format"):
            i += 1; opts["fmt"] = args[i]
        elif a.startswith("--format="):
            opts["fmt"] = a.split("=",1)[1]
        elif a in ("-c", "--config"):
            i += 1; opts["config"] = args[i]
        elif a in ("-i", "--ignore"):
            i += 1; opts["ignore"].append(args[i])
        elif a == "--":
            if i + 1 < len(args): opts["target"] = args[i+1]
            break
        elif not a.startswith("-"):
            opts["target"] = a
        i += 1
    return opts

def cmd_check(args):
    if "-h" in args or "--help" in args:
        print(HELP["check"]); return 0
    opts = parse_common(args)
    disabled, ignores = disabled_from_config(opts["config"])
    ignores += opts["ignore"]
    any_diag = False
    if opts["stdin"]:
        text = sys.stdin.read()
        for d in analyze(text, disabled):
            any_diag = True; print_diag("<stdin>", d, opts["fmt"])
    else:
        for p in iter_files(opts["target"], ignores):
            try: text = open(p, encoding="utf-8").read()
            except UnicodeDecodeError: continue
            for d in analyze(text, disabled):
                any_diag = True; print_diag(p, d, opts["fmt"])
    return 1 if any_diag else 0

def unified(path, old, new):
    return "\n".join(difflib.unified_diff(old.splitlines(), new.splitlines(), fromfile=path, tofile=path+" [fixed]", lineterm="")) + ("\n" if old != new else "")

def cmd_fix(args, single=False):
    key = "single" if single else "fix"
    if "-h" in args or "--help" in args:
        print(HELP[key]); return 0
    opts = parse_common(args)
    disabled, ignores = disabled_from_config(opts["config"])
    ignores += opts["ignore"]
    changed = False
    if opts["stdin"]:
        old = sys.stdin.read(); new = fix_text(old)
        if opts["dry"]: print(unified("<stdin>", old, new), end="")
        else: print(new, end="")
        return 0
    for p in iter_files(opts["target"], ignores):
        old = open(p, encoding="utf-8").read()
        new = fix_text(old)
        if new != old:
            changed = True
            if opts["dry"]:
                print(unified(p, old, new), end="")
            else:
                open(p, "w", encoding="utf-8").write(new)
    return 0

def main():
    args = sys.argv[1:]
    if not args or args[0] in ("-h", "--help"):
        print(TOP_HELP); return 0
    if args[0] in ("-V", "--version"):
        print(VERSION); return 0
    cmd, rest = args[0], args[1:]
    if cmd == "help":
        if not rest:
            print(TOP_HELP); return 0
        print(HELP.get(rest[0], TOP_HELP)); return 0
    if cmd == "list":
        if "-h" in rest or "--help" in rest: print(HELP["list"])
        else:
            for code, name in LINTS: print(code, name)
        return 0
    if cmd == "dump":
        if "-h" in rest or "--help" in rest: print(HELP["dump"])
        else: print("disabled = []\nignore = ['.direnv']\n")
        return 0
    if cmd == "explain":
        if "-h" in rest or "--help" in rest or not rest:
            print(HELP["explain"]); return 0
        s = rest[0].upper()
        n = int(s[1:] if s.startswith("W") and s[1:].isdigit() else s)
        if n not in EXPLAINS:
            print(f"explain error: lint with code `{n}` not found", file=sys.stderr); return 1
        print(EXPLAINS[n]); return 0
    if cmd == "check": return cmd_check(rest)
    if cmd == "fix": return cmd_fix(rest)
    if cmd == "single": return cmd_fix(rest, True)
    print(f"error:  The subcommand '{cmd}' wasn't recognized", file=sys.stderr)
    print("\nUSAGE:\n    executable <subcommands>\n\nFor more information try --help", file=sys.stderr)
    return 1

if __name__ == "__main__":
    sys.exit(main())
