#!/usr/bin/env python3
import os, sys, re, hashlib, datetime, calendar
from pathlib import Path

VERSION = "4.8.2"
HELP = """Usage:
calcurse [-D <directory>] [-C <directory>] [-c <calendar file>]
calcurse -Q [--from <date>] [--to <date>] [--days <number>]
calcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]
calcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon

Operations in command line mode:
  -Q, --query   Print items in a given query range
  -G, --grep    Grep items from the data files
  -P, --purge   Read items and write them back
Query short forms:
-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>

Note that filter, format and day-range options affect input or output:
  --filter-*              Filter items loaded by -Q, -G, -P and -x
  --format-*              Rewrite output from -Q, -G and --dump-imported
  --from <date>           Limit day range of -Q.
  --to <date>             Limit day range of -Q.
  --days <number>         Limit day range of -Q.

  --limit, -l <number>    Limit number of query results
  --search, -S <regexp>   Match regular expression in queries
Consult the man page for details.

Miscellaneous:
  -c, --calendar <file>   The calendar data file to use
  -C, --confdir <dir>     The configuration directory to use
  --daemon                Run notification daemon in the background
  -D, --datadir <dir>     The data directory to use
  -g, --gc                Run the garbage collector
  -h, --help              Show this help text
  -i, --import <file>     Import iCal data from file
  -q, --quiet             Suppress import/export result message
  --read-only             Do not save configuration or data files
  --status                Display status of running instances
  -v, --version           Show version information
  -x, --export[<format>]  Export to stdout in ical (default) or pcal format

For more information, type '?' from within calcurse, or read the manpage.
Submit feature requests and suggestions to <misc@calcurse.org>.
Submit bug reports to <bugs@calcurse.org>."""

def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)

def default_dir():
    home = Path(os.environ.get("HOME", "."))
    old = home/".calcurse"
    if old.exists(): return old
    return Path(os.environ.get("XDG_DATA_HOME", str(home/".local/share")))/"calcurse"

def unesc(s):
    return s.replace("\\n","\n").replace("\\,",",").replace("\\;",";").replace("\\\\","\\")

def esc(s):
    return s.replace("\\","\\\\").replace("\n","\\n").replace(",","\\,").replace(";","\\;")

def parse_date(s, fmt=1):
    s = s.strip()
    today = datetime.date.today()
    lows = {"today":0,"now":0,"tomorrow":1,"yesterday":-1}
    if s.lower() in lows: return today + datetime.timedelta(days=lows[s.lower()])
    wds = ["mon","tue","wed","thu","fri","sat","sun"]
    if s[:3].lower() in wds:
        d = (wds.index(s[:3].lower()) - today.weekday()) % 7
        return today + datetime.timedelta(days=d)
    parts = re.split(r"[-/]", s)
    if len(parts) != 3: raise ValueError
    a,b,c = map(int, parts)
    if "-" in s or fmt == 4 or len(parts[0]) == 4:
        y,m,d = a,b,c
    elif fmt == 2:
        d,m,y = a,b,c
    elif fmt == 3:
        y,m,d = a,b,c
    else:
        m,d,y = a,b,c
    if y < 100: y += 2000 if y < 70 else 1900
    return datetime.date(y,m,d)

def fmt_date(d): return d.strftime("%m/%d/%y")
def fmt_store_date(d): return d.strftime("%m/%d/%Y")
def fmt_ical_dt(dt): return dt.strftime("%Y%m%dT%H%M%S")
def fmt_ical_date(d): return d.strftime("%Y%m%d")

class Item:
    def __init__(self, typ, summary="", start=None, end=None, prio=0, note=None, raw=None, recur=None):
        self.typ, self.summary, self.start, self.end, self.prio, self.note, self.raw, self.recur = typ, summary, start, end, prio, note, raw, recur

def note_hash(text): return hashlib.sha1(text.encode()).hexdigest()

def make_note(desc, loc=None, comment=None, extra=None):
    chunks = []
    if desc is not None: chunks.append(desc)
    tails = []
    if loc is not None: tails.append("Location: " + loc)
    if comment is not None:
        lines = comment.splitlines()
        if lines:
            tails.append("Comment: " + lines[0] + ("\n" + "\n".join("    "+x for x in lines[1:]) if len(lines)>1 else ""))
    if extra: tails.append("Import: " + extra)
    if tails:
        if chunks: chunks.append("-- \n" + "\n".join(tails))
        else: chunks.append("-- \n" + "\n".join(tails))
    return ("\n".join(chunks) + "\n") if chunks else None

def prop_name(line):
    left = line.split(":",1)[0]
    return left.split(";",1)[0].upper()

def prop_val(line):
    return line.split(":",1)[1] if ":" in line else ""

def unfold(raw):
    raw = raw.replace("\r\n","\n").replace("\r","\n").splitlines()
    out = []
    for ln in raw:
        if (ln.startswith(" ") or ln.startswith("\t")) and out:
            out[-1] += ln[1:]
        else:
            out.append(ln)
    return out

def parse_ical_dt(v, dateonly=False):
    v = v.strip()
    if v.endswith("Z"): v = v[:-1]
    if dateonly or re.fullmatch(r"\d{8}", v):
        return datetime.datetime.strptime(v[:8], "%Y%m%d")
    return datetime.datetime.strptime(v[:15], "%Y%m%dT%H%M%S")

def parse_duration(v):
    m = re.fullmatch(r"P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?", v.strip())
    if not m: return datetime.timedelta()
    d,h,mi,s = [(int(x) if x else 0) for x in m.groups()]
    return datetime.timedelta(days=d, hours=h, minutes=mi, seconds=s)

def parse_rrule(v, start, is_event=False, end=None):
    p = {}
    for part in v.split(";"):
        if "=" in part:
            k,val = part.split("=",1); p[k.upper()] = val
    freq = p.get("FREQ","").upper()
    interval = int(p.get("INTERVAL","1") or "1")
    code = {"DAILY":"D","WEEKLY":"W","MONTHLY":"M","YEARLY":"Y"}.get(freq)
    if not code: return None
    until = None
    if "UNTIL" in p:
        udt = parse_ical_dt(p["UNTIL"])
        until = udt.date()
        if not is_event and udt.time() < start.time(): until -= datetime.timedelta(days=1)
    elif "COUNT" in p:
        count = max(int(p["COUNT"]), 1)
        cur = start.date()
        for _ in range(count-1):
            cur = add_period(cur, code, interval)
        until = cur
    else:
        until = datetime.date(2038,1,1)
    suffix = ""
    if "BYDAY" in p and code in ("M","Y"):
        by = p["BYDAY"].split(",")[0]
        m = re.match(r"(-?\d+)?([A-Z]{2})", by)
        if m:
            n = int(m.group(1) or "1"); wd = ["MO","TU","WE","TH","FR","SA","SU"].index(m.group(2))+1
            suffix += f" w{wd}{n}"
    if "BYMONTH" in p: suffix += " m" + p["BYMONTH"].split(",")[0]
    return {"interval":interval, "code":code, "until":until, "suffix":suffix, "ex": []}

def add_period(d, code, n):
    if code=="D": return d + datetime.timedelta(days=n)
    if code=="W": return d + datetime.timedelta(days=7*n)
    m = d.month - 1 + n
    y = d.year + m//12
    mo = m%12 + 1
    day = min(d.day, calendar.monthrange(y,mo)[1])
    return datetime.date(y,mo,day)

def recur_text(r):
    if not r: return ""
    s = f" {{{r['interval']}{r['code']} -> {fmt_store_date(r['until'])}{r.get('suffix','')}"
    for e in r.get("ex",[]): s += " !" + fmt_store_date(e)
    return s + "}"

def item_raw(it):
    if it.raw: return it.raw
    n = (">"+it.note+" ") if it.note else ""
    if it.typ == "todo":
        pre = f"[{it.prio}]" if it.prio >= 0 else "[-0]"
        return f"{pre}{n if n else ' '}{it.summary}"
    if it.typ == "event":
        dur = max(((it.end.date() - it.start.date()).days if it.end else 1), 1)
        durtxt = f" {{{dur-1}D -> {fmt_store_date(it.end.date()-datetime.timedelta(days=1))}}}" if dur > 1 and not it.recur else recur_text(it.recur)
        return f"{fmt_store_date(it.start.date())} [1]{durtxt} {n}{it.summary}"
    nt = (">"+it.note+" ") if it.note else ""
    sep = "" if not it.recur and not nt else " "
    return f"{fmt_store_date(it.start.date())} @ {it.start:%H:%M} -> {fmt_store_date(it.end.date())} @ {it.end:%H:%M}{recur_text(it.recur)}{sep}{nt}|{it.summary}"

def parse_store_line(line, todo=False):
    line=line.rstrip("\n")
    if todo:
        m=re.match(r"\[(-?\d+)\](?:>([0-9a-f]{40}) )? ?(.*)", line)
        if m: return Item("todo", m.group(3), prio=int(m.group(1)), note=m.group(2), raw=line)
        return None
    m=re.match(r"(\d\d/\d\d/\d{4}) @ (\d\d:\d\d) -> (\d\d/\d\d/\d{4}) @ (\d\d:\d\d)(?: \{([^}]*)\})?(?:>([0-9a-f]{40}) )? ?\|(.*)", line)
    if m:
        sd,st,ed,et,rr,note,summ=m.groups()
        start=datetime.datetime.strptime(sd+" "+st,"%m/%d/%Y %H:%M")
        end=datetime.datetime.strptime(ed+" "+et,"%m/%d/%Y %H:%M")
        return Item("apt", summ, start, end, note=note, raw=line)
    m=re.match(r"(\d\d/\d\d/\d{4}) \[(\d+)\](?: \{([^}]*)\})? (?:>([0-9a-f]{40}) )?(.*)", line)
    if m:
        sd, days, rr, note, summ=m.groups()
        start=datetime.datetime.combine(datetime.datetime.strptime(sd,"%m/%d/%Y").date(), datetime.time())
        end=start+datetime.timedelta(days=int(days))
        if rr:
            mm=re.search(r"-> (\d\d/\d\d/\d{4})", rr)
            if mm: end=datetime.datetime.combine(datetime.datetime.strptime(mm.group(1),"%m/%d/%Y").date()+datetime.timedelta(days=1), datetime.time())
        return Item("event", summ, start, end, note=note, raw=line)
    return None

def load_data(datadir, calfile=None):
    items=[]
    apts = Path(calfile) if calfile else Path(datadir)/"apts"
    todo = Path(datadir)/"todo"
    if apts.exists():
        for ln in apts.read_text(errors="ignore").splitlines():
            it=parse_store_line(ln, False)
            if it: items.append(it)
    if todo.exists():
        for ln in todo.read_text(errors="ignore").splitlines():
            it=parse_store_line(ln, True)
            if it: items.append(it)
    return items

def save_data(items, datadir, calfile=None):
    Path(datadir).mkdir(parents=True, exist_ok=True)
    (Path(datadir)/"notes").mkdir(exist_ok=True)
    cals=[x for x in items if x.typ!="todo"]
    todos=[x for x in items if x.typ=="todo"]
    cals.sort(key=lambda x:(x.start.date(), x.typ!="event", 0 if x.typ=="event" and (x.end.date()-x.start.date()).days>1 else 1, x.start.time(), x.summary))
    (Path(calfile) if calfile else Path(datadir)/"apts").write_text("\n".join(item_raw(x) for x in cals)+("\n" if cals else ""))
    (Path(datadir)/"todo").write_text("\n".join(item_raw(x) for x in todos)+("\n" if todos else ""))

def parse_ical_file(path, datadir):
    raw=Path(path).read_text(errors="ignore")
    lines=unfold(raw)
    objs=[]; cur=None; startline=0
    for idx,ln in enumerate(lines,1):
        u=ln.upper()
        if u in ("BEGIN:VEVENT","BEGIN:VTODO"):
            cur={"kind":u.split(":")[1],"lines":[],"startline":idx}
        elif u in ("END:VEVENT","END:VTODO") and cur:
            objs.append(cur); cur=None
        elif cur is not None:
            cur["lines"].append(ln)
    items=[]; skipped=0
    notesdir=Path(datadir)/"notes"; notesdir.mkdir(parents=True, exist_ok=True)
    for ob in objs:
        props={}
        bad=False
        for ln in ob["lines"]:
            if ":" not in ln: bad=True; continue
            props.setdefault(prop_name(ln), []).append(ln)
        try:
            summary=unesc(prop_val(props.get("SUMMARY",["SUMMARY:"])[0]))
            desc=unesc(prop_val(props["DESCRIPTION"][0])) if "DESCRIPTION" in props else None
            loc=unesc(prop_val(props["LOCATION"][0])) if "LOCATION" in props else None
            comment=unesc(prop_val(props["COMMENT"][0])) if "COMMENT" in props else None
            note=make_note(desc, loc, comment)
            noteid=None
            if note is not None:
                noteid=note_hash(note); (notesdir/noteid).write_text(note)
            if ob["kind"]=="VTODO":
                pr=int(prop_val(props.get("PRIORITY",["PRIORITY:0"])[0]) or "0")
                if pr < 0 or pr > 9: raise ValueError
                items.append(Item("todo", summary, prio=pr, note=noteid))
            else:
                ds=props.get("DTSTART")
                if not ds: raise ValueError
                dl=ds[0]; dateonly=("VALUE=DATE" in dl.upper())
                start=parse_ical_dt(prop_val(dl), dateonly)
                if "DURATION" in props: end=start+parse_duration(prop_val(props["DURATION"][0]))
                elif "DTEND" in props:
                    el=props["DTEND"][0]; end=parse_ical_dt(prop_val(el), "VALUE=DATE" in el.upper())
                else: end=start+(datetime.timedelta(days=1) if dateonly else datetime.timedelta())
                typ="event" if dateonly else "apt"
                recur=parse_rrule(prop_val(props["RRULE"][0]), start, typ=="event", end) if "RRULE" in props else None
                if recur and "EXDATE" in props:
                    for exl in props["EXDATE"]:
                        for v in prop_val(exl).split(","):
                            try: recur["ex"].append(parse_ical_dt(v, dateonly).date())
                            except Exception: pass
                if typ=="event" and (end.date()-start.date()).days>1:
                    note = make_note(desc, loc, comment, "multi-day event changed to one-day event")
                    noteid=note_hash(note); (notesdir/noteid).write_text(note)
                items.append(Item(typ, summary, start, end, note=noteid, recur=recur))
        except Exception:
            skipped += 1
    return items, skipped, len(lines)

def import_file(path, datadir, calfile, dump=False, quiet=False):
    old=load_data(datadir, calfile)
    new, skipped, nlines=parse_ical_file(path, datadir)
    allitems=old+new
    save_data(allitems, datadir, calfile)
    if dump:
        for it in new: print(item_raw(it))
    if not quiet:
        apps=sum(1 for x in new if x.typ=="apt"); ev=sum(1 for x in new if x.typ=="event"); td=sum(1 for x in new if x.typ=="todo")
        print(f"Import process report: {nlines:04d} lines read")
        print(f"{apps} app{'s' if apps!=1 else ''} / {ev} event{'s' if ev!=1 else ''} / {td} todo{'s' if td!=1 else ''} / {skipped} skipped")

def iter_occurrences(it, startd, endd):
    if it.typ=="todo": return
    if not it.recur:
        d=it.start.date()
        while d <= it.end.date() if it.typ=="apt" else d < it.end.date():
            if startd <= d <= endd: yield d, it, it.start, it.end
            d += datetime.timedelta(days=1)
        return
    d=it.start.date()
    ex=set(it.recur.get("ex",[]))
    while d <= it.recur["until"] and d <= endd:
        if d not in ex and d >= startd:
            delta=d-it.start.date()
            yield d, it, it.start+delta, it.end+delta
        d=add_period(d, it.recur["code"], it.recur["interval"])

def query(items, startd, endd, include_todo=True, include_cal=True, pattern=None, limit=None):
    if include_todo:
        todos=[x for x in items if x.typ=="todo" and (not pattern or re.search(pattern,x.summary))]
        if todos:
            print("to do:")
            for t in todos[:limit or None]: print(f"{abs(t.prio)}. {t.summary}")
            print()
    if not include_cal: return
    count=0
    d=startd
    while d<=endd:
        occ=[o for o in (iter_occurrences(x,d,d) for x in items if x.typ!="todo") for o in o]
        occ=[o for o in occ if not pattern or re.search(pattern,o[1].summary)]
        if occ:
            print(f"{fmt_date(d)}:")
            for _,it,st,en in sorted(occ, key=lambda o:(o[2].time(), o[1].typ!="event", o[1].summary)):
                if it.typ=="event":
                    print(f" * {it.summary}")
                else:
                    ss = st.strftime("%H:%M") if st.date()==d else "..:.."
                    ee = en.strftime("%H:%M") if en.date()==d else "..:.."
                    print(f" - {ss} -> {ee}\n\t{it.summary}")
                count+=1
                if limit and count>=limit: return
            if d != endd: print()
        d += datetime.timedelta(days=1)

def export_ical(items):
    print("BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//calcurse//NONSGML v4.8.2//EN")
    for it in [x for x in items if x.typ!="todo"]:
        print("BEGIN:VEVENT")
        if it.typ=="event":
            print(f"DTSTART;VALUE=DATE:{fmt_ical_date(it.start.date())}")
            if (it.end.date()-it.start.date()).days>1 and not it.recur:
                print(f"RRULE:FREQ=DAILY;UNTIL={fmt_ical_date(it.end.date()-datetime.timedelta(days=1))}")
        else:
            print(f"DTSTART:{fmt_ical_dt(it.start)}")
            dur=it.end-it.start
            days=dur.days; sec=dur.seconds; h=sec//3600; m=(sec%3600)//60; s=sec%60
            print(f"DURATION:P{days}DT{h}H{m}M{s}S" if days else f"DURATION:PT{h}H{m}M{s}S")
        print(f"SUMMARY:{esc(it.summary)}")
        print("END:VEVENT")
    for it in [x for x in items if x.typ=="todo"]:
        print("BEGIN:VTODO")
        if it.prio>0: print(f"PRIORITY:{it.prio}")
        print(f"SUMMARY:{esc(it.summary)}")
        print("END:VTODO")
    print("END:VCALENDAR")

def export_pcal(items):
    print("# calcurse pcal export\n\n# =======\n# options\n# =======\nopt -A -K -l -m -F Monday")
    print("# Display week number (i.e. 1-52) on every Monday\nall monday in all week %w\n")
    print("\n# =============\n# Recur. Events\n# =============\n# (pcal does not support from..until dates specification\n")
    print("# ======\n# Events\n# ======\n")
    for it in items:
        if it.typ=="event": print(f"{it.start:%b} {it.start.day}\t{it.summary}")
    print("\n# =============\n# Appointments\n# =============\n")
    for it in items:
        if it.typ=="apt": print(f"{it.start:%b} {it.start.day}\t{it.start:%H:%M} {it.summary}")

def render_fmt(fmt, it, st=None, en=None):
    st = st or it.start
    en = en or it.end
    def repl(m):
        tok=m.group(1)
        if tok=="m": return it.summary
        if tok=="p": return str(abs(it.prio))
        if tok=="S": return st.strftime("%H:%M")
        if tok=="E": return en.strftime("%H:%M")
        if tok=="s": return str(int(st.timestamp()))
        if tok=="e": return str(int(en.timestamp()))
        if tok=="d": return str(int((en-st).total_seconds()))
        if tok=="n": return it.note or ""
        if tok=="N": return ""
        return "%" + tok
    fmt=fmt.replace("\\n","\n").replace("\\t","\t")
    fmt=fmt.replace("%(raw)", item_raw(it)).replace("%(hash)", hashlib.sha1((item_raw(it)+"\n").encode()).hexdigest())
    return re.sub(r"%([mdpSEsendN])", repl, fmt)

def main(argv):
    datadir=str(default_dir()); confdir=None; calfile=None
    op=None; import_path=None; export_fmt="ical"; dump=False; quiet=False
    inputfmt=1; fromd=None; tod=None; days=None; todo_prio=None; pattern=None; limit=None
    formats={}; filter_types=None
    i=0
    while i < len(argv):
        a=argv[i]
        def need():
            nonlocal i
            i+=1
            if i>=len(argv): die(f"{a}: option requires an argument")
            return argv[i]
        if a in ("-h","--help"): print(HELP); return
        elif a in ("-v","--version"): print(f"calcurse {VERSION} -- text-based organizer\n\nCopyright (c) 2004-2023 calcurse Development Team.\nThis is free software; see the source for copying conditions."); return
        elif a=="--status": print("calcurse is not running"); return
        elif a in ("-D","--datadir"): datadir=need()
        elif a in ("-C","--confdir"): confdir=need()
        elif a in ("-c","--calendar"): calfile=need()
        elif a in ("-i","--import"): op="import"; import_path=need()
        elif a=="--dump-imported": dump=True
        elif a in ("-q","--quiet"): quiet=True
        elif a in ("-Q","--query"): op="query"
        elif a in ("-G","--grep"): op="grep"
        elif a in ("-P","--purge","-g","--gc"): op=a
        elif a in ("-a","--appointment"): op="query"; fromd=datetime.date.today(); tod=fromd; todo_prio="none"
        elif a in ("-d","--day"):
            op="query"; v=need(); todo_prio="none"
            if re.fullmatch(r"-?\d+", v): days=int(v)
            else: fromd=parse_date(v,inputfmt); tod=fromd
        elif a.startswith("-r") and a!="-read-only":
            op="query"; todo_prio="none"; days=int(a[2:] or "1")
        elif a.startswith("-s"):
            op="query"; todo_prio="none"; fromd=parse_date(a[2:] or (argv[i+1] if i+1<len(argv) and not argv[i+1].startswith("-") else "today"),inputfmt)
            if not a[2:] and i+1<len(argv) and not argv[i+1].startswith("-"): i+=1
        elif a in ("-n","--next"):
            op="next"
        elif a in ("--todo",):
            op="todo"; todo_prio = need() if i+1<len(argv) and not argv[i+1].startswith("-") else None
        elif a.startswith("-t") and a not in ("--to",):
            op="todo"; todo_prio=a[2:] if a[2:] else None
        elif a in ("--from",): fromd=parse_date(need(),inputfmt)
        elif a in ("--to",): tod=parse_date(need(),inputfmt)
        elif a=="--days": days=int(need())
        elif a=="--input-datefmt": inputfmt=int(need())
        elif a=="--output-datefmt": need()
        elif a in ("-S","--search","--filter-pattern"): pattern=need()
        elif a in ("-l","--limit"): limit=int(need())
        elif a.startswith("-x") and a!="-x":
            op="export"; export_fmt=a[2:] or "ical"
        elif a=="-x" or a=="--export":
            op="export"
        elif a.startswith("--export="):
            op="export"; export_fmt=a.split("=",1)[1] or "ical"
        elif a.startswith("--filter-type"):
            val = a.split("=",1)[1] if "=" in a else need()
            mp={"cal":["event","apt"],"recur":["event","apt"],"event":["event"],"apt":["apt"],"todo":["todo"],"recur-event":["event"],"recur-apt":["apt"]}
            filter_types=set()
            for part in val.split(","): filter_types.update(mp.get(part,[part]))
        elif a.startswith("--format-"):
            key = a.split("=",1)[0][9:].replace("-","_")
            val = a.split("=",1)[1] if "=" in a else need()
            formats[key]=val
        elif a.startswith("--filter-"):
            if "=" not in a and i+1<len(argv) and not argv[i+1].startswith("-"): i+=1
        elif a=="--daemon":
            return
        else:
            if op=="export" and a in ("ical","pcal"): export_fmt=a
            else:
                print(f"{sys.argv[0]}: unrecognized option '{a}'", file=sys.stderr); print(HELP, file=sys.stderr); sys.exit(1)
        i+=1
    if calfile and not os.path.isabs(calfile): calfile=os.path.abspath(calfile)
    if op=="import": import_file(import_path, datadir, calfile, dump, quiet); return
    items=load_data(datadir, calfile)
    if filter_types is not None:
        items=[x for x in items if x.typ in filter_types]
    if op=="grep":
        for it in items:
            if pattern and not re.search(pattern,it.summary): continue
            key = "todo" if it.typ=="todo" else ("event" if it.typ=="event" else "apt")
            fmt = formats.get(key, "%(raw)")
            print(render_fmt(fmt,it), end="" if fmt.endswith("\\n") or fmt.endswith("\n") else "\n")
        return
    if op in ("-P","--purge","-g","--gc"):
        save_data(items, datadir, calfile); return
    if op=="export":
        if export_fmt not in ("ical","pcal"): die(f"args.c: 631: invalid export format: {export_fmt}")
        export_pcal(items) if export_fmt=="pcal" else export_ical(items); return
    if op=="todo":
        todos=[x for x in items if x.typ=="todo"]
        if todo_prio not in (None,""):
            p=int(todo_prio)
            if p<0 or p>9: die(f"args.c: 612: invalid priority: {p}")
            todos=[x for x in todos if abs(x.prio)==p]
        if todos:
            print("to do:")
            for t in todos: print(f"{abs(t.prio)}. {t.summary}")
        return
    if op=="next":
        now=datetime.datetime.now()
        future=[x for x in items if x.typ=="apt" and now <= x.start <= now+datetime.timedelta(days=1)]
        if future:
            x=sorted(future,key=lambda z:z.start)[0]
            rem=x.start-now; mins=int(rem.total_seconds()//60)
            print(f"next appointment:\n   [{mins//60:02d}:{mins%60:02d}] {x.start:%m/%d/%y @ %H:%M} -> {x.end:%m/%d/%y @ %H:%M} |{x.summary}")
        return
    if op=="query":
        if fromd is None: fromd=datetime.date.today()
        if days is not None:
            if days>=0: tod=fromd+datetime.timedelta(days=max(days-1,0))
            else: tod=fromd; fromd=fromd+datetime.timedelta(days=days+1)
        if tod is None: tod=fromd
        query(items, fromd, tod, include_todo=(todo_prio!="none"), include_cal=True, pattern=pattern, limit=limit); return
    print(HELP)

if __name__ == "__main__":
    main(sys.argv[1:])
