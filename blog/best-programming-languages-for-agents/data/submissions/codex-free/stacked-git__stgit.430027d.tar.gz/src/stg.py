#!/usr/bin/env python3
import json
import os
import re
import subprocess
import sys

VERSION = """Stacked Git 2.5.5
Copyright (C) 2005-2025 StGit authors
This is free software: you are free to change and redistribute it.
There is NO WARRANTY, to the extent permitted by law.
SPDX-License-Identifier: GPL-2.0-only"""

COMMANDS = [
    ("Patch inspection commands", ["diff   Show a diff", "files  Show files modified by a patch",
     "id     Print git hash of a StGit revision", "log    Display or optionally clear the stack changelog",
     "name   Print patch name of a StGit revision", "show   Show patch commits"]),
    ("Patch manipulation commands", ["edit     Edit a patch", "fold     Fold diff file into the current patch",
     "new      Create a new patch at top of the stack", "refresh  Incorporate worktree changes into current patch",
     "rename   Rename a patch", "spill    Spill changes from the topmost patch",
     "sync     Synchronize patches with a branch or a series"]),
    ("Stack inspection commands", ["email    Format and send patches as email", "export   Export patches to a directory",
     "next     Print the name of the next patch", "patches  Show patches that modify files",
     "prev     Print the name of the previous patch", "series   Display the patch series",
     "top      Print the name of the top patch"]),
    ("Stack manipulation commands", ["branch    Branch operations: switch, list, create, rename, delete, ...",
     "clean     Delete empty patches from the series", "commit    Finalize patches to the stack base",
     "delete    Delete patches", "float     Push patches to the top, even if applied",
     "goto      Go to patch by pushing or popping as necessary", "hide      Hide patches in the series",
     "import    Import patches to stack", "init      Initialize a StGit stack on a branch",
     "pick      Import a patch from another branch or a commit object", "pop       Pop (unapply) one or more applied patches",
     "pull      Pull changes from a remote repository", "push      Push (apply) one or more unapplied patches",
     "rebase    Move the stack base to another point in history", "redo      Undo the last undo operation",
     "repair    Repair stack after branch is modified with git commands",
     "reset     Reset the patch stack to an earlier state", "sink      Move patches deeper in the stack",
     "squash    Squash two or more patches into one", "uncommit  Convert regular Git commits into StGit patches",
     "undo      Undo the last command", "unhide    Unhide hidden patches"]),
    ("Administration commands", ["completion  Support for shell completions", "version     Print version information and exit"]),
]


class Error(Exception):
    pass


def run(cmd, check=True, capture=True, env=None):
    p = subprocess.run(cmd, text=True, stdout=subprocess.PIPE if capture else None,
                       stderr=subprocess.PIPE if capture else None, env=env)
    if check and p.returncode != 0:
        if capture and p.stderr:
            sys.stderr.write(p.stderr)
        raise SystemExit(p.returncode)
    return p


def git(args, check=True):
    return run(["git"] + args, check=check)


def git_out(args, check=True):
    return git(args, check).stdout.rstrip("\n")


def die(msg, code=2):
    sys.stderr.write(f"error: {msg}\n")
    raise SystemExit(code)


def git_dir():
    p = git(["rev-parse", "--git-dir"], check=False)
    if p.returncode != 0:
        die("not a git repository")
    gd = p.stdout.strip()
    if not os.path.isabs(gd):
        gd = os.path.abspath(gd)
    return gd


def branch():
    b = git_out(["branch", "--show-current"], check=False)
    return b or "HEAD"


def state_path():
    return os.path.join(git_dir(), "stgit-lite.json")


def load_all():
    path = state_path()
    if os.path.exists(path):
        with open(path) as f:
            return json.load(f)
    return {"branches": {}}


def save_all(data):
    path = state_path()
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    os.replace(tmp, path)


def get_state(create=False, br=None):
    data = load_all()
    br = br or branch()
    if br not in data["branches"]:
        if not create:
            return data, br, None
        head = git_out(["rev-parse", "HEAD"])
        data["branches"][br] = {"base": head, "series": []}
        save_all(data)
    return data, br, data["branches"][br]


def init_stack():
    data, br, st = get_state(create=True)
    return data, br, st


def applied(st):
    return [p for p in st["series"] if p.get("status") == "applied"]


def unapplied(st):
    return [p for p in st["series"] if p.get("status") == "unapplied"]


def visible_series(st, all_patches=False):
    if all_patches:
        return st["series"]
    return [p for p in st["series"] if p.get("status") != "hidden"]


def find_patch(st, name):
    if name in ("@","top"):
        aps = applied(st)
        if not aps:
            die("no patches applied")
        return aps[-1]
    if name == "{base}":
        return {"name": "{base}", "commit": st["base"], "status": "base"}
    if name.endswith("^"):
        p = find_patch(st, name[:-1])
        return {"name": name, "commit": git_out(["rev-parse", p["commit"] + "^"])}
    for p in st["series"]:
        if p["name"] == name:
            return p
    die(f"unknown patch `{name}`")


def slug(s):
    s = s.strip().splitlines()[0] if s.strip() else "patch"
    s = re.sub(r"[^A-Za-z0-9._-]+", "-", s).strip("-").lower()
    return s or "patch"


def unique_name(st, base):
    names = {p["name"] for p in st["series"]}
    if base not in names:
        return base
    i = 2
    while f"{base}-{i}" in names:
        i += 1
    return f"{base}-{i}"


def parse_common(argv):
    out = []
    i = 0
    color = None
    while i < len(argv):
        if argv[i] == "--color":
            i += 2
        elif argv[i].startswith("--color="):
            i += 1
        else:
            out.append(argv[i]); i += 1
    return out, color


def top_help():
    print("Maintain a stack of patches on top of a Git branch.\n")
    print("Usage: stg [OPTIONS] <command> [...]")
    print("       stg [OPTIONS] <-h|--help>")
    print("       stg --version\n")
    for title, rows in COMMANDS:
        print(title + ":")
        for r in rows:
            print("  " + r)
        print()
    print("Aliases:")
    print('  add       Alias for shell command `git -C "$GIT_PREFIX" add`')
    print('  mv        Alias for shell command `git -C "$GIT_PREFIX" mv`')
    print('  resolved  Alias for shell command `git -C "$GIT_PREFIX" add`')
    print('  rm        Alias for shell command `git -C "$GIT_PREFIX" rm`')
    print("  status    Alias for shell command `git status -s`\n")
    print("Help:\n  help  Print this message or the help of the given subcommand(s)\n")
    print("Options:\n      --version\n          Print version information\n")
    print("  -C <path>\n          Run as if stg was started in '<path>' instead of the current working\n          directory.\n")
    print("  -h, --help\n          Print help (see a summary with '-h')")


def command_help(cmd):
    summaries = {
        "init": ("Initialize a StGit stack on a branch.", "Usage: stg init [OPTIONS]"),
        "new": ("Create a new, empty patch on the current stack.", "Usage: stg new [OPTIONS] [patchname] [-- <path>...]"),
        "refresh": ("Include the latest work tree and index changes in the current patch.", "Usage: stg refresh [OPTIONS] [path]..."),
        "series": ("Show all the patches in the series.", "Usage: stg series [OPTIONS] [-A] [-U] [-H]"),
        "top": ("Print the name of the top patch.", "Usage: stg top [OPTIONS]"),
        "pop": ("Pop (unapply) one or more applied patches.", "Usage: stg pop [OPTIONS] [patch]..."),
        "push": ("Push one or more unapplied patches from the series onto the stack.", "Usage: stg push [OPTIONS] [patch]..."),
        "delete": ("Delete patches", "Usage: stg delete [OPTIONS] [<patch>...]"),
        "rename": ("Rename a patch.", "Usage: stg rename [OPTIONS] <oldpatch> <newpatch>"),
        "files": ("Show the files modified by a patch.", "Usage: stg files [OPTIONS] [revision]"),
        "diff": ("Show the diff.", "Usage: stg diff [OPTIONS] [path]..."),
        "show": ("Show the commit log and diff corresponding to the given patches.", "Usage: stg show [OPTIONS] [patch-or-rev]..."),
        "id": ("Print the hash (object id) of a StGit revision.", "Usage: stg id [OPTIONS] [revision]"),
        "name": ("Print the patch name of a StGit revision.", "Usage: stg name [OPTIONS] [revision]"),
        "next": ("Print the name of the next patch.", "Usage: stg next [OPTIONS]"),
        "prev": ("Print the name of the previous patch.", "Usage: stg prev [OPTIONS]"),
        "branch": ("Create, clone, switch, rename, or delete StGit-enabled branches.", "Usage: stg branch [--list|-l] [branch]"),
        "commit": ("Finalize one or more patches into the base of the current stack.", "Usage: stg commit [OPTIONS] [patch]..."),
        "uncommit": ("Convert one or more Git commits from the base of the current stack into StGit patches.", "Usage: stg uncommit [OPTIONS] [patchname]..."),
        "clean": ("Delete the empty patches from the entire series.", "Usage: stg clean [OPTIONS]"),
        "hide": ("Hide patches in the series.", "Usage: stg hide [OPTIONS] <patch>..."),
        "unhide": ("Unhide hidden patches in the series.", "Usage: stg unhide [OPTIONS] <patch>..."),
        "version": ("Print version information and exit", "Usage: stg version [OPTIONS]"),
    }
    if cmd not in summaries:
        print(f"No help for `{cmd}`")
        return
    print(summaries[cmd][0] + "\n")
    print(summaries[cmd][1] + "\n")
    print("Options:")
    print("  -h, --help          Print help")


def cmd_version(argv):
    if "-s" in argv or "--short" in argv:
        print("2.5.5")
    else:
        print(VERSION)
        gv = git(["--version"], check=False)
        if gv.returncode == 0:
            print(gv.stdout.strip())


def cmd_series(argv):
    data, br, st = get_state()
    if st is None:
        return
    count = "-c" in argv or "--count" in argv
    allp = "-a" in argv or "--all" in argv
    only_a = "-A" in argv or "--applied" in argv
    only_u = "-U" in argv or "--unapplied" in argv
    only_h = "-H" in argv or "--hidden" in argv
    nop = "-P" in argv or "--no-prefix" in argv
    desc = "-d" in argv or "--description" in argv
    reverse = "-r" in argv or "--reverse" in argv
    patches = visible_series(st, allp or only_h)
    if only_a:
        patches = [p for p in patches if p["status"] == "applied"]
    if only_u:
        patches = [p for p in patches if p["status"] == "unapplied"]
    if only_h:
        patches = [p for p in patches if p["status"] == "hidden"]
    if reverse:
        patches = list(reversed(patches))
    if count:
        print(len(patches)); return
    aps = applied(st)
    top = aps[-1]["name"] if aps else None
    for p in patches:
        pref = {"applied": "+", "unapplied": "-", "hidden": "!"}.get(p["status"], " ")
        if p["name"] == top:
            pref = ">"
        line = p["name"] if nop else f"{pref} {p['name']}"
        if desc:
            subj = git_out(["show", "-s", "--format=%s", p["commit"]], check=False)
            line += "  " + subj
        print(line)


def commit_with_message(message, allow_empty=False):
    args = ["commit"]
    if allow_empty:
        args.append("--allow-empty")
    args += ["-m", message]
    git(args, check=True)
    return git_out(["rev-parse", "HEAD"])


def cmd_new(argv):
    data, br, st = init_stack()
    name = None; msg = None; refresh = False; index = False; paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-m","--message"):
            msg = argv[i+1]; i += 2
        elif a.startswith("--message="):
            msg = a.split("=",1)[1]; i += 1
        elif a in ("-n","--name"):
            name = argv[i+1]; i += 2
        elif a in ("-r","--refresh"):
            refresh = True; i += 1
        elif a in ("-i","--index"):
            index = True; i += 1
        elif a == "--":
            paths = argv[i+1:]; break
        elif a.startswith("-"):
            i += 1
        elif name is None:
            name = a; i += 1
        else:
            paths.append(a); i += 1
    msg = msg if msg is not None else (name or "patch")
    name = unique_name(st, name or slug(msg))
    if refresh or paths:
        if not index:
            git(["add"] + (paths if paths else ["-A"]))
        commit = commit_with_message(msg, allow_empty=True)
    else:
        commit = commit_with_message(msg, allow_empty=True)
    idx = len(applied(st))
    st["series"].insert(idx, {"name": name, "commit": commit, "status": "applied"})
    save_all(data)
    print(f"> {name} (new)")


def cmd_refresh(argv):
    data, br, st = get_state()
    if st is None or not applied(st):
        die("no patches applied")
    msg = None; index = False; paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-m","--message"):
            msg = argv[i+1]; i += 2
        elif a.startswith("--message="):
            msg = a.split("=",1)[1]; i += 1
        elif a in ("-i","--index"):
            index = True; i += 1
        elif a == "--":
            paths = argv[i+1:]; break
        elif a.startswith("-"):
            i += 1
        else:
            paths.append(a); i += 1
    if not index:
        git(["add"] + (paths if paths else ["-A"]))
    args = ["commit", "--amend", "--allow-empty"]
    if msg is None:
        args += ["--no-edit"]
    else:
        args += ["-m", msg]
    git(args)
    applied(st)[-1]["commit"] = git_out(["rev-parse", "HEAD"])
    save_all(data)


def cmd_top(argv):
    data, br, st = get_state()
    aps = applied(st) if st else []
    if not aps:
        die("no patches applied")
    print(aps[-1]["name"])


def cmd_next(argv):
    data, br, st = get_state()
    ups = unapplied(st) if st else []
    if not ups:
        die("no unapplied patches")
    print(ups[0]["name"])


def cmd_prev(argv):
    data, br, st = get_state()
    aps = applied(st) if st else []
    if len(aps) < 2:
        die("no previous patch")
    print(aps[-2]["name"])


def cmd_pop(argv):
    data, br, st = get_state()
    if st is None:
        die("stack is not initialized")
    n = 1
    if "-a" in argv or "--all" in argv:
        n = len(applied(st))
    if "-n" in argv:
        n = int(argv[argv.index("-n")+1])
    if "--number" in argv:
        n = int(argv[argv.index("--number")+1])
    if n < 0:
        n = max(0, len(applied(st)) + n)
    for _ in range(n):
        aps = applied(st)
        if not aps:
            die("no patches applied")
        p = aps[-1]
        parent = git_out(["rev-parse", p["commit"] + "^"])
        git(["reset", "--hard", parent])
        p["status"] = "unapplied"
        print(f"- {p['name']}")
    save_all(data)


def cmd_push(argv):
    data, br, st = get_state()
    if st is None:
        die("stack is not initialized")
    targets = [a for a in argv if not a.startswith("-")]
    if "-a" in argv or "--all" in argv:
        targets = [p["name"] for p in unapplied(st)]
    elif not targets:
        ups = unapplied(st)
        if not ups:
            die("no unapplied patches")
        targets = [ups[0]["name"]]
    for name in targets:
        p = find_patch(st, name)
        if p["status"] != "unapplied":
            continue
        res = git(["cherry-pick", p["commit"]], check=False)
        if res.returncode != 0:
            sys.stderr.write(res.stderr)
            raise SystemExit(res.returncode)
        p["commit"] = git_out(["rev-parse", "HEAD"])
        p["status"] = "applied"
        print(f"> {p['name']}")
    save_all(data)


def cmd_files(argv):
    data, br, st = get_state()
    if st is None:
        return
    stat = "-s" in argv or "--stat" in argv
    revs = [a for a in argv if not a.startswith("-")]
    rev = revs[0] if revs else "@"
    p = find_patch(st, rev)
    if stat:
        sys.stdout.write(git_out(["diff", "--stat", p["commit"] + "^", p["commit"]]) + "\n")
    else:
        out = git_out(["diff", "--name-status", p["commit"] + "^", p["commit"]], check=False)
        if out:
            print(out)


def cmd_diff(argv):
    args = ["diff"]
    paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-s","--stat"):
            args.append("--stat"); i += 1
        elif a in ("-O","--diff-opt"):
            args.append(argv[i+1]); i += 2
        elif a in ("-r","--range"):
            rng = argv[i+1]; i += 2
            if ".." in rng:
                a1, a2 = rng.split("..",1)
                args += [rev_to_commit(a1), rev_to_commit(a2)]
            else:
                c = rev_to_commit(rng)
                args += [c + "^", c]
        elif a == "--":
            paths = argv[i+1:]; break
        elif a.startswith("-"):
            i += 1
        else:
            paths.append(a); i += 1
    if paths:
        args += ["--"] + paths
    p = git(args, check=False)
    sys.stdout.write(p.stdout)
    sys.stderr.write(p.stderr)
    raise SystemExit(p.returncode)


def rev_to_commit(rev):
    data, br, st = get_state()
    if st:
        try:
            return find_patch(st, rev)["commit"]
        except SystemExit:
            pass
    return git_out(["rev-parse", rev])


def cmd_show(argv):
    data, br, st = get_state()
    stat = "-s" in argv or "--stat" in argv
    revs = [a for a in argv if not a.startswith("-")]
    if not revs:
        revs = ["@"] if st and applied(st) else ["HEAD"]
    args = ["show"]
    if stat:
        args.append("--stat")
    for r in revs:
        args.append(rev_to_commit(r) if st else r)
    p = git(args, check=False)
    sys.stdout.write(p.stdout); sys.stderr.write(p.stderr)
    raise SystemExit(p.returncode)


def cmd_id(argv):
    revs = [a for a in argv if not a.startswith("-")]
    print(rev_to_commit(revs[0] if revs else ("@" if get_state()[2] and applied(get_state()[2]) else "HEAD")))


def cmd_name(argv):
    data, br, st = get_state()
    if st is None:
        die("stack is not initialized")
    revs = [a for a in argv if not a.startswith("-")]
    if not revs:
        cmd_top(argv); return
    c = rev_to_commit(revs[0])
    for p in st["series"]:
        if p["commit"].startswith(c) or c.startswith(p["commit"]):
            print(p["name"]); return
    die(f"revision `{revs[0]}` does not match a patch")


def cmd_rename(argv):
    data, br, st = get_state()
    args = [a for a in argv if not a.startswith("-")]
    if len(args) == 1:
        old = applied(st)[-1]["name"] if applied(st) else None
        new = args[0]
    elif len(args) >= 2:
        old, new = args[0], args[1]
    else:
        die("missing patch name")
    p = find_patch(st, old)
    p["name"] = new
    save_all(data)


def cmd_delete(argv):
    data, br, st = get_state()
    args = [a for a in argv if not a.startswith("-")]
    if "-t" in argv or "--top" in argv:
        args = [applied(st)[-1]["name"]]
    if "-a" in argv or "--all" in argv:
        args = [p["name"] for p in list(st["series"])]
    if not args:
        die("no patches specified")
    for name in args:
        p = find_patch(st, name)
        if p["status"] == "applied" and applied(st) and applied(st)[-1]["name"] == p["name"]:
            git(["reset", "--hard", p["commit"] + "^"])
        st["series"] = [x for x in st["series"] if x["name"] != p["name"]]
        print(f"# {p['name']}")
    save_all(data)


def cmd_hide(argv, hidden):
    data, br, st = get_state()
    for name in [a for a in argv if not a.startswith("-")]:
        p = find_patch(st, name)
        p["status"] = "hidden" if hidden else "unapplied"
    save_all(data)


def cmd_branch(argv):
    if not argv:
        print(branch()); return
    if "-l" in argv or "--list" in argv:
        sys.stdout.write(git_out(["branch"]) + "\n"); return
    if "-c" in argv or "--create" in argv:
        idx = argv.index("-c") if "-c" in argv else argv.index("--create")
        git(["checkout", "-b", argv[idx+1]]); init_stack(); return
    args = [a for a in argv if not a.startswith("-")]
    if args:
        git(["checkout", args[0]], check=True)


def cmd_uncommit(argv):
    data, br, st = init_stack()
    n = 0; prefix = None; names = [a for a in argv if not a.startswith("-")]
    if "-n" in argv:
        n = int(argv[argv.index("-n")+1])
        prefix = names[0] if names else None
    elif "--number" in argv:
        n = int(argv[argv.index("--number")+1])
        prefix = names[0] if names else None
    else:
        n = len(names)
    if n <= 0:
        die("no commits specified")
    commits = git_out(["rev-list", f"--max-count={n}", "HEAD"]).splitlines()
    commits_oldest = list(reversed(commits))
    base = git_out(["rev-parse", commits_oldest[0] + "^"])
    st["base"] = base
    for idx, c in enumerate(commits_oldest):
        if names and "-n" not in argv and "--number" not in argv:
            nm = names[len(commits_oldest)-1-idx]
        elif prefix:
            nm = f"{prefix}{idx+1}"
        else:
            nm = unique_name(st, slug(git_out(["show", "-s", "--format=%s", c])))
        st["series"].insert(idx, {"name": nm, "commit": c, "status": "applied"})
        print(f"+ {nm}")
    save_all(data)


def cmd_commit(argv):
    data, br, st = get_state()
    n = 1
    if "-a" in argv or "--all" in argv:
        n = len(applied(st))
    if "-n" in argv:
        n = int(argv[argv.index("-n")+1])
    for _ in range(min(n, len(applied(st)))):
        p = applied(st)[0]
        st["base"] = p["commit"]
        st["series"].remove(p)
        print(f"# {p['name']}")
    save_all(data)


def cmd_clean(argv):
    data, br, st = get_state()
    if st is None:
        return
    keep = []
    for p in st["series"]:
        same = git(["diff", "--quiet", p["commit"] + "^", p["commit"]], check=False).returncode == 0
        if same:
            print(f"# {p['name']}")
        else:
            keep.append(p)
    st["series"] = keep
    save_all(data)


def cmd_goto(argv):
    data, br, st = get_state()
    args = [a for a in argv if not a.startswith("-")]
    if not args:
        die("missing patch")
    target = args[0]
    names = [p["name"] for p in st["series"]]
    if target not in names:
        die(f"unknown patch `{target}`")
    target_idx = names.index(target)
    while applied(st) and names.index(applied(st)[-1]["name"]) > target_idx:
        cmd_pop([])
        data, br, st = get_state()
    while not applied(st) or applied(st)[-1]["name"] != target:
        cmd_push([])
        data, br, st = get_state()


def cmd_pick(argv):
    data, br, st = init_stack()
    args = [a for a in argv if not a.startswith("-")]
    if not args:
        die("missing commit")
    commit = args[0]
    res = git(["cherry-pick", commit], check=False)
    if res.returncode != 0:
        sys.stderr.write(res.stderr)
        raise SystemExit(res.returncode)
    new_commit = git_out(["rev-parse", "HEAD"])
    name = unique_name(st, slug(git_out(["show", "-s", "--format=%s", new_commit])))
    st["series"].insert(len(applied(st)), {"name": name, "commit": new_commit, "status": "applied"})
    save_all(data)
    print(f"> {name}")


def cmd_export(argv):
    data, br, st = get_state()
    outdir = "patches"
    args = [a for a in argv if not a.startswith("-")]
    if args:
        outdir = args[0]
    os.makedirs(outdir, exist_ok=True)
    patches = applied(st) if st else []
    for i, p in enumerate(patches, 1):
        path = os.path.join(outdir, f"{i:04d}-{p['name']}.patch")
        fmt = git_out(["format-patch", "-1", "--stdout", p["commit"]])
        with open(path, "w") as f:
            f.write(fmt)
        print(path)


def cmd_log(argv):
    data, br, st = get_state()
    if st is None:
        return
    print(f"Stack on branch {br}")
    print(f"base {st['base']}")
    for p in st["series"]:
        print(f"{p['status'][0]} {p['name']} {p['commit']}")


def cmd_completion(argv):
    if not argv or argv[0] in ("list",):
        for _, rows in COMMANDS:
            for r in rows:
                print(r.split()[0])
        for a in ("add", "mv", "resolved", "rm", "status"):
            print(a)
    elif argv[0] in ("bash", "zsh", "fish"):
        print(f"# completion for stg ({argv[0]})")
    else:
        command_help("completion")


def cmd_edit(argv):
    data, br, st = get_state()
    patch = None; msg = None
    i = 0
    while i < len(argv):
        if argv[i] in ("-m", "--message"):
            msg = argv[i+1]; i += 2
        elif argv[i].startswith("--message="):
            msg = argv[i].split("=", 1)[1]; i += 1
        elif not argv[i].startswith("-"):
            patch = argv[i]; i += 1
        else:
            i += 1
    if st is None:
        die("stack is not initialized")
    p = find_patch(st, patch or "@")
    if msg is not None and p["status"] == "applied" and applied(st)[-1]["name"] == p["name"]:
        git(["commit", "--amend", "--allow-empty", "-m", msg])
        p["commit"] = git_out(["rev-parse", "HEAD"])
        save_all(data)


def cmd_patches(argv):
    data, br, st = get_state()
    if st is None:
        return
    paths = [a for a in argv if not a.startswith("-")]
    for p in st["series"]:
        changed = git_out(["diff", "--name-only", p["commit"] + "^", p["commit"]], check=False).splitlines()
        if not paths or any(x in changed for x in paths):
            print(p["name"])


def cmd_import(argv):
    data, br, st = init_stack()
    files = [a for a in argv if not a.startswith("-")]
    if not files:
        die("missing patch file")
    for fn in files:
        before = git_out(["rev-parse", "HEAD"])
        res = git(["am", fn], check=False)
        if res.returncode != 0:
            sys.stderr.write(res.stderr)
            raise SystemExit(res.returncode)
        c = git_out(["rev-parse", "HEAD"])
        if c != before:
            name = unique_name(st, slug(git_out(["show", "-s", "--format=%s", c])))
            st["series"].insert(len(applied(st)), {"name": name, "commit": c, "status": "applied"})
            print(f"> {name}")
    save_all(data)


def cmd_reorder(argv, to_top):
    data, br, st = get_state()
    if st is None:
        die("stack is not initialized")
    names = [a for a in argv if not a.startswith("-")]
    moving = [find_patch(st, n) for n in names]
    st["series"] = [p for p in st["series"] if p not in moving]
    if to_top:
        idx = len(applied(st))
        for p in moving:
            st["series"].insert(idx, p); idx += 1
    else:
        for p in reversed(moving):
            st["series"].insert(0, p)
    save_all(data)


def cmd_squash(argv):
    data, br, st = get_state()
    if st is None:
        die("stack is not initialized")
    names = [a for a in argv if not a.startswith("-")]
    if len(names) < 2:
        die("need at least two patches")
    msg = "squashed patch"
    selected = [find_patch(st, n) for n in names]
    if any(p["status"] != "applied" for p in selected):
        die("can only squash applied patches")
    top = applied(st)[-1]
    if selected[-1]["name"] != top["name"]:
        die("can only squash patches ending at top")
    base = git_out(["rev-parse", selected[0]["commit"] + "^"])
    git(["reset", "--soft", base])
    git(["commit", "--allow-empty", "-m", msg])
    newc = git_out(["rev-parse", "HEAD"])
    newname = unique_name(st, names[0] + "-squashed")
    st["series"] = [p for p in st["series"] if p not in selected]
    st["series"].insert(len(applied(st)), {"name": newname, "commit": newc, "status": "applied"})
    save_all(data)
    print(f"> {newname}")


def alias_git(cmd, argv):
    if cmd == "status":
        os.execvp("git", ["git", "status", "-s"] + argv)
    target = "add" if cmd == "resolved" else cmd
    os.execvp("git", ["git", target] + argv)


def main():
    argv = sys.argv[1:]
    while argv and argv[0] == "-C":
        os.chdir(argv[1]); argv = argv[2:]
    if not argv or argv[0] in ("-h","--help"):
        top_help(); return
    if argv[0] == "--version":
        cmd_version([]); return
    cmd = argv[0]; args = argv[1:]
    args, _ = parse_common(args)
    if cmd == "help":
        if args: command_help(args[0])
        else: top_help()
        return
    if "--help" in args or "-h" in args:
        command_help(cmd); return
    if cmd in ("status","add","rm","mv","resolved"):
        alias_git(cmd, args)
    table = {
        "version": cmd_version, "init": lambda a: init_stack() and None,
        "series": cmd_series, "new": cmd_new, "refresh": cmd_refresh,
        "top": cmd_top, "next": cmd_next, "prev": cmd_prev, "pop": cmd_pop,
        "push": cmd_push, "files": cmd_files, "diff": cmd_diff, "show": cmd_show,
        "id": cmd_id, "name": cmd_name, "rename": cmd_rename, "delete": cmd_delete,
        "hide": lambda a: cmd_hide(a, True), "unhide": lambda a: cmd_hide(a, False),
        "branch": cmd_branch, "uncommit": cmd_uncommit, "commit": cmd_commit,
        "clean": cmd_clean,
        "goto": cmd_goto, "pick": cmd_pick, "export": cmd_export,
        "log": cmd_log, "completion": cmd_completion,
        "repair": lambda a: None, "undo": lambda a: die("undo is not available", 1),
        "redo": lambda a: die("redo is not available", 1),
        "pull": lambda a: os.execvp("git", ["git", "pull"] + a),
        "rebase": lambda a: os.execvp("git", ["git", "rebase"] + a),
        "edit": cmd_edit, "patches": cmd_patches, "import": cmd_import,
        "float": lambda a: cmd_reorder(a, True), "sink": lambda a: cmd_reorder(a, False),
        "squash": cmd_squash, "email": lambda a: cmd_export(a),
    }
    if cmd in table:
        table[cmd](args); return
    die(f"unrecognized subcommand `{cmd}`")


if __name__ == "__main__":
    try:
        main()
    except Error as e:
        die(str(e))
