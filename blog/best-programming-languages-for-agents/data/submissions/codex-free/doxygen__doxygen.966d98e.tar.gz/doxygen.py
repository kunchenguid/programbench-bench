#!/usr/bin/env python3
import html, os, re, shutil, sys
from pathlib import Path

VERSION = "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)"
SHORT_VERSION = "1.17.0"
BASE = Path(__file__).resolve().parent
TEMPLATE_DIR = BASE / "templates"

HELP_TAIL = """Doxygen version {ver}
Copyright Dimitri van Heesch 1997-2025

You can use Doxygen in a number of ways:

1) Use Doxygen to generate a template configuration file*:
    {prog} [-s] -g [configName]

2) Use Doxygen to update an old configuration file*:
    {prog} [-s] -u [configName]

3) Use Doxygen to generate documentation using an existing configuration file*:
    {prog} [configName]

4) Use Doxygen to generate a template file controlling the layout of the
   generated documentation:
    {prog} -l [layoutFileName]

    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.
    If - is used for layoutFileName Doxygen will write to standard output.

5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.
    RTF:        {prog} -w rtf styleSheetFile
    HTML:       {prog} -w html headerFile footerFile styleSheetFile [configFile]
    LaTeX:      {prog} -w latex headerFile footerFile styleSheetFile [configFile]

6) Use Doxygen to generate a rtf extensions file
    {prog} -e rtf extensionsFile

    If - is used for extensionsFile Doxygen will write to standard output.

7) Use Doxygen to compare the used configuration file with the template configuration file
    {prog} -x [configFile]

   Use Doxygen to compare the used configuration file with the template configuration file
   without replacing the environment variables or CMake type replacement variables
    {prog} -x_noenv [configFile]

8) Use Doxygen to show a list of built-in emojis.
    {prog} -f emoji outputFileName

    If - is used for outputFileName Doxygen will write to standard output.

*) If -s is specified the comments of the configuration items in the config file will be omitted.
   If configName is omitted 'Doxyfile' will be used as a default.
   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.

If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.

-v print version string, -V print extended version information
-h,-? prints usage help information
{prog} -d prints additional usage flags for debugging purposes
"""

DEV = """Developer parameters:
  -m          dump symbol map
  -b          making messages output unbuffered
  -c <file>   process input file as a comment block and produce HTML output
  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):
	alias
	cite
	commentcnv
	commentscan
	entries
	extcmd
	filteroutput
	formula
	fortranfixed2free
	layout
	lex
	lex:code
	lex:commentcnv
	lex:commentscan
	lex:configimpl
	lex:constexp
	lex:declinfo
	lex:defargs
	lex:doctokenizer
	lex:fortrancode
	lex:fortranscanner
	lex:lexcode
	lex:lexscanner
	lex:pre
	lex:pycode
	lex:pyscanner
	lex:scanner
	lex:sqlcode
	lex:vhdlcode
	lex:xml
	lex:xmlcode
	markdown
	nolineno
	plantuml
	preprocessor
	printtree
	qhp
	rtf
	sections
	stderr
	tag
	time
"""

def t(name):
    return (TEMPLATE_DIR / name).read_text(errors="replace")

def write_target(name, text):
    if name == "-":
        sys.stdout.write(text)
    else:
        Path(name).write_text(text)

def usage(prog):
    return HELP_TAIL.format(ver=VERSION, prog=prog)

def parse_config(path):
    cfg = {}
    try:
        lines = Path(path).read_text(errors="replace").splitlines()
    except FileNotFoundError:
        raise
    cur = None
    for raw in lines:
        line = raw.split('#',1)[0].rstrip()
        if not line.strip():
            continue
        if line.endswith('\\'):
            line = line[:-1].rstrip()
        m = re.match(r'\s*([A-Za-z0-9_]+)\s*(\+?=)\s*(.*)', line)
        if m:
            k, op, v = m.groups(); v = v.strip().strip('"')
            if op == '+=' and k in cfg and v:
                cfg[k] += ' ' + v
            else:
                cfg[k] = v
    return cfg

def split_words(v):
    return re.findall(r'"([^"]*)"|(\S+)', v or '')

def word_list(v):
    out=[]
    for a,b in split_words(v): out.append(a or b)
    return out

def find_inputs(cfg):
    vals = word_list(cfg.get('INPUT','')) or ['.']
    recursive = cfg.get('RECURSIVE','NO').upper() == 'YES'
    pats = word_list(cfg.get('FILE_PATTERNS','')) or ['*.c','*.cc','*.cpp','*.cxx','*.h','*.hh','*.hpp','*.hxx','*.py','*.java','*.md']
    files=[]
    for val in vals:
        p=Path(val)
        if p.is_dir():
            it = p.rglob('*') if recursive else p.glob('*')
            for f in it:
                if f.is_file() and any(f.match(pat) for pat in pats): files.append(f)
        elif p.is_file():
            files.append(p)
    return sorted(dict.fromkeys(files), key=lambda x: str(x))

def extract_symbols(files):
    classes=[]; funcs=[]; docs=[]
    pending=''
    for f in files:
        try: lines=f.read_text(errors='replace').splitlines()
        except Exception: continue
        for line in lines:
            s=line.strip()
            dm=re.search(r'/\*\*(.*?)\*/', s)
            if dm:
                pending=dm.group(1).strip(' *')
                docs.append(pending)
            cm=re.match(r'(?:template\s*<[^>]+>\s*)?(class|struct)\s+([A-Za-z_][\w:]*)', s)
            if cm:
                classes.append((cm.group(2).split('::')[-1], str(f), pending)); pending=''
            fm=re.match(r'(?:[A-Za-z_][\w:<>&*~\s]+\s+)+([A-Za-z_][\w:]*)\s*\([^;{}]*\)\s*(?:const\s*)?[;{]', s)
            if fm and not s.startswith(('if','for','while','switch')):
                funcs.append((fm.group(1).split('::')[-1], str(f), pending)); pending=''
    return classes, funcs, docs

def page(title, project, body):
    return f'''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "https://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US">
<head>
<meta http-equiv="Content-Type" content="text/xhtml;charset=UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=11"/>
<meta name="generator" content="Doxygen {SHORT_VERSION}"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{html.escape(project)}: {html.escape(title)}</title>
<link href="doxygen.css" rel="stylesheet" type="text/css" />
</head><body><div id="top"><div id="titlearea"><div id="projectname">{html.escape(project)}</div></div></div>
<div class="contents">{body}</div>
<hr class="footer"/><address class="footer"><small>Generated by Doxygen {SHORT_VERSION}</small></address>
</body></html>
'''

def run_docs(config, quiet_flag=False):
    cfg = parse_config(config)
    quiet = quiet_flag or cfg.get('QUIET','NO').upper() == 'YES'
    project = cfg.get('PROJECT_NAME','My Project').strip('"') or 'My Project'
    outdir = Path(cfg.get('OUTPUT_DIRECTORY','').strip() or '.')
    html_dir = outdir / 'html'
    if not quiet:
        print(f'Doxygen version used: {VERSION}')
        if not outdir.exists(): print(f"Notice: Output directory '{outdir}' does not exist. I have created it for you.")
        for m in ['Searching for include files...','Searching INPUT for files to process...','Parsing files']:
            print(m)
    html_dir.mkdir(parents=True, exist_ok=True)
    files = find_inputs(cfg)
    classes, funcs, docs = extract_symbols(files)
    if not quiet:
        for f in files:
            print(f'Parsing file {f.resolve()}...')
        for m in ['Building class list...','Building file list...','Generating style sheet...','Generating file documentation...','Generating class documentation...','Generating index page...','finished...']:
            print(m)
    shutil.copyfile(TEMPLATE_DIR/'doxygen.css', html_dir/'doxygen.css')
    (html_dir/'tabs.css').write_text('/* tabs */\n')
    (html_dir/'dynsections.js').write_text('// generated\n')
    body = '<h1>Main Page</h1>\n'
    if docs: body += ''.join(f'<p>{html.escape(d)}</p>\n' for d in docs[:5])
    if classes: body += '<h2>Classes</h2><ul>' + ''.join(f'<li><a href="class{html.escape(c)}.html">{html.escape(c)}</a></li>' for c,_,__ in classes) + '</ul>'
    if funcs: body += '<h2>Functions</h2><ul>' + ''.join(f'<li>{html.escape(fn)}()</li>' for fn,_,__ in funcs) + '</ul>'
    (html_dir/'index.html').write_text(page('Main Page', project, body))
    file_items=''.join(f'<li><a href="{html.escape(p.name.replace(".", "_8"))}.html">{html.escape(str(p))}</a></li>' for p in files)
    (html_dir/'files.html').write_text(page('File List', project, '<h1>File List</h1><ul>'+file_items+'</ul>'))
    (html_dir/'annotated.html').write_text(page('Class List', project, '<h1>Class List</h1><ul>'+''.join(f'<li>{html.escape(c)}</li>' for c,_,__ in classes)+'</ul>'))
    for c,f,d in classes:
        (html_dir/f'class{c}.html').write_text(page(f'{c} Class Reference', project, f'<h1>{html.escape(c)} Class Reference</h1><p>{html.escape(d)}</p><p>File: {html.escape(f)}</p>'))
    for p in files:
        txt = p.read_text(errors='replace')
        name = p.name.replace('.', '_8') + '.html'
        (html_dir/name).write_text(page(f'{p.name} File Reference', project, f'<h1>{html.escape(p.name)} File Reference</h1><pre>{html.escape(txt)}</pre>'))
    if cfg.get('GENERATE_LATEX','NO').upper() == 'YES':
        ldir=outdir/'latex'; ldir.mkdir(parents=True, exist_ok=True); (ldir/'refman.tex').write_text('\\documentclass{article}\n\\begin{document}\n'+project+'\\end{document}\n')
    return 0

def main(argv):
    prog = argv[0] if argv else 'doxygen'
    args = argv[1:]
    if args and args[0] in ('-h','-?','--help'):
        sys.stdout.write(usage(prog)); return 0
    if args and args[0] in ('-v','--version'):
        print(VERSION); return 0
    if args and args[0] == '-V':
        print(VERSION); print('    with sqlite3 3.42.0.'); return 0
    if args and args[0] == '-d' and len(args)==1:
        sys.stdout.write(DEV); return 0
    simple = False
    if '-s' in args:
        simple=True; args=[a for a in args if a!='-s']
    if args and args[0] in ('-g','-u'):
        mode=args[0]; name=args[1] if len(args)>1 else 'Doxyfile'
        text=t('Doxyfile_s' if simple else 'Doxyfile_full')
        write_target(name, text)
        if name != '-':
            verb='updated' if mode=='-u' else 'created'
            print(f"\n\nConfiguration file '{name}' {verb}.\n")
            if mode=='-g':
                cmd='' if name=='Doxyfile' else ' '+name
                print('Now edit the configuration file and enter\n')
                print(f'  doxygen{cmd}\n')
                print('to generate the documentation for your project')
        return 0
    if args and args[0] == '-l':
        write_target(args[1] if len(args)>1 else 'DoxygenLayout.xml', t('layout.xml')); return 0
    if args and args[0] == '-e':
        if len(args)<3 or args[1] != 'rtf':
            print('error: option "-e" has invalid format specifier.', file=sys.stderr); return 1
        write_target(args[2], t('rtf_extensions.txt')); return 0
    if args and args[0] == '-f':
        if len(args)<3 or args[1] != 'emoji':
            print('error: option "-f" has invalid list specifier.', file=sys.stderr); return 1
        write_target(args[2], t('emoji.txt')); return 0
    if args and args[0] == '-w':
        if len(args)<2 or args[1] not in ('rtf','html','latex'):
            bad=args[1] if len(args)>1 else ''
            print(f'error: Illegal format specifier "{bad}": should be one of rtf, html or latex', file=sys.stderr); return 1
        fmt=args[1]
        need={'rtf':3,'html':5,'latex':5}[fmt]
        if len(args)<need:
            print(f'error: option "-w {fmt}" does not have enough arguments', file=sys.stderr); return 1
        if fmt=='rtf': write_target(args[2], t('rtf_style.txt'))
        elif fmt=='html':
            write_target(args[2], t('header.html')); write_target(args[3], t('footer.html')); write_target(args[4], t('doxygen.css'))
        else:
            write_target(args[2], t('latex_header.tex')); write_target(args[3], t('latex_footer.tex')); write_target(args[4], t('latex_style.sty'))
        return 0
    if args and args[0] in ('-x','-x_noenv'):
        print(f'# Difference with default Doxyfile {SHORT_VERSION} (9135bd68ddc9ea65023d967c75048a7a86a5d495)'); return 0
    quiet=False
    if args and args[0]=='-q': quiet=True; args=args[1:]
    if args and args[0].startswith('-'):
        print(f'error: Unknown option "{args[0]}"', file=sys.stderr)
        sys.stdout.write(usage(prog))
        return 1
    if not args:
        tmp=Path('.doxygen_default_tmp'); tmp.write_text('')
        cfg=str(tmp)
    else:
        cfg=args[0]
    if cfg == '-':
        tmp=Path('.doxygen_stdin_tmp'); tmp.write_text(sys.stdin.read()); cfg=str(tmp)
    if not Path(cfg).exists():
        print(f'error: configuration file {cfg} not found!', file=sys.stderr)
        sys.stdout.write(usage(prog)); return 1
    try: return run_docs(cfg, quiet)
    except Exception as e:
        print('error:', e, file=sys.stderr); return 1

if __name__ == '__main__':
    sys.exit(main(sys.argv))
