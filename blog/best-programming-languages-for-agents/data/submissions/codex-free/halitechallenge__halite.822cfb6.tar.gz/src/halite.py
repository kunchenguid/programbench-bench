#!/usr/bin/env python3
import os
import random
import select
import subprocess
import sys
import time

HELP = """
USAGE: 

   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...


Where: 

   -i <path to directory>,  --replaydirectory <path to directory>
     The path to directory for replay output.

   -s <positive integer>,  --seed <positive integer>
     The seed for the map generator.

   -d <a string containing two space-seprated positive integers>, 
      --dimensions <a string containing two space-seprated positive
      integers>
     The dimensions of the map.

   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>
     Create a map that will accommodate n players [SINGLE PLAYER MODE
     ONLY].

   -r,  --noreplay
     Turns off the replay generation.

   -t,  --timeout
     Causes game environment to ignore timeouts (give all bots infinite
     time).

   -o,  --override
     Overrides player-sent names using cmd args [SERVER ONLY].

   -q,  --quiet
     Runs game in quiet mode, producing machine-parsable output.

   --,  --ignore_rest
     Ignores the rest of the labeled arguments following this flag.

   --version
     Displays version information and exits.

   -h,  --help
     Displays usage information and exits.

   <Array of strings>  (accepted multiple times)
     Start commands for bots.


   Halite Game Environment
"""

BRIEF = """Brief USAGE: 
   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a
                 string containing two space-seprated positive integers>]
                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]
                 [-h] <Array of strings> ...

For complete USAGE and HELP type: 
   ./executable --help
"""


def parse_error(arg, value):
    print(f"PARSE ERROR: Argument: {arg}", file=sys.stderr)
    print(f"             Couldn't read argument value from string '{value}'", file=sys.stderr)
    print(file=sys.stderr)
    print(BRIEF, file=sys.stderr)
    sys.exit(1)


def parse_args(argv):
    opts = {
        "replay_dir": ".",
        "seed": None,
        "dims": None,
        "nplayers": None,
        "noreplay": False,
        "timeout": False,
        "override": False,
        "quiet": False,
    }
    bots = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            sys.exit(0)
        if a == "--version":
            print()
            print("./executable  version: 1.2")
            print()
            sys.exit(0)
        if a in ("--", "--ignore_rest"):
            bots.extend(argv[i + 1 :])
            break
        if a in ("-i", "--replaydirectory"):
            i += 1
            if i >= len(argv):
                parse_error("-i (--replaydirectory)", "")
            opts["replay_dir"] = argv[i]
        elif a in ("-s", "--seed"):
            i += 1
            if i >= len(argv):
                parse_error("-s (--seed)", "")
            try:
                seed = int(argv[i])
                if seed <= 0:
                    raise ValueError
                opts["seed"] = seed
            except ValueError:
                parse_error("-s (--seed)", argv[i])
        elif a in ("-d", "--dimensions"):
            i += 1
            if i >= len(argv):
                parse_error("-d (--dimensions)", "")
            parts = argv[i].split()
            try:
                if len(parts) != 2:
                    raise ValueError
                w, h = int(parts[0]), int(parts[1])
                if w < 0 or h < 0:
                    raise ValueError
                opts["dims"] = (w, h)
            except ValueError:
                parse_error("-d (--dimensions)", argv[i])
        elif a in ("-n", "--nplayers"):
            i += 1
            if i >= len(argv):
                parse_error("-n (--nplayers)", "")
            try:
                n = int(argv[i])
            except ValueError:
                n = 0
            opts["nplayers"] = n
        elif a in ("-r", "--noreplay"):
            opts["noreplay"] = True
        elif a in ("-t", "--timeout"):
            opts["timeout"] = True
        elif a in ("-o", "--override"):
            opts["override"] = True
        elif a in ("-q", "--quiet"):
            opts["quiet"] = True
        else:
            bots.append(a)
        i += 1
    return opts, bots


def dimensions(opts, bot_count):
    if opts["dims"] is not None:
        return opts["dims"]
    if opts["nplayers"] is None:
        table = {
            1: (40, 40),
            2: (40, 40),
            3: (39, 39),
            4: (24, 30),
            5: (30, 30),
            6: (36, 39),
        }
        return table.get(bot_count, (40, 40))
    n = opts["nplayers"]
    if n <= 2:
        return (40, 40)
    if n == 3:
        return (30, 30)
    if n == 4:
        return (24, 30)
    if n == 5:
        return (30, 30)
    return (24, 30)


def make_map(w, h, players, seed):
    rng = random.Random(seed)
    prod = [rng.randint(1, 9) for _ in range(w * h)]
    owners = [0] * (w * h)
    strengths = [rng.randint(0, 255) for _ in range(w * h)]
    starts = [
        (w // 2, h // 2),
        (0, 0),
        (w - 1, h - 1),
        (w - 1, 0),
        (0, h - 1),
        (w // 2, 0),
    ]
    for pid in range(1, players + 1):
        x, y = starts[(pid - 1) % len(starts)]
        idx = (y % h) * w + (x % w)
        owners[idx] = pid
        strengths[idx] = 255
    return prod, owners, strengths


def rle_owners(owners):
    out = []
    if not owners:
        return out
    cur = owners[0]
    cnt = 1
    for v in owners[1:]:
        if v == cur:
            cnt += 1
        else:
            out.extend([cnt, cur])
            cur, cnt = v, 1
    out.extend([cnt, cur])
    return out


def line(nums):
    return " ".join(str(x) for x in nums) + " \n"


def read_line(proc, timeout):
    try:
        if timeout is not None:
            ready, _, _ = select.select([proc.stdout], [], [], timeout)
            if not ready:
                return None, "timeout"
        s = proc.stdout.readline()
        if s == "":
            return "", "eof"
        return s.rstrip("\r\n"), None
    except Exception as e:
        return "", str(e)


def drain_stderr(proc, log):
    try:
        while True:
            ready, _, _ = select.select([proc.stderr], [], [], 0)
            if not ready:
                break
            data = os.read(proc.stderr.fileno(), 4096)
            if not data:
                break
            log.write(data.decode("utf-8", "replace"))
            log.flush()
    except Exception:
        pass


def main():
    opts, bots = parse_args(sys.argv[1:])
    if not bots:
        print("Please provide the launch command string for at least one bot.", file=sys.stderr)
        print("Use the --help flag for usage details.", file=sys.stderr)
        return 1
    if opts["nplayers"] is not None and opts["nplayers"] not in range(1, 7):
        for b in bots:
            print(b)
        for b in bots:
            print(b)
        print()
        print("A map can only accommodate between 1 and 6 players.")
        return 1
    if opts["nplayers"] is not None and len(bots) > 1:
        for b in bots:
            print(b)
        for b in bots:
            print(b)
        print()
        print("Only single-player mode enables specified n-player maps.  When entering multiple bots, please do not try to specify n.")
        return 1
    players_on_map = opts["nplayers"] or len(bots)
    w, h = dimensions(opts, len(bots))
    if w == 0 or h == 0:
        os.kill(os.getpid(), 11)
    seed = opts["seed"] if opts["seed"] is not None else random.SystemRandom().randrange(1, 2**32)
    timestamp = int(time.time())

    for b in bots:
        print(b)
    if not opts["quiet"]:
        for b in bots:
            print(b)
    print(f"{w} {h}")
    sys.stdout.flush()

    prod, owners, strengths = make_map(w, h, players_on_map, seed)
    prod_line = line(prod)
    frame_line = line(rle_owners(owners) + strengths)
    procs = []
    names = []
    alive = []
    last_alive = []
    logs = []
    init_timeout = None if opts["timeout"] else 2.0
    for i, cmd in enumerate(bots, 1):
        log_path = f"{i}-{timestamp}.log"
        log = open(log_path, "w")
        logs.append(log)
        p = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.PIPE, text=True, bufsize=1)
        procs.append(p)
        try:
            p.stdin.write(f"{i}\n")
            p.stdin.write(f"{w} {h} \n")
            p.stdin.write(prod_line)
            p.stdin.write(frame_line)
            p.stdin.flush()
        except Exception:
            pass
        if not opts["quiet"]:
            print(f"Init Message sent to player {i}.")
        name, err = read_line(p, init_timeout)
        drain_stderr(p, log)
        if name is None:
            name = cmd
            alive.append(False)
            last_alive.append(0)
        elif name == "" and err:
            err_line = ""
            try:
                drain_stderr(p, log)
                log.flush()
                with open(log_path, "r") as r:
                    err_line = r.readline().strip()
            except Exception:
                pass
            name = err_line or cmd
            alive.append(False)
            last_alive.append(0)
        else:
            alive.append(True)
            last_alive.append(0)
        if opts["override"]:
            name = cmd
        names.append(name)
        if not opts["quiet"]:
            print(f"Init Message received from player {i}, {name}.")
        sys.stdout.flush()

    max_turns = int((w * h) ** 0.5 * 10)
    if max_turns < 1:
        max_turns = 1
    for turn in range(1, max_turns + 1):
        if not opts["quiet"]:
            print(f"Turn {turn}")
            sys.stdout.flush()
        for idx, p in enumerate(procs):
            if not alive[idx]:
                continue
            try:
                p.stdin.write(frame_line)
                p.stdin.flush()
            except Exception:
                alive[idx] = False
                continue
            move, err = read_line(p, None if opts["timeout"] else 1.0)
            drain_stderr(p, logs[idx])
            if move is None or (move == "" and err == "eof"):
                alive[idx] = False
                if not opts["quiet"]:
                    print(f"Bot #{idx + 1} timeout or error (Unix) 0")
            else:
                last_alive[idx] = turn

    for p in procs:
        try:
            p.terminate()
        except Exception:
            pass
    for log in logs:
        log.close()

    ranked = sorted(range(len(bots)), key=lambda i: (last_alive[i], i), reverse=True)
    rank = [0] * len(bots)
    for r, idx in enumerate(ranked, 1):
        rank[idx] = r

    if opts["quiet"]:
        for i in range(len(bots)):
            print(f"{i + 1} {rank[i]} {last_alive[i]}")
        print(" ")
    else:
        if not opts["noreplay"]:
            os.makedirs(opts["replay_dir"], exist_ok=True)
            replay = os.path.join(opts["replay_dir"], f"{timestamp}-{seed}.hlt")
            with open(replay, "w") as f:
                f.write(f"Halite replay placeholder\nseed {seed}\n{w} {h}\n")
            print(f"Map seed was {seed}")
            print(f"Opening a file at {replay}")
        for i in range(len(bots)):
            print(f"Player #{i + 1}, {names[i]}, came in rank #{rank[i]} and was last alive on frame #{last_alive[i]}!")
    return 0


if __name__ == "__main__":
    sys.exit(main())
