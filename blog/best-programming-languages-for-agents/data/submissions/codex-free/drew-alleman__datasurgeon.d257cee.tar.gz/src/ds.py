#!/usr/bin/env python3
import argparse
import os
import re
import sys
import time
from pathlib import Path

VERSION = "DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8"
PLUGIN_PATH = "/home/agent/.DataSurgeon/plugins.json"


HELP = """Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.

Usage: executable [OPTIONS]

Options:
  -f, --file <file>            File to extract information from [default: ""]
      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: ""]
      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: ""]
      --list                   List all added plugins
  -C, --clean                  Only displays the matched result, rather than the entire line
      --directory <directory>  Process all files found in the specified directory [default: ""]
      --ignore                 Silences error messages
  -l, --line                   Displays the line number where the match occurred
  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line
  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)
  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file
      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop "^.{1,10}$" will hide all matches not under 10 characters) [default: ""]
      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: ""]
  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.
  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: ""]
  -t, --time                   Time how long the operation took
  -e, --email                  Extract email addresses
  -p, --phone                  Extracts phone numbers
  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)
  -i, --ip-addr                Extract IP addresses
  -6, --ipv6-addr              Extract IPv6 addresses
  -m, --mac-addr               Extract MAC addresses
  -c, --credit-card            Extract credit card numbers
  -u, --url                    Extract urls
  -F, --files                  Extract filenames
  -b, --bitcoin                Extract bitcoin wallets
  -a, --aws                    Extract AWS keys
  -g, --google                 Extract Google service account private key ids (used for google automations services)
  -d, --dns                    Extract Domain Name System records
  -s, --social                 Extract social security numbers
  -h, --help                   Print help
  -V, --version                Print version"""


def plugin_warning():
    print(f"Failed to open plugins.json file. PLUGIN_PATH: {PLUGIN_PATH}", file=sys.stderr)


def valid_ipv4(s):
    try:
        parts = s.split(".")
        return len(parts) == 4 and all(p.isdigit() and 0 <= int(p) <= 255 for p in parts)
    except Exception:
        return False


DETECTORS = [
    ("phone_number", re.compile(r"(?<!\d)(?:\+?1[-. ]?)?(?:\(?[2-9]\d{2}\)?[-. ]+)[2-9]\d{2}[-. ]+\d{4}(?!\d)")),
    ("email", re.compile(r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b")),
    ("ip_address", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
    ("ipv6_address", re.compile(r"(?:(?<![:\w])::1(?![:\w])|(?<![\w:])(?:[0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{0,4}(?![\w:]))")),
    ("mac_address", re.compile(r"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b")),
    ("credit_card", re.compile(r"\b(?:\d[ -]*?){13,16}\b")),
    ("url", re.compile(r"\b(?:https?|ftp)://[^\s<>'\"]+")),
    # The original is permissive and often includes the previous word.
    ("files", re.compile(r"\b(?:\S+\s+){0,2}\S+\.(?:txt|pdf|docx?|xlsx?|pptx?|csv|json|xml|html?|log|png|jpe?g|gif|zip|tar\.gz|gz|exe|dll|sh|py|rs|go|c|cpp|h)\b", re.I)),
    ("bitcoin_wallet", re.compile(r"\b(?:bc1[ac-hj-np-z02-9]{11,71}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b")),
    ("aws_key", re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b")),
    ("google_api", re.compile(r"\b[0-9a-f]{40}\b")),
    ("dns", re.compile(r"\b(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b")),
    ("social_security", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("hashes", re.compile(r"\b(?:\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}|[A-Fa-f0-9]{32}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{56}|[A-Fa-f0-9]{64}|[A-Fa-f0-9]{96}|[A-Fa-f0-9]{128})\b")),
]

FLAG_TO_NAME = {
    "email": "email",
    "phone": "phone_number",
    "hash": "hashes",
    "ip_addr": "ip_address",
    "ipv6_addr": "ipv6_address",
    "mac_addr": "mac_address",
    "credit_card": "credit_card",
    "url": "url",
    "files": "files",
    "bitcoin": "bitcoin_wallet",
    "aws": "aws_key",
    "google": "google_api",
    "dns": "dns",
    "social": "social_security",
}


def build_parser():
    p = argparse.ArgumentParser(add_help=False, prog="executable")
    p.add_argument("-f", "--file", default="")
    p.add_argument("--add", default="")
    p.add_argument("--update", default="")
    p.add_argument("--remove", default="")
    p.add_argument("--list", action="store_true", dest="list_plugins")
    p.add_argument("-C", "--clean", action="store_true")
    p.add_argument("--directory", default="")
    p.add_argument("--ignore", action="store_true")
    p.add_argument("-l", "--line", action="store_true")
    p.add_argument("-T", "--thorough", action="store_true")
    p.add_argument("-D", "--display", action="store_true")
    p.add_argument("-S", "--suppress", action="store_true")
    p.add_argument("--drop", default="")
    p.add_argument("--filter", default="")
    p.add_argument("-X", "--hide", action="store_true")
    p.add_argument("-o", "--output", default="")
    p.add_argument("-t", "--time", action="store_true")
    p.add_argument("-e", "--email", action="store_true")
    p.add_argument("-p", "--phone", action="store_true")
    p.add_argument("-H", "--hash", action="store_true")
    p.add_argument("-i", "--ip-addr", action="store_true")
    p.add_argument("-6", "--ipv6-addr", action="store_true")
    p.add_argument("-m", "--mac-addr", action="store_true")
    p.add_argument("-c", "--credit-card", action="store_true")
    p.add_argument("-u", "--url", action="store_true")
    p.add_argument("-F", "--files", action="store_true")
    p.add_argument("-b", "--bitcoin", action="store_true")
    p.add_argument("-a", "--aws", action="store_true")
    p.add_argument("-g", "--google", action="store_true")
    p.add_argument("-d", "--dns", action="store_true")
    p.add_argument("-s", "--social", action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    return p


def selected_names(args):
    names = [name for attr, name in FLAG_TO_NAME.items() if getattr(args, attr)]
    return set(names) if names else {name for name, _ in DETECTORS}


def ordered_detectors(args, explicit):
    if explicit:
        return DETECTORS
    if args.clean:
        order = ["phone_number", "email", "files", "hashes", "ip_address", "ipv6_address", "mac_address",
                 "credit_card", "url", "bitcoin_wallet", "aws_key", "google_api", "dns", "social_security"]
    else:
        order = ["email", "mac_address", "credit_card", "phone_number", "hashes", "files", "ip_address",
                 "ipv6_address", "url", "bitcoin_wallet", "aws_key", "google_api", "dns", "social_security"]
    by_name = dict(DETECTORS)
    return [(name, by_name[name]) for name in order if name in by_name]


def find_matches(line, names, detectors):
    out = []
    for name, rx in detectors:
        if name not in names:
            continue
        for m in rx.finditer(line):
            val = m.group(0).strip()
            if name == "files" and "://" in val and "=" in val:
                val = val.rsplit("=", 1)[-1].strip()
            if name == "ip_address" and not valid_ipv4(val):
                continue
            if name == "credit_card":
                digits = re.sub(r"\D", "", val)
                if len(digits) < 13 or len(digits) > 16:
                    continue
            out.append((name, val))
    return out


def passes_filters(value, args):
    try:
        if args.drop and re.search(args.drop, value):
            return False
        if args.filter and not re.search(args.filter, value):
            return False
    except re.error:
        return True
    return True


def format_record(kind, value, line_no, filename, args):
    if args.output:
        return f"{kind}, {value}"
    if args.hide:
        text = value
    elif args.line:
        text = f"{kind}, {value}"
    else:
        text = f"{kind}: {value}"
    if args.display and filename:
        if args.hide:
            text = f"file: {filename} {text}"
        elif args.line:
            text = f"{kind}, file: {filename} {value}"
        else:
            text = f"{kind}: file: {filename} {value}"
    if args.line:
        text = f"{text}, line: {line_no}"
    return text


def process_lines(lines, filename, args):
    records = []
    explicit = any(getattr(args, attr) for attr in FLAG_TO_NAME)
    names = selected_names(args)
    detectors = ordered_detectors(args, explicit)
    seen = set()
    for idx, line in enumerate(lines, 1):
        line = line.rstrip("\n")
        matches = find_matches(line, names, detectors)
        if not args.clean:
            if matches:
                kind = matches[0][0]
                val = line
                if passes_filters(val, args):
                    records.append((kind, val, idx, filename))
            continue
        for kind, val in matches:
            if not passes_filters(val, args):
                continue
            key = (kind, val)
            if key in seen:
                continue
            seen.add(key)
            records.append((kind, val, idx, filename))
            if not args.thorough:
                break
    return records


def input_files(args):
    if args.directory:
        base = Path(args.directory)
        if not base.exists():
            if not args.ignore:
                print(f"[-] Directory not found: {args.directory}", file=sys.stderr)
            return []
        return [str(p) for p in sorted(base.rglob("*")) if p.is_file()]
    if args.file:
        return [args.file]
    return []


def emit(records, args):
    lines = [format_record(*r, args) for r in records]
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write("content_type, data\n")
            for line in lines:
                f.write(line + "\n")
    else:
        for line in lines:
            print(line)


def main(argv):
    if "--help" in argv or "-h" in argv:
        plugin_warning()
        print(HELP)
        return 0
    if "--version" in argv or "-V" in argv:
        plugin_warning()
        print(VERSION)
        return 0
    parser = build_parser()
    try:
        args, _ = parser.parse_known_args(argv)
    except SystemExit as e:
        return int(e.code)

    start = time.time()
    plugin_warning()

    if args.list_plugins:
        plugin_warning()
        print(f"No plugins found. Plugin File: {PLUGIN_PATH}")
        return 0
    if args.add:
        print("[-] Error: Failed to parse plugins.json from the provided URL. Reason: builder error: relative URL without a base")
        return 0
    if args.remove or args.update:
        plugin_warning()
        return 0

    all_records = []
    files = input_files(args)
    if files:
        for fn in files:
            try:
                with open(fn, "r", encoding="utf-8", errors="ignore") as f:
                    all_records.extend(process_lines(f.readlines(), fn, args))
            except FileNotFoundError:
                if not args.ignore:
                    print(f"[-] File not found: {fn}", file=sys.stderr)
            except OSError as e:
                if not args.ignore:
                    print(f"[-] Error reading file {fn}: {e}", file=sys.stderr)
    else:
        if not args.suppress:
            print("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)", file=sys.stderr)
        all_records.extend(process_lines(sys.stdin.readlines(), "", args))

    emit(all_records, args)
    if args.time:
        print(f"Operation completed in {time.time() - start:.2f} seconds")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
