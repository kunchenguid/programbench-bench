#!/usr/bin/env python3
import argparse
import bz2
import gzip
import lzma
import os
import re
import sys


VERSION = "hck git:23bebe8-modified"

HELP_SHORT = """* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...  Input files to parse, defaults to stdin

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout
  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag [default: \\s+]
  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters
  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set
  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs [default: "\\t"]
  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive
  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`
  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex
  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex
  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals
  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions
  -Z, --try-compress
          Try to gzip compress the output
  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in `hck` staying single threaded [default: 4]
  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level [default: 6]
      --no-mmap
          Disallow the possibility of using mmap
      --crlf
          Support CRLF newlines
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

HELP_LONG = """* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`

## Selection by headers

Instead of specifying fields to output by index ranges (i.e `1-2,4-`), you can specify a regex or string literal to select a headered column to output with the `-F` option. By default `-F` options are treated as string literals. To treat them as regexs add the `-r` flag.

## Ordering of outputs

*Values are written only once*. So for a `fields` value of `4-,1,5-8`, which translates to "print columns 4 through the end and then the last column and then columns 5 through 8", columns 5-8 won't be printed again because they were already consumed by the `4-` range.

If `field-headers` is used as a regex then the headers will be be grouped together in groups that all matched the same regex, and in the order of the regex as specified on the CLI.

Usage: executable [OPTIONS] [INPUT]...

Arguments:
  [INPUT]...
          Input files to parse, defaults to stdin.
          
          If a file has a recognizable file extension indicating that it is compressed, and a local binary to perform decompression is found, decompression will occur automagically. This requires with `-z`.

Options:
  -o, --output <OUTPUT>
          Output file to write to, defaults to stdout

  -d, --delimiter <DELIMITER>
          Delimiter to use on input files, this is a substring literal by default. To treat it as a literal add the `-L` flag
          
          [default: \\s+]

  -L, --delim-is-literal
          Treat the delimiter as a string literal. This can significantly improve performance, especially for single byte delimiters

  -I, --use-input-delim
          Use the input delimiter as the output delimiter if the input is literal and no other output delimiter has been set

  -D, --output-delimiter <OUTPUT_DELIMITER>
          Delimiter string to use on outputs
          
          [default: "\\t"]

  -f, --fields <FIELDS>
          Fields to keep in the output, ex: 1,2-,-5,2-5. Fields are 1-based and inclusive

  -e, --exclude <EXCLUDE>
          Fields to exclude from the output, ex: 3,9-11,15-. Exclude fields are 1 based and inclusive. Exclude fields take precedence over `fields`

  -E, --exclude-header <EXCLUDE_HEADER>
          Headers to exclude from the output, ex: '^badfield.*$`. This is a string literal by default. Add the `-r` flag to treat as a regex

  -F, --header-field <HEADER_FIELD>
          A string literal or regex to select headers, ex: '^is_.*$`. This is a string literal by default. add the `-r` flag to treat it as a regex

  -r, --header-is-regex
          Treat the header_fields as regexs instead of string literals

  -z, --try-decompress
          Try to find the correct decompression method based on the file extensions

  -Z, --try-compress
          Try to gzip compress the output

  -t, --compression-threads <COMPRESSION_THREADS>
          Threads to use for compression, 0 will result in `hck` staying single threaded
          
          [default: 4]

  -l, --compression-level <COMPRESSION_LEVEL>
          Compression level
          
          [default: 6]

      --no-mmap
          Disallow the possibility of using mmap

      --crlf
          Support CRLF newlines

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""


def decode_escapes(s):
    out = []
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            c = s[i + 1]
            if c == "t":
                out.append("\t")
            elif c == "n":
                out.append("\n")
            elif c == "r":
                out.append("\r")
            elif c == "\\":
                out.append("\\")
            else:
                out.append("\\")
                out.append(c)
            i += 2
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def log_error(message):
    print(f"[2026-06-01T00:00:00Z ERROR hck] {message}", file=sys.stderr)


def parse_ranges(spec):
    if not spec:
        return []
    ranges = []
    for raw in spec.split(","):
        part = raw.strip()
        if not part:
            continue
        if "-" in part:
            if part.count("-") > 1:
                log_error(f"Invalid range: {part}")
                sys.exit(1)
            lo_s, hi_s = part.split("-", 1)
            lo = int(lo_s) if lo_s else 1
            hi = int(hi_s) if hi_s else None
            if lo < 1 or (hi is not None and hi < 1):
                bad = lo if lo < 1 else hi
                log_error(f"Fields and positions are numbered from 1: {bad}")
                sys.exit(1)
            if hi is not None and hi < lo:
                log_error(f"High end of range less than low end of range: {part}")
                sys.exit(1)
            ranges.append((lo, hi))
        else:
            try:
                n = int(part)
            except ValueError:
                log_error(f"Invalid field: {part}")
                sys.exit(1)
            if n < 1:
                log_error(f"Fields and positions are numbered from 1: {n}")
                sys.exit(1)
            ranges.append((n, n))
    return ranges


def indices_from_ranges(ranges, nfields):
    intervals = []
    for lo, hi in ranges:
        end = nfields if hi is None else min(hi, nfields)
        if lo <= end:
            intervals.append([lo, end])
    if not intervals:
        return []

    # hck preserves selector order for disjoint selections, but overlapping
    # ranges are coalesced and emitted in field order.
    merged_any = False
    used = [False] * len(intervals)
    groups = []
    for i, (lo, hi) in enumerate(intervals):
        if used[i]:
            continue
        used[i] = True
        changed = True
        while changed:
            changed = False
            for j, (jlo, jhi) in enumerate(intervals):
                if used[j]:
                    continue
                if jlo <= hi and jhi >= lo:
                    lo = min(lo, jlo)
                    hi = max(hi, jhi)
                    used[j] = True
                    changed = True
                    merged_any = True
        groups.append((lo, hi))
    if merged_any:
        groups.sort(key=lambda p: p[0])

    result = []
    for lo, hi in groups:
        result.extend(range(lo - 1, hi))
    return result


def split_line(line, args):
    if args.crlf and line.endswith("\r"):
        line = line[:-1]
    delim = decode_escapes(args.delimiter)
    if args.delim_is_literal:
        if delim == "":
            return [line]
        return line.split(delim)
    try:
        return re.split(delim, line)
    except re.error as e:
        print("Error: regex parse error:", file=sys.stderr)
        print(f"    {delim}", file=sys.stderr)
        print(f"error: {e}", file=sys.stderr)
        sys.exit(1)


def header_matches(header, pattern, regex):
    pat = decode_escapes(pattern)
    if regex:
        return re.search(pat, header) is not None
    return header == pat


def select_header_indices(headers, includes, excludes, regex):
    seen = set()
    selected = []
    if includes:
        for pat in includes:
            for i, h in enumerate(headers):
                if i not in seen and header_matches(h, pat, regex):
                    seen.add(i)
                    selected.append(i)
    else:
        selected = list(range(len(headers)))
        seen = set(selected)
    if excludes:
        excluded = set()
        for pat in excludes:
            for i, h in enumerate(headers):
                if header_matches(h, pat, regex):
                    excluded.add(i)
        selected = [i for i in selected if i not in excluded]
    return selected


def open_input(path, try_decompress):
    if path == "-":
        return sys.stdin
    if try_decompress:
        lower = path.lower()
        if lower.endswith(".gz"):
            return gzip.open(path, "rt", newline="")
        if lower.endswith(".bz2"):
            return bz2.open(path, "rt", newline="")
        if lower.endswith(".xz") or lower.endswith(".lzma"):
            return lzma.open(path, "rt", newline="")
    return open(path, "r", newline="")


def open_output(path, try_compress):
    if path is None:
        if try_compress:
            return gzip.open(sys.stdout.buffer, "wt", newline="")
        return sys.stdout
    if try_compress or path.lower().endswith(".gz"):
        return gzip.open(path, "wt", newline="")
    return open(path, "w", newline="")


def process_stream(fh, out, args, state):
    header_mode = bool(args.header_field or args.exclude_header)
    out_delim = decode_escapes(args.output_delimiter)
    if args.use_input_delim and args.delim_is_literal and not args.output_delimiter_set:
        out_delim = decode_escapes(args.delimiter)
    field_ranges = parse_ranges(args.fields) if args.fields else []
    exclude_ranges = parse_ranges(args.exclude) if args.exclude else []
    header_indices = None

    for raw in fh:
        line = raw[:-1] if raw.endswith("\n") else raw
        parts = split_line(line, args)
        if header_mode and header_indices is None:
            header_indices = select_header_indices(
                parts, args.header_field or [], args.exclude_header or [], args.header_is_regex
            )
            if (args.header_field or args.exclude_header) and not header_indices:
                log_error("No headers matched")
                sys.exit(1)
            indices = header_indices
        elif header_mode:
            indices = [i for i in header_indices if i < len(parts)]
        elif field_ranges:
            indices = indices_from_ranges(field_ranges, len(parts))
        else:
            indices = list(range(len(parts)))

        if exclude_ranges and not header_mode:
            excluded = set(indices_from_ranges(exclude_ranges, len(parts)))
            indices = [i for i in indices if i not in excluded]
        elif exclude_ranges and header_mode:
            excluded = set(indices_from_ranges(exclude_ranges, len(parts)))
            indices = [i for i in indices if i not in excluded]

        values = [parts[i] for i in indices if i < len(parts)]
        out.write(out_delim.join(values))
        out.write("\n")
        state["wrote"] = True


def build_parser():
    parser = argparse.ArgumentParser(
        prog="executable",
        formatter_class=argparse.RawTextHelpFormatter,
        description="* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`",
    )
    parser.add_argument("-o", "--output")
    parser.add_argument("-d", "--delimiter", default=r"\s+")
    parser.add_argument("-L", "--delim-is-literal", action="store_true")
    parser.add_argument("-I", "--use-input-delim", action="store_true")
    parser.add_argument("-D", "--output-delimiter", default="\t")
    parser.add_argument("-f", "--fields")
    parser.add_argument("-e", "--exclude")
    parser.add_argument("-E", "--exclude-header", action="append")
    parser.add_argument("-F", "--header-field", action="append")
    parser.add_argument("-r", "--header-is-regex", action="store_true")
    parser.add_argument("-z", "--try-decompress", action="store_true")
    parser.add_argument("-Z", "--try-compress", action="store_true")
    parser.add_argument("-t", "--compression-threads", default="4")
    parser.add_argument("-l", "--compression-level", default="6")
    parser.add_argument("--no-mmap", action="store_true")
    parser.add_argument("--crlf", action="store_true")
    parser.add_argument("-V", "--version", action="store_true")
    parser.add_argument("input", nargs="*")
    return parser


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if argv == ["-h"]:
        print(HELP_SHORT, end="")
        return 0
    if argv == ["--help"]:
        print(HELP_LONG, end="")
        return 0
    output_delimiter_set = any(a == "-D" or a == "--output-delimiter" or a.startswith("-D") for a in argv)
    parser = build_parser()
    args = parser.parse_args(argv)
    args.output_delimiter_set = output_delimiter_set
    if args.version:
        print(VERSION)
        return 0
    inputs = args.input or ["-"]
    state = {"wrote": False}
    with open_output(args.output, args.try_compress) as out:
        for path in inputs:
            with open_input(path, args.try_decompress) as fh:
                process_stream(fh, out, args, state)
    return 0


if __name__ == "__main__":
    sys.exit(main())
