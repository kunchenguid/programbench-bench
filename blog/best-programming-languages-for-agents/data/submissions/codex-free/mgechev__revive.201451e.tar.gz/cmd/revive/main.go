package main

import (
	"bytes"
	"encoding/json"
	"encoding/xml"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"unicode"
)

const banner = `
 _ __ _____   _(_)__  _____
| '__/ _ \ \ / / \ \ / / _ \
| | |  __/\ V /| |\ V /  __/
|_|  \___| \_/ |_| \_/ \___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...

`

type listFlag []string

func (l *listFlag) String() string { return strings.Join(*l, ",") }
func (l *listFlag) Set(s string) error {
	*l = append(*l, s)
	return nil
}

type config struct {
	hasConfig bool
	severity  string
	rules     map[string]bool
	lineLimit int
}

type pos struct {
	Filename string
	Offset   int
	Line     int
	Column   int
}

type position struct {
	Start pos
	End   pos
}

type failure struct {
	Severity        string
	Failure         string
	RuleName        string
	Category        string
	Position        position
	Confidence      float64
	ReplacementLine string
}

func main() {
	var cfgPath, formatter string
	var maxOpen int
	var setExit, version bool
	var excludes listFlag
	flag.CommandLine.Init(os.Args[0], flag.ExitOnError)
	flag.CommandLine.SetOutput(os.Stderr)
	flag.Usage = func() {
		fmt.Fprint(os.Stderr, banner)
		fmt.Fprintf(os.Stderr, "Usage of %s:\n", os.Args[0])
		flag.PrintDefaults()
	}
	flag.StringVar(&cfgPath, "config", "", "path to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)")
	flag.Var(&excludes, "exclude", "list of globs which specify files to be excluded (i.e. -exclude foo/...)")
	flag.StringVar(&formatter, "formatter", "", "formatter to be used for the output (i.e. -formatter stylish)")
	flag.IntVar(&maxOpen, "max_open_files", 0, "maximum number of open files at the same time")
	flag.BoolVar(&setExit, "set_exit_status", false, "set exit status to 1 if any issues are found, overwrites errorCode and warningCode in config")
	flag.BoolVar(&version, "version", false, "get revive version")
	flag.Parse()
	_ = maxOpen

	if version {
		fmt.Println("Version:\ta75b67b")
		fmt.Println("Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05")
		fmt.Println("Built\t\t2026-04-17 19:59 UTC by build.sh")
		return
	}

	if formatter == "" {
		formatter = "default"
	}
	if !knownFormatter(formatter) {
		fmt.Fprintf(os.Stderr, "formatting - getting formatter: unknown formatter %s\n", formatter)
		os.Exit(1)
	}

	cfg, err := loadConfig(cfgPath)
	if err != nil {
		fmt.Fprintln(os.Stderr, "cannot read the config file")
		os.Exit(1)
	}
	files := collectFiles(flag.Args(), excludes)
	var fails []failure
	for _, file := range files {
		fails = append(fails, lintFile(file, cfg)...)
	}
	sortFailures(fails, formatter)
	printFailures(formatter, fails)
	if setExit && len(fails) > 0 {
		os.Exit(1)
	}
}

func knownFormatter(s string) bool {
	switch s {
	case "default", "json", "ndjson", "friendly", "stylish", "checkstyle", "sarif", "plain", "unix":
		return true
	}
	return false
}

func loadConfig(path string) (config, error) {
	cfg := config{severity: "warning", rules: map[string]bool{
		"package-comments": true, "exported": true, "var-naming": true,
	}}
	if path == "" {
		for _, p := range defaultConfigPaths() {
			if _, err := os.Stat(p); err == nil {
				path = p
				break
			}
		}
	}
	if path == "" {
		return cfg, nil
	}
	data, err := os.ReadFile(path)
	if err != nil {
		return cfg, err
	}
	cfg.hasConfig = true
	cfg.rules = map[string]bool{}
	current := ""
	for _, raw := range strings.Split(string(data), "\n") {
		line := strings.TrimSpace(strings.Split(raw, "#")[0])
		if line == "" {
			continue
		}
		if strings.HasPrefix(line, "severity") && strings.Contains(line, "=") {
			cfg.severity = trimValue(strings.SplitN(line, "=", 2)[1])
			continue
		}
		if strings.HasPrefix(line, "[rule.") && strings.HasSuffix(line, "]") {
			current = strings.TrimSuffix(strings.TrimPrefix(line, "[rule."), "]")
			cfg.rules[current] = true
			continue
		}
		if current != "" && strings.HasPrefix(strings.ToLower(line), "disabled") && strings.Contains(line, "=") {
			v := strings.ToLower(trimValue(strings.SplitN(line, "=", 2)[1]))
			if v == "true" {
				cfg.rules[current] = false
			}
		}
		if current == "line-length-limit" && strings.HasPrefix(strings.ToLower(line), "arguments") {
			re := regexp.MustCompile(`\d+`)
			if m := re.FindString(line); m != "" {
				cfg.lineLimit, _ = strconv.Atoi(m)
			}
		}
	}
	return cfg, nil
}

func trimValue(s string) string {
	s = strings.TrimSpace(s)
	s = strings.Trim(s, `"'`)
	return s
}

func defaultConfigPaths() []string {
	var out []string
	if xdg := os.Getenv("XDG_CONFIG_HOME"); xdg != "" {
		out = append(out, filepath.Join(xdg, "revive.toml"))
	}
	if home := os.Getenv("HOME"); home != "" {
		out = append(out, filepath.Join(home, "revive.toml"))
	}
	return out
}

func collectFiles(args []string, excludes []string) []string {
	if len(args) == 0 {
		return nil
	}
	seen := map[string]bool{}
	var files []string
	add := func(p string) {
		if !strings.HasSuffix(p, ".go") || strings.HasSuffix(p, "_test.go") || excluded(p, excludes) || seen[p] {
			return
		}
		seen[p] = true
		files = append(files, p)
	}
	for _, arg := range args {
		if strings.HasSuffix(arg, "/...") {
			root := strings.TrimSuffix(arg, "/...")
			if root == "" {
				root = "."
			}
			filepath.WalkDir(root, func(path string, d fs.DirEntry, err error) error {
				if err != nil {
					return nil
				}
				if d.IsDir() {
					if d.Name() == ".git" || d.Name() == "vendor" || excluded(path, excludes) {
						return filepath.SkipDir
					}
					return nil
				}
				add(path)
				return nil
			})
			continue
		}
		st, err := os.Stat(arg)
		if err == nil && st.IsDir() {
			ents, _ := os.ReadDir(arg)
			for _, ent := range ents {
				if !ent.IsDir() {
					add(filepath.Join(arg, ent.Name()))
				}
			}
			continue
		}
		add(arg)
	}
	sort.Strings(files)
	return files
}

func excluded(path string, patterns []string) bool {
	clean := filepath.ToSlash(path)
	for _, pat := range patterns {
		p := filepath.ToSlash(pat)
		if strings.HasSuffix(p, "/...") {
			if strings.HasPrefix(clean, strings.TrimSuffix(p, "/...")) {
				return true
			}
		}
		if ok, _ := filepath.Match(p, clean); ok || clean == p {
			return true
		}
	}
	return false
}

func lintFile(path string, cfg config) []failure {
	src, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	fset := token.NewFileSet()
	file, err := parser.ParseFile(fset, path, src, parser.ParseComments)
	if err != nil {
		return nil
	}
	var fails []failure
	disabledLines, disabledAll := disabledInfo(src)
	if cfg.rules["line-length-limit"] && !disabledAll {
		limit := cfg.lineLimit
		if limit == 0 {
			limit = 80
		}
		offset := 0
		for i, line := range strings.Split(string(src), "\n") {
			lineNo := i + 1
			if len(line) > limit && !disabledLines[lineNo] {
				p := position{Start: pos{path, offset, lineNo, 1}, End: pos{path, offset + len(line), lineNo, len(line) + 1}}
				msg := fmt.Sprintf("line is %d characters, out of limit %d", len(line), limit)
				fails = append(fails, failure{cfg.severity, msg, "line-length-limit", "style", p, 1, ""})
			}
			offset += len(line) + 1
		}
	}
	if cfg.rules["package-comments"] && !disabledAll && !disabledLines[fset.Position(file.Package).Line] && file.Doc == nil {
		p := mkPos(fset, file.Package, file.Name.End())
		fails = append(fails, failure{cfg.severity, "should have a package comment", "package-comments", "comments", p, 1, ""})
	}
	ast.Inspect(file, func(n ast.Node) bool {
		if n == nil || disabledAll {
			return true
		}
		switch x := n.(type) {
		case *ast.GenDecl:
			for _, spec := range x.Specs {
				switch s := spec.(type) {
				case *ast.TypeSpec:
					doc := x.Doc
					if s.Doc != nil {
						doc = s.Doc
					}
					if !disabledLines[fset.Position(s.Name.Pos()).Line] {
						checkName(&fails, cfg, fset, s.Name, s.Name.Name, "type", doc, s.Pos(), s.End(), "")
					}
				case *ast.ValueSpec:
					doc := x.Doc
					if s.Doc != nil {
						doc = s.Doc
					}
					kind := strings.ToLower(x.Tok.String())
					for _, name := range s.Names {
						if !disabledLines[fset.Position(name.Pos()).Line] {
							checkName(&fails, cfg, fset, name, name.Name, kind, doc, name.Pos(), s.End(), "")
						}
					}
				}
			}
		case *ast.FuncDecl:
			kind := "function"
			prefix := ""
			if x.Recv != nil && len(x.Recv.List) > 0 {
				kind = "method"
				prefix = recvName(x.Recv.List[0].Type) + "."
			}
			if !disabledLines[fset.Position(x.Name.Pos()).Line] {
				checkName(&fails, cfg, fset, x.Name, x.Name.Name, kind, x.Doc, x.Pos(), x.End(), prefix)
			}
		}
		return true
	})
	return fails
}

func disabledInfo(src []byte) (map[int]bool, bool) {
	lines := strings.Split(string(src), "\n")
	disabled := map[int]bool{}
	all := false
	block := false
	for i, line := range lines {
		lineNo := i + 1
		if block {
			disabled[lineNo] = true
		}
		if strings.Contains(line, "revive:disable-next-line") {
			disabled[lineNo+1] = true
			continue
		}
		if strings.Contains(line, "revive:disable-line") {
			disabled[lineNo] = true
			continue
		}
		if strings.Contains(line, "revive:disable") {
			block = true
			all = true
			disabled[lineNo] = true
		}
		if strings.Contains(line, "revive:enable") {
			block = false
		}
	}
	return disabled, all && !strings.Contains(string(src), "revive:enable")
}

func checkName(fails *[]failure, cfg config, fset *token.FileSet, ident *ast.Ident, name, kind string, doc *ast.CommentGroup, start, end token.Pos, prefix string) {
	if cfg.rules["exported"] && ast.IsExported(name) && doc == nil {
		msg := fmt.Sprintf("exported %s %s%s should have comment or be unexported", kind, prefix, name)
		*fails = append(*fails, failure{cfg.severity, msg, "exported", "comments", mkPos(fset, start, end), 1, ""})
	}
	if cfg.rules["var-naming"] && strings.Contains(name, "_") {
		msg := fmt.Sprintf("don't use underscores in Go names; %s %s should be %s", goKind(kind), name, lintName(name))
		*fails = append(*fails, failure{cfg.severity, msg, "var-naming", "naming", mkPos(fset, ident.Pos(), ident.End()), 0.9, ""})
	}
}

func goKind(k string) string {
	if k == "function" {
		return "func"
	}
	return k
}

func recvName(e ast.Expr) string {
	switch t := e.(type) {
	case *ast.Ident:
		return t.Name
	case *ast.StarExpr:
		return recvName(t.X)
	}
	return ""
}

func lintName(s string) string {
	parts := strings.Split(s, "_")
	for i, p := range parts {
		if p == "" {
			continue
		}
		rs := []rune(strings.ToLower(p))
		rs[0] = unicode.ToUpper(rs[0])
		parts[i] = string(rs)
	}
	return strings.Join(parts, "")
}

func mkPos(fset *token.FileSet, start, end token.Pos) position {
	sp := fset.Position(start)
	ep := fset.Position(end)
	return position{Start: pos{sp.Filename, sp.Offset, sp.Line, sp.Column}, End: pos{ep.Filename, ep.Offset, ep.Line, ep.Column}}
}

func sortFailures(fails []failure, formatter string) {
	sort.SliceStable(fails, func(i, j int) bool {
		a, b := fails[i], fails[j]
		if a.Position.Start.Filename != b.Position.Start.Filename {
			return a.Position.Start.Filename < b.Position.Start.Filename
		}
		if formatter == "friendly" {
			if a.RuleName != b.RuleName {
				return a.RuleName < b.RuleName
			}
		}
		if a.Position.Start.Line != b.Position.Start.Line {
			return a.Position.Start.Line < b.Position.Start.Line
		}
		if a.Position.Start.Column != b.Position.Start.Column {
			return a.Position.Start.Column < b.Position.Start.Column
		}
		return a.RuleName < b.RuleName
	})
}

func printFailures(formatter string, fails []failure) {
	switch formatter {
	case "json":
		b, _ := json.Marshal(fails)
		fmt.Println(string(b))
	case "ndjson":
		for _, f := range fails {
			b, _ := json.Marshal(f)
			fmt.Println(string(b))
		}
		if len(fails) > 0 {
			fmt.Println()
		}
	case "unix":
		for _, f := range fails {
			fmt.Printf("%s:%d:%d: [%s] %s\n", f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column, f.RuleName, f.Failure)
		}
		if len(fails) > 0 {
			fmt.Println()
		}
	case "plain":
		for _, f := range fails {
			fmt.Printf("%s:%d:%d: %s https://revive.run/r#%s\n", f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column, f.Failure, f.RuleName)
		}
	case "friendly":
		printFriendly(fails)
	case "stylish":
		printStylish(fails)
	case "checkstyle":
		printCheckstyle(fails)
	case "sarif":
		printSarif(fails)
	default:
		for _, f := range fails {
			fmt.Printf("%s:%d:%d: %s\n", f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column, f.Failure)
		}
	}
}

func printFriendly(fails []failure) {
	counts := map[string]int{}
	for _, f := range fails {
		fmt.Printf("  \u26a0  https://revive.run/r#%s  %s\n  %s:%d:%d\n\n", f.RuleName, f.Failure, f.Position.Start.Filename, f.Position.Start.Line, f.Position.Start.Column)
		counts[f.RuleName]++
	}
	if len(fails) == 0 {
		return
	}
	fmt.Printf("\u26a0 %d problems (0 errors, %d warnings)\n\nWarnings:\n", len(fails), len(fails))
	var rules []string
	for r := range counts {
		rules = append(rules, r)
	}
	sort.Strings(rules)
	for _, r := range rules {
		fmt.Printf("  %d  %s\n", counts[r], r)
	}
	fmt.Println()
}

func printStylish(fails []failure) {
	byFile := map[string][]failure{}
	var files []string
	for _, f := range fails {
		if _, ok := byFile[f.Position.Start.Filename]; !ok {
			files = append(files, f.Position.Start.Filename)
		}
		byFile[f.Position.Start.Filename] = append(byFile[f.Position.Start.Filename], f)
	}
	sort.Strings(files)
	for _, file := range files {
		fmt.Println(file)
		for _, f := range byFile[file] {
			fmt.Printf("  (%d, %d)  %-35s  %s\n", f.Position.Start.Line, f.Position.Start.Column, "https://revive.run/r#"+f.RuleName, f.Failure)
		}
		fmt.Println()
	}
	if len(fails) > 0 {
		fmt.Printf("\n \u2716 %d problems (0 errors) (%d warnings)\n", len(fails), len(fails))
	}
}

type csCheckstyle struct {
	XMLName xml.Name `xml:"checkstyle"`
	Version string   `xml:"version,attr"`
	Files   []csFile `xml:"file"`
}
type csFile struct {
	Name   string    `xml:"name,attr"`
	Errors []csError `xml:"error"`
}
type csError struct {
	Line     int    `xml:"line,attr"`
	Column   int    `xml:"column,attr"`
	Message  string `xml:"message,attr"`
	Severity string `xml:"severity,attr"`
	Source   string `xml:"source,attr"`
}

func printCheckstyle(fails []failure) {
	byFile := map[string][]failure{}
	var files []string
	for _, f := range fails {
		if _, ok := byFile[f.Position.Start.Filename]; !ok {
			files = append(files, f.Position.Start.Filename)
		}
		byFile[f.Position.Start.Filename] = append(byFile[f.Position.Start.Filename], f)
	}
	sort.Strings(files)
	var out csCheckstyle
	out.Version = "5.0"
	for _, file := range files {
		cf := csFile{Name: file}
		for _, f := range byFile[file] {
			cf.Errors = append(cf.Errors, csError{f.Position.Start.Line, f.Position.Start.Column, fmt.Sprintf("%s (confidence %s)", f.Failure, confString(f.Confidence)), f.Severity, "revive/" + f.RuleName})
		}
		out.Files = append(out.Files, cf)
	}
	var buf bytes.Buffer
	buf.WriteString("<?xml version='1.0' encoding='UTF-8'?>\n")
	enc := xml.NewEncoder(&buf)
	enc.Indent("", "    ")
	_ = enc.Encode(out)
	fmt.Println(buf.String())
}

func printSarif(fails []failure) {
	type result struct {
		Level     string `json:"level"`
		Locations []any  `json:"locations"`
		Message   any    `json:"message"`
		RuleID    string `json:"ruleId"`
	}
	var results []result
	for _, f := range fails {
		loc := map[string]any{"physicalLocation": map[string]any{"artifactLocation": map[string]any{"uri": f.Position.Start.Filename}, "region": map[string]any{"startColumn": f.Position.Start.Column, "startLine": f.Position.Start.Line}}}
		results = append(results, result{f.Severity, []any{loc}, map[string]any{"text": f.Failure}, f.RuleName})
	}
	obj := map[string]any{"runs": []any{map[string]any{"results": results, "tool": map[string]any{"driver": map[string]any{"informationUri": "https://revive.run", "name": "revive", "rules": []any{map[string]any{"helpUri": "https://revive.run/r#var-declaration", "id": "var-declaration", "properties": map[string]any{"severity": "warning"}}}}}}}, "version": "2.1.0", "$schema": "https://json.schemastore.org/sarif-2.1.0.json"}
	b, _ := json.MarshalIndent(obj, "", "  ")
	fmt.Println(string(b))
}

func confString(f float64) string {
	if f == float64(int(f)) {
		return strconv.Itoa(int(f))
	}
	return strconv.FormatFloat(f, 'f', -1, 64)
}
