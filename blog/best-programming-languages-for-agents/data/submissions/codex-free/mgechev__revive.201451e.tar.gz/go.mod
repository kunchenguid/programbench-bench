module revive-reimpl

go 1.20
