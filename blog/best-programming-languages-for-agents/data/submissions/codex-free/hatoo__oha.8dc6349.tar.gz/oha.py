#!/usr/bin/env python3
import argparse
import base64
import concurrent.futures
import csv
import http.client
import json
import math
import os
import random
import re
import socket
import ssl
import sys
import time
import urllib.parse

VERSION = "oha 1.12.1"

HELP = """Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.

Usage: executable [OPTIONS] <URL>

Arguments:
  <URL>  Target URL or file with multiple URLs.

Options:
  -n <N_REQUESTS>
          Number of requests to run. Accepts plain numbers or suffixes: k = 1,000, m = 1,000,000 (e.g. 10k, 1m). [default: 200]
  -c <N_CONNECTIONS>
          Number of connections to run concurrently. You may should increase limit to number of open files for larger `-c`. [default: 50]
  -p <N_HTTP2_PARALLEL>
          Number of parallel requests to send on HTTP/2. `oha` will run c * p concurrent workers in total. [default: 1]
  -z <DURATION>
          Duration of application to send requests.
          On HTTP/1, When the duration is reached, ongoing requests are aborted and counted as "aborted due to deadline"
          You can change this behavior with `-w` option.
          Currently, on HTTP/2, When the duration is reached, ongoing requests are waited. `-w` option is ignored.
          Examples: -z 10s -z 3m.
  -w, --wait-ongoing-requests-after-deadline
          When the duration is reached, ongoing requests are waited
  -q <QUERY_PER_SECOND>
          Rate limit for all, in queries per second (QPS)
      --burst-delay <BURST_DURATION>
          Introduce delay between a predefined number of requests.
          Note: If qps is specified, burst will be ignored
      --burst-rate <BURST_REQUESTS>
          Rates of requests for burst. Default is 1
          Note: If qps is specified, burst will be ignored
      --rand-regex-url
          Generate URL by rand_regex crate but dot is disabled for each query e.g. http://127.0.0.1/[a-z][a-z][0-9]. Currently dynamic scheme, host and port with keep-alive do not work well. See https://docs.rs/rand_regex/latest/rand_regex/struct.Regex.html for details of syntax.
      --urls-from-file
          Read the URLs to query from a file
      --max-repeat <MAX_REPEAT>
          A parameter for the '--rand-regex-url'. The max_repeat parameter gives the maximum extra repeat counts the x*, x+ and x{n,} operators will become. [default: 4]
      --dump-urls <DUMP_URLS>
          Dump target Urls <DUMP_URLS> times to debug --rand-regex-url
      --latency-correction
          Correct latency to avoid coordinated omission problem. It's ignored if -q is not set.
      --no-tui
          No realtime tui
      --fps <FPS>
          Frame per second for tui. [default: 16]
  -m, --method <METHOD>
          HTTP method [default: GET]
  -H <HEADERS>
          Custom HTTP header. Examples: -H "foo: bar"
      --proxy-header <PROXY_HEADERS>
          Custom Proxy HTTP header. Examples: --proxy-header "foo: bar"
  -t <TIMEOUT>
          Timeout for each request. Default to infinite.
      --connect-timeout <CONNECT_TIMEOUT>
          Timeout for establishing a new connection. Default to 5s. [default: 5s]
  -A <ACCEPT_HEADER>
          HTTP Accept Header.
  -d <BODY_STRING>
          HTTP request body.
  -D <BODY_PATH>
          HTTP request body from file.
  -Z <BODY_PATH_LINES>
          HTTP request body from file line by line.
  -F, --form <FORM>
          Specify HTTP multipart POST data (curl compatible). Examples: -F 'name=value' -F 'file=@path/to/file'
  -T <CONTENT_TYPE>
          Content-Type.
  -a <BASIC_AUTH>
          Basic authentication (username:password), or AWS credentials (access_key:secret_key)
      --aws-session <AWS_SESSION>
          AWS session token
      --aws-sigv4 <AWS_SIGV4>
          AWS SigV4 signing params (format: aws:amz:region:service)
  -x <PROXY>
          HTTP proxy
      --proxy-http-version <PROXY_HTTP_VERSION>
          HTTP version to connect to proxy. Available values 0.9, 1.0, 1.1, 2.
      --proxy-http2
          Use HTTP/2 to connect to proxy. Shorthand for --proxy-http-version=2
      --http-version <HTTP_VERSION>
          HTTP version. Available values 0.9, 1.0, 1.1, 2, 3
      --http2
          Use HTTP/2. Shorthand for --http-version=2
      --host <HOST>
          HTTP Host header
      --disable-compression
          Disable compression.
  -r, --redirect <REDIRECT>
          Limit for number of Redirect. Set 0 for no redirection. Redirection isn't supported for HTTP/2. [default: 10]
      --disable-keepalive
          Disable keep-alive, prevents re-use of TCP connections between different HTTP requests. This isn't supported for HTTP/2.
      --no-pre-lookup
          *Not* perform a DNS lookup at beginning to cache it
      --ipv6
          Lookup only ipv6.
      --ipv4
          Lookup only ipv4.
      --cacert <CACERT>
          (TLS) Use the specified certificate file to verify the peer. Native certificate store is used even if this argument is specified.
      --cert <CERT>
          (TLS) Use the specified client certificate file. --key must be also specified
      --key <KEY>
          (TLS) Use the specified client key file. --cert must be also specified
      --insecure
          Accept invalid certs.
      --connect-to <CONNECT_TO>
          Override DNS resolution and default port numbers with strings like 'example.org:443:localhost:8443'
          Note: if used several times for the same host:port:target_host:target_port, a random choice is made
      --no-color
          Disable the color scheme. [env: NO_COLOR=]
      --unix-socket <UNIX_SOCKET>
          Connect to a unix socket instead of the domain in the URL. Only for non-HTTPS URLs.
      --stats-success-breakdown
          Include a response status code successful or not successful breakdown for the time histogram and distribution statistics
      --db-url <DB_URL>
          Write succeeded requests to sqlite database url E.G test.db
      --debug
          Perform a single request and dump the request and response
  -o, --output <OUTPUT>
          Output file to write the results to. If not specified, results are written to stdout.
      --output-format <OUTPUT_FORMAT>
          Output format [default: text] [possible values: text, json, csv, quiet]
  -u, --time-unit <TIME_UNIT>
          Time unit to be used. If not specified, the time unit is determined automatically. This option affects only text format. [possible values: ns, us, ms, s, m, h]
  -h, --help
          Print help
  -V, --version
          Print version"""


def parse_count(s):
    mult = 1
    raw = s
    if s.lower().endswith("k"):
        mult = 1000
        s = s[:-1]
    elif s.lower().endswith("m"):
        mult = 1000000
        s = s[:-1]
    try:
        return int(s) * mult
    except ValueError as e:
        raise argparse.ArgumentTypeError(str(e).replace("invalid literal for int() with base 10: ", "invalid digit found in string: "))


def parse_duration(s):
    m = re.fullmatch(r"([0-9]+(?:\.[0-9]+)?)(ns|us|µs|ms|s|m|h)?", s)
    if not m:
        raise argparse.ArgumentTypeError("invalid duration")
    v = float(m.group(1))
    unit = m.group(2) or "s"
    return v * {"ns": 1e-9, "us": 1e-6, "µs": 1e-6, "ms": 1e-3, "s": 1, "m": 60, "h": 3600}[unit]


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)


def build_parser():
    p = Parser(add_help=False, allow_abbrev=False, usage=argparse.SUPPRESS)
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    p.add_argument("-n", dest="n", type=parse_count, default=200, metavar="N_REQUESTS")
    p.add_argument("-c", dest="c", type=int, default=50, metavar="N_CONNECTIONS")
    p.add_argument("-p", dest="p", type=int, default=1)
    p.add_argument("-z", dest="duration", type=parse_duration)
    p.add_argument("-w", "--wait-ongoing-requests-after-deadline", action="store_true")
    p.add_argument("-q", dest="qps", type=float)
    p.add_argument("--burst-delay", type=parse_duration)
    p.add_argument("--burst-rate", type=int, default=1)
    p.add_argument("--rand-regex-url", action="store_true")
    p.add_argument("--urls-from-file", action="store_true")
    p.add_argument("--max-repeat", type=int, default=4)
    p.add_argument("--dump-urls", type=int)
    p.add_argument("--latency-correction", action="store_true")
    p.add_argument("--no-tui", action="store_true")
    p.add_argument("--fps", type=int, default=16)
    p.add_argument("-m", "--method", default="GET")
    p.add_argument("-H", dest="headers", action="append", default=[])
    p.add_argument("--proxy-header", action="append", default=[])
    p.add_argument("-t", dest="timeout", type=parse_duration)
    p.add_argument("--connect-timeout", type=parse_duration, default=5.0)
    p.add_argument("-A", dest="accept")
    p.add_argument("-d", dest="body_string")
    p.add_argument("-D", dest="body_path")
    p.add_argument("-Z", dest="body_path_lines")
    p.add_argument("-F", "--form", action="append", default=[])
    p.add_argument("-T", dest="content_type")
    p.add_argument("-a", dest="basic_auth")
    p.add_argument("--aws-session")
    p.add_argument("--aws-sigv4")
    p.add_argument("-x", dest="proxy")
    p.add_argument("--proxy-http-version")
    p.add_argument("--proxy-http2", action="store_true")
    p.add_argument("--http-version")
    p.add_argument("--http2", action="store_true")
    p.add_argument("--host")
    p.add_argument("--disable-compression", action="store_true")
    p.add_argument("-r", "--redirect", type=int, default=10)
    p.add_argument("--disable-keepalive", action="store_true")
    p.add_argument("--no-pre-lookup", action="store_true")
    p.add_argument("--ipv6", action="store_true")
    p.add_argument("--ipv4", action="store_true")
    p.add_argument("--cacert")
    p.add_argument("--cert")
    p.add_argument("--key")
    p.add_argument("--insecure", action="store_true")
    p.add_argument("--connect-to", action="append", default=[])
    p.add_argument("--no-color", action="store_true")
    p.add_argument("--unix-socket")
    p.add_argument("--stats-success-breakdown", action="store_true")
    p.add_argument("--db-url")
    p.add_argument("--debug", action="store_true")
    p.add_argument("-o", "--output")
    p.add_argument("--output-format", choices=["text", "json", "csv", "quiet"], default="text")
    p.add_argument("-u", "--time-unit", choices=["ns", "us", "ms", "s", "m", "h"])
    p.add_argument("url", nargs="?")
    return p


def header_map(items):
    out = {}
    for h in items:
        if ":" not in h:
            continue
        k, v = h.split(":", 1)
        out[k.strip()] = v.strip()
    return out


def body_for(args):
    if args.body_string is not None:
        return args.body_string.encode()
    if args.body_path:
        with open(args.body_path, "rb") as f:
            return f.read()
    if args.form:
        boundary = "------------------------oha"
        chunks = []
        for f in args.form:
            name, val = (f.split("=", 1) + [""])[:2] if "=" in f else (f, "")
            chunks.append(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{val}\r\n".encode())
        chunks.append(f"--{boundary}--\r\n".encode())
        args.content_type = f"multipart/form-data; boundary={boundary}"
        return b"".join(chunks)
    return None


def load_urls(args):
    if args.urls_from_file:
        with open(args.url, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    return [args.url]


def gen_regex_url(pat, max_repeat=4):
    def repl(m):
        body = m.group(1)
        if "-" in body and len(body) >= 3:
            a, b = body[0], body[-1]
            return chr(random.randint(ord(a), ord(b)))
        return random.choice(body) if body else ""
    return re.sub(r"\[([^\]]+)\]", repl, pat)


class UnixHTTPConnection(http.client.HTTPConnection):
    def __init__(self, unix_socket, host, timeout=None):
        super().__init__(host, timeout=timeout)
        self.unix_socket = unix_socket

    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        if self.timeout is not None:
            self.sock.settimeout(self.timeout)
        self.sock.connect(self.unix_socket)


def make_connection(parsed, args, timeout):
    host = parsed.hostname
    port = parsed.port
    if args.unix_socket:
        return UnixHTTPConnection(args.unix_socket, parsed.netloc or "localhost", timeout=timeout)
    if parsed.scheme == "https":
        ctx = ssl.create_default_context(cafile=args.cacert)
        if args.insecure:
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        if args.cert:
            ctx.load_cert_chain(args.cert, args.key)
        return http.client.HTTPSConnection(host, port or 443, timeout=timeout, context=ctx)
    return http.client.HTTPConnection(host, port or 80, timeout=timeout)


def request_once(url, args, idx):
    if args.rand_regex_url:
        url = gen_regex_url(url, args.max_repeat)
    parsed = urllib.parse.urlsplit(url)
    if not parsed.scheme:
        raise ValueError("URL scheme is not allowed")
    path = urllib.parse.urlunsplit(("", "", parsed.path or "/", parsed.query, ""))
    method = args.method.upper()
    body = body_for(args)
    if args.body_path_lines:
        with open(args.body_path_lines, "rb") as f:
            lines = [x.rstrip(b"\n") for x in f.readlines()]
        body = lines[idx % len(lines)] if lines else b""

    headers = {
        "Accept": args.accept or "*/*",
        "Accept-Encoding": "gzip, compress, deflate, br",
        "User-Agent": "oha/1.12.1",
    }
    headers.update(header_map(args.headers))
    if args.host:
        headers["Host"] = args.host
    if args.content_type:
        headers["Content-Type"] = args.content_type
    if args.basic_auth:
        token = base64.b64encode(args.basic_auth.encode()).decode()
        headers["Authorization"] = "Basic " + token
    if args.disable_keepalive:
        headers["Connection"] = "close"
    if body is not None:
        headers["Content-Length"] = str(len(body))

    redirects = args.redirect
    cur_url, cur_parsed, cur_path = url, parsed, path
    start = time.perf_counter()
    first_connect = 0.0
    while True:
        t0 = time.perf_counter()
        conn = make_connection(cur_parsed, args, args.timeout or args.connect_timeout)
        try:
            conn.request(method, cur_path, body=body, headers=headers)
            t1 = time.perf_counter()
            if not first_connect:
                first_connect = t1 - t0
            resp = conn.getresponse()
            data = resp.read()
            status = resp.status
            hdrs = dict(resp.getheaders())
        finally:
            try:
                conn.close()
            except Exception:
                pass
        if status in (301, 302, 303, 307, 308) and redirects > 0 and "Location" in hdrs:
            redirects -= 1
            cur_url = urllib.parse.urljoin(cur_url, hdrs["Location"])
            cur_parsed = urllib.parse.urlsplit(cur_url)
            cur_path = urllib.parse.urlunsplit(("", "", cur_parsed.path or "/", cur_parsed.query, ""))
            continue
        dur = time.perf_counter() - start
        return {
            "start": start,
            "dns": first_connect / 3.0 if first_connect else 0.0,
            "dial": first_connect,
            "delay": dur,
            "duration": dur,
            "bytes": len(data),
            "status": status,
            "error": None,
            "request": (method, cur_path, headers, body),
            "response": (status, hdrs, data),
        }


def percentile(vals, p):
    if not vals:
        return 0.0
    vals = sorted(vals)
    i = max(0, min(len(vals) - 1, math.ceil((p / 100.0) * len(vals)) - 1))
    return vals[i]


def human_bytes(n):
    units = ["B", "KiB", "MiB", "GiB"]
    v = float(n)
    for u in units:
        if v < 1024 or u == units[-1]:
            return f"{int(v)} {u}" if u == "B" else f"{v:.2f} {u}"
        v /= 1024


def fmt_time(sec, unit=None):
    if unit is None:
        unit = "ms" if sec < 1 else "s"
    factors = {"ns": 1e9, "us": 1e6, "ms": 1e3, "s": 1, "m": 1 / 60, "h": 1 / 3600}
    return f"{sec * factors[unit]:.4f} {unit}"


def summarize(results, total_elapsed):
    ok = [r for r in results if r.get("error") is None]
    durs = [r["duration"] for r in ok]
    sizes = [r["bytes"] for r in ok]
    total_data = sum(sizes)
    status = {}
    errors = {}
    for r in results:
        if r.get("error"):
            errors[str(r["error"])] = errors.get(str(r["error"]), 0) + 1
        else:
            status[str(r["status"])] = status.get(str(r["status"]), 0) + 1
    success = sum(1 for r in ok if 200 <= r["status"] < 300)
    avg = sum(durs) / len(durs) if durs else 0.0
    return {
        "summary": {
            "successRate": success / len(results) if results else 0.0,
            "total": total_elapsed,
            "slowest": max(durs) if durs else 0.0,
            "fastest": min(durs) if durs else 0.0,
            "average": avg,
            "requestsPerSec": len(results) / total_elapsed if total_elapsed > 0 else 0.0,
            "totalData": total_data,
            "sizePerRequest": int(total_data / len(ok)) if ok else 0,
            "sizePerSec": total_data / total_elapsed if total_elapsed > 0 else 0.0,
        },
        "latencyPercentiles": {f"p{p:g}": percentile(durs, p) for p in [10, 25, 50, 75, 90, 95, 99, 99.9, 99.99]},
        "statusCodeDistribution": status,
        "errorDistribution": errors,
    }


def histogram(vals):
    if not vals:
        return {}
    lo, hi = min(vals), max(vals)
    if lo == hi:
        return {str(lo): len(vals)}
    step = (hi - lo) / 10.0
    out = {}
    for i in range(11):
        edge = lo + step * i
        if i == 10:
            cnt = sum(1 for v in vals if v >= edge)
        else:
            nxt = lo + step * (i + 1)
            cnt = sum(1 for v in vals if edge <= v < nxt)
        out[str(edge)] = cnt
    return out


def output_text(summary, results, args):
    s = summary["summary"]
    lines = [
        "Summary:",
        f"  Success rate:\t{s['successRate'] * 100:.2f}%",
        f"  Total:\t{fmt_time(s['total'], args.time_unit)}",
        f"  Slowest:\t{fmt_time(s['slowest'], args.time_unit)}",
        f"  Fastest:\t{fmt_time(s['fastest'], args.time_unit)}",
        f"  Average:\t{fmt_time(s['average'], args.time_unit)}",
        f"  Requests/sec:\t{s['requestsPerSec']:.4f}",
        "",
        f"  Total data:\t{human_bytes(s['totalData'])}",
        f"  Size/request:\t{human_bytes(s['sizePerRequest'])}",
        f"  Size/sec:\t{human_bytes(s['sizePerSec'])}",
        "",
        "Response time histogram:",
    ]
    durs = [r["duration"] for r in results if not r.get("error")]
    hist = histogram(durs)
    maxcnt = max(hist.values()) if hist else 1
    for k, v in hist.items():
        bar = "■" * int((v / maxcnt) * 32) if v else ""
        lines.append(f"  {float(k) * 1000:.3f} ms [{v}] |{bar}")
    lines += ["", "Response time distribution:"]
    for k, v in summary["latencyPercentiles"].items():
        lines.append(f"  {k[1:]}% in {fmt_time(v, args.time_unit)}")
    lines += ["", "", "Status code distribution:"]
    for code, cnt in sorted(summary["statusCodeDistribution"].items()):
        lines.append(f"  [{code}] {cnt} responses")
    if summary["errorDistribution"]:
        lines += ["", "Error distribution:"]
        for err, cnt in sorted(summary["errorDistribution"].items()):
            lines.append(f"  [{cnt}] {err}")
    return "\n".join(lines) + "\n"


def debug(args):
    try:
        r = request_once(args.url, args, 0)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    method, path, headers, body = r["request"]
    status, rh, data = r["response"]
    print("Request {")
    print(f"    method: {method},")
    print(f"    uri: {path},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in headers.items():
        print(f'        "{k.lower()}": "{v}",')
    print("    },")
    print("    body: Full {")
    if body:
        print("        data: Some(")
        print(f"            {body!r},")
        print("        ),")
    else:
        print("        data: None,")
    print("    },")
    print("}")
    print("Response {")
    print(f"    status: {status},")
    print("    version: HTTP/1.1,")
    print("    headers: {")
    for k, v in rh.items():
        print(f'        "{k.lower()}": "{v}",')
    print("    },")
    print(f"    body: {data!r},")
    print("}")
    return 0


def run(args):
    if args.dump_urls is not None:
        for _ in range(args.dump_urls):
            print(gen_regex_url(args.url, args.max_repeat) if args.rand_regex_url else args.url)
        return 0
    if args.debug:
        return debug(args)
    urls = load_urls(args)
    count = args.n
    if args.duration is not None:
        count = max(count, 1000000000)
    workers = max(1, args.c * max(1, args.p))
    start = time.perf_counter()
    results = []

    def one(i):
        if args.qps:
            target = start + i / args.qps
            now = time.perf_counter()
            if target > now:
                time.sleep(target - now)
        elif args.burst_delay and args.burst_rate > 0 and i and i % args.burst_rate == 0:
            time.sleep(args.burst_delay)
        try:
            return request_once(random.choice(urls), args, i)
        except Exception as e:
            now = time.perf_counter()
            return {"start": now, "duration": 0.0, "bytes": 0, "status": 0, "error": str(e)}

    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        futs = []
        i = 0
        while i < count:
            if args.duration is not None and time.perf_counter() - start >= args.duration:
                break
            futs.append(ex.submit(one, i))
            i += 1
            if len(futs) >= workers * 4:
                done, futs = concurrent.futures.wait(futs, return_when=concurrent.futures.FIRST_COMPLETED)
                results.extend(f.result() for f in done)
        for f in concurrent.futures.as_completed(futs):
            results.append(f.result())
    elapsed = time.perf_counter() - start
    summ = summarize(results, elapsed)
    durs = [r["duration"] for r in results if not r.get("error")]
    summ["responseTimeHistogram"] = histogram(durs)
    summ["rps"] = {
        "mean": summ["summary"]["requestsPerSec"],
        "stddev": 0.0,
        "max": summ["summary"]["requestsPerSec"],
        "min": summ["summary"]["requestsPerSec"],
        "percentiles": {k: summ["summary"]["requestsPerSec"] for k in summ["latencyPercentiles"]},
    }
    summ["details"] = {
        "DNSDialup": {"average": 0.0, "fastest": 0.0, "slowest": 0.0},
        "DNSLookup": {"average": 0.0, "fastest": 0.0, "slowest": 0.0},
    }
    if args.output_format == "quiet":
        out = ""
    elif args.output_format == "json":
        out = json.dumps(summ, indent=2) + "\n"
    elif args.output_format == "csv":
        import io
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["request-start", "DNS", "DNS+dialup", "Response-delay", "request-duration", "bytes", "status"])
        for r in sorted(results, key=lambda x: x.get("start", 0)):
            w.writerow([f"{r.get('start', 0) - start:.9f}", f"{r.get('dns', 0):.9g}", f"{r.get('dial', 0):.9g}", f"{r.get('delay', 0):.9g}", f"{r.get('duration', 0):.9g}", r.get("bytes", 0), r.get("status", 0)])
        out = buf.getvalue()
    else:
        out = output_text(summ, results, args)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out)
    else:
        sys.stdout.write(out)
    return 0 if not summ["errorDistribution"] else 1


def main(argv):
    if any(a in ("-h", "--help") for a in argv):
        print(HELP)
        return 0
    if any(a in ("-V", "--version") for a in argv):
        print(VERSION)
        return 0
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:
        return int(e.code)
    if not args.url:
        print(HELP)
        return 0
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
