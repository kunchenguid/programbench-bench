#!/usr/bin/env python3
import os
import re
import shlex
import subprocess
import sys


VERSION = "0.68.0 (5676da4a)"

HELP = """fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
        --scheme=SCHEME      Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
    --with-nth=N[,..]        Transform the presentation of each line
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result
    --tail=NUM               Maximum number of items to keep in memory
    --disabled               Do not perform search

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters
    --ansi                   Enable processing of ANSI color codes

  DISPLAY MODE
    --height=[~]HEIGHT[%]    Display fzf window below the cursor
    --tmux[=OPTS]            Start fzf in a tmux popup

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page
"""


ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")


class Config:
    def __init__(self):
        self.filter = None
        self.query = ""
        self.exact = False
        self.extended = True
        self.case = "smart"
        self.sort = True
        self.read0 = False
        self.print0 = False
        self.print_query = False
        self.select1 = False
        self.exit0 = False
        self.delimiter = None
        self.nth = None
        self.with_nth = None
        self.accept_nth = None
        self.tac = False
        self.tail = None
        self.disabled = False
        self.ansi = False
        self.expect = None
        self.scheme = "default"


OPTS_WITH_ARG = {
    "--scheme", "--nth", "--with-nth", "--accept-nth", "--delimiter", "--tail",
    "--query", "--filter", "--height", "--min-height", "--tmux", "--layout",
    "--margin", "--padding", "--border", "--border-label", "--border-label-pos",
    "--multi", "--wrap-sign", "--gap", "--gap-line", "--freeze-left",
    "--freeze-right", "--scroll-off", "--hscroll-off", "--jump-labels",
    "--gutter", "--gutter-raw", "--pointer", "--marker", "--marker-multi-line",
    "--ellipsis", "--tabstop", "--scrollbar", "--list-border", "--list-label",
    "--list-label-pos", "--prompt", "--info", "--info-command", "--separator",
    "--ghost", "--input-border", "--input-label", "--input-label-pos",
    "--preview", "--preview-window", "--preview-border", "--preview-label",
    "--preview-label-pos", "--header", "--header-lines", "--header-border",
    "--header-lines-border", "--header-label", "--header-label-pos", "--footer",
    "--footer-border", "--footer-label", "--footer-label-pos", "--expect",
    "--bind", "--color", "--style", "--with-shell", "--listen", "--walker",
    "--walker-root", "--walker-skip", "--history", "--history-size",
    "--tiebreak", "--algo",
}

FLAG_OPTS = {
    "--exact", "--no-exact", "--extended", "--no-extended", "--ignore-case", "--no-ignore-case",
    "--smart-case", "--literal", "--no-sort", "--disabled", "--read0",
    "--print0", "--ansi", "--sync", "--no-color", "--no-bold", "--reverse", "--inline-info",
    "--highlight-line", "--cycle", "--wrap", "--no-multi-line", "--raw",
    "--track", "--tac", "--keep-right", "--no-hscroll", "--no-scrollbar",
    "--no-input", "--no-separator", "--filepath-word", "--header-first",
    "--print-query", "--select-1", "--exit-0", "--bash", "--zsh", "--fish",
    "--help", "--version", "--man",
}


def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(2)


def option_words(argv):
    words = []
    env_file = os.environ.get("FZF_DEFAULT_OPTS_FILE")
    if env_file:
        try:
            with open(os.path.expanduser(env_file), "r", encoding="utf-8") as f:
                words += shlex.split(f.read(), comments=False, posix=True)
        except OSError:
            pass
    env_opts = os.environ.get("FZF_DEFAULT_OPTS")
    if env_opts:
        try:
            words += shlex.split(env_opts, comments=False, posix=True)
        except ValueError:
            words += env_opts.split()
    words += argv
    return words


def get_arg(words, i, opt):
    if i + 1 >= len(words):
        if opt == "--height":
            die("height required: [~]HEIGHT[%]")
        die(f"{opt} option requires an argument")
    return words[i + 1], i + 1


def parse(argv):
    cfg = Config()
    words = option_words(argv)
    i = 0
    while i < len(words):
        w = words[i]
        if w == "--":
            i += 1
            break
        opt, val, had_eq = w, None, False
        if w.startswith("--") and "=" in w:
            opt, val = w.split("=", 1)
            had_eq = True

        if opt in ("--help",):
            print(HELP, end="")
            sys.exit(0)
        if opt == "--version":
            print(VERSION)
            sys.exit(0)
        if opt == "--man":
            try:
                with open("man/man1/fzf.1", "r", encoding="utf-8") as f:
                    print(f.read(), end="")
            except OSError:
                print(HELP, end="")
            sys.exit(0)
        if opt in ("--bash", "--zsh", "--fish"):
            shell = opt[2:]
            print(f"### key-bindings.{shell} ###")
            print("# fzf shell integration")
            print(f"# Generated by fzf {VERSION}")
            sys.exit(0)

        if w in ("-e",):
            cfg.exact = True
        elif w in ("-x",):
            cfg.extended = True
        elif w in ("-i",):
            cfg.case = "ignore"
        elif w == "+i":
            cfg.case = "respect"
        elif w in ("+x",):
            cfg.extended = False
        elif w in ("+s",):
            cfg.sort = False
        elif w == "-1":
            cfg.select1 = True
        elif w == "-0":
            cfg.exit0 = True
        elif w == "-q":
            val, i = get_arg(words, i, "--query")
            cfg.query = val
        elif w.startswith("-q") and len(w) > 2:
            cfg.query = w[2:]
        elif w == "-f":
            val, i = get_arg(words, i, "--filter")
            cfg.filter = val
        elif w.startswith("-f") and len(w) > 2:
            cfg.filter = w[2:]
        elif w == "-d":
            val, i = get_arg(words, i, "--delimiter")
            cfg.delimiter = val
        elif w.startswith("-d") and len(w) > 2:
            cfg.delimiter = w[2:]
        elif w == "-n":
            val, i = get_arg(words, i, "--nth")
            cfg.nth = val
        elif w.startswith("-n") and len(w) > 2:
            cfg.nth = w[2:]
        elif w == "-m":
            pass
        elif w.startswith("--"):
            if opt not in OPTS_WITH_ARG and opt not in FLAG_OPTS:
                die(f"unknown option: {w}")
            if opt in OPTS_WITH_ARG:
                if val is None and opt not in ("--tmux", "--border", "--preview-border", "--list-border", "--input-border", "--header-border", "--header-lines-border", "--footer-border", "--multi", "--gap", "--scrollbar", "--listen"):
                    val, i = get_arg(words, i, opt)
                elif val is None:
                    val = ""
                apply_long(cfg, opt, val)
            else:
                apply_long(cfg, opt, None)
        elif w.startswith("+"):
            if w == "+i":
                cfg.case = "respect"
            elif w in ("+x", "+s"):
                pass
            else:
                die(f"unknown option: {w}")
        else:
            pass
        i += 1
    return cfg


def apply_long(cfg, opt, val):
    if opt == "--exact":
        cfg.exact = True
    elif opt == "--no-exact":
        cfg.exact = False
    elif opt == "--extended":
        cfg.extended = True
    elif opt == "--no-extended":
        cfg.extended = False
    elif opt == "--ignore-case":
        cfg.case = "ignore"
    elif opt == "--no-ignore-case":
        cfg.case = "respect"
    elif opt == "--smart-case":
        cfg.case = "smart"
    elif opt == "--no-sort":
        cfg.sort = False
    elif opt == "--read0":
        cfg.read0 = True
    elif opt == "--print0":
        cfg.print0 = True
    elif opt == "--ansi":
        cfg.ansi = True
    elif opt == "--tac":
        cfg.tac = True
    elif opt == "--disabled":
        cfg.disabled = True
    elif opt == "--print-query":
        cfg.print_query = True
    elif opt == "--select-1":
        cfg.select1 = True
    elif opt == "--exit-0":
        cfg.exit0 = True
    elif opt == "--query":
        cfg.query = val
    elif opt == "--filter":
        cfg.filter = val
    elif opt == "--delimiter":
        cfg.delimiter = val
    elif opt == "--nth":
        cfg.nth = val
    elif opt == "--with-nth":
        cfg.with_nth = val
    elif opt == "--accept-nth":
        cfg.accept_nth = val
    elif opt == "--tail":
        try:
            cfg.tail = int(val)
        except ValueError:
            die(f"not a valid integer: {val}")
    elif opt == "--multi" and val:
        try:
            int(val)
        except ValueError:
            die(f"not a valid integer: {val}")
    elif opt == "--scheme":
        if val not in ("default", "path", "history"):
            die(f"invalid scoring scheme: {val} (expected: default|path|history)")
        cfg.scheme = val
    elif opt == "--expect":
        cfg.expect = val


def read_items(cfg):
    if sys.stdin.isatty():
        cmd = os.environ.get("FZF_DEFAULT_COMMAND")
        if cmd:
            try:
                data = subprocess.check_output(cmd, shell=True)
            except Exception:
                data = b""
        else:
            rows = []
            for root, dirs, files in os.walk("."):
                dirs[:] = [d for d in dirs if d not in (".git", "node_modules")]
                for name in files:
                    rows.append(os.path.join(root, name)[2:])
            data = ("\n".join(rows) + ("\n" if rows else "")).encode()
    else:
        data = sys.stdin.buffer.read()
    sep = b"\0" if cfg.read0 else b"\n"
    parts = data.split(sep)
    if parts and parts[-1] == b"":
        parts.pop()
    items = [p.decode("utf-8", "surrogateescape") for p in parts]
    if cfg.tail is not None and cfg.tail >= 0:
        items = items[-cfg.tail:]
    if cfg.tac:
        items.reverse()
    return items


def strip_ansi(s):
    return ANSI_RE.sub("", s)


def fields(line, delim):
    if delim is None:
        return re.findall(r"\S+", line)
    try:
        return re.split(delim, line)
    except re.error:
        return line.split(delim)


def select_expr(fs, expr):
    out = []
    for part in expr.split(","):
        part = part.strip()
        if not part:
            continue
        if ".." in part:
            a, b = part.split("..", 1)
            start = int(a) if a else 1
            end = int(b) if b else len(fs)
            if start < 0:
                start = len(fs) + start + 1
            if end < 0:
                end = len(fs) + end + 1
            out.extend(fs[max(start - 1, 0):max(end, 0)])
        else:
            n = int(part)
            if n < 0:
                n = len(fs) + n + 1
            if 1 <= n <= len(fs):
                out.append(fs[n - 1])
    return out


def transform(line, spec, delim, ordinal):
    fs = fields(line, delim)
    joiner = " " if delim is None else (delim if not re.search(r"[\\.^$*+?{}\[\]|()]", delim) else " ")
    if "{" in spec:
        def repl(m):
            inner = m.group(1)
            if inner == "n":
                return str(ordinal)
            try:
                return joiner.join(select_expr(fs, inner))
            except Exception:
                return ""
        return re.sub(r"\{([^{}]+)\}", repl, spec)
    try:
        return joiner.join(select_expr(fs, spec))
    except Exception:
        return line


def searchable_text(line, cfg, ordinal):
    text = line
    if cfg.with_nth:
        text = transform(text, cfg.with_nth, cfg.delimiter, ordinal)
    if cfg.nth:
        text = transform(text, cfg.nth, cfg.delimiter, ordinal)
    if cfg.ansi:
        text = strip_ansi(text)
    return text


def normalize_case(q, s, cfg):
    if cfg.case == "ignore" or (cfg.case == "smart" and not any(c.isupper() for c in q)):
        return q.lower(), s.lower()
    return q, s


def fuzzy_score(q, s):
    if q == "":
        return 0
    pos = []
    start = 0
    for ch in q:
        idx = s.find(ch, start)
        if idx < 0:
            return None
        pos.append(idx)
        start = idx + 1
    span = pos[-1] - pos[0] + 1
    gaps = span - len(q)
    contiguous = 100 if gaps == 0 else 0
    prefix = 30 if pos[0] == 0 else 0
    return 1000 + contiguous + prefix - pos[0] * 2 - gaps * 8 - len(s)


def token_score(raw, text, cfg):
    inv = raw.startswith("!")
    tok = raw[1:] if inv else raw
    quoted = tok.startswith("'")
    if quoted:
        tok = tok[1:]
    prefix = tok.startswith("^")
    suffix = tok.endswith("$") and len(tok) > 0
    if prefix:
        tok = tok[1:]
    if suffix:
        tok = tok[:-1]
    q, s = normalize_case(tok, text, cfg)
    if tok == "":
        ok, score = True, 0
    elif prefix and suffix:
        ok = s == q
        score = 2000 - len(s) if ok else None
    elif prefix:
        ok = s.startswith(q)
        score = 1800 - len(s) if ok else None
    elif suffix:
        ok = s.endswith(q)
        score = 1800 - len(s) if ok else None
    elif quoted or cfg.exact:
        idx = s.find(q)
        ok = idx >= 0
        score = 1500 - idx * 2 - len(s) if ok else None
    else:
        score = fuzzy_score(q, s)
        ok = score is not None
    if inv:
        return 0 if not ok else None
    return score if ok else None


def split_query(q, extended):
    if not extended:
        return [[q]] if q else [[]]
    groups = [[]]
    cur = ""
    esc = False
    for ch in q:
        if esc:
            cur += ch
            esc = False
        elif ch == "\\":
            esc = True
        elif ch == "|":
            if cur.strip():
                groups[-1].extend(cur.strip().split())
            groups.append([])
            cur = ""
        else:
            cur += ch
    if cur.strip():
        groups[-1].extend(cur.strip().split())
    return groups


def match_score(query, text, cfg):
    if cfg.disabled or query == "":
        return 0
    groups = split_query(query, cfg.extended)
    best = None
    for group in groups:
        total = 0
        ok = True
        for tok in group:
            sc = token_score(tok, text, cfg)
            if sc is None:
                ok = False
                break
            total += sc
        if ok:
            best = total if best is None else max(best, total)
    return best


def output_line(item, cfg, ordinal):
    if cfg.accept_nth:
        return transform(item, cfg.accept_nth, cfg.delimiter, ordinal)
    return item


def main():
    cfg = parse(sys.argv[1:])
    query = cfg.filter if cfg.filter is not None else cfg.query
    items = read_items(cfg)
    matches = []
    for idx, item in enumerate(items):
        sc = match_score(query, searchable_text(item, cfg, idx), cfg)
        if sc is not None:
            matches.append((idx, sc, item))
    if cfg.sort and query:
        matches.sort(key=lambda x: (-x[1], len(searchable_text(x[2], cfg, x[0])), x[0]))
    if cfg.filter is None:
        if cfg.exit0 and not matches:
            if cfg.print_query:
                write_records([query], cfg)
            sys.exit(1)
        if cfg.select1 and len(matches) == 1:
            records = []
            if cfg.print_query:
                records.append(query)
            records.append(output_line(matches[0][2], cfg, matches[0][0]))
            write_records(records, cfg)
            sys.exit(0)
        # There is no terminal UI in this reimplementation. In batch contexts,
        # behave like accepting all current matches so scripts can still compose.
    records = []
    if cfg.print_query:
        records.append(query)
    for idx, _, item in matches:
        records.append(output_line(item, cfg, idx))
    write_records(records, cfg)
    sys.exit(0 if matches else 1)


def write_records(records, cfg):
    sep = "\0" if cfg.print0 else "\n"
    if records:
        sys.stdout.write(sep.join(records) + sep)


if __name__ == "__main__":
    main()
