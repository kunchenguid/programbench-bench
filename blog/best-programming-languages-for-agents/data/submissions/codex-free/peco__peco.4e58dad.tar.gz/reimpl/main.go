package main

import (
    "bufio"
    "fmt"
    "io"
    "os"
    "strconv"
    "strings"
)

const helpText = `
Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
`

const versionText = "peco version v0.5.11 (built with go1.25.0)\n"

type opts struct {
    query string
    rcfile string
    bufferSize int
    null bool
    initialIndex int
    initialFilter string
    prompt string
    layout string
    select1 bool
    exit0 bool
    selectAll bool
    onCancel string
    selectionPrefix string
    execCmd string
    printQuery bool
    ansi bool
    height string
    version bool
    help bool
    file string
}

func usageErr(msg string) {
    fmt.Fprintln(os.Stderr, msg)
    fmt.Fprint(os.Stderr, helpText)
    fmt.Fprintf(os.Stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: %s\n", msg)
}

func needArg(args []string, i *int, name string) (string, bool) {
    if *i+1 >= len(args) {
        usageErr("expected argument for flag `" + name + "'")
        return "", false
    }
    *i++
    return args[*i], true
}

func parseIntFlag(value, flag string) (int, bool) {
    n, err := strconv.ParseInt(value, 10, 0)
    if err != nil {
        msg := fmt.Sprintf("invalid argument for flag `%s' (expected int): strconv.ParseInt: parsing %q: invalid syntax", flag, value)
        usageErr(msg)
        return 0, false
    }
    return int(n), true
}

func parseArgs(args []string) (opts, bool) {
    o := opts{layout:"top-down", onCancel:"success", prompt:"QUERY>"}
    for i := 0; i < len(args); i++ {
        a := args[i]
        if a == "--" {
            if i+1 < len(args) { o.file = args[i+1] }
            break
        }
        if !strings.HasPrefix(a, "-") || a == "-" {
            if o.file == "" { o.file = a }
            continue
        }
        name, val, hasEq := a, "", false
        if strings.HasPrefix(a, "--") {
            if p := strings.IndexByte(a, '='); p >= 0 { name, val, hasEq = a[:p], a[p+1:], true }
        }
        switch name {
        case "-h", "--help": o.help = true
        case "--version": o.version = true
        case "--query": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--query"); if !ok { return o, false } }; o.query = val
        case "--rcfile": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--rcfile"); if !ok { return o, false } }; o.rcfile = val
        case "-b", "--buffer-size": if !hasEq { var ok bool; val, ok = needArg(args, &i, name); if !ok { return o, false } }; n, ok := parseIntFlag(val, "-b, --buffer-size"); if !ok { return o, false }; o.bufferSize = n
        case "--null": o.null = true
        case "--initial-index": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--initial-index"); if !ok { return o, false } }; n, ok := parseIntFlag(val, "--initial-index"); if !ok { return o, false }; o.initialIndex = n
        case "--initial-filter": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--initial-filter"); if !ok { return o, false } }; o.initialFilter = val
        case "--prompt": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--prompt"); if !ok { return o, false } }; o.prompt = val
        case "--layout": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--layout"); if !ok { return o, false } }; o.layout = val
        case "--select-1": o.select1 = true
        case "--exit-0": o.exit0 = true
        case "--select-all": o.selectAll = true
        case "--on-cancel": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--on-cancel"); if !ok { return o, false } }; o.onCancel = val
        case "--selection-prefix": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--selection-prefix"); if !ok { return o, false } }; o.selectionPrefix = val
        case "--exec": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--exec"); if !ok { return o, false } }; o.execCmd = val
        case "--print-query": o.printQuery = true
        case "--ansi": o.ansi = true
        case "--height": if !hasEq { var ok bool; val, ok = needArg(args, &i, "--height"); if !ok { return o, false } }; o.height = val
        default:
            if strings.HasPrefix(a, "--") { usageErr("unknown flag `" + strings.TrimPrefix(strings.SplitN(a,"=",2)[0], "--") + "'") } else { usageErr("unknown flag `" + strings.TrimPrefix(a, "-") + "'") }
            return o, false
        }
    }
    return o, true
}

func readItems(o opts) ([]string, error) {
    var r io.Reader = os.Stdin
    if o.file != "" {
        f, err := os.Open(o.file)
        if err != nil { return nil, fmt.Errorf("failed to setup input source: failed to open file for input: %w", err) }
        defer f.Close()
        r = f
    }
    b, err := io.ReadAll(r)
    if err != nil { return nil, err }
    if len(b) == 0 { return nil, nil }
    parts := strings.Split(string(b), "\n")
    if len(parts) > 0 && parts[len(parts)-1] == "" { parts = parts[:len(parts)-1] }
    return parts, nil
}

func resultFor(line string, useNull bool) string {
    if useNull {
        if idx := strings.IndexByte(line, 0); idx >= 0 { return line[idx+1:] }
    }
    return line
}

func validate(o opts) bool {
    if o.layout != "" && o.layout != "top-down" && o.layout != "bottom-up" && o.layout != "top-down-query-bottom" {
        fmt.Fprintf(os.Stderr, "Error: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line arguments: unknown layout: '%s'\n", o.layout)
        return false
    }
    if o.onCancel != "success" && o.onCancel != "error" {
        fmt.Fprintf(os.Stderr, "Error: failed to setup peco: failed to apply configuration: invalid --on-cancel value: invalid OnCancel value %q: must be \"success\" or \"error\"\n", o.onCancel)
        return false
    }
    if o.initialFilter != "" {
        switch o.initialFilter { case "IgnoreCase", "CaseSensitive", "SmartCase", "IRegexp", "Regexp", "Fuzzy": default:
            fmt.Fprintln(os.Stderr, "Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found")
            return false
        }
    }
    if o.rcfile != "" {
        if _, err := os.Stat(o.rcfile); err != nil {
            fmt.Fprintf(os.Stderr, "Error: failed to setup peco: failed to setup configuration: failed to read config file: failed to open file %s: %v\n", o.rcfile, err)
            return false
        }
    }
    return true
}

func main() {
    o, ok := parseArgs(os.Args[1:])
    if !ok { os.Exit(1) }
    if o.help { fmt.Print(helpText); return }
    if o.version { fmt.Print(versionText); return }
    if !validate(o) { os.Exit(1) }
    items, err := readItems(o)
    if err != nil { fmt.Fprintf(os.Stderr, "Error: %v\n", err); os.Exit(1) }
    if o.exit0 && len(items) == 0 { os.Exit(1) }
    if o.select1 && len(items) == 1 {
        w := bufio.NewWriter(os.Stdout)
        if o.printQuery { fmt.Fprintln(w, o.query) }
        fmt.Fprintln(w, resultFor(items[0], o.null))
        w.Flush()
        return
    }
    if o.selectAll && len(items) == 0 { return }
    if o.selectAll {
        w := bufio.NewWriter(os.Stdout)
        if o.printQuery { fmt.Fprintln(w, o.query) }
        for _, it := range items { fmt.Fprintln(w, resultFor(it, o.null)) }
        w.Flush()
        return
    }
    if os.Getenv("TERM") == "" {
        fmt.Fprintln(os.Stderr, "Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set")
    } else {
        fmt.Fprintln(os.Stderr, "Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address")
    }
    os.Exit(1)
}
