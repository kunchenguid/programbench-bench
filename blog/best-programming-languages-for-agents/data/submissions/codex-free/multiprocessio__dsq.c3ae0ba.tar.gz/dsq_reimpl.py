#!/usr/bin/env python3
import csv
import io
import json
import os
import re
import shlex
import sqlite3
import sys
import zipfile
import xml.etree.ElementTree as ET


HELP = """dsq (Version latest) - commandline SQL engine for data files

Usage:  dsq [file...] $query
        dsq $file [query]
        cat $file | dsq -s $filetype [query]
        dsq $file -f $queryfile

dsq is a tool for running SQL on one or more data files. It uses
SQLite's SQL dialect. Files as tables are accessible via "{N}" where N
is the 0-based index of the file in the commandline.

The shorthand "{}" is replaced with "{0}".

Examples:

    # This simply dumps the CSV as JSON
    $ dsq test.csv

    # This dumps the first 10 rows of the parquet file as JSON.
    $ dsq data.parquet "SELECT * FROM {} LIMIT 10"

    # This joins two datasets of differing origin types (CSV and JSON).
    $ dsq testdata/join/users.csv testdata/join/ages.json \\
          "select {0}.name, {1}.age from {0} join {1} on {0}.id = {1}.id"

See the repo for more details: https://github.com/multiprocessio/dsq"""


def detect(path, forced=None):
    if forced:
        return forced.lower()
    ext = os.path.splitext(path)[1].lower().lstrip(".")
    aliases = {"txt": "csv", "tab": "tsv", "jsonl": "ndjson", "logfmt": "logfmt"}
    return aliases.get(ext, ext)


def csv_rows(text, delim):
    reader = csv.DictReader(io.StringIO(text), delimiter=delim)
    return [dict(r) for r in reader]


def json_rows(text):
    text = text.strip()
    if not text:
        return []
    try:
        obj = json.loads(text)
        if isinstance(obj, list):
            return [x if isinstance(x, dict) else {"value": x} for x in obj]
        if isinstance(obj, dict):
            return [obj]
        return [{"value": obj}]
    except json.JSONDecodeError:
        rows = []
        for line in text.splitlines():
            if line.strip():
                x = json.loads(line)
                rows.append(x if isinstance(x, dict) else {"value": x})
        return rows


def logfmt_rows(text):
    out = []
    for line in text.splitlines():
        if not line.strip():
            continue
        row = {}
        for tok in shlex.split(line):
            if "=" in tok:
                k, v = tok.split("=", 1)
                row[k] = v
        out.append(row)
    return out


def col_index(cell):
    m = re.match(r"([A-Z]+)", cell or "")
    n = 0
    for ch in (m.group(1) if m else ""):
        n = n * 26 + ord(ch) - 64
    return n - 1


def xlsx_rows(path):
    ns = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
          "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships"}
    with zipfile.ZipFile(path) as z:
        shared = []
        if "xl/sharedStrings.xml" in z.namelist():
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root.findall("m:si", ns):
                shared.append("".join(t.text or "" for t in si.findall(".//m:t", ns)))
        wb = ET.fromstring(z.read("xl/workbook.xml"))
        first = wb.find(".//m:sheets/m:sheet", ns)
        rid = first.attrib.get("{%s}id" % ns["r"]) if first is not None else None
        relroot = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
        target = None
        for rel in relroot:
            if rel.attrib.get("Id") == rid:
                target = rel.attrib.get("Target")
                break
        sheet_path = "xl/" + (target or "worksheets/sheet1.xml").lstrip("/")
        root = ET.fromstring(z.read(sheet_path))
        matrix = []
        for r in root.findall(".//m:sheetData/m:row", ns):
            vals = []
            for c in r.findall("m:c", ns):
                idx = col_index(c.attrib.get("r", ""))
                while len(vals) <= idx:
                    vals.append("")
                t = c.attrib.get("t")
                v = c.find("m:v", ns)
                inline = c.find("m:is", ns)
                if t == "s" and v is not None and v.text is not None:
                    val = shared[int(v.text)]
                elif t == "b" and v is not None and v.text is not None:
                    val = "TRUE" if v.text == "1" else "FALSE"
                elif t == "inlineStr" and inline is not None:
                    val = "".join(x.text or "" for x in inline.findall(".//m:t", ns))
                else:
                    val = v.text if v is not None and v.text is not None else ""
                vals[idx] = val
            matrix.append(vals)
    if not matrix:
        return []
    headers = [str(x) for x in matrix[0]]
    rows = []
    for vals in matrix[1:]:
        row = {}
        for i, h in enumerate(headers):
            row[h] = vals[i] if i < len(vals) else ""
        rows.append(row)
    return rows


def ods_rows(path):
    ns = {
        "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
        "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
        "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
    }
    with zipfile.ZipFile(path) as z:
        root = ET.fromstring(z.read("content.xml"))
    table = root.find(".//table:table", ns)
    matrix = []
    if table is None:
        return []
    for row_el in table.findall("table:table-row", ns):
        rrep = int(row_el.attrib.get("{%s}number-rows-repeated" % ns["table"], "1"))
        vals = []
        for cell in row_el.findall("table:table-cell", ns):
            crep = int(cell.attrib.get("{%s}number-columns-repeated" % ns["table"], "1"))
            vtype = cell.attrib.get("{%s}value-type" % ns["office"])
            if vtype == "boolean":
                val = "TRUE" if cell.attrib.get("{%s}boolean-value" % ns["office"]) == "true" else "FALSE"
            else:
                texts = []
                for p in cell.findall(".//text:p", ns):
                    texts.append("".join(p.itertext()))
                val = "\n".join(texts)
                if not val:
                    val = cell.attrib.get("{%s}value" % ns["office"], "")
            vals.extend([val] * min(crep, 1000))
        for _ in range(min(rrep, 1000)):
            if any(v != "" for v in vals):
                matrix.append(list(vals))
    if not matrix:
        return []
    headers = [str(x) for x in matrix[0]]
    out = []
    for vals in matrix[1:]:
        out.append({h: (vals[i] if i < len(vals) else "") for i, h in enumerate(headers)})
    return out


def read_rows(src, fmt, stdin_text=None):
    if stdin_text is not None:
        text = stdin_text
    else:
        with open(src, "r", encoding="utf-8", errors="replace", newline="") as f:
            text = f.read()
    if fmt == "csv":
        return csv_rows(text, ",")
    if fmt == "tsv":
        return csv_rows(text, "\t")
    if fmt in ("json", "ndjson"):
        return json_rows(text)
    if fmt == "logfmt":
        return logfmt_rows(text)
    if fmt == "xlsx" and stdin_text is None:
        return xlsx_rows(src)
    if fmt == "ods" and stdin_text is None:
        return ods_rows(src)
    raise ValueError(f"Unknown mimetype for file: {src}.")


def all_columns(rows, sort=False):
    cols = []
    seen = set()
    for r in rows:
        for k in r.keys():
            if k not in seen:
                seen.add(k)
                cols.append(k)
    return sorted(cols) if sort else cols


def scalar_kind(v):
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return "number"
    if isinstance(v, list):
        return "array"
    if isinstance(v, dict):
        return "object"
    return "string"


def schema(rows):
    cols = all_columns(rows, sort=False)
    obj = {}
    for c in cols:
        kinds = []
        for r in rows:
            k = scalar_kind(r.get(c))
            if k not in kinds:
                kinds.append(k)
        if len(kinds) == 1:
            obj[c] = {"kind": "scalar", "scalar": kinds[0]}
        else:
            obj[c] = {"kind": "varied", "varied": [{"kind": "scalar", "scalar": k} for k in kinds]}
    return {"kind": "array", "array": {"kind": "object", "object": obj}}


def json_value(v, col_types=None, col=None):
    if col_types and col in col_types and "boolean" in col_types[col] and isinstance(v, int):
        return bool(v)
    if isinstance(v, str):
        if col_types and col in col_types and "boolean" in col_types[col] and v in ("0", "1"):
            return v == "1"
        return v
    return v


def dump_json(rows, col_types=None):
    print("[", end="")
    for i, row in enumerate(rows):
        if i:
            print(",")
        clean = {k: json_value(v, col_types, k) for k, v in row.items()}
        print(json.dumps(clean, separators=(",", ":")), end="")
    print("]")


def make_sqlite(datasets, formats, col_types, text_cols, empty_cols):
    con = sqlite3.connect(":memory:")
    for i, rows in enumerate(datasets):
        cols = all_columns(rows, sort=True)
        if not cols:
            cols = ["value"]
        affinity = "TEXT" if formats[i] in ("xlsx", "ods") else "NUMERIC"
        qcols = [f'"{c}"' for c in cols]
        con.execute(f'create table t{i} ({",".join(c + " " + affinity for c in qcols)})')
        for r in rows:
            vals = []
            for c in cols:
                v = r.get(c)
                if isinstance(v, (dict, list)):
                    v = json.dumps(v, separators=(",", ":"))
                if formats[i] in ("csv", "tsv") and v == "":
                    empty_cols.add(c)
                    v = None
                vals.append(v)
            con.execute(f'insert into t{i} values ({",".join(["?"] * len(cols))})', vals)
        for c in cols:
            kinds = {scalar_kind(r.get(c)) for r in rows}
            col_types[c] = kinds
            if formats[i] in ("csv", "tsv", "logfmt", "xlsx", "ods"):
                text_cols.add(c)
    return con


def rewrite_query(q, nfiles):
    q = q.replace("{}", "{0}")
    for i in range(nfiles):
        q = q.replace("{" + str(i) + "}", f"t{i}")
    return q


def run_query(datasets, formats, query):
    col_types = {}
    text_cols = set()
    empty_cols = set()
    con = make_sqlite(datasets, formats, col_types, text_cols, empty_cols)
    cur = con.execute(rewrite_query(query, len(datasets)))
    names = [d[0] for d in cur.description] if cur.description else []
    rows = []
    for rec in cur.fetchall():
        row = {}
        for k, v in zip(names, rec):
            if v is None and k in empty_cols:
                row[k] = ""
            elif v is not None and k in text_cols:
                row[k] = str(v)
            else:
                row[k] = json_value(v, col_types, k)
        rows.append(row)
    return rows


def pretty(rows):
    cols = all_columns(rows, sort=True)
    widths = {c: len(c) for c in cols}
    for r in rows:
        for c in cols:
            widths[c] = max(widths[c], len("" if r.get(c) is None else str(r.get(c))))
    border = "+" + "+".join("-" * (widths[c] + 2) for c in cols) + "+"
    print(border)
    print("| " + " | ".join(c.ljust(widths[c]) for c in cols) + " |")
    print(border)
    for r in rows:
        cells = []
        for c in cols:
            s = "" if r.get(c) is None else str(r.get(c))
            cells.append(s.rjust(widths[c]) if re.fullmatch(r"-?\d+(\.\d+)?", s) else s.ljust(widths[c]))
        print("| " + " | ".join(cells) + " |")
    print(border)
    print(f"({len(rows)} rows)")


def main(argv):
    if argv and argv[0] in ("--help", "-h"):
        print(HELP)
        return 0
    if argv and argv[0] == "--version":
        print("dsq latest")
        return 0
    pretty_out = False
    schema_out = False
    stdin_fmt = None
    query_file = None
    args = []
    it = iter(range(len(argv)))
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-p", "--pretty"):
            pretty_out = True
        elif a == "--schema":
            schema_out = True
        elif a in ("-s", "--stream"):
            if i + 1 >= len(argv):
                print("Must specify stdin mimetype.", file=sys.stderr)
                return 1
            i += 1
            stdin_fmt = argv[i]
        elif a in ("-f", "--file"):
            if i + 1 >= len(argv):
                print("Must specify query file.", file=sys.stderr)
                return 1
            i += 1
            query_file = argv[i]
        elif a in ("-C", "--cache", "-i", "--interactive"):
            pass
        else:
            args.append(a)
        i += 1

    if not args and not stdin_fmt:
        print("No input files.", file=sys.stderr)
        return 1

    query = None
    files = list(args)
    if query_file:
        with open(query_file, "r", encoding="utf-8") as f:
            query = f.read().strip()
    elif args and (len(args) > 1 or stdin_fmt) and ("select" in args[-1].lower() or "with" in args[-1].lower()):
        query = args[-1]
        files = args[:-1]

    try:
        datasets = []
        formats = []
        if stdin_fmt:
            fmt = detect("stdin", stdin_fmt)
            datasets.append(read_rows("stdin", fmt, sys.stdin.read()))
            formats.append(fmt)
        for f in files:
            fmt = detect(f)
            if fmt not in ("csv", "tsv", "json", "ndjson", "logfmt", "xlsx", "ods"):
                raise ValueError(f"Unknown mimetype for file: {f}.")
            datasets.append(read_rows(f, fmt))
            formats.append(fmt)
    except FileNotFoundError as e:
        print(f"open {e.filename}: no such file or directory", file=sys.stderr)
        return 1
    except Exception as e:
        print(str(e), file=sys.stderr)
        return 1

    if schema_out:
        print(json.dumps(schema(datasets[0] if datasets else []), indent=2))
        return 0
    if query:
        try:
            rows = run_query(datasets, formats, query)
        except Exception as e:
            print(str(e), file=sys.stderr)
            return 1
    else:
        if not datasets:
            print("No input files.", file=sys.stderr)
            return 1
        rows = datasets[0]
    if pretty_out:
        pretty(rows)
    else:
        dump_json(rows)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
