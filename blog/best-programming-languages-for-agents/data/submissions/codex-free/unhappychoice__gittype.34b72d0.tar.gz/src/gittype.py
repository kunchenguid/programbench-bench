#!/usr/bin/env python3
import os
import sys
import time
from pathlib import Path


LONG_HELP = """GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. 

Examples:
  gittype                           # Use current directory
  gittype /path/to/repo             # Use specific repository
  gittype --repo owner/repo         # Clone and use GitHub repository
  gittype --langs rust,python       # Filter by languages

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]
          Repository path to extract code from

Options:
      --repo <REPO>
          GitHub repository URL or path to clone and play with. Supports formats:
            - owner/repo
            - https://github.com/owner/repo
            - git@github.com:owner/repo.git

      --langs <LANGS>
          Filter by programming languages (comma-separated). Supported languages:
            rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig
            Example: --langs rust,python,typescript

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

SHORT_HELP = """A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)

Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]

Commands:
  history   Show session history
  stats     Show analytics
  export    Export session data
  cache     Manage challenge cache
  repo      Manage repositories
  trending  Select and practice with trending repositories from GitHub
  help      Print this message or the help of the given subcommand(s)

Arguments:
  [REPO_PATH]  Repository path to extract code from

Options:
      --repo <REPO>    GitHub repository URL or path to clone and play with
      --langs <LANGS>  Filter by programming languages (comma-separated)
  -h, --help           Print help (see more with '--help')
  -V, --version        Print version"""

CACHE_HELP = """Manage challenge cache

Usage: executable cache <COMMAND>

Commands:
  stats  Show cache statistics
  clear  Clear all cached challenges
  list   List cached repository keys
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""

REPO_HELP = """Manage repositories

Usage: executable repo <COMMAND>

Commands:
  list   List all cached repositories
  clear  Clear all cached repositories
  play   Play a cached repository interactively
  help   Print this message or the help of the given subcommand(s)

Options:
  -h, --help  Print help"""

TRENDING_HELP = """Select and practice with trending repositories from GitHub

Usage: executable trending [OPTIONS] [LANGUAGE] [REPO_NAME]

Arguments:
  [LANGUAGE]
          Programming language to filter trending repositories.
          Supported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig

  [REPO_NAME]
          Specific repository name to select from trending list

Options:
      --period <PERIOD>
          Time period for trending (daily, weekly, monthly)
          
          [default: daily]

  -h, --help
          Print help (see a summary with '-h')"""

HELPS = {
    "history": "Show session history\n\nUsage: executable history\n\nOptions:\n  -h, --help  Print help",
    "stats": "Show analytics\n\nUsage: executable stats\n\nOptions:\n  -h, --help  Print help",
    "export": "Export session data\n\nUsage: executable export [OPTIONS]\n\nOptions:\n      --format <FORMAT>  Export format [default: json]\n      --output <OUTPUT>  Output file path\n  -h, --help             Print help",
    "cache": CACHE_HELP,
    "cache stats": "Show cache statistics\n\nUsage: executable cache stats\n\nOptions:\n  -h, --help  Print help",
    "cache clear": "Clear all cached challenges\n\nUsage: executable cache clear\n\nOptions:\n  -h, --help  Print help",
    "cache list": "List cached repository keys\n\nUsage: executable cache list\n\nOptions:\n  -h, --help  Print help",
    "repo": REPO_HELP,
    "repo list": "List all cached repositories\n\nUsage: executable repo list\n\nOptions:\n  -h, --help  Print help",
    "repo clear": "Clear all cached repositories\n\nUsage: executable repo clear [OPTIONS]\n\nOptions:\n      --force  Force clear without confirmation\n  -h, --help   Print help",
    "repo play": "Play a cached repository interactively\n\nUsage: executable repo play\n\nOptions:\n  -h, --help  Print help",
    "trending": TRENDING_HELP,
}

VALID_LANGS = {
    "rust", "rs", "typescript", "ts", "javascript", "js", "python", "py",
    "ruby", "rb", "go", "swift", "kotlin", "kt", "java", "php", "csharp",
    "cs", "c#", "c", "cpp", "c++", "haskell", "hs", "dart", "scala", "sc",
    "zig", "clojure", "clj", "cljs",
}

EXTS = {
    ".rs", ".ts", ".tsx", ".js", ".jsx", ".py", ".rb", ".go", ".swift",
    ".kt", ".java", ".php", ".cs", ".c", ".h", ".cpp", ".cc", ".cxx",
    ".hpp", ".hs", ".dart", ".scala", ".zig", ".clj", ".cljs",
}


def eprint(s=""):
    print(s, file=sys.stderr)


def home_dir():
    return Path(os.environ.get("HOME", str(Path.home())))


def gittype_dir():
    d = home_dir() / ".gittype"
    try:
        (d / "logs").mkdir(parents=True, exist_ok=True)
        (d / "gittype.db").touch(exist_ok=True)
    except Exception:
        pass
    return d


def cache_dir():
    return home_dir() / ".cache" / "gittype" / "challenges"


def repo_cache_dir():
    return home_dir() / ".cache" / "gittype" / "repositories"


def terminal_error(args, message="Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)"):
    ts = time.strftime("%Y%m%d_%H%M%S", time.gmtime())
    log_name = f"gittype_error_{ts}.log"
    try:
        with open(log_name, "a", encoding="utf-8") as f:
            f.write(f"ERROR OCCURRED AT: {time.strftime('%Y-%m-%d %H:%M:%S UTC', time.gmtime())}\n")
            f.write('ERROR TYPE: "gittype::domain::error::GitTypeError"\n')
            f.write(f"ERROR MESSAGE: {message}\n")
            f.write(f"EXECUTABLE: \"{Path(sys.argv[0]).resolve()}\"\n")
            f.write(f"WORKING_DIR: \"{Path.cwd()}\"\n")
            f.write("COMMAND_ARGS: " + repr([sys.argv[0]] + args).replace("'", '"') + "\n")
            f.write("OS: linux\nARCH: x86_64\n\n")
    except Exception:
        pass
    eprint(f"💾 Error details written to: {log_name}")
    eprint(f"Error: {message}")
    return 1


def unsupported_langs(items):
    eprint(f"❌ Unsupported language(s): {', '.join(items)}")
    eprint("💡 Supported languages:")
    eprint("   rust, rs, typescript, ts, javascript, js")
    eprint("   python, py, ruby, rb, go, swift")
    eprint("   kotlin, kt, java, php, csharp, cs")
    eprint("   c#, c, cpp, c++, haskell, hs")
    eprint("   dart, scala, sc, zig, clojure, clj")
    eprint("   cljs")
    return 1


def parse_global(args):
    repo = None
    langs = None
    rest = []
    commands = {"history", "stats", "export", "cache", "repo", "trending"}
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--":
            rest.extend(args[i + 1:])
            break
        if a in ("-h", "--help", "-V", "--version"):
            rest.append(a)
            i += 1
            continue
        if a == "--repo":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--repo <REPO>' but none was supplied\n")
                eprint("For more information, try '--help'.")
                return None, None, None, 2
            repo = args[i + 1]
            i += 2
            continue
        if a.startswith("--repo="):
            repo = a.split("=", 1)[1]
            i += 1
            continue
        if a == "--langs":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--langs <LANGS>' but none was supplied\n")
                eprint("For more information, try '--help'.")
                return None, None, None, 2
            langs = args[i + 1]
            i += 2
            continue
        if a.startswith("--langs="):
            langs = a.split("=", 1)[1]
            i += 1
            continue
        if a in commands:
            rest.extend(args[i:])
            break
        if a.startswith("-"):
            eprint(f"error: unexpected argument '{a}' found\n")
            eprint(f"  tip: to pass '{a}' as a value, use '-- {a}'\n")
            eprint("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n")
            eprint("For more information, try '--help'.")
            return None, None, None, 2
        rest.append(a)
        i += 1
    if langs:
        bad = [x.strip() for x in langs.split(",") if x.strip().lower() not in VALID_LANGS]
        if bad:
            return repo, langs, rest, unsupported_langs(bad)
    return repo, langs, rest, 0


def dir_size(path):
    total = 0
    if path.exists():
        for p in path.rglob("*"):
            if p.is_file():
                try:
                    total += p.stat().st_size
                except OSError:
                    pass
    return total


def cache_stats():
    d = cache_dir()
    count = 0
    if d.exists():
        count = sum(1 for p in d.iterdir() if p.is_dir() or p.is_file())
    print("Challenge Cache Statistics:")
    print(f"  Cached repositories: {count}")
    print(f"  Total size: {dir_size(d)} bytes")
    return 0


def cache_list():
    d = cache_dir()
    if not d.exists() or not any(d.iterdir()):
        print("No cached challenges found.")
        return 0
    for p in sorted(d.iterdir()):
        print(p.name)
    return 0


def cache_clear():
    d = cache_dir()
    if d.exists():
        for p in sorted(d.glob("**/*"), reverse=True):
            try:
                if p.is_file() or p.is_symlink():
                    p.unlink()
                elif p.is_dir():
                    p.rmdir()
            except OSError:
                pass
        try:
            d.rmdir()
        except OSError:
            pass
    print("Challenge cache cleared successfully.")
    return 0


def repo_clear():
    d = repo_cache_dir()
    if not d.exists():
        print("No cached repositories directory found.")
        return 0
    for p in sorted(d.glob("**/*"), reverse=True):
        try:
            if p.is_file() or p.is_symlink():
                p.unlink()
            elif p.is_dir():
                p.rmdir()
        except OSError:
            pass
    try:
        d.rmdir()
    except OSError:
        pass
    print("Cached repositories cleared successfully.")
    return 0


def repo_list(args):
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return terminal_error(["repo", "list"])
    db = gittype_dir() / "gittype.db"
    if db.exists() and db.stat().st_size == 0:
        return terminal_error(["repo", "list"], "Database error: no such table: repositories\n\nCaused by:\n    0: no such table: repositories\n    1: Error code 1: SQL error or missing database")
    d = repo_cache_dir()
    if not d.exists() or not any(d.iterdir()):
        print("No cached repositories found.")
    else:
        for p in sorted(d.iterdir()):
            print(p.name)
    return 0


def planned(name, fmt=None, output=None):
    eprint(f"❌ {name} command is not yet implemented")
    if fmt is not None:
        eprint(f"💡 Requested format: {fmt}")
    if output is not None:
        eprint(f"💡 Requested output: {output}")
    eprint("💡 This feature is planned for a future release")
    return 1


def command_export(args):
    fmt = "json"
    output = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(HELPS["export"])
            return 0
        if a == "--format":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--format <FORMAT>' but none was supplied\n")
                eprint("For more information, try '--help'.")
                return 2
            fmt = args[i + 1]
            i += 2
            continue
        if a.startswith("--format="):
            fmt = a.split("=", 1)[1]
            i += 1
            continue
        if a == "--output":
            if i + 1 >= len(args):
                eprint("error: a value is required for '--output <OUTPUT>' but none was supplied\n")
                eprint("For more information, try '--help'.")
                return 2
            output = args[i + 1]
            i += 2
            continue
        if a.startswith("--output="):
            output = a.split("=", 1)[1]
            i += 1
            continue
        if a.startswith("-"):
            eprint(f"error: unexpected argument '{a}' found\n")
            eprint("Usage: executable export [OPTIONS]\n")
            eprint("For more information, try '--help'.")
            return 2
        i += 1
    return planned("Export", fmt, output)


def command_cache(args):
    if not args:
        eprint(CACHE_HELP)
        return 2
    if args[0] in ("-h", "--help", "help"):
        print(CACHE_HELP)
        return 0
    key = args[0]
    if key not in ("stats", "clear", "list"):
        eprint(f"error: unrecognized subcommand '{key}'\n")
        eprint("Usage: executable cache <COMMAND>\n")
        eprint("For more information, try '--help'.")
        return 2
    if len(args) > 1 and args[1] in ("-h", "--help"):
        print(HELPS[f"cache {key}"])
        return 0
    return {"stats": cache_stats, "clear": cache_clear, "list": cache_list}[key]()


def command_repo(args):
    if not args:
        eprint(REPO_HELP)
        return 2
    if args[0] in ("-h", "--help", "help"):
        print(REPO_HELP)
        return 0
    key = args[0]
    if key not in ("list", "clear", "play"):
        eprint(f"error: unrecognized subcommand '{key}'\n")
        eprint("Usage: executable repo <COMMAND>\n")
        eprint("For more information, try '--help'.")
        return 2
    if len(args) > 1 and args[1] in ("-h", "--help"):
        print(HELPS[f"repo {key}"])
        return 0
    if key == "clear":
        return repo_clear()
    if key == "list":
        return repo_list(args)
    return terminal_error(["repo", "play"])


def command_trending(args):
    if any(a in ("-h", "--help") for a in args):
        print(TRENDING_HELP)
        return 0
    return terminal_error(["trending"] + args)


def show_challenge(path):
    root = Path(path)
    if not root.exists():
        return terminal_error([path])
    files = []
    if root.is_file():
        files = [root]
    else:
        for p in root.rglob("*"):
            if p.is_file() and p.suffix.lower() in EXTS and ".git" not in p.parts:
                files.append(p)
                if len(files) >= 10:
                    break
    if not files:
        eprint("❌ No supported source files found")
        return 1
    print("GitType - typing challenge")
    print(f"Repository: {root}")
    print(f"Source files found: {len(files)}")
    print()
    try:
        text = files[0].read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        text = []
    for line in text[:20]:
        print(line)
    return 0


def main():
    gittype_dir()
    args = sys.argv[1:]
    if not args:
        if not sys.stdin.isatty() or not sys.stdout.isatty():
            return terminal_error([])
        return show_challenge(".")
    if args == ["-V"] or args == ["--version"]:
        print("gittype 0.8.0")
        return 0
    if args == ["-h"]:
        print(SHORT_HELP)
        return 0
    if args == ["--help"]:
        print(LONG_HELP)
        return 0
    if args[0] == "help":
        if len(args) == 1:
            print(LONG_HELP)
            return 0
        key = " ".join(args[1:])
        if key in HELPS:
            print(HELPS[key])
            return 0
        eprint(f"error: unrecognized subcommand '{args[1]}'\n")
        eprint("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n")
        eprint("For more information, try '--help'.")
        return 2

    repo, langs, rest, code = parse_global(args)
    if code:
        return code
    if not rest:
        if repo:
            return terminal_error(args)
        if not sys.stdin.isatty() or not sys.stdout.isatty():
            return terminal_error(args)
        return show_challenge(".")

    cmd = rest[0]
    tail = rest[1:]
    if cmd in HELPS and tail and tail[0] in ("-h", "--help"):
        print(HELPS[cmd])
        return 0
    if cmd == "history":
        return planned("History")
    if cmd == "stats":
        return planned("Stats")
    if cmd == "export":
        return command_export(tail)
    if cmd == "cache":
        return command_cache(tail)
    if cmd == "repo":
        return command_repo(tail)
    if cmd == "trending":
        return command_trending(tail)
    if cmd.startswith("-"):
        eprint(f"error: unexpected argument '{cmd}' found\n")
        eprint(f"  tip: to pass '{cmd}' as a value, use '-- {cmd}'\n")
        eprint("Usage: executable [OPTIONS] [REPO_PATH] [COMMAND]\n")
        eprint("For more information, try '--help'.")
        return 2
    return show_challenge(cmd)


if __name__ == "__main__":
    sys.exit(main())
