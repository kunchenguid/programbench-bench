#!/usr/bin/env node
'use strict';

const fs = require('fs');
const osmod = require('os');
const path = require('path');
const vm = require('vm');
const child_process = require('child_process');

const VERSION = '2025-09-13';
const HELP = `QuickJS version ${VERSION}
usage: qjs [options] [file [args]]
-h  --help         list options
-e  --eval EXPR    evaluate EXPR
-i  --interactive  go to interactive mode
-m  --module       load as ES6 module (default=autodetect)
    --script       load as ES6 script (default=autodetect)
    --strict       force strict mode
-I  --include file include an additional file
    --std          make 'std' and 'os' available to the loaded script
-T  --trace        trace memory allocation
-d  --dump         dump the memory usage stats
    --memory-limit n  limit the memory usage to 'n' bytes (SI suffixes allowed)
    --stack-size n    limit the stack size to 'n' bytes (SI suffixes allowed)
    --no-unhandled-rejection  ignore unhandled promise rejections
-s                    strip all the debug info
    --strip-source    strip the source code
-q  --quit         just instantiate the interpreter and quit`;

function putsRaw(s) { process.stdout.write(String(s)); }
function println(...args) { console.log(...args); }

globalThis.print = (...args) => console.log(...args);
globalThis.console = console;
globalThis.scriptArgs = [];

function pad(str, width, left, ch) {
  str = String(str);
  if (!width || str.length >= width) return str;
  const p = (ch || ' ').repeat(width - str.length);
  return left ? str + p : p + str;
}

function sprintf(fmt, ...args) {
  let ai = 0;
  return String(fmt).replace(/%([#0 +\-]*)(\d+)?(?:\.(\d+))?([%sdifxXoc])/g, (m, flags, width, prec, type) => {
    if (type === '%') return '%';
    const left = flags.includes('-');
    const zero = flags.includes('0') && !left;
    const w = width ? parseInt(width, 10) : 0;
    const v = args[ai++];
    let out;
    switch (type) {
      case 's': out = String(v); if (prec !== undefined) out = out.slice(0, parseInt(prec, 10)); break;
      case 'd': case 'i': out = String(Math.trunc(Number(v))); break;
      case 'f': out = Number(v).toFixed(prec !== undefined ? parseInt(prec, 10) : 6); break;
      case 'x': out = (Number(v) >>> 0).toString(16); break;
      case 'X': out = (Number(v) >>> 0).toString(16).toUpperCase(); break;
      case 'o': out = (Number(v) >>> 0).toString(8); break;
      case 'c': out = typeof v === 'number' ? String.fromCharCode(v) : String(v)[0] || ''; break;
      default: out = String(v);
    }
    if (zero && /^[+-]/.test(out)) return out[0] + pad(out.slice(1), Math.max(0, w - 1), left, '0');
    return pad(out, w, left, zero ? '0' : ' ');
  });
}

class QJSFile {
  constructor(filePath, mode, fd) {
    this.path = filePath;
    this.mode = mode || 'r';
    this.fd = fd;
    this.closed = false;
    this._lines = null;
    this._lineNo = 0;
  }
  close() { if (!this.closed && this.fd > 2) fs.closeSync(this.fd); this.closed = true; return 0; }
  puts(s) { fs.writeSync(this.fd, String(s)); return 0; }
  printf(fmt, ...args) { fs.writeSync(this.fd, sprintf(fmt, ...args)); return 0; }
  flush() { return 0; }
  tell() { try { return fs.fstatSync(this.fd).size; } catch { return -1; } }
  seek(offset, whence) { return 0; }
  getline() {
    if (this._lines === null) {
      const data = this.fd === 0 ? fs.readFileSync(0, 'utf8') : fs.readFileSync(this.fd, 'utf8');
      this._lines = data.match(/.*(?:\n|$)/g).filter(x => x.length);
    }
    if (this._lineNo >= this._lines.length) return null;
    return this._lines[this._lineNo++];
  }
  readAsString() { return this.fd === 0 ? fs.readFileSync(0, 'utf8') : fs.readFileSync(this.fd, 'utf8'); }
}

function modeToFlag(mode) {
  if (!mode || mode[0] === 'r') return 'r';
  if (mode[0] === 'w') return 'w';
  if (mode[0] === 'a') return 'a';
  return mode;
}

const std = {
  in: new QJSFile('<stdin>', 'r', 0),
  out: new QJSFile('<stdout>', 'w', 1),
  err: new QJSFile('<stderr>', 'w', 2),
  SEEK_SET: 0, SEEK_CUR: 1, SEEK_END: 2,
  Error,
  sprintf,
  printf(fmt, ...args) { process.stdout.write(sprintf(fmt, ...args)); return 0; },
  puts(s) { process.stdout.write(String(s) + '\n'); return 0; },
  open(file, mode) { try { return new QJSFile(file, mode, fs.openSync(file, modeToFlag(mode))); } catch { return null; } },
  popen(cmd, mode) { try { const out = child_process.execSync(cmd, {encoding:'utf8', shell:'/bin/sh'}); return { close(){return 0}, readAsString(){return out}, getline(){ if(!this._l){this._l=out.match(/.*(?:\n|$)/g).filter(x=>x.length);this._i=0;} return this._i<this._l.length?this._l[this._i++]:null; } }; } catch { return null; } },
  tmpfile() { const p = path.join(osmod.tmpdir(), 'qjs-' + process.pid + '-' + Math.random().toString(36).slice(2)); return new QJSFile(p, 'w+', fs.openSync(p, 'w+')); },
  getline() { return std.in.getline(); },
  readFile(file, flags) { const b = fs.readFileSync(file); return flags === 'b' ? b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) : b.toString('utf8'); },
  loadFile(file) { try { return fs.readFileSync(file, 'utf8'); } catch { return null; } },
  strerror(errno) { return 'Error ' + errno; },
  exit(code) { process.exit(code === undefined ? 0 : Number(code)); },
  gc() { if (global.gc) global.gc(); },
  getenv(name) { return Object.prototype.hasOwnProperty.call(process.env, name) ? process.env[name] : undefined; },
  setenv(name, value) { process.env[name] = String(value); return 0; },
  unsetenv(name) { delete process.env[name]; return 0; },
  getenviron() { return {...process.env}; },
  urlGet() { throw new Error('network is disabled'); },
  parseExtJSON(s) { return JSON.parse(String(s)); }
};

function statArray(st) {
  return [{ dev: st.dev, ino: st.ino, mode: st.mode, nlink: st.nlink, uid: st.uid, gid: st.gid, rdev: st.rdev, size: st.size, blocks: st.blocks || 0, atime: st.atimeMs/1000, mtime: st.mtimeMs/1000, ctime: st.ctimeMs/1000 }, 0];
}

const qjsos = {
  platform: process.platform,
  Worker: undefined,
  open(file, flags, mode) { try { return [fs.openSync(file, flags, mode), 0]; } catch (e) { return [-1, e.errno || -1]; } },
  close(fd) { try { fs.closeSync(fd); return 0; } catch (e) { return e.errno || -1; } },
  seek(fd, off, whence) { return [0, 0]; },
  read(fd, buffer, offset, length) { try { const b = Buffer.alloc(length); const n = fs.readSync(fd, b, 0, length, null); if (buffer && buffer.set) buffer.set(b.subarray(0,n), offset || 0); return n; } catch (e) { return e.errno || -1; } },
  write(fd, buffer, offset, length) { try { const b = Buffer.from(buffer); return fs.writeSync(fd, b, offset || 0, length === undefined ? b.length : length); } catch (e) { return e.errno || -1; } },
  isatty(fd) { return fd === 0 ? process.stdin.isTTY : fd === 1 ? process.stdout.isTTY : fd === 2 ? process.stderr.isTTY : false; },
  ttyGetWinSize() { return [process.stdout.columns || 80, process.stdout.rows || 25]; },
  ttySetRaw(fd, raw) { if (fd === 0 && process.stdin.setRawMode) process.stdin.setRawMode(!!raw); return 0; },
  remove(p) { try { fs.rmSync(p); return 0; } catch (e) { return e.errno || -1; } },
  rename(a,b) { try { fs.renameSync(a,b); return 0; } catch (e) { return e.errno || -1; } },
  realpath(p) { try { return [fs.realpathSync(p), 0]; } catch (e) { return [null, e.errno || -1]; } },
  getcwd() { try { return [process.cwd(), 0]; } catch (e) { return [null, e.errno || -1]; } },
  chdir(p) { try { process.chdir(p); return 0; } catch (e) { return e.errno || -1; } },
  mkdir(p, mode) { try { fs.mkdirSync(p, {mode}); return 0; } catch (e) { return e.errno || -1; } },
  stat(p) { try { return statArray(fs.statSync(p)); } catch (e) { return [null, e.errno || -1]; } },
  lstat(p) { try { return statArray(fs.lstatSync(p)); } catch (e) { return [null, e.errno || -1]; } },
  utimes(p, a, m) { try { fs.utimesSync(p, a, m); return 0; } catch (e) { return e.errno || -1; } },
  symlink(t,p) { try { fs.symlinkSync(t,p); return 0; } catch (e) { return e.errno || -1; } },
  readlink(p) { try { return [fs.readlinkSync(p), 0]; } catch (e) { return [null, e.errno || -1]; } },
  readdir(p) { try { return [fs.readdirSync(p), 0]; } catch (e) { return [null, e.errno || -1]; } },
  setReadHandler() {}, setWriteHandler() {}, signal() {},
  exec(args, opts) { try { const r = child_process.spawnSync(args[0], args.slice(1), {stdio: opts && opts.block === false ? 'ignore' : 'inherit'}); return r.status || 0; } catch (e) { return -1; } },
  waitpid() { return [0, 0]; },
  pipe() { return [-1, -1]; },
  kill(pid, sig) { try { process.kill(pid, sig); return 0; } catch (e) { return e.errno || -1; } },
  sleep(ms) { const end = Date.now() + Number(ms); while (Date.now() < end) {} },
  setTimeout: global.setTimeout.bind(global),
  clearTimeout: global.clearTimeout.bind(global)
};

globalThis.std = std;
globalThis.os = qjsos;

function transformModule(code) {
  code = code.replace(/import\s+\*\s+as\s+(\w+)\s+from\s+['"]std['"]\s*;?/g, 'const $1 = globalThis.std;');
  code = code.replace(/import\s+\*\s+as\s+(\w+)\s+from\s+['"]os['"]\s*;?/g, 'const $1 = globalThis.os;');
  code = code.replace(/import\s+\{([^}]+)\}\s+from\s+['"]std['"]\s*;?/g, 'const {$1} = globalThis.std;');
  code = code.replace(/import\s+\{([^}]+)\}\s+from\s+['"]os['"]\s*;?/g, 'const {$1} = globalThis.os;');
  code = code.replace(/import\s+(\w+)\s+from\s+['"]std['"]\s*;?/g, 'const $1 = globalThis.std;');
  code = code.replace(/import\s+(\w+)\s+from\s+['"]os['"]\s*;?/g, 'const $1 = globalThis.os;');
  code = code.replace(/import\s*\(\s*['"]std['"]\s*\)/g, 'Promise.resolve(globalThis.std)');
  code = code.replace(/import\s*\(\s*['"]os['"]\s*\)/g, 'Promise.resolve(globalThis.os)');
  code = code.replace(/export\s+default\s+/g, '');
  code = code.replace(/export\s+(?=(async\s+)?function|class|const|let|var)/g, '');
  code = code.replace(/export\s*\{[^}]*\}\s*;?/g, '');
  return code;
}

function cleanStack(e) {
  if (!e || !e.stack) return String(e);
  const first = e.name ? `${e.name}: ${e.message}` : String(e);
  const lines = String(e.stack).split('\n');
  const useful = lines.filter(l =>
    /<cmdline>|<eval>|\.js:|\(.*\.js:/.test(l) &&
    !/\/workspace\/executable|\/workspace\/src\/qjs_shim/.test(l));
  return [first, ...useful.slice(0, 8)].join('\n');
}

function runCode(code, filename, asModule, strict) {
  let src = String(code);
  if (asModule || /(^|\n)\s*import\s/m.test(src) || /(^|\n)\s*export\s/m.test(src)) src = transformModule(src);
  if (strict) src = '"use strict";\n' + src;
  return vm.runInThisContext(src, {filename: filename || '<eval>', displayErrors: false});
}

function usageError(opt) {
  console.error(`qjs: unknown option '${opt}'`);
  console.error(HELP);
  process.exit(1);
}
function missing(opt) { console.error(`qjs: missing argument for '${opt}'`); process.exit(1); }

async function main() {
  const args = process.argv.slice(2);
  let evals = [], includes = [], interactive = false, asModule = false, forceScript = false, strict = false, dump = false, quit = false;
  let file = null, fileArgs = [];
  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (a === '-h' || a === '--help') { console.log(HELP); return; }
    else if (a === '-e' || a === '--eval') { if (++i >= args.length) missing(a); evals.push(args[i]); }
    else if (a === '-I' || a === '--include') { if (++i >= args.length) missing(a); includes.push(args[i]); }
    else if (a === '-i' || a === '--interactive') interactive = true;
    else if (a === '-m' || a === '--module') asModule = true;
    else if (a === '--script') forceScript = true;
    else if (a === '--strict') strict = true;
    else if (a === '--std') {}
    else if (a === '-T' || a === '--trace' || a === '-s' || a === '--strip-source' || a === '--no-unhandled-rejection') {}
    else if (a === '-d' || a === '--dump') dump = true;
    else if (a === '-q' || a === '--quit') quit = true;
    else if (a === '--memory-limit' || a === '--stack-size') { if (++i >= args.length) missing(a); }
    else if (a.startsWith('-') && a !== '-') usageError(a);
    else {
      if (evals.length) {
        fileArgs = args.slice(i);
      } else {
        file = a;
        fileArgs = args.slice(i + 1);
      }
      break;
    }
  }
  if (quit) return;
  globalThis.scriptArgs = file ? [file, ...fileArgs] : fileArgs;
  for (const inc of includes) runCode(fs.readFileSync(inc, 'utf8'), inc, asModule && !forceScript, strict);
  for (const e of evals) runCode(e, '<cmdline>', asModule && !forceScript, strict);
  if (file) {
    let code;
    try {
      code = fs.readFileSync(file, 'utf8');
    } catch (e) {
      console.error(`${file}: No such file or directory`);
      process.exit(1);
    }
    runCode(code, file, (asModule || (!forceScript && /\.mjs$/i.test(file))), strict);
  } else if (!evals.length || interactive) {
    const repl = require('repl');
    repl.start({prompt: 'qjs > ', useColors: true, ignoreUndefined: false});
    return;
  }
  if (dump) console.error('QuickJS memory usage -- unavailable in compatibility build');
}

main().catch(e => {
  console.error(cleanStack(e).replace(/evalmachine\.<anonymous>/g, '<eval>'));
  process.exit(1);
});
