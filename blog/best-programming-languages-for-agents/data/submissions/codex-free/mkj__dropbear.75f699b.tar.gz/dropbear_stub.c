#define _GNU_SOURCE
#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define VERSION "2025.89"
#define MAX_LISTEN 10

typedef struct {
    char *host;
    char *port;
    char *shown;
} ListenSpec;

static ListenSpec listens[MAX_LISTEN];
static int listen_count = 0;
static const char *hostkeys[64];
static int hostkey_count = 0;
static bool make_keys = false;
static bool foreground = false;
static const char *pidfile = "/var/run/dropbear.pid";
static const char *iface = NULL;

static void timestamp(char *buf, size_t n) {
    time_t t = time(NULL);
    struct tm tmv;
    localtime_r(&t, &tmv);
    strftime(buf, n, "%b %e %H:%M:%S", &tmv);
}

static void logmsg(const char *fmt, ...) {
    char ts[64];
    timestamp(ts, sizeof(ts));
    fprintf(stderr, "[%ld] %s ", (long)getpid(), ts);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    fflush(stderr);
}

static void early_exit(const char *fmt, ...) {
    char ts[64];
    timestamp(ts, sizeof(ts));
    fprintf(stderr, "[%ld] %s Early exit: ", (long)getpid(), ts);
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static void usage(void) {
    printf("Dropbear server v%s https://matt.ucc.asn.au/dropbear/dropbear.html\n", VERSION);
    printf("Usage: ./executable [options]\n");
    printf("-b bannerfile\tDisplay the contents of bannerfile before user login\n");
    printf("\t\t(default: none)\n");
    printf("-r keyfile      Specify hostkeys (repeatable)\n");
    printf("\t\tdefaults: \n");
    printf("\t\t- rsa /etc/dropbear/dropbear_rsa_host_key\n");
    printf("\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key\n");
    printf("\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key\n");
    printf("-D\t\tDirectory containing authorized_keys file\n");
    printf("-R\t\tCreate hostkeys as required\n");
    printf("-F\t\tDon't fork into background\n");
    printf("-e\t\tPass on server process environment to child process\n");
    printf("(Syslog support not compiled in, using stderr)\n");
    printf("-m\t\tDon't display the motd on login\n");
    printf("-w\t\tDisallow root logins\n");
    printf("-G\t\tRestrict logins to members of specified group\n");
    printf("-s\t\tDisable password logins\n");
    printf("-g\t\tDisable password logins for root\n");
    printf("-B\t\tAllow blank password logins\n");
    printf("-t\t\tEnable two-factor authentication (both password and public key required)\n");
    printf("-T\t\tMaximum authentication tries (default 10)\n");
    printf("-j\t\tDisable local port forwarding\n");
    printf("-k\t\tDisable remote port forwarding\n");
    printf("-a\t\tAllow connections to forwarded ports from any host\n");
    printf("-c command\tForce executed command\n");
    printf("-p [address:]port\n");
    printf("\t\tListen on specified tcp port (and optionally address),\n");
    printf("\t\tup to 10 can be specified\n");
    printf("\t\t(default port is 22 if none specified)\n");
    printf("-P PidFile\tCreate pid file PidFile\n");
    printf("\t\t(default /var/run/dropbear.pid)\n");
    printf("-l <interface>\n");
    printf("\t\tinterface to bind on\n");
    printf("-i\t\tStart for inetd\n");
    printf("-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)\n");
    printf("-K <keepalive>  (0 is never, default 0, in seconds)\n");
    printf("-I <idle_timeout>  (0 is never, default 0, in seconds)\n");
    printf("-z    disable QoS\n");
    printf("-V    Version\n");
}

static bool nonneg_int(const char *s) {
    if (!s || !*s) return false;
    for (const char *p = s; *p; p++) {
        if (*p < '0' || *p > '9') return false;
    }
    return true;
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) exit(2);
    return r;
}

static void add_listen(const char *arg) {
    if (listen_count >= MAX_LISTEN) return;
    ListenSpec *ls = &listens[listen_count++];
    ls->shown = xstrdup(arg);
    char *tmp = xstrdup(arg);
    char *colon = strrchr(tmp, ':');
    if (colon && colon != tmp) {
        *colon = '\0';
        ls->host = xstrdup(tmp);
        ls->port = xstrdup(colon + 1);
    } else {
        ls->host = NULL;
        ls->port = xstrdup(arg);
    }
    free(tmp);
}

static int bind_one(ListenSpec *ls) {
    const char *port = ls->port ? ls->port : "22";
    char pbuf[16];
    if (nonneg_int(port)) {
        unsigned long v = strtoul(port, NULL, 10);
        snprintf(pbuf, sizeof(pbuf), "%u", (unsigned)(v & 0xffff));
        port = pbuf;
    }

    struct addrinfo hints;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    struct addrinfo *res = NULL;
    int gai = getaddrinfo(ls->host, port, &hints, &res);
    if (gai != 0) {
        const char *reason = gai_strerror(gai);
        if (strstr(reason, "Temporary failure")) reason = "Error resolving: Temporary failure in name resolution";
        else if (strstr(reason, "Name or service not known")) reason = "Error resolving: Temporary failure in name resolution";
        else if (strstr(reason, "Servname")) reason = "Error resolving: Servname not supported for ai_socktype";
        logmsg("Failed listening on '%s': %s", ls->port, reason);
        return -1;
    }

    int fd = -1;
    for (struct addrinfo *ai = res; ai; ai = ai->ai_next) {
        fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) continue;
        int one = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
        if (bind(fd, ai->ai_addr, ai->ai_addrlen) == 0 && listen(fd, 20) == 0) {
            freeaddrinfo(res);
            return fd;
        }
        close(fd);
        fd = -1;
    }
    freeaddrinfo(res);
    logmsg("Failed listening on '%s': %s", ls->port, strerror(errno));
    return -1;
}

static void on_signal(int sig) {
    (void)sig;
    logmsg("Early exit: Terminated by signal");
    _exit(1);
}

static void handle_client(int cfd, struct sockaddr_storage *ss, socklen_t slen) {
    char host[NI_MAXHOST] = "unknown";
    char serv[NI_MAXSERV] = "0";
    getnameinfo((struct sockaddr *)ss, slen, host, sizeof(host), serv, sizeof(serv),
                NI_NUMERICHOST | NI_NUMERICSERV);
    logmsg("Child connection from %s:%s", host, serv);
    const char *banner = "SSH-2.0-dropbear_2025.89\r\n";
    ssize_t wr = write(cfd, banner, strlen(banner));
    char buf[256];
    ssize_t rd = read(cfd, buf, sizeof(buf));
    (void)wr;
    (void)rd;
    close(cfd);
    logmsg("Exit before auth from <%s:%s>: Exited normally", host, serv);
    _exit(0);
}

static void server_loop(int *fds, int nfds) {
    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    signal(SIGCHLD, SIG_IGN);
    if (iface) logmsg("Binding to interface '%s'", iface);
    if (foreground) logmsg("Not backgrounding");
    FILE *pf = fopen(pidfile, "w");
    if (pf) {
        fprintf(pf, "%ld\n", (long)getpid());
        fclose(pf);
    }
    while (1) {
        fd_set rfds;
        FD_ZERO(&rfds);
        int maxfd = -1;
        for (int i = 0; i < nfds; i++) {
            FD_SET(fds[i], &rfds);
            if (fds[i] > maxfd) maxfd = fds[i];
        }
        if (select(maxfd + 1, &rfds, NULL, NULL, NULL) < 0) {
            if (errno == EINTR) continue;
            early_exit("%s", strerror(errno));
        }
        for (int i = 0; i < nfds; i++) {
            if (!FD_ISSET(fds[i], &rfds)) continue;
            struct sockaddr_storage ss;
            socklen_t slen = sizeof(ss);
            int cfd = accept(fds[i], (struct sockaddr *)&ss, &slen);
            if (cfd < 0) continue;
            pid_t pid = fork();
            if (pid == 0) {
                for (int j = 0; j < nfds; j++) close(fds[j]);
                handle_client(cfd, &ss, slen);
            }
            close(cfd);
        }
    }
}

int main(int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (a[0] != '-') early_exit("Invalid argument: %s", a);
        if (strcmp(a, "-V") == 0) {
            printf("Dropbear v%s\n", VERSION);
            return 0;
        }
        if (strcmp(a, "--help") == 0) {
            printf("Invalid option --\n");
            usage();
            return 1;
        }
        if (strncmp(a, "--", 2) == 0) {
            printf("Invalid option --\n");
            usage();
            return 1;
        }
        if (strlen(a) != 2) {
            printf("Invalid option %s\n", a);
            usage();
            return 1;
        }
        char o = a[1];
        switch (o) {
        case 'b': case 'D': case 'G': case 'c': case 'P': case 'l':
        case 'p': case 'r': case 'T': case 'W': case 'K': case 'I':
            if (++i >= argc) early_exit("Missing argument");
            if (o == 'p') add_listen(argv[i]);
            else if (o == 'r' && hostkey_count < 64) hostkeys[hostkey_count++] = argv[i];
            else if (o == 'P') pidfile = argv[i];
            else if (o == 'l') iface = argv[i];
            else if (o == 'T' && !nonneg_int(argv[i])) early_exit("Bad maxauthtries '%s'", argv[i]);
            else if (o == 'K' && !nonneg_int(argv[i])) early_exit("Bad keepalive '%s'", argv[i]);
            else if (o == 'I' && !nonneg_int(argv[i])) early_exit("Bad idle_timeout '%s'", argv[i]);
            else if (o == 'W') {
                long v = nonneg_int(argv[i]) ? strtol(argv[i], NULL, 10) : -1;
                if (v < 0) logmsg("Bad recv window '%s', using 24576", argv[i]);
                else if (v > 10485760) logmsg("Bad recv window '%s', using 10485760", argv[i]);
            }
            break;
        case 'R': make_keys = true; break;
        case 'F': foreground = true; break;
        case 'e': case 'm': case 'w': case 's': case 'g': case 'B':
        case 't': case 'j': case 'k': case 'a': case 'i': case 'z':
            break;
        default:
            printf("Invalid option -%c\n", o);
            usage();
            return 1;
        }
    }

    if (listen_count == 0) add_listen("22");

    if (!make_keys) {
        if (hostkey_count == 0) {
            const char *defs[] = {
                "/etc/dropbear/dropbear_rsa_host_key",
                "/etc/dropbear/dropbear_ecdsa_host_key",
                "/etc/dropbear/dropbear_ed25519_host_key"
            };
            for (size_t i = 0; i < sizeof(defs)/sizeof(defs[0]); i++) logmsg("Failed loading %s", defs[i]);
        } else {
            for (int i = 0; i < hostkey_count; i++) {
                if (access(hostkeys[i], R_OK) == 0) early_exit("Bad buf_getptr");
                logmsg("Failed loading %s", hostkeys[i]);
            }
        }
        early_exit("No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
    }

    int fds[MAX_LISTEN];
    int nfds = 0;
    for (int i = 0; i < listen_count; i++) {
        int fd = bind_one(&listens[i]);
        if (fd >= 0) fds[nfds++] = fd;
    }
    if (nfds == 0) early_exit("No listening ports available.");

    if (!foreground) {
        pid_t pid = fork();
        if (pid < 0) early_exit("fork: %s", strerror(errno));
        if (pid > 0) return 0;
        setsid();
    }
    server_loop(fds, nfds);
    return 0;
}
