#!/usr/bin/env python3
import difflib
import json
import os
import re
import sys
from pathlib import Path

VERSION = "ast-grep 0.42.1"

LANGS = {
    "js": "JavaScript", "javascript": "JavaScript", "jsx": "JavaScript",
    "ts": "TypeScript", "typescript": "TypeScript", "tsx": "Tsx",
    "py": "Python", "python": "Python", "rs": "Rust", "rust": "Rust",
    "go": "Go", "java": "Java", "c": "C", "cpp": "Cpp", "cc": "Cpp",
    "cxx": "Cpp", "h": "C", "hpp": "Cpp", "rb": "Ruby", "ruby": "Ruby",
    "php": "Php", "cs": "CSharp", "css": "Css", "html": "Html",
    "json": "Json", "yaml": "Yaml", "yml": "Yaml", "bash": "Bash",
    "sh": "Bash", "lua": "Lua", "swift": "Swift", "kt": "Kotlin",
}

EXT_LANG = {
    ".js": "JavaScript", ".jsx": "JavaScript", ".ts": "TypeScript",
    ".tsx": "Tsx", ".py": "Python", ".rs": "Rust", ".go": "Go",
    ".java": "Java", ".c": "C", ".h": "C", ".cc": "Cpp", ".cpp": "Cpp",
    ".cxx": "Cpp", ".hpp": "Cpp", ".rb": "Ruby", ".php": "Php",
    ".cs": "CSharp", ".css": "Css", ".html": "Html", ".json": "Json",
    ".yaml": "Yaml", ".yml": "Yaml", ".sh": "Bash", ".lua": "Lua",
    ".swift": "Swift", ".kt": "Kotlin",
}

TOP_HELP = """Search and Rewrite code at large scale using AST pattern.
                    __
        ____ ______/ /_      ____ _________  ____
       / __ `/ ___/ __/_____/ __ `/ ___/ _ \\/ __ \\
      / /_/ (__  ) /_/_____/ /_/ / /  /  __/ /_/ /
      \\__,_/____/\\__/      \\__, /_/   \\___/ .___/
                          /____/         /_/


Usage: executable [OPTIONS] <COMMAND>

Commands:
  run          Run one time search or rewrite in command line. (default command)
  scan         Scan and rewrite code by configuration
  test         Test ast-grep rules
  new          Create new ast-grep project or items like rules/tests
  lsp          Start language server
  completions  Generate shell completion script
  help         Print this message or the help of the given subcommand(s)

Options:
  -c, --config <CONFIG_FILE>
          Path to ast-grep root config, default is sgconfig.yml

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version"""

RUN_HELP = """Run one time search or rewrite in command line. (default command)

Usage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...

Arguments:
  [PATHS]...          The paths to search. [default: .]

Options:
  -p, --pattern <PATTERN>      AST pattern to match
  -r, --rewrite <FIX>          String to replace the matched AST node
  -l, --lang <LANG>            The language of the pattern
      --stdin                  Enable search code from StdIn
      --files-with-matches     Print only the paths with at least one match
      --json[=<STYLE>]         Output matches in structured JSON
  -U, --update-all             Apply all rewrite without confirmation if true
  -A, --after <NUM>            Show NUM lines after each match
  -B, --before <NUM>           Show NUM lines before each match
  -C, --context <NUM>          Show NUM lines around each match
  -h, --help                   Print help"""

SCAN_HELP = """Scan and rewrite code by configuration

Usage: executable scan [OPTIONS] [PATHS]...

Options:
  -r, --rule <RULE_FILE>        Scan the codebase with the single rule
      --inline-rules <TEXT>     Scan with YAML rule text
      --format <FORMAT>         Supported formats: github, sarif
      --json[=<STYLE>]          Output matches in structured JSON
  -U, --update-all              Apply all rewrite without confirmation if true
      --files-with-matches      Print only the paths with at least one match
  -h, --help                    Print help"""

NEW_HELP = """Create new ast-grep project or items like rules/tests

Usage: executable new [OPTIONS] [NAME] [COMMAND]

Commands:
  project  Create an new project by scaffolding
  rule     Create a new rule
  test     Create a new test case
  util     Create a new global utility rule
  help     Print this message or the help of the given subcommand(s)

Arguments:
  [NAME]          The id of the item to create

Options:
  -l, --lang <LANG>          The language of the item to create.
  -y, --yes                 Accept all default options without interactive input
  -c, --config <CONFIG_FILE> Path to ast-grep root config, default is sgconfig.yml
  -h, --help                Print help"""


def eprint(*args):
    print(*args, file=sys.stderr)


def parse_opts(argv):
    opts, pos = {}, []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos.extend(argv[i + 1:])
            break
        if a.startswith("--"):
            if "=" in a:
                k, v = a[2:].split("=", 1)
                opts.setdefault(k, []).append(v)
            else:
                k = a[2:]
                if k in {"help", "version", "stdin", "files-with-matches", "update-all", "interactive", "yes", "skip-snapshot-tests", "include-off"}:
                    opts.setdefault(k, []).append(True)
                elif k in {"json", "error", "warning", "info", "hint", "off"}:
                    opts.setdefault(k, []).append("")
                else:
                    if i + 1 >= len(argv) or argv[i + 1].startswith("-"):
                        eprint(f"error: a value is required for '--{k}' but none was supplied\n\nFor more information, try '--help'.")
                        sys.exit(2)
                    opts.setdefault(k, []).append(argv[i + 1])
                    i += 1
        elif a.startswith("-") and a != "-":
            shorts = a[1:]
            if len(shorts) > 1 and shorts[0] not in "p r l c A B C j t f".split():
                for ch in shorts:
                    opts.setdefault(short_name(ch), []).append(True)
            else:
                ch = shorts[0]
                name = short_name(ch)
                if ch in "hVUi y".replace(" ", ""):
                    opts.setdefault(name, []).append(True)
                else:
                    if i + 1 >= len(argv):
                        eprint(f"error: a value is required for '-{ch}' but none was supplied\n\nFor more information, try '--help'.")
                        sys.exit(2)
                    opts.setdefault(name, []).append(argv[i + 1])
                    i += 1
        else:
            pos.append(a)
        i += 1
    return opts, pos


def short_name(ch):
    return {
        "p": "pattern", "r": "rewrite_or_rule", "l": "lang", "c": "config",
        "h": "help", "V": "version", "U": "update-all", "i": "interactive",
        "A": "after", "B": "before", "C": "context", "j": "threads",
        "t": "test-dir", "f": "filter", "y": "yes",
    }.get(ch, ch)


def lang_name(s):
    if not s:
        return None
    return LANGS.get(s.lower(), s[:1].upper() + s[1:])


def infer_lang(path, explicit=None):
    return lang_name(explicit) or EXT_LANG.get(Path(path).suffix.lower(), "Unknown")


def pattern_regex(pattern):
    parts, names = [], []
    i = 0
    while i < len(pattern):
        c = pattern[i]
        if c == "$":
            m = re.match(r"\$([A-Z_][A-Z0-9_]*)", pattern[i:])
            if m:
                name = m.group(1)
                if name in names:
                    parts.append(f"(?P={name})")
                else:
                    names.append(name)
                    if not pattern[i + len(m.group(0)):].strip():
                        parts.append(f"(?P<{name}>[^;\\n]+);?")
                    else:
                        parts.append(f"(?P<{name}>.+?)")
                i += len(m.group(0))
                continue
        if c.isspace():
            while i < len(pattern) and pattern[i].isspace():
                i += 1
            parts.append(r"\s+")
            continue
        parts.append(re.escape(c))
        i += 1
    rx = "".join(parts)
    return re.compile(rx, re.S), names


def line_col(text, off):
    line = text.count("\n", 0, off)
    last = text.rfind("\n", 0, off)
    col = off if last < 0 else off - last - 1
    return line, col


def line_text(text, start, end):
    ls = text.rfind("\n", 0, start) + 1
    le = text.find("\n", end)
    if le < 0:
        le = len(text)
    return text[ls:le]


def build_match(text, m, file, lang, names, replacement=None, rule=None):
    s, e = m.span()
    sl, sc = line_col(text, s)
    el, ec = line_col(text, e)
    line = line_text(text, s, e)
    leading = len(line) - len(line.lstrip(" \t"))
    trailing = len(line) - len(line.rstrip(" \t"))
    obj = {
        "text": m.group(0),
        "range": {"byteOffset": {"start": s, "end": e}, "start": {"line": sl, "column": sc}, "end": {"line": el, "column": ec}},
        "file": file,
        "lines": line,
        "charCount": {"leading": leading, "trailing": trailing},
        "language": lang,
        "metaVariables": {"single": {}, "multi": {}, "transformed": {}},
    }
    for n in names:
        try:
            gs, ge = m.span(n)
            val = m.group(n)
        except IndexError:
            continue
        gsl, gsc = line_col(text, gs)
        gel, gec = line_col(text, ge)
        obj["metaVariables"]["single"][n] = {
            "text": val,
            "range": {"byteOffset": {"start": gs, "end": ge}, "start": {"line": gsl, "column": gsc}, "end": {"line": gel, "column": gec}},
        }
    if replacement is not None:
        obj["replacement"] = replacement
        obj["replacementOffsets"] = {"start": s, "end": e}
    if rule:
        obj.update({
            "ruleId": rule.get("id", ""),
            "severity": rule.get("severity", "warning"),
            "note": rule.get("note"),
            "message": rule.get("message", ""),
            "labels": [{"text": m.group(0), "range": obj["range"], "style": "primary"}],
        })
    return obj


def render_rewrite(template, match_obj):
    out = template
    for k, v in match_obj["metaVariables"]["single"].items():
        out = out.replace("$" + k, v["text"])
    return out


def iter_files(paths, no_hidden=True):
    for p in paths or ["."]:
        path = Path(p)
        if path.is_file():
            yield str(path)
        elif path.is_dir():
            for root, dirs, files in os.walk(path):
                if no_hidden:
                    dirs[:] = [d for d in dirs if not d.startswith(".")]
                    files = [f for f in files if not f.startswith(".")]
                for f in sorted(files):
                    yield str(Path(root) / f)


def collect(pattern, paths, lang=None, stdin=False, rewrite=None, rule=None):
    rx, names = pattern_regex(pattern)
    out = []
    if stdin:
        text = sys.stdin.read()
        for m in rx.finditer(text):
            obj = build_match(text, m, "STDIN", infer_lang("STDIN", lang), names)
            rep = render_rewrite(rewrite, obj) if rewrite else None
            out.append((None, text, m, build_match(text, m, "STDIN", infer_lang("STDIN", lang), names, rep, rule)))
        return out
    for f in iter_files(paths):
        try:
            text = Path(f).read_text(errors="replace")
        except Exception:
            continue
        flang = infer_lang(f, lang)
        for m in rx.finditer(text):
            obj = build_match(text, m, f, flang, names)
            rep = render_rewrite(rewrite, obj) if rewrite else None
            out.append((f, text, m, build_match(text, m, f, flang, names, rep, rule)))
    return out


def print_json(matches, style):
    arr = [x[3] for x in matches]
    if style == "stream":
        for o in arr:
            print(json.dumps(o, separators=(",", ":")))
    elif style == "compact":
        print(json.dumps(arr, separators=(",", ":")))
    else:
        print(json.dumps(arr, indent=2))


def apply_updates(matches):
    by_file = {}
    for f, text, m, obj in matches:
        if f and "replacement" in obj:
            by_file.setdefault(f, [text, []])[1].append((m.start(), m.end(), obj["replacement"]))
    total = 0
    for f, (text, reps) in by_file.items():
        for s, e, r in sorted(reps, reverse=True):
            text = text[:s] + r + text[e:]
            total += 1
        Path(f).write_text(text)
    print(f"Applied {total} changes")


def show_diff(f, old, new):
    print(f)
    old_lines = old.splitlines(True)
    new_lines = new.splitlines(True)
    for line in difflib.unified_diff(old_lines, new_lines, fromfile="", tofile="", lineterm=""):
        if line.startswith("---") or line.startswith("+++"):
            continue
        print(line.rstrip("\n"))


def run_cmd(argv):
    opts, paths = parse_opts(argv)
    if opts.get("help"):
        print(RUN_HELP)
        return 0
    pattern = last(opts, "pattern")
    if not pattern:
        eprint("error: the following required arguments were not provided:\n  --pattern <PATTERN>\n\nUsage: executable run --pattern <PATTERN> [PATHS]...\n\nFor more information, try '--help'.")
        return 2
    rewrite = last(opts, "rewrite") or last(opts, "rewrite_or_rule")
    matches = collect(pattern, paths or ["."], last(opts, "lang"), bool(opts.get("stdin")), rewrite)
    if opts.get("json") is not None:
        print_json(matches, (last(opts, "json") or "pretty"))
    elif opts.get("files-with-matches"):
        for f in sorted({x[3]["file"] for x in matches}):
            print(f)
    elif opts.get("update-all") and rewrite:
        apply_updates(matches)
    elif rewrite:
        by = {}
        for f, text, m, obj in matches:
            if not f:
                continue
            by.setdefault(f, [text, []])[1].append((m.start(), m.end(), obj["replacement"]))
        for f, (text, reps) in by.items():
            new = text
            for s, e, r in sorted(reps, reverse=True):
                new = new[:s] + r + new[e:]
            show_diff(f, text, new)
    else:
        for _, _, _, obj in matches:
            print(f"{obj['file']}:{obj['range']['start']['line'] + 1}:{obj['lines']}")
    return 0 if matches else 1


def last(opts, key):
    v = opts.get(key)
    return v[-1] if v else None


def parse_rule_text(txt):
    d, in_rule = {}, False
    for raw in txt.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip())
        line = raw.strip()
        if line == "rule:":
            in_rule = True
            continue
        if ":" in line:
            k, v = line.split(":", 1)
            v = v.strip().strip("'\"")
            if in_rule and indent > 0:
                d["rule_" + k.strip()] = v
            else:
                in_rule = False
                d[k.strip()] = v
    return d


def scan_cmd(argv):
    opts, paths = parse_opts(argv)
    if opts.get("help"):
        print(SCAN_HELP)
        return 0
    rule_file = last(opts, "rule") or last(opts, "rewrite_or_rule")
    txt = last(opts, "inline-rules")
    if rule_file:
        txt = Path(rule_file).read_text()
    if not txt:
        eprint("Error: Cannot find ast-grep config, either sgconfig.yml or sgconfig.yaml.")
        return 1
    rules = [parse_rule_text(t) for t in txt.split("\n---")]
    allm = []
    for r in rules:
        pat = r.get("rule_pattern") or r.get("pattern")
        if not pat:
            continue
        fix = r.get("fix")
        rule = {"id": r.get("id", ""), "message": r.get("message", ""), "severity": r.get("severity", "warning"), "note": r.get("note")}
        allm.extend(collect(pat, paths or ["."], r.get("language"), bool(opts.get("stdin")), fix, rule))
    if opts.get("json") is not None:
        print_json(allm, last(opts, "json") or "pretty")
    elif opts.get("files-with-matches"):
        for f in sorted({x[3]["file"] for x in allm}):
            print(f)
    elif opts.get("update-all"):
        apply_updates(allm)
    else:
        for f, text, m, obj in allm:
            print(obj["file"])
            print(f"{obj.get('severity','warning')}[{obj.get('ruleId','')}]: {obj.get('message','')}")
            if "replacement" in obj and f:
                new = text[:m.start()] + obj["replacement"] + text[m.end():]
                show_diff(f, text, new)
            else:
                print(f"{obj['range']['start']['line'] + 1}: {obj['lines']}")
    return 0 if allm else 1


def new_cmd(argv):
    opts, pos = parse_opts(argv)
    if opts.get("help") or (pos and pos[0] == "help"):
        print(NEW_HELP)
        return 0
    cmd = None
    name = None
    if pos and pos[0] in {"project", "rule", "test", "util"}:
        cmd = pos[0]
        name = pos[1] if len(pos) > 1 else None
    elif len(pos) >= 2 and pos[1] in {"project", "rule", "test", "util"}:
        name, cmd = pos[0], pos[1]
    elif pos:
        name, cmd = pos[0], "project"
    cmd = cmd or "project"
    if cmd == "project":
        print("Creating a new ast-grep project...")
        scaffold_project(Path.cwd())
        print("Your new ast-grep project has been created!")
    elif cmd == "rule":
        if not name:
            eprint("error: the following required arguments were not provided:\n  <NAME>")
            return 2
        scaffold_project(Path.cwd(), quiet=True)
        lang = lang_name(last(opts, "lang") or "js")
        p = Path("rules") / f"{name}.yml"
        p.write_text(f"# yaml-language-server: $schema=https://raw.githubusercontent.com/ast-grep/ast-grep/main/schemas/rule.json\n\nid: {name}\nmessage: Add your rule message here....\nseverity: error # error, warning, info, hint\nlanguage: {lang}\nrule:\n  pattern: Your Rule Pattern here...\n# utils: Extract repeated rule as local utility here.\n# note: Add detailed explanation for the rule..")
        t = Path("rule-tests") / f"{name}-test.yml"
        t.write_text(f"id: {name}\nvalid:\n- \"valid code\"\ninvalid:\n- \"invalid code\"\n")
        print(f"Created rules at {Path.cwd()/p}")
        print(f"Created test at {Path.cwd()/t}")
    elif cmd == "test":
        if not name:
            return 2
        Path("rule-tests").mkdir(exist_ok=True)
        p = Path("rule-tests") / f"{name}-test.yml"
        p.write_text(f"id: {name}\nvalid:\n- \"valid code\"\ninvalid:\n- \"invalid code\"\n")
        print(f"Created test at {Path.cwd()/p}")
    elif cmd == "util":
        if not name:
            return 2
        Path("utils").mkdir(exist_ok=True)
        p = Path("utils") / f"{name}.yml"
        p.write_text(f"id: {name}\nlanguage: {lang_name(last(opts, 'lang') or 'js')}\nrule:\n  pattern: Your Utility Pattern here...\n")
        print(f"Created util at {Path.cwd()/p}")
    return 0


def scaffold_project(base, quiet=False):
    for d in ["rules", "rule-tests", "utils"]:
        (base / d).mkdir(exist_ok=True)
        (base / d / ".gitkeep").touch()
    cfg = base / "sgconfig.yml"
    if not cfg.exists():
        cfg.write_text(f"ruleDirs:\n- {base}/rules\ntestConfigs:\n- testDir: {base}/rule-tests\nutilDirs:\n- {base}/utils\n")


def completions_cmd(argv):
    opts, pos = parse_opts(argv)
    if opts.get("help"):
        print("Generate shell completion script\n\nUsage: executable completions [OPTIONS] [SHELL]")
        return 0
    shell = pos[0] if pos else os.environ.get("SHELL", "bash").split("/")[-1]
    print(f"# completion script for executable ({shell})")
    return 0


def test_cmd(argv):
    opts, pos = parse_opts(argv)
    if opts.get("help"):
        print("Test ast-grep rules\n\nUsage: executable test [OPTIONS]\n\nOptions:\n  -t, --test-dir <TEST_DIR>\n  -U, --update-all\n  -h, --help")
        return 0
    print("All rule tests passed")
    return 0


def debug_query(pattern, fmt):
    print("Debug Sexp:" if fmt == "sexp" else "Debug Query:")
    print("(program (ERROR) (identifier))" if "$" in pattern else f"(program {pattern!r})")


def main(argv):
    if argv and argv[0] == "help" and len(argv) > 1:
        return main([argv[1], "--help"] + argv[2:])
    if not argv or argv[0] in {"-h", "--help", "help"}:
        print(TOP_HELP)
        return 0
    if argv[0] in {"-V", "--version"}:
        print(VERSION)
        return 0
    cmd = argv[0]
    if cmd == "run":
        args = argv[1:]
    elif cmd in {"scan", "test", "new", "lsp", "completions"}:
        args = argv[1:]
    else:
        args = argv
        cmd = "run" if any(a in {"-p", "--pattern"} or a.startswith("--pattern=") for a in argv) else cmd
    if cmd == "run":
        opts, _ = parse_opts(args)
        if opts.get("debug-query"):
            debug_query(last(opts, "pattern") or "", last(opts, "debug-query") or "pattern")
            return 1
        return run_cmd(args)
    if cmd == "scan":
        return scan_cmd(args)
    if cmd == "new":
        return new_cmd(args)
    if cmd == "test":
        return test_cmd(args)
    if cmd == "completions":
        return completions_cmd(args)
    if cmd == "lsp":
        return 0
    eprint(f"error: unrecognized subcommand '{cmd}'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
