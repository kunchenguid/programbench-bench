#!/usr/bin/env python3
import os
import re
import sys
import stat
import pwd
import grp
import math
import datetime

VERSION = "pls 0.0.1-beta.9"
ARROW = "\U000f0054"

DET_VALUES = ["dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid",
              "size", "blocks", "btime", "ctime", "mtime", "atime", "git", "none", "std", "all"]
SORT_VALUES = ["dev", "ino", "nlink", "typ", "cat", "user", "uid", "group", "gid", "size",
               "blocks", "btime", "ctime", "mtime", "atime", "name", "cname", "ext", "inode_",
               "nlinks_", "typ_", "cat_", "user_", "uid_", "group_", "gid_", "size_", "blocks_",
               "btime_", "ctime_", "mtime_", "atime_", "name_", "cname_", "ext_", "none"]
TYPE_VALUES = ["dir", "symlink", "fifo", "socket", "block-device", "char-device", "file", "none", "all"]

HELP_LONG = """pls is a prettier and powerful ls(1) for the pros.

Read docs: https://pls.cli.rs/
Get source: https://github.com/pls-rs/pls/
Sponsor: https://github.com/sponsors/dhruvkb/

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          the paths to list, each of which may be a file or directory
          
          [default: .]

Options:
  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Detail view:
  -d, --det <DETAILS>
          the data points to show about each node
          
          [default: none]
          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,
          btime, ctime, mtime, atime, git, none, std, all]

  -H, --header <HEADER>
          show headers above columnar data
          
          [default: true]
          [possible values: true, false]

  -u, --unit <UNIT>
          the type of units to use for the node sizes
          
          [default: binary]
          [possible values: binary, decimal, none]

Grid view:
  -g, --grid <GRID>
          display node names in multiple columns
          
          [default: false]
          [possible values: true, false]

  -D, --down <DOWN>
          display node names column-first
          
          [default: false]
          [possible values: true, false]

Presentation:
  -i, --icon <ICON>
          display icons next to node names
          
          [default: true]
          [possible values: true, false]

  -S, --suffix <SUFFIX>
          display node type suffixes after the node name
          
          [default: true]
          [possible values: true, false]

  -l, --sym <SYM>
          show symlink targets
          
          [default: true]
          [possible values: true, false]

  -c, --collapse <COLLAPSE>
          show dependent nodes as children of their principal nodes
          
          [default: true]
          [possible values: true, false]

  -a, --align <ALIGN>
          align items accounting for leading dots
          
          [default: true]
          [possible values: true, false]

Filtering:
  -t, --typ <TYPES>
          the set of node types to include in the output
          
          [default: all]
          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]

  -I, --imp <IMP>
          the importance cutoff to dim or hide unimportant files
          
          [default: 0]

  -e, --exclude <EXCLUDE>
          the pattern of files to selectively hide from the output

  -o, --only <ONLY>
          the pattern of files to exclusively show in the output

Sorting:
  -s, --sort <SORT_BASES>
          the set of fields to sort by, trailing `_` reverses the direction
          
          [default: cat cname]
          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,
          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,
          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]
"""

HELP_SHORT = """pls is a prettier and powerful ls(1) for the pros.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  the paths to list, each of which may be a file or directory [default: .]

Options:
  -h, --help     Print help (see more with '--help')
  -V, --version  Print version
"""

def die_arg(msg, usage="Usage: executable [OPTIONS] [PATHS]..."):
    print(msg, file=sys.stderr)
    print("", file=sys.stderr)
    print(usage, file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)

def parse_bool(v, opt):
    if v in ("true", "false"):
        return v == "true"
    print(f"error: invalid value '{v}' for '{opt}'", file=sys.stderr)
    print("  [possible values: true, false]", file=sys.stderr)
    print("", file=sys.stderr)
    print("For more information, try '--help'.", file=sys.stderr)
    sys.exit(2)

def parse_args(argv):
    opts = {"det": [], "header": True, "unit": "binary", "grid": False, "down": False,
            "icon": True, "suffix": True, "sym": True, "collapse": True, "align": True,
            "types": [], "imp": "0", "exclude": None, "only": None, "sort": []}
    paths = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            paths.extend(argv[i+1:])
            break
        if a in ("-h", "--help"):
            print(HELP_SHORT if a == "-h" else HELP_LONG, end="")
            sys.exit(0)
        if a in ("-V", "--version"):
            print(VERSION)
            sys.exit(0)
        if a.startswith("--") and "=" in a:
            k, v = a.split("=", 1)
            argv = argv[:i] + [k, v] + argv[i+1:]
            a = argv[i]
        def need():
            nonlocal i
            if i + 1 >= len(argv):
                die_arg(f"error: a value is required for '{a} <{a.lstrip('-').upper()}>' but none was supplied")
            i += 1
            return argv[i]
        if a in ("-d", "--det"):
            v = need()
            if v not in DET_VALUES:
                print(f"error: invalid value '{v}' for '--det <DETAILS>'", file=sys.stderr)
                print("  [possible values: " + ", ".join(DET_VALUES) + "]", file=sys.stderr)
                print("", file=sys.stderr)
                print("For more information, try '--help'.", file=sys.stderr)
                sys.exit(2)
            opts["det"].append(v)
        elif a in ("-H", "--header"):
            opts["header"] = parse_bool(need(), "--header <HEADER>")
        elif a in ("-u", "--unit"):
            v = need()
            if v not in ("binary", "decimal", "none"):
                die_arg(f"error: invalid value '{v}' for '--unit <UNIT>'\n  [possible values: binary, decimal, none]")
            opts["unit"] = v
        elif a in ("-g", "--grid"):
            opts["grid"] = parse_bool(need(), "--grid <GRID>")
        elif a in ("-D", "--down"):
            opts["down"] = parse_bool(need(), "--down <DOWN>")
        elif a in ("-i", "--icon"):
            opts["icon"] = parse_bool(need(), "--icon <ICON>")
        elif a in ("-S", "--suffix"):
            opts["suffix"] = parse_bool(need(), "--suffix <SUFFIX>")
        elif a in ("-l", "--sym"):
            opts["sym"] = parse_bool(need(), "--sym <SYM>")
        elif a in ("-c", "--collapse"):
            opts["collapse"] = parse_bool(need(), "--collapse <COLLAPSE>")
        elif a in ("-a", "--align"):
            opts["align"] = parse_bool(need(), "--align <ALIGN>")
        elif a in ("-t", "--typ"):
            v = need()
            if v not in TYPE_VALUES:
                die_arg(f"error: invalid value '{v}' for '--typ <TYPES>'\n  [possible values: " + ", ".join(TYPE_VALUES) + "]")
            opts["types"].append(v)
        elif a in ("-I", "--imp"):
            opts["imp"] = need()
        elif a in ("-e", "--exclude"):
            opts["exclude"] = compile_regex(need(), "--exclude <EXCLUDE>")
        elif a in ("-o", "--only"):
            opts["only"] = compile_regex(need(), "--only <ONLY>")
        elif a in ("-s", "--sort"):
            v = need()
            if v not in SORT_VALUES:
                die_arg(f"error: invalid value '{v}' for '--sort <SORT_BASES>'\n  [possible values: " + ", ".join(SORT_VALUES) + "]")
            opts["sort"].append(v)
        elif a.startswith("-"):
            print(f"error: unexpected argument '{a}' found", file=sys.stderr)
            print("", file=sys.stderr)
            print(f"  tip: to pass '{a}' as a value, use '-- {a}'", file=sys.stderr)
            print("", file=sys.stderr)
            print("Usage: executable [OPTIONS] [PATHS]...", file=sys.stderr)
            print("", file=sys.stderr)
            print("For more information, try '--help'.", file=sys.stderr)
            sys.exit(2)
        else:
            paths.append(a)
        i += 1
    if not paths:
        paths = ["."]
    if not opts["det"]:
        opts["det"] = ["none"]
    if not opts["sort"]:
        opts["sort"] = ["cat", "cname"]
    if not opts["types"]:
        opts["types"] = ["all"]
    return opts, paths

def compile_regex(pat, opt):
    try:
        return re.compile(pat)
    except re.error as e:
        print(f"error: invalid value '{pat}' for '{opt}': regex parse error:", file=sys.stderr)
        print(f"    {pat}", file=sys.stderr)
        print(f"    ^", file=sys.stderr)
        print(f"error: {e}", file=sys.stderr)
        print("", file=sys.stderr)
        print("For more information, try '--help'.", file=sys.stderr)
        sys.exit(2)

def kind(st):
    m = st.st_mode
    if stat.S_ISDIR(m): return "dir"
    if stat.S_ISLNK(m): return "symlink"
    if stat.S_ISFIFO(m): return "fifo"
    if stat.S_ISSOCK(m): return "socket"
    if stat.S_ISBLK(m): return "block-device"
    if stat.S_ISCHR(m): return "char-device"
    return "file"

def typchar(k):
    return {"dir":"d","symlink":"l","fifo":"p","socket":"s","block-device":"b","char-device":"c","file":"f"}.get(k, "?")

def cat(k):
    return {"dir":0, "file":1, "symlink":2, "fifo":3, "socket":4, "block-device":5, "char-device":6}.get(k, 9)

def cname(n):
    return n[1:].lower() if n.startswith(".") else n.lower()

def permstr(mode):
    bits = []
    for shift in (6,3,0):
        v = (mode >> shift) & 7
        bits.append(("r" if v & 4 else "-") + ("w" if v & 2 else "-") + ("x" if v & 1 else "-"))
    return " ".join(bits)

def user(uid):
    try: return pwd.getpwuid(uid).pw_name
    except KeyError: return str(uid)

def group(gid):
    try: return grp.getgrgid(gid).gr_name
    except KeyError: return str(gid)

def fmt_time(ts):
    s = datetime.datetime.fromtimestamp(ts).strftime("%Y-%b-%d %I:%M%p")
    return s[:-2] + s[-2:].lower()

def fmt_size(n, unit):
    if unit == "none":
        return f"{n} B"
    base = 1024 if unit == "binary" else 1000
    labels = ["B", "KiB" if unit == "binary" else "kB", "MiB" if unit == "binary" else "MB",
              "GiB" if unit == "binary" else "GB", "TiB" if unit == "binary" else "TB"]
    x = float(n)
    idx = 0
    while x >= base and idx < len(labels) - 1:
        x /= base
        idx += 1
    if idx == 0 and unit == "binary":
        return f"{x:.1f}   B"
    if idx == 0 and unit == "decimal":
        return f"{x:.1f}  B"
    return f"{x:.1f} {labels[idx]}"

class Node:
    def __init__(self, path, display=None):
        self.path = path
        self.name = display if display is not None else os.path.basename(path.rstrip("/")) or path
        self.st = os.lstat(path)
        self.kind = kind(self.st)
        self.target = None
        if self.kind == "symlink":
            try: self.target = os.readlink(path)
            except OSError: self.target = None

def icon_for(n):
    if n.kind == "dir": return "\uf07b"
    if n.kind == "symlink": return "\U000f0339"
    ext = n.name.rsplit(".", 1)[-1].lower() if "." in n.name.strip(".") else ""
    if ext == "rs": return "\ue68b"
    if ext in ("txt", "md", "text"): return "\ue612"
    if ext in ("png", "jpg", "jpeg", "gif", "bmp", "svg"): return "\uf1c5"
    if ext in ("zip", "gz", "tar", "tgz"): return "\uf1c6"
    if ext in ("py",): return "\ue606"
    if ext in ("c", "h", "cpp", "hpp"): return "\uf121"
    return " "

def name_text(n, opts, with_target=True):
    s = n.name
    if opts["suffix"]:
        if n.kind == "dir": s += "/"
        elif n.kind == "symlink": s += "@"
        elif n.kind == "fifo": s += "|"
        elif n.kind == "socket": s += "="
    if with_target and opts["sym"] and n.kind == "symlink" and n.target is not None:
        s += f" {ARROW} {n.target}"
    if opts["icon"]:
        ic = icon_for(n)
        if ic == " ":
            return ("   " if opts["align"] and not n.name.startswith(".") else "  ") + s
        return f"{ic}  {s}"
    return (" " if opts["align"] and not n.name.startswith(".") else "") + s

def detail_list(raw):
    out = []
    for d in raw:
        if d == "none":
            continue
        if d == "std":
            out += ["nlink", "typ", "perm", "user", "group", "size", "mtime"]
        elif d == "all":
            out += ["dev", "ino", "nlink", "typ", "perm", "oct", "user", "uid", "group", "gid",
                    "size", "blocks", "btime", "ctime", "mtime", "atime", "git"]
        else:
            out.append(d)
    seen = []
    for d in out:
        if d not in seen:
            seen.append(d)
    return seen

HEAD = {"dev":"Dev", "ino":"Inode", "nlink":"Link#", "typ":"T", "perm":"Permissions",
        "oct":"Octal", "user":"User", "uid":"UID", "group":"Group", "gid":"GID",
        "size":"Size", "blocks":"Blocks", "btime":"Created", "ctime":"Changed",
        "mtime":"Modified", "atime":"Accessed", "git":"Git"}

def detail_value(n, d, opts):
    st = n.st
    if d == "dev": return str(st.st_dev)
    if d == "ino": return str(st.st_ino)
    if d == "nlink": return str(st.st_nlink)
    if d == "typ": return typchar(n.kind)
    if d == "perm": return permstr(st.st_mode)
    if d == "oct": return f"{stat.S_IMODE(st.st_mode):4o}"
    if d == "user": return user(st.st_uid)
    if d == "uid": return str(st.st_uid)
    if d == "group": return group(st.st_gid)
    if d == "gid": return str(st.st_gid)
    if d == "size":
        return "" if n.kind == "dir" else fmt_size(st.st_size, opts["unit"])
    if d == "blocks": return "" if n.kind == "dir" else str(getattr(st, "st_blocks", 0))
    if d in ("btime", "ctime", "mtime", "atime"):
        ts = st.st_ctime if d in ("btime", "ctime") else (st.st_mtime if d == "mtime" else st.st_atime)
        return fmt_time(ts)
    if d == "git": return ""
    return ""

def sort_key(n, keys):
    vals = []
    for k in keys:
        rev = k.endswith("_")
        base = k[:-1] if rev else k
        if base == "none":
            vals.append(0)
        elif base == "cat":
            vals.append(cat(n.kind))
        elif base in ("name", "cname"):
            vals.append(cname(n.name) if base == "cname" else n.name.lower())
        elif base == "ext":
            vals.append(os.path.splitext(n.name)[1].lower())
        elif base == "size":
            vals.append(n.st.st_size)
        elif base == "dev":
            vals.append(n.st.st_dev)
        elif base in ("ino", "inode"):
            vals.append(n.st.st_ino)
        elif base in ("nlink", "nlinks"):
            vals.append(n.st.st_nlink)
        elif base == "typ":
            vals.append(typchar(n.kind))
        elif base == "user":
            vals.append(user(n.st.st_uid))
        elif base == "uid":
            vals.append(n.st.st_uid)
        elif base == "group":
            vals.append(group(n.st.st_gid))
        elif base == "gid":
            vals.append(n.st.st_gid)
        elif base == "blocks":
            vals.append(getattr(n.st, "st_blocks", 0))
        elif base == "mtime":
            vals.append(n.st.st_mtime)
        elif base in ("ctime", "btime"):
            vals.append(n.st.st_ctime)
        elif base == "atime":
            vals.append(n.st.st_atime)
        else:
            vals.append(cname(n.name))
    vals.append(cname(n.name))
    return tuple(vals)

def apply_reverse(nodes, keys):
    # The real program reverses per key; this covers the common single-key case.
    rev = len(keys) == 1 and keys[0].endswith("_")
    return sorted(nodes, key=lambda n: sort_key(n, keys), reverse=rev)

def list_dir(path):
    out = []
    with os.scandir(path) as it:
        for e in it:
            out.append(Node(e.path, e.name))
    return out

def allowed(n, opts):
    ts = opts["types"]
    if "none" in ts:
        return False
    if "all" not in ts and n.kind not in ts:
        return False
    if opts["only"] and not opts["only"].search(n.name):
        return False
    if opts["exclude"] and opts["exclude"].search(n.name):
        return False
    return True

def print_nodes(nodes, opts):
    dets = detail_list(opts["det"])
    nodes = [n for n in nodes if allowed(n, opts)]
    nodes = apply_reverse(nodes, opts["sort"])
    if not dets:
        for n in nodes:
            print(name_text(n, opts, with_target=not opts["grid"]))
        return
    rows = []
    for n in nodes:
        vals = [detail_value(n, d, opts) for d in dets]
        vals.append(name_text(n, opts))
        rows.append(vals)
    headers = [HEAD.get(d, d.title()) for d in dets] + ["Name"]
    widths = [len(h) if opts["header"] else 0 for h in headers]
    for r in rows:
        for i, v in enumerate(r):
            widths[i] = max(widths[i], len(v))
    if opts["header"]:
        parts = []
        for i in range(len(headers)):
            h = headers[i]
            if i == len(headers) - 1:
                parts.append(h)
            elif h in ("Size","Link#","Dev","Inode","UID","GID","Blocks","Octal"):
                parts.append(h.rjust(widths[i]))
            else:
                parts.append(h.ljust(widths[i]))
        print(" ".join(parts))
    for r in rows:
        parts = []
        for i, v in enumerate(r):
            h = headers[i]
            if i == len(headers) - 1:
                parts.append(v)
            elif h in ("Size","Link#","Dev","Inode","UID","GID","Blocks","Octal"):
                parts.append(v.rjust(widths[i]))
            else:
                parts.append(v.ljust(widths[i]))
        print(" ".join(parts))

def main():
    opts, paths = parse_args(sys.argv[1:])
    multi = len(paths) > 1
    first = True
    for p in paths:
        try:
            st = os.lstat(p)
        except OSError as e:
            if not first: print()
            print(f"{p}:")
            print(f"\terror: {e.strerror} (os error {e.errno})")
            first = False
            continue
        if not first:
            print()
        if stat.S_ISDIR(st.st_mode):
            if multi:
                print(f"{p}:")
            print_nodes(list_dir(p), opts)
        else:
            print_nodes([Node(p, os.path.basename(p))], opts)
        first = False

if __name__ == "__main__":
    main()
