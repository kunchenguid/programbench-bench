#define _POSIX_C_SOURCE 200809L

#include <dirent.h>
#include <errno.h>
#include <getopt.h>
#include <limits.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static const char *usage_text =
"usage: nnn [OPTIONS] [PATH]\n"
"\n"
"The unorthodox terminal file manager.\n"
"\n"
"positional args:\n"
"  PATH   start dir/file [default: .]\n"
"\n"
"optional args:\n"
" -a      auto NNN_FIFO\n"
" -A      no dir auto-enter during filter\n"
" -b key  open bookmark key (trumps -s/S)\n"
" -B      use bsdtar for archives\n"
" -c      cli-only NNN_OPENER (trumps -e)\n"
" -C      8-color scheme\n"
" -d      detail mode\n"
" -D      dirs in context color\n"
" -e      text in $VISUAL/$EDITOR/vi\n"
" -E      internal edits in EDITOR\n"
" -f      use history file\n"
" -F val  fifo mode [0:preview 1:explore]\n"
" -g      regex filters\n"
" -H      show hidden files\n"
" -i      show current file info\n"
" -J      no auto-advance on selection\n"
" -K      detect key collision and exit\n"
" -l val  set scroll lines\n"
" -n      type-to-nav mode\n"
" -N      use native prompt\n"
" -o      open files only on Enter\n"
" -p file selection file [-:stdout]\n"
" -P key  run plugin key\n"
" -Q      no quit confirmation\n"
" -r      use advcpmv patched cp, mv\n"
" -R      no rollover at edges\n"
" -s name load session by name\n"
" -S      persistent session\n"
" -t secs timeout to lock\n"
" -T key  sort order [a/d/e/r/s/t/v]\n"
" -u      use selection (no prompt)\n"
" -U      show user and group\n"
" -V      show version\n"
" -x      notis, selection sync, xterm title\n"
" -z      in order fuzzy filters\n"
" -0      null separator in picker mode\n"
" -h      show help\n"
"\n"
"v5.2\n"
"BSD 2-Clause\n"
"https://github.com/jarun/nnn\n";

struct opts {
    int show_hidden;
    int detail;
    int null_sep;
    int picker;
    int help;
    const char *pickfile;
};

static int mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    size_t len = strlen(path);
    if (len == 0 || len >= sizeof(tmp))
        return -1;
    strcpy(tmp, path);
    if (len > 1 && tmp[len - 1] == '/')
        tmp[len - 1] = '\0';
    for (char *p = tmp + 1; *p; ++p) {
        if (*p == '/') {
            *p = '\0';
            if (mkdir(tmp, 0777) == -1 && errno != EEXIST)
                return -1;
            *p = '/';
        }
    }
    if (mkdir(tmp, 0777) == -1 && errno != EEXIST)
        return -1;
    return 0;
}

static void parent_dir(char *path) {
    char *slash = strrchr(path, '/');
    if (!slash) {
        strcpy(path, ".");
    } else if (slash == path) {
        slash[1] = '\0';
    } else {
        *slash = '\0';
    }
}

static int cmp_names(const void *a, const void *b) {
    const char *const *sa = (const char *const *)a;
    const char *const *sb = (const char *const *)b;
    return strcasecmp(*sa, *sb);
}

static char **read_entries(const char *dir, int show_hidden, size_t *count) {
    DIR *dp = opendir(dir);
    if (!dp)
        return NULL;
    size_t cap = 32, n = 0;
    char **items = calloc(cap, sizeof(*items));
    if (!items) {
        closedir(dp);
        return NULL;
    }
    struct dirent *de;
    while ((de = readdir(dp))) {
        if (!show_hidden && de->d_name[0] == '.')
            continue;
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, ".."))
            continue;
        if (n == cap) {
            cap *= 2;
            char **next = realloc(items, cap * sizeof(*items));
            if (!next)
                break;
            items = next;
        }
        items[n++] = strdup(de->d_name);
    }
    closedir(dp);
    qsort(items, n, sizeof(*items), cmp_names);
    *count = n;
    return items;
}

static void free_entries(char **items, size_t n) {
    if (!items)
        return;
    for (size_t i = 0; i < n; ++i)
        free(items[i]);
    free(items);
}

static void write_selection(const char *target, const char *path, int null_sep) {
    FILE *fp = stdout;
    if (target && strcmp(target, "-") != 0) {
        fp = fopen(target, "a");
        if (!fp)
            return;
    }
    fputs(path, fp);
    fputc(null_sep ? '\0' : '\n', fp);
    if (fp != stdout)
        fclose(fp);
}

static void display_listing(const char *dir, struct opts *opts) {
    size_t n = 0;
    char **items = read_entries(dir, opts->show_hidden, &n);
    if (!items) {
        fprintf(stderr, "%s: %s\n", dir, strerror(errno));
        return;
    }

    const char *term = getenv("TERM");
    int interactive = isatty(STDIN_FILENO) && isatty(STDOUT_FILENO) && term && strcmp(term, "dumb") != 0;
    if (opts->picker && !interactive) {
        if (n > 0) {
            char path[PATH_MAX];
            snprintf(path, sizeof(path), "%s/%s", dir, items[0]);
            write_selection(opts->pickfile, path, opts->null_sep);
        }
        free_entries(items, n);
        return;
    }

    if (interactive)
        printf("\033[?1049h\033[H\033[2J");
    printf("%s\n", dir);
    for (size_t i = 0; i < n; ++i)
        printf("%c %s\n", i == 0 ? '>' : ' ', items[i]);
    fflush(stdout);

    if (interactive) {
        struct termios oldt, raw;
        if (tcgetattr(STDIN_FILENO, &oldt) == 0) {
            raw = oldt;
            raw.c_lflag &= (tcflag_t)~(ICANON | ECHO);
            tcsetattr(STDIN_FILENO, TCSANOW, &raw);
            int c;
            while ((c = getchar()) != EOF) {
                if (c == 'q' || c == 'Q' || c == 27)
                    break;
                if ((c == '\n' || c == '\r') && opts->picker && n > 0) {
                    char path[PATH_MAX];
                    snprintf(path, sizeof(path), "%s/%s", dir, items[0]);
                    write_selection(opts->pickfile, path, opts->null_sep);
                    break;
                }
                if (c == '?') {
                    printf("\033[H\033[2J%s", usage_text);
                    fflush(stdout);
                }
            }
            tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
        }
        printf("\033[?1049l");
    }
    free_entries(items, n);
}

int main(int argc, char **argv) {
    struct opts opts;
    memset(&opts, 0, sizeof(opts));

    opterr = 1;
    int c;
    while ((c = getopt(argc, argv, "aAb:BcCdDeEfF:gHiJl:KnNop:P:QrRSs:t:T:uUVxz0h")) != -1) {
        switch (c) {
        case 'H':
            opts.show_hidden = 1;
            break;
        case 'd':
            opts.detail = 1;
            break;
        case 'p':
            opts.picker = 1;
            opts.pickfile = optarg;
            break;
        case '0':
            opts.null_sep = 1;
            break;
        case 'V':
            puts("5.2");
            return 0;
        case 'h':
            opts.help = 1;
            break;
        case 'F':
            if (optarg && strcmp(optarg, "0") && strcmp(optarg, "1"))
                return 1;
            break;
        case '?':
        default:
            fputs(usage_text, stdout);
            return 1;
        }
    }

    if (opts.help) {
        fputs(usage_text, stdout);
        return 0;
    }

    const char *argpath = optind < argc ? argv[optind] : ".";
    struct stat st;
    char start[PATH_MAX];
    if (strlen(argpath) >= sizeof(start)) {
        fprintf(stderr, "%s: File name too long\n", argpath);
        return 1;
    }
    strcpy(start, argpath);

    if (stat(start, &st) == -1) {
        size_t len = strlen(start);
        if (len > 0 && start[len - 1] == '/') {
            mkdir_p(start);
        } else {
            char parent[PATH_MAX];
            strcpy(parent, start);
            parent_dir(parent);
            mkdir_p(parent);
            strncpy(start, parent, sizeof(start) - 1);
            start[sizeof(start) - 1] = '\0';
        }
    } else if (!S_ISDIR(st.st_mode)) {
        parent_dir(start);
    }

    display_listing(start, &opts);
    return 0;
}
