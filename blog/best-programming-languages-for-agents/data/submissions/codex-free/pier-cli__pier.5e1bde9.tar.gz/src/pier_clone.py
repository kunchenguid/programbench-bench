#!/usr/bin/env python3
import os, sys, re, subprocess, tempfile
from pathlib import Path

VERSION='pier 0.1.6'

HELP_MAIN='''pier 0.1.6
Benjamin Scholtz, Isak Johansson
A simple script management CLI

USAGE:
    executable [FLAGS] [OPTIONS] <alias> [args]...
    executable [FLAGS] [OPTIONS] <SUBCOMMAND>

FLAGS:
    -h, --help       
            Prints help information

    -V, --version    
            Prints version information

    -v, --verbose    
            The level of verbosity


OPTIONS:
    -c, --config-file <path>    
            Sets a custom config file.
            
            DEFAULT PATH is otherwise determined in this order:
            
            - $PIER_CONFIG_PATH (environment variable if set)
            
            - pier.toml (in the current directory)
            
            - $XDG_CONFIG_HOME/pier/config.toml
            
            - $XDG_CONFIG_HOME/pier/config
            
            - $XDG_CONFIG_HOME/pier.toml
            
            - $HOME/.pier.toml
            
            - $HOME/.pier
            
             [env: PIER_CONFIG_PATH=]

ARGS:
    <alias>      
            The alias or name for the script.

    <args>...    
            The positional arguments to send to script.


SUBCOMMANDS:
    add            Add a new script to config.
    config-init    alias: init - Add a config file.
    copy           alias: cp - Copy existing alias to the new one
    edit           Edit a script matching alias.
    help           Prints this message or the help of the given subcommand(s)
    list           alias: ls - List scripts
    move           alias: mv, rename - Move/rename existing alias to the new one
    remove         alias: rm - Remove a script matching alias.
    run            Run a script matching alias.
    show           Show a script matching alias.'''

SUBHELPS={
'add':'''executable-add 0.1.6
Add a new script to config.

USAGE:
    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

OPTIONS:
    -a, --alias <alias>                The alias or name for the script.
    -d, --description <description>    The description for the script.
    -t, --tag <tags>...                Set which tags the script belongs to.

ARGS:
    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR
                 for you to enter the script into.''',
'list':'''executable-list 0.1.6
alias: ls - List scripts

Display options are determined by priority in this order:

1. List only aliases

2. Show full command

3. Command display with (cli option)

4. Command display with (config option)

USAGE:
    executable list [FLAGS] [OPTIONS]

FLAGS:
    -l, --cmd_full        Display the full command.
    -h, --help            Prints help information
    -q, --list_aliases    Only displays aliases of the scripts.
    -V, --version         Prints version information

OPTIONS:
    -c, --cmd_width <cmd-width>    The max number of characters to display from the command.
    -t, --tag <tags>...            Filter based on tags.''',
'run':'''executable-run 0.1.6
Run a script matching alias.

USAGE:
    executable run <alias> [args]...

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>      The alias or name for the script.
    <args>...    The positional arguments to send to script.''',
'config-init':'''executable-config-init 0.1.6
alias: init - Add a config file.

USAGE:
    executable config-init

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information''',
'show':'''executable-show 0.1.6
Show a script matching alias.

USAGE:
    executable show <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.''',
'remove':'''executable-remove 0.1.6
alias: rm - Remove a script matching alias.

USAGE:
    executable remove <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.''',
'copy':'''executable-copy 0.1.6
alias: cp - Copy existing alias to the new one

USAGE:
    executable copy <from-alias> <to-alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be copied.
    <to-alias>      The new alias of the copy of the script.''',
'move':'''executable-move 0.1.6
alias: mv, rename - Move/rename existing alias to the new one

USAGE:
    executable move [FLAGS] <from-alias> <to-alias>

FLAGS:
    -f, --force      Allows to overwrite the existing script
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <from-alias>    The alias of the script that will be moved.
    <to-alias>      The new alias of the script.''',
'edit':'''executable-edit 0.1.6
Edit a script matching alias.

USAGE:
    executable edit <alias>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

ARGS:
    <alias>    The alias or name for the script.'''
}
ALIASES={'ls':'list','rm':'remove','cp':'copy','mv':'move','rename':'move','init':'config-init'}

def eprint(s): print(s, file=sys.stderr)

def config_candidates():
    if os.environ.get('PIER_CONFIG_PATH'):
        return [Path(os.environ['PIER_CONFIG_PATH'])]
    xdg=os.environ.get('XDG_CONFIG_HOME') or str(Path.home()/'.config')
    return [Path('pier.toml'), Path(xdg)/'pier/config.toml', Path(xdg)/'pier/config', Path(xdg)/'pier.toml', Path.home()/'.pier.toml', Path.home()/'.pier']

def find_config(explicit=None):
    if explicit: return Path(explicit)
    for p in config_candidates():
        if p.exists(): return p
    return config_candidates()[0]

def unquote(v):
    v=v.strip()
    if len(v)>=2 and v[0] in "'\"" and v[-1]==v[0]:
        return bytes(v[1:-1], 'utf-8').decode('unicode_escape') if v[0]=='"' else v[1:-1]
    return v

def quote(v):
    return "'" + str(v).replace('\\','\\\\').replace("'", "\\'") + "'"

def load_config(path):
    try: lines=Path(path).read_text().splitlines()
    except Exception as ex:
        eprint(f"error: Unable to read config from file {path}: {ex} ")
        sys.exit(1)
    scripts={}; default={}; cur=None; arr_key=None; arr=[]
    for raw in lines:
        line=raw.strip()
        if not line or line.startswith('#'): continue
        if arr_key:
            if line.startswith(']'):
                cur[arr_key]=arr; arr_key=None; arr=[]
            else:
                val=line.rstrip(',').strip()
                if val: arr.append(unquote(val))
            continue
        m=re.match(r'\[scripts(?:\.([^\]]+))?\]', line)
        if m:
            name=m.group(1)
            cur = scripts.setdefault(name,{}) if name else None
            continue
        if line=='[default]': cur=default; continue
        if cur is None or '=' not in line: continue
        k,v=[x.strip() for x in line.split('=',1)]
        if v.startswith('['):
            inside=v[1:].strip()
            vals=[]
            if inside.endswith(']'):
                inside=inside[:-1].strip()
                if inside:
                    vals=[unquote(x.strip().rstrip(',')) for x in inside.split(',') if x.strip().rstrip(',')]
                cur[k]=vals
            else:
                arr_key=k; arr=[]
        else:
            cur[k.replace('-','_')]=unquote(v)
    return {'scripts':scripts, 'default':default}

def save_config(path, cfg):
    out=[]
    scripts=cfg.get('scripts',{})
    if scripts:
        for name in sorted(scripts.keys()):
            s=scripts[name]
            out.append(f'[scripts.{name}]')
            if 'command' in s: out.append('command = '+quote(s.get('command','')))
            if s.get('description') is not None: out.append('description = '+quote(s.get('description','')))
            tags=s.get('tags') or []
            if tags:
                out.append('tags = [')
                for t in tags: out.append('    '+quote(t)+',')
                out.append(']')
            out.append('')
    else:
        out += ['[scripts]','']
    out.append('[default]')
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text('\n'.join(out)+'\n')

def no_scripts():
    eprint('error: No scripts exist. Would you like to add a new script?')
    sys.exit(1)

def get_script(cfg, alias):
    scripts=cfg.get('scripts',{})
    if not scripts: no_scripts()
    if alias not in scripts:
        eprint(f'error: AliasNotFound: No script found by alias {alias}')
        sys.exit(1)
    return scripts[alias]

def table(rows, width=None, full=False):
    headers=['Alias','Tags','Command','Description']
    data=[]
    for a,s in rows:
        cmd=s.get('command','')
        if width is not None and not full: cmd=cmd[:width]
        data.append([a, ','.join(s.get('tags') or []), cmd, s.get('description','')])
    widths=[len(h) for h in headers]
    for r in data:
        for i,c in enumerate(r): widths[i]=max(widths[i], len(c))
    border='≖'*(sum(widths)+13)
    print(border)
    print('⋮ '+' ⋮ '.join(headers[i].ljust(widths[i]) for i in range(4))+' ⋮')
    print(border)
    for r in data:
        print('⋮ '+' ⋮ '.join(r[i].ljust(widths[i]) for i in range(4))+' ⋮')
    print(border)

def parse_globals(argv):
    cfg=None; i=0
    while i<len(argv):
        a=argv[i]
        if a in ('-c','--config-file') and i+1<len(argv):
            cfg=argv[i+1]; i+=2
        elif a.startswith('--config-file='):
            cfg=a.split('=',1)[1]; i+=1
        elif a in ('-v','--verbose'):
            i+=1
        else:
            break
    return cfg, argv[i:]

def cmd_add(path,args):
    if '-h' in args or '--help' in args: print(SUBHELPS['add']); return 0
    if '-V' in args or '--version' in args: print('executable-add 0.1.6'); return 0
    alias=None; desc=None; tags=[]; force=False; cmd_parts=[]; i=0; after=False
    while i<len(args):
        a=args[i]
        if after: cmd_parts.append(a); i+=1; continue
        if a=='--': after=True; i+=1; continue
        if a in ('-f','--force'): force=True; i+=1; continue
        if a in ('-a','--alias'):
            if i+1>=len(args): eprint("error: The argument '--alias <alias>' requires a value but none was supplied\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help"); return 1
            alias=args[i+1]; i+=2; continue
        if a in ('-d','--description') and i+1<len(args): desc=args[i+1]; i+=2; continue
        if a in ('-t','--tag') and i+1<len(args): tags.append(args[i+1]); i+=2; continue
        cmd_parts.append(a); i+=1
    if not alias:
        eprint('error: The following required arguments were not provided:\n    --alias <alias>\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFor more information try --help')
        return 1
    cfg=load_config(path)
    if alias in cfg['scripts'] and not force:
        eprint(f'error: AliasAlreadyExists:  {alias}'); return 1
    command=' '.join(cmd_parts)
    if not command:
        editor=os.environ.get('EDITOR','vi')
        fd,tmp=tempfile.mkstemp(); os.close(fd)
        rc=subprocess.call([editor,tmp])
        if rc!=0:
            eprint(f'error: EditorError: Failed when trying to get input from editor Failed to open `{editor}` as a text editor or editor was terminated with errors.')
            return 1
        command=Path(tmp).read_text(); os.unlink(tmp)
    ent={'command':command}
    if desc is not None: ent['description']=desc
    if tags: ent['tags']=tags
    cfg['scripts'][alias]=ent; save_config(path,cfg); print(f'Added {alias}'); return 0

def main():
    cfg_arg, argv=parse_globals(sys.argv[1:])
    if not argv or argv[0] in ('-h','--help'):
        print(HELP_MAIN); return 0
    if argv[0] in ('-V','--version'):
        print(VERSION); return 0
    if argv[0]=='help':
        if len(argv)==1: print(HELP_MAIN); return 0
        key=ALIASES.get(argv[1], argv[1]); print(SUBHELPS.get(key, HELP_MAIN)); return 0
    cmd=ALIASES.get(argv[0], argv[0]); args=argv[1:]
    if cmd in SUBHELPS and ('-h' in args or '--help' in args): print(SUBHELPS[cmd]); return 0
    if cmd in SUBHELPS and ('-V' in args or '--version' in args): print(('executable-'+cmd+' 0.1.6')); return 0
    path=find_config(cfg_arg)
    if cmd=='config-init':
        p=path if cfg_arg else Path(os.environ.get('XDG_CONFIG_HOME') or str(Path.home()/'.config'))/'pier/config.toml'
        cfg={'scripts':{'hello-pier':{'command':'echo Hello, Pier!','description':'This is an example command.'}},'default':{}}
        save_config(p,cfg); print('Added hello-pier'); return 0
    if cmd=='add': return cmd_add(path,args)
    cfg=load_config(path)
    if cmd=='list':
        aliases_only=False; full=False; width=None; tags=[]; i=0
        while i<len(args):
            a=args[i]
            if a in ('-q','--list_aliases'): aliases_only=True; i+=1
            elif a in ('-l','--cmd_full'): full=True; i+=1
            elif a in ('-c','--cmd_width') and i+1<len(args): width=int(args[i+1]); i+=2
            elif a in ('-t','--tag') and i+1<len(args): tags.append(args[i+1]); i+=2
            else: i+=1
        if not cfg['scripts']: no_scripts()
        rows=[]
        for a in sorted(cfg['scripts'].keys()):
            s=cfg['scripts'][a]
            if tags and not any(t in (s.get('tags') or []) for t in tags): continue
            rows.append((a,s))
        if aliases_only:
            for a,s in rows: print(a)
        else: table(rows,width,full)
        return 0
    if cmd=='show':
        if not args: eprint('error: The following required arguments were not provided:\n    <alias>'); return 1
        print(get_script(cfg,args[0]).get('command','')); return 0
    if cmd=='run' or cmd not in SUBHELPS:
        alias=args[0] if cmd=='run' and args else cmd
        rargs=(args[1:] if cmd=='run' else args)
        s=get_script(cfg,alias)
        return subprocess.call(['/bin/bash','-c',s.get('command',''),alias]+rargs)
    if cmd=='remove':
        if not args: return 1
        get_script(cfg,args[0]); del cfg['scripts'][args[0]]; save_config(path,cfg); print(f'Removed {args[0]}'); return 0
    if cmd=='copy':
        if len(args)<2: return 1
        s=dict(get_script(cfg,args[0]))
        if args[1] in cfg['scripts']: eprint(f'error: AliasAlreadyExists:  {args[1]}'); return 1
        cfg['scripts'][args[1]]=s; save_config(path,cfg); print(f'Copy from alias {args[0]} to new alias {args[1]}'); return 0
    if cmd=='move':
        force=False; rest=[]
        for a in args:
            if a in ('-f','--force'): force=True
            else: rest.append(a)
        if len(rest)<2: return 1
        s=dict(get_script(cfg,rest[0]))
        if rest[1] in cfg['scripts'] and not force: eprint(f'error: AliasAlreadyExists:  {rest[1]}'); return 1
        cfg['scripts'][rest[1]]=s
        if rest[0] in cfg['scripts']: del cfg['scripts'][rest[0]]
        save_config(path,cfg); print(f'Move from alias {rest[0]} to new alias {rest[1]}'); return 0
    if cmd=='edit':
        if not args: return 1
        s=get_script(cfg,args[0]); editor=os.environ.get('EDITOR','vi')
        fd,tmp=tempfile.mkstemp(); os.close(fd); Path(tmp).write_text(s.get('command',''))
        rc=subprocess.call([editor,tmp])
        if rc!=0: eprint(f'error: EditorError: Failed when trying to get input from editor Failed to open `{editor}` as a text editor or editor was terminated with errors.'); return 1
        s['command']=Path(tmp).read_text(); os.unlink(tmp); save_config(path,cfg); return 0
    return 1

if __name__=='__main__': sys.exit(main())
