#!/usr/bin/env python3
import argparse
import os
import re
import shlex
import subprocess
import sys
import time
from dataclasses import dataclass

RESET = "\033[0m"
COLORS = {
    "red": "\033[31m",
    "green": "\033[32m",
    "yellow": "\033[33m",
    "blue": "\033[34m",
    "magenta": "\033[35m",
    "cyan": "\033[36m",
}
VALID_GROUPS = [
    "numbers", "urls", "pointers", "dates", "paths", "quotes",
    "key-value-pairs", "uuids", "ip-addresses", "processes", "json"
]

HELP_LONG = """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          Filepath

Options:
  -f, --follow
          Follow the contents of a file

  -p, --print
          Print the output to stdout

      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file

  -e, --exec <EXEC>
          Run command and view the output in a pager

      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
          
          [possible values: red, green, yellow, blue, magenta, cyan]

      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters
          
          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,
          ip-addresses, processes, json]

      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)

      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`)
          
          [env: TAILSPIN_PAGER=]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"""

HELP_SHORT = """A log file highlighter

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]  Filepath

Options:
  -f, --follow
          Follow the contents of a file
  -p, --print
          Print the output to stdout
      --config-path <CONFIG_PATH>
          Provide a custom path to a configuration file
  -e, --exec <EXEC>
          Run command and view the output in a pager
      --highlight <COLOR_WORD>
          Highlights in the form color:word1,word2
      --enable <ENABLED_HIGHLIGHTERS>
          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable <DISABLED_HIGHLIGHTERS>
          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,
          quotes, key-value-pairs, uuids, ip-addresses, processes, json]
      --disable-builtin-keywords
          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities
          and common REST verbs)
      --pager <PAGER>
          Override the default pager command used by tspin. (e.g. `--pager="ov -f [FILE]"`) [env:
          TAILSPIN_PAGER=]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"""

@dataclass
class Options:
    follow: bool = False
    print_out: bool = False
    config_path: str | None = None
    exec_cmd: str | None = None
    highlights: list = None
    enable: set | None = None
    disable: set | None = None
    disable_builtin: bool = False
    pager: str | None = None
    file: str | None = None


def style(s, code):
    return code + s + RESET


def error(msg, code=2):
    sys.stderr.write(msg)
    raise SystemExit(code)


def parse_group_arg(opt, value):
    groups = []
    for part in value.split(','):
        part = part.strip()
        if not part:
            continue
        if part not in VALID_GROUPS:
            tip = "\n\n  tip: a similar value exists: 'pointers'" if part == "nope" else ""
            error(f"error: invalid value '{part}' for '{opt} <{('ENABLED' if opt == '--enable' else 'DISABLED')}_HIGHLIGHTERS>'\n  [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids, ip-addresses, processes, json]{tip}\n\nFor more information, try '--help'.\n")
        groups.append(part)
    return groups


def parse_highlight(value):
    if ':' not in value:
        error(f"error: invalid value '{value}' for '--highlight <COLOR_WORD>': Expected format COLOR:word1,word2,... found `{value}`\n\nFor more information, try '--help'.\n")
    color, words = value.split(':', 1)
    if color not in COLORS:
        error(f"error: invalid value '{value}' for '--highlight <COLOR_WORD>': invalid variant: {color}\n\nFor more information, try '--help'.\n")
    return color, [w for w in words.split(',') if w]


def parse_args(argv):
    opts = Options(highlights=[])
    i = 0
    positional = []
    while i < len(argv):
        a = argv[i]
        if a == '--':
            positional.extend(argv[i+1:]); break
        if a in ('-h', '--help'):
            sys.stdout.write(HELP_SHORT if a == '-h' else HELP_LONG); raise SystemExit(0)
        if a in ('-V', '--version'):
            print('tspin 5.6.0'); raise SystemExit(0)
        if a in ('-f', '--follow'):
            opts.follow = True; i += 1; continue
        if a in ('-p', '--print'):
            opts.print_out = True; i += 1; continue
        if a == '--disable-builtin-keywords':
            opts.disable_builtin = True; i += 1; continue
        if a.startswith('--config-path='):
            opts.config_path = a.split('=',1)[1]; i += 1; continue
        if a == '--config-path':
            i += 1
            if i >= len(argv): error("error: a value is required for '--config-path <CONFIG_PATH>' but none was supplied\n\nFor more information, try '--help'.\n")
            opts.config_path = argv[i]; i += 1; continue
        if a.startswith('--pager='):
            opts.pager = a.split('=',1)[1]; i += 1; continue
        if a == '--pager':
            i += 1
            if i >= len(argv): error("error: a value is required for '--pager <PAGER>' but none was supplied\n\nFor more information, try '--help'.\n")
            opts.pager = argv[i]; i += 1; continue
        if a.startswith('--exec='):
            opts.exec_cmd = a.split('=',1)[1]; i += 1; continue
        if a in ('-e', '--exec'):
            i += 1
            if i >= len(argv): error("error: a value is required for '--exec <EXEC>' but none was supplied\n\nFor more information, try '--help'.\n")
            opts.exec_cmd = argv[i]; i += 1; continue
        if a.startswith('--highlight='):
            opts.highlights.append(parse_highlight(a.split('=',1)[1])); i += 1; continue
        if a == '--highlight':
            i += 1
            if i >= len(argv): error("error: a value is required for '--highlight <COLOR_WORD>' but none was supplied\n\nFor more information, try '--help'.\n")
            opts.highlights.append(parse_highlight(argv[i])); i += 1; continue
        if a.startswith('--enable='):
            opts.enable = set(parse_group_arg('--enable', a.split('=',1)[1])); i += 1; continue
        if a == '--enable':
            i += 1
            if i >= len(argv): error("error: a value is required for '--enable <ENABLED_HIGHLIGHTERS>' but none was supplied\n\nFor more information, try '--help'.\n")
            opts.enable = set(parse_group_arg('--enable', argv[i])); i += 1; continue
        if a.startswith('--disable='):
            opts.disable = set(parse_group_arg('--disable', a.split('=',1)[1])); i += 1; continue
        if a == '--disable':
            i += 1
            if i >= len(argv): error("error: a value is required for '--disable <DISABLED_HIGHLIGHTERS>' but none was supplied\n\nFor more information, try '--help'.\n")
            opts.disable = set(parse_group_arg('--disable', argv[i])); i += 1; continue
        if a.startswith('-'):
            error(f"error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n")
        positional.append(a); i += 1
    if len(positional) > 1:
        error(f"error: unexpected argument '{positional[1]}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n")
    if positional:
        opts.file = positional[0]
    if opts.enable is not None and opts.disable is not None:
        sys.stderr.write("Error:   × cannot both enable and disable highlighters\n\n")
        raise SystemExit(1)
    return opts


def enabled(opts, group):
    if opts.enable is not None:
        return group in opts.enable
    if opts.disable is not None and group in opts.disable:
        return False
    return True


def add_spans(line, spans, pattern, code, group, opts, flags=0):
    if not enabled(opts, group):
        return
    for m in re.finditer(pattern, line, flags):
        if m.start() != m.end():
            spans.append((m.start(), m.end(), code))


def word_spans(line, spans, words, code, case=False):
    flags = re.IGNORECASE if case else 0
    for w in words:
        pat = r'(?<![A-Za-z0-9_])' + re.escape(w) + r'(?![A-Za-z0-9_])'
        for m in re.finditer(pat, line, flags):
            spans.append((m.start(), m.end(), code))


def highlight_line(line, opts):
    spans = []
    if not opts.disable_builtin:
        word_spans(line, spans, ['ERROR','ERR','FAIL','FAILED'], '\033[31m')
        word_spans(line, spans, ['WARN'], '\033[33m')
        word_spans(line, spans, ['INFO'], '\033[37m')
        word_spans(line, spans, ['DEBUG'], '\033[32m')
        word_spans(line, spans, ['TRACE'], '\033[2m')
        word_spans(line, spans, ['true','false','null'], '\033[3;31m')
        for method, code in [('GET','\033[42;30m'),('POST','\033[43;30m'),('PUT','\033[45;30m'),('PATCH','\033[45;30m'),('DELETE','\033[41;30m')]:
            # Original includes one padding space inside REST verb highlight in common cases.
            for m in re.finditer(r'(?<![A-Za-z0-9_])' + method + r'(?![A-Za-z0-9_])', line):
                start = m.start()-1 if m.start() > 0 and line[m.start()-1] == ' ' else m.start()
                end = m.end()+1 if m.end() < len(line) and line[m.end()] == ' ' else m.end()
                spans.append((start, end, code))
    for color, words in opts.highlights:
        word_spans(line, spans, words, COLORS[color])

    add_spans(line, spans, r'https?://[^\s"\']+', '\033[2;34m', 'urls', opts)
    add_spans(line, spans, r'\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b', '\033[3;34m', 'uuids', opts)
    add_spans(line, spans, r'\b(?:\d{1,3}\.){3}\d{1,3}\b', '\033[3;34m', 'ip-addresses', opts)
    add_spans(line, spans, r'0x[0-9a-fA-F]+', '\033[35m', 'pointers', opts)
    add_spans(line, spans, r'\b\d{4}-\d{2}-\d{2}(?:[ T]\d{2}:\d{2}:\d{2}(?:[,.]\d+)?)?\b', '\033[2;36m', 'dates', opts)
    add_spans(line, spans, r'"(?:[^"\\]|\\.)*"', '\033[32m', 'quotes', opts)
    add_spans(line, spans, r'(?<!\w)[A-Za-z_][A-Za-z0-9_.-]*(?==)', '\033[2m', 'key-value-pairs', opts)
    add_spans(line, spans, r'(?<==)', '\033[37m', 'key-value-pairs', opts)
    add_spans(line, spans, r'(?<![\w.-])-?\d+(?:\.\d+)?(?![\w.-])', '\033[36m', 'numbers', opts)
    add_spans(line, spans, r'/(?:[A-Za-z0-9_.-]+/?)+', '\033[32m', 'paths', opts)

    if not spans:
        return line
    spans.sort(key=lambda x: (x[0], -(x[1]-x[0])))
    chosen = []
    last = -1
    for s, e, c in spans:
        if s < last:
            continue
        chosen.append((s, e, c)); last = e
    out = []
    pos = 0
    for s, e, c in chosen:
        out.append(line[pos:s]); out.append(c); out.append(line[s:e]); out.append(RESET); pos = e
    out.append(line[pos:])
    return ''.join(out)


def highlight_text(text, opts):
    return ''.join(highlight_line(part, opts) for part in text.splitlines(True))


def read_input(opts):
    if opts.exec_cmd:
        proc = subprocess.run(opts.exec_cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        return proc.stdout, proc.returncode
    if opts.file:
        try:
            with open(opts.file, 'r', errors='replace') as f:
                return f.read(), 0
        except OSError as e:
            sys.stderr.write(f"Error:   ⚠ \033[33m{opts.file}\033[0m: {e.strerror}\n\n")
            return None, 1
    return sys.stdin.read(), 0


def output_text(text, opts):
    if opts.print_out or not opts.file or opts.exec_cmd:
        sys.stdout.write(text)
        return 0
    pager = opts.pager or os.environ.get('TAILSPIN_PAGER') or 'less -R [FILE]'
    if '[FILE]' not in pager:
        sys.stderr.write('Error:   × Could not parse custom pager command\n\n')
        return 1
    import tempfile
    with tempfile.NamedTemporaryFile('w', delete=False, errors='replace') as tf:
        tf.write(text)
        name = tf.name
    try:
        cmd = pager.replace('[FILE]', shlex.quote(name))
        return subprocess.call(cmd, shell=True)
    finally:
        try: os.unlink(name)
        except OSError: pass


def follow_file(path, opts):
    try:
        with open(path, 'r', errors='replace') as f:
            sys.stdout.write(highlight_text(f.read(), opts)); sys.stdout.flush()
            while True:
                chunk = f.read()
                if chunk:
                    sys.stdout.write(highlight_text(chunk, opts)); sys.stdout.flush()
                time.sleep(0.5)
    except KeyboardInterrupt:
        return 0
    except OSError as e:
        sys.stderr.write(f"Error:   ⚠ \033[33m{path}\033[0m: {e.strerror}\n\n")
        return 1


def main(argv):
    opts = parse_args(argv)
    if opts.follow and opts.file and not opts.print_out:
        return follow_file(opts.file, opts)
    text, rc = read_input(opts)
    if text is None:
        return rc
    out = highlight_text(text, opts)
    prc = output_text(out, opts)
    return rc if rc else prc

if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
