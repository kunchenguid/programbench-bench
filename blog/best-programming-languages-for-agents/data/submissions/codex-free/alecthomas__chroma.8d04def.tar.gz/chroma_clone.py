#!/usr/bin/env python3
import html
import json
import os
import re
import sys

HELP = """Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
"""

LEXERS = [
    ("ABAP", ["abap"], ["*.abap", "*.ABAP"], ["text/x-abap"]),
    ("Bash", ["bash", "sh", "shell"], ["*.sh", "*.bash", ".bashrc"], ["application/x-sh", "text/x-sh"]),
    ("C", ["c"], ["*.c", "*.h"], ["text/x-c"]),
    ("C++", ["cpp", "c++"], ["*.cpp", "*.cxx", "*.cc", "*.hpp"], ["text/x-c++hdr", "text/x-c++src"]),
    ("CSS", ["css"], ["*.css"], ["text/css"]),
    ("Diff", ["diff", "udiff"], ["*.diff", "*.patch"], ["text/x-diff"]),
    ("Go", ["go", "golang"], ["*.go"], ["text/x-gosrc"]),
    ("HTML", ["html"], ["*.html", "*.htm"], ["text/html"]),
    ("INI", ["ini"], ["*.ini", "*.cfg"], ["text/x-ini"]),
    ("Java", ["java"], ["*.java"], ["text/x-java"]),
    ("JavaScript", ["js", "javascript"], ["*.js", "*.mjs", "*.cjs"], ["application/javascript", "text/javascript"]),
    ("JSON", ["json"], ["*.json"], ["application/json"]),
    ("markdown", ["md", "markdown"], ["*.md", "*.markdown"], ["text/x-markdown"]),
    ("Makefile", ["make", "makefile"], ["Makefile", "makefile", "*.mk"], ["text/x-makefile"]),
    ("Perl", ["perl", "pl"], ["*.pl", "*.pm"], ["text/x-perl"]),
    ("PHP", ["php"], ["*.php"], ["text/x-php"]),
    ("plaintext", ["text", "plain"], ["*.txt"], ["text/plain"]),
    ("Python", ["python", "py"], ["*.py", "*.pyw"], ["text/x-python"]),
    ("Ruby", ["ruby", "rb"], ["*.rb"], ["text/x-ruby"]),
    ("Rust", ["rust", "rs"], ["*.rs"], ["text/x-rustsrc"]),
    ("SQL", ["sql"], ["*.sql"], ["text/x-sql"]),
    ("TOML", ["toml"], ["*.toml"], ["application/toml"]),
    ("TypeScript", ["ts", "typescript"], ["*.ts", "*.tsx"], ["application/typescript"]),
    ("XML", ["xml"], ["*.xml", "*.xsl", "*.rss", "*.svg"], ["text/xml", "application/xml"]),
    ("YAML", ["yaml"], ["*.yaml", "*.yml"], ["text/x-yaml"]),
]

STYLES = "abap algol algol_nu arduino ashen aura-theme-dark aura-theme-dark-soft autumn average base16-snazzy borland bw catppuccin-frappe catppuccin-latte catppuccin-macchiato catppuccin-mocha colorful darcula doom-one doom-one2 dracula emacs evergarden friendly fruity github github-dark gruvbox gruvbox-light hr_high_contrast hrdark igor kanagawa-dragon kanagawa-lotus kanagawa-wave lovelace manni modus-operandi modus-vivendi monokai monokailight murphy native nord nordic onedark onesenterprise paraiso-dark paraiso-light pastie perldoc pygments rainbow_dash rose-pine rose-pine-dawn rose-pine-moon rpgle rrt solarized-dark solarized-dark256 solarized-light swapoff tango tokyonight-day tokyonight-moon tokyonight-night tokyonight-storm trac vim vs vulcan witchhazel xcode xcode-dark".split()
FORMATTERS = "html json noop svg terminal terminal16 terminal16m terminal256 terminal8 tokens".split()

KEYWORDS = {
    "go": {"package": "KeywordNamespace", "import": "KeywordNamespace", "func": "KeywordDeclaration", "var": "KeywordDeclaration", "const": "KeywordDeclaration", "type": "KeywordDeclaration", "return": "Keyword", "if": "Keyword", "else": "Keyword", "for": "Keyword", "range": "Keyword", "switch": "Keyword", "case": "Keyword", "default": "Keyword", "go": "Keyword", "defer": "Keyword", "struct": "Keyword", "interface": "Keyword", "map": "Keyword", "chan": "Keyword", "select": "Keyword", "break": "Keyword", "continue": "Keyword", "fallthrough": "Keyword", "println": "NameBuiltin", "print": "NameBuiltin", "make": "NameBuiltin", "new": "NameBuiltin", "len": "NameBuiltin", "cap": "NameBuiltin", "append": "NameBuiltin", "true": "KeywordConstant", "false": "KeywordConstant", "nil": "KeywordConstant"},
    "python": {"def": "Keyword", "class": "Keyword", "return": "Keyword", "if": "Keyword", "elif": "Keyword", "else": "Keyword", "for": "Keyword", "while": "Keyword", "try": "Keyword", "except": "Keyword", "finally": "Keyword", "with": "Keyword", "as": "Keyword", "import": "KeywordNamespace", "from": "KeywordNamespace", "pass": "Keyword", "break": "Keyword", "continue": "Keyword", "yield": "Keyword", "lambda": "Keyword", "in": "OperatorWord", "is": "OperatorWord", "and": "OperatorWord", "or": "OperatorWord", "not": "OperatorWord", "None": "KeywordConstant", "True": "KeywordConstant", "False": "KeywordConstant", "print": "NameBuiltin", "len": "NameBuiltin", "range": "NameBuiltin", "str": "NameBuiltin", "int": "NameBuiltin"},
    "js": {"function": "KeywordDeclaration", "const": "KeywordDeclaration", "let": "KeywordDeclaration", "var": "KeywordDeclaration", "return": "Keyword", "if": "Keyword", "else": "Keyword", "for": "Keyword", "while": "Keyword", "class": "Keyword", "new": "Keyword", "import": "KeywordNamespace", "export": "KeywordNamespace", "from": "KeywordNamespace", "true": "KeywordConstant", "false": "KeywordConstant", "null": "KeywordConstant", "undefined": "NameBuiltin", "console": "NameBuiltin"},
    "c": {"int": "KeywordType", "char": "KeywordType", "void": "KeywordType", "long": "KeywordType", "short": "KeywordType", "float": "KeywordType", "double": "KeywordType", "return": "Keyword", "if": "Keyword", "else": "Keyword", "for": "Keyword", "while": "Keyword", "do": "Keyword", "switch": "Keyword", "case": "Keyword", "break": "Keyword", "continue": "Keyword", "struct": "Keyword", "typedef": "Keyword", "const": "KeywordDeclaration", "static": "KeywordDeclaration", "printf": "NameBuiltin"},
}

CLASS = {
    "Keyword": "k", "KeywordNamespace": "kn", "KeywordDeclaration": "kd",
    "KeywordType": "kt", "KeywordConstant": "kc", "NameOther": "nx",
    "NameFunction": "nf", "NameBuiltin": "nb", "NameAttribute": "na",
    "LiteralString": "s", "LiteralStringDouble": "s2", "LiteralStringSingle": "s1",
    "LiteralNumberInteger": "mi", "LiteralNumberFloat": "mf",
    "Comment": "c", "CommentSingle": "c1", "Operator": "o",
    "OperatorWord": "ow", "Punctuation": "p", "Text": "", "TextWhitespace": "w",
    "GenericHeading": "gh", "GenericDeleted": "gd", "GenericInserted": "gi",
}

ANSI16 = {
    "Keyword": "\033[1m\033[31m", "KeywordNamespace": "\033[1m\033[31m",
    "KeywordDeclaration": "\033[1m\033[36m", "KeywordType": "\033[1m\033[36m",
    "NameFunction": "\033[1m\033[33m", "NameOther": "\033[1m\033[33m",
    "NameBuiltin": "\033[1m\033[37m", "LiteralString": "\033[32m",
    "LiteralStringDouble": "\033[32m", "LiteralStringSingle": "\033[32m",
    "LiteralNumberInteger": "\033[33m", "LiteralNumberFloat": "\033[33m",
    "Comment": "\033[2m\033[37m", "CommentSingle": "\033[2m\033[37m",
    "Punctuation": "\033[1m\033[37m", "Operator": "\033[1m\033[37m",
    "TextWhitespace": "\033[1m\033[37m", "Text": "\033[1m\033[37m",
}


def die(msg, status=80):
    print(f"executable: error: {msg}", file=sys.stderr)
    sys.exit(status)


def parse(argv):
    opts = {
        "lexer": "autodetect", "style": "swapoff", "formatter": "terminal",
        "filename": None, "fail": False, "check": False, "trace": False,
        "html_only": False, "html_styles": False, "html_inline": False,
        "html_lines": False, "html_lines_table": False, "html_prefix": "",
        "html_base_line": 1, "html_prevent_pre": False,
    }
    files = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP, end="")
            sys.exit(0)
        if a == "--version":
            print("?-?-?")
            sys.exit(0)
        if a == "--list":
            opts["list"] = True
        elif a == "--json":
            opts["formatter"] = "json"
        elif a == "--html":
            opts["formatter"] = "html"
        elif a == "--svg":
            opts["formatter"] = "svg"
        elif a in ("--unbuffered",):
            pass
        elif a == "--trace":
            opts["trace"] = True
        elif a == "--check":
            opts["check"] = True
        elif a == "--fail":
            opts["fail"] = True
        elif a in ("-l", "--lexer", "-s", "--style", "-f", "--formatter", "--filename"):
            i += 1
            if i >= len(argv):
                die(f"{a}: expected argument")
            val = argv[i]
            if a in ("-l", "--lexer"):
                opts["lexer"] = val
            elif a in ("-s", "--style"):
                opts["style"] = val
            elif a in ("-f", "--formatter"):
                opts["formatter"] = val
            else:
                opts["filename"] = val
        elif a.startswith("--lexer="):
            opts["lexer"] = a.split("=", 1)[1]
        elif a.startswith("--style="):
            opts["style"] = a.split("=", 1)[1]
        elif a.startswith("--formatter="):
            opts["formatter"] = a.split("=", 1)[1]
        elif a.startswith("--filename="):
            opts["filename"] = a.split("=", 1)[1]
        elif a == "--html-only":
            opts["html_only"] = True
        elif a == "--html-styles" or a == "--html-all-styles":
            opts["html_styles"] = True
        elif a == "--html-inline-styles":
            opts["html_inline"] = True
        elif a == "--html-lines":
            opts["html_lines"] = True
        elif a == "--html-lines-table":
            opts["html_lines_table"] = True
            opts["html_lines"] = True
        elif a == "--html-prevent-surrounding-pre":
            opts["html_prevent_pre"] = True
        elif a.startswith("--html-prefix="):
            opts["html_prefix"] = a.split("=", 1)[1]
        elif a.startswith("--html-base-line="):
            try:
                opts["html_base_line"] = int(a.split("=", 1)[1])
            except ValueError:
                die(f"{a}: invalid value")
        elif a.startswith("--html-"):
            if "=" in a or a in ("--html-linkable-lines",):
                pass
            else:
                die(f"unknown flag {a}")
        elif a.startswith("-"):
            die(f"unknown flag {a}")
        else:
            files.append(a)
        i += 1
    return opts, files


def print_list():
    print("lexers:")
    for name, aliases, filenames, mimetypes in LEXERS:
        print(f"  {name}")
        if aliases:
            print("    aliases: " + " ".join(aliases))
        if filenames:
            print("    filenames: " + " ".join(filenames))
        if mimetypes:
            print("    mimetypes: " + " ".join(mimetypes))
    print()
    print("styles: " + " ".join(STYLES))
    print("formatters: " + " ".join(FORMATTERS))


def lexer_from_name(name):
    n = name.lower()
    if n in ("autodetect", ""):
        return None
    for lang, aliases, _, _ in LEXERS:
        if n == lang.lower() or n in aliases:
            if lang == "Go": return "go"
            if lang == "Python": return "python"
            if lang in ("JavaScript", "TypeScript"): return "js"
            if lang in ("C", "C++", "Java", "Rust"): return "c"
            if lang == "JSON": return "json"
            if lang == "HTML": return "html"
            if lang == "CSS": return "css"
            if lang == "Bash": return "bash"
            if lang == "Diff": return "diff"
            return "text"
    return "text"


def detect(filename, text, explicit):
    if explicit and explicit != "autodetect":
        return lexer_from_name(explicit) or "text", True
    fn = filename or ""
    low = os.path.basename(fn).lower()
    ext = os.path.splitext(low)[1]
    mapping = {
        ".go": "go", ".py": "python", ".pyw": "python", ".js": "js", ".mjs": "js",
        ".ts": "js", ".tsx": "js", ".c": "c", ".h": "c", ".cpp": "c", ".cc": "c",
        ".rs": "c", ".java": "c", ".json": "json", ".html": "html", ".htm": "html",
        ".css": "css", ".sh": "bash", ".bash": "bash", ".diff": "diff", ".patch": "diff",
        ".md": "text", ".txt": "text", ".xml": "html", ".yaml": "text", ".yml": "text",
    }
    if low in ("makefile",):
        return "text", True
    if ext in mapping:
        return mapping[ext], mapping[ext] != "text" or ext in (".txt", ".md")
    s = text.lstrip()
    if s.startswith("{") or s.startswith("["):
        return "json", False
    if s.startswith("<!doctype") or s.startswith("<html") or s.startswith("<?xml"):
        return "html", False
    return "text", False


TOKEN_RE = re.compile(r"(\s+|//[^\n]*|#[^\n]*|/\*.*?\*/|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'|`(?:\\.|[^`\\])*`|\d+\.\d+|\d+|[A-Za-z_][A-Za-z0-9_]*|==|!=|<=|>=|:=|&&|\|\||[{}()\[\],.;]+|[:+\-*/%=<>!&|^~])", re.S)


def lex(text, lang):
    if lang == "text":
        return [("Text", text)] if text else []
    if lang == "json":
        return lex_json(text)
    if lang == "html":
        return lex_html(text)
    if lang == "diff":
        return lex_diff(text)
    kw = KEYWORDS.get(lang, {})
    out = []
    pos = 0
    for m in TOKEN_RE.finditer(text):
        if m.start() > pos:
            out.append(("Text", text[pos:m.start()]))
        v = m.group(0)
        if v.isspace():
            t = "TextWhitespace"
        elif v.startswith("//") or v.startswith("#") or v.startswith("/*"):
            t = "CommentSingle" if not v.startswith("/*") else "Comment"
        elif v[0] in "\"'`":
            t = "LiteralStringDouble" if v[0] == '"' else "LiteralStringSingle"
        elif re.fullmatch(r"\d+\.\d+", v):
            t = "LiteralNumberFloat"
        elif v.isdigit():
            t = "LiteralNumberInteger"
        elif re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", v):
            t = kw.get(v, "NameOther")
            if lang == "go" and out and out[-1] == ("KeywordDeclaration", "func"):
                t = "NameFunction"
        elif re.fullmatch(r"[{}()\[\],.;]+", v):
            t = "Punctuation"
        else:
            t = "Operator"
        out.append((t, v))
        pos = m.end()
    if pos < len(text):
        out.append(("Text", text[pos:]))
    if lang == "go":
        for idx, (t, v) in enumerate(out[:-1]):
            if t == "KeywordDeclaration" and v == "func":
                j = idx + 1
                while j < len(out) and out[j][0] == "TextWhitespace":
                    j += 1
                if j < len(out) and out[j][0] == "NameOther":
                    out[j] = ("NameFunction", out[j][1])
    return out


def lex_json(text):
    raw = lex(text, "js")
    out = []
    for i, (t, v) in enumerate(raw):
        if t == "NameOther" and v in ("true", "false", "null"):
            t = "KeywordConstant"
        elif t in ("LiteralStringDouble", "LiteralStringSingle"):
            j = i + 1
            while j < len(raw) and raw[j][0] == "TextWhitespace":
                j += 1
            if j < len(raw) and raw[j][1] == ":":
                t = "NameTag"
        elif v == ":":
            t = "Punctuation"
        elif t == "TextWhitespace" and "\n" in v:
            t = "Text"
        out.append((t, v))
    return out


def lex_html(text):
    out = []
    pos = 0
    for m in re.finditer(r"<!--.*?-->|</?[A-Za-z][^>]*>|&[A-Za-z0-9#]+;", text, re.S):
        if m.start() > pos:
            out.append(("Text", text[pos:m.start()]))
        v = m.group(0)
        out.append(("Comment" if v.startswith("<!--") else "NameTag", v))
        pos = m.end()
    if pos < len(text):
        out.append(("Text", text[pos:]))
    return out


def lex_diff(text):
    out = []
    for line in text.splitlines(True):
        if line.startswith("+") and not line.startswith("+++"):
            out.append(("GenericInserted", line))
        elif line.startswith("-") and not line.startswith("---"):
            out.append(("GenericDeleted", line))
        elif line.startswith("@@"):
            out.append(("GenericHeading", line))
        else:
            out.append(("Text", line))
    return out


def ansi_for(ttype, formatter):
    if formatter == "terminal16m":
        colors = {
            "KeywordNamespace": "\033[38;2;249;38;114m", "KeywordDeclaration": "\033[38;2;102;217;239m",
            "Keyword": "\033[38;2;249;38;114m", "NameOther": "\033[38;2;166;226;46m",
            "NameFunction": "\033[38;2;166;226;46m", "LiteralNumberInteger": "\033[38;2;174;129;255m",
            "LiteralStringDouble": "\033[38;2;230;219;116m", "LiteralStringSingle": "\033[38;2;230;219;116m",
            "Comment": "\033[38;2;117;113;94m", "CommentSingle": "\033[38;2;117;113;94m",
            "TextWhitespace": "\033[38;2;248;248;242m", "Text": "\033[38;2;248;248;242m",
            "Punctuation": "\033[38;2;248;248;242m", "Operator": "\033[38;2;249;38;114m",
        }
        return colors.get(ttype, "\033[38;2;248;248;242m")
    return ANSI16.get(ttype, "\033[1m\033[37m")


def fmt_terminal(tokens, formatter):
    return "".join(ansi_for(t, formatter) + v + "\033[0m" for t, v in tokens)


def fmt_json(tokens):
    if not tokens:
        return "[]"
    rows = [f'  {json.dumps({"type": t, "value": v}, separators=(",", ":"))}' for t, v in tokens]
    return "[\n" + ",\n".join(rows) + "\n]"


def fmt_tokens(tokens):
    return "".join(f"{t:30} {v!r}\n" for t, v in tokens)


def html_span(ttype, val, opts):
    esc = html.escape(val)
    if opts["html_inline"]:
        style = {
            "KeywordNamespace": "color:#f92672", "KeywordDeclaration": "color:#66d9ef",
            "Keyword": "color:#f92672", "NameOther": "color:#a6e22e",
            "NameFunction": "color:#a6e22e", "LiteralNumberInteger": "color:#ae81ff",
            "LiteralStringDouble": "color:#e6db74", "LiteralStringSingle": "color:#e6db74",
            "Comment": "color:#75715e", "CommentSingle": "color:#75715e",
        }.get(ttype)
        return f'<span style="{style}">{esc}</span>' if style else esc
    cls = CLASS.get(ttype, "")
    if not cls:
        return esc
    return f'<span class="{opts["html_prefix"]}{cls}">{esc}</span>'


def fmt_html(tokens, opts):
    if opts["html_styles"]:
        return "/* Chroma highlighting styles */\n.chroma { background-color: #272822; color: #f8f8f2 }\n.chroma .k,.chroma .kn { color: #f92672 }\n.chroma .kd { color: #66d9ef }\n"
    def line_wrapped():
        parts = ['<span class="line"><span class="cl">']
        pieces = []
        for t, v in tokens:
            for chunk in v.splitlines(True):
                pieces.append((t, chunk))
        for idx, (t, chunk) in enumerate(pieces):
            parts.append(html_span(t, chunk, opts))
            if chunk.endswith("\n") and idx != len(pieces) - 1:
                    parts.append('</span></span><span class="line"><span class="cl">')
        parts.append('</span></span>')
        return "".join(parts)

    body = "".join(html_span(t, v, opts) for t, v in tokens)
    if opts["html_lines"] or opts["html_lines_table"]:
        lines = body.splitlines(True)
        n = opts["html_base_line"]
        rendered = []
        for line in lines or [""]:
            rendered.append(f'<span class="ln">{n}</span><span class="cl">{line}</span>')
            n += 1
        body = '<span class="line">' + '</span><span class="line">'.join(rendered) + '</span>'
    else:
        body = line_wrapped()
    if opts["html_prevent_pre"]:
        return body
    return f'<pre class="chroma"><code>{body}</code></pre>'


def fmt_svg(tokens):
    text = html.escape("".join(v for _, v in tokens))
    lines = text.splitlines() or [""]
    tspans = []
    y = 20
    for line in lines:
        tspans.append(f'<text x="10" y="{y}" font-family="monospace" font-size="14">{line}</text>')
        y += 18
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="800" height="{y}">' + "".join(tspans) + "</svg>"


def format_tokens(tokens, opts):
    f = opts["formatter"]
    if f in ("terminal", "terminal16", "terminal256", "terminal8", "terminal16m"):
        return fmt_terminal(tokens, f)
    if f == "json":
        return fmt_json(tokens) + "\n"
    if f == "html":
        return fmt_html(tokens, opts)
    if f == "svg":
        return fmt_svg(tokens)
    if f == "tokens":
        return fmt_tokens(tokens)
    if f == "noop":
        return "".join(v for _, v in tokens)
    die(f"unknown formatter {f}")


def normalize_tokens(tokens, lang):
    if lang == "python":
        return [("Text" if t == "TextWhitespace" and "\n" in v else t, v) for t, v in tokens]
    return tokens


def main():
    opts, files = parse(sys.argv[1:])
    if opts.get("list"):
        print_list()
        return
    def check_style():
        if opts["style"] == "swapoff" and opts["formatter"] not in ("json", "noop", "tokens"):
            die("open swapoff: no such file or directory", 1)
        if opts["style"] not in STYLES and not os.path.exists(opts["style"]):
            die(f"open {opts['style']}: no such file or directory", 1)

    if not files:
        text = sys.stdin.read()
        lang, specific = detect(opts["filename"], text, opts["lexer"])
        check_style()
        if opts["fail"] and not specific:
            sys.exit(1)
        tokens = normalize_tokens(lex(text, lang), lang)
        sys.stdout.write(format_tokens(tokens, opts))
        return
    for path in files:
        if not os.path.exists(path):
            die(f"[<files> ...]: stat {path}: no such file or directory")
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError as e:
            die(f"[<files> ...]: {e}")
        lang, specific = detect(path, text, opts["lexer"])
        if opts["fail"] and not specific:
            sys.exit(1)
        if opts["check"]:
            continue
        check_style()
        tokens = normalize_tokens(lex(text, lang), lang)
        sys.stdout.write(format_tokens(tokens, opts))


if __name__ == "__main__":
    main()
