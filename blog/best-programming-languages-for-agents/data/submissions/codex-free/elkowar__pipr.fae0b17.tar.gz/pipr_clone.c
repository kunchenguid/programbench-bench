#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <termios.h>
#include <unistd.h>

static const char *HELP =
"Usage: ./executable [options]\n"
"\n"
"Options:\n"
"    -d, --default TEXT  text inserted into the textfield on startup\n"
"    -o, --out-file FILE write final command to file\n"
"        --in-file FILE  read initial command from file\n"
"        --config-reference \n"
"                        print out the default configuration file\n"
"    -r, --raw-mode      keep linebreaks in finished command when closing\n"
"        --no-isolation  disable isolation. This will run the commands directly\n"
"                        on your system, without protection. Take care.\n"
"    -h, --help          print this help menu\n";

static const char *CONFIG =
"\n"
"#  ____  _\n"
"# |  _ \\(_)_ __  _ __       .________.\n"
"# | |_) | | '_ \\| '__|      |________|\n"
"# |  __/| | |_) | |          |_    -|\n"
"# |_|   |_| .__/|_|     xX  xXx___x_|\n"
"#         |_|\n"
"#\n"
"# A commandline utility by\n"
"# Leon Kowarschick\n"
"\n"
"# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.\n"
"# finish_hook = \"xclip -selection clipboard -in\"\n"
"\n"
"# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.\n"
"paranoid_history_mode_default = false\n"
"\n"
"autoeval_mode_default = true\n"
"\n"
"history_size = 500\n"
"cmdlist_always_show_preview = false\n"
"cmd_timeout_millis = 2000\n"
"\n"
"highlighting_enabled = true\n"
"\n"
"eval_environment = [\"bash\", \"-c\"]\n"
"\n"
"# Snippets can be used to quickly insert common bits of shell\n"
"# use || (two pipes) where you want your cursor to be after insertion\n"
"[snippets]\n"
"s = \" | sed -r 's/||//g'\"\n"
"\n"
"[help_viewers]\n"
"'m' = \"man ??\"\n"
"'h' = \"?? --help | less\"\n"
"\n"
"[output_viewers]\n"
"'l' = \"less\"\n"
"\n";

struct opts {
    char *def;
    char *outfile;
    char *infile;
    bool config;
    bool raw;
    bool noiso;
    bool help;
};

static void die_opt(const char *fmt, const char *arg) {
    fprintf(stderr, fmt, arg);
    fputc('\n', stderr);
    exit(1);
}

static bool exists_on_path(const char *name) {
    char *path = getenv("PATH");
    if (!path) return false;
    char *copy = strdup(path), *save = NULL;
    for (char *p = strtok_r(copy, ":", &save); p; p = strtok_r(NULL, ":", &save)) {
        char buf[4096];
        snprintf(buf, sizeof(buf), "%s/%s", *p ? p : ".", name);
        if (access(buf, X_OK) == 0) {
            free(copy);
            return true;
        }
    }
    free(copy);
    return false;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        printf("Error: %s (os error %d)\n", strerror(errno), errno);
        exit(1);
    }
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return strdup(""); }
    long n = ftell(f);
    if (n < 0) n = 0;
    rewind(f);
    char *s = calloc((size_t)n + 1, 1);
    if (!s) exit(1);
    size_t got = fread(s, 1, (size_t)n, f);
    s[got] = 0;
    n = (long)got;
    fclose(f);
    while (n > 0 && (s[n - 1] == '\n' || s[n - 1] == '\r')) s[--n] = 0;
    return s;
}

static char *finish_text(const char *s, bool raw) {
    char *out = strdup(s ? s : "");
    if (!out) exit(1);
    if (!raw) {
        for (char *p = out; *p; p++) {
            if (*p == '\n' || *p == '\r') *p = ' ';
        }
    }
    return out;
}

static void parse(int argc, char **argv, struct opts *o) {
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) o->help = true;
        else if (!strcmp(a, "--config-reference")) {
            if (o->config) die_opt("./executable: Option '%s' given more than once", "config-reference");
            o->config = true;
        } else if (!strcmp(a, "-r") || !strcmp(a, "--raw-mode")) {
            if (o->raw) die_opt("./executable: Option '%s' given more than once", "raw-mode");
            o->raw = true;
        } else if (!strcmp(a, "--no-isolation")) {
            if (o->noiso) die_opt("./executable: Option '%s' given more than once", "no-isolation");
            o->noiso = true;
        } else if (!strcmp(a, "-d") || !strcmp(a, "--default")) {
            if (o->def) die_opt("./executable: Option '%s' given more than once", "default");
            if (++i >= argc) die_opt("./executable: Argument to option '%s' missing", a[1] == '-' ? "default" : "d");
            o->def = argv[i];
        } else if (!strncmp(a, "--default=", 10)) {
            if (o->def) die_opt("./executable: Option '%s' given more than once", "default");
            o->def = a + 10;
        } else if (!strncmp(a, "-d", 2) && a[2]) {
            if (o->def) die_opt("./executable: Option '%s' given more than once", "default");
            o->def = a + 2;
        } else if (!strcmp(a, "-o") || !strcmp(a, "--out-file")) {
            if (o->outfile) die_opt("./executable: Option '%s' given more than once", "out-file");
            if (++i >= argc) die_opt("./executable: Argument to option '%s' missing", a[1] == '-' ? "out-file" : "o");
            o->outfile = argv[i];
        } else if (!strncmp(a, "--out-file=", 11)) {
            if (o->outfile) die_opt("./executable: Option '%s' given more than once", "out-file");
            o->outfile = a + 11;
        } else if (!strncmp(a, "-o", 2) && a[2]) {
            if (o->outfile) die_opt("./executable: Option '%s' given more than once", "out-file");
            o->outfile = a + 2;
        } else if (!strcmp(a, "--in-file")) {
            if (o->infile) die_opt("./executable: Option '%s' given more than once", "in-file");
            if (++i >= argc) die_opt("./executable: Argument to option '%s' missing", "in-file");
            o->infile = argv[i];
        } else if (!strncmp(a, "--in-file=", 10)) {
            if (o->infile) die_opt("./executable: Option '%s' given more than once", "in-file");
            o->infile = a + 10;
        } else if (a[0] == '-') {
            if (!strcmp(a, "-rr")) die_opt("./executable: Option '%s' given more than once", "raw-mode");
            die_opt("./executable: Unrecognized option: '%s'", a + (a[1] == '-' ? 2 : 1));
        }
    }
}

static void redraw(const char *cmd) {
    printf("\033[?1049h\033[2J\033[2;2H┌ Command [Autoeval] ");
    for (int i = 0; i < 54; i++) printf("─");
    printf("┐\033[3;2H│%-76.76s│\033[4;2H└", cmd);
    for (int i = 0; i < 76; i++) printf("─");
    printf("┘\033[5;2H┌ Output [+] ");
    for (int i = 0; i < 64; i++) printf("─");
    printf("┐\033[23;2H└");
    for (int i = 0; i < 66; i++) printf("─");
    printf("Help:\033[23;75HF1──┘\033[3;3H");
    fflush(stdout);
}

static char *run_ui(char *initial) {
    int tty = isatty(STDIN_FILENO) ? dup(STDIN_FILENO) : open("/dev/tty", O_RDWR);
    if (tty < 0) {
        fprintf(stderr, "\033[?1049hError: %s (os error %d)\n", strerror(errno), errno);
        exit(1);
    }
    struct termios oldt, raw;
    tcgetattr(tty, &oldt);
    raw = oldt;
    cfmakeraw(&raw);
    tcsetattr(tty, TCSANOW, &raw);
    size_t cap = strlen(initial) + 128, len = strlen(initial);
    char *cmd = malloc(cap);
    if (!cmd) exit(1);
    memcpy(cmd, initial, len + 1);
    redraw(cmd);
    unsigned char c;
    while (read(tty, &c, 1) == 1) {
        if (c == 3 || c == 27) break;
        if (c == 127 || c == 8) {
            if (len) cmd[--len] = 0;
        } else if (c == '\r' || c == '\n') {
            /* Enter evaluates in pipr; keep the command text unchanged. */
        } else if (c >= 32 || c == '\t') {
            if (len + 2 >= cap) {
                cap *= 2;
                cmd = realloc(cmd, cap);
                if (!cmd) exit(1);
            }
            cmd[len++] = (char)c;
            cmd[len] = 0;
        }
        redraw(cmd);
    }
    tcsetattr(tty, TCSANOW, &oldt);
    printf("\033[?1049l%s\r\n", cmd);
    fflush(stdout);
    close(tty);
    return cmd;
}

int main(int argc, char **argv) {
    struct opts o = {0};
    parse(argc, argv, &o);
    if (o.help) {
        fputs(HELP, stdout);
        return 0;
    }
    if (o.config) {
        fputs(CONFIG, stdout);
        return 0;
    }
    if (!o.noiso && !exists_on_path("bwrap")) {
        puts("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode");
        return 1;
    }
    char *owned = NULL;
    char *initial = o.def ? o.def : "";
    if (o.infile) {
        owned = read_file(o.infile);
        initial = owned;
    }
    char *cmd = run_ui(initial);
    char *final = finish_text(cmd, o.raw);
    if (o.outfile) {
        FILE *f = fopen(o.outfile, "wb");
        if (!f) {
            printf("Error: %s (os error %d)\n", strerror(errno), errno);
            return 1;
        }
        fwrite(final, 1, strlen(final), f);
        fclose(f);
    }
    free(owned);
    free(cmd);
    free(final);
    return 0;
}
