package main

import (
    "bytes"
    "errors"
    "flag"
    "fmt"
    "image"
    "image/color"
    "image/gif"
    "image/jpeg"
    "image/png"
    "io"
    "log"
    "math"
    "net/http"
    "os"
    "strconv"
    "strings"
)

const version = "1.3.2"
const banner = "   ___  _____  ____\n  / _ \\/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau\n / ___// /_>  </ __/ -_) __/  ' \\ https://github.com/eliukblau/pixterm\n/_/  /___/_/|_|\\__\\__/_/ /_/_/_/                1.3.2\n"

var usageText = banner + `
USAGE:

  executable [options] image/url

  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
  Supported URL protocols: HTTP, HTTPS.

OPTIONS:

  -credits
    	show some love to contributors <3
  -d mode
    	dithering mode:
    	   0 - no dithering (default)
    	   1 - with blocks
    	   2 - with chars
  -go
    	output Go code to 'fmt.Print()' the image
  -m color
    	matte color for transparency or background
    	(optional, hex format, default: 000000)
  -nobg
    	disable background color
    	(optional, only in dithering mode, ignores matte color)
  -s method
    	scale method:
    	   0 - resize (default)
    	   1 - fill
    	   2 - fit
  -tc columns
    	terminal columns (optional, >=2; when piping, default: 80)
  -tr rows
    	terminal rows (optional, >=2; when piping, default: 24)
  -version
    	show PIXterm version
  -help
	prints this message :D LOL
`

const creditsText = banner + `
CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.
`

type RGB struct{ R, G, B uint8 }

type opts struct {
    dither int
    scale int
    cols int
    rows int
    matte RGB
    nobg bool
    goout bool
}

func main() {
    log.SetPrefix("[PIXTERM ERROR] ")
    log.SetFlags(log.Ldate | log.Ltime)
    o := opts{cols:80, rows:24, matte:RGB{0,0,0}}
    fs := flag.NewFlagSet(os.Args[0], flag.ContinueOnError)
    fs.SetOutput(io.Discard)
    help := fs.Bool("help", false, "")
    ver := fs.Bool("version", false, "")
    credits := fs.Bool("credits", false, "")
    fs.IntVar(&o.dither, "d", 0, "")
    fs.IntVar(&o.scale, "s", 0, "")
    fs.IntVar(&o.cols, "tc", 80, "")
    fs.IntVar(&o.rows, "tr", 24, "")
    matte := fs.String("m", "000000", "")
    fs.BoolVar(&o.nobg, "nobg", false, "")
    fs.BoolVar(&o.goout, "go", false, "")
    if err := fs.Parse(os.Args[1:]); err != nil { fmt.Print(usageText); os.Exit(2) }
    if *help { fmt.Print(usageText); return }
    if *ver { fmt.Println(version); return }
    if *credits { fmt.Print(creditsText); return }
    if fs.NArg() < 1 { fmt.Print(usageText); return }
    m, err := parseHex(*matte); if err != nil { fmt.Print(banner+"\n"); log.Fatal(err) }
    o.matte = m
    img, err := loadImage(fs.Arg(0)); if err != nil { fmt.Print(banner+"\n"); log.Fatal(err) }
    if o.cols < 2 { o.cols = 2 }; if o.rows < 2 { o.rows = 2 }
    out := render(img, o)
    if o.goout { printGo(out) } else { fmt.Print(out) }
}

func parseHex(s string) (RGB,error) {
    s = strings.TrimPrefix(s, "#")
    if len(s) != 6 { return RGB{}, errors.New("invalid matte color") }
    v, err := strconv.ParseUint(s,16,32); if err != nil { return RGB{}, err }
    return RGB{uint8(v>>16),uint8(v>>8),uint8(v)}, nil
}

func loadImage(path string) (image.Image,error) {
    var data []byte; var err error
    if strings.HasPrefix(path,"http://") || strings.HasPrefix(path,"https://") {
        resp, e := http.Get(path); if e != nil { return nil,e }; defer resp.Body.Close()
        data, err = io.ReadAll(resp.Body)
    } else { data, err = os.ReadFile(path) }
    if err != nil { return nil, err }
    if img, _, err := image.Decode(bytes.NewReader(data)); err == nil { return img,nil }
    if img, err := png.Decode(bytes.NewReader(data)); err == nil { return img,nil }
    if img, err := jpeg.Decode(bytes.NewReader(data)); err == nil { return img,nil }
    if img, err := gif.Decode(bytes.NewReader(data)); err == nil { return img,nil }
    if img, err := decodeBMP(data); err == nil { return img,nil }
    return nil, errors.New("image: unknown format")
}

func render(src image.Image, o opts) string {
    tw, th := o.cols, o.rows
    if o.dither == 0 { th = o.rows*2 }
    if tw < 1 { tw = 1 }; if th < 1 { th = 1 }
    pix := scaleCanvas(src, tw, th, o.scale, o.matte)
    var sb strings.Builder
    if o.dither == 0 {
        rows := th/2
        if th%2 != 0 { rows++ }
        for y:=0; y<rows; y++ {
            for x:=0; x<tw; x++ {
                top := pix[min(y*2,th-1)][x]
                bot := pix[min(y*2+1,th-1)][x]
                fmt.Fprintf(&sb,"\x1b[48;2;%d;%d;%dm\x1b[38;2;%d;%d;%dm▄", top.R,top.G,top.B, bot.R,bot.G,bot.B)
            }
            sb.WriteString("\x1b[0m\n")
        }
    } else {
        for y:=0; y<th; y++ {
            for x:=0; x<tw; x++ {
                c := pix[y][x]
                ch := shade(c, o.dither)
                if !o.nobg { fmt.Fprintf(&sb,"\x1b[48;2;%d;%d;%dm", o.matte.R,o.matte.G,o.matte.B) }
                fmt.Fprintf(&sb,"\x1b[38;2;%d;%d;%dm%s", c.R,c.G,c.B,ch)
            }
            sb.WriteString("\x1b[0m\n")
        }
    }
    return sb.String()
}

func scaleCanvas(src image.Image, w,h, mode int, matte RGB) [][]RGB {
    b:=src.Bounds(); sw,sh:=b.Dx(),b.Dy()
    if mode == 0 { return resizeLanczos(src,w,h,matte) }
    rw := float64(w)/float64(sw); rh := float64(h)/float64(sh)
    r := rw
    if mode == 1 { if rh > r { r = rh } } else { if rh < r { r = rh } }
    nw,nh := int(math.Round(float64(sw)*r)), int(math.Round(float64(sh)*r))
    if nw<1 {nw=1}; if nh<1 {nh=1}
    scaled := resizeLanczos(src,nw,nh,matte)
    out:=make([][]RGB,h); for y:=range out { out[y]=make([]RGB,w); for x:=range out[y] { out[y][x]=matte } }
    ox,oy := (w-nw)/2, (h-nh)/2
    for y:=0; y<nh; y++ { dy:=y+oy; if dy<0 || dy>=h {continue}; for x:=0; x<nw; x++ { dx:=x+ox; if dx<0 || dx>=w {continue}; out[dy][dx]=scaled[y][x] } }
    return out
}

func rgbaAt(img image.Image, x,y int, matte RGB) (float64,float64,float64) {
    r,g,b,a := img.At(img.Bounds().Min.X+x,img.Bounds().Min.Y+y).RGBA()
    af := float64(a)/65535.0
    rf := float64(r)/257.0; gf := float64(g)/257.0; bf := float64(b)/257.0
    return rf*af+float64(matte.R)*(1-af), gf*af+float64(matte.G)*(1-af), bf*af+float64(matte.B)*(1-af)
}

func resizeLanczos(img image.Image, w,h int, matte RGB) [][]RGB {
    b:=img.Bounds(); sw,sh:=b.Dx(),b.Dy()
    out:=make([][]RGB,h); for i:=range out { out[i]=make([]RGB,w) }
    if sw==0 || sh==0 { return out }
    for y:=0; y<h; y++ {
        sy := (float64(y)+0.5)*float64(sh)/float64(h)-0.5
        for x:=0; x<w; x++ {
            sx := (float64(x)+0.5)*float64(sw)/float64(w)-0.5
            var rr,gg,bb,wsum float64
            x0:=int(math.Floor(sx))-3; x1:=int(math.Floor(sx))+3
            y0:=int(math.Floor(sy))-3; y1:=int(math.Floor(sy))+3
            for yy:=y0; yy<=y1; yy++ { wy:=lanczos(sy-float64(yy)); if wy==0 {continue}; cy:=clamp(yy,0,sh-1)
                for xx:=x0; xx<=x1; xx++ { wx:=lanczos(sx-float64(xx)); wt:=wx*wy; if wt==0 {continue}; cx:=clamp(xx,0,sw-1)
                    r,g,b:=rgbaAt(img,cx,cy,matte); rr+=r*wt; gg+=g*wt; bb+=b*wt; wsum+=wt
                }
            }
            if wsum != 0 { rr/=wsum; gg/=wsum; bb/=wsum }
            out[y][x]=RGB{to8(rr),to8(gg),to8(bb)}
        }
    }
    return out
}
func lanczos(x float64) float64 { x=math.Abs(x); if x<1e-9 {return 1}; if x>=3 {return 0}; return 3*math.Sin(math.Pi*x)*math.Sin(math.Pi*x/3)/(math.Pi*math.Pi*x*x) }
func to8(v float64) uint8 { if v<0 {v=0}; if v>255 {v=255}; return uint8(math.Floor(v+0.5)) }
func clamp(v,a,b int) int { if v<a {return a}; if v>b {return b}; return v }
func min(a,b int) int { if a<b {return a}; return b }

func shade(c RGB, mode int) string {
    lum := 0.299*float64(c.R)+0.587*float64(c.G)+0.114*float64(c.B)
    if mode == 1 { if lum>210 {return "█"}; if lum>140 {return "▓"}; if lum>70 {return "▒"}; return "░" }
    chars := []string{" ",".",":","-","=","+","*","X","$","#"}
    idx := int(lum/256*float64(len(chars))); if idx<0 {idx=0}; if idx>=len(chars){idx=len(chars)-1}; return chars[idx]
}

func printGo(s string) { for _, line := range strings.SplitAfter(s,"\n") { if line=="" {continue}; q:=strconv.Quote(line); q=strings.ReplaceAll(q,"\\x1b","\\033"); fmt.Printf("fmt.Print(%s)\n", q) } }

func decodeBMP(data []byte) (image.Image,error) {
    if len(data)<54 || string(data[:2])!="BM" { return nil, errors.New("not bmp") }
    off:=int(le32(data[10:])); w:=int(int32(le32(data[18:]))); hraw:=int(int32(le32(data[22:]))); bpp:=int(le16(data[28:])); comp:=le32(data[30:])
    if w<=0 || hraw==0 || comp!=0 || (bpp!=24 && bpp!=32) { return nil, errors.New("unsupported bmp") }
    topDown:=hraw<0; h:=hraw; if h<0 {h=-h}
    img:=image.NewRGBA(image.Rect(0,0,w,h)); stride:=((w*bpp+31)/32)*4
    for y:=0; y<h; y++ { sy:=y; if !topDown { sy=h-1-y }; row:=off+sy*stride; if row<0 || row+stride>len(data){return nil,errors.New("bad bmp")}
        for x:=0; x<w; x++ { p:=row+x*(bpp/8); b,g,r:=data[p],data[p+1],data[p+2]; a:=uint8(255); if bpp==32 {a=data[p+3]}; img.SetRGBA(x,y,color.RGBA{r,g,b,a}) }
    }
    return img,nil
}
func le16(b []byte) uint16 { return uint16(b[0])|uint16(b[1])<<8 }
func le32(b []byte) uint32 { return uint32(b[0])|uint32(b[1])<<8|uint32(b[2])<<16|uint32(b[3])<<24 }
