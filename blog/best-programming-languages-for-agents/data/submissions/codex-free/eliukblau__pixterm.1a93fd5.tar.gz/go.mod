module pixtermclone

go 1.21
