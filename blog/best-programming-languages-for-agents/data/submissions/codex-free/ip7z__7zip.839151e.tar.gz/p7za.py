#!/usr/bin/env python3
import binascii
import ctypes
import fnmatch
import hashlib
import os
import shutil
import stat
import sys
import time


VERSION = """7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12
 64-bit locale=C.UTF-8 Threads:14 OPEN_MAX:1048576"""

HELP = VERSION + """

Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

<Commands>
  a : Add files to archive
  b : Benchmark
  d : Delete files from archive
  e : Extract files from archive (without using directory names)
  h : Calculate hash values for files
  i : Show information about supported formats
  l : List contents of archive
  rn : Rename files in archive
  t : Test integrity of archive
  u : Update files to archive
  x : eXtract files with full paths

<Switches>
  -- : Stop switches and @listfile parsing
  -ao{a|s|t|u} : set Overwrite mode
  -bd : disable progress indicator
  -i... : Include filenames
  -m{Parameters} : set compression Method
  -o{Directory} : set Output directory
  -p{Password} : set Password
  -r[-|0] : Recurse subdirectories for name search
  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands
  -slt : show technical information for l (List) command
  -so : write data to stdout
  -t{Type} : Set type of archive
  -x... : eXclude filenames
  -y : assume Yes on all queries
"""

ARCHIVE_OK = 0
AE_IFREG = 0o100000
AE_IFDIR = 0o040000
AE_IFLNK = 0o120000


def eprint(*args):
    print(*args, file=sys.stderr)


class LibArchive:
    def __init__(self):
        self.lib = ctypes.CDLL("libarchive.so.13")
        c_void = ctypes.c_void_p
        c_char = ctypes.c_char_p
        c_int = ctypes.c_int
        c_long = ctypes.c_long
        c_size = ctypes.c_size_t
        c_ssize = ctypes.c_ssize_t

        for name in ["archive_read_new", "archive_write_new", "archive_entry_new"]:
            getattr(self.lib, name).restype = c_void
        for name in [
            "archive_read_support_format_all", "archive_read_support_filter_all",
            "archive_read_close", "archive_read_free", "archive_write_close",
            "archive_write_free", "archive_write_add_filter_none",
            "archive_write_add_filter_gzip", "archive_write_add_filter_bzip2",
            "archive_write_add_filter_xz", "archive_write_set_format_7zip",
            "archive_write_set_format_zip", "archive_write_set_format_pax_restricted",
            "archive_write_set_format_gnutar", "archive_write_set_format_by_name",
            "archive_write_header", "archive_entry_free",
        ]:
            getattr(self.lib, name).argtypes = [c_void]
            getattr(self.lib, name).restype = c_int
        self.lib.archive_write_header.argtypes = [c_void, c_void]
        self.lib.archive_write_set_format_by_name.argtypes = [c_void, c_char]
        self.lib.archive_entry_free.argtypes = [c_void]
        self.lib.archive_read_open_filename.argtypes = [c_void, c_char, c_size]
        self.lib.archive_read_open_filename.restype = c_int
        self.lib.archive_read_next_header.argtypes = [c_void, ctypes.POINTER(c_void)]
        self.lib.archive_read_next_header.restype = c_int
        self.lib.archive_read_data.argtypes = [c_void, c_void, c_size]
        self.lib.archive_read_data.restype = c_ssize
        self.lib.archive_read_data_skip.argtypes = [c_void]
        self.lib.archive_read_data_skip.restype = c_int
        self.lib.archive_write_open_filename.argtypes = [c_void, c_char]
        self.lib.archive_write_open_filename.restype = c_int
        self.lib.archive_write_data.argtypes = [c_void, c_void, c_size]
        self.lib.archive_write_data.restype = c_ssize
        self.lib.archive_entry_pathname_utf8.argtypes = [c_void]
        self.lib.archive_entry_pathname_utf8.restype = c_char
        self.lib.archive_entry_pathname.argtypes = [c_void]
        self.lib.archive_entry_pathname.restype = c_char
        self.lib.archive_entry_size.argtypes = [c_void]
        self.lib.archive_entry_size.restype = ctypes.c_longlong
        self.lib.archive_entry_filetype.argtypes = [c_void]
        self.lib.archive_entry_filetype.restype = c_int
        self.lib.archive_entry_perm.argtypes = [c_void]
        self.lib.archive_entry_perm.restype = c_int
        self.lib.archive_entry_mtime.argtypes = [c_void]
        self.lib.archive_entry_mtime.restype = c_long
        self.lib.archive_entry_set_pathname.argtypes = [c_void, c_char]
        self.lib.archive_entry_set_size.argtypes = [c_void, ctypes.c_longlong]
        self.lib.archive_entry_set_filetype.argtypes = [c_void, c_int]
        self.lib.archive_entry_set_perm.argtypes = [c_void, c_int]
        self.lib.archive_entry_set_mtime.argtypes = [c_void, c_long, ctypes.c_long]
        self.lib.archive_error_string.argtypes = [c_void]
        self.lib.archive_error_string.restype = c_char

    def err(self, a):
        s = self.lib.archive_error_string(a)
        return s.decode("utf-8", "replace") if s else "unknown archive error"


LA = None


def libarchive():
    global LA
    if LA is None:
        LA = LibArchive()
    return LA


def header(file=sys.stdout):
    print(file=file)
    print(VERSION, file=file)
    print(file=file)


def die(msg, code=2):
    eprint()
    eprint("Error:")
    eprint(msg)
    sys.exit(code)


class Options:
    def __init__(self):
        self.type = None
        self.outdir = "."
        self.stdout = False
        self.recurse = False
        self.yes = False
        self.slt = False
        self.hash = "CRC32"
        self.excludes = []
        self.includes = []
        self.files = []
        self.archive = None


def read_listfile(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return [line.rstrip("\n\r") for line in f if line.rstrip("\n\r")]


def parse(argv):
    if not argv or argv[0] in ("--help", "-h", "-?", "/?"):
        print(HELP)
        sys.exit(0)
    cmd = argv[0].lower()
    opts = Options()
    args = []
    stop = False
    for raw in argv[1:]:
        if raw == "--":
            stop = True
            continue
        if not stop and raw.startswith("@"):
            args.extend(read_listfile(raw[1:]))
            continue
        low = raw.lower()
        if not stop and raw.startswith("-") and raw != "-":
            if low.startswith("-t") and len(raw) > 2:
                opts.type = raw[2:].lower()
            elif low.startswith("-o") and len(raw) > 2:
                opts.outdir = raw[2:]
            elif low == "-so":
                opts.stdout = True
            elif low == "-slt":
                opts.slt = True
            elif low.startswith("-scrc"):
                opts.hash = raw[5:].upper() or "CRC32"
            elif low.startswith("-r"):
                opts.recurse = not low.startswith("-r-")
            elif low == "-y":
                opts.yes = True
            elif low.startswith("-x!") or low.startswith("-x"):
                val = raw[3:] if raw[:3].lower() == "-x!" else raw[2:]
                if val:
                    opts.excludes.append(val)
            elif low.startswith("-i!") or low.startswith("-i"):
                val = raw[3:] if raw[:3].lower() == "-i!" else raw[2:]
                if val:
                    opts.includes.append(val)
            else:
                pass
        else:
            args.append(raw)
    if cmd in ("a", "u", "d", "l", "x", "e", "t", "rn"):
        if not args:
            die("incorrect command line")
        opts.archive = args[0]
        opts.files = args[1:]
    else:
        opts.files = args
    return cmd, opts


def archive_type(path, explicit=None):
    if explicit:
        return explicit
    p = path.lower()
    if p.endswith(".tar.gz") or p.endswith(".tgz"):
        return "tgz"
    if p.endswith(".tar.bz2") or p.endswith(".tbz2"):
        return "tbz2"
    if p.endswith(".tar.xz") or p.endswith(".txz"):
        return "txz"
    ext = os.path.splitext(p)[1].lstrip(".")
    return ext or "7z"


def should_include(name, opts):
    base = os.path.basename(name)
    for pat in opts.excludes:
        if fnmatch.fnmatch(name, pat) or fnmatch.fnmatch(base, pat):
            return False
    if opts.includes:
        return any(fnmatch.fnmatch(name, p) or fnmatch.fnmatch(base, p) for p in opts.includes)
    if opts.files:
        return any(fnmatch.fnmatch(name, p) or fnmatch.fnmatch(base, p) for p in opts.files)
    return True


def open_reader(path):
    la = libarchive()
    a = la.lib.archive_read_new()
    la.lib.archive_read_support_filter_all(a)
    la.lib.archive_read_support_format_all(a)
    r = la.lib.archive_read_open_filename(a, os.fsencode(path), 10240)
    if r != ARCHIVE_OK:
        msg = la.err(a)
        la.lib.archive_read_free(a)
        die(f"Can not open the file as archive: {path}\n{msg}", 1)
    return la, a


def iter_entries(path):
    la, a = open_reader(path)
    entry = ctypes.c_void_p()
    try:
        while True:
            r = la.lib.archive_read_next_header(a, ctypes.byref(entry))
            if r == 1:
                break
            if r < ARCHIVE_OK:
                raise RuntimeError(la.err(a))
            raw = la.lib.archive_entry_pathname_utf8(entry) or la.lib.archive_entry_pathname(entry)
            name = raw.decode("utf-8", "replace") if raw else ""
            size = int(la.lib.archive_entry_size(entry))
            ftype = int(la.lib.archive_entry_filetype(entry))
            perm = int(la.lib.archive_entry_perm(entry))
            mtime = int(la.lib.archive_entry_mtime(entry))
            yield la, a, entry, name, size, ftype, perm, mtime
            la.lib.archive_read_data_skip(a)
    finally:
        la.lib.archive_read_close(a)
        la.lib.archive_read_free(a)


def fmt_size(n):
    if n < 1024:
        return f"{n} bytes"
    return f"{n} bytes ({(n + 1023)//1024} KiB)"


def cmd_list(opts):
    header()
    st = os.stat(opts.archive)
    print("Scanning the drive for archives:")
    print(f"1 file, {fmt_size(st.st_size)}")
    print()
    print(f"Listing archive: {opts.archive}")
    print()
    print("--")
    print(f"Path = {opts.archive}")
    print(f"Type = {archive_type(opts.archive, opts.type)}")
    print(f"Physical Size = {st.st_size}")
    print()
    if opts.slt:
        for _, _, _, name, size, ftype, perm, mtime in iter_entries(opts.archive):
            if not should_include(name, opts):
                continue
            print(f"Path = {name}")
            print(f"Size = {size}")
            print(f"Packed Size = {size}")
            print(f"Modified = {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(mtime)) if mtime else ''}")
            print(f"Attributes = {'D' if ftype == AE_IFDIR else 'A'}")
            print()
        return 0
    print("   Date      Time    Attr         Size   Compressed  Name")
    print("------------------- ----- ------------ ------------  ------------------------")
    total = files = dirs = 0
    for _, _, _, name, size, ftype, perm, mtime in iter_entries(opts.archive):
        if not should_include(name, opts):
            continue
        ts = time.localtime(mtime or 0)
        attr = "D...." if ftype == AE_IFDIR or name.endswith("/") else "....."
        print(f"{time.strftime('%Y-%m-%d %H:%M:%S', ts)} {attr:5} {size:12d} {size:12d}  {name}")
        if attr.startswith("D"):
            dirs += 1
        else:
            files += 1
            total += size
    print("------------------- ----- ------------ ------------  ------------------------")
    tail = f"{files} files" + (f", {dirs} folders" if dirs else "")
    print(f"{'':19}       {total:12d} {total:12d}  {tail}")
    return 0


def safe_join(root, name, flatten=False):
    name = name.replace("\\", "/")
    if flatten:
        name = os.path.basename(name.rstrip("/"))
    name = name.lstrip("/")
    parts = [p for p in name.split("/") if p and p != "."]
    if any(p == ".." for p in parts):
        raise ValueError(name)
    return os.path.join(root, *parts) if parts else root


def cmd_extract(opts, flatten=False, test=False):
    outstream = sys.stderr if opts.stdout else sys.stdout
    header(outstream)
    st = os.stat(opts.archive)
    print("Scanning the drive for archives:", file=outstream)
    print(f"1 file, {fmt_size(st.st_size)}", file=outstream)
    print(file=outstream)
    print(("Testing archive: " if test else "Extracting archive: ") + opts.archive, file=outstream)
    print("--", file=outstream)
    print(f"Path = {opts.archive}", file=outstream)
    print(f"Type = {archive_type(opts.archive, opts.type)}", file=outstream)
    print(f"Physical Size = {st.st_size}", file=outstream)
    print(file=outstream)
    la, a = open_reader(opts.archive)
    entry = ctypes.c_void_p()
    total = 0
    buf = ctypes.create_string_buffer(1024 * 128)
    try:
        while True:
            r = la.lib.archive_read_next_header(a, ctypes.byref(entry))
            if r == 1:
                break
            if r < ARCHIVE_OK:
                die(la.err(a), 1)
            raw = la.lib.archive_entry_pathname_utf8(entry) or la.lib.archive_entry_pathname(entry)
            name = raw.decode("utf-8", "replace") if raw else ""
            size = int(la.lib.archive_entry_size(entry))
            ftype = int(la.lib.archive_entry_filetype(entry))
            perm = int(la.lib.archive_entry_perm(entry)) or 0o644
            mtime = int(la.lib.archive_entry_mtime(entry))
            if not should_include(name, opts):
                la.lib.archive_read_data_skip(a)
                continue
            total += max(size, 0)
            if test:
                while la.lib.archive_read_data(a, buf, len(buf)) > 0:
                    pass
                continue
            if opts.stdout and ftype != AE_IFDIR:
                out = sys.stdout.buffer
                while True:
                    n = la.lib.archive_read_data(a, buf, len(buf))
                    if n <= 0:
                        break
                    out.write(buf.raw[:n])
                continue
            dest = safe_join(opts.outdir, name, flatten)
            if ftype == AE_IFDIR or name.endswith("/"):
                os.makedirs(dest, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
            with open(dest, "wb") as f:
                while True:
                    n = la.lib.archive_read_data(a, buf, len(buf))
                    if n <= 0:
                        break
                    f.write(buf.raw[:n])
            try:
                os.chmod(dest, perm & 0o777)
                if mtime:
                    os.utime(dest, (mtime, mtime))
            except OSError:
                pass
    finally:
        la.lib.archive_read_close(a)
        la.lib.archive_read_free(a)
    if not opts.stdout:
        print("Everything is Ok")
        print()
        print(f"Size:       {total}")
        print(f"Compressed: {st.st_size}")
    return 0


def gather(paths, recurse):
    out = []
    for p in paths or ["."]:
        if os.path.isdir(p):
            out.append(p)
            if recurse or True:
                for root, dirs, files in os.walk(p):
                    for d in dirs:
                        out.append(os.path.join(root, d))
                    for f in files:
                        out.append(os.path.join(root, f))
        elif os.path.exists(p):
            out.append(p)
        else:
            eprint(f"WARNING: No more files\n{p}")
    seen = []
    for p in out:
        if p not in seen:
            seen.append(p)
    return seen


def set_write_format(la, a, typ):
    t = typ.lower()
    if t in ("7z", "7zip"):
        la.lib.archive_write_set_format_7zip(a)
        la.lib.archive_write_add_filter_none(a)
    elif t == "zip":
        la.lib.archive_write_set_format_zip(a)
        la.lib.archive_write_add_filter_none(a)
    elif t in ("tar", "tgz", "tbz2", "txz", "gz", "gzip", "bz2", "bzip2", "xz"):
        la.lib.archive_write_set_format_pax_restricted(a)
        if t in ("tgz", "gz", "gzip"):
            la.lib.archive_write_add_filter_gzip(a)
        elif t in ("tbz2", "bz2", "bzip2"):
            la.lib.archive_write_add_filter_bzip2(a)
        elif t in ("txz", "xz"):
            la.lib.archive_write_add_filter_xz(a)
        else:
            la.lib.archive_write_add_filter_none(a)
    else:
        if la.lib.archive_write_set_format_by_name(a, t.encode()) != ARCHIVE_OK:
            la.lib.archive_write_set_format_7zip(a)
        la.lib.archive_write_add_filter_none(a)


def arcname(path):
    p = path.rstrip(os.sep)
    if p in ("", "."):
        return os.path.basename(os.getcwd())
    return p.replace(os.sep, "/").lstrip("./")


def cmd_add(opts):
    paths = gather(opts.files, opts.recurse)
    total = sum(os.path.getsize(p) for p in paths if os.path.isfile(p) and not os.path.islink(p))
    nfiles = sum(1 for p in paths if os.path.isfile(p) and not os.path.islink(p))
    ndirs = sum(1 for p in paths if os.path.isdir(p))
    header()
    print("Scanning the drive:")
    bits = []
    if ndirs:
        bits.append(f"{ndirs} folder" + ("" if ndirs == 1 else "s"))
    bits.append(f"{nfiles} file" + ("" if nfiles == 1 else "s"))
    print(", ".join(bits) + f", {fmt_size(total)}")
    print()
    print(f"Creating archive: {opts.archive}")
    print()
    print("Add new data to archive: " + ", ".join(bits) + f", {fmt_size(total)}")
    print()
    la = libarchive()
    a = la.lib.archive_write_new()
    set_write_format(la, a, archive_type(opts.archive, opts.type))
    if la.lib.archive_write_open_filename(a, os.fsencode(opts.archive)) != ARCHIVE_OK:
        die(la.err(a), 1)
    buf = ctypes.create_string_buffer(1024 * 128)
    try:
        for p in paths:
            try:
                st = os.lstat(p)
            except OSError:
                continue
            ent = la.lib.archive_entry_new()
            name = arcname(p)
            la.lib.archive_entry_set_pathname(ent, os.fsencode(name))
            la.lib.archive_entry_set_perm(ent, stat.S_IMODE(st.st_mode))
            la.lib.archive_entry_set_mtime(ent, int(st.st_mtime), 0)
            if stat.S_ISDIR(st.st_mode):
                la.lib.archive_entry_set_filetype(ent, AE_IFDIR)
                la.lib.archive_entry_set_size(ent, 0)
                la.lib.archive_write_header(a, ent)
            elif stat.S_ISREG(st.st_mode):
                la.lib.archive_entry_set_filetype(ent, AE_IFREG)
                la.lib.archive_entry_set_size(ent, st.st_size)
                if la.lib.archive_write_header(a, ent) == ARCHIVE_OK:
                    with open(p, "rb") as f:
                        while True:
                            data = f.read(len(buf))
                            if not data:
                                break
                            ctypes.memmove(buf, data, len(data))
                            la.lib.archive_write_data(a, buf, len(data))
            la.lib.archive_entry_free(ent)
    finally:
        la.lib.archive_write_close(a)
        la.lib.archive_write_free(a)
    size = os.path.getsize(opts.archive) if os.path.exists(opts.archive) else 0
    print()
    print(f"Files read from disk: {nfiles}")
    print(f"Archive size: {fmt_size(size)}")
    print("Everything is Ok")
    return 0


def open_writer(path, typ):
    la = libarchive()
    a = la.lib.archive_write_new()
    set_write_format(la, a, typ)
    if la.lib.archive_write_open_filename(a, os.fsencode(path)) != ARCHIVE_OK:
        die(la.err(a), 1)
    return la, a


def copy_archive_rewrite(opts, rename=None, delete=False):
    rename = rename or {}
    tmp = opts.archive + ".tmp"
    typ = archive_type(opts.archive, opts.type)
    rla, ra = open_reader(opts.archive)
    wla, wa = open_writer(tmp, typ)
    entry = ctypes.c_void_p()
    buf = ctypes.create_string_buffer(1024 * 128)
    changed = 0
    kept = 0
    try:
        while True:
            r = rla.lib.archive_read_next_header(ra, ctypes.byref(entry))
            if r == 1:
                break
            if r < ARCHIVE_OK:
                die(rla.err(ra), 1)
            raw = rla.lib.archive_entry_pathname_utf8(entry) or rla.lib.archive_entry_pathname(entry)
            name = raw.decode("utf-8", "replace") if raw else ""
            matched = should_include(name, opts)
            if delete and matched:
                changed += 1
                rla.lib.archive_read_data_skip(ra)
                continue
            newname = rename.get(name, name)
            if newname != name:
                changed += 1
            size = int(rla.lib.archive_entry_size(entry))
            ftype = int(rla.lib.archive_entry_filetype(entry))
            perm = int(rla.lib.archive_entry_perm(entry)) or 0o644
            mtime = int(rla.lib.archive_entry_mtime(entry))
            ent = wla.lib.archive_entry_new()
            wla.lib.archive_entry_set_pathname(ent, os.fsencode(newname))
            wla.lib.archive_entry_set_filetype(ent, ftype or AE_IFREG)
            wla.lib.archive_entry_set_perm(ent, perm)
            wla.lib.archive_entry_set_mtime(ent, mtime, 0)
            wla.lib.archive_entry_set_size(ent, 0 if ftype == AE_IFDIR else size)
            if wla.lib.archive_write_header(wa, ent) == ARCHIVE_OK and ftype != AE_IFDIR:
                while True:
                    n = rla.lib.archive_read_data(ra, buf, len(buf))
                    if n <= 0:
                        break
                    wla.lib.archive_write_data(wa, buf, n)
            else:
                rla.lib.archive_read_data_skip(ra)
            wla.lib.archive_entry_free(ent)
            kept += 1
    finally:
        rla.lib.archive_read_close(ra)
        rla.lib.archive_read_free(ra)
        wla.lib.archive_write_close(wa)
        wla.lib.archive_write_free(wa)
    os.replace(tmp, opts.archive)
    header()
    print(f"Updating archive: {opts.archive}")
    print()
    print("Everything is Ok")
    return 0 if changed or kept >= 0 else 1


def cmd_rename(opts):
    if len(opts.files) % 2:
        die("incorrect rename command")
    pairs = {opts.files[i]: opts.files[i + 1] for i in range(0, len(opts.files), 2)}
    opts.files = []
    return copy_archive_rewrite(opts, rename=pairs, delete=False)


def hash_file(path, alg):
    if alg == "CRC32":
        crc = 0
        size = 0
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(1024 * 1024), b""):
                size += len(chunk)
                crc = binascii.crc32(chunk, crc)
        return f"{crc & 0xffffffff:08X}", size
    hname = {"SHA1": "sha1", "SHA256": "sha256", "SHA512": "sha512", "MD5": "md5"}.get(alg, "sha256")
    h = hashlib.new(hname)
    size = 0
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            size += len(chunk)
            h.update(chunk)
    return h.hexdigest().upper(), size


def cmd_hash(opts):
    files = []
    for p in opts.files or ["."]:
        if os.path.isdir(p):
            for root, _, names in os.walk(p):
                for n in names:
                    files.append(os.path.join(root, n))
        elif os.path.isfile(p):
            files.append(p)
    alg = opts.hash if opts.hash != "*" else "CRC32"
    header()
    print("Scanning")
    total_size = sum(os.path.getsize(p) for p in files)
    print(f"{len(files)} files, {fmt_size(total_size)}")
    print()
    namew = max(len(alg), 8)
    print(f"{alg:<{namew}}          Size  Name")
    print(f"{'-'*namew} -------------  ------------")
    for p in files:
        digest, size = hash_file(p, alg)
        print(f"{digest:<{namew}} {size:13d}  {p}")
    print(f"{'-'*namew} -------------  ------------")
    print(f"{'':<{namew}} {total_size:13d}  ")
    print()
    print(f"Files: {len(files)}")
    print(f"Size: {total_size}")
    print()
    print("Everything is Ok")
    return 0


def cmd_info():
    header()
    print("Formats:")
    for f in ["7z", "zip", "tar", "gzip", "bzip2", "xz", "cpio", "iso", "rar", "wim"]:
        print(f"  {f}")
    print()
    print("Codecs:")
    for c in ["Copy", "Deflate", "BZip2", "LZMA", "LZMA2", "PPMd", "AES256CBC"]:
        print(f"  {c}")
    return 0


def cmd_bench():
    header()
    print("RAM size:   1024 MB,  # CPU hardware threads:  1")
    print("Benchmark stub")
    print("Everything is Ok")
    return 0


def main(argv):
    cmd, opts = parse(argv)
    try:
        if cmd in ("a", "u"):
            return cmd_add(opts)
        if cmd == "l":
            return cmd_list(opts)
        if cmd == "x":
            return cmd_extract(opts, flatten=False)
        if cmd == "e":
            return cmd_extract(opts, flatten=True)
        if cmd == "t":
            return cmd_extract(opts, test=True)
        if cmd == "h":
            return cmd_hash(opts)
        if cmd == "i":
            return cmd_info()
        if cmd == "b":
            return cmd_bench()
        if cmd == "d":
            return copy_archive_rewrite(opts, delete=True)
        if cmd == "rn":
            return cmd_rename(opts)
        print(HELP)
        return 2
    except BrokenPipeError:
        return 0
    except Exception as ex:
        die(str(ex), 1)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
