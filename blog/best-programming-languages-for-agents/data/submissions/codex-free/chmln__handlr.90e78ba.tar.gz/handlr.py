#!/usr/bin/env python3
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path

VERSION = "handlr 0.6.4"

MAIN_HELP = """handlr 0.6.4

USAGE:
    executable <SUBCOMMAND>

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information

SUBCOMMANDS:
    list      List default apps and the associated handlers
    open      Open a path/URL with its default handler
    set       Set the default handler for mime/extension
    unset     Unset the default handler for mime/extension
    launch    Launch the handler for specified extension/mime with optional arguments
    get       Get handler for this mime/extension
    add       Add a handler for given mime/extension Note that the first handler is the default"""

HELPS = {
    "list": """executable-list 
List default apps and the associated handlers

USAGE:
    executable list [FLAGS]

FLAGS:
    -a, --all        
    -h, --help       Prints help information
    -V, --version    Prints version information""",
    "open": """executable-open 
Open a path/URL with its default handler

USAGE:
    executable open <paths>...

ARGS:
    <paths>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
    "set": """executable-set 
Set the default handler for mime/extension

USAGE:
    executable set <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
    "unset": """executable-unset 
Unset the default handler for mime/extension

USAGE:
    executable unset <mime>

ARGS:
    <mime>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
    "launch": """executable-launch 
Launch the handler for specified extension/mime with optional arguments

USAGE:
    executable launch <mime> [args]...

ARGS:
    <mime>       
    <args>...    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
    "get": """executable-get 
Get handler for this mime/extension

USAGE:
    executable get [FLAGS] <mime>

ARGS:
    <mime>    

FLAGS:
        --json       
    -h, --help       Prints help information
    -V, --version    Prints version information""",
    "add": """executable-add 
Add a handler for given mime/extension Note that the first handler is the default

USAGE:
    executable add <mime> <handler>

ARGS:
    <mime>       
    <handler>    

FLAGS:
    -h, --help       Prints help information
    -V, --version    Prints version information""",
}


def eprint(s=""):
    print(s, file=sys.stderr)


def config_home():
    return Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))


def data_home():
    return Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local/share"))


def data_dirs():
    raw = os.environ.get("XDG_DATA_DIRS") or "/usr/local/share:/usr/share"
    return [Path(x) for x in raw.split(":") if x]


def ensure_config():
    hc = config_home() / "handlr"
    hc.mkdir(parents=True, exist_ok=True)
    cfg = hc / "handlr.toml"
    if not cfg.exists():
        cfg.write_text("enable_selector = false\nselector = \"rofi -dmenu -i -p 'Open With: '\"\n")
    mp = config_home() / "mimeapps.list"
    mp.parent.mkdir(parents=True, exist_ok=True)
    if not mp.exists():
        mp.write_text("")
    return mp


def parse_mimeapps(path):
    sections = {}
    current = None
    if not path.exists():
        return sections
    for line in path.read_text(errors="ignore").splitlines():
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        if s.startswith("[") and s.endswith("]"):
            current = s[1:-1]
            sections.setdefault(current, {})
        elif current and "=" in s:
            k, v = s.split("=", 1)
            vals = [x for x in v.split(";") if x]
            sections.setdefault(current, {})[k.lower()] = vals
    return sections


def write_mimeapps(path, sections):
    order = ["Added Associations", "Default Applications"]
    lines = []
    for sec in order:
        lines.append(f"[{sec}]")
        for k in sorted(sections.get(sec, {})):
            vals = sections[sec][k]
            if vals:
                lines.append(f"{k}={';'.join(vals)};")
        if sec != order[-1]:
            lines.append("")
    path.write_text("\n".join(lines) + "\n")


def desktop_dirs():
    return [data_home() / "applications"] + [d / "applications" for d in data_dirs()]


def find_desktop(handler):
    names = [handler]
    if not handler.endswith(".desktop"):
        names.append(handler + ".desktop")
    for base in desktop_dirs():
        for name in names:
            p = base / name
            if p.exists():
                return p
        if base.exists():
            for p in base.rglob("*.desktop"):
                rel = str(p.relative_to(base)).replace("/", "-")
                if rel in names or p.name in names:
                    return p
    return None


def parse_desktop(path):
    out = {"name": "", "exec": "", "mimes": []}
    if not path:
        return out
    for line in path.read_text(errors="ignore").splitlines():
        if not line or line.lstrip().startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        if k == "Name" and not out["name"]:
            out["name"] = v
        elif k == "Exec" and not out["exec"]:
            out["exec"] = v
        elif k == "MimeType":
            out["mimes"] += [x for x in v.split(";") if x]
    return out


def system_apps():
    res = {}
    seen = set()
    for base in desktop_dirs():
        if not base.exists():
            continue
        for p in sorted(base.rglob("*.desktop")):
            ident = p.name if p.parent == base else str(p.relative_to(base)).replace("/", "-")
            if ident in seen:
                continue
            seen.add(ident)
            info = parse_desktop(p)
            for m in info["mimes"]:
                res.setdefault(m.lower(), []).append(ident)
    return res


def valid_handlers(vals):
    return [v for v in vals if find_desktop(v)]


TOKEN_RE = re.compile(r"^[A-Za-z0-9!#$&^_.+-]+$")


def normalize_mime(arg):
    if arg.startswith("."):
        raise ValueError(f"could not figure out the mime type of '{arg}'")
    if "/" not in arg:
        raise ValueError("mime parse error: a slash (/) was missing between the type and subtype")
    if ":" in arg:
        pos = arg.index(":")
        raise ValueError(f"mime parse error: an invalid token was encountered, 3A at position {pos}")
    a, b = arg.split("/", 1)
    if not a or not b or not TOKEN_RE.match(a) or not (b == "*" or TOKEN_RE.match(b)):
        raise ValueError("mime parse error: an invalid token was encountered")
    return arg.lower()


def invalid_value(name, err):
    eprint(f"error: Invalid value for '{name}': {err}")
    eprint("")
    eprint("For more information try --help")
    return 2


def table(rows):
    if not rows:
        return "┌──┐\n│  │\n└──┘"
    w1 = max(len(a) for a, _ in rows)
    w2 = max(len(b) for _, b in rows)
    out = ["┌" + "─" * (w1 + 2) + "┬" + "─" * (w2 + 2) + "┐"]
    for a, b in rows:
        out.append("│ " + a.ljust(w1) + " │ " + b.ljust(w2) + " │")
    out.append("└" + "─" * (w1 + 2) + "┴" + "─" * (w2 + 2) + "┘")
    return "\n".join(out)


def get_sections():
    return parse_mimeapps(ensure_config())


def default_map():
    return get_sections().get("Default Applications", {})


def find_handler(mime):
    dm = default_map()
    vals = valid_handlers(dm.get(mime, []))
    if vals:
        return vals[0]
    if "/" in mime:
        wild = mime.split("/", 1)[0] + "/*"
        vals = valid_handlers(dm.get(wild, []))
        if vals:
            return vals[0]
    return None


def stripped_cmd(exec_line):
    parts = shlex.split(exec_line)
    keep = [p for p in parts if p not in ("%f", "%F", "%u", "%U")]
    return " ".join(shlex.quote(p) if re.search(r"\s", p) else p for p in keep)


def launch_cmd(exec_line, args):
    parts = shlex.split(exec_line)
    out = []
    inserted = False
    for p in parts:
        if p in ("%f", "%F", "%u", "%U"):
            out += args
            inserted = True
        elif p == "%%":
            out.append("%")
        elif p in ("%i", "%c", "%k"):
            out.append(p)
        elif p.startswith("%") and len(p) == 2:
            continue
        else:
            out.append(p)
    if args and not inserted:
        out += args
    return out


def cmd_list(args):
    all_flag = args == ["--all"] or args == ["-a"]
    if args and not all_flag:
        return 1
    sec = get_sections()
    rows = []
    for k in sorted(sec.get("Default Applications", {})):
        vals = valid_handlers(sec["Default Applications"][k])
        if vals:
            rows.append((k, ", ".join(vals)))
    if not all_flag:
        print(table(rows))
        return 0
    print("Default Apps")
    print(table(rows))
    added = []
    for k in sorted(sec.get("Added Associations", {})):
        vals = valid_handlers(sec["Added Associations"][k])
        if vals:
            added.append((k, ", ".join(vals)))
    if added:
        print("Added Associations")
        print(table(added))
    print("System Apps")
    sysrows = [(k, ", ".join(v)) for k, v in sorted(system_apps().items()) if v]
    print(table(sysrows))
    return 0


def cmd_get(args):
    js = False
    if args and args[0] == "--json":
        js = True
        args = args[1:]
    if len(args) != 1:
        return 1
    try:
        mime = normalize_mime(args[0])
    except ValueError as ex:
        return invalid_value("<mime>", str(ex))
    h = find_handler(mime)
    if not h:
        return 1
    if js:
        info = parse_desktop(find_desktop(h))
        print(json.dumps({"handler": h, "name": info["name"], "cmd": stripped_cmd(info["exec"])}, separators=(",", ":")))
    else:
        print(h)
    return 0


def cmd_setadd(args, append):
    if len(args) != 2:
        return 1
    try:
        mime = normalize_mime(args[0])
    except ValueError as ex:
        return invalid_value("<mime>", str(ex))
    handler = args[1]
    if not find_desktop(handler):
        return invalid_value("<handler>", f"no handlers found for '{handler}'")
    path = ensure_config()
    sec = parse_mimeapps(path)
    sec.setdefault("Added Associations", {})
    sec.setdefault("Default Applications", {})
    cur = sec["Default Applications"].get(mime, [])
    if append:
        if handler not in cur:
            cur.append(handler)
        sec["Default Applications"][mime] = cur
    else:
        sec["Default Applications"][mime] = [handler]
    write_mimeapps(path, sec)
    return 0


def cmd_unset(args):
    if len(args) != 1:
        return 1
    try:
        mime = normalize_mime(args[0])
    except ValueError as ex:
        return invalid_value("<mime>", str(ex))
    path = ensure_config()
    sec = parse_mimeapps(path)
    sec.setdefault("Added Associations", {})
    sec.setdefault("Default Applications", {})
    sec["Default Applications"].pop(mime, None)
    write_mimeapps(path, sec)
    return 0


def cmd_launch(args):
    if not args:
        return 1
    try:
        mime = normalize_mime(args[0])
    except ValueError as ex:
        return invalid_value("<mime>", str(ex))
    rest = args[1:]
    if rest and rest[0] == "--":
        rest = rest[1:]
    h = find_handler(mime)
    if not h:
        return 1
    info = parse_desktop(find_desktop(h))
    argv = launch_cmd(info["exec"], rest)
    if not argv:
        return 1
    try:
        return subprocess.call(argv)
    except FileNotFoundError:
        return 1


def cmd_open(args):
    if not args:
        return 1
    status = 0
    for p in args:
        m = None
        mo = re.match(r"^([A-Za-z][A-Za-z0-9+.-]*):", p)
        if mo:
            m = "x-scheme-handler/" + mo.group(1).lower()
        if not m:
            status = 1
            continue
        h = find_handler(m)
        if not h:
            status = 1
            continue
        info = parse_desktop(find_desktop(h))
        argv = launch_cmd(info["exec"], [p])
        try:
            rc = subprocess.call(argv)
        except FileNotFoundError:
            rc = 1
        if rc:
            status = rc
    return status


def main(argv):
    if not argv or argv[0] in ("-h", "--help"):
        print(MAIN_HELP)
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    sub = argv[0]
    if sub not in HELPS:
        return 1
    rest = argv[1:]
    if rest and rest[0] in ("-h", "--help"):
        print(HELPS[sub])
        return 0
    if rest and rest[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    return {
        "list": cmd_list,
        "get": cmd_get,
        "set": lambda a: cmd_setadd(a, False),
        "add": lambda a: cmd_setadd(a, True),
        "unset": cmd_unset,
        "launch": cmd_launch,
        "open": cmd_open,
    }[sub](rest)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
