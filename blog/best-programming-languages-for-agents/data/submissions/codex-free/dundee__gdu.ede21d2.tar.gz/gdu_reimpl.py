#!/usr/bin/env python3
import argparse
import datetime as _dt
import fnmatch
import json
import os
import re
import stat
import sys
from dataclasses import dataclass, field


HELP = """Pretty fast disk usage analyzer written in Go.

Gdu is intended primarily for SSD disks where it can fully utilize parallel processing.
However HDDs work as well, but the performance gain is not so huge.

Usage:
  gdu [directory_to_scan] [flags]

Flags:
      --archive-browsing              Enable browsing of zip/jar archives
      --collapse-path                 Collapse single-child directory chains
      --config-file string            Read config from file (default is $HOME/.gdu.yaml)
  -D, --db string                     Store analysis in database (*.sqlite for SQLite, *.badger for BadgerDB)
      --depth int                     Show directory structure up to specified depth in non-interactive mode (0 means the flag is ignored)
      --enable-profiling              Enable collection of profiling data and provide it on http://localhost:6060/debug/pprof/
  -E, --exclude-type strings          File types to exclude (e.g., --exclude-type yaml,json)
  -L, --follow-symlinks               Follow symlinks for files, i.e. show the size of the file to which symlink points to (symlinks to directories are not followed)
  -h, --help                          help for gdu
  -i, --ignore-dirs strings           Paths to ignore (separated by comma). Can be absolute or relative to current directory (default [/proc,/dev,/sys,/run])
  -I, --ignore-dirs-pattern strings   Path patterns to ignore (separated by comma)
  -X, --ignore-from string            Read path patterns to ignore from file
  -f, --input-file string             Import analysis from JSON file
  -l, --log-file string               Path to a logfile (default "/dev/null")
      --max-age string                Include files with mtime no older than DURATION (e.g., 7d, 2h30m, 1y2mo)
  -m, --max-cores int                 Set max cores that Gdu will use. 14 cores available (default 14)
      --min-age string                Include files with mtime at least DURATION old (e.g., 30d, 1w)
      --mouse                         Use mouse
  -c, --no-color                      Do not use colorized output
  -x, --no-cross                      Do not cross filesystem boundaries
      --no-delete                     Do not allow deletions
  -H, --no-hidden                     Ignore hidden directories (beginning with dot)
      --no-prefix                     Show sizes as raw numbers without any prefixes (SI or binary) in non-interactive mode
  -p, --no-progress                   Do not show progress in non-interactive mode
      --no-spawn-shell                Do not allow spawning shell
  -u, --no-unicode                    Do not use Unicode symbols (for size bar)
  -n, --non-interactive               Do not run in interactive mode
  -o, --output-file string            Export all info into file as JSON
  -r, --read-from-storage             Use existing database instead of re-scanning
      --reverse-sort                  Reverse sorting order (smallest to largest) in non-interactive mode
      --sequential                    Use sequential scanning (intended for rotating HDDs)
  -A, --show-annexed-size             Use apparent size of git-annex'ed files in case files are not present locally (real usage is zero)
  -a, --show-apparent-size            Show apparent size
  -d, --show-disks                    Show all mounted disks
  -k, --show-in-kib                   Show sizes in KiB (or kB with --si) in non-interactive mode
  -C, --show-item-count               Show number of items in directory
  -M, --show-mtime                    Show latest mtime of items in directory
  -B, --show-relative-size            Show relative size
      --si                            Show sizes with decimal SI prefixes (kB, MB, GB) instead of binary prefixes (KiB, MiB, GiB)
      --since string                  Include files with mtime >= WHEN. WHEN accepts RFC3339 timestamp (e.g., 2025-08-11T01:00:00-07:00) or date only YYYY-MM-DD (calendar-day compare; includes the whole day)
  -s, --summarize                     Show only a total in non-interactive mode
  -t, --top int                       Show only top X largest files in non-interactive mode
  -T, --type strings                  File types to include (e.g., --type yaml,json)
      --until string                  Include files with mtime <= WHEN. WHEN accepts RFC3339 timestamp or date only YYYY-MM-DD
  -v, --version                       Print version
      --write-config                  Write current configuration to file (default is $HOME/.gdu.yaml)
"""


@dataclass
class Node:
    name: str
    path: str
    asize: int = 0
    dsize: int = 0
    mtime: int = 0
    is_dir: bool = False
    notreg: bool = False
    error: bool = False
    actual_empty: bool = False
    children: list = field(default_factory=list)

    @property
    def empty(self):
        return self.is_dir and self.actual_empty

    def size(self, apparent=False):
        return self.asize if apparent else self.dsize


def split_csv(values):
    out = []
    for v in values or []:
        for part in str(v).split(","):
            if part:
                out.append(part)
    return out


def ext(path):
    base = os.path.basename(path)
    if "." not in base:
        return ""
    return base.rsplit(".", 1)[1]


def parse_when(s, end=False):
    if not s:
        return None
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
        d = _dt.date.fromisoformat(s)
        t = _dt.time.max if end else _dt.time.min
        return int(_dt.datetime.combine(d, t).timestamp())
    z = s.replace("Z", "+00:00")
    try:
        return int(_dt.datetime.fromisoformat(z).timestamp())
    except ValueError:
        return None


def parse_duration(s):
    if not s:
        return None
    total = 0
    units = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800, "mo": 2592000, "y": 31536000}
    for num, unit in re.findall(r"(\d+)(mo|[smhdwy])", s):
        total += int(num) * units[unit]
    return total or None


def human(n, si=False, kib=False, raw=False):
    if raw:
        return str(int(n)).rjust(10)
    if kib:
        v = n / 1000.0 if si else n / 1024.0
        return f"{v:.1f} {'kB' if si else 'KiB'}".rjust(10)
    step = 1000.0 if si else 1024.0
    units = ["B", "kB" if si else "KiB", "MB" if si else "MiB", "GB" if si else "GiB", "TB" if si else "TiB"]
    v = float(n)
    u = 0
    while abs(v) >= step and u < len(units) - 1:
        v /= step
        u += 1
    if u == 0:
        return f"{int(v)} B".rjust(10)
    return f"{v:.1f} {units[u]}".rjust(10)


def should_ignore(path, root, args):
    base = os.path.basename(path)
    if args.no_hidden and base.startswith(".") and path != root:
        return True
    ap = os.path.abspath(path)
    rel = os.path.relpath(ap, os.getcwd())
    for p in args.ignore_dirs:
        pp = os.path.abspath(p) if os.path.isabs(p) else os.path.abspath(p)
        if ap == pp or rel == p.strip("/"):
            return True
    for pat in args.ignore_patterns:
        try:
            if re.search(pat, path):
                return True
        except re.error:
            if fnmatch.fnmatch(path, pat):
                return True
    return False


def type_allowed(path, is_dir, args):
    if is_dir:
        return True
    e = ext(path)
    inc = set(args.types)
    exc = set(args.exclude_types)
    if inc and e not in inc:
        return False
    if e in exc:
        return False
    return True


def time_allowed(mtime, args):
    if args.since is not None and mtime < args.since:
        return False
    if args.until is not None and mtime > args.until:
        return False
    now = int(_dt.datetime.now().timestamp())
    if args.max_age and mtime < now - args.max_age:
        return False
    if args.min_age and mtime > now - args.min_age:
        return False
    return True


def scan(path, args, root=None, seen=None):
    root = root or path
    seen = seen if seen is not None else set()
    try:
        st = os.stat(path) if args.follow_symlinks and not os.path.isdir(path) else os.lstat(path)
    except OSError as e:
        raise e
    mode = st.st_mode
    is_dir = stat.S_ISDIR(mode)
    is_reg = stat.S_ISREG(mode)
    node = Node(os.path.basename(path) or path, path, st.st_size, getattr(st, "st_blocks", 0) * 512, int(st.st_mtime), is_dir, not (is_reg or is_dir))
    if not time_allowed(node.mtime, args) or not type_allowed(path, is_dir, args):
        node.asize = node.dsize = 0
        return node
    if is_reg:
        key = (st.st_dev, st.st_ino)
        if key in seen:
            node.dsize = 0
        seen.add(key)
    if is_dir:
        try:
            entries = sorted(os.listdir(path))
        except OSError:
            node.error = True
            return node
        node.actual_empty = len(entries) == 0
        total_a, total_d = node.asize, node.dsize
        max_m = node.mtime
        for name in entries:
            child_path = os.path.join(path, name)
            if should_ignore(child_path, root, args):
                continue
            try:
                child = scan(child_path, args, root, seen)
            except OSError:
                continue
            if child.size(True) == 0 and child.size(False) == 0 and not child.is_dir and (args.types or args.exclude_types or args.since or args.until or args.max_age or args.min_age):
                continue
            node.children.append(child)
            total_a += child.asize
            total_d += child.dsize
            max_m = max(max_m, child.mtime)
        node.asize, node.dsize, node.mtime = total_a, total_d, max_m
    return node


def sort_children(children, args):
    return sorted(children, key=lambda n: (n.size(args.apparent), n.name), reverse=not args.reverse_sort)


def print_line(node, name, args):
    flag = " "
    if node.error:
        flag = "!"
    elif node.empty:
        flag = "e"
    elif node.notreg:
        flag = "@"
    print(f"{flag}{human(node.size(args.apparent), args.si, args.kib, args.raw)} {name}")


def list_default(root, args):
    for child in sort_children(root.children, args):
        name = ("/" + child.name) if child.is_dir else child.name
        print_line(child, name, args)


def walk_depth(node, args, max_depth, depth=0):
    print_line(node, node.path, args)
    if depth >= max_depth:
        return
    for c in sort_children(node.children, args):
        walk_depth(c, args, max_depth, depth + 1)


def collect_files(node, out):
    if not node.is_dir:
        out.append(node)
    for c in node.children:
        collect_files(c, out)


def to_json_obj(node):
    if node.is_dir:
        head = {"name": node.path if os.path.isabs(node.path) else node.name, "mtime": node.mtime, "asize": node.asize, "dsize": node.dsize}
        arr = [head]
        for c in node.children:
            obj = to_json_obj(c)
            if c.is_dir and isinstance(obj, list):
                obj[0]["name"] = c.name
            arr.append(obj)
        return arr
    o = {"name": node.name, "asize": node.asize, "mtime": node.mtime}
    if node.dsize:
        o["dsize"] = node.dsize
    if node.notreg:
        o["notreg"] = True
    return o


def from_json_obj(obj, parent=""):
    if isinstance(obj, list):
        meta = obj[0]
        name = meta.get("name", "")
        path = name if os.path.isabs(name) else os.path.join(parent, name)
        own_a = int(meta.get("asize", 4096))
        own_d = int(meta.get("dsize", 4096))
        n = Node(os.path.basename(name) if os.path.isabs(name) else name, path, own_a, own_d, int(meta.get("mtime", 0)), True)
        if "asize" in meta or "dsize" in meta:
            n.children = []
            return_children_only = False
        else:
            return_children_only = True
        for child in obj[1:]:
            cn = from_json_obj(child, path)
            n.children.append(cn)
            if return_children_only:
                n.asize += cn.asize
                n.dsize += cn.dsize
            n.mtime = max(n.mtime, cn.mtime)
        n.actual_empty = len(n.children) == 0
        return n
    name = obj.get("name", "")
    return Node(name, os.path.join(parent, name), int(obj.get("asize", 0)), int(obj.get("dsize", 0)), int(obj.get("mtime", 0)), False, bool(obj.get("notreg")))


def load_json(path):
    data = json.load(open(path))
    if isinstance(data, list) and len(data) >= 4 and data[0] == 1:
        return from_json_obj(data[3])
    return from_json_obj(data)


def show_disks():
    print("   Device      Size      Used      Free Used% Mount point")
    seen = set()
    try:
        mounts = open("/proc/mounts").read().splitlines()
    except OSError:
        mounts = []
    for line in mounts:
        parts = line.split()
        if len(parts) < 2:
            continue
        dev, mp = parts[0], parts[1].replace("\\040", " ")
        if not dev.startswith("/"):
            continue
        try:
            st = os.statvfs(mp)
        except OSError:
            continue
        size = st.f_frsize * st.f_blocks
        free = st.f_frsize * st.f_bavail
        used = max(0, size - free)
        pct = int(round((used / size) * 100)) if size else 0
        key = (dev, mp)
        if key in seen:
            continue
        seen.add(key)
        print(f"{dev:<8} {human(size).strip():>9} {human(used).strip():>9} {human(free).strip():>9} {pct:>4}% {mp}")


def build_parser():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("path", nargs="?")
    for s in ["--archive-browsing", "--collapse-path", "--enable-profiling", "--mouse", "--no-delete", "--no-spawn-shell", "--sequential", "-A", "--show-annexed-size", "-x", "--no-cross", "-c", "--no-color", "-u", "--no-unicode", "-r", "--read-from-storage", "--write-config"]:
        p.add_argument(s, action="store_true")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("-n", "--non-interactive", action="store_true")
    p.add_argument("-p", "--no-progress", action="store_true")
    p.add_argument("-a", "--show-apparent-size", dest="apparent", action="store_true")
    p.add_argument("-H", "--no-hidden", action="store_true")
    p.add_argument("--no-prefix", dest="raw", action="store_true")
    p.add_argument("-k", "--show-in-kib", dest="kib", action="store_true")
    p.add_argument("--si", action="store_true")
    p.add_argument("-s", "--summarize", action="store_true")
    p.add_argument("-d", "--show-disks", action="store_true")
    p.add_argument("-L", "--follow-symlinks", action="store_true")
    p.add_argument("--reverse-sort", action="store_true")
    p.add_argument("-C", "--show-item-count", action="store_true")
    p.add_argument("-M", "--show-mtime", action="store_true")
    p.add_argument("-B", "--show-relative-size", action="store_true")
    p.add_argument("--depth", type=int, default=0)
    p.add_argument("-t", "--top", type=int, default=0)
    p.add_argument("-i", "--ignore-dirs", action="append", default=[])
    p.add_argument("-I", "--ignore-dirs-pattern", dest="ignore_patterns", action="append", default=[])
    p.add_argument("-X", "--ignore-from")
    p.add_argument("-T", "--type", dest="types", action="append", default=[])
    p.add_argument("-E", "--exclude-type", dest="exclude_types", action="append", default=[])
    p.add_argument("-o", "--output-file")
    p.add_argument("-f", "--input-file")
    p.add_argument("-l", "--log-file", default="/dev/null")
    p.add_argument("-D", "--db")
    p.add_argument("--config-file")
    p.add_argument("-m", "--max-cores", type=int)
    p.add_argument("--max-age")
    p.add_argument("--min-age")
    p.add_argument("--since")
    p.add_argument("--until")
    return p


def main(argv):
    parser = build_parser()
    try:
        args, unknown = parser.parse_known_args(argv)
    except SystemExit:
        return 1
    if unknown:
        print(f"Error: unknown flag: {unknown[0]}", file=sys.stderr)
        return 1
    if args.help:
        print(HELP, end="")
        return 0
    if args.version:
        print("Version:\t dev")
        print("Built time:\t Fri Apr 17 19:59:35 UTC 2026")
        print("Built user:\t root")
        return 0
    if args.show_disks:
        show_disks()
        return 0
    args.ignore_dirs = split_csv(args.ignore_dirs) or ["/proc", "/dev", "/sys", "/run"]
    args.ignore_patterns = split_csv(args.ignore_patterns)
    args.types = split_csv(args.types)
    args.exclude_types = split_csv(args.exclude_types)
    if args.ignore_from:
        try:
            args.ignore_patterns += [x.strip() for x in open(args.ignore_from) if x.strip()]
        except OSError as e:
            print(f"Error: {e}", file=sys.stderr)
            return 1
    args.since = parse_when(args.since, False)
    args.until = parse_when(args.until, True)
    args.max_age = parse_duration(args.max_age)
    args.min_age = parse_duration(args.min_age)
    try:
        root = load_json(args.input_file) if args.input_file else scan(args.path or ".", args)
    except OSError as e:
        if isinstance(e, FileNotFoundError):
            target = args.path or "."
            print(f"Error: stat {target}: no such file or directory", file=sys.stderr)
        else:
            print(f"Error: {e}", file=sys.stderr)
        return 1
    if args.output_file:
        payload = [1, 2, {"progname": "gdu", "progver": "dev", "timestamp": int(_dt.datetime.now().timestamp())}, to_json_obj(root)]
        with open(args.output_file, "w") as f:
            json.dump(payload, f, separators=(",", ":"))
    if args.summarize:
        print_line(root, os.path.basename(root.path.rstrip(os.sep)) or root.path, args)
    elif args.depth > 0:
        walk_depth(root, args, args.depth)
    elif args.top > 0:
        files = []
        collect_files(root, files)
        files = sorted(files, key=lambda n: (n.size(args.apparent), n.path), reverse=True)[: args.top]
        for n in files:
            print_line(n, n.path, args)
    elif not args.output_file:
        list_default(root, args)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
