#!/usr/bin/env python3
import os
import shutil
import sys
import textwrap


DESCRIPTION = "A simple terminal UI for search and replace, ala VS Code"
VERSION = """serpl 0.3.4- (2026-04-20)

Authors: Yassine Bridi <ybridi@gmail.com>

Config directory: {config_dir}
"""


def terminal_width():
    try:
        return int(os.environ.get("COLUMNS") or shutil.get_terminal_size((80, 24)).columns)
    except Exception:
        return 80


def help_text():
    width = terminal_width()
    if width <= 50:
        desc = textwrap.fill(DESCRIPTION, width=width)
        return f"""{desc}

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>
          Path to the project root
          [default: .]
  -h, --help
          Print help
  -V, --version
          Print version
"""
    return f"""{DESCRIPTION}

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version
"""


def print_parse_error(message, usage=True):
    sys.stderr.write(f"error: {message}\n\n")
    if usage:
        sys.stderr.write("Usage: executable [OPTIONS]\n\n")
    sys.stderr.write("For more information, try '--help'.\n")
    return 2


def config_dir():
    if os.environ.get("XDG_CONFIG_HOME"):
        return os.path.join(os.environ["XDG_CONFIG_HOME"], "serpl")
    home = os.environ.get("HOME") or os.path.expanduser("~")
    return os.path.join(home, ".config", "serpl")


def parse(argv):
    project_seen = False
    end_options = False
    i = 0
    while i < len(argv):
        arg = argv[i]
        if end_options:
            return ("error", f"unexpected argument '{arg}' found", True)
        if arg == "--":
            end_options = True
        elif arg in ("-h", "--help"):
            return ("help",)
        elif arg in ("-V", "--version"):
            return ("version",)
        elif arg == "--project-root" or arg == "-p":
            if project_seen:
                return ("error", "the argument '--project-root <PATH>' cannot be used multiple times", True)
            project_seen = True
            if i + 1 >= len(argv):
                return ("error", f"a value is required for '{arg} <PATH>' but none was supplied", False)
            i += 1
        elif arg.startswith("--project-root="):
            if project_seen:
                return ("error", "the argument '--project-root <PATH>' cannot be used multiple times", True)
            project_seen = True
            if arg == "--project-root=":
                return ("error", "a value is required for '--project-root <PATH>' but none was supplied", False)
        elif arg.startswith("-p") and len(arg) > 2:
            if project_seen:
                return ("error", "the argument '--project-root <PATH>' cannot be used multiple times", True)
            project_seen = True
        elif arg.startswith("-") and len(arg) > 2 and "V" in arg[1:]:
            return ("version",)
        elif arg.startswith("-"):
            return ("error", f"unexpected argument '{arg}' found", True)
        else:
            return ("error", f"unexpected argument '{arg}' found", True)
        i += 1
    return ("run",)


def main():
    result = parse(sys.argv[1:])
    mode = result[0]
    if mode == "help":
        sys.stdout.write(help_text())
        return 0
    if mode == "version":
        sys.stdout.write(VERSION.format(config_dir=config_dir()))
        return 0
    if mode == "error":
        return print_parse_error(result[1], result[2])

    # The reference program attempts to initialize a terminal UI. In the
    # cleanroom's non-interactive execution mode that initialization fails
    # before any project-root validation or file scanning happens.
    sys.stderr.write("serpl error: Something went wrong\n")
    sys.stderr.write("Error: \n")
    sys.stderr.write("   0: \033[91mResource temporarily unavailable (os error 11)\033[0m\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
