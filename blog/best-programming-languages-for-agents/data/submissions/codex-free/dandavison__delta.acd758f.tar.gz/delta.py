#!/usr/bin/env python3
import difflib
import os
import re
import shutil
import sys

VERSION = "delta 0.18.2"

BLUE = "\033[34m"
GREEN = "\033[32m"
RED = "\033[31m"
MAGENTA = "\033[35m"
DIM = "\033[38;5;238m"
MINUS_BG = "\033[48;5;52m"
PLUS_BG = "\033[48;5;22m"
RESET = "\033[0m"
ERASE = "\033[0K"

HELP_SHORT = """A viewer for git and diff output

Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]

Arguments:
  [MINUS_FILE]  First file to be compared when delta is being used to diff two files
  [PLUS_FILE]   Second file to be compared when delta is being used to diff two files

Options:
      --raw                         Do not alter the input in any way
      --color-only                  Do not alter the input structurally in any way
  -n, --line-numbers                Display line numbers next to the diff
  -s, --side-by-side                Display diffs in side-by-side layout
      --syntax-theme <SYNTAX_THEME> The syntax-highlighting theme to use
      --paging <auto|always|never>  Whether to use a pager when displaying output [default: auto]
      --list-languages              List supported languages and associated file extensions
      --list-syntax-themes          List available syntax-highlighting color themes
      --show-config                 Display the active values for all Delta options
      --show-colors                 Show available named colors
      --parse-ansi                  Display ANSI color escape sequences in human-readable form
  -w, --width <N>                   The width of underline/overline decorations
  -@, --diff-args <STRING>          Extra arguments to pass to git diff when comparing two files
  -h, --help                        Print help (see more with '--help')
  -V, --version                     Print version
"""

HELP_LONG = """A viewer for git and diff output

Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]

Arguments:
  [MINUS_FILE]
          First file to be compared when delta is being used to diff two
          files.

          `delta file1 file2` is equivalent to `diff -u file1 file2 | delta`.

  [PLUS_FILE]
          Second file to be compared when delta is being used to diff two
          files

Options:
      --raw
          Do not alter the input in any way.

      --color-only
          Do not alter the input structurally in any way.

  -n, --line-numbers
          Display line numbers next to the diff.

  -s, --side-by-side
          Display diffs in side-by-side layout

      --list-languages
          List supported languages and associated file extensions

      --list-syntax-themes
          List available syntax-highlighting color themes

      --show-config
          Display the active values for all Delta options.

      --show-colors
          Show available named colors.

      --parse-ansi
          Display ANSI color escape sequences in human-readable form.

      --paging <auto|always|never>
          Whether to use a pager when displaying output

      --syntax-theme <SYNTAX_THEME>
          The syntax-highlighting theme to use.

  -w, --width <N>
          The width of underline/overline decorations.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

Git config

  By default, delta takes settings from a section named "delta" in git config
  files, if one is present.

Styles

  Options that have a name like --*-style accept git-style color strings.
"""

LANGUAGES = [
    ("ActionScript", "as"), ("Ada", "adb, ads, gpr"), ("Bourne Again Shell (bash)", "sh, bash, zsh"),
    ("C", "c, h"), ("C++", "cpp, cc, cxx, hpp"), ("CMake", "CMakeLists.txt, cmake"),
    ("CSS", "css"), ("Diff", "diff, patch"), ("Dockerfile", "Dockerfile, dockerfile"),
    ("Git Config", "gitconfig, .gitconfig, .gitmodules"), ("Go", "go"), ("HTML", "html, htm"),
    ("Java", "java"), ("JavaScript", "js, mjs, jsx"), ("JSON", "json"), ("Makefile", "make, Makefile"),
    ("Markdown", "md, markdown"), ("Perl", "pl, pm"), ("PHP", "php"), ("Plain Text", "txt"),
    ("Python", "py, py3, pyw"), ("Ruby", "rb, Gemfile, Rakefile"), ("Rust", "rs"),
    ("SQL", "sql"), ("TOML", "toml, Cargo.lock"), ("TypeScript", "ts, tsx"),
    ("XML", "xml, xsd, svg"), ("YAML", "yaml, yml"), ("Zig", "zig"),
]

THEMES = [
    ("dark", "1337"), ("dark", "Coldark-Cold"), ("dark", "Coldark-Dark"), ("dark", "DarkNeon"),
    ("dark", "Dracula"), ("dark", "Monokai Extended"), ("dark", "Monokai Extended Bright"),
    ("dark", "Monokai Extended Origin"), ("dark", "Nord"), ("dark", "OneHalfDark"),
    ("dark", "Solarized (dark)"), ("dark", "Sublime Snazzy"), ("dark", "TwoDark"),
    ("dark", "Visual Studio Dark+"), ("dark", "ansi"), ("dark", "base16"),
    ("dark", "base16-256"), ("dark", "gruvbox-dark"), ("dark", "zenburn"),
    ("light", "GitHub"), ("light", "Monokai Extended Light"), ("light", "OneHalfLight"),
    ("light", "Solarized (light)"), ("light", "gruvbox-light"),
]

VALUE_OPTIONS = {
    "--blame-code-style", "--blame-format", "--blame-palette", "--blame-separator-format",
    "--blame-separator-style", "--blame-timestamp-format", "--blame-timestamp-output-format",
    "--config", "--commit-decoration-style", "--commit-regex", "--commit-style",
    "--default-language", "--detect-dark-light", "--diff-args", "-@", "--diff-stat-align-width",
    "--features", "--file-added-label", "--file-copied-label", "--file-decoration-style",
    "--file-modified-label", "--file-removed-label", "--file-renamed-label", "--file-style",
    "--file-transformation", "--generate-completion", "--grep-context-line-style",
    "--grep-file-style", "--grep-header-decoration-style", "--grep-header-file-style",
    "--grep-line-number-style", "--grep-output-type", "--grep-match-line-style",
    "--grep-match-word-style", "--grep-separator-symbol", "--hunk-header-decoration-style",
    "--hunk-header-file-style", "--hunk-header-line-number-style", "--hunk-header-style",
    "--hunk-label", "--hyperlinks-commit-link-format", "--hyperlinks-file-link-format",
    "--inline-hint-style", "--inspect-raw-lines", "--line-buffer-size", "--line-fill-method",
    "--line-numbers-left-format", "--line-numbers-left-style", "--line-numbers-minus-style",
    "--line-numbers-plus-style", "--line-numbers-right-format", "--line-numbers-right-style",
    "--line-numbers-zero-style", "--map-styles", "--max-line-distance",
    "--max-syntax-highlighting-length", "--max-line-length", "--merge-conflict-begin-symbol",
    "--merge-conflict-end-symbol", "--merge-conflict-ours-diff-header-decoration-style",
    "--merge-conflict-ours-diff-header-style", "--merge-conflict-theirs-diff-header-decoration-style",
    "--merge-conflict-theirs-diff-header-style", "--minus-empty-line-marker-style",
    "--minus-emph-style", "--minus-non-emph-style", "--minus-style", "--navigate-regex",
    "--pager", "--paging", "--plus-emph-style", "--plus-empty-line-marker-style",
    "--plus-non-emph-style", "--plus-style", "--right-arrow", "--syntax-theme", "--tabs",
    "--true-color", "--24-bit-color", "--whitespace-error-style", "--width",
    "-w", "--word-diff-regex", "--wrap-left-symbol", "--wrap-max-lines",
    "--wrap-right-percent", "--wrap-right-prefix-symbol", "--wrap-right-symbol", "--zero-style",
}


def parse_args(argv):
    opts = {
        "raw": False, "color_only": False, "line_numbers": False, "side_by_side": False,
        "keep_markers": False, "parse_ansi": False, "width": 80, "syntax_theme": None,
        "command": None, "diff_args": "", "completion": None,
    }
    pos = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            pos.extend(argv[i + 1:])
            break
        if a in ("-h", "--help"):
            opts["command"] = "help_short" if a == "-h" else "help_long"
        elif a in ("-V", "--version"):
            opts["command"] = "version"
        elif a == "--raw":
            opts["raw"] = True
        elif a == "--color-only":
            opts["color_only"] = True
        elif a in ("-n", "--line-numbers"):
            opts["line_numbers"] = True
        elif a in ("-s", "--side-by-side"):
            opts["side_by_side"] = True
        elif a == "--keep-plus-minus-markers":
            opts["keep_markers"] = True
        elif a == "--parse-ansi":
            opts["parse_ansi"] = True
        elif a == "--list-languages":
            opts["command"] = "languages"
        elif a == "--list-syntax-themes":
            opts["command"] = "themes"
        elif a in ("--show-config",):
            opts["command"] = "config"
        elif a in ("--show-colors", "--show-themes", "--show-syntax-themes"):
            opts["command"] = "colors" if a == "--show-colors" else "demo"
        elif a.startswith("--generate-completion="):
            opts["command"] = "completion"
            opts["completion"] = a.split("=", 1)[1]
        elif a == "--generate-completion":
            opts["command"] = "completion"
            i += 1
            opts["completion"] = argv[i] if i < len(argv) else "bash"
        elif a.startswith("--width="):
            opts["width"] = parse_width(a.split("=", 1)[1])
        elif a in ("--width", "-w"):
            i += 1
            opts["width"] = parse_width(argv[i] if i < len(argv) else "80")
        elif a.startswith("--syntax-theme="):
            opts["syntax_theme"] = a.split("=", 1)[1]
        elif a.startswith("--diff-args="):
            opts["diff_args"] = a.split("=", 1)[1]
        elif a in VALUE_OPTIONS:
            i += 1
            if a in ("--diff-args", "-@") and i < len(argv):
                opts["diff_args"] = argv[i]
        elif a.startswith("--") and "=" in a:
            pass
        elif a.startswith("-") and a not in ("-",):
            pass
        else:
            pos.append(a)
        i += 1
    return opts, pos


def parse_width(s):
    if s == "variable":
        return 80
    m = re.match(r"^(-?\d+)(?:-(\d+))?$", s)
    if not m:
        return 80
    n = int(m.group(1))
    if n < 0:
        return max(20, shutil.get_terminal_size((80, 20)).columns + n)
    if m.group(2):
        n -= int(m.group(2))
    return max(20, n)


def c(text, code):
    return f"{code}{text}{RESET}"


def strip_ansi(s):
    return re.sub(r"\033\[[0-9;?]*[ -/]*[@-~]", "", s)


def parse_ansi_text(text):
    def repl(m):
        return f"({m.group(0)})"
    return "(normal)" + re.sub(r"\033\[[0-9;?]*[ -/]*[@-~]", repl, text)


def unified_from_files(a, b):
    try:
        with open(a, "r", encoding="utf-8", errors="replace") as f:
            left = f.readlines()
        with open(b, "r", encoding="utf-8", errors="replace") as f:
            right = f.readlines()
    except OSError as e:
        print(f"delta: {e}", file=sys.stderr)
        return 2, ""
    diff = difflib.unified_diff(left, right, fromfile=a, tofile=b, lineterm="")
    lines = []
    for line in diff:
        if not line.endswith("\n"):
            line += "\n"
        lines.append(line)
    return 0, "".join(lines)


def hunk_start(line):
    m = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", line)
    if m:
        return int(m.group(1)), int(m.group(2))
    return None


def file_label(minus, plus):
    def clean(p):
        return p[4:] if p.startswith(("--- ", "+++ ")) else p
    return f"{clean(minus).strip()} ⟶   {clean(plus).strip()}"


def render_color_only(text):
    out = []
    for line in text.splitlines(True):
        if line.startswith("+") and not line.startswith("+++"):
            out.append(f"{PLUS_BG}{line.rstrip(chr(10))}{RESET}{PLUS_BG}{ERASE}{RESET}\n")
        elif line.startswith("-") and not line.startswith("---"):
            out.append(f"{MINUS_BG}{line.rstrip(chr(10))}{RESET}{MINUS_BG}{ERASE}{RESET}\n")
        else:
            out.append(line)
    return "".join(out)


def render_normal(text, opts):
    if opts["color_only"]:
        return render_color_only(text)
    if opts["side_by_side"]:
        return render_side_by_side(text, opts)
    out = []
    old = new = None
    minus_file = plus_file = None
    for raw in text.splitlines(True):
        line = raw.rstrip("\n")
        if line.startswith("--- "):
            minus_file = line[4:]
            continue
        if line.startswith("+++ "):
            plus_file = line[4:]
            out.append("\n")
            out.append(c(file_label(minus_file or "", plus_file or ""), BLUE) + "\n")
            out.append(c("─" * opts["width"], BLUE) + "\n")
            continue
        hs = hunk_start(line)
        if hs:
            old, new = hs
            out.append("\n")
            out.append(c("───", BLUE) + c("┐", BLUE) + "\n")
            out.append(c(str(new), BLUE) + ": " + c("│", BLUE) + "\n")
            out.append(c("───", BLUE) + c("┘", BLUE) + "\n")
            continue
        prefix = ""
        body = line
        style = None
        if line.startswith("+"):
            if new is not None:
                prefix = num_prefix(None, new, "+", opts)
                new += 1
            body = line if opts["keep_markers"] else line[1:]
            style = PLUS_BG
        elif line.startswith("-"):
            if old is not None:
                prefix = num_prefix(old, None, "-", opts)
                old += 1
            body = line if opts["keep_markers"] else line[1:]
            style = MINUS_BG
        elif line.startswith(" "):
            if old is not None and new is not None:
                prefix = num_prefix(old, new, " ", opts)
                old += 1
                new += 1
            body = line[1:] if not opts["keep_markers"] else line
        if opts["line_numbers"]:
            out.append(prefix)
        if style:
            out.append(f"{style}{body}{RESET}{style}{ERASE}{RESET}\n")
        else:
            out.append(body + "\n")
    return "".join(out)


def num_prefix(old, new, kind, opts):
    if not opts["line_numbers"]:
        return ""
    l = f"{old:^4}" if old is not None else "    "
    r = f"{new:^4}" if new is not None else "    "
    if kind == " ":
        return f"{BLUE}{DIM}{l}{BLUE}⋮{DIM}{r}{BLUE}│{RESET}"
    return f"{BLUE}{RED if kind == '-' else GREEN}{l}{BLUE}⋮{GREEN if kind == '+' else RED}{r}{BLUE}│{RESET}"


def render_side_by_side(text, opts):
    width = opts["width"]
    col = max(10, (width - 7) // 2)
    out = []
    pending_minus = []
    for raw in text.splitlines(True):
        line = raw.rstrip("\n")
        if line.startswith("--- ") or line.startswith("+++ ") or hunk_start(line):
            if not line.startswith("+++ "):
                out.append(render_normal(raw, {**opts, "side_by_side": False}))
            continue
        if line.startswith("-"):
            pending_minus.append(line[1:])
        elif line.startswith("+"):
            left = pending_minus.pop(0) if pending_minus else ""
            out.append(f"{MINUS_BG}{left[:col]:<{col}}{RESET} {BLUE}│{RESET} {PLUS_BG}{line[1:][:col]:<{col}}{RESET}\n")
        else:
            while pending_minus:
                left = pending_minus.pop(0)
                out.append(f"{MINUS_BG}{left[:col]:<{col}}{RESET} {BLUE}│{RESET}\n")
            body = line[1:] if line.startswith(" ") else line
            out.append(f"{body[:col]:<{col}} {BLUE}│{RESET} {body[:col]}\n")
    while pending_minus:
        left = pending_minus.pop(0)
        out.append(f"{MINUS_BG}{left[:col]:<{col}}{RESET} {BLUE}│{RESET}\n")
    return "".join(out)


def print_languages():
    for name, exts in LANGUAGES:
        colored = ", ".join(c(x.strip(), GREEN) for x in exts.split(","))
        print(f"{name:<26}{colored}")


def print_themes():
    for kind, name in THEMES:
        print(f"{kind}\t{name}")


def print_config(opts):
    print("    commit-style                  = raw")
    print(f"    file-style                    = {c('blue', BLUE)}")
    print("    hunk-header-style             = syntax")
    print(f"    minus-style                   = {MINUS_BG}normal 52{RESET}")
    print(f"    plus-style                    = {PLUS_BG}syntax 22{RESET}")
    print("    zero-style                    = syntax")
    print(f"    grep-file-style               = {c('purple', MAGENTA)}")
    print(f"    grep-line-number-style        = {c('green', GREEN)}")
    print("    keep-plus-minus-markers       = " + str(opts["keep_markers"]).lower())
    print("    line-numbers                  = " + str(opts["line_numbers"]).lower())
    print("    paging                        = never")
    print("    side-by-side                  = " + str(opts["side_by_side"]).lower())
    print("    syntax-theme                  = " + str(opts["syntax_theme"] or "none"))
    print("    width                         = " + str(opts["width"]))
    print("    tabs                          = 8")
    print("    word-diff-regex               = '\\w+'")


def print_colors():
    groups = {
        "Blue": [("cadetblue", "#5f9ea0"), ("steelblue", "#4682b4"), ("blue", "#0000ff")],
        "Green": [("green", "#008000"), ("limegreen", "#32cd32"), ("darkgreen", "#006400")],
        "Red": [("red", "#ff0000"), ("crimson", "#dc143c"), ("darkred", "#8b0000")],
        "Yellow": [("gold", "#ffd700"), ("yellow", "#ffff00"), ("khaki", "#f0e68c")],
    }
    for group, vals in groups.items():
        print("\n" + c(group, "\033[1m") + "\n")
        for name, hx in vals:
            print(f'export function color(): string {{ return "{name}" }}')
            print(f'export function hex(): string {{ return "{hx}" }}')


def completion(shell):
    if shell == "bash":
        print("complete -W '--help --version --raw --color-only --line-numbers --side-by-side --paging --syntax-theme' delta")
    elif shell == "fish":
        print("complete -c delta -l help -d 'Print help'")
    else:
        print("#compdef delta\n_arguments '*::arg:->args'")


def main(argv):
    opts, pos = parse_args(argv)
    cmd = opts["command"]
    if cmd == "version":
        print(VERSION)
        return 0
    if cmd == "help_short":
        print(HELP_SHORT, end="")
        return 0
    if cmd == "help_long":
        help_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "full-help.md")
        if os.path.exists(help_path):
            text = open(help_path, "r", encoding="utf-8", errors="replace").read()
            m = re.search(r"```txt\n(.*?)\n```", text, re.S)
            print((m.group(1) if m else text) + "\n", end="")
        else:
            print(HELP_LONG, end="")
        return 0
    if cmd == "completion":
        completion(opts.get("completion") or "bash")
        return 0
    if cmd == "languages":
        print_languages()
        return 0
    if cmd == "themes":
        print_themes()
        return 0
    if cmd == "config":
        print_config(opts)
        return 0
    if cmd == "colors":
        print_colors()
        return 0
    if cmd == "demo":
        sample = "--- a/example.py\n+++ b/example.py\n@@ -1,2 +1,2 @@\n-print('old')\n+print('new')\n"
        print(render_normal(sample, opts), end="")
        return 0

    if len(pos) >= 2:
        status, text = unified_from_files(pos[0], pos[1])
        if status:
            return status
    else:
        text = sys.stdin.read()

    if opts["raw"]:
        sys.stdout.write(text)
        return 0
    if opts["parse_ansi"]:
        sys.stdout.write(parse_ansi_text(text))
        return 0
    sys.stdout.write(render_normal(text, opts))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
