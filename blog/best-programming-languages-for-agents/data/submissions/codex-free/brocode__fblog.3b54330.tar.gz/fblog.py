#!/usr/bin/env python3
import argparse
import datetime as _dt
import json
import os
import re
import sys

BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"

DEFAULT_MESSAGE_KEYS = ["short_message", "msg", "message"]
DEFAULT_TIME_KEYS = ["timestamp", "time", "@timestamp"]
DEFAULT_LEVEL_KEYS = ["level", "severity", "log.level", "loglevel"]


def c(code, text):
    return f"\033[{code}m{text}{RESET}"


def bold(text):
    return f"{BOLD}{text}{RESET}"


def unknown_line(text, red=False):
    color = "1;31" if red else "1;38;2;255;135;22"
    return f"\033[{color}m??? >{RESET} {text}"


def parse_args():
    p = argparse.ArgumentParser(
        prog="executable",
        description="json log viewer",
        formatter_class=argparse.RawTextHelpFormatter,
        add_help=False,
    )
    p.add_argument("input", nargs="?", default="-", metavar="INPUT")
    p.add_argument("-a", "--additional-value", action="append", default=[])
    p.add_argument("--config-file")
    p.add_argument("-m", "--message-key", action="append", default=[])
    p.add_argument("--print-lua", action="store_true")
    p.add_argument("-t", "--time-key", action="append", default=[])
    p.add_argument("-l", "--level-key", action="append", default=[])
    p.add_argument("--map-level", action="append", default=[])
    p.add_argument("-d", "--dump-all", action="store_true")
    p.add_argument("-x", "--excluded-value", action="append", default=[])
    p.add_argument("-p", "--with-prefix", action="store_true")
    p.add_argument("-f", "--filter")
    p.add_argument("--no-implicit-filter-return-statement", action="store_true")
    p.add_argument("--main-line-format")
    p.add_argument("--additional-value-format")
    p.add_argument("-s", "--substitute", action="store_true")
    p.add_argument("-c", "--context-key", default="context")
    p.add_argument("-F", "--placeholder-format", default="{key}")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-V", "--version", action="store_true")
    ns = p.parse_args()
    if ns.help:
        print_help()
        sys.exit(0)
    if ns.version:
        print("fblog 4.17.0")
        sys.exit(0)
    return ns


def print_help():
    print("""json log viewer

Usage: executable [OPTIONS] [INPUT]

Arguments:
  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]

Options:
  -a, --additional-value <additional-value>
          adds additional values
      --config-file <config-file>
          configuration file to load
  -m, --message-key <message-key>
          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.
      --print-lua
          Prints lua init expressions. Used for fblog debugging.
  -t, --time-key <time-key>
          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.
  -l, --level-key <level-key>
          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.
      --map-level <from=to>
          Rewrite the log level from one value to another.
  -d, --dump-all
          dumps all values
  -x, --excluded-value <excluded-value>
          Excludes values (--dump-all is enabled implicitly)
  -p, --with-prefix
          consider all text before opening curly brace as prefix
  -f, --filter <filter>
          lua expression to filter log entries. `message ~= nil and string.find(message, "text.*") ~= nil`
      --no-implicit-filter-return-statement
          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.
      --main-line-format <main-line-format>
          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.
      --additional-value-format <additional-value-format>
          Formats the additional value fblog output.
  -s, --substitute
          Enable substitution of placeholders in the log messages with their corresponding values from the context.
  -c, --context-key <context-key>
          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).
  -F, --placeholder-format <placeholder-format>
          The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${key}.
  -h, --help
          Print help
  -V, --version
          Print version""")


def load_config(path):
    cfg = {}
    if not path:
        return cfg
    section = None
    try:
        text = open(path, encoding="utf-8").read()
    except OSError:
        return cfg
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            if line.startswith("[") and line.endswith("]"):
                section = line[1:-1]
            continue
        k, v = [x.strip() for x in line.split("=", 1)]
        if section == "level_map":
            cfg.setdefault("level_map", {})[k.strip('"')] = v.strip('"')
            continue
        if v.startswith("[") and v.endswith("]"):
            cfg[k] = re.findall(r'"([^"]*)"', v)
        elif v.startswith('"') and v.endswith('"'):
            cfg[k] = v[1:-1]
    return cfg


def flatten(value, prefix="", array_depth=0, string_from_array=False):
    out = []
    if isinstance(value, dict):
        for k in sorted(value):
            name = f"{prefix} > {k}" if prefix else str(k)
            out.extend(flatten(value[k], name, array_depth, False))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            shown = i if array_depth == 0 else i + 1
            name = f"{prefix}[{shown}]"
            out.extend(flatten(item, name, array_depth + 1, True))
    else:
        out.append((prefix, value, string_from_array))
    return out


def resolve_path(obj, key):
    if key in obj:
        return obj[key], False
    cur = obj
    array_depth = 0
    from_array = False
    for part in [p.strip() for p in key.split(">")]:
        if not part:
            continue
        bits = re.findall(r"([^\[\]]+)|\[(\d+)\]", part)
        if not bits:
            return None, from_array
        first = True
        for name, idx_s in bits:
            name = name.strip()
            if name:
                if not isinstance(cur, dict) or name not in cur:
                    return None, from_array
                cur = cur[name]
                first = False
                continue
            idx_num = int(idx_s)
            idx = idx_num if array_depth == 0 else idx_num - 1
            if not isinstance(cur, list) or idx < 0 or idx >= len(cur):
                return None, from_array
            cur = cur[idx]
            array_depth += 1
            from_array = True
            first = False
        if first:
            return None, from_array
    return cur, from_array


def get_path(obj, key):
    return resolve_path(obj, key)[0]


def first_value(obj, keys):
    for k in keys:
        v = get_path(obj, k)
        if v is not None:
            return v
    return None


def fmt_time(v):
    if v is None:
        return "???"
    s = str(v)
    if re.fullmatch(r"\d{13}", s):
        try:
            return _dt.datetime.utcfromtimestamp(int(s) / 1000).strftime("%Y-%m-%dT%H:%M:%S")
        except Exception:
            pass
    if re.match(r"^[A-Z][a-z][a-z] [A-Z][a-z][a-z] \d\d? \d\d:\d\d:\d\d ", s):
        return s[:19]
    return s.replace("Z", "")[:19]


def level_color(level):
    lv = str(level or "UNKNO").lower()
    if lv == "trace":
        return "1;36"
    if lv == "debug":
        return "1;34"
    if lv in ("info", "information"):
        return "1;32"
    if lv in ("warn", "warning"):
        return "1;33" if lv == "warn" else "1;35"
    if lv in ("error", "err"):
        return "1;31"
    if lv in ("fatal", "critical", "unkno", "unknown"):
        return "1;35"
    return "1;35"


def fmt_level(level):
    s = str(level if level is not None else "UNKNO").upper()[:5].rjust(5)
    return c(level_color(level), s)


def val_plain(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)):
        return str(v)
    if isinstance(v, (list, dict)):
        return json.dumps(v, ensure_ascii=False, separators=(",", ":"))
    return str(v)


def val_rich(v):
    if isinstance(v, bool):
        return c("1;32" if v else "1;31", "true" if v else "false")
    if isinstance(v, (int, float)):
        return c("1;36", str(v))
    if isinstance(v, str):
        return c("1;33", v)
    if isinstance(v, list):
        return DIM + "[" + RESET + (DIM + ", " + RESET).join(val_rich(x) for x in v) + DIM + "]" + RESET
    if isinstance(v, dict):
        parts = []
        for k in sorted(v):
            parts.append(c("35", k) + DIM + ": " + RESET + val_rich(v[k]))
        return DIM + "{" + RESET + (DIM + ", " + RESET).join(parts) + DIM + "}" + RESET
    return val_plain(v)


def substitute_message(msg, ctx, placeholder):
    if not isinstance(msg, str):
        return val_plain(msg)
    if ctx is None:
        return msg
    def repl(m):
        key = m.group(1)
        value = None
        if isinstance(ctx, list) and key.isdigit():
            idx = int(key)
            if 0 <= idx < len(ctx):
                value = ctx[idx]
        elif isinstance(ctx, dict) and key in ctx:
            value = ctx[key]
        if value is None:
            return DIM + "{" + RESET + c("1;31", key) + DIM + "}" + RESET
        return val_rich(value)
    if placeholder == "{key}":
        return re.sub(r"\{([^{}]+)\}", repl, msg)
    pat = re.escape(placeholder).replace("key", r"([^{}$\[\]#]+)")
    return re.sub(pat, repl, msg)


def parse_map(items):
    mp = {}
    for it in items:
        if "=" in it:
            a, b = it.split("=", 1)
            mp[a] = b
    return mp


def filter_ok(expr, env):
    if not expr:
        return True
    e = expr.strip()
    if e.startswith("return "):
        e = e[7:].strip()
    e = e.replace("~=", "!=").replace(" nil", " None").replace(" and ", " and ").replace(" or ", " or ")
    m = re.fullmatch(r'([\w_.]+)\s*==\s*"([^"]*)"', e)
    if m:
        return str(env.get(m.group(1), "")) == m.group(2)
    m = re.fullmatch(r'([\w_.]+)\s*!=\s*"([^"]*)"', e)
    if m:
        return str(env.get(m.group(1), "")) != m.group(2)
    m = re.fullmatch(r'string\.find\(([\w_.]+),\s*"([^"]*)"\)\s*!=\s*None', e)
    if m:
        return re.search(m.group(2), str(env.get(m.group(1), ""))) is not None
    # Conservative fallback: do not drop lines for unsupported Lua.
    return True


def render_template(tpl, env):
    if tpl is None:
        return None
    out = tpl
    for k, v in sorted(env.items(), key=lambda kv: -len(kv[0])):
        out = out.replace("{{" + k + "}}", val_plain(v))
    # Common wrappers used by the default config.
    out = re.sub(r"\{\{uppercase ([^{}]+)\}\}", lambda m: str(env.get(m.group(1), "")).upper(), out)
    return out


def main():
    ns = parse_args()
    if ns.print_lua:
        return 0
    cfg = load_config(ns.config_file)
    message_keys = ns.message_key + cfg.get("message_keys", DEFAULT_MESSAGE_KEYS)
    time_keys = ns.time_key + cfg.get("time_keys", DEFAULT_TIME_KEYS)
    level_keys = ns.level_key + cfg.get("level_keys", DEFAULT_LEVEL_KEYS)
    level_map = cfg.get("level_map", {})
    level_map.update(parse_map(ns.map_level))
    dump_all = ns.dump_all or bool(ns.excluded_value)
    excluded = set(ns.excluded_value)

    try:
        fh = sys.stdin.buffer if ns.input == "-" else open(ns.input, "rb")
    except OSError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    with fh:
        for raw in fh:
            try:
                line = raw.decode("utf-8").rstrip("\n")
            except UnicodeDecodeError:
                print(unknown_line("Could not read line: stream did not contain valid UTF-8", red=True))
                continue
            if line.endswith("\r"):
                line = line[:-1]
            prefix = ""
            json_text = line
            if ns.with_prefix:
                pos = line.find("{")
                if pos > 0:
                    prefix = line[:pos].rstrip()
                    json_text = line[pos:]
            try:
                obj = json.loads(json_text)
                if not isinstance(obj, dict):
                    raise ValueError
            except Exception:
                print(unknown_line(line))
                continue

            msg = first_value(obj, message_keys)
            ts = fmt_time(first_value(obj, time_keys))
            lvl = first_value(obj, level_keys)
            if lvl is not None:
                lvl = level_map.get(str(lvl), lvl)
            if lvl is None:
                lvl = "UNKNO"
            if msg is None:
                msg = json_text
            ctx = get_path(obj, ns.context_key)
            if ns.substitute:
                msg_out = substitute_message(str(msg), ctx, ns.placeholder_format)
            else:
                msg_out = val_plain(msg)

            env = dict(obj)
            env.update({
                "message": msg,
                "level": first_value(obj, level_keys),
                "fblog_message": msg,
                "fblog_timestamp": ts,
                "fblog_level": lvl,
                "fblog_prefix": prefix,
            })
            if not filter_ok(ns.filter, env):
                continue

            templ = render_template(ns.main_line_format or cfg.get("main_line_format"), env)
            if ns.main_line_format:
                print(templ)
            else:
                pre = ""
                if prefix:
                    pre = f" {BOLD}\033[36m{prefix}{RESET}{RESET}"
                print(f"{bold(ts)} {fmt_level(lvl)}:{pre} {msg_out}")

            fields = []
            if dump_all:
                fields = flatten(obj)
            for name in ns.additional_value:
                value, from_array = resolve_path(obj, name)
                if value is not None:
                    fields.append((name, value, from_array))
            for item in fields:
                if len(item) == 2:
                    name, value = item
                    quote_string = False
                else:
                    name, value, quote_string = item
                if name in excluded:
                    continue
                key = name.rjust(25)
                shown = json.dumps(value, ensure_ascii=False) if quote_string and isinstance(value, str) else val_plain(value)
                print(f"{BOLD}\033[38;2;150;150;150m{key}{RESET}{RESET}: {shown}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
