#!/usr/bin/env python3
import os
import sys

HELP = """Interactive Grep

Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...

Arguments:
  <PATTERN>   Regular expression used for searching
  [PATHS]...  Files or directories to search. Directories are searched recursively. If not specified, searching starts from current directory

Options:
      --editor <EDITOR>
          Text editor used to open selected match [possible values: vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh]
      --custom-command <CUSTOM_COMMAND>
          Custom command used to open selected match. Must contain {file_name} and {line_number} tokens [env: IGREP_CUSTOM_EDITOR=]
      --theme <THEME>
          UI color theme [default: dark] [possible values: light, dark]
  -i, --ignore-case
          Searches case insensitively
  -S, --smart-case
          Searches case insensitively if the pattern is all lowercase. Search case sensitively otherwise
  -., --hidden
          Search hidden files and directories. By default, hidden files and directories are skipped
  -L, --follow
          Follow symbolic links while traversing directories
  -w, --word-regexp
          Only show matches surrounded by word boundaries
  -F, --fixed-strings
          Exact matches with no regex. Useful when searching for a string full of delimiters
  -U, --multiline
          Search with pattern contains newline character ('\\n')
  -g, --glob <GLOB>
          Include files and directories for searching that match the given glob. Multiple globs may be provided
      --type-list
          Show all supported file types and their corresponding globs
  -t, --type <TYPE_MATCHING>
          Only search files matching TYPE. Multiple types may be provided
  -T, --type-not <TYPE_NOT>
          Do not search files matching TYPE-NOT. Multiple types-not may be provided
      --context-viewer <CONTEXT_VIEWER>
          Context viewer position at startup [default: none] [possible values: none, vertical, horizontal]
      --sort <SORT_BY>
          Sort results, see ripgrep for details [possible values: path, modified, created, accessed]
      --sortr <SORT_BY_REVERSE>
          Sort results reverse, see ripgrep for details [possible values: path, modified, created, accessed]
  -h, --help
          Print help
  -V, --version
          Print version
"""

EDITORS = {
    "vim", "neovim", "nvim", "nano", "code", "vscode", "code-insiders",
    "emacs", "emacsclient", "hx", "helix", "subl", "sublime-text",
    "micro", "intellij", "goland", "pycharm", "less", "fresh",
}
EDITOR_VALUES = "vim, neovim, nvim, nano, code, vscode, code-insiders, emacs, emacsclient, hx, helix, subl, sublime-text, micro, intellij, goland, pycharm, less, fresh"
THEMES = {"light", "dark"}
VIEWERS = {"none", "vertical", "horizontal"}
SORTS = {"path", "modified", "created", "accessed"}


def err(msg, code=2):
    sys.stderr.write(msg)
    if not msg.endswith("\n"):
        sys.stderr.write("\n")
    raise SystemExit(code)


def type_list():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "type-list.txt")
    with open(path, "r", encoding="utf-8") as f:
        sys.stdout.write(f.read())


def known_types():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "type-list.txt")
    names = set()
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if ":" in line:
                names.add(line.split(":", 1)[0])
    return names


def missing_value(name, metavar=None, values=None):
    text = f"error: a value is required for '{name}"
    if metavar:
        text += f" <{metavar}>"
    text += "' but none was supplied\n"
    if values:
        text += f"  [possible values: {values}]\n"
    text += "\nFor more information, try '--help'.\n"
    err(text)


def invalid_value(name, metavar, value, values):
    err(
        f"error: invalid value '{value}' for '{name} <{metavar}>'\n"
        f"  [possible values: {values}]\n\n"
        "For more information, try '--help'.\n"
    )


def unexpected(arg):
    err(
        f"error: unexpected argument '{arg}' found\n\n"
        f"  tip: to pass '{arg}' as a value, use '-- {arg}'\n\n"
        "Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\n"
        "For more information, try '--help'.\n"
    )


def validate_custom(cmd):
    if cmd is None:
        cmd = os.environ.get("IGREP_CUSTOM_EDITOR")
    if not cmd:
        return
    cause = None
    if " " not in cmd.strip():
        cause = "Expected program and its arguments"
    elif cmd.count("{line_number}") != 1:
        cause = "Expected one occurrence of '{line_number}'."
    elif cmd.count("{file_name}") != 1:
        cause = "Expected one occurrence of '{file_name}'."
    if cause:
        err(f"Error: Incorrect editor command: '{cmd}'\n\nCaused by:\n    {cause}\n", 1)


def main(argv):
    if any(a in ("--help", "-h") for a in argv):
        sys.stdout.write(HELP)
        return 0
    if any(a in ("--version", "-V") for a in argv):
        sys.stdout.write("igrep 1.3.0\n")
        return 0

    positional = []
    type_list_seen = False
    custom_command = None
    seen_single = {}
    i = 0
    end_opts = False
    while i < len(argv):
        a = argv[i]
        if end_opts:
            positional.append(a)
            i += 1
            continue
        if a == "--":
            end_opts = True
            i += 1
            continue
        if a == "--type-list":
            type_list_seen = True
            i += 1
            continue
        if a.startswith("--") and "=" in a:
            opt, val = a.split("=", 1)
            if opt in ("--editor", "--theme", "--custom-command", "--context-viewer", "--sort", "--sortr", "--glob", "--type", "--type-not"):
                a = opt
                argv = argv[:i] + [opt, val] + argv[i + 1:]
            else:
                unexpected(a)
        if a in ("--editor", "--theme", "--custom-command", "--context-viewer", "--sort", "--sortr", "-g", "--glob", "-t", "--type", "-T", "--type-not"):
            if a in ("--editor", "--theme", "--custom-command", "--context-viewer", "--sort", "--sortr"):
                display = {
                    "--editor": "--editor <EDITOR>",
                    "--theme": "--theme <THEME>",
                    "--custom-command": "--custom-command <CUSTOM_COMMAND>",
                    "--context-viewer": "--context-viewer <CONTEXT_VIEWER>",
                    "--sort": "--sort <SORT_BY>",
                    "--sortr": "--sortr <SORT_BY_REVERSE>",
                }[a]
                if seen_single.get(a):
                    err(
                        f"error: the argument '{display}' cannot be used multiple times\n\n"
                        "Usage: executable [OPTIONS] --type-list <PATTERN> [PATHS]...\n\n"
                        "For more information, try '--help'.\n"
                    )
                if (a == "--editor" and seen_single.get("--custom-command")) or (a == "--custom-command" and seen_single.get("--editor")):
                    err(
                        "error: the argument '--editor <EDITOR>' cannot be used with '--custom-command <CUSTOM_COMMAND>'\n\n"
                        "Usage: executable --type-list --editor <EDITOR> <PATTERN> [PATHS]...\n\n"
                        "For more information, try '--help'.\n"
                    )
                seen_single[a] = True
            if i + 1 >= len(argv):
                if a in ("--editor",):
                    missing_value("--editor", "EDITOR", EDITOR_VALUES)
                if a in ("-g", "--glob"):
                    missing_value("--glob", "GLOB")
                if a in ("-t", "--type"):
                    missing_value("--type", "TYPE_MATCHING")
                if a in ("-T", "--type-not"):
                    missing_value("--type-not", "TYPE_NOT")
                if a == "--custom-command":
                    missing_value("--custom-command", "CUSTOM_COMMAND")
                if a == "--theme":
                    missing_value("--theme", "THEME", "light, dark")
                if a == "--context-viewer":
                    missing_value("--context-viewer", "CONTEXT_VIEWER", "none, vertical, horizontal")
                if a == "--sort":
                    missing_value("--sort", "SORT_BY", "path, modified, created, accessed")
                if a == "--sortr":
                    missing_value("--sortr", "SORT_BY_REVERSE", "path, modified, created, accessed")
            val = argv[i + 1]
            if a == "--editor" and val not in EDITORS:
                invalid_value("--editor", "EDITOR", val, EDITOR_VALUES)
            elif a == "--theme" and val not in THEMES:
                invalid_value("--theme", "THEME", val, "light, dark")
            elif a == "--context-viewer" and val not in VIEWERS:
                invalid_value("--context-viewer", "CONTEXT_VIEWER", val, "none, vertical, horizontal")
            elif a == "--sort" and val not in SORTS:
                invalid_value("--sort", "SORT_BY", val, "path, modified, created, accessed")
            elif a == "--sortr" and val not in SORTS:
                invalid_value("--sortr", "SORT_BY_REVERSE", val, "path, modified, created, accessed")
            elif a == "--custom-command":
                custom_command = val
            # ripgrep type errors happen after clap parsing.
            elif a in ("-t", "--type", "-T", "--type-not") and val not in known_types():
                err(f"Error: unrecognized file type: {val}\n", 1)
            i += 2
            continue
        if len(a) > 2 and a[0] == "-" and a[1] in "gtT":
            opt = {"g": "-g", "t": "-t", "T": "-T"}[a[1]]
            argv = argv[:i] + [opt, a[2:]] + argv[i + 1:]
            continue
        if a.startswith("--"):
            if type_list_seen:
                err(
                    f"error: unexpected argument '{a}' found\n\n"
                    f"  tip: to pass '{a}' as a value, use '-- {a}'\n\n"
                    "Usage: executable <PATTERN|--type-list> [PATHS]...\n\n"
                    "For more information, try '--help'.\n"
                )
            if a == "--type-add":
                err(
                    "error: unexpected argument '--type-add' found\n\n"
                    "  tip: a similar argument exists: '--type'\n\n"
                    "Usage: executable --type-list --type <TYPE_MATCHING> <PATTERN> [PATHS]...\n\n"
                    "For more information, try '--help'.\n"
                )
            if a == "--files":
                err(
                    "error: unexpected argument '--files' found\n\n"
                    "  tip: a similar argument exists: '--fixed-strings'\n\n"
                    "Usage: executable --type-list --fixed-strings <PATTERN> [PATHS]...\n\n"
                    "For more information, try '--help'.\n"
                )
            unexpected(a)
        if a.startswith("-") and a != "-":
            # The real CLI allows bundled known shorts; unknown shorts are rejected.
            known = set("iSLwFU.")
            if all(ch in known for ch in a[1:]):
                i += 1
                continue
            unexpected(a)
        positional.append(a)
        i += 1

    if type_list_seen:
        if positional:
            usage = "Usage: executable --type-list <PATTERN>"
            if len(positional) > 1:
                usage += " <PATHS>..."
            else:
                usage += " [PATHS]..."
            err(
                "error: the argument '--type-list' cannot be used with '<PATTERN>'\n\n"
                f"{usage}\n\n"
                "For more information, try '--help'.\n"
            )
        type_list()
        return 0

    if not positional:
        err(
            "error: the following required arguments were not provided:\n"
            "  --type-list\n"
            "  <PATTERN>\n\n"
            "Usage: executable --type-list <PATTERN> [PATHS]...\n\n"
            "For more information, try '--help'.\n"
        )

    validate_custom(custom_command)
    sys.stderr.write("Error: Resource temporarily unavailable (os error 11)\n")
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
