#!/usr/bin/env python3
import fnmatch
import gzip
import lzma
import os
import re
import stat
import sys
import time

STDIN_CACHE = None

VERSION = """ag version 2.2.0

Features:
  +jit +lzma +zlib"""

HELP = """Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
                          (This often differs from the number of matching lines)
     --[no]color          Print color codes in results (Enabled by default)
     --color-line-number  Color codes for line numbers (Default: 1;33)
     --color-match        Color codes for result match numbers (Default: 30;43)
     --color-path         Color codes for path names (Default: 1;32)
     --column             Print column numbers in results
     --[no]filename       Print file names (Enabled unless searching a single file)
  -H --[no]heading        Print file names before each file's matches
                          (Enabled by default)
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -l --files-with-matches Only print filenames that contain matches
                          (don't print the matching lines)
  -L --files-without-matches
                          Only print filenames that don't contain matches
     --print-all-files    Print headings for all files searched, even those that
                          don't contain matches
     --[no]numbers        Print line numbers. Default is to omit line numbers
                          when searching streams
  -o --only-matching      Prints only the matching part of the lines
     --print-long-lines   Print matches on very long lines (Default: >2k characters)
     --passthrough        When searching a stream, print all lines even if they
                          don't match
     --silent             Suppress all log messages, including errors
     --stats              Print stats (files scanned, time taken, etc.)
     --stats-only         Print stats and nothing else.
                          (Same as --count when searching a single file)
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
                          (it reports every match on the line)
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files (doesn't include hidden files
                          or patterns from ignore files)
  -D --debug              Ridiculous debugging (probably not useful)
     --depth NUM          Search up to NUM directories deep (Default: 25)
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files (obeys .*ignore files)
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
                          (literal file/directory names also allowed)
     --ignore-dir NAME    Alias for --ignore for compatibility with ack.
  -m --max-count NUM      Skip the rest of a file after NUM matches (Default: 10,000)
     --one-device         Don't follow links to other devices.
  -p --path-to-ignore STRING
                          Use .ignore file at STRING
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
     --search-binary      Search binary files for matches
  -t --all-text           Search all text files (doesn't include hidden files)
  -u --unrestricted       Search all files (ignore .ignore, .gitignore, etc.;
                          searches binary and hidden files as well)
  -U --skip-vcs-ignores   Ignore VCS ignore files
                          (.gitignore, .hgignore; still obey .ignore)
  -v --invert-match
  -w --word-regexp        Only match whole words
  -W --width NUM          Truncate match lines after NUM characters
  -z --search-zip         Search contents of compressed (e.g., gzip) files

File Types:
The search can be restricted to certain types of files. Example:
  ag --html needle
  - Searches for 'needle' in files with suffix .htm, .html, .shtml or .xhtml.

For a list of supported file types run:
  ag --list-file-types

ag was originally created by Geoff Greer. More information (and the latest release)
can be found at http://geoff.greer.fm/ag"""

TYPE_EXTS = {
    "actionscript": [".as", ".mxml"], "ada": [".ada", ".adb", ".ads"],
    "asciidoc": [".adoc", ".ad", ".asc", ".asciidoc"], "apl": [".apl"],
    "asm": [".asm", ".s"], "asp": [".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"],
    "aspx": [".asp", ".asa", ".aspx", ".asax", ".ashx", ".ascx", ".asmx"], "batch": [".bat", ".cmd"],
    "bazel": [".bazel"], "bitbake": [".bb", ".bbappend", ".bbclass", ".inc"], "cc": [".c", ".h", ".xs"],
    "cfmx": [".cfc", ".cfm", ".cfml"], "chpl": [".chpl"], "clojure": [".clj", ".cljs", ".cljc", ".cljx", ".edn"],
    "coffee": [".coffee", ".cjsx"], "config": [".config"], "coq": [".coq", ".g", ".v"],
    "cpp": [".cpp", ".cc", ".C", ".cxx", ".m", ".hpp", ".hh", ".h", ".H", ".hxx", ".tpp"],
    "crystal": [".cr", ".ecr"], "csharp": [".cs"], "cshtml": [".cshtml"], "css": [".css"],
    "cython": [".pyx", ".pxd", ".pxi"], "delphi": [".pas", ".int", ".dfm", ".nfm", ".dof", ".dpk", ".dpr", ".dproj", ".groupproj", ".bdsgroup", ".bdsproj"],
    "dlang": [".d", ".di"], "dot": [".dot", ".gv"], "dts": [".dts", ".dtsi"],
    "elisp": [".el"], "elixir": [".ex", ".exs"], "elm": [".elm"], "erlang": [".erl", ".hrl"],
    "fortran": [".f", ".f77", ".f90", ".f95", ".f03", ".for", ".ftn", ".fpp"], "go": [".go"],
    "groovy": [".groovy", ".gtmpl", ".gpp", ".grunit", ".gradle"], "haml": [".haml"],
    "haskell": [".hs", ".lhs"], "html": [".htm", ".html", ".shtml", ".xhtml"],
    "jade": [".jade"], "java": [".java", ".properties"], "js": [".js", ".jsx", ".vue"],
    "json": [".json"], "jsp": [".jsp", ".jspx", ".jhtm", ".jhtml"], "less": [".less"],
    "lisp": [".lisp", ".lsp"], "lua": [".lua"], "make": ["Makefile", ".mk", ".mak"],
    "markdown": [".md", ".markdown", ".mkd", ".mkdn"], "matlab": [".m"], "objc": [".m", ".h"],
    "objcpp": [".mm", ".h"], "ocaml": [".ml", ".mli", ".mll", ".mly"], "perl": [".pl", ".pm", ".pod", ".t"],
    "php": [".php", ".phpt", ".php3", ".php4", ".php5", ".phtml"], "pike": [".pike", ".pmod"],
    "python": [".py"], "r": [".R", ".r", ".Rmd", ".Rnw"], "ruby": [".rb", ".rhtml", ".rjs", ".rxml", ".erb", ".rake", ".spec"],
    "rust": [".rs"], "scala": [".scala"], "scss": [".scss"], "shell": [".sh", ".bash", ".csh", ".tcsh", ".ksh", ".zsh"],
    "sql": [".sql", ".ctl"], "swift": [".swift"], "tcl": [".tcl", ".itcl", ".itk"], "tex": [".tex", ".cls", ".sty"],
    "ts": [".ts", ".tsx"], "tt": [".tt", ".tt2", ".ttml"], "vim": [".vim"], "xml": [".xml", ".dtd", ".xsl", ".xslt", ".ent"],
    "yaml": [".yaml", ".yml"],
}

class Opt:
    def __init__(self):
        self.after = self.before = 0
        self.breaks = False
        self.count = False
        self.column = False
        self.filename = None
        self.heading = False
        self.files_with = False
        self.files_without = False
        self.only = False
        self.vimgrep = False
        self.ackmate = False
        self.numbers = None
        self.ignore_case = None
        self.literal = False
        self.word = False
        self.invert = False
        self.hidden = False
        self.unrestricted = False
        self.all_types = False
        self.all_text = False
        self.search_binary = False
        self.follow = False
        self.norecurse = False
        self.depth = 25
        self.max_count = 10000
        self.width = None
        self.file_re = None
        self.name_re = None
        self.ignores = []
        self.path_ignore = None
        self.skip_vcs = False
        self.search_zip = False
        self.passthrough = False
        self.silent = False
        self.stats = False
        self.stats_only = False
        self.null = False
        self.types = set()

def die(msg, code=1):
    sys.stderr.write(msg + "\n")
    sys.exit(code)

def print_file_types():
    print("The following file types are supported:")
    for name in sorted(TYPE_EXTS):
        print(f"  --{name}")
        print("      " + "  ".join(TYPE_EXTS[name]))
        print()

def parse_int_arg(args, i, default):
    if i + 1 < len(args) and not args[i + 1].startswith("-"):
        try:
            return int(args[i + 1]), i + 2
        except ValueError:
            die(f"ERR: Bad value for option {args[i]}")
    return default, i + 1

def parse(argv):
    opt = Opt()
    pos = []
    i = 0
    stop = False
    while i < len(argv):
        a = argv[i]
        if stop or not a.startswith("-") or a == "-":
            pos.append(a); i += 1; continue
        if re.match(r"^-[ABC]\d+$", a):
            n = int(a[2:])
            if a[1] == "A":
                opt.after = n
            elif a[1] == "B":
                opt.before = n
            else:
                opt.before = opt.after = n
            i += 1
            continue
        if re.match(r"^-m\d+$", a):
            opt.max_count = int(a[2:]); i += 1; continue
        if re.match(r"^-W\d+$", a):
            opt.width = int(a[2:]); i += 1; continue
        if a == "--":
            stop = True; i += 1; continue
        if a in ("--help", "-h"):
            print(HELP); sys.exit(0)
        if a in ("--version", "-V"):
            print(VERSION); sys.exit(0)
        if a == "--list-file-types":
            print_file_types(); sys.exit(0)
        if a.startswith("--") and a[2:] in TYPE_EXTS:
            opt.types.add(a[2:]); i += 1; continue
        if a in ("-A", "--after"):
            opt.after, i = parse_int_arg(argv, i, 2); continue
        if a in ("-B", "--before"):
            opt.before, i = parse_int_arg(argv, i, 2); continue
        if a in ("-C", "--context"):
            n, i = parse_int_arg(argv, i, 2); opt.before = opt.after = n; continue
        if a in ("-c", "--count"): opt.count = True
        elif a == "--column": opt.column = True
        elif a in ("-H", "--heading", "--group"): opt.heading = True; opt.breaks = True
        elif a in ("--noheading", "--nogroup", "--no-heading", "--no-group"): opt.heading = False; opt.breaks = False
        elif a == "--break": opt.breaks = True
        elif a == "--nobreak": opt.breaks = False
        elif a in ("--filename",): opt.filename = True
        elif a in ("--nofilename", "--no-filename"): opt.filename = False
        elif a in ("-l", "--files-with-matches"): opt.files_with = True
        elif a in ("-L", "--files-without-matches"): opt.files_without = True
        elif a in ("-o", "--only-matching"): opt.only = True
        elif a == "--vimgrep": opt.vimgrep = True
        elif a == "--ackmate": opt.ackmate = True
        elif a == "--numbers": opt.numbers = True
        elif a in ("--nonumbers", "--no-numbers"): opt.numbers = False
        elif a in ("-i", "--ignore-case"): opt.ignore_case = True
        elif a in ("-s", "--case-sensitive"): opt.ignore_case = False
        elif a in ("-S", "--smart-case"): opt.ignore_case = None
        elif a in ("-Q", "--literal", "-F", "--fixed-strings"): opt.literal = True
        elif a in ("-w", "--word-regexp"): opt.word = True
        elif a in ("-v", "--invert-match"): opt.invert = True
        elif a == "--hidden": opt.hidden = True
        elif a in ("-u", "--unrestricted"): opt.unrestricted = True; opt.hidden = True; opt.search_binary = True
        elif a in ("-a", "--all-types"): opt.all_types = True
        elif a in ("-t", "--all-text"): opt.all_text = True
        elif a == "--search-binary": opt.search_binary = True
        elif a in ("-f", "--follow"): opt.follow = True
        elif a in ("-n", "--norecurse"): opt.norecurse = True
        elif a in ("-U", "--skip-vcs-ignores"): opt.skip_vcs = True
        elif a in ("-z", "--search-zip"): opt.search_zip = True
        elif a in ("--passthrough", "--passthru"): opt.passthrough = True
        elif a == "--silent": opt.silent = True
        elif a == "--stats": opt.stats = True
        elif a == "--stats-only": opt.stats_only = True
        elif a in ("-0", "--null", "--print0"): opt.null = True
        elif a == "--print-long-lines": pass
        elif a in ("--nocolor", "--color", "--color-line-number", "--color-match", "--color-path", "--mmap", "--nommap", "--multiline", "--nomultiline", "--affinity", "--noaffinity", "--pager", "--nopager", "--parallel", "--one-device", "--print-all-files", "--debug", "-D", "--workers"):
            if a in ("--pager", "--color-line-number", "--color-match", "--color-path", "--workers") and i + 1 < len(argv) and not argv[i + 1].startswith("-"):
                i += 1
        elif a in ("-g", "--filename-pattern"):
            if i + 1 >= len(argv): die("ERR: Missing filename pattern")
            opt.name_re = argv[i + 1]; i += 1
        elif a in ("-G", "--file-search-regex"):
            if i + 1 >= len(argv): die("ERR: Missing file search regex")
            opt.file_re = argv[i + 1]; i += 1
        elif a in ("--ignore", "--ignore-dir"):
            if i + 1 >= len(argv): die("ERR: Missing ignore pattern")
            opt.ignores.append(argv[i + 1]); i += 1
        elif a in ("-p", "--path-to-ignore"):
            if i + 1 >= len(argv): die("ERR: Missing ignore path")
            opt.path_ignore = argv[i + 1]; i += 1
        elif a == "--depth":
            if i + 1 >= len(argv): die("ERR: Missing depth")
            opt.depth = int(argv[i + 1]); i += 1
        elif a in ("-m", "--max-count"):
            if i + 1 >= len(argv): die("ERR: Missing max-count")
            opt.max_count = int(argv[i + 1]); i += 1
        elif a in ("-W", "--width"):
            if i + 1 >= len(argv): die("ERR: Missing width")
            opt.width = int(argv[i + 1]); i += 1
        elif len(a) > 2 and a.startswith("-") and not a.startswith("--"):
            # Small cluster support for common flags, e.g. -il.
            expanded = ["-" + ch for ch in a[1:]]
            argv = argv[:i] + expanded + argv[i+1:]
            continue
        else:
            die(f"ERR: Unrecognized option: {a}")
        i += 1
    return opt, pos

def load_ignore_file(path):
    out = []
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    out.append(line)
    except OSError:
        pass
    return out

def hidden_path(path, root):
    try:
        rel = os.path.relpath(path, root)
    except ValueError:
        rel = path
    return any(part.startswith(".") and part not in (".", "..") for part in rel.split(os.sep))

def ignored(path, root, pats):
    rel = os.path.relpath(path, root).replace(os.sep, "/")
    base = os.path.basename(path)
    for pat in pats:
        p = pat.strip()
        if not p or p.startswith("!"):
            continue
        p = p.lstrip("/")
        dirpat = p.endswith("/")
        p = p.rstrip("/")
        if fnmatch.fnmatch(base, p) or fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(rel, p + "/*"):
            return True
        if dirpat and (rel == p or rel.startswith(p + "/") or base == p):
            return True
    return False

def type_ok(path, opt):
    if not opt.types:
        return True
    base = os.path.basename(path)
    for t in opt.types:
        for ext in TYPE_EXTS.get(t, []):
            if ext.startswith(".") and path.endswith(ext):
                return True
            if base == ext:
                return True
    return False

def iter_files(paths, opt):
    for root in paths:
        if root == "-":
            yield "-"
            continue
        if os.path.isfile(root):
            yield root
            continue
        if not os.path.isdir(root):
            if not opt.silent:
                sys.stderr.write(f"ERR: Error opening directory {root}: No such file or directory\n")
            continue
        base_depth = root.rstrip(os.sep).count(os.sep)
        global_ign = []
        if opt.path_ignore:
            global_ign.extend(load_ignore_file(opt.path_ignore))
        for cur, dirs, files in os.walk(root, followlinks=opt.follow):
            depth = cur.rstrip(os.sep).count(os.sep) - base_depth
            local_ign = list(global_ign)
            if not opt.unrestricted and not opt.all_types and not opt.all_text:
                local_ign.extend(load_ignore_file(os.path.join(cur, ".ignore")))
                if not opt.skip_vcs:
                    local_ign.extend(load_ignore_file(os.path.join(cur, ".gitignore")))
                    local_ign.extend(load_ignore_file(os.path.join(cur, ".hgignore")))
            local_ign.extend(opt.ignores)
            ndirs = []
            for d in dirs:
                p = os.path.join(cur, d)
                if opt.norecurse or (opt.depth >= 0 and depth >= opt.depth):
                    continue
                if not (opt.hidden or opt.unrestricted) and d.startswith("."):
                    continue
                if not opt.unrestricted and not opt.all_types and not opt.all_text and ignored(p, root, local_ign):
                    continue
                ndirs.append(d)
            dirs[:] = ndirs
            for f in files:
                p = os.path.join(cur, f)
                if not (opt.hidden or opt.unrestricted) and hidden_path(p, root):
                    continue
                if not opt.unrestricted and not opt.all_types and not opt.all_text and ignored(p, root, local_ign):
                    continue
                if opt.file_re and not re.search(opt.file_re, p):
                    continue
                if not type_ok(p, opt):
                    continue
                yield p[2:] if p.startswith("./") else p

def read_lines(path, opt):
    global STDIN_CACHE
    if path == "-":
        if STDIN_CACHE is None:
            STDIN_CACHE = sys.stdin.read()
        return STDIN_CACHE.splitlines(True)
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError as e:
        if not opt.silent:
            sys.stderr.write(f"ERR: Error opening file {path}: {e.strerror}\n")
        return None
    if b"\0" in data[:4096] and not (opt.search_binary or opt.unrestricted):
        return None
    if opt.search_zip and path.endswith(".gz"):
        try: data = gzip.decompress(data)
        except Exception: pass
    elif opt.search_zip and (path.endswith(".xz") or path.endswith(".lzma")):
        try: data = lzma.decompress(data)
        except Exception: pass
    return data.decode("utf-8", errors="replace").splitlines(True)

def compile_pat(pat, opt):
    raw = re.escape(pat) if opt.literal else pat
    if opt.word:
        raw = r"(?<!\w)(?:" + raw + r")(?!\w)"
    flags = re.MULTILINE
    ic = opt.ignore_case
    if ic is None:
        ic = not any(c.isupper() for c in pat)
    if ic:
        flags |= re.IGNORECASE
    try:
        return re.compile(raw, flags)
    except re.error as e:
        die(f"ERR: Bad regex! {e}")

def line_text(line):
    return line[:-1] if line.endswith("\n") else line

def find_matches(lines, rx, opt):
    res = []
    for idx, line in enumerate(lines, 1):
        text = line_text(line)
        ms = list(rx.finditer(text))
        if opt.invert:
            if not ms:
                res.append((idx, text, []))
        elif ms:
            res.append((idx, text, ms))
    return res

def prefix(path, line, col, show_file, show_num, opt, sep=":"):
    bits = []
    if show_file:
        bits.append(path)
    if show_num:
        bits.append(str(line))
    if col is not None:
        bits.append(str(col))
    return sep.join(bits) + (sep if bits else "")

def output_path(path, null=False):
    sys.stdout.write(path + ("\0" if null else "\n"))

def print_file_result(path, lines, matches, opt, show_file, show_num):
    if opt.ackmate:
        print(":" + path)
        for ln, text, ms in matches:
            spans = ",".join(f"{m.start()} {max(0, m.end()-m.start())}" for m in ms)
            print(f"{ln};{spans}:{text}")
        return
    if opt.heading and show_file:
        print(path)
        sf = False
    else:
        sf = show_file
    if opt.before or opt.after:
        wanted = {}
        match_lines = {ln for ln, _, _ in matches}
        nlines = len(lines)
        virtual_last = nlines + 1 if nlines and lines[-1].endswith("\n") else nlines
        for ln, _, _ in matches:
            for n in range(max(1, ln - opt.before), min(virtual_last, ln + opt.after) + 1):
                wanted[n] = n in match_lines
        prev = 0
        for n in sorted(wanted):
            if prev and n > prev + 1:
                print("--")
            text = line_text(lines[n - 1]) if n <= nlines else ""
            sep = ":" if wanted[n] else "-"
            end = "\n" if n > nlines or lines[n - 1].endswith("\n") else ""
            sys.stdout.write(prefix(path, n, None, sf, show_num, opt, sep=sep) + text + end)
            prev = n
        return
    for ln, text, ms in matches:
        if opt.only and not opt.invert:
            for m in ms:
                col = m.start() + 1 if (opt.column or opt.vimgrep) else None
                sys.stdout.write(prefix(path, ln, col, sf, show_num, opt) + m.group(0) + "\n")
        elif opt.vimgrep and not opt.invert:
            for m in ms:
                sys.stdout.write(prefix(path, ln, m.start() + 1, sf, True, opt) + text + "\n")
        else:
            col = (ms[0].start() + 1) if (ms and opt.column) else None
            end = "\n" if lines[ln - 1].endswith("\n") else ""
            sys.stdout.write(prefix(path, ln, col, sf, show_num, opt) + text + end)

def main():
    global STDIN_CACHE
    start = time.time()
    opt, pos = parse(sys.argv[1:])
    if opt.name_re:
        paths = pos or ["."]
        any_out = False
        try: nrx = re.compile(opt.name_re)
        except re.error as e: die(f"ERR: Bad regex! {e}")
        for p in iter_files(paths, opt):
            if p != "-" and nrx.search(p):
                output_path(p, opt.null); any_out = True
        sys.exit(0 if any_out else 1)
    if not pos:
        print(HELP)
        sys.exit(1)
    pat = pos[0]
    if pos[1:]:
        paths = pos[1:]
    elif not sys.stdin.isatty():
        STDIN_CACHE = sys.stdin.read()
        paths = ["-"] if STDIN_CACHE else ["."]
    else:
        paths = ["."]
    rx = compile_pat(pat, opt)
    files = list(iter_files(paths, opt))
    explicit_single_file = len(paths) == 1 and paths[0] != "-" and os.path.isfile(paths[0])
    show_file = opt.filename if opt.filename is not None else not explicit_single_file and paths != ["-"]
    show_num = opt.numbers if opt.numbers is not None else paths != ["-"]
    total_matches = 0
    files_with = 0
    searched = 0
    printed_any = False
    first_block = True
    for p in files:
        lines = read_lines(p, opt)
        if lines is None:
            continue
        searched += 1
        matches = find_matches(lines, rx, opt)
        count = sum((1 if opt.invert else max(1, len(ms))) for _, _, ms in matches)
        if opt.max_count and count > opt.max_count:
            # Keep complete matching lines up to roughly the max count.
            kept = []
            c = 0
            for row in matches:
                inc = 1 if opt.invert else max(1, len(row[2]))
                if c >= opt.max_count: break
                kept.append(row); c += inc
            matches = kept; count = min(count, opt.max_count)
        total_matches += count
        if count:
            files_with += 1
        if opt.stats_only:
            continue
        if opt.files_with:
            if count:
                output_path(p, opt.null); printed_any = True
            continue
        if opt.files_without:
            if not count:
                output_path(p, opt.null); printed_any = True
            continue
        if opt.count:
            if count:
                print(prefix(p, None, None, show_file, False, opt).rstrip(":") + (":" if show_file else "") + str(count))
                printed_any = True
            continue
        if opt.passthrough and p == "-":
            for i, line in enumerate(lines, 1):
                sys.stdout.write(line)
            printed_any = True
            continue
        if matches:
            if opt.breaks and not first_block:
                print()
            elif opt.ackmate and not first_block:
                print()
            print_file_result(p, lines, matches, opt, show_file, show_num)
            printed_any = True
            first_block = False
    if opt.stats or opt.stats_only:
        sys.stderr.write(f"{searched} files searched\n{files_with} files contained matches\n{total_matches} matches\n{time.time() - start:.6f} seconds\n")
    if opt.files_with or opt.files_without or opt.name_re:
        sys.exit(0 if printed_any else 1)
    sys.exit(0 if total_matches or printed_any else 1)

if __name__ == "__main__":
    main()
