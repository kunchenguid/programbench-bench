#!/usr/bin/env python3
import base64
import os
import socket
import sys
import threading
import time


CONTROL_PORT = 7835
VERSION = "bore-cli 0.6.0"
ABOUT = (
    "A modern, simple TCP tunnel in Rust that exposes local ports to a remote "
    "server, bypassing standard NAT connection firewalls."
)


ROOT_HELP = f"""{ABOUT}

Usage: executable <COMMAND>

Commands:
  local   Starts a local proxy to the remote server
  server  Runs the remote proxy server
  help    Print this message or the help of the given subcommand(s)

Options:
  -h, --help     Print help
  -V, --version  Print version
"""

LOCAL_HELP = """Starts a local proxy to the remote server

Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>

Arguments:
  <LOCAL_PORT>  The local port to expose [env: BORE_LOCAL_PORT=]

Options:
  -l, --local-host <HOST>  The local host to expose [default: localhost]
  -t, --to <TO>            Address of the remote server to expose local ports to [env: BORE_SERVER=]
  -p, --port <PORT>        Optional port on the remote server to select [default: 0]
  -s, --secret <SECRET>    Optional secret for authentication [env: BORE_SECRET]
  -h, --help               Print help
"""

SERVER_HELP = """Runs the remote proxy server

Usage: executable server [OPTIONS]

Options:
      --min-port <MIN_PORT>          Minimum accepted TCP port number [env: BORE_MIN_PORT=] [default: 1024]
      --max-port <MAX_PORT>          Maximum accepted TCP port number [env: BORE_MAX_PORT=] [default: 65535]
  -s, --secret <SECRET>              Optional secret for authentication [env: BORE_SECRET]
      --bind-addr <BIND_ADDR>        IP address to bind to, clients must reach this [default: 0.0.0.0]
      --bind-tunnels <BIND_TUNNELS>  IP address where tunnels will listen on, defaults to --bind-addr
  -h, --help                         Print help
"""


def eprint(text=""):
    print(text, file=sys.stderr)


def die_usage(message, usage, code=2):
    eprint(f"error: {message}\n")
    eprint(usage)
    eprint("\nFor more information, try '--help'.")
    sys.exit(code)


def parse_port(value, name):
    try:
        port = int(value, 10)
    except Exception:
        eprint(f"error: invalid value '{value}' for '{name}': invalid digit found in string\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)
    if not (0 <= port <= 65535):
        eprint(f"error: invalid value '{value}' for '{name}': {value} is not in 0..=65535\n")
        eprint("For more information, try '--help'.")
        sys.exit(2)
    return port


def enc(s):
    return base64.urlsafe_b64encode((s or "").encode()).decode()


def recvall_line(sock):
    data = bytearray()
    while True:
        ch = sock.recv(1)
        if not ch:
            if not data:
                return None
            break
        if ch == b"\n":
            break
        data.extend(ch)
        if len(data) > 8192:
            raise OSError("line too long")
    return data.decode(errors="replace")


def pipe(a, b):
    def one_way(src, dst):
        try:
            while True:
                data = src.recv(65536)
                if not data:
                    break
                dst.sendall(data)
        except OSError:
            pass
        try:
            dst.shutdown(socket.SHUT_WR)
        except OSError:
            pass

    t1 = threading.Thread(target=one_way, args=(a, b), daemon=True)
    t2 = threading.Thread(target=one_way, args=(b, a), daemon=True)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    for s in (a, b):
        try:
            s.close()
        except OSError:
            pass


def connect_host(host, port):
    last = None
    for res in socket.getaddrinfo(host, port, type=socket.SOCK_STREAM):
        family, socktype, proto, _, sockaddr = res
        s = socket.socket(family, socktype, proto)
        try:
            s.connect(sockaddr)
            return s
        except OSError as exc:
            last = exc
            s.close()
    raise last or OSError("connection failed")


class BoreServer:
    def __init__(self, bind_addr, bind_tunnels, min_port, max_port, secret):
        self.bind_addr = bind_addr
        self.bind_tunnels = bind_tunnels or bind_addr
        self.min_port = min_port
        self.max_port = max_port
        self.secret = secret or ""
        self.next_id = 1
        self.pending = {}
        self.lock = threading.Lock()

    def run(self):
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((self.bind_addr, CONTROL_PORT))
        listener.listen(128)
        print(f"server listening addr={self.bind_addr}", file=sys.stderr, flush=True)
        while True:
            conn, _ = listener.accept()
            threading.Thread(target=self.handle_control, args=(conn,), daemon=True).start()

    def handle_control(self, conn):
        try:
            line = recvall_line(conn)
            if not line:
                conn.close()
                return
            parts = line.split(" ")
            if parts[0] == "OPEN" and len(parts) >= 3:
                port = int(parts[1])
                secret = base64.urlsafe_b64decode(parts[2].encode()).decode()
                self.open_tunnel(conn, port, secret)
            elif parts[0] == "DATA" and len(parts) >= 3:
                ident = int(parts[1])
                secret = base64.urlsafe_b64decode(parts[2].encode()).decode()
                self.attach_data(conn, ident, secret)
            else:
                conn.sendall(b"ERR bad request\n")
                conn.close()
        except Exception:
            try:
                conn.close()
            except OSError:
                pass

    def check_secret(self, conn, secret):
        if self.secret and secret != self.secret:
            conn.sendall(b"ERR authentication failed\n")
            conn.close()
            return False
        if not self.secret and secret:
            conn.sendall(b"ERR expected no authentication\n")
            conn.close()
            return False
        return True

    def make_tunnel_listener(self, requested):
        if requested:
            if requested < self.min_port or requested > self.max_port:
                raise ValueError("requested port outside allowed range")
            ports = [requested]
        else:
            ports = range(self.min_port, self.max_port + 1)
        last = None
        for port in ports:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind((self.bind_tunnels, port))
                s.listen(128)
                return s, s.getsockname()[1]
            except OSError as exc:
                last = exc
                s.close()
        raise last or OSError("no available port")

    def open_tunnel(self, conn, requested, secret):
        if not self.check_secret(conn, secret):
            return
        try:
            tunnel, port = self.make_tunnel_listener(requested)
        except Exception as exc:
            conn.sendall(f"ERR {exc}\n".encode())
            conn.close()
            return
        conn.sendall(f"OK {port}\n".encode())
        writer_lock = threading.Lock()

        def accept_loop():
            while True:
                try:
                    remote, _ = tunnel.accept()
                except OSError:
                    break
                with self.lock:
                    ident = self.next_id
                    self.next_id += 1
                    self.pending[ident] = remote
                try:
                    with writer_lock:
                        conn.sendall(f"CONN {ident}\n".encode())
                except OSError:
                    with self.lock:
                        sock = self.pending.pop(ident, None)
                    if sock:
                        sock.close()
                    break
            try:
                tunnel.close()
            except OSError:
                pass

        threading.Thread(target=accept_loop, daemon=True).start()
        try:
            while conn.recv(1):
                pass
        except OSError:
            pass
        try:
            tunnel.close()
        except OSError:
            pass

    def attach_data(self, conn, ident, secret):
        if not self.check_secret(conn, secret):
            return
        deadline = time.time() + 10
        remote = None
        while time.time() < deadline:
            with self.lock:
                remote = self.pending.pop(ident, None)
            if remote:
                break
            time.sleep(0.01)
        if not remote:
            conn.sendall(b"ERR unknown connection\n")
            conn.close()
            return
        conn.sendall(b"OK\n")
        pipe(remote, conn)


def run_local(args):
    local_host = "localhost"
    remote_host = os.environ.get("BORE_SERVER")
    remote_port = 0
    secret = os.environ.get("BORE_SECRET", "")
    local_port_value = os.environ.get("BORE_LOCAL_PORT")
    positionals = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(LOCAL_HELP)
            return 0
        if a in ("-l", "--local-host", "-t", "--to", "-p", "--port", "-s", "--secret"):
            if i + 1 >= len(args):
                die_usage(f"a value is required for '{a} <VALUE>'", "Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>")
            v = args[i + 1]
            if a in ("-l", "--local-host"):
                local_host = v
            elif a in ("-t", "--to"):
                remote_host = v
            elif a in ("-p", "--port"):
                remote_port = parse_port(v, "--port <PORT>")
            else:
                secret = v
            i += 2
            continue
        if a.startswith("-"):
            die_usage(f"unexpected argument '{a}' found", "Usage: executable local [OPTIONS] --to <TO> <LOCAL_PORT>")
        positionals.append(a)
        i += 1
    if positionals:
        local_port_value = positionals[0]
    missing = []
    if not remote_host:
        missing.append("  --to <TO>")
    if not local_port_value:
        missing.append("  <LOCAL_PORT>")
    if missing:
        eprint("error: the following required arguments were not provided:")
        for m in missing:
            eprint(m)
        eprint("\nUsage: executable local --to <TO> <LOCAL_PORT>\n")
        eprint("For more information, try '--help'.")
        return 2
    local_port = parse_port(local_port_value, "<LOCAL_PORT>")
    try:
        ctl = connect_host(remote_host, CONTROL_PORT)
        ctl.sendall(f"OPEN {remote_port} {enc(secret)}\n".encode())
        line = recvall_line(ctl)
        if not line or not line.startswith("OK "):
            raise OSError((line or "server closed").replace("ERR ", ""))
        assigned = int(line.split()[1])
        print(f"connected to server remote_port={assigned}", file=sys.stderr, flush=True)
        print(f"listening at {remote_host}:{assigned}", file=sys.stderr, flush=True)
        while True:
            line = recvall_line(ctl)
            if not line:
                break
            parts = line.split()
            if len(parts) == 2 and parts[0] == "CONN":
                ident = int(parts[1])
                threading.Thread(
                    target=local_data_conn,
                    args=(remote_host, ident, secret, local_host, local_port),
                    daemon=True,
                ).start()
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        eprint(f"Error: {exc}")
        return 1
    return 0


def local_data_conn(remote_host, ident, secret, local_host, local_port):
    try:
        server = connect_host(remote_host, CONTROL_PORT)
        server.sendall(f"DATA {ident} {enc(secret)}\n".encode())
        line = recvall_line(server)
        if line != "OK":
            server.close()
            return
        local = connect_host(local_host, local_port)
        pipe(server, local)
    except Exception:
        try:
            server.close()
        except Exception:
            pass


def run_server(args):
    min_port = parse_port(os.environ.get("BORE_MIN_PORT", "1024"), "--min-port <MIN_PORT>")
    max_port = parse_port(os.environ.get("BORE_MAX_PORT", "65535"), "--max-port <MAX_PORT>")
    secret = os.environ.get("BORE_SECRET", "")
    bind_addr = "0.0.0.0"
    bind_tunnels = None
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-h", "--help"):
            print(SERVER_HELP)
            return 0
        if a in ("--min-port", "--max-port", "-s", "--secret", "--bind-addr", "--bind-tunnels"):
            if i + 1 >= len(args):
                die_usage(f"a value is required for '{a} <VALUE>'", "Usage: executable server [OPTIONS]")
            v = args[i + 1]
            if a == "--min-port":
                min_port = parse_port(v, "--min-port <MIN_PORT>")
            elif a == "--max-port":
                max_port = parse_port(v, "--max-port <MAX_PORT>")
            elif a in ("-s", "--secret"):
                secret = v
            elif a == "--bind-addr":
                bind_addr = v
            else:
                bind_tunnels = v
            i += 2
            continue
        die_usage(f"unexpected argument '{a}' found", "Usage: executable server [OPTIONS]")
    if min_port > max_port:
        eprint("error: port range is empty\n")
        eprint("Usage: bore-cli <COMMAND>\n")
        eprint("For more information, try '--help'.")
        return 2
    try:
        BoreServer(bind_addr, bind_tunnels, min_port, max_port, secret).run()
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        eprint(f"Error: {exc}")
        return 1
    return 0


def main(argv):
    if not argv:
        eprint(ROOT_HELP)
        return 2
    if argv[0] in ("-h", "--help", "help"):
        if len(argv) >= 2 and argv[0] == "help":
            if argv[1] == "local":
                print(LOCAL_HELP)
            elif argv[1] == "server":
                print(SERVER_HELP)
            else:
                print(ROOT_HELP)
        else:
            print(ROOT_HELP)
        return 0
    if argv[0] in ("-V", "--version"):
        print(VERSION)
        return 0
    if argv[0] == "local":
        return run_local(argv[1:])
    if argv[0] == "server":
        return run_server(argv[1:])
    eprint(f"error: unrecognized subcommand '{argv[0]}'\n")
    eprint("Usage: executable <COMMAND>\n")
    eprint("For more information, try '--help'.")
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
