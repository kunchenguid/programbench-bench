#!/usr/bin/env python3
import os, sys, fnmatch

HELP = """Usage: ./executable [options] <path> [<path>..]

Options:
    -d, --depth [DEPTH] show directories up to depth N (def 1)
    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)
    -s, --summary       equivalent to -da, or -d1 -a1M
    -u, --usage         report real disk usage instead of file size
    -b, --bytes         print sizes in bytes
    -f, --files-only    skip directories for a fast local overview
    -x, --exclude NAME  exclude matching files or directories
    -H, --no-hidden     exclude hidden files
    -A, --ascii         ASCII characters only, no colors
    -h, --help          show help
    -v, --version       print version number"""

class Node:
    __slots__ = ('name','path','size','children','is_dir')
    def __init__(self, name, path, size=0, children=None, is_dir=False):
        self.name=name; self.path=path; self.size=size; self.children=children or []; self.is_dir=is_dir

def parse_size(s):
    if s is None or s == '': return 1024*1024
    mult=1
    last=s[-1].upper()
    if last in 'KMG':
        mult={'K':1024,'M':1024**2,'G':1024**3}[last]
        s=s[:-1]
    try:
        return int(s)*mult
    except Exception:
        print("invalid argument '%s'" % s, file=sys.stderr)
        sys.exit(1)

def parse_args(argv):
    opts={'depth':None,'aggr':0,'usage':False,'bytes':False,'files_only':False,'hidden':True,'ascii':False,'exclude':[]}
    paths=[]; i=0
    while i < len(argv):
        a=argv[i]
        if a in ('-h','--help'):
            print(HELP); sys.exit(0)
        if a in ('-v','--version'):
            print('dutree version 0.2.18'); sys.exit(0)
        if a == '-s' or a == '--summary':
            opts['depth']=1; opts['aggr']=1024*1024; i+=1; continue
        if a in ('-u','--usage'): opts['usage']=True; i+=1; continue
        if a in ('-b','--bytes'): opts['bytes']=True; i+=1; continue
        if a in ('-f','--files-only'): opts['files_only']=True; i+=1; continue
        if a in ('-H','--no-hidden'): opts['hidden']=False; i+=1; continue
        if a in ('-A','--ascii'): opts['ascii']=True; i+=1; continue
        if a in ('-x','--exclude'):
            if i+1 >= len(argv): print('missing argument for %s'%a, file=sys.stderr); sys.exit(1)
            opts['exclude'].append(argv[i+1]); i+=2; continue
        if a.startswith('--depth'):
            val = None
            if a.startswith('--depth='): val=a.split('=',1)[1]
            elif i+1 < len(argv) and argv[i+1].isdigit(): i+=1; val=argv[i]
            opts['depth'] = int(val) if val is not None else 1; i+=1; continue
        if a.startswith('--aggr'):
            if a.startswith('--aggr='): val=a.split('=',1)[1]
            elif i+1 < len(argv): i+=1; val=argv[i]
            else: val='1M'
            opts['aggr']=parse_size(val); i+=1; continue
        if a == '-d':
            if i+1 < len(argv) and argv[i+1].isdigit(): i+=1; opts['depth']=int(argv[i])
            else: opts['depth']=1
            i+=1; continue
        if a.startswith('-d') and len(a)>2:
            val=a[2:]
            opts['depth']=int(val) if val.isdigit() else 1
            # handle compact -da used by dutree summary-ish shorthand
            if 'a' in val and not val.isdigit(): opts['aggr']=1024*1024
            i+=1; continue
        if a == '-a':
            if i+1 >= len(argv): opts['aggr']=1024*1024; i+=1; continue
            opts['aggr']=parse_size(argv[i+1]); i+=2; continue
        if a.startswith('-a') and len(a)>2:
            opts['aggr']=parse_size(a[2:]); i+=1; continue
        if a.startswith('-'):
            print(HELP); print("Unrecognized option: '%s'" % a.lstrip('-'), file=sys.stderr); sys.exit(1)
        paths.append(a); i+=1
    if not paths: paths=['.']
    return opts, paths

def excluded(name, opts):
    if not opts['hidden'] and name.startswith('.'):
        return True
    for pat in opts['exclude']:
        if name == pat or fnmatch.fnmatch(name, pat): return True
    return False

def entry_size(path, st, usage):
    return st.st_blocks*512 if usage else st.st_size

def build(path, opts, root=False):
    try: st=os.lstat(path)
    except OSError: return None
    name = os.path.basename(path.rstrip('/')) or path
    is_dir = os.path.isdir(path) and not os.path.islink(path)
    size = entry_size(path, st, opts['usage'])
    node=Node(name,path,size,[],is_dir)
    if is_dir:
        if opts['files_only'] and not root:
            return None
        try:
            names=list(os.listdir(path))
        except OSError:
            names=[]
        for n in names:
            if excluded(n, opts): continue
            p=os.path.join(path,n)
            try:
                child_is_dir = os.path.isdir(p) and not os.path.islink(p)
            except OSError:
                child_is_dir = False
            if opts['files_only'] and child_is_dir:
                continue
            ch=build(p, opts, False)
            if ch is not None:
                node.children.append(ch); size += ch.size
        node.size=size
    return node

def fmt_size(n, bytes_mode):
    if bytes_mode: return f'{n} B'
    units=['B','KiB','MiB','GiB','TiB']
    x=float(n); u=0
    while x >= 1024 and u < len(units)-1:
        x/=1024.0; u+=1
    if u==0: return f'{int(n)} B'
    return f'{x:.2f} {units[u]}'

def sorted_children(children):
    return sorted(children, key=lambda c: (-c.size, c.name))

def visible_children(node, opts):
    kids=sorted_children(node.children)
    if opts['aggr'] and opts['aggr']>0:
        small=[c for c in kids if c.size < opts['aggr']]
        big=[c for c in kids if c.size >= opts['aggr']]
        if small:
            big.append(Node('<aggregated>','',sum(c.size for c in small),[],False))
        return big
    return kids

def truncate(s, n):
    return s if len(s) <= n else s[:n]

def line_for(prefix, branch, node, parent_size, max_sib, opts, cap_fill=None):
    label = prefix + branch + truncate(node.name, 15)
    left = label[:26].ljust(26)
    barw=32
    ratio = (node.size / max_sib) if max_sib else 0
    if max_sib and node.size == max_sib:
        fill = barw
    else:
        fill = int(ratio * barw) if max_sib else 0
        if fill == 16 and ratio < 0.51:
            fill = 15
    if fill > barw: fill=barw
    if cap_fill is not None and fill > cap_fill: fill = cap_fill
    ch = '#' if opts['ascii'] else '█'
    bar = ' ' + (' '*(barw-fill)) + (ch*fill)
    pct = int((node.size / parent_size) * 100) if parent_size else 0
    return f'{left}│{bar}│{pct:4d}% {fmt_size(node.size, opts["bytes"]):>13}'

def render(node, opts):
    print(f'[ {node.name} {fmt_size(node.size, opts["bytes"])} ]')
    def rec(n, prefix, level, cap_fill=None):
        if opts['depth'] is not None and level >= opts['depth']:
            return
        kids=visible_children(n, opts)
        if not kids: return
        mx=max(c.size for c in kids) or 1
        for idx,c in enumerate(kids):
            last = idx == len(kids)-1
            branch = '└─ ' if last else '├─ '
            print(line_for(prefix, branch, c, n.size, mx, opts, cap_fill))
            ratio = (c.size / mx) if mx else 0
            if mx and c.size == mx:
                child_fill = 32
            else:
                child_fill = int(ratio * 32) if mx else 0
                if child_fill == 16 and ratio < 0.51:
                    child_fill = 15
            if cap_fill is not None and child_fill > cap_fill: child_fill = cap_fill
            rec(c, prefix + ('   ' if last else '│  '), level+1, child_fill)
    rec(node, '', 0, None)

def main():
    opts, paths=parse_args(sys.argv[1:])
    nodes=[]
    for p in paths:
        if not os.path.exists(p):
            print(f"path {p} doesn't exist", file=sys.stderr); sys.exit(1)
        n=build(p, opts, True)
        if n: nodes.append(n)
    if len(nodes)==1:
        render(nodes[0], opts)
    else:
        root=Node('<collection>','',sum(n.size for n in nodes),nodes,True)
        render(root, opts)

if __name__=='__main__': main()
