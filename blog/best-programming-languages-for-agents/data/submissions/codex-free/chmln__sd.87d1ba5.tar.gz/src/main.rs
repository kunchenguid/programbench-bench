use regex::{Regex, RegexBuilder};
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::process;

#[derive(Debug)]
struct Config {
    preview: bool,
    fixed: bool,
    max_replacements: usize,
    flags: String,
    find: String,
    replace_with: String,
    files: Vec<String>,
}

fn print_help(long: bool) {
    if long {
        println!(
            "sd v1.0.0\nAn intuitive find & replace CLI\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nArguments:\n  <FIND>\n          The regexp or string (if using `-F`) to search for\n\n  <REPLACE_WITH>\n          What to replace each match with. Unless in string mode, you may use captured values like\n          $1, $2, etc\n\n  [FILES]...\n          The path to file(s). This is optional - sd can also read from STDIN.\n          \n          Note: sd modifies files in-place by default. See documentation for examples.\n\nOptions:\n  -p, --preview\n          Display changes in a human reviewable format (the specifics of the format are likely to\n          change in the future)\n\n  -F, --fixed-strings\n          Treat FIND and REPLACE_WITH args as literal strings\n\n  -n, --max-replacements <LIMIT>\n          Limit the number of replacements that can occur per file. 0 indicates unlimited\n          replacements\n          \n          [default: 0]\n\n  -f, --flags <FLAGS>\n          Regex flags. May be combined (like `-f mc`).\n          \n          c - case-sensitive\n          \n          e - disable multi-line matching\n          \n          i - case-insensitive\n          \n          m - multi-line matching\n          \n          s - make `.` match newlines\n          \n          w - match full words only\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version"
        );
    } else {
        println!(
            "sd v1.0.0\nAn intuitive find & replace CLI\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nArguments:\n  <FIND>          The regexp or string (if using `-F`) to search for\n  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured\n                  values like $1, $2, etc\n  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN\n\nOptions:\n  -p, --preview                   Display changes in a human reviewable format (the specifics of the\n                                  format are likely to change in the future)\n  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings\n  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0\n                                  indicates unlimited replacements [default: 0]\n  -f, --flags <FLAGS>             Regex flags. May be combined (like `-f mc`).\n  -h, --help                      Print help (see more with '--help')\n  -V, --version                   Print version"
        );
    }
}

fn die(message: &str, code: i32) -> ! {
    eprintln!("{message}");
    process::exit(code);
}

fn parse_args() -> Config {
    let raw: Vec<String> = env::args().skip(1).collect();
    let mut preview = false;
    let mut fixed = false;
    let mut max_replacements = 0usize;
    let mut flags = String::new();
    let mut positionals = Vec::new();
    let mut end_flags = false;
    let mut i = 0usize;

    while i < raw.len() {
        let arg = &raw[i];
        if end_flags {
            positionals.push(arg.clone());
            i += 1;
            continue;
        }

        if arg == "--" {
            end_flags = true;
            i += 1;
        } else if arg == "-h" {
            print_help(false);
            process::exit(0);
        } else if arg == "--help" {
            print_help(true);
            process::exit(0);
        } else if arg == "-V" || arg == "--version" {
            println!("sd 1.0.0");
            process::exit(0);
        } else if arg == "-p" || arg == "--preview" {
            preview = true;
            i += 1;
        } else if arg == "-F" || arg == "--fixed-strings" {
            fixed = true;
            i += 1;
        } else if arg == "-n" || arg == "--max-replacements" {
            i += 1;
            if i >= raw.len() {
                die("error: a value is required for '--max-replacements <LIMIT>' but none was supplied\n\nFor more information, try '--help'.", 2);
            }
            max_replacements = parse_limit(&raw[i]);
            i += 1;
        } else if let Some(value) = arg.strip_prefix("--max-replacements=") {
            max_replacements = parse_limit(value);
            i += 1;
        } else if let Some(value) = arg.strip_prefix("-n") {
            if value.is_empty() {
                die("error: a value is required for '--max-replacements <LIMIT>' but none was supplied\n\nFor more information, try '--help'.", 2);
            }
            max_replacements = parse_limit(value);
            i += 1;
        } else if arg == "-f" || arg == "--flags" {
            i += 1;
            if i >= raw.len() {
                die("error: a value is required for '--flags <FLAGS>' but none was supplied\n\nFor more information, try '--help'.", 2);
            }
            flags.push_str(&raw[i]);
            i += 1;
        } else if let Some(value) = arg.strip_prefix("--flags=") {
            flags.push_str(value);
            i += 1;
        } else if let Some(value) = arg.strip_prefix("-f") {
            if value.is_empty() {
                die("error: a value is required for '--flags <FLAGS>' but none was supplied\n\nFor more information, try '--help'.", 2);
            }
            flags.push_str(value);
            i += 1;
        } else if arg.starts_with('-') && !arg.starts_with("--") && arg.len() > 2 {
            let mut chars = arg[1..].char_indices().peekable();
            let mut consumed_value = false;
            while let Some((idx, ch)) = chars.next() {
                match ch {
                    'p' => preview = true,
                    'F' => fixed = true,
                    'h' => {
                        print_help(false);
                        process::exit(0);
                    }
                    'V' => {
                        println!("sd 1.0.0");
                        process::exit(0);
                    }
                    'n' => {
                        let next_idx = idx + ch.len_utf8();
                        let value = &arg[1 + next_idx..];
                        if !value.is_empty() {
                            max_replacements = parse_limit(value);
                        } else {
                            i += 1;
                            if i >= raw.len() {
                                die("error: a value is required for '--max-replacements <LIMIT>' but none was supplied\n\nFor more information, try '--help'.", 2);
                            }
                            max_replacements = parse_limit(&raw[i]);
                        }
                        consumed_value = true;
                        break;
                    }
                    'f' => {
                        let next_idx = idx + ch.len_utf8();
                        let value = &arg[1 + next_idx..];
                        if !value.is_empty() {
                            flags.push_str(value);
                        } else {
                            i += 1;
                            if i >= raw.len() {
                                die("error: a value is required for '--flags <FLAGS>' but none was supplied\n\nFor more information, try '--help'.", 2);
                            }
                            flags.push_str(&raw[i]);
                        }
                        consumed_value = true;
                        break;
                    }
                    _ => {
                        eprintln!("error: unexpected argument '-{ch}' found\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.");
                        process::exit(2);
                    }
                }
            }
            let _ = consumed_value;
            i += 1;
        } else if arg.starts_with('-') {
            eprintln!("error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.");
            process::exit(2);
        } else {
            positionals.push(arg.clone());
            i += 1;
        }
    }

    if positionals.len() < 2 {
        if positionals.is_empty() {
            die("error: the following required arguments were not provided:\n  <FIND>\n  <REPLACE_WITH>\n\nUsage: executable <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.", 2);
        }
        die("error: the following required arguments were not provided:\n  <REPLACE_WITH>\n\nUsage: executable <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.", 2);
    }

    Config {
        preview,
        fixed,
        max_replacements,
        flags,
        find: positionals[0].clone(),
        replace_with: positionals[1].clone(),
        files: positionals[2..].to_vec(),
    }
}

fn parse_limit(value: &str) -> usize {
    match value.parse::<usize>() {
        Ok(n) => n,
        Err(e) => die(
            &format!(
                "error: invalid value '{value}' for '--max-replacements <LIMIT>': {e}\n\nFor more information, try '--help'."
            ),
            2,
        ),
    }
}

fn build_regex(cfg: &Config) -> Regex {
    let mut pattern = if cfg.fixed {
        regex::escape(&cfg.find)
    } else {
        cfg.find.clone()
    };

    let mut case_insensitive = false;
    let mut multi_line = true;
    let mut dot_matches_new_line = false;
    let mut word = false;

    for ch in cfg.flags.chars() {
        match ch {
            'c' => case_insensitive = false,
            'i' => case_insensitive = true,
            'e' => multi_line = false,
            'm' => multi_line = true,
            's' => dot_matches_new_line = true,
            'w' => word = true,
            _ => {}
        }
    }

    if word {
        pattern = format!(r"\b(?:{})\b", pattern);
    }

    match RegexBuilder::new(&pattern)
        .case_insensitive(case_insensitive)
        .multi_line(multi_line)
        .dot_matches_new_line(dot_matches_new_line)
        .build()
    {
        Ok(re) => re,
        Err(e) => die(&format!("error: invalid regex {e}"), 1),
    }
}

fn replace_text(re: &Regex, cfg: &Config, input: &str) -> String {
    let limit = cfg.max_replacements;
    if cfg.fixed {
        if limit == 0 {
            re.replace_all(input, regex::NoExpand(&cfg.replace_with)).into_owned()
        } else {
            re.replacen(input, limit, regex::NoExpand(&cfg.replace_with)).into_owned()
        }
    } else if limit == 0 {
        re.replace_all(input, cfg.replace_with.as_str()).into_owned()
    } else {
        re.replacen(input, limit, cfg.replace_with.as_str()).into_owned()
    }
}

fn main() {
    let cfg = parse_args();
    let re = build_regex(&cfg);

    if cfg.files.is_empty() {
        let mut input = String::new();
        if let Err(e) = io::stdin().read_to_string(&mut input) {
            die(&format!("error: {e}"), 1);
        }
        print!("{}", replace_text(&re, &cfg, &input));
        return;
    }

    for path in &cfg.files {
        let input = match fs::read_to_string(path) {
            Ok(s) => s,
            Err(_) => die(&format!("error: invalid path: {path}"), 1),
        };
        let output = replace_text(&re, &cfg, &input);
        if cfg.preview {
            print!("{output}");
            let _ = io::stdout().flush();
        } else if output != input {
            if let Err(e) = fs::write(path, output) {
                die(&format!("error: failed to write {path}: {e}"), 1);
            }
        }
    }
}
