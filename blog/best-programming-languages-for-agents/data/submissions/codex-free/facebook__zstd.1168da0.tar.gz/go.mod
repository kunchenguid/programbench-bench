module pbzstd

go 1.21
