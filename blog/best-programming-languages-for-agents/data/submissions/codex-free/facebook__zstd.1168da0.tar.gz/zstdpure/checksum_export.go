package zstdpure

func Checksum64(b []byte) uint64 {
	var x xxhash64
	x.reset()
	x.update(b)
	return x.digest()
}
