package main

import (
	"bytes"
	"compress/gzip"
	"encoding/binary"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"

	"pbzstd/zstdpure"
)

const helpText = `*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***

Compress or decompress the INPUT file(s); reads from STDIN if INPUT is ` + "`-`" + ` or not provided.

Usage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]

Options:
  -o OUTPUT                     Write output to a single file, OUTPUT.
  -k, --keep                    Preserve INPUT file(s). [Default] 
  --rm                          Remove INPUT file(s) after successful (de)compression to file.

  -#                            Desired compression level, where ` + "`#`" + ` is a number between 1 and 19;
                                lower numbers provide faster compression, higher numbers yield
                                better compression ratios. [Default: 3]

  -d, --decompress              Perform decompression.
  -D DICT                       Use DICT as the dictionary for compression or decompression.

  -f, --force                   Disable input and output checks. Allows overwriting existing files,
                                receiving input from the console, printing output to STDOUT, and
                                operating on links, block devices, etc. Unrecognized formats will be
                                passed-through through as-is.

  -h                            Display short usage and exit.
  -H, --help                    Display full help and exit.
  -V, --version                 Display the program version and exit.
`

type config struct {
	decompress bool
	test       bool
	list       bool
	stdout     bool
	force      bool
	rm         bool
	check      bool
	quiet      int
	out        string
	format     string
	inputs     []string
}

func main() {
	cfg, err := parseArgs(os.Args[1:])
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	if err := run(cfg); err != nil {
		if cfg.quiet < 2 {
			fmt.Fprintln(os.Stderr, err)
		}
		os.Exit(1)
	}
}

func parseArgs(args []string) (config, error) {
	cfg := config{check: true}
	for i := 0; i < len(args); i++ {
		a := args[i]
		if a == "--" {
			cfg.inputs = append(cfg.inputs, args[i+1:]...)
			break
		}
		if a == "-" || !strings.HasPrefix(a, "-") {
			cfg.inputs = append(cfg.inputs, a)
			continue
		}
		switch {
		case a == "-h" || a == "-H" || a == "--help":
			fmt.Print(helpText)
			os.Exit(0)
		case a == "-V" || a == "--version":
			fmt.Println("*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***")
			os.Exit(0)
		case a == "-d" || a == "--decompress" || a == "--uncompress":
			cfg.decompress = true
		case a == "-t" || a == "--test":
			cfg.decompress = true
			cfg.test = true
		case a == "-l":
			cfg.list = true
		case a == "-c" || a == "--stdout":
			cfg.stdout = true
		case a == "-f" || a == "--force":
			cfg.force = true
		case a == "-k" || a == "--keep":
			cfg.rm = false
		case a == "--rm":
			cfg.rm = true
		case a == "-q" || a == "--quiet":
			cfg.quiet++
		case a == "-v" || a == "--verbose":
		case a == "--no-check":
			cfg.check = false
		case a == "--check":
			cfg.check = true
		case a == "-o":
			i++
			if i >= len(args) {
				return cfg, errors.New("Argument expected after -o")
			}
			cfg.out = args[i]
		case strings.HasPrefix(a, "-o") && len(a) > 2:
			cfg.out = a[2:]
		case strings.HasPrefix(a, "-") && !strings.HasPrefix(a, "--") && len(a) > 2 && isShortCluster(a):
			applyShortCluster(&cfg, a[1:])
		case a == "-D":
			i++
			if i >= len(args) {
				return cfg, errors.New("Argument expected after -D")
			}
		case strings.HasPrefix(a, "-D") && len(a) > 2:
		case strings.HasPrefix(a, "-T") || strings.HasPrefix(a, "-M") || strings.HasPrefix(a, "-b") || strings.HasPrefix(a, "-e") || strings.HasPrefix(a, "-i"):
		case strings.HasPrefix(a, "-") && allDigits(a[1:]):
		case strings.HasPrefix(a, "--format="):
			cfg.format = strings.TrimPrefix(a, "--format=")
		case strings.HasPrefix(a, "--fast") || a == "--ultra" || strings.HasPrefix(a, "--long") || a == "--adapt" || a == "--rsyncable" || strings.HasPrefix(a, "--stream-size=") || strings.HasPrefix(a, "--size-hint=") || strings.HasPrefix(a, "--jobsize=") || strings.HasPrefix(a, "--target-compressed-block-size=") || strings.HasPrefix(a, "--auto-threads=") || a == "--single-thread" || a == "--no-progress" || a == "--progress" || a == "--no-asyncio" || a == "--asyncio" || a == "--sparse" || a == "--no-sparse" || a == "--pass-through" || a == "--no-pass-through" || a == "--exclude-compressed" || a == "--no-dictID" || a == "--compress-literals" || a == "--no-compress-literals" || a == "--row-match-finder" || a == "--no-row-match-finder" || strings.HasPrefix(a, "--trace"):
			if a == "--trace" {
				i++
			}
		default:
			return cfg, fmt.Errorf("Incorrect parameter: %s ", a)
		}
	}
	return cfg, nil
}

func isShortCluster(s string) bool {
	for _, r := range s[1:] {
		if !strings.ContainsRune("dcftkqv", r) {
			return false
		}
	}
	return true
}

func applyShortCluster(cfg *config, s string) {
	for _, r := range s {
		switch r {
		case 'd':
			cfg.decompress = true
		case 'c':
			cfg.stdout = true
		case 'f':
			cfg.force = true
		case 't':
			cfg.decompress = true
			cfg.test = true
		case 'k':
			cfg.rm = false
		case 'q':
			cfg.quiet++
		}
	}
}

func allDigits(s string) bool {
	if s == "" {
		return false
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

func run(cfg config) error {
	if cfg.list {
		return listFiles(cfg)
	}
	if len(cfg.inputs) == 0 {
		cfg.inputs = []string{"-"}
		cfg.stdout = true
	}
	if cfg.out != "" && len(cfg.inputs) > 1 {
		return errors.New("error: multiple input files cannot use a single output")
	}
	for _, in := range cfg.inputs {
		if err := processOne(cfg, in); err != nil {
			return err
		}
	}
	return nil
}

func processOne(cfg config, in string) error {
	var data []byte
	var err error
	if in == "-" {
		data, err = io.ReadAll(os.Stdin)
	} else {
		data, err = os.ReadFile(in)
	}
	if err != nil {
		return err
	}

	var out []byte
	if cfg.decompress {
		out, err = decompressAll(data)
	} else {
		if cfg.format == "gzip" {
			out = compressGzip(data)
		} else {
			out = compressRawZstd(data, cfg.check)
		}
	}
	if err != nil {
		return err
	}
	if cfg.test {
		if cfg.quiet == 0 && in != "-" {
			fmt.Fprintf(os.Stderr, "%s: 0 bytes \n", in)
		}
		return nil
	}

	if cfg.stdout || cfg.out == "" && in == "-" {
		_, err = os.Stdout.Write(out)
		return err
	}
	outName := cfg.out
	if outName == "" {
		if cfg.decompress {
			outName = decompressName(in)
		} else if cfg.format == "gzip" {
			outName = in + ".gz"
		} else {
			outName = in + ".zst"
		}
	}
	if !cfg.force {
		if _, err := os.Stat(outName); err == nil {
			return fmt.Errorf("%s already exists; not overwritten", outName)
		}
	}
	if err := os.MkdirAll(filepath.Dir(outName), 0o755); err != nil && filepath.Dir(outName) != "." {
		return err
	}
	if err := os.WriteFile(outName, out, 0o644); err != nil {
		return err
	}
	if cfg.rm && in != "-" {
		_ = os.Remove(in)
	}
	if cfg.quiet == 0 && in != "-" {
		if cfg.decompress {
			fmt.Fprintf(os.Stderr, "%s: %d bytes \n", in, len(out))
		} else {
			ratio := 0.0
			if len(data) > 0 {
				ratio = float64(len(out)) * 100 / float64(len(data))
			}
			fmt.Fprintf(os.Stderr, "%s                :%.2f%%   (%6d B => %6d B, %s) \n", in, ratio, len(data), len(out), outName)
		}
	}
	return nil
}

func decompressName(path string) string {
	for _, suffix := range []string{".zst", ".zstd", ".gz"} {
		if strings.HasSuffix(path, suffix) {
			return strings.TrimSuffix(path, suffix)
		}
	}
	return path + ".out"
}

func decompressAll(data []byte) ([]byte, error) {
	if len(data) >= 2 && data[0] == 0x1f && data[1] == 0x8b {
		r, err := gzip.NewReader(bytes.NewReader(data))
		if err != nil {
			return nil, err
		}
		defer r.Close()
		return io.ReadAll(r)
	}
	r := zstdpure.NewReader(bytes.NewReader(data))
	return io.ReadAll(r)
}

func compressGzip(src []byte) []byte {
	var out bytes.Buffer
	w := gzip.NewWriter(&out)
	_, _ = w.Write(src)
	_ = w.Close()
	return out.Bytes()
}

func compressRawZstd(src []byte, checksum bool) []byte {
	var out bytes.Buffer
	out.Write([]byte{0x28, 0xb5, 0x2f, 0xfd})
	size := uint64(len(src))
	fcsFlag := byte(3)
	switch {
	case size <= 255:
		fcsFlag = 0
	case size <= 65791:
		fcsFlag = 1
	case size <= 0xffffffff:
		fcsFlag = 2
	}
	desc := byte(0x20) | fcsFlag<<6
	if checksum {
		desc |= 0x04
	}
	out.WriteByte(desc)
	switch fcsFlag {
	case 0:
		out.WriteByte(byte(size))
	case 1:
		var b [2]byte
		binary.LittleEndian.PutUint16(b[:], uint16(size-256))
		out.Write(b[:])
	case 2:
		var b [4]byte
		binary.LittleEndian.PutUint32(b[:], uint32(size))
		out.Write(b[:])
	default:
		var b [8]byte
		binary.LittleEndian.PutUint64(b[:], size)
		out.Write(b[:])
	}

	const maxBlock = 128 * 1024
	if len(src) == 0 {
		out.Write([]byte{0x01, 0x00, 0x00})
	} else {
		for off := 0; off < len(src); off += maxBlock {
			end := off + maxBlock
			if end > len(src) {
				end = len(src)
			}
			last := byte(0)
			if end == len(src) {
				last = 1
			}
			blockSize := end - off
			header := uint32(blockSize<<3) | uint32(last)
			var h [3]byte
			h[0] = byte(header)
			h[1] = byte(header >> 8)
			h[2] = byte(header >> 16)
			out.Write(h[:])
			out.Write(src[off:end])
		}
	}
	if checksum {
		sum := zstdpure.Checksum64(src)
		var b [4]byte
		binary.LittleEndian.PutUint32(b[:], uint32(sum))
		out.Write(b[:])
	}
	return out.Bytes()
}

func listFiles(cfg config) error {
	if len(cfg.inputs) == 0 {
		return errors.New("No files given")
	}
	fmt.Println("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename")
	for _, name := range cfg.inputs {
		b, err := os.ReadFile(name)
		if err != nil {
			return err
		}
		plain, err := decompressAll(b)
		if err != nil {
			return err
		}
		ratio := "0.000"
		if len(plain) > 0 {
			ratio = strconv.FormatFloat(float64(len(b))/float64(len(plain)), 'f', 3, 64)
		}
		fmt.Printf("     1      0 %11d %13d  %s  XXH64  %s\n", len(b), len(plain), ratio, name)
	}
	return nil
}
