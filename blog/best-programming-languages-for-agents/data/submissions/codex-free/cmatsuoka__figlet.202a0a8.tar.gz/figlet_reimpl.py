#!/usr/bin/env python3
import os
import shutil
import sys

def usage_line(prog):
    return (f"Usage: {prog} [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n"
            "              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n"
            "              [ -C controlfile ] [ -I infocode ] [ message ]")

VERSION_TEXT = """FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,
Christiaan Keet and Claudio Matsuoka
Internet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012

FIGlet, along with the various FIGlet fonts and documentation, may be
freely copied and distributed.

If you use FIGlet, please send an e-mail message to <info@figlet.org>.

The latest version of FIGlet is available from the web site,
\thttp://www.figlet.org/

"""

HIER = "|/\\[]{}()<>"  # increasing hierarchy groups are handled below


def c_atoi(s):
    if s is None:
        return 0
    s = str(s).lstrip()
    sign = 1
    if s[:1] in "+-":
        if s[0] == "-":
            sign = -1
        s = s[1:]
    n = 0
    seen = False
    for ch in s:
        if not ch.isdigit():
            break
        seen = True
        n = n * 10 + ord(ch) - 48
    return sign * n if seen else 0


class Font:
    def __init__(self, path):
        self.path = path
        with open(path, "rb") as f:
            raw = f.read()
        text = raw.decode("utf-8", "replace").splitlines()
        if not text:
            raise ValueError
        header = text[0].split()
        magic = header[0]
        self.is_tlf = magic.startswith("tlf2")
        if not (magic.startswith("flf2") or self.is_tlf):
            raise ValueError
        self.hardblank = magic[-1]
        self.height = int(header[1])
        self.baseline = int(header[2])
        self.maxlen = int(header[3])
        self.old_layout = int(header[4]) if len(header) > 4 else 0
        self.comment_lines = int(header[5]) if len(header) > 5 else 0
        self.print_direction = int(header[6]) if len(header) > 6 else 0
        self.full_layout = int(header[7]) if len(header) > 7 else self.old_layout
        if len(header) <= 7:
            if self.old_layout < 0:
                self.full_layout = -1
            elif self.old_layout == 0:
                self.full_layout = 64
            else:
                self.full_layout = self.old_layout
        self.chars = {}
        idx = 1 + self.comment_lines
        if idx >= len(text):
            raise ValueError
        endmark = text[idx][-1] if text[idx] else "@"

        def read_glyph(pos):
            rows = []
            for _ in range(self.height):
                if pos >= len(text):
                    line = ""
                else:
                    line = text[pos]
                pos += 1
                mark = line[-1] if self.is_tlf and line else endmark
                while line.endswith(mark):
                    line = line[:-1]
                rows.append(line)
            return rows, pos

        for code in range(32, 127):
            glyph, idx = read_glyph(idx)
            self.chars[code] = glyph
        extras = [196, 214, 220, 228, 246, 252, 223]
        for code in extras:
            if idx + self.height <= len(text):
                glyph, idx = read_glyph(idx)
                self.chars[code] = glyph
        # Code-tagged glyphs follow the Latin-1 extension in many FIGfonts.
        while idx < len(text):
            tag = text[idx].strip()
            idx += 1
            if not tag:
                break
            try:
                code = int(tag.split()[0], 0)
            except Exception:
                break
            glyph, idx = read_glyph(idx)
            self.chars[code] = glyph

    def glyph(self, ch):
        code = ord(ch)
        return self.chars.get(code) or self.chars.get(0) or self.chars.get(32)


def find_font(fontdir, name):
    base = name
    candidates = []
    if os.path.isabs(base) or "/" in base:
        candidates.append(base)
        if not (base.endswith(".flf") or base.endswith(".tlf")):
            candidates += [base + ".flf", base + ".tlf"]
    else:
        names = [base] if (base.endswith(".flf") or base.endswith(".tlf")) else [base + ".flf", base + ".tlf", base]
        for n in names:
            candidates.append(os.path.join(fontdir, n))
        for n in names:
            candidates.append(n)
    for p in candidates:
        if os.path.exists(p):
            return p
    return None


def smush_pair(a, b, mode, hardblank):
    if a == " ":
        return b
    if b == " ":
        return a
    if mode == 0:
        return None
    if mode < 0:
        return b
    if (mode & 1) and a == b and a != hardblank:
        return a
    if (mode & 2) and a == "_" and b in "|/\\[]{}()<>":
        return b
    if (mode & 2) and b == "_" and a in "|/\\[]{}()<>":
        return a
    groups = ["|", "/\\", "[]", "{}", "()", "<>"]
    if mode & 4:
        ia = ib = -1
        for i, g in enumerate(groups):
            if a in g:
                ia = i
            if b in g:
                ib = i
        if ia >= 0 and ib >= 0 and ia != ib:
            return a if ia > ib else b
    if mode & 8:
        pairs = {"[": "]", "]": "[", "{": "}", "}": "{", "(": ")", ")": "("}
        if pairs.get(a) == b:
            return "|"
    if (mode & 16) and ((a == "/" and b == "\\") or (a == "\\" and b == "/")):
        return "Y"
    if (mode & 16) and ((a == ">" and b == "<") or (a == "<" and b == ">")):
        return "X"
    if (mode & 32) and a == hardblank and b == hardblank:
        return hardblank
    return None


def overlay(left, right, mode, hardblank):
    if all(r == "" for r in left):
        return right[:]
    if mode == -1:
        best = 0
    else:
        best = 10 ** 9
        for lrow, rrow in zip(left, right):
            rt = len(lrow) - len(lrow.rstrip(" "))
            ll = len(rrow) - len(rrow.lstrip(" "))
            row = rt + ll
            li = len(lrow) - rt - 1
            ri = ll
            if mode != 0 and li >= 0 and ri < len(rrow):
                if smush_pair(lrow[li], rrow[ri], mode, hardblank) is not None:
                    row += 1
            best = min(best, row)
        if best == 10 ** 9:
            best = 0
    out = []
    for lrow, rrow in zip(left, right):
        start = len(lrow) - best
        if best == 0:
            out.append(lrow + rrow)
            continue
        row = list(lrow)
        for j, b in enumerate(rrow):
            pos = start + j
            if pos < 0:
                continue
            if pos < len(row):
                a = row[pos]
                row[pos] = smush_pair(a, b, mode, hardblank)
            else:
                row.append(b)
        out.append("".join(row))
    return out


def render_line(font, text, mode, direction, trim=True):
    original = text
    if direction == 1:
        text = text[::-1]
    rows = ["" for _ in range(font.height)]
    for ch in text:
        glyph = font.glyph(ch)
        rows = overlay(rows, glyph, mode, font.hardblank)
    if trim and mode != -1 and original and not original.startswith(" "):
        common = min((len(r) - len(r.lstrip(" ")) for r in rows if r), default=0)
        if common:
            rows = [r[common:] for r in rows]
    return [r.replace(font.hardblank, " ") for r in rows]


def fig_width(font, text, mode, direction):
    rows = render_line(font, text, mode, direction)
    return max((len(r) for r in rows), default=0)


def split_wrapped(font, line, mode, direction, width):
    if width <= 0:
        return [line]
    if width == 1:
        return [ch for ch in line if ch != " "] or [""]
    words = line.split(" ")
    parts = []
    cur = ""
    for i, word in enumerate(words):
        token = word if cur == "" else " " + word
        trial = cur + token
        if cur and fig_width(font, trial, mode, direction) >= width:
            parts.append(cur)
            cur = word
        else:
            cur = trial
    if cur or not parts:
        parts.append(cur)
    final = []
    for part in parts:
        if fig_width(font, part, mode, direction) <= width or len(part) <= 1:
            final.append(part)
            continue
        cur = ""
        for ch in part:
            if cur and fig_width(font, cur + ch, mode, direction) >= width:
                final.append(cur)
                cur = ch
            else:
                cur += ch
        if cur:
            final.append(cur)
    return final


def justify(rows, how, width):
    if how == "left" or width <= 0:
        return rows
    out = []
    for r in rows:
        n = len(r)
        pad = max(0, width - n)
        if how == "center":
            out.append(" " * (pad // 2) + r)
        elif how == "right":
            out.append(" " * max(0, width - 1 - n) + r)
        else:
            out.append(r)
    return out


def preprocess_stdin(data, paragraph):
    if not paragraph:
        return data
    out = []
    for i, ch in enumerate(data):
        if ch == "\n":
            prev = data[i - 1] if i else "\n"
            nxt = data[i + 1] if i + 1 < len(data) else "\n"
            out.append(" " if prev != "\n" and nxt != " " and nxt != "\n" else "\n")
        else:
            out.append(ch)
    return "".join(out)


def deutsch(s):
    table = str.maketrans({"[": "Ä", "\\": "Ö", "]": "Ü", "{": "ä", "|": "ö", "}": "ü", "~": "ß"})
    return s.translate(table)


def main():
    prog = os.path.basename(sys.argv[0])
    fontdir = "/usr/local/share/figlet"
    fontname = "standard"
    width = 80
    mode_opt = None
    info = -1
    justify_opt = None
    direction = 0
    paragraph = False
    use_deutsch = False
    messages = []
    args = sys.argv[1:]
    i = 0
    bad = None
    while i < len(args):
        a = args[i]
        if not a.startswith("-") or a == "-":
            messages = args[i:]
            break
        j = 1
        while j < len(a):
            opt = a[j]
            if opt in "dfwmCI":
                val = a[j + 1:] if j + 1 < len(a) else None
                if val is None:
                    i += 1
                    val = args[i] if i < len(args) else ""
                if opt == "d":
                    fontdir = val
                elif opt == "f":
                    fontname = val[:-4] if val.endswith(".flf") else (val[:-4] if val.endswith(".tlf") else val)
                elif opt == "w":
                    width = c_atoi(val)
                elif opt == "m":
                    m = c_atoi(val)
                    if m == -1:
                        mode_opt = -1
                    elif m == 0:
                        mode_opt = 0
                    elif m == -2:
                        mode_opt = None
                    else:
                        mode_opt = m
                elif opt == "C":
                    pass
                elif opt == "I":
                    info = c_atoi(val)
                j = len(a)
                break
            elif opt == "c":
                justify_opt = "center"
            elif opt == "l":
                justify_opt = "left"
            elif opt == "r":
                justify_opt = "right"
            elif opt == "x":
                justify_opt = None
            elif opt == "L":
                direction = 0
            elif opt == "R":
                direction = 1
            elif opt == "X":
                direction = 0
            elif opt == "p":
                paragraph = True
            elif opt == "n":
                paragraph = False
            elif opt == "D":
                use_deutsch = True
            elif opt == "E":
                use_deutsch = False
            elif opt == "t":
                width = shutil.get_terminal_size((width, 24)).columns
            elif opt == "v":
                info = 0
            elif opt == "W":
                mode_opt = -1
            elif opt == "k":
                mode_opt = 0
            elif opt == "o":
                mode_opt = -2
            elif opt in "sS":
                mode_opt = None
            elif opt == "N":
                pass
            else:
                bad = opt
                break
            j += 1
        if bad is not None:
            break
        i += 1
    if bad is not None:
        print(f"{sys.argv[0]}: invalid option -- '{bad}'", file=sys.stderr)
        print(usage_line(prog), file=sys.stderr)
        return 1

    if info >= 0:
        if info == 0:
            sys.stdout.write(VERSION_TEXT)
            print(usage_line(prog))
        elif info == 1:
            print("20205")
        elif info == 2:
            print(fontdir)
        elif info == 3:
            print(fontname)
        elif info == 4:
            print(width)
        elif info == 5:
            print("flf2 tlf2")
        return 0

    fpath = find_font(fontdir, fontname)
    if not fpath:
        print(f"{prog}: {fontname}: Unable to open font file", file=sys.stderr)
        return 1
    try:
        font = Font(fpath)
    except Exception:
        print(f"{prog}: {fontname}: Unable to open font file", file=sys.stderr)
        return 1
    if mode_opt is None:
        mode = font.full_layout
        if mode < 0:
            mode = -1
        elif font.old_layout == 0 and font.full_layout >= 128:
            mode = -2
        elif mode == 64:
            mode = 0
    elif mode_opt == -2:
        mode = -2
    else:
        mode = mode_opt
    if messages:
        data = " ".join(messages)
    else:
        data = preprocess_stdin(sys.stdin.read(), paragraph).rstrip("\n")
    if use_deutsch:
        data = deutsch(data)
    lines = data.split("\n")
    just = justify_opt if justify_opt else ("right" if direction == 1 else "left")
    for idx, line in enumerate(lines):
        pieces = split_wrapped(font, line, mode, direction, width)
        for piece in pieces:
            rows = render_line(font, piece, mode, direction, trim=(width != 1))
            for row in justify(rows, just, width):
                print(row)


if __name__ == "__main__":
    sys.exit(main())
