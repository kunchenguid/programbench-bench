#!/usr/bin/env python3
import json
import os
import re
import sys

VERSION = "39.2.0"

HELP = """
  fx 39.2.0
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
"""

MISSING = object()


def parse_scalar(s):
    s = s.strip()
    if not s:
        return ""
    if (s[0:1] == s[-1:] and s[:1] in ("'", '"')):
        return s[1:-1]
    if s in ("true", "True"):
        return True
    if s in ("false", "False"):
        return False
    if s in ("null", "Null", "~"):
        return None
    try:
        if re.match(r"^-?\d+$", s):
            return int(s)
        if re.match(r"^-?(\d+\.\d*|\d*\.\d+)([eE][+-]?\d+)?$", s) or re.match(r"^-?\d+[eE][+-]?\d+$", s):
            return float(s)
    except Exception:
        pass
    if s.startswith("[") or s.startswith("{"):
        try:
            return json.loads(s)
        except Exception:
            pass
    return s


def parse_yaml(text):
    root = {}
    stack = [(-1, root)]
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        line = raw.strip()
        if ":" not in line:
            raise ValueError("invalid yaml")
        key, val = line.split(":", 1)
        key = key.strip().strip('"\'')
        while stack and indent <= stack[-1][0]:
            stack.pop()
        parent = stack[-1][1]
        if val.strip() == "":
            obj = {}
            parent[key] = obj
            stack.append((indent, obj))
        else:
            parent[key] = parse_scalar(val)
    return root


def parse_toml(text):
    root = {}
    current = root
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            current = root
            for part in line[1:-1].split("."):
                current = current.setdefault(part.strip(), {})
            continue
        if "=" not in line:
            raise ValueError("invalid toml")
        key, val = line.split("=", 1)
        current[key.strip()] = parse_scalar(val)
    return root


def parse_json_stream(text, slurp=False):
    dec = json.JSONDecoder()
    vals = []
    i = 0
    n = len(text)
    while True:
        while i < n and text[i].isspace():
            i += 1
        if i >= n:
            break
        try:
            val, j = dec.raw_decode(text, i)
        except json.JSONDecodeError as e:
            print_json_error(text, e)
            sys.exit(1)
        vals.append(val)
        i = j
    if slurp:
        return vals
    if not vals:
        return None
    return vals if len(vals) > 1 else vals[0]


def print_json_error(text, err):
    lines = text.splitlines() or [text]
    line = lines[err.lineno - 1] if 0 <= err.lineno - 1 < len(lines) else ""
    print(f"Unexpected character {line[err.colno-1:err.colno]!r} on line {err.lineno}.")
    print()
    print(f"  {line}")
    print("  " + " " * max(err.colno - 1, 0) + "^")


def js_string(s):
    return json.dumps(s, ensure_ascii=False)


def scalar(v, top=False):
    if v is MISSING:
        return "undefined"
    if isinstance(v, str):
        return v if top else js_string(v)
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    return json.dumps(v, ensure_ascii=False, separators=(",", ": "))


def can_inline(v):
    return isinstance(v, list) and len(v) <= 4 and all(not isinstance(x, (dict, list)) for x in v)


def fmt(v, indent=0, top=False, no_inline=False, allow_inline=False):
    sp = " " * indent
    if v is MISSING or not isinstance(v, (dict, list)):
        return sp + scalar(v, top=top)
    if isinstance(v, list):
        if not v:
            return sp + "[]"
        if can_inline(v) and allow_inline and not top and not no_inline:
            return sp + "[ " + ", ".join(scalar(x) for x in v) + " ]"
        out = [sp + "["]
        for i, item in enumerate(v):
            chunk = fmt(item, indent + 2, top=False, no_inline=no_inline, allow_inline=False)
            if i != len(v) - 1:
                chunk += ","
            out.append(chunk)
        out.append(sp + "]")
        return "\n".join(out)
    if not v:
        return sp + "{}"
    out = [sp + "{"]
    items = list(v.items())
    for idx, (k, val) in enumerate(items):
        pref = " " * (indent + 2) + js_string(str(k)) + ": "
        if isinstance(val, (dict, list)) and not (can_inline(val) and not no_inline):
            rendered = fmt(val, indent + 2, top=False, no_inline=no_inline, allow_inline=True).lstrip()
            line = pref + rendered
        else:
            line = pref + (fmt(val, 0, top=False, no_inline=no_inline, allow_inline=True).strip())
        if idx != len(items) - 1:
            line += ","
        out.append(line)
    out.append(sp + "}")
    return "\n".join(out)


def ref_error(expr):
    print()
    print(f"  {expr}")
    print("  " + "^" * len(expr))
    print()
    print(f"ReferenceError: {expr} is not defined")
    sys.exit(1)


def syntax_error(expr, msg="Unexpected token"):
    print()
    print(f"  {expr}")
    print("  " + "^" * max(len(expr), 1))
    print()
    print(f"{msg} ")
    sys.exit(1)


def get_prop(obj, key):
    if obj is MISSING:
        return MISSING
    if key == "length" and isinstance(obj, (list, str, dict)):
        return len(obj)
    if isinstance(obj, dict):
        return obj.get(key, MISSING)
    return MISSING


def eval_path(obj, expr):
    if expr in ("", ".", "this", "json"):
        return obj
    cur = obj
    i = 0
    if expr.startswith("."):
        i = 1
    else:
        ref_error(expr)
    while i < len(expr):
        if expr[i] == ".":
            i += 1
            continue
        if expr[i] == "[":
            j = expr.find("]", i)
            if j < 0:
                syntax_error(expr)
            key = expr[i + 1:j].strip()
            if (key.startswith('"') and key.endswith('"')) or (key.startswith("'") and key.endswith("'")):
                cur = get_prop(cur, key[1:-1])
            else:
                try:
                    idx = int(key)
                    cur = cur[idx] if isinstance(cur, list) and 0 <= idx < len(cur) else MISSING
                except Exception:
                    cur = MISSING
            i = j + 1
            continue
        m = re.match(r"[A-Za-z_$][A-Za-z0-9_$]*", expr[i:])
        if not m:
            syntax_error(expr)
        cur = get_prop(cur, m.group(0))
        i += len(m.group(0))
    return cur


def apply_filter(obj, expr):
    expr = expr.strip()
    if expr in ("", ".", "this", "json"):
        return obj
    if expr == "keys":
        if isinstance(obj, dict):
            return list(obj.keys())
        if isinstance(obj, list):
            return list(range(len(obj)))
        return []
    if expr == "values":
        if isinstance(obj, dict):
            return list(obj.values())
        if isinstance(obj, list):
            return obj
        return []
    if expr == "reverse" and isinstance(obj, list):
        return list(reversed(obj))
    if expr == "sort" and isinstance(obj, list):
        try:
            return sorted(obj)
        except Exception:
            return obj
    if expr.startswith("map(") and expr.endswith(")") and isinstance(obj, list):
        inner = expr[4:-1].strip()
        return [apply_filter(x, inner) for x in obj]
    if expr.startswith("filter(") and expr.endswith(")") and isinstance(obj, list):
        inner = expr[7:-1].strip()
        return [x for x in obj if apply_filter(x, inner)]
    return eval_path(obj, expr)


def themes():
    sample = '{\n  "string": "Fox jumps over the lazy dog",\n  "number": 1234567890,\n  "boolean": true,\n  "null": null,\n  "collapsed": {"preview":…}\n}'
    for i in range(10):
        print(f'export FX_THEME="{i}"')
        print(sample)


def completion(shell):
    if shell == "bash":
        print("complete -o filenames -C fx fx")
    elif shell == "fish":
        print("complete --command fx --arguments '(COMP_FISH=(commandline -cp) fx)'")
    elif shell == "zsh":
        print("#compdef fx\n\n_fx() {\n    local -a reply\n    reply=(\"${(@f)$(COMP_ZSH=\"${LBUFFER}\" fx)}\")\n}\ncompdef _fx fx")
    else:
        print("unknown shell type")


def main(argv):
    raw = slurp = yaml_mode = toml_mode = no_inline = False
    args = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            print(HELP)
            return 0
        if a in ("-v", "--version"):
            print(VERSION)
            return 0
        if a == "--themes":
            themes()
            return 0
        if a == "--comp":
            completion(argv[i + 1] if i + 1 < len(argv) else "")
            return 0
        if a in ("-r", "--raw"):
            raw = True
        elif a in ("-s", "--slurp"):
            slurp = True
        elif a == "--yaml":
            yaml_mode = True
        elif a == "--toml":
            toml_mode = True
        elif a == "--no-inline":
            no_inline = True
        elif a in ("--strict", "--game-of-life"):
            pass
        else:
            args.append(a)
        i += 1

    input_text = None
    filters = args
    if args and os.path.exists(args[0]) and os.path.isfile(args[0]):
        with open(args[0], "r", encoding="utf-8") as f:
            input_text = f.read()
        filters = args[1:]
    else:
        input_text = sys.stdin.read()

    if raw:
        data = input_text[:-1] if input_text.endswith("\n") else input_text
    elif yaml_mode:
        data = parse_yaml(input_text)
    elif toml_mode:
        data = parse_toml(input_text)
    else:
        data = parse_json_stream(input_text, slurp=slurp)

    if filters:
        for f in filters:
            data = apply_filter(data, f)
    print(fmt(data, top=True, no_inline=no_inline))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main(sys.argv[1:]))
    except BrokenPipeError:
        pass
