package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"os"
	"strings"
	"time"
)

type module struct {
	Path     string     `json:"Path"`
	Version  string     `json:"Version"`
	Time     string     `json:"Time"`
	Indirect bool       `json:"Indirect"`
	Update   *modUpdate `json:"Update"`
}

type modUpdate struct {
	Path    string `json:"Path"`
	Version string `json:"Version"`
	Time    string `json:"Time"`
}

type row struct {
	module          string
	version         string
	newVersion      string
	direct          string
	validTimestamps string
	hasUpdate       bool
}

func main() {
	onlyDirect := flag.Bool("direct", false, "List only direct modules")
	onlyUpdate := flag.Bool("update", false, "List only modules with updates")
	ci := flag.Bool("ci", false, "Non-zero exit code when at least one outdated dependency was found")
	style := flag.String("style", "default", "Output style, pass 'markdown' for a Markdown table")
	flag.Parse()

	dec := json.NewDecoder(os.Stdin)
	var rows []row
	outdated := false

	for {
		var m module
		err := dec.Decode(&m)
		if err == io.EOF {
			break
		}
		if err != nil {
			log.Print(err)
			return
		}

		direct := !m.Indirect
		if *onlyDirect && !direct {
			continue
		}
		hasUpdate := m.Update != nil && m.Update.Version != ""
		if *onlyUpdate && !hasUpdate {
			continue
		}

		newVersion := ""
		valid := true
		if m.Update != nil {
			newVersion = m.Update.Version
			valid = validTimes(m.Time, m.Update.Time)
		}
		rows = append(rows, row{
			module:          m.Path,
			version:         m.Version,
			newVersion:      newVersion,
			direct:          fmt.Sprintf("%t", direct),
			validTimestamps: fmt.Sprintf("%t", valid),
			hasUpdate:       hasUpdate,
		})
		if hasUpdate {
			outdated = true
		}
	}

	if len(rows) > 0 {
		if *style == "markdown" {
			printTable(rows, true)
		} else {
			printTable(rows, false)
		}
	}
	if *ci && outdated {
		os.Exit(1)
	}
}

func validTimes(current, update string) bool {
	if current == "" || update == "" {
		return true
	}
	t1, err1 := time.Parse(time.RFC3339, current)
	t2, err2 := time.Parse(time.RFC3339, update)
	if err1 != nil || err2 != nil {
		return true
	}
	return !t2.Before(t1)
}

func printTable(rows []row, markdown bool) {
	headers := []string{"MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"}
	widths := make([]int, len(headers))
	copy(widths, []int{len(headers[0]), len(headers[1]), len(headers[2]), len(headers[3]), len(headers[4])})
	for _, r := range rows {
		vals := []string{r.module, r.version, r.newVersion, r.direct, r.validTimestamps}
		for i, v := range vals {
			if len(v) > widths[i] {
				widths[i] = len(v)
			}
		}
	}

	if !markdown {
		fmt.Println(border(widths))
	}
	fmt.Println(headerLine(headers, widths))
	fmt.Println(separator(widths, markdown))
	for _, r := range rows {
		fmt.Println(dataLine([]string{r.module, r.version, r.newVersion, r.direct, r.validTimestamps}, widths))
	}
	if !markdown {
		fmt.Println(border(widths))
	}
}

func border(widths []int) string {
	parts := make([]string, len(widths))
	for i, w := range widths {
		parts[i] = strings.Repeat("-", w+2)
	}
	return "+" + strings.Join(parts, "+") + "+"
}

func separator(widths []int, markdown bool) string {
	if !markdown {
		return border(widths)
	}
	parts := make([]string, len(widths))
	for i, w := range widths {
		parts[i] = strings.Repeat("-", w+2)
	}
	return "|" + strings.Join(parts, "|") + "|"
}

func headerLine(headers []string, widths []int) string {
	cells := make([]string, len(headers))
	for i, h := range headers {
		cells[i] = center(h, widths[i]+2)
	}
	return "|" + strings.Join(cells, "|") + "|"
}

func dataLine(values []string, widths []int) string {
	cells := make([]string, len(values))
	for i, v := range values {
		cells[i] = " " + v + strings.Repeat(" ", widths[i]-len(v)+1)
	}
	return "|" + strings.Join(cells, "|") + "|"
}

func center(s string, width int) string {
	pad := width - len(s)
	if pad <= 0 {
		return s
	}
	left := pad / 2
	right := pad - left
	return strings.Repeat(" ", left) + s + strings.Repeat(" ", right)
}
