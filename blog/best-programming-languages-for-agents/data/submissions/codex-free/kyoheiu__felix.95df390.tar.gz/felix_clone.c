#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

static const char *HELP_TEXT =
"# felix v2.16.1\n"
"A simple TUI file manager with vim-like keymapping.\n"
"\n"
"## Usage\n"
"`fx` => Show items in the current directory.\n"
"`fx <directory path>` => Show items in the path.\n"
"Both relative and absolute path available.\n"
"\n"
"## Options\n"
"`--help` | `-h`   => Print help.\n"
"`--log`  | `-l`   => Launch the app, automatically generating a log file.\n"
"`--init`          => Returns a shell script that can be sourcedfor\n"
"                     for shell integration.\n"
"\n"
"## Manual\n"
"j / <Down>         :Go down.\n"
"k / <Up>           :Go up.\n"
"<C-d>              :Go down 1/2 page.\n"
"<C-u>>             :Go up 1/2 page.\n"
"h / <Left>         :Go to the parent directory if exists.\n"
"l / <Right> / <CR> :Open item or change directory.\n"
"gg                 :Go to the top.\n"
"G                  :Go to the bottom.\n"
"z<CR>              :Go to the home directory.\n"
"z {keyword}<CR>    :Jump to a directory that matches the keyword.\n"
"                    (zoxide required)\n"
"<C-o>              :Jump backward.\n"
"<C-i>              :Jump forward.\n"
"i{file name}<CR>   :Create a new empty file.\n"
"I{dir name}<CR>    :Create a new empty directory.\n"
"o                  :Open item in a new window.\n"
"e                  :Unpack archive/compressed file.\n"
"dd                 :Delete and yank item.\n"
"yy                 :Yank item.\n"
"p                  :Put yanked item(s) from register zero\n"
"                    in the current directory.\n"
":reg               :Show registers. To hide it, press v.\n"
"\"ayy               :Yank item to register a.\n"
"\"add               :Delete and yank item to register a.\n"
"\"Ayy               :Append item to register a.\n"
"\"Add               :Delete and append item to register a.\n"
"\"ap                :Put item(s) from register a.\n"
"V                  :Switch to the linewise visual mode.\n"
"  - y              :In the visual mode, yank selected item(s).\n"
"  - d              :In the visual mode, delete and yank selected item(s).\n"
"  - \"ay            :In the visual mode, yank items to register a.\n"
"  - \"ad            :In the visual mode, delete and yank items to register a.\n"
"  - \"Ay            :In the visual mode, append items to register a.\n"
"  - \"Ad            :In the visual mode, delete and append items to register a.\n"
"  - c              :Rename selected items in default editor.\n"
"u                  :Undo put/delete/rename.\n"
"<C-r>              :Redo put/delete/rename.\n"
"v                  :Toggle whether to show the preview.\n"
"s                  :Toggle between vertical / horizontal split in the preview mode.\n"
"<Alt-j>\n"
" / <Alt-<Down>>    :Scroll down the preview text.\n"
"<Alt-k> \n"
" / <Alt-<Up>>      :Scroll up the preview text.\n"
"<BS>               :Toggle whether to show hidden items.\n"
"t                  :Toggle the sort order (name <-> modified time).\n"
"c                  :Switch to the rename mode.\n"
"/{keyword}         :Search items by a keyword.\n"
"n                  :Go forward to the item that matches the keyword.\n"
"N                  :Go backward to the item that matches the keyword.\n"
":                  :Switch to the command line.\n"
"  - <C-r>a         :In the command line, paste item name in register a.\n"
":cd<CR>            :Go to the home directory.\n"
":cd {path}<CR>     :Go to the path.\n"
":e<CR>             :Reload the current directory.\n"
":config<CR>        :Go to the directory that contains the config file if exists.\n"
":trash<CR>         :Go to the trash directory.\n"
":empty<CR>         :Empty the trash directory.\n"
":h<CR>             :Show help.\n"
":q<CR>             :Exit.\n"
":{command}         :Execute a command e.g. :zip test *.md\n"
"<Esc>              :Return to the normal mode.\n"
"<C-h>              :Works as Backspace after `i`, `I`, `c`, `/`, `:` and `z`.\n"
"ZZ                 :Exit without cd to last working directory\n"
"                    (if `match_vim_exit_behavior` is `false`).\n"
"ZQ                 :cd into the last working directory and exit\n"
"                    (if shell setting is ready and `match_vim_exit_behavior is `false`).\n"
"\n"
"## Preview feature\n"
"By default, text files and directories can be previewed.\n"
"To preview images, you need to install chafa (>= v1.10.0).\n"
"Please see https://hpjansson.org/chafa/\n"
"\n"
"## Configuration\n"
"\n"
"*Both `config.yaml` and `config.yml` work.*\n"
"\n"
"### Linux\n"
"config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)\n"
"trash directory: $XDG_DATA_HOME/felix/trash\n"
"log files      : $XDG_DATA_HOME/felix/log\n"
"\n"
"### macOS\n"
"On macOS, felix looks for the config file in the following locations:\n"
"\n"
"1. `$HOME/Library/Application Support/felix/config.yaml(config.yml)`\n"
"2. `$HOME/.config/felix/config.yaml`\n"
"\n"
"trash directory: $HOME/Library/Application Support/felix/trash\n"
"log files      : $HOME/Library/Application Support/felix/log\n"
"\n"
"### Windows\n"
"config file     : $PROFILE\\\\AppData\\\\Roaming\\\\felix\\\\config.yaml(config.yml)\n"
"trash directory : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\trash\n"
"log files       : $PROFILE\\\\AppData\\\\Local\\\\felix\\\\log\n"
"\n"
"For more details, visit https://github.com/kyoheiu/felix\n";

static const char *INIT_TEXT =
"# To be eval'ed in the calling shell\n"
"  eval \"$(\n"
"    if [ -n \"$XDG_RUNTIME_DIR\" ]; then\n"
"      runtime_dir=\"$XDG_RUNTIME_DIR/felix\"\n"
"    elif [ -n \"$TMPDIR\" ]; then\n"
"      runtime_dir=\"$TMPDIR/felix\"\n"
"    else\n"
"      runtime_dir=/tmp/felix\n"
"    fi\n"
"\n"
"    mkdir -p \"$runtime_dir\"\n"
"\n"
"    # Clean up leftover LWD files\n"
"    find \"$runtime_dir\" -type f -and -mmin +1 -delete\n"
"\n"
"    cat << EOF\n"
"fx() {\n"
"  local RUNTIME_DIR=\"$runtime_dir\"\n"
"  SHELL_PID=\\$\\$ command fx \"\\$@\"\n"
"\n"
"  if [ -f \"\\$RUNTIME_DIR/\\$\\$\" ]; then\n"
"    cd \"\\$(cat \"\\$RUNTIME_DIR/\\$\\$\")\"\n"
"    rm \"\\$RUNTIME_DIR/\\$\\$\"\n"
"  fi\n"
"}\n"
"EOF\n"
"  )\"\n";

typedef struct {
    char name[PATH_MAX];
    char path[PATH_MAX];
    struct stat st;
    bool is_dir;
} Entry;

static Entry *entries = NULL;
static size_t entry_count = 0;
static size_t selected = 0;
static char cwd_path[PATH_MAX];
static struct termios old_term;
static bool raw_enabled = false;
static int term_rows = 24;
static int term_cols = 80;

static void mkdir_p(const char *path) {
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", path);
    size_t len = strlen(tmp);
    if (len == 0) return;
    if (tmp[len - 1] == '/') tmp[len - 1] = '\0';
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    mkdir(tmp, 0777);
}

static int cmp_entries(const void *a, const void *b) {
    const Entry *ea = (const Entry *)a;
    const Entry *eb = (const Entry *)b;
    if (ea->is_dir != eb->is_dir) return ea->is_dir ? -1 : 1;
    return strcasecmp(ea->name, eb->name);
}

static void free_entries(void) {
    free(entries);
    entries = NULL;
    entry_count = 0;
    selected = 0;
}

static void disable_raw(void) {
    if (raw_enabled) {
        tcsetattr(STDIN_FILENO, TCSAFLUSH, &old_term);
        raw_enabled = false;
    }
    printf("\033[?25h\033[?1049l\0338\033[?25h");
    fflush(stdout);
}

static int enable_raw(void) {
    if (tcgetattr(STDIN_FILENO, &old_term) != 0) return -1;
    struct termios raw = old_term;
    raw.c_lflag &= (tcflag_t)~(ECHO | ICANON | IEXTEN | ISIG);
    raw.c_iflag &= (tcflag_t)~(IXON | ICRNL | BRKINT | INPCK | ISTRIP);
    raw.c_oflag &= (tcflag_t)~(OPOST);
    raw.c_cflag |= CS8;
    raw.c_cc[VMIN] = 1;
    raw.c_cc[VTIME] = 0;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) != 0) return -1;
    raw_enabled = true;
    atexit(disable_raw);
    return 0;
}

static bool get_size(void) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) != 0 || ws.ws_row == 0 || ws.ws_col == 0) {
        return false;
    }
    term_rows = ws.ws_row;
    term_cols = ws.ws_col;
    return true;
}

static void join_path(char *out, size_t n, const char *dir, const char *name) {
    if (strcmp(dir, "/") == 0) snprintf(out, n, "/%s", name);
    else snprintf(out, n, "%s/%s", dir, name);
}

static int load_dir(const char *path) {
    char resolved[PATH_MAX];
    if (!realpath(path, resolved)) return -1;
    DIR *dir = opendir(resolved);
    if (!dir) return -1;

    Entry *new_entries = NULL;
    size_t cap = 0, count = 0;
    struct dirent *de;
    while ((de = readdir(dir)) != NULL) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) continue;
        if (count == cap) {
            cap = cap ? cap * 2 : 32;
            Entry *tmp = realloc(new_entries, cap * sizeof(Entry));
            if (!tmp) {
                free(new_entries);
                closedir(dir);
                return -1;
            }
            new_entries = tmp;
        }
        Entry *e = &new_entries[count];
        memset(e, 0, sizeof(*e));
        snprintf(e->name, sizeof(e->name), "%s", de->d_name);
        join_path(e->path, sizeof(e->path), resolved, de->d_name);
        if (lstat(e->path, &e->st) != 0) memset(&e->st, 0, sizeof(e->st));
        e->is_dir = S_ISDIR(e->st.st_mode);
        count++;
    }
    closedir(dir);
    qsort(new_entries, count, sizeof(Entry), cmp_entries);
    free_entries();
    entries = new_entries;
    entry_count = count;
    snprintf(cwd_path, sizeof(cwd_path), "%s", resolved);
    if (chdir(cwd_path) != 0) {}
    return 0;
}

static const char *color_for(const Entry *e) {
    if (e->is_dir) return "\033[38;5;14m";
    if (e->st.st_mode & (S_IXUSR | S_IXGRP | S_IXOTH)) return "\033[38;5;1m";
    return "\033[38;5;15m";
}

static void format_size(off_t size, char *buf, size_t n) {
    if (size < 1024) snprintf(buf, n, "%lldB", (long long)size);
    else if (size < 1024 * 1024) snprintf(buf, n, "%lldKB", (long long)((size + 1023) / 1024));
    else snprintf(buf, n, "%lldMB", (long long)((size + 1024 * 1024 - 1) / (1024 * 1024)));
}

static void draw(void) {
    get_size();
    printf("\033[?25l\033[?1049h\033[2J\033[1;1H");
    printf("\033[38;5;6m %s\033[0m", cwd_path);
    int list_rows = term_rows > 4 ? term_rows - 3 : 1;
    size_t start = 0;
    if (selected >= (size_t)list_rows) start = selected - (size_t)list_rows + 1;
    for (int i = 0; i < list_rows && start + (size_t)i < entry_count; i++) {
        Entry *e = &entries[start + (size_t)i];
        char date[64] = "";
        struct tm tmv;
        localtime_r(&e->st.st_mtime, &tmv);
        strftime(date, sizeof(date), "%Y-%m-%d %H:%M", &tmv);
        printf("\033[%d;1H%s", i + 3, (start + (size_t)i == selected) ? ">" : " ");
        printf("\033[%d;3H%s%.*s\033[0m", i + 3, color_for(e), term_cols > 20 ? term_cols - 20 : 20, e->name);
        if (term_cols > 25) printf("\033[1000D\033[%dC %s\033[0m", term_cols - 17, date);
    }
    printf("\033[%d;1H\033[2K\033[0m\033[7m%*s\033[0m", term_rows, term_cols, "");
    if (entry_count) {
        char sz[32];
        format_size(entries[selected].st.st_size, sz, sizeof(sz));
        printf("\033[%d;1H\033[7m %zu/%zu %s %o\033[0m", term_rows, selected + 1, entry_count, sz,
               entries[selected].st.st_mode & 0777);
        printf("\033[%d;1H>", (int)(selected - start) + 3);
    }
    fflush(stdout);
}

static void command_line(void) {
    char buf[256];
    size_t len = 0;
    printf("\033[?25h\033[2;2H\033[2K:");
    fflush(stdout);
    while (len + 1 < sizeof(buf)) {
        char c;
        if (read(STDIN_FILENO, &c, 1) != 1) break;
        if (c == '\r' || c == '\n') break;
        if (c == 27) {
            len = 0;
            break;
        }
        if ((c == 127 || c == 8) && len > 0) {
            len--;
            printf("\b \b");
            fflush(stdout);
            continue;
        }
        if (isprint((unsigned char)c)) {
            buf[len++] = c;
            (void)write(STDOUT_FILENO, &c, 1);
        }
    }
    buf[len] = '\0';
    if (strcmp(buf, "q") == 0) exit(0);
    if (strcmp(buf, "h") == 0) {
        printf("\033[2J\033[1;1H%s", HELP_TEXT);
        fflush(stdout);
        char c;
        while (read(STDIN_FILENO, &c, 1) == 1 && c != 27 && c != 'q' && c != '\r' && c != '\n') {}
    } else if (strncmp(buf, "cd ", 3) == 0 && buf[3]) {
        if (load_dir(buf + 3) != 0) {}
    } else if (strcmp(buf, "cd") == 0) {
        const char *home = getenv("HOME");
        if (home) load_dir(home);
    } else if (strcmp(buf, "e") == 0) {
        load_dir(cwd_path);
    } else if (buf[0]) {
        disable_raw();
        int rc = system(buf);
        (void)rc;
        enable_raw();
    }
}

static void open_selected(void) {
    if (!entry_count) return;
    if (entries[selected].is_dir) {
        load_dir(entries[selected].path);
    }
}

static void parent_dir(void) {
    if (strcmp(cwd_path, "/") == 0) return;
    char parent[PATH_MAX];
    snprintf(parent, sizeof(parent), "%s", cwd_path);
    char *slash = strrchr(parent, '/');
    if (slash && slash != parent) *slash = '\0';
    else strcpy(parent, "/");
    load_dir(parent);
}

static void write_last_working_dir(void) {
    const char *pid = getenv("SHELL_PID");
    if (!pid || !*pid) return;
    const char *base = getenv("XDG_RUNTIME_DIR");
    char runtime[PATH_MAX];
    if (base && *base) snprintf(runtime, sizeof(runtime), "%s/felix", base);
    else {
        base = getenv("TMPDIR");
        snprintf(runtime, sizeof(runtime), "%s/felix", (base && *base) ? base : "/tmp");
    }
    mkdir_p(runtime);
    char file[PATH_MAX];
    snprintf(file, sizeof(file), "%s/%s", runtime, pid);
    FILE *f = fopen(file, "w");
    if (f) {
        fprintf(f, "%s", cwd_path);
        fclose(f);
    }
}

static void tui_loop(void) {
    printf("\0337\033[?25l\033[?1049h");
    enable_raw();
    draw();
    int z_pending = 0, g_pending = 0;
    for (;;) {
        char c;
        if (read(STDIN_FILENO, &c, 1) != 1) break;
        if (c == 'j' || c == 14) {
            if (selected + 1 < entry_count) selected++;
        } else if (c == 'k' || c == 16) {
            if (selected > 0) selected--;
        } else if (c == 'G') {
            if (entry_count) selected = entry_count - 1;
        } else if (c == 'g') {
            if (g_pending) selected = 0;
            g_pending = !g_pending;
        } else if (c == 'h') {
            parent_dir();
        } else if (c == 'l' || c == '\r' || c == '\n') {
            open_selected();
        } else if (c == ':') {
            command_line();
        } else if (c == 'Z') {
            char next;
            if (read(STDIN_FILENO, &next, 1) == 1 && (next == 'Z' || next == 'Q')) {
                if (next == 'Q') write_last_working_dir();
                exit(0);
            }
        } else if (c == 'z') {
            z_pending = 1;
        } else if ((c == '\r' || c == '\n') && z_pending) {
            const char *home = getenv("HOME");
            if (home) load_dir(home);
            z_pending = 0;
        } else if (c == 4) {
            size_t step = (size_t)(term_rows / 2);
            if (selected + step >= entry_count) selected = entry_count ? entry_count - 1 : 0;
            else selected += step;
        } else if (c == 21) {
            size_t step = (size_t)(term_rows / 2);
            selected = selected > step ? selected - step : 0;
        } else if (c == 27) {
            char seq[2];
            if (read(STDIN_FILENO, seq, 1) == 1 && seq[0] == '[' && read(STDIN_FILENO, seq + 1, 1) == 1) {
                if (seq[1] == 'A' && selected > 0) selected--;
                if (seq[1] == 'B' && selected + 1 < entry_count) selected++;
                if (seq[1] == 'C') open_selected();
                if (seq[1] == 'D') parent_dir();
            }
        }
        draw();
    }
}

static void make_log(void) {
    const char *base = getenv("XDG_DATA_HOME");
    char dir[PATH_MAX];
    if (base && *base) snprintf(dir, sizeof(dir), "%s/felix", base);
    else {
        const char *home = getenv("HOME");
        snprintf(dir, sizeof(dir), "%s/.local/share/felix", home ? home : "/tmp");
    }
    mkdir_p(dir);
    strncat(dir, "/log", sizeof(dir) - strlen(dir) - 1);
    mkdir_p(dir);
    time_t now = time(NULL);
    struct tm tmv;
    localtime_r(&now, &tmv);
    char file[PATH_MAX], stamp[64], line[32];
    strftime(stamp, sizeof(stamp), "%Y-%m-%d-%H-%M-%S", &tmv);
    strftime(line, sizeof(line), "%H:%M:%S", &tmv);
    snprintf(file, sizeof(file), "%s/%s.log", dir, stamp);
    FILE *f = fopen(file, "w");
    if (f) {
        fprintf(f, "%s [INFO] ===START===\n", line);
        fclose(f);
    }
}

int main(int argc, char **argv) {
    const char *path = ".";
    bool log = false;

    if (argc >= 2 && (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0 || strcmp(argv[1], "--init") == 0)) {
        fputs(strcmp(argv[1], "--init") == 0 ? INIT_TEXT : HELP_TEXT, stdout);
        return 0;
    }
    if (argc >= 2 && (strcmp(argv[1], "-l") == 0 || strcmp(argv[1], "--log") == 0)) {
        log = true;
        if (argc >= 3) path = argv[2];
    } else if (argc == 2) {
        path = argv[1];
    } else if (argc > 2) {
        fputs(HELP_TEXT, stdout);
        return 0;
    }

    if (log) make_log();

    struct stat st;
    if (stat(path, &st) != 0) {
        printf("Invalid path: %s\n`fx -h` shows help.\n", path);
        return 0;
    }
    if (!S_ISDIR(st.st_mode)) {
        printf("Path should be directory.\n`fx -h` shows help.\n");
        return 0;
    }
    if (!get_size()) {
        printf("Error: Cannot detect terminal size\n");
        return 0;
    }
    if (load_dir(path) != 0) {
        printf("Invalid path: %s\n`fx -h` shows help.\n", path);
        return 0;
    }
    tui_loop();
    return 0;
}
