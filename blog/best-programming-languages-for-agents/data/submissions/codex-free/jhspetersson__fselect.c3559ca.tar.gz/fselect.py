#!/usr/bin/env python3
import base64
import csv
import fnmatch
import getpass
import grp
import hashlib
import html
import json
import math
import mimetypes
import os
import pwd
import random
import re
import shlex
import stat
import sys
import time
from datetime import datetime, date, timedelta


ARCHIVE_EXT = {".7z", ".bz2", ".bzip2", ".gz", ".gzip", ".lz", ".rar", ".tar", ".xz", ".zip"}
AUDIO_EXT = {".aac", ".aiff", ".amr", ".flac", ".gsm", ".m4a", ".m4b", ".m4p", ".mp3", ".ogg", ".wav", ".wma"}
BOOK_EXT = {".azw3", ".chm", ".djv", ".djvu", ".epub", ".fb2", ".mobi", ".pdf"}
DOC_EXT = {".accdb", ".doc", ".docm", ".docx", ".dot", ".dotm", ".dotx", ".mdb", ".odp", ".ods", ".odt", ".pdf", ".potm", ".potx", ".ppt", ".pptm", ".pptx", ".rtf", ".xlm", ".xls", ".xlsm", ".xlsx", ".xlt", ".xltm", ".xltx", ".xps"}
FONT_EXT = {".eot", ".fon", ".otc", ".otf", ".ttc", ".ttf", ".woff", ".woff2"}
IMAGE_EXT = {".bmp", ".exr", ".gif", ".heic", ".jpeg", ".jpg", ".jxl", ".png", ".psb", ".psd", ".svg", ".tga", ".tiff", ".webp"}
SOURCE_EXT = {".asm", ".awk", ".bas", ".c", ".cc", ".ceylon", ".clj", ".coffee", ".cpp", ".cs", ".d", ".dart", ".elm", ".erl", ".go", ".gradle", ".groovy", ".h", ".hh", ".hpp", ".java", ".jl", ".js", ".jsp", ".jsx", ".kt", ".kts", ".lua", ".nim", ".pas", ".php", ".pl", ".pm", ".py", ".rb", ".rs", ".scala", ".sol", ".swift", ".tcl", ".ts", ".tsx", ".vala", ".vb", ".zig"}
VIDEO_EXT = {".3gp", ".avi", ".flv", ".m4p", ".m4v", ".mkv", ".mov", ".mp4", ".mpeg", ".mpg", ".webm", ".wmv"}

HELP = """fselect \033[33m0.10.0\033[0m
Find files with SQL-like queries.
\033[4;36mhttps://github.com/jhspetersson/fselect\033[0m

Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]
"""


def die(msg, code=1):
    print(msg, file=sys.stderr)
    sys.exit(code)


def tokenize(s):
    lex = shlex.shlex(s, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    lex.wordchars += ".*?/:~@%+-<>=!|&[]{}"
    lex.whitespace += ","
    return list(lex)


def split_top(s, sep=","):
    out, cur, depth, quote = [], [], 0, None
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            cur.append(c)
            if c == quote:
                quote = None
        elif c in "'\"`":
            quote = c
            cur.append(c)
        elif c in "({":
            depth += 1
            cur.append(c)
        elif c in ")}":
            depth -= 1
            cur.append(c)
        elif c == sep and depth == 0:
            out.append("".join(cur).strip())
            cur = []
        else:
            cur.append(c)
        i += 1
    if cur or s.strip() == "":
        out.append("".join(cur).strip())
    return [x for x in out if x != ""]


def find_keyword(s, phrase):
    words = phrase.lower().split()
    depth, quote = 0, None
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            if c == quote:
                quote = None
            i += 1
            continue
        if c in "'\"`":
            quote = c
            i += 1
            continue
        if c in "({":
            depth += 1
        elif c in ")}":
            depth -= 1
        elif depth == 0 and (i == 0 or not (s[i - 1].isalnum() or s[i - 1] == "_")):
            j = i
            start = None
            ok = True
            for k, w in enumerate(words):
                while j < len(s) and s[j].isspace():
                    j += 1
                if start is None:
                    start = j
                if s[j:j + len(w)].lower() != w:
                    ok = False
                    break
                end = j + len(w)
                if end < len(s) and (s[end].isalnum() or s[end] == "_"):
                    ok = False
                    break
                j = end
            if ok:
                return start if start is not None else i
        i += 1
    return -1


def unquote(x):
    x = x.strip()
    if len(x) >= 2 and x[0] == x[-1] and x[0] in "'\"`":
        return x[1:-1]
    return x


def parse_query(args):
    opts = {"nocolor": False, "no_errors": False, "us_dates": False}
    rest = []
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("--nocolor", "--no-color"):
            opts["nocolor"] = True
        elif a == "--no-errors":
            opts["no_errors"] = True
        elif a == "--us-dates":
            opts["us_dates"] = True
        elif a == "--config":
            i += 1
        else:
            rest.append(a)
        i += 1
    q = " ".join(rest).strip()
    if q.lower().startswith("select "):
        q = q[7:].strip()
    fmt = "tabs"
    for kw in ("into",):
        p = find_keyword(q, kw)
        if p >= 0:
            fmt = q[p + len(kw):].strip().split()[0].lower()
            q = q[:p].strip()
            break
    offset = 0
    p = find_keyword(q, "offset")
    if p >= 0:
        tail = q[p + 6:].strip().split()
        if tail:
            offset = int(tail[0])
        q = q[:p].strip()
    limit = None
    p = find_keyword(q, "limit")
    if p >= 0:
        tail = q[p + 5:].strip().split()
        if tail:
            limit = int(tail[0])
        q = q[:p].strip()
    order = ""
    p = find_keyword(q, "order by")
    if p >= 0:
        order = q[p + len("order by"):].strip()
        q = q[:p].strip()
    group = ""
    p = find_keyword(q, "group by")
    if p >= 0:
        group = q[p + len("group by"):].strip()
        q = q[:p].strip()
    where = ""
    p = find_keyword(q, "where")
    if p >= 0:
        where = q[p + len("where"):].strip()
        q = q[:p].strip()
    roots = ["."]
    p = find_keyword(q, "from")
    if p >= 0:
        cols = q[:p].strip()
        roots_s = q[p + 4:].strip()
        roots = parse_roots(roots_s)
    else:
        cols = q.strip()
    if not cols:
        die("query: no columns specified")
    return {
        "columns": split_top(cols),
        "roots": roots,
        "where": where,
        "group": split_top(group) if group else [],
        "order": split_top(order) if order else [],
        "limit": limit,
        "offset": offset,
        "format": fmt,
        "opts": opts,
    }


def parse_roots(s):
    roots = []
    for part in split_top(s):
        toks = tokenize(part)
        if not toks:
            continue
        root = unquote(toks[0])
        opt = {"path": os.path.expanduser(root), "mindepth": 1, "maxdepth": None, "symlinks": False, "dfs": False}
        i = 1
        while i < len(toks):
            t = toks[i].lower()
            if t in ("mindepth", "maxdepth", "depth"):
                i += 1
                if i < len(toks):
                    if t == "mindepth":
                        opt["mindepth"] = int(toks[i])
                    else:
                        opt["maxdepth"] = int(toks[i])
            elif t in ("symlinks", "sym"):
                opt["symlinks"] = True
            elif t == "dfs":
                opt["dfs"] = True
            elif t in ("as",):
                i += 1
            i += 1
        roots.append(opt)
    return roots or [{"path": ".", "mindepth": 1, "maxdepth": None, "symlinks": False, "dfs": False}]


class Entry:
    def __init__(self, root, path, st=None):
        self.root = os.path.abspath(root)
        self.abspath = os.path.abspath(path)
        self.path = os.path.relpath(self.abspath, self.root)
        if self.path == ".":
            self.path = ""
        try:
            self.lst = os.lstat(self.abspath)
        except OSError:
            self.lst = None
        try:
            self.st = os.stat(self.abspath)
        except OSError:
            self.st = self.lst
        self._cache = {}

    def col(self, name):
        key = name.lower()
        aliases = {
            "extension": "ext", "fname": "filename", "dirname": "dir", "directory": "dir",
            "hsize": "fsize", "is_fifo": "is_pipe", "is_character": "is_char",
            "sticky": "is_sticky", "is_suid": "suid", "is_sgid": "sgid",
            "user_rwx": "user_all", "group_rwx": "group_all", "other_rwx": "other_all",
            "sha256": "sha2_256", "sha512": "sha2_512", "sha3": "sha3_512",
        }
        key = aliases.get(key, key)
        if key in self._cache:
            return self._cache[key]
        st = self.st
        lst = self.lst
        base = os.path.basename(self.abspath)
        stem, ext = os.path.splitext(base)
        mode = lst.st_mode if lst else 0
        ext_l = ext.lower()
        val = ""
        if key == "name":
            val = base
        elif key == "filename":
            val = stem
        elif key == "ext":
            val = ext[1:]
        elif key == "path":
            val = self.path
        elif key == "abspath":
            val = self.abspath
        elif key == "dir":
            d = os.path.dirname(self.path)
            val = "" if d == "." else d
        elif key == "absdir":
            val = os.path.dirname(self.abspath)
        elif key == "size":
            val = lst.st_size if lst else 0
        elif key == "fsize":
            val = format_size(lst.st_size if lst else 0)
        elif key in ("uid", "gid", "device", "rdev", "inode", "hardlinks"):
            attr = {"uid": "st_uid", "gid": "st_gid", "device": "st_dev", "rdev": "st_rdev", "inode": "st_ino", "hardlinks": "st_nlink"}[key]
            val = getattr(st, attr, 0) if st else 0
        elif key == "blocks":
            val = getattr(st, "st_blocks", 0) * 2 if st else 0
        elif key == "user":
            try:
                val = pwd.getpwuid(st.st_uid).pw_name
            except Exception:
                val = str(st.st_uid if st else "")
        elif key == "group":
            try:
                val = grp.getgrgid(st.st_gid).gr_name
            except Exception:
                val = str(st.st_gid if st else "")
        elif key in ("mtime", "atime", "ctime"):
            val = int(getattr(st, "st_" + key[0] + "time", 0)) if st else 0
        elif key in ("modified", "accessed", "created"):
            attr = {"modified": "st_mtime", "accessed": "st_atime", "created": "st_ctime"}[key]
            val = datetime.fromtimestamp(getattr(st, attr, 0)).strftime("%Y-%m-%d %H:%M:%S") if st else ""
        elif key == "is_dir":
            val = stat.S_ISDIR(mode)
        elif key == "is_file":
            val = stat.S_ISREG(mode)
        elif key == "is_symlink":
            val = stat.S_ISLNK(mode)
        elif key == "is_pipe":
            val = stat.S_ISFIFO(mode)
        elif key == "is_char":
            val = stat.S_ISCHR(mode)
        elif key == "is_block":
            val = stat.S_ISBLK(mode)
        elif key == "is_socket":
            val = stat.S_ISSOCK(mode)
        elif key == "is_hidden":
            val = base.startswith(".")
        elif key == "mode":
            val = stat.filemode(mode)
        elif key.endswith("_read") or key.endswith("_write") or key.endswith("_exec") or key.endswith("_all"):
            val = perm_bool(mode, key)
        elif key == "suid":
            val = bool(mode & stat.S_ISUID)
        elif key == "sgid":
            val = bool(mode & stat.S_ISGID)
        elif key == "is_sticky":
            val = bool(mode & stat.S_ISVTX)
        elif key == "is_empty":
            val = is_empty(self.abspath, mode, st)
        elif key == "is_shebang":
            val = starts_with(self.abspath, b"#!")
        elif key == "line_count":
            val = line_count(self.abspath)
        elif key == "mime":
            val = mimetypes.guess_type(self.abspath)[0] or ""
        elif key == "is_binary":
            val = is_binary(self.abspath)
        elif key == "is_text":
            val = not is_binary(self.abspath) if stat.S_ISREG(mode) else False
        elif key == "is_archive":
            val = ext_l in ARCHIVE_EXT
        elif key == "is_audio":
            val = ext_l in AUDIO_EXT
        elif key == "is_book":
            val = ext_l in BOOK_EXT
        elif key == "is_doc":
            val = ext_l in DOC_EXT
        elif key == "is_font":
            val = ext_l in FONT_EXT
        elif key == "is_image":
            val = ext_l in IMAGE_EXT
        elif key == "is_source":
            val = ext_l in SOURCE_EXT
        elif key == "is_video":
            val = ext_l in VIDEO_EXT
        elif key in ("sha1", "sha2_256", "sha2_512", "sha3_512"):
            val = digest(self.abspath, key)
        elif key in ("width", "height"):
            w, h = image_size(self.abspath)
            val = w if key == "width" else h
        elif key in ("has_xattrs", "has_extattrs", "has_acl", "has_default_acl", "has_capabilities"):
            val = False
        elif key == "xattr_count":
            val = 0
        elif key in ("extattrs", "acl", "default_acl", "capabilities"):
            val = ""
        else:
            val = ""
        self._cache[key] = val
        return val


def perm_bool(mode, key):
    who, what = key.split("_", 1)
    masks = {
        "user": (stat.S_IRUSR, stat.S_IWUSR, stat.S_IXUSR),
        "group": (stat.S_IRGRP, stat.S_IWGRP, stat.S_IXGRP),
        "other": (stat.S_IROTH, stat.S_IWOTH, stat.S_IXOTH),
    }[who]
    if what == "read":
        return bool(mode & masks[0])
    if what == "write":
        return bool(mode & masks[1])
    if what == "exec":
        return bool(mode & masks[2])
    return all(mode & m for m in masks)


def starts_with(path, prefix):
    try:
        with open(path, "rb") as f:
            return f.read(len(prefix)) == prefix
    except Exception:
        return False


def line_count(path):
    try:
        with open(path, "rb") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def is_binary(path):
    try:
        with open(path, "rb") as f:
            data = f.read(4096)
        return b"\0" in data
    except Exception:
        return False


def is_empty(path, mode, st):
    if stat.S_ISDIR(mode):
        try:
            return len(os.listdir(path)) == 0
        except Exception:
            return False
    return (st.st_size if st else 0) == 0


def digest(path, kind):
    alg = {"sha1": "sha1", "sha2_256": "sha256", "sha2_512": "sha512", "sha3_512": "sha3_512"}[kind]
    h = hashlib.new(alg)
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                h.update(chunk)
        return h.hexdigest()
    except Exception:
        return ""


def image_size(path):
    try:
        with open(path, "rb") as f:
            data = f.read(32)
            if data.startswith(b"\x89PNG\r\n\x1a\n"):
                return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
            if data[:6] in (b"GIF87a", b"GIF89a"):
                return int.from_bytes(data[6:8], "little"), int.from_bytes(data[8:10], "little")
    except Exception:
        pass
    return 0, 0


def format_size(n):
    n = float(n)
    units = ["B", "K", "M", "G", "T", "P"]
    i = 0
    while abs(n) >= 1024 and i < len(units) - 1:
        n /= 1024.0
        i += 1
    if i == 0:
        return f"{int(n)}B"
    return f"{n:.1f}{units[i]}".replace(".0", "")


def walk(rootopt):
    root = os.path.abspath(rootopt["path"])
    if not os.path.exists(root):
        raise FileNotFoundError(rootopt["path"])
    maxd = rootopt["maxdepth"]
    mind = rootopt["mindepth"]
    follow = rootopt["symlinks"]
    q = [(root, 0)]
    while q:
        path, d = q.pop() if rootopt.get("dfs") else q.pop(0)
        if d >= mind and path != root:
            yield Entry(root, path)
        if maxd is not None and d >= maxd:
            continue
        try:
            names = os.listdir(path)
        except Exception:
            continue
        for name in names:
            child = os.path.join(path, name)
            try:
                lst = os.lstat(child)
            except OSError:
                continue
            if stat.S_ISDIR(lst.st_mode) or (follow and stat.S_ISLNK(lst.st_mode) and os.path.isdir(child)):
                if maxd is None or d + 1 < maxd:
                    q.append((child, d + 1))
            else:
                if d + 1 >= mind:
                    yield Entry(root, child)


def to_num(v):
    if isinstance(v, bool):
        return 1 if v else 0
    if isinstance(v, (int, float)):
        return v
    s = str(v).strip()
    mult = 1
    m = re.match(r"^(-?\d+(?:\.\d+)?)([kmgtp]i?b?|bytes?)?$", s, re.I)
    if m:
        unit = (m.group(2) or "").lower()
        if unit.startswith("k"):
            mult = 1024
        elif unit.startswith("m"):
            mult = 1024 ** 2
        elif unit.startswith("g"):
            mult = 1024 ** 3
        elif unit.startswith("t"):
            mult = 1024 ** 4
        return float(m.group(1)) * mult
    try:
        return float(s)
    except Exception:
        return 0


def truth(v):
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v != 0
    return str(v).lower() not in ("", "0", "false", "no", "none", "null")


def val_str(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


class ExprParser:
    def __init__(self, text):
        self.toks = tokenize_expr(text)
        self.i = 0

    def peek(self):
        return self.toks[self.i] if self.i < len(self.toks) else None

    def pop(self):
        t = self.peek()
        self.i += 1
        return t

    def parse(self):
        if not self.toks:
            return lambda e: True
        return self.parse_or()

    def parse_or(self):
        left = self.parse_and()
        while self.peek() and self.peek().lower() == "or":
            self.pop()
            right = self.parse_and()
            old = left
            left = lambda e, old=old, right=right: old(e) or right(e)
        return left

    def parse_and(self):
        left = self.parse_atom()
        while self.peek() and self.peek().lower() == "and":
            self.pop()
            right = self.parse_atom()
            old = left
            left = lambda e, old=old, right=right: old(e) and right(e)
        return left

    def parse_atom(self):
        if self.peek() == "(":
            self.pop()
            inner = self.parse_or()
            if self.peek() == ")":
                self.pop()
            return inner
        left = self.parse_value_token()
        op = self.peek()
        if op is None or op.lower() in ("and", "or", ")"):
            return lambda e, left=left: truth(left(e))
        self.pop()
        opl = op.lower()
        if opl == "not" and self.peek() and self.peek().lower() == "like":
            self.pop()
            opl = "notlike"
        if opl == "between":
            a = self.parse_value_token()
            if self.peek() and self.peek().lower() == "and":
                self.pop()
            b = self.parse_value_token()
            return lambda e, left=left, a=a, b=b: to_num(a(e)) <= to_num(left(e)) <= to_num(b(e))
        if opl == "in":
            vals = []
            if self.peek() == "(":
                self.pop()
                while self.peek() and self.peek() != ")":
                    if self.peek() == ",":
                        self.pop()
                    else:
                        vals.append(self.parse_value_token())
                if self.peek() == ")":
                    self.pop()
            else:
                vals.append(self.parse_value_token())
            return lambda e, left=left, vals=vals: any(val_str(left(e)) == val_str(v(e)) for v in vals)
        right = self.parse_value_token()
        return lambda e, left=left, right=right, opl=opl: compare(left(e), opl, right(e))

    def parse_value_token(self):
        tok = self.pop()
        if tok is None:
            return lambda e: ""
        if tok in ("+", "-") and self.peek():
            nxt = self.pop()
            tok += nxt
        if self.peek() == "(" and re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", tok):
            self.pop()
            args = []
            while self.peek() and self.peek() != ")":
                if self.peek() == ",":
                    self.pop()
                else:
                    args.append(self.parse_value_token())
            if self.peek() == ")":
                self.pop()
            return lambda e, name=tok, args=args: eval_func(name, [a(e) for a in args], e)
        return lambda e, tok=tok: eval_literal_or_col(tok, e)


def tokenize_expr(s):
    out, cur, quote = [], [], None
    ops = ["!==", "===", "!=~", "!~=", ">=", "<=", "!=", "<>", "=~", "~=", "==", "=", "<", ">", "(", ")", ","]
    i = 0
    while i < len(s):
        c = s[i]
        if quote:
            if c == quote:
                out.append("".join(cur))
                cur = []
                quote = None
            else:
                cur.append(c)
            i += 1
            continue
        if c in "'\"`":
            if cur:
                out.append("".join(cur)); cur = []
            quote = c
            i += 1
            continue
        if c.isspace():
            if cur:
                out.append("".join(cur)); cur = []
            i += 1
            continue
        matched = None
        for op in ops:
            if s.startswith(op, i):
                matched = op
                break
        if matched:
            if cur:
                out.append("".join(cur)); cur = []
            out.append(matched)
            i += len(matched)
            continue
        cur.append(c)
        i += 1
    if cur:
        out.append("".join(cur))
    return out


def eval_literal_or_col(tok, e):
    tl = tok.lower()
    if tl in ("true", "yes"):
        return True
    if tl in ("false", "no"):
        return False
    if tl in ("null", "none"):
        return ""
    if re.match(r"^-?\d+(\.\d+)?([kmgtp]i?b?|bytes?)?$", tok, re.I):
        return to_num(tok)
    if re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", tok) and is_known_col(tok):
        return e.col(tok)
    return tok


def is_known_col(name):
    cols = {
        "name", "filename", "fname", "extension", "ext", "path", "abspath", "directory", "dirname", "dir", "absdir",
        "size", "fsize", "hsize", "uid", "gid", "user", "group", "created", "accessed", "modified", "atime", "mtime",
        "ctime", "is_dir", "is_file", "is_symlink", "is_pipe", "is_fifo", "is_char", "is_character", "is_block",
        "is_socket", "device", "rdev", "inode", "blocks", "hardlinks", "mode", "user_read", "user_write",
        "user_exec", "user_all", "user_rwx", "group_read", "group_write", "group_exec", "group_all", "group_rwx",
        "other_read", "other_write", "other_exec", "other_all", "other_rwx", "suid", "is_suid", "sgid", "is_sgid",
        "is_sticky", "sticky", "is_hidden", "has_xattrs", "xattr_count", "extattrs", "has_extattrs", "acl",
        "has_acl", "default_acl", "has_default_acl", "has_capabilities", "has_caps", "capabilities", "caps",
        "is_shebang", "is_empty", "width", "height", "duration", "mp3_bitrate", "bitrate", "mp3_freq", "freq",
        "mp3_title", "title", "mp3_artist", "artist", "mp3_album", "album", "mp3_year", "mp3_genre", "genre",
        "mime", "line_count", "is_binary", "is_text", "is_archive", "is_audio", "is_book", "is_doc", "is_font",
        "is_image", "is_source", "is_video", "sha1", "sha2_256", "sha256", "sha2_512", "sha512", "sha3_512", "sha3",
    }
    return name.lower() in cols


def compare(a, op, b):
    op = {"eq": "=", "==": "=", "ne": "!=", "<>": "!=", "lt": "<", "lte": "<=", "le": "<=", "gt": ">", "gte": ">=", "ge": ">=", "rx": "=~", "regexp": "=~", "notrx": "!=~", "eeq": "===", "ene": "!=="} .get(op.lower(), op.lower())
    sa, sb = val_str(a), val_str(b)
    if op in ("=", "!="):
        da, db = date_key(sa), date_key(sb)
        if da and db:
            ok = da == db
        elif any(ch in sb for ch in "*?["):
            ok = fnmatch.fnmatchcase(sa, sb)
        else:
            ok = sa == sb
        return ok if op == "=" else not ok
    if op in ("===", "!=="):
        ok = sa == sb
        return ok if op == "===" else not ok
    if op in ("=~", "~=", "!=~", "!~="):
        try:
            ok = re.search(sb, sa) is not None
        except re.error:
            ok = False
        return ok if op in ("=~", "~=") else not ok
    if op in ("like", "notlike"):
        pat = "^" + re.escape(sb).replace("%", ".*").replace("_", ".") + "$"
        ok = re.match(pat, sa) is not None
        return ok if op == "like" else not ok
    if op in ("<", "<=", ">", ">="):
        da, db = parse_datetimeish(sa), parse_datetimeish(sb)
        if da and db:
            na, nb = da.timestamp(), db.timestamp()
            return {"<": na < nb, "<=": na <= nb, ">": na > nb, ">=": na >= nb}[op]
        na, nb = to_num(a), to_num(b)
        if na == 0 and nb == 0 and not str(a).strip().startswith("0") and not str(b).strip().startswith("0"):
            na, nb = sa, sb
        return {"<": na < nb, "<=": na <= nb, ">": na > nb, ">=": na >= nb}[op]
    return False


def parse_datetimeish(s):
    sl = s.strip().lower()
    if sl == "today":
        return datetime.combine(date.today(), datetime.min.time())
    if sl == "yesterday":
        return datetime.combine(date.today() - timedelta(days=1), datetime.min.time())
    if sl == "tomorrow":
        return datetime.combine(date.today() + timedelta(days=1), datetime.min.time())
    return parse_datetime(s)


def date_key(s):
    d = parse_datetimeish(s)
    return d.date().isoformat() if d else None


def eval_expr(expr, e):
    expr = expr.strip()
    if len(expr) >= 2 and expr[0] == expr[-1] and expr[0] in "'\"`":
        return expr[1:-1]
    return ExprParser(expr).parse_value_token()(e) if expr else ""


def eval_func(name, args, e=None):
    n = name.lower()
    sargs = [val_str(a) for a in args]
    try:
        if n in ("lower", "lowercase", "lcase"):
            return sargs[0].lower()
        if n in ("upper", "uppercase", "ucase"):
            return sargs[0].upper()
        if n in ("length", "len"):
            return len(sargs[0])
        if n == "initcap":
            return sargs[0].title()
        if n == "concat":
            return "".join(sargs)
        if n == "concat_ws":
            return sargs[0].join(sargs[1:])
        if n in ("substr", "substring"):
            start = int(to_num(args[1])) - 1 if len(args) > 1 else 0
            ln = int(to_num(args[2])) if len(args) > 2 else None
            return sargs[0][start:] if ln is None else sargs[0][start:start + ln]
        if n == "replace":
            return sargs[0].replace(sargs[1], sargs[2])
        if n == "trim":
            return sargs[0].strip()
        if n == "ltrim":
            return sargs[0].lstrip()
        if n == "rtrim":
            return sargs[0].rstrip()
        if n in ("to_base64", "base64"):
            return base64.b64encode(sargs[0].encode()).decode()
        if n == "from_base64":
            return base64.b64decode(sargs[0]).decode(errors="replace")
        if n in ("abs", "sqrt", "floor", "ceil", "ceiling", "round", "hex", "oct", "bin"):
            x = to_num(args[0])
            return {"abs": abs, "sqrt": math.sqrt, "floor": math.floor, "ceil": math.ceil, "ceiling": math.ceil, "round": round, "hex": lambda y: format(int(y), "x"), "oct": lambda y: format(int(y), "o"), "bin": lambda y: format(int(y), "b")}[n](x)
        if n in ("power", "pow"):
            return math.pow(to_num(args[0]), to_num(args[1]))
        if n == "format_size" or n == "format_filesize":
            return format_size(to_num(args[0]))
        if n in ("year", "month", "day"):
            dt = parse_datetime(sargs[0])
            return {"year": dt.year, "month": dt.month, "day": dt.day}[n] if dt else ""
        if n in ("current_date", "cur_date", "curdate"):
            return date.today().isoformat()
        if n in ("current_time", "cur_time", "curtime"):
            return datetime.now().strftime("%H:%M:%S")
        if n in ("current_timestamp", "now"):
            return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if n == "current_uid":
            return os.getuid()
        if n == "current_gid":
            return os.getgid()
        if n == "current_user":
            return getpass.getuser()
        if n == "current_group":
            return grp.getgrgid(os.getgid()).gr_name
        if n == "contains" and e is not None:
            try:
                with open(e.abspath, "r", errors="ignore") as f:
                    return sargs[0] in f.read()
            except Exception:
                return False
        if n == "coalesce":
            for a in args:
                if val_str(a):
                    return a
            return ""
        if n in ("rand", "random"):
            if len(args) == 2:
                return random.uniform(to_num(args[0]), to_num(args[1]))
            return random.random() * (to_num(args[0]) if args else 1)
    except Exception:
        return ""
    return ""


def parse_datetime(s):
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d %H", "%Y-%m-%d"):
        try:
            return datetime.strptime(s[:len(fmt)], fmt)
        except Exception:
            pass
    return None


def column_value(expr, e):
    expr = expr.strip()
    ar = split_arith(expr)
    if ar:
        left, op, right = ar
        a, b = to_num(column_value(left, e)), to_num(column_value(right, e))
        try:
            return {"+": a + b, "-": a - b, "*": a * b, "/": a / b if b != 0 else 0, "%": a % b if b != 0 else 0}[op]
        except Exception:
            return 0
    m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)\s*[\(\{](.*)[\)\}]$", expr)
    if m:
        args = [column_value(x, e) for x in split_top(m.group(2))]
        return eval_func(m.group(1), args, e)
    if expr == "*":
        return e.col("path")
    return eval_literal_or_col(unquote(expr), e)


def split_arith(expr):
    depth, quote = 0, None
    for i in range(len(expr) - 1, -1, -1):
        c = expr[i]
        if quote:
            if c == quote:
                quote = None
            continue
        if c in "'\"`":
            quote = c
        elif c in ")}":
            depth += 1
        elif c in "({":
            depth -= 1
        elif depth == 0 and c in "+-" and i > 0:
            return expr[:i].strip(), c, expr[i + 1:].strip()
    depth, quote = 0, None
    for i in range(len(expr) - 1, -1, -1):
        c = expr[i]
        if quote:
            if c == quote:
                quote = None
            continue
        if c in "'\"`":
            quote = c
        elif c in ")}":
            depth += 1
        elif c in "({":
            depth -= 1
        elif depth == 0 and c in "*/%" and i > 0:
            return expr[:i].strip(), c, expr[i + 1:].strip()
    return None


def col_title(expr):
    s = expr.strip()
    m = re.match(r"^([A-Za-z_][A-Za-z0-9_]*)$", s)
    if m:
        return {"path": "Path", "name": "Name", "size": "Size", "ext": "Ext", "extension": "Extension"}.get(s.lower(), s[:1].upper() + s[1:])
    return s


AGG_RE = re.compile(r"^(count|min|max|avg|sum|stddev_pop|stddev|std|stddev_samp|var_pop|variance|var_samp)\s*[\(\{](.*)[\)\}]$", re.I)


def is_agg(expr):
    return AGG_RE.match(expr.strip()) is not None


def aggregate(expr, rows):
    m = AGG_RE.match(expr.strip())
    if not m:
        return ""
    fn, inner = m.group(1).lower(), m.group(2).strip()
    if fn == "count":
        return len(rows) if inner == "*" else sum(1 for r in rows if val_str(column_value(inner, r)) != "")
    vals = [column_value(inner, r) for r in rows]
    nums = [to_num(v) for v in vals]
    if not nums:
        return ""
    if fn == "min":
        return min(vals)
    if fn == "max":
        return max(vals)
    if fn == "sum":
        return sum(nums)
    if fn == "avg":
        return sum(nums) / len(nums)
    mean = sum(nums) / len(nums)
    var = sum((x - mean) ** 2 for x in nums) / (len(nums) if "samp" not in fn else max(1, len(nums) - 1))
    if fn.startswith("std"):
        return math.sqrt(var)
    return var


def run_query(q):
    pred = ExprParser(q["where"]).parse() if q["where"] else (lambda e: True)
    rows = []
    for root in q["roots"]:
        for ent in walk(root):
            try:
                if pred(ent):
                    rows.append(ent)
            except Exception:
                pass
    cols = q["columns"]
    if q["group"]:
        groups = {}
        for r in rows:
            key = tuple(val_str(column_value(g, r)) for g in q["group"])
            groups.setdefault(key, []).append(r)
        out_rows = []
        for key, grows in groups.items():
            first = grows[0]
            vals = [aggregate(c, grows) if is_agg(c) else column_value(c, first) for c in cols]
            out_rows.append((first, vals))
    elif any(is_agg(c) for c in cols):
        out_rows = [(rows[0] if rows else None, [aggregate(c, rows) if is_agg(c) else (column_value(c, rows[0]) if rows else "") for c in cols])]
    else:
        out_rows = [(r, [column_value(c, r) for c in cols]) for r in rows]
    if q["order"]:
        def keyfunc(rv):
            r, vals = rv
            keys = []
            for spec in q["order"]:
                parts = spec.split()
                expr = parts[0]
                if expr.isdigit():
                    idx = int(expr) - 1
                    v = vals[idx] if 0 <= idx < len(vals) else ""
                elif r is not None:
                    v = column_value(expr, r)
                else:
                    v = ""
                keys.append(to_num(v) if isinstance(v, (int, float)) or re.match(r"^-?\d+(\.\d+)?$", val_str(v)) else val_str(v))
            return tuple(keys)
        # Stable multi-pass sorting supports mixed asc/desc.
        for spec in reversed(q["order"]):
            desc = spec.lower().split()[-1:] == ["desc"]
            one = {"order": [spec]}
            out_rows.sort(key=lambda rv, spec=spec: sort_one(rv, spec, cols), reverse=desc)
    if q["offset"]:
        out_rows = out_rows[q["offset"]:]
    if q["limit"] is not None:
        out_rows = out_rows[:q["limit"]]
    return [vals for _, vals in out_rows], [col_title(c) for c in cols]


def sort_one(rv, spec, cols):
    r, vals = rv
    parts = spec.split()
    expr = parts[0]
    if expr.isdigit():
        idx = int(expr) - 1
        v = vals[idx] if 0 <= idx < len(vals) else ""
    elif r is not None:
        v = column_value(expr, r)
    else:
        v = ""
    s = val_str(v)
    try:
        return (0, float(s))
    except Exception:
        return (1, s)


def emit(rows, headers, fmt):
    fmt = fmt.lower()
    if fmt in ("tabs", "tab", "tsv"):
        for row in rows:
            print("\t".join(val_str(v) for v in row))
    elif fmt == "lines":
        for row in rows:
            for v in row:
                print(val_str(v))
    elif fmt == "list":
        print(" ".join(val_str(v) for row in rows for v in row))
    elif fmt == "csv":
        w = csv.writer(sys.stdout, lineterminator="\n")
        for row in rows:
            w.writerow([val_str(v) for v in row])
    elif fmt == "json":
        print(json.dumps([{headers[i]: val_str(v) for i, v in enumerate(row)} for row in rows], separators=(",", ":")), end="")
    elif fmt == "html":
        print("<table>")
        for row in rows:
            print("<tr>" + "".join("<td>" + html.escape(val_str(v)) + "</td>" for v in row) + "</tr>")
        print("</table>")
    else:
        for row in rows:
            print("\t".join(val_str(v) for v in row))


def repl():
    while True:
        try:
            line = input("> ")
        except EOFError:
            break
        if line.strip().lower() in ("exit", "quit"):
            break
        if line.strip().lower() == "pwd":
            print(os.getcwd()); continue
        if line.strip().lower() == "help":
            print(HELP); continue
        if line.strip().lower().startswith("cd "):
            try:
                os.chdir(os.path.expanduser(line.strip()[3:]))
            except Exception as e:
                print(e, file=sys.stderr)
            continue
        try:
            q = parse_query([line])
            rows, heads = run_query(q)
            emit(rows, heads, q["format"])
        except Exception as e:
            print(str(e), file=sys.stderr)


def main():
    args = sys.argv[1:]
    if not args:
        print(HELP, end="")
        return 0
    if any(a in ("--help", "-h", "--version", "-V") for a in args):
        print(HELP, end="")
        return 0
    if any(a in ("-i", "--interactive") for a in args):
        repl()
        return 0
    q = None
    try:
        q = parse_query(args)
        rows, heads = run_query(q)
        emit(rows, heads, q["format"])
        return 0
    except FileNotFoundError as e:
        if not (q and q["opts"].get("no_errors")):
            p = str(e.args[0])
            if not (q and q["opts"].get("nocolor")):
                p = f"\033[33m{p}\033[0m"
            print(f"{p}: could not canonicalize path: No such file or directory (os error 2)", file=sys.stderr)
        return 1
    except Exception as e:
        if not (q and q["opts"].get("no_errors")):
            print(f"query: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
