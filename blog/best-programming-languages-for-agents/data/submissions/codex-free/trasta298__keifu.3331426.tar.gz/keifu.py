#!/usr/bin/env python3
import os
import select
import shutil
import subprocess
import sys
import termios
import tty
import time

HELP = """A TUI tool to visualize Git commit graphs with branch genealogy

Usage: executable

Options:
  -h, --help     Print help
  -V, --version  Print version
"""

VERSION = "keifu 0.2.3"


def run_git(args, cwd=None, check=False):
    p = subprocess.run(
        ["git"] + args,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if check and p.returncode != 0:
        raise RuntimeError(p.stderr.strip() or p.stdout.strip())
    return p


def parse_args(argv):
    if any(a in ("-h", "--help") for a in argv[1:]):
        print(HELP, end="")
        return 0, False
    if any(a in ("-V", "--version") for a in argv[1:]):
        print(VERSION)
        return 0, False
    if len(argv) > 1:
        arg = argv[1]
        sys.stderr.write(f"error: unexpected argument '{arg}' found\n\n")
        sys.stderr.write("Usage: executable\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        return 2, False
    return 0, True


def ensure_repo():
    p = run_git(["rev-parse", "--show-toplevel"])
    if p.returncode != 0:
        sys.stderr.write("Error: Git repository not found. Please run inside a Git repository.\n\n")
        sys.stderr.write("Caused by:\n")
        sys.stderr.write("    could not find repository at '.'; class=Repository (6); code=NotFound (-3)\n")
        return None
    return p.stdout.strip()


def git_lines(args):
    p = run_git(args)
    if p.returncode != 0:
        return []
    return p.stdout.splitlines()


def head_branch():
    p = run_git(["branch", "--show-current"])
    name = p.stdout.strip()
    if name:
        return name
    p = run_git(["rev-parse", "--short", "HEAD"])
    return p.stdout.strip() or "HEAD"


def branch_labels():
    labels = {}
    p = run_git(["for-each-ref", "--format=%(objectname:short)|%(refname:short)", "refs/heads", "refs/remotes"])
    for line in p.stdout.splitlines():
        if "|" not in line:
            continue
        sha, name = line.split("|", 1)
        if name == "origin/HEAD":
            continue
        labels.setdefault(sha, []).append(name)
    return labels


def commits():
    fmt = "%h%x1f%H%x1f%ad%x1f%an%x1f%ae%x1f%s"
    p = run_git(["log", "--all", "--date=short", "--pretty=format:" + fmt, "-n", "500"])
    labels = branch_labels()
    rows = []
    for line in p.stdout.splitlines():
        parts = line.split("\x1f")
        if len(parts) != 6:
            continue
        short, full, date, author, email, subject = parts
        rows.append({
            "short": short,
            "full": full,
            "date": date,
            "author": author,
            "email": email,
            "subject": subject,
            "labels": labels.get(short, []),
        })
    if rows:
        return rows
    p = run_git(["status", "--porcelain"])
    if p.returncode == 0:
        return []
    return []


def changed_files(full_sha):
    p = run_git(["show", "--numstat", "--format=", "--no-renames", full_sha])
    files = []
    adds = dels = 0
    for line in p.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) != 3:
            continue
        a, d, path = parts
        ai = 0 if a == "-" else int(a or 0)
        di = 0 if d == "-" else int(d or 0)
        adds += ai
        dels += di
        files.append((path, ai, di))
    return files, adds, dels


def esc(s):
    return "\x1b[" + s


def clip(s, width):
    if width <= 0:
        return ""
    return s if len(s) <= width else s[: max(0, width - 1)] + "…"


def clean(s):
    return "".join(ch if ch >= " " else " " for ch in s)


def border(title, width):
    title_text = f" {title} "
    inner = max(0, width - len(title_text) - 2)
    return "┌" + title_text + "─" * inner + "┐"


def bottom(width):
    return "└" + "─" * max(0, width - 2) + "┘"


def draw(selected=0, show_help=False, status_msg=""):
    size = shutil.get_terminal_size((80, 24))
    w = max(40, size.columns)
    h = max(12, size.lines)
    repo = os.path.basename(run_git(["rev-parse", "--show-toplevel"]).stdout.strip() or os.getcwd())
    branch = head_branch()
    rows = commits()
    selected = min(max(selected, 0), max(0, len(rows) - 1))
    out = []
    out.append(esc("?25l"))
    out.append(esc("1;1H"))
    commit_h = max(5, h - 8)
    out.append("\x1b[38;5;8m" + border("Commits", w) + "\x1b[0m")
    visible = commit_h - 2
    start = max(0, selected - visible + 1)
    start = min(start, max(0, len(rows) - visible))
    for i in range(visible):
        idx = start + i
        y = i + 2
        out.append(esc(f"{y};1H") + "\x1b[38;5;8m│\x1b[0m")
        if idx < len(rows):
            r = rows[idx]
            lab = ""
            if r["labels"]:
                lab = "[" + r["labels"][0] + (f" +{len(r['labels'])-1}" if len(r["labels"]) > 1 else "") + "] "
            marker = "◉" if idx == selected else "●"
            graph = f"\x1b[38;5;12m{marker}\x1b[0m "
            subj = clean(lab + r["subject"])
            author = clip(r["author"], 8).ljust(8)
            left_width = max(8, w - 31)
            line = graph + clip(subj, left_width).ljust(left_width) + " "
            line += "\x1b[38;5;8m" + r["date"] + "\x1b[0m  "
            line += "\x1b[38;5;6m" + author + "\x1b[0m"
            if idx == selected:
                line = "\x1b[1;48;5;8m " + line + "\x1b[0m"
            else:
                line = " " + line
            out.append(esc(f"{y};2H") + clip(line, w + 70))
        out.append(esc(f"{y};{w}H") + "\x1b[38;5;8m│\x1b[0m")
    out.append(esc(f"{commit_h};1H") + "\x1b[38;5;8m" + bottom(w) + "\x1b[0m")
    detail_y = commit_h + 1
    half = w // 2
    out.append(esc(f"{detail_y};1H") + "\x1b[38;5;8m" + border("Commit Detail", half) + border("Changed Files", w - half) + "\x1b[0m")
    panel_h = max(4, h - detail_y - 1)
    selected_row = rows[selected] if rows else None
    files = []
    adds = dels = 0
    if selected_row:
        files, adds, dels = changed_files(selected_row["full"])
    detail = []
    if selected_row:
        detail = [
            ("Commit:", selected_row["full"]),
            ("Author:", f"{selected_row['author']} <{selected_row['email']}>"),
            ("Date:", selected_row["date"]),
            ("", selected_row["subject"]),
        ]
    else:
        detail = [("Repository:", "No commits")]
    file_lines = [f"{len(files)} files changed   +{adds} -{dels}"] + [
        f" M  {path}  +{a} -{d}" for path, a, d in files[:50]
    ]
    for i in range(panel_h - 2):
        y = detail_y + i + 1
        out.append(esc(f"{y};1H") + "\x1b[38;5;8m│\x1b[0m")
        if i < len(detail):
            k, v = detail[i]
            text = (k + " " + v).strip()
            out.append(esc(f"{y};2H") + clip(text, half - 3))
        out.append(esc(f"{y};{half}H") + "\x1b[38;5;8m││\x1b[0m")
        if i < len(file_lines):
            out.append(esc(f"{y};{half+2}H") + clip(file_lines[i], w - half - 3))
        out.append(esc(f"{y};{w}H") + "\x1b[38;5;8m│\x1b[0m")
    out.append(esc(f"{detail_y + panel_h - 1};1H") + "\x1b[38;5;8m" + bottom(half) + bottom(w - half) + "\x1b[0m")
    bar_y = h
    if show_help:
        bar = " j/k move  g/G top/bottom  Enter checkout  b branch  d delete  f fetch  R refresh  / search  q quit "
    else:
        bar = f" {repo}  {branch}  j/k move  Enter checkout  b branch  f fetch  ? help  q quit "
    if status_msg:
        bar += " " + status_msg
    out.append(esc(f"{bar_y};1H") + "\x1b[1;38;5;0;48;5;6m" + clip(bar.ljust(w), w) + "\x1b[0m")
    sys.stdout.write("".join(out))
    sys.stdout.flush()
    return selected


def checkout_selected(row):
    target = row["labels"][0] if row and row["labels"] else row["full"] if row else ""
    if not target:
        return "nothing selected"
    p = subprocess.run(["git", "checkout", target], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    return (p.stderr or p.stdout).strip().splitlines()[-1] if (p.stderr or p.stdout).strip() else f"checked out {target}"


def tui():
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        sys.stderr.write("Error: No such device or address (os error 6)\n")
        return 1
    if ensure_repo() is None:
        return 1
    old = termios.tcgetattr(sys.stdin.fileno())
    selected = 0
    show_help = False
    status_msg = ""
    try:
        tty.setcbreak(sys.stdin.fileno())
        sys.stdout.write(esc("?1049h") + esc("2J"))
        sys.stdout.flush()
        selected = draw(selected, show_help, status_msg)
        last = time.time()
        while True:
            timeout = max(0.05, 10 - (time.time() - last))
            r, _, _ = select.select([sys.stdin], [], [], timeout)
            if not r:
                last = time.time()
                selected = draw(selected, show_help, status_msg)
                continue
            ch = os.read(sys.stdin.fileno(), 16)
            if ch in (b"q", b"\x1b"):
                break
            rows = commits()
            if ch in (b"j", b"\x1b[B", b"\x04"):
                selected = min(selected + 1, max(0, len(rows) - 1))
            elif ch in (b"k", b"\x1b[A", b"\x15"):
                selected = max(0, selected - 1)
            elif ch in (b"g", b"\x1b[H"):
                selected = 0
            elif ch in (b"G", b"\x1b[F"):
                selected = max(0, len(rows) - 1)
            elif ch == b"?":
                show_help = not show_help
            elif ch == b"R":
                status_msg = "refreshed"
            elif ch == b"f":
                p = subprocess.run(["git", "fetch", "origin"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                status_msg = "fetch ok" if p.returncode == 0 else "fetch failed"
            elif ch in (b"\r", b"\n"):
                status_msg = checkout_selected(rows[selected] if rows else None)
            selected = draw(selected, show_help, status_msg)
    finally:
        termios.tcsetattr(sys.stdin.fileno(), termios.TCSADRAIN, old)
        sys.stdout.write("\x1b[0m" + esc("?1049l") + esc("?25h"))
        sys.stdout.flush()
    return 0


def main():
    code, should_run = parse_args(sys.argv)
    if not should_run:
        return code
    return tui()


if __name__ == "__main__":
    raise SystemExit(main())
