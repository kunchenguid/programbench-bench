#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <pwd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <unistd.h>

#define VERSION "htop 3.5.0-dev-878e0ce"

static const char *sort_names[] = {
   "PID","Command","STATE","PPID","PGRP","SESSION","TTY","TPGID","MINFLT",
   "CMINFLT","MAJFLT","CMAJFLT","UTIME","STIME","CUTIME","CSTIME","PRIORITY",
   "NICE","STARTTIME","PROCESSOR","M_VIRT","M_RESIDENT","M_SHARE","M_TRS",
   "M_DRS","M_LRS","ST_UID","PERCENT_CPU","PERCENT_MEM","USER","TIME","NLWP",
   "TGID","PERCENT_NORM_CPU","ELAPSED","SCHEDULERPOLICY","RCHAR","WCHAR",
   "SYSCR","SYSCW","RBYTES","WBYTES","CNCLWB","IO_READ_RATE","IO_WRITE_RATE",
   "IO_RATE","CGROUP","OOM","IO_PRIORITY","M_PSS","M_SWAP","M_PSSWP","CTXT",
   "SECATTR","COMM","EXE","CWD","AUTOGROUP_ID","AUTOGROUP_NICE","CCGROUP",
   "CONTAINER","M_PRIV","GPU_TIME","GPU_PERCENT","ISCONTAINER", NULL
};

static void print_help(void) {
   puts(VERSION);
   puts("(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.");
   puts("Released under the GNU GPLv2+.");
   puts("");
   puts("-C --no-color                   Use a monochrome color scheme");
   puts("-d --delay=DELAY                Set the delay between updates, in tenths of seconds");
   puts("-F --filter=FILTER              Show only the commands matching the given filter");
   puts("   --no-function-bar             Hide the function bar");
   puts("-h --help                       Print this help screen");
   puts("-H --highlight-changes[=DELAY]  Highlight new and old processes");
   puts("-M --no-mouse                   Disable the mouse");
   puts("   --no-meters                  Hide meters");
   puts("-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates");
   puts("-p --pid=PID[,PID,PID...]       Show only the given PIDs");
   puts("   --readonly                   Disable all system and process changing features");
   puts("-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)");
   puts("-t --tree                       Show the tree view (can be combined with -s)");
   puts("-u --user[=USERNAME]            Show only processes for a given user (or $USER)");
   puts("-U --no-unicode                 Do not use unicode but plain ASCII");
   puts("-V --version                    Print version info");
   puts("");
   puts("Press F1 inside htop for online help.");
   puts("See 'man htop' for more information.");
}

static void print_sort_help(void) {
   puts("                PID Process/thread ID");
   puts("            Command Command line (insert as last column only)");
   puts("              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)");
   puts("               PPID Parent process ID");
   puts("               PGRP Process group ID");
   puts("            SESSION Process's session ID");
   puts("                TTY Controlling terminal");
   puts("              TPGID Process ID of the fg process group of the controlling terminal");
   puts("             MINFLT Number of minor faults which have not required loading a memory page from disk");
   puts("            CMINFLT Children processes' minor faults");
   puts("             MAJFLT Number of major faults which have required loading a memory page from disk");
   puts("            CMAJFLT Children processes' major faults");
   puts("              UTIME User CPU time - time the process spent executing in user mode");
   puts("              STIME System CPU time - time the kernel spent running system calls for this process");
   puts("             CUTIME Children processes' user CPU time");
   puts("             CSTIME Children processes' system CPU time");
   puts("           PRIORITY Kernel's internal priority for the process");
   puts("               NICE Nice value (the higher the value, the more it lets other processes take priority)");
   puts("          STARTTIME Time the process was started");
   puts("          PROCESSOR Id of the CPU the process last executed on");
   puts("             M_VIRT Total program size in virtual memory");
   puts("         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage");
   puts("            M_SHARE Size of the process's shared pages");
   puts("              M_TRS Size of the .text segment of the process (CODE)");
   puts("              M_DRS Size of the .data segment plus stack usage of the process (DATA)");
   puts("              M_LRS The library size of the process (calculated from memory maps)");
   puts("             ST_UID User ID of the process owner");
   puts("        PERCENT_CPU Percentage of the CPU time the process used in the last sampling");
   puts("        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size");
   puts("               USER Username of the process owner (or user ID if name cannot be determined)");
   puts("               TIME Total time the process has spent in user and system time");
   puts("               NLWP Number of threads in the process");
   puts("               TGID Thread group ID (i.e. process ID)");
   puts("   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)");
   puts("            ELAPSED Time since the process was started");
   puts("    SCHEDULERPOLICY Current scheduling policy of the process");
   puts("              RCHAR Number of bytes the process has read");
   puts("              WCHAR Number of bytes the process has written");
   puts("              SYSCR Number of read(2) syscalls for the process");
   puts("              SYSCW Number of write(2) syscalls for the process");
   puts("             RBYTES Bytes of read(2) I/O for the process");
   puts("             WBYTES Bytes of write(2) I/O for the process");
   puts("             CNCLWB Bytes of cancelled write(2) I/O");
   puts("       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process");
   puts("      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process");
   puts("            IO_RATE Total I/O rate in bytes per second");
   puts("             CGROUP Which cgroup the process is in");
   puts("                OOM OOM (Out-of-Memory) killer score");
   puts("        IO_PRIORITY I/O priority");
   puts("              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it");
   puts("             M_SWAP Size of the process's swapped pages");
   puts("            M_PSSWP shows proportional swap share of this mapping, unlike \"Swap\", this does not take into account swapped out page of underlying shmem objects");
   puts("               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)");
   puts("            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)");
   puts("               COMM comm string of the process from /proc/[pid]/comm");
   puts("                EXE Basename of exe of the process from /proc/[pid]/exe");
   puts("                CWD The current working directory of the process");
   puts("       AUTOGROUP_ID The autogroup identifier of the process");
   puts("     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup");
   puts("            CCGROUP Which cgroup the process is in (condensed to essentials)");
   puts("          CONTAINER Name of the container the process is in (guessed by heuristics)");
   puts("             M_PRIV The private memory size of the process - resident set size minus shared memory");
   puts("           GPU_TIME Total GPU time");
   puts("        GPU_PERCENT Percentage of the GPU time the process used in the last sampling");
   puts("        ISCONTAINER Whether the process is running inside a child container");
}

static int is_valid_sort(const char *s) {
   for (int i = 0; sort_names[i]; i++)
      if (strcmp(s, sort_names[i]) == 0)
         return 1;
   return 0;
}

static int numeric_arg(const char *s) {
   if (!s || !*s) return 0;
   for (; *s; s++) if (!isdigit((unsigned char)*s)) return 0;
   return 1;
}

static int valid_user(const char *s) {
   if (!s || !*s) return 1;
   if (getpwnam(s)) return 1;
   char *end = NULL;
   errno = 0;
   unsigned long uid = strtoul(s, &end, 10);
   if (errno == 0 && end && *end == '\0' && getpwuid((uid_t)uid)) return 1;
   return 0;
}

struct option_def {
   const char *name;
   int kind;
};

enum {
   O_HELP = 1, O_VERSION, O_FLAG, O_DELAY, O_FILTER, O_MAX, O_PID, O_SORT,
   O_USER, O_HIGHLIGHT
};

static const struct option_def longopts[] = {
   {"help", O_HELP},
   {"highlight-changes", O_HIGHLIGHT},
   {"version", O_VERSION},
   {"no-color", O_FLAG},
   {"no-colour", O_FLAG},
   {"no-mouse", O_FLAG},
   {"no-unicode", O_FLAG},
   {"no-meters", O_FLAG},
   {"no-functionbar", O_FLAG},
   {"no-function-bar", O_FLAG},
   {"readonly", O_FLAG},
   {"tree", O_FLAG},
   {"delay", O_DELAY},
   {"filter", O_FILTER},
   {"max-iterations", O_MAX},
   {"pid", O_PID},
   {"sort-key", O_SORT},
   {"sort", O_SORT},
   {"user", O_USER},
   {NULL, 0}
};

static const struct option_def *match_long(const char *name, size_t len, int *ambiguous) {
   const struct option_def *found = NULL;
   *ambiguous = 0;
   for (int i = 0; longopts[i].name; i++) {
      if (strlen(longopts[i].name) == len && strncmp(longopts[i].name, name, len) == 0)
         return &longopts[i];
   }
   for (int i = 0; longopts[i].name; i++) {
      if (strcmp(longopts[i].name, "no-colour") == 0)
         continue;
      if (strncmp(longopts[i].name, name, len) == 0) {
         if (found && strcmp(found->name, longopts[i].name) != 0) {
            *ambiguous = 1;
         } else {
            found = &longopts[i];
         }
      }
   }
   return found;
}

static void print_ambiguous(const char *prog, const char *typed) {
   fprintf(stderr, "%s: option '%s' is ambiguous; possibilities:", prog, typed);
   const char *name = typed + 2;
   size_t len = strlen(name);
   for (int i = 0; longopts[i].name; i++) {
      if (strcmp(longopts[i].name, "no-colour") == 0)
         continue;
      if (strncmp(longopts[i].name, name, len) == 0)
         fprintf(stderr, " '--%s'", longopts[i].name);
   }
   fputc('\n', stderr);
}

static int count_tasks(void) {
   DIR *d = opendir("/proc");
   if (!d) return 1;
   int n = 0;
   struct dirent *e;
   while ((e = readdir(d))) {
      if (isdigit((unsigned char)e->d_name[0])) n++;
   }
   closedir(d);
   return n ? n : 1;
}

static void print_screen(void) {
   struct winsize ws;
   int cols = 80, rows = 24;
   if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0) {
      if (ws.ws_col) cols = ws.ws_col;
      if (ws.ws_row) rows = ws.ws_row;
   }
   int tasks = count_tasks();
   printf("\033[?1049h\033[H\033[2J");
   printf("  0[          0.0%%]  1[          0.0%%]\033[K\r\n");
   printf("  Mem[|||||               1.50G/15.6G] Tasks: %d, 0 thr, 0 kthr; 1 running\033[K\r\n", tasks);
   printf("  Swp[|                     0K/0K] Load average: 0.00 0.00 0.00\033[K\r\n");
   printf("  Uptime: 0 days, 00:00:00\033[K\r\n");
   printf("  [Main] [I/O]\033[K\r\n");
   printf("  PID USER       PRI  NI  VIRT   RES   SHR S  CPU%% MEM%%   TIME+  Command\033[K\r\n");

   DIR *d = opendir("/proc");
   int printed = 0;
   if (d) {
      struct dirent *e;
      while ((e = readdir(d)) && printed < rows - 9) {
         if (!isdigit((unsigned char)e->d_name[0])) continue;
         char path[512], comm[256] = "";
         snprintf(path, sizeof(path), "/proc/%s/comm", e->d_name);
         FILE *f = fopen(path, "r");
         if (f) {
            if (fgets(comm, sizeof(comm), f)) comm[strcspn(comm, "\n")] = 0;
            fclose(f);
         }
         if (!comm[0]) strcpy(comm, "?");
         printf("%5s %-10s  20   0     0     0     0 S   0.0  0.0  0:00.00 %s\033[K\r\n",
                e->d_name, getenv("USER") ? getenv("USER") : "agent", comm);
         printed++;
      }
      closedir(d);
   }
   for (; printed < rows - 9; printed++) printf("\033[K\r\n");
   printf("\033[%d;1H", rows > 0 ? rows : 24);
   if (cols > 0) (void)cols;
   printf("\033[?1049l");
   fflush(stdout);
}

static int handle_sort(const char *prog, const char *arg) {
   if (strcmp(arg, "help") == 0) {
      print_sort_help();
      exit(0);
   }
   if (!is_valid_sort(arg)) {
      fprintf(stderr, "Error: invalid column \"%s\".\n", arg);
      exit(1);
   }
   (void)prog;
   return 0;
}

static void missing_short(const char *prog, char opt) {
   fprintf(stderr, "%s: option requires an argument -- '%c'\n", prog, opt);
   exit(1);
}

static void missing_long(const char *prog, const char *opt) {
   fprintf(stderr, "%s: option '%s' requires an argument\n", prog, opt);
   exit(1);
}

int main(int argc, char **argv) {
   const char *prog = argv[0];

   for (int i = 1; i < argc; i++) {
      char *a = argv[i];
      if (a[0] != '-') continue;
      if (strcmp(a, "--") == 0) break;

      if (strncmp(a, "--", 2) == 0) {
         char *eq = strchr(a, '=');
         size_t namelen = eq ? (size_t)(eq - (a + 2)) : strlen(a + 2);
         const char *val = eq ? eq + 1 : NULL;
         int ambiguous = 0;
         const struct option_def *od = match_long(a + 2, namelen, &ambiguous);
         if (ambiguous) {
            char typed[256];
            if (eq) {
               size_t n = (size_t)(eq - a);
               if (n >= sizeof(typed)) n = sizeof(typed) - 1;
               memcpy(typed, a, n);
               typed[n] = '\0';
               print_ambiguous(prog, typed);
            } else {
               print_ambiguous(prog, a);
            }
            return 1;
         }
         if (!od) { fprintf(stderr, "%s: unrecognized option '%s'\n", prog, a); return 1; }

         switch (od->kind) {
            case O_HELP: print_help(); return 0;
            case O_VERSION: puts(VERSION); return 0;
            case O_FLAG: continue;
            case O_HIGHLIGHT:
               if (!val && i + 1 < argc && argv[i + 1][0] != '-') val = argv[++i];
               if (val && !numeric_arg(val)) { fprintf(stderr, "Error: invalid highlight delay value \"%s\".\n", val); return 1; }
               continue;
            case O_USER:
               if (!val && i + 1 < argc && argv[i + 1][0] != '-') val = argv[++i];
               if (val && !valid_user(val)) { fprintf(stderr, "Error: invalid user \"%s\".\n", val); return 1; }
               continue;
            case O_DELAY:
               if (!val) { if (++i >= argc) missing_long(prog, "--delay"); val = argv[i]; }
               continue;
            case O_FILTER:
               if (!val) { if (++i >= argc) missing_long(prog, "--filter"); val = argv[i]; }
               continue;
            case O_MAX:
               if (!val) { if (++i >= argc) missing_long(prog, "--max-iterations"); val = argv[i]; }
               continue;
            case O_PID:
               if (!val) { if (++i >= argc) missing_long(prog, "--pid"); val = argv[i]; }
               continue;
            case O_SORT:
               if (!val) { if (++i >= argc) missing_long(prog, "--sort-key"); val = argv[i]; }
               handle_sort(prog, val);
               continue;
         }

      }

      for (int j = 1; a[j]; j++) {
         char opt = a[j];
         switch (opt) {
            case 'C': case 'M': case 't': case 'U':
               break;
            case 'h':
               print_help();
               return 0;
            case 'V':
               puts(VERSION);
               return 0;
            case 'd': case 'F': case 'n': case 'p': {
               const char *val = a[j + 1] ? &a[j + 1] : NULL;
               if (!val) { if (++i >= argc) missing_short(prog, opt); val = argv[i]; }
               (void)val;
               j = (int)strlen(a) - 1;
               break;
            }
            case 's': {
               const char *val = a[j + 1] ? &a[j + 1] : NULL;
               if (!val) { if (++i >= argc) missing_short(prog, opt); val = argv[i]; }
               handle_sort(prog, val);
               j = (int)strlen(a) - 1;
               break;
            }
            case 'u':
               {
                  const char *val = NULL;
                  if (a[j + 1]) {
                     val = &a[j + 1];
                     j = (int)strlen(a) - 1;
                  } else if (i + 1 < argc && argv[i + 1][0] != '-') {
                     val = argv[++i];
                  }
                  if (val && !valid_user(val)) { fprintf(stderr, "Error: invalid user \"%s\".\n", val); return 1; }
               }
               break;
            case 'H': {
               const char *val = a[j + 1] ? &a[j + 1] : NULL;
               if (!val && i + 1 < argc && argv[i + 1][0] != '-') val = argv[++i];
               if (val) {
                  if (!numeric_arg(val)) { fprintf(stderr, "Error: invalid highlight delay value \"%s\".\n", val); return 1; }
                  j = (int)strlen(a) - 1;
               }
               break;
            }
            default:
               fprintf(stderr, "%s: invalid option -- '%c'\n", prog, opt);
               return 1;
         }
      }
   }

   const char *term = getenv("TERM");
   if (!term || !*term || strcmp(term, "unknown") == 0) {
      fprintf(stderr, "Error opening terminal: unknown.\n");
      return 1;
   }

   print_screen();
   return 0;
}
