#!/usr/bin/env python3
import argparse
import html
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from xml.dom import minidom

VERSION = "xq version 1.4.0"


class XQParser(argparse.ArgumentParser):
    def error(self, message):
        if message.startswith("unrecognized arguments: "):
            arg = message.split(": ", 1)[1].split()[0]
            print(f"Error: unknown flag: {arg}", file=sys.stderr)
        elif "invalid int value" in message:
            m = re.search(r"argument (--?[\w-]+): invalid int value: '([^']+)'", message)
            if m:
                print(
                    f'Error: invalid argument "{m.group(2)}" for "{m.group(1)}" flag: '
                    f'strconv.ParseInt: parsing "{m.group(2)}": invalid syntax',
                    file=sys.stderr,
                )
            else:
                print("Error: " + message, file=sys.stderr)
        else:
            print("Error: " + message, file=sys.stderr)
        raise SystemExit(1)


def build_parser():
    p = XQParser(
        prog="xq",
        add_help=False,
        usage=argparse.SUPPRESS,
        description=argparse.SUPPRESS,
    )
    p.add_argument("file", nargs="?")
    p.add_argument("-a", "--attr")
    p.add_argument("-c", "--color", action="store_true")
    p.add_argument("--compact", action="store_true")
    p.add_argument("-d", "--depth", type=int, default=-1)
    p.add_argument("-e", "--extract")
    p.add_argument("-h", "--help", action="store_true")
    p.add_argument("-m", "--html", action="store_true", dest="html_mode")
    p.add_argument("-i", "--in-place", action="store_true", dest="in_place")
    p.add_argument("--indent", type=int, default=2)
    p.add_argument("-j", "--json", action="store_true", dest="json_mode")
    p.add_argument("--no-color", action="store_true")
    p.add_argument("-n", "--node", action="store_true")
    p.add_argument("-q", "--query")
    p.add_argument("--tab", action="store_true")
    p.add_argument("-v", "--version", action="store_true")
    p.add_argument("-x", "--xpath")
    return p


HELP = """Command-line XML and HTML beautifier and content extractor

Usage:
  xq [flags]

Flags:
  -a, --attr string      Extract an attribute value instead of node content for provided CSS query
  -c, --color            Force colorful output
      --compact          Compact JSON output (no indentation)
  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)
  -e, --extract string   Extract a single node from XML
  -h, --help             Print this help message
  -m, --html             Use HTML formatter
  -i, --in-place         Format file in place
      --indent int       Use the given number of spaces for indentation (default 2)
  -j, --json             Output the result as JSON
      --no-color         Disable colorful output
  -n, --node             Return the node content instead of text
  -q, --query string     Extract the node(s) using CSS selector
      --tab              Use tabs for indentation
  -v, --version          Print version information
  -x, --xpath string     Extract the node(s) from XML
"""


def read_input(path):
    if path:
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except OSError as e:
            print(f"Error: open {path}: {e.strerror.lower()}", file=sys.stderr)
            sys.exit(1)
    return sys.stdin.read()


def unit(args):
    return "\t" if args.tab else " " * args.indent


def text_of(elem):
    return "".join(elem.itertext()).strip()


def strip_ns(tag):
    return tag.split("}", 1)[-1] if "}" in tag else tag


def parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError as e:
        print(f"Error: XML syntax error on line {getattr(e, 'position', (1, 0))[0]}: {e.msg}", file=sys.stderr)
        sys.exit(1)


def serialize_elem(elem):
    return ET.tostring(elem, encoding="unicode", short_empty_elements=True)


def simple_xpath(root, expr):
    expr = expr.strip()
    attr = None
    if "/@" in expr:
        expr, attr = expr.rsplit("/@", 1)
    pred = re.search(r"\[@([^=\]]+)=['\"]([^'\"]+)['\"]\]$", expr)
    pred_attr = pred_val = None
    if pred:
        pred_attr, pred_val = pred.group(1), pred.group(2)
        expr = expr[: pred.start()]
    if expr.startswith("//"):
        tag = expr[2:] or "*"
        found = [e for e in root.iter() if tag == "*" or strip_ns(e.tag) == tag]
    elif expr.startswith("/"):
        parts = [p for p in expr.split("/") if p]
        found = [root]
        if parts and strip_ns(root.tag) == parts[0]:
            parts = parts[1:]
        for part in parts:
            nxt = []
            for e in found:
                nxt.extend([c for c in list(e) if part == "*" or strip_ns(c.tag) == part])
            found = nxt
    else:
        try:
            found = root.findall(expr)
        except SyntaxError:
            found = []
    if pred_attr:
        found = [e for e in found if e.attrib.get(pred_attr) == pred_val]
    if attr is not None:
        return [e.attrib.get(attr, "") for e in found if attr in e.attrib], True
    return found, False


class Node:
    def __init__(self, tag, attrs=None, parent=None):
        self.tag = tag
        self.attrs = attrs or {}
        self.children = []
        self.text = ""
        self.parent = parent


class HTMLTree(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.root = Node("__root__")
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        n = Node(tag.lower(), dict(attrs), self.stack[-1])
        self.stack[-1].children.append(n)
        self.stack.append(n)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(Node(tag.lower(), dict(attrs), self.stack[-1]))

    def handle_endtag(self, tag):
        tag = tag.lower()
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        self.stack[-1].text += data

    def handle_entityref(self, name):
        self.stack[-1].text += "&" + name + ";"

    def handle_charref(self, name):
        self.stack[-1].text += "&#" + name + ";"


def node_text(n):
    parts = [html.unescape(n.text.strip())] if n.text.strip() else []
    for c in n.children:
        t = node_text(c)
        if t:
            parts.append(t)
    return " ".join(parts).strip()


def serialize_html_node(n, depth=0, ind="  "):
    attrs = "".join(f' {k}="{html.escape(v, quote=True)}"' for k, v in n.attrs.items())
    if not n.children and not n.text.strip():
        return f"{ind*depth}<{n.tag}{attrs}></{n.tag}>"
    if not n.children:
        return f"{ind*depth}<{n.tag}{attrs}>{html.escape(html.unescape(n.text.strip()))}</{n.tag}>"
    prefix = f"{ind*depth}<{n.tag}{attrs}>"
    if n.text.strip():
        prefix += html.escape(html.unescape(n.text.strip()))
    lines = [prefix]
    for c in n.children:
        lines.append(serialize_html_node(c, depth + 1, ind))
    lines.append(f"{ind*depth}</{n.tag}>")
    return "\n".join(lines)


def parse_selector(s):
    toks = []
    for part in re.split(r"(\s*>\s*|\s+)", s.strip()):
        if not part or part.isspace():
            continue
        if ">" in part:
            toks.append(">")
        else:
            toks.append(part.strip())
    seq = []
    rel = "desc"
    for t in toks:
        if t == ">":
            rel = "child"
        else:
            seq.append((rel, t))
            rel = "desc"
    return seq


def match_simple(n, token):
    m = re.match(r"^([a-zA-Z0-9_-]|\*)*", token)
    tag = m.group(0) if m else ""
    rest = token[len(tag):]
    if tag and tag != "*" and n.tag != tag.lower():
        return False
    for cls in re.findall(r"\.([a-zA-Z0-9_-]+)", rest):
        if cls not in n.attrs.get("class", "").split():
            return False
    ident = re.search(r"#([a-zA-Z0-9_-]+)", rest)
    if ident and n.attrs.get("id") != ident.group(1):
        return False
    for a, v in re.findall(r"\[([a-zA-Z0-9_-]+)(?:=['\"]?([^'\"]+)['\"]?)?\]", rest):
        if a not in n.attrs:
            return False
        if v and n.attrs.get(a) != v:
            return False
    return True


def descendants(n):
    for c in n.children:
        yield c
        yield from descendants(c)


def css_select(root, selector):
    current = [root]
    for rel, token in parse_selector(selector):
        cand = []
        for n in current:
            pool = n.children if rel == "child" else descendants(n)
            cand.extend([x for x in pool if match_simple(x, token)])
        current = cand
    return current


def format_xml(data, args):
    try:
        dom = minidom.parseString(data.encode("utf-8"))
        out = dom.toprettyxml(indent=unit(args))
        lines = [ln for ln in out.splitlines() if ln.strip()]
        if lines and lines[0] == "<?xml version=\"1.0\" ?>":
            if data.lstrip().startswith("<?xml"):
                lines[0] = re.match(r"\s*(<\?xml[^?]*\?>)", data, re.S).group(1)
            else:
                lines = lines[1:]
        out = "\n".join(lines) + "\n"
        out = out.replace(" />", "/>")
        return out
    except Exception:
        root = parse_xml(data)
        return serialize_elem(root) + "\n"


def elem_to_obj(e, depth=-1):
    if depth == 0:
        return None
    children = list(e)
    attrs = e.attrib
    txt = (e.text or "").strip()
    if not children and not attrs:
        return txt
    obj = {}
    if txt:
        obj["#text"] = txt
    for k, v in attrs.items():
        obj["@" + k] = v
    groups = {}
    for c in children:
        groups.setdefault(strip_ns(c.tag), []).append(c)
    nd = depth - 1 if depth > 0 else depth
    for k, vals in groups.items():
        converted = [elem_to_obj(v, nd) for v in vals]
        obj[k] = converted if len(converted) > 1 else converted[0]
    return obj


def main():
    args = build_parser().parse_args()
    if args.help:
        print(HELP, end="")
        return 0
    if args.version:
        print(VERSION)
        return 0
    data = read_input(args.file)
    if args.query:
        hp = HTMLTree(); hp.feed(data)
        nodes = css_select(hp.root, args.query)
        vals = []
        for n in nodes:
            if args.attr:
                if args.attr in n.attrs:
                    vals.append(n.attrs[args.attr])
            elif args.node:
                vals.append(serialize_html_node(n, 0, unit(args)))
            else:
                vals.append(node_text(n))
        if vals:
            print("\n".join(vals))
        return 0
    if args.xpath or args.extract:
        root = parse_xml(data)
        vals, is_attr = simple_xpath(root, args.xpath or args.extract)
        if args.extract and vals:
            vals = vals[:1]
        out = []
        for v in vals:
            if is_attr:
                out.append(v)
            elif args.node:
                out.append(serialize_elem(v))
            else:
                out.append(text_of(v))
        if out:
            print("\n".join(out))
        return 0
    if args.json_mode:
        root = parse_xml(data)
        obj = {strip_ns(root.tag): elem_to_obj(root, args.depth)}
        if args.compact:
            print(json.dumps(obj, ensure_ascii=False, separators=(",", ": ")))
        else:
            print(json.dumps(obj, ensure_ascii=False, indent=2))
        return 0
    if args.html_mode:
        hp = HTMLTree(); hp.feed(data)
        out = "\n".join(serialize_html_node(c, 0, unit(args)) for c in hp.root.children) + "\n"
    else:
        out = format_xml(data, args)
    if args.in_place and args.file:
        with open(args.file, "w", encoding="utf-8") as f:
            f.write(out)
    else:
        sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
