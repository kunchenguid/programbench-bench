#include <errno.h>
#include <getopt.h>
#include <stddef.h>
#include <stdio.h>
#include <jpeglib.h>
#include <setjmp.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>

typedef struct {
  unsigned char r, g, b;
} Pixel;

typedef struct {
  int width, height, comps;
  Pixel *px;
} Image;

typedef struct {
  struct jpeg_error_mgr pub;
  jmp_buf setjmp_buffer;
  char msg[JMSG_LENGTH_MAX];
} JpegError;

typedef struct {
  int out_w, out_h;
  bool have_w, have_h, size_set;
  bool border, invert, flipx, flipy, html, html_raw, colors, fill, grayscale;
  bool clear, verbose, debug, no_bold;
  int html_fontsize;
  char *html_title;
  char *output;
  char *chars;
  double rw, gw, bw;
  bool term_fit, term_width, term_height, term_zoom;
} Opt;

static void jpeg_error_exit(j_common_ptr cinfo) {
  JpegError *err = (JpegError *)cinfo->err;
  (*cinfo->err->format_message)(cinfo, err->msg);
  longjmp(err->setjmp_buffer, 1);
}

static void die(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vfprintf(stderr, fmt, ap);
  va_end(ap);
  fputc('\n', stderr);
  exit(1);
}

static void print_version(void) {
  puts("jp2a 1.0.8");
  puts("Copyright 2006-2016 Christian Stigen Larsen");
  puts("Distributed under the GNU General Public License (GPL) v2.");
}

static void print_help(void) {
  print_version();
  puts("");
  puts("Usage: jp2a [ options ] [ file(s) | URL(s) ]");
  puts("");
  puts("Convert files or URLs from JPEG format to ASCII.");
  puts("");
  puts("OPTIONS");
  puts("  -                 Read images from standard input.");
  puts("      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145");
  puts("  -b, --border      Print a border around the output image.");
  puts("      --chars=...   Select character palette used to paint the image.");
  puts("                    Leftmost character corresponds to black pixel, right-");
  puts("                    most to white.  Minimum two characters must be specified.");
  puts("      --clear       Clears screen before drawing each output image.");
  puts("      --colors      Use ANSI colors in output.");
  puts("  -d, --debug       Print additional debug information.");
  puts("      --fill        When used with --color and/or --html, color each character's");
  puts("                    background color.");
  puts("  -x, --flipx       Flip image in X direction.");
  puts("  -y, --flipy       Flip image in Y direction.");
  puts("  -f, --term-fit    Use the largest image dimension that fits in your terminal");
  puts("                    display with correct aspect ratio.");
  puts("      --term-height Use terminal display height.");
  puts("      --term-width  Use terminal display width.");
  puts("  -z, --term-zoom   Use terminal display dimension for output.");
  puts("      --grayscale   Convert image to grayscale when using --html or --colors");
  puts("      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866");
  puts("      --height=N    Set output height, calculate width from aspect ratio.");
  puts("  -h, --help        Print program help.");
  puts("      --html        Produce strict XHTML 1.0 output.");
  puts("      --html-fill   Same as --fill (will be phased out)");
  puts("      --html-fontsize=N   Set fontsize to N pt, default is 4.");
  puts("      --html-no-bold      Do not use bold characters with HTML output");
  puts("      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.");
  puts("      --html-title=...  Set HTML output title");
  puts("  -i, --invert      Invert output image.  Use if your display has a dark");
  puts("                    background.");
  puts("      --background=dark   These are just mnemonics whether to use --invert");
  puts("      --background=light  or not.  If your console has light characters on");
  puts("                    a dark background, use --background=dark.");
  puts("      --output=...  Write output to file.");
  puts("      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.");
  puts("      --size=WxH    Set output width and height.");
  puts("  -v, --verbose     Verbose output.");
  puts("  -V, --version     Print program version.");
  puts("      --width=N     Set output width, calculate height from ratio.");
  puts("");
  puts("  The default mode is `jp2a --term-fit --background=dark'.");
  puts("  See the man-page for jp2a for more detailed help text.");
  puts("");
  puts("Project homepage on https://github.com/cslarsen/jp2a");
  puts("Report bugs to <csl@csl.name>");
}

static void init_opt(Opt *o) {
  memset(o, 0, sizeof(*o));
  o->chars = strdup("   ...',;:clodxkO0KXNWM");
  o->rw = 0.2989;
  o->gw = 0.5866;
  o->bw = 0.1145;
  o->html_fontsize = 4;
  o->html_title = strdup("jp2a converted image");
  o->term_fit = true;
}

static int parse_int(const char *s) {
  char *e = NULL;
  long v = strtol(s, &e, 10);
  if (!s[0] || *e || v <= 0 || v > 100000) return -1;
  return (int)v;
}

static void parse_size(Opt *o, const char *s) {
  char *x = strchr(s, 'x');
  if (!x) x = strchr(s, 'X');
  if (!x) {
    fprintf(stderr, "Unknown option --size=%s\n\n", s);
    print_help();
    exit(1);
  }
  char a[64], b[64];
  size_t n = (size_t)(x - s);
  if (n >= sizeof(a) || strlen(x + 1) >= sizeof(b)) exit(1);
  memcpy(a, s, n);
  a[n] = 0;
  strcpy(b, x + 1);
  int w = parse_int(a), h = parse_int(b);
  if (w < 1 || h < 1) {
    fprintf(stderr, "Unknown option --size=%s\n\n", s);
    print_help();
    exit(1);
  }
  o->out_w = w;
  o->out_h = h;
  o->have_w = o->have_h = o->size_set = true;
  o->term_fit = o->term_width = o->term_height = o->term_zoom = false;
}

static void parse_args(Opt *o, int argc, char **argv, int *first_file) {
  enum {
    OPT_BLUE = 1000, OPT_CHARS, OPT_CLEAR, OPT_COLORS, OPT_FILL, OPT_TERM_HEIGHT,
    OPT_TERM_WIDTH, OPT_GRAYSCALE, OPT_GREEN, OPT_HTML, OPT_HTML_FILL,
    OPT_HTML_FONTSIZE, OPT_HTML_NO_BOLD, OPT_HTML_RAW, OPT_HTML_TITLE,
    OPT_BACKGROUND, OPT_OUTPUT, OPT_RED, OPT_SIZE, OPT_WIDTH, OPT_HEIGHT
  };
  static struct option opts[] = {
      {"blue", required_argument, 0, OPT_BLUE},
      {"border", no_argument, 0, 'b'},
      {"chars", required_argument, 0, OPT_CHARS},
      {"clear", no_argument, 0, OPT_CLEAR},
      {"colors", no_argument, 0, OPT_COLORS},
      {"color", no_argument, 0, OPT_COLORS},
      {"debug", no_argument, 0, 'd'},
      {"fill", no_argument, 0, OPT_FILL},
      {"flipx", no_argument, 0, 'x'},
      {"flipy", no_argument, 0, 'y'},
      {"term-fit", no_argument, 0, 'f'},
      {"term-height", no_argument, 0, OPT_TERM_HEIGHT},
      {"term-width", no_argument, 0, OPT_TERM_WIDTH},
      {"term-zoom", no_argument, 0, 'z'},
      {"zoom", no_argument, 0, 'z'},
      {"grayscale", no_argument, 0, OPT_GRAYSCALE},
      {"green", required_argument, 0, OPT_GREEN},
      {"height", required_argument, 0, OPT_HEIGHT},
      {"help", no_argument, 0, 'h'},
      {"html", no_argument, 0, OPT_HTML},
      {"html-fill", no_argument, 0, OPT_HTML_FILL},
      {"html-fontsize", required_argument, 0, OPT_HTML_FONTSIZE},
      {"html-no-bold", no_argument, 0, OPT_HTML_NO_BOLD},
      {"html-raw", no_argument, 0, OPT_HTML_RAW},
      {"html-title", required_argument, 0, OPT_HTML_TITLE},
      {"invert", no_argument, 0, 'i'},
      {"background", required_argument, 0, OPT_BACKGROUND},
      {"output", required_argument, 0, OPT_OUTPUT},
      {"red", required_argument, 0, OPT_RED},
      {"size", required_argument, 0, OPT_SIZE},
      {"verbose", no_argument, 0, 'v'},
      {"version", no_argument, 0, 'V'},
      {"width", required_argument, 0, OPT_WIDTH},
      {0, 0, 0, 0}};
  opterr = 0;
  int c;
  while ((c = getopt_long(argc, argv, "bdxfzyhiVv", opts, NULL)) != -1) {
    switch (c) {
    case 'b': o->border = true; break;
    case 'd': o->debug = true; break;
    case 'x': o->flipx = true; break;
    case 'y': o->flipy = true; break;
    case 'f': o->term_fit = true; o->term_width = o->term_height = o->term_zoom = false; break;
    case 'z': o->term_zoom = true; o->term_fit = o->term_width = o->term_height = false; break;
    case 'h': print_help(); exit(0);
    case 'i': o->invert = true; break;
    case 'V': print_version(); exit(0);
    case 'v': o->verbose = true; break;
    case OPT_BLUE: o->bw = atof(optarg); break;
    case OPT_GREEN: o->gw = atof(optarg); break;
    case OPT_RED: o->rw = atof(optarg); break;
    case OPT_CHARS:
      free(o->chars);
      o->chars = strdup(optarg);
      break;
    case OPT_CLEAR: o->clear = true; break;
    case OPT_COLORS: o->colors = true; break;
    case OPT_FILL:
    case OPT_HTML_FILL: o->fill = true; break;
    case OPT_TERM_HEIGHT: o->term_height = true; o->term_fit = o->term_width = o->term_zoom = false; break;
    case OPT_TERM_WIDTH: o->term_width = true; o->term_fit = o->term_height = o->term_zoom = false; break;
    case OPT_GRAYSCALE: o->grayscale = true; break;
    case OPT_HEIGHT:
      o->out_h = parse_int(optarg);
      if (o->out_h < 1) die("Invalid height");
      o->have_h = true; o->term_fit = o->term_width = o->term_height = o->term_zoom = false;
      break;
    case OPT_WIDTH:
      o->out_w = parse_int(optarg);
      if (o->out_w < 1) die("Invalid width");
      o->have_w = true; o->term_fit = o->term_width = o->term_height = o->term_zoom = false;
      break;
    case OPT_HTML: o->html = true; break;
    case OPT_HTML_FONTSIZE: o->html_fontsize = parse_int(optarg); if (o->html_fontsize < 1) o->html_fontsize = 4; break;
    case OPT_HTML_NO_BOLD: o->no_bold = true; break;
    case OPT_HTML_RAW: o->html = true; o->html_raw = true; break;
    case OPT_HTML_TITLE: free(o->html_title); o->html_title = strdup(optarg); break;
    case OPT_BACKGROUND:
      if (strcmp(optarg, "dark") == 0) o->invert = true;
      else if (strcmp(optarg, "light") == 0) o->invert = false;
      else die("Unknown background: %s", optarg);
      break;
    case OPT_OUTPUT: o->output = strdup(optarg); break;
    case OPT_SIZE: parse_size(o, optarg); break;
    case '?':
    default:
      if (argv[optind - 1])
        fprintf(stderr, "Unknown option %s\n\n", argv[optind - 1]);
      print_help();
      exit(1);
    }
  }
  if (strlen(o->chars) < 2) {
    fprintf(stderr, "Character palette must contain at least two characters\n");
    exit(1);
  }
  *first_file = optind;
}

static Image read_jpeg(FILE *fp) {
  Image img = {0, 0, 0, NULL};
  struct jpeg_decompress_struct cinfo;
  JpegError jerr;
  cinfo.err = jpeg_std_error(&jerr.pub);
  jerr.pub.error_exit = jpeg_error_exit;
  if (setjmp(jerr.setjmp_buffer)) {
    jpeg_destroy_decompress(&cinfo);
    die("%s", jerr.msg);
  }
  jpeg_create_decompress(&cinfo);
  jpeg_stdio_src(&cinfo, fp);
  jpeg_read_header(&cinfo, TRUE);
  jpeg_start_decompress(&cinfo);
  img.width = (int)cinfo.output_width;
  img.height = (int)cinfo.output_height;
  img.comps = (int)cinfo.output_components;
  img.px = calloc((size_t)img.width * img.height, sizeof(Pixel));
  if (!img.px) die("Out of memory");
  int stride = img.width * img.comps;
  JSAMPARRAY buf = (*cinfo.mem->alloc_sarray)((j_common_ptr)&cinfo, JPOOL_IMAGE, stride, 1);
  while (cinfo.output_scanline < cinfo.output_height) {
    int y = (int)cinfo.output_scanline;
    jpeg_read_scanlines(&cinfo, buf, 1);
    for (int x = 0; x < img.width; x++) {
      Pixel *p = &img.px[(size_t)y * img.width + x];
      if (img.comps == 1) {
        p->r = p->g = p->b = buf[0][x];
      } else {
        p->r = buf[0][x * img.comps + 0];
        p->g = buf[0][x * img.comps + 1];
        p->b = buf[0][x * img.comps + 2];
      }
    }
  }
  jpeg_finish_decompress(&cinfo);
  jpeg_destroy_decompress(&cinfo);
  return img;
}

static void terminal_size(int *w, int *h) {
  struct winsize ws;
  if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == 0 && ws.ws_col > 0 && ws.ws_row > 0) {
    *w = ws.ws_col;
    *h = ws.ws_row;
    return;
  }
  char *cw = getenv("COLUMNS"), *ch = getenv("LINES");
  if (cw && ch) {
    int a = parse_int(cw), b = parse_int(ch);
    if (a > 0 && b > 0) {
      *w = a; *h = b; return;
    }
  }
  if (!getenv("TERM")) die("Environment variable TERM not set.");
  *w = 80;
  *h = 24;
}

static void decide_size(Opt *o, const Image *img) {
  int tw = 80, th = 24;
  if (o->term_fit || o->term_width || o->term_height || o->term_zoom)
    terminal_size(&tw, &th);
  if (o->term_zoom) {
    o->out_w = tw;
    o->out_h = th;
  } else if (o->term_width) {
    o->out_w = tw;
    o->out_h = (int)(0.5 + (double)o->out_w * img->height / img->width * 0.5);
  } else if (o->term_height) {
    o->out_h = th;
    o->out_w = (int)(0.5 + (double)o->out_h * img->width / img->height * 2.0);
  } else if (o->term_fit) {
    int by_w_h = (int)((double)tw * img->height / img->width * 0.5);
    int by_h_w = (int)((double)th * img->width / img->height * 2.0);
    if (by_w_h <= th) {
      o->out_w = tw;
      o->out_h = by_w_h > 0 ? by_w_h : 1;
    } else {
      o->out_h = th;
      o->out_w = by_h_w > 0 ? by_h_w : 1;
    }
  } else if (o->have_w && !o->have_h) {
    o->out_h = (int)((double)o->out_w * img->height / img->width * 0.5);
    if (o->out_h < 1) o->out_h = 1;
  } else if (o->have_h && !o->have_w) {
    o->out_w = (int)((double)o->out_h * img->width / img->height * 2.0);
    if (o->out_w < 1) o->out_w = 1;
  } else if (!o->have_w && !o->have_h) {
    o->out_w = img->width;
    o->out_h = img->height / 2;
    if (o->out_h < 1) o->out_h = 1;
  }
}

static int luminance(const Opt *o, Pixel p) {
  int v = (int)(o->rw * p.r + o->gw * p.g + o->bw * p.b);
  if (v < 0) v = 0;
  if (v > 255) v = 255;
  if (o->invert) v = 255 - v;
  return v;
}

static Pixel sample_cell(const Opt *o, const Image *img, int ox, int oy) {
  int x0 = (int)((long long)ox * img->width / o->out_w);
  int x1 = (int)((long long)(ox + 1) * img->width / o->out_w);
  int sy = (int)((long long)oy * img->height / o->out_h);
  if (x1 <= x0) x1 = x0 + 1;
  if (x1 > img->width) x1 = img->width;
  if (sy >= img->height) sy = img->height - 1;
  if (o->flipy) sy = img->height - 1 - sy;
  long sr = 0, sg = 0, sb = 0, count = 0;
  for (int x = x0; x < x1; x++) {
    int sx = o->flipx ? img->width - 1 - x : x;
    Pixel p = img->px[(size_t)sy * img->width + sx];
    sr += p.r; sg += p.g; sb += p.b; count++;
  }
  Pixel p;
  p.r = (unsigned char)(sr / count);
  p.g = (unsigned char)(sg / count);
  p.b = (unsigned char)(sb / count);
  return p;
}

static void html_escape_char(FILE *out, char c) {
  if (c == '<') fputs("&lt;", out);
  else if (c == '>') fputs("&gt;", out);
  else if (c == '&') fputs("&amp;", out);
  else if (c == '"') fputs("&quot;", out);
  else fputc(c, out);
}

static void emit_text(FILE *out, const Opt *o, const Image *img) {
  int n = (int)strlen(o->chars);
  if (o->border) {
    fputc('+', out);
    for (int i = 0; i < o->out_w; i++) fputc('-', out);
    fputs("+\n", out);
  }
  for (int oy = 0; oy < o->out_h; oy++) {
    if (o->border) fputc('|', out);
    for (int ox = 0; ox < o->out_w; ox++) {
      Pixel p = sample_cell(o, img, ox, oy);
      int v = luminance(o, p);
      int ci = (int)((long long)v * n / 256);
      if (ci >= n) ci = n - 1;
      char ch = o->chars[ci];
      if (o->colors && !o->grayscale) {
        int fg_r = o->fill ? p.r / 2 : p.r;
        int fg_g = o->fill ? p.g / 2 : p.g;
        int fg_b = o->fill ? p.b / 2 : p.b;
        if (o->fill)
          fprintf(out, "\033[38;2;%d;%d;%dm\033[48;2;%d;%d;%dm%c", fg_r, fg_g, fg_b, p.r, p.g, p.b, ch);
        else
          fprintf(out, "\033[38;2;%d;%d;%dm%c", fg_r, fg_g, fg_b, ch);
      } else {
        fputc(ch, out);
      }
    }
    if (o->colors && !o->grayscale) fputs("\033[0m", out);
    if (o->border) fputc('|', out);
    fputc('\n', out);
  }
  if (o->border) {
    fputc('+', out);
    for (int i = 0; i < o->out_w; i++) fputc('-', out);
    fputs("+\n", out);
  }
}

static void emit_html(FILE *out, const Opt *o, const Image *img) {
  int n = (int)strlen(o->chars);
  if (!o->html_raw) {
    fputs("<?xml version='1.0' encoding='ISO-8859-1'?>\n", out);
    fputs("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n", out);
    fputs("<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>\n<head>\n<title>", out);
    fputs(o->html_title, out);
    fputs("</title>\n<style type='text/css'>\nbody {\n", out);
    fprintf(out, "background-color: %s;\n}\n.ascii {\n   font-family: Courier;\n", o->invert ? "white" : "black");
    if (!o->colors) fprintf(out, "   color: %s;\n", o->invert ? "black" : "white");
    fprintf(out, "   font-size:%dpt;\n", o->html_fontsize * 2);
    if (!o->no_bold) fputs("   font-weight: bold;\n", out);
    fputs("}\n</style>\n</head>\n<body>\n<div class='ascii'><pre>\n", out);
  }
  for (int oy = 0; oy < o->out_h; oy++) {
    for (int ox = 0; ox < o->out_w; ox++) {
      Pixel p = sample_cell(o, img, ox, oy);
      int v = luminance(o, p);
      int ci = (int)((long long)v * n / 256);
      if (ci >= n) ci = n - 1;
      char ch = o->chars[ci];
      if (o->colors && !o->grayscale) {
        int fg_r = o->fill ? p.r / 2 : p.r;
        int fg_g = o->fill ? p.g / 2 : p.g;
        int fg_b = o->fill ? p.b / 2 : p.b;
        fprintf(out, "<span style='color:#%02x%02x%02x;", fg_r, fg_g, fg_b);
        if (o->fill) fprintf(out, " background-color:#%02x%02x%02x;", p.r, p.g, p.b);
        fputs("'>", out);
        html_escape_char(out, ch);
        fputs("</span>", out);
      } else {
        html_escape_char(out, ch);
      }
    }
    if (o->colors && !o->grayscale) fputs("<br/>", out);
    fputc('\n', out);
  }
  if (!o->html_raw) fputs("</pre>\n</div>\n</body>\n</html>\n", out);
}

static FILE *open_input(const char *name) {
  if (strcmp(name, "-") == 0) return stdin;
  if (strncmp(name, "file://", 7) == 0) name += 7;
  FILE *fp = fopen(name, "rb");
  if (!fp) fprintf(stderr, "%s: %s\n", name, strerror(errno));
  return fp;
}

int main(int argc, char **argv) {
  Opt opt;
  init_opt(&opt);
  int first = 1;
  parse_args(&opt, argc, argv, &first);
  FILE *out = stdout;
  if (opt.output && strcmp(opt.output, "-") != 0) {
    out = fopen(opt.output, "wb");
    if (!out) die("%s: %s", opt.output, strerror(errno));
  }
  if (opt.clear) fputs("\033[H\033[J", out);
  int files = argc - first;
  if (files == 0) {
    fprintf(stderr, "No files specified.\n\n");
    print_help();
    return 1;
  }
  int rc = 0;
  for (int i = first; i < argc; i++) {
    const char *name = argv[i];
    FILE *fp = open_input(name);
    if (!fp) { rc = 1; continue; }
    Image img = read_jpeg(fp);
    if (fp != stdin) fclose(fp);
    Opt cur = opt;
    decide_size(&cur, &img);
    if (opt.verbose) {
      fprintf(stderr, "File: %s\n", name);
      fprintf(stderr, "Source width: %d\nSource height: %d\nSource color components: %d\n", img.width, img.height, img.comps);
      fprintf(stderr, "Output width: %d\nOutput height: %d\n", cur.out_w, cur.out_h);
      fprintf(stderr, "Output palette (%zu chars): '%s'\n", strlen(cur.chars), cur.chars);
    }
    if (cur.html) emit_html(out, &cur, &img);
    else emit_text(out, &cur, &img);
    free(img.px);
  }
  if (out != stdout) fclose(out);
  return rc;
}
