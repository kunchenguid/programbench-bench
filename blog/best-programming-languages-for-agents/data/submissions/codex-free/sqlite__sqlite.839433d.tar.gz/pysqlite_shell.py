#!/usr/bin/env python3
import csv
import html
import io
import json
import os
import shlex
import sqlite3
import sys
import time

VERSION = "3.54.0"
SOURCE_DATE = "2026-04-14 20:02:49"
SOURCE_HASH = "49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b"
VERSION_LINE = f"{VERSION} {SOURCE_DATE} {SOURCE_HASH} (64-bit)"

HELP = """Usage: ./executable [OPTIONS] [FILENAME [SQL...]]
FILENAME is the name of an SQLite database. A new database is created
if the file does not previously exist. Defaults to :memory:.
OPTIONS include:
   --                   treat no subsequent arguments as options
   -A ARGS...           run ".archive ARGS" and exit
   -append              append the database to the end of the file
   -ascii               set output mode to 'ascii'
   -bail                stop after hitting an error
   -batch               force batch I/O
   -box                 set output mode to 'box'
   -cmd COMMAND         run "COMMAND" before reading stdin
   -column              set output mode to 'column'
   -csv                 set output mode to 'csv'
   -deserialize         open the database using sqlite3_deserialize()
   -echo                print inputs before execution
   -escape T            ctrl-char escape; T is one of: symbol, ascii, off
   -init FILENAME       read/process named file
   -[no]header          turn headers on or off
   -help                show this message
   -html                set output mode to HTML
   -ifexists            only open if database already exists
   -interactive         force interactive I/O
   -json                set output mode to 'json'
   -line                set output mode to 'line'
   -list                set output mode to 'list'
   -lookaside SIZE N    use N entries of SZ bytes for lookaside memory
   -markdown            set output mode to 'markdown'
   -maxsize N           maximum size for a --deserialize database
   -memtrace            trace all memory allocations and deallocations
   -mmap N              default mmap size set to N
   -newline SEP         set output row separator. Default: '\\n'
   -nofollow            refuse to open symbolic links to database files
   -noinit              Do not read the ~/.sqliterc file at startup
   -nonce STRING        set the safe-mode escape nonce
   -no-rowid-in-view    Disable rowid-in-view using sqlite3_config()
   -nullvalue TEXT      set text string for NULL values. Default ''
   -pagecache SIZE N    use N slots of SZ bytes each for page cache memory
   -pcachetrace         trace all page cache operations
   -quote               set output mode to 'quote'
   -readonly            open the database read-only
   -safe                enable safe-mode
   -screenwidth N       use N as the default screenwidth 
   -separator SEP       set output column separator. Default: '|'
   -stats               print memory stats before each finalize
   -table               set output mode to 'table'
   -tabs                set output mode to 'tabs'
   -unsafe-testing      allow unsafe commands and modes for testing
   -version             show SQLite version
   -vfs NAME            use NAME as the default VFS
   -vfstrace            enable tracing of all VFS calls
   -zip                 open the file as a ZIP Archive"""

DOT_HELP = """.archive ...             Manage SQL archives
.auth ON|OFF             Show authorizer callbacks
.backup ?DB? FILE        Backup DB (default "main") to FILE
.bail on|off             Stop after hitting an error.  Default OFF
.cd DIRECTORY            Change the working directory to DIRECTORY
.changes on|off          Show number of rows changed by SQL
.clone NEWDB             Clone data into NEWDB from the existing database
.connection [close] [#]  Open or close an auxiliary database connection
.crlf ?on|off?           Whether or not to use \\r\\n line endings
.databases               List names and files of attached databases
.dbconfig ?op? ?val?     List or change sqlite3_db_config() options
.dbinfo ?DB?             Show status information about the database
.dbtotxt                 Hex dump of the database file
.dump ?OBJECTS?          Render database content as SQL
.echo on|off             Turn command echo on or off
.eqp on|off|full|...     Enable or disable automatic EXPLAIN QUERY PLAN
.excel                   Display the output of next command in spreadsheet
.exit ?CODE?             Exit this program with return-code CODE
.expert                  EXPERIMENTAL. Suggest indexes for queries
.explain ?on|off|auto?   Change the EXPLAIN formatting mode.  Default: auto
.filectrl CMD ...        Run various sqlite3_file_control() operations
.fullschema ?--indent?   Show schema and the content of sqlite_stat tables
.headers on|off          Turn display of headers on or off
.help ?-all? ?PATTERN?   Show help text for PATTERN
.import FILE TABLE       Import data from FILE into TABLE
.imposter INDEX TABLE    Create imposter table TABLE on index INDEX
.indexes ?PATTERN?       Show names of indexes matching PATTERN
.intck ?STEPS_PER_UNLOCK?  Run an incremental integrity check on the db
.limit ?LIMIT? ?VAL?     Display or change the value of an SQLITE_LIMIT
.lint OPTIONS            Report potential schema issues.
.load FILE ?ENTRY?       Load an extension library
.log FILE|on|off         Turn logging on or off.  FILE can be stderr/stdout
.mode ?MODE? ?OPTIONS?   Set output mode
.nonce STRING            Suspend safe mode for one command if nonce matches
.nullvalue STRING        Use STRING in place of NULL values
.once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE
.open ?OPTIONS? ?FILE?   Close existing database and reopen FILE
.output ?FILE?           Send output to FILE or stdout if FILE is omitted
.parameter CMD ...       Manage SQL parameter bindings
.print STRING...         Print literal STRING
.progress N              Invoke progress handler after every N opcodes
.prompt MAIN CONTINUE        Replace the standard prompts
.quit                    Stop interpreting input stream, exit if primary.
.read FILE               Read input from FILE or command output
.recover                 Recover as much data as possible from corrupt db.
.restore ?DB? FILE       Restore content of DB (default "main") from FILE
.save ?OPTIONS? FILE     Write database to FILE (an alias for .backup ...)
.scanstats on|off|est    Turn sqlite3_stmt_scanstatus() metrics on or off
.schema ?PATTERN?        Show the CREATE statements matching PATTERN
.sha3sum ...             Compute a SHA3 hash of database content
.shell CMD ARGS...       Run CMD ARGS... in a system shell
.stats ?ARG?             Show stats or turn stats on or off
.system CMD ARGS...      Run CMD ARGS... in a system shell
.tables ?TABLE?          List names of tables matching LIKE pattern TABLE
.testcase NAME           Begin a test case.
.timeout MS              Try opening locked tables for MS milliseconds
.timer on|off|once       Turn SQL timer on or off.
.trace ?OPTIONS?         Output each SQL statement as it is run
.version                 Show source, library and compiler versions
.vfsinfo ?AUX?           Information about the top-level VFS
.vfslist                 List all available VFSes
.vfsname ?AUX?           Print the name of the VFS stack
.www                     Display output of the next command in web browser"""


class Shell:
    def __init__(self, argv0):
        self.argv0 = argv0
        self.mode = "list"
        self.headers = False
        self.nullvalue = ""
        self.separator = "|"
        self.rowsep = "\n"
        self.echo = False
        self.bail = False
        self.changes = False
        self.timer = False
        self.out = sys.stdout
        self.filename = ":memory:"
        self.conn = None
        self.had_error = False

    def open_db(self, name, readonly=False):
        self.filename = name or ":memory:"
        if readonly and self.filename != ":memory:":
            uri = "file:" + self.filename + "?mode=ro"
            self.conn = sqlite3.connect(uri, uri=True)
        else:
            self.conn = sqlite3.connect(self.filename)
        self.conn.row_factory = sqlite3.Row
        self.conn.create_function("sqlite_version", 0, lambda: VERSION)
        self.conn.create_function("sqlite_source_id", 0, lambda: f"{SOURCE_DATE} {SOURCE_HASH}")

    def emit(self, s="", end="\n"):
        self.out.write(s + end)
        self.out.flush()

    def set_mode(self, mode):
        aliases = {"lines": "line", "cols": "column", "tabs": "tabs"}
        mode = aliases.get(mode, mode)
        valid = {"ascii", "box", "column", "csv", "html", "json", "line", "list",
                 "markdown", "quote", "table", "tabs"}
        if mode not in valid:
            return False
        self.mode = mode
        if mode == "tabs":
            self.separator = "\t"
        elif mode == "ascii":
            self.separator = "\x1f"
            self.rowsep = "\x1e"
        elif mode == "csv":
            self.separator = ","
        return True

    def cell(self, v):
        if v is None:
            return self.nullvalue
        if isinstance(v, bytes):
            return "X'" + v.hex().upper() + "'"
        return str(v)

    def quote_cell(self, v):
        if v is None:
            return "NULL"
        if isinstance(v, (int, float)):
            return str(v)
        if isinstance(v, bytes):
            return "X'" + v.hex().upper() + "'"
        return "'" + str(v).replace("'", "''") + "'"

    def run_sql_text(self, text, source="stdin", arg_index=None):
        buf = ""
        line_no = 0
        for raw in text.splitlines(True):
            line_no += 1
            line = raw.rstrip("\n")
            if not buf.strip() and line.lstrip().startswith("."):
                if self.echo:
                    self.emit(line)
                rc = self.dot(line, line_no)
                if rc is not None:
                    return rc
                continue
            buf += raw
            if sqlite3.complete_statement(buf):
                stmts = split_sql(buf)
                buf = ""
                for stmt in stmts:
                    if not stmt.strip():
                        continue
                    if self.echo:
                        self.emit(stmt.strip())
                    ok = self.execute(stmt.strip(), source, line_no, arg_index)
                    if not ok and self.bail:
                        return 1
        if buf.strip():
            self.execute(buf.strip(), source, line_no or 1, arg_index)
        return 1 if self.had_error else 0

    def execute(self, stmt, source, line_no, arg_index=None):
        try:
            cur = self.conn.cursor()
            cur.execute(stmt)
            if cur.description:
                rows = cur.fetchall()
                cols = [d[0] for d in cur.description]
                self.output_rows(cols, rows)
            else:
                self.conn.commit()
                if self.changes:
                    self.emit(f"changes: {self.conn.total_changes}   total_changes: {self.conn.total_changes}")
            return True
        except sqlite3.Error as e:
            self.had_error = True
            msg = str(e)
            if arg_index is not None:
                sys.stderr.write(f"Parse error in {ordinal(arg_index)} command line argument: {msg}\n")
            else:
                sys.stderr.write(f"Parse error near line {line_no}: {msg}\n")
            return False

    def output_rows(self, cols, rows):
        if self.mode in ("list", "tabs", "ascii"):
            data = []
            if self.headers:
                data.append(self.separator.join(cols))
            for r in rows:
                data.append(self.separator.join(self.cell(v) for v in r))
            if self.mode == "ascii":
                if data:
                    self.out.write(self.rowsep.join(data) + self.rowsep)
            else:
                for line in data:
                    self.emit(line, self.rowsep)
        elif self.mode == "csv":
            writer = csv.writer(self.out, lineterminator="\r\n")
            if self.headers:
                writer.writerow(cols)
            for r in rows:
                writer.writerow(["" if v is None else v for v in r])
        elif self.mode == "json":
            arr = []
            for r in rows:
                arr.append({cols[i]: r[i] for i in range(len(cols))})
            self.emit(json.dumps(arr, separators=(",", ":")).replace("},{", "},\n{"))
        elif self.mode == "line":
            for ri, r in enumerate(rows):
                for i, c in enumerate(cols):
                    self.emit(f"{c} = {self.cell(r[i])}" if False else f"{c}: {self.cell(r[i])}")
                if ri != len(rows) - 1:
                    self.emit("")
        elif self.mode == "quote":
            if self.headers:
                self.emit(",".join(self.quote_cell(c) for c in cols))
            for r in rows:
                self.emit(",".join(self.quote_cell(v) for v in r))
        elif self.mode == "html":
            if self.headers:
                self.emit("<TR>")
                for c in cols:
                    self.emit("<TH>" + html.escape(c))
                self.emit("</TR>")
            for r in rows:
                self.emit("<TR>")
                for v in r:
                    self.emit("<TD>" + ("null" if v is None else html.escape(str(v))))
                self.emit("</TR>")
        elif self.mode in ("column", "table", "box", "markdown"):
            self.aligned(cols, rows)

    def aligned(self, cols, rows):
        srows = [[self.cell(v) for v in r] for r in rows]
        include_header = self.headers or self.mode in ("table", "box", "markdown")
        widths = [len(c) for c in cols]
        for row in srows:
            for i, v in enumerate(row):
                widths[i] = max(widths[i], len(v))
        numeric = []
        for i in range(len(cols)):
            numeric.append(all(is_number(row[i]) for row in srows if row[i] != ""))

        def fmt_row(vals, sep="  ", pad=True):
            out = []
            for i, v in enumerate(vals):
                if numeric[i] and v != "":
                    out.append(v.rjust(widths[i]))
                else:
                    out.append(v.ljust(widths[i]))
            return sep.join(out)

        if self.mode == "column":
            if self.headers:
                self.emit("  ".join(cols[i].ljust(widths[i]) for i in range(len(cols))).rstrip())
                self.emit("  ".join("-" * w for w in widths))
            for row in srows:
                self.emit(fmt_row(row).rstrip())
            return

        if self.mode == "markdown":
            self.emit("| " + " | ".join(center_cell(cols[i], widths[i]) for i in range(len(cols))) + " |")
            self.emit("|" + "|".join("-" * (w + 2) for w in widths) + "|")
            for row in srows:
                self.emit("| " + " | ".join(fmt_table_cell(row[i], widths[i], numeric[i]) for i in range(len(cols))) + " |")
            return

        if self.mode == "table":
            border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
            self.emit(border)
            self.emit("| " + " | ".join(center_cell(cols[i], widths[i]) for i in range(len(cols))) + " |")
            self.emit(border)
            for row in srows:
                self.emit("| " + " | ".join(fmt_table_cell(row[i], widths[i], numeric[i]) for i in range(len(cols))) + " |")
            self.emit(border)
            return

        if self.mode == "box":
            self.emit("╭" + "┬".join("─" * (w + 2) for w in widths) + "╮")
            self.emit("│ " + " │ ".join(center_cell(cols[i], widths[i]) for i in range(len(cols))) + " │")
            self.emit("╞" + "╪".join("═" * (w + 2) for w in widths) + "╡")
            for row in srows:
                self.emit("│ " + " │ ".join(fmt_table_cell(row[i], widths[i], numeric[i]) for i in range(len(cols))) + " │")
            self.emit("╰" + "┴".join("─" * (w + 2) for w in widths) + "╯")

    def dot(self, line, line_no=0):
        try:
            parts = shlex.split(line)
        except ValueError:
            parts = line.split()
        if not parts:
            return None
        cmd = parts[0][1:]
        args = parts[1:]
        if cmd in ("quit", "exit"):
            raise SystemExit(int(args[0]) if args and args[0].isdigit() else 0)
        if cmd == "help":
            self.emit(DOT_HELP)
        elif cmd == "version":
            self.emit(f"SQLite {VERSION} {SOURCE_DATE}")
            self.emit(SOURCE_HASH)
            self.emit(f"zlib version 1.2.13")
            self.emit(f"gcc-11.4.0 (64-bit)")
        elif cmd == "mode":
            if not args:
                self.emit(f".mode {self.mode}")
            elif not self.set_mode(args[0]):
                sys.stderr.write(f"line {line_no}: .mode {args[0]}\nline {line_no}:       ^--- unknown mode\nline {line_no}: Use \".help .mode\" for more info\n")
                self.had_error = True
        elif cmd in ("headers", "header"):
            if args:
                self.headers = onoff(args[0])
            else:
                self.emit("on" if self.headers else "off")
        elif cmd == "nullvalue" and args:
            self.nullvalue = args[0]
        elif cmd == "separator":
            if args:
                self.separator = decode_sep(args[0])
            if len(args) > 1:
                self.rowsep = decode_sep(args[1])
        elif cmd == "print":
            self.emit(" ".join(args))
        elif cmd == "echo" and args:
            self.echo = onoff(args[0])
        elif cmd == "bail" and args:
            self.bail = onoff(args[0])
        elif cmd == "changes" and args:
            self.changes = onoff(args[0])
        elif cmd == "timer" and args:
            self.timer = onoff(args[0])
        elif cmd == "tables":
            self.show_tables(args[0] if args else None)
        elif cmd == "indexes":
            self.show_indexes(args[0] if args else None)
        elif cmd == "schema":
            self.show_schema(args[0] if args else None)
        elif cmd == "dump":
            self.dump()
        elif cmd == "databases":
            self.databases()
        elif cmd == "read" and args:
            with open(args[0], "r", encoding="utf-8") as f:
                return self.run_sql_text(f.read())
        elif cmd == "open":
            name = args[-1] if args else ":memory:"
            if self.conn:
                self.conn.close()
            self.open_db(name)
        elif cmd == "cd" and args:
            os.chdir(args[0])
        elif cmd in ("output", "once"):
            if not args or args[0].lower() == "stdout":
                if self.out is not sys.stdout:
                    self.out.close()
                self.out = sys.stdout
            else:
                self.out = open(args[0], "w", encoding="utf-8", newline="")
        elif cmd in ("import",):
            if len(args) >= 2:
                self.import_csv(args[0], args[1])
        elif cmd in ("backup", "save") and args:
            target = args[-1]
            dst = sqlite3.connect(target)
            self.conn.backup(dst)
            dst.close()
        elif cmd in ("restore",) and args:
            src = sqlite3.connect(args[-1])
            src.backup(self.conn)
            src.close()
        elif cmd == "shell" or cmd == "system":
            os.system(" ".join(shlex.quote(a) for a in args))
        else:
            sys.stderr.write(f"Error: unknown command or invalid arguments:  \"{cmd}\". Enter \".help\" for help\n")
            self.had_error = True
        return None

    def show_tables(self, pattern=None):
        sql = "select name from sqlite_schema where type in ('table','view') and name not like 'sqlite_%'"
        params = []
        if pattern:
            sql += " and name like ?"
            params.append(pattern.replace("*", "%"))
        names = [r[0] for r in self.conn.execute(sql + " order by 1", params)]
        if names:
            self.emit(" ".join(names))

    def show_indexes(self, pattern=None):
        sql = "select name from sqlite_schema where type='index' and name not like 'sqlite_%'"
        params = []
        if pattern:
            sql += " and tbl_name like ?"
            params.append(pattern.replace("*", "%"))
        names = [r[0] for r in self.conn.execute(sql + " order by 1", params)]
        for n in names:
            self.emit(n)

    def show_schema(self, pattern=None):
        sql = "select sql from sqlite_schema where sql not null"
        params = []
        if pattern:
            sql += " and name like ?"
            params.append(pattern.replace("*", "%"))
        for (s,) in self.conn.execute(sql + " order by type!='table', name", params):
            self.emit(s.rstrip(";") + ";")

    def dump(self):
        self.emit("PRAGMA foreign_keys=OFF;")
        self.emit("BEGIN TRANSACTION;")
        for line in self.conn.iterdump():
            if line not in ("BEGIN TRANSACTION;", "COMMIT;"):
                self.emit(unquote_simple_insert(line))
        self.emit("COMMIT;")

    def databases(self):
        for seq, name, file in self.conn.execute("pragma database_list"):
            display = file if file else ""
            access = "r/w"
            self.emit(f"{name}: {display} {access}")

    def import_csv(self, filename, table):
        with open(filename, newline="", encoding="utf-8") as f:
            reader = csv.reader(f, delimiter=self.separator if len(self.separator) == 1 else ",")
            rows = list(reader)
        if not rows:
            return
        n = len(rows[0])
        q = ",".join("?" for _ in range(n))
        self.conn.executemany(f'insert into "{table}" values({q})', rows)
        self.conn.commit()


def fmt_table_cell(v, width, numeric):
    if numeric and v != "":
        return v.rjust(width)
    return v.ljust(width)


def center_cell(v, width):
    extra = width - len(v)
    left = extra // 2
    right = extra - left
    return " " * left + v + " " * right


def split_sql(sql):
    out = []
    start = 0
    quote = None
    bracket = False
    line_comment = False
    block_comment = False
    i = 0
    n = len(sql)
    while i < n:
        c = sql[i]
        nxt = sql[i + 1] if i + 1 < n else ""
        if line_comment:
            if c == "\n":
                line_comment = False
        elif block_comment:
            if c == "*" and nxt == "/":
                block_comment = False
                i += 1
        elif quote:
            if c == quote:
                if nxt == quote:
                    i += 1
                else:
                    quote = None
        elif bracket:
            if c == "]":
                bracket = False
        else:
            if c in ("'", '"', "`"):
                quote = c
            elif c == "[":
                bracket = True
            elif c == "-" and nxt == "-":
                line_comment = True
                i += 1
            elif c == "/" and nxt == "*":
                block_comment = True
                i += 1
            elif c == ";":
                out.append(sql[start:i + 1])
                start = i + 1
        i += 1
    tail = sql[start:].strip()
    if tail:
        out.append(tail)
    return out


def unquote_simple_insert(line):
    prefix = 'INSERT INTO "'
    if not line.startswith(prefix):
        return line
    rest = line[len(prefix):]
    name, sep, after = rest.partition('"')
    if sep and name.replace("_", "").isalnum() and after.startswith(" VALUES"):
        return "INSERT INTO " + name + after
    return line


def is_number(s):
    try:
        float(s)
        return True
    except Exception:
        return False


def onoff(s):
    return s.lower() in ("on", "yes", "true", "1")


def decode_sep(s):
    return s.encode("utf-8").decode("unicode_escape")


def ordinal(n):
    if 10 <= n % 100 <= 20:
        suf = "th"
    else:
        suf = {1: "st", 2: "nd", 3: "rd"}.get(n % 10, "th")
    return f"{n}{suf}"


def parse(argv, shell):
    cmds = []
    filename = None
    sql_args = []
    readonly = False
    i = 1
    while i < len(argv):
        a = argv[i]
        if a == "--":
            i += 1
            break
        if a in ("-help", "--help"):
            print(HELP)
            raise SystemExit(0)
        if a in ("-version", "--version"):
            print(VERSION_LINE)
            raise SystemExit(0)
        if a == "-cmd" and i + 1 < len(argv):
            cmds.append(argv[i + 1])
            i += 2
            continue
        if a == "-init" and i + 1 < len(argv):
            try:
                with open(argv[i + 1], encoding="utf-8") as f:
                    cmds.append(f.read())
            except OSError as e:
                sys.stderr.write(f"Error: cannot open \"{argv[i+1]}\"\n")
            i += 2
            continue
        if a in ("-header", "-headers"):
            shell.headers = True
            i += 1
            continue
        if a in ("-noheader", "-noheaders"):
            shell.headers = False
            i += 1
            continue
        if a in ("-echo",):
            shell.echo = True
            i += 1
            continue
        if a in ("-bail",):
            shell.bail = True
            i += 1
            continue
        if a in ("-readonly",):
            readonly = True
            i += 1
            continue
        if a in ("-separator", "-newline", "-nullvalue", "-mmap", "-maxsize", "-vfs", "-nonce", "-escape"):
            if i + 1 < len(argv):
                val = argv[i + 1]
                if a == "-separator":
                    shell.separator = decode_sep(val)
                elif a == "-newline":
                    shell.rowsep = decode_sep(val)
                elif a == "-nullvalue":
                    shell.nullvalue = val
                i += 2
                continue
        if a in ("-lookaside", "-pagecache") and i + 2 < len(argv):
            i += 3
            continue
        if a.startswith("-") and len(a) > 1:
            mode = a[1:]
            if mode in ("list", "line", "column", "csv", "json", "quote", "html", "tabs", "ascii", "box", "table", "markdown"):
                shell.set_mode(mode)
                if mode in ("column", "html"):
                    shell.headers = True
                i += 1
                continue
            if mode in ("batch", "interactive", "noinit", "deserialize", "append", "ifexists", "nofollow", "safe",
                        "unsafe-testing", "stats", "memtrace", "pcachetrace", "vfstrace", "zip", "no-rowid-in-view"):
                i += 1
                continue
            sys.stderr.write(f"{argv[0]}: Error: unknown option: {a}\nUse -help for a list of options.\n")
            raise SystemExit(1)
        break
    rest = argv[i:]
    if rest:
        filename = rest[0]
        sql_args = rest[1:]
    if filename is None:
        filename = ":memory:"
    return filename, sql_args, cmds, readonly


def main(argv):
    shell = Shell(argv[0] if argv else "./executable")
    try:
        filename, sql_args, cmds, readonly = parse(argv, shell)
        shell.open_db(filename, readonly)
        for c in cmds:
            shell.run_sql_text(c if c.endswith("\n") else c + "\n", source="-cmd")
        if sql_args:
            sql = " ".join(sql_args)
            return shell.run_sql_text(sql if sql.endswith("\n") else sql + "\n", source="argv", arg_index=2)
        if not sys.stdin.isatty():
            return shell.run_sql_text(sys.stdin.read())
        return 0
    except SystemExit as e:
        return int(e.code or 0)
    except KeyboardInterrupt:
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
