#!/usr/bin/env python3
import argparse
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

VERSION = "1.14.0.git"


class Rule:
    def __init__(self, name, vars=None):
        self.name = name
        self.vars = vars or {}


class Edge:
    def __init__(self, outputs, rule, inputs, implicit=None, order=None, vars=None):
        self.outputs = outputs
        self.rule = rule
        self.inputs = inputs
        self.implicit = implicit or []
        self.order = order or []
        self.vars = vars or {}


class Manifest:
    def __init__(self):
        self.vars = {}
        self.rules = {"phony": Rule("phony", {"command": ""})}
        self.edges = []
        self.by_out = {}
        self.defaults = []
        self.buildfile = "build.ninja"


def usage(exitcode=0, err=False):
    text = f"""usage: ninja [options] [targets...]

if targets are unspecified, builds the 'default' target (see manual).

options:
  --version      print ninja version ("{VERSION}")
  -v, --verbose  show all command lines while building
  --quiet        don't show progress status, just command output

  -C DIR   change to DIR before doing anything else
  -f FILE  specify input build file [default=build.ninja]

  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]
  -k N     keep going until N jobs fail (0 means infinity) [default=1]
  -l N     do not start new jobs if the load average is greater than N
  -n       dry run (don't run commands but act like they succeeded)

  -d MODE  enable debugging (use '-d list' to list modes)
  -t TOOL  run a subtool (use '-t list' to list subtools)
    terminates toplevel options; further flags are passed to the tool
  -w FLAG  adjust warnings (use '-w list' to list warnings)
"""
    (sys.stderr if err else sys.stdout).write(text)
    raise SystemExit(exitcode)


def debug_list():
    print("""debugging modes:
  stats        print operation counts/timing info
  explain      explain what caused a command to execute
  keepdepfile  don't delete depfiles after they're read by ninja
  keeprsp      don't delete @response files on success
multiple modes can be enabled via -d FOO -d BAR""")


def tool_list():
    print("""ninja subtools:
     browse  browse dependency graph in a web browser
      clean  clean built files
   commands  list all commands required to rebuild given targets
     inputs  list all inputs required to rebuild given targets
multi-inputs  print one or more sets of inputs required to build targets
       deps  show dependencies stored in the deps log
missingdeps  check deps log dependencies on generated files
      graph  output graphviz dot file for targets
      query  show inputs/outputs for a path
    targets  list targets by their rule or depth in the DAG
     compdb  dump JSON compilation database to stdout
compdb-targets  dump JSON compilation database for a given list of targets to stdout
  recompact  recompacts ninja-internal data structures
     restat  restats all outputs in the build log
      rules  list all rules
  cleandead  clean built files that are no longer produced by the manifest""")


def warn_list():
    print("warning flags:\n  phonycycle={err,warn}  phony build statement references itself")


def logical_lines(path):
    try:
        raw = open(path, "r", encoding="utf-8").read().splitlines()
    except OSError as e:
        print(f"ninja: error: loading '{path}': {e.strerror}", file=sys.stderr)
        raise SystemExit(1)
    out = []
    cur = ""
    start = 0
    for i, line in enumerate(raw, 1):
        if cur == "":
            start = i
        if line.endswith("$"):
            cur += line[:-1]
            continue
        cur += line
        out.append((start, cur))
        cur = ""
    if cur:
        out.append((start, cur))
    return out


def expand(s, scopes):
    res = []
    i = 0
    while i < len(s):
        c = s[i]
        if c != "$":
            res.append(c)
            i += 1
            continue
        i += 1
        if i >= len(s):
            res.append("$")
            break
        ch = s[i]
        if ch == "$":
            res.append("$"); i += 1
        elif ch in " :|\n":
            res.append(ch); i += 1
        elif ch == "{":
            j = s.find("}", i + 1)
            if j < 0:
                res.append("$")
            else:
                name = s[i + 1:j]
                res.append(lookup(name, scopes))
                i = j + 1
        else:
            j = i
            while j < len(s) and (s[j].isalnum() or s[j] == "_"):
                j += 1
            name = s[i:j]
            res.append(lookup(name, scopes) if name else "$" + ch)
            i = j if name else i + 1
    return "".join(res)


def lookup(name, scopes):
    for scope in scopes:
        if name in scope:
            return scope[name]
    return ""


def split_words(s):
    words, cur = [], []
    i = 0
    while i < len(s):
        c = s[i]
        if c.isspace():
            if cur:
                words.append("".join(cur)); cur = []
            i += 1
        elif c == "$" and i + 1 < len(s):
            cur.append(s[i + 1]); i += 2
        else:
            cur.append(c); i += 1
    if cur:
        words.append("".join(cur))
    return words


def parse_manifest(path, manifest=None, parent_vars=None):
    m = manifest or Manifest()
    if manifest is None:
        m.buildfile = path
    base = os.path.dirname(path) or "."
    vars_scope = dict(parent_vars or m.vars)
    lines = logical_lines(path)
    i = 0
    while i < len(lines):
        lineno, line = lines[i]
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            i += 1; continue
        if line[0].isspace():
            print(f"ninja: error: {path}:{lineno}: unexpected indent", file=sys.stderr)
            raise SystemExit(1)
        if stripped.startswith("rule "):
            name = stripped[5:].strip()
            vals = {}
            i += 1
            while i < len(lines) and (lines[i][1].startswith(" ") or lines[i][1].startswith("\t")):
                body = lines[i][1].strip()
                if body and not body.startswith("#") and "=" in body:
                    k, v = body.split("=", 1)
                    vals[k.strip()] = v.strip()
                i += 1
            m.rules[name] = Rule(name, vals)
            continue
        if stripped.startswith("pool "):
            i += 1
            while i < len(lines) and (lines[i][1].startswith(" ") or lines[i][1].startswith("\t")):
                i += 1
            continue
        if stripped.startswith("build "):
            rest = stripped[6:]
            if ":" not in rest:
                print(f"ninja: error: {path}:{lineno}: expected ':'", file=sys.stderr)
                raise SystemExit(1)
            left, right = rest.split(":", 1)
            outs = [w for w in split_words(expand(left, [vars_scope])) if w not in ("|", "|@")]
            parts = split_words(expand(right, [vars_scope]))
            if not parts:
                print(f"ninja: error: {path}:{lineno}: expected rule name", file=sys.stderr)
                raise SystemExit(1)
            rule = parts[0]
            mode, ins, imp, order = "in", [], [], []
            for tok in parts[1:]:
                if tok == "|":
                    mode = "imp"; continue
                if tok == "||":
                    mode = "order"; continue
                (ins if mode == "in" else imp if mode == "imp" else order).append(tok)
            evars = {}
            i += 1
            while i < len(lines) and (lines[i][1].startswith(" ") or lines[i][1].startswith("\t")):
                body = lines[i][1].strip()
                if body and not body.startswith("#") and "=" in body:
                    k, v = body.split("=", 1)
                    evars[k.strip()] = expand(v.strip(), [evars, vars_scope])
                i += 1
            edge = Edge(outs, rule, ins, imp, order, evars)
            m.edges.append(edge)
            for out in outs:
                m.by_out[out] = edge
            continue
        if stripped.startswith("default "):
            m.defaults += split_words(expand(stripped[8:], [vars_scope]))
            i += 1; continue
        if stripped.startswith("include ") or stripped.startswith("subninja "):
            sub = expand(stripped.split(None, 1)[1], [vars_scope])
            parse_manifest(os.path.join(base, sub), m, vars_scope)
            i += 1; continue
        if "=" in stripped:
            k, v = stripped.split("=", 1)
            vars_scope[k.strip()] = expand(v.strip(), [vars_scope])
            if parent_vars is None:
                m.vars[k.strip()] = vars_scope[k.strip()]
            i += 1; continue
        i += 1
    return m


def edge_env(m, e):
    special = {"in": " ".join(e.inputs), "out": " ".join(e.outputs)}
    return [special, e.vars, m.rules.get(e.rule, Rule(e.rule)).vars, m.vars]


def edge_var(m, e, name):
    rule = m.rules.get(e.rule, Rule(e.rule))
    raw = e.vars.get(name, rule.vars.get(name, ""))
    return expand(raw, edge_env(m, e))


def roots(m):
    if m.defaults:
        return m.defaults
    used = set()
    for e in m.edges:
        used.update(e.inputs); used.update(e.implicit); used.update(e.order)
    return [o for e in m.edges for o in e.outputs if o not in used]


def command_hash(cmd):
    return hashlib.sha1(cmd.encode()).hexdigest()


def load_cmdlog():
    try:
        return json.load(open(".ninja_cmd_log", "r"))
    except Exception:
        return {}


def load_depslog():
    try:
        return json.load(open(".ninja_deps_json", "r"))
    except Exception:
        return {}


def save_cmdlog(log):
    with open(".ninja_cmd_log", "w") as f:
        json.dump(log, f, sort_keys=True)


def save_depslog(log):
    with open(".ninja_deps_json", "w") as f:
        json.dump(log, f, sort_keys=True)


def parse_depfile(path):
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError:
        return []
    text = text.replace("\\\n", " ")
    if ":" in text:
        text = text.split(":", 1)[1]
    return [w for w in split_words(text) if w]


class Builder:
    def __init__(self, m, dry=False, verbose=False, quiet=False, explain=False):
        self.m = m
        self.dry = dry
        self.verbose = verbose or dry
        self.quiet = quiet
        self.explain = explain
        self.cmdlog = load_cmdlog()
        self.depslog = load_depslog()
        self.plan = []
        self.seen = set()
        self.built = set()

    def needed(self, e):
        if e.rule == "phony":
            return False
        cmd = edge_var(self.m, e, "command")
        newest = 0
        extra = []
        for o in e.outputs:
            extra += self.depslog.get(o, [])
        for p in e.inputs + e.implicit + extra:
            if os.path.exists(p):
                newest = max(newest, os.path.getmtime(p))
        for o in e.outputs:
            if not os.path.exists(o):
                return True
            if os.path.getmtime(o) < newest:
                return True
            if self.cmdlog.get(o) != command_hash(cmd):
                return True
        return False

    def visit(self, target, stack=None):
        stack = stack or []
        if target in self.seen:
            return
        e = self.m.by_out.get(target)
        if not e:
            if not os.path.exists(target):
                print(f"ninja: error: '{target}', needed by '{stack[-1] if stack else target}', missing and no known rule to make it", file=sys.stderr)
                raise SystemExit(1)
            self.seen.add(target)
            return
        for dep in e.inputs + e.implicit + e.order:
            self.visit(dep, stack + [target])
        if self.needed(e):
            self.plan.append(e)
        self.seen.update(e.outputs)

    def build(self, targets):
        for t in targets:
            self.visit(t)
        if not self.plan:
            print("ninja: no work to do.")
            return 0
        total = len(self.plan)
        for idx, e in enumerate(self.plan, 1):
            cmd = edge_var(self.m, e, "command")
            desc = edge_var(self.m, e, "description") or cmd
            if not self.quiet:
                print(f"[{idx}/{total}] {cmd if self.verbose else desc}")
            if not self.dry:
                for o in e.outputs:
                    d = os.path.dirname(o)
                    if d:
                        os.makedirs(d, exist_ok=True)
                rspfile = edge_var(self.m, e, "rspfile")
                if rspfile:
                    rd = os.path.dirname(rspfile)
                    if rd:
                        os.makedirs(rd, exist_ok=True)
                    with open(rspfile, "w", encoding="utf-8") as f:
                        f.write(edge_var(self.m, e, "rspfile_content"))
                p = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                if p.returncode:
                    print(f"FAILED: [code={p.returncode}] {' '.join(e.outputs)} ")
                    print(cmd)
                    if p.stdout:
                        print(p.stdout, end="")
                    print("ninja: build stopped: subcommand failed.", file=sys.stderr)
                    return 1
                if p.stdout:
                    print(p.stdout, end="")
                if rspfile:
                    try:
                        os.remove(rspfile)
                    except OSError:
                        pass
                h = command_hash(cmd)
                depfile = edge_var(self.m, e, "depfile")
                deps = parse_depfile(depfile) if depfile else []
                for o in e.outputs:
                    self.cmdlog[o] = h
                    if deps:
                        self.depslog[o] = deps
        if not self.dry:
            save_cmdlog(self.cmdlog)
            save_depslog(self.depslog)
        return 0


def collect_edges(m, targets):
    seen_t, seen_e, out = set(), set(), []
    def rec(t):
        if t in seen_t:
            return
        seen_t.add(t)
        e = m.by_out.get(t)
        if not e:
            return
        for d in e.inputs + e.implicit + e.order:
            rec(d)
        if id(e) not in seen_e and e.rule != "phony":
            seen_e.add(id(e)); out.append(e)
    for t in targets:
        rec(t)
    return out


def tool_query(m, args):
    for t in args:
        e = m.by_out.get(t)
        print(f"{t}:")
        if not e:
            print("  unknown target")
            continue
        print(f"  input: {e.rule}")
        for x in e.inputs:
            print(f"    {x}")
        for x in e.implicit:
            print(f"    | {x}")
        for x in e.order:
            print(f"    || {x}")
        print("  outputs:")
        for oe in m.edges:
            if t in oe.inputs + oe.implicit + oe.order:
                for o in oe.outputs:
                    print(f"    {o}")


def tool_targets(m, args):
    if args and args[0] == "all":
        for e in m.edges:
            for o in e.outputs:
                print(f"{o}: {e.rule}")
    elif args and args[0] == "rule":
        name = args[1] if len(args) > 1 else ""
        for e in m.edges:
            if e.rule == name:
                for o in e.outputs:
                    print(o)
    else:
        for e in m.edges:
            for o in e.outputs:
                print(f"{o}: {e.rule}")
                if args[:1] == ["depth"]:
                    for d in e.inputs:
                        print(f"  {d}")


def json_escape(s):
    return json.dumps(s)


def run_tool(m, tool, args):
    if tool == "list":
        tool_list(); return 0
    if tool == "rules":
        for r in m.rules:
            print(r)
        return 0
    if tool == "targets":
        tool_targets(m, args); return 0
    if tool == "query":
        tool_query(m, args); return 0
    if tool == "commands":
        final_only = args and args[0] == "-s"
        if final_only:
            args = args[1:]
        edges = collect_edges(m, args or roots(m))
        if final_only and edges:
            edges = edges[-1:]
        for e in edges:
            print(edge_var(m, e, "command"))
        return 0
    if tool == "inputs":
        vals = []
        for e in collect_edges(m, args or roots(m)):
            vals += e.inputs + e.implicit
        for v in dict.fromkeys(vals):
            print(shlex.quote(v))
        return 0
    if tool == "multi-inputs":
        for t in args or roots(m):
            for e in collect_edges(m, [t]):
                for v in e.inputs + e.implicit:
                    print(f"{t}\t{v}")
        return 0
    if tool in ("compdb", "compdb-targets"):
        expand_rsp = False
        if args and args[0] == "-x":
            expand_rsp = True; args = args[1:]
        edges = collect_edges(m, args) if tool == "compdb-targets" else [e for e in m.edges if e.rule in args]
        arr = []
        for e in edges:
            if not e.inputs:
                continue
            arr.append({"directory": os.getcwd(), "command": edge_var(m, e, "command"), "file": e.inputs[0], "output": e.outputs[0] if e.outputs else ""})
        print(json.dumps(arr, indent=2))
        return 0
    if tool == "clean":
        by_rule = False
        if args and args[0] == "-r":
            by_rule = True
            args = args[1:]
        selected = set(args)
        removed = 0
        for e in m.edges:
            if by_rule and selected and e.rule not in selected:
                continue
            if (not by_rule) and selected and not (set(e.outputs) & selected):
                continue
            for o in e.outputs:
                if os.path.exists(o):
                    print(f"Remove {o}")
                    os.remove(o); removed += 1
        print(f"{removed} files.")
        return 0
    if tool == "graph":
        print('digraph ninja {\nrankdir="LR"')
        for e in m.edges:
            for o in e.outputs:
                print(f'  "{e.rule}" -> "{o}"')
            for i in e.inputs:
                print(f'  "{i}" -> "{e.rule}"')
        print("}")
        return 0
    if tool == "deps":
        deps = load_depslog()
        if not deps:
            print("ninja deps log: 0 entries")
        else:
            for out, vals in deps.items():
                if args and out not in args:
                    continue
                print(f"{out}: #deps {len(vals)}")
                for v in vals:
                    print(f"    {v}")
        return 0
    if tool in ("missingdeps", "recompact", "restat", "cleandead"):
        return 0
    print(f"ninja: fatal: unknown tool '{tool}'", file=sys.stderr)
    return 1


def parse_args(argv):
    opts = {"file": "build.ninja", "dry": False, "verbose": False, "quiet": False, "tool": None, "targets": [], "explain": False}
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-h", "--help"):
            usage()
        if a == "--version":
            print(VERSION); raise SystemExit(0)
        if a in ("-v", "--verbose"):
            opts["verbose"] = True; i += 1; continue
        if a == "--quiet":
            opts["quiet"] = True; i += 1; continue
        if a == "-n":
            opts["dry"] = True; i += 1; continue
        if a == "-C":
            i += 1; os.chdir(argv[i]); print(f"ninja: Entering directory `{argv[i]}'"); i += 1; continue
        if a.startswith("-C") and len(a) > 2:
            os.chdir(a[2:]); print(f"ninja: Entering directory `{a[2:]}'"); i += 1; continue
        if a == "-f":
            i += 1; opts["file"] = argv[i]; i += 1; continue
        if a.startswith("-f") and len(a) > 2:
            opts["file"] = a[2:]; i += 1; continue
        if a in ("-j", "-k", "-l", "-w", "-d"):
            val = argv[i + 1] if i + 1 < len(argv) else ""
            if a == "-d" and val == "list":
                debug_list(); raise SystemExit(0)
            if a == "-w" and val == "list":
                warn_list(); raise SystemExit(0)
            if a == "-d" and val == "explain":
                opts["explain"] = True
            i += 2; continue
        if (a.startswith("-j") or a.startswith("-k") or a.startswith("-l")) and len(a) > 2:
            i += 1; continue
        if a == "-t":
            if i + 1 >= len(argv):
                print("ninja: option requires an argument -- 't'", file=sys.stderr); raise SystemExit(1)
            opts["tool"] = argv[i + 1]
            opts["targets"] = argv[i + 2:]
            return opts
        if a.startswith("-"):
            print(f"{sys.argv[0]}: invalid option -- '{a.lstrip('-')[:1]}'", file=sys.stderr)
            usage(1, err=True)
        opts["targets"].append(a)
        i += 1
    return opts


def main(argv):
    opts = parse_args(argv)
    if opts["tool"] == "list":
        tool_list()
        return 0
    m = parse_manifest(opts["file"])
    if opts["tool"]:
        return run_tool(m, opts["tool"], opts["targets"])
    targets = opts["targets"] or roots(m)
    fixed = []
    for t in targets:
        if t.endswith("^"):
            src = t[:-1]
            match = next((e.outputs[0] for e in m.edges if src in e.inputs + e.implicit), None)
            fixed.append(match or t)
        else:
            fixed.append(t)
    targets = fixed
    b = Builder(m, opts["dry"], opts["verbose"], opts["quiet"], opts["explain"])
    return b.build(targets)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
