#!/usr/bin/env python3
import argparse
import json
import os
import re
import shutil
import sys
from pathlib import Path


VERSION = "nomino 1.6.4"
HELP_LONG = """Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...
          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>
          Sets the working directory

      --depth <DEPTH>
          Optional value to overwrite inferred subdirectory depth value in 'regex' mode

  -E, --no-extension
          Does not preserve the extension of input files in 'sort' and 'regex' options

  -g, --generate <PATH>
          Stores a JSON map file in '<PATH>' after renaming files

  -h, --help
          Print help (see a summary with '-h')

  -k, --mkdir
          Recursively creates all parent directories of '<OUTPUT>' if they are missing

  -m, --map <PATH>
          Sets the path of map file to be used for renaming files
          
          [aliases: --from-file]

      --max-depth <DEPTH>
          Optional value to set the maximum of subdirectory depth value in 'regex' mode

  -q, --quiet
          Does not print the map table to stdout

  -r, --regex <PATTERN>
          Regex pattern to match by filenames

  -s, --sort <ORDER>
          Sets the order of natural sorting (by name) to rename files using enumerator

          Possible values:
          - asc:  Sort in ascending order
          - desc: Sort in descending order

  -t, --test
          Runs in test mode without renaming actual files
          
          [aliases: --dry-run]

  -V, --version
          Print version

  -w, --overwrite
          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information."""

HELP_SHORT = """Batch rename utility for developers

Usage: executable [OPTIONS] [[SOURCE] OUTPUT]...

Arguments:
  [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option

Options:
  -d, --dir <PATH>         Sets the working directory
      --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode
  -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options
  -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files
  -h, --help               Print help (see more with '--help')
  -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing
  -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]
      --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode
  -q, --quiet              Does not print the map table to stdout
  -r, --regex <PATTERN>    Regex pattern to match by filenames
  -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]
  -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]
  -V, --version            Print version
  -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename

OUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information."""


def eprint(s):
    print(s, file=sys.stderr)


def parse_args(argv):
    if "--help" in argv:
        print(HELP_LONG)
        sys.exit(0)
    if "-h" in argv:
        print(HELP_SHORT)
        sys.exit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        sys.exit(0)
    p = argparse.ArgumentParser(add_help=False, prog="executable", allow_abbrev=False)
    p.add_argument("-d", "--dir", dest="dir", default=".")
    p.add_argument("--depth", type=int)
    p.add_argument("--max-depth", type=int)
    p.add_argument("-E", "--no-extension", action="store_true")
    p.add_argument("-g", "--generate")
    p.add_argument("-k", "--mkdir", action="store_true")
    p.add_argument("-m", "--map", "--from-file", dest="map")
    p.add_argument("-q", "--quiet", action="store_true")
    p.add_argument("-r", "--regex")
    p.add_argument("-s", "--sort", choices=["asc", "desc"])
    p.add_argument("-t", "--test", "--dry-run", dest="test", action="store_true")
    p.add_argument("-w", "--overwrite", action="store_true")
    p.add_argument("patterns", nargs="*")
    try:
        return p.parse_args(argv)
    except SystemExit as ex:
        sys.exit(ex.code)


def natural_key(s):
    parts = re.split(r"(\d+)", s)
    out = []
    for part in parts:
        if part.isdigit():
            out.append((0, int(part), part))
        else:
            out.append((1, part))
    return out


def iter_paths(root, depth):
    root = Path(root)
    if depth is None:
        depth = 1
    if depth <= 0:
        yield Path("")
        return
    for cur, dirs, files in os.walk(root):
        rel_dir = Path(cur).relative_to(root)
        level = 0 if str(rel_dir) == "." else len(rel_dir.parts)
        if level >= depth:
            dirs[:] = []
        names = list(dirs) + list(files)
        for name in names:
            rel = Path(name) if str(rel_dir) == "." else rel_dir / name
            yield rel


def split_ext(name):
    p = Path(name)
    base = p.name
    if base in ("", ".", ".."):
        return str(p), ""
    idx = base.rfind(".")
    if idx <= 0:
        return str(p), ""
    stem = base[:idx]
    ext = base[idx:]
    return str(p.with_name(stem)), ext


def pad_value(val, pad):
    if pad and re.fullmatch(r"\d+", val):
        return val.zfill(int(pad))
    return val


def expand_pattern(fmt, groups, named=None):
    named = named or {}
    auto = 1

    def repl(m):
        nonlocal auto
        key = m.group(1)
        pad = m.group(2)
        if key == "":
            key = str(auto)
            auto += 1
        val = ""
        if key in named:
            val = named.get(key) or ""
        elif key.isdigit():
            idx = int(key)
            if 0 <= idx < len(groups):
                val = groups[idx] or ""
        return pad_value(str(val), pad)

    return re.sub(r"\{([^{}:]*)(?::(\d+))?\}", repl, fmt)


def with_extension(out, inp, preserve):
    if not preserve:
        return out
    _, ext = split_ext(inp)
    if ext and not str(out).endswith(ext):
        return out + ext
    return out


def collision_name(root, out, overwrite):
    if overwrite:
        return out
    p = Path(out)
    candidate = p
    while (Path(root) / candidate).exists():
        candidate = candidate.with_name("_" + candidate.name)
    return str(candidate)


def print_table(rows):
    headers = ("Input", "Output")
    w1 = max([len(headers[0])] + [len(a) for a, _ in rows])
    w2 = max([len(headers[1])] + [len(b) for _, b in rows])
    sep = "+" + "-" * (w1 + 2) + "+" + "-" * (w2 + 2) + "+"
    print(sep)
    print(f"| {headers[0].ljust(w1)} | {headers[1].ljust(w2)} |")
    print(sep)
    for a, b in rows:
        print(f"| {a.ljust(w1)} | {b.ljust(w2)} |")
    print(sep)


def compute_pairs(args):
    root = args.dir
    pairs = []
    if args.map:
        try:
            with open(Path(root) / args.map, "r", encoding="utf-8") as f:
                mp = json.load(f)
        except Exception as ex:
            eprint(str(ex))
            return None, 1
        if not isinstance(mp, dict):
            eprint("error: invalid type: sequence, expected a map at line 1 column 0")
            return None, 1
        for src, dst in mp.items():
            out = collision_name(root, dst, args.overwrite)
            pairs.append((src, out))
        return pairs, 0

    if args.sort:
        if not args.patterns:
            eprint("error: [output-format] output formatter must be set")
            return None, 1
        fmt = args.patterns[-1]
        entries = [p.name for p in Path(root).iterdir()]
        entries.sort(key=natural_key, reverse=args.sort == "desc")
        for i, name in enumerate(entries, 1):
            out = expand_pattern(fmt, [name, str(i)])
            out = with_extension(out, name, not args.no_extension)
            out = collision_name(root, out, args.overwrite)
            pairs.append((name, out))
        return pairs, 0

    regex_pat = args.regex
    fmt = None
    if regex_pat:
        if not args.patterns:
            eprint("error: [output-format] output formatter must be set")
            return None, 1
        fmt = args.patterns[-1]
    elif len(args.patterns) >= 2:
        regex_pat, fmt = args.patterns[-2], args.patterns[-1]
    else:
        eprint("error: one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.")
        eprint("usage: run './executable --help' for more information.")
        return None, 1

    try:
        rx = re.compile(regex_pat)
    except re.error as ex:
        eprint("error: regex parse error:")
        eprint(f"    {regex_pat}")
        eprint("    ^")
        eprint(f"error: {ex}")
        return None, 1

    depth = args.depth
    if depth is None:
        slashes = max(regex_pat.count("/"), fmt.count("/"))
        depth = min(args.max_depth if args.max_depth is not None else slashes + 1, slashes + 1)
    entries = list(iter_paths(root, depth))
    entries = sorted([str(p) for p in entries], key=natural_key)
    for name in entries:
        m = rx.search(name)
        if not m:
            continue
        groups = [m.group(0)] + list(m.groups())
        out = expand_pattern(fmt, groups, m.groupdict())
        out = with_extension(out, name, not args.no_extension)
        out = collision_name(root, out, args.overwrite)
        pairs.append((name, out))
    return pairs, 0


def do_renames(args, pairs):
    root = Path(args.dir)
    ok = True
    for src, dst in pairs:
        sp = root / src
        dp = root / dst
        if args.test:
            continue
        if args.mkdir:
            dp.parent.mkdir(parents=True, exist_ok=True)
        try:
            if args.overwrite and dp.exists():
                if dp.is_dir():
                    shutil.rmtree(dp)
                else:
                    dp.unlink()
            sp.rename(dp)
        except OSError as ex:
            eprint(f"[error] unable to rename '{src}': {ex.strerror} (os error {ex.errno})")
            ok = False
    return 0 if ok else 1


def main(argv):
    args = parse_args(argv)
    pairs, code = compute_pairs(args)
    if code:
        return code
    if not args.quiet:
        print_table(pairs)
    rc = do_renames(args, pairs)
    if args.generate:
        mp = {dst: src for src, dst in pairs}
        with open(Path(args.dir) / args.generate, "w", encoding="utf-8") as f:
            json.dump(mp, f, indent=2)
            f.write("\n")
    return rc


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
