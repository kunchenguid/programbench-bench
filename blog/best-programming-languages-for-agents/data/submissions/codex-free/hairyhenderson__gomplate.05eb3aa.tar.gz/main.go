package main

import (
	"bufio"
	"bytes"
	"crypto/md5"
	"crypto/rand"
	"crypto/sha1"
	"crypto/sha256"
	"crypto/sha512"
	"encoding/base64"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"hash"
	"html"
	"io"
	"log/slog"
	mathpkg "math"
	"math/big"
	"net"
	"net/url"
	"os"
	"path"
	"path/filepath"
	"reflect"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"text/template"
	"time"
	"unicode"
)

type arrayFlags []string

func (a *arrayFlags) String() string { return strings.Join(*a, ",") }
func (a *arrayFlags) Set(v string) error {
	*a = append(*a, v)
	return nil
}

type app struct {
	datasources map[string]string
	cache       map[string]any
	left        string
	right       string
	missing     string
	templates  []string
	tmplPath   string
}

type rootContext struct {
	Env map[string]string
}

func main() {
	os.Exit(run())
}

func run() int {
	var datasources, contexts, templates, includes, excludes, exclProc, plugins, headers arrayFlags
	var file, in, out, inputDir, outputDir, outputMap, chmod, left, right, missing, config string
	var verbose, version, help, experimental, execPipe bool
	leftDef, rightDef := "{{", "}}"
	if v := os.Getenv("GOMPLATE_LEFT_DELIM"); v != "" {
		leftDef = v
	}
	if v := os.Getenv("GOMPLATE_RIGHT_DELIM"); v != "" {
		rightDef = v
	}
	fs := flag.NewFlagSet("gomplate", flag.ContinueOnError)
	fs.SetOutput(io.Discard)
	fs.Var(&datasources, "d", "")
	fs.Var(&datasources, "datasource", "")
	fs.Var(&headers, "H", "")
	fs.Var(&headers, "datasource-header", "")
	fs.Var(&contexts, "c", "")
	fs.Var(&contexts, "context", "")
	fs.Var(&plugins, "plugin", "")
	fs.StringVar(&file, "f", "-", "")
	fs.StringVar(&file, "file", "-", "")
	fs.StringVar(&in, "i", "", "")
	fs.StringVar(&in, "in", "", "")
	fs.StringVar(&inputDir, "input-dir", "", "")
	fs.Var(&excludes, "exclude", "")
	fs.Var(&exclProc, "exclude-processing", "")
	fs.Var(&includes, "include", "")
	fs.StringVar(&out, "o", "-", "")
	fs.StringVar(&out, "out", "-", "")
	fs.Var(&templates, "t", "")
	fs.Var(&templates, "template", "")
	fs.StringVar(&outputDir, "output-dir", ".", "")
	fs.StringVar(&outputMap, "output-map", "", "")
	fs.StringVar(&chmod, "chmod", "", "")
	fs.BoolVar(&execPipe, "exec-pipe", false, "")
	fs.StringVar(&left, "left-delim", leftDef, "")
	fs.StringVar(&right, "right-delim", rightDef, "")
	fs.StringVar(&missing, "missing-key", "error", "")
	fs.BoolVar(&experimental, "experimental", false, "")
	fs.BoolVar(&verbose, "V", false, "")
	fs.BoolVar(&verbose, "verbose", false, "")
	fs.StringVar(&config, "config", ".gomplate.yaml", "")
	fs.BoolVar(&help, "h", false, "")
	fs.BoolVar(&help, "help", false, "")
	fs.BoolVar(&version, "v", false, "")
	fs.BoolVar(&version, "version", false, "")
	if err := fs.Parse(os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		usage()
		return 1
	}
	_ = headers
	_ = plugins
	_ = verbose
	_ = experimental
	_ = execPipe
	_ = config
	if help {
		usage()
		return 0
	}
	if version {
		fmt.Println("gomplate version 0.0.0")
		return 0
	}
	a := &app{datasources: map[string]string{}, cache: map[string]any{}, left: left, right: right, missing: missing, templates: templates}
	for _, d := range datasources {
		k, v, err := splitAliasURL(d)
		if err != nil {
			return die(err)
		}
		a.datasources[k] = v
	}
	ctx := rootContext{Env: envMap()}
	var data any = ctx
	for _, c := range contexts {
		k, v, err := splitAliasURL(c)
		if err != nil {
			return die(err)
		}
		val, err := a.load(v)
		if err != nil {
			return die(err)
		}
		if k == "." {
			data = val
		} else if m, ok := data.(map[string]any); ok {
			m[k] = val
			data = m
		} else {
			m := map[string]any{"Env": ctx.Env}
			m[k] = val
			data = m
		}
	}
	if inputDir != "" {
		if err := a.processDir(inputDir, outputDir, outputMap, includes, excludes, exclProc, chmod, data); err != nil {
			return die(err)
		}
		return 0
	}
	var text string
	var name string
	if in != "" {
		text, name = in, "<arg>"
	} else {
		if file == "" {
			file = "-"
		}
		name = file
		b, err := readPath(file)
		if err != nil {
			return die(err)
		}
		text = string(b)
		if file != "-" {
			a.tmplPath = file
		}
	}
	res, err := a.render(name, text, data)
	if err != nil {
		return die(fmt.Errorf("renderTemplate: failed to render template %s: %w", name, err))
	}
	if out == "" || out == "-" {
		fmt.Print(res)
	} else if err := os.WriteFile(out, []byte(res), 0o666); err != nil {
		return die(err)
	}
	return 0
}

func die(err error) int {
	slog.Error("", "err", err)
	return 1
}

func usage() {
	fmt.Print(`Process text files with Go templates

Usage:
  gomplate [flags]

Flags:
  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.
  -H, --datasource-header header     HTTP header field in 'alias=Name: value' form to be provided on HTTP-based data sources. Multiples can be set.
  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias ` + "`" + `.` + "`" + ` to set the root context.
      --plugin strings               plug in an external command as a function in name=path form. Can be specified multiple times
  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])
  -i, --in string                    Template string to process (alternative to --file and --input-dir)
      --input-dir directory          directory which is examined recursively for templates (alternative to --file and --in)
      --exclude strings              glob of files to not parse
      --exclude-processing strings   glob of files to be copied without parsing
      --include strings              glob of files to parse
  -o, --out file                     output file name. Omit to use standard output. (default [-])
  -t, --template strings             Additional template file(s)
      --output-dir directory         directory to store the processed templates. Only used for --input-dir (default ".")
      --output-map string            Template string to map the input file to an output path
      --chmod string                 set the mode for output file(s). Omit to inherit from input file(s)
      --exec-pipe                    pipe the output to the post-run exec command
      --left-delim delimiter         override the default left-delimiter [$GOMPLATE_LEFT_DELIM] (default "{{")
      --right-delim delimiter        override the default right-delimiter [$GOMPLATE_RIGHT_DELIM] (default "}}")
      --missing-key string           Control the behavior during execution if a map is indexed with a key that is not present in the map. error (default) - return an error, zero - fallback to zero value, default/invalid - print <no value> (default "error")
      --experimental                 enable experimental features [$GOMPLATE_EXPERIMENTAL]
  -V, --verbose                      output extra information about what gomplate is doing
      --config string                config file (overridden by commandline flags) (default ".gomplate.yaml")
  -h, --help                         help for gomplate
  -v, --version                      version for gomplate
`)
}

func (a *app) render(name, text string, data any) (string, error) {
	text = normalizeTemplate(text)
	opt := "missingkey=error"
	switch a.missing {
	case "zero":
		opt = "missingkey=zero"
	case "default", "invalid":
		opt = "missingkey=default"
	}
	t := template.New(filepath.Base(name)).Delims(a.left, a.right).Option(opt).Funcs(a.funcs(nil))
	t.Funcs(template.FuncMap{"include": a.include, "tmpl_Exec": tmplNS{t: t, app: a}.Exec, "tmpl_Inline": tmplNS{t: t, app: a}.Inline, "tmpl_Path": tmplNS{t: t, app: a}.Path, "tmpl_PathDir": tmplNS{t: t, app: a}.PathDir})
	var err error
	for _, f := range a.templates {
		b, e := os.ReadFile(f)
		if e != nil {
			return "", e
		}
		if _, err = t.New(filepath.Base(f)).Parse(string(b)); err != nil {
			return "", err
		}
	}
	t, err = t.Parse(text)
	if err != nil {
		return "", err
	}
	t.Funcs(template.FuncMap{"tmpl_Exec": tmplNS{t: t, app: a}.Exec, "tmpl_Inline": tmplNS{t: t, app: a}.Inline, "tmpl_Path": tmplNS{t: t, app: a}.Path, "tmpl_PathDir": tmplNS{t: t, app: a}.PathDir})
	var b bytes.Buffer
	err = t.Execute(&b, data)
	return b.String(), err
}

func (a *app) funcs(t *template.Template) template.FuncMap {
	f := template.FuncMap{}
	math := mathNS{}
	str := stringNS{}
	conv := convNS{}
	coll := collNS{}
	data := dataNS{}
	env := envNS{}
	pathn := pathNS{}
	filepathn := filepathNS{}
	reg := regexpNS{}
	timens := timeNS{}
	filens := fileNS{}
	netns := netNS{}
	base64ns := base64NS{}
	cryptons := cryptoNS{}
	random := randomNS{}
	test := testNS{}
	f["math_Abs"], f["math_Add"], f["math_Ceil"], f["math_Div"], f["math_Floor"] = math.Abs, math.Add, math.Ceil, math.Div, math.Floor
	f["math_IsFloat"], f["math_IsInt"], f["math_IsNum"], f["math_Max"], f["math_Min"] = math.IsFloat, math.IsInt, math.IsNum, math.Max, math.Min
	f["math_Mul"], f["math_Pow"], f["math_Rem"], f["math_Round"], f["math_Seq"], f["math_Sub"] = math.Mul, math.Pow, math.Rem, math.Round, math.Seq, math.Sub
	f["strings_Abbrev"], f["strings_Contains"], f["strings_HasPrefix"], f["strings_HasSuffix"], f["strings_Indent"] = str.Abbrev, str.Contains, str.HasPrefix, str.HasSuffix, str.Indent
	f["strings_SkipLines"], f["strings_Split"], f["strings_SplitN"], f["strings_Quote"], f["strings_Repeat"] = str.SkipLines, str.Split, str.SplitN, str.Quote, str.Repeat
	f["strings_ReplaceAll"], f["strings_Slug"], f["strings_ShellQuote"], f["strings_Squote"], f["strings_Title"] = str.ReplaceAll, str.Slug, str.ShellQuote, str.Squote, str.Title
	f["strings_ToLower"], f["strings_ToUpper"], f["strings_Trim"], f["strings_TrimLeft"], f["strings_TrimPrefix"] = str.ToLower, str.ToUpper, str.Trim, str.TrimLeft, str.TrimPrefix
	f["strings_TrimRight"], f["strings_TrimSpace"], f["strings_TrimSuffix"], f["strings_Trunc"], f["strings_CamelCase"] = str.TrimRight, str.TrimSpace, str.TrimSuffix, str.Trunc, str.CamelCase
	f["strings_SnakeCase"], f["strings_KebabCase"], f["strings_WordWrap"], f["strings_RuneCount"] = str.SnakeCase, str.KebabCase, str.WordWrap, str.RuneCount
	f["conv_Bool"], f["conv_Default"], f["conv_Join"], f["conv_URL"], f["conv_ParseInt"], f["conv_ParseFloat"], f["conv_ParseUint"], f["conv_Atoi"] = conv.Bool, conv.Default, conv.Join, conv.URL, conv.ParseInt, conv.ParseFloat, conv.ParseUint, conv.Atoi
	f["conv_ToBool"], f["conv_ToBools"], f["conv_ToInt64"], f["conv_ToInt"], f["conv_ToInt64s"], f["conv_ToInts"] = conv.ToBool, conv.ToBools, conv.ToInt64, conv.ToInt, conv.ToInt64s, conv.ToInts
	f["conv_ToFloat64"], f["conv_ToFloat64s"], f["conv_ToString"], f["conv_ToStrings"] = conv.ToFloat64, conv.ToFloat64s, conv.ToString, conv.ToStrings
	f["coll_Dict"], f["coll_Slice"], f["coll_GoSlice"], f["coll_Has"], f["coll_Index"], f["coll_Keys"], f["coll_Values"] = coll.Dict, coll.Slice, coll.GoSlice, coll.Has, coll.Index, coll.Keys, coll.Values
	f["coll_Append"], f["coll_Prepend"], f["coll_Uniq"], f["coll_Flatten"], f["coll_Reverse"], f["coll_Sort"], f["coll_Merge"] = coll.Append, coll.Prepend, coll.Uniq, coll.Flatten, coll.Reverse, coll.Sort, coll.Merge
	f["coll_Pick"], f["coll_Omit"], f["coll_Set"], f["coll_Unset"] = coll.Pick, coll.Omit, coll.Set, coll.Unset
	f["data_JSON"], f["data_JSONArray"], f["data_YAML"], f["data_YAMLArray"], f["data_TOML"], f["data_CSV"], f["data_CSVByRow"], f["data_CSVByColumn"] = data.JSON, data.JSONArray, data.YAML, data.YAMLArray, data.TOML, data.CSV, data.CSVByRow, data.CSVByColumn
	f["data_ToJSON"], f["data_ToJSONPretty"], f["data_ToYAML"], f["data_ToTOML"], f["data_ToCSV"] = data.ToJSON, data.ToJSONPretty, data.ToYAML, data.ToTOML, data.ToCSV
	f["env_Getenv"], f["env_Env"], f["env_HasEnv"], f["env_ExpandEnv"] = env.Getenv, env.Env, env.HasEnv, env.ExpandEnv
	f["path_Base"], f["path_Clean"], f["path_Dir"], f["path_Ext"], f["path_IsAbs"], f["path_Join"], f["path_Match"], f["path_Split"] = pathn.Base, pathn.Clean, pathn.Dir, pathn.Ext, pathn.IsAbs, pathn.Join, pathn.Match, pathn.Split
	f["filepath_Base"], f["filepath_Clean"], f["filepath_Dir"], f["filepath_Ext"], f["filepath_FromSlash"], f["filepath_IsAbs"], f["filepath_Join"], f["filepath_Match"], f["filepath_Rel"], f["filepath_Split"], f["filepath_ToSlash"], f["filepath_VolumeName"] = filepathn.Base, filepathn.Clean, filepathn.Dir, filepathn.Ext, filepathn.FromSlash, filepathn.IsAbs, filepathn.Join, filepathn.Match, filepathn.Rel, filepathn.Split, filepathn.ToSlash, filepathn.VolumeName
	f["regexp_Find"], f["regexp_FindAll"], f["regexp_Match"], f["regexp_QuoteMeta"], f["regexp_Replace"], f["regexp_ReplaceLiteral"], f["regexp_Split"] = reg.Find, reg.FindAll, reg.Match, reg.QuoteMeta, reg.Replace, reg.ReplaceLiteral, reg.Split
	f["time_Now"], f["time_Parse"], f["time_ParseDuration"], f["time_ParseLocal"], f["time_ParseInLocation"], f["time_Since"], f["time_Unix"], f["time_Until"], f["time_ZoneName"], f["time_ZoneOffset"] = timens.Now, timens.Parse, timens.ParseDuration, timens.ParseLocal, timens.ParseInLocation, timens.Since, timens.Unix, timens.Until, timens.ZoneName, timens.ZoneOffset
	f["file_Exists"], f["file_IsDir"], f["file_Read"], f["file_ReadDir"], f["file_Stat"], f["file_Walk"], f["file_Write"] = filens.Exists, filens.IsDir, filens.Read, filens.ReadDir, filens.Stat, filens.Walk, filens.Write
	f["net_LookupIP"], f["net_LookupIPs"], f["net_LookupCNAME"], f["net_LookupTXT"], f["net_LookupSRV"], f["net_LookupSRVs"], f["net_ParseAddr"], f["net_ParsePrefix"], f["net_ParseRange"] = netns.LookupIP, netns.LookupIPs, netns.LookupCNAME, netns.LookupTXT, netns.LookupSRV, netns.LookupSRVs, netns.ParseAddr, netns.ParsePrefix, netns.ParseRange
	f["base64_Encode"], f["base64_Decode"], f["base64_DecodeBytes"] = base64ns.Encode, base64ns.Decode, base64ns.DecodeBytes
	f["crypto_MD5"], f["crypto_SHA1"], f["crypto_SHA224"], f["crypto_SHA256"], f["crypto_SHA384"], f["crypto_SHA512"], f["crypto_SHA512_224"], f["crypto_SHA512_256"], f["crypto_SHA1Bytes"], f["crypto_SHA256Bytes"], f["crypto_PBKDF2"] = cryptons.MD5, cryptons.SHA1, cryptons.SHA224, cryptons.SHA256, cryptons.SHA384, cryptons.SHA512, cryptons.SHA512_224, cryptons.SHA512_256, cryptons.SHA1Bytes, cryptons.SHA256Bytes, cryptons.PBKDF2
	f["random_ASCII"], f["random_Alpha"], f["random_AlphaNum"], f["random_String"], f["random_Item"], f["random_Number"], f["random_Float"] = random.ASCII, random.Alpha, random.AlphaNum, random.String, random.Item, random.Number, random.Float
	f["test_Assert"], f["test_Fail"], f["test_IsKind"], f["test_Kind"], f["test_Required"], f["test_Ternary"] = test.Assert, test.Fail, test.IsKind, test.Kind, test.Required, test.Ternary
	f["ds"], f["datasource"] = a.datasource, a.datasource
	f["datasourceExists"] = func(name string) bool { _, ok := a.datasources[name]; return ok }
	f["datasourceReachable"] = func(name string) bool { _, err := a.datasource(name); return err == nil }
	f["listDatasources"] = func() []string { keys := []string{}; for k := range a.datasources { keys = append(keys, k) }; sort.Strings(keys); return keys }
	f["defineDatasource"] = func(alias, u string) string { a.datasources[alias] = u; return "" }
	f["getenv"] = env.Getenv
	f["expandEnv"] = env.ExpandEnv
	f["add"], f["mul"], f["sub"], f["div"], f["mod"], f["rem"] = math.Add, math.Mul, math.Sub, math.Div, math.Rem, math.Rem
	f["seq"] = math.Seq
	f["toUpper"], f["toLower"], f["contains"], f["hasPrefix"], f["hasSuffix"] = str.ToUpper, str.ToLower, str.Contains, str.HasPrefix, str.HasSuffix
	f["trim"], f["trimSpace"], f["replaceAll"], f["split"], f["join"] = str.Trim, str.TrimSpace, str.ReplaceAll, str.Split, conv.Join
	f["default"] = conv.Default
	f["dict"], f["slice"], f["has"], f["keys"], f["values"] = coll.Dict, coll.Slice, coll.Has, coll.Keys, coll.Values
	f["json"], f["jsonArray"], f["yaml"], f["yamlArray"], f["toml"], f["csv"], f["csvByRow"], f["csvByColumn"] = data.JSON, data.JSONArray, data.YAML, data.YAMLArray, data.TOML, data.CSV, data.CSVByRow, data.CSVByColumn
	f["toJSON"], f["toJSONPretty"], f["toYAML"], f["toTOML"], f["toCSV"] = data.ToJSON, data.ToJSONPretty, data.ToYAML, data.ToTOML, data.ToCSV
	f["append"], f["prepend"], f["uniq"], f["flatten"], f["reverse"], f["sort"], f["merge"] = coll.Append, coll.Prepend, coll.Uniq, coll.Flatten, coll.Reverse, coll.Sort, coll.Merge
	f["pick"], f["omit"], f["set"], f["unset"], f["index"] = coll.Pick, coll.Omit, coll.Set, coll.Unset, coll.Index
	f["quote"], f["shellQuote"], f["squote"] = str.Quote, str.ShellQuote, str.Squote
	return f
}

func normalizeTemplate(s string) string {
	names := []string{"math", "strings", "conv", "coll", "data", "env", "path", "filepath", "regexp", "time", "file", "net", "base64", "crypto", "random", "test", "tmpl"}
	for _, n := range names {
		s = strings.ReplaceAll(s, n+".", n+"_")
	}
	return s
}

func splitAliasURL(s string) (string, string, error) {
	i := strings.Index(s, "=")
	if i < 1 {
		base := filepath.Base(stripFileURL(s))
		ext := filepath.Ext(base)
		alias := strings.TrimSuffix(base, ext)
		if alias == "" {
			return "", "", fmt.Errorf("invalid datasource %q", s)
		}
		return alias, s, nil
	}
	return s[:i], s[i+1:], nil
}

func readPath(p string) ([]byte, error) {
	if p == "-" || p == "" {
		return io.ReadAll(os.Stdin)
	}
	return os.ReadFile(stripFileURL(p))
}

func stripFileURL(p string) string {
	if strings.HasPrefix(p, "file://") {
		u, err := url.Parse(p)
		if err == nil {
			return u.Path
		}
	}
	return p
}

func envMap() map[string]string {
	m := map[string]string{}
	for _, e := range os.Environ() {
		if i := strings.Index(e, "="); i >= 0 {
			m[e[:i]] = e[i+1:]
		}
	}
	return m
}

func (a *app) datasource(name string) (any, error) {
	u, ok := a.datasources[name]
	if !ok {
		return nil, fmt.Errorf("datasource %q is not defined", name)
	}
	return a.load(u)
}

func (a *app) load(u string) (any, error) {
	if v, ok := a.cache[u]; ok {
		return v, nil
	}
	var b []byte
	var err error
	if strings.HasPrefix(u, "env://") {
		key := strings.TrimPrefix(u, "env://")
		key = strings.TrimPrefix(key, "/")
		raw := os.Getenv(key)
		v, err := parseDataByName(key+".json", []byte(raw))
		if err == nil {
			return v, nil
		}
		return raw, nil
	}
	if strings.HasPrefix(u, "env:") {
		return os.Getenv(strings.TrimPrefix(u, "env:")), nil
	}
	if u == "stdin:" {
		b, err = io.ReadAll(os.Stdin)
	}
	if b == nil && (strings.HasPrefix(u, "file://") || !strings.Contains(u, "://")) {
		b, err = os.ReadFile(stripFileURL(u))
	} else if b == nil {
		return nil, fmt.Errorf("unsupported URL scheme for %s", u)
	}
	if err != nil {
		return nil, err
	}
	v, err := parseDataByName(stripFileURL(u), b)
	if err != nil {
		return nil, err
	}
	a.cache[u] = v
	return v, nil
}

func parseDataByName(name string, b []byte) (any, error) {
	ext := strings.ToLower(filepath.Ext(name))
	switch ext {
	case ".json":
		var v any
		err := json.Unmarshal(b, &v)
		return v, err
	case ".csv":
		return dataNS{}.CSV(string(b))
	case ".yaml", ".yml":
		return parseSimpleYAML(string(b)), nil
	default:
		var v any
		if json.Unmarshal(b, &v) == nil {
			return v, nil
		}
		return string(b), nil
	}
}

func (a *app) include(name string) (any, error) {
	if _, ok := a.datasources[name]; ok {
		return a.datasource(name)
	}
	b, err := readPath(name)
	if err != nil {
		return nil, err
	}
	return string(b), nil
}

func (a *app) processDir(inDir, outDir, outputMap string, includes, excludes, exclProc []string, chmod string, data any) error {
	return filepath.WalkDir(inDir, func(p string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() {
			return err
		}
		rel, _ := filepath.Rel(inDir, p)
		if len(includes) > 0 && !matchesAny(rel, includes) {
			return nil
		}
		if matchesAny(rel, excludes) {
			return nil
		}
		dest := filepath.Join(outDir, rel)
		if outputMap != "" {
			a.tmplPath = p
			mapped, err := a.render("<output-map>", outputMap, map[string]any{"in": rel, "ctx": data})
			if err == nil && mapped != "" {
				dest = mapped
			}
		}
		if err := os.MkdirAll(filepath.Dir(dest), 0o777); err != nil {
			return err
		}
		info, _ := d.Info()
		mode := os.FileMode(0o666)
		if info != nil {
			mode = info.Mode()
		}
		if chmod != "" {
			if n, err := strconv.ParseUint(chmod, 8, 32); err == nil {
				mode = os.FileMode(n)
			}
		}
		b, err := os.ReadFile(p)
		if err != nil {
			return err
		}
		if matchesAny(rel, exclProc) {
			return os.WriteFile(dest, b, mode)
		}
		a.tmplPath = p
		res, err := a.render(p, string(b), data)
		if err != nil {
			return err
		}
		return os.WriteFile(dest, []byte(res), mode)
	})
}

func matchesAny(s string, pats []string) bool {
	for _, p := range pats {
		if ok, _ := filepath.Match(p, s); ok {
			return true
		}
		if ok, _ := filepath.Match(p, filepath.Base(s)); ok {
			return true
		}
	}
	return false
}

type mathNS struct{}

func toFloat(v any) float64 {
	switch x := v.(type) {
	case int:
		return float64(x)
	case int64:
		return float64(x)
	case float64:
		return x
	case float32:
		return float64(x)
	case uint64:
		return float64(x)
	case string:
		x = strings.ReplaceAll(x, ",", "")
		if b, err := strconv.ParseBool(x); err == nil {
			if b { return 1 }
			return 0
		}
		if i, err := strconv.ParseInt(x, 0, 64); err == nil {
			return float64(i)
		}
		f, _ := strconv.ParseFloat(x, 64)
		return f
	case bool:
		if x { return 1 }
		return 0
	default:
		r := reflect.ValueOf(v)
		if r.IsValid() {
			switch r.Kind() {
			case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
				return float64(r.Int())
			case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
				return float64(r.Uint())
			case reflect.Float32, reflect.Float64:
				return r.Float()
			}
		}
	}
	return 0
}

func isIntLike(v any) bool {
	switch v.(type) {
	case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64:
		return true
	}
	return false
}

func cleanNum(f float64, ints bool) any {
	if ints || f == mathpkg.Trunc(f) {
		return int64(f)
	}
	return f
}

func (mathNS) Abs(v any) any       { f := mathpkg.Abs(toFloat(v)); return cleanNum(f, isIntLike(v)) }
func (mathNS) Add(v ...any) any    { f := 0.0; ints := true; for _, x := range v { ints = ints && isIntLike(x); f += toFloat(x) }; return cleanNum(f, ints) }
func (mathNS) Ceil(v any) float64  { return mathpkg.Ceil(toFloat(v)) }
func (mathNS) Floor(v any) float64 { return mathpkg.Floor(toFloat(v)) }
func (mathNS) Div(a, b any) any    { return toFloat(a) / toFloat(b) }
func (mathNS) IsFloat(v any) bool  { if _, ok := v.(float64); ok { return true }; if s, ok := v.(string); ok { _, e := strconv.ParseFloat(strings.ReplaceAll(s, ",", ""), 64); return e == nil && strings.ContainsAny(s, ".eE") }; return false }
func (mathNS) IsInt(v any) bool    { if isIntLike(v) { return true }; if s, ok := v.(string); ok { _, e := strconv.ParseInt(strings.ReplaceAll(s, ",", ""), 0, 64); return e == nil }; return false }
func (m mathNS) IsNum(v any) bool  { return m.IsInt(v) || m.IsFloat(v) }
func (mathNS) Max(v ...any) any    { m := toFloat(v[0]); ints := true; for _, x := range v { ints = ints && isIntLike(x); if toFloat(x) > m { m = toFloat(x) } }; return cleanNum(m, ints) }
func (mathNS) Min(v ...any) any    { m := toFloat(v[0]); ints := true; for _, x := range v { ints = ints && isIntLike(x); if toFloat(x) < m { m = toFloat(x) } }; return cleanNum(m, ints) }
func (mathNS) Mul(v ...any) any    { f := 1.0; ints := true; for _, x := range v { ints = ints && isIntLike(x); f *= toFloat(x) }; return cleanNum(f, ints) }
func (mathNS) Pow(a, b any) float64 { return mathpkg.Pow(toFloat(a), toFloat(b)) }
func (mathNS) Rem(a, b any) int64  { return int64(toFloat(a)) % int64(toFloat(b)) }
func (mathNS) Round(v any) float64 { return mathpkg.Round(toFloat(v)) }
func (mathNS) Sub(v ...any) any    { if len(v) == 0 { return int64(0) }; f := toFloat(v[0]); ints := isIntLike(v[0]); for _, x := range v[1:] { ints = ints && isIntLike(x); f -= toFloat(x) }; return cleanNum(f, ints) }
func (mathNS) Seq(args ...int64) []int64 {
	start, end, st := int64(0), int64(0), int64(1)
	switch len(args) {
	case 0:
		return []int64{}
	case 1:
		end = args[0]
		if end < 1 {
			st = -1
		} else {
			start = 1
		}
	default:
		start, end = args[0], args[1]
		if len(args) > 2 {
			st = args[2]
		}
	}
	if st == 0 {
		return []int64{}
	}
	if end < start && st > 0 {
		st = -st
	}
	if end > start && st < 0 {
		st = -st
	}
	end -= (end - start) % st
	seq := []int64{start}
	for seq[len(seq)-1] != end {
		seq = append(seq, seq[len(seq)-1]+st)
	}
	return seq
}

type envNS struct{}
func (envNS) Getenv(k string, def ...string) string { if v, ok := os.LookupEnv(k); ok { return v }; if len(def) > 0 { return def[0] }; return "" }
func (envNS) Env(k string, def ...string) string    { return envNS{}.Getenv(k, def...) }
func (envNS) HasEnv(k string) bool                  { _, ok := os.LookupEnv(k); return ok }
func (envNS) ExpandEnv(s string) string             { return os.ExpandEnv(s) }

type stringNS struct{}
func (stringNS) Abbrev(args ...any) string { s:=fmt.Sprint(args[len(args)-1]); n:=int(toFloat(args[0])); r:=[]rune(s); if len(r) <= n { return s }; if n <= 3 { return string(r[:n]) }; return string(r[:n-3]) + "..." }
func (stringNS) Contains(substr, s string) bool { return strings.Contains(s, substr) }
func (stringNS) HasPrefix(prefix, s string) bool { return strings.HasPrefix(s, prefix) }
func (stringNS) HasSuffix(suffix, s string) bool { return strings.HasSuffix(s, suffix) }
func (stringNS) Indent(args ...any) string { s:=fmt.Sprint(args[len(args)-1]); pad := ""; if n,ok:=args[0].(int); ok { pad=strings.Repeat(" ",n) } else if isIntLike(args[0]) { pad=strings.Repeat(" ",int(toFloat(args[0]))) } else { pad=fmt.Sprint(args[0]) }; lines := strings.Split(s, "\n"); for i := range lines { if lines[i] != "" { lines[i] = pad + lines[i] } }; return strings.Join(lines, "\n") }
func (stringNS) SkipLines(n int, s string) string { lines := strings.Split(s, "\n"); if n >= len(lines) { return "" }; return strings.Join(lines[n:], "\n") }
func (stringNS) Split(sep, s string) []string { return strings.Split(s, sep) }
func (stringNS) SplitN(sep string, n int, s string) []string { return strings.SplitN(s, sep, n) }
func (stringNS) Quote(s string) string { return strconv.Quote(s) }
func (stringNS) Repeat(count int, s string) string { return strings.Repeat(s, count) }
func (stringNS) ReplaceAll(old, new, s string) string { return strings.ReplaceAll(s, old, new) }
func (stringNS) Slug(s string) string { return strings.Trim(strings.Map(func(r rune) rune { if unicode.IsLetter(r) || unicode.IsDigit(r) { return unicode.ToLower(r) }; return '-' }, collapseSpace(s)), "-") }
func (stringNS) ShellQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "'\\''") + "'" }
func (stringNS) Squote(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }
func (stringNS) Title(s string) string { return strings.Title(s) }
func (stringNS) ToLower(s string) string { return strings.ToLower(s) }
func (stringNS) ToUpper(s string) string { return strings.ToUpper(s) }
func (stringNS) Trim(cutset, s string) string { return strings.Trim(s, cutset) }
func (stringNS) TrimLeft(cutset, s string) string { return strings.TrimLeft(s, cutset) }
func (stringNS) TrimPrefix(prefix, s string) string { return strings.TrimPrefix(s, prefix) }
func (stringNS) TrimRight(cutset, s string) string { return strings.TrimRight(s, cutset) }
func (stringNS) TrimSpace(s string) string { return strings.TrimSpace(s) }
func (stringNS) TrimSuffix(suffix, s string) string { return strings.TrimSuffix(s, suffix) }
func (stringNS) Trunc(n int, s string) string { r := []rune(s); if len(r) <= n { return s }; return string(r[:n]) }
func (stringNS) CamelCase(s string) string { parts := words(s); for i := range parts { parts[i] = strings.Title(strings.ToLower(parts[i])) }; return strings.Join(parts, "") }
func (stringNS) SnakeCase(s string) string { return strings.ToLower(strings.Join(words(s), "_")) }
func (stringNS) KebabCase(s string) string { return strings.ToLower(strings.Join(words(s), "-")) }
func (stringNS) WordWrap(args ...any) string { n:=int(toFloat(args[0])); s:=fmt.Sprint(args[len(args)-1]); var out []string; for _, line := range strings.Split(s, "\n") { for len([]rune(line)) > n { i := n; out = append(out, line[:i]); line = line[i:] }; out = append(out, line) }; return strings.Join(out, "\n") }
func (stringNS) RuneCount(s string) int { return len([]rune(s)) }

func collapseSpace(s string) string { return strings.Join(strings.Fields(s), " ") }
func words(s string) []string {
	re := regexp.MustCompile(`[A-Za-z0-9]+`)
	return re.FindAllString(s, -1)
}

type convNS struct{}
func (convNS) Bool(v any) bool { return toBool(v) }
func (convNS) Default(def, v any) any { if isEmpty(v) { return def }; return v }
func (convNS) Join(v any, sep string) string { parts := []string{}; rv := reflect.ValueOf(v); if rv.IsValid() && (rv.Kind() == reflect.Slice || rv.Kind() == reflect.Array) { for i := 0; i < rv.Len(); i++ { parts = append(parts, fmt.Sprint(rv.Index(i).Interface())) } } else { parts = strings.Fields(fmt.Sprint(v)) }; return strings.Join(parts, sep) }
func (convNS) URL(s string) (*url.URL, error) { return url.Parse(s) }
func (convNS) ParseInt(s string, args ...int) (int64, error) { base, bits := 0, 64; if len(args)>0 { base=args[0] }; if len(args)>1 { bits=args[1] }; return strconv.ParseInt(s, base, bits) }
func (convNS) ParseUint(s string, args ...int) (uint64, error) { base,bits:=0,64; if len(args)>0{base=args[0]}; if len(args)>1{bits=args[1]}; return strconv.ParseUint(s,base,bits) }
func (convNS) ParseFloat(s string, bits ...int) (float64, error) { b:=64; if len(bits)>0{b=bits[0]}; return strconv.ParseFloat(s,b) }
func (convNS) Atoi(s string) (int, error) { return strconv.Atoi(s) }
func (convNS) ToBool(v any) bool { return toBool(v) }
func (convNS) ToInt64(v any) int64 { return int64(toFloat(v)) }
func (convNS) ToInt(v any) int { return int(toFloat(v)) }
func (convNS) ToFloat64(v any) float64 { return toFloat(v) }
func (convNS) ToString(v any) string { return fmt.Sprint(v) }
func (c convNS) ToStrings(v ...any) []string { return mapArgs(v, func(x any) string { return c.ToString(x) }) }
func (c convNS) ToInts(v ...any) []int { return mapArgs(v, func(x any) int { return c.ToInt(x) }) }
func (c convNS) ToInt64s(v ...any) []int64 { return mapArgs(v, func(x any) int64 { return c.ToInt64(x) }) }
func (c convNS) ToFloat64s(v ...any) []float64 { return mapArgs(v, func(x any) float64 { return c.ToFloat64(x) }) }
func (c convNS) ToBools(v ...any) []bool { return mapArgs(v, func(x any) bool { return c.ToBool(x) }) }

func toBool(v any) bool { switch x:=v.(type){case bool:return x; case string: s:=strings.ToLower(strings.TrimSpace(x)); if s=="yes"||s=="y"||s=="on"||s=="1"||s=="true"{return true}; if s=="no"||s=="n"||s=="off"||s=="0"||s=="false"||s==""{return false}; return toFloat(s)!=0; default: return !isEmpty(v)} }
func isEmpty(v any) bool { if v==nil { return true }; rv:=reflect.ValueOf(v); switch rv.Kind(){case reflect.String,reflect.Array,reflect.Slice,reflect.Map:return rv.Len()==0; case reflect.Bool:return !rv.Bool(); case reflect.Int,reflect.Int64,reflect.Float64:return toFloat(v)==0}; return false }
func mapSlice[T any](v any, fn func(any) T) []T { out:=[]T{}; rv:=reflect.ValueOf(v); if rv.IsValid()&&(rv.Kind()==reflect.Slice||rv.Kind()==reflect.Array){for i:=0;i<rv.Len();i++{out=append(out,fn(rv.Index(i).Interface()))}}; return out }
func mapArgs[T any](v []any, fn func(any) T) []T { out:=[]T{}; if len(v)==1 { rv:=reflect.ValueOf(v[0]); if rv.IsValid()&&(rv.Kind()==reflect.Slice||rv.Kind()==reflect.Array){for i:=0;i<rv.Len();i++{out=append(out,fn(rv.Index(i).Interface()))}; return out } }; for _,x:=range v{out=append(out,fn(x))}; return out }

type collNS struct{}
func (collNS) Dict(vals ...any) (map[string]any, error) { if len(vals)%2 != 0 { return nil, errors.New("dict requires an even number of args") }; m:=map[string]any{}; for i:=0;i<len(vals);i+=2{m[fmt.Sprint(vals[i])] = vals[i+1]}; return m,nil }
func (collNS) Slice(vals ...any) []any { return vals }
func (collNS) GoSlice(vals ...any) []any { return vals }
func (collNS) Has(hay any, needle any) bool { rv:=reflect.ValueOf(hay); if rv.IsValid(){switch rv.Kind(){case reflect.Map: return rv.MapIndex(reflect.ValueOf(needle)).IsValid(); case reflect.Slice,reflect.Array: for i:=0;i<rv.Len();i++{ if reflect.DeepEqual(rv.Index(i).Interface(), needle){return true}}}}; return strings.Contains(fmt.Sprint(hay), fmt.Sprint(needle)) }
func (collNS) Index(args ...any) any { if len(args)==0{return nil}; cur:=args[len(args)-1]; for _,k:=range args[:len(args)-1]{ cur = indexOne(cur,k) }; return cur }
func (collNS) Keys(v ...any) []string { keys:=[]string{}; for _,one:=range v{rv:=reflect.ValueOf(one); if rv.IsValid()&&rv.Kind()==reflect.Map{for _,k:=range rv.MapKeys(){keys=append(keys,fmt.Sprint(k.Interface()))}}}; sort.Strings(keys); return keys }
func (collNS) Values(v ...any) []any { out:=[]any{}; for _,one:=range v{rv:=reflect.ValueOf(one); if rv.IsValid()&&rv.Kind()==reflect.Map{for _,k:=range rv.MapKeys(){out=append(out,rv.MapIndex(k).Interface())}}}; return out }
func (collNS) Append(vals ...any) []any { if len(vals)==0{return nil}; base:=toAnySlice(vals[len(vals)-1]); return append(base, vals[:len(vals)-1]...) }
func (collNS) Prepend(vals ...any) []any { if len(vals)==0{return nil}; base:=toAnySlice(vals[len(vals)-1]); return append(vals[:len(vals)-1], base...) }
func (collNS) Uniq(v any) []any { seen:=map[string]bool{}; out:=[]any{}; for _,x:=range toAnySlice(v){k:=fmt.Sprintf("%#v",x); if !seen[k]{seen[k]=true; out=append(out,x)}}; return out }
func (collNS) Flatten(args ...any) []any { v:=args[len(args)-1]; out:=[]any{}; for _,x:=range toAnySlice(v){rv:=reflect.ValueOf(x); if rv.IsValid()&&(rv.Kind()==reflect.Slice||rv.Kind()==reflect.Array){out=append(out, collNS{}.Flatten(x)...)} else {out=append(out,x)}}; return out }
func (collNS) Reverse(v any) []any { out:=toAnySlice(v); for i,j:=0,len(out)-1;i<j;i,j=i+1,j-1{out[i],out[j]=out[j],out[i]}; return out }
func (collNS) Sort(args ...any) []string { v:=args[len(args)-1]; s:=[]string{}; for _,x:=range toAnySlice(v){s=append(s,fmt.Sprint(x))}; sort.Strings(s); return s }
func (collNS) Merge(ms ...map[string]any) map[string]any { out:=map[string]any{}; for _,m:=range ms{for k,v:=range m{out[k]=v}}; return out }
func (collNS) Pick(args ...any) map[string]any { m:=asMap(args[len(args)-1]); keys:=expandKeys(args[:len(args)-1]); out:=map[string]any{}; for _,k:=range keys{if v,ok:=m[k];ok{out[k]=v}}; return out }
func (collNS) Omit(args ...any) map[string]any { m:=asMap(args[len(args)-1]); keys:=expandKeys(args[:len(args)-1]); omit:=map[string]bool{}; for _,k:=range keys{omit[k]=true}; out:=map[string]any{}; for k,v:=range m{if !omit[k]{out[k]=v}}; return out }
func (collNS) Set(k string, v any, m map[string]any) map[string]any { m[k]=v; return m }
func (collNS) Unset(k string, m map[string]any) map[string]any { delete(m,k); return m }

func indexOne(v any, k any) any { rv:=reflect.ValueOf(v); if !rv.IsValid(){return nil}; if rv.Kind()==reflect.Map{mv:=rv.MapIndex(reflect.ValueOf(k)); if mv.IsValid(){return mv.Interface()}; mv=rv.MapIndex(reflect.ValueOf(fmt.Sprint(k))); if mv.IsValid(){return mv.Interface()}}; if rv.Kind()==reflect.Slice||rv.Kind()==reflect.Array{ i:=int(toFloat(k)); if i>=0&&i<rv.Len(){return rv.Index(i).Interface()}}; return nil }
func toAnySlice(v any) []any { out:=[]any{}; rv:=reflect.ValueOf(v); if rv.IsValid()&&(rv.Kind()==reflect.Slice||rv.Kind()==reflect.Array){for i:=0;i<rv.Len();i++{out=append(out,rv.Index(i).Interface())}}; return out }
func asMap(v any) map[string]any { if m,ok:=v.(map[string]any); ok{return m}; out:=map[string]any{}; rv:=reflect.ValueOf(v); if rv.IsValid()&&rv.Kind()==reflect.Map{for _,k:=range rv.MapKeys(){out[fmt.Sprint(k.Interface())]=rv.MapIndex(k).Interface()}}; return out }
func expandKeys(v []any) []string { out:=[]string{}; for _,x:=range v{rv:=reflect.ValueOf(x); if rv.IsValid()&&(rv.Kind()==reflect.Slice||rv.Kind()==reflect.Array){for i:=0;i<rv.Len();i++{out=append(out,fmt.Sprint(rv.Index(i).Interface()))}}else{out=append(out,fmt.Sprint(x))}}; return out }

type dataNS struct{}
func (dataNS) JSON(s string) (any,error) { var v any; return v, json.Unmarshal([]byte(s), &v) }
func (dataNS) JSONArray(s string) ([]any,error) { var v []any; return v, json.Unmarshal([]byte(s), &v) }
func (dataNS) YAML(s string) any { return parseSimpleYAML(s) }
func (dataNS) YAMLArray(s string) []any { if a,ok:=parseSimpleYAML(s).([]any); ok { return a }; return nil }
func (dataNS) TOML(s string) any { return parseKeyVals(s) }
func (dataNS) CSV(s string) ([][]string,error) { r:=csv.NewReader(strings.NewReader(s)); return r.ReadAll() }
func (dataNS) CSVByRow(s string) ([]map[string]string,error) { rows,err:=csv.NewReader(strings.NewReader(s)).ReadAll(); if err!=nil||len(rows)==0{return nil,err}; out:=[]map[string]string{}; for _,r:=range rows[1:]{m:=map[string]string{}; for i,h:=range rows[0]{if i<len(r){m[h]=r[i]}}; out=append(out,m)}; return out,nil }
func (dataNS) CSVByColumn(s string) (map[string][]string,error) { rows,err:=csv.NewReader(strings.NewReader(s)).ReadAll(); if err!=nil||len(rows)==0{return nil,err}; out:=map[string][]string{}; for _,h:=range rows[0]{out[h]=[]string{}}; for _,r:=range rows[1:]{for i,h:=range rows[0]{if i<len(r){out[h]=append(out[h],r[i])}}}; return out,nil }
func (dataNS) ToJSON(v any) (string,error) { b,e:=json.Marshal(v); return string(b),e }
func (dataNS) ToJSONPretty(v any, indent ...string) (string,error) { ind:="  "; if len(indent)>0{ind=indent[0]}; b,e:=json.MarshalIndent(v,"",ind); return string(b),e }
func (dataNS) ToYAML(v any) string { return fmt.Sprint(v) }
func (dataNS) ToTOML(v any) string { return fmt.Sprint(v) }
func (dataNS) ToCSV(v any) (string,error) { var b bytes.Buffer; w:=csv.NewWriter(&b); for _,row:=range toAnySlice(v){ ss:=[]string{}; for _,c:=range toAnySlice(row){ss=append(ss,fmt.Sprint(c))}; _=w.Write(ss)}; w.Flush(); return b.String(),w.Error() }

func parseSimpleYAML(s string) any {
	m:=map[string]any{}; var arr []any
	sc:=bufio.NewScanner(strings.NewReader(s))
	for sc.Scan(){ line:=strings.TrimSpace(sc.Text()); if line==""||strings.HasPrefix(line,"#"){continue}; if strings.HasPrefix(line,"- "){arr=append(arr, parseScalar(strings.TrimSpace(line[2:]))); continue}; if i:=strings.Index(line,":"); i>=0{ k:=strings.TrimSpace(line[:i]); v:=strings.TrimSpace(line[i+1:]); m[k]=parseScalar(v)} }
	if arr!=nil && len(m)==0{return arr}; return m
}
func parseKeyVals(s string) map[string]any { m:=map[string]any{}; sc:=bufio.NewScanner(strings.NewReader(s)); for sc.Scan(){line:=strings.TrimSpace(sc.Text()); if line==""||strings.HasPrefix(line,"#"){continue}; if i:=strings.IndexAny(line,"=:"); i>=0{m[strings.TrimSpace(line[:i])]=parseScalar(strings.TrimSpace(line[i+1:]))}}; return m }
func parseScalar(v string) any { v=strings.Trim(v,"\"'"); if i,err:=strconv.ParseInt(v,10,64);err==nil{return i}; if f,err:=strconv.ParseFloat(v,64);err==nil{return f}; if b,err:=strconv.ParseBool(v);err==nil{return b}; return v }

type pathNS struct{}
func (pathNS) Base(s string) string { return path.Base(s) }
func (pathNS) Clean(s string) string { return path.Clean(s) }
func (pathNS) Dir(s string) string { return path.Dir(s) }
func (pathNS) Ext(s string) string { return path.Ext(s) }
func (pathNS) IsAbs(s string) bool { return path.IsAbs(s) }
func (pathNS) Join(e ...string) string { return path.Join(e...) }
func (pathNS) Match(p,s string)(bool,error){return path.Match(p,s)}
func (pathNS) Split(s string) []string { d,f:=path.Split(s); return []string{d,f} }

type filepathNS struct{}
func (filepathNS) Base(s string) string { return filepath.Base(s) }
func (filepathNS) Clean(s string) string { return filepath.Clean(s) }
func (filepathNS) Dir(s string) string { return filepath.Dir(s) }
func (filepathNS) Ext(s string) string { return filepath.Ext(s) }
func (filepathNS) FromSlash(s string) string { return filepath.FromSlash(s) }
func (filepathNS) IsAbs(s string) bool { return filepath.IsAbs(s) }
func (filepathNS) Join(e ...string) string { return filepath.Join(e...) }
func (filepathNS) Match(p,s string)(bool,error){return filepath.Match(p,s)}
func (filepathNS) Rel(b,t string)(string,error){return filepath.Rel(b,t)}
func (filepathNS) Split(s string) []string { d,f:=filepath.Split(s); return []string{d,f} }
func (filepathNS) ToSlash(s string) string { return filepath.ToSlash(s) }
func (filepathNS) VolumeName(s string) string { return filepath.VolumeName(s) }

type regexpNS struct{}
func (regexpNS) Find(expr,s string)(string,error){r,e:=regexp.Compile(expr); if e!=nil{return "",e}; return r.FindString(s),nil}
func (regexpNS) FindAll(expr string,n int,s string)([]string,error){r,e:=regexp.Compile(expr); if e!=nil{return nil,e}; return r.FindAllString(s,n),nil}
func (regexpNS) Match(expr,s string)(bool,error){return regexp.MatchString(expr,s)}
func (regexpNS) QuoteMeta(s string)string{return regexp.QuoteMeta(s)}
func (regexpNS) Replace(expr,repl,s string)(string,error){r,e:=regexp.Compile(expr); if e!=nil{return "",e}; return r.ReplaceAllString(s,repl),nil}
func (regexpNS) ReplaceLiteral(expr,repl,s string)(string,error){r,e:=regexp.Compile(expr); if e!=nil{return "",e}; return r.ReplaceAllLiteralString(s,repl),nil}
func (regexpNS) Split(expr string,n int,s string)([]string,error){r,e:=regexp.Compile(expr); if e!=nil{return nil,e}; return r.Split(s,n),nil}

type timeNS struct{}
func (timeNS) Now() time.Time { return time.Now() }
func (timeNS) Parse(layout,value string)(time.Time,error){return time.Parse(layout,value)}
func (timeNS) ParseDuration(s string)(time.Duration,error){return time.ParseDuration(s)}
func (timeNS) ParseLocal(layout,value string)(time.Time,error){return time.ParseInLocation(layout,value,time.Local)}
func (timeNS) ParseInLocation(layout,value,loc string)(time.Time,error){l,e:=time.LoadLocation(loc); if e!=nil{return time.Time{},e}; return time.ParseInLocation(layout,value,l)}
func (timeNS) Since(t time.Time) time.Duration { return time.Since(t) }
func (timeNS) Unix(sec int64,nsec ...int64) time.Time { ns:=int64(0); if len(nsec)>0{ns=nsec[0]}; return time.Unix(sec,ns) }
func (timeNS) Until(t time.Time) time.Duration { return time.Until(t) }
func (timeNS) ZoneName(t time.Time) string { n,_:=t.Zone(); return n }
func (timeNS) ZoneOffset(t time.Time) int { _,o:=t.Zone(); return o }

type fileNS struct{}
func (fileNS) Exists(p string) bool { _,e:=os.Stat(p); return e==nil }
func (fileNS) IsDir(p string) bool { i,e:=os.Stat(p); return e==nil&&i.IsDir() }
func (fileNS) Read(p string)(string,error){b,e:=os.ReadFile(p);return string(b),e}
func (fileNS) ReadDir(p string)([]string,error){es,e:=os.ReadDir(p); if e!=nil{return nil,e}; out:=[]string{}; for _,x:=range es{out=append(out,x.Name())}; return out,nil}
func (fileNS) Stat(p string)(os.FileInfo,error){return os.Stat(p)}
func (fileNS) Walk(p string)([]string,error){out:=[]string{}; e:=filepath.WalkDir(p,func(q string,d os.DirEntry,e error)error{if e==nil{out=append(out,q)};return e}); return out,e}
func (fileNS) Write(p,s string)(string,error){return "",os.WriteFile(p,[]byte(s),0o666)}

type netNS struct{}
func (netNS) LookupIP(name string)(string,error){ips,e:=net.LookupIP(name); if e!=nil||len(ips)==0{return "",e}; for _,ip:=range ips{if ip.To4()!=nil{return ip.String(),nil}}; return ips[0].String(),nil}
func (netNS) LookupIPs(name string)([]string,error){ips,e:=net.LookupIP(name); if e!=nil{return nil,e}; out:=[]string{}; seen:=map[string]bool{}; for _,ip:=range ips{if ip.To4()!=nil{str:=ip.String(); if !seen[str]{seen[str]=true; out=append(out,str)}}}; return out,nil}
func (netNS) LookupCNAME(name string)(string,error){return net.LookupCNAME(name)}
func (netNS) LookupTXT(name string)([]string,error){return net.LookupTXT(name)}
func (netNS) LookupSRV(name string)(*net.SRV,error){_,a,e:=net.LookupSRV("","",name); if e!=nil||len(a)==0{return nil,e}; return a[0],nil}
func (netNS) LookupSRVs(name string)([]*net.SRV,error){_,a,e:=net.LookupSRV("","",name); return a,e}
func (netNS) ParseAddr(s string)(net.IP,error){ip:=net.ParseIP(s); if ip==nil{return nil,fmt.Errorf("invalid IP address: %s",s)}; return ip,nil}
func (netNS) ParsePrefix(s string)(*net.IPNet,error){_,n,e:=net.ParseCIDR(s); return n,e}
func (netNS) ParseRange(s string) []string { return strings.Split(s,"-") }

type base64NS struct{}
func (base64NS) Encode(s any) string { return base64.StdEncoding.EncodeToString([]byte(fmt.Sprint(s))) }
func (base64NS) Decode(s string)(string,error){b,e:=base64.StdEncoding.DecodeString(s); return string(b),e}
func (base64NS) DecodeBytes(s string)([]byte,error){return base64.StdEncoding.DecodeString(s)}

type cryptoNS struct{}
func hashString(h hash.Hash, s string) string { h.Write([]byte(s)); return hex.EncodeToString(h.Sum(nil)) }
func (cryptoNS) MD5(s string) string { return hashString(md5.New(),s) }
func (cryptoNS) SHA1(s string) string { return hashString(sha1.New(),s) }
func (cryptoNS) SHA224(s string) string { return hashString(sha256.New224(),s) }
func (cryptoNS) SHA256(s string) string { return hashString(sha256.New(),s) }
func (cryptoNS) SHA384(s string) string { return hashString(sha512.New384(),s) }
func (cryptoNS) SHA512(s string) string { return hashString(sha512.New(),s) }
func (cryptoNS) SHA512_224(s string) string { return hashString(sha512.New512_224(),s) }
func (cryptoNS) SHA512_256(s string) string { return hashString(sha512.New512_256(),s) }
func (cryptoNS) SHA1Bytes(b []byte) string { return cryptoNS{}.SHA1(string(b)) }
func (cryptoNS) SHA256Bytes(b []byte) string { return cryptoNS{}.SHA256(string(b)) }
func (cryptoNS) PBKDF2(password,salt string, iter,keyLen int)(string,error){return cryptoNS{}.SHA256(password+salt+strconv.Itoa(iter)+strconv.Itoa(keyLen)),nil}

type randomNS struct{}
func randInt(max int64) int64 { if max<=0{return 0}; n,_:=rand.Int(rand.Reader,big.NewInt(max)); return n.Int64() }
func (randomNS) ASCII(n int) string { return randChars(n, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_=+[]{};:,.?/") }
func (randomNS) Alpha(n int) string { return randChars(n, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") }
func (randomNS) AlphaNum(n int) string { return randChars(n, "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") }
func (randomNS) String(n int, chars string) string { return randChars(n, chars) }
func (randomNS) Item(v any) any { s:=toAnySlice(v); if len(s)==0{return nil}; return s[randInt(int64(len(s)))] }
func (randomNS) Number(min,max int64) int64 { return min+randInt(max-min+1) }
func (randomNS) Float() float64 { return float64(randInt(1<<53))/float64(1<<53) }
func randChars(n int, chars string) string { r:=[]rune(chars); out:=make([]rune,n); for i:=range out{out[i]=r[randInt(int64(len(r)))]}; return string(out) }

type testNS struct{}
func (testNS) Assert(ok bool,msg ...string)(string,error){if !ok{m:="assertion failed"; if len(msg)>0{m=msg[0]}; return "",errors.New(m)}; return "",nil}
func (testNS) Fail(msg string)(string,error){return "",errors.New(msg)}
func (testNS) Kind(v any) string { if v==nil{return "invalid"}; return reflect.TypeOf(v).Kind().String() }
func (testNS) IsKind(k string,v any) bool { return testNS{}.Kind(v)==k }
func (testNS) Required(msg string,v any)(any,error){if isEmpty(v){return nil,errors.New(msg)}; return v,nil}
func (testNS) Ternary(a,b any,cond bool) any { if cond {return a}; return b }

type tmplNS struct{ t *template.Template; app *app }
func (n tmplNS) Exec(name string, data ...any)(string,error){d:=any(nil); if len(data)>0{d=data[0]}; var b bytes.Buffer; e:=n.t.ExecuteTemplate(&b,filepath.Base(name),d); return b.String(),e}
func (n tmplNS) Inline(s string,data ...any)(string,error){d:=any(nil); if len(data)>0{d=data[0]}; return n.app.render("<inline>",s,d)}
func (n tmplNS) Path() string { return n.app.tmplPath }
func (n tmplNS) PathDir() string { return filepath.Dir(n.app.tmplPath) }

func htmlEscape(s string) string { return html.EscapeString(s) }
