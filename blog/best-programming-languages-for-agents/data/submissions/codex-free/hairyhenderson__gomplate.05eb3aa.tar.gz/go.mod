module pb-gomplate

go 1.21
