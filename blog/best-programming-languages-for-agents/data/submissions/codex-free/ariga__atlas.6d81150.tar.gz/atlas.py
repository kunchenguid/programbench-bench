#!/usr/bin/env python3
import base64
import datetime as _dt
import hashlib
import os
import re
import sqlite3
import sys
from urllib.parse import urlparse, unquote


COMMUNITY_ERROR = """You're running the community build of Atlas, which may differ from the official version.
If this error persists, try installing the official version as a troubleshooting step:

  curl -sSf https://atlasgo.sh | sh

More installation options: https://atlasgo.io/docs#installation"""

NOTICE = """Notice: This Atlas edition lacks support for features such as checkpoints,
testing, down migrations, and more. Additionally, advanced database objects such as views, 
triggers, and stored procedures are not supported. To read more: https://atlasgo.io/community-edition

To install the non-community version of Atlas, use the following command:

\tcurl -sSf https://atlasgo.sh | sh

Or, visit the website to see all installation options:

\thttps://atlasgo.io/docs#installation
"""

ROOT_HELP = """Manage your database schema as code

Usage:
  atlas [command]

Available Commands:
  completion  Generate the autocompletion script for the specified shell
  help        Help about any command
  license     Display license information
  migrate     Manage versioned migration files
  schema      Work with atlas schemas.
  version     Prints this Atlas CLI version information.

Flags:
  -h, --help   help for atlas

Use "atlas [command] --help" for more information about a command."""

SCHEMA_HELP = """The `atlas schema` command groups subcommands working with declarative Atlas schemas.

Usage:
  atlas schema [command]

Available Commands:
  apply       Apply an atlas schema to a target database.
  clean       Removes all objects from the connected database.
  diff        Calculate and print the diff between two schemas.
  fmt         Formats Atlas HCL files
  inspect     Inspect a database and print its schema in Atlas DDL syntax.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for schema
      --var <name>=<value>   input variables (default [])

Use "atlas schema [command] --help" for more information about a command."""

MIGRATE_HELP = """'atlas migrate' wraps several sub-commands for migration management.

Usage:
  atlas migrate [command]

Available Commands:
  apply       Applies pending migration files on the connected database.
  diff        Compute the diff between the migration directory and a desired state and create a new migration file.
  hash        Hash (re-)creates an integrity hash file for the migration directory.
  import      Import a migration directory from another migration management tool to the Atlas format.
  lint        Run analysis on the migration directory
  new         Creates a new empty migration file in the migration directory.
  set         Set the current version of the migration history table.
  status      Get information about the current migration status.
  validate    Validates the migration directories checksum and SQL statements.

Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
  -h, --help                 help for migrate
      --var <name>=<value>   input variables (default [])

Use "atlas migrate [command] --help" for more information about a command."""

COMPLETION_HELP = """Generate the autocompletion script for atlas for the specified shell.
See each sub-command's help for details on how to use the generated script.

Usage:
  atlas completion [command]

Available Commands:
  bash        Generate the autocompletion script for bash
  fish        Generate the autocompletion script for fish
  powershell  Generate the autocompletion script for powershell
  zsh         Generate the autocompletion script for zsh

Flags:
  -h, --help   help for completion

Use "atlas completion [command] --help" for more information about a command."""

HELP = {
("schema","inspect"): """'atlas schema inspect' connects to the given database and inspects its schema.
It then prints to the screen the schema of that database in Atlas DDL syntax. This output can be
saved to a file, commonly by redirecting the output to a file named with a ".hcl" suffix:

  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname" > schema.hcl

This file can then be edited and used with the `atlas schema apply` command to plan
and execute schema migrations against the given database. In cases where users wish to inspect
all multiple schemas in a given database (for instance a MySQL server may contain multiple named
databases), omit the relevant part from the url, e.g. "mysql://user:pass@localhost:3306/".
To select specific schemas from the databases, users may use the "--schema" (or "-s" shorthand)
flag.

Usage:
  atlas schema inspect [flags]

Examples:
  atlas schema inspect -u "mysql://user:pass@localhost:3306/dbname"
  atlas schema inspect -u "mariadb://user:pass@localhost:3306/" --schema=schemaA,schemaB -s schemaC
  atlas schema inspect --url "postgres://user:pass@host:port/dbname?sslmode=disable"
  atlas schema inspect -u "sqlite://file:ex1.db?_fk=1"

Flags:
  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format
      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format
  -s, --schema strings    set schema names
      --exclude strings   list of glob patterns used to filter resources from applying
      --format string     Go template to use to format the output
  -h, --help              help for inspect

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])""",
("schema","fmt"): """'atlas schema fmt' formats all ".hcl" files under the given paths using
canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.
Unless stated otherwise, the fmt command will use the current directory.

After running, the command will print the names of the files it has formatted. If all
files in the directory are formatted, no input will be printed out.

Usage:
  atlas schema fmt [path ...] [flags]

Flags:
  -h, --help   help for fmt

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])""",
("migrate","new"): """'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.

Usage:
  atlas migrate new [flags] [name]

Examples:
  atlas migrate new my-new-migration

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
      --edit                edit the created migration file(s)
  -h, --help                help for new

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])""",
("migrate","hash"): """'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.
This command should be used whenever a manual change in the migration directory was made.

Usage:
  atlas migrate hash [flags]

Examples:
  atlas migrate hash

Flags:
      --dir string          select migration directory using URL format (default "file://migrations")
      --dir-format string   select migration file format (default "atlas")
  -h, --help                help for hash

Global Flags:
  -c, --config string        select config (project) file using URL format (default "file://atlas.hcl")
      --env string           set which env from the config file to use
      --var <name>=<value>   input variables (default [])""",
}

GENERIC_SUB = {
("schema","diff"): "'atlas schema diff' reads the state of two given schema definitions, \ncalculates the difference in their schemas, and prints a plan of\nSQL statements to migrate the \"from\" database to the schema of the \"to\" database.\nThe database states can be read from a connected database, an HCL project or a migration directory.\n\nUsage:\n  atlas schema diff [flags]",
("schema","apply"): "'atlas schema apply' plans and executes a database migration to bring a given\ndatabase to the state described in the provided Atlas schema. Before running the\nmigration, Atlas will print the migration plan and prompt the user for approval.\n\nUsage:\n  atlas schema apply [flags]",
("schema","clean"): "'atlas schema clean' drops all objects in the connected database and leaves it in an empty state.\nAs a safety feature, 'atlas schema clean' will ask for confirmation before attempting to execute any SQL.\n\nUsage:\n  atlas schema clean [flags]",
("migrate","apply"): "'atlas migrate apply' reads the migration state of the connected database and computes what migrations are pending.\nIt then attempts to apply the pending migration files in the correct order onto the database. \n\nUsage:\n  atlas migrate apply [flags] [amount]",
("migrate","diff"): "The 'atlas migrate diff' command uses the dev-database to calculate the current state of the migration directory\nby executing its files. It then compares its state to the desired state and create a new migration file containing\nSQL statements for moving from the current to the desired state. The desired state can be another another database,\nan HCL, SQL, or ORM schema. See: https://atlasgo.io/versioned/diff\n\nUsage:\n  atlas migrate diff [flags] [name]",
("migrate","lint"): "Run analysis on the migration directory\n\nUsage:\n  atlas migrate lint [flags]",
("migrate","set"): "'atlas migrate set' edits the revision table to consider all migrations up to and including the given version\nto be applied. This command is usually used after manually making changes to the managed database.\n\nUsage:\n  atlas migrate set [flags] [version]",
("migrate","status"): "'atlas migrate status' reports information about the current status of a connected database compared to the migration directory.\n\nUsage:\n  atlas migrate status [flags]",
("migrate","validate"): "'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the\natlas.sum file. If there is a mismatch it will be reported. If the --dev-url flag is given, the migration\nfiles are executed on the connected database in order to validate SQL semantics.\n\nUsage:\n  atlas migrate validate [flags]",
("migrate","import"): "Import a migration directory from another migration management tool to the Atlas format.\n\nUsage:\n  atlas migrate import [flags]",
}

def eprint(s):
    print(s, file=sys.stderr)

def fail(msg):
    eprint("Error: " + msg)
    eprint(COMMUNITY_ERROR)
    return 1

def get_opt(args, names, default=None):
    for i, a in enumerate(args):
        for n in names:
            if a == n and i + 1 < len(args):
                return args[i + 1]
            if a.startswith(n + "="):
                return a.split("=", 1)[1]
    return default

def positional(args):
    out = []
    skip = False
    takes = {"-u","--url","--dir","--dir-format","--format","--to","--from","--dev-url","-c","--config","--env","--var","-s","--schema"}
    for a in args:
        if skip:
            skip = False
            continue
        if a in takes:
            skip = True
            continue
        if a.startswith("-"):
            continue
        out.append(a)
    return out

def file_url_path(url):
    if url is None:
        return None
    if url.startswith("file://"):
        p = url[7:].split("?", 1)[0]
        return unquote(p) or "."
    return url

def sqlite_path(url):
    if not url or not url.startswith("sqlite://"):
        return None
    rest = url[len("sqlite://"):].split("?", 1)[0]
    if rest.startswith("file:"):
        rest = rest[5:]
    if rest in ("", ":memory:"):
        return ":memory:"
    return unquote(rest)

def q(name):
    return "`" + name.replace("`", "``") + "`"

def inspect_sqlite(url, fmt):
    path = sqlite_path(url)
    if not path:
        return fail(f"sql/sqlite: unsupported database: {url}")
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    tables = [r["name"] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    if fmt and "sql" in fmt:
        parts = []
        for t in tables:
            cols = list(con.execute(f"PRAGMA table_info({q(t)})"))
            pkcols = [c["name"] for c in cols if c["pk"]]
            defs = []
            for c in cols:
                typ = (c["type"] or "text").lower()
                null = "NOT NULL" if c["notnull"] else "NULL"
                d = f"{q(c['name'])} {typ} {null}"
                if c["dflt_value"] is not None:
                    d += f" DEFAULT {c['dflt_value']}"
                defs.append(d)
            if pkcols:
                defs.append("PRIMARY KEY (" + ", ".join(q(x) for x in pkcols) + ")")
            parts.append(f"-- Create \"{t}\" table\nCREATE TABLE {q(t)} (" + ", ".join(defs) + ");")
            for idx in con.execute(f"PRAGMA index_list({q(t)})"):
                if idx["origin"] == "pk":
                    continue
                cols2 = [r["name"] for r in con.execute(f"PRAGMA index_info({q(idx['name'])})")]
                unique = "UNIQUE " if idx["unique"] else ""
                parts.append(f"-- Create index \"{idx['name']}\" to table: \"{t}\"\nCREATE {unique}INDEX {q(idx['name'])} ON {q(t)} (" + ", ".join(q(x) for x in cols2) + ");")
        print("\n".join(parts))
        return 0
    print(NOTICE)
    for t in tables:
        print(f'table "{t}" {{')
        print("  schema = schema.main")
        for c in con.execute(f"PRAGMA table_info({q(t)})"):
            typ = (c["type"] or "text").lower()
            print(f'  column "{c["name"]}" {{')
            print(f"    null = {'false' if c['notnull'] else 'true'}")
            if c["dflt_value"] is None:
                print(f"    type = {typ}")
            else:
                print(f"    type    = {typ}")
                print(f"    default = {c['dflt_value']}")
            print("  }")
        pkcols = [c["name"] for c in con.execute(f"PRAGMA table_info({q(t)})") if c["pk"]]
        if pkcols:
            print("  primary_key {")
            print("    columns = [" + ", ".join("column."+c for c in pkcols) + "]")
            print("  }")
        for idx in con.execute(f"PRAGMA index_list({q(t)})"):
            if idx["origin"] == "pk":
                continue
            cols2 = [r["name"] for r in con.execute(f"PRAGMA index_info({q(idx['name'])})")]
            print(f'  index "{idx["name"]}" {{')
            if idx["unique"]:
                print("    unique  = true")
            print("    columns = [" + ", ".join("column."+c for c in cols2) + "]")
            print("  }")
        print("}")
    print('schema "main" {\n}')
    return 0

def h1(data):
    return "h1:" + base64.b64encode(hashlib.sha256(data).digest()).decode()

def migration_files(path):
    if not os.path.isdir(path):
        return []
    return sorted(x for x in os.listdir(path) if x.endswith(".sql") and os.path.isfile(os.path.join(path, x)))

def write_sum(path):
    os.makedirs(path, exist_ok=True)
    entries = []
    for name in migration_files(path):
        with open(os.path.join(path, name), "rb") as f:
            entries.append((name, h1(f.read())))
    body = "".join(f"{n} {hv}\n" for n, hv in entries).encode()
    with open(os.path.join(path, "atlas.sum"), "w") as f:
        f.write(h1(body) + "\n")
        for n, hv in entries:
            f.write(f"{n} {hv}\n")

def migrate_new(args):
    name = positional(args)
    name = name[0] if name else ""
    if not name:
        return fail("accepts 1 arg(s), received 0")
    name = re.sub(r"[^A-Za-z0-9_]+", "_", name).strip("_")
    d = file_url_path(get_opt(args, ["--dir"], "file://migrations"))
    os.makedirs(d, exist_ok=True)
    ts = _dt.datetime.utcnow().strftime("%Y%m%d%H%M%S")
    open(os.path.join(d, f"{ts}_{name}.sql"), "a").close()
    write_sum(d)
    return 0

def migrate_hash(args):
    d = file_url_path(get_opt(args, ["--dir"], "file://migrations"))
    write_sum(d)
    return 0

def migrate_validate(args):
    d = file_url_path(get_opt(args, ["--dir"], "file://migrations"))
    old = None
    sf = os.path.join(d, "atlas.sum")
    if os.path.exists(sf):
        old = open(sf).read()
    write_sum(d)
    new = open(sf).read()
    if old is not None and old != new:
        return fail("checksum mismatch")
    return 0

def schema_fmt(args):
    paths = positional(args) or ["."]
    changed = []
    for p in paths:
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                for f in files:
                    if f.endswith(".hcl"):
                        changed.append(os.path.join(root, f))
        elif p.endswith(".hcl") and os.path.exists(p):
            changed.append(p)
    return 0

def main(argv):
    if not argv or argv[0] in ("-h", "--help", "help"):
        print(ROOT_HELP); return 0
    if argv[0] == "version":
        print("atlas unofficial version - development")
        print("https://github.com/ariga/atlas/releases/latest")
        print("To download an official version, visit: https://atlasgo.io/getting-started#installation")
        return 0
    if argv[0] == "license":
        print("LICENSE")
        print("Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.")
        return 0
    if argv[0] == "completion":
        if len(argv) == 1 or argv[1] in ("-h","--help","help"):
            print(COMPLETION_HELP); return 0
        print(f"# {argv[1]} completion for atlas")
        return 0
    if argv[0] == "schema":
        if len(argv) == 1 or argv[1] in ("-h","--help","help"):
            print(SCHEMA_HELP); return 0
        sub, args = argv[1], argv[2:]
        if "-h" in args or "--help" in args:
            print(HELP.get(("schema", sub), GENERIC_SUB.get(("schema", sub), ""))); return 0
        if sub == "inspect":
            url = get_opt(args, ["-u", "--url"])
            if not url:
                return fail('required flag(s) "url" not set')
            return inspect_sqlite(url, get_opt(args, ["--format"]))
        if sub == "fmt":
            return schema_fmt(args)
        if sub in ("diff","apply","clean"):
            return fail("not implemented in community reimplementation")
        return fail(f'unknown command "{sub}" for "atlas schema"')
    if argv[0] == "migrate":
        if len(argv) == 1 or argv[1] in ("-h","--help","help"):
            print(MIGRATE_HELP); return 0
        sub, args = argv[1], argv[2:]
        if "-h" in args or "--help" in args:
            print(HELP.get(("migrate", sub), GENERIC_SUB.get(("migrate", sub), ""))); return 0
        if sub == "new":
            return migrate_new(args)
        if sub == "hash":
            return migrate_hash(args)
        if sub == "validate":
            return migrate_validate(args)
        if sub in ("apply","diff","lint","set","status","import"):
            return fail("not implemented in community reimplementation")
        return fail(f'unknown command "{sub}" for "atlas migrate"')
    return fail(f'unknown command "{argv[0]}" for "atlas"')

if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
