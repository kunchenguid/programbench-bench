#!/usr/bin/env python3
import argparse
import csv
import os
import sys
import unicodedata


VERSION = "csview 1.3.4"
STYLES = {"none", "ascii", "ascii2", "sharp", "rounded", "reinforced", "markdown", "grid"}
ALIGNS = {"left", "center", "right"}


def char_width(ch):
    if ch == "\n":
        return 0
    cat = unicodedata.category(ch)
    if cat in ("Mn", "Me", "Cf"):
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    o = ord(ch)
    if 0x1F000 <= o <= 0x1FAFF or 0x2600 <= o <= 0x27BF:
        return 2
    return 1


def width(text):
    return sum(char_width(c) for c in text)


def fit(text, w, align):
    n = width(text)
    if n >= w:
        out = []
        used = 0
        for ch in text:
            cw = char_width(ch)
            if used + cw > w:
                break
            out.append(ch)
            used += cw
        return "".join(out) + " " * (w - used)
    gap = w - n
    if align == "right":
        return " " * gap + text
    if align == "center":
        left = gap // 2
        return " " * left + text + " " * (gap - left)
    return text + " " * gap


class Parser(argparse.ArgumentParser):
    def error(self, message):
        sys.stderr.write(f"error: {message}\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        raise SystemExit(2)


def parse_args(argv):
    if "--help" in argv or "-h" in argv:
        print("""A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version""")
        raise SystemExit(0)
    if "--version" in argv or "-V" in argv:
        print(VERSION)
        raise SystemExit(0)

    p = Parser(prog="executable", add_help=False)
    p.add_argument("-H", "--no-headers", action="store_true")
    p.add_argument("-n", "--number", action="store_true")
    p.add_argument("-t", "--tsv", action="store_true")
    p.add_argument("-d", "--delimiter", default=",")
    p.add_argument("-s", "--style", default="sharp")
    p.add_argument("-p", "--padding", type=int, default=1)
    p.add_argument("-i", "--indent", type=int, default=0)
    p.add_argument("--sniff", type=int, default=1000)
    p.add_argument("--header-align", default="center")
    p.add_argument("--body-align", default="left")
    p.add_argument("-P", "--disable-pager", action="store_true")
    p.add_argument("file", nargs="?")
    ns, extra = p.parse_known_args(argv)
    if extra:
        sys.stderr.write(f"error: unexpected argument '{extra[0]}' found\n\n")
        sys.stderr.write("Usage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n")
        raise SystemExit(2)
    if ns.style not in STYLES:
        sys.stderr.write(f"error: invalid value '{ns.style}' for '--style <STYLE>'\n")
        sys.stderr.write("  [possible values: none, ascii, ascii2, sharp, rounded, reinforced, markdown, grid]\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        raise SystemExit(2)
    if ns.header_align not in ALIGNS:
        p.error(f"invalid value '{ns.header_align}' for '--header-align <HEADER_ALIGN>'")
    if ns.body_align not in ALIGNS:
        p.error(f"invalid value '{ns.body_align}' for '--body-align <BODY_ALIGN>'")
    if len(ns.delimiter) != 1:
        sys.stderr.write(f"error: invalid value '{ns.delimiter}' for '--delimiter <DELIMITER>': too many characters in string\n\n")
        sys.stderr.write("For more information, try '--help'.\n")
        raise SystemExit(2)
    if ns.tsv:
        ns.delimiter = "\t"
    if ns.padding < 0:
        ns.padding = 0
    if ns.indent < 0:
        ns.indent = 0
    return ns


def read_rows(ns):
    try:
        if ns.file:
            f = open(ns.file, newline="", encoding="utf-8")
            raw = f.read()
            f.close()
        else:
            raw = sys.stdin.read()
    except OSError as e:
        sys.stderr.write(f"csview: {e.strerror} (os error {e.errno})\n")
        raise SystemExit(1)
    rdr = csv.reader(raw.splitlines(True), delimiter=ns.delimiter)
    rows = []
    expected = None
    starts = []
    pos = 0
    for line in raw.splitlines(True):
        starts.append(pos)
        pos += len(line.encode("utf-8"))
    try:
        for idx, row in enumerate(rdr):
            if expected is None:
                expected = len(row)
            elif len(row) != expected:
                byte = starts[rdr.line_num - 1] if rdr.line_num - 1 < len(starts) else 0
                sys.stderr.write(
                    f"csview: CSV error: record {idx} (line: {rdr.line_num}, byte: {byte}): "
                    f"found record with {len(row)} fields, but the previous record has {expected} fields\n"
                )
                raise SystemExit(1)
            rows.append(row)
    except csv.Error as e:
        sys.stderr.write(f"csview: CSV error: {e}\n")
        raise SystemExit(1)
    return rows


STYLE_CHARS = {
    "ascii": dict(tl="+", tr="+", bl="+", br="+", h="-", v="|", tj="+", bj="+", lj="+", rj="+", x="+"),
    "sharp": dict(tl="┌", tr="┐", bl="└", br="┘", h="─", v="│", tj="┬", bj="┴", lj="├", rj="┤", x="┼"),
    "rounded": dict(tl="╭", tr="╮", bl="╰", br="╯", h="─", v="│", tj="┬", bj="┴", lj="├", rj="┤", x="┼"),
    "reinforced": dict(tl="┏", tr="┓", bl="┗", br="┛", h="─", v="│", tj="┬", bj="┴", lj="├", rj="┤", x="┼"),
    "grid": dict(tl="┌", tr="┐", bl="└", br="┘", h="─", v="│", tj="┬", bj="┴", lj="├", rj="┤", x="┼"),
}


def split_table(rows, no_headers, numbered):
    if not rows:
        header, body = ([] if not no_headers else None), []
    elif no_headers:
        header, body = None, rows
    else:
        header, body = rows[0], rows[1:]
    if numbered:
        if header is None:
            body = [[str(i + 1)] + r for i, r in enumerate(body)]
        else:
            header = ["#"] + header
            body = [[str(i + 1)] + r for i, r in enumerate(body)]
    return header, body


def column_widths(header, body, sniff):
    all_rows = []
    if header is not None:
        all_rows.append(header)
    lim = len(body) if sniff == 0 else min(len(body), sniff)
    all_rows.extend(body[:lim])
    cols = max((len(r) for r in all_rows), default=0)
    ws = [0] * cols
    for r in all_rows:
        for i, c in enumerate(r):
            ws[i] = max(ws[i], width(c))
    return ws


def line_for(ws, chars, kind):
    if kind == "top":
        l, j, r = chars["tl"], chars["tj"], chars["tr"]
    elif kind == "bottom":
        l, j, r = chars["bl"], chars["bj"], chars["br"]
    else:
        l, j, r = chars["lj"], chars["x"], chars["rj"]
    return l + j.join(chars["h"] * w for w in ws) + r


def row_for(row, ws, chars, pad, align):
    parts = []
    for i, w in enumerate(ws):
        text = row[i] if i < len(row) else ""
        parts.append(" " * pad + fit(text, w - 2 * pad, align) + " " * pad)
    return chars["v"] + chars["v"].join(parts) + chars["v"]


def render_none(header, body, widths, pad, ha, ba):
    rows = []
    inner = [w + 2 * pad for w in widths]
    if header is not None:
        rows.append("".join(" " * pad + fit(header[i] if i < len(header) else "", widths[i], ha) + " " * pad for i in range(len(widths))))
    for r in body:
        rows.append("".join(" " * pad + fit(r[i] if i < len(r) else "", widths[i], ba) + " " * pad for i in range(len(widths))))
    return rows


def render_ascii2(header, body, widths, pad, ha, ba):
    out = []
    seg = [w + 2 * pad for w in widths]
    def bare(r, al):
        return " " + "|".join(" " * pad + fit(r[i] if i < len(r) else "", widths[i], al) + " " * pad for i in range(len(widths))) + " "
    if header is not None:
        out.append(bare(header, ha))
        out.append(" " + "+".join("-" * s for s in seg) + " ")
    for r in body:
        out.append(bare(r, ba))
    return out


def render_markdown(header, body, widths, pad, ha, ba):
    out = []
    seg = [w + 2 * pad for w in widths]
    def mdrow(r, al):
        return "|" + "|".join(" " * pad + fit(r[i] if i < len(r) else "", widths[i], al) + " " * pad for i in range(len(widths))) + "|"
    if header is not None:
        out.append(mdrow(header, ha))
        out.append("|" + "|".join("-" * s for s in seg) + "|")
    for r in body:
        out.append(mdrow(r, ba))
    return out


def render(header, body, ns):
    pad = ns.padding
    widths = column_widths(header, body, ns.sniff)
    seg = [w + 2 * pad for w in widths]
    if ns.style == "none":
        out = render_none(header, body, widths, pad, ns.header_align, ns.body_align)
    elif ns.style == "ascii2":
        out = render_ascii2(header, body, widths, pad, ns.header_align, ns.body_align)
    elif ns.style == "markdown":
        out = render_markdown(header, body, widths, pad, ns.header_align, ns.body_align)
    else:
        ch = STYLE_CHARS[ns.style]
        out = [line_for(seg, ch, "top")]
        if header is not None:
            out.append(row_for(header, seg, ch, pad, ns.header_align))
            if body:
                out.append(line_for(seg, ch, "mid"))
        for i, r in enumerate(body):
            out.append(row_for(r, seg, ch, pad, ns.body_align))
            if ns.style == "grid" and i != len(body) - 1:
                out.append(line_for(seg, ch, "mid"))
        out.append(line_for(seg, ch, "bottom"))
    ind = " " * ns.indent
    return "\n".join(ind + x for x in out) + "\n"


def main(argv):
    ns = parse_args(argv)
    rows = read_rows(ns)
    header, body = split_table(rows, ns.no_headers, ns.number)
    sys.stdout.write(render(header, body, ns))


if __name__ == "__main__":
    main(sys.argv[1:])
