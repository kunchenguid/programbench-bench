#!/usr/bin/env python3
import base64
import json
import os
import re
import shlex
import subprocess
import sys


class Param:
    def __init__(self, kind, spec, desc="", names=None, notations=None):
        self.kind = kind
        self.raw = spec
        self.desc = desc.strip()
        self.names = names or []
        self.notations = notations or []
        self.flag = kind == "flag"
        self.id = ""
        self.required = False
        self.multiple = False
        self.mult_occurs = False
        self.delim = None
        self.terminated = False
        self.default = None
        self.choice = None
        self.skip_check = False
        self.prefixed = False
        self.assigned = False
        self.num_args = (0, 0) if self.flag else (1, 1)
        self.parse_spec(spec)
        if self.kind in ("option", "flag"):
            self.names = [self.clean_option_name(n) for n in self.names]

    def clean_option_name(self, n):
        assigned = n.endswith(":")
        if assigned:
            n = n[:-1]
        if "[" in n:
            n = n.split("[", 1)[0]
        if "=" in n:
            n = n.split("=", 1)[0]
        if n.endswith("*,"):
            n = n[:-2] + "*"
        n = re.sub(r"[!+~,]+$", "", n)
        if n.endswith("*") and not self.prefixed:
            n = n[:-1]
        if assigned:
            n += ":"
        return n

    def parse_spec(self, spec):
        s = spec
        if self.kind in ("option", "flag"):
            main = self.names[-1] if self.names else s
            if main.endswith(":"):
                self.assigned = True
                main = main[:-1]
            if main.endswith("*") and len(main) > 2 and main[-2] == "-":
                self.prefixed = True
            ident = main
            if "[" in ident:
                ident = ident.split("[", 1)[0]
            if "=" in ident:
                ident = ident.split("=", 1)[0]
            ident = ident.lstrip("-+").rstrip("*+!~,:")
            if ident.endswith(":"):
                ident = ident[:-1]
            self.id = ident.replace("-", "_")
        else:
            self.id = re.split(r"[!*+~=,\[]", s, 1)[0].replace("-", "_")

        m = re.search(r"\[(.*)\]", s)
        if m:
            body = m.group(1)
            if body.startswith("?"):
                self.skip_check = True
                body = body[1:]
            if body.startswith("="):
                body = body[1:]
                self.default = body.split("|", 1)[0]
            self.choice = body
            s = s[:m.start()] + s[m.end():]

        if "=" in s:
            before, after = s.split("=", 1)
            self.default = after.rstrip(",")
            s = before + ("," if after.endswith(",") else "")

        if s.endswith(",") or "*," in s or "+," in s:
            self.delim = ","
            s = s.replace(",", "")
        if "~" in s:
            self.terminated = True
        if "!" in s:
            self.required = True
        if "+" in s:
            self.required = True
            self.multiple = True
            self.mult_occurs = True
        if "*" in s:
            self.multiple = True
            self.mult_occurs = True
        if self.kind == "arg":
            self.mult_occurs = False
            if self.default is not None:
                self.required = False
        if self.kind == "option":
            if self.notations:
                mn = 0
                mx = 0
                for n in self.notations:
                    if n.endswith("*"):
                        mx = 999
                    elif n.endswith("+"):
                        mn += 1; mx = 999
                    elif n.endswith("?"):
                        mx += 1
                    else:
                        mn += 1; mx += 1
                self.num_args = (mn, mx)
            else:
                self.num_args = (1, 999 if self.terminated else 1)

    def notation(self):
        if self.kind == "arg":
            if self.notations:
                n = self.notations[0]
            else:
                n = self.id.upper()
            return n
        if self.notations:
            return " ".join("<%s>" % n.strip("<>") for n in self.notations)
        base = self.id.upper()
        if self.terminated:
            base += "~"
        return "<%s>" % base

    def usage_piece(self):
        n = self.notation().strip("<>")
        if self.kind == "arg":
            if self.multiple:
                n = n + "..."
            if self.required:
                return "<%s>" % n
            return "[%s]" % n
        primary = self.names[-1]
        if self.flag:
            return primary
        val = self.notation()
        if self.mult_occurs and not self.required:
            val = "[%s]..." % val.strip("<>")
        elif self.mult_occurs:
            val = "%s..." % val
        return "%s %s" % (primary, val)

    def to_json(self):
        if self.kind == "arg":
            return {
                "id": self.id, "describe": self.desc, "notation": self.notation().strip("<>"),
                "required": self.required, "multiple": self.multiple, "delimiter": self.delim,
                "terminated": self.terminated, "default": self.default, "choice": self.choice,
                "env": None,
            }
        return {
            "id": self.id, "long_name": next((x for x in self.names if x.startswith("--")), None),
            "short_name": next((x for x in self.names if re.match(r"^[-+][^-+].*$", x) and len(x.lstrip("-+")) == 1), None),
            "describe": self.desc, "flag": self.flag, "notations": [n.strip("<>") for n in self.notations],
            "required": self.required, "multiple_values": self.num_args[1] > 1,
            "multiple_occurs": self.mult_occurs, "num_args": list(self.num_args), "delimiter": self.delim,
            "terminated": self.terminated, "prefixed": self.prefixed, "assigned": self.assigned,
            "default": self.default, "choice": self.choice, "env": None, "inherited": False,
        }


class Command:
    def __init__(self, name, fn=None, desc=""):
        self.name = name
        self.fn = fn
        self.desc = desc.strip()
        self.long_desc = []
        self.aliases = []
        self.options = []
        self.args = []
        self.envs = []
        self.sub = []
        self.version = None
        self.default_sub = False
        self.dotenv = False

    def to_json(self):
        opts = [p.to_json() for p in self.options] + [help_param(self.sub).to_json()]
        if self.version:
            opts.append(version_param().to_json())
        return {
            "name": self.name, "describe": self.desc, "version": self.version, "aliases": self.aliases,
            "flag_options": opts, "positionals": [a.to_json() for a in self.args], "envs": [],
            "subcommands": [c.to_json() for c in self.sub], "command_fn": self.fn,
        }


def help_param(has_sub=False):
    p = Param("flag", "--help", "Print help", ["-h", "--help"])
    if has_sub:
        p.desc = ""
    return p


def version_param():
    return Param("flag", "--version", "Print version", ["-V", "--version"])


def words(s):
    try:
        return shlex.split(s, comments=False, posix=True)
    except Exception:
        return s.split()


def clean_name(fn):
    return fn.replace("::", " ").replace("_", "-")


def parse_decl(line):
    line = line.strip()
    if line.startswith("#"):
        line = line[1:].strip()
    if line.startswith("@"):
        line = line[1:]
    parts = line.split(None, 1)
    return (parts[0], parts[1] if len(parts) > 1 else "")


def split_param(rest, kind):
    toks = words(rest)
    names = []
    nots = []
    i = 0
    if kind in ("option", "flag"):
        while i < len(toks):
            t = toks[i]
            if t.startswith("-") or t.startswith("+"):
                names.append(t)
                i += 1
                continue
            break
        while i < len(toks) and toks[i].startswith("<") and toks[i].endswith(">"):
            nots.append(toks[i].strip("<>"))
            i += 1
        spec = names[-1] if names else (toks[0] if toks else "")
    else:
        spec = toks[0] if toks else ""
        i = 1
        if i < len(toks) and toks[i].startswith("<") and toks[i].endswith(">"):
            nots.append(toks[i].strip("<>"))
            i += 1
    desc = " ".join(toks[i:])
    return Param(kind, spec, desc, names, nots)


def parse_file(path):
    root = Command(os.path.splitext(os.path.basename(path))[0])
    by_fn = {}
    pending = []
    try:
        lines = open(path, encoding="utf-8").read().splitlines()
    except Exception as e:
        die_code("error: %s" % e, 1)
    i = 0
    while i < len(lines):
        line = lines[i]
        st = line.strip()
        if st.startswith("#") and re.match(r"#\s*@?\w", st):
            pending.append(st)
            i += 1
            continue
        m = re.match(r"\s*([A-Za-z_][\w:.-]*)\s*\(\)\s*\{", line)
        if m:
            fn = m.group(1)
            cmd = None
            cmd_idx = next((j for j, x in enumerate(pending) if parse_decl(x)[0] == "cmd"), None)
            if cmd_idx is not None:
                if cmd_idx > 0:
                    apply_pending(root, pending[:cmd_idx], root_only=True)
                cmd = Command(clean_name(fn), fn)
                apply_pending(cmd, pending[cmd_idx:])
                insert_command(root, cmd)
                by_fn[fn] = cmd
            elif fn == "main":
                apply_pending(root, pending, root_only=True)
                root.fn = "main"
            pending = []
            i += 1
            continue
        if "eval " in line and "argc" in line:
            apply_pending(root, pending, root_only=True)
            pending = []
        elif st and not st.startswith("#"):
            if pending and not any(parse_decl(x)[0] == "cmd" for x in pending):
                apply_pending(root, pending, root_only=True)
            pending = []
        i += 1
    apply_inherit(root)
    return root


def apply_pending(cmd, pending, root_only=False):
    last_tag = None
    for raw in pending:
        tag, rest = parse_decl(raw)
        if tag == "describe":
            cmd.desc = rest
            last_tag = tag
        elif tag == "cmd" and not root_only:
            if rest:
                cmd.desc = rest
            last_tag = tag
        elif tag == "alias":
            cmd.aliases += [x.strip(",") for x in rest.split() if x.strip(",")]
            last_tag = tag
        elif tag == "arg":
            cmd.args.append(split_param(rest, "arg"))
            last_tag = tag
        elif tag == "option":
            cmd.options.append(split_param(rest, "option"))
            last_tag = tag
        elif tag == "flag":
            cmd.options.append(split_param(rest, "flag"))
            last_tag = tag
        elif tag == "env":
            cmd.envs.append(rest.split()[0] if rest.split() else rest)
            last_tag = tag
        elif tag == "meta":
            xs = rest.split(None, 1)
            key = xs[0] if xs else ""
            val = xs[1] if len(xs) > 1 else ""
            if key == "version":
                cmd.version = val
            if key == "default-subcommand":
                cmd.default_sub = True
            if key == "dotenv":
                cmd.dotenv = True
            last_tag = tag
        elif tag and tag[0] != "@" and last_tag in ("describe", "cmd"):
            cmd.long_desc.append(raw.lstrip("#").strip())


def insert_command(root, cmd):
    parts = cmd.fn.split("::") if cmd.fn else [cmd.name]
    parent = root
    for part in parts[:-1]:
        name = clean_name(part)
        found = next((c for c in parent.sub if c.name == name), None)
        if not found:
            found = Command(name, part)
            parent.sub.append(found)
        parent = found
    cmd.name = clean_name(parts[-1])
    parent.sub.append(cmd)


def apply_inherit(root):
    # The common documented inheritance mode: root options are accepted by child commands.
    inherited = list(root.options)
    if inherited:
        def rec(c):
            for ch in c.sub:
                for p in inherited:
                    if not any(q.id == p.id for q in ch.options):
                        ch.options.insert(0, p)
                rec(ch)
        rec(root)


def die_code(msg, status=1):
    print("command cat >&2 <<-'EOF' ")
    print(msg)
    print("EOF")
    print("exit %d" % status)
    sys.exit(0)


def shell_quote(v):
    if v == "":
        return "''"
    return shlex.quote(str(v))


def arr(vals):
    return "( " + " ".join(shell_quote(v) for v in vals) + " )"


def find_sub(cmd, tok):
    for c in cmd.sub:
        if tok == c.name or tok in c.aliases or tok == (c.fn or ""):
            return c
    return None


def opt_maps(cmd):
    m = {}
    pref = []
    for p in cmd.options + [help_param(False), version_param()]:
        for n in p.names:
            key = n.rstrip(":")
            if key.endswith("*"):
                pref.append((key[:-1], p))
            else:
                m[key] = p
    return m, pref


def possible_values(p):
    if not p.choice:
        return []
    c = p.choice
    if c.startswith("`") and c.endswith("`"):
        return []
    return [x for x in c.split("|") if x and not x.startswith("=")]


def validate(p, val):
    vals = possible_values(p)
    if vals and not p.skip_check and val not in vals:
        die_code("error: invalid value `%s` for `%s`\n  [possible values: %s]" %
                 (val, "[%s]" % p.id.upper() if p.kind == "arg" and not p.required else "<%s>" % p.id.upper(), ", ".join(vals)), 1)


def parse_args(root, argv):
    cmd = root
    consumed_cmds = []
    rest = list(argv)
    while rest and cmd.sub:
        c = find_sub(cmd, rest[0])
        if c:
            consumed_cmds.append(rest.pop(0))
            cmd = c
        else:
            d = next((x for x in cmd.sub if x.default_sub), None)
            if d:
                cmd = d
            break
    if cmd.sub and not rest and not cmd.fn:
        return cmd, {}, [], "help"
    vals = {}
    pos = []
    i = 0
    omap, pref = opt_maps(cmd)
    while i < len(rest):
        t = rest[i]
        if t == "--":
            pos += rest[i+1:]; break
        if t in ("--help", "-h", "-help", "+help"):
            return cmd, vals, pos, "help"
        if t in ("--version", "-V"):
            return cmd, vals, pos, "version"
        name = t
        oval = None
        if "=" in t and (t.startswith("--") or t.startswith("+")):
            name, oval = t.split("=", 1)
        p = omap.get(name)
        if p is None:
            # combined shorts, e.g. -rf
            if t.startswith("-") and len(t) > 2 and not t.startswith("--"):
                all_flags = True
                for ch in t[1:]:
                    fp = omap.get("-" + ch)
                    if not fp or not fp.flag:
                        all_flags = False
                        break
                if all_flags:
                    for ch in t[1:]:
                        add_val(vals, omap["-" + ch], "1")
                    i += 1
                    continue
            pp = next(((pre, q) for pre, q in pref if t.startswith(pre)), None)
            if pp:
                p = pp[1]
                oval = t[len(pp[0]):]
            elif t.startswith("-") or t.startswith("+"):
                die_code("error: unexpected argument `%s` found" % t, 1)
        if p:
            if p.flag:
                add_val(vals, p, "1")
                i += 1
            else:
                got = []
                if oval is not None:
                    got.append(oval)
                else:
                    mn, mx = p.num_args
                    j = i + 1
                    while j < len(rest) and len(got) < mx:
                        if len(got) >= mn and rest[j].startswith("-") and rest[j] in omap:
                            break
                        got.append(rest[j]); j += 1
                    i = j - 1
                if not got and p.required:
                    die_code("error: a value is required for `%s <VALUE>` but none was supplied" % name, 1)
                out = []
                for g in got:
                    out += g.split(p.delim) if p.delim else [g]
                for g in out:
                    validate(p, g)
                add_val(vals, p, out if (p.mult_occurs or len(out) > 1) else out[0])
                i += 1
            continue
        pos.append(t)
        i += 1

    # defaults
    for p in cmd.options:
        if p.default is not None and p.id not in vals:
            vals[p.id] = raw_default(p.default)
    # required options
    miss = [p for p in cmd.options if p.required and p.id not in vals]
    if miss:
        lines = ["error: the following required arguments were not provided:"]
        for p in miss:
            lines.append("  %s" % p.usage_piece())
        die_code("\n".join(lines), 1)
    bind_positionals(cmd, vals, pos)
    return cmd, vals, pos, "run"


def raw_default(v):
    return v


def add_val(vals, p, v):
    if p.flag:
        if p.mult_occurs:
            vals[p.id] = int(vals.get(p.id, 0)) + 1
        else:
            vals[p.id] = "1"
    elif p.mult_occurs:
        cur = vals.get(p.id, [])
        if not isinstance(cur, list):
            cur = [cur]
        if isinstance(v, list):
            cur += v
        else:
            cur.append(v)
        vals[p.id] = cur
    else:
        vals[p.id] = v


def bind_positionals(cmd, vals, pos):
    if not cmd.args and cmd.default_sub:
        return
    pi = 0
    remaining = list(pos)
    for idx, p in enumerate(cmd.args):
        if p.multiple:
            req_after = sum(1 for q in cmd.args[idx+1:] if q.required and not q.multiple)
            take = max(0, len(remaining) - req_after)
            if p.required and take == 0:
                missing(p)
            got = remaining[:take]
            remaining = remaining[take:]
            if p.delim:
                tmp = []
                for g in got: tmp += g.split(p.delim)
                got = tmp
            for g in got: validate(p, g)
            vals[p.id] = got
        else:
            if remaining:
                g = remaining.pop(0)
                validate(p, g)
                vals[p.id] = g
            elif p.default is not None:
                vals[p.id] = raw_default(p.default)
            elif p.required:
                missing(p)
    if remaining and not (cmd.args and cmd.args[-1].terminated):
        die_code("error: unexpected argument `%s` found" % remaining[0], 1)


def missing(p):
    die_code("error: the following required arguments were not provided:\n  %s" % p.usage_piece(), 1)


def emit_eval(file, argv):
    root = parse_file(file)
    cmd, vals, pos, action = parse_args(root, argv)
    if action == "help":
        emit_help(root, cmd)
        return
    if action == "version":
        print("echo %s" % shell_quote(cmd.version or root.version or ""))
        print("exit 0")
        return
    lines = []
    for k, v in vals.items():
        if isinstance(v, list):
            lines.append("argc_%s=%s" % (k, arr(v)))
        elif isinstance(v, str) and v.startswith("`") and v.endswith("`"):
            lines.append("argc_%s=%s" % (k, v))
        else:
            lines.append("argc_%s=%s" % (k, shell_quote(v)))
    fullargs = [os.path.splitext(os.path.basename(file))[0]] + argv
    lines.append("argc__args=%s" % arr(fullargs))
    if cmd.fn:
        lines.append("argc__fn=%s" % shell_quote(cmd.fn))
    bound_pos = positional_values(cmd, vals, pos)
    lines.append("argc__positionals=%s" % arr(bound_pos))
    env_lines = env_shell(root, cmd)
    blob = base64.b64encode(";".join(lines).encode()).decode()
    print("export ARGC_VARS=%s" % blob)
    for l in env_lines:
        print(l)
    for l in lines:
        print(l)
    if cmd.fn:
        call_args = bound_pos
        print("%s %s" % (cmd.fn, " ".join(shell_quote(x) for x in call_args)))


def positional_values(cmd, vals, original):
    if not cmd.args:
        return list(original)
    out = []
    for a in cmd.args:
        if a.id in vals:
            v = vals[a.id]
            if isinstance(v, list):
                out += v
            else:
                out.append(v)
    return out


def parse_env_spec(spec):
    tok = spec.split()[0] if spec.split() else spec
    name = re.split(r"[!\[=]", tok, 1)[0]
    required = "!" in tok
    default = None
    choice = None
    m = re.search(r"\[(.*)\]", tok)
    if m:
        body = m.group(1)
        if body.startswith("="):
            body = body[1:]
            default = body.split("|", 1)[0]
        choice = body
    if "=" in tok and default is None:
        default = tok.split("=", 1)[1]
    return name, required, default, choice


def env_shell(root, cmd):
    specs = []
    specs += root.envs
    if cmd is not root:
        specs += cmd.envs
    out = []
    if root.dotenv:
        out += [
            '_argc_load_dotenv() {',
            '    local env_file="$1"',
            '    if [[ -f "$env_file" ]]; then',
            '        set -a; source "$env_file"; set +a',
            '    fi',
            '}',
            '_argc_load_dotenv .env',
        ]
    missing_env = []
    for sp in specs:
        name, req, default, choice = parse_env_spec(sp)
        if not name:
            continue
        val = os.environ.get(name)
        if val is None and default is not None:
            out.append("export %s=%s" % (name, default if default.startswith("`") else shell_quote(default)))
            val = default
        if val is None and req:
            missing_env.append(name)
        vals = []
        if choice and not choice.startswith("`"):
            vals = [x for x in choice.lstrip("=").split("|") if x]
        if val is not None and vals and val not in vals:
            die_code("error: invalid value `%s` for `%s`\n  [possible values: %s]" % (val, name, ", ".join(vals)), 1)
    if missing_env:
        die_code("error: the following required environments were not provided:\n  " + "\n  ".join(missing_env), 1)
    return out


def emit_help(root, cmd):
    text = help_text(root, cmd)
    print("command cat >&2 <<-'EOF' ")
    print(text)
    print("EOF")
    print("exit 0")


def help_text(root, cmd):
    name_parts = [root.name]
    def find_path(c, target, path):
        if c is target:
            return path
        for ch in c.sub:
            r = find_path(ch, target, path + [ch.name])
            if r: return r
        return None
    path = find_path(root, cmd, [])
    if path:
        name_parts += path
    s = []
    if cmd.desc: s += [cmd.desc, ""]
    usage = "USAGE: " + " ".join(name_parts)
    if cmd.sub:
        usage += " <COMMAND>"
    else:
        opts = [p for p in cmd.options if p.required]
        if cmd.options:
            usage += " [OPTIONS]"
        for p in opts:
            usage += " " + p.usage_piece()
        for a in cmd.args:
            usage += " " + a.usage_piece()
    s += [usage, ""]
    if cmd.args:
        rows = []
        for a in cmd.args:
            rows.append((a.usage_piece(), a.desc))
        s += ["ARGS:"] + format_rows(rows) + [""]
    if cmd.options:
        rows = []
        for p in cmd.options + [help_param(False)]:
            nm = opt_display(p)
            rows.append((nm, p.desc + extra(p)))
        s += ["OPTIONS:"] + format_rows(rows) + [""]
    if cmd.sub:
        rows = []
        for c in cmd.sub:
            d = c.desc
            if c.aliases:
                d += " [aliases: %s]" % ", ".join(c.aliases)
            rows.append((c.name, d))
        s += ["COMMANDS:"] + format_rows(rows) + [""]
    return "\n".join(s).rstrip() + "\n"


def opt_display(p):
    ns = []
    if len(p.names) > 1:
        ns = p.names
    else:
        ns = p.names
    if p.flag:
        return ", ".join(ns)
    return (", ".join(ns) + " " + p.notation()).strip()


def extra(p):
    xs = []
    vals = possible_values(p)
    if vals: xs.append("[possible values: %s]" % ", ".join(vals))
    if p.default is not None and not (p.default.startswith("`") and p.default.endswith("`")):
        xs.append("[default: %s]" % p.default)
    return (" " + " ".join(xs)) if xs else ""


def format_rows(rows):
    if not rows: return []
    w = max(len(a) for a, _ in rows)
    return ["  %-*s  %s" % (w, a, b) if b else "  %s" % a for a, b in rows]


def export_json(file):
    print(json.dumps(parse_file(file).to_json(), indent=2))


def compgen(args):
    if len(args) < 2:
        return
    shell, file = args[0], args[1]
    argv = args[2:]
    root = parse_file(file) if file else Command("argc")
    cmd = root
    for t in argv[1:]:
        if t == "--" or t.startswith("-"):
            break
        c = find_sub(cmd, t)
        if c: cmd = c
    for c in cmd.sub:
        print("%s\t%s" % (c.name, c.desc))
    for p in cmd.options + [help_param(False)]:
        for n in p.names:
            if n.startswith("--") or len(p.names) == 1:
                print("%s (%s)" % (n, p.desc or "Print help"))


def completions(args):
    cmds = " ".join(args[1:]) if len(args) > 1 else "argc"
    print("_argc_completer() { COMPREPLY=( $(argc --argc-compgen bash \"\" \"${COMP_WORDS[@]}\" 2>/dev/null) ); }")
    print("complete -F _argc_completer %s" % cmds)


def create(args):
    names = args or ["default"]
    print("#!/usr/bin/env bash")
    for n in names:
        print("\n# @cmd")
        print("%s() {\n    :\n}" % n.replace("-", "_"))
    print('\neval "$(argc --argc-eval "$0" "$@")"')


def run_script(args):
    if not args:
        die_code("error: file required", 1)
    bin_path = os.path.abspath(sys.argv[0])
    env = dict(os.environ)
    env["ARGC_BIN"] = bin_path
    env["BASH_FUNC_argc%%"] = '() { "$ARGC_BIN" "$@"; }'
    p = subprocess.call(["bash"] + args, env=env)
    sys.exit(p)


def main():
    argv = sys.argv[1:]
    if not argv:
        path = "Argcfile.sh"
        if os.path.exists(path):
            run_script([path])
        print("Argcfile not found, try `argc --argc-help` for help.", file=sys.stderr)
        sys.exit(1)
    cmd = argv[0]
    rest = argv[1:]
    if cmd == "--argc-help":
        print("A bash cli framework, also a bash-based command runner - https://github.com/sigoden/argc\n")
        print("USAGE:")
        for l in [
            "    argc --argc-eval <FILE> <ARGS~>            Use `eval \"$(argc --argc-eval \"$0\" \"$@\")\"`",
            "    argc --argc-create <RECIPES~>              Create a boilerplate argcfile",
            "    argc --argc-run <FILE> <ARGS~>             Run an argc-based script",
            "    argc --argc-build <FILE> <OUTPATH?>        Generate bashscript without argc dependency",
            "    argc --argc-mangen <FILE> <OUTDIR>         Generate man pages",
            "    argc --argc-completions <SHELL> <CMDS>     Generate shell completion scripts",
            "    argc --argc-compgen <SHELL> <FILE> <ARGS>  Generate completion candidates",
            "    argc --argc-export <FILE>                  Export command line definitions as json",
            "    argc --argc-parallel <FILE> <ARGS~>        Run functions in parallel",
            "    argc --argc-script-path                    Print current argcfile path",
            "    argc --argc-shell-path                     Print current shell path",
            "    argc --argc-help                           Print help information",
            "    argc --argc-version                        Print version information",
        ]: print(l)
    elif cmd == "--argc-version":
        print("argc 1.23.0")
    elif cmd == "--argc-eval":
        if not rest: die_code("error: file required", 1)
        emit_eval(rest[0], rest[1:])
    elif cmd == "--argc-export":
        export_json(rest[0])
    elif cmd == "--argc-compgen":
        compgen(rest)
    elif cmd == "--argc-completions":
        completions(rest)
    elif cmd == "--argc-create":
        create(rest)
    elif cmd == "--argc-run":
        run_script(rest)
    elif cmd == "--argc-script-path":
        print(os.path.abspath("Argcfile.sh"))
    elif cmd == "--argc-shell-path":
        print(os.environ.get("SHELL", "/bin/bash"))
    elif cmd == "--argc-build":
        if not rest: sys.exit(1)
        src = open(rest[0], encoding="utf-8").read()
        out = rest[1] if len(rest) > 1 else "-"
        if out != "-":
            if os.path.isdir(out):
                out = os.path.join(out, os.path.basename(rest[0]))
            open(out, "w", encoding="utf-8").write(src)
            os.chmod(out, 0o755)
        else:
            print(src)
    elif cmd == "--argc-mangen":
        root = parse_file(rest[0])
        outdir = rest[1] if len(rest) > 1 else "."
        os.makedirs(outdir, exist_ok=True)
        open(os.path.join(outdir, root.name + ".1"), "w").write(".TH %s 1\n.SH NAME\n%s\n" % (root.name.upper(), root.name))
    elif cmd == "--argc-parallel":
        # Run sequentially; enough for scripts that only depend on preserved argc vars.
        if len(rest) >= 2:
            file = rest[0]
            jobs = []
            cur = []
            for x in rest[1:]:
                if x == ":::":
                    if cur: jobs.append(cur); cur = []
                else:
                    cur.append(x)
            if cur: jobs.append(cur)
            for j in jobs:
                subprocess.call(["bash", file] + j)
    else:
        path = "Argcfile.sh"
        if os.path.exists(path):
            run_script([path] + argv)
        print("Argcfile not found, try `argc --argc-help` for help.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
