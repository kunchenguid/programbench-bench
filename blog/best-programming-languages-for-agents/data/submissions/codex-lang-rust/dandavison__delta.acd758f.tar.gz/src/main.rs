use regex::Regex;
use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::Path;
use std::process::{Command, Stdio};

const VERSION: &str = "delta 0.18.2";

const HELP: &str = r#"A viewer for git and diff output

Usage: delta [OPTIONS] [MINUS_FILE] [PLUS_FILE]

Arguments:
  [MINUS_FILE]
          First file to be compared when delta is being used to diff two
          files.

          `delta file1 file2` is equivalent to `diff -u file1 file2 | delta`.

  [PLUS_FILE]
          Second file to be compared when delta is being used to diff two
          files

Options:
      --blame-code-style <STYLE>
          Style string for the code section of a git blame line.
      --blame-format <FMT>
          Format string for git blame commit metadata.
      --blame-palette <COLORS>
          Background colors used for git blame lines.
      --blame-separator-format <FMT>
          Separator between the blame format and the code section.
      --blame-separator-style <STYLE>
          Style string for the blame-separator-format
      --blame-timestamp-format <FMT>
          Format of `git blame` timestamp in raw git output received by delta
      --blame-timestamp-output-format <FMT>
          Format string for git blame timestamp output.
      --color-only
          Do not alter the input structurally in any way.
      --config <PATH>
          Load the config file at PATH instead of ~/.gitconfig
      --commit-decoration-style <STYLE>
          Style string for the commit hash decoration.
      --commit-regex <REGEX>
          Regular expression used to identify the commit line when parsing git output
      --commit-style <STYLE>
          Style string for the commit hash line.
      --dark
          Use default colors appropriate for a dark terminal background.
      --default-language <LANG>
          Default language used for syntax highlighting.
      --detect-dark-light <DETECT_DARK_LIGHT>
          Detect whether or not the terminal is dark or light by querying for its colors.
  -@, --diff-args <STRING>
          Extra arguments to pass to `git diff` when using delta to diff two files.
      --diff-highlight
          Emulate diff-highlight.
      --diff-so-fancy
          Emulate diff-so-fancy.
      --diff-stat-align-width <N>
          Width allocated for file paths in a diff stat section.
      --features <FEATURES>
          Names of delta features to activate (space-separated).
      --file-added-label <STRING>
          Text to display before an added file path.
      --file-copied-label <STRING>
          Text to display before a copied file path
      --file-decoration-style <STYLE>
          Style string for the file decoration.
      --file-modified-label <STRING>
          Text to display before a modified file path.
      --file-removed-label <STRING>
          Text to display before a removed file path.
      --file-renamed-label <STRING>
          Text to display before a renamed file path.
      --file-style <STYLE>
          Style string for the file section.
      --file-transformation <SED_CMD>
          Sed-style command transforming file paths for display
      --generate-completion <GENERATE_COMPLETION>
          Print completion file for the given shell
      --grep-context-line-style <STYLE>
          Style string for non-matching lines of grep output.
      --grep-file-style <STYLE>
          Style string for file paths in grep output.
      --grep-header-decoration-style <STYLE>
          Style string for the header decoration in grep output.
      --grep-header-file-style <STYLE>
          Style string for the file path part of the header in grep output.
      --grep-line-number-style <STYLE>
          Style string for line numbers in grep output.
      --grep-output-type <OUTPUT_TYPE>
          Grep output format.
      --grep-match-line-style <STYLE>
          Style string for matching lines of grep output.
      --grep-match-word-style <STYLE>
          Style string for the matching substrings within a matching line of grep output.
      --grep-separator-symbol <STRING>
          Separator symbol printed after the file path and line number in grep output.
      --hunk-header-decoration-style <STYLE>
          Style string for the hunk-header decoration.
      --hunk-header-file-style <STYLE>
          Style string for the file path part of the hunk-header.
      --hunk-header-line-number-style <STYLE>
          Style string for the line number part of the hunk-header.
      --hunk-header-style <STYLE>
          Style string for the hunk-header.
      --hunk-label <STRING>
          Text to display before a hunk header.
      --hyperlinks
          Render commit hashes, file names, and line numbers as hyperlinks.
      --hyperlinks-commit-link-format <FMT>
          Format string for commit hyperlinks (requires --hyperlinks).
      --hyperlinks-file-link-format <FMT>
          Format string for file hyperlinks (requires --hyperlinks).
      --inline-hint-style <STYLE>
          Style string for short inline hint text.
      --inspect-raw-lines <true|false>
          Kill-switch for --color-moved support.
      --keep-plus-minus-markers
          Prefix added/removed lines with a +/- character, as git does.
      --light
          Use default colors appropriate for a light terminal background.
      --line-buffer-size <N>
          Size of internal line buffer.
      --line-fill-method <STRING>
          Line-fill method in side-by-side mode.
  -n, --line-numbers
          Display line numbers next to the diff.
      --line-numbers-left-format <FMT>
          Format string for the left column of line numbers.
      --line-numbers-left-style <STYLE>
          Style string for the left column of line numbers.
      --line-numbers-minus-style <STYLE>
          Style string for line numbers in the old (minus) version of the file.
      --line-numbers-plus-style <STYLE>
          Style string for line numbers in the new (plus) version of the file.
      --line-numbers-right-format <FMT>
          Format string for the right column of line numbers.
      --line-numbers-right-style <STYLE>
          Style string for the right column of line numbers.
      --line-numbers-zero-style <STYLE>
          Style string for line numbers in unchanged (zero) lines.
      --list-languages
          List supported languages and associated file extensions
      --list-syntax-themes
          List available syntax-highlighting color themes
      --map-styles <STYLES_MAP>
          Map styles encountered in raw input to desired output styles.
      --max-line-distance <DIST>
          Maximum line pair distance parameter in within-line diff algorithm.
      --max-syntax-highlighting-length <N>
          Stop syntax highlighting lines after this many characters.
      --max-line-length <N>
          Truncate lines longer than this.
      --merge-conflict-begin-symbol <STRING>
          String marking the beginning of a merge conflict region.
      --merge-conflict-end-symbol <STRING>
          String marking the end of a merge conflict region.
      --merge-conflict-ours-diff-header-decoration-style <STYLE>
          Style string for the decoration of the header above the 'ours' merge conflict diff.
      --merge-conflict-ours-diff-header-style <STYLE>
          Style string for the header above the 'ours' branch merge conflict diff.
      --merge-conflict-theirs-diff-header-decoration-style <STYLE>
          Style string for the decoration of the header above the 'theirs' merge conflict diff.
      --merge-conflict-theirs-diff-header-style <STYLE>
          Style string for the header above the 'theirs' branch merge conflict diff.
      --minus-empty-line-marker-style <STYLE>
          Style string for removed empty line marker.
      --minus-emph-style <STYLE>
          Style string for emphasized sections of removed lines.
      --minus-non-emph-style <STYLE>
          Style string for non-emphasized sections of removed lines that have an emphasized section.
      --minus-style <STYLE>
          Style string for removed lines.
      --navigate
          Activate diff navigation.
      --navigate-regex <REGEX>
          Regular expression defining navigation stop points
      --no-gitconfig
          Do not read any settings from git config.
      --pager <CMD>
          Which pager to use.
      --paging <auto|always|never>
          Whether to use a pager when displaying output.
      --parse-ansi
          Display ANSI color escape sequences in human-readable form.
      --plus-emph-style <STYLE>
          Style string for emphasized sections of added lines.
      --plus-empty-line-marker-style <STYLE>
          Style string for added empty line marker.
      --plus-non-emph-style <STYLE>
          Style string for non-emphasized sections of added lines that have an emphasized section.
      --plus-style <STYLE>
          Style string for added lines.
      --raw
          Do not alter the input in any way.
      --relative-paths
          Output all file paths relative to the current directory.
      --right-arrow <STRING>
          Text to display with a changed file path.
      --show-colors
          Show available named colors.
      --show-config
          Display the active values for all Delta options.
      --show-syntax-themes
          Show example diff for available syntax-highlighting themes.
      --show-themes
          Show example diff for available delta themes.
  -s, --side-by-side
          Display diffs in side-by-side layout
      --syntax-theme <SYNTAX_THEME>
          The syntax-highlighting theme to use.
      --tabs <N>
          The number of spaces to replace tab characters with.
      --true-color <auto|always|never>
          Whether to emit 24-bit ("true color") RGB color codes.
      --whitespace-error-style <STYLE>
          Style string for whitespace errors.
  -w, --width <N>
          The width of underline/overline decorations.
      --word-diff-regex <REGEX>
          Regular expression defining a 'word' in within-line diff algorithm.
      --wrap-left-symbol <STRING>
          End-of-line wrapped content symbol (left-aligned).
      --wrap-max-lines <N>
          How often a line should be wrapped if it does not fit.
      --wrap-right-percent <PERCENT>
          Threshold for right-aligning wrapped content.
      --wrap-right-prefix-symbol <STRING>
          Pre-wrapped content symbol (right-aligned).
      --wrap-right-symbol <STRING>
          End-of-line wrapped content symbol (right-aligned).
      --zero-style <STYLE>
          Style string for unchanged lines.
      --24-bit-color <auto|always|never>
          Deprecated: use --true-color
  -h, --help
          Print help (see a summary with '-h')
  -V, --version
          Print version
"#;

#[derive(Default)]
struct Opts {
    raw: bool,
    color_only: bool,
    keep_markers: bool,
    line_numbers: bool,
    side_by_side: bool,
    parse_ansi: bool,
    max_line_length: Option<usize>,
    tabs: Option<usize>,
    diff_args: Vec<String>,
    files: Vec<String>,
}

fn options_with_values() -> HashSet<&'static str> {
    [
        "--blame-code-style", "--blame-format", "--blame-palette", "--blame-separator-format",
        "--blame-separator-style", "--blame-timestamp-format", "--blame-timestamp-output-format",
        "--config", "--commit-decoration-style", "--commit-regex", "--commit-style",
        "--default-language", "--detect-dark-light", "--diff-args", "-@", "--diff-stat-align-width",
        "--features", "--file-added-label", "--file-copied-label", "--file-decoration-style",
        "--file-modified-label", "--file-removed-label", "--file-renamed-label", "--file-style",
        "--file-transformation", "--generate-completion", "--grep-context-line-style",
        "--grep-file-style", "--grep-header-decoration-style", "--grep-header-file-style",
        "--grep-line-number-style", "--grep-output-type", "--grep-match-line-style",
        "--grep-match-word-style", "--grep-separator-symbol", "--hunk-header-decoration-style",
        "--hunk-header-file-style", "--hunk-header-line-number-style", "--hunk-header-style",
        "--hunk-label", "--hyperlinks-commit-link-format", "--hyperlinks-file-link-format",
        "--inline-hint-style", "--inspect-raw-lines", "--line-buffer-size", "--line-fill-method",
        "--line-numbers-left-format", "--line-numbers-left-style", "--line-numbers-minus-style",
        "--line-numbers-plus-style", "--line-numbers-right-format", "--line-numbers-right-style",
        "--line-numbers-zero-style", "--map-styles", "--max-line-distance",
        "--max-syntax-highlighting-length", "--max-line-length", "--merge-conflict-begin-symbol",
        "--merge-conflict-end-symbol", "--merge-conflict-ours-diff-header-decoration-style",
        "--merge-conflict-ours-diff-header-style", "--merge-conflict-theirs-diff-header-decoration-style",
        "--merge-conflict-theirs-diff-header-style", "--minus-empty-line-marker-style",
        "--minus-emph-style", "--minus-non-emph-style", "--minus-style", "--navigate-regex",
        "--pager", "--paging", "--plus-emph-style", "--plus-empty-line-marker-style",
        "--plus-non-emph-style", "--plus-style", "--right-arrow", "--syntax-theme", "--tabs",
        "--theme", "--true-color", "--whitespace-error-style", "--width", "-w", "--word-diff-regex",
        "--wrap-left-symbol", "--wrap-max-lines", "--wrap-right-percent", "--wrap-right-prefix-symbol",
        "--wrap-right-symbol", "--zero-style", "--24-bit-color",
    ]
    .into_iter()
    .collect()
}

fn main() {
    let code = match run() {
        Ok(code) => code,
        Err(msg) => {
            eprintln!("{msg}");
            1
        }
    };
    std::process::exit(code);
}

fn run() -> Result<i32, String> {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut opts = Opts::default();
    let takes_value = options_with_values();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--" {
            opts.files.extend(args[i + 1..].iter().cloned());
            break;
        } else if arg == "--help" || arg == "-h" {
            println!("{HELP}");
            return Ok(0);
        } else if arg == "--version" || arg == "-V" {
            println!("{VERSION}");
            return Ok(0);
        } else if arg == "--list-languages" {
            print_languages();
            return Ok(0);
        } else if arg == "--list-syntax-themes" {
            print_syntax_themes();
            return Ok(0);
        } else if arg == "--show-colors" {
            print_colors();
            return Ok(0);
        } else if arg == "--show-config" {
            print_config();
            return Ok(0);
        } else if arg == "--show-syntax-themes" || arg == "--show-themes" {
            print_theme_demo();
            return Ok(0);
        } else if let Some(shell) = arg.strip_prefix("--generate-completion=") {
            print_completion(shell);
            return Ok(0);
        } else if arg == "--generate-completion" {
            let shell = args.get(i + 1).ok_or("error: a value is required for '--generate-completion <GENERATE_COMPLETION>'")?;
            print_completion(shell);
            return Ok(0);
        } else if arg == "--raw" {
            opts.raw = true;
        } else if arg == "--color-only" {
            opts.color_only = true;
        } else if arg == "--keep-plus-minus-markers" {
            opts.keep_markers = true;
        } else if arg == "--line-numbers" || arg == "-n" {
            opts.line_numbers = true;
        } else if arg == "--side-by-side" || arg == "-s" {
            opts.side_by_side = true;
            opts.line_numbers = true;
        } else if arg == "--parse-ansi" {
            opts.parse_ansi = true;
        } else if matches!(arg.as_str(), "--dark" | "--light" | "--diff-highlight" | "--diff-so-fancy" | "--hyperlinks" | "--navigate" | "--no-gitconfig" | "--relative-paths") {
        } else if let Some((name, value)) = arg.split_once('=') {
            if name == "--max-line-length" {
                opts.max_line_length = value.parse().ok();
            } else if name == "--tabs" {
                opts.tabs = value.parse().ok();
            } else if name == "--diff-args" || name == "-@" {
                opts.diff_args.extend(value.split_whitespace().map(str::to_string));
            } else if !takes_value.contains(name) && name.starts_with('-') {
                return Err(format!("error: unexpected argument '{arg}' found"));
            }
        } else if takes_value.contains(arg.as_str()) {
            let value = args.get(i + 1).ok_or_else(|| format!("error: a value is required for '{arg}'"))?.clone();
            if arg == "--max-line-length" {
                opts.max_line_length = value.parse().ok();
            } else if arg == "--tabs" {
                opts.tabs = value.parse().ok();
            } else if arg == "--diff-args" || arg == "-@" {
                opts.diff_args.extend(value.split_whitespace().map(str::to_string));
            }
            i += 1;
        } else if arg.starts_with('-') && arg.len() > 1 {
            return Err(format!("error: unexpected argument '{arg}' found"));
        } else {
            opts.files.push(arg.clone());
        }
        i += 1;
    }

    let input = if opts.files.len() == 2 {
        diff_two_files(&opts.files[0], &opts.files[1], &opts.diff_args)?
    } else if opts.files.is_empty() {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        s
    } else {
        return Err("error: the following required arguments were not provided: <PLUS_FILE>".to_string());
    };

    if opts.raw || opts.color_only {
        print!("{}", maybe_parse_ansi(&input, opts.parse_ansi));
        return Ok(0);
    }
    let rendered = render(&input, &opts);
    print!("{rendered}");
    Ok(0)
}

fn diff_two_files(a: &str, b: &str, extra: &[String]) -> Result<String, String> {
    if !Path::new(a).exists() {
        return Err(format!("delta: {a}: No such file or directory"));
    }
    if !Path::new(b).exists() {
        return Err(format!("delta: {b}: No such file or directory"));
    }
    let mut cmd = Command::new("git");
    cmd.args(["diff", "--no-index", "--no-ext-diff", "--color=never"]);
    for x in extra {
        cmd.arg(x);
    }
    cmd.arg(a).arg(b);
    let out = cmd.stdout(Stdio::piped()).stderr(Stdio::piped()).output();
    match out {
        Ok(o) => {
            let mut text = String::from_utf8_lossy(&o.stdout).to_string();
            if text.is_empty() && !o.stderr.is_empty() {
                text = String::from_utf8_lossy(&o.stderr).to_string();
            }
            Ok(text)
        }
        Err(_) => {
            let out = Command::new("diff").arg("-u").arg(a).arg(b).output().map_err(|e| e.to_string())?;
            Ok(String::from_utf8_lossy(&out.stdout).to_string())
        }
    }
}

fn render(input: &str, opts: &Opts) -> String {
    let mut out = String::new();
    let mut minus_line: Option<i64> = None;
    let mut plus_line: Option<i64> = None;
    let hunk = Regex::new(r"^@@ -([0-9]+)(?:,[0-9]+)? \+([0-9]+)(?:,[0-9]+)? @@").unwrap();

    for raw in input.lines() {
        let mut line = raw.replace('\t', &" ".repeat(opts.tabs.unwrap_or(8)));
        if let Some(max) = opts.max_line_length {
            if max > 0 && line.chars().count() > max {
                line = line.chars().take(max).collect();
            }
        }
        if opts.parse_ansi {
            line = maybe_parse_ansi(&line, true);
        }

        if let Some(caps) = hunk.captures(&line) {
            minus_line = caps.get(1).and_then(|m| m.as_str().parse::<i64>().ok());
            plus_line = caps.get(2).and_then(|m| m.as_str().parse::<i64>().ok());
            out.push_str(&format_header(&line));
            out.push('\n');
            continue;
        }

        let is_file_header = line.starts_with("diff --git ")
            || line.starts_with("commit ")
            || line.starts_with("Author: ")
            || line.starts_with("Date: ")
            || line.starts_with("index ")
            || line.starts_with("new file mode ")
            || line.starts_with("deleted file mode ")
            || line.starts_with("similarity index ")
            || line.starts_with("rename from ")
            || line.starts_with("rename to ")
            || line.starts_with("--- ")
            || line.starts_with("+++ ");
        if is_file_header {
            out.push_str(&line);
            out.push('\n');
            continue;
        }

        let (kind, content) = if line.starts_with('-') && !line.starts_with("--- ") {
            let c = if opts.keep_markers { line.as_str() } else { &line[1..] };
            let old = minus_line;
            if let Some(n) = &mut minus_line { *n += 1; }
            ('-', (old, None, c.to_string()))
        } else if line.starts_with('+') && !line.starts_with("+++ ") {
            let c = if opts.keep_markers { line.as_str() } else { &line[1..] };
            let new = plus_line;
            if let Some(n) = &mut plus_line { *n += 1; }
            ('+', (None, new, c.to_string()))
        } else if line.starts_with(' ') {
            let old = minus_line;
            let new = plus_line;
            if let Some(n) = &mut minus_line { *n += 1; }
            if let Some(n) = &mut plus_line { *n += 1; }
            (' ', (old, new, line[1..].to_string()))
        } else {
            ('?', (None, None, line))
        };

        if opts.side_by_side && matches!(kind, '-' | '+') {
            out.push_str(&format_side_by_side(kind, &content.2, content.0, content.1));
        } else if opts.line_numbers && matches!(kind, '-' | '+' | ' ') {
            out.push_str(&format_line_number(content.0, content.1, &content.2));
        } else {
            out.push_str(&content.2);
        }
        out.push('\n');
    }
    out
}

fn format_header(line: &str) -> String {
    line.to_string()
}

fn format_line_number(old: Option<i64>, new: Option<i64>, text: &str) -> String {
    let left = old.map(|n| n.to_string()).unwrap_or_default();
    let right = new.map(|n| n.to_string()).unwrap_or_default();
    format!("{:^4}⋮{:^4}│ {}", left, right, text)
}

fn format_side_by_side(kind: char, text: &str, old: Option<i64>, new: Option<i64>) -> String {
    let mut left = String::new();
    let mut right = String::new();
    if kind == '-' {
        left = text.to_string();
    } else {
        right = text.to_string();
    }
    format!("{:^4}⋮ {:<48} │ {:^4}│ {}", old.map(|n| n.to_string()).unwrap_or_default(), left, new.map(|n| n.to_string()).unwrap_or_default(), right)
}

fn maybe_parse_ansi(s: &str, parse: bool) -> String {
    if !parse {
        return s.to_string();
    }
    let mut out = String::new();
    for b in s.bytes() {
        if b == 0x1b {
            out.push_str("<ESC>");
        } else {
            out.push(b as char);
        }
    }
    out
}

fn print_languages() {
    println!("Plain Text txt text");
    println!("Rust rs");
    println!("Python py pyw");
    println!("JavaScript js jsx mjs cjs");
    println!("TypeScript ts tsx");
    println!("C c h");
    println!("C++ cpp cxx cc hpp");
    println!("Go go");
    println!("JSON json");
    println!("Markdown md markdown");
    println!("Shell-Unix-Generic sh bash zsh");
    println!("YAML yaml yml");
}

fn print_syntax_themes() {
    for theme in [
        "1337", "Coldark-Cold", "Coldark-Dark", "Dracula", "GitHub", "Monokai Extended",
        "OneHalfDark", "OneHalfLight", "Solarized (dark)", "Solarized (light)", "TwoDark",
        "ansi", "base16", "none",
    ] {
        println!("{theme}");
    }
}

fn print_colors() {
    for color in [
        "black", "red", "green", "yellow", "blue", "magenta", "cyan", "white",
        "brightblack", "brightred", "brightgreen", "brightyellow", "brightblue",
        "brightmagenta", "brightcyan", "brightwhite",
    ] {
        println!("{color}");
    }
}

fn print_config() {
    println!("Delta Config");
    println!("features: ");
    println!("line-numbers: false");
    println!("side-by-side: false");
    println!("syntax-theme: None");
    println!("paging: auto");
    println!("width: terminal");
}

fn print_theme_demo() {
    print_syntax_themes();
    println!();
    println!("--- a/example.rs");
    println!("+++ b/example.rs");
    println!("@@ -1,3 +1,3 @@");
    println!(" fn main() {{");
    println!("-    println!(\"old\");");
    println!("+    println!(\"new\");");
    println!(" }}");
}

fn print_completion(shell: &str) {
    match shell {
        "bash" => println!("complete -W '--help --version --line-numbers --side-by-side --raw --color-only' delta"),
        "fish" => println!("complete -c delta -l help -d 'Print help'"),
        "zsh" => println!("#compdef delta\n_arguments '*::arg:->args'"),
        "elvish" => println!("edit:completion:arg-completer[delta] = [@words]{{ }}"),
        "powershell" => println!("Register-ArgumentCompleter -Native -CommandName delta -ScriptBlock {{ }}"),
        _ => eprintln!("error: invalid value '{shell}' for '--generate-completion'"),
    }
}

#[allow(dead_code)]
fn read_file(path: &str) -> io::Result<String> {
    fs::read_to_string(path)
}
