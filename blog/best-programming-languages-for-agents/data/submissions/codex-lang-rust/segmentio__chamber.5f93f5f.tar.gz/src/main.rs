use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::os::unix::process::CommandExt;
use std::process::{Command, ExitCode};

const TOP_HELP: &str = r#"CLI for storing secrets

Usage:
  chamber [command]

Available Commands:
  completion    Generate the autocompletion script for the specified shell
  delete        Delete a secret, including all versions
  env           Print the secrets from the parameter store in a format to export as environment variables
  exec          Executes a command with secrets loaded into the environment
  export        Exports parameters in the specified format
  find          Find the given secret across all services
  help          Help about any command
  history       View the history of a secret
  import        import secrets from json or yaml
  list          List the secrets set for a service
  list-services List services
  read          Read a specific secret from the parameter store
  tag           work with tags on secrets
  version       print version
  write         write a secret

Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   	null: no-op
                                   	ssm: SSM Parameter Store
                                   	secretsmanager: Secrets Manager
                                   	s3: S3; requires --backend-s3-bucket
                                   	s3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
  -h, --help                       help for chamber
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    standard
                                    adaptive (default "standard")
      --verbose                    Print more information to STDERR

Use "chamber [command] --help" for more information about a command.
"#;

const GLOBAL_FLAGS: &str = r#"Global Flags:
  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND
                                   	null: no-op
                                   	ssm: SSM Parameter Store
                                   	secretsmanager: Secrets Manager
                                   	s3: S3; requires --backend-s3-bucket
                                   	s3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default "ssm")
      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET
      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default "alias/parameter_store_key")
  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)
      --retry-mode string          For SSM, the model used to retry requests
                                    standard
                                    adaptive (default "standard")
      --verbose                    Print more information to STDERR
"#;

struct Cli {
    backend: String,
    args: Vec<String>,
}

fn main() -> ExitCode {
    match run() {
        Ok(code) => ExitCode::from(code),
        Err(msg) => {
            eprintln!("Error: {}", msg);
            ExitCode::from(1)
        }
    }
}

fn run() -> Result<u8, String> {
    let cli = parse_global(env::args().skip(1).collect());
    let args = cli.args;
    if args.is_empty() || has_flag(&args, "-h", "--help") {
        print!("{}", TOP_HELP);
        return Ok(0);
    }
    if args[0] == "help" {
        if args.len() == 1 { print!("{}", TOP_HELP); } else { print_help_path(&args[1..]); }
        return Ok(0);
    }
    if cli.backend.to_uppercase() != "NULL" && cli.backend != "ssm" {
        if args.get(0).map(String::as_str) == Some("version") { println!("chamber dev"); }
        return Err(format!("Failed to get secret store: invalid backend `{}`", cli.backend.to_uppercase()));
    }

    match args[0].as_str() {
        "version" => { println!("chamber dev"); Ok(0) }
        "list" => cmd_list(&args[1..]),
        "list-services" => cmd_list_services(&args[1..]),
        "read" => cmd_read(&args[1..]),
        "env" => cmd_env(&args[1..]),
        "export" => cmd_export(&args[1..]),
        "find" => cmd_find(&args[1..]),
        "history" => cmd_history(&args[1..]),
        "write" => cmd_write(&args[1..]),
        "delete" => cmd_delete(&args[1..]),
        "import" => cmd_import(&args[1..]),
        "exec" => cmd_exec(&args[1..]),
        "tag" => cmd_tag(&args[1..]),
        "completion" => cmd_completion(&args[1..]),
        other => {
            eprintln!("Error: unknown command {:?} for {:?}\nRun 'chamber --help' for usage.", other, "chamber");
            Ok(1)
        }
    }
}

fn parse_global(input: Vec<String>) -> Cli {
    let mut backend = env::var("CHAMBER_SECRET_BACKEND").unwrap_or_else(|_| "ssm".to_string());
    let mut args = Vec::new();
    let mut i = 0;
    while i < input.len() {
        match input[i].as_str() {
            "-b" | "--backend" => { if i + 1 < input.len() { backend = input[i + 1].clone(); i += 2; } else { i += 1; } }
            s if s.starts_with("--backend=") => { backend = s[10..].to_string(); i += 1; }
            "--backend-s3-bucket" | "--kms-key-alias" | "-r" | "--retries" | "--retry-mode" => { i += if i + 1 < input.len() { 2 } else { 1 }; }
            s if s.starts_with("--backend-s3-bucket=") || s.starts_with("--kms-key-alias=") || s.starts_with("--retries=") || s.starts_with("--retry-mode=") => { i += 1; }
            "--verbose" => i += 1,
            _ => { args.push(input[i].clone()); i += 1; }
        }
    }
    Cli { backend, args }
}

fn has_flag(args: &[String], short: &str, long: &str) -> bool { args.iter().any(|a| a == short || a == long) }
fn strip_flags(args: &[String], specs: &[(&str, bool)]) -> Vec<String> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < args.len() {
        if args[i] == "--" { out.extend_from_slice(&args[i+1..]); break; }
        if let Some((_, takes)) = specs.iter().find(|(n, _)| *n == args[i]) {
            i += if *takes { 2 } else { 1 };
        } else if specs.iter().any(|(n, takes)| *takes && args[i].starts_with(&format!("{}=", n))) {
            i += 1;
        } else {
            out.push(args[i].clone()); i += 1;
        }
    }
    out
}

fn arg_error(msg: &str, usage: &str) -> Result<u8, String> {
    eprintln!("Error: {}", msg);
    eprintln!("{}", usage);
    Ok(1)
}

fn cmd_list(args: &[String]) -> Result<u8, String> {
    if has_flag(args, "-h", "--help") { print!("{}", help_list()); return Ok(0); }
    let expand = has_flag(args, "-e", "--expand");
    let pos = strip_flags(args, &[("-e", false),("--expand", false),("-t", false),("--time", false),("-u", false),("--user", false),("-v", false),("--version", false)]);
    if pos.len() != 1 { return arg_error(&format!("accepts 1 arg(s), received {}", pos.len()), &help_list()); }
    if expand { println!("Key\tVersion\t\tLastModified\tUser\tValue"); } else { println!("Key\tVersion\t\tLastModified\tUser"); }
    Ok(0)
}
fn cmd_list_services(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_list_services()); return Ok(0); } println!("Service"); Ok(0) }
fn cmd_read(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_read()); return Ok(0); } let quiet=has_flag(args,"-q","--quiet"); let pos=strip_flags(args,&[("-q",false),("--quiet",false),("-v",true),("--version",true)]); if pos.len()!=2 { return arg_error(&format!("accepts 2 arg(s), received {}", pos.len()), &help_read()); } if quiet { return Err("Failed to read: Not implemented for Null Store".into()); } eprintln!("Error: Failed to read: Not implemented for Null Store\nor \"chamber\"\nRun 'chamber --help' for usage."); Ok(1) }
fn cmd_env(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_env()); return Ok(0); } let pos=strip_flags(args,&[("-p",false),("--preserve-case",false),("-e",false),("--escape-strings",false)]); if pos.len()!=1 { return arg_error(&format!("accepts 1 arg(s), received {}", pos.len()), &help_env()); } Ok(0) }
fn cmd_export(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_export()); return Ok(0); } let mut fmt="json".to_string(); let mut output=None::<String>; let mut pos=Vec::new(); let mut i=0; while i<args.len(){ match args[i].as_str(){"-f"|"--format"=>{if i+1<args.len(){fmt=args[i+1].clone();} i+=2}, s if s.starts_with("--format=")=>{fmt=s[9..].to_string();i+=1}, "-o"|"--output-file"=>{if i+1<args.len(){output=Some(args[i+1].clone());} i+=2}, s if s.starts_with("--output-file=")=>{output=Some(s[14..].to_string());i+=1}, _=>{pos.push(args[i].clone());i+=1}} } if pos.is_empty(){return arg_error("requires at least 1 arg(s), only received 0", &help_export());} let content=match fmt.as_str(){"json"|"yaml"=>"{}\n".to_string(),"csv"|"tsv"|"dotenv"|"java-properties"|"tfvars"=>String::new(), _=>return Err(format!("Unable to export parameters: Unsupported export format: {}",fmt))}; if let Some(path)=output{fs::write(path, content).map_err(|e|e.to_string())?;} else {print!("{}",content);} Ok(0) }
fn cmd_find(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_find()); return Ok(0); } let pos=strip_flags(args,&[("-v",false),("--by-value",false)]); if pos.len()!=1 { return arg_error(&format!("accepts 1 arg(s), received {}", pos.len()), &help_find()); } println!("Service"); Ok(0) }
fn cmd_history(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_history()); return Ok(0); } let pos=strip_flags(args,&[]); if pos.len()!=2 { return arg_error(&format!("accepts 2 arg(s), received {}", pos.len()), &help_history()); } println!("Event\tVersion\t\tDate\tUser"); Ok(0) }
fn cmd_write(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_write()); return Ok(0); } let pos=strip_flags(args,&[("-s",false),("--singleline",false),("--skip-unchanged",false),("-t",true),("--tags",true)]); if pos.len()!=3 { return arg_error(&format!("accepts 3 arg(s), received {}", pos.len()), &help_write()); } if pos[2]=="-" { let mut s=String::new(); let _=io::stdin().read_to_string(&mut s); } Err("Write is not implemented for Null Store".into()) }
fn cmd_delete(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_delete()); return Ok(0); } let pos=strip_flags(args,&[("--exact-key",false)]); if pos.len()!=2 { return arg_error(&format!("accepts 2 arg(s), received {}", pos.len()), &help_delete()); } Err("Not implemented for Null Store".into()) }
fn cmd_import(args: &[String]) -> Result<u8, String> { if has_flag(args,"-h","--help") { print!("{}", help_import()); return Ok(0); } let pos=strip_flags(args,&[("--normalize-keys",false)]); if pos.len()!=2 { return arg_error(&format!("accepts 2 arg(s), received {}", pos.len()), &help_import()); } if pos[1]=="-" { let mut s=String::new(); let _=io::stdin().read_to_string(&mut s); } Err("Failed to write secret: Write is not implemented for Null Store".into()) }

fn cmd_exec(args: &[String]) -> Result<u8, String> {
    if has_flag(args,"-h","--help") { print!("{}", help_exec()); return Ok(0); }
    let mut strict=false; let mut pristine=false; let mut strict_value="chamberme".to_string(); let mut before=Vec::new(); let mut cmd=Vec::new(); let mut after=false; let mut i=0;
    while i<args.len(){ if after { cmd.push(args[i].clone()); i+=1; continue; } match args[i].as_str(){"--"=>{after=true;i+=1},"--strict"=>{strict=true;i+=1},"--pristine"=>{pristine=true;i+=1},"--strict-value"=>{if i+1<args.len(){strict_value=args[i+1].clone();} i+=2},s if s.starts_with("--strict-value=")=>{strict_value=s[15..].to_string();i+=1},_=>{before.push(args[i].clone());i+=1}} }
    if !after || before.is_empty() || cmd.is_empty() { eprintln!("Error: please separate services and command with '--'. See usage\n{}", help_exec()); return Ok(1); }
    if strict { for (k,v) in env::vars(){ if v==strict_value { eprintln!("Error: parent env was expecting {}={}, but was not in store", k, strict_value); return Ok(1); } } }
    let mut c=Command::new(&cmd[0]); if cmd.len()>1 { c.args(&cmd[1..]); } if pristine { c.env_clear(); }
    let err=c.exec(); Err(err.to_string())
}

fn cmd_tag(args: &[String]) -> Result<u8, String> { if args.is_empty() || has_flag(args,"-h","--help") { print!("{}", help_tag()); return Ok(0); } match args[0].as_str(){"read"=>{if has_flag(&args[1..],"-h","--help"){print!("{}",help_tag_read());Ok(0)}else{println!("{{}}");Err("Failed to read tags: Not implemented for Null Store".into())}},"write"=>{if has_flag(&args[1..],"-h","--help"){print!("{}",help_tag_write());Ok(0)}else{Err("Failed to write tags: Not implemented for Null Store".into())}},"delete"=>{if has_flag(&args[1..],"-h","--help"){print!("{}",help_tag_delete());Ok(0)}else{Err("Failed to delete tags: Not implemented for Null Store".into())}},_=>{print!("{}",help_tag());Ok(1)}} }
fn cmd_completion(args: &[String]) -> Result<u8, String> { if args.is_empty() || has_flag(args,"-h","--help") { print!("{}", help_completion()); return Ok(0); } if has_flag(&args[1..],"-h","--help") { match args[0].as_str(){"bash"=>print!("{}",help_completion_bash()),"zsh"=>print!("{}",help_completion_zsh()),_=>print!("{}",help_completion())}; } else { println!("# completion for chamber ({})", args[0]); } Ok(0) }

fn print_help_path(path:&[String]) { match path[0].as_str(){"list"=>print!("{}",help_list()),"read"=>print!("{}",help_read()),"env"=>print!("{}",help_env()),"export"=>print!("{}",help_export()),"find"=>print!("{}",help_find()),"history"=>print!("{}",help_history()),"write"=>print!("{}",help_write()),"delete"=>print!("{}",help_delete()),"import"=>print!("{}",help_import()),"exec"=>print!("{}",help_exec()),"version"=>print!("{}",help_version()),"list-services"=>print!("{}",help_list_services()),"tag"=>print!("{}",help_tag()),"completion"=>print!("{}",help_completion()),_=>print!("{}",TOP_HELP)} }
fn hf(title:&str, usage:&str, flags:&str)->String{format!("{}\n\nUsage:\n  {}\n\nFlags:\n{}\n{}",title,usage,flags,GLOBAL_FLAGS)}
fn help_version()->String{hf("print version","chamber version [flags]","  -h, --help   help for version\n")}
fn help_list_services()->String{hf("List services","chamber list-services <service> [flags]","  -h, --help      help for list-services\n  -s, --secrets   Include secret names in the list\n")}
fn help_list()->String{hf("List the secrets set for a service","chamber list <service> [flags]","  -e, --expand    Expand parameter list with values\n  -h, --help      help for list\n  -t, --time      Sort by modified time\n  -u, --user      Sort by user\n  -v, --version   Sort by version\n")}
fn help_read()->String{hf("Read a specific secret from the parameter store","chamber read <service> <key> [flags]","  -h, --help          help for read\n  -q, --quiet         Only print the secret\n  -v, --version int   The version number of the secret. Defaults to latest. (default -1)\n")}
fn help_env()->String{hf("Print the secrets from the parameter store in a format to export as environment variables","chamber env <service> [flags]","  -p, --preserve-case    preserve variable name case\n  -e, --escape-strings   escape special characters in values\n  -h, --help             help for env\n")}
fn help_export()->String{hf("Exports parameters in the specified format","chamber export <service...> [flags]","  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default \"json\")\n  -o, --output-file string   Output file (default is standard output)\n  -h, --help                 help for export\n")}
fn help_find()->String{hf("Find the given secret across all services","chamber find <secret name> [flags]","  -v, --by-value   Find parameters by value\n  -h, --help       help for find\n")}
fn help_history()->String{hf("View the history of a secret","chamber history <service> <key> [flags]","  -h, --help   help for history\n")}
fn help_write()->String{hf("write a secret","chamber write <service> <key> [--] <value|-> [flags]","  -h, --help                  help for write\n  -s, --singleline            Insert single line parameter (end with \\n)\n      --skip-unchanged        Skip writing secret if value is unchanged\n  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])\n")}
fn help_delete()->String{hf("Delete a secret, including all versions","chamber delete <service> <key> [flags]","      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.\n  -h, --help        help for delete\n")}
fn help_import()->String{hf("import secrets from json or yaml","chamber import <service> <file|-> [flags]","  -h, --help                           help for import\n      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.\n")}
fn help_exec()->String{format!("Executes a command with secrets loaded into the environment\n\nUsage:\n  chamber exec <service...> -- <command> [<arg...>] [flags]\n\nExamples:\n\nGiven a secret store like this:\n\n\t$ echo '{{\"db_username\": \"root\", \"db_password\": \"hunter22\"}}' | chamber import - \n\n--strict will fail with unfilled env vars\n\n\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme EXTRA=chamberme chamber exec --strict service exec -- env\n\tchamber: extra unfilled env var EXTRA\n\texit 1\n\n--pristine takes effect after checking for --strict values\n\n\t$ HOME=/tmp DB_USERNAME=chamberme DB_PASSWORD=chamberme chamber exec --strict --pristine service exec -- env\n\tDB_USERNAME=root\n\tDB_PASSWORD=hunter22\n\n\nFlags:\n  -h, --help                  help for exec\n      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables\n      --strict                enable strict mode:\n                              only inject secrets for which there is a corresponding env var with value\n                              <strict-value>, and fail if there are any env vars with that value missing\n                              from secrets\n      --strict-value string   value to expect in --strict mode (default \"chamberme\")\n\n{}",GLOBAL_FLAGS)}
fn help_tag()->String{format!("work with tags on secrets\n\nUsage:\n  chamber tag [command]\n\nAvailable Commands:\n  delete      Delete tags for a specific secret\n  read        Read tags for a specific secret\n  write       Write tags for a specific secret\n\nFlags:\n  -h, --help   help for tag\n\n{}\nUse \"chamber tag [command] --help\" for more information about a command.\n",GLOBAL_FLAGS)}
fn help_tag_read()->String{hf("Read tags for a specific secret","chamber tag read <service> <key> [flags]","  -h, --help   help for read\n")}
fn help_tag_write()->String{hf("Write tags for a specific secret","chamber tag write <service> <key> <tag>... [flags]","      --delete-other-tags   Delete tags not specified in the command\n  -h, --help                help for write\n")}
fn help_tag_delete()->String{hf("Delete tags for a specific secret","chamber tag delete <service> <key> <tag key>... [flags]","  -h, --help   help for delete\n")}
fn help_completion()->String{format!("Generate the autocompletion script for chamber for the specified shell.\nSee each sub-command's help for details on how to use the generated script.\n\nUsage:\n  chamber completion [command]\n\nAvailable Commands:\n  bash        Generate the autocompletion script for bash\n  fish        Generate the autocompletion script for fish\n  powershell  Generate the autocompletion script for powershell\n  zsh         Generate the autocompletion script for zsh\n\nFlags:\n  -h, --help   help for completion\n\n{}\nUse \"chamber completion [command] --help\" for more information about a command.\n",GLOBAL_FLAGS)}
fn help_completion_bash()->String{hf("Generate the autocompletion script for the bash shell.\n\nThis script depends on the 'bash-completion' package.","chamber completion bash","  -h, --help              help for bash\n      --no-descriptions   disable completion descriptions\n")}
fn help_completion_zsh()->String{hf("Generate the autocompletion script for the zsh shell.","chamber completion zsh [flags]","  -h, --help              help for zsh\n      --no-descriptions   disable completion descriptions\n")}

#[allow(dead_code)]
fn _parse_tags(_s: &str) -> BTreeMap<String,String> { BTreeMap::new() }
