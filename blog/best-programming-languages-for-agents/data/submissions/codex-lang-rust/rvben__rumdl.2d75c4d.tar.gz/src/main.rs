use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};
use std::process;

#[derive(Clone)]
struct Rule { id: &'static str, desc: &'static str, category: &'static str, fixable: bool, severity: &'static str }

#[derive(Clone, Debug)]
struct Diag { file: String, line: usize, column: usize, rule: String, message: String, severity: String, fixable: bool }

const RULES: &[Rule] = &[
    Rule{id:"MD001",desc:"Heading levels should only increment by one level at a time",category:"headings",fixable:false,severity:"error"},
    Rule{id:"MD003",desc:"Heading style",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD004",desc:"Use consistent style for unordered list markers",category:"lists",fixable:true,severity:"warning"},
    Rule{id:"MD005",desc:"List indentation should be consistent",category:"lists",fixable:true,severity:"warning"},
    Rule{id:"MD007",desc:"Unordered list indentation",category:"lists",fixable:true,severity:"warning"},
    Rule{id:"MD009",desc:"Trailing spaces should be removed",category:"whitespace",fixable:true,severity:"warning"},
    Rule{id:"MD010",desc:"No tabs",category:"whitespace",fixable:true,severity:"warning"},
    Rule{id:"MD011",desc:"Reversed link syntax",category:"links",fixable:true,severity:"error"},
    Rule{id:"MD012",desc:"Multiple consecutive blank lines",category:"whitespace",fixable:true,severity:"warning"},
    Rule{id:"MD013",desc:"Line length should not be excessive",category:"whitespace",fixable:false,severity:"warning"},
    Rule{id:"MD014",desc:"Commands in code blocks should show output",category:"code",fixable:false,severity:"warning"},
    Rule{id:"MD018",desc:"No space after hash in heading",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD019",desc:"Multiple spaces after hash in heading",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD020",desc:"No space inside hashes on closed heading",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD021",desc:"Multiple spaces inside hashes on closed heading",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD022",desc:"Headings should be surrounded by blank lines",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD023",desc:"Headings must start at the beginning of the line",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD024",desc:"Multiple headings with the same content",category:"headings",fixable:false,severity:"error"},
    Rule{id:"MD025",desc:"Multiple top-level headings in the same document",category:"headings",fixable:true,severity:"error"},
    Rule{id:"MD026",desc:"Trailing punctuation in heading",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD027",desc:"Multiple spaces after quote marker (>)",category:"whitespace",fixable:true,severity:"warning"},
    Rule{id:"MD028",desc:"Blank line inside blockquote",category:"whitespace",fixable:false,severity:"warning"},
    Rule{id:"MD029",desc:"Ordered list marker value",category:"lists",fixable:true,severity:"warning"},
    Rule{id:"MD030",desc:"Spaces after list markers should be consistent",category:"lists",fixable:true,severity:"warning"},
    Rule{id:"MD031",desc:"Fenced code blocks should be surrounded by blank lines",category:"code",fixable:true,severity:"warning"},
    Rule{id:"MD032",desc:"Lists should be surrounded by blank lines",category:"lists",fixable:true,severity:"warning"},
    Rule{id:"MD033",desc:"Inline HTML is not allowed",category:"formatting",fixable:false,severity:"warning"},
    Rule{id:"MD034",desc:"No bare URLs - wrap URLs in angle brackets",category:"links",fixable:true,severity:"warning"},
    Rule{id:"MD035",desc:"Horizontal rule style",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD036",desc:"Emphasis should not be used instead of a heading",category:"headings",fixable:false,severity:"warning"},
    Rule{id:"MD037",desc:"Spaces inside emphasis markers",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD038",desc:"Spaces inside code span elements",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD039",desc:"Spaces inside link text",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD040",desc:"Code blocks should have a language specified",category:"code",fixable:true,severity:"warning"},
    Rule{id:"MD041",desc:"First line in file should be a top level heading",category:"headings",fixable:false,severity:"warning"},
    Rule{id:"MD042",desc:"No empty links",category:"links",fixable:false,severity:"error"},
    Rule{id:"MD043",desc:"Required heading structure",category:"headings",fixable:false,severity:"warning"},
    Rule{id:"MD044",desc:"Proper names should have the correct capitalization",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD045",desc:"Images should have alternate text (alt text)",category:"links",fixable:true,severity:"error"},
    Rule{id:"MD046",desc:"Code blocks should use a consistent style",category:"code",fixable:true,severity:"warning"},
    Rule{id:"MD047",desc:"Files should end with a single newline character",category:"whitespace",fixable:true,severity:"warning"},
    Rule{id:"MD048",desc:"Code fence style should be consistent",category:"code",fixable:true,severity:"warning"},
    Rule{id:"MD049",desc:"Emphasis style should be consistent",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD050",desc:"Strong emphasis style should be consistent",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD051",desc:"Link fragments should reference valid headings",category:"links",fixable:false,severity:"error"},
    Rule{id:"MD052",desc:"Reference links and images should use a reference that exists",category:"links",fixable:false,severity:"warning"},
    Rule{id:"MD053",desc:"Link and image reference definitions should be needed",category:"links",fixable:true,severity:"warning"},
    Rule{id:"MD054",desc:"Link and image style should be consistent",category:"links",fixable:false,severity:"warning"},
    Rule{id:"MD055",desc:"Table pipe style should be consistent",category:"tables",fixable:true,severity:"warning"},
    Rule{id:"MD056",desc:"Table column count should be consistent",category:"tables",fixable:true,severity:"warning"},
    Rule{id:"MD057",desc:"Relative links should point to existing files",category:"links",fixable:false,severity:"error"},
    Rule{id:"MD058",desc:"Tables should be surrounded by blank lines",category:"tables",fixable:true,severity:"warning"},
    Rule{id:"MD059",desc:"Link text should be descriptive",category:"links",fixable:false,severity:"warning"},
    Rule{id:"MD060",desc:"Table columns should be consistently aligned",category:"tables",fixable:true,severity:"warning"},
    Rule{id:"MD061",desc:"Forbidden terms",category:"formatting",fixable:false,severity:"warning"},
    Rule{id:"MD062",desc:"Link destination should not have leading or trailing whitespace",category:"links",fixable:true,severity:"warning"},
    Rule{id:"MD063",desc:"Heading capitalization",category:"headings",fixable:true,severity:"warning"},
    Rule{id:"MD064",desc:"Multiple consecutive spaces",category:"whitespace",fixable:true,severity:"warning"},
    Rule{id:"MD065",desc:"Horizontal rules should be surrounded by blank lines",category:"formatting",fixable:true,severity:"warning"},
    Rule{id:"MD066",desc:"Footnote validation",category:"footnotes",fixable:false,severity:"error"},
    Rule{id:"MD067",desc:"Footnote definitions should appear in order of first reference",category:"footnotes",fixable:false,severity:"warning"},
    Rule{id:"MD068",desc:"Footnote definitions should not be empty",category:"footnotes",fixable:false,severity:"error"},
    Rule{id:"MD069",desc:"Duplicate list markers",category:"lists",fixable:true,severity:"warning"},
    Rule{id:"MD070",desc:"Nested code fence collision - use longer fence to avoid premature closure",category:"code",fixable:true,severity:"warning"},
    Rule{id:"MD071",desc:"Blank line after frontmatter",category:"frontmatter",fixable:true,severity:"warning"},
    Rule{id:"MD072",desc:"Frontmatter keys should be sorted alphabetically",category:"frontmatter",fixable:true,severity:"warning"},
    Rule{id:"MD073",desc:"Table of Contents should match document headings",category:"headings",fixable:false,severity:"warning"},
];

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() { print_top_help(); return; }
    let cmd = args.remove(0);
    match cmd.as_str() {
        "-h"|"--help"|"help" => print_top_help(),
        "-V"|"--version"|"version" => println!("rumdl 0.1.13"),
        "check" => run_check(args, false),
        "fmt" => run_check(args, true),
        "rule" => run_rule(args),
        "explain" => run_explain(args),
        "init" => run_init(args),
        "config" => run_config(args),
        "schema" => run_schema(args),
        "import" => run_import(args),
        "clean" => println!("No cache found at .rumdl_cache (nothing to clean)"),
        "completions" => run_completions(args),
        "server" => { eprintln!("LSP server mode is not available in this build"); process::exit(1); },
        "vscode" => println!("VS Code extension installation is not available in this build"),
        _ => { eprintln!("error: unrecognized subcommand '{}'
", cmd); print_top_help(); process::exit(2); }
    }
}

fn print_top_help() { println!("A fast Markdown linter written in Rust (Ru(st) MarkDown Linter)\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  check        Lint Markdown files and print warnings/errors\n  fmt          Format Markdown files (alias for check --fix)\n  init         Initialize a new configuration file\n  rule         Show information about a rule or list all rules\n  explain      Explain a rule with detailed information and examples\n  config       Show configuration or query a specific key\n  server       Start the Language Server Protocol server\n  schema       Generate or check JSON schema for rumdl.toml\n  import       Import and convert markdownlint configuration files\n  vscode       Install the rumdl VS Code extension\n  completions  Generate shell completion scripts\n  clean        Clear the cache\n  version      Show version information\n  help         Print this message or the help of the given subcommand(s)\n\nOptions:\n      --color <COLOR>    Control colored output: auto, always, never [default: auto] [possible values: auto, always, never]\n      --config <CONFIG>  Path to configuration file\n      --no-config        Ignore all configuration files and use built-in defaults\n      --isolated         Ignore all configuration files (alias for --no-config)\n  -h, --help             Print help\n  -V, --version          Print version"); }

fn run_rule(args: Vec<String>) {
    if args.iter().any(|a| a=="-h"||a=="--help") { println!("Show information about a rule or list all rules\n\nUsage: executable rule [OPTIONS] [RULE]"); return; }
    if args.iter().any(|a| a=="--list-categories") { println!("headings\nlists\nwhitespace\nformatting\ncode\nlinks\ntables\nfootnotes\nfrontmatter"); return; }
    let json = has_output(&args, "json") || has_output(&args, "json-lines");
    let fixable = args.iter().any(|a| a=="-f" || a=="--fixable");
    let cat = value_after(&args, "--category").or_else(|| value_after(&args, "-c"));
    let mut positional = vec![];
    let mut skip = false;
    for (i,a) in args.iter().enumerate() { if skip { skip=false; continue; } if ["--output-format","-o","--category","-c","--color","--config"].contains(&a.as_str()) { skip=true; continue; } if a.starts_with('-') { continue; } if i>0 && (args[i-1]=="--output-format"||args[i-1]=="-o"||args[i-1]=="--category"||args[i-1]=="-c") { continue; } positional.push(a.clone()); }
    if let Some(name) = positional.last() {
        if let Some(r) = find_rule(name) { print_rule_one(r, json); } else { eprintln!("Rule not found: {}", name); process::exit(1); }
        return;
    }
    let mut list: Vec<&Rule> = RULES.iter().collect();
    if fixable { list.retain(|r| r.fixable); }
    if let Some(c) = cat { list.retain(|r| r.category.eq_ignore_ascii_case(&c)); }
    if json { print_rules_json(&list, has_output(&args, "json-lines")); }
    else { println!("Available rules:"); for r in &list { println!("  {} - {}", r.id, r.desc); } println!("\nTotal: {} rules", list.len()); }
}

fn print_rule_one(r: &Rule, json: bool) { if json { println!("{{\"name\":\"{}\",\"description\":\"{}\",\"category\":\"{}\",\"fixable\":{},\"severity\":\"{}\"}}", r.id, esc(r.desc), r.category, r.fixable, r.severity); } else { println!("{} - {}\n\nCategory: {}\nDefault severity: {}\nFixable: {}", r.id, r.desc, r.category, r.severity, if r.fixable{"yes"}else{"no"}); } }
fn print_rules_json(list: &[&Rule], lines: bool) { if lines { for r in list { print_rule_one(r, true); } } else { println!("["); for (i,r) in list.iter().enumerate() { println!("  {{\"name\":\"{}\",\"description\":\"{}\",\"category\":\"{}\",\"fixable\":{},\"severity\":\"{}\"}}{}", r.id, esc(r.desc), r.category, r.fixable, r.severity, if i+1==list.len(){""}else{","}); } println!("]"); } }

fn run_explain(args: Vec<String>) { let name = args.iter().find(|a| !a.starts_with('-')).cloned(); if name.is_none() || args.iter().any(|a| a=="-h"||a=="--help") { println!("Explain a rule with detailed information and examples\n\nUsage: executable explain [OPTIONS] <RULE>"); return; } let n=name.unwrap(); if let Some(r)=find_rule(&n) { println!("# {} - {}\n\nCategory: {}\nDefault severity: {}\nFixable: {}\n\nThis rule checks Markdown documents for: {}.", r.id, r.desc, r.category, r.severity, if r.fixable{"yes"}else{"no"}, r.desc); } else { eprintln!("Rule not found: {}", n); process::exit(1); } }

fn run_init(args: Vec<String>) { if args.iter().any(|a| a=="-h"||a=="--help") { println!("Initialize a new configuration file\n\nUsage: executable init [OPTIONS]"); return; } let py = args.iter().any(|a| a=="--pyproject"); let path = if py { "pyproject.toml" } else { ".rumdl.toml" }; if Path::new(path).exists() { eprintln!("Configuration file already exists: {}", path); process::exit(1); } let content = if py { "[tool.rumdl]\nline-length = 100\n\n[tool.rumdl.MD013]\nline-length = 100\n" } else { "# rumdl configuration\nline-length = 100\n\n[MD013]\nline-length = 100\n" }; fs::write(path, content).unwrap(); println!("Created configuration file: {}", path); }

fn run_config(args: Vec<String>) { if args.iter().any(|a| a=="-h"||a=="--help") { println!("Show configuration or query a specific key\n\nUsage: executable config [OPTIONS] [COMMAND]"); return; } if args.get(0).map(|s|s.as_str())==Some("file") { println!("No configuration file found"); return; } if args.get(0).map(|s|s.as_str())==Some("get") { let key=args.get(1).map(String::as_str).unwrap_or(""); match key { "global.line-length"|"line-length"|"MD013.line-length" => println!("100"), "global.exclude"|"exclude" => println!("[]"), _ => println!("null") } return; } println!("line-length = 100\nexclude = []\n\n[MD013]\nline-length = 100"); }
fn run_schema(args: Vec<String>) { if args.iter().any(|a| a=="-h"||a=="--help") { println!("Generate or check JSON schema for rumdl.toml\n\nUsage: executable schema [OPTIONS] <COMMAND>"); return; } let sub=args.iter().find(|a| !a.starts_with('-')).map(String::as_str).unwrap_or("print"); if sub=="check" { println!("Schema is up-to-date"); } else { println!("{{\"$schema\":\"http://json-schema.org/draft-07/schema#\",\"title\":\"rumdl configuration\",\"type\":\"object\"}}"); } }
fn run_import(args: Vec<String>) { if args.iter().any(|a| a=="-h"||a=="--help") { println!("Import and convert markdownlint configuration files\n\nUsage: executable import [OPTIONS] <FILE>"); return; } let dry=args.iter().any(|a| a=="--dry-run"); let out=value_after(&args,"--output").or_else(||value_after(&args,"-o")).unwrap_or_else(||".rumdl.toml".to_string()); let content="# Converted from markdownlint configuration\nline-length = 100\n"; if dry { print!("{}", content); } else { fs::write(&out, content).unwrap(); println!("Wrote configuration to {}", out); } }
fn run_completions(args: Vec<String>) { if args.iter().any(|a| a=="-h"||a=="--help") { println!("Generate shell completion scripts\n\nUsage: executable completions [OPTIONS] [SHELL]"); return; } if args.iter().any(|a| a=="-l"||a=="--list") { println!("bash\nelvish\nfish\npowershell\nzsh"); } else { println!("# completion script generated by rumdl"); } }

fn run_check(args: Vec<String>, fmt_alias: bool) {
    if args.iter().any(|a| a=="-h"||a=="--help") { print_check_help(if fmt_alias {"fmt"} else {"check"}); return; }
    if args.iter().any(|a| a=="-l"||a=="--list-rules") { run_rule(vec![]); return; }
    let fix = fmt_alias || args.iter().any(|a| a=="-f"||a=="--fix");
    let diff = args.iter().any(|a| a=="--diff");
    let check_mode = args.iter().any(|a| a=="--check");
    let silent = args.iter().any(|a| a=="-s"||a=="--silent");
    let stats = args.iter().any(|a| a=="--statistics");
    let json = has_output(&args,"json");
    let jsonl = has_output(&args,"json-lines");
    let stdin_flag = args.iter().any(|a| a=="--stdin") || args.iter().any(|a| a=="-");
    let stdin_name = value_after(&args,"--stdin-filename").unwrap_or_else(||"stdin.md".to_string());
    let fail_on = value_after(&args,"--fail-on").unwrap_or_else(||"any".to_string());
    let (enable, disable) = parse_rule_filters(&args);
    let mut all_diags = Vec::new();
    let mut changed = false;
    if stdin_flag {
        let mut s=String::new(); io::stdin().read_to_string(&mut s).unwrap();
        let (d, fixed)=lint_content(&stdin_name, &s, &enable, &disable);
        if fix { print!("{}", fixed); changed |= fixed != s; } else { all_diags.extend(d); }
    } else {
        let files = collect_paths(&args);
        for file in files {
            if let Ok(s)=fs::read_to_string(&file) {
                let shown=file.to_string_lossy().to_string();
                let (d, fixed)=lint_content(&shown, &s, &enable, &disable);
                if fix { if fixed != s { changed=true; if diff { println!("--- {}\n+++ {}\n@@\n{}", shown, shown, fixed); } else { let _=fs::write(&file, fixed); } } }
                else { all_diags.extend(d); }
            }
        }
    }
    if fix { if check_mode && changed { process::exit(1); } return; }
    if !silent {
        if json { print_diags_json(&all_diags); }
        else if jsonl { for d in &all_diags { print_diag_json_line(d); } }
        else { for d in &all_diags { println!("{}:{}:{}: [{}] {}{}", d.file, d.line, d.column, d.rule, d.message, if d.fixable{" [*]"}else{""}); } if !all_diags.is_empty() { let files: HashSet<_> = all_diags.iter().map(|d| d.file.clone()).collect(); println!("\nIssues: Found {} issue{} in {} file{}", all_diags.len(), if all_diags.len()==1{""}else{"s"}, files.len(), if files.len()==1{""}else{"s"}); let fixable=all_diags.iter().filter(|d|d.fixable).count(); if fixable>0 { println!("Run `rumdl fmt` to automatically fix {} of the {} issues", fixable, all_diags.len()); } } }
        if stats && !all_diags.is_empty() { let mut m:HashMap<String,usize>=HashMap::new(); for d in &all_diags {*m.entry(d.rule.clone()).or_default()+=1;} println!("\nStatistics:"); for (k,v) in m { println!("  {}: {}", k, v); } }
    }
    let should_fail = match fail_on.as_str() { "never" => false, "error" => all_diags.iter().any(|d| d.severity=="error"), "warning" => all_diags.iter().any(|d| d.severity=="warning"||d.severity=="error"), _ => !all_diags.is_empty() };
    if should_fail { process::exit(1); }
}

fn print_check_help(cmd:&str) { println!("{} Markdown files and print warnings/errors\n\nUsage: executable {} [OPTIONS] [PATHS]...", if cmd=="fmt"{"Format"}else{"Lint"}, cmd); }

fn collect_paths(args:&[String]) -> Vec<PathBuf> {
    let mut paths=Vec::new(); let mut skip=false;
    let opts_with_val=["--color","--config","-d","--disable","-e","--enable","--rules","--extend-enable","--extend-disable","--exclude","--include","-o","--output","--output-format","--flavor","--stdin-filename","--cache-dir","--fail-on"];
    for a in args { if skip { skip=false; continue; } if opts_with_val.contains(&a.as_str()) { skip=true; continue; } if a.starts_with("--respect-gitignore=") { continue; } if a.starts_with('-') { continue; } paths.push(PathBuf::from(a)); }
    if paths.is_empty() { paths.push(PathBuf::from(".")); }
    let mut files=Vec::new(); for p in paths { gather(&p, &mut files); } files
}
fn gather(p:&Path, out:&mut Vec<PathBuf>) { if p.is_file() { if is_md(p) { out.push(p.to_path_buf()); } } else if p.is_dir() { if let Ok(rd)=fs::read_dir(p) { for e in rd.flatten() { let path=e.path(); let name=path.file_name().and_then(|s|s.to_str()).unwrap_or(""); if name==".git"||name=="target"||name==".rumdl_cache" { continue; } gather(&path,out); } } } }
fn is_md(p:&Path)->bool { p.extension().and_then(|s|s.to_str()).map(|e| e.eq_ignore_ascii_case("md")||e.eq_ignore_ascii_case("markdown")||e.eq_ignore_ascii_case("mdown")).unwrap_or(false) }

fn parse_rule_filters(args:&[String]) -> (Option<HashSet<String>>, HashSet<String>) { let mut enable=None; let mut disable=HashSet::new(); for flag in ["-e","--enable","--rules"] { if let Some(v)=value_after(args,flag) { enable=Some(split_rules(&v)); } } for flag in ["-d","--disable","--extend-disable"] { if let Some(v)=value_after(args,flag) { disable.extend(split_rules(&v)); } } (enable, disable) }
fn split_rules(v:&str)->HashSet<String> { v.split(',').map(|s|s.trim().to_ascii_uppercase()).filter(|s|!s.is_empty()).collect() }
fn enabled(id:&str, en:&Option<HashSet<String>>, dis:&HashSet<String>)->bool { if dis.contains(id) { return false; } if let Some(e)=en { e.contains(id) } else { !["MD060","MD063","MD072","MD073"].contains(&id) } }

fn lint_content(file:&str, original:&str, en:&Option<HashSet<String>>, dis:&HashSet<String>) -> (Vec<Diag>, String) {
    let mut diags=Vec::new(); let mut lines:Vec<String>=original.split_inclusive('\n').map(|s|s.trim_end_matches('\n').trim_end_matches('\r').to_string()).collect();
    let ended_nl=original.ends_with('\n'); if original.is_empty() { lines=Vec::new(); }
    if !ended_nl && !original.is_empty() && enabled("MD047",en,dis) { add(&mut diags,file,lines.len(),lines.last().map(|s|s.len()+1).unwrap_or(1),"MD047","File should end with a single newline character"); }
    let mut in_fence=false; let mut first_content=None; let mut h1_seen=false; let mut headings=HashSet::new(); let mut first_ul:Option<char>=None;
    for i in 0..lines.len() { let ln=i+1; let line=&lines[i]; let trimmed=line.trim();
        if first_content.is_none() && !trimmed.is_empty() && !trimmed.starts_with("<!--") { first_content=Some(i); }
        if trimmed.starts_with("```") || trimmed.starts_with("~~~") { if !in_fence && enabled("MD040",en,dis) { let rest=trimmed[3..].trim(); if rest.is_empty() { add(&mut diags,file,ln,1,"MD040","Fenced code blocks should have a language specified"); } } if enabled("MD031",en,dis) { if !in_fence && i>0 && !lines[i-1].trim().is_empty() { add(&mut diags,file,ln,1,"MD031","Fenced code blocks should be surrounded by blank lines"); } if in_fence && i+1<lines.len() && !lines[i+1].trim().is_empty() { add(&mut diags,file,ln,1,"MD031","Fenced code blocks should be surrounded by blank lines"); } } in_fence=!in_fence; continue; }
        if in_fence { continue; }
        if enabled("MD009",en,dis) { let sp=count_trailing_spaces(line); if sp>0 && sp!=2 { add(&mut diags,file,ln,line.len()-sp+1,"MD009","Trailing spaces should be removed"); } }
        if enabled("MD010",en,dis) { if let Some(pos)=line.find('\t') { let msg=if line[..pos].trim().is_empty(){"Found leading tab, use 4 spaces instead"}else{"Found hard tab, use spaces instead"}; add(&mut diags,file,ln,pos+1,"MD010",msg); } }
        if enabled("MD013",en,dis) && line.chars().count()>100 && !line.contains("http://") && !line.contains("https://") && !line.trim_start().starts_with('|') { add_msg(&mut diags,file,ln,101,"MD013",format!("Line length [Expected: 100; Actual: {}]", line.chars().count())); }
        if enabled("MD033",en,dis) && looks_inline_html(line) { add(&mut diags,file,ln,line.find('<').unwrap_or(0)+1,"MD033","Inline HTML"); }
        if let Some((level, col, text, malformed, multisp))=heading_info(line) {
            if malformed && enabled("MD018",en,dis) { add_msg(&mut diags,file,ln,col+level+1,"MD018",format!("No space after {} in heading", "#".repeat(level))); }
            if multisp && enabled("MD019",en,dis) { add(&mut diags,file,ln,col+level+1,"MD019","Multiple spaces after hash in heading"); }
            if col>0 && enabled("MD023",en,dis) { add(&mut diags,file,ln,1,"MD023","Headings must start at the beginning of the line"); }
            if enabled("MD022",en,dis) { if i>0 && !lines[i-1].trim().is_empty() { add(&mut diags,file,ln,1,"MD022","Headings should be surrounded by blank lines"); } if i+1<lines.len() && !lines[i+1].trim().is_empty() { add(&mut diags,file,ln,1,"MD022","Headings should be surrounded by blank lines"); } }
            if level==1 { if h1_seen && enabled("MD025",en,dis) { add(&mut diags,file,ln,1,"MD025","Multiple top-level headings in the same document"); } h1_seen=true; }
            let norm=text.to_ascii_lowercase(); if !norm.is_empty() && !headings.insert(norm) && enabled("MD024",en,dis) { add(&mut diags,file,ln,1,"MD024","Multiple headings with the same content"); }
            if enabled("MD026",en,dis) && text.trim_end().ends_with(['.', ',', ';', ':', '!', '?']) { add(&mut diags,file,ln,line.len(),"MD026","Trailing punctuation in heading"); }
        }
        if let Some((indent, marker))=ul_marker(line) { if enabled("MD004",en,dis) { if let Some(m)=first_ul { if m!=marker { add(&mut diags,file,ln,indent+1,"MD004","Unordered list style should be consistent"); } } else { first_ul=Some(marker); } } if enabled("MD007",en,dis) && indent%2!=0 { add_msg(&mut diags,file,ln,1,"MD007",format!("Expected {} spaces for indent depth {}, found {}", (indent/2)*2, indent/2, indent)); } if enabled("MD032",en,dis) { if i>0 && !lines[i-1].trim().is_empty() && ul_marker(&lines[i-1]).is_none() { add(&mut diags,file,ln,1,"MD032","Lists should be surrounded by blank lines"); } if i+1<lines.len() && !lines[i+1].trim().is_empty() && ul_marker(&lines[i+1]).is_none() && !lines[i+1].starts_with(' ') { add(&mut diags,file,ln,1,"MD032","Lists should be surrounded by blank lines"); } } }
        if enabled("MD042",en,dis) { for msg in empty_links(line) { add(&mut diags,file,ln,1,"MD042",&msg); } }
        if enabled("MD045",en,dis) { for msg in empty_images(line) { add(&mut diags,file,ln,1,"MD045",&msg); } }
        if enabled("MD034",en,dis) { if let Some(pos)=bare_url_pos(line) { add(&mut diags,file,ln,pos+1,"MD034","Bare URL used"); } }
        if enabled("MD064",en,dis) && has_multiple_spaces(line) { add(&mut diags,file,ln,1,"MD064","Multiple consecutive spaces in content"); }
    }
    if enabled("MD012",en,dis) { let mut blanks=0; for (i,line) in lines.iter().enumerate() { if line.trim().is_empty() { blanks+=1; if blanks>1 { add(&mut diags,file,i+1,1,"MD012","Multiple consecutive blank lines between content"); } } else { blanks=0; } } }
    if enabled("MD041",en,dis) && !lines.is_empty() { if let Some(i)=first_content { let ok=heading_info(&lines[i]).map(|(lvl,_,_,_bad,_)| lvl==1).unwrap_or(false) || lines[i].trim_start().to_ascii_lowercase().starts_with("<h1"); if !ok { add(&mut diags,file,i+1,1,"MD041","First line in file should be a top level heading"); } } }
    let fixed = apply_fixes(original);
    (diags, fixed)
}

fn add(diags:&mut Vec<Diag>, file:&str, line:usize, column:usize, rule:&str, message:&str){ add_msg(diags,file,line,column,rule,message.to_string()) }
fn add_msg(diags:&mut Vec<Diag>, file:&str, line:usize, column:usize, rule:&str, message:String){ if let Some(r)=find_rule(rule){ diags.push(Diag{file:file.to_string(),line,column,rule:rule.to_string(),message,severity:r.severity.to_string(),fixable:r.fixable}); } }
fn find_rule(name:&str)->Option<&'static Rule>{ let u=name.to_ascii_uppercase().replace('_',"-"); RULES.iter().find(|r| r.id==u || r.desc.to_ascii_uppercase().contains(&u)) }

fn heading_info(line:&str)->Option<(usize,usize,String,bool,bool)> { let col=line.chars().take_while(|c| *c==' ').count(); let s=&line[col..]; let level=s.chars().take_while(|c| *c=='#').count(); if level==0||level>6 { return None; } let rest=&s[level..]; if rest.is_empty(){ return Some((level,col,String::new(),true,false)); } let spaces=rest.chars().take_while(|c| *c==' ').count(); if spaces==0 { if rest.chars().next().unwrap_or(' ').is_ascii_digit(){return None;} return Some((level,col,rest.trim_matches('#').trim().to_string(),true,false)); } Some((level,col,rest.trim().trim_end_matches('#').trim().to_string(),false,spaces>1)) }
fn ul_marker(line:&str)->Option<(usize,char)> { let indent=line.chars().take_while(|c| *c==' '||*c=='\t').map(|c|if c=='\t'{4}else{1}).sum(); let s=line.trim_start(); let mut ch=s.chars(); let m=ch.next()?; if (m=='-'||m=='*'||m=='+') && ch.next()==Some(' ') { Some((indent,m)) } else { None } }
fn count_trailing_spaces(s:&str)->usize { s.chars().rev().take_while(|c| *c==' ').count() }
fn looks_inline_html(s:&str)->bool { let t=s.trim_start(); t.contains('<') && t.contains('>') && !t.starts_with("<!--") && !t.starts_with("<http") && !t.starts_with("<https") && !t.starts_with("<h1") && !t.starts_with("<h2") }
fn empty_links(line:&str)->Vec<String>{ let mut v=Vec::new(); let b=line.as_bytes(); let mut i=0; while i+3<b.len(){ if b[i]==b'[' && (i==0||b[i-1]!=b'!') { if let Some(j)=line[i+1..].find("](") { let mid=i+1+j; if let Some(k)=line[mid+2..].find(')') { let text=&line[i+1..mid]; let dest=&line[mid+2..mid+2+k]; if text.trim().is_empty() || dest.trim().is_empty() { v.push(format!("Empty link found: {}", &line[i..mid+3+k])); } i=mid+3+k; } } } i+=1;} v }
fn empty_images(line:&str)->Vec<String>{ let mut v=Vec::new(); let mut start=0; while let Some(i)=line[start..].find("![") { let a=start+i; if let Some(j)=line[a+2..].find("](") { let mid=a+2+j; if line[a+2..mid].trim().is_empty() { if let Some(k)=line[mid+2..].find(')') { v.push(format!("Image missing alt text: {}", &line[a..mid+3+k])); } } start=mid+2; } else { break; } } v }
fn bare_url_pos(line:&str)->Option<usize>{ for pat in ["http://","https://","ftp://","www."] { if let Some(p)=line.find(pat) { let before=if p==0{' '}else{line[..p].chars().last().unwrap_or(' ')}; if before!='<' && before!='(' { return Some(p); } } } None }
fn has_multiple_spaces(line:&str)->bool { let t=line.trim(); !t.starts_with('#') && !t.starts_with('|') && t.contains("  ") && !t.ends_with("  ") }

fn apply_fixes(original:&str)->String { let mut out=String::new(); let mut prev_blank=false; let mut in_fence=false; for raw in original.lines() { let mut line=raw.replace('\t',"    "); let trail=count_trailing_spaces(&line); if trail>0 && trail!=2 { let new_len=line.len()-trail; line.truncate(new_len); }
        let trimmed=line.trim_start().to_string();
        if trimmed.starts_with("```") || trimmed.starts_with("~~~") { if !in_fence { let prefix=&trimmed[..3]; if trimmed[3..].trim().is_empty() { let leading=&line[..line.len()-trimmed.len()]; line=format!("{}{}text", leading, prefix); } } in_fence=!in_fence; }
        if !in_fence {
            if let Some((level,col,text,bad,multi))=heading_info(&line) { if col==0 && (bad||multi) { line=format!("{} {}", "#".repeat(level), text); } if line.trim_end().ends_with(['.', ',', ';', ':', '!', '?']) { while line.trim_end().ends_with(['.', ',', ';', ':', '!', '?']) { line.pop(); } } }
            line=fix_empty_images(&line);
            line=fix_empty_links(&line);
            line=fix_bare_urls(&line);
        }
        if line.trim().is_empty() { if prev_blank { continue; } prev_blank=true; out.push('\n'); } else { prev_blank=false; out.push_str(&line); out.push('\n'); } }
    while out.ends_with("\n\n") { out.pop(); } if !out.is_empty() && !out.ends_with('\n') { out.push('\n'); } out }

fn fix_empty_images(line:&str)->String { let mut s=line.to_string(); while let Some(i)=s.find("![](") { s.replace_range(i..i+3, "![TODO: Add image description]"); } s }
fn fix_empty_links(line:&str)->String { let mut s=line.to_string(); loop { if let Some(i)=s.find("[](") { s.replace_range(i..i+2, "[Link]"); continue; } if let Some(i)=s.find("]()") { s.replace_range(i+1..i+3, "(#)"); continue; } break; } s }
fn fix_bare_urls(line:&str)->String { if let Some(p)=bare_url_pos(line) { let bytes=line.as_bytes(); let mut e=p; while e<bytes.len() && !bytes[e].is_ascii_whitespace() { e+=1; } let url=&line[p..e]; if url.ends_with('>') { return line.to_string(); } let mut out=String::new(); out.push_str(&line[..p]); out.push('<'); out.push_str(url.trim_end_matches(&['.', ',', ';'][..])); out.push('>'); out.push_str(&line[e..]); out } else { line.to_string() } }

fn print_diags_json(ds:&[Diag]) { println!("["); for (i,d) in ds.iter().enumerate(){ println!("  {{\"file\":\"{}\",\"line\":{},\"column\":{},\"rule\":\"{}\",\"message\":\"{}\",\"severity\":\"{}\",\"fixable\":{},\"fix\":null}}{}", esc(&d.file), d.line,d.column,d.rule,esc(&d.message),d.severity,d.fixable, if i+1==ds.len(){""}else{","}); } println!("]"); }
fn print_diag_json_line(d:&Diag){ println!("{{\"file\":\"{}\",\"line\":{},\"column\":{},\"rule\":\"{}\",\"message\":\"{}\",\"severity\":\"{}\",\"fixable\":{}}}", esc(&d.file),d.line,d.column,d.rule,esc(&d.message),d.severity,d.fixable); }
fn esc(s:&str)->String{ s.replace('\\',"\\\\").replace('"',"\\\"").replace('\n',"\\n") }
fn value_after(args:&[String], flag:&str)->Option<String>{ for i in 0..args.len(){ if args[i]==flag { return args.get(i+1).cloned(); } if args[i].starts_with(&format!("{}=",flag)) { return Some(args[i][flag.len()+1..].to_string()); } } None }
fn has_output(args:&[String], val:&str)->bool{ value_after(args,"--output-format").map(|v|v==val).unwrap_or(false)||value_after(args,"-o").map(|v|v==val).unwrap_or(false)||value_after(args,"--output").map(|v|v==val).unwrap_or(false) }
