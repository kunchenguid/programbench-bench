use std::io::{self, BufRead};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum AngleUnit {
    Degree,
    Radian,
    Gradian,
}

#[derive(Debug)]
struct Args {
    input: Option<String>,
    fix: u32,
    base: u32,
    angle_unit: AngleUnit,
}

#[derive(Clone, Debug, PartialEq)]
enum Tok {
    Num(f64),
    Ident(String),
    Plus,
    Minus,
    Star,
    Slash,
    Pow,
    LParen,
    RParen,
    Comma,
}

#[derive(Debug)]
enum CalcError {
    Parser(&'static str),
    Syntax(String),
    Math(&'static str),
    Domain(&'static str),
}

impl CalcError {
    fn print(&self) {
        match self {
            CalcError::Parser(s) => eprintln!("Parser Error: {}", s),
            CalcError::Syntax(s) => eprintln!("Syntax Error: {}", s),
            CalcError::Math(s) => eprintln!("Math Error: {}", s),
            CalcError::Domain(s) => eprintln!("Domain Error: {}", s),
        }
    }
}

struct EvalParser {
    toks: Vec<Tok>,
    pos: usize,
    prev: f64,
    angle: AngleUnit,
    implicit_after: bool,
}

impl EvalParser {
    fn new(input: &str, prev: f64, angle: AngleUnit) -> Result<Self, CalcError> {
        Ok(Self { toks: lex(input)?, pos: 0, prev, angle, implicit_after: false })
    }

    fn parse_all(&mut self) -> Result<f64, CalcError> {
        if self.toks.is_empty() {
            return Ok(0.0);
        }
        let v = self.expr()?;
        if self.pos < self.toks.len() {
            match self.peek() {
                Some(Tok::RParen) => Err(CalcError::Syntax("Mismatched parentheses!".into())),
                _ => Err(CalcError::Parser("Too many operators, too few operands")),
            }
        } else {
            Ok(v)
        }
    }

    fn peek(&self) -> Option<&Tok> { self.toks.get(self.pos) }
    fn bump(&mut self) -> Option<Tok> { let t = self.toks.get(self.pos).cloned(); if t.is_some() { self.pos += 1; } t }

    fn expr(&mut self) -> Result<f64, CalcError> {
        let mut v = self.term()?;
        loop {
            match self.peek() {
                Some(Tok::Plus) => { self.bump(); v += self.term()?; }
                Some(Tok::Minus) => { self.bump(); v -= self.term()?; }
                _ => break,
            }
        }
        Ok(v)
    }

    fn term(&mut self) -> Result<f64, CalcError> {
        let mut v = self.power()?;
        loop {
            match self.peek() {
                Some(Tok::Star) => { self.bump(); v *= self.power()?; }
                Some(Tok::Slash) => {
                    self.bump();
                    let r = self.power()?;
                    if r == 0.0 { return Err(CalcError::Math("Divide by zero error!")); }
                    v /= r;
                }
                Some(t) if self.implicit_after && starts_implicit(t) => {
                    v *= self.power()?;
                }
                _ => break,
            }
        }
        Ok(v)
    }

    fn power(&mut self) -> Result<f64, CalcError> {
        let left = self.unary()?;
        if matches!(self.peek(), Some(Tok::Pow)) {
            self.bump();
            let right = self.power()?;
            let v = left.powf(right);
            if v.is_nan() { return Err(CalcError::Domain("Out of bounds!")); }
            Ok(v)
        } else { Ok(left) }
    }

    fn unary(&mut self) -> Result<f64, CalcError> {
        match self.peek() {
            Some(Tok::Plus) => { self.bump(); self.unary() }
            Some(Tok::Minus) => { self.bump(); Ok(-self.unary()?) }
            _ => self.primary(),
        }
    }

    fn primary(&mut self) -> Result<f64, CalcError> {
        match self.bump() {
            Some(Tok::Num(n)) => {
                self.implicit_after = true;
                Ok(n)
            }
            Some(Tok::LParen) => {
                let v = self.expr()?;
                if matches!(self.peek(), Some(Tok::RParen)) { self.bump(); }
                self.implicit_after = true;
                Ok(v)
            }
            Some(Tok::Ident(s)) => self.ident(s),
            Some(Tok::RParen) => Err(CalcError::Syntax("Mismatched parentheses!".into())),
            _ => Err(CalcError::Parser("Too many operators, too few operands")),
        }
    }

    fn ident(&mut self, s: String) -> Result<f64, CalcError> {
        match s.as_str() {
            "pi" => {
                self.implicit_after = false;
                return Ok(std::f64::consts::PI);
            }
            "e" => {
                self.implicit_after = false;
                return Ok(std::f64::consts::E);
            }
            "_" => {
                self.implicit_after = false;
                return Ok(self.prev);
            }
            _ => {}
        }
        if !matches!(self.peek(), Some(Tok::LParen)) {
            if is_function_name(&s) {
                return Err(CalcError::Syntax(format!("Function '{}' expected parentheses", s)));
            }
            return Err(CalcError::Parser("Too many operators, too few operands"));
        }
        self.bump();
        let a = self.expr()?;
        let mut args = vec![a];
        while matches!(self.peek(), Some(Tok::Comma)) {
            self.bump();
            args.push(self.expr()?);
        }
        if matches!(self.peek(), Some(Tok::RParen)) { self.bump(); }
        let v = self.call(&s, &args)?;
        self.implicit_after = true;
        Ok(v)
    }

    fn trig_arg(&self, x: f64) -> f64 {
        match self.angle {
            AngleUnit::Radian => x,
            AngleUnit::Degree | AngleUnit::Gradian => x.to_radians(),
        }
    }

    fn call(&self, name: &str, args: &[f64]) -> Result<f64, CalcError> {
        let arity = match name { "log" | "nroot" => 2, _ => 1 };
        if args.len() != arity { return Err(CalcError::Parser("Too many operators, too few operands")); }
        let x = args[0];
        let y = args.get(1).copied().unwrap_or(0.0);
        let v = match name {
            "sin" => self.trig_arg(x).sin(),
            "cos" => self.trig_arg(x).cos(),
            "tan" => self.trig_arg(x).tan(),
            "csc" => 1.0 / self.trig_arg(x).sin(),
            "sec" => 1.0 / self.trig_arg(x).cos(),
            "cot" => 1.0 / self.trig_arg(x).tan(),
            "sinh" => x.sinh(),
            "cosh" => x.cosh(),
            "tanh" => x.tanh(),
            "asin" => checked_domain(x.asin())?,
            "acos" => checked_domain(x.acos())?,
            "atan" => x.atan(),
            "acsc" => checked_domain((1.0 / x).asin())?,
            "asec" => checked_domain((1.0 / x).acos())?,
            "acot" => (1.0 / x).atan(),
            "ln" => checked_domain(x.ln())?,
            "log2" => checked_domain(x.log2())?,
            "log10" => checked_domain(x.log10())?,
            "sqrt" => checked_domain(x.sqrt())?,
            "ceil" => x.ceil(),
            "floor" => x.floor(),
            "abs" => x.abs(),
            "log" => checked_domain(x.log(y))?,
            "nroot" => checked_domain(x.powf(1.0 / y))?,
            _ => return Err(CalcError::Parser("Too many operators, too few operands")),
        };
        if v.is_infinite() { Ok(v) } else { checked_domain(v) }
    }
}

fn checked_domain(v: f64) -> Result<f64, CalcError> {
    if v.is_nan() { Err(CalcError::Domain("Out of bounds!")) } else { Ok(v) }
}

fn starts_implicit(t: &Tok) -> bool {
    matches!(t, Tok::Num(_) | Tok::Ident(_) | Tok::LParen)
}

fn is_function_name(s: &str) -> bool {
    matches!(
        s,
        "sin" | "cos" | "tan" | "csc" | "sec" | "cot" | "sinh" | "cosh" | "tanh"
            | "asin" | "acos" | "atan" | "acsc" | "asec" | "acot" | "ln" | "log2"
            | "log10" | "sqrt" | "ceil" | "floor" | "abs" | "log" | "nroot"
    )
}

fn lex(input: &str) -> Result<Vec<Tok>, CalcError> {
    let chars: Vec<char> = input.chars().collect();
    let mut i = 0;
    let mut out = Vec::new();
    while i < chars.len() {
        let c = chars[i];
        if c.is_whitespace() { i += 1; continue; }
        match c {
            '0'..='9' | '.' => {
                let start = i;
                let mut dots = if c == '.' { 1 } else { 0 };
                i += 1;
                while i < chars.len() {
                    let ch = chars[i];
                    if ch.is_ascii_digit() { i += 1; }
                    else if ch == '.' && dots == 0 { dots += 1; i += 1; }
                    else { break; }
                }
                let s: String = chars[start..i].iter().collect();
                let n = s.parse::<f64>().map_err(|_| CalcError::Syntax(format!("Unexpected character '{}'", s)))?;
                out.push(Tok::Num(n));
            }
            'a'..='z' | '_' => {
                let start = i;
                i += 1;
                while i < chars.len() && (chars[i].is_ascii_lowercase() || chars[i].is_ascii_digit() || chars[i] == '_') { i += 1; }
                out.push(Tok::Ident(chars[start..i].iter().collect()));
            }
            'A'..='Z' => {
                let start = i;
                i += 1;
                while i < chars.len() && !chars[i].is_whitespace() && !"+-*/^(),".contains(chars[i]) { i += 1; }
                let s: String = chars[start..i].iter().collect();
                return Err(CalcError::Syntax(format!("Unexpected character '{}'", s)));
            }
            '+' => { out.push(Tok::Plus); i += 1; }
            '-' => { out.push(Tok::Minus); i += 1; }
            '*' => { if i + 1 < chars.len() && chars[i + 1] == '*' { out.push(Tok::Pow); i += 2; } else { out.push(Tok::Star); i += 1; } }
            '/' => { out.push(Tok::Slash); i += 1; }
            '^' => { out.push(Tok::Pow); i += 1; }
            '(' => { out.push(Tok::LParen); i += 1; }
            ')' => { out.push(Tok::RParen); i += 1; }
            ',' => { out.push(Tok::Comma); i += 1; }
            _ => return Err(CalcError::Syntax(format!("Unexpected character '{}'", c))),
        }
    }
    Ok(out)
}

fn format_value(v: f64, fix: u32, base: u32) -> String {
    if base == 10 {
        let raw = format!("{:.*}", fix as usize, v);
        return group_decimal(&raw);
    }
    if !v.is_finite() { return format!("{:.*}", fix as usize, v); }
    let neg = v < 0.0;
    let abs = v.abs();
    let int = abs.trunc() as u128;
    let frac = abs - abs.trunc();
    let mut s = int_to_base(int, base);
    if fix > 0 {
        s.push('.');
        if frac == 0.0 { s.push('0'); }
        else {
            let mut f = frac;
            for _ in 0..fix {
                f *= base as f64;
                let d = f.trunc() as u32;
                s.push(digit(d));
                f -= d as f64;
                if f.abs() < 1e-14 { break; }
            }
        }
    }
    let mut parts = s.splitn(2, '.');
    let int_part = parts.next().unwrap_or("");
    let frac_part = parts.next();
    let grouped = group_base_int(int_part);
    let s = if let Some(frac) = frac_part {
        format!("{}.{}", grouped, frac)
    } else {
        grouped
    };
    if neg { format!("-{}", s) } else { s }
}

fn group_decimal(raw: &str) -> String {
    let (sign, rest) = raw.strip_prefix('-').map_or(("", raw), |r| ("-", r));
    let mut parts = rest.splitn(2, '.');
    let int_part = parts.next().unwrap_or("");
    let frac = parts.next();
    let grouped = group_digits(int_part);
    match frac {
        Some(f) => format!("{}{}.{}", sign, grouped, f),
        None => format!("{}{}", sign, grouped),
    }
}

fn group_digits(s: &str) -> String {
    let mut groups = Vec::new();
    let mut end = s.len();
    while end > 3 {
        groups.push(&s[end - 3..end]);
        end -= 3;
    }
    groups.push(&s[..end]);
    groups.reverse();
    groups.join(",")
}

fn group_base_int(s: &str) -> String {
    let mut groups: Vec<String> = Vec::new();
    let mut end = s.len();
    while end > 3 {
        groups.push(s[end - 3..end].to_string());
        end -= 3;
    }
    groups.push(s[..end].to_string());
    groups.reverse();
    while groups.len() < 4 {
        groups.insert(0, String::new());
    }
    let mut out = String::new();
    for (i, g) in groups.iter().enumerate() {
        if i > 0 {
            out.push(',');
        }
        if i == 0 {
            if g.is_empty() { out.push(' '); } else { out.push_str(g); }
        } else if g.is_empty() {
            out.push_str("   ");
        } else {
            out.push_str(&format!("{:>3}", g));
        }
    }
    out
}

fn int_to_base(mut n: u128, base: u32) -> String {
    if n == 0 { return "0".into(); }
    let mut ds = Vec::new();
    while n > 0 {
        ds.push(digit((n % base as u128) as u32));
        n /= base as u128;
    }
    ds.iter().rev().collect()
}

fn digit(d: u32) -> char {
    match d { 0..=9 => (b'0' + d as u8) as char, _ => (b'A' + (d - 10) as u8) as char }
}

fn eval_print(input: &str, args: &Args, prev: f64) -> Result<f64, CalcError> {
    let mut p = EvalParser::new(input, prev, args.angle_unit)?;
    let v = p.parse_all()?;
    println!("{}", format_value(v, args.fix, args.base));
    Ok(v)
}

fn help() {
    println!("Calculator REPL similar to bc(1)\n\nUsage: executable [OPTIONS] [INPUT]\n\nArguments:\n  [INPUT]  Optional expression string to run eva in command mode\n\nOptions:\n  -f, --fix <FIX>                Number of decimal places in output (1 - 64) [default: 10]\n  -b, --base <RADIX>             Radix of calculation output (1 - 36) [default: 10]\n  -a, --angle_unit <angle_unit>  Angle unit [default: degree] [possible values: degree, radian, gradian]\n  -h, --help                     Print help\n  -V, --version                  Print version");
}

fn parse_value_u32(name: &str, val: Option<String>, lo: u32, hi: u32) -> Result<u32, i32> {
    let Some(s) = val else {
        eprintln!("error: a value is required for '{}' but none was supplied", name);
        return Err(2);
    };
    match s.parse::<u32>() {
        Ok(v) if v >= lo && v <= hi => Ok(v),
        Ok(v) => {
            eprintln!(
                "error: invalid value '{}' for '{}': {} is not in {}..={}\n\nFor more information, try '--help'.",
                s, name, v, lo, hi
            );
            Err(2)
        }
        Err(_) => {
            eprintln!("error: invalid value '{}' for '{}'\n\nFor more information, try '--help'.", s, name);
            Err(2)
        }
    }
}

fn parse_angle(s: String) -> Result<AngleUnit, i32> {
    match s.as_str() {
        "degree" => Ok(AngleUnit::Degree),
        "radian" => Ok(AngleUnit::Radian),
        "gradian" => Ok(AngleUnit::Gradian),
        _ => {
            eprintln!(
                "error: invalid value '{}' for '--angle_unit <angle_unit>'\n  [possible values: degree, radian, gradian]\n\nFor more information, try '--help'.",
                s
            );
            Err(2)
        }
    }
}

fn parse_args() -> Result<Args, i32> {
    let mut fix = 10;
    let mut base = 10;
    let mut angle_unit = AngleUnit::Degree;
    let mut input: Option<String> = None;
    let mut it = std::env::args().skip(1).peekable();
    let mut positional_only = false;
    while let Some(a) = it.next() {
        if !positional_only && a == "--" {
            positional_only = true;
            continue;
        }
        if !positional_only && (a == "-h" || a == "--help") {
            help();
            return Err(0);
        }
        if !positional_only && (a == "-V" || a == "--version") {
            println!("eva 0.3.1");
            return Err(0);
        }
        if !positional_only && (a == "-f" || a == "--fix") {
            fix = parse_value_u32("--fix <FIX>", it.next(), 1, 64)?;
            continue;
        }
        if !positional_only && (a == "-b" || a == "--base") {
            base = parse_value_u32("--base <RADIX>", it.next(), 1, 36)?;
            continue;
        }
        if !positional_only && (a == "-a" || a == "--angle_unit") {
            let Some(v) = it.next() else {
                eprintln!("error: a value is required for '--angle_unit <angle_unit>' but none was supplied");
                return Err(2);
            };
            angle_unit = parse_angle(v)?;
            continue;
        }
        if !positional_only && a.starts_with('-') {
            eprintln!(
                "error: unexpected argument '{}' found\n\n  tip: to pass '{}' as a value, use '-- {}'\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.",
                a, a, a
            );
            return Err(2);
        }
        if input.is_none() {
            input = Some(a);
        } else {
            eprintln!(
                "error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.",
                a
            );
            return Err(2);
        }
    }
    Ok(Args { input, fix, base, angle_unit })
}

fn main() {
    let args = match parse_args() { Ok(a) => a, Err(code) => std::process::exit(code) };
    if let Some(input) = &args.input {
        match eval_print(input, &args, 0.0) {
            Ok(_) => std::process::exit(0),
            Err(e) => { e.print(); std::process::exit(1); }
        }
    }

    println!("No previous history.");
    let stdin = io::stdin();
    let mut prev = 0.0;
    for line in stdin.lock().lines() {
        match line {
            Ok(l) => match eval_print(&l, &args, prev) {
                Ok(v) => prev = v,
                Err(e) => e.print(),
            },
            Err(_) => break,
        }
    }
}
