use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

#[derive(Clone, Copy, PartialEq, Eq)]
enum Style {
    Normal,
    Round,
    Bold,
    Double,
    Ascii,
}

impl Style {
    fn parse(s: &str) -> Result<Self, String> {
        match s {
            "normal" | "thin" | "n" | "t" => Ok(Self::Normal),
            "round" | "r" => Ok(Self::Round),
            "bold" | "b" => Ok(Self::Bold),
            "double" | "d" => Ok(Self::Double),
            "ascii" | "a" => Ok(Self::Ascii),
            _ => Err(format!(
                "Unknown characters/style '{}'. Must be one of [normal|thin|round|bold|double|ascii]",
                s
            )),
        }
    }

    fn dot(self) -> &'static str {
        match self {
            Self::Ascii => "*",
            Self::Round => "●",
            Self::Bold => "●",
            Self::Double => "●",
            Self::Normal => "●",
        }
    }

    fn merge_dot(self) -> &'static str {
        match self {
            Self::Ascii => "o",
            _ => "○",
        }
    }

    fn v(self) -> &'static str {
        match self {
            Self::Ascii => "|",
            Self::Bold => "┃",
            Self::Double => "║",
            _ => "│",
        }
    }

    fn h(self) -> &'static str {
        match self {
            Self::Ascii => "-",
            Self::Bold => "━",
            Self::Double => "═",
            _ => "─",
        }
    }

    fn left_join(self) -> &'static str {
        match self {
            Self::Ascii => "|",
            Self::Bold => "┣",
            Self::Double => "╠",
            _ => "├",
        }
    }

    fn right_top(self) -> &'static str {
        match self {
            Self::Ascii => ".",
            Self::Bold => "┓",
            Self::Double => "╗",
            _ => "┐",
        }
    }

    fn right_bottom(self) -> &'static str {
        match self {
            Self::Ascii => "'",
            Self::Bold => "┛",
            Self::Double => "╝",
            _ => "┘",
        }
    }
}

#[derive(Default)]
struct Opts {
    path: String,
    model: String,
    max_count: Option<usize>,
    color: String,
    no_color: bool,
    wrap: Vec<String>,
    format: String,
    reverse: bool,
    local: bool,
    svg: bool,
    debug: bool,
    sparse: bool,
    style: Style,
    command: Option<Subcommand>,
}

enum Subcommand {
    Help,
    Model { list: bool, model: Option<String> },
}

impl Default for Style {
    fn default() -> Self {
        Style::Normal
    }
}

#[derive(Clone, Default)]
struct Commit {
    h: String,
    short: String,
    parents: Vec<String>,
    parents_short: Vec<String>,
    refs: String,
    subject: String,
    body: String,
    raw_body: String,
    an: String,
    ae: String,
    ad: String,
    as_: String,
    ar: String,
    cn: String,
    ce: String,
    cd: String,
    cs: String,
    cr: String,
}

fn main() {
    let code = match run() {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    };
    std::process::exit(code);
}

fn run() -> Result<(), String> {
    let opts = parse_args(env::args().skip(1).collect())?;
    match &opts.command {
        Some(Subcommand::Help) => {
            print_help(false);
            return Ok(());
        }
        Some(Subcommand::Model { list, model }) => {
            return handle_model(&opts, *list, model.as_deref());
        }
        None => {}
    }

    if opts.model != "none" && opts.model != "simple" && opts.model != "git-flow" {
        return Err(format!(
            "ERROR: No branching model named '{}' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow",
            opts.model
        ));
    }

    let repo = repo_root(&opts.path)?;
    let mut commits = read_commits(&repo, &opts)?;
    if opts.reverse {
        commits.reverse();
    }
    if opts.svg {
        print_svg(&commits, &opts);
    } else {
        print_text(&commits, &opts)?;
    }
    Ok(())
}

fn parse_args(args: Vec<String>) -> Result<Opts, String> {
    let mut o = Opts {
        path: ".".to_string(),
        model: "git-flow".to_string(),
        color: "auto".to_string(),
        format: "oneline".to_string(),
        style: Style::Normal,
        ..Default::default()
    };
    let mut i = 0usize;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "help" => {
                o.command = Some(Subcommand::Help);
                i += 1;
            }
            "model" => {
                let mut list = false;
                let mut model = None;
                i += 1;
                while i < args.len() {
                    match args[i].as_str() {
                        "-l" | "--list" => list = true,
                        "-h" | "--help" => {
                            print_model_help();
                            std::process::exit(0);
                        }
                        s if s.starts_with('-') => {
                            return Err(format!("error: unexpected argument '{}' found", s));
                        }
                        s => model = Some(s.to_string()),
                    }
                    i += 1;
                }
                o.command = Some(Subcommand::Model { list, model });
            }
            "-h" => {
                print_help(false);
                std::process::exit(0);
            }
            "--help" => {
                print_help(true);
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("git-graph 0.7.0");
                std::process::exit(0);
            }
            "-p" | "--path" => {
                i += 1;
                o.path = need_arg(&args, i, a)?.to_string();
                i += 1;
            }
            "--skip-repo-owner-validation" => i += 1,
            "-m" | "--model" => {
                i += 1;
                o.model = need_arg(&args, i, a)?.to_string();
                i += 1;
            }
            "-n" | "--max-count" => {
                i += 1;
                o.max_count = Some(need_arg(&args, i, a)?.parse().map_err(|_| {
                    format!("invalid value '{}' for '{}'", args[i], a)
                })?);
                i += 1;
            }
            "--color" => {
                i += 1;
                o.color = need_arg(&args, i, a)?.to_string();
                i += 1;
            }
            "--no-color" => {
                o.no_color = true;
                i += 1;
            }
            "-w" | "--wrap" => {
                i += 1;
                while i < args.len() && !args[i].starts_with('-') {
                    o.wrap.push(args[i].clone());
                    i += 1;
                }
            }
            "-f" | "--format" => {
                i += 1;
                o.format = need_arg(&args, i, a)?.to_string();
                i += 1;
            }
            "-r" | "--reverse" => {
                o.reverse = true;
                i += 1;
            }
            "-l" | "--local" => {
                o.local = true;
                i += 1;
            }
            "--svg" => {
                o.svg = true;
                i += 1;
            }
            "-d" | "--debug" => {
                o.debug = true;
                i += 1;
            }
            "-S" | "--sparse" => {
                o.sparse = true;
                i += 1;
            }
            "-s" | "--style" => {
                i += 1;
                o.style = Style::parse(need_arg(&args, i, a)?)?;
                i += 1;
            }
            s if s.starts_with("--style=") => {
                o.style = Style::parse(&s[8..])?;
                i += 1;
            }
            s if s.starts_with("--model=") => {
                o.model = s[8..].to_string();
                i += 1;
            }
            s if s.starts_with("--format=") => {
                o.format = s[9..].to_string();
                i += 1;
            }
            s if s.starts_with("--path=") => {
                o.path = s[7..].to_string();
                i += 1;
            }
            s if s.starts_with('-') => {
                return Err(format!(
                    "error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.",
                    s
                ));
            }
            s => return Err(format!("error: unexpected argument '{}' found", s)),
        }
    }
    Ok(o)
}

fn need_arg<'a>(args: &'a [String], i: usize, opt: &str) -> Result<&'a str, String> {
    args.get(i)
        .map(|s| s.as_str())
        .ok_or_else(|| format!("error: a value is required for '{}'", opt))
}

fn print_help(long: bool) {
    println!("Structured Git graphs for your branching model.");
    println!("    https://github.com/mlange-42/git-graph\n");
    println!("EXAMPES:");
    println!("    git-graph                   -> Show graph");
    println!("    git-graph --style round     -> Show graph in a different style");
    println!("    git-graph --model <model>   -> Show graph using a certain <model>");
    println!("    git-graph model --list      -> List available branching models");
    println!("    git-graph model             -> Show repo's current branching models");
    println!("    git-graph model <model>     -> Permanently set model <model> for this repo\n");
    println!("Usage: executable [OPTIONS] [COMMAND]\n");
    println!("Commands:");
    println!("  model  Prints or permanently sets the branching model for a repository.");
    println!("  help   Print this message or the help of the given subcommand(s)\n");
    println!("Options:");
    if long {
        println!("  -p, --path <path>\n          Open repository from this path or above. Default '.'\n");
        println!("      --skip-repo-owner-validation\n          Skip owner validation for the repository.\n          This will turn off libgit2's owner validation, which may increase security risks.\n          Please do not disable this validation for repositories you do not trust.\n");
        println!("  -m, --model <model>\n          Branching model. Available presets are [simple|git-flow|none].\n          Default: git-flow. \n          Permanently set the model for a repository with\n          > git-graph model <model>\n");
        println!("  -n, --max-count <n>\n          Maximum number of commits\n");
        println!("      --color <color>\n          Specify when colors should be used. One of [auto|always|never].\n          Default: auto.\n");
        println!("      --no-color\n          Print without colors. Missing color support should be detected\n          automatically (e.g. when piping to a file).\n          Overrides option '--color'\n");
        println!("  -w, --wrap [<wrap>...]\n          Line wrapping for formatted commit text. Default: 'auto 0 8'\n");
        println!("  -f, --format <format>\n          Commit format. One of [oneline|short|medium|full|\"<string>\"].\n");
        println!("  -r, --reverse\n          Reverse the order of commits.\n");
        println!("  -l, --local\n          Show only local branches, no remotes.\n");
        println!("      --svg\n          Render graph as SVG instead of text-based.\n");
        println!("  -d, --debug\n          Additional debug output and graphics.\n");
        println!("  -S, --sparse\n          Print a less compact graph: merge lines point to target lines\n          rather than merge commits.\n");
        println!("  -s, --style <style>\n          Output style. One of [normal/thin|round|bold|double|ascii].\n");
        println!("  -h, --help\n          Print help (see a summary with '-h')\n");
        println!("  -V, --version\n          Print version");
    } else {
        println!("  -p, --path <path>                 Open repository from this path or above. Default '.'");
        println!("      --skip-repo-owner-validation  Skip owner validation for the repository.");
        println!("  -m, --model <model>               Branching model. Available presets are [simple|git-flow|none].");
        println!("  -n, --max-count <n>               Maximum number of commits");
        println!("      --color <color>               Specify when colors should be used. One of [auto|always|never].");
        println!("      --no-color                    Print without colors.");
        println!("  -w, --wrap [<wrap>...]            Line wrapping for formatted commit text. Default: 'auto 0 8'");
        println!("  -f, --format <format>             Commit format. One of [oneline|short|medium|full|\"<string>\"].");
        println!("  -r, --reverse                     Reverse the order of commits.");
        println!("  -l, --local                       Show only local branches, no remotes.");
        println!("      --svg                         Render graph as SVG instead of text-based.");
        println!("  -d, --debug                       Additional debug output and graphics.");
        println!("  -S, --sparse                      Print a less compact graph.");
        println!("  -s, --style <style>               Output style. One of [normal/thin|round|bold|double|ascii].");
        println!("  -h, --help                        Print help (see more with '--help')");
        println!("  -V, --version                     Print version");
    }
}

fn print_model_help() {
    println!("Prints or permanently sets the branching model for a repository.\n");
    println!("Usage: executable model [OPTIONS] [model]\n");
    println!("Arguments:");
    println!("  [model]  The branching model to be used. Available presets are [simple|git-flow|none].");
    println!("           When not given, prints the currently set model.\n");
    println!("Options:");
    println!("  -l, --list  List all available branching models.");
    println!("  -h, --help  Print help");
}

fn handle_model(opts: &Opts, list: bool, model: Option<&str>) -> Result<(), String> {
    if list {
        println!("none\nsimple\ngit-flow");
        return Ok(());
    }
    let repo = repo_root(&opts.path)?;
    let cfg = repo.join(".git").join("git-graph.toml");
    if let Some(m) = model {
        if m != "none" && m != "simple" && m != "git-flow" {
            return Err(format!(
                "ERROR: No branching model named '{}' found in /home/agent/.config/git-graph/models\n       Available models are: none, simple, git-flow",
                m
            ));
        }
        fs::write(cfg, format!("model = \"{}\"\n", m)).map_err(|e| e.to_string())?;
        println!("Branching model set to '{}'", m);
    } else if let Ok(s) = fs::read_to_string(cfg) {
        if let Some(m) = parse_model_file(&s) {
            println!("{}", m);
        } else {
            println!("No branching model set");
        }
    } else {
        println!("No branching model set");
    }
    Ok(())
}

fn parse_model_file(s: &str) -> Option<String> {
    for line in s.lines() {
        let t = line.trim();
        if let Some(rest) = t.strip_prefix("model") {
            let v = rest.split('=').nth(1)?.trim().trim_matches('"');
            return Some(v.to_string());
        }
    }
    None
}

fn repo_root(path: &str) -> Result<PathBuf, String> {
    let out = Command::new("git")
        .args(["-C", path, "rev-parse", "--show-toplevel"])
        .stderr(Stdio::piped())
        .output()
        .map_err(|e| e.to_string())?;
    if !out.status.success() {
        let msg = String::from_utf8_lossy(&out.stderr);
        return Err(if msg.trim().is_empty() {
            "ERROR: Could not open repository".to_string()
        } else {
            msg.trim().to_string()
        });
    }
    Ok(PathBuf::from(String::from_utf8_lossy(&out.stdout).trim()))
}

fn git_out(repo: &Path, args: &[&str]) -> Result<String, String> {
    let out = Command::new("git")
        .arg("-C")
        .arg(repo)
        .args(args)
        .output()
        .map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(String::from_utf8_lossy(&out.stderr).trim().to_string());
    }
    Ok(String::from_utf8_lossy(&out.stdout).to_string())
}

fn read_commits(repo: &Path, opts: &Opts) -> Result<Vec<Commit>, String> {
    let sep = "%x1f";
    let rec = "%x1e";
    let fmt = format!(
        "%H{sep}%h{sep}%P{sep}%p{sep}%d{sep}%s{sep}%b{sep}%B{sep}%an{sep}%ae{sep}%ad{sep}%as{sep}%ar{sep}%cn{sep}%ce{sep}%cd{sep}%cs{sep}%cr{rec}"
    );
    let mut args_owned = vec![
        "log".to_string(),
        "--all".to_string(),
        "--topo-order".to_string(),
        "--date-order".to_string(),
        "--date=default".to_string(),
        format!("--format={}", fmt),
    ];
    if let Some(n) = opts.max_count {
        args_owned.push(format!("-n{}", n));
    }
    if opts.local {
        args_owned.retain(|x| x != "--all");
        args_owned.push("--branches".to_string());
        args_owned.push("--tags".to_string());
    }
    let args_ref: Vec<&str> = args_owned.iter().map(|s| s.as_str()).collect();
    let out = git_out(repo, &args_ref)?;
    let mut commits = Vec::new();
    for r in out.split('\x1e') {
        let r = r.trim_matches('\n');
        if r.is_empty() {
            continue;
        }
        let parts: Vec<&str> = r.split('\x1f').collect();
        if parts.len() < 18 {
            continue;
        }
        commits.push(Commit {
            h: parts[0].to_string(),
            short: parts[1].to_string(),
            parents: split_words(parts[2]),
            parents_short: split_words(parts[3]),
            refs: parts[4].to_string(),
            subject: parts[5].to_string(),
            body: parts[6].trim_end_matches('\n').to_string(),
            raw_body: parts[7].trim_end_matches('\n').to_string(),
            an: parts[8].to_string(),
            ae: parts[9].to_string(),
            ad: parts[10].to_string(),
            as_: parts[11].to_string(),
            ar: parts[12].to_string(),
            cn: parts[13].to_string(),
            ce: parts[14].to_string(),
            cd: parts[15].to_string(),
            cs: parts[16].to_string(),
            cr: parts[17].to_string(),
        });
    }
    Ok(commits)
}

fn split_words(s: &str) -> Vec<String> {
    s.split_whitespace().map(|x| x.to_string()).collect()
}

fn print_text(commits: &[Commit], opts: &Opts) -> Result<(), String> {
    let prefixes = graph_prefixes(commits, opts.style);
    for (idx, c) in commits.iter().enumerate() {
        let text = format_commit(c, &opts.format);
        let mut lines = text.lines();
        if let Some(first) = lines.next() {
            println!("{}{}", prefixes.get(idx).map(String::as_str).unwrap_or(" ●  "), first);
        }
        for line in lines {
            println!("    {}", line);
        }
    }
    io::stdout().flush().map_err(|e| e.to_string())
}

fn graph_prefixes(commits: &[Commit], style: Style) -> Vec<String> {
    let all: HashSet<String> = commits.iter().map(|c| c.h.clone()).collect();
    let mut active: Vec<String> = Vec::new();
    let mut out = Vec::new();
    for c in commits {
        let pos = active.iter().position(|h| h == &c.h).unwrap_or_else(|| {
            active.insert(0, c.h.clone());
            0
        });
        let mut line = String::from(" ");
        for i in 0..active.len().max(pos + 1) {
            if i == pos {
                line.push_str(if c.parents.len() > 1 { style.merge_dot() } else { style.dot() });
            } else if active.get(i).is_some() {
                line.push_str(style.v());
            } else {
                line.push(' ');
            }
            line.push(' ');
        }
        let visible_parent_count = c.parents.iter().filter(|p| all.contains(*p)).count();
        if c.parents.len() > 1 && visible_parent_count > 1 {
            line = format!(" {}<{}{}  ", style.merge_dot(), style.right_top(), lane_tail(&active, pos, style));
        } else {
            line.push(' ');
        }
        out.push(fix_width(line));

        let mut new_active = active.clone();
        new_active.remove(pos);
        let parents: Vec<String> = c.parents.iter().filter(|p| all.contains(*p)).cloned().collect();
        for (j, p) in parents.iter().enumerate() {
            if !new_active.iter().any(|h| h == p) {
                new_active.insert(pos + j, p.clone());
            }
        }
        if c.parents.len() > 1 && parents.len() > 1 {
            let mut conn = String::from(" ");
            for i in 0..new_active.len() {
                if i == pos {
                    conn.push_str(style.left_join());
                    conn.push_str(style.h());
                } else if i == pos + parents.len() - 1 {
                    conn.push_str(style.right_bottom());
                    conn.push(' ');
                } else if i > pos && i < pos + parents.len() - 1 {
                    conn.push_str(style.h());
                    conn.push(' ');
                } else {
                    conn.push_str(style.v());
                    conn.push(' ');
                }
            }
            out.push(fix_width(conn));
        }
        active = new_active;
    }
    let mut result = Vec::new();
    let mut extra_iter = out.into_iter();
    for c in commits {
        let p = extra_iter.next().unwrap_or_else(|| " ●  ".to_string());
        result.push(p);
        if c.parents.len() > 1 {
            let _ = extra_iter.next();
        }
    }
    result
}

fn lane_tail(active: &[String], pos: usize, style: Style) -> String {
    let mut s = String::new();
    for i in (pos + 1)..active.len() {
        let _ = i;
        s.push(' ');
        s.push_str(style.v());
    }
    s
}

fn fix_width(mut s: String) -> String {
    while s.chars().count() < 4 {
        s.push(' ');
    }
    s
}

fn format_commit(c: &Commit, fmt: &str) -> String {
    match fmt {
        "oneline" | "o" => format!("{}{} {}", c.short, space_ref(&c.refs), c.subject),
        "short" | "s" => format!(
            "commit {}{}\nAuthor: {} <{}>\n\n    {}\n",
            c.h,
            space_ref(&c.refs),
            c.an,
            c.ae,
            c.subject
        ),
        "medium" | "m" => {
            let mut s = format!(
                "commit {}{}\nAuthor: {} <{}>\nDate:   {}\n\n    {}",
                c.h,
                space_ref(&c.refs),
                c.an,
                c.ae,
                c.ad,
                c.subject
            );
            if !c.body.is_empty() {
                s.push_str("\n\n");
                for l in c.body.lines() {
                    s.push_str("    ");
                    s.push_str(l);
                    s.push('\n');
                }
                s.pop();
            }
            s.push('\n');
            s
        }
        "full" | "f" => {
            let mut s = format!(
                "commit {}{}\nAuthor: {} <{}>\nCommit: {} <{}>\nDate:   {}\n\n    {}",
                c.h,
                space_ref(&c.refs),
                c.an,
                c.ae,
                c.cn,
                c.ce,
                c.ad,
                c.subject
            );
            if !c.body.is_empty() {
                s.push_str("\n\n");
                for l in c.body.lines() {
                    s.push_str("    ");
                    s.push_str(l);
                    s.push('\n');
                }
                s.pop();
            }
            s.push('\n');
            s
        }
        other => expand_custom(c, other),
    }
}

fn space_ref(r: &str) -> String {
    if r.is_empty() {
        String::new()
    } else if r.starts_with(' ') {
        r.to_string()
    } else {
        format!(" {}", r)
    }
}

fn placeholder(c: &Commit, name: &str) -> Option<String> {
    Some(match name {
        "H" => c.h.clone(),
        "h" => c.short.clone(),
        "P" => c.parents.join(" "),
        "p" => c.parents_short.join(" "),
        "d" => c.refs.clone(),
        "s" => c.subject.clone(),
        "b" => c.body.clone(),
        "B" => c.raw_body.clone(),
        "an" => c.an.clone(),
        "ae" => c.ae.clone(),
        "ad" => c.ad.clone(),
        "as" => c.as_.clone(),
        "ar" => c.ar.clone(),
        "cn" => c.cn.clone(),
        "ce" => c.ce.clone(),
        "cd" => c.cd.clone(),
        "cs" => c.cs.clone(),
        "cr" => c.cr.clone(),
        "n" => "\n".to_string(),
        _ => return None,
    })
}

fn expand_custom(c: &Commit, fmt: &str) -> String {
    let mut out = String::new();
    let chars: Vec<char> = fmt.chars().collect();
    let mut i = 0usize;
    while i < chars.len() {
        if chars[i] != '%' {
            out.push(chars[i]);
            i += 1;
            continue;
        }
        i += 1;
        if i >= chars.len() {
            out.push('%');
            break;
        }
        let modifier = if chars[i] == '+' || chars[i] == '-' || chars[i] == ' ' {
            let m = chars[i];
            i += 1;
            Some(m)
        } else {
            None
        };
        let mut candidates = Vec::new();
        if i + 1 < chars.len() {
            candidates.push(format!("{}{}", chars[i], chars[i + 1]));
        }
        candidates.push(chars[i].to_string());
        let mut matched = None;
        for cand in candidates {
            if let Some(v) = placeholder(c, &cand) {
                matched = Some((cand.len(), v));
                break;
            }
        }
        if let Some((len, val)) = matched {
            match modifier {
                Some('+') if !val.is_empty() => {
                    out.push('\n');
                    out.push_str(&val);
                }
                Some('-') if val.is_empty() => {
                    while out.ends_with('\n') {
                        out.pop();
                    }
                }
                Some(' ') if !val.is_empty() => {
                    out.push(' ');
                    out.push_str(&val);
                }
                Some('-') => out.push_str(&val),
                Some(_) => {}
                None => out.push_str(&val),
            }
            i += len;
        } else {
            out.push('%');
        }
    }
    out
}

fn print_svg(commits: &[Commit], _opts: &Opts) {
    let h = (commits.len().max(1) * 15 + 30) as i32;
    println!(
        "<svg height=\"{}\" viewBox=\"0 0 45 {}\" width=\"45\" xmlns=\"http://www.w3.org/2000/svg\">",
        h, h
    );
    for (i, c) in commits.iter().enumerate() {
        let y = 15 + (i as i32) * 15;
        if i + 1 < commits.len() {
            println!("<line stroke=\"blue\" stroke-width=\"1\" x1=\"15\" x2=\"15\" y1=\"{}\" y2=\"{}\"/>", y, y + 15);
        }
        if c.parents.len() > 1 {
            println!("<circle cx=\"15\" cy=\"{}\" fill=\"white\" r=\"4\" stroke=\"blue\" stroke-width=\"1\"/>", y);
        } else {
            println!("<circle cx=\"15\" cy=\"{}\" fill=\"blue\" r=\"4\" stroke=\"blue\" stroke-width=\"1\"/>", y);
        }
    }
    println!("</svg>");
}
