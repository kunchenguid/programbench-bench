use serde_json::Value;
use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read};

#[derive(Clone, Debug)]
struct Opts {
    input_format: Option<String>,
    guess: bool,
    ih: bool,
    inum: bool,
    id: String,
    od: String,
    oq: String,
    oh: bool,
    oaq: bool,
    crlf: bool,
    onull: String,
    out: Option<String>,
    output: String,
    query_file: Option<String>,
    table_file: Option<String>,
    analyze: Option<(String, bool)>,
    version: bool,
    help: bool,
    dblist: bool,
    sql_parts: Vec<String>,
}

#[derive(Clone, Debug)]
struct Table { headers: Vec<String>, rows: Vec<Vec<Option<String>>> }

#[derive(Clone, Debug)]
struct Query {
    selects: Vec<String>,
    table: String,
    where_clause: Option<String>,
    group_by: Vec<String>,
    order_by: Vec<(String, bool)>,
    limit: Option<usize>,
}

fn main() {
    let opts = parse_args(env::args().skip(1).collect());
    if opts.help { print_help(); return; }
    if opts.version { println!("trdsql version devel"); return; }
    if opts.dblist { return; }
    if let Some((file, only)) = &opts.analyze {
        match load_table(file, &opts) {
            Ok(t) => { println!("SELECT {} FROM `{}`{}", t.headers.join(","), file, if *only { "" } else { ";" }); return; }
            Err(e) => die(&e),
        }
    }
    let mut sql = if let Some(qf) = &opts.query_file { fs::read_to_string(qf).unwrap_or_else(|e| die_ret(&format!("{}", e))) } else { opts.sql_parts.join(" ") };
    if sql.trim().is_empty() {
        if let Some(t) = &opts.table_file { sql = format!("select * from {}", t); } else { print_help(); return; }
    }
    let q = match parse_query(&sql) { Ok(q) => q, Err(e) => die(&e) };
    let table = match load_table(&q.table, &opts) { Ok(t) => t, Err(e) => die(&e) };
    let result = execute_query(&q, table);
    let text = format_output(&result, &opts);
    if let Some(out) = &opts.out { fs::write(out, text).unwrap_or_else(|e| die(&format!("{}", e))); } else { print!("{}", text); }
}

fn die_ret(msg: &str) -> String { eprintln!("{}", msg); std::process::exit(1) }
fn die(msg: &str) -> ! { eprintln!("{}", msg); std::process::exit(1) }

fn parse_args(args: Vec<String>) -> Opts {
    let mut o = Opts { input_format: None, guess: true, ih: false, inum: false, id: ",".into(), od: ",".into(), oq: "\"".into(), oh: false, oaq: false, crlf: false, onull: "".into(), out: None, output: "csv".into(), query_file: None, table_file: None, analyze: None, version: false, help: false, dblist: false, sql_parts: vec![] };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let take = |i: &mut usize| -> String { *i += 1; if *i >= args.len() { String::new() } else { args[*i].clone() } };
        match a.as_str() {
            "-help" | "--help" | "-h" => o.help = true,
            "-version" | "--version" => o.version = true,
            "-dblist" => o.dblist = true,
            "-debug" | "-out-without-guess" | "-onowrap" => {},
            "-ih" => o.ih = true, "-inum" => o.inum = true, "-oh" => o.oh = true, "-oaq" => o.oaq = true, "-ocrlf" => o.crlf = true,
            "-icsv" => o.input_format = Some("csv".into()), "-iltsv" => o.input_format = Some("ltsv".into()), "-ijson" => o.input_format = Some("json".into()), "-iyaml" => o.input_format = Some("yaml".into()), "-itbln" => o.input_format = Some("tbln".into()), "-itext" => o.input_format = Some("text".into()), "-iwidth" => o.input_format = Some("text".into()),
            "-ig" => o.guess = take(&mut i) != "false",
            "-ocsv" => o.output = "csv".into(), "-ojson" => o.output = "json".into(), "-ojsonl" => o.output = "jsonl".into(), "-oltsv" => o.output = "ltsv".into(), "-omd" => o.output = "md".into(), "-oat" => o.output = "at".into(), "-oraw" => o.output = "raw".into(), "-otbln" => o.output = "tbln".into(), "-ovf" => o.output = "vf".into(), "-oyaml" => o.output = "yaml".into(),
            "-id" => o.id = take(&mut i), "-od" => o.od = take(&mut i), "-oq" => o.oq = take(&mut i), "-onull" => o.onull = take(&mut i),
            "-out" => o.out = Some(take(&mut i)), "-q" => o.query_file = Some(take(&mut i)), "-t" => o.table_file = Some(take(&mut i)),
            "-a" => o.analyze = Some((take(&mut i), false)), "-A" => o.analyze = Some((take(&mut i), true)),
            "-config" | "-db" | "-driver" | "-dsn" | "-ijq" | "-ilr" | "-inull" | "-ir" | "-is" | "-oz" => { let _ = take(&mut i); },
            _ if a.starts_with("-o") && a.len() > 2 => o.output = a[2..].to_string(),
            _ => o.sql_parts.push(a.clone()),
        }
        i += 1;
    }
    o
}

fn print_help() { println!("trdsql - Execute SQL queries on CSV, LTSV, JSON, YAML and TBLN.\n\nUsage\n\ttrdsql [OPTIONS] [SQL(SELECT...)]\n\nOptions:\n  -help               display usage information.\n  -version            display version information.\n  -q string           read query from the specified file.\n  -t string           read table name from the specified file.\n\nInput Formats:\n  -icsv               CSV format for input.\n  -ijson              JSON format for input.\n  -iltsv              LTSV format for input.\n\nOutput Formats:\n  -ocsv               CSV format for output.\n  -ojson              JSON format for output.\n  -ojsonl             JSON lines format for output.\n  -oltsv              LTSV format for output.\n  -omd                Markdown format for output.\n  -oat                ASCII Table format for output."); }

fn parse_query(sql: &str) -> Result<Query, String> {
    let s = sql.trim().trim_end_matches(';').trim();
    let low = s.to_lowercase();
    if !low.starts_with("select ") { return Err("only SELECT queries are supported".into()); }
    let from_pos = find_kw(&low, " from ").ok_or("missing FROM")?;
    let select_part = s[6..from_pos].trim();
    let rest = s[from_pos+6..].trim();
    let rest_low = rest.to_lowercase();
    let mut cuts: Vec<(usize,&str)> = [" where ", " group by ", " order by ", " limit "].iter().filter_map(|kw| find_kw(&rest_low, kw).map(|p| (p,*kw))).collect();
    cuts.sort_by_key(|x| x.0);
    let table_end = cuts.first().map(|x| x.0).unwrap_or(rest.len());
    let table = unquote_ident(rest[..table_end].trim()).split("::").next().unwrap_or("").to_string();
    let mut q = Query { selects: split_commas(select_part), table, where_clause: None, group_by: vec![], order_by: vec![], limit: None };
    for idx in 0..cuts.len() {
        let (pos, kw) = cuts[idx];
        let start = pos + kw.len();
        let end = cuts.get(idx+1).map(|x| x.0).unwrap_or(rest.len());
        let val = rest[start..end].trim();
        match kw.trim() {
            "where" => q.where_clause = Some(val.to_string()),
            "group by" => q.group_by = split_commas(val),
            "order by" => q.order_by = split_commas(val).into_iter().map(|v| { let l=v.to_lowercase(); if l.ends_with(" desc") {(v[..v.len()-5].trim().to_string(), false)} else if l.ends_with(" asc") {(v[..v.len()-4].trim().to_string(), true)} else {(v, true)} }).collect(),
            "limit" => q.limit = val.split_whitespace().next().and_then(|x| x.parse().ok()),
            _ => {}
        }
    }
    Ok(q)
}
fn find_kw(s: &str, kw: &str) -> Option<usize> { s.find(kw) }
fn split_commas(s: &str) -> Vec<String> {
    let mut res=vec![]; let mut cur=String::new(); let mut quote=false; let mut par=0;
    for c in s.chars() { match c { '\''|'"' => { quote=!quote; cur.push(c); }, '(' if !quote => { par+=1; cur.push(c); }, ')' if !quote => { if par>0{par-=1}; cur.push(c); }, ',' if !quote && par==0 => { res.push(cur.trim().to_string()); cur.clear(); }, _ => cur.push(c) } }
    if !cur.trim().is_empty() { res.push(cur.trim().to_string()); }
    res
}
fn unquote_ident(s: &str) -> &str { s.trim().trim_matches('`').trim_matches('"').trim_matches('\'') }

fn load_table(path: &str, opts: &Opts) -> Result<Table, String> {
    let content = if path == "-" { let mut b=String::new(); io::stdin().read_to_string(&mut b).map_err(|e|e.to_string())?; b } else { fs::read_to_string(path).map_err(|e| format!("{}", e))? };
    let fmt = opts.input_format.clone().unwrap_or_else(|| guess_format(path));
    let mut t = match fmt.as_str() { "json" => parse_json(&content), "ltsv" => parse_ltsv(&content), "tbln" => parse_tbln(&content), "text" => parse_text(&content), _ => parse_csv(&content, &opts.id, opts.ih) };
    if opts.inum { t.headers.insert(0, "rownum".into()); for (i,r) in t.rows.iter_mut().enumerate() { r.insert(0, Some((i+1).to_string())); } }
    Ok(t)
}
fn guess_format(path: &str) -> String { path.rsplit('.').next().map(|e| match e.to_lowercase().as_str() { "json"|"jsonl" => "json", "ltsv" => "ltsv", "tbln" => "tbln", "txt"|"log" => "text", _ => "csv" }).unwrap_or("csv").into() }

fn parse_csv(s: &str, delim: &str, has_header: bool) -> Table {
    let d = delim.chars().next().unwrap_or(',');
    let mut recs: Vec<Vec<Option<String>>> = s.lines().filter(|l| !l.is_empty()).map(|l| parse_csv_line(l, d).into_iter().map(Some).collect()).collect();
    let width = recs.iter().map(|r| r.len()).max().unwrap_or(0);
    let headers = if has_header && !recs.is_empty() { recs.remove(0).into_iter().enumerate().map(|(i,v)| v.unwrap_or_else(|| format!("c{}",i+1))).collect() } else { (1..=width).map(|i| format!("c{}", i)).collect() };
    Table { headers, rows: recs }
}
fn parse_csv_line(l: &str, d: char) -> Vec<String> {
    let mut v=vec![]; let mut cur=String::new(); let mut q=false; let mut chars=l.chars().peekable();
    while let Some(c)=chars.next() { if q { if c=='"' { if chars.peek()==Some(&'"') {cur.push('"'); chars.next();} else {q=false;} } else {cur.push(c);} } else if c=='"' { q=true; } else if c==d { v.push(cur.clone()); cur.clear(); } else { cur.push(c); } }
    v.push(cur); v
}
fn parse_ltsv(s: &str) -> Table {
    let mut headers=vec![]; let mut rows=vec![];
    for line in s.lines().filter(|l|!l.is_empty()) { let mut map=BTreeMap::new(); for f in line.split('\t') { if let Some((k,v))=f.split_once(':') { if !headers.contains(&k.to_string()) { headers.push(k.to_string()); } map.insert(k.to_string(), v.to_string()); } } rows.push(map); }
    let rows = rows.into_iter().map(|m| headers.iter().map(|h| m.get(h).cloned()).collect()).collect(); Table{headers,rows}
}
fn parse_json(s: &str) -> Table {
    let val: Result<Value,_> = serde_json::from_str(s);
    let mut vals=vec![];
    if let Ok(v)=val { match v { Value::Array(a)=>vals=a, Value::Object(_)=>vals.push(v), _=>{} } } else { for l in s.lines() { if let Ok(v)=serde_json::from_str::<Value>(l) { vals.push(v); } } }
    let mut headers=vec![]; let mut maps=vec![];
    for v in vals { if let Value::Object(obj)=v { let mut m=BTreeMap::new(); for (k,v) in obj { if !headers.contains(&k) { headers.push(k.clone()); } m.insert(k, json_scalar(v)); } maps.push(m); } }
    let rows=maps.into_iter().map(|m| headers.iter().map(|h| m.get(h).cloned()).collect()).collect(); Table{headers,rows}
}
fn json_scalar(v: Value) -> String { match v { Value::Null=>"".into(), Value::String(s)=>s, Value::Bool(b)=>b.to_string(), Value::Number(n)=>n.to_string(), other=>other.to_string() } }
fn parse_text(s: &str) -> Table { Table{headers:vec!["c1".into()], rows:s.lines().map(|l|vec![Some(l.to_string())]).collect()} }
fn parse_tbln(s: &str) -> Table { let lines: Vec<&str>=s.lines().filter(|l|l.trim_start().starts_with('|')).collect(); let recs: Vec<Vec<Option<String>>>=lines.iter().map(|l| l.trim().trim_matches('|').split('|').map(|x|Some(x.trim().to_string())).collect()).collect(); let width=recs.iter().map(|r|r.len()).max().unwrap_or(0); Table{headers:(1..=width).map(|i|format!("c{}",i)).collect(), rows:recs} }

fn execute_query(q: &Query, table: Table) -> Table {
    let mut rows: Vec<Vec<Option<String>>> = table.rows.into_iter().filter(|r| q.where_clause.as_ref().map(|w| eval_where(w, &table.headers, r)).unwrap_or(true)).collect();
    if !q.group_by.is_empty() || q.selects.iter().any(|s| is_agg(s)) { return aggregate(q, &table.headers, rows); }
    if !q.order_by.is_empty() { let headers=table.headers.clone(); rows.sort_by(|a,b| compare_order(&headers,a,b,&q.order_by)); }
    if let Some(n)=q.limit { rows.truncate(n); }
    project(&q.selects, &table.headers, rows)
}
fn project(sel: &[String], headers: &[String], rows: Vec<Vec<Option<String>>>) -> Table {
    if sel.len()==1 && sel[0].trim()=="*" { return Table{headers:headers.to_vec(), rows}; }
    let idxs: Vec<(String,Option<usize>)> = sel.iter().map(|s| { let name=alias_name(s); let base=expr_base(s); (name, col_index(headers,&base)) }).collect();
    let out_rows = rows.into_iter().map(|r| idxs.iter().map(|(_,i)| i.and_then(|ix| r.get(ix).cloned()).flatten()).collect()).collect();
    Table{headers:idxs.into_iter().map(|x|x.0).collect(), rows:out_rows}
}
fn alias_name(s:&str)->String{ let l=s.to_lowercase(); if let Some(p)=l.rfind(" as "){return s[p+4..].trim().to_string()} unquote_ident(s.trim()).to_string() }
fn expr_base(s:&str)->String{ let l=s.to_lowercase(); let p=l.rfind(" as ").unwrap_or(s.len()); unquote_ident(s[..p].trim()).to_string() }
fn col_index(headers:&[String], name:&str)->Option<usize>{ let n=unquote_ident(name); if let Some(rest)=n.strip_prefix('c') { if let Ok(i)=rest.parse::<usize>() { if i>0 {return Some(i-1)} } } headers.iter().position(|h| h.eq_ignore_ascii_case(n)) }

fn is_agg(s:&str)->bool{ let l=s.to_lowercase(); ["count(","sum(","avg(","min(","max("].iter().any(|p| l.contains(p)) }
fn aggregate(q:&Query, headers:&[String], rows:Vec<Vec<Option<String>>>) -> Table {
    let gidx: Vec<usize> = q.group_by.iter().filter_map(|g| col_index(headers,g)).collect();
    let mut groups:BTreeMap<Vec<String>, Vec<Vec<Option<String>>>>=BTreeMap::new();
    if gidx.is_empty(){ groups.insert(vec![], rows); } else { for r in rows { let key=gidx.iter().map(|&i| r.get(i).and_then(|v|v.clone()).unwrap_or_default()).collect(); groups.entry(key).or_default().push(r); } }
    let mut out_headers=vec![]; let mut out_rows=vec![];
    for s in &q.selects { out_headers.push(alias_name(s)); }
    for (key,rs) in groups { let mut orow=vec![]; for s in &q.selects { let sl=s.to_lowercase(); if sl.trim()=="*" { continue; } else if sl.starts_with("count(") { orow.push(Some(rs.len().to_string())); } else if sl.starts_with("sum(") || sl.starts_with("avg(") || sl.starts_with("min(") || sl.starts_with("max(") { orow.push(calc_agg(s, headers, &rs)); } else if let Some(ix)=col_index(headers,s) { orow.push(rs.first().and_then(|r|r.get(ix).cloned()).flatten()); } else if let Some(pos)=q.group_by.iter().position(|g| g.eq_ignore_ascii_case(s)) { orow.push(Some(key.get(pos).cloned().unwrap_or_default())); } else { orow.push(None); } } out_rows.push(orow); }
    if !q.order_by.is_empty(){ let h=out_headers.clone(); out_rows.sort_by(|a,b| compare_order(&h,a,b,&q.order_by)); }
    if let Some(n)=q.limit { out_rows.truncate(n); }
    Table{headers:out_headers, rows:out_rows}
}
fn calc_agg(s:&str, headers:&[String], rows:&[Vec<Option<String>>])->Option<String>{ let l=s.to_lowercase(); let name=s[s.find('(')?+1..s.rfind(')')?].trim(); let ix=col_index(headers,name)?; let vals:Vec<String>=rows.iter().filter_map(|r|r.get(ix).and_then(|v|v.clone())).collect(); if l.starts_with("min("){return vals.into_iter().min()} if l.starts_with("max("){return vals.into_iter().max()} let nums:Vec<f64>=vals.iter().filter_map(|v|v.parse().ok()).collect(); let sum:f64=nums.iter().sum(); if l.starts_with("avg("){ if nums.is_empty(){None}else{Some(trim_float(sum/nums.len() as f64))} } else { Some(trim_float(sum)) } }
fn trim_float(f:f64)->String{ let s=format!("{}",f); s }

fn eval_where(w:&str, headers:&[String], row:&[Option<String>])->bool{ for part in split_and(w) { if !eval_cond(&part,headers,row){return false;} } true }
fn split_and(s:&str)->Vec<String>{ let mut out=vec![]; let mut rest=s.trim(); loop { let low=rest.to_lowercase(); if let Some(p)=low.find(" and "){ out.push(rest[..p].trim().to_string()); rest=&rest[p+5..]; } else { out.push(rest.trim().to_string()); break; } } out }
fn eval_cond(c:&str, headers:&[String], row:&[Option<String>])->bool{ let low=c.to_lowercase(); if let Some(p)=low.find(" like "){ let left=c[..p].trim(); let pat=literal(c[p+6..].trim()); let val=value_of(left,headers,row); return like_match(&val,&pat); } for op in [">=","<=","!=","<>","=",">","<"] { if let Some(p)=c.find(op){ let val=value_of(c[..p].trim(),headers,row); let rhs=literal(c[p+op.len()..].trim()); return cmp_vals(&val,&rhs,op); } } false }
fn value_of(e:&str, headers:&[String], row:&[Option<String>])->String{ if let Some(i)=col_index(headers,e){ row.get(i).and_then(|v|v.clone()).unwrap_or_default() } else { literal(e) } }
fn literal(s:&str)->String{ unquote_ident(s.trim()).to_string() }
fn cmp_vals(a:&str,b:&str,op:&str)->bool{ if let (Ok(x),Ok(y))=(a.parse::<f64>(),b.parse::<f64>()) { match op {"="=>x==y,"!="|"<>"=>x!=y,">"=>x>y,"<"=>x<y,">="=>x>=y,"<="=>x<=y,_=>false} } else { match op {"="=>a==b,"!="|"<>"=>a!=b,">"=>a>b,"<"=>a<b,">="=>a>=b,"<="=>a<=b,_=>false} } }
fn like_match(v:&str, p:&str)->bool{ if p=="%"{true}else if p.starts_with('%')&&p.ends_with('%'){v.contains(&p[1..p.len()-1])}else if p.starts_with('%'){v.ends_with(&p[1..])}else if p.ends_with('%'){v.starts_with(&p[..p.len()-1])}else{v==p} }
fn compare_order(headers:&[String],a:&[Option<String>],b:&[Option<String>], ord:&[(String,bool)])->Ordering{ for (c,asc) in ord{ if let Some(i)=col_index(headers,c){ let av=a.get(i).and_then(|v|v.as_ref()).map(|s|s.as_str()).unwrap_or(""); let bv=b.get(i).and_then(|v|v.as_ref()).map(|s|s.as_str()).unwrap_or(""); let o=if let(Ok(x),Ok(y))=(av.parse::<f64>(),bv.parse::<f64>()){x.partial_cmp(&y).unwrap_or(Ordering::Equal)}else{av.cmp(bv)}; if o!=Ordering::Equal{return if *asc{o}else{o.reverse()};} } } Ordering::Equal }

fn format_output(t:&Table, opts:&Opts)->String{ let nl=if opts.crlf{"\r\n"}else{"\n"}; let mut s=match opts.output.as_str(){ "json"=>fmt_json(t,true), "jsonl"=>fmt_jsonl(t), "ltsv"=>fmt_ltsv(t,nl), "md"=>fmt_md(t,nl), "at"=>fmt_at(t,nl), "raw"=>fmt_csv(t,opts,false,nl), "tbln"=>fmt_tbln(t,nl), "vf"=>fmt_vf(t,nl), "yaml"=>fmt_yaml(t,nl), _=>fmt_csv(t,opts,opts.oh,nl) }; if !s.ends_with(nl){s.push_str(nl);} s }
fn cell(v:&Option<String>, opts:&Opts)->String{ v.clone().unwrap_or_else(||opts.onull.clone()) }
fn fmt_csv(t:&Table, opts:&Opts, header:bool, nl:&str)->String{ let mut lines=vec![]; if header{lines.push(t.headers.iter().map(|x|csv_escape(x,&opts.oq,&opts.od,opts.oaq)).collect::<Vec<_>>().join(&opts.od));} for r in &t.rows{lines.push(r.iter().map(|v|csv_escape(&cell(v,opts),&opts.oq,&opts.od,opts.oaq)).collect::<Vec<_>>().join(&opts.od));} lines.join(nl) }
fn csv_escape(v:&str,q:&str,d:&str,all:bool)->String{ let need=all||v.contains(d)||v.contains('\n')||v.contains('\r')||v.contains(q); if need{format!("{}{}{}",q,v.replace(q,&format!("{}{}",q,q)),q)}else{v.to_string()} }
fn json_escape(s:&str)->String{ serde_json::to_string(s).unwrap() }
fn fmt_json(t:&Table, pretty:bool)->String{
    if !pretty { return format!("[{}]", t.rows.iter().map(|r|json_row(t,r,false,0)).collect::<Vec<_>>().join(",")); }
    if t.rows.is_empty(){ return "[]".into(); }
    let rows=t.rows.iter().map(|r|json_row(t,r,true,2)).collect::<Vec<_>>().join(",\n");
    format!("[\n{}\n]", rows)
}
fn fmt_jsonl(t:&Table)->String{ t.rows.iter().map(|r|json_row(t,r,false,0)).collect::<Vec<_>>().join("\n") }
fn json_row(t:&Table,r:&[Option<String>],pretty:bool,indent:usize)->String{
    if pretty {
        let sp=" ".repeat(indent); let sp2=" ".repeat(indent+2);
        let fields=(0..t.headers.len()).map(|i|{
            let val=r.get(i).and_then(|v|v.clone()).map(|v|json_escape(&v)).unwrap_or_else(||"null".into());
            format!("{}{}: {}", sp2, json_escape(&t.headers[i]), val)
        }).collect::<Vec<_>>().join(",\n");
        format!("{}{{\n{}\n{}}}", sp, fields, sp)
    } else {
        let fields=(0..t.headers.len()).map(|i|{
            let val=r.get(i).and_then(|v|v.clone()).map(|v|json_escape(&v)).unwrap_or_else(||"null".into());
            format!("{}:{}", json_escape(&t.headers[i]), val)
        }).collect::<Vec<_>>().join(",");
        format!("{{{}}}", fields)
    }
}
fn fmt_ltsv(t:&Table,nl:&str)->String{ t.rows.iter().map(|r| t.headers.iter().enumerate().map(|(i,h)|format!("{}:{}",h,r.get(i).and_then(|v|v.clone()).unwrap_or_default())).collect::<Vec<_>>().join("\t")).collect::<Vec<_>>().join(nl) }
fn widths(t:&Table)->Vec<usize>{ (0..t.headers.len()).map(|i| std::iter::once(t.headers[i].len()).chain(t.rows.iter().map(move|r|r.get(i).and_then(|v|v.as_ref()).map(|s|s.len()).unwrap_or(0))).max().unwrap_or(0)).collect() }
fn numeric_col(t:&Table,i:usize)->bool{ t.rows.iter().all(|r|r.get(i).and_then(|v|v.as_ref()).map(|s|s.parse::<f64>().is_ok()).unwrap_or(false)) }
fn pad(v:&str,w:usize,num:bool)->String{ if num{format!("{:>width$}",v,width=w)}else{format!("{:<width$}",v,width=w)} }
fn fmt_md(t:&Table,nl:&str)->String{ let w=widths(t); let mut lines=vec![]; lines.push(format!("| {} |", t.headers.iter().enumerate().map(|(i,h)|pad(h,w[i],false)).collect::<Vec<_>>().join(" | "))); lines.push(format!("|{}|", w.iter().map(|x|"-".repeat(x+2)).collect::<Vec<_>>().join("|"))); for r in &t.rows{lines.push(format!("| {} |", (0..t.headers.len()).map(|i|pad(&r.get(i).and_then(|v|v.clone()).unwrap_or_default(),w[i],numeric_col(t,i))).collect::<Vec<_>>().join(" | ")));} lines.join(nl) }
fn fmt_at(t:&Table,nl:&str)->String{ let w=widths(t); let sep=format!("+{}+",w.iter().map(|x|"-".repeat(x+2)).collect::<Vec<_>>().join("+")); let mut lines=vec![sep.clone(),format!("| {} |",t.headers.iter().enumerate().map(|(i,h)|pad(h,w[i],false)).collect::<Vec<_>>().join(" | ")),sep.clone()]; for r in &t.rows{lines.push(format!("| {} |",(0..t.headers.len()).map(|i|pad(&r.get(i).and_then(|v|v.clone()).unwrap_or_default(),w[i],numeric_col(t,i))).collect::<Vec<_>>().join(" | ")));} lines.push(sep); lines.join(nl) }
fn fmt_tbln(t:&Table,nl:&str)->String{ let mut lines=vec![format!("; name: | {} |",t.headers.join(" | ")),format!("; type: | {} |",vec!["text";t.headers.len()].join(" | "))]; for r in &t.rows{lines.push(format!("| {} |",(0..t.headers.len()).map(|i|r.get(i).and_then(|v|v.clone()).unwrap_or_default()).collect::<Vec<_>>().join(" | ")));} lines.join(nl) }
fn fmt_vf(t:&Table,nl:&str)->String{ let hw=t.headers.iter().map(|h|h.len()).max().unwrap_or(0); let mut lines=vec![]; for (ri,r) in t.rows.iter().enumerate(){ lines.push(format!("---[ {}]------------------------",ri+1)); for (i,h) in t.headers.iter().enumerate(){ lines.push(format!("{:>width$} | {}",h,r.get(i).and_then(|v|v.clone()).unwrap_or_default(),width=hw)); } } lines.join(nl) }
fn fmt_yaml(t:&Table,nl:&str)->String{ let mut lines=vec![]; for r in &t.rows{ for (i,h) in t.headers.iter().enumerate(){ let v=r.get(i).and_then(|v|v.clone()).unwrap_or_default(); if i==0{lines.push(format!("- {}: {}",h,v));}else{lines.push(format!("  {}: {}",h,v));} } } lines.join(nl) }
