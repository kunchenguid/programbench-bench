use regex::Regex;
use serde::Serialize;
use std::cmp::Ordering;
use std::collections::{HashMap, HashSet};
use std::ffi::OsStr;
use std::fs;
use std::io::{self, Read};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Clone, Copy, Debug)]
enum Format {
    Si,
    B,
    K,
    M,
    G,
    T,
    Kb,
    Mb,
    Gb,
    Tb,
}

#[derive(Clone, Copy, Debug)]
enum FileTimeKind {
    A,
    C,
    M,
}

#[derive(Debug)]
struct Args {
    depth: Option<usize>,
    threads: Option<usize>,
    config: Option<String>,
    number_of_lines: Option<usize>,
    full_paths: bool,
    ignore_directory: Vec<String>,
    ignore_all_in_file: Option<String>,
    dereference_links: bool,
    limit_filesystem: bool,
    apparent_size: bool,
    reverse: bool,
    no_colors: bool,
    force_colors: bool,
    no_percent_bars: bool,
    bars_on_right: bool,
    min_size: Option<String>,
    screen_reader: bool,
    skip_total: bool,
    filecount: bool,
    ignore_hidden: bool,
    invert_filter: Vec<String>,
    filter: Vec<String>,
    file_types: bool,
    terminal_width: Option<usize>,
    no_progress: bool,
    print_errors: bool,
    only_dir: bool,
    only_file: bool,
    output_format: Option<Format>,
    stack_size: Option<String>,
    output_json: bool,
    mtime: Option<String>,
    atime: Option<String>,
    ctime: Option<String>,
    files0_from: Option<String>,
    files_from: Option<String>,
    collapse: Vec<String>,
    filetime: Option<FileTimeKind>,
    paths: Vec<String>,
}

#[derive(Clone, Debug)]
struct Node {
    name: String,
    path: PathBuf,
    size: u64,
    is_dir: bool,
    children: Vec<Node>,
    depth: usize,
}

#[derive(Serialize)]
struct JsonNode {
    size: String,
    name: String,
    children: Vec<JsonNode>,
}

struct Ctx {
    args: Args,
    min_size: u64,
    filters: Vec<Regex>,
    excludes: Vec<Regex>,
    ignore_names: HashSet<String>,
    root_dev: Option<u64>,
    time_filter: Option<(char, i64)>,
}

fn default_args() -> Args {
    Args {
        depth: None,
        threads: None,
        config: None,
        number_of_lines: None,
        full_paths: false,
        ignore_directory: Vec::new(),
        ignore_all_in_file: None,
        dereference_links: false,
        limit_filesystem: false,
        apparent_size: false,
        reverse: false,
        no_colors: false,
        force_colors: false,
        no_percent_bars: false,
        bars_on_right: false,
        min_size: None,
        screen_reader: false,
        skip_total: false,
        filecount: false,
        ignore_hidden: false,
        invert_filter: Vec::new(),
        filter: Vec::new(),
        file_types: false,
        terminal_width: None,
        no_progress: false,
        print_errors: false,
        only_dir: false,
        only_file: false,
        output_format: None,
        stack_size: None,
        output_json: false,
        mtime: None,
        atime: None,
        ctime: None,
        files0_from: None,
        files_from: None,
        collapse: Vec::new(),
        filetime: None,
        paths: Vec::new(),
    }
}

fn parse_args() -> Args {
    let mut a = default_args();
    let raw = std::env::args().skip(1).collect::<Vec<_>>();
    if let Some(cfg) = find_config_path(&raw) {
        apply_config(&mut a, &cfg);
    } else if let Some(home) = std::env::var_os("HOME") {
        let p1 = PathBuf::from(&home).join(".config/dust/config.toml");
        let p2 = PathBuf::from(&home).join(".dust.toml");
        if p1.exists() {
            apply_config(&mut a, &p1);
        } else if p2.exists() {
            apply_config(&mut a, &p2);
        }
    }
    let mut it = raw.into_iter().peekable();
    while let Some(arg) = it.next() {
        if arg == "--help" || arg == "-h" || arg == "--version" || arg == "-V" {
            continue;
        }
        let (key, inline) = if let Some((k, v)) = arg.split_once('=') {
            (k.to_string(), Some(v.to_string()))
        } else {
            (arg.clone(), None)
        };
        let mut val = || inline.clone().or_else(|| it.next()).unwrap_or_default();
        match key.as_str() {
            "-d" | "--depth" => a.depth = val().parse().ok(),
            "-T" | "--threads" => a.threads = val().parse().ok(),
            "--config" => a.config = Some(val()),
            "-n" | "--number-of-lines" => a.number_of_lines = val().parse().ok(),
            "-p" | "--full-paths" => a.full_paths = true,
            "-X" | "--ignore-directory" => a.ignore_directory.push(val()),
            "-I" | "--ignore-all-in-file" => a.ignore_all_in_file = Some(val()),
            "-L" | "--dereference-links" => a.dereference_links = true,
            "-x" | "--limit-filesystem" => a.limit_filesystem = true,
            "-s" | "--apparent-size" => a.apparent_size = true,
            "-r" | "--reverse" => a.reverse = true,
            "-c" | "--no-colors" => a.no_colors = true,
            "-C" | "--force-colors" => a.force_colors = true,
            "-b" | "--no-percent-bars" => a.no_percent_bars = true,
            "-B" | "--bars-on-right" => a.bars_on_right = true,
            "-z" | "--min-size" => a.min_size = Some(val()),
            "-R" | "--screen-reader" => a.screen_reader = true,
            "--skip-total" => a.skip_total = true,
            "-f" | "--filecount" => a.filecount = true,
            "-i" | "--ignore-hidden" => a.ignore_hidden = true,
            "-v" | "--invert-filter" => a.invert_filter.push(val()),
            "-e" | "--filter" => a.filter.push(val()),
            "-t" | "--file-types" => a.file_types = true,
            "-w" | "--terminal-width" => a.terminal_width = val().parse().ok(),
            "-P" | "--no-progress" => a.no_progress = true,
            "--print-errors" => a.print_errors = true,
            "-D" | "--only-dir" => a.only_dir = true,
            "-F" | "--only-file" => a.only_file = true,
            "-o" | "--output-format" => a.output_format = parse_format(&val()),
            "-S" | "--stack-size" => a.stack_size = Some(val()),
            "-j" | "--output-json" => a.output_json = true,
            "-M" | "--mtime" => a.mtime = Some(val()),
            "-A" | "--atime" => a.atime = Some(val()),
            "-y" | "--ctime" => a.ctime = Some(val()),
            "--files0-from" => a.files0_from = Some(val()),
            "--files-from" => a.files_from = Some(val()),
            "--collapse" => a.collapse.push(val()),
            "-m" | "--filetime" => a.filetime = parse_filetime(&val()),
            _ if key.starts_with('-') && key.len() > 2 && !key.starts_with("--") => {
                for ch in key[1..].chars() {
                    match ch {
                        'p' => a.full_paths = true,
                        'L' => a.dereference_links = true,
                        'x' => a.limit_filesystem = true,
                        's' => a.apparent_size = true,
                        'r' => a.reverse = true,
                        'c' => a.no_colors = true,
                        'C' => a.force_colors = true,
                        'b' => a.no_percent_bars = true,
                        'B' => a.bars_on_right = true,
                        'R' => a.screen_reader = true,
                        'f' => a.filecount = true,
                        'i' => a.ignore_hidden = true,
                        't' => a.file_types = true,
                        'P' => a.no_progress = true,
                        'D' => a.only_dir = true,
                        'F' => a.only_file = true,
                        'j' => a.output_json = true,
                        _ => {}
                    }
                }
            }
            _ => a.paths.push(arg),
        }
    }
    a
}

fn find_config_path(raw: &[String]) -> Option<PathBuf> {
    let mut i = 0;
    while i < raw.len() {
        if raw[i] == "--config" {
            return raw.get(i + 1).map(PathBuf::from);
        }
        if let Some(v) = raw[i].strip_prefix("--config=") {
            return Some(PathBuf::from(v));
        }
        i += 1;
    }
    None
}

fn apply_config(a: &mut Args, path: &Path) {
    let Ok(text) = fs::read_to_string(path) else { return; };
    for line in text.lines() {
        let line = line.split('#').next().unwrap_or("").trim();
        let Some((k, v)) = line.split_once('=') else { continue; };
        let key = k.trim();
        let val = v.trim().trim_matches('"').trim_matches('\'');
        let b = matches!(val, "true" | "yes" | "1");
        match key {
            "reverse" => a.reverse = b,
            "display-full-paths" | "full-paths" => a.full_paths = b,
            "display-apparent-size" | "apparent-size" => a.apparent_size = b,
            "no-colors" => a.no_colors = b,
            "no-bars" | "no-percent-bars" => a.no_percent_bars = b,
            "skip-total" => a.skip_total = b,
            "ignore-hidden" => a.ignore_hidden = b,
            "output-format" => a.output_format = parse_format(val),
            "number-of-lines" => a.number_of_lines = val.parse().ok(),
            "depth" => a.depth = val.parse().ok(),
            "only-dir" => a.only_dir = b,
            "only-file" => a.only_file = b,
            "filecount" => a.filecount = b,
            "min-size" => a.min_size = Some(val.to_string()),
            "filter" => a.filter.push(val.to_string()),
            "invert-filter" => a.invert_filter.push(val.to_string()),
            _ => {}
        }
    }
}

fn parse_format(s: &str) -> Option<Format> {
    match s.to_ascii_lowercase().as_str() {
        "si" => Some(Format::Si),
        "b" => Some(Format::B),
        "k" | "kib" => Some(Format::K),
        "m" | "mib" => Some(Format::M),
        "g" | "gib" => Some(Format::G),
        "t" | "tib" => Some(Format::T),
        "kb" => Some(Format::Kb),
        "mb" => Some(Format::Mb),
        "gb" => Some(Format::Gb),
        "tb" => Some(Format::Tb),
        _ => None,
    }
}

fn parse_filetime(s: &str) -> Option<FileTimeKind> {
    match s {
        "a" => Some(FileTimeKind::A),
        "c" => Some(FileTimeKind::C),
        "m" => Some(FileTimeKind::M),
        _ => None,
    }
}

fn print_help(_long: bool) {
    println!("Like du but more intuitive\n");
    println!("Usage: executable [OPTIONS] [PATH]...\n");
    println!("Arguments:\n  [PATH]...  Input files or directories\n");
    println!("Options:");
    println!("  -d, --depth <DEPTH>              Depth to show");
    println!("  -T, --threads <THREADS>          Number of threads to use");
    println!("      --config <FILE>              Specify a config file to use");
    println!("  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)");
    println!("  -p, --full-paths                 Subdirectories will not have their path shortened");
    println!("  -X, --ignore-directory <PATH>    Exclude any file or directory with this path");
    println!("  -I, --ignore-all-in-file <FILE>  Exclude regexes listed in this file");
    println!("  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them");
    println!("  -x, --limit-filesystem           Only count same filesystem");
    println!("  -s, --apparent-size              Use file length instead of blocks");
    println!("  -r, --reverse                    Print tree upside down (biggest highest)");
    println!("  -c, --no-colors                  No colors will be printed");
    println!("  -C, --force-colors               Force colors print");
    println!("  -b, --no-percent-bars            No percent bars or percentages will be displayed");
    println!("  -B, --bars-on-right              percent bars moved to right side of screen");
    println!("  -z, --min-size <MIN_SIZE>        Minimum size file to include in output");
    println!("  -R, --screen-reader              Removes bars. Adds depth column");
    println!("      --skip-total                 No total row will be displayed");
    println!("  -f, --filecount                  Directory 'size' is number of child files");
    println!("  -i, --ignore-hidden              Do not display hidden files");
    println!("  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex");
    println!("  -e, --filter <REGEX>             Only include filepaths matching this regex");
    println!("  -t, --file-types                 show only these file types");
    println!("  -w, --terminal-width <WIDTH>     Specify width of output");
    println!("  -P, --no-progress                Disable the progress indication");
    println!("      --print-errors               Print path with errors");
    println!("  -D, --only-dir                   Only directories will be displayed");
    println!("  -F, --only-file                  Only files will be displayed");
    println!("  -o, --output-format <FORMAT>     Changes output display size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]");
    println!("  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size");
    println!("  -j, --output-json                Output the directory tree as json");
    println!("  -M, --mtime <MTIME>              Filter by modified time");
    println!("  -A, --atime <ATIME>              Filter by access time");
    println!("  -y, --ctime <CTIME>              Filter by change time");
    println!("      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE");
    println!("      --files-from <FILES_FROM>    Read newline-terminated paths from FILE");
    println!("      --collapse <COLLAPSE>        Keep these directories collapsed");
    println!("  -m, --filetime <FILETIME>        Directory 'size' is max filetime [possible values: a, c, m]");
    println!("  -h, --help                       Print help");
    println!("  -V, --version                    Print version");
}

fn main() {
    let args = parse_args();
    if std::env::args().any(|a| a == "--help" || a == "-h") {
        print_help(false);
        return;
    }
    if std::env::args().any(|a| a == "--version" || a == "-V") {
        println!("Dust 1.2.3");
        return;
    }
    let mut paths = args.paths.clone();
    if let Some(file) = &args.files_from {
        match read_paths_file(file, false) {
            Ok(mut p) => paths.append(&mut p),
            Err(e) => {
                eprintln!("Failed to read {}: {}", file, e);
                std::process::exit(1);
            }
        }
    }
    if let Some(file) = &args.files0_from {
        match read_paths_file(file, true) {
            Ok(mut p) => paths.append(&mut p),
            Err(e) => {
                eprintln!("Failed to read {}: {}", file, e);
                std::process::exit(1);
            }
        }
    }
    if paths.is_empty() {
        paths.push(".".to_string());
    }

    let mut excludes = Vec::new();
    for pat in &args.invert_filter {
        if let Ok(r) = Regex::new(pat) {
            excludes.push(r);
        }
    }
    if let Some(file) = &args.ignore_all_in_file {
        if let Ok(text) = fs::read_to_string(file) {
            for line in text.lines().filter(|l| !l.trim().is_empty()) {
                if let Ok(r) = Regex::new(line.trim()) {
                    excludes.push(r);
                }
            }
        }
    }
    let filters = args
        .filter
        .iter()
        .filter_map(|p| Regex::new(p).ok())
        .collect::<Vec<_>>();
    let min_size = args.min_size.as_deref().map(parse_size).unwrap_or(0);
    let time_filter = args
        .mtime
        .as_ref()
        .map(|s| ('m', parse_time_arg(s)))
        .or_else(|| args.atime.as_ref().map(|s| ('a', parse_time_arg(s))))
        .or_else(|| args.ctime.as_ref().map(|s| ('c', parse_time_arg(s))));

    let mut roots = Vec::new();
    for p in &paths {
        let pb = PathBuf::from(p);
        let root_dev = metadata(&pb, args.dereference_links).ok().map(|m| m.dev());
        let mut ctx = Ctx {
            args: Args { paths: paths.clone(), ..args_clone_without_paths(&args) },
            min_size,
            filters: filters.clone(),
            excludes: excludes.clone(),
            ignore_names: args.ignore_directory.iter().cloned().collect(),
            root_dev,
            time_filter,
        };
        if let Some(node) = scan(&pb, 0, &mut ctx) {
            roots.push(node);
        }
    }

    if args.file_types {
        roots = vec![file_type_tree(&roots)];
    } else if roots.len() > 1 {
        let total = roots.iter().map(|n| n.size).sum();
        roots.sort_by(sort_nodes);
        roots = vec![Node {
            name: "(total)".to_string(),
            path: PathBuf::from("(total)"),
            size: total,
            is_dir: true,
            children: roots,
            depth: 0,
        }];
    }

    if args.output_json {
        let json_roots = roots.iter().map(|n| to_json(n, &args)).collect::<Vec<_>>();
        if json_roots.len() == 1 {
            println!("{}", serde_json::to_string(&json_roots[0]).unwrap());
        } else {
            println!("{}", serde_json::to_string(&json_roots).unwrap());
        }
        return;
    }

    for root in roots {
        print_tree(&root, &args);
    }
}

fn args_clone_without_paths(a: &Args) -> Args {
    Args {
        depth: a.depth,
        threads: a.threads,
        config: a.config.clone(),
        number_of_lines: a.number_of_lines,
        full_paths: a.full_paths,
        ignore_directory: a.ignore_directory.clone(),
        ignore_all_in_file: a.ignore_all_in_file.clone(),
        dereference_links: a.dereference_links,
        limit_filesystem: a.limit_filesystem,
        apparent_size: a.apparent_size,
        reverse: a.reverse,
        no_colors: a.no_colors,
        force_colors: a.force_colors,
        no_percent_bars: a.no_percent_bars,
        bars_on_right: a.bars_on_right,
        min_size: a.min_size.clone(),
        screen_reader: a.screen_reader,
        skip_total: a.skip_total,
        filecount: a.filecount,
        ignore_hidden: a.ignore_hidden,
        invert_filter: a.invert_filter.clone(),
        filter: a.filter.clone(),
        file_types: a.file_types,
        terminal_width: a.terminal_width,
        no_progress: a.no_progress,
        print_errors: a.print_errors,
        only_dir: a.only_dir,
        only_file: a.only_file,
        output_format: a.output_format,
        stack_size: a.stack_size.clone(),
        output_json: a.output_json,
        mtime: a.mtime.clone(),
        atime: a.atime.clone(),
        ctime: a.ctime.clone(),
        files0_from: a.files0_from.clone(),
        files_from: a.files_from.clone(),
        collapse: a.collapse.clone(),
        filetime: a.filetime,
        paths: Vec::new(),
    }
}

fn read_paths_file(file: &str, nul: bool) -> io::Result<Vec<String>> {
    let mut text = Vec::new();
    if file == "-" {
        io::stdin().read_to_end(&mut text)?;
    } else {
        text = fs::read(file)?;
    }
    let parts: Vec<&[u8]> = if nul {
        text.split(|b| *b == 0).collect()
    } else {
        text.split(|b| *b == b'\n').collect()
    };
    Ok(parts
        .into_iter()
        .filter(|p| !p.is_empty())
        .map(|p| String::from_utf8_lossy(p).to_string())
        .collect())
}

fn metadata(path: &Path, deref: bool) -> io::Result<fs::Metadata> {
    if deref {
        fs::metadata(path)
    } else {
        fs::symlink_metadata(path)
    }
}

fn scan(path: &Path, depth: usize, ctx: &mut Ctx) -> Option<Node> {
    let md = match metadata(path, ctx.args.dereference_links) {
        Ok(m) => m,
        Err(e) => {
            if ctx.args.print_errors {
                eprintln!("{}: {}", path.display(), e);
            }
            return None;
        }
    };
    let name = path
        .file_name()
        .unwrap_or_else(|| OsStr::new(path.to_str().unwrap_or(".")))
        .to_string_lossy()
        .to_string();
    if ctx.args.ignore_hidden && name.starts_with('.') && depth > 0 {
        return None;
    }
    if ctx.ignore_names.contains(&name) || ctx.ignore_names.contains(&path.to_string_lossy().to_string()) {
        return None;
    }
    let pstr = path.to_string_lossy();
    if ctx.excludes.iter().any(|r| r.is_match(&pstr)) {
        return None;
    }
    if ctx.args.limit_filesystem && ctx.root_dev.is_some_and(|d| d != md.dev()) {
        return None;
    }
    if let Some((kind, arg)) = ctx.time_filter {
        if !time_matches(&md, kind, arg) {
            return None;
        }
    }

    let is_dir = md.is_dir();
    let self_size = if ctx.args.filecount {
        if md.is_file() { 1 } else { 0 }
    } else if let Some(kind) = ctx.args.filetime {
        file_time_value(&md, kind)
    } else if is_dir && !ctx.filters.is_empty() {
        0
    } else if ctx.args.apparent_size {
        md.len()
    } else {
        md.blocks().saturating_mul(512)
    };

    let mut children = Vec::new();
    let mut size = self_size;
    if is_dir && !ctx.args.collapse.iter().any(|c| c == &name) {
        if let Ok(rd) = fs::read_dir(path) {
            for ent in rd.flatten() {
                if let Some(ch) = scan(&ent.path(), depth + 1, ctx) {
                    if ctx.args.filetime.is_some() {
                        size = size.max(ch.size);
                    } else {
                        size = size.saturating_add(ch.size);
                    }
                    children.push(ch);
                }
            }
        }
    }
    children.sort_by(sort_nodes);

    let matches_filter = ctx.filters.is_empty() || ctx.filters.iter().any(|r| r.is_match(&pstr));
    if !is_dir && !matches_filter {
        return None;
    }
    if ctx.min_size > 0 && !is_dir && size < ctx.min_size {
        return None;
    }
    if is_dir && !ctx.filters.is_empty() && children.is_empty() && !matches_filter {
        return None;
    }
    Some(Node {
        name,
        path: path.to_path_buf(),
        size,
        is_dir,
        children,
        depth,
    })
}

fn sort_nodes(a: &Node, b: &Node) -> Ordering {
    a.size.cmp(&b.size).then_with(|| a.name.cmp(&b.name))
}

fn parse_size(s: &str) -> u64 {
    let s = s.trim();
    let num_end = s
        .find(|c: char| !(c.is_ascii_digit() || c == '.'))
        .unwrap_or(s.len());
    let n: f64 = s[..num_end].parse().unwrap_or(0.0);
    let unit = s[num_end..].to_ascii_lowercase();
    let mul = match unit.as_str() {
        "k" | "ki" | "kib" => 1024.0,
        "m" | "mi" | "mib" => 1024.0 * 1024.0,
        "g" | "gi" | "gib" => 1024.0 * 1024.0 * 1024.0,
        "t" | "ti" | "tib" => 1024.0_f64.powi(4),
        "kb" => 1000.0,
        "mb" => 1000.0 * 1000.0,
        "gb" => 1000.0 * 1000.0 * 1000.0,
        "tb" => 1000.0_f64.powi(4),
        _ => 1.0,
    };
    (n * mul) as u64
}

fn parse_time_arg(s: &str) -> i64 {
    if let Some(rest) = s.strip_prefix('+') {
        rest.parse::<i64>().unwrap_or(0) + 10_000_000
    } else if let Some(rest) = s.strip_prefix('-') {
        -rest.parse::<i64>().unwrap_or(0)
    } else {
        s.parse().unwrap_or(0)
    }
}

fn time_matches(md: &fs::Metadata, kind: char, arg: i64) -> bool {
    let secs = match kind {
        'a' => md.atime(),
        'c' => md.ctime(),
        _ => md.mtime(),
    };
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_secs() as i64;
    let age_days = (now - secs) / 86_400;
    if arg >= 10_000_000 {
        age_days > arg - 10_000_000
    } else if arg < 0 {
        age_days < -arg
    } else {
        age_days == arg
    }
}

fn file_time_value(md: &fs::Metadata, kind: FileTimeKind) -> u64 {
    match kind {
        FileTimeKind::A => md.atime(),
        FileTimeKind::C => md.ctime(),
        FileTimeKind::M => md.mtime(),
    }
    .max(0) as u64
}

fn format_size(size: u64, args: &Args) -> String {
    if args.filecount {
        return size.to_string();
    }
    if args.filetime.is_some() {
        return size.to_string();
    }
    let Some(fmt) = args.output_format else {
        return human(size, 1024);
    };
    match fmt {
        Format::B => format!("{}B", size),
        Format::K => format!("{}K", size / 1024),
        Format::M => format!("{}M", size / 1024 / 1024),
        Format::G => format!("{}G", size / 1024 / 1024 / 1024),
        Format::T => format!("{}T", size / 1024 / 1024 / 1024 / 1024),
        Format::Kb => format!("{}kB", size / 1000),
        Format::Mb => format!("{}MB", size / 1000 / 1000),
        Format::Gb => format!("{}GB", size / 1000 / 1000 / 1000),
        Format::Tb => format!("{}TB", size / 1000 / 1000 / 1000 / 1000),
        Format::Si => human(size, 1000),
    }
}

fn human(size: u64, base: u64) -> String {
    let units = ["B", "K", "M", "G", "T"];
    let mut v = size as f64;
    let mut idx = 0;
    while v >= base as f64 && idx < units.len() - 1 {
        v /= base as f64;
        idx += 1;
    }
    if idx == 0 {
        format!("{}B", size)
    } else if v < 10.0 {
        format!("{:.1}{}", v, units[idx])
    } else {
        format!("{:.0}{}", v, units[idx])
    }
}

fn display_name(n: &Node, args: &Args) -> String {
    if args.full_paths || args.output_json {
        n.path.to_string_lossy().to_string()
    } else {
        n.name.clone()
    }
}

fn flatten<'a>(n: &'a Node, max_depth: usize, out: &mut Vec<&'a Node>) {
    if n.depth <= max_depth {
        out.push(n);
        for ch in &n.children {
            flatten(ch, max_depth, out);
        }
    }
}

fn print_tree(root: &Node, args: &Args) {
    let max_depth = args.depth.unwrap_or(usize::MAX);
    let mut items = Vec::new();
    flatten(root, max_depth, &mut items);
    if args.only_dir {
        items.retain(|n| n.is_dir || n.depth == 0);
    }
    if args.only_file {
        items.retain(|n| !n.is_dir || n.depth == 0);
    }
    if args.skip_total {
        items.retain(|n| n.depth != 0);
    }
    items.sort_by(|a, b| sort_nodes(a, b));
    if args.reverse {
        items.reverse();
    }
    let limit = args.number_of_lines.unwrap_or(usize::MAX);
    if items.len() > limit {
        if args.reverse {
            items.truncate(limit);
        } else {
            let start = items.len() - limit;
            items = items[start..].to_vec();
        }
    }
    let total = root.size.max(1);
    let size_w = items
        .iter()
        .map(|n| format_size(n.size, args).len())
        .max()
        .unwrap_or(1);
    let name_w = items.iter().map(|n| display_name(n, args).len() + n.depth * 2).max().unwrap_or(1);
    for n in items {
        let sz = format_size(n.size, args);
        let indent = "  ".repeat(n.depth);
        let pct = (n.size as f64 * 100.0 / total as f64).round() as u64;
        let mut name = format!("{}{}", indent, display_name(n, args));
        if args.screen_reader {
            println!("{:>width$} {} {}", sz, n.depth, name, width = size_w);
        } else if args.no_percent_bars {
            println!("{:>width$}   {}", sz, name, width = size_w);
        } else {
            let bar_len = ((pct as usize).max(1) * 30 / 100).max(1);
            let bar = "█".repeat(bar_len);
            while name.len() < name_w {
                name.push(' ');
            }
            if args.bars_on_right {
                println!("{:>width$}   {} {:>3}% │{}│", sz, name, pct, bar, width = size_w);
            } else {
                println!("{:>width$}   {} │{:<30}│ {:>3}%", sz, name, bar, pct, width = size_w);
            }
        }
    }
}

fn to_json(n: &Node, args: &Args) -> JsonNode {
    JsonNode {
        size: format_size(n.size, args),
        name: n.path.to_string_lossy().to_string(),
        children: n.children.iter().rev().map(|c| to_json(c, args)).collect(),
    }
}

fn file_type_tree(roots: &[Node]) -> Node {
    let mut map: HashMap<String, u64> = HashMap::new();
    fn walk(n: &Node, map: &mut HashMap<String, u64>) {
        if n.is_dir {
            for c in &n.children {
                walk(c, map);
            }
        } else {
            if let Some(e) = n.path.extension() {
                let ext = format!(".{}", e.to_string_lossy());
                *map.entry(ext).or_insert(0) += n.size;
            }
        }
    }
    for r in roots {
        walk(r, &mut map);
    }
    let mut children = map
        .into_iter()
        .map(|(name, size)| Node {
            name: name.clone(),
            path: PathBuf::from(name),
            size,
            is_dir: false,
            children: Vec::new(),
            depth: 1,
        })
        .collect::<Vec<_>>();
    children.sort_by(sort_nodes);
    let total = children.iter().map(|n| n.size).sum();
    Node {
        name: "(total)".to_string(),
        path: PathBuf::from("(total)"),
        size: total,
        is_dir: true,
        children,
        depth: 0,
    }
}
