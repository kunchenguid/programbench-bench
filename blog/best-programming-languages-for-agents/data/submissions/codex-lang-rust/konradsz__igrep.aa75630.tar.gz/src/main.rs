use std::env;
use std::io::{self, IsTerminal, Write};
use std::process;

const TYPE_LIST: &str = include_str!("../type-list.txt");
const HELP: &str = include_str!("../help.txt");

const EDITORS: &[&str] = &[
    "vim",
    "neovim",
    "nvim",
    "nano",
    "code",
    "vscode",
    "code-insiders",
    "emacs",
    "emacsclient",
    "hx",
    "helix",
    "subl",
    "sublime-text",
    "micro",
    "intellij",
    "goland",
    "pycharm",
    "less",
    "fresh",
];

const THEMES: &[&str] = &["light", "dark"];
const VIEWERS: &[&str] = &["none", "vertical", "horizontal"];
const SORTS: &[&str] = &["path", "modified", "created", "accessed"];

#[derive(Default)]
struct Parsed {
    type_list: bool,
    pattern: Option<String>,
    custom_command_seen: bool,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    match run(&args) {
        Ok(()) => {}
        Err(code) => process::exit(code),
    }
}

fn run(args: &[String]) -> Result<(), i32> {
    if args.is_empty() {
        return clap_error(
            "the following required arguments were not provided:\n  --type-list\n  <PATTERN>",
            Some("executable --type-list <PATTERN> [PATHS]..."),
        );
    }

    let mut parsed = Parsed::default();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--" {
            for value in &args[i + 1..] {
                take_positional(&mut parsed, value);
            }
            break;
        }

        match arg.as_str() {
            "-h" | "--help" => {
                print!("{HELP}");
                return Ok(());
            }
            "-V" | "--version" => {
                println!("igrep 1.3.0");
                return Ok(());
            }
            "--type-list" => parsed.type_list = true,
            "-i" | "--ignore-case" | "-S" | "--smart-case" | "-." | "--hidden" | "-L"
            | "--follow" | "-w" | "--word-regexp" | "-F" | "--fixed-strings" | "-U"
            | "--multiline" => {}
            "--editor" => {
                let value = value_after(args, &mut i, "--editor <EDITOR>")?;
                validate_value("--editor <EDITOR>", value, EDITORS)?;
            }
            "--theme" => {
                let value = value_after(args, &mut i, "--theme <THEME>")?;
                validate_value("--theme <THEME>", value, THEMES)?;
            }
            "--context-viewer" => {
                let value = value_after(args, &mut i, "--context-viewer <CONTEXT_VIEWER>")?;
                validate_value("--context-viewer <CONTEXT_VIEWER>", value, VIEWERS)?;
            }
            "--sort" => {
                let value = value_after(args, &mut i, "--sort <SORT_BY>")?;
                validate_value("--sort <SORT_BY>", value, SORTS)?;
            }
            "--sortr" => {
                let value = value_after(args, &mut i, "--sortr <SORT_BY_REVERSE>")?;
                validate_value("--sortr <SORT_BY_REVERSE>", value, SORTS)?;
            }
            "-g" | "--glob" => {
                value_after(args, &mut i, "--glob <GLOB>")?;
            }
            "-t" | "--type" => {
                value_after(args, &mut i, "--type <TYPE_MATCHING>")?;
            }
            "-T" | "--type-not" => {
                value_after(args, &mut i, "--type-not <TYPE_NOT>")?;
            }
            "--custom-command" => {
                let value = value_after(args, &mut i, "--custom-command <CUSTOM_COMMAND>")?;
                validate_command(value)?;
                parsed.custom_command_seen = true;
            }
            _ if arg.starts_with("--editor=") => {
                validate_value("--editor <EDITOR>", &arg["--editor=".len()..], EDITORS)?;
            }
            _ if arg.starts_with("--theme=") => {
                validate_value("--theme <THEME>", &arg["--theme=".len()..], THEMES)?;
            }
            _ if arg.starts_with("--context-viewer=") => {
                validate_value(
                    "--context-viewer <CONTEXT_VIEWER>",
                    &arg["--context-viewer=".len()..],
                    VIEWERS,
                )?;
            }
            _ if arg.starts_with("--sort=") => {
                validate_value("--sort <SORT_BY>", &arg["--sort=".len()..], SORTS)?;
            }
            _ if arg.starts_with("--sortr=") => {
                validate_value("--sortr <SORT_BY_REVERSE>", &arg["--sortr=".len()..], SORTS)?;
            }
            _ if arg.starts_with("--custom-command=") => {
                validate_command(&arg["--custom-command=".len()..])?;
                parsed.custom_command_seen = true;
            }
            _ if arg.starts_with("--glob=") || arg.starts_with("--type=") || arg.starts_with("--type-not=") => {}
            _ if arg.starts_with("--") => {
                return clap_error(
                    &format!(
                        "unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'"
                    ),
                    Some("executable [OPTIONS] --type-list <PATTERN> [PATHS]..."),
                );
            }
            _ if is_flag_cluster(arg) => {}
            _ if arg.starts_with('-') && arg.len() > 1 => {
                return clap_error(
                    &format!("unexpected argument '{arg}' found"),
                    Some("executable [OPTIONS] --type-list <PATTERN> [PATHS]..."),
                );
            }
            _ => take_positional(&mut parsed, arg),
        }
        i += 1;
    }

    if parsed.type_list {
        if parsed.pattern.is_some() {
            return clap_error(
                "the argument '--type-list' cannot be used with '<PATTERN>'",
                Some("executable --type-list <PATTERN> [PATHS]..."),
            );
        }
        print!("{TYPE_LIST}");
        return Ok(());
    }

    if parsed.pattern.is_none() {
        return clap_error(
            "the following required arguments were not provided:\n  --type-list\n  <PATTERN>",
            Some("executable --type-list <PATTERN> [PATHS]..."),
        );
    }

    if !parsed.custom_command_seen {
        if let Ok(command) = env::var("IGREP_CUSTOM_EDITOR") {
            if !command.is_empty() {
                validate_command(&command)?;
            }
        }
    }

    if !io::stdin().is_terminal() || !io::stdout().is_terminal() {
        eprintln!("Error: Resource temporarily unavailable (os error 11)");
        return Err(1);
    }

    print!("\x1b[?25l");
    let _ = io::stdout().flush();
    Ok(())
}

fn is_flag_cluster(arg: &str) -> bool {
    let mut chars = arg.chars();
    if chars.next() != Some('-') || arg.starts_with("--") {
        return false;
    }
    chars.all(|c| matches!(c, 'i' | 'S' | '.' | 'L' | 'w' | 'F' | 'U'))
}

fn take_positional(parsed: &mut Parsed, value: &str) {
    if parsed.pattern.is_none() {
        parsed.pattern = Some(value.to_string());
    }
}

fn value_after<'a>(args: &'a [String], i: &mut usize, name: &str) -> Result<&'a str, i32> {
    if *i + 1 >= args.len() {
        clap_error(
            &format!("a value is required for '{name}' but none was supplied"),
            None,
        )?;
        unreachable!();
    }
    *i += 1;
    Ok(&args[*i])
}

fn validate_value(name: &str, value: &str, allowed: &[&str]) -> Result<(), i32> {
    if allowed.contains(&value) {
        return Ok(());
    }
    clap_error(
        &format!(
            "invalid value '{value}' for '{name}'\n  [possible values: {}]",
            allowed.join(", ")
        ),
        None,
    )
}

fn validate_command(value: &str) -> Result<(), i32> {
    if value.matches("{file_name}").count() != 1 {
        eprintln!("Error: Incorrect editor command: '{value}'\n\nCaused by:\n    Expected one occurrence of '{{file_name}}'.");
        return Err(1);
    }
    if value.matches("{line_number}").count() != 1 {
        eprintln!("Error: Incorrect editor command: '{value}'\n\nCaused by:\n    Expected one occurrence of '{{line_number}}'.");
        return Err(1);
    }
    Ok(())
}

fn clap_error(message: &str, usage: Option<&str>) -> Result<(), i32> {
    eprintln!("error: {message}");
    if let Some(usage) = usage {
        eprintln!("\nUsage: {usage}");
    }
    eprintln!("\nFor more information, try '--help'.");
    Err(2)
}
