use std::env;
use std::fs;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "oranda 0.6.5";

fn main() {
    let args: Vec<String> = env::args().collect();
    let code = run(&args);
    process::exit(code);
}

fn run(args: &[String]) -> i32 {
    let mut i = 1usize;
    let mut verbose = false;
    let mut output_format = "human".to_string();

    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => {
                print_top_help(false);
                return 0;
            }
            "-V" | "--version" => {
                println!("{VERSION}");
                return 0;
            }
            "-v" | "--verbose" => {
                verbose = true;
                i += 1;
            }
            "--output-format" => {
                if i + 1 >= args.len() {
                    eprintln!("error: a value is required for '--output-format <OUTPUT_FORMAT>' but none was supplied\n\nFor more information, try '--help'.");
                    return 2;
                }
                output_format = args[i + 1].clone();
                if output_format != "human" && output_format != "json" {
                    eprintln!("error: invalid value '{}' for '--output-format <OUTPUT_FORMAT>'\n  [possible values: human, json]\n\nFor more information, try '--help'.", output_format);
                    return 2;
                }
                i += 2;
            }
            "--" => {
                i += 1;
                break;
            }
            s if s.starts_with('-') => {
                eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.", s);
                return 2;
            }
            _ => break,
        }
    }

    if i >= args.len() {
        print_top_help(true);
        return 2;
    }

    let rest = &args[i..];
    match rest[0].as_str() {
        "help" => {
            if rest.len() == 1 {
                print_top_help(false);
            } else {
                dispatch_help(&rest[1..]);
            }
            0
        }
        "build" => build_cmd(&rest[1..], &output_format),
        "serve" => serve_cmd(&rest[1..]),
        "dev" => dev_cmd(&rest[1..], &output_format),
        "generate" => generate_cmd(&rest[1..], &output_format),
        "config-schema" => config_schema_cmd(&rest[1..]),
        "generate-css" => generate_css_cmd(&rest[1..]),
        other => {
            let _ = verbose;
            eprintln!("error: unrecognized subcommand '{}'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.", other);
            2
        }
    }
}

fn dispatch_help(parts: &[String]) {
    match parts.get(0).map(String::as_str) {
        Some("build") => print_build_help(false),
        Some("dev") => print_dev_help(false),
        Some("serve") => print_serve_help(false),
        Some("generate") if parts.get(1).map(String::as_str) == Some("ci") => print_generate_ci_help(false),
        Some("generate") => print_generate_help(false),
        Some("config-schema") => print_config_schema_help(false),
        Some("generate-css") => print_generate_css_help(false),
        _ => print_top_help(false),
    }
}

fn print_top_help(short: bool) {
    if short {
        println!("🎁 generate beautiful landing pages for your projects\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  build     Build an oranda site\n  dev       Start a local development server that recompiles your oranda site if a file changes\n  serve     Start a file server to access your oranda site in a browser\n  generate  Generate infrastructure files for oranda sites\n  help      Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help (see more with '--help')\n  -V, --version  Print version\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:\n                                       human, json]");
    } else {
        println!("🎁 generate beautiful landing pages for your projects\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  build     Build an oranda site\n  dev       Start a local development server that recompiles your oranda site if a file changes\n  serve     Start a file server to access your oranda site in a browser\n  generate  Generate infrastructure files for oranda sites\n  help      Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output");
    }
}

fn print_build_help(short: bool) {
    if short { println!("Build an oranda site\n\nUsage: executable build [OPTIONS]\n\nOptions:\n      --json-only  Only build the artifacts JSON file (if applicable) and other files that may be used to\n                   support it, such as installer source files\n  -h, --help       Print help (see more with '--help')\n\nGLOBAL OPTIONS:\n  -v, --verbose                        Whether to output more detailed debug information\n      --output-format <OUTPUT_FORMAT>  The format of the output [default: human] [possible values:\n                                       human, json]"); }
    else { println!("Build an oranda site\n\nUsage: executable build [OPTIONS]\n\nOptions:\n      --json-only\n          Only build the artifacts JSON file (if applicable) and other files that may be used to\n          support it, such as installer source files\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output"); }
}

fn print_dev_help(_: bool) {
    println!("Start a local development server that recompiles your oranda site if a file changes\n\nUsage: executable dev [OPTIONS]\n\nOptions:\n      --port <PORT>\n          The port for the file server to be launched on\n\n      --no-first-build\n          Skip the first build before starting to watch for changes\n\n  -i, --include-paths <INCLUDE_PATHS>\n          List of extra paths to watch\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output");
}

fn print_serve_help(_: bool) {
    println!("Start a file server to access your oranda site in a browser\n\nUsage: executable serve [OPTIONS]\n\nOptions:\n      --port <PORT>\n          [default: 7979]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output");
}

fn print_generate_help(_: bool) {
    println!("Generate infrastructure files for oranda sites\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nCommands:\n  ci    Generates a CI file that can be used to deploy your site\n  help  Print this message or the help of the given subcommand(s)\n\nOptions:\n  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output");
}

fn print_generate_ci_help(_: bool) {
    println!("Generates a CI file that can be used to deploy your site\n\nUsage: executable generate ci [OPTIONS]\n\nOptions:\n      --ci <CI>\n          What CI to generate a file for\n          \n          [default: github]\n\n          Possible values:\n          - github: Deploy to GitHub Pages using GitHub Actions\n\n  -o, --output-path <OUTPUT_PATH>\n          Path to the output file\n\n  -s, --site-path <SITE_PATH>\n          Path to your oranda site\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output");
}

fn print_config_schema_help(_: bool) {
    println!("Usage: executable config-schema [OPTIONS]\n\nOptions:\n      --output <OUTPUT>\n          Write the config schema to the named file instead of stdout\n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output");
}

fn print_generate_css_help(_: bool) {
    println!("Usage: executable generate-css [OPTIONS]\n\nOptions:\n      --out-dir <OUT_DIR>\n          \n\n  -h, --help\n          Print help (see a summary with '-h')\n\nGLOBAL OPTIONS:\n  -v, --verbose\n          Whether to output more detailed debug information\n\n      --output-format <OUTPUT_FORMAT>\n          The format of the output\n          \n          [default: human]\n\n          Possible values:\n          - human: Human-readable output\n          - json:  Machine-readable JSON output");
}

fn build_cmd(args: &[String], output_format: &str) -> i32 {
    let mut json_only = false;
    for a in args {
        match a.as_str() {
            "-h" | "--help" => { print_build_help(false); return 0; }
            "--json-only" => json_only = true,
            x => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable build [OPTIONS]\n\nFor more information, try '--help'.", x); return 2; }
        }
    }
    if json_only {
        let _ = fs::create_dir_all("public");
        let _ = fs::write("public/artifacts.json", "[]\n");
        success(output_format, "Wrote artifacts JSON");
        return 0;
    }
    match build_site() {
        Ok(()) => { success(output_format, "Your site was built successfully."); 0 }
        Err(e) => { diagnostic(output_format, &e); 255 }
    }
}

fn build_site() -> Result<(), String> {
    fs::create_dir_all("public").map_err(|e| e.to_string())?;
    let readme = read_first(&["README.md", "readme.md"]).unwrap_or_else(|| "oranda\n\nGenerate beautiful landing pages for your projects.".to_string());
    let (title, body) = parse_markdown(&readme);
    let cfg_title = config_project_name().unwrap_or(title);
    let html = format!("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>{}</title>\n<link rel=\"stylesheet\" href=\"oranda.css\">\n</head>\n<body>\n<main>\n<h1>{}</h1>\n{}\n</main>\n</body>\n</html>\n", esc(&cfg_title), esc(&cfg_title), body);
    fs::write("public/index.html", html).map_err(|e| e.to_string())?;
    fs::write("public/oranda.css", "body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;margin:0;background:#f7f7f7;color:#202124}main{max-width:880px;margin:0 auto;padding:4rem 1.5rem}h1{font-size:2.5rem}pre{overflow:auto;background:#202124;color:white;padding:1rem;border-radius:6px}code{background:#e9e9e9;padding:.1rem .25rem;border-radius:3px}a{color:#0b57d0}\n").map_err(|e| e.to_string())?;
    fs::write("public/favicon.ico", []).map_err(|e| e.to_string())?;
    Ok(())
}

fn parse_markdown(src: &str) -> (String, String) {
    let mut title = "oranda".to_string();
    let mut body = String::new();
    let mut in_code = false;
    for line in src.lines() {
        if let Some(rest) = line.strip_prefix("# ") {
            if title == "oranda" { title = rest.trim().to_string(); }
            body.push_str(&format!("<h2>{}</h2>\n", esc(rest.trim())));
        } else if let Some(rest) = line.strip_prefix("## ") {
            body.push_str(&format!("<h2>{}</h2>\n", esc(rest.trim())));
        } else if let Some(rest) = line.strip_prefix("### ") {
            body.push_str(&format!("<h3>{}</h3>\n", esc(rest.trim())));
        } else if line.trim_start().starts_with("```") {
            if in_code { body.push_str("</code></pre>\n"); } else { body.push_str("<pre><code>"); }
            in_code = !in_code;
        } else if in_code {
            body.push_str(&esc(line));
            body.push('\n');
        } else if line.trim().is_empty() {
            body.push('\n');
        } else {
            body.push_str(&format!("<p>{}</p>\n", esc(line.trim())));
        }
    }
    if in_code { body.push_str("</code></pre>\n"); }
    (title, body)
}

fn config_project_name() -> Option<String> {
    let s = fs::read_to_string("oranda.json").ok()?;
    let key = "\"name\"";
    let pos = s.find(key)?;
    let after = &s[pos + key.len()..];
    let colon = after.find(':')?;
    let mut chars = after[colon + 1..].chars().skip_while(|c| c.is_whitespace());
    if chars.next()? != '"' { return None; }
    let rest: String = chars.collect();
    let end = rest.find('"')?;
    Some(rest[..end].to_string())
}

fn serve_cmd(args: &[String]) -> i32 {
    let mut port = 7979u16;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { print_serve_help(false); return 0; }
            "--port" => {
                if i + 1 >= args.len() { eprintln!("error: a value is required for '--port <PORT>' but none was supplied"); return 2; }
                port = args[i + 1].parse().unwrap_or(7979);
                i += 2;
            }
            x => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable serve [OPTIONS]\n\nFor more information, try '--help'.", x); return 2; }
        }
    }
    serve_forever(port, PathBuf::from("public"))
}

fn dev_cmd(args: &[String], output_format: &str) -> i32 {
    let mut port = 7979u16;
    let mut first_build = true;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { print_dev_help(false); return 0; }
            "--port" => { if i + 1 >= args.len() { return 2; } port = args[i + 1].parse().unwrap_or(7979); i += 2; }
            "--no-first-build" => { first_build = false; i += 1; }
            "-i" | "--include-paths" => { i += 2; }
            x => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable dev [OPTIONS]\n\nFor more information, try '--help'.", x); return 2; }
        }
    }
    if first_build {
        let _ = build_site().map(|_| success(output_format, "Your site was built successfully."));
    }
    serve_forever(port, PathBuf::from("public"))
}

fn serve_forever(port: u16, root: PathBuf) -> i32 {
    let listener = match TcpListener::bind(("127.0.0.1", port)) {
        Ok(l) => l,
        Err(e) => { eprintln!("  × {}", e); return 255; }
    };
    println!("✓ >o_o< SUCCESS: Your project is available at: http://127.0.0.1:{}/", port);
    for stream in listener.incoming().flatten() {
        let _ = handle_client(stream, &root);
    }
    0
}

fn handle_client(mut stream: TcpStream, root: &Path) -> std::io::Result<()> {
    let mut buf = [0u8; 1024];
    let n = stream.read(&mut buf)?;
    let req = String::from_utf8_lossy(&buf[..n]);
    let path = req.split_whitespace().nth(1).unwrap_or("/");
    let rel = path.trim_start_matches('/').split('?').next().unwrap_or("");
    let file = if rel.is_empty() { root.join("index.html") } else { root.join(rel) };
    let (status, body, ctype) = match fs::read(&file) {
        Ok(b) => ("200 OK", b, content_type(&file)),
        Err(_) => ("404 Not Found", b"not found\n".to_vec(), "text/plain"),
    };
    write!(stream, "HTTP/1.1 {}\r\nContent-Length: {}\r\nContent-Type: {}\r\nConnection: close\r\n\r\n", status, body.len(), ctype)?;
    stream.write_all(&body)?;
    Ok(())
}

fn content_type(p: &Path) -> &'static str {
    match p.extension().and_then(|e| e.to_str()).unwrap_or("") {
        "html" => "text/html; charset=utf-8",
        "css" => "text/css; charset=utf-8",
        "json" => "application/json",
        "js" => "text/javascript; charset=utf-8",
        _ => "application/octet-stream",
    }
}

fn generate_cmd(args: &[String], _output_format: &str) -> i32 {
    if args.is_empty() {
        print_generate_help(false);
        return 2;
    }
    let mut output: Option<String> = None;
    let mut site = ".".to_string();
    let mut ci = "github".to_string();
    let mut i = 0;
    let mut subcmd: Option<&str> = None;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { print_generate_help(false); return 0; }
            "-o" | "--output-path" => { if i + 1 >= args.len() { return 2; } output = Some(args[i+1].clone()); i += 2; }
            "-s" | "--site-path" => { if i + 1 >= args.len() { return 2; } site = args[i+1].clone(); i += 2; }
            "ci" => { subcmd = Some("ci"); i += 1; break; }
            "help" => { print_generate_help(false); return 0; }
            x if x.starts_with('-') => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.", x); return 2; }
            x => { eprintln!("error: unrecognized subcommand '{}'\n\nUsage: executable generate [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.", x); return 2; }
        }
    }
    if subcmd != Some("ci") { print_generate_help(false); return 2; }
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { print_generate_ci_help(false); return 0; }
            "--ci" => { if i + 1 >= args.len() { return 2; } ci = args[i+1].clone(); i += 2; }
            "-o" | "--output-path" => { if i + 1 >= args.len() { return 2; } output = Some(args[i+1].clone()); i += 2; }
            "-s" | "--site-path" => { if i + 1 >= args.len() { return 2; } site = args[i+1].clone(); i += 2; }
            x => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable generate ci [OPTIONS]\n\nFor more information, try '--help'.", x); return 2; }
        }
    }
    if ci != "github" {
        eprintln!("error: invalid value '{}' for '--ci <CI>'\n  [possible values: github]\n\nFor more information, try '--help'.", ci);
        return 2;
    }
    println!("↪ >o_o< INFO: Generating a CI deploy workflow for your site...");
    let path = output.unwrap_or_else(|| ".github/workflows/web.yml".to_string());
    if let Some(parent) = Path::new(&path).parent() {
        let _ = fs::create_dir_all(parent);
    }
    let workflow = github_workflow(&site);
    match fs::write(&path, workflow) {
        Ok(()) => { println!("✓ >o_o< SUCCESS: Wrote GitHub Actions workflow to {}", path); 0 }
        Err(e) => { eprintln!("  × {}", e); 255 }
    }
}

fn github_workflow(site: &str) -> String {
    format!("name: Web\n\non:\n  push:\n    branches: [main]\n  workflow_dispatch:\n\npermissions:\n  contents: read\n  pages: write\n  id-token: write\n\nconcurrency:\n  group: pages\n  cancel-in-progress: false\n\njobs:\n  deploy:\n    environment:\n      name: github-pages\n      url: ${{{{ steps.deployment.outputs.page_url }}}}\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - name: Install oranda\n        run: curl --proto '=https' --tlsv1.2 -LsSf https://github.com/axodotdev/oranda/releases/download/v0.6.5/oranda-installer.sh | sh\n      - name: Build\n        run: oranda build\n        working-directory: {}\n      - name: Setup Pages\n        uses: actions/configure-pages@v4\n      - name: Upload artifact\n        uses: actions/upload-pages-artifact@v3\n        with:\n          path: {}/public\n      - name: Deploy to GitHub Pages\n        id: deployment\n        uses: actions/deploy-pages@v4\n", site, site)
}

fn config_schema_cmd(args: &[String]) -> i32 {
    let mut output: Option<String> = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { print_config_schema_help(false); return 0; }
            "--output" => { if i + 1 >= args.len() { return 2; } output = Some(args[i+1].clone()); i += 2; }
            x => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable config-schema [OPTIONS]\n\nFor more information, try '--help'.", x); return 2; }
        }
    }
    let schema = r#"{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "OrandaLayer",
  "description": "Configuration for `oranda` (typically stored in oranda.json)",
  "type": "object",
  "properties": {
    "$schema": { "type": ["string", "null"] },
    "build": { "type": ["object", "null"] },
    "components": { "type": ["object", "null"] },
    "marketing": { "type": ["object", "null"] },
    "project": { "type": ["object", "null"] },
    "styles": { "type": ["object", "null"] },
    "workspace": { "type": ["object", "null"] }
  }
}
"#;
    if let Some(path) = output {
        match fs::write(path, schema) { Ok(()) => 0, Err(e) => { eprintln!("  × {}", e); 255 } }
    } else {
        print!("{}", schema);
        0
    }
}

fn generate_css_cmd(args: &[String]) -> i32 {
    let mut out = PathBuf::from(".");
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { print_generate_css_help(false); return 0; }
            "--out-dir" => { if i + 1 >= args.len() { return 2; } out = PathBuf::from(&args[i+1]); i += 2; }
            x => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable generate-css [OPTIONS]\n\nFor more information, try '--help'.", x); return 2; }
        }
    }
    let _ = fs::create_dir_all(&out);
    match fs::write(out.join("oranda.css"), "body{font-family:system-ui,sans-serif}\n") {
        Ok(()) => { println!("✓ >o_o< SUCCESS: Generated CSS"); 0 }
        Err(e) => { eprintln!("  × {}", e); 255 }
    }
}

fn success(format: &str, msg: &str) {
    if format == "json" {
        println!("{{\"message\":\"{}\",\"severity\":\"success\"}}", json_escape(msg));
    } else {
        println!("✓ >o_o< SUCCESS: {}", msg);
    }
}

fn diagnostic(format: &str, msg: &str) {
    if format == "json" {
        println!("{{\"diagnostic\": {{\"message\": \"{}\",\"severity\": \"error\",\"causes\": [],\"labels\": [],\"related\": []}}}}", json_escape(msg));
    }
    eprintln!("  × {}", msg);
}

fn read_first(names: &[&str]) -> Option<String> {
    names.iter().find_map(|n| fs::read_to_string(n).ok())
}

fn esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")
}
