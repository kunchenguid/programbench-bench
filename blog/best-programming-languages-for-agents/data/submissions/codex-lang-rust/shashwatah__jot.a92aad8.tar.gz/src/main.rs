use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io;
use std::path::{Component, Path, PathBuf};
use std::process::{Command, Stdio};

const BLUE: &str = "\x1b[0;34m";
const RED: &str = "\x1b[0;31m";
const RESET: &str = "\x1b[0m";

#[derive(Clone, Debug)]
struct Config {
    editor: String,
    conflict: bool,
}

#[derive(Clone, Debug)]
struct VaultFile {
    current: Option<String>,
    vaults: BTreeMap<String, String>,
}

#[derive(Clone, Debug)]
struct VaultData {
    name: String,
    location: String,
    folder: String,
}

fn main() {
    ensure_files();
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        print_main_help();
        std::process::exit(2);
    }
    if args[0] == "-h" || args[0] == "--help" {
        print_main_help();
        return;
    }
    if args[0] == "help" {
        if args.len() == 1 {
            print_main_help();
        } else {
            print_cmd_help(&args[1]);
        }
        return;
    }
    if args.len() > 1 && (args[1] == "-h" || args[1] == "--help") {
        print_cmd_help(&args[0]);
        return;
    }

    let res = match args[0].as_str() {
        "vault" | "vl" => cmd_vault(&args[1..]),
        "enter" | "en" => cmd_enter(&args[1..]),
        "note" | "nt" => cmd_note(&args[1..]),
        "folder" | "fd" => cmd_folder(&args[1..]),
        "open" | "op" => cmd_open(&args[1..]),
        "opdir" | "od" => cmd_opdir(&args[1..]),
        "list" | "ls" => cmd_list(&args[1..]),
        "chdir" | "cd" => cmd_chdir(&args[1..]),
        "remove" | "rm" => cmd_remove(&args[1..]),
        "rename" | "rn" => cmd_rename(&args[1..]),
        "move" | "mv" => cmd_move(&args[1..]),
        "vmove" | "vm" => cmd_vmove(&args[1..]),
        "config" | "cf" => cmd_config(&args[1..]),
        other => {
            eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context\n", other);
            eprintln!("USAGE:\n    executable <SUBCOMMAND>\n\nFor more information try --help");
            std::process::exit(2);
        }
    };
    if let Err(e) = res {
        println!("{RED}error{RESET}: {e}");
    }
}

fn home() -> PathBuf {
    PathBuf::from(env::var("HOME").unwrap_or_else(|_| ".".to_string()))
}

fn config_path() -> PathBuf {
    env::var("XDG_CONFIG_HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|_| home().join(".config"))
        .join("jot")
        .join("config")
}

fn vaults_path() -> PathBuf {
    env::var("XDG_DATA_HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|_| home().join(".local/share"))
        .join("jot")
        .join("vaults")
}

fn ensure_files() {
    let cp = config_path();
    if !cp.exists() {
        let _ = fs::create_dir_all(cp.parent().unwrap());
        let _ = fs::write(&cp, "editor = 'nvim'\nconflict = true\n");
    }
    let vp = vaults_path();
    if !vp.exists() {
        let _ = fs::create_dir_all(vp.parent().unwrap());
        let _ = fs::write(&vp, "[vaults]\n");
    }
    let _ = fs::create_dir_all(home().join(".cache/rosetta"));
}

fn read_config() -> Config {
    let s = fs::read_to_string(config_path()).unwrap_or_default();
    let mut c = Config { editor: "nvim".into(), conflict: true };
    for line in s.lines() {
        if let Some(v) = parse_assign(line, "editor") { c.editor = v; }
        if let Some(v) = parse_assign(line, "conflict") { c.conflict = v == "true"; }
    }
    c
}

fn write_config(c: &Config) -> io::Result<()> {
    fs::write(config_path(), format!("editor = '{}'\nconflict = {}\n", c.editor, c.conflict))
}

fn read_vaults() -> VaultFile {
    let s = fs::read_to_string(vaults_path()).unwrap_or_default();
    let mut vf = VaultFile { current: None, vaults: BTreeMap::new() };
    let mut in_vaults = false;
    for line in s.lines() {
        let t = line.trim();
        if t == "[vaults]" { in_vaults = true; continue; }
        if !in_vaults {
            if let Some(v) = parse_assign(t, "current") { vf.current = Some(v); }
        } else if let Some((k, v)) = parse_any_assign(t) {
            vf.vaults.insert(k, v);
        }
    }
    vf
}

fn write_vaults(vf: &VaultFile) -> io::Result<()> {
    let mut s = String::new();
    if let Some(cur) = &vf.current {
        s.push_str(&format!("current = '{}'\n\n", cur));
    }
    s.push_str("[vaults]\n");
    for (k, v) in &vf.vaults {
        s.push_str(&format!("{} = '{}'\n", k, v));
    }
    fs::write(vaults_path(), s)
}

fn parse_assign(line: &str, key: &str) -> Option<String> {
    let (k, v) = parse_any_assign(line)?;
    if k == key { Some(v) } else { None }
}

fn parse_any_assign(line: &str) -> Option<(String, String)> {
    let (k, v) = line.split_once('=')?;
    let val = v.trim().trim_matches('\'').to_string();
    Some((k.trim().to_string(), val))
}

fn vault_data_path(name: &str, loc: &str) -> PathBuf {
    Path::new(loc).join(name).join(".jot/data")
}

fn read_vault_data(name: &str, loc: &str) -> VaultData {
    let s = fs::read_to_string(vault_data_path(name, loc)).unwrap_or_default();
    let mut d = VaultData { name: name.into(), location: loc.into(), folder: String::new() };
    for line in s.lines() {
        if let Some(v) = parse_assign(line, "name") { d.name = v; }
        if let Some(v) = parse_assign(line, "location") { d.location = v; }
        if let Some(v) = parse_assign(line, "folder") { d.folder = v; }
    }
    d
}

fn write_vault_data(d: &VaultData) -> io::Result<()> {
    let p = vault_data_path(&d.name, &d.location);
    fs::create_dir_all(p.parent().unwrap())?;
    fs::write(p, format!("name = '{}'\nlocation = '{}'\nfolder = '{}'\nhistory = []\n", d.name, d.location, d.folder))
}

fn current_vault() -> Result<VaultData, String> {
    let vf = read_vaults();
    let name = vf.current.ok_or_else(|| "not inside a vault".to_string())?;
    let loc = vf.vaults.get(&name).ok_or_else(|| format!("vault {} doesn't exist", name))?;
    Ok(read_vault_data(&name, loc))
}

fn current_dir(d: &VaultData) -> PathBuf {
    let mut p = Path::new(&d.location).join(&d.name);
    if !d.folder.is_empty() {
        p.push(&d.folder);
    }
    p
}

fn note_file(base: &Path, name: &str) -> PathBuf {
    if name.ends_with(".md") { base.join(name) } else { base.join(format!("{name}.md")) }
}

fn strip_md(name: &str) -> String {
    name.strip_suffix(".md").unwrap_or(name).to_string()
}

fn blue(s: &str) -> String {
    format!("{BLUE}{s}{RESET}")
}

fn cmd_vault(args: &[String]) -> Result<(), String> {
    let mut vf = read_vaults();
    if args.is_empty() {
        for k in vf.vaults.keys() { println!("   {k}"); }
        return Ok(());
    }
    if args.len() == 1 && args[0] == "-l" {
        for (k, v) in &vf.vaults { println!("   {k} \t {v}"); }
        return Ok(());
    }
    if args.len() < 2 { return Err("couldn't find the path specified".into()); }
    let name = &args[0];
    let loc = &args[1];
    if vf.vaults.contains_key(name) { return Err(format!("vault {name} already exists")); }
    let lp = Path::new(loc);
    if !lp.is_absolute() { return Err("specified path isn't absolute".into()); }
    if !lp.exists() { return Err("couldn't find the path specified".into()); }
    let vp = lp.join(name);
    fs::create_dir_all(vp.join(".jot")).map_err(|e| e.to_string())?;
    let d = VaultData { name: name.clone(), location: loc.clone(), folder: String::new() };
    write_vault_data(&d).map_err(|e| e.to_string())?;
    vf.vaults.insert(name.clone(), loc.clone());
    write_vaults(&vf).map_err(|e| e.to_string())?;
    println!("vault {} created", blue(name));
    Ok(())
}

fn cmd_enter(args: &[String]) -> Result<(), String> {
    if args.is_empty() { return Err("vault  doesn't exist".into()); }
    let mut vf = read_vaults();
    let name = &args[0];
    if !vf.vaults.contains_key(name) { return Err(format!("vault {name} doesn't exist")); }
    vf.current = Some(name.clone());
    write_vaults(&vf).map_err(|e| e.to_string())?;
    println!("entered {}", blue(name));
    Ok(())
}

fn cmd_note(args: &[String]) -> Result<(), String> {
    if args.is_empty() { req_arg_error("note name", "jt note\n    jt note [note name]"); }
    let d = current_vault()?;
    let base = current_dir(&d);
    let name = &args[0];
    let p = note_file(&base, name);
    if p.exists() { return Err(format!("a note named {name} already exists in this location")); }
    fs::write(&p, "").map_err(|e| e.to_string())?;
    println!("note {} created", blue(name));
    Ok(())
}

fn cmd_folder(args: &[String]) -> Result<(), String> {
    if args.is_empty() { req_arg_error("folder name", "jt folder\n    jt folder [folder name]"); }
    let d = current_vault()?;
    let base = current_dir(&d);
    let name = &args[0];
    let p = base.join(name);
    if p.exists() { return Err(format!("a folder named {name} already exists in this location")); }
    fs::create_dir(&p).map_err(|e| e.to_string())?;
    println!("folder {} created", blue(name));
    Ok(())
}

fn cmd_chdir(args: &[String]) -> Result<(), String> {
    if args.is_empty() { return Err("couldn't find the path specified".into()); }
    let mut d = current_vault()?;
    let root = Path::new(&d.location).join(&d.name);
    let target = normalize_folder(&root, &current_dir(&d), &args[0])?;
    if !target.is_dir() { return Err("couldn't find the path specified".into()); }
    let rel = target.strip_prefix(&root).unwrap();
    d.folder = rel.to_string_lossy().trim_matches('/').to_string();
    write_vault_data(&d).map_err(|e| e.to_string())?;
    println!("folder changed");
    Ok(())
}

fn cmd_open(args: &[String]) -> Result<(), String> {
    if args.is_empty() { return Err("note  not found".into()); }
    let d = current_vault()?;
    let p = note_file(&current_dir(&d), &args[0]);
    if !p.exists() { return Err(format!("note {} not found", args[0])); }
    let editor = read_config().editor;
    let mut child = Command::new(editor).arg(p).stdin(Stdio::null()).spawn();
    if let Ok(ref mut ch) = child {
        let _ = ch.wait();
    }
    Ok(())
}

fn cmd_opdir(_args: &[String]) -> Result<(), String> {
    let d = current_vault()?;
    let p = current_dir(&d);
    let mut child = Command::new("xdg-open").arg(p).stdin(Stdio::null()).stdout(Stdio::null()).stderr(Stdio::null()).spawn();
    if let Ok(ref mut ch) = child {
        let _ = ch.wait();
    }
    Ok(())
}

fn normalize_folder(root: &Path, cur: &Path, raw: &str) -> Result<PathBuf, String> {
    let start = if Path::new(raw).is_absolute() {
        PathBuf::from(raw)
    } else {
        cur.join(raw)
    };
    let mut out = PathBuf::new();
    for c in start.components() {
        match c {
            Component::ParentDir => { out.pop(); }
            Component::CurDir => {}
            other => out.push(other.as_os_str()),
        }
    }
    if !out.starts_with(root) { return Err("couldn't find the path specified".into()); }
    Ok(out)
}

fn cmd_list(args: &[String]) -> Result<(), String> {
    let d = current_vault()?;
    let base = current_dir(&d);
    let kind = args.get(0).map(|s| s.as_str());
    let title = if d.folder.is_empty() { d.name.clone() } else { format!("{} > {}", d.name, d.folder.replace('/', " > ")) };
    println!("{title}");
    print_tree(&base, "", kind, true)?;
    Ok(())
}

fn print_tree(dir: &Path, prefix: &str, kind: Option<&str>, root_call: bool) -> Result<(), String> {
    let mut entries = Vec::new();
    for e in fs::read_dir(dir).map_err(|e| e.to_string())? {
        let e = e.map_err(|e| e.to_string())?;
        let name = e.file_name().to_string_lossy().to_string();
        let p = e.path();
        let is_dir = p.is_dir();
        let is_note = p.is_file() && name.ends_with(".md");
        if name == ".jot" && kind.is_none() { continue; }
        if name == ".jot" && kind.map_or(false, |k| matches!(k, "note" | "nt")) { continue; }
        if kind.map_or(true, |k| match k { "note" | "nt" => is_note, "folder" | "fd" => is_dir, _ => is_note || is_dir }) {
            if is_note || is_dir { entries.push((name, p, is_dir, is_note)); }
        }
    }
    entries.sort_by(|a, b| {
        if kind.is_none() {
            // The reference presents notes before folders in mixed normal listings.
            let ak = if a.3 { 0 } else { 1 };
            let bk = if b.3 { 0 } else { 1 };
            ak.cmp(&bk).then_with(|| a.0.cmp(&b.0))
        } else if matches!(kind, Some("folder" | "fd")) {
            let ak = if a.0 == ".jot" { 1 } else { 0 };
            let bk = if b.0 == ".jot" { 1 } else { 0 };
            ak.cmp(&bk).then_with(|| a.0.cmp(&b.0))
        } else {
            a.0.cmp(&b.0)
        }
    });
    let len = entries.len();
    for (i, (name, p, is_dir, is_note)) in entries.into_iter().enumerate() {
        let last = i + 1 == len;
        let branch = if last { "└── " } else { "├── " };
        let display = if is_note { blue(&strip_md(&name)) } else { name.clone() };
        println!("{prefix}{branch}{display}");
        if is_dir && kind.is_none() && name != ".jot" {
            let next_prefix = format!("{}{}", prefix, if last { "    " } else { "│   " });
            let _ = print_tree(&p, &next_prefix, kind, false);
        }
    }
    let _ = root_call;
    Ok(())
}

fn cmd_remove(args: &[String]) -> Result<(), String> {
    if args.len() < 2 { return Err("missing arguments".into()); }
    match norm_kind(&args[0])? {
        "vault" => {
            let mut vf = read_vaults();
            let name = &args[1];
            let loc = vf.vaults.remove(name).ok_or_else(|| format!("vault {name} doesn't exist"))?;
            let _ = fs::remove_dir_all(Path::new(&loc).join(name));
            if vf.current.as_deref() == Some(name) { vf.current = None; }
            write_vaults(&vf).map_err(|e| e.to_string())?;
            println!("vault {} removed", blue(name));
        }
        "note" => {
            let d = current_vault()?;
            let name = &args[1];
            let p = note_file(&current_dir(&d), name);
            if !p.exists() { return Err(format!("note {name} not found")); }
            fs::remove_file(p).map_err(|e| e.to_string())?;
            println!("note {} removed", blue(name));
        }
        "folder" => {
            let d = current_vault()?;
            let name = &args[1];
            let p = current_dir(&d).join(name);
            if !p.exists() { return Err(format!("folder {name} not found")); }
            fs::remove_dir_all(p).map_err(|e| e.to_string())?;
            println!("folder {} removed", blue(name));
        }
        _ => {}
    }
    Ok(())
}

fn cmd_rename(args: &[String]) -> Result<(), String> {
    if args.len() < 3 { return Err("missing arguments".into()); }
    match norm_kind(&args[0])? {
        "vault" => rename_vault(&args[1], &args[2]),
        "note" => {
            let d = current_vault()?;
            let from = note_file(&current_dir(&d), &args[1]);
            if !from.exists() { return Err(format!("note {} not found", args[1])); }
            let to = note_file(&current_dir(&d), &args[2]);
            fs::rename(from, to).map_err(|e| e.to_string())?;
            println!("note {} renamed to {}", blue(&args[1]), blue(&args[2]));
            Ok(())
        }
        "folder" => {
            let d = current_vault()?;
            let from = current_dir(&d).join(&args[1]);
            if !from.exists() { return Err(format!("folder {} not found", args[1])); }
            let to = current_dir(&d).join(&args[2]);
            fs::rename(from, to).map_err(|e| e.to_string())?;
            println!("folder {} renamed to {}", blue(&args[1]), blue(&args[2]));
            Ok(())
        }
        _ => Ok(()),
    }
}

fn rename_vault(old: &str, new: &str) -> Result<(), String> {
    let mut vf = read_vaults();
    let loc = vf.vaults.remove(old).ok_or_else(|| format!("vault {old} doesn't exist"))?;
    fs::rename(Path::new(&loc).join(old), Path::new(&loc).join(new)).map_err(|e| e.to_string())?;
    vf.vaults.insert(new.into(), loc.clone());
    if vf.current.as_deref() == Some(old) { vf.current = Some(new.into()); }
    write_vaults(&vf).map_err(|e| e.to_string())?;
    let mut d = read_vault_data(old, &loc);
    d.name = new.into();
    write_vault_data(&d).map_err(|e| e.to_string())?;
    println!("vault {} renamed to {}", blue(old), blue(new));
    Ok(())
}

fn cmd_move(args: &[String]) -> Result<(), String> {
    if args.len() < 3 { return Err("missing arguments".into()); }
    match norm_kind(&args[0])? {
        "vault" => {
            let mut vf = read_vaults();
            let name = &args[1];
            let old = vf.vaults.get(name).cloned().ok_or_else(|| format!("vault {name} doesn't exist"))?;
            let newloc = Path::new(&args[2]);
            if !newloc.is_absolute() { return Err("specified path isn't absolute".into()); }
            if !newloc.exists() { return Err("couldn't find the path specified".into()); }
            fs::rename(Path::new(&old).join(name), newloc.join(name)).map_err(|e| e.to_string())?;
            vf.vaults.insert(name.clone(), args[2].clone());
            write_vaults(&vf).map_err(|e| e.to_string())?;
            let mut d = read_vault_data(name, &args[2]);
            d.location = args[2].clone();
            write_vault_data(&d).map_err(|e| e.to_string())?;
            println!("vault {} moved", blue(name));
            Ok(())
        }
        "note" | "folder" => {
            let d = current_vault()?;
            let base = current_dir(&d);
            let name = &args[1];
            let dest = normalize_folder(&Path::new(&d.location).join(&d.name), &base, &args[2])?;
            if !dest.is_dir() { return Err("couldn't find the path specified".into()); }
            let (from, to, label) = if norm_kind(&args[0])? == "note" {
                (note_file(&base, name), note_file(&dest, name), "note")
            } else {
                (base.join(name), dest.join(name), "folder")
            };
            if !from.exists() { return Err(format!("{label} {name} not found")); }
            fs::rename(from, to).map_err(|e| e.to_string())?;
            println!("{label} {} moved", blue(name));
            Ok(())
        }
        _ => Ok(()),
    }
}

fn cmd_vmove(args: &[String]) -> Result<(), String> {
    if args.len() < 3 { return Err("missing arguments".into()); }
    let kind = norm_kind(&args[0])?;
    if kind == "vault" { return Err("invalid item type".into()); }
    let d = current_vault()?;
    let vf = read_vaults();
    let dest_loc = vf.vaults.get(&args[2]).ok_or_else(|| format!("vault {} doesn't exist", args[2]))?;
    let dest = Path::new(dest_loc).join(&args[2]);
    let base = current_dir(&d);
    let name = &args[1];
    let (from, to, label) = if kind == "note" {
        (note_file(&base, name), note_file(&dest, name), "note")
    } else {
        (base.join(name), dest.join(name), "folder")
    };
    if !from.exists() { return Err(format!("{} {} not found", label, name)); }
    fs::rename(from, to).map_err(|e| e.to_string())?;
    println!("{label} {} moved to vault {}", blue(name), blue(&args[2]));
    Ok(())
}

fn norm_kind(s: &str) -> Result<&'static str, String> {
    match s {
        "vault" | "vl" => Ok("vault"),
        "note" | "nt" => Ok("note"),
        "folder" | "fd" => Ok("folder"),
        _ => Err("invalid item type".into()),
    }
}

fn cmd_config(args: &[String]) -> Result<(), String> {
    let mut c = read_config();
    if args.is_empty() {
        let mut child = Command::new(&c.editor).arg(config_path()).stdin(Stdio::null()).spawn();
        if let Ok(ref mut ch) = child { let _ = ch.wait(); }
        return Ok(());
    }
    match args[0].as_str() {
        "editor" => {
            if args.len() == 1 { println!("editor: {}", blue(&c.editor)); }
            else {
                c.editor = args[1..].join(" ");
                write_config(&c).map_err(|e| e.to_string())?;
                println!("set {} to {}", blue("editor"), blue(&c.editor));
            }
        }
        "conflict" => {
            if args.len() == 1 { println!("conflict: {}", blue(if c.conflict { "true" } else { "false" })); }
            else {
                c.conflict = args[1] == "true";
                write_config(&c).map_err(|e| e.to_string())?;
                println!("set {} to {}", blue("conflict"), blue(if c.conflict { "true" } else { "false" }));
            }
        }
        v => {
            eprintln!("error: \"{}\" isn't a valid value for '<config type>'\n\t[possible values: editor, conflict]\n\nFor more information try --help", v);
            std::process::exit(2);
        }
    }
    Ok(())
}

fn req_arg_error(name: &str, usage: &str) -> ! {
    eprintln!("error: The following required arguments were not provided:\n    <{}>\n\nUSAGE:\n    {}\n\nFor more information try --help", name, usage);
    std::process::exit(2);
}

fn print_main_help() {
    print!("{BLUE}________      _____ 
______(_)_______  /_
_____  /_  __ \\  __/
____  / / /_/ / /_  
___  /  \\____/\\__/  
/___/         ᵥ₀.₁.₂  
{RESET}         

usage: jt <command>

{BLUE}commands:{RESET}

create items
    {BLUE}vault{RESET}, {BLUE}vl{RESET}       create a vault or list vaults
    create items in current folder
        {BLUE}note{RESET}, {BLUE}nt{RESET}        create a note 
        {BLUE}folder{RESET}, {BLUE}fd{RESET}      create a folder

interact with items
    {BLUE}enter{RESET}, {BLUE}en{RESET}       enter a vault
    {BLUE}open{RESET}, {BLUE}op{RESET}        open a note from current folder
    {BLUE}opdir{RESET}, {BLUE}od{RESET}       open current folder in file explorer
    {BLUE}chdir{RESET}, {BLUE}cd{RESET}       change folder within current vault
    {BLUE}list{RESET}, {BLUE}ls{RESET}        list items in current folder

perform fs operations on items
    {BLUE}remove{RESET}, {BLUE}rm{RESET}      remove an item 
    {BLUE}rename{RESET}, {BLUE}rn{RESET}      rename an item 
    {BLUE}move{RESET}, {BLUE}mv{RESET}        move an item to a new location
    {BLUE}vmove{RESET}, {BLUE}vm{RESET}       move an item to a different vault

config
    {BLUE}config{RESET}, {BLUE}cf{RESET}      display, set or open config

get help 
    use {BLUE}help{RESET} or {BLUE}-h{RESET} and {BLUE}--help{RESET} flags along with a command to get corresponding help
");
}

fn print_cmd_help(cmd: &str) {
    let c = match cmd {
        "vl" => "vault", "nt" => "note", "fd" => "folder", "en" => "enter", "op" => "open",
        "od" => "opdir", "cd" => "chdir", "ls" => "list", "rm" => "remove", "rn" => "rename",
        "mv" => "move", "vm" => "vmove", "cf" => "config", other => other,
    };
    match c {
        "vault" => println!("executable-vault \ncreate a vault or list vaults\n\nUSAGE:\n    jt vault\n    jt vault -l\n    jt vault <vault name> <vault location>\n\nARGS:\n    <vault name>        name for new vault\n    <vault location>    absolute path to location of new vault\n\nOPTIONS:\n    -l            show vaults' location\n    -h, --help    Print help information"),
        "note" => println!("executable-note \ncreate a note\n\nUSAGE:\n    jt note\n    jt note [note name]\n\nARGS:\n    <note name>    name for new note (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information"),
        "folder" => println!("executable-folder \ncreate a folder\n\nUSAGE:\n    jt folder\n    jt folder [folder name]\n\nARGS:\n    <folder name>    name for new folder (to be created in the current folder)\n\nOPTIONS:\n    -h, --help    Print help information"),
        "enter" => println!("executable-enter \nenter a vault\n\nUSAGE:\n    executable enter <vault name>\n\nARGS:\n    <vault name>    name of the vault to enter\n\nOPTIONS:\n    -h, --help    Print help information"),
        "open" => println!("executable-open \nopen a note (from the current folder)\n\nUSAGE:\n    executable open <note name>\n\nARGS:\n    <note name>    name of note to be opened\n\nOPTIONS:\n    -h, --help    Print help information"),
        "opdir" => println!("executable-opdir \nopen current folder in file explorer\n\nUSAGE:\n    executable opdir\n\nOPTIONS:\n    -h, --help    Print help information"),
        "chdir" => println!("executable-chdir \nchange folder within current vault\n\nUSAGE:\n    executable chdir <folder path>\n\nARGS:\n    <folder path>    path to folder to switch to (from current folder)\n\nOPTIONS:\n    -h, --help    Print help information"),
        "list" => println!("executable-list \nlist items in current folder\n\nUSAGE:\n    executable list [item type]\n\nARGS:\n    <item type>    \n\nOPTIONS:\n    -h, --help    Print help information"),
        "remove" => println!("executable-remove \nremove an item\n\nUSAGE:\n    executable remove <item type> <name>\n\nARGS:\n    <item type>    remove a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be removed\n\nOPTIONS:\n    -h, --help    Print help information"),
        "rename" => println!("executable-rename \nrename an item\n\nUSAGE:\n    executable rename <item type> <name> <new name>\n\nARGS:\n    <item type>    rename a vault (or vl) | note (or nt) | folder (or fd)\n    <name>         name of item to be renamed\n    <new name>     new name of item\n\nOPTIONS:\n    -h, --help    Print help information"),
        "move" => println!("executable-move \nmove an item\n\nUSAGE:\n    executable move <item type> <name> <new location>\n\nARGS:\n    <item type>       move a vault (or vl) | note (or nt) | folder (or fd)\n    <name>            name of item to be moved\n    <new location>    path to new location of item (current folder as root in case of note or\n                      folder)\n\nOPTIONS:\n    -h, --help    Print help information"),
        "vmove" => println!("executable-vmove \nmove notes and folders to a different vault\n\nUSAGE:\n    executable vmove <item type> <name> <vault name>\n\nARGS:\n    <item type>     move a note (or nt) | folder (or fd)\n    <name>          name of item to be moved\n    <vault name>    name of vault to move the item to\n\nOPTIONS:\n    -h, --help    Print help information"),
        "config" => println!("executable-config \ndisplay, set or open config\n\nUSAGE:\n    jt config <config type>\n    jt config <config type> [config value]\n\nARGS:\n    <config type>     name of config item to display or set\n    <config value>    pass a value if config needs to be updated\n\nOPTIONS:\n    -h, --help    Print help information"),
        _ => print_main_help(),
    }
}
