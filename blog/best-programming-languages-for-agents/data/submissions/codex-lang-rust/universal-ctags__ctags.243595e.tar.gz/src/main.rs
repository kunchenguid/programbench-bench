use std::env;
use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
use std::path::Path;

#[derive(Clone, Debug)]
struct Tag {
    name: String,
    path: String,
    line: usize,
    text: String,
    kind: char,
    kind_name: &'static str,
    fields: Vec<String>,
}

#[derive(Debug)]
struct Config {
    files: Vec<String>,
    output: Option<String>,
    output_format: String,
    xref: bool,
    append: bool,
    sort: bool,
    recurse: bool,
    filter: bool,
    filter_term: Option<String>,
    fields_line: bool,
    fields_lang: bool,
    fields_kind_long: bool,
    print_language: bool,
    language_force: Option<String>,
    list_action: Option<String>,
    machinable: bool,
    with_header: bool,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            files: Vec::new(), output: None, output_format: "u-ctags".into(), xref: false,
            append: false, sort: true, recurse: false, filter: false, filter_term: None,
            fields_line: false, fields_lang: false, fields_kind_long: false, print_language: false,
            language_force: None, list_action: None, machinable: false, with_header: true,
        }
    }
}

fn main() {
    let mut cfg = Config::default();
    if let Err(e) = parse_args(&mut cfg) {
        eprintln!("executable: {}", e);
        std::process::exit(1);
    }
    if let Some(action) = cfg.list_action.clone() {
        print_list(&action, &cfg);
        return;
    }
    if cfg.filter {
        run_filter(&cfg).unwrap_or_else(exit_io);
        return;
    }
    if cfg.files.is_empty() && !cfg.print_language {
        cfg.files.push(".".into());
    }
    let files = collect_files(&cfg.files, cfg.recurse);
    if cfg.print_language {
        for f in files { println!("{}", language_for(&f, &cfg).unwrap_or_else(|| "NONE".into())); }
        return;
    }
    let mut tags = Vec::new();
    for f in &files { tags.extend(parse_file(f, &cfg)); }
    if cfg.sort { tags.sort_by(|a,b| a.name.cmp(&b.name).then(a.path.cmp(&b.path)).then(a.line.cmp(&b.line)).then(a.kind.cmp(&b.kind))); }
    write_output(&tags, &cfg, &files).unwrap_or_else(exit_io);
}

fn exit_io(e: io::Error) { eprintln!("executable: {}", e); std::process::exit(1); }

fn parse_args(cfg: &mut Config) -> Result<(), String> {
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "--help" | "-?" | "--help-full" => { print_help(); std::process::exit(0); }
            "--version" => { print_version(); std::process::exit(0); }
            "--license" => { println!("Universal Ctags is distributed under the GNU General Public License."); std::process::exit(0); }
            "-x" => { cfg.xref = true; cfg.output_format = "xref".into(); cfg.output = Some("-".into()); }
            "-e" => { cfg.output_format = "etags".into(); }
            "-u" => cfg.sort = false,
            "-R" => cfg.recurse = true,
            "-a" => cfg.append = true,
            "-n" => cfg.fields_line = true,
            "-N" | "-B" | "-F" | "--quiet" | "--quiet=yes" | "--quiet=no" | "--totals" | "--totals=yes" | "--totals=no" => {}
            "--print-language" => cfg.print_language = true,
            "--machinable" | "--machinable=yes" => cfg.machinable = true,
            "--with-list-header=no" => cfg.with_header = false,
            "--with-list-header" | "--with-list-header=yes" => cfg.with_header = true,
            "--filter" | "--filter=yes" => cfg.filter = true,
            "--filter=no" => cfg.filter = false,
            "--recurse" | "--recurse=yes" => cfg.recurse = true,
            "--recurse=no" => cfg.recurse = false,
            "--sort=no" => cfg.sort = false,
            "--sort=yes" => cfg.sort = true,
            "--sort=foldcase" => cfg.sort = true,
            "--append" | "--append=yes" => cfg.append = true,
            "--append=no" => cfg.append = false,
            "-f" | "-o" => cfg.output = Some(it.next().ok_or(format!("{} option requires an argument", arg))?),
            "-L" => {
                let p = it.next().ok_or("-L option requires an argument")?;
                cfg.files.extend(read_list_file(&p).map_err(|e| e.to_string())?);
            }
            "-G" => {}
            "-D" | "-I" | "-h" => { let _ = it.next(); }
            _ if arg.starts_with("-f") && arg.len() > 2 => cfg.output = Some(arg[2..].to_string()),
            _ if arg.starts_with("-o") && arg.len() > 2 => cfg.output = Some(arg[2..].to_string()),
            _ if arg.starts_with("--output-format=") => { cfg.output_format = val(&arg).to_string(); cfg.xref = cfg.output_format == "xref"; }
            _ if arg.starts_with("--format=") => {}
            _ if arg.starts_with("--fields=") => apply_fields(cfg, val(&arg)),
            _ if arg.starts_with("--language-force=") => cfg.language_force = Some(val(&arg).to_string()),
            _ if arg.starts_with("--filter-terminator=") => cfg.filter_term = Some(val(&arg).to_string()),
            _ if arg.starts_with("--list-") => cfg.list_action = Some(arg.trim_start_matches("--").to_string()),
            _ if arg.starts_with("--exclude") || arg.starts_with("--options") || arg.starts_with("--maxdepth") || arg.starts_with("--links") || arg.starts_with("--tag-relative") || arg.starts_with("--extras") || arg.starts_with("--kinds-") || arg.starts_with("--roles-") || arg.starts_with("--pseudo-tags") || arg.starts_with("--input-encoding") || arg.starts_with("--output-encoding") || arg.starts_with("--langmap") || arg.starts_with("--map-") || arg.starts_with("--alias-") || arg.starts_with("--param-") || arg.starts_with("--excmd") || arg.starts_with("--pattern-length-limit") => {}
            _ if arg.starts_with('-') => {}
            _ => cfg.files.push(arg),
        }
    }
    Ok(())
}

fn val(s: &str) -> &str { s.split_once('=').map(|(_,v)| v).unwrap_or("") }

fn apply_fields(cfg: &mut Config, s: &str) {
    let enabling = !s.starts_with('-');
    for c in s.trim_start_matches(&['+','-'][..]).chars() {
        match c { 'n' if enabling => cfg.fields_line = true, 'l' if enabling => cfg.fields_lang = true, 'K' | 'z' if enabling => cfg.fields_kind_long = true, '*' if enabling => { cfg.fields_line=true; cfg.fields_lang=true; cfg.fields_kind_long=true; }, _ => {} }
    }
}

fn read_list_file(p: &str) -> io::Result<Vec<String>> {
    let mut s = String::new();
    if p == "-" { io::stdin().read_to_string(&mut s)?; } else { File::open(p)?.read_to_string(&mut s)?; }
    Ok(s.lines().map(str::trim).filter(|l| !l.is_empty()).map(str::to_string).collect())
}

fn run_filter(cfg: &Config) -> io::Result<()> {
    let mut input = String::new(); io::stdin().read_to_string(&mut input)?;
    for file in input.lines().map(str::trim).filter(|l| !l.is_empty()) {
        let mut c = Config { files: vec![file.into()], output: Some("-".into()), ..cfg.clone_basic() };
        c.filter = false;
        let tags = parse_file(file, &c);
        write_tags_stream(&mut io::stdout(), &tags, &c)?;
        if let Some(t) = &cfg.filter_term { print!("{}", t); }
    }
    Ok(())
}

impl Config { fn clone_basic(&self) -> Self { Self { files:self.files.clone(), output:self.output.clone(), output_format:self.output_format.clone(), xref:self.xref, append:self.append, sort:self.sort, recurse:self.recurse, filter:self.filter, filter_term:self.filter_term.clone(), fields_line:self.fields_line, fields_lang:self.fields_lang, fields_kind_long:self.fields_kind_long, print_language:self.print_language, language_force:self.language_force.clone(), list_action:None, machinable:self.machinable, with_header:self.with_header } } }

fn collect_files(inputs: &[String], recurse: bool) -> Vec<String> {
    let mut out = Vec::new();
    for name in inputs {
        let p = Path::new(name);
        if p.is_dir() { if recurse { walk_dir(p, &mut out); } }
        else if p.exists() { out.push(name.clone()); }
    }
    out
}
fn walk_dir(p: &Path, out: &mut Vec<String>) {
    if let Ok(rd) = fs::read_dir(p) {
        let mut entries: Vec<_> = rd.filter_map(Result::ok).collect(); entries.sort_by_key(|e| e.path());
        for e in entries { let path=e.path(); if path.is_dir() { walk_dir(&path,out); } else if path.is_file() { out.push(path.to_string_lossy().into_owned()); } }
    }
}

fn language_for(path: &str, cfg: &Config) -> Option<String> {
    if let Some(l) = &cfg.language_force { if l != "auto" { return Some(l.clone()); } }
    let p = Path::new(path); let name = p.file_name()?.to_string_lossy(); let ext = p.extension().map(|e| e.to_string_lossy().to_ascii_lowercase()).unwrap_or_default();
    Some(match ext.as_str() {
        "c" | "h" => "C", "cc"|"cpp"|"cxx"|"hpp"|"hh" => "C++", "py" => "Python", "rs" => "Rust", "go" => "Go", "js"|"mjs"|"cjs" => "JavaScript", "ts"|"tsx" => "TypeScript", "java" => "Java", "rb" => "Ruby", "php" => "PHP", "lua" => "Lua", "sh"|"bash" => "Sh", "pl"|"pm" => "Perl", "html"|"htm" => "HTML", "css" => "CSS", "json" => "JSON", "md"|"markdown" => "Markdown", "make" => "Make", _ if name == "Makefile" || name.ends_with(".mk") => "Make", _ => "NONE"
    }.into())
}

fn parse_file(path: &str, cfg: &Config) -> Vec<Tag> {
    let lang = language_for(path, cfg).unwrap_or_else(|| "NONE".into());
    let data = fs::read_to_string(path).unwrap_or_default();
    let lines: Vec<&str> = data.lines().collect();
    match lang.as_str() {
        "C" | "C++" | "Java" => parse_c_like(path, &lines, &lang),
        "Python" => parse_python(path, &lines),
        "Rust" => parse_rust(path, &lines),
        "Go" => parse_go(path, &lines),
        "JavaScript" | "TypeScript" => parse_js(path, &lines),
        "Ruby" => parse_ruby(path, &lines),
        "Sh" | "Make" => parse_shellish(path, &lines),
        _ => parse_generic(path, &lines),
    }
}

fn tag(path:&str, line:usize, text:&str, name:&str, kind:char, kind_name:&'static str, fields:Vec<String>) -> Tag { Tag{name:name.into(), path:path.into(), line, text:text.into(), kind, kind_name, fields} }
fn first_ident(s:&str)->Option<String>{ let mut out=String::new(); let mut started=false; for ch in s.chars(){ if !started { if ch=='_'||ch.is_ascii_alphabetic(){out.push(ch);started=true;} } else if ch=='_'||ch.is_ascii_alphanumeric(){out.push(ch)} else {break} } if out.is_empty(){None}else{Some(out)} }
fn words(s:&str)->Vec<String>{ let mut v=Vec::new(); let mut cur=String::new(); for ch in s.chars(){ if ch=='_'||ch.is_ascii_alphanumeric(){cur.push(ch)} else if !cur.is_empty(){v.push(cur.clone());cur.clear()} } if !cur.is_empty(){v.push(cur)} v }
fn clean_type(s:&str)->String{ s.split_whitespace().filter(|w| !["static","extern","const","volatile","inline","pub","private","protected","public","final","mut"].contains(w)).collect::<Vec<_>>().join(" ") }

fn parse_c_like(path:&str, lines:&[&str], lang:&str)->Vec<Tag>{
    let mut tags=Vec::new(); let is_java=lang=="Java";
    for (i,line) in lines.iter().enumerate(){ let n=i+1; let t=line.trim(); if t.is_empty()||t.starts_with("//"){continue}
        if let Some(rest)=t.strip_prefix("#define "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'d',"macro",vec!["file:".into()])); } }
        if let Some(pos)=t.find("enum "){ if let Some(name)=first_ident(&t[pos+5..]){ tags.push(tag(path,n,line,&name,'g',"enum", if is_java{vec![]}else{vec!["file:".into()]})); if let (Some(a),Some(b))=(t.find('{'),t.rfind('}')){ for w in t[a+1..b].split(',').filter_map(first_ident){ tags.push(tag(path,n,line,&w,'e',"enumerator",vec![format!("enum:{}",name),"file:".into()])); } } } }
        if let Some(pos)=t.find("struct "){ if let Some(name)=first_ident(&t[pos+7..]){ tags.push(tag(path,n,line,&name,'s',"struct", if is_java{vec![]}else{vec!["file:".into()]})); if t.starts_with("typedef") { if let Some(last)=words(t).last(){ tags.push(tag(path,n,line,last,'t',"typedef",vec![format!("typeref:struct:{}",name),"file:".into()])); } } if let (Some(a),Some(b))=(t.find('{'),t.rfind('}')){ for part in t[a+1..b].split(';'){ let ws=words(part); if ws.len()>=2 { let m=ws.last().unwrap(); tags.push(tag(path,n,line,m,'m',"member",vec![format!("struct:{}",name),format!("typeref:typename:{}",ws[..ws.len()-1].join(" ")),"file:".into()])); } } } } }
        if is_java { if let Some(pos)=t.find("class "){ if let Some(name)=first_ident(&t[pos+6..]){ tags.push(tag(path,n,line,&name,'c',"class",vec![])); } } }
        if t.contains('(') && (t.ends_with('{')||t.contains(") {")||t.ends_with(';')) && !t.starts_with("if") && !t.starts_with("for") && !t.starts_with("while") && !t.starts_with("switch") {
            if let Some(p)=t.find('('){ let before=t[..p].trim(); if let Some(name)=words(before).last().cloned(){ if !["return","sizeof"].contains(&name.as_str()){ let typ=before.trim_end_matches(&name).trim(); if !t.ends_with(';') { let kind='f'; let kname="function"; let mut fs=Vec::new(); let ct=clean_type(typ); if !ct.is_empty(){fs.push(format!("typeref:typename:{}",ct));} if !is_java && typ.contains("static"){fs.push("file:".into());} tags.push(tag(path,n,line,&name,kind,kname,fs)); } } } }
        }
        if t.ends_with(';') && !t.contains('(') && !t.starts_with("typedef") && !t.starts_with("#") && !t.contains("enum ") && !t.contains("struct ") { let decl=t.split('=').next().unwrap_or(t).trim_end_matches(';').trim(); let ws=words(decl); if ws.len()>=2 { let name=ws.last().unwrap(); if !["return"].contains(&name.as_str()) { let typ=clean_type(&ws[..ws.len()-1].join(" ")); if !typ.is_empty(){ tags.push(tag(path,n,line,name,'v',"variable",vec![format!("typeref:typename:{}",typ),"file:".into()])); } } } }
    } tags
}

fn parse_python(path:&str, lines:&[&str])->Vec<Tag>{ let mut tags=Vec::new(); let mut classes:Vec<(usize,String)>=Vec::new(); for (i,line) in lines.iter().enumerate(){ let n=i+1; let indent=line.chars().take_while(|c| *c==' '||*c=='\t').count(); let t=line.trim(); while classes.last().map(|(ind,_)| indent<=*ind).unwrap_or(false){classes.pop();} if let Some(rest)=t.strip_prefix("class "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'c',"class",vec![])); classes.push((indent,name)); } } else if let Some(rest)=t.strip_prefix("def "){ if let Some(name)=first_ident(rest){ if let Some((_,c))=classes.last(){ tags.push(tag(path,n,line,&name,'m',"member",vec![format!("class:{}",c)])); } else { tags.push(tag(path,n,line,&name,'f',"function",vec![])); } } } else if let Some(eq)=t.find('='){ let left=t[..eq].trim(); if !left.contains(' ') && !left.contains('.') { if let Some(name)=first_ident(left){ let mut fs=Vec::new(); if let Some((_,c))=classes.last(){fs.push(format!("class:{}",c));} tags.push(tag(path,n,line,&name,'v',"variable",fs)); } } } } tags }

fn parse_rust(path:&str, lines:&[&str])->Vec<Tag>{ let mut tags=Vec::new(); for (i,line) in lines.iter().enumerate(){ let n=i+1; let t=line.trim(); let s=t.strip_prefix("pub ").unwrap_or(t); for (kw,k,kn) in [("struct ",'s',"struct"),("enum ",'g',"enum"),("trait ",'i',"interface"),("mod ",'n',"module")]{ if let Some(rest)=s.strip_prefix(kw){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,k,kn,vec![])); if kw=="struct " { if let (Some(a),Some(b))=(s.find('{'),s.rfind('}')){ for part in s[a+1..b].split(','){ let p=part.trim().strip_prefix("pub ").unwrap_or(part.trim()); if let Some(col)=p.find(':'){ if let Some(m)=first_ident(&p[..col]){ tags.push(tag(path,n,line,&m,'m',"member",vec![format!("struct:{}",name)])); } } } } } if kw=="enum " { if let (Some(a),Some(b))=(s.find('{'),s.rfind('}')){ for v in s[a+1..b].split(',').filter_map(first_ident){ tags.push(tag(path,n,line,&v,'e',"enumerator",vec![format!("enum:{}",name)])); } } } } } }
        if let Some(rest)=s.strip_prefix("fn "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'f',"function",vec![])); } }
        if let Some(tp)=s.find("trait "){ if let Some(name)=first_ident(&s[tp+6..]){ if let Some(fp)=s.find("fn "){ if let Some(m)=first_ident(&s[fp+3..]){ tags.push(tag(path,n,line,&m,'P',"method",vec![format!("interface:{}",name)])); } } } }
        if let Some(rest)=s.strip_prefix("const "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'C',"constant",vec![])); } }
        if let Some(rest)=s.strip_prefix("static "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'v',"variable",vec![])); } }
        if let Some(rest)=s.strip_prefix("macro_rules! "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'M',"macro",vec![])); } }
        if let Some(rest)=s.strip_prefix("impl "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'c',"implementation",vec![])); if let Some(p)=s.find("fn "){ if let Some(m)=first_ident(&s[p+3..]){ tags.push(tag(path,n,line,&m,'P',"method",vec![format!("implementation:{}",name)])); } } } }
    } tags }

fn parse_go(path:&str, lines:&[&str])->Vec<Tag>{ let mut tags=Vec::new(); let mut pkg=String::new(); for (i,line) in lines.iter().enumerate(){ let n=i+1; let t=line.trim(); if let Some(rest)=t.strip_prefix("package "){ if let Some(name)=first_ident(rest){ pkg=name; tags.push(tag(path,n,line,&pkg,'p',"package",vec![])); } } else if let Some(rest)=t.strip_prefix("type "){ let ws=words(rest); if ws.len()>=2 { let name=&ws[0]; let (k,kn)=if ws.get(1).map(|s|s.as_str())==Some("interface") {('i',"interface")} else if ws.get(1).map(|s|s.as_str())==Some("struct") {('s',"struct")} else {('t',"typedef")}; tags.push(tag(path,n,line,name,k,kn,vec![format!("package:{}",pkg)])); if t.contains("struct") && t.contains('{') { let inside=t.split('{').nth(1).unwrap_or("").split('}').next().unwrap_or(""); let w=words(inside); if w.len()>=2 { tags.push(tag(path,n,line,&w[0],'m',"member",vec![format!("struct:{}.{}",pkg,name),format!("typeref:typename:{}",w[1])])); } } } } else if let Some(rest)=t.strip_prefix("func "){ let after=if rest.starts_with('('){ rest.split_once(')').map(|(_,r)|r.trim()).unwrap_or(rest) } else { rest }; if let Some(name)=first_ident(after){ tags.push(tag(path,n,line,&name,'f',"function",vec![format!("package:{}",pkg)])); } } else if let Some(rest)=t.strip_prefix("var "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'v',"variable",vec![format!("package:{}",pkg)])); } } else if let Some(rest)=t.strip_prefix("const "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'c',"constant",vec![format!("package:{}",pkg)])); } } } tags }

fn parse_js(path:&str, lines:&[&str])->Vec<Tag>{ let mut tags=Vec::new(); for (i,line) in lines.iter().enumerate(){ let n=i+1; let t=line.trim(); if let Some(rest)=t.strip_prefix("function "){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'f',"function",vec![])); } } if let Some(pos)=t.find("class "){ if let Some(name)=first_ident(&t[pos+6..]){ tags.push(tag(path,n,line,&name,'c',"class",vec![])); if let (Some(a),Some(b))=(t.find('{'),t.rfind('}')){ for part in t[a+1..b].split('{'){ let before=part.trim(); if before.ends_with(')'){ let w=words(before); if let Some(m)=w.last(){ if m!="static" { tags.push(tag(path,n,line,m,'m',"member",vec![format!("class:{}",name)])); } } } } } } } for kw in ["const ","let ","var "] { if let Some(rest)=t.strip_prefix(kw){ if let Some(name)=first_ident(rest){ let is_func=rest.contains("=>")||rest.contains("function"); let kind=if is_func{'f'}else if kw=="const "{'C'}else{'v'}; let kn=if kind=='f'{"function"}else if kind=='C'{"constant"}else{"variable"}; tags.push(tag(path,n,line,&name,kind,kn,vec![])); } } } } tags }
fn parse_ruby(path:&str, lines:&[&str])->Vec<Tag>{ let mut tags=Vec::new(); let mut cls=Vec::new(); for (i,line) in lines.iter().enumerate(){ let n=i+1; let t=line.trim(); if let Some(rest)=t.strip_prefix("class ").or_else(||t.strip_prefix("module ")){ if let Some(name)=first_ident(rest){ tags.push(tag(path,n,line,&name,'c',"class",vec![])); cls.push(name); } } else if let Some(rest)=t.strip_prefix("def "){ if let Some(name)=first_ident(rest){ let fs=cls.last().map(|c|vec![format!("class:{}",c)]).unwrap_or_default(); tags.push(tag(path,n,line,&name,'f',"method",fs)); } } else if t=="end" { cls.pop(); } } tags }
fn parse_shellish(path:&str, lines:&[&str])->Vec<Tag>{ let mut tags=Vec::new(); for (i,line) in lines.iter().enumerate(){ let n=i+1; let t=line.trim(); if t.ends_with("() {")||t.ends_with("(){") { if let Some(name)=first_ident(t){ tags.push(tag(path,n,line,&name,'f',"function",vec![])); } } else if let Some(eq)=t.find('='){ if eq>0 && !t[..eq].contains(' ') { if let Some(name)=first_ident(&t[..eq]){ tags.push(tag(path,n,line,&name,'v',"variable",vec![])); } } } } tags }
fn parse_generic(path:&str, lines:&[&str])->Vec<Tag>{ let mut tags=Vec::new(); for (i,line) in lines.iter().enumerate(){ let n=i+1; let t=line.trim(); if t.starts_with('#') { let name=t.trim_start_matches('#').trim(); if !name.is_empty(){ tags.push(tag(path,n,line,name,'s',"section",vec![])); } } } tags }

fn write_output(tags:&[Tag], cfg:&Config, files:&[String])->io::Result<()> { let out=cfg.output.clone().unwrap_or_else(|| if cfg.output_format=="etags"{"TAGS".into()}else{"tags".into()}); if out=="-" { write_tags_stream(&mut io::stdout(),tags,cfg) } else { let mut f:Box<dyn Write>=if cfg.append{Box::new(OpenOptions::new().create(true).append(true).open(out)?)}else{Box::new(File::create(out)?)}; if !cfg.append && cfg.output_format=="u-ctags" { write_pseudo(&mut f, files)?; } write_tags_stream(&mut f,tags,cfg) } }
fn write_tags_stream(w:&mut dyn Write,tags:&[Tag],cfg:&Config)->io::Result<()> { match cfg.output_format.as_str(){ "json"=>for t in tags{ writeln!(w,"{}",json_tag(t,cfg))?; }, "xref"=>for t in tags{ writeln!(w,"{:<16} {:<12} {:>4} {} {}",t.name,t.kind_name,t.line,t.path,t.text.trim())?; }, "etags"=>for t in tags{ writeln!(w,"{}\x7f{}\x01{},{}",t.text,t.name,t.line,t.text.len())?; }, _=>for t in tags{ write!(w,"{}\t{}\t{};\"\t{}",t.name,t.path,tag_pattern(t),t.kind)?; if cfg.fields_line{write!(w,"\tline:{}",t.line)?;} if cfg.fields_kind_long{write!(w,"\tkind:{}",t.kind_name)?;} for f in &t.fields{write!(w,"\t{}",f)?;} if cfg.fields_lang{ if let Some(l)=language_for(&t.path,cfg){write!(w,"\tlanguage:{}",l)?;} } writeln!(w)?; } } Ok(()) }
fn tag_pattern(t:&Tag)->String{ if t.kind=='d' && t.text.trim_start().starts_with("#define ") { format!("/^#define {} /", escape_pat(&t.name)) } else { format!("/^{}$/", escape_pat(&t.text)) } }
fn escape_pat(s:&str)->String{ s.replace('\\',"\\\\").replace('/',"\\/") }
fn json_escape(s:&str)->String{ s.chars().flat_map(|c| match c { '"'=>"\\\"".chars().collect::<Vec<_>>(), '\\'=>"\\\\".chars().collect(), '\n'=>"\\n".chars().collect(), '\r'=>"\\r".chars().collect(), '\t'=>"\\t".chars().collect(), _=>vec![c] }).collect() }
fn json_tag(t:&Tag,cfg:&Config)->String{ let mut s=format!("{{\"_type\": \"tag\", \"name\": \"{}\", \"path\": \"{}\", \"pattern\": \"/^{}$/\", \"kind\": \"{}\"",json_escape(&t.name),json_escape(&t.path),json_escape(&escape_pat(&t.text)),t.kind_name); if cfg.fields_line{s.push_str(&format!(", \"line\": {}",t.line));} for f in &t.fields{ if let Some(v)=f.strip_prefix("class:"){s.push_str(&format!(", \"scope\": \"{}\", \"scopeKind\": \"class\"",json_escape(v)));} else if let Some(v)=f.strip_prefix("struct:"){s.push_str(&format!(", \"scope\": \"{}\", \"scopeKind\": \"struct\"",json_escape(v)));} else if let Some(v)=f.strip_prefix("enum:"){s.push_str(&format!(", \"scope\": \"{}\", \"scopeKind\": \"enum\"",json_escape(v)));} } s.push('}'); s }
fn write_pseudo(w:&mut dyn Write,files:&[String])->io::Result<()> { let langs:Vec<String>=files.iter().filter_map(|f| language_for(f,&Config::default())).collect(); writeln!(w,"!_TAG_FILE_FORMAT\t2\t/extended format; --format=1 will not append ;\" to lines/")?; writeln!(w,"!_TAG_FILE_SORTED\t1\t/0=unsorted, 1=sorted, 2=foldcase/")?; writeln!(w,"!_TAG_OUTPUT_MODE\tu-ctags\t/u-ctags or e-ctags/")?; writeln!(w,"!_TAG_OUTPUT_VERSION\t1.1\t/current.age/")?; for l in langs{ if l!="NONE"{ writeln!(w,"!_TAG_PARSER_VERSION!{}\t1.0\t/current.age/",l)?; } } writeln!(w,"!_TAG_PROGRAM_AUTHOR\tUniversal Ctags Team\t//")?; writeln!(w,"!_TAG_PROGRAM_NAME\tUniversal Ctags\t/Derived from Exuberant Ctags/")?; writeln!(w,"!_TAG_PROGRAM_URL\thttps://ctags.io/\t/official site/")?; writeln!(w,"!_TAG_PROGRAM_VERSION\t6.2.0\t/d922013/") }

fn print_version(){ println!("Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team"); println!("Universal Ctags is derived from Exuberant Ctags."); println!("Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert"); println!("  Compiled: Apr 20 2026, 16:52:56"); println!("  URL: https://ctags.io/"); println!("  Output version: 1.1"); println!("  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript"); }
fn print_help(){ print_version(); println!("\nUsage: executable [options] [file(s)]\n\nInput/Output Options\n  -f <tagfile>\n       Write tags to specified <tagfile>. Value of \"-\" writes tags to stdout\n  -R   Equivalent to --recurse.\n  -L <file>\n       A list of input file names is read from the specified <file>.\n  --filter[=(yes|no)]\n       Behave as a filter, reading file names from standard input.\n\nOutput Format Options\n  --output-format=(u-ctags|e-ctags|etags|xref|json)\n  -x   Print a tabular cross reference file to standard output.\n  --fields=[+|-][<flags>|*]\n\nListing Options\n  --list-languages\n  --list-kinds[=(<language>|all)]\n  --list-fields\n  --list-features\n\nMiscellaneous Options\n  --help\n  --version"); }
fn print_list(action:&str,cfg:&Config){ let a=action.split('=').next().unwrap_or(action); match a { "list-languages"=>{ for l in ["C","C++","Go","HTML","Java","JavaScript","JSON","Lua","Make","Markdown","PHP","Python","Ruby","Rust","Sh","TypeScript"]{println!("{}",l)} }, "list-features"=>{ println!("#NAME             DESCRIPTION"); for f in ["iconv","interactive","json","option-directory","optscript","packcc","regex","sandbox","wildcards","xpath","yaml"]{println!("{:<17} supported",f)} }, "list-output-formats"=>{ println!("#OFORMAT DEFAULT AVAILABLE NULLTAG "); println!("e-ctags       no       yes      no "); println!("etags         no       yes      no "); println!("json          no       yes     yes "); println!("u-ctags      yes       yes      no "); println!("xref          no       yes     yes "); }, "list-kinds"=>{ if cfg.with_header && cfg.machinable {println!("LETTER\tNAME\tENABLED\tREFONLY\tNROLES\tMASTER\tDESCRIPTION");} for (c,n,d) in [('c',"class","classes"),('d',"macro","macro definitions"),('e',"enumerator","enumerators"),('f',"function","functions"),('g',"enum","enumeration names"),('i',"interface","interfaces"),('m',"member","members"),('n',"module","modules"),('p',"prototype","prototypes"),('s',"struct","structure names"),('t',"typedef","typedefs"),('v',"variable","variables")]{ if cfg.machinable{println!("{}\t{}\tyes\tno\t0\tNONE\t{}",c,n,d)}else{println!("{}  {}",c,d)} } }, "list-fields"=>{ println!("#LETTER NAME           ENABLED LANGUAGE         JSTYPE FIXED OP VER DESCRIPTION"); for (c,n,d) in [('N',"name","tag name"),('F',"input","input file"),('P',"pattern","pattern"),('f',"file","File-restricted scoping"),('k',"NONE","Kind of tag in one-letter form"),('l',"language","Language"),('n',"line","Line number"),('s',"NONE","scope"),('t',"typeref","Type and name")]{println!("{:<7} {:<14} yes     NONE             s--    no    --   0 {}",c,n,d)} }, _=>{} } }
