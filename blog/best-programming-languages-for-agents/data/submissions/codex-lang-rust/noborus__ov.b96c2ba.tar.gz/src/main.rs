use std::env;
use std::fs::File;
use std::io::{self};
use std::process;

const HELP: &str = r#"ov is a feature rich pager(such as more/less).
It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).

Usage:
  ov [flags] [FILE]...

Flags:
Short   Long                                    Purpose
  -l, --align                                   align the output columns for better readability
  -C, --alternate-rows                          alternately change the line color
      --caption string                          custom caption
  -i, --case-sensitive                          case-sensitive in search
  -d, --column-delimiter character              column delimiter character (default ",")
  -c, --column-mode                             column mode
      --column-rainbow                          column mode to rainbow
      --column-width                            column mode for width
      --completion string                       generate completion script [bash|zsh|fish|powershell]
      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)
      --converter string                        converter [es|raw|align] (default "es")
      --debug                                   debug mode
      --disable-column-cycle                    disable column cycling
      --disable-mouse                           disable mouse support
  -e, --exec                                    command execution result instead of file
  -X, --exit-write                              output the current screen when exiting
  -a, --exit-write-after int                    number after the current lines when exiting
  -b, --exit-write-before int                   number before the current lines when exiting
      --filter string                           filter search pattern
  -A, --follow-all                              follow multiple files and show the most recently updated one
  -f, --follow-mode                             monitor file and display new content as it is written
      --follow-name                             follow mode to monitor by file name
      --follow-section                          section-by-section follow mode
      --force-screen                            display screen even when redirecting output
  -H, --header int                              number of header lines to be displayed constantly
  -Y, --header-column int                       number of columns to display as a vertical header
  -h, --help                                    help for ov
      --help-key                                display key bind information
      --hide-other-section                      hide other section
      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default "10%")
      --incsearch[=true|false]                  incremental search (default true)
  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']
  -n, --line-number                             line number mode
      --list-view-modes                         list available view modes defined in the configuration file
      --memory-limit int                        number of chunks to limit in memory (default -1)
      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)
  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. "ERROR,WARNING"
      --non-match-filter string                 filter non match search pattern
      --notify-eof int                          notify at the end of the file
      --pattern string                          search pattern
  -p, --plain                                   disable original decoration
  -F, --quit-if-one-screen                      quit if the output fits on one screen
  -r, --raw                                     raw escape sequences without processing
      --regexp-search                           regular expression search
      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)
      --section-delimiter regexp                regexp for section delimiter .e.g. "^#"
      --section-header                          enable section-delimiter line as Header
      --section-header-num int                  number of section header lines (default 1)
      --section-start int                       section start position
      --set-terminal-title                      set terminal title
      --skip-extract                            skip extracting compressed files
      --skip-lines int                          skip the number of lines
      --smart-case-sensitive                    smart case-sensitive in search
      --status-line[=true|false]                status line (default true)
  -x, --tab-width int                           tab stop width (default 8)
  -v, --version                                 display version information
  -y, --vertical-header int                     number of characters to display as a vertical header
  -m, --view-mode string                        apply predefined settings for a specific mode
  -T, --watch seconds                           watch mode interval(seconds)
  -w, --wrap[=true|false]                       wrap mode (default true)
"#;

const HELP_KEY: &str = r#"ov is a feature rich pager
 Key                            Action

	General
 [Escape], [q]                  * quit
 [ctrl+c]                       * cancel
 [Q]                            * output screen and quit
 [ctrl+q]                       * set output screen and quit
 [alt+shift+F8]                 * set output original screen and quit
 [ctrl+z]                       * suspend
 [alt+v]                        * edit current document
 [h], [ctrl+F1], [ctrl+alt+c]   * display help screen
 [ctrl+F2], [ctrl+alt+e]        * display log screen
 [ctrl+l]                       * screen sync
 [ctrl+f]                       * follow mode toggle
 [ctrl+a]                       * follow all mode toggle
 [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse
 [S]                            * save buffer to file

	Moving
 [Enter], [Down], [ctrl+n]      * forward by one line
 [Up], [ctrl+p]                 * backward by one line
 [Home]                         * go to top of document
 [End]                          * go to end of document
 [PageDown], [ctrl+v]           * forward by page
 [PageUp], [ctrl+b]             * backward by page
 [ctrl+d]                       * forward a half page
 [ctrl+u]                       * backward a half page
 [left]                         * scroll left
 [right]                        * scroll right
 [ctrl+left]                    * scroll left half screen
 [ctrl+right]                   * scroll right half screen
 [alt+left]                     * scroll left specified width
 [alt+right]                    * scroll right specified width
 [shift+Home]                   * go to beginning of line
 [shift+End]                    * go to end of line
 [g]                            * go to line(input number or `.n` or `n%` allowed)
 [,]                            * go to mark number(input number allowed)

	Sidebar
 [alt+h]                        * show/hide help in sidebar
 [alt+m]                        * show mark list in sidebar
 [alt+l]                        * show document list in sidebar
 [shift+Up]                     * scroll up in sidebar
 [shift+Down]                   * scroll down in sidebar
 [shift+Left]                   * scroll left in sidebar
 [shift+Right]                  * scroll right in sidebar

	Move document
 []]                            * next document
 [[]                            * previous document
 [ctrl+k]                       * close current document
 [K]                            * close all filtered documents

	Mark position
 [m]                            * mark current position
 [M]                            * remove mark current position
 [ctrl+delete]                  * remove all mark
 [>]                            * move to next marked position
 [<]                            * move to previous marked position
 [*]                            * mark by pattern mode

	Search
 [/]                            * forward search mode
 [?]                            * backward search mode
 [n]                            * repeat forward search
 [N]                            * repeat backward search
 [&]                            * filter search mode

	Change display
 [w], [W]                       * wrap/nowrap toggle
 [c]                            * column mode toggle
 [alt+o]                        * column width toggle
 [ctrl+r]                       * column rainbow toggle
 [C]                            * alternate rows of style toggle
 [G]                            * line number toggle
 [ctrl+e]                       * original decoration toggle(plain)
 [alt+f]                        * align columns
 [alt+r]                        * raw output
 [alt+shift+F9]                 * ruler toggle
 [ctrl+F10]                     * status line toggle

	Change Display with Input
 [p], [P]                       * view mode selection
 [d]                            * column delimiter string
 [H]                            * number of header lines
 [ctrl+s]                       * number of skip lines
 [t]                            * TAB width
 [.]                            * multi color highlight
 [j]                            * jump target(`.n` or `n%` or `section` allowed)
 [alt+t]                        * convert type selection
 [y]                            * number of vertical header
 [Y]                            * number of header column

	Column operation
 [F]                            * header column fixed toggle
 [s]                            * shrink column toggle(align mode only)
 [alt+a]                        * right align column toggle(align mode only)

	Section operation
 [alt+d]                        * section delimiter regular expression
 [ctrl+F3], [alt+s]             * section start position
 [space]                        * next section
 [^]                            * previous section
 [9]                            * last section
 [F2]                           * follow section mode toggle
 [F7]                           * number of section header lines
 [alt+-]                        * hide "other" section toggle

	Close and reload
 [ctrl+F9], [ctrl+alt+s]        * close file
 [F5], [ctrl+alt+l]             * reload file
 [F4], [ctrl+alt+w]             * watch mode
 [ctrl+w]                       * set watch interval

	Key binding when typing
 [alt+c]                        * case-sensitive toggle
 [alt+s]                        * smart case-sensitive toggle
 [alt+r]                        * regular expression search toggle
 [alt+i]                        * incremental search toggle
 [!]                            * non-match toggle
 [Up]                           * previous candidate
 [Down]                         * next candidate
 [ctrl+c]                       * copy to clipboard
 [ctrl+v]                       * paste from clipboard

"#;

const TAKES_VALUE: &[&str] = &[
    "--caption", "--column-delimiter", "--completion", "--config", "--converter",
    "--exit-write-after", "--exit-write-before", "--filter", "--header",
    "--header-column", "--hscroll-width", "--jump-target", "--memory-limit",
    "--memory-limit-file", "--multi-color", "--non-match-filter", "--notify-eof",
    "--pattern", "--ruler", "--section-delimiter", "--section-header-num",
    "--section-start", "--skip-lines", "--tab-width", "--vertical-header",
    "--view-mode", "--watch",
];

const BOOL_FLAGS: &[&str] = &[
    "--align", "--alternate-rows", "--case-sensitive", "--column-mode",
    "--column-rainbow", "--column-width", "--debug", "--disable-column-cycle",
    "--disable-mouse", "--exec", "--exit-write", "--follow-all", "--follow-mode",
    "--follow-name", "--follow-section", "--force-screen", "--help-key",
    "--hide-other-section", "--incsearch", "--line-number", "--list-view-modes",
    "--plain", "--quit-if-one-screen", "--raw", "--regexp-search",
    "--section-header", "--set-terminal-title", "--skip-extract",
    "--smart-case-sensitive", "--status-line", "--version", "--wrap",
];

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    let mut files = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let arg = args[i].clone();
        if arg == "__complete" || arg == "__completeNoDesc" {
            shell_complete(&arg, &args[i + 1..]);
            return;
        } else if arg == "--" {
            files.extend(args.drain(i + 1..));
            break;
        } else if arg == "-h" || arg == "--help" {
            print!("{HELP}");
            return;
        } else if arg == "-v" || arg == "--version" {
            println!("ov version dev rev:HEAD");
            return;
        } else if arg == "--help-key" {
            print!("{HELP_KEY}");
            return;
        } else if arg == "--list-view-modes" {
            println!("general");
            return;
        } else if arg == "--completion" {
            if let Some(shell) = args.get(i + 1) {
                completion(shell);
                return;
            } else {
                eprintln!("Error: flag needs an argument: --completion");
                process::exit(1);
            }
        } else if let Some(shell) = arg.strip_prefix("--completion=") {
            completion(shell);
            return;
        } else if let Some(name) = arg.strip_prefix("--") {
            let flag = format!("--{}", name.split('=').next().unwrap_or(""));
            if TAKES_VALUE.contains(&flag.as_str()) {
                let value = if let Some((_, v)) = arg.split_once('=') {
                    Some(v.to_string())
                } else {
                    args.get(i + 1).cloned()
                };
                if value.is_none() {
                    eprintln!("Error: flag needs an argument: {}", flag);
                    process::exit(1);
                }
                if let Some(v) = value.as_deref() {
                    if is_int_flag(&flag) && v.parse::<i64>().is_err() {
                        eprintln!(
                            "Error: invalid argument \"{}\" for \"{}\" flag: strconv.ParseInt: parsing \"{}\": invalid syntax",
                            v,
                            flag_display(&flag),
                            v
                        );
                        process::exit(1);
                    }
                }
                if flag == "--config" {
                    if let Some(v) = value {
                        if !(v.ends_with(".yaml") || v.ends_with(".yml") || v.ends_with(".toml") || v.ends_with(".json")) {
                            eprintln!("failed to read config file: Unsupported Config Type \"\"");
                        } else if File::open(&v).is_err() {
                            eprintln!("failed to read config file: open {}: no such file or directory", v);
                        }
                    }
                }
                if !arg.contains('=') {
                    i += 1;
                }
            } else if BOOL_FLAGS.contains(&flag.as_str()) {
                if flag == "--debug" {
                    eprintln!("failed to read config file: Config File \"config\" Not Found in \"[/home/agent/.config/ov]\"");
                    eprintln!("config file not found");
                }
                // Optional boolean forms such as --wrap=false are accepted.
            } else {
                eprintln!("Error: unknown flag: --{}", name);
                process::exit(1);
            }
        } else if arg.starts_with('-') && arg.len() > 1 {
            match arg.as_str() {
                "-l" | "-C" | "-i" | "-c" | "-e" | "-X" | "-A" | "-f" | "-n" | "-p" | "-F" | "-r" | "-v" | "-h" => {}
                "-w" => {}
                _ => {
                    let rest = arg.trim_start_matches('-');
                    let ch = rest.chars().next().unwrap_or_default();
                    if is_short_value(ch) {
                        let inline = &rest[ch.len_utf8()..];
                        let value = if inline.is_empty() {
                            args.get(i + 1).cloned()
                        } else {
                            Some(inline.to_string())
                        };
                        let Some(v) = value else {
                            eprintln!("Error: flag needs an argument: '{}' in {}", ch, arg);
                            process::exit(1);
                        };
                        if is_short_int(ch) && v.parse::<i64>().is_err() {
                            eprintln!(
                                "Error: invalid argument \"{}\" for \"{}\" flag: strconv.ParseInt: parsing \"{}\": invalid syntax",
                                v,
                                short_display(ch),
                                v
                            );
                            process::exit(1);
                        }
                        if inline.is_empty() {
                            i += 1;
                        }
                    } else {
                        eprintln!("Error: unknown shorthand flag: '{}' in {}", ch, arg);
                        process::exit(1);
                    }
                }
            }
        } else {
            files.push(arg);
        }
        i += 1;
    }

    if files.is_empty() {
        let mut stdin = io::stdin().lock();
        let mut stdout = io::stdout().lock();
        let _ = io::copy(&mut stdin, &mut stdout);
        return;
    }

    for path in files {
        match File::open(&path) {
            Ok(mut f) => {
                let _ = io::copy(&mut f, &mut io::stdout().lock());
                break;
            }
            Err(e) => {
                let msg = if e.kind() == io::ErrorKind::NotFound {
                    "no such file or directory".to_string()
                } else {
                    e.to_string()
                };
                eprintln!("Error: open {}: {}", path, msg);
                process::exit(1);
            }
        }
    }
}

fn completion(shell: &str) {
    match shell {
        "bash" => print_completion("bash"),
        "zsh" => print_completion("zsh"),
        "fish" => print_completion("fish"),
        "powershell" => print_completion("powershell"),
        _ => {
            eprintln!("Error: requires one of the arguments bash/zsh/fish/powershell");
            process::exit(1);
        }
    }
}

fn print_completion(shell: &str) {
    match shell {
        "bash" => print!("{}", include_str!("../completions/bash")),
        "zsh" => print!("{}", include_str!("../completions/zsh")),
        "fish" => print!("{}", include_str!("../completions/fish")),
        "powershell" => print!("{}", include_str!("../completions/powershell")),
        _ => {}
    }
}

fn shell_complete(cmd: &str, rest: &[String]) {
    if rest.is_empty() {
        eprintln!("Error: requires at least 1 arg(s), only received 0");
        process::exit(1);
    }
    if rest.first().map(String::as_str) == Some("--completion") && rest.len() > 1 {
        println!("bash");
        println!("zsh");
        println!("fish");
        println!("powershell");
        println!(":4");
        eprintln!("Completion ended with directive: ShellCompDirectiveNoFileComp");
        return;
    }
    if rest.first().map(String::as_str) == Some("--completion") {
        if cmd == "__completeNoDesc" {
            println!("--completion");
        } else {
            println!("--completion\tgenerate completion script [bash|zsh|fish|powershell]");
        }
        println!(":4");
        eprintln!("Completion ended with directive: ShellCompDirectiveNoFileComp");
        return;
    }
    if cmd == "__completeNoDesc" {
        print!("{}", include_str!("../completions/complete_nodesc"));
    } else {
        print!("{}", include_str!("../completions/complete_desc"));
    }
}

fn is_int_flag(flag: &str) -> bool {
    matches!(
        flag,
        "--exit-write-after"
            | "--exit-write-before"
            | "--header"
            | "--header-column"
            | "--memory-limit"
            | "--memory-limit-file"
            | "--notify-eof"
            | "--ruler"
            | "--section-header-num"
            | "--section-start"
            | "--skip-lines"
            | "--tab-width"
            | "--vertical-header"
            | "--watch"
    )
}

fn flag_display(flag: &str) -> &'static str {
    match flag {
        "--exit-write-after" => "-a, --exit-write-after",
        "--exit-write-before" => "-b, --exit-write-before",
        "--header" => "-H, --header",
        "--header-column" => "-Y, --header-column",
        "--multi-color" => "-M, --multi-color",
        "--tab-width" => "-x, --tab-width",
        "--vertical-header" => "-y, --vertical-header",
        "--view-mode" => "-m, --view-mode",
        "--watch" => "-T, --watch",
        _ => Box::leak(flag.to_string().into_boxed_str()),
    }
}

fn is_short_value(ch: char) -> bool {
    matches!(ch, 'd' | 'a' | 'b' | 'H' | 'Y' | 'j' | 'M' | 'x' | 'y' | 'm' | 'T')
}

fn is_short_int(ch: char) -> bool {
    matches!(ch, 'a' | 'b' | 'H' | 'Y' | 'x' | 'y' | 'T')
}

fn short_display(ch: char) -> &'static str {
    match ch {
        'a' => "-a, --exit-write-after",
        'b' => "-b, --exit-write-before",
        'H' => "-H, --header",
        'Y' => "-Y, --header-column",
        'M' => "-M, --multi-color",
        'x' => "-x, --tab-width",
        'y' => "-y, --vertical-header",
        'm' => "-m, --view-mode",
        'T' => "-T, --watch",
        'd' => "-d, --column-delimiter",
        'j' => "-j, --jump-target",
        _ => "",
    }
}
