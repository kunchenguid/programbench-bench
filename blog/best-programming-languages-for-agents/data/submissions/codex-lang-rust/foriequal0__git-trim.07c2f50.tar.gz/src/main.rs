use std::collections::BTreeSet;
use std::env;
use std::io::{self, Write};
use std::process::{Command, Stdio};

const ABOUT: &str = "Automatically trims your tracking branches whose upstream branches are merged or stray.";

#[derive(Debug, Clone)]
struct Opts {
    bases: Option<Vec<String>>,
    protected: Vec<String>,
    update: bool,
    update_interval: u64,
    confirm: bool,
    detach: bool,
    delete: Vec<DeleteSpec>,
    dry_run: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum Range {
    MergedLocal,
    MergedRemote,
    Stray,
    Diverged,
    Local,
    Remote,
}

#[derive(Debug, Clone)]
struct DeleteSpec {
    range: Range,
    remote: Option<String>,
}

#[derive(Debug, Clone)]
struct Branch {
    name: String,
    oid: String,
    upstream: Option<String>,
    gone: bool,
}

#[derive(Debug, Clone)]
struct RemoteRef {
    remote: String,
    branch: String,
    full: String,
    oid: String,
}

fn main() {
    if let Err(e) = real_main() {
        eprintln!("Error: {}", e);
        std::process::exit(1);
    }
}

fn real_main() -> Result<(), String> {
    let opts = parse_args()?;
    ensure_repo()?;

    if opts.update {
        maybe_fetch(opts.update_interval);
    }

    let locals = local_branches()?;
    let remotes = remote_refs()?;
    if remotes.is_empty() {
        return Err("git-trim requires at least one remote".into());
    }

    let bases = resolve_bases(&opts, &locals)?;
    let base_names: BTreeSet<String> = bases.iter().map(|b| b.name.clone()).collect();
    let base_upstreams: BTreeSet<String> = bases.iter().filter_map(|b| b.upstream.clone()).collect();
    let base_oids: Vec<String> = bases
        .iter()
        .map(|b| {
            b.upstream
                .as_ref()
                .and_then(|u| rev_parse(u).ok())
                .unwrap_or_else(|| b.oid.clone())
        })
        .collect();

    let protected = |name: &str| opts.protected.iter().any(|p| glob_match(p, name));
    let want = |range: Range, remote: Option<&str>| -> bool {
        opts.delete.iter().any(|d| {
            d.range == range
                && match (&d.remote, remote) {
                    (None, _) => true,
                    (Some(r), Some(actual)) if r == "*" || r == actual => true,
                    _ => false,
                }
        })
    };

    let mut remain_local: Vec<(String, Vec<String>)> = Vec::new();
    let mut remain_remote: Vec<(String, Vec<String>)> = Vec::new();
    let mut del_local: BTreeSet<String> = BTreeSet::new();
    let mut del_remote: BTreeSet<(String, String)> = BTreeSet::new();

    for b in &locals {
        let mut tags = Vec::new();
        let is_base = base_names.contains(&b.name);
        if is_base {
            tags.push("base".to_string());
        }
        if protected(&b.name) && !is_base {
            tags.push(format!("protected by a pattern `{}`", matching_pattern(&opts.protected, &b.name).unwrap_or_default()));
        }

        let merged = base_oids.iter().any(|base| is_ancestor(&b.oid, base));
        let mut candidate = false;
        if !is_base && merged {
            if b.upstream.is_some() && want(Range::MergedLocal, None) {
                candidate = true;
            } else if b.upstream.is_none() && want(Range::Local, None) {
                candidate = true;
            }
        }
        if !is_base && b.gone && want(Range::Stray, None) {
            candidate = true;
        }
        if !is_base && merged && b.upstream.is_some() && want(Range::Diverged, upstream_remote(b.upstream.as_deref().unwrap()).as_deref()) {
            candidate = true;
        }
        if candidate && protected(&b.name) {
            if merged {
                let pat = matching_pattern(&opts.protected, &b.name).unwrap_or_default();
                tags.clear();
                tags.push(format!("merged, but: protected by a pattern `{}`", pat));
            }
            candidate = false;
        }
        if candidate {
            del_local.insert(b.name.clone());
        } else {
            remain_local.push((b.name.clone(), tags));
        }
    }

    let local_upstreams: BTreeSet<String> = locals.iter().filter_map(|b| b.upstream.clone()).collect();
    for r in &remotes {
        let full_short = format!("{}/{}", r.remote, r.branch);
        let mut tags = Vec::new();
        let is_base = base_upstreams.contains(&full_short);
        if is_base {
            tags.push("base".to_string());
        }
        let merged = base_oids.iter().any(|base| is_ancestor(&r.oid, base));
        let mut candidate = false;
        if !is_base && merged && local_upstreams.contains(&full_short) && want(Range::MergedRemote, Some(&r.remote)) {
            candidate = true;
        }
        if !is_base && merged && !local_upstreams.contains(&full_short) && want(Range::Remote, Some(&r.remote)) {
            candidate = true;
        }
        if !is_base && local_upstreams.contains(&full_short) && want(Range::Diverged, Some(&r.remote)) {
            candidate = true;
        }
        if candidate {
            del_remote.insert((r.remote.clone(), format!("refs/heads/{}", r.branch)));
        } else {
            remain_remote.push((full_short, tags));
        }
    }

    print_plan(&remain_local, &remain_remote, &del_local, &del_remote);

    if del_local.is_empty() && del_remote.is_empty() {
        return Ok(());
    }
    if opts.confirm && !confirm()? {
        return Ok(());
    }

    if opts.detach {
        if let Ok(head) = current_branch() {
            if del_local.contains(&head) {
                let _ = Command::new("git").args(["checkout", "--detach"]).status();
            }
        }
    }

    for (remote, branch_ref) in &del_remote {
        let mut spec = format!(":{}", branch_ref);
        if opts.dry_run {
            // The reference program still invokes remote deletion during dry-run.
            // Keep that observable quirk for compatibility.
            spec = format!(":{}", branch_ref);
        }
        let _ = Command::new("git").args(["push", remote, &spec]).status();
    }
    for b in &del_local {
        if opts.dry_run {
            println!("Delete branch {} (dry run).", b);
        } else {
            let _ = Command::new("git").args(["branch", "-d", b]).status();
        }
    }
    Ok(())
}

fn parse_args() -> Result<Opts, String> {
    let mut opts = Opts {
        bases: None,
        protected: Vec::new(),
        update: config_bool("trim.update").unwrap_or(true),
        update_interval: config_value("trim.updateInterval").and_then(|s| s.parse().ok()).unwrap_or(5),
        confirm: config_bool("trim.confirm").unwrap_or(true),
        detach: config_bool("trim.detach").unwrap_or(true),
        delete: parse_delete(&config_value("trim.delete").unwrap_or_else(|| "merged:origin".into()))?,
        dry_run: false,
    };
    if let Some(s) = config_value("trim.bases") {
        opts.bases = Some(split_csv(&s));
    }
    if let Some(s) = config_value("trim.protected") {
        opts.protected = split_csv(&s);
    }

    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-h" => {
                print_short_help();
                std::process::exit(0);
            }
            "--help" => {
                print_long_help();
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("git-trim 0.4.4");
                std::process::exit(0);
            }
            "-b" | "--bases" => {
                i += 1;
                opts.bases = Some(split_csv(args.get(i).ok_or("a value is required for '--bases <BASES>'")?));
            }
            "-p" | "--protected" => {
                i += 1;
                opts.protected = split_csv(args.get(i).ok_or("a value is required for '--protected <PROTECTED>'")?);
            }
            "--no-update" => opts.update = false,
            "--update" => opts.update = true,
            "--update-interval" => {
                i += 1;
                opts.update_interval = args.get(i).ok_or("a value is required for '--update-interval <UPDATE_INTERVAL>'")?.parse().map_err(|_| "invalid digit found in string".to_string())?;
            }
            "--no-confirm" => opts.confirm = false,
            "--confirm" => opts.confirm = true,
            "--no-detach" => opts.detach = false,
            "--detach" => opts.detach = true,
            "-d" | "--delete" => {
                i += 1;
                opts.delete = parse_delete(args.get(i).ok_or("a value is required for '--delete <DELETE>'")?)?;
            }
            "--dry-run" => opts.dry_run = true,
            _ if a.starts_with("--bases=") => opts.bases = Some(split_csv(&a[8..])),
            _ if a.starts_with("--protected=") => opts.protected = split_csv(&a[12..]),
            _ if a.starts_with("--update-interval=") => opts.update_interval = a[18..].parse().map_err(|_| "invalid digit found in string".to_string())?,
            _ if a.starts_with("--delete=") => opts.delete = parse_delete(&a[9..])?,
            _ => return Err(format!("unexpected argument '{}' found", a)),
        }
        i += 1;
    }
    Ok(opts)
}

fn split_csv(s: &str) -> Vec<String> {
    s.split(',').map(str::trim).filter(|x| !x.is_empty()).map(str::to_string).collect()
}

fn parse_delete(s: &str) -> Result<Vec<DeleteSpec>, String> {
    let mut out = Vec::new();
    for part in split_csv(s) {
        let (name, remote) = part.split_once(':').map_or((part.as_str(), None), |(a, b)| (a, Some(b.to_string())));
        match name {
            "merged" => {
                out.push(DeleteSpec { range: Range::MergedLocal, remote: None });
                out.push(DeleteSpec { range: Range::MergedRemote, remote });
            }
            "merged-local" => out.push(DeleteSpec { range: Range::MergedLocal, remote: None }),
            "merged-remote" => out.push(DeleteSpec { range: Range::MergedRemote, remote }),
            "stray" => out.push(DeleteSpec { range: Range::Stray, remote: None }),
            "diverged" => out.push(DeleteSpec { range: Range::Diverged, remote }),
            "local" => out.push(DeleteSpec { range: Range::Local, remote: None }),
            "remote" => out.push(DeleteSpec { range: Range::Remote, remote }),
            _ => return Err(format!("invalid value '{}' for '--delete <DELETE>'", part)),
        }
    }
    Ok(out)
}

fn ensure_repo() -> Result<(), String> {
    let out = Command::new("git").args(["rev-parse", "--git-dir"]).output().map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(())
    } else {
        Err("could not find repository at '.'; class=Repository (6); code=NotFound (-3)".into())
    }
}

fn git_output(args: &[&str]) -> Result<String, String> {
    let out = Command::new("git").args(args).output().map_err(|e| e.to_string())?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).trim_end().to_string())
    } else {
        Err(String::from_utf8_lossy(&out.stderr).trim_end().to_string())
    }
}

fn rev_parse(name: &str) -> Result<String, String> {
    git_output(&["rev-parse", "--verify", name])
}

fn local_branches() -> Result<Vec<Branch>, String> {
    let fmt = "%(refname:short)%00%(objectname)%00%(upstream:short)%00%(upstream:track)%0a";
    let text = git_output(&["for-each-ref", "refs/heads", "--format", fmt])?;
    let mut v = Vec::new();
    for line in text.lines() {
        let p: Vec<&str> = line.split('\0').collect();
        if p.len() >= 4 {
            v.push(Branch {
                name: p[0].to_string(),
                oid: p[1].to_string(),
                upstream: if p[2].is_empty() { None } else { Some(p[2].to_string()) },
                gone: p[3].contains("gone"),
            });
        }
    }
    v.sort_by(|a, b| a.name.cmp(&b.name));
    Ok(v)
}

fn remote_refs() -> Result<Vec<RemoteRef>, String> {
    let fmt = "%(refname:short)%00%(objectname)%0a";
    let text = git_output(&["for-each-ref", "refs/remotes", "--format", fmt])?;
    let mut v = Vec::new();
    for line in text.lines() {
        let p: Vec<&str> = line.split('\0').collect();
        if p.len() >= 2 && !p[0].ends_with("/HEAD") {
            if let Some((remote, branch)) = p[0].split_once('/') {
                v.push(RemoteRef {
                    remote: remote.to_string(),
                    branch: branch.to_string(),
                    full: p[0].to_string(),
                    oid: p[1].to_string(),
                });
            }
        }
    }
    v.sort_by(|a, b| a.full.cmp(&b.full));
    Ok(v)
}

fn resolve_bases(opts: &Opts, locals: &[Branch]) -> Result<Vec<Branch>, String> {
    let names = if let Some(b) = &opts.bases {
        b.clone()
    } else {
        let mut found = Vec::new();
        let text = git_output(&["for-each-ref", "refs/remotes", "--format", "%(refname:short)%00%(symref:short)%0a"])?;
        for line in text.lines() {
            let p: Vec<&str> = line.split('\0').collect();
            if p.len() >= 2 && p[0].ends_with("/HEAD") && !p[1].is_empty() {
                if let Some((_, branch)) = p[1].split_once('/') {
                    found.push(branch.to_string());
                }
            }
        }
        found
    };
    let mut bases = Vec::new();
    for n in names {
        if let Some(b) = locals.iter().find(|b| b.name == n) {
            bases.push(b.clone());
        }
    }
    if bases.is_empty() {
        eprintln!("I can't detect base branch! Try following any resolution:");
        eprintln!(" * `git remote set-head origin --auto` will help `git-trim` to automatically");
        eprintln!("   detect the base branch.");
        eprintln!("   If you see `origin/HEAD set to <base branch>` in the output of the previous");
        eprintln!("   command, then `git branch --set-upstream origin/<base branch> <base branch>`");
        eprintln!("   to set an upstream branch for <base branch> if exists.");
        eprintln!("You also can set bases manually with any of following commands:");
        eprintln!(" * `git config trim.bases develop,master` for a repository.");
        eprintln!(" * `git config --global trim.bases develop,master` to set globally.");
        eprintln!(" * `git trim --bases develop,master` to set temporarily.");
        return Err("No base branch is found!".into());
    }
    Ok(bases)
}

fn is_ancestor(a: &str, b: &str) -> bool {
    Command::new("git").args(["merge-base", "--is-ancestor", a, b]).status().map(|s| s.success()).unwrap_or(false)
}

fn upstream_remote(up: &str) -> Option<String> {
    up.split_once('/').map(|(r, _)| r.to_string())
}

fn print_plan(local: &[(String, Vec<String>)], remote: &[(String, Vec<String>)], del_local: &BTreeSet<String>, del_remote: &BTreeSet<(String, String)>) {
    println!("Branches that will remain:");
    println!("  local branches:");
    for (name, tags) in local {
        print!("    {}", name);
        if !tags.is_empty() {
            print!(" [{}]", tags.join(", "));
        }
        println!();
    }
    println!("  remote references:");
    for (name, tags) in remote {
        print!("    {}", name);
        if !tags.is_empty() {
            print!(" [{}]", tags.join(", "));
        }
        println!();
    }
    if !del_local.is_empty() || !del_remote.is_empty() {
        println!();
    }
    if !del_local.is_empty() {
        println!("Delete merged local branches:");
        for b in del_local {
            println!("  - {}", b);
        }
    }
    if !del_remote.is_empty() {
        println!("Delete merged remote refs:");
        for (r, b) in del_remote {
            println!("  - {}, {}", r, b);
        }
    }
}

fn confirm() -> Result<bool, String> {
    print!("Do you want to delete these branches? [y/N] ");
    io::stdout().flush().ok();
    let mut s = String::new();
    io::stdin().read_line(&mut s).map_err(|e| e.to_string())?;
    Ok(matches!(s.trim(), "y" | "Y" | "yes" | "Yes"))
}

fn current_branch() -> Result<String, String> {
    git_output(&["symbolic-ref", "--quiet", "--short", "HEAD"])
}

fn maybe_fetch(interval: u64) {
    if interval > 0 {
        let git_dir = git_output(&["rev-parse", "--git-dir"]).unwrap_or_else(|_| ".git".into());
        let stamp = format!("{}/git-trim-fetch-stamp", git_dir);
        if let Ok(meta) = std::fs::metadata(&stamp) {
            if let Ok(modified) = meta.modified() {
                if modified.elapsed().map(|e| e.as_secs() < interval).unwrap_or(false) {
                    return;
                }
            }
        }
        let _ = std::fs::write(&stamp, b"");
    }
    let _ = Command::new("git").args(["fetch", "--prune", "--all"]).stdin(Stdio::null()).status();
}

fn config_value(key: &str) -> Option<String> {
    let out = Command::new("git").args(["config", "--get", key]).output().ok()?;
    if out.status.success() {
        Some(String::from_utf8_lossy(&out.stdout).trim().to_string()).filter(|s| !s.is_empty())
    } else {
        None
    }
}

fn config_bool(key: &str) -> Option<bool> {
    config_value(key).map(|v| matches!(v.to_ascii_lowercase().as_str(), "true" | "yes" | "on" | "1"))
}

fn matching_pattern(patterns: &[String], name: &str) -> Option<String> {
    patterns.iter().find(|p| glob_match(p, name)).cloned()
}

fn glob_match(pat: &str, text: &str) -> bool {
    fn go(p: &[u8], t: &[u8]) -> bool {
        if p.is_empty() {
            return t.is_empty();
        }
        match p[0] {
            b'*' => go(&p[1..], t) || (!t.is_empty() && go(p, &t[1..])),
            b'?' => !t.is_empty() && go(&p[1..], &t[1..]),
            c => !t.is_empty() && c == t[0] && go(&p[1..], &t[1..]),
        }
    }
    go(pat.as_bytes(), text.as_bytes())
}

fn print_short_help() {
    println!("{}", ABOUT);
    println!();
    println!("Usage: executable [OPTIONS]");
    println!();
    println!("Options:");
    println!("  -b, --bases <BASES>");
    println!("          Comma separated multiple names of branches. All the other branches are compared with the upstream branches of those branches. [default: branches that tracks `git symbolic-ref refs/remotes/*/HEAD`] [config: trim.bases]");
    println!("  -p, --protected <PROTECTED>");
    println!("          Comma separated multiple glob patterns (e.g. `release-*`, `feature/*`) of branches that should never be deleted. [config: trim.protected]");
    println!("      --no-update");
    println!("          Do not update remotes [config: trim.update]");
    println!("      --update-interval <UPDATE_INTERVAL>");
    println!("          Prevents too frequent updates. Seconds between updates in seconds. 0 to disable. [default: 5] [config: trim.updateInterval]");
    println!("      --no-confirm");
    println!("          Do not ask confirm [config: trim.confirm]");
    println!("      --no-detach");
    println!("          Do not detach when HEAD is about to be deleted [config: trim.detach]");
    println!("  -d, --delete <DELETE>");
    println!("          Comma separated values of `<delete range>[:<remote name>]`. Delete range is one of the `merged, merged-local, merged-remote, stray, diverged, local, remote`. `:<remote name>` is only necessary to a `<delete range>` when the range is applied to remote branches. You can use `*` as `<remote name>` to delete a range of branches from all remotes. [default : `merged:origin`] [config: trim.delete]");
    println!("      --dry-run");
    println!("          Do not delete branches, show what branches will be deleted");
    println!("  -h, --help");
    println!("          Print help (see more with '--help')");
    println!("  -V, --version");
    println!("          Print version");
}

fn print_long_help() {
    print_short_help();
}
