use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

const VERSION_TEXT: &str = "FIGlet Copyright (C) 1991-2012 Glenn Chappell, Ian Chai, John Cowan,\nChristiaan Keet and Claudio Matsuoka\nInternet: <info@figlet.org> Version: 2.2.5, date: 31 May 2012\n\nFIGlet, along with the various FIGlet fonts and documentation, may be\nfreely copied and distributed.\n\nIf you use FIGlet, please send an e-mail message to <info@figlet.org>.\n\nThe latest version of FIGlet is available from the web site,\n\thttp://www.figlet.org/\n\n";
const USAGE: &str = "Usage: executable [ -cklnoprstvxDELNRSWX ] [ -d fontdirectory ]\n              [ -f fontfile ] [ -m smushmode ] [ -w outputwidth ]\n              [ -C controlfile ] [ -I infocode ] [ message ]";

#[derive(Clone)]
struct Glyph {
    rows: Vec<String>,
    width: usize,
}

struct Font {
    hardblank: char,
    height: usize,
    old_layout: i32,
    full_layout: i32,
    print_direction: i32,
    glyphs: HashMap<u32, Glyph>,
}

#[derive(Clone, Copy, PartialEq)]
enum Layout {
    Full,
    Kern,
    Smush(i32),
    Overlap,
}

#[derive(Clone, Copy, PartialEq)]
enum Justify {
    Left,
    Center,
    Right,
    Auto,
}

struct Options {
    font_dir: String,
    font_name: String,
    width: usize,
    layout: Option<Layout>,
    justify: Justify,
    direction: Option<i32>,
    paragraph: bool,
    info: i32,
    message: Vec<String>,
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err(msg) => {
            eprintln!("{}", msg);
            eprintln!("{}", USAGE);
            std::process::exit(1);
        }
    };

    if opts.info >= 0 {
        print_info(&opts);
        return;
    }

    let font = match load_font(&opts.font_dir, &opts.font_name) {
        Ok(f) => f,
        Err(_) => {
            eprintln!("executable: {}: Unable to open font file", opts.font_name);
            std::process::exit(1);
        }
    };

    let mut input = if !opts.message.is_empty() {
        let mut s = String::new();
        for (i, arg) in opts.message.iter().enumerate() {
            if i > 0 {
                s.push(' ');
            }
            if arg.is_empty() {
                s.push('\n');
            } else {
                s.push_str(arg);
            }
        }
        s
    } else {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).unwrap();
        s
    };
    if opts.paragraph {
        input = paragraphize(&input);
    }

    let dir = opts.direction.unwrap_or(font.print_direction);
    let justify = match opts.justify {
        Justify::Auto if dir == 1 => Justify::Right,
        Justify::Auto => Justify::Left,
        x => x,
    };
    let layout = opts.layout.unwrap_or_else(|| default_layout(&font));

    let logical_lines: Vec<&str> = input.split('\n').collect();
    for (li, line) in logical_lines.iter().enumerate() {
        if li == logical_lines.len() - 1 && line.is_empty() && input.ends_with('\n') {
            break;
        }
        let mut rows = render_line(line, &font, layout, opts.width, dir == 1);
        for row in rows.drain(..) {
            let row = row.replace(font.hardblank, " ");
            println!("{}", apply_justify(&row, opts.width, justify));
        }
    }
}

fn parse_args() -> Result<Options, String> {
    let mut opts = Options {
        font_dir: "/usr/local/share/figlet".to_string(),
        font_name: "standard".to_string(),
        width: 80,
        layout: None,
        justify: Justify::Auto,
        direction: None,
        paragraph: false,
        info: -1,
        message: Vec::new(),
    };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--help" {
            return Err("./executable: invalid option -- '-'".to_string());
        }
        if !arg.starts_with('-') || arg == "-" {
            opts.message.extend(args[i..].iter().cloned());
            break;
        }
        let chars: Vec<char> = arg.chars().collect();
        let mut pos = 1;
        while pos < chars.len() {
            let c = chars[pos];
            match c {
                'd' | 'f' | 'm' | 'w' | 'C' | 'I' => {
                    let value = if pos + 1 < chars.len() {
                        chars[pos + 1..].iter().collect::<String>()
                    } else {
                        i += 1;
                        if i >= args.len() {
                            return Err(format!("./executable: option requires an argument -- '{}'", c));
                        }
                        args[i].clone()
                    };
                    match c {
                        'd' => opts.font_dir = value,
                        'f' => opts.font_name = trim_font_suffix(&value),
                        'm' => {
                            let m = value.parse::<i32>().unwrap_or(-999);
                            opts.layout = Some(match m {
                                -1 => Layout::Full,
                                0 => Layout::Kern,
                                -2 => Layout::Smush(-1),
                                1..=63 => Layout::Smush(m),
                                _ => Layout::Smush(m),
                            });
                        }
                        'w' => opts.width = value.parse::<usize>().unwrap_or(80).max(1),
                        'C' => {}
                        'I' => opts.info = value.parse::<i32>().unwrap_or(0),
                        _ => {}
                    }
                    break;
                }
                'c' => opts.justify = Justify::Center,
                'l' => opts.justify = Justify::Left,
                'r' => opts.justify = Justify::Right,
                'x' => opts.justify = Justify::Auto,
                't' => opts.width = env::var("COLUMNS").ok().and_then(|v| v.parse().ok()).unwrap_or(opts.width),
                'p' => opts.paragraph = true,
                'n' => opts.paragraph = false,
                's' => opts.layout = Some(Layout::Smush(-1)),
                'S' => opts.layout = Some(Layout::Smush(63)),
                'k' => opts.layout = Some(Layout::Kern),
                'W' => opts.layout = Some(Layout::Full),
                'o' => opts.layout = Some(Layout::Overlap),
                'L' => opts.direction = Some(0),
                'R' => opts.direction = Some(1),
                'X' => opts.direction = None,
                'D' | 'E' | 'N' => {}
                'v' => opts.info = 0,
                other => {
                    return Err(format!("./executable: invalid option -- '{}'", other));
                }
            }
            pos += 1;
        }
        i += 1;
    }
    Ok(opts)
}

fn print_info(opts: &Options) {
    match opts.info {
        0 => {
            print!("{}", VERSION_TEXT);
            println!("{}", USAGE);
        }
        1 => println!("20205"),
        2 => println!("{}", opts.font_dir),
        3 => println!("{}", opts.font_name),
        4 => println!("{}", opts.width),
        5 => println!("flf2 tlf2"),
        _ => {}
    }
}

fn trim_font_suffix(s: &str) -> String {
    s.strip_suffix(".flf")
        .or_else(|| s.strip_suffix(".tlf"))
        .unwrap_or(s)
        .to_string()
}

fn load_font(dir: &str, name: &str) -> io::Result<Font> {
    let paths = candidate_paths(dir, name);
    for p in paths {
        if let Ok(data) = fs::read(&p) {
            let text = String::from_utf8_lossy(&data);
            return parse_font(&text);
        }
    }
    Err(io::Error::new(io::ErrorKind::NotFound, "font"))
}

fn candidate_paths(dir: &str, name: &str) -> Vec<PathBuf> {
    let mut v = Vec::new();
    let p = Path::new(name);
    let has_ext = p.extension().is_some();
    if p.is_absolute() || name.contains('/') {
        v.push(PathBuf::from(name));
        if !has_ext {
            v.push(PathBuf::from(format!("{}.flf", name)));
            v.push(PathBuf::from(format!("{}.tlf", name)));
        }
        return v;
    }
    for base in [dir, ".", "fonts", "assets"] {
        let base = Path::new(base);
        v.push(base.join(name));
        if !has_ext {
            v.push(base.join(format!("{}.flf", name)));
            v.push(base.join(format!("{}.tlf", name)));
        }
    }
    v
}

fn parse_font(data: &str) -> io::Result<Font> {
    let mut lines = data.lines();
    let header = lines.next().ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "empty"))?;
    if !header.starts_with("flf2a") && !header.starts_with("tlf2a") {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "bad header"));
    }
    let hardblank = header.chars().nth(5).unwrap_or('$');
    let nums: Vec<i32> = header[6..]
        .split_whitespace()
        .filter_map(|x| x.parse::<i32>().ok())
        .collect();
    if nums.len() < 5 {
        return Err(io::Error::new(io::ErrorKind::InvalidData, "bad header"));
    }
    let height = nums[0].max(1) as usize;
    let old_layout = nums[3];
    let comments = nums[4].max(0) as usize;
    let print_direction = *nums.get(5).unwrap_or(&0);
    let full_layout = *nums.get(6).unwrap_or(&old_layout);
    for _ in 0..comments {
        lines.next();
    }
    let mut glyphs = HashMap::new();
    for code in 32u32..=126 {
        if let Some(g) = read_glyph(&mut lines, height) {
            glyphs.insert(code, g);
        }
    }
    while let Some(line) = lines.next() {
        let t = line.trim();
        if t.is_empty() {
            continue;
        }
        let code = if let Some(hex) = t.strip_prefix("0x") {
            i32::from_str_radix(hex.split_whitespace().next().unwrap_or(""), 16).ok()
        } else {
            t.split_whitespace().next().and_then(|x| x.parse::<i32>().ok())
        };
        if let Some(c) = code {
            if let Some(g) = read_glyph(&mut lines, height) {
                glyphs.insert(c as u32, g);
            }
        }
    }
    Ok(Font { hardblank, height, old_layout, full_layout, print_direction, glyphs })
}

fn read_glyph<'a, I: Iterator<Item = &'a str>>(lines: &mut I, height: usize) -> Option<Glyph> {
    let mut rows = Vec::new();
    for _ in 0..height {
        let raw = lines.next()?;
        let end = raw.chars().last().unwrap_or('@');
        let mut s = raw.to_string();
        while s.ends_with(end) {
            s.pop();
        }
        rows.push(s);
    }
    let width = rows.iter().map(|r| r.chars().count()).max().unwrap_or(0);
    for r in &mut rows {
        let len = r.chars().count();
        if len < width {
            r.push_str(&" ".repeat(width - len));
        }
    }
    Some(Glyph { rows, width })
}

fn default_layout(font: &Font) -> Layout {
    if font.old_layout == -1 {
        Layout::Full
    } else if font.old_layout == 0 {
        Layout::Kern
    } else {
        let mode = if font.old_layout > 0 { font.old_layout & 63 } else { font.full_layout & 63 };
        Layout::Smush(mode)
    }
}

fn render_line(line: &str, font: &Font, layout: Layout, width: usize, rtl: bool) -> Vec<String> {
    let mut chunks: Vec<Vec<String>> = Vec::new();
    let mut rows = empty_rows(font.height);
    let chars: Vec<char> = if rtl { line.chars().rev().collect() } else { line.chars().collect() };
    for ch in chars {
        let glyph = glyph_for(font, ch);
        if width == 1 && ch != ' ' && rows_width(&rows) > 0 {
            chunks.push(rows);
            rows = empty_rows(font.height);
        } else if width > 1 && rows_width(&rows) > 0 {
            let test = append_glyph(rows.clone(), &glyph, font, layout);
            if rows_width(&test) > width {
                chunks.push(finalize_rows(rows, layout, font.hardblank));
                rows = empty_rows(font.height);
            }
        }
        rows = append_glyph(rows, &glyph, font, layout);
    }
    chunks.push(finalize_rows(rows, layout, font.hardblank));
    chunks.into_iter().flat_map(|r| r).collect()
}

fn finalize_rows(mut rows: Vec<String>, layout: Layout, hardblank: char) -> Vec<String> {
    if !matches!(layout, Layout::Full) {
        trim_common_left(&mut rows, hardblank);
    }
    rows
}

fn trim_common_left(rows: &mut [String], hardblank: char) {
    let min = rows
        .iter()
        .map(|r| r.chars().take_while(|c| *c == ' ' || *c == hardblank).count())
        .min()
        .unwrap_or(0);
    if min == 0 {
        return;
    }
    for r in rows {
        *r = r.chars().skip(min).collect();
    }
}

fn empty_rows(h: usize) -> Vec<String> {
    vec![String::new(); h]
}

fn rows_width(rows: &[String]) -> usize {
    rows.iter().map(|r| r.chars().count()).max().unwrap_or(0)
}

fn glyph_for(font: &Font, ch: char) -> Glyph {
    font.glyphs
        .get(&(ch as u32))
        .or_else(|| font.glyphs.get(&(b'?' as u32)))
        .or_else(|| font.glyphs.get(&(b' ' as u32)))
        .cloned()
        .unwrap_or_else(|| Glyph { rows: vec![ch.to_string(); font.height], width: 1 })
}

fn append_glyph(mut left: Vec<String>, right: &Glyph, font: &Font, layout: Layout) -> Vec<String> {
    if rows_width(&left) == 0 {
        return right.rows.clone();
    }
    let overlap = match layout {
        Layout::Full => 0,
        Layout::Kern => max_overlap(&left, right, font, Layout::Kern),
        Layout::Smush(mode) => max_overlap(&left, right, font, Layout::Smush(mode)),
        Layout::Overlap => max_overlap(&left, right, font, Layout::Overlap),
    };
    for i in 0..left.len() {
        left[i] = merge_row(&left[i], &right.rows[i], overlap, font, layout);
    }
    left
}

fn max_overlap(left: &[String], right: &Glyph, font: &Font, layout: Layout) -> usize {
    let lw = rows_width(left);
    let rw = right.width;
    let max = lw.min(rw);
    if matches!(layout, Layout::Smush(_) | Layout::Overlap) {
        let kern = max_overlap(left, right, font, Layout::Kern);
        let candidate = (kern + 1).min(max);
        if candidate > 0 && can_overlap(left, right, font, layout, candidate) {
            return candidate;
        }
        return kern;
    }
    for amt in (0..=max).rev() {
        if amt == 0 {
            return 0;
        }
        if can_overlap(left, right, font, layout, amt) {
            return amt;
        }
    }
    0
}

fn can_overlap(left: &[String], right: &Glyph, font: &Font, layout: Layout, amt: usize) -> bool {
    let lw = rows_width(left);
    for i in 0..left.len() {
        let lchars: Vec<char> = left[i].chars().collect();
        let rchars: Vec<char> = right.rows[i].chars().collect();
        for j in 0..amt {
            let lc = *lchars.get(lw - amt + j).unwrap_or(&' ');
            let rc = *rchars.get(j).unwrap_or(&' ');
            if smush_pair(lc, rc, font, layout).is_none() {
                return false;
            }
        }
    }
    true
}

fn merge_row(left: &str, right: &str, overlap: usize, font: &Font, layout: Layout) -> String {
    let l: Vec<char> = left.chars().collect();
    let r: Vec<char> = right.chars().collect();
    if overlap == 0 {
        return format!("{}{}", left, right);
    }
    let lw = l.len();
    let mut out = String::new();
    for c in &l[..lw - overlap] {
        out.push(*c);
    }
    for j in 0..overlap {
        let lc = l[lw - overlap + j];
        let rc = *r.get(j).unwrap_or(&' ');
        out.push(smush_pair(lc, rc, font, layout).unwrap_or(rc));
    }
    for c in &r[overlap..] {
        out.push(*c);
    }
    out
}

fn smush_pair(l: char, r: char, font: &Font, layout: Layout) -> Option<char> {
    if l == ' ' {
        return Some(r);
    }
    if r == ' ' {
        return Some(l);
    }
    match layout {
        Layout::Full => None,
        Layout::Kern => None,
        Layout::Overlap => Some(r),
        Layout::Smush(mode) => {
            let mode = if mode < 0 { font.old_layout & 63 } else { mode };
            if mode == 0 {
                return Some(r);
            }
            if mode & 1 != 0 && l == r && l != font.hardblank {
                return Some(l);
            }
            if mode & 2 != 0 {
                let set = "|/\\[]{}()<>";
                if l == '_' && set.contains(r) {
                    return Some(r);
                }
                if r == '_' && set.contains(l) {
                    return Some(l);
                }
            }
            if mode & 4 != 0 {
                let order = ['|', '/', '\\', '[', ']', '{', '}', '(', ')', '<', '>'];
                if let (Some(a), Some(b)) = (order.iter().position(|&x| x == l), order.iter().position(|&x| x == r)) {
                    return Some(order[a.max(b)]);
                }
            }
            if mode & 8 != 0 {
                match (l, r) {
                    ('[', ']') | (']', '[') | ('{', '}') | ('}', '{') | ('(', ')') | (')', '(') => return Some('|'),
                    _ => {}
                }
            }
            if mode & 16 != 0 {
                match (l, r) {
                    ('/', '\\') => return Some('|'),
                    ('\\', '/') => return Some('Y'),
                    ('>', '<') => return Some('X'),
                    _ => {}
                }
            }
            if mode & 32 != 0 && l == font.hardblank && r == font.hardblank {
                return Some(font.hardblank);
            }
            None
        }
    }
}

fn apply_justify(row: &str, width: usize, justify: Justify) -> String {
    let len = row.chars().count();
    if len >= width {
        return row.to_string();
    }
    let pad = match justify {
        Justify::Left | Justify::Auto => 0,
        Justify::Right => width.saturating_sub(len + 1),
        Justify::Center => (width - len) / 2,
    };
    format!("{}{}", " ".repeat(pad), row)
}

fn paragraphize(input: &str) -> String {
    let chars: Vec<char> = input.chars().collect();
    let mut out = String::new();
    for i in 0..chars.len() {
        if chars[i] == '\n' {
            let prev_nl = i > 0 && chars[i - 1] == '\n';
            let next_space = i + 1 < chars.len() && chars[i + 1].is_whitespace() && chars[i + 1] != '\n';
            if !prev_nl && !next_space {
                out.push(' ');
            } else {
                out.push('\n');
            }
        } else {
            out.push(chars[i]);
        }
    }
    out
}
