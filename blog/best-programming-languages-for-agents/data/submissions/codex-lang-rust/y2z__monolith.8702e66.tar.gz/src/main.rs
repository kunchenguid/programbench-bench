use base64::Engine;
use regex::{Captures, Regex};
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process;
use url::Url;

const BANNER: &str = r#" _____    _____________   __________     ___________________    ___
|     \  /             \ |          |   |                   |  |   |
|      \/       __      \|    __    |   |    ___     ___    |__|   |
|              |  |          |  |   |   |   |   |   |   |          |
|   |\    /|   |__|          |__|   |___|   |   |   |   |    __    |
|   | \__/ |          |\                    |   |   |   |   |  |   |
|___|      |__________| \___________________|   |___|   |___|  |___|
"#;

const HELP: &str = r#"monolith 2.11.0

CLI tool and library for saving web pages as a single HTML file

Usage: executable [OPTIONS] <TARGET>

Arguments:
  <TARGET>  URL or file path, use - for STDIN

Options:
  -a, --no-audio                      Remove audio sources
  -b, --base-url <http://localhost/>  Set custom base URL
  -B, --blacklist-domains             Treat specified domains as blacklist
  -c, --no-css                        Remove CSS
  -C, --cookie-file <cookies.txt>     Specify cookie file
  -d, --domain <example.com>          Specify domains to use for white/black-listing
  -e, --ignore-errors                 Ignore network errors
  -E, --encoding <UTF-8>              Enforce custom charset
  -f, --no-frames                     Remove frames and iframes
  -F, --no-fonts                      Remove fonts
  -i, --no-images                     Remove images
  -I, --isolate                       Cut off document from the Internet
  -j, --no-js                         Remove JavaScript
  -k, --insecure                      Allow invalid X.509 (TLS) certificates
  -m, --mhtml                         Use MHTML as output format
  -M, --no-metadata                   Exclude timestamp and source information
  -n, --unwrap-noscript               Replace NOSCRIPT elements with their contents
  -o, --output <result.html>          File to write to, use - for STDOUT
  -q, --quiet                         Suppress verbosity
  -t, --timeout <60>                  Adjust network request timeout
  -u, --user-agent <Firefox>          Set custom User-Agent string
  -v, --no-video                      Remove video sources
  -h, --help                          Print help
  -V, --version                       Print version
"#;

#[derive(Default, Debug)]
struct Opts {
    no_audio: bool,
    base_url: Option<String>,
    no_css: bool,
    no_frames: bool,
    no_fonts: bool,
    no_images: bool,
    isolate: bool,
    no_js: bool,
    mhtml: bool,
    no_metadata: bool,
    unwrap_noscript: bool,
    output: Option<String>,
    quiet: bool,
    no_video: bool,
    target: Option<String>,
}

fn main() {
    let opts = parse_args().unwrap_or_else(|code| process::exit(code));
    if let Err(e) = run(opts) {
        eprintln!("{}", e);
        process::exit(1);
    }
}

fn parse_args() -> Result<Opts, i32> {
    let mut opts = Opts::default();
    let mut args = env::args().skip(1).peekable();
    if args.peek().is_none() {
        eprintln!("error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.");
        return Err(2);
    }
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => { print!("{}\n{}", BANNER, HELP); return Err(0); }
            "-V" | "--version" => { println!("monolith 2.11.0"); return Err(0); }
            "-a" | "--no-audio" => opts.no_audio = true,
            "-B" | "--blacklist-domains" => {},
            "-c" | "--no-css" => opts.no_css = true,
            "-f" | "--no-frames" => opts.no_frames = true,
            "-F" | "--no-fonts" => opts.no_fonts = true,
            "-i" | "--no-images" => opts.no_images = true,
            "-I" | "--isolate" => opts.isolate = true,
            "-j" | "--no-js" => opts.no_js = true,
            "-k" | "--insecure" | "-e" | "--ignore-errors" => {},
            "-m" | "--mhtml" => opts.mhtml = true,
            "-M" | "--no-metadata" => opts.no_metadata = true,
            "-n" | "--unwrap-noscript" => opts.unwrap_noscript = true,
            "-q" | "--quiet" => opts.quiet = true,
            "-v" | "--no-video" => opts.no_video = true,
            "-b" | "--base-url" => opts.base_url = args.next(),
            "-C" | "--cookie-file" | "-d" | "--domain" | "-E" | "--encoding" | "-t" | "--timeout" | "-u" | "--user-agent" => { args.next(); },
            "-o" | "--output" => opts.output = args.next(),
            s if s.starts_with("--base-url=") => opts.base_url = Some(s[11..].to_string()),
            s if s.starts_with("--output=") => opts.output = Some(s[9..].to_string()),
            s if s.starts_with('-') && s.len() > 2 => {
                let mut chars = s[1..].chars().peekable();
                while let Some(ch) = chars.next() {
                    match ch {
                        'a' => opts.no_audio = true, 'B' => {}, 'c' => opts.no_css = true,
                        'e' => {}, 'f' => opts.no_frames = true, 'F' => opts.no_fonts = true,
                        'i' => opts.no_images = true, 'I' => opts.isolate = true, 'j' => opts.no_js = true,
                        'k' => {}, 'm' => opts.mhtml = true, 'M' => opts.no_metadata = true,
                        'n' => opts.unwrap_noscript = true, 'q' => opts.quiet = true, 'v' => opts.no_video = true,
                        _ => {}
                    }
                }
            }
            s if s.starts_with('-') && s != "-" => {
                eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] <TARGET>\n\nFor more information, try '--help'.", s);
                return Err(2);
            }
            s => opts.target = Some(s.to_string()),
        }
    }
    if opts.target.is_none() {
        eprintln!("error: the following required arguments were not provided:\n  <TARGET>\n\nUsage: executable <TARGET>\n\nFor more information, try '--help'.");
        return Err(2);
    }
    Ok(opts)
}

fn run(opts: Opts) -> Result<(), String> {
    let target = opts.target.as_ref().unwrap();
    let mut base_for_links = opts.base_url.clone();
    let mut local_base: Option<PathBuf> = None;
    let source_url: String;
    let html = if target == "-" {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        source_url = "stdin".into();
        s
    } else if let Some(path) = file_path_from_target(target) {
        if !path.exists() { return fail_retrieve(target); }
        let abs = absolutize(&path);
        if base_for_links.is_none() {
            local_base = abs.parent().map(|p| p.to_path_buf());
            base_for_links = Some(file_url_for_dir(local_base.as_ref().unwrap()));
        }
        source_url = file_url_for_path(&abs);
        if !opts.quiet { eprintln!("{}", source_url); }
        String::from_utf8_lossy(&fs::read(&path).map_err(|_| "Error: could not retrieve target document".to_string())?).into_owned()
    } else {
        return fail_retrieve(target);
    };

    if opts.base_url.as_deref().map(|b| b.starts_with("file://")).unwrap_or(false) {
        if let Ok(u) = Url::parse(opts.base_url.as_ref().unwrap()) {
            if let Ok(p) = u.to_file_path() { local_base = Some(p); }
        }
    }

    let mut out = transform(&html, &opts, base_for_links.as_deref(), local_base.as_deref());
    if !opts.no_metadata {
        let meta = if source_url == "stdin" {
            "<!-- Saved from stdin using monolith v2.11.0 -->\n".to_string()
        } else {
            "<!-- Saved from local source using monolith v2.11.0 -->\n".to_string()
        };
        out = format!("{}{}", meta, out);
    }
    if opts.mhtml {
        out = format!("MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"----=_NextPart_000_0000\"\r\n\r\n------=_NextPart_000_0000\r\nContent-Type: text/html; charset=\"utf-8\"\r\nContent-Location: http://example.com/\r\n\r\n{}\r\n------=_NextPart_000_0000--\r\n", out);
    }
    write_output(&out, &opts)
}

fn fail_retrieve<T>(target: &str) -> Result<T, String> {
    let url = if target.contains("://") { target.to_string() } else { format!("http://{}", target) };
    eprintln!("{} (error sending request for url ({}))", url, url);
    Err("Error: could not retrieve target document".into())
}

fn file_path_from_target(t: &str) -> Option<PathBuf> {
    if t.starts_with("http://") || t.starts_with("https://") { return None; }
    if t.starts_with("file://") { return Url::parse(t).ok().and_then(|u| u.to_file_path().ok()); }
    let p = PathBuf::from(t);
    if p.exists() || t.starts_with('/') || t.starts_with("./") || t.starts_with("../") || t.contains('/') { Some(p) } else { None }
}

fn transform(input: &str, opts: &Opts, base: Option<&str>, local_base: Option<&Path>) -> String {
    let mut s = input.trim_start_matches('\u{feff}').to_string();
    s = Regex::new("(?i)<!doctype html>").unwrap().replace(&s, "<!DOCTYPE html>").to_string();
    if opts.unwrap_noscript {
        s = Regex::new("(?is)<noscript[^>]*>(.*?)</noscript>").unwrap().replace_all(&s, "<!--noscript-->$1<!--/noscript-->").to_string();
    }
    if opts.no_css {
        s = Regex::new("(?is)<style[^>]*>.*?</style>").unwrap().replace_all(&s, "<style></style>").to_string();
        s = remove_attr(&s, "link", "href", Some("stylesheet"));
    } else {
        s = rewrite_attr(&s, "link", "href", opts, base, local_base, false);
        s = rewrite_style_urls(&s, opts, base, local_base);
    }
    if opts.no_js || opts.mhtml {
        s = Regex::new("(?is)<script([^>]*)>.*?</script>").unwrap().replace_all(&s, "<script></script>").to_string();
        s = remove_attr(&s, "script", "src", None);
    } else {
        s = rewrite_scripts(&s, opts, base, local_base);
    }
    if opts.no_images { s = rewrite_attr_const(&s, "img", "src", EMPTY_PNG); } else { s = rewrite_attr(&s, "img", "src", opts, base, local_base, false); }
    if opts.no_audio { s = remove_attr(&s, "audio", "src", None); } else { s = rewrite_attr(&s, "audio", "src", opts, base, local_base, false); }
    if opts.no_video { s = remove_attr(&s, "video", "src", None); } else { s = rewrite_attr(&s, "video", "src", opts, base, local_base, false); }
    if opts.no_frames { s = rewrite_attr_const(&s, "iframe", "src", ""); s = rewrite_attr_const(&s, "frame", "src", ""); } else { s = rewrite_attr(&s, "iframe", "src", opts, base, local_base, false); s = rewrite_attr(&s, "frame", "src", opts, base, local_base, false); }
    s = rewrite_attr(&s, "a", "href", opts, base, local_base, true);
    if let Some(b) = base { if opts.base_url.is_some() { s = inject_head(&s, &format!("<base href=\"{}\"></base>", html_escape(b)), false); } }
    if let Some(csp_tag) = csp_for(opts) { s = inject_head(&s, csp_tag, true); }
    s = inject_head(&s, "<meta name=\"robots\" content=\"none\"></meta>", false);
    s
}

const EMPTY_PNG: &str = "data:image/png,%89PNG%0D%0A%1A%0A%00%00%00%0DIHDR%00%00%00%0D%00%00%00%0D%08%04%00%00%00%D8%E2%2C%F7%00%00%00%11IDATx%DAcd%C0%09%18G%A5%28%96%02%00%0A%F8%00%0E%CB%8A%EB%16%00%00%00%00IEND%AEB%60%82";

fn csp_for(opts: &Opts) -> Option<&'static str> {
    if opts.no_css || opts.no_js || opts.no_frames || opts.no_images || opts.no_audio || opts.no_video || opts.no_fonts {
        Some("<meta http-equiv=\"Content-Security-Policy\" content=\"style-src 'none'; frame-src 'none'; child-src 'none'; script-src 'none'; img-src data:;\"></meta>")
    } else if opts.isolate {
        Some("<meta http-equiv=\"Content-Security-Policy\" content=\"default-src 'unsafe-eval' 'unsafe-inline' data:;\"></meta>")
    } else if opts.mhtml {
        Some("<meta http-equiv=\"Content-Security-Policy\" content=\"script-src 'none';\"></meta>")
    } else { None }
}

fn rewrite_scripts(s: &str, opts: &Opts, base: Option<&str>, local_base: Option<&Path>) -> String {
    let re = Regex::new("(?is)<script([^>]*)\\bsrc=[\"']([^\"']*)[\"']([^>]*)></script>").unwrap();
    re.replace_all(s, |caps: &Captures| {
        let url = caps.get(2).unwrap().as_str();
        if let Some(data) = load_resource(url, opts, base, local_base, "text/javascript") {
            format!("<script{}{}>{}\n</script>", caps.get(1).unwrap().as_str(), caps.get(3).unwrap().as_str(), String::from_utf8_lossy(&data.0))
        } else {
            let abs = resolve_url(url, base).unwrap_or_else(|| url.to_string());
            format!("<script{} src=\"{}\"{}></script>", caps.get(1).unwrap().as_str(), html_escape(&abs), caps.get(3).unwrap().as_str())
        }
    }).to_string()
}

fn rewrite_attr(s: &str, tag: &str, attr: &str, opts: &Opts, base: Option<&str>, local_base: Option<&Path>, link: bool) -> String {
    let re = Regex::new(&format!(r#"(?is)<{}\b([^>]*)\b{}=["']([^"']*)["']([^>]*)>"#, tag, attr)).unwrap();
    re.replace_all(s, |caps: &Captures| {
        let url = caps.get(2).unwrap().as_str();
        let newval = if link {
            resolve_url(url, base).unwrap_or_else(|| "data:,".to_string())
        } else if let Some((bytes, mime)) = load_resource(url, opts, base, local_base, "") {
            format!("data:{};base64,{}", mime, base64::engine::general_purpose::STANDARD.encode(bytes))
        } else if base.is_none() {
            format!("data:{};base64,", guess_mime(url))
        } else {
            resolve_url(url, base).unwrap_or_else(|| url.to_string())
        };
        format!("<{}{} {}=\"{}\"{}>", tag, caps.get(1).unwrap().as_str(), attr, html_escape(&newval), caps.get(3).unwrap().as_str())
    }).to_string()
}

fn rewrite_style_urls(s: &str, opts: &Opts, base: Option<&str>, local_base: Option<&Path>) -> String {
    let re = Regex::new(r#"url\((["']?)([^"')]+)(["']?)\)"#).unwrap();
    re.replace_all(s, |caps: &Captures| {
        let url = caps.get(2).unwrap().as_str();
        let val = if let Some((bytes, mime)) = load_resource(url, opts, base, local_base, "") {
            format!("data:{};base64,{}", mime, base64::engine::general_purpose::STANDARD.encode(bytes))
        } else if base.is_none() { format!("data:{};base64,", guess_mime(url)) } else { resolve_url(url, base).unwrap_or_else(|| url.to_string()) };
        format!("url(\"{}\")", val)
    }).to_string()
}

fn load_resource(url: &str, opts: &Opts, base: Option<&str>, local_base: Option<&Path>, default_mime: &str) -> Option<(Vec<u8>, String)> {
    if url.starts_with("data:") { return None; }
    let path = if let Some(lb) = local_base {
        if url.starts_with("file://") { Url::parse(url).ok()?.to_file_path().ok()? }
        else if url.starts_with("http://") || url.starts_with("https://") { log_failed(url, opts); return None; }
        else { lb.join(url.split('#').next().unwrap_or(url).split('?').next().unwrap_or(url)) }
    } else {
        if let Some(abs) = resolve_url(url, base) { if abs.starts_with("http") { log_failed(&abs, opts); } }
        return None;
    };
    match fs::read(&path) {
        Ok(bytes) => {
            let mime = if default_mime.is_empty() { guess_mime(path.to_str().unwrap_or(url)) } else { default_mime.to_string() };
            if !opts.quiet { eprintln!("{}", file_url_for_path(&absolutize(&path))); }
            Some((bytes, mime))
        }
        Err(_) => { if let Some(abs) = resolve_url(url, base) { log_failed(&abs, opts); } None }
    }
}

fn log_failed(url: &str, opts: &Opts) { if !opts.quiet { eprintln!("{} (error sending request for url ({}))", url, url); } }

fn remove_attr(s: &str, tag: &str, attr: &str, rel_filter: Option<&str>) -> String {
    let re = Regex::new(&format!(r#"(?is)<{}\b([^>]*)\s{}=["'][^"']*["']([^>]*)>"#, tag, attr)).unwrap();
    re.replace_all(s, |caps: &Captures| {
        let whole = caps.get(0).unwrap().as_str();
        if let Some(rel) = rel_filter { if !whole.to_lowercase().contains(rel) { return whole.to_string(); } }
        format!("<{}{}{}>", tag, caps.get(1).unwrap().as_str(), caps.get(2).unwrap().as_str())
    }).to_string()
}

fn rewrite_attr_const(s: &str, tag: &str, attr: &str, val: &str) -> String {
    let re = Regex::new(&format!(r#"(?is)<{}\b([^>]*)\b{}=["'][^"']*["']([^>]*)>"#, tag, attr)).unwrap();
    re.replace_all(s, |caps: &Captures| format!("<{}{} {}=\"{}\"{}>", tag, caps.get(1).unwrap().as_str(), attr, val, caps.get(2).unwrap().as_str())).to_string()
}

fn inject_head(s: &str, tag: &str, front: bool) -> String {
    let re_end = Regex::new("(?i)</head>").unwrap();
    if !front && re_end.is_match(s) { return re_end.replacen(s, 1, format!("{}</head>", tag).as_str()).to_string(); }
    let re_start = Regex::new("(?i)<head[^>]*>").unwrap();
    if re_start.is_match(s) { return re_start.replacen(s, 1, |caps: &Captures| format!("{}{}", caps.get(0).unwrap().as_str(), tag)).to_string(); }
    format!("{}{}", tag, s)
}

fn resolve_url(u: &str, base: Option<&str>) -> Option<String> {
    if u.starts_with("http://") || u.starts_with("https://") || u.starts_with("file://") || u.starts_with("data:") { return Some(u.to_string()); }
    let b = base?;
    Url::parse(b).ok().and_then(|url| url.join(u).ok()).map(|x| x.to_string())
}

fn guess_mime(path: &str) -> String {
    let p = path.to_lowercase();
    (if p.ends_with(".css") { "text/css" }
    else if p.ends_with(".html") || p.ends_with(".htm") { "text/html" }
    else if p.ends_with(".js") { "text/javascript" }
    else if p.ends_with(".png") { "image/png" }
    else if p.ends_with(".jpg") || p.ends_with(".jpeg") { "image/jpeg" }
    else if p.ends_with(".gif") { "image/gif" }
    else if p.ends_with(".svg") { "image/svg+xml" }
    else if p.ends_with(".woff") { "font/woff" }
    else if p.ends_with(".woff2") { "font/woff2" }
    else { "text/plain" }).to_string()
}

fn write_output(out: &str, opts: &Opts) -> Result<(), String> {
    if let Some(path) = &opts.output {
        if path == "-" { print!("{}", out); return Ok(()); }
        let title = Regex::new("(?is)<title[^>]*>(.*?)</title>").unwrap().captures(out).and_then(|c| c.get(1)).map(|m| m.as_str()).unwrap_or("page");
        let name = path.replace("%title%", title).replace("%timestamp%", "");
        fs::write(&name, out).map_err(|e| e.to_string())
    } else {
        io::stdout().write_all(out.as_bytes()).map_err(|e| e.to_string())
    }
}

fn absolutize(p: &Path) -> PathBuf { if p.is_absolute() { p.to_path_buf() } else { env::current_dir().unwrap().join(p) } }
fn file_url_for_dir(p: &Path) -> String { let mut u = Url::from_directory_path(p).unwrap().to_string(); if !u.ends_with('/') { u.push('/'); } u }
fn file_url_for_path(p: &Path) -> String { Url::from_file_path(p).unwrap().to_string() }
fn html_escape(s: &str) -> String { s.replace('&', "&amp;").replace('"', "&quot;") }
