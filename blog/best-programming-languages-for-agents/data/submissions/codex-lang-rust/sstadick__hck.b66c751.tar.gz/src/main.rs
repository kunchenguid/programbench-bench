use regex::Regex;
use std::collections::HashSet;
use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader, BufWriter, Write};
use std::process::{Command, Stdio};

#[derive(Default)]
struct Args {
    output: Option<String>,
    delimiter: String,
    literal: bool,
    use_input_delim: bool,
    output_delim: Option<String>,
    fields: Vec<String>,
    exclude: Vec<String>,
    header_fields: Vec<String>,
    exclude_headers: Vec<String>,
    header_regex: bool,
    try_decompress: bool,
    try_compress: bool,
    crlf: bool,
    inputs: Vec<String>,
}

fn main() {
    if let Err(e) = run() {
        eprintln!("[2026-05-31T20:37:20Z ERROR hck] {}", e);
        std::process::exit(1);
    }
}

fn run() -> Result<(), String> {
    let args = parse_args()?;
    let out_delim = if args.output_delim.is_none() && args.use_input_delim && args.literal {
        args.delimiter.clone()
    } else {
        args.output_delim.clone().unwrap_or_else(|| "\t".to_string())
    };

    let mut writer: Box<dyn Write> = if args.try_compress {
        if let Some(path) = &args.output {
            let file = File::create(path).map_err(|e| e.to_string())?;
            let child = Command::new("gzip")
                .arg("-c")
                .stdin(Stdio::piped())
                .stdout(file)
                .spawn()
                .map_err(|e| e.to_string())?;
            Box::new(GzipWriter { child: Some(child) })
        } else {
            let child = Command::new("gzip")
                .arg("-c")
                .stdin(Stdio::piped())
                .spawn()
                .map_err(|e| e.to_string())?;
            Box::new(GzipWriter { child: Some(child) })
        }
    } else if let Some(path) = &args.output {
        Box::new(BufWriter::new(File::create(path).map_err(|e| e.to_string())?))
    } else {
        Box::new(BufWriter::new(io::stdout()))
    };

    let selector_specs = build_selector_specs(&args.fields)?;
    let exclude_specs = build_selector_specs(&args.exclude)?;
    let mut header_selection: Option<Vec<usize>> = None;
    let mut wrote_any_input = false;

    if args.inputs.is_empty() {
        let stdin = io::stdin();
        process_reader(
            stdin.lock(),
            &args,
            &selector_specs,
            &exclude_specs,
            &out_delim,
            &mut writer,
            &mut header_selection,
        )?;
    } else {
        for path in &args.inputs {
            let reader = open_input(path, args.try_decompress)?;
            process_reader(
                reader,
                &args,
                &selector_specs,
                &exclude_specs,
                &out_delim,
                &mut writer,
                &mut header_selection,
            )?;
            wrote_any_input = true;
        }
    }
    if wrote_any_input {
        writer.flush().map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn parse_args() -> Result<Args, String> {
    let mut a = Args {
        delimiter: r"\s+".to_string(),
        ..Default::default()
    };
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        if arg == "--" {
            a.inputs.extend(it);
            break;
        } else if arg == "-h" {
            print_short_help();
            std::process::exit(0);
        } else if arg == "--help" {
            print_long_help();
            std::process::exit(0);
        } else if arg == "-V" || arg == "--version" {
            println!("hck git:23bebe8-modified");
            std::process::exit(0);
        } else if let Some(name) = arg.strip_prefix("--") {
            match name {
                "output" => a.output = Some(next_arg(&mut it, "--output")?),
                "delimiter" => a.delimiter = next_arg(&mut it, "--delimiter")?,
                "delim-is-literal" => a.literal = true,
                "use-input-delim" => a.use_input_delim = true,
                "output-delimiter" => a.output_delim = Some(next_arg(&mut it, "--output-delimiter")?),
                "fields" => a.fields.push(next_arg(&mut it, "--fields")?),
                "exclude" => a.exclude.push(next_arg(&mut it, "--exclude")?),
                "exclude-header" => a.exclude_headers.push(next_arg(&mut it, "--exclude-header")?),
                "header-field" => a.header_fields.push(next_arg(&mut it, "--header-field")?),
                "header-is-regex" => a.header_regex = true,
                "try-decompress" => a.try_decompress = true,
                "try-compress" => a.try_compress = true,
                "compression-threads" | "compression-level" => {
                    let _ = next_arg(&mut it, name)?;
                }
                "no-mmap" => {}
                "crlf" => a.crlf = true,
                _ if name.starts_with("output=") => a.output = Some(name[7..].to_string()),
                _ if name.starts_with("delimiter=") => a.delimiter = name[10..].to_string(),
                _ if name.starts_with("output-delimiter=") => a.output_delim = Some(name[17..].to_string()),
                _ if name.starts_with("fields=") => a.fields.push(name[7..].to_string()),
                _ if name.starts_with("exclude=") => a.exclude.push(name[8..].to_string()),
                _ if name.starts_with("exclude-header=") => a.exclude_headers.push(name[15..].to_string()),
                _ if name.starts_with("header-field=") => a.header_fields.push(name[13..].to_string()),
                _ => return Err(format!("unexpected argument '--{}'", name)),
            }
        } else if arg.starts_with('-') && arg.len() > 1 {
            parse_short(&arg, &mut it, &mut a)?;
        } else {
            a.inputs.push(arg);
        }
    }
    Ok(a)
}

fn next_arg<I: Iterator<Item = String>>(it: &mut std::iter::Peekable<I>, name: &str) -> Result<String, String> {
    it.next().ok_or_else(|| format!("a value is required for '{}'", name))
}

fn parse_short<I: Iterator<Item = String>>(
    arg: &str,
    it: &mut std::iter::Peekable<I>,
    a: &mut Args,
) -> Result<(), String> {
    let chars: Vec<char> = arg[1..].chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        let needs_value = matches!(c, 'o' | 'd' | 'D' | 'f' | 'e' | 'E' | 'F' | 't' | 'l');
        if needs_value {
            let value: String = if i + 1 < chars.len() {
                chars[i + 1..].iter().collect()
            } else {
                it.next().ok_or_else(|| format!("a value is required for '-{}'", c))?
            };
            match c {
                'o' => a.output = Some(value),
                'd' => a.delimiter = value,
                'D' => a.output_delim = Some(value),
                'f' => a.fields.push(value),
                'e' => a.exclude.push(value),
                'E' => a.exclude_headers.push(value),
                'F' => a.header_fields.push(value),
                't' | 'l' => {}
                _ => unreachable!(),
            }
            return Ok(());
        }
        match c {
            'L' => a.literal = true,
            'I' => a.use_input_delim = true,
            'r' => a.header_regex = true,
            'z' => a.try_decompress = true,
            'Z' => a.try_compress = true,
            'h' => {
                print_short_help();
                std::process::exit(0);
            }
            'V' => {
                println!("hck git:23bebe8-modified");
                std::process::exit(0);
            }
            _ => return Err(format!("unexpected argument '-{}'", c)),
        }
        i += 1;
    }
    Ok(())
}

fn open_input(path: &str, decompress: bool) -> Result<Box<dyn BufRead>, String> {
    if decompress && path.ends_with(".gz") {
        let child = Command::new("gzip")
            .arg("-dc")
            .arg(path)
            .stdout(Stdio::piped())
            .spawn()
            .map_err(|e| e.to_string())?;
        let out = child.stdout.ok_or_else(|| "failed to read gzip output".to_string())?;
        Ok(Box::new(BufReader::new(out)))
    } else {
        let file = File::open(path).map_err(|e| e.to_string())?;
        Ok(Box::new(BufReader::new(file)))
    }
}

fn process_reader<R: BufRead>(
    mut reader: R,
    args: &Args,
    fields: &[FieldSpec],
    excludes: &[FieldSpec],
    out_delim: &str,
    writer: &mut Box<dyn Write>,
    header_selection: &mut Option<Vec<usize>>,
) -> Result<(), String> {
    let regex = if args.literal {
        None
    } else {
        Some(Regex::new(&args.delimiter).map_err(|e| e.to_string())?)
    };
    let mut buf = String::new();
    while reader.read_line(&mut buf).map_err(|e| e.to_string())? != 0 {
        let mut line = buf.trim_end_matches('\n').to_string();
        if args.crlf {
            if line.ends_with('\r') {
                line.pop();
            }
        }
        let parts: Vec<String> = split_line(&line, &args.delimiter, args.literal, regex.as_ref());
        let selected = if !args.header_fields.is_empty() || !args.exclude_headers.is_empty() {
            if header_selection.is_none() {
                let idx = select_header_indices(&parts, args, fields, excludes)?;
                *header_selection = Some(idx.clone());
                idx
            } else {
                header_selection.as_ref().unwrap().clone()
            }
        } else {
            select_indices(parts.len(), fields, excludes)
        };
        write_selected(&parts, &selected, out_delim, args.crlf, writer)?;
        buf.clear();
    }
    Ok(())
}

fn split_line(line: &str, delim: &str, literal: bool, regex: Option<&Regex>) -> Vec<String> {
    if literal {
        if delim.is_empty() {
            vec![line.to_string()]
        } else {
            line.split(delim).map(|s| s.to_string()).collect()
        }
    } else {
        regex.unwrap().split(line).map(|s| s.to_string()).collect()
    }
}

#[derive(Clone)]
enum FieldSpec {
    Single(usize),
    From(usize),
    To(usize),
    Range(usize, usize),
}

fn build_selector_specs(items: &[String]) -> Result<Vec<FieldSpec>, String> {
    let mut out = Vec::new();
    for item in items {
        for raw in item.split(',') {
            if raw.is_empty() {
                return Err("Failed to parse field: ".to_string());
            }
            if let Some((lo, hi)) = raw.split_once('-') {
                if lo.is_empty() && hi.is_empty() {
                    return Err("Failed to parse field: ".to_string());
                }
                if lo.is_empty() {
                    let end = parse_pos(hi)?;
                    out.push(FieldSpec::To(end));
                } else if hi.is_empty() {
                    let start = parse_pos(lo)?;
                    out.push(FieldSpec::From(start));
                } else {
                    let start = parse_pos(lo)?;
                    let end = parse_pos(hi)?;
                    if end < start {
                        return Err(format!("High end of range less than low end of range: {}", raw));
                    }
                    out.push(FieldSpec::Range(start, end));
                }
            } else {
                let n = parse_pos(raw)?;
                out.push(FieldSpec::Single(n));
            }
        }
    }
    Ok(out)
}

fn parse_pos(s: &str) -> Result<usize, String> {
    let n = s.parse::<usize>().map_err(|_| format!("Failed to parse field: {}", s))?;
    if n == 0 {
        return Err("Fields and positions are numbered from 1: 0".to_string());
    }
    Ok(n)
}

fn expand_specs(specs: &[FieldSpec], len: usize) -> Vec<usize> {
    let mut seen = HashSet::new();
    let mut out = Vec::new();
    for spec in specs {
        let (start, end) = match *spec {
            FieldSpec::Single(n) => (n, n),
            FieldSpec::From(n) => (n, len),
            FieldSpec::To(n) => (1, n),
            FieldSpec::Range(a, b) => (a, b),
        };
        if start > len {
            continue;
        }
        for n in start..=end.min(len) {
            let idx = n - 1;
            if seen.insert(idx) {
                out.push(idx);
            }
        }
    }
    out
}

fn select_indices(len: usize, fields: &[FieldSpec], excludes: &[FieldSpec]) -> Vec<usize> {
    let mut idx = if fields.is_empty() {
        (0..len).collect::<Vec<_>>()
    } else {
        expand_specs(fields, len)
    };
    if !excludes.is_empty() {
        let ex: HashSet<usize> = expand_specs(excludes, len).into_iter().collect();
        idx.retain(|i| !ex.contains(i));
    }
    idx
}

fn select_header_indices(
    headers: &[String],
    args: &Args,
    fields: &[FieldSpec],
    excludes: &[FieldSpec],
) -> Result<Vec<usize>, String> {
    let mut seen = HashSet::new();
    let mut idx = Vec::new();
    if args.header_regex {
        let regexes: Vec<Regex> = args
            .header_fields
            .iter()
            .map(|p| Regex::new(p).map_err(|e| e.to_string()))
            .collect::<Result<_, _>>()?;
        let mut groups: Vec<Vec<usize>> = vec![Vec::new(); regexes.len()];
        for (i, h) in headers.iter().enumerate() {
            let mut last_match = None;
            for (g, re) in regexes.iter().enumerate() {
                if re.is_match(h) {
                    groups[g].push(i);
                    last_match = Some(g);
                }
            }
            if let Some(last) = last_match {
                for group in groups.iter_mut().take(last) {
                    group.retain(|v| *v != i);
                }
            }
        }
        for group in groups {
            for i in group {
                if seen.insert(i) {
                    idx.push(i);
                }
            }
        }
    } else {
        for pat in &args.header_fields {
            for (i, h) in headers.iter().enumerate() {
                if h == pat && seen.insert(i) {
                    idx.push(i);
                }
            }
        }
    }
    if !fields.is_empty() {
        for i in select_indices(headers.len(), fields, &[]) {
            if seen.insert(i) {
                idx.push(i);
            }
        }
    }
    if args.header_fields.is_empty() && fields.is_empty() {
        idx = (0..headers.len()).collect();
    }

    if !args.exclude_headers.is_empty() {
        let mut ex = HashSet::new();
        for pat in &args.exclude_headers {
            if args.header_regex {
                let re = Regex::new(pat).map_err(|e| e.to_string())?;
                for (i, h) in headers.iter().enumerate() {
                    if re.is_match(h) {
                        ex.insert(i);
                    }
                }
            } else {
                for (i, h) in headers.iter().enumerate() {
                    if h == pat {
                        ex.insert(i);
                    }
                }
            }
        }
        idx.retain(|i| !ex.contains(i));
    }
    if !excludes.is_empty() && !fields.is_empty() {
        let ex: HashSet<usize> = expand_specs(excludes, headers.len()).into_iter().collect();
        idx.retain(|i| !ex.contains(i));
    }
    Ok(idx)
}

fn write_selected(
    parts: &[String],
    idx: &[usize],
    delim: &str,
    crlf: bool,
    writer: &mut Box<dyn Write>,
) -> Result<(), String> {
    for (pos, i) in idx.iter().enumerate() {
        if pos > 0 {
            writer.write_all(delim.as_bytes()).map_err(|e| e.to_string())?;
        }
        if let Some(s) = parts.get(*i) {
            writer.write_all(s.as_bytes()).map_err(|e| e.to_string())?;
        }
    }
    if crlf {
        writer.write_all(b"\r\n").map_err(|e| e.to_string())?;
    } else {
        writer.write_all(b"\n").map_err(|e| e.to_string())?;
    }
    Ok(())
}

struct GzipWriter {
    child: Option<std::process::Child>,
}

impl Write for GzipWriter {
    fn write(&mut self, buf: &[u8]) -> io::Result<usize> {
        self.child
            .as_mut()
            .unwrap()
            .stdin
            .as_mut()
            .unwrap()
            .write(buf)
    }

    fn flush(&mut self) -> io::Result<()> {
        self.child
            .as_mut()
            .unwrap()
            .stdin
            .as_mut()
            .unwrap()
            .flush()
    }
}

impl Drop for GzipWriter {
    fn drop(&mut self) {
        if let Some(mut child) = self.child.take() {
            drop(child.stdin.take());
            let _ = child.wait();
        }
    }
}

fn print_short_help() {
    println!("* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`\n");
    println!("Usage: executable [OPTIONS] [INPUT]...\n");
    println!("Options:");
    println!("  -o, --output <OUTPUT>");
    println!("  -d, --delimiter <DELIMITER>          [default: \\s+]");
    println!("  -L, --delim-is-literal");
    println!("  -I, --use-input-delim");
    println!("  -D, --output-delimiter <OUTPUT_DELIMITER>          [default: \"\\t\"]");
    println!("  -f, --fields <FIELDS>");
    println!("  -e, --exclude <EXCLUDE>");
    println!("  -E, --exclude-header <EXCLUDE_HEADER>");
    println!("  -F, --header-field <HEADER_FIELD>");
    println!("  -r, --header-is-regex");
    println!("  -z, --try-decompress");
    println!("  -Z, --try-compress");
    println!("  -h, --help");
    println!("  -V, --version");
}

fn print_long_help() {
    print_short_help();
}
