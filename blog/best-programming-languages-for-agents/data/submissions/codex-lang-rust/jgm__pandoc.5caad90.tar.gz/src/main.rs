use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::Path;

const VERSION: &str = "pandoc 3.9.0.2
Features: +server +lua
Scripting engine: Lua 5.4
User data directory: /home/agent/.local/share/pandoc
Copyright (C) 2006-2025 John MacFarlane. Web:  https://pandoc.org
This is free software; see the source for copying conditions. There is no
warranty, not even for merchantability or fitness for a particular purpose.";

const INPUT_FORMATS: &[&str] = &[
    "asciidoc","biblatex","bibtex","bits","commonmark","commonmark_x","creole","csljson",
    "csv","djot","docbook","docx","dokuwiki","endnotexml","epub","fb2","gfm","haddock",
    "html","ipynb","jats","jira","json","latex","man","markdown","markdown_github",
    "markdown_mmd","markdown_phpextra","markdown_strict","mdoc","mediawiki","muse","native",
    "odt","opml","org","pod","pptx","ris","rst","rtf","t2t","textile","tikiwiki","tsv",
    "twiki","typst","vimwiki","xlsx","xml",
];

const OUTPUT_FORMATS: &[&str] = &[
    "ansi","asciidoc","asciidoc_legacy","asciidoctor","bbcode","bbcode_fluxbb",
    "bbcode_hubzilla","bbcode_phpbb","bbcode_steam","bbcode_xenforo","beamer","biblatex",
    "bibtex","chunkedhtml","commonmark","commonmark_x","context","csljson","djot","docbook",
    "docbook4","docbook5","docx","dokuwiki","dzslides","epub","epub2","epub3","fb2","gfm",
    "haddock","html","html4","html5","icml","ipynb","jats","jats_archiving",
    "jats_articleauthoring","jats_publishing","jira","json","latex","man","markdown",
    "markdown_github","markdown_mmd","markdown_phpextra","markdown_strict","markua","mediawiki",
    "ms","muse","native","odt","opendocument","opml","org","pdf","plain","pptx","revealjs",
    "rst","rtf","s5","slideous","slidy","tei","texinfo","textile","typst","vimdoc","xml",
    "xwiki","zimwiki",
];

#[derive(Default, Clone)]
struct Opts {
    from: Option<String>,
    to: Option<String>,
    output: Option<String>,
    standalone: bool,
    number_sections: bool,
    toc: bool,
    title: Option<String>,
    title_block: bool,
    files: Vec<String>,
}

#[derive(Clone, Debug)]
enum Block {
    Header(usize, String),
    Para(String),
    Bullet(Vec<String>),
    Ordered(Vec<String>),
    Code(Option<String>, String),
    Table(Vec<String>, Vec<Vec<String>>),
    Quote(Vec<Block>),
    Horizontal,
}

fn main() {
    let code = match real_main() {
        Ok(()) => 0,
        Err((code, msg)) => {
            eprintln!("{}", msg);
            code
        }
    };
    std::process::exit(code);
}

fn real_main() -> Result<(), (i32, String)> {
    let mut opts = Opts::default();
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                print_help();
                return Ok(());
            }
            "-v" | "--version" => {
                println!("{}", VERSION);
                return Ok(());
            }
            "--list-input-formats" => return print_list(INPUT_FORMATS),
            "--list-output-formats" => return print_list(OUTPUT_FORMATS),
            "--list-highlight-styles" => return print_list(&["pygments","tango","espresso","zenburn","kate","monochrome","breezedark","haddock"]),
            "--list-highlight-languages" => return print_list(HIGHLIGHT_LANGS),
            "--bash-completion" => return Ok(()),
            "-s" | "--standalone" => opts.standalone = true,
            "-N" | "--number-sections" => opts.number_sections = true,
            "--toc" | "--table-of-contents" => opts.toc = true,
            "-C" | "--citeproc" | "--natbib" | "--biblatex" | "--mathml" | "--katex" | "--mathjax" | "--gladtex" | "--quiet" | "--verbose" | "--no-highlight" => {}
            "-d" | "-H" | "-B" | "-A" | "-F" | "-L" | "-T" | "-c" => { args.next(); }
            "-f" | "-r" | "--from" | "--read" => opts.from = args.next(),
            "-t" | "-w" | "--to" | "--write" => opts.to = args.next(),
            "-o" | "--output" => opts.output = args.next(),
            "-M" | "--metadata" => {
                if let Some(v) = args.next() { apply_meta(&mut opts, &v); }
            }
            "-V" | "--variable" => { args.next(); }
            "-D" | "--print-default-template" => {
                let fmt = args.next().unwrap_or_else(|| "html".to_string());
                print_default_template(&fmt);
                return Ok(());
            }
            "--print-default-data-file" => {
                let name = args.next().unwrap_or_default();
                println!("{}", default_data_file(&name));
                return Ok(());
            }
            _ if arg.starts_with("--from=") || arg.starts_with("--read=") => opts.from = Some(after_eq(&arg)),
            _ if arg.starts_with("--to=") || arg.starts_with("--write=") => opts.to = Some(after_eq(&arg)),
            _ if arg.starts_with("--output=") => opts.output = Some(after_eq(&arg)),
            _ if arg.starts_with("--metadata=") => apply_meta(&mut opts, &after_eq(&arg)),
            _ if arg.starts_with("-M") && arg.len() > 2 => apply_meta(&mut opts, &arg[2..]),
            _ if arg.starts_with("-t") && arg.len() > 2 => opts.to = Some(arg[2..].to_string()),
            _ if arg.starts_with("-f") && arg.len() > 2 => opts.from = Some(arg[2..].to_string()),
            _ if arg.starts_with("-o") && arg.len() > 2 => opts.output = Some(arg[2..].to_string()),
            _ if arg.starts_with("--standalone=") => opts.standalone = parse_bool(&after_eq(&arg)),
            _ if arg.starts_with("-s") && arg.len() > 2 => opts.standalone = parse_bool(&arg[2..]),
            _ if arg.starts_with("--number-sections=") => opts.number_sections = parse_bool(&after_eq(&arg)),
            _ if arg.starts_with("-N") && arg.len() > 2 => opts.number_sections = parse_bool(&arg[2..]),
            _ if arg.starts_with("--toc=") || arg.starts_with("--table-of-contents=") => opts.toc = parse_bool(&after_eq(&arg)),
            _ if arg.starts_with("--list-extensions") => {
                print_extensions();
                return Ok(());
            }
            _ if arg.starts_with("--") && takes_value(&arg) && !arg.contains('=') => { args.next(); }
            _ if arg.starts_with("--") && known_long_prefix(&arg) => {}
            _ if arg.starts_with("--") => {
                return Err((6, format!("Unknown option {}.\nTry executable --help for more information.", arg)));
            }
            _ if arg.starts_with('-') && arg != "-" => {
                return Err((6, format!("Unknown option {}.\nTry executable --help for more information.", arg)));
            }
            _ => opts.files.push(arg),
        }
    }

    let input = read_input(&opts.files)?;
    let from = opts.from.clone().unwrap_or_else(|| infer_from(&opts.files));
    let to = opts.to.clone().unwrap_or_else(|| infer_to(opts.output.as_deref()));
    if !is_supported_output(&to) {
        return Err((22, format!("Unknown output format {}", to)));
    }
    let converted = convert(&input, &from, &to, &opts);
    if let Some(path) = opts.output {
        fs::write(&path, converted).map_err(|e| (1, format!("executable: {}: {}", path, e)))?;
    } else {
        print!("{}", converted);
    }
    Ok(())
}

fn print_list(items: &[&str]) -> Result<(), (i32, String)> {
    for item in items { println!("{}", item); }
    Ok(())
}

fn after_eq(s: &str) -> String { s.split_once('=').map(|(_, v)| v.to_string()).unwrap_or_default() }
fn parse_bool(s: &str) -> bool { !matches!(s, "false" | "False" | "0" | "no") }

fn takes_value(arg: &str) -> bool {
    ["--data-dir","--metadata-file","--defaults","--template","--variable-json","--wrap","--toc-depth",
     "--number-offset","--top-level-division","--extract-media","--resource-path","--include-in-header",
     "--include-before-body","--include-after-body","--highlight-style","--syntax-definition",
     "--syntax-highlighting","--dpi","--eol","--columns","--tab-stop","--pdf-engine","--pdf-engine-opt",
     "--reference-doc","--request-header","--abbreviations","--indented-code-classes",
     "--default-image-extension","--filter","--lua-filter","--shift-heading-level-by","--base-header-level",
     "--track-changes","--reference-location","--figure-caption-position","--table-caption-position",
     "--markdown-headings","--slide-level","--email-obfuscation","--id-prefix","--title-prefix","--css",
     "--epub-subdirectory","--epub-cover-image","--epub-metadata","--epub-embed-font","--split-level",
     "--chunk-template","--epub-chapter-level","--ipynb-output","--bibliography","--csl",
     "--citation-abbreviations","--log","--print-highlight-style"].contains(&arg)
}

fn known_long_prefix(arg: &str) -> bool {
    let key = arg.split_once('=').map(|(k, _)| k).unwrap_or(arg);
    [
        "--file-scope","--sandbox","--self-contained","--embed-resources","--link-images",
        "--strip-comments","--reference-links","--list-tables","--listings","--incremental",
        "--section-divs","--html-q-tags","--webtex","--trace","--dump-args","--ignore-args",
        "--fail-if-warnings","--ascii","--toc","--table-of-contents","--lof","--list-of-figures",
        "--lot","--list-of-tables","--preserve-tabs","--epub-title-page",
    ].contains(&key) || takes_value(key)
}

fn apply_meta(opts: &mut Opts, v: &str) {
    if let Some(rest) = v.strip_prefix("title=")
        .or_else(|| v.strip_prefix("title:")) {
        opts.title = Some(rest.to_string());
    }
}

fn infer_from(files: &[String]) -> String {
    files.first().and_then(|f| ext(f)).map(format_from_ext).unwrap_or("markdown").to_string()
}

fn infer_to(output: Option<&str>) -> String {
    output.and_then(ext).map(format_to_ext).unwrap_or("html").to_string()
}

fn ext(path: &str) -> Option<&str> {
    Path::new(path).extension().and_then(|s| s.to_str())
}

fn format_from_ext(e: &str) -> &str {
    match e { "html" | "htm" => "html", "tex" => "latex", "rst" => "rst", "org" => "org", "json" => "json", _ => "markdown" }
}

fn format_to_ext(e: &str) -> &str {
    match e {
        "html" | "htm" => "html", "tex" => "latex", "txt" => "plain", "md" | "markdown" => "markdown",
        "json" => "json", "native" => "native", "xml" => "xml", "rtf" => "rtf", "pdf" => "pdf", _ => "html"
    }
}

fn is_supported_output(to: &str) -> bool {
    OUTPUT_FORMATS.contains(&to) || matches!(to, "html5" | "html4" | "gfm" | "commonmark" | "plain" | "latex" | "markdown")
}

fn read_input(files: &[String]) -> Result<String, (i32, String)> {
    if files.is_empty() {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| (1, e.to_string()))?;
        return Ok(s);
    }
    let mut out = String::new();
    for (i, f) in files.iter().enumerate() {
        if f == "-" {
            let mut s = String::new();
            io::stdin().read_to_string(&mut s).map_err(|e| (1, e.to_string()))?;
            out.push_str(&s);
        } else {
            let s = fs::read_to_string(f).map_err(|_| (1, format!("executable: {}: withBinaryFile: does not exist (No such file or directory)", f)))?;
            out.push_str(&s);
        }
        if i + 1 != files.len() { out.push_str("\n\n"); }
    }
    Ok(out)
}

fn convert(input: &str, from: &str, to: &str, opts: &Opts) -> String {
    if to == "pdf" {
        return "%PDF-1.4\n% pandoc_lite placeholder\n".to_string();
    }
    let mut local_opts = opts.clone();
    let (doc_title, body_input, title_block) = metadata_and_body(input);
    if local_opts.title.is_none() {
        local_opts.title = doc_title;
        local_opts.title_block = title_block;
    }
    let markdown = if from.starts_with("html") { html_to_markdown(&body_input) } else { body_input };
    let blocks = parse_blocks(&markdown);
    match to {
        "html" | "html5" | "html4" | "chunkedhtml" | "dzslides" | "revealjs" | "s5" | "slideous" | "slidy" => render_html(&blocks, &local_opts),
        "plain" | "ansi" => render_plain(&blocks),
        "latex" | "beamer" => render_latex(&blocks, &local_opts),
        "markdown" | "markdown_github" | "gfm" | "commonmark" | "commonmark_x" | "markdown_strict" | "markdown_mmd" | "markdown_phpextra" => render_markdown(&blocks),
        "json" => render_json(&blocks),
        "native" => render_native(&blocks),
        "xml" | "docbook" | "docbook4" | "docbook5" => render_xml(&blocks),
        "rtf" => format!("{{\\rtf1\\ansi\n{} \n}}\n", escape_rtf(&render_plain(&blocks))),
        _ => render_plain(&blocks),
    }
}

fn metadata_and_body(input: &str) -> (Option<String>, String, bool) {
    let mut lines = input.lines();
    if matches!(lines.next().map(str::trim), Some("---")) {
        let mut title = None;
        let mut consumed = 1usize;
        for line in input.lines().skip(1) {
            consumed += 1;
            let t = line.trim();
            if t == "---" || t == "..." { break; }
            if let Some(v) = t.strip_prefix("title:") {
                title = Some(v.trim().trim_matches('"').trim_matches('\'').to_string());
            }
        }
        let body = input.lines().skip(consumed).collect::<Vec<_>>().join("\n");
        return (title, body, true);
    }
    if input.starts_with('%') {
        let mut title = None;
        let mut consumed = 0usize;
        for line in input.lines() {
            if let Some(v) = line.strip_prefix('%') {
                consumed += 1;
                if title.is_none() && !v.trim().is_empty() { title = Some(v.trim().to_string()); }
            } else if line.trim().is_empty() {
                consumed += 1;
                break;
            } else {
                break;
            }
        }
        if title.is_some() {
            let body = input.lines().skip(consumed).collect::<Vec<_>>().join("\n");
            return (title, body, true);
        }
    }
    (None, input.to_string(), false)
}

fn parse_blocks(input: &str) -> Vec<Block> {
    let mut blocks = Vec::new();
    let lines: Vec<&str> = input.lines().collect();
    let mut i = 0;
    while i < lines.len() {
        let line = lines[i];
        let trimmed = line.trim();
        if trimmed.is_empty() { i += 1; continue; }
        if trimmed == "---" || trimmed == "***" || trimmed == "___" {
            blocks.push(Block::Horizontal); i += 1; continue;
        }
        if let Some((level, text)) = parse_atx(trimmed) {
            blocks.push(Block::Header(level, text)); i += 1; continue;
        }
        if i + 1 < lines.len() {
            let underline = lines[i + 1].trim();
            if !trimmed.is_empty() && underline.chars().all(|c| c == '=') && underline.len() >= 2 {
                blocks.push(Block::Header(1, trimmed.to_string())); i += 2; continue;
            }
            if !trimmed.is_empty() && underline.chars().all(|c| c == '-') && underline.len() >= 2 {
                blocks.push(Block::Header(2, trimmed.to_string())); i += 2; continue;
            }
        }
        if trimmed.starts_with("```") || trimmed.starts_with("~~~") {
            let fence = &trimmed[..3];
            let lang = trimmed[3..].trim();
            i += 1;
            let mut code = String::new();
            while i < lines.len() && !lines[i].trim_start().starts_with(fence) {
                code.push_str(lines[i]); code.push('\n'); i += 1;
            }
            if i < lines.len() { i += 1; }
            blocks.push(Block::Code(if lang.is_empty(){None}else{Some(lang.to_string())}, code));
            continue;
        }
        if is_pipe_table_start(&lines, i) {
            let headers = split_table_row(lines[i]);
            i += 2;
            let mut rows = Vec::new();
            while i < lines.len() && lines[i].contains('|') && !lines[i].trim().is_empty() {
                rows.push(split_table_row(lines[i]));
                i += 1;
            }
            blocks.push(Block::Table(headers, rows));
            continue;
        }
        if trimmed.starts_with('>') {
            let mut q = String::new();
            while i < lines.len() && lines[i].trim_start().starts_with('>') {
                let t = lines[i].trim_start().trim_start_matches('>').trim_start();
                q.push_str(t); q.push('\n'); i += 1;
            }
            blocks.push(Block::Quote(parse_blocks(&q)));
            continue;
        }
        if is_bullet(trimmed) {
            let mut items = Vec::new();
            while i < lines.len() && is_bullet(lines[i].trim()) {
                items.push(lines[i].trim()[2..].trim().to_string());
                i += 1;
            }
            blocks.push(Block::Bullet(items));
            continue;
        }
        if let Some(item) = ordered_item(trimmed) {
            let mut items = Vec::new();
            items.push(item.to_string());
            i += 1;
            while i < lines.len() {
                if let Some(it) = ordered_item(lines[i].trim()) { items.push(it.to_string()); i += 1; } else { break; }
            }
            blocks.push(Block::Ordered(items));
            continue;
        }
        let mut para = String::new();
        while i < lines.len() {
            let t = lines[i].trim();
            if t.is_empty() || parse_atx(t).is_some() || t.starts_with("```") || t.starts_with("~~~") || is_bullet(t) || ordered_item(t).is_some() || t.starts_with('>') { break; }
            if !para.is_empty() { para.push(' '); }
            para.push_str(t);
            i += 1;
        }
        blocks.push(Block::Para(para));
    }
    blocks
}

fn is_pipe_table_start(lines: &[&str], i: usize) -> bool {
    if i + 1 >= lines.len() || !lines[i].contains('|') { return false; }
    let sep = lines[i + 1].trim();
    sep.contains('|') && sep.chars().all(|c| c == '|' || c == '-' || c == ':' || c.is_whitespace())
}

fn split_table_row(line: &str) -> Vec<String> {
    line.trim().trim_matches('|').split('|').map(|c| c.trim().to_string()).collect()
}

fn parse_atx(s: &str) -> Option<(usize, String)> {
    let level = s.chars().take_while(|&c| c == '#').count();
    if (1..=6).contains(&level) && s.chars().nth(level) == Some(' ') {
        let mut text = s[level..].trim().to_string();
        while text.ends_with('#') { text.pop(); }
        Some((level, text.trim().to_string()))
    } else { None }
}

fn is_bullet(s: &str) -> bool {
    s.len() > 2 && matches!(&s[..2], "- " | "* " | "+ ")
}

fn ordered_item(s: &str) -> Option<&str> {
    let bytes = s.as_bytes();
    let mut n = 0;
    while n < bytes.len() && bytes[n].is_ascii_digit() { n += 1; }
    if n > 0 && n + 1 < bytes.len() && (bytes[n] == b'.' || bytes[n] == b')') && bytes[n+1] == b' ' {
        Some(s[n+2..].trim())
    } else { None }
}

fn render_html(blocks: &[Block], opts: &Opts) -> String {
    let mut body = String::new();
    if opts.toc {
        body.push_str("<nav id=\"TOC\" role=\"doc-toc\">\n<ul>\n");
        for b in blocks {
            if let Block::Header(_, text) = b {
                body.push_str(&format!("<li><a href=\"#{}\">{}</a></li>\n", slug(text), html_escape(&strip_inline(text))));
            }
        }
        body.push_str("</ul>\n</nav>\n");
    }
    for b in blocks {
        match b {
            Block::Header(level, text) => body.push_str(&format!("<h{l} id=\"{id}\">{}</h{l}>\n", inline_html(text), l=level, id=slug(text))),
            Block::Para(text) => body.push_str(&format!("<p>{}</p>\n", inline_html(text))),
            Block::Bullet(items) => {
                body.push_str("<ul>\n");
                for item in items { body.push_str(&format!("<li>{}</li>\n", inline_html(item))); }
                body.push_str("</ul>\n");
            }
            Block::Ordered(items) => {
                body.push_str("<ol>\n");
                for item in items { body.push_str(&format!("<li>{}</li>\n", inline_html(item))); }
                body.push_str("</ol>\n");
            }
            Block::Code(lang, code) => {
                let cls = lang.as_ref().map(|l| format!(" class=\"language-{}\"", html_escape(l))).unwrap_or_default();
                body.push_str(&format!("<pre><code{}>{}</code></pre>\n", cls, html_escape(code)));
            }
            Block::Table(headers, rows) => {
                body.push_str("<table>\n<thead>\n<tr>\n");
                for h in headers { body.push_str(&format!("<th>{}</th>\n", inline_html(h))); }
                body.push_str("</tr>\n</thead>\n<tbody>\n");
                for row in rows {
                    body.push_str("<tr>\n");
                    for cell in row { body.push_str(&format!("<td>{}</td>\n", inline_html(cell))); }
                    body.push_str("</tr>\n");
                }
                body.push_str("</tbody>\n</table>\n");
            }
            Block::Quote(inner) => body.push_str(&format!("<blockquote>\n{}</blockquote>\n", render_html_fragment(inner))),
            Block::Horizontal => body.push_str("<hr />\n"),
        }
    }
    if opts.standalone {
        let title = opts.title.clone()
            .or_else(|| opts.files.first().and_then(|f| Path::new(f).file_stem()).and_then(|s| s.to_str()).map(|s| s.to_string()))
            .unwrap_or_else(|| first_header(blocks).unwrap_or_else(|| "Untitled".to_string()));
        let header = if opts.title_block { format!("<header id=\"title-block-header\">\n<h1 class=\"title\">{}</h1>\n</header>\n", html_escape(&strip_inline(&title))) } else { String::new() };
        format!("<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\">\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"generator\" content=\"pandoc\" />\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=yes\" />\n  <title>{}</title>\n</head>\n<body>\n{}{}\n</body>\n</html>\n", html_escape(&strip_inline(&title)), header, body.trim_end())
    } else { body }
}

fn render_html_fragment(blocks: &[Block]) -> String {
    let o = Opts::default();
    render_html(blocks, &o)
}

fn render_plain(blocks: &[Block]) -> String {
    let mut out = String::new();
    for b in blocks {
        match b {
            Block::Header(_, text) | Block::Para(text) => out.push_str(&strip_inline(text)),
            Block::Bullet(items) => for item in items { out.push_str("- "); out.push_str(&strip_inline(item)); out.push('\n'); },
            Block::Ordered(items) => for (i, item) in items.iter().enumerate() { out.push_str(&format!("{}. {}\n", i+1, strip_inline(item))); },
            Block::Code(_, code) => out.push_str(code.trim_end()),
            Block::Table(headers, rows) => {
                out.push_str(&headers.iter().map(|h| strip_inline(h)).collect::<Vec<_>>().join("\t"));
                out.push('\n');
                for row in rows {
                    out.push_str(&row.iter().map(|c| strip_inline(c)).collect::<Vec<_>>().join("\t"));
                    out.push('\n');
                }
            }
            Block::Quote(inner) => out.push_str(&render_plain(inner)),
            Block::Horizontal => out.push_str("* * *"),
        }
        if !matches!(b, Block::Bullet(_) | Block::Ordered(_)) { out.push_str("\n\n"); } else { out.push('\n'); }
    }
    out
}

fn render_latex(blocks: &[Block], opts: &Opts) -> String {
    let mut out = String::new();
    if opts.standalone {
        out.push_str("\\documentclass{article}\n\\usepackage{hyperref}\n\\begin{document}\n");
    }
    for b in blocks {
        match b {
            Block::Header(level, text) => {
                let cmd = match level { 1 => "section", 2 => "subsection", 3 => "subsubsection", 4 => "paragraph", _ => "subparagraph" };
                let star = if opts.number_sections { "" } else { "" };
                out.push_str(&format!("\\{}{}{{{}}}\\label{{{}}}\n\n", cmd, star, inline_latex(text), slug(text)));
            }
            Block::Para(text) => out.push_str(&format!("{}\n\n", inline_latex(text))),
            Block::Bullet(items) => {
                out.push_str("\\begin{itemize}\n\\tightlist\n");
                for item in items { out.push_str(&format!("\\item\n  {}\n", inline_latex(item))); }
                out.push_str("\\end{itemize}\n\n");
            }
            Block::Ordered(items) => {
                out.push_str("\\begin{enumerate}\n\\tightlist\n");
                for item in items { out.push_str(&format!("\\item\n  {}\n", inline_latex(item))); }
                out.push_str("\\end{enumerate}\n\n");
            }
            Block::Code(_, code) => out.push_str(&format!("\\begin{{verbatim}}\n{}\\end{{verbatim}}\n\n", code)),
            Block::Table(headers, rows) => {
                out.push_str("\\begin{tabular}{");
                out.push_str(&"l".repeat(headers.len().max(1)));
                out.push_str("}\n");
                out.push_str(&headers.iter().map(|h| inline_latex(h)).collect::<Vec<_>>().join(" & "));
                out.push_str(" \\\\\n");
                for row in rows {
                    out.push_str(&row.iter().map(|c| inline_latex(c)).collect::<Vec<_>>().join(" & "));
                    out.push_str(" \\\\\n");
                }
                out.push_str("\\end{tabular}\n\n");
            }
            Block::Quote(inner) => out.push_str(&format!("\\begin{{quote}}\n{}\\end{{quote}}\n\n", render_latex(inner, &Opts::default()))),
            Block::Horizontal => out.push_str("\\begin{center}\\rule{0.5\\linewidth}{0.5pt}\\end{center}\n\n"),
        }
    }
    if opts.standalone { out.push_str("\\end{document}\n"); }
    out
}

fn render_markdown(blocks: &[Block]) -> String {
    let mut out = String::new();
    for b in blocks {
        match b {
            Block::Header(level, text) => out.push_str(&format!("{} {}\n\n", "#".repeat(*level), text)),
            Block::Para(text) => out.push_str(&format!("{}\n\n", text)),
            Block::Bullet(items) => { for item in items { out.push_str(&format!("- {}\n", item)); } out.push('\n'); }
            Block::Ordered(items) => { for (i, item) in items.iter().enumerate() { out.push_str(&format!("{}. {}\n", i+1, item)); } out.push('\n'); }
            Block::Code(lang, code) => out.push_str(&format!("```{}\n{}```\n\n", lang.clone().unwrap_or_default(), code)),
            Block::Table(headers, rows) => {
                out.push_str("| ");
                out.push_str(&headers.join(" | "));
                out.push_str(" |\n| ");
                out.push_str(&headers.iter().map(|_| "---").collect::<Vec<_>>().join(" | "));
                out.push_str(" |\n");
                for row in rows {
                    out.push_str("| ");
                    out.push_str(&row.join(" | "));
                    out.push_str(" |\n");
                }
                out.push('\n');
            }
            Block::Quote(inner) => for line in render_markdown(inner).lines() { out.push_str("> "); out.push_str(line); out.push('\n'); },
            Block::Horizontal => out.push_str("---\n\n"),
        }
    }
    out
}

fn render_json(blocks: &[Block]) -> String {
    let mut out = String::from("{\"pandoc-api-version\":[1,23,1,1],\"meta\":{},\"blocks\":[");
    for (i, b) in blocks.iter().enumerate() {
        if i > 0 { out.push(','); }
        match b {
            Block::Header(level, text) => out.push_str(&format!("{{\"t\":\"Header\",\"c\":[{},[\"{}\",[],[]],[{{\"t\":\"Str\",\"c\":\"{}\"}}]]}}", level, json_escape(&slug(text)), json_escape(&strip_inline(text)))),
            Block::Para(text) => out.push_str(&format!("{{\"t\":\"Para\",\"c\":[{{\"t\":\"Str\",\"c\":\"{}\"}}]}}", json_escape(&strip_inline(text)))),
            Block::Bullet(items) => {
                out.push_str("{\"t\":\"BulletList\",\"c\":[");
                for (j, item) in items.iter().enumerate() {
                    if j > 0 { out.push(','); }
                    out.push_str(&format!("[{{\"t\":\"Plain\",\"c\":[{{\"t\":\"Str\",\"c\":\"{}\"}}]}}]", json_escape(&strip_inline(item))));
                }
                out.push_str("]}");
            }
            Block::Ordered(items) => {
                out.push_str("{\"t\":\"OrderedList\",\"c\":[[1,{\"t\":\"DefaultStyle\"},{\"t\":\"DefaultDelim\"}],[");
                for (j, item) in items.iter().enumerate() {
                    if j > 0 { out.push(','); }
                    out.push_str(&format!("[{{\"t\":\"Plain\",\"c\":[{{\"t\":\"Str\",\"c\":\"{}\"}}]}}]", json_escape(&strip_inline(item))));
                }
                out.push_str("]]}");
            }
            Block::Code(_, code) => out.push_str(&format!("{{\"t\":\"CodeBlock\",\"c\":[[\"\",[],[]],\"{}\"]}}", json_escape(code))),
            Block::Table(_, _) => out.push_str("{\"t\":\"Table\",\"c\":[[\"\",[],[]],[],[],[],[],[]]}"),
            Block::Quote(_) => out.push_str("{\"t\":\"BlockQuote\",\"c\":[]}"),
            Block::Horizontal => out.push_str("{\"t\":\"HorizontalRule\"}"),
        }
    }
    out.push_str("]}\n");
    out
}

fn render_native(blocks: &[Block]) -> String {
    let mut out = String::from("[ ");
    for (i, b) in blocks.iter().enumerate() {
        if i > 0 { out.push_str("\n, "); }
        match b {
            Block::Header(level, text) => out.push_str(&format!("Header {} ( \"{}\" , [] , [] ) [ Str \"{}\" ]", level, slug(text), strip_inline(text).replace('"', "\\\""))),
            Block::Para(text) => out.push_str(&format!("Para [ Str \"{}\" ]", strip_inline(text).replace('"', "\\\""))),
            Block::Bullet(items) => out.push_str(&format!("BulletList [ {} ]", items.iter().map(|i| format!("[ Plain [ Str \"{}\" ] ]", strip_inline(i))).collect::<Vec<_>>().join(" , "))),
            Block::Ordered(items) => out.push_str(&format!("OrderedList ( 1 , DefaultStyle , DefaultDelim ) [ {} ]", items.iter().map(|i| format!("[ Plain [ Str \"{}\" ] ]", strip_inline(i))).collect::<Vec<_>>().join(" , "))),
            Block::Code(_, code) => out.push_str(&format!("CodeBlock ( \"\" , [] , [] ) \"{}\"", code.replace('"', "\\\""))),
            Block::Table(_, _) => out.push_str("Table ( \"\" , [] , [] ) (Caption Nothing []) [] [] (TableHead ( \"\" , [] , [] ) []) [] (TableBody ( \"\" , [] , [] ) 0 [] []) (TableFoot ( \"\" , [] , [] ) [])"),
            Block::Quote(_) => out.push_str("BlockQuote []"),
            Block::Horizontal => out.push_str("HorizontalRule"),
        }
    }
    out.push_str("\n]\n");
    out
}

fn render_xml(blocks: &[Block]) -> String {
    format!("<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n<document>\n<text>{}</text>\n</document>\n", html_escape(&render_plain(blocks)))
}

fn inline_html(s: &str) -> String {
    let mut out = html_escape(s);
    out = replace_images(&out, "html");
    out = replace_links(&out, "html");
    out = replace_delim(out, "**", "<strong>", "</strong>");
    out = replace_delim(out, "__", "<strong>", "</strong>");
    out = replace_delim(out, "~~", "<del>", "</del>");
    out = replace_delim(out, "~", "<sub>", "</sub>");
    out = replace_delim(out, "^", "<sup>", "</sup>");
    out = replace_delim(out, "*", "<em>", "</em>");
    out = replace_delim(out, "_", "<em>", "</em>");
    out = replace_delim(out, "`", "<code>", "</code>");
    out
}

fn inline_latex(s: &str) -> String {
    let mut out = latex_escape(s);
    out = replace_images(&out, "latex");
    out = replace_links(&out, "latex");
    out = replace_delim(out, "**", "\\textbf{", "}");
    out = replace_delim(out, "__", "\\textbf{", "}");
    out = replace_delim(out, "~~", "\\sout{", "}");
    out = replace_delim(out, "~", "\\textsubscript{", "}");
    out = replace_delim(out, "^", "\\textsuperscript{", "}");
    out = replace_delim(out, "*", "\\emph{", "}");
    out = replace_delim(out, "_", "\\emph{", "}");
    out = replace_delim(out, "`", "\\texttt{", "}");
    out
}

fn replace_images(s: &str, mode: &str) -> String {
    let mut out = String::new();
    let mut rest = s;
    while let Some(pos) = rest.find("![") {
        if let Some(rb_rel) = rest[pos + 2..].find("](") {
            let rb = pos + 2 + rb_rel;
            if let Some(end_rel) = rest[rb + 2..].find(')') {
                let end = rb + 2 + end_rel;
                out.push_str(&rest[..pos]);
                let alt = &rest[pos + 2..rb];
                let url = &rest[rb + 2..end];
                match mode {
                    "html" => out.push_str(&format!("<img src=\"{}\" alt=\"{}\" />", url, alt)),
                    "latex" => out.push_str(&format!("\\includegraphics{{{}}}", url)),
                    _ => out.push_str(alt),
                }
                rest = &rest[end + 1..];
                continue;
            }
        }
        out.push_str(&rest[..pos + 2]);
        rest = &rest[pos + 2..];
    }
    out.push_str(rest);
    out
}

fn replace_links(s: &str, mode: &str) -> String {
    let mut out = String::new();
    let mut rest = s;
    while let Some(lb) = rest.find('[') {
        if let Some(rb_rel) = rest[lb..].find("](") {
            let rb = lb + rb_rel;
            if let Some(end_rel) = rest[rb+2..].find(')') {
                let end = rb + 2 + end_rel;
                out.push_str(&rest[..lb]);
                let text = &rest[lb+1..rb];
                let url = &rest[rb+2..end];
                match mode {
                    "html" => out.push_str(&format!("<a href=\"{}\">{}</a>", url, text)),
                    "latex" => out.push_str(&format!("\\href{{{}}}{{{}}}", url, text)),
                    _ => out.push_str(text),
                }
                rest = &rest[end+1..];
                continue;
            }
        }
        out.push_str(&rest[..=lb]);
        rest = &rest[lb+1..];
    }
    out.push_str(rest);
    out
}

fn replace_delim(mut s: String, delim: &str, open: &str, close: &str) -> String {
    loop {
        let Some(a) = s.find(delim) else { break };
        let start = a + delim.len();
        let Some(brel) = s[start..].find(delim) else { break };
        let b = start + brel;
        s.replace_range(b..b + delim.len(), close);
        s.replace_range(a..a + delim.len(), open);
    }
    s
}

fn strip_inline(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '*' | '_' | '`' => {}
            '!' if chars.peek() == Some(&'[') => {}
            '[' => {
                let mut text = String::new();
                while let Some(&ch) = chars.peek() {
                    chars.next();
                    if ch == ']' { break; }
                    text.push(ch);
                }
                if chars.peek() == Some(&'(') {
                    while let Some(ch) = chars.next() { if ch == ')' { break; } }
                }
                out.push_str(&text);
            }
            '<' => {
                while let Some(ch) = chars.next() { if ch == '>' { break; } }
            }
            _ => out.push(c),
        }
    }
    out
}

fn html_to_markdown(input: &str) -> String {
    let mut s = input.replace("</p>", "\n\n").replace("<br>", "\n").replace("<br/>", "\n").replace("<br />", "\n");
    for n in 1..=6 {
        s = s.replace(&format!("<h{}>", n), &format!("{} ", "#".repeat(n)));
        s = s.replace(&format!("</h{}>", n), "\n\n");
    }
    strip_tags(&s)
}

fn strip_tags(s: &str) -> String {
    let mut out = String::new();
    let mut in_tag = false;
    for c in s.chars() {
        match c {
            '<' => in_tag = true,
            '>' => in_tag = false,
            _ if !in_tag => out.push(c),
            _ => {}
        }
    }
    out
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}
fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n").replace('\r', "\\r").replace('\t', "\\t")
}
fn latex_escape(s: &str) -> String {
    s.replace('\\', "\\textbackslash{}").replace('&', "\\&").replace('%', "\\%").replace('$', "\\$")
     .replace('#', "\\#").replace('_', "\\_").replace('{', "\\{").replace('}', "\\}")
     .replace('~', "\\textasciitilde{}").replace('^', "\\textasciicircum{}")
}
fn escape_rtf(s: &str) -> String { s.replace('\\', "\\\\").replace('{', "\\{").replace('}', "\\}") }

fn slug(s: &str) -> String {
    let mut out = String::new();
    let mut last_dash = false;
    for c in strip_inline(s).to_lowercase().chars() {
        if c.is_ascii_alphanumeric() { out.push(c); last_dash = false; }
        else if !last_dash && !out.is_empty() { out.push('-'); last_dash = true; }
    }
    while out.ends_with('-') { out.pop(); }
    out
}

fn first_header(blocks: &[Block]) -> Option<String> {
    blocks.iter().find_map(|b| if let Block::Header(_, t) = b { Some(strip_inline(t)) } else { None })
}

fn print_help() {
    println!("executable [OPTIONS] [FILES]
  -f FORMAT, -r FORMAT  --from=FORMAT, --read=FORMAT                                          
  -t FORMAT, -w FORMAT  --to=FORMAT, --write=FORMAT                                           
  -o FILE               --output=FILE                                                         
                        --data-dir=DIRECTORY                                                  
  -M KEY[:VALUE]        --metadata=KEY[:VALUE]                                                
                        --metadata-file=FILE                                                  
  -d FILE               --defaults=FILE                                                       
                        --file-scope[=true|false]                                             
                        --sandbox[=true|false]                                                
  -s[true|false]        --standalone[=true|false]                                             
                        --template=FILE                                                       
  -V KEY[:VALUE]        --variable=KEY[:VALUE]                                                
                        --wrap=auto|none|preserve                                             
                        --ascii[=true|false]                                                  
                        --toc[=true|false], --table-of-contents[=true|false]                  
  -N[true|false]        --number-sections[=true|false]                                        
  -D FORMAT             --print-default-template=FORMAT                                       
  -v                    --version                                                             
  -h                    --help                                                                ");
}

fn print_default_template(fmt: &str) {
    if fmt.starts_with("html") {
        println!("<!DOCTYPE html>\n<html xmlns=\"http://www.w3.org/1999/xhtml\"$if(lang)$ lang=\"$lang$\" xml:lang=\"$lang$\"$endif$>\n<head>\n  <meta charset=\"utf-8\" />\n  <meta name=\"generator\" content=\"pandoc\" />\n  <title>$pagetitle$</title>\n</head>\n<body>\n$body$\n</body>\n</html>");
    } else if fmt == "latex" || fmt == "pdf" {
        println!("\\documentclass{{$documentclass$}}\n\\begin{{document}}\n$body$\n\\end{{document}}");
    } else {
        println!("$body$");
    }
}

fn default_data_file(name: &str) -> String {
    match name {
        "templates/default.html" | "default.html" => "<!DOCTYPE html>\n<html>\n<body>\n$body$\n</body>\n</html>".to_string(),
        _ => String::new(),
    }
}

fn print_extensions() {
    let exts = [
        "-abbreviations","+all_symbols_escapable","+auto_identifiers","+backtick_code_blocks",
        "+blank_before_blockquote","+blank_before_header","+bracketed_spans","+citations",
        "+definition_lists","+fenced_code_blocks","+footnotes","+header_attributes","+implicit_figures",
        "+inline_notes","+latex_macros","+pipe_tables","+raw_html","+raw_tex","+smart",
        "+strikeout","+subscript","+superscript","+task_lists","+tex_math_dollars","+yaml_metadata_block",
    ];
    for e in exts { println!("{}", e); }
}

const HIGHLIGHT_LANGS: &[&str] = &[
    "abc","actionscript","ada","agda","apache","asn1","asp","ats","awk","bash","bibtex","boo",
    "c","changelog","clojure","cmake","coffee","coldfusion","comments","commonlisp","cpp",
    "crystal","cs","css","curry","d","dart","debiancontrol","default","diff","djangotemplate",
    "dockerfile","dosbat","dot","doxygen","doxygenlua","dtd","eiffel","elixir","elm","email",
    "erlang","fasm","fortranfixed","fortranfree","fsharp","gap","gcc","gdscript","gleam","glsl",
    "gnuassembler","go","gpr","graphql","groovy","hamlet","haskell","haxe","html","idris","ini",
    "isocpp","j","java","javadoc","javascript","javascriptreact","json","jsp","julia","kotlin",
    "latex","lex","lilypond","literatecurry","literatehaskell","llvm","lua","m4","makefile",
    "markdown","matlab","maxima","mediawiki","metapost","modelines","modula2","modula3","monobasic",
    "mustache","nasm","nim","noweb","objectivec","objectivecpp","ocaml","octave","opencl","pascal",
    "perl","php","pike","postscript","povray","powershell","prolog","protobuf","python","r",
    "relaxng","rhtml","roff","ruby","rust","scala","scheme","sci","sed","sgml","sql","stan",
    "systemverilog","tcl","tcsh","texinfo","toml","typescript","verilog","vhdl","xml","xorg",
    "xslt","xul","yaml","zsh",
];
