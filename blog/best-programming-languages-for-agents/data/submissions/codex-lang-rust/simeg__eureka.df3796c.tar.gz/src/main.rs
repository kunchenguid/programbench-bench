use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

#[derive(Debug, Default)]
struct Args {
    clear_config: bool,
    view: bool,
}

struct Config {
    repo: String,
}

fn main() {
    let args = parse_args();
    if args.clear_config {
        let _ = fs::remove_file(config_path());
        return;
    }

    if args.view {
        match load_config().and_then(|cfg| view_repo(&cfg.repo)) {
            Ok(()) => {}
            Err(e) => log_error(&e),
        }
        return;
    }

    if !config_path().exists() {
        if let Err(e) = first_time_setup() {
            log_error(&e);
        }
        return;
    }

    match load_config().and_then(|cfg| capture_idea(&cfg.repo)) {
        Ok(()) => {}
        Err(e) => log_error(&e),
    }
}

fn parse_args() -> Args {
    let mut parsed = Args::default();
    for arg in env::args().skip(1) {
        match arg.as_str() {
            "--clear-config" => parsed.clear_config = true,
            "-v" | "--view" => parsed.view = true,
            "-h" | "--help" => {
                print_help();
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("eureka 2.0.0");
                std::process::exit(0);
            }
            _ => {
                eprintln!("error: unexpected argument '{}' found\n", arg);
                eprintln!("Usage: executable [OPTIONS]\n");
                eprintln!("For more information, try '--help'.");
                std::process::exit(2);
            }
        }
    }
    parsed
}

fn print_help() {
    println!("Input and store your ideas without leaving the terminal\n");
    println!("Usage: executable [OPTIONS]\n");
    println!("Options:");
    println!("      --clear-config  Clear your stored configuration");
    println!("  -v, --view          View ideas with your $PAGER env variable. If unset use less");
    println!("  -h, --help          Print help");
    println!("  -V, --version       Print version");
}

fn config_path() -> PathBuf {
    if let Ok(xdg) = env::var("XDG_CONFIG_HOME") {
        PathBuf::from(xdg).join("eureka").join("config.json")
    } else if let Ok(home) = env::var("HOME") {
        PathBuf::from(home).join(".config").join("eureka").join("config.json")
    } else {
        PathBuf::from(".config/eureka/config.json")
    }
}

fn load_config() -> Result<Config, String> {
    let bytes = fs::read(config_path()).map_err(|e| e.to_string())?;
    parse_config(&String::from_utf8_lossy(&bytes))
}

fn parse_config(text: &str) -> Result<Config, String> {
    let key = "\"repo\"";
    let key_pos = text.find(key).ok_or_else(|| "missing field `repo`".to_string())?;
    let rest = &text[key_pos + key.len()..];
    let colon = rest.find(':').ok_or_else(|| "expected `:`".to_string())?;
    let value = rest[colon + 1..].trim_start();
    let mut chars = value.chars();
    if chars.next() != Some('"') {
        return Err("expected string".to_string());
    }
    let mut out = String::new();
    let mut esc = false;
    for c in chars {
        if esc {
            out.push(match c {
                'n' => '\n',
                'r' => '\r',
                't' => '\t',
                '"' => '"',
                '\\' => '\\',
                other => other,
            });
            esc = false;
        } else if c == '\\' {
            esc = true;
        } else if c == '"' {
            return Ok(Config { repo: out });
        } else {
            out.push(c);
        }
    }
    Err("unterminated string".to_string())
}

fn escape_json(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c => out.push(c),
        }
    }
    out
}

fn first_time_setup() -> Result<(), String> {
    print!("\x1b[0m\x1b[33m############################################################\n");
    print!("####                  First Time Setup                  ####\n");
    print!("############################################################\n\n");
    print!("This tool requires you to have a repository with a README.md\n");
    print!("in the root folder. The markdown file is where your ideas\n");
    print!("will be stored.\n\n");
    print!("Once first time setup has completed, simply run Eureka again\n");
    print!("to begin writing down ideas.\n        \n");
    print!("\x1b[0m\x1b[0m\x1b[1m\x1b[32mAbsolute path to your idea repo\n");
    print!("\x1b[0m> ");
    io::stdout().flush().ok();

    let mut repo = String::new();
    io::stdin().read_line(&mut repo).map_err(|e| e.to_string())?;
    let repo = repo.trim_end_matches(['\r', '\n']).to_string();
    let path = config_path();
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let json = format!("{{\"repo\":\"{}\"}}", escape_json(&repo));
    fs::write(path, json).map_err(|e| e.to_string())?;
    println!("First time setup complete. Happy ideation!");
    Ok(())
}

fn prompt_summary() -> Result<String, String> {
    loop {
        print!("\x1b[0m\x1b[1m\x1b[32m>> Idea summary\n");
        print!("\x1b[0m> ");
        io::stdout().flush().ok();
        let mut summary = String::new();
        io::stdin().read_line(&mut summary).map_err(|e| e.to_string())?;
        let summary = summary.trim().to_string();
        if !summary.is_empty() {
            return Ok(summary);
        }
    }
}

fn capture_idea(repo: &str) -> Result<(), String> {
    let summary = prompt_summary()?;
    let readme = Path::new(repo).join("README.md");
    let editor = env::var("EDITOR").unwrap_or_else(|_| "vim".to_string());
    let _ = Command::new(editor).arg(&readme).status().map_err(|e| e.to_string())?;

    println!("Adding and committing your new idea to main..");
    ensure_git_identity(repo)?;
    run_git(repo, &["checkout", "-B", "main"])?;
    run_git(repo, &["add", "README.md"])?;
    run_git(repo, &["commit", "-m", &summary])?;
    println!("Added and committed!");
    println!("Pushing your new idea..");
    match run_git(repo, &["push", "-u", "origin", "main"]) {
        Ok(()) => println!("Pushed!"),
        Err(e) => log_error(&normalize_push_error(&e)),
    }
    Ok(())
}

fn ensure_git_identity(repo: &str) -> Result<(), String> {
    let name = git_output(repo, &["config", "user.name"])
        .map_err(|_| "config value 'user.name' was not found; class=Config (7); code=NotFound (-3)".to_string())?;
    if name.trim().is_empty() {
        return Err("config value 'user.name' was not found; class=Config (7); code=NotFound (-3)".to_string());
    }
    let email = git_output(repo, &["config", "user.email"])
        .map_err(|_| "config value 'user.email' was not found; class=Config (7); code=NotFound (-3)".to_string())?;
    if email.trim().is_empty() {
        return Err("config value 'user.email' was not found; class=Config (7); code=NotFound (-3)".to_string());
    }
    Ok(())
}

fn view_repo(repo: &str) -> Result<(), String> {
    let pager = env::var("PAGER").unwrap_or_else(|_| "less".to_string());
    let readme = Path::new(repo).join("README.md");
    let status = Command::new(pager)
        .arg(readme)
        .status()
        .map_err(|e| e.to_string())?;
    if status.success() {
        Ok(())
    } else {
        Err(format!("process exited with: {}", status))
    }
}

fn run_git(repo: &str, args: &[&str]) -> Result<(), String> {
    let out = Command::new("git")
        .args(args)
        .current_dir(repo)
        .stdout(Stdio::null())
        .stderr(Stdio::piped())
        .output()
        .map_err(|e| git_os_error(repo, e))?;
    if out.status.success() {
        Ok(())
    } else {
        let stderr = String::from_utf8_lossy(&out.stderr).trim().to_string();
        if stderr.is_empty() {
            Err(format!("git {:?} failed", args))
        } else {
            Err(stderr)
        }
    }
}

fn git_output(repo: &str, args: &[&str]) -> Result<String, String> {
    let out = Command::new("git")
        .args(args)
        .current_dir(repo)
        .stderr(Stdio::piped())
        .output()
        .map_err(|e| git_os_error(repo, e))?;
    if out.status.success() {
        Ok(String::from_utf8_lossy(&out.stdout).to_string())
    } else {
        Err(String::from_utf8_lossy(&out.stderr).trim().to_string())
    }
}

fn git_os_error(repo: &str, e: io::Error) -> String {
    if e.kind() == io::ErrorKind::NotFound {
        format!("failed to resolve path '{}': No such file or directory; class=Os (2); code=NotFound (-3)", repo)
    } else {
        e.to_string()
    }
}

fn normalize_push_error(e: &str) -> String {
    if e.contains("'origin'") || e.contains("origin does not appear") || e.contains("No such remote") {
        "remote 'origin' does not exist; class=Config (7); code=NotFound (-3)".to_string()
    } else {
        e.to_string()
    }
}

fn log_error(msg: &str) {
    eprintln!(" ERROR eureka > {}", msg);
}
