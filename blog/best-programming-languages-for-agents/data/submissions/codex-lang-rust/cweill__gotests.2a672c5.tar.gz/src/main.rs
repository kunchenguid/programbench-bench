use regex::Regex;
use std::collections::{BTreeMap, HashMap};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};

const VERSION: &str = "gotests v0.0.0-20260303205902-f3b63d74369a
Go version: go1.24.5
Git commit: f3b63d74369a8c405a9a3990a656a278a4f9096f
Build time: 2026-03-03T20:59:02Z";

#[derive(Default)]
struct Opt {
    all: bool,
    exported: bool,
    only: Option<String>,
    excl: Option<String>,
    write: bool,
    named: bool,
    nosubtests: bool,
    parallel: bool,
    inputs: bool,
    use_go_cmp: bool,
    version: bool,
    paths: Vec<String>,
}

#[derive(Clone, Debug)]
struct Param {
    name: String,
    typ: String,
    variadic: bool,
}

#[derive(Clone, Debug)]
struct Ret {
    typ: String,
}

#[derive(Clone, Debug)]
struct Func {
    name: String,
    receiver_name: Option<String>,
    receiver_type: Option<String>,
    receiver_ptr: bool,
    type_args: String,
    params: Vec<Param>,
    returns: Vec<Ret>,
}

#[derive(Clone, Debug)]
struct StructDef {
    fields: Vec<Param>,
}

#[derive(Default)]
struct FileInfo {
    package: String,
    funcs: Vec<Func>,
    structs: BTreeMap<String, StructDef>,
}

fn main() {
    let opt = parse_args();
    if opt.version {
        println!("{}", VERSION);
        return;
    }
    if !(opt.all || opt.exported || opt.only.is_some() || opt.excl.is_some()) {
        println!("Please specify either the -only, -excl, -exported, or -all flag");
        return;
    }
    if opt.paths.is_empty() {
        println!("Please specify a file or directory containing the source");
        return;
    }

    let mut had_err = false;
    for path in collect_paths(&opt.paths) {
        match process_path(&path, &opt) {
            Ok(()) => {}
            Err(e) => {
                println!("{}", e);
                had_err = true;
            }
        }
    }
    if had_err {
        std::process::exit(1);
    }
}

fn usage() {
    print!(
"Usage of ./executable:
  -ai
    \tgenerate test cases using AI (requires Ollama)
  -ai-endpoint string
    \tOllama API endpoint (default \"http://localhost:11434\")
  -ai-max-cases int
    \tmaximum number of test cases to generate with AI (default 10)
  -ai-min-cases int
    \tminimum number of test cases to generate with AI (default 3)
  -ai-model string
    \tAI model to use for test generation (default \"qwen2.5-coder:0.5b\")
  -all
    \tgenerate tests for all functions and methods
  -excl string
    \tregexp. generate tests for functions and methods that don't match. Takes precedence over -only, -exported, and -all
  -exported
    \tgenerate tests for exported functions and methods. Takes precedence over -only and -all
  -i\tprint test inputs in error messages
  -named
    \tswitch table tests from using slice to map (with test name for the key)
  -nosubtests
    \tdisable generating tests using the Go 1.7 subtests feature
  -only string
    \tregexp. generate tests for functions and methods that match only. Takes precedence over -all
  -parallel
    \tenable generating parallel subtests using the Go 1.7 feature
  -template string
    \toptional. Specify custom test code templates, e.g. testify. This can also be set via environment variable GOTESTS_TEMPLATE
  -template_dir string
    \toptional. Path to a directory containing custom test code templates. Takes precedence over -template. This can also be set via environment variable GOTESTS_TEMPLATE_DIR
  -template_params string
    \tread external parameters to template by json with stdin
  -template_params_file string
    \tread external parameters to template by json with file
  -use_go_cmp
    \tuse cmp.Equal (google/go-cmp) instead of reflect.DeepEqual
  -version
    \tprint version information and exit
  -w\twrite output to (test) files instead of stdout
"
    );
}

fn parse_args() -> Opt {
    let mut opt = Opt::default();
    let mut args = env::args().skip(1).peekable();
    while let Some(a) = args.next() {
        match a.as_str() {
            "--help" | "-h" => {
                usage();
                std::process::exit(0);
            }
            "-all" => opt.all = true,
            "-exported" => opt.exported = true,
            "-w" => opt.write = true,
            "-named" => opt.named = true,
            "-nosubtests" => opt.nosubtests = true,
            "-parallel" => opt.parallel = true,
            "-i" => opt.inputs = true,
            "-use_go_cmp" => opt.use_go_cmp = true,
            "-version" => opt.version = true,
            "-only" => opt.only = Some(take_value(&mut args, "-only")),
            "-excl" => opt.excl = Some(take_value(&mut args, "-excl")),
            "-template" | "-template_dir" | "-template_params" | "-template_params_file"
            | "-ai-model" | "-ai-endpoint" | "-ai-min-cases" | "-ai-max-cases" => {
                let _ = take_value(&mut args, &a);
            }
            "-ai" => {}
            _ if a.starts_with('-') => {
                eprintln!("flag provided but not defined: {}", a);
                usage();
                std::process::exit(2);
            }
            _ => opt.paths.push(a),
        }
    }
    opt
}

fn take_value<I: Iterator<Item = String>>(args: &mut std::iter::Peekable<I>, flag: &str) -> String {
    args.next().unwrap_or_else(|| {
        eprintln!("flag needs an argument: {}", flag);
        usage();
        std::process::exit(2);
    })
}

fn collect_paths(paths: &[String]) -> Vec<PathBuf> {
    let mut out = Vec::new();
    for p in paths {
        if p.ends_with("/...") {
            let root = Path::new(p.trim_end_matches("/..."));
            collect_recursive(root, &mut out);
        } else {
            let path = PathBuf::from(p);
            if path.is_dir() {
                if let Ok(rd) = fs::read_dir(&path) {
                    for e in rd.flatten() {
                        let q = e.path();
                        if is_go_source(&q) {
                            out.push(q);
                        }
                    }
                }
            } else if is_go_source(&path) {
                out.push(path);
            }
        }
    }
    out
}

fn collect_recursive(root: &Path, out: &mut Vec<PathBuf>) {
    if let Ok(rd) = fs::read_dir(root) {
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() {
                collect_recursive(&p, out);
            } else if is_go_source(&p) {
                out.push(p);
            }
        }
    }
}

fn is_go_source(path: &Path) -> bool {
    path.extension().and_then(|s| s.to_str()) == Some("go")
        && !path.file_name().unwrap_or_default().to_string_lossy().ends_with("_test.go")
}

fn process_path(path: &Path, opt: &Opt) -> Result<(), String> {
    let src = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let info = parse_file(&src);
    if info.package.is_empty() {
        return Ok(());
    }
    let test_path = sibling_test_path(path);
    let existing_src = fs::read_to_string(&test_path).ok();
    let existing_tests = existing_src.as_deref().map(existing_test_names).unwrap_or_default();
    let mut funcs = select_funcs(&info.funcs, opt)?;
    funcs.retain(|f| !existing_tests.contains(&test_name(f)));
    if funcs.is_empty() {
        return Ok(());
    }
    for f in &funcs {
        println!("Generated {}", test_name(f));
    }
    let generated = if let Some(existing) = &existing_src {
        let mut out = existing.trim_end().to_string();
        out.push_str("\n\n");
        out.push_str(&render_funcs_only(&info, &funcs, opt));
        out
    } else {
        render_file(&info, &funcs, opt)
    };
    if opt.write {
        fs::write(test_path, generated).map_err(|e| e.to_string())?;
    } else {
        print!("{}", generated);
    }
    Ok(())
}

fn sibling_test_path(path: &Path) -> PathBuf {
    let mut out = path.to_path_buf();
    let stem = path.file_stem().unwrap_or_default().to_string_lossy();
    out.set_file_name(format!("{}_test.go", stem));
    out
}

fn existing_test_names(src: &str) -> Vec<String> {
    let re = Regex::new(r"\bfunc\s+(Test[A-Za-z0-9_]+)\s*\(").unwrap();
    re.captures_iter(src).map(|c| c[1].to_string()).collect()
}

fn select_funcs(funcs: &[Func], opt: &Opt) -> Result<Vec<Func>, String> {
    let only = opt.only.as_ref().map(|s| Regex::new(s)).transpose().map_err(|e| e.to_string())?;
    let excl = opt.excl.as_ref().map(|s| Regex::new(s)).transpose().map_err(|e| e.to_string())?;
    Ok(funcs
        .iter()
        .filter(|f| {
            let n = &f.name;
            if let Some(re) = &excl {
                return !re.is_match(n);
            }
            if opt.exported {
                return n.chars().next().map(|c| c.is_uppercase()).unwrap_or(false);
            }
            if let Some(re) = &only {
                return re.is_match(n);
            }
            opt.all
        })
        .cloned()
        .collect())
}

fn parse_file(src: &str) -> FileInfo {
    let clean = strip_comments(src);
    let mut info = FileInfo::default();
    let pkg_re = Regex::new(r"(?m)^\s*package\s+([A-Za-z_][A-Za-z0-9_]*)").unwrap();
    if let Some(c) = pkg_re.captures(&clean) {
        info.package = c[1].to_string();
    }
    parse_structs(&clean, &mut info);
    parse_funcs(&clean, &mut info);
    info
}

fn strip_comments(src: &str) -> String {
    let block = Regex::new(r"(?s)/\*.*?\*/").unwrap();
    let s = block.replace_all(src, "");
    let line = Regex::new(r"(?m)//.*$").unwrap();
    line.replace_all(&s, "").to_string()
}

fn parse_structs(src: &str, info: &mut FileInfo) {
    let re = Regex::new(r"(?s)type\s+([A-Za-z_][A-Za-z0-9_]*)(?:\s*\[[^\]]+\])?\s+struct\s*\{(.*?)\}").unwrap();
    for cap in re.captures_iter(src) {
        let name = cap[1].to_string();
        let mut fields = Vec::new();
        for line in cap[2].lines() {
            let l = line.trim();
            if l.is_empty() || l.starts_with('`') {
                continue;
            }
            let l = l.split('`').next().unwrap_or(l).trim().trim_end_matches(',');
            let parts: Vec<&str> = l.split_whitespace().collect();
            if parts.len() >= 2 {
                let typ = parts[1..].join(" ");
                for nm in parts[0].split(',') {
                    let nm = nm.trim();
                    if !nm.is_empty() && nm.chars().next().unwrap().is_alphabetic() && !typ.contains('T') {
                        fields.push(Param { name: nm.to_string(), typ: typ.clone(), variadic: false });
                    }
                }
            }
        }
        info.structs.insert(name, StructDef { fields });
    }
}

fn parse_funcs(src: &str, info: &mut FileInfo) {
    let re = Regex::new(r"(?s)\bfunc\s+(?:\(([^)]*)\)\s*)?([A-Za-z_][A-Za-z0-9_]*)(\[[^\]]+\])?\s*\((.*?)\)\s*(\([^)]*\)|[^\s\{]+)?\s*\{").unwrap();
    for cap in re.captures_iter(src) {
        let recv = cap.get(1).map(|m| m.as_str().trim().to_string());
        let (receiver_name, receiver_type, receiver_ptr) = recv.map(parse_receiver).unwrap_or((None, None, false));
        let type_args_raw = cap.get(3).map(|m| m.as_str()).unwrap_or("");
        let mut type_map = type_arg_map(type_args_raw);
        if let Some(rt) = &receiver_type {
            for id in receiver_type_params(rt) {
                type_map.entry(id).or_insert_with(|| "string".to_string());
            }
        }
        let params = parse_params(cap.get(4).map(|m| m.as_str()).unwrap_or(""), &type_map);
        let returns = parse_returns(cap.get(5).map(|m| m.as_str()).unwrap_or(""), &type_map);
        info.funcs.push(Func {
            name: cap[2].to_string(),
            receiver_name,
            receiver_type,
            receiver_ptr,
            type_args: concrete_type_args(type_args_raw),
            params,
            returns,
        });
    }
}

fn parse_receiver(s: String) -> (Option<String>, Option<String>, bool) {
    let parts: Vec<&str> = s.split_whitespace().collect();
    if parts.is_empty() {
        return (None, None, false);
    }
    let (name, typ) = if parts.len() == 1 { ("", parts[0]) } else { (parts[0], parts[1]) };
    let ptr = typ.starts_with('*');
    let typ = typ.trim_start_matches('*').to_string();
    (Some(name.to_string()), Some(typ), ptr)
}

fn type_arg_map(raw: &str) -> HashMap<String, String> {
    let mut m = HashMap::new();
    let inner = raw.trim().trim_start_matches('[').trim_end_matches(']');
    for part in split_top(inner, ',') {
        let toks: Vec<&str> = part.split_whitespace().collect();
        if toks.len() >= 2 {
            m.insert(toks[0].to_string(), concrete_for_constraint(&toks[1..].join(" ")));
        }
    }
    m
}

fn concrete_type_args(raw: &str) -> String {
    let inner = raw.trim().trim_start_matches('[').trim_end_matches(']');
    if inner.is_empty() {
        return String::new();
    }
    let vals: Vec<String> = split_top(inner, ',')
        .iter()
        .filter_map(|p| {
            let toks: Vec<&str> = p.split_whitespace().collect();
            if toks.len() >= 2 { Some(concrete_for_constraint(&toks[1..].join(" "))) } else { None }
        })
        .collect();
    if vals.is_empty() { String::new() } else { format!("[{}]", vals.join(", ")) }
}

fn receiver_type_params(t: &str) -> Vec<String> {
    let Some(start) = t.find('[') else { return Vec::new(); };
    let Some(end) = t.rfind(']') else { return Vec::new(); };
    split_top(&t[start + 1..end], ',')
        .into_iter()
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect()
}

fn concrete_for_constraint(c: &str) -> String {
    let c = c.trim();
    if c == "comparable" { "string".into() }
    else if c == "any" || c == "interface{}" { "int".into() }
    else {
        c.split('|').next().unwrap_or("int").trim().trim_start_matches('~').to_string()
    }
}

fn apply_type_map(t: &str, m: &HashMap<String, String>) -> String {
    let mut out = t.trim().to_string();
    for (k, v) in m {
        let re = Regex::new(&format!(r"\b{}\b", regex::escape(k))).unwrap();
        out = re.replace_all(&out, v.as_str()).to_string();
    }
    out
}

fn parse_params(s: &str, type_map: &HashMap<String, String>) -> Vec<Param> {
    let mut out = Vec::new();
    let mut anon = 0;
    let mut pending_names: Vec<String> = Vec::new();
    for part in split_top(s, ',') {
        let p = part.trim();
        if p.is_empty() { continue; }
        let toks: Vec<&str> = p.split_whitespace().collect();
        if toks.len() >= 2 {
            let typ = apply_type_map(&toks[1..].join(" "), type_map);
            let variadic = typ.starts_with("...");
            let typ2 = if variadic { format!("[]{}", typ.trim_start_matches("...")) } else { typ };
            let mut names: Vec<String> = pending_names.drain(..).collect();
            for nm in toks[0].split(',') {
                let nm = nm.trim();
                if !nm.is_empty() {
                    names.push(nm.to_string());
                }
            }
            for nm in names {
                out.push(Param { name: nm, typ: typ2.clone(), variadic });
            }
        } else {
            let looks_like_type = p.starts_with('*') || p.starts_with("[]") || p.starts_with("map[") || p.starts_with("func(") || p == "error" || p.chars().next().map(|c| c.is_uppercase()).unwrap_or(false);
            if looks_like_type {
                anon += 1;
                out.push(Param { name: format!("arg{}", anon), typ: apply_type_map(p, type_map), variadic: false });
            } else {
                pending_names.push(p.to_string());
            }
        }
    }
    out
}

fn parse_returns(s: &str, type_map: &HashMap<String, String>) -> Vec<Ret> {
    let s = s.trim();
    if s.is_empty() { return Vec::new(); }
    let inner = if s.starts_with('(') && s.ends_with(')') { &s[1..s.len()-1] } else { s };
    split_top(inner, ',').into_iter().filter_map(|p| {
        let p = p.trim();
        if p.is_empty() { None } else {
            let toks: Vec<&str> = p.split_whitespace().collect();
            let typ = if toks.len() >= 2 { toks.last().unwrap().to_string() } else { p.to_string() };
            Some(Ret { typ: apply_type_map(&typ, type_map) })
        }
    }).collect()
}

fn split_top(s: &str, sep: char) -> Vec<String> {
    let mut out = Vec::new();
    let mut depth = 0i32;
    let mut start = 0usize;
    for (i, ch) in s.char_indices() {
        match ch {
            '(' | '[' | '{' => depth += 1,
            ')' | ']' | '}' => depth -= 1,
            c if c == sep && depth == 0 => {
                out.push(s[start..i].trim().to_string());
                start = i + ch.len_utf8();
            }
            _ => {}
        }
    }
    if start <= s.len() {
        out.push(s[start..].trim().to_string());
    }
    out
}

fn render_file(info: &FileInfo, funcs: &[Func], opt: &Opt) -> String {
    let needs_deep = funcs.iter().any(|f| f.returns.iter().any(|r| !is_error(&r.typ) && !is_comparable(&r.typ)));
    let mut s = String::new();
    s.push_str(&format!("package {}\n\n", info.package));
    if needs_deep && opt.use_go_cmp {
        s.push_str("import (\n\t\"testing\"\n\n\t\"github.com/google/go-cmp/cmp\"\n)\n\n");
    } else if needs_deep {
        s.push_str("import (\n\t\"reflect\"\n\t\"testing\"\n)\n\n");
    } else {
        s.push_str("import \"testing\"\n\n");
    }
    for (i, f) in funcs.iter().enumerate() {
        if i > 0 { s.push('\n'); }
        s.push_str(&render_func(info, f, opt));
    }
    s
}

fn render_funcs_only(info: &FileInfo, funcs: &[Func], opt: &Opt) -> String {
    let mut s = String::new();
    for (i, f) in funcs.iter().enumerate() {
        if i > 0 { s.push('\n'); }
        s.push_str(&render_func(info, f, opt));
    }
    s
}

fn is_error(t: &str) -> bool { t.trim() == "error" }
fn is_comparable(t: &str) -> bool {
    let t = t.trim();
    !(t.starts_with("[]") || t.starts_with("map[") || t.starts_with("func("))
}

fn test_name(f: &Func) -> String {
    if let Some(rt) = &f.receiver_type {
        let b = base_type(rt);
        let sep = if b.chars().next().map(|c| c.is_lowercase()).unwrap_or(false) { "_" } else { "" };
        format!("Test{}{}_{}", sep, b, f.name)
    } else {
        format!("Test{}", f.name)
    }
}

fn base_type(t: &str) -> String {
    t.split('[').next().unwrap_or(t).trim_start_matches('*').to_string()
}

fn receiver_concrete(t: &str) -> String {
    t.replace("[T]", "[string]")
}

fn render_func(info: &FileInfo, f: &Func, opt: &Opt) -> String {
    let mut s = String::new();
    s.push_str(&format!("func {}(t *testing.T) {{\n", test_name(f)));
    if opt.parallel { s.push_str("\tt.Parallel()\n"); }
    let recv_base = f.receiver_type.as_ref().map(|x| base_type(x));
    let fields = recv_base.as_ref().and_then(|b| info.structs.get(b));
    let use_fields = fields.filter(|d| !d.fields.is_empty());
    if let Some(def) = use_fields {
        s.push_str("\ttype fields struct {\n");
        let width = def.fields.iter().map(|p| p.name.len()).max().unwrap_or(0);
        for p in &def.fields { s.push_str(&field_line(2, &p.name, &p.typ, width)); }
        s.push_str("\t}\n");
    }
    if !f.params.is_empty() {
        s.push_str("\ttype args struct {\n");
        let width = f.params.iter().map(|p| p.name.len()).max().unwrap_or(0);
        for p in &f.params { s.push_str(&field_line(2, &p.name, &p.typ, width)); }
        s.push_str("\t}\n");
    }
    s.push_str(if opt.named { "\ttests := map[string]struct {\n" } else { "\ttests := []struct {\n" });
    let mut test_fields: Vec<(String, String)> = Vec::new();
    if !opt.named { test_fields.push(("name".into(), "string".into())); }
    if use_fields.is_some() {
        test_fields.push(("fields".into(), "fields".into()));
    } else if let (Some(rn), Some(rt)) = (&f.receiver_name, &f.receiver_type) {
        let name = if rn.is_empty() { "receiver" } else { rn };
        let typ = if f.receiver_ptr { format!("*{}", receiver_concrete(rt)) } else { receiver_concrete(rt) };
        test_fields.push((name.to_string(), typ));
    }
    if !f.params.is_empty() { test_fields.push(("args".into(), "args".into())); }
    let non_err: Vec<&Ret> = f.returns.iter().filter(|r| !is_error(&r.typ)).collect();
    let has_err = f.returns.iter().any(|r| is_error(&r.typ));
    for (i, r) in non_err.iter().enumerate() {
        let nm = if i == 0 { "want".to_string() } else { format!("want{}", i) };
        test_fields.push((nm, r.typ.clone()));
    }
    if has_err { test_fields.push(("wantErr".into(), "bool".into())); }
    let width = test_fields.iter().map(|(n, _)| n.len()).max().unwrap_or(0);
    for (n, t) in test_fields {
        s.push_str(&field_line(2, &n, &t, width));
    }
    s.push_str("\t}{\n\t\t// TODO: Add test cases.\n\t}\n");
    let loop_head = if opt.named { "\tfor name, tt := range tests {\n" } else { "\tfor _, tt := range tests {\n" };
    s.push_str(loop_head);
    if opt.nosubtests {
        s.push_str(&render_body(info, f, opt, 2, false));
    } else {
        let run_name = if opt.named { "name" } else { "tt.name" };
        s.push_str(&format!("\t\tt.Run({}, func(t *testing.T) {{\n", run_name));
        if opt.parallel { s.push_str("\t\t\tt.Parallel()\n"); }
        s.push_str(&render_body(info, f, opt, 3, true));
        s.push_str("\t\t})\n");
    }
    s.push_str("\t}\n}\n");
    s
}

fn field_line(indent: usize, name: &str, typ: &str, width: usize) -> String {
    format!("{}{}{}{}\n", "\t".repeat(indent), name, " ".repeat(width.saturating_sub(name.len()) + 1), typ)
}

fn render_body(info: &FileInfo, f: &Func, opt: &Opt, indent: usize, subtest: bool) -> String {
    let mut s = String::new();
    let tab = "\t".repeat(indent);
    if let Some(rt) = &f.receiver_type {
        let recv = f.receiver_name.as_deref().filter(|x| !x.is_empty()).unwrap_or("receiver");
        let typ = receiver_concrete(rt);
        let base = base_type(rt);
        let fields = info.structs.get(&base).filter(|d| !d.fields.is_empty());
        if fields.is_none() {
            if f.receiver_ptr {
                s.push_str(&format!("{}{} := &{}{{}}\n", tab, recv, typ));
            } else {
                s.push_str(&format!("{}{} := {}{{}}\n", tab, recv, typ));
            }
        } else if f.receiver_ptr {
            s.push_str(&format!("{}{} := &{}{{\n", tab, recv, typ));
            if let Some(def) = fields {
                for p in &def.fields {
                    s.push_str(&format!("{}\t{}: tt.fields.{},\n", tab, p.name, p.name));
                }
            }
            s.push_str(&format!("{}}}\n", tab));
        } else if let Some(def) = fields {
            s.push_str(&format!("{}{} := {}{{\n", tab, recv, typ));
            for p in &def.fields {
                s.push_str(&format!("{}\t{}: tt.fields.{},\n", tab, p.name, p.name));
            }
            s.push_str(&format!("{}}}\n", tab));
        }
    }
    let call = call_expr(f);
    let non_err_count = f.returns.iter().filter(|r| !is_error(&r.typ)).count();
    let has_err = f.returns.iter().any(|r| is_error(&r.typ));
    if f.returns.is_empty() {
        s.push_str(&format!("{}{}\n", tab, call));
        return s;
    }
    if has_err {
        let lhs = if non_err_count == 0 { "err".to_string() } else if non_err_count == 1 { "got, err".to_string() } else {
            let mut v: Vec<String> = (0..non_err_count).map(|i| if i == 0 { "got".into() } else { format!("got{}", i) }).collect();
            v.push("err".into());
            v.join(", ")
        };
        s.push_str(&format!("{}{} := {}\n", tab, lhs, call));
        s.push_str(&format!("{}if (err != nil) != tt.wantErr {{\n", tab));
        s.push_str(&format!("{}\t{}\n", tab, err_line(f, opt, subtest)));
        if opt.nosubtests && !subtest {
            s.push_str(&format!("{}\tcontinue\n", tab));
        }
        s.push_str(&format!("{}}}\n", tab));
        s.push_str(&format!("{}if tt.wantErr {{\n{}\treturn\n{}}}\n", tab, tab, tab));
        for i in 0..non_err_count {
            s.push_str(&compare_block(f, opt, indent, i, subtest, non_err_count > 1));
        }
    } else if non_err_count == 1 {
        s.push_str(&format!("{}if got := {}; ", tab, call));
        s.push_str(&compare_condition(&f.returns[0].typ, opt, "got", "tt.want"));
        s.push_str(" {\n");
        s.push_str(&format!("{}\t{}\n", tab, errorf_line(f, opt, 0, subtest, false)));
        s.push_str(&format!("{}}}\n", tab));
    } else {
        let lhs: Vec<String> = (0..non_err_count).map(|i| if i == 0 { "got".into() } else { format!("got{}", i) }).collect();
        s.push_str(&format!("{}{} := {}\n", tab, lhs.join(", "), call));
        for i in 0..non_err_count {
            s.push_str(&compare_block(f, opt, indent, i, subtest, true));
        }
    }
    s
}

fn call_expr(f: &Func) -> String {
    let args: Vec<String> = f.params.iter().map(|p| {
        if p.variadic { format!("tt.args.{}...", p.name) } else { format!("tt.args.{}", p.name) }
    }).collect();
    let callee = if let Some(recv) = &f.receiver_name {
        let r = if recv.is_empty() { "receiver" } else { recv };
        format!("{}.{}", r, f.name)
    } else {
        format!("{}{}", f.name, f.type_args)
    };
    format!("{}({})", callee, args.join(", "))
}

fn display_name(f: &Func) -> String {
    if let Some(rt) = &f.receiver_type {
        format!("{}.{}", base_type(rt), f.name)
    } else { f.name.clone() }
}

fn compare_block(f: &Func, opt: &Opt, indent: usize, idx: usize, subtest: bool, multi: bool) -> String {
    let tab = "\t".repeat(indent);
    let got = if idx == 0 { "got".to_string() } else { format!("got{}", idx) };
    let want = if idx == 0 { "tt.want".to_string() } else { format!("tt.want{}", idx) };
    let typ = f.returns.iter().filter(|r| !is_error(&r.typ)).nth(idx).unwrap().typ.clone();
    let mut s = String::new();
    s.push_str(&format!("{}if {} {{\n", tab, compare_condition(&typ, opt, &got, &want)));
    s.push_str(&format!("{}\t{}\n", tab, errorf_line(f, opt, idx, subtest, multi)));
    s.push_str(&format!("{}}}\n", tab));
    s
}

fn compare_condition(typ: &str, opt: &Opt, got: &str, want: &str) -> String {
    if is_comparable(typ) {
        format!("{} != {}", got, want)
    } else if opt.use_go_cmp {
        format!("!cmp.Equal({}, {})", want, got)
    } else {
        format!("!reflect.DeepEqual({}, {})", got, want)
    }
}

fn errorf_line(f: &Func, opt: &Opt, idx: usize, subtest: bool, multi: bool) -> String {
    let got = if idx == 0 { "got".to_string() } else { format!("got{}", idx) };
    let want = if idx == 0 { "tt.want".to_string() } else { format!("tt.want{}", idx) };
    let prefix = if opt.nosubtests && !subtest { "%q. " } else { "" };
    let name = display_name(f);
    let label = if multi { if idx == 0 { "got".to_string() } else { format!("got{}", idx) } } else { String::new() };
    let input_vals: Vec<String> = f.params.iter().map(|p| format!("tt.args.{}", p.name)).collect();
    let deep = f.returns.iter().filter(|r| !is_error(&r.typ)).nth(idx).map(|r| !is_comparable(&r.typ)).unwrap_or(false);
    let mut args = Vec::new();
    if opt.nosubtests && !subtest { args.push("tt.name".to_string()); }
    if opt.inputs && !input_vals.is_empty() {
        args.extend(input_vals.iter().cloned());
    }
    args.push(got.clone());
    args.push(want.clone());
    if deep && opt.use_go_cmp {
        args.push(format!("cmp.Diff({}, {})", want, got));
    }
    let fmt = if opt.inputs && !input_vals.is_empty() {
        if multi {
            format!("{}{}({}) {} = %v, want %v", prefix, name, vec!["%v"; input_vals.len()].join(", "), label)
        } else {
            format!("{}{}({}) = %v, want %v", prefix, name, vec!["%v"; input_vals.len()].join(", "))
        }
    } else if multi {
        format!("{}{}() {} = %v, want %v", prefix, name, label)
    } else if deep && opt.use_go_cmp {
        format!("{}{}() = %v, want %v\\ndiff=%s", prefix, name)
    } else {
        format!("{}{}() = %v, want %v", prefix, name)
    };
    format!("t.Errorf(\"{}\", {})", fmt, args.join(", "))
}

fn err_line(f: &Func, opt: &Opt, subtest: bool) -> String {
    let prefix = if opt.nosubtests && !subtest { "%q. " } else { "" };
    let name = display_name(f);
    let input_vals: Vec<String> = f.params.iter().map(|p| format!("tt.args.{}", p.name)).collect();
    let mut args = Vec::new();
    if opt.nosubtests && !subtest { args.push("tt.name".to_string()); }
    let fmt = if opt.inputs && !input_vals.is_empty() {
        args.extend(input_vals.iter().cloned());
        format!("{}{}({}) error = %v, wantErr %v", prefix, name, vec!["%v"; input_vals.len()].join(", "))
    } else {
        format!("{}{}() error = %v, wantErr %v", prefix, name)
    };
    args.push("err".to_string());
    args.push("tt.wantErr".to_string());
    let meth = if opt.nosubtests && !subtest { "t.Errorf" } else { "t.Fatalf" };
    format!("{}(\"{}\", {})", meth, fmt, args.join(", "))
}
