use serde::Serialize;
use std::collections::HashMap;
use std::env;
use std::fs::{self, File, OpenOptions};
use std::process::{Command, Stdio};
use std::time::Instant;

const HELP: &str = r#"A command-line benchmarking tool.

Usage: executable [OPTIONS] <command>...

Arguments:
  <command>...
          The command to benchmark. This can be the name of an executable, a
          command line like "grep -i todo" or a shell command like "sleep 0.5 &&
          echo test". The latter is only available if the shell is not
          explicitly disabled via '--shell=none'. If multiple commands are
          given, hyperfine will show a comparison of the respective runtimes.

Options:
  -w, --warmup <NUM>
          Perform NUM warmup runs before the actual benchmark.
  -m, --min-runs <NUM>
          Perform at least NUM runs for each command (default: 10).
  -M, --max-runs <NUM>
          Perform at most NUM runs for each command.
  -r, --runs <NUM>
          Perform exactly NUM runs for each command.
  -s, --setup <CMD>
          Execute CMD before each set of timing runs.
      --reference <CMD>
          The reference command for the relative comparison of results.
      --reference-name <CMD>
          Give a meaningful name to the reference command.
  -p, --prepare <CMD>
          Execute CMD before each timing run.
  -C, --conclude <CMD>
          Execute CMD after each timing run.
  -c, --cleanup <CMD>
          Execute CMD after the completion of all benchmarking runs.
  -P, --parameter-scan <VAR> <MIN> <MAX>
          Perform benchmark runs for each value in the range MIN..MAX.
  -D, --parameter-step-size <DELTA>
          Traverse the range MIN..MAX in steps of DELTA.
  -L, --parameter-list <VAR> <VALUES>
          Perform benchmark runs for each value in the comma-separated list.
  -S, --shell <SHELL>
          Set the shell to use for executing benchmarked commands.
  -N
          An alias for '--shell=none'.
  -i, --ignore-failure[=<MODE>]
          Ignore failures of the benchmarked programs.
      --style <TYPE>
          Set output style type (default: auto).
      --sort <METHOD>
          Specify the sort order.
  -u, --time-unit <UNIT>
          Set the time unit to be used.
      --export-asciidoc <FILE>
      --export-csv <FILE>
      --export-json <FILE>
      --export-markdown <FILE>
      --export-orgmode <FILE>
      --show-output
          Print the stdout and stderr of the benchmark instead of suppressing it.
      --output <WHERE>
          Control where the output of the benchmark is redirected.
      --input <WHERE>
          Control where the input of the benchmark comes from.
  -n, --command-name <NAME>
          Give a meaningful name to a command.
  -h, --help
          Print help
  -V, --version
          Print version
"#;

#[derive(Default, Debug)]
struct Opt {
    warmup: usize,
    min_runs: usize,
    max_runs: Option<usize>,
    runs: Option<usize>,
    setup: Vec<String>,
    prepare: Vec<String>,
    conclude: Vec<String>,
    cleanup: Vec<String>,
    param_scans: Vec<(String, String, String)>,
    step: Option<String>,
    param_lists: Vec<(String, Vec<String>)>,
    shell: String,
    shell_none: bool,
    ignore: Option<Vec<i32>>,
    style: String,
    sort: String,
    unit: Option<String>,
    export_csv: Option<String>,
    export_json: Option<String>,
    export_md: Option<String>,
    export_adoc: Option<String>,
    export_org: Option<String>,
    show_output: bool,
    outputs: Vec<String>,
    input: String,
    names: Vec<String>,
    reference: Option<String>,
    reference_name: Option<String>,
    commands: Vec<String>,
}

#[derive(Clone)]
struct Bench {
    command: String,
    name: String,
    params: HashMap<String, String>,
}

#[derive(Serialize, Clone)]
struct JsonResult {
    command: String,
    mean: f64,
    stddev: Option<f64>,
    median: f64,
    user: f64,
    system: f64,
    min: f64,
    max: f64,
    times: Vec<f64>,
    memory_usage_byte: Vec<u64>,
    exit_codes: Vec<i32>,
}

#[derive(Serialize)]
struct JsonOut {
    results: Vec<JsonResult>,
}

fn main() {
    let opt = match parse_args() {
        Ok(o) => o,
        Err((msg, code)) => {
            eprintln!("{msg}");
            std::process::exit(code);
        }
    };
    if let Err(e) = run(opt) {
        eprintln!("{e}");
        std::process::exit(1);
    }
}

fn next_arg(args: &[String], i: &mut usize, flag: &str) -> Result<String, (String, i32)> {
    *i += 1;
    args.get(*i)
        .cloned()
        .ok_or_else(|| (format!("error: a value is required for '{flag}' but none was supplied"), 2))
}

fn parse_usize_arg(s: &str, flag: &str) -> Result<usize, (String, i32)> {
    s.parse::<usize>()
        .map_err(|e| (format!("Error: Could not read numeric integer argument to '{flag}': {e}"), 1))
}

fn parse_args() -> Result<Opt, (String, i32)> {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print!("{HELP}");
        std::process::exit(0);
    }
    if args.iter().any(|a| a == "-V" || a == "--version") {
        println!("hyperfine 1.20.0");
        std::process::exit(0);
    }
    let mut o = Opt {
        min_runs: 10,
        shell: "default".into(),
        style: "auto".into(),
        sort: "auto".into(),
        input: "null".into(),
        ..Default::default()
    };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-w" | "--warmup" => {
                let v = next_arg(&args, &mut i, a)?;
                o.warmup = parse_usize_arg(&v, a)?;
            }
            "-m" | "--min-runs" => {
                let v = next_arg(&args, &mut i, a)?;
                o.min_runs = parse_usize_arg(&v, a)?;
            }
            "-M" | "--max-runs" => {
                let v = next_arg(&args, &mut i, a)?;
                o.max_runs = Some(parse_usize_arg(&v, a)?);
            }
            "-r" | "--runs" => {
                let v = next_arg(&args, &mut i, a)?;
                o.runs = Some(parse_usize_arg(&v, "--runs")?);
            }
            "-s" | "--setup" => o.setup.push(next_arg(&args, &mut i, a)?),
            "-p" | "--prepare" => o.prepare.push(next_arg(&args, &mut i, a)?),
            "-C" | "--conclude" => o.conclude.push(next_arg(&args, &mut i, a)?),
            "-c" | "--cleanup" => o.cleanup.push(next_arg(&args, &mut i, a)?),
            "--reference" => o.reference = Some(next_arg(&args, &mut i, a)?),
            "--reference-name" => o.reference_name = Some(next_arg(&args, &mut i, a)?),
            "-P" | "--parameter-scan" => {
                let var = next_arg(&args, &mut i, a)?;
                let min = next_arg(&args, &mut i, a)?;
                let max = next_arg(&args, &mut i, a)?;
                o.param_scans.push((var, min, max));
            }
            "-D" | "--parameter-step-size" => o.step = Some(next_arg(&args, &mut i, a)?),
            "-L" | "--parameter-list" => {
                let var = next_arg(&args, &mut i, a)?;
                let values = next_arg(&args, &mut i, a)?
                    .split(',')
                    .map(|s| s.to_string())
                    .collect();
                o.param_lists.push((var, values));
            }
            "-S" | "--shell" => {
                o.shell = next_arg(&args, &mut i, a)?;
                o.shell_none = o.shell == "none";
            }
            "-N" => {
                o.shell = "none".into();
                o.shell_none = true;
            }
            "-i" | "--ignore-failure" => o.ignore = Some(Vec::new()),
            "--show-output" => o.show_output = true,
            "--style" => o.style = next_arg(&args, &mut i, a)?,
            "--sort" => o.sort = next_arg(&args, &mut i, a)?,
            "-u" | "--time-unit" => o.unit = Some(next_arg(&args, &mut i, a)?),
            "--export-csv" => o.export_csv = Some(next_arg(&args, &mut i, a)?),
            "--export-json" => o.export_json = Some(next_arg(&args, &mut i, a)?),
            "--export-markdown" => o.export_md = Some(next_arg(&args, &mut i, a)?),
            "--export-asciidoc" => o.export_adoc = Some(next_arg(&args, &mut i, a)?),
            "--export-orgmode" => o.export_org = Some(next_arg(&args, &mut i, a)?),
            "--output" => o.outputs.push(next_arg(&args, &mut i, a)?),
            "--input" => o.input = next_arg(&args, &mut i, a)?,
            "-n" | "--command-name" => o.names.push(next_arg(&args, &mut i, a)?),
            _ if a.starts_with("--ignore-failure=") => {
                let val = a.trim_start_matches("--ignore-failure=");
                if val == "all-non-zero" {
                    o.ignore = Some(Vec::new());
                } else {
                    let mut codes = Vec::new();
                    for c in val.split(',') {
                        codes.push(c.parse::<i32>().map_err(|e| {
                            (format!("Error: Could not read numeric integer argument to '--ignore-failure': {e}"), 1)
                        })?);
                    }
                    o.ignore = Some(codes);
                }
            }
            _ if a.starts_with("--style=") => o.style = a[8..].to_string(),
            _ if a.starts_with("--sort=") => o.sort = a[7..].to_string(),
            _ if a.starts_with("--shell=") => {
                o.shell = a[8..].to_string();
                o.shell_none = o.shell == "none";
            }
            _ if a.starts_with("--output=") => o.outputs.push(a[9..].to_string()),
            _ if a.starts_with("--input=") => o.input = a[8..].to_string(),
            _ if a.starts_with('-') => return Err((format!("error: unexpected argument '{a}' found"), 2)),
            _ => o.commands.push(a.clone()),
        }
        i += 1;
    }
    validate(&o)?;
    Ok(o)
}

fn validate(o: &Opt) -> Result<(), (String, i32)> {
    if o.commands.is_empty() {
        return Err(("error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable <command>...\n\nFor more information, try '--help'.".into(), 2));
    }
    if o.show_output && o.style != "auto" {
        return Err((format!("error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\nUsage: executable --style <TYPE> <command>...\n\nFor more information, try '--help'."), 2));
    }
    if o.show_output && !o.outputs.is_empty() {
        return Err(("error: the argument '--show-output' cannot be used with '--output <WHERE>'\n\nUsage: executable --show-output <command>...\n\nFor more information, try '--help'.".into(), 2));
    }
    let styles = ["auto", "basic", "full", "nocolor", "color", "none"];
    if !styles.contains(&o.style.as_str()) {
        return Err((format!("error: invalid value '{}' for '--style <TYPE>'\n  [possible values: auto, basic, full, nocolor, color, none]\n\nFor more information, try '--help'.", o.style), 2));
    }
    let sorts = ["auto", "command", "mean-time"];
    if !sorts.contains(&o.sort.as_str()) {
        return Err((format!("error: invalid value '{}' for '--sort <METHOD>'\n  [possible values: auto, command, mean-time]\n\nFor more information, try '--help'.", o.sort), 2));
    }
    if let Some(u) = &o.unit {
        if !["microsecond", "millisecond", "second"].contains(&u.as_str()) {
            return Err((format!("error: invalid value '{u}' for '--time-unit <UNIT>'\n  [possible values: microsecond, millisecond, second]\n\nFor more information, try '--help'."), 2));
        }
    }
    if o.step.is_some() && o.param_scans.is_empty() {
        return Err(("Error: The '--parameter-step-size' option can only be used in combination with '--parameter-scan'.".into(), 1));
    }
    Ok(())
}

fn run(o: Opt) -> Result<(), String> {
    let benches = expand_benches(&o)?;
    let silent = o.style == "none";
    let mut results = Vec::new();
    for (idx, b) in benches.iter().enumerate() {
        if !silent {
            println!("Benchmark {}: {}", idx + 1, b.name);
        }
        for s in &o.setup {
            run_helper(&replace_params(s, &b.params), &o)?;
        }
        for _ in 0..o.warmup {
            run_command(&b.command, &o, idx, 0, false)?;
        }
        let runs = o.runs.unwrap_or_else(|| {
            if let Some(max) = o.max_runs {
                o.min_runs.min(max)
            } else {
                o.min_runs
            }
        });
        let mut times = Vec::new();
        let mut codes = Vec::new();
        for r in 0..runs {
            if let Some(p) = pick(&o.prepare, idx) {
                run_helper(&replace_params(p, &b.params), &o)?;
            }
            let start = Instant::now();
            let code = run_command(&b.command, &o, idx, r + 1, true)?;
            let t = start.elapsed().as_secs_f64();
            codes.push(code);
            if code != 0 && !ignored(&o, code) {
                return Err(format!("Error: Command terminated with non-zero exit code {code} in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong."));
            }
            times.push(t);
            if let Some(c) = pick(&o.conclude, idx) {
                run_helper(&replace_params(c, &b.params), &o)?;
            }
        }
        if let Some(c) = pick(&o.cleanup, idx) {
            run_helper(&replace_params(c, &b.params), &o)?;
        }
        let jr = summarize(&b.name, times, codes);
        if !silent {
            print_summary_line(&jr, &o);
            if jr.mean < 0.005 {
                println!("  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.");
            }
            if jr.exit_codes.iter().any(|&c| c != 0) && o.ignore.is_some() {
                println!("  Warning: Ignoring non-zero exit code.");
            }
            println!(" ");
        }
        results.push(jr);
    }
    if results.len() > 1 && !silent {
        print_comparison(&results, &o);
    }
    write_exports(&results, &o)?;
    Ok(())
}

fn expand_benches(o: &Opt) -> Result<Vec<Bench>, String> {
    let mut combos: Vec<HashMap<String, String>> = vec![HashMap::new()];
    for (var, vals) in &o.param_lists {
        let mut next = Vec::new();
        for c in &combos {
            for v in vals {
                let mut n = c.clone();
                n.insert(var.clone(), v.clone());
                next.push(n);
            }
        }
        combos = next;
    }
    for (var, min_s, max_s) in &o.param_scans {
        let min = min_s.parse::<f64>().map_err(|e| format!("Error: Could not parse parameter-scan minimum: {e}"))?;
        let max = max_s.parse::<f64>().map_err(|e| format!("Error: Could not parse parameter-scan maximum: {e}"))?;
        let step = o.step.as_deref().unwrap_or("1").parse::<f64>().map_err(|e| format!("Error: Could not parse parameter step size: {e}"))?;
        let decimals = [min_s, max_s, o.step.as_ref().unwrap_or(&"".to_string())]
            .iter()
            .filter_map(|s| s.split_once('.').map(|(_, f)| f.len()))
            .max()
            .unwrap_or(0);
        let mut vals = Vec::new();
        let mut x = min;
        while x <= max + step.abs() * 1e-9 {
            vals.push(if decimals == 0 { format!("{}", x.round() as i64) } else { format!("{x:.decimals$}") });
            x += step;
        }
        let mut next = Vec::new();
        for c in &combos {
            for v in &vals {
                let mut n = c.clone();
                n.insert(var.clone(), v.clone());
                next.push(n);
            }
        }
        combos = next;
    }
    if combos.is_empty() {
        combos.push(HashMap::new());
    }
    let mut out = Vec::new();
    for combo in combos {
        for (i, c) in o.commands.iter().enumerate() {
            let command = replace_params(c, &combo);
            let name = o.names.get(i).cloned().unwrap_or_else(|| command.clone());
            out.push(Bench { command, name, params: combo.clone() });
        }
    }
    Ok(out)
}

fn replace_params(s: &str, params: &HashMap<String, String>) -> String {
    let mut out = s.to_string();
    for (k, v) in params {
        out = out.replace(&format!("{{{k}}}"), v);
    }
    out
}

fn pick(v: &[String], idx: usize) -> Option<&String> {
    if v.is_empty() {
        None
    } else if v.len() == 1 {
        v.first()
    } else {
        v.get(idx)
    }
}

fn ignored(o: &Opt, code: i32) -> bool {
    match &o.ignore {
        None => false,
        Some(v) if v.is_empty() => code != 0,
        Some(v) => v.contains(&code),
    }
}

fn run_helper(cmd: &str, o: &Opt) -> Result<i32, String> {
    let mut c = shell_command(cmd, o);
    if o.show_output {
        c.stdout(Stdio::inherit()).stderr(Stdio::inherit());
    } else {
        c.stdout(Stdio::null()).stderr(Stdio::null());
    }
    let status = c.status().map_err(|e| format!("Error: Failed to execute '{cmd}': {e}"))?;
    let code = status.code().unwrap_or(1);
    if code != 0 {
        Err(format!("Error: Command '{cmd}' terminated with non-zero exit code {code}."))
    } else {
        Ok(code)
    }
}

fn run_command(cmd: &str, o: &Opt, idx: usize, iter: usize, measured: bool) -> Result<i32, String> {
    let mut c = if o.shell_none { direct_command(cmd) } else { shell_command(cmd, o) };
    c.env("HYPERFINE_ITERATION", iter.to_string());
    setup_stdio(&mut c, o, idx, measured)?;
    let status = c.status().map_err(|e| format!("Error: Failed to execute '{cmd}': {e}"))?;
    Ok(status.code().unwrap_or(1))
}

fn shell_command(cmd: &str, o: &Opt) -> Command {
    let shell = if o.shell == "default" || o.shell.is_empty() { "/bin/sh" } else { &o.shell };
    let mut parts = split_words(shell);
    let prog = parts.remove(0);
    let mut c = Command::new(prog);
    c.args(parts).arg("-c").arg(cmd);
    c
}

fn direct_command(cmd: &str) -> Command {
    let mut parts = split_words(cmd);
    let prog = if parts.is_empty() { String::new() } else { parts.remove(0) };
    let mut c = Command::new(prog);
    c.args(parts);
    c
}

fn split_words(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut quote: Option<char> = None;
    for ch in s.chars() {
        if let Some(q) = quote {
            if ch == q {
                quote = None;
            } else {
                cur.push(ch);
            }
        } else if ch == '\'' || ch == '"' {
            quote = Some(ch);
        } else if ch.is_whitespace() {
            if !cur.is_empty() {
                out.push(std::mem::take(&mut cur));
            }
        } else {
            cur.push(ch);
        }
    }
    if !cur.is_empty() {
        out.push(cur);
    }
    out
}

fn setup_stdio(c: &mut Command, o: &Opt, idx: usize, measured: bool) -> Result<(), String> {
    if o.input == "null" {
        c.stdin(Stdio::null());
    } else {
        c.stdin(File::open(&o.input).map_err(|e| format!("Error: Could not open input file '{}': {e}", o.input))?);
    }
    if o.show_output {
        c.stdout(Stdio::inherit()).stderr(Stdio::inherit());
        return Ok(());
    }
    let where_to = pick(&o.outputs, idx).map(String::as_str).unwrap_or("null");
    match where_to {
        "null" => {
            c.stdout(Stdio::null()).stderr(Stdio::null());
        }
        "pipe" => {
            c.stdout(Stdio::null()).stderr(Stdio::null());
        }
        "inherit" => {
            c.stdout(Stdio::inherit()).stderr(Stdio::inherit());
        }
        path => {
            let f = OpenOptions::new().create(true).append(measured).write(true).truncate(!measured).open(path)
                .map_err(|e| format!("Error: Could not open output file '{path}': {e}"))?;
            let f2 = f.try_clone().map_err(|e| e.to_string())?;
            c.stdout(Stdio::from(f)).stderr(Stdio::from(f2));
        }
    }
    Ok(())
}

fn summarize(command: &str, mut times: Vec<f64>, codes: Vec<i32>) -> JsonResult {
    let mean = times.iter().sum::<f64>() / times.len().max(1) as f64;
    let stddev = if times.len() > 1 {
        let var = times.iter().map(|t| (t - mean).powi(2)).sum::<f64>() / (times.len() - 1) as f64;
        Some(var.sqrt())
    } else {
        None
    };
    let min = times.iter().copied().fold(f64::INFINITY, f64::min);
    let max = times.iter().copied().fold(0.0, f64::max);
    times.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let median = if times.is_empty() { 0.0 } else { times[times.len() / 2] };
    JsonResult {
        command: command.into(),
        mean,
        stddev,
        median,
        user: 0.0,
        system: 0.0,
        min,
        max,
        times,
        memory_usage_byte: vec![0; codes.len()],
        exit_codes: codes,
    }
}

fn print_summary_line(r: &JsonResult, o: &Opt) {
    let (mean, unit) = format_time(r.mean, o);
    if let Some(sd) = r.stddev {
        let (sdv, _) = format_time(sd, o);
        let (mn, _) = format_time(r.min, o);
        let (mx, _) = format_time(r.max, o);
        println!("  Time (mean ± σ):    {:>8} {} ± {:>5} {}    [User: 0.0 ms, System: 0.0 ms]", mean, unit, sdv, unit);
        println!("  Range (min … max):  {:>8} {} … {:>5} {}    {} runs", mn, unit, mx, unit, r.times.len());
    } else {
        println!("  Time (abs ≡):       {:>8} {}               [User: 0.0 ms, System: 0.0 ms]", mean, unit);
    }
    println!(" ");
}

fn format_time(t: f64, o: &Opt) -> (String, &'static str) {
    match o.unit.as_deref() {
        Some("second") => (format!("{:.3}", t), "s"),
        Some("microsecond") => (format!("{:.1}", t * 1e6), "µs"),
        Some("millisecond") => (format!("{:.1}", t * 1e3), "ms"),
        _ if t < 0.001 => (format!("{:.1}", t * 1e6), "µs"),
        _ if t < 1.0 => (format!("{:.1}", t * 1e3), "ms"),
        _ => (format!("{:.3}", t), "s"),
    }
}

fn print_comparison(results: &[JsonResult], o: &Opt) {
    let mut refs: Vec<&JsonResult> = results.iter().collect();
    if o.sort == "mean-time" || o.sort == "auto" {
        refs.sort_by(|a, b| a.mean.partial_cmp(&b.mean).unwrap());
    }
    let fastest = refs[0];
    println!("Summary");
    println!("  {} ran", fastest.command);
    for r in refs.iter().skip(1) {
        println!("    {:.2} times faster than {}", r.mean / fastest.mean, r.command);
    }
}

fn write_exports(results: &[JsonResult], o: &Opt) -> Result<(), String> {
    if let Some(p) = &o.export_json {
        let s = serde_json::to_string_pretty(&JsonOut { results: results.to_vec() }).map_err(|e| e.to_string())?;
        fs::write(p, s + "\n").map_err(|e| format!("Error: Could not write '{p}': {e}"))?;
    }
    if let Some(p) = &o.export_csv {
        let mut s = "command,mean,stddev,median,user,system,min,max\n".to_string();
        for r in results {
            s.push_str(&format!("\"{}\",{},{},{},{},{},{},{}\n", csv_escape(&r.command), r.mean, opt_num(r.stddev), r.median, r.user, r.system, r.min, r.max));
        }
        fs::write(p, s).map_err(|e| format!("Error: Could not write '{p}': {e}"))?;
    }
    if let Some(p) = &o.export_md {
        fs::write(p, table(results, o, "md")).map_err(|e| format!("Error: Could not write '{p}': {e}"))?;
    }
    if let Some(p) = &o.export_adoc {
        fs::write(p, table(results, o, "adoc")).map_err(|e| format!("Error: Could not write '{p}': {e}"))?;
    }
    if let Some(p) = &o.export_org {
        fs::write(p, table(results, o, "org")).map_err(|e| format!("Error: Could not write '{p}': {e}"))?;
    }
    Ok(())
}

fn opt_num(v: Option<f64>) -> String {
    v.map(|x| x.to_string()).unwrap_or_default()
}

fn csv_escape(s: &str) -> String {
    s.replace('"', "\"\"")
}

fn table(results: &[JsonResult], o: &Opt, kind: &str) -> String {
    let u = table_unit(results, o);
    let mut rows = Vec::new();
    let fastest = results.iter().map(|r| r.mean).fold(f64::INFINITY, f64::min);
    for r in results {
        let factor = r.mean / fastest;
        rows.push((r, factor));
    }
    let mut s = String::new();
    match kind {
        "org" => {
            s.push_str(&format!("| Command | Mean [{}] | Min [{}] | Max [{}] | Relative |\n|-\n", u, u, u));
            for (r, factor) in rows {
                s.push_str(&format!("| {} | {} | {} | {} | {:.2} |\n", r.command, conv(r.mean, o), conv(r.min, o), conv(r.max, o), factor));
            }
        }
        "adoc" => {
            s.push_str(&format!("[cols=\"5,2,2,2,2\"]\n|===\n| Command | Mean [{}] | Min [{}] | Max [{}] | Relative\n", u, u, u));
            for (r, factor) in rows {
                s.push_str(&format!("| `{}` | {} | {} | {} | {:.2}\n", r.command, conv(r.mean, o), conv(r.min, o), conv(r.max, o), factor));
            }
            s.push_str("|===\n");
        }
        _ => {
            s.push_str(&format!("| Command | Mean [{}] | Min [{}] | Max [{}] | Relative |\n|:---|---:|---:|---:|---:|\n", u, u, u));
            for (r, factor) in rows {
                s.push_str(&format!("| `{}` | {} | {} | {} | {:.2} |\n", r.command.replace('|', "\\|"), conv(r.mean, o), conv(r.min, o), conv(r.max, o), factor));
            }
        }
    }
    s
}

fn conv(v: f64, o: &Opt) -> String {
    match o.unit.as_deref() {
        Some("second") => format!("{:.3}", v),
        Some("microsecond") => format!("{:.1}", v * 1e6),
        Some("millisecond") => format!("{:.1}", v * 1e3),
        _ if v < 0.001 => format!("{:.1}", v * 1e6),
        _ if v < 1.0 => format!("{:.1}", v * 1e3),
        _ => format!("{:.3}", v),
    }
}

fn table_unit(results: &[JsonResult], o: &Opt) -> &'static str {
    match o.unit.as_deref() {
        Some("microsecond") => "us",
        Some("millisecond") => "ms",
        Some("second") => "s",
        _ => {
            let avg = results.iter().map(|r| r.mean).fold(f64::INFINITY, f64::min);
            if avg < 0.001 { "us" } else if avg < 1.0 { "ms" } else { "s" }
        }
    }
}
