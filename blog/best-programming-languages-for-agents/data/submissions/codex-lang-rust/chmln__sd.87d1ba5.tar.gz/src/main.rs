use clap::{value_parser, Arg, ArgAction, Command};
use regex::{Captures, Regex, RegexBuilder};
use std::fs;
use std::io::{self, Read, Write};
use std::path::PathBuf;
use std::process;

struct Args {
    preview: bool,
    fixed_strings: bool,
    max_replacements: usize,
    flags: Option<String>,
    find: String,
    replace_with: String,
    files: Vec<PathBuf>,
}

fn main() {
    if let Some(arg) = std::env::args().nth(1) {
        match arg.as_str() {
            "-h" | "--help" => {
                print_help();
                return;
            }
            "-V" | "--version" => {
                println!("sd 1.0.0");
                return;
            }
            _ => {}
        }
    }
    let args = parse_args();
    if let Err(err) = run(args) {
        eprintln!("error: {}", err);
        process::exit(1);
    }
}

fn print_help() {
    print!(
        "sd v1.0.0
An intuitive find & replace CLI

Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...

Arguments:
  <FIND>
          The regexp or string (if using `-F`) to search for

  <REPLACE_WITH>
          What to replace each match with. Unless in string mode, you may use captured values like
          $1, $2, etc

  [FILES]...
          The path to file(s). This is optional - sd can also read from STDIN.
          
          Note: sd modifies files in-place by default. See documentation for examples.

Options:
  -p, --preview
          Display changes in a human reviewable format (the specifics of the format are likely to
          change in the future)

  -F, --fixed-strings
          Treat FIND and REPLACE_WITH args as literal strings

  -n, --max-replacements <LIMIT>
          Limit the number of replacements that can occur per file. 0 indicates unlimited
          replacements
          
          [default: 0]

  -f, --flags <FLAGS>
          Regex flags. May be combined (like `-f mc`).
          
          c - case-sensitive
          
          e - disable multi-line matching
          
          i - case-insensitive
          
          m - multi-line matching
          
          s - make `.` match newlines
          
          w - match full words only

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"
    );
}

fn parse_args() -> Args {
    let matches = Command::new("sd")
        .bin_name("executable")
        .version("1.0.0")
        .about("An intuitive find & replace CLI")
        .disable_help_subcommand(true)
        .arg(
            Arg::new("preview")
                .short('p')
                .long("preview")
                .help("Display changes in a human reviewable format (the specifics of the format are likely to change in the future)")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("fixed-strings")
                .short('F')
                .long("fixed-strings")
                .help("Treat FIND and REPLACE_WITH args as literal strings")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("max-replacements")
                .short('n')
                .long("max-replacements")
                .value_name("LIMIT")
                .default_value("0")
                .value_parser(value_parser!(usize))
                .help("Limit the number of replacements that can occur per file. 0 indicates unlimited replacements"),
        )
        .arg(
            Arg::new("flags")
                .short('f')
                .long("flags")
                .value_name("FLAGS")
                .help("Regex flags. May be combined (like `-f mc`)."),
        )
        .arg(
            Arg::new("find")
                .value_name("FIND")
                .help("The regexp or string (if using `-F`) to search for")
                .required(true),
        )
        .arg(
            Arg::new("replace-with")
                .value_name("REPLACE_WITH")
                .help("What to replace each match with. Unless in string mode, you may use captured values like $1, $2, etc")
                .required(true),
        )
        .arg(
            Arg::new("files")
                .value_name("FILES")
                .help("The path to file(s). This is optional - sd can also read from STDIN")
                .action(ArgAction::Append)
                .num_args(0..),
        )
        .get_matches();

    Args {
        preview: matches.get_flag("preview"),
        fixed_strings: matches.get_flag("fixed-strings"),
        max_replacements: *matches
            .get_one::<usize>("max-replacements")
            .unwrap_or(&0usize),
        flags: matches.get_one::<String>("flags").cloned(),
        find: matches.get_one::<String>("find").unwrap().clone(),
        replace_with: matches.get_one::<String>("replace-with").unwrap().clone(),
        files: matches
            .get_many::<String>("files")
            .map(|vals| vals.map(PathBuf::from).collect())
            .unwrap_or_default(),
    }
}

fn run(args: Args) -> Result<(), String> {
    let replacer = Replacer::new(&args)?;

    if args.files.is_empty() {
        let mut input = String::new();
        io::stdin()
            .read_to_string(&mut input)
            .map_err(|e| e.to_string())?;
        let output = replacer.replace(&input);
        io::stdout()
            .write_all(output.as_bytes())
            .map_err(|e| e.to_string())?;
        return Ok(());
    }

    let multi_preview = args.preview && args.files.len() > 1;
    for path in &args.files {
        let input = match fs::read_to_string(path) {
            Ok(s) => s,
            Err(_) if !path.exists() => return Err(format!("invalid path: {}", path.display())),
            Err(e) => return Err(e.to_string()),
        };
        let output = replacer.replace(&input);
        if args.preview {
            if multi_preview {
                println!("----- FILE {} -----", path.display());
            }
            print!("{}", output);
        } else {
            fs::write(path, output).map_err(|e| e.to_string())?;
        }
    }

    Ok(())
}

enum Replacer {
    Fixed {
        find: String,
        replacement: String,
        limit: usize,
    },
    Regex {
        regex: Regex,
        replacement: String,
        limit: usize,
    },
}

impl Replacer {
    fn new(args: &Args) -> Result<Self, String> {
        if args.fixed_strings {
            return Ok(Self::Fixed {
                find: args.find.clone(),
                replacement: args.replace_with.clone(),
                limit: args.max_replacements,
            });
        }

        let mut case_insensitive = false;
        let mut multi_line = true;
        let mut dot_matches_new_line = false;
        let mut word = false;

        if let Some(flags) = &args.flags {
            for ch in flags.chars() {
                match ch {
                    'i' => case_insensitive = true,
                    'c' => case_insensitive = false,
                    'e' => multi_line = false,
                    'm' => {}
                    's' => dot_matches_new_line = true,
                    'w' => word = true,
                    _ => {}
                }
            }
        }

        let pattern = if word {
            format!(r"\b(?:{})\b", args.find)
        } else {
            args.find.clone()
        };

        let regex = RegexBuilder::new(&pattern)
            .case_insensitive(case_insensitive)
            .multi_line(multi_line)
            .dot_matches_new_line(dot_matches_new_line)
            .build()
            .map_err(|e| format!("invalid regex {}", e))?;

        Ok(Self::Regex {
            regex,
            replacement: unescape_replacement(&args.replace_with),
            limit: args.max_replacements,
        })
    }

    fn replace(&self, input: &str) -> String {
        match self {
            Self::Fixed {
                find,
                replacement,
                limit,
            } => replace_fixed(input, find, replacement, *limit),
            Self::Regex {
                regex,
                replacement,
                limit,
            } => replace_regex(input, regex, replacement, *limit),
        }
    }
}

fn replace_fixed(input: &str, find: &str, replacement: &str, limit: usize) -> String {
    if limit == 0 {
        input.replace(find, replacement)
    } else {
        input.replacen(find, replacement, limit)
    }
}

fn replace_regex(input: &str, regex: &Regex, replacement: &str, limit: usize) -> String {
    if limit == 0 {
        regex.replace_all(input, replacement).into_owned()
    } else {
        let mut count = 0usize;
        regex
            .replace_all(input, |caps: &Captures| {
                if count < limit {
                    count += 1;
                    let mut out = String::new();
                    caps.expand(replacement, &mut out);
                    out
                } else {
                    caps.get(0).map(|m| m.as_str()).unwrap_or("").to_string()
                }
            })
            .into_owned()
    }
}

fn unescape_replacement(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch != '\\' {
            out.push(ch);
            continue;
        }
        match chars.next() {
            Some('n') => out.push('\n'),
            Some('r') => out.push('\r'),
            Some('t') => out.push('\t'),
            Some('\\') => out.push('\\'),
            Some('x') => {
                let h1 = chars.next();
                let h2 = chars.next();
                if let (Some(a), Some(b)) = (h1, h2) {
                    let hex = format!("{}{}", a, b);
                    if let Ok(v) = u8::from_str_radix(&hex, 16) {
                        out.push(v as char);
                    } else {
                        out.push_str("\\x");
                        out.push(a);
                        out.push(b);
                    }
                } else {
                    out.push_str("\\x");
                    if let Some(a) = h1 {
                        out.push(a);
                    }
                    if let Some(b) = h2 {
                        out.push(b);
                    }
                }
            }
            Some(other) => {
                out.push('\\');
                out.push(other);
            }
            None => out.push('\\'),
        }
    }
    out
}
