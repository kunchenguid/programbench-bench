use std::env;
use std::fs::{self, File};
use std::io::{BufRead, BufReader, Write};
use std::path::Path;
use std::process::{Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

const HELP: &str = "\nUSAGE: \n\n   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a\n                 string containing two space-seprated positive integers>]\n                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]\n                 [-h] <Array of strings> ...\n\n\nWhere: \n\n   -i <path to directory>,  --replaydirectory <path to directory>\n     The path to directory for replay output.\n\n   -s <positive integer>,  --seed <positive integer>\n     The seed for the map generator.\n\n   -d <a string containing two space-seprated positive integers>, \n      --dimensions <a string containing two space-seprated positive\n      integers>\n     The dimensions of the map.\n\n   -n <{1,2,3,4,5,6}>,  --nplayers <{1,2,3,4,5,6}>\n     Create a map that will accommodate n players [SINGLE PLAYER MODE\n     ONLY].\n\n   -r,  --noreplay\n     Turns off the replay generation.\n\n   -t,  --timeout\n     Causes game environment to ignore timeouts (give all bots infinite\n     time).\n\n   -o,  --override\n     Overrides player-sent names using cmd args [SERVER ONLY].\n\n   -q,  --quiet\n     Runs game in quiet mode, producing machine-parsable output.\n\n   --,  --ignore_rest\n     Ignores the rest of the labeled arguments following this flag.\n\n   --version\n     Displays version information and exits.\n\n   -h,  --help\n     Displays usage information and exits.\n\n   <Array of strings>  (accepted multiple times)\n     Start commands for bots.\n\n\n   Halite Game Environment\n\n";

#[derive(Clone)]
struct Opts {
    replay_dir: String,
    seed: Option<u32>,
    width: usize,
    height: usize,
    nplayers: Option<usize>,
    noreplay: bool,
    quiet: bool,
    override_names: bool,
    bots: Vec<String>,
}

fn brief_usage() -> &'static str {
    "\nBrief USAGE: \n   ./executable  [-i <path to directory>] [-s <positive integer>] [-d <a\n                 string containing two space-seprated positive integers>]\n                 [-n <{1,2,3,4,5,6}>] [-r] [-t] [-o] [-q] [--] [--version]\n                 [-h] <Array of strings> ...\n\nFor complete USAGE and HELP type: \n   ./executable --help\n\n"
}

fn parse_positive(s: &str, flag: &str, long: &str) -> Result<u32, String> {
    match s.parse::<u32>() {
        Ok(v) if v > 0 => Ok(v),
        _ => Err(format!("PARSE ERROR: Argument: {} ({})\n             Couldn't read argument value from string '{}'\n{}", flag, long, s, brief_usage())),
    }
}

fn parse_dimensions(s: &str) -> Result<(usize, usize), String> {
    let parts: Vec<_> = s.split_whitespace().collect();
    if parts.len() != 2 {
        return Err(format!("PARSE ERROR: Argument: -d (--dimensions)\n             Couldn't read argument value from string '{}'\n{}", s, brief_usage()));
    }
    let w = parts[0].parse::<usize>().ok().filter(|v| *v > 0);
    let h = parts[1].parse::<usize>().ok().filter(|v| *v > 0);
    match (w, h) {
        (Some(w), Some(h)) => Ok((w, h)),
        _ => Err(format!("PARSE ERROR: Argument: -d (--dimensions)\n             Couldn't read argument value from string '{}'\n{}", s, brief_usage())),
    }
}

fn parse_args() -> Result<Option<Opts>, i32> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print!("{}", HELP);
        return Ok(None);
    }
    if args.iter().any(|a| a == "--version") {
        println!("\n./executable  version: 1.2\n");
        return Ok(None);
    }
    let mut opts = Opts { replay_dir: ".".into(), seed: None, width: 20, height: 20, nplayers: None, noreplay: false, quiet: false, override_names: false, bots: Vec::new() };
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        match a.as_str() {
            "--" | "--ignore_rest" => {
                opts.bots.extend(args.drain(i + 1..));
                break;
            }
            "-i" | "--replaydirectory" => {
                i += 1;
                if i >= args.len() { eprintln!("Missing value for {}", a); return Err(1); }
                opts.replay_dir = args[i].clone();
            }
            "-s" | "--seed" => {
                i += 1;
                if i >= args.len() { eprintln!("Missing value for {}", a); return Err(1); }
                match parse_positive(&args[i], "-s", "--seed") { Ok(v) => opts.seed = Some(v), Err(e) => { print!("{}", e); return Err(1); } }
            }
            "-d" | "--dimensions" => {
                i += 1;
                if i >= args.len() { eprintln!("Missing value for {}", a); return Err(1); }
                match parse_dimensions(&args[i]) { Ok((w,h)) => { opts.width=w; opts.height=h; }, Err(e) => { print!("{}", e); return Err(1); } }
            }
            "-n" | "--nplayers" => {
                i += 1;
                if i >= args.len() { eprintln!("Missing value for {}", a); return Err(1); }
                match parse_positive(&args[i], "-n", "--nplayers") { Ok(v) => opts.nplayers = Some(v as usize), Err(e) => { print!("{}", e); return Err(1); } }
            }
            "-r" | "--noreplay" => opts.noreplay = true,
            "-t" | "--timeout" => {},
            "-o" | "--override" => opts.override_names = true,
            "-q" | "--quiet" => opts.quiet = true,
            _ => opts.bots.push(a),
        }
        i += 1;
    }
    Ok(Some(opts))
}

struct Rng(u64);
impl Rng {
    fn new(seed: u64) -> Self { Self(seed | 1) }
    fn next(&mut self) -> u32 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        (self.0 >> 32) as u32
    }
    fn range(&mut self, lo: u16, hi: u16) -> u16 { lo + (self.next() as u16 % (hi - lo + 1)) }
}

fn make_maps(w: usize, h: usize, players: usize, seed: u32) -> (Vec<u8>, Vec<u16>, Vec<u16>) {
    let mut owners = vec![0u8; w*h];
    let mut strengths = vec![0u16; w*h];
    let mut prod = vec![0u16; w*h];
    let mut rng = Rng::new(seed as u64 + (w as u64)*1009 + (h as u64)*9176);
    for y in 0..h { for x in 0..w {
        let idx = y*w+x;
        prod[idx] = rng.range(1, 15);
        strengths[idx] = rng.range(0, 200);
    }}
    let locs = start_locations(w, h, players);
    for (i, (x,y)) in locs.into_iter().enumerate() {
        let idx = (y % h) * w + (x % w);
        owners[idx] = (i+1) as u8;
        strengths[idx] = 50;
    }
    (owners, strengths, prod)
}

fn start_locations(w: usize, h: usize, p: usize) -> Vec<(usize, usize)> {
    match p {
        1 => vec![(w/2, h/2)],
        2 => vec![(w/4, h/2), ((3*w)/4, h/2)],
        3 => vec![(w/2, h/5), (w/5, (4*h)/5), ((4*w)/5, (4*h)/5)],
        4 => vec![(w/4, h/4), ((3*w)/4, h/4), (w/4, (3*h)/4), ((3*w)/4, (3*h)/4)],
        5 => vec![(w/2,h/2),(w/5,h/5),((4*w)/5,h/5),(w/5,(4*h)/5),((4*w)/5,(4*h)/5)],
        _ => vec![(w/4,h/4), (w/2,h/4), ((3*w)/4,h/4), (w/4,(3*h)/4), (w/2,(3*h)/4), ((3*w)/4,(3*h)/4)],
    }
}

fn production_line(prod: &[u16]) -> String {
    let mut s = String::new();
    for v in prod { s.push_str(&format!("{} ", v)); }
    s
}

fn frame_line(owners: &[u8], strengths: &[u16]) -> String {
    let mut s = String::new();
    if owners.is_empty() { return s; }
    let mut i = 0;
    while i < owners.len() {
        let o = owners[i];
        let mut run = 1usize;
        while i + run < owners.len() && owners[i+run] == o { run += 1; }
        s.push_str(&format!("{} {} ", run, o));
        i += run;
    }
    for v in strengths { s.push_str(&format!("{} ", v)); }
    s
}

struct Bot {
    id: usize,
    name: String,
    alive: bool,
    last_alive: usize,
    child: Option<std::process::Child>,
    stdin: Option<std::process::ChildStdin>,
    stdout: Option<BufReader<std::process::ChildStdout>>,
}

fn sanitize_name(s: &str) -> String {
    let mut t = s.trim_end_matches(['\r','\n']).to_string();
    if t.len() > 30 { t.truncate(30); }
    if t.is_empty() { t = "Anonymous".to_string(); }
    t
}

fn launch_bot(id: usize, command: &str, opts: &Opts, prod_line: &str) -> Bot {
    let child = Command::new("/bin/sh")
        .arg("-c")
        .arg(command)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn();
    let mut name = command.to_string();
    let mut alive = false;
    let mut child_opt = None;
    let mut stdin_opt = None;
    let mut stdout_opt = None;
    if let Ok(mut ch) = child {
        if let (Some(mut sin), Some(sout)) = (ch.stdin.take(), ch.stdout.take()) {
            let _ = writeln!(sin, "{}", id);
            let _ = writeln!(sin, "{} {} ", opts.width, opts.height);
            let _ = writeln!(sin, "{}", prod_line);
            let _ = sin.flush();
            if !opts.quiet { println!("Init Message sent to player {}.", id); }
            let mut reader = BufReader::new(sout);
            let mut line = String::new();
            match reader.read_line(&mut line) {
                Ok(n) if n > 0 => { name = sanitize_name(&line); alive = true; }
                _ => { name = command.to_string(); alive = false; }
            }
            if opts.override_names { name = command.to_string(); }
            if !opts.quiet { println!("Init Message received from player {}, {}.", id, name); }
            child_opt = Some(ch);
            stdin_opt = Some(sin);
            stdout_opt = Some(reader);
        }
    }
    Bot { id, name, alive, last_alive: 0, child: child_opt, stdin: stdin_opt, stdout: stdout_opt }
}

fn main() {
    let opts = match parse_args() { Ok(Some(o)) => o, Ok(None) => return, Err(code) => std::process::exit(code) };
    if opts.bots.is_empty() {
        println!("Please provide the launch command string for at least one bot.\nUse the --help flag for usage details.");
        std::process::exit(1);
    }
    let player_count = opts.nplayers.unwrap_or(opts.bots.len());
    if player_count < 1 || player_count > 6 {
        for b in &opts.bots { println!("{}", b); }
        if !opts.quiet { for b in &opts.bots { println!("{}", b); } }
        println!("\nA map can only accommodate between 1 and 6 players.\n");
        std::process::exit(1);
    }
    if opts.bots.len() > 6 {
        println!("\nA map can only accommodate between 1 and 6 players.\n");
        std::process::exit(1);
    }
    let seed = opts.seed.unwrap_or_else(|| {
        (SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos() as u32).wrapping_mul(1664525).wrapping_add(1013904223)
    });
    for b in &opts.bots { println!("{}", b); }
    if !opts.quiet { for b in &opts.bots { println!("{}", b); } }
    println!("{} {}", opts.width, opts.height);

    let (owners, mut strengths, prod) = make_maps(opts.width, opts.height, player_count, seed);
    let prod_line = production_line(&prod);
    let mut bots = Vec::new();
    for (i, cmd) in opts.bots.iter().enumerate() {
        bots.push(launch_bot(i+1, cmd, &opts, &prod_line));
    }
    let max_turns = (10.0 * ((opts.width * opts.height) as f64).sqrt()).round() as usize;
    for turn in 1..=max_turns {
        if !opts.quiet { println!("Turn {}", turn); }
        let frame = frame_line(&owners, &strengths);
        for bot in bots.iter_mut() {
            if bot.alive {
                if let Some(sin) = bot.stdin.as_mut() {
                    if writeln!(sin, "{}", frame).and_then(|_| sin.flush()).is_err() {
                        bot.alive = false;
                    }
                }
                let mut line = String::new();
                if bot.alive {
                    if let Some(reader) = bot.stdout.as_mut() {
                        match reader.read_line(&mut line) {
                            Ok(_) => {
                                if line.chars().any(|c| !(c.is_ascii_digit() || c.is_ascii_whitespace())) {
                                    if !opts.quiet { println!("Bot sent an invalid character - ejecting from game."); }
                                    bot.alive = false;
                                } else {
                                    bot.last_alive = turn;
                                }
                            }
                            Err(_) => { bot.alive = false; }
                        }
                    }
                }
            }
        }
        for (i, st) in strengths.iter_mut().enumerate() {
            if owners[i] == 0 { *st = st.saturating_add(prod[i]).min(255); }
        }
    }
    for bot in bots.iter_mut() {
        if let Some(mut ch) = bot.child.take() {
            let _ = ch.kill();
            let _ = ch.wait();
        }
    }
    if !opts.noreplay {
        let dir = Path::new(&opts.replay_dir);
        let _ = fs::create_dir_all(dir);
        let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
        let path = dir.join(format!("{}-{}.hlt", ts, seed));
        if let Ok(mut f) = File::create(&path) {
            let _ = writeln!(f, "Halite replay placeholder seed={} width={} height={}", seed, opts.width, opts.height);
        }
        if !opts.quiet { println!("Map seed was {}", seed); println!("Opening a file at {}", path.display()); }
    }
    let mut ranks: Vec<_> = bots.iter().collect();
    ranks.sort_by_key(|b| std::cmp::Reverse(b.last_alive));
    if opts.quiet {
        for (rank, bot) in ranks.iter().enumerate() {
            println!("{} {} {}", bot.id, rank+1, max_turns);
        }
        println!(" ");
    } else {
        for (rank, bot) in ranks.iter().enumerate() {
            println!("Player #{}, {}, came in rank #{} and was last alive on frame #{}!", bot.id, bot.name, rank+1, bot.last_alive);
        }
    }
}
