use chrono::{NaiveDateTime, TimeZone, Utc};
use regex::Regex;
use std::env;
use std::io::{self, Read, Write};
use std::process::Command;
use std::thread;
use std::time::{Duration, Instant};

const HELP: &str = "loop 0.6.1
Rich Jones <miserlou@gmail.com>
UNIX's missing `loop` command

USAGE:
    executable [FLAGS] [OPTIONS] [input]...

FLAGS:
    -D, --error-duration    Exit with timeout error code on duration
    -h, --help              Prints help information
    -l, --only-last         Only print the output of the last execution of the command
    -i, --stdin             Read from standard input
        --summary           Provide a summary
    -C, --until-changes     Keep going until the output changes
    -f, --until-fail        Keep going until the command exit status is non-zero
    -S, --until-same        Keep going until the output changes
    -s, --until-success     Keep going until the command exit status is zero
    -V, --version           Prints version information

OPTIONS:
    -b, --count-by <count_by>                Amount to increment the counter by [default: 1]
    -e, --every <every>                      How often to iterate. ex., 5s, 1h1m1s1ms1us [default: 1us]
        --for <ffor>                         A comma-separated list of values, placed into 4ITEM. ex., red,green,blue
    -d, --for-duration <for_duration>        Keep going until the duration has elapsed (example 1m30s)
    -n, --num <num>                          Number of iterations to execute
    -o, --offset <offset>                    Amount to offset the initial counter by [default: 0]
    -c, --until-contains <until_contains>    Keep going until the output contains this string
    -r, --until-error <until_error>          Keep going until the command exit status is the value given
    -m, --until-match <until_match>          Keep going until the output matches this regular expression
    -t, --until-time <until_time>            Keep going until a future time, ex. \"2018-04-20 04:20:00\" (Times in UTC.)

ARGS:
    <input>...    The command to be looped
";

#[derive(Default)]
struct Opts {
    num: Option<usize>,
    every: Duration,
    for_duration: Option<Duration>,
    until_time: Option<chrono::DateTime<Utc>>,
    count_by: i64,
    offset: i64,
    list: Option<Vec<String>>,
    use_stdin: bool,
    only_last: bool,
    summary: bool,
    until_changes: bool,
    until_same: bool,
    until_success: bool,
    until_fail: bool,
    until_contains: Option<String>,
    until_match: Option<Regex>,
    until_error: Option<i32>,
    error_duration: bool,
    input: Vec<String>,
}

fn main() {
    let mut opts = Opts { every: Duration::from_micros(1), count_by: 1, ..Default::default() };
    match parse_args(&mut opts) {
        Ok(Action::Help) => {
            print!("{}", HELP);
            return;
        }
        Ok(Action::Version) => {
            println!("loop 0.6.1");
            return;
        }
        Ok(Action::Run) => {}
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(1);
        }
    }

    if opts.input.is_empty() {
        println!("No command supplied, exiting.");
        return;
    }

    if opts.use_stdin {
        let mut s = String::new();
        let _ = io::stdin().read_to_string(&mut s);
        opts.list = Some(s.lines().map(|l| l.to_string()).collect());
    }

    let start = Instant::now();
    let mut count = opts.offset;
    let mut runs = 0usize;
    let mut successes = 0usize;
    let mut failures: Vec<i32> = Vec::new();
    let mut previous: Option<String> = None;
    let mut last_output = String::new();

    loop {
        if should_stop_before(&opts, runs, start) {
            if opts.error_duration {
                finish_summary(&opts, runs, successes, &failures);
                std::process::exit(1);
            }
            break;
        }

        let item = current_item(&opts, runs);
        let command = render_command(&opts.input);
        let (status, output) = run_shell(&command, count, item.as_deref().unwrap_or(""));
        runs += 1;
        if status == 0 {
            successes += 1;
        } else {
            failures.push(status);
        }

        if opts.only_last {
            last_output = output.clone();
        } else {
            print!("{}", output);
            let _ = io::stdout().flush();
        }

        let mut stop = false;
        if opts.until_success && status == 0 {
            stop = true;
        }
        if opts.until_fail && status != 0 {
            stop = true;
        }
        if opts.until_error == Some(status) {
            stop = true;
        }
        if let Some(s) = &opts.until_contains {
            if output.contains(s) {
                stop = true;
            }
        }
        if let Some(re) = &opts.until_match {
            if re.is_match(&output) {
                stop = true;
            }
        }
        if opts.until_changes {
            if let Some(prev) = &previous {
                if prev != &output {
                    stop = true;
                }
            }
        }
        if opts.until_same {
            if let Some(prev) = &previous {
                if prev == &output {
                    stop = true;
                }
            }
        }
        previous = Some(output);
        count += opts.count_by;

        if stop || should_stop_after(&opts, runs, start) {
            break;
        }
        thread::sleep(opts.every);
    }

    if opts.only_last {
        print!("{}", last_output);
    }
    finish_summary(&opts, runs, successes, &failures);
}

enum Action {
    Run,
    Help,
    Version,
}

fn parse_args(opts: &mut Opts) -> Result<Action, String> {
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        if let Some((name, value)) = arg.split_once('=') {
            match name {
                "--num" => {
                    opts.num = Some(value.parse::<f64>().map_err(|e| format!("error: Invalid value for '--num <num>': {}", e))? as usize);
                    continue;
                }
                "--count-by" => {
                    opts.count_by = value.parse::<i64>().map_err(|e| format!("error: Invalid value for '--count-by <count_by>': {}", e))?;
                    continue;
                }
                "--offset" => {
                    opts.offset = value.parse::<i64>().map_err(|e| format!("error: Invalid value for '--offset <offset>': {}", e))?;
                    continue;
                }
                "--every" => {
                    opts.every = parse_duration(value)?;
                    continue;
                }
                "--for-duration" => {
                    opts.for_duration = Some(parse_duration(value)?);
                    continue;
                }
                "--for" => {
                    opts.list = Some(value.split(',').map(|s| s.to_string()).collect());
                    continue;
                }
                "--until-contains" => {
                    opts.until_contains = Some(value.to_string());
                    continue;
                }
                "--until-match" => {
                    opts.until_match = Some(Regex::new(value).map_err(|e| e.to_string())?);
                    continue;
                }
                "--until-error" => {
                    opts.until_error = Some(value.parse::<i32>().map_err(|e| format!("error: Invalid value for '--until-error <until_error>': {}", e))?);
                    continue;
                }
                "--until-time" => {
                    opts.until_time = Some(parse_time(value)?);
                    continue;
                }
                _ => {}
            }
        }
        match arg.as_str() {
            "-h" | "--help" => return Ok(Action::Help),
            "-V" | "--version" => return Ok(Action::Version),
            "--" => {
                opts.input.extend(args);
                break;
            }
            "-D" | "--error-duration" => opts.error_duration = true,
            "-l" | "--only-last" => opts.only_last = true,
            "-i" | "--stdin" => opts.use_stdin = true,
            "--summary" => opts.summary = true,
            "-C" | "--until-changes" => opts.until_changes = true,
            "-S" | "--until-same" => opts.until_same = true,
            "-f" | "--until-fail" => opts.until_fail = true,
            "-s" | "--until-success" => opts.until_success = true,
            "-n" | "--num" => opts.num = Some(parse_value::<f64, _>(&mut args, "--num <num>")? as usize),
            "-b" | "--count-by" => opts.count_by = parse_value::<i64, _>(&mut args, "--count-by <count_by>")?,
            "-o" | "--offset" => opts.offset = parse_value::<i64, _>(&mut args, "--offset <offset>")?,
            "-e" | "--every" => opts.every = parse_duration(&next_val(&mut args, "--every <every>")?)?,
            "-d" | "--for-duration" => opts.for_duration = Some(parse_duration(&next_val(&mut args, "--for-duration <for_duration>")?)?),
            "--for" => {
                let v = next_val(&mut args, "--for <ffor>")?;
                opts.list = Some(v.split(',').map(|s| s.to_string()).collect());
            }
            "-c" | "--until-contains" => opts.until_contains = Some(next_val(&mut args, "--until-contains <until_contains>")?),
            "-m" | "--until-match" => {
                let pat = next_val(&mut args, "--until-match <until_match>")?;
                opts.until_match = Some(Regex::new(&pat).map_err(|e| e.to_string())?);
            }
            "-r" | "--until-error" => opts.until_error = Some(parse_value::<i32, _>(&mut args, "--until-error <until_error>")?),
            "-t" | "--until-time" => {
                let t = next_val(&mut args, "--until-time <until_time>")?;
                opts.until_time = Some(parse_time(&t)?);
            }
            s if s.starts_with('-') => {
                return Err(format!(
                    "error: Found argument '{}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input]...\n\nFor more information try --help",
                    s
                ));
            }
            _ => {
                opts.input.push(arg);
                opts.input.extend(args);
                break;
            }
        }
    }
    Ok(Action::Run)
}

fn next_val<I>(args: &mut std::iter::Peekable<I>, opt: &str) -> Result<String, String>
where
    I: Iterator<Item = String>,
{
    args.next().ok_or_else(|| format!("error: The argument '{}' requires a value but none was supplied", opt))
}

fn parse_value<T: std::str::FromStr, I>(args: &mut std::iter::Peekable<I>, opt: &str) -> Result<T, String>
where
    I: Iterator<Item = String>,
    T::Err: std::fmt::Display,
{
    let v = next_val(args, opt)?;
    v.parse::<T>().map_err(|e| format!("error: Invalid value for '{}': {}", opt, e))
}

fn parse_duration(s: &str) -> Result<Duration, String> {
    if s.is_empty() {
        return Ok(Duration::ZERO);
    }
    let mut rest = s;
    let mut total = Duration::ZERO;
    while !rest.is_empty() {
        let digits = rest.find(|c: char| !c.is_ascii_digit()).unwrap_or(rest.len());
        if digits == 0 {
            return Err(format!("Invalid duration: {}", s));
        }
        let n: u64 = rest[..digits].parse().map_err(|_| format!("Invalid duration: {}", s))?;
        rest = &rest[digits..];
        let unit = if rest.starts_with("us") {
            rest = &rest[2..];
            Duration::from_micros(n)
        } else if rest.starts_with("ms") {
            rest = &rest[2..];
            Duration::from_millis(n)
        } else if rest.starts_with('s') {
            rest = &rest[1..];
            Duration::from_secs(n)
        } else if rest.starts_with('m') {
            rest = &rest[1..];
            Duration::from_secs(n * 60)
        } else if rest.starts_with('h') {
            rest = &rest[1..];
            Duration::from_secs(n * 3600)
        } else if rest.is_empty() {
            Duration::from_secs(n)
        } else {
            return Err(format!("Invalid duration: {}", s));
        };
        total += unit;
    }
    Ok(total)
}

fn parse_time(s: &str) -> Result<chrono::DateTime<Utc>, String> {
    let fmt = "%Y-%m-%d %H:%M:%S";
    let naive = NaiveDateTime::parse_from_str(s, fmt).map_err(|e| e.to_string())?;
    Ok(Utc.from_utc_datetime(&naive))
}

fn should_stop_before(opts: &Opts, runs: usize, start: Instant) -> bool {
    if let Some(n) = opts.num {
        if runs >= n {
            return true;
        }
    }
    if let Some(d) = opts.for_duration {
        if start.elapsed() >= d {
            return true;
        }
    }
    if let Some(t) = opts.until_time {
        if Utc::now() >= t {
            return true;
        }
    }
    false
}

fn should_stop_after(opts: &Opts, runs: usize, start: Instant) -> bool {
    should_stop_before(opts, runs, start)
}

fn current_item(opts: &Opts, runs: usize) -> Option<String> {
    let list = opts.list.as_ref()?;
    if list.is_empty() {
        Some(String::new())
    } else if runs < list.len() {
        Some(list[runs].clone())
    } else {
        Some(list[list.len() - 1].clone())
    }
}

fn render_command(input: &[String]) -> String {
    input.join(" ")
}

fn run_shell(command: &str, count: i64, item: &str) -> (i32, String) {
    let wrapped = format!("{{ {}; }} 2>&1", command);
    match Command::new("sh")
        .arg("-c")
        .arg(wrapped)
        .env("COUNT", count.to_string())
        .env("ITEM", item)
        .output()
    {
        Ok(out) => {
            let code = out.status.code().unwrap_or(1);
            (code, String::from_utf8_lossy(&out.stdout).into_owned())
        }
        Err(e) => (127, format!("{}\n", e)),
    }
}

fn finish_summary(opts: &Opts, runs: usize, successes: usize, failures: &[i32]) {
    if !opts.summary {
        return;
    }
    println!("Total runs:\t{}", runs);
    println!("Successes:\t{}", successes);
    if failures.is_empty() {
        println!("Failures:\t0");
    } else {
        let vals = failures.iter().map(|v| v.to_string()).collect::<Vec<_>>().join(", ");
        println!("Failures:\t{} ({})", failures.len(), vals);
    }
}
