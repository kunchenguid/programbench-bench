fn main() {
    println!("cargo:rustc-link-arg=/lib/x86_64-linux-gnu/libbrotlienc.so.1");
    println!("cargo:rustc-link-arg=/lib/x86_64-linux-gnu/libbrotlidec.so.1");
    println!("cargo:rustc-link-arg=/lib/x86_64-linux-gnu/libbrotlicommon.so.1");
}
