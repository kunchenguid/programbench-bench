use base64::Engine;
use std::env;
use std::ffi::{c_int, c_void};
use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
use std::os::raw::c_uint;
use std::path::{Path, PathBuf};
use std::ptr;

#[repr(C)]
struct BrotliDecoderState(c_void);

extern "C" {
    fn BrotliEncoderMaxCompressedSize(input_size: usize) -> usize;
    fn BrotliEncoderCompress(
        quality: c_int,
        lgwin: c_int,
        mode: c_int,
        input_size: usize,
        input_buffer: *const u8,
        encoded_size: *mut usize,
        encoded_buffer: *mut u8,
    ) -> c_int;
}

extern "C" {
    fn BrotliDecoderCreateInstance(
        alloc_func: *mut c_void,
        free_func: *mut c_void,
        opaque: *mut c_void,
    ) -> *mut BrotliDecoderState;
    fn BrotliDecoderDestroyInstance(state: *mut BrotliDecoderState);
    fn BrotliDecoderDecompressStream(
        state: *mut BrotliDecoderState,
        available_in: *mut usize,
        next_in: *mut *const u8,
        available_out: *mut usize,
        next_out: *mut *mut u8,
        total_out: *mut usize,
    ) -> c_uint;
    fn BrotliDecoderIsFinished(state: *mut BrotliDecoderState) -> c_int;
}

const HELP: &str = "Usage: executable [OPTION]... [FILE]...
Options:
  -#                          compression level (0-9)
  -c, --stdout                write on standard output
  -d, --decompress            decompress
  -f, --force                 force output file overwrite
  -h, --help                  display this help and exit
  -j, --rm                    remove source file(s)
  -s, --squash                remove destination file if larger than source
  -k, --keep                  keep source file(s) (default)
  -n, --no-copy-stat          do not copy source file(s) attributes
  -o FILE, --output=FILE      output file (only if 1 input file)
  -q NUM, --quality=NUM       compression level (0-11)
  -t, --test                  test compressed file integrity
  -v, --verbose               verbose mode
  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)
                              window size = 2**NUM - 16
                              0 lets compressor choose the optimal value
  --large_window=NUM          use incompatible large-window brotli
                              bitstream with window size (0, 10-30)
                              WARNING: this format is not compatible
                              with brotli RFC 7932 and may not be
                              decodable with regular brotli decoders
  -C B64, --comment=B64       set comment; argument is base64-decoded first;
                              (maximal decoded length: 80)
                              when decoding: check stream comment;
                              when encoding: embed comment (fingerprint)
  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary
  -K, --concatenated          allows concatenated brotli streams as input
  -S SUF, --suffix=SUF        output file suffix (default:'.br')
  -V, --version               display version and exit
  -Z, --best                  use best compression level (11) (default)
Simple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.
With no FILE, or when FILE is -, read standard input.
All arguments after '--' are treated as files.
";

#[derive(Clone)]
struct Options {
    quality: i32,
    lgwin: i32,
    stdout: bool,
    decompress: bool,
    force: bool,
    remove: bool,
    test: bool,
    verbose: u32,
    suffix: String,
    output: Option<String>,
    concatenated: bool,
    squash: bool,
    files: Vec<String>,
}

impl Default for Options {
    fn default() -> Self {
        Self {
            quality: 11,
            lgwin: 24,
            stdout: false,
            decompress: false,
            force: false,
            remove: false,
            test: false,
            verbose: 0,
            suffix: ".br".to_string(),
            output: None,
            concatenated: false,
            squash: false,
            files: Vec::new(),
        }
    }
}

fn usage_err(msg: impl AsRef<str>) -> ! {
    eprintln!("{}", msg.as_ref());
    eprint!("{}", HELP);
    std::process::exit(1);
}

fn parse_num(s: &str, what: &str, min: i32, max: i32) -> i32 {
    match s.parse::<i32>() {
        Ok(v) if v >= min && v <= max => v,
        _ => usage_err(format!("error parsing {} value [{}]", what, s)),
    }
}

fn take_arg(args: &[String], i: &mut usize, opt: &str) -> String {
    *i += 1;
    if *i >= args.len() {
        usage_err(format!("expected parameter for argument {}", opt));
    }
    args[*i].clone()
}

fn parse_args() -> Options {
    let mut opts = Options::default();
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    let mut files_only = false;
    while i < args.len() {
        let arg = &args[i];
        if files_only || arg == "-" || !arg.starts_with('-') {
            opts.files.push(arg.clone());
            i += 1;
            continue;
        }
        if arg == "--" {
            files_only = true;
            i += 1;
            continue;
        }
        if arg.starts_with("--") {
            let (name, value) = match arg.find('=') {
                Some(p) => (&arg[..p], Some(arg[p + 1..].to_string())),
                None => (arg.as_str(), None),
            };
            match name {
                "--stdout" => opts.stdout = true,
                "--decompress" => opts.decompress = true,
                "--force" => opts.force = true,
                "--help" => {
                    print!("{}", HELP);
                    std::process::exit(0);
                }
                "--rm" => opts.remove = true,
                "--keep" => opts.remove = false,
                "--no-copy-stat" => {}
                "--test" => {
                    opts.test = true;
                    opts.decompress = true;
                    opts.stdout = true;
                }
                "--verbose" => opts.verbose += 1,
                "--best" => opts.quality = 11,
                "--concatenated" => opts.concatenated = true,
                "--version" => {
                    println!("brotli 1.2.0");
                    std::process::exit(0);
                }
                "--quality" => {
                    let v = value.unwrap_or_else(|| take_arg(&args, &mut i, "--quality"));
                    opts.quality = parse_num(&v, "quality", 0, 11);
                }
                "--lgwin" => {
                    let v = value.unwrap_or_else(|| take_arg(&args, &mut i, "--lgwin"));
                    opts.lgwin = parse_lgwin(&v, false);
                }
                "--large_window" => {
                    let v = value.unwrap_or_else(|| usage_err("must pass the parameter as --large_window=value"));
                    opts.lgwin = parse_lgwin(&v, true);
                }
                "--output" => {
                    opts.output = Some(value.unwrap_or_else(|| take_arg(&args, &mut i, "--output")));
                }
                "--suffix" => {
                    opts.suffix = value.unwrap_or_else(|| take_arg(&args, &mut i, "--suffix"));
                }
                "--comment" => {
                    let v = value.unwrap_or_else(|| take_arg(&args, &mut i, "--comment"));
                    validate_comment(&v);
                }
                "--dictionary" => {
                    let _ = value.unwrap_or_else(|| take_arg(&args, &mut i, "--dictionary"));
                }
                other => usage_err(format!("must pass the parameter as {}=value", other)),
            }
            i += 1;
            continue;
        }
        let chars: Vec<char> = arg[1..].chars().collect();
        let mut j = 0;
        while j < chars.len() {
            match chars[j] {
                '0'..='9' => opts.quality = chars[j].to_digit(10).unwrap() as i32,
                'c' => opts.stdout = true,
                'd' => opts.decompress = true,
                'f' => opts.force = true,
                'h' => {
                    print!("{}", HELP);
                    std::process::exit(0);
                }
                'j' => opts.remove = true,
                'k' => opts.remove = false,
                'n' => {}
                's' => opts.squash = true,
                't' => {
                    opts.test = true;
                    opts.decompress = true;
                    opts.stdout = true;
                }
                'v' => opts.verbose += 1,
                'K' => opts.concatenated = true,
                'V' => {
                    println!("brotli 1.2.0");
                    std::process::exit(0);
                }
                'Z' => opts.quality = 11,
                'q' | 'w' | 'o' | 'S' | 'C' | 'D' => {
                    let rest: String = chars[j + 1..].iter().collect();
                    let val = if rest.is_empty() { take_arg(&args, &mut i, &format!("-{}", chars[j])) } else { rest };
                    match chars[j] {
                        'q' => opts.quality = parse_num(&val, "quality", 0, 11),
                        'w' => opts.lgwin = parse_lgwin(&val, false),
                        'o' => opts.output = Some(val),
                        'S' => opts.suffix = val,
                        'C' => validate_comment(&val),
                        'D' => {}
                        _ => {}
                    }
                    break;
                }
                c => usage_err(format!("invalid argument -{}", c)),
            }
            j += 1;
        }
        i += 1;
    }
    if opts.files.is_empty() {
        opts.files.push("-".to_string());
    }
    if opts.output.is_some() && opts.files.len() != 1 {
        usage_err("write to output is only allowed for a single input");
    }
    opts
}

fn parse_lgwin(v: &str, large: bool) -> i32 {
    let n = match v.parse::<i32>() {
        Ok(x) => x,
        Err(_) => usage_err(format!("error parsing lgwin value [{}]", v)),
    };
    let max = if large { 30 } else { 24 };
    if n != 0 && n < 10 {
        usage_err(format!("lgwin parameter ({}) smaller than the minimum (10)", n));
    }
    if n > max {
        usage_err(format!("lgwin parameter ({}) larger than the maximum ({})", n, max));
    }
    n
}

fn validate_comment(v: &str) {
    match base64::engine::general_purpose::STANDARD.decode(v) {
        Ok(bytes) if bytes.len() <= 80 => {}
        _ => usage_err("invalid base64-encoded comment"),
    }
}

fn compress(input: &[u8], quality: i32, lgwin: i32) -> Result<Vec<u8>, String> {
    let mut cap = unsafe { BrotliEncoderMaxCompressedSize(input.len()) };
    if cap == 0 {
        cap = input.len().saturating_add(1024).max(1024);
    }
    let mut out = vec![0u8; cap];
    let mut encoded = out.len();
    let ok = unsafe {
        BrotliEncoderCompress(
            quality,
            lgwin,
            0,
            input.len(),
            input.as_ptr(),
            &mut encoded,
            out.as_mut_ptr(),
        )
    };
    if ok == 0 {
        return Err("compression failed".to_string());
    }
    out.truncate(encoded);
    Ok(out)
}

fn decompress_once(input: &[u8]) -> Result<(Vec<u8>, usize), String> {
    let state = unsafe { BrotliDecoderCreateInstance(ptr::null_mut(), ptr::null_mut(), ptr::null_mut()) };
    if state.is_null() {
        return Err("decoder allocation failed".to_string());
    }
    let mut available_in = input.len();
    let mut next_in = input.as_ptr();
    let start = input.as_ptr() as usize;
    let mut out = Vec::new();
    let mut total = 0usize;
    loop {
        let old_len = out.len();
        out.resize(old_len + 64 * 1024, 0);
        let mut available_out = out.len() - old_len;
        let mut next_out = unsafe { out.as_mut_ptr().add(old_len) };
        let result = unsafe {
            BrotliDecoderDecompressStream(
                state,
                &mut available_in,
                &mut next_in,
                &mut available_out,
                &mut next_out,
                &mut total,
            )
        };
        let produced = (out.len() - old_len) - available_out;
        out.truncate(old_len + produced);
        if result == 0 {
            unsafe { BrotliDecoderDestroyInstance(state) };
            return Err("corrupt input".to_string());
        }
        if unsafe { BrotliDecoderIsFinished(state) } != 0 || result == 1 {
            let consumed = (next_in as usize).saturating_sub(start);
            unsafe { BrotliDecoderDestroyInstance(state) };
            return Ok((out, consumed));
        }
        if result == 2 && available_in == 0 {
            unsafe { BrotliDecoderDestroyInstance(state) };
            return Err("corrupt input".to_string());
        }
    }
}

fn decompress(input: &[u8], concatenated: bool) -> Result<Vec<u8>, String> {
    let mut pos = 0usize;
    let mut out = Vec::new();
    loop {
        let (chunk, used) = decompress_once(&input[pos..])?;
        if used == 0 {
            return Err("corrupt input".to_string());
        }
        out.extend_from_slice(&chunk);
        pos += used;
        if pos >= input.len() {
            return Ok(out);
        }
        if !concatenated {
            return Err("corrupt input".to_string());
        }
    }
}

fn input_label(name: &str) -> &str {
    if name == "-" { "con" } else { name }
}

fn read_input(name: &str) -> Result<Vec<u8>, String> {
    let mut data = Vec::new();
    if name == "-" {
        io::stdin().read_to_end(&mut data).map_err(|e| format!("failed to read input [con]: {}", e))?;
    } else {
        File::open(name)
            .map_err(|e| format!("failed to open input file [{}]: {}", name, e))?
            .read_to_end(&mut data)
            .map_err(|e| format!("failed to read input file [{}]: {}", name, e))?;
    }
    Ok(data)
}

fn output_path(opts: &Options, input: &str) -> Result<Option<PathBuf>, String> {
    if opts.stdout || opts.test || input == "-" {
        return Ok(opts.output.as_ref().map(PathBuf::from));
    }
    if let Some(o) = &opts.output {
        return Ok(Some(PathBuf::from(o)));
    }
    if opts.decompress {
        if !input.ends_with(&opts.suffix) {
            return Err(format!("input file [{}] suffix mismatch", input));
        }
        Ok(Some(PathBuf::from(&input[..input.len() - opts.suffix.len()])))
    } else {
        Ok(Some(PathBuf::from(format!("{}{}", input, opts.suffix))))
    }
}

fn write_output(path: Option<&Path>, data: &[u8], opts: &Options) -> Result<(), String> {
    if let Some(p) = path {
        let mut open = OpenOptions::new();
        open.write(true).create(true);
        if opts.force {
            open.truncate(true);
        } else {
            open.create_new(true);
        }
        let mut f = open.open(p).map_err(|e| format!("failed to open output file [{}]: {}", p.display(), e))?;
        f.write_all(data).map_err(|e| format!("failed to write output file [{}]: {}", p.display(), e))?;
    } else if !opts.test {
        io::stdout().write_all(data).map_err(|e| format!("failed to write output [con]: {}", e))?;
    }
    Ok(())
}

fn process_file(opts: &Options, name: &str) -> Result<(), String> {
    let input = read_input(name)?;
    let out_path = output_path(opts, name)?;
    let output = if opts.decompress {
        decompress(&input, opts.concatenated)?
    } else {
        compress(&input, opts.quality, opts.lgwin)?
    };
    if opts.squash && !opts.decompress && name != "-" && output.len() > input.len() {
        if let Some(p) = &out_path {
            let _ = fs::remove_file(p);
        }
        return Ok(());
    }
    write_output(out_path.as_deref(), &output, opts)?;
    if opts.remove && name != "-" {
        let _ = fs::remove_file(name);
    }
    if opts.verbose > 0 && name != "-" && !opts.test {
        let action = if opts.decompress { "Decompressed" } else { "Compressed" };
        eprintln!("{} [{}]: {} B -> {} B", action, name, input.len(), output.len());
    }
    Ok(())
}

fn main() {
    let opts = parse_args();
    let mut status = 0;
    for f in &opts.files {
        if let Err(e) = process_file(&opts, f) {
            if e == "corrupt input" {
                eprintln!("corrupt input [{}]", input_label(f));
            } else {
                eprintln!("{}", e);
            }
            status = 1;
        }
    }
    std::process::exit(status);
}
