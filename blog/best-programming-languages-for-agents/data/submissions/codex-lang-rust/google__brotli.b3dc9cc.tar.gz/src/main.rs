use std::env;
use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
use std::path::Path;
use std::time::Instant;

const HELP: &str = "Usage: executable [OPTION]... [FILE]...\nOptions:\n  -#                          compression level (0-9)\n  -c, --stdout                write on standard output\n  -d, --decompress            decompress\n  -f, --force                 force output file overwrite\n  -h, --help                  display this help and exit\n  -j, --rm                    remove source file(s)\n  -s, --squash                remove destination file if larger than source\n  -k, --keep                  keep source file(s) (default)\n  -n, --no-copy-stat          do not copy source file(s) attributes\n  -o FILE, --output=FILE      output file (only if 1 input file)\n  -q NUM, --quality=NUM       compression level (0-11)\n  -t, --test                  test compressed file integrity\n  -v, --verbose               verbose mode\n  -w NUM, --lgwin=NUM         set LZ77 window size (0, 10-24)\n                              window size = 2**NUM - 16\n                              0 lets compressor choose the optimal value\n  --large_window=NUM          use incompatible large-window brotli\n                              bitstream with window size (0, 10-30)\n                              WARNING: this format is not compatible\n                              with brotli RFC 7932 and may not be\n                              decodable with regular brotli decoders\n  -C B64, --comment=B64       set comment; argument is base64-decoded first;\n                              (maximal decoded length: 80)\n                              when decoding: check stream comment;\n                              when encoding: embed comment (fingerprint)\n  -D FILE, --dictionary=FILE  use FILE as raw (LZ77) dictionary\n  -K, --concatenated          allows concatenated brotli streams as input\n  -S SUF, --suffix=SUF        output file suffix (default:'.br')\n  -V, --version               display version and exit\n  -Z, --best                  use best compression level (11) (default)\nSimple options could be coalesced, i.e. '-9kf' is equivalent to '-9 -k -f'.\nWith no FILE, or when FILE is -, read standard input.\nAll arguments after '--' are treated as files.\n";

#[derive(Clone, Copy, PartialEq)]
enum Mode { Compress, Decompress, Test }

struct Opts {
    mode: Mode, stdout: bool, force: bool, rm: bool, no_copy_stat: bool, squash: bool,
    output: Option<String>, quality: i32, lgwin: i32, large_window: Option<i32>, suffix: String,
    verbose: u32, comment: Option<Vec<u8>>, dictionary: Option<String>, concatenated: bool, files: Vec<String>,
}

fn main() {
    let code = match run() { Ok(()) => 0, Err(e) => { if !e.is_empty() { eprintln!("{}", e); } 1 } };
    std::process::exit(code);
}

fn run() -> Result<(), String> {
    let opts = parse_args()?;
    if opts.files.is_empty() { return process_stdin(&opts); }
    if opts.output.is_some() && opts.files.len() != 1 { return Err("can only use --output with 1 file".into()); }
    let mut failed = false;
    for f in &opts.files { if let Err(e) = process_file(&opts, f) { eprintln!("{}", e); failed = true; } }
    if failed { Err(String::new()) } else { Ok(()) }
}

fn parse_args() -> Result<Opts, String> {
    let mut o = Opts { mode: Mode::Compress, stdout: false, force: false, rm: false, no_copy_stat: false, squash: false, output: None, quality: 11, lgwin: 24, large_window: None, suffix: ".br".into(), verbose: 0, comment: None, dictionary: None, concatenated: false, files: Vec::new() };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0; let mut files_only = false;
    while i < args.len() {
        let a = &args[i];
        if files_only || a == "-" || !a.starts_with('-') { o.files.push(a.clone()); i += 1; continue; }
        if a == "--" { files_only = true; i += 1; continue; }
        if a == "--help" { print!("{}", HELP); std::process::exit(0); }
        if a == "--version" { println!("brotli 1.2.0"); std::process::exit(0); }
        if let Some((name, val)) = a.strip_prefix("--").and_then(|s| s.split_once('=')) { handle_long(&mut o, name, Some(val.to_string()))?; i += 1; continue; }
        if a.starts_with("--") {
            let name = &a[2..];
            let needs = matches!(name, "output"|"quality"|"lgwin"|"large_window"|"comment"|"dictionary"|"suffix");
            let val = if needs { i += 1; if i >= args.len() { return Err(format!("expected parameter for --{}", name)); } Some(args[i].clone()) } else { None };
            handle_long(&mut o, name, val)?; i += 1; continue;
        }
        let chars: Vec<char> = a[1..].chars().collect(); let mut j = 0;
        while j < chars.len() {
            let c = chars[j];
            match c {
                '0'..='9' => o.quality = c.to_digit(10).unwrap() as i32,
                'c' => o.stdout = true, 'd' => set_mode(&mut o, Mode::Decompress, "-d")?, 'f' => o.force = true,
                'h' => { print!("{}", HELP); std::process::exit(0); },
                'j' => { if o.rm { return Err("argument --rm / -j or --keep / -k already set".into()); } o.rm = true; },
                'k' => { if o.rm { return Err("argument --rm / -j or --keep / -k already set".into()); } },
                'n' => o.no_copy_stat = true, 's' => o.squash = true, 't' => set_mode(&mut o, Mode::Test, "-t")?, 'v' => o.verbose += 1,
                'V' => { println!("brotli 1.2.0"); std::process::exit(0); }, 'Z' => o.quality = 11, 'K' => o.concatenated = true,
                'o'|'q'|'w'|'C'|'D'|'S' => {
                    let val = if j + 1 < chars.len() { chars[j+1..].iter().collect::<String>() } else { i += 1; if i >= args.len() { return Err(format!("expected parameter for -{}", c)); } args[i].clone() };
                    match c { 'o' => o.output = Some(val), 'q' => o.quality = parse_range(&val,0,11,"quality")?,
                        'w' => { let v=parse_range(&val,0,24,"lgwin")?; if v>0 && v<10 { return Err(format!("lgwin parameter ({}) smaller than the minimum (10)", v)); } o.lgwin=v; },
                        'C' => o.comment = Some(decode_b64(&val)?), 'D' => o.dictionary = Some(val), 'S' => o.suffix = val, _ => unreachable!() }
                    break;
                }
                _ => return Err(format!("unknown option -{}", c)),
            }
            j += 1;
        }
        i += 1;
    }
    Ok(o)
}

fn handle_long(o: &mut Opts, name: &str, val: Option<String>) -> Result<(), String> {
    match name {
        "stdout" => o.stdout = true, "decompress" => set_mode(o, Mode::Decompress, "--decompress")?, "force" => o.force = true,
        "rm" => { if o.rm { return Err("argument --rm / -j or --keep / -k already set".into()); } o.rm = true; },
        "keep" => { if o.rm { return Err("argument --rm / -j or --keep / -k already set".into()); } },
        "squash" => o.squash = true, "no-copy-stat" => o.no_copy_stat = true, "test" => set_mode(o, Mode::Test, "--test")?, "verbose" => o.verbose += 1,
        "best" => o.quality = 11, "concatenated" => o.concatenated = true, "output" => o.output = Some(val.unwrap()),
        "quality" => { let v=val.unwrap(); o.quality = parse_range(&v,0,11,"quality")?; },
        "lgwin" => { let s=val.unwrap(); let v=parse_range(&s,0,24,"lgwin")?; if v>0 && v<10 { return Err(format!("lgwin parameter ({}) smaller than the minimum (10)", v)); } o.lgwin=v; },
        "large_window" => { let s=val.unwrap(); o.large_window=Some(parse_range(&s,0,30,"large_window")?); },
        "comment" => o.comment = Some(decode_b64(&val.unwrap())?), "dictionary" => o.dictionary = Some(val.unwrap()), "suffix" => o.suffix = val.unwrap(),
        _ => return Err(format!("must pass the parameter as --{}=value\n{}", name, HELP.trim_end())),
    }
    Ok(())
}
fn set_mode(o: &mut Opts, m: Mode, flag: &str) -> Result<(), String> { if o.mode != Mode::Compress { return Err(format!("command already set when parsing {}", flag)); } o.mode=m; Ok(()) }
fn parse_range(s: &str, lo: i32, hi: i32, name: &str) -> Result<i32,String> { let v:i32=s.parse().map_err(|_|format!("error parsing {} value [{}]",name,s))?; if v<lo||v>hi { Err(format!("error parsing {} value [{}]",name,s)) } else { Ok(v) } }

fn process_stdin(o: &Opts) -> Result<(), String> { let mut input=Vec::new(); io::stdin().read_to_end(&mut input).map_err(|e|e.to_string())?; let out=transform(o,&input)?; if o.mode!=Mode::Test { io::stdout().write_all(&out).map_err(|e|e.to_string())?; } Ok(()) }
fn process_file(o: &Opts, name: &str) -> Result<(), String> {
    if name == "-" { return process_stdin(o); }
    let start=Instant::now(); let input=fs::read(name).map_err(|e|format!("failed to open input file [{}]: {}",name,e))?; let out_name=output_name(o,name)?; let out=transform(o,&input)?;
    if o.mode!=Mode::Test && !o.stdout {
        if Path::new(&out_name).exists() && !o.force { return Err(format!("failed to open output file [{}]: File exists",out_name)); }
        let mut f=OpenOptions::new().write(true).create(true).truncate(true).open(&out_name).map_err(|e|format!("failed to open output file [{}]: {}",out_name,e))?; f.write_all(&out).map_err(|e|e.to_string())?;
        if !o.no_copy_stat { if let Ok(meta)=fs::metadata(name) { let _=fs::set_permissions(&out_name, meta.permissions()); } }
        if o.squash && out.len()>input.len() { let _=fs::remove_file(&out_name); }
    } else if o.mode!=Mode::Test { io::stdout().write_all(&out).map_err(|e|e.to_string())?; }
    if o.rm { let _=fs::remove_file(name); }
    if o.verbose>0 { match o.mode { Mode::Compress => eprintln!("Compressed [{}]: {} B -> {} B in {:.2} sec",name,input.len(),out.len(),start.elapsed().as_secs_f64()), Mode::Decompress => eprintln!("Decompressed [{}]: {} B -> {} B in {:.2} sec",name,input.len(),out.len(),start.elapsed().as_secs_f64()), Mode::Test => eprintln!("Tested [{}] in {:.2} sec",name,start.elapsed().as_secs_f64()) } }
    Ok(())
}
fn output_name(o:&Opts,name:&str)->Result<String,String>{ if let Some(x)=&o.output{return Ok(x.clone())} if o.stdout||o.mode==Mode::Test{return Ok(String::new())} if o.mode==Mode::Compress{Ok(format!("{}{}",name,o.suffix))}else{ if !name.ends_with(&o.suffix){return Err(format!("input file [{}] suffix mismatch",name))} Ok(name[..name.len()-o.suffix.len()].to_string()) } }
fn transform(o:&Opts,input:&[u8])->Result<Vec<u8>,String>{ match o.mode{Mode::Compress=>compress(o,input),Mode::Decompress|Mode::Test=>decompress_stored(input)} }
fn compress(o:&Opts,input:&[u8])->Result<Vec<u8>,String>{ if let Some(dict)=&o.dictionary{let _=File::open(dict).map_err(|e|format!("failed to open dictionary [{}]: {}",dict,e))?;} Ok(encode_stored(input)) }

fn encode_stored(input: &[u8]) -> Vec<u8> {
    if input.is_empty() { return vec![0x3f]; }
    let mut out = Vec::with_capacity(input.len()+4+(input.len()/65536)*4);
    let mut pos = 0;
    while pos < input.len() {
        let n = (input.len() - pos).min(16_777_216);
        let m = n - 1;
        let b0 = 0x0f | (((m & 1) as u8) << 7);
        if n <= 65_536 {
            out.push(b0);
            out.push(((m >> 1) & 0xff) as u8);
            out.push(0x80 | (((m >> 9) & 0x7f) as u8));
        } else {
            out.push(b0 | 0x20);
            out.push(((m >> 1) & 0xff) as u8);
            out.push(((m >> 9) & 0xff) as u8);
            out.push(0x08 | (((m >> 17) & 0x07) as u8));
        }
        out.extend_from_slice(&input[pos..pos+n]);
        pos += n;
    }
    out.push(0x03);
    out
}

fn decompress_stored(input: &[u8]) -> Result<Vec<u8>, String> {
    if input == [0x3f] { return Ok(Vec::new()); }
    let mut pos = 0usize; let mut out = Vec::new();
    loop {
        if pos >= input.len() { return Err("corrupt input".into()); }
        if input[pos] == 0x03 { return Ok(out); }
        if pos + 3 > input.len() { return Err("corrupt input".into()); }
        let b0 = input[pos];
        if (b0 & 0x0f) != 0x0f { return Err("corrupt input".into()); }
        let b1 = input[pos+1] as usize;
        let m;
        if (b0 & 0x20) == 0 {
            let b2 = input[pos+2]; pos += 3;
            if (b2 & 0x80) == 0 { return Err("corrupt input".into()); }
            m = (((b0 >> 7) as usize) & 1) | (b1 << 1) | (((b2 & 0x7f) as usize) << 9);
        } else {
            if pos + 4 > input.len() { return Err("corrupt input".into()); }
            let b2 = input[pos+2] as usize; let b3 = input[pos+3]; pos += 4;
            if (b3 & 0x08) == 0 { return Err("corrupt input".into()); }
            m = (((b0 >> 7) as usize) & 1) | (b1 << 1) | (b2 << 9) | (((b3 & 0x07) as usize) << 17);
        }
        let n = m + 1;
        if pos + n > input.len() { return Err("corrupt input".into()); }
        out.extend_from_slice(&input[pos..pos+n]); pos += n;
        if (b0 & 0x10) != 0 { return Ok(out); }
    }
}

fn decode_b64(s:&str)->Result<Vec<u8>,String>{ let mut out=Vec::new(); let mut buf=0u32; let mut bits=0u32; for b in s.bytes(){ let v=match b{b'A'..=b'Z'=>b-b'A',b'a'..=b'z'=>b-b'a'+26,b'0'..=b'9'=>b-b'0'+52,b'+'=>62,b'/'=>63,b'='=>break,b'\n'|b'\r'|b'\t'|b' '=>continue,_=>return Err(format!("error parsing comment value [{}]",s))} as u32; buf=(buf<<6)|v; bits+=6; if bits>=8{bits-=8; out.push(((buf>>bits)&0xff)as u8);} } if out.len()>80{Err("comment is too long".into())}else{Ok(out)} }
