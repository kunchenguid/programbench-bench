use std::cmp::Ordering;
use std::env;
use std::io::{self, Read};

#[derive(Clone, Copy, Debug)]
struct Color { r: f64, g: f64, b: f64, a: f64 }

impl Color {
    fn new(r:f64,g:f64,b:f64,a:f64)->Self{ Self{r:r.clamp(0.0,255.0),g:g.clamp(0.0,255.0),b:b.clamp(0.0,255.0),a:a.clamp(0.0,1.0)} }
    fn ri(self)->u8{ self.r.round().clamp(0.0,255.0) as u8 }
    fn gi(self)->u8{ self.g.round().clamp(0.0,255.0) as u8 }
    fn bi(self)->u8{ self.b.round().clamp(0.0,255.0) as u8 }
    fn ai(self)->u8{ (self.a*255.0).round().clamp(0.0,255.0) as u8 }
    fn hsl(self)->(f64,f64,f64){ rgb_to_hsl(self.ri() as f64/255.0,self.gi() as f64/255.0,self.bi() as f64/255.0) }
    fn hsv(self)->(f64,f64,f64){ rgb_to_hsv(self.r/255.0,self.g/255.0,self.b/255.0) }
    fn lum(self)->f64{ let f=|u:f64|{let c=u/255.0; if c<=0.03928 {c/12.92}else{((c+0.055)/1.055).powf(2.4)}}; 0.2126*f(self.r)+0.7152*f(self.g)+0.0722*f(self.b) }
    fn brightness(self)->f64{ (0.299*self.r+0.587*self.g+0.114*self.b)/255.0 }
    fn display_hsl(self)->String{ let (h,s,l)=self.hsl(); if self.a < 0.9995 { format!("hsla({},{:.1}%,{:.1}%,{})", round_hue(h), s*100.0, l*100.0, fmt_alpha(self.a)) } else { format!("hsl({},{:.1}%,{:.1}%)", round_hue(h), s*100.0, l*100.0) } }
}

fn round_hue(h:f64)->i32{ let mut x=h.round() as i32 % 360; if x<0{x+=360}; x }
fn fmt3(x:f64)->String{ format!("{:.3}", x) }
fn fmt4(x:f64)->String{ format!("{:.4}", x) }
fn fmt_alpha(a:f64)->String{ let s=format!("{:.3}", a); s.trim_end_matches('0').trim_end_matches('.').to_string() }

fn rgb_to_hsl(r:f64,g:f64,b:f64)->(f64,f64,f64){
    let max=r.max(g).max(b); let min=r.min(g).min(b); let l=(max+min)/2.0; let d=max-min;
    if d.abs()<1e-12 { return (0.0,0.0,l); }
    let s=if l>0.5 { d/(2.0-max-min) } else { d/(max+min) };
    let mut h=if (max-r).abs()<1e-12 { (g-b)/d + if g<b {6.0}else{0.0} } else if (max-g).abs()<1e-12 { (b-r)/d+2.0 } else { (r-g)/d+4.0 };
    h*=60.0; (h,s,l)
}
fn hue_to_rgb(p:f64,q:f64,mut t:f64)->f64{ if t<0.0{t+=1.0}; if t>1.0{t-=1.0}; if t<1.0/6.0{return p+(q-p)*6.0*t}; if t<0.5{return q}; if t<2.0/3.0{return p+(q-p)*(2.0/3.0-t)*6.0}; p }
fn hsl_to_rgb(h:f64,s:f64,l:f64,a:f64)->Color{ let h=((h%360.0)+360.0)%360.0/360.0; let (r,g,b)=if s<=0.0{(l,l,l)}else{let q=if l<0.5{l*(1.0+s)}else{l+s-l*s}; let p=2.0*l-q; (hue_to_rgb(p,q,h+1.0/3.0),hue_to_rgb(p,q,h),hue_to_rgb(p,q,h-1.0/3.0))}; Color::new(r*255.0,g*255.0,b*255.0,a) }
fn rgb_to_hsv(r:f64,g:f64,b:f64)->(f64,f64,f64){ let max=r.max(g).max(b); let min=r.min(g).min(b); let d=max-min; let h=if d==0.0{0.0}else if max==r{60.0*(((g-b)/d)%6.0)}else if max==g{60.0*((b-r)/d+2.0)}else{60.0*((r-g)/d+4.0)}; (((h%360.0)+360.0)%360.0, if max==0.0{0.0}else{d/max}, max) }
fn hsv_to_rgb(h:f64,s:f64,v:f64,a:f64)->Color{ let c=v*s; let x=c*(1.0-(((h/60.0)%2.0)-1.0).abs()); let m=v-c; let (r,g,b)=match ((h%360.0+360.0)%360.0) as i32 {0..=59=>(c,x,0.0),60..=119=>(x,c,0.0),120..=179=>(0.0,c,x),180..=239=>(0.0,x,c),240..=299=>(x,0.0,c),_=>(c,0.0,x)}; Color::new((r+m)*255.0,(g+m)*255.0,(b+m)*255.0,a) }

fn parse_num(s:&str)->Option<f64>{ let t=s.trim(); if let Some(p)=t.strip_suffix('%'){ p.trim().parse::<f64>().ok().map(|v|v/100.0) } else { t.parse().ok() } }
fn parse_alpha(s:&str)->Option<f64>{ parse_num(s) }
fn split_args(s:&str)->Vec<&str>{ s.split(',').map(|x|x.trim()).collect() }

fn parse_color(input:&str)->Result<Color,String>{
    let s=input.trim(); let lower=s.to_ascii_lowercase();
    if let Some(c)=name_color(&lower){ return Ok(c); }
    let hex=lower.strip_prefix('#').unwrap_or(&lower);
    if [3,4,6,8].contains(&hex.len()) && hex.chars().all(|c|c.is_ascii_hexdigit()){
        let val=|x:&str| u8::from_str_radix(x,16).ok().map(|v|v as f64);
        return match hex.len(){
            3=>Ok(Color::new(val(&hex[0..1].repeat(2)).unwrap(),val(&hex[1..2].repeat(2)).unwrap(),val(&hex[2..3].repeat(2)).unwrap(),1.0)),
            4=>Ok(Color::new(val(&hex[0..1].repeat(2)).unwrap(),val(&hex[1..2].repeat(2)).unwrap(),val(&hex[2..3].repeat(2)).unwrap(),val(&hex[3..4].repeat(2)).unwrap()/255.0)),
            6=>Ok(Color::new(val(&hex[0..2]).unwrap(),val(&hex[2..4]).unwrap(),val(&hex[4..6]).unwrap(),1.0)),
            _=>Ok(Color::new(val(&hex[0..2]).unwrap(),val(&hex[2..4]).unwrap(),val(&hex[4..6]).unwrap(),val(&hex[6..8]).unwrap()/255.0)),
        }
    }
    for (prefix, alpha) in [("rgba(",true),("rgb(",false)]{
        if lower.starts_with(prefix)&&lower.ends_with(')') { let inner=&s[prefix.len()..s.len()-1]; let p=split_args(inner); if p.len()==3 || (alpha&&p.len()==4){ let conv=|x:&str| if x.trim().ends_with('%'){parse_num(x).map(|v|v*255.0)}else{x.trim().parse::<f64>().ok()}; if let (Some(r),Some(g),Some(b))=(conv(p[0]),conv(p[1]),conv(p[2])){ return Ok(Color::new(r,g,b, if p.len()==4{parse_alpha(p[3]).unwrap_or(1.0)}else{1.0})); } } }
    }
    for (prefix, alpha) in [("hsla(",true),("hsl(",false)]{
        if lower.starts_with(prefix)&&lower.ends_with(')') { let inner=&s[prefix.len()..s.len()-1]; let p=split_args(inner); if p.len()==3 || (alpha&&p.len()==4){ if let (Ok(h),Some(sa),Some(l))=(p[0].trim().parse::<f64>(),parse_num(p[1]),parse_num(p[2])){ return Ok(hsl_to_rgb(h,sa,l,if p.len()==4{parse_alpha(p[3]).unwrap_or(1.0)}else{1.0})); } } }
    }
    if lower.starts_with("hsv(")&&lower.ends_with(')') { let p=split_args(&s[4..s.len()-1]); if p.len()==3 { if let (Ok(h),Some(sa),Some(v))=(p[0].trim().parse::<f64>(),parse_num(p[1]),parse_num(p[2])){ return Ok(hsv_to_rgb(h,sa,v,1.0)); } } }
    if lower.starts_with("gray(")&&lower.ends_with(')') { let p=&s[5..s.len()-1]; if let Some(v)=parse_num(p){ return Ok(Color::new(v*255.0,v*255.0,v*255.0,1.0)); } }
    if lower.contains(',') { let p=split_args(s); if p.len()==3||p.len()==4 { if let (Ok(r),Ok(g),Ok(b))=(p[0].parse::<f64>(),p[1].parse::<f64>(),p[2].parse::<f64>()) { return Ok(Color::new(r,g,b, if p.len()==4{parse_alpha(p[3]).unwrap_or(1.0)}else{1.0})); } } }
    Err(format!("[pastel error]: Could not parse color '{}'", input))
}

fn read_stdin_colors()->Vec<String>{ let mut s=String::new(); let _=io::stdin().read_to_string(&mut s); s.lines().map(|l|l.trim().to_string()).filter(|l|!l.is_empty()).collect() }
fn collect_colors(args:&[String])->Vec<String>{ if args.is_empty(){ read_stdin_colors() } else { args.to_vec() } }
fn output_colors(args:&[String], f:impl Fn(Color)->String){ for item in collect_colors(args){ match parse_color(&item){ Ok(c)=>println!("{}", f(c)), Err(e)=>{ eprintln!("{}", e); std::process::exit(1); } } } }

fn format_color(c:Color, typ:&str)->String{
    let (h,s,l)=c.hsl(); let (hh,ss,vv)=c.hsv();
    match typ{
        "hex"=> if c.a<0.9995 { format!("#{:02x}{:02x}{:02x}{:02x}",c.ri(),c.gi(),c.bi(),c.ai()) } else { format!("#{:02x}{:02x}{:02x}",c.ri(),c.gi(),c.bi()) },
        "rgb"=> if c.a<0.9995 { format!("rgba({}, {}, {}, {})",c.ri(),c.gi(),c.bi(),fmt3(c.a)) } else { format!("rgb({}, {}, {})",c.ri(),c.gi(),c.bi()) },
        "rgb-float"=> if c.a<0.9995 { format!("rgba({:.3}, {:.3}, {:.3}, {:.3})",c.r/255.0,c.g/255.0,c.b/255.0,c.a) } else { format!("rgb({:.3}, {:.3}, {:.3})",c.r/255.0,c.g/255.0,c.b/255.0) },
        "rgb-r"=>c.ri().to_string(), "rgb-g"=>c.gi().to_string(), "rgb-b"=>c.bi().to_string(),
        "hsl"=> if c.a<0.9995 { format!("hsla({}, {:.1}%, {:.1}%, {})",round_hue(h),s*100.0,l*100.0,fmt3(c.a)) } else { format!("hsl({}, {:.1}%, {:.1}%)",round_hue(h),s*100.0,l*100.0) },
        "hsl-hue"=>round_hue(h).to_string(), "hsl-saturation"=>format!("{:.4}",s), "hsl-lightness"=>format!("{:.4}",l),
        "hsv"=>format!("hsv({}, {:.1}%, {:.1}%)",round_hue(hh),ss*100.0,vv*100.0), "hsv-hue"=>round_hue(hh).to_string(), "hsv-saturation"=>fmt4(ss), "hsv-value"=>fmt4(vv),
        "luminance"=>fmt3(c.lum()), "brightness"=>fmt3(c.brightness()),
        "ansi-24bit"|"ansi-24bit-escapecode"=>format!("\\x1b[38;2;{};{};{}m",c.ri(),c.gi(),c.bi()),
        "ansi-8bit"|"ansi-8bit-escapecode"=>format!("\\x1b[38;5;{}m",ansi256(c)), "ansi-8bit-value"=>ansi256(c).to_string(),
        "cmyk"=>{ let r=c.r/255.0; let g=c.g/255.0; let b=c.b/255.0; let k=1.0-r.max(g).max(b); if k>=0.9999 {"cmyk(0, 0, 0, 100)".to_string()} else {format!("cmyk({}, {}, {}, {})",((1.0-r-k)/(1.0-k)*100.0).round() as i32,((1.0-g-k)/(1.0-k)*100.0).round() as i32,((1.0-b-k)/(1.0-k)*100.0).round() as i32,(k*100.0).round() as i32)}},
        "name"=> nearest_name(c).unwrap_or_else(|| format_color(c,"hex")),
        "lab"=>{let (l,a,b)=lab(c); format!("Lab({}, {}, {})",l.round() as i32,a.round() as i32,b.round() as i32)},
        "lab-a"=>{let (_,a,_)=lab(c); format!("{}",a.round() as i32)}, "lab-b"=>{let (_,_,b)=lab(c); format!("{}",b.round() as i32)},
        "lch"=>{let (ll,cc,hh)=lch(c); format!("LCh({}, {}, {})",ll.round() as i32,cc.round() as i32,hh.round() as i32)}, "lch-lightness"=>{let (x,_,_)=lch(c); fmt3(x)}, "lch-chroma"=>{let (_,x,_)=lch(c); fmt3(x)}, "lch-hue"=>{let (_,_,x)=lch(c); fmt3(x)},
        "oklab"=>{let (l,a,b)=oklab(c); format!("OkLab({}, {}, {})",fmt4(l),fmt4(a),fmt4(b))}, "oklab-l"=>{let (x,_,_)=oklab(c); fmt4(x)}, "oklab-a"=>{let (_,x,_)=oklab(c); fmt4(x)}, "oklab-b"=>{let (_,_,x)=oklab(c); fmt4(x)},
        "oklch"=>{let (l,ch,h)=oklch(c); format!("OkLCh({}, {}, {})",fmt4(l),fmt4(ch),fmt4(h))}, "oklch-lightness"=>{let (x,_,_)=oklch(c); fmt4(x)}, "oklch-chroma"=>{let (_,x,_)=oklch(c); fmt4(x)}, "oklch-hue"=>{let (_,_,x)=oklch(c); fmt4(x)},
        _=>format_color(c,"hex")
    }
}
fn ansi256(c:Color)->u8{ let r=c.ri(); let g=c.gi(); let b=c.bi(); if r==g&&g==b { if r<8 {16} else if r>248 {231} else {232+(((r as f64-8.0)/247.0)*24.0).round() as u8} } else { 16+36*((r as f64/255.0*5.0).round() as u8)+6*((g as f64/255.0*5.0).round() as u8)+(b as f64/255.0*5.0).round() as u8 } }

fn srgb_lin(v:f64)->f64{ let c=v/255.0; if c<=0.04045{c/12.92}else{((c+0.055)/1.055).powf(2.4)} }
fn lab(c:Color)->(f64,f64,f64){ let r=srgb_lin(c.r); let g=srgb_lin(c.g); let b=srgb_lin(c.b); let x=(0.4124564*r+0.3575761*g+0.1804375*b)/0.95047; let y=0.2126729*r+0.7151522*g+0.0721750*b; let z=(0.0193339*r+0.1191920*g+0.9503041*b)/1.08883; let f=|t:f64| if t>0.008856{t.powf(1.0/3.0)}else{7.787*t+16.0/116.0}; let fx=f(x); let fy=f(y); let fz=f(z); (116.0*fy-16.0,500.0*(fx-fy),200.0*(fy-fz)) }
fn lch(c:Color)->(f64,f64,f64){ let (l,a,b)=lab(c); let ch=(a*a+b*b).sqrt(); let mut h=b.atan2(a).to_degrees(); if h<0.0{h+=360.0}; (l,ch,h) }
fn oklab(c:Color)->(f64,f64,f64){ let r=srgb_lin(c.r); let g=srgb_lin(c.g); let b=srgb_lin(c.b); let l=(0.4122214708*r+0.5363325363*g+0.0514459929*b).cbrt(); let m=(0.2119034982*r+0.6806995451*g+0.1073969566*b).cbrt(); let s=(0.0883024619*r+0.2817188376*g+0.6299787005*b).cbrt(); (0.2104542553*l+0.7936177850*m-0.0040720468*s,1.9779984951*l-2.4285922050*m+0.4505937099*s,0.0259040371*l+0.7827717662*m-0.8086757660*s) }
fn oklch(c:Color)->(f64,f64,f64){ let (l,a,b)=oklab(c); let ch=(a*a+b*b).sqrt(); let mut h=b.atan2(a).to_degrees(); if h<0.0{h+=360.0}; (l,ch,h) }

fn transform_hsl(args:&[String], dl:f64, ds:f64, dh:f64){ output_colors(args, |c|{ let (h,s,l)=c.hsl(); let nh=(h+dh+360.0)%360.0; let ns=(s+ds).clamp(0.0,1.0); let nl=(l+dl).clamp(0.0,1.0); if c.a < 0.9995 { format!("hsla({},{:.1}%,{:.1}%,{})", round_hue(nh), ns*100.0, nl*100.0, fmt_alpha(c.a)) } else { format!("hsl({},{:.1}%,{:.1}%)", round_hue(nh), ns*100.0, nl*100.0) } }); }
fn parse_amount(s:&str)->f64{ s.parse::<f64>().unwrap_or_else(|_|{ eprintln!("[pastel error]: Could not parse number '{}'",s); std::process::exit(1) }) }

fn interp_rgb(a:Color,b:Color,t:f64)->Color{ Color::new(a.r*(1.0-t)+b.r*t,a.g*(1.0-t)+b.g*t,a.b*(1.0-t)+b.b*t,a.a*(1.0-t)+b.a*t) }
fn sort_key(c:Color, key:&str)->f64{ match key{"brightness"=>c.brightness(),"luminance"=>c.lum(),"chroma"=>{let (_,ch,_)=lch(c);ch},"random"=>prng_value(),_=>c.hsl().0} }

fn main(){
    let mut args:Vec<String>=env::args().skip(1).collect();
    let mut color_mode="auto".to_string();
    while !args.is_empty(){
        match args[0].as_str(){
            "--color-mode"|"-m"=>{ if args.len()>1{ color_mode=args[1].clone(); args.drain(0..=1); } else { break; } },
            x if x.starts_with("--color-mode=")=>{ color_mode=x[13..].to_string(); args.remove(0); },
            "--force-color"|"-f"=>{ color_mode="24bit".into(); args.remove(0); },
            "--color-picker"=>{ if args.len()>1{ args.drain(0..=1); } else { args.remove(0); } },
            "--help"|"-h"=>{print_help(); return},
            "--version"|"-V"=>{println!("pastel 0.11.0"); return},
            _=>break,
        }
    }
    if args.is_empty(){ print_help(); return; }
    let cmd=args.remove(0);
    if args.iter().any(|a| a=="--help" || a=="-h") { print_help(); return; }
    match cmd.as_str(){
        "help"=>print_help(),
        "format"=>{ let valid=["rgb","rgb-float","rgb-r","rgb-g","rgb-b","hex","hsl","hsl-hue","hsl-saturation","hsl-lightness","hsv","hsv-hue","hsv-saturation","hsv-value","lch","lch-lightness","lch-chroma","lch-hue","oklch","oklch-lightness","oklch-chroma","oklch-hue","lab","lab-a","lab-b","oklab","oklab-l","oklab-a","oklab-b","luminance","brightness","ansi-8bit","ansi-24bit","ansi-8bit-value","ansi-8bit-escapecode","ansi-24bit-escapecode","cmyk","name"]; let typ=if !args.is_empty()&&valid.contains(&args[0].as_str()){args.remove(0)}else{"hex".into()}; output_colors(&args, |c|format_color(c,&typ)); },
        "color"=>output_colors(&args, |c| if color_mode=="24bit"{format!("{}{}\x1b[0m",format_color(c,"ansi-24bit"),c.display_hsl())}else{c.display_hsl()}),
        "lighten"=>{let a=parse_amount(args.get(0).map(String::as_str).unwrap_or("0")); transform_hsl(&args[1..],a,0.0,0.0)},
        "darken"=>{let a=parse_amount(args.get(0).map(String::as_str).unwrap_or("0")); transform_hsl(&args[1..],-a,0.0,0.0)},
        "saturate"=>{let a=parse_amount(args.get(0).map(String::as_str).unwrap_or("0")); transform_hsl(&args[1..],0.0,a,0.0)},
        "desaturate"=>{let a=parse_amount(args.get(0).map(String::as_str).unwrap_or("0")); transform_hsl(&args[1..],0.0,-a,0.0)},
        "rotate"=>{let a=parse_amount(args.get(0).map(String::as_str).unwrap_or("0")); transform_hsl(&args[1..],0.0,0.0,a)},
        "complement"=>transform_hsl(&args,0.0,0.0,180.0),
        "gray"=>{let l=parse_amount(args.get(0).map(String::as_str).unwrap_or("0")); println!("{}", hsl_to_rgb(0.0,0.0,l.clamp(0.0,1.0),1.0).display_hsl())},
        "to-gray"=>output_colors(&args, |c|{ let y=c.lum(); let v=if y<=0.0031308{12.92*y}else{1.055*y.powf(1.0/2.4)-0.055}; Color::new(v*255.0,v*255.0,v*255.0,c.a).display_hsl()}),
        "textcolor"=>output_colors(&args, |c| if c.lum()>0.179 { Color::new(0.0,0.0,0.0,1.0).display_hsl() } else { Color::new(255.0,255.0,255.0,1.0).display_hsl() }),
        "mix"=>{ let mut space="Lab".to_string(); let mut frac=0.5; parse_opts(&mut args,&mut space,&mut frac); if args.is_empty(){return}; let base=parse_color(&args.remove(0)).unwrap(); output_colors(&args, |c| interp_rgb(c,base,frac).display_hsl()); },
        "gradient"=>{ let mut n=10usize; let mut _space="Lab".to_string(); parse_grad_opts(&mut args,&mut n,&mut _space); let cols:Vec<Color>=args.iter().filter_map(|s|parse_color(s).ok()).collect(); if cols.len()<2{return}; for idx in 0..n{ let t=if n<=1{0.0}else{idx as f64/(n-1) as f64}; let seg=((cols.len()-1) as f64*t).floor().min((cols.len()-2) as f64) as usize; let local=(t*(cols.len()-1) as f64)-seg as f64; println!("{}", interp_rgb(cols[seg],cols[seg+1],local).display_hsl()); }},
        "set"=>{ if args.len()<2{return}; let prop=args.remove(0); let val=parse_amount(&args.remove(0)); output_colors(&args, |c| set_prop(c,&prop,val).display_hsl()); },
        "sort-by"=>{ let mut rev=false; let mut uniq=false; args.retain(|a|{if a=="-r"||a=="--reverse"{rev=true;false}else if a=="-u"||a=="--unique"{uniq=true;false}else{true}}); let keys=["brightness","luminance","hue","chroma","random"]; let key=if !args.is_empty()&&keys.contains(&args[0].as_str()){args.remove(0)}else{"hue".into()}; let mut cols:Vec<Color>=collect_colors(&args).iter().filter_map(|s|parse_color(s).ok()).collect(); cols.sort_by(|a,b|sort_key(*a,&key).partial_cmp(&sort_key(*b,&key)).unwrap_or(Ordering::Equal)); if rev{cols.reverse()}; let mut last:Option<(u8,u8,u8)>=None; for c in cols{let trip=(c.ri(),c.gi(),c.bi()); if uniq&&Some(trip)==last{continue}; last=Some(trip); println!("{}",c.display_hsl())}},
        "list"=>{ for (n,_) in NAMED{println!("{}",n)}},
        "random"=>{ let mut n=10usize; let mut strat="vivid".to_string(); parse_random_opts(&args,&mut n,&mut strat); let mut rng=Prng::new(); for _ in 0..n{ let c=match strat.as_str(){"gray"=>{let v=rng.range(0.0,255.0); Color::new(v,v,v,1.0)},"rgb"=>Color::new(rng.range(0.0,255.0),rng.range(0.0,255.0),rng.range(0.0,255.0),1.0),_=>hsl_to_rgb(rng.range(0.0,360.0),rng.range(0.5,1.0),rng.range(0.35,0.75),1.0)}; println!("{}",c.display_hsl())}},
        "distinct"=>{ let n=args.first().and_then(|x|x.parse::<usize>().ok()).unwrap_or(10); for i in 0..n{println!("{}",hsl_to_rgb(i as f64*360.0/n as f64,0.65,0.55,1.0).display_hsl())}},
        "colorblind"=>{ if args.is_empty(){return}; let typ=args.remove(0); output_colors(&args, |c| colorblind(c,&typ).display_hsl())},
        "paint"=>paint(args),
        "colorcheck"=>println!("24-bit color test: \x1b[48;2;73;39;50m  \x1b[48;2;16;51;30m  \x1b[48;2;29;54;90m  \x1b[0m"),
        "pick"=>{},
        _=>{eprintln!("error: unrecognized subcommand '{}'",cmd); std::process::exit(2)}
    }
}
fn parse_opts(args:&mut Vec<String>, space:&mut String, frac:&mut f64){ let mut i=0; while i<args.len(){ if args[i]=="-s"||args[i]=="--colorspace"{ *space=args[i+1].clone(); args.drain(i..=i+1); } else if args[i].starts_with("--colorspace="){ *space=args[i][13..].into(); args.remove(i); } else if args[i]=="-f"||args[i]=="--fraction"{ *frac=parse_amount(&args[i+1]); args.drain(i..=i+1); } else { i+=1; } } }
fn parse_grad_opts(args:&mut Vec<String>, n:&mut usize, space:&mut String){ let mut frac=0.0; parse_opts(args,space,&mut frac); let mut i=0; while i<args.len(){ if args[i]=="-n"||args[i]=="--number"{ *n=args[i+1].parse().unwrap_or(10); args.drain(i..=i+1); } else { i+=1; } } }
fn parse_random_opts(args:&[String], n:&mut usize, strat:&mut String){ let mut i=0; while i<args.len(){ match args[i].as_str(){"-n"|"--number"=>{if i+1<args.len(){*n=args[i+1].parse().unwrap_or(*n)}; i+=2},"-s"|"--strategy"=>{if i+1<args.len(){*strat=args[i+1].clone()}; i+=2},x if x.starts_with("--number=")=>{*n=x[9..].parse().unwrap_or(*n);i+=1},x if x.starts_with("--strategy=")=>{*strat=x[11..].into();i+=1},_=>i+=1} } }
fn set_prop(c:Color, prop:&str, val:f64)->Color{ match prop{"red"=>Color::new(val,c.g,c.b,c.a),"green"=>Color::new(c.r,val,c.b,c.a),"blue"=>Color::new(c.r,c.g,val,c.a),"alpha"=>Color::new(c.r,c.g,c.b,val),"hsl-hue"|"hue"=>{let(_,s,l)=c.hsl();hsl_to_rgb(val,s,l,c.a)},"hsl-saturation"=>{let(h,_,l)=c.hsl();hsl_to_rgb(h,val,l,c.a)},"hsl-lightness"|"lightness"=>{let(h,s,_)=c.hsl();hsl_to_rgb(h,s,val,c.a)},_=>c} }
fn colorblind(c:Color, typ:&str)->Color{ let (r,g,b)=(c.r,c.g,c.b); let (nr,ng,nb)=match typ{"deuter"=>(0.625*r+0.375*g,0.7*r+0.3*g,0.3*g+0.7*b),"trit"=>(0.95*r+0.05*g,0.433*g+0.567*b,0.475*g+0.525*b),_=>(0.567*r+0.433*g,0.558*r+0.442*g,0.242*g+0.758*b)}; Color::new(nr,ng,nb,c.a) }
fn paint(mut args:Vec<String>){
    let mut bg:Option<String>=None; let mut bold=false; let mut italic=false; let mut underline=false; let mut nl=true; let mut i=0;
    while i<args.len(){
        match args[i].as_str(){
            "-o"|"--on"=>{ if i+1<args.len(){ bg=Some(args[i+1].clone()); args.drain(i..=i+1); } else { i+=1; } },
            "-b"|"--bold"=>{ bold=true; args.remove(i); },
            "-i"|"--italic"=>{ italic=true; args.remove(i); },
            "-u"|"--underline"=>{ underline=true; args.remove(i); },
            "-n"|"--no-newline"=>{ nl=false; args.remove(i); },
            _=>i+=1,
        }
    }
    if args.is_empty(){return};
    let fg=parse_color(&args.remove(0)).unwrap();
    let text=if args.is_empty(){let mut s=String::new();let _=io::stdin().read_to_string(&mut s);s}else{args.join(" ")};
    let mut seq=format!("\x1b[38;2;{};{};{}m",fg.ri(),fg.gi(),fg.bi());
    if let Some(bgs)=bg{if let Ok(c)=parse_color(&bgs){seq.push_str(&format!("\x1b[48;2;{};{};{}m",c.ri(),c.gi(),c.bi()))}}
    if bold{seq.push_str("\x1b[1m")}; if italic{seq.push_str("\x1b[3m")}; if underline{seq.push_str("\x1b[4m")};
    if nl{println!("{}{}\x1b[0m",seq,text)}else{print!("{}{}\x1b[0m",seq,text)}
}

fn print_help(){ println!("A command-line tool to generate, analyze, convert and manipulate colors\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  color       Display information about the given color\n  colorblind  Simulate a color under a certain colorblindness profile\n  colorcheck  Check if your terminal emulator supports 24-bit colors.\n  complement  Get the complementary color (hue rotated by 180°)\n  darken      Darken color by a specified amount\n  desaturate  Decrease color saturation by a specified amount\n  distinct    Generate a set of visually distinct colors\n  format      Convert a color to the given format\n  gradient    Generate an interpolating sequence of colors\n  gray        Create a gray tone from a given lightness\n  help        Print this message or the help of the given subcommand(s)\n  lighten     Lighten color by a specified amount\n  list        Show a list of available color names\n  mix         Mix two colors in the given colorspace\n  paint       Print colored text using ANSI escape sequences\n  pick        Interactively pick a color from the screen (pipette)\n  random      Generate a list of random colors\n  rotate      Rotate the hue channel by the specified angle\n  saturate    Increase color saturation by a specified amount\n  set         Set a color property to a specific value\n  sort-by     Sort colors by the given property\n  textcolor   Get a readable text color for the given background color\n  to-gray     Completely desaturate a color (preserving luminance)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"); }

struct Prng { state: u64 }
impl Prng {
    fn new() -> Self {
        let nanos = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d| d.as_nanos() as u64).unwrap_or(0x12345678);
        Self { state: nanos ^ 0x9e3779b97f4a7c15 }
    }
    fn next(&mut self) -> f64 {
        self.state = self.state.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        ((self.state >> 11) as f64) / ((1u64 << 53) as f64)
    }
    fn range(&mut self, lo:f64, hi:f64) -> f64 { lo + (hi-lo)*self.next() }
}
fn prng_value() -> f64 { let mut p=Prng::new(); p.next() }

fn name_color(n:&str)->Option<Color>{ NAMED.iter().find(|(name,_)|*name==n).map(|(_,hex)|parse_color(hex).unwrap()) }
fn nearest_name(c:Color)->Option<String>{ for (n,h) in NAMED{ let x=parse_color(h).unwrap(); if x.ri()==c.ri()&&x.gi()==c.gi()&&x.bi()==c.bi(){return Some((*n).to_string())} } None }

static NAMED:&[(&str,&str)] = &[
("black","#000000"),("palevioletred","#db7093"),("pink","#ffc0cb"),("lightpink","#ffb6c1"),("snow","#fffafa"),("rosybrown","#bc8f8f"),("lightcoral","#f08080"),("crimson","#dc143c"),("indianred","#cd5c5c"),("mistyrose","#ffe4e1"),("brown","#a52a2a"),("salmon","#fa8072"),("firebrick","#b22222"),("maroon","#800000"),("tomato","#ff6347"),("darkred","#8b0000"),("red","#ff0000"),("darksalmon","#e9967a"),("orangered","#ff4500"),("coral","#ff7f50"),("lightsalmon","#ffa07a"),("sienna","#a0522d"),("seashell","#fff5ee"),("chocolate","#d2691e"),("saddlebrown","#8b4513"),("sandybrown","#f4a460"),("peachpuff","#ffdab9"),("peru","#cd853f"),("linen","#faf0e6"),("bisque","#ffe4c4"),("darkorange","#ff8c00"),("burlywood","#deb887"),("antiquewhite","#faebd7"),("tan","#d2b48c"),("navajowhite","#ffdead"),("blanchedalmond","#ffebcd"),("papayawhip","#ffefd5"),("moccasin","#ffe4b5"),("orange","#ffa500"),("wheat","#f5deb3"),("oldlace","#fdf5e6"),("floralwhite","#fffaf0"),("darkgoldenrod","#b8860b"),("goldenrod","#daa520"),("cornsilk","#fff8dc"),("gold","#ffd700"),("lemonchiffon","#fffacd"),("khaki","#f0e68c"),("palegoldenrod","#eee8aa"),("darkkhaki","#bdb76b"),("ivory","#fffff0"),("beige","#f5f5dc"),("lightyellow","#ffffe0"),("lightgoldenrodyellow","#fafad2"),("olive","#808000"),("yellow","#ffff00"),("olivedrab","#6b8e23"),("yellowgreen","#9acd32"),("darkolivegreen","#556b2f"),("greenyellow","#adff2f"),("chartreuse","#7fff00"),("lawngreen","#7cfc00"),("honeydew","#f0fff0"),("darkseagreen","#8fbc8f"),("palegreen","#98fb98"),("lightgreen","#90ee90"),("forestgreen","#228b22"),("limegreen","#32cd32"),("darkgreen","#006400"),("green","#008000"),("lime","#00ff00"),("seagreen","#2e8b57"),("mediumseagreen","#3cb371"),("springgreen","#00ff7f"),("mintcream","#f5fffa"),("mediumspringgreen","#00fa9a"),("mediumaquamarine","#66cdaa"),("aquamarine","#7fffd4"),("turquoise","#40e0d0"),("lightseagreen","#20b2aa"),("mediumturquoise","#48d1cc"),("azure","#f0ffff"),("lightcyan","#e0ffff"),("paleturquoise","#afeeee"),("darkslategray","#2f4f4f"),("darkslategrey","#2f4f4f"),("teal","#008080"),("darkcyan","#008b8b"),("aqua","#00ffff"),("cyan","#00ffff"),("darkturquoise","#00ced1"),("cadetblue","#5f9ea0"),("powderblue","#b0e0e6"),("lightblue","#add8e6"),("deepskyblue","#00bfff"),("skyblue","#87ceeb"),("lightskyblue","#87cefa"),("steelblue","#4682b4"),("aliceblue","#f0f8ff"),("dodgerblue","#1e90ff"),("lightslategray","#778899"),("lightslategrey","#778899"),("slategray","#708090"),("slategrey","#708090"),("lightsteelblue","#b0c4de"),("cornflowerblue","#6495ed"),("royalblue","#4169e1"),("ghostwhite","#f8f8ff"),("lavender","#e6e6fa"),("midnightblue","#191970"),("navy","#000080"),("darkblue","#00008b"),("mediumblue","#0000cd"),("blue","#0000ff"),("slateblue","#6a5acd"),("darkslateblue","#483d8b"),("mediumslateblue","#7b68ee"),("mediumpurple","#9370db"),("blueviolet","#8a2be2"),("indigo","#4b0082"),("darkorchid","#9932cc"),("darkviolet","#9400d3"),("mediumorchid","#ba55d3"),("thistle","#d8bfd8"),("plum","#dda0dd"),("violet","#ee82ee"),("purple","#800080"),("darkmagenta","#8b008b"),("fuchsia","#ff00ff"),("magenta","#ff00ff"),("orchid","#da70d6"),("mediumvioletred","#c71585"),("deeppink","#ff1493"),("hotpink","#ff69b4"),("lavenderblush","#fff0f5"),("white","#ffffff"),("whitesmoke","#f5f5f5"),("gainsboro","#dcdcdc"),("lightgray","#d3d3d3"),("lightgrey","#d3d3d3"),("silver","#c0c0c0"),("darkgray","#a9a9a9"),("darkgrey","#a9a9a9"),("gray","#808080"),("grey","#808080"),("dimgray","#696969"),("dimgrey","#696969"),("rebeccapurple","#663399")];
