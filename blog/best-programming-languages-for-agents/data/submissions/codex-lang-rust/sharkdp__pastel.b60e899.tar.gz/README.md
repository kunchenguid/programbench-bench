pastel

pastel is a command-line tool to generate, analyze, convert and manipulate colors. It supports many color formats and color spaces and provides a set of subcommands for common color tasks.

Usage examples:

- Show help and list available commands:

  pastel

- Convert a color to a different format:

  pastel format hsl ff8000

- Generate distinct colors:

  pastel distinct 8

- Analyze or show colors:

  pastel color 556270 4ecdc4 c7f484 ff6b6b c44d58

- Pipe commands together:

  pastel random | pastel mix red | pastel lighten 0.2 | pastel format hex

For license information, see the included LICENSE files (LICENSE-APACHE and LICENSE-MIT).
