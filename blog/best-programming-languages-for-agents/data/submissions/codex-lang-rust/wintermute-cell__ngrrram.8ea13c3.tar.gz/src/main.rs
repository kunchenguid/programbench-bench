use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::path::Path;
use std::process;
use std::time::{Duration, Instant};

#[derive(Clone, Debug)]
struct Config {
    n: String,
    top: usize,
    combi: usize,
    rep: usize,
    wpm: usize,
    acc: usize,
    emu_in: String,
    emu_out: String,
    show_ortho: bool,
    nokb: bool,
    cat: bool,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            n: "2".to_string(),
            top: 50,
            combi: 2,
            rep: 3,
            wpm: 40,
            acc: 94,
            emu_in: String::new(),
            emu_out: String::new(),
            show_ortho: false,
            nokb: false,
            cat: false,
        }
    }
}

fn main() {
    let program = env::args()
        .next()
        .and_then(|s| Path::new(&s).file_name().map(|n| n.to_string_lossy().into_owned()))
        .unwrap_or_else(|| "executable".to_string());

    let cfg = match parse_args(&program) {
        Ok(Some(cfg)) => cfg,
        Ok(None) => return,
        Err((msg, code)) => {
            eprint!("{msg}");
            process::exit(code);
        }
    };

    if let Err(msg) = validate(&cfg) {
        eprintln!("{msg}");
        process::exit(1);
    }

    if !io::stdin().is_terminal() {
        print!("\x1b[?1049h");
        let _ = io::stdout().flush();
        eprintln!("Error: Os {{ code: 6, kind: Uncategorized, message: \"No such device or address\" }}");
        process::exit(1);
    }

    run_session(cfg);
}

fn parse_args(program: &str) -> Result<Option<Config>, (String, i32)> {
    let mut cfg = Config::default();
    let mut args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let arg = args[i].clone();
        match arg.as_str() {
            "-h" | "--help" => {
                print_help(program);
                return Ok(None);
            }
            "-n" | "--n" => cfg.n = take_value(&args, &mut i, "--n <2|3|4|w|file>")?,
            "-t" | "--top" => cfg.top = parse_number(&take_number_value(&args, &mut i, "--top <1-200>", program)?, "top", "<1-200>")?,
            "-c" | "--combi" => cfg.combi = parse_number(&take_number_value(&args, &mut i, "--combi <1-200>", program)?, "combi", "<1-200>")?,
            "-r" | "--rep" => cfg.rep = parse_number(&take_number_value(&args, &mut i, "--rep <number>", program)?, "rep", "<number>")?,
            "-w" | "--wpm" => cfg.wpm = parse_number(&take_number_value(&args, &mut i, "--wpm <number>", program)?, "wpm", "<number>")?,
            "-a" | "--acc" => cfg.acc = parse_number(&take_number_value(&args, &mut i, "--acc <0-100>", program)?, "acc", "<0-100>")?,
            "--emu-in" => cfg.emu_in = take_value(&args, &mut i, "--emu-in <layout>")?,
            "--emu-out" => cfg.emu_out = take_value(&args, &mut i, "--emu-out <layout>")?,
            "--show-ortho" => cfg.show_ortho = true,
            "--nokb" => cfg.nokb = true,
            "--cat" => cfg.cat = true,
            _ if arg.starts_with("--") => {
                return Err((format!("error: unexpected argument '{arg}' found\n\nUsage: {program} [OPTIONS]\n\nFor more information, try '--help'.\n"), 2));
            }
            _ if arg.starts_with('-') => {
                return Err((format!("error: unexpected argument '{arg}' found\n\nUsage: {program} [OPTIONS]\n\nFor more information, try '--help'.\n"), 2));
            }
            _ => {
                return Err((format!("error: unexpected argument '{arg}' found\n\nUsage: {program} [OPTIONS]\n\nFor more information, try '--help'.\n"), 2));
            }
        }
        i += 1;
    }
    args.clear();
    Ok(Some(cfg))
}

fn take_value(args: &[String], i: &mut usize, display: &str) -> Result<String, (String, i32)> {
    let name = display.split_whitespace().next().unwrap_or(display);
    if *i + 1 >= args.len() || args[*i + 1].starts_with('-') {
        return Err((format!("error: a value is required for '{display}' but none was supplied\n\nFor more information, try '--help'.\n"), 2));
    }
    *i += 1;
    let _ = name;
    Ok(args[*i].clone())
}

fn take_number_value(args: &[String], i: &mut usize, display: &str, program: &str) -> Result<String, (String, i32)> {
    if *i + 1 < args.len() && args[*i + 1].starts_with('-') {
        let arg = &args[*i + 1];
        return Err((format!("error: unexpected argument '{arg}' found\n\nUsage: {program} [OPTIONS]\n\nFor more information, try '--help'.\n"), 2));
    }
    take_value(args, i, display)
}

fn parse_number(s: &str, flag: &str, display: &str) -> Result<usize, (String, i32)> {
    match s.parse::<usize>() {
        Ok(n) => Ok(n),
        Err(e) => Err((format!("error: invalid value '{s}' for '--{flag} {display}': {e}\n\nFor more information, try '--help'.\n"), 2)),
    }
}

fn validate(cfg: &Config) -> Result<(), String> {
    range(cfg.top, "top", 1, 200)?;
    range(cfg.combi, "combi", 1, 200)?;
    range(cfg.rep, "rep", 1, 200)?;
    range(cfg.wpm, "wpm", 1, 200)?;
    range(cfg.acc, "acc", 0, 100)?;

    if cfg.emu_in.is_empty() != cfg.emu_out.is_empty() {
        return Err("You need to specify both emu_in and emu_out.".to_string());
    }

    if !matches!(cfg.n.as_str(), "2" | "3" | "4" | "w") && fs::read_to_string(&cfg.n).is_err() {
        return Err(format!("File not found: {}", cfg.n));
    }
    Ok(())
}

fn range(v: usize, name: &str, lo: usize, hi: usize) -> Result<(), String> {
    if v < lo || v > hi {
        Err(format!("Invalid argument for {name}. Use a number between {lo} and {hi}."))
    } else {
        Ok(())
    }
}

fn print_help(program: &str) {
    println!("Usage: {program} [OPTIONS]\n");
    println!("Options:");
    println!("  -n, --n <2|3|4|w|file>  use bi-(2), tri-(3), tetragrams(4), (w)ords or comma separated wordlist file. [default: 2]");
    println!("  -t, --top <1-200>       use the top X ngrams ordered by usage. [default: 50]");
    println!("  -c, --combi <1-200>     how many different ngrams to use in a single lesson. [default: 2]");
    println!("  -r, --rep <number>      how often to repeat *each* different ngram in a lesson. [default: 3]");
    println!("  -w, --wpm <number>      the wpm threshold at which the lesson is considered a success. [default: 40]");
    println!("  -a, --acc <0-100>       the accuracy in percent at which the lesson is considered a success. [default: 94]");
    println!("      --emu-in <layout>   your current keyboard layout. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    println!("      --emu-out <layout>  the layout you want to emulate. only needed if you want to emulate a different layout. see docs for supported layouts. [default: ]");
    println!("      --show-ortho        show keyboard in ortholinear format");
    println!("      --nokb              pass this flag to disable the keyboard layout display.");
    println!("      --cat               the most important flag. don't practice alone.");
    println!("  -h, --help              Print help");
}

fn run_session(cfg: Config) {
    let mut out = io::stdout();
    let lesson = build_lesson(&cfg);
    let mut input = String::new();
    let start = Instant::now();

    let _ = write!(out, "\x1b[?1049h\x1b[2J\x1b[H");
    draw(&mut out, &cfg, &lesson, "", Duration::ZERO);
    let _ = out.flush();

    let mut stdin = io::stdin();
    let mut buf = [0u8; 1];
    loop {
        match stdin.read(&mut buf) {
            Ok(0) => break,
            Ok(_) => {
                let b = buf[0];
                if b == 3 || b == b'q' && input.is_empty() {
                    break;
                }
                if b == 8 || b == 127 {
                    input.pop();
                } else if b == b'\r' || b == b'\n' {
                    if input.trim_end() == lesson {
                        break;
                    }
                } else if !b.is_ascii_control() {
                    input.push(b as char);
                }
                let elapsed = start.elapsed();
                let _ = write!(out, "\x1b[2J\x1b[H");
                draw(&mut out, &cfg, &lesson, &input, elapsed);
                let _ = out.flush();
                if input == lesson {
                    break;
                }
            }
            Err(_) => break,
        }
    }
    let _ = write!(out, "\x1b[?1049l");
    let _ = out.flush();
}

fn draw(out: &mut io::Stdout, cfg: &Config, lesson: &str, input: &str, elapsed: Duration) {
    let typed = input.chars().count();
    let total = lesson.chars().count().max(1);
    let correct = input.chars().zip(lesson.chars()).filter(|(a, b)| a == b).count();
    let acc = if typed == 0 { 100 } else { correct * 100 / typed };
    let mins = elapsed.as_secs_f64() / 60.0;
    let wpm = if mins > 0.0 { (typed as f64 / 5.0 / mins) as usize } else { 0 };

    let _ = writeln!(out, "ngrrram");
    let _ = writeln!(out);
    let _ = writeln!(out, "{lesson}");
    let _ = writeln!(out, "{input}");
    let _ = writeln!(out);
    let _ = writeln!(out, "wpm: {wpm}/{}, acc: {acc}/{}, progress: {typed}/{total}", cfg.wpm, cfg.acc);
    if !cfg.emu_in.is_empty() {
        let _ = writeln!(out, "emulating {} -> {}", cfg.emu_in, cfg.emu_out);
    }
    if cfg.cat {
        let _ = writeln!(out, " /\\_/\\\\");
        let _ = writeln!(out, "( o.o )");
        let _ = writeln!(out, " > ^ <");
    }
    if !cfg.nokb {
        let _ = writeln!(out);
        if cfg.show_ortho {
            let _ = writeln!(out, "q w e r t y u i o p");
            let _ = writeln!(out, "a s d f g h j k l ;");
            let _ = writeln!(out, "z x c v b n m , . /");
        } else {
            let _ = writeln!(out, "q w e r t y u i o p");
            let _ = writeln!(out, " a s d f g h j k l ;");
            let _ = writeln!(out, "  z x c v b n m , . /");
        }
    }
}

fn build_lesson(cfg: &Config) -> String {
    let base: Vec<String> = match cfg.n.as_str() {
        "2" => BIGRAMS.iter().map(|s| s.to_string()).collect(),
        "3" => TRIGRAMS.iter().map(|s| s.to_string()).collect(),
        "4" => TETRAGRAMS.iter().map(|s| s.to_string()).collect(),
        "w" => WORDS.iter().map(|s| s.to_string()).collect(),
        path => fs::read_to_string(path)
            .unwrap_or_default()
            .split(|c| c == ',' || c == '\n' || c == '\r')
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .map(ToOwned::to_owned)
            .collect(),
    };
    let choices = base.into_iter().take(cfg.top).take(cfg.combi).collect::<Vec<_>>();
    let choices = if choices.is_empty() { vec!["th".to_string()] } else { choices };
    let mut parts = Vec::new();
    for _ in 0..cfg.rep {
        for item in &choices {
            parts.push(item.clone());
        }
    }
    emulate(parts.join(" "), &cfg.emu_in, &cfg.emu_out)
}

fn emulate(s: String, input: &str, output: &str) -> String {
    if input.is_empty() || output.is_empty() || input == output {
        return s;
    }
    let from = layout(input);
    let to = layout(output);
    match (from, to) {
        (Some(f), Some(t)) => s.chars().map(|c| {
            f.find(c)
                .and_then(|idx| t.chars().nth(idx))
                .unwrap_or(c)
        }).collect(),
        _ => s,
    }
}

fn layout(name: &str) -> Option<&'static str> {
    match name {
        "qwerty" => Some("qwertyuiopasdfghjkl;zxcvbnm,./"),
        "qwertz" => Some("qwertzuiopasdfghjkl;yxcvbnm,.-"),
        "azerty" => Some("azertyuiopqsdfghjklmwxcvbn,;:"),
        "dvorak" => Some("',.pyfgcrlaoeuidhtns;qjkxbmwvz"),
        "colemak" => Some("qwfpgjluy;arstdhneiozxcvbkm,./"),
        "colemakdh" => Some("qwfpbjluy;arstgmneiozxcdvkh,./"),
        _ => None,
    }
}

const BIGRAMS: &[&str] = &[
    "th", "he", "in", "er", "an", "re", "on", "at", "en", "nd", "ti", "es", "or", "te", "of",
    "ed", "is", "it", "al", "ar", "st", "to", "nt", "ng", "se", "ha", "as", "ou", "io", "le",
    "ve", "co", "me", "de", "hi", "ri", "ro", "ic", "ne", "ea", "ra", "ce", "li", "ch", "ll",
    "be", "ma", "si", "om", "ur", "ca", "el", "ta", "la", "ns", "di", "fo", "ho", "pe", "ec",
];

const TRIGRAMS: &[&str] = &[
    "the", "and", "ing", "ion", "ent", "her", "tha", "nth", "int", "ere", "tio", "ter", "est",
    "ers", "ati", "hat", "ate", "all", "eth", "hes", "ver", "his", "oft", "ith", "fth", "sth",
    "oth", "res", "ont", "rea", "are", "ear", "was", "con", "not", "you", "but", "had", "for",
];

const TETRAGRAMS: &[&str] = &[
    "tion", "ther", "with", "that", "here", "ould", "ight", "have", "hich", "whic", "this",
    "thin", "they", "atio", "ever", "from", "ough", "were", "hing", "ment", "ions", "ande",
];

const WORDS: &[&str] = &[
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on",
    "with", "he", "as", "you", "do", "at", "this", "but", "his", "by", "from", "they", "we",
    "say", "her", "she", "or", "an", "will", "my", "one", "all", "would", "there", "their",
];
