fn main() {
    println!("cargo:rustc-link-arg=/usr/lib/x86_64-linux-gnu/libsqlite3.so.0");
}
