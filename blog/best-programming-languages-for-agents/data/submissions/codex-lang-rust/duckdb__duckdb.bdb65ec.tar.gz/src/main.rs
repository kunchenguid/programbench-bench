use std::env;
use std::fs;
use std::io::{self, Read};

#[derive(Clone, Copy, PartialEq, Eq)]
enum Mode { DuckBox, Ascii, Box, Table, Column, Csv, Json, JsonLines, Line, List, Markdown, Quote, Html }

struct Config {
    mode: Mode,
    headers: bool,
    null_value: String,
    col_sep: String,
    row_sep: String,
    bail: bool,
    echo: bool,
    no_stdin: bool,
    db: String,
    commands: Vec<String>,
}

#[derive(Debug, Clone)]
enum Val { Null, Int(i64), Float(f64), Text(String) }

#[derive(Debug)]
struct ResultSet { columns: Vec<String>, types: Vec<String>, rows: Vec<Vec<Val>> }

fn main() {
    let mut cfg = Config { mode: Mode::DuckBox, headers: true, null_value: "NULL".to_string(), col_sep: "|".to_string(), row_sep: "\n".to_string(), bail: false, echo: false, no_stdin: false, db: ":memory:".to_string(), commands: Vec::new() };
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() && atty_stdin() {
        print_intro();
    }
    let mut i = 0usize;
    let mut positional: Vec<String> = Vec::new();
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-h" | "-help" | "--help" => { print_help(); return; }
            "-version" | "--version" => { println!("v0.0.1 (Unknown Version) 780a7396"); return; }
            "-ascii" => cfg.mode = Mode::Ascii,
            "-box" => cfg.mode = Mode::Box,
            "-table" => cfg.mode = Mode::Table,
            "-column" => cfg.mode = Mode::Column,
            "-csv" => { cfg.mode = Mode::Csv; cfg.col_sep = ",".to_string(); },
            "-json" => cfg.mode = Mode::Json,
            "-jsonlines" => cfg.mode = Mode::JsonLines,
            "-line" => cfg.mode = Mode::Line,
            "-list" => cfg.mode = Mode::List,
            "-markdown" => cfg.mode = Mode::Markdown,
            "-quote" => cfg.mode = Mode::Quote,
            "-html" => cfg.mode = Mode::Html,
            "-header" => cfg.headers = true,
            "-noheader" => cfg.headers = false,
            "-bail" => cfg.bail = true,
            "-echo" => cfg.echo = true,
            "-batch" | "-interactive" | "-readonly" | "-safe" | "-unsigned" | "-unredacted" | "-no-init" | "-ui" => {},
            "-no-stdin" => cfg.no_stdin = true,
            "-separator" => { i += 1; if i < args.len() { cfg.col_sep = unescape_sep(&args[i]); } },
            "-newline" => { i += 1; if i < args.len() { cfg.row_sep = unescape_sep(&args[i]); } },
            "-nullvalue" => { i += 1; if i < args.len() { cfg.null_value = args[i].clone(); } },
            "-cmd" => { i += 1; if i < args.len() { cfg.commands.push(args[i].clone()); } },
            "-c" | "-s" => { i += 1; if i < args.len() { cfg.commands.push(args[i].clone()); cfg.no_stdin = true; } },
            "-f" | "-init" | "-format-file" => { i += 1; if i < args.len() { match fs::read_to_string(&args[i]) { Ok(s) => cfg.commands.push(s), Err(e) => { eprintln!("Error: unable to open \"{}\": {}", args[i], e); std::process::exit(1); } } } },
            "-format" => { let mut s = String::new(); let _ = io::stdin().read_to_string(&mut s); print!("{}", s); return; }
            "-storage-version" => { i += 1; },
            _ if a.starts_with('-') => {},
            _ => positional.push(a.clone()),
        }
        i += 1;
    }
    if !positional.is_empty() { cfg.db = positional[0].clone(); }
    if positional.len() > 1 { cfg.commands.push(positional[1..].join(" ")); cfg.no_stdin = true; }
    if cfg.commands.is_empty() && !cfg.no_stdin {
        let mut s = String::new(); let _ = io::stdin().read_to_string(&mut s); if !s.trim().is_empty() { cfg.commands.push(s); }
    }
    let mut status = 0;
    for cmd in cfg.commands.clone() {
        if cfg.echo { println!("{}", cmd); }
        if let Err(code) = run_input(&mut cfg, &cmd) { status = code; if cfg.bail { break; } }
    }
    std::process::exit(status);
}

fn atty_stdin() -> bool { false }

fn print_intro() { println!("DuckDB v0.0.1 (Unknown Version) 780a7396"); }

fn print_help() {
    println!("\x1b[1mUsage: \x1b[00m\x1b[32m./executable\x1b[00m\x1b[33m [OPTIONS] FILENAME [SQL]\n");
    println!("\x1b[00m\x1b[1mFILENAME\x1b[00m is the name of a DuckDB database. A new database is created");
    println!("if the file does not previously exist.\n");
    println!("\x1b[1mOPTIONS:\x1b[00m");
    let opts = [
        ("-ascii", "set output mode to 'ascii'"), ("-bail", "stop after hitting an error"), ("-batch", "force batch I/O'"),
        ("-box", "set output mode to 'box'"), ("-column", "set output mode to 'column'"), ("-cmd COMMAND", "run \"COMMAND\" before reading stdin"),
        ("-csv", "set output mode to 'csv'"), ("-c COMMAND", "run \"COMMAND\" and exit"), ("-echo", "print commands before execution"),
        ("-f FILENAME", "read/process named file and exit"), ("-format", "format SQL from stdin, writing result to stdout"), ("-format-file FILENAME", "format SQL in file, writing result to stdout"),
        ("-init FILENAME", "read/process named file"), ("-header", "turn headers on"), ("-h", "show help message"), ("-help", "show help message"),
        ("-html", "set output mode to HTML"), ("-interactive", "force interactive I/O"), ("-json", "set output mode to 'json'"), ("-jsonlines", "set output mode to 'jsonlines'"),
        ("-line", "set output mode to 'line'"), ("-list", "set output mode to 'list'"), ("-markdown", "set output mode to 'markdown'"),
        ("-newline SEP", "set output row separator. Default: '\\n'"), ("-no-init", "skip processing the init file"), ("-no-stdin", "exit after processing options instead of reading stdin"),
        ("-noheader", "turn headers off"), ("-nullvalue TEXT", "set text string for NULL values. Default 'NULL'"), ("-quote", "set output mode to 'quote'"),
        ("-readonly", "open the database read-only"), ("-s COMMAND", "run \"COMMAND\" and exit"), ("-safe", "enable safe-mode"),
        ("-separator SEP", "set output column separator. Default: '|'"), ("-storage-version VER", "database storage compatibility version to use. Default: 'v0.10.0'"),
        ("-table", "set output mode to 'table'"), ("-ui", "launches a web interface using the ui extension (configurable with .ui_command)"),
        ("-unredacted", "allow printing unredacted secrets"), ("-unsigned", "allow loading of unsigned extensions"), ("-version", "show DuckDB version"),
    ];
    for (o, d) in opts { println!("\x1b[32m  {:<24}\x1b[00m {}", o, d); }
}

fn run_input(cfg: &mut Config, input: &str) -> Result<(), i32> {
    let mut sql = String::new();
    for line in input.lines() {
        let t = line.trim();
        if t.starts_with('.') && sql.trim().is_empty() {
            if let Err(c) = meta(cfg, t) { return Err(c); }
        } else { sql.push_str(line); sql.push('\n'); }
    }
    if sql.trim().is_empty() { return Ok(()); }
    match execute_sql(cfg, &sql) {
        Ok(results) => { for rs in results { render(cfg, &rs); } Ok(()) }
        Err(e) => { eprintln!("Error: {}", e); Err(1) }
    }
}

fn meta(cfg: &mut Config, line: &str) -> Result<(), i32> {
    let mut parts = line.split_whitespace();
    let cmd = parts.next().unwrap_or("");
    match cmd {
        ".help" => { print_meta_help(); Ok(()) }
        ".version" => { println!("v0.0.1 (Unknown Version) 780a7396"); Ok(()) }
        ".quit" | ".exit" => std::process::exit(parts.next().and_then(|x| x.parse().ok()).unwrap_or(0)),
        ".headers" | ".header" => { if let Some(v) = parts.next() { cfg.headers = matches_on(v); } Ok(()) }
        ".mode" => { if let Some(v) = parts.next() { set_mode(cfg, v); } Ok(()) }
        ".separator" => { if let Some(v) = parts.next() { cfg.col_sep = unescape_sep(v); } if let Some(v) = parts.next() { cfg.row_sep = unescape_sep(v); } Ok(()) }
        ".nullvalue" => { cfg.null_value = parts.collect::<Vec<_>>().join(" "); Ok(()) }
        ".print" => { println!("{}", parts.collect::<Vec<_>>().join(" ")); Ok(()) }
        ".read" => { if let Some(f) = parts.next() { match fs::read_to_string(f) { Ok(s) => run_input(cfg, &s), Err(e) => { eprintln!("Error: cannot open \"{}\": {}", f, e); Err(1) } } } else { Ok(()) } }
        ".tables" => match execute_sql(cfg, "select name from sqlite_master where type='table' order by name") { Ok(r) => { for rs in r { for row in rs.rows { if let Some(v) = row.get(0) { print!("{}", display_val(v, cfg, false)); } } println!(); } Ok(()) }, Err(e) => { eprintln!("Error: {}", e); Err(1) } }
        ".show" => { println!("        echo: off\n     headers: {}\n        mode: {}\n   nullvalue: \"{}\"\n   separator: \"{}\"", if cfg.headers {"on"} else {"off"}, mode_name(cfg.mode), cfg.null_value, cfg.col_sep); Ok(()) }
        _ => { eprintln!("Error: unknown command or invalid arguments:  \"{}\". Enter \".help\" for help", line); Err(1) }
    }
}

fn print_meta_help() {
    let lines = [
        ".about                                  Show information about DuckDB", ".bail on|off                             Stop after hitting an error.  Default OFF",
        ".echo on|off                             Turn command echo on or off", ".exit ?CODE?                             Exit this program with return-code CODE",
        ".headers on|off                          Turn display of headers on or off", ".help ?-all? ?PATTERN?                   Show help text for PATTERN",
        ".mode MODE ?TABLE?                       Set output mode", ".nullvalue STRING                        Use STRING in place of NULL values",
        ".print STRING...                         Print literal STRING", ".quit                                   Exit this program",
        ".read FILE                               Read input from FILE", ".separator COL ?ROW?                     Change the column and row separators",
        ".show                                   Show the current values for various settings", ".tables ?TABLE?                          List names of tables matching LIKE pattern TABLE",
        ".version                                Show the version",
    ];
    for l in lines { println!("\x1b[32m{}\x1b[00m", l); }
}

fn matches_on(v: &str) -> bool { matches!(v.to_ascii_lowercase().as_str(), "on" | "yes" | "true" | "1") }
fn set_mode(cfg: &mut Config, v: &str) { cfg.mode = match v.to_ascii_lowercase().as_str() { "ascii" => Mode::Ascii, "box" | "duckbox" => Mode::Box, "table" => Mode::Table, "column" => Mode::Column, "csv" => { cfg.col_sep=",".into(); Mode::Csv }, "json" => Mode::Json, "jsonlines" | "jsonl" => Mode::JsonLines, "line" => Mode::Line, "list" => Mode::List, "markdown" => Mode::Markdown, "quote" => Mode::Quote, "html" => Mode::Html, _ => cfg.mode }; }
fn mode_name(m: Mode) -> &'static str { match m { Mode::DuckBox => "duckbox", Mode::Ascii => "ascii", Mode::Box => "box", Mode::Table => "table", Mode::Column => "column", Mode::Csv => "csv", Mode::Json => "json", Mode::JsonLines => "jsonlines", Mode::Line => "line", Mode::List => "list", Mode::Markdown => "markdown", Mode::Quote => "quote", Mode::Html => "html" } }
fn unescape_sep(s: &str) -> String { s.replace("\\n", "\n").replace("\\t", "\t") }


#[allow(non_camel_case_types)]
type sqlite3 = std::ffi::c_void;
#[allow(non_camel_case_types)]
type sqlite3_stmt = std::ffi::c_void;

extern "C" {
    fn sqlite3_open(filename: *const std::os::raw::c_char, ppDb: *mut *mut sqlite3) -> std::os::raw::c_int;
    fn sqlite3_close(db: *mut sqlite3) -> std::os::raw::c_int;
    fn sqlite3_prepare_v2(db: *mut sqlite3, zSql: *const std::os::raw::c_char, nByte: std::os::raw::c_int, ppStmt: *mut *mut sqlite3_stmt, pzTail: *mut *const std::os::raw::c_char) -> std::os::raw::c_int;
    fn sqlite3_step(stmt: *mut sqlite3_stmt) -> std::os::raw::c_int;
    fn sqlite3_finalize(stmt: *mut sqlite3_stmt) -> std::os::raw::c_int;
    fn sqlite3_errmsg(db: *mut sqlite3) -> *const std::os::raw::c_char;
    fn sqlite3_column_count(stmt: *mut sqlite3_stmt) -> std::os::raw::c_int;
    fn sqlite3_column_name(stmt: *mut sqlite3_stmt, N: std::os::raw::c_int) -> *const std::os::raw::c_char;
    fn sqlite3_column_type(stmt: *mut sqlite3_stmt, iCol: std::os::raw::c_int) -> std::os::raw::c_int;
    fn sqlite3_column_int64(stmt: *mut sqlite3_stmt, iCol: std::os::raw::c_int) -> i64;
    fn sqlite3_column_double(stmt: *mut sqlite3_stmt, iCol: std::os::raw::c_int) -> f64;
    fn sqlite3_column_text(stmt: *mut sqlite3_stmt, iCol: std::os::raw::c_int) -> *const std::os::raw::c_uchar;
}
const SQLITE_ROW: i32 = 100;
const SQLITE_DONE: i32 = 101;
const SQLITE_INTEGER: i32 = 1;
const SQLITE_FLOAT: i32 = 2;
const SQLITE_TEXT: i32 = 3;
const SQLITE_NULL: i32 = 5;

fn execute_sql(cfg: &Config, sql: &str) -> Result<Vec<ResultSet>, String> {
    if let Some(rs) = try_csv_select(sql) { return Ok(vec![rs]); }
    unsafe {
        let path = std::ffi::CString::new(if cfg.db.is_empty() { ":memory:" } else { &cfg.db }).map_err(|e| e.to_string())?;
        let mut db: *mut sqlite3 = std::ptr::null_mut();
        if sqlite3_open(path.as_ptr(), &mut db) != 0 { return Err("unable to open database".into()); }
        let result = execute_sqlite(db, sql);
        sqlite3_close(db);
        result
    }
}

unsafe fn execute_sqlite(db: *mut sqlite3, sql: &str) -> Result<Vec<ResultSet>, String> {
    let csql = std::ffi::CString::new(sql).map_err(|e| e.to_string())?;
    let mut tail = csql.as_ptr();
    let end = csql.as_ptr().add(csql.as_bytes().len());
    let mut out = Vec::new();
    while tail < end {
        while tail < end && (*tail as u8).is_ascii_whitespace() { tail = tail.add(1); }
        if tail >= end { break; }
        let mut stmt: *mut sqlite3_stmt = std::ptr::null_mut();
        let rc = sqlite3_prepare_v2(db, tail, -1, &mut stmt, &mut tail);
        if rc != 0 { return Err(sqlite_err(db)); }
        if stmt.is_null() { continue; }
        let cols = sqlite3_column_count(stmt) as usize;
        let mut names = Vec::new();
        for i in 0..cols {
            let p = sqlite3_column_name(stmt, i as i32);
            names.push(if p.is_null() { format!("column{}", i+1) } else { std::ffi::CStr::from_ptr(p).to_string_lossy().into_owned() });
        }
        let mut rows: Vec<Vec<Val>> = Vec::new();
        loop {
            let step = sqlite3_step(stmt);
            if step == SQLITE_ROW {
                let mut row = Vec::new();
                for i in 0..cols { row.push(sqlite_value(stmt, i as i32)); }
                rows.push(row);
            } else if step == SQLITE_DONE { break; }
            else { let e = sqlite_err(db); sqlite3_finalize(stmt); return Err(e); }
        }
        if cols > 0 {
            let mut types = vec!["varchar".to_string(); cols];
            for i in 0..cols {
                for r in &rows {
                    match r.get(i) {
                        Some(Val::Int(v)) => { types[i] = if *v >= -2147483648 && *v <= 2147483647 { "int32" } else { "int64" }.into(); break; }
                        Some(Val::Float(_)) => { types[i] = "double".into(); break; }
                        Some(Val::Text(_)) => { types[i] = "varchar".into(); break; }
                        _ => {}
                    }
                }
            }
            out.push(ResultSet { columns: names, types, rows });
        }
        sqlite3_finalize(stmt);
    }
    Ok(out)
}

unsafe fn sqlite_value(stmt: *mut sqlite3_stmt, col: i32) -> Val {
    match sqlite3_column_type(stmt, col) {
        SQLITE_INTEGER => Val::Int(sqlite3_column_int64(stmt, col)),
        SQLITE_FLOAT => Val::Float(sqlite3_column_double(stmt, col)),
        SQLITE_TEXT => {
            let p = sqlite3_column_text(stmt, col);
            if p.is_null() { Val::Null } else { Val::Text(std::ffi::CStr::from_ptr(p as *const std::os::raw::c_char).to_string_lossy().into_owned()) }
        }
        SQLITE_NULL => Val::Null,
        _ => Val::Text(String::new()),
    }
}
unsafe fn sqlite_err(db: *mut sqlite3) -> String { let p = sqlite3_errmsg(db); if p.is_null() { "SQL error".into() } else { std::ffi::CStr::from_ptr(p).to_string_lossy().into_owned() } }

fn try_csv_select(sql: &str) -> Option<ResultSet> {
    let low = sql.trim().to_ascii_lowercase();
    if !(low.starts_with("select * from '") || low.starts_with("select * from \"")) { return None; }
    let quote = sql.trim().chars().nth("select * from ".len())?;
    let rest = &sql.trim()["select * from ".len()+1..];
    let end = rest.find(quote)?; let path = &rest[..end];
    let content = fs::read_to_string(path).ok()?;
    let mut lines = content.lines(); let header = lines.next()?; let columns = split_csv_line(header);
    let mut rows=Vec::new(); for l in lines { rows.push(split_csv_line(l).into_iter().map(Val::Text).collect()); }
    let types=vec!["varchar".to_string(); columns.len()]; Some(ResultSet{columns,types,rows})
}
fn split_csv_line(l:&str)->Vec<String>{ let mut out=Vec::new(); let mut cur=String::new(); let mut q=false; let mut chars=l.chars().peekable(); while let Some(ch)=chars.next(){ if q { if ch=='"' { if chars.peek()==Some(&'"') { cur.push('"'); chars.next(); } else { q=false; } } else { cur.push(ch); } } else if ch=='"' { q=true; } else if ch==',' { out.push(cur.clone()); cur.clear(); } else { cur.push(ch); } } out.push(cur); out }

fn render(cfg: &Config, rs: &ResultSet) { match cfg.mode { Mode::Csv => render_sep(cfg, rs, ",", true, false), Mode::List => render_sep(cfg, rs, &cfg.col_sep, false, false), Mode::Quote => render_sep(cfg, rs, &cfg.col_sep, false, true), Mode::Json => render_json(rs, false), Mode::JsonLines => render_json(rs, true), Mode::Line => render_line(cfg, rs), Mode::Column => render_column(cfg, rs), Mode::Markdown => render_markdown(cfg, rs), Mode::Html => render_html(cfg, rs), Mode::Ascii | Mode::Table => render_ascii_box(cfg, rs), Mode::Box | Mode::DuckBox => render_duckbox(cfg, rs) } }
fn display_val(v:&Val,cfg:&Config,quote:bool)->String{ match v { Val::Null=>cfg.null_value.clone(), Val::Int(i)=>i.to_string(), Val::Float(f)=>{let mut s=f.to_string(); if s.ends_with(".0"){s.truncate(s.len()-2)} s}, Val::Text(s)=> if quote { format!("'{}'", s.replace('\'', "''")) } else { s.clone() } } }
fn render_sep(cfg:&Config,rs:&ResultSet,sep:&str,csv:bool,quote:bool){ if cfg.headers { let h:Vec<String>=rs.columns.iter().map(|x| if csv {csv_field(x)} else if quote {format!("'{}'",x)} else {x.clone()}).collect(); print!("{}{}",h.join(sep),cfg.row_sep); } for r in &rs.rows { let fields:Vec<String>=r.iter().map(|v| { let s=display_val(v,cfg,quote); if csv { csv_field(&s) } else { s } }).collect(); print!("{}{}",fields.join(sep),cfg.row_sep); } }
fn csv_field(s:&str)->String{ if s.contains(',')||s.contains('"')||s.contains('\n'){format!("\"{}\"",s.replace('"',"\"\""))}else{s.to_string()} }
fn render_json(rs:&ResultSet, lines:bool){ let mut objs=Vec::new(); for r in &rs.rows { let mut parts=Vec::new(); for (i,v) in r.iter().enumerate(){ parts.push(format!("\"{}\":{}", json_escape(&rs.columns[i]), json_val(v))); } let obj=format!("{{{}}}",parts.join(",")); if lines { println!("{}",obj); } else { objs.push(obj); } } if !lines { println!("[{}]",objs.join(",")); } }
fn json_escape(s:&str)->String{s.replace('\\',"\\\\").replace('"',"\\\"").replace('\n',"\\n")}
fn json_val(v:&Val)->String{match v{Val::Null=>"null".into(),Val::Int(i)=>i.to_string(),Val::Float(f)=>f.to_string(),Val::Text(s)=>format!("\"{}\"",json_escape(s))}}
fn render_line(cfg:&Config,rs:&ResultSet){ for r in &rs.rows { for (i,v) in r.iter().enumerate(){ println!("{:>5} = {}",rs.columns[i],display_val(v,cfg,false)); } } }
fn render_column(cfg:&Config,rs:&ResultSet){ let mut widths:Vec<usize>=rs.columns.iter().map(|c|c.len()).collect(); for r in &rs.rows{for(i,v)in r.iter().enumerate(){widths[i]=widths[i].max(display_val(v,cfg,false).len());}} if cfg.headers { println!("{}",rs.columns.iter().enumerate().map(|(i,c)|format!("{:<w$}",c,w=widths[i])).collect::<Vec<_>>().join("  ")); println!("{}",widths.iter().map(|w|"-".repeat(*w)).collect::<Vec<_>>().join("  ")); } for r in &rs.rows{println!("{}",r.iter().enumerate().map(|(i,v)|format!("{:<w$}",display_val(v,cfg,false),w=widths[i])).collect::<Vec<_>>().join("  "));}}
fn render_markdown(cfg:&Config,rs:&ResultSet){ if cfg.headers { println!("| {} |",rs.columns.join(" | ")); println!("|{}|",rs.columns.iter().enumerate().map(|(i,_)| if rs.types.get(i).map(|t|t.starts_with("int")||t=="double").unwrap_or(false){"--:"}else{"---"}).collect::<Vec<_>>().join("|")); } for r in &rs.rows{println!("| {} |",r.iter().map(|v|display_val(v,cfg,false)).collect::<Vec<_>>().join(" | "));}}
fn render_html(cfg:&Config,rs:&ResultSet){ if cfg.headers { print!("<tr>"); for c in &rs.columns{println!("<th>{}</th>",html(c));} println!("</tr>"); } for r in &rs.rows{print!("<tr>"); for v in r{println!("<td>{}</td>",html(&display_val(v,cfg,false)));} println!("</tr>");} }
fn html(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;")}
fn render_ascii_box(cfg:&Config,rs:&ResultSet){ render_box_generic(cfg,rs,false); }
fn render_duckbox(cfg:&Config,rs:&ResultSet){ render_box_generic(cfg,rs,true); }
fn render_box_generic(cfg:&Config,rs:&ResultSet,unicode:bool){ let mut data=Vec::new(); if cfg.headers { data.push(rs.columns.clone()); data.push(rs.types.clone()); } for r in &rs.rows{data.push(r.iter().map(|v|display_val(v,cfg,false)).collect());} let n=rs.columns.len(); if n==0{return;} let mut w=vec![0;n]; for row in &data{for i in 0..n{w[i]=w[i].max(row.get(i).map(|s|s.len()).unwrap_or(0));}} let (tl,tr,bl,br,h,v,tm,bm,ml,mr,mm)= if unicode{('┌','┐','└','┘','─','│','┬','┴','├','┤','┼')}else{('+','+','+','+','-','|','+','+','+','+','+')}; print_border(&w,tl,tm,tr,h); if cfg.headers { print_row_aligned(&data[0],&w,v,0,rs); print_row_aligned(&data[1],&w,v,1,rs); print_border(&w,ml,mm,mr,h); for (ri,row) in data.iter().skip(2).enumerate(){ print_row_aligned(row,&w,v,ri+2,rs); } } else { for (ri,row) in data.iter().enumerate(){ print_row_aligned(row,&w,v,ri+2,rs);} } print_border(&w,bl,bm,br,h); }
fn print_border(w:&[usize],l:char,m:char,r:char,h:char){ print!("{}",l); for(i,x)in w.iter().enumerate(){ print!("{}",h.to_string().repeat(*x+2)); print!("{}", if i+1==w.len(){r}else{m}); } println!(); }
fn print_row_aligned(row:&[String],w:&[usize],v:char,row_kind:usize,rs:&ResultSet){ print!("{}",v); for(i,x)in w.iter().enumerate(){ let s=row.get(i).cloned().unwrap_or_default(); let cell = if row_kind==0 { center(&s,*x) } else if row_kind==1 { format!("{:<width$}",s,width=*x) } else if rs.types.get(i).map(|t|t.starts_with("int")||t=="double").unwrap_or(false) { format!("{:>width$}",s,width=*x) } else { format!("{:<width$}",s,width=*x) }; print!(" {} {}",cell,v); } println!(); }
fn center(s:&str,w:usize)->String{ if s.len()>=w{return s.to_string();} let pad=w-s.len(); let l=pad/2; let r=pad-l; format!("{}{}{}"," ".repeat(l),s," ".repeat(r)) }
