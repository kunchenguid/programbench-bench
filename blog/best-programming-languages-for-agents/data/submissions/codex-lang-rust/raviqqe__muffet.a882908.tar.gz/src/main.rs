use regex::Regex;
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet, VecDeque};
use std::env;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::time::Duration;
use url::Url;

const HELP: &str = "Usage:\n  executable [options] <url>\n\nApplication Options:\n      --accepted-status-codes=<codes>       Accepted HTTP response status codes\n                                            (e.g. '200..300,403') (default:\n                                            200..300)\n  -b, --buffer-size=<size>                  HTTP response buffer size in bytes\n                                            (default: 4096)\n  -c, --max-connections=<count>             Maximum number of HTTP connections\n                                            (default: 512)\n      --max-connections-per-host=<count>    Maximum number of HTTP connections\n                                            per host (default: 512)\n      --max-response-body-size=<size>       Maximum response body size to read\n                                            (default: 10000000)\n  -e, --exclude=<pattern>...                Exclude URLs matched with given\n                                            regular expressions\n  -i, --include=<pattern>...                Include URLs matched with given\n                                            regular expressions\n      --follow-robots-txt                   Follow robots.txt when scraping\n                                            pages\n      --follow-sitemap-xml                  Scrape only pages listed in\n                                            sitemap.xml (deprecated)\n      --header=<header>...                  Custom headers\n  -f, --ignore-fragments                    Ignore URL fragments\n      --max-retries=<count>                 Maximum retry count for network\n                                            errors (default: 0)\n      --dns-resolver=<address>              Custom DNS resolver\n      --format=[text|json|junit]            Output format (default: text)\n      --json                                Output results in JSON (deprecated)\n      --experimental-verbose-json           Include successful results in JSON\n                                            (deprecated)\n      --junit                               Output results as JUnit XML file\n                                            (deprecated)\n  -r, --max-redirections=<count>            Maximum number of redirections\n                                            (default: 64)\n      --rate-limit=<rate>                   Max requests per second\n  -t, --timeout=<seconds>                   Timeout for HTTP requests in\n                                            seconds (default: 10)\n  -v, --verbose                             Show successful results too\n      --proxy=<host>                        HTTP proxy host\n      --skip-tls-verification               Skip TLS certificate verification\n      --one-page-only                       Only check links found in the given\n                                            URL\n      --color=[auto|always|never]           Color output (default: auto)\n  -h, --help                                Show this help\n      --version                             Show version\n";

#[derive(Clone)]
struct Opt {
    url: String,
    accepted: Vec<(u16, u16)>,
    include: Vec<Regex>,
    exclude: Vec<Regex>,
    headers: Vec<String>,
    format: String,
    verbose: bool,
    ignore_fragments: bool,
    one_page_only: bool,
    max_redirs: usize,
    timeout: u64,
    max_body: usize,
    color: String,
}

#[derive(Clone, Debug)]
struct LinkResult { url: String, status: Option<u16>, error: Option<String> }
#[derive(Clone, Debug)]
struct PageResult { url: String, links: Vec<LinkResult> }
#[derive(Serialize)]
struct JsonLink { url: String, #[serde(skip_serializing_if="Option::is_none")] status: Option<u16>, #[serde(skip_serializing_if="Option::is_none")] error: Option<String> }
#[derive(Serialize)]
struct JsonPage { url: String, links: Vec<JsonLink> }

fn main() {
    let opt = match parse_args() { Ok(Some(o)) => o, Ok(None) => return, Err(e) => { eprintln!("{}", e); std::process::exit(1); } };
    let mut crawler = Crawler::new(opt.clone());
    let ok_root = crawler.crawl();
    if !ok_root { std::process::exit(1); }
    let any_err = crawler.results.iter().any(|p| p.links.iter().any(|l| l.error.is_some()));
    output(&opt, &crawler.results);
    if any_err { std::process::exit(1); }
}

fn parse_args() -> Result<Option<Opt>, String> {
    let mut o = Opt { url: String::new(), accepted: vec![(200,299)], include: vec![], exclude: vec![], headers: vec![], format: "text".into(), verbose: false, ignore_fragments: false, one_page_only: false, max_redirs: 64, timeout: 10, max_body: 10_000_000, color: "auto".into() };
    let mut urls = vec![];
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--help" || a == "-h" { print!("{}", HELP); return Ok(None); }
        if a == "--version" { println!("2.11.1"); return Ok(None); }
        if a == "-v" || a == "--verbose" { o.verbose = true; i+=1; continue; }
        if a == "-f" || a == "--ignore-fragments" { o.ignore_fragments = true; i+=1; continue; }
        if a == "--one-page-only" { o.one_page_only = true; i+=1; continue; }
        if a == "--json" { o.format = "json".into(); i+=1; continue; }
        if a == "--junit" { o.format = "junit".into(); i+=1; continue; }
        if a == "--experimental-verbose-json" { o.format = "json".into(); o.verbose = true; i+=1; continue; }
        if a == "--follow-robots-txt" || a == "--follow-sitemap-xml" || a == "--skip-tls-verification" { i+=1; continue; }
        let (key, val_inline) = if let Some((k,v)) = a.split_once('=') { (k, Some(v.to_string())) } else { (a.as_str(), None) };
        let needs_val = matches!(key, "--accepted-status-codes"|"-b"|"--buffer-size"|"-c"|"--max-connections"|"--max-connections-per-host"|"--max-response-body-size"|"-e"|"--exclude"|"-i"|"--include"|"--header"|"--max-retries"|"--dns-resolver"|"--format"|"-r"|"--max-redirections"|"--rate-limit"|"-t"|"--timeout"|"--proxy"|"--color");
        if needs_val {
            let v = if let Some(v)=val_inline { v } else { i+=1; if i>=args.len(){return Err(format!("expected argument for flag `{}`", key.trim_start_matches('-')))}; args[i].clone() };
            match key {
                "--accepted-status-codes" => o.accepted = parse_codes(&v)?,
                "-e"|"--exclude" => o.exclude.push(Regex::new(&v).map_err(|e| e.to_string())?),
                "-i"|"--include" => o.include.push(Regex::new(&v).map_err(|e| e.to_string())?),
                "--header" => o.headers.push(v),
                "--format" => o.format = v,
                "-r"|"--max-redirections" => o.max_redirs = v.parse().unwrap_or(64),
                "-t"|"--timeout" => o.timeout = v.parse().unwrap_or(10),
                "--max-response-body-size" => o.max_body = v.parse().unwrap_or(10_000_000),
                "--color" => o.color = v,
                _ => {}
            }
            i+=1; continue;
        }
        if a.starts_with('-') { return Err(format!("unknown flag `{}`", a.trim_start_matches('-'))); }
        urls.push(a.clone()); i+=1;
    }
    if urls.len()!=1 { return Err("invalid number of arguments".into()); }
    o.url = urls.remove(0);
    Ok(Some(o))
}

fn parse_codes(s: &str) -> Result<Vec<(u16,u16)>, String> {
    let mut v=vec![];
    for part in s.split(',') { if let Some((a,b))=part.split_once("..") { let start:u16=a.parse().map_err(|_|"invalid status code")?; let end:u16=b.parse().map_err(|_|"invalid status code")?; v.push((start,end-1)); } else { let c:u16=part.parse().map_err(|_|"invalid status code")?; v.push((c,c)); } }
    Ok(v)
}

struct Crawler { opt: Opt, root: Url, seen_pages: BTreeSet<String>, checked: BTreeMap<String, LinkResult>, results: Vec<PageResult> }
impl Crawler {
    fn new(opt: Opt) -> Self { let root = Url::parse(&opt.url).unwrap_or_else(|_| Url::parse("http://invalid/").unwrap()); Self{opt,root,seen_pages:BTreeSet::new(),checked:BTreeMap::new(),results:vec![]} }
    fn crawl(&mut self) -> bool {
        let root_s = self.norm(self.root.clone(), true);
        let root_fetch = self.fetch_url(&root_s, 0);
        let (body, ctype) = match root_fetch { Ok((_,h,b,u)) => { let c=content_type(&h); self.checked.insert(root_s.clone(), LinkResult{url:u,status:Some(200),error:None}); (b,c) }, Err(e) => { eprintln!("failed to fetch root page: {}", e); return false; } };
        let mut q=VecDeque::new(); q.push_back((root_s, body, ctype));
        while let Some((page_url, body, ctype))=q.pop_front() {
            if !self.seen_pages.insert(page_url.clone()) { continue; }
            if !ctype.contains("html") && !looks_html(&body) { continue; }
            let base=Url::parse(&page_url).unwrap();
            let mut links=vec![];
            for raw in extract_links(&body) {
                if raw.starts_with("mailto:") || raw.starts_with("tel:") || raw.starts_with("javascript:") || raw.starts_with('#') { continue; }
                let mut u = match base.join(&raw) { Ok(u)=>u, Err(_)=>continue };
                if self.opt.ignore_fragments { u.set_fragment(None); }
                let full = self.norm(u.clone(), false);
                if !self.should_check(&full) { continue; }
                let lr = self.check_link(&full, u.fragment());
                let recurse = self.same_origin(&full) && lr.error.is_none() && is_probably_page(&full) && !self.opt.one_page_only && u.fragment().is_none();
                links.push(lr.clone());
                if recurse && !self.seen_pages.contains(&full) {
                    if let Ok((_,h,b,final_url)) = self.fetch_url(&full, 0) { if content_type(&h).contains("html") || looks_html(&b) { q.push_back((final_url,b,content_type(&h))); } }
                }
            }
            self.results.push(PageResult{url:page_url,links});
        }
        true
    }
    fn should_check(&self, u:&str)->bool{ if !self.opt.include.is_empty() && !self.opt.include.iter().any(|r|r.is_match(u)){return false;} if self.opt.exclude.iter().any(|r|r.is_match(u)){return false;} true }
    fn same_origin(&self,u:&str)->bool{ Url::parse(u).ok().map(|x| x.scheme()==self.root.scheme()&&x.host_str()==self.root.host_str()&&x.port_or_known_default()==self.root.port_or_known_default()).unwrap_or(false) }
    fn norm(&self, mut u:Url, page:bool)->String{ if page && u.path().is_empty(){u.set_path("/");} u.to_string() }
    fn accepted(&self,c:u16)->bool{ self.opt.accepted.iter().any(|(a,b)| c>=*a&&c<=*b) }
    fn check_link(&mut self, full:&str, frag:Option<&str>)->LinkResult{
        if let Some(cached)=self.checked.get(full){ return cached.clone(); }
        let lr=match self.fetch_url(full,0){ Ok((code,_h,b,_final_url))=>{ let mut err=None; if !self.accepted(code){err=Some(code.to_string());} else if let Some(f)=frag { if !fragment_exists(&b,f){err=Some(format!("id #{} not found",f));} } LinkResult{url: full.into(), status:Some(code), error:err} }, Err(e)=>LinkResult{url:full.into(),status:None,error:Some(e)} };
        if lr.error.is_none() && lr.status.is_some() { /* keep */ }
        self.checked.insert(full.into(), lr.clone()); lr
    }
    fn fetch_url(&self, full:&str, redirs:usize)->Result<(u16,String,String,String),String>{
        if redirs>self.opt.max_redirs { return Err("too many redirections".into()); }
        let url=Url::parse(full).map_err(|e|e.to_string())?;
        if url.scheme()!="http" { return Err(format!("unsupported protocol scheme `{}`", url.scheme())); }
        let host=url.host_str().ok_or("missing host")?; let port=url.port_or_known_default().unwrap_or(80);
        let addr=format!("{}:{}",host,port);
        let mut s=TcpStream::connect(&addr).map_err(|e| format!("error when dialing {}: {}", addr, e))?;
        let _=s.set_read_timeout(Some(Duration::from_secs(self.opt.timeout))); let _=s.set_write_timeout(Some(Duration::from_secs(self.opt.timeout)));
        let mut path=url.path().to_string(); if path.is_empty(){path.push('/');} if let Some(q)=url.query(){path.push('?'); path.push_str(q);}
        let mut req=format!("GET {} HTTP/1.1\r\nHost: {}\r\nUser-Agent: muffet/2.11.1\r\nAccept: */*\r\nConnection: close\r\n",path,host);
        for h in &self.opt.headers { req.push_str(h); req.push_str("\r\n"); } req.push_str("\r\n");
        s.write_all(req.as_bytes()).map_err(|e|e.to_string())?;
        let mut bytes=Vec::new(); s.take((self.opt.max_body+65536) as u64).read_to_end(&mut bytes).map_err(|e|e.to_string())?;
        let text=String::from_utf8_lossy(&bytes).to_string(); let (head,body)=text.split_once("\r\n\r\n").unwrap_or((text.as_str(),""));
        let status=head.lines().next().and_then(|l|l.split_whitespace().nth(1)).and_then(|s|s.parse::<u16>().ok()).ok_or("invalid response")?;
        if (300..400).contains(&status) { if let Some(loc)=header_value(head,"location") { let next=url.join(&loc).map_err(|e|e.to_string())?.to_string(); return self.fetch_url(&next,redirs+1); } }
        Ok((status,head.to_string(),body.to_string(),full.to_string()))
    }
}
fn header_value(h:&str,name:&str)->Option<String>{ for l in h.lines(){ if let Some((k,v))=l.split_once(':'){ if k.eq_ignore_ascii_case(name){return Some(v.trim().to_string())}}} None }
fn content_type(h:&str)->String{header_value(h,"content-type").unwrap_or_default().to_lowercase()}
fn looks_html(b:&str)->bool{ let s=b.trim_start().to_lowercase(); s.starts_with("<") || s.contains("<a ") || s.contains("href=") }
fn is_probably_page(u:&str)->bool{ let p=Url::parse(u).ok().map(|x|x.path().to_lowercase()).unwrap_or_default(); !(p.ends_with(".png")||p.ends_with(".jpg")||p.ends_with(".jpeg")||p.ends_with(".gif")||p.ends_with(".css")||p.ends_with(".js")||p.ends_with(".svg")||p.ends_with(".ico")||p.ends_with(".pdf")) }
fn extract_links(b:&str)->Vec<String>{ let re=Regex::new(r#"(?is)\b(?:href|src|action)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))"#).unwrap(); re.captures_iter(b).filter_map(|c| c.get(1).or_else(||c.get(2)).or_else(||c.get(3)).map(|m|m.as_str().trim().to_string())).collect() }
fn fragment_exists(b:&str,f:&str)->bool{ let pat=format!(r#"(?is)\b(?:id|name)\s*=\s*(?:"{}"|'{}'|{})"#,regex::escape(f),regex::escape(f),regex::escape(f)); Regex::new(&pat).unwrap().is_match(b) }
fn output(opt:&Opt, pages:&[PageResult]){ match opt.format.as_str(){"json"=>out_json(opt,pages),"junit"=>out_junit(pages),_=>out_text(opt,pages)} }
fn out_text(opt:&Opt,pages:&[PageResult]){ let color=opt.color=="always"; for p in pages{ let show=opt.verbose || p.links.iter().any(|l|l.error.is_some()); if !show{continue;} if color{println!("\x1b[33m{}\x1b[0m",p.url)}else{println!("{}",p.url)} for l in &p.links{ if opt.verbose || l.error.is_some(){ if let Some(e)=&l.error{ if color{println!("\t\x1b[31m{}\x1b[0m\t{}",e,l.url)}else{println!("\t{}\t{}",e,l.url)} } else if let Some(s)=l.status{ println!("\t{}\t{}",s,l.url); } } } } }
fn out_json(opt:&Opt,pages:&[PageResult]){ let mut out=vec![]; for p in pages{ let links:Vec<_>=p.links.iter().filter(|l| opt.verbose||l.error.is_some()).map(|l|JsonLink{url:l.url.clone(),status: if opt.verbose&&l.error.is_none(){l.status}else{None},error:l.error.clone()}).collect(); if !links.is_empty(){out.push(JsonPage{url:p.url.clone(),links});} } println!("{}",serde_json::to_string(&out).unwrap()); }
fn esc(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;")}
fn out_junit(pages:&[PageResult]){ println!("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<testsuites>"); for p in pages{ let failures=p.links.iter().filter(|l|l.error.is_some()).count(); println!("  <testsuite name=\"{}\" tests=\"{}\" failures=\"{}\" skipped=\"0\">",esc(&p.url),p.links.len(),failures); for l in &p.links{ println!("    <testcase name=\"{}\" classname=\"{}\">{}",esc(&l.url),esc(&p.url),if l.error.is_some(){""}else{"</testcase>"}); if let Some(e)=&l.error{ println!("      <failure message=\"{}\"></failure>\n    </testcase>",esc(e)); } } println!("  </testsuite>"); } println!("</testsuites>"); }
