use serde_json::{json, Map, Value};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, HashMap};
use std::env;
use std::ffi::OsStr;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

const VERSION: &str = "2.37.1";

fn main() {
    let mut args: Vec<String> = env::args().collect();
    let self_path = args.get(0).cloned().unwrap_or_else(|| "direnv".into());
    if args.len() == 1 {
        print_help();
        return;
    }
    let cmd = args.remove(1);
    let rest = args.split_off(1);
    let code = match cmd.as_str() {
        "help" | "--help" | "-h" => { print_help(); 0 }
        "version" => cmd_version(&rest),
        "hook" => cmd_hook(&self_path, &rest),
        "stdlib" => { print_stdlib(&self_path); 0 }
        "allow" | "permit" | "grant" => cmd_allow(&rest, true),
        "block" | "deny" | "disallow" | "revoke" => cmd_allow(&rest, false),
        "export" => cmd_export(&rest),
        "exec" => cmd_exec(&rest),
        "status" => cmd_status(&self_path, &rest),
        "reload" => { remove_env_state(); 0 }
        "prune" => cmd_prune(),
        "log" => cmd_log(&rest),
        "fetchurl" => { err("fetchurl requires network access, which is unavailable in this build"); 1 }
        "edit" => cmd_edit(&rest),
        _ => { err(&format!("command \"{} {}\" not found", self_path, cmd)); 1 }
    };
    std::process::exit(code);
}

fn print_help() {
    println!("direnv v{}", VERSION);
    println!("Usage: direnv COMMAND [...ARGS]\n");
    println!("Available commands\n------------------");
    println!("allow [PATH_TO_RC]:\n  aliases: permit, grant\n  Grants direnv permission to load the given .envrc or .env file.");
    println!("block [PATH_TO_RC]:\n  aliases: deny, disallow, revoke\n  Revokes the authorization of a given .envrc or .env file.");
    println!("edit [PATH_TO_RC]:\n  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow\n  the file to be loaded afterwards.");
    println!("exec DIR COMMAND [...ARGS]:\n  Executes a command after loading the first .envrc or .env found in DIR");
    println!("export SHELL:\n  Loads an .envrc or .env and prints the diff in terms of exports.\n  Supported SHELL values are: [fish, json, tcsh, zsh, systemd, vim, pwsh, bash, elvish, gha, gzenv, murex]");
    println!("fetchurl <url> [<integrity-hash>]:\n  Fetches a given URL into direnv's CAS");
    println!("help [SHOW_PRIVATE]:\n  Shows this help");
    println!("hook SHELL:\n  Used to setup the shell hook");
    println!("prune:\n  Removes old allowed and required files");
    println!("reload:\n  Triggers an env reload");
    println!("status [--json]:\n  Prints some debug status information");
    println!("stdlib:\n  Displays the stdlib available in the .envrc execution context");
    println!("version [VERSION_AT_LEAST]:\n  prints the version or checks that direnv is older than VERSION_AT_LEAST.");
    println!("log [--status | --error] <message>:\n  Logs a given message");
}

fn cmd_version(args: &[String]) -> i32 {
    if args.is_empty() { println!("{}", VERSION); return 0; }
    if version_lt(VERSION, &args[0]) {
        err(&format!("current version v{} is older than the desired version v{}", VERSION, args[0]));
        1
    } else { 0 }
}

fn version_lt(a: &str, b: &str) -> bool {
    let pa: Vec<u64> = a.trim_start_matches('v').split('.').map(|s| s.parse().unwrap_or(0)).collect();
    let pb: Vec<u64> = b.trim_start_matches('v').split('.').map(|s| s.parse().unwrap_or(0)).collect();
    for i in 0..3 { let av=*pa.get(i).unwrap_or(&0); let bv=*pb.get(i).unwrap_or(&0); if av != bv { return av < bv; } }
    false
}

fn cmd_hook(self_path: &str, args: &[String]) -> i32 {
    let shell = args.get(0).map(String::as_str).unwrap_or("");
    match shell {
        "bash" => println!(r#"
_direnv_hook() {{
  local previous_exit_status=$?;
  vars="$("{}" export bash)";
  trap -- '' SIGINT;
  eval "$vars";
  trap - SIGINT;
  return $previous_exit_status;
}};
if [[ ";${{PROMPT_COMMAND[*]:-}};" != *";_direnv_hook;"* ]]; then
  if [[ "$(declare -p PROMPT_COMMAND 2>&1)" == "declare -a"* ]]; then
    PROMPT_COMMAND=(_direnv_hook "${{PROMPT_COMMAND[@]}}")
  else
    PROMPT_COMMAND="_direnv_hook${{PROMPT_COMMAND:+;$PROMPT_COMMAND}}"
  fi
fi"#, self_path),
        "zsh" => println!(r#"
_direnv_hook() {{
  vars="$({} export zsh)"
  trap -- '' SIGINT
  eval "$vars"
  trap - SIGINT
}}
typeset -ag precmd_functions
if (( ! ${{precmd_functions[(I)_direnv_hook]}} )); then
  precmd_functions=(_direnv_hook $precmd_functions)
fi
typeset -ag chpwd_functions
if (( ! ${{chpwd_functions[(I)_direnv_hook]}} )); then
  chpwd_functions=(_direnv_hook $chpwd_functions)
fi"#, shell_quote(self_path)),
        "fish" => println!(r#"
    function __direnv_export_eval --on-event fish_prompt;
        "{}" export fish | source;

        if test "$direnv_fish_mode" != "disable_arrow";
            function __direnv_cd_hook --on-variable PWD;
                if test "$direnv_fish_mode" = "eval_after_arrow";
                    set -g __direnv_export_again 0;
                else;
                    "{}" export fish | source;
                end;
            end;
        end;
    end;

    function __direnv_export_eval_2 --on-event fish_preexec;
        if set -q __direnv_export_again;
            set -e __direnv_export_again;
            "{}" export fish | source;
            echo;
        end;

        functions --erase __direnv_cd_hook;
    end;"#, self_path, self_path, self_path),
        "tcsh" => print!("alias precmd 'eval `{} export tcsh`'", self_path),
        "elvish" => println!("## hook for direnv\nset @edit:before-readline = $@edit:before-readline {{\n\ttry {{\n\t\tvar m = [({} export elvish | from-json)]\n\t\tif (> (count $m) 0) {{\n\t\t\tset m = (all $m)\n\t\t\tkeys $m | each {{ |k|\n\t\t\t\tif $m[$k] {{ set-env $k $m[$k] }} else {{ unset-env $k }}\n\t\t\t}}\n\t\t}}\n\t}} catch e {{ echo $e }}\n}}", shell_quote(self_path)),
        "pwsh" => println!("$hook = {{\n  $export = ({} export pwsh) -join [Environment]::NewLine;\n  if ($export) {{ Invoke-Expression -Command $export; }}\n}};\n$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = $hook;", self_path),
        "murex" => println!("event: onPrompt direnv_hook=before {{\n\t{} export murex -> set exports\n}}", shell_quote(self_path)),
        _ => { err(&format!("unknown target shell '{}'", shell)); return 1; }
    }
    0
}

fn cmd_allow(args: &[String], allow: bool) -> i32 {
    let rc = match resolve_rc(args.get(0).map(String::as_str)) { Ok(p) => p, Err(e) => { err(&e); return 1; } };
    if !rc.exists() { err(&format!("{} not found", rc.display())); return 1; }
    let id = rc_id(&rc);
    let dir = if allow { data_dir().join("allow") } else { data_dir().join("deny") };
    let other = if allow { data_dir().join("deny") } else { data_dir().join("allow") };
    let _ = fs::create_dir_all(&dir);
    let _ = fs::create_dir_all(&other);
    let _ = fs::write(dir.join(&id), rc.to_string_lossy().as_bytes());
    let _ = fs::remove_file(other.join(&id));
    0
}

fn cmd_export(args: &[String]) -> i32 {
    let shell = args.get(0).map(String::as_str).unwrap_or("");
    if shell.is_empty() { err("missing target shell"); return 1; }
    if !matches!(shell, "json" | "elvish" | "murex" | "bash" | "zsh" | "fish" | "tcsh" | "pwsh" | "gha" | "vim" | "systemd" | "gzenv") {
        err(&format!("unknown target shell '{}'", shell));
        return 1;
    }
    let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let rc = find_rc(&cwd);
    let mut changes = BTreeMap::new();
    if let Some(rc) = rc {
        changes.insert("DIRENV_FILE".into(), Some(rc.to_string_lossy().to_string()));
        changes.insert("DIRENV_DIR".into(), Some(format!("-{}", rc.parent().unwrap_or(&cwd).display())));
        changes.insert("DIRENV_DIFF".into(), Some("direnv-clone".into()));
        changes.insert("DIRENV_WATCHES".into(), Some("direnv-clone".into()));
        if is_allowed(&rc) {
            eprintln!("\x1b[0mdirenv: loading {}", rc.display());
            match eval_rc(&rc) {
                Ok(envs) => {
                    let before: HashMap<String,String> = env::vars().collect();
                    for (k,v) in envs { if before.get(&k) != Some(&v) && !ignored_key(&k) { changes.insert(k, Some(v)); } }
                    let diff = diff_summary(&before, &changes);
                    if !diff.is_empty() { eprintln!("\x1b[0mdirenv: export {}", diff); }
                }
                Err(e) => { err(&e); return 1; }
            }
        } else {
            render(shell, &changes);
            err(&format!("{} is blocked. Run `direnv allow` to approve its content", rc.display()));
            return 1;
        }
    } else if env::var("DIRENV_DIR").is_ok() {
        changes.insert("DIRENV_DIR".into(), None);
        changes.insert("DIRENV_FILE".into(), None);
        changes.insert("DIRENV_DIFF".into(), None);
        changes.insert("DIRENV_WATCHES".into(), None);
        eprintln!("\x1b[0mdirenv: unloading");
    }
    render(shell, &changes);
    0
}

fn cmd_exec(args: &[String]) -> i32 {
    if args.len() < 2 { err("invalid arguments"); return 1; }
    let dir = PathBuf::from(&args[0]);
    let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let abs = if dir.is_absolute() { dir } else { cwd.join(dir) };
    let rc = find_rc(&abs);
    let mut cmd = Command::new(&args[1]);
    cmd.args(&args[2..]).current_dir(&abs);
    if let Some(rc) = rc {
        if !is_allowed(&rc) { err(&format!("{} is blocked. Run `direnv allow` to approve its content", rc.display())); return 1; }
        match eval_rc(&rc) { Ok(envs) => { cmd.envs(envs); }, Err(e) => { err(&e); return 1; } }
    }
    match cmd.status() { Ok(st) => st.code().unwrap_or(1), Err(e) => { err(&e.to_string()); 1 } }
}

fn cmd_status(self_path: &str, args: &[String]) -> i32 {
    let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let rc = find_rc(&cwd);
    if args.iter().any(|a| a == "--json") {
        let val = json!({"config":{"ConfigDir":config_dir().to_string_lossy(),"SelfPath":self_path},"state":{"foundRC":rc.as_ref().map(|p| p.to_string_lossy().to_string()),"loadedRC":env::var("DIRENV_FILE").ok()}});
        println!("{}", serde_json::to_string_pretty(&val).unwrap());
    } else {
        println!("direnv exec path {}", self_path);
        println!("DIRENV_CONFIG {}", config_dir().display());
        println!("bash_path /usr/bin/bash");
        println!("disable_stdin false");
        println!("warn_timeout 5s");
        println!("whitelist.prefix []");
        println!("whitelist.exact map[]");
        match env::var("DIRENV_FILE") { Ok(v) => println!("Loaded RC path {}", v), Err(_) => println!("No .envrc or .env loaded") }
        match rc { Some(p) => { println!("Found RC path {}", p.display()); println!("Found RC allowed {}", if is_allowed(&p){0}else{-1}); }, None => println!("No .envrc or .env found") }
    }
    0
}

fn cmd_prune() -> i32 {
    for sub in ["allow", "deny"] { let _ = fs::create_dir_all(data_dir().join(sub)); }
    0
}

fn cmd_log(args: &[String]) -> i32 {
    let msg: Vec<&String> = args.iter().filter(|a| !a.starts_with("--")).collect();
    if msg.is_empty() { err("invalid arguments"); return 1; }
    eprintln!("\x1b[0mdirenv: {}", msg.iter().map(|s| s.as_str()).collect::<Vec<_>>().join(" "));
    0
}

fn cmd_edit(args: &[String]) -> i32 {
    let rc = match resolve_rc(args.get(0).map(String::as_str)) { Ok(p) => p, Err(e) => { err(&e); return 1; } };
    if !rc.exists() { let _ = fs::write(&rc, b""); }
    let editor = env::var("EDITOR").unwrap_or_else(|_| "vi".into());
    let status = Command::new(editor).arg(&rc).status();
    if status.map(|s| s.success()).unwrap_or(false) { cmd_allow(&[rc.to_string_lossy().to_string()], true) } else { 1 }
}

fn render(shell: &str, changes: &BTreeMap<String, Option<String>>) {
    match shell {
        "json" | "elvish" | "murex" => {
            let mut m = Map::new();
            for (k,v) in changes { m.insert(k.clone(), v.as_ref().map_or(Value::Null, |s| Value::String(s.clone()))); }
            println!("{}", serde_json::to_string_pretty(&Value::Object(m)).unwrap());
        }
        "bash" | "zsh" => { for (k,v) in changes { match v { Some(val) => print!("export {}={};", k, shell_quote(val)), None => print!("unset {};", k) } } }
        "fish" => { for (k,v) in changes { match v { Some(val) => println!("set -gx {} {};", k, shell_quote(val)), None => println!("set -e {};", k) } } }
        "tcsh" => { for (k,v) in changes { match v { Some(val) => println!("setenv {} {};", k, shell_quote(val)), None => println!("unsetenv {};", k) } } }
        "pwsh" => { for (k,v) in changes { match v { Some(val) => println!("$Env:{} = {}", k, ps_quote(val)), None => println!("Remove-Item Env:{} -ErrorAction SilentlyContinue", k) } } }
        "gha" => { for (k,v) in changes { if let Some(val)=v { println!("{}={}", k, val); } } }
        "vim" => { for (k,v) in changes { if let Some(val)=v { println!("let $env:{}={}", k, shell_quote(val)); } } }
        "systemd" | "gzenv" => { for (k,v) in changes { if let Some(val)=v { println!("{}={}", k, val); } } }
        _ => err(&format!("unknown target shell '{}'", shell)),
    }
}

fn eval_rc(rc: &Path) -> Result<HashMap<String,String>, String> {
    let dir = rc.parent().unwrap_or(Path::new("."));
    let mut script = String::new();
    script.push_str(&stdlib_text("direnv"));
    script.push_str("\ncd "); script.push_str(&shell_quote(&dir.to_string_lossy())); script.push('\n');
    if rc.file_name() == Some(OsStr::new(".env")) {
        script.push_str("set -a\nsource "); script.push_str(&shell_quote(&rc.to_string_lossy())); script.push_str("\nset +a\n");
    } else {
        script.push_str("source "); script.push_str(&shell_quote(&rc.to_string_lossy())); script.push('\n');
    }
    script.push_str("env -0\n");
    let out = Command::new("/usr/bin/bash").arg("-lc").arg(script).stdin(Stdio::null()).output().map_err(|e| e.to_string())?;
    if !out.status.success() { return Err(String::from_utf8_lossy(&out.stderr).trim().to_string()); }
    let mut map = HashMap::new();
    for part in out.stdout.split(|b| *b == 0) {
        if part.is_empty() { continue; }
        if let Some(pos) = part.iter().position(|b| *b == b'=') {
            let k = String::from_utf8_lossy(&part[..pos]).to_string();
            let v = String::from_utf8_lossy(&part[pos+1..]).to_string();
            map.insert(k, v);
        }
    }
    Ok(map)
}

fn stdlib_text(direnv_path: &str) -> String { format!(r#"#!/usr/bin/env bash
shopt -s nullglob extglob
direnv={}
direnv_config_dir="${{DIRENV_CONFIG:-${{XDG_CONFIG_HOME:-$HOME/.config}}/direnv}}"
export DIRENV_IN_ENVRC=1
has() {{ type "$1" >/dev/null 2>&1; }}
expand_path() {{ local p="$1" base="${{2:-$PWD}}"; [[ "$p" = /* ]] && (cd "$(dirname "$p")" && printf "%s/%s\n" "$PWD" "$(basename "$p")") || (cd "$base" && cd "$(dirname "$p")" && printf "%s/%s\n" "$PWD" "$(basename "$p")"); }}
user_rel_path() {{ case "$1" in "$HOME"*) printf '~%s\n' "${{1#$HOME}}";; *) printf '%s\n' "$1";; esac; }}
find_up() {{ local name="${{1:-.envrc}}" d="$PWD"; while true; do [[ -e "$d/$name" ]] && {{ echo "$d/$name"; return 0; }}; [[ "$d" = / ]] && return 1; d="$(dirname "$d")"; done; }}
dotenv() {{ local f="${{1:-.env}}"; set -a; source "$f"; set +a; }}
dotenv_if_exists() {{ local f="${{1:-.env}}"; [[ -f "$f" ]] && dotenv "$f" || true; }}
source_env() {{ local p="$1"; [[ -d "$p" ]] && p="$p/.envrc"; source "$p"; }}
source_env_if_exists() {{ [[ -f "$1" ]] && source "$1" || true; }}
source_up() {{ local f="${{1:-.envrc}}" p; p=$(find_up "$f") || return 1; source "$p"; }}
source_up_if_exists() {{ source_up "${{1:-.envrc}}" || true; }}
path_add() {{ local var="$1" p; p=$(expand_path "$2"); local old="${{!var}}"; export "$var=$p${{old:+:$old}}"; }}
PATH_add() {{ path_add PATH "$1"; }}
MANPATH_add() {{ path_add MANPATH "$1"; }}
PATH_rm() {{ local out= ent pat keep; IFS=: read -ra parts <<< "$PATH"; for ent in "${{parts[@]}}"; do keep=1; for pat in "$@"; do [[ "$ent" == $pat ]] && keep=0; done; [[ $keep = 1 ]] && out="${{out:+$out:}}$ent"; done; export PATH="$out"; }}
load_prefix() {{ local p; p=$(expand_path "$1"); PATH_add "$p/bin"; path_add CPATH "$p/include"; path_add LD_LIBRARY_PATH "$p/lib"; path_add LIBRARY_PATH "$p/lib"; MANPATH_add "$p/share/man"; path_add PKG_CONFIG_PATH "$p/lib/pkgconfig"; }}
direnv_layout_dir() {{ local hash; hash=$(printf %s "$PWD" | sha256sum | cut -d' ' -f1); echo "${{XDG_CACHE_HOME:-$HOME/.cache}}/direnv/layouts/$hash"; }}
layout() {{ case "$1" in go) export GOPATH="$(direnv_layout_dir)/go"; PATH_add bin;; node) PATH_add node_modules/.bin;; python|python3) :;; *) :;; esac; }}
watch_file() {{ :; }}
watch_dir() {{ :; }}
strict_env() {{ "$@"; }}
unstrict_env() {{ "$@"; }}
log_status() {{ echo "direnv: $*" >&2; }}
log_error() {{ echo "direnv: error $*" >&2; }}
"#, shell_quote(direnv_path)) }

fn print_stdlib(self_path: &str) { println!("{}", stdlib_text(self_path)); }

fn find_rc(start: &Path) -> Option<PathBuf> {
    let mut d = if start.is_dir() { start.to_path_buf() } else { start.parent()?.to_path_buf() };
    loop {
        let envrc = d.join(".envrc"); if envrc.exists() { return Some(canon(envrc)); }
        let dotenv = d.join(".env"); if dotenv.exists() { return Some(canon(dotenv)); }
        if !d.pop() { break; }
    }
    None
}

fn resolve_rc(arg: Option<&str>) -> Result<PathBuf, String> {
    let cwd = env::current_dir().map_err(|e| e.to_string())?;
    if let Some(a) = arg {
        let mut p = PathBuf::from(a);
        if !p.is_absolute() { p = cwd.join(p); }
        if p.is_dir() { let e = p.join(".envrc"); if e.exists() { return Ok(canon(e)); } return Ok(canon(p.join(".env"))); }
        return Ok(canon(p));
    }
    find_rc(&cwd).map(canon).ok_or_else(|| ".envrc not found".into())
}

fn canon(p: PathBuf) -> PathBuf { fs::canonicalize(&p).unwrap_or(p) }
fn config_dir() -> PathBuf { env::var_os("DIRENV_CONFIG").map(PathBuf::from).or_else(|| env::var_os("XDG_CONFIG_HOME").map(|p| PathBuf::from(p).join("direnv"))).unwrap_or_else(|| home().join(".config/direnv")) }
fn data_dir() -> PathBuf { env::var_os("XDG_DATA_HOME").map(|p| PathBuf::from(p).join("direnv")).unwrap_or_else(|| home().join(".local/share/direnv")) }
fn home() -> PathBuf { env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| PathBuf::from(".")) }
fn rc_id(rc: &Path) -> String { let content = fs::read(rc).unwrap_or_default(); let mut h = Sha256::new(); h.update(rc.to_string_lossy().as_bytes()); h.update(b"\0"); h.update(content); let bytes = h.finalize(); bytes.iter().map(|b| format!("{:02x}", b)).collect() }
fn is_allowed(rc: &Path) -> bool { let id=rc_id(rc); data_dir().join("allow").join(&id).exists() && !data_dir().join("deny").join(&id).exists() }
fn ignored_key(k: &str) -> bool { matches!(k, "_" | "SHLVL" | "PWD" | "OLDPWD" | "DIRENV_IN_ENVRC") }
fn remove_env_state() { println!("unset DIRENV_DIFF;unset DIRENV_DIR;unset DIRENV_FILE;unset DIRENV_WATCHES;"); }
fn diff_summary(before: &HashMap<String,String>, changes: &BTreeMap<String,Option<String>>) -> String { let mut add=Vec::new(); let mut ch=Vec::new(); for (k,v) in changes { if k.starts_with("DIRENV_") { continue; } if let Some(val)=v { if before.contains_key(k) { if before.get(k)!=Some(val) { ch.push(format!("~{}", k)); } } else { add.push(format!("+{}", k)); } } } add.extend(ch); add.join(" ") }
fn err(s: &str) { eprintln!("\x1b[31mdirenv: error {}\x1b[0m", s); }
fn shell_quote(s: &str) -> String { format!("'{}'", s.replace("'", "'\\''")) }
fn ps_quote(s: &str) -> String { format!("'{}'", s.replace("'", "''")) }
