use std::cell::RefCell;
use std::cmp::Ordering;
use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::rc::Rc;

#[derive(Clone, Debug, PartialEq)]
enum Tok {
    Eof,
    Name(String),
    Num(f64),
    Str(String),
    Sym(String),
    Kw(String),
}

struct Lexer {
    chars: Vec<char>,
    pos: usize,
}

impl Lexer {
    fn new(s: &str) -> Self {
        Self { chars: s.chars().collect(), pos: 0 }
    }
    fn peek(&self) -> Option<char> { self.chars.get(self.pos).copied() }
    fn bump(&mut self) -> Option<char> {
        let c = self.peek()?;
        self.pos += 1;
        Some(c)
    }
    fn starts(&self, s: &str) -> bool {
        self.chars[self.pos..].iter().take(s.len()).collect::<String>() == s
    }
    fn skip_ws(&mut self) {
        loop {
            while matches!(self.peek(), Some(c) if c.is_whitespace()) { self.pos += 1; }
            if self.starts("--[[") {
                self.pos += 4;
                while self.pos + 1 < self.chars.len() && !self.starts("]]") { self.pos += 1; }
                if self.starts("]]") { self.pos += 2; }
            } else if self.starts("--") {
                while !matches!(self.peek(), None | Some('\n')) { self.pos += 1; }
            } else {
                break;
            }
        }
    }
    fn string(&mut self, quote: char) -> Tok {
        self.bump();
        let mut out = String::new();
        while let Some(c) = self.bump() {
            if c == quote { break; }
            if c == '\\' {
                let e = self.bump().unwrap_or('\\');
                out.push(match e {
                    'n' => '\n', 't' => '\t', 'r' => '\r', '\\' => '\\', '"' => '"', '\'' => '\'',
                    other => other,
                });
            } else { out.push(c); }
        }
        Tok::Str(out)
    }
    fn next(&mut self) -> Tok {
        self.skip_ws();
        let Some(c) = self.peek() else { return Tok::Eof; };
        if c == '"' || c == '\'' { return self.string(c); }
        if c.is_ascii_digit() || (c == '.' && self.chars.get(self.pos + 1).is_some_and(|x| x.is_ascii_digit())) {
            let start = self.pos;
            if self.starts("0x") || self.starts("0X") {
                self.pos += 2;
                while matches!(self.peek(), Some(x) if x.is_ascii_hexdigit()) { self.pos += 1; }
                let s: String = self.chars[start + 2..self.pos].iter().collect();
                return Tok::Num(i64::from_str_radix(&s, 16).unwrap_or(0) as f64);
            }
            while matches!(self.peek(), Some(x) if x.is_ascii_digit() || x == '.') { self.pos += 1; }
            if matches!(self.peek(), Some('e' | 'E')) {
                self.pos += 1;
                if matches!(self.peek(), Some('+' | '-')) { self.pos += 1; }
                while matches!(self.peek(), Some(x) if x.is_ascii_digit()) { self.pos += 1; }
            }
            let s: String = self.chars[start..self.pos].iter().collect();
            return Tok::Num(s.parse().unwrap_or(0.0));
        }
        if c.is_ascii_alphabetic() || c == '_' {
            let start = self.pos;
            while matches!(self.peek(), Some(x) if x.is_ascii_alphanumeric() || x == '_') { self.pos += 1; }
            let s: String = self.chars[start..self.pos].iter().collect();
            return match s.as_str() {
                "and"|"break"|"do"|"else"|"elseif"|"end"|"false"|"for"|"function"|"goto"|"if"|"in"|"local"|"nil"|"not"|"or"|"repeat"|"return"|"then"|"true"|"until"|"while" => Tok::Kw(s),
                _ => Tok::Name(s),
            };
        }
        for op in ["...", "//", "==", "~=", "<=", ">=", "..", "::"] {
            if self.starts(op) { self.pos += op.len(); return Tok::Sym(op.into()); }
        }
        self.pos += 1;
        Tok::Sym(c.to_string())
    }
}

#[derive(Clone, Debug)]
enum Expr {
    Nil, Bool(bool), Num(f64), Str(String), Var(String), Table(Vec<(Option<Expr>, Expr)>),
    Unary(String, Box<Expr>), Binary(Box<Expr>, String, Box<Expr>),
    Call(Box<Expr>, Vec<Expr>), MethodCall(Box<Expr>, String, Vec<Expr>), Index(Box<Expr>, Box<Expr>), Function(Vec<String>, Vec<Stmt>),
}

#[derive(Clone, Debug)]
enum Stmt {
    Expr(Expr), Local(Vec<String>, Vec<Expr>), Assign(Vec<Expr>, Vec<Expr>),
    If(Vec<(Expr, Vec<Stmt>)>, Vec<Stmt>), While(Expr, Vec<Stmt>), Repeat(Vec<Stmt>, Expr),
    ForNum(String, Expr, Expr, Option<Expr>, Vec<Stmt>),
    ForIn(Vec<String>, Expr, Vec<Stmt>), Function(String, Vec<String>, Vec<Stmt>),
    Return(Vec<Expr>), Break,
}

struct Parser {
    toks: Vec<Tok>,
    pos: usize,
}

impl Parser {
    fn new(src: &str) -> Self {
        let mut l = Lexer::new(src);
        let mut toks = Vec::new();
        loop {
            let t = l.next();
            let eof = t == Tok::Eof;
            toks.push(t);
            if eof { break; }
        }
        Self { toks, pos: 0 }
    }
    fn peek(&self) -> &Tok { self.toks.get(self.pos).unwrap_or(&Tok::Eof) }
    fn next(&mut self) -> Tok { let t = self.peek().clone(); self.pos += 1; t }
    fn sym(&mut self, s: &str) -> bool { if *self.peek() == Tok::Sym(s.into()) { self.pos += 1; true } else { false } }
    fn kw(&mut self, s: &str) -> bool { if *self.peek() == Tok::Kw(s.into()) { self.pos += 1; true } else { false } }
    fn name(&mut self) -> Result<String, String> {
        match self.next() { Tok::Name(s) => Ok(s), _ => Err("syntax error: name expected".into()) }
    }
    fn block(&mut self, stops: &[&str]) -> Result<Vec<Stmt>, String> {
        let mut v = Vec::new();
        while !matches!(self.peek(), Tok::Eof) {
            if let Tok::Kw(k) = self.peek() { if stops.contains(&k.as_str()) { break; } }
            v.push(self.stmt()?);
            self.sym(";");
        }
        Ok(v)
    }
    fn stmt(&mut self) -> Result<Stmt, String> {
        if self.kw("local") {
            if self.kw("function") {
                let name = self.name()?;
                let (p, b) = self.func_body()?;
                return Ok(Stmt::Local(vec![name], vec![Expr::Function(p, b)]));
            }
            let mut names = vec![self.name()?];
            while self.sym(",") { names.push(self.name()?); }
            let vals = if self.sym("=") { self.expr_list()? } else { Vec::new() };
            return Ok(Stmt::Local(names, vals));
        }
        if self.kw("function") {
            let name = self.name()?;
            let (p, b) = self.func_body()?;
            return Ok(Stmt::Function(name, p, b));
        }
        if self.kw("if") {
            let mut arms = Vec::new();
            let c = self.expr()?;
            self.kw("then");
            arms.push((c, self.block(&["elseif", "else", "end"])?));
            while self.kw("elseif") {
                let c = self.expr()?;
                self.kw("then");
                arms.push((c, self.block(&["elseif", "else", "end"])?));
            }
            let els = if self.kw("else") { self.block(&["end"])? } else { Vec::new() };
            self.kw("end");
            return Ok(Stmt::If(arms, els));
        }
        if self.kw("while") {
            let c = self.expr()?;
            self.kw("do");
            let b = self.block(&["end"])?;
            self.kw("end");
            return Ok(Stmt::While(c, b));
        }
        if self.kw("repeat") {
            let b = self.block(&["until"])?;
            self.kw("until");
            let c = self.expr()?;
            return Ok(Stmt::Repeat(b, c));
        }
        if self.kw("for") {
            let n = self.name()?;
            if self.sym("=") {
                let a = self.expr()?; self.sym(","); let b = self.expr()?;
                let step = if self.sym(",") { Some(self.expr()?) } else { None };
                self.kw("do"); let body = self.block(&["end"])?; self.kw("end");
                return Ok(Stmt::ForNum(n, a, b, step, body));
            }
            let mut names = vec![n];
            while self.sym(",") { names.push(self.name()?); }
            self.kw("in"); let iter = self.expr()?; self.kw("do");
            let body = self.block(&["end"])?; self.kw("end");
            return Ok(Stmt::ForIn(names, iter, body));
        }
        if self.kw("return") {
            let vals = if matches!(self.peek(), Tok::Eof | Tok::Kw(_)) { Vec::new() } else { self.expr_list()? };
            return Ok(Stmt::Return(vals));
        }
        if self.kw("break") { return Ok(Stmt::Break); }
        let e = self.prefix_expr()?;
        if self.sym("=") || self.sym(",") {
            self.pos -= 1;
            let mut lhs = vec![e];
            while self.sym(",") { lhs.push(self.prefix_expr()?); }
            self.sym("=");
            Ok(Stmt::Assign(lhs, self.expr_list()?))
        } else {
            Ok(Stmt::Expr(e))
        }
    }
    fn func_body(&mut self) -> Result<(Vec<String>, Vec<Stmt>), String> {
        self.sym("(");
        let mut params = Vec::new();
        if !self.sym(")") {
            loop {
                match self.next() {
                    Tok::Name(s) => params.push(s),
                    Tok::Sym(s) if s == "..." => params.push("...".into()),
                    _ => return Err("syntax error: parameter expected".into()),
                }
                if self.sym(")") { break; }
                self.sym(",");
            }
        }
        let body = self.block(&["end"])?;
        self.kw("end");
        Ok((params, body))
    }
    fn expr_list(&mut self) -> Result<Vec<Expr>, String> {
        let mut v = vec![self.expr()?];
        while self.sym(",") { v.push(self.expr()?); }
        Ok(v)
    }
    fn expr(&mut self) -> Result<Expr, String> { self.bin(1) }
    fn prec(op: &str) -> (u8, bool) {
        match op { "or" => (1,false), "and" => (2,false), "=="|"~="|"<"|">"|"<="|">=" => (3,false), ".." => (4,true), "+"|"-" => (5,false), "*"|"/"|"//"|"%" => (6,false), "^" => (8,true), _ => (0,false) }
    }
    fn bin(&mut self, min: u8) -> Result<Expr, String> {
        let mut left = self.unary()?;
        loop {
            let op = match self.peek() {
                Tok::Sym(s) => s.clone(),
                Tok::Kw(s) if s == "and" || s == "or" => s.clone(),
                _ => break,
            };
            let (p, right) = Self::prec(&op);
            if p < min || p == 0 { break; }
            self.next();
            let rhs = self.bin(if right { p } else { p + 1 })?;
            left = Expr::Binary(Box::new(left), op, Box::new(rhs));
        }
        Ok(left)
    }
    fn unary(&mut self) -> Result<Expr, String> {
        match self.peek() {
            Tok::Sym(s) if s == "-" || s == "#" => { let op = s.clone(); self.next(); Ok(Expr::Unary(op, Box::new(self.unary()?))) }
            Tok::Kw(s) if s == "not" => { self.next(); Ok(Expr::Unary("not".into(), Box::new(self.unary()?))) }
            _ => self.prefix_expr(),
        }
    }
    fn prefix_expr(&mut self) -> Result<Expr, String> {
        let mut e = self.primary()?;
        loop {
            if self.sym("(") {
                let args = if self.sym(")") { Vec::new() } else { let a = self.expr_list()?; self.sym(")"); a };
                e = Expr::Call(Box::new(e), args);
            } else if self.sym(".") {
                let n = self.name()?;
                e = Expr::Index(Box::new(e), Box::new(Expr::Str(n)));
            } else if self.sym(":") {
                let n = self.name()?;
                self.sym("(");
                let mut args = if self.sym(")") { Vec::new() } else { let a = self.expr_list()?; self.sym(")"); a };
                args.insert(0, e.clone());
                e = Expr::MethodCall(Box::new(Expr::Index(Box::new(e), Box::new(Expr::Str(n.clone())))), n, args);
            } else if self.sym("[") {
                let k = self.expr()?; self.sym("]");
                e = Expr::Index(Box::new(e), Box::new(k));
            } else if matches!(self.peek(), Tok::Str(_)) {
                if let Tok::Str(s) = self.next() { e = Expr::Call(Box::new(e), vec![Expr::Str(s)]); }
            } else { break; }
        }
        Ok(e)
    }
    fn primary(&mut self) -> Result<Expr, String> {
        match self.next() {
            Tok::Kw(s) if s == "nil" => Ok(Expr::Nil),
            Tok::Kw(s) if s == "true" => Ok(Expr::Bool(true)),
            Tok::Kw(s) if s == "false" => Ok(Expr::Bool(false)),
            Tok::Num(n) => Ok(Expr::Num(n)),
            Tok::Str(s) => Ok(Expr::Str(s)),
            Tok::Name(s) => Ok(Expr::Var(s)),
            Tok::Sym(s) if s == "(" => { let e = self.expr()?; self.sym(")"); Ok(e) }
            Tok::Sym(s) if s == "..." => Ok(Expr::Var("...".into())),
            Tok::Sym(s) if s == "{" => {
                let mut items = Vec::new();
                if !self.sym("}") {
                    loop {
                        if self.sym("[") {
                            let k = self.expr()?; self.sym("]"); self.sym("="); let v = self.expr()?;
                            items.push((Some(k), v));
                        } else if let Tok::Name(n) = self.peek().clone() {
                            if self.toks.get(self.pos + 1) == Some(&Tok::Sym("=".into())) {
                                self.next(); self.sym("="); let v = self.expr()?;
                                items.push((Some(Expr::Str(n)), v));
                            } else { items.push((None, self.expr()?)); }
                        } else {
                            items.push((None, self.expr()?));
                        }
                        if self.sym("}") { break; }
                        self.sym(",") || self.sym(";");
                    }
                }
                Ok(Expr::Table(items))
            }
            Tok::Kw(s) if s == "function" => { let (p,b) = self.func_body()?; Ok(Expr::Function(p,b)) }
            _ => Err("syntax error".into()),
        }
    }
}

#[derive(Clone)]
enum Value {
    Nil, Bool(bool), Num(f64), Str(String), Table(Rc<RefCell<Table>>), Func(Rc<Func>),
}

#[derive(Clone)]
enum Func {
    Builtin(fn(Vec<Value>, &mut Interp) -> Result<Vec<Value>, String>),
    User(Vec<String>, Vec<Stmt>, Env),
}

#[derive(Default)]
struct Table { arr: Vec<Value>, map: HashMap<String, Value> }
type Env = Rc<RefCell<Scope>>;
struct Scope { vars: HashMap<String, Value>, parent: Option<Env> }

enum Flow { None, Return(Vec<Value>), Break }

struct Interp { env: Env, globals: Env, script: String }

impl Value {
    fn truthy(&self) -> bool { !matches!(self, Value::Nil | Value::Bool(false)) }
    fn type_name(&self) -> &'static str {
        match self { Value::Nil=>"nil", Value::Bool(_)=>"boolean", Value::Num(_)=>"number", Value::Str(_)=>"string", Value::Table(_)=>"table", Value::Func(_)=>"function" }
    }
    fn key(&self) -> String {
        match self {
            Value::Str(s) => s.clone(),
            Value::Num(n) if n.fract() == 0.0 => (*n as i64).to_string(),
            Value::Num(n) => n.to_string(),
            Value::Bool(b) => b.to_string(),
            Value::Nil => "nil".into(),
            _ => format!("{:p}", self),
        }
    }
    fn display(&self) -> String {
        match self {
            Value::Nil => "nil".into(),
            Value::Bool(b) => b.to_string(),
            Value::Num(n) if n.fract() == 0.0 => (*n as i64).to_string(),
            Value::Num(n) => {
                let mut s = n.to_string();
                if s.contains('.') { while s.ends_with('0') { s.pop(); } if s.ends_with('.') { s.push('0'); } }
                s
            }
            Value::Str(s) => s.clone(),
            Value::Table(t) => format!("table: {:p}", Rc::as_ptr(t)),
            Value::Func(f) => format!("function: {:p}", Rc::as_ptr(f)),
        }
    }
    fn num(&self) -> f64 {
        match self { Value::Num(n) => *n, Value::Str(s) => s.parse().unwrap_or(0.0), Value::Bool(true) => 1.0, _ => 0.0 }
    }
}

impl Interp {
    fn new(script: String, args: Vec<String>) -> Self {
        let globals = Rc::new(RefCell::new(Scope { vars: HashMap::new(), parent: None }));
        let mut me = Self { env: globals.clone(), globals: globals.clone(), script };
        me.install(args);
        me
    }
    fn child(&self) -> Env { Rc::new(RefCell::new(Scope { vars: HashMap::new(), parent: Some(self.env.clone()) })) }
    fn get(&self, n: &str) -> Value {
        let mut cur = Some(self.env.clone());
        while let Some(e) = cur {
            if let Some(v) = e.borrow().vars.get(n) { return v.clone(); }
            cur = e.borrow().parent.clone();
        }
        Value::Nil
    }
    fn set_local(&mut self, n: String, v: Value) { self.env.borrow_mut().vars.insert(n, v); }
    fn set(&mut self, n: String, v: Value) {
        let mut cur = Some(self.env.clone());
        while let Some(e) = cur {
            if e.borrow().vars.contains_key(&n) { e.borrow_mut().vars.insert(n, v); return; }
            cur = e.borrow().parent.clone();
        }
        self.globals.borrow_mut().vars.insert(n, v);
    }
    fn install(&mut self, args: Vec<String>) {
        for (n, f) in [
            ("print", builtin_print as fn(Vec<Value>, &mut Interp) -> _), ("type", builtin_type), ("tostring", builtin_tostring),
            ("tonumber", builtin_tonumber), ("error", builtin_error), ("assert", builtin_assert), ("pairs", builtin_id),
            ("ipairs", builtin_id), ("next", builtin_next), ("require", builtin_require), ("dofile", builtin_dofile),
            ("pcall", builtin_pcall), ("select", builtin_select), ("collectgarbage", builtin_collect),
        ] { self.set(n.into(), Value::Func(Rc::new(Func::Builtin(f)))); }
        self.set("_VERSION".into(), Value::Str("Lua 5.5".into()));
        let argt = Rc::new(RefCell::new(Table::default()));
        for (i, a) in args.iter().enumerate() { argt.borrow_mut().map.insert(i.to_string(), Value::Str(a.clone())); }
        self.set("arg".into(), Value::Table(argt));
        self.lib_math(); self.lib_string(); self.lib_table(); self.lib_os(); self.lib_io(); self.lib_utf8();
    }
    fn lib(&mut self, name: &str, funcs: &[(&str, fn(Vec<Value>, &mut Interp)->Result<Vec<Value>,String>)]) {
        let t = Rc::new(RefCell::new(Table::default()));
        for (n, f) in funcs { t.borrow_mut().map.insert((*n).into(), Value::Func(Rc::new(Func::Builtin(*f)))); }
        self.set(name.into(), Value::Table(t));
    }
    fn lib_math(&mut self) { self.lib("math", &[("abs", m_abs),("floor",m_floor),("ceil",m_ceil),("max",m_max),("min",m_min),("sqrt",m_sqrt),("sin",m_sin),("cos",m_cos),("type",m_type)]); }
    fn lib_string(&mut self) { self.lib("string", &[("len",s_len),("upper",s_upper),("lower",s_lower),("sub",s_sub),("rep",s_rep),("reverse",s_reverse),("format",s_format)]); }
    fn lib_table(&mut self) { self.lib("table", &[("concat",t_concat),("insert",t_insert),("remove",t_remove)]); }
    fn lib_os(&mut self) { self.lib("os", &[("exit", os_exit)]); }
    fn lib_io(&mut self) { self.lib("io", &[("write", io_write),("read", io_read)]); }
    fn lib_utf8(&mut self) { self.lib("utf8", &[("char", utf8_char),("len", s_len)]); }
    fn eval_block(&mut self, b: &[Stmt]) -> Result<Flow, String> {
        for s in b {
            match self.stmt(s)? { Flow::None => (), f => return Ok(f) }
        }
        Ok(Flow::None)
    }
    fn stmt(&mut self, s: &Stmt) -> Result<Flow, String> {
        match s {
            Stmt::Expr(e) => { self.eval(e)?; Ok(Flow::None) }
            Stmt::Local(ns, es) => {
                let vals = self.eval_list(es)?;
                for (i,n) in ns.iter().enumerate() { self.set_local(n.clone(), vals.get(i).cloned().unwrap_or(Value::Nil)); }
                Ok(Flow::None)
            }
            Stmt::Assign(lhs, rhs) => {
                let vals = self.eval_list(rhs)?;
                for (i,l) in lhs.iter().enumerate() { self.assign(l, vals.get(i).cloned().unwrap_or(Value::Nil))?; }
                Ok(Flow::None)
            }
            Stmt::Function(n,p,b) => { self.set(n.clone(), Value::Func(Rc::new(Func::User(p.clone(), b.clone(), self.env.clone())))); Ok(Flow::None) }
            Stmt::If(arms, els) => {
                for (c,b) in arms { if self.eval(c)?.truthy() { return self.with_scope(b); } }
                self.with_scope(els)
            }
            Stmt::While(c,b) => {
                while self.eval(c)?.truthy() {
                    match self.with_scope(b)? { Flow::None => (), Flow::Break => break, r @ Flow::Return(_) => return Ok(r) }
                }
                Ok(Flow::None)
            }
            Stmt::Repeat(b,c) => {
                loop {
                    match self.with_scope(b)? { Flow::None => (), Flow::Break => break, r @ Flow::Return(_) => return Ok(r) }
                    if self.eval(c)?.truthy() { break; }
                }
                Ok(Flow::None)
            }
            Stmt::ForNum(n,a,b,st,body) => {
                let mut i = self.eval(a)?.num(); let limit = self.eval(b)?.num(); let step = st.as_ref().map(|e| self.eval(e).map(|v| v.num())).transpose()?.unwrap_or(1.0);
                while if step >= 0.0 { i <= limit } else { i >= limit } {
                    let old = self.env.clone(); self.env = self.child(); self.set_local(n.clone(), Value::Num(i));
                    let f = self.eval_block(body)?; self.env = old;
                    match f { Flow::None => (), Flow::Break => break, r @ Flow::Return(_) => return Ok(r) }
                    i += step;
                }
                Ok(Flow::None)
            }
            Stmt::ForIn(names, iter, body) => {
                let v = self.eval(iter)?;
                let table = match v { Value::Table(t) => t, _ => return Ok(Flow::None) };
                let mut entries: Vec<(Value,Value)> = Vec::new();
                for (i,val) in table.borrow().arr.iter().enumerate() { entries.push((Value::Num((i+1) as f64), val.clone())); }
                for (k,val) in table.borrow().map.iter() { entries.push((Value::Str(k.clone()), val.clone())); }
                entries.sort_by(|a,b| a.0.display().cmp(&b.0.display()));
                for (k,val) in entries {
                    let old = self.env.clone(); self.env = self.child();
                    if let Some(n) = names.get(0) { self.set_local(n.clone(), k); }
                    if let Some(n) = names.get(1) { self.set_local(n.clone(), val); }
                    let f = self.eval_block(body)?; self.env = old;
                    match f { Flow::None => (), Flow::Break => break, r @ Flow::Return(_) => return Ok(r) }
                }
                Ok(Flow::None)
            }
            Stmt::Return(es) => Ok(Flow::Return(self.eval_list(es)?)),
            Stmt::Break => Ok(Flow::Break),
        }
    }
    fn with_scope(&mut self, b: &[Stmt]) -> Result<Flow, String> { let old = self.env.clone(); self.env = self.child(); let r = self.eval_block(b); self.env = old; r }
    fn assign(&mut self, lhs: &Expr, v: Value) -> Result<(), String> {
        match lhs {
            Expr::Var(n) => self.set(n.clone(), v),
            Expr::Index(t,k) => {
                if let Value::Table(tab) = self.eval(t)? {
                    let keyv = self.eval(k)?;
                    if let Value::Num(n) = keyv { if n.fract()==0.0 && n >= 1.0 { let mut tb=tab.borrow_mut(); let idx=n as usize; if idx>tb.arr.len(){tb.arr.resize(idx,Value::Nil)}; tb.arr[idx-1]=v; return Ok(()); } }
                    tab.borrow_mut().map.insert(keyv.key(), v);
                }
            }
            _ => {}
        }
        Ok(())
    }
    fn eval_list(&mut self, es: &[Expr]) -> Result<Vec<Value>, String> {
        let mut out = Vec::new();
        for (i,e) in es.iter().enumerate() {
            let vals = self.eval_multi(e)?;
            if i + 1 == es.len() { out.extend(vals); } else { out.push(vals.into_iter().next().unwrap_or(Value::Nil)); }
        }
        Ok(out)
    }
    fn eval_multi(&mut self, e: &Expr) -> Result<Vec<Value>, String> {
        if let Expr::Call(_,_) = e { self.eval_call_expr(e) } else { Ok(vec![self.eval(e)?]) }
    }
    fn eval(&mut self, e: &Expr) -> Result<Value, String> {
        Ok(match e {
            Expr::Nil => Value::Nil, Expr::Bool(b) => Value::Bool(*b), Expr::Num(n) => Value::Num(*n), Expr::Str(s) => Value::Str(s.clone()),
            Expr::Var(n) => self.get(n),
            Expr::Function(p,b) => Value::Func(Rc::new(Func::User(p.clone(), b.clone(), self.env.clone()))),
            Expr::Table(items) => {
                let t = Rc::new(RefCell::new(Table::default())); let mut idx = 1usize;
                for (k,v) in items {
                    let val = self.eval(v)?;
                    if let Some(ke) = k { let key = self.eval(ke)?; if let Value::Num(n)=key { if n.fract()==0.0 && n>=1.0 { let i=n as usize; if i>t.borrow().arr.len(){t.borrow_mut().arr.resize(i,Value::Nil)}; t.borrow_mut().arr[i-1]=val; continue; } } t.borrow_mut().map.insert(key.key(), val); }
                    else { if idx>t.borrow().arr.len(){t.borrow_mut().arr.resize(idx,Value::Nil)}; t.borrow_mut().arr[idx-1]=val; idx+=1; }
                }
                Value::Table(t)
            }
            Expr::Index(t,k) => {
                let tv = self.eval(t)?; let kv = self.eval(k)?;
                match tv { Value::Table(tab) => {
                    if let Value::Num(n)=kv { if n.fract()==0.0 && n>=1.0 { return Ok(tab.borrow().arr.get(n as usize -1).cloned().unwrap_or(Value::Nil)); } }
                    tab.borrow().map.get(&kv.key()).cloned().unwrap_or(Value::Nil)
                }, Value::Str(s) => if kv.key()=="len" { Value::Num(s.len() as f64) } else { Value::Nil }, _ => Value::Nil }
            }
            Expr::Unary(op,a) => { let v = self.eval(a)?; match op.as_str() { "-" => Value::Num(-v.num()), "not" => Value::Bool(!v.truthy()), "#" => match v { Value::Str(s)=>Value::Num(s.chars().count() as f64), Value::Table(t)=>Value::Num(t.borrow().arr.len() as f64), _=>Value::Num(0.0)}, _=>Value::Nil } }
            Expr::Binary(a,op,b) => {
                if op=="and" { let av=self.eval(a)?; if !av.truthy(){return Ok(av)}; return self.eval(b); }
                if op=="or" { let av=self.eval(a)?; if av.truthy(){return Ok(av)}; return self.eval(b); }
                let av=self.eval(a)?; let bv=self.eval(b)?;
                match op.as_str() {
                    "+"=>Value::Num(av.num()+bv.num()), "-"=>Value::Num(av.num()-bv.num()), "*"=>Value::Num(av.num()*bv.num()), "/"=>Value::Num(av.num()/bv.num()), "//"=>Value::Num((av.num()/bv.num()).floor()), "%"=>Value::Num(av.num()%bv.num()), "^"=>Value::Num(av.num().powf(bv.num())),
                    ".."=>Value::Str(format!("{}{}", av.display(), bv.display())),
                    "=="=>Value::Bool(eqv(&av,&bv)), "~="=>Value::Bool(!eqv(&av,&bv)), "<"=>Value::Bool(cmpv(&av,&bv)==Ordering::Less), ">"=>Value::Bool(cmpv(&av,&bv)==Ordering::Greater), "<="=>Value::Bool(cmpv(&av,&bv)!=Ordering::Greater), ">="=>Value::Bool(cmpv(&av,&bv)!=Ordering::Less),
                    _=>Value::Nil
                }
            }
            Expr::Call(_,_) | Expr::MethodCall(_,_,_) => return Ok(self.eval_call_expr(e)?.into_iter().next().unwrap_or(Value::Nil)),
        })
    }
    fn eval_call_expr(&mut self, e: &Expr) -> Result<Vec<Value>, String> {
        match e {
            Expr::Call(f,args) => {
                let fv = self.eval(f)?;
                let av = self.eval_list(args)?;
                self.call(fv, av)
            }
            Expr::MethodCall(f, name, args) => {
                let mut fv = self.eval(f)?;
                if matches!(fv, Value::Nil) {
                    if matches!(args.get(0), Some(Expr::Str(_))) {
                        if let Value::Table(st) = self.get("string") {
                            fv = st.borrow().map.get(name).cloned().unwrap_or(Value::Nil);
                        }
                    }
                }
                let av = self.eval_list(args)?;
                self.call(fv, av)
            }
            _ => Ok(vec![self.eval(e)?])
        }
    }
    fn call(&mut self, f: Value, args: Vec<Value>) -> Result<Vec<Value>, String> {
        match f {
            Value::Func(fun) => match &*fun {
                Func::Builtin(b) => b(args, self),
                Func::User(params, body, closure) => {
                    let old = self.env.clone();
                    self.env = Rc::new(RefCell::new(Scope { vars: HashMap::new(), parent: Some(closure.clone()) }));
                    for (i,p) in params.iter().enumerate() { self.set_local(p.clone(), args.get(i).cloned().unwrap_or(Value::Nil)); }
                    let r = self.eval_block(body)?;
                    self.env = old;
                    Ok(match r { Flow::Return(v) => v, _ => Vec::new() })
                }
            },
            _ => Err("attempt to call a non-function value".into()),
        }
    }
}

fn eqv(a:&Value,b:&Value)->bool{match(a,b){(Value::Nil,Value::Nil)=>true,(Value::Bool(x),Value::Bool(y))=>x==y,(Value::Num(x),Value::Num(y))=>(*x-*y).abs()<1e-12,(Value::Str(x),Value::Str(y))=>x==y,(Value::Table(x),Value::Table(y))=>Rc::ptr_eq(x,y),(Value::Func(x),Value::Func(y))=>Rc::ptr_eq(x,y),_=>false}}
fn cmpv(a:&Value,b:&Value)->Ordering{match(a,b){(Value::Str(x),Value::Str(y))=>x.cmp(y),_=>a.num().partial_cmp(&b.num()).unwrap_or(Ordering::Equal)}}

fn builtin_print(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{println!("{}",args.iter().map(Value::display).collect::<Vec<_>>().join("\t"));Ok(vec![])}
fn builtin_type(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Str(args.get(0).unwrap_or(&Value::Nil).type_name().into())])}
fn builtin_tostring(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Str(args.get(0).unwrap_or(&Value::Nil).display())])}
fn builtin_tonumber(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{Ok(vec![args.get(0).and_then(|v|v.display().parse::<f64>().ok()).map(Value::Num).unwrap_or(Value::Nil)])}
fn builtin_error(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{Err(args.get(0).unwrap_or(&Value::Str("error".into())).display())}
fn builtin_assert(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{if args.get(0).is_some_and(Value::truthy){Ok(args)}else{Err(args.get(1).map(Value::display).unwrap_or("assertion failed!".into()))}}
fn builtin_id(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{Ok(args)}
fn builtin_next(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{if let Some(Value::Table(t))=args.get(0){if let Some(v)=t.borrow().arr.first(){return Ok(vec![Value::Num(1.0),v.clone()])}if let Some((k,v))=t.borrow().map.iter().next(){return Ok(vec![Value::Str(k.clone()),v.clone()])}}Ok(vec![Value::Nil])}
fn builtin_collect(_: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(0.0)])}
fn builtin_require(args: Vec<Value>, i: &mut Interp)->Result<Vec<Value>,String>{
    let name=args.get(0).unwrap_or(&Value::Nil).display();
    Ok(vec![i.get(&name)])
}
fn builtin_dofile(args: Vec<Value>, i: &mut Interp)->Result<Vec<Value>,String>{
    let path=args.get(0).unwrap_or(&Value::Nil).display();
    let src=fs::read_to_string(&path).map_err(|e|e.to_string())?;
    let mut p=Parser::new(&src);
    let b=p.block(&[])?;
    match i.eval_block(&b)? { Flow::Return(v)=>Ok(v), _=>Ok(vec![]) }
}
fn builtin_pcall(args: Vec<Value>, i: &mut Interp)->Result<Vec<Value>,String>{
    let Some(f)=args.get(0).cloned() else { return Ok(vec![Value::Bool(false),Value::Str("attempt to call a nil value".into())]); };
    match i.call(f, args.into_iter().skip(1).collect()) {
        Ok(mut v)=>{v.insert(0,Value::Bool(true));Ok(v)}
        Err(e)=>Ok(vec![Value::Bool(false),Value::Str(e)])
    }
}
fn builtin_select(args: Vec<Value>, _: &mut Interp)->Result<Vec<Value>,String>{
    if args.get(0).is_some_and(|v| v.display()=="#") { return Ok(vec![Value::Num((args.len().saturating_sub(1)) as f64)]); }
    let idx=args.get(0).map(Value::num).unwrap_or(1.0) as isize;
    let start=if idx<0 {(args.len() as isize + idx).max(1)} else {idx}.max(1) as usize;
    Ok(args.into_iter().skip(start).collect())
}
fn m_abs(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.get(0).unwrap_or(&Value::Nil).num().abs())])}
fn m_floor(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.get(0).unwrap_or(&Value::Nil).num().floor())])}
fn m_ceil(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.get(0).unwrap_or(&Value::Nil).num().ceil())])}
fn m_sqrt(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.get(0).unwrap_or(&Value::Nil).num().sqrt())])}
fn m_sin(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.get(0).unwrap_or(&Value::Nil).num().sin())])}
fn m_cos(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.get(0).unwrap_or(&Value::Nil).num().cos())])}
fn m_max(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.iter().map(Value::num).fold(f64::NEG_INFINITY,f64::max))])}
fn m_min(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.iter().map(Value::num).fold(f64::INFINITY,f64::min))])}
fn m_type(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{let v=a.get(0).unwrap_or(&Value::Nil);Ok(vec![Value::Str(if matches!(v,Value::Num(n) if n.fract()==0.0){"integer"}else if matches!(v,Value::Num(_)){"float"}else{"nil"}.into())])}
fn s_len(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Num(a.get(0).unwrap_or(&Value::Nil).display().chars().count() as f64)])}
fn s_upper(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Str(a.get(0).unwrap_or(&Value::Nil).display().to_uppercase())])}
fn s_lower(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Str(a.get(0).unwrap_or(&Value::Nil).display().to_lowercase())])}
fn s_reverse(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Str(a.get(0).unwrap_or(&Value::Nil).display().chars().rev().collect())])}
fn s_rep(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Str(a.get(0).unwrap_or(&Value::Nil).display().repeat(a.get(1).unwrap_or(&Value::Num(1.0)).num() as usize))])}
fn s_sub(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{let s=a.get(0).unwrap_or(&Value::Nil).display();let chars:Vec<char>=s.chars().collect();let len=chars.len() as isize;let mut i=a.get(1).unwrap_or(&Value::Num(1.0)).num() as isize;let mut j=a.get(2).map(Value::num).unwrap_or(len as f64) as isize;if i<0{i=len+i+1}if j<0{j=len+j+1}let start=(i.max(1)-1) as usize;let end=j.max(0).min(len) as usize;Ok(vec![Value::Str(if start<end{chars[start..end].iter().collect()}else{String::new()})])}
fn s_format(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{let mut fmt=a.get(0).unwrap_or(&Value::Str(String::new())).display();for v in a.iter().skip(1){if let Some(p)=fmt.find("%s"){fmt.replace_range(p..p+2,&v.display())}else if let Some(p)=fmt.find("%d"){fmt.replace_range(p..p+2,&(v.num() as i64).to_string())}else if let Some(p)=fmt.find("%f"){fmt.replace_range(p..p+2,&v.num().to_string())}}Ok(vec![Value::Str(fmt.replace("%%","%"))])}
fn t_concat(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{let sep=a.get(1).map(Value::display).unwrap_or_default();if let Some(Value::Table(t))=a.get(0){Ok(vec![Value::Str(t.borrow().arr.iter().filter(|v|!matches!(v,Value::Nil)).map(Value::display).collect::<Vec<_>>().join(&sep))])}else{Ok(vec![Value::Str(String::new())])}}
fn t_insert(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{if let Some(Value::Table(t))=a.get(0){let val=if a.len()>2{a[2].clone()}else{a.get(1).cloned().unwrap_or(Value::Nil)};if a.len()>2{let p=a[1].num() as usize;t.borrow_mut().arr.insert(p.saturating_sub(1),val)}else{t.borrow_mut().arr.push(val)}}Ok(vec![])}
fn t_remove(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{if let Some(Value::Table(t))=a.get(0){let p=a.get(1).map(Value::num).unwrap_or(t.borrow().arr.len() as f64) as usize;if p>=1&&p<=t.borrow().arr.len(){return Ok(vec![t.borrow_mut().arr.remove(p-1)])}}Ok(vec![Value::Nil])}
fn os_exit(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{std::process::exit(a.get(0).map(Value::num).unwrap_or(0.0) as i32)}
fn io_write(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{print!("{}",a.iter().map(Value::display).collect::<Vec<_>>().join(""));let _=io::stdout().flush();Ok(vec![Value::Bool(true)])}
fn io_read(_:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{let mut s=String::new();io::stdin().read_line(&mut s).map_err(|e|e.to_string())?;if s.ends_with('\n'){s.pop();if s.ends_with('\r'){s.pop();}}Ok(vec![Value::Str(s)])}
fn utf8_char(a:Vec<Value>,_:&mut Interp)->Result<Vec<Value>,String>{Ok(vec![Value::Str(a.iter().filter_map(|v|char::from_u32(v.num() as u32)).collect())])}

fn run(src:&str, name:String, args:Vec<String>) -> i32 {
    let mut p = Parser::new(src);
    match p.block(&[]) {
        Ok(stmts) => {
            let mut i = Interp::new(name, args);
            match i.eval_block(&stmts) { Ok(_) => 0, Err(e) => { eprintln!("./executable: {}", e); 1 } }
        }
        Err(e) => { eprintln!("./executable: {}", e); 1 }
    }
}

fn usage() {
    eprintln!("usage: ./executable [options] [script [args]]");
    eprintln!("Available options are:");
    eprintln!("  -e stat   execute string 'stat'");
    eprintln!("  -i        enter interactive mode after executing 'script'");
    eprintln!("  -l mod    require library 'mod' into global 'mod'");
    eprintln!("  -l g=mod  require library 'mod' into global 'g'");
    eprintln!("  -v        show version information");
    eprintln!("  -E        ignore environment variables");
    eprintln!("  -W        turn warnings on");
    eprintln!("  --        stop handling options");
    eprintln!("  -         stop handling options and execute stdin");
}

fn repl() {
    println!("Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio");
    let mut line = String::new();
    loop {
        print!("> "); let _=io::stdout().flush(); line.clear();
        if io::stdin().read_line(&mut line).unwrap_or(0)==0 { break; }
        let code = if line.trim_start().starts_with('=') { format!("print({})", line.trim_start().trim_start_matches('=')) } else { line.clone() };
        run(&code, "(stdin)".into(), vec![]);
    }
}

fn main() {
    let argv: Vec<String> = env::args().collect();
    let mut i=1usize; let mut chunks:Vec<String>=Vec::new(); let mut interactive=false; let mut script:Option<String>=None; let mut stdin_script=false; let mut version_only=false;
    while i<argv.len() {
        let a=&argv[i];
        if a=="--" { i+=1; break; }
        if a=="-" { stdin_script=true; i+=1; break; }
        if !a.starts_with('-') { break; }
        match a.as_str() {
            "-v" => { println!("Lua 5.5.1  Copyright (C) 1994-2026 Lua.org, PUC-Rio"); version_only=true; },
            "-i" => interactive=true,
            "-E"|"-W" => {},
            "-e" => { i+=1; if i>=argv.len(){usage();std::process::exit(1)}; chunks.push(argv[i].clone()); },
            "-l" => { i+=1; },
            _ => { eprintln!("./executable: unrecognized option '{}'", a); usage(); std::process::exit(1); }
        }
        i+=1;
    }
    if stdin_script {
        let mut s=String::new(); io::stdin().read_to_string(&mut s).unwrap(); chunks.push(s);
    } else if i<argv.len() {
        script=Some(argv[i].clone()); i+=1;
    }
    let rest=argv[i..].to_vec();
    let mut status=0;
    let had_chunks = !chunks.is_empty();
    for c in &chunks { status=run(c, "(command line)".into(), {let mut a=vec!["./executable".into(),"-e".into(),c.clone()];a.extend(rest.clone());a}); if status!=0{std::process::exit(status)} }
    if let Some(path)=script {
        match fs::read_to_string(&path) { Ok(s)=> status=run(&s,path.clone(), {let mut a=vec![path.clone()];a.extend(rest.clone());a}), Err(e)=>{eprintln!("./executable: cannot open {}: {}",path,e);status=1;} }
    } else if !had_chunks && !interactive {
        if version_only { return; }
        if io::stdin().is_terminal() {
            repl();
            return;
        }
        let mut s=String::new(); io::stdin().read_to_string(&mut s).unwrap();
        status=run(&s, "(stdin)".into(), vec!["./executable".into()]);
    }
    if interactive { repl(); }
    std::process::exit(status);
}
