use clap::{value_parser, Arg, ArgAction, Command};
use regex::Regex;
use serde_json::{json, Map, Value};
use std::collections::HashSet;
use std::fs;
use std::path::PathBuf;

#[derive(Clone, Debug)]
enum Output {
    Text,
    Flag,
    List,
    Hierarchical,
}

struct Args {
    schema: Option<String>,
    instances: Vec<String>,
    assert_format: bool,
    no_assert_format: bool,
    output: Output,
    version: bool,
    errors_only: bool,
}

#[derive(Clone, Debug)]
struct Ctx<'a> {
    root: &'a Value,
    assert_format: bool,
}

#[derive(Clone, Debug)]
struct Eval {
    valid: bool,
    errors: Vec<String>,
}

impl Eval {
    fn ok() -> Self {
        Self { valid: true, errors: Vec::new() }
    }
    fn err(msg: String) -> Self {
        Self { valid: false, errors: vec![msg] }
    }
    fn merge(&mut self, other: Eval) {
        if !other.valid {
            self.valid = false;
            self.errors.extend(other.errors);
        }
    }
}

fn main() {
    let args = parse_args();
    if args.version {
        println!("Version: 0.41.0");
        return;
    }

    let schema_path = args.schema.as_ref().expect("schema required by clap");
    let schema = match read_json(schema_path) {
        Ok(v) => v,
        Err(e) => {
            println!("Error: {e}");
            std::process::exit(1);
        }
    };

    if args.instances.is_empty() {
        let ctx = Ctx { root: &schema, assert_format: args.assert_format && !args.no_assert_format };
        let result = validate_schema_shape(&schema, &ctx);
        if result.valid {
            println!("Schema is valid");
            std::process::exit(0);
        } else {
            println!("Schema is invalid. Errors:");
            print_errors(&result.errors);
            std::process::exit(1);
        }
    }

    let mut all_valid = true;
    for inst_path in &args.instances {
        let inst = match read_json(inst_path) {
            Ok(v) => v,
            Err(e) => {
                println!("Error: {e}");
                std::process::exit(1);
            }
        };
        let ctx = Ctx { root: &schema, assert_format: args.assert_format && !args.no_assert_format };
        let result = validate(&schema, &inst, &ctx);
        all_valid &= result.valid;
        match args.output {
            Output::Text => {
                if result.valid {
                    if !args.errors_only {
                        println!("{inst_path} - VALID");
                    }
                } else {
                    println!("{inst_path} - INVALID. Errors:");
                    print_errors(&result.errors);
                }
            }
            Output::Flag => print_flag(schema_path, inst_path, result.valid),
            Output::List | Output::Hierarchical => print_basic_json(schema_path, inst_path, &args.output, result),
        }
    }

    std::process::exit(if all_valid { 0 } else { 1 });
}

fn parse_args() -> Args {
    let m = Command::new("executable")
        .bin_name("executable")
        .disable_version_flag(true)
        .arg(Arg::new("schema").value_name("SCHEMA").help("The JSON Schema to validate with (i.e. schema.json)").required_unless_present("version"))
        .arg(Arg::new("instance").short('i').long("instance").value_name("INSTANCES").help("A path to a JSON instance (i.e. filename.json) to validate (may be specified multiple times)").action(ArgAction::Append))
        .arg(Arg::new("draft").short('d').long("draft").value_name("DRAFT").help("Enforce a specific JSON Schema draft").value_parser(["4", "6", "7", "2019", "2020"]))
        .arg(Arg::new("assert-format").long("assert-format").help("Turn ON format validation").action(ArgAction::SetTrue))
        .arg(Arg::new("no-assert-format").long("no-assert-format").help("Turn OFF format validation").action(ArgAction::SetTrue))
        .arg(Arg::new("output").long("output").value_name("OUTPUT").help("Select output style: text (default), flag, list, hierarchical").default_value("text").value_parser(["text", "flag", "list", "hierarchical"]))
        .arg(Arg::new("version").short('v').long("version").help("Show program's version number and exit").action(ArgAction::SetTrue))
        .arg(Arg::new("errors-only").long("errors-only").help("Only show validation errors").action(ArgAction::SetTrue))
        .arg(Arg::new("connect-timeout").long("connect-timeout").value_name("SECONDS").help("Timeout for establishing connections (in seconds)").value_parser(value_parser!(u64)))
        .arg(Arg::new("timeout").long("timeout").value_name("SECONDS").help("Total timeout for HTTP requests (in seconds)").value_parser(value_parser!(u64)))
        .arg(Arg::new("insecure").short('k').long("insecure").help("Skip TLS certificate verification (dangerous!)").action(ArgAction::SetTrue))
        .arg(Arg::new("cacert").long("cacert").value_name("FILE").help("Path to a custom CA certificate file (PEM format)"))
        .get_matches();
    let output = match m.get_one::<String>("output").map(String::as_str).unwrap_or("text") {
        "flag" => Output::Flag,
        "list" => Output::List,
        "hierarchical" => Output::Hierarchical,
        _ => Output::Text,
    };
    Args {
        schema: m.get_one::<String>("schema").cloned(),
        instances: m.get_many::<String>("instance").map(|v| v.cloned().collect()).unwrap_or_default(),
        assert_format: m.get_flag("assert-format"),
        no_assert_format: m.get_flag("no-assert-format"),
        output,
        version: m.get_flag("version"),
        errors_only: m.get_flag("errors-only"),
    }
}

fn read_json(path: &str) -> Result<Value, String> {
    let text = fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&text).map_err(|e| e.to_string())
}

fn print_errors(errors: &[String]) {
    for (idx, err) in errors.iter().enumerate() {
        println!("{}. {}", idx + 1, err);
    }
}

fn print_flag(schema: &str, instance: &str, valid: bool) {
    println!("{}", json!({
        "instance": instance,
        "output": "flag",
        "payload": { "valid": valid },
        "schema": schema
    }));
}

fn print_basic_json(schema: &str, instance: &str, out: &Output, result: Eval) {
    let output = match out { Output::List => "list", Output::Hierarchical => "hierarchical", _ => "text" };
    let schema_uri = file_uri(schema);
    let mut root = Map::new();
    root.insert("valid".into(), Value::Bool(result.valid));
    root.insert("evaluationPath".into(), Value::String(String::new()));
    root.insert("instanceLocation".into(), Value::String(String::new()));
    root.insert("schemaLocation".into(), Value::String(format!("{schema_uri}#")));
    if !result.valid {
        let mut errs = Map::new();
        for (i, e) in result.errors.iter().enumerate() {
            errs.insert(format!("error{}", i + 1), Value::String(e.clone()));
        }
        root.insert("errors".into(), Value::Object(errs));
    }
    println!("{}", json!({
        "instance": instance,
        "output": output,
        "payload": root,
        "schema": schema
    }));
}

fn file_uri(path: &str) -> String {
    let p = fs::canonicalize(path).unwrap_or_else(|_| PathBuf::from(path));
    format!("file://{}", p.display())
}

fn validate_schema_shape(schema: &Value, _ctx: &Ctx) -> Eval {
    match schema {
        Value::Bool(_) | Value::Object(_) => Eval::ok(),
        _ => Eval::err(format!("{} is not of types \"boolean\", \"object\"", display(schema))),
    }
}

fn validate(schema: &Value, inst: &Value, ctx: &Ctx) -> Eval {
    match schema {
        Value::Bool(true) => Eval::ok(),
        Value::Bool(false) => Eval::err(format!("false schema does not allow {}", display(inst))),
        Value::Object(obj) => validate_obj(obj, inst, ctx),
        _ => Eval::ok(),
    }
}

fn validate_obj(obj: &Map<String, Value>, inst: &Value, ctx: &Ctx) -> Eval {
    if let Some(r) = obj.get("$ref").and_then(Value::as_str) {
        if let Some(target) = resolve_ref(ctx.root, r) {
            return validate(target, inst, ctx);
        }
        return Eval::err(format!("Unresolvable reference: {r}"));
    }

    let mut out = Eval::ok();
    if let Some(t) = obj.get("type") {
        if !check_type(t, inst) {
            out.merge(Eval::err(format!("{} is not of type {}", display(inst), type_desc(t))));
        }
    }
    if let Some(c) = obj.get("const") {
        if inst != c {
            out.merge(Eval::err(format!("{} was expected", display(c))));
        }
    }
    if let Some(arr) = obj.get("enum").and_then(Value::as_array) {
        if !arr.iter().any(|v| v == inst) {
            out.merge(Eval::err(format!("{} is not one of {}", display(inst), join_or(arr))));
        }
    }
    validate_numeric(obj, inst, &mut out);
    validate_string(obj, inst, ctx.assert_format, &mut out);
    validate_array(obj, inst, ctx, &mut out);
    validate_object(obj, inst, ctx, &mut out);
    validate_combinators(obj, inst, ctx, &mut out);
    out
}

fn validate_numeric(obj: &Map<String, Value>, inst: &Value, out: &mut Eval) {
    let Some(n) = as_f64(inst) else { return; };
    for (key, text) in [
        ("minimum", "less than the minimum of"),
        ("exclusiveMinimum", "less than or equal to the minimum of"),
        ("maximum", "greater than the maximum of"),
        ("exclusiveMaximum", "greater than or equal to the maximum of"),
    ] {
        if let Some(limit) = obj.get(key).and_then(as_f64) {
            let bad = match key {
                "minimum" => n < limit,
                "exclusiveMinimum" => n <= limit,
                "maximum" => n > limit,
                "exclusiveMaximum" => n >= limit,
                _ => false,
            };
            if bad {
                out.merge(Eval::err(format!("{} is {} {}", display(inst), text, display(obj.get(key).unwrap()))));
            }
        }
    }
    if let Some(m) = obj.get("multipleOf").and_then(as_f64) {
        let q = n / m;
        if (q - q.round()).abs() > 1e-12 {
            out.merge(Eval::err(format!("{} is not a multiple of {}", display(inst), display(obj.get("multipleOf").unwrap()))));
        }
    }
}

fn validate_string(obj: &Map<String, Value>, inst: &Value, assert_format: bool, out: &mut Eval) {
    let Some(s) = inst.as_str() else { return; };
    let len = s.chars().count();
    if let Some(min) = obj.get("minLength").and_then(Value::as_u64) {
        if len < min as usize {
            out.merge(Eval::err(format!("{} is shorter than {} characters", display(inst), min)));
        }
    }
    if let Some(max) = obj.get("maxLength").and_then(Value::as_u64) {
        if len > max as usize {
            out.merge(Eval::err(format!("{} is longer than {} characters", display(inst), max)));
        }
    }
    if let Some(pat) = obj.get("pattern").and_then(Value::as_str) {
        if Regex::new(pat).map(|r| !r.is_match(s)).unwrap_or(false) {
            out.merge(Eval::err(format!("{} does not match {:?}", display(inst), pat)));
        }
    }
    if assert_format {
        if let Some(fmt) = obj.get("format").and_then(Value::as_str) {
            if !format_ok(fmt, s) {
                out.merge(Eval::err(format!("{} is not a {:?}", display(inst), fmt)));
            }
        }
    }
}

fn validate_array(obj: &Map<String, Value>, inst: &Value, ctx: &Ctx, out: &mut Eval) {
    let Some(arr) = inst.as_array() else { return; };
    if let Some(min) = obj.get("minItems").and_then(Value::as_u64) {
        if arr.len() < min as usize {
            out.merge(Eval::err(format!("{} has less than {} items", display(inst), min)));
        }
    }
    if let Some(max) = obj.get("maxItems").and_then(Value::as_u64) {
        if arr.len() > max as usize {
            out.merge(Eval::err(format!("{} has more than {} items", display(inst), max)));
        }
    }
    if obj.get("uniqueItems").and_then(Value::as_bool) == Some(true) {
        let mut seen = HashSet::new();
        for v in arr {
            if !seen.insert(display(v)) {
                out.merge(Eval::err(format!("{} has non-unique elements", display(inst))));
                break;
            }
        }
    }
    if let Some(items) = obj.get("items") {
        if let Some(tuple) = items.as_array() {
            for (i, sub) in tuple.iter().enumerate() {
                if let Some(v) = arr.get(i) {
                    out.merge(validate(sub, v, ctx));
                }
            }
        } else {
            for v in arr {
                out.merge(validate(items, v, ctx));
            }
        }
    }
    if let Some(prefix) = obj.get("prefixItems").and_then(Value::as_array) {
        for (i, sub) in prefix.iter().enumerate() {
            if let Some(v) = arr.get(i) {
                out.merge(validate(sub, v, ctx));
            }
        }
    }
    if obj.get("contains").is_some() {
        let sub = obj.get("contains").unwrap();
        if !arr.iter().any(|v| validate(sub, v, ctx).valid) {
            out.merge(Eval::err(format!("{} does not contain items matching the given schema", display(inst))));
        }
    }
}

fn validate_object(obj: &Map<String, Value>, inst: &Value, ctx: &Ctx, out: &mut Eval) {
    let Some(map) = inst.as_object() else { return; };
    if let Some(min) = obj.get("minProperties").and_then(Value::as_u64) {
        if map.len() < min as usize {
            out.merge(Eval::err(format!("{} has less than {} properties", display(inst), min)));
        }
    }
    if let Some(max) = obj.get("maxProperties").and_then(Value::as_u64) {
        if map.len() > max as usize {
            out.merge(Eval::err(format!("{} has more than {} properties", display(inst), max)));
        }
    }
    if let Some(reqs) = obj.get("required").and_then(Value::as_array) {
        for r in reqs.iter().filter_map(Value::as_str) {
            if !map.contains_key(r) {
                out.merge(Eval::err(format!("{:?} is a required property", r)));
            }
        }
    }

    let mut covered: HashSet<String> = HashSet::new();
    if let Some(props) = obj.get("properties").and_then(Value::as_object) {
        let mut keys: Vec<_> = props.keys().cloned().collect();
        keys.sort();
        for k in keys {
            if let Some(v) = map.get(&k) {
                covered.insert(k.clone());
                out.merge(validate(&props[&k], v, ctx));
            }
        }
    }
    if let Some(patterns) = obj.get("patternProperties").and_then(Value::as_object) {
        for (pat, sub) in patterns {
            if let Ok(re) = Regex::new(pat) {
                for (k, v) in map {
                    if re.is_match(k) {
                        covered.insert(k.clone());
                        out.merge(validate(sub, v, ctx));
                    }
                }
            }
        }
    }
    if let Some(addl) = obj.get("additionalProperties") {
        let extras: Vec<_> = map.keys().filter(|k| !covered.contains(*k)).cloned().collect();
        match addl {
            Value::Bool(false) if !extras.is_empty() => {
                let names = extras.iter().map(|s| format!("'{s}'")).collect::<Vec<_>>();
                let was = if names.len() == 1 { "was" } else { "were" };
                out.merge(Eval::err(format!("Additional properties are not allowed ({} {} unexpected)", names.join(", "), was)));
            }
            Value::Object(_) | Value::Bool(true) => {
                for k in extras {
                    out.merge(validate(addl, &map[&k], ctx));
                }
            }
            _ => {}
        }
    }
    if let Some(deps) = obj.get("dependentRequired").or_else(|| obj.get("dependencies")).and_then(Value::as_object) {
        for (k, dep) in deps {
            if map.contains_key(k) {
                if let Some(arr) = dep.as_array() {
                    for d in arr.iter().filter_map(Value::as_str) {
                        if !map.contains_key(d) {
                            out.merge(Eval::err(format!("{:?} is a dependency of {:?}", d, k)));
                        }
                    }
                } else if dep.is_object() || dep.is_boolean() {
                    out.merge(validate(dep, inst, ctx));
                }
            }
        }
    }
}

fn validate_combinators(obj: &Map<String, Value>, inst: &Value, ctx: &Ctx, out: &mut Eval) {
    if let Some(all) = obj.get("allOf").and_then(Value::as_array) {
        for sub in all {
            out.merge(validate(sub, inst, ctx));
        }
    }
    if let Some(any) = obj.get("anyOf").and_then(Value::as_array) {
        if !any.iter().any(|s| validate(s, inst, ctx).valid) {
            out.merge(Eval::err(format!("{} is not valid under any of the schemas listed in the 'anyOf' keyword", display(inst))));
        }
    }
    if let Some(one) = obj.get("oneOf").and_then(Value::as_array) {
        let count = one.iter().filter(|s| validate(s, inst, ctx).valid).count();
        if count == 0 {
            out.merge(Eval::err(format!("{} is not valid under any of the schemas listed in the 'oneOf' keyword", display(inst))));
        } else if count > 1 {
            out.merge(Eval::err(format!("{} is valid under more than one of the schemas listed in the 'oneOf' keyword", display(inst))));
        }
    }
    if let Some(not) = obj.get("not") {
        if validate(not, inst, ctx).valid {
            out.merge(Eval::err(format!("{} is not allowed for {}", display(not), display(inst))));
        }
    }
    if let Some(ifs) = obj.get("if") {
        let ok = validate(ifs, inst, ctx).valid;
        if ok {
            if let Some(t) = obj.get("then") {
                out.merge(validate(t, inst, ctx));
            }
        } else if let Some(e) = obj.get("else") {
            out.merge(validate(e, inst, ctx));
        }
    }
}

fn check_type(t: &Value, inst: &Value) -> bool {
    if let Some(s) = t.as_str() {
        return is_type(s, inst);
    }
    if let Some(arr) = t.as_array() {
        return arr.iter().filter_map(Value::as_str).any(|s| is_type(s, inst));
    }
    true
}

fn is_type(t: &str, v: &Value) -> bool {
    match t {
        "null" => v.is_null(),
        "boolean" => v.is_boolean(),
        "object" => v.is_object(),
        "array" => v.is_array(),
        "number" => v.is_number(),
        "integer" => v.as_i64().is_some() || v.as_u64().is_some() || v.as_f64().map(|n| n.fract() == 0.0).unwrap_or(false),
        "string" => v.is_string(),
        _ => true,
    }
}

fn type_desc(t: &Value) -> String {
    if let Some(s) = t.as_str() { format!("{s:?}") } else { display(t) }
}

fn as_f64(v: &Value) -> Option<f64> {
    v.as_f64()
}

fn display(v: &Value) -> String {
    serde_json::to_string(v).unwrap_or_else(|_| "null".into())
}

fn join_or(vals: &[Value]) -> String {
    match vals.len() {
        0 => String::new(),
        1 => display(&vals[0]),
        2 => format!("{} or {}", display(&vals[0]), display(&vals[1])),
        _ => {
            let parts: Vec<String> = vals[..vals.len() - 1].iter().map(display).collect();
            let last = display(vals.last().unwrap());
            format!("{} or {}", parts.join(", "), last)
        }
    }
}

fn format_ok(fmt: &str, s: &str) -> bool {
    match fmt {
        "email" | "idn-email" => {
            let parts: Vec<_> = s.split('@').collect();
            parts.len() == 2 && !parts[0].is_empty() && parts[1].contains('.') && !parts[1].starts_with('.') && !parts[1].ends_with('.')
        }
        "ipv4" => s.parse::<std::net::Ipv4Addr>().is_ok(),
        "ipv6" => s.parse::<std::net::Ipv6Addr>().is_ok(),
        "uri" | "uri-reference" | "iri" | "iri-reference" => s.contains(':') || fmt.ends_with("reference"),
        "uuid" => Regex::new(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$").unwrap().is_match(s),
        "date" => Regex::new(r"^\d{4}-\d{2}-\d{2}$").unwrap().is_match(s),
        "time" => Regex::new(r"^\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$").unwrap().is_match(s),
        "date-time" => Regex::new(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$").unwrap().is_match(s),
        "hostname" => !s.is_empty() && s.len() <= 253 && s.split('.').all(|p| !p.is_empty() && p.len() <= 63 && p.chars().all(|c| c.is_ascii_alphanumeric() || c == '-')),
        _ => true,
    }
}

fn resolve_ref<'a>(root: &'a Value, r: &str) -> Option<&'a Value> {
    if r.is_empty() || r == "#" {
        return Some(root);
    }
    let ptr = r.strip_prefix("#")?;
    if ptr.is_empty() {
        Some(root)
    } else {
        root.pointer(ptr)
    }
}
