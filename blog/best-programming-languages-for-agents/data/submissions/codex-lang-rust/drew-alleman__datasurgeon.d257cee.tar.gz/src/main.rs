use regex::Regex;
use std::fs::{self, File};
use std::io::{self, BufRead, BufReader, Read, Write};
use std::path::{Path, PathBuf};
use std::time::Instant;

const PLUGIN_PATH: &str = "/home/agent/.DataSurgeon/plugins.json";

#[derive(Debug, Default)]
struct Args {
    file: String,
    add: String,
    update: String,
    remove: String,
    list: bool,
    clean: bool,
    directory: String,
    ignore: bool,
    line: bool,
    thorough: bool,
    display: bool,
    suppress: bool,
    drop: String,
    filter: String,
    hide: bool,
    output: String,
    time: bool,
    email: bool,
    phone: bool,
    hash: bool,
    ip_addr: bool,
    ipv6_addr: bool,
    mac_addr: bool,
    credit_card: bool,
    url: bool,
    files: bool,
    bitcoin: bool,
    aws: bool,
    google: bool,
    dns: bool,
    social: bool,
    help: bool,
    version: bool,
}

struct Extractor {
    label: &'static str,
    regex: Regex,
}

struct MatchOut {
    label: &'static str,
    data: String,
    line: usize,
    file: Option<String>,
}

fn main() {
    let args = parse_args();
    eprintln!("Failed to open plugins.json file. PLUGIN_PATH: {}", PLUGIN_PATH);

    if args.help {
        print_help();
        return;
    }
    if args.version {
        println!("DataSurgeon: https://github.com/Drew-Alleman/DataSurgeon 1.2.8");
        return;
    }
    if args.list {
        eprintln!("Failed to open plugins.json file. PLUGIN_PATH: {}", PLUGIN_PATH);
        println!("No plugins found. Plugin File: {}", PLUGIN_PATH);
        return;
    }
    if !args.add.is_empty() {
        println!("[-] Error: Failed to parse plugins.json from the provided URL. Reason: error sending request for url ({}): error trying to connect: dns error: failed to lookup address information: Temporary failure in name resolution", plugin_url(&args.add));
        return;
    }
    if !args.remove.is_empty() || !args.update.is_empty() {
        eprintln!("Failed to open plugins.json file. PLUGIN_PATH: {}", PLUGIN_PATH);
        return;
    }

    let start = Instant::now();
    let extractors = build_extractors(&args);
    let filter = compile_optional(&args.filter);
    let drop = compile_optional(&args.drop);
    let mut matches = Vec::new();

    if !args.directory.is_empty() {
        for path in collect_files(Path::new(&args.directory)) {
            if let Ok(file) = File::open(&path) {
                let shown = path.to_string_lossy().to_string();
                process_reader(BufReader::new(file), Some(shown), &args, &extractors, filter.as_ref(), drop.as_ref(), &mut matches);
            }
        }
    } else if !args.file.is_empty() {
        match File::open(&args.file) {
            Ok(file) => process_reader(BufReader::new(file), Some(args.file.clone()), &args, &extractors, filter.as_ref(), drop.as_ref(), &mut matches),
            Err(_) => {
                if !args.ignore {
                    eprintln!("[-] File not found: {}", args.file);
                }
                return;
            }
        }
    } else {
        if !args.suppress {
            eprintln!("[*] Reading standard input. If you meant to analyze a file use 'ds -f <FILE>' (ctrl+c to exit)");
        }
        let mut buf = String::new();
        io::stdin().read_to_string(&mut buf).ok();
        process_reader(BufReader::new(buf.as_bytes()), None, &args, &extractors, filter.as_ref(), drop.as_ref(), &mut matches);
    }

    if args.output.is_empty() {
        for m in &matches {
            println!("{}", format_match(m, &args));
        }
    } else if let Ok(mut f) = File::create(&args.output) {
        let _ = writeln!(f, "content_type, data");
        for m in &matches {
            let _ = writeln!(f, "{}, {}", m.label, csv_escape(&m.data));
        }
    }
    if args.time {
        let s = start.elapsed().as_secs();
        println!("[*] Time elapsed: {:02}h:{:02}m:{:02}s", s / 3600, (s / 60) % 60, s % 60);
    }
}

fn parse_args() -> Args {
    let mut a = Args::default();
    let mut it = std::env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "--help" => a.help = true,
            "--version" => a.version = true,
            "--list" => a.list = true,
            "--clean" => a.clean = true,
            "--ignore" => a.ignore = true,
            "--line" => a.line = true,
            "--thorough" => a.thorough = true,
            "--display" => a.display = true,
            "--suppress" => a.suppress = true,
            "--hide" => a.hide = true,
            "--time" => a.time = true,
            "--email" => a.email = true,
            "--phone" => a.phone = true,
            "--hash" => a.hash = true,
            "--ip-addr" => a.ip_addr = true,
            "--ipv6-addr" => a.ipv6_addr = true,
            "--mac-addr" => a.mac_addr = true,
            "--credit-card" => a.credit_card = true,
            "--url" => a.url = true,
            "--files" => a.files = true,
            "--bitcoin" => a.bitcoin = true,
            "--aws" => a.aws = true,
            "--google" => a.google = true,
            "--dns" => a.dns = true,
            "--social" => a.social = true,
            "-f" | "--file" => a.file = it.next().unwrap_or_default(),
            "--add" => a.add = it.next().unwrap_or_default(),
            "--update" => a.update = it.next().unwrap_or_default(),
            "--remove" => a.remove = it.next().unwrap_or_default(),
            "--directory" => a.directory = it.next().unwrap_or_default(),
            "--drop" => a.drop = it.next().unwrap_or_default(),
            "--filter" => a.filter = it.next().unwrap_or_default(),
            "-o" | "--output" => a.output = it.next().unwrap_or_default(),
            _ if arg.starts_with("--file=") => a.file = arg[7..].to_string(),
            _ if arg.starts_with("--add=") => a.add = arg[6..].to_string(),
            _ if arg.starts_with("--update=") => a.update = arg[9..].to_string(),
            _ if arg.starts_with("--remove=") => a.remove = arg[9..].to_string(),
            _ if arg.starts_with("--directory=") => a.directory = arg[12..].to_string(),
            _ if arg.starts_with("--drop=") => a.drop = arg[7..].to_string(),
            _ if arg.starts_with("--filter=") => a.filter = arg[9..].to_string(),
            _ if arg.starts_with("--output=") => a.output = arg[9..].to_string(),
            _ if arg.starts_with('-') => parse_short_cluster(&arg, &mut a, &mut it),
            _ => {}
        }
    }
    a
}

fn parse_short_cluster<I>(arg: &str, a: &mut Args, it: &mut std::iter::Peekable<I>)
where
    I: Iterator<Item = String>,
{
    let mut chars = arg[1..].chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            'h' => a.help = true,
            'V' => a.version = true,
            'C' => a.clean = true,
            'l' => a.line = true,
            'T' => a.thorough = true,
            'D' => a.display = true,
            'S' => a.suppress = true,
            'X' => a.hide = true,
            't' => a.time = true,
            'e' => a.email = true,
            'p' => a.phone = true,
            'H' => a.hash = true,
            'i' => a.ip_addr = true,
            '6' => a.ipv6_addr = true,
            'm' => a.mac_addr = true,
            'c' => a.credit_card = true,
            'u' => a.url = true,
            'F' => a.files = true,
            'b' => a.bitcoin = true,
            'a' => a.aws = true,
            'g' => a.google = true,
            'd' => a.dns = true,
            's' => a.social = true,
            'f' => {
                let rest: String = chars.collect();
                a.file = if rest.is_empty() { it.next().unwrap_or_default() } else { rest };
                break;
            }
            'o' => {
                let rest: String = chars.collect();
                a.output = if rest.is_empty() { it.next().unwrap_or_default() } else { rest };
                break;
            }
            _ => {}
        }
    }
}

fn compile_optional(s: &str) -> Option<Regex> {
    if s.is_empty() { None } else { Regex::new(s).ok() }
}

fn plugin_url(url: &str) -> String {
    let mut parts: Vec<&str> = url.trim_end_matches('/').split('/').collect();
    if parts.len() >= 2 {
        let repo = parts.pop().unwrap();
        let owner = parts.pop().unwrap();
        format!("https://raw.githubusercontent.com/{}/{}/main/plugins.json", owner, repo)
    } else {
        url.to_string()
    }
}

fn build_extractors(args: &Args) -> Vec<Extractor> {
    let any = args.email || args.phone || args.hash || args.ip_addr || args.ipv6_addr || args.mac_addr
        || args.credit_card || args.url || args.files || args.bitcoin || args.aws || args.google
        || args.dns || args.social;
    let mut v = Vec::new();
    macro_rules! add {
        ($flag:expr, $label:expr, $pat:expr) => {
            if $flag || !any {
                v.push(Extractor { label: $label, regex: Regex::new($pat).unwrap() });
            }
        };
    }
    add!(args.email, "email", r"(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b");
    add!(args.phone, "phone_number", r"\b(?:\+?1[\s.-]?)?(?:\([2-9]\d{2}\)[\s.-]?|[2-9]\d{2}[\s.-])[2-9]\d{2}[\s.-]\d{4}\b");
    add!(args.ip_addr, "ip_address", r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b");
    add!(args.ipv6_addr, "ipv6_address", r"\b(?:[0-9A-Fa-f]{1,4}:){5,7}[0-9A-Fa-f]{1,4}\b");
    add!(args.mac_addr, "mac_address", r"\b[0-9A-Fa-f]{2}(?::[0-9A-Fa-f]{2}){5}\b");
    add!(args.url, "url", r#"(?i)\bhttps?://[^\s<>"')]+[^\s<>"').,;:]"#);
    add!(args.hash, "hashes", r"\b(?:[A-Fa-f0-9]{32}|[A-Fa-f0-9]{40}|[A-Fa-f0-9]{56}|[A-Fa-f0-9]{64}|[A-Fa-f0-9]{96}|[A-Fa-f0-9]{128}|\$2[aby]\$[0-9]{2}\$[./A-Za-z0-9]{53})\b");
    add!(args.credit_card, "credit_card", r"\b(?:\d[ -]*?){13,19}\b");
    add!(args.files, "files", r"(?i)\b(?:[A-Za-z0-9_-]+\s+)?[A-Za-z0-9_-]+\.(?:txt|log|csv|json|xml|js|css|png|jpe?g|gif|pdf|docx?|xlsx?|pptx?|zip|tar|gz|exe|dll|so|rs|py|go|cpp?)\b");
    add!(args.bitcoin, "bitcoin_wallet", r"\b(?:bc1[ac-hj-np-z02-9]{11,71}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})\b");
    add!(args.aws, "aws_key", r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b");
    add!(args.google, "google_private_key_id", r#""private_key_id"\s*:\s*"[a-f0-9]{40}""#);
    add!(args.dns, "dns_record", r"\b(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}\b");
    add!(args.social, "social_security", r"\b\d{3}-\d{2}-\d{4}\b");
    v
}

fn process_reader<R: BufRead>(reader: R, file: Option<String>, args: &Args, exts: &[Extractor], filter: Option<&Regex>, drop: Option<&Regex>, out: &mut Vec<MatchOut>) {
    for (idx, line_res) in reader.lines().enumerate() {
        let Ok(line) = line_res else { continue };
        if let Some(f) = filter {
            if !f.is_match(&line) {
                continue;
            }
        }
        for ext in exts {
            if args.clean {
                let iter = ext.regex.find_iter(&line);
                for mat in iter {
                    let data = mat.as_str().to_string();
                    if drop.map_or(false, |d| d.is_match(&data)) {
                        continue;
                    }
                    out.push(MatchOut { label: ext.label, data, line: idx + 1, file: file.clone() });
                    if !args.thorough {
                        break;
                    }
                }
            } else if ext.regex.is_match(&line) {
                if drop.map_or(false, |d| d.is_match(&line)) {
                    continue;
                }
                out.push(MatchOut { label: ext.label, data: line.clone(), line: idx + 1, file: file.clone() });
            }
        }
    }
}

fn format_match(m: &MatchOut, args: &Args) -> String {
    if args.hide {
        let mut s = String::new();
        if args.display {
            if let Some(f) = &m.file {
                s.push_str(&format!("file: {} ", f));
            }
        }
        s.push_str(&m.data);
        if args.line {
            s.push_str(&format!(", line: {}", m.line));
        }
        return s;
    }
    if args.display || args.line {
        let mut s = m.label.to_string();
        if args.display {
            if let Some(f) = &m.file {
                s.push_str(&format!(", file: {} {}", f, m.data));
            } else {
                s.push_str(&format!(", file:  {}", m.data));
            }
        } else {
            s.push_str(&format!(", {}", m.data));
        }
        if args.line {
            s.push_str(&format!(", line: {}", m.line));
        }
        s
    } else {
        format!("{}: {}", m.label, m.data)
    }
}

fn collect_files(root: &Path) -> Vec<PathBuf> {
    let mut out = Vec::new();
    fn walk(p: &Path, out: &mut Vec<PathBuf>) {
        if let Ok(rd) = fs::read_dir(p) {
            let mut entries: Vec<_> = rd.filter_map(Result::ok).collect();
            entries.sort_by_key(|e| e.path());
            for e in entries {
                let path = e.path();
                if path.is_dir() {
                    walk(&path, out);
                } else if path.is_file() {
                    out.push(path);
                }
            }
        }
    }
    walk(root, &mut out);
    out
}

fn csv_escape(s: &str) -> String {
    if s.contains(',') || s.contains('"') || s.contains('\n') {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_string()
    }
}

fn print_help() {
    println!("Note: All extraction features (e.g: -i) work on a specified file (-f) or an output stream.\n");
    println!("Usage: executable [OPTIONS]\n");
    println!("Options:");
    println!("  -f, --file <file>            File to extract information from [default: \"\"]");
    println!("      --add <add>              Adds a plugin from a GitHub repository (e.g ds --add https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: \"\"]");
    println!("      --update <update>        Updates a plugin from a GitHub repository. You can also use `ds --update all` to update all plugins. (e.g ds --update https://github.com/DataSurgeon-ds/ds-cve-plugin/) [default: \"\"]");
    println!("      --remove <remove>        Removes a plugin from a GitHub repository (e.g ds --remove https://github.com/Drew-Alleman/ds-winreg-plugin/) [default: \"\"]");
    println!("      --list                   List all added plugins");
    println!("  -C, --clean                  Only displays the matched result, rather than the entire line");
    println!("      --directory <directory>  Process all files found in the specified directory [default: \"\"]");
    println!("      --ignore                 Silences error messages");
    println!("  -l, --line                   Displays the line number where the match occurred");
    println!("  -T, --thorough               Doesn't stop at first match (useful for -C if multiple unique matches are on the same line");
    println!("  -D, --display                Displays the filename assoicated with the content found (https://github.com/Drew-Alleman/DataSurgeon#reading-all-files-in-a-directory)");
    println!("  -S, --suppress               Suppress the 'Reading standard input' message when not providing a file");
    println!("{}", "      --drop <drop>            Specify a regular expression to exclude certain patterns from the search. (e.g --drop \"^.{1,10}$\" will hide all matches not under 10 characters) [default: \"\"]");
    println!("      --filter <filter>        Include only lines that match the specified regex. (e.g: '--filter ^error' will only include lines that start with the word 'error' [default: \"\"]");
    println!("  -X, --hide                   Hides the identifier string infront of the desired content (e.g: 'hash: ', 'url: ', 'email: ' will not be displayed.");
    println!("  -o, --output <output>        Output's the results of the procedure to a local file (recommended for large files) [default: \"\"]");
    println!("  -t, --time                   Time how long the operation took");
    println!("  -e, --email                  Extract email addresses");
    println!("  -p, --phone                  Extracts phone numbers");
    println!("  -H, --hash                   Extract hashes (NTLM, LM, bcrypt, Oracle, MD5, SHA-1, SHA-224, SHA-256, SHA-384, SHA-512, SHA3-224, SHA3-256, SHA3-384, SHA3-512, MD4)");
    println!("  -i, --ip-addr                Extract IP addresses");
    println!("  -6, --ipv6-addr              Extract IPv6 addresses");
    println!("  -m, --mac-addr               Extract MAC addresses");
    println!("  -c, --credit-card            Extract credit card numbers");
    println!("  -u, --url                    Extract urls");
    println!("  -F, --files                  Extract filenames");
    println!("  -b, --bitcoin                Extract bitcoin wallets");
    println!("  -a, --aws                    Extract AWS keys");
    println!("  -g, --google                 Extract Google service account private key ids (used for google automations services)");
    println!("  -d, --dns                    Extract Domain Name System records");
    println!("  -s, --social                 Extract social security numbers");
    println!("  -h, --help                   Print help");
    println!("  -V, --version                Print version");
}
