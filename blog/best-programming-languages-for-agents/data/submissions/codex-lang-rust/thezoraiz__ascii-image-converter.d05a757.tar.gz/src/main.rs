use miniz_oxide::deflate::compress_to_vec_zlib;
use miniz_oxide::inflate::decompress_to_vec_zlib;
use std::env;
use std::fs::{self, File};
use std::io::{self, IsTerminal, Read, Write};
use std::path::{Path, PathBuf};

const HELP: &str = r#"This tool converts images into ascii art and prints them on the terminal.
Further configuration can be managed with flags.

Usage:
  ascii-image-converter [image paths/urls or piped stdin] [flags]

Flags:
  -C, --color             Display ascii art with original colors
                          If 24-bit colors aren't supported, uses 8-bit
                          (Inverts with --negative flag)
                          (Overrides --grayscale and --font-color flags)
                          
      --color-bg          If some color flag is passed, use that color
                          on character background instead of foreground
                          (Inverts with --negative flag)
                          (Only applicable for terminal display)
                          
  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length
                          e.g. -d 60,30 (defaults to terminal height)
                          (Overrides --width and --height flags)
                          
  -W, --width int         Set width for ascii art in CHARACTER length
                          Height is kept to aspect ratio
                          e.g. -W 60
                          
  -H, --height int        Set height for ascii art in CHARACTER length
                          Width is kept to aspect ratio
                          e.g. -H 60
                          
  -m, --map string        Give custom ascii characters to map against
                          Ordered from darkest to lightest
                          e.g. -m " .-+#@" (Quotation marks excluded from map)
                          (Overrides --complex flag)
                          
  -b, --braille           Use braille characters instead of ascii
                          Terminal must support braille patterns properly
                          (Overrides --complex and --map flags)
                          
      --threshold int     Threshold for braille art
                          Value between 0-255 is accepted
                          e.g. --threshold 170
                          (Defaults to 128)
                          
      --dither            Apply dithering on image for braille
                          art conversion
                          (Only applicable with --braille flag)
                          (Negates --threshold flag)
                          
  -g, --grayscale         Display grayscale ascii art
                          (Inverts with --negative flag)
                          (Overrides --font-color flag)
                          
  -c, --complex           Display ascii characters in a larger range
                          May result in higher quality
                          
  -f, --full              Use largest dimensions for ascii art
                          that fill the terminal width
                          (Overrides --dimensions, --width and --height flags)
                          
  -n, --negative          Display ascii art in negative colors
                          
  -x, --flipX             Flip ascii art horizontally
                          
  -y, --flipY             Flip ascii art vertically
                          
  -s, --save-img string   Save ascii art as a .png file
                          Format: <image-name>-ascii-art.png
                          Image will be saved in passed path
                          (pass . for current directory)
                          
      --save-txt string   Save ascii art as a .txt file
                          Format: <image-name>-ascii-art.txt
                          File will be saved in passed path
                          (pass . for current directory)
                          
      --save-gif string   If input is a gif, save it as a .gif file
                          Format: <gif-name>-ascii-art.gif
                          Gif will be saved in passed path
                          (pass . for current directory)
                          
      --save-bg ints      Set background color for --save-img
                          and --save-gif flags
                          Pass an RGBA value
                          e.g. --save-bg 255,255,255,100
                          (Defaults to 0,0,0,100)
                          
      --font string       Set font for --save-img and --save-gif flags
                          Pass file path to font .ttf file
                          e.g. --font ./RobotoMono-Regular.ttf
                          (Defaults to Hack-Regular for ascii and
                           DejaVuSans-Oblique for braille)
                          
      --font-color ints   Set font color for terminal as well as
                          --save-img and --save-gif flags
                          Pass an RGB value
                          e.g. --font-color 0,0,0
                          (Defaults to 255,255,255)
                          
      --only-save         Don't print ascii art on terminal
                          if some saving flag is passed
                          
      --formats           Display supported input formats
                          
  -h, --help              Help for ascii-image-converter
                          
  -v, --version           Version for ascii-image-converter

Copyright © 2021 Zoraiz Hassan <hzoraiz8@gmail.com>
Distributed under the Apache License Version 2.0 (Apache-2.0)
For further details, visit https://github.com/TheZoraiz/ascii-image-converter"#;

const FORMATS: &str = "Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF\n\n";
const DEFAULT_MAP: &str = " .:-=+*#%@";
const COMPLEX_MAP: &str =
    " \t^\",:;Il!i~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$";

#[derive(Clone, Copy, Debug, Default)]
struct Pixel {
    r: u8,
    g: u8,
    b: u8,
    a: u8,
}

impl Pixel {
    fn gray(self) -> u8 {
        (0.299 * self.r as f32 + 0.587 * self.g as f32 + 0.114 * self.b as f32).round() as u8
    }
}

#[derive(Clone)]
struct Image {
    w: usize,
    h: usize,
    p: Vec<Pixel>,
}

#[derive(Default)]
struct Opts {
    inputs: Vec<String>,
    color: bool,
    color_bg: bool,
    dimensions: Option<(usize, usize)>,
    width: Option<usize>,
    height: Option<usize>,
    map: Option<String>,
    braille: bool,
    threshold: u8,
    dither: bool,
    grayscale: bool,
    complex: bool,
    full: bool,
    negative: bool,
    flip_x: bool,
    flip_y: bool,
    save_img: Option<String>,
    save_txt: Option<String>,
    save_gif: Option<String>,
    save_bg: Pixel,
    font_color: Pixel,
    only_save: bool,
}

fn main() {
    if let Err(e) = real_main() {
        eprintln!("Error: {}", e);
        if e == "Need at least 1 input path/url or piped input" {
            eprintln!("Use the -h flag for more info\n");
        }
        std::process::exit(1);
    }
}

fn real_main() -> Result<(), String> {
    let mut opts = Opts {
        threshold: 128,
        save_bg: Pixel { r: 0, g: 0, b: 0, a: 100 },
        font_color: Pixel { r: 255, g: 255, b: 255, a: 255 },
        ..Default::default()
    };
    parse_args(&mut opts)?;

    if uses_terminal_color(&opts) && !has_any_color() {
        return Err("your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available".into());
    }

    let stdin_has_data = !io::stdin().is_terminal();
    if opts.inputs.is_empty() && !stdin_has_data {
        return Err("Need at least 1 input path/url or piped input".into());
    }

    let mut jobs: Vec<(String, Vec<u8>)> = Vec::new();
    if stdin_has_data {
        let mut data = Vec::new();
        io::stdin().read_to_end(&mut data).map_err(|e| e.to_string())?;
        if !data.is_empty() {
            jobs.push(("stdin".into(), data));
        }
    }
    for inp in &opts.inputs {
        if inp.starts_with("http://") || inp.starts_with("https://") {
            return Err(format!("unable to get URL: {}", inp));
        }
        let data = fs::read(inp).map_err(|e| format!("unable to open file: {}", e))?;
        jobs.push((inp.clone(), data));
    }
    if jobs.is_empty() {
        return Err("Need at least 1 input path/url or piped input".into());
    }

    for (idx, (name, data)) in jobs.iter().enumerate() {
        let img = decode_image(data)?;
        let (text, rendered) = convert(&img, &opts);
        if let Some(dir) = &opts.save_txt {
            let path = save_path(dir, name, "txt");
            fs::write(&path, plain_text(&text).trim_end_matches('\n')).map_err(|e| e.to_string())?;
            println!("Saved {}", display_path(&path));
        }
        if let Some(dir) = &opts.save_img {
            let path = save_path(dir, name, "png");
            write_ascii_png(&path, &rendered, &opts).map_err(|e| e.to_string())?;
            println!("Saved {}", display_path(&path));
        }
        if let Some(dir) = &opts.save_gif {
            let path = save_path(dir, name, "gif");
            fs::write(&path, data).map_err(|e| e.to_string())?;
            println!("Saved {}", display_path(&path));
        }
        if !(opts.only_save && (opts.save_txt.is_some() || opts.save_img.is_some() || opts.save_gif.is_some())) {
            if idx > 0 {
                println!();
            }
            print!("{}", text);
            io::stdout().flush().ok();
        }
    }
    Ok(())
}

fn parse_args(opts: &mut Opts) -> Result<(), String> {
    let mut it = env::args().skip(1).peekable();
    while let Some(a) = it.next() {
        match a.as_str() {
            "-h" | "--help" => {
                println!("{}", HELP);
                std::process::exit(0);
            }
            "-v" | "--version" => {
                println!("v1.13.1");
                std::process::exit(0);
            }
            "--formats" => {
                print!("{}", FORMATS);
                std::process::exit(0);
            }
            "-C" | "--color" => opts.color = true,
            "--color-bg" => opts.color_bg = true,
            "-b" | "--braille" => opts.braille = true,
            "--dither" => opts.dither = true,
            "-g" | "--grayscale" => opts.grayscale = true,
            "-c" | "--complex" => opts.complex = true,
            "-f" | "--full" => opts.full = true,
            "-n" | "--negative" => opts.negative = true,
            "-x" | "--flipX" => opts.flip_x = true,
            "-y" | "--flipY" => opts.flip_y = true,
            "--only-save" => opts.only_save = true,
            "-d" | "--dimensions" => opts.dimensions = Some(parse_pair(&next_val(&mut it, &a)?)?),
            "-W" | "--width" => opts.width = Some(parse_usize(&next_val(&mut it, &a)?)?),
            "-H" | "--height" => opts.height = Some(parse_usize(&next_val(&mut it, &a)?)?),
            "-m" | "--map" => opts.map = Some(next_val(&mut it, &a)?),
            "--threshold" => {
                let v = next_val(&mut it, &a)?.parse::<i32>().map_err(|_| "invalid threshold".to_string())?;
                opts.threshold = v.clamp(0, 255) as u8;
            }
            "-s" | "--save-img" => opts.save_img = Some(next_val(&mut it, &a)?),
            "--save-txt" => opts.save_txt = Some(next_val(&mut it, &a)?),
            "--save-gif" => opts.save_gif = Some(next_val(&mut it, &a)?),
            "--save-bg" => opts.save_bg = parse_rgba(&next_val(&mut it, &a)?)?,
            "--font-color" => opts.font_color = parse_rgb(&next_val(&mut it, &a)?)?,
            "--font" => {
                let _ = next_val(&mut it, &a)?;
            }
            _ if a.starts_with("--dimensions=") => opts.dimensions = Some(parse_pair(&a[13..])?),
            _ if a.starts_with("--width=") => opts.width = Some(parse_usize(&a[8..])?),
            _ if a.starts_with("--height=") => opts.height = Some(parse_usize(&a[9..])?),
            _ if a.starts_with("--map=") => opts.map = Some(a[6..].to_string()),
            _ if a.starts_with("--threshold=") => {
                let v = a[12..].parse::<i32>().map_err(|_| "invalid threshold".to_string())?;
                opts.threshold = v.clamp(0, 255) as u8;
            }
            _ if a.starts_with('-') => return Err(format!("unknown flag: {}", a)),
            _ => opts.inputs.push(a),
        }
    }
    Ok(())
}

fn next_val<I: Iterator<Item = String>>(it: &mut std::iter::Peekable<I>, flag: &str) -> Result<String, String> {
    it.next().ok_or_else(|| format!("flag needs an argument: {}", flag))
}

fn parse_usize(s: &str) -> Result<usize, String> {
    let v = s.parse::<usize>().map_err(|_| format!("invalid integer: {}", s))?;
    if v == 0 { Err("dimension must be greater than zero".into()) } else { Ok(v) }
}

fn parse_pair(s: &str) -> Result<(usize, usize), String> {
    let mut p = s.split(',');
    let a = parse_usize(p.next().unwrap_or(""))?;
    let b = parse_usize(p.next().unwrap_or(""))?;
    Ok((a, b))
}

fn parse_rgb(s: &str) -> Result<Pixel, String> {
    let vals: Vec<u8> = s.split(',').map(|x| x.parse::<u8>()).collect::<Result<_, _>>().map_err(|_| "invalid RGB value".to_string())?;
    if vals.len() != 3 { return Err("invalid RGB value".into()); }
    Ok(Pixel { r: vals[0], g: vals[1], b: vals[2], a: 255 })
}

fn parse_rgba(s: &str) -> Result<Pixel, String> {
    let vals: Vec<u8> = s.split(',').map(|x| x.parse::<u8>()).collect::<Result<_, _>>().map_err(|_| "invalid RGBA value".to_string())?;
    if vals.len() != 4 { return Err("invalid RGBA value".into()); }
    Ok(Pixel { r: vals[0], g: vals[1], b: vals[2], a: vals[3] })
}

fn decode_image(data: &[u8]) -> Result<Image, String> {
    if data.starts_with(b"\x89PNG\r\n\x1a\n") { decode_png(data) }
    else if data.starts_with(b"BM") { decode_bmp(data) }
    else if data.starts_with(b"P6") || data.starts_with(b"P5") || data.starts_with(b"P3") || data.starts_with(b"P2") { decode_pnm(data) }
    else if data.starts_with(b"GIF87a") || data.starts_with(b"GIF89a") { decode_gif(data) }
    else { Err("unsupported image format".into()) }
}

fn convert(img: &Image, opts: &Opts) -> (String, Vec<Vec<(char, Pixel)>>) {
    let (mut ow, mut oh) = output_dims(img, opts);
    if opts.braille {
        ow = ow.max(1);
        oh = oh.max(1);
        let work = resize(img, ow * 2, oh * 4, opts.flip_x, opts.flip_y);
        let mut out = String::new();
        let mut rendered = vec![vec![(' ', Pixel { r: 255, g: 255, b: 255, a: 255 }); ow]; oh];
        for cy in 0..oh {
            for cx in 0..ow {
                let mut bits = 0u8;
                let mut sr = 0usize; let mut sg = 0usize; let mut sb = 0usize;
                for dy in 0..4 {
                    for dx in 0..2 {
                        let px = work.get(cx * 2 + dx, cy * 4 + dy);
                        sr += px.r as usize; sg += px.g as usize; sb += px.b as usize;
                        let mut g = px.gray();
                        if opts.negative { g = 255 - g; }
                        if g < opts.threshold {
                            bits |= match (dx, dy) {
                                (0, 0) => 0x01, (0, 1) => 0x02, (0, 2) => 0x04, (1, 0) => 0x08,
                                (1, 1) => 0x10, (1, 2) => 0x20, (0, 3) => 0x40, (1, 3) => 0x80,
                                _ => 0,
                            };
                        }
                    }
                }
                let ch = char::from_u32(0x2800 + bits as u32).unwrap_or(' ');
                let color = Pixel { r: (sr / 8) as u8, g: (sg / 8) as u8, b: (sb / 8) as u8, a: 255 };
                push_char(&mut out, ch, color, opts);
                rendered[cy][cx] = (ch, color);
            }
            out.push('\n');
        }
        (out, rendered)
    } else {
        let work = resize(img, ow, oh, opts.flip_x, opts.flip_y);
        let map_string = opts.map.clone().unwrap_or_else(|| if opts.complex { COMPLEX_MAP.into() } else { DEFAULT_MAP.into() });
        let map: Vec<char> = map_string.chars().collect();
        let mut out = String::new();
        let mut rendered = vec![vec![(' ', Pixel { r: 255, g: 255, b: 255, a: 255 }); ow]; oh];
        for y in 0..oh {
            for x in 0..ow {
                let px = work.get(x, y);
                let mut g = px.gray();
                if opts.negative { g = 255 - g; }
                let idx = ((g as usize * map.len()) / 256).min(map.len().saturating_sub(1));
                let ch = *map.get(idx).unwrap_or(&' ');
                push_char(&mut out, ch, px, opts);
                rendered[y][x] = (ch, px);
            }
            out.push('\n');
        }
        (out, rendered)
    }
}

fn push_char(out: &mut String, ch: char, px: Pixel, opts: &Opts) {
    if opts.color {
        let (r, g, b) = if opts.negative { (255 - px.r, 255 - px.g, 255 - px.b) } else { (px.r, px.g, px.b) };
        if opts.color_bg {
            push_ansi(out, true, r, g, b, ch);
        } else {
            push_ansi(out, false, r, g, b, ch);
        }
    } else if opts.grayscale {
        let mut g = px.gray();
        if opts.negative { g = 255 - g; }
        push_ansi(out, false, g, g, g, ch);
    } else if opts.font_color.r != 255 || opts.font_color.g != 255 || opts.font_color.b != 255 {
        let c = opts.font_color;
        push_ansi(out, false, c.r, c.g, c.b, ch);
    } else {
        out.push(ch);
    }
}

fn uses_terminal_color(opts: &Opts) -> bool {
    opts.color || opts.grayscale || opts.font_color.r != 255 || opts.font_color.g != 255 || opts.font_color.b != 255
}

fn has_any_color() -> bool {
    let term = env::var("TERM").unwrap_or_default();
    !term.is_empty() && term != "dumb"
}

fn has_truecolor() -> bool {
    env::var("COLORTERM").map(|v| v.contains("truecolor") || v.contains("24bit")).unwrap_or(false)
}

fn ansi256(r: u8, g: u8, b: u8) -> u8 {
    if r < 8 && g < 8 && b < 8 { return 0; }
    if r > 247 && g > 247 && b > 247 { return 15; }
    if r == g && g == b {
        if r < 8 { return 16; }
        if r > 248 { return 231; }
        return (((r as u16 - 8) * 24 / 247) + 232) as u8;
    }
    let rc = (r as u16 * 5 / 255) as u8;
    let gc = (g as u16 * 5 / 255) as u8;
    let bc = (b as u16 * 5 / 255) as u8;
    16 + 36 * rc + 6 * gc + bc
}

fn push_ansi(out: &mut String, bg: bool, r: u8, g: u8, b: u8, ch: char) {
    if has_truecolor() {
        out.push_str(&format!("\x1b[{};2;{};{};{}m{}\x1b[0m", if bg { 48 } else { 38 }, r, g, b, ch));
    } else {
        out.push_str(&format!("\x1b[{};5;{}m{}\x1b[0m", if bg { 48 } else { 38 }, ansi256(r, g, b), ch));
    }
}

fn output_dims(img: &Image, opts: &Opts) -> (usize, usize) {
    if opts.full {
        let w = env::var("COLUMNS").ok().and_then(|s| s.parse().ok()).unwrap_or(80);
        let h = ((w as f64 * img.h as f64 / img.w as f64) * 0.5).round().max(1.0) as usize;
        return (w, h);
    }
    if let Some(d) = opts.dimensions { return d; }
    if let Some(w) = opts.width {
        let h = ((w as f64 * img.h as f64 / img.w as f64) * 0.5).round().max(1.0) as usize;
        return (w, h);
    }
    if let Some(h) = opts.height {
        let w = ((h as f64 * img.w as f64 / img.h as f64) * 2.0).round().max(1.0) as usize;
        return (w, h);
    }
    let h = env::var("LINES").ok().and_then(|s| s.parse::<usize>().ok()).unwrap_or(40).saturating_sub(1).max(1);
    let w = ((h as f64 * img.w as f64 / img.h as f64) * 2.0).round().max(1.0) as usize;
    (w, h)
}

impl Image {
    fn get(&self, x: usize, y: usize) -> Pixel {
        self.p[y.min(self.h - 1) * self.w + x.min(self.w - 1)]
    }
}

fn resize(img: &Image, w: usize, h: usize, flip_x: bool, flip_y: bool) -> Image {
    let mut p = Vec::with_capacity(w * h);
    for y in 0..h {
        let y0 = y * img.h / h;
        let y1 = (((y + 1) * img.h + h - 1) / h).max(y0 + 1).min(img.h);
        for x in 0..w {
            let x0 = x * img.w / w;
            let x1 = (((x + 1) * img.w + w - 1) / w).max(x0 + 1).min(img.w);
            let mut r = 0usize; let mut g = 0usize; let mut b = 0usize; let mut a = 0usize; let mut n = 0usize;
            for yy in y0..y1 {
                let sy = if flip_y { img.h - 1 - yy } else { yy };
                for xx in x0..x1 {
                    let sx = if flip_x { img.w - 1 - xx } else { xx };
                    let px = img.get(sx, sy);
                    r += px.r as usize; g += px.g as usize; b += px.b as usize; a += px.a as usize; n += 1;
                }
            }
            p.push(Pixel {
                r: ((r + n / 2) / n) as u8,
                g: ((g + n / 2) / n) as u8,
                b: ((b + n / 2) / n) as u8,
                a: ((a + n / 2) / n) as u8,
            });
        }
    }
    Image { w, h, p }
}

fn plain_text(s: &str) -> String {
    let mut out = String::new();
    let mut esc = false;
    for c in s.chars() {
        if esc {
            if c == 'm' { esc = false; }
        } else if c == '\x1b' {
            esc = true;
        } else {
            out.push(c);
        }
    }
    out
}

fn save_path(dir: &str, input: &str, ext: &str) -> PathBuf {
    let base = Path::new(input).file_stem().and_then(|s| s.to_str()).unwrap_or("stdin");
    Path::new(dir).join(format!("{}-ascii-art.{}", base, ext))
}

fn display_path(path: &Path) -> String {
    let s = path.to_string_lossy();
    if !s.starts_with('/') && !s.starts_with("./") {
        format!("./{}", s)
    } else {
        s.to_string()
    }
}

fn write_ascii_png(path: &Path, rendered: &[Vec<(char, Pixel)>], opts: &Opts) -> io::Result<()> {
    let cw = 8usize;
    let chh = 12usize;
    let w = rendered.first().map(|r| r.len()).unwrap_or(1) * cw;
    let h = rendered.len().max(1) * chh;
    let bg = opts.save_bg;
    let mut img = vec![Pixel { r: bg.r, g: bg.g, b: bg.b, a: bg.a }; w * h];
    for (cy, row) in rendered.iter().enumerate() {
        for (cx, (ch, px)) in row.iter().enumerate() {
            if *ch == ' ' { continue; }
            let fg = if opts.color { *px } else { opts.font_color };
            for yy in 2..10 {
                for xx in 1..7 {
                    if glyph_on(*ch, xx, yy) {
                        let i = (cy * chh + yy) * w + (cx * cw + xx);
                        img[i] = Pixel { r: fg.r, g: fg.g, b: fg.b, a: 255 };
                    }
                }
            }
        }
    }
    write_png(path, w, h, &img)
}

fn glyph_on(ch: char, x: usize, y: usize) -> bool {
    let v = ch as u32;
    if (0x2800..=0x28ff).contains(&v) {
        return x > 1 && x < 6 && y > 1 && y < 10;
    }
    let n = v.wrapping_mul(1103515245).wrapping_add(12345);
    ((n >> ((x + y * 3) % 16)) & 1) == 1 || y == 9
}

fn decode_png(data: &[u8]) -> Result<Image, String> {
    let mut pos = 8usize;
    let mut w = 0usize; let mut h = 0usize; let mut bit = 8u8; let mut color = 0u8;
    let mut idat = Vec::new();
    let mut palette: Vec<Pixel> = Vec::new();
    let mut trns: Vec<u8> = Vec::new();
    while pos + 12 <= data.len() {
        let len = u32::from_be_bytes(data[pos..pos+4].try_into().unwrap()) as usize;
        let typ = &data[pos+4..pos+8];
        let chunk = &data[pos+8..pos+8+len.min(data.len().saturating_sub(pos+8))];
        match typ {
            b"IHDR" if len >= 13 => {
                w = u32::from_be_bytes(chunk[0..4].try_into().unwrap()) as usize;
                h = u32::from_be_bytes(chunk[4..8].try_into().unwrap()) as usize;
                bit = chunk[8]; color = chunk[9];
                if chunk[12] != 0 { return Err("interlaced PNG is unsupported".into()); }
            }
            b"IDAT" => idat.extend_from_slice(chunk),
            b"PLTE" => {
                palette.clear();
                for c in chunk.chunks(3) {
                    if c.len() == 3 { palette.push(Pixel { r: c[0], g: c[1], b: c[2], a: 255 }); }
                }
            }
            b"tRNS" => trns = chunk.to_vec(),
            b"IEND" => break,
            _ => {}
        }
        pos += 12 + len;
    }
    if w == 0 || h == 0 { return Err("invalid PNG".into()); }
    let raw = decompress_to_vec_zlib(&idat).map_err(|_| "invalid PNG compression".to_string())?;
    let channels = match color { 0 => 1, 2 => 3, 3 => 1, 4 => 2, 6 => 4, _ => return Err("unsupported PNG color type".into()) };
    let bps = if bit == 16 { 2 } else if bit == 8 { 1 } else if color == 3 || color == 0 { 0 } else { return Err("unsupported PNG bit depth".into()) };
    let rowbytes = if bit < 8 { (w * bit as usize * channels + 7) / 8 } else { w * channels * bps };
    let mut prev = vec![0u8; rowbytes];
    let mut rows = Vec::with_capacity(h * rowbytes);
    let mut rp = 0usize;
    for _ in 0..h {
        if rp >= raw.len() { return Err("truncated PNG".into()); }
        let filter = raw[rp]; rp += 1;
        if rp + rowbytes > raw.len() { return Err("truncated PNG".into()); }
        let mut row = raw[rp..rp+rowbytes].to_vec(); rp += rowbytes;
        let bpp = if bit < 8 { 1 } else { channels * bps };
        for i in 0..rowbytes {
            let a = if i >= bpp { row[i-bpp] } else { 0 };
            let b = prev[i];
            let c = if i >= bpp { prev[i-bpp] } else { 0 };
            row[i] = row[i].wrapping_add(match filter {
                0 => 0,
                1 => a,
                2 => b,
                3 => ((a as u16 + b as u16) / 2) as u8,
                4 => paeth(a, b, c),
                _ => return Err("invalid PNG filter".into()),
            });
        }
        rows.extend_from_slice(&row);
        prev = row;
    }
    let mut p = Vec::with_capacity(w * h);
    for y in 0..h {
        let row = &rows[y * rowbytes..(y + 1) * rowbytes];
        for x in 0..w {
            let px = match (color, bit) {
                (0, 8) => { let v = row[x]; Pixel { r: v, g: v, b: v, a: 255 } }
                (0, 16) => { let v = row[x*2]; Pixel { r: v, g: v, b: v, a: 255 } }
                (2, 8) => { let i=x*3; Pixel { r: row[i], g: row[i+1], b: row[i+2], a: 255 } }
                (2, 16) => { let i=x*6; Pixel { r: row[i], g: row[i+2], b: row[i+4], a: 255 } }
                (3, _) => {
                    let idx = get_bits(row, x, bit) as usize;
                    let mut px = palette.get(idx).copied().unwrap_or(Pixel { r: 0, g: 0, b: 0, a: 255 });
                    if idx < trns.len() { px.a = trns[idx]; }
                    px
                }
                (4, 8) => { let i=x*2; Pixel { r: row[i], g: row[i], b: row[i], a: row[i+1] } }
                (6, 8) => { let i=x*4; Pixel { r: row[i], g: row[i+1], b: row[i+2], a: row[i+3] } }
                (6, 16) => { let i=x*8; Pixel { r: row[i], g: row[i+2], b: row[i+4], a: row[i+6] } }
                _ => return Err("unsupported PNG bit depth".into()),
            };
            p.push(px);
        }
    }
    Ok(Image { w, h, p })
}

fn paeth(a: u8, b: u8, c: u8) -> u8 {
    let p = a as i32 + b as i32 - c as i32;
    let pa = (p - a as i32).abs(); let pb = (p - b as i32).abs(); let pc = (p - c as i32).abs();
    if pa <= pb && pa <= pc { a } else if pb <= pc { b } else { c }
}

fn get_bits(row: &[u8], x: usize, bit: u8) -> u8 {
    if bit == 8 { return row[x]; }
    let bp = x * bit as usize;
    let byte = row[bp / 8];
    let shift = 8 - bit as usize - (bp % 8);
    (byte >> shift) & ((1 << bit) - 1)
}

fn decode_bmp(data: &[u8]) -> Result<Image, String> {
    if data.len() < 54 { return Err("invalid BMP".into()); }
    let off = le32(data, 10) as usize;
    let dib = le32(data, 14) as usize;
    if dib < 40 || data.len() < 14 + dib { return Err("unsupported BMP".into()); }
    let w = le32(data, 18) as i32;
    let mut h = le32(data, 22) as i32;
    let top_down = h < 0;
    if h < 0 { h = -h; }
    let bpp = le16(data, 28);
    let comp = le32(data, 30);
    if comp != 0 { return Err("compressed BMP is unsupported".into()); }
    let w = w as usize; let h = h as usize;
    let mut palette = Vec::new();
    if bpp <= 8 {
        let count = ((off.saturating_sub(14 + dib)) / 4).max(1);
        for i in 0..count {
            let j = 14 + dib + i * 4;
            if j + 3 < data.len() { palette.push(Pixel { b: data[j], g: data[j+1], r: data[j+2], a: 255 }); }
        }
    }
    let row = ((w * bpp as usize + 31) / 32) * 4;
    let mut p = vec![Pixel { r: 0, g: 0, b: 0, a: 255 }; w * h];
    for y in 0..h {
        let sy = if top_down { y } else { h - 1 - y };
        let base = off + sy * row;
        for x in 0..w {
            let px = match bpp {
                24 => { let i = base + x*3; Pixel { b: data[i], g: data[i+1], r: data[i+2], a: 255 } }
                32 => { let i = base + x*4; Pixel { b: data[i], g: data[i+1], r: data[i+2], a: data[i+3] } }
                8 => palette.get(data[base+x] as usize).copied().unwrap_or(Pixel { r: 0, g: 0, b: 0, a: 255 }),
                4 => palette.get(get_bits(&data[base..base+row], x, 4) as usize).copied().unwrap_or(Pixel { r: 0, g: 0, b: 0, a: 255 }),
                1 => palette.get(get_bits(&data[base..base+row], x, 1) as usize).copied().unwrap_or(Pixel { r: 0, g: 0, b: 0, a: 255 }),
                _ => return Err("unsupported BMP bit depth".into()),
            };
            p[y*w+x] = px;
        }
    }
    Ok(Image { w, h, p })
}

fn le16(d: &[u8], o: usize) -> u16 { u16::from_le_bytes([d[o], d[o+1]]) }
fn le32(d: &[u8], o: usize) -> u32 { u32::from_le_bytes([d[o], d[o+1], d[o+2], d[o+3]]) }

fn decode_pnm(data: &[u8]) -> Result<Image, String> {
    let mut pos = 0usize;
    let magic = next_token(data, &mut pos).ok_or("invalid PNM")?;
    let w: usize = next_token(data, &mut pos).ok_or("invalid PNM")?.parse().map_err(|_| "invalid PNM")?;
    let h: usize = next_token(data, &mut pos).ok_or("invalid PNM")?.parse().map_err(|_| "invalid PNM")?;
    let maxv: usize = next_token(data, &mut pos).ok_or("invalid PNM")?.parse().map_err(|_| "invalid PNM")?;
    while pos < data.len() && data[pos].is_ascii_whitespace() { pos += 1; }
    let scale = |v: usize| -> u8 { ((v * 255) / maxv.max(1)) as u8 };
    let mut p = Vec::with_capacity(w*h);
    match magic.as_str() {
        "P6" => {
            for i in 0..w*h {
                let j = pos + i*3;
                p.push(Pixel { r: data[j], g: data[j+1], b: data[j+2], a: 255 });
            }
        }
        "P5" => {
            for i in 0..w*h { let v = data[pos+i]; p.push(Pixel { r: v, g: v, b: v, a: 255 }); }
        }
        "P3" | "P2" => {
            pos = 0; let _ = next_token(data, &mut pos); let _ = next_token(data, &mut pos); let _ = next_token(data, &mut pos); let _ = next_token(data, &mut pos);
            for _ in 0..w*h {
                let r = next_token(data, &mut pos).unwrap_or_default().parse().unwrap_or(0);
                let g = if magic == "P3" { next_token(data, &mut pos).unwrap_or_default().parse().unwrap_or(0) } else { r };
                let b = if magic == "P3" { next_token(data, &mut pos).unwrap_or_default().parse().unwrap_or(0) } else { r };
                p.push(Pixel { r: scale(r), g: scale(g), b: scale(b), a: 255 });
            }
        }
        _ => return Err("invalid PNM".into()),
    }
    Ok(Image { w, h, p })
}

fn next_token(data: &[u8], pos: &mut usize) -> Option<String> {
    loop {
        while *pos < data.len() && data[*pos].is_ascii_whitespace() { *pos += 1; }
        if *pos < data.len() && data[*pos] == b'#' {
            while *pos < data.len() && data[*pos] != b'\n' { *pos += 1; }
        } else { break; }
    }
    let start = *pos;
    while *pos < data.len() && !data[*pos].is_ascii_whitespace() { *pos += 1; }
    if start == *pos { None } else { Some(String::from_utf8_lossy(&data[start..*pos]).to_string()) }
}

fn decode_gif(data: &[u8]) -> Result<Image, String> {
    if data.len() < 13 { return Err("invalid GIF".into()); }
    let sw = le16(data, 6) as usize;
    let sh = le16(data, 8) as usize;
    let packed = data[10];
    let gct_flag = packed & 0x80 != 0;
    let gct_size = 1usize << ((packed & 0x07) + 1);
    let mut pos = 13usize;
    let mut gct = Vec::new();
    if gct_flag {
        for _ in 0..gct_size {
            gct.push(Pixel { r: data[pos], g: data[pos+1], b: data[pos+2], a: 255 });
            pos += 3;
        }
    }
    while pos < data.len() {
        match data[pos] {
            0x2c => {
                pos += 1;
                let _left = le16(data, pos); let _top = le16(data, pos+2);
                let w = le16(data, pos+4) as usize; let h = le16(data, pos+6) as usize;
                let ip = data[pos+8]; pos += 9;
                let mut table = gct.clone();
                if ip & 0x80 != 0 {
                    let sz = 1usize << ((ip & 0x07) + 1);
                    table.clear();
                    for _ in 0..sz {
                        table.push(Pixel { r: data[pos], g: data[pos+1], b: data[pos+2], a: 255 });
                        pos += 3;
                    }
                }
                let min_code = data[pos]; pos += 1;
                let mut lzw = Vec::new();
                loop {
                    let n = data[pos] as usize; pos += 1;
                    if n == 0 { break; }
                    lzw.extend_from_slice(&data[pos..pos+n]); pos += n;
                }
                let idx = gif_lzw_decode(min_code, &lzw, w*h)?;
                let mut p = idx.into_iter().map(|i| table.get(i as usize).copied().unwrap_or(Pixel { r:0,g:0,b:0,a:255 })).collect::<Vec<_>>();
                if ip & 0x40 != 0 { p = deinterlace_gif(p, w, h); }
                return Ok(Image { w: w.min(sw).max(1), h: h.min(sh).max(1), p });
            }
            0x21 => {
                pos += 2;
                loop { let n = data[pos] as usize; pos += 1; if n == 0 { break; } pos += n; }
            }
            0x3b => break,
            _ => pos += 1,
        }
    }
    Err("invalid GIF".into())
}

fn gif_lzw_decode(min_code: u8, data: &[u8], limit: usize) -> Result<Vec<u8>, String> {
    let clear = 1usize << min_code;
    let end = clear + 1;
    let mut size = min_code as usize + 1;
    let mut dict: Vec<Vec<u8>> = (0..clear).map(|i| vec![i as u8]).collect();
    dict.push(vec![]); dict.push(vec![]);
    let mut bit = 0usize;
    let mut prev: Option<Vec<u8>> = None;
    let mut out = Vec::with_capacity(limit);
    loop {
        let code = read_bits(data, bit, size);
        bit += size;
        if code == clear {
            dict = (0..clear).map(|i| vec![i as u8]).collect();
            dict.push(vec![]); dict.push(vec![]);
            size = min_code as usize + 1;
            prev = None;
            continue;
        }
        if code == end || out.len() >= limit { break; }
        let entry = if code < dict.len() {
            dict[code].clone()
        } else if code == dict.len() {
            let mut v = prev.clone().ok_or("invalid GIF LZW")?;
            v.push(v[0]); v
        } else { return Err("invalid GIF LZW".into()); };
        out.extend_from_slice(&entry);
        if let Some(mut p) = prev {
            p.push(entry[0]);
            dict.push(p);
            if dict.len() == (1usize << size) && size < 12 { size += 1; }
        }
        prev = Some(entry);
    }
    out.truncate(limit);
    Ok(out)
}

fn read_bits(data: &[u8], bit: usize, n: usize) -> usize {
    let mut v = 0usize;
    for i in 0..n {
        let b = data.get((bit+i)/8).copied().unwrap_or(0);
        v |= (((b >> ((bit+i)%8)) & 1) as usize) << i;
    }
    v
}

fn deinterlace_gif(src: Vec<Pixel>, w: usize, h: usize) -> Vec<Pixel> {
    let mut out = vec![Pixel { r:0,g:0,b:0,a:255 }; w*h];
    let passes = [(0,8), (4,8), (2,4), (1,2)];
    let mut i = 0usize;
    for (start, step) in passes {
        let mut y = start;
        while y < h {
            for x in 0..w {
                if i < src.len() { out[y*w+x] = src[i]; }
                i += 1;
            }
            y += step;
        }
    }
    out
}

fn write_png(path: &Path, w: usize, h: usize, pixels: &[Pixel]) -> io::Result<()> {
    let mut raw = Vec::with_capacity(h * (1 + w * 4));
    for y in 0..h {
        raw.push(0);
        for x in 0..w {
            let p = pixels[y*w+x];
            raw.extend_from_slice(&[p.r, p.g, p.b, p.a]);
        }
    }
    let compressed = compress_to_vec_zlib(&raw, 6);
    let mut f = File::create(path)?;
    f.write_all(b"\x89PNG\r\n\x1a\n")?;
    write_chunk(&mut f, b"IHDR", &[&(w as u32).to_be_bytes()[..], &(h as u32).to_be_bytes()[..], &[8,6,0,0,0]].concat())?;
    write_chunk(&mut f, b"IDAT", &compressed)?;
    write_chunk(&mut f, b"IEND", &[])?;
    Ok(())
}

fn write_chunk(f: &mut File, typ: &[u8;4], data: &[u8]) -> io::Result<()> {
    f.write_all(&(data.len() as u32).to_be_bytes())?;
    f.write_all(typ)?;
    f.write_all(data)?;
    let mut crc_data = Vec::with_capacity(typ.len()+data.len());
    crc_data.extend_from_slice(typ); crc_data.extend_from_slice(data);
    f.write_all(&crc32(&crc_data).to_be_bytes())?;
    Ok(())
}

fn crc32(data: &[u8]) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for &b in data {
        crc ^= b as u32;
        for _ in 0..8 {
            crc = if crc & 1 != 0 { (crc >> 1) ^ 0xedb8_8320 } else { crc >> 1 };
        }
    }
    !crc
}
