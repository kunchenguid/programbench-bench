use std::env;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20";
const WARNING: &str = "WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.";

fn main() {
    let raw: Vec<String> = env::args().skip(1).collect();
    let args = strip_config(raw);
    let code = dispatch(&args);
    process::exit(code);
}

fn strip_config(args: Vec<String>) -> Vec<String> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < args.len() {
        if args[i] == "--config" {
            i += 2;
        } else if args[i].starts_with("--config=") {
            i += 1;
        } else {
            out.push(args[i].clone());
            i += 1;
        }
    }
    out
}

fn dispatch(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "--version") {
        println!("{}", VERSION);
        return 0;
    }
    if args.iter().any(|a| a == "--drivers") {
        print_drivers(None);
        return 0;
    }
    if args.iter().any(|a| a == "--json-usage") {
        print_json_usage(args);
        return 0;
    }
    if args.is_empty() {
        eprintln!("ERROR 1: gdal: Missing command name.");
        print_main_usage(false);
        return 1;
    }
    if is_help(args) {
        print_main_usage(true);
        return 0;
    }
    match args[0].as_str() {
        "convert" => command_convert(&args[1..]),
        "info" => command_info(&args[1..], "gdal info"),
        "dataset" => command_dataset(&args[1..]),
        "driver" => command_driver(&args[1..]),
        "mdim" => command_group("mdim", &args[1..], mdim_help()),
        "pipeline" => command_pipeline(&args[1..]),
        "raster" => command_raster(&args[1..]),
        "vector" => command_vector(&args[1..]),
        "vsi" => command_vsi(&args[1..]),
        other if !other.starts_with('-') && Path::new(other).exists() => command_info(args, "gdal info"),
        other if other.starts_with('-') => {
            eprintln!("ERROR 5: gdal: Option '{}' is unknown.", other);
            print_main_usage(false);
            1
        }
        other => {
            eprintln!("ERROR 1: gdal: Unknown command: '{}'", other);
            print_main_usage(false);
            1
        }
    }
}

fn is_help(args: &[String]) -> bool {
    args.iter().any(|a| a == "--help" || a == "-h")
}

fn command_group(name: &str, args: &[String], help: &str) -> i32 {
    if args.iter().any(|a| a == "--drivers") {
        print_drivers(Some(name));
        return 0;
    }
    if args.is_empty() {
        eprintln!("ERROR 1: {}: Missing command name.", name);
        print!("{}", help.replace("\nWARNING:", "\nTry 'gdal --help' for help.\n\nWARNING:"));
        return 1;
    }
    if is_help(args) {
        print!("{}", help);
        return 0;
    }
    eprintln!("ERROR 1: {}: Unknown command: '{}'", name, args[0]);
    println!("Usage: gdal {} <SUBCOMMAND> [OPTIONS]", name);
    println!("Try 'gdal {} --help' for help.", name);
    1
}

fn print_main_usage(full: bool) {
    println!("Usage: gdal <COMMAND> [OPTIONS]");
    println!("where <COMMAND> is one of:");
    println!("  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').");
    println!("  - dataset:  Commands to manage datasets.");
    println!("  - driver:   Command for driver specific operations.");
    println!("  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').");
    println!("  - mdim:     Multidimensional commands.");
    println!("  - pipeline: Process a dataset applying several steps.");
    println!("  - raster:   Raster commands.");
    println!("  - vector:   Vector commands.");
    println!("  - vsi:      GDAL Virtual System Interface (VSI) commands.");
    println!();
    if !full {
        println!("Try 'gdal --help' for help.");
        println!();
    } else {
        println!("Common Options:");
        println!("  -h, --help              Display help message and exit");
        println!("  --json-usage            Display usage as JSON document and exit");
        println!("  --config <KEY>=<VALUE>  Configuration option [may be repeated]");
        println!();
        println!("Options:");
        println!("  --version               Display GDAL version and exit");
        println!("  --drivers               Display driver list as JSON document");
        println!();
    }
    println!("'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.");
    println!("And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.");
    println!();
    println!("For more details, consult https://gdal.org/programs/index.html");
    println!();
    println!("{}", WARNING);
}

fn dataset_help() -> &'static str {
    "Usage: gdal dataset <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - check:    Check whether there are errors when reading the content of a dataset.\n  - copy:     Copy files of a dataset. (alias: cp)\n  - delete:   Delete dataset(s). (alias: rm, remove)\n  - identify: Identify driver opening dataset(s).\n  - rename:   Rename files of a dataset. (alias: ren, mv)\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_dataset.html\n\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.\n"
}

fn mdim_help() -> &'static str {
    "Usage: gdal mdim <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - convert: Convert a multidimensional dataset.\n  - info:    Return information on a multidimensional dataset.\n  - mosaic:  Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --drivers               Display multidimensional driver list as JSON document\n\nFor more details, consult https://gdal.org/programs/gdal_mdim.html\n\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.\n"
}

fn driver_help() -> &'static str {
    "Usage: gdal driver <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - cog: Command for COG driver specific operations.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.\n"
}

fn raster_help() -> &'static str {
    "Usage: gdal raster <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - as-features:     Create features from pixels of a raster dataset\n  - aspect:          Generate an aspect map\n  - blend:           Blend/compose two raster datasets\n  - calc:            Perform raster algebra\n  - clean-collar:    Clean the collar of a raster dataset, removing noise.\n  - clip:            Clip a raster dataset.\n  - color-map:       Generate a RGB or RGBA dataset from a single band, using a color map\n  - compare:         Compare two raster datasets.\n  - contour:         Creates a vector contour from a raster elevation model (DEM).\n  - convert:         Convert a raster dataset.\n  - create:          Create a new raster dataset.\n  - edit:            Edit a raster dataset.\n  - fill-nodata:     Fill nodata raster regions by interpolation from edges.\n  - footprint:       Compute the footprint of a raster dataset.\n  - hillshade:       Generate a shaded relief map\n  - index:           Create a vector index of raster datasets.\n  - info:            Return information on a raster dataset.\n  - mosaic:          Build a mosaic, either virtual (VRT) or materialized.\n  - neighbors:       Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)\n  - nodata-to-alpha: Replace nodata value(s) with an alpha band.\n  - overview:        Manage overviews of a raster dataset.\n  - pansharpen:      Perform a pansharpen operation.\n  - pipeline:        Process a raster dataset applying several steps.\n  - pixel-info:      Return information on a pixel of a raster dataset.\n  - polygonize:      Create a polygon feature dataset from a raster band.\n  - proximity:       Produces a raster proximity map.\n  - reclassify:      Reclassify values in a raster dataset\n  - reproject:       Reproject a raster dataset.\n  - resize:          Resize a raster dataset without changing the georeferenced extents.\n  - rgb-to-palette:  Convert a RGB image into a pseudo-color / paletted image.\n  - roughness:       Generate a roughness map\n  - scale:           Scale the values of the bands of a raster dataset.\n  - select:          Select a subset of bands from a raster dataset.\n  - set-type:        Modify the data type of bands of a raster dataset.\n  - sieve:           Remove small polygons from a raster dataset.\n  - slope:           Generate a slope map\n  - stack:           Combine together input bands into a multi-band output, either virtual (VRT) or materialized.\n  - tile:            Generate tiles in separate files from a raster dataset.\n  - tpi:             Generate a Topographic Position Index (TPI) map\n  - tri:             Generate a Terrain Ruggedness Index (TRI) map\n  - unscale:         Convert scaled values of a raster dataset into unscaled values.\n  - update:          Update the destination raster with the content of the input one.\n  - viewshed:        Compute the viewshed of a raster dataset.\n  - zonal-stats:     Calculate raster zonal statistics\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --drivers               Display raster driver list as JSON document\n\nFor more details, consult https://gdal.org/programs/gdal_raster.html\n\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.\n"
}

fn vector_help() -> &'static str {
    "Usage: gdal vector <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - buffer:              Compute a buffer around geometries of a vector dataset.\n  - check-coverage:      Check a polygon coverage for validity\n  - check-geometry:      Check a dataset for invalid geometries\n  - clean-coverage:      Alter polygon boundaries to make shared edges identical, removing gaps and overlaps\n  - clip:                Clip a vector dataset.\n  - combine:             Combine features into collections\n  - concat:              Concatenate vector datasets.\n  - concave-hull:        Compute the concave hull of geometries of a vector dataset.\n  - convert:             Convert a vector dataset.\n  - convex-hull:         Compute the convex hull of geometries of a vector dataset.\n  - create:              Create a vector dataset.\n  - dissolve:            Dissolves multipart features\n  - edit:                Edit metadata of a vector dataset.\n  - explode-collections: Explode geometries of type collection of a vector dataset.\n  - export-schema:       Export the OGR_SCHEMA from a vector dataset.\n  - filter:              Filter a vector dataset.\n  - grid:                Create a regular grid from scattered points.\n  - index:               Create a vector index of vector datasets.\n  - info:                Return information on a vector dataset.\n  - layer-algebra:       Perform algebraic operation between 2 layers.\n  - make-point:          Create point geometries from attribute fields\n  - make-valid:          Fix validity of geometries of a vector dataset.\n  - partition:           Partition a vector dataset into multiple files.\n  - pipeline:            Process a vector dataset applying several steps.\n  - rasterize:           Burns vector geometries into a raster.\n  - rename-layer:        Rename layer(s) of a vector dataset.\n  - reproject:           Reproject a vector dataset.\n  - segmentize:          Segmentize geometries of a vector dataset.\n  - select:              Select a subset of fields from a vector dataset.\n  - set-field-type:      Modify the type of a field of a vector dataset.\n  - set-geom-type:       Modify the geometry type of a vector dataset.\n  - simplify:            Simplify geometries of a vector dataset.\n  - simplify-coverage:   Simplify shared boundaries of a polygonal vector dataset.\n  - sort:                Spatially order the features in a layer\n  - sql:                 Apply SQL statement(s) to a dataset.\n  - swap-xy:             Swap X and Y coordinates of geometries of a vector dataset.\n  - update:              Update an existing vector dataset with an input vector dataset.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --drivers               Display vector driver list as JSON document and exit\n\nFor more details, consult https://gdal.org/programs/gdal_vector.html\n\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.\n"
}

fn vsi_help() -> &'static str {
    "Usage: gdal vsi <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)\n  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)\n  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)\n  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)\n  - sozip:  Seek-optimized ZIP (SOZIP) commands.\n  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_vsi.html\n\nWARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\nThe project reserves the right to modify, rename, reorganize, and change the behavior of the utility\nuntil it is officially frozen in a future feature release of GDAL.\n"
}

fn command_dataset(args: &[String]) -> i32 {
    if args.is_empty() || is_help(args) {
        print!("{}", dataset_help());
        return if args.is_empty() { 1 } else { 0 };
    }
    match args[0].as_str() {
        "copy" | "cp" => file_copy(&args[1..], false, "gdal dataset copy [OPTIONS] <SOURCE> <DESTINATION>"),
        "rename" | "ren" | "mv" => file_move(&args[1..], "gdal dataset rename [OPTIONS] <SOURCE> <DESTINATION>"),
        "delete" | "rm" | "remove" => file_delete(&args[1..], "gdal dataset delete [OPTIONS] <FILENAME>"),
        "identify" => dataset_identify(&args[1..]),
        "check" => dataset_check(&args[1..]),
        other => unknown_sub("dataset", other),
    }
}

fn command_driver(args: &[String]) -> i32 {
    if args.is_empty() || is_help(args) {
        print!("{}", driver_help());
        return if args.is_empty() { 1 } else { 0 };
    }
    if args[0] == "cog" {
        println!("Usage: gdal driver cog <SUBCOMMAND> [OPTIONS]");
        println!("where <SUBCOMMAND> is one of:");
        println!("  - validate: Validate a Cloud Optimized GeoTIFF.");
        println!("\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n");
        println!("{}", WARNING);
        0
    } else {
        unknown_sub("driver", &args[0])
    }
}

fn command_raster(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "--drivers") {
        print_drivers(Some("raster"));
        return 0;
    }
    if args.is_empty() || is_help(args) {
        print!("{}", raster_help());
        return if args.is_empty() { 1 } else { 0 };
    }
    match args[0].as_str() {
        "info" => command_info(&args[1..], "gdal raster info"),
        "convert" | "update" => command_convert(&args[1..]),
        "create" => command_create(&args[1..]),
        name => generic_algorithm_help_or_error("raster", name, &args[1..]),
    }
}

fn command_vector(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "--drivers") {
        print_drivers(Some("vector"));
        return 0;
    }
    if args.is_empty() || is_help(args) {
        print!("{}", vector_help());
        return if args.is_empty() { 1 } else { 0 };
    }
    match args[0].as_str() {
        "info" => command_info(&args[1..], "gdal vector info"),
        "convert" | "update" => command_convert(&args[1..]),
        "create" => command_create(&args[1..]),
        name => generic_algorithm_help_or_error("vector", name, &args[1..]),
    }
}

fn command_vsi(args: &[String]) -> i32 {
    if args.is_empty() || is_help(args) {
        print!("{}", vsi_help());
        return if args.is_empty() { 1 } else { 0 };
    }
    match args[0].as_str() {
        "list" | "ls" => vsi_list(&args[1..]),
        "copy" | "cp" => file_copy(&args[1..], true, "gdal vsi copy [OPTIONS] <SOURCE> <DESTINATION>"),
        "move" | "mv" | "ren" | "rename" => file_move(&args[1..], "gdal vsi move [OPTIONS] <SOURCE> <DESTINATION>"),
        "delete" | "rm" | "rmdir" | "del" => file_delete(&args[1..], "gdal vsi delete [OPTIONS] <FILENAME>"),
        "sync" => file_copy(&args[1..], true, "gdal vsi sync [OPTIONS] <SOURCE> <DESTINATION>"),
        "sozip" => {
            println!("Usage: gdal vsi sozip <SUBCOMMAND> [OPTIONS]");
            println!("where <SUBCOMMAND> is one of:\n  - create: Create a seek-optimized ZIP file.\n  - list:   List SOZIP content.");
            0
        }
        other => unknown_sub("vsi", other),
    }
}

fn command_pipeline(args: &[String]) -> i32 {
    if is_help(args) {
        println!("Usage: gdal pipeline [OPTIONS] <PIPELINE>\n\nProcess a dataset applying several steps.\n\nCommon Options:\n  -h, --help                        Display help message and exit\n  --json-usage                      Display usage as JSON document and exit\n  --config <KEY>=<VALUE>            Configuration option [may be repeated]\n  -q, --quiet                       Quiet mode (no progress bar or warning message)\n\n<PIPELINE> is of the form: read|calc|concat|create|mosaic|stack [READ-OPTIONS] ( ! <STEP-NAME> [STEP-OPTIONS] )* ! write!info!tile [WRITE-OPTIONS]\n\nFor more details, consult https://gdal.org/programs/gdal_pipeline.html\n\n{}", WARNING);
        0
    } else if args.is_empty() {
        eprintln!("ERROR 1: pipeline: Positional arguments starting at 'PIPELINE' have not been specified.");
        println!("Usage: gdal pipeline [OPTIONS] <PIPELINE>");
        println!("Try 'gdal pipeline --help' for help.");
        1
    } else {
        eprintln!("ERROR 6: pipeline execution is not supported by this reimplementation.");
        1
    }
}

fn command_convert(args: &[String]) -> i32 {
    if is_help(args) {
        println!("Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>\n\nConvert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').\n\nPositional arguments:\n  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]\n  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n  -q, --quiet                                          Quiet mode (no progress bar or warning message)\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n\nFor all options, run 'gdal raster convert --help' or 'gdal vector convert --help'\n\nFor more details, consult https://gdal.org/programs/gdal_convert.html\n\n{}", WARNING);
        return 0;
    }
    file_copy(args, true, "gdal convert [OPTIONS] <INPUT> <OUTPUT>")
}

fn command_create(args: &[String]) -> i32 {
    if is_help(args) {
        println!("Usage: gdal raster create [OPTIONS] <OUTPUT>\n\nCreate a new raster dataset.\n\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\nOptions:\n  --size <WIDTH>,<HEIGHT> Raster size\n  -f, --format <FORMAT>   Output format\n\n{}", WARNING);
        0
    } else if let Some(out) = positionals(args).last() {
        match fs::File::create(out) {
            Ok(_) => 0,
            Err(e) => { eprintln!("ERROR 1: {}: {}", out, e); 1 }
        }
    } else {
        eprintln!("ERROR 1: create: Positional arguments starting at 'OUTPUT' have not been specified.");
        1
    }
}

fn generic_algorithm_help_or_error(group: &str, name: &str, args: &[String]) -> i32 {
    if is_help(args) {
        println!("Usage: gdal {} {} [OPTIONS] <INPUT> <OUTPUT>", group, name);
        println!("\n{}\n", generic_desc(name));
        println!("Common Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n");
        println!("For more details, consult https://gdal.org/programs/gdal_{}_{}.html", group, name.replace('-', "_"));
        println!("\n{}", WARNING);
        0
    } else {
        eprintln!("ERROR 6: gdal {} {} is not implemented in this clean-room reimplementation.", group, name);
        1
    }
}

fn generic_desc(name: &str) -> String {
    name.replace('-', " ")
}

fn unknown_sub(group: &str, sub: &str) -> i32 {
    eprintln!("ERROR 1: {}: Unknown command: '{}'", group, sub);
    println!("Usage: gdal {} <SUBCOMMAND> [OPTIONS]", group);
    println!("Try 'gdal {} --help' for help.", group);
    1
}

fn positionals(args: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" {
            out.extend(args[i + 1..].iter().cloned());
            break;
        } else if a.starts_with("--") {
            if let Some((key, val)) = a.split_once('=') {
                if named_positional(key) {
                    out.push(val.to_string());
                }
            } else if option_takes_value(a) && i + 1 < args.len() {
                if named_positional(a) {
                    out.push(args[i + 1].clone());
                }
                i += 1;
            }
        } else if a.starts_with('-') {
            if matches!(a.as_str(), "-i" | "-o") && i + 1 < args.len() {
                out.push(args[i + 1].clone());
                i += 1;
            } else if matches!(a.as_str(), "-f" | "-of" | "-l" | "-b") {
                i += 1;
            }
        } else {
            out.push(a.clone());
        }
        i += 1;
    }
    out
}

fn option_takes_value(a: &str) -> bool {
    matches!(a, "--format" | "--output-format" | "--of" | "--input" | "--output" | "--source" |
        "--destination" | "--filename" | "--input-format" | "--if" | "--open-option" | "--oo" |
        "--creation-option" | "--co" | "--layer-creation-option" | "--lco" | "--output-layer" |
        "--size" | "--depth")
}

fn named_positional(a: &str) -> bool {
    matches!(a, "--input" | "--dataset" | "--source" | "--destination" | "--filename" | "--output")
}

fn file_copy(args: &[String], progress: bool, usage: &str) -> i32 {
    if is_help(args) {
        println!("Usage: {}", usage);
        return 0;
    }
    let quiet = args.iter().any(|a| a == "-q" || a == "--quiet");
    let recursive = args.iter().any(|a| a == "-r" || a == "-R" || a == "--recursive");
    let p = positionals(args);
    if p.len() < 2 {
        eprintln!("ERROR 1: Positional arguments starting at '{}' have not been specified.", if p.is_empty() { "SOURCE" } else { "DESTINATION" });
        println!("Usage: {}", usage);
        println!("Try '{} --help' for help.", usage.split(" [").next().unwrap_or("gdal"));
        return 1;
    }
    let src = Path::new(&p[0]);
    let dst = Path::new(&p[1]);
    let res = if src.is_dir() {
        if recursive {
            copy_dir(src, dst)
        } else {
            Err(io::Error::new(io::ErrorKind::Other, "Is a directory"))
        }
    } else {
        if let Some(parent) = dst.parent() {
            let _ = fs::create_dir_all(parent);
        }
        fs::copy(src, dst).map(|_| ())
    };
    match res {
        Ok(_) => {
            if progress && !quiet {
                println!("0...10...20...30...40...50...60...70...80...90...100 - done.");
            }
            0
        }
        Err(e) => {
            eprintln!("ERROR 1: {}: {}", p[0], e);
            1
        }
    }
}

fn copy_dir(src: &Path, dst: &Path) -> io::Result<()> {
    fs::create_dir_all(dst)?;
    for ent in fs::read_dir(src)? {
        let ent = ent?;
        let from = ent.path();
        let to = dst.join(ent.file_name());
        if from.is_dir() {
            copy_dir(&from, &to)?;
        } else {
            fs::copy(&from, &to)?;
        }
    }
    Ok(())
}

fn file_move(args: &[String], usage: &str) -> i32 {
    if is_help(args) {
        println!("Usage: {}", usage);
        return 0;
    }
    let quiet = args.iter().any(|a| a == "-q" || a == "--quiet");
    let p = positionals(args);
    if p.len() < 2 {
        eprintln!("ERROR 1: Positional arguments starting at '{}' have not been specified.", if p.is_empty() { "SOURCE" } else { "DESTINATION" });
        return 1;
    }
    match fs::rename(&p[0], &p[1]) {
        Ok(_) => {
            if !quiet && usage.contains("vsi") {
                println!("0...10...20...30...40...50...60...70...80...90...100 - done.");
            }
            0
        }
        Err(e) => { eprintln!("ERROR 1: {}: {}", p[0], e); 1 }
    }
}

fn file_delete(args: &[String], usage: &str) -> i32 {
    if is_help(args) {
        println!("Usage: {}", usage);
        return 0;
    }
    let recursive = args.iter().any(|a| a == "-r" || a == "-R" || a == "--recursive");
    let p = positionals(args);
    if p.is_empty() {
        eprintln!("ERROR 1: Positional arguments starting at 'FILENAME' have not been specified.");
        return 1;
    }
    let mut ok = true;
    for f in p {
        let path = Path::new(&f);
        let res = if path.is_dir() {
            if recursive { fs::remove_dir_all(path) } else { fs::remove_dir(path) }
        } else {
            fs::remove_file(path)
        };
        if let Err(e) = res {
            eprintln!("ERROR 1: {}: {}", f, e);
            ok = false;
        }
    }
    if ok { 0 } else { 1 }
}

fn vsi_list(args: &[String]) -> i32 {
    if is_help(args) {
        println!("Usage: gdal vsi list [OPTIONS] <FILENAME>\n\nList files of one of the GDAL Virtual System Interface (VSI).\n\nPositional arguments:\n  --filename <FILENAME>                                File or directory name [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n  -l, --long, --long-listing                           Use a long listing format\n  -R, --recursive                                      List subdirectories recursively\n  --depth <DEPTH>                                      Maximum depth in recursive mode\n  --abs, --absolute-path                               Display absolute path\n  --tree                                               Use a hierarchical presentation for JSON output\n\nFor more details, consult https://gdal.org/programs/gdal_vsi_list.html\n\n{}", WARNING);
        return 0;
    }
    let json = args.iter().any(|a| a == "-f=json" || a == "--format=json" || a == "--output-format=json") ||
        args.windows(2).any(|w| (w[0] == "-f" || w[0] == "--format" || w[0] == "--output-format") && w[1] == "json");
    let long = args.iter().any(|a| a == "-l" || a == "--long" || a == "--long-listing");
    let recursive = args.iter().any(|a| a == "-R" || a == "--recursive");
    let absolute = args.iter().any(|a| a == "--abs" || a == "--absolute-path");
    let p = positionals(args);
    let Some(root) = p.first() else {
        eprintln!("ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified.");
        return 1;
    };
    let path = Path::new(root);
    if json {
        let mut entries = Vec::new();
        collect_entries(path, path, recursive, absolute, &mut entries);
        println!("[");
        for (i, e) in entries.iter().enumerate() {
            println!("  {{\"name\":\"{}\"}}{}", json_escape(e), if i + 1 == entries.len() { "" } else { "," });
        }
        println!("]");
        return 0;
    }
    if path.is_dir() {
        match fs::read_dir(path) {
            Ok(rd) => {
                for ent in rd.flatten() {
                    let name = if absolute { ent.path().display().to_string() } else { ent.file_name().to_string_lossy().into_owned() };
                    if long {
                        if let Ok(md) = ent.metadata() {
                            println!("{} {}", md.len(), name);
                        } else {
                            println!("{}", name);
                        }
                    } else {
                        println!("{}", name);
                    }
                }
                0
            }
            Err(e) => { eprintln!("ERROR 1: {}: {}", root, e); 1 }
        }
    } else if path.exists() {
        println!("{}", if absolute { fs::canonicalize(path).unwrap_or_else(|_| PathBuf::from(path)).display().to_string() } else { path.file_name().unwrap_or_default().to_string_lossy().into_owned() });
        0
    } else {
        eprintln!("ERROR 1: {}: No such file or directory", root);
        1
    }
}

fn collect_entries(root: &Path, path: &Path, recursive: bool, absolute: bool, out: &mut Vec<String>) {
    if let Ok(rd) = fs::read_dir(path) {
        for ent in rd.flatten() {
            let p = ent.path();
            let s = if absolute {
                p.display().to_string()
            } else {
                p.strip_prefix(root).unwrap_or(&p).display().to_string()
            };
            out.push(s);
            if recursive && p.is_dir() {
                collect_entries(root, &p, recursive, absolute, out);
            }
        }
    }
}

fn dataset_identify(args: &[String]) -> i32 {
    if is_help(args) {
        println!("Usage: gdal dataset identify [OPTIONS] <FILENAME>\n\nIdentify driver opening dataset(s).\n\nPositional arguments:\n  --input, --filename <FILENAME>                       File or directory name [may be repeated] [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n  -q, --quiet                                          Quiet mode (no progress bar or warning message)\n\nOptions:\n  -o, --output <OUTPUT>                                Output vector dataset (created by algorithm)\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n  --overwrite                                          Whether overwriting existing output dataset is allowed\n  -r, --recursive                                      Recursively scan files/folders for datasets\n  --detailed                                           Most detailed output. Reports the presence of georeferencing, if a GeoTIFF file is cloud optimized, etc.\n  --report-failures                                    Report failures if file type is unidentified\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_identify.html\n\n{}", WARNING);
        return 0;
    }
    let p = positionals(args);
    if p.is_empty() {
        eprintln!("ERROR 1: identify: Positional arguments starting at 'FILENAME' have not been specified.");
        return 1;
    }
    let report = args.iter().any(|a| a == "--report-failures");
    for f in p {
        if let Some(driver) = identify_driver(&f) {
            println!("{}: {}", f, driver);
        } else if report {
            println!("{}: unrecognized", f);
        }
    }
    0
}

fn dataset_check(args: &[String]) -> i32 {
    if is_help(args) {
        println!("Usage: gdal dataset check [OPTIONS] <INPUT>\n\nCheck whether there are errors when reading the content of a dataset.\n\nPositional arguments:\n  -i, --input <INPUT>                  Input raster, vector or multidimensional raster dataset [required]\n\nCommon Options:\n  -h, --help                           Display help message and exit\n  --json-usage                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>               Configuration option [may be repeated]\n  -q, --quiet                          Quiet mode (no progress bar or warning message)\n\nAdvanced Options:\n  --oo, --open-option <KEY>=<VALUE>    Open options [may be repeated]\n  --if, --input-format <INPUT-FORMAT>  Input formats [may be repeated]\n\nFor more details, consult https://gdal.org/programs/gdal_dataset_check.html\n\n{}", WARNING);
        return 0;
    }
    let p = positionals(args);
    if p.is_empty() {
        eprintln!("ERROR 1: check: Positional arguments starting at 'INPUT' have not been specified.");
        return 1;
    }
    if identify_driver(&p[0]).is_some() { 0 } else {
        eprintln!("ERROR 4: `{}` not recognized as being in a supported file format.", p[0]);
        println!("Usage: gdal dataset check [OPTIONS] <INPUT>");
        println!("Try 'gdal dataset check --help' for help.");
        1
    }
}

fn command_info(args: &[String], usage_name: &str) -> i32 {
    if is_help(args) {
        println!("Usage: {} [OPTIONS] <INPUT>\n\nReturn information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').\n\nPositional arguments:\n  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]\n\nCommon Options:\n  -h, --help                                           Display help message and exit\n  --json-usage                                         Display usage as JSON document and exit\n  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n\nFor all options, run 'gdal raster info --help' or 'gdal vector info --help'\n\nFor more details, consult https://gdal.org/programs/gdal_info.html\n\n{}", usage_name, WARNING);
        return 0;
    }
    let json = args.iter().any(|a| a == "-f=json" || a == "--format=json" || a == "--output-format=json") ||
        args.windows(2).any(|w| (w[0] == "-f" || w[0] == "--format" || w[0] == "--output-format" || w[0] == "--of") && w[1] == "json");
    let p = positionals(args);
    if p.is_empty() {
        eprintln!("ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.");
        println!("Usage: {} [OPTIONS] <INPUT>", usage_name);
        println!("Try '{} --help' for help.", usage_name);
        return 1;
    }
    let f = &p[0];
    let path = Path::new(f);
    if !path.exists() {
        eprintln!("ERROR 4: {}: No such file or directory", f);
        println!("Usage: {} [OPTIONS] <INPUT>", usage_name);
        println!("Try '{} --help' for help.", usage_name);
        return 1;
    }
    let driver = identify_driver(f).unwrap_or_else(|| "Unknown".to_string());
    let size = fs::metadata(path).map(|m| m.len()).unwrap_or(0);
    let (w, h) = image_size(path).unwrap_or((0, 0));
    if json {
        println!("{{");
        println!("  \"description\":\"{}\",", json_escape(f));
        println!("  \"driverShortName\":\"{}\",", json_escape(&driver));
        println!("  \"driverLongName\":\"{}\",", json_escape(driver_long(&driver)));
        if w > 0 && h > 0 {
            println!("  \"size\":[{},{}],", w, h);
        }
        println!("  \"files\":[\"{}\"]", json_escape(f));
        println!("}}");
    } else {
        println!("Driver: {}/{}", driver, driver_long(&driver));
        if w > 0 && h > 0 {
            println!("Size is {}, {}", w, h);
        }
        println!("Files: {}", f);
        println!("File size: {} bytes", size);
    }
    0
}

fn identify_driver(name: &str) -> Option<String> {
    let p = Path::new(name);
    if p.is_dir() {
        return Some("Directory".to_string());
    }
    let ext = p.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
    let driver = match ext.as_str() {
        "tif" | "tiff" => "GTiff",
        "vrt" => "VRT",
        "png" => "PNG",
        "jpg" | "jpeg" => "JPEG",
        "gif" => "GIF",
        "bmp" => "BMP",
        "pgm" | "ppm" | "pnm" => "PNM",
        "grd" => "AAIGrid",
        "json" | "geojson" => "GeoJSON",
        "shp" => "ESRI Shapefile",
        "gpkg" => "GPKG",
        "csv" => "CSV",
        "kml" => "KML",
        "xml" => "GML",
        _ => return None,
    };
    Some(driver.to_string())
}

fn driver_long(driver: &str) -> &str {
    match driver {
        "GTiff" => "GeoTIFF",
        "VRT" => "Virtual Raster",
        "PNG" => "Portable Network Graphics",
        "JPEG" => "JPEG JFIF",
        "GIF" => "Graphics Interchange Format",
        "BMP" => "MS Windows Device Independent Bitmap",
        "PNM" => "Portable Pixmap Format",
        "AAIGrid" => "Arc/Info ASCII Grid",
        "GeoJSON" => "GeoJSON",
        "ESRI Shapefile" => "ESRI Shapefile",
        "GPKG" => "GeoPackage",
        "CSV" => "Comma Separated Value",
        "KML" => "Keyhole Markup Language",
        "GML" => "Geography Markup Language",
        "Directory" => "Directory",
        _ => "Unknown",
    }
}

fn image_size(path: &Path) -> Option<(u32, u32)> {
    let data = fs::read(path).ok()?;
    if data.starts_with(b"\x89PNG\r\n\x1a\n") && data.len() >= 24 {
        let w = u32::from_be_bytes([data[16], data[17], data[18], data[19]]);
        let h = u32::from_be_bytes([data[20], data[21], data[22], data[23]]);
        return Some((w, h));
    }
    if data.starts_with(b"P5") || data.starts_with(b"P6") || data.starts_with(b"P2") || data.starts_with(b"P3") {
        let text = String::from_utf8_lossy(&data);
        let toks: Vec<&str> = text.lines()
            .flat_map(|l| l.split('#').next().unwrap_or("").split_whitespace())
            .collect();
        if toks.len() >= 3 {
            if let (Ok(w), Ok(h)) = (toks[1].parse(), toks[2].parse()) {
                return Some((w, h));
            }
        }
    }
    None
}

fn print_drivers(scope: Option<&str>) {
    let drivers = [
        ("GTiff", "GeoTIFF", "raster", "tif,tiff"),
        ("COG", "Cloud optimized GeoTIFF generator", "raster", "tif,tiff"),
        ("VRT", "Virtual Raster", "raster", "vrt"),
        ("MEM", "In Memory raster, vector and multidimensional raster", "raster,vector,multidimensional_raster", ""),
        ("PNG", "Portable Network Graphics", "raster", "png"),
        ("JPEG", "JPEG JFIF", "raster", "jpg,jpeg"),
        ("GeoJSON", "GeoJSON", "vector", "json,geojson"),
        ("ESRI Shapefile", "ESRI Shapefile", "vector", "shp"),
        ("GPKG", "GeoPackage", "raster,vector", "gpkg"),
        ("CSV", "Comma Separated Value", "vector", "csv"),
    ];
    println!("[");
    let mut first = true;
    for (short, long, scopes, exts) in drivers {
        if let Some(s) = scope {
            if s == "mdim" && !scopes.contains("multidimensional") { continue; }
            if s != "mdim" && !scopes.contains(s) { continue; }
        }
        if !first { println!(","); }
        first = false;
        println!("  {{");
        println!("    \"short_name\":\"{}\",", json_escape(short));
        println!("    \"long_name\":\"{}\",", json_escape(long));
        print!("    \"scopes\":[");
        let ss: Vec<&str> = scopes.split(',').filter(|s| !s.is_empty()).collect();
        for (i, s) in ss.iter().enumerate() {
            print!("{}\"{}\"", if i == 0 { "" } else { "," }, s);
        }
        println!("],");
        println!("    \"capabilities\":[\"open\",\"create\",\"create_copy\"],");
        print!("    \"file_extensions\":[");
        let ee: Vec<&str> = exts.split(',').filter(|s| !s.is_empty()).collect();
        for (i, e) in ee.iter().enumerate() {
            print!("{}\"{}\"", if i == 0 { "" } else { "," }, e);
        }
        println!("]");
        print!("  }}");
    }
    println!("\n]");
}

fn print_json_usage(args: &[String]) {
    let path = if args.is_empty() { vec!["gdal".to_string()] } else { std::iter::once("gdal".to_string()).chain(args.iter().filter(|a| !a.starts_with('-')).cloned()).collect() };
    println!("{{");
    println!("  \"description\":\"Main gdal entry point.\",");
    print!("  \"full_path\":[");
    for (i, p) in path.iter().enumerate() {
        print!("{}\"{}\"", if i == 0 { "" } else { "," }, json_escape(p));
    }
    println!("],");
    println!("  \"url\":\"https://gdal.org/programs/index.html\",");
    println!("  \"sub_algorithms\":[");
    let subs = ["convert","dataset","driver","info","mdim","pipeline","raster","vector","vsi"];
    for (i, s) in subs.iter().enumerate() {
        println!("    {{\"name\":\"{}\",\"description\":\"{}\"}}{}", s, generic_desc(s), if i + 1 == subs.len() { "" } else { "," });
    }
    println!("  ],");
    println!("  \"input_arguments\":[],");
    println!("  \"output_arguments\":[]");
    println!("}}");
}

fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")
}
