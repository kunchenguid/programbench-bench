use anyhow::{Context, Result};
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::env;
use std::fs;
use std::fmt::Write as FmtWrite;
use std::path::{Path, PathBuf};

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
struct ExportDoc { cards: Vec<Card>, sessions: Vec<serde_json::Value> }

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
struct Card {
    hash: String,
    family_hash: Option<String>,
    deck_name: String,
    location: Location,
    content: Content,
    performance: Option<serde_json::Value>,
}

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
struct Location { file_path: String, line_start: usize, line_end: usize }

#[derive(Serialize, Clone)]
#[serde(rename_all = "camelCase")]
enum Content {
    #[serde(rename = "basic")]
    Basic { question: String, answer: String },
    #[serde(rename = "cloze")]
    Cloze { text: String, start: usize, end: usize },
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct Stats { cards_in_deck_count: usize, cards_in_db_count: usize, tex_macro_count: usize, cards_reviewed_today_count: usize }

fn main() {
    let code = match run() {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("hashcards: error: {e:#}");
            1
        }
    };
    if code != 0 { std::process::exit(code); }
}

fn run() -> Result<()> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() { print_main_help(); return Ok(()); }
    match args[0].as_str() {
        "-h" | "--help" => print_main_help(),
        "-V" | "--version" => println!("hashcards 0.3.0"),
        "help" => {
            if args.len() > 1 { print_help_for(&args[1]); } else { print_main_help(); }
        }
        "check" => {
            if has_help(&args) { print_check_help(); return Ok(()); }
            let dir = positional_dir(&mut args, 1);
            let _ = parse_collection(&dir)?;
            println!("ok");
        }
        "stats" => handle_stats(&args[1..])?,
        "export" => handle_export(&args[1..])?,
        "orphans" => handle_orphans(&args[1..]),
        "drill" => handle_drill(&args[1..]),
        other => {
            eprintln!("error: unrecognized subcommand '{other}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.");
            std::process::exit(2);
        }
    }
    Ok(())
}

fn has_help(args: &[String]) -> bool { args.iter().any(|a| a == "-h" || a == "--help") }

fn positional_dir(args: &mut [String], start: usize) -> PathBuf {
    args.iter().skip(start).find(|a| !a.starts_with('-')).map(PathBuf::from).unwrap_or_else(|| PathBuf::from("."))
}

fn handle_stats(args: &[String]) -> Result<()> {
    if has_help(args) { print_stats_help(); return Ok(()); }
    let mut format = "html".to_string();
    let mut dir = PathBuf::from(".");
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--format" => { if let Some(v) = args.get(i + 1) { format = v.clone(); i += 2; } else { i += 1; } }
            a if a.starts_with("--format=") => { format = a[9..].to_string(); i += 1; }
            a if !a.starts_with('-') => { dir = PathBuf::from(a); i += 1; }
            _ => i += 1,
        }
    }
    match format.as_str() {
        "html" => println!("HTML output is not implemented yet."),
        "json" => {
            let cards = parse_collection(&dir)?;
            let stats = Stats { cards_in_deck_count: cards.len(), cards_in_db_count: 0, tex_macro_count: count_tex(&dir)?, cards_reviewed_today_count: 0 };
            println!("{}", serde_json::to_string_pretty(&stats)?);
        }
        _ => { eprintln!("error: invalid value '{format}' for '--format <FORMAT>'\n  [possible values: html, json]\n\nFor more information, try '--help'."); std::process::exit(2); }
    }
    Ok(())
}

fn handle_export(args: &[String]) -> Result<()> {
    if has_help(args) { print_export_help(); return Ok(()); }
    let mut output: Option<PathBuf> = None;
    let mut dir = PathBuf::from(".");
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--output" => { if let Some(v) = args.get(i + 1) { output = Some(PathBuf::from(v)); i += 2; } else { i += 1; } }
            a if a.starts_with("--output=") => { output = Some(PathBuf::from(&a[9..])); i += 1; }
            a if !a.starts_with('-') => { dir = PathBuf::from(a); i += 1; }
            _ => i += 1,
        }
    }
    let doc = ExportDoc { cards: parse_collection(&dir)?, sessions: vec![] };
    let mut json = serde_json::to_string_pretty(&doc)?;
    json.push('\n');
    if let Some(path) = output { fs::write(path, json)?; } else { print!("{json}"); }
    Ok(())
}

fn handle_orphans(args: &[String]) {
    if args.is_empty() || has_help(args) { print_orphans_help(); return; }
    match args[0].as_str() {
        "list" => { if has_help(&args[1..]) { print_orphans_list_help(); } }
        "delete" => { if has_help(&args[1..]) { print_orphans_delete_help(); } }
        "help" => print_orphans_help(),
        other => { eprintln!("error: unrecognized subcommand '{other}'\n\nUsage: executable orphans <COMMAND>\n\nFor more information, try '--help'."); std::process::exit(2); }
    }
}

fn handle_drill(args: &[String]) {
    if has_help(args) { print_drill_help(); return; }
    println!("Drill web interface is not implemented in this reimplementation.");
}

fn print_help_for(cmd: &str) { match cmd { "check" => print_check_help(), "stats" => print_stats_help(), "export" => print_export_help(), "orphans" => print_orphans_help(), "drill" => print_drill_help(), _ => print_main_help() } }

fn print_main_help() { println!("A plain text-based spaced repetition system.\n\nUsage: executable <COMMAND>\n\nCommands:\n  drill    Drill cards through a web interface\n  check    Check the integrity of a collection\n  stats    Print collection statistics\n  orphans  Commands relating to orphan cards\n  export   Export a collection\n  help     Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"); }
fn print_check_help() { println!("Check the integrity of a collection\n\nUsage: executable check [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help"); }
fn print_stats_help() { println!("Print collection statistics\n\nUsage: executable stats [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --format <FORMAT>\n          Which output format to use\n\n          Possible values:\n          - html: HTML output\n          - json: JSON output\n          \n          [default: html]\n\n  -h, --help\n          Print help (see a summary with '-h')"); }
fn print_export_help() { println!("Export a collection\n\nUsage: executable export [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --output <OUTPUT>  Optional path to the output file. By default, the output is printed to stdout\n  -h, --help             Print help"); }
fn print_orphans_help() { println!("Commands relating to orphan cards\n\nUsage: executable orphans <COMMAND>\n\nCommands:\n  list    List the hashes of all orphan cards in the collection\n  delete  Remove all orphan cards from the database\n  help    Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help  Print help"); }
fn print_orphans_list_help() { println!("List the hashes of all orphan cards in the collection\n\nUsage: executable orphans list [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help"); }
fn print_orphans_delete_help() { println!("Remove all orphan cards from the database\n\nUsage: executable orphans delete [DIRECTORY]\n\nArguments:\n  [DIRECTORY]  Path to the collection directory. By default, the current working directory is used\n\nOptions:\n  -h, --help  Print help"); }
fn print_drill_help() { println!("Drill cards through a web interface\n\nUsage: executable drill [OPTIONS] [DIRECTORY]\n\nArguments:\n  [DIRECTORY]\n          Path to the collection directory. By default, the current working directory is used\n\nOptions:\n      --card-limit <CARD_LIMIT>\n          Maximum number of cards to drill in a session. By default, all cards due today are drilled\n\n      --new-card-limit <NEW_CARD_LIMIT>\n          Maximum number of new cards to drill in a session\n\n      --host <HOST>\n          The host address to bind to. Default is 127.0.0.1\n          \n          [default: 127.0.0.1]\n\n      --port <PORT>\n          The port to use for the web server. Default is 8000\n          \n          [default: 8000]\n\n      --from-deck <FROM_DECK>\n          Only drill cards from this deck\n\n      --open-browser <OPEN_BROWSER>\n          Whether to open the browser automatically. Default is true\n          \n          [possible values: true, false]\n\n      --answer-controls <ANSWER_CONTROLS>\n          Which answer controls to show:\n\n          Possible values:\n          - full:   Show all four rating buttons (Forgot/Hard/Good/Easy)\n          - binary: Show only two rating buttons (Forgot/Good)\n          \n          [default: full]\n\n      --bury-siblings <BURY_SIBLINGS>\n          Whether or not to bury siblings. Default is true\n          \n          [possible values: true, false]\n\n  -h, --help\n          Print help (see a summary with '-h')"); }

fn count_tex(dir: &Path) -> Result<usize> {
    Ok(list_files(dir)?.into_iter().filter(|p| p.extension().and_then(|s| s.to_str()) == Some("tex")).count())
}

fn list_files(dir: &Path) -> Result<Vec<PathBuf>> {
    let mut out = Vec::new();
    fn rec(base: &Path, out: &mut Vec<PathBuf>) -> Result<()> {
        if !base.exists() { return Ok(()); }
        for ent in fs::read_dir(base).with_context(|| format!("reading {}", base.display()))? {
            let ent = ent?;
            let p = ent.path();
            let name = ent.file_name().to_string_lossy().to_string();
            if name == ".git" || name == "target" { continue; }
            if p.is_dir() { rec(&p, out)?; } else { out.push(p); }
        }
        Ok(())
    }
    rec(dir, &mut out)?;
    out.sort();
    Ok(out)
}

fn parse_collection(dir: &Path) -> Result<Vec<Card>> {
    let mut cards = Vec::new();
    for path in list_files(dir)? {
        if path.extension().and_then(|s| s.to_str()) == Some("md") { parse_file(&path, &mut cards)?; }
    }
    cards.sort_by(|a, b| a.hash.cmp(&b.hash));
    Ok(cards)
}

fn parse_file(path: &Path, cards: &mut Vec<Card>) -> Result<()> {
    let text = fs::read_to_string(path).with_context(|| format!("reading {}", path.display()))?;
    let lines: Vec<&str> = text.lines().collect();
    let deck = path.file_stem().and_then(|s| s.to_str()).unwrap_or("Deck").to_string();
    let file_path = abs_path(path);
    let mut i = 0;
    while i < lines.len() {
        if let Some(rest) = lines[i].strip_prefix("Q:") {
            let start = i;
            let mut q_lines = vec![rest.trim_start().to_string()];
            i += 1;
            while i < lines.len() && !lines[i].starts_with("A:") && !is_marker(lines[i]) { q_lines.push(lines[i].to_string()); i += 1; }
            if i >= lines.len() || !lines[i].starts_with("A:") { continue; }
            let mut a_lines = vec![lines[i].strip_prefix("A:").unwrap().trim_start().to_string()];
            i += 1;
            while i < lines.len() && !is_marker(lines[i]) { a_lines.push(lines[i].to_string()); i += 1; }
            let end = i.min(lines.len().saturating_sub(1));
            add_basic(cards, &deck, &file_path, start, end, trim_block(&q_lines), trim_block(&a_lines));
            continue;
        }
        if let Some(rest) = lines[i].strip_prefix("C:") {
            let start = i;
            let mut c_lines = vec![rest.trim_start().to_string()];
            i += 1;
            while i < lines.len() && !is_marker(lines[i]) { c_lines.push(lines[i].to_string()); i += 1; }
            let end = if i == 0 { 0 } else { i - 1 };
            add_clozes(cards, &deck, &file_path, start, end, &trim_block(&c_lines));
            continue;
        }
        i += 1;
    }
    Ok(())
}

fn is_marker(line: &str) -> bool { line.starts_with("Q:") || line.starts_with("C:") }

fn trim_block(lines: &[String]) -> String {
    let mut start = 0;
    let mut end = lines.len();
    while start < end && lines[start].trim().is_empty() { start += 1; }
    while end > start && lines[end - 1].trim().is_empty() { end -= 1; }
    lines[start..end].join("\n")
}

fn add_basic(cards: &mut Vec<Card>, deck: &str, file_path: &str, line_start: usize, line_end: usize, question: String, answer: String) {
    let content = Content::Basic { question, answer };
    let hash = hash_card(None, &content);
    cards.push(Card { hash, family_hash: None, deck_name: deck.to_string(), location: Location { file_path: file_path.to_string(), line_start, line_end }, content, performance: None });
}

fn add_clozes(cards: &mut Vec<Card>, deck: &str, file_path: &str, line_start: usize, line_end: usize, raw: &str) {
    let mut text = String::new();
    let mut ranges = Vec::new();
    let chars: Vec<char> = raw.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '[' {
            let start_pos = text.len();
            i += 1;
            let mut inner = String::new();
            while i < chars.len() && chars[i] != ']' { inner.push(chars[i]); i += 1; }
            if i < chars.len() && chars[i] == ']' { i += 1; }
            text.push_str(&inner);
            let len = inner.len();
            if len > 0 { ranges.push((start_pos, start_pos + len - 1)); }
        } else { text.push(chars[i]); i += 1; }
    }
    if ranges.is_empty() { return; }
    let family = sha256_hex(format!("cloze-family\n{text}"));
    for (start, end) in ranges {
        let content = Content::Cloze { text: text.clone(), start, end };
        let hash = hash_card(Some(&family), &content);
        cards.push(Card { hash, family_hash: Some(family.clone()), deck_name: deck.to_string(), location: Location { file_path: file_path.to_string(), line_start, line_end }, content, performance: None });
    }
}

fn hash_card(family: Option<&str>, content: &Content) -> String {
    match content {
        Content::Basic { question, answer } => sha256_hex(format!("basic\n{question}\n{answer}")),
        Content::Cloze { text, start, end } => sha256_hex(format!("cloze\n{}\n{text}\n{start}\n{end}", family.unwrap_or(""))),
    }
}

fn sha256_hex<T: AsRef<[u8]>>(data: T) -> String {
    let mut h = Sha256::new();
    h.update(data);
    let bytes = h.finalize();
    let mut s = String::with_capacity(bytes.len() * 2);
    for b in bytes { let _ = write!(&mut s, "{b:02x}"); }
    s
}

fn abs_path(path: &Path) -> String { fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf()).display().to_string() }
