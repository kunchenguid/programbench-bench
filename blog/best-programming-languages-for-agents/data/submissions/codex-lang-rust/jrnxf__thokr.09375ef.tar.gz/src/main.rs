use std::env;
use std::fs::{self, OpenOptions};
use std::io::{self, IsTerminal, Read, Write};
use std::path::PathBuf;
use std::process;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

const VERSION: &str = "0.4.1";

#[derive(Clone, Debug)]
struct Config {
    words: usize,
    seconds: Option<u64>,
    sentences: Option<usize>,
    language: String,
    prompt: Option<String>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            words: 15,
            seconds: None,
            sentences: None,
            language: "english".to_string(),
            prompt: None,
        }
    }
}

fn main() {
    let mut args: Vec<String> = env::args().collect();
    let argv0 = args.get(0).cloned().unwrap_or_else(|| "executable".to_string());
    let display_name = argv0.rsplit('/').next().unwrap_or("executable").to_string();
    args.remove(0);

    let cfg = match parse_args(&args, &display_name) {
        Ok(Some(cfg)) => cfg,
        Ok(None) => return,
        Err(code) => process::exit(code),
    };

    if !io::stdin().is_terminal() {
        eprintln!("error: stdin must be a tty\n");
        eprintln!("USAGE:");
        eprintln!("    thokr [OPTIONS]\n");
        eprintln!("For more information try --help");
        process::exit(2);
    }

    if let Err(err) = run(cfg) {
        restore_screen();
        eprintln!("error: {}", err);
        process::exit(1);
    }
}

fn parse_args(args: &[String], display_name: &str) -> Result<Option<Config>, i32> {
    let mut cfg = Config::default();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        match arg.as_str() {
            "-h" | "--help" => {
                print_help(display_name);
                return Ok(None);
            }
            "-V" | "--version" => {
                println!("thokr {}", VERSION);
                return Ok(None);
            }
            "-w" | "--number-of-words" => {
                cfg.words = parse_usize_value(args, &mut i, "--number-of-words", "NUMBER_OF_WORDS", false)?;
            }
            "-s" | "--number-of-secs" => {
                cfg.seconds = Some(parse_u64_value(args, &mut i, "--number-of-secs", "NUMBER_OF_SECS", false)?);
            }
            "-f" | "--full-sentences" => {
                cfg.sentences = Some(parse_usize_value(args, &mut i, "--full-sentences", "NUMBER_OF_SENTENCES", false)?);
            }
            "-p" | "--prompt" => {
                cfg.prompt = Some(parse_string_value(args, &mut i, "--prompt", "PROMPT")?);
            }
            "-l" | "--supported-language" => {
                let value = parse_string_value(args, &mut i, "--supported-language", "SUPPORTED_LANGUAGE")?;
                if !matches!(value.as_str(), "english" | "english1k" | "english10k") {
                    eprintln!("error: \"{}\" isn't a valid value for '--supported-language <SUPPORTED_LANGUAGE>'", value);
                    eprintln!("\t[possible values: english, english1k, english10k]\n");
                    eprintln!("USAGE:");
                    eprintln!("    {} --supported-language <SUPPORTED_LANGUAGE>\n", display_name);
                    eprintln!("For more information try --help");
                    return Err(2);
                }
                cfg.language = value;
            }
            "--" => {
                if i + 1 < args.len() {
                    unexpected(&args[i + 1], display_name);
                    return Err(2);
                }
            }
            _ if arg.starts_with('-') => {
                unexpected(arg, display_name);
                return Err(2);
            }
            _ => {
                unexpected(arg, display_name);
                return Err(2);
            }
        }
        i += 1;
    }
    Ok(Some(cfg))
}

fn parse_string_value(args: &[String], i: &mut usize, long: &str, name: &str) -> Result<String, i32> {
    if *i + 1 >= args.len() {
        eprintln!("error: The argument '{} <{}>' requires a value but none was supplied\n", long, name);
        eprintln!("USAGE:");
        eprintln!("    executable [OPTIONS]\n");
        eprintln!("For more information try --help");
        return Err(2);
    }
    *i += 1;
    Ok(args[*i].clone())
}

fn parse_usize_value(args: &[String], i: &mut usize, long: &str, name: &str, allow_hyphen: bool) -> Result<usize, i32> {
    let value = parse_string_value(args, i, long, name)?;
    if value.starts_with('-') && !allow_hyphen {
        unexpected(&value, "executable");
        return Err(2);
    }
    match value.parse::<usize>() {
        Ok(v) => Ok(v),
        Err(e) => {
            eprintln!("error: Invalid value \"{}\" for '{} <{}>': {}\n", value, long, name, e);
            eprintln!("For more information try --help");
            Err(2)
        }
    }
}

fn parse_u64_value(args: &[String], i: &mut usize, long: &str, name: &str, allow_hyphen: bool) -> Result<u64, i32> {
    let value = parse_string_value(args, i, long, name)?;
    if value.starts_with('-') && !allow_hyphen {
        unexpected(&value, "executable");
        return Err(2);
    }
    match value.parse::<u64>() {
        Ok(v) => Ok(v),
        Err(e) => {
            eprintln!("error: Invalid value \"{}\" for '{} <{}>': {}\n", value, long, name, e);
            eprintln!("For more information try --help");
            Err(2)
        }
    }
}

fn unexpected(arg: &str, display_name: &str) {
    eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context\n", arg);
    eprintln!("\tIf you tried to supply `{}` as a value rather than a flag, use `-- {}`\n", arg, arg);
    eprintln!("USAGE:");
    eprintln!("    {} [OPTIONS]\n", display_name);
    eprintln!("For more information try --help");
}

fn print_help(name: &str) {
    println!("thokr {}", VERSION);
    println!("sleek typing tui with visualized results and historical logging\n");
    println!("USAGE:");
    println!("    {} [OPTIONS]\n", name);
    println!("OPTIONS:");
    println!("    -f, --full-sentences <NUMBER_OF_SENTENCES>");
    println!("            number of sentences to use in test\n");
    println!("    -h, --help");
    println!("            Print help information\n");
    println!("    -l, --supported-language <SUPPORTED_LANGUAGE>");
    println!("            language to pull words from [default: english] [possible values: english, english1k,");
    println!("            english10k]\n");
    println!("    -p, --prompt <PROMPT>");
    println!("            custom prompt to use\n");
    println!("    -s, --number-of-secs <NUMBER_OF_SECS>");
    println!("            number of seconds to run test\n");
    println!("    -V, --version");
    println!("            Print version information\n");
    println!("    -w, --number-of-words <NUMBER_OF_WORDS>");
    println!("            number of words to use in test [default: 15]");
}

fn run(cfg: Config) -> io::Result<()> {
    let prompt = cfg.prompt.clone().unwrap_or_else(|| build_prompt(&cfg));
    let mut stdout = io::stdout();
    write!(stdout, "\x1b[?1049h\x1b[2J\x1b[H\x1b[?25l")?;
    render(&mut stdout, &prompt, "", Instant::now(), cfg.seconds)?;

    let started = Instant::now();
    let mut input = String::new();
    let mut buffer = [0u8; 1];
    loop {
        if let Some(limit) = cfg.seconds {
            if started.elapsed() >= Duration::from_secs(limit) {
                break;
            }
        }
        match io::stdin().read(&mut buffer) {
            Ok(0) => {
                std::thread::sleep(Duration::from_millis(50));
            }
            Ok(_) => {
                let b = buffer[0];
                match b {
                    3 | 4 | 27 => break,
                    b'\n' | b'\r' => {
                        if input.trim_end() == prompt {
                            break;
                        }
                    }
                    8 | 127 => {
                        input.pop();
                    }
                    _ if !b.is_ascii_control() => input.push(b as char),
                    _ => {}
                }
                render(&mut stdout, &prompt, &input, started, cfg.seconds)?;
                if input == prompt {
                    break;
                }
            }
            Err(err) => return Err(err),
        }
    }

    let elapsed = started.elapsed().as_secs_f64().max(0.01);
    let stats = stats(&prompt, &input, elapsed);
    write_log(&stats);
    render_results(&mut stdout, &stats)?;
    restore_screen();
    Ok(())
}

fn render(out: &mut io::Stdout, prompt: &str, input: &str, started: Instant, seconds: Option<u64>) -> io::Result<()> {
    let remaining = seconds.map(|s| s.saturating_sub(started.elapsed().as_secs()));
    write!(out, "\x1b[2J\x1b[H")?;
    writeln!(out, "thokr")?;
    if let Some(left) = remaining {
        writeln!(out, "{}s", left)?;
    }
    writeln!(out)?;
    writeln!(out, "{}", prompt)?;
    writeln!(out)?;
    write!(out, "{}", input)?;
    out.flush()
}

fn render_results(out: &mut io::Stdout, stats: &Stats) -> io::Result<()> {
    write!(out, "\x1b[2J\x1b[H")?;
    writeln!(out, "wpm: {:.0}", stats.wpm)?;
    writeln!(out, "accuracy: {:.0}%", stats.accuracy)?;
    writeln!(out, "chars: {}/{}", stats.correct, stats.total)?;
    out.flush()
}

fn restore_screen() {
    let _ = write!(io::stdout(), "\x1b[?25h\x1b[?1049l");
    let _ = io::stdout().flush();
}

fn build_prompt(cfg: &Config) -> String {
    if let Some(n) = cfg.sentences {
        return (0..n)
            .map(|idx| {
                let words = pick_words(&cfg.language, 8 + (idx % 5));
                let mut sentence = words.join(" ");
                if let Some(first) = sentence.get_mut(0..1) {
                    first.make_ascii_uppercase();
                }
                sentence.push('.');
                sentence
            })
            .collect::<Vec<_>>()
            .join(" ");
    }
    pick_words(&cfg.language, cfg.words).join(" ")
}

fn pick_words(language: &str, count: usize) -> Vec<&'static str> {
    let words = match language {
        "english1k" => ENGLISH_1K,
        "english10k" => ENGLISH_10K,
        _ => ENGLISH,
    };
    let seed = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().subsec_nanos() as usize;
    (0..count).map(|i| words[(seed.wrapping_add(i * 37)) % words.len()]).collect()
}

struct Stats {
    wpm: f64,
    accuracy: f64,
    correct: usize,
    total: usize,
}

fn stats(prompt: &str, input: &str, elapsed: f64) -> Stats {
    let total = prompt.chars().count();
    let correct = prompt.chars().zip(input.chars()).filter(|(a, b)| a == b).count();
    let typed = input.chars().count();
    let accuracy = if typed == 0 { 0.0 } else { correct as f64 * 100.0 / typed as f64 };
    let wpm = (correct as f64 / 5.0) / (elapsed / 60.0);
    Stats { wpm, accuracy, correct, total }
}

fn write_log(stats: &Stats) {
    let Some(dir) = config_dir() else { return; };
    if fs::create_dir_all(&dir).is_err() {
        return;
    }
    let path = dir.join("log.csv");
    let new_file = !path.exists();
    if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(path) {
        if new_file {
            let _ = writeln!(file, "timestamp,wpm,accuracy,correct,total");
        }
        let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
        let _ = writeln!(file, "{},{:.2},{:.2},{},{}", ts, stats.wpm, stats.accuracy, stats.correct, stats.total);
    }
}

fn config_dir() -> Option<PathBuf> {
    if let Ok(xdg) = env::var("XDG_CONFIG_HOME") {
        return Some(PathBuf::from(xdg).join("thokr"));
    }
    env::var("HOME").ok().map(|home| PathBuf::from(home).join(".config").join("thokr"))
}

const ENGLISH: &[&str] = &[
    "the", "be", "to", "of", "and", "a", "in", "that", "have", "i", "it", "for", "not", "on", "with",
    "he", "as", "you", "do", "at", "this", "but", "his", "by", "from", "they", "we", "say", "her", "she",
    "or", "an", "will", "my", "one", "all", "would", "there", "their", "what", "so", "up", "out", "if",
    "about", "who", "get", "which", "go", "me", "when", "make", "can", "like", "time", "no", "just",
    "him", "know", "take", "people", "into", "year", "your", "good", "some", "could", "them", "see",
    "other", "than", "then", "now", "look", "only", "come", "its", "over", "think", "also", "back",
    "after", "use", "two", "how", "our", "work", "first", "well", "way", "even", "new", "want",
    "because", "any", "these", "give", "day", "most", "us",
];

const ENGLISH_1K: &[&str] = &[
    "able", "accept", "account", "across", "act", "action", "activity", "actually", "add", "address",
    "administration", "admit", "adult", "affect", "after", "again", "against", "age", "agency", "agent",
    "ago", "agree", "ahead", "air", "all", "allow", "almost", "alone", "along", "already", "also",
    "although", "always", "american", "among", "amount", "analysis", "and", "animal", "another", "answer",
    "any", "anyone", "anything", "appear", "apply", "approach", "area", "argue", "arm", "around", "arrive",
    "art", "article", "artist", "ask", "assume", "attack", "attention", "attorney", "audience", "author",
    "available", "avoid", "away", "baby", "back", "bad", "bag", "ball", "bank", "bar", "base", "beat",
    "beautiful", "because", "become", "bed", "before", "begin", "behavior", "behind", "believe", "benefit",
    "best", "better", "between", "beyond", "big", "bill", "billion", "bit", "black", "blood", "blue",
    "board", "body", "book", "born", "both", "box", "boy", "break", "bring", "brother", "budget",
    "build", "building", "business", "but", "buy", "call", "camera", "campaign", "can", "cancer",
    "candidate", "capital", "car", "card", "care", "career", "carry", "case", "catch", "cause",
];

const ENGLISH_10K: &[&str] = &[
    "abandon", "ability", "absence", "absolute", "abstract", "academy", "accelerate", "accent", "accept",
    "access", "accident", "accompany", "accomplish", "account", "accurate", "accuse", "achieve", "acid",
    "acoustic", "acquire", "across", "activate", "actual", "adapt", "addition", "adequate", "adjust",
    "administration", "advance", "advantage", "adventure", "advertise", "advice", "aerial", "affair",
    "afford", "afraid", "afterward", "agency", "aggressive", "aircraft", "alcohol", "algorithm", "alien",
    "alley", "allocate", "allowance", "alphabet", "already", "alter", "although", "altitude", "amateur",
    "amazing", "ambition", "amount", "amuse", "analysis", "ancestor", "ancient", "anger", "angle",
    "animal", "annual", "answer", "anxiety", "anybody", "apartment", "apology", "apparent", "appeal",
    "appendix", "appetite", "applaud", "appoint", "approve", "architect", "arena", "argument", "arise",
    "arrange", "arrival", "article", "artwork", "aspect", "assemble", "assist", "assume", "athlete",
    "atmosphere", "attach", "attempt", "attitude", "attract", "auction", "author", "automatic", "average",
];
