use chrono::{Local, Timelike, Utc};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::thread;
use std::time::Duration;

const USAGE: &str =
"usage : tty-clock [-iuvsScbtrahDBxn] [-C [0-7]] [-f format] [-d delay] [-a nsdelay] [-T tty] 
    -s            Show seconds                                   
    -S            Screensaver mode                               
    -x            Show box                                       
    -c            Set the clock at the center of the terminal    
    -C [0-7]      Set the clock color                            
    -b            Use bold colors                                
    -t            Set the hour in 12h format                     
    -u            Use UTC time                                   
    -T tty        Display the clock on the specified terminal    
    -r            Do rebound the clock                           
    -f format     Set the date format                            
    -n            Don't quit on keypress                         
    -v            Show tty-clock version                         
    -i            Show some info about tty-clock                 
    -h            Show this page                                 
    -D            Hide date                                      
    -B            Enable blinking colon                          
    -d delay      Set the delay between two redraws of the clock. Default 1s. 
    -a nsdelay    Additional delay between two redraws in nanoseconds. Default 0ns.
";

#[derive(Clone)]
struct Opts {
    seconds: bool,
    box_: bool,
    center: bool,
    color: u8,
    bold: bool,
    twelve: bool,
    utc: bool,
    hide_date: bool,
    blink: bool,
    date_fmt: String,
    delay: u64,
    nsdelay: u32,
}

impl Default for Opts {
    fn default() -> Self {
        Self {
            seconds: false,
            box_: false,
            center: false,
            color: 2,
            bold: false,
            twelve: false,
            utc: false,
            hide_date: false,
            blink: false,
            date_fmt: "%F".to_string(),
            delay: 1,
            nsdelay: 0,
        }
    }
}

fn usage() {
    print!("{}", USAGE);
}

fn option_error(prog: &str, msg: &str, opt: char) -> ! {
    println!("{}: {} -- '{}'", prog, msg, opt);
    usage();
    std::process::exit(0);
}

fn need_arg(args: &[String], i: &mut usize, chars: &[char], pos: usize, prog: &str, opt: char) -> String {
    if pos + 1 < chars.len() {
        chars[pos + 1..].iter().collect()
    } else {
        *i += 1;
        if *i >= args.len() {
            option_error(prog, "option requires an argument", opt);
        }
        args[*i].clone()
    }
}

fn parse() -> Opts {
    let args: Vec<String> = env::args().collect();
    let prog = args.get(0).cloned().unwrap_or_else(|| "./executable".to_string());
    let mut opts = Opts::default();
    let mut i = 1;
    while i < args.len() {
        let arg = &args[i];
        if !arg.starts_with('-') || arg == "-" {
            i += 1;
            continue;
        }
        let chars: Vec<char> = arg[1..].chars().collect();
        let mut p = 0;
        while p < chars.len() {
            match chars[p] {
                's' => opts.seconds = true,
                'S' => {}
                'x' => opts.box_ = true,
                'c' => opts.center = true,
                'b' => opts.bold = true,
                't' => opts.twelve = true,
                'u' => opts.utc = true,
                'r' => {}
                'n' => {}
                'D' => opts.hide_date = true,
                'B' => opts.blink = true,
                'h' => {
                    usage();
                    std::process::exit(0);
                }
                'v' => {
                    println!("TTY-Clock 2 © devel version");
                    std::process::exit(0);
                }
                'i' => {
                    println!("TTY-Clock 2 © by Martin Duquesnoy (xorg62@gmail.com), Grey (grey@greytheory.net)");
                    std::process::exit(0);
                }
                'C' => {
                    let v = need_arg(&args, &mut i, &chars, p, &prog, 'C');
                    opts.color = v.parse::<u8>().unwrap_or(2);
                    if opts.color > 7 {
                        opts.color = 2;
                    }
                    break;
                }
                'f' => {
                    opts.date_fmt = need_arg(&args, &mut i, &chars, p, &prog, 'f');
                    break;
                }
                'd' => {
                    let v = need_arg(&args, &mut i, &chars, p, &prog, 'd');
                    opts.delay = v.parse::<u64>().unwrap_or(1);
                    break;
                }
                'a' => {
                    let v = need_arg(&args, &mut i, &chars, p, &prog, 'a');
                    opts.nsdelay = v.parse::<u32>().unwrap_or(0);
                    break;
                }
                'T' => {
                    let path = need_arg(&args, &mut i, &chars, p, &prog, 'T');
                    if let Err(e) = fs::metadata(&path) {
                        let msg = e.to_string();
                        let msg = msg.split(" (os error").next().unwrap_or(&msg);
                        println!("tty-clock: error: couldn't stat '{}': {}.", path, msg);
                        std::process::exit(1);
                    }
                    break;
                }
                c => option_error(&prog, "invalid option", c),
            }
            p += 1;
        }
        i += 1;
    }
    opts
}

fn digit_rows(c: char) -> [&'static str; 5] {
    match c {
        '0' => [" #### ", "##  ##", "##  ##", "##  ##", " #### "],
        '1' => ["  ##  ", " #### ", "  ##  ", "  ##  ", "######"],
        '2' => [" #### ", "##  ##", "   ## ", "  ##  ", "######"],
        '3' => ["####  ", "    ##", " #### ", "    ##", "####  "],
        '4' => ["##  ##", "##  ##", "######", "    ##", "    ##"],
        '5' => ["######", "##    ", "##### ", "    ##", "##### "],
        '6' => [" #### ", "##    ", "##### ", "##  ##", " #### "],
        '7' => ["######", "    ##", "   ## ", "  ##  ", " ##   "],
        '8' => [" #### ", "##  ##", " #### ", "##  ##", " #### "],
        '9' => [" #### ", "##  ##", " #####", "    ##", " #### "],
        ':' => ["      ", "  ##  ", "      ", "  ##  ", "      "],
        _ => ["      "; 5],
    }
}

fn color_codes(opts: &Opts) -> (u8, u8) {
    let n = opts.color.min(7);
    let fg = 30 + n;
    let bg = 40 + n;
    (fg, bg)
}

fn move_to(row: usize, col: usize) {
    print!("\x1b[{};{}H", row, col);
}

fn draw_big(text: &str, row: usize, col: usize, opts: &Opts) {
    let (fg, bg) = color_codes(opts);
    for r in 0..5 {
        let mut x = col;
        for ch in text.chars() {
            let pat = digit_rows(ch)[r];
            move_to(row + r, x);
            let mut in_block = false;
            for pc in pat.chars() {
                if pc == '#' {
                    if !in_block {
                        if opts.bold {
                            print!("\x1b[1m");
                        }
                        print!("\x1b[{}m", bg);
                        in_block = true;
                    }
                    print!(" ");
                } else {
                    if in_block {
                        print!("\x1b[49m\x1b(B\x1b[m");
                        in_block = false;
                    }
                    print!(" ");
                }
            }
            if in_block {
                print!("\x1b[49m\x1b(B\x1b[m");
            }
            x += 8;
        }
    }
    print!("\x1b[{}m", fg);
}

fn term_size() -> (usize, usize) {
    let cols = env::var("COLUMNS").ok().and_then(|s| s.parse().ok()).unwrap_or(80);
    let rows = env::var("LINES").ok().and_then(|s| s.parse().ok()).unwrap_or(24);
    (cols, rows)
}

fn current_strings(opts: &Opts) -> (String, String) {
    if opts.utc {
        let now = Utc::now();
        let mut hour = now.hour();
        if opts.twelve {
            hour %= 12;
            if hour == 0 { hour = 12; }
        }
        let time = if opts.seconds {
            format!("{:02}:{:02}:{:02}", hour, now.minute(), now.second())
        } else {
            format!("{:02}:{:02}", hour, now.minute())
        };
        let date = now.format(&opts.date_fmt).to_string();
        (time, date)
    } else {
        let now = Local::now();
        let mut hour = now.hour();
        if opts.twelve {
            hour %= 12;
            if hour == 0 { hour = 12; }
        }
        let time = if opts.seconds {
            format!("{:02}:{:02}:{:02}", hour, now.minute(), now.second())
        } else {
            format!("{:02}:{:02}", hour, now.minute())
        };
        let date = now.format(&opts.date_fmt).to_string();
        (time, date)
    }
}

fn draw_frame(width: usize, height: usize, row: usize, col: usize) {
    move_to(row, col);
    print!("\x1b(0l{}k\x1b(B", "q".repeat(width.saturating_sub(2)));
    for y in 1..height.saturating_sub(1) {
        move_to(row + y, col);
        print!("\x1b(0x\x1b(B");
        move_to(row + y, col + width.saturating_sub(1));
        print!("\x1b(0x\x1b(B");
    }
    move_to(row + height.saturating_sub(1), col);
    print!("\x1b(0m{}j\x1b(B", "q".repeat(width.saturating_sub(2)));
}

fn run(opts: Opts) -> io::Result<()> {
    let term = env::var("TERM").unwrap_or_else(|_| "unknown".to_string());
    if term == "unknown" || term.is_empty() {
        println!("Error opening terminal: unknown.");
        std::process::exit(1);
    }
    let mut out = io::stdout();
    print!("\x1b[?1049h\x1b[22;0;0t\x1b[1;24r\x1b(B\x1b[m\x1b[4l\x1b[?7h\x1b[?1h\x1b=\x1b[39;49m\x1b[?25l\x1b[39;49m\x1b(B\x1b[m\x1b[H\x1b[2J");
    let sleep = Duration::new(opts.delay, opts.nsdelay);
    loop {
        let (time, date) = current_strings(&opts);
        let (cols, rows) = term_size();
        let w = time.len() * 8 - 2;
        let h = if opts.hide_date { 5 } else { 7 };
        let mut row = 2usize;
        let mut col = 2usize;
        if opts.center {
            row = rows.saturating_sub(h) / 2 + 1;
            col = cols.saturating_sub(w) / 2 + 1;
        }
        print!("\x1b[H\x1b[2J");
        let draw_row = if opts.box_ { row + 1 } else { row };
        let draw_col = if opts.box_ { col + 1 } else { col };
        if opts.box_ {
            draw_frame(w + 4, h + 2, row, col);
        }
        draw_big(&time, draw_row, draw_col, &opts);
        if !opts.hide_date {
            let (fg, _) = color_codes(&opts);
            let dcol = draw_col + w.saturating_sub(date.len()) / 2;
            move_to(draw_row + 6, dcol);
            print!("\x1b[{}m{}\x1b[39m\x1b(B\x1b[m", fg, date);
        }
        out.flush()?;
        thread::sleep(sleep);
    }
}

fn main() {
    let opts = parse();
    let _ = run(opts);
}
