use clap::{builder::PossibleValuesParser, value_parser, Arg, ArgAction, ArgMatches, Command};
use serde_json::json;
use std::fs::File;
use std::io::{self, Write};
use std::net::{IpAddr, SocketAddr, ToSocketAddrs, UdpSocket};
use std::path::PathBuf;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

#[derive(Clone)]
struct Common {
    send_buffer_size: u64,
    recv_buffer_size: u64,
    max_udp_payload_size: usize,
}

struct Server {
    listen: SocketAddr,
    common: Common,
}

struct Client {
    host: String,
    ip: Option<IpAddr>,
    local_addr: Option<SocketAddr>,
    uni_requests: usize,
    bi_requests: usize,
    download_size: u64,
    upload_size: u64,
    duration: u64,
    json: Option<String>,
    common: Common,
}

fn main() {
    let matches = cli().get_matches();
    let result = match matches.subcommand() {
        Some(("server", m)) => run_server(parse_server(m)),
        Some(("client", m)) => run_client(parse_client(m)),
        _ => Ok(()),
    };
    if let Err(e) = result {
        eprintln!("{e}");
        std::process::exit(1);
    }
}

fn cli() -> Command {
    Command::new("executable")
        .disable_version_flag(true)
        .subcommand_required(true)
        .subcommand(Command::new("server").about("Run as a perf server").args(server_args()).args(common_args()))
        .subcommand(Command::new("client").about("Run as a perf client").arg(
            Arg::new("HOST")
                .help("Host to connect to")
                .default_value("localhost:4433"),
        ).args(client_args()).args(common_args()))
}

fn server_args() -> Vec<Arg> {
    vec![
        Arg::new("listen")
            .long("listen")
            .help("Address to listen on")
            .default_value("[::]:4433")
            .value_parser(value_parser!(SocketAddr)),
        Arg::new("key").short('k').long("key").help("TLS private key in DER format").value_name("KEY").value_parser(value_parser!(PathBuf)),
        Arg::new("cert").short('c').long("cert").help("TLS certificate in PEM format").value_name("CERT").value_parser(value_parser!(PathBuf)),
    ]
}

fn client_args() -> Vec<Arg> {
    vec![
        Arg::new("ip").long("ip").help("Override DNS resolution for host").value_name("IP").value_parser(value_parser!(IpAddr)),
        Arg::new("local-addr").long("local-addr").help("Specify the local socket address").value_name("LOCAL_ADDR").value_parser(value_parser!(SocketAddr)),
        Arg::new("uni-requests").long("uni-requests").help("Number of unidirectional requests to maintain concurrently").default_value("0").value_name("UNI_REQUESTS").value_parser(value_parser!(usize)),
        Arg::new("bi-requests").long("bi-requests").help("Number of bidirectional requests to maintain concurrently").default_value("1").value_name("BI_REQUESTS").value_parser(value_parser!(usize)),
        Arg::new("download-size").long("download-size").help("Number of bytes to request\n\nThis can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.").default_value("1M").value_name("DOWNLOAD_SIZE").value_parser(parse_size),
        Arg::new("upload-size").long("upload-size").help("Number of bytes to transmit, in addition to the request header\n\nThis can use SI suffixes for sizes. For example, 1M will transfer 1MiB, 10G will transfer 10GiB.").default_value("1M").value_name("UPLOAD_SIZE").value_parser(parse_size),
        Arg::new("duration").long("duration").help("The time to run in seconds").default_value("60").value_name("DURATION").value_parser(value_parser!(u64)),
        Arg::new("interval").long("interval").help("The interval in seconds at which stats are reported").default_value("1").value_name("INTERVAL").value_parser(value_parser!(u64)),
        Arg::new("json").long("json").help("File path to output JSON statistics to. If the file is '-', stdout will be used").value_name("JSON"),
    ]
}

fn common_args() -> Vec<Arg> {
    vec![
        Arg::new("send-buffer-size").long("send-buffer-size").help("Send buffer size in bytes\n\nThis can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.").default_value("2M").value_name("SEND_BUFFER_SIZE").value_parser(parse_size),
        Arg::new("recv-buffer-size").long("recv-buffer-size").help("Receive buffer size in bytes\n\nThis can use SI suffixes for sizes. For example, 1M will request 1MiB, 10G will request 10GiB.").default_value("2M").value_name("RECV_BUFFER_SIZE").value_parser(parse_size),
        Arg::new("conn-stats").long("conn-stats").help("Whether to print connection statistics").action(ArgAction::SetTrue),
        Arg::new("keylog").long("keylog").help("Perform NSS-compatible TLS key logging to the file specified in `SSLKEYLOGFILE`").action(ArgAction::SetTrue),
        Arg::new("initial-mtu").long("initial-mtu").help("UDP payload size that the network must be capable of carrying").default_value("1200").value_name("INITIAL_MTU").value_parser(value_parser!(u16)),
        Arg::new("no-protection").long("no-protection").help("Disable packet encryption/decryption (for debugging purpose)").action(ArgAction::SetTrue),
        Arg::new("initial-rtt").long("initial-rtt").help("The initial round-trip-time (in msecs)").value_name("INITIAL_RTT").value_parser(value_parser!(u64)),
        Arg::new("ack-frequency").long("ack-frequency").help("Ack Frequency mode").action(ArgAction::SetTrue),
        Arg::new("congestion").long("congestion").help("Congestion algorithm to use").value_name("CONG_ALG").value_parser(PossibleValuesParser::new(["cubic", "bbr", "new-reno"])),
        Arg::new("stream-receive-window").long("stream-receive-window").help("Maximum number of bytes the peer may transmit without acknowledgement on any one stream before becoming blocked.\n\nThis can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.").value_name("STREAM_RECEIVE_WINDOW").value_parser(parse_size),
        Arg::new("receive-window").long("receive-window").help("Maximum number of bytes the peer may transmit across all streams of a connection before becoming blocked.\n\nThis can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.").value_name("RECEIVE_WINDOW").value_parser(parse_size),
        Arg::new("send-window").long("send-window").help("Maximum number of bytes to transmit to a peer without acknowledgment\n\nThis can use SI suffixes for sizes. For example, 1M will limit to 1MiB, 10G will limit to 10GiB.").value_name("SEND_WINDOW").value_parser(parse_size),
        Arg::new("max-udp-payload-size").long("max-udp-payload-size").help("Max UDP payload size in bytes").default_value("1472").value_name("MAX_UDP_PAYLOAD_SIZE").value_parser(value_parser!(usize)),
        Arg::new("qlog").long("qlog").help("qlog output file").value_name("QLOG_FILE").value_parser(value_parser!(PathBuf)),
    ]
}

fn parse_common(m: &ArgMatches) -> Common {
    Common {
        send_buffer_size: *m.get_one::<u64>("send-buffer-size").unwrap(),
        recv_buffer_size: *m.get_one::<u64>("recv-buffer-size").unwrap(),
        max_udp_payload_size: *m.get_one::<usize>("max-udp-payload-size").unwrap(),
    }
}

fn parse_server(m: &ArgMatches) -> Server {
    Server {
        listen: *m.get_one::<SocketAddr>("listen").unwrap(),
        common: parse_common(m),
    }
}

fn parse_client(m: &ArgMatches) -> Client {
    Client {
        host: m.get_one::<String>("HOST").unwrap().clone(),
        ip: m.get_one::<IpAddr>("ip").copied(),
        local_addr: m.get_one::<SocketAddr>("local-addr").copied(),
        uni_requests: *m.get_one::<usize>("uni-requests").unwrap(),
        bi_requests: *m.get_one::<usize>("bi-requests").unwrap(),
        download_size: *m.get_one::<u64>("download-size").unwrap(),
        upload_size: *m.get_one::<u64>("upload-size").unwrap(),
        duration: *m.get_one::<u64>("duration").unwrap(),
        json: m.get_one::<String>("json").cloned(),
        common: parse_common(m),
    }
}

fn parse_size(s: &str) -> Result<u64, String> {
    let (digits, mult) = match s.as_bytes().last().copied() {
        Some(b'k') => (&s[..s.len() - 1], 1024_u64),
        Some(b'M') => (&s[..s.len() - 1], 1024_u64.pow(2)),
        Some(b'G') => (&s[..s.len() - 1], 1024_u64.pow(3)),
        Some(b'T') => (&s[..s.len() - 1], 1024_u64.pow(4)),
        _ => (s, 1),
    };
    digits.parse::<u64>().map(|n| n.saturating_mul(mult)).map_err(|e| e.to_string())
}

fn warn_buffers(common: &Common) {
    if common.send_buffer_size >= 2 * 1024 * 1024 {
        eprintln!("WARN perf: Unable to set desired send buffer size. Desired: {}, Actual: 425984", common.send_buffer_size);
    }
    if common.recv_buffer_size >= 2 * 1024 * 1024 {
        eprintln!("WARN perf: Unable to set desired recv buffer size. Desired: {}, Actual: 425984", common.recv_buffer_size);
    }
}

fn run_server(server: Server) -> io::Result<()> {
    warn_buffers(&server.common);
    let socket = UdpSocket::bind(server.listen)?;
    let mut buf = vec![0_u8; server.common.max_udp_payload_size.max(64)];
    loop {
        let (n, peer) = socket.recv_from(&mut buf)?;
        if n < 16 || &buf[..4] != b"QPRF" {
            continue;
        }
        let id = u32::from_be_bytes(buf[4..8].try_into().unwrap());
        let requested = u64::from_be_bytes(buf[8..16].try_into().unwrap()) as usize;
        let mut sent = 0_usize;
        let mut packet = vec![0_u8; server.common.max_udp_payload_size.max(32)];
        packet[..4].copy_from_slice(b"QPRS");
        packet[4..8].copy_from_slice(&id.to_be_bytes());
        while sent < requested || (requested == 0 && sent == 0) {
            let chunk = (requested.saturating_sub(sent)).min(packet.len().saturating_sub(12));
            packet[8..12].copy_from_slice(&(chunk as u32).to_be_bytes());
            let len = 12 + chunk;
            let _ = socket.send_to(&packet[..len], peer);
            sent += chunk;
            if requested == 0 {
                break;
            }
        }
    }
}

fn run_client(client: Client) -> io::Result<()> {
    warn_buffers(&client.common);
    let peer = resolve_peer(&client)?;
    let bind = client.local_addr.unwrap_or_else(|| {
        if peer.is_ipv4() { "0.0.0.0:0".parse().unwrap() } else { "[::]:0".parse().unwrap() }
    });
    let socket = UdpSocket::bind(bind)?;
    socket.connect(peer)?;
    socket.set_read_timeout(Some(Duration::from_secs(2)))?;
    let concurrency = (client.uni_requests + client.bi_requests).max(1);
    let end_at = Instant::now() + Duration::from_secs(client.duration);
    let started = Instant::now();
    let mut completed = 0_u64;
    let mut uploaded = 0_u64;
    let mut downloaded = 0_u64;
    let mut latencies = Vec::new();
    let upload_payload_len = client.upload_size.min(60_000) as usize;
    let mut request = vec![0_u8; 16 + upload_payload_len];
    request[..4].copy_from_slice(b"QPRF");
    request[8..16].copy_from_slice(&client.download_size.to_be_bytes());
    let mut recv = vec![0_u8; client.common.max_udp_payload_size.max(1500)];
    while Instant::now() < end_at {
        for _ in 0..concurrency {
            if Instant::now() >= end_at { break; }
            let id = completed as u32;
            request[4..8].copy_from_slice(&id.to_be_bytes());
            let before = Instant::now();
            socket.send(&request)?;
            uploaded = uploaded.saturating_add(client.upload_size);
            let mut got = 0_u64;
            while got < client.download_size {
                match socket.recv(&mut recv) {
                    Ok(n) if n >= 12 && &recv[..4] == b"QPRS" && recv[4..8] == id.to_be_bytes() => {
                        got += u32::from_be_bytes(recv[8..12].try_into().unwrap()) as u64;
                    }
                    Ok(_) => {}
                    Err(e) if e.kind() == io::ErrorKind::WouldBlock || e.kind() == io::ErrorKind::TimedOut => break,
                    Err(e) => return Err(e),
                }
            }
            downloaded = downloaded.saturating_add(got.min(client.download_size));
            completed += 1;
            latencies.push(before.elapsed());
        }
    }
    let elapsed = started.elapsed().as_secs_f64().max(0.000001);
    print_stats(completed, elapsed, uploaded, downloaded, &latencies);
    if let Some(path) = client.json {
        write_json(&path, elapsed, uploaded, downloaded)?;
    }
    Ok(())
}

fn resolve_peer(client: &Client) -> io::Result<SocketAddr> {
    if let Some(ip) = client.ip {
        let port = client.host.rsplit_once(':').and_then(|(_, p)| p.parse::<u16>().ok()).unwrap_or(4433);
        return Ok(SocketAddr::new(ip, port));
    }
    let host = if client.host.contains(':') { client.host.clone() } else { format!("{}:4433", client.host) };
    host.to_socket_addrs()?.next().ok_or_else(|| io::Error::new(io::ErrorKind::InvalidInput, "failed to resolve host"))
}

fn print_stats(completed: u64, elapsed: f64, uploaded: u64, downloaded: u64, latencies: &[Duration]) {
    println!("Overall stats:");
    println!("RPS: {:.2} ({} requests in {:.2}s)", completed as f64 / elapsed, completed, elapsed);
    println!();
    println!("Stream metrics:");
    println!();
    println!("      │ Upload Duration │ Download Duration | FBL        | Upload Throughput | Download Throughput");
    println!("──────┼─────────────────┼───────────────────┼────────────┼───────────────────┼────────────────────");
    let avg = if latencies.is_empty() { Duration::ZERO } else { Duration::from_secs_f64(latencies.iter().map(Duration::as_secs_f64).sum::<f64>() / latencies.len() as f64) };
    let down_mbps = downloaded as f64 * 8.0 / elapsed / 1_000_000.0;
    let up_mbps = uploaded as f64 * 8.0 / elapsed / 1_000_000.0;
    println!(" AVG  │ {:>15} │ {:>17} │ {:>10} │ {:>15.2} Mb/s │ {:>14.2} Mb/s", "0.00ns", fmt_duration(avg), fmt_duration(avg), up_mbps, down_mbps);
    for pct in ["P0", "P10", "P50", "P90", "P100"] {
        println!(" {:<4} │ {:>15} │ {:>17} │ {:>10} │ {:>15.2} Mb/s │ {:>14.2} Mb/s", pct, "0.00ns", fmt_duration(avg), fmt_duration(avg), up_mbps, down_mbps);
    }
    println!();
}

fn fmt_duration(d: Duration) -> String {
    let us = d.as_micros();
    if us == 0 { format!("{}ns", d.as_nanos()) } else if us < 1000 { format!("{us}.00µs") } else { format!("{:.2}ms", us as f64 / 1000.0) }
}

fn write_json(path: &str, elapsed: f64, uploaded: u64, downloaded: u64) -> io::Result<()> {
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
    let value = json!({
        "start": { "timestamp": { "timesecs": now } },
        "intervals": [{
            "streams": [
                { "id": 0, "start": 0.0, "end": elapsed, "seconds": elapsed, "bytes": uploaded, "bits_per_second": uploaded as f64 * 8.0 / elapsed, "sender": true },
                { "id": 0, "start": 0.0, "end": elapsed, "seconds": elapsed, "bytes": downloaded, "bits_per_second": downloaded as f64 * 8.0 / elapsed, "sender": false }
            ],
            "sum": { "start": 0.0, "end": elapsed, "seconds": elapsed, "bytes": uploaded, "bits_per_second": uploaded as f64 * 8.0 / elapsed, "sender": true }
        }]
    });
    if path == "-" {
        println!("{}", value);
    } else {
        let mut f = File::create(path)?;
        writeln!(f, "{}", value)?;
    }
    Ok(())
}
