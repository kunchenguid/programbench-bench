use base64::Engine;
use chrono::{Datelike, Duration, Local, NaiveDate, TimeZone};
use regex::Regex;
use sha2::{Digest, Sha256, Sha512};
use std::cmp::Ordering;
use std::collections::VecDeque;
use std::env;
use std::ffi::OsStr;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::os::unix::fs::{FileTypeExt, MetadataExt};
use std::path::{Path, PathBuf};

#[derive(Clone, Debug)]
struct Root { path: PathBuf, min_depth: usize, max_depth: Option<usize>, follow: bool }
#[derive(Clone, Debug)]
struct Query { columns: Vec<String>, roots: Vec<Root>, where_tokens: Vec<String>, order: Vec<(String,bool)>, limit: Option<usize>, offset: usize, format: String, group: Vec<String> }
#[derive(Clone, Debug)]
struct Entry { root: PathBuf, full: PathBuf, rel: PathBuf, md: fs::Metadata, lmd: fs::Metadata }

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() { repl(); return; }
    let mut filtered = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--help" || a == "-h" || a == "/?" || a == "/h" { print_help(); return; }
        if a == "--interactive" || a == "-i" || a == "/i" { repl(); return; }
        if a == "--config" || a == "-c" || a == "/config" { i += 2; continue; }
        if a == "--nocolor" || a == "--no-color" || a == "--no-errors" || a == "--us-dates" { i += 1; continue; }
        filtered.push(a.clone()); i += 1;
    }
    args = filtered;
    if args.is_empty() { repl(); return; }
    let query = args.join(" ");
    match run_query(&query) {
        Ok(s) => { print!("{}", s); }
        Err(e) => { eprintln!("{}", e); std::process::exit(2); }
    }
}

fn repl() {
    let stdin = io::stdin();
    loop {
        print!("fselect> "); let _ = io::stdout().flush();
        let mut line = String::new();
        if stdin.read_line(&mut line).unwrap_or(0) == 0 { break; }
        let line = line.trim();
        if line.eq_ignore_ascii_case("exit") || line.eq_ignore_ascii_case("quit") { break; }
        if line.eq_ignore_ascii_case("pwd") { println!("{}", env::current_dir().unwrap().display()); continue; }
        if line.to_ascii_lowercase().starts_with("cd ") { if let Err(e)=env::set_current_dir(line[3..].trim()) { eprintln!("{}", e); } continue; }
        if line.eq_ignore_ascii_case("help") { print_help(); continue; }
        if !line.is_empty() { match run_query(line) { Ok(s)=>print!("{}",s), Err(e)=>eprintln!("{}",e) } }
    }
}

fn print_help() {
    println!("fselect \x1b[33m0.10.0\x1b[0m");
    println!("Find files with SQL-like queries.");
    println!("\x1b[4;36mhttps://github.com/jhspetersson/fselect\x1b[0m\n");
    println!("Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]");
}

fn run_query(s: &str) -> Result<String,String> {
    let q = parse_query(s)?;
    let mut entries = Vec::new();
    for r in &q.roots { walk_root(r, &mut entries); }
    entries.retain(|e| eval_where(&q.where_tokens, e));
    let mut rows: Vec<Vec<String>>;
    if q.columns.iter().any(|c| is_aggregate(c)) {
        rows = vec![q.columns.iter().map(|c| aggregate(c, &entries)).collect()];
    } else if !q.group.is_empty() {
        let mut seen: Vec<Vec<String>> = Vec::new();
        for e in &entries { let key: Vec<String> = q.group.iter().map(|c| eval_expr(c,e)).collect(); if !seen.contains(&key) { seen.push(key); } }
        rows = seen;
    } else {
        if !q.order.is_empty() { sort_entries(&mut entries, &q.order); }
        let start = q.offset.min(entries.len()); let end = q.limit.map(|l| (start+l).min(entries.len())).unwrap_or(entries.len());
        rows = entries[start..end].iter().map(|e| q.columns.iter().map(|c| eval_expr(c, e)).collect()).collect();
    }
    if q.columns.iter().any(|c| is_aggregate(c)) {
        if !q.order.is_empty() { /* no-op */ }
        let start = q.offset.min(rows.len()); let end = q.limit.map(|l| (start+l).min(rows.len())).unwrap_or(rows.len()); rows = rows[start..end].to_vec();
    }
    Ok(format_rows(&rows, &q.columns, &q.format))
}

fn tokenize(s: &str) -> Vec<String> {
    let mut out=Vec::new(); let mut cur=String::new(); let mut q: Option<char>=None;
    let mut chars=s.chars().peekable();
    while let Some(c)=chars.next() {
        if let Some(qc)=q { if c==qc { q=None; } else { cur.push(c); } continue; }
        match c {
            '\''|'"'|'`' => { q=Some(c); },
            ' '| '\t' | '\n' | '\r' => { if !cur.is_empty(){out.push(cur.clone());cur.clear();} },
            ','|'('|')'|'{'|'}' => { if !cur.is_empty(){out.push(cur.clone());cur.clear();} out.push(if c=='{'{"(".into()}else if c=='}'{")".into()}else{c.to_string()}); },
            '<'|'>'|'='|'!'|'~' => { if !cur.is_empty(){out.push(cur.clone());cur.clear();} let mut op=c.to_string(); while let Some(n)=chars.peek(){ if "<>=!~".contains(*n){op.push(*n); chars.next();} else {break;} } out.push(op); },
            _ => cur.push(c),
        }
    }
    if !cur.is_empty(){out.push(cur);} out
}
fn lower(t:&str)->String{t.to_ascii_lowercase()}
fn is_kw(t:&str, kws:&[&str])->bool{kws.iter().any(|k| lower(t)==*k)}
fn is_clause(ts:&[String], i:usize, kws:&[&str])->bool{
    if i>=ts.len(){return false;}
    let l=lower(&ts[i]);
    if (l=="group" || l=="order") && kws.contains(&l.as_str()) { return i+1<ts.len() && lower(&ts[i+1])=="by"; }
    kws.iter().any(|k| *k==l)
}

fn parse_query(s:&str)->Result<Query,String>{
    let t=tokenize(s); if t.is_empty(){return Err("Empty query".into())}
    let mut i=0; if is_kw(&t[i], &["select"]){i+=1;}
    let mut col_t=Vec::new(); while i<t.len() && !is_clause(&t, i, &["from","where","group","order","limit","offset","into"]){col_t.push(t[i].clone()); i+=1;}
    let columns=split_list(&col_t); if columns.is_empty(){return Err("No columns selected".into())}
    let mut roots=Vec::new();
    if i<t.len() && is_kw(&t[i], &["from"]){ i+=1; let mut cur=Vec::new(); while i<t.len() && !is_clause(&t, i, &["where","group","order","limit","offset","into"]){ if t[i]=="," { if !cur.is_empty(){roots.push(parse_root(&cur)); cur.clear();} } else {cur.push(t[i].clone());} i+=1;} if !cur.is_empty(){roots.push(parse_root(&cur));} }
    if roots.is_empty(){roots.push(Root{path:PathBuf::from("."),min_depth:0,max_depth:None,follow:false});}
    let mut where_tokens=Vec::new(); if i<t.len() && is_kw(&t[i], &["where"]){ i+=1; while i<t.len() && !is_clause(&t, i, &["group","order","limit","offset","into"]){where_tokens.push(t[i].clone()); i+=1;} }
    let mut group=Vec::new(); if i<t.len() && is_clause(&t, i, &["group"]){ i+=1; if i<t.len() && is_kw(&t[i], &["by"]){i+=1;} let mut g=Vec::new(); while i<t.len() && !is_clause(&t, i, &["order","limit","offset","into"]){g.push(t[i].clone()); i+=1;} group=split_list(&g); }
    let mut order=Vec::new(); if i<t.len() && is_clause(&t, i, &["order"]){ i+=1; if i<t.len() && is_kw(&t[i], &["by"]){i+=1;} let mut cur=Vec::new(); while i<t.len() && !is_clause(&t, i, &["limit","offset","into"]){ if t[i]=="," { push_order(&mut order,&cur); cur.clear(); } else {cur.push(t[i].clone());} i+=1;} if !cur.is_empty(){push_order(&mut order,&cur);} }
    let mut limit=None; let mut offset=0; let mut format="tabs".to_string();
    while i<t.len(){ if is_kw(&t[i], &["limit"]){i+=1; if i<t.len(){limit=t[i].parse().ok(); i+=1;}} else if is_kw(&t[i], &["offset"]){i+=1; if i<t.len(){offset=t[i].parse().unwrap_or(0); i+=1;}} else if is_kw(&t[i], &["into"]){i+=1; if i<t.len(){format=lower(&t[i]); i+=1;}} else {i+=1;} }
    Ok(Query{columns,roots,where_tokens,order,limit,offset,format,group})
}
fn split_list(ts:&[String])->Vec<String>{ let mut res=Vec::new(); let mut cur=Vec::new(); let mut depth=0; for x in ts { if x=="("{depth+=1;} if x==")"&&depth>0{depth-=1;} if x=="," && depth==0 { if !cur.is_empty(){res.push(cur.join(" ")); cur.clear();} } else {cur.push(x.clone());} } if !cur.is_empty(){ if !cur.contains(&",".to_string()) && cur.len()>1 { // optional comma style, but keep function args intact
            let mut tmp=Vec::new(); let mut one=Vec::new(); let mut d=0; for x in cur { if x=="("{d+=1;} if x==")"&&d>0{d-=1;} if d==0 && x!="(" && x!=")" && !one.is_empty() { tmp.push(one.join(" ")); one=vec![x]; } else { one.push(x); } } if !one.is_empty(){tmp.push(one.join(" "));} res.extend(tmp);
        } else {res.push(cur.join(" "));} } res.into_iter().map(|s|s.trim().to_string()).filter(|s|!s.is_empty()).collect() }
fn parse_root(ts:&[String])->Root{ let mut path=PathBuf::from(ts.get(0).cloned().unwrap_or_else(||".".into())); let mut min_depth=0; let mut max_depth=None; let mut follow=false; let mut i=1; while i<ts.len(){ match lower(&ts[i]).as_str(){"mindepth"=>{i+=1;if i<ts.len(){min_depth=ts[i].parse().unwrap_or(0);}},"maxdepth"|"depth"=>{i+=1;if i<ts.len(){max_depth=ts[i].parse().ok();}},"symlinks"|"sym"=>follow=true,"as"=>{i+=1;}, _=>{} } i+=1;} if path.as_os_str().is_empty(){path=PathBuf::from(".");} Root{path,min_depth,max_depth,follow} }
fn push_order(order:&mut Vec<(String,bool)>, ts:&[String]){ if ts.is_empty(){return;} let mut asc=true; let mut col=ts.join(" "); if let Some(last)=ts.last(){ if is_kw(last,&["desc"]){asc=false; col=ts[..ts.len()-1].join(" ");} else if is_kw(last,&["asc"]){col=ts[..ts.len()-1].join(" ");} } order.push((col.trim().to_string(),asc)); }

fn walk_root(root:&Root, out:&mut Vec<Entry>){ let base=root.path.clone(); let mut q=VecDeque::new(); q.push_back((base.clone(),0usize)); while let Some((p,depth))=q.pop_front(){ let rd=match fs::read_dir(&p){Ok(r)=>r,Err(_)=>continue}; let mut ents:Vec<_>=rd.filter_map(Result::ok).collect(); ents.sort_by_key(|e| e.file_name()); for de in ents { let full=de.path(); let lmd=match fs::symlink_metadata(&full){Ok(m)=>m,Err(_)=>continue}; let md=if root.follow { fs::metadata(&full).unwrap_or_else(|_|lmd.clone()) } else { lmd.clone() }; let child_depth=depth+1; if child_depth>=root.min_depth && root.max_depth.map(|m| child_depth<=m).unwrap_or(true) { let rel=full.strip_prefix(&base).unwrap_or(&full).to_path_buf(); out.push(Entry{root:base.clone(),full:full.clone(),rel,md:md.clone(),lmd:lmd.clone()}); }
            if md.is_dir() && root.max_depth.map(|m| child_depth < m).unwrap_or(true) && (root.follow || !lmd.file_type().is_symlink()) { q.push_back((full,child_depth)); }
        } }
}

fn sort_entries(es:&mut [Entry], order:&[(String,bool)]){ es.sort_by(|a,b|{ for (c,asc) in order { let va=if let Ok(n)=c.parse::<usize>(){ eval_expr(&n.to_string(),a)} else {eval_expr(c,a)}; let vb=if let Ok(n)=c.parse::<usize>(){ eval_expr(&n.to_string(),b)} else {eval_expr(c,b)}; let ord=cmp_vals(&va,&vb); if ord!=Ordering::Equal {return if *asc{ord}else{ord.reverse()};} } Ordering::Equal }); }
fn cmp_vals(a:&str,b:&str)->Ordering{ match (a.parse::<f64>(), b.parse::<f64>()) { (Ok(x),Ok(y))=>x.partial_cmp(&y).unwrap_or(Ordering::Equal), _=>a.cmp(b) } }

fn eval_where(ts:&[String], e:&Entry)->bool{ if ts.is_empty(){return true;} let mut parts:Vec<Vec<String>>=Vec::new(); let mut cur=Vec::new(); for x in ts { if is_kw(x,&["or"]){parts.push(cur);cur=Vec::new();} else {cur.push(x.clone());} } parts.push(cur); parts.iter().any(|p| eval_and(p,e)) }
fn eval_and(ts:&[String], e:&Entry)->bool{ let mut cur=Vec::new(); let mut ok=true; for x in ts { if is_kw(x,&["and"]){ ok &= eval_cond(&cur,e); cur=Vec::new(); } else {cur.push(x.clone());} } ok & eval_cond(&cur,e) }
fn eval_cond(ts:&[String], e:&Entry)->bool{ if ts.is_empty(){return true;} if ts.len()==1 { return truthy(&eval_expr(&ts[0],e)); }
    if ts.len()>=5 && is_kw(&ts[1], &["between"]) { let v=eval_expr(&ts[0],e); let a=parse_comp(&ts[2]); let b=parse_comp(&ts[4]); let x=parse_comp(&v); return x>=a && x<=b; }
    if ts.len()>=4 && is_kw(&ts[1], &["in"]) { let v=eval_expr(&ts[0],e); return ts[2..].iter().any(|x| x!="," && x!="(" && x!=")" && strip(x)==v); }
    let col=&ts[0]; let op=lower(&ts[1]); let rhs=ts[2..].join(" "); let lv=eval_expr(col,e); let rv=strip(&rhs);
    if matches!(lower(col).as_str(), "modified"|"created"|"accessed") { if let Some(b)=date_compare(&lv,&rv,&op){ return b; } }
    match op.as_str(){"="|"=="|"eq"=>match_like_or_eq(&lv,&rv),"==="|"eeq"=>lv==rv,"!="|"<>"|"ne"=>!match_like_or_eq(&lv,&rv),"!=="|"ene"=>lv!=rv,">"|"gt"=>parse_comp(&lv)>parse_comp(&rv),">="|"gte"|"ge"=>parse_comp(&lv)>=parse_comp(&rv),"<"|"lt"=>parse_comp(&lv)<parse_comp(&rv),"<="|"lte"|"le"=>parse_comp(&lv)<=parse_comp(&rv),"=~"|"~="|"regexp"|"rx"=>Regex::new(&rv).map(|r|r.is_match(&lv)).unwrap_or(false),"!=~"|"!~="|"notrx"=>!Regex::new(&rv).map(|r|r.is_match(&lv)).unwrap_or(false),"like"=>like(&lv,&rv),"notlike"=>!like(&lv,&rv), _=>false}
}

fn date_compare(lv:&str, rv:&str, op:&str)->Option<bool>{
    let lhs = parse_datetimeish(lv)?;
    let (rhs_start, rhs_end) = parse_date_literal(rv)?;
    Some(match op {
        "="|"=="|"eq" => lhs >= rhs_start && lhs <= rhs_end,
        "!="|"<>"|"ne" => !(lhs >= rhs_start && lhs <= rhs_end),
        ">"|"gt" => lhs > rhs_end,
        ">="|"gte"|"ge" => lhs >= rhs_start,
        "<"|"lt" => lhs < rhs_start,
        "<="|"lte"|"le" => lhs <= rhs_end,
        _ => return None,
    })
}
fn parse_datetimeish(s:&str)->Option<i64>{
    Local.datetime_from_str(s, "%Y-%m-%d %H:%M:%S").ok().map(|d| d.timestamp())
}
fn parse_date_literal(s:&str)->Option<(i64,i64)>{
    let l=s.to_ascii_lowercase();
    let d = if l=="today" { Local::now().date_naive() }
        else if l=="yesterday" { Local::now().date_naive() - Duration::days(1) }
        else if l=="tomorrow" { Local::now().date_naive() + Duration::days(1) }
        else { NaiveDate::parse_from_str(s, "%Y-%m-%d").ok()? };
    let start = Local.from_local_datetime(&d.and_hms_opt(0,0,0)?).single()?.timestamp();
    let end = Local.from_local_datetime(&d.and_hms_opt(23,59,59)?).single()?.timestamp();
    Some((start,end))
}
fn truthy(s:&str)->bool{ matches!(lower(s).as_str(),"true"|"1"|"yes") }
fn strip(s:&str)->String{ let mut x=s.trim().to_string(); if x.starts_with('(')&&x.ends_with(')'){x=x[1..x.len()-1].to_string();} x }
fn parse_comp(s:&str)->f64{ let x=s.trim().to_ascii_lowercase(); let (num,mul)=if let Some(n)=x.strip_suffix("tib").or_else(||x.strip_suffix('t')){(n,1024f64.powi(4))}else if let Some(n)=x.strip_suffix("tb"){(n,1000f64.powi(4))}else if let Some(n)=x.strip_suffix("gib").or_else(||x.strip_suffix('g')){(n,1024f64.powi(3))}else if let Some(n)=x.strip_suffix("gb"){(n,1000f64.powi(3))}else if let Some(n)=x.strip_suffix("mib").or_else(||x.strip_suffix('m')){(n,1024f64.powi(2))}else if let Some(n)=x.strip_suffix("mb"){(n,1000f64.powi(2))}else if let Some(n)=x.strip_suffix("kib").or_else(||x.strip_suffix('k')){(n,1024f64)}else if let Some(n)=x.strip_suffix("kb"){(n,1000f64)}else{(x.as_str(),1.0)}; num.parse::<f64>().unwrap_or(0.0)*mul }
fn match_like_or_eq(v:&str, pat:&str)->bool{ if pat.contains('*')||pat.contains('?'){ glob(v,pat) } else { v==pat } }
fn glob(v:&str, pat:&str)->bool{ let mut re=String::from("^"); for c in pat.chars(){ match c {'*'=>re.push_str(".*"),'?'=>re.push('.'), _=>re.push_str(&regex::escape(&c.to_string()))} } re.push('$'); Regex::new(&re).map(|r|r.is_match(v)).unwrap_or(false) }
fn like(v:&str, pat:&str)->bool{ let mut re=String::from("^"); for c in pat.chars(){ match c {'%'=>re.push_str(".*"),'_'=>re.push('.'), _=>re.push_str(&regex::escape(&c.to_string()))} } re.push('$'); Regex::new(&re).map(|r|r.is_match(v)).unwrap_or(false) }

fn eval_expr(expr:&str,e:&Entry)->String{ let ex=expr.trim(); if ex.parse::<usize>().is_ok(){return eval_expr("path",e)} if let Some((f,args))=func(ex){ return eval_func(&f,&args,e); } let l=lower(ex); match l.as_str(){
    "name"=>fname(&e.full),"filename"|"fname"=>stem(&e.full),"ext"|"extension"=>ext(&e.full),"path"=>path_str(&e.rel),"abspath"=>abs_path(&e.full),"dir"|"directory"|"dirname"=>dir_str(e.rel.parent()),"absdir"=>dir_str(e.full.parent()),"size"=>e.lmd.len().to_string(),"fsize"|"hsize"=>format_size(e.lmd.len()),"uid"=>e.lmd.uid().to_string(),"gid"=>e.lmd.gid().to_string(),"user"=>lookup_name("/etc/passwd", e.lmd.uid()),"group"=>lookup_name("/etc/group", e.lmd.gid()),"atime"=>e.lmd.atime().to_string(),"mtime"=>e.lmd.mtime().to_string(),"ctime"=>e.lmd.ctime().to_string(),"accessed"=>fmt_time(e.lmd.atime()),"modified"=>fmt_time(e.lmd.mtime()),"created"=>fmt_time(e.lmd.ctime()),"is_dir"=>e.md.is_dir().to_string(),"is_file"=>e.md.is_file().to_string(),"is_symlink"=>e.lmd.file_type().is_symlink().to_string(),"is_pipe"|"is_fifo"=>e.lmd.file_type().is_fifo().to_string(),"is_char"|"is_character"=>e.lmd.file_type().is_char_device().to_string(),"is_block"=>e.lmd.file_type().is_block_device().to_string(),"is_socket"=>e.lmd.file_type().is_socket().to_string(),"is_hidden"=>fname(&e.full).starts_with('.').to_string(),"is_empty"=>is_empty(e).to_string(),"mode"=>mode_string(e),"device"=>e.lmd.dev().to_string(),"rdev"=>e.lmd.rdev().to_string(),"inode"=>e.lmd.ino().to_string(),"blocks"=>e.lmd.blocks().to_string(),"hardlinks"=>e.lmd.nlink().to_string(),"user_read"=>(e.lmd.mode()&0o400!=0).to_string(),"user_write"=>(e.lmd.mode()&0o200!=0).to_string(),"user_exec"=>(e.lmd.mode()&0o100!=0).to_string(),"user_all"|"user_rwx"=>(e.lmd.mode()&0o700==0o700).to_string(),"group_read"=>(e.lmd.mode()&0o040!=0).to_string(),"group_write"=>(e.lmd.mode()&0o020!=0).to_string(),"group_exec"=>(e.lmd.mode()&0o010!=0).to_string(),"group_all"|"group_rwx"=>(e.lmd.mode()&0o070==0o070).to_string(),"other_read"=>(e.lmd.mode()&0o004!=0).to_string(),"other_write"=>(e.lmd.mode()&0o002!=0).to_string(),"other_exec"=>(e.lmd.mode()&0o001!=0).to_string(),"other_all"|"other_rwx"=>(e.lmd.mode()&0o007==0o007).to_string(),"suid"|"is_suid"=>(e.lmd.mode()&0o4000!=0).to_string(),"sgid"|"is_sgid"=>(e.lmd.mode()&0o2000!=0).to_string(),"sticky"|"is_sticky"=>(e.lmd.mode()&0o1000!=0).to_string(),"is_source"=>is_ext(&ext(&e.full), SOURCE).to_string(),"is_image"=>is_ext(&ext(&e.full), IMAGE).to_string(),"is_audio"=>is_ext(&ext(&e.full), AUDIO).to_string(),"is_video"=>is_ext(&ext(&e.full), VIDEO).to_string(),"is_archive"=>is_ext(&ext(&e.full), ARCHIVE).to_string(),"is_doc"=>is_ext(&ext(&e.full), DOC).to_string(),"is_book"=>is_ext(&ext(&e.full), BOOK).to_string(),"is_font"=>is_ext(&ext(&e.full), FONT).to_string(),"is_shebang"=>starts_with(e,b"#!").to_string(),"line_count"=>line_count(e).to_string(),"is_binary"=>is_binary(e).to_string(),"is_text"=>(!is_binary(e)).to_string(),"mime"=>mime(e),"width"=>image_dim(e).map(|(w,_)|w.to_string()).unwrap_or_default(),"height"=>image_dim(e).map(|(_,h)|h.to_string()).unwrap_or_default(),"current_date"|"cur_date"|"curdate"=>Local::now().format("%Y-%m-%d").to_string(),"current_time"|"cur_time"|"curtime"=>Local::now().format("%H:%M:%S").to_string(),"current_timestamp"|"now"=>Local::now().format("%Y-%m-%d %H:%M:%S").to_string(),"sha1"=>String::new(),"sha2_256"|"sha256"=>hash::<Sha256>(e),"sha2_512"|"sha512"=>hash::<Sha512>(e),"sha3_512"|"sha3"=>String::new(), _=>ex.to_string() }
}
fn func(ex:&str)->Option<(String,Vec<String>)>{ let p=ex.find('(')?; let q=ex.rfind(')')?; let f=lower(ex[..p].trim()); let inside=&ex[p+1..q]; let args=split_list(&tokenize(inside)); Some((f,args)) }
fn eval_func(f:&str,args:&[String],e:&Entry)->String{ let a=args.get(0).map(|s|eval_expr(s,e)).unwrap_or_default(); match f {"lower"|"lowercase"|"lcase"=>a.to_lowercase(),"upper"|"uppercase"|"ucase"=>a.to_uppercase(),"length"|"len"=>a.chars().count().to_string(),"trim"=>a.trim().to_string(),"ltrim"=>a.trim_start().to_string(),"rtrim"=>a.trim_end().to_string(),"to_base64"|"base64"=>base64::engine::general_purpose::STANDARD.encode(a),"from_base64"=>base64::engine::general_purpose::STANDARD.decode(a).ok().and_then(|v|String::from_utf8(v).ok()).unwrap_or_default(),"format_size"|"format_filesize"=>format_size(parse_comp(&a) as u64),"year"=>date_part(&a,0),"month"=>date_part(&a,1),"day"=>date_part(&a,2),"floor"=>format!("{}",parse_comp(&a).floor() as i64),"ceil"|"ceiling"=>format!("{}",parse_comp(&a).ceil() as i64),"round"=>format!("{}",parse_comp(&a).round() as i64),"abs"=>format!("{}",parse_comp(&a).abs()),"hex"=>format!("{:x}",parse_comp(&a) as i64),"oct"=>format!("{:o}",parse_comp(&a) as i64),"bin"=>format!("{:b}",parse_comp(&a) as i64),"coalesce"=>args.iter().map(|x|eval_expr(x,e)).find(|x|!x.is_empty()).unwrap_or_default(), _=>String::new()} }
fn date_part(s:&str,which:u8)->String{ if let Ok(dt)=Local.datetime_from_str(s,"%Y-%m-%d %H:%M:%S"){ match which{0=>dt.year().to_string(),1=>dt.month().to_string(),_=>dt.day().to_string()} } else {String::new()} }
fn is_aggregate(c:&str)->bool{ func(c).map(|(f,_)|matches!(f.as_str(),"count"|"min"|"max"|"sum"|"avg"|"stddev_pop"|"stddev"|"std"|"stddev_samp"|"var_pop"|"variance"|"var_samp")).unwrap_or(false) }
fn aggregate(c:&str, es:&[Entry])->String{ let (f,args)=func(c).unwrap_or((lower(c),vec!["*".into()])); if f=="count"{return es.len().to_string();} let vals:Vec<f64>=es.iter().map(|e|parse_comp(&eval_expr(args.get(0).map(String::as_str).unwrap_or("size"),e))).collect(); if vals.is_empty(){return String::new();} match f.as_str(){"min"=>fmt_num(vals.iter().cloned().fold(f64::INFINITY,f64::min)),"max"=>fmt_num(vals.iter().cloned().fold(f64::NEG_INFINITY,f64::max)),"sum"=>fmt_num(vals.iter().sum()),"avg"=>fmt_num(vals.iter().sum::<f64>()/vals.len() as f64),"var_pop"|"variance"=>{let m=vals.iter().sum::<f64>()/vals.len() as f64; fmt_num(vals.iter().map(|v|(v-m)*(v-m)).sum::<f64>()/vals.len() as f64)},"stddev_pop"|"stddev"|"std"=>{let m=vals.iter().sum::<f64>()/vals.len() as f64; fmt_num((vals.iter().map(|v|(v-m)*(v-m)).sum::<f64>()/vals.len() as f64).sqrt())},_=>String::new()} }
fn fmt_num(x:f64)->String{ if (x.fract()).abs()<1e-9 {format!("{}",x as i64)}else{format!("{}",x)} }

fn fname(p:&Path)->String{p.file_name().and_then(OsStr::to_str).unwrap_or("").to_string()} fn stem(p:&Path)->String{p.file_stem().and_then(OsStr::to_str).unwrap_or("").to_string()} fn ext(p:&Path)->String{p.extension().and_then(OsStr::to_str).unwrap_or("").to_string()} fn path_str(p:&Path)->String{p.to_string_lossy().to_string()} fn abs_path(p:&Path)->String{fs::canonicalize(p).unwrap_or_else(|_|p.to_path_buf()).to_string_lossy().to_string()} fn dir_str(p:Option<&Path>)->String{p.map(path_str).unwrap_or_default()}
fn fmt_time(sec:i64)->String{ Local.timestamp_opt(sec,0).single().map(|d|d.format("%Y-%m-%d %H:%M:%S").to_string()).unwrap_or_default() }
fn format_size(n:u64)->String{ let units=[("TiB",1u64<<40),("GiB",1u64<<30),("MiB",1u64<<20),("KiB",1u64<<10)]; for (u,m) in units { if n>=m { let v=n as f64/m as f64; return if (v.fract()).abs()<0.05 {format!("{}{}",v.round() as u64,u)} else {format!("{:.1}{}",v,u)}; } } format!("{}B",n) }
fn mode_string(e:&Entry)->String{ let m=e.lmd.mode(); let mut s=String::new(); s.push(if e.lmd.file_type().is_symlink(){'l'}else if e.md.is_dir(){'d'}else{'-'}); for (r,w,x) in [(0o400,0o200,0o100),(0o040,0o020,0o010),(0o004,0o002,0o001)] {s.push(if m&r!=0{'r'}else{'-'});s.push(if m&w!=0{'w'}else{'-'});s.push(if m&x!=0{'x'}else{'-'});} s }

fn lookup_name(file:&str, id:u32)->String{
    if let Ok(text)=fs::read_to_string(file){
        for line in text.lines(){
            let parts:Vec<&str>=line.split(':').collect();
            if parts.len()>2 && parts[2].parse::<u32>().ok()==Some(id){ return parts[0].to_string(); }
        }
    }
    id.to_string()
}
fn image_dim(e:&Entry)->Option<(u32,u32)>{
    let mut b=[0u8;32]; let mut f=File::open(&e.full).ok()?; let n=f.read(&mut b).ok()?;
    if n>=24 && &b[0..8]==b"\x89PNG\r\n\x1a\n" { return Some((u32::from_be_bytes([b[16],b[17],b[18],b[19]]), u32::from_be_bytes([b[20],b[21],b[22],b[23]]))); }
    if n>=4 && b[0]==0xff && b[1]==0xd8 {
        let data=fs::read(&e.full).ok()?; let mut i=2usize;
        while i+9<data.len(){ if data[i]!=0xff {i+=1; continue;} let marker=data[i+1]; if marker==0xc0 || marker==0xc2 { let h=u16::from_be_bytes([data[i+5],data[i+6]]) as u32; let w=u16::from_be_bytes([data[i+7],data[i+8]]) as u32; return Some((w,h)); } if i+3>=data.len(){break;} let len=u16::from_be_bytes([data[i+2],data[i+3]]) as usize; if len<2{break;} i += 2 + len; }
    }
    None
}
fn is_empty(e:&Entry)->bool{ if e.md.is_dir(){ fs::read_dir(&e.full).map(|mut r|r.next().is_none()).unwrap_or(false)}else{e.lmd.len()==0} }
fn starts_with(e:&Entry,prefix:&[u8])->bool{ let mut b=vec![0;prefix.len()]; File::open(&e.full).and_then(|mut f|f.read_exact(&mut b)).is_ok() && b==prefix }
fn line_count(e:&Entry)->usize{ let mut s=String::new(); File::open(&e.full).and_then(|mut f|f.read_to_string(&mut s)).map(|_|s.lines().count()).unwrap_or(0) }
fn is_binary(e:&Entry)->bool{ let mut b=[0u8;1024]; if let Ok(mut f)=File::open(&e.full){ if let Ok(n)=f.read(&mut b){ return b[..n].contains(&0); }} false }
fn mime(e:&Entry)->String{ let x=ext(&e.full).to_lowercase(); match x.as_str(){"txt"|"md"|"rs"|"c"|"h"|"py"|"js"|"json"|"toml"=>"text/plain","html"|"htm"=>"text/html","jpg"|"jpeg"=>"image/jpeg","png"=>"image/png","gif"=>"image/gif","pdf"=>"application/pdf","zip"=>"application/zip",_=>""}.to_string() }
fn hash<D:Digest+Default>(e:&Entry)->String{ if !e.md.is_file(){return String::new();} let mut f=match File::open(&e.full){Ok(f)=>f,Err(_)=>return String::new()}; let mut h=D::new(); let mut buf=[0u8;8192]; loop{match f.read(&mut buf){Ok(0)=>break,Ok(n)=>h.update(&buf[..n]),Err(_)=>return String::new()}} h.finalize().iter().map(|b| format!("{:02x}", b)).collect::<String>() }
fn is_ext(e:&str,set:&[&str])->bool{set.contains(&e.to_ascii_lowercase().as_str())}
const SOURCE:&[&str]=&["asm","awk","bas","c","cc","clj","coffee","cpp","cs","d","dart","elm","erl","go","gradle","groovy","h","hpp","java","js","jsx","kt","lua","nim","pas","php","pl","pm","py","rb","rs","scala","swift","tcl","ts","tsx","vb","zig"];
const IMAGE:&[&str]=&["bmp","gif","heic","jpeg","jpg","png","psd","svg","tiff","webp"];
const AUDIO:&[&str]=&["aac","aiff","flac","m4a","mp3","ogg","wav","wma"];
const VIDEO:&[&str]=&["avi","flv","mkv","mov","mp4","mpeg","mpg","webm","wmv"];
const ARCHIVE:&[&str]=&["7z","bz2","gz","rar","tar","xz","zip"];
const DOC:&[&str]=&["doc","docx","odt","pdf","ppt","pptx","rtf","xls","xlsx","xps"];
const BOOK:&[&str]=&["azw3","chm","djv","djvu","epub","fb2","mobi","pdf"];
const FONT:&[&str]=&["eot","fon","otc","otf","ttc","ttf","woff","woff2"];

fn format_rows(rows:&[Vec<String>], cols:&[String], fmt:&str)->String{ match fmt {"csv"=>rows.iter().map(|r|r.iter().map(|v|csv(v)).collect::<Vec<_>>().join(",")).collect::<Vec<_>>().join("\n")+if rows.is_empty(){""}else{"\n"},"lines"=>rows.iter().flat_map(|r|r.iter()).cloned().collect::<Vec<_>>().join("\n")+if rows.is_empty(){""}else{"\n"},"list"=>{let mut s=rows.iter().flat_map(|r|r.iter()).cloned().collect::<Vec<_>>().join("\0"); if !s.is_empty(){s.push('\0');} s},"json"=>json(rows,cols),"html"=>html(rows,cols),_=>rows.iter().map(|r|r.join("\t")).collect::<Vec<_>>().join("\n")+if rows.is_empty(){""}else{"\n"}} }
fn csv(v:&str)->String{ if v.contains(',')||v.contains('"')||v.contains('\n'){format!("\"{}\"",v.replace('"',"\"\""))}else{v.to_string()} }
fn key(c:&str)->String{ let raw=func(c).map(|(f,_)|f).unwrap_or_else(||lower(c)); raw.split('_').map(|p|{let mut ch=p.chars(); match ch.next(){Some(a)=>a.to_uppercase().collect::<String>()+ch.as_str(),None=>String::new()}}).collect::<Vec<_>>().join("") }
fn esc(s:&str)->String{s.replace('\\',"\\\\").replace('"',"\\\"").replace('\n',"\\n").replace('\t',"\\t")}
fn json(rows:&[Vec<String>],cols:&[String])->String{ let mut s=String::from("["); for (i,r) in rows.iter().enumerate(){ if i>0{s.push(',');} s.push('{'); for (j,v) in r.iter().enumerate(){ if j>0{s.push(',');} s.push_str(&format!("\"{}\":\"{}\"",key(cols.get(j).map(String::as_str).unwrap_or("Column")),esc(v))); } s.push('}'); } s.push(']'); s }
fn html(rows:&[Vec<String>],cols:&[String])->String{ let mut s=String::from("<html><body><table>\n<tr>"); for c in cols{s.push_str(&format!("<th>{}</th>",key(c)));} s.push_str("</tr>\n"); for r in rows{s.push_str("<tr>"); for v in r{s.push_str(&format!("<td>{}</td>",v));} s.push_str("</tr>\n");} s.push_str("</table></body></html>\n"); s }
