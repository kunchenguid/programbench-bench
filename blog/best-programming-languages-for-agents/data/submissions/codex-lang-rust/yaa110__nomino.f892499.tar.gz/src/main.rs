use regex::Regex;
use serde_json::Value;
use std::cmp::Ordering;
use std::collections::{HashMap, HashSet};
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

#[derive(Copy, Clone, Debug)]
enum SortOrder {
    Asc,
    Desc,
}

#[derive(Debug, Default)]
struct Cli {
    args: Vec<String>,
    dir: Option<PathBuf>,
    depth: Option<usize>,
    no_extension: bool,
    generate: Option<PathBuf>,
    mkdir: bool,
    map: Option<PathBuf>,
    max_depth: Option<usize>,
    quiet: bool,
    regex: Option<String>,
    sort: Option<SortOrder>,
    test: bool,
    overwrite: bool,
}

#[derive(Clone, Debug)]
struct Item {
    input: String,
    output: String,
}

fn main() {
    let cli = match parse_cli() {
        Ok(c) => c,
        Err((msg, code)) => {
            eprintln!("{msg}");
            std::process::exit(code);
        }
    };
    if let Err(e) = run(cli) {
        eprintln!("error: {e}");
        std::process::exit(1);
    }
}

fn parse_cli() -> Result<Cli, (String, i32)> {
    let mut cli = Cli::default();
    let mut it = std::env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" => {
                println!("{}", short_help());
                std::process::exit(0);
            }
            "--help" => {
                println!("{}", long_help());
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("nomino 1.6.4");
                std::process::exit(0);
            }
            "-d" | "--dir" => cli.dir = Some(PathBuf::from(next_value(&mut it, &arg)?)),
            "--depth" => cli.depth = Some(parse_usize(next_value(&mut it, &arg)?, "--depth")?),
            "-E" | "--no-extension" => cli.no_extension = true,
            "-g" | "--generate" => cli.generate = Some(PathBuf::from(next_value(&mut it, &arg)?)),
            "-k" | "--mkdir" => cli.mkdir = true,
            "-m" | "--map" | "--from-file" => cli.map = Some(PathBuf::from(next_value(&mut it, &arg)?)),
            "--max-depth" => cli.max_depth = Some(parse_usize(next_value(&mut it, &arg)?, "--max-depth")?),
            "-q" | "--quiet" => cli.quiet = true,
            "-r" | "--regex" => cli.regex = Some(next_value(&mut it, &arg)?),
            "-s" | "--sort" => {
                let v = next_value(&mut it, &arg)?;
                cli.sort = Some(match v.as_str() {
                    "asc" => SortOrder::Asc,
                    "desc" => SortOrder::Desc,
                    _ => return Err((format!("error: invalid value '{v}' for '--sort <ORDER>'\n  [possible values: asc, desc]\n\nFor more information, try '--help'."), 2)),
                });
            }
            "-t" | "--test" | "--dry-run" => cli.test = true,
            "-w" | "--overwrite" => cli.overwrite = true,
            _ if arg.starts_with('-') => {
                return Err((format!("error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nFor more information, try '--help'."), 2));
            }
            _ => cli.args.push(arg),
        }
    }
    Ok(cli)
}

fn next_value<I>(it: &mut std::iter::Peekable<I>, opt: &str) -> Result<String, (String, i32)>
where
    I: Iterator<Item = String>,
{
    it.next().ok_or_else(|| (format!("error: a value is required for '{opt} <VALUE>' but none was supplied"), 2))
}

fn parse_usize(value: String, opt: &str) -> Result<usize, (String, i32)> {
    value.parse::<usize>().map_err(|_| (format!("error: invalid value '{value}' for '{opt} <DEPTH>'"), 2))
}

fn short_help() -> &'static str {
    "Batch rename utility for developers\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nArguments:\n  [[SOURCE] OUTPUT]...  OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n  -d, --dir <PATH>         Sets the working directory\n      --depth <DEPTH>      Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n  -E, --no-extension       Does not preserve the extension of input files in 'sort' and 'regex' options\n  -g, --generate <PATH>    Stores a JSON map file in '<PATH>' after renaming files\n  -h, --help               Print help (see more with '--help')\n  -k, --mkdir              Recursively creates all parent directories of '<OUTPUT>' if they are missing\n  -m, --map <PATH>         Sets the path of map file to be used for renaming files [aliases: --from-file]\n      --max-depth <DEPTH>  Optional value to set the maximum of subdirectory depth value in 'regex' mode\n  -q, --quiet              Does not print the map table to stdout\n  -r, --regex <PATTERN>    Regex pattern to match by filenames\n  -s, --sort <ORDER>       Sets the order of natural sorting (by name) to rename files using enumerator [possible values: asc, desc]\n  -t, --test               Runs in test mode without renaming actual files [aliases: --dry-run]\n  -V, --version            Print version\n  -w, --overwrite          Overwrites output files, otherwise, a '_' is prepended to filename\n\nOUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information."
}

fn long_help() -> &'static str {
    "Batch rename utility for developers\n\nUsage: executable [OPTIONS] [[SOURCE] OUTPUT]...\n\nArguments:\n  [[SOURCE] OUTPUT]...\n          OUTPUT is the pattern to be used for renaming files, and SOURCE is the optional regex pattern to match by filenames. SOURCE has the same function as -r option\n\nOptions:\n  -d, --dir <PATH>\n          Sets the working directory\n\n      --depth <DEPTH>\n          Optional value to overwrite inferred subdirectory depth value in 'regex' mode\n\n  -E, --no-extension\n          Does not preserve the extension of input files in 'sort' and 'regex' options\n\n  -g, --generate <PATH>\n          Stores a JSON map file in '<PATH>' after renaming files\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -k, --mkdir\n          Recursively creates all parent directories of '<OUTPUT>' if they are missing\n\n  -m, --map <PATH>\n          Sets the path of map file to be used for renaming files\n          \n          [aliases: --from-file]\n\n      --max-depth <DEPTH>\n          Optional value to set the maximum of subdirectory depth value in 'regex' mode\n\n  -q, --quiet\n          Does not print the map table to stdout\n\n  -r, --regex <PATTERN>\n          Regex pattern to match by filenames\n\n  -s, --sort <ORDER>\n          Sets the order of natural sorting (by name) to rename files using enumerator\n\n          Possible values:\n          - asc:  Sort in ascending order\n          - desc: Sort in descending order\n\n  -t, --test\n          Runs in test mode without renaming actual files\n          \n          [aliases: --dry-run]\n\n  -V, --version\n          Print version\n\n  -w, --overwrite\n          Overwrites output files, otherwise, a '_' is prepended to filename\n\nOUTPUT pattern accepts placeholders that have the format of '{G:P}' where 'G' is the captured group and 'P' is the padding of digits with `0`. Please refer to https://github.com/yaa110/nomino for more information."
}

fn run(cli: Cli) -> Result<(), String> {
    let cwd = cli.dir.clone().unwrap_or_else(|| PathBuf::from("."));
    let items = if let Some(map) = &cli.map {
        map_items(&cwd, map)?
    } else if cli.sort.is_some() {
        let output = cli.args.last().ok_or_else(missing_mode)?;
        sort_items(&cwd, cli.sort.unwrap(), output, cli.no_extension)?
    } else {
        let (source, output) = regex_source_output(&cli)?;
        regex_items(&cwd, &source, &output, cli.no_extension, cli.depth, cli.max_depth)?
    };

    let final_items = resolve_collisions(&cwd, items, cli.overwrite);
    if !cli.test {
        apply_renames(&cwd, &final_items, cli.mkdir, cli.overwrite)?;
    }
    if let Some(path) = &cli.generate {
        write_map(&cwd, path, &final_items)?;
    }
    if !cli.quiet {
        print_table(&final_items)?;
    }
    Ok(())
}

fn missing_mode() -> String {
    "one of 'regex', 'sort', 'map' or 'SOURCE' options must be set.\nusage: run './executable --help' for more information.".to_string()
}

fn regex_source_output(cli: &Cli) -> Result<(String, String), String> {
    if let Some(r) = &cli.regex {
        let out = cli.args.last().ok_or_else(missing_mode)?;
        return Ok((r.clone(), out.clone()));
    }
    if cli.args.len() >= 2 {
        Ok((cli.args[0].clone(), cli.args[1].clone()))
    } else {
        Err(missing_mode())
    }
}

fn list_entries(base: &Path, max_depth: usize) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    visit(base, Path::new(""), max_depth, &mut out)?;
    out.sort_by(|a, b| natural_cmp(a, b));
    Ok(out)
}

fn visit(base: &Path, rel: &Path, depth: usize, out: &mut Vec<String>) -> Result<(), String> {
    let dir = base.join(rel);
    let entries = fs::read_dir(&dir).map_err(|e| e.to_string())?;
    let mut names = Vec::new();
    for ent in entries {
        let ent = ent.map_err(|e| e.to_string())?;
        let name = ent.file_name().to_string_lossy().to_string();
        names.push((name, ent.file_type().map_err(|e| e.to_string())?.is_dir()));
    }
    names.sort_by(|a, b| natural_cmp(&a.0, &b.0));
    for (name, is_dir) in names {
        let r = rel.join(&name);
        out.push(path_string(&r));
        if is_dir && depth > 0 {
            visit(base, &r, depth - 1, out)?;
        }
    }
    Ok(())
}

fn sort_items(base: &Path, order: SortOrder, output: &str, no_ext: bool) -> Result<Vec<Item>, String> {
    let mut entries = list_entries(base, 0)?;
    if matches!(order, SortOrder::Desc) {
        entries.reverse();
    }
    let mut items = Vec::new();
    for (idx, input) in entries.iter().enumerate() {
        let mut caps = HashMap::new();
        caps.insert("0".to_string(), input.clone());
        caps.insert("1".to_string(), (idx + 1).to_string());
        let mut name = expand(output, &caps, idx + 1);
        if !no_ext {
            name = preserve_extension(input, &name);
        }
        items.push(Item { input: input.clone(), output: name });
    }
    Ok(items)
}

fn regex_items(base: &Path, pattern: &str, output: &str, no_ext: bool, depth: Option<usize>, max_depth: Option<usize>) -> Result<Vec<Item>, String> {
    let re = Regex::new(pattern).map_err(|e| e.to_string())?;
    let inferred = pattern.matches('/').count();
    let d = depth.unwrap_or_else(|| max_depth.unwrap_or(inferred));
    let entries = list_entries(base, d)?;
    let mut items = Vec::new();
    for input in entries {
        if let Some(c) = re.captures(&input) {
            let mut caps = HashMap::new();
            for i in 0..c.len() {
                if let Some(m) = c.get(i) {
                    caps.insert(i.to_string(), m.as_str().to_string());
                }
            }
            for name in re.capture_names().flatten() {
                if let Some(m) = c.name(name) {
                    caps.insert(name.to_string(), m.as_str().to_string());
                }
            }
            let mut name = expand(output, &caps, 1);
            if !no_ext {
                name = preserve_extension(&input, &name);
            }
            items.push(Item { input, output: name });
        }
    }
    Ok(items)
}

fn map_items(base: &Path, map_path: &Path) -> Result<Vec<Item>, String> {
    let p = if map_path.is_absolute() { map_path.to_path_buf() } else { base.join(map_path) };
    let text = fs::read_to_string(p).map_err(|e| e.to_string())?;
    let v: Value = serde_json::from_str(&text).map_err(|e| e.to_string())?;
    let obj = v.as_object().ok_or_else(|| "invalid type: sequence, expected a map at line 1 column 0".to_string())?;
    let mut items = Vec::new();
    for (inp, out) in obj {
        let output = out.as_str().ok_or_else(|| "invalid map value, expected string".to_string())?;
        items.push(Item { input: inp.to_string(), output: output.to_string() });
    }
    Ok(items)
}

fn expand(pattern: &str, caps: &HashMap<String, String>, _ordinal: usize) -> String {
    let mut out = String::new();
    let mut chars = pattern.chars().peekable();
    let mut auto = 1usize;
    while let Some(ch) = chars.next() {
        if ch == '{' {
            let mut body = String::new();
            let mut closed = false;
            while let Some(c) = chars.next() {
                if c == '}' {
                    closed = true;
                    break;
                }
                body.push(c);
            }
            if !closed {
                out.push('{');
                out.push_str(&body);
                continue;
            }
            let mut parts = body.splitn(2, ':');
            let group = parts.next().unwrap_or("");
            let pad = parts.next().and_then(|p| p.parse::<usize>().ok()).unwrap_or(0);
            let key = if group.is_empty() {
                let k = auto.to_string();
                auto += 1;
                k
            } else {
                group.to_string()
            };
            let raw = caps.get(&key).cloned().unwrap_or_default();
            out.push_str(&pad_value(&raw, pad));
        } else if ch == '\\' && matches!(chars.peek(), Some('{') | Some('}')) {
            out.push(chars.next().unwrap());
        } else {
            out.push(ch);
        }
    }
    out
}

fn pad_value(raw: &str, pad: usize) -> String {
    if pad == 0 {
        return raw.to_string();
    }
    if raw.chars().all(|c| c.is_ascii_digit()) {
        format!("{raw:0>width$}", width = pad)
    } else {
        raw.to_string()
    }
}

fn preserve_extension(input: &str, output: &str) -> String {
    let in_path = Path::new(input);
    if in_path.extension().is_none() {
        return output.to_string();
    }
    let ext = in_path.extension().unwrap().to_string_lossy();
    let out_path = Path::new(output);
    if out_path.extension().map(|e| e == ext.as_ref()).unwrap_or(false) {
        output.to_string()
    } else {
        format!("{output}.{ext}")
    }
}

fn resolve_collisions(base: &Path, items: Vec<Item>, overwrite: bool) -> Vec<Item> {
    if overwrite {
        return items;
    }
    let mut outputs = HashSet::new();
    let mut result = Vec::new();
    for mut item in items {
        while (base.join(&item.output).exists() && item.output != item.input) || outputs.contains(&item.output) {
            item.output = prepend_underscore(&item.output);
        }
        outputs.insert(item.output.clone());
        result.push(item);
    }
    result
}

fn prepend_underscore(path: &str) -> String {
    let p = Path::new(path);
    if let Some(parent) = p.parent() {
        if parent.as_os_str().is_empty() {
            format!("_{}", p.file_name().unwrap_or_default().to_string_lossy())
        } else {
            path_string(&parent.join(format!("_{}", p.file_name().unwrap_or_default().to_string_lossy())))
        }
    } else {
        format!("_{path}")
    }
}

fn apply_renames(base: &Path, items: &[Item], mkdir: bool, overwrite: bool) -> Result<(), String> {
    for item in items {
        let src = base.join(&item.input);
        let dst = base.join(&item.output);
        if mkdir {
            if let Some(parent) = dst.parent() {
                fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
        }
        if overwrite && dst.exists() {
            if dst.is_dir() {
                fs::remove_dir_all(&dst).map_err(|e| e.to_string())?;
            } else {
                fs::remove_file(&dst).map_err(|e| e.to_string())?;
            }
        }
        fs::rename(src, dst).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn write_map(base: &Path, path: &Path, items: &[Item]) -> Result<(), String> {
    let mut s = String::from("{\n");
    for (idx, item) in items.iter().enumerate() {
        s.push_str(&format!("  {}: {}", json_string(&item.output), json_string(&item.input)));
        if idx + 1 != items.len() {
            s.push(',');
        }
        s.push('\n');
    }
    s.push('}');
    let p = if path.is_absolute() { path.to_path_buf() } else { base.join(path) };
    if let Some(parent) = p.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    fs::write(p, s).map_err(|e| e.to_string())
}

fn json_string(s: &str) -> String {
    serde_json::to_string(s).unwrap()
}

fn print_table(items: &[Item]) -> Result<(), String> {
    let iw = items.iter().map(|i| i.input.len()).max().unwrap_or(5).max(5);
    let ow = items.iter().map(|i| i.output.len()).max().unwrap_or(6).max(6);
    let border = format!("+{}+{}+", "-".repeat(iw + 2), "-".repeat(ow + 2));
    let mut stdout = io::stdout();
    writeln!(stdout, "{border}").map_err(|e| e.to_string())?;
    writeln!(stdout, "| {:<iw$} | {:<ow$} |", "Input", "Output", iw = iw, ow = ow).map_err(|e| e.to_string())?;
    writeln!(stdout, "{border}").map_err(|e| e.to_string())?;
    for item in items {
        writeln!(stdout, "| {:<iw$} | {:<ow$} |", item.input, item.output, iw = iw, ow = ow).map_err(|e| e.to_string())?;
    }
    writeln!(stdout, "{border}").map_err(|e| e.to_string())?;
    Ok(())
}

fn path_string(p: &Path) -> String {
    p.to_string_lossy().replace('\\', "/")
}

fn natural_cmp(a: &str, b: &str) -> Ordering {
    let mut ia = 0;
    let mut ib = 0;
    let ba = a.as_bytes();
    let bb = b.as_bytes();
    while ia < ba.len() && ib < bb.len() {
        if ba[ia].is_ascii_digit() && bb[ib].is_ascii_digit() {
            let sa = ia;
            let sb = ib;
            while ia < ba.len() && ba[ia].is_ascii_digit() { ia += 1; }
            while ib < bb.len() && bb[ib].is_ascii_digit() { ib += 1; }
            let na = &a[sa..ia].trim_start_matches('0');
            let nb = &b[sb..ib].trim_start_matches('0');
            let na = if na.is_empty() { "0" } else { na };
            let nb = if nb.is_empty() { "0" } else { nb };
            match na.len().cmp(&nb.len()).then_with(|| na.cmp(nb)) {
                Ordering::Equal => {}
                o => return o,
            }
        } else {
            let ca = ba[ia].to_ascii_lowercase();
            let cb = bb[ib].to_ascii_lowercase();
            match ca.cmp(&cb) {
                Ordering::Equal => {
                    ia += 1;
                    ib += 1;
                }
                o => return o,
            }
        }
    }
    ba.len().cmp(&bb.len())
}
