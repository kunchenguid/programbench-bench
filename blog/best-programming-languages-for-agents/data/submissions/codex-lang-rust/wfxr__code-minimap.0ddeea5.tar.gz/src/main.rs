use clap::{Arg, ArgAction, Command, ValueHint};
use std::fs;
use std::io::{self, Read, Write};
use std::path::PathBuf;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Encoding {
    Utf8Lossy,
    Utf8,
}

fn cli() -> Command {
    Command::new("executable")
        .bin_name("executable")
        .about("A high performance code minimap generator")
        .next_line_help(true)
        .arg(
            Arg::new("horizontal-scale")
                .short('H')
                .long("horizontal-scale")
                .value_name("HSCALE")
                .help("Specify horizontal scale factor")
                .default_value("1.0")
                .value_parser(clap::value_parser!(f64)),
        )
        .arg(
            Arg::new("vertical-scale")
                .short('V')
                .long("vertical-scale")
                .value_name("VSCALE")
                .help("Specify vertical scale factor")
                .default_value("1.0")
                .value_parser(clap::value_parser!(f64)),
        )
        .arg(
            Arg::new("padding")
                .long("padding")
                .value_name("PADDING")
                .help("Specify padding width")
                .value_parser(clap::value_parser!(usize)),
        )
        .arg(
            Arg::new("encoding")
                .long("encoding")
                .value_name("ENCODING")
                .help("Specify input encoding")
                .default_value("utf8-lossy")
                .value_parser(["utf8-lossy", "utf8"]),
        )
        .arg(
            Arg::new("version")
                .long("version")
                .help("Print version")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("FILE")
                .help("File to read")
                .value_hint(ValueHint::FilePath)
                .value_parser(clap::value_parser!(PathBuf)),
        )
        .subcommand(
            Command::new("completion")
                .about("Generate shell completion file")
                .arg(
                    Arg::new("SHELL")
                        .help("Target shell name")
                        .required(true)
                        .value_parser(["bash", "elvish", "fish", "powershell", "zsh"]),
                ),
        )
}

fn main() {
    let matches = cli().get_matches();

    if matches.get_flag("version") {
        println!("code-minimap 0.6.8");
        return;
    }

    if let Some(("completion", sub)) = matches.subcommand() {
        let shell = sub.get_one::<String>("SHELL").map(String::as_str).unwrap_or("");
        print_completion(shell);
        return;
    }

    let hscale = *matches.get_one::<f64>("horizontal-scale").unwrap_or(&1.0);
    let vscale = *matches.get_one::<f64>("vertical-scale").unwrap_or(&1.0);
    let padding = matches.get_one::<usize>("padding").copied().unwrap_or(0);
    let encoding = match matches
        .get_one::<String>("encoding")
        .map(String::as_str)
        .unwrap_or("utf8-lossy")
    {
        "utf8" => Encoding::Utf8,
        _ => Encoding::Utf8Lossy,
    };

    let input = match read_input(matches.get_one::<PathBuf>("FILE"), encoding) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("code-minimap: {e}");
            std::process::exit(1);
        }
    };

    let rendered = render_minimap(&input, hscale, vscale, padding);
    print!("{rendered}");
}

fn read_input(path: Option<&PathBuf>, encoding: Encoding) -> Result<String, String> {
    let bytes = if let Some(path) = path {
        fs::read(path).map_err(|e| e.to_string())?
    } else {
        let mut buf = Vec::new();
        io::stdin()
            .read_to_end(&mut buf)
            .map_err(|e| e.to_string())?;
        buf
    };

    match encoding {
        Encoding::Utf8Lossy => Ok(String::from_utf8_lossy(&bytes).into_owned()),
        Encoding::Utf8 => String::from_utf8(bytes).map_err(|e| e.to_string()),
    }
}

fn render_minimap(input: &str, hscale: f64, vscale: f64, padding: usize) -> String {
    let mut spans = Vec::new();
    let mut max_width = 0usize;

    for raw in input.lines() {
        let line = raw.strip_suffix('\r').unwrap_or(raw);
        let expanded = expand_tabs(line);
        max_width = max_width.max(expanded.chars().count().max(1));
        let span = line_span(&expanded);
        spans.push(span);
    }

    if input.is_empty() {
        return String::new();
    }

    let rows_in = spans.len();
    let width_in = max_width;
    let width_out = scaled_width(width_in, hscale);
    let rows_out = scaled_rows(rows_in, vscale);

    let cell_cols = (width_out + 1) / 2;
    let cell_rows = (rows_out + 3) / 4;

    let mut out = String::new();
    for cy in 0..cell_rows {
        for cx in 0..cell_cols {
            let mut bits = 0u8;
            for dy in 0..4 {
                for dx in 0..2 {
                    let x = cx * 2 + dx;
                    let y = cy * 4 + dy;
                    if x < width_out && y < rows_out && pixel_at(&spans, width_in, x, y, width_out, rows_out) {
                        bits |= braille_bit(dx, dy);
                    }
                }
            }
            out.push(char::from_u32(0x2800 + bits as u32).unwrap());
        }
        for _ in cell_cols..padding {
            out.push(' ');
        }
        out.push('\n');
    }
    out
}

fn expand_tabs(line: &str) -> String {
    let mut out = String::new();
    for ch in line.chars() {
        if ch == '\t' {
            out.push(' ');
        } else {
            out.push(ch);
        }
    }
    out
}

fn line_span(line: &str) -> Option<(usize, usize)> {
    let mut first = None;
    let mut last = None;
    for (idx, ch) in line.chars().enumerate() {
        if !ch.is_whitespace() {
            first.get_or_insert(idx);
            last = Some(idx + 1);
        }
    }
    first.zip(last)
}

fn scaled_width(width: usize, scale: f64) -> usize {
    if width == 0 || !scale.is_finite() || scale <= 0.0 {
        return 0;
    }
    ((width as f64) * scale).floor() as usize
}

fn scaled_rows(rows: usize, scale: f64) -> usize {
    if rows == 0 || !scale.is_finite() || scale <= 0.0 {
        return 0;
    }
    let s = scale.min(1.0);
    ((rows as f64) * s).ceil() as usize
}

fn pixel_at(
    spans: &[Option<(usize, usize)>],
    width_in: usize,
    x: usize,
    y: usize,
    width_out: usize,
    rows_out: usize,
) -> bool {
    if width_in == 0 || width_out == 0 || rows_out == 0 || spans.is_empty() {
        return false;
    }

    let src_y = ((y * spans.len()) / rows_out).min(spans.len() - 1);
    let src_x0 = (x * width_in) / width_out;
    let src_x1 = (((x + 1) * width_in + width_out - 1) / width_out).max(src_x0 + 1);
    match spans[src_y] {
        Some((start, end)) => src_x0 < end && src_x1 > start,
        None => false,
    }
}

fn braille_bit(dx: usize, dy: usize) -> u8 {
    match (dx, dy) {
        (0, 0) => 0x01,
        (0, 1) => 0x02,
        (0, 2) => 0x04,
        (0, 3) => 0x40,
        (1, 0) => 0x08,
        (1, 1) => 0x10,
        (1, 2) => 0x20,
        (1, 3) => 0x80,
        _ => 0,
    }
}

fn print_completion(shell: &str) {
    match shell {
        "bash" => println!(
            "_executable() {{\n    COMPREPLY=($(compgen -W \"completion help --horizontal-scale --vertical-scale --padding --encoding --version --help\" -- \"${{COMP_WORDS[COMP_CWORD]}}\"))\n}}\ncomplete -F _executable executable"
        ),
        "fish" => println!(
            "complete -c executable -s H -l horizontal-scale -d 'Specify horizontal scale factor'\ncomplete -c executable -s V -l vertical-scale -d 'Specify vertical scale factor'\ncomplete -c executable -l padding -d 'Specify padding width'\ncomplete -c executable -l encoding -d 'Specify input encoding'\ncomplete -c executable -l version -d 'Print version'\ncomplete -c executable -s h -l help -d 'Print help'"
        ),
        "zsh" => println!(
            "#compdef executable\n_arguments \\\n  '(-H --horizontal-scale)'{{-H,--horizontal-scale}}'[Specify horizontal scale factor]:HSCALE:' \\\n  '(-V --vertical-scale)'{{-V,--vertical-scale}}'[Specify vertical scale factor]:VSCALE:' \\\n  '--padding[Specify padding width]:PADDING:' \\\n  '--encoding[Specify input encoding]:ENCODING:(utf8-lossy utf8)' \\\n  '--version[Print version]' \\\n  '(-h --help)'{{-h,--help}}'[Print help]' \\\n  '*:FILE:_files'"
        ),
        "powershell" => println!(
            "Register-ArgumentCompleter -Native -CommandName 'executable' -ScriptBlock {{ param($wordToComplete) @('completion','help','--horizontal-scale','--vertical-scale','--padding','--encoding','--version','--help') | Where-Object {{ $_ -like \"$wordToComplete*\" }} }}"
        ),
        "elvish" => println!(
            "set edit:completion:arg-completer[executable] = {{|@words| put completion help --horizontal-scale --vertical-scale --padding --encoding --version --help }}"
        ),
        _ => {}
    }
    let _ = io::stdout().flush();
}
