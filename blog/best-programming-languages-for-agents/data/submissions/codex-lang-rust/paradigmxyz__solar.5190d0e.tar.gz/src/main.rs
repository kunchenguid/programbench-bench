use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

const VERSION: &str = "0.1.8";

#[derive(Clone, Debug)]
struct Field { name: String, typ: String, internal: String, indexed: bool, comps: Vec<Field> }
#[derive(Clone, Debug)]
struct AbiItem { kind: String, name: String, inputs: Vec<Field>, outputs: Vec<Field>, state: String, anonymous: Option<bool> }
#[derive(Clone, Debug)]
struct ContractOut { abi: Vec<AbiItem>, hashes: BTreeMap<String, String> }
#[derive(Default)]
struct Opts { inputs: Vec<String>, emit_abi: bool, emit_hashes: bool, pretty: bool, out_dir: Option<String>, stop_after: Option<String>, no_resolve_imports: bool }

fn main() {
    let code = match run() { Ok(()) => 0, Err((c, m)) => { eprint!("{}", m); c } };
    std::process::exit(code);
}

fn run() -> Result<(), (i32, String)> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() { print_short_help(); return Err((2, String::new())); }
    if args.iter().any(|a| a == "--help") { print_long_help(); return Ok(()); }
    if args.iter().any(|a| a == "-h") { print_short_help(); return Ok(()); }
    if args.iter().any(|a| a == "--version" || a == "-V") { print_version(); return Ok(()); }
    if args.iter().any(|a| a == "-Zhelp") { print_zhelp(); return Err((1, String::new())); }
    let opts = parse_args(&mut args)?;
    if opts.inputs.is_empty() {
        return Err((1, "error: no files found\n  │\n  ╰ note: if you wish to use the standard input, please specify `-` explicitly\n\nerror: aborting due to 1 previous error\n\n".into()));
    }
    if opts.stop_after.is_some() && !opts.emit_abi && !opts.emit_hashes { return Ok(()); }
    let mut contracts: BTreeMap<String, ContractOut> = BTreeMap::new();
    let mut seen = std::collections::BTreeSet::new();
    for inp in &opts.inputs {
        if inp.contains('=') && !Path::new(inp).exists() { continue; }
        let (name, src) = if inp == "-" {
            let mut s = String::new(); io::stdin().read_to_string(&mut s).unwrap(); ("<stdin>".to_string(), s)
        } else {
            match fs::read_to_string(inp) { Ok(s) => (inp.clone(), s), Err(_) => return Err((1, format!("error: file {} not found\n\nerror: aborting due to 1 previous error\n\n", inp))) }
        };
        process_source(&name, &src, &opts, &mut seen, &mut contracts);
    }
    if !opts.emit_abi && !opts.emit_hashes { return Ok(()); }
    if contracts.is_empty() && opts.inputs.iter().any(|i| i != "-" && !i.contains('=')) { }
    let json = render_json(&contracts, &opts);
    if let Some(dir) = &opts.out_dir {
        let path = Path::new(dir).join("combined.json");
        fs::write(&path, json).map_err(|e| (1, format!("error: failed to write to output: {}\n\nerror: aborting due to 1 previous error\n\n", e)))?;
    } else { print!("{}", json); }
    Ok(())
}

fn parse_args(args: &mut Vec<String>) -> Result<Opts, (i32, String)> {
    let mut o = Opts { emit_abi: false, emit_hashes: false, ..Default::default() };
    let mut i=0;
    while i<args.len() {
        let a=&args[i];
        match a.as_str() {
            "--pretty-json" => o.pretty=true,
            "--pretty-json-err"|"--no-warnings"|"-v" => {},
            "--emit" => { i+=1; if i>=args.len(){return Err((2,"error: a value is required for '--emit <EMIT>'\n".into()))} parse_emit(&args[i], &mut o)?; },
            x if x.starts_with("--emit=") => parse_emit(&x[7..], &mut o)?,
            "--out-dir" => { i+=1; if i>=args.len(){return Err((2,"error: a value is required for '--out-dir <OUT_DIR>'\n".into()))} o.out_dir=Some(args[i].clone()); },
            x if x.starts_with("--out-dir=") => o.out_dir=Some(x[10..].to_string()),
            "--stop-after" => { i+=1; if let Some(v)=args.get(i){ validate_choice("--stop-after <STOP_AFTER>",v,&["parsing","lowering","analysis"])?; o.stop_after=Some(v.clone()); } },
            x if x.starts_with("--stop-after=") => { let v=&x[13..]; validate_choice("--stop-after <STOP_AFTER>",v,&["parsing","lowering","analysis"])?; o.stop_after=Some(v.to_string()) },
            "-j"|"--threads"|"--jobs" => { i+=1; if let Some(v)=args.get(i){ if v.parse::<usize>().is_err(){return Err((2,format!("error: invalid value '{}' for '--threads <THREADS>': invalid digit found in string\n\nFor more information, try '--help'.\n",v)))}}},
            "--evm-version" => { i+=1; if let Some(v)=args.get(i){ validate_choice("--evm-version <EVM_VERSION>",v,&["homestead","tangerineWhistle","spuriousDragon","byzantium","constantinople","petersburg","istanbul","berlin","london","paris","shanghai","cancun","prague","osaka"])?; } },
            "--base-path"|"-I"|"--include-path"|"--allow-paths"|"--color"|"--error-format"|"--error-format-human"|"--diagnostic-width"|"-Z" => { i+=1; },
            "-Zno-resolve-imports" => o.no_resolve_imports=true,
            x if x.starts_with("-Z") => {},
            "-" => o.inputs.push("-".to_string()),
            x if x.starts_with('-') => return Err((2, format!("error: unexpected argument '{}' found\n\nFor more information, try '--help'.\n", x))),
            x => o.inputs.push(x.to_string()),
        }
        i+=1;
    }
    Ok(o)
}
fn parse_emit(s:&str,o:&mut Opts)->Result<(),(i32,String)>{ for p in s.split(',') { match p {"abi"=>o.emit_abi=true,"hashes"=>o.emit_hashes=true,""=>{},x=>return Err((2,format!("error: invalid value '{}' for '--emit <EMIT>'\n  [possible values: abi, hashes]\n\nFor more information, try '--help'.\n",x)))}} Ok(()) }
fn validate_choice(name:&str,v:&str,vals:&[&str])->Result<(),(i32,String)>{ if vals.contains(&v){Ok(())}else{Err((2,format!("error: invalid value '{}' for '{}'\n  [possible values: {}]\n\nFor more information, try '--help'.\n",v,name,vals.join(", "))))} }

fn parse_source(_file:&str, src:&str) -> Vec<(String, ContractOut)> {
    let s = strip_comments(src);
    let toks = lex(&s);
    let mut res=Vec::new(); let mut i=0;
    while i<toks.len() {
        if matches!(toks[i].as_str(), "contract"|"interface"|"library") || (toks[i]=="abstract" && i+1<toks.len() && toks[i+1]=="contract") {
            if toks[i]=="abstract" { i+=1; }
            let ckind=toks[i].clone(); i+=1; if i>=toks.len(){break} let cname=toks[i].clone();
            while i<toks.len() && toks[i]!="{" { i+=1; } if i>=toks.len(){break}
            let start=i; let end=find_match(&toks,start,"{","}").unwrap_or(toks.len()-1);
            let body=&toks[start+1..end]; res.push((cname.clone(), parse_contract(&cname, &ckind, body))); i=end+1;
        } else { i+=1; }
    }
    res
}

fn process_source(name:&str, src:&str, opts:&Opts, seen:&mut std::collections::BTreeSet<String>, contracts:&mut BTreeMap<String,ContractOut>) {
    if !seen.insert(name.to_string()) { return; }
    for (cname, out) in parse_source(name, src) { contracts.insert(format!("{}:{}", name, cname), out); }
    if opts.no_resolve_imports || name == "<stdin>" { return; }
    let base = Path::new(name).parent().unwrap_or(Path::new(""));
    for imp in find_imports(src) {
        let path = clean_path(if imp.starts_with('.') { base.join(&imp) } else { PathBuf::from(&imp) });
        if let Ok(text) = fs::read_to_string(&path) {
            let display = path.to_string_lossy().to_string();
            process_source(&display, &text, opts, seen, contracts);
        }
    }
}

fn clean_path(path: PathBuf) -> PathBuf {
    let mut out = PathBuf::new();
    for c in path.components() {
        match c {
            std::path::Component::CurDir => {}
            std::path::Component::ParentDir => { out.pop(); }
            other => out.push(other.as_os_str()),
        }
    }
    out
}

fn find_imports(src:&str)->Vec<String>{
    let mut out=Vec::new();
    for line in src.lines() {
        let l=line.trim();
        if !l.starts_with("import") { continue; }
        let bytes=l.as_bytes();
        for q in [b'"', b'\''] {
            if let Some(s)=bytes.iter().position(|&b| b==q) {
                if let Some(e)=bytes[s+1..].iter().position(|&b| b==q) {
                    out.push(l[s+1..s+1+e].to_string());
                    break;
                }
            }
        }
    }
    out
}

fn parse_contract(cname:&str, ckind:&str, body:&[String]) -> ContractOut {
    let mut structs: BTreeMap<String, Vec<Field>>=BTreeMap::new();
    let mut enums = std::collections::BTreeSet::new();
    let mut items=Vec::new(); let mut i=0;
    while i<body.len() {
        match body[i].as_str() {
            "struct" if i+2<body.len() && body[i+2]=="{" => { let nm=body[i+1].clone(); if let Some(e)=find_match(body,i+2,"{","}") { structs.insert(nm, parse_struct_fields(&body[i+3..e], cname)); i=e+1; } },
            "enum" if i+1<body.len() => { enums.insert(body[i+1].clone()); },
            _=>{}
        }
        i+=1;
    }
    i=0;
    while i<body.len() {
        let t=&body[i];
        if t=="function" {
            if let Some((it, ni))=parse_function(body,i,cname,&structs,&enums) { if ckind!="library" || is_public(&body[i..ni]) { items.push(it); } i=ni; continue; }
        } else if t=="constructor" {
            if let Some((it,ni))=parse_constructor(body,i,cname,&structs,&enums){items.push(it); i=ni; continue;}
        } else if t=="event" {
            if let Some((it,ni))=parse_event_error(body,i,cname,&structs,&enums,true){items.push(it); i=ni; continue;}
        } else if t=="error" {
            if let Some((it,ni))=parse_event_error(body,i,cname,&structs,&enums,false){items.push(it); i=ni; continue;}
        } else if t=="receive" || t=="fallback" {
            if let Some((it,ni))=parse_receive_fallback(body,i){items.push(it); i=ni; continue;}
        } else if t=="enum" {
            if i+2<body.len() && body[i+2]=="{" {
                if let Some(e)=find_match(body,i+2,"{","}") { i=e+1; continue; }
            }
        } else if t=="struct" {
            if i+2<body.len() && body[i+2]=="{" {
                if let Some(e)=find_match(body,i+2,"{","}") { i=e+1; continue; }
            }
        } else if looks_variable(body,i) {
            if let Some((it,ni))=parse_variable(body,i,cname,&structs,&enums){items.push(it); i=ni; continue;}
        }
        i+=1;
    }
    items.sort_by(|a,b| sort_key(a).cmp(&sort_key(b)));
    let mut hashes=BTreeMap::new();
    for it in &items { if it.kind=="function" { let sig=format!("{}({})",it.name,it.inputs.iter().map(|f| selector_type(f)).collect::<Vec<_>>().join(",")); hashes.insert(sig.clone(), selector(&sig)); } }
    ContractOut{abi:items, hashes}
}
fn sort_key(a:&AbiItem)->(i32,String){ let c=match a.kind.as_str(){"constructor"=>0,"error"=>1,"event"=>2,"fallback"=>3,"function"=>4,"receive"=>5,_=>9};(c,a.name.clone())}
fn is_public(sl:&[String])->bool{ sl.iter().any(|x| x=="public"||x=="external") }
fn looks_variable(b:&[String],i:usize)->bool{ let mut j=i; while j<b.len()&&b[j]!=";"&&b[j]!="{" { if b[j]=="public" {return true} if matches!(b[j].as_str(),"function"|"event"|"error"|"struct"|"modifier"|"constructor") {return false} j+=1;} false }

fn parse_function(b:&[String],i:usize,cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>)->Option<(AbiItem,usize)> {
    let name=b.get(i+1)?.clone(); let ps=i+2; if b.get(ps)?!="("{return None} let pe=find_match(b,ps,"(",")")?;
    let mut j=pe+1; let mut state="nonpayable".to_string(); let mut outputs=Vec::new();
    while j<b.len() && b[j]!=";" && b[j]!="{" {
        match b[j].as_str(){"view"|"pure"|"payable"=>state=b[j].clone(),"returns" if j+1<b.len()&&b[j+1]=="("=>{let e=find_match(b,j+1,"(",")")?; outputs=parse_params(&b[j+2..e],cname,structs,enums,false); j=e;}, _=>{} } j+=1;
    }
    let vis=is_public(&b[i..j]);
    let ni=skip_decl(b,j); if !vis {return Some((AbiItem{kind:"skip".into(),name,inputs:vec![],outputs:vec![],state,anonymous:None},ni)).filter(|_|false)}
    Some((AbiItem{kind:"function".into(),name,inputs:parse_params(&b[ps+1..pe],cname,structs,enums,false),outputs,state,anonymous:None},ni))
}
fn parse_constructor(b:&[String],i:usize,cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>)->Option<(AbiItem,usize)>{ let ps=i+1; let pe=find_match(b,ps,"(",")")?; let mut j=pe+1; let mut state="nonpayable".to_string(); while j<b.len()&&b[j]!=";"&&b[j]!="{"{if b[j]=="payable"{state="payable".into()} j+=1;} Some((AbiItem{kind:"constructor".into(),name:"".into(),inputs:parse_params(&b[ps+1..pe],cname,structs,enums,false),outputs:vec![],state,anonymous:None},skip_decl(b,j))) }
fn parse_event_error(b:&[String],i:usize,cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>,event:bool)->Option<(AbiItem,usize)>{ let name=b.get(i+1)?.clone(); let ps=i+2; let pe=find_match(b,ps,"(",")")?; let mut j=pe+1; let mut anon=false; while j<b.len()&&b[j]!=";"{if b[j]=="anonymous"{anon=true} j+=1;} Some((AbiItem{kind:if event{"event".into()}else{"error".into()},name,inputs:parse_params(&b[ps+1..pe],cname,structs,enums,event),outputs:vec![],state:"".into(),anonymous:if event{Some(anon)}else{None}},j+1)) }
fn parse_receive_fallback(b:&[String],i:usize)->Option<(AbiItem,usize)>{ let kind=b[i].clone(); let mut j=i+1; let mut state="nonpayable".to_string(); while j<b.len()&&b[j]!=";"&&b[j]!="{"{if b[j]=="payable"{state="payable".into()} j+=1;} Some((AbiItem{kind,name:"".into(),inputs:vec![],outputs:vec![],state,anonymous:None},skip_decl(b,j))) }
fn parse_variable(b:&[String],i:usize,cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>)->Option<(AbiItem,usize)>{ let mut j=i; while j<b.len()&&b[j]!=";"{j+=1;} let sl=&b[i..j]; let pubpos=sl.iter().position(|x|x=="public")?; let mut name=""; for k in (pubpos+1..sl.len()).rev(){ if is_ident(&sl[k]) && !matches!(sl[k].as_str(),"constant"|"immutable"|"override") { name=&sl[k]; break; } } if name.is_empty(){return None} let type_tokens=&sl[..pubpos]; let f=field_from_tokens("", type_tokens,cname,structs,enums,false); Some((AbiItem{kind:"function".into(),name:name.into(),inputs:vec![],outputs:vec![f],state:"view".into(),anonymous:None},j+1)) }
fn skip_decl(b:&[String],j:usize)->usize{ if j>=b.len(){return j} if b[j]==";"{return j+1} if b[j]=="{"{return find_match(b,j,"{","}").map(|x|x+1).unwrap_or(b.len())} j+1 }

fn parse_struct_fields(t:&[String],cname:&str)->Vec<Field>{ let mut out=Vec::new(); let mut start=0; let empty_enums=std::collections::BTreeSet::new(); for i in 0..=t.len(){ if i==t.len()||t[i]==";"{ if i>start { let sl=&t[start..i]; let name=sl.last().cloned().unwrap_or_default(); out.push(field_from_tokens(&name,&sl[..sl.len().saturating_sub(1)],cname,&BTreeMap::new(),&empty_enums,false)); } start=i+1; }} out }
fn parse_params(t:&[String],cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>,event:bool)->Vec<Field>{ let mut out=Vec::new(); let mut start=0; let mut depth=0; for i in 0..=t.len(){ if i<t.len(){match t[i].as_str(){"("|"["=>depth+=1,")"|"]"=>depth-=1,_=>{}}} if i==t.len()||(t[i]==","&&depth==0){ if i>start { out.push(parse_param(&t[start..i],cname,structs,enums,event)); } start=i+1; }} out }
fn parse_param(sl:&[String],cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>,event:bool)->Field{ let indexed=event&&sl.iter().any(|x|x=="indexed"); let clean:Vec<String>=sl.iter().filter(|x|!matches!(x.as_str(),"memory"|"calldata"|"storage"|"indexed")).cloned().collect(); let mut name=""; let mut end=clean.len(); if clean.len()>1 && is_ident(clean.last().unwrap()) && !is_type_word(clean.last().unwrap(),structs,enums) { name=clean.last().unwrap(); end-=1; } field_from_tokens(name,&clean[..end],cname,structs,enums,indexed) }
fn field_from_tokens(name:&str,toks:&[String],cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>,indexed:bool)->Field{ let raw=toks.join(""); let mut internal=canonical_internal(&raw,cname,structs,enums); let typ=canonical_type(&raw,structs,enums); let comps=if typ=="tuple"{ let sn=raw.trim_end_matches(|c: char| c==']'||c=='['||c.is_ascii_digit()).split('.').last().unwrap_or(&raw); structs.get(sn).cloned().unwrap_or_default() } else { vec![] }; if raw.contains("payable") && typ=="address" { internal="address payable".into(); } Field{name:name.into(),typ,internal,indexed,comps} }
fn canonical_internal(raw:&str,cname:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>)->String{ let r=raw.replace("uint[","uint256[").replace("int[","int256["); let base=r.split('[').next().unwrap_or(""); if structs.contains_key(base) { format!("struct {}.{}{}",cname,base, array_suffix(&r)) } else if enums.contains(base) { format!("enum {}.{}{}",cname,base,array_suffix(&r)) } else { canonical_type(&r,structs,enums) } }
fn canonical_type(raw:&str,structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>)->String{ let r=raw.replace(" ",""); let base=r.split('[').next().unwrap_or(""); let suf=array_suffix(&r); let b=if base=="uint"{"uint256"}else if base=="int"{"int256"}else if base=="addresspayable"{"address"}else if structs.contains_key(base){"tuple"}else if enums.contains(base){"uint8"}else{base}; format!("{}{}",b,suf) }
fn selector_type(f:&Field)->String{ if f.typ.starts_with("tuple") { format!("({}){}", f.comps.iter().map(selector_type).collect::<Vec<_>>().join(","), f.typ.strip_prefix("tuple").unwrap_or("")) } else { f.typ.clone() } }
fn array_suffix(r:&str)->String{ if let Some(p)=r.find('['){r[p..].to_string()}else{"".into()} }
fn is_type_word(s:&str, structs:&BTreeMap<String,Vec<Field>>,enums:&std::collections::BTreeSet<String>)->bool{ matches!(s,"uint"|"uint256"|"int"|"int256"|"address"|"bool"|"string"|"bytes"|"bytes32"|"payable")||structs.contains_key(s)||enums.contains(s)||s.starts_with("bytes") }
fn is_ident(s:&str)->bool{ s.chars().next().map(|c|c=='_'||c.is_ascii_alphabetic()).unwrap_or(false) && s.chars().all(|c|c=='_'||c.is_ascii_alphanumeric()) }

fn render_json(contracts:&BTreeMap<String,ContractOut>,opts:&Opts)->String{ if opts.pretty { pretty_json(&compact_json(contracts,opts)) } else { compact_json(contracts,opts) } }
fn compact_json(contracts:&BTreeMap<String,ContractOut>,opts:&Opts)->String{ let mut s="{\"contracts\":{".to_string(); let mut first=true; for (k,c) in contracts { if !first{s.push(',')} first=false; s.push_str(&format!("\"{}\":{{",esc(k))); let mut f2=true; if opts.emit_abi { s.push_str("\"abi\":["); for (idx,it) in c.abi.iter().enumerate(){ if idx>0{s.push(',')} s.push_str(&abi_json(it)); } s.push(']'); f2=false; } if opts.emit_hashes { if !f2{s.push(',')} s.push_str("\"hashes\":{"); let mut hfirst=true; for (sig,h) in &c.hashes{ if !hfirst{s.push(',')} hfirst=false; s.push_str(&format!("\"{}\":\"{}\"",esc(sig),h)); } s.push('}'); } s.push('}'); } s.push_str(&format!("}},\"version\":\"{}\"}}",VERSION)); s }
fn abi_json(it:&AbiItem)->String{ let mut s=format!("{{\"type\":\"{}\"",it.kind); match it.kind.as_str(){"constructor"=>{s.push_str(&format!(",\"inputs\":{},\"stateMutability\":\"{}\"",fields_json(&it.inputs,false),it.state));},"error"=>{s.push_str(&format!(",\"name\":\"{}\",\"inputs\":{}",esc(&it.name),fields_json(&it.inputs,false)));},"event"=>{s.push_str(&format!(",\"name\":\"{}\",\"inputs\":{},\"anonymous\":{}",esc(&it.name),fields_json(&it.inputs,true),it.anonymous.unwrap_or(false)));},"function"=>{s.push_str(&format!(",\"name\":\"{}\",\"inputs\":{},\"outputs\":{},\"stateMutability\":\"{}\"",esc(&it.name),fields_json(&it.inputs,false),fields_json(&it.outputs,false),it.state));},"fallback"|"receive"=>{s.push_str(&format!(",\"stateMutability\":\"{}\"",it.state));},_=>{}} s.push('}'); s }
fn fields_json(v:&[Field], include_indexed:bool)->String{ let mut s="[".to_string(); for (i,f) in v.iter().enumerate(){ if i>0{s.push(',')} s.push_str(&format!("{{\"name\":\"{}\",\"type\":\"{}\"",esc(&f.name),esc(&f.typ))); if include_indexed { s.push_str(&format!(",\"indexed\":{}",f.indexed)); } s.push_str(&format!(",\"internalType\":\"{}\"",esc(&f.internal))); if !f.comps.is_empty(){s.push_str(&format!(",\"components\":{}",fields_json(&f.comps,false)));} s.push('}'); } s.push(']'); s }
fn pretty_json(c:&str)->String{ let mut out=String::new(); let mut ind=0; let mut in_str=false; let mut escp=false; for ch in c.chars(){ if in_str{out.push(ch); if escp{escp=false}else if ch=='\\'{escp=true}else if ch=='\"'{in_str=false} continue;} match ch{'\"'=>{in_str=true;out.push(ch)},'{'|'['=>{out.push(ch);out.push('\n');ind+=2;out.push_str(&" ".repeat(ind));},'}'|']'=>{out.push('\n');ind-=2;out.push_str(&" ".repeat(ind));out.push(ch)},','=>{out.push(ch);out.push('\n');out.push_str(&" ".repeat(ind));},':'=>out.push_str(": "),_=>out.push(ch)} } out }
fn esc(s:&str)->String{ s.replace('\\',"\\\\").replace('"',"\\\"").replace('\n',"\\n") }

fn strip_comments(src:&str)->String{ let mut o=String::new(); let mut it=src.chars().peekable(); while let Some(c)=it.next(){ if c=='/'&&it.peek()==Some(&'/'){ for x in it.by_ref(){ if x=='\n'{o.push('\n');break} } } else if c=='/'&&it.peek()==Some(&'*'){ it.next(); let mut prev=' '; for x in it.by_ref(){ if prev=='*'&&x=='/'{break} prev=x; } } else { o.push(c) } } o }
fn lex(s:&str)->Vec<String>{ let mut v=Vec::new(); let mut cur=String::new(); for c in s.chars(){ if c.is_whitespace(){ if !cur.is_empty(){v.push(cur.clone());cur.clear();} } else if "{}()[];,=>".contains(c){ if !cur.is_empty(){v.push(cur.clone());cur.clear();} v.push(c.to_string()); } else { cur.push(c); } } if !cur.is_empty(){v.push(cur)} v }
fn find_match(t:&[String],start:usize,open:&str,close:&str)->Option<usize>{ if t.get(start)?!=open{return None} let mut d=0; for i in start..t.len(){ if t[i]==open{d+=1}else if t[i]==close{d-=1;if d==0{return Some(i)}} } None }

fn selector(sig:&str)->String{ let h=keccak256(sig.as_bytes()); format!("{:02x}{:02x}{:02x}{:02x}",h[0],h[1],h[2],h[3]) }
fn keccak256(input:&[u8])->[u8;32]{ const R:usize=136; let mut st=[0u64;25]; let mut off=0; while off+R<=input.len(){ absorb(&mut st,&input[off..off+R]); keccakf(&mut st); off+=R;} let mut block=[0u8;R]; let rem=&input[off..]; block[..rem.len()].copy_from_slice(rem); block[rem.len()]=0x01; block[R-1]|=0x80; absorb(&mut st,&block); keccakf(&mut st); let mut out=[0u8;32]; for i in 0..4{out[i*8..i*8+8].copy_from_slice(&st[i].to_le_bytes());} out }
fn absorb(st:&mut[u64;25],b:&[u8]){ for i in 0..(b.len()/8){ let mut a=[0u8;8]; a.copy_from_slice(&b[i*8..i*8+8]); st[i]^=u64::from_le_bytes(a); } }
fn keccakf(a:&mut[u64;25]){ const RC:[u64;24]=[0x0000000000000001,0x0000000000008082,0x800000000000808a,0x8000000080008000,0x000000000000808b,0x0000000080000001,0x8000000080008081,0x8000000000008009,0x000000000000008a,0x0000000000000088,0x0000000080008009,0x000000008000000a,0x000000008000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,0x8000000000008002,0x8000000000000080,0x000000000000800a,0x800000008000000a,0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008]; const ROT:[u32;25]=[0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14]; const PI:[usize;25]=[0,10,20,5,15,16,1,11,21,6,7,17,2,12,22,23,8,18,3,13,14,24,9,19,4]; for &rc in &RC{ let mut c=[0u64;5]; for x in 0..5{c[x]=a[x]^a[x+5]^a[x+10]^a[x+15]^a[x+20];} let mut d=[0u64;5]; for x in 0..5{d[x]=c[(x+4)%5]^c[(x+1)%5].rotate_left(1);} for x in 0..5{for y in 0..5{a[x+5*y]^=d[x];}} let old=*a; for i in 0..25{a[PI[i]]=old[i].rotate_left(ROT[i]);} for y in 0..5{ let row=[a[5*y],a[5*y+1],a[5*y+2],a[5*y+3],a[5*y+4]]; for x in 0..5{a[5*y+x]=row[x]^((!row[(x+1)%5])&row[(x+2)%5]);}} a[0]^=rc; } }

fn print_version(){ println!("solar Version: 0.1.8\nCommit SHA: 8f228ae9f0bd90ad4ec81fb1ef4fbba29748b8d5\nBuild Timestamp: 2026-04-17T19:59:51.519973035Z\nBuild Features: mimalloc,tracing\nBuild Profile: release"); }
fn print_short_help(){ println!("Blazingly fast Solidity compiler\n\nUsage: executable [OPTIONS] [INPUT]...\n\nArguments:\n  [INPUT]...  Files to compile, or import remappings\n\nOptions:\n  -j, --threads <THREADS>          Number of threads to use. Zero specifies the number of logical cores [default: 4] [aliases: --jobs]\n      --evm-version <EVM_VERSION>  EVM version [default: prague] [possible values: homestead, tangerineWhistle, spuriousDragon, byzantium, constantinople, petersburg, istanbul, berlin, london, paris, shanghai, cancun, prague, osaka]\n      --stop-after <STOP_AFTER>    Stop execution after the given compiler stage [possible values: parsing, lowering, analysis]\n      --out-dir <OUT_DIR>          Directory to write output files\n      --emit <EMIT>                Comma separated list of types of output for the compiler to emit [possible values: abi, hashes]\n  -Z <FLAG>                        Unstable flags. WARNING: these are completely unstable, and may change at any time\n  -h, --help                       Print help (see more with '--help')\n  -V, --version                    Print version"); }
fn print_long_help(){ print_short_help(); println!("\nInput options:\n      --base-path <BASE_PATH>        Use the given path as the root of the source tree\n  -I, --include-path <INCLUDE_PATH>  Directory to search for files\n      --allow-paths <ALLOW_PATHS>    Allow a given path for imports\n\nDisplay options:\n      --color <COLOR>                Coloring [default: auto] [possible values: auto, always, never]\n  -v, --verbose                      Use verbose output\n      --pretty-json                  Pretty-print JSON output\n      --pretty-json-err              Pretty-print error JSON output\n      --error-format <ERROR_FORMAT>  How errors and other messages are produced [default: human] [possible values: human, json, rustc-json]\n      --error-format-human <VALUE>   Human-readable error message style [default: unicode]\n      --diagnostic-width <WIDTH>     Terminal width for error message formatting\n      --no-warnings                  Whether to disable warnings"); }
fn print_zhelp(){ eprintln!("error: List of all unstable flags.\nWARNING: these are completely unstable, and may change at any time!\n\nOptions:\n      -Zui-testing\n          Enables UI testing mode\n\n      -Zhelp\n          Print help\n\nUsage: solar [OPTIONS] [INPUT]...\n\nFor more information, try '--help'."); }
