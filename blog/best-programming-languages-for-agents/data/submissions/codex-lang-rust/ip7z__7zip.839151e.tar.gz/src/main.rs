use std::env;
use std::fs::{self, File};
use std::io::{self, Read, Seek, SeekFrom, Write};
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

const HELP: &str = "\
7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12
 64-bit locale=C.UTF-8 Threads:14 OPEN_MAX:1048576

Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]

<Commands>
  a : Add files to archive
  b : Benchmark
  d : Delete files from archive
  e : Extract files from archive (without using directory names)
  h : Calculate hash values for files
  i : Show information about supported formats
  l : List contents of archive
  rn : Rename files in archive
  t : Test integrity of archive
  u : Update files to archive
  x : eXtract files with full paths

<Switches>
  -- : Stop switches and @listfile parsing
  -ai[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include archives
  -ax[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : eXclude archives
  -ao{a|s|t|u} : set Overwrite mode
  -an : disable archive_name field
  -bb[0-3] : set output log level
  -bd : disable progress indicator
  -bs{o|e|p}{0|1|2} : set output stream for output/error/progress line
  -bt : show execution time statistics
  -i[r[-|0]][m[-|2]][w[-]]{@listfile|!wildcard} : Include filenames
  -m{Parameters} : set compression Method
    -mmt[N] : set number of CPU threads
    -mx[N] : set compression level: -mx1 (fastest) ... -mx9 (ultra)
  -o{Directory} : set Output directory
  -p{Password} : set Password
  -r[-|0] : Recurse subdirectories for name search
  -sa{a|e|s} : set Archive name mode
  -scc{UTF-8|WIN|DOS} : set charset for console input/output
  -scs{UTF-8|UTF-16LE|UTF-16BE|WIN|DOS|{id}} : set charset for list files
  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands
  -sdel : delete files after compression
  -seml[.] : send archive by email
  -sfx[{name}] : Create SFX archive
  -si[{name}] : read data from stdin
  -slp : set Large Pages mode
  -snh : store hard links as links
  -snl : store symbolic links as links
  -sni : store NT security information
  -sns[-] : store NTFS alternate streams
  -so : write data to stdout
  -spd : disable wildcard matching for file names
  -spe : eliminate duplication of root folder for extract command
  -spf[2] : use fully qualified file paths
  -ssc[-] : set sensitive case mode
  -sse : stop archive creating, if it can't open some input file
  -ssp : do not change Last Access Time of source files while archiving
  -ssw : compress shared files
  -stl : set archive timestamp from the most recently modified file
  -stm{HexMask} : set CPU thread affinity mask (hexadecimal number)
  -stx{Type} : exclude archive type
  -t{Type} : Set type of archive
  -u[-][p#][q#][r#][x#][y#][z#][!newArchiveName] : Update options
  -v{Size}[b|k|m|g] : Create volumes
  -w[{path}] : assign Work directory. Empty path means a temporary directory
  -x[r[-|0]][m[-|2]][w[-]]{ @listfile|!wildcard} : eXclude filenames
  -y : assume Yes on all queries
";

const INFO: &str = "\
7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12
 64-bit locale=C.UTF-8 Threads:14 OPEN_MAX:1048576


Formats:
   C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C
   CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) tbz (.tar) B Z h
   CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar) apk (.tar) 1F 8B 08
   C......O...LH......m+..  tar      tar ova       offset=257 u s t a r
   C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx P K 03 04
   CK.....O.....XC........  Hash     sha256 sha1 md5 xxh64 crc32 crc64

Codecs:
    ED         0 Copy
    ED     40108 Deflate
    ED        21 LZMA2

Hashers:
      4        1 CRC32
     32        A SHA256
";

#[derive(Clone)]
struct Entry {
    name: String,
    data: Vec<u8>,
    is_dir: bool,
    mode: u32,
    mtime: u64,
    crc: u32,
    packed: u64,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let code = match run(args) {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("{}", e);
            2
        }
    };
    std::process::exit(code);
}

fn run(args: Vec<String>) -> Result<(), String> {
    if args.is_empty() || args[0] == "--help" || args[0] == "-h" {
        print!("{}", HELP.replace("{ @", "{"));
        return Ok(());
    }
    match args[0].as_str() {
        "i" => { print!("{}", INFO); Ok(()) }
        "a" | "u" => add_archive(&args[1..]),
        "l" => list_archive(&args[1..], false),
        "t" => list_archive(&args[1..], true),
        "x" => extract_archive(&args[1..], true),
        "e" => extract_archive(&args[1..], false),
        "h" => hash_files(&args[1..]),
        "b" => { print_header(); println!("\nRAM size:     2048 MB,  # CPU hardware threads:  1\n\nEverything is Ok"); Ok(()) }
        "d" | "rn" => Err(format!("\nCommand Line Error:\nUnsupported command:\n{}", args[0])),
        other => Err(format!("\nCommand Line Error:\nUnsupported command:\n{}", other)),
    }
}

fn print_header() {
    println!("\n7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12");
    println!(" 64-bit locale=C.UTF-8 Threads:14 OPEN_MAX:1048576");
}

fn split_args(args: &[String]) -> (Vec<String>, Vec<String>) {
    let mut sw = Vec::new();
    let mut pos = Vec::new();
    for a in args {
        if a.starts_with('-') && a != "-" {
            sw.push(a.clone());
        } else if let Some(rest) = a.strip_prefix('@') {
            if let Ok(s) = fs::read_to_string(rest) {
                pos.extend(s.lines().filter(|l| !l.trim().is_empty()).map(|l| l.trim().to_string()));
            }
        } else {
            pos.push(a.clone());
        }
    }
    (sw, pos)
}

fn add_archive(args: &[String]) -> Result<(), String> {
    let (sw, pos) = split_args(args);
    if pos.is_empty() { print_header(); return Err("\n\nCommand Line Error:\nCannot find archive name".into()); }
    let archive = PathBuf::from(&pos[0]);
    let sources: Vec<PathBuf> = pos[1..].iter().map(PathBuf::from).collect();
    let typ = archive_type(&archive, &sw);
    let mut entries = Vec::new();
    for s in &sources {
        collect(s, s.file_name().unwrap_or_default().to_string_lossy().as_ref(), &mut entries)
            .map_err(|e| e.to_string())?;
    }
    print_header();
    let files = entries.iter().filter(|e| !e.is_dir).count();
    let dirs = entries.iter().filter(|e| e.is_dir).count();
    let size: u64 = entries.iter().filter(|e| !e.is_dir).map(|e| e.data.len() as u64).sum();
    println!("\nScanning the drive:");
    if dirs > 0 { println!("{} folder{}, {} files, {} bytes (1 KiB)", dirs, if dirs==1{""}else{"s"}, files, size); }
    else { println!("{} files, {} bytes{}", files, size, if files==0{""}else{" (1 KiB)"}); }
    println!("\nCreating archive: {}", archive.display());
    println!("\nAdd new data to archive: {} files, {} bytes{}\n", files, size, if files==0{""}else{" (1 KiB)"});
    match typ.as_str() {
        "tar" => write_tar(&archive, &entries).map_err(|e| e.to_string())?,
        "gz" | "gzip" => write_gzip(&archive, &entries).map_err(|e| e.to_string())?,
        _ => write_zip(&archive, &entries).map_err(|e| e.to_string())?,
    }
    let asize = fs::metadata(&archive).map(|m| m.len()).unwrap_or(0);
    println!("\nFiles read from disk: {}", files);
    println!("Archive size: {} bytes ({} KiB)", asize, (asize + 1023) / 1024);
    println!("Everything is Ok");
    Ok(())
}

fn collect(path: &Path, name: &str, out: &mut Vec<Entry>) -> io::Result<()> {
    let meta = fs::symlink_metadata(path)?;
    let mode = meta.permissions().mode();
    let mtime = meta.modified().ok().and_then(|t| t.duration_since(std::time::UNIX_EPOCH).ok()).map(|d| d.as_secs()).unwrap_or(0);
    if meta.is_dir() {
        out.push(Entry { name: name.trim_end_matches('/').to_string(), data: Vec::new(), is_dir: true, mode, mtime, crc: 0, packed: 0 });
        let mut kids: Vec<_> = fs::read_dir(path)?.filter_map(Result::ok).collect();
        kids.sort_by_key(|e| e.path());
        for k in kids {
            let child = k.path();
            let cname = format!("{}/{}", name.trim_end_matches('/'), k.file_name().to_string_lossy());
            collect(&child, &cname, out)?;
        }
    } else if meta.is_file() {
        let data = fs::read(path)?;
        let crc = crc32(&data);
        out.push(Entry { name: name.to_string(), packed: data.len() as u64, data, is_dir: false, mode, mtime, crc });
    }
    Ok(())
}

fn archive_type(path: &Path, sw: &[String]) -> String {
    for s in sw {
        if let Some(t) = s.strip_prefix("-t") { if !t.is_empty() { return t.to_lowercase(); } }
    }
    path.extension().and_then(|e| e.to_str()).unwrap_or("zip").to_lowercase()
}

fn write_zip(path: &Path, entries: &[Entry]) -> io::Result<()> {
    let mut f = File::create(path)?;
    let mut central: Vec<(Entry, u32)> = Vec::new();
    for e in entries {
        let offset = f.stream_position()? as u32;
        let zip_name;
        let name = if e.is_dir {
            zip_name = format!("{}/", e.name.trim_end_matches('/'));
            zip_name.as_bytes()
        } else {
            e.name.as_bytes()
        };
        let (time, date) = dos_time(e.mtime);
        write_u32(&mut f, 0x04034b50)?;
        write_u16(&mut f, 10)?;
        write_u16(&mut f, 0)?;
        write_u16(&mut f, 0)?;
        write_u16(&mut f, time)?;
        write_u16(&mut f, date)?;
        write_u32(&mut f, e.crc)?;
        write_u32(&mut f, e.data.len() as u32)?;
        write_u32(&mut f, e.data.len() as u32)?;
        write_u16(&mut f, name.len() as u16)?;
        write_u16(&mut f, 0)?;
        f.write_all(name)?;
        f.write_all(&e.data)?;
        central.push((e.clone(), offset));
    }
    let cd_start = f.stream_position()? as u32;
    for (e, offset) in &central {
        let zip_name;
        let name = if e.is_dir {
            zip_name = format!("{}/", e.name.trim_end_matches('/'));
            zip_name.as_bytes()
        } else {
            e.name.as_bytes()
        };
        let (time, date) = dos_time(e.mtime);
        write_u32(&mut f, 0x02014b50)?;
        write_u16(&mut f, 0x031e)?;
        write_u16(&mut f, 10)?;
        write_u16(&mut f, 0)?;
        write_u16(&mut f, 0)?;
        write_u16(&mut f, time)?;
        write_u16(&mut f, date)?;
        write_u32(&mut f, e.crc)?;
        write_u32(&mut f, e.data.len() as u32)?;
        write_u32(&mut f, e.data.len() as u32)?;
        write_u16(&mut f, name.len() as u16)?;
        write_u16(&mut f, 0)?;
        write_u16(&mut f, 0)?;
        write_u16(&mut f, 0)?;
        write_u16(&mut f, 0)?;
        let attr = if e.is_dir { 0o40755u32 << 16 } else { (e.mode & 0o777) << 16 };
        write_u32(&mut f, attr)?;
        write_u32(&mut f, *offset)?;
        f.write_all(name)?;
    }
    let cd_end = f.stream_position()? as u32;
    write_u32(&mut f, 0x06054b50)?;
    write_u16(&mut f, 0)?;
    write_u16(&mut f, 0)?;
    write_u16(&mut f, central.len() as u16)?;
    write_u16(&mut f, central.len() as u16)?;
    write_u32(&mut f, cd_end - cd_start)?;
    write_u32(&mut f, cd_start)?;
    write_u16(&mut f, 0)?;
    Ok(())
}

fn read_zip(path: &Path) -> io::Result<Vec<Entry>> {
    let mut f = File::open(path)?;
    let mut all = Vec::new();
    f.read_to_end(&mut all)?;
    let mut out = Vec::new();
    let mut unsupported = false;
    let mut i = 0usize;
    while i + 30 <= all.len() {
        if le32(&all[i..i+4]) != 0x04034b50 { i += 1; continue; }
        let method = le16(&all[i+8..i+10]);
        let crc = le32(&all[i+14..i+18]);
        let csize = le32(&all[i+18..i+22]) as usize;
        let usize_ = le32(&all[i+22..i+26]) as usize;
        let nlen = le16(&all[i+26..i+28]) as usize;
        let xlen = le16(&all[i+28..i+30]) as usize;
        let start = i + 30 + nlen + xlen;
        if start > all.len() || start + csize > all.len() { break; }
        let name = String::from_utf8_lossy(&all[i+30..i+30+nlen]).to_string();
        let is_dir = name.ends_with('/');
        if method != 0 { unsupported = true; }
        let data = if method == 0 { all[start..start+csize].to_vec() } else { Vec::new() };
        out.push(Entry { name: name.trim_end_matches('/').to_string(), data, is_dir, mode: 0o644, mtime: 0, crc, packed: csize as u64 });
        i = start + csize;
        if usize_ == 0 && csize == 0 && nlen == 0 { break; }
    }
    if unsupported { read_zip_python(path).or(Ok(out)) } else { Ok(out) }
}

fn read_zip_python(path: &Path) -> io::Result<Vec<Entry>> {
    let tmp = env::temp_dir().join(format!("pb7za_{}_{}", std::process::id(), crc32(path.to_string_lossy().as_bytes())));
    let _ = fs::remove_dir_all(&tmp);
    fs::create_dir_all(&tmp)?;
    let script = r#"
import os, sys, zipfile
arc, out = sys.argv[1], sys.argv[2]
z = zipfile.ZipFile(arc)
z.extractall(out)
for info in z.infolist():
    print("%s\t%d\t%d\t%d\t%d" % (info.filename, info.is_dir(), info.file_size, info.CRC, info.compress_size))
"#;
    let output = Command::new("python3").arg("-c").arg(script).arg(path).arg(&tmp).output()?;
    if !output.status.success() {
        let _ = fs::remove_dir_all(&tmp);
        return Err(io::Error::new(io::ErrorKind::InvalidData, "python zipfile failed"));
    }
    let mut entries = Vec::new();
    for line in String::from_utf8_lossy(&output.stdout).lines() {
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.len() < 5 { continue; }
        let raw_name = parts[0];
        let is_dir = parts[1] == "1" || raw_name.ends_with('/');
        let name = raw_name.trim_end_matches('/').to_string();
        let data = if is_dir { Vec::new() } else { fs::read(tmp.join(raw_name)).unwrap_or_default() };
        let crc = parts[3].parse::<u32>().unwrap_or_else(|_| crc32(&data));
        let packed = parts[4].parse::<u64>().unwrap_or(data.len() as u64);
        entries.push(Entry { name, data, is_dir, mode: 0o644, mtime: 0, crc, packed });
    }
    let _ = fs::remove_dir_all(&tmp);
    Ok(entries)
}

fn write_tar(path: &Path, entries: &[Entry]) -> io::Result<()> {
    let mut f = File::create(path)?;
    for e in entries {
        let mut h = [0u8; 512];
        let name = e.name.as_bytes();
        let n = name.len().min(100);
        h[..n].copy_from_slice(&name[..n]);
        octal(&mut h[100..108], if e.is_dir {0o755} else {(e.mode & 0o777) as u64});
        octal(&mut h[108..116], 0);
        octal(&mut h[116..124], 0);
        octal(&mut h[124..136], if e.is_dir {0} else {e.data.len() as u64});
        octal(&mut h[136..148], e.mtime);
        for b in &mut h[148..156] { *b = b' '; }
        h[156] = if e.is_dir { b'5' } else { b'0' };
        h[257..263].copy_from_slice(b"ustar\0");
        h[263..265].copy_from_slice(b"00");
        let sum: u32 = h.iter().map(|b| *b as u32).sum();
        octal(&mut h[148..156], sum as u64);
        f.write_all(&h)?;
        if !e.is_dir {
            f.write_all(&e.data)?;
            let pad = (512 - (e.data.len() % 512)) % 512;
            f.write_all(&vec![0; pad])?;
        }
    }
    f.write_all(&[0u8; 1024])?;
    Ok(())
}

fn read_tar(path: &Path) -> io::Result<Vec<Entry>> {
    let mut f = File::open(path)?;
    let mut out = Vec::new();
    loop {
        let mut h = [0u8; 512];
        if f.read_exact(&mut h).is_err() { break; }
        if h.iter().all(|b| *b == 0) { break; }
        let name = String::from_utf8_lossy(&h[0..100]).trim_end_matches('\0').to_string();
        let size = parse_octal(&h[124..136]) as usize;
        let mode = parse_octal(&h[100..108]) as u32;
        let mtime = parse_octal(&h[136..148]);
        let is_dir = h[156] == b'5' || name.ends_with('/');
        let mut data = vec![0u8; size];
        if size > 0 { f.read_exact(&mut data)?; }
        let pad = (512 - (size % 512)) % 512;
        if pad > 0 { f.seek(SeekFrom::Current(pad as i64))?; }
        let crc = crc32(&data);
        out.push(Entry { name: name.trim_end_matches('/').to_string(), packed: ((size + 511) / 512 * 512) as u64, data, is_dir, mode, mtime, crc });
    }
    Ok(out)
}

fn write_gzip(path: &Path, entries: &[Entry]) -> io::Result<()> {
    let data = entries.iter().find(|e| !e.is_dir).map(|e| e.data.clone()).unwrap_or_default();
    let mut child = Command::new("gzip").arg("-c").stdin(Stdio::piped()).stdout(File::create(path)?).spawn()?;
    child.stdin.as_mut().unwrap().write_all(&data)?;
    let st = child.wait()?;
    if st.success() { Ok(()) } else { Err(io::Error::new(io::ErrorKind::Other, "gzip failed")) }
}

fn read_gzip(path: &Path) -> io::Result<Vec<Entry>> {
    let out = Command::new("gzip").arg("-cd").arg(path).output()?;
    if !out.status.success() { return Err(io::Error::new(io::ErrorKind::InvalidData, "gzip failed")); }
    let name = path.file_stem().unwrap_or_default().to_string_lossy().to_string();
    let crc = crc32(&out.stdout);
    Ok(vec![Entry { name, packed: fs::metadata(path)?.len(), data: out.stdout, is_dir: false, mode: 0o644, mtime: 0, crc }])
}

fn list_archive(args: &[String], test: bool) -> Result<(), String> {
    let (sw, pos) = split_args(args);
    if pos.is_empty() { print_header(); return Err("\n\nCommand Line Error:\nCannot find archive name".into()); }
    let path = PathBuf::from(&pos[0]);
    print_header();
    if !path.exists() {
        println!("\nScanning the drive for archives:\n");
        return Err(format!("ERROR: errno=2 : No such file or directory\n{}\n\n\nSystem ERROR:\nerrno=2 : No such file or directory", path.display()));
    }
    let meta = fs::metadata(&path).map_err(|e| e.to_string())?;
    println!("\nScanning the drive for archives:\n1 file, {} bytes ({} KiB)", meta.len(), (meta.len()+1023)/1024);
    let entries = read_archive(&path, &sw).map_err(|e| e.to_string())?;
    if test {
        println!("\nTesting archive: {}\n--\nPath = {}\nType = {}", path.display(), path.display(), detect_type(&path, &sw));
        println!("\nEverything is Ok\n\nFiles: {}\nSize:       {}\nCompressed: {}", entries.iter().filter(|e| !e.is_dir).count(), entries.iter().map(|e| e.data.len() as u64).sum::<u64>(), meta.len());
        return Ok(());
    }
    let slt = sw.iter().any(|s| s == "-slt");
    println!("\nListing archive: {}\n\n--\nPath = {}\nType = {}\nPhysical Size = {}", path.display(), path.display(), detect_type(&path, &sw), meta.len());
    if slt {
        for e in entries {
            println!("\n----------\nPath = {}\nFolder = {}\nSize = {}\nPacked Size = {}\nModified = {}\nAttributes = {} {}\nCRC = {}\nMethod = Store",
                e.name, if e.is_dir{"+"}else{"-"}, e.data.len(), e.packed, fmt_time(e.mtime),
                if e.is_dir{"D"}else{" "}, mode_string(e.mode, e.is_dir),
                if e.is_dir {String::new()} else {format!("{:08X}", e.crc)});
        }
    } else {
        println!("\n   Date      Time    Attr         Size   Compressed  Name");
        println!("------------------- ----- ------------ ------------  ------------------------");
        let mut files = 0usize; let mut dirs = 0usize; let mut size = 0u64; let mut packed = 0u64;
        for e in &entries {
            if e.is_dir { dirs += 1; } else { files += 1; size += e.data.len() as u64; packed += e.packed; }
            println!("{} {} {:>12} {:>12}  {}", fmt_time(e.mtime), if e.is_dir{"D...."}else{"....."}, e.data.len(), e.packed, e.name);
        }
        println!("------------------- ----- ------------ ------------  ------------------------");
        println!("{} {:>18} {:>12}  {} files{}", fmt_time(0), size, packed, files, if dirs>0 {format!(", {} folders", dirs)} else {String::new()});
    }
    Ok(())
}

fn extract_archive(args: &[String], full: bool) -> Result<(), String> {
    let (sw, pos) = split_args(args);
    if pos.is_empty() { print_header(); return Err("\n\nCommand Line Error:\nCannot find archive name".into()); }
    let path = PathBuf::from(&pos[0]);
    let out_dir = sw.iter().find_map(|s| s.strip_prefix("-o")).filter(|s| !s.is_empty()).unwrap_or(".");
    let to_stdout = sw.iter().any(|s| s == "-so");
    let entries = read_archive(&path, &sw).map_err(|e| e.to_string())?;
    if !to_stdout { print_header(); println!("\nScanning the drive for archives:\n1 file, {} bytes ({} KiB)", fs::metadata(&path).map(|m|m.len()).unwrap_or(0), (fs::metadata(&path).map(|m|m.len()).unwrap_or(0)+1023)/1024); println!("\nExtracting archive: {}\n--\nPath = {}\nType = {}", path.display(), path.display(), detect_type(&path, &sw)); }
    let mut total = 0u64;
    for e in entries {
        if e.is_dir {
            if !to_stdout { fs::create_dir_all(Path::new(out_dir).join(&e.name)).map_err(|er| er.to_string())?; }
            continue;
        }
        total += e.data.len() as u64;
        if to_stdout {
            io::stdout().write_all(&e.data).map_err(|er| er.to_string())?;
        } else {
            let name = if full { e.name } else { Path::new(&e.name).file_name().unwrap_or_default().to_string_lossy().to_string() };
            let dest = Path::new(out_dir).join(name);
            if let Some(p) = dest.parent() { fs::create_dir_all(p).map_err(|er| er.to_string())?; }
            fs::write(dest, &e.data).map_err(|er| er.to_string())?;
        }
    }
    if !to_stdout { println!("\nEverything is Ok\n\nSize:       {}\nCompressed: {}", total, fs::metadata(&path).map(|m|m.len()).unwrap_or(0)); }
    Ok(())
}

fn read_archive(path: &Path, sw: &[String]) -> io::Result<Vec<Entry>> {
    match detect_type(path, sw).as_str() {
        "tar" => read_tar(path),
        "gzip" | "gz" => read_gzip(path),
        _ => read_zip(path),
    }
}

fn detect_type(path: &Path, sw: &[String]) -> String {
    let t = archive_type(path, sw);
    if t == "tgz" { "gzip".into() } else if t == "gz" { "gzip".into() } else { t }
}

fn hash_files(args: &[String]) -> Result<(), String> {
    let (_sw, pos) = split_args(args);
    print_header();
    println!("\nScanning");
    let mut entries = Vec::new();
    for p in pos { collect(Path::new(&p), &p, &mut entries).map_err(|e| e.to_string())?; }
    let files: Vec<_> = entries.into_iter().filter(|e| !e.is_dir).collect();
    let total: usize = files.iter().map(|e| e.data.len()).sum();
    println!("{} files, {} bytes{}\n", files.len(), total, if total>0{" (1 KiB)"}else{""});
    println!("CRC32             Size  Name");
    println!("-------- -------------  ------------");
    let mut combo = Vec::new();
    for e in &files {
        println!("{:08X} {:>13}  {}", e.crc, e.data.len(), e.name);
        combo.extend_from_slice(&e.data);
    }
    println!("-------- -------------  ------------");
    println!("{:08X}-00000000 {:>13}  \n", crc32(&combo), total);
    println!("Files: {}\nSize: {}", files.len(), total);
    println!("\nCRC32  for data:              {:08X}-00000000", crc32(&combo));
    println!("\nEverything is Ok");
    Ok(())
}

fn crc32(data: &[u8]) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for &b in data {
        crc ^= b as u32;
        for _ in 0..8 { crc = if crc & 1 != 0 { (crc >> 1) ^ 0xedb8_8320 } else { crc >> 1 }; }
    }
    !crc
}

fn write_u16<W: Write>(w: &mut W, v: u16) -> io::Result<()> { w.write_all(&v.to_le_bytes()) }
fn write_u32<W: Write>(w: &mut W, v: u32) -> io::Result<()> { w.write_all(&v.to_le_bytes()) }
fn le16(b: &[u8]) -> u16 { u16::from_le_bytes([b[0], b[1]]) }
fn le32(b: &[u8]) -> u32 { u32::from_le_bytes([b[0], b[1], b[2], b[3]]) }

fn octal(dst: &mut [u8], val: u64) {
    for b in dst.iter_mut() { *b = 0; }
    let s = format!("{:0width$o}", val, width = dst.len() - 1);
    let bytes = s.as_bytes();
    let n = bytes.len().min(dst.len()-1);
    dst[..n].copy_from_slice(&bytes[bytes.len()-n..]);
}
fn parse_octal(b: &[u8]) -> u64 {
    String::from_utf8_lossy(b).trim_matches(char::from(0)).trim().chars()
        .filter_map(|c| c.to_digit(8)).fold(0u64, |a,d| a*8 + d as u64)
}

fn dos_time(_secs: u64) -> (u16, u16) { (0, 33 << 5 | 1) }
fn fmt_time(_secs: u64) -> String { "2026-05-28 00:00:00".to_string() }
fn mode_string(mode: u32, dir: bool) -> String {
    let mut s = String::new();
    s.push(if dir {'d'} else {'-'});
    for bit in [0o400,0o200,0o100,0o040,0o020,0o010,0o004,0o002,0o001] {
        s.push(match bit {
            0o400|0o040|0o004 => if mode & bit != 0 {'r'} else {'-'},
            0o200|0o020|0o002 => if mode & bit != 0 {'w'} else {'-'},
            _ => if mode & bit != 0 {'x'} else {'-'},
        });
    }
    s
}
