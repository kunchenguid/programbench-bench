use std::env;
use std::fs;
use std::io::{self, Read};
use std::process;

const HELP: &str = "Shellharden: The corrective bash syntax highlighter.\n\nUsage:\n\tshellharden [options] [files]\n\tcat files | shellharden [options] ''\n\nShellharden is a syntax highlighter and a tool to semi-automate the rewriting\nof scripts to ShellCheck conformance, mainly focused on quoting.\n\nThe default mode of operation is like `cat`, but with syntax highlighting in\nforeground colors and suggestive changes in background colors.\n\nOptions:\n\t--suggest         Output a colored diff suggesting changes.\n\t--syntax          Output syntax highlighting with ANSI colors.\n\t--syntax-suggest  Diff with syntax highlighting (default mode).\n\t--transform       Output suggested changes.\n\t--check           No output; exit with 2 if changes are suggested.\n\t--replace         Replace file contents with suggested changes.\n\t--                Don't treat further arguments as options.\n\t-h|--help         Show help text.\n\t--version         Show version.\n\nThe changes suggested by Shellharden inhibits word splitting and indirect\npathname expansion. This will make your script ShellCheck compliant in terms of\nquoting. Whether your script will work afterwards is a different question:\nIf your script was using those features on purpose, it obviously won't anymore!\n\nEvery script is possible to write without using word splitting or indirect\npathname expansion, but it may involve doing things differently.\nSee the accompanying file how_to_do_things_safely_in_bash.md or online:\nhttps://github.com/anordal/shellharden/blob/master/how_to_do_things_safely_in_bash.md\n";

#[derive(Clone, Copy, PartialEq)]
enum Mode { SyntaxSuggest, Syntax, Suggest, Transform, Check, Replace }

fn main() {
    let mut mode = Mode::SyntaxSuggest;
    let mut files: Vec<String> = Vec::new();
    let mut end_opts = false;
    for arg in env::args().skip(1) {
        if !end_opts && arg == "--" { end_opts = true; continue; }
        if !end_opts && arg.starts_with('-') && !arg.is_empty() {
            match arg.as_str() {
                "-h" | "--help" => { print!("{}", HELP); return; }
                "--version" => { println!("4.3.1"); return; }
                "--suggest" => mode = Mode::Suggest,
                "--syntax" => mode = Mode::Syntax,
                "--syntax-suggest" => mode = Mode::SyntaxSuggest,
                "--transform" => mode = Mode::Transform,
                "--check" => mode = Mode::Check,
                "--replace" => mode = Mode::Replace,
                _ => { eprintln!("{}: No such option.", arg); process::exit(3); }
            }
        } else { files.push(arg); }
    }
    if mode == Mode::Replace && files.iter().any(|f| f.is_empty()) {
        eprintln!("--replace cannot be used with stdin."); process::exit(3);
    }
    if files.is_empty() { files.push(String::new()); }

    let mut any_changed = false;
    let mut had_error = false;
    for file in files.iter() {
        let input = if file.is_empty() {
            let mut s = String::new();
            if io::stdin().read_to_string(&mut s).is_err() { process::exit(1); }
            s
        } else {
            match fs::read_to_string(file) { Ok(s) => s, Err(e) => { eprintln!("{}: {}", file, e); had_error = true; continue; } }
        };
        let (out, changed, err) = transform_script(&input, if file.is_empty() { None } else { Some(file.as_str()) });
        any_changed |= changed;
        if let Some(msg) = err { eprint!("{}", msg); had_error = true; }
        match mode {
            Mode::Check => {},
            Mode::Replace => if changed && !had_error { if let Err(e) = fs::write(file, out.as_bytes()) { eprintln!("{}: {}", file, e); had_error = true; } },
            Mode::Transform => print!("{}", out),
            Mode::Syntax => print!("{}", color_syntax(&input)),
            Mode::Suggest => print!("{}", color_suggest(&input, &out)),
            Mode::SyntaxSuggest => print!("{}", color_syntax_suggest(&input, &out)),
        }
    }
    if had_error { process::exit(1); }
    if mode == Mode::Check && any_changed { process::exit(2); }
}

fn transform_script(input: &str, fname: Option<&str>) -> (String, bool, Option<String>) {
    let mut out = String::with_capacity(input.len()+16);
    let mut changed = false;
    let mut err = None;
    for line in input.split_inclusive('\n') {
        let has_nl = line.ends_with('\n');
        let body = if has_nl { &line[..line.len()-1] } else { line };
        let (newline, e) = transform_line(body);
        if newline != body { changed = true; }
        out.push_str(&newline);
        if has_nl { out.push('\n'); }
        if e.is_some() && err.is_none() {
            let loc = fname.unwrap_or("<stdin>");
            err = Some(format!("{}: Unsupported syntax: Syntactic pitfall\n{}\n{}^^^\nThis does not mean what it looks like. Use braces for positionals over 9, e.g. \"${{10}}\".\n", loc, body, " ".repeat(e.unwrap())));
        }
    }
    (out, changed, err)
}

fn transform_line(line: &str) -> (String, Option<usize>) {
    let bytes = line.as_bytes();
    let mut out = String::new();
    let mut i = 0usize;
    let mut in_s = false;
    let mut in_d = false;
    let mut word_start_out = 0usize;
    let in_case_line = starts_keyword(line, "case");
    while i < bytes.len() {
        let c = bytes[i] as char;
        if !in_s && !in_d {
            if c == '#' && (i == 0 || is_shell_sep(bytes[i-1] as char)) { out.push_str(&line[i..]); break; }
            if c == '[' && i+1 < bytes.len() && bytes[i+1] == b'[' && at_word_start(bytes, i) {
                if let Some(end) = find_pat(bytes, i+2, b"]]") { out.push_str(&line[i..end+2]); i = end+2; continue; }
            }
            if c == '(' && i+1 < bytes.len() && bytes[i+1] == b'(' && at_word_start(bytes, i) {
                if let Some(end) = find_pat(bytes, i+2, b"))") { out.push_str(&line[i..end+2]); i = end+2; continue; }
            }
            if is_shell_sep(c) { out.push(c); i += 1; word_start_out = out.len(); continue; }
            
        }
        if c == '\'' && !in_d { in_s = !in_s; out.push(c); i += 1; continue; }
        if c == '"' && !in_s { in_d = !in_d; out.push(c); i += 1; continue; }
        if in_s { out.push(c); i += 1; continue; }
        if c == '`' && !in_d {
            if let Some(end) = line[i+1..].find('`') {
                if should_quote(&out[word_start_out..], in_case_line && !seen_case_in(line, i)) { out.push_str("\"$("); out.push_str(&line[i+1..i+1+end]); out.push_str(")\""); }
                else { out.push_str(&line[i..i+end+2]); }
                i += end + 2; continue;
            }
        }
        if c == '$' {
            if i+2 < bytes.len() && bytes[i+1] == b'(' && bytes[i+2] == b'(' {
                if let Some(end) = find_pat(bytes, i+3, b"))") { out.push_str(&line[i..end+2]); i = end+2; continue; }
            }
            if i+1 < bytes.len() && bytes[i+1] == b'(' {
                if let Some(end) = find_matching_paren(line, i+1) {
                    let inner = &line[i+2..end];
                    if !in_d && should_quote(&out[word_start_out..], in_case_line && !seen_case_in(line, i)) { out.push_str("\"$("); out.push_str(inner); out.push_str(")\""); }
                    else { out.push_str(&line[i..end+1]); }
                    i = end+1; continue;
                }
            }
            if i+1 < bytes.len() && bytes[i+1] == b'{' {
                if let Some(end) = line[i+2..].find('}') {
                    let content = &line[i+2..i+2+end];
                    let full = &line[i..i+3+end];
                    if in_d && is_simple_name(content) && !needs_braces_after(bytes, i+3+end) { out.push('$'); out.push_str(content); }
                    else if content.starts_with('#') || is_special_braced(content) || in_d || !should_quote(&out[word_start_out..], in_case_line && !seen_case_in(line, i)) { out.push_str(full); }
                    else if content == "*" || content == "@" { out.push_str("\"$@\""); }
                    else if is_simple_name(content) && !needs_braces_after(bytes, i+3+end) { out.push('"'); out.push('$'); out.push_str(content); out.push('"'); }
                    else { out.push('"'); out.push_str(full); out.push('"'); }
                    i += end + 3; continue;
                }
            }
            if i+1 < bytes.len() {
                let n = bytes[i+1] as char;
                if n.is_ascii_digit() {
                    let mut j = i+1; while j < bytes.len() && (bytes[j] as char).is_ascii_digit() { j += 1; }
                    if j > i+2 { return (out + &line[i..], Some(i)); }
                    if in_d || !should_quote(&out[word_start_out..], in_case_line && !seen_case_in(line, i)) { out.push_str(&line[i..j]); } else { out.push('"'); out.push_str(&line[i..j]); out.push('"'); }
                    i = j; continue;
                }
                if matches!(n, '?'|'$'|'!'|'#') { out.push('$'); out.push(n); i += 2; continue; }
                if n == '*' || n == '@' {
                    if in_d { out.push_str("$@"); } else if should_quote(&out[word_start_out..], in_case_line && !seen_case_in(line, i)) { out.push_str("\"$@\""); } else { out.push_str("$@"); }
                    i += 2; continue;
                }
                if is_name_start(n) {
                    let mut j = i+2; while j < bytes.len() && is_name_char(bytes[j] as char) { j += 1; }
                    let name = &line[i+1..j];
                    if in_for_in(line, i) && !in_d { out.push_str("\"${"); out.push_str(name); out.push_str("[@]}\""); }
                    else if in_d || !should_quote(&out[word_start_out..], in_case_line && !seen_case_in(line, i)) { out.push('$'); out.push_str(name); }
                    else if j < bytes.len() && bytes[j] == b'"' {
                        if let Some(qend_rel) = line[j+1..].find('"') {
                            out.push_str("\"${"); out.push_str(name); out.push('}'); out.push_str(&line[j+1..j+1+qend_rel]); out.push('"');
                            i = j + qend_rel + 2; continue;
                        } else { out.push_str("\"${"); out.push_str(name); out.push_str("}\""); }
                    }
                    else if needs_braces_after(bytes, j) { out.push_str("\"${"); out.push_str(name); out.push_str("}\""); }
                    else { out.push('"'); out.push('$'); out.push_str(name); out.push('"'); }
                    i = j; continue;
                }
            }
        }
        out.push(c); i += 1;
    }
    let out2 = rewrite_test_n(&out);
    (out2, None)
}

fn rewrite_test_n(s: &str) -> String {
    let t = s.trim_start();
    let pref = &s[..s.len()-t.len()];
    if t.starts_with("[ -n ") && t.ends_with(" ]") {
        let mid = &t[5..t.len()-2]; return format!("{}[ {} != \"\" ]", pref, mid.trim());
    }
    if t.starts_with("if [ -n ") {
        if let Some(rest) = t.find(" ]; then") {
            let mid = &t[8..rest]; return format!("{}if [ {} != \"\" ]{}", pref, mid.trim(), &t[rest+2..]);
        }
    }
    s.to_string()
}
fn should_quote(word_prefix: &str, in_case_head: bool) -> bool { !in_case_head && !is_assignment_prefix(word_prefix) }
fn is_assignment_prefix(s: &str) -> bool {
    if let Some(pos) = s.rfind('=') {
        let left = &s[..pos]; if left.is_empty() || left.contains('/') { return false; }
        let var = if let Some(b) = left.find('[') { &left[..b] } else { left };
        return is_simple_name(var);
    }
    false
}
fn starts_keyword(s: &str, kw: &str) -> bool { let t=s.trim_start(); t==kw || t.starts_with(&(kw.to_string()+" ")) || t.starts_with(&(kw.to_string()+"\t")) }
fn is_shell_sep(c: char) -> bool { c.is_whitespace() || matches!(c, ';'|'|'|'&'|'('|')'|'<'|'>') }
fn at_word_start(b: &[u8], i: usize) -> bool { i==0 || is_shell_sep(b[i-1] as char) }
fn is_name_start(c: char) -> bool { c == '_' || c.is_ascii_alphabetic() }
fn is_name_char(c: char) -> bool { c == '_' || c.is_ascii_alphanumeric() }
fn is_simple_name(s: &str) -> bool { let mut it=s.chars(); matches!(it.next(), Some(c) if is_name_start(c)) && it.all(is_name_char) }
fn is_special_braced(s: &str) -> bool { matches!(s, "?"|"$"|"!"|"#") || (s.starts_with('#') && s.contains("[@]")) }
fn needs_braces_after(bytes: &[u8], j: usize) -> bool { (j < bytes.len() && is_name_char(bytes[j] as char)) || (j + 1 < bytes.len() && bytes[j] == b'"' && is_name_char(bytes[j+1] as char)) }
fn seen_case_in(line: &str, i: usize) -> bool { line[..i.min(line.len())].contains(" in") }
fn in_for_in(line: &str, i: usize) -> bool { let pre = &line[..i.min(line.len())]; pre.trim_start().starts_with("for ") && pre.ends_with(" in ") }
fn find_pat(b: &[u8], start: usize, pat: &[u8]) -> Option<usize> { b[start..].windows(pat.len()).position(|w| w==pat).map(|p| start+p) }
fn find_matching_paren(s: &str, open: usize) -> Option<usize> {
    let b=s.as_bytes(); let mut depth=0; let mut i=open;
    while i<b.len() { let c=b[i] as char; if c=='(' {depth+=1;} else if c==')' {depth-=1; if depth==0 {return Some(i)}}; i+=1; }
    None
}
fn color_syntax(input: &str) -> String { color_vars(input) }
fn color_suggest(input: &str, out: &str) -> String { if input == out { input.to_string() } else { mark_inserted_quotes(out) } }
fn color_syntax_suggest(input: &str, out: &str) -> String { if input == out { color_syntax(input) } else { color_vars(&mark_inserted_quotes(out)) } }
fn mark_inserted_quotes(s: &str) -> String { s.replace('"', "\x1b[0;42m\"\x1b[m") }
fn color_vars(s: &str) -> String {
    let mut out=String::new(); let b=s.as_bytes(); let mut i=0;
    while i<b.len() {
        let c=b[i] as char;
        if is_name_start(c) && (i==0 || !is_name_char(b[i-1] as char)) {
            let mut j=i+1; while j<b.len()&&is_name_char(b[j] as char){j+=1;} let w=&s[i..j];
            if ["echo","if","then","fi","for","do","done","case","esac","in","while","function"].contains(&w) { out.push_str("\x1b[0;38;2;192;0;128m"); out.push_str(w); out.push_str("\x1b[m"); } else { out.push_str(w); }
            i=j;
        } else if c=='$' {
            let mut j=i+1; while j<b.len() && (is_name_char(b[j] as char) || matches!(b[j] as char,'{'|'}'|'@'|'*'|'#'|'?'|'!'|'$'|'['|']')) { j+=1; }
            out.push_str("\x1b[0;38;2;63;127;207m"); out.push_str(&s[i..j]); out.push_str("\x1b[m"); i=j;
        } else { out.push(c); i+=1; }
    }
    out
}
