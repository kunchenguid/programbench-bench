use std::env;
use std::fs::File;
use std::io::{self, Read, Seek, SeekFrom};
use std::path::Path;

#[derive(Clone, Copy, PartialEq)]
enum Border { Unicode, Ascii, None }
#[derive(Clone, Copy, PartialEq)]
enum Color { Always, Auto, Never, Force }
#[derive(Clone, Copy, PartialEq)]
enum Base { Hex, Dec, Oct, Bin }
#[derive(Clone, Copy, PartialEq)]
enum Endian { Big, Little }
#[derive(Clone, Copy, PartialEq)]
enum CharTable { Default, Ascii, Cp437, Cp1047, Braille }

struct Opt {
    file: Option<String>,
    length: Option<usize>,
    skip: i64,
    block_size: usize,
    no_squeeze: bool,
    color: Color,
    border: Border,
    chars: bool,
    pos: bool,
    ctable: CharTable,
    base: Base,
    panels: Option<usize>,
    group: usize,
    endian: Endian,
    display_offset: i64,
    include: bool,
    terminal_width: Option<usize>,
}

fn main() {
    let mut opt = Opt {
        file: None, length: None, skip: 0, block_size: 512, no_squeeze: false,
        color: Color::Always, border: Border::Unicode, chars: true, pos: true,
        ctable: CharTable::Default, base: Base::Hex, panels: None, group: 1,
        endian: Endian::Big, display_offset: 0, include: false, terminal_width: None,
    };
    let args: Vec<String> = env::args().collect();
    if let Err(e) = parse_args(&args[1..], &mut opt) {
        eprintln!("{e}");
        std::process::exit(2);
    }
    if opt.include {
        if let Err(e) = include_mode(&opt) { eprintln!("Error: {e}"); std::process::exit(1); }
    } else if opt.print_color_table_stub() {
        print_color_table(opt.color != Color::Never);
    } else if let Err(e) = run(&opt) {
        eprintln!("Error: {e}");
        std::process::exit(1);
    }
}

impl Opt {
    fn print_color_table_stub(&self) -> bool {
        env::args().any(|a| a == "--print-color-table")
    }
}

fn parse_args(args: &[String], opt: &mut Opt) -> Result<(), String> {
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let (key, val_inline) = if let Some(p) = a.find('=') { (&a[..p], Some(a[p+1..].to_string())) } else { (a.as_str(), None) };
        let need_val = |i: &mut usize, val: Option<String>| -> Result<String, String> {
            if let Some(v) = val { Ok(v) } else {
                *i += 1;
                args.get(*i).cloned().ok_or_else(|| format!("error: a value is required for '{key}' but none was supplied"))
            }
        };
        match key {
            "-h" => { print_short_help(); std::process::exit(0); }
            "--help" => { print_long_help(); std::process::exit(0); }
            "-V" | "--version" => { println!("hexyl 0.16.0"); std::process::exit(0); }
            "-n" | "--length" | "--bytes" | "-c" | "-l" => {
                let v = need_val(&mut i, val_inline)?;
                opt.length = Some(parse_num(&v, opt.block_size)? as usize);
            }
            "-s" | "--skip" => {
                let v = need_val(&mut i, val_inline)?;
                opt.skip = parse_num(&v, opt.block_size)?;
            }
            "--block-size" => {
                let v = need_val(&mut i, val_inline)?;
                opt.block_size = parse_num(&v, opt.block_size)? as usize;
            }
            "-v" | "--no-squeezing" => opt.no_squeeze = true,
            "--color" => {
                let v = need_val(&mut i, val_inline)?;
                opt.color = match v.as_str() { "always" => Color::Always, "auto" => Color::Auto, "never" => Color::Never, "force" => Color::Force, _ => return Err(format!("error: invalid value '{v}' for '--color <WHEN>'")) };
            }
            "--border" => {
                let v = need_val(&mut i, val_inline)?;
                opt.border = match v.as_str() { "unicode" => Border::Unicode, "ascii" => Border::Ascii, "none" => Border::None, _ => return Err(format!("error: invalid value '{v}' for '--border <STYLE>'")) };
            }
            "-p" | "--plain" => { opt.chars = false; opt.pos = false; opt.border = Border::None; opt.color = Color::Never; }
            "--no-characters" => opt.chars = false,
            "-C" | "--characters" => opt.chars = true,
            "-P" | "--no-position" => opt.pos = false,
            "--character-table" => {
                let v = need_val(&mut i, val_inline)?;
                opt.ctable = match v.as_str() { "default" => CharTable::Default, "ascii" => CharTable::Ascii, "codepage-437" => CharTable::Cp437, "codepage-1047" => CharTable::Cp1047, "braille" => CharTable::Braille, _ => return Err(format!("error: invalid value '{v}' for '--character-table <FORMAT>'")) };
            }
            "--color-scheme" => { let _ = need_val(&mut i, val_inline)?; }
            "-o" | "--display-offset" => {
                let v = need_val(&mut i, val_inline)?;
                opt.display_offset = parse_num(&v, opt.block_size)?;
            }
            "--panels" => {
                let v = need_val(&mut i, val_inline)?;
                opt.panels = if v == "auto" { Some(2) } else { Some(v.parse().map_err(|_| format!("error: invalid value '{v}' for '--panels <N>'"))?) };
            }
            "-g" | "--group-size" | "--groupsize" => {
                let v = need_val(&mut i, val_inline)?;
                opt.group = v.parse().map_err(|_| format!("error: invalid value '{v}' for '--group-size <N>'"))?;
                if ![1,2,4,8].contains(&opt.group) { return Err(format!("error: invalid value '{v}' for '--group-size <N>'")); }
            }
            "--endianness" => {
                let v = need_val(&mut i, val_inline)?;
                opt.endian = match v.as_str() { "big" => Endian::Big, "little" => Endian::Little, _ => return Err(format!("error: invalid value '{v}' for '--endianness <FORMAT>'")) };
            }
            "-e" => opt.endian = Endian::Little,
            "-b" | "--base" => {
                let v = need_val(&mut i, val_inline)?;
                opt.base = match v.as_str() { "hex"|"hexadecimal" => Base::Hex, "dec"|"decimal" => Base::Dec, "oct"|"octal" => Base::Oct, "bin"|"binary" => Base::Bin, _ => return Err(format!("error: invalid value '{v}' for '--base <B>'")) };
            }
            "--terminal-width" => {
                let v = need_val(&mut i, val_inline)?;
                opt.terminal_width = v.parse().ok();
            }
            "-i" | "--include" => opt.include = true,
            "--completion" => { let sh = need_val(&mut i, val_inline)?; print_completion(&sh); std::process::exit(0); }
            "--print-color-table" => {}
            _ if a.starts_with('-') => return Err(format!("error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.")),
            _ => {
                if opt.file.is_some() { return Err(format!("error: unexpected argument '{a}' found")); }
                opt.file = Some(a.clone());
            }
        }
        i += 1;
    }
    Ok(())
}

fn parse_num(s: &str, block: usize) -> Result<i64, String> {
    let neg = s.starts_with('-');
    let body = if neg { &s[1..] } else { s };
    let split = body.find(|c: char| !(c.is_ascii_hexdigit() || c == 'x' || c == 'X')).unwrap_or(body.len());
    let (num, unit) = body.split_at(split);
    let base_val = if num.starts_with("0x") || num.starts_with("0X") {
        i64::from_str_radix(&num[2..], 16).map_err(|_| format!("invalid number: {s}"))?
    } else {
        num.parse::<i64>().map_err(|_| format!("invalid number: {s}"))?
    };
    let mult = match unit.to_ascii_lowercase().as_str() {
        "" | "b" => 1,
        "kb" => 1_000, "mb" => 1_000_000, "gb" => 1_000_000_000,
        "kib" | "k" => 1024, "mib" | "m" => 1024*1024, "gib" | "g" => 1024*1024*1024,
        "block" | "blocks" => block as i64,
        _ => return Err(format!("invalid unit in '{s}'")),
    };
    let v = base_val.saturating_mul(mult);
    Ok(if neg { -v } else { v })
}

fn read_input_with_offset(opt: &Opt) -> io::Result<(Vec<u8>, usize)> {
    let mut data = Vec::new();
    let start_offset;
    if let Some(path) = &opt.file {
        let mut f = File::open(path)?;
        let len = f.metadata().ok().map(|m| m.len() as i64).unwrap_or(0);
        let start = if opt.skip < 0 { (len + opt.skip).max(0) as u64 } else { opt.skip as u64 };
        start_offset = start as usize;
        f.seek(SeekFrom::Start(start))?;
        if let Some(n) = opt.length { f.take(n as u64).read_to_end(&mut data)?; } else { f.read_to_end(&mut data)?; }
    } else {
        io::stdin().read_to_end(&mut data)?;
        if opt.skip > 0 {
            start_offset = opt.skip as usize;
            data = data.into_iter().skip(opt.skip as usize).collect();
        } else if opt.skip < 0 {
            let n = (-opt.skip) as usize;
            start_offset = data.len().saturating_sub(n);
            data = if n <= data.len() { data[data.len()-n..].to_vec() } else { data };
        } else {
            start_offset = 0;
        }
        if let Some(n) = opt.length { data.truncate(n); }
    }
    Ok((data, start_offset))
}

fn include_mode(opt: &Opt) -> io::Result<()> {
    let (data, _) = read_input_with_offset(opt)?;
    let name = opt.file.as_ref().and_then(|p| Path::new(p).file_name()).and_then(|s| s.to_str()).unwrap_or("stdin");
    let var = name.chars().map(|c| if c.is_ascii_alphanumeric() { c } else { '_' }).collect::<String>();
    println!("unsigned char {var}[] = {{");
    for (i, chunk) in data.chunks(12).enumerate() {
        print!("  ");
        for (j, b) in chunk.iter().enumerate() {
            let last = i*12 + j + 1 == data.len();
        print!("0x{b:02x}{}", if last { "" } else if j + 1 == chunk.len() { "," } else { ", " });
        }
        println!();
    }
    println!("}};");
    println!("unsigned int {var}_len = {};", data.len());
    Ok(())
}

fn run(opt: &Opt) -> io::Result<()> {
    let (data, base_offset) = read_input_with_offset(opt)?;
    let panels = effective_panels(opt);
    let row = panels * 8;
    let use_color = match opt.color { Color::Never => false, Color::Auto => false, Color::Always => env::var_os("NO_COLOR").is_none(), Color::Force => true };
    if opt.border != Border::None { print_border(opt, panels, true); }
    let mut prev_key: Option<Vec<u8>> = None;
    let mut squeezed = false;
    let mut ever_squeezed = false;
    let mut off = 0usize;
    while off < data.len() {
        let end = (off + row).min(data.len());
        let chunk = &data[off..end];
        let key = if chunk.len() == row { Some(chunk.to_vec()) } else { None };
        if !opt.no_squeeze && key.is_some() && prev_key.as_ref() == key.as_ref() {
            if !squeezed {
                print_squeeze(opt, panels);
                squeezed = true;
                ever_squeezed = true;
            }
        } else {
            squeezed = false;
            print_row(opt, panels, base_offset + off, chunk, use_color);
        }
        if key.is_some() { prev_key = key; }
        off += row;
    }
    if ever_squeezed || data.is_empty() { print_final_offset(opt, panels, base_offset + data.len()); }
    if opt.border != Border::None { print_border(opt, panels, false); }
    Ok(())
}

fn effective_panels(opt: &Opt) -> usize {
    if let Some(p) = opt.panels { return p.max(1); }
    if let Some(w) = opt.terminal_width { if w < 80 { return 1; } }
    match opt.base { Base::Hex => 2, _ => 1 }
}

fn cell_width(base: Base, group: usize) -> usize {
    match base { Base::Hex => 2*group, Base::Dec|Base::Oct => 3*group, Base::Bin => 8*group }
}

fn panel_width(opt: &Opt) -> usize {
    if opt.base == Base::Hex && opt.group == 1 { 25 } else { 8 / opt.group * (cell_width(opt.base,opt.group)+1) - 1 }
}

fn panel_inner_width(opt: &Opt) -> usize {
    panel_width(opt).saturating_sub(2)
}

fn fmt_byte(b: u8, base: Base) -> String {
    match base { Base::Hex => format!("{b:02x}"), Base::Dec => format!("{b:03}"), Base::Oct => format!("{b:03o}"), Base::Bin => format!("{b:08b}") }
}

fn format_panel(opt: &Opt, bytes: &[u8]) -> String {
    let mut cells = Vec::new();
    for group in bytes.chunks(opt.group) {
        let mut g = group.to_vec();
        if opt.endian == Endian::Little && opt.group > 1 { g.reverse(); }
        cells.push(g.iter().map(|&b| fmt_byte(b, opt.base)).collect::<String>());
    }
    let mut s = cells.join(" ");
    let width = panel_inner_width(opt);
    while visible_len(&s) < width { s.push(' '); }
    s
}

fn print_row(opt: &Opt, panels: usize, off: usize, chunk: &[u8], color: bool) {
    let sep = match opt.border { Border::Unicode => "│", Border::Ascii => "|", Border::None => "" };
    if opt.border != Border::None { print!("{sep}"); } else if opt.pos { print!(" "); } else { print!("  "); }
    if opt.pos {
        let shown = off as i64 + opt.display_offset;
        print!("{}", colorize(&format!("{:08x}", shown.max(0)), "offset", color));
        if opt.border != Border::None { print!("{sep}"); } else { print!("  "); }
    }
    for p in 0..panels {
        let start = p*8;
        let part = if start < chunk.len() { &chunk[start..chunk.len().min(start+8)] } else { &[] };
        let panel = format_panel(opt, part);
        if opt.border != Border::None {
            print!(" {panel} ");
        } else {
            print!("{panel}");
            if p + 1 == panels { print!(" "); } else { print!("  "); }
        }
        if opt.border != Border::None {
            if p + 1 < panels { print!("{}", if opt.border == Border::Unicode { "┊" } else { "|" }); } else { print!("{sep}"); }
        } else {
            print!(" ");
        }
    }
    if opt.chars {
        for p in 0..panels {
            let start = p*8;
            let part = if start < chunk.len() { &chunk[start..chunk.len().min(start+8)] } else { &[] };
            let mut cs = String::new();
            for &b in part { cs.push_str(&char_for(b, opt.ctable)); }
            while visible_len(&cs) < 8 { cs.push(' '); }
            print!("{}", if opt.border == Border::None && p == 0 { "" } else { "" });
            print!("{}", color_chars(&cs, part, color));
            if opt.border != Border::None {
                if p + 1 < panels { print!("{}", if opt.border == Border::Unicode { "┊" } else { "|" }); } else { print!("{sep}"); }
            } else {
                print!(" ");
            }
        }
    }
    println!();
}

fn print_final_offset(opt: &Opt, panels: usize, len: usize) {
    let sep = match opt.border { Border::Unicode => "│", Border::Ascii => "|", Border::None => "" };
    if opt.border != Border::None { print!("{sep}"); } else { print!(" "); }
    if opt.pos {
        print!("{:08x}", (len as i64 + opt.display_offset).max(0));
        if opt.border != Border::None { print!("{sep}"); } else { print!("  "); }
    }
    for p in 0..panels {
        if opt.border != Border::None { print!(" {} ", " ".repeat(panel_inner_width(opt))); }
        else { print!("{}  ", " ".repeat(panel_inner_width(opt))); }
        if opt.border != Border::None {
            if p+1 < panels { print!("{}", if opt.border == Border::Unicode { "┊" } else { "|" }); } else { print!("{sep}"); }
        } else { print!(" "); }
    }
    if opt.chars {
        for p in 0..panels {
            print!("{}", " ".repeat(8));
            if opt.border != Border::None {
                if p+1 < panels { print!("{}", if opt.border == Border::Unicode { "┊" } else { "|" }); } else { print!("{sep}"); }
            } else { print!(" "); }
        }
    }
    println!();
}

fn print_squeeze(opt: &Opt, panels: usize) {
    let sep = match opt.border { Border::Unicode => "│", Border::Ascii => "|", Border::None => "" };
    if opt.border != Border::None { print!("{sep}*       {sep}"); } else { print!(" *       "); }
    for p in 0..panels {
        if opt.border != Border::None { print!(" {} ", " ".repeat(panel_inner_width(opt))); }
        else { print!("{}  ", " ".repeat(panel_inner_width(opt))); }
        if opt.border != Border::None {
            if p+1 < panels { print!("{}", if opt.border == Border::Unicode { "┊" } else { "|" }); } else { print!("{sep}"); }
        } else { print!(" "); }
    }
    if opt.chars {
        for p in 0..panels {
            print!("{}", " ".repeat(8));
            if opt.border != Border::None {
                if p+1 < panels { print!("{}", if opt.border == Border::Unicode { "┊" } else { "|" }); } else { print!("{sep}"); }
            } else { print!(" "); }
        }
    }
    println!();
}

fn print_border(opt: &Opt, panels: usize, top: bool) {
    let (l, j, m, r, h) = match (opt.border, top) {
        (Border::Unicode, true) => ("┌","┬","┬","┐","─"),
        (Border::Unicode, false) => ("└","┴","┴","┘","─"),
        (Border::Ascii, _) => ("+","+","+","+","-"),
        _ => return,
    };
    let mut line = String::new();
    line.push_str(l);
    if opt.pos { line.push_str(&h.repeat(8)); line.push_str(j); }
    for _ in 0..panels { line.push_str(&h.repeat(panel_width(opt))); line.push_str(m); }
    if opt.chars { for _ in 0..panels { line.push_str(&h.repeat(8)); line.push_str(m); } }
    line.pop(); line.push_str(r);
    println!("{line}");
}

fn char_for(b: u8, table: CharTable) -> String {
    match table {
        CharTable::Ascii => if b == b' ' { " ".into() } else if (0x21..=0x7e).contains(&b) { (b as char).to_string() } else { ".".into() },
        CharTable::Braille => if b < 0x80 { char_for(b, CharTable::Default) } else { "⣿".into() },
        CharTable::Cp437 => if b < 0x80 { char_for(b, CharTable::Ascii) } else { ".".into() },
        CharTable::Cp1047 => if (0x40..=0xfe).contains(&b) { ".".into() } else { ".".into() },
        CharTable::Default => {
            if b == 0 { "⋄".into() }
            else if b == b' ' { " ".into() }
            else if b.is_ascii_graphic() { (b as char).to_string() }
            else if b.is_ascii_whitespace() { "_".into() }
            else if b < 0x80 { "•".into() }
            else { "×".into() }
        }
    }
}

fn colorize(s: &str, kind: &str, color: bool) -> String {
    if !color { return s.to_string(); }
    let code = match kind { "offset" => "38;5;242", _ => "36" };
    format!("\x1b[{code}m{s}\x1b[0m")
}

fn color_chars(s: &str, bytes: &[u8], color: bool) -> String {
    if !color { return s.to_string(); }
    let mut out = String::new();
    let mut chars = s.chars();
    for &b in bytes {
        let c = chars.next().unwrap_or(' ');
        let code = if b == 0 { "38;5;242" } else if b < 0x80 && !(b as char).is_ascii_graphic() { "32" } else if b < 0x80 { "36" } else { "33" };
        out.push_str(&format!("\x1b[{code}m{c}\x1b[0m"));
    }
    for c in chars { out.push(c); }
    out
}

fn visible_len(s: &str) -> usize { s.chars().count() }

fn print_short_help() {
    println!("A command-line hex viewer\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]  The file to display. If no FILE argument is given, read from STDIN\n\nOptions:\n  -n, --length <N>                Only read N bytes from the input\n  -s, --skip <N>                  Skip the first N bytes of the input\n      --color <WHEN>              When to use colors [default: always]\n      --border <STYLE>            Whether to draw a border [default: unicode]\n  -p, --plain                     Display output with --no-characters, --no-position, --border=none, and --color=never\n  -h, --help                      Print help (see more with '--help')\n  -V, --version                   Print version");
}

fn print_long_help() { print_short_help(); }

fn print_completion(sh: &str) { println!("# completion for {sh}"); }

fn print_color_table(color: bool) {
    let samples = [("NUL", 0u8), ("ASCII printable", b'A'), ("ASCII whitespace", b'\n'), ("ASCII other", 1), ("Non-ASCII", 255)];
    for (name, b) in samples { println!("{:18} {}", name, color_chars(&char_for(b, CharTable::Default), &[b], color)); }
}
