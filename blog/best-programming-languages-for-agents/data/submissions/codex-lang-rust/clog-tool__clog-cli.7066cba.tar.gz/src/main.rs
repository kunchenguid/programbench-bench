use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::Instant;

#[derive(Clone, Debug)]
struct Args {
    repository: Option<String>,
    from: Option<String>,
    to: String,
    format: String,
    major: bool,
    minor: bool,
    patch: bool,
    git_dir: Option<String>,
    work_tree: Option<String>,
    subtitle: Option<String>,
    outfile: Option<String>,
    config: String,
    infile: Option<String>,
    setversion: Option<String>,
    from_latest_tag: bool,
    link_style: String,
    changelog: Option<String>,
}

#[derive(Clone, Debug, Default)]
struct Config {
    repository: Option<String>,
    from_latest_tag: bool,
    changelog: Option<String>,
    sections: Vec<(String, Vec<String>)>,
}

#[derive(Clone, Debug)]
struct Commit {
    hash: String,
    typ: String,
    component: Option<String>,
    subject: String,
    body: String,
}

#[derive(Clone, Debug)]
struct Entry {
    component: Option<String>,
    subject_json: String,
    subject_md: String,
    link: String,
    closes: Option<Vec<String>>,
    breaks: Option<Vec<String>>,
}

fn main() {
    let start = Instant::now();
    let args = match parse_args() {
        Ok(a) => a,
        Err(code) => std::process::exit(code),
    };
    if let Err(e) = run(args, start) {
        eprintln!("\x1b[1;31merror:\x1b[0m {}", e);
        std::process::exit(1);
    }
}

fn run(mut args: Args, start: Instant) -> Result<(), String> {
    let cfg_path = resolve_config_path(&args);
    let cfg = parse_config(&cfg_path).unwrap_or_default();
    if args.repository.is_none() { args.repository = cfg.repository.clone(); }
    if !args.from_latest_tag { args.from_latest_tag = cfg.from_latest_tag; }
    if args.changelog.is_none() { args.changelog = cfg.changelog.clone(); }
    if args.changelog.is_some() {
        if args.infile.is_none() { args.infile = args.changelog.clone(); }
        if args.outfile.is_none() { args.outfile = args.changelog.clone(); }
    }

    let version = determine_version(&args)?;
    let patch_version = version.as_ref().map(|v| is_patch_version(v)).unwrap_or(false);
    let date = current_date();
    let repo = args.repository.clone().unwrap_or_default().trim_end_matches(".git").trim_end_matches('/').to_string();
    let from = if args.from_latest_tag && args.from.is_none() { latest_tag(&args).ok() } else { args.from.clone() };
    let commits = read_commits(&args, from.as_deref(), &args.to).unwrap_or_default();
    let sections = build_sections(&cfg.sections, commits, &repo, &args.link_style);

    let generated = if args.format == "json" {
        render_json(version.as_deref(), patch_version, args.subtitle.as_deref(), &date, &sections)
    } else {
        render_markdown(version.as_deref(), args.subtitle.as_deref(), &date, &sections)
    };
    let final_text = if let Some(infile) = &args.infile {
        let old = fs::read_to_string(infile).unwrap_or_default();
        if old.is_empty() { generated.clone() } else { format!("{}\n{}", generated, old) }
    } else { generated.clone() };

    if let Some(outfile) = &args.outfile {
        fs::write(outfile, final_text).map_err(|_| "fatal I/O error with output file".to_string())?;
    } else {
        print!("{}", final_text);
        io::stdout().flush().ok();
    }
    println!("changelog written. (took {} ms)", start.elapsed().as_millis());
    Ok(())
}

fn parse_args() -> Result<Args, i32> {
    let mut a = Args { repository: None, from: None, to: "HEAD".into(), format: "markdown".into(), major: false, minor: false, patch: false, git_dir: None, work_tree: None, subtitle: None, outfile: None, config: ".clog.toml".into(), infile: None, setversion: None, from_latest_tag: false, link_style: "github".into(), changelog: None };
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => { print_help(); return Err(0); }
            "-V" | "--version" => { println!("clog 0.10.0"); return Err(0); }
            "-M" | "--major" => a.major = true,
            "-m" | "--minor" => a.minor = true,
            "-p" | "--patch" => a.patch = true,
            "-F" | "--from-latest-tag" => a.from_latest_tag = true,
            "-r" | "--repository" => a.repository = Some(take_val(&mut it, &arg)?),
            "-f" | "--from" => a.from = Some(take_val(&mut it, &arg)?),
            "-t" | "--to" => a.to = take_val(&mut it, &arg)?,
            "-T" | "--format" => { a.format = take_val(&mut it, &arg)?; if a.format != "markdown" && a.format != "json" { eprintln!("error: invalid value '{}' for '--format <STR>'\n  [possible values: markdown, json]\n\nFor more information, try '--help'.", a.format); return Err(2); } }
            "-g" | "--git-dir" => a.git_dir = Some(take_val(&mut it, &arg)?),
            "-w" | "--work-tree" => a.work_tree = Some(take_val(&mut it, &arg)?),
            "-s" | "--subtitle" => a.subtitle = Some(take_val(&mut it, &arg)?),
            "-o" | "--outfile" => a.outfile = Some(take_val(&mut it, &arg)?),
            "-c" | "--config" => a.config = take_val(&mut it, &arg)?,
            "-i" | "--infile" => a.infile = Some(take_val(&mut it, &arg)?),
            "--setversion" => a.setversion = Some(take_val(&mut it, &arg)?),
            "-l" | "--link-style" => { a.link_style = take_val(&mut it, &arg)?; if !["github","gitlab","stash","cgit"].contains(&a.link_style.as_str()) { eprintln!("error: invalid value '{}' for '--link-style <STR>'\n  [possible values: github, gitlab, stash, cgit]\n\nFor more information, try '--help'.", a.link_style); return Err(2); } }
            "-C" | "--changelog" => a.changelog = Some(take_val(&mut it, &arg)?),
            _ => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", arg); return Err(2); }
        }
    }
    Ok(a)
}

fn take_val<I: Iterator<Item=String>>(it: &mut std::iter::Peekable<I>, opt: &str) -> Result<String, i32> {
    match it.next() { Some(v) if !v.starts_with('-') => Ok(v), _ => { eprintln!("error: a value is required for '{}' but none was supplied", opt); Err(2) } }
}

fn print_help() {
    println!("a conventional changelog for the rest of us\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -r, --repository <URL>  Repository used for generating commit and issue links (without the .git,\n                          e.g. https://github.com/thoughtram/clog)\n  -f, --from <COMMIT>     e.g. 12a8546\n  -T, --format <STR>      The output format, defaults to markdown [default: markdown] [possible\n                          values: markdown, json]\n  -M, --major             Increment major version by one (Sets minor and patch to 0)\n  -g, --git-dir <PATH>    Local .git directory (defaults to \"$(pwd)/.git\")\n  -w, --work-tree <PATH>  Local working tree of the git project (defaults to \"$(pwd)\")\n  -m, --minor             Increment minor version by one (Sets patch to 0)\n  -p, --patch             Increment patch version by one\n  -s, --subtitle <STR>    \n  -t, --to <COMMIT>       e.g. 8057684 [default: HEAD]\n  -o, --outfile <PATH>    Where to write the changelog (Defaults to stdout when omitted)\n  -c, --config <COMMIT>   The Clog Configuration TOML file to use [default: .clog.toml]\n  -i, --infile <PATH>     A changelog to append to, but *NOT* write to (Useful in conjunction with\n                          --outfile)\n      --setversion <VER>  e.g. 1.0.1\n  -F, --from-latest-tag   use latest tag as start (instead of --from)\n  -l, --link-style <STR>  The style of repository link to generate [default: github] [possible\n                          values: github, gitlab, stash, cgit]\n  -C, --changelog <PATH>  A previous changelog to prepend new changes to (this is like using the\n                          same file for both --infile and --outfile and should not be used in\n                          conjunction with either)\n  -h, --help              Print help\n  -V, --version           Print version\n\n\nIf your .git directory is a child of your project directory (most common, such as /myproject/.git)\nAND not in the current working directory (i.e you need to use --work-tree or --git-dir) you only\nneed to specify either the --work-tree (i.e. /myproject) OR --git-dir (i.e. /myproject/.git), you\ndon't need to use both.\n\nIf using the --config to specify a clog configuration TOML file NOT in the current working directory\n(meaning you need to use --work-tree or --git-dir) AND the TOML file is inside your project\ndirectory (i.e. /myproject/.clog.toml) you do not need to use --work-tree or --git-dir.");
}

fn resolve_config_path(args: &Args) -> PathBuf {
    let p = PathBuf::from(&args.config);
    if p.is_absolute() || p.exists() { return p; }
    if let Some(w) = &args.work_tree { return Path::new(w).join(&args.config); }
    if let Some(g) = &args.git_dir { if let Some(parent) = Path::new(g).parent() { return parent.join(&args.config); } }
    p
}

fn parse_config(path: &Path) -> Result<Config, String> {
    let s = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let mut cfg = Config::default();
    let mut section = String::new();
    for raw in s.lines() {
        let line = raw.split('#').next().unwrap_or("").trim();
        if line.is_empty() { continue; }
        if line.starts_with('[') && line.ends_with(']') { section = line.trim_matches(&['[',']'][..]).to_string(); continue; }
        let Some((k,v)) = line.split_once('=') else { continue; };
        let key = unquote(k.trim()); let val = v.trim();
        if section == "clog" {
            match key.as_str() {
                "repository" => cfg.repository = Some(unquote(val)),
                "from-latest-tag" => cfg.from_latest_tag = val == "true",
                "changelog" => cfg.changelog = Some(unquote(val)),
                _ => {}
            }
        } else if section == "sections" {
            cfg.sections.push((key, parse_array(val)));
        }
    }
    Ok(cfg)
}

fn unquote(s: &str) -> String { s.trim().trim_matches('"').trim_matches('\'').to_string() }
fn parse_array(s: &str) -> Vec<String> { s.trim().trim_start_matches('[').trim_end_matches(']').split(',').map(unquote).filter(|x| !x.is_empty()).collect() }

fn determine_version(args: &Args) -> Result<Option<String>, String> {
    if let Some(v) = &args.setversion { return Ok(Some(v.clone())); }
    if args.major || args.minor || args.patch {
        let base = latest_version_from_changelog(args).ok_or_else(|| "Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.".to_string())?;
        let (mut maj, mut min, mut pat, prefix) = parse_semver(&base).ok_or_else(|| "Failed to parse version into valid SemVer. Ensure the version is in the X.Y.Z format.".to_string())?;
        if args.major { maj += 1; min = 0; pat = 0; } else if args.minor { min += 1; pat = 0; } else { pat += 1; }
        return Ok(Some(format!("{}{}.{}.{}", prefix, maj, min, pat)));
    }
    Ok(None)
}

fn latest_version_from_changelog(args: &Args) -> Option<String> {
    let path = args.changelog.as_ref().or(args.infile.as_ref()).map(String::as_str).unwrap_or("changelog.md");
    let s = fs::read_to_string(path).ok()?;
    for line in s.lines() {
        if let Some(rest) = line.strip_prefix("<a name=\"") { return rest.split('"').next().map(|x| x.to_string()); }
        let t = line.trim_start_matches('#').trim();
        if t.chars().next().map(|c| c == 'v' || c.is_ascii_digit()).unwrap_or(false) { return t.split_whitespace().next().map(|x| x.to_string()); }
    }
    None
}
fn parse_semver(v: &str) -> Option<(u64,u64,u64,&str)> { let (p, rest) = if let Some(r)=v.strip_prefix('v') {("v", r)} else {("", v)}; let parts: Vec<_> = rest.split('.').collect(); if parts.len()!=3 {return None;} Some((parts[0].parse().ok()?, parts[1].parse().ok()?, parts[2].parse().ok()?, p)) }
fn is_patch_version(v: &str) -> bool { parse_semver(v).map(|(_,_,p,_)| p > 0).unwrap_or(false) }

fn git_base(args: &Args) -> Command {
    let mut c = Command::new("git");
    if let Some(g) = &args.git_dir { c.arg(format!("--git-dir={}", g)); }
    if let Some(w) = &args.work_tree { c.arg(format!("--work-tree={}", w)); }
    c
}
fn latest_tag(args: &Args) -> Result<String, String> { let out = git_base(args).args(["describe","--tags","--abbrev=0"]).output().map_err(|e| e.to_string())?; if out.status.success() { Ok(String::from_utf8_lossy(&out.stdout).trim().to_string()) } else { Err("no tag".into()) } }

fn read_commits(args: &Args, from: Option<&str>, to: &str) -> Result<Vec<Commit>, String> {
    let range = if let Some(f) = from { format!("{}..{}", f, to) } else { to.to_string() };
    let fmt = "%H%x1f%s%x1f%b%x1e";
    let out = git_base(args).args(["log", "--reverse"]).arg(format!("--format=format:{}", fmt)).arg(range).output().map_err(|e| e.to_string())?;
    if !out.status.success() { return Ok(Vec::new()); }
    let text = String::from_utf8_lossy(&out.stdout);
    let mut cs = Vec::new();
    for rec in text.split('\x1e') {
        let rec = rec.trim_matches('\n'); if rec.is_empty() { continue; }
        let mut parts = rec.splitn(3, '\x1f');
        let hash = parts.next().unwrap_or("").to_string(); let subj = parts.next().unwrap_or(""); let body = parts.next().unwrap_or("").to_string();
        if let Some((typ, comp, subject)) = parse_subject(subj) { cs.push(Commit{hash, typ, component: comp, subject, body}); }
    }
    cs.reverse();
    Ok(cs)
}

fn parse_subject(s: &str) -> Option<(String, Option<String>, String)> {
    let (left, right) = s.split_once(':')?;
    let subject = right.to_string();
    if let Some(p) = left.find('(') { let typ = left[..p].trim().to_string(); let comp = left[p+1..].trim_end_matches(')').to_string(); Some((typ, if comp.is_empty(){None}else{Some(comp)}, subject)) } else { Some((left.trim().to_string(), None, subject)) }
}

fn build_sections(defs: &[(String, Vec<String>)], commits: Vec<Commit>, repo: &str, style: &str) -> Vec<(String, Vec<Entry>)> {
    let mut map: BTreeMap<String, Vec<Entry>> = BTreeMap::new();
    let mut order = Vec::new();
    for (title, _) in defs { order.push(title.clone()); map.insert(title.clone(), Vec::new()); }
    for c in commits {
        for (title, aliases) in defs {
            if aliases.iter().any(|a| a == &c.typ) {
                let link = commit_link(repo, style, &c.hash);
                map.get_mut(title).unwrap().push(Entry{ component: c.component.clone(), subject_json: c.subject.clone(), subject_md: c.subject.trim_start().to_string(), link, closes: find_refs(&c.body, &["close", "closes", "closed", "fix", "fixes", "fixed"]), breaks: find_breaks(&c.body), });
                break;
            }
        }
    }
    order.into_iter().filter_map(|t| { let v = map.remove(&t).unwrap_or_default(); if v.is_empty(){None}else{Some((t,v))} }).collect()
}

fn commit_link(repo: &str, style: &str, hash: &str) -> String { if repo.is_empty() { hash.to_string() } else if style == "cgit" { format!("{}/commit/?id={}", repo, hash) } else if style == "stash" { format!("{}/commits/{}", repo, hash) } else { format!("{}/commit/{}", repo, hash) } }
fn issue_link(repo: &str, n: &str) -> String { if repo.is_empty(){ format!("#{}", n) } else { format!("{}/issues/{}", repo, n) } }

fn find_refs(body: &str, words: &[&str]) -> Option<Vec<String>> {
    let lower = body.to_lowercase();
    if !words.iter().any(|w| lower.contains(w)) { return None; }
    let mut refs = Vec::new(); let bytes = body.as_bytes(); let mut i=0;
    while i < bytes.len() { if bytes[i] == b'#' { let mut j=i+1; while j<bytes.len() && bytes[j].is_ascii_digit(){j+=1;} if j>i+1 { refs.push(body[i+1..j].to_string()); } i=j; } else { i+=1; } }
    if refs.is_empty() { None } else { Some(refs) }
}
fn find_breaks(body: &str) -> Option<Vec<String>> { if body.to_lowercase().contains("breaking change") || body.to_lowercase().contains("breaks") { Some(find_refs(body, &["break"]).unwrap_or_default()) } else { None } }

fn render_markdown(ver: Option<&str>, subtitle: Option<&str>, date: &str, sections: &[(String, Vec<Entry>)]) -> String {
    let v = ver.unwrap_or(""); let sub = subtitle.unwrap_or("");
    let hashes = if ver.map(is_patch_version).unwrap_or(false) { "###" } else { "##" };
    let mut out = format!("<a name=\"{}\"></a>\n{} {} {} ({})\n", v, hashes, v, sub, date);
    for (title, entries) in sections {
        out.push_str(&format!("\n\n#### {}\n\n", title));
        for e in entries {
            let hash = hash_from_link(&e.link); let short = if hash.len()>8 { &hash[..8] } else { hash };
            if let Some(c) = &e.component { out.push_str(&format!("* **{}:**  {} ([{}]({})", c, e.subject_md, short, e.link)); } else { out.push_str(&format!("*   {} ([{}]({})", e.subject_md, short, e.link)); }
            if let Some(closes) = &e.closes { for n in closes { let repo = repo_from_link(&e.link); out.push_str(&format!(", closes [#{}]({})", n, issue_link(&repo, n))); } }
            if let Some(breaks) = &e.breaks { if breaks.is_empty() { let repo = repo_from_link(&e.link); out.push_str(&format!(", breaks [#]({}/issues/)", repo)); } else { for n in breaks { let repo = repo_from_link(&e.link); out.push_str(&format!(", breaks [#{}]({})", n, issue_link(&repo, n))); } } }
            out.push_str(")\n");
        }
    }
    out
}


fn hash_from_link(link: &str) -> &str {
    if let Some((_, h)) = link.rsplit_once("?id=") { h }
    else if let Some((_, h)) = link.rsplit_once("/commit/") { h }
    else if let Some((_, h)) = link.rsplit_once("/commits/") { h }
    else { link.rsplit('/').next().unwrap_or(link) }
}
fn repo_from_link(link: &str) -> String {
    if let Some((r, _)) = link.rsplit_once("/commit/?id=") { r.to_string() }
    else if let Some((r, _)) = link.rsplit_once("/commit/") { r.to_string() }
    else if let Some((r, _)) = link.rsplit_once("/commits/") { r.to_string() }
    else { String::new() }
}

fn render_json(ver: Option<&str>, patch_version: bool, subtitle: Option<&str>, date: &str, sections: &[(String, Vec<Entry>)]) -> String {
    let v = ver.map(|x| format!("\"{}\"", esc(x))).unwrap_or_else(|| "None".into());
    let st = subtitle.map(|x| format!("\"{}\"", esc(x))).unwrap_or_else(|| "null".into());
    let mut out = format!("{{\"header\":{{\"version\":{},\"patch_version\":{},\"subtitle\":{},\"date\":\"{}\"}},\"sections\":", v, patch_version, st, date);
    if sections.is_empty() { out.push_str("null}"); return out; }
    out.push('[');
    for (si,(title, entries)) in sections.iter().enumerate() { if si>0 {out.push(',');} out.push_str(&format!("{{\"title\":\"{}\",\"commits\":[", esc(title))); for (i,e) in entries.iter().enumerate(){ if i>0{out.push(',');} out.push_str(&format!("{{\"component\":{},\"subject\":\"{}\",\"commit_link\":\"{}\",\"closes\":{},\"breaks\":{}}}", e.component.as_ref().map(|c|format!("\"{}\"",esc(c))).unwrap_or_else(||"null".into()), esc(&e.subject_json), esc(&e.link), refs_json(&e.closes), refs_json(&e.breaks))); } out.push_str("]}"); }
    out.push_str("]}"); out
}
fn refs_json(r: &Option<Vec<String>>) -> String { match r { None => "null".into(), Some(v) if v.is_empty() => "[]".into(), Some(v) => format!("[{}]", v.iter().map(|x| format!("\"{}\"", esc(x))).collect::<Vec<_>>().join(",")) } }
fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n") }
fn current_date() -> String { let out = Command::new("date").arg("+%F").output().ok(); out.map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string()).filter(|s| !s.is_empty()).unwrap_or_else(|| "2026-05-28".into()) }
