use chrono::Local;
use clap::{Arg, ArgAction, ArgMatches, Command};
use std::fs::{self, File};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::process;

const LONG_ABOUT: &str = "GitType turns your own source code into typing challenges. Practice typing by using functions, classes, and methods from your actual projects. \n\nExamples:\n  gittype                           # Use current directory\n  gittype /path/to/repo             # Use specific repository\n  gittype --repo owner/repo         # Clone and use GitHub repository\n  gittype --langs rust,python       # Filter by languages";

const SHORT_ABOUT: &str = "A typing practice tool using your own code repositories - extracts all code chunks (functions, classes, methods, etc.)";

fn main() {
    let matches = cli().get_matches();

    match matches.subcommand() {
        Some(("history", _)) => planned("History command is not yet implemented", &[]),
        Some(("stats", _)) => planned("Stats command is not yet implemented", &[]),
        Some(("export", m)) => export_cmd(m),
        Some(("cache", m)) => cache_cmd(m),
        Some(("repo", m)) => repo_cmd(m),
        Some(("trending", m)) => trending_cmd(m),
        _ => start_session(&matches),
    }
}

fn cli() -> Command {
    Command::new("gittype")
        .bin_name("executable")
        .version("0.8.0")
        .about(SHORT_ABOUT)
        .long_about(LONG_ABOUT)
        .arg(
            Arg::new("repo")
                .long("repo")
                .value_name("REPO")
                .help("GitHub repository URL or path to clone and play with")
                .long_help("GitHub repository URL or path to clone and play with. Supports formats:\n  - owner/repo\n  - https://github.com/owner/repo\n  - git@github.com:owner/repo.git"),
        )
        .arg(
            Arg::new("langs")
                .long("langs")
                .value_name("LANGS")
                .help("Filter by programming languages (comma-separated)")
                .long_help("Filter by programming languages (comma-separated). Supported languages:\n  rust, typescript, javascript, python, ruby, go, swift, kotlin, java, php, csharp, c, cpp, haskell, dart, scala, zig\n  Example: --langs rust,python,typescript"),
        )
        .arg(
            Arg::new("repo_path")
                .value_name("REPO_PATH")
                .help("Repository path to extract code from"),
        )
        .subcommand(Command::new("history").about("Show session history"))
        .subcommand(Command::new("stats").about("Show analytics"))
        .subcommand(
            Command::new("export")
                .about("Export session data")
                .arg(
                    Arg::new("format")
                        .long("format")
                        .value_name("FORMAT")
                        .default_value("json")
                        .help("Export format"),
                )
                .arg(
                    Arg::new("output")
                        .long("output")
                        .value_name("OUTPUT")
                        .help("Output file path"),
                ),
        )
        .subcommand(
            Command::new("cache")
                .about("Manage challenge cache")
                .subcommand_required(true)
                .subcommand(Command::new("stats").about("Show cache statistics"))
                .subcommand(Command::new("clear").about("Clear all cached challenges"))
                .subcommand(Command::new("list").about("List cached repository keys")),
        )
        .subcommand(
            Command::new("repo")
                .about("Manage repositories")
                .subcommand_required(true)
                .subcommand(Command::new("list").about("List all cached repositories"))
                .subcommand(
                    Command::new("clear")
                        .about("Clear all cached repositories")
                        .arg(Arg::new("force").long("force").help("Force clear without confirmation").action(ArgAction::SetTrue)),
                )
                .subcommand(Command::new("play").about("Play a cached repository interactively")),
        )
        .subcommand(
            Command::new("trending")
                .about("Select and practice with trending repositories from GitHub")
                .arg(
                    Arg::new("period")
                        .long("period")
                        .value_name("PERIOD")
                        .default_value("daily")
                        .help("Time period for trending (daily, weekly, monthly)"),
                )
                .arg(
                    Arg::new("language")
                        .value_name("LANGUAGE")
                        .help("Programming language to filter trending repositories.\nSupported languages: C, C#, C++, Dart, Go, Haskell, Java, JavaScript, Kotlin, PHP, Python, Ruby, Rust, Scala, Swift, TypeScript, Zig"),
                )
                .arg(Arg::new("repo_name").value_name("REPO_NAME").help("Specific repository name to select from trending list")),
        )
}

fn export_cmd(m: &ArgMatches) -> ! {
    let fmt = m.get_one::<String>("format").map(String::as_str).unwrap_or("json");
    let mut hints = vec![format!("Requested format: {}", fmt)];
    if let Some(out) = m.get_one::<String>("output") {
        hints.push(format!("Requested output: {}", out));
    }
    let refs: Vec<&str> = hints.iter().map(String::as_str).collect();
    planned("Export command is not yet implemented", &refs)
}

fn planned(message: &str, hints: &[&str]) -> ! {
    println!("❌ {}", message);
    for hint in hints {
        println!("💡 {}", hint);
    }
    println!("💡 This feature is planned for a future release");
    process::exit(1);
}

fn cache_cmd(m: &ArgMatches) -> ! {
    match m.subcommand() {
        Some(("stats", _)) => {
            let (count, size) = cache_stats();
            println!("Challenge Cache Statistics:");
            println!("  Cached repositories: {}", count);
            println!("  Total size: {} bytes", size);
            process::exit(0);
        }
        Some(("clear", _)) => {
            let _ = fs::remove_dir_all(cache_dir());
            println!("Challenge cache cleared successfully.");
            process::exit(0);
        }
        Some(("list", _)) => {
            let dir = cache_dir();
            let mut entries = list_names(&dir);
            if entries.is_empty() {
                println!("No cached challenges found.");
            } else {
                entries.sort();
                for entry in entries { println!("{}", entry); }
            }
            process::exit(0);
        }
        _ => process::exit(2),
    }
}

fn repo_cmd(m: &ArgMatches) -> ! {
    match m.subcommand() {
        Some(("clear", _)) => {
            let dir = repo_cache_dir();
            if dir.exists() {
                let _ = fs::remove_dir_all(&dir);
                println!("Cached repositories cleared successfully.");
            } else {
                println!("No cached repositories directory found.");
            }
            process::exit(0);
        }
        Some(("list", _)) | Some(("play", _)) => terminal_error(),
        _ => process::exit(2),
    }
}

fn trending_cmd(m: &ArgMatches) -> ! {
    if let Some(repo) = m.get_one::<String>("repo_name") {
        if !valid_owner_repo(repo) {
            println!("⚠️ Repository name must be in format 'owner/repo'");
            process::exit(0);
        }
    }
    terminal_error()
}

fn start_session(m: &ArgMatches) -> ! {
    if let Some(langs) = m.get_one::<String>("langs") {
        let bad: Vec<&str> = langs.split(',').map(str::trim).filter(|s| !s.is_empty() && !valid_lang(s)).collect();
        if !bad.is_empty() {
            println!("❌ Unsupported language(s): {}", bad.join(", "));
            println!("💡 Supported languages:");
            println!("   rust, rs, typescript, ts, javascript, js");
            println!("   python, py, ruby, rb, go, swift");
            println!("   kotlin, kt, java, php, csharp, cs");
            println!("   c#, c, cpp, c++, haskell, hs");
            println!("   dart, scala, sc, zig, clojure, clj");
            println!("   cljs");
            process::exit(1);
        }
    }
    terminal_error()
}

fn valid_lang(lang: &str) -> bool {
    matches!(lang.to_ascii_lowercase().as_str(),
        "rust"|"rs"|"typescript"|"ts"|"javascript"|"js"|"python"|"py"|"ruby"|"rb"|"go"|"swift"|
        "kotlin"|"kt"|"java"|"php"|"csharp"|"cs"|"c#"|"c"|"cpp"|"c++"|"haskell"|"hs"|"dart"|
        "scala"|"sc"|"zig"|"clojure"|"clj"|"cljs")
}

fn valid_owner_repo(s: &str) -> bool {
    let mut parts = s.split('/');
    matches!((parts.next(), parts.next(), parts.next()), (Some(a), Some(b), None) if !a.is_empty() && !b.is_empty())
}

fn terminal_error() -> ! {
    let name = format!("gittype_error_{}.log", Local::now().format("%Y%m%d_%H%M%S"));
    if let Ok(mut f) = File::create(&name) {
        let _ = writeln!(f, "Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)");
    }
    println!("💾 Error details written to: {}", name);
    println!("Error: Terminal error: Failed to create terminal: Resource temporarily unavailable (os error 11)");
    process::exit(1);
}

fn home() -> PathBuf {
    std::env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| PathBuf::from("."))
}

fn cache_dir() -> PathBuf { home().join(".cache").join("gittype").join("challenges") }
fn repo_cache_dir() -> PathBuf { home().join(".cache").join("gittype").join("repos") }

fn list_names(dir: &Path) -> Vec<String> {
    fs::read_dir(dir).map(|rd| rd.filter_map(|e| e.ok()).filter_map(|e| e.file_name().into_string().ok()).collect()).unwrap_or_default()
}

fn cache_stats() -> (usize, u64) {
    let dir = cache_dir();
    let entries = list_names(&dir).len();
    (entries, dir_size(&dir))
}

fn dir_size(path: &Path) -> u64 {
    let Ok(meta) = fs::metadata(path) else { return 0; };
    if meta.is_file() { return meta.len(); }
    fs::read_dir(path).map(|rd| rd.filter_map(|e| e.ok()).map(|e| dir_size(&e.path())).sum()).unwrap_or(0)
}
