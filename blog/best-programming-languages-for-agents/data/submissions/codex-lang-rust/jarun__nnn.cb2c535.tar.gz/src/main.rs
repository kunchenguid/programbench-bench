use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process;

const HELP: &str = "usage: nnn [OPTIONS] [PATH]\n\nThe unorthodox terminal file manager.\n\npositional args:\n  PATH   start dir/file [default: .]\n\noptional args:\n -a      auto NNN_FIFO\n -A      no dir auto-enter during filter\n -b key  open bookmark key (trumps -s/S)\n -B      use bsdtar for archives\n -c      cli-only NNN_OPENER (trumps -e)\n -C      8-color scheme\n -d      detail mode\n -D      dirs in context color\n -e      text in $VISUAL/$EDITOR/vi\n -E      internal edits in EDITOR\n -f      use history file\n -F val  fifo mode [0:preview 1:explore]\n -g      regex filters\n -H      show hidden files\n -i      show current file info\n -J      no auto-advance on selection\n -K      detect key collision and exit\n -l val  set scroll lines\n -n      type-to-nav mode\n -N      use native prompt\n -o      open files only on Enter\n -p file selection file [-:stdout]\n -P key  run plugin key\n -Q      no quit confirmation\n -r      use advcpmv patched cp, mv\n -R      no rollover at edges\n -s name load session by name\n -S      persistent session\n -t secs timeout to lock\n -T key  sort order [a/d/e/r/s/t/v]\n -u      use selection (no prompt)\n -U      show user and group\n -V      show version\n -x      notis, selection sync, xterm title\n -z      in order fuzzy filters\n -0      null separator in picker mode\n -h      show help\n\nv5.2\nBSD 2-Clause\nhttps://github.com/jarun/nnn\n";

#[allow(non_camel_case_types)]
type c_int = i32;
extern "C" {
    fn isatty(fd: c_int) -> c_int;
}

#[derive(Default)]
struct Opts {
    detect_collision: bool,
    show_hidden: bool,
    detail: bool,
    picker: Option<String>,
    null_sep: bool,
    path: Option<String>,
}

fn print_help() {
    print!("{}", HELP);
    let _ = io::stdout().flush();
}

fn prog_name() -> String {
    env::args().next().unwrap_or_else(|| "nnn".to_string())
}

fn invalid(opt: char) -> ! {
    eprintln!("{}: invalid option -- '{}'", prog_name(), opt);
    print_help();
    process::exit(1);
}

fn missing(opt: char) -> ! {
    eprintln!("{}: option requires an argument -- '{}'", prog_name(), opt);
    print_help();
    process::exit(1);
}

fn parse_args() -> Opts {
    let mut opts = Opts::default();
    let mut args: Vec<String> = env::args().skip(1).collect();

    if let Ok(nnopts) = env::var("NNN_OPTS") {
        if !nnopts.is_empty() {
            let mut injected = Vec::new();
            for part in nnopts.split_whitespace() {
                if part.starts_with('-') {
                    injected.push(part.to_string());
                } else {
                    injected.push(format!("-{}", part));
                }
            }
            injected.extend(args);
            args = injected;
        }
    }

    let no_arg = "aABcCdDeEfgHiJKnNoQrRSuUxz0";
    let arg_req = "bFlpPstT";
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "-" || !arg.starts_with('-') {
            if opts.path.is_none() {
                opts.path = Some(arg.clone());
            }
            i += 1;
            continue;
        }
        let chars: Vec<char> = arg.chars().collect();
        if chars.len() >= 2 && chars[1] == '-' {
            invalid('-');
        }
        let mut j = 1;
        while j < chars.len() {
            let ch = chars[j];
            if ch == 'h' {
                print_help();
                process::exit(0);
            }
            if ch == 'V' {
                println!("5.2");
                process::exit(0);
            }
            if ch == 'K' {
                opts.detect_collision = true;
                j += 1;
                continue;
            }
            if ch == 'H' {
                opts.show_hidden = true;
                j += 1;
                continue;
            }
            if ch == 'd' {
                opts.detail = true;
                j += 1;
                continue;
            }
            if ch == '0' {
                opts.null_sep = true;
                j += 1;
                continue;
            }
            if no_arg.contains(ch) {
                j += 1;
                continue;
            }
            if arg_req.contains(ch) {
                let value = if j + 1 < chars.len() {
                    chars[j + 1..].iter().collect::<String>()
                } else {
                    i += 1;
                    if i >= args.len() {
                        missing(ch);
                    }
                    args[i].clone()
                };
                if ch == 'p' {
                    opts.picker = Some(value);
                }
                break;
            }
            invalid(ch);
        }
        i += 1;
    }
    opts
}

fn entries_for(path: &Path, show_hidden: bool) -> io::Result<Vec<PathBuf>> {
    let dir = if path.is_dir() { path.to_path_buf() } else { path.parent().unwrap_or_else(|| Path::new(".")).to_path_buf() };
    let mut entries = Vec::new();
    for entry in fs::read_dir(dir)? {
        let entry = entry?;
        let name = entry.file_name();
        if !show_hidden && name.to_string_lossy().starts_with('.') {
            continue;
        }
        entries.push(entry.path());
    }
    entries.sort_by(|a, b| {
        let an = a.file_name().unwrap_or_default().to_string_lossy().to_lowercase();
        let bn = b.file_name().unwrap_or_default().to_string_lossy().to_lowercase();
        an.cmp(&bn)
    });
    Ok(entries)
}

fn run_picker(opts: &Opts, path: &Path) -> i32 {
    let entries = match entries_for(path, opts.show_hidden) {
        Ok(v) => v,
        Err(_) => Vec::new(),
    };
    if let Some(target) = &opts.picker {
        if target == "-" {
            for e in entries {
                print!("{}{}", e.display(), if opts.null_sep { "\0" } else { "\n" });
            }
            return 0;
        }
        let data: String = entries.iter().map(|p| format!("{}\n", p.display())).collect();
        if fs::write(target, data).is_ok() { 0 } else { 1 }
    } else {
        0
    }
}

fn interactive_stub(opts: &Opts, path: &Path) -> i32 {
    let entries = entries_for(path, opts.show_hidden).unwrap_or_default();
    println!();
    println!("{}", path.display());
    for (idx, entry) in entries.iter().take(40).enumerate() {
        let name = entry.file_name().unwrap_or_default().to_string_lossy();
        if opts.detail {
            let marker = if entry.is_dir() { "/" } else { "" };
            println!("{:>3} {}{}", idx + 1, name, marker);
        } else {
            println!("{}", name);
        }
    }
    let _ = io::stdout().flush();
    let mut buf = [0_u8; 1];
    loop {
        match io::stdin().read(&mut buf) {
            Ok(0) | Err(_) => break,
            Ok(_) => {
                if matches!(buf[0], b'q' | 3 | 4 | 27) {
                    break;
                }
            }
        }
    }
    0
}

fn main() {
    let opts = parse_args();
    if opts.detect_collision {
        process::exit(0);
    }

    let path_s = opts.path.clone().unwrap_or_else(|| ".".to_string());
    let path = PathBuf::from(path_s);

    let stdin_tty = unsafe { isatty(0) != 0 };
    let stdout_tty = unsafe { isatty(1) != 0 };
    if !stdin_tty || !stdout_tty {
        eprintln!("0 entries");
        process::exit(1);
    }

    if opts.picker.is_some() {
        process::exit(run_picker(&opts, &path));
    }

    process::exit(interactive_stub(&opts, &path));
}
