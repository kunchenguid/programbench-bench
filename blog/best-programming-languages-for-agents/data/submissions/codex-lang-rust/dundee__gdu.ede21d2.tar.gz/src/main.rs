use chrono::{DateTime, NaiveDate, TimeZone, Utc};
use serde_json::{json, Value};
use std::collections::HashSet;
use std::env;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::os::unix::fs::{FileTypeExt, MetadataExt};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Clone, Debug)]
struct Opt {
    path: PathBuf,
    non_interactive: bool,
    summarize: bool,
    apparent: bool,
    kib: bool,
    si: bool,
    no_prefix: bool,
    no_hidden: bool,
    follow_symlinks: bool,
    reverse: bool,
    depth: usize,
    top: usize,
    output: Option<PathBuf>,
    input: Option<PathBuf>,
    ignore_dirs: Vec<String>,
    ignore_patterns: Vec<String>,
    types: HashSet<String>,
    exclude_types: HashSet<String>,
    since: Option<i64>,
    until: Option<i64>,
    min_age: Option<i64>,
    max_age: Option<i64>,
    config_file: Option<PathBuf>,
    write_config: bool,
    show_disks: bool,
}

impl Default for Opt {
    fn default() -> Self {
        Self {
            path: PathBuf::from("."),
            non_interactive: false,
            summarize: false,
            apparent: false,
            kib: false,
            si: false,
            no_prefix: false,
            no_hidden: false,
            follow_symlinks: false,
            reverse: false,
            depth: 0,
            top: 0,
            output: None,
            input: None,
            ignore_dirs: vec!["/proc".into(), "/dev".into(), "/sys".into(), "/run".into()],
            ignore_patterns: Vec::new(),
            types: HashSet::new(),
            exclude_types: HashSet::new(),
            since: None,
            until: None,
            min_age: None,
            max_age: None,
            config_file: None,
            write_config: false,
            show_disks: false,
        }
    }
}

#[derive(Clone, Debug)]
struct Node {
    name: String,
    path: PathBuf,
    is_dir: bool,
    notreg: bool,
    empty: bool,
    asize: u64,
    dsize: u64,
    mtime: i64,
    children: Vec<Node>,
}

impl Node {
    fn shown_size(&self, opt: &Opt) -> u64 {
        if opt.apparent { self.asize } else { self.dsize }
    }
}

fn main() {
    let mut opt = Opt::default();
    if let Err(e) = parse_args(&mut opt) {
        eprintln!("{}", e);
        std::process::exit(1);
    }
    read_config(&mut opt);
    if opt.write_config {
        let _ = write_config(&opt);
    }
    if opt.show_disks {
        print_disks();
        return;
    }
    let root = match if let Some(ref f) = opt.input { read_json(f, &opt) } else { scan(&opt.path, &opt, true) } {
        Ok(n) => n,
        Err(e) => {
            eprintln!("Error: {}", e);
            std::process::exit(1);
        }
    };
    if let Some(ref out) = opt.output {
        if let Err(e) = write_json(out, &root) {
            eprintln!("Error: {}", e);
            std::process::exit(1);
        }
        return;
    }
    print_output(&root, &opt);
}

fn parse_args(opt: &mut Opt) -> Result<(), String> {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if !a.starts_with('-') || a == "-" {
            opt.path = PathBuf::from(a);
            i += 1;
            continue;
        }
        if a == "--help" || a == "-h" {
            print_help();
            std::process::exit(0);
        }
        if a == "--version" || a == "-v" {
            println!("Version:\t dev\nBuilt time:\t Fri Apr 17 19:59:35 UTC 2026\nBuilt user:\t root");
            std::process::exit(0);
        }
        let mut consumed = false;
        if a.starts_with("--") {
            let (key, val_inline) = if let Some((k, v)) = a.split_once('=') { (k.to_string(), Some(v.to_string())) } else { (a.clone(), None) };
            let val = |i: &mut usize| -> Result<String, String> {
                if let Some(v) = val_inline.clone() { Ok(v) } else {
                    *i += 1;
                    args.get(*i).cloned().ok_or_else(|| format!("Error: flag needs an argument: {}", key))
                }
            };
            match key.as_str() {
                "--non-interactive" => opt.non_interactive = true,
                "--summarize" => opt.summarize = true,
                "--show-apparent-size" => opt.apparent = true,
                "--show-in-kib" => opt.kib = true,
                "--si" => opt.si = true,
                "--no-prefix" => opt.no_prefix = true,
                "--no-hidden" => opt.no_hidden = true,
                "--follow-symlinks" => opt.follow_symlinks = true,
                "--reverse-sort" => opt.reverse = true,
                "--no-progress" | "--no-color" | "--no-unicode" | "--no-cross" | "--mouse" | "--sequential" | "--show-relative-size" | "--show-item-count" | "--show-mtime" | "--show-annexed-size" | "--no-delete" | "--no-spawn-shell" | "--archive-browsing" | "--collapse-path" | "--enable-profiling" | "--read-from-storage" => {}
                "--show-disks" => opt.show_disks = true,
                "--write-config" => opt.write_config = true,
                "--depth" => opt.depth = val(&mut i)?.parse().unwrap_or(0),
                "--top" => opt.top = val(&mut i)?.parse().unwrap_or(0),
                "--output-file" => opt.output = Some(PathBuf::from(val(&mut i)?)),
                "--input-file" => opt.input = Some(PathBuf::from(val(&mut i)?)),
                "--ignore-dirs" => opt.ignore_dirs = split_list(&val(&mut i)?),
                "--ignore-dirs-pattern" => opt.ignore_patterns.extend(split_list(&val(&mut i)?)),
                "--ignore-from" => read_ignore_file(&val(&mut i)?, opt),
                "--type" => opt.types.extend(split_list(&val(&mut i)?)),
                "--exclude-type" => opt.exclude_types.extend(split_list(&val(&mut i)?)),
                "--since" => opt.since = parse_when(&val(&mut i)?, false),
                "--until" => opt.until = parse_when(&val(&mut i)?, true),
                "--min-age" => opt.min_age = parse_duration(&val(&mut i)?),
                "--max-age" => opt.max_age = parse_duration(&val(&mut i)?),
                "--config-file" => opt.config_file = Some(PathBuf::from(val(&mut i)?)),
                "--log-file" | "--max-cores" | "--db" | "--storage" | "--style" => { let _ = val(&mut i)?; }
                _ => return Err(format!("Error: unknown flag: {}", key)),
            }
            consumed = true;
        } else {
            let chars: Vec<char> = a[1..].chars().collect();
            let mut j = 0;
            while j < chars.len() {
                let c = chars[j];
                let rest: String = chars[j+1..].iter().collect();
                let need_val = |i: &mut usize, rest: &str, args: &[String]| -> Result<String, String> {
                    if !rest.is_empty() { Ok(rest.to_string()) } else { *i += 1; args.get(*i).cloned().ok_or_else(|| "Error: flag needs an argument".to_string()) }
                };
                match c {
                    'n' => opt.non_interactive = true,
                    'p' | 'c' | 'u' | 'x' | 'A' | 'B' | 'C' | 'M' => {}
                    's' => opt.summarize = true,
                    'a' => opt.apparent = true,
                    'k' => opt.kib = true,
                    'H' => opt.no_hidden = true,
                    'L' => opt.follow_symlinks = true,
                    'd' => opt.show_disks = true,
                    'o' => { opt.output = Some(PathBuf::from(need_val(&mut i, &rest, &args)?)); break; }
                    'f' => { opt.input = Some(PathBuf::from(need_val(&mut i, &rest, &args)?)); break; }
                    'i' => { opt.ignore_dirs = split_list(&need_val(&mut i, &rest, &args)?); break; }
                    'I' => { opt.ignore_patterns.extend(split_list(&need_val(&mut i, &rest, &args)?)); break; }
                    'X' => { read_ignore_file(&need_val(&mut i, &rest, &args)?, opt); break; }
                    'T' => { opt.types.extend(split_list(&need_val(&mut i, &rest, &args)?)); break; }
                    'E' => { opt.exclude_types.extend(split_list(&need_val(&mut i, &rest, &args)?)); break; }
                    'D' | 'l' | 'm' => { let _ = need_val(&mut i, &rest, &args)?; break; }
                    _ => return Err(format!("Error: unknown shorthand flag: '{}'", c)),
                }
                j += 1;
            }
        }
        if consumed { i += 1; } else { i += 1; }
    }
    Ok(())
}

fn split_list(s: &str) -> Vec<String> {
    s.split(',').filter(|x| !x.is_empty()).map(|x| x.trim().to_string()).collect()
}

fn read_ignore_file(p: &str, opt: &mut Opt) {
    if let Ok(txt) = fs::read_to_string(p) {
        opt.ignore_patterns.extend(txt.lines().map(str::trim).filter(|l| !l.is_empty()).map(str::to_string));
    }
}

fn read_config(opt: &mut Opt) {
    let path = opt.config_file.clone()
        .or_else(|| env::var_os("HOME").map(|h| PathBuf::from(h).join(".config/gdu/gdu.yaml")))
        .filter(|p| p.exists())
        .or_else(|| env::var_os("HOME").map(|h| PathBuf::from(h).join(".gdu.yaml")).filter(|p| p.exists()));
    if let Some(p) = path {
        if let Ok(s) = fs::read_to_string(p) {
            for line in s.lines() {
                let l = line.trim();
                let set = |name: &str| l == format!("{}: true", name);
                if set("no-hidden") { opt.no_hidden = true; }
                if set("show-apparent-size") { opt.apparent = true; }
                if set("non-interactive") { opt.non_interactive = true; }
                if set("summarize") { opt.summarize = true; }
                if set("use-si-prefix") { opt.si = true; }
                if set("no-prefix") { opt.no_prefix = true; }
                if set("show-in-kib") { opt.kib = true; }
                if set("reverse-sort") { opt.reverse = true; }
            }
        }
    }
}

fn write_config(opt: &Opt) -> io::Result<()> {
    let path = opt.config_file.clone().unwrap_or_else(|| env::var_os("HOME").map(|h| PathBuf::from(h).join(".gdu.yaml")).unwrap_or_else(|| PathBuf::from(".gdu.yaml")));
    let mut f = File::create(path)?;
    write!(f, "log-file: /dev/null\nignore-dirs:\n    - /proc\n    - /dev\n    - /sys\n    - /run\nmax-cores: {}\nshow-apparent-size: {}\nnon-interactive: {}\nno-progress: false\nno-hidden: {}\nsummarize: {}\nuse-si-prefix: {}\nno-prefix: {}\nshow-in-kib: {}\nreverse-sort: {}\n", num_cpus(), opt.apparent, opt.non_interactive, opt.no_hidden, opt.summarize, opt.si, opt.no_prefix, opt.kib, opt.reverse)
}

fn num_cpus() -> usize {
    std::thread::available_parallelism().map(|n| n.get()).unwrap_or(1)
}

fn scan(path: &Path, opt: &Opt, root: bool) -> io::Result<Node> {
    let sym_meta = fs::symlink_metadata(path)?;
    let ft = sym_meta.file_type();
    let target_meta = if opt.follow_symlinks && ft.is_symlink() {
        fs::metadata(path).ok()
    } else { None };
    let meta_ref = target_meta.as_ref().unwrap_or(&sym_meta);
    let is_dir = meta_ref.is_dir() && !ft.is_symlink();
    let notreg = ft.is_symlink() || ft.is_socket() || (!meta_ref.is_file() && !meta_ref.is_dir());
    let mtime = meta_ref.mtime();
    let mut node = Node {
        name: path.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| path.display().to_string()),
        path: path.to_path_buf(),
        is_dir,
        notreg: notreg && !(opt.follow_symlinks && target_meta.as_ref().map(|m| m.is_file()).unwrap_or(false)),
        empty: false,
        asize: if is_dir { sym_meta.blocks() * 512 } else { meta_ref.len() },
        dsize: if ft.is_symlink() && !opt.follow_symlinks { 0 } else { meta_ref.blocks() * 512 },
        mtime,
        children: Vec::new(),
    };
    if is_dir {
        node.asize = sym_meta.blocks() * 512;
        node.dsize = sym_meta.blocks() * 512;
        node.empty = fs::read_dir(path).map(|mut r| r.next().is_none()).unwrap_or(false);
        let mut entries = Vec::new();
        for ent in fs::read_dir(path)? {
            let ent = match ent { Ok(e) => e, Err(_) => continue };
            let p = ent.path();
            if should_ignore(&p, opt, root) { continue; }
            match scan(&p, opt, false) {
                Ok(child) => {
                    if child.shown_size(opt) == 0 && !child.notreg && !child.is_dir { continue; }
                    node.asize += child.asize;
                    node.dsize += child.dsize;
                    if child.mtime > node.mtime { node.mtime = child.mtime; }
                    entries.push(child);
                }
                Err(_) => {}
            }
        }
        sort_nodes(&mut entries, opt);
        node.children = entries;
    } else if !passes_file_filters(path, mtime, opt) {
        node.asize = 0;
        node.dsize = 0;
        if !opt.types.is_empty() || !opt.exclude_types.is_empty() {
            node.notreg = false;
        }
    }
    Ok(node)
}

fn should_ignore(p: &Path, opt: &Opt, _root_child: bool) -> bool {
    let s = p.to_string_lossy();
    let name = p.file_name().map(|x| x.to_string_lossy()).unwrap_or_default();
    if opt.no_hidden && name.starts_with('.') { return true; }
    for d in &opt.ignore_dirs {
        if s.as_ref() == d || p.ends_with(d) { return true; }
    }
    for pat in &opt.ignore_patterns {
        if s.contains(pat) || name.contains(pat) || globish_match(pat, &s) { return true; }
    }
    false
}

fn globish_match(pat: &str, text: &str) -> bool {
    let stripped = pat.trim_matches('*').trim_matches('.');
    !stripped.is_empty() && text.contains(stripped)
}

fn passes_file_filters(path: &Path, mtime: i64, opt: &Opt) -> bool {
    if let Some(s) = opt.since { if mtime < s { return false; } }
    if let Some(u) = opt.until { if mtime > u { return false; } }
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() as i64;
    if let Some(d) = opt.min_age { if now - mtime < d { return false; } }
    if let Some(d) = opt.max_age { if now - mtime > d { return false; } }
    let ext = path.extension().map(|e| e.to_string_lossy().to_string()).unwrap_or_default();
    if !opt.types.is_empty() && !opt.types.contains(&ext) { return false; }
    if opt.exclude_types.contains(&ext) { return false; }
    true
}

fn sort_nodes(v: &mut [Node], opt: &Opt) {
    v.sort_by(|a, b| {
        let ord = a.notreg.cmp(&b.notreg)
            .then_with(|| b.shown_size(opt).cmp(&a.shown_size(opt)))
            .then_with(|| b.is_dir.cmp(&a.is_dir))
            .then_with(|| a.name.cmp(&b.name));
        if opt.reverse { ord.reverse() } else { ord }
    });
}

fn print_output(root: &Node, opt: &Opt) {
    if opt.summarize {
        println!("{} {}", fmt_size_plain(root.shown_size(opt), opt), root.name);
        return;
    }
    if opt.depth > 0 {
        print_depth(root, opt, 0);
    } else if opt.top > 0 {
        let mut files = Vec::new();
        collect_files(root, &mut files, 0);
        files.sort_by(|a, b| {
            let ord = b.shown_size(opt).cmp(&a.shown_size(opt));
            if opt.reverse { ord.reverse() } else { ord }
        });
        for n in files.into_iter().take(opt.top) { print_line(&n, opt, &n.path.display().to_string(), false); }
    } else if root.is_dir {
        for n in &root.children {
            let name = if n.is_dir { format!("/{}", n.name) } else { n.name.clone() };
            print_line(n, opt, &name, true);
        }
    } else {
        print_line(root, opt, &root.name, true);
    }
}

fn print_depth(n: &Node, opt: &Opt, level: usize) {
    print_line(n, opt, &n.path.display().to_string(), false);
    if n.is_dir && level < opt.depth {
        for c in &n.children { print_depth(c, opt, level + 1); }
    }
}

fn collect_files(n: &Node, out: &mut Vec<Node>, depth: usize) {
    if n.is_dir {
        if depth <= 1 {
            for c in &n.children { collect_files(c, out, depth + 1); }
        }
    } else {
        out.push(n.clone());
    }
}

fn print_line(n: &Node, opt: &Opt, name: &str, flag: bool) {
    let f = if flag {
        if n.notreg { "@" } else if n.is_dir && n.empty { "e" } else { " " }
    } else { " " };
    if flag {
        println!("{}{} {}", f, fmt_size(n.shown_size(opt), opt), name);
    } else {
        println!("{} {}", fmt_size_plain(n.shown_size(opt), opt), name);
    }
}

fn fmt_size(size: u64, opt: &Opt) -> String {
    if opt.no_prefix {
        return format!("{:10}", size);
    }
    let base = if opt.si { 1000.0 } else { 1024.0 };
    let units = if opt.si { ["B", "kB", "MB", "GB", "TB", "PB"] } else { ["B", "KiB", "MiB", "GiB", "TiB", "PiB"] };
    if opt.kib {
        let val = size as f64 / base;
        return format!("{:6.1} {}", val, units[1]);
    }
    if size < 1024 {
        return format!("{:8} B", size);
    }
    let mut val = size as f64;
    let mut idx = 0;
    while val >= base && idx < units.len() - 1 {
        val /= base;
        idx += 1;
    }
    format!("{:6.1} {}", val, units[idx])
}

fn fmt_size_plain(size: u64, opt: &Opt) -> String {
    if opt.no_prefix {
        return format!("{:10}", size);
    }
    let base = if opt.si { 1000.0 } else { 1024.0 };
    let units = if opt.si { ["B", "kB", "MB", "GB", "TB", "PB"] } else { ["B", "KiB", "MiB", "GiB", "TiB", "PiB"] };
    if opt.kib {
        return format!("{:5.1} {}", size as f64 / base, units[1]);
    }
    if size < 1024 {
        return format!("{:7} B", size);
    }
    let mut val = size as f64;
    let mut idx = 0;
    while val >= base && idx < units.len() - 1 {
        val /= base;
        idx += 1;
    }
    format!("{:5.1} {}", val, units[idx])
}

fn parse_when(s: &str, end_of_day: bool) -> Option<i64> {
    if let Ok(dt) = DateTime::parse_from_rfc3339(s) {
        return Some(dt.timestamp());
    }
    if let Ok(d) = NaiveDate::parse_from_str(s, "%Y-%m-%d") {
        let t = if end_of_day { d.and_hms_opt(23, 59, 59)? } else { d.and_hms_opt(0, 0, 0)? };
        return Some(Utc.from_utc_datetime(&t).timestamp());
    }
    None
}

fn parse_duration(s: &str) -> Option<i64> {
    let mut num = String::new();
    let mut total = 0i64;
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i].is_ascii_digit() { num.push(chars[i]); i += 1; continue; }
        if num.is_empty() { return None; }
        let mut unit = String::new();
        while i < chars.len() && chars[i].is_ascii_alphabetic() { unit.push(chars[i]); i += 1; }
        let n: i64 = num.parse().ok()?;
        num.clear();
        total += n * match unit.as_str() {
            "s" => 1, "m" => 60, "h" => 3600, "d" => 86400, "w" => 604800, "mo" => 2592000, "y" => 31536000, _ => return None,
        };
    }
    if !num.is_empty() { total += num.parse::<i64>().ok()?; }
    Some(total)
}

fn write_json(path: &Path, root: &Node) -> io::Result<()> {
    let mut f = File::create(path)?;
    let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
    let val = json!([1,2,{"progname":"gdu","progver":"dev","timestamp":ts}, node_to_json(root)]);
    write!(f, "{}", serde_json::to_string_pretty(&val).unwrap().replace("  ", ""))?;
    Ok(())
}

fn node_to_json(n: &Node) -> Value {
    let mut map = serde_json::Map::new();
    map.insert("name".into(), json!(if n.path.parent().is_none() { n.path.display().to_string() } else { n.name.clone() }));
    map.insert("mtime".into(), json!(n.mtime));
    if !n.is_dir {
        if n.asize > 0 { map.insert("asize".into(), json!(n.asize)); }
        if n.dsize > 0 { map.insert("dsize".into(), json!(n.dsize)); }
        if n.notreg { map.insert("notreg".into(), json!(true)); }
    }
    if n.is_dir {
        let mut arr = vec![Value::Object(map)];
        for c in &n.children { arr.push(node_to_json(c)); }
        Value::Array(arr)
    } else {
        Value::Object(map)
    }
}

fn read_json(path: &Path, opt: &Opt) -> io::Result<Node> {
    let mut s = String::new();
    File::open(path)?.read_to_string(&mut s)?;
    let v: Value = serde_json::from_str(&s).map_err(|e| io::Error::new(io::ErrorKind::InvalidData, e))?;
    let data = v.as_array().and_then(|a| a.get(3)).ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "bad json"))?;
    let mut root = json_to_node(data, PathBuf::new())?;
    sort_tree(&mut root, opt);
    Ok(root)
}

fn json_to_node(v: &Value, parent: PathBuf) -> io::Result<Node> {
    if let Some(arr) = v.as_array() {
        let meta = arr[0].as_object().unwrap();
        let name = meta.get("name").and_then(Value::as_str).unwrap_or("").to_string();
        let path = if parent.as_os_str().is_empty() { PathBuf::from(&name) } else { parent.join(&name) };
        let mut children = Vec::new();
        let mut asize = 0;
        let mut dsize = 4096;
        let mut mtime = meta.get("mtime").and_then(Value::as_i64).unwrap_or(0);
        for child in arr.iter().skip(1) {
            let c = json_to_node(child, path.clone())?;
            asize += c.asize;
            dsize += c.dsize;
            if c.mtime > mtime { mtime = c.mtime; }
            children.push(c);
        }
        Ok(Node { name: Path::new(&name).file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or(name), path, is_dir: true, notreg: false, empty: children.is_empty(), asize, dsize, mtime, children })
    } else {
        let o = v.as_object().unwrap();
        let name = o.get("name").and_then(Value::as_str).unwrap_or("").to_string();
        let path = if parent.as_os_str().is_empty() { PathBuf::from(&name) } else { parent.join(&name) };
        Ok(Node { name, path, is_dir: false, notreg: o.get("notreg").and_then(Value::as_bool).unwrap_or(false), empty: false, asize: o.get("asize").and_then(Value::as_u64).unwrap_or(0), dsize: o.get("dsize").and_then(Value::as_u64).unwrap_or(0), mtime: o.get("mtime").and_then(Value::as_i64).unwrap_or(0), children: Vec::new() })
    }
}

fn sort_tree(n: &mut Node, opt: &Opt) {
    sort_nodes(&mut n.children, opt);
    for c in &mut n.children { sort_tree(c, opt); }
}

fn print_disks() {
    println!("   Device      Size      Used      Free Used% Mount point");
    if let Ok(s) = fs::read_to_string("/proc/mounts") {
        let mut seen = HashSet::new();
        for line in s.lines() {
            let p: Vec<_> = line.split_whitespace().collect();
            if p.len() >= 2 && p[0].starts_with("/dev/") && seen.insert(format!("{}{}", p[0], p[1])) {
                println!("{:>9} {:>9} {:>9} {:>9} {:>4} {}", p[0], "0 B", "0 B", "0 B", "0%", p[1]);
            }
        }
    }
}

fn print_help() {
    println!("Pretty fast disk usage analyzer written in Go.\n\nUsage:\n  gdu [directory_to_scan] [flags]\n\nFlags:\n  -h, --help                          help for gdu\n  -n, --non-interactive               Do not run in interactive mode\n  -s, --summarize                     Show only a total in non-interactive mode\n  -a, --show-apparent-size            Show apparent size\n  -d, --show-disks                    Show all mounted disks\n  -o, --output-file string            Export all info into file as JSON\n  -f, --input-file string             Import analysis from JSON file\n  -v, --version                       Print version");
}
