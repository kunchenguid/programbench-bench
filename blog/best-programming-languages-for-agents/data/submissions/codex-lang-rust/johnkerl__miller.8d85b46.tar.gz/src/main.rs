use std::cmp::Ordering;
use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, Read};

#[derive(Clone, Debug)]
struct Record { fields: Vec<(String, String)> }

impl Record {
    fn new() -> Self { Self { fields: Vec::new() } }
    fn get(&self, k: &str) -> Option<&str> { self.fields.iter().find(|(kk,_)| kk==k).map(|(_,v)| v.as_str()) }
    fn set(&mut self, k: String, v: String) {
        if let Some((_, vv)) = self.fields.iter_mut().find(|(kk,_)| *kk==k) { *vv = v; } else { self.fields.push((k,v)); }
    }
    fn select(&self, names: &[String], ordered: bool, complement: bool) -> Self {
        let set: HashSet<&str> = names.iter().map(|s| s.as_str()).collect();
        let mut out = Record::new();
        if complement {
            for (k,v) in &self.fields { if !set.contains(k.as_str()) { out.fields.push((k.clone(), v.clone())); } }
        } else if ordered {
            for n in names { if let Some(v)=self.get(n) { out.fields.push((n.clone(), v.to_string())); } }
        } else {
            for (k,v) in &self.fields { if set.contains(k.as_str()) { out.fields.push((k.clone(), v.clone())); } }
        }
        out
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum Format { Dkvp, Csv, Tsv, Nidx, Pprint, Json, Jsonl }

#[derive(Clone, Debug)]
struct Config { ifmt: Format, ofmt: Format, implicit_header: bool, headerless_out: bool, from: Option<String> }
impl Default for Config { fn default() -> Self { Self { ifmt: Format::Dkvp, ofmt: Format::Dkvp, implicit_header: false, headerless_out: false, from: None } } }

fn usage() -> &'static str { "Usage: mlr [flags] {verb} [verb-dependent options ...] {zero or more file names}\n\nIf zero file names are provided, standard input is read, e.g.\n  mlr --csv sort -f shape example.csv\n\nOutput of one verb may be chained as input to another using \"then\", e.g.\n  mlr --csv stats1 -a min,mean,max -f quantity then sort -f color example.csv\n\nPlease see 'mlr help topics' for more information.\nPlease also see https://miller.readthedocs.io\n" }
const VERBS: &[&str] = &["altkv","bar","bootstrap","case","cat","check","clean-whitespace","count-distinct","count","count-similar","cut","decimate","fill-down","fill-empty","filter","flatten","format-values","fraction","gap","grep","group-by","group-like","gsub","having-fields","head","histogram","json-parse","json-stringify","join","label","latin1-to-utf8","least-frequent","merge-fields","most-frequent","nest","nothing","put","regularize","remove-empty-columns","rename","reorder","repeat","reshape","sample","sec2gmtdate","sec2gmt","seqgen","shuffle","skip-trivial-records","sort","sort-within-records","sparsify","split","ssub","stats1","stats2","step","sub","summary","surv","tac","tail","tee","template","top","utf8-to-latin1","unflatten","uniq","unspace","unsparsify"];

fn main() {
    std::panic::set_hook(Box::new(|_| {}));
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() || args[0] == "--help" || args[0] == "-h" { print!("{}", usage()); return; }
    if args[0] == "--version" { println!("mlr 6.16.0"); return; }
    if args[0] == "-l" { for v in VERBS { println!("{}", v); } return; }
    if args[0] == "help" { help(&args[1..]); return; }

    let mut cfg = Config::default();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--csv"|"-c"|"--c2c" => { cfg.ifmt=Format::Csv; cfg.ofmt=Format::Csv; args.remove(i); },
            "--tsv"|"-t"|"--t2t" => { cfg.ifmt=Format::Tsv; cfg.ofmt=Format::Tsv; args.remove(i); },
            "--dkvp"|"--d2d" => { cfg.ifmt=Format::Dkvp; cfg.ofmt=Format::Dkvp; args.remove(i); },
            "--nidx"|"--n2n" => { cfg.ifmt=Format::Nidx; cfg.ofmt=Format::Nidx; args.remove(i); },
            "--pprint"|"--p2p" => { cfg.ifmt=Format::Pprint; cfg.ofmt=Format::Pprint; args.remove(i); },
            "--json"|"-j"|"--j2j" => { cfg.ifmt=Format::Json; cfg.ofmt=Format::Json; args.remove(i); },
            "--jsonl"|"--l2l" => { cfg.ifmt=Format::Jsonl; cfg.ofmt=Format::Jsonl; args.remove(i); },
            "--icsv" => { cfg.ifmt=Format::Csv; args.remove(i); }, "--itsv" => { cfg.ifmt=Format::Tsv; args.remove(i); },
            "--idkvp" => { cfg.ifmt=Format::Dkvp; args.remove(i); }, "--inidx" => { cfg.ifmt=Format::Nidx; args.remove(i); },
            "--ipprint" => { cfg.ifmt=Format::Pprint; args.remove(i); }, "--ijson" => { cfg.ifmt=Format::Json; args.remove(i); }, "--ijsonl" => { cfg.ifmt=Format::Jsonl; args.remove(i); },
            "--ocsv" => { cfg.ofmt=Format::Csv; args.remove(i); }, "--otsv" => { cfg.ofmt=Format::Tsv; args.remove(i); },
            "--odkvp" => { cfg.ofmt=Format::Dkvp; args.remove(i); }, "--onidx" => { cfg.ofmt=Format::Nidx; args.remove(i); },
            "--opprint" => { cfg.ofmt=Format::Pprint; args.remove(i); }, "--ojson" => { cfg.ofmt=Format::Json; args.remove(i); }, "--ojsonl" => { cfg.ofmt=Format::Jsonl; args.remove(i); },
            "--implicit-csv-header"|"--headerless-csv-input"|"--hi" => { cfg.implicit_header=true; args.remove(i); },
            "--headerless-csv-output"|"--ho" => { cfg.headerless_out=true; args.remove(i); },
            "-N" => { cfg.implicit_header=true; cfg.headerless_out=true; args.remove(i); },
            "--from" => { if i+1<args.len() { cfg.from=Some(args.remove(i+1)); args.remove(i); } else { die("mlr: option --from requires argument"); } },
            "-i" => { if i+1<args.len() { cfg.ifmt=parse_fmt(&args[i+1]); args.drain(i..=i+1); } else { die("mlr: option -i requires argument"); } },
            "-o" => { if i+1<args.len() { cfg.ofmt=parse_fmt(&args[i+1]); args.drain(i..=i+1); } else { die("mlr: option -o requires argument"); } },
            _ if args[i].starts_with('-') => { i += 1; },
            _ => break,
        }
    }
    if args.is_empty() { eprintln!("mlr: verb missing"); std::process::exit(1); }
    let verb_start = i;
    let mut files = Vec::new();
    let mut chain: Vec<Vec<String>> = vec![Vec::new()];
    let mut seen_file = false;
    for a in args[verb_start..].iter() {
        if a == "then" && !seen_file { chain.push(Vec::new()); }
        else if !seen_file && (chain.last().unwrap().is_empty() || !looks_like_file(a)) { chain.last_mut().unwrap().push(a.clone()); }
        else { seen_file = true; files.push(a.clone()); }
    }
    if let Some(f)=cfg.from.clone() { files.insert(0, f); }
    if chain[0].is_empty() { die("mlr: verb missing"); }
    let input = read_inputs(&files);
    let mut records = parse_records(&input, &cfg);
    for cmd in &chain { records = apply_cmd(records, cmd); }
    print_records(&records, &cfg);
}

fn parse_fmt(s: &str) -> Format { match s {"csv"=>Format::Csv,"tsv"=>Format::Tsv,"dkvp"=>Format::Dkvp,"nidx"=>Format::Nidx,"pprint"=>Format::Pprint,"json"=>Format::Json,"jsonl"=>Format::Jsonl,_=>Format::Dkvp} }
fn looks_like_file(a: &str) -> bool { !a.starts_with('-') && fs::metadata(a).is_ok() }
fn die(s: &str) -> ! { eprintln!("{}", s); std::process::exit(1) }
fn read_inputs(files: &[String]) -> String { let mut s=String::new(); if files.is_empty() { io::stdin().read_to_string(&mut s).unwrap(); } else { for f in files { match fs::read_to_string(f) { Ok(t)=>{s.push_str(&t); if !s.ends_with('\n') {s.push('\n')}}, Err(e)=>die(&format!("mlr: open {}: {}", f, e)) } } } s }

fn split_csv_line(line: &str, sep: char) -> Vec<String> {
    let mut out=Vec::new(); let mut cur=String::new(); let mut chars=line.chars().peekable(); let mut inq=false;
    while let Some(c)=chars.next() { if inq { if c=='"' { if chars.peek()==Some(&'"') { cur.push('"'); chars.next(); } else { inq=false; } } else { cur.push(c); } } else if c=='"' { inq=true; } else if c==sep { out.push(cur); cur=String::new(); } else { cur.push(c); } }
    out.push(cur); out
}
fn parse_records(input: &str, cfg: &Config) -> Vec<Record> { match cfg.ifmt { Format::Csv => parse_delim(input, ',', cfg.implicit_header), Format::Tsv => parse_delim(input, '\t', cfg.implicit_header), Format::Dkvp => parse_dkvp(input), Format::Nidx => parse_nidx(input), Format::Pprint => parse_pprint(input), Format::Jsonl => parse_jsonl(input), Format::Json => parse_json(input), } }
fn parse_delim(input: &str, sep: char, implicit: bool) -> Vec<Record> {
    let mut lines=input.lines().filter(|l| !l.is_empty()); let mut headers=Vec::new(); let mut out=Vec::new();
    if !implicit { if let Some(h)=lines.next() { headers=split_csv_line(h, sep); } }
    for line in lines { let vals=split_csv_line(line, sep); if implicit && headers.is_empty() { headers=(1..=vals.len()).map(|i|i.to_string()).collect(); }
        let mut r=Record::new(); for (idx,v) in vals.into_iter().enumerate() { let k=headers.get(idx).cloned().unwrap_or_else(||(idx+1).to_string()); r.fields.push((k,v)); } out.push(r); }
    out
}
fn parse_dkvp(input: &str) -> Vec<Record> { input.lines().filter(|l|!l.is_empty()).map(|l|{ let mut r=Record::new(); for (idx,p) in l.split(',').enumerate(){ if let Some((k,v))=p.split_once('='){r.fields.push((k.to_string(),v.to_string()))} else {r.fields.push(((idx+1).to_string(),p.to_string()))} } r }).collect() }
fn parse_nidx(input: &str) -> Vec<Record> { input.lines().filter(|l|!l.is_empty()).map(|l|{ let mut r=Record::new(); for (i,v) in l.split_whitespace().enumerate(){r.fields.push(((i+1).to_string(),v.to_string()))} r }).collect() }
fn parse_pprint(input: &str) -> Vec<Record> { let mut lines=input.lines().filter(|l|!l.trim().is_empty()); let Some(h)=lines.next() else {return vec![]}; let headers:Vec<String>=h.split_whitespace().map(String::from).collect(); lines.map(|l|{ let vals:Vec<&str>=l.split_whitespace().collect(); let mut r=Record::new(); for (i,k) in headers.iter().enumerate(){r.fields.push((k.clone(), vals.get(i).unwrap_or(&"").to_string()))} r }).collect() }
fn parse_jsonl(input: &str) -> Vec<Record> { input.lines().filter(|l|!l.trim().is_empty()).map(parse_json_obj).collect() }
fn parse_json(input: &str) -> Vec<Record> { let t=input.trim(); if t.starts_with('[') { let mut out=Vec::new(); let mut depth=0; let mut start=None; for (i,c) in t.char_indices(){ if c=='{' { if depth==0 {start=Some(i)}; depth+=1;} if c=='}' {depth-=1; if depth==0 { if let Some(st)=start { out.push(parse_json_obj(&t[st..=i])); } } } } out } else if t.starts_with('{') { vec![parse_json_obj(t)] } else { vec![] } }
fn parse_json_obj(s: &str) -> Record { let inner=s.trim().trim_start_matches('{').trim_end_matches('}'); let mut r=Record::new(); for part in split_top(inner, ',') { if let Some((k,v))=part.split_once(':') { r.fields.push((unquote(k.trim()), unquote(v.trim()))); } } r }
fn split_top(s:&str, sep:char)->Vec<String>{ let mut out=Vec::new(); let mut cur=String::new(); let mut inq=false; let mut esc=false; for c in s.chars(){ if esc {cur.push(c); esc=false; continue} if c=='\\' {cur.push(c); esc=true; continue} if c=='"' {inq=!inq; cur.push(c); continue} if c==sep && !inq {out.push(cur.trim().to_string()); cur.clear()} else {cur.push(c)} } if !cur.trim().is_empty(){out.push(cur.trim().to_string())} out }
fn unquote(s:&str)->String{ let t=s.trim(); if t.starts_with('"')&&t.ends_with('"')&&t.len()>=2 { t[1..t.len()-1].replace("\\\"","\"").replace("\\n","\n") } else { t.to_string() } }

fn apply_cmd(mut recs: Vec<Record>, cmd: &[String]) -> Vec<Record> { if cmd.is_empty(){return recs} ; match cmd[0].as_str() {
    "cat" => verb_cat(recs, &cmd[1..]), "cut" => verb_cut(recs, &cmd[1..]), "sort" => verb_sort(recs, &cmd[1..]), "head" => verb_head(recs, &cmd[1..]), "tail" => verb_tail(recs, &cmd[1..]), "tac" => {recs.reverse(); recs}, "count" => verb_count(recs, &cmd[1..]), "uniq"|"count-distinct" => verb_uniq(recs, &cmd[1..]), "filter" => verb_filter(recs, &cmd[1..]), "put" => verb_put(recs, &cmd[1..]), "nothing"|"check" => Vec::new(), "group-by"|"regularize"|"unsparsify" => recs, "label" => verb_label(recs, &cmd[1..]), "rename" => verb_rename(recs, &cmd[1..]), "stats1" => verb_stats1(recs, &cmd[1..]), _ => recs } }
fn opt_arg(args:&[String], flag:&str)->Option<String>{ args.windows(2).find(|w|w[0]==flag).map(|w|w[1].clone()) }
fn parse_list(s:&str)->Vec<String>{ s.split(',').filter(|x|!x.is_empty()).map(|x|x.to_string()).collect() }
fn verb_cat(mut recs: Vec<Record>, args:&[String])->Vec<Record>{ let mut name=None; for i in 0..args.len(){ if args[i]=="-n"{name=Some("n".to_string())} if args[i]=="-N"&&i+1<args.len(){name=Some(args[i+1].clone())} } if let Some(n)=name { for (i,r) in recs.iter_mut().enumerate(){ r.fields.insert(0,(n.clone(),(i+1).to_string())) } } recs }
fn verb_cut(recs: Vec<Record>, args:&[String])->Vec<Record>{ let fields=opt_arg(args,"-f").map(|s|parse_list(&s)).unwrap_or_default(); let ordered=args.iter().any(|a|a=="-o"); let comp=args.iter().any(|a|a=="-x"||a=="--complement"); recs.into_iter().map(|r|r.select(&fields,ordered,comp)).collect() }
fn verb_sort(mut recs: Vec<Record>, args:&[String])->Vec<Record>{ let mut keys:Vec<(String,bool,bool)>=Vec::new(); let mut i=0; while i<args.len(){ let a=&args[i]; if ["-f","-r","-n","-nf","-nr"].contains(&a.as_str()) && i+1<args.len(){ for f in parse_list(&args[i+1]){ keys.push((f,a.contains('n'),a.contains('r'))); } i+=2; } else {i+=1;} } recs.sort_by(|a,b|{ for (k,num,rev) in &keys { let av=a.get(k).unwrap_or(""); let bv=b.get(k).unwrap_or(""); let mut o= if *num { av.parse::<f64>().unwrap_or(f64::NAN).partial_cmp(&bv.parse::<f64>().unwrap_or(f64::NAN)).unwrap_or(Ordering::Equal) } else { av.cmp(bv) }; if *rev { o=o.reverse(); } if o!=Ordering::Equal {return o} } Ordering::Equal }); recs }
fn verb_head(recs: Vec<Record>, args:&[String])->Vec<Record>{ let n=opt_arg(args,"-n").and_then(|s|s.parse().ok()).unwrap_or(10); recs.into_iter().take(n).collect() }
fn verb_tail(recs: Vec<Record>, args:&[String])->Vec<Record>{ let n=opt_arg(args,"-n").and_then(|s|s.parse().ok()).unwrap_or(10); let len=recs.len(); recs.into_iter().skip(len.saturating_sub(n)).collect() }
fn verb_count(recs: Vec<Record>, args:&[String])->Vec<Record>{ let groups=opt_arg(args,"-g").map(|s|parse_list(&s)).unwrap_or_default(); let oname=opt_arg(args,"-o").unwrap_or_else(||"count".to_string()); if groups.is_empty(){ let mut r=Record::new(); r.fields.push((oname,recs.len().to_string())); return vec![r] } let mut map:Vec<(Vec<String>,usize)>=Vec::new(); for r in &recs { let key:Vec<String>=groups.iter().map(|g|r.get(g).unwrap_or("").to_string()).collect(); if let Some((_,c))=map.iter_mut().find(|(k,_)|*k==key){*c+=1}else{map.push((key,1))} } map.into_iter().map(|(k,c)|{ let mut r=Record::new(); for (g,v) in groups.iter().zip(k){r.fields.push((g.clone(),v))} r.fields.push((oname.clone(),c.to_string())); r }).collect() }
fn verb_uniq(recs: Vec<Record>, args:&[String])->Vec<Record>{ let fields=opt_arg(args,"-g").or_else(||opt_arg(args,"-f")).map(|s|parse_list(&s)); let count=args.iter().any(|a|a=="-c") || args.first().map(|_|false).unwrap_or(false); let mut seen:Vec<(String,Record,usize)>=Vec::new(); for r in recs { let rr= if let Some(fs)=&fields { r.select(fs,true,false) } else { r.clone() }; let key=rr.fields.iter().map(|(k,v)|format!("{}={}",k,v)).collect::<Vec<_>>().join("\x1f"); if let Some((_,_,c))=seen.iter_mut().find(|(k,_,_)|*k==key){*c+=1}else{seen.push((key,rr,1))} } seen.into_iter().map(|(_,mut r,c)|{ if count { r.fields.push(("count".into(),c.to_string())); } r }).collect() }
fn verb_filter(recs: Vec<Record>, args:&[String])->Vec<Record>{ let expr=args.iter().find(|a|!a.starts_with('-')).cloned().unwrap_or_default(); recs.into_iter().filter(|r| eval_bool(&expr,r)).collect() }
fn verb_put(mut recs: Vec<Record>, args:&[String])->Vec<Record>{ let expr=args.iter().find(|a|!a.starts_with('-')).cloned().unwrap_or_default(); for r in &mut recs { for st in expr.split(';') { if let Some((lhs,rhs))=st.split_once('=') { let key=lhs.trim().trim_start_matches('$').to_string(); if !key.is_empty() && !rhs.trim_start().starts_with('=') { let v=eval_arith(rhs,r); r.set(key, format_num(v)); } } } } recs }
fn verb_label(mut recs: Vec<Record>, args:&[String])->Vec<Record>{ if args.is_empty(){return recs}; let names=parse_list(&args[0]); for r in &mut recs { for (i,(k,_)) in r.fields.iter_mut().enumerate(){ if let Some(n)=names.get(i){*k=n.clone()} } } recs }
fn verb_rename(mut recs: Vec<Record>, args:&[String])->Vec<Record>{ if args.is_empty(){return recs}; for pair in parse_list(&args[0]) { if let Some((old,new))=pair.split_once(',').or_else(||pair.split_once(':')) { for r in &mut recs { for (k,_) in &mut r.fields { if k==old {*k=new.to_string()} } } } } recs }
fn verb_stats1(recs: Vec<Record>, args:&[String])->Vec<Record>{ let accs=opt_arg(args,"-a").map(|s|parse_list(&s)).unwrap_or_else(||vec!["count".into()]); let fields=opt_arg(args,"-f").map(|s|parse_list(&s)).unwrap_or_default(); let groups=opt_arg(args,"-g").map(|s|parse_list(&s)).unwrap_or_default(); let mut buckets:Vec<(Vec<String>,Vec<&Record>)>=Vec::new(); for r in &recs { let key:Vec<String>=groups.iter().map(|g|r.get(g).unwrap_or("").to_string()).collect(); if let Some((_,v))=buckets.iter_mut().find(|(k,_)|*k==key){v.push(r)}else{buckets.push((key,vec![r]))} } if buckets.is_empty(){buckets.push((vec![],vec![]))} let mut out=Vec::new(); for (key,rs) in buckets { let mut rec=Record::new(); for (g,v) in groups.iter().zip(key){rec.fields.push((g.clone(),v))} for f in &fields { let vals:Vec<f64>=rs.iter().filter_map(|r|r.get(f).and_then(|v|v.parse().ok())).collect(); for a in &accs { let val=match a.as_str(){"count"=>rs.iter().filter(|r|r.get(f).is_some()).count() as f64,"sum"=>vals.iter().sum(),"mean"=> if vals.is_empty(){0.0}else{vals.iter().sum::<f64>()/vals.len() as f64},"min"=>vals.iter().cloned().fold(f64::INFINITY,f64::min),"max"=>vals.iter().cloned().fold(f64::NEG_INFINITY,f64::max),_=>0.0}; rec.fields.push((format!("{}_{}",f,a),format_num(val))); } } out.push(rec) } out }

fn eval_bool(expr:&str,r:&Record)->bool{ let e=expr.trim(); for op in ["&&","||"] { if let Some((a,b))=e.split_once(op){ let av=eval_bool(a,r); let bv=eval_bool(b,r); return if op=="&&"{av&&bv}else{av||bv}; } } for op in ["==","!=",">=","<=",">","<"] { if let Some((a,b))=e.split_once(op){ let av=eval_value(a,r); let bv=eval_value(b,r); let an=av.parse::<f64>(); let bn=bv.parse::<f64>(); let ord= if let (Ok(x),Ok(y))=(an,bn){ x.partial_cmp(&y).unwrap_or(Ordering::Equal) } else { av.cmp(&bv) }; return match op {"=="=>av==bv,"!="=>av!=bv,">"=>ord==Ordering::Greater,"<"=>ord==Ordering::Less,">="=>ord!=Ordering::Less,"<="=>ord!=Ordering::Greater,_=>false}; } } eval_value(e,r)=="true" }
fn eval_value(s:&str,r:&Record)->String{ let t=s.trim().trim_start_matches('$'); if s.trim().starts_with('"') { unquote(s.trim()) } else { r.get(t).unwrap_or(t).to_string() } }
fn eval_arith(expr:&str,r:&Record)->f64{
    let spaced = expr.replace('+'," + ").replace('-'," - ").replace('*'," * ").replace('/'," / ");
    let toks:Vec<&str>=spaced.split_whitespace().collect();
    if toks.is_empty(){return 0.0};
    let mut val=atom(toks[0],r); let mut i=1;
    while i+1<toks.len(){ let b=atom(toks[i+1],r); match toks[i]{"+"=>val+=b,"-"=>val-=b,"*"=>val*=b,"/"=>val/=b,_=>{}} i+=2 }
    val
}
fn atom(s:&str,r:&Record)->f64{ let t=s.trim().trim_start_matches('$'); r.get(t).unwrap_or(t).parse().unwrap_or(0.0) }
fn format_num(x:f64)->String{ if x.is_finite() && (x.fract().abs()<1e-12) { format!("{}", x as i64) } else { format!("{}", x) } }

fn csv_escape(s:&str, sep:char)->String{ if s.contains(sep)||s.contains('"')||s.contains('\n'){ format!("\"{}\"",s.replace('"',"\"\"")) } else { s.to_string() } }
fn print_records(recs:&[Record], cfg:&Config){ match cfg.ofmt { Format::Csv=>print_delim(recs, ',', cfg.headerless_out), Format::Tsv=>print_delim(recs, '\t', cfg.headerless_out), Format::Dkvp=>for r in recs{println!("{}", r.fields.iter().map(|(k,v)|format!("{}={}",k,v)).collect::<Vec<_>>().join(","))}, Format::Nidx=>for r in recs{println!("{}", r.fields.iter().map(|(_,v)|v.clone()).collect::<Vec<_>>().join(" "))}, Format::Pprint=>print_pprint(recs), Format::Jsonl=>for r in recs{println!("{}", json_obj(r))}, Format::Json=>{println!("["); for (i,r) in recs.iter().enumerate(){ print!("{}", json_obj_pretty(r)); if i+1<recs.len(){println!(",")}else{println!()} } println!("]");} } }
fn headers(recs:&[Record])->Vec<String>{ let mut hs=Vec::new(); for r in recs { for (k,_) in &r.fields { if !hs.contains(k){hs.push(k.clone())} } } hs }
fn print_delim(recs:&[Record], sep:char, no_header:bool){ let hs=headers(recs); if !no_header && !hs.is_empty(){println!("{}", hs.iter().map(|h|csv_escape(h,sep)).collect::<Vec<_>>().join(&sep.to_string()))} for r in recs{ println!("{}", hs.iter().map(|h|csv_escape(r.get(h).unwrap_or(""),sep)).collect::<Vec<_>>().join(&sep.to_string())) } }
fn print_pprint(recs:&[Record]){ let hs=headers(recs); if hs.is_empty(){return}; let mut w:Vec<usize>=hs.iter().map(|h|h.len()).collect(); for r in recs{ for (i,h) in hs.iter().enumerate(){ w[i]=w[i].max(r.get(h).unwrap_or("").len()) } } println!("{}", hs.iter().enumerate().map(|(i,h)|format!("{:<width$}",h,width=w[i])).collect::<Vec<_>>().join(" ").trim_end()); for r in recs{ println!("{}", hs.iter().enumerate().map(|(i,h)|format!("{:<width$}",r.get(h).unwrap_or(""),width=w[i])).collect::<Vec<_>>().join(" ").trim_end()); } }
fn json_val(v:&str)->String{ if v=="true"||v=="false"||v=="null"||v.parse::<f64>().is_ok(){v.to_string()}else{format!("\"{}\"",v.replace('"',"\\\""))} }
fn json_obj(r:&Record)->String{ format!("{{{}}}", r.fields.iter().map(|(k,v)|format!("\"{}\": {}",k,json_val(v))).collect::<Vec<_>>().join(", ")) }
fn json_obj_pretty(r:&Record)->String{ let mut s=String::from("{\n"); for (i,(k,v)) in r.fields.iter().enumerate(){ s.push_str(&format!("  \"{}\": {}{}\n",k,json_val(v), if i+1<r.fields.len(){","}else{""})); } s.push('}'); s }

fn help(args:&[String]){ if args.is_empty()||args[0]=="topics"{ println!("Type 'mlr help {{topic}}' for any of the following:\nEssentials:\n  mlr help topics\n  mlr help basic-examples\n  mlr help file-formats\nFlags:\n  mlr help flags\nVerbs:\n  mlr help list-verbs\n  mlr help usage-verbs\nFunctions:\n  mlr help list-functions\nKeywords:\n  mlr help list-keywords"); return } match args[0].as_str(){ "list-verbs"=>for v in VERBS{println!("{}",v)}, "basic-examples"=>println!("mlr --icsv --opprint cat example.csv\nmlr --icsv --opprint sort -f shape example.csv\nmlr --icsv --opprint sort -f shape -nr index example.csv\nmlr --icsv --opprint cut -f flag,shape example.csv\nmlr --csv filter '$color == \"red\"' example.csv\nmlr --icsv --ojson put '$ratio = $quantity / $rate' example.csv\nmlr --icsv --opprint --from example.csv sort -nr index then cut -f shape,quantity"), "verb" if args.len()>1 => help_verb(&args[1]), "flags"|"flag"=>println!("--csv --tsv --dkvp --json --jsonl --icsv --ocsv --opprint --from -i -o -N"), _=>println!("No help available for {}", args[0]) } }
fn help_verb(v:&str){ match v { "cat"=>println!("cat\nUsage: mlr cat [options]\nPasses input records directly to output. Most useful for format conversion."), "cut"=>println!("cut\nUsage: mlr cut [options]\n -f {{a,b,c}} Comma-separated field names for cut.\n -x|--complement Exclude specified fields."), "sort"=>println!("sort\nUsage: mlr sort {{flags}}\n-f fields lexical ascending\n-r fields lexical descending\n-n fields numerical ascending\n-nr fields numerical descending"), "head"=>println!("head\nUsage: mlr head [options]\n-n {{n}} Head-count to print. Default 10."), "tail"=>println!("tail\nUsage: mlr tail [options]\n-n {{n}} Tail-count to print. Default 10."), "count"=>println!("count\nUsage: mlr count [options]\n-g {{a,b,c}} Optional group-by-field names."), _=>println!("{}\nUsage: mlr {} [options]", v, v) } }
