use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Clone, Debug, Default)]
struct Node {
    name: String,
    attrs: HashMap<String, String>,
    children: Vec<Node>,
    text: String,
}

#[derive(Clone, Debug, Default)]
struct Field {
    go_name: String,
    go_type: String,
    xml_name: String,
    attr: bool,
    repeated: bool,
    doc: String,
    inline_fields: Vec<Field>,
    chardata: bool,
}

#[derive(Clone, Debug, Default)]
struct TypeDef {
    name: String,
    namespace: String,
    fields: Vec<Field>,
    simple_alias: Option<String>,
    enum_values: Vec<(String, String)>,
    doc: String,
    root_element: bool,
}

#[derive(Clone, Debug, Default)]
struct Operation {
    name: String,
    input: String,
    output: String,
    action: String,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let mut out = "myservice.go".to_string();
    let mut pkg = "myservice".to_string();
    let mut dir = "./".to_string();
    let mut version = false;
    let mut wsdl_arg: Option<String> = None;
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "-o" => {
                i += 1;
                if i >= args.len() { usage(); std::process::exit(2); }
                out = args[i].clone();
            }
            "-p" => {
                i += 1;
                if i >= args.len() { usage(); std::process::exit(2); }
                pkg = args[i].clone();
            }
            "-d" => {
                i += 1;
                if i >= args.len() { usage(); std::process::exit(2); }
                dir = args[i].clone();
            }
            "-i" | "-make-public" => {}
            "-v" => version = true,
            "--help" | "-h" => { usage(); return; }
            s if s.starts_with('-') => {
                eprintln!("flag provided but not defined: {}", s);
                usage();
                std::process::exit(2);
            }
            s => wsdl_arg = Some(s.to_string()),
        }
        i += 1;
    }
    if version {
        println!("🍀  v0.5.0");
        return;
    }
    let Some(wsdl) = wsdl_arg else {
        usage();
        return;
    };
    let input_path = if Path::new(&wsdl).is_absolute() {
        PathBuf::from(&wsdl)
    } else {
        env::current_dir().unwrap().join(&wsdl)
    };
    println!("🍀  Reading file {}", input_path.display());
    let source = match fs::read_to_string(&input_path) {
        Ok(s) => s,
        Err(e) => {
            println!("🍀  {}", e);
            std::process::exit(1);
        }
    };
    match generate(&source, &pkg) {
        Ok((client, server)) => {
            let package_dir = Path::new(&dir).join(&pkg);
            if let Err(e) = fs::create_dir_all(&package_dir) {
                println!("🍀  {}", e);
                std::process::exit(1);
            }
            let client_path = package_dir.join(&out);
            let server_path = package_dir.join(format!("server{}", out));
            if let Err(e) = fs::write(&client_path, client).and_then(|_| fs::write(&server_path, server)) {
                println!("🍀  {}", e);
                std::process::exit(1);
            }
            println!("🍀  Done 👍");
        }
        Err(e) => {
            println!("🍀  {}", e);
            std::process::exit(1);
        }
    }
}

fn usage() {
    println!("Usage: ./executable [options] myservice.wsdl");
    println!("  -d string");
    println!("\tDirectory under which package directory will be created (default \"./\")");
    println!("  -i\tSkips TLS Verification");
    println!("  -make-public");
    println!("\tMake the generated types public/exported (default true)");
    println!("  -o string");
    println!("\tFile where the generated code will be saved (default \"myservice.go\")");
    println!("  -p string");
    println!("\tPackage under which code will be generated (default \"myservice\")");
    println!("  -v\tShows gowsdl version");
}

fn generate(src: &str, pkg: &str) -> Result<(String, String), String> {
    let root = parse_xml(src)?;
    let mut defs: Vec<TypeDef> = Vec::new();
    let mut messages: HashMap<String, String> = HashMap::new();
    let mut operations: Vec<Operation> = Vec::new();
    let mut iface = "Service".to_string();
    let mut actions: HashMap<String, String> = HashMap::new();

    for n in descendants(&root) {
        if local(&n.name) == "schema" {
            let ns = n.attrs.get("targetNamespace").cloned().unwrap_or_default();
            for c in &n.children {
                match local(&c.name) {
                    "element" => {
                        if let Some(td) = type_from_element(c, &ns, true) {
                            defs.push(td);
                        }
                    }
                    "complexType" => {
                        if let Some(name) = c.attrs.get("name") {
                            let mut td = TypeDef { name: public_name(name), namespace: ns.clone(), ..Default::default() };
                            td.fields = fields_from_complex(c, &ns);
                            defs.push(td);
                        }
                    }
                    "simpleType" => {
                        if let Some(name) = c.attrs.get("name") {
                            let mut td = TypeDef { name: public_name(name), namespace: ns.clone(), ..Default::default() };
                            let (base, vals) = simple_info(c);
                            td.simple_alias = Some(go_type(&base));
                            td.enum_values = vals;
                            defs.push(td);
                        }
                    }
                    _ => {}
                }
            }
        }
        if local(&n.name) == "message" {
            if let Some(name) = n.attrs.get("name") {
                if let Some(p) = n.children.iter().find(|x| local(&x.name) == "part") {
                    if let Some(el) = p.attrs.get("element").or_else(|| p.attrs.get("type")) {
                        messages.insert(name.clone(), public_name(strip_prefix(el)));
                    }
                }
            }
        }
        if local(&n.name) == "binding" {
            for op in n.children.iter().filter(|x| local(&x.name) == "operation") {
                if let Some(name) = op.attrs.get("name") {
                    for so in &op.children {
                        if local(&so.name) == "operation" {
                            if let Some(a) = so.attrs.get("soapAction") {
                                actions.insert(name.clone(), a.clone());
                            }
                        }
                    }
                }
            }
        }
    }
    if let Some(pt) = descendants(&root).into_iter().find(|n| local(&n.name) == "portType") {
        if let Some(n) = pt.attrs.get("name") { iface = public_name(n); }
        for op in pt.children.iter().filter(|x| local(&x.name) == "operation") {
            let name = op.attrs.get("name").cloned().unwrap_or_default();
            let mut input = String::new();
            let mut output = String::new();
            for c in &op.children {
                if local(&c.name) == "input" {
                    if let Some(m) = c.attrs.get("message") {
                        input = messages.get(strip_prefix(m)).cloned().unwrap_or_else(|| public_name(strip_prefix(m)));
                    }
                } else if local(&c.name) == "output" {
                    if let Some(m) = c.attrs.get("message") {
                        output = messages.get(strip_prefix(m)).cloned().unwrap_or_else(|| public_name(strip_prefix(m)));
                    }
                }
            }
            operations.push(Operation { action: actions.get(&name).cloned().unwrap_or_else(|| "''".to_string()), name: public_name(&name), input, output });
        }
    }
    dedup_types(&mut defs);
    let client = emit_client(pkg, &defs, &iface, &operations);
    let server = emit_server(pkg, src, &operations);
    Ok((client, server))
}

fn parse_xml(s: &str) -> Result<Node, String> {
    let mut stack = vec![Node { name: "#root".into(), ..Default::default() }];
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'<' {
            if s[i..].starts_with("<!--") {
                if let Some(j) = s[i+4..].find("-->") { i += j + 7; } else { break; }
                continue;
            }
            if s[i..].starts_with("<?") {
                if let Some(j) = s[i+2..].find("?>") { i += j + 4; } else { break; }
                continue;
            }
            if s[i..].starts_with("<!") {
                if let Some(j) = s[i..].find('>') { i += j + 1; } else { break; }
                continue;
            }
            let Some(end_rel) = s[i..].find('>') else { return Err("invalid XML".into()); };
            let mut inside = s[i+1..i+end_rel].trim().to_string();
            let close = inside.starts_with('/');
            if close {
                let node = stack.pop().ok_or("invalid XML")?;
                if let Some(parent) = stack.last_mut() { parent.children.push(node); }
            } else {
                let self_close = inside.ends_with('/');
                if self_close { inside.pop(); }
                let (name, attrs) = parse_tag(&inside);
                let node = Node { name, attrs, ..Default::default() };
                if self_close {
                    if let Some(parent) = stack.last_mut() { parent.children.push(node); }
                } else {
                    stack.push(node);
                }
            }
            i += end_rel + 1;
        } else {
            let next = s[i..].find('<').map(|x| i + x).unwrap_or(bytes.len());
            let t = s[i..next].trim();
            if !t.is_empty() {
                if let Some(last) = stack.last_mut() {
                    if !last.text.is_empty() { last.text.push(' '); }
                    last.text.push_str(t);
                }
            }
            i = next;
        }
    }
    while stack.len() > 1 {
        let node = stack.pop().unwrap();
        stack.last_mut().unwrap().children.push(node);
    }
    Ok(stack.pop().unwrap())
}

fn parse_tag(s: &str) -> (String, HashMap<String, String>) {
    let mut chars = s.chars().peekable();
    let mut name = String::new();
    while let Some(&c) = chars.peek() {
        if c.is_whitespace() { break; }
        name.push(c); chars.next();
    }
    let mut attrs = HashMap::new();
    loop {
        while matches!(chars.peek(), Some(c) if c.is_whitespace()) { chars.next(); }
        if chars.peek().is_none() { break; }
        let mut key = String::new();
        while let Some(&c) = chars.peek() {
            if c == '=' || c.is_whitespace() { break; }
            key.push(c); chars.next();
        }
        while matches!(chars.peek(), Some(c) if c.is_whitespace() || *c == '=') { chars.next(); }
        let quote = chars.next().unwrap_or('"');
        let mut val = String::new();
        for c in chars.by_ref() {
            if c == quote { break; }
            val.push(c);
        }
        if !key.is_empty() { attrs.insert(key, xml_unescape(&val)); }
    }
    (name, attrs)
}

fn type_from_element(n: &Node, ns: &str, root: bool) -> Option<TypeDef> {
    let name_raw = n.attrs.get("name")?;
    let name = public_name(name_raw);
    let doc = direct_documentation(n);
    if let Some(t) = n.attrs.get("type") {
        let base = strip_prefix(t);
        if !is_builtin(base) {
            return Some(TypeDef { name, namespace: ns.into(), simple_alias: Some(public_name(base)), doc, root_element: root, ..Default::default() });
        }
        let alias = go_type(base);
        if root || base == "dateTime" || base == "date" {
            return Some(TypeDef { name, namespace: ns.into(), simple_alias: Some(alias), doc, root_element: root, ..Default::default() });
        }
        return None;
    }
    if let Some(ct) = n.children.iter().find(|c| local(&c.name) == "complexType") {
        return Some(TypeDef { name, namespace: ns.into(), fields: fields_from_complex(ct, ns), doc, root_element: root, ..Default::default() });
    }
    if let Some(st) = n.children.iter().find(|c| local(&c.name) == "simpleType") {
        let (base, vals) = simple_info(st);
        return Some(TypeDef { name, namespace: ns.into(), simple_alias: Some(go_type(&base)), enum_values: vals, doc, root_element: root, ..Default::default() });
    }
    None
}

fn fields_from_complex(ct: &Node, ns: &str) -> Vec<Field> {
    let mut fields = Vec::new();
    for c in &ct.children {
        match local(&c.name) {
            "sequence" | "all" | "choice" => {
                for e in c.children.iter().filter(|x| local(&x.name) == "element") {
                    fields.push(field_from_element(e, ns));
                }
            }
            "attribute" => fields.push(field_from_attr(c, ns)),
            "simpleContent" => {
                fields.push(Field { go_name: "Value".into(), go_type: "string".into(), xml_name: ",chardata".into(), chardata: true, ..Default::default() });
                for ext in descendants(c).into_iter().filter(|x| local(&x.name) == "extension") {
                    for a in ext.children.iter().filter(|x| local(&x.name) == "attribute") {
                        fields.push(field_from_attr(a, ns));
                    }
                }
            }
            _ => {}
        }
    }
    fields
}

fn field_from_element(e: &Node, ns: &str) -> Field {
    let name = e.attrs.get("name").or_else(|| e.attrs.get("ref")).map(|s| strip_prefix(s).to_string()).unwrap_or_else(|| "Value".into());
    let mut go_t = e.attrs.get("type").map(|t| type_name(strip_prefix(t))).unwrap_or_else(|| "string".into());
    let mut inline = Vec::new();
    if let Some(ct) = e.children.iter().find(|x| local(&x.name) == "complexType") {
        inline = fields_from_complex(ct, ns);
        go_t = "struct".into();
    } else if let Some(st) = e.children.iter().find(|x| local(&x.name) == "simpleType") {
        let (base, _) = simple_info(st);
        go_t = go_type(&base);
    }
    let repeated = e.attrs.get("maxOccurs").map(|v| v == "unbounded" || v.parse::<usize>().unwrap_or(1) > 1).unwrap_or(false);
    Field { go_name: public_name(&name), go_type: go_t, xml_name: name, attr: false, repeated, doc: direct_documentation(e), inline_fields: inline, ..Default::default() }
}

fn field_from_attr(a: &Node, _ns: &str) -> Field {
    let name = a.attrs.get("name").or_else(|| a.attrs.get("ref")).map(|s| strip_prefix(s).to_string()).unwrap_or_else(|| "attr".into());
    let go_t = a.attrs.get("type").map(|t| type_name(strip_prefix(t))).unwrap_or_else(|| {
        if let Some(st) = a.children.iter().find(|x| local(&x.name) == "simpleType") {
            let (base, _) = simple_info(st);
            go_type(&base)
        } else { "string".into() }
    });
    Field { go_name: public_name(&name), go_type: go_t, xml_name: name, attr: true, doc: direct_documentation(a), ..Default::default() }
}

fn simple_info(st: &Node) -> (String, Vec<(String, String)>) {
    let mut base = "string".to_string();
    let mut vals = Vec::new();
    for r in descendants(st) {
        if local(&r.name) == "restriction" {
            if let Some(b) = r.attrs.get("base") { base = strip_prefix(b).to_string(); }
        }
        if local(&r.name) == "enumeration" {
            if let Some(v) = r.attrs.get("value") { vals.push((v.clone(), documentation(r))); }
        }
    }
    (base, vals)
}

fn emit_client(pkg: &str, defs: &[TypeDef], iface: &str, ops: &[Operation]) -> String {
    let mut s = String::new();
    s.push_str("// Code generated by gowsdl DO NOT EDIT.\n\n");
    s.push_str(&format!("package {}\n\n", pkg));
    s.push_str("import (\n\t\"context\"\n\t\"encoding/xml\"\n\t\"github.com/hooklift/gowsdl/soap\"\n\t\"time\"\n)\n\n");
    s.push_str("// against \"unused imports\"\nvar _ time.Time\nvar _ xml.Name\n\n");
    s.push_str("type AnyType struct {\n\tInnerXML string `xml:\",innerxml\"`\n}\n\n");
    s.push_str("type AnyURI string\n\n");
    s.push_str("type NCName string\n\n");
    for d in defs {
        emit_typedef(&mut s, d);
    }
    if !ops.is_empty() {
        s.push_str(&format!("type {} interface {{\n", iface));
        for op in ops {
            s.push_str(&format!("\t{}(request *{}) (*{}, error)\n\n", op.name, op.input, op.output));
            s.push_str(&format!("\t{}Context(ctx context.Context, request *{}) (*{}, error)\n\n", op.name, op.input, op.output));
        }
        s.push_str("}\n\n");
        let recv = private_name(iface);
        s.push_str(&format!("type {} struct {{\n\tclient *soap.Client\n}}\n\n", recv));
        s.push_str(&format!("func New{}(client *soap.Client) {} {{\n\treturn &{}{{\n\t\tclient: client,\n\t}}\n}}\n\n", iface, iface, recv));
        for op in ops {
            s.push_str(&format!("func (service *{}) {}Context(ctx context.Context, request *{}) (*{}, error) {{\n", recv, op.name, op.input, op.output));
            s.push_str(&format!("\tresponse := new({})\n", op.output));
            s.push_str(&format!("\terr := service.client.CallContext(ctx, \"{}\", request, response)\n", op.action));
            s.push_str("\tif err != nil {\n\t\treturn nil, err\n\t}\n\n\treturn response, nil\n}\n\n");
            s.push_str(&format!("func (service *{}) {}(request *{}) (*{}, error) {{\n", recv, op.name, op.input, op.output));
            s.push_str(&format!("\treturn service.{}Context(\n\t\tcontext.Background(),\n\t\trequest,\n\t)\n}}\n\n", op.name));
        }
    }
    s
}

fn emit_typedef(s: &mut String, d: &TypeDef) {
    if let Some(alias) = &d.simple_alias {
        if d.doc.len() > 0 { s.push_str(&format!("// {}\n", d.doc)); }
        s.push_str(&format!("type {} {}\n\n", d.name, alias));
        if !d.enum_values.is_empty() {
            s.push_str("const (\n\n");
            for (v, doc) in &d.enum_values {
                if !doc.is_empty() { s.push_str(&format!("\t// {}\n", doc)); }
                s.push_str(&format!("\t{}{} {} = \"{}\"\n\n", d.name, public_name(v), d.name, v));
            }
            s.push_str(")\n\n");
        }
        if alias == "soap.XSDDateTime" {
            s.push_str(&format!("func (xdt {}) MarshalXML(e *xml.Encoder, start xml.StartElement) error {{\n\treturn soap.XSDDateTime(xdt).MarshalXML(e, start)\n}}\n\n", d.name));
            s.push_str(&format!("func (xdt *{}) UnmarshalXML(dec *xml.Decoder, start xml.StartElement) error {{\n\treturn (*soap.XSDDateTime)(xdt).UnmarshalXML(dec, start)\n}}\n\n", d.name));
        }
        return;
    }
    if d.doc.len() > 0 { s.push_str(&format!("// {}\n", d.doc)); }
    s.push_str(&format!("type {} struct {{\n", d.name));
    if d.root_element {
        s.push_str(&format!("\tXMLName xml.Name `xml:\"{} {}\"`\n\n", d.namespace, d.name));
    }
    for f in &d.fields {
        emit_field(s, f, &d.namespace);
    }
    s.push_str("}\n\n");
}

fn emit_field(s: &mut String, f: &Field, ns: &str) {
    if !f.doc.is_empty() { s.push_str(&format!("\t// {}\n", f.doc)); }
    if f.chardata {
        s.push_str("\tValue string `xml:\",chardata\" json:\"-,\"`\n\n");
        return;
    }
    let mut typ = f.go_type.clone();
    if typ == "struct" {
        if f.repeated { s.push_str(&format!("\t{} []struct {{\n", f.go_name)); } else { s.push_str(&format!("\t{} struct {{\n", f.go_name)); }
        for sub in &f.inline_fields { emit_field(s, sub, ns); }
        s.push_str(&format!("\t}} `xml:\"{},omitempty\" json:\"{},omitempty\"`\n\n", f.xml_name, f.xml_name));
        return;
    }
    if !is_go_builtin(&typ) && f.attr { typ = format!("*{}", typ); }
    if f.repeated { typ = format!("[]{}", typ); }
    let tag = if f.attr {
        format!("{} {},attr,omitempty", ns, f.xml_name)
    } else {
        format!("{},omitempty", f.xml_name)
    };
    s.push_str(&format!("\t{} {} `xml:\"{}\" json:\"{},omitempty\"`\n\n", f.go_name, typ, tag, f.xml_name));
}

fn emit_server(pkg: &str, original: &str, ops: &[Operation]) -> String {
    let mut s = String::new();
    s.push_str("// Code generated by gowsdl DO NOT EDIT.\n\n");
    s.push_str(&format!("package {}\n\n", pkg));
    s.push_str("import (\n\t\"encoding/xml\"\n\t\"errors\"\n\t\"fmt\"\n\t\"net/http\"\n\t\"reflect\"\n\t\"strings\"\n)\n\n");
    s.push_str("var wsdl = `");
    s.push_str(&original.replace('`', "` + \"`\" + `"));
    if !original.ends_with('\n') { s.push('\n'); }
    s.push_str("`\n\n");
    s.push_str("var WSDLUndefinedError = errors.New(\"Server was unable to process request. --> Object reference not set to an instance of an object.\")\n\n");
    s.push_str("type SOAPEnvelopeRequest struct {\n\tXMLName xml.Name `xml:\"http://schemas.xmlsoap.org/soap/envelope/ Envelope\"`\n\tBody    SOAPBodyRequest\n}\n\n");
    s.push_str("type SOAPBodyRequest struct {\n\tXMLName xml.Name `xml:\"http://schemas.xmlsoap.org/soap/envelope/ Body\"`\n\n");
    for op in ops { s.push_str(&format!("\t{} *{} `xml:,omitempty`\n", op.input, op.input)); }
    s.push_str("}\n\n");
    s.push_str("type SOAPEnvelopeResponse struct {\n\tXMLName    xml.Name `xml:\"soap:Envelope\"`\n\tPrefixSoap string   `xml:\"xmlns:soap,attr\"`\n\tPrefixXsi  string   `xml:\"xmlns:xsi,attr\"`\n\tPrefixXsd  string   `xml:\"xmlns:xsd,attr\"`\n\n\tBody SOAPBodyResponse\n}\n\n");
    s.push_str("func NewSOAPEnvelopResponse() *SOAPEnvelopeResponse {\n\treturn &SOAPEnvelopeResponse{\n\t\tPrefixSoap: \"http://schemas.xmlsoap.org/soap/envelope/\",\n\t\tPrefixXsd:  \"http://www.w3.org/2001/XMLSchema\",\n\t\tPrefixXsi:  \"http://www.w3.org/2001/XMLSchema-instance\",\n\t}\n}\n\n");
    s.push_str("type Fault struct {\n\tXMLName xml.Name `xml:\"SOAP-ENV:Fault\"`\n\tSpace   string   `xml:\"xmlns:SOAP-ENV,omitempty,attr\"`\n\n\tCode   string `xml:\"faultcode,omitempty\"`\n\tString string `xml:\"faultstring,omitempty\"`\n\tActor  string `xml:\"faultactor,omitempty\"`\n\tDetail string `xml:\"detail,omitempty\"`\n}\n\n");
    s.push_str("type SOAPBodyResponse struct {\n\tXMLName xml.Name `xml:\"soap:Body\"`\n\tFault   *Fault   `xml:\",omitempty\"`\n\n");
    for op in ops { s.push_str(&format!("\t{} *{} `xml:\",omitempty\"`\n", op.input, op.output)); }
    s.push_str("}\n\n");
    for op in ops {
        s.push_str(&format!("func (service *SOAPBodyRequest) {}Func(request *{}) (*{}, error) {{\n\treturn nil, WSDLUndefinedError\n}}\n\n", op.input, op.input, op.output));
    }
    s.push_str(include_str!("server_tail.txt"));
    s
}

fn dedup_types(defs: &mut Vec<TypeDef>) {
    let mut seen = HashSet::new();
    defs.retain(|d| seen.insert(d.name.clone()));
}

fn descendants<'a>(n: &'a Node) -> Vec<&'a Node> {
    let mut out = Vec::new();
    fn walk<'a>(n: &'a Node, out: &mut Vec<&'a Node>) {
        out.push(n);
        for c in &n.children { walk(c, out); }
    }
    walk(n, &mut out);
    out
}

fn documentation(n: &Node) -> String {
    for d in descendants(n) {
        if local(&d.name) == "documentation" && !d.text.trim().is_empty() {
            return d.text.trim().split_whitespace().collect::<Vec<_>>().join(" ");
        }
    }
    String::new()
}

fn direct_documentation(n: &Node) -> String {
    for c in &n.children {
        if local(&c.name) == "annotation" {
            for d in &c.children {
                if local(&d.name) == "documentation" && !d.text.trim().is_empty() {
                    return d.text.trim().split_whitespace().collect::<Vec<_>>().join(" ");
                }
            }
        }
    }
    String::new()
}

fn local(n: &str) -> &str { n.rsplit(':').next().unwrap_or(n) }
fn strip_prefix(n: &str) -> &str { n.rsplit(':').next().unwrap_or(n) }

fn public_name(s: &str) -> String {
    let mut out = String::new();
    let mut cap = true;
    for c in s.chars() {
        if c.is_ascii_alphanumeric() {
            if out.is_empty() && c.is_ascii_digit() { out.push('_'); }
            if cap { out.push(c.to_ascii_uppercase()); } else { out.push(c); }
            cap = false;
        } else {
            cap = true;
        }
    }
    if out.is_empty() { "Value".into() } else { out }
}

fn private_name(s: &str) -> String {
    let mut chars: Vec<char> = s.chars().collect();
    if let Some(c) = chars.first_mut() { *c = c.to_ascii_lowercase(); }
    chars.into_iter().collect()
}

fn is_builtin(s: &str) -> bool {
    matches!(s, "string"|"normalizedString"|"token"|"float"|"double"|"decimal"|"int"|"integer"|"long"|"short"|"byte"|"boolean"|"bool"|"dateTime"|"date"|"time"|"base64Binary"|"anyType"|"anyURI"|"NCName")
}

fn go_type(s: &str) -> String {
    match s {
        "string" | "normalizedString" | "token" => "string",
        "float" => "float32",
        "double" | "decimal" => "float64",
        "int" | "integer" | "long" | "short" | "byte" => "int",
        "boolean" | "bool" => "bool",
        "dateTime" | "date" | "time" => "soap.XSDDateTime",
        "base64Binary" => "[]byte",
        "anyURI" => "AnyURI",
        "NCName" => "NCName",
        "anyType" => "AnyType",
        other => return public_name(other),
    }.to_string()
}

fn type_name(s: &str) -> String {
    if is_builtin(s) { go_type(s) } else { public_name(s) }
}

fn is_go_builtin(s: &str) -> bool {
    matches!(s, "string"|"float32"|"float64"|"int"|"bool"|"[]byte"|"soap.XSDDateTime"|"AnyURI"|"NCName"|"AnyType")
}

fn xml_unescape(s: &str) -> String {
    s.replace("&quot;", "\"").replace("&apos;", "'").replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&")
}
