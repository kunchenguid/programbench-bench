use std::collections::{BTreeMap, HashMap, HashSet};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};

const BANNER: &str = r#"
 _ __ _____   _(_)__  _____
| '__/ _ \ \ / / \ \ / / _ \
| | |  __/\ V /| |\ V /  __/
|_|  \___| \_/ |_| \_/ \___|

Example:
  revive -config c.toml -formatter friendly -exclude a.go -exclude b.go ./...
"#;

#[derive(Clone, Debug)]
struct Config {
    severity: String,
    rules: HashMap<String, RuleConfig>,
}

#[derive(Clone, Debug, Default)]
struct RuleConfig {
    disabled: bool,
    arguments: Vec<String>,
}

#[derive(Clone, Debug)]
struct Issue {
    filename: String,
    line: usize,
    column: usize,
    end_column: usize,
    offset: usize,
    end_offset: usize,
    rule: String,
    category: String,
    severity: String,
    message: String,
}

#[derive(Default)]
struct Args {
    config: Option<String>,
    excludes: Vec<String>,
    formatter: String,
    set_exit_status: bool,
    version: bool,
    help: bool,
    packages: Vec<String>,
}

fn main() {
    let args = parse_args();
    if args.help {
        print_help();
        return;
    }
    if args.version {
        println!("Version:\ta75b67b");
        println!("Commit:\t\ta75b67b73b9edb91dfc9f302dd108fa9d3ea5b05");
        println!("Built\t\t2026-04-17 19:59 UTC by build.sh");
        return;
    }

    let config_path = match find_config(args.config.as_deref()) {
        Ok(p) => p,
        Err(msg) => {
            println!("{}", msg);
            std::process::exit(1);
        }
    };

    let config = match config_path {
        Some(path) => match fs::read_to_string(path) {
            Ok(s) => parse_config(&s),
            Err(_) => {
                println!("cannot read the config file");
                std::process::exit(1);
            }
        },
        None => {
            println!("initializing revive - getting lint rules: cannot configure rule: \"var-naming\": load std packages: err: go command required, not found: exec: \"go\": executable file not found in $PATH: stderr: ");
            std::process::exit(1);
        }
    };

    let roots = if args.packages.is_empty() {
        vec![".".to_string()]
    } else {
        args.packages.clone()
    };
    let files = collect_go_files(&roots, &args.excludes);
    let mut issues = Vec::new();
    for file in files {
        if let Ok(text) = fs::read_to_string(&file) {
            let display = display_path(&file);
            lint_file(&display, &text, &config, &mut issues);
        }
    }

    format_issues(&args.formatter, &issues);
    if args.set_exit_status && !issues.is_empty() {
        std::process::exit(1);
    }
}

fn parse_args() -> Args {
    let mut out = Args {
        formatter: "default".into(),
        ..Args::default()
    };
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => out.help = true,
            "-version" | "--version" => out.version = true,
            "-set_exit_status" => out.set_exit_status = true,
            "-config" => out.config = it.next(),
            "-formatter" => out.formatter = it.next().unwrap_or_default(),
            "-exclude" => {
                if let Some(v) = it.next() {
                    out.excludes.push(v);
                }
            }
            "-max_open_files" => {
                let _ = it.next();
            }
            x if x.starts_with("-config=") => out.config = Some(x[8..].to_string()),
            x if x.starts_with("-formatter=") => out.formatter = x.get(11..).unwrap_or("").to_string(),
            x if x.starts_with("-exclude=") => out.excludes.push(x[9..].to_string()),
            x if x.starts_with("-max_open_files=") => {}
            other => out.packages.push(other.to_string()),
        }
    }
    out
}

fn print_help() {
    println!("{}", BANNER);
    println!("Usage of ./executable:");
    println!("  -config string");
    println!("\t\tpath to the configuration TOML file, defaults to $XDG_CONFIG_HOME/revive.toml or $HOME/revive.toml, if present (i.e. -config myconf.toml)");
    println!("  -exclude value");
    println!("\t\tlist of globs which specify files to be excluded (i.e. -exclude foo/...)");
    println!("  -formatter string");
    println!("\t\tformatter to be used for the output (i.e. -formatter stylish)");
    println!("  -max_open_files int");
    println!("\t\tmaximum number of open files at the same time");
    println!("  -set_exit_status");
    println!("\t\tset exit status to 1 if any issues are found, overwrites errorCode and warningCode in config");
    println!("  -version");
    println!("\t\tget revive version");
}

fn find_config(explicit: Option<&str>) -> Result<Option<PathBuf>, String> {
    if let Some(path) = explicit {
        let p = PathBuf::from(path);
        if p.exists() {
            return Ok(Some(p));
        }
        return Err("cannot read the config file".into());
    }
    if let Ok(xdg) = env::var("XDG_CONFIG_HOME") {
        let p = PathBuf::from(xdg).join("revive.toml");
        if p.exists() {
            return Ok(Some(p));
        }
    }
    if let Ok(home) = env::var("HOME") {
        let p = PathBuf::from(home).join("revive.toml");
        if p.exists() {
            return Ok(Some(p));
        }
    }
    Ok(None)
}

fn parse_config(s: &str) -> Config {
    let mut cfg = Config {
        severity: "warning".into(),
        rules: HashMap::new(),
    };
    let mut current: Option<String> = None;
    for raw in s.lines() {
        let line = raw.split('#').next().unwrap_or("").trim();
        if line.is_empty() {
            continue;
        }
        if line.starts_with('[') && line.ends_with(']') {
            let sec = &line[1..line.len() - 1];
            current = sec.strip_prefix("rule.").map(|v| v.trim_matches('"').to_string());
            if let Some(rule) = &current {
                cfg.rules.entry(rule.clone()).or_default();
            }
            continue;
        }
        let Some((key, val)) = line.split_once('=') else { continue };
        let key = key.trim();
        let val = val.trim();
        if let Some(rule) = &current {
            let entry = cfg.rules.entry(rule.clone()).or_default();
            if key.eq_ignore_ascii_case("disabled") {
                entry.disabled = val.eq_ignore_ascii_case("true");
            } else if key.eq_ignore_ascii_case("arguments") {
                entry.arguments = parse_array(val);
            }
        } else if key == "severity" {
            cfg.severity = unquote(val).to_string();
        }
    }
    cfg
}

fn parse_array(v: &str) -> Vec<String> {
    let t = v.trim().trim_start_matches('[').trim_end_matches(']');
    t.split(',')
        .map(|x| unquote(x.trim()).to_string())
        .filter(|x| !x.is_empty())
        .collect()
}

fn unquote(v: &str) -> &str {
    v.trim().trim_matches('"').trim_matches('\'')
}

fn rule_enabled(cfg: &Config, name: &str) -> bool {
    cfg.rules.get(name).map(|r| !r.disabled).unwrap_or(false)
}

fn collect_go_files(roots: &[String], excludes: &[String]) -> Vec<PathBuf> {
    let mut out = Vec::new();
    for root in roots {
        if let Some(base) = root.strip_suffix("/...") {
            walk(Path::new(if base.is_empty() { "." } else { base }), excludes, &mut out);
        } else {
            let p = PathBuf::from(root);
            if p.is_dir() {
                read_dir_go(&p, excludes, &mut out);
            } else if is_go_file(&p) && !excluded(&p, excludes) {
                out.push(p);
            }
        }
    }
    out.sort();
    out
}

fn walk(dir: &Path, excludes: &[String], out: &mut Vec<PathBuf>) {
    if excluded(dir, excludes) {
        return;
    }
    read_dir_go(dir, excludes, out);
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() {
                walk(&p, excludes, out);
            }
        }
    }
}

fn read_dir_go(dir: &Path, excludes: &[String], out: &mut Vec<PathBuf>) {
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let p = e.path();
            if is_go_file(&p) && !excluded(&p, excludes) {
                out.push(p);
            }
        }
    }
}

fn is_go_file(p: &Path) -> bool {
    p.extension().and_then(|s| s.to_str()) == Some("go")
        && !p.file_name().and_then(|s| s.to_str()).unwrap_or("").ends_with("_test.go")
}

fn excluded(p: &Path, patterns: &[String]) -> bool {
    let s = display_path(p);
    patterns.iter().any(|pat| {
        if let Some(prefix) = pat.strip_suffix("/...") {
            s == prefix || s.starts_with(&format!("{}/", prefix))
        } else if pat.contains('*') {
            glob_match(pat, &s)
        } else {
            s == *pat || s.ends_with(&format!("/{}", pat))
        }
    })
}

fn glob_match(pat: &str, text: &str) -> bool {
    fn inner(p: &[u8], t: &[u8]) -> bool {
        if p.is_empty() {
            return t.is_empty();
        }
        if p[0] == b'*' {
            (0..=t.len()).any(|i| inner(&p[1..], &t[i..]))
        } else if !t.is_empty() && (p[0] == b'?' || p[0] == t[0]) {
            inner(&p[1..], &t[1..])
        } else {
            false
        }
    }
    inner(pat.as_bytes(), text.as_bytes())
}

fn display_path(p: &Path) -> String {
    let s = p.to_string_lossy().replace('\\', "/");
    s.strip_prefix("./").unwrap_or(&s).to_string()
}

fn lint_file(filename: &str, text: &str, cfg: &Config, issues: &mut Vec<Issue>) {
    let disabled = disabled_lines(text);
    let lines: Vec<&str> = text.lines().collect();
    if rule_enabled(cfg, "line-length-limit") {
        let limit = cfg.rules["line-length-limit"].arguments.get(0)
            .and_then(|v| v.parse::<usize>().ok()).unwrap_or(80);
        let mut offset = 0;
        for (idx, line) in lines.iter().enumerate() {
            let len = line.chars().count();
            let line_no = idx + 1;
            if len > limit && !is_disabled(&disabled, "line-length-limit", line_no) {
                issues.push(Issue {
                    filename: filename.into(), line: line_no, column: 0, end_column: len,
                    offset: 0, end_offset: 0, rule: "line-length-limit".into(),
                    category: "style".into(), severity: cfg.severity.clone(),
                    message: format!("line is {} characters, out of limit {}", len, limit),
                });
            }
            offset += line.len() + 1;
        }
    }

    if rule_enabled(cfg, "package-comments") {
        for (idx, line) in lines.iter().enumerate() {
            let t = line.trim_start();
            if t.starts_with("package ") {
                let line_no = idx + 1;
                let prev = lines[..idx].iter().rev().find(|l| !l.trim().is_empty()).copied().unwrap_or("");
                let pkg = t.trim_start_matches("package ").split_whitespace().next().unwrap_or("");
                let ok = prev.trim_start().starts_with("// Package ") && prev.contains(pkg);
                if !ok && !is_disabled(&disabled, "package-comments", line_no) {
                    issues.push(Issue {
                        filename: filename.into(), line: line_no, column: 1, end_column: line.len() + 1,
                        offset: offset_of(text, line_no, 1), end_offset: offset_of(text, line_no, line.len() + 1),
                        rule: "package-comments".into(), category: "comments".into(),
                        severity: cfg.severity.clone(), message: "should have a package comment".into(),
                    });
                }
                break;
            }
        }
    }

    if rule_enabled(cfg, "exported") {
        for (idx, line) in lines.iter().enumerate() {
            let t = line.trim_start();
            let kind_name = if let Some(rest) = t.strip_prefix("func ") {
                rest.split(|c: char| !(c.is_ascii_alphanumeric() || c == '_')).next().map(|n| ("function", n))
            } else if let Some(rest) = t.strip_prefix("type ") {
                rest.split_whitespace().next().map(|n| ("type", n))
            } else if let Some(rest) = t.strip_prefix("var ") {
                rest.split(|c: char| !(c.is_ascii_alphanumeric() || c == '_')).next().map(|n| ("var", n))
            } else if let Some(rest) = t.strip_prefix("const ") {
                rest.split(|c: char| !(c.is_ascii_alphanumeric() || c == '_')).next().map(|n| ("const", n))
            } else {
                None
            };
            let Some((kind, name)) = kind_name else { continue };
            if !name.chars().next().map(|c| c.is_ascii_uppercase()).unwrap_or(false) {
                continue;
            }
            let line_no = idx + 1;
            let prev = lines[..idx].iter().rev().find(|l| !l.trim().is_empty()).copied().unwrap_or("");
            let ok = prev.trim_start().starts_with(&format!("// {}", name));
            if !ok && !is_disabled(&disabled, "exported", line_no) {
                issues.push(Issue {
                    filename: filename.into(), line: line_no, column: 1, end_column: line.len() + 1,
                    offset: offset_of(text, line_no, 1), end_offset: offset_of(text, line_no, line.len() + 1),
                    rule: "exported".into(), category: "comments".into(), severity: cfg.severity.clone(),
                    message: format!("exported {} {} should have comment or be unexported", kind, name),
                });
            }
        }
    }
}

fn offset_of(text: &str, line: usize, col: usize) -> usize {
    let mut off = 0;
    for (idx, l) in text.lines().enumerate() {
        if idx + 1 == line {
            return off + col.saturating_sub(1);
        }
        off += l.len() + 1;
    }
    off
}

fn disabled_lines(text: &str) -> HashMap<usize, HashSet<String>> {
    let mut map: HashMap<usize, HashSet<String>> = HashMap::new();
    let mut all = false;
    let mut rules: HashSet<String> = HashSet::new();
    for (idx, line) in text.lines().enumerate() {
        let n = idx + 1;
        if all {
            map.entry(n).or_default().insert("*".into());
        }
        for r in &rules {
            map.entry(n).or_default().insert(r.clone());
        }
        let t = line.trim();
        if let Some(rest) = t.strip_prefix("//revive:disable-next-line") {
            let rule = rest.strip_prefix(':').unwrap_or("*").trim();
            map.entry(n + 1).or_default().insert(if rule.is_empty() { "*" } else { rule }.into());
        } else if let Some(rest) = t.strip_prefix("//revive:disable") {
            if let Some(rule) = rest.strip_prefix(':') {
                rules.insert(rule.trim().into());
            } else {
                all = true;
            }
        } else if let Some(rest) = t.strip_prefix("//revive:enable") {
            if let Some(rule) = rest.strip_prefix(':') {
                rules.remove(rule.trim());
            } else {
                all = false;
                rules.clear();
            }
        }
    }
    map
}

fn is_disabled(map: &HashMap<usize, HashSet<String>>, rule: &str, line: usize) -> bool {
    map.get(&line).map(|s| s.contains("*") || s.contains(rule)).unwrap_or(false)
}

fn format_issues(formatter: &str, issues: &[Issue]) {
    match formatter {
        "json" => print_json(issues, true),
        "ndjson" => print_json(issues, false),
        "friendly" => print_friendly(issues),
        "stylish" => print_stylish(issues),
        "checkstyle" => print_checkstyle(issues),
        "plain" => print_plain(issues),
        "unix" => print_unix(issues),
        "sarif" => print_sarif(issues),
        _ => print_default(issues),
    }
}

fn print_default(issues: &[Issue]) {
    for i in issues {
        if i.column == 0 {
            println!("{}:{}: {}", i.filename, i.line, i.message);
        } else {
            println!("{}:{}:{}: {}", i.filename, i.line, i.column, i.message);
        }
    }
}

fn print_plain(issues: &[Issue]) {
    for i in sorted_plain(issues) {
        if i.column == 0 {
            println!("{}:{}: {} https://revive.run/r#{}", i.filename, i.line, i.message, i.rule);
        } else {
            println!("{}:{}:{}: {} https://revive.run/r#{}", i.filename, i.line, i.column, i.message, i.rule);
        }
    }
    if !issues.is_empty() {
        println!();
    }
}

fn print_unix(issues: &[Issue]) {
    for i in sorted_by_file_rule(issues) {
        if i.column == 0 {
            println!("{}:{}: [{}] {}", i.filename, i.line, i.rule, i.message);
        } else {
            println!("{}:{}:{}: [{}] {}", i.filename, i.line, i.column, i.rule, i.message);
        }
    }
    if !issues.is_empty() {
        println!();
    }
}

fn print_json(issues: &[Issue], array: bool) {
    if array {
        print!("[");
    }
    for (idx, i) in issues.iter().enumerate() {
        if array && idx > 0 {
            print!(",");
        }
        print!("{}", issue_json(i));
        if !array {
            println!();
        }
    }
    if array {
        println!("]");
    } else if !issues.is_empty() {
        println!();
    }
}

fn issue_json(i: &Issue) -> String {
    format!(
        "{{\"Severity\":\"{}\",\"Failure\":\"{}\",\"RuleName\":\"{}\",\"Category\":\"{}\",\"Position\":{{\"Start\":{{\"Filename\":\"{}\",\"Offset\":{},\"Line\":{},\"Column\":{}}},\"End\":{{\"Filename\":\"{}\",\"Offset\":{},\"Line\":{},\"Column\":{}}}}},\"Confidence\":1,\"ReplacementLine\":\"\"}}",
        esc(&i.severity), esc(&i.message), esc(&i.rule), esc(&i.category),
        esc(&i.filename), i.offset, i.line, i.column,
        esc(&i.filename), i.end_offset, i.line, i.end_column
    )
}

fn print_friendly(issues: &[Issue]) {
    for i in issues {
        let mark = if i.severity == "error" { "✘" } else { "⚠" };
        println!("  {}  https://revive.run/r#{}  {}", mark, i.rule, i.message);
        println!("  {}:{}:{}", i.filename, i.line, i.column);
        println!();
    }
    if !issues.is_empty() {
        let errors = issues.iter().filter(|i| i.severity == "error").count();
        let warnings = issues.len() - errors;
        println!("⚠ {} problems ({} errors, {} warnings)", issues.len(), errors, warnings);
        println!();
        if warnings > 0 {
            println!("Warnings:");
            let mut counts: Vec<(&str, usize)> = Vec::new();
            for i in issues.iter().filter(|i| i.severity != "error") {
                if let Some((_, count)) = counts.iter_mut().find(|(rule, _)| *rule == i.rule) {
                    *count += 1;
                } else {
                    counts.push((&i.rule, 1));
                }
            }
            for (rule, count) in counts {
                println!("  {}  {}", count, rule);
            }
            println!();
        }
    }
}

fn print_stylish(issues: &[Issue]) {
    let mut by_file: BTreeMap<&str, Vec<&Issue>> = BTreeMap::new();
    for i in issues {
        by_file.entry(&i.filename).or_default().push(i);
    }
    for (file, xs) in by_file {
        println!("{}", file);
        for i in xs {
            println!("  ({}, {})  https://revive.run/r#{:<18} {}", i.line, i.column, i.rule, i.message);
        }
        println!();
    }
    if !issues.is_empty() {
        let errors = issues.iter().filter(|i| i.severity == "error").count();
        let warnings = issues.len() - errors;
        println!();
        println!(" ✖ {} problems ({} errors) ({} warnings)", issues.len(), errors, warnings);
    }
}

fn print_checkstyle(issues: &[Issue]) {
    println!("<?xml version='1.0' encoding='UTF-8'?>");
    println!("<checkstyle version=\"5.0\">");
    let mut by_file: BTreeMap<&str, Vec<&Issue>> = BTreeMap::new();
    for i in sorted_plain(issues) {
        by_file.entry(&i.filename).or_default().push(i);
    }
    for (file, xs) in by_file {
        println!("    <file name=\"{}\">", xml(file));
        for i in xs {
            println!("      <error line=\"{}\" column=\"{}\" message=\"{} (confidence 1)\" severity=\"{}\" source=\"revive/{}\"/>",
                i.line, i.column, xml(&i.message), xml(&i.severity), xml(&i.rule));
        }
        println!("    </file>");
    }
    println!("</checkstyle>");
}

fn print_sarif(issues: &[Issue]) {
    print!("{{\"version\":\"2.1.0\",\"runs\":[{{\"tool\":{{\"driver\":{{\"name\":\"revive\"}}}},\"results\":[");
    for (idx, i) in issues.iter().enumerate() {
        if idx > 0 {
            print!(",");
        }
        print!("{{\"ruleId\":\"{}\",\"level\":\"{}\",\"message\":{{\"text\":\"{}\"}},\"locations\":[{{\"physicalLocation\":{{\"artifactLocation\":{{\"uri\":\"{}\"}},\"region\":{{\"startLine\":{},\"startColumn\":{}}}}}}}]}}",
            esc(&i.rule), esc(&i.severity), esc(&i.message), esc(&i.filename), i.line, i.column.max(1));
    }
    println!("]}}]}}");
}

fn sorted_plain(issues: &[Issue]) -> Vec<&Issue> {
    let mut xs: Vec<&Issue> = issues.iter().collect();
    xs.sort_by_key(|i| (i.filename.clone(), plain_rule_order(&i.rule), i.line));
    xs
}

fn sorted_by_file_rule(issues: &[Issue]) -> Vec<&Issue> {
    let mut xs: Vec<&Issue> = issues.iter().collect();
    xs.sort_by_key(|i| (i.filename.clone(), unix_rule_order(&i.rule), i.line));
    xs
}

fn plain_rule_order(rule: &str) -> usize {
    match rule {
        "exported" => 0,
        "line-length-limit" => 1,
        "package-comments" => 2,
        _ => 9,
    }
}

fn unix_rule_order(rule: &str) -> usize {
    match rule {
        "package-comments" => 0,
        "exported" => 1,
        "line-length-limit" => 2,
        _ => 9,
    }
}

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")
}

fn xml(s: &str) -> String {
    s.replace('&', "&amp;").replace('"', "&quot;").replace('<', "&lt;").replace('>', "&gt;")
}
