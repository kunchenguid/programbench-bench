use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read};
use std::path::{Path, PathBuf};
use std::process::{exit, Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

const HELP: &str = "Universal multi-language runner and REPL

Usage: executable [OPTIONS] [ARGS]...

Arguments:
  [ARGS]...  Positional arguments (language, code, or file)

Options:
  -V, --version      Print version information and exit
  -l, --lang <LANG>  Explicitly choose the language to execute
  -f, --file <PATH>  Execute code from the provided file path
  -c, --code <CODE>  Execute the provided code snippet
      --no-detect    Disable heuristic language detection
  -h, --help         Print help
";

const VERSION: &str = "run-kit 0.3.2
Universal multi-language runner and smart REPL
author: Esubalew Chekol <esubalewchekol6@gmail.com>
homepage: https://esubalew.et
repository: https://github.com/Esubaalew/run
license: Apache-2.0
commit: 0050c88 (2026-03-03T12:39:28-08:00, dirty: dirty)
built: 2026-04-17T19:59:44.418829299+00:00 [release for x86_64-unknown-linux-gnu]
rustc: rustc 1.92.0 (ded5c06cf 2025-12-08)
";

#[derive(Default)]
struct Cli {
    lang: Option<String>,
    file: Option<String>,
    code: Option<String>,
    no_detect: bool,
    args: Vec<String>,
}

fn main() {
    let cli = parse_args();
    let input = match resolve_input(&cli) {
        Ok(input) => input,
        Err(code) => exit(code),
    };

    let status = run(input);
    exit(status);
}

struct Input {
    lang: String,
    code: Option<String>,
    file: Option<String>,
}

fn parse_args() -> Cli {
    let mut cli = Cli::default();
    let mut args = env::args().skip(1).peekable();
    let mut positional_mode = false;

    while let Some(arg) = args.next() {
        if positional_mode {
            cli.args.push(arg);
            continue;
        }
        match arg.as_str() {
            "--" => positional_mode = true,
            "-h" | "--help" => {
                print!("{}", HELP);
                exit(0);
            }
            "-V" | "--version" => {
                print!("{}", VERSION);
                exit(0);
            }
            "--no-detect" => cli.no_detect = true,
            "-l" | "--lang" => cli.lang = Some(next_value(&mut args, "--lang <LANG>")),
            "-f" | "--file" => cli.file = Some(next_value(&mut args, "--file <PATH>")),
            "-c" | "--code" => cli.code = Some(next_value(&mut args, "--code <CODE>")),
            _ if arg.starts_with("--lang=") => cli.lang = Some(arg[7..].to_string()),
            _ if arg.starts_with("--file=") => cli.file = Some(arg[7..].to_string()),
            _ if arg.starts_with("--code=") => cli.code = Some(arg[7..].to_string()),
            _ if arg.starts_with('-') && arg != "-" => unexpected(&arg),
            _ => cli.args.push(arg),
        }
    }
    cli
}

fn next_value<I>(args: &mut std::iter::Peekable<I>, name: &str) -> String
where
    I: Iterator<Item = String>,
{
    match args.next() {
        Some(v) => v,
        None => {
            eprintln!("error: a value is required for '{}' but none was supplied", name);
            eprintln!();
            eprintln!("For more information, try '--help'.");
            exit(2);
        }
    }
}

fn unexpected(arg: &str) -> ! {
    eprintln!("error: unexpected argument '{}' found", arg);
    eprintln!();
    eprintln!("  tip: to pass '{}' as a value, use '-- {}'", arg, arg);
    eprintln!();
    eprintln!("Usage: executable [OPTIONS] [ARGS]...");
    eprintln!();
    eprintln!("For more information, try '--help'.");
    exit(2);
}

fn resolve_input(cli: &Cli) -> Result<Input, i32> {
    let mut code = cli.code.clone();
    let mut file = cli.file.clone();
    let mut lang = cli.lang.as_ref().map(|s| normalize_lang(s));
    let mut args = cli.args.clone();

    if let Some(explicit) = &lang {
        if !is_language_name(explicit) {
            eprintln!("Error: Unknown language '{}'. Available languages: bash, c, cpp, crystal, csharp, dart, elixir, go, groovy, haskell, java, javascript, julia, kotlin, lua, nim, perl, php, python, r, ruby, rust, swift, typescript, zig", explicit);
            return Err(1);
        }
    }

    if lang.is_none() && !cli.no_detect {
        if let Some(first) = args.first() {
            let n = normalize_lang(first);
            if is_language_name(&n) {
                lang = Some(n);
                args.remove(0);
            }
        }
    }

    if cli.code.is_some() {
        if cli.file.is_some() {
            eprintln!("Error: --code/--inline cannot be combined with --file");
            return Err(1);
        }
        if !args.is_empty() {
            eprintln!("Error: Unexpected positional arguments after specifying --code");
            return Err(1);
        }
    }

    if file.is_none() && !args.is_empty() {
        let first = args[0].clone();
        if Path::new(&first).exists() || looks_like_path(&first) {
            file = Some(first);
            args.remove(0);
        }
    }

    if code.is_none() && !args.is_empty() {
        code = Some(args.join(" "));
    }

    if code.is_none() && file.is_none() && !io::stdin().is_terminal() {
        let mut buf = String::new();
        let _ = io::stdin().read_to_string(&mut buf);
        if !buf.is_empty() {
            code = Some(buf);
        }
    }

    if lang.is_none() && !cli.no_detect {
        if let Some(path) = &file {
            lang = detect_path(path);
        }
        if lang.is_none() {
            if let Some(src) = &code {
                lang = detect_code(src);
            }
        }
    }

    Ok(Input {
        lang: lang.unwrap_or_else(|| "python".to_string()),
        code,
        file,
    })
}

fn looks_like_path(s: &str) -> bool {
    s.contains('/') || Path::new(s).extension().is_some()
}

fn normalize_lang(s: &str) -> String {
    match s.to_ascii_lowercase().as_str() {
        "rs" => "rust".to_string(),
        "py" => "python".to_string(),
        "js" | "node" => "javascript".to_string(),
        "cc" | "cxx" | "c++" => "cpp".to_string(),
        "shell" => "bash".to_string(),
        other => other.to_string(),
    }
}

fn is_language_name(s: &str) -> bool {
    matches!(
        s,
        "rust"
            | "python"
            | "go"
            | "javascript"
            | "bash"
            | "sh"
            | "c"
            | "cpp"
            | "ruby"
            | "java"
            | "crystal"
            | "csharp"
            | "dart"
            | "elixir"
            | "groovy"
            | "haskell"
            | "julia"
            | "kotlin"
            | "lua"
            | "nim"
            | "perl"
            | "php"
            | "r"
            | "swift"
            | "typescript"
            | "zig"
    )
}

fn detect_path(path: &str) -> Option<String> {
    let ext = Path::new(path).extension()?.to_str()?.to_ascii_lowercase();
    Some(match ext.as_str() {
        "rs" => "rust",
        "py" => "python",
        "go" => "go",
        "js" | "mjs" | "cjs" => "javascript",
        "sh" | "bash" => "bash",
        "c" => "c",
        "cc" | "cpp" | "cxx" | "hpp" => "cpp",
        "rb" => "ruby",
        "java" => "java",
        _ => return None,
    }
    .to_string())
}

fn detect_code(code: &str) -> Option<String> {
    let t = code.trim_start();
    if t.contains("fn main") || t.contains("println!") || t.starts_with("use std::") {
        Some("rust".to_string())
    } else if t.contains("#include") {
        if t.contains("std::") || t.contains("<iostream>") {
            Some("cpp".to_string())
        } else {
            Some("c".to_string())
        }
    } else if t.starts_with("#!/bin/bash") || t.starts_with("echo ") {
        Some("bash".to_string())
    } else {
        None
    }
}

fn run(input: Input) -> i32 {
    match input.lang.as_str() {
        "rust" => compile_and_run("rust", "main.rs", input, |src, out| {
            Command::new("rustc")
                .arg("--crate-name")
                .arg("run_snippet")
                .arg(src)
                .arg("-o")
                .arg(out)
                .status()
        }),
        "c" => compile_and_run("c", "main.c", input, |src, out| {
            Command::new("gcc").arg(src).arg("-o").arg(out).status()
        }),
        "cpp" => compile_and_run("cpp", "main.cpp", input, |src, out| {
            Command::new("g++").arg(src).arg("-o").arg(out).status()
        }),
        "bash" | "sh" => run_shell(input),
        "python" => {
            println!("python is not available in the rust-mandated arm");
            127
        }
        "go" => {
            eprintln!("Error: Go support requires the `go` executable. Install it from https://go.dev/dl/ and ensure it is on your PATH.");
            1
        }
        "java" => {
            eprintln!("Error: Java support requires the `javac` compiler. Install the JDK from https://adoptium.net/ or your vendor of choice and ensure it is on your PATH.");
            1
        }
        "perl" => run_interpreter("perl", "-e", input),
        "javascript" | "typescript" | "ruby" => 127,
        "php" => missing("PHP support requires the `php` CLI executable. Install PHP and ensure it is on your PATH."),
        "lua" => missing("Lua support requires the `lua` executable. Install it from https://www.lua.org/download.html and ensure it is on your PATH."),
        "r" => missing("R support requires the `Rscript` executable. Install R from https://cran.r-project.org/ and ensure `Rscript` is on your PATH."),
        "zig" => missing("Zig support requires the `zig` executable. Install it from https://ziglang.org/download/ and ensure it is on your PATH."),
        "crystal" => missing("Crystal support requires the `crystal` executable. Install it from https://crystal-lang.org/install/ and ensure it is on your PATH."),
        "csharp" => missing("C# support requires the `dotnet` CLI. Install the .NET SDK from https://dotnet.microsoft.com/download and ensure `dotnet` is on your PATH."),
        "dart" => missing("Dart support requires the `dart` executable. Install the Dart SDK from https://dart.dev/get-dart and ensure `dart` is on your PATH."),
        "elixir" => missing("Elixir support requires the `elixir` executable. Install Elixir from https://elixir-lang.org/install.html and ensure `elixir` is on your PATH."),
        "groovy" => missing("Groovy support requires the `groovy` executable. Install it from https://groovy-lang.org/download.html and make sure it is available on your PATH."),
        "haskell" => missing("Haskell support requires the `runghc` executable. Install the GHC toolchain from https://www.haskell.org/ghc/ (or via ghcup) and ensure `runghc` is on your PATH."),
        "julia" => missing("Julia support requires the `julia` executable. Install Julia from https://julialang.org/downloads/ and ensure `julia` is on your PATH."),
        "kotlin" => missing("Kotlin support requires the `kotlinc` compiler. Install it from https://kotlinlang.org/docs/command-line.html and ensure it is on your PATH."),
        "nim" => missing("Nim support requires the `nim` executable. Install it from https://nim-lang.org/install.html and ensure it is on your PATH."),
        "swift" => missing("Swift support requires the `swift` executable. Install Xcode command-line tools or the Swift toolchain from https://www.swift.org/download/ and ensure `swift` is on your PATH."),
        _ => {
            println!("python is not available in the rust-mandated arm");
            127
        }
    }
}

fn missing(message: &str) -> i32 {
    eprintln!("Error: {}", message);
    1
}

fn run_interpreter(program: &str, eval_flag: &str, input: Input) -> i32 {
    let mut cmd = Command::new(program);
    if let Some(file) = input.file {
        cmd.arg(file);
    } else if let Some(code) = input.code {
        cmd.arg(eval_flag).arg(code);
    } else {
        return 0;
    }
    cmd.stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()
        .ok()
        .and_then(|s| s.code())
        .unwrap_or(127)
}

fn compile_and_run<F>(prefix: &str, filename: &str, input: Input, mut build: F) -> i32
where
    F: FnMut(&Path, &Path) -> io::Result<std::process::ExitStatus>,
{
    let dir = temp_dir(prefix);
    if let Err(err) = fs::create_dir_all(&dir) {
        eprintln!("Error: {}", err);
        return 1;
    }
    let temp_src = dir.join(filename);
    let out = dir.join("main");

    let src: PathBuf;
    if let Some(path) = input.file {
        src = PathBuf::from(path);
    } else if let Some(code) = input.code {
        if let Err(err) = fs::write(&temp_src, code) {
            eprintln!("Error: {}", err);
            let _ = fs::remove_dir_all(&dir);
            return 1;
        }
        src = temp_src;
    } else {
        let _ = fs::remove_dir_all(&dir);
        return 0;
    }

    let status = match build(&src, &out) {
        Ok(status) => status,
        Err(err) => {
            eprintln!("Error: {}", err);
            let _ = fs::remove_dir_all(&dir);
            return 1;
        }
    };
    if !status.success() {
        let code = status.code().unwrap_or(1);
        let _ = fs::remove_dir_all(&dir);
        return code;
    }

    let status = Command::new(&out)
        .stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status();
    let _ = fs::remove_dir_all(&dir);
    status.ok().and_then(|s| s.code()).unwrap_or(1)
}

fn run_shell(input: Input) -> i32 {
    let mut cmd = Command::new("/usr/bin/bash");
    if let Some(file) = input.file {
        cmd.arg(file);
    } else if let Some(code) = input.code {
        cmd.arg("-c").arg(code);
    } else {
        return 0;
    }
    cmd.stdin(Stdio::inherit())
        .stdout(Stdio::inherit())
        .stderr(Stdio::inherit())
        .status()
        .ok()
        .and_then(|s| s.code())
        .unwrap_or(1)
}

fn temp_dir(prefix: &str) -> PathBuf {
    let pid = std::process::id();
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_nanos())
        .unwrap_or(0);
    env::temp_dir().join(format!("run-{}{:x}{:x}", prefix, pid, nanos & 0xffffff))
}
