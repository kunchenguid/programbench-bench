use chrono::Local;
use serde_json::json;
use std::collections::{BTreeMap, BTreeSet};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "0.2.7";

#[derive(Clone, Debug)]
struct Config {
    name: String,
    tagline: String,
    url: String,
    language: String,
    pagination: usize,
    content_path: String,
    enable_search: bool,
    footer: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            name: "Home".into(),
            tagline: String::new(),
            url: String::new(),
            language: "en".into(),
            pagination: 10,
            content_path: "content".into(),
            enable_search: false,
            footer: r#"<div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>"#.into(),
        }
    }
}

#[derive(Clone, Debug, Default)]
struct Content {
    title: String,
    slug: String,
    output: String,
    body_md: String,
    body_html: String,
    description: String,
    date: Option<String>,
    tags: Vec<String>,
    authors: Vec<String>,
    stream: Option<String>,
    series: Option<String>,
    page: bool,
    source: PathBuf,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_help();
        return;
    }
    if args.iter().any(|a| a == "-V" || a == "--version") {
        println!("marmite {}", VERSION);
        return;
    }
    if args.is_empty() {
        eprintln!("error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.");
        process::exit(2);
    }

    let mut input: Option<String> = None;
    let mut output: Option<String> = None;
    let mut config_file = "marmite.yaml".to_string();
    let mut generate_config = false;
    let mut init_site = false;
    let mut init_templates = false;
    let mut shortcodes = false;
    let mut show_urls = false;
    let mut new_title: Option<String> = None;
    let mut new_page = false;
    let mut new_tags = Vec::new();
    let mut overrides = Config::default();
    let mut force = false;

    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-v" | "--verbose" | "-vv" | "-vvv" | "-vvvv" | "--watch" | "--serve" | "--force" | "-e" => {
                if a == "--force" { force = true; }
            }
            "-p" => new_page = true,
            "-c" | "--config" => { i += 1; config_file = args.get(i).cloned().unwrap_or_else(|| die_usage("--config requires a value")); }
            "--generate-config" => generate_config = true,
            "--init-site" => init_site = true,
            "--init-templates" => init_templates = true,
            "--shortcodes" => shortcodes = true,
            "--show-urls" => show_urls = true,
            "--new" => { i += 1; new_title = Some(args.get(i).cloned().unwrap_or_else(|| die_usage("--new requires a value"))); }
            "-t" => { i += 1; new_tags = split_list(args.get(i).map(String::as_str).unwrap_or("")); }
            "--name" => { i += 1; overrides.name = args.get(i).cloned().unwrap_or_default(); }
            "--tagline" => { i += 1; overrides.tagline = args.get(i).cloned().unwrap_or_default(); }
            "--url" => { i += 1; overrides.url = args.get(i).cloned().unwrap_or_default(); }
            "--language" => { i += 1; overrides.language = args.get(i).cloned().unwrap_or_default(); }
            "--pagination" => { i += 1; overrides.pagination = args.get(i).and_then(|s| s.parse().ok()).unwrap_or(10); }
            "--enable-search" => { i += 1; overrides.enable_search = args.get(i).map(|s| s == "true").unwrap_or(false); }
            "--content-path" => { i += 1; overrides.content_path = args.get(i).cloned().unwrap_or_else(|| "content".into()); }
            "--footer" => { i += 1; overrides.footer = args.get(i).cloned().unwrap_or_default(); }
            "--bind" | "--start-theme" | "--set-theme" | "--https" | "--enable-related-content" | "--templates-path" | "--static-path" | "--media-path" | "--default-date-format" | "--colorscheme" | "--toc" | "--json-feed" | "--show-next-prev-links" | "--publish-md" | "--source-repository" | "--image-provider" | "--theme" | "--build-sitemap" | "--publish-urls-json" | "--enable-shortcodes" | "--shortcode-pattern" | "--skip-image-resize" => { i += 1; }
            _ if a.starts_with('-') => {}
            _ => {
                if input.is_none() { input = Some(a.clone()); }
                else if output.is_none() { output = Some(a.clone()); }
            }
        }
        i += 1;
    }
    let input = input.unwrap_or_else(|| die_usage("the following required arguments were not provided:\n  <INPUT_FOLDER>"));
    let input_path = PathBuf::from(&input);

    if generate_config || init_site {
        fs::create_dir_all(&input_path).unwrap_or_else(|e| die(&format!("Cannot create input folder: {e}")));
        write_config(&input_path.join(&config_file));
        eprintln!("[{} INFO  marmite::config] Config file generated: {}", Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true), input_path.join(&config_file).display());
        if generate_config && !init_site {
            return;
        }
    }
    if init_site {
        init_site_files(&input_path);
        eprintln!("[{} INFO  marmite::site] Site initialized in {}", Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true), input_path.display());
        return;
    }
    if init_templates {
        let dir = input_path.join("templates");
        fs::create_dir_all(&dir).unwrap();
        fs::write(dir.join("base.html"), "<!DOCTYPE html>\n<html>{{ content }}</html>\n").unwrap();
        return;
    }
    if let Some(title) = new_title {
        fs::create_dir_all(&input_path).unwrap_or_else(|e| die(&format!("Cannot create input folder: {e}")));
        create_new(&input_path, &title, new_page, &new_tags);
        return;
    }
    if shortcodes {
        print_shortcodes();
        return;
    }
    if !input_path.exists() {
        eprintln!("[{} ERROR marmite] Input folder does not exist: \"{}\"", Local::now().to_rfc3339_opts(chrono::SecondsFormat::Secs, true), input_path.display());
        process::exit(1);
    }

    let out = output.map(PathBuf::from).unwrap_or_else(|| input_path.join("site"));
    let mut cfg = read_config(&input_path.join(&config_file));
    apply_cli_overrides(&mut cfg, overrides);
    if show_urls {
        let contents = read_contents(&input_path, &cfg);
        println!("{}", urls_json(&contents, &cfg));
        return;
    }
    build_site(&input_path, &out, &cfg, force);
}

fn die_usage(msg: &str) -> ! {
    eprintln!("error: {msg}\n\nUsage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.");
    process::exit(2);
}

fn die(msg: &str) -> ! {
    eprintln!("{msg}");
    process::exit(1);
}

fn print_help() {
    println!(r#"Marmite is the easiest static site generator.

Usage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]

Arguments:
  <INPUT_FOLDER>   Input folder containing markdown files
  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]

Options:
  -v, --verbose...          Verbosity level (0-4)
  -w, --watch               Detect changes and rebuild the site automatically
      --serve               Serve the site with a built-in HTTP server
      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]
  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]
      --init-templates      Initialize templates in the project
      --start-theme <NAME>  Initialize a theme with templates and static assets
      --set-theme <THEME>   Download and set a theme from a remote URL or local folder
      --generate-config     Generate the configuration file
      --init-site           Init a new site with sample content and default configuration
      --force               Force the rebuild of the site even if no changes detected
      --shortcodes          List all available shortcodes
      --show-urls           Show all site URLs organized by content type
      --new <NEW>           Create a new post with the given title
  -e                        Edit the file in the default editor
  -p                        Set the new content as a page
  -t <TAGS>                 Set the tags for the new content
      --name <NAME>         Site name [default: "Home" or value from config file]
      --tagline <TAGLINE>   Site tagline
      --url <URL>           Site url
      --enable-search <BOOL> Enable search
  -h, --help                Print help
  -V, --version             Print version"#);
}

fn print_shortcodes() {
    println!(r#"Shortcodes:
Enabled: true
Pattern: <!-- \.(\w+)(?:\s+([^-][\s\S]*?))?\s*-->

Reusable blocks of content that can be used in your markdown files.
They are defined in the shortcodes/ directory and are rendered using the Tera template engine.
Check the documentation for details on how to use and create shortcodes.
================
Examples based on your configuration:
  <!-- .tags -->
  <!-- .tags param=value -->
  <!-- .socials -->
  <!-- .youtube -->
  <!-- .youtube param=value -->

Note: Replace 'param' and 'value' with actual parameter names and values.
--------------------------------
Available shortcodes:
  - authors: Display a list of all authors with post counts. Params: ord=desc, items=0
  - card: Display a card for content based on slug with optional parameter overrides
  - gallery: Display a gallery of images
  - pages: Display a list of all pages. Params: ord=asc, items=0
  - posts: Display a list of recent posts. Params: ord=desc, items=10
  - series: Display a list of all content series with post counts. Params: ord=desc, items=0
  - socials: Display social network links
  - spotify: Embed Spotify content with custom dimensions
  - streams: Display a list of all content streams with post counts. Params: ord=desc, items=0
  - tags: Display a list of all tags with post counts. Params: ord=desc, items=0
  - toc: Display table of contents for the current content
  - youtube: Embed a YouTube video"#);
}

fn write_config(path: &Path) {
    let txt = r#"name: Home
tagline: ''
url: ''
https: null
footer: <div>Powered by <a href="https://github.com/rochacbruno/marmite">Marmite</a> | <small><a href="https://creativecommons.org/licenses/by-nc-sa/4.0/">CC-BY_NC-SA</a></small></div>
language: ''
pagination: 10
pages_title: Pages
tags_title: Tags
archives_title: Archive
streams_title: Streams
series_title: Series
default_author: ''
authors_title: Authors
enable_search: false
enable_related_content: false
search_title: ''
content_path: content
site_path: ''
templates_path: templates
static_path: static
media_path: media
toc: false
json_feed: false
show_next_prev_links: true
publish_md: false
build_sitemap: true
publish_urls_json: true
"#;
    fs::write(path, txt).unwrap();
}

fn init_site_files(root: &Path) {
    let content = root.join("content");
    fs::create_dir_all(&content).unwrap();
    let today = Local::now().format("%Y-%m-%d").to_string();
    fs::write(content.join(format!("{today}-welcome.md")), "# Welcome to Marmite\n\nThis is your first post!\n\n## Edit this content\n\nedit on `content/{date}-welcome.md`\n\n## Add more content\n\ncreate new markdown files in the `content` folder\n\nuse `marmite --new` to create new content\n\n## Customize your site\n\nedit `marmite.yaml` to change site settings\n\n").unwrap();
    fs::write(content.join("_404.md"), "# Not Found").unwrap();
    fs::write(content.join("_announce.md"), "Give us a &star; on [github]").unwrap();
    fs::write(content.join("_hero.md"), "##### Welcome to Marmite\n\nMarmite is a static site generator written in Rust.\nedit `content/_hero.md` to change this content.\nremove the file to disable the hero section.\n").unwrap();
    fs::write(content.join("about.md"), "---\ntitle: About\npage: true\n---\n# About\n\nThis is a sample page.\n").unwrap();
    fs::write(root.join("custom.css"), "").unwrap();
    fs::write(root.join("custom.js"), "").unwrap();
}

fn create_new(root: &Path, title: &str, page: bool, tags: &[String]) {
    let now = Local::now();
    let slug = slugify(title);
    let name = if page {
        format!("{slug}.md")
    } else {
        format!("{}-{slug}.md", now.format("%Y-%m-%d-%H-%M-%S"))
    };
    let mut text = format!("# {title}\n");
    if page || !tags.is_empty() {
        text = "---\n".to_string() + &format!("title: {title}\n");
        if page { text.push_str("page: true\n"); }
        if !tags.is_empty() { text.push_str(&format!("tags: [{}]\n", tags.join(", "))); }
        text.push_str("---\n\n");
        text.push_str(&format!("# {title}\n"));
    }
    fs::write(root.join(&name), text).unwrap();
    println!("{}", root.join(name).display());
}

fn read_config(path: &Path) -> Config {
    let mut cfg = Config::default();
    let Ok(text) = fs::read_to_string(path) else { return cfg; };
    for line in text.lines() {
        if let Some((k, v)) = line.split_once(':') {
            let val = clean_scalar(v.trim());
            match k.trim() {
                "name" => cfg.name = val,
                "tagline" => cfg.tagline = val,
                "url" => cfg.url = val.trim_end_matches('/').to_string(),
                "language" if !val.is_empty() => cfg.language = val,
                "pagination" => cfg.pagination = val.parse().unwrap_or(10),
                "content_path" => cfg.content_path = val,
                "enable_search" => cfg.enable_search = val == "true",
                "footer" => cfg.footer = val,
                _ => {}
            }
        }
    }
    cfg
}

fn apply_cli_overrides(cfg: &mut Config, o: Config) {
    if o.name != "Home" { cfg.name = o.name; }
    if !o.tagline.is_empty() { cfg.tagline = o.tagline; }
    if !o.url.is_empty() { cfg.url = o.url.trim_end_matches('/').to_string(); }
    if o.language != "en" { cfg.language = o.language; }
    if o.pagination != 10 { cfg.pagination = o.pagination; }
    if o.content_path != "content" { cfg.content_path = o.content_path; }
    if o.enable_search { cfg.enable_search = true; }
    if !o.footer.starts_with("<div>Powered") { cfg.footer = o.footer; }
}

fn clean_scalar(v: &str) -> String {
    let mut s = v.trim().to_string();
    if s == "''" || s == "null" { return String::new(); }
    if (s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\'')) {
        s = s[1..s.len().saturating_sub(1)].to_string();
    }
    s
}

fn build_site(input: &Path, out: &Path, cfg: &Config, _force: bool) {
    fs::create_dir_all(out).unwrap();
    let contents = read_contents(input, cfg);
    write_static(out);
    let mut posts: Vec<_> = contents.iter().filter(|c| !c.page).cloned().collect();
    let mut pages: Vec<_> = contents.iter().filter(|c| c.page).cloned().collect();
    posts.sort_by(|a, b| b.date.cmp(&a.date).then(a.title.cmp(&b.title)));
    pages.sort_by(|a, b| a.title.cmp(&b.title));
    for c in &contents {
        fs::write(out.join(&c.output), render_content(c, cfg)).unwrap();
    }
    fs::write(out.join("index.html"), render_list("Welcome to Marmite", &posts, cfg, "Posts")).unwrap();
    fs::write(out.join("pages.html"), render_list("Pages", &pages, cfg, "Pages")).unwrap();
    fs::write(out.join("archive.html"), render_list("Archive", &posts, cfg, "Archive")).unwrap();
    fs::write(out.join("tags.html"), render_taxonomy("Tags", group_counts(&posts, |c| c.tags.clone()), "tag", cfg)).unwrap();
    fs::write(out.join("authors.html"), render_taxonomy("Authors", group_counts(&posts, |c| c.authors.clone()), "author", cfg)).unwrap();
    fs::write(out.join("series.html"), render_taxonomy("Series", group_counts(&posts, |c| c.series.clone().into_iter().collect()), "series", cfg)).unwrap();
    fs::write(out.join("streams.html"), render_taxonomy("Streams", group_counts(&posts, |c| c.stream.clone().into_iter().collect()), "stream", cfg)).unwrap();
    write_group_pages(out, &posts, cfg);
    fs::write(out.join("404.html"), page_shell("Not Found", "<h1>Not Found</h1>", cfg)).unwrap();
    fs::write(out.join("robots.txt"), "User-agent: Mediapartners-Google\nDisallow:\n\nUser-agent: *\nAllow: /\n").unwrap();
    fs::write(out.join("sitemap.xml"), sitemap(&contents, cfg)).unwrap();
    fs::write(out.join("urls.json"), urls_json(&contents, cfg)).unwrap();
    fs::write(out.join("marmite.json"), marmite_json(&posts, &pages, cfg)).unwrap();
}

fn read_contents(input: &Path, cfg: &Config) -> Vec<Content> {
    let content_dir = input.join(&cfg.content_path);
    let root = if content_dir.exists() { content_dir } else { input.to_path_buf() };
    let mut files = Vec::new();
    collect_md(&root, &mut files);
    files.into_iter().filter_map(|p| parse_content(&p, &root)).collect()
}

fn collect_md(dir: &Path, out: &mut Vec<PathBuf>) {
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() {
                if p.file_name().and_then(|s| s.to_str()) != Some("site") { collect_md(&p, out); }
            } else if p.extension().and_then(|s| s.to_str()) == Some("md") {
                let name = p.file_name().and_then(|s| s.to_str()).unwrap_or("");
                if !name.starts_with('_') { out.push(p); }
            }
        }
    }
}

fn parse_content(path: &Path, root: &Path) -> Option<Content> {
    let text = fs::read_to_string(path).ok()?;
    let (fm, body) = split_frontmatter(&text);
    let mut c = Content::default();
    c.source = path.to_path_buf();
    c.body_md = body.trim().to_string();
    let mut map = BTreeMap::new();
    for line in fm.lines() {
        if let Some((k, v)) = line.split_once(':') {
            map.insert(k.trim().to_string(), v.trim().to_string());
        }
    }
    let explicit_title = map.get("title").map(|s| clean_scalar(s));
    c.title = explicit_title.clone().unwrap_or_else(|| first_heading(&c.body_md).unwrap_or_else(|| path.file_stem().unwrap().to_string_lossy().to_string()));
    c.slug = map
        .get("slug")
        .map(|s| slugify(&clean_scalar(s)))
        .or_else(|| explicit_title.as_ref().map(|t| slugify(t)))
        .unwrap_or_else(|| slug_from_path(path, root, &c.title));
    c.date = map.get("date").map(|s| clean_scalar(s)).or_else(|| date_from_filename(path));
    c.page = map.get("page").map(|s| clean_scalar(s) == "true").unwrap_or(false);
    c.tags = map.get("tags").map(|s| split_list(s)).unwrap_or_default();
    c.authors = map.get("authors").map(|s| split_list(s)).unwrap_or_default();
    c.stream = map.get("stream").map(|s| clean_scalar(s)).filter(|s| !s.is_empty());
    c.series = map.get("series").map(|s| clean_scalar(s)).filter(|s| !s.is_empty());
    c.description = map.get("description").map(|s| clean_scalar(s)).unwrap_or_else(|| plain_text(&c.body_md).chars().take(180).collect());
    c.body_html = markdown_to_html(&remove_first_heading(&c.body_md));
    let prefix = c.stream.as_ref().map(|s| format!("{}-", slugify(s))).unwrap_or_default();
    c.output = format!("{}{}.html", prefix, c.slug);
    if c.page {
        c.output = format!("{}.html", c.slug);
    }
    Some(c)
}

fn split_frontmatter(text: &str) -> (&str, &str) {
    if let Some(rest) = text.strip_prefix("---\n") {
        if let Some(pos) = rest.find("\n---") {
            return (&rest[..pos], &rest[pos + 4..]);
        }
    }
    ("", text)
}

fn slug_from_path(path: &Path, root: &Path, title: &str) -> String {
    let stem = path.strip_prefix(root).unwrap_or(path).with_extension("");
    let s = stem.to_string_lossy();
    let last = s.rsplit('/').next().unwrap_or(&s);
    let without_date = if last.len() > 20
        && last.as_bytes().get(4) == Some(&b'-')
        && last.as_bytes().get(7) == Some(&b'-')
        && last.as_bytes().get(10) == Some(&b'-')
        && last.as_bytes().get(13) == Some(&b'-')
        && last.as_bytes().get(16) == Some(&b'-')
    {
        &last[20..]
    } else if last.len() > 11 && last.as_bytes().get(4) == Some(&b'-') && last.as_bytes().get(7) == Some(&b'-') {
        &last[11..]
    } else { last };
    let slug = slugify(without_date);
    if slug.is_empty() { slugify(title) } else { slug }
}

fn date_from_filename(path: &Path) -> Option<String> {
    let name = path.file_name()?.to_string_lossy();
    if name.len() >= 10 && name.as_bytes().get(4) == Some(&b'-') && name.as_bytes().get(7) == Some(&b'-') {
        Some(name[..10].to_string())
    } else { None }
}

fn first_heading(md: &str) -> Option<String> {
    md.lines().find_map(|l| l.strip_prefix("# ").map(|s| s.trim().to_string()))
}

fn remove_first_heading(md: &str) -> String {
    let mut removed = false;
    md.lines().filter(|l| {
        if !removed && l.starts_with("# ") { removed = true; false } else { true }
    }).collect::<Vec<_>>().join("\n")
}

fn markdown_to_html(md: &str) -> String {
    let mut html = String::new();
    let mut para = Vec::new();
    let mut in_ul = false;
    let mut in_code = false;
    let mut code = String::new();
    for line in md.lines() {
        let trimmed = line.trim_end();
        if trimmed.starts_with("```") {
            if in_code {
                html.push_str(&format!("<pre><code>{}</code></pre>\n", escape_html(&code)));
                code.clear();
                in_code = false;
            } else {
                flush_para(&mut html, &mut para);
                in_code = true;
            }
            continue;
        }
        if in_code {
            code.push_str(trimmed);
            code.push('\n');
            continue;
        }
        if trimmed.is_empty() {
            flush_para(&mut html, &mut para);
            if in_ul { html.push_str("</ul>\n"); in_ul = false; }
            continue;
        }
        if let Some(h) = heading_level(trimmed) {
            flush_para(&mut html, &mut para);
            if in_ul { html.push_str("</ul>\n"); in_ul = false; }
            let text = trimmed[h + 1..].trim();
            html.push_str(&format!("<h{h}>{}</h{h}>\n", inline_md(text)));
        } else if let Some(item) = trimmed.strip_prefix("- ").or_else(|| trimmed.strip_prefix("* ")) {
            flush_para(&mut html, &mut para);
            if !in_ul { html.push_str("<ul>\n"); in_ul = true; }
            html.push_str(&format!("<li>{}</li>\n", inline_md(item.trim())));
        } else {
            para.push(trimmed.to_string());
        }
    }
    flush_para(&mut html, &mut para);
    if in_ul { html.push_str("</ul>\n"); }
    html
}

fn heading_level(line: &str) -> Option<usize> {
    let n = line.chars().take_while(|&c| c == '#').count();
    if (1..=6).contains(&n) && line.chars().nth(n) == Some(' ') { Some(n) } else { None }
}

fn flush_para(html: &mut String, para: &mut Vec<String>) {
    if !para.is_empty() {
        html.push_str(&format!("<p>{}</p>\n", inline_md(&para.join("\n"))));
        para.clear();
    }
}

fn inline_md(s: &str) -> String {
    let mut out = escape_html(s);
    out = replace_pairs(&out, "**", "<strong>", "</strong>");
    out = replace_pairs(&out, "*", "<em>", "</em>");
    out = replace_pairs(&out, "`", "<code>", "</code>");
    out = replace_links(&out);
    out
}

fn replace_pairs(s: &str, pat: &str, open: &str, close: &str) -> String {
    let mut out = String::new();
    let mut rest = s;
    let mut on = true;
    while let Some(i) = rest.find(pat) {
        out.push_str(&rest[..i]);
        out.push_str(if on { open } else { close });
        on = !on;
        rest = &rest[i + pat.len()..];
    }
    out.push_str(rest);
    out
}

fn replace_links(s: &str) -> String {
    let mut out = String::new();
    let mut rest = s;
    while let Some(b) = rest.find('[') {
        if let Some(m) = rest[b..].find("](") {
            let mid = b + m;
            if let Some(e) = rest[mid + 2..].find(')') {
                out.push_str(&rest[..b]);
                let text = &rest[b + 1..mid];
                let url = &rest[mid + 2..mid + 2 + e];
                out.push_str(&format!(r#"<a href="{url}">{text}</a>"#));
                rest = &rest[mid + 3 + e..];
                continue;
            }
        }
        out.push_str(&rest[..=b]);
        rest = &rest[b + 1..];
    }
    out.push_str(rest);
    out
}

fn escape_html(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn plain_text(md: &str) -> String {
    md.replace('#', "").replace('*', "").replace('`', "").trim().to_string()
}

fn render_content(c: &Content, cfg: &Config) -> String {
    let date = c.date.clone().unwrap_or_default();
    let tags = c.tags.iter().map(|t| format!(r#"<a class="tag" href="/tag-{}.html">{}</a>"#, slugify(t), escape_html(t))).collect::<Vec<_>>().join(" ");
    let body = format!(r#"<article class="h-entry">
<data class="p-name" value="{title}"></data>
<a class="u-url" href="/{url}" style="display: none;"></a>
<div class="content-title" id="title"><h1>{title}</h1><span class="content-date"><small>{date}</small></span></div>
<div class="content-tags">{tags}</div>
<div class="content-html e-content">{html}</div>
</article>"#, title=escape_html(&c.title), url=c.output, date=escape_html(&date), tags=tags, html=c.body_html);
    page_shell(&c.title, &body, cfg)
}

fn render_list(title: &str, items: &[Content], cfg: &Config, label: &str) -> String {
    let mut body = format!(r#"<div class="list-title"><article><strong> {label} </strong></article></div><section class="content-list h-feed">"#);
    for c in items {
        body.push_str(&format!(r#"<article class="h-entry"><h2 class="p-name"><a class="u-url" href="/{}">{}</a></h2><small><time class="dt-published">{}</time></small><p>{}</p></article>"#, c.output, escape_html(&c.title), c.date.clone().unwrap_or_default(), escape_html(&c.description)));
    }
    body.push_str("</section>");
    page_shell(title, &body, cfg)
}

fn render_taxonomy(title: &str, counts: BTreeMap<String, usize>, prefix: &str, cfg: &Config) -> String {
    let mut body = format!(r#"<div class="list-title"><article><strong> {title} </strong></article></div><ul>"#);
    for (name, count) in counts {
        body.push_str(&format!(r#"<li><a href="/{}-{}.html">{}</a> <sup>{}</sup></li>"#, prefix, slugify(&name), escape_html(&name), count));
    }
    body.push_str("</ul>");
    page_shell(title, &body, cfg)
}

fn page_shell(title: &str, body: &str, cfg: &Config) -> String {
    let base = url_path(&cfg.url);
    let search = if cfg.enable_search { r##"<li><a href="#" id="search-toggle" class="secondary" title="Search (Ctrl + Shift + F)"> <span class="search-txt">Search</span><span class="search-magnifier"></span></a></li>"## } else { "" };
    let search_bar = if cfg.enable_search { r#"<div class="marmite-search-bar hidden"><button class="marmite-close-button" id="search-close">X</button><input placeholder="Search" id="marmite-search-input" /><div class="marmite-search-bar-result"><ul id="marmite-search-bar-result"></ul></div></div>"# } else { "" };
    let search_js = if cfg.enable_search { format!(r#"<script type="module" src="{base}/static/search.js"></script>"#) } else { String::new() };
    format!(r#"<!DOCTYPE html>
<html lang="{lang}">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/x-icon" href="{base}/static/favicon.ico">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="color-scheme" content="light dark" />
    <meta name="generator" content="Marmite" />
    <meta property="og:title" content="{site}">
    <meta property="og:description" content="{tagline}">
    <meta property="og:site_name" content="{site}">
    <title>{title} | {site}</title>
    <link rel="stylesheet" type="text/css" href="{base}/static/pico.min.css">
    <link rel="stylesheet" type="text/css" href="{base}/static/marmite.css">
    <link rel="stylesheet" type="text/css" href="{base}/static/custom.css">
</head>
<body>
<main class="container">
<header class="header-content"><nav class="header-nav"><ul class="header-name"><li><hgroup class="h-card"><h2><a href="{base}/" class="contrast p-name u-url">{site}</a></h2><p class="p-note">{tagline}</p></hgroup></li></ul><ul class="header-menu" id="header-menu"><li><a class="menu-item secondary" href="{base}/tags.html">Tags</a></li><li><a class="menu-item secondary" href="{base}/archive.html">Archive</a></li><li><a class="menu-item secondary" href="{base}/authors.html">Authors</a></li>{search}</ul></nav>{search_bar}</header>
<section class="main-content">{body}</section>
<footer>{footer}</footer>
</main>
{search_js}
</body>
</html>"#, lang=cfg.language, base=base, site=escape_html(&cfg.name), tagline=escape_html(&cfg.tagline), title=escape_html(title), search=search, search_bar=search_bar, body=body, footer=cfg.footer, search_js=search_js)
}

fn group_counts<F: Fn(&Content) -> Vec<String>>(items: &[Content], f: F) -> BTreeMap<String, usize> {
    let mut m = BTreeMap::new();
    for c in items {
        for v in f(c) {
            *m.entry(v).or_insert(0) += 1;
        }
    }
    m
}

fn write_group_pages(out: &Path, posts: &[Content], cfg: &Config) {
    let mut years: BTreeMap<String, Vec<Content>> = BTreeMap::new();
    for c in posts {
        if let Some(d) = &c.date { years.entry(d.chars().take(4).collect()).or_default().push(c.clone()); }
        for t in &c.tags { write_named_group(out, &format!("tag-{}", slugify(t)), &format!("Posts tagged with '{}'", t), &[c.clone()], cfg); }
        for a in &c.authors { write_named_group(out, &format!("author-{}", slugify(a)), &format!("Author: {}", a), &[c.clone()], cfg); }
        if let Some(s) = &c.series { write_named_group(out, &format!("series-{}", slugify(s)), &format!("{} series", s), &[c.clone()], cfg); }
        if let Some(s) = &c.stream { write_named_group(out, &slugify(s), &format!("Posts from '{}'", s), &[c.clone()], cfg); }
    }
    for (y, list) in years {
        write_named_group(out, &format!("archive-{y}"), &format!("Posts from '{y}'"), &list, cfg);
    }
}

fn write_named_group(out: &Path, name: &str, title: &str, items: &[Content], cfg: &Config) {
    let html = render_list(title, items, cfg, title);
    let _ = fs::write(out.join(format!("{name}.html")), html);
    let _ = fs::write(out.join(format!("{name}.rss")), rss(title, items, cfg));
    let _ = fs::write(out.join(format!("{name}-1.html")), render_list(title, items, cfg, title));
}

fn rss(title: &str, items: &[Content], cfg: &Config) -> String {
    let mut s = format!(r#"<?xml version="1.0" encoding="UTF-8"?><rss version="2.0"><channel><title>{}</title><link>{}</link>"#, escape_html(title), cfg.url);
    for c in items {
        s.push_str(&format!("<item><title>{}</title><link>{}/{}</link><description>{}</description></item>", escape_html(&c.title), cfg.url, c.output, escape_html(&c.description)));
    }
    s.push_str("</channel></rss>");
    s
}

fn sitemap(items: &[Content], cfg: &Config) -> String {
    let mut s = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n".to_string();
    s.push_str(&format!("<url><loc>{}/index.html</loc></url>\n", cfg.url));
    for c in items { s.push_str(&format!("<url><loc>{}/{}</loc></url>\n", cfg.url, c.output)); }
    s.push_str("</urlset>\n");
    s
}

fn urls_json(items: &[Content], cfg: &Config) -> String {
    let posts: Vec<String> = items.iter().filter(|c| !c.page).map(|c| format!("/{}", c.output)).collect();
    let pages: Vec<String> = items.iter().filter(|c| c.page).map(|c| format!("/{}", c.output)).collect();
    let tags: Vec<String> = items.iter().flat_map(|c| c.tags.iter()).map(|t| format!("/tag-{}.html", slugify(t))).collect::<BTreeSet<_>>().into_iter().collect();
    let authors: Vec<String> = items.iter().flat_map(|c| c.authors.iter()).map(|t| format!("/author-{}.html", slugify(t))).collect::<BTreeSet<_>>().into_iter().collect();
    let series: Vec<String> = items.iter().filter_map(|c| c.series.as_ref()).map(|t| format!("/series-{}.html", slugify(t))).collect::<BTreeSet<_>>().into_iter().collect();
    let streams: Vec<String> = items.iter().filter_map(|c| c.stream.as_ref()).map(|t| format!("/{}.html", slugify(t))).collect::<BTreeSet<_>>().into_iter().collect();
    let archives: Vec<String> = items.iter().filter_map(|c| c.date.as_ref()).map(|d| format!("/archive-{}.html", &d[..4.min(d.len())])).collect::<BTreeSet<_>>().into_iter().collect();
    serde_json::to_string_pretty(&json!({
        "posts": posts, "pages": pages, "tags": tags, "authors": authors, "series": series, "streams": streams, "archives": archives,
        "feeds": [], "pagination": [], "file_mappings": [], "misc": ["/index.html"],
        "summary": {"posts": posts.len(), "pages": pages.len(), "tags": tags.len(), "authors": authors.len(), "series": series.len(), "streams": streams.len(), "archives": archives.len(), "feeds": 0, "pagination": 0, "file_mappings": 0, "misc": 1, "total": posts.len()+pages.len()+1, "meta": {"url": cfg.url, "absolute_urls": false}}
    })).unwrap()
}

fn marmite_json(posts: &[Content], pages: &[Content], cfg: &Config) -> String {
    serde_json::to_string_pretty(&json!({
        "marmite_version": VERSION,
        "posts": posts.len(),
        "pages": pages.len(),
        "generated_at": Local::now().to_string(),
        "config": {"name": cfg.name, "tagline": cfg.tagline, "url": cfg.url, "language": cfg.language, "pagination": cfg.pagination, "content_path": cfg.content_path, "enable_search": cfg.enable_search, "footer": cfg.footer}
    })).unwrap()
}

fn write_static(out: &Path) {
    let dir = out.join("static");
    fs::create_dir_all(&dir).unwrap();
    let _ = fs::write(dir.join("marmite.css"), "body{font-family:sans-serif}.container{max-width:73ch;margin:auto}.tag{margin-right:.5rem}.header-menu{display:flex;gap:1rem;list-style:none}.content-list article{margin-bottom:1.5rem}\n");
    let _ = fs::write(dir.join("pico.min.css"), "");
    let _ = fs::write(dir.join("custom.css"), "");
    let _ = fs::write(dir.join("custom.js"), "");
    let _ = fs::write(dir.join("marmite.js"), "");
    let _ = fs::write(dir.join("search.js"), "");
    let _ = fs::write(dir.join("robots.txt"), "User-agent: *\nAllow: /\n");
    let _ = fs::write(dir.join("favicon.ico"), "");
    let _ = fs::write(dir.join("logo.png"), "");
    let _ = fs::write(dir.join("avatar-placeholder.png"), "");
    let _ = fs::write(dir.join("Atkinson-Hyperlegible-Regular-102.woff"), "");
}

fn split_list(s: &str) -> Vec<String> {
    let mut x = clean_scalar(s);
    x = x.trim_matches(['[', ']']).to_string();
    x.split(',').map(clean_scalar).map(|v| v.trim().to_string()).filter(|v| !v.is_empty()).collect()
}

fn slugify(s: &str) -> String {
    let mut out = String::new();
    let mut dash = false;
    for c in s.chars() {
        if c.is_ascii_alphanumeric() {
            out.push(c.to_ascii_lowercase());
            dash = false;
        } else if !dash {
            out.push('-');
            dash = true;
        }
    }
    out.trim_matches('-').to_string()
}

fn url_path(url: &str) -> String {
    if let Some(rest) = url.strip_prefix("https://").or_else(|| url.strip_prefix("http://")) {
        if let Some(pos) = rest.find('/') {
            let p = &rest[pos..];
            if p == "/" { String::new() } else { p.trim_end_matches('/').to_string() }
        } else { String::new() }
    } else { String::new() }
}
