use serde_json::{json, Map, Value as Json};
use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::process;

const VERSION: &str = "PHP 8.6.0-dev (cli) (built: Apr 17 2026 20:00:58) (NTS)";

#[derive(Clone, Debug)]
enum Val {
    Null,
    Bool(bool),
    Int(i64),
    Float(f64),
    Str(String),
    Array(Vec<(Key, Val)>),
}

#[derive(Clone, Debug, PartialEq, Eq, Hash)]
enum Key {
    Int(i64),
    Str(String),
}

impl Val {
    fn truthy(&self) -> bool {
        match self {
            Val::Null => false,
            Val::Bool(b) => *b,
            Val::Int(i) => *i != 0,
            Val::Float(f) => *f != 0.0,
            Val::Str(s) => !s.is_empty() && s != "0",
            Val::Array(a) => !a.is_empty(),
        }
    }
    fn as_num(&self) -> f64 {
        match self {
            Val::Int(i) => *i as f64,
            Val::Float(f) => *f,
            Val::Bool(b) => if *b { 1.0 } else { 0.0 },
            Val::Str(s) => s.trim().parse::<f64>().unwrap_or(0.0),
            _ => 0.0,
        }
    }
    fn out(&self) -> String {
        match self {
            Val::Null => String::new(),
            Val::Bool(true) => "1".into(),
            Val::Bool(false) => String::new(),
            Val::Int(i) => i.to_string(),
            Val::Float(f) => {
                let mut s = f.to_string();
                if s.ends_with(".0") { s.truncate(s.len() - 2); }
                s
            }
            Val::Str(s) => s.clone(),
            Val::Array(_) => "Array".into(),
        }
    }
}

#[derive(Clone, Debug, PartialEq)]
enum Tok {
    Var(String), Ident(String), Num(String), Str(String, bool),
    Sym(String), Eof,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    match run_cli(args) {
        Ok(code) => process::exit(code),
        Err((msg, code)) => {
            eprintln!("{msg}");
            process::exit(code);
        }
    }
}

fn run_cli(args: Vec<String>) -> Result<i32, (String, i32)> {
    let mut i = 0;
    let mut no_config = false;
    while i < args.len() {
        match args[i].as_str() {
            "-n" | "-e" | "-H" => { if args[i] == "-n" { no_config = true; } i += 1; }
            "-c" | "-d" => i += 2,
            "-h" | "--help" => { print_help(); return Ok(0); }
            "-v" | "--version" => { print_version(); return Ok(0); }
            "-m" => { print_modules(); return Ok(0); }
            "--ini" => { print_ini(no_config); return Ok(0); }
            s if s.starts_with("--ini=") => { print_ini_diff(); return Ok(0); }
            "-i" => { print_info(); return Ok(0); }
            "--rf" | "--rc" | "--re" | "--rz" | "--ri" => {
                let name = args.get(i + 1).map(String::as_str).unwrap_or("");
                print_ref(args[i].as_str(), name);
                return Ok(0);
            }
            "-r" => {
                let code = args.get(i + 1).ok_or(("Option -r requires an argument".into(), 1))?.clone();
                let rest = collect_script_args(&args[i + 2..]);
                return exec_code(&code, false, rest, "Command line code").map(|_| 0);
            }
            "-f" => {
                let file = args.get(i + 1).ok_or(("No input file specified.".into(), 1))?;
                let src = fs::read_to_string(file).map_err(|_| (format!("Could not open input file: {file}"), 1))?;
                let rest = collect_script_args(&args[i + 2..]);
                return exec_code(&src, true, rest, file).map(|_| 0);
            }
            "-S" => {
                eprintln!("PHP Development Server (http://{}/) started", args.get(i + 1).map(String::as_str).unwrap_or("127.0.0.1:8000"));
                return Ok(0);
            }
            "-t" => i += 2,
            "-B" | "-R" | "-F" | "-E" => return run_filter(&args[i..]),
            "-l" => {
                let file = args.get(i + 1).ok_or(("No input file specified.".into(), 1))?;
                if fs::read_to_string(file).is_ok() {
                    println!("No syntax errors detected in {file}");
                    return Ok(0);
                }
                eprintln!("Could not open input file: {file}");
                return Ok(1);
            }
            "-w" | "-s" => {
                let file = args.get(i + 1).ok_or(("No input file specified.".into(), 1))?;
                let src = fs::read_to_string(file).map_err(|_| (format!("Could not open input file: {file}"), 1))?;
                print!("{}", src);
                return Ok(0);
            }
            "-a" => { println!("Interactive shell"); return Ok(0); }
            "--" => {
                let code = read_stdin();
                return exec_code(&code, true, collect_script_args(&args[i + 1..]), "Standard input code").map(|_| 0);
            }
            s if s.starts_with('-') => { print_help(); return Ok(0); }
            file => {
                let src = fs::read_to_string(file).map_err(|_| (format!("Could not open input file: {file}"), 1))?;
                let rest = collect_script_args(&args[i + 1..]);
                return exec_code(&src, true, rest, file).map(|_| 0);
            }
        }
    }
    let code = read_stdin();
    exec_code(&code, true, vec![], "Standard input code").map(|_| 0)
}

fn collect_script_args(xs: &[String]) -> Vec<String> {
    let mut v = Vec::new();
    let mut start = 0;
    if xs.first().map(String::as_str) == Some("--") { start = 1; }
    v.push("Standard input code".to_string());
    v.extend(xs[start..].iter().cloned());
    v
}

fn read_stdin() -> String {
    let mut s = String::new();
    let _ = io::stdin().read_to_string(&mut s);
    s
}

fn print_help() {
    println!("Usage: executable [options] [-f] <file> [--] [args...]");
    println!("   executable [options] -r <code> [--] [args...]");
    println!("   executable [options] [-B <begin_code>] -R <code> [-E <end_code>] [--] [args...]");
    println!("   executable [options] [-B <begin_code>] -F <file> [-E <end_code>] [--] [args...]");
    println!("   executable [options] -S <addr>:<port> [-t docroot] [router]");
    println!("   executable [options] -- [args...]");
    println!("   executable [options] -a\n");
    println!("  -a               Run as interactive shell (requires readline extension)");
    println!("  -c <path>|<file> Look for php.ini file in this directory");
    println!("  -n               No configuration (ini) files will be used");
    println!("  -d foo[=bar]     Define INI entry foo with value 'bar'");
    println!("  -e               Generate extended information for debugger/profiler");
    println!("  -f <file>        Parse and execute <file>.");
    println!("  -h               This help");
    println!("  -i               PHP information");
    println!("  -l               Syntax check only (lint)");
    println!("  -m               Show compiled in modules");
    println!("  -r <code>        Run PHP <code> without using script tags <?..?>");
    println!("  -B <begin_code>  Run PHP <begin_code> before processing input lines");
    println!("  -R <code>        Run PHP <code> for every input line");
    println!("  -F <file>        Parse and execute <file> for every input line");
    println!("  -E <end_code>    Run PHP <end_code> after processing all input lines");
}

fn print_version() {
    println!("{VERSION}");
    println!("Copyright (c) The PHP Group");
    println!("Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies");
    println!("    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies");
}

fn print_modules() {
    println!("[PHP Modules]\nCore\ndate\nhash\njson\nlexbor\npcre\nrandom\nReflection\nSPL\nstandard\nuri\nZend OPcache\n\n[Zend Modules]\nZend OPcache\n");
}

fn print_ini(_n: bool) {
    println!("Configuration File (php.ini) Path: \"/usr/local/lib\"");
    println!("Loaded Configuration File:         (none)");
    println!("Scan for additional .ini files in: (none)");
    println!("Additional .ini files parsed:      (none)");
}

fn print_ini_diff() {
    println!("No INI entries differ from the built-in default");
}

fn print_info() {
    println!("phpinfo()");
    println!("PHP Version => 8.6.0-dev\n");
    println!("System => Linux");
    println!("Build Date => Apr 17 2026 20:00:58");
    println!("Build System => Linux");
    println!("Configure Command =>  './configure'  '--disable-all' '--enable-cli' '--enable-debug=no'");
    println!("Server API => Command Line Interface");
    println!("Configuration File (php.ini) Path => /usr/local/lib");
    println!("Loaded Configuration File => (none)");
    println!("Scan this dir for additional .ini files => (none)");
    println!("Additional .ini files parsed => (none)");
    println!("PHP API => 20250926");
    println!("PHP Extension => 20250926");
    println!("Zend Extension => 420250926\n");
    println!("This program makes use of the Zend Scripting Language Engine:");
    println!("Zend Engine v4.6.0-dev, Copyright (c) Zend Technologies");
    println!("    with Zend OPcache v8.6.0-dev, Copyright (c), by Zend Technologies\n");
    println!("Configuration\n\nCore\n\nPHP Version => 8.6.0-dev");
}

fn print_ref(kind: &str, name: &str) {
    match kind {
        "--rf" => {
            let ret = match name { "strlen" | "count" => "int", "json_encode" => "string|false", _ => "mixed" };
            println!("Function [ <internal:Core> function {name} ] {{\n");
            println!("  - Parameters [0] {{\n  }}");
            println!("  - Return [ {ret} ]\n}}\n");
        }
        "--re" | "--ri" => println!("{name}\n\n{name} support => enabled"),
        _ => println!("Class [ <internal:Core> class {name} ] {{\n}}\n"),
    }
}

fn run_filter(args: &[String]) -> Result<i32, (String, i32)> {
    let mut begin = None; let mut each = None; let mut end = None; let mut file_each = None; let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-B" => { begin = args.get(i+1).cloned(); i += 2; }
            "-R" => { each = args.get(i+1).cloned(); i += 2; }
            "-F" => { file_each = args.get(i+1).and_then(|p| fs::read_to_string(p).ok()); i += 2; }
            "-E" => { end = args.get(i+1).cloned(); i += 2; }
            "--" => break,
            _ => { i += 1; }
        }
    }
    let mut env = Env::new(vec!["Standard input code".into()]);
    if let Some(c) = begin { exec_inner(&c, &mut env, "Command line code")?; }
    let body = each.or(file_each).unwrap_or_default();
    for line in read_stdin().lines() {
        env.set("argn", Val::Str(line.to_string()));
        env.set("argi", Val::Int(env.line_no));
        env.line_no += 1;
        exec_inner(&body, &mut env, "Command line code")?;
    }
    if let Some(c) = end { exec_inner(&c, &mut env, "Command line code")?; }
    Ok(0)
}

fn exec_code(src: &str, strip_tags: bool, script_args: Vec<String>, file: &str) -> Result<(), (String, i32)> {
    let mut env = Env::new(script_args);
    if strip_tags {
        for seg in split_php(src) {
            match seg {
                Segment::Text(t) => print!("{t}"),
                Segment::Code(c) => exec_inner(&c, &mut env, file)?,
            }
        }
    } else {
        if src.contains("<?") {
            println!("\nParse error: syntax error, unexpected token \"<\", expecting end of file in {file} on line 1\n");
            return Err(("".into(), 255));
        }
        exec_inner(src, &mut env, file)?;
    }
    Ok(())
}

enum Segment { Text(String), Code(String) }

fn split_php(src: &str) -> Vec<Segment> {
    let mut out = Vec::new();
    let mut rest = src;
    loop {
        if let Some(p) = rest.find("<?") {
            if p > 0 { out.push(Segment::Text(rest[..p].to_string())); }
            rest = &rest[p+2..];
            if rest.starts_with("php") { rest = &rest[3..]; }
            if let Some(e) = rest.find("?>") {
                out.push(Segment::Code(rest[..e].to_string()));
                rest = &rest[e+2..];
            } else {
                out.push(Segment::Code(rest.to_string()));
                break;
            }
        } else {
            if !rest.is_empty() { out.push(Segment::Text(rest.to_string())); }
            break;
        }
    }
    out
}

#[derive(Clone)]
struct Env {
    vars: HashMap<String, Val>,
    funcs: HashMap<String, (Vec<String>, Stmt)>,
    line_no: i64,
}

impl Env {
    fn new(argv: Vec<String>) -> Self {
        let mut vars = HashMap::new();
        let arr = argv.iter().enumerate().map(|(i, s)| (Key::Int(i as i64), Val::Str(s.clone()))).collect();
        vars.insert("argv".into(), Val::Array(arr));
        vars.insert("argc".into(), Val::Int(argv.len() as i64));
        vars.insert("_SERVER".into(), Val::Array(vec![(Key::Str("argv".into()), vars["argv"].clone()), (Key::Str("argc".into()), vars["argc"].clone())]));
        Env { vars, funcs: HashMap::new(), line_no: 0 }
    }
    fn get(&self, n: &str) -> Val { self.vars.get(n).cloned().unwrap_or(Val::Null) }
    fn set(&mut self, n: &str, v: Val) { self.vars.insert(n.to_string(), v); }
}

fn exec_inner(src: &str, env: &mut Env, file: &str) -> Result<(), (String, i32)> {
    let toks = lex(src);
    let mut p = Parser { toks, pos: 0 };
    let stmts = p.parse_program();
    for s in &stmts { exec_stmt(s, env, file)?; }
    Ok(())
}

#[derive(Clone, Debug)]
enum Stmt {
    Echo(Vec<Expr>), Expr(Expr), Assign(LValue, Expr), Block(Vec<Stmt>),
    If(Expr, Box<Stmt>, Option<Box<Stmt>>), While(Expr, Box<Stmt>),
    For(Option<Box<Stmt>>, Option<Expr>, Option<Expr>, Box<Stmt>),
    Foreach(Expr, Option<String>, String, Box<Stmt>), Return(Option<Expr>), Empty,
    Func(String, Vec<String>, Box<Stmt>),
}

#[derive(Clone, Debug)]
enum LValue { Var(String), Index(String, Box<Expr>) }

#[derive(Clone, Debug)]
enum Expr {
    Val(Val), String(String, bool), Var(String), Index(Box<Expr>, Box<Expr>), Array(Vec<(Option<Expr>, Expr)>),
    Call(String, Vec<Expr>), Unary(String, Box<Expr>), Bin(Box<Expr>, String, Box<Expr>),
    Assign(LValue, Box<Expr>), PostInc(String), PostDec(String),
}

fn exec_stmt(s: &Stmt, env: &mut Env, file: &str) -> Result<Option<Val>, (String, i32)> {
    match s {
        Stmt::Echo(xs) => { for e in xs { print!("{}", eval(e, env, file)?.out()); } Ok(None) }
        Stmt::Expr(e) => { let _ = eval(e, env, file)?; Ok(None) }
        Stmt::Assign(l, e) => { let v = eval(e, env, file)?; assign(l, v, env); Ok(None) }
        Stmt::Block(ss) => { for st in ss { if let Some(v) = exec_stmt(st, env, file)? { return Ok(Some(v)); } } Ok(None) }
        Stmt::If(c, t, e) => if eval(c, env, file)?.truthy() { exec_stmt(t, env, file) } else if let Some(es) = e { exec_stmt(es, env, file) } else { Ok(None) },
        Stmt::While(c, b) => { let mut n = 0; while eval(c, env, file)?.truthy() && n < 100000 { if let Some(v)=exec_stmt(b, env, file)? { return Ok(Some(v)); } n+=1; } Ok(None) }
        Stmt::For(init, cond, post, body) => {
            if let Some(i) = init { exec_stmt(i, env, file)?; }
            let mut n = 0;
            while cond.as_ref().map(|c| eval(c, env, file).map(|v| v.truthy())).transpose()?.unwrap_or(true) && n < 100000 {
                if let Some(v) = exec_stmt(body, env, file)? { return Ok(Some(v)); }
                if let Some(p) = post { let _ = eval(p, env, file)?; }
                n += 1;
            }
            Ok(None)
        }
        Stmt::Foreach(arr, key, val, body) => {
            if let Val::Array(items) = eval(arr, env, file)? {
                for (k, v) in items {
                    if let Some(kn) = key { env.set(kn, match k { Key::Int(i)=>Val::Int(i), Key::Str(s)=>Val::Str(s) }); }
                    env.set(val, v);
                    if let Some(r) = exec_stmt(body, env, file)? { return Ok(Some(r)); }
                }
            }
            Ok(None)
        }
        Stmt::Return(e) => Ok(Some(e.as_ref().map(|x| eval(x, env, file)).transpose()?.unwrap_or(Val::Null))),
        Stmt::Empty => Ok(None),
        Stmt::Func(n, params, body) => { env.funcs.insert(n.to_ascii_lowercase(), (params.clone(), *body.clone())); Ok(None) }
    }
}

fn assign(l: &LValue, v: Val, env: &mut Env) {
    match l {
        LValue::Var(n) => env.set(n, v),
        LValue::Index(n, idx) => {
            let key_v = eval(idx, env, "").unwrap_or(Val::Null);
            let key = val_key(&key_v);
            let mut arr = match env.get(n) { Val::Array(a) => a, _ => vec![] };
            if let Some((_, old)) = arr.iter_mut().find(|(k, _)| *k == key) { *old = v; } else { arr.push((key, v)); }
            env.set(n, Val::Array(arr));
        }
    }
}

fn eval(e: &Expr, env: &mut Env, file: &str) -> Result<Val, (String, i32)> {
    Ok(match e {
        Expr::Val(v) => v.clone(),
        Expr::String(s, double) => Val::Str(if *double { interpolate(s, env) } else { s.clone() }),
        Expr::Var(n) => env.get(n),
        Expr::Index(a, i) => {
            let av = eval(a, env, file)?; let kv = val_key(&eval(i, env, file)?);
            match av { Val::Array(xs) => xs.into_iter().find(|(k,_)| *k == kv).map(|(_,v)| v).unwrap_or(Val::Null), _ => Val::Null }
        }
        Expr::Array(items) => {
            let mut out = Vec::new(); let mut next = 0;
            for (k, v) in items {
                let key = if let Some(ke) = k { val_key(&eval(ke, env, file)?) } else { let k = Key::Int(next); next += 1; k };
                if let Key::Int(i) = key { if i >= next { next = i + 1; } }
                out.push((key, eval(v, env, file)?));
            }
            Val::Array(out)
        }
        Expr::Call(name, args) => call_func(name, args, env, file)?,
        Expr::Unary(op, x) => { let v = eval(x, env, file)?; match op.as_str() { "!" => Val::Bool(!v.truthy()), "-" => Val::Int(-(v.as_num() as i64)), _ => v } }
        Expr::Bin(a, op, b) => bin(eval(a, env, file)?, op, eval(b, env, file)?),
        Expr::Assign(l, rhs) => { let v = eval(rhs, env, file)?; assign(l, v.clone(), env); v }
        Expr::PostInc(n) => { let old = env.get(n); env.set(n, Val::Int(old.as_num() as i64 + 1)); old }
        Expr::PostDec(n) => { let old = env.get(n); env.set(n, Val::Int(old.as_num() as i64 - 1)); old }
    })
}

fn val_key(v: &Val) -> Key {
    match v { Val::Int(i) => Key::Int(*i), Val::Float(f) => Key::Int(*f as i64), Val::Bool(b) => Key::Int(if *b {1} else {0}), Val::Str(s) => s.parse::<i64>().map(Key::Int).unwrap_or_else(|_| Key::Str(s.clone())), _ => Key::Str(String::new()) }
}

fn bin(a: Val, op: &str, b: Val) -> Val {
    match op {
        "." => Val::Str(format!("{}{}", a.out(), b.out())),
        "+" => if matches!(a, Val::Float(_)) || matches!(b, Val::Float(_)) { Val::Float(a.as_num()+b.as_num()) } else { Val::Int(a.as_num() as i64 + b.as_num() as i64) },
        "-" => Val::Int(a.as_num() as i64 - b.as_num() as i64),
        "*" => Val::Int(a.as_num() as i64 * b.as_num() as i64),
        "/" => Val::Float(a.as_num() / b.as_num()),
        "%" => Val::Int(a.as_num() as i64 % b.as_num() as i64),
        "==" | "===" => Val::Bool(a.out() == b.out()),
        "!=" | "!==" | "<>" => Val::Bool(a.out() != b.out()),
        "<" => Val::Bool(a.as_num() < b.as_num()),
        ">" => Val::Bool(a.as_num() > b.as_num()),
        "<=" => Val::Bool(a.as_num() <= b.as_num()),
        ">=" => Val::Bool(a.as_num() >= b.as_num()),
        "&&" | "and" => Val::Bool(a.truthy() && b.truthy()),
        "||" | "or" => Val::Bool(a.truthy() || b.truthy()),
        _ => Val::Null,
    }
}

fn call_func(name: &str, args: &[Expr], env: &mut Env, file: &str) -> Result<Val, (String, i32)> {
    let low = name.to_ascii_lowercase();
    if let Some((params, body)) = env.funcs.get(&low).cloned() {
        let vals: Vec<Val> = args.iter().map(|a| eval(a, env, file)).collect::<Result<_,_>>()?;
        let saved = env.vars.clone();
        for (i, p) in params.iter().enumerate() { env.set(p, vals.get(i).cloned().unwrap_or(Val::Null)); }
        let ret = exec_stmt(&body, env, file)?.unwrap_or(Val::Null);
        env.vars = saved;
        return Ok(ret);
    }
    if low == "var_dump" {
        for a in args { dump(&eval(a, env, file)?, 0); }
        return Ok(Val::Null);
    }
    if low == "print_r" {
        if let Some(a) = args.first() { print_r(&eval(a, env, file)?, 0); }
        return Ok(Val::Bool(true));
    }
    let vals: Vec<Val> = args.iter().map(|a| eval(a, env, file)).collect::<Result<_,_>>()?;
    Ok(match low.as_str() {
        "strlen" => Val::Int(vals.get(0).map(|v| v.out().len() as i64).unwrap_or(0)),
        "count" | "sizeof" => Val::Int(match vals.get(0) { Some(Val::Array(a)) => a.len() as i64, Some(Val::Null)|None => 0, _ => 1 }),
        "strtoupper" => Val::Str(vals.get(0).map(|v| v.out().to_uppercase()).unwrap_or_default()),
        "strtolower" => Val::Str(vals.get(0).map(|v| v.out().to_lowercase()).unwrap_or_default()),
        "trim" => Val::Str(vals.get(0).map(|v| v.out().trim().to_string()).unwrap_or_default()),
        "substr" => { let s=vals.get(0).map(|v|v.out()).unwrap_or_default(); let st=vals.get(1).map(|v|v.as_num() as usize).unwrap_or(0); let len=vals.get(2).map(|v|v.as_num() as usize).unwrap_or(s.len()); Val::Str(s.chars().skip(st).take(len).collect()) }
        "json_encode" => Val::Str(to_json(vals.get(0).unwrap_or(&Val::Null)).to_string()),
        "intval" => Val::Int(vals.get(0).map(|v|v.as_num() as i64).unwrap_or(0)),
        "strval" => Val::Str(vals.get(0).map(|v|v.out()).unwrap_or_default()),
        "is_array" => Val::Bool(matches!(vals.get(0), Some(Val::Array(_)))),
        "isset" => Val::Bool(!matches!(vals.get(0), None | Some(Val::Null))),
        "empty" => Val::Bool(vals.get(0).map(|v| !v.truthy()).unwrap_or(true)),
        "explode" => { let sep=vals.get(0).map(|v|v.out()).unwrap_or_default(); let s=vals.get(1).map(|v|v.out()).unwrap_or_default(); Val::Array(s.split(&sep).enumerate().map(|(i,x)|(Key::Int(i as i64),Val::Str(x.into()))).collect()) }
        "implode" | "join" => {
            let sep=vals.get(0).map(|v|v.out()).unwrap_or_default();
            let arr=match vals.get(1).or(vals.get(0)) { Some(Val::Array(a))=>a.iter().map(|(_,v)|v.out()).collect::<Vec<_>>().join(&sep), _=>String::new() };
            Val::Str(arr)
        }
        _ => Val::Null,
    })
}

fn to_json(v: &Val) -> Json {
    match v {
        Val::Null => Json::Null, Val::Bool(b) => json!(b), Val::Int(i) => json!(i), Val::Float(f) => json!(f), Val::Str(s) => json!(s),
        Val::Array(a) => {
            let sequential = a.iter().enumerate().all(|(i,(k,_))| *k == Key::Int(i as i64));
            if sequential { Json::Array(a.iter().map(|(_,v)|to_json(v)).collect()) } else {
                let mut m = Map::new();
                for (k,v) in a { m.insert(match k { Key::Int(i)=>i.to_string(), Key::Str(s)=>s.clone() }, to_json(v)); }
                Json::Object(m)
            }
        }
    }
}

fn dump(v: &Val, _indent: usize) {
    match v {
        Val::Null => println!("NULL"),
        Val::Bool(b) => println!("bool({})", if *b {"true"} else {"false"}),
        Val::Int(i) => println!("int({i})"),
        Val::Float(f) => println!("float({f})"),
        Val::Str(s) => println!("string({}) \"{}\"", s.len(), s),
        Val::Array(a) => { println!("array({}) {{", a.len()); for (k,v) in a { println!("  [{}]=>", key_s(k)); dump(v, 2); } println!("}}"); }
    }
}

fn print_r(v: &Val, indent: usize) {
    match v {
        Val::Array(a) => {
            println!("Array\n{}(", " ".repeat(indent));
            for (k,v) in a { print!("{}    [{}] => ", " ".repeat(indent), key_s(k)); match v { Val::Array(_) => print_r(v, indent+4), _ => println!("{}", v.out()) } }
            println!("{})", " ".repeat(indent));
        }
        _ => print!("{}", v.out()),
    }
}

fn key_s(k: &Key) -> String { match k { Key::Int(i)=>i.to_string(), Key::Str(s)=>s.clone() } }

fn interpolate(s: &str, env: &Env) -> String {
    let mut out = String::new();
    let mut it = s.chars().peekable();
    while let Some(c) = it.next() {
        if c == '$' {
            let mut n = String::new();
            while let Some(ch) = it.peek() {
                if ch.is_alphanumeric() || *ch == '_' { n.push(*ch); it.next(); } else { break; }
            }
            if n.is_empty() { out.push('$'); } else { out.push_str(&env.get(&n).out()); }
        } else { out.push(c); }
    }
    out
}

fn lex(src: &str) -> Vec<Tok> {
    let mut t = Vec::new();
    let mut it = src.chars().peekable();
    while let Some(c) = it.next() {
        if c.is_whitespace() { continue; }
        if c == '/' && it.peek() == Some(&'/') { for ch in it.by_ref() { if ch == '\n' { break; } } continue; }
        if c == '#' { for ch in it.by_ref() { if ch == '\n' { break; } } continue; }
        if c == '/' && it.peek() == Some(&'*') { it.next(); let mut prev=' '; for ch in it.by_ref() { if prev=='*' && ch=='/' { break; } prev=ch; } continue; }
        if c == '$' {
            let mut s=String::new(); while let Some(ch)=it.peek() { if ch.is_alphanumeric() || *ch=='_' { s.push(*ch); it.next(); } else { break; } }
            t.push(Tok::Var(s)); continue;
        }
        if c.is_ascii_digit() {
            let mut s=c.to_string(); while let Some(ch)=it.peek() { if ch.is_ascii_digit() || *ch=='.' { s.push(*ch); it.next(); } else { break; } }
            t.push(Tok::Num(s)); continue;
        }
        if c.is_alphabetic() || c == '_' {
            let mut s=c.to_string(); while let Some(ch)=it.peek() { if ch.is_alphanumeric() || *ch=='_' { s.push(*ch); it.next(); } else { break; } }
            t.push(Tok::Ident(s)); continue;
        }
        if c == '"' || c == '\'' {
            let quote=c; let mut s=String::new();
            while let Some(ch)=it.next() {
                if ch == quote { break; }
                if ch == '\\' {
                    if let Some(n)=it.next() { s.push(match n { 'n'=>'\n','r'=>'\r','t'=>'\t','\\'=>'\\','"'=>'"','\''=>'\'', other=>other }); }
                } else { s.push(ch); }
            }
            t.push(Tok::Str(s, quote == '"')); continue;
        }
        let mut op = c.to_string();
        if let Some(n)=it.peek() {
            let two = format!("{c}{n}");
            if ["==","!=","<=",">=","&&","||","++","--","=>","::","<>"].contains(&two.as_str()) { op=two; it.next(); }
            else if matches!(c, '='|'!' ) && *n == '=' { op.push(*n); it.next(); if it.peek()==Some(&'=') { op.push('='); it.next(); } }
        }
        t.push(Tok::Sym(op));
    }
    t.push(Tok::Eof); t
}

struct Parser { toks: Vec<Tok>, pos: usize }

impl Parser {
    fn peek(&self) -> &Tok { &self.toks[self.pos] }
    fn next(&mut self) -> Tok { let x=self.toks[self.pos].clone(); self.pos+=1; x }
    fn eat_sym(&mut self, s: &str) -> bool { if self.peek()==&Tok::Sym(s.into()) { self.pos+=1; true } else { false } }
    fn eat_ident(&mut self, s: &str) -> bool { if matches!(self.peek(), Tok::Ident(x) if x.eq_ignore_ascii_case(s)) { self.pos+=1; true } else { false } }
    fn parse_program(&mut self) -> Vec<Stmt> { let mut v=Vec::new(); while !matches!(self.peek(), Tok::Eof) { v.push(self.stmt()); } v }
    fn stmt(&mut self) -> Stmt {
        if self.eat_sym(";") { return Stmt::Empty; }
        if self.eat_sym("{") { let mut ss=Vec::new(); while !self.eat_sym("}") && !matches!(self.peek(), Tok::Eof) { ss.push(self.stmt()); } return Stmt::Block(ss); }
        if self.eat_ident("echo") { let mut xs=vec![self.expr()]; while self.eat_sym(",") { xs.push(self.expr()); } self.eat_sym(";"); return Stmt::Echo(xs); }
        if self.eat_ident("print") { let e=self.expr(); self.eat_sym(";"); return Stmt::Echo(vec![e]); }
        if self.eat_ident("if") { self.eat_sym("("); let c=self.expr(); self.eat_sym(")"); let t=self.stmt(); let e=if self.eat_ident("else") { Some(Box::new(self.stmt())) } else { None }; return Stmt::If(c, Box::new(t), e); }
        if self.eat_ident("while") { self.eat_sym("("); let c=self.expr(); self.eat_sym(")"); let b=self.stmt(); return Stmt::While(c, Box::new(b)); }
        if self.eat_ident("for") {
            self.eat_sym("(");
            let init=if self.eat_sym(";") { None } else { let st=self.simple_stmt(); self.eat_sym(";"); Some(Box::new(st)) };
            let cond=if self.eat_sym(";") { None } else { let e=self.expr(); self.eat_sym(";"); Some(e) };
            let post=if self.eat_sym(")") { None } else { let e=self.expr(); self.eat_sym(")"); Some(e) };
            let b=self.stmt(); return Stmt::For(init, cond, post, Box::new(b));
        }
        if self.eat_ident("foreach") {
            self.eat_sym("("); let arr=self.expr(); self.eat_ident("as");
            let mut key=None;
            let val=if let Tok::Var(v)=self.next() {
                if self.eat_sym("=>") { key=Some(v); if let Tok::Var(v2)=self.next(){v2}else{String::new()} } else { v }
            } else { String::new() };
            self.eat_sym(")"); let b=self.stmt(); return Stmt::Foreach(arr,key,val,Box::new(b));
        }
        if self.eat_ident("return") { let e=if self.eat_sym(";") { None } else { let x=self.expr(); self.eat_sym(";"); Some(x) }; return Stmt::Return(e); }
        if self.eat_ident("function") {
            let name = if let Tok::Ident(n) = self.next() { n } else { String::new() };
            let mut params = Vec::new();
            self.eat_sym("(");
            if !self.eat_sym(")") {
                loop {
                    if let Tok::Var(v) = self.next() { params.push(v); }
                    if self.eat_sym(")") { break; }
                    self.eat_sym(",");
                }
            }
            let body = self.stmt();
            return Stmt::Func(name, params, Box::new(body));
        }
        let st=self.simple_stmt(); self.eat_sym(";"); st
    }
    fn simple_stmt(&mut self) -> Stmt {
        if let Tok::Var(n)=self.peek().clone() {
            let save=self.pos; self.next();
            if self.eat_sym("=") { return Stmt::Assign(LValue::Var(n), self.expr()); }
            if self.eat_sym("[") { let idx=self.expr(); self.eat_sym("]"); if self.eat_sym("=") { return Stmt::Assign(LValue::Index(n, Box::new(idx)), self.expr()); } }
            self.pos=save;
        }
        Stmt::Expr(self.expr())
    }
    fn expr(&mut self) -> Expr { self.bin(0) }
    fn prec(op: &str) -> i32 { match op { "||"|"or"=>1, "&&"|"and"=>2, "=="|"==="|"!="|"!=="|"<>"=>3, "<"|">"|"<="|">="=>4, "."=>5, "+"|"-"=>6, "*"|"/"|"%"=>7, _=>-1 } }
    fn bin(&mut self, min: i32) -> Expr {
        let mut left=self.unary();
        loop {
            let op=match self.peek() { Tok::Sym(s)|Tok::Ident(s) => s.clone(), _=>break };
            if op == "=" {
                self.next();
                let lv = match left { Expr::Var(n)=>LValue::Var(n), Expr::Index(boxed, idx)=>if let Expr::Var(n)=*boxed { LValue::Index(n,idx) } else { LValue::Var(String::new()) }, _=>LValue::Var(String::new()) };
                left=Expr::Assign(lv, Box::new(self.expr()));
                continue;
            }
            let p=Self::prec(&op); if p < min { break; }
            self.next();
            let right=self.bin(p+1);
            left=Expr::Bin(Box::new(left), op, Box::new(right));
        }
        left
    }
    fn unary(&mut self) -> Expr {
        if let Tok::Sym(s)=self.peek().clone() { if s=="!" || s=="-" { self.next(); return Expr::Unary(s, Box::new(self.unary())); } }
        self.primary()
    }
    fn primary(&mut self) -> Expr {
        let mut e=match self.next() {
            Tok::Num(s) => if s.contains('.') { Expr::Val(Val::Float(s.parse().unwrap_or(0.0))) } else { Expr::Val(Val::Int(s.parse().unwrap_or(0))) },
            Tok::Str(s,d) => Expr::String(s,d),
            Tok::Var(n) => {
                if self.eat_sym("++") { Expr::PostInc(n) } else if self.eat_sym("--") { Expr::PostDec(n) } else { Expr::Var(n) }
            }
            Tok::Ident(id) => {
                let low=id.to_ascii_lowercase();
                if low == "array" && self.eat_sym("(") { Expr::Array(self.array_items(")")) }
                else if ["true","false","null"].contains(&low.as_str()) { Expr::Val(match low.as_str(){"true"=>Val::Bool(true),"false"=>Val::Bool(false),_=>Val::Null}) }
                else if self.eat_sym("(") { let args=self.args(")"); Expr::Call(id,args) }
                else { Expr::Val(Val::Str(id)) }
            }
            Tok::Sym(s) if s=="(" => { let e=self.expr(); self.eat_sym(")"); e }
            Tok::Sym(s) if s=="[" => { let a=self.array_items("]"); Expr::Array(a) }
            _ => Expr::Val(Val::Null),
        };
        loop {
            if self.eat_sym("[") { let idx=self.expr(); self.eat_sym("]"); e=Expr::Index(Box::new(e), Box::new(idx)); }
            else { break; }
        }
        e
    }
    fn args(&mut self, end: &str) -> Vec<Expr> {
        let mut a=Vec::new(); if self.eat_sym(end) { return a; }
        loop { a.push(self.expr()); if self.eat_sym(end) { break; } self.eat_sym(","); }
        a
    }
    fn array_items(&mut self, end: &str) -> Vec<(Option<Expr>, Expr)> {
        let mut a=Vec::new(); if self.eat_sym(end) { return a; }
        loop {
            let first=self.expr();
            let item=if self.eat_sym("=>") { (Some(first), self.expr()) } else { (None, first) };
            a.push(item);
            if self.eat_sym(end) { break; }
            self.eat_sym(",");
        }
        a
    }
}
