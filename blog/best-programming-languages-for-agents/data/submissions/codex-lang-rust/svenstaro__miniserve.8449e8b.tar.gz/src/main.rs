#![allow(dead_code, unused_mut)]

use base64::Engine;
use sha2::{Digest, Sha256, Sha512};
use std::cmp::Ordering;
use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::thread;
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "0.32.0";

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum SortMethod { Name, Size, Date }
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum SortOrder { Asc, Desc }
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum ColorScheme { Squirrel, Archlinux, Zenburn, Monokai }
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum MediaType { Image, Audio, Video }
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum Duplicate { Error, Overwrite, Rename }
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum SizeDisplay { Human, Exact }
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum Shell { Bash, Elvish, Fish, Powershell, Zsh }

#[derive(Debug, Clone)]
struct Args {
    path: Option<PathBuf>,
    verbose: bool,
    temp_upload_directory: Option<PathBuf>,
    index: Option<String>,
    spa: bool,
    pretty_urls: bool,
    port: u16,
    interfaces: Option<String>,
    auth: Vec<String>,
    auth_file: Option<PathBuf>,
    route_prefix: Option<String>,
    random_route: bool,
    no_symlinks: bool,
    hidden: bool,
    sort_method: SortMethod,
    sort_order: SortOrder,
    color_scheme: ColorScheme,
    color_scheme_dark: ColorScheme,
    qrcode: bool,
    upload_files: Option<String>,
    web_upload_concurrency: usize,
    chmod: Option<String>,
    directory_size: bool,
    mkdir: bool,
    media_type: Option<MediaType>,
    raw_media_type: Option<String>,
    on_duplicate_files: Duplicate,
    rm_files: Option<String>,
    enable_tar: bool,
    enable_tar_gz: bool,
    enable_zip: bool,
    compress_response: bool,
    dirs_first: bool,
    title: Option<String>,
    headers: Vec<String>,
    show_symlink_info: bool,
    hide_version_footer: bool,
    hide_theme_selector: bool,
    show_wget_footer: bool,
    print_completions: Option<Shell>,
    print_manpage: bool,
    tls_cert: Option<PathBuf>,
    tls_key: Option<PathBuf>,
    readme: bool,
    disable_indexing: bool,
    enable_webdav: bool,
    size_display: SizeDisplay,
    file_external_url: Option<String>,
}

impl Default for Args {
    fn default() -> Self {
        Self {
            path: env::var_os("MINISERVE_PATH").map(PathBuf::from),
            verbose: env_bool("MINISERVE_VERBOSE"),
            temp_upload_directory: env::var_os("MINISERVER_TEMP_UPLOAD_DIRECTORY").map(PathBuf::from),
            index: env::var("MINISERVE_INDEX").ok(),
            spa: env_bool("MINISERVE_SPA"),
            pretty_urls: env_bool("MINISERVE_PRETTY_URLS"),
            port: env::var("MINISERVE_PORT").ok().and_then(|v| v.parse().ok()).unwrap_or(8080),
            interfaces: env::var("MINISERVE_INTERFACE").ok(),
            auth: env::var("MINISERVE_AUTH").ok().into_iter().collect(),
            auth_file: env::var_os("MINISERVE_AUTH_FILE").map(PathBuf::from),
            route_prefix: env::var("MINISERVE_ROUTE_PREFIX").ok(),
            random_route: env_bool("MINISERVE_RANDOM_ROUTE"),
            no_symlinks: env_bool("MINISERVE_NO_SYMLINKS"),
            hidden: env_bool("MINISERVE_HIDDEN"),
            sort_method: parse_sort_method(&env::var("MINISERVE_DEFAULT_SORTING_METHOD").unwrap_or_else(|_| "name".into())).unwrap_or(SortMethod::Name),
            sort_order: parse_sort_order(&env::var("MINISERVE_DEFAULT_SORTING_ORDER").unwrap_or_else(|_| "desc".into())).unwrap_or(SortOrder::Desc),
            color_scheme: ColorScheme::Squirrel,
            color_scheme_dark: ColorScheme::Archlinux,
            qrcode: env_bool("MINISERVE_QRCODE"),
            upload_files: env::var("MINISERVE_ALLOWED_UPLOAD_DIR").ok(),
            web_upload_concurrency: env::var("MINISERVE_WEB_UPLOAD_CONCURRENCY").ok().and_then(|v| v.parse().ok()).unwrap_or(0),
            chmod: env::var("MINISERVE_CHMOD").ok(),
            directory_size: env_bool("MINISERVE_DIRECTORY_SIZE"),
            mkdir: env_bool("MINISERVE_MKDIR_ENABLED"),
            media_type: None,
            raw_media_type: env::var("MINISERVE_RAW_MEDIA_TYPE").ok(),
            on_duplicate_files: Duplicate::Error,
            rm_files: env::var("MINISERVE_ALLOWED_RM_DIR").ok(),
            enable_tar: env_bool("MINISERVE_ENABLE_TAR"),
            enable_tar_gz: env_bool("MINISERVE_ENABLE_TAR_GZ"),
            enable_zip: env_bool("MINISERVE_ENABLE_ZIP"),
            compress_response: env_bool("MINISERVE_COMPRESS_RESPONSE"),
            dirs_first: env_bool("MINISERVE_DIRS_FIRST"),
            title: env::var("MINISERVE_TITLE").ok(),
            headers: env::var("MINISERVE_HEADER").ok().into_iter().collect(),
            show_symlink_info: env_bool("MINISERVE_SHOW_SYMLINK_INFO"),
            hide_version_footer: env_bool("MINISERVE_HIDE_VERSION_FOOTER"),
            hide_theme_selector: env_bool("MINISERVE_HIDE_THEME_SELECTOR"),
            show_wget_footer: env_bool("MINISERVE_SHOW_WGET_FOOTER"),
            print_completions: None,
            print_manpage: false,
            tls_cert: env::var_os("MINISERVE_TLS_CERT").map(PathBuf::from),
            tls_key: env::var_os("MINISERVE_TLS_KEY").map(PathBuf::from),
            readme: env_bool("MINISERVE_README"),
            disable_indexing: env_bool("MINISERVE_DISABLE_INDEXING"),
            enable_webdav: env_bool("MINISERVE_ENABLE_WEBDAV"),
            size_display: parse_size_display(&env::var("MINISERVE_SIZE_DISPLAY").unwrap_or_else(|_| "human".into())).unwrap_or(SizeDisplay::Human),
            file_external_url: env::var("MINISERVE_FILE_EXTERNAL_URL").ok(),
        }
    }
}

impl Args {
    fn parse() -> Self {
        let mut a = Args::default();
        let mut it = env::args().skip(1).peekable();
        while let Some(arg) = it.next() {
            if arg == "--" {
                if let Some(p) = it.next() { a.path = Some(PathBuf::from(p)); }
                break;
            }
            if arg == "-h" || arg == "--help" { print_help(arg == "--help"); std::process::exit(0); }
            if arg == "-V" || arg == "--version" { println!("miniserve {}", VERSION); std::process::exit(0); }
            if !arg.starts_with('-') { a.path = Some(PathBuf::from(arg)); continue; }
            match arg.as_str() {
                "-v" | "--verbose" => a.verbose = true,
                "--spa" => a.spa = true,
                "--pretty-urls" => a.pretty_urls = true,
                "--random-route" => a.random_route = true,
                "-P" | "--no-symlinks" => a.no_symlinks = true,
                "-H" | "--hidden" => a.hidden = true,
                "-q" | "--qrcode" => a.qrcode = true,
                "-U" | "--mkdir" => a.mkdir = true,
                "-r" | "--enable-tar" => a.enable_tar = true,
                "-g" | "--enable-tar-gz" => a.enable_tar_gz = true,
                "-z" | "--enable-zip" => a.enable_zip = true,
                "-C" | "--compress-response" => a.compress_response = true,
                "-D" | "--dirs-first" => a.dirs_first = true,
                "-l" | "--show-symlink-info" => a.show_symlink_info = true,
                "-F" | "--hide-version-footer" => a.hide_version_footer = true,
                "--hide-theme-selector" => a.hide_theme_selector = true,
                "-W" | "--show-wget-footer" => a.show_wget_footer = true,
                "--readme" => a.readme = true,
                "-I" | "--disable-indexing" => a.disable_indexing = true,
                "--enable-webdav" => a.enable_webdav = true,
                "--print-manpage" => a.print_manpage = true,
                "-u" | "--upload-files" => a.upload_files = optional_value(&mut it),
                "-R" | "--rm-files" => a.rm_files = optional_value(&mut it),
                "-p" | "--port" => a.port = parse_u16(take(&mut it, &arg), "--port <PORT>"),
                "-i" | "--interfaces" => a.interfaces = Some(take(&mut it, &arg)),
                "-a" | "--auth" => a.auth.push(take(&mut it, &arg)),
                "--auth-file" => a.auth_file = Some(PathBuf::from(take(&mut it, &arg))),
                "--route-prefix" => a.route_prefix = Some(take(&mut it, &arg)),
                "--temp-directory" => a.temp_upload_directory = Some(PathBuf::from(take(&mut it, &arg))),
                "--index" => a.index = Some(take(&mut it, &arg)),
                "-S" | "--default-sorting-method" => a.sort_method = parse_sort_method_or_exit(&take(&mut it, &arg)),
                "-O" | "--default-sorting-order" => a.sort_order = parse_sort_order_or_exit(&take(&mut it, &arg)),
                "-c" | "--color-scheme" => { let _ = take(&mut it, &arg); },
                "-d" | "--color-scheme-dark" => { let _ = take(&mut it, &arg); },
                "--web-upload-files-concurrency" => a.web_upload_concurrency = take(&mut it, &arg).parse().unwrap_or(0),
                "--chmod" => a.chmod = Some(take(&mut it, &arg)),
                "-m" | "--media-type" => { let _ = take(&mut it, &arg); },
                "-M" | "--raw-media-type" => a.raw_media_type = Some(take(&mut it, &arg)),
                "-o" | "--on-duplicate-files" => a.on_duplicate_files = parse_duplicate(&take(&mut it, &arg)),
                "-t" | "--title" => a.title = Some(take(&mut it, &arg)),
                "--header" => a.headers.push(take(&mut it, &arg)),
                "--print-completions" => a.print_completions = parse_shell(&take(&mut it, &arg)),
                "--tls-cert" => a.tls_cert = Some(PathBuf::from(take(&mut it, &arg))),
                "--tls-key" => a.tls_key = Some(PathBuf::from(take(&mut it, &arg))),
                "--size-display" => a.size_display = parse_size_display(&take(&mut it, &arg)).unwrap_or(SizeDisplay::Human),
                "--file-external-url" => a.file_external_url = Some(take(&mut it, &arg)),
                _ => {
                    if let Some((k, v)) = arg.split_once('=') {
                        let mut v_it = std::iter::once(v.to_string()).peekable();
                        match k {
                            "--port" => a.port = parse_u16(v.to_string(), "--port <PORT>"),
                            "--index" => a.index = Some(v.to_string()),
                            "--auth" => a.auth.push(v.to_string()),
                            "--route-prefix" => a.route_prefix = Some(v.to_string()),
                            _ => unexpected(&arg),
                        }
                        drop(v_it);
                    } else {
                        unexpected(&arg);
                    }
                }
            }
        }
        a
    }
}

fn env_bool(name: &str) -> bool {
    env::var(name).map(|v| {
        let v = v.to_ascii_lowercase();
        !(v.is_empty() || v == "0" || v == "false" || v == "no")
    }).unwrap_or(false)
}
fn take<I: Iterator<Item=String>>(it: &mut std::iter::Peekable<I>, flag: &str) -> String {
    it.next().unwrap_or_else(|| { eprintln!("error: a value is required for '{} <VALUE>'", flag); std::process::exit(2); })
}
fn optional_value<I: Iterator<Item=String>>(it: &mut std::iter::Peekable<I>) -> Option<String> {
    if it.peek().map(|s| !s.starts_with('-')).unwrap_or(false) { it.next() } else { Some("/".into()) }
}
fn parse_u16(v: String, name: &str) -> u16 {
    v.parse().unwrap_or_else(|e| { eprintln!("error: invalid value '{}' for '{}': {}", v, name, e); eprintln!("\nFor more information, try '--help'."); std::process::exit(2); })
}
fn parse_sort_method(v: &str) -> Option<SortMethod> { match v { "name" => Some(SortMethod::Name), "size" => Some(SortMethod::Size), "date" => Some(SortMethod::Date), _ => None } }
fn parse_sort_method_or_exit(v: &str) -> SortMethod { parse_sort_method(v).unwrap_or_else(|| { eprintln!("error: invalid value '{}' for '--default-sorting-method <DEFAULT_SORTING_METHOD>'\n  [possible values: name, size, date]\n\nFor more information, try '--help'.", v); std::process::exit(2); }) }
fn parse_sort_order(v: &str) -> Option<SortOrder> { match v { "asc" => Some(SortOrder::Asc), "desc" => Some(SortOrder::Desc), _ => None } }
fn parse_sort_order_or_exit(v: &str) -> SortOrder { parse_sort_order(v).unwrap_or(SortOrder::Desc) }
fn parse_size_display(v: &str) -> Option<SizeDisplay> { match v { "human" => Some(SizeDisplay::Human), "exact" => Some(SizeDisplay::Exact), _ => None } }
fn parse_duplicate(v: &str) -> Duplicate { match v { "overwrite" => Duplicate::Overwrite, "rename" => Duplicate::Rename, _ => Duplicate::Error } }
fn parse_shell(v: &str) -> Option<Shell> { match v { "bash" => Some(Shell::Bash), "elvish" => Some(Shell::Elvish), "fish" => Some(Shell::Fish), "powershell" => Some(Shell::Powershell), "zsh" => Some(Shell::Zsh), _ => None } }
fn unexpected(arg: &str) -> ! {
    eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] [PATH]\n\nFor more information, try '--help'.", arg);
    std::process::exit(2)
}
fn print_help(long: bool) {
    println!("For when you really just want to serve some files over HTTP right now!\n");
    println!("Usage: executable [OPTIONS] [PATH]\n");
    println!("Arguments:\n  [PATH]  Which path to serve [env: MINISERVE_PATH=]\n");
    println!("Options:");
    let lines = [
        "  -v, --verbose          Be verbose, includes emitting access logs [env: MINISERVE_VERBOSE=]",
        "      --temp-directory <TEMP_UPLOAD_DIRECTORY>",
        "      --index <INDEX>    The name of a directory index file to serve, like \"index.html\" [env: MINISERVE_INDEX=]",
        "      --spa              Activate SPA (Single Page Application) mode [env: MINISERVE_SPA=]",
        "      --pretty-urls      Activate Pretty URLs mode [env: MINISERVE_PRETTY_URLS=]",
        "  -p, --port <PORT>      Port to use [env: MINISERVE_PORT=] [default: 8080]",
        "  -i, --interfaces <INTERFACES>  Interface to listen on [env: MINISERVE_INTERFACE=]",
        "  -a, --auth <AUTH>      Set authentication [env: MINISERVE_AUTH=]",
        "      --auth-file <AUTH_FILE>  Read authentication values from a file [env: MINISERVE_AUTH_FILE=]",
        "      --route-prefix <ROUTE_PREFIX>  Use a specific route prefix [env: MINISERVE_ROUTE_PREFIX=]",
        "      --random-route     Generate a random 6-hexdigit route [env: MINISERVE_RANDOM_ROUTE=]",
        "  -P, --no-symlinks      Hide symlinks in listing and prevent them from being followed",
        "  -H, --hidden           Show hidden files",
        "  -S, --default-sorting-method <DEFAULT_SORTING_METHOD> [default: name] [possible values: name, size, date]",
        "  -O, --default-sorting-order <DEFAULT_SORTING_ORDER> [default: desc] [possible values: asc, desc]",
        "  -c, --color-scheme <COLOR_SCHEME> [default: squirrel] [possible values: squirrel, archlinux, zenburn, monokai]",
        "  -d, --color-scheme-dark <COLOR_SCHEME_DARK> [default: archlinux] [possible values: squirrel, archlinux, zenburn, monokai]",
        "  -q, --qrcode           Enable QR code display",
        "  -u, --upload-files [<ALLOWED_UPLOAD_DIR>]  Enable file uploading (and optionally specify for which directory)",
        "      --web-upload-files-concurrency <WEB_UPLOAD_CONCURRENCY> [default: 0]",
        "      --chmod <CHMOD>    Set unix file permissions of uploaded files",
        "      --directory-size   Enable recursive directory size calculation",
        "  -U, --mkdir            Enable creating directories",
        "  -m, --media-type <MEDIA_TYPE> [possible values: image, audio, video]",
        "  -M, --raw-media-type <MEDIA_TYPE_RAW>",
        "  -o, --on-duplicate-files <ON_DUPLICATE_FILES> [default: error] [possible values: error, overwrite, rename]",
        "  -R, --rm-files [<ALLOWED_RM_DIR>]  Enable file and directory deletion",
        "  -r, --enable-tar       Enable uncompressed tar archive generation",
        "  -g, --enable-tar-gz    Enable gz-compressed tar archive generation",
        "  -z, --enable-zip       Enable zip archive generation",
        "  -C, --compress-response  Compress response",
        "  -D, --dirs-first       List directories first",
        "  -t, --title <TITLE>    Shown instead of host in page title and heading",
        "      --header <HEADER>  Inserts custom headers into the responses",
        "  -l, --show-symlink-info  Visualize symlinks in directory listing",
        "  -F, --hide-version-footer  Hide version footer",
        "      --hide-theme-selector  Hide theme selector",
        "  -W, --show-wget-footer  If enabled, display a wget command to recursively download the current directory",
        "      --print-completions <shell> [possible values: bash, elvish, fish, powershell, zsh]",
        "      --print-manpage    Generate man page",
        "      --tls-cert <TLS_CERT>  TLS certificate to use",
        "      --tls-key <TLS_KEY>  TLS private key to use",
        "      --readme           Enable README.md rendering in directories",
        "  -I, --disable-indexing  Disable indexing",
        "      --enable-webdav    Enable read-only WebDAV support (PROPFIND requests)",
        "      --size-display <SIZE_DISPLAY> [default: human] [possible values: human, exact]",
        "      --file-external-url <FILE_EXTERNAL_URL>",
        "  -h, --help             Print help (see more with '--help')",
        "  -V, --version          Print version",
    ];
    let max = if long { lines.len() } else { lines.len() };
    for line in lines.iter().take(max) { println!("{}", line); }
}

#[derive(Clone)]
struct Config { args: Args, root: PathBuf, prefix: String, auths: Vec<Auth> }
#[derive(Clone)]
enum AuthKind { Plain(String), Sha256(String), Sha512(String) }
#[derive(Clone)]
struct Auth { user: String, kind: AuthKind }

fn main() {
    let mut args = Args::parse();
    if args.print_manpage { print_manpage(); return; }
    if let Some(shell) = args.print_completions { println!("# completion script for {:?} is not available in this reimplementation", shell); return; }
    if args.random_route && args.route_prefix.is_none() { args.route_prefix = Some(format!("/{:06x}", (SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().subsec_nanos()) & 0xffffff)); }
    let Some(path) = args.path.clone() else {
        eprintln!("miniserve v{}", VERSION);
        eprintln!("Sun, 31 May 2026 00:00:00 +0000 [ERROR] Refusing to start as no explicit serve path was set and no interactive terminal was attached");
        eprintln!("Sun, 31 May 2026 00:00:00 +0000 [ERROR] Please set an explicit serve path like: `miniserve /my/path`");
        eprintln!("Error: Refusing to start as no explicit serve path was set and no interactive terminal was attached\nPlease set an explicit serve path like: `miniserve /my/path`");
        std::process::exit(1);
    };
    let root = fs::canonicalize(path).unwrap_or_else(|_| env::current_dir().unwrap());
    let mut auths = args.auth.iter().filter_map(|s| parse_auth(s)).collect::<Vec<_>>();
    if let Some(f) = &args.auth_file { if let Ok(txt)=fs::read_to_string(f) { for l in txt.lines() { if let Some(a)=parse_auth(l) { auths.push(a); } } } }
    let mut prefix = args.route_prefix.clone().unwrap_or_default();
    if !prefix.is_empty() && !prefix.starts_with('/') { prefix.insert(0, '/'); }
    if prefix.ends_with('/') && prefix.len() > 1 { prefix.pop(); }
    let cfg = Arc::new(Config { args: args.clone(), root: root.clone(), prefix: prefix.clone(), auths });
    let bind_host = args.interfaces.clone().unwrap_or_else(|| "0.0.0.0".to_string());
    let listener = TcpListener::bind((bind_host.as_str(), args.port)).or_else(|_| TcpListener::bind(("::", args.port))).expect("failed to bind");
    println!("miniserve v{}", VERSION);
    println!("Bound to [::]:{}, 0.0.0.0:{}", args.port, args.port);
    println!("Serving path {}", root.display());
    println!("Available at (non-exhaustive list):");
    println!("    http://127.0.0.1:{}{}", args.port, prefix);
    println!("    http://[::1]:{}{}", args.port, prefix);
    println!();
    for stream in listener.incoming().flatten() { let cfg = cfg.clone(); thread::spawn(move || { let _ = handle(stream, &cfg); }); }
}

fn parse_auth(s: &str) -> Option<Auth> {
    let parts: Vec<&str> = s.splitn(3, ':').collect();
    if parts.len() < 2 { return None; }
    let kind = if parts.len()==3 && parts[1]=="sha256" { AuthKind::Sha256(parts[2].to_string()) } else if parts.len()==3 && parts[1]=="sha512" { AuthKind::Sha512(parts[2].to_string()) } else { AuthKind::Plain(parts[1..].join(":")) };
    Some(Auth { user: parts[0].to_string(), kind })
}

struct Req { method: String, target: String, headers: HashMap<String,String>, body: Vec<u8> }

fn handle(mut stream: TcpStream, cfg: &Config) -> std::io::Result<()> {
    let mut buf = Vec::new(); let mut tmp = [0u8; 8192];
    loop { let n=stream.read(&mut tmp)?; if n==0 { break; } buf.extend_from_slice(&tmp[..n]); if find_header_end(&buf).is_some() { break; } if buf.len()>1024*1024 { break; } }
    let Some(hend)=find_header_end(&buf) else { return Ok(()); };
    let head = String::from_utf8_lossy(&buf[..hend]).to_string();
    let mut lines = head.split("\r\n"); let first = lines.next().unwrap_or("");
    let mut fp = first.split_whitespace(); let method=fp.next().unwrap_or("").to_string(); let target=fp.next().unwrap_or("/").to_string();
    let mut headers=HashMap::new(); for l in lines { if let Some((k,v))=l.split_once(':') { headers.insert(k.trim().to_ascii_lowercase(), v.trim().to_string()); } }
    let cl = headers.get("content-length").and_then(|v| v.parse::<usize>().ok()).unwrap_or(0);
    let mut body = buf[hend+4..].to_vec(); while body.len()<cl { let n=stream.read(&mut tmp)?; if n==0 { break; } body.extend_from_slice(&tmp[..n]); }
    let req=Req{method,target,headers,body};
    respond(stream, cfg, req)
}
fn find_header_end(b:&[u8])->Option<usize>{ b.windows(4).position(|w| w==b"\r\n\r\n") }

fn respond(mut s: TcpStream, cfg: &Config, req: Req) -> std::io::Result<()> {
    let mut pathq = req.target.clone(); let query = if let Some(i)=pathq.find('?') { let q=pathq[i+1..].to_string(); pathq.truncate(i); q } else { String::new() };
    let path_dec = percent_decode(&pathq);
    if !cfg.prefix.is_empty() {
        if path_dec == cfg.prefix { return redirect(&mut s, &(cfg.prefix.clone()+"/")); }
        if !path_dec.starts_with(&(cfg.prefix.clone()+"/")) { return send_text(&mut s, 404, "Not Found", "No such file or directory (os error 2)", vec![]); }
    }
    let rel_url = if cfg.prefix.is_empty() { path_dec.as_str() } else { &path_dec[cfg.prefix.len()..] };
    if !authorized(cfg, &req) { return unauthorized(&mut s, req.headers.contains_key("authorization")); }
    if req.method == "POST" && rel_url == "/upload" { return upload(&mut s, cfg, &req, &query); }
    if req.method == "POST" && rel_url == "/__miniserve_internal/api" { return api(&mut s, cfg, &req); }
    if rel_url.starts_with("/__miniserve_internal/") { return internal(&mut s, cfg, &req); }
    if req.method == "PROPFIND" && cfg.args.enable_webdav { return webdav(&mut s, cfg, rel_url); }
    if req.method != "GET" && req.method != "HEAD" { return send_text(&mut s, 405, "Method Not Allowed", "Method Not Allowed", vec![]); }
    serve_get(&mut s, cfg, rel_url, &query, req.method=="HEAD")
}

fn internal(s:&mut TcpStream, _cfg:&Config, _req:&Req)->std::io::Result<()> {
    if _req.target.contains("style.css") { send_raw(s,200,"OK",b"body{font-family:sans-serif}.container{max-width:960px;margin:auto}table{width:100%}td{padding:.25rem}".to_vec(), vec![("content-type".into(),"text/css".into())]) }
    else if _req.target.contains("favicon.svg") { send_raw(s,200,"OK",br#"<svg xmlns="http://www.w3.org/2000/svg"/>"#.to_vec(), vec![("content-type".into(),"image/svg+xml".into())]) }
    else { send_text(s,404,"Not Found","No such file or directory (os error 2)",vec![]) }
}
fn authorized(cfg:&Config, req:&Req)->bool {
    if cfg.auths.is_empty() { return true; }
    let Some(h)=req.headers.get("authorization") else { return false; };
    let Some(b64)=h.strip_prefix("Basic ") else { return false; };
    let Ok(bytes)=base64::engine::general_purpose::STANDARD.decode(b64) else { return false; };
    let Ok(pair)=String::from_utf8(bytes) else { return false; };
    let Some((u,p))=pair.split_once(':') else { return false; };
    cfg.auths.iter().any(|a| a.user==u && match &a.kind { AuthKind::Plain(x)=>x==p, AuthKind::Sha256(x)=>hex(&Sha256::digest(p.as_bytes()))==x.to_lowercase(), AuthKind::Sha512(x)=>hex(&Sha512::digest(p.as_bytes()))==x.to_lowercase() })
}
fn unauthorized(s:&mut TcpStream, had: bool)->std::io::Result<()> { if !had { send_raw(s,401,"Unauthorized",vec![],vec![("www-authenticate".into(),"Basic".into())]) } else { send_raw(s,401,"Unauthorized",error_page("401 Unauthorized","Invalid credentials for HTTP authentication").into_bytes(),vec![("www-authenticate".into(),"Basic realm=\"miniserve\"".into()),("content-type".into(),"text/html".into())]) } }

fn serve_get(s:&mut TcpStream, cfg:&Config, rel:&str, query:&str, head:bool)->std::io::Result<()> {
    if cfg.root.is_file() {
        let root_name = cfg.root.file_name().and_then(|n| n.to_str()).unwrap_or("");
        if rel == "/" || rel.trim_start_matches('/') == root_name {
            return send_file(s, &cfg.root, head, &cfg.args.headers);
        }
        return send_text(s,404,"Not Found","No such file or directory (os error 2)",vec![]);
    }
    let mut path = safe_join(&cfg.root, rel);
    if cfg.args.no_symlinks && fs::symlink_metadata(&path).map(|m| m.file_type().is_symlink()).unwrap_or(false) { return send_text(s,404,"Not Found","No such file or directory (os error 2)",vec![]); }
    if !path.exists() && cfg.args.pretty_urls && !rel.ends_with('/') { let p = safe_join(&cfg.root, &(rel.to_string()+".html")); if p.exists() { path=p; } }
    if !path.exists() && cfg.args.spa { if let Some(idx)=&cfg.args.index { let p=cfg.root.join(idx); if p.exists() { path=p; } } }
    if !path.exists() { return send_text(s,404,"Not Found","No such file or directory (os error 2)",vec![]); }
    if path.is_dir() {
        if !rel.ends_with('/') { return redirect(s, &(with_prefix(cfg, rel).trim_end_matches('/').to_string()+"/")); }
        if let Some(idx)=&cfg.args.index { let p=path.join(idx); if p.is_file() { return send_file(s, &p, head, &cfg.args.headers); } }
        if cfg.args.disable_indexing { return send_raw(s,403,"Forbidden",error_page("403 Forbidden","Directory listing is disabled").into_bytes(),vec![("content-type".into(),"text/html; charset=utf-8".into())]); }
        return listing(s,cfg,&path,rel,query,head);
    }
    send_file(s,&path,head,&cfg.args.headers)
}
fn with_prefix(cfg:&Config, rel:&str)->String{ format!("{}{}", cfg.prefix, rel) }

fn safe_join(root:&Path, rel:&str)->PathBuf { let mut p=root.to_path_buf(); for c in rel.trim_start_matches('/').split('/') { let d=percent_decode(c); if d.is_empty()||d=="."||d==".." { continue; } p.push(d); } p }

fn listing(s:&mut TcpStream, cfg:&Config, dir:&Path, rel:&str, query:&str, head:bool)->std::io::Result<()> {
    let mut sort=cfg.args.sort_method; let mut order=cfg.args.sort_order; for (k,v) in parse_query(query) { if k=="sort" { sort=match v.as_str(){"size"=>SortMethod::Size,"date"=>SortMethod::Date,_=>SortMethod::Name}; } if k=="order" { order=if v=="asc"{SortOrder::Asc}else{SortOrder::Desc}; } }
    let mut ents=Vec::new();
    if let Ok(rd)=fs::read_dir(dir) { for e in rd.flatten() { let name=e.file_name().to_string_lossy().to_string(); if !cfg.args.hidden && name.starts_with('.') { continue; } if cfg.args.no_symlinks && e.file_type().map(|ft|ft.is_symlink()).unwrap_or(false) { continue; } if let Ok(md)=e.metadata() { ents.push((name, md.is_dir(), md.len(), md.modified().unwrap_or(UNIX_EPOCH))); } } }
    ents.sort_by(|a,b| { let mut o = if cfg.args.dirs_first && a.1 != b.1 { if a.1 { Ordering::Less } else { Ordering::Greater } } else { match sort { SortMethod::Name => natcmp(&a.0,&b.0), SortMethod::Size => a.2.cmp(&b.2), SortMethod::Date => a.3.cmp(&b.3) } }; if order==SortOrder::Desc { o=o.reverse(); } o });
    let title=cfg.args.title.clone().unwrap_or_else(|| "127.0.0.1".into()); let mut html=format!("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><link rel=\"stylesheet\" href=\"{}__miniserve_internal/style.css\"><title>{}</title></head><body id=\"drop-container\"><div class=\"container\"><h1 class=\"title\"><span><bdi>{}</bdi></span>{}</h1><table><thead><tr><th class=\"name\"><a href=\"?sort=name&amp;order=asc\">Name</a></th><th class=\"size\"><a href=\"?sort=size&amp;order=asc\">Size</a></th><th class=\"date\"><a href=\"?sort=date&amp;order=asc\">Last modification</a></th></tr></thead><tbody>", cfg.prefix_with_slash(), esc(&title), esc(&title), esc(rel));
    if rel != "/" { html.push_str("<tr class=\"entry-type-directory\"><td><p><a class=\"directory\" href=\"../\">../</a></p></td><td></td><td></td></tr>"); }
    for (name,is_dir,size,mtime) in ents { let disp=if is_dir{format!("{}/",name)}else{name.clone()}; let href=format!("{}{}{}", cfg.args.file_external_url.clone().unwrap_or_else(|| cfg.prefix.clone()), rel.trim_end_matches('/'), format!("/{}{}", urlenc(&name), if is_dir{"/"}else{""})); html.push_str(&format!("<tr class=\"entry-type-{}\"><td><p><a class=\"{}\" href=\"{}\">{}</a></p></td><td class=\"size-cell\">{}</td><td class=\"date-cell\"><span>{}</span></td></tr>", if is_dir{"directory"}else{"file"}, if is_dir{"directory"}else{"file"}, href, esc(&disp), if is_dir{"".into()}else{size_fmt(size,cfg.args.size_display)}, date_fmt(mtime))); }
    html.push_str("</tbody></table>");
    if cfg.args.upload_files.is_some() { html.push_str("<form action=\"/upload?path=/\" method=\"post\" enctype=\"multipart/form-data\"><input type=\"file\" name=\"path\"><button>Upload</button></form>"); }
    if !cfg.args.hide_version_footer { html.push_str(&format!("<div class=\"footer\"><div class=\"version\"><a href=\"https://github.com/svenstaro/miniserve\">miniserve</a>/{}</div></div>", VERSION)); }
    html.push_str("</div></body></html>");
    if head { send_raw(s,200,"OK",vec![],vec![("content-length".into(),html.len().to_string()),("content-type".into(),"text/html; charset=utf-8".into())]) } else { send_raw(s,200,"OK",html.into_bytes(),vec![("content-type".into(),"text/html; charset=utf-8".into())]) }
}
trait PrefixSlash { fn prefix_with_slash(&self)->String; }
impl PrefixSlash for Config { fn prefix_with_slash(&self)->String { if self.prefix.is_empty(){"/".into()} else {format!("{}/", self.prefix.trim_end_matches('/'))} } }

fn send_file(s:&mut TcpStream, path:&Path, head:bool, custom:&[String])->std::io::Result<()> { let data=fs::read(path).unwrap_or_default(); let name=path.file_name().and_then(|x|x.to_str()).unwrap_or("file"); let mut headers=vec![("content-type".into(), mime(path).into()), ("content-disposition".into(), format!("inline; filename=\"{}\"", name)), ("accept-ranges".into(),"bytes".into())]; for h in custom { if let Some((k,v))=h.split_once(':') { headers.push((k.trim().into(), v.trim().into())); } } if head { headers.push(("content-length".into(),data.len().to_string())); send_raw(s,200,"OK",vec![],headers) } else { send_raw(s,200,"OK",data,headers) } }
fn upload(s:&mut TcpStream, cfg:&Config, req:&Req, query:&str)->std::io::Result<()> { if cfg.args.upload_files.is_none(){return send_text(s,405,"Method Not Allowed","Upload not allowed",vec![])}; let q=parse_query(query); let base=q.get("path").cloned().unwrap_or_else(||"/".into()); let dir=safe_join(&cfg.root,&base); let ct=req.headers.get("content-type").cloned().unwrap_or_default(); if let Some(b)=ct.split("boundary=").nth(1) { parse_multipart(&req.body,b,&dir,cfg); } redirect(s,&with_prefix(cfg,&base)) }
fn parse_multipart(body:&[u8], boundary:&str, dir:&Path, cfg:&Config){ let marker=format!("--{}", boundary); let s=String::from_utf8_lossy(body); for part in s.split(&marker).skip(1) { if !part.contains("filename=") { continue; } let Some((head,rest))=part.split_once("\r\n\r\n") else {continue}; let fname=head.split("filename=\"").nth(1).and_then(|x|x.split('"').next()).unwrap_or("upload.bin"); let mut bytes=rest.as_bytes().to_vec(); while bytes.ends_with(b"\r\n") { bytes.truncate(bytes.len()-2); } if bytes.ends_with(b"--") { bytes.truncate(bytes.len()-2); } let mut path=dir.join(clean_name(fname)); if path.exists() { match cfg.args.on_duplicate_files { Duplicate::Error=>continue, Duplicate::Overwrite=>{}, Duplicate::Rename=>{ path=rename_path(&path); } } } let _=fs::create_dir_all(dir); let _=fs::write(path,bytes); } }
fn rename_path(path:&Path)->PathBuf{ for i in 1..10000 { let stem=path.file_stem().and_then(|s|s.to_str()).unwrap_or("file"); let ext=path.extension().and_then(|s|s.to_str()).map(|e|format!(".{}",e)).unwrap_or_default(); let p=path.with_file_name(format!("{}-{}{}",stem,i,ext)); if !p.exists(){return p;} } path.to_path_buf() }
fn api(s:&mut TcpStream, cfg:&Config, req:&Req)->std::io::Result<()> { let body=String::from_utf8_lossy(&req.body); if body.contains("DirSize") { return send_text(s,200,"OK","-",vec![]); } if body.contains("Mkdir") && cfg.args.mkdir { if let Some(p)=extract_json_path(&body) { let _=fs::create_dir_all(safe_join(&cfg.root,&p)); } return send_text(s,200,"OK","",vec![]); } if body.contains("Rm") && cfg.args.rm_files.is_some() { if let Some(p)=extract_json_path(&body) { let target=safe_join(&cfg.root,&p); let _=if target.is_dir(){fs::remove_dir_all(target)}else{fs::remove_file(target)}; } return send_text(s,200,"OK","",vec![]); } send_text(s,400,"Bad Request","Bad Request",vec![]) }
fn extract_json_path(s:&str)->Option<String>{ if let Some(i)=s.find("path") { return s[i..].split(':').nth(1).map(|x|x.trim_matches(|c| c==' '||c=='"'||c=='}'||c=='{').to_string()); } s.split(':').nth(1).map(|x|x.trim_matches(|c| c==' '||c=='"'||c=='}'||c=='{').to_string()) }
fn webdav(s:&mut TcpStream,_cfg:&Config,rel:&str)->std::io::Result<()> { let xml=format!("<?xml version=\"1.0\"?><D:multistatus xmlns:D=\"DAV:\"><D:response><D:href>{}</D:href><D:propstat><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response></D:multistatus>", esc(rel)); send_raw(s,207,"Multi-Status",xml.into_bytes(),vec![("content-type".into(),"application/xml".into())]) }

fn send_text(s:&mut TcpStream, code:u16, reason:&str, txt:&str, headers:Vec<(String,String)>)->std::io::Result<()> { let mut h=headers; h.push(("content-type".into(),"text/plain; charset=utf-8".into())); send_raw(s,code,reason,txt.as_bytes().to_vec(),h) }
fn redirect(s:&mut TcpStream, loc:&str)->std::io::Result<()> { send_raw(s,303,"See Other",vec![],vec![("location".into(),loc.into())]) }
fn send_raw(s:&mut TcpStream, code:u16, reason:&str, body:Vec<u8>, mut headers:Vec<(String,String)>)->std::io::Result<()> { if !headers.iter().any(|(k,_)| k.eq_ignore_ascii_case("content-length")) { headers.insert(0,("content-length".into(),body.len().to_string())); } write!(s,"HTTP/1.1 {} {}\r\n",code,reason)?; for (k,v) in headers { write!(s,"{}: {}\r\n",k,v)?; } write!(s,"\r\n")?; s.write_all(&body) }

fn mime(p:&Path)->&'static str{ match p.extension().and_then(|s|s.to_str()).unwrap_or("").to_ascii_lowercase().as_str(){"html"|"htm"=>"text/html; charset=utf-8","txt"|"md"|"rs"|"toml"=>"text/plain; charset=utf-8","css"=>"text/css","js"=>"application/javascript","json"=>"application/json","svg"=>"image/svg+xml","png"=>"image/png","jpg"|"jpeg"=>"image/jpeg","gif"=>"image/gif","pdf"=>"application/pdf",_=>"application/octet-stream"} }
fn esc(s:&str)->String{s.replace('&',"&amp;").replace('<',"&lt;").replace('>',"&gt;").replace('"',"&quot;")}
fn percent_decode(s:&str)->String{ let bytes=s.as_bytes(); let mut out=Vec::new(); let mut i=0; while i<bytes.len(){ if bytes[i]==b'%'&&i+2<bytes.len(){ if let Ok(v)=u8::from_str_radix(&s[i+1..i+3],16){out.push(v); i+=3; continue;} } if bytes[i]==b'+'{out.push(b' ')}else{out.push(bytes[i])}; i+=1;} String::from_utf8_lossy(&out).into() }
fn urlenc(s:&str)->String{ s.bytes().map(|b| if b.is_ascii_alphanumeric()||b"-_.~".contains(&b){(b as char).to_string()}else{format!("%{:02X}",b)}).collect() }
fn parse_query(q:&str)->HashMap<String,String>{ let mut m=HashMap::new(); for p in q.split('&'){ if let Some((k,v))=p.split_once('='){m.insert(percent_decode(k),percent_decode(v));}} m }
fn size_fmt(n:u64, disp:SizeDisplay)->String{ if disp==SizeDisplay::Exact { return n.to_string(); } if n<1024 { format!("{} B",n) } else if n<1024*1024 { format!("{:.1} KiB", n as f64/1024.0) } else { format!("{:.1} MiB", n as f64/1024.0/1024.0) } }
fn date_fmt(t:SystemTime)->String{ let secs=t.duration_since(UNIX_EPOCH).unwrap_or_default().as_secs(); format!("{}", secs) }
fn natcmp(a:&str,b:&str)->Ordering{ a.to_ascii_lowercase().cmp(&b.to_ascii_lowercase()) }
fn clean_name(s:&str)->String{ s.replace('/',"_").replace('\\',"_") }
fn hex(bytes:&[u8])->String{ bytes.iter().map(|b|format!("{:02x}",b)).collect() }
fn error_page(t:&str,msg:&str)->String{ format!("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>{}</title></head><body><div class=\"error\"><p>{}</p><p>{}</p><div class=\"error-nav\"><a class=\"error-back\" href=\"/\">Go back to file listing</a></div><p class=\"footer\"><div class=\"version\"><a href=\"https://github.com/svenstaro/miniserve\">miniserve</a>/{}</div></p></div></body></html>",t,t,msg,VERSION) }
fn print_manpage(){ println!(".TH miniserve 1  \"miniserve {}\"\n.SH NAME\nminiserve \\- For when you really just want to serve some files over HTTP right now!\n.SH SYNOPSIS\nminiserve [OPTIONS] [PATH]\n.SH DESCRIPTION\nFor when you really just want to serve some files over HTTP right now!", VERSION); }
