use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::path::{Path, PathBuf};

use url::Url;

#[derive(Debug, Clone)]
enum Node {
    Text(String),
    Elem(Element),
}

#[derive(Debug, Clone)]
struct Element {
    tag: String,
    attrs: HashMap<String, String>,
    children: Vec<Node>,
}

#[derive(Debug, Clone)]
struct Config {
    input: Option<String>,
    output: Option<String>,
    overwrite: bool,
    domain: Option<String>,
    include: Option<String>,
    exclude: Option<String>,
    strong: String,
    table: bool,
    strike: bool,
    table_header_promotion: bool,
    table_skip_empty_rows: bool,
    table_presentation: bool,
    table_span: String,
    table_pad: String,
    table_newline: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            input: None,
            output: None,
            overwrite: false,
            domain: None,
            include: None,
            exclude: None,
            strong: "**".to_string(),
            table: false,
            strike: false,
            table_header_promotion: false,
            table_skip_empty_rows: false,
            table_presentation: false,
            table_span: "empty".to_string(),
            table_pad: "aligned".to_string(),
            table_newline: "skip".to_string(),
        }
    }
}

fn main() {
    let cfg = match parse_args() {
        Ok(ParseResult::Run(c)) => c,
        Ok(ParseResult::Exit) => return,
        Err(e) => {
            eprintln!("\nerror: {}\n", e);
            std::process::exit(1);
        }
    };

    if let Err(e) = run(cfg) {
        eprintln!("\nerror: {}", e);
        std::process::exit(1);
    }
}

enum ParseResult {
    Run(Config),
    Exit,
}

fn parse_args() -> Result<ParseResult, String> {
    let mut cfg = Config::default();
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        let (key, val_inline) = if let Some((k, v)) = arg.split_once('=') {
            (k.to_string(), Some(v.to_string()))
        } else {
            (arg.clone(), None)
        };
        let mut next_val = |name: &str| -> Result<String, String> {
            if let Some(v) = val_inline.clone() {
                Ok(v)
            } else {
                args.next().ok_or_else(|| format!("missing value for {}", name))
            }
        };
        match key.as_str() {
            "-v" | "--version" => {
                print_version();
                return Ok(ParseResult::Exit);
            }
            "--help" => {
                print_help();
                return Ok(ParseResult::Exit);
            }
            "--input" => cfg.input = Some(next_val("--input")?),
            "--output" => cfg.output = Some(next_val("--output")?),
            "--output-overwrite" => cfg.overwrite = true,
            "--domain" => cfg.domain = Some(next_val("--domain")?),
            "--exclude-selector" => cfg.exclude = Some(next_val("--exclude-selector")?),
            "--include-selector" => cfg.include = Some(next_val("--include-selector")?),
            "--opt-strong-delimiter" => {
                let v = next_val("--opt-strong-delimiter")?;
                if v != "**" && v != "__" {
                    return Err(format!(
                        "invalid value for --opt-strong-delimiter=\"{}\" must be exactly 2 characters of \"**\" or \"__\"",
                        v
                    ));
                }
                cfg.strong = v;
            }
            "--plugin-table" => cfg.table = true,
            "--plugin-strikethrough" => cfg.strike = true,
            "--opt-table-header-promotion" => cfg.table_header_promotion = val_inline.clone().map(parse_bool).transpose()?.unwrap_or(true),
            "--opt-table-presentation-tables" => cfg.table_presentation = val_inline.clone().map(parse_bool).transpose()?.unwrap_or(true),
            "--opt-table-skip-empty-rows" => cfg.table_skip_empty_rows = val_inline.clone().map(parse_bool).transpose()?.unwrap_or(true),
            "--opt-table-cell-padding-behavior" => {
                let v = next_val(&key)?;
                if !["aligned", "minimal", "none"].contains(&v.as_str()) {
                    return Err(format!("invalid value for {}=\"{}\"", key, v));
                }
                cfg.table_pad = v;
            }
            "--opt-table-newline-behavior" => {
                let v = next_val(&key)?;
                if !["skip", "preserve"].contains(&v.as_str()) {
                    return Err(format!("invalid value for {}=\"{}\"", key, v));
                }
                cfg.table_newline = v;
            }
            "--opt-table-span-cell-behavior" => {
                let v = next_val(&key)?;
                if !["empty", "mirror"].contains(&v.as_str()) {
                    return Err(format!("invalid value for {}=\"{}\"", key, v));
                }
                cfg.table_span = v;
            }
            _ if key.starts_with('-') => return Err(format!("unknown flag: {}", key)),
            _ => {
                if cfg.input.is_none() {
                    cfg.input = Some(arg);
                } else {
                    return Err(format!("unknown argument: {}", arg));
                }
            }
        }
    }
    Ok(ParseResult::Run(cfg))
}

fn parse_bool(v: String) -> Result<bool, String> {
    match v.as_str() {
        "true" | "1" => Ok(true),
        "false" | "0" => Ok(false),
        _ => Err(format!("invalid boolean value \"{}\"", v)),
    }
}

fn print_version() {
    println!("html2markdown\n");
    println!("GitVersion:  dev");
    println!("GitCommit:   none");
    println!("BuildDate:   unknown");
}

fn print_help() {
    println!(
        r#"
# html2markdown - convert html to markdown [version dev]

Convert HTML to Markdown. Even works with entire websites!

## Basics

By default the "Commonmark" Plugin will be enabled. You can customize the options,
for example changing the appearance of bold with --opt-strong-delimiter="__"

Other Plugins can also be enabled. For example "GitHub Flavored Markdown" (GFM)
extends Commonmark with more features.

## Relative / Absolute Links

Use --domain="https://example.com" to convert *relative* links to *absolute* links.
The same also works for images.

## Escaping

Some characters have a special meaning in markdown. The library escapes these — if necessary.
See the documentation for more info.

## Security

Once you convert this markdown *back* to HTML you need to be careful of malicious content. 
Use a HTML sanitizer before displaying the HTML in the browser!


## Examples

    echo "<strong>important</strong>" | html2markdown

    curl --no-progress-meter http://example.com | html2markdown


    html2markdown --input file.html --output file.md

    html2markdown --input "src/*.html" --output "dist/"


## Flags

    -v, --version
        show the version of html2markdown and exit

    --help

    --input PATH
        Input file, directory, or glob pattern (instead of stdin)

    --output PATH
        Output file or directory (instead of stdout)

    --output-overwrite
        Replace existing files

    If --input is a directory or glob pattern, --output must be a directory.



    --domain
        The url of the web page, used to convert relative links to absolute links.

    --exclude-selector
        css query selector to exclude parts of the input

    --include-selector
        css query selector to only include parts of the input

    --opt-strong-delimiter
        Make bold text. Should <strong> be indicated by two asterisks or two underscores?
        "**" or "__" (default: "**")

    --opt-table-cell-padding-behavior
        [for --plugin-table] whether cells in the tables should include extra padding for visual continuity: "aligned", "minimal", or "none"

    --opt-table-header-promotion
        [for --plugin-table] first row should be treated as a header

    --opt-table-newline-behavior
        [for --plugin-table] how tables containing newlines should be handled: "skip" or "preserve"

    --opt-table-presentation-tables
        [for --plugin-table] whether tables with role="presentation" should be converted

    --opt-table-skip-empty-rows
        [for --plugin-table] omit empty rows from the output

    --opt-table-span-cell-behavior
        [for --plugin-table] how colspan/rowspan should be rendered: "empty" or "mirror"

    --plugin-strikethrough
        enable the plugin ~~strikethrough~~

    --plugin-table
        enable the plugin table



For more information visit the documentation:
https://github.com/Johanneskaufmann/html-to-markdown
"#
    );
}

fn run(cfg: Config) -> Result<(), String> {
    if let Some(input) = cfg.input.clone() {
        if has_glob(&input) {
            let output = cfg.output.clone().ok_or_else(glob_help)?;
            if !output.ends_with('/') {
                if Path::new(&output).is_dir() {
                    return Err(format!(
                        "path \"{}\" exists and is a directory, did you mean \"{}/\"?\n\nThe --output must end with \"/\" to indicate a directory",
                        Path::new(&output).file_name().unwrap_or_default().to_string_lossy(),
                        Path::new(&output).file_name().unwrap_or_default().to_string_lossy()
                    ));
                }
                return Err(glob_help());
            }
            let files = expand_glob(&input)?;
            if files.is_empty() {
                return Err(format!("no files found matching pattern \"{}\"\n\nHere is how you can use a glob to match multiple files:\n\n    html2markdown --input \"src/*.html\" --output \"dist/\"", input));
            }
            fs::create_dir_all(&output).map_err(|e| e.to_string())?;
            for file in files {
                let html = fs::read_to_string(&file).map_err(|e| e.to_string())?;
                let md = convert(&html, &cfg);
                let stem = file.file_stem().unwrap_or_default().to_string_lossy();
                let out = Path::new(&output).join(format!("{}.md", stem));
                write_output(&out, &md, cfg.overwrite)?;
            }
            return Ok(());
        }
        let p = Path::new(&input);
        if p.is_dir() {
            return Err(format!(
                "input path \"{}\" is a directory, not a file\n\nHere is how you can use a glob to match multiple files:\n\n    html2markdown --input \"src/*.html\" --output \"dist/\"",
                input
            ));
        }
        let html = fs::read_to_string(p).map_err(|e| e.to_string())?;
        let md = convert(&html, &cfg);
        if let Some(out) = cfg.output.clone() {
            let outp = Path::new(&out);
            if outp.is_dir() && !out.ends_with('/') {
                return Err(format!(
                    "path \"{}\" exists and is a directory, did you mean \"{}/\"?\n\nThe --output must end with \"/\" to indicate a directory",
                    outp.file_name().unwrap_or_default().to_string_lossy(),
                    outp.file_name().unwrap_or_default().to_string_lossy()
                ));
            }
            write_output(outp, &md, cfg.overwrite)?;
        } else {
            print!("{}", md);
        }
    } else {
        if io::stdin().is_terminal() {
            return Err("the html input should be piped into the cli\n\nHere is how you can use the CLI:\n\n    echo \"<strong>important</strong>\" | html2markdown".to_string());
        }
        let mut html = String::new();
        io::stdin().read_to_string(&mut html).map_err(|e| e.to_string())?;
        if html.is_empty() {
            return Err("the html input should be piped into the cli\n\nHere is how you can use the CLI:\n\n    echo \"<strong>important</strong>\" | html2markdown".to_string());
        }
        let md = convert(&html, &cfg);
        if let Some(out) = cfg.output.clone() {
            write_output(Path::new(&out), &md, cfg.overwrite)?;
        } else {
            print!("{}", md);
        }
    }
    Ok(())
}

fn write_output(path: &Path, data: &str, overwrite: bool) -> Result<(), String> {
    if path.exists() && !overwrite {
        return Err(format!(
            "output path \"{}\" already exists. Use --output-overwrite to replace existing files",
            path.display()
        ));
    }
    let mut f = fs::File::create(path).map_err(|e| e.to_string())?;
    f.write_all(data.as_bytes()).map_err(|e| e.to_string())
}

fn glob_help() -> String {
    "Here is how you can use a glob to match multiple files:\n\n    html2markdown --input \"src/*.html\" --output \"dist/\"".to_string()
}

fn has_glob(s: &str) -> bool {
    s.contains('*') || s.contains('?')
}

fn expand_glob(pattern: &str) -> Result<Vec<PathBuf>, String> {
    let path = Path::new(pattern);
    let dir = path.parent().unwrap_or_else(|| Path::new("."));
    let name_pat = path.file_name().unwrap_or_default().to_string_lossy().to_string();
    let mut out = Vec::new();
    for ent in fs::read_dir(dir).map_err(|e| e.to_string())? {
        let ent = ent.map_err(|e| e.to_string())?;
        let name = ent.file_name().to_string_lossy().to_string();
        if wildcard_match(&name_pat, &name) && ent.path().is_file() {
            out.push(ent.path());
        }
    }
    out.sort();
    Ok(out)
}

fn wildcard_match(pat: &str, text: &str) -> bool {
    fn rec(p: &[u8], t: &[u8]) -> bool {
        if p.is_empty() {
            return t.is_empty();
        }
        match p[0] {
            b'*' => rec(&p[1..], t) || (!t.is_empty() && rec(p, &t[1..])),
            b'?' => !t.is_empty() && rec(&p[1..], &t[1..]),
            c => !t.is_empty() && c == t[0] && rec(&p[1..], &t[1..]),
        }
    }
    rec(pat.as_bytes(), text.as_bytes())
}

fn convert(html: &str, cfg: &Config) -> String {
    let root = parse_html(html);
    let filtered = apply_filters(&root, cfg);
    let mut r = Renderer::new(cfg);
    r.render_nodes(&filtered.children);
    r.finish()
}

fn parse_html(input: &str) -> Element {
    let mut stack = vec![Element { tag: "root".into(), attrs: HashMap::new(), children: vec![] }];
    let mut i = 0usize;
    let bytes = input.as_bytes();
    while i < input.len() {
        if bytes[i] == b'<' {
            if input[i..].starts_with("<!--") {
                if let Some(end) = input[i + 4..].find("-->") {
                    i += 4 + end + 3;
                } else {
                    break;
                }
                continue;
            }
            if let Some(end) = input[i..].find('>') {
                let raw = &input[i + 1..i + end];
                let raw_trim = raw.trim();
                if raw_trim.starts_with('!') || raw_trim.starts_with('?') {
                    i += end + 1;
                    continue;
                }
                if let Some(stripped) = raw_trim.strip_prefix('/') {
                    let close = stripped.split_whitespace().next().unwrap_or("").to_ascii_lowercase();
                    close_to(&mut stack, &close);
                } else {
                    let self_close = raw_trim.ends_with('/') || is_void(raw_trim.split_whitespace().next().unwrap_or(""));
                    let (tag, attrs) = parse_tag(raw_trim.trim_end_matches('/').trim());
                    if tag == "script" || tag == "style" {
                        let close = format!("</{}>", tag);
                        if let Some(pos) = input[i + end + 1..].to_ascii_lowercase().find(&close) {
                            i = i + end + 1 + pos + close.len();
                        } else {
                            i += end + 1;
                        }
                        continue;
                    }
                    let elem = Element { tag: tag.clone(), attrs, children: vec![] };
                    if self_close {
                        stack.last_mut().unwrap().children.push(Node::Elem(elem));
                    } else {
                        stack.push(elem);
                    }
                }
                i += end + 1;
            } else {
                push_text(&mut stack, &input[i..]);
                break;
            }
        } else {
            let next = input[i..].find('<').map(|p| i + p).unwrap_or(input.len());
            push_text(&mut stack, &input[i..next]);
            i = next;
        }
    }
    while stack.len() > 1 {
        let e = stack.pop().unwrap();
        stack.last_mut().unwrap().children.push(Node::Elem(e));
    }
    stack.pop().unwrap()
}

fn push_text(stack: &mut [Element], text: &str) {
    if !text.is_empty() {
        stack.last_mut().unwrap().children.push(Node::Text(decode_entities(text)));
    }
}

fn close_to(stack: &mut Vec<Element>, tag: &str) {
    if let Some(pos) = stack.iter().rposition(|e| e.tag == tag) {
        while stack.len() > pos {
            let e = stack.pop().unwrap();
            if let Some(parent) = stack.last_mut() {
                parent.children.push(Node::Elem(e));
            }
            if stack.len() == pos {
                break;
            }
        }
    }
}

fn parse_tag(raw: &str) -> (String, HashMap<String, String>) {
    let mut chars = raw.chars().peekable();
    let mut tag = String::new();
    while let Some(&c) = chars.peek() {
        if c.is_whitespace() {
            break;
        }
        tag.push(c.to_ascii_lowercase());
        chars.next();
    }
    let rest: String = chars.collect();
    (tag, parse_attrs(&rest))
}

fn parse_attrs(s: &str) -> HashMap<String, String> {
    let mut map = HashMap::new();
    let mut i = 0usize;
    let b = s.as_bytes();
    while i < s.len() {
        while i < s.len() && b[i].is_ascii_whitespace() {
            i += 1;
        }
        if i >= s.len() {
            break;
        }
        let start = i;
        while i < s.len() && !b[i].is_ascii_whitespace() && b[i] != b'=' {
            i += 1;
        }
        let name = s[start..i].to_ascii_lowercase();
        while i < s.len() && b[i].is_ascii_whitespace() {
            i += 1;
        }
        let mut val = String::new();
        if i < s.len() && b[i] == b'=' {
            i += 1;
            while i < s.len() && b[i].is_ascii_whitespace() {
                i += 1;
            }
            if i < s.len() && (b[i] == b'"' || b[i] == b'\'') {
                let q = b[i];
                i += 1;
                let st = i;
                while i < s.len() && b[i] != q {
                    i += 1;
                }
                val = decode_entities(&s[st..i]);
                if i < s.len() {
                    i += 1;
                }
            } else {
                let st = i;
                while i < s.len() && !b[i].is_ascii_whitespace() {
                    i += 1;
                }
                val = decode_entities(&s[st..i]);
            }
        }
        if !name.is_empty() {
            map.insert(name, val);
        }
    }
    map
}

fn is_void(tag: &str) -> bool {
    matches!(tag.to_ascii_lowercase().as_str(), "area" | "base" | "br" | "col" | "embed" | "hr" | "img" | "input" | "link" | "meta" | "param" | "source" | "track" | "wbr")
}

fn decode_entities(s: &str) -> String {
    let mut out = String::new();
    let mut i = 0usize;
    while let Some(pos) = s[i..].find('&') {
        out.push_str(&s[i..i + pos]);
        i += pos;
        if let Some(end) = s[i..].find(';') {
            let ent = &s[i + 1..i + end];
            let repl = match ent {
                "amp" => Some("&".to_string()),
                "quot" => Some("\"".to_string()),
                "apos" => Some("'".to_string()),
                "nbsp" => Some(" ".to_string()),
                _ if ent.starts_with("#x") || ent.starts_with("#X") => u32::from_str_radix(&ent[2..], 16).ok().and_then(char::from_u32).map(|c| c.to_string()),
                _ if ent.starts_with('#') => ent[1..].parse::<u32>().ok().and_then(char::from_u32).map(|c| c.to_string()),
                _ => None,
            };
            if let Some(r) = repl {
                out.push_str(&r);
            } else {
                out.push('&');
                out.push_str(ent);
                out.push(';');
            }
            i += end + 1;
        } else {
            out.push('&');
            i += 1;
        }
    }
    out.push_str(&s[i..]);
    out
}

fn apply_filters(root: &Element, cfg: &Config) -> Element {
    let mut base = root.clone();
    if let Some(sel) = &cfg.exclude {
        base.children = base.children.into_iter().filter_map(|n| remove_matching(n, sel)).collect();
    }
    if let Some(sel) = &cfg.include {
        let mut children = Vec::new();
        collect_matching(&base.children, sel, &mut children);
        base.children = children;
    }
    base
}

fn remove_matching(n: Node, sel: &str) -> Option<Node> {
    match n {
        Node::Text(_) => Some(n),
        Node::Elem(mut e) => {
            if matches_selector(&e, sel) {
                None
            } else {
                e.children = e.children.into_iter().filter_map(|c| remove_matching(c, sel)).collect();
                Some(Node::Elem(e))
            }
        }
    }
}

fn collect_matching(nodes: &[Node], sel: &str, out: &mut Vec<Node>) {
    for n in nodes {
        if let Node::Elem(e) = n {
            if matches_selector(e, sel) {
                out.push(Node::Elem(e.clone()));
            } else {
                collect_matching(&e.children, sel, out);
            }
        }
    }
}

fn matches_selector(e: &Element, sel: &str) -> bool {
    let sel = sel.trim();
    if let Some(id) = sel.strip_prefix('#') {
        e.attrs.get("id").map(|v| v == id).unwrap_or(false)
    } else if let Some(cls) = sel.strip_prefix('.') {
        e.attrs.get("class").map(|v| v.split_whitespace().any(|c| c == cls)).unwrap_or(false)
    } else if let Some((tag, cls)) = sel.split_once('.') {
        e.tag == tag && e.attrs.get("class").map(|v| v.split_whitespace().any(|c| c == cls)).unwrap_or(false)
    } else {
        e.tag == sel.to_ascii_lowercase()
    }
}

struct Renderer<'a> {
    cfg: &'a Config,
    out: String,
    list_stack: Vec<ListCtx>,
    in_pre: bool,
}

#[derive(Clone)]
struct ListCtx {
    ordered: bool,
    idx: usize,
}

impl<'a> Renderer<'a> {
    fn new(cfg: &'a Config) -> Self {
        Self { cfg, out: String::new(), list_stack: vec![], in_pre: false }
    }

    fn finish(mut self) -> String {
        trim_trailing_blank(&mut self.out);
        while self.out.contains("~~~~") {
            self.out = self.out.replace("~~~~", "");
        }
        if !self.out.is_empty() {
            self.out.push('\n');
        }
        self.out
    }

    fn render_node(&mut self, n: &Node) {
        match n {
            Node::Text(t) => self.text(t),
            Node::Elem(e) => self.elem(e),
        }
    }

    fn render_nodes(&mut self, nodes: &[Node]) {
        for (idx, c) in nodes.iter().enumerate() {
            self.render_node(c);
            if is_list_node(c) && nodes.get(idx + 1).map(is_list_node).unwrap_or(false) {
                self.ensure_block();
                self.out.push_str("<!--THE END-->");
                self.block_end();
            }
        }
    }

    fn render_children(&mut self, e: &Element) {
        self.render_nodes(&e.children);
    }

    fn elem(&mut self, e: &Element) {
        match e.tag.as_str() {
            "html" | "body" | "main" | "article" | "section" | "span" | "font" | "center" => self.render_children(e),
            "p" => {
                self.ensure_block();
                self.render_children(e);
                self.block_end();
            }
            "div" | "header" | "footer" | "nav" | "aside" => {
                self.ensure_block();
                self.render_children(e);
                self.block_end();
            }
            "br" => self.out.push_str("  \n"),
            "hr" => {
                self.ensure_block();
                self.out.push_str("* * *");
                self.block_end();
            }
            "h1" | "h2" | "h3" | "h4" | "h5" | "h6" => {
                self.ensure_block();
                let level = e.tag[1..].parse::<usize>().unwrap_or(1);
                self.out.push_str(&"#".repeat(level));
                self.out.push(' ');
                self.render_children(e);
                self.block_end();
            }
            "strong" | "b" => {
                self.out.push_str(&self.cfg.strong);
                self.render_children(e);
                self.out.push_str(&self.cfg.strong);
            }
            "em" | "i" => {
                self.out.push('*');
                self.render_children(e);
                self.out.push('*');
            }
            "del" | "s" | "strike" if self.cfg.strike => {
                self.out.push_str("~~");
                self.render_children(e);
                self.out.push_str("~~");
            }
            "code" if !self.in_pre => {
                self.out.push('`');
                let mut s = plain_text(e);
                s = s.replace('`', "\\`");
                self.out.push_str(&s);
                self.out.push('`');
            }
            "pre" => {
                self.ensure_block();
                self.out.push_str("```\n");
                self.in_pre = true;
                let content = if e.children.len() == 1 {
                    if let Node::Elem(c) = &e.children[0] {
                        if c.tag == "code" { plain_text(c) } else { plain_text(e) }
                    } else { plain_text(e) }
                } else { plain_text(e) };
                self.out.push_str(content.trim_matches('\n'));
                self.in_pre = false;
                self.out.push_str("\n```");
                self.block_end();
            }
            "a" => {
                let txt = render_inline(e, self.cfg);
                let href = e.attrs.get("href").cloned().unwrap_or_default();
                if href.is_empty() {
                    self.out.push_str(&txt);
                } else {
                    self.out.push('[');
                    self.out.push_str(&txt);
                    self.out.push_str("](");
                    self.out.push_str(&resolve_url(&href, self.cfg));
                    self.out.push(')');
                }
            }
            "img" => {
                let alt = e.attrs.get("alt").cloned().unwrap_or_default();
                let src = e.attrs.get("src").cloned().unwrap_or_default();
                self.out.push_str("![");
                self.out.push_str(&escape_text(&alt));
                self.out.push_str("](");
                self.out.push_str(&resolve_url(&src, self.cfg));
                self.out.push(')');
            }
            "ul" | "ol" => {
                let nested = !self.list_stack.is_empty();
                if nested {
                    trim_spaces(&mut self.out);
                    self.out.push('\n');
                    self.out.push_str(&"  ".repeat(self.list_stack.len()));
                    self.out.push('\n');
                } else {
                    self.ensure_block();
                }
                self.list_stack.push(ListCtx { ordered: e.tag == "ol", idx: 1 });
                for c in &e.children {
                    self.render_node(c);
                }
                self.list_stack.pop();
                if !nested {
                    self.block_end();
                }
            }
            "li" => self.render_li(e),
            "blockquote" => {
                let inner = render_fragment(&e.children, self.cfg).trim_end().to_string();
                self.ensure_block();
                for line in inner.lines() {
                    self.out.push_str("> ");
                    self.out.push_str(line);
                    self.out.push('\n');
                }
                self.block_end();
            }
            "table" if self.cfg.table => self.render_table(e),
            "thead" | "tbody" | "tfoot" | "tr" | "td" | "th" | "table" => self.render_children(e),
            "script" | "style" | "noscript" => {}
            _ => self.render_children(e),
        }
    }

    fn render_li(&mut self, e: &Element) {
        let depth = self.list_stack.len().saturating_sub(1);
        let (ordered, idx) = if let Some(ctx) = self.list_stack.last_mut() {
            let n = ctx.idx;
            ctx.idx += 1;
            (ctx.ordered, n)
        } else {
            (false, 1)
        };
        if !self.out.ends_with('\n') && !self.out.is_empty() {
            self.out.push('\n');
        }
        self.out.push_str(&"  ".repeat(depth));
        if ordered {
            self.out.push_str(&format!("{}. ", idx));
        } else {
            self.out.push_str("- ");
        }
        for c in &e.children {
            self.render_node(c);
        }
        trim_spaces(&mut self.out);
        if !self.out.ends_with('\n') {
            self.out.push('\n');
        }
    }

    fn render_table(&mut self, e: &Element) {
        if !self.cfg.table_presentation && e.attrs.get("role").map(|v| v == "presentation").unwrap_or(false) {
            self.render_children(e);
            return;
        }
        let mut rows = Vec::new();
        collect_rows(e, &mut rows);
        if self.cfg.table_skip_empty_rows {
            rows.retain(|r| r.iter().any(|c| !c.0.trim().is_empty()));
        }
        if rows.is_empty() {
            return;
        }
        let cols = rows.iter().map(|r| r.len()).max().unwrap_or(0);
        let has_th = rows.get(0).map(|r| r.iter().any(|c| c.1)).unwrap_or(false);
        let promote = has_th || self.cfg.table_header_promotion;
        let mut table: Vec<Vec<String>> = rows.into_iter().map(|r| {
            let mut row: Vec<String> = r.into_iter().map(|c| c.0.replace('\n', if self.cfg.table_newline == "preserve" { "<br>" } else { " " }).trim().to_string()).collect();
            row.resize(cols, String::new());
            row
        }).collect();
        if !promote {
            table.insert(0, vec![String::new(); cols]);
        }
        let widths: Vec<usize> = (0..cols)
            .map(|i| table.iter().map(|r| r[i].chars().count()).max().unwrap_or(0).max(1))
            .collect();
        self.ensure_block();
        for (ri, row) in table.iter().enumerate() {
            self.out.push('|');
            for (i, cell) in row.iter().enumerate() {
                if self.cfg.table_pad != "none" {
                    self.out.push(' ');
                }
                self.out.push_str(cell);
                if self.cfg.table_pad == "aligned" {
                    let pad = widths[i].saturating_sub(cell.chars().count());
                    self.out.push_str(&" ".repeat(pad));
                }
                if self.cfg.table_pad != "none" {
                    self.out.push(' ');
                }
                self.out.push('|');
            }
            self.out.push('\n');
            if ri == 0 {
                self.out.push('|');
                for w in &widths {
                    self.out.push_str(&"-".repeat(if self.cfg.table_pad == "aligned" { w + 2 } else { 3 }));
                    self.out.push('|');
                }
                self.out.push('\n');
            }
        }
        self.block_end();
    }

    fn text(&mut self, t: &str) {
        if self.in_pre {
            self.out.push_str(t);
        } else {
            let collapsed = collapse_ws(t);
            if collapsed.is_empty() {
                if !self.out.ends_with([' ', '\n']) && !self.out.is_empty() {
                    self.out.push(' ');
                }
            } else {
                self.out.push_str(&escape_text(&collapsed));
            }
        }
    }

    fn ensure_block(&mut self) {
        trim_spaces(&mut self.out);
        if self.out.is_empty() {
            return;
        }
        if !self.out.ends_with("\n\n") {
            if !self.out.ends_with('\n') {
                self.out.push('\n');
            }
            self.out.push('\n');
        }
    }

    fn block_end(&mut self) {
        trim_spaces(&mut self.out);
        if !self.out.ends_with("\n\n") {
            if !self.out.ends_with('\n') {
                self.out.push('\n');
            }
            self.out.push('\n');
        }
    }
}

fn render_fragment(nodes: &[Node], cfg: &Config) -> String {
    let mut r = Renderer::new(cfg);
    for n in nodes {
        r.render_node(n);
    }
    r.finish()
}

fn is_list_node(n: &Node) -> bool {
    matches!(n, Node::Elem(e) if e.tag == "ul" || e.tag == "ol")
}

fn render_inline(e: &Element, cfg: &Config) -> String {
    let mut r = Renderer::new(cfg);
    r.render_children(e);
    r.finish().trim().to_string()
}

fn plain_text(e: &Element) -> String {
    let mut s = String::new();
    fn walk(n: &Node, s: &mut String) {
        match n {
            Node::Text(t) => s.push_str(t),
            Node::Elem(e) => {
                for c in &e.children {
                    walk(c, s);
                }
            }
        }
    }
    for c in &e.children {
        walk(c, &mut s);
    }
    s
}

fn collect_rows(e: &Element, rows: &mut Vec<Vec<(String, bool)>>) {
    if e.tag == "tr" {
        let mut row = Vec::new();
        for c in &e.children {
            if let Node::Elem(cell) = c {
                if cell.tag == "td" || cell.tag == "th" {
                    let txt = render_fragment(&cell.children, &Config::default()).trim().to_string();
                    row.push((txt, cell.tag == "th"));
                }
            }
        }
        rows.push(row);
    } else {
        for c in &e.children {
            if let Node::Elem(child) = c {
                collect_rows(child, rows);
            }
        }
    }
}

fn resolve_url(u: &str, cfg: &Config) -> String {
    if u.is_empty() {
        return String::new();
    }
    if let Some(domain) = &cfg.domain {
        if let Ok(base) = Url::parse(domain) {
            if let Ok(joined) = base.join(u) {
                return joined.to_string();
            }
        }
    }
    u.to_string()
}

fn collapse_ws(s: &str) -> String {
    let mut out = String::new();
    let mut last = false;
    for c in s.chars() {
        if c.is_whitespace() {
            if !last {
                out.push(' ');
                last = true;
            }
        } else {
            out.push(c);
            last = false;
        }
    }
    out
}

fn escape_text(s: &str) -> String {
    let mut out = String::new();
    let mut line_start = true;
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if line_start {
            if c == '#' || c == '-' || c == '+' || c == '>' {
                out.push('\\');
            } else if c.is_ascii_digit() {
                let mut j = i;
                while j < chars.len() && chars[j].is_ascii_digit() {
                    j += 1;
                }
                if j < chars.len() && chars[j] == '.' {
                    for ch in &chars[i..j] {
                        out.push(*ch);
                    }
                    out.push('\\');
                    out.push('.');
                    i = j + 1;
                    line_start = false;
                    continue;
                }
            }
        }
        if c == '*' || c == '_' {
            let prev_word = i > 0 && chars[i - 1].is_alphanumeric();
            let next_word = i + 1 < chars.len() && chars[i + 1].is_alphanumeric();
            let prev_same = i > 0 && chars[i - 1] == c;
            let next_same = i + 1 < chars.len() && chars[i + 1] == c;
            if next_word || next_same || (prev_word && !prev_same) {
                out.push('\\');
            }
        } else if matches!(c, '`' | '[') {
            out.push('\\');
        }
        out.push(c);
        line_start = c == '\n';
        i += 1;
    }
    out
}

fn trim_spaces(s: &mut String) {
    while s.ends_with(' ') || s.ends_with('\t') {
        s.pop();
    }
}

fn trim_trailing_blank(s: &mut String) {
    while s.ends_with('\n') || s.ends_with(' ') || s.ends_with('\t') {
        s.pop();
    }
}
