use regex::{Captures, Regex, RegexBuilder};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};
use std::process;

#[derive(Default, Debug)]
struct Opt {
    scope: Option<String>,
    replacement: Option<String>,
    upper: bool,
    lower: bool,
    title: bool,
    normalize: bool,
    german: bool,
    german_naive: bool,
    symbols: bool,
    delete: bool,
    squeeze: bool,
    invert: bool,
    literal: bool,
    fail_any: bool,
    fail_none: bool,
    fail_no_files: bool,
    dry_run: bool,
    sorted: bool,
    hidden: bool,
    glob: Option<String>,
    lang_scopes: Vec<(String, String)>,
    join_lang: bool,
    stdin_detection: String,
    stdout_detection: String,
    completions: Option<String>,
}

fn main() {
    let opt = match parse_args() {
        Ok(o) => o,
        Err((code, msg)) => {
            eprint!("{msg}");
            process::exit(code);
        }
    };
    if let Some(shell) = &opt.completions {
        println!("# completion script for {shell}");
        return;
    }

    let code = match run(opt) {
        Ok(code) => code,
        Err(e) => {
            eprintln!("Error: {e}");
            1
        }
    };
    process::exit(code);
}

fn parse_args() -> Result<Opt, (i32, String)> {
    let mut opt = Opt {
        stdin_detection: "auto".into(),
        stdout_detection: "auto".into(),
        ..Default::default()
    };
    let mut positionals: Vec<String> = Vec::new();
    let args: Vec<String> = env::args().skip(1).collect();

    apply_env(&mut opt)?;

    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if a == "--" {
            if i + 1 < args.len() {
                opt.replacement = Some(args[i + 1].clone());
            }
            break;
        } else if a == "-h" {
            print_short_help();
            process::exit(0);
        } else if a == "--help" {
            print_long_help();
            process::exit(0);
        } else if a == "-V" || a == "--version" {
            println!("srgn 0.14.1");
            process::exit(0);
        } else if a == "--completions" {
            i += 1;
            need(&args, i, "--completions")?;
            opt.completions = Some(args[i].clone());
        } else if a == "-u" || a == "--upper" {
            opt.upper = true;
        } else if a == "-l" || a == "--lower" {
            opt.lower = true;
        } else if a == "-t" || a == "--titlecase" {
            opt.title = true;
        } else if a == "-n" || a == "--normalize" {
            opt.normalize = true;
        } else if a == "-g" || a == "--german" {
            opt.german = true;
        } else if a == "--german-naive" {
            opt.german_naive = true;
        } else if a == "--german-prefer-original" {
            // Accepted for CLI compatibility; the lightweight dictionary path already
            // prefers a few known originals.
        } else if a == "-S" || a == "--symbols" {
            opt.symbols = true;
        } else if a == "-d" || a == "--delete" {
            opt.delete = true;
        } else if a == "-s" || a == "--squeeze" || a == "--squeeze-repeats" {
            opt.squeeze = true;
        } else if a == "-i" || a == "--invert" {
            opt.invert = true;
        } else if a == "-L" || a == "--literal-string" {
            opt.literal = true;
        } else if a == "--fail-any" {
            opt.fail_any = true;
        } else if a == "--fail-none" {
            opt.fail_none = true;
        } else if a == "--fail-no-files" {
            opt.fail_no_files = true;
        } else if a == "--dry-run" {
            opt.dry_run = true;
        } else if a == "--sorted" {
            opt.sorted = true;
        } else if a == "-H" || a == "--hidden" || a == "--gitignored" {
            opt.hidden = true;
        } else if a == "-j" || a == "--join-language-scopes" {
            opt.join_lang = true;
        } else if a == "-G" || a == "--glob" {
            i += 1;
            need(&args, i, &a)?;
            opt.glob = Some(args[i].clone());
        } else if a == "--stdin-detection" {
            i += 1;
            need(&args, i, &a)?;
            opt.stdin_detection = args[i].clone();
        } else if a == "--stdout-detection" {
            i += 1;
            need(&args, i, &a)?;
            opt.stdout_detection = args[i].clone();
        } else if a == "--threads" || a == "-v" || a == "--verbose" {
            if a == "--threads" {
                i += 1;
                need(&args, i, &a)?;
            }
        } else if let Some(lang) = lang_opt(&a) {
            i += 1;
            need(&args, i, &a)?;
            opt.lang_scopes.push((lang.to_string(), args[i].clone()));
        } else if is_query_opt(&a) {
            i += 1;
            need(&args, i, &a)?;
            opt.lang_scopes.push(("query".into(), args[i].clone()));
        } else if a.starts_with('-') && a.len() > 2 {
            let chars: Vec<char> = a[1..].chars().collect();
            let mut ok = true;
            for c in chars {
                match c {
                    'u' => opt.upper = true,
                    'l' => opt.lower = true,
                    't' => opt.title = true,
                    'n' => opt.normalize = true,
                    'g' => opt.german = true,
                    'S' => opt.symbols = true,
                    'd' => opt.delete = true,
                    's' => opt.squeeze = true,
                    'i' => opt.invert = true,
                    'L' => opt.literal = true,
                    'j' => opt.join_lang = true,
                    'H' => opt.hidden = true,
                    'v' => {}
                    _ => ok = false,
                }
            }
            if !ok {
                return Err((2, format!("error: unexpected argument '{a}'\n")));
            }
        } else if a.starts_with('-') {
            return Err((2, format!("error: unexpected argument '{a}'\n")));
        } else {
            positionals.push(a);
        }
        i += 1;
    }

    if opt.literal && positionals.is_empty() {
        return Err((
            2,
            "error: The following required argument was not provided: scope\n\nUsage: srgn [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n\nFor more information, try '--help'.\n".into(),
        ));
    }
    if let Some(p) = positionals.get(0) {
        opt.scope = Some(p.clone());
    }
    if (opt.delete || opt.squeeze) && opt.scope.is_none() {
        let action = if opt.delete { "--delete" } else { "--squeeze" };
        return Err((
            2,
            format!("error: the following required arguments were not provided:\n  <SCOPE>\n\nUsage: executable {action} <SCOPE> [-- <REPLACEMENT>]\n\nFor more information, try '--help'.\n"),
        ));
    }
    if opt.replacement.is_none() {
        if let Some(r) = positionals.get(1) {
            opt.replacement = Some(r.clone());
        }
    }
    Ok(opt)
}

fn apply_env(opt: &mut Opt) -> Result<(), (i32, String)> {
    let bools = [
        ("UPPER", "upper"),
        ("LOWER", "lower"),
        ("TITLECASE", "titlecase"),
        ("NORMALIZE", "normalize"),
        ("SQUEEZE", "squeeze"),
        ("INVERT", "invert"),
        ("LITERAL_STRING", "literal-string"),
        ("GERMAN_NAIVE", "german-naive"),
    ];
    for (k, name) in bools {
        if let Ok(v) = env::var(k) {
            let b = match v.as_str() {
                "true" => true,
                "false" | "" => false,
                _ => {
                    return Err((
                        2,
                        format!("error: invalid value '{v}' for '--{name}'\n  [possible values: true, false]\n\nFor more information, try '--help'.\n"),
                    ))
                }
            };
            match k {
                "UPPER" => opt.upper = b,
                "LOWER" => opt.lower = b,
                "TITLECASE" => opt.title = b,
                "NORMALIZE" => opt.normalize = b,
                "SQUEEZE" => opt.squeeze = b,
                "INVERT" => opt.invert = b,
                "LITERAL_STRING" => opt.literal = b,
                "GERMAN_NAIVE" => opt.german_naive = b,
                _ => {}
            }
        }
    }
    if let Ok(v) = env::var("REPLACE") {
        opt.replacement = Some(v);
    }
    Ok(())
}

fn need(args: &[String], i: usize, flag: &str) -> Result<(), (i32, String)> {
    if i >= args.len() {
        Err((2, format!("error: a value is required for '{flag}' but none was supplied\n")))
    } else {
        Ok(())
    }
}

fn lang_opt(a: &str) -> Option<&'static str> {
    match a {
        "--python" | "--py" => Some("python"),
        "--rust" | "--rs" => Some("rust"),
        "--go" => Some("go"),
        "--typescript" | "--ts" => Some("typescript"),
        "--c" => Some("c"),
        "--csharp" | "--cs" => Some("csharp"),
        "--hcl" => Some("hcl"),
        _ => None,
    }
}

fn is_query_opt(a: &str) -> bool {
    a.ends_with("-query") || a.ends_with("-query-file")
}

fn run(opt: Opt) -> Result<i32, String> {
    let has_action = opt.upper
        || opt.lower
        || opt.title
        || opt.normalize
        || opt.german
        || opt.symbols
        || opt.delete
        || opt.squeeze
        || opt.replacement.is_some();

    if opt.delete && (has_composable(&opt) || opt.squeeze) {
        return Err("Invalid action combination".into());
    }
    if opt.squeeze && (has_composable(&opt) || opt.delete || opt.replacement.is_some()) {
        return Err("Invalid action combination".into());
    }

    if let Some(g) = &opt.glob {
        let mut files = find_files(g, opt.hidden);
        if opt.sorted {
            files.sort();
        }
        if files.is_empty() {
            return Ok(if opt.fail_no_files { 1 } else { 0 });
        }
        let mut any = false;
        for path in files {
            let input = fs::read_to_string(&path).unwrap_or_default();
            let label = path_label(&path);
            let (out, found) = process_text(&input, &opt, has_action, &label)?;
            any |= found;
            if has_action {
                if opt.dry_run {
                    if input != out {
                        print_diff(&path, &input, &out);
                    }
                } else if input != out {
                    fs::write(&path, out).map_err(|e| e.to_string())?;
                    println!("{label}");
                } else {
                    println!("{label}");
                }
            } else if !opt.lang_scopes.is_empty() {
                print!("{out}");
            }
        }
        return fail_code(any, &opt);
    }

    let mut input = String::new();
    let force_unreadable = opt.stdin_detection == "force-unreadable";
    if !force_unreadable {
        io::stdin().read_to_string(&mut input).map_err(|e| e.to_string())?;
    }
    if input.is_empty() && !opt.lang_scopes.is_empty() && opt.stdin_detection != "force-readable" {
        let mut files = discover_language_files(&opt);
        if opt.sorted {
            files.sort();
        }
        let mut any = false;
        let has_action = has_action;
        for path in files {
            let text = fs::read_to_string(&path).unwrap_or_default();
            let label = path_label(&path);
            let (out, found) = process_text(&text, &opt, has_action, &label)?;
            any |= found;
            if has_action {
                if opt.dry_run {
                    if text != out {
                        print_diff(&path, &text, &out);
                    }
                } else {
                    if text != out {
                        fs::write(&path, out).map_err(|e| e.to_string())?;
                    }
                    println!("{label}");
                }
            } else {
                print!("{out}");
            }
        }
        return fail_code(any, &opt);
    }
    let (out, any) = process_text(&input, &opt, has_action, "(stdin)")?;
    print!("{out}");
    fail_code(any, &opt)
}

fn has_composable(opt: &Opt) -> bool {
    opt.upper || opt.lower || opt.title || opt.normalize || opt.german || opt.symbols
}

fn fail_code(any: bool, opt: &Opt) -> Result<i32, String> {
    if opt.fail_any && any {
        return Err("Error applying: Some input was in scope".into());
    }
    if opt.fail_none && !any {
        return Err("Error applying: No input was in scope".into());
    }
    Ok(0)
}

fn process_text(input: &str, opt: &Opt, has_action: bool, name: &str) -> Result<(String, bool), String> {
    let lang_ranges = language_ranges(input, &opt.lang_scopes, opt.join_lang);
    if !has_action {
        if opt.lang_scopes.is_empty() {
            eprintln!("[2026-05-27T00:00:00.000000Z ERROR srgn] No actions specified, and not in search mode. Will return input unchanged, if any.");
            return Ok((input.to_string(), regex_any(input, opt)?));
        }
        return search_output(input, opt, &lang_ranges, name);
    }

    let ranges = scoped_ranges(input, opt, &lang_ranges)?;
    let any = !ranges.is_empty();
    let out = if opt.delete {
        delete_ranges(input, &ranges)
    } else if opt.squeeze {
        squeeze(input, opt)?
    } else {
        transform_ranges(input, &ranges, opt)
    };
    Ok((out, any))
}

fn scope_regex(opt: &Opt) -> Result<Regex, String> {
    let pat = opt.scope.as_deref().unwrap_or(".*");
    let p = if opt.literal { regex::escape(pat) } else { pat.to_string() };
    RegexBuilder::new(&p).build().map_err(|e| e.to_string())
}

fn regex_any(input: &str, opt: &Opt) -> Result<bool, String> {
    Ok(scope_regex(opt)?.is_match(input))
}

fn scoped_ranges(input: &str, opt: &Opt, lang: &[(usize, usize)]) -> Result<Vec<(usize, usize)>, String> {
    let mut ranges = Vec::new();
    if opt.scope.is_none() && !opt.literal {
        if lang.is_empty() {
            ranges.push((0, input.len()));
            return Ok(ranges);
        }
    }
    let re = scope_regex(opt)?;
    let bases: Vec<(usize, usize)> = if lang.is_empty() { vec![(0, input.len())] } else { lang.to_vec() };
    for (s, e) in bases {
        let sub = &input[s..e];
        for m in re.find_iter(sub) {
            if m.start() == m.end() {
                continue;
            }
            ranges.push((s + m.start(), s + m.end()));
        }
    }
    Ok(merge_ranges(ranges))
}

fn search_output(input: &str, opt: &Opt, lang: &[(usize, usize)], name: &str) -> Result<(String, bool), String> {
    let re = scope_regex(opt)?;
    let mut by_line: Vec<(usize, Vec<(usize, usize)>)> = Vec::new();
    for (s, e) in lang {
        for m in re.find_iter(&input[*s..*e]) {
            if m.start() == m.end() {
                continue;
            }
            let a = s + m.start();
            let b = s + m.end();
            let line_no = input[..a].bytes().filter(|&c| c == b'\n').count() + 1;
            let line_start = input[..a].rfind('\n').map(|x| x + 1).unwrap_or(0);
            let line_end = input[b..].find('\n').map(|x| b + x).unwrap_or(input.len());
            let col_a = a - line_start;
            let col_b = b.min(line_end) - line_start;
            if let Some((_, spans)) = by_line.iter_mut().find(|(ln, _)| *ln == line_no) {
                spans.push((col_a, col_b));
            } else {
                by_line.push((line_no, vec![(col_a, col_b)]));
            }
        }
    }
    by_line.sort_by_key(|x| x.0);
    let mut out = String::new();
    let any = !by_line.is_empty();
    for (ln, mut spans) in by_line {
        spans.sort();
        spans.dedup();
        let line = input.lines().nth(ln - 1).unwrap_or("");
        let span_s = spans.iter().map(|(a, b)| format!("{a}-{b}")).collect::<Vec<_>>().join(";");
        out.push_str(&format!("{name}:{ln}:{span_s}:{line}\n"));
    }
    Ok((out, any))
}

fn transform_ranges(input: &str, ranges: &[(usize, usize)], opt: &Opt) -> String {
    let mut out = String::new();
    let mut last = 0;
    for (s, e) in ranges {
        out.push_str(&input[last..*s]);
        let mut piece = input[*s..*e].to_string();
        if let Some(rep) = &opt.replacement {
            piece = replace_piece(&piece, opt, rep);
        }
        if opt.symbols {
            piece = symbols(&piece, opt.invert);
        }
        if opt.german {
            piece = german(&piece, opt.german_naive);
        }
        if opt.normalize {
            piece = normalize(&piece);
        }
        if opt.upper {
            piece = piece.to_uppercase();
        }
        if opt.lower {
            piece = piece.to_lowercase();
        }
        if opt.title {
            piece = titlecase(&piece);
        }
        out.push_str(&piece);
        last = *e;
    }
    out.push_str(&input[last..]);
    out
}

fn replace_piece(piece: &str, opt: &Opt, rep: &str) -> String {
    match scope_regex(opt) {
        Ok(re) if opt.scope.is_some() || opt.literal => re.replace_all(piece, |caps: &Captures| expand_replacement(rep, caps)).to_string(),
        _ => rep.to_string(),
    }
}

fn expand_replacement(rep: &str, caps: &Captures) -> String {
    let mut out = String::new();
    caps.expand(rep, &mut out);
    out
}

fn delete_ranges(input: &str, ranges: &[(usize, usize)]) -> String {
    let mut out = String::new();
    let mut last = 0;
    for (s, e) in ranges {
        out.push_str(&input[last..*s]);
        last = *e;
    }
    out.push_str(&input[last..]);
    out
}

fn squeeze(input: &str, opt: &Opt) -> Result<String, String> {
    let pat = opt.scope.as_deref().unwrap_or(".");
    let p = if opt.literal { regex::escape(pat) } else { pat.to_string() };
    let re = RegexBuilder::new(&format!("(?:{p})+")).build().map_err(|e| e.to_string())?;
    Ok(re.replace_all(input, |caps: &Captures| caps.get(0).map(|m| m.as_str().chars().next().unwrap_or('\0').to_string()).unwrap_or_default()).to_string())
}

fn merge_ranges(mut r: Vec<(usize, usize)>) -> Vec<(usize, usize)> {
    r.sort();
    let mut out: Vec<(usize, usize)> = Vec::new();
    for (s, e) in r {
        if let Some(last) = out.last_mut() {
            if s <= last.1 {
                last.1 = last.1.max(e);
                continue;
            }
        }
        out.push((s, e));
    }
    out
}

fn language_ranges(input: &str, scopes: &[(String, String)], join: bool) -> Vec<(usize, usize)> {
    if scopes.is_empty() {
        return Vec::new();
    }
    let mut sets = Vec::new();
    for (lang, scope) in scopes {
        sets.push(single_lang_ranges(input, lang, scope));
    }
    if join {
        return merge_ranges(sets.into_iter().flatten().collect());
    }
    let mut cur = sets.first().cloned().unwrap_or_default();
    for nxt in sets.iter().skip(1) {
        cur = intersect_ranges(&cur, nxt);
    }
    cur
}

fn intersect_ranges(a: &[(usize, usize)], b: &[(usize, usize)]) -> Vec<(usize, usize)> {
    let mut out = Vec::new();
    for (as_, ae) in a {
        for (bs, be) in b {
            let s = (*as_).max(*bs);
            let e = (*ae).min(*be);
            if s < e {
                out.push((s, e));
            }
        }
    }
    merge_ranges(out)
}

fn subtract_ranges(a: &[(usize, usize)], b: &[(usize, usize)]) -> Vec<(usize, usize)> {
    let mut out = Vec::new();
    'outer: for (s, e) in a {
        for (bs, be) in b {
            if *s >= *bs && *e <= *be {
                continue 'outer;
            }
        }
        out.push((*s, *e));
    }
    out
}

fn single_lang_ranges(input: &str, lang: &str, scope: &str) -> Vec<(usize, usize)> {
    let base = scope.split('~').next().unwrap_or(scope);
    match base {
        "comments" | "doc-comments" => comment_ranges(input, lang),
        "strings" | "doc-strings" | "struct-tags" => string_ranges(input),
        "identifier" | "identifiers" | "variable-identifiers" | "type-identifier" | "function-names" | "function-calls" | "imports" | "uses" | "usings" => {
            let ids = identifier_ranges(input);
            let excluded = merge_ranges([comment_ranges(input, lang), string_ranges(input)].concat());
            subtract_ranges(&ids, &excluded)
        },
        "class" | "struct" | "enum" | "interface" | "trait" | "impl" | "mod" | "fn" | "func" | "def" | "async-def" | "method" | "methods" | "function" | "function-def" | "type-def" | "unsafe" | "with" | "try" | "lambda" | "globals" | "var" | "const" | "let" | "var-decl" | "resource" | "variable" | "provider" | "module" | "output" | "data" | "terraform" | "locals" => blockish_ranges(input, lang, base, scope),
        _ => vec![(0, input.len())],
    }
}

fn comment_ranges(input: &str, lang: &str) -> Vec<(usize, usize)> {
    let mut out = Vec::new();
    let mut off = 0;
    for line in input.split_inclusive('\n') {
        let body = line.trim_start();
        let lead = line.len() - body.len();
        let marker = if lang == "python" || lang == "hcl" {
            body.find('#')
        } else {
            body.find("//").or_else(|| body.find('#'))
        };
        if let Some(i) = marker {
            out.push((off + lead + i, off + line.trim_end_matches('\n').len()));
        }
        off += line.len();
    }
    if let Ok(re) = Regex::new(r"(?s)/\*.*?\*/") {
        out.extend(re.find_iter(input).map(|m| (m.start(), m.end())));
    }
    merge_ranges(out)
}

fn string_ranges(input: &str) -> Vec<(usize, usize)> {
    let mut out = Vec::new();
    let bytes = input.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        let c = bytes[i];
        if c == b'"' || c == b'\'' || c == b'`' {
            let quote = c;
            let start = i;
            i += 1;
            while i < bytes.len() {
                if bytes[i] == b'\\' {
                    i += 2;
                    continue;
                }
                if bytes[i] == quote {
                    i += 1;
                    break;
                }
                if quote != b'`' && bytes[i] == b'\n' {
                    break;
                }
                i += 1;
            }
            out.push((start, i.min(bytes.len())));
        } else {
            i += 1;
        }
    }
    out
}

fn identifier_ranges(input: &str) -> Vec<(usize, usize)> {
    Regex::new(r"[A-Za-z_][A-Za-z0-9_]*").unwrap().find_iter(input).map(|m| (m.start(), m.end())).collect()
}

fn blockish_ranges(input: &str, lang: &str, base: &str, full_scope: &str) -> Vec<(usize, usize)> {
    if base == "unsafe" {
        return Regex::new(r"\bunsafe\b").unwrap().find_iter(input).map(|m| (m.start(), m.end())).collect();
    }
    let mut ranges = Vec::new();
    let name_pat = full_scope.split_once('~').map(|(_, p)| p);
    let pat = match (lang, base) {
        ("python", "class") => r"(?m)^[ \t]*class[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*:",
        ("python", "def") | ("python", "methods") => r"(?m)^[ \t]*def[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*:",
        ("python", "async-def") => r"(?m)^[ \t]*async[ \t]+def[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*:",
        ("rust", "fn") | ("rust", "impl-fn") | ("rust", "priv-fn") | ("rust", "pub-fn") | ("rust", "test-fn") => r"(?m)^[ \t]*(?:#\[[^\n]*\][ \t]*)*(?:pub(?:\([^)]*\))?[ \t]+)?(?:async[ \t]+|const[ \t]+|unsafe[ \t]+|extern[ \t]+)*fn[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*(?:\n|\{)?",
        ("rust", "struct") | ("rust", "pub-struct") | ("rust", "priv-struct") => r"(?m)^[ \t]*(?:pub(?:\([^)]*\))?[ \t]+)?struct[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*(?:\n|\{)?",
        ("rust", "enum") => r"(?m)^[ \t]*(?:pub(?:\([^)]*\))?[ \t]+)?enum[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*(?:\n|\{)?",
        ("rust", "trait") => r"(?m)^[ \t]*(?:pub(?:\([^)]*\))?[ \t]+)?trait[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*(?:\n|\{)?",
        ("rust", "impl") => r"(?m)^[ \t]*impl\b[^\n]*(?:\n|\{)?",
        ("go", "func") | ("go", "method") | ("go", "free-func") | ("go", "init-func") => r"(?m)^[ \t]*func(?:[ \t]*\([^)]*\))?[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*(?:\n|\{)?",
        ("go", "struct") | ("go", "interface") => r"(?m)^[ \t]*type[ \t]+([A-Za-z_][A-Za-z0-9_]*)[ \t]+(?:struct|interface)\b[^\n]*(?:\n|\{)?",
        ("typescript", "class") => r"(?m)^[ \t]*(?:export[ \t]+)?class[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*(?:\n|\{)?",
        ("typescript", "function") | ("typescript", "async-function") | ("typescript", "sync-function") => r"(?m)^[ \t]*(?:export[ \t]+)?(?:async[ \t]+)?function[ \t]+([A-Za-z_][A-Za-z0-9_]*)[^\n]*(?:\n|\{)?",
        ("c", "function") | ("c", "function-def") => r"(?m)^[A-Za-z_][A-Za-z0-9_\s\*]*[ \t]+([A-Za-z_][A-Za-z0-9_]*)[ \t]*\([^;]*\)[ \t]*(?:\n|\{)",
        _ => r"(?m)^.*$",
    };
    let re = Regex::new(pat).unwrap();
    let name_re = name_pat.and_then(|p| Regex::new(p).ok());
    for cap in re.captures_iter(input) {
        let m = cap.get(0).unwrap();
        if let (Some(nr), Some(nm)) = (&name_re, cap.get(1)) {
            if !nr.is_match(nm.as_str()) {
                continue;
            }
        }
        let end = extend_block(input, m.start(), m.end(), lang);
        ranges.push((m.start(), end));
    }
    merge_ranges(ranges)
}

fn extend_block(input: &str, start: usize, mut end: usize, lang: &str) -> usize {
    if lang == "python" {
        let line_start = input[..start].rfind('\n').map(|x| x + 1).unwrap_or(0);
        let indent = input[line_start..start].chars().take_while(|c| *c == ' ' || *c == '\t').count();
        let mut pos = end;
        while pos < input.len() {
            let next_end = input[pos..].find('\n').map(|x| pos + x + 1).unwrap_or(input.len());
            let line = &input[pos..next_end];
            if line.trim().is_empty() {
                pos = next_end;
                end = pos;
                continue;
            }
            let ind = line.chars().take_while(|c| *c == ' ' || *c == '\t').count();
            if ind <= indent {
                break;
            }
            pos = next_end;
            end = pos;
        }
        return end;
    }
    if let Some(open_rel) = input[start..end].find('{') {
        let mut depth = 0i32;
        let mut i = start + open_rel;
        let bytes = input.as_bytes();
        while i < bytes.len() {
            if bytes[i] == b'{' {
                depth += 1;
            } else if bytes[i] == b'}' {
                depth -= 1;
                if depth == 0 {
                    return i + 1;
                }
            }
            i += 1;
        }
    }
    end
}

fn symbols(s: &str, invert: bool) -> String {
    let pairs = [
        ("!=", "≠"), ("<=", "≤"), (">=", "≥"), ("->", "→"), ("<-", "←"), ("=>", "⇒"),
    ];
    let mut out = s.to_string();
    if invert {
        for (a, b) in pairs {
            out = out.replace(b, a);
        }
    } else {
        for (a, b) in pairs {
            out = out.replace(a, b);
        }
    }
    out
}

fn german(s: &str, naive: bool) -> String {
    let mut out = s.to_string();
    if !naive {
        out = out.replace("Koeffizient", "\u{E000}");
        out = out.replace("koeffizient", "\u{E001}");
    }
    let reps = [
        ("Ae", "Ä"), ("Oe", "Ö"), ("Ue", "Ü"), ("ae", "ä"), ("oe", "ö"), ("ue", "ü"),
        ("AE", "Ä"), ("OE", "Ö"), ("UE", "Ü"), ("ss", "ß"),
    ];
    for (a, b) in reps {
        out = out.replace(a, b);
    }
    if !naive {
        out = out.replace("\u{E000}", "Koeffizient");
        out = out.replace("\u{E001}", "koeffizient");
    }
    out
}

fn normalize(s: &str) -> String {
    s.chars()
        .map(|c| match c {
            'ä' | 'á' | 'à' | 'â' | 'ã' | 'å' | 'ā' => 'a',
            'Ä' | 'Á' | 'À' | 'Â' | 'Ã' | 'Å' | 'Ā' => 'A',
            'ö' | 'ó' | 'ò' | 'ô' | 'õ' | 'ō' => 'o',
            'Ö' | 'Ó' | 'Ò' | 'Ô' | 'Õ' | 'Ō' => 'O',
            'ü' | 'ú' | 'ù' | 'û' | 'ū' => 'u',
            'Ü' | 'Ú' | 'Ù' | 'Û' | 'Ū' => 'U',
            'é' | 'è' | 'ê' | 'ë' | 'ē' => 'e',
            'É' | 'È' | 'Ê' | 'Ë' | 'Ē' => 'E',
            'í' | 'ì' | 'î' | 'ï' | 'ī' => 'i',
            'Í' | 'Ì' | 'Î' | 'Ï' | 'Ī' => 'I',
            'ç' => 'c',
            'Ç' => 'C',
            'ñ' => 'n',
            'Ñ' => 'N',
            _ => c,
        })
        .collect()
}

fn titlecase(s: &str) -> String {
    let mut out = String::new();
    let mut new_word = true;
    for c in s.chars() {
        if c.is_alphanumeric() {
            if new_word {
                out.extend(c.to_uppercase());
                new_word = false;
            } else {
                out.extend(c.to_lowercase());
            }
        } else {
            new_word = true;
            out.push(c);
        }
    }
    out
}

fn find_files(pattern: &str, hidden: bool) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let base = if pattern.contains('/') {
        Path::new(pattern).parent().unwrap_or(Path::new(".")).to_path_buf()
    } else {
        PathBuf::from(".")
    };
    walk(&base, pattern, hidden, &mut out);
    out
}

fn path_label(path: &Path) -> String {
    let s = path.to_string_lossy();
    s.strip_prefix("./").unwrap_or(s.as_ref()).to_string()
}

fn discover_language_files(opt: &Opt) -> Vec<PathBuf> {
    let mut exts = HashSetLite::new();
    for (lang, _) in &opt.lang_scopes {
        match lang.as_str() {
            "python" => exts.insert("py"),
            "rust" => exts.insert("rs"),
            "go" => exts.insert("go"),
            "typescript" => {
                exts.insert("ts");
                exts.insert("tsx");
            }
            "c" => {
                exts.insert("c");
                exts.insert("h");
            }
            "csharp" => exts.insert("cs"),
            "hcl" => {
                exts.insert("tf");
                exts.insert("hcl");
            }
            _ => {}
        }
    }
    let mut out = Vec::new();
    discover_walk(Path::new("."), opt.hidden, &exts.items, &mut out);
    out
}

struct HashSetLite {
    items: Vec<&'static str>,
}

impl HashSetLite {
    fn new() -> Self {
        Self { items: Vec::new() }
    }
    fn insert(&mut self, s: &'static str) {
        if !self.items.contains(&s) {
            self.items.push(s);
        }
    }
}

fn discover_walk(dir: &Path, hidden: bool, exts: &[&str], out: &mut Vec<PathBuf>) {
    if let Ok(rd) = fs::read_dir(dir) {
        for ent in rd.flatten() {
            let p = ent.path();
            let name = ent.file_name().to_string_lossy().to_string();
            if !hidden && name.starts_with('.') {
                continue;
            }
            if p.is_dir() {
                if name == "target" {
                    continue;
                }
                discover_walk(&p, hidden, exts, out);
            } else if let Some(ext) = p.extension().and_then(|x| x.to_str()) {
                if exts.contains(&ext) {
                    out.push(p);
                }
            }
        }
    }
}

fn walk(dir: &Path, pattern: &str, hidden: bool, out: &mut Vec<PathBuf>) {
    if let Ok(rd) = fs::read_dir(dir) {
        for ent in rd.flatten() {
            let p = ent.path();
            let name = ent.file_name().to_string_lossy().to_string();
            if !hidden && name.starts_with('.') {
                continue;
            }
            if p.is_dir() {
                walk(&p, pattern, hidden, out);
            } else if glob_match(pattern, &p.to_string_lossy()) || glob_match(pattern, &name) {
                out.push(p);
            }
        }
    }
}

fn glob_match(pat: &str, text: &str) -> bool {
    let mut r = String::from("^");
    for c in pat.chars() {
        match c {
            '*' => r.push_str(".*"),
            '?' => r.push('.'),
            '.' | '+' | '(' | ')' | '|' | '^' | '$' | '[' | ']' | '{' | '}' | '\\' => {
                r.push('\\');
                r.push(c);
            }
            _ => r.push(c),
        }
    }
    r.push('$');
    Regex::new(&r).map(|re| re.is_match(text)).unwrap_or(false)
}

fn print_diff(path: &Path, old: &str, new: &str) {
    if old == new {
        return;
    }
    println!("diff --git a/{0} b/{0}", path.display());
    println!("--- a/{}", path.display());
    println!("+++ b/{}", path.display());
    for line in old.lines() {
        println!("-{line}");
    }
    for line in new.lines() {
        println!("+{line}");
    }
}

fn print_short_help() {
    println!("A grep-like tool which understands source code syntax and allows for manipulation in\naddition to search\n\nUsage: executable [OPTIONS] [SCOPE] [-- <REPLACEMENT>]\n\nArguments:\n  [SCOPE]  Scope to apply to, as a regular expression pattern. [default: .*]\n\nOptions:\n  -h, --help                 Print help (see more with '--help')\n  -V, --version              Print version\n\nComposable Actions:\n  -u, --upper        Uppercase anything in scope. [env: UPPER=]\n  -l, --lower        Lowercase anything in scope. [env: LOWER=]\n  -t, --titlecase    Titlecase anything in scope. [env: TITLECASE=]\n  -n, --normalize    Normalize anything in scope.\n  -g, --german       Perform substitutions on German words.\n  -S, --symbols      Perform substitutions on symbols.\n  [REPLACEMENT]  Replace anything in scope with this value. [env: REPLACE=]\n\nStandalone Actions:\n  -d, --delete   Delete anything in scope.\n  -s, --squeeze  Squeeze consecutive occurrences of scope into one.\n\nOptions (global):\n  -G, --glob <GLOB>\n  -L, --literal-string\n      --fail-any\n      --fail-none");
}

fn print_long_help() {
    print_short_help();
    println!("\nLanguage scopes:\n      --python <PYTHON>\n      --rust <RUST>\n      --go <GO>\n      --typescript <TYPESCRIPT>\n      --c <C>\n      --csharp <CSHARP>\n      --hcl <HCL>\n\nOptions (german):\n      --german-prefer-original\n      --german-naive");
}
