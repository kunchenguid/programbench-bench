use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

#[derive(Clone, Debug, PartialEq, Eq)]
enum Kind {
    Ident,
    Sym(char),
}

#[derive(Clone, Debug)]
struct Tok {
    kind: Kind,
    text: String,
    start: usize,
    end: usize,
    line: usize,
    col: usize,
}

#[derive(Clone, Debug)]
struct Def {
    name: String,
    start: usize,
    end: usize,
    line: usize,
    col: usize,
    end_col: usize,
    scope_start: usize,
    scope_end: usize,
    message_kind: &'static str,
    def_tok: usize,
    skip: bool,
}

#[derive(Clone, Debug)]
struct ResultItem {
    line: usize,
    column: usize,
    end_column: usize,
    message: String,
    start: usize,
    end: usize,
}

#[derive(Default)]
struct Opts {
    no_lambda_arg: bool,
    no_lambda_pattern_names: bool,
    no_underscore: bool,
    warn_used_underscore: bool,
    quiet: bool,
    edit: bool,
    hidden: bool,
    fail: bool,
    json: bool,
    excludes: Vec<String>,
    paths: Vec<String>,
}

fn is_ident_start(c: char) -> bool {
    c == '_' || c.is_ascii_alphabetic()
}

fn is_ident_char(c: char) -> bool {
    c == '_' || c == '-' || c == '\'' || c.is_ascii_alphanumeric()
}

fn lex(src: &str) -> Vec<Tok> {
    let bytes = src.as_bytes();
    let mut out = Vec::new();
    let mut i = 0;
    let mut line = 1usize;
    let mut col = 1usize;
    while i < bytes.len() {
        let c = bytes[i] as char;
        if c == '\n' {
            i += 1;
            line += 1;
            col = 1;
        } else if c.is_ascii_whitespace() {
            i += 1;
            col += 1;
        } else if c == '#' {
            while i < bytes.len() && bytes[i] != b'\n' {
                i += 1;
                col += 1;
            }
        } else if c == '"' {
            i += 1;
            col += 1;
            while i < bytes.len() {
                let ch = bytes[i] as char;
                if ch == '\\' {
                    i = (i + 2).min(bytes.len());
                    col += 2;
                } else if ch == '"' {
                    i += 1;
                    col += 1;
                    break;
                } else if ch == '$' && i + 1 < bytes.len() && bytes[i + 1] == b'{' {
                    out.push(Tok { kind: Kind::Sym('{'), text: "{".into(), start: i + 1, end: i + 2, line, col: col + 1 });
                    i += 2;
                    col += 2;
                } else if ch == '\n' {
                    i += 1;
                    line += 1;
                    col = 1;
                } else if is_ident_start(ch) {
                    let start = i;
                    let l = line;
                    let c0 = col;
                    while i < bytes.len() && is_ident_char(bytes[i] as char) {
                        i += 1;
                        col += 1;
                    }
                    out.push(Tok { kind: Kind::Ident, text: src[start..i].to_string(), start, end: i, line: l, col: c0 });
                } else {
                    if "{}()[]:;=,.?@".contains(ch) {
                        out.push(Tok { kind: Kind::Sym(ch), text: ch.to_string(), start: i, end: i + 1, line, col });
                    }
                    i += 1;
                    col += 1;
                }
            }
        } else if i + 1 < bytes.len() && bytes[i] == b'\'' && bytes[i + 1] == b'\'' {
            i += 2;
            col += 2;
            while i < bytes.len() {
                if i + 1 < bytes.len() && bytes[i] == b'\'' && bytes[i + 1] == b'\'' {
                    i += 2;
                    col += 2;
                    break;
                }
                let ch = bytes[i] as char;
                if ch == '\n' {
                    i += 1;
                    line += 1;
                    col = 1;
                } else if ch == '$' && i + 1 < bytes.len() && bytes[i + 1] == b'{' {
                    out.push(Tok { kind: Kind::Sym('{'), text: "{".into(), start: i + 1, end: i + 2, line, col: col + 1 });
                    i += 2;
                    col += 2;
                } else {
                    i += 1;
                    col += 1;
                }
            }
        } else if is_ident_start(c) {
            let start = i;
            let l = line;
            let c0 = col;
            while i < bytes.len() && is_ident_char(bytes[i] as char) {
                i += 1;
                col += 1;
            }
            out.push(Tok { kind: Kind::Ident, text: src[start..i].to_string(), start, end: i, line: l, col: c0 });
        } else {
            if "{}()[]:;=,.?@".contains(c) {
                out.push(Tok { kind: Kind::Sym(c), text: c.to_string(), start: i, end: i + 1, line, col });
            }
            i += 1;
            col += 1;
        }
    }
    out
}

fn is_sym(toks: &[Tok], i: usize, c: char) -> bool {
    toks.get(i).map(|t| t.kind == Kind::Sym(c)).unwrap_or(false)
}

fn is_ident_text(toks: &[Tok], i: usize, s: &str) -> bool {
    toks.get(i).map(|t| t.kind == Kind::Ident && t.text == s).unwrap_or(false)
}

fn matching(toks: &[Tok], open: usize) -> Option<usize> {
    let close = match toks.get(open)?.kind {
        Kind::Sym('{') => '}',
        Kind::Sym('(') => ')',
        Kind::Sym('[') => ']',
        _ => return None,
    };
    let open_ch = match toks[open].kind { Kind::Sym(c) => c, _ => return None };
    let mut depth = 0i32;
    for i in open..toks.len() {
        if toks[i].kind == Kind::Sym(open_ch) {
            depth += 1;
        } else if toks[i].kind == Kind::Sym(close) {
            depth -= 1;
            if depth == 0 {
                return Some(i);
            }
        }
    }
    None
}

fn find_top_in(toks: &[Tok], start: usize, end: usize) -> Option<usize> {
    let mut par = 0i32;
    let mut bra = 0i32;
    let mut cur = 0i32;
    for i in start..end {
        match toks[i].kind {
            Kind::Sym('(') => par += 1,
            Kind::Sym(')') => par -= 1,
            Kind::Sym('[') => bra += 1,
            Kind::Sym(']') => bra -= 1,
            Kind::Sym('{') => cur += 1,
            Kind::Sym('}') => cur -= 1,
            Kind::Ident if toks[i].text == "in" && par == 0 && bra == 0 && cur == 0 => return Some(i),
            _ => {}
        }
    }
    None
}

fn previous_line_has_skip(src: &str, byte: usize) -> bool {
    let before = &src[..byte.min(src.len())];
    let line_start = before.rfind('\n').map(|x| x + 1).unwrap_or(0);
    if line_start == 0 {
        return false;
    }
    let prev_end = line_start - 1;
    let prev_start = src[..prev_end].rfind('\n').map(|x| x + 1).unwrap_or(0);
    src[prev_start..prev_end].contains("deadnix: skip")
}

fn add_def(defs: &mut Vec<Def>, toks: &[Tok], idx: usize, scope_start: usize, scope_end: usize, kind: &'static str, skip: bool) {
    let t = &toks[idx];
    defs.push(Def {
        name: t.text.clone(),
        start: t.start,
        end: t.end,
        line: t.line,
        col: t.col,
        end_col: t.col + t.text.chars().count(),
        scope_start,
        scope_end,
        message_kind: kind,
        def_tok: idx,
        skip,
    });
}

fn parse_pattern(defs: &mut Vec<Def>, toks: &[Tok], open: usize, close: usize, scope_start: usize, scope_end: usize, opts: &Opts, src: &str) {
    if opts.no_lambda_pattern_names {
        return;
    }
    let mut i = open + 1;
    while i < close {
        if toks[i].kind == Kind::Ident && toks[i].text != "..." {
            let name_idx = i;
            if !toks[name_idx].text.starts_with('_') || !opts.no_underscore {
                add_def(defs, toks, name_idx, scope_start, scope_end, "lambda pattern", previous_line_has_skip(src, toks[name_idx].start));
            }
            i += 1;
            let mut depth = 0i32;
            while i < close {
                match toks[i].kind {
                    Kind::Sym('{') | Kind::Sym('(') | Kind::Sym('[') => depth += 1,
                    Kind::Sym('}') | Kind::Sym(')') | Kind::Sym(']') => depth -= 1,
                    Kind::Sym(',') if depth == 0 => { i += 1; break; }
                    _ => {}
                }
                i += 1;
            }
        } else {
            i += 1;
        }
    }
}

fn parse_expr(defs: &mut Vec<Def>, toks: &[Tok], start: usize, end: usize, opts: &Opts, src: &str) {
    let mut i = start;
    while i < end {
        if is_ident_text(toks, i, "let") {
            if let Some(in_i) = find_top_in(toks, i + 1, end) {
                parse_let(defs, toks, i, in_i, end, opts, src);
                parse_expr(defs, toks, in_i + 1, end, opts, src);
                i = end;
                continue;
            }
        }
        if toks[i].kind == Kind::Ident && i + 1 < end && is_sym(toks, i + 1, ':') {
            if !opts.no_lambda_arg && !toks[i].text.starts_with('_') && (!opts.no_underscore || !toks[i].text.starts_with('_')) {
                add_def(defs, toks, i, i + 2, end, "lambda argument", previous_line_has_skip(src, toks[i].start));
            }
            parse_expr(defs, toks, i + 2, end, opts, src);
            return;
        }
        if toks[i].kind == Kind::Ident && i + 2 < end && is_sym(toks, i + 1, '@') && is_sym(toks, i + 2, '{') {
            if let Some(close) = matching(toks, i + 2) {
                if close + 1 < end && is_sym(toks, close + 1, ':') {
                    add_def(defs, toks, i, close + 2, end, "lambda pattern", previous_line_has_skip(src, toks[i].start));
                    parse_pattern(defs, toks, i + 2, close, close + 2, end, opts, src);
                    parse_expr(defs, toks, close + 2, end, opts, src);
                    return;
                }
            }
        }
        if is_sym(toks, i, '{') {
            if let Some(close) = matching(toks, i) {
                let mut colon = close + 1;
                let mut alias = None;
                if colon + 1 < end && is_sym(toks, colon, '@') && toks[colon + 1].kind == Kind::Ident {
                    alias = Some(colon + 1);
                    colon += 2;
                }
                if colon < end && is_sym(toks, colon, ':') {
                    if let Some(ai) = alias {
                        add_def(defs, toks, ai, i + 1, end, "lambda pattern", previous_line_has_skip(src, toks[ai].start));
                    }
                    parse_pattern(defs, toks, i, close, colon + 1, end, opts, src);
                    parse_expr(defs, toks, colon + 1, end, opts, src);
                    return;
                }
                parse_expr(defs, toks, i + 1, close, opts, src);
                i = close + 1;
                continue;
            }
        }
        i += 1;
    }
}

fn parse_let(defs: &mut Vec<Def>, toks: &[Tok], let_i: usize, in_i: usize, expr_end: usize, opts: &Opts, src: &str) {
    let mut i = let_i + 1;
    while i < in_i {
        if is_ident_text(toks, i, "inherit") {
            let mut j = i + 1;
            if is_sym(toks, j, '(') {
                if let Some(c) = matching(toks, j) {
                    parse_expr(defs, toks, j + 1, c, opts, src);
                    j = c + 1;
                }
            }
            while j < in_i && !is_sym(toks, j, ';') {
                if toks[j].kind == Kind::Ident {
                    if !opts.no_underscore || !toks[j].text.starts_with('_') {
                        add_def(defs, toks, j, let_i + 1, expr_end, "let binding", previous_line_has_skip(src, toks[j].start));
                    }
                }
                j += 1;
            }
            i = j + 1;
        } else if toks[i].kind == Kind::Ident && i + 1 < in_i && is_sym(toks, i + 1, '=') {
            if !opts.no_underscore || !toks[i].text.starts_with('_') {
                add_def(defs, toks, i, let_i + 1, expr_end, "let binding", previous_line_has_skip(src, toks[i].start));
            }
            let rhs_start = i + 2;
            let mut j = rhs_start;
            let mut depth = 0i32;
            while j < in_i {
                match toks[j].kind {
                    Kind::Sym('{') | Kind::Sym('(') | Kind::Sym('[') => depth += 1,
                    Kind::Sym('}') | Kind::Sym(')') | Kind::Sym(']') => depth -= 1,
                    Kind::Sym(';') if depth == 0 => break,
                    _ => {}
                }
                j += 1;
            }
            parse_expr(defs, toks, rhs_start, j, opts, src);
            i = j + 1;
        } else {
            i += 1;
        }
    }
}

fn analyze(src: &str, opts: &Opts) -> Vec<ResultItem> {
    let toks = lex(src);
    let mut defs = Vec::new();
    parse_expr(&mut defs, &toks, 0, toks.len(), opts, src);
    let def_tokens: HashSet<usize> = defs.iter().map(|d| d.def_tok).collect();
    let mut used = vec![false; defs.len()];
    let keywords: HashSet<&str> = ["let", "in", "inherit", "rec", "with", "assert", "if", "then", "else"].iter().copied().collect();
    for (ti, tok) in toks.iter().enumerate() {
        if tok.kind != Kind::Ident || def_tokens.contains(&ti) || keywords.contains(tok.text.as_str()) {
            continue;
        }
        if ti > 0 && is_sym(&toks, ti - 1, '.') {
            continue;
        }
        if ti + 1 < toks.len() && is_sym(&toks, ti + 1, '=') {
            continue;
        }
        let mut best: Option<(usize, usize)> = None;
        for (di, d) in defs.iter().enumerate() {
            if tok.text == d.name && ti >= d.scope_start && ti < d.scope_end {
                let width = d.scope_end.saturating_sub(d.scope_start);
                match best {
                    None => best = Some((di, width)),
                    Some((_, best_width)) if width <= best_width => best = Some((di, width)),
                    _ => {}
                }
            }
        }
        if let Some((di, _)) = best {
            used[di] = true;
        }
    }
    let mut results = Vec::new();
    for (i, d) in defs.iter().enumerate() {
        if d.skip {
            continue;
        }
        if opts.no_underscore && d.name.starts_with('_') {
            continue;
        }
        if !used[i] {
            results.push(ResultItem {
                line: d.line,
                column: d.col,
                end_column: d.end_col,
                message: format!("Unused {}: {}", d.message_kind, d.name),
                start: d.start,
                end: d.end,
            });
        } else if opts.warn_used_underscore && d.name.starts_with('_') {
            results.push(ResultItem {
                line: d.line,
                column: d.col,
                end_column: d.end_col,
                message: format!("Used underscore-prefixed {}: {}", d.message_kind, d.name),
                start: d.start,
                end: d.end,
            });
        }
    }
    results.sort_by_key(|r| (r.line, r.column, r.end_column));
    results
}

fn parse_args() -> Result<Opts, i32> {
    let mut opts = Opts::default();
    let mut args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "--help" => {
                print_help();
                return Err(0);
            }
            "-V" | "--version" => {
                println!("deadnix 1.3.1");
                return Err(0);
            }
            "-l" | "--no-lambda-arg" => opts.no_lambda_arg = true,
            "-L" | "--no-lambda-pattern-names" => opts.no_lambda_pattern_names = true,
            "-_" | "--no-underscore" => opts.no_underscore = true,
            "-W" | "--warn-used-underscore" => opts.warn_used_underscore = true,
            "-q" | "--quiet" => opts.quiet = true,
            "-e" | "--edit" => opts.edit = true,
            "-h" | "--hidden" => opts.hidden = true,
            "-f" | "--fail" => opts.fail = true,
            "-o" | "--output-format" => {
                i += 1;
                if i >= args.len() {
                    eprintln!("error: a value is required for '--output-format <OUTPUT_FORMAT>'");
                    return Err(2);
                }
                opts.json = match args[i].as_str() {
                    "json" => true,
                    "human-readable" => false,
                    _ => {
                        eprintln!("error: invalid value '{}' for '--output-format <OUTPUT_FORMAT>'", args[i]);
                        return Err(2);
                    }
                };
            }
            "--exclude" => {
                i += 1;
                while i < args.len() && args[i] != "--" {
                    opts.excludes.push(args[i].clone());
                    i += 1;
                }
            }
            "--" => {}
            _ if a.starts_with('-') && a.len() > 2 => {
                for ch in a[1..].chars() {
                    match ch {
                        'l' => opts.no_lambda_arg = true,
                        'L' => opts.no_lambda_pattern_names = true,
                        '_' => opts.no_underscore = true,
                        'W' => opts.warn_used_underscore = true,
                        'q' => opts.quiet = true,
                        'e' => opts.edit = true,
                        'h' => opts.hidden = true,
                        'f' => opts.fail = true,
                        _ => opts.paths.push(a.clone()),
                    }
                }
            }
            _ => opts.paths.push(a.clone()),
        }
        i += 1;
    }
    if opts.paths.is_empty() {
        opts.paths.push(".".into());
    }
    args.clear();
    Ok(opts)
}

fn print_help() {
    println!("Find dead code in .nix files\n");
    println!("Usage: executable [OPTIONS] [FILE_PATHS]...\n");
    println!("Arguments:\n  [FILE_PATHS]...  .nix files, or directories with .nix files inside [default: .]\n");
    println!("Options:");
    println!("  -l, --no-lambda-arg                  Don't check lambda parameter arguments");
    println!("  -L, --no-lambda-pattern-names        Don't check lambda attrset pattern names (don't break nixpkgs callPackage)");
    println!("  -_, --no-underscore                  Don't check any bindings that start with a _");
    println!("  -W, --warn-used-underscore           Warn if bindings are referenced that start with '_'");
    println!("  -q, --quiet                          Don't print dead code report");
    println!("  -e, --edit                           Remove unused code and write to source file");
    println!("  -h, --hidden                         Recurse into hidden subdirectories and process hidden .*.nix files");
    println!("      --help                           ");
    println!("  -f, --fail                           Exit with 1 if unused code has been found");
    println!("  -o, --output-format <OUTPUT_FORMAT>  Output format to use [default: human-readable] [possible values: human-readable, json]");
    println!("      --exclude <EXCLUDES>...          Files to exclude from analysis");
    println!("  -V, --version                        Print version");
}

fn collect_files(path: &Path, opts: &Opts, out: &mut Vec<PathBuf>) {
    let s = path.to_string_lossy().to_string();
    if opts.excludes.iter().any(|e| s == *e || s.ends_with(e)) {
        return;
    }
    let name = path.file_name().and_then(|x| x.to_str()).unwrap_or("");
    if !opts.hidden && name.starts_with('.') && name != "." {
        return;
    }
    if path.is_file() {
        if path.extension().and_then(|x| x.to_str()) == Some("nix") {
            out.push(path.to_path_buf());
        }
    } else if path.is_dir() {
        if let Ok(rd) = fs::read_dir(path) {
            let mut entries: Vec<_> = rd.filter_map(Result::ok).collect();
            entries.sort_by_key(|e| e.path());
            for e in entries {
                collect_files(&e.path(), opts, out);
            }
        }
    }
}

fn json_escape(s: &str) -> String {
    s.chars().flat_map(|c| match c {
        '"' => "\\\"".chars().collect::<Vec<_>>(),
        '\\' => "\\\\".chars().collect(),
        '\n' => "\\n".chars().collect(),
        '\r' => "\\r".chars().collect(),
        '\t' => "\\t".chars().collect(),
        _ => vec![c],
    }).collect()
}

fn print_json(all: &[(String, Vec<ResultItem>)]) {
    print!("[");
    for (fi, (file, res)) in all.iter().enumerate() {
        if fi > 0 { print!(","); }
        print!("{{\"file\":\"{}\",\"results\":[", json_escape(file));
        for (ri, r) in res.iter().enumerate() {
            if ri > 0 { print!(","); }
            print!("{{\"column\":{},\"endColumn\":{},\"line\":{},\"message\":\"{}\"}}",
                   r.column, r.end_column, r.line, json_escape(&r.message));
        }
        print!("]}}");
    }
    println!("]");
}

fn print_human(file: &str, src: &str, res: &[ResultItem]) {
    if res.is_empty() {
        return;
    }
    println!("Warning: Unused declarations were found.");
    for r in res {
        let line_text = src.lines().nth(r.line - 1).unwrap_or("");
        println!("   ╭─[{}:{}:{}]", file, r.line, r.column);
        println!("{:>3} │{}", r.line, line_text);
        let spaces = " ".repeat(r.column.saturating_sub(1));
        println!("    │{}╰{} {}", spaces, "─".repeat((r.end_column - r.column).saturating_sub(1)), r.message);
    }
}

fn apply_edit(src: &str, res: &[ResultItem]) -> String {
    let mut remove_lines = HashSet::new();
    let mut replacements: Vec<(usize, usize, String)> = Vec::new();
    for r in res {
        if r.message.contains("Unused let binding") {
            remove_lines.insert(r.line);
        } else if (r.message.contains("Unused lambda argument") || r.message.contains("Unused lambda pattern"))
            && !src[r.start..r.end].starts_with('_') {
            replacements.push((r.start, r.end, format!("_{}", &src[r.start..r.end])));
        }
    }
    let mut edited = String::new();
    for (idx, line) in src.split_inclusive('\n').enumerate() {
        if !remove_lines.contains(&(idx + 1)) {
            edited.push_str(line);
        }
    }
    if remove_lines.is_empty() {
        replacements.sort_by_key(|x| x.0);
        let mut out = String::new();
        let mut last = 0;
        for (s, e, rep) in replacements {
            out.push_str(&src[last..s]);
            out.push_str(&rep);
            last = e;
        }
        out.push_str(&src[last..]);
        out
    } else {
        edited
    }
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err(code) => std::process::exit(code),
    };
    let mut files = Vec::new();
    for p in &opts.paths {
        collect_files(Path::new(p), &opts, &mut files);
    }
    files.sort();
    let mut any = false;
    let mut all = Vec::new();
    for p in files {
        let path_s = p.to_string_lossy().to_string();
        match fs::read_to_string(&p) {
            Ok(src) => {
                let res = analyze(&src, &opts);
                if !res.is_empty() {
                    any = true;
                }
                if opts.edit && !res.is_empty() {
                    let edited = apply_edit(&src, &res);
                    let _ = fs::write(&p, edited);
                }
                if opts.json {
                    all.push((path_s, res));
                } else if !opts.quiet {
                    print_human(&path_s, &src, &res);
                }
            }
            Err(e) => {
                let _ = writeln!(io::stderr(), "{}: {}", path_s, e);
            }
        }
    }
    if opts.json && !opts.quiet {
        let nonempty: Vec<_> = all.into_iter().filter(|(_, r)| !r.is_empty()).collect();
        print_json(&nonempty);
    }
    if opts.fail && any {
        std::process::exit(1);
    }
}
