use std::process::Command;

fn main() {
    let out_dir = std::env::var("OUT_DIR").unwrap();
    let obj = format!("{out_dir}/jpeg_bridge.o");
    let lib = format!("{out_dir}/libjpeg_bridge.a");

    let status = Command::new("gcc")
        .args([
            "-c",
            "src/jpeg_bridge.c",
            "-O2",
            "-fPIC",
            "-o",
            &obj,
        ])
        .status()
        .expect("failed to run gcc");
    assert!(status.success(), "gcc failed");

    let status = Command::new("ar")
        .args(["crus", &lib, &obj])
        .status()
        .expect("failed to run ar");
    assert!(status.success(), "ar failed");

    println!("cargo:rustc-link-search=native={out_dir}");
    println!("cargo:rustc-link-lib=static=jpeg_bridge");
    println!("cargo:rustc-link-lib=jpeg");
    println!("cargo:rerun-if-changed=src/jpeg_bridge.c");
}
