use std::ffi::c_char;
use std::fs;
use std::io::{self, Read, Write};
use std::os::raw::{c_int, c_uchar, c_ulong};

const VERSION: &str = "jp2a 1.0.8";
const PALETTE: &str = "   ...',;:clodxkO0KXNWM";

extern "C" {
    fn decode_jpeg_memory(
        input: *const c_uchar,
        input_len: c_ulong,
        out_pixels: *mut *mut c_uchar,
        out_w: *mut c_int,
        out_h: *mut c_int,
        out_components: *mut c_int,
        errbuf: *mut c_char,
        errbuf_len: c_int,
    ) -> c_int;
    fn free_jpeg_pixels(ptr: *mut c_uchar);
}

#[derive(Clone)]
struct Options {
    border: bool,
    chars: Vec<char>,
    clear: bool,
    colors: bool,
    fill: bool,
    flipx: bool,
    flipy: bool,
    grayscale: bool,
    html: bool,
    html_raw: bool,
    html_no_bold: bool,
    html_fontsize: i32,
    html_title: String,
    invert: bool,
    output: Option<String>,
    red: f32,
    green: f32,
    blue: f32,
    term_fit: bool,
    term_height: bool,
    term_width: bool,
    term_zoom: bool,
    verbose: bool,
    width: Option<usize>,
    height: Option<usize>,
    files: Vec<String>,
}

struct Image {
    width: usize,
    height: usize,
    comps: usize,
    pixels: Vec<u8>,
}

fn version_text() -> String {
    format!("{VERSION}\nCopyright 2006-2016 Christian Stigen Larsen\nDistributed under the GNU General Public License (GPL) v2.\n")
}

fn help_text() -> String {
    format!(
"{ver}
Usage: jp2a [ options ] [ file(s) | URL(s) ]

Convert files or URLs from JPEG format to ASCII.

OPTIONS
  -                 Read images from standard input.
      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145
  -b, --border      Print a border around the output image.
      --chars=...   Select character palette used to paint the image.
                    Leftmost character corresponds to black pixel, right-
                    most to white.  Minimum two characters must be specified.
      --clear       Clears screen before drawing each output image.
      --colors      Use ANSI colors in output.
  -d, --debug       Print additional debug information.
      --fill        When used with --color and/or --html, color each character's
                    background color.
  -x, --flipx       Flip image in X direction.
  -y, --flipy       Flip image in Y direction.
  -f, --term-fit    Use the largest image dimension that fits in your terminal
                    display with correct aspect ratio.
      --term-height Use terminal display height.
      --term-width  Use terminal display width.
  -z, --term-zoom   Use terminal display dimension for output.
      --grayscale   Convert image to grayscale when using --html or --colors
      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866
      --height=N    Set output height, calculate width from aspect ratio.
  -h, --help        Print program help.
      --html        Produce strict XHTML 1.0 output.
      --html-fill   Same as --fill (will be phased out)
      --html-fontsize=N   Set fontsize to N pt, default is 4.
      --html-no-bold      Do not use bold characters with HTML output
      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.
      --html-title=...  Set HTML output title
  -i, --invert      Invert output image.  Use if your display has a dark
                    background.
      --background=dark   These are just mnemonics whether to use --invert
      --background=light  or not.  If your console has light characters on
                    a dark background, use --background=dark.
      --output=...  Write output to file.
      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.
      --size=WxH    Set output width and height.
  -v, --verbose     Verbose output.
  -V, --version     Print program version.
      --width=N     Set output width, calculate height from ratio.

  The default mode is `jp2a --term-fit --background=dark'.
  See the man-page for jp2a for more detailed help text.

Project homepage on https://github.com/cslarsen/jp2a
Report bugs to <csl@csl.name>
", ver = version_text())
}

fn parse_num<T: std::str::FromStr>(s: &str, name: &str) -> Result<T, String> {
    s.parse::<T>().map_err(|_| format!("Invalid value for {name}: {s}"))
}

fn parse_args() -> Result<Option<Options>, String> {
    let mut opt = Options {
        border: false, chars: PALETTE.chars().collect(), clear: false, colors: false,
        fill: false, flipx: false, flipy: false, grayscale: false, html: false,
        html_raw: false, html_no_bold: false, html_fontsize: 4,
        html_title: "jp2a converted image".to_string(), invert: false, output: None,
        red: 0.2989, green: 0.5866, blue: 0.1145, term_fit: true, term_height: false,
        term_width: false, term_zoom: false, verbose: false, width: None, height: None,
        files: Vec::new(),
    };

    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        macro_rules! value {
            ($prefix:expr) => {{
                if let Some(v) = a.strip_prefix(concat!($prefix, "=")) {
                    v.to_string()
                } else {
                    i += 1;
                    if i >= args.len() { return Err(format!("Option {} requires an argument", $prefix)); }
                    args[i].clone()
                }
            }};
        }
        match a.as_str() {
            "-h" | "--help" => {
                print!("{}", help_text());
                return Ok(None);
            }
            "-V" | "--version" => {
                print!("{}", version_text());
                return Ok(None);
            }
            "-b" | "--border" => opt.border = true,
            "--clear" => opt.clear = true,
            "--colors" | "--color" => opt.colors = true,
            "-d" | "--debug" => {}
            "--fill" | "--html-fill" => opt.fill = true,
            "-x" | "--flipx" => opt.flipx = true,
            "-y" | "--flipy" => opt.flipy = true,
            "-f" | "--term-fit" => { opt.term_fit = true; opt.term_width = false; opt.term_height = false; opt.term_zoom = false; }
            "--term-height" => { opt.term_fit = false; opt.term_height = true; }
            "--term-width" => { opt.term_fit = false; opt.term_width = true; }
            "-z" | "--term-zoom" | "--zoom" => { opt.term_fit = false; opt.term_zoom = true; }
            "--grayscale" => opt.grayscale = true,
            "--html" => opt.html = true,
            "--html-raw" => { opt.html = true; opt.html_raw = true; }
            "--html-no-bold" => opt.html_no_bold = true,
            "-i" | "--invert" => opt.invert = !opt.invert,
            "--background=dark" => opt.invert = false,
            "--background=light" => opt.invert = true,
            "-v" | "--verbose" => opt.verbose = true,
            "-" => opt.files.push("-".to_string()),
            _ if a.starts_with("--chars") => {
                let v = value!("--chars");
                let chars: Vec<char> = v.chars().collect();
                if chars.len() < 2 {
                    return Err("You must specify at least two characters in --chars.".to_string());
                }
                opt.chars = chars;
            }
            _ if a.starts_with("--html-fontsize") => opt.html_fontsize = parse_num(&value!("--html-fontsize"), "--html-fontsize")?,
            _ if a.starts_with("--html-title") => opt.html_title = value!("--html-title"),
            _ if a.starts_with("--output") => opt.output = Some(value!("--output")),
            _ if a.starts_with("--red") => opt.red = parse_num(&value!("--red"), "--red")?,
            _ if a.starts_with("--green") => opt.green = parse_num(&value!("--green"), "--green")?,
            _ if a.starts_with("--blue") => opt.blue = parse_num(&value!("--blue"), "--blue")?,
            _ if a.starts_with("--width") => { opt.term_fit = false; opt.width = Some(parse_num(&value!("--width"), "--width")?); }
            _ if a.starts_with("--height") => { opt.term_fit = false; opt.height = Some(parse_num(&value!("--height"), "--height")?); }
            _ if a.starts_with("--size") => {
                opt.term_fit = false;
                let v = value!("--size");
                let (w, h) = v.split_once('x').or_else(|| v.split_once('X')).ok_or_else(|| format!("Invalid size: {v}"))?;
                opt.width = Some(parse_num(w, "--size")?);
                opt.height = Some(parse_num(h, "--size")?);
            }
            _ if a.starts_with('-') => return Err(format!("Unknown option {a}")),
            _ => opt.files.push(a.clone()),
        }
        i += 1;
    }
    if opt.files.is_empty() {
        return Err("No input files specified.".to_string());
    }
    Ok(Some(opt))
}

fn decode_jpeg(data: &[u8]) -> Result<Image, String> {
    unsafe {
        let mut ptr: *mut c_uchar = std::ptr::null_mut();
        let mut w: c_int = 0;
        let mut h: c_int = 0;
        let mut c: c_int = 0;
        let mut err = vec![0i8; 512];
        let ok = decode_jpeg_memory(
            data.as_ptr(), data.len() as c_ulong, &mut ptr, &mut w, &mut h, &mut c,
            err.as_mut_ptr(), err.len() as c_int,
        );
        if ok == 0 {
            let msg = err.iter().take_while(|&&b| b != 0).map(|&b| b as u8 as char).collect::<String>();
            return Err(if msg.is_empty() { "Not a JPEG file".to_string() } else { msg });
        }
        let len = w as usize * h as usize * c as usize;
        let pixels = std::slice::from_raw_parts(ptr, len).to_vec();
        free_jpeg_pixels(ptr);
        Ok(Image { width: w as usize, height: h as usize, comps: c as usize, pixels })
    }
}

fn terminal_size() -> (usize, usize) {
    let cols: usize = std::env::var("COLUMNS").ok().and_then(|v| v.parse().ok()).unwrap_or(80);
    let lines: usize = std::env::var("LINES").ok().and_then(|v| v.parse().ok()).unwrap_or(24);
    (cols.saturating_sub(6).max(1), lines.saturating_sub(1).max(1))
}

fn output_size(opt: &Options, img: &Image) -> (usize, usize) {
    if opt.term_zoom {
        return terminal_size();
    }
    if opt.term_width {
        let (tw, _) = terminal_size();
        return (tw, ((tw as f64 * img.height as f64) / (img.width as f64 * 2.0)).floor().max(1.0) as usize);
    }
    if opt.term_height {
        let (_, th) = terminal_size();
        return (((th as f64 * img.width as f64 * 2.0) / img.height as f64).round().max(1.0) as usize, th);
    }
    match (opt.width, opt.height) {
        (Some(w), Some(h)) => (w.max(1), h.max(1)),
        (Some(w), None) => (w.max(1), ((w as f64 * img.height as f64) / (img.width as f64 * 2.0)).floor().max(1.0) as usize),
        (None, Some(h)) => (((h as f64 * img.width as f64 * 2.0) / img.height as f64).round().max(1.0) as usize, h.max(1)),
        (None, None) => {
            let (tw, th) = terminal_size();
            let by_h = ((th as f64 * img.width as f64 * 2.0) / img.height as f64).round() as usize;
            if by_h <= tw {
                (by_h.max(1), th.max(1))
            } else {
                (tw.max(1), ((tw as f64 * img.height as f64) / (img.width as f64 * 2.0)).floor().max(1.0) as usize)
            }
        }
    }
}

fn sample_rgb(img: &Image, x: usize, y: usize) -> (u8, u8, u8) {
    let idx = (y * img.width + x) * img.comps;
    match img.comps {
        1 => { let g = img.pixels[idx]; (g, g, g) }
        3 | 4 => (img.pixels[idx], img.pixels[idx + 1], img.pixels[idx + 2]),
        _ => { let g = img.pixels[idx]; (g, g, g) }
    }
}

fn average_rgb(img: &Image, x0: usize, x1: usize, y0: usize, y1: usize) -> (u8, u8, u8) {
    let mut rs: u64 = 0;
    let mut gs: u64 = 0;
    let mut bs: u64 = 0;
    let mut n: u64 = 0;
    for y in y0..y1.max(y0 + 1).min(img.height) {
        for x in x0..x1.max(x0 + 1).min(img.width) {
            let (r, g, b) = sample_rgb(img, x, y);
            rs += r as u64;
            gs += g as u64;
            bs += b as u64;
            n += 1;
        }
    }
    if n == 0 {
        return sample_rgb(img, x0.min(img.width - 1), y0.min(img.height - 1));
    }
    ((rs / n) as u8, (gs / n) as u8, (bs / n) as u8)
}

fn html_escape(c: char) -> String {
    match c {
        '<' => "&lt;".to_string(),
        '>' => "&gt;".to_string(),
        '&' => "&amp;".to_string(),
        '"' => "&quot;".to_string(),
        _ => c.to_string(),
    }
}

fn render_ascii(opt: &Options, img: &Image, name: &str) -> String {
    let (ow, oh) = output_size(opt, img);
    if opt.verbose {
        eprintln!("File: {name}");
        eprintln!("Source width: {}", img.width);
        eprintln!("Source height: {}", img.height);
        eprintln!("Source color components: {}", img.comps);
        eprintln!("Output width: {ow}");
        eprintln!("Output height: {oh}");
        eprintln!("Output palette ({} chars): '{}'", opt.chars.len(), opt.chars.iter().collect::<String>());
    }
    let mut rows: Vec<String> = Vec::with_capacity(oh);
    let plen = opt.chars.len();
    for oy in 0..oh {
        let mut line = String::new();
        for ox in 0..ow {
            let ax0 = ox * img.width / ow;
            let ax1 = (ox + 1) * img.width / ow;
            let (sx0, sx1) = if opt.flipx {
                (img.width - ax1.max(ax0 + 1).min(img.width), img.width - ax0)
            } else {
                (ax0, ax1)
            };
            let ay0 = oy * img.height / oh;
            let ay1 = (oy + 1) * img.height / oh;
            let (sy0, sy1) = if opt.flipy {
                (img.height - ay1.max(ay0 + 1).min(img.height), img.height - ay0)
            } else {
                (ay0, ay1)
            };
            let (r, g, b) = average_rgb(img, sx0, sx1, sy0, sy1);
            let lum = (r as f32 * opt.red + g as f32 * opt.green + b as f32 * opt.blue).round().clamp(0.0, 255.0) as usize;
            let val = if opt.invert { 255 - lum } else { lum };
            let idx = (val * (plen - 1)) / 255;
            let ch = opt.chars[idx];
            if opt.colors && !opt.html && !opt.grayscale {
                if opt.fill {
                    line.push_str(&format!("\x1b[48;2;{r};{g};{b}m{ch}\x1b[0m"));
                } else {
                    line.push_str(&format!("\x1b[38;2;{r};{g};{b}m{ch}\x1b[0m"));
                }
            } else if opt.html && opt.colors && !opt.grayscale {
                if opt.fill {
                    line.push_str(&format!("<span style='color:rgb({r},{g},{b}); background-color:rgb({r},{g},{b});'>{}</span>", html_escape(ch)));
                } else {
                    line.push_str(&format!("<span style='color:rgb({r},{g},{b});'>{}</span>", html_escape(ch)));
                }
            } else {
                line.push(ch);
            }
        }
        rows.push(line);
    }
    if opt.border && !opt.html {
        let mut out = String::new();
        out.push('+'); out.push_str(&"-".repeat(ow)); out.push_str("+\n");
        for row in rows {
            out.push('|'); out.push_str(&row); out.push_str("|\n");
        }
        out.push('+'); out.push_str(&"-".repeat(ow)); out.push_str("+\n");
        out
    } else {
        let mut out = rows.join("\n");
        out.push('\n');
        out
    }
}

fn render_html(opt: &Options, body: &str) -> String {
    if opt.html_raw {
        return body.to_string();
    }
    let bg = if opt.invert { "black" } else { "white" };
    let fg = if opt.invert { "white" } else { "black" };
    let weight = if opt.html_no_bold { "normal" } else { "bold" };
    format!(
"<?xml version='1.0' encoding='ISO-8859-1'?>
<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>
<head>
<title>{}</title>
<style type='text/css'>
body {{
background-color: {};
}}
.ascii {{
   font-family: Courier;
   color: {};
   font-size:{}pt;
   font-weight: {};
}}
</style>
</head>
<body>
<div class='ascii'><pre>
{}</pre>
</div>
</body>
</html>
", opt.html_title, bg, fg, opt.html_fontsize * 2, weight, body)
}

fn read_input(path: &str) -> Result<Vec<u8>, String> {
    if path == "-" {
        let mut data = Vec::new();
        io::stdin().read_to_end(&mut data).map_err(|e| e.to_string())?;
        return Ok(data);
    }
    if path.starts_with("http://") || path.starts_with("https://") || path.starts_with("ftp://") {
        return Err(format!("Cannot download URL: {path}"));
    }
    fs::read(path).map_err(|_| format!("Could not open file: {path}"))
}

fn run() -> Result<(), String> {
    let opt = match parse_args()? {
        Some(o) => o,
        None => return Ok(()),
    };
    let mut all = String::new();
    if opt.clear {
        all.push_str("\x1b[H\x1b[2J");
    }
    for path in &opt.files {
        let data = read_input(path)?;
        let img = decode_jpeg(&data).map_err(|e| format!("{path}: {e}"))?;
        let mut rendered = render_ascii(&opt, &img, path);
        if opt.html {
            rendered = render_html(&opt, &rendered);
        }
        all.push_str(&rendered);
    }
    match opt.output.as_deref() {
        Some("-") | None => {
            print!("{all}");
            io::stdout().flush().ok();
        }
        Some(path) => fs::write(path, all).map_err(|e| e.to_string())?,
    }
    Ok(())
}

fn main() {
    if std::env::var_os("TERM").is_none()
        && std::env::args().skip(1).any(|a| a != "--help" && a != "-h" && a != "--version" && a != "-V")
    {
        eprintln!("Environment variable TERM not set.");
        std::process::exit(1);
    }
    if let Err(e) = run() {
        eprintln!("{e}");
        if e.starts_with("Unknown option") {
            eprintln!();
            print!("{}", help_text());
        }
        std::process::exit(1);
    }
}
