#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <jpeglib.h>

struct my_error_mgr {
    struct jpeg_error_mgr pub;
    jmp_buf setjmp_buffer;
    char message[JMSG_LENGTH_MAX];
};

typedef struct my_error_mgr * my_error_ptr;

static void my_error_exit(j_common_ptr cinfo) {
    my_error_ptr myerr = (my_error_ptr)cinfo->err;
    (*cinfo->err->format_message)(cinfo, myerr->message);
    longjmp(myerr->setjmp_buffer, 1);
}

int decode_jpeg_memory(const unsigned char *input, unsigned long input_len,
                       unsigned char **out_pixels, int *out_w, int *out_h,
                       int *out_components, char *errbuf, int errbuf_len) {
    struct jpeg_decompress_struct cinfo;
    struct my_error_mgr jerr;
    JSAMPARRAY buffer;
    int row_stride;
    unsigned long total;

    *out_pixels = NULL;
    *out_w = *out_h = *out_components = 0;
    if (errbuf && errbuf_len > 0) errbuf[0] = 0;

    cinfo.err = jpeg_std_error(&jerr.pub);
    jerr.pub.error_exit = my_error_exit;
    if (setjmp(jerr.setjmp_buffer)) {
        if (errbuf && errbuf_len > 0) {
            snprintf(errbuf, errbuf_len, "%s", jerr.message);
        }
        jpeg_destroy_decompress(&cinfo);
        if (*out_pixels) {
            free(*out_pixels);
            *out_pixels = NULL;
        }
        return 0;
    }

    jpeg_create_decompress(&cinfo);
    jpeg_mem_src(&cinfo, input, input_len);
    jpeg_read_header(&cinfo, TRUE);
    jpeg_start_decompress(&cinfo);

    row_stride = cinfo.output_width * cinfo.output_components;
    total = (unsigned long)row_stride * (unsigned long)cinfo.output_height;
    *out_pixels = (unsigned char*)malloc(total ? total : 1);
    if (!*out_pixels) {
        snprintf(errbuf, errbuf_len, "Out of memory");
        jpeg_destroy_decompress(&cinfo);
        return 0;
    }

    buffer = (*cinfo.mem->alloc_sarray)((j_common_ptr)&cinfo, JPOOL_IMAGE, row_stride, 1);
    while (cinfo.output_scanline < cinfo.output_height) {
        unsigned int y = cinfo.output_scanline;
        jpeg_read_scanlines(&cinfo, buffer, 1);
        memcpy(*out_pixels + (unsigned long)y * row_stride, buffer[0], row_stride);
    }

    *out_w = (int)cinfo.output_width;
    *out_h = (int)cinfo.output_height;
    *out_components = (int)cinfo.output_components;
    jpeg_finish_decompress(&cinfo);
    jpeg_destroy_decompress(&cinfo);
    return 1;
}

void free_jpeg_pixels(unsigned char *ptr) {
    free(ptr);
}
