use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

#[derive(Clone, Debug)]
struct Opts {
    paths: Vec<String>,
    format: String,
    output: Option<String>,
    by_file: bool,
    ci: bool,
    no_cocomo: bool,
    no_size: bool,
    no_complexity: bool,
    no_duplicates: bool,
    wide: bool,
    percent: bool,
    uloc: bool,
    dryness: bool,
    character: bool,
    languages: bool,
    version: bool,
    help: bool,
    include_ext: HashSet<String>,
    exclude_ext: HashSet<String>,
    exclude_dirs: HashSet<String>,
    exclude_files: HashSet<String>,
    no_gitignore: bool,
    no_ignore: bool,
    no_sccignore: bool,
    no_large: bool,
    large_byte_count: usize,
    large_line_count: usize,
    include_symlinks: bool,
    count_ignore: bool,
    count_as: HashMap<String, String>,
    sort: String,
    currency: String,
    avg_wage: f64,
    project_type: String,
    sql_project: String,
}

#[derive(Clone, Debug, Default)]
struct FileStat {
    language: String,
    path: String,
    bytes: usize,
    lines: usize,
    code: usize,
    comments: usize,
    blanks: usize,
    complexity: usize,
    uloc: usize,
    max_len: usize,
    mean_len: usize,
}

#[derive(Clone, Debug, Default)]
struct Summary {
    language: String,
    files: usize,
    bytes: usize,
    lines: usize,
    code: usize,
    comments: usize,
    blanks: usize,
    complexity: usize,
    uloc: usize,
    max_len: usize,
    mean_len: usize,
    file_stats: Vec<FileStat>,
}

fn main() {
    let opts = parse_args();
    if opts.help {
        print_help();
        return;
    }
    if opts.version {
        println!("scc version 3.7.0");
        return;
    }
    if opts.languages {
        print_languages();
        return;
    }

    let paths: Vec<PathBuf> = if opts.paths.is_empty() {
        vec![PathBuf::from(".")]
    } else {
        opts.paths.iter().map(PathBuf::from).collect()
    };

    let files = discover_files(&paths, &opts);
    let mut stats = Vec::new();
    let mut seen = HashSet::new();
    for path in files {
        if opts.no_duplicates {
            if let Ok(bytes) = fs::read(&path) {
                let key = format!("{:x}", simple_hash(&bytes));
                if !seen.insert(key) { continue; }
            }
        }
        if let Some(st) = process_file(&path, &opts) {
            stats.push(st);
        }
    }
    let summaries = summarize(&stats, &opts);
    let out = match opts.format.as_str() {
        "json" => format_json(&summaries, false),
        "json2" => format_json2(&summaries),
        "csv" => format_csv(&summaries),
        "csv-stream" => format_csv_stream(&stats),
        "cloc-yaml" => format_yaml(&summaries),
        "openmetrics" => format_openmetrics(&summaries),
        "html" => format_html(&summaries, &opts),
        "html-table" => format_html_table(&summaries, &opts),
        "sql" | "sql-insert" => format_sql(&summaries, &stats, &opts),
        "wide" => {
            let mut o = opts.clone();
            o.wide = true;
            format_table(&summaries, &stats, &o)
        }
        _ => format_table(&summaries, &stats, &opts),
    };

    if let Some(path) = &opts.output {
        if let Err(e) = fs::write(path, out) {
            eprintln!("Error: {}", e);
            std::process::exit(1);
        }
    } else {
        print!("{}", out);
        let _ = io::stdout().flush();
    }
}

fn parse_args() -> Opts {
    let mut opts = Opts {
        format: "tabular".into(),
        exclude_dirs: [".git", ".hg", ".svn"].iter().map(|s| s.to_string()).collect(),
        exclude_files: ["package-lock.json", "Cargo.lock", "yarn.lock", "pubspec.lock", "Podfile.lock", "pnpm-lock.yaml"].iter().map(|s| s.to_string()).collect(),
        large_byte_count: 1_000_000,
        large_line_count: 40_000,
        sort: "files".into(),
        currency: "$".into(),
        avg_wage: 56286.0,
        project_type: "organic".into(),
        sql_project: "Project".into(),
        ..Default::default()
    };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let mut val: Option<String> = None;
        let key = if let Some((k, v)) = a.split_once('=') {
            val = Some(v.to_string());
            k.to_string()
        } else {
            a.to_string()
        };
        let mut take = |i: &mut usize| -> String {
            if let Some(v) = val.take() { v } else { *i += 1; args.get(*i).cloned().unwrap_or_default() }
        };
        match key.as_str() {
            "-h" | "--help" => opts.help = true,
            "--version" => opts.version = true,
            "-l" | "--languages" => opts.languages = true,
            "-f" | "--format" => opts.format = take(&mut i),
            "-o" | "--output" => opts.output = Some(take(&mut i)),
            "--by-file" => opts.by_file = true,
            "--ci" => opts.ci = true,
            "--no-cocomo" => opts.no_cocomo = true,
            "--no-size" => opts.no_size = true,
            "-c" | "--no-complexity" => opts.no_complexity = true,
            "-d" | "--no-duplicates" => opts.no_duplicates = true,
            "-w" | "--wide" => opts.wide = true,
            "-p" | "--percent" => opts.percent = true,
            "-u" | "--uloc" => opts.uloc = true,
            "-a" | "--dryness" => { opts.dryness = true; opts.uloc = true; },
            "-m" | "--character" => opts.character = true,
            "-i" | "--include-ext" => opts.include_ext.extend(split_list(&take(&mut i))),
            "-x" | "--exclude-ext" => opts.exclude_ext.extend(split_list(&take(&mut i))),
            "--exclude-dir" => opts.exclude_dirs = split_list(&take(&mut i)),
            "-n" | "--exclude-file" => opts.exclude_files.extend(split_list(&take(&mut i))),
            "--no-gitignore" => opts.no_gitignore = true,
            "--no-ignore" => opts.no_ignore = true,
            "--no-scc-ignore" => opts.no_sccignore = true,
            "--no-large" => opts.no_large = true,
            "--include-symlinks" => opts.include_symlinks = true,
            "--count-ignore" => opts.count_ignore = true,
            "--large-byte-count" => opts.large_byte_count = take(&mut i).parse().unwrap_or(1_000_000),
            "--large-line-count" => opts.large_line_count = take(&mut i).parse().unwrap_or(40_000),
            "-s" | "--sort" => opts.sort = take(&mut i),
            "--currency-symbol" => opts.currency = take(&mut i),
            "--avg-wage" => opts.avg_wage = take(&mut i).parse().unwrap_or(56286.0),
            "--cocomo-project-type" => opts.project_type = take(&mut i),
            "--sql-project" => opts.sql_project = take(&mut i),
            "--count-as" => parse_count_as(&take(&mut i), &mut opts.count_as),
            "--binary" | "--debug" | "--trace" | "--verbose" | "--gen" | "--min" | "-z" | "--min-gen" |
            "--no-gen" | "--no-min" | "--no-min-gen" | "--locomo" | "--cost-comparison" | "--sloccount-format" |
            "--mcp" => {}
            "--directory-walker-job-workers" | "--file-gc-count" | "--file-list-queue-size" |
            "--file-process-job-workers" | "--file-summary-job-queue-size" | "--eaf" | "--overhead" |
            "--remap-all" | "--remap-unknown" | "--size-unit" | "--locomo-config" | "--locomo-cycles" |
            "--locomo-input-price" | "--locomo-output-price" | "--locomo-preset" | "--locomo-review" |
            "--locomo-tps" | "--min-gen-line-length" | "-M" | "--not-match" | "--generated-markers" => { let _ = take(&mut i); }
            _ if key.starts_with('-') => {}
            _ => opts.paths.push(a.clone()),
        }
        i += 1;
    }
    opts
}

impl Default for Opts {
    fn default() -> Self {
        Self {
            paths: Vec::new(), format: String::new(), output: None, by_file: false, ci: false,
            no_cocomo: false, no_size: false, no_complexity: false, no_duplicates: false, wide: false, percent: false,
            uloc: false, dryness: false, character: false, languages: false, version: false, help: false,
            include_ext: HashSet::new(), exclude_ext: HashSet::new(), exclude_dirs: HashSet::new(),
            exclude_files: HashSet::new(), no_gitignore: false, no_ignore: false, no_sccignore: false,
            no_large: false, large_byte_count: 0, large_line_count: 0, include_symlinks: false,
            count_ignore: false, count_as: HashMap::new(), sort: String::new(), currency: String::new(),
            avg_wage: 0.0, project_type: String::new(), sql_project: String::new(),
        }
    }
}

fn split_list(s: &str) -> HashSet<String> {
    s.split(',').filter(|x| !x.is_empty()).map(|x| x.trim().trim_matches('"').to_lowercase()).collect()
}

fn parse_count_as(s: &str, map: &mut HashMap<String, String>) {
    for part in s.split(',') {
        if let Some((from, to)) = part.split_once(':') {
            map.insert(from.trim().trim_start_matches('.').to_lowercase(), to.trim().trim_matches('"').to_string());
        }
    }
}

fn discover_files(paths: &[PathBuf], opts: &Opts) -> Vec<PathBuf> {
    let mut out = Vec::new();
    for p in paths {
        walk(p, opts, &mut out);
    }
    out.sort();
    out
}

fn walk(path: &Path, opts: &Opts, out: &mut Vec<PathBuf>) {
    let meta = match fs::symlink_metadata(path) { Ok(m) => m, Err(_) => return };
    if meta.file_type().is_symlink() && !opts.include_symlinks { return; }
    if meta.is_dir() {
        let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
        if opts.exclude_dirs.contains(&name.to_lowercase()) { return; }
        let ignores = read_ignore_files(path, opts);
        if let Ok(rd) = fs::read_dir(path) {
            for ent in rd.flatten() {
                let p = ent.path();
                let nm = p.file_name().and_then(|s| s.to_str()).unwrap_or("").to_string();
                if !opts.count_ignore && ignores.iter().any(|pat| simple_match(pat, &nm)) { continue; }
                walk(&p, opts, out);
            }
        }
    } else if meta.is_file() {
        if should_consider(path, opts) {
            out.push(path.to_path_buf());
        }
    }
}

fn read_ignore_files(dir: &Path, opts: &Opts) -> Vec<String> {
    let mut pats = Vec::new();
    let names = [(".gitignore", opts.no_gitignore), (".ignore", opts.no_ignore), (".sccignore", opts.no_sccignore)];
    for (name, disabled) in names {
        if disabled { continue; }
        if let Ok(s) = fs::read_to_string(dir.join(name)) {
            for line in s.lines() {
                let t = line.trim();
                if !t.is_empty() && !t.starts_with('#') { pats.push(t.trim_matches('/').to_string()); }
            }
        }
    }
    pats
}

fn simple_match(pat: &str, name: &str) -> bool {
    if pat == name { return true; }
    if let Some(suf) = pat.strip_prefix("*.") { return name.ends_with(&format!(".{}", suf)); }
    if pat.contains('*') {
        let parts: Vec<&str> = pat.split('*').collect();
        return parts.iter().all(|p| p.is_empty() || name.contains(p));
    }
    false
}

fn should_consider(path: &Path, opts: &Opts) -> bool {
    let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
    if opts.exclude_files.contains(name) { return false; }
    if !opts.count_ignore && (name == ".gitignore" || name == ".ignore" || name == ".sccignore") { return false; }
    let ext = ext_of(path);
    if opts.exclude_ext.contains(&ext) { return false; }
    if !opts.include_ext.is_empty() && !opts.include_ext.contains(&ext) { return false; }
    true
}

fn process_file(path: &Path, opts: &Opts) -> Option<FileStat> {
    let bytes = fs::read(path).ok()?;
    if !opts.no_large && bytes.len() > opts.large_byte_count { return None; }
    if bytes.iter().take(8000).any(|b| *b == 0) { return None; }
    let text = String::from_utf8_lossy(&bytes);
    let line_count = if text.is_empty() { 0 } else { text.lines().count() + if text.ends_with('\n') { 0 } else { 0 } };
    if !opts.no_large && line_count > opts.large_line_count { return None; }
    let lang = language_for(path, &text, opts)?;
    let rules = rules_for(&lang);
    let mut st = count_text(&text, &rules);
    st.language = lang;
    st.path = clean_path(path);
    st.bytes = bytes.len();
    if opts.no_complexity { st.complexity = 0; }
    if opts.uloc {
        let mut set = BTreeSet::new();
        for line in text.lines() {
            let t = line.trim();
            if !t.is_empty() { set.insert(t.to_string()); }
        }
        st.uloc = set.len();
    }
    Some(st)
}

fn clean_path(path: &Path) -> String {
    let s = path.to_string_lossy().replace('\\', "/");
    s.strip_prefix("./").unwrap_or(&s).to_string()
}

fn ext_of(path: &Path) -> String {
    let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("").to_lowercase();
    if name.starts_with('.') && !name[1..].contains('.') { return name; }
    if let Some(e) = path.extension().and_then(|s| s.to_str()) { e.to_lowercase() } else { name }
}

fn language_for(path: &Path, text: &str, opts: &Opts) -> Option<String> {
    let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("").to_lowercase();
    let ext = ext_of(path);
    if let Some(mapped) = opts.count_as.get(&ext) {
        return Some(canonical_lang(mapped));
    }
    if !name.contains('.') {
        if let Some(first) = text.lines().next() {
            if first.starts_with("#!") {
                let f = first.to_lowercase();
                if f.contains("python") { return Some("Python".into()); }
                if f.contains("bash") { return Some("BASH".into()); }
                if f.contains("sh") { return Some("Shell".into()); }
                if f.contains("perl") { return Some("Perl".into()); }
                if f.contains("ruby") { return Some("Ruby".into()); }
                if f.contains("node") { return Some("JavaScript".into()); }
            }
        }
    }
    Some(match name.as_str() {
        "makefile" | "gnumakefile" => "Makefile",
        "cmakelists.txt" => "CMake",
        "dockerfile" => "Dockerfile",
        "license" | "licence" | "copying" => "License",
        "readme" => "Plain Text",
        "build" | "workspace" | "build.bazel" => "Bazel",
        _ => match ext.as_str() {
            "rs" => "Rust", "go" => "Go", "py" | "pyw" => "Python", "js" | "mjs" | "cjs" => "JavaScript",
            "ts" | "tsx" => "TypeScript", "jsx" => "JavaScript JSX", "java" => "Java", "c" | "ec" | "pgc" => "C",
            "h" => "C Header", "cc" | "cpp" | "cxx" | "c++" | "ino" => "C++", "hpp" | "hh" | "hxx" | "h++" | "inl" => "C++ Header",
            "cs" | "csx" => "C#", "php" | "php3" | "php4" | "php5" | "phtml" => "PHP", "rb" => "Ruby",
            "sh" => "Shell", "bash" | ".bashrc" | ".bash_profile" | ".bash_login" | ".bash_logout" => "BASH",
            "zsh" => "Zsh", "fish" => "Fish", "pl" | "pm" => "Perl", "swift" => "Swift", "kt" | "kts" => "Kotlin",
            "scala" => "Scala", "r" => "R", "lua" => "Lua", "dart" => "Dart", "ex" | "exs" => "Elixir",
            "erl" | "hrl" => "Erlang", "fs" | "fsx" | "fsi" => "F#", "vb" => "Visual Basic",
            "html" | "htm" | "xhtml" => "HTML", "css" => "CSS", "scss" => "Sass", "sass" => "Sass",
            "less" => "Less", "xml" => "XML", "svg" => "SVG", "json" => "JSON", "yaml" | "yml" => "YAML",
            "toml" => "TOML", "ini" | "cfg" | "conf" => "INI", "md" | "markdown" => "Markdown", "rst" => "ReStructuredText",
            "txt" | "text" => "Plain Text", "sql" => "SQL", "proto" => "Protobuf", "vue" => "Vue",
            "svelte" => "Svelte", "rbw" => "Ruby", "m" => "Objective-C", "mm" => "Objective-C++",
            "plsql" => "PL/SQL", "ps1" => "Powershell", "bat" | "cmd" => "Batch", "rake" => "Ruby",
            "gradle" => "Groovy", "groovy" => "Groovy", "clj" | "cljc" => "Clojure", "hs" => "Haskell",
            "lhs" => "Literate Haskell", "ml" | "mli" => "OCaml", "nim" => "Nim", "zig" => "Zig",
            "d" => "D", "jl" => "Julia", "tex" => "TeX", "csv" => "CSV", "tsv" => "TSV",
            _ => return None,
        }
    }.into())
}

fn canonical_lang(s: &str) -> String {
    let lower = s.to_lowercase();
    for (name, exts) in language_table() {
        if lower == name.to_lowercase() || exts.iter().any(|e| lower == *e) {
            return name.to_string();
        }
    }
    s.to_string()
}

#[derive(Clone)]
struct Rules { line: Vec<&'static str>, block: Vec<(&'static str, &'static str)>, plain: bool }

fn rules_for(lang: &str) -> Rules {
    match lang {
        "Markdown" | "Plain Text" | "CSV" | "TSV" | "JSON" | "TOML" | "YAML" | "XML" | "SVG" | "License" => Rules { line: vec![], block: vec![], plain: true },
        "Python" | "Ruby" | "Perl" | "R" | "Shell" | "BASH" | "Zsh" | "Fish" | "Powershell" | "Makefile" | "Dockerfile" => Rules { line: vec!["#"], block: vec![], plain: false },
        "SQL" | "PL/SQL" => Rules { line: vec!["--"], block: vec![("/*", "*/")], plain: false },
        "HTML" | "Vue" | "Svelte" => Rules { line: vec![], block: vec![("<!--", "-->")], plain: false },
        "CSS" | "Sass" | "Less" => Rules { line: vec![], block: vec![("/*", "*/")], plain: false },
        _ => Rules { line: vec!["//"], block: vec![("/*", "*/")], plain: false },
    }
}

fn count_text(text: &str, rules: &Rules) -> FileStat {
    let mut st = FileStat::default();
    let mut in_block: Option<&str> = None;
    let mut total_len = 0usize;
    for line in text.lines() {
        st.lines += 1;
        let trimmed = line.trim();
        let len = line.chars().count();
        st.max_len = st.max_len.max(len);
        total_len += len;
        if trimmed.is_empty() {
            st.blanks += 1;
            continue;
        }
        if rules.plain {
            st.code += 1;
            continue;
        }
        if let Some(end) = in_block {
            st.comments += 1;
            if trimmed.contains(end) { in_block = None; }
            continue;
        }
        let mut comment_line = false;
        for (start, end) in &rules.block {
            if trimmed.starts_with(start) {
                st.comments += 1;
                comment_line = true;
                if !trimmed.contains(end) { in_block = Some(end); }
                break;
            }
        }
        if comment_line { continue; }
        if rules.line.iter().any(|p| trimmed.starts_with(p)) {
            st.comments += 1;
        } else {
            st.code += 1;
            st.complexity += complexity_line(trimmed);
        }
    }
    if st.lines > 0 { st.mean_len = total_len / st.lines; }
    st
}

fn complexity_line(line: &str) -> usize {
    let mut c = 0;
    let words: Vec<String> = line.split(|ch: char| !ch.is_alphanumeric() && ch != '_').map(|s| s.to_lowercase()).collect();
    for w in words {
        if matches!(w.as_str(), "if" | "for" | "while" | "case" | "catch" | "except" | "elif" | "else" | "when" | "match") {
            c += 1;
        }
    }
    c + line.matches("&&").count() + line.matches("||").count() + line.matches('?').count()
}

fn summarize(files: &[FileStat], opts: &Opts) -> Vec<Summary> {
    let mut map: BTreeMap<String, Summary> = BTreeMap::new();
    for f in files {
        let s = map.entry(f.language.clone()).or_insert_with(|| Summary { language: f.language.clone(), ..Default::default() });
        s.files += 1; s.bytes += f.bytes; s.lines += f.lines; s.code += f.code; s.comments += f.comments; s.blanks += f.blanks;
        s.complexity += f.complexity; s.uloc += f.uloc; s.max_len = s.max_len.max(f.max_len); s.mean_len += f.mean_len; s.file_stats.push(f.clone());
    }
    let mut v: Vec<Summary> = map.into_values().map(|mut s| { if s.files > 0 { s.mean_len /= s.files; } s }).collect();
    match opts.sort.as_str() {
        "name" => v.sort_by(|a,b| a.language.cmp(&b.language)),
        "lines" => v.sort_by(|a,b| b.lines.cmp(&a.lines).then(a.language.cmp(&b.language))),
        "blanks" => v.sort_by(|a,b| b.blanks.cmp(&a.blanks).then(a.language.cmp(&b.language))),
        "code" => v.sort_by(|a,b| b.code.cmp(&a.code).then(a.language.cmp(&b.language))),
        "comments" => v.sort_by(|a,b| b.comments.cmp(&a.comments).then(a.language.cmp(&b.language))),
        "complexity" => v.sort_by(|a,b| b.complexity.cmp(&a.complexity).then(a.language.cmp(&b.language))),
        _ => v.sort_by(|a,b| b.files.cmp(&a.files).then(a.language.cmp(&b.language))),
    }
    v
}

fn totals(sums: &[Summary]) -> Summary {
    let mut t = Summary { language: "Total".into(), ..Default::default() };
    for s in sums {
        t.files += s.files; t.bytes += s.bytes; t.lines += s.lines; t.code += s.code; t.comments += s.comments; t.blanks += s.blanks;
        t.complexity += s.complexity; t.uloc += s.uloc; t.max_len = t.max_len.max(s.max_len); t.mean_len += s.mean_len;
    }
    if !sums.is_empty() { t.mean_len /= sums.len(); }
    t
}

fn comma(n: usize) -> String {
    let s = n.to_string();
    let mut out = String::new();
    for (i, ch) in s.chars().rev().enumerate() {
        if i > 0 && i % 3 == 0 { out.push(','); }
        out.push(ch);
    }
    out.chars().rev().collect()
}

fn format_table(sums: &[Summary], _stats: &[FileStat], opts: &Opts) -> String {
    let mut out = String::new();
    let border = if opts.ci { "-".repeat(79) } else { "─".repeat(79) };
    let show_uloc = opts.uloc || opts.dryness;
    let show_char = opts.character;
    out.push_str(&border); out.push('\n');
    if show_uloc {
        out.push_str(&format!("{:<20} {:>8} {:>11} {:>9} {:>9} {:>10} {:>10} {:>7}\n", "Language", "Files", "Lines", "Blanks", "Comments", "Code", "Complexity", "ULOC"));
    } else if show_char {
        out.push_str(&format!("{:<20} {:>8} {:>11} {:>9} {:>9} {:>10} {:>10} {:>8} {:>8}\n", "Language", "Files", "Lines", "Blanks", "Comments", "Code", "Complexity", "Max", "Mean"));
    } else {
        out.push_str(&format!("{:<20} {:>8} {:>11} {:>9} {:>9} {:>10} {:>10}\n", "Language", "Files", "Lines", "Blanks", "Comments", "Code", "Complexity"));
    }
    out.push_str(&border); out.push('\n');
    for s in sums {
        append_row(&mut out, &s.language, Some(s.files), s.lines, s.blanks, s.comments, s.code, s.complexity, s.uloc, s.max_len, s.mean_len, show_uloc, show_char);
        if opts.by_file {
            let mut files = s.file_stats.clone();
            files.sort_by(|a,b| a.path.cmp(&b.path));
            for f in files {
                append_row(&mut out, &f.path, None, f.lines, f.blanks, f.comments, f.code, f.complexity, f.uloc, f.max_len, f.mean_len, show_uloc, show_char);
            }
            out.push_str(&border); out.push('\n');
        }
    }
    if !opts.by_file { out.push_str(&border); out.push('\n'); }
    let t = totals(sums);
    append_row(&mut out, "Total", Some(t.files), t.lines, t.blanks, t.comments, t.code, t.complexity, t.uloc, t.max_len, t.mean_len, show_uloc, show_char);
    out.push_str(&border); out.push('\n');
    if opts.dryness {
        let dry = if t.code == 0 { 0.0 } else { (t.uloc as f64 / t.code as f64) * 100.0 };
        out.push_str(&format!("DRYness {:.2}%\n", dry));
        out.push_str(&border); out.push('\n');
    }
    if !opts.no_cocomo {
        let (cost, sched, people) = estimate(t.code, opts.avg_wage);
        out.push_str(&format!("Estimated Cost to Develop ({}) {}{}\n", opts.project_type, opts.currency, comma(cost.floor() as usize)));
        out.push_str(&format!("Estimated Schedule Effort ({}) {:.2} months\n", opts.project_type, sched));
        out.push_str(&format!("Estimated People Required ({}) {:.2}\n", opts.project_type, people));
        out.push_str(&border); out.push('\n');
    }
    if !opts.no_size {
        out.push_str(&format!("Processed {} bytes, {:.3} megabytes (SI)\n", t.bytes, t.bytes as f64 / 1_000_000.0));
        out.push_str(&border); out.push('\n');
    }
    out
}

#[allow(clippy::too_many_arguments)]
fn append_row(out: &mut String, name: &str, files: Option<usize>, lines: usize, blanks: usize, comments: usize, code: usize, complexity: usize, uloc: usize, max: usize, mean: usize, show_uloc: bool, show_char: bool) {
    let n = truncate_name(name, 20);
    if show_uloc {
        out.push_str(&format!("{:<20} {:>8} {:>11} {:>9} {:>9} {:>10} {:>10} {:>7}\n", n, files.map(comma).unwrap_or_default(), comma(lines), comma(blanks), comma(comments), comma(code), comma(complexity), comma(uloc)));
    } else if show_char {
        out.push_str(&format!("{:<20} {:>8} {:>11} {:>9} {:>9} {:>10} {:>10} {:>8} {:>8}\n", n, files.map(comma).unwrap_or_default(), comma(lines), comma(blanks), comma(comments), comma(code), comma(complexity), comma(max), comma(mean)));
    } else {
        out.push_str(&format!("{:<20} {:>8} {:>11} {:>9} {:>9} {:>10} {:>10}\n", n, files.map(comma).unwrap_or_default(), comma(lines), comma(blanks), comma(comments), comma(code), comma(complexity)));
    }
}

fn truncate_name(s: &str, max: usize) -> String {
    if s.chars().count() <= max { return s.to_string(); }
    let mut out: String = s.chars().take(max - 1).collect();
    out.push('…');
    out
}

fn estimate(code: usize, wage: f64) -> (f64, f64, f64) {
    if code == 0 { return (0.0, 0.0, 0.0); }
    let kloc = code as f64 / 1000.0;
    let effort = 2.4 * kloc.powf(1.05);
    let sched = 2.5 * effort.powf(0.38);
    let people = if sched == 0.0 { 0.0 } else { effort / sched };
    let cost = effort * (wage / 12.0) * 2.4;
    (cost, sched, people)
}

fn simple_hash(bytes: &[u8]) -> u64 {
    let mut h = 1469598103934665603u64;
    for b in bytes {
        h ^= *b as u64;
        h = h.wrapping_mul(1099511628211);
    }
    h
}

fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n") }

fn format_json(sums: &[Summary], include_files: bool) -> String {
    let mut out = String::from("[");
    for (i, s) in sums.iter().enumerate() {
        if i > 0 { out.push(','); }
        out.push_str(&summary_json(s, include_files));
    }
    out.push(']');
    out
}

fn summary_json(s: &Summary, include_files: bool) -> String {
    let mut files = String::from("[]");
    if include_files {
        files = String::from("[");
        for (i, f) in s.file_stats.iter().enumerate() {
            if i > 0 { files.push(','); }
            files.push_str(&format!("{{\"Name\":\"{}\",\"Bytes\":{},\"CodeBytes\":0,\"Lines\":{},\"Code\":{},\"Comment\":{},\"Blank\":{},\"Complexity\":{},\"Count\":0,\"WeightedComplexity\":0,\"Files\":[],\"LineLength\":null,\"ULOC\":{}}}", esc(&f.path), f.bytes, f.lines, f.code, f.comments, f.blanks, f.complexity, f.uloc));
        }
        files.push(']');
    }
    format!("{{\"Name\":\"{}\",\"Bytes\":{},\"CodeBytes\":0,\"Lines\":{},\"Code\":{},\"Comment\":{},\"Blank\":{},\"Complexity\":{},\"Count\":{},\"WeightedComplexity\":0,\"Files\":{},\"LineLength\":null,\"ULOC\":{}}}",
        esc(&s.language), s.bytes, s.lines, s.code, s.comments, s.blanks, s.complexity, s.files, files, s.uloc)
}

fn format_json2(sums: &[Summary]) -> String {
    let t = totals(sums);
    let (cost, sched, people) = estimate(t.code, 56286.0);
    format!("{{\"languageSummary\":{},\"estimatedCost\":{},\"estimatedScheduleMonths\":{},\"estimatedPeople\":{}}}", format_json(sums, false), cost, sched, people)
}

fn format_csv(sums: &[Summary]) -> String {
    let mut out = "Language,Lines,Code,Comments,Blanks,Complexity,Bytes,Files,ULOC\n".to_string();
    for s in sums {
        out.push_str(&format!("{},{},{},{},{},{},{},{},{}\n", s.language, s.lines, s.code, s.comments, s.blanks, s.complexity, s.bytes, s.files, s.uloc));
    }
    out
}

fn format_csv_stream(stats: &[FileStat]) -> String {
    let mut out = "Language,Filename,Lines,Code,Comments,Blanks,Complexity,Bytes,ULOC\n".to_string();
    for f in stats {
        out.push_str(&format!("{},{},{},{},{},{},{},{},{}\n", f.language, f.path, f.lines, f.code, f.comments, f.blanks, f.complexity, f.bytes, f.uloc));
    }
    out
}

fn format_yaml(sums: &[Summary]) -> String {
    let t = totals(sums);
    let mut out = "# https://github.com/boyter/scc/\nheader:\n  url: https://github.com/boyter/scc/\n  version: 3.7.0\n  elapsed_seconds: 0.012\n".to_string();
    out.push_str(&format!("  n_files: {}\n  n_lines: {}\n", t.files, t.lines));
    for s in sums {
        out.push_str(&format!("{}:\n  name: {}\n  code: {}\n  comment: {}\n  blank: {}\n  nFiles: {}\n", s.language, s.language, s.code, s.comments, s.blanks, s.files));
    }
    out.push_str(&format!("SUM:\n  code: {}\n  comment: {}\n  blank: {}\n  nFiles: {}\n", t.code, t.comments, t.blanks, t.files));
    out
}

fn format_openmetrics(sums: &[Summary]) -> String {
    let mut out = "# TYPE scc_files gauge\n# HELP scc_files Number of sourcecode files.\n# TYPE scc_lines gauge\n# HELP scc_lines Number of lines.\n# TYPE scc_code gauge\n# HELP scc_code Number of lines of actual code.\n# TYPE scc_comments gauge\n# HELP scc_comments Number of comments.\n# TYPE scc_blanks gauge\n# HELP scc_blanks Number of blank lines.\n# TYPE scc_complexity gauge\n# HELP scc_complexity Code complexity.\n# TYPE scc_bytes gauge\n# UNIT scc_bytes bytes\n# HELP scc_bytes Size in bytes.\n".to_string();
    for s in sums {
        let l = esc(&s.language);
        out.push_str(&format!("scc_files{{language=\"{}\"}} {}\nscc_lines{{language=\"{}\"}} {}\nscc_code{{language=\"{}\"}} {}\nscc_comments{{language=\"{}\"}} {}\nscc_blanks{{language=\"{}\"}} {}\nscc_complexity{{language=\"{}\"}} {}\nscc_bytes{{language=\"{}\"}} {}\n", l, s.files, l, s.lines, l, s.code, l, s.comments, l, s.blanks, l, s.complexity, l, s.bytes));
    }
    out
}

fn format_html_table(sums: &[Summary], opts: &Opts) -> String {
    let t = totals(sums);
    let mut out = "<table id=\"scc-table\">\n\t<thead><tr>\n\t\t<th>Language</th>\n\t\t<th>Files</th>\n\t\t<th>Lines</th>\n\t\t<th>Blank</th>\n\t\t<th>Comment</th>\n\t\t<th>Code</th>\n\t\t<th>Complexity</th>\n\t\t<th>Bytes</th>\n\t\t<th>Uloc</th>\n\t</tr></thead>\n\t<tbody>".to_string();
    for s in sums { html_row(&mut out, &s.language, s.files, s.lines, s.blanks, s.comments, s.code, s.complexity, s.bytes, s.uloc); }
    out.push_str("</tbody>\n\t<tfoot>");
    html_row(&mut out, "Total", t.files, t.lines, t.blanks, t.comments, t.code, t.complexity, t.bytes, t.uloc);
    if !opts.no_cocomo {
        let (cost, sched, people) = estimate(t.code, opts.avg_wage);
        out.push_str(&format!("\t<tr>\n\t\t<th colspan=\"9\">Estimated Cost to Develop ({}) {}{}<br>Estimated Schedule Effort ({}) {:.2} months<br>Estimated People Required ({}) {:.2}<br></th>\n\t</tr>", opts.project_type, opts.currency, comma(cost.floor() as usize), opts.project_type, sched, opts.project_type, people));
    }
    out.push_str("</tfoot>\n\t</table>");
    out
}

fn html_row(out: &mut String, name: &str, files: usize, lines: usize, blanks: usize, comments: usize, code: usize, complexity: usize, bytes: usize, uloc: usize) {
    out.push_str(&format!("<tr>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t\t<th>{}</th>\n\t</tr>", name, files, lines, blanks, comments, code, complexity, bytes, uloc));
}

fn format_html(sums: &[Summary], opts: &Opts) -> String {
    format!("<!doctype html><html><head><meta charset=\"utf-8\"><title>scc</title></head><body>{}</body></html>", format_html_table(sums, opts))
}

fn format_sql(sums: &[Summary], stats: &[FileStat], opts: &Opts) -> String {
    let t = totals(sums);
    let (cost, sched, people) = estimate(t.code, opts.avg_wage);
    let mut out = "create table metadata (   -- github.com/boyter/scc v 3.7.0\n             timestamp text,\n             Project   text,\n             elapsed_s real,\n             estimated_cost real,\n             estimated_schedule_months real,\n             estimated_people real);\ncreate table t        (\n             Project       text   ,\n             Language      text   ,\n             File          text   ,\n             File_dirname  text   ,\n             File_basename text   ,\n             nByte         integer,\n             nBlank        integer,\n             nComment      integer,\n             nCode         integer,\n             nComplexity   integer,\n             nUloc         integer    \n);\nbegin transaction;\n".to_string();
    for f in stats {
        let p = Path::new(&f.path);
        let base = p.file_name().and_then(|s| s.to_str()).unwrap_or("");
        let dir = p.parent().map(|p| format!("{}/", p.to_string_lossy())).unwrap_or_default();
        out.push_str(&format!("insert into t values('{}', '{}', '{}', '{}', '{}', {}, {}, {}, {}, {}, {});\n", sq(&opts.sql_project), sq(&f.language), sq(&f.path), sq(&dir), sq(base), f.bytes, f.blanks, f.comments, f.code, f.complexity, f.uloc));
    }
    out.push_str(&format!("commit;\nbegin transaction;\ninsert into metadata values('2026-05-28 00:00:00', '{}', 0.012000, {:.6}, {:.6}, {:.6});\ncommit;\n", sq(&opts.sql_project), cost, sched, people));
    out
}

fn sq(s: &str) -> String { s.replace('\'', "''") }

fn print_help() {
    println!("Sloc, Cloc and Code. Count lines of code in a directory with complexity estimation.\nVersion 3.7.0\nBen Boyter <ben@boyter.org> + Contributors\n\nUsage:\n  scc [flags] [files or directories]\n\nFlags:\n      --avg-wage int                       average wage value used for basic COCOMO calculation (default 56286)\n      --binary                             disable binary file detection\n      --by-file                            display output for every file\n  -m, --character                          calculate max and mean characters per line\n      --ci                                 enable CI output settings where stdout is ASCII\n      --cocomo-project-type string         change COCOMO model type [organic, semi-detached, embedded, \"custom,1,1,1,1\"] (default \"organic\")\n      --cost-comparison                    show both COCOMO and LOCOMO estimates side by side\n      --count-as string                    count extension as language [e.g. jsp:htm,chead:\"C Header\" maps extension jsp to html and chead to C Header]\n      --count-ignore                       set to allow .gitignore and .ignore files to be counted\n      --currency-symbol string             set currency symbol (default \"$\")\n  -a, --dryness                            calculate the DRYness of the project (implies --uloc)\n  -x, --exclude-ext strings                ignore file extensions (overrides include-ext) [comma separated list: e.g. go,java,js]\n  -n, --exclude-file strings               ignore files with matching names (default [package-lock.json,Cargo.lock,yarn.lock,pubspec.lock,Podfile.lock,pnpm-lock.yaml])\n  -f, --format string                      set output format [tabular, wide, json, json2, csv, csv-stream, cloc-yaml, html, html-table, sql, sql-insert, openmetrics] (default \"tabular\")\n  -h, --help                               help for scc\n  -i, --include-ext strings                limit to file extensions [comma separated list: e.g. go,java,js]\n  -l, --languages                          print supported languages and extensions\n      --no-cocomo                          remove COCOMO calculation output\n  -c, --no-complexity                      skip calculation of code complexity\n  -d, --no-duplicates                      remove duplicate files from stats and output\n      --no-size                            remove size calculation output\n  -o, --output string                      output filename (default stdout)\n  -p, --percent                            include percentage values in output\n  -s, --sort string                        column to sort by [files, name, lines, blanks, code, comments, complexity] (default \"files\")\n  -u, --uloc                               calculate the number of unique lines of code (ULOC) for the project\n  -v, --verbose                            verbose output\n      --version                            version for scc\n  -w, --wide                               wider output with additional statistics (implies --complexity)");
}

fn print_languages() {
    for (name, exts) in language_table() {
        println!("{} ({})", name, exts.join(","));
    }
}

fn language_table() -> Vec<(&'static str, Vec<&'static str>)> {
    vec![
        ("BASH", vec!["bash","bash_login","bash_logout","bash_profile","bashrc",".bash_login",".bash_logout",".bash_profile",".bashrc"]),
        ("C", vec!["c","ec","pgc"]), ("C Header", vec!["h"]), ("C++", vec!["cc","cpp","cxx","c++","ino"]),
        ("C++ Header", vec!["hh","hpp","hxx","h++","inl","ipp"]), ("C#", vec!["cs","csx"]),
        ("CSS", vec!["css"]), ("CSV", vec!["csv"]), ("Dart", vec!["dart"]), ("Dockerfile", vec!["dockerfile"]),
        ("Elixir", vec!["ex","exs"]), ("Erlang", vec!["erl","hrl"]), ("Go", vec!["go"]), ("Groovy", vec!["groovy","gradle"]),
        ("HTML", vec!["html","htm","xhtml"]), ("Java", vec!["java"]), ("JavaScript", vec!["js","mjs","cjs"]),
        ("JSON", vec!["json"]), ("Kotlin", vec!["kt","kts"]), ("License", vec!["license"]), ("Lua", vec!["lua"]),
        ("Makefile", vec!["makefile"]), ("Markdown", vec!["md","markdown"]), ("PHP", vec!["php","phtml"]),
        ("Plain Text", vec!["txt","text"]), ("Python", vec!["py","pyw"]), ("Ruby", vec!["rb","rake"]),
        ("Rust", vec!["rs"]), ("Shell", vec!["sh"]), ("SQL", vec!["sql"]), ("Swift", vec!["swift"]),
        ("TOML", vec!["toml"]), ("TypeScript", vec!["ts","tsx"]), ("XML", vec!["xml"]), ("YAML", vec!["yaml","yml"]),
    ]
}
