use std::env;
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Class {
    Elf32,
    Elf64,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum Endian {
    Little,
    Big,
}

#[derive(Debug)]
struct Header {
    class: Class,
    endian: Endian,
    abi: u8,
    abi_ver: u8,
    e_type: u16,
    e_machine: u16,
    e_entry: u64,
    e_phoff: u64,
    e_shoff: u64,
    e_flags: u32,
    e_ehsize: u16,
    e_phentsize: u16,
    e_phnum: u16,
    e_shentsize: u16,
    e_shnum: u16,
    e_shstrndx: u16,
}

#[derive(Debug)]
struct ProgramHeader {
    p_type: u32,
    p_flags: u32,
    p_offset: u64,
    p_vaddr: u64,
    p_paddr: u64,
    p_filesz: u64,
    p_memsz: u64,
    p_align: u64,
}

#[derive(Debug)]
struct SectionHeader {
    name_off: u32,
    name: String,
    sh_type: u32,
    sh_flags: u64,
    sh_addr: u64,
    sh_offset: u64,
    sh_size: u64,
    sh_link: u32,
    sh_info: u32,
    sh_addralign: u64,
    sh_entsize: u64,
}

#[derive(Debug)]
struct Elf {
    header: Header,
    phdrs: Vec<ProgramHeader>,
    shdrs: Vec<SectionHeader>,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() == 2 && args[1] == "--version" {
        println!("elfcat 0.1.10");
        return;
    }
    if args.len() != 2 || args[1] == "--help" || args[1] == "-h" {
        println!("Usage: elfcat <filename>");
        println!("Writes <filename>.html to CWD.");
        std::process::exit(if args.len() == 2 { 0 } else { 1 });
    }

    let filename = &args[1];
    let bytes = match fs::read(filename) {
        Ok(bytes) => bytes,
        Err(err) => {
            eprintln!("Failed to read file \"{}\": {}", filename, err);
            std::process::exit(1);
        }
    };

    let elf = match parse_elf(&bytes) {
        Ok(elf) => elf,
        Err(err) => {
            eprintln!("Failed to parse ELF: {}", err);
            std::process::exit(1);
        }
    };

    let input = Path::new(filename);
    let display_name = input
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or(filename);
    let out = PathBuf::from(format!("{}.html", display_name));

    let html = render_html(display_name, &bytes, &elf);
    if let Err(err) = write_file(&out, html.as_bytes()) {
        eprintln!("Failed to write file \"{}\": {}", out.display(), err);
        std::process::exit(1);
    }
}

fn write_file(path: &Path, bytes: &[u8]) -> std::io::Result<()> {
    let mut f = fs::File::create(path)?;
    f.write_all(bytes)
}

fn parse_elf(data: &[u8]) -> Result<Elf, String> {
    if data.len() < 16 {
        return Err("file is smaller than ELF header's e_ident".to_string());
    }
    if &data[0..4] != b"\x7fELF" {
        return Err("mismatched magic: not an ELF file".to_string());
    }
    let class = match data[4] {
        1 => Class::Elf32,
        2 => Class::Elf64,
        x => return Err(format!("Unknown bitness: {}", x)),
    };
    let endian = match data[5] {
        1 => Endian::Little,
        2 => Endian::Big,
        x => return Err(format!("Unknown endianness: {}", x)),
    };
    let min = match class {
        Class::Elf32 => 52,
        Class::Elf64 => 64,
    };
    if data.len() < min {
        return Err("file is smaller than ELF file header".to_string());
    }

    let header = if class == Class::Elf64 {
        Header {
            class,
            endian,
            abi: data[7],
            abi_ver: data[8],
            e_type: u16_at(data, 16, endian)?,
            e_machine: u16_at(data, 18, endian)?,
            e_entry: u64_at(data, 24, endian)?,
            e_phoff: u64_at(data, 32, endian)?,
            e_shoff: u64_at(data, 40, endian)?,
            e_flags: u32_at(data, 48, endian)?,
            e_ehsize: u16_at(data, 52, endian)?,
            e_phentsize: u16_at(data, 54, endian)?,
            e_phnum: u16_at(data, 56, endian)?,
            e_shentsize: u16_at(data, 58, endian)?,
            e_shnum: u16_at(data, 60, endian)?,
            e_shstrndx: u16_at(data, 62, endian)?,
        }
    } else {
        Header {
            class,
            endian,
            abi: data[7],
            abi_ver: data[8],
            e_type: u16_at(data, 16, endian)?,
            e_machine: u16_at(data, 18, endian)?,
            e_entry: u32_at(data, 24, endian)? as u64,
            e_phoff: u32_at(data, 28, endian)? as u64,
            e_shoff: u32_at(data, 32, endian)? as u64,
            e_flags: u32_at(data, 36, endian)?,
            e_ehsize: u16_at(data, 40, endian)?,
            e_phentsize: u16_at(data, 42, endian)?,
            e_phnum: u16_at(data, 44, endian)?,
            e_shentsize: u16_at(data, 46, endian)?,
            e_shnum: u16_at(data, 48, endian)?,
            e_shstrndx: u16_at(data, 50, endian)?,
        }
    };

    let mut phdrs = Vec::new();
    for i in 0..header.e_phnum as usize {
        let off = checked_table_offset(header.e_phoff, header.e_phentsize, i)?;
        if off + header.e_phentsize as usize > data.len() {
            break;
        }
        phdrs.push(parse_phdr(data, off, class, endian)?);
    }

    let mut shdrs = Vec::new();
    for i in 0..header.e_shnum as usize {
        let off = checked_table_offset(header.e_shoff, header.e_shentsize, i)?;
        if off + header.e_shentsize as usize > data.len() {
            break;
        }
        shdrs.push(parse_shdr(data, off, class, endian)?);
    }

    let shstr = shdrs
        .get(header.e_shstrndx as usize)
        .and_then(|sh| bytes_range(data, sh.sh_offset, sh.sh_size));
    if let Some(strings) = shstr {
        for sh in &mut shdrs {
            sh.name = read_cstr(strings, sh.name_off as usize);
        }
    }

    Ok(Elf { header, phdrs, shdrs })
}

fn checked_table_offset(base: u64, entsize: u16, idx: usize) -> Result<usize, String> {
    let off = base
        .checked_add((entsize as u64).saturating_mul(idx as u64))
        .ok_or_else(|| "offset overflow".to_string())?;
    usize::try_from(off).map_err(|_| "offset does not fit usize".to_string())
}

fn parse_phdr(data: &[u8], off: usize, class: Class, endian: Endian) -> Result<ProgramHeader, String> {
    if class == Class::Elf64 {
        Ok(ProgramHeader {
            p_type: u32_at(data, off, endian)?,
            p_flags: u32_at(data, off + 4, endian)?,
            p_offset: u64_at(data, off + 8, endian)?,
            p_vaddr: u64_at(data, off + 16, endian)?,
            p_paddr: u64_at(data, off + 24, endian)?,
            p_filesz: u64_at(data, off + 32, endian)?,
            p_memsz: u64_at(data, off + 40, endian)?,
            p_align: u64_at(data, off + 48, endian)?,
        })
    } else {
        Ok(ProgramHeader {
            p_type: u32_at(data, off, endian)?,
            p_offset: u32_at(data, off + 4, endian)? as u64,
            p_vaddr: u32_at(data, off + 8, endian)? as u64,
            p_paddr: u32_at(data, off + 12, endian)? as u64,
            p_filesz: u32_at(data, off + 16, endian)? as u64,
            p_memsz: u32_at(data, off + 20, endian)? as u64,
            p_flags: u32_at(data, off + 24, endian)?,
            p_align: u32_at(data, off + 28, endian)? as u64,
        })
    }
}

fn parse_shdr(data: &[u8], off: usize, class: Class, endian: Endian) -> Result<SectionHeader, String> {
    if class == Class::Elf64 {
        Ok(SectionHeader {
            name_off: u32_at(data, off, endian)?,
            name: String::new(),
            sh_type: u32_at(data, off + 4, endian)?,
            sh_flags: u64_at(data, off + 8, endian)?,
            sh_addr: u64_at(data, off + 16, endian)?,
            sh_offset: u64_at(data, off + 24, endian)?,
            sh_size: u64_at(data, off + 32, endian)?,
            sh_link: u32_at(data, off + 40, endian)?,
            sh_info: u32_at(data, off + 44, endian)?,
            sh_addralign: u64_at(data, off + 48, endian)?,
            sh_entsize: u64_at(data, off + 56, endian)?,
        })
    } else {
        Ok(SectionHeader {
            name_off: u32_at(data, off, endian)?,
            name: String::new(),
            sh_type: u32_at(data, off + 4, endian)?,
            sh_flags: u32_at(data, off + 8, endian)? as u64,
            sh_addr: u32_at(data, off + 12, endian)? as u64,
            sh_offset: u32_at(data, off + 16, endian)? as u64,
            sh_size: u32_at(data, off + 20, endian)? as u64,
            sh_link: u32_at(data, off + 24, endian)?,
            sh_info: u32_at(data, off + 28, endian)?,
            sh_addralign: u32_at(data, off + 32, endian)? as u64,
            sh_entsize: u32_at(data, off + 36, endian)? as u64,
        })
    }
}

fn u16_at(data: &[u8], off: usize, endian: Endian) -> Result<u16, String> {
    let b = data.get(off..off + 2).ok_or_else(|| "unexpected end of file".to_string())?;
    Ok(match endian { Endian::Little => u16::from_le_bytes([b[0], b[1]]), Endian::Big => u16::from_be_bytes([b[0], b[1]]) })
}
fn u32_at(data: &[u8], off: usize, endian: Endian) -> Result<u32, String> {
    let b = data.get(off..off + 4).ok_or_else(|| "unexpected end of file".to_string())?;
    Ok(match endian { Endian::Little => u32::from_le_bytes([b[0], b[1], b[2], b[3]]), Endian::Big => u32::from_be_bytes([b[0], b[1], b[2], b[3]]) })
}
fn u64_at(data: &[u8], off: usize, endian: Endian) -> Result<u64, String> {
    let b = data.get(off..off + 8).ok_or_else(|| "unexpected end of file".to_string())?;
    Ok(match endian { Endian::Little => u64::from_le_bytes([b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]]), Endian::Big => u64::from_be_bytes([b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7]]) })
}

fn bytes_range(data: &[u8], off: u64, size: u64) -> Option<&[u8]> {
    let start = usize::try_from(off).ok()?;
    let len = usize::try_from(size).ok()?;
    data.get(start..start.checked_add(len)?)
}

fn read_cstr(data: &[u8], off: usize) -> String {
    if off >= data.len() {
        return String::new();
    }
    let end = data[off..].iter().position(|&b| b == 0).map(|p| off + p).unwrap_or(data.len());
    String::from_utf8_lossy(&data[off..end]).into_owned()
}

fn render_html(name: &str, data: &[u8], elf: &Elf) -> String {
    let h = &elf.header;
    let mut s = String::new();
    s.push_str("<!doctype html>\n<html>\n  <head>\n    <meta charset='utf-8'>\n    <meta name='viewport' content='width=900, initial-scale=1'>\n");
    s.push_str(&format!("    <title>{}</title>\n", esc(name)));
    s.push_str(STYLE);
    s.push_str("  </head>\n  <body>\n");
    s.push_str("    <svg width='100%' height='100%'><defs><marker id='arrowhead' viewBox='0 0 10 10' refX='10' refY='5' markerWidth='10' markerHeight='10' orient='auto'><path d='M 0 0 L 10 5 L 0 10 z' /></marker></defs><g id='arrows' stroke='black' stroke-width='1' marker-end='url(#arrowhead)'></g></svg>\n");
    s.push_str("    <div id='rightmenu'>\n      <a id='credits' href='https://github.com/rbakbashev/elfcat'>generated with elfcat 0.1.10</a>\n      <button class='textbutton' id='settings_toggle'>Settings</button>\n      <button class='textbutton' id='help_toggle'>Help</button>\n");
    s.push_str("      <div class='right_hidden' id='settings'><label for='arrow_opacity_range'>Arrow opacity:</label><input type='range' id='arrow_opacity_range' min='0' max='100' value='100'></div>\n");
    s.push_str("      <div class='right_hidden' id='help'><p>The leftmost column shows offsets within the file. The middle column is the file dump. It has ELF structs, sections and segments highlighted. Some fields that reference areas in the file are clickable and connected with arrows. The rightmost column shows printable ASCII characters corresponding to the file bytes.</p><p>Legend</p><ul><li><span class='legend_rect ident'></span>ELF Identification</li><li><span class='legend_rect ehdr'></span>ELF Header</li><li><span class='legend_rect phdr'></span>Program Header</li><li><span class='legend_rect shdr'></span>Section Header</li><li><span class='legend_rect segment'></span>Segment</li><li><span class='legend_rect section'></span>Section</li><li><span class='legend_rect segm_sect_legend'></span>Segment &amp; Section overlap</li></ul></div>\n    </div>\n");
    s.push_str("    <table>\n");
    s.push_str(&format!("      <tr class='fileinfo_file_name'> <td>File name:</td> <td>{}</td> </tr>\n", esc(name)));
    s.push_str(&format!("      <tr class='fileinfo_file_size'> <td>File size:</td> <td>{} ({} B)</td> </tr>\n", human_size(data.len() as u64), data.len()));
    s.push_str(&format!("      <tr class='fileinfo_class'> <td>Object class:</td> <td>{}</td> </tr>\n", if h.class == Class::Elf64 { "64-bit" } else { "32-bit" }));
    s.push_str(&format!("      <tr class='fileinfo_data'> <td>Data encoding:</td> <td>{}</td> </tr>\n", if h.endian == Endian::Little { "Little endian" } else { "Big endian" }));
    s.push_str(&format!("      <tr class='fileinfo_abi'> <td>ABI:</td> <td>{}</td> </tr>\n", abi_name(h.abi)));
    s.push_str(&format!("      <tr class='fileinfo_abi_version'> <td>ABI version:</td> <td>{}</td> </tr>\n", h.abi_ver));
    s.push_str(&format!("      <tr class='fileinfo_e_type'> <td>Type:</td> <td>{}</td> </tr>\n", e_type_name(h.e_type)));
    s.push_str(&format!("      <tr class='fileinfo_e_machine'> <td>Architecture:</td> <td>{}</td> </tr>\n", machine_name(h.e_machine)));
    s.push_str(&format!("      <tr class='fileinfo_e_flags'> <td>Flags:</td> <td><span class='number' title='{}'>0x{:x}</span></td> </tr>\n", h.e_flags, h.e_flags));
    s.push_str(&format!("      <tr class='fileinfo_e_entry'> <td>Entrypoint:</td> <td><span class='number' title='{}'>0x{:x}</span></td> </tr>\n", h.e_entry, h.e_entry));
    s.push_str(&format!("      <tr class='fileinfo_ph'> <td>Program headers:</td> <td><span title='0x{:x}' class='number fileinfo_e_phnum'>{}</span> * <span title='0x{:x}' class='number fileinfo_e_phentsize'>{}</span> @ <span title='0x{:x}' class='number fileinfo_e_phoff'>{}</span></td> </tr>\n", h.e_phnum, h.e_phnum, h.e_phentsize, h.e_phentsize, h.e_phoff, h.e_phoff));
    s.push_str(&format!("      <tr class='fileinfo_sh'> <td>Section headers:</td> <td><span title='0x{:x}' class='number fileinfo_e_shnum'>{}</span> * <span title='0x{:x}' class='number fileinfo_e_shentsize'>{}</span> @ <span title='0x{:x}' class='number fileinfo_e_shoff'>{}</span></td> </tr>\n", h.e_shnum, h.e_shnum, h.e_shentsize, h.e_shentsize, h.e_shoff, h.e_shoff));
    s.push_str("    </table>\n");

    s.push_str("    <h2>Program headers</h2>\n    <table class='headers'><tr><th>#</th><th>Type</th><th>Flags</th><th>Offset</th><th>VirtAddr</th><th>PhysAddr</th><th>FileSize</th><th>MemSize</th><th>Align</th></tr>\n");
    for (i, p) in elf.phdrs.iter().enumerate() {
        s.push_str(&format!("      <tr class='bin_phdr{} phdr'><td>{}</td><td>{}</td><td>{}</td><td class='p_offset'>0x{:x}</td><td>0x{:x}</td><td>0x{:x}</td><td>{}</td><td>{}</td><td>0x{:x}</td></tr>\n", i, i, p_type_name(p.p_type), flags(p.p_flags), p.p_offset, p.p_vaddr, p.p_paddr, p.p_filesz, p.p_memsz, p.p_align));
    }
    s.push_str("    </table>\n");

    s.push_str("    <h2>Section headers</h2>\n    <table class='headers'><tr><th>#</th><th>Name</th><th>Type</th><th>Flags</th><th>Address</th><th>Offset</th><th>Size</th><th>Link</th><th>Info</th><th>Align</th><th>EntSize</th></tr>\n");
    for (i, sh) in elf.shdrs.iter().enumerate() {
        s.push_str(&format!("      <tr class='bin_shdr{} shdr'><td>{}</td><td>{}</td><td>{}</td><td>0x{:x}</td><td>0x{:x}</td><td class='sh_offset'>0x{:x}</td><td>{}</td><td class='sh_link'>{}</td><td>{}</td><td>{}</td><td>{}</td></tr>\n", i, i, esc(&sh.name), sh_type_name(sh.sh_type), sh.sh_flags, sh.sh_addr, sh.sh_offset, sh.sh_size, sh.sh_link, sh.sh_info, sh.sh_addralign, sh.sh_entsize));
    }
    s.push_str("    </table>\n");

    s.push_str("    <div id='offsets'>");
    for off in (0..data.len()).step_by(16) {
        s.push_str(&format!("{:x}\n", off));
    }
    s.push_str("</div>\n    <div id='bytes'>");
    s.push_str(&render_bytes(data, elf));
    s.push_str("</div>\n    <div id='ascii'>");
    for chunk in data.chunks(16) {
        for &b in chunk {
            let c = if b.is_ascii_graphic() || b == b' ' { b as char } else { '.' };
            s.push_str(&esc_char(c));
        }
        s.push('\n');
    }
    s.push_str("</div>\n");
    s.push_str(SCRIPT);
    s.push_str("  </body>\n</html>\n");
    s
}

fn render_bytes(data: &[u8], elf: &Elf) -> String {
    let mut points: Vec<(usize, &'static str, String)> = Vec::new();
    points.push((0, "open", "ehdr".to_string()));
    points.push((0, "open", "ident".to_string()));
    points.push((16.min(data.len()), "close", String::new()));
    points.push(((elf.header.e_ehsize as usize).min(data.len()), "close", String::new()));
    for (i, p) in elf.phdrs.iter().enumerate() {
        let start = checked_table_offset(elf.header.e_phoff, elf.header.e_phentsize, i).unwrap_or(0);
        points.push((start.min(data.len()), "open", format!("bin_phdr{} phdr", i)));
        points.push(((start + elf.header.e_phentsize as usize).min(data.len()), "close", String::new()));
        if p.p_filesz > 0 {
            if let (Ok(a), Ok(sz)) = (usize::try_from(p.p_offset), usize::try_from(p.p_filesz)) {
                points.push((a.min(data.len()), "open", format!("bin_segment{} segment hover", i)));
                points.push((a.saturating_add(sz).min(data.len()), "close", String::new()));
            }
        }
    }
    for (i, sh) in elf.shdrs.iter().enumerate() {
        let start = checked_table_offset(elf.header.e_shoff, elf.header.e_shentsize, i).unwrap_or(0);
        points.push((start.min(data.len()), "open", format!("bin_shdr{} shdr", i)));
        points.push(((start + elf.header.e_shentsize as usize).min(data.len()), "close", String::new()));
        if sh.sh_type != 8 && sh.sh_size > 0 {
            if let (Ok(a), Ok(sz)) = (usize::try_from(sh.sh_offset), usize::try_from(sh.sh_size)) {
                points.push((a.min(data.len()), "open", format!("bin_section{} section hover", i)));
                points.push((a.saturating_add(sz).min(data.len()), "close", String::new()));
            }
        }
    }
    points.sort_by(|a, b| a.0.cmp(&b.0).then_with(|| order_rank(a.1).cmp(&order_rank(b.1))));
    let mut point_idx = 0;
    let mut out = String::new();
    for (i, b) in data.iter().enumerate() {
        while point_idx < points.len() && points[point_idx].0 == i && points[point_idx].1 == "close" {
            out.push_str("</span>");
            point_idx += 1;
        }
        while point_idx < points.len() && points[point_idx].0 == i && points[point_idx].1 == "open" {
            out.push_str(&format!("<span class='{}'>", esc(&points[point_idx].2)));
            point_idx += 1;
        }
        if i > 0 {
            if i % 16 == 0 {
                out.push('\n');
            } else {
                out.push(' ');
            }
        }
        if *b == b'\x7f' {
            out.push_str("7f");
        } else if b.is_ascii_graphic() && *b != b'<' && *b != b'>' && *b != b'&' {
            out.push_str(&format!("&nbsp;{}", *b as char));
        } else {
            out.push_str(&format!("{:02x}", b));
        }
    }
    while point_idx < points.len() {
        if points[point_idx].1 == "close" {
            out.push_str("</span>");
        }
        point_idx += 1;
    }
    out
}

fn order_rank(kind: &str) -> u8 {
    if kind == "close" { 0 } else { 1 }
}

fn human_size(n: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KiB", "MiB", "GiB", "TiB"];
    let mut val = n as f64;
    let mut unit = 0;
    while val >= 1024.0 && unit + 1 < UNITS.len() {
        val /= 1024.0;
        unit += 1;
    }
    if unit == 0 {
        format!("{} B", n)
    } else {
        format!("{:.1} {}", val, UNITS[unit])
    }
}

fn esc(s: &str) -> String {
    s.chars().map(esc_char).collect()
}
fn esc_char(c: char) -> String {
    match c {
        '&' => "&amp;".to_string(),
        '<' => "&lt;".to_string(),
        '>' => "&gt;".to_string(),
        '"' => "&quot;".to_string(),
        '\'' => "&#39;".to_string(),
        _ => c.to_string(),
    }
}

fn abi_name(v: u8) -> String {
    match v {
        0 => "SysV".into(),
        1 => "HP-UX".into(),
        2 => "NetBSD".into(),
        3 => "Linux".into(),
        6 => "Solaris".into(),
        7 => "AIX".into(),
        8 => "IRIX".into(),
        9 => "FreeBSD".into(),
        12 => "OpenBSD".into(),
        x => format!("Unknown ({})", x),
    }
}
fn e_type_name(v: u16) -> String {
    match v {
        0 => "No file type (NONE)".into(),
        1 => "Relocatable file (REL)".into(),
        2 => "Executable file (EXEC)".into(),
        3 => "Shared object file (DYN)".into(),
        4 => "Core file (CORE)".into(),
        x => format!("Processor-specific or unknown ({})", x),
    }
}
fn machine_name(v: u16) -> String {
    match v {
        0 => "No machine".into(),
        3 => "x86".into(),
        8 => "MIPS".into(),
        20 => "PowerPC".into(),
        40 => "ARM".into(),
        50 => "IA-64".into(),
        62 => "x86-64".into(),
        183 => "AArch64".into(),
        243 => "RISC-V".into(),
        x => format!("Unknown ({})", x),
    }
}
fn p_type_name(v: u32) -> String {
    match v {
        0 => "NULL".into(),
        1 => "LOAD".into(),
        2 => "DYNAMIC".into(),
        3 => "INTERP".into(),
        4 => "NOTE".into(),
        5 => "SHLIB".into(),
        6 => "PHDR".into(),
        7 => "TLS".into(),
        0x6474e550 => "GNU_EH_FRAME".into(),
        0x6474e551 => "GNU_STACK".into(),
        0x6474e552 => "GNU_RELRO".into(),
        0x6474e553 => "GNU_PROPERTY".into(),
        x => format!("0x{:x}", x),
    }
}
fn sh_type_name(v: u32) -> String {
    match v {
        0 => "NULL".into(),
        1 => "PROGBITS".into(),
        2 => "SYMTAB".into(),
        3 => "STRTAB".into(),
        4 => "RELA".into(),
        5 => "HASH".into(),
        6 => "DYNAMIC".into(),
        7 => "NOTE".into(),
        8 => "NOBITS".into(),
        9 => "REL".into(),
        11 => "DYNSYM".into(),
        14 => "INIT_ARRAY".into(),
        15 => "FINI_ARRAY".into(),
        0x6ffffff6 => "GNU_HASH".into(),
        0x6fffffff => "GNU_versym".into(),
        0x6ffffffe => "GNU_verneed".into(),
        x => format!("0x{:x}", x),
    }
}
fn flags(v: u32) -> String {
    let mut out = String::new();
    if v & 4 != 0 { out.push('R'); }
    if v & 2 != 0 { out.push('W'); }
    if v & 1 != 0 { out.push('E'); }
    if out.is_empty() { out.push('-'); }
    out
}

const STYLE: &str = r#"    <style>
      html { font-family: monospace; }
      #rightmenu { vertical-align: top; text-align: right; float: right; }
      #credits { color: #ddd; text-decoration: none; margin-bottom: 0.5em; display: block; }
      #credits:hover { color: #000; }
      .right_hidden { text-align: left; display: none; }
      .textbutton { color: #222; cursor: pointer; background: none; border: none; padding: 0; margin: 0 0.5em 0.5em 0; }
      .textbutton::before { content: "["; } .textbutton::after { content: "]"; }
      .legend_rect { float: left; margin-right: 0.4em; width: 3em; height: 1.5em; border: 1px solid rgba(0,0,0,.2); }
      ul { list-style: none; padding: 0; }
      table { border-collapse: collapse; margin-bottom: 1em; }
      td, th { padding: 0.15em 0.8em 0.15em 0; text-align: left; }
      .headers th { border-bottom: 1px solid #999; }
      #offsets, #bytes, #ascii { display: inline-block; vertical-align: top; white-space: pre; line-height: 1.25; }
      #offsets { color: #777; text-align: right; margin-right: 1em; }
      #bytes { min-width: 48em; }
      #ascii { margin-left: 1em; color: #555; }
      svg { position: absolute; z-index: -1; left: 0; top: 0; }
      .ident, .legend_rect.ident { background: rgba(255, 230, 120, .55); }
      .ehdr, .legend_rect.ehdr { background: rgba(255, 180, 180, .35); }
      .phdr, .legend_rect.phdr { background: rgba(120, 190, 255, .35); }
      .shdr, .legend_rect.shdr { background: rgba(190, 150, 255, .35); }
      .segment, .legend_rect.segment { background: rgba(120, 220, 150, .25); }
      .section, .legend_rect.section { outline: 1px solid rgba(0,0,0,.18); }
      .segm_sect_legend { background: linear-gradient(90deg, rgba(120,220,150,.35), rgba(190,150,255,.35)); }
      .hover:hover, .phdr:hover, .shdr:hover { background: rgba(255, 80, 80, .35); }
      .number { color: #152f78; }
    </style>
"#;

const SCRIPT: &str = r#"    <script type='text/javascript'>
      function toggleVisibility(elem) {
          if (elem.style.display === "none" || elem.style.display === "") elem.style.display = "block";
          else elem.style.display = "none";
      }
      document.getElementById('settings_toggle').onclick = function() {
          toggleVisibility(document.getElementById('settings'));
          document.getElementById('help').style.display = "none";
      };
      document.getElementById('help_toggle').onclick = function() {
          toggleVisibility(document.getElementById('help'));
          document.getElementById('settings').style.display = "none";
      };
      function connect(a, b) { return [a, b]; }
    </script>
"#;
