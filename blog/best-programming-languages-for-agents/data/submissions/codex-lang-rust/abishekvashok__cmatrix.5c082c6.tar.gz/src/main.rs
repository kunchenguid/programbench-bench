use std::env;
use std::io::{self, Read, Write};
use std::process::{Command, Stdio};
use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

const HELP: &str = " Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]
 -a: Asynchronous scroll
 -b: Bold characters on
 -B: All bold characters (overrides -b)
 -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts
 -f: Force the linux $TERM type to be on
 -l: Linux mode (uses matrix console font)
 -L: Lock mode (can be closed from another terminal)
 -o: Use old-style scrolling
 -h: Print usage and exit
 -n: No bold characters (overrides -b and -B, default)
 -s: \"Screensaver\" mode, exits on first keystroke
 -x: X window mode, use if your xterm is using mtx.pcf
 -V: Print version information and exit
 -M [message]: Prints your message in the center of the screen. Overrides -L's default message.
 -u delay (0 - 10, default 4): Screen update delay
 -C [color]: Use this color for matrix (default green)
 -r: rainbow mode
 -m: lambda mode
 -k: Characters change while scrolling. (Works without -o opt.)
 -t [tty]: Set tty to use
";

const VERSION: &str = " CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)
Email: abishekvashok@gmail.com
Web: https://github.com/abishekvashok/cmatrix
";

#[derive(Clone)]
struct Opts {
    color: Color,
    rainbow: bool,
    lambda: bool,
    bold: u8,
    delay: u64,
    message: Option<String>,
    lock: bool,
    screensaver: bool,
    changing: bool,
}

#[derive(Clone, Copy)]
enum Color {
    Green,
    Red,
    Blue,
    White,
    Yellow,
    Cyan,
    Magenta,
    Black,
}

impl Color {
    fn from_name(s: &str) -> Option<Self> {
        match s {
            "green" => Some(Self::Green),
            "red" => Some(Self::Red),
            "blue" => Some(Self::Blue),
            "white" => Some(Self::White),
            "yellow" => Some(Self::Yellow),
            "cyan" => Some(Self::Cyan),
            "magenta" => Some(Self::Magenta),
            "black" => Some(Self::Black),
            _ => None,
        }
    }

    fn fg(self) -> u8 {
        match self {
            Self::Black => 30,
            Self::Red => 31,
            Self::Green => 32,
            Self::Yellow => 33,
            Self::Blue => 34,
            Self::Magenta => 35,
            Self::Cyan => 36,
            Self::White => 37,
        }
    }
}

struct TermGuard {
    saved: Option<String>,
}

impl TermGuard {
    fn enter() -> Self {
        let saved = Command::new("stty")
            .arg("-g")
            .stderr(Stdio::null())
            .output()
            .ok()
            .and_then(|o| {
                if o.status.success() {
                    Some(String::from_utf8_lossy(&o.stdout).trim().to_string())
                } else {
                    None
                }
            });
        let _ = Command::new("stty")
            .args(["-echo", "-icanon", "min", "0", "time", "0"])
            .stderr(Stdio::null())
            .status();
        print!("\x1b[?1049h\x1b[?25l\x1b[H\x1b[2J");
        let _ = io::stdout().flush();
        Self { saved }
    }
}

impl Drop for TermGuard {
    fn drop(&mut self) {
        print!("\x1b[0m\x1b[?25h\x1b[?1049l");
        let _ = io::stdout().flush();
        if let Some(saved) = &self.saved {
            let _ = Command::new("stty").arg(saved).status();
        }
    }
}

#[derive(Clone)]
struct Rng(u64);

impl Rng {
    fn new() -> Self {
        let seed = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos() as u64;
        Self(seed ^ 0x9e37_79b9_7f4a_7c15)
    }

    fn next(&mut self) -> u32 {
        self.0 = self.0.wrapping_mul(6364136223846793005).wrapping_add(1);
        (self.0 >> 32) as u32
    }

    fn range(&mut self, n: u32) -> u32 {
        if n == 0 {
            0
        } else {
            self.next() % n
        }
    }
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let opts = match parse_args(&args) {
        Action::Help => {
            print!("{HELP}");
            return;
        }
        Action::Version => {
            print!("{VERSION}");
            return;
        }
        Action::InvalidColor => {
            println!(" Invalid color selection");
            println!(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.");
            return;
        }
        Action::Run(o) => o,
    };

    run(opts);
}

enum Action {
    Help,
    Version,
    InvalidColor,
    Run(Opts),
}

fn parse_args(args: &[String]) -> Action {
    let mut opts = Opts {
        color: Color::Green,
        rainbow: false,
        lambda: false,
        bold: 0,
        delay: 4,
        message: None,
        lock: false,
        screensaver: false,
        changing: false,
    };
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if !arg.starts_with('-') || arg == "-" {
            i += 1;
            continue;
        }
        let mut chars = arg[1..].chars().peekable();
        while let Some(ch) = chars.next() {
            match ch {
                'h' | '?' | 'Z' => return Action::Help,
                'V' => return Action::Version,
                'a' | 'f' | 'l' | 'o' | 'c' | 'x' => {}
                'L' => opts.lock = true,
                's' => opts.screensaver = true,
                'r' => opts.rainbow = true,
                'm' => opts.lambda = true,
                'k' => opts.changing = true,
                'b' => opts.bold = 1,
                'B' => opts.bold = 2,
                'n' => opts.bold = 0,
                'u' | 'C' | 'M' | 't' => {
                    let rest: String = chars.collect();
                    let val = if !rest.is_empty() {
                        rest
                    } else {
                        i += 1;
                        if i >= args.len() {
                            return Action::Help;
                        }
                        args[i].clone()
                    };
                    match ch {
                        'u' => opts.delay = val.parse::<u64>().unwrap_or(4).min(10),
                        'C' => match Color::from_name(&val) {
                            Some(c) => opts.color = c,
                            None => return Action::InvalidColor,
                        },
                        'M' => opts.message = Some(val),
                        't' => {}
                        _ => {}
                    }
                    break;
                }
                _ => {}
            }
        }
        i += 1;
    }
    Action::Run(opts)
}

fn terminal_size() -> (usize, usize) {
    if let Ok(out) = Command::new("stty")
        .arg("size")
        .stderr(Stdio::null())
        .output()
    {
        if out.status.success() {
            let s = String::from_utf8_lossy(&out.stdout);
            let mut it = s.split_whitespace();
            if let (Some(r), Some(c)) = (it.next(), it.next()) {
                if let (Ok(rows), Ok(cols)) = (r.parse::<usize>(), c.parse::<usize>()) {
                    return (rows.max(1), cols.max(1));
                }
            }
        }
    }
    let rows = env::var("LINES")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(24);
    let cols = env::var("COLUMNS")
        .ok()
        .and_then(|v| v.parse().ok())
        .unwrap_or(80);
    (rows, cols)
}

fn run(mut opts: Opts) {
    let term = env::var("TERM").unwrap_or_default();
    if term.is_empty() || term == "unknown" || term == "dumb" {
        eprintln!("Error opening terminal: unknown.");
        std::process::exit(1);
    }

    let _guard = TermGuard::enter();
    let (rows, cols) = terminal_size();
    let mut rng = Rng::new();
    let mut drops = vec![0usize; cols.max(1)];
    let mut speeds = vec![1usize; cols.max(1)];
    let mut lengths = vec![0usize; cols.max(1)];
    for c in 0..cols {
        drops[c] = rng.range(rows as u32) as usize;
        speeds[c] = 1 + rng.range(4) as usize;
        lengths[c] = 4 + rng.range((rows / 2).max(5) as u32) as usize;
    }

    draw_blank(rows, cols, opts.color);
    let mut frame = 0usize;
    loop {
        if handle_input(&mut opts) {
            break;
        }
        frame = frame.wrapping_add(1);
        for col in (0..cols).step_by(2) {
            if frame % speeds[col] != 0 {
                continue;
            }
            let head = drops[col] % rows;
            let tail = (drops[col] + rows - (lengths[col] % rows.max(1))) % rows;
            move_to(tail + 1, col + 1);
            print!(" ");
            move_to(head + 1, col + 1);
            let color = if opts.rainbow {
                [31, 32, 33, 34, 35, 36, 37][rng.range(7) as usize]
            } else if opts.bold == 2 || (opts.bold == 1 && rng.range(4) == 0) {
                37
            } else {
                opts.color.fg()
            };
            print!("\x1b[{}m{}", color, glyph(&mut rng, opts.lambda));
            if opts.changing && head > 0 {
                move_to(head, col + 1);
                print!("\x1b[{}m{}", opts.color.fg(), glyph(&mut rng, opts.lambda));
            }
            drops[col] = (drops[col] + 1) % rows.max(1);
        }
        if let Some(msg) = opts.message.as_deref().or(if opts.lock {
            Some("Computer locked.")
        } else {
            None
        }) {
            let row = rows / 2;
            let start = cols.saturating_sub(msg.len()) / 2 + 1;
            move_to(row.max(1), start.max(1));
            print!("\x1b[37m{msg}");
        }
        let _ = io::stdout().flush();
        let millis = 20 + opts.delay * 20;
        thread::sleep(Duration::from_millis(millis));
        if opts.screensaver && input_available() {
            break;
        }
    }
}

fn draw_blank(rows: usize, cols: usize, color: Color) {
    print!("\x1b[{}m", color.fg());
    for r in 1..=rows {
        move_to(r, 1);
        for _ in 0..cols {
            print!(" ");
        }
    }
    let _ = io::stdout().flush();
}

fn move_to(row: usize, col: usize) {
    print!("\x1b[{};{}H", row, col);
}

fn glyph(rng: &mut Rng, lambda: bool) -> char {
    if lambda {
        return 'λ';
    }
    const CHARS: &[u8] =
        b"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%^&*<>[]{};:,.!?";
    CHARS[rng.range(CHARS.len() as u32) as usize] as char
}

fn input_available() -> bool {
    let mut buf = [0u8; 1];
    matches!(io::stdin().read(&mut buf), Ok(1))
}

fn handle_input(opts: &mut Opts) -> bool {
    let mut buf = [0u8; 8];
    let n = io::stdin().read(&mut buf).unwrap_or(0);
    for &b in &buf[..n] {
        match b {
            b'q' if !opts.lock => return true,
            b'a' => {}
            b'b' => opts.bold = 1,
            b'B' => opts.bold = 2,
            b'n' => opts.bold = 0,
            b'0'..=b'9' => opts.delay = (b - b'0') as u64,
            b'!' => opts.color = Color::Red,
            b'@' => opts.color = Color::Green,
            b'#' => opts.color = Color::Yellow,
            b'$' => opts.color = Color::Blue,
            b'%' => opts.color = Color::Magenta,
            b'^' => opts.color = Color::Cyan,
            b'&' => opts.color = Color::White,
            b')' => opts.color = Color::Black,
            _ => {}
        }
    }
    false
}
