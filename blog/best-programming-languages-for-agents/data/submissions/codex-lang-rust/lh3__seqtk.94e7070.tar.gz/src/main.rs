use std::collections::{HashMap, HashSet};
use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::process::{Command, Stdio};

#[derive(Clone, Debug)]
struct Record {
    name: String,
    comment: String,
    seq: String,
    qual: Option<String>,
}

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        usage();
        return;
    }
    let cmd = args.remove(0);
    let res = match cmd.as_str() {
        "seq" => cmd_seq(&args),
        "size" => cmd_size(&args),
        "comp" => cmd_comp(&args),
        "subseq" => cmd_subseq(&args),
        "sample" => cmd_sample(&args),
        "mergepe" => cmd_mergepe(&args),
        "trimfq" => cmd_trimfq(&args),
        "split" => cmd_split(&args),
        "fqchk" => cmd_fqchk(&args),
        "rename" => cmd_rename(&args),
        "hpc" => cmd_hpc(&args),
        "gap" => cmd_gap(&args),
        "cutN" => cmd_cutn(&args),
        "telo" => cmd_telo(&args),
        _ => {
            eprintln!("[main] unrecognized command '{}'. Abort!", cmd);
            Ok(())
        }
    };
    if let Err(e) = res {
        eprintln!("{}", e);
        std::process::exit(1);
    }
}

fn usage() {
    println!();
    println!("Usage:   seqtk <command> <arguments>");
    println!("Version: 1.5-r133");
    println!();
    println!("Command: seq       common transformation of FASTA/Q");
    println!("         size      report the number sequences and bases");
    println!("         comp      get the nucleotide composition of FASTA/Q");
    println!("         sample    subsample sequences");
    println!("         subseq    extract subsequences from FASTA/Q");
    println!("         fqchk     fastq QC (base/quality summary)");
    println!("         mergepe   interleave two PE FASTA/Q files");
    println!("         split     split one file into multiple smaller files");
    println!("         trimfq    trim FASTQ using the Phred algorithm");
    println!();
    println!("         hety      regional heterozygosity");
    println!("         gc        identify high- or low-GC regions");
    println!("         mutfa     point mutate FASTA at specified positions");
    println!("         mergefa   merge two FASTA/Q files");
    println!("         famask    apply a X-coded FASTA to a source FASTA");
    println!("         dropse    drop unpaired from interleaved PE FASTA/Q");
    println!("         rename    rename sequence names");
    println!("         randbase  choose a random base from hets");
    println!("         cutN      cut sequence at long N");
    println!("         gap       get the gap locations");
    println!("         listhet   extract the position of each het");
    println!("         hpc       homopolyer-compressed sequence");
    println!("         telo      identify telomere repeats in asm or long reads");
    println!();
}

fn open_reader(path: Option<&str>) -> io::Result<Box<dyn BufRead>> {
    match path {
        None | Some("-") => Ok(Box::new(BufReader::new(io::stdin()))),
        Some(p) if p.ends_with(".gz") => {
            let child = Command::new("gzip")
                .arg("-dc")
                .arg(p)
                .stdout(Stdio::piped())
                .spawn()?;
            Ok(Box::new(BufReader::new(child.stdout.unwrap())))
        }
        Some(p) => Ok(Box::new(BufReader::new(File::open(p)?))),
    }
}

fn read_records(path: Option<&str>) -> io::Result<Vec<Record>> {
    let mut r = open_reader(path)?;
    let mut s = String::new();
    r.read_to_string(&mut s)?;
    Ok(parse_records(&s))
}

fn parse_records(s: &str) -> Vec<Record> {
    let mut lines = s.lines().peekable();
    let mut out = Vec::new();
    while let Some(line) = lines.next() {
        if line.is_empty() { continue; }
        let first = line.as_bytes()[0] as char;
        if first != '>' && first != '@' { continue; }
        let (name, comment) = split_header(&line[1..]);
        if first == '@' {
            let mut seq = String::new();
            while let Some(&l) = lines.peek() {
                if l.starts_with('+') { lines.next(); break; }
                seq.push_str(lines.next().unwrap().trim_end());
            }
            let mut qual = String::new();
            while qual.len() < seq.len() {
                match lines.next() {
                    Some(q) => qual.push_str(q.trim_end()),
                    None => break,
                }
            }
            out.push(Record { name, comment, seq, qual: Some(qual) });
        } else {
            let mut seq = String::new();
            while let Some(&l) = lines.peek() {
                if l.starts_with('>') || l.starts_with('@') { break; }
                seq.push_str(lines.next().unwrap().trim_end());
            }
            out.push(Record { name, comment, seq, qual: None });
        }
    }
    out
}

fn split_header(h: &str) -> (String, String) {
    let mut sp = h.splitn(2, char::is_whitespace);
    let name = sp.next().unwrap_or("").to_string();
    let comment = sp.next().unwrap_or("").trim_start().to_string();
    (name, comment)
}

fn header(rec: &Record, keep_comment: bool, override_name: Option<&str>) -> String {
    let n = override_name.unwrap_or(&rec.name);
    if keep_comment && !rec.comment.is_empty() {
        format!("{} {}", n, rec.comment)
    } else {
        n.to_string()
    }
}

fn write_record<W: Write>(w: &mut W, rec: &Record, as_fasta: bool, keep_comment: bool, line_len: usize, name_override: Option<&str>) -> io::Result<()> {
    if as_fasta || rec.qual.is_none() {
        writeln!(w, ">{}", header(rec, keep_comment, name_override))?;
        write_wrapped(w, &rec.seq, line_len)?;
    } else {
        let q = rec.qual.as_ref().unwrap();
        writeln!(w, "@{}", header(rec, keep_comment, name_override))?;
        write_wrapped(w, &rec.seq, line_len)?;
        writeln!(w, "+")?;
        write_wrapped(w, q, line_len)?;
    }
    Ok(())
}

fn write_wrapped<W: Write>(w: &mut W, text: &str, line_len: usize) -> io::Result<()> {
    if line_len == 0 {
        writeln!(w, "{}", text)
    } else {
        for chunk in text.as_bytes().chunks(line_len) {
            writeln!(w, "{}", String::from_utf8_lossy(chunk))?;
        }
        Ok(())
    }
}

fn revcomp(s: &str) -> String {
    s.bytes().rev().map(|b| match b {
        b'A' => 'T', b'C' => 'G', b'G' => 'C', b'T' => 'A',
        b'a' => 't', b'c' => 'g', b'g' => 'c', b't' => 'a',
        b'U' => 'A', b'u' => 'a', b'N' => 'N', b'n' => 'n',
        b'R' => 'Y', b'Y' => 'R', b'M' => 'K', b'K' => 'M',
        b'S' => 'S', b'W' => 'W', b'B' => 'V', b'V' => 'B',
        b'D' => 'H', b'H' => 'D',
        b'r' => 'y', b'y' => 'r', b'm' => 'k', b'k' => 'm',
        b's' => 's', b'w' => 'w', b'b' => 'v', b'v' => 'b',
        b'd' => 'h', b'h' => 'd', _ => b as char,
    }).collect()
}

fn cmd_seq(args: &[String]) -> io::Result<()> {
    let mut as_fasta = false;
    let mut keep_comment = true;
    let mut line_len = 0usize;
    let mut reverse = false;
    let mut qoff = 33i32;
    let mut qmin: Option<i32> = None;
    let mut mask_char: Option<char> = None;
    let mut min_len = 0usize;
    let mut no_amb = false;
    let mut mask_file: Option<String> = None;
    let mut files = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "-a" || a == "-A" { as_fasta = true; }
        else if a == "-C" { keep_comment = false; }
        else if a == "-r" { reverse = true; }
        else if a == "-N" { no_amb = true; }
        else if a.starts_with("-l") { line_len = parse_opt_val(a, args, &mut i, 2).unwrap_or(0); }
        else if a.starts_with("-Q") { qoff = parse_opt_val(a, args, &mut i, 2).unwrap_or(33); }
        else if a.starts_with("-q") { qmin = Some(parse_opt_val(a, args, &mut i, 2).unwrap_or(0)); }
        else if a.starts_with("-n") {
            let v: String = parse_opt_val_string(a, args, &mut i, 2).unwrap_or_default();
            mask_char = v.chars().next();
        }
        else if a.starts_with("-L") { min_len = parse_opt_val(a, args, &mut i, 2).unwrap_or(0); }
        else if a.starts_with("-M") { mask_file = parse_opt_val_string(a, args, &mut i, 2); }
        else if a.starts_with('-') { /* tolerate lesser-used switches */ }
        else { files.push(a.clone()); }
        i += 1;
    }
    let mut recs = read_records(files.first().map(|s| s.as_str()))?;
    if let Some(mf) = mask_file {
        let regs = read_bed(&mf)?;
        for r in recs.iter_mut() {
            if let Some(v) = regs.get(&r.name) {
                let mut bytes = r.seq.as_bytes().to_vec();
                for reg in v {
                    let st = reg.start.min(bytes.len());
                    let en = reg.end.min(bytes.len());
                    for b in &mut bytes[st..en] { *b = b.to_ascii_lowercase(); }
                }
                r.seq = String::from_utf8_lossy(&bytes).to_string();
            }
        }
    }
    let stdout = io::stdout();
    let mut out = io::BufWriter::new(stdout.lock());
    for mut r in recs.drain(..) {
        if r.seq.len() < min_len { continue; }
        if no_amb && r.seq.bytes().any(|b| b == b'N' || b == b'n') { continue; }
        if let (Some(th), Some(q)) = (qmin, r.qual.as_ref()) {
            let mut b = r.seq.as_bytes().to_vec();
            for (j, qc) in q.bytes().enumerate().take(b.len()) {
                if (qc as i32 - qoff) < th {
                    if let Some(c) = mask_char { b[j] = c as u8; }
                    else { b[j] = b[j].to_ascii_lowercase(); }
                }
            }
            r.seq = String::from_utf8_lossy(&b).to_string();
        }
        if reverse {
            r.seq = revcomp(&r.seq);
            if let Some(q) = r.qual.take() {
                r.qual = Some(q.chars().rev().collect());
            }
        }
        write_record(&mut out, &r, as_fasta, keep_comment, line_len, None)?;
    }
    Ok(())
}

fn parse_opt_val<T: std::str::FromStr>(a: &str, args: &[String], i: &mut usize, n: usize) -> Option<T> {
    if a.len() > n { a[n..].parse().ok() } else { *i += 1; args.get(*i)?.parse().ok() }
}
fn parse_opt_val_string(a: &str, args: &[String], i: &mut usize, n: usize) -> Option<String> {
    if a.len() > n { Some(a[n..].to_string()) } else { *i += 1; args.get(*i).cloned() }
}

fn cmd_size(args: &[String]) -> io::Result<()> {
    let recs = read_records(args.first().map(|s| s.as_str()))?;
    let n = recs.len();
    let b: usize = recs.iter().map(|r| r.seq.len()).sum();
    println!("{}\t{}", n, b);
    Ok(())
}

fn cmd_comp(args: &[String]) -> io::Result<()> {
    let recs = read_records(args.first().map(|s| s.as_str()))?;
    for r in recs {
        let mut a=0; let mut c=0; let mut g=0; let mut t=0; let mut two=0; let mut three=0; let mut four=0;
        let mut prev = 0u8;
        let mut cpg = 0;
        for b in r.seq.bytes() {
            let u = b.to_ascii_uppercase();
            if prev == b'C' && u == b'G' { cpg += 2; }
            prev = u;
            match b.to_ascii_uppercase() {
                b'A' => a += 1, b'C' => c += 1, b'G' => g += 1, b'T' | b'U' => t += 1,
                b'R'|b'Y'|b'S'|b'W'|b'K'|b'M' => two += 1,
                b'B'|b'D'|b'H'|b'V' => three += 1,
                b'N' => four += 1, _ => {}
            }
        }
        println!("{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t0\t0\t0", r.name, r.seq.len(), a, c, g, t, two, three, four, cpg);
    }
    Ok(())
}

#[derive(Clone)]
struct Region { start: usize, end: usize, strand: i8 }

fn read_bed(path: &str) -> io::Result<HashMap<String, Vec<Region>>> {
    let mut map: HashMap<String, Vec<Region>> = HashMap::new();
    let mut txt = String::new();
    open_reader(Some(path))?.read_to_string(&mut txt)?;
    for l in txt.lines() {
        if l.trim().is_empty() || l.starts_with('#') { continue; }
        let f: Vec<&str> = l.split_whitespace().collect();
        if f.len() >= 3 {
            let st = f[1].parse::<usize>().unwrap_or(0);
            let en = f[2].parse::<usize>().unwrap_or(st);
            let strand = if f.len() >= 6 && f[5] == "-" { -1 } else { 1 };
            map.entry(f[0].to_string()).or_default().push(Region{start:st,end:en,strand});
        }
    }
    Ok(map)
}

fn cmd_subseq(args: &[String]) -> io::Result<()> {
    let mut tab = false; let mut strand = false; let mut line_len = 0usize; let mut pos = Vec::new(); let mut i=0;
    while i < args.len() {
        let a=&args[i];
        if a=="-t" { tab=true; } else if a=="-s" { strand=true; }
        else if a.starts_with("-l") { line_len=parse_opt_val(a,args,&mut i,2).unwrap_or(0); }
        else { pos.push(a.clone()); }
        i+=1;
    }
    if pos.len() < 2 {
        eprintln!("Usage:   seqtk subseq [options] <in.fa> <in.bed>|<name.list>");
        eprintln!("Options:\n  -t       TAB delimited output\n  -s       strand aware\n  -l INT   sequence line length [0]");
        return Ok(());
    }
    let recs = read_records(Some(&pos[0]))?;
    let mut spec = String::new(); open_reader(Some(&pos[1]))?.read_to_string(&mut spec)?;
    let is_bed = spec.lines().find(|l| !l.trim().is_empty() && !l.starts_with('#')).map(|l| l.split_whitespace().count() >= 3).unwrap_or(false);
    let stdout = io::stdout(); let mut out=io::BufWriter::new(stdout.lock());
    if is_bed {
        let regs = read_bed(&pos[1])?;
        for r in recs {
            if let Some(v) = regs.get(&r.name) {
                for reg in v {
                    let st = reg.start.min(r.seq.len()); let en = reg.end.min(r.seq.len());
                    if en < st { continue; }
                    let mut s = r.seq[st..en].to_string();
                    let mut q = r.qual.as_ref().map(|x| x[st..en].to_string());
                    if strand && reg.strand < 0 {
                        s = revcomp(&s);
                        if let Some(qq)=q.take() { q=Some(qq.chars().rev().collect()); }
                    }
                    if tab {
                        writeln!(out, "{}\t{}\t{}", r.name, st+1, s)?;
                    } else {
                        let nr = Record{name:format!("{}:{}-{}", r.name, st+1, en), comment:r.comment.clone(), seq:s, qual:q};
                        write_record(&mut out, &nr, nr.qual.is_none(), true, line_len, None)?;
                    }
                }
            }
        }
    } else {
        let names: HashSet<String> = spec.lines().filter_map(|l| l.split_whitespace().next().map(|x| x.to_string())).collect();
        for r in recs {
            if names.contains(&r.name) { write_record(&mut out, &r, r.qual.is_none(), true, line_len, None)?; }
        }
    }
    Ok(())
}

fn cmd_mergepe(args: &[String]) -> io::Result<()> {
    if args.len() < 2 { eprintln!("Usage: seqtk mergepe <in1.fq> <in2.fq>"); return Ok(()); }
    let a=read_records(Some(&args[0]))?; let b=read_records(Some(&args[1]))?;
    let stdout=io::stdout(); let mut out=io::BufWriter::new(stdout.lock());
    for i in 0..a.len().max(b.len()) {
        if let Some(r)=a.get(i) { write_record(&mut out,r,r.qual.is_none(),true,0,None)?; }
        if let Some(r)=b.get(i) { write_record(&mut out,r,r.qual.is_none(),true,0,None)?; }
    }
    Ok(())
}

fn cmd_trimfq(args: &[String]) -> io::Result<()> {
    let mut btrim=0usize; let mut etrim=0usize; let mut keep5=0usize; let mut files=Vec::new(); let mut i=0;
    while i<args.len() {
        let a=&args[i];
        if a.starts_with("-b") { btrim=parse_opt_val(a,args,&mut i,2).unwrap_or(0); }
        else if a.starts_with("-e") { etrim=parse_opt_val(a,args,&mut i,2).unwrap_or(0); }
        else if a.starts_with("-L") { keep5=parse_opt_val(a,args,&mut i,2).unwrap_or(0); }
        else if a=="-Q" { eprintln!("trimfq: invalid option -- 'Q'"); }
        else if a.starts_with("-q") || a.starts_with("-l") { if a.len()==2 { i+=1; } }
        else if !a.starts_with('-') { files.push(a.clone()); }
        i+=1;
    }
    if files.is_empty() {
        eprintln!("\nUsage:   seqtk trimfq [options] <in.fq>\n");
        return Ok(());
    }
    let recs=read_records(Some(&files[0]))?; let stdout=io::stdout(); let mut out=io::BufWriter::new(stdout.lock());
    for mut r in recs {
        let mut st=btrim.min(r.seq.len()); let mut en=r.seq.len().saturating_sub(etrim);
        if keep5>0 { en=en.min(keep5); }
        if en<st { st=en; }
        r.seq=r.seq[st..en].to_string();
        if let Some(q)=r.qual.take() { r.qual=Some(q[st..en].to_string()); }
        write_record(&mut out,&r,r.qual.is_none(),true,0,None)?;
    }
    Ok(())
}

fn cmd_sample(args: &[String]) -> io::Result<()> {
    let mut seed=11u64; let mut pos=Vec::new(); let mut i=0;
    while i<args.len() {
        let a=&args[i];
        if a=="-2" {}
        else if a.starts_with("-s") { seed=parse_opt_val(a,args,&mut i,2).unwrap_or(11); }
        else { pos.push(a.clone()); }
        i+=1;
    }
    if pos.len()<2 { eprintln!("\nUsage:   seqtk sample [-2] [-s seed=11] <in.fa> <frac>|<number>\n"); return Ok(()); }
    let recs=read_records(Some(&pos[0]))?;
    let target=&pos[1]; let stdout=io::stdout(); let mut out=io::BufWriter::new(stdout.lock());
    if target.contains('.') {
        let frac=target.parse::<f64>().unwrap_or(0.0);
        let mut rng=Lcg::new(seed);
        for r in recs { if rng.next_f64() < frac { write_record(&mut out,&r,r.qual.is_none(),true,0,None)?; } }
    } else {
        let n=target.parse::<usize>().unwrap_or(0).min(recs.len());
        let mut idx: Vec<usize>=(0..recs.len()).collect();
        let mut rng=Lcg::new(seed);
        for j in (1..idx.len()).rev() { let k=(rng.next_f64()*((j+1) as f64)) as usize; idx.swap(j,k); }
        idx.truncate(n); idx.sort_unstable();
        for j in idx { let r=&recs[j]; write_record(&mut out,r,r.qual.is_none(),true,0,None)?; }
    }
    Ok(())
}

struct Lcg { x: u64 }
impl Lcg { fn new(seed:u64)->Self{Self{x:seed|1}} fn next_u32(&mut self)->u32{self.x=self.x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407); (self.x>>32) as u32} fn next_f64(&mut self)->f64{(self.next_u32() as f64)/4294967296.0} }

fn cmd_fqchk(args: &[String]) -> io::Result<()> {
    let mut qlim=20i32; let mut files=Vec::new(); let mut i=0;
    while i<args.len(){let a=&args[i]; if a.starts_with("-q"){qlim=parse_opt_val(a,args,&mut i,2).unwrap_or(20);} else {files.push(a.clone());} i+=1;}
    if files.is_empty(){eprintln!("Usage: seqtk fqchk [-q 20] <in.fq>"); return Ok(());}
    let recs=read_records(Some(&files[0]))?;
    let minl=recs.iter().map(|r|r.seq.len()).min().unwrap_or(0); let maxl=recs.iter().map(|r|r.seq.len()).max().unwrap_or(0);
    let total:usize=recs.iter().map(|r|r.seq.len()).sum(); let avg=if recs.is_empty(){0.0}else{total as f64/recs.len() as f64};
    let mut quals=HashSet::new(); for r in &recs { if let Some(q)=&r.qual { for b in q.bytes(){quals.insert(b);} } }
    println!("min_len: {}; max_len: {}; avg_len: {:.2}; {} distinct quality values",minl,maxl,avg,quals.len());
    println!("POS\t#bases\t%A\t%C\t%G\t%T\t%N\tavgQ\terrQ\t%low\t%high");
    fq_line("ALL", &recs, None, qlim);
    for p in 0..maxl { fq_line(&(p+1).to_string(), &recs, Some(p), qlim); }
    Ok(())
}

fn fq_line(label:&str,recs:&[Record],pos:Option<usize>,qlim:i32){
    let mut n=0usize; let mut ac=[0usize;5]; let mut qsum=0i64; let mut low=0usize;
    for r in recs {
        let range: Box<dyn Iterator<Item=usize>> = match pos { Some(p)=>Box::new(std::iter::once(p)), None=>Box::new(0..r.seq.len()) };
        for i in range { if i>=r.seq.len(){continue;} n+=1; match r.seq.as_bytes()[i].to_ascii_uppercase(){b'A'=>ac[0]+=1,b'C'=>ac[1]+=1,b'G'=>ac[2]+=1,b'T'=>ac[3]+=1,_=>ac[4]+=1}; if let Some(q)=&r.qual { let v=q.as_bytes().get(i).map(|b|*b as i32-33).unwrap_or(0); qsum+=v as i64; if v<qlim{low+=1;} } }
    }
    if n==0{return;}
    let pct=|x:usize| x as f64*100.0/n as f64; let avgq=qsum as f64/n as f64;
    let errq=if avgq<=0.0{0.0}else{-10.0*(10f64.powf(-avgq/10.0)).log10()};
    println!("{}\t{}\t{:.1}\t{:.1}\t{:.1}\t{:.1}\t{:.1}\t{:.1}\t{:.1}\t{:.1}\t{:.1}",label,n,pct(ac[0]),pct(ac[1]),pct(ac[2]),pct(ac[3]),pct(ac[4]),avgq,errq,pct(low),pct(n-low));
}

fn cmd_rename(args:&[String])->io::Result<()>{
    if args.len()<2{return Ok(());} let recs=read_records(Some(&args[0]))?; let prefix=&args[1]; let stdout=io::stdout(); let mut out=io::BufWriter::new(stdout.lock());
    for (i,r) in recs.iter().enumerate(){ let name=format!("{}{}",prefix,i+1); write_record(&mut out,r,r.qual.is_none(),true,0,Some(&name))?; }
    Ok(())
}

fn cmd_split(args:&[String])->io::Result<()>{
    let mut nfiles=10usize; let mut line_len=0usize; let mut pos=Vec::new(); let mut i=0;
    while i<args.len(){let a=&args[i]; if a.starts_with("-n"){nfiles=parse_opt_val(a,args,&mut i,2).unwrap_or(10);} else if a.starts_with("-l"){line_len=parse_opt_val(a,args,&mut i,2).unwrap_or(0);} else {pos.push(a.clone());} i+=1;}
    if pos.len()<2{eprintln!("Usage: seqtk split [options] <prefix> <in.fa>\nOptions:\n  -n INT    number of files [10]\n  -l INT    line length [0]"); return Ok(());}
    let recs=read_records(Some(&pos[1]))?;
    let mut writers: Vec<io::BufWriter<File>> = Vec::new();
    for i in 0..nfiles { writers.push(io::BufWriter::new(File::create(format!("{}.{}", pos[0], i))?)); }
    for (i,r) in recs.iter().enumerate(){ let k=i % nfiles; write_record(&mut writers[k],r,r.qual.is_none(),true,line_len,None)?; }
    Ok(())
}

fn cmd_hpc(args:&[String])->io::Result<()>{
    let recs=read_records(args.first().map(|s|s.as_str()))?; let stdout=io::stdout(); let mut out=io::BufWriter::new(stdout.lock());
    for mut r in recs { let mut s=String::new(); let mut last=0u8; for b in r.seq.bytes(){ if b.to_ascii_uppercase()!=last.to_ascii_uppercase(){s.push(b as char); last=b;} } r.seq=s; r.qual=None; write_record(&mut out,&r,true,false,0,None)?; }
    Ok(())
}

fn cmd_gap(args:&[String])->io::Result<()>{
    let recs=read_records(args.first().map(|s|s.as_str()))?;
    for r in recs { let mut st=None; for (i,b) in r.seq.bytes().enumerate(){ if b==b'N'||b==b'n'{ if st.is_none(){st=Some(i);} } else if let Some(s)=st.take(){ println!("{}\t{}\t{}",r.name,s,i); } } if let Some(s)=st{println!("{}\t{}\t{}",r.name,s,r.seq.len());} }
    Ok(())
}

fn cmd_cutn(args:&[String])->io::Result<()>{
    let mut min_n=1usize; let mut files=Vec::new(); let mut i=0; while i<args.len(){let a=&args[i]; if a.starts_with("-n"){min_n=parse_opt_val(a,args,&mut i,2).unwrap_or(1);} else if !a.starts_with('-'){files.push(a.clone());} i+=1;}
    let recs=read_records(files.first().map(|s|s.as_str()))?; let stdout=io::stdout(); let mut out=io::BufWriter::new(stdout.lock());
    for r in recs { let bytes=r.seq.as_bytes(); let mut start=0usize; let mut i=0usize; while i<=bytes.len(){ let mut j=i; while j<bytes.len()&&(bytes[j]==b'N'||bytes[j]==b'n'){j+=1;} if j>i && j-i>=min_n { if i>start { let nr=Record{name:format!("{}:{}-{}",r.name,start+1,i),comment:String::new(),seq:r.seq[start..i].to_string(),qual:None}; write_record(&mut out,&nr,true,true,0,None)?; } start=j; } i=if j>i{j}else{i+1}; } if start<bytes.len(){ let nr=Record{name:format!("{}:{}-{}",r.name,start+1,bytes.len()),comment:String::new(),seq:r.seq[start..].to_string(),qual:None}; write_record(&mut out,&nr,true,true,0,None)?; } }
    Ok(())
}

fn cmd_telo(args:&[String])->io::Result<()>{
    let recs=read_records(args.first().map(|s|s.as_str()))?;
    for r in recs {
        let u=r.seq.to_ascii_uppercase();
        for motif in ["TTAGGG","CCCTAA"] {
            let mut pos=0; while let Some(k)=u[pos..].find(motif){ let s=pos+k; println!("{}\t{}\t{}\t{}",r.name,s,s+motif.len(),motif); pos=s+motif.len(); }
        }
    }
    Ok(())
}
