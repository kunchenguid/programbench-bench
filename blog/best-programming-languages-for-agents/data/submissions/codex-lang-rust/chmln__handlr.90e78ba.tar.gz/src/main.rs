use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

#[derive(Clone, Debug)]
struct DesktopEntry {
    id: String,
    name: String,
    exec: String,
    mimes: Vec<String>,
}

fn main() {
    init_config();
    let args: Vec<String> = env::args().skip(1).collect();
    let code = run(args);
    std::process::exit(code);
}

fn run(args: Vec<String>) -> i32 {
    if args.is_empty() {
        print_main_help();
        return 2;
    }
    match args[0].as_str() {
        "-h" | "--help" => { print_main_help(); 0 }
        "-V" | "--version" => { println!("handlr 0.6.4"); 0 }
        "list" => cmd_list(&args[1..]),
        "open" => cmd_open(&args[1..]),
        "set" => cmd_set(&args[1..], true),
        "add" => cmd_set(&args[1..], false),
        "unset" => cmd_unset(&args[1..]),
        "launch" => cmd_launch(&args[1..]),
        "get" => cmd_get(&args[1..]),
        other => {
            eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context\n", other);
            eprintln!("If you tried to supply `{}` as a PATTERN use `-- {}`\n", other, other);
            eprintln!("USAGE:\n    executable <SUBCOMMAND>\n");
            eprintln!("For more information try --help");
            2
        }
    }
}

fn print_main_help() {
    println!("handlr 0.6.4\n");
    println!("USAGE:\n    executable <SUBCOMMAND>\n");
    println!("FLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n");
    println!("SUBCOMMANDS:\n    list      List default apps and the associated handlers\n    open      Open a path/URL with its default handler\n    set       Set the default handler for mime/extension\n    unset     Unset the default handler for mime/extension\n    launch    Launch the handler for specified extension/mime with optional arguments\n    get       Get handler for this mime/extension\n    add       Add a handler for given mime/extension Note that the first handler is the default");
}

fn sub_help(name: &str) {
    match name {
        "list" => println!("executable-list \nList default apps and the associated handlers\n\nUSAGE:\n    executable list [FLAGS]\n\nFLAGS:\n    -a, --all        \n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "open" => println!("executable-open \nOpen a path/URL with its default handler\n\nUSAGE:\n    executable open <paths>...\n\nARGS:\n    <paths>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "set" => println!("executable-set \nSet the default handler for mime/extension\n\nUSAGE:\n    executable set <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "unset" => println!("executable-unset \nUnset the default handler for mime/extension\n\nUSAGE:\n    executable unset <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "launch" => println!("executable-launch \nLaunch the handler for specified extension/mime with optional arguments\n\nUSAGE:\n    executable launch <mime> [args]...\n\nARGS:\n    <mime>       \n    <args>...    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "get" => println!("executable-get \nGet handler for this mime/extension\n\nUSAGE:\n    executable get [FLAGS] <mime>\n\nARGS:\n    <mime>    \n\nFLAGS:\n        --json       \n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        "add" => println!("executable-add \nAdd a handler for given mime/extension Note that the first handler is the default\n\nUSAGE:\n    executable add <mime> <handler>\n\nARGS:\n    <mime>       \n    <handler>    \n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        _ => {}
    }
}

fn cmd_list(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "-h" || a == "--help") { sub_help("list"); return 0; }
    if args.iter().any(|a| a == "-V" || a == "--version") { println!("handlr 0.6.4"); return 0; }
    let all = args.iter().any(|a| a == "-a" || a == "--all");
    let apps = scan_desktops();
    let defaults = read_mimeapps().defaults;
    if all { println!("Default Apps"); }
    let mut rows: Vec<(String, String)> = defaults.into_iter().filter(|(_, hs)| !hs.is_empty()).map(|(m, hs)| (m, hs[0].clone())).collect();
    rows.sort();
    print_table(&rows);
    if all {
        println!("System Apps");
        let mut sys = Vec::new();
        for app in apps.values() {
            for m in &app.mimes { sys.push((m.clone(), app.id.clone())); }
        }
        sys.sort();
        print_table(&sys);
    }
    0
}

fn cmd_get(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "-h" || a == "--help") { sub_help("get"); return 0; }
    if args.iter().any(|a| a == "-V" || a == "--version") { println!("handlr 0.6.4"); return 0; }
    let json = args.iter().any(|a| a == "--json");
    let rest: Vec<&String> = args.iter().filter(|a| a.as_str() != "--json").collect();
    if rest.is_empty() { missing("get", "<mime>"); return 2; }
    let mime = match normalize_mime(rest[0]) { Ok(m) => m, Err(e) => { invalid("<mime>", &e); return 2; } };
    if let Some((id, app)) = find_handler(&mime) {
        if json {
            if let Some(a) = app {
                println!("{{\"handler\":\"{}\",\"name\":\"{}\",\"cmd\":\"{}\"}}", esc(&id), esc(&a.name), esc(&clean_exec(&a.exec)));
            } else {
                println!("{{\"handler\":\"{}\",\"name\":\"\",\"cmd\":\"\"}}", esc(&id));
            }
        } else { println!("{}", id); }
        0
    } else { 1 }
}

fn cmd_set(args: &[String], replace: bool) -> i32 {
    let name = if replace { "set" } else { "add" };
    if args.iter().any(|a| a == "-h" || a == "--help") { sub_help(name); return 0; }
    if args.iter().any(|a| a == "-V" || a == "--version") { println!("handlr 0.6.4"); return 0; }
    if args.len() < 2 { missing(name, if args.is_empty() { "<mime>" } else { "<handler>" }); return 2; }
    let mime = match normalize_mime(&args[0]) { Ok(m) => m, Err(e) => { invalid("<mime>", &e); return 2; } };
    let apps = scan_desktops();
    if !apps.contains_key(&args[1]) { invalid("<handler>", &format!("no handlers found for '{}'", args[1])); return 2; }
    let mut mf = read_mimeapps();
    if replace { mf.defaults.insert(mime, vec![args[1].clone()]); }
    else { mf.defaults.entry(mime).or_default().push(args[1].clone()); }
    if let Err(e) = write_mimeapps(&mf) { eprintln!("{}", e); return 1; }
    0
}

fn cmd_unset(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "-h" || a == "--help") { sub_help("unset"); return 0; }
    if args.iter().any(|a| a == "-V" || a == "--version") { println!("handlr 0.6.4"); return 0; }
    if args.is_empty() { missing("unset", "<mime>"); return 2; }
    let mime = match normalize_mime(&args[0]) { Ok(m) => m, Err(e) => { invalid("<mime>", &e); return 2; } };
    let mut mf = read_mimeapps();
    mf.defaults.remove(&mime);
    if let Err(e) = write_mimeapps(&mf) { eprintln!("{}", e); return 1; }
    0
}

fn cmd_launch(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "-h" || a == "--help") { sub_help("launch"); return 0; }
    if args.iter().any(|a| a == "-V" || a == "--version") { println!("handlr 0.6.4"); return 0; }
    if args.is_empty() { missing("launch", "<mime>"); return 2; }
    let mime = match normalize_mime(&args[0]) { Ok(m) => m, Err(e) => { invalid("<mime>", &e); return 2; } };
    let pass: Vec<String> = args[1..].iter().filter(|a| a.as_str() != "--").cloned().collect();
    if let Some((_id, Some(app))) = find_handler(&mime) { return launch_app(&app, &pass); }
    1
}

fn cmd_open(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "-h" || a == "--help") { sub_help("open"); return 0; }
    if args.iter().any(|a| a == "-V" || a == "--version") { println!("handlr 0.6.4"); return 0; }
    if args.is_empty() { missing("open", "<paths>..."); return 2; }
    let mut ok = true;
    for p in args {
        let mime = if p.starts_with("http://") { "x-scheme-handler/http".to_string() } else if p.starts_with("https://") { "x-scheme-handler/https".to_string() } else { match normalize_mime(p) { Ok(m) => m, Err(_) => { ok = false; continue; } } };
        if let Some((_id, Some(app))) = find_handler(&mime) { if launch_app(&app, &[p.clone()]) != 0 { ok = false; } } else { ok = false; }
    }
    if ok { 0 } else { 1 }
}

fn missing(cmd: &str, arg: &str) {
    eprintln!("error: The following required arguments were not provided:\n    {}\n", arg);
    match cmd {
        "get" => eprintln!("USAGE:\n    executable get [FLAGS] <mime>\n"),
        "open" => eprintln!("USAGE:\n    executable open <paths>...\n"),
        "launch" => eprintln!("USAGE:\n    executable launch <mime> [args]...\n"),
        "unset" => eprintln!("USAGE:\n    executable unset <mime>\n"),
        "set" => eprintln!("USAGE:\n    executable set <mime> <handler>\n"),
        "add" => eprintln!("USAGE:\n    executable add <mime> <handler>\n"),
        _ => {}
    }
    eprintln!("For more information try --help");
}

fn invalid(arg: &str, msg: &str) { eprintln!("error: Invalid value for '{}': {}\n\nFor more information try --help", arg, msg); }

fn normalize_mime(s: &str) -> Result<String, String> {
    if s.starts_with('.') {
        return ext_to_mime(&s[1..]).ok_or_else(|| format!("could not figure out the mime type of '{}'", s));
    }
    if !s.contains('/') {
        let p = Path::new(s);
        if p.exists() || s.contains('.') {
            if let Some(ext) = p.extension().and_then(|e| e.to_str()) { return ext_to_mime(ext).ok_or_else(|| format!("could not figure out the mime type of '{}'", s)); }
        }
        return Err("mime parse error: a slash (/) was missing between the type and subtype".to_string());
    }
    let parts: Vec<&str> = s.split('/').collect();
    if parts.len() != 2 || parts[0].is_empty() || parts[1].is_empty() { return Err("mime parse error".to_string()); }
    Ok(s.to_string())
}

fn ext_to_mime(ext: &str) -> Option<String> {
    let needle = format!("*.{}", ext);
    let mut dirs = Vec::new();
    dirs.push(data_home().join("mime"));
    let data_dirs = env::var("XDG_DATA_DIRS").unwrap_or_else(|_| "/usr/local/share:/usr/share".to_string());
    for d in data_dirs.split(':') { dirs.push(Path::new(d).join("mime")); }
    for dir in dirs {
        for file in ["globs2", "globs"] {
            let path = dir.join(file);
            let text = fs::read_to_string(path).unwrap_or_default();
            for line in text.lines() {
                let t = line.trim();
                if t.is_empty() || t.starts_with('#') { continue; }
                let parts: Vec<&str> = t.split(':').collect();
                if file == "globs2" {
                    if parts.len() >= 3 && parts[2] == needle { return Some(parts[1].to_string()); }
                } else if parts.len() >= 2 && parts[1] == needle {
                    return Some(parts[0].to_string());
                }
            }
        }
    }
    None
}

#[derive(Default)]
struct MimeApps { defaults: BTreeMap<String, Vec<String>>, added: BTreeMap<String, Vec<String>> }

fn read_mimeapps() -> MimeApps {
    let mut out = MimeApps::default();
    let path = mimeapps_path();
    let text = fs::read_to_string(path).unwrap_or_default();
    let mut section = String::new();
    for line in text.lines() {
        let t = line.trim();
        if t.starts_with('[') && t.ends_with(']') { section = t[1..t.len()-1].to_string(); continue; }
        if let Some((k, v)) = t.split_once('=') {
            let vals = v.split(';').filter(|x| !x.is_empty()).map(|x| x.to_string()).collect();
            if section == "Default Applications" { out.defaults.insert(k.to_string(), vals); }
            else if section == "Added Associations" { out.added.insert(k.to_string(), vals); }
        }
    }
    out
}

fn write_mimeapps(mf: &MimeApps) -> io::Result<()> {
    let path = mimeapps_path();
    if let Some(p) = path.parent() { fs::create_dir_all(p)?; }
    let mut s = String::from("[Added Associations]\n");
    for (k, vals) in &mf.added { s.push_str(k); s.push('='); for v in vals { s.push_str(v); s.push(';'); } s.push('\n'); }
    s.push_str("\n[Default Applications]\n");
    for (k, vals) in &mf.defaults { s.push_str(k); s.push('='); for v in vals { s.push_str(v); s.push(';'); } s.push('\n'); }
    fs::write(path, s)
}

fn find_handler(mime: &str) -> Option<(String, Option<DesktopEntry>)> {
    let apps = scan_desktops();
    let mf = read_mimeapps();
    if let Some(ids) = mf.defaults.get(mime) { for id in ids { return Some((id.clone(), apps.get(id).cloned())); } }
    let wildcard = mime.split_once('/').map(|(t, _)| format!("{}/*", t));
    if let Some(w) = wildcard.as_ref() { if let Some(ids) = mf.defaults.get(w) { for id in ids { return Some((id.clone(), apps.get(id).cloned())); } } }
    for app in apps.values() { if app.mimes.iter().any(|m| m == mime || wildcard.as_ref().is_some_and(|w| m == w)) { return Some((app.id.clone(), Some(app.clone()))); } }
    None
}

fn scan_desktops() -> BTreeMap<String, DesktopEntry> {
    let mut dirs = Vec::new();
    dirs.push(data_home().join("applications"));
    let data_dirs = env::var("XDG_DATA_DIRS").unwrap_or_else(|_| "/usr/local/share:/usr/share".to_string());
    for d in data_dirs.split(':') { dirs.push(Path::new(d).join("applications")); }
    let mut map = BTreeMap::new();
    for dir in dirs {
        if let Ok(rd) = fs::read_dir(dir) {
            for ent in rd.flatten() {
                let p = ent.path();
                if p.extension().and_then(|e| e.to_str()) == Some("desktop") {
                    if let Some(de) = parse_desktop(&p) { map.entry(de.id.clone()).or_insert(de); }
                }
            }
        }
    }
    map
}

fn parse_desktop(path: &Path) -> Option<DesktopEntry> {
    let text = fs::read_to_string(path).ok()?;
    let mut in_entry = false; let mut name = String::new(); let mut exec = String::new(); let mut mimes = Vec::new(); let mut typ = String::new();
    for line in text.lines() {
        let t = line.trim();
        if t.starts_with('[') { in_entry = t == "[Desktop Entry]"; continue; }
        if !in_entry { continue; }
        if let Some((k, v)) = t.split_once('=') {
            match k { "Name" => name = v.to_string(), "Exec" => exec = v.to_string(), "MimeType" => mimes = v.split(';').filter(|x| !x.is_empty()).map(|x| x.to_string()).collect(), "Type" => typ = v.to_string(), _ => {} }
        }
    }
    if typ != "Application" { return None; }
    let id = path.file_name()?.to_str()?.to_string();
    Some(DesktopEntry { id, name, exec, mimes })
}

fn launch_app(app: &DesktopEntry, args: &[String]) -> i32 {
    let mut toks = split_words(&app.exec);
    if toks.is_empty() { return 1; }
    let mut argv: Vec<String> = Vec::new();
    let mut used_placeholder = false;
    for tok in toks.drain(..) {
        if tok == "%f" || tok == "%F" || tok == "%u" || tok == "%U" {
            argv.extend(args.iter().cloned());
            used_placeholder = true;
            continue;
        }
        let cleaned = remove_field_codes(&tok);
        if !cleaned.is_empty() { argv.push(cleaned); }
    }
    if !used_placeholder { argv.extend(args.iter().cloned()); }
    if argv.is_empty() { return 1; }
    match Command::new(&argv[0]).args(&argv[1..]).stdin(Stdio::null()).status() {
        Ok(s) => s.code().unwrap_or(1),
        Err(_) => 1,
    }
}

fn remove_field_codes(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '%' {
            if let Some(n) = chars.peek().copied() {
                if matches!(n, 'f'|'F'|'u'|'U'|'i'|'c'|'k'|'d'|'D'|'n'|'N'|'v'|'m') {
                    chars.next();
                    continue;
                }
                if n == '%' {
                    chars.next();
                    out.push('%');
                    continue;
                }
            }
        }
        out.push(ch);
    }
    out
}

fn clean_exec(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '\'' || ch == '"' { continue; }
        if ch == '%' {
            if let Some(n) = chars.peek().copied() {
                if matches!(n, 'f'|'F'|'u'|'U'|'i'|'c'|'k'|'d'|'D'|'n'|'N'|'v'|'m') {
                    chars.next();
                    continue;
                }
                if n == '%' {
                    chars.next();
                    out.push('%');
                    continue;
                }
            }
        }
        out.push(ch);
    }
    out.split_whitespace().collect::<Vec<_>>().join(" ")
}

fn split_words(s: &str) -> Vec<String> {
    let mut out = Vec::new(); let mut cur = String::new(); let mut quote: Option<char> = None; let mut escp = false;
    for ch in s.chars() {
        if escp { cur.push(ch); escp = false; continue; }
        if ch == '\\' { escp = true; continue; }
        if let Some(q) = quote { if ch == q { quote = None; } else { cur.push(ch); } continue; }
        if ch == '\'' || ch == '"' { quote = Some(ch); continue; }
        if ch.is_whitespace() { if !cur.is_empty() { out.push(cur.clone()); cur.clear(); } } else { cur.push(ch); }
    }
    if !cur.is_empty() { out.push(cur); }
    out
}

fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }

fn print_table(rows: &[(String, String)]) {
    if rows.is_empty() { println!("┌──┐\n│  │\n└──┘"); return; }
    let w1 = rows.iter().map(|r| r.0.chars().count()).max().unwrap_or(0);
    let w2 = rows.iter().map(|r| r.1.chars().count()).max().unwrap_or(0);
    println!("┌{}┬{}┐", "─".repeat(w1+2), "─".repeat(w2+2));
    for (a,b) in rows { println!("│ {}{} │ {}{} │", a, " ".repeat(w1-a.chars().count()), b, " ".repeat(w2-b.chars().count())); }
    println!("└{}┴{}┘", "─".repeat(w1+2), "─".repeat(w2+2));
}

fn init_config() {
    let handlr = config_home().join("handlr");
    let _ = fs::create_dir_all(&handlr);
    let cfg = handlr.join("handlr.toml");
    if !cfg.exists() { let _ = fs::write(cfg, "enable_selector = false\nselector = \"rofi -dmenu -i -p 'Open With: '\"\n"); }
    let mime = mimeapps_path();
    if let Some(p) = mime.parent() { let _ = fs::create_dir_all(p); }
    if !mime.exists() { let _ = fs::write(mime, ""); }
}
fn home() -> PathBuf { env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| PathBuf::from(".")) }
fn config_home() -> PathBuf { env::var_os("XDG_CONFIG_HOME").map(PathBuf::from).unwrap_or_else(|| home().join(".config")) }
fn data_home() -> PathBuf { env::var_os("XDG_DATA_HOME").map(PathBuf::from).unwrap_or_else(|| home().join(".local/share")) }
fn mimeapps_path() -> PathBuf { config_home().join("mimeapps.list") }
