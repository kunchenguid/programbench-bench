use std::env;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

const MAGIC: &[u8; 4] = b"\x28\xb5\x2f\xfd";
const BLOCK_MAX: usize = 128 * 1024;

#[derive(Default)]
struct Opts {
    decompress: bool,
    stdout: bool,
    force: bool,
    rm: bool,
    quiet: u8,
    level: i32,
    output: Option<PathBuf>,
    dict: Option<PathBuf>,
    inputs: Vec<String>,
    test: bool,
    list: bool,
    recursive: bool,
    filelist: Option<PathBuf>,
    format_gzip: bool,
    pass_through: bool,
}

fn short_help() -> &'static str {
    "Compress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.\n\nUsage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]\n\nOptions:\n  -o OUTPUT                     Write output to a single file, OUTPUT.\n  -k, --keep                    Preserve INPUT file(s). [Default] \n  --rm                          Remove INPUT file(s) after successful (de)compression to file.\n\n  -#                            Desired compression level, where `#` is a number between 1 and 19;\n                                lower numbers provide faster compression, higher numbers yield\n                                better compression ratios. [Default: 3]\n\n  -d, --decompress              Perform decompression.\n  -D DICT                       Use DICT as the dictionary for compression or decompression.\n\n  -f, --force                   Disable input and output checks. Allows overwriting existing files,\n                                receiving input from the console, printing output to STDOUT, and\n                                operating on links, block devices, etc. Unrecognized formats will be\n                                passed-through through as-is.\n\n  -h                            Display short usage and exit.\n  -H, --help                    Display full help and exit.\n  -V, --version                 Display the program version and exit.\n"
}

fn full_help() -> &'static str {
    "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***\n\nCompress or decompress the INPUT file(s); reads from STDIN if INPUT is `-` or not provided.\n\nUsage: executable [OPTIONS...] [INPUT... | -] [-o OUTPUT]\n\nOptions:\n  -o OUTPUT                     Write output to a single file, OUTPUT.\n  -k, --keep                    Preserve INPUT file(s). [Default] \n  --rm                          Remove INPUT file(s) after successful (de)compression to file.\n\n  -#                            Desired compression level, where `#` is a number between 1 and 19;\n                                lower numbers provide faster compression, higher numbers yield\n                                better compression ratios. [Default: 3]\n\n  -d, --decompress              Perform decompression.\n  -D DICT                       Use DICT as the dictionary for compression or decompression.\n\n  -f, --force                   Disable input and output checks. Allows overwriting existing files,\n                                receiving input from the console, printing output to STDOUT, and\n                                operating on links, block devices, etc. Unrecognized formats will be\n                                passed-through through as-is.\n\n  -h                            Display short usage and exit.\n  -H, --help                    Display full help and exit.\n  -V, --version                 Display the program version and exit.\n\nAdvanced options:\n  -c, --stdout                  Write to STDOUT (even if it is a console) and keep the INPUT file(s).\n  -v, --verbose                 Enable verbose output; pass multiple times to increase verbosity.\n  -q, --quiet                   Suppress warnings; pass twice to suppress errors.\n  --trace LOG                   Log tracing information to LOG.\n  --[no-]progress               Forcibly show/hide the progress counter.\n  -r                            Operate recursively on directories.\n  --filelist LIST               Read a list of files to operate on from LIST.\n  --output-dir-flat DIR         Store processed files in DIR.\n  --output-dir-mirror DIR       Store processed files in DIR, respecting original directory structure.\n  --[no-]asyncio                Use asynchronous IO. [Default: Enabled]\n  --[no-]check                  Add XXH64 integrity checksums during compression. [Default: Add, Validate]\n  --format=zstd                 Compress files to the `.zst` format. [Default]\n  --format=gzip                 Compress files to the `.gz` format.\n\nAdvanced decompression options:\n  -l                            Print information about Zstandard-compressed files.\n  --test                        Test compressed file integrity.\n  -M#                           Set the memory usage limit to # megabytes.\n  --[no-]sparse                 Enable sparse mode. [Default: Enabled for files, disabled for STDOUT.]\n  --[no-]pass-through           Pass through uncompressed files as-is. [Default: Disabled]\n"
}

fn version() -> &'static str {
    "*** Zstandard CLI (64-bit) v1.6.0, by Yann Collet ***"
}

fn parse_args() -> Result<(Opts, bool), String> {
    let mut opts = Opts { level: 3, ..Default::default() };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    let mut end_opts = false;
    while i < args.len() {
        let arg = args[i].clone();
        if end_opts {
            opts.inputs.push(arg);
            i += 1;
            continue;
        }
        if arg == "--" {
            end_opts = true;
        } else if arg == "-h" {
            print!("{}", short_help());
            return Ok((opts, true));
        } else if arg == "-H" || arg == "--help" {
            print!("{}", full_help());
            return Ok((opts, true));
        } else if arg == "-V" || arg == "--version" {
            println!("{}", version());
            return Ok((opts, true));
        } else if arg == "-d" || arg == "--decompress" || arg == "--uncompress" {
            opts.decompress = true;
        } else if arg == "-c" || arg == "--stdout" || arg == "--to-stdout" {
            opts.stdout = true;
        } else if arg == "-f" || arg == "--force" {
            opts.force = true;
        } else if arg == "-k" || arg == "--keep" {
            opts.rm = false;
        } else if arg == "--rm" {
            opts.rm = true;
        } else if arg == "-q" || arg == "--quiet" {
            opts.quiet = opts.quiet.saturating_add(1);
        } else if arg == "-v" || arg == "--verbose" {
        } else if arg == "-t" || arg == "--test" {
            opts.decompress = true;
            opts.test = true;
        } else if arg == "-l" {
            opts.list = true;
            opts.decompress = true;
        } else if arg == "-r" {
            opts.recursive = true;
        } else if arg == "--format=gzip" {
            opts.format_gzip = true;
        } else if arg == "--format=zstd" || arg == "--no-progress" || arg == "--progress" ||
                  arg == "--asyncio" || arg == "--no-asyncio" || arg == "--check" ||
                  arg == "--no-check" || arg == "--ultra" || arg == "--adapt" ||
                  arg == "--long" || arg.starts_with("--long=") || arg == "--single-thread" ||
                  arg.starts_with("-T") || arg.starts_with("-M") || arg.starts_with("-b") ||
                  arg.starts_with("-e") || arg.starts_with("-i") || arg == "-S" ||
                  arg.starts_with("--jobsize=") || arg == "--rsyncable" ||
                  arg == "--exclude-compressed" || arg.starts_with("--stream-size=") ||
                  arg.starts_with("--size-hint=") || arg.starts_with("--target-compressed-block-size=") ||
                  arg == "--no-dictID" || arg == "--compress-literals" ||
                  arg == "--no-compress-literals" || arg == "--row-match-finder" ||
                  arg == "--no-row-match-finder" || arg == "--mmap-dict" ||
                  arg == "--no-mmap-dict" || arg.starts_with("--auto-threads=") ||
                  arg.starts_with("--priority=") || arg.starts_with("--split=") ||
                  arg == "--sparse" || arg == "--no-sparse" {
        } else if arg == "--pass-through" {
            opts.pass_through = true;
        } else if arg == "--no-pass-through" {
            opts.pass_through = false;
        } else if arg == "-o" {
            i += 1;
            if i >= args.len() {
                return Err("zstd: option `-o` requires an argument".to_string());
            }
            opts.output = Some(PathBuf::from(&args[i]));
        } else if let Some(v) = arg.strip_prefix("-o") {
            if v.is_empty() {
                return Err("zstd: option `-o` requires an argument".to_string());
            }
            opts.output = Some(PathBuf::from(v));
        } else if arg == "-D" {
            i += 1;
            if i >= args.len() {
                return Err("zstd: option `-D` requires an argument".to_string());
            }
            opts.dict = Some(PathBuf::from(&args[i]));
        } else if let Some(v) = arg.strip_prefix("-D") {
            if v.is_empty() {
                return Err("zstd: option `-D` requires an argument".to_string());
            }
            opts.dict = Some(PathBuf::from(v));
        } else if arg == "--filelist" {
            i += 1;
            if i >= args.len() {
                return Err("zstd: option `--filelist` requires an argument".to_string());
            }
            opts.filelist = Some(PathBuf::from(&args[i]));
        } else if let Some(v) = arg.strip_prefix("--filelist=") {
            opts.filelist = Some(PathBuf::from(v));
        } else if let Some(v) = arg.strip_prefix("--fast=") {
            opts.level = -v.parse::<i32>().unwrap_or(1).abs();
        } else if arg == "--fast" {
            opts.level = -1;
        } else if arg.starts_with('-') && arg.len() > 1 && arg[1..].chars().all(|c| c.is_ascii_digit()) {
            opts.level = arg[1..].parse::<i32>().unwrap_or(3);
        } else if arg.starts_with('-') && arg.len() > 2 {
            for ch in arg[1..].chars() {
                match ch {
                    'd' => opts.decompress = true,
                    'c' => opts.stdout = true,
                    'f' => opts.force = true,
                    'q' => opts.quiet = opts.quiet.saturating_add(1),
                    't' => {
                        opts.decompress = true;
                        opts.test = true;
                    }
                    'l' => {
                        opts.decompress = true;
                        opts.list = true;
                    }
                    'k' => opts.rm = false,
                    _ if ch.is_ascii_digit() => {}
                    _ => return Err(format!("zstd: unknown option -- '{}'", ch)),
                }
            }
        } else {
            opts.inputs.push(arg);
        }
        i += 1;
    }

    if let Some(list) = &opts.filelist {
        let s = fs::read_to_string(list).map_err(|e| format!("zstd: {}: {}", list.display(), e))?;
        opts.inputs.extend(s.lines().filter(|l| !l.is_empty()).map(|s| s.to_string()));
    }

    if opts.inputs.is_empty() {
        opts.inputs.push("-".to_string());
        opts.stdout = true;
    }

    Ok((opts, false))
}

fn encode_zstd_raw(input: &[u8], checksum: bool) -> Vec<u8> {
    let mut out = Vec::with_capacity(input.len() + input.len() / BLOCK_MAX * 3 + 16);
    out.extend_from_slice(MAGIC);
    let len = input.len() as u64;
    if len < 256 {
        out.push(0x20 | if checksum { 0x04 } else { 0 });
        out.push(len as u8);
    } else if len < 65_792 {
        out.push(0x40 | 0x20 | if checksum { 0x04 } else { 0 });
        out.extend_from_slice(&((len - 256) as u16).to_le_bytes());
    } else if len <= u32::MAX as u64 {
        out.push(0x80 | 0x20 | if checksum { 0x04 } else { 0 });
        out.extend_from_slice(&(len as u32).to_le_bytes());
    } else {
        out.push(0xC0 | 0x20 | if checksum { 0x04 } else { 0 });
        out.extend_from_slice(&len.to_le_bytes());
    }
    if input.is_empty() {
        out.extend_from_slice(&1u32.to_le_bytes()[..3]);
    } else {
        let mut pos = 0;
        while pos < input.len() {
            let take = (input.len() - pos).min(BLOCK_MAX);
            let last = pos + take == input.len();
            let header = ((take as u32) << 3) | if last { 1 } else { 0 };
            out.extend_from_slice(&header.to_le_bytes()[..3]);
            out.extend_from_slice(&input[pos..pos + take]);
            pos += take;
        }
    }
    if checksum {
        let h = xxh64(input, 0) as u32;
        out.extend_from_slice(&h.to_le_bytes());
    }
    out
}

fn decode_zstd(data: &[u8]) -> Result<(Vec<u8>, Option<u64>), String> {
    if data.len() < 5 || &data[..4] != MAGIC {
        return Err("unsupported format".to_string());
    }
    let mut p = 4;
    let desc = data[p];
    p += 1;
    if desc & 0x08 != 0 {
        return Err("unsupported frame descriptor".to_string());
    }
    let fcs_flag = desc >> 6;
    let single = desc & 0x20 != 0;
    let checksum = desc & 0x04 != 0;
    let dict_flag = desc & 0x03;
    if !single {
        if p >= data.len() {
            return Err("truncated frame".to_string());
        }
        p += 1; // Window descriptor. Raw block decoding does not need it.
    }
    p += match dict_flag {
        0 => 0,
        1 => 1,
        2 => 2,
        _ => 4,
    };
    if p > data.len() {
        return Err("truncated frame".to_string());
    }
    let fcs_size = match fcs_flag {
        0 if single => 1,
        0 => 0,
        1 => 2,
        2 => 4,
        _ => 8,
    };
    let declared_size = if fcs_size == 0 {
        None
    } else {
        if p + fcs_size > data.len() {
            return Err("truncated frame".to_string());
        }
        let v = match fcs_size {
            1 => data[p] as u64,
            2 => u16::from_le_bytes([data[p], data[p + 1]]) as u64 + 256,
            4 => u32::from_le_bytes([data[p], data[p + 1], data[p + 2], data[p + 3]]) as u64,
            _ => u64::from_le_bytes([
                data[p], data[p + 1], data[p + 2], data[p + 3],
                data[p + 4], data[p + 5], data[p + 6], data[p + 7],
            ]),
        };
        p += fcs_size;
        Some(v)
    };

    let mut out = Vec::with_capacity(declared_size.unwrap_or(0).min(16 * 1024 * 1024) as usize);
    loop {
        if p + 3 > data.len() {
            return Err("truncated block".to_string());
        }
        let bh = (data[p] as u32) | ((data[p + 1] as u32) << 8) | ((data[p + 2] as u32) << 16);
        p += 3;
        let last = bh & 1 != 0;
        let block_type = (bh >> 1) & 0x3;
        let size = (bh >> 3) as usize;
        match block_type {
            0 => {
                if p + size > data.len() {
                    return Err("truncated raw block".to_string());
                }
                out.extend_from_slice(&data[p..p + size]);
                p += size;
            }
            1 => {
                if p >= data.len() {
                    return Err("truncated rle block".to_string());
                }
                let b = data[p];
                p += 1;
                out.resize(out.len() + size, b);
            }
            2 => return Err("compressed blocks are not supported".to_string()),
            _ => return Err("reserved block type".to_string()),
        }
        if last {
            break;
        }
    }
    if checksum {
        if p + 4 > data.len() {
            return Err("truncated checksum".to_string());
        }
        let expect = u32::from_le_bytes([data[p], data[p + 1], data[p + 2], data[p + 3]]);
        let got = xxh64(&out, 0) as u32;
        if expect != got {
            return Err("checksum mismatch".to_string());
        }
    }
    if let Some(sz) = declared_size {
        if out.len() as u64 != sz {
            return Err("decompressed size mismatch".to_string());
        }
    }
    Ok((out, declared_size))
}

fn frame_content_size(data: &[u8]) -> Option<u64> {
    if data.len() < 5 || &data[..4] != MAGIC {
        return None;
    }
    let mut p = 4;
    let desc = data[p];
    p += 1;
    let single = desc & 0x20 != 0;
    if !single {
        p += 1;
    }
    p += match desc & 0x03 {
        0 => 0,
        1 => 1,
        2 => 2,
        _ => 4,
    };
    let fcs_flag = desc >> 6;
    let fcs_size = match fcs_flag {
        0 if single => 1,
        0 => 0,
        1 => 2,
        2 => 4,
        _ => 8,
    };
    if p + fcs_size > data.len() {
        return None;
    }
    match fcs_size {
        0 => None,
        1 => Some(data[p] as u64),
        2 => Some(u16::from_le_bytes([data[p], data[p + 1]]) as u64 + 256),
        4 => Some(u32::from_le_bytes([data[p], data[p + 1], data[p + 2], data[p + 3]]) as u64),
        _ => Some(u64::from_le_bytes([
            data[p], data[p + 1], data[p + 2], data[p + 3],
            data[p + 4], data[p + 5], data[p + 6], data[p + 7],
        ])),
    }
}

fn xxh64(input: &[u8], seed: u64) -> u64 {
    const P1: u64 = 11400714785074694791;
    const P2: u64 = 14029467366897019727;
    const P3: u64 = 1609587929392839161;
    const P4: u64 = 9650029242287828579;
    const P5: u64 = 2870177450012600261;
    fn round(acc: u64, lane: u64) -> u64 {
        (acc.wrapping_add(lane.wrapping_mul(P2))).rotate_left(31).wrapping_mul(P1)
    }
    fn merge(acc: u64, lane: u64) -> u64 {
        (acc ^ round(0, lane)).wrapping_mul(P1).wrapping_add(P4)
    }
    let mut p = 0;
    let mut h;
    if input.len() >= 32 {
        let mut v1 = seed.wrapping_add(P1).wrapping_add(P2);
        let mut v2 = seed.wrapping_add(P2);
        let mut v3 = seed;
        let mut v4 = seed.wrapping_sub(P1);
        while p + 32 <= input.len() {
            v1 = round(v1, u64::from_le_bytes(input[p..p + 8].try_into().unwrap()));
            v2 = round(v2, u64::from_le_bytes(input[p + 8..p + 16].try_into().unwrap()));
            v3 = round(v3, u64::from_le_bytes(input[p + 16..p + 24].try_into().unwrap()));
            v4 = round(v4, u64::from_le_bytes(input[p + 24..p + 32].try_into().unwrap()));
            p += 32;
        }
        h = v1.rotate_left(1)
            .wrapping_add(v2.rotate_left(7))
            .wrapping_add(v3.rotate_left(12))
            .wrapping_add(v4.rotate_left(18));
        h = merge(h, v1);
        h = merge(h, v2);
        h = merge(h, v3);
        h = merge(h, v4);
    } else {
        h = seed.wrapping_add(P5);
    }
    h = h.wrapping_add(input.len() as u64);
    while p + 8 <= input.len() {
        let k = round(0, u64::from_le_bytes(input[p..p + 8].try_into().unwrap()));
        h ^= k;
        h = h.rotate_left(27).wrapping_mul(P1).wrapping_add(P4);
        p += 8;
    }
    if p + 4 <= input.len() {
        h ^= (u32::from_le_bytes(input[p..p + 4].try_into().unwrap()) as u64).wrapping_mul(P1);
        h = h.rotate_left(23).wrapping_mul(P2).wrapping_add(P3);
        p += 4;
    }
    while p < input.len() {
        h ^= (input[p] as u64).wrapping_mul(P5);
        h = h.rotate_left(11).wrapping_mul(P1);
        p += 1;
    }
    h ^= h >> 33;
    h = h.wrapping_mul(P2);
    h ^= h >> 29;
    h = h.wrapping_mul(P3);
    h ^ (h >> 32)
}

fn collect_inputs(opts: &Opts) -> io::Result<Vec<String>> {
    let mut out = Vec::new();
    for inp in &opts.inputs {
        if inp == "-" {
            out.push(inp.clone());
            continue;
        }
        let p = Path::new(inp);
        if p.is_dir() && opts.recursive {
            collect_dir(p, &mut out)?;
        } else {
            out.push(inp.clone());
        }
    }
    Ok(out)
}

fn collect_dir(dir: &Path, out: &mut Vec<String>) -> io::Result<()> {
    for ent in fs::read_dir(dir)? {
        let ent = ent?;
        let path = ent.path();
        if path.is_dir() {
            collect_dir(&path, out)?;
        } else if path.is_file() {
            out.push(path.to_string_lossy().into_owned());
        }
    }
    Ok(())
}

fn default_output(input: &str, decompress: bool, format_gzip: bool) -> PathBuf {
    if input == "-" {
        return PathBuf::from("-");
    }
    if decompress {
        if let Some(s) = input.strip_suffix(".zst") {
            PathBuf::from(s)
        } else if let Some(s) = input.strip_suffix(".gz") {
            PathBuf::from(s)
        } else {
            PathBuf::from(format!("{input}.out"))
        }
    } else if format_gzip {
        PathBuf::from(format!("{input}.gz"))
    } else {
        PathBuf::from(format!("{input}.zst"))
    }
}

fn read_all(path: &str) -> io::Result<Vec<u8>> {
    let mut buf = Vec::new();
    if path == "-" {
        io::stdin().read_to_end(&mut buf)?;
    } else {
        File::open(path)?.read_to_end(&mut buf)?;
    }
    Ok(buf)
}

fn write_output(path: &Path, data: &[u8], force: bool) -> io::Result<()> {
    if path == Path::new("-") {
        io::stdout().write_all(data)?;
        return Ok(());
    }
    if path.exists() && !force {
        return Err(io::Error::new(io::ErrorKind::AlreadyExists, "already exists"));
    }
    let mut f = File::create(path)?;
    f.write_all(data)
}

fn human_bytes(n: u64) -> String {
    if n < 10_000 {
        format!("{:>6} B", n)
    } else if n < 10_000_000 {
        format!("{:>6.2} KB", n as f64 / 1024.0)
    } else {
        format!("{:>6.2} MB", n as f64 / 1024.0 / 1024.0)
    }
}

fn list_file(path: &str) -> Result<(), String> {
    let data = read_all(path).map_err(|e| format!("zstd: {path}: {e}"))?;
    let csize = data.len() as u64;
    let usize = frame_content_size(&data);
    println!("Frames  Skips  Compressed  Uncompressed  Ratio  Check  Filename");
    match usize {
        Some(u) => {
            let ratio = if csize == 0 { 0.0 } else { u as f64 / csize as f64 };
            println!("{:>6} {:>6} {:>7}   B {:>9}   B {:>6.3}  XXH64  {}", 1, 0, csize, u, ratio, path);
        }
        None => println!("{:>6} {:>6} {:>7}   B       unknown  -----  None   {}", 1, 0, csize, path),
    }
    Ok(())
}

fn main() {
    let (opts, done) = match parse_args() {
        Ok(v) => v,
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(1);
        }
    };
    if done {
        return;
    }

    if opts.format_gzip && !opts.decompress {
        eprintln!("zstd: gzip compression is not supported in this build");
        std::process::exit(1);
    }
    if let Some(p) = &opts.dict {
        let _ = fs::read(p).map_err(|e| {
            eprintln!("zstd: {}: {}", p.display(), e);
            std::process::exit(1);
        });
    }

    let inputs = match collect_inputs(&opts) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("zstd: {e}");
            std::process::exit(1);
        }
    };

    if opts.list {
        let mut ok = true;
        for input in &inputs {
            if let Err(e) = list_file(input) {
                eprintln!("{e}");
                ok = false;
            }
        }
        std::process::exit(if ok { 0 } else { 1 });
    }

    if inputs.len() > 1 && opts.output.is_some() && !opts.stdout {
        eprintln!("zstd: cannot use -o with multiple input files");
        std::process::exit(1);
    }

    let mut all_ok = true;
    for input in inputs {
        let source = match read_all(&input) {
            Ok(v) => v,
            Err(e) => {
                if opts.quiet < 2 {
                    eprintln!("zstd: {input}: {e}");
                }
                all_ok = false;
                continue;
            }
        };
        let result = if opts.decompress {
            match decode_zstd(&source) {
                Ok((v, _)) => Ok(v),
                Err(e) if opts.pass_through || opts.force => Ok(source.clone()),
                Err(e) => Err(e),
            }
        } else {
            Ok(encode_zstd_raw(&source, true))
        };

        let result = match result {
            Ok(v) => v,
            Err(e) => {
                if opts.quiet < 2 {
                    eprintln!("zstd: {input}: {e}");
                }
                all_ok = false;
                continue;
            }
        };

        if opts.test {
            if opts.quiet == 0 && input != "-" {
                eprintln!("{}               : {} bytes ", input, result.len());
            }
            continue;
        }

        let out_path = if opts.stdout {
            PathBuf::from("-")
        } else if let Some(p) = &opts.output {
            p.clone()
        } else {
            default_output(&input, opts.decompress, opts.format_gzip)
        };

        if let Err(e) = write_output(&out_path, &result, opts.force) {
            if e.kind() == io::ErrorKind::AlreadyExists {
                eprintln!("zstd: {} already exists; not overwritten", out_path.display());
            } else {
                eprintln!("zstd: {}: {}", out_path.display(), e);
            }
            all_ok = false;
            continue;
        }

        if opts.rm && input != "-" && out_path != Path::new("-") {
            let _ = fs::remove_file(&input);
        }

        if opts.quiet == 0 && !opts.stdout && input != "-" {
            if opts.decompress {
                eprintln!("{}: {} bytes", out_path.display(), result.len());
            } else {
                let pct = if source.is_empty() { 0.0 } else { result.len() as f64 * 100.0 / source.len() as f64 };
                eprintln!(
                    "{:<20} :{:>6.2}%   ({} => {}, {}) ",
                    input,
                    pct,
                    human_bytes(source.len() as u64),
                    human_bytes(result.len() as u64),
                    out_path.display()
                );
            }
        }
    }

    std::process::exit(if all_ok { 0 } else { 1 });
}
