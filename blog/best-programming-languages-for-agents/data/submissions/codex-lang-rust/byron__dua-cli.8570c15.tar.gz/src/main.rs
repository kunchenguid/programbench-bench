use std::collections::HashSet;
use std::env;
use std::fs;
use std::io;
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Format {
    Metric,
    Binary,
    Bytes,
    Gb,
    Gib,
    Mb,
    Mib,
}

#[derive(Debug)]
struct Config {
    format: Format,
    apparent: bool,
    count_hard_links: bool,
    stay_on_filesystem: bool,
    ignore_dirs: Vec<PathBuf>,
}

#[derive(Debug, Default)]
struct Agg {
    bytes: u64,
    errors: u64,
    is_dir: bool,
}

#[derive(Debug, Default)]
struct Stats {
    entries: u64,
    smallest: Option<u64>,
    largest: Option<u64>,
}

#[derive(Debug)]
struct Row {
    bytes: u64,
    path: String,
    is_dir: bool,
    errors: u64,
    order: usize,
}

fn main() {
    let code = run();
    std::process::exit(code);
}

fn run() -> i32 {
    let mut cfg = Config {
        format: Format::Binary,
        apparent: false,
        count_hard_links: false,
        stay_on_filesystem: false,
        ignore_dirs: vec!["/proc", "/dev", "/sys", "/run"]
            .into_iter()
            .map(PathBuf::from)
            .collect(),
    };

    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "--help") {
        if let Some(cmd) = args.iter().find(|a| matches!(a.as_str(), "aggregate" | "a" | "interactive" | "i" | "completions")) {
            print_sub_help(cmd);
        } else {
            print_long_help();
        }
        return 0;
    }
    if args.iter().any(|a| a == "-h") {
        if let Some(cmd) = args.iter().find(|a| matches!(a.as_str(), "aggregate" | "a" | "interactive" | "i" | "completions")) {
            print_sub_help(cmd);
        } else {
            print_short_help();
        }
        return 0;
    }
    if args.iter().any(|a| a == "--version" || a == "-V") {
        println!("dua 2.32.2");
        return 0;
    }

    let mut subcmd = String::from("aggregate");
    let mut sub_index = None;
    for (idx, arg) in args.iter().enumerate() {
        if matches!(arg.as_str(), "aggregate" | "a" | "interactive" | "i" | "completions" | "help") {
            subcmd = arg.clone();
            sub_index = Some(idx);
            break;
        }
    }

    if subcmd == "help" {
        print_long_help();
        return 0;
    }
    if subcmd == "completions" {
        let shell = args.get(sub_index.unwrap_or(0) + 1).cloned();
        return completions(shell);
    }
    if subcmd == "interactive" || subcmd == "i" {
        let _ = parse_global(&mut cfg, &args[..sub_index.unwrap_or(args.len())]);
        eprintln!("interactive mode is not available in this reimplementation");
        return aggregate_cmd(&cfg, &[], false, false, false);
    }

    let split = sub_index.unwrap_or(args.len());
    let mut pre_inputs = Vec::new();
    let post = if sub_index.is_some() { args[split + 1..].to_vec() } else { Vec::new() };
    let mut pi = 0;
    while pi < split {
        if args[pi].starts_with('-') {
            if let Err(msg) = parse_global_one(&mut cfg, &args[..split], &mut pi) {
                eprintln!("{msg}");
                return 2;
            }
        } else {
            pre_inputs.push(args[pi].clone());
        }
        pi += 1;
    }

    let mut stats = false;
    let mut no_sort = false;
    let mut no_total = false;
    let mut inputs = Vec::new();
    let mut i = 0;
    while i < post.len() {
        match post[i].as_str() {
            "--stats" => stats = true,
            "--no-sort" => no_sort = true,
            "--no-total" => no_total = true,
            "-h" | "--help" => {
                print_sub_help(&"aggregate".to_string());
                return 0;
            }
            arg if arg.starts_with('-') => {
                if let Err(msg) = parse_global_one(&mut cfg, &post, &mut i) {
                    eprintln!("{msg}");
                    return 2;
                }
            }
            _ => inputs.push(post[i].clone()),
        }
        i += 1;
    }
    inputs.extend(pre_inputs);
    aggregate_cmd(&cfg, &inputs, stats, no_sort, no_total)
}

fn parse_global(cfg: &mut Config, args: &[String]) -> Result<(), String> {
    let mut i = 0;
    while i < args.len() {
        parse_global_one(cfg, args, &mut i)?;
        i += 1;
    }
    Ok(())
}

fn parse_global_one(cfg: &mut Config, args: &[String], i: &mut usize) -> Result<(), String> {
    let arg = args[*i].as_str();
    match arg {
        "-A" | "--apparent-size" => cfg.apparent = true,
        "-l" | "--count-hard-links" => cfg.count_hard_links = true,
        "-x" | "--stay-on-filesystem" => cfg.stay_on_filesystem = true,
        "-t" | "--threads" | "--log-file" => {
            *i += 1;
            if *i >= args.len() {
                return Err(format!("error: a value is required for '{arg}' but none was supplied"));
            }
        }
        "-f" | "--format" => {
            *i += 1;
            if *i >= args.len() {
                return Err(format!("error: a value is required for '{arg}' but none was supplied"));
            }
            cfg.format = parse_format(&args[*i])?;
        }
        s if s.starts_with("--format=") => cfg.format = parse_format(&s[9..])?,
        "-i" | "--ignore-dirs" => {
            *i += 1;
            if *i >= args.len() {
                return Err(format!("error: a value is required for '{arg}' but none was supplied"));
            }
            cfg.ignore_dirs.push(PathBuf::from(&args[*i]));
        }
        s if s.starts_with('-') => {
            return Err(format!(
                "error: unexpected argument '{s}' found\n\nUsage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n\nFor more information, try '--help'."
            ));
        }
        _ => {}
    }
    Ok(())
}

fn parse_format(s: &str) -> Result<Format, String> {
    match s {
        "metric" => Ok(Format::Metric),
        "binary" => Ok(Format::Binary),
        "bytes" => Ok(Format::Bytes),
        "gb" => Ok(Format::Gb),
        "gib" => Ok(Format::Gib),
        "mb" => Ok(Format::Mb),
        "mib" => Ok(Format::Mib),
        other => Err(format!(
            "error: invalid value '{other}' for '--format <FORMAT>'\n  [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\nFor more information, try '--help'."
        )),
    }
}

fn aggregate_cmd(cfg: &Config, inputs: &[String], show_stats: bool, no_sort: bool, no_total: bool) -> i32 {
    let mut seen = HashSet::new();
    let mut stats = Stats::default();
    let mut rows = Vec::new();
    let mut status = 0;

    let (roots, names): (Vec<PathBuf>, Option<Vec<String>>) = if inputs.is_empty() {
        let roots: Vec<PathBuf> = match fs::read_dir(".") {
            Ok(rd) => rd.filter_map(Result::ok).map(|e| e.path()).filter(|p| {
                fs::symlink_metadata(p).map(|m| !m.file_type().is_symlink()).unwrap_or(true)
            }).collect(),
            Err(err) => {
                eprintln!("{err}");
                return 1;
            }
        };
        (roots, None)
    } else if inputs.len() == 1 && is_dir_path(Path::new(&inputs[0])) {
        match fs::read_dir(&inputs[0]) {
            Ok(rd) => {
                let mut roots = Vec::new();
                let mut names = Vec::new();
                for ent in rd.filter_map(Result::ok) {
                    names.push(ent.file_name().to_string_lossy().to_string());
                    roots.push(ent.path());
                }
                (roots, Some(names))
            }
            Err(_) => (vec![PathBuf::from(&inputs[0])], None),
        }
    } else {
        (inputs.iter().map(PathBuf::from).collect(), None)
    };

    for (idx, path) in roots.iter().enumerate() {
        let name = names.as_ref().and_then(|n| n.get(idx).cloned()).unwrap_or_else(|| display_path(path));
        match aggregate_path(path, cfg, &mut seen, &mut stats, None, true) {
            Ok(agg) => {
                if agg.errors > 0 {
                    status = 1;
                }
                rows.push(Row { bytes: agg.bytes, path: name, is_dir: agg.is_dir, errors: agg.errors, order: idx });
            }
            Err(_) => {
                status = 1;
                rows.push(Row { bytes: 0, path: name, is_dir: true, errors: 1, order: idx });
            }
        }
    }

    if !no_sort {
        rows.sort_by(|a, b| a.bytes.cmp(&b.bytes).then(a.is_dir.cmp(&b.is_dir)).then(a.order.cmp(&b.order)));
    }
    let total: u64 = rows.iter().map(|r| r.bytes).sum();
    let multiple = rows.len() > 1;
    for row in &rows {
        print_row(cfg.format, row.bytes, &row.path, row.is_dir, row.errors);
    }
    if multiple && !no_total {
        print_row(cfg.format, total, "total", false, 0);
    }
    if show_stats {
        eprintln!(
            "Statistics {{ entries_traversed: {}, smallest_file_in_bytes: {}, largest_file_in_bytes: {} }}",
            stats.entries,
            stats.smallest.unwrap_or(0),
            stats.largest.unwrap_or(0)
        );
    }
    status
}

fn is_dir_path(path: &Path) -> bool {
    fs::symlink_metadata(path).map(|m| m.file_type().is_dir()).unwrap_or(false)
}

fn aggregate_path(
    path: &Path,
    cfg: &Config,
    seen: &mut HashSet<(u64, u64)>,
    stats: &mut Stats,
    root_dev: Option<u64>,
    count_entry: bool,
) -> io::Result<Agg> {
    let meta = fs::symlink_metadata(path)?;
    let ft = meta.file_type();
    if ft.is_symlink() {
        let bytes = if cfg.apparent { meta.len() } else { 0 };
        if count_entry { record_stats(stats, bytes); }
        return Ok(Agg { bytes, errors: 0, is_dir: false });
    }

    let dev = meta.dev();
    let is_root = root_dev.is_none();
    let root_dev = root_dev.unwrap_or(dev);
    if cfg.stay_on_filesystem && dev != root_dev {
        return Ok(Agg { bytes: 0, errors: 0, is_dir: ft.is_dir() });
    }
    if !is_root && ft.is_dir() && cfg.ignore_dirs.iter().any(|p| path == p) {
        return Ok(Agg { bytes: 0, errors: 0, is_dir: true });
    }

    let mut own = size_of(&meta, cfg.apparent);
    if !cfg.count_hard_links && !ft.is_dir() {
        let key = (meta.dev(), meta.ino());
        if !seen.insert(key) {
            own = 0;
        }
    }
    if count_entry {
        record_stats(stats, own);
    }
    let mut out = Agg { bytes: own, errors: 0, is_dir: ft.is_dir() };
    if ft.is_dir() {
        match fs::read_dir(path) {
            Ok(rd) => {
                for ent in rd {
                    match ent {
                        Ok(ent) => match aggregate_path(&ent.path(), cfg, seen, stats, Some(root_dev), true) {
                            Ok(child) => {
                                out.bytes = out.bytes.saturating_add(child.bytes);
                                out.errors += child.errors;
                            }
                            Err(_) => out.errors += 1,
                        },
                        Err(_) => out.errors += 1,
                    }
                }
            }
            Err(_) => out.errors += 1,
        }
    }
    Ok(out)
}

fn size_of(meta: &fs::Metadata, apparent: bool) -> u64 {
    if apparent {
        meta.len()
    } else {
        meta.blocks().saturating_mul(512)
    }
}

fn record_stats(stats: &mut Stats, bytes: u64) {
    stats.entries += 1;
    if bytes > 0 {
        stats.smallest = Some(stats.smallest.map_or(bytes, |v| v.min(bytes)));
        stats.largest = Some(stats.largest.map_or(bytes, |v| v.max(bytes)));
    }
}

fn display_path(path: &Path) -> String {
    let s = path.to_string_lossy();
    if let Some(stripped) = s.strip_prefix("./") {
        stripped.to_string()
    } else {
        s.to_string()
    }
}

fn print_row(format: Format, bytes: u64, path: &str, is_dir: bool, errors: u64) {
    let left = format_size(bytes, format);
    let path = if is_dir {
        format!("\x1b[36m{path}\x1b[39m")
    } else {
        path.to_string()
    };
    if errors > 0 {
        println!("\x1b[32m{left}\x1b[39m {path}  <{errors} IO Error>");
    } else {
        println!("\x1b[32m{left}\x1b[39m {path}");
    }
}

fn format_size(bytes: u64, format: Format) -> String {
    match format {
        Format::Bytes => format!("{:>10} b", bytes),
        Format::Metric => human(bytes as f64, 1000.0, &["B", "KB", "MB", "GB", "TB"]),
        Format::Binary => human(bytes as f64, 1024.0, &["B", "KiB", "MiB", "GiB", "TiB"]),
        Format::Gb => format!("{:>7.2} GB", bytes as f64 / 1_000_000_000.0),
        Format::Gib => format!("{:>6.2} GiB", bytes as f64 / 1_073_741_824.0),
        Format::Mb => format!("{:>9.2} MB", bytes as f64 / 1_000_000.0),
        Format::Mib => format!("{:>8.2} MiB", bytes as f64 / 1_048_576.0),
    }
}

fn human(mut n: f64, base: f64, units: &[&str]) -> String {
    let mut idx = 0;
    while n >= base && idx + 1 < units.len() {
        n /= base;
        idx += 1;
    }
    if idx == 0 {
        format!("{:>7.0}   {}", n, units[idx])
    } else {
        format!("{:>7.2} {}", n, units[idx])
    }
}

fn completions(shell: Option<String>) -> i32 {
    match shell.as_deref() {
        Some("bash") => {
            println!("_dua() {{");
            println!("    COMPREPLY=()");
            println!("}}");
            println!("complete -F _dua dua");
            0
        }
        Some("fish") | Some("zsh") | Some("powershell") | Some("elvish") => 0,
        Some(other) => {
            eprintln!("error: invalid value '{other}' for '<SHELL>'");
            2
        }
        None => {
            eprintln!("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completions <SHELL>\n\nFor more information, try '--help'.");
            2
        }
    }
}

fn print_sub_help(cmd: &str) {
    match cmd {
        "interactive" | "i" => println!(
            "Launch the terminal user interface\n\nUsage: executable interactive [OPTIONS] [INPUT]...\n\nArguments:\n  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory\n\nOptions:\n  -e, --no-entry-check  Do not check entries for presence when listing a directory to avoid slugging performance on slow filesystems\n  -h, --help            Print help"
        ),
        "completions" => println!(
            "Generate shell completions\n\nUsage: executable completions <SHELL>\n\nArguments:\n  <SHELL>  The shell to generate a completions-script for [possible values: bash, elvish, fish, powershell, zsh]\n\nOptions:\n  -h, --help  Print help"
        ),
        _ => println!(
            "Aggregate the consumed space of one or more directories or files\n\nUsage: executable aggregate [OPTIONS] [INPUT]...\n\nArguments:\n  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory\n\nOptions:\n      --stats     If set, print additional statistics about the file traversal to stderr\n      --no-sort   If set, paths will be printed in their order of occurrence on the command-line. Otherwise they are sorted by their size in bytes, ascending\n      --no-total  If set, no total column will be computed for multiple inputs\n  -h, --help      Print help"
        ),
    }
}

fn print_long_help() {
    println!("A tool to learn about disk usage, fast!\n\nUsage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n\nCommands:\n  interactive  Launch the terminal user interface [aliases: i]\n  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]\n  completions  Generate shell completions\n  help         Print this message or the help of the given subcommand(s)\n\nArguments:\n  [INPUT]...\n          One or more input files or directories. If unset, we will use all entries in the current working directory\n\nOptions:\n  -t, --threads <THREADS>\n          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread\n          \n          [default: 0]\n\n  -f, --format <FORMAT>\n          The format with which to print byte counts\n          \n          [default: binary]\n          [possible values: metric, binary, bytes, gb, gib, mb, mib]\n\n  -A, --apparent-size\n          Display apparent size instead of disk usage\n\n  -l, --count-hard-links\n          Count hard-linked files each time they are seen\n\n  -x, --stay-on-filesystem\n          If set, we will not cross filesystems or traverse mount points\n\n  -i, --ignore-dirs <IGNORE_DIRS>\n          One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path.\n          \n          Hence, they will only be ignored if they are eventually reached as part of the traversal.\n          \n          [default: /proc /dev /sys /run]\n\n      --log-file <LOG_FILE>\n          Write a log file with debug information, including panics\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
}

fn print_short_help() {
    println!("A tool to learn about disk usage, fast!\n\nUsage: dua [FLAGS] [OPTIONS] [SUBCOMMAND] [INPUT]...\n\nCommands:\n  interactive  Launch the terminal user interface [aliases: i]\n  aggregate    Aggregate the consumed space of one or more directories or files [aliases: a]\n  completions  Generate shell completions\n  help         Print this message or the help of the given subcommand(s)\n\nArguments:\n  [INPUT]...  One or more input files or directories. If unset, we will use all entries in the current working directory\n\nOptions:\n  -t, --threads <THREADS>          The amount of threads to use. Defaults to 0, indicating the amount of logical processors. Set to 1 to use only a single thread [default: 0]\n  -f, --format <FORMAT>            The format with which to print byte counts [default: binary] [possible values: metric, binary, bytes, gb, gib, mb, mib]\n  -A, --apparent-size              Display apparent size instead of disk usage\n  -l, --count-hard-links           Count hard-linked files each time they are seen\n  -x, --stay-on-filesystem         If set, we will not cross filesystems or traverse mount points\n  -i, --ignore-dirs <IGNORE_DIRS>  One or more absolute directories to ignore. Note that these are not ignored if they are passed as input path [default: /proc /dev /sys /run]\n      --log-file <LOG_FILE>        Write a log file with debug information, including panics\n  -h, --help                       Print help (see more with '--help')\n  -V, --version                    Print version");
}
