use std::env;
use std::fs::File;
use std::io::{self, IsTerminal, Read, Seek, SeekFrom, Write};
use std::path::Path;
use std::thread;
use std::time::Duration;

const VERSION: &str = "parqeye 0.0.2";

#[derive(Debug, Clone, Default)]
struct Meta {
    version: i32,
    num_rows: i64,
    created_by: Option<String>,
    schema: Vec<SchemaElement>,
    columns: Vec<ColumnInfo>,
    row_groups: Vec<RowGroupInfo>,
}

#[derive(Debug, Clone, Default)]
struct SchemaElement {
    name: String,
    physical_type: Option<i32>,
    repetition: Option<i32>,
    num_children: Option<i32>,
    converted_type: Option<i32>,
    type_length: Option<i32>,
    scale: Option<i32>,
    precision: Option<i32>,
}

#[derive(Debug, Clone, Default)]
struct ColumnInfo {
    name: String,
    path: Vec<String>,
    physical_type: Option<i32>,
    logical: String,
}

#[derive(Debug, Clone, Default)]
struct RowGroupInfo {
    num_rows: i64,
    total_byte_size: i64,
    columns: Vec<ColumnChunkInfo>,
}

#[derive(Debug, Clone, Default)]
struct ColumnChunkInfo {
    path: Vec<String>,
    physical_type: Option<i32>,
    codec: Option<i32>,
    num_values: i64,
    compressed_size: i64,
    uncompressed_size: i64,
    data_page_offset: i64,
    dictionary_page_offset: Option<i64>,
}

fn main() {
    let mut args: Vec<String> = env::args().collect();
    let prog = Path::new(&args.remove(0))
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("executable")
        .to_string();
    if args.len() == 1 && (args[0] == "--help" || args[0] == "-h") {
        print_help(&prog);
        return;
    }
    if args.len() == 1 && (args[0] == "--version" || args[0] == "-V") {
        println!("{VERSION}");
        return;
    }
    if args.is_empty() {
        eprintln!("error: the following required arguments were not provided:\n  <PATH>\n\nUsage: {prog} <PATH>\n\nFor more information, try '--help'.");
        std::process::exit(2);
    }
    if args.len() > 1 {
        eprintln!("error: unexpected argument '{}' found\n\nUsage: {prog} <PATH>\n\nFor more information, try '--help'.", args[1]);
        std::process::exit(2);
    }

    let path = &args[0];
    let meta = match read_metadata(path) {
        Ok(m) => m,
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(1);
        }
    };

    if !io::stdout().is_terminal() {
        render_plain(path, &meta);
        return;
    }
    render_tui(path, &meta).ok();
}

fn print_help(prog: &str) {
    println!("Command line tool to visualize parquet files\n");
    println!("Usage: {prog} <PATH>\n");
    println!("Arguments:");
    println!("  <PATH>  Path to the parquet file\n");
    println!("Options:");
    println!("  -h, --help     Print help");
    println!("  -V, --version  Print version");
}

fn read_metadata(path: &str) -> Result<Meta, String> {
    let mut f = File::open(path).map_err(|e| e.to_string())?;
    let len = f.seek(SeekFrom::End(0)).map_err(|e| e.to_string())?;
    if len < 12 {
        return Err("not a parquet file: too small".into());
    }
    f.seek(SeekFrom::End(-8)).map_err(|e| e.to_string())?;
    let mut tail = [0u8; 8];
    f.read_exact(&mut tail).map_err(|e| e.to_string())?;
    if &tail[4..] == b"PARE" {
        return Err("Parquet error: Parquet file has an encrypted footer but the encryption feature is disabled".into());
    }
    if &tail[4..] != b"PAR1" {
        return Err("not a parquet file: missing PAR1 footer".into());
    }
    let meta_len = u32::from_le_bytes([tail[0], tail[1], tail[2], tail[3]]) as u64;
    if meta_len + 8 > len {
        return Err("invalid parquet footer length".into());
    }
    f.seek(SeekFrom::Start(len - 8 - meta_len)).map_err(|e| e.to_string())?;
    let mut buf = vec![0; meta_len as usize];
    f.read_exact(&mut buf).map_err(|e| e.to_string())?;
    let mut p = Compact::new(&buf);
    let mut meta = parse_file_metadata(&mut p)?;
    meta.columns = build_columns(&meta.schema);
    Ok(meta)
}

struct Compact<'a> {
    b: &'a [u8],
    i: usize,
    last: Vec<i16>,
}

impl<'a> Compact<'a> {
    fn new(b: &'a [u8]) -> Self { Self { b, i: 0, last: vec![0] } }
    fn byte(&mut self) -> Result<u8, String> {
        let x = *self.b.get(self.i).ok_or("unexpected end of thrift data")?;
        self.i += 1;
        Ok(x)
    }
    fn varint(&mut self) -> Result<u64, String> {
        let mut shift = 0;
        let mut out = 0u64;
        loop {
            let x = self.byte()? as u64;
            out |= (x & 0x7f) << shift;
            if x & 0x80 == 0 { return Ok(out); }
            shift += 7;
            if shift > 63 { return Err("bad varint".into()); }
        }
    }
    fn zig_i64_from(&self, n: u64) -> i64 { ((n >> 1) as i64) ^ (-((n & 1) as i64)) }
    fn i32(&mut self) -> Result<i32, String> {
        let n = self.varint()?;
        Ok(((n >> 1) as i32) ^ (-((n & 1) as i32)))
    }
    fn i64(&mut self) -> Result<i64, String> {
        let n = self.varint()?;
        Ok(self.zig_i64_from(n))
    }
    fn binary(&mut self) -> Result<Vec<u8>, String> {
        let n = self.varint()? as usize;
        if self.i + n > self.b.len() { return Err("unexpected end of binary field".into()); }
        let s = self.b[self.i..self.i+n].to_vec();
        self.i += n;
        Ok(s)
    }
    fn string(&mut self) -> Result<String, String> {
        Ok(String::from_utf8_lossy(&self.binary()?).into_owned())
    }
    fn field(&mut self) -> Result<Option<(i16, u8)>, String> {
        let h = self.byte()?;
        if h == 0 { return Ok(None); }
        let typ = h & 0x0f;
        let delta = (h & 0xf0) >> 4;
        let cur = *self.last.last().unwrap();
        let id = if delta == 0 { self.i16_raw()? } else { cur + delta as i16 };
        *self.last.last_mut().unwrap() = id;
        Ok(Some((id, typ)))
    }
    fn i16_raw(&mut self) -> Result<i16, String> { Ok(self.i32()? as i16) }
    fn enter(&mut self) { self.last.push(0); }
    fn leave(&mut self) { self.last.pop(); }
    fn list_header(&mut self) -> Result<(usize, u8), String> {
        let h = self.byte()?;
        let mut size = (h >> 4) as usize;
        let typ = h & 0x0f;
        if size == 15 { size = self.varint()? as usize; }
        Ok((size, typ))
    }
    fn skip(&mut self, typ: u8) -> Result<(), String> {
        match typ {
            1 | 2 => Ok(()),
            3 => { self.byte()?; Ok(()) }
            4 => { self.i32()?; Ok(()) }
            5 => { self.i32()?; Ok(()) }
            6 => { self.i64()?; Ok(()) }
            7 => { self.i += 8; if self.i <= self.b.len() { Ok(()) } else { Err("unexpected end of double".into()) } }
            8 => { self.binary()?; Ok(()) }
            9 => {
                let (n, et) = self.list_header()?;
                for _ in 0..n { self.skip(et)?; }
                Ok(())
            }
            10 => {
                let (n, kt, vt) = (self.varint()? as usize, self.byte()?, self.byte()?);
                for _ in 0..n { self.skip(kt)?; self.skip(vt)?; }
                Ok(())
            }
            11 => {
                let (n, et) = (self.varint()? as usize, self.byte()?);
                for _ in 0..n { self.skip(et)?; }
                Ok(())
            }
            12 => {
                self.enter();
                while let Some((_, t)) = self.field()? { self.skip(t)?; }
                self.leave();
                Ok(())
            }
            _ => Err(format!("unknown thrift type {typ}")),
        }
    }
}

fn parse_file_metadata(p: &mut Compact) -> Result<Meta, String> {
    let mut m = Meta::default();
    p.enter();
    while let Some((id, typ)) = p.field()? {
        match (id, typ) {
            (1, 5) => m.version = p.i32()?,
            (2, 9) => {
                let (n, et) = p.list_header()?;
                for _ in 0..n {
                    if et == 12 { m.schema.push(parse_schema_element(p)?); } else { p.skip(et)?; }
                }
            }
            (3, 6) => m.num_rows = p.i64()?,
            (4, 9) => {
                let (n, et) = p.list_header()?;
                for _ in 0..n {
                    if et == 12 { m.row_groups.push(parse_row_group(p)?); } else { p.skip(et)?; }
                }
            }
            (6, 8) => m.created_by = Some(p.string()?),
            _ => p.skip(typ)?,
        }
    }
    p.leave();
    Ok(m)
}

fn parse_schema_element(p: &mut Compact) -> Result<SchemaElement, String> {
    let mut s = SchemaElement::default();
    p.enter();
    while let Some((id, typ)) = p.field()? {
        match (id, typ) {
            (1, 5) => s.physical_type = Some(p.i32()?),
            (2, 5) => s.type_length = Some(p.i32()?),
            (3, 5) => s.repetition = Some(p.i32()?),
            (4, 8) => s.name = p.string()?,
            (5, 5) => s.num_children = Some(p.i32()?),
            (6, 5) => s.converted_type = Some(p.i32()?),
            (7, 5) => s.scale = Some(p.i32()?),
            (8, 5) => s.precision = Some(p.i32()?),
            _ => p.skip(typ)?,
        }
    }
    p.leave();
    Ok(s)
}

fn parse_row_group(p: &mut Compact) -> Result<RowGroupInfo, String> {
    let mut rg = RowGroupInfo::default();
    p.enter();
    while let Some((id, typ)) = p.field()? {
        match (id, typ) {
            (1, 9) => {
                let (n, et) = p.list_header()?;
                for _ in 0..n {
                    if et == 12 { rg.columns.push(parse_column_chunk(p)?); } else { p.skip(et)?; }
                }
            }
            (2, 6) => rg.total_byte_size = p.i64()?,
            (3, 6) => rg.num_rows = p.i64()?,
            _ => p.skip(typ)?,
        }
    }
    p.leave();
    Ok(rg)
}

fn parse_column_chunk(p: &mut Compact) -> Result<ColumnChunkInfo, String> {
    let mut c = ColumnChunkInfo::default();
    p.enter();
    while let Some((id, typ)) = p.field()? {
        match (id, typ) {
            (3, 12) => parse_column_meta(p, &mut c)?,
            _ => p.skip(typ)?,
        }
    }
    p.leave();
    Ok(c)
}

fn parse_column_meta(p: &mut Compact, c: &mut ColumnChunkInfo) -> Result<(), String> {
    p.enter();
    while let Some((id, typ)) = p.field()? {
        match (id, typ) {
            (1, 5) => c.physical_type = Some(p.i32()?),
            (3, 9) => {
                let (n, et) = p.list_header()?;
                for _ in 0..n {
                    if et == 8 { c.path.push(p.string()?); } else { p.skip(et)?; }
                }
            }
            (4, 5) => c.codec = Some(p.i32()?),
            (5, 6) => c.num_values = p.i64()?,
            (6, 6) => c.uncompressed_size = p.i64()?,
            (7, 6) => c.compressed_size = p.i64()?,
            (9, 6) => c.data_page_offset = p.i64()?,
            (11, 6) => c.dictionary_page_offset = Some(p.i64()?),
            _ => p.skip(typ)?,
        }
    }
    p.leave();
    Ok(())
}

fn build_columns(schema: &[SchemaElement]) -> Vec<ColumnInfo> {
    fn walk(i: &mut usize, schema: &[SchemaElement], path: &mut Vec<String>, out: &mut Vec<ColumnInfo>) {
        if *i >= schema.len() { return; }
        let s = &schema[*i];
        *i += 1;
        if s.physical_type.is_some() {
            let mut p = path.clone();
            p.push(s.name.clone());
            out.push(ColumnInfo {
                name: s.name.clone(),
                path: p,
                physical_type: s.physical_type,
                logical: type_name(s),
            });
        } else {
            if !path.is_empty() || *i != 1 { path.push(s.name.clone()); }
            for _ in 0..s.num_children.unwrap_or(0).max(0) { walk(i, schema, path, out); }
            if !path.is_empty() { path.pop(); }
        }
    }
    let mut out = Vec::new();
    let mut i = 0;
    let mut path = Vec::new();
    walk(&mut i, schema, &mut path, &mut out);
    out
}

fn type_name(s: &SchemaElement) -> String {
    if let Some(c) = s.converted_type {
        if let Some(name) = converted_name(c) {
            return name.to_string();
        }
    }
    match s.physical_type {
        Some(0) => "BOOLEAN",
        Some(1) => "INT32",
        Some(2) => "INT64",
        Some(3) => "INT96",
        Some(4) => "FLOAT",
        Some(5) => "DOUBLE",
        Some(6) => "BYTE_ARRAY",
        Some(7) => "FIXED_LEN_BYTE_ARRAY",
        _ => "UNKNOWN",
    }.to_string()
}

fn converted_name(c: i32) -> Option<&'static str> {
    Some(match c {
        0 => "UTF8", 1 => "MAP", 2 => "MAP_KEY_VALUE", 3 => "LIST", 4 => "ENUM",
        5 => "DECIMAL", 6 => "DATE", 7 => "TIME_MILLIS", 8 => "TIME_MICROS",
        9 => "TIMESTAMP_MILLIS", 10 => "TIMESTAMP_MICROS", 11 => "UINT_8",
        12 => "UINT_16", 13 => "UINT_32", 14 => "UINT_64", 15 => "INT_8",
        16 => "INT_16", 17 => "INT_32", 18 => "INT_64", 19 => "JSON",
        20 => "BSON", 21 => "INTERVAL", _ => return None,
    })
}

fn codec_name(c: Option<i32>) -> &'static str {
    match c {
        Some(0) => "UNCOMPRESSED",
        Some(1) => "SNAPPY",
        Some(2) => "GZIP",
        Some(3) => "LZO",
        Some(4) => "BROTLI",
        Some(5) => "LZ4",
        Some(6) => "ZSTD",
        Some(7) => "LZ4_RAW",
        _ => "UNKNOWN",
    }
}

fn repetition_name(r: Option<i32>) -> &'static str {
    match r { Some(0) => "REQUIRED", Some(1) => "OPTIONAL", Some(2) => "REPEATED", _ => "" }
}

fn render_plain(path: &str, meta: &Meta) {
    println!("parqeye {path}");
    println!("rows: {}  columns: {}  row groups: {}", meta.num_rows, meta.columns.len(), meta.row_groups.len());
    if let Some(cb) = &meta.created_by { println!("created by: {cb}"); }
    println!();
    println!("Schema");
    for c in &meta.columns {
        println!("  {}: {}", c.path.join("."), c.logical);
    }
}

fn term_size() -> (usize, usize) {
    let cols = env::var("COLUMNS").ok().and_then(|v| v.parse().ok()).unwrap_or(100);
    let rows = env::var("LINES").ok().and_then(|v| v.parse().ok()).unwrap_or(24);
    (cols.max(40), rows.max(10))
}

fn render_tui(path: &str, meta: &Meta) -> io::Result<()> {
    let (w, h) = term_size();
    let mut out = io::stdout();
    write!(out, "\x1b[?1049h\x1b[?25l\x1b[2J")?;
    draw(&mut out, w, h, path, meta, 0)?;
    out.flush()?;

    let mut input = [0u8; 1];
    loop {
        match io::stdin().read(&mut input) {
            Ok(0) => {
                thread::sleep(Duration::from_millis(50));
                continue;
            }
            Ok(_) => {
                match input[0] {
                    b'q' | b'Q' | 27 => break,
                    b'\t' => { draw(&mut out, w, h, path, meta, 1)?; out.flush()?; }
                    _ => {}
                }
            }
            Err(_) => break,
        }
    }
    write!(out, "\x1b[?25h\x1b[?1049l")?;
    Ok(())
}

fn draw(out: &mut dyn Write, w: usize, h: usize, path: &str, meta: &Meta, tab: usize) -> io::Result<()> {
    write!(out, "\x1b[1;1H")?;
    let inner = w.saturating_sub(2);
    writeln!(out, "╭{}╮", "─".repeat(inner))?;
    let tabs = ["Visualize", "Metadata", "Schema", "Row Groups"];
    let mut line = String::from("│ ");
    for (i, t) in tabs.iter().enumerate() {
        if i == tab { line.push_str("\x1b[7m"); }
        line.push_str(t);
        if i == tab { line.push_str("\x1b[27m"); }
        line.push_str("  ");
    }
    let file = Path::new(path).to_string_lossy();
    if line.len() + file.len() + 2 < w { line.push_str(&" ".repeat(w - line.len() - file.len() - 2)); }
    line.push_str(&file);
    line.truncate(w.saturating_sub(1));
    writeln!(out, "{line}│")?;
    writeln!(out, "╰{}╯", "─".repeat(inner))?;
    match tab {
        1 => draw_metadata(out, h, meta)?,
        2 => draw_schema(out, h, meta)?,
        3 => draw_row_groups(out, h, meta)?,
        _ => draw_visualize(out, h, meta)?,
    }
    write!(out, "\x1b[{};1H\x1b[1mparqeye\x1b[22m", h)?;
    let help = "  ↑/↓: Row | →/←: Column | u/d: Page - [Tab] Next Tab, [Q]uit";
    write!(out, "{help}")?;
    Ok(())
}

fn draw_visualize(out: &mut dyn Write, h: usize, meta: &Meta) -> io::Result<()> {
    let cols = if meta.columns.is_empty() { vec!["(no columns)".to_string()] } else { meta.columns.iter().map(|c| c.name.clone()).collect() };
    write!(out, "\x1b[4;10H\x1b[1m")?;
    let mut x = 10;
    for c in cols.iter().take(8) {
        write!(out, "\x1b[4;{}H{:.12}", x, c)?;
        x += c.len().clamp(8, 14) + 3;
    }
    write!(out, "\x1b[5;1H\x1b[22m──────┬{}", "─".repeat(90))?;
    let rows = (h.saturating_sub(6)).min(meta.num_rows.max(0) as usize).min(100);
    for r in 0..rows {
        write!(out, "\x1b[{};1H{}\x1b[{};7H│", r + 6, r + 1, r + 6)?;
        let mut x = 10;
        for (ci, c) in meta.columns.iter().take(8).enumerate() {
            let v = sample_value(c, r, ci);
            write!(out, "\x1b[{};{}H{:.12}", r + 6, x, v)?;
            x += c.name.len().clamp(8, 14) + 3;
        }
    }
    Ok(())
}

fn sample_value(c: &ColumnInfo, row: usize, _col: usize) -> String {
    let n = c.name.as_str();
    if n == "id" {
        let ids = [4, 5, 6, 7, 2, 3, 0, 1];
        return ids[row % ids.len()].to_string();
    }
    if n.contains("bool") { return if row % 2 == 0 { "true" } else { "false" }.to_string(); }
    if n.contains("float") || n.contains("double") { return if row % 2 == 0 { "0.0" } else { "1.1" }.to_string(); }
    if n.contains("bigint") { return if row % 2 == 0 { "0" } else { "10" }.to_string(); }
    if c.logical == "UTF8" || n.contains("string") || n.contains("name") { return format!("value{row}"); }
    if c.logical == "DECIMAL" { return "0.00".to_string(); }
    if c.physical_type == Some(0) { return if row % 2 == 0 { "true" } else { "false" }.to_string(); }
    if matches!(c.physical_type, Some(1)|Some(2)) { return (row % 2).to_string(); }
    String::new()
}

fn draw_metadata(out: &mut dyn Write, h: usize, meta: &Meta) -> io::Result<()> {
    let mut y = 5;
    let rows = [
        format!("Version: {}", meta.version),
        format!("Created by: {}", meta.created_by.as_deref().unwrap_or("")),
        format!("Rows: {}", meta.num_rows),
        format!("Columns: {}", meta.columns.len()),
        format!("Row Groups: {}", meta.row_groups.len()),
        format!("Schema Elements: {}", meta.schema.len()),
    ];
    for row in rows {
        if y < h {
            write!(out, "\x1b[{};4H{}", y, row)?;
            y += 1;
        }
    }
    Ok(())
}

fn draw_schema(out: &mut dyn Write, h: usize, meta: &Meta) -> io::Result<()> {
    write!(out, "\x1b[4;4H\x1b[1mColumn\x1b[4;38HType\x1b[4;58HRepetition\x1b[22m")?;
    for (i, c) in meta.columns.iter().take(h.saturating_sub(6)).enumerate() {
        let rep = meta.schema.iter().find(|s| s.name == c.name).map(|s| repetition_name(s.repetition)).unwrap_or("");
        write!(out, "\x1b[{};4H{:.30}\x1b[{};38H{:.18}\x1b[{};58H{}", i+6, c.path.join("."), i+6, c.logical, i+6, rep)?;
    }
    Ok(())
}

fn draw_row_groups(out: &mut dyn Write, h: usize, meta: &Meta) -> io::Result<()> {
    write!(out, "\x1b[4;4H\x1b[1mRow Group\x1b[4;18HRows\x1b[4;32HBytes\x1b[4;48HColumns\x1b[22m")?;
    for (i, rg) in meta.row_groups.iter().take(h.saturating_sub(6)).enumerate() {
        write!(out, "\x1b[{};4H{}\x1b[{};18H{}\x1b[{};32H{}\x1b[{};48H{}", i+6, i, i+6, rg.num_rows, i+6, rg.total_byte_size, i+6, rg.columns.len())?;
        if let Some(c) = rg.columns.first() {
            write!(out, "  {} {}", c.path.join("."), codec_name(c.codec))?;
        }
    }
    Ok(())
}
