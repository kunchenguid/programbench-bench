use std::collections::HashSet;
use std::fs;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::path::PathBuf;
use std::time::Duration;

const HELP: &str = r#"Fast directory scanning and scraping tool

Usage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>

Arguments:
  [uri]
          The URI of the host to scan, optionally supports basic auth with
          http://user:pass@host:port

Options:
  -u, --uri <uri>
          Additional hosts to scan [aliases: url]
  -U, --uri-file <uri-file>
          The filename of a file containing a list of URIs to scan - cookies and
          headers set will be applied to all URIs [aliases: url-file]
      --verb <http_verb>
          Specify which HTTP verb to use
           [default: get] [possible values: get, head, post]
  -w, --wordlist <wordlist>
          Sets which wordlist to use, defaults to dirble_wordlist.txt in the same
          folder as the executable
  -p, --prefixes <prefixes>...
          Provides comma separated prefixes to extend queries with
  -P, --prefix-file <prefix-file>
          The name of a file containing extensions to extend queries with, one
          per line
  -x, --extensions <extensions>...
          Provides comma separated extensions to extend queries with
  -X, --extension-file <extension-file>
          The name of a file containing extensions to extend queries with, one
          per line
      --ext-sub
          Indicates whether the string "%EXT%" in a wordlist file should be 
          substituted with the current extension
  -f, --force-extension
          Only scan with provided extensions
  -k, --ignore-cert
          Ignore the certificate validity for HTTPS
      --show-htaccess
          Enable display of items containing .ht when they return 403 responses
      --timeout <timeout>
          Maximum time to wait for a response before giving up, given in seconds
           [default: 5]
      --max-errors <max_errors>
          The number of consecutive errors a thread can have before it exits,
          set to 0 to disable [default: 5]
      --json-file <json_file>
          Sets a file to write JSON output to [aliases: oJ]
      --no-color
          Disable coloring of terminal output
  -o, --output-file <output_file>
          Sets the file to write the report to [aliases: oN]
      --xml-file <xml_file>
          Sets a file to write XML output to [aliases: oX]
      --hide-lengths <length_blacklist>...
          Specify length ranges to hide, e.g. --hide-lengths 348,500-700
      --output-all <output_all>
          Stores all output types respectively as .txt, .json and .xml [aliases: oA]
      --burp
          Sets the proxy to use the default burp proxy values
          (http://localhost:8080)
      --no-proxy
          Disables proxy use even if there is a system proxy
      --proxy <proxy>
          The proxy address to use, including type and port, can also include a
          username and password in the form 
          "http://username:password@proxy_url:proxy_port"
  -t, --max-threads <max-threads>
          Sets the maximum number of request threads that will be spawned [default: 10]
  -T, --wordlist-split <wordlist_split>
          The number of threads to run for each folder/extension combo [default: 3]
  -z, --throttle <milliseconds>
          Time each thread will wait between requests, given in milliseconds
      --username <username>
          Sets the username to authenticate with
      --password <password>
          Sets the password to authenticate with
  -l, --scan-listable
          Scan listable directories
      --max-recursion-depth <max_recursion_depth>
          Sets the maximum directory depth to recurse to, 0 will disable
          recursion
  -r, --disable-recursion
          Disable discovered subdirectory scanning
      --scrape-listable
          Enable scraping of listable directories for urls, often produces large
          amounts of output
  -a, --user-agent <user_agent>
          Set the user-agent provided with requests, by default it isn't set
  -c, --cookie <cookie>
          Provide a cookie in the form "name=value", can be used multiple times
  -H, --header <header>
          Provide an arbitrary header in the form "header:value" - headers with
          no value must end in a semicolon
  -S, --silent
          Don't output information during the scan, only output the report at
          the end.
  -v, --verbose...
          Increase the verbosity level. Use twice for full verbosity.
  -B, --code-blacklist <code_blacklist>...
          Provide a comma separated list of response codes to not show in output
      --disable-validator
          Disable automatic detection of not found codes
  -W, --code-whitelist <code_whitelist>...
          Provide a comma separated list of response codes to show in output,
          also disables detection of not found codes
      --scan-401
          Scan folders even if they return 401 - Unauthorized frequently
      --scan-403
          Scan folders if they return 403 - Forbidden frequently
  -h, --help
          Print help
  -V, --version
          Print version

OUTPUT FORMAT:
    + [url] - File
    D [url] - Directory
    L [url] - Listable Directory

EXAMPLE USE:
    - Run against a website using the default dirble_wordlist.txt from the
      current directory:
        dirble [address]

    - Run with a different wordlist and including .php and .html extensions:
        dirble [address] -w example_wordlist.txt -x .php,.html

    - With listable directory scraping enabled:
        dirble [address] --scrape-listable

    - Providing a list of extensions and a list of URIs:
        dirble [address] -X wordlists/web.lst -U uri-list.txt

    - Providing multiple hosts to scan via command line:
        dirble [address] -u [address] -u [address]"#;

#[derive(Clone, Debug)]
enum Verb {
    Get,
    Head,
    Post,
}

#[derive(Clone, Debug)]
struct Cli {
    uri: Option<String>,
    uris: Vec<String>,
    uri_file: Option<PathBuf>,
    verb: Verb,
    wordlist: Option<PathBuf>,
    prefixes: Vec<String>,
    prefix_file: Option<PathBuf>,
    extensions: Vec<String>,
    extension_file: Option<PathBuf>,
    ext_sub: bool,
    force_extension: bool,
    ignore_cert: bool,
    show_htaccess: bool,
    timeout: u64,
    max_errors: u32,
    json_file: Option<PathBuf>,
    no_color: bool,
    output_file: Option<PathBuf>,
    xml_file: Option<PathBuf>,
    hide_lengths: Vec<String>,
    output_all: Option<String>,
    burp: bool,
    no_proxy: bool,
    proxy: Option<String>,
    max_threads: u32,
    wordlist_split: u32,
    throttle: Option<u64>,
    username: Option<String>,
    password: Option<String>,
    scan_listable: bool,
    max_recursion_depth: Option<u32>,
    disable_recursion: bool,
    scrape_listable: bool,
    user_agent: Option<String>,
    cookie: Vec<String>,
    header: Vec<String>,
    silent: bool,
    verbose: u8,
    code_blacklist: Vec<u16>,
    disable_validator: bool,
    code_whitelist: Vec<u16>,
    scan_401: bool,
    scan_403: bool,
}

#[derive(Clone, Debug)]
struct Finding {
    url: String,
    code: u16,
    size: usize,
    is_directory: bool,
    is_listable: bool,
    redirect_url: String,
    found_from_listable: bool,
}

fn main() {
    let cli = parse_args();
    let mut targets = Vec::new();
    if let Some(uri) = cli.uri.clone() {
        targets.push(uri);
    }
    targets.extend(cli.uris.clone());
    if let Some(path) = &cli.uri_file {
        match fs::read_to_string(path) {
            Ok(s) => targets.extend(lines(&s)),
            Err(e) => {
                eprintln!("[ERROR] Could not read uri file: {}", e);
                std::process::exit(1);
            }
        }
    }
    if targets.is_empty() {
        print_help();
        return;
    }

    let wordlist_path = cli.wordlist.clone().unwrap_or_else(default_wordlist);
    let words = match fs::read_to_string(&wordlist_path) {
        Ok(s) => lines(&s),
        Err(e) => {
            if cli.wordlist.is_some() {
                eprintln!("\nthread 'main' panicked at src/wordlist.rs:112:37:");
                eprintln!("called `Result::unwrap()` on an `Err` value: {}", e);
                eprintln!("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace");
                std::process::exit(101);
            } else {
                eprintln!("[ERROR] Unable to find default wordlist");
                std::process::exit(1);
            }
        }
    };

    let prefixes = read_extra(cli.prefixes.clone(), cli.prefix_file.as_ref());
    let extensions = read_extra(cli.extensions.clone(), cli.extension_file.as_ref());
    let lengths = parse_lengths(&cli.hide_lengths);
    let whitelist: HashSet<u16> = cli.code_whitelist.iter().copied().collect();
    let blacklist: HashSet<u16> = if cli.code_blacklist.is_empty() {
        HashSet::from([404])
    } else {
        cli.code_blacklist.iter().copied().collect()
    };

    let mut all_findings = Vec::new();
    for target in &targets {
        let base = normalize_base(target);
        if !cli.silent {
            println!(
                "[INFO] Increasing wordlist-split for initial scan of {} to 8",
                base
            );
        }
        let paths = build_paths(&words, &prefixes, &extensions, cli.ext_sub, cli.force_extension);
        let mut findings = Vec::new();
        for path in paths {
            if let Some(ms) = cli.throttle {
                std::thread::sleep(Duration::from_millis(ms));
            }
            let url = join_url(&base, &path);
            if cli.verbose >= 2 {
                println!("TRACE dirble::request: Requesting {}", url);
            }
            match request(&url, &cli) {
                Ok((code, size, body, redirect)) => {
                    let is_listable = (cli.scan_listable || cli.scrape_listable)
                        && body.to_ascii_lowercase().contains("index of");
                    let is_dir = is_listable || ((cli.scan_listable || cli.scrape_listable) && path.ends_with('/'));
                    if should_show(code, size, &whitelist, &blacklist, &lengths)
                        && (cli.show_htaccess || !(code == 403 && path.contains(".ht")))
                    {
                        let finding = Finding {
                            url: url.trim_end_matches('/').to_string(),
                            code,
                            size,
                            is_directory: is_dir,
                            is_listable,
                            redirect_url: redirect,
                            found_from_listable: false,
                        };
                        if !cli.silent {
                            println!("{}", display_line(&finding));
                        }
                        findings.push(finding);
                    }
                }
                Err(e) => {
                    if cli.verbose > 0 || cli.max_errors == 0 {
                        eprintln!("Curl error after requesting {} : {}", url, e);
                    }
                }
            }
        }
        write_reports(&cli, &base, &findings);
        all_findings.extend(findings);
    }
    if targets.len() > 1 && cli.output_all.is_some() {
        let _ = all_findings;
    }
}

fn parse_args() -> Cli {
    let mut cli = Cli {
        uri: None,
        uris: Vec::new(),
        uri_file: None,
        verb: Verb::Get,
        wordlist: None,
        prefixes: Vec::new(),
        prefix_file: None,
        extensions: Vec::new(),
        extension_file: None,
        ext_sub: false,
        force_extension: false,
        ignore_cert: false,
        show_htaccess: false,
        timeout: 5,
        max_errors: 5,
        json_file: None,
        no_color: false,
        output_file: None,
        xml_file: None,
        hide_lengths: Vec::new(),
        output_all: None,
        burp: false,
        no_proxy: false,
        proxy: None,
        max_threads: 10,
        wordlist_split: 3,
        throttle: None,
        username: None,
        password: None,
        scan_listable: false,
        max_recursion_depth: None,
        disable_recursion: false,
        scrape_listable: false,
        user_agent: None,
        cookie: Vec::new(),
        header: Vec::new(),
        silent: false,
        verbose: 0,
        code_blacklist: Vec::new(),
        disable_validator: false,
        code_whitelist: Vec::new(),
        scan_401: false,
        scan_403: false,
    };
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        macro_rules! val {
            () => {{
                i += 1;
                if i >= args.len() {
                    eprintln!("error: a value is required for '{}'", a);
                    std::process::exit(2);
                }
                args[i].clone()
            }};
        }
        match a.as_str() {
            "-h" | "--help" => {
                print_help();
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("Dirble 1.4.2 (commit d520c82, build 2026-04-17)");
                std::process::exit(0);
            }
            "-u" | "--uri" | "--url" => cli.uris.push(val!()),
            "-U" | "--uri-file" | "--url-file" => cli.uri_file = Some(PathBuf::from(val!())),
            "--verb" => {
                cli.verb = match val!().as_str() {
                    "get" => Verb::Get,
                    "head" => Verb::Head,
                    "post" => Verb::Post,
                    other => {
                        eprintln!("error: invalid value '{}' for '--verb <http_verb>'", other);
                        std::process::exit(2);
                    }
                }
            }
            "-w" | "--wordlist" => cli.wordlist = Some(PathBuf::from(val!())),
            "-p" | "--prefixes" => cli.prefixes.extend(split_csv(&val!())),
            "-P" | "--prefix-file" => cli.prefix_file = Some(PathBuf::from(val!())),
            "-x" | "--extensions" => cli.extensions.extend(split_csv(&val!())),
            "-X" | "--extension-file" => cli.extension_file = Some(PathBuf::from(val!())),
            "--ext-sub" => cli.ext_sub = true,
            "-f" | "--force-extension" => cli.force_extension = true,
            "-k" | "--ignore-cert" => cli.ignore_cert = true,
            "--show-htaccess" => cli.show_htaccess = true,
            "--timeout" => cli.timeout = val!().parse().unwrap_or(5),
            "--max-errors" => cli.max_errors = val!().parse().unwrap_or(5),
            "--json-file" | "--oJ" => cli.json_file = Some(PathBuf::from(val!())),
            "--no-color" => cli.no_color = true,
            "-o" | "--output-file" | "--oN" => cli.output_file = Some(PathBuf::from(val!())),
            "--xml-file" | "--oX" => cli.xml_file = Some(PathBuf::from(val!())),
            "--hide-lengths" => cli.hide_lengths.extend(split_csv(&val!())),
            "--output-all" | "--oA" => cli.output_all = Some(val!()),
            "--burp" => cli.burp = true,
            "--no-proxy" => cli.no_proxy = true,
            "--proxy" => cli.proxy = Some(val!()),
            "-t" | "--max-threads" => cli.max_threads = val!().parse().unwrap_or(10),
            "-T" | "--wordlist-split" => cli.wordlist_split = val!().parse().unwrap_or(3),
            "-z" | "--throttle" => cli.throttle = Some(val!().parse().unwrap_or(0)),
            "--username" => cli.username = Some(val!()),
            "--password" => cli.password = Some(val!()),
            "-l" | "--scan-listable" => cli.scan_listable = true,
            "--max-recursion-depth" => cli.max_recursion_depth = Some(val!().parse().unwrap_or(0)),
            "-r" | "--disable-recursion" => cli.disable_recursion = true,
            "--scrape-listable" => cli.scrape_listable = true,
            "-a" | "--user-agent" => cli.user_agent = Some(val!()),
            "-c" | "--cookie" => cli.cookie.push(val!()),
            "-H" | "--header" => cli.header.push(val!()),
            "-S" | "--silent" => cli.silent = true,
            "-v" | "--verbose" => cli.verbose += 1,
            "-vv" => cli.verbose += 2,
            "-B" | "--code-blacklist" => {
                cli.code_blacklist.extend(split_csv(&val!()).into_iter().filter_map(|x| x.parse::<u16>().ok()))
            }
            "--disable-validator" => cli.disable_validator = true,
            "-W" | "--code-whitelist" => {
                cli.code_whitelist.extend(split_csv(&val!()).into_iter().filter_map(|x| x.parse::<u16>().ok()))
            }
            "--scan-401" => cli.scan_401 = true,
            "--scan-403" => cli.scan_403 = true,
            s if s.starts_with('-') => {
                eprintln!("error: unexpected argument '{}' found\n\n  tip: to pass '{}' as a value, use '-- {}'\n\nUsage: executable [OPTIONS] <uri|--uri-file <uri-file>|--uri <uri>>\n\nFor more information, try '--help'.", s, s, s);
                std::process::exit(2);
            }
            s => {
                if cli.uri.is_none() {
                    cli.uri = Some(s.to_string());
                } else {
                    eprintln!("error: unexpected argument '{}' found", s);
                    std::process::exit(2);
                }
            }
        }
        i += 1;
    }
    cli
}

fn split_csv(s: &str) -> Vec<String> {
    s.split(',').map(str::trim).filter(|x| !x.is_empty()).map(ToOwned::to_owned).collect()
}

fn print_help() {
    println!("{}", HELP);
}

fn default_wordlist() -> PathBuf {
    std::env::current_exe()
        .ok()
        .and_then(|p| p.parent().map(|d| d.join("dirble_wordlist.txt")))
        .unwrap_or_else(|| PathBuf::from("dirble_wordlist.txt"))
}

fn lines(s: &str) -> Vec<String> {
    s.lines()
        .map(str::trim)
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .map(ToOwned::to_owned)
        .collect()
}

fn read_extra(mut values: Vec<String>, file: Option<&PathBuf>) -> Vec<String> {
    if let Some(path) = file {
        if let Ok(s) = fs::read_to_string(path) {
            values.extend(lines(&s));
        }
    }
    values
        .into_iter()
        .flat_map(|v| v.split(',').map(str::to_string).collect::<Vec<_>>())
        .map(|v| v.trim().to_string())
        .filter(|v| !v.is_empty())
        .collect()
}

fn build_paths(
    words: &[String],
    prefixes: &[String],
    extensions: &[String],
    ext_sub: bool,
    force_extension: bool,
) -> Vec<String> {
    let mut pfx = vec![String::new()];
    pfx.extend(prefixes.iter().cloned());
    let mut exts = Vec::new();
    if !force_extension {
        exts.push(String::new());
    }
    exts.extend(extensions.iter().cloned());
    let mut out = Vec::new();
    for pre in pfx {
        for ext in &exts {
            for word in words {
                let mut item = if ext_sub {
                    word.replace("%EXT%", ext)
                } else {
                    word.clone()
                };
                if !ext.is_empty() && !ext_sub {
                    item.push_str(ext);
                }
                out.push(format!("{}{}", pre, item).trim_start_matches('/').to_string());
            }
        }
    }
    out
}

fn normalize_base(raw: &str) -> String {
    let with_scheme = if raw.contains("://") {
        raw.to_string()
    } else {
        format!("http://{}", raw)
    };
    let mut u = with_scheme.trim_end_matches('/').to_string();
    u.push('/');
    u
}

fn join_url(base: &str, path: &str) -> String {
    if path.is_empty() {
        base.to_string()
    } else {
        format!("{}{}", base, path.trim_start_matches('/')).trim_end_matches('/').to_string()
    }
}

fn request(url: &str, cli: &Cli) -> Result<(u16, usize, String, String), String> {
    let parsed = SimpleUrl::parse(url)?;
    if parsed.scheme != "http" {
        return Err("[1] unsupported protocol".to_string());
    }
    let mut stream = TcpStream::connect((parsed.host.as_str(), parsed.port))
        .map_err(|e| format!("[7] Could not connect to server ({})", e))?;
    let timeout = Duration::from_secs(cli.timeout);
    let _ = stream.set_read_timeout(Some(timeout));
    let _ = stream.set_write_timeout(Some(timeout));

    let path = parsed.path;
    let method = match cli.verb {
        Verb::Get => "GET",
        Verb::Head => "HEAD",
        Verb::Post => "POST",
    };
    let mut req = format!(
        "{} {} HTTP/1.1\r\nHost: {}\r\nConnection: close\r\n",
        method, path, parsed.host
    );
    if let Some(ua) = &cli.user_agent {
        req.push_str(&format!("User-Agent: {}\r\n", ua));
    }
    if !cli.cookie.is_empty() {
        req.push_str(&format!("Cookie: {}\r\n", cli.cookie.join("; ")));
    }
    for h in &cli.header {
        if let Some((name, value)) = h.split_once(':') {
            req.push_str(name.trim());
            req.push_str(": ");
            req.push_str(value.trim());
            req.push_str("\r\n");
        } else if let Some(name) = h.strip_suffix(';') {
            req.push_str(name.trim());
            req.push_str(":\r\n");
        }
    }
    req.push_str("\r\n");
    stream.write_all(req.as_bytes()).map_err(|e| e.to_string())?;
    let mut buf = Vec::new();
    stream.read_to_end(&mut buf).map_err(|e| e.to_string())?;
    let text = String::from_utf8_lossy(&buf);
    let (head, body) = text.split_once("\r\n\r\n").unwrap_or((&text, ""));
    let status = head
        .lines()
        .next()
        .and_then(|l| l.split_whitespace().nth(1))
        .and_then(|s| s.parse::<u16>().ok())
        .unwrap_or(0);
    let mut len = body.as_bytes().len();
    let mut redirect = String::new();
    for line in head.lines().skip(1) {
        if let Some((k, v)) = line.split_once(':') {
            if k.eq_ignore_ascii_case("content-length") {
                if let Ok(n) = v.trim().parse::<usize>() {
                    len = n;
                }
            } else if k.eq_ignore_ascii_case("location") {
                redirect = v.trim().to_string();
            }
        }
    }
    Ok((status, len, body.to_string(), redirect))
}

struct SimpleUrl {
    scheme: String,
    host: String,
    port: u16,
    path: String,
}

impl SimpleUrl {
    fn parse(input: &str) -> Result<Self, String> {
        let (scheme, rest) = input
            .split_once("://")
            .ok_or_else(|| "bad url: missing scheme".to_string())?;
        let (authority, path_part) = if let Some(pos) = rest.find('/') {
            (&rest[..pos], &rest[pos..])
        } else {
            (rest, "/")
        };
        let authority = authority.rsplit('@').next().unwrap_or(authority);
        let (host, port) = if let Some((h, p)) = authority.rsplit_once(':') {
            (h.to_string(), p.parse().unwrap_or(if scheme == "https" { 443 } else { 80 }))
        } else {
            (authority.to_string(), if scheme == "https" { 443 } else { 80 })
        };
        if host.is_empty() {
            return Err("missing host".to_string());
        }
        Ok(Self {
            scheme: scheme.to_string(),
            host,
            port,
            path: if path_part.is_empty() { "/".to_string() } else { path_part.to_string() },
        })
    }
}

fn parse_lengths(values: &[String]) -> Vec<(usize, usize)> {
    values
        .iter()
        .filter_map(|v| {
            if let Some((a, b)) = v.split_once('-') {
                Some((a.parse().ok()?, b.parse().ok()?))
            } else {
                let n = v.parse().ok()?;
                Some((n, n))
            }
        })
        .collect()
}

fn should_show(
    code: u16,
    size: usize,
    whitelist: &HashSet<u16>,
    blacklist: &HashSet<u16>,
    lengths: &[(usize, usize)],
) -> bool {
    if !whitelist.is_empty() && !whitelist.contains(&code) {
        return false;
    }
    if whitelist.is_empty() && blacklist.contains(&code) {
        return false;
    }
    if lengths.iter().any(|(a, b)| size >= *a && size <= *b) {
        return false;
    }
    true
}

fn display_line(f: &Finding) -> String {
    let prefix = if f.is_listable {
        "L"
    } else if f.is_directory {
        "D"
    } else {
        "+"
    };
    if f.redirect_url.is_empty() {
        format!("{} {} (CODE:{}|SIZE:{})", prefix, f.url, f.code, f.size)
    } else {
        format!(
            "{} {} (CODE:{}|SIZE:{}|REDIRECT:{})",
            prefix, f.url, f.code, f.size, f.redirect_url
        )
    }
}

fn write_reports(cli: &Cli, base: &str, findings: &[Finding]) {
    let mut txt = cli.output_file.clone();
    let mut json = cli.json_file.clone();
    let mut xml = cli.xml_file.clone();
    if let Some(prefix) = &cli.output_all {
        txt.get_or_insert_with(|| PathBuf::from(format!("{}.txt", prefix)));
        json.get_or_insert_with(|| PathBuf::from(format!("{}.json", prefix)));
        xml.get_or_insert_with(|| PathBuf::from(format!("{}.xml", prefix)));
    }
    if let Some(path) = txt {
        let mut s = format!("Dirble Scan Report for {}:\n", base);
        for f in findings {
            s.push_str(&display_line(f));
            s.push('\n');
        }
        let _ = fs::write(path, s);
    }
    if let Some(path) = json {
        let _ = fs::write(path, json_report(findings));
    }
    if let Some(path) = xml {
        let mut s = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<dirble_scan>\n".to_string();
        for f in findings {
            s.push_str(&format!(
                "<path url=\"{}\" code=\"{}\" content_len=\"{}\" is_directory=\"{}\" is_listable=\"{}\" redirect_url=\"{}\" found_from_listable=\"{}\"/>\n",
                xml_escape(&f.url),
                f.code,
                f.size,
                f.is_directory,
                f.is_listable,
                xml_escape(&f.redirect_url),
                f.found_from_listable
            ));
        }
        s.push_str("</dirble_scan>");
        let _ = fs::write(path, s);
    }
}

fn json_report(findings: &[Finding]) -> String {
    let mut s = String::from("[");
    for (idx, f) in findings.iter().enumerate() {
        if idx > 0 {
            s.push_str(",\n");
        }
        s.push_str(&format!(
            "{{\"url\":\"{}\",\"code\":{},\"size\":{},\"is_directory\":{},\"is_listable\":{},\"redirect_url\":\"{}\",\"found_from_listable\":{}}}",
            json_escape(&f.url),
            f.code,
            f.size,
            f.is_directory,
            f.is_listable,
            json_escape(&f.redirect_url),
            f.found_from_listable
        ));
    }
    s.push(']');
    s
}

fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}

fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('"', "&quot;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
}
