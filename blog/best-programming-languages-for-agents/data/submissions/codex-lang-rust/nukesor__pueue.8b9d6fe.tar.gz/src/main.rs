use clap::{Arg, ArgAction, Command, ValueHint};
use std::env;
use std::path::PathBuf;
use std::process;

const VERSION: &str = "4.0.4";

const DELAY_AFTER_HELP: &str = r#"DELAY FORMAT:

    The --delay argument must be either a number of seconds or a "date expression" similar to GNU
    "date -d" with some extensions. It does not attempt to parse all natural language, but is
    incredibly flexible. Here are some supported examples.

    2020-04-01T18:30:00   // RFC 3339 timestamp
    2020-4-1 18:2:30      // Optional leading zeros
    2020-4-1 5:30pm       // Informal am/pm time
    2020-4-1 5pm          // Optional minutes and seconds
    April 1 2020 18:30:00 // English months
    1 Apr 8:30pm          // Implies current year
    4/1                   // American form date
    wednesday 10:30pm     // The closest wednesday in the future at 22:30
    wednesday             // The closest wednesday in the future
    4 months              // 4 months from today at 00:00:00
    1 week                // 1 week at the current time
    1days                 // 1 day from today at the current time
    1d 03:00              // The closest 3:00 after 1 day (24 hours)
    3h                    // 3 hours from now
    3600s                 // 3600 seconds from now"#;

const STATUS_QUERY_HELP: &str = r#"Users can specify a custom query to filter for specific values, order by a column
or limit the amount of tasks listed.

Syntax:
   [column_selection]? [filter]* [order_by]? [limit]?

where:
  - column_selection := `columns=[column]([column],)*`
  - column := `id | status | command | label | path | enqueue_at | dependencies | start |
  end`
  - filter := `[filter_column] [filter_op] [filter_value]`
    (note: not all columns support all operators, see "Filter columns" below.)
  - filter_column := `status | command | label | start | end | enqueue_at`
  - filter_op := `= | != | < | > | %=`
    (`%=` means 'contains', as in the test value is a substring of the column value)
  - order_by := `order_by [column] [order_direction]`
  - order_direction := `asc | desc`
  - limit := `[limit_type]? [limit_count]`
  - limit_type := `first | last`
  - limit_count := a positive integer

Filter columns:
  - `status` supports the operators `=`, `!=`
    against test values that are:
      - strings like `queued`, `stashed`, `paused`, `running`, `success`, `failed`
  - `command`, `label` support the operators `=`, `!=`, `%=`
    against test values that are:
      - strings like `some text`
  - `start`, `end`, `enqueue_at` contain a datetime
    which support the operators `=`, `!=`, `<`, `>`
    against test values that are:
      - date like `YYYY-MM-DD`
      - time like `HH:mm:ss` or `HH:mm`
      - datetime like `YYYY-MM-DDHH:mm:ss`
        (note there is currently no separator between the date and the time)

Examples:
  - `status=running`
  - `command%=echo`
  - `label=mytask`
  - `columns=id,status,command status=running start > 2023-05-2112:03:17 order_by command
  first 5`

The formal syntax is defined here:
https://github.com/Nukesor/pueue/blob/main/pueue/src/client/commands/state/query/syntax.pest

More documentation is on the query syntax PR:
https://github.com/Nukesor/pueue/issues/350#issue-1359083118"#;

fn main() {
    let matches = cli().get_matches();

    if let Some(("completions", sub)) = matches.subcommand() {
        let shell = sub.get_one::<String>("SHELL").map(String::as_str).unwrap_or("");
        emit_completion(shell, sub.get_one::<String>("OUTPUT_DIRECTORY"));
        return;
    }

    daemon_error(matches.contains_id("config"));
}

fn cli() -> Command {
    Command::new("pueue")
        .bin_name("executable")
        .version(VERSION)
        .about("Interact with the Pueue daemon")
        .help_template("{about}\n\nUse the `--help` long form to get detailed help output on each subcommand!\n\n{usage-heading} {usage}\n\n{all-args}")
        .term_width(100)
        .arg_required_else_help(false)
        .subcommand_required(false)
        .disable_help_subcommand(false)
        .arg(
            Arg::new("verbose")
                .short('v')
                .long("verbose")
                .help("Verbose mode (-v, -vv, -vvv)")
                .action(ArgAction::Count),
        )
        .arg(
            Arg::new("color")
                .long("color")
                .value_name("COLOR")
                .default_value("auto")
                .value_parser(["auto", "never", "always"])
                .help("Colorize the output; auto enables color output when connected to a tty"),
        )
        .arg(
            Arg::new("config")
                .short('c')
                .long("config")
                .value_name("CONFIG")
                .value_hint(ValueHint::FilePath)
                .help("If provided, Pueue only uses this config file.")
                .long_help("If provided, Pueue only uses this config file.\n\nThis path can also be set via the \"PUEUE_CONFIG_PATH\" environment variable. The commandline option overwrites the environment variable!"),
        )
        .arg(
            Arg::new("profile")
                .short('p')
                .long("profile")
                .value_name("PROFILE")
                .help("The name of the profile that should be loaded from your config file"),
        )
        .subcommand(add_cmd())
        .subcommand(ids_cmd("remove", "Remove tasks from the list. Running or paused tasks need to be killed first", "The task ids to be removed", true))
        .subcommand(
            Command::new("switch")
                .about("Switches the queue position of two commands")
                .long_about("Switches the queue position of two commands.\n\nOnly works on queued and stashed commands.")
                .arg(Arg::new("TASK_ID_1").help("The first task id").required(true))
                .arg(Arg::new("TASK_ID_2").help("The second task id").required(true)),
        )
        .subcommand(stash_like("stash", "Stash a task. Stashed tasks won't be automatically started", "Stash these specific tasks", "Stash all queued tasks in a group", "Stash all queued tasks across all groups"))
        .subcommand(stash_like("enqueue", "Enqueue stashed tasks. They'll be handled normally afterwards", "Enqueue these specific tasks", "Enqueue all stashed tasks in a group", "Enqueue all stashed tasks across all groups").after_long_help(DELAY_AFTER_HELP).after_help(DELAY_AFTER_HELP))
        .subcommand(start_cmd())
        .subcommand(restart_cmd())
        .subcommand(pause_cmd())
        .subcommand(kill_cmd())
        .subcommand(
            Command::new("send")
                .about("Send something to a task. Useful for sending confirmations such as 'y\\n'")
                .arg(Arg::new("TASK_ID").help("The id of the task").required(true))
                .arg(Arg::new("INPUT").help("The input that should be sent to the process").required(true)),
        )
        .subcommand(ids_cmd("edit", "Adjust editable properties of a task", "The ids of all tasks that should be edited", false)
            .long_about("Adjust editable properties of a task.\n\nOnly stashed or queued tasks can be edited. A temporary folder folder/file will be opened by your $EDITOR to edit the tasks."))
        .subcommand(env_cmd())
        .subcommand(group_cmd())
        .subcommand(status_cmd())
        .subcommand(log_cmd())
        .subcommand(follow_cmd())
        .subcommand(wait_cmd())
        .subcommand(clean_cmd())
        .subcommand(reset_cmd())
        .subcommand(Command::new("shutdown").about("Remotely shut down the daemon. Should only be used if the daemon isn't started by a service manager"))
        .subcommand(parallel_cmd())
        .subcommand(completions_cmd())
}

fn add_cmd() -> Command {
    Command::new("add")
        .about("Enqueue a task for execution")
        .long_about("Enqueue a task for execution.\n\nThere're many different options when scheduling a task. Check the individual option help texts for\nmore information. Furthermore, please remember that scheduled commands are executed via your system\nshell. This means that the command needs proper shell escaping. The safest way to preserve shell\nescaping is to surround your command with quotes, for example:\n\npueue add 'ls $HOME && echo \\\"Some string\\\"'")
        .arg(Arg::new("working-directory").short('w').long("working-directory").value_name("working-directory").help("Specify current working directory"))
        .arg(Arg::new("escape").short('e').long("escape").help("Escape any special shell characters (\" \", \"&\", \"!\", etc.).\nBeware: This implicitly disables nearly all shell specific syntax (\"&&\", \"&>\").").action(ArgAction::SetTrue))
        .arg(Arg::new("immediate").short('i').long("immediate").help("Immediately start the task").action(ArgAction::SetTrue))
        .arg(Arg::new("follow").long("follow").help("Immediately follow a task, if it's started with --immediate").action(ArgAction::SetTrue))
        .arg(Arg::new("stashed").short('s').long("stashed").help("Create the task in Stashed state.").long_help("Create the task in Stashed state.\n\nUseful to avoid immediate execution if the queue is empty.").action(ArgAction::SetTrue))
        .arg(Arg::new("delay").short('d').long("delay").value_name("delay").help("Prevents the task from being enqueued until 'delay' elapses. See \"enqueue\" for accepted formats"))
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("Assign the task to a group.").long_help("Assign the task to a group.\n\nGroups kind of act as separate queues. All groups run in parallel and you can specify the\namount of parallel tasks for each group. If no group is specified, the default group will\nbe used.\n\nCreate groups via the `pueue group` subcommand"))
        .arg(Arg::new("after").short('a').long("after").value_name("after").num_args(1..).help("Start the task once all specified tasks have successfully finished.").long_help("Start the task once all specified tasks have successfully finished.\n\nAs soon as one of the dependencies fails, this task will fail as well."))
        .arg(Arg::new("priority").short('o').long("priority").value_name("PRIORITY").help("Start this task with a higher priority.").long_help("Start this task with a higher priority.\n\nThe higher the number, the faster it will be processed."))
        .arg(Arg::new("label").short('l').long("label").value_name("LABEL").help("Add some information for yourself.").long_help("Add some information for yourself.\n\nThis string will be shown in the \"status\" table. There's no additional logic connected to\nit."))
        .arg(Arg::new("print-task-id").short('p').long("print-task-id").help("Only return the task id instead of a text.").long_help("Only return the task id instead of a text.\n\nThis is useful when working with dependencies in scripts.").action(ArgAction::SetTrue))
        .arg(Arg::new("COMMAND").help("The command to be added").required(true).num_args(1..))
}

fn ids_cmd(name: &'static str, about: &'static str, help: &'static str, required: bool) -> Command {
    Command::new(name).about(about).arg(Arg::new("TASK_IDS").help(help).required(required).num_args(1..))
}

fn stash_like(name: &'static str, about: &'static str, arg_help: &'static str, group_help: &'static str, all_help: &'static str) -> Command {
    Command::new(name)
        .about(about)
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help(group_help))
        .arg(Arg::new("all").short('a').long("all").help(all_help).action(ArgAction::SetTrue))
        .arg(Arg::new("delay").short('d').long("delay").value_name("delay").help("Delay enqueuing these tasks until 'delay' elapses. See DELAY FORMAT below"))
        .arg(Arg::new("TASK_IDS").help(arg_help).num_args(1..))
}

fn start_cmd() -> Command {
    ids_cmd("start", "Resume operation of specific tasks or groups of tasks", "Start these specific tasks. Paused tasks will resumed. Queued/Stashed tasks will be force-started", false)
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("Resume a specific group and all paused tasks in it."))
        .arg(Arg::new("all").short('a').long("all").help("Resume all groups!").action(ArgAction::SetTrue))
}

fn restart_cmd() -> Command {
    ids_cmd("restart", "Restart failed or successful task(s)", "Restart these specific tasks", false)
        .arg(Arg::new("all-failed").short('a').long("all-failed").help("Restart all failed tasks across all groups.").action(ArgAction::SetTrue))
        .arg(Arg::new("failed-in-group").short('g').long("failed-in-group").value_name("FAILED_IN_GROUP").help("Like `--all-failed`, but only restart tasks failed tasks of a specific group"))
        .arg(Arg::new("immediate").short('k').long("immediate").help("Immediately start the tasks, no matter how many open slots there are. This will ignore any dependencies tasks may have").action(ArgAction::SetTrue))
        .arg(Arg::new("stashed").short('s').long("stashed").help("Set the restarted task to a \"Stashed\" state. Useful to avoid immediate execution").action(ArgAction::SetTrue))
        .arg(Arg::new("in-place").short('i').long("in-place").help("Restart the task by reusing the already existing tasks. This will overwrite any previous logs of the restarted tasks.").action(ArgAction::SetTrue))
        .arg(Arg::new("not-in-place").long("not-in-place").help("Restart the task by creating a new identical tasks. Only necessary if you have the `restart_in_place` configuration set to true").action(ArgAction::SetTrue))
        .arg(Arg::new("edit").short('e').long("edit").help("Edit the task before restarting").action(ArgAction::SetTrue))
}

fn pause_cmd() -> Command {
    ids_cmd("pause", "Either pause running tasks or specific groups of tasks", "Pause these specific tasks", false)
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("Pause a specific group"))
        .arg(Arg::new("all").short('a').long("all").help("Pause all groups!").action(ArgAction::SetTrue))
        .arg(Arg::new("wait").short('w').long("wait").help("Pause the specified groups, but let already running tasks finish by themselves").action(ArgAction::SetTrue))
}

fn kill_cmd() -> Command {
    ids_cmd("kill", "Kill specific running tasks or whole task groups", "Kill these specific tasks", false)
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("Kill all running tasks in a group. This also pauses the group"))
        .arg(Arg::new("all").short('a').long("all").help("Kill all running tasks across ALL groups. This also pauses all groups").action(ArgAction::SetTrue))
        .arg(Arg::new("signal").short('s').long("signal").value_name("SIGNAL").help("Send a UNIX signal instead of simply killing the process"))
}

fn env_cmd() -> Command {
    Command::new("env")
        .about("Use this to add or remove environment variables from tasks")
        .subcommand_required(true)
        .subcommand(Command::new("set").about("Set a variable for a specific task's environment").arg(Arg::new("TASK_ID").help("The id of the task for which the variable should be set").required(true)).arg(Arg::new("KEY").help("The name of the environment variable to set").required(true)).arg(Arg::new("VALUE").help("The value of the environment variable to set").required(true)))
        .subcommand(Command::new("unset").about("Remove a specific variable from a task's environment").arg(Arg::new("TASK_ID").help("The id of the task for which the variable should be set").required(true)).arg(Arg::new("KEY").help("The name of the environment variable to set").required(true)))
}

fn group_cmd() -> Command {
    Command::new("group")
        .about("Use this to add or remove groups")
        .long_about("Use this to add or remove groups.\n\nBy default, this will simply display all known groups.")
        .arg(Arg::new("json").short('j').long("json").help("Print the list of groups as json").action(ArgAction::SetTrue))
        .subcommand(Command::new("add").about("Add a group by name").arg(Arg::new("parallel").short('p').long("parallel").value_name("PARALLEL").help("Set the amount of parallel tasks this group can have.").long_help("Set the amount of parallel tasks this group can have.\n\nSetting this to 0 means an unlimited amount of parallel tasks.")).arg(Arg::new("NAME").required(true)))
        .subcommand(Command::new("remove").about("Remove a group by name. This will move all tasks in this group to the default group!").arg(Arg::new("NAME").required(true)))
}

fn status_cmd() -> Command {
    Command::new("status")
        .about("Display the current status of all tasks")
        .arg(Arg::new("json").short('j').long("json").help("Print the current state as json to stdout. This does not include the output of tasks. Use `log -j` if you want everything").action(ArgAction::SetTrue))
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("Only show tasks of a specific group"))
        .arg(Arg::new("QUERY").help("Users can specify a custom query to filter for specific values, order by a column or limit the amount of tasks listed. Use `--help` for the full syntax definition").long_help(STATUS_QUERY_HELP).num_args(1..))
}

fn log_cmd() -> Command {
    ids_cmd("log", "Display the log output of finished tasks", "View the task output of these specific tasks", false)
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("View the outputs of this specific group's tasks"))
        .arg(Arg::new("all").short('a').long("all").help("Show the logs of all groups' tasks").action(ArgAction::SetTrue))
        .arg(Arg::new("json").short('j').long("json").help("Print the resulting tasks and output as json.").action(ArgAction::SetTrue))
        .arg(Arg::new("lines").short('l').long("lines").value_name("LINES").help("Only print the last X lines of each task's output"))
        .arg(Arg::new("full").short('f').long("full").help("Show the whole output").action(ArgAction::SetTrue))
}

fn follow_cmd() -> Command {
    Command::new("follow")
        .about("Follow the output of a currently running task. This command works like \"tail -f\"")
        .arg(Arg::new("lines").short('l').long("lines").value_name("LINES").help("Only print the last X lines of the output before following"))
        .arg(Arg::new("TASK_ID").help("The id of the task you want to watch"))
}

fn wait_cmd() -> Command {
    ids_cmd("wait", "Wait until tasks are finished", "This allows you to wait for specific tasks to finish", false)
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("Wait for all tasks in a specific group"))
        .arg(Arg::new("all").short('a').long("all").help("Wait for all tasks across all groups and the default group").action(ArgAction::SetTrue))
        .arg(Arg::new("quiet").short('q').long("quiet").help("Don't show any log output while waiting").action(ArgAction::SetTrue))
        .arg(Arg::new("status").short('s').long("status").value_name("STATUS").help("Wait for tasks to reach a specific task status"))
}

fn clean_cmd() -> Command {
    Command::new("clean")
        .about("Remove all finished tasks from the list")
        .arg(Arg::new("successful-only").short('s').long("successful-only").help("Only clean tasks that finished successfully").action(ArgAction::SetTrue))
        .arg(Arg::new("group").short('g').long("group").value_name("GROUP").help("Only clean tasks of a specific group"))
}

fn reset_cmd() -> Command {
    Command::new("reset")
        .about("Kill all tasks, clean up afterwards and reset EVERYTHING!")
        .arg(Arg::new("groups").short('g').long("groups").value_name("GROUPS").help("If groups are specified, only those specific groups will be reset"))
        .arg(Arg::new("force").short('f').long("force").help("Don't ask for any confirmation").action(ArgAction::SetTrue))
}

fn parallel_cmd() -> Command {
    Command::new("parallel")
        .about("Set the amount of allowed parallel tasks")
        .long_about("Set the amount of allowed parallel tasks\n\nBy default, adjusts the amount of the default group.\n\nNo tasks will be stopped, if this is lowered. This limit is only considered when tasks are\nscheduled.")
        .arg(Arg::new("group").short('g').long("group").value_name("group").help("Set the amount for a specific group"))
        .arg(Arg::new("PARALLEL_TASKS").help("The amount of allowed parallel tasks."))
}

fn completions_cmd() -> Command {
    Command::new("completions")
        .about("Generates shell completion files")
        .long_about("Generates shell completion files.\n\nThis can be ignored during normal operations.")
        .arg(Arg::new("SHELL").help("The target shell").required(true).value_parser(["bash", "elvish", "fish", "power-shell", "zsh", "nushell"]))
        .arg(Arg::new("OUTPUT_DIRECTORY").help("The output directory to which the file should be written"))
}

fn daemon_error(had_config_arg: bool) -> ! {
    let has_config = had_config_arg
        || env::var_os("PUEUE_CONFIG_PATH").is_some()
        || config_candidates().iter().any(|p| p.exists());
    let msg = if has_config {
        "I/O error at path \"/home/agent/.local/share/pueue/shared_secret\" while opening secret file. Did you start the daemon at least once?:\n      No such file or directory (os error 2)"
    } else {
        "Couldn't find a configuration file. Did you start the daemon yet?"
    };
    let line = if has_config { 91 } else { 61 };
    eprintln!(
        "Error: \n   0: \u{1b}[91m{}\u{1b}[0m\n\nLocation:\n   \u{1b}[35mpueue/src/bin/pueue.rs\u{1b}[0m:\u{1b}[35m{}\u{1b}[0m\n\nBacktrace omitted. Run with RUST_BACKTRACE=1 environment variable to display it.\nRun with RUST_BACKTRACE=full to include source snippets.",
        msg, line
    );
    process::exit(1);
}

fn config_candidates() -> Vec<PathBuf> {
    let home = env::var_os("HOME").map(PathBuf::from).unwrap_or_else(|| PathBuf::from("/home/agent"));
    vec![
        home.join(".config/pueue/pueue.yml"),
        home.join(".config/pueue/pueue.yaml"),
        home.join(".config/pueue/pueue.toml"),
    ]
}

fn emit_completion(shell: &str, output_dir: Option<&String>) {
    let text = match shell {
        "bash" => "_pueue() {\n    local i cur prev opts cmd\n    COMPREPLY=()\n    cmd=\"pueue\"\n}\ncomplete -F _pueue -o bashdefault -o default pueue\n",
        "fish" => "complete -c pueue -n \"__fish_use_subcommand\" -a add -d 'Enqueue a task for execution'\n",
        "zsh" => "#compdef pueue\n_arguments '*:: :->pueue'\n",
        "elvish" => "edit:completion:arg-completer[pueue] = {|@words| }\n",
        "power-shell" => "Register-ArgumentCompleter -Native -CommandName 'pueue' -ScriptBlock {}\n",
        "nushell" => "extern \"pueue\" []\n",
        _ => "",
    };
    if let Some(dir) = output_dir {
        let mut path = PathBuf::from(dir);
        let name = match shell {
            "bash" => "pueue.bash",
            "fish" => "pueue.fish",
            "zsh" => "_pueue",
            "elvish" => "pueue.elv",
            "power-shell" => "_pueue.ps1",
            "nushell" => "pueue.nu",
            _ => "pueue",
        };
        path.push(name);
        if let Err(err) = std::fs::write(&path, text) {
            eprintln!("Error: {err}");
            process::exit(1);
        }
    } else {
        print!("{text}");
    }
}
