use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode};
use std::time::{SystemTime, UNIX_EPOCH};

const HELP_LONG: &str = r##"CLI tools for generating beautiful code snapshots

Usage: codesnap [OPTIONS] --output <OUTPUT>

Options:
  -f, --from-file <FROM_FILE>
          Path to the file to snapshot

  -c, --from-code [<Code>]
          Code snippet for snapshot

  -i, --from-image [<Image>]
          

      --from-clipboard
          

  -o, --output <OUTPUT>
          Output path for the snapshot. Available value:
          
          - clipboard: Copy the snapshot to clipboard - file path: Save the snapshot to the file path
          
          Currently CodeSnap supports SVG format and PNG format If output is directory, CodeSnap will generate a temporary file name to save the snapshot to the directory.

      --silent
          

  -e, --execute <EXECUTE>...
          Executing a command and taking the output as the code snippet

      --skip
          Skip run the command to get output, just take the command as the input

      --range <RANGE>
          You can set the range of the code snippet to display for example, display the 3rd to 5th: 3:5 The syntax is similar to the range in Python or Golang, so basically you can use 3: to represent the 3rd to the end, or use :5 to represent the start to the 5th. This option is useful when you use the `from_file` option as the input, and you just want to display part of the code snippet

      --code-font-family <CODE_FONT_FAMILY>
          Font family for the code snippet

      --code-theme <CODE_THEME>
          Code theme for the code snippet

      --has-breadcrumbs <HAS_BREADCRUMBS>
          Breadcrumbs is a useful and unique feature in CodeSnap, it shows the path of the file so that users can know where the code snippet comes from
          
          [default: false]
          [possible values: true, false]

      --has-line-number
          

      --breadcrumbs-separator <BREADCRUMBS_SEPARATOR>
          Breadcrumbs separator is the character to separate the path in breadcrumbs Default is `/`

      --breadcrumbs-font-family <BREADCRUMBS_FONT_FAMILY>
          Breadcrumbs font family

      --breadcrumbs-color <BREADCRUMBS_COLOR>
          Breadcrumbs font color

      --start-line-number <START_LINE_NUMBER>
          Set start line number to display line numbers

      --line-number-color <LINE_NUMBER_COLOR>
          Line number font color
          
          [default: #495162]

  -d, --delete-line <DELETE_LINE>...
          Delete lines will be marked with a red line

      --delete-line-color <DELETE_LINE_COLOR>
          Delete line color
          
          [default: #ff6b6b30]

  -a, --add-line <ADD_LINE>...
          New lines will be marked with a green line

      --add-line-color <ADD_LINE_COLOR>
          New line color
          
          [default: #2ecc7130]

      --highlight-range <HIGHLIGHT_RANGE>
          Convenient version of `--raw-highlight-lines` option, you can set the highlight range with a simple syntax, for example, highlight the 3rd to 5th lines: 3:5

      --relative-highlight-range
          

      --highlight-range-color <HIGHLIGHT_RANGE_COLOR>
          Highlight color for the highlighted code lines
          
          [default: #ffffff10]

      --raw-highlight-lines <RAW_HIGHLIGHT_LINES>
          CodeSnap allows users to highlight multiple lines with custom highlight color in the code snippet The content of highlight_lines is JSON string, for example highlight the first line and the 3rd to 5th lines: "[ [1, "#ff0000"], [3, 5, "#00ff00"] ]"

  -l, --language <LANGUAGE>
          Set the language of the code snippet, If you using the `file` option, CodeSnap will automatically detect the language from the file extension

      --file-path <FILE_PATH>
          Used to detect the language of the code snippet, if you want to set language manually, use `--language` or `-l` option

  -w, --watermark <WATERMARK>
          Set watermark for the code snippet

      --watermark-font-family <WATERMARK_FONT_FAMILY>
          Watermark font family

      --watermark-color <WATERMARK_COLOR>
          Watermark font color

      --shadow-radius <SHADOW_RADIUS>
          Set window shadow radius

      --shadow-color <SHADOW_COLOR>
          

      --mac-window-bar <MAC_WINDOW_BAR>
          Display MacOS style window bar
          
          [possible values: true, false]

      --has-border
          Display window border

      --border-color <BORDER_COLOR>
          Window border color
          
          [default: #ffffff30]

      --margin-x <MARGIN_X>
          Set horizontal margin of window

      --margin-y <MARGIN_Y>
          Set vertical margin of window

      --title <TITLE>
          Set title of the window

      --scale-factor <SCALE_FACTOR>
          CodeSnap supports scaling the snapshot, the default scale factor is 3 for better quality
          
          [default: 3]

      --title-font-family <TITLE_FONT_FAMILY>
          Title font family

      --title-color <TITLE_COLOR>
          Title font color

      --background <BACKGROUND>
          Set background color of the snapshot

      --type <TYPE>
          [default: image]
          [possible values: ascii, image]

      --config <CONFIG>
          

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"##;

#[derive(Default)]
struct Opts {
    from_file: Option<String>,
    from_code: Option<String>,
    from_image: Option<String>,
    from_clipboard: bool,
    output: Option<String>,
    silent: bool,
    execute: Vec<String>,
    skip: bool,
    range: Option<String>,
    has_line_number: bool,
    has_breadcrumbs: bool,
    breadcrumbs_separator: String,
    start_line_number: usize,
    title: Option<String>,
    watermark: Option<String>,
    background: Option<String>,
    output_type: String,
    add_lines: Vec<usize>,
    delete_lines: Vec<usize>,
    highlight_range: Option<String>,
}

fn main() -> ExitCode {
    ensure_config();
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(msg) => {
            eprintln!("\x1b[31m[ERROR]\x1b[0m {msg}");
            ExitCode::from(1)
        }
    }
}

fn run() -> Result<(), String> {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "--help") {
        println!("{HELP_LONG}");
        return Ok(());
    }
    if args.iter().any(|a| a == "-h") {
        print_short_help();
        return Ok(());
    }
    if args.iter().any(|a| a == "--version" || a == "-V") {
        println!("codesnap-cli 0.13.1");
        return Ok(());
    }
    let opts = parse_args(&args)?;
    let out = opts.output.clone().ok_or_else(|| {
        "the following required arguments were not provided:\n  --output <OUTPUT>".to_string()
    })?;
    let mut code = collect_code(&opts)?;
    if let Some(r) = &opts.range {
        code = apply_range(&code, r);
    }
    if code.is_empty() {
        return Err("No code snippet provided".into());
    }
    if opts.output_type == "ascii" {
        if out == "clipboard" {
            println!("{}", ascii_snapshot(&code, &opts));
        } else {
            eprintln!("\x1b[33m[WARN]\x1b[0m ASCII snapshot only supports copying to clipboard");
        }
        return Ok(());
    }
    if out == "clipboard" {
        println!("{}", ascii_snapshot(&code, &opts));
        return Ok(());
    }
    let out_path = resolve_output_path(&out);
    if let Some(parent) = out_path.parent() {
        if !parent.as_os_str().is_empty() {
            fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
    }
    let ext = out_path.extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase();
    match ext.as_str() {
        "png" => fs::write(&out_path, make_png(&code, &opts)).map_err(|e| e.to_string())?,
        "html" | "htm" => fs::write(&out_path, make_html(&code, &opts)).map_err(|e| e.to_string())?,
        _ => fs::write(&out_path, make_svg(&code, &opts)).map_err(|e| e.to_string())?,
    }
    if !opts.silent {
        println!("\x1b[32m[SUCCESS]\x1b[0m Snapshot saved to {} successful!", out_path.display());
    }
    Ok(())
}

fn parse_args(args: &[String]) -> Result<Opts, String> {
    let mut opts = Opts {
        breadcrumbs_separator: "/".to_string(),
        start_line_number: 1,
        output_type: "image".to_string(),
        ..Default::default()
    };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-f" | "--from-file" => { i += 1; opts.from_file = Some(value(args, i, a)?); }
            "-c" | "--from-code" => {
                if i + 1 < args.len() && !looks_like_option(&args[i + 1]) {
                    i += 1; opts.from_code = Some(args[i].clone());
                } else {
                    let mut s = String::new();
                    io::stdin().read_to_string(&mut s).ok();
                    opts.from_code = Some(s);
                }
            }
            "-i" | "--from-image" => {
                if i + 1 < args.len() && !looks_like_option(&args[i + 1]) {
                    i += 1; opts.from_image = Some(args[i].clone());
                } else {
                    opts.from_image = Some(String::new());
                }
            }
            "--from-clipboard" => opts.from_clipboard = true,
            "-o" | "--output" => { i += 1; opts.output = Some(value(args, i, a)?); }
            "--silent" => opts.silent = true,
            "-e" | "--execute" => {
                i += 1;
                while i < args.len() && !is_known_option(&args[i]) {
                    opts.execute.push(args[i].clone());
                    i += 1;
                }
                i = i.saturating_sub(1);
            }
            "--skip" => opts.skip = true,
            "--range" => { i += 1; opts.range = Some(value(args, i, a)?); }
            "--has-line-number" => opts.has_line_number = true,
            "--has-breadcrumbs" => {
                if i + 1 < args.len() && !looks_like_option(&args[i + 1]) {
                    i += 1;
                    opts.has_breadcrumbs = args[i] == "true";
                } else {
                    opts.has_breadcrumbs = true;
                }
            }
            "--breadcrumbs-separator" => { i += 1; opts.breadcrumbs_separator = value(args, i, a)?; }
            "--start-line-number" => { i += 1; opts.start_line_number = value(args, i, a)?.parse().unwrap_or(1); }
            "--title" => { i += 1; opts.title = Some(value(args, i, a)?); }
            "-w" | "--watermark" => { i += 1; opts.watermark = Some(value(args, i, a)?); }
            "--background" => { i += 1; opts.background = Some(value(args, i, a)?); }
            "--type" => { i += 1; opts.output_type = value(args, i, a)?; }
            "-a" | "--add-line" => {
                i += 1;
                while i < args.len() && !is_known_option(&args[i]) {
                    if let Ok(n) = args[i].parse() { opts.add_lines.push(n); }
                    i += 1;
                }
                i = i.saturating_sub(1);
            }
            "-d" | "--delete-line" => {
                i += 1;
                while i < args.len() && !is_known_option(&args[i]) {
                    if let Ok(n) = args[i].parse() { opts.delete_lines.push(n); }
                    i += 1;
                }
                i = i.saturating_sub(1);
            }
            "--highlight-range" => { i += 1; opts.highlight_range = Some(value(args, i, a)?); }
            "--code-font-family" | "--code-theme" | "--breadcrumbs-font-family" | "--breadcrumbs-color"
            | "--line-number-color" | "--delete-line-color" | "--add-line-color"
            | "--highlight-range-color" | "--raw-highlight-lines" | "-l" | "--language"
            | "--file-path" | "--watermark-font-family" | "--watermark-color" | "--shadow-radius"
            | "--shadow-color" | "--mac-window-bar" | "--border-color" | "--margin-x" | "--margin-y"
            | "--scale-factor" | "--title-font-family" | "--title-color" | "--config" => {
                if i + 1 < args.len() && !is_known_option(&args[i + 1]) { i += 1; }
            }
            "--has-border" | "--relative-highlight-range" => {}
            s if s.starts_with('-') => return Err(format!("unexpected argument '{s}' found")),
            _ => {}
        }
        i += 1;
    }
    Ok(opts)
}

fn collect_code(opts: &Opts) -> Result<String, String> {
    if let Some(path) = &opts.from_file {
        return fs::read_to_string(path).map_err(|e| e.to_string());
    }
    if let Some(code) = &opts.from_code {
        return Ok(code.clone());
    }
    if !opts.execute.is_empty() {
        if opts.skip {
            return Ok(opts.execute.join(" "));
        }
        let cmd = &opts.execute[0];
        let output = Command::new(cmd)
            .args(&opts.execute[1..])
            .output()
            .map_err(|e| e.to_string())?;
        let mut text = String::from_utf8_lossy(&output.stdout).to_string();
        if text.is_empty() {
            text = String::from_utf8_lossy(&output.stderr).to_string();
        }
        return Ok(text);
    }
    if let Some(path) = &opts.from_image {
        if path.is_empty() {
            return Ok("[image]".to_string());
        }
        let bytes = fs::read(path).map_err(|e| e.to_string())?;
        return Ok(format!("[image: {} bytes]", bytes.len()));
    }
    if opts.from_clipboard {
        return Err("Clipboard is not available in this environment".into());
    }
    Err("No code snippet provided".into())
}

fn apply_range(code: &str, range: &str) -> String {
    let lines: Vec<&str> = code.lines().collect();
    let parts: Vec<&str> = range.split(':').collect();
    if parts.len() != 2 {
        return code.to_string();
    }
    let start = if parts[0].is_empty() { 1 } else { parts[0].parse::<usize>().unwrap_or(1) };
    let end = if parts[1].is_empty() { lines.len() } else { parts[1].parse::<usize>().unwrap_or(lines.len()) };
    if start == 0 || end < start {
        return String::new();
    }
    lines.iter().skip(start - 1).take(end - start + 1).copied().collect::<Vec<_>>().join("\n")
}

fn resolve_output_path(out: &str) -> PathBuf {
    let p = Path::new(out);
    if p.is_dir() {
        let ts = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_millis();
        p.join(format!("codesnap-{ts}.svg"))
    } else {
        p.to_path_buf()
    }
}

fn make_svg(code: &str, opts: &Opts) -> String {
    let lines: Vec<&str> = if code.is_empty() { vec![""] } else { code.lines().collect() };
    let max_chars = lines.iter().map(|l| l.chars().count()).max().unwrap_or(1);
    let number_width = if opts.has_line_number { 52 } else { 0 };
    let width = (max_chars as i32 * 9 + 92 + number_width).max(360);
    let height = (lines.len() as i32 * 22 + 116 + if opts.title.is_some() { 26 } else { 0 }).max(160);
    let bg = opts.background.as_deref().unwrap_or("#161b22");
    let title = opts.title.as_deref().unwrap_or("CodeSnap");
    let mut s = String::new();
    s.push_str(&format!(r#"<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">"#));
    s.push_str("<defs><filter id=\"shadow\"><feDropShadow dx=\"0\" dy=\"12\" stdDeviation=\"12\" flood-opacity=\"0.25\"/></filter></defs>");
    s.push_str(&format!(r#"<rect width="100%" height="100%" fill="{}"/>"#, esc(bg)));
    s.push_str(&format!(r##"<rect x="36" y="36" width="{}" height="{}" rx="12" fill="#0d1117" stroke="#ffffff30" filter="url(#shadow)"/>"##, width - 72, height - 72));
    s.push_str(r##"<circle cx="60" cy="58" r="6" fill="#ff5f56"/><circle cx="80" cy="58" r="6" fill="#ffbd2e"/><circle cx="100" cy="58" r="6" fill="#27c93f"/>"##);
    s.push_str(&format!(r##"<text x="{}" y="64" fill="#ffffff" font-size="14" font-family="monospace" text-anchor="middle">{}</text>"##, width / 2, esc(title)));
    if opts.has_breadcrumbs {
        if let Some(path) = &opts.from_file {
            let crumb = path.replace('/', &opts.breadcrumbs_separator);
            s.push_str(&format!(r##"<text x="54" y="88" fill="#80848b" font-size="12" font-family="monospace">{}</text>"##, esc(&crumb)));
        }
    }
    let y0 = if opts.has_breadcrumbs { 112 } else { 94 };
    for (idx, line) in lines.iter().enumerate() {
        let line_no = opts.start_line_number + idx;
        let y = y0 + idx as i32 * 22;
        if opts.add_lines.contains(&(idx + 1)) {
            s.push_str(&format!(r##"<rect x="45" y="{}" width="{}" height="22" fill="#2ecc7130"/>"##, y - 16, width - 90));
        }
        if opts.delete_lines.contains(&(idx + 1)) {
            s.push_str(&format!(r##"<rect x="45" y="{}" width="{}" height="22" fill="#ff6b6b30"/>"##, y - 16, width - 90));
        }
        if range_contains(opts.highlight_range.as_deref(), idx + 1) {
            s.push_str(&format!(r##"<rect x="45" y="{}" width="{}" height="22" fill="#ffffff10"/>"##, y - 16, width - 90));
        }
        if opts.has_line_number {
            s.push_str(&format!(r##"<text x="58" y="{y}" fill="#495162" font-size="14" font-family="monospace">{line_no}</text>"##));
        }
        s.push_str(&format!(r##"<text x="{}" y="{y}" fill="#e6edf3" font-size="14" font-family="monospace" xml:space="preserve">{}</text>"##, 58 + number_width, esc(line)));
    }
    if let Some(w) = &opts.watermark {
        s.push_str(&format!(r##"<text x="{}" y="{}" fill="#ffffff80" font-size="13" font-family="sans-serif" text-anchor="end">{}</text>"##, width - 48, height - 48, esc(w)));
    }
    s.push_str("</svg>");
    s
}

fn make_html(code: &str, opts: &Opts) -> String {
    format!(
        "<!doctype html><meta charset=\"utf-8\"><title>{}</title><body style=\"margin:0;background:#161b22\">{}</body>",
        esc(opts.title.as_deref().unwrap_or("CodeSnap")),
        make_svg(code, opts)
    )
}

fn make_png(code: &str, _opts: &Opts) -> Vec<u8> {
    let lines = code.lines().count().max(1);
    let width = 640u32;
    let height = (120 + lines as u32 * 24).max(180);
    let mut raw = Vec::with_capacity((width * height * 4 + height) as usize);
    for y in 0..height {
        raw.push(0);
        for x in 0..width {
            let inside = x > 40 && x < width - 40 && y > 40 && y < height - 40;
            let (r, g, b, a) = if inside { (13, 17, 23, 255) } else { (32, 39, 51, 255) };
            raw.extend([r, g, b, a]);
        }
    }
    let compressed = zlib_store(&raw);
    let mut png = Vec::new();
    png.extend(b"\x89PNG\r\n\x1a\n");
    let mut ihdr = Vec::new();
    ihdr.extend(width.to_be_bytes());
    ihdr.extend(height.to_be_bytes());
    ihdr.extend([8, 6, 0, 0, 0]);
    chunk(&mut png, b"IHDR", &ihdr);
    chunk(&mut png, b"IDAT", &compressed);
    chunk(&mut png, b"IEND", &[]);
    png
}

fn zlib_store(data: &[u8]) -> Vec<u8> {
    let mut out = vec![0x78, 0x01];
    let mut pos = 0;
    while pos < data.len() {
        let len = (data.len() - pos).min(65535);
        let final_block = if pos + len >= data.len() { 1u8 } else { 0u8 };
        out.push(final_block);
        out.extend((len as u16).to_le_bytes());
        out.extend((!(len as u16)).to_le_bytes());
        out.extend(&data[pos..pos + len]);
        pos += len;
    }
    out.extend(adler32(data).to_be_bytes());
    out
}

fn chunk(png: &mut Vec<u8>, name: &[u8; 4], data: &[u8]) {
    png.extend((data.len() as u32).to_be_bytes());
    png.extend(name);
    png.extend(data);
    let mut crc_data = Vec::with_capacity(4 + data.len());
    crc_data.extend(name);
    crc_data.extend(data);
    png.extend(crc32(&crc_data).to_be_bytes());
}

fn crc32(data: &[u8]) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for &b in data {
        crc ^= b as u32;
        for _ in 0..8 {
            crc = if crc & 1 != 0 { (crc >> 1) ^ 0xedb8_8320 } else { crc >> 1 };
        }
    }
    !crc
}

fn adler32(data: &[u8]) -> u32 {
    let mut a = 1u32;
    let mut b = 0u32;
    for &x in data {
        a = (a + x as u32) % 65521;
        b = (b + a) % 65521;
    }
    (b << 16) | a
}

fn ascii_snapshot(code: &str, opts: &Opts) -> String {
    let lines: Vec<&str> = code.lines().collect();
    let width = lines.iter().map(|l| l.chars().count()).max().unwrap_or(0) + if opts.has_line_number { 6 } else { 0 };
    let mut out = String::new();
    out.push_str(&format!("+{}+\n", "-".repeat(width + 2)));
    for (i, line) in lines.iter().enumerate() {
        let content = if opts.has_line_number {
            format!("{:>4}  {}", opts.start_line_number + i, line)
        } else {
            (*line).to_string()
        };
        out.push_str(&format!("| {:width$} |\n", content, width = width));
    }
    out.push_str(&format!("+{}+", "-".repeat(width + 2)));
    out
}

fn range_contains(range: Option<&str>, line: usize) -> bool {
    range.map(|r| {
        let parts: Vec<&str> = r.split(':').collect();
        if parts.len() == 2 {
            let start = if parts[0].is_empty() { 1 } else { parts[0].parse().unwrap_or(1) };
            let end = if parts[1].is_empty() { usize::MAX } else { parts[1].parse().unwrap_or(start) };
            line >= start && line <= end
        } else {
            r.parse::<usize>().map(|n| n == line).unwrap_or(false)
        }
    }).unwrap_or(false)
}

fn value(args: &[String], i: usize, flag: &str) -> Result<String, String> {
    args.get(i).cloned().ok_or_else(|| format!("a value is required for '{flag}' but none was supplied"))
}

fn looks_like_option(s: &str) -> bool {
    s.starts_with('-') && s != "-"
}

fn is_known_option(s: &str) -> bool {
    matches!(s,
        "-f" | "--from-file" | "-c" | "--from-code" | "-i" | "--from-image" | "--from-clipboard"
        | "-o" | "--output" | "--silent" | "-e" | "--execute" | "--skip" | "--range"
        | "--code-font-family" | "--code-theme" | "--has-breadcrumbs" | "--has-line-number"
        | "--breadcrumbs-separator" | "--breadcrumbs-font-family" | "--breadcrumbs-color"
        | "--start-line-number" | "--line-number-color" | "-d" | "--delete-line"
        | "--delete-line-color" | "-a" | "--add-line" | "--add-line-color" | "--highlight-range"
        | "--relative-highlight-range" | "--highlight-range-color" | "--raw-highlight-lines"
        | "-l" | "--language" | "--file-path" | "-w" | "--watermark" | "--watermark-font-family"
        | "--watermark-color" | "--shadow-radius" | "--shadow-color" | "--mac-window-bar"
        | "--has-border" | "--border-color" | "--margin-x" | "--margin-y" | "--title"
        | "--scale-factor" | "--title-font-family" | "--title-color" | "--background"
        | "--type" | "--config" | "-h" | "--help" | "-V" | "--version")
}

fn esc(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn ensure_config() {
    let home = env::var("HOME").unwrap_or_else(|_| ".".into());
    let path = Path::new(&home).join(".config/codesnap/config.json");
    if path.exists() {
        return;
    }
    if let Some(parent) = path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let default = r##"{
  "print_eggs": false,
  "snapshot_config": {
    "theme": "candy",
    "window": { "mac_window_bar": true, "shadow": { "radius": 20, "color": "#00000040" }, "margin": { "x": 82, "y": 82 } },
    "code_config": { "font_family": "CaskaydiaCove Nerd Font", "breadcrumbs": { "enable": false, "separator": "/", "color": "#80848b" } },
    "watermark": { "content": "CodeSnap", "color": "#ffffff" }
  }
}
"##;
    if fs::write(&path, default).is_ok() {
        eprintln!("\x1b[34m[INFO]\x1b[0m Automated created config file at \"{}\"", path.display());
    }
}

fn print_short_help() {
    let mut short = String::new();
    for line in HELP_LONG.lines() {
        if line.trim().is_empty() || line.starts_with("          ") && !line.contains("[") {
            continue;
        }
        short.push_str(line);
        short.push('\n');
    }
    print!("{short}");
}
