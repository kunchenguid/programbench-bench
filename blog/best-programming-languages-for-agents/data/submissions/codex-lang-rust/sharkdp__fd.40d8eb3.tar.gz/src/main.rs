use chrono::{Local, NaiveDate, NaiveDateTime, TimeZone};
use regex::{Regex, RegexBuilder};
use std::collections::HashSet;
use std::env;
use std::ffi::OsStr;
use std::fs::{self, DirEntry, Metadata};
use std::io::{self, Write};
use std::os::unix::fs::{FileTypeExt, MetadataExt, PermissionsExt};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

#[derive(Default, Clone)]
struct Config {
    hidden: bool,
    no_ignore: bool,
    case_sensitive: Option<bool>,
    glob: bool,
    fixed: bool,
    absolute: bool,
    list_details: bool,
    follow: bool,
    full_path: bool,
    print0: bool,
    max_depth: Option<usize>,
    min_depth: usize,
    exact_depth: Option<usize>,
    excludes: Vec<String>,
    types: Vec<FileKind>,
    extensions: Vec<String>,
    size: Option<SizeFilter>,
    changed_within: Option<SystemTime>,
    changed_before: Option<SystemTime>,
    owner: Option<OwnerFilter>,
    format: Option<String>,
    exec: Option<Vec<String>>,
    exec_batch: Option<Vec<String>>,
    batch_size: usize,
    max_results: Option<usize>,
    quiet: bool,
    show_errors: bool,
    base_directory: Option<PathBuf>,
    path_separator: Option<String>,
    search_paths: Vec<PathBuf>,
    strip_cwd_prefix: StripMode,
    prune: bool,
    and_patterns: Vec<String>,
    ignore_contain: Vec<String>,
    color_always: bool,
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum StripMode {
    Auto,
    Always,
    Never,
}

impl Default for StripMode {
    fn default() -> Self {
        StripMode::Auto
    }
}

#[derive(Clone, Copy, PartialEq, Eq)]
enum FileKind {
    File,
    Dir,
    Symlink,
    Socket,
    Pipe,
    Block,
    Char,
    Executable,
    Empty,
}

#[derive(Clone)]
enum SizeFilter {
    Eq(u64),
    Ge(u64),
    Le(u64),
}

#[derive(Clone)]
struct OwnerFilter {
    user: Option<(u32, bool)>,
    group: Option<(u32, bool)>,
}

struct Matcher {
    pattern: Option<Pattern>,
    ands: Vec<Pattern>,
}

enum Pattern {
    Regex(Regex),
    Glob { pat: String, ci: bool },
    Fixed { needle: String, ci: bool },
}

#[derive(Clone)]
struct ResultEntry {
    path: PathBuf,
    rel: PathBuf,
    depth: usize,
    meta: Metadata,
    is_dir: bool,
    is_symlink: bool,
}

fn main() {
    let code = match real_main() {
        Ok(code) => code,
        Err(msg) => {
            if msg.starts_with("regex parse error:") {
                eprintln!("[fd error]: {msg}\n\nNote: You can use the '--fixed-strings' option to search for a literal string instead of a regular expression. Alternatively, you can also use the '--glob' option to match on a glob pattern.");
                1
            } else {
                eprintln!("error: {msg}");
                2
            }
        }
    };
    std::process::exit(code);
}

fn real_main() -> Result<i32, String> {
    let raw: Vec<String> = env::args().skip(1).collect();
    if raw.iter().any(|a| a == "--help") {
        print_long_help();
        return Ok(0);
    }
    if raw.iter().any(|a| a == "-h") {
        print_short_help();
        return Ok(0);
    }
    if raw.iter().any(|a| a == "--version" || a == "-V") {
        println!("fd 10.3.0");
        return Ok(0);
    }

    let (mut cfg, positionals) = parse_args(raw)?;
    if let Some(d) = cfg.exact_depth {
        cfg.min_depth = d;
        cfg.max_depth = Some(d);
    }
    if let Some(base) = &cfg.base_directory {
        env::set_current_dir(base).map_err(|e| format!("{}: {}", base.display(), e))?;
    }

    let (pattern, paths) = split_pattern_paths(positionals, &cfg);
    let paths: Vec<PathBuf> = if !cfg.search_paths.is_empty() {
        cfg.search_paths.clone()
    } else if paths.is_empty() {
        vec![PathBuf::from(".")]
    } else {
        paths
    };
    let matcher = build_matcher(pattern.as_deref(), &cfg)?;
    let mut results = Vec::new();
    for root in paths {
        let root = if root.as_os_str().is_empty() { PathBuf::from(".") } else { root };
        walk_root(&root, &cfg, &matcher, &mut results)?;
        if let Some(max) = cfg.max_results {
            if results.len() >= max {
                results.truncate(max);
                break;
            }
        }
    }
    results.sort_by(|a, b| display_path(a, &cfg, false).cmp(&display_path(b, &cfg, false)));
    if let Some(max) = cfg.max_results {
        results.truncate(max);
    }

    if cfg.quiet {
        return Ok(if results.is_empty() { 1 } else { 0 });
    }
    if cfg.list_details {
        return run_list_details(&results, &cfg);
    }
    if let Some(cmd) = &cfg.exec {
        return run_exec_each(cmd, &results, &cfg);
    }
    if let Some(cmd) = &cfg.exec_batch {
        return run_exec_batch(cmd, &results, &cfg);
    }
    print_results(&results, &cfg)?;
    Ok(0)
}

fn parse_args(args: Vec<String>) -> Result<(Config, Vec<String>), String> {
    let mut cfg = Config { batch_size: 0, ..Default::default() };
    let mut pos = Vec::new();
    let mut i = 0;
    let mut stop_opts = false;
    while i < args.len() {
        let a = &args[i];
        if stop_opts {
            pos.push(a.clone());
            i += 1;
            continue;
        }
        if a == "--" {
            stop_opts = true;
            i += 1;
            continue;
        }
        if a == "-x" || a == "--exec" || a == "-X" || a == "--exec-batch" {
            let batch = a == "-X" || a == "--exec-batch";
            let cmd = args[i + 1..].to_vec();
            if cmd.is_empty() {
                return Err(format!("a value is required for '{} <cmd>...'", a));
            }
            if batch { cfg.exec_batch = Some(cmd); } else { cfg.exec = Some(cmd); }
            break;
        }
        if !a.starts_with('-') || a == "-" {
            pos.push(a.clone());
            i += 1;
            continue;
        }
        if let Some((name, val)) = a.split_once('=') {
            handle_long(name, Some(val.to_string()), &mut cfg, &mut pos)?;
            i += 1;
            continue;
        }
        if a.starts_with("--") {
            let name = a.as_str();
            let needs = option_needs_value(name);
            let val = if needs {
                i += 1;
                args.get(i).cloned().ok_or_else(|| format!("a value is required for '{} <value>'", name))?
            } else {
                String::new()
            };
            handle_long(name, if needs { Some(val) } else { None }, &mut cfg, &mut pos)?;
            i += 1;
            continue;
        }
        let chars: Vec<char> = a[1..].chars().collect();
        let mut j = 0;
        while j < chars.len() {
            let c = chars[j];
            match c {
                'H' => cfg.hidden = true,
                'I' => cfg.no_ignore = true,
                'u' => { cfg.hidden = true; cfg.no_ignore = true; },
                's' => cfg.case_sensitive = Some(true),
                'i' => cfg.case_sensitive = Some(false),
                'g' => cfg.glob = true,
                'F' => cfg.fixed = true,
                'a' => cfg.absolute = true,
                'l' => cfg.list_details = true,
                'L' => cfg.follow = true,
                'p' => cfg.full_path = true,
                '0' => cfg.print0 = true,
                '1' => cfg.max_results = Some(1),
                'q' => { cfg.quiet = true; cfg.max_results = Some(1); },
                'd' | 'E' | 't' | 'e' | 'S' | 'o' | 'c' | 'j' | 'C' => {
                    let rest: String = chars[j + 1..].iter().collect();
                    let val = if !rest.is_empty() {
                        j = chars.len();
                        rest
                    } else {
                        i += 1;
                        args.get(i).cloned().ok_or_else(|| format!("a value is required for '-{} <value>'", c))?
                    };
                    handle_short_value(c, val, &mut cfg)?;
                    break;
                }
                _ => return Err(format!("unexpected argument '-{}' found", c)),
            }
            j += 1;
        }
        i += 1;
    }
    Ok((cfg, pos))
}

fn option_needs_value(name: &str) -> bool {
    matches!(name,
        "--max-depth" | "--min-depth" | "--exact-depth" | "--max-results" | "--exclude" | "--type" |
        "--extension" | "--size" | "--changed-within" | "--change-newer-than" |
        "--newer" | "--changed-after" | "--changed-before" | "--change-older-than" |
        "--older" | "--owner" | "--format" | "--batch-size" | "--ignore-file" |
        "--color" | "--threads" | "--base-directory" | "--path-separator" |
        "--search-path" | "--and" | "--ignore-contain")
}

fn handle_long(name: &str, val: Option<String>, cfg: &mut Config, _pos: &mut Vec<String>) -> Result<(), String> {
    match name {
        "--hidden" => cfg.hidden = true,
        "--no-hidden" => cfg.hidden = false,
        "--no-ignore" | "--no-ignore-vcs" | "--no-ignore-parent" => cfg.no_ignore = true,
        "--ignore" | "--ignore-vcs" => cfg.no_ignore = false,
        "--unrestricted" => { cfg.hidden = true; cfg.no_ignore = true; },
        "--case-sensitive" => cfg.case_sensitive = Some(true),
        "--ignore-case" => cfg.case_sensitive = Some(false),
        "--glob" => cfg.glob = true,
        "--regex" => cfg.glob = false,
        "--fixed-strings" => cfg.fixed = true,
        "--absolute-path" => cfg.absolute = true,
        "--relative-path" => cfg.absolute = false,
        "--list-details" => cfg.list_details = true,
        "--follow" => cfg.follow = true,
        "--no-follow" => cfg.follow = false,
        "--full-path" => cfg.full_path = true,
        "--print0" => cfg.print0 = true,
        "--max-depth" => cfg.max_depth = Some(parse_usize(val, name)?),
        "--min-depth" => cfg.min_depth = parse_usize(val, name)?,
        "--exact-depth" => cfg.exact_depth = Some(parse_usize(val, name)?),
        "--exclude" => cfg.excludes.push(required(val, name)?),
        "--prune" => cfg.prune = true,
        "--type" => cfg.types.push(parse_type(&required(val, name)?)?),
        "--extension" => cfg.extensions.push(required(val, name)?.trim_start_matches('.').to_string()),
        "--size" => cfg.size = Some(parse_size(&required(val, name)?)?),
        "--changed-within" | "--change-newer-than" | "--newer" | "--changed-after" => cfg.changed_within = Some(parse_time_filter(&required(val, name)?)?),
        "--changed-before" | "--change-older-than" | "--older" => cfg.changed_before = Some(parse_time_filter(&required(val, name)?)?),
        "--owner" => cfg.owner = Some(parse_owner(&required(val, name)?)?),
        "--format" => cfg.format = Some(required(val, name)?),
        "--batch-size" => cfg.batch_size = parse_usize(val, name)?,
        "--ignore-file" => { let _ = val; },
        "--color" => cfg.color_always = required(val, name)? == "always",
        "--hyperlink" => {},
        "--threads" => { let _ = val; },
        "--max-results" => cfg.max_results = Some(parse_usize(val, name)?),
        "--has-results" | "--quiet" => { cfg.quiet = true; cfg.max_results = Some(1); },
        "--show-errors" => cfg.show_errors = true,
        "--base-directory" => cfg.base_directory = Some(PathBuf::from(required(val, name)?)),
        "--path-separator" => cfg.path_separator = Some(required(val, name)?),
        "--search-path" => cfg.search_paths.push(PathBuf::from(required(val, name)?)),
        "--strip-cwd-prefix" => {
            let v = val.unwrap_or_else(|| "always".to_string());
            cfg.strip_cwd_prefix = match v.as_str() {
                "always" => StripMode::Always,
                "never" => StripMode::Never,
                _ => StripMode::Auto,
            };
        }
        "--one-file-system" | "--mount" | "--xdev" | "--no-require-git" | "--require-git" => {},
        "--and" => cfg.and_patterns.push(required(val, name)?),
        "--ignore-contain" => cfg.ignore_contain.push(required(val, name)?),
        _ if name.starts_with("--strip-cwd-prefix") => {}
        _ if name.starts_with("--hyperlink") => {},
        _ => return Err(format!("unexpected argument '{}' found", name)),
    }
    Ok(())
}

fn handle_short_value(c: char, val: String, cfg: &mut Config) -> Result<(), String> {
    match c {
        'd' => cfg.max_depth = Some(val.parse().map_err(|_| "invalid value for depth".to_string())?),
        'E' => cfg.excludes.push(val),
        't' => cfg.types.push(parse_type(&val)?),
        'e' => cfg.extensions.push(val.trim_start_matches('.').to_string()),
        'S' => cfg.size = Some(parse_size(&val)?),
        'o' => cfg.owner = Some(parse_owner(&val)?),
        'c' => cfg.color_always = val == "always",
        'j' => {},
        'C' => cfg.base_directory = Some(PathBuf::from(val)),
        _ => {}
    }
    Ok(())
}

fn required(v: Option<String>, name: &str) -> Result<String, String> {
    v.ok_or_else(|| format!("a value is required for '{}'", name))
}

fn parse_usize(v: Option<String>, name: &str) -> Result<usize, String> {
    required(v, name)?.parse().map_err(|_| format!("invalid value for '{}'", name))
}

fn split_pattern_paths(pos: Vec<String>, cfg: &Config) -> (Option<String>, Vec<PathBuf>) {
    if !cfg.search_paths.is_empty() {
        return (pos.get(0).cloned(), Vec::new());
    }
    if pos.is_empty() {
        return (None, Vec::new());
    }
    let pat = pos[0].clone();
    let paths = pos.into_iter().skip(1).map(PathBuf::from).collect();
    (Some(pat), paths)
}

fn build_matcher(pattern: Option<&str>, cfg: &Config) -> Result<Matcher, String> {
    let mut all = Vec::new();
    if let Some(p) = pattern {
        if !p.is_empty() {
            all.push(p.to_string());
        }
    }
    all.extend(cfg.and_patterns.clone());
    let ci = match cfg.case_sensitive {
        Some(cs) => !cs,
        None => !all.iter().any(|p| p.chars().any(|c| c.is_uppercase())),
    };
    let mut pats = Vec::new();
    for p in all {
        pats.push(if cfg.fixed {
            Pattern::Fixed { needle: if ci { p.to_lowercase() } else { p }, ci }
        } else if cfg.glob {
            Pattern::Glob { pat: if ci { p.to_lowercase() } else { p }, ci }
        } else {
            let re = RegexBuilder::new(&p).case_insensitive(ci).build().map_err(|e| e.to_string())?;
            Pattern::Regex(re)
        });
    }
    let pattern = if pats.is_empty() { None } else { Some(pats.remove(0)) };
    Ok(Matcher { pattern, ands: pats })
}

fn walk_root(root: &Path, cfg: &Config, matcher: &Matcher, out: &mut Vec<ResultEntry>) -> Result<(), String> {
    let root_abs = fs::canonicalize(root).unwrap_or_else(|_| root.to_path_buf());
    let mut ignore_stack = Vec::<String>::new();
    if !cfg.no_ignore {
        let cwd = Path::new(".");
        load_ignore_file(cwd, ".gitignore", &mut ignore_stack);
        load_ignore_file(cwd, ".ignore", &mut ignore_stack);
        load_ignore_file(cwd, ".fdignore", &mut ignore_stack);
    }
    let initial_rel = if root == Path::new(".") {
        PathBuf::new()
    } else {
        root.to_path_buf()
    };
    walk_dir(root, &initial_rel, 0, &root_abs, cfg, matcher, out, ignore_stack);
    Ok(())
}

fn walk_dir(path: &Path, rel: &Path, depth: usize, root_abs: &Path, cfg: &Config, matcher: &Matcher, out: &mut Vec<ResultEntry>, mut ignores: Vec<String>) {
    if let Some(max) = cfg.max_results {
        if out.len() >= max { return; }
    }
    if !cfg.no_ignore {
        load_ignore_file(path, ".gitignore", &mut ignores);
        load_ignore_file(path, ".ignore", &mut ignores);
        load_ignore_file(path, ".fdignore", &mut ignores);
    }
    if cfg.ignore_contain.iter().any(|n| path.join(n).exists()) {
        return;
    }
    let rd = match fs::read_dir(path) {
        Ok(rd) => rd,
        Err(e) => {
            if cfg.show_errors { eprintln!("{}: {}", path.display(), e); }
            return;
        }
    };
    let mut entries: Vec<DirEntry> = rd.filter_map(Result::ok).collect();
    entries.sort_by(|a, b| {
        let am = if cfg.follow { fs::metadata(a.path()) } else { fs::symlink_metadata(a.path()) };
        let bm = if cfg.follow { fs::metadata(b.path()) } else { fs::symlink_metadata(b.path()) };
        let ad = am.map(|m| m.is_dir()).unwrap_or(false);
        let bd = bm.map(|m| m.is_dir()).unwrap_or(false);
        bd.cmp(&ad).then_with(|| a.file_name().cmp(&b.file_name()))
    });
    for ent in entries {
        let name = ent.file_name().to_string_lossy().to_string();
        if !cfg.hidden && name.starts_with('.') {
            continue;
        }
        let child_rel = rel.join(&name);
        if !cfg.no_ignore && is_ignored(&child_rel, &name, &ignores) {
            continue;
        }
        if cfg.excludes.iter().any(|p| glob_match(p, &name) || glob_match(p, &path_to_slash(&child_rel))) {
            continue;
        }
        let child_path = ent.path();
        let meta_res = if cfg.follow { fs::metadata(&child_path) } else { fs::symlink_metadata(&child_path) };
        let meta = match meta_res {
            Ok(m) => m,
            Err(e) => {
                if cfg.show_errors { eprintln!("{}: {}", child_path.display(), e); }
                continue;
            }
        };
        let ft = meta.file_type();
        let is_symlink = ft.is_symlink();
        let is_dir = if cfg.follow { meta.is_dir() } else { ft.is_dir() };
        let entry_depth = depth + 1;
        let entry = ResultEntry { path: child_path.clone(), rel: child_rel.clone(), depth: entry_depth, meta: meta.clone(), is_dir, is_symlink };
        let matches = entry_depth >= cfg.min_depth && matches_entry(&entry, root_abs, cfg, matcher);
        if matches {
            out.push(entry.clone());
            if let Some(max) = cfg.max_results {
                if out.len() >= max { return; }
            }
        }
        let should_descend = is_dir && cfg.max_depth.map_or(true, |m| entry_depth < m) && !(cfg.prune && matches);
        if should_descend {
            if is_symlink && !cfg.follow { continue; }
            walk_dir(&child_path, &child_rel, entry_depth, root_abs, cfg, matcher, out, ignores.clone());
        }
    }
}

fn matches_entry(e: &ResultEntry, root_abs: &Path, cfg: &Config, matcher: &Matcher) -> bool {
    if !type_matches(e, cfg) || !ext_matches(e, cfg) || !size_matches(e, cfg) || !time_matches(e, cfg) || !owner_matches(e, cfg) {
        return false;
    }
    let candidate = if cfg.full_path {
        let p = if cfg.absolute { absolute_for(e, root_abs) } else { e.rel.clone() };
        path_to_slash(&p)
    } else {
        e.rel.file_name().unwrap_or_else(|| OsStr::new("")).to_string_lossy().to_string()
    };
    pattern_matches_opt(&matcher.pattern, &candidate) && matcher.ands.iter().all(|p| pattern_matches(p, &candidate))
}

fn pattern_matches_opt(p: &Option<Pattern>, text: &str) -> bool {
    p.as_ref().map_or(true, |p| pattern_matches(p, text))
}

fn pattern_matches(p: &Pattern, text: &str) -> bool {
    match p {
        Pattern::Regex(r) => r.is_match(text),
        Pattern::Glob { pat, ci } => {
            let t = if *ci { text.to_lowercase() } else { text.to_string() };
            glob_match(pat, &t)
        }
        Pattern::Fixed { needle, ci } => {
            let t = if *ci { text.to_lowercase() } else { text.to_string() };
            t.contains(needle)
        }
    }
}

fn type_matches(e: &ResultEntry, cfg: &Config) -> bool {
    if cfg.types.is_empty() {
        return true;
    }
    let set: HashSet<FileKind> = cfg.types.iter().copied().collect();
    let normal_type_requested = set.iter().any(|k| !matches!(k, FileKind::Executable | FileKind::Empty));
    let mut ok = false;
    for t in &cfg.types {
        ok |= match t {
            FileKind::File => e.meta.is_file(),
            FileKind::Dir => e.is_dir,
            FileKind::Symlink => e.is_symlink,
            FileKind::Socket => e.meta.file_type().is_socket(),
            FileKind::Pipe => e.meta.file_type().is_fifo(),
            FileKind::Block => e.meta.file_type().is_block_device(),
            FileKind::Char => e.meta.file_type().is_char_device(),
            FileKind::Executable => e.meta.is_file() && (e.meta.permissions().mode() & 0o111 != 0),
            FileKind::Empty => {
                let base = if normal_type_requested { true } else { e.meta.is_file() || e.is_dir };
                base && is_empty(e)
            }
        };
    }
    ok
}

impl std::hash::Hash for FileKind {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) { (*self as u8).hash(state); }
}

fn is_empty(e: &ResultEntry) -> bool {
    if e.meta.is_file() {
        e.meta.len() == 0
    } else if e.is_dir {
        fs::read_dir(&e.path).map(|mut r| r.next().is_none()).unwrap_or(false)
    } else {
        false
    }
}

fn ext_matches(e: &ResultEntry, cfg: &Config) -> bool {
    if cfg.extensions.is_empty() {
        return true;
    }
    let ext = e.path.extension().and_then(|s| s.to_str()).unwrap_or("");
    cfg.extensions.iter().any(|x| ext.eq_ignore_ascii_case(x))
}

fn size_matches(e: &ResultEntry, cfg: &Config) -> bool {
    match &cfg.size {
        None => true,
        Some(SizeFilter::Eq(n)) => e.meta.len() == *n,
        Some(SizeFilter::Ge(n)) => e.meta.len() >= *n,
        Some(SizeFilter::Le(n)) => e.meta.len() <= *n,
    }
}

fn time_matches(e: &ResultEntry, cfg: &Config) -> bool {
    let mt = e.meta.modified().unwrap_or(UNIX_EPOCH);
    if let Some(t) = cfg.changed_within {
        if mt <= t { return false; }
    }
    if let Some(t) = cfg.changed_before {
        if mt >= t { return false; }
    }
    true
}

fn owner_matches(e: &ResultEntry, cfg: &Config) -> bool {
    let Some(of) = &cfg.owner else { return true };
    if let Some((u, neg)) = of.user {
        let m = e.meta.uid() == u;
        if m == neg { return false; }
    }
    if let Some((g, neg)) = of.group {
        let m = e.meta.gid() == g;
        if m == neg { return false; }
    }
    true
}

fn parse_type(s: &str) -> Result<FileKind, String> {
    match s {
        "f" | "file" => Ok(FileKind::File),
        "d" | "dir" | "directory" => Ok(FileKind::Dir),
        "l" | "symlink" => Ok(FileKind::Symlink),
        "s" | "socket" => Ok(FileKind::Socket),
        "p" | "pipe" => Ok(FileKind::Pipe),
        "b" | "block-device" => Ok(FileKind::Block),
        "c" | "char-device" => Ok(FileKind::Char),
        "x" | "executable" => Ok(FileKind::Executable),
        "e" | "empty" => Ok(FileKind::Empty),
        _ => Err(format!("invalid value '{}' for '--type <filetype>'", s)),
    }
}

fn parse_size(s: &str) -> Result<SizeFilter, String> {
    let (mode, rest) = match s.as_bytes().first() {
        Some(b'+') => ('+', &s[1..]),
        Some(b'-') => ('-', &s[1..]),
        _ => ('=', s),
    };
    let split = rest.find(|c: char| !c.is_ascii_digit()).unwrap_or(rest.len());
    let num: u64 = rest[..split].parse().map_err(|_| format!("invalid size '{}'", s))?;
    let unit = rest[split..].to_ascii_lowercase();
    let mult = match unit.as_str() {
        "" | "b" => 1,
        "k" => 1000,
        "m" => 1000_u64.pow(2),
        "g" => 1000_u64.pow(3),
        "t" => 1000_u64.pow(4),
        "ki" => 1024,
        "mi" => 1024_u64.pow(2),
        "gi" => 1024_u64.pow(3),
        "ti" => 1024_u64.pow(4),
        _ => return Err(format!("invalid size unit '{}'", unit)),
    };
    let val = num.saturating_mul(mult);
    Ok(match mode { '+' => SizeFilter::Ge(val), '-' => SizeFilter::Le(val), _ => SizeFilter::Eq(val) })
}

fn parse_time_filter(s: &str) -> Result<SystemTime, String> {
    if let Some(ts) = s.strip_prefix('@') {
        let secs: u64 = ts.parse().map_err(|_| format!("invalid timestamp '{}'", s))?;
        return Ok(UNIX_EPOCH + Duration::from_secs(secs));
    }
    if let Some(dur) = parse_duration(s) {
        return Ok(SystemTime::now().checked_sub(dur).unwrap_or(UNIX_EPOCH));
    }
    if let Ok(dt) = NaiveDateTime::parse_from_str(s, "%Y-%m-%d %H:%M:%S") {
        return Ok(Local.from_local_datetime(&dt).single().unwrap().into());
    }
    if let Ok(d) = NaiveDate::parse_from_str(s, "%Y-%m-%d") {
        let dt = d.and_hms_opt(0, 0, 0).unwrap();
        return Ok(Local.from_local_datetime(&dt).single().unwrap().into());
    }
    Err(format!("invalid date or duration '{}'", s))
}

fn parse_duration(s: &str) -> Option<Duration> {
    let split = s.find(|c: char| !c.is_ascii_digit())?;
    let n: u64 = s[..split].parse().ok()?;
    let u = s[split..].to_ascii_lowercase();
    let secs = match u.as_str() {
        "s" | "sec" | "secs" | "second" | "seconds" => n,
        "m" | "min" | "mins" | "minute" | "minutes" => n * 60,
        "h" | "hr" | "hour" | "hours" => n * 3600,
        "d" | "day" | "days" => n * 86400,
        "w" | "week" | "weeks" => n * 604800,
        _ => return None,
    };
    Some(Duration::from_secs(secs))
}

fn parse_owner(s: &str) -> Result<OwnerFilter, String> {
    let mut parts = s.splitn(2, ':');
    let u = parts.next().unwrap_or("");
    let g = parts.next();
    Ok(OwnerFilter { user: parse_id_part(u, true)?, group: g.map(|x| parse_id_part(x, false)).transpose()?.flatten() })
}

fn parse_id_part(s: &str, user: bool) -> Result<Option<(u32, bool)>, String> {
    if s.is_empty() { return Ok(None); }
    let (neg, val) = if let Some(v) = s.strip_prefix('!') { (true, v) } else { (false, s) };
    if let Ok(id) = val.parse::<u32>() {
        return Ok(Some((id, neg)));
    }
    let c = std::ffi::CString::new(val).map_err(|_| "invalid owner".to_string())?;
    unsafe {
        if user {
            let p = libc::getpwnam(c.as_ptr());
            if p.is_null() { Err(format!("unknown user '{}'", val)) } else { Ok(Some(((*p).pw_uid, neg))) }
        } else {
            let p = libc::getgrnam(c.as_ptr());
            if p.is_null() { Err(format!("unknown group '{}'", val)) } else { Ok(Some(((*p).gr_gid, neg))) }
        }
    }
}

fn load_ignore_file(dir: &Path, name: &str, ignores: &mut Vec<String>) {
    if let Ok(text) = fs::read_to_string(dir.join(name)) {
        for line in text.lines() {
            let l = line.trim();
            if l.is_empty() || l.starts_with('#') || l.starts_with('!') { continue; }
            ignores.push(l.to_string());
        }
    }
}

fn is_ignored(rel: &Path, name: &str, pats: &[String]) -> bool {
    let slash = path_to_slash(rel);
    for p in pats {
        let p2 = p.trim_start_matches('/');
        if let Some(dirpat) = p2.strip_suffix('/') {
            if slash == dirpat || slash.starts_with(&format!("{}/", dirpat)) || name == dirpat {
                return true;
            }
        } else if p2.contains('/') {
            if glob_match(p2, &slash) { return true; }
        } else if glob_match(p2, name) || glob_match(p2, &slash) {
            return true;
        }
    }
    false
}

fn print_results(results: &[ResultEntry], cfg: &Config) -> Result<(), String> {
    let mut out = io::BufWriter::new(io::stdout());
    for e in results {
        let s = if let Some(fmt) = &cfg.format {
            format_entry(fmt, e, cfg)
        } else {
            display_path(e, cfg, true)
        };
        out.write_all(s.as_bytes()).map_err(|e| e.to_string())?;
        if cfg.print0 {
            out.write_all(&[0]).map_err(|e| e.to_string())?;
        } else {
            out.write_all(b"\n").map_err(|e| e.to_string())?;
        }
    }
    Ok(())
}

fn display_path(e: &ResultEntry, cfg: &Config, for_output: bool) -> String {
    let mut p = if cfg.absolute {
        if e.path.is_absolute() {
            e.path.clone()
        } else {
            let clean = e.path.strip_prefix(".").unwrap_or(&e.path);
            env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).join(clean)
        }
    } else {
        e.rel.clone()
    };
    let mut s = path_to_slash(&p);
    if s.is_empty() { s = ".".to_string(); }
    if e.is_dir && !s.ends_with('/') {
        s.push('/');
    }
    if let Some(sep) = &cfg.path_separator {
        if sep != "/" { s = s.replace('/', sep); }
    }
    if for_output && !cfg.absolute && needs_dot_prefix(cfg) && !s.starts_with("./") {
        s = format!("./{}", s);
    }
    if cfg.color_always {
        if e.is_dir { s = format!("\x1b[1;34m{}\x1b[0m", s); }
        else if e.is_symlink { s = format!("\x1b[1;36m{}\x1b[0m", s); }
        else if e.meta.permissions().mode() & 0o111 != 0 { s = format!("\x1b[1;32m{}\x1b[0m", s); }
    }
    p.clear();
    s
}

fn needs_dot_prefix(cfg: &Config) -> bool {
    match cfg.strip_cwd_prefix {
        StripMode::Always => false,
        StripMode::Never => true,
        StripMode::Auto => cfg.print0 || cfg.exec.is_some() || cfg.exec_batch.is_some(),
    }
}

fn absolute_for(e: &ResultEntry, _root_abs: &Path) -> PathBuf {
    fs::canonicalize(&e.path).unwrap_or_else(|_| {
        if e.path.is_absolute() { e.path.clone() } else { env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).join(&e.path) }
    })
}

fn path_to_slash(p: &Path) -> String {
    p.to_string_lossy().replace('\\', "/")
}

fn format_entry(fmt: &str, e: &ResultEntry, cfg: &Config) -> String {
    let full = display_path(e, cfg, false);
    let base = e.path.file_name().and_then(|s| s.to_str()).unwrap_or("");
    let parent = e.rel.parent().map(path_to_slash).filter(|s| !s.is_empty()).unwrap_or_else(|| ".".to_string());
    let stem = e.path.file_stem().and_then(|s| s.to_str()).unwrap_or(base);
    fmt.replace("{}", &full)
        .replace("{/}", base)
        .replace("{//}", &parent)
        .replace("{.}", trim_ext(&full))
        .replace("{/.}", stem)
}

fn trim_ext(s: &str) -> &str {
    match s.rfind('.') {
        Some(i) if !s[i + 1..].contains('/') => &s[..i],
        _ => s,
    }
}

fn run_list_details(results: &[ResultEntry], cfg: &Config) -> Result<i32, String> {
    if results.is_empty() { return Ok(0); }
    let mut cmd = Command::new("ls");
    cmd.arg("-ld");
    for e in results {
        cmd.arg(display_path(e, cfg, false));
    }
    let st = cmd.status().map_err(|e| e.to_string())?;
    Ok(st.code().unwrap_or(1))
}

fn run_exec_each(cmd: &[String], results: &[ResultEntry], cfg: &Config) -> Result<i32, String> {
    let mut code = 0;
    for e in results {
        let args = expand_command(cmd, std::slice::from_ref(e), cfg);
        if args.is_empty() { continue; }
        let st = Command::new(&args[0]).args(&args[1..]).status().map_err(|e| e.to_string())?;
        if !st.success() { code = st.code().unwrap_or(1); }
    }
    Ok(code)
}

fn run_exec_batch(cmd: &[String], results: &[ResultEntry], cfg: &Config) -> Result<i32, String> {
    if results.is_empty() { return Ok(0); }
    let size = if cfg.batch_size == 0 { results.len() } else { cfg.batch_size };
    let mut code = 0;
    for chunk in results.chunks(size) {
        let args = expand_command(cmd, chunk, cfg);
        if args.is_empty() { continue; }
        let st = Command::new(&args[0]).args(&args[1..]).status().map_err(|e| e.to_string())?;
        if !st.success() { code = st.code().unwrap_or(1); }
    }
    Ok(code)
}

fn expand_command(cmd: &[String], entries: &[ResultEntry], cfg: &Config) -> Vec<String> {
    let has_placeholder = cmd.iter().any(|a| a.contains("{}") || a.contains("{/}") || a.contains("{//}") || a.contains("{.}") || a.contains("{/.}"));
    let mut out = Vec::new();
    for arg in cmd {
        if arg == "{}" {
            out.extend(entries.iter().map(|e| display_path(e, cfg, true)));
        } else if arg == "{/}" {
            out.extend(entries.iter().map(|e| e.path.file_name().and_then(|s| s.to_str()).unwrap_or("").to_string()));
        } else if arg == "{//}" {
            out.extend(entries.iter().map(|e| e.rel.parent().map(path_to_slash).unwrap_or_else(|| ".".to_string())));
        } else if arg == "{.}" {
            out.extend(entries.iter().map(|e| trim_ext(&display_path(e, cfg, true)).to_string()));
        } else if arg == "{/.}" {
            out.extend(entries.iter().map(|e| e.path.file_stem().and_then(|s| s.to_str()).unwrap_or("").to_string()));
        } else {
            out.push(arg.replace("{{", "{").replace("}}", "}"));
        }
    }
    if !has_placeholder {
        out.extend(entries.iter().map(|e| display_path(e, cfg, true)));
    }
    out
}

fn glob_match(pat: &str, text: &str) -> bool {
    let p: Vec<char> = pat.chars().collect();
    let t: Vec<char> = text.chars().collect();
    glob_dp(&p, &t, 0, 0)
}

fn glob_dp(p: &[char], t: &[char], mut i: usize, mut j: usize) -> bool {
    let mut star: Option<usize> = None;
    let mut match_j = 0;
    while j < t.len() {
        if i < p.len() && (p[i] == '?' || p[i] == t[j]) {
            i += 1; j += 1;
        } else if i < p.len() && p[i] == '*' {
            while i + 1 < p.len() && p[i + 1] == '*' { i += 1; }
            star = Some(i);
            match_j = j;
            i += 1;
        } else if let Some(si) = star {
            i = si + 1;
            match_j += 1;
            j = match_j;
        } else {
            return false;
        }
    }
    while i < p.len() && p[i] == '*' { i += 1; }
    i == p.len()
}

fn print_short_help() {
    println!("A program to find entries in your filesystem\n\nUsage: executable [OPTIONS] [pattern] [path]...\n\nArguments:\n  [pattern]  the search pattern (a regular expression, unless '--glob' is used; optional)\n  [path]...  the root directories for the filesystem search (optional)\n\nOptions:\n  -H, --hidden                     Search hidden files and directories\n  -I, --no-ignore                  Do not respect .(git|fd)ignore files\n  -s, --case-sensitive             Case-sensitive search (default: smart case)\n  -i, --ignore-case                Case-insensitive search (default: smart case)\n  -g, --glob                       Glob-based search (default: regular expression)\n  -a, --absolute-path              Show absolute instead of relative paths\n  -l, --list-details               Use a long listing format with file metadata\n  -L, --follow                     Follow symbolic links\n  -p, --full-path                  Search full abs. path (default: filename only)\n  -d, --max-depth <depth>          Set maximum search depth (default: none)\n  -E, --exclude <pattern>          Exclude entries that match the given glob pattern\n  -t, --type <filetype>            Filter by type: file (f), directory (d/dir), symlink (l), executable (x), empty (e), socket (s), pipe (p), char-device (c), block-device (b)\n  -e, --extension <ext>            Filter by file extension\n  -S, --size <size>                Limit results based on the size of files\n      --format <fmt>               Print results according to template\n  -x, --exec <cmd>...              Execute a command for each search result\n  -X, --exec-batch <cmd>...        Execute a command with all search results at once\n  -h, --help                       Print help (see more with '--help')\n  -V, --version                    Print version");
}

fn print_long_help() {
    print_short_help();
}
