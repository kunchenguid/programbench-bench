use regex::{Captures, Regex};
use std::collections::HashSet;
use std::env;
use std::ffi::CString;
use std::fs;
use std::io::{self, Write};
use std::os::unix::ffi::OsStrExt;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

const HELP: &str = "ambr 0.6.0

USAGE:
    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...

FLAGS:
        --key-from-file        Use file contents of KEYWORD as keyword for search
        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement
        --verbose              Verbose message
    -r, --regex                Enable regular expression search
        --column               Enable column output
        --row                  Enable row output
        --binary               Enable binary file search
        --statistics           Enable statistics output
        --skipped              Enable skipped file output
        --preserve-time        Enable timestamp preserve
        --no-interactive       Disable interactive replace
        --no-recursive         Disable recursive directory search
        --no-symlink           Disable symbolic link follow
        --no-color             Disable colored output
        --no-file              Disable filename output
        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip
        --no-skip-gitignore    Disable .gitignore skip
        --no-fixed-order       Disable output order guarantee
        --no-parent-ignore     Disable .*ignore file search at parent directories
        --tbm                  [Experimental] Enable TBM matcher
        --sse                  [Experimental] Enable SSE 4.2
    -h, --help                 Prints help information
    -V, --version              Prints version information

OPTIONS:
        --max-threads <NUM>          Number of max threads [default: 4]
        --size-per-thread <BYTES>    File size per one thread [default: 1048576]
        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]
        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]

ARGS:
    <KEYWORD>        Keyword for search
    <REPLACEMENT>    Keyword for replace
    <PATHS>...       Search paths
";

#[derive(Clone)]
struct Config {
    regex: bool,
    column: bool,
    row: bool,
    binary: bool,
    statistics: bool,
    skipped: bool,
    interactive: bool,
    recursive: bool,
    symlink: bool,
    color: bool,
    file: bool,
    skip_vcs: bool,
    skip_gitignore: bool,
    fixed_order: bool,
    parent_ignore: bool,
    preserve_time: bool,
    key_from_file: bool,
    rep_from_file: bool,
    verbose: bool,
    max_threads: usize,
    size_per_thread: usize,
    bin_check_bytes: usize,
    mmap_bytes: usize,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            regex: false,
            column: false,
            row: false,
            binary: false,
            statistics: false,
            skipped: false,
            interactive: true,
            recursive: true,
            symlink: true,
            color: true,
            file: true,
            skip_vcs: true,
            skip_gitignore: true,
            fixed_order: true,
            parent_ignore: true,
            preserve_time: false,
            key_from_file: false,
            rep_from_file: false,
            verbose: false,
            max_threads: 4,
            size_per_thread: 1_048_576,
            bin_check_bytes: 256,
            mmap_bytes: 1_048_576,
        }
    }
}

struct Args {
    cfg: Config,
    keyword: String,
    replacement: String,
    paths: Vec<PathBuf>,
}

#[derive(Default)]
struct Stats {
    searched: usize,
    changed: usize,
    skipped: usize,
    matches: usize,
}

enum Decision {
    Yes,
    No,
    All,
    Quit,
}

fn main() {
    let code = match real_main() {
        Ok(found) => {
            if found {
                0
            } else {
                1
            }
        }
        Err(code) => code,
    };
    std::process::exit(code);
}

fn real_main() -> Result<bool, i32> {
    let mut cfg = Config::default();
    load_config(&mut cfg);
    let args = parse_args(cfg)?;
    let keyword = if args.cfg.key_from_file {
        fs::read_to_string(&args.keyword).unwrap_or_default()
    } else {
        args.keyword
    };
    let replacement = if args.cfg.rep_from_file {
        fs::read_to_string(&args.replacement).unwrap_or_default()
    } else {
        args.replacement
    };
    if keyword.is_empty() {
        return Ok(false);
    }

    let matcher = if args.cfg.regex {
        Some(match Regex::new(&keyword) {
            Ok(r) => r,
            Err(e) => {
                eprintln!("error: {}", e);
                return Err(1);
            }
        })
    } else {
        None
    };

    let mut files = Vec::new();
    let mut stats = Stats::default();
    for p in &args.paths {
        collect_files(p, &args.cfg, &mut files, &mut stats);
    }
    if args.cfg.fixed_order {
        files.sort();
    }

    let mut all = !args.cfg.interactive;
    let mut any = false;
    for file in files {
        if process_file(&file, &args.cfg, &keyword, &replacement, matcher.as_ref(), &mut all, &mut stats)? {
            any = true;
        }
    }

    if args.cfg.statistics {
        println!("{} files searched", stats.searched);
        println!("{} files changed", stats.changed);
        println!("{} matches replaced", stats.matches);
        if args.cfg.skipped {
            println!("{} files skipped", stats.skipped);
        }
    }

    Ok(any)
}

fn parse_args(mut cfg: Config) -> Result<Args, i32> {
    let raw: Vec<String> = env::args().skip(1).collect();
    if raw.iter().any(|x| x == "-h" || x == "--help") {
        print!("{}", HELP);
        return Err(0);
    }
    if raw.iter().any(|x| x == "-V" || x == "--version") {
        println!("ambr 0.6.0");
        return Err(0);
    }

    let mut pos = Vec::new();
    let mut i = 0;
    while i < raw.len() {
        let a = &raw[i];
        match a.as_str() {
            "--key-from-file" => cfg.key_from_file = true,
            "--rep-from-file" => cfg.rep_from_file = true,
            "--verbose" => cfg.verbose = true,
            "-r" | "--regex" => cfg.regex = true,
            "--column" => cfg.column = true,
            "--row" => cfg.row = true,
            "--binary" => cfg.binary = true,
            "--statistics" => cfg.statistics = true,
            "--skipped" => cfg.skipped = true,
            "--preserve-time" => cfg.preserve_time = true,
            "--no-interactive" => cfg.interactive = false,
            "--no-recursive" => cfg.recursive = false,
            "--no-symlink" => cfg.symlink = false,
            "--no-color" => cfg.color = false,
            "--no-file" => cfg.file = false,
            "--no-skip-vcs" => cfg.skip_vcs = false,
            "--no-skip-gitignore" => cfg.skip_gitignore = false,
            "--no-fixed-order" => cfg.fixed_order = false,
            "--no-parent-ignore" => cfg.parent_ignore = false,
            "--tbm" | "--sse" => {}
            "--max-threads" | "--size-per-thread" | "--bin-check-bytes" | "--mmap-bytes" => {
                i += 1;
                if i >= raw.len() {
                    eprintln!("error: The argument '{}' requires a value but none was supplied", a);
                    return Err(1);
                }
                let v = match raw[i].parse::<usize>() {
                    Ok(v) => v,
                    Err(e) => {
                        eprintln!("error: Invalid value for '{} <{}>': {}", a, if *a == "--max-threads" { "NUM" } else { "BYTES" }, e);
                        return Err(1);
                    }
                };
                match a.as_str() {
                    "--max-threads" => cfg.max_threads = v,
                    "--size-per-thread" => cfg.size_per_thread = v,
                    "--bin-check-bytes" => cfg.bin_check_bytes = v,
                    "--mmap-bytes" => cfg.mmap_bytes = v,
                    _ => {}
                }
            }
            "--" => {
                pos.extend(raw[i + 1..].iter().cloned());
                break;
            }
            _ if a.starts_with("--") => {
                eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context", a);
                eprintln!();
                eprintln!("USAGE:");
                eprintln!("    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...");
                eprintln!();
                eprintln!("For more information try --help");
                return Err(1);
            }
            _ if a.starts_with('-') && a != "-" => {
                eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context", a);
                return Err(1);
            }
            _ => pos.push(a.clone()),
        }
        i += 1;
    }

    if pos.len() < 2 {
        eprintln!("error: The following required arguments were not provided:");
        if pos.is_empty() {
            eprintln!("    <KEYWORD>");
        }
        eprintln!("    <REPLACEMENT>");
        eprintln!();
        eprintln!("USAGE:");
        eprintln!("    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>");
        eprintln!();
        eprintln!("For more information try --help");
        return Err(1);
    }

    let keyword = pos.remove(0);
    let replacement = pos.remove(0);
    let paths = if pos.is_empty() {
        vec![PathBuf::from(".")]
    } else {
        pos.into_iter().map(PathBuf::from).collect()
    };
    Ok(Args { cfg, keyword, replacement, paths })
}

fn load_config(cfg: &mut Config) {
    let mut paths = Vec::new();
    if let Ok(home) = env::var("HOME") {
        paths.push(PathBuf::from(&home).join(".ambr.toml"));
        paths.push(PathBuf::from(&home).join(".config/amber/ambr.toml"));
    }
    paths.push(PathBuf::from("/etc/amber/ambr.toml"));
    for p in paths {
        if let Ok(s) = fs::read_to_string(p) {
            apply_config(cfg, &s);
            break;
        }
    }
}

fn apply_config(cfg: &mut Config, text: &str) {
    for line in text.lines() {
        let line = line.split('#').next().unwrap_or("").trim();
        if line.is_empty() {
            continue;
        }
        let Some((k, v)) = line.split_once('=') else { continue };
        let val = match v.trim() {
            "true" => true,
            "false" => false,
            _ => continue,
        };
        match k.trim() {
            "regex" => cfg.regex = val,
            "column" => cfg.column = val,
            "row" => cfg.row = val,
            "binary" => cfg.binary = val,
            "statistics" => cfg.statistics = val,
            "skipped" => cfg.skipped = val,
            "interactive" => cfg.interactive = val,
            "recursive" => cfg.recursive = val,
            "symlink" => cfg.symlink = val,
            "color" => cfg.color = val,
            "file" => cfg.file = val,
            "skip_vcs" => cfg.skip_vcs = val,
            "skip_gitignore" => cfg.skip_gitignore = val,
            "fixed_order" => cfg.fixed_order = val,
            "parent_ignore" => cfg.parent_ignore = val,
            _ => {}
        }
    }
}

fn collect_files(path: &Path, cfg: &Config, files: &mut Vec<PathBuf>, stats: &mut Stats) {
    let meta = if cfg.symlink {
        fs::metadata(path)
    } else {
        fs::symlink_metadata(path)
    };
    let Ok(meta) = meta else {
        stats.skipped += 1;
        if cfg.skipped {
            println!("Skipped: {}", path.display());
        }
        return;
    };

    if meta.is_file() {
        files.push(path.to_path_buf());
        return;
    }
    if !meta.is_dir() {
        return;
    }
    if !cfg.recursive && !is_root_path(path) {
        return;
    }
    if cfg.skip_vcs && is_vcs_dir(path) {
        return;
    }

    let ignores = if cfg.skip_gitignore {
        read_ignore_file(path)
    } else {
        HashSet::new()
    };

    let Ok(rd) = fs::read_dir(path) else {
        stats.skipped += 1;
        return;
    };
    for ent in rd.flatten() {
        let p = ent.path();
        let name = ent.file_name().to_string_lossy().into_owned();
        if cfg.skip_vcs && matches!(name.as_str(), ".git" | ".hg" | ".svn" | ".bzr") {
            continue;
        }
        if ignores.contains(&name) {
            continue;
        }
        let Ok(ft) = ent.file_type() else { continue };
        if ft.is_dir() {
            if cfg.recursive {
                collect_files(&p, cfg, files, stats);
            }
        } else if ft.is_file() || (cfg.symlink && ft.is_symlink()) {
            files.push(p);
        }
    }
}

fn is_root_path(path: &Path) -> bool {
    path == Path::new(".") || path.components().count() <= 1
}

fn is_vcs_dir(path: &Path) -> bool {
    path.file_name()
        .and_then(|s| s.to_str())
        .map(|s| matches!(s, ".git" | ".hg" | ".svn" | ".bzr"))
        .unwrap_or(false)
}

fn read_ignore_file(dir: &Path) -> HashSet<String> {
    let mut set = HashSet::new();
    let Ok(s) = fs::read_to_string(dir.join(".gitignore")) else {
        return set;
    };
    for line in s.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') || line.starts_with('!') {
            continue;
        }
        let cleaned = line.trim_end_matches('/').trim_start_matches('/');
        if !cleaned.contains('*') && !cleaned.contains('/') {
            set.insert(cleaned.to_string());
        }
    }
    set
}

fn process_file(
    path: &Path,
    cfg: &Config,
    keyword: &str,
    replacement: &str,
    regex: Option<&Regex>,
    all: &mut bool,
    stats: &mut Stats,
) -> Result<bool, i32> {
    stats.searched += 1;
    if !cfg.binary && is_binary(path, cfg.bin_check_bytes) {
        stats.skipped += 1;
        if cfg.skipped {
            println!("Skipped: {}", path.display());
        }
        return Ok(false);
    }
    let original_bytes = match fs::read(path) {
        Ok(v) => v,
        Err(_) => {
            stats.skipped += 1;
            return Ok(false);
        }
    };
    let text = match String::from_utf8(original_bytes.clone()) {
        Ok(text) => text,
        Err(_) => {
            if !cfg.binary {
                stats.skipped += 1;
                return Ok(false);
            }
            String::from_utf8_lossy(&original_bytes).into_owned()
        }
    };
    if regex.is_none() && !text.contains(keyword) {
        return Ok(false);
    }
    if let Some(r) = regex {
        if !r.is_match(&text) {
            return Ok(false);
        }
    }

    let before_times = if cfg.preserve_time {
        fs::metadata(path).ok().map(|m| (m.accessed().ok(), m.modified().ok())).unwrap_or((None, None))
    } else {
        (None, None)
    };

    let mut changed_matches = 0usize;
    let new_text = if let Some(r) = regex {
        replace_regex(path, cfg, &text, r, replacement, all, &mut changed_matches)?
    } else {
        replace_fixed(path, cfg, &text, keyword, replacement, all, &mut changed_matches)?
    };

    if changed_matches > 0 && new_text != text {
        if fs::write(path, new_text.as_bytes()).is_err() {
            return Err(1);
        }
        if cfg.preserve_time {
            restore_times(path, before_times.0, before_times.1);
        }
        stats.changed += 1;
        stats.matches += changed_matches;
        Ok(true)
    } else {
        Ok(false)
    }
}

fn replace_fixed(
    path: &Path,
    cfg: &Config,
    text: &str,
    keyword: &str,
    replacement: &str,
    all: &mut bool,
    changed: &mut usize,
) -> Result<String, i32> {
    let mut out = String::with_capacity(text.len());
    let mut rest = text;
    while let Some(pos) = rest.find(keyword) {
        out.push_str(&rest[..pos]);
        let do_replace = if *all {
            true
        } else {
            match ask(path, cfg, rest, pos, keyword.len())? {
                Decision::Yes => true,
                Decision::No => false,
                Decision::All => {
                    *all = true;
                    true
                }
                Decision::Quit => return Err(1),
            }
        };
        if do_replace {
            out.push_str(replacement);
            *changed += 1;
        } else {
            out.push_str(keyword);
        }
        rest = &rest[pos + keyword.len()..];
    }
    out.push_str(rest);
    Ok(out)
}

fn replace_regex(
    path: &Path,
    cfg: &Config,
    text: &str,
    regex: &Regex,
    replacement: &str,
    all: &mut bool,
    changed: &mut usize,
) -> Result<String, i32> {
    let mut out = String::with_capacity(text.len());
    let mut last = 0;
    for caps in regex.captures_iter(text) {
        let Some(m) = caps.get(0) else { continue };
        out.push_str(&text[last..m.start()]);
        let do_replace = if *all {
            true
        } else {
            match ask(path, cfg, text, m.start(), m.end() - m.start())? {
                Decision::Yes => true,
                Decision::No => false,
                Decision::All => {
                    *all = true;
                    true
                }
                Decision::Quit => return Err(1),
            }
        };
        if do_replace {
            let mut rep = String::new();
            expand_replacement(&caps, replacement, &mut rep);
            out.push_str(&rep);
            *changed += 1;
        } else {
            out.push_str(m.as_str());
        }
        last = m.end();
    }
    out.push_str(&text[last..]);
    Ok(out)
}

fn expand_replacement(caps: &Captures<'_>, replacement: &str, out: &mut String) {
    caps.expand(replacement, out);
}

fn ask(path: &Path, cfg: &Config, text: &str, byte_pos: usize, len: usize) -> Result<Decision, i32> {
    if cfg.file || cfg.row || cfg.column {
        print_match_context(path, cfg, text, byte_pos, len);
    }
    print!("Replace keyword? ( Yes[Y], No[N], All[A], Quit[Q] ):");
    let _ = io::stdout().flush();
    let mut line = String::new();
    if io::stdin().read_line(&mut line).is_err() {
        return Ok(Decision::No);
    }
    match parse_decision(&line) {
        Decision::Yes => Ok(Decision::Yes),
        Decision::No => Ok(Decision::No),
        Decision::All => Ok(Decision::All),
        Decision::Quit => Err(1),
    }
}

fn parse_decision(s: &str) -> Decision {
    match s.trim().to_ascii_lowercase().as_str() {
        "y" | "yes" => Decision::Yes,
        "a" | "all" => Decision::All,
        "q" | "quit" => Decision::Quit,
        _ => Decision::No,
    }
}

fn print_match_context(path: &Path, cfg: &Config, text: &str, byte_pos: usize, len: usize) {
    let start = text[..byte_pos].rfind('\n').map(|p| p + 1).unwrap_or(0);
    let end = text[byte_pos..].find('\n').map(|p| byte_pos + p).unwrap_or(text.len());
    let line = &text[start..end];
    let row = text[..byte_pos].bytes().filter(|&b| b == b'\n').count() + 1;
    let col = text[start..byte_pos].chars().count() + 1;
    let mut prefix = String::new();
    if cfg.file {
        prefix.push_str(&path.display().to_string());
    }
    if cfg.row {
        if !prefix.is_empty() {
            prefix.push(':');
        }
        prefix.push_str(&row.to_string());
    }
    if cfg.column {
        if !prefix.is_empty() {
            prefix.push(':');
        }
        prefix.push_str(&col.to_string());
    }
    if !prefix.is_empty() {
        prefix.push(':');
        print!("{}", prefix);
    }
    if cfg.color {
        let rel_start = byte_pos - start;
        print!("{}{}{}{}", &line[..rel_start], "\x1b[01;31m", &line[rel_start..rel_start + len], "\x1b[0m");
        println!("{}", &line[rel_start + len..]);
    } else {
        println!("{}", line);
    }
}

fn is_binary(path: &Path, check_bytes: usize) -> bool {
    let Ok(bytes) = fs::read(path) else { return false };
    bytes.iter().take(check_bytes).any(|&b| b == 0)
}

fn restore_times(path: &Path, accessed: Option<SystemTime>, modified: Option<SystemTime>) {
    let at = to_timespec(accessed.unwrap_or_else(SystemTime::now));
    let mt = to_timespec(modified.unwrap_or_else(SystemTime::now));
    let times = [at, mt];
    let cpath = match CString::new(path.as_os_str().as_bytes()) {
        Ok(p) => p,
        Err(_) => return,
    };
    unsafe {
        libc::utimensat(libc::AT_FDCWD, cpath.as_ptr(), times.as_ptr(), 0);
    }
}

fn to_timespec(t: SystemTime) -> libc::timespec {
    let d = t.duration_since(UNIX_EPOCH).unwrap_or_default();
    libc::timespec {
        tv_sec: d.as_secs() as libc::time_t,
        tv_nsec: d.subsec_nanos() as libc::c_long,
    }
}
