use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

const VERSION: &str = "1.17.0 (9135bd68ddc9ea65023d967c75048a7a86a5d495)";
const SHORT_VERSION: &str = "1.17.0";
const DOXY_TEMPLATE: &str = include_str!("Doxyfile.full.template");
const DOXY_TEMPLATE_SHORT: &str = include_str!("Doxyfile.template");
const LAYOUT_TEMPLATE: &str = include_str!("DoxygenLayout.xml");
const RTF_EXT: &str = include_str!("rtf_extensions.txt");
const RTF_STYLE: &str = include_str!("rtf_stylesheet.txt");
const EMOJIS: &str = include_str!("emojis.txt");
const HTML_HEADER: &str = include_str!("html_header.html");
const HTML_FOOTER: &str = include_str!("html_footer.html");
const HTML_STYLE: &str = include_str!("html_style.css");
const LATEX_HEADER: &str = include_str!("latex_header.tex");
const LATEX_FOOTER: &str = include_str!("latex_footer.tex");
const LATEX_STYLE: &str = include_str!("latex_style.sty");

fn main() {
    let code = run();
    std::process::exit(code);
}

fn run() -> i32 {
    let args: Vec<String> = env::args().collect();
    let prog = args.get(0).map(String::as_str).unwrap_or("./executable");
    let mut rest: Vec<String> = args.iter().skip(1).cloned().collect();

    if rest.is_empty() {
        if Path::new("Doxyfile").exists() {
            return generate_docs("Doxyfile", false);
        }
        eprintln!("error: Doxyfile not found and no input file specified!");
        print_help(prog);
        return 1;
    }

    if rest.iter().any(|a| a == "-h" || a == "-?" || a == "--help") {
        print_help(prog);
        return 0;
    }
    if rest[0] == "-v" || rest[0] == "--version" {
        println!("{VERSION}");
        return 0;
    }
    if rest[0] == "-V" {
        println!("{VERSION}");
        println!("    with sqlite3 3.42.0.");
        return 0;
    }
    if rest[0] == "-d" && rest.len() == 1 {
        print_debug_help();
        return 0;
    }

    let mut short = false;
    let mut quiet = false;
    rest.retain(|a| {
        if a == "-s" {
            short = true;
            false
        } else if a == "-q" {
            quiet = true;
            false
        } else {
            true
        }
    });
    if rest.is_empty() {
        return generate_docs("Doxyfile", quiet);
    }

    match rest[0].as_str() {
        "-g" => {
            let name = rest.get(1).map(String::as_str).unwrap_or("Doxyfile");
            write_or_stdout(name, if short { DOXY_TEMPLATE_SHORT } else { DOXY_TEMPLATE });
            if name != "-" {
                println!("\n\nConfiguration file '{name}' created.\n\nNow edit the configuration file and enter\n\n  doxygen\n\nto generate the documentation for your project\n");
            }
            0
        }
        "-u" => {
            let name = rest.get(1).map(String::as_str).unwrap_or("Doxyfile");
            if name == "-" {
                let mut input = String::new();
                let _ = io::stdin().read_to_string(&mut input);
                let merged = merge_config(&input, if short { DOXY_TEMPLATE_SHORT } else { DOXY_TEMPLATE });
                print!("{merged}");
                return 0;
            }
            if !Path::new(name).exists() {
                eprintln!("error: configuration file {name} not found!");
                print_help(prog);
                return 1;
            }
            let input = fs::read_to_string(name).unwrap_or_default();
            let merged = merge_config(&input, if short { DOXY_TEMPLATE_SHORT } else { DOXY_TEMPLATE });
            let _ = fs::write(name, merged);
            println!("Configuration file '{name}' updated.");
            0
        }
        "-l" => {
            let name = rest.get(1).map(String::as_str).unwrap_or("DoxygenLayout.xml");
            write_or_stdout(name, LAYOUT_TEMPLATE);
            0
        }
        "-e" => {
            if rest.get(1).map(String::as_str) != Some("rtf") || rest.len() < 3 {
                eprintln!("error: option -e expects 'rtf' and a file name");
                return 1;
            }
            write_or_stdout(&rest[2], RTF_EXT);
            0
        }
        "-f" => {
            if rest.get(1).map(String::as_str) != Some("emoji") || rest.len() < 3 {
                eprintln!("error: option -f expects 'emoji' and a file name");
                return 1;
            }
            write_or_stdout(&rest[2], EMOJIS);
            0
        }
        "-w" => write_template_files(&rest),
        "-x" | "-x_noenv" => {
            let name = rest.get(1).map(String::as_str).unwrap_or("Doxyfile");
            if !Path::new(name).exists() {
                eprintln!("error: Doxyfile not found and no input file specified!");
                print_help(prog);
                return 1;
            }
            let cfg = fs::read_to_string(name).unwrap_or_default();
            print_config_diff(&cfg);
            0
        }
        a if a.starts_with("-d") => generate_docs(rest.last().map(String::as_str).unwrap_or("Doxyfile"), quiet),
        path if path.starts_with('-') => {
            eprintln!("error: Unknown option '{path}'");
            print_help(prog);
            1
        }
        path => generate_docs(path, quiet),
    }
}

fn print_help(prog: &str) {
    println!("Doxygen version {VERSION}");
    println!("Copyright Dimitri van Heesch 1997-2025\n");
    println!("You can use Doxygen in a number of ways:\n");
    println!("1) Use Doxygen to generate a template configuration file*:");
    println!("    {prog} [-s] -g [configName]\n");
    println!("2) Use Doxygen to update an old configuration file*:");
    println!("    {prog} [-s] -u [configName]\n");
    println!("3) Use Doxygen to generate documentation using an existing configuration file*:");
    println!("    {prog} [configName]\n");
    println!("4) Use Doxygen to generate a template file controlling the layout of the");
    println!("   generated documentation:");
    println!("    {prog} -l [layoutFileName]\n");
    println!("    In case layoutFileName is omitted DoxygenLayout.xml will be used as filename.");
    println!("    If - is used for layoutFileName Doxygen will write to standard output.\n");
    println!("5) Use Doxygen to generate a template style sheet file for RTF, HTML or Latex.");
    println!("    RTF:        {prog} -w rtf styleSheetFile");
    println!("    HTML:       {prog} -w html headerFile footerFile styleSheetFile [configFile]");
    println!("    LaTeX:      {prog} -w latex headerFile footerFile styleSheetFile [configFile]\n");
    println!("6) Use Doxygen to generate a rtf extensions file");
    println!("    {prog} -e rtf extensionsFile\n");
    println!("    If - is used for extensionsFile Doxygen will write to standard output.\n");
    println!("7) Use Doxygen to compare the used configuration file with the template configuration file");
    println!("    {prog} -x [configFile]\n");
    println!("   Use Doxygen to compare the used configuration file with the template configuration file");
    println!("   without replacing the environment variables or CMake type replacement variables");
    println!("    {prog} -x_noenv [configFile]\n");
    println!("8) Use Doxygen to show a list of built-in emojis.");
    println!("    {prog} -f emoji outputFileName\n");
    println!("    If - is used for outputFileName Doxygen will write to standard output.\n");
    println!("*) If -s is specified the comments of the configuration items in the config file will be omitted.");
    println!("   If configName is omitted 'Doxyfile' will be used as a default.");
    println!("   If - is used for configFile Doxygen will write / read the configuration to /from standard output / input.\n");
    println!("If -q is used for a Doxygen documentation run, Doxygen will see this as if QUIET=YES has been set.\n");
    println!("-v print version string, -V print extended version information");
    println!("-h,-? prints usage help information");
    println!("{prog} -d prints additional usage flags for debugging purposes");
}

fn print_debug_help() {
    println!("Developer parameters:");
    println!("  -m          dump symbol map");
    println!("  -b          making messages output unbuffered");
    println!("  -c <file>   process input file as a comment block and produce HTML output");
    println!("  -d <level>  enable a debug level, such as (multiple invocations of -d are possible):");
    for name in ["alias","cite","commentcnv","commentscan","entries","extcmd","filteroutput","formula","fortranfixed2free","layout","lex","lex:code","lex:commentcnv","lex:commentscan","lex:configimpl","lex:constexp","lex:declinfo","lex:defargs","lex:doctokenizer","lex:fortrancode","lex:fortranscanner","lex:lexcode","lex:lexscanner","lex:pre","lex:pycode","lex:pyscanner","lex:scanner","lex:sqlcode","lex:vhdlcode","lex:xml","lex:xmlcode","markdown","nolineno","plantuml","preprocessor","printtree","qhp","rtf","sections","stderr","tag","time"] {
        println!("\t{name}");
    }
}

fn write_or_stdout(name: &str, content: &str) {
    if name == "-" {
        print!("{content}");
    } else {
        let _ = fs::write(name, content);
    }
}

fn write_template_files(args: &[String]) -> i32 {
    match args.get(1).map(String::as_str) {
        Some("rtf") if args.len() >= 3 => {
            write_or_stdout(&args[2], RTF_STYLE);
            0
        }
        Some("html") if args.len() >= 5 => {
            write_or_stdout(&args[2], HTML_HEADER);
            write_or_stdout(&args[3], HTML_FOOTER);
            write_or_stdout(&args[4], HTML_STYLE);
            0
        }
        Some("latex") if args.len() >= 5 => {
            write_or_stdout(&args[2], LATEX_HEADER);
            write_or_stdout(&args[3], LATEX_FOOTER);
            write_or_stdout(&args[4], LATEX_STYLE);
            0
        }
        _ => {
            eprintln!("error: invalid -w arguments");
            1
        }
    }
}

fn merge_config(input: &str, template: &str) -> String {
    let old = parse_config(input);
    let mut out = String::new();
    for line in template.lines() {
        if let Some((key, _, _)) = parse_assignment(line) {
            if let Some(value) = old.get(&key) {
                out.push_str(&format!("{key:<23}= {value}\n"));
                continue;
            }
        }
        out.push_str(line);
        out.push('\n');
    }
    out
}

fn print_config_diff(input: &str) {
    let cfg = parse_config(input);
    let defaults = parse_config(DOXY_TEMPLATE_SHORT);
    let mut keys: Vec<_> = cfg.keys().collect();
    keys.sort();
    for key in keys {
        let val = cfg.get(key).unwrap();
        if defaults.get(key).map(String::as_str) != Some(val.as_str()) {
            println!("{key:<23}= {val}");
        }
    }
}

fn parse_config(text: &str) -> HashMap<String, String> {
    let mut map = HashMap::new();
    let mut current: Option<(String, String)> = None;
    for raw in text.lines() {
        let line = raw.trim_end();
        if let Some((k, v, append)) = parse_assignment(line) {
            if let Some((pk, pv)) = current.take() {
                commit_config_value(&mut map, pk, pv);
            }
            let existing = if append {
                map.remove(&k).unwrap_or_default()
            } else {
                String::new()
            };
            let mut combined = existing;
            if !combined.is_empty() && !v.is_empty() {
                combined.push(' ');
            }
            combined.push_str(strip_continuation(&v).trim());
            if v.trim_end().ends_with('\\') {
                current = Some((k, combined));
            } else {
                commit_config_value(&mut map, k, combined);
            }
        } else if current.is_some() {
            if let Some((_, ref mut v)) = current {
                if !v.is_empty() {
                    v.push(' ');
                }
                v.push_str(strip_continuation(line).trim());
                if !line.trim_end().ends_with('\\') {
                    if let Some((pk, pv)) = current.take() {
                        commit_config_value(&mut map, pk, pv);
                    }
                }
            }
        }
    }
    if let Some((k, v)) = current {
        commit_config_value(&mut map, k, v);
    }
    map
}

fn commit_config_value(map: &mut HashMap<String, String>, key: String, value: String) {
    map.insert(key, value.trim().to_string());
}

fn strip_continuation(s: &str) -> &str {
    s.trim_end().strip_suffix('\\').unwrap_or(s)
}

fn parse_assignment(line: &str) -> Option<(String, String, bool)> {
    let trimmed = line.trim_start();
    if trimmed.is_empty() || trimmed.starts_with('#') {
        return None;
    }
    let idx = trimmed.find('=')?;
    let left = trimmed[..idx].trim();
    let append = left.ends_with('+');
    let key = left.trim_end_matches('+').trim().to_string();
    if key.is_empty() || key.contains(' ') {
        return None;
    }
    Some((key, trimmed[idx + 1..].trim().to_string(), append))
}

fn generate_docs(config_path: &str, quiet_arg: bool) -> i32 {
    let cfg_text = if config_path == "-" {
        let mut s = String::new();
        let _ = io::stdin().read_to_string(&mut s);
        s
    } else {
        match fs::read_to_string(config_path) {
            Ok(s) => s,
            Err(_) => {
                eprintln!("error: configuration file {config_path} not found!");
                return 1;
            }
        }
    };
    let cfg = parse_config(&cfg_text);
    let quiet = quiet_arg || yes(&cfg, "QUIET");
    let out_root = cfg_value(&cfg, "OUTPUT_DIRECTORY", ".");
    let project = cfg_value(&cfg, "PROJECT_NAME", "My Project");
    let project = unquote(&project);
    let html_enabled = !no(&cfg, "GENERATE_HTML");
    let latex_enabled = yes_default(&cfg, "GENERATE_LATEX", true);
    let rtf_enabled = yes(&cfg, "GENERATE_RTF");
    let man_enabled = yes(&cfg, "GENERATE_MAN");
    let xml_enabled = yes(&cfg, "GENERATE_XML");
    let inputs = collect_inputs(&cfg);
    let symbols = extract_symbols(&inputs);

    if html_enabled {
        let dir = Path::new(&out_root).join(cfg_value(&cfg, "HTML_OUTPUT", "html"));
        let _ = fs::create_dir_all(dir.join("search"));
        write_html_set(&dir, &project, &symbols, &inputs);
    }
    if latex_enabled {
        let dir = Path::new(&out_root).join(cfg_value(&cfg, "LATEX_OUTPUT", "latex"));
        let _ = fs::create_dir_all(&dir);
        let _ = fs::write(dir.join("refman.tex"), format!("\\documentclass{{article}}\n\\title{{{}}}\n\\begin{{document}}\n\\maketitle\nGenerated by Doxygen {SHORT_VERSION}.\n\\end{{document}}\n", tex_escape(&project)));
        let _ = fs::write(dir.join("Makefile"), "all:\n\t@echo 'Run pdflatex refman.tex'\n");
    }
    if rtf_enabled {
        let dir = Path::new(&out_root).join(cfg_value(&cfg, "RTF_OUTPUT", "rtf"));
        let _ = fs::create_dir_all(&dir);
        let _ = fs::write(dir.join("refman.rtf"), format!("{{\\rtf1\\ansi {project}\\par Generated by Doxygen {SHORT_VERSION}.}}\n"));
    }
    if man_enabled {
        let dir = Path::new(&out_root).join(cfg_value(&cfg, "MAN_OUTPUT", "man"));
        let _ = fs::create_dir_all(&dir);
        let _ = fs::write(dir.join("index.3"), format!(".TH \"{project}\" 3\n.SH NAME\n{project}\n"));
    }
    if xml_enabled {
        let dir = Path::new(&out_root).join(cfg_value(&cfg, "XML_OUTPUT", "xml"));
        let _ = fs::create_dir_all(&dir);
        let _ = fs::write(dir.join("index.xml"), format!("<doxygen><compound name=\"{}\"/></doxygen>\n", xml_escape(&project)));
    }
    if !quiet {
        println!("Doxygen version {VERSION}");
        println!("Searching for include files...");
        println!("Parsing files");
        println!("Generating output...");
        println!("finished...");
    }
    0
}

fn cfg_value(map: &HashMap<String, String>, key: &str, default: &str) -> String {
    map.get(key).filter(|s| !s.trim().is_empty()).cloned().unwrap_or_else(|| default.to_string())
}

fn yes(map: &HashMap<String, String>, key: &str) -> bool {
    map.get(key).map(|v| v.eq_ignore_ascii_case("YES")).unwrap_or(false)
}

fn no(map: &HashMap<String, String>, key: &str) -> bool {
    map.get(key).map(|v| v.eq_ignore_ascii_case("NO")).unwrap_or(false)
}

fn yes_default(map: &HashMap<String, String>, key: &str, default: bool) -> bool {
    map.get(key).map(|v| v.eq_ignore_ascii_case("YES")).unwrap_or(default)
}

fn unquote(s: &str) -> String {
    let t = s.trim();
    if t.len() >= 2 && t.starts_with('"') && t.ends_with('"') {
        t[1..t.len()-1].to_string()
    } else {
        t.to_string()
    }
}

fn collect_inputs(cfg: &HashMap<String, String>) -> Vec<PathBuf> {
    let input = cfg_value(cfg, "INPUT", ".");
    let recursive = yes(cfg, "RECURSIVE");
    let mut files = Vec::new();
    for token in split_words(&input) {
        let p = PathBuf::from(unquote(&token));
        collect_path(&p, recursive, &mut files);
    }
    files
}

fn split_words(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut in_quote = false;
    for ch in s.chars() {
        match ch {
            '"' => {
                in_quote = !in_quote;
                cur.push(ch);
            }
            ' ' | '\t' if !in_quote => {
                if !cur.is_empty() {
                    out.push(cur.clone());
                    cur.clear();
                }
            }
            _ => cur.push(ch),
        }
    }
    if !cur.is_empty() {
        out.push(cur);
    }
    out
}

fn collect_path(path: &Path, recursive: bool, out: &mut Vec<PathBuf>) {
    if path.is_file() {
        out.push(path.to_path_buf());
    } else if path.is_dir() {
        if let Ok(read) = fs::read_dir(path) {
            for entry in read.flatten() {
                let p = entry.path();
                if p.is_file() && is_source(&p) {
                    out.push(p);
                } else if recursive && p.is_dir() {
                    collect_path(&p, recursive, out);
                }
            }
        }
    }
}

fn is_source(p: &Path) -> bool {
    matches!(p.extension().and_then(|e| e.to_str()).unwrap_or(""),
        "c" | "cc" | "cpp" | "cxx" | "h" | "hpp" | "hh" | "java" | "py" | "rs" | "md" | "dox")
}

#[derive(Default)]
struct Symbols {
    classes: Vec<String>,
    functions: Vec<String>,
    files: Vec<String>,
}

fn extract_symbols(files: &[PathBuf]) -> Symbols {
    let mut syms = Symbols::default();
    for p in files {
        if let Some(name) = p.file_name().and_then(|s| s.to_str()) {
            syms.files.push(name.to_string());
        }
        let Ok(text) = fs::read_to_string(p) else { continue };
        for line in text.lines() {
            let t = line.trim();
            for kw in ["class ", "struct ", "interface ", "enum "] {
                if let Some(rest) = t.strip_prefix(kw) {
                    if let Some(name) = ident(rest) {
                        push_unique(&mut syms.classes, name);
                    }
                }
            }
            if (t.contains('(') && t.contains(')')) && !t.starts_with('#') && !t.starts_with("//") {
                let before = t.split('(').next().unwrap_or("").trim();
                if let Some(name) = before.split_whitespace().last().and_then(ident) {
                    if !["if","for","while","switch","catch"].contains(&name.as_str()) {
                        push_unique(&mut syms.functions, name);
                    }
                }
            }
        }
    }
    syms
}

fn ident(s: &str) -> Option<String> {
    let mut out = String::new();
    for ch in s.chars() {
        if ch.is_ascii_alphanumeric() || ch == '_' || ch == ':' {
            out.push(ch);
        } else {
            break;
        }
    }
    if out.is_empty() { None } else { Some(out.trim_matches(':').to_string()) }
}

fn push_unique(v: &mut Vec<String>, s: String) {
    if !v.contains(&s) {
        v.push(s);
    }
}

fn write_html_set(dir: &Path, project: &str, syms: &Symbols, inputs: &[PathBuf]) {
    let index = html_page(project, "Main Page", &format!("<h1>{}</h1><p>Generated by Doxygen {}.</p>", html_escape(project), SHORT_VERSION));
    let _ = fs::write(dir.join("index.html"), index);
    let _ = fs::write(dir.join("doxygen.css"), "body{font-family:Arial,sans-serif;margin:2rem}.contents{max-width:70rem}.title{font-weight:bold}code{background:#f3f3f3;padding:2px 4px}\n");
    for asset in ["tabs.css","navtree.css","search/search.css","dynsections.js","clipboard.js","menu.js","menudata.js","navtree.js","navtreedata.js","navtreeindex0.js","cookie.js","search/search.js","search/searchdata.js"] {
        let path = dir.join(asset);
        if let Some(parent) = path.parent() { let _ = fs::create_dir_all(parent); }
        let _ = fs::write(path, "");
    }
    let files_list = syms.files.iter().map(|f| format!("<li>{}</li>", html_escape(f))).collect::<Vec<_>>().join("\n");
    let classes_list = syms.classes.iter().map(|c| format!("<li><a href=\"class{}.html\">{}</a></li>", sanitize(c), html_escape(c))).collect::<Vec<_>>().join("\n");
    let funcs_list = syms.functions.iter().map(|f| format!("<li>{}</li>", html_escape(f))).collect::<Vec<_>>().join("\n");
    let _ = fs::write(dir.join("files.html"), html_page(project, "File List", &format!("<h1>File List</h1><ul>{files_list}</ul>")));
    let _ = fs::write(dir.join("classes.html"), html_page(project, "Class List", &format!("<h1>Class List</h1><ul>{classes_list}</ul>")));
    let _ = fs::write(dir.join("annotated.html"), html_page(project, "Class List", &format!("<h1>Class List</h1><ul>{classes_list}</ul>")));
    let _ = fs::write(dir.join("functions.html"), html_page(project, "Functions", &format!("<h1>Functions</h1><ul>{funcs_list}</ul>")));
    let _ = fs::write(dir.join("functions_func.html"), html_page(project, "Functions", &format!("<h1>Functions</h1><ul>{funcs_list}</ul>")));
    for class in &syms.classes {
        let body = format!("<h1>{}</h1><p>Class Reference</p>", html_escape(class));
        let _ = fs::write(dir.join(format!("class{}.html", sanitize(class))), html_page(project, class, &body));
    }
    for p in inputs {
        let name = p.file_name().and_then(|s| s.to_str()).unwrap_or("file");
        let stem = sanitize(&name.replace('.', "_8"));
        let src = fs::read_to_string(p).unwrap_or_default();
        let body = format!("<h1>{}</h1><pre>{}</pre>", html_escape(name), html_escape(&src));
        let _ = fs::write(dir.join(format!("{stem}_source.html")), html_page(project, name, &body));
    }
}

fn html_page(project: &str, title: &str, body: &str) -> String {
    format!("<!DOCTYPE html>\n<html lang=\"en-US\">\n<head>\n<meta name=\"generator\" content=\"Doxygen 1.17.0\"/>\n<title>{}: {}</title>\n<link href=\"doxygen.css\" rel=\"stylesheet\" type=\"text/css\" />\n</head>\n<body>\n<div id=\"titlearea\"><div id=\"projectname\">{}</div></div>\n<div class=\"contents\">\n{}\n</div>\n<!-- Generated by Doxygen 1.17.0 -->\n</body>\n</html>\n", html_escape(project), html_escape(title), html_escape(project), body)
}

fn sanitize(s: &str) -> String {
    s.chars().map(|c| if c.is_ascii_alphanumeric() { c } else { '_' }).collect()
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn xml_escape(s: &str) -> String { html_escape(s) }

fn tex_escape(s: &str) -> String {
    s.replace('\\', "\\textbackslash{}").replace('_', "\\_").replace('&', "\\&").replace('%', "\\%").replace('$', "\\$")
}
