use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::process::Command;

const VERSION: &str = "0.4.3";
const HELP: &str = "./executable: A tiny UTF-8 terminal text editor

Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.
Specify file paths to edit as a command argument or run without argument to
start to write a new text.
Help can show up with key mapping Ctrl-?.

Usage:
    ./executable [options] [FILES...]

Mappings:
    Ctrl-Q                        : Quit
    Ctrl-S                        : Save to file
    Ctrl-O                        : Open text buffer
    Ctrl-X                        : Next text buffer
    Alt-X                         : Previous text buffer
    Ctrl-P or UP                  : Move cursor up
    Ctrl-N or DOWN                : Move cursor down
    Ctrl-F or RIGHT               : Move cursor right
    Ctrl-B or LEFT                : Move cursor left
    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line
    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line
    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page
    Ctrl-] or Alt-V or PAGE UP    : Previous page
    Alt-F or Ctrl-RIGHT           : Move cursor to next word
    Alt-B or Ctrl-LEFT            : Move cursor to previous word
    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph
    Alt-P or Ctrl-UP              : Move cursor to previous paragraph
    Alt-<                         : Move cursor to top of file
    Alt->                         : Move cursor to bottom of file
    Ctrl-H or BACKSPACE           : Delete character
    Ctrl-D or DELETE              : Delete next character
    Ctrl-W                        : Delete a word
    Ctrl-J                        : Delete until head of line
    Ctrl-K                        : Delete until end of line
    Ctrl-U                        : Undo last change
    Ctrl-R                        : Redo last undo change
    Ctrl-G                        : Search text
    Ctrl-M                        : New line
    Ctrl-L                        : Refresh screen
    Ctrl-?                        : Show this help

Options:
    -v, --version       Print version
    -h, --help          Print this help
";

#[derive(Clone)]
struct Buffer {
    name: Option<String>,
    rows: Vec<String>,
    cx: usize,
    cy: usize,
    rowoff: usize,
    dirty: bool,
}

impl Buffer {
    fn new(name: Option<String>) -> Self {
        let rows = match &name {
            Some(p) => fs::read_to_string(p)
                .map(|s| {
                    let mut v: Vec<String> = s.lines().map(|l| l.to_string()).collect();
                    if v.is_empty() {
                        v.push(String::new());
                    }
                    v
                })
                .unwrap_or_else(|_| vec![String::new()]),
            None => vec![String::new()],
        };
        Self { name, rows, cx: 0, cy: 0, rowoff: 0, dirty: false }
    }

    fn insert_char(&mut self, ch: char) {
        if self.cy >= self.rows.len() {
            self.rows.push(String::new());
        }
        let idx = byte_idx(&self.rows[self.cy], self.cx);
        self.rows[self.cy].insert(idx, ch);
        self.cx += 1;
        self.dirty = true;
    }

    fn newline(&mut self) {
        let idx = byte_idx(&self.rows[self.cy], self.cx);
        let tail = self.rows[self.cy].split_off(idx);
        self.cy += 1;
        self.cx = 0;
        self.rows.insert(self.cy, tail);
        self.dirty = true;
    }

    fn backspace(&mut self) {
        if self.cx > 0 {
            let end = byte_idx(&self.rows[self.cy], self.cx);
            let start = byte_idx(&self.rows[self.cy], self.cx - 1);
            self.rows[self.cy].replace_range(start..end, "");
            self.cx -= 1;
            self.dirty = true;
        } else if self.cy > 0 {
            let cur = self.rows.remove(self.cy);
            self.cy -= 1;
            self.cx = self.rows[self.cy].chars().count();
            self.rows[self.cy].push_str(&cur);
            self.dirty = true;
        }
    }

    fn delete(&mut self) {
        if self.cx < self.rows[self.cy].chars().count() {
            let start = byte_idx(&self.rows[self.cy], self.cx);
            let end = byte_idx(&self.rows[self.cy], self.cx + 1);
            self.rows[self.cy].replace_range(start..end, "");
            self.dirty = true;
        } else if self.cy + 1 < self.rows.len() {
            let next = self.rows.remove(self.cy + 1);
            self.rows[self.cy].push_str(&next);
            self.dirty = true;
        }
    }

    fn save(&mut self) -> io::Result<()> {
        if let Some(path) = &self.name {
            let mut s = self.rows.join("\n");
            s.push('\n');
            fs::write(path, s)?;
            self.dirty = false;
        }
        Ok(())
    }
}

fn byte_idx(s: &str, chars: usize) -> usize {
    s.char_indices().nth(chars).map(|(i, _)| i).unwrap_or(s.len())
}

struct Term {
    saved: Option<String>,
}

impl Term {
    fn enter() -> Self {
        let saved = Command::new("stty").arg("-g").output().ok()
            .and_then(|o| String::from_utf8(o.stdout).ok())
            .map(|s| s.trim().to_string())
            .filter(|s| !s.is_empty());
        let _ = Command::new("stty").args(["raw", "-echo"]).status();
        print!("\x1b[?1049h\x1b[?25l");
        let _ = io::stdout().flush();
        Self { saved }
    }
}

impl Drop for Term {
    fn drop(&mut self) {
        print!("\x1b[?25h\x1b[?1049l\x1b[H");
        let _ = io::stdout().flush();
        if let Some(s) = &self.saved {
            let _ = Command::new("stty").arg(s).status();
        } else {
            let _ = Command::new("stty").arg("sane").status();
        }
    }
}

fn term_size() -> (usize, usize) {
    if let Ok(out) = Command::new("stty").arg("size").output() {
        if let Ok(s) = String::from_utf8(out.stdout) {
            let mut it = s.split_whitespace();
            if let (Some(r), Some(c)) = (it.next(), it.next()) {
                if let (Ok(r), Ok(c)) = (r.parse(), c.parse()) {
                    return (r, c);
                }
            }
        }
    }
    (24, 80)
}

fn parse_args() -> Result<Action, String> {
    let mut files = Vec::new();
    let mut help = false;
    let mut version = false;
    for arg in env::args().skip(1) {
        if arg == "--" {
            files.push(arg);
        } else if arg == "--help" {
            help = true;
        } else if arg == "--version" {
            version = true;
        } else if arg.starts_with("--") && arg.len() > 2 {
            return Err(format!("Error: Unrecognized option: '{}'. Please see --help for more details", &arg[2..]));
        } else if arg.starts_with('-') && arg.len() > 1 {
            for ch in arg[1..].chars() {
                match ch {
                    'h' => help = true,
                    'v' => version = true,
                    _ => return Err(format!("Error: Unrecognized option: '{}'. Please see --help for more details", ch)),
                }
            }
        } else {
            files.push(arg);
        }
    }
    if version {
        Ok(Action::Version)
    } else if help {
        Ok(Action::Help)
    } else {
        Ok(Action::Edit(files))
    }
}

enum Action { Help, Version, Edit(Vec<String>) }

fn draw(buffers: &[Buffer], cur: usize, message: &str, rows: usize, cols: usize) {
    let b = &buffers[cur];
    print!("\x1b[?25l\x1b[39;0m");
    let text_rows = rows.saturating_sub(2);
    for y in 0..text_rows {
        print!("\x1b[{}H", y + 1);
        let file_row = b.rowoff + y;
        if file_row < b.rows.len() {
            let mut line: String = b.rows[file_row].chars().take(cols).collect();
            line = line.replace('\t', "    ");
            print!("{}\x1b[39;0m\x1b[K", line);
        } else if b.name.is_none() && b.rows.len() == 1 && b.rows[0].is_empty() && y == text_rows / 3 {
            let welcome = format!("Kiro editor -- version {}", VERSION);
            let pad = cols.saturating_sub(welcome.len()) / 2;
            print!("{}{}\x1b[K", " ".repeat(pad), welcome);
        } else {
            print!("\x1b[37m~\x1b[39;0m\x1b[K");
        }
    }
    let name = b.name.as_deref().unwrap_or("[No Name]");
    let dirty = if b.dirty { " (modified)" } else { "" };
    let left = format!("\"{}\" - {}/{}{}", name, cur + 1, buffers.len(), dirty);
    let right = format!("plain {}/{}", b.cy + 1, b.rows.len().max(1));
    let mut status = left;
    if status.len() + right.len() < cols {
        status.push_str(&" ".repeat(cols - status.len() - right.len()));
    } else {
        status.truncate(cols);
    }
    status.push_str(&right);
    status.truncate(cols);
    print!("\x1b[{}H\x1b[7m{}\x1b[39;0m", rows.saturating_sub(1), status);
    let mut msg = message.to_string();
    msg.truncate(cols);
    print!("\x1b[{}H{}\x1b[K", rows, msg);
    let cy = (b.cy.saturating_sub(b.rowoff) + 1).min(text_rows.max(1));
    let cx = (b.cx + 1).min(cols.max(1));
    print!("\x1b[{};{}H\x1b[?25h", cy, cx);
    let _ = io::stdout().flush();
}

fn main() {
    match parse_args() {
        Ok(Action::Help) => {
            print!("{}", HELP);
        }
        Ok(Action::Version) => {
            println!("{}", VERSION);
        }
        Ok(Action::Edit(files)) => {
            if !io::stdin().is_terminal() {
                eprintln!("Error: Inappropriate ioctl for device (os error 25)");
                std::process::exit(1);
            }
            if let Err(e) = run_editor(files) {
                eprintln!("Error: {}", e);
                std::process::exit(1);
            }
        }
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(1);
        }
    }
}

fn run_editor(files: Vec<String>) -> io::Result<()> {
    let _term = Term::enter();
    let (screen_rows, screen_cols) = term_size();
    let mut buffers: Vec<Buffer> = if files.is_empty() {
        vec![Buffer::new(None)]
    } else {
        files.into_iter().map(|f| Buffer::new(Some(f))).collect()
    };
    let mut cur = 0usize;
    let mut message = "Ctrl-? for help".to_string();
    let mut quit_warn = false;
    draw(&buffers, cur, &message, screen_rows, screen_cols);
    let mut stdin = io::stdin();
    let mut byte = [0u8; 1];
    loop {
        if stdin.read(&mut byte)? == 0 {
            break;
        }
        let b = byte[0];
        match b {
            17 => {
                if buffers.iter().any(|x| x.dirty) && !quit_warn {
                    message = "At least one file has unsaved changes! Press ^Q again to quit or ^S to save".to_string();
                    quit_warn = true;
                } else {
                    break;
                }
            }
            19 => {
                match buffers[cur].save() {
                    Ok(()) => message = if buffers[cur].name.is_some() { "File saved".into() } else { "No file name".into() },
                    Err(e) => message = format!("Error writing file: {}", e),
                }
                quit_warn = false;
            }
            24 => {
                cur = (cur + 1) % buffers.len();
                quit_warn = false;
            }
            12 => {}
            1 => buffers[cur].cx = 0,
            5 => buffers[cur].cx = buffers[cur].rows[buffers[cur].cy].chars().count(),
            16 => move_up(&mut buffers[cur]),
            14 => move_down(&mut buffers[cur]),
            2 => move_left(&mut buffers[cur]),
            6 => move_right(&mut buffers[cur]),
            8 | 127 => { buffers[cur].backspace(); quit_warn = false; }
            4 => { buffers[cur].delete(); quit_warn = false; }
            10 | 13 => { buffers[cur].newline(); quit_warn = false; }
            27 => read_escape(&mut stdin, &mut buffers, &mut cur),
            31 => message = HELP.lines().take(18).collect::<Vec<_>>().join(" | "),
            32..=126 => { buffers[cur].insert_char(b as char); quit_warn = false; }
            128..=255 => {
                let mut buf = vec![b];
                while let Ok(n) = stdin.read(&mut byte) {
                    if n == 0 { break; }
                    buf.push(byte[0]);
                    if let Ok(s) = std::str::from_utf8(&buf) {
                        for ch in s.chars() { buffers[cur].insert_char(ch); }
                        break;
                    }
                    if buf.len() >= 4 { break; }
                }
                quit_warn = false;
            }
            _ => {}
        }
        clamp(&mut buffers[cur], screen_rows.saturating_sub(2));
        draw(&buffers, cur, &message, screen_rows, screen_cols);
    }
    Ok(())
}

fn read_escape(stdin: &mut io::Stdin, buffers: &mut [Buffer], cur: &mut usize) {
    let mut seq = [0u8; 3];
    let n = stdin.read(&mut seq).unwrap_or(0);
    let b = &mut buffers[*cur];
    if n == 0 { return; }
    if seq[0] == b'[' {
        match seq[1] {
            b'A' => move_up(b),
            b'B' => move_down(b),
            b'C' => move_right(b),
            b'D' => move_left(b),
            b'H' => b.cx = 0,
            b'F' => b.cx = b.rows[b.cy].chars().count(),
            b'5' => b.rowoff = b.rowoff.saturating_sub(20),
            b'6' => b.rowoff += 20,
            b'3' => b.delete(),
            _ => {}
        }
    } else {
        match seq[0] {
            b'x' | b'X' => {
                if !buffers.is_empty() {
                    *cur = (*cur + buffers.len() - 1) % buffers.len();
                }
            }
            b'<' => {
                b.cy = 0;
                b.cx = 0;
            }
            b'>' => {
                b.cy = b.rows.len().saturating_sub(1);
                b.cx = b.rows[b.cy].chars().count();
            }
            _ => {}
        }
    }
}

fn move_up(b: &mut Buffer) {
    if b.cy > 0 { b.cy -= 1; }
    b.cx = b.cx.min(b.rows[b.cy].chars().count());
}
fn move_down(b: &mut Buffer) {
    if b.cy + 1 < b.rows.len() { b.cy += 1; }
    b.cx = b.cx.min(b.rows[b.cy].chars().count());
}
fn move_left(b: &mut Buffer) {
    if b.cx > 0 {
        b.cx -= 1;
    } else if b.cy > 0 {
        b.cy -= 1;
        b.cx = b.rows[b.cy].chars().count();
    }
}
fn move_right(b: &mut Buffer) {
    if b.cx < b.rows[b.cy].chars().count() {
        b.cx += 1;
    } else if b.cy + 1 < b.rows.len() {
        b.cy += 1;
        b.cx = 0;
    }
}
fn clamp(b: &mut Buffer, text_rows: usize) {
    if b.cy < b.rowoff {
        b.rowoff = b.cy;
    }
    if b.cy >= b.rowoff + text_rows {
        b.rowoff = b.cy.saturating_sub(text_rows.saturating_sub(1));
    }
}
