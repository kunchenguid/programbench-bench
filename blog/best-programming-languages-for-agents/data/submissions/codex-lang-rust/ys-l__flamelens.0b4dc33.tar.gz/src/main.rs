use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::process;
use std::thread;
use std::time::Duration;

const HELP: &str = "Usage: executable [OPTIONS] [FILENAME]

Arguments:
  [FILENAME]  Profile data filename

Options:
      --sorted   Whether to sort the stacks by time spent
      --echo     Print data to stdout on exit. Useful when piping to other tools
      --debug    Show debug info
  -h, --help     Print help
  -V, --version  Print version
";

#[derive(Default)]
struct Args {
    sorted: bool,
    echo: bool,
    debug: bool,
    filename: Option<String>,
}

fn main() {
    let args = parse_args();

    let data = match args.filename.as_deref() {
        Some(path) => fs::read_to_string(path).unwrap_or_else(|e| {
            eprintln!();
            eprintln!(
                "thread 'main' ({}) panicked at src/main.rs:44:47:",
                process::id()
            );
            eprintln!("Could not read file: {:?}", e);
            eprintln!("note: run with `RUST_BACKTRACE=1` environment variable to display a backtrace");
            process::exit(101);
        }),
        None => {
            let mut s = String::new();
            let _ = io::stdin().read_to_string(&mut s);
            s
        }
    };

    if args.echo {
        println!("{}", data);
    }

    if io::stdin().is_terminal() && io::stdout().is_terminal() {
        run_tui(&data, args);
    } else {
        eprintln!(
            "Error: Os {{ code: 11, kind: WouldBlock, message: \"Resource temporarily unavailable\" }}"
        );
        process::exit(1);
    }
}

fn parse_args() -> Args {
    let mut parsed = Args::default();
    let mut positional = Vec::new();
    let mut after_dashdash = false;

    let args: Vec<String> = env::args().skip(1).collect();
    for arg in args {
        if after_dashdash {
            positional.push(arg);
            continue;
        }

        match arg.as_str() {
            "-h" | "--help" => {
                print!("{}", HELP);
                process::exit(0);
            }
            "-V" | "--version" => {
                println!("flamelens 0.3.1");
                process::exit(0);
            }
            "--sorted" => parsed.sorted = true,
            "--echo" => parsed.echo = true,
            "--debug" => parsed.debug = true,
            "--" => after_dashdash = true,
            _ if arg == "--sorted=false" => flag_value_error("--sorted", "false"),
            _ if arg == "--echo=1" => flag_value_error("--echo", "1"),
            _ if arg.starts_with("--sorted=") => {
                flag_value_error("--sorted", arg.split_once('=').unwrap().1)
            }
            _ if arg.starts_with("--echo=") => {
                flag_value_error("--echo", arg.split_once('=').unwrap().1)
            }
            _ if arg.starts_with("--debug=") => {
                flag_value_error("--debug", arg.split_once('=').unwrap().1)
            }
            _ if arg.starts_with('-') => unexpected(&arg, positional.is_empty()),
            _ => positional.push(arg),
        }
    }

    if positional.len() > 1 {
        unexpected(&positional[1], false);
    }
    parsed.filename = positional.into_iter().next();
    parsed
}

fn flag_value_error(flag: &str, value: &str) -> ! {
    eprintln!(
        "error: unexpected value '{}' for '{}' found; no more were expected",
        value, flag
    );
    eprintln!();
    eprintln!("Usage: executable {} [FILENAME]", flag);
    eprintln!();
    eprintln!("For more information, try '--help'.");
    process::exit(2);
}

fn unexpected(arg: &str, show_tip: bool) -> ! {
    eprintln!("error: unexpected argument '{}' found", arg);
    if show_tip && arg.starts_with('-') {
        eprintln!();
        eprintln!("  tip: to pass '{}' as a value, use '-- {}'", arg, arg);
    }
    eprintln!();
    eprintln!("Usage: executable [OPTIONS] [FILENAME]");
    eprintln!();
    eprintln!("For more information, try '--help'.");
    process::exit(2);
}

fn run_tui(data: &str, args: Args) -> ! {
    let mut stdout = io::stdout();
    let _ = write!(stdout, "\x1b[?1049h\x1b[?25l\x1b[2J");
    let _ = draw(&mut stdout, data, args.sorted, args.debug);
    let _ = stdout.flush();

    let mut input = [0_u8; 1];
    loop {
        match io::stdin().read(&mut input) {
            Ok(1) if input[0] == b'q' || input[0] == 3 => {
                let _ = write!(stdout, "\x1b[?25h\x1b[?1049l");
                let _ = stdout.flush();
                process::exit(0);
            }
            Ok(_) => {}
            Err(_) => {}
        }
        thread::sleep(Duration::from_millis(50));
    }
}

fn draw<W: Write>(out: &mut W, data: &str, sorted: bool, debug: bool) -> io::Result<()> {
    let total = data
        .lines()
        .filter_map(|line| line.rsplit_once(' '))
        .filter_map(|(_, n)| n.trim().parse::<u64>().ok())
        .sum::<u64>();
    write!(out, "\x1b[H")?;
    writeln!(out, "flamelens")?;
    if debug {
        writeln!(out, "debug: true sorted: {}", sorted)?;
    }
    writeln!(out, "total: {}", total)?;
    for line in data.lines().take(20) {
        writeln!(out, "{}", line)?;
    }
    Ok(())
}
