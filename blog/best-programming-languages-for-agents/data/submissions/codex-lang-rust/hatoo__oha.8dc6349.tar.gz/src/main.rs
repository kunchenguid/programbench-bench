use serde::Serialize;
use std::collections::BTreeMap;
use std::fs;
use std::io::{Read, Write};
use std::net::{TcpStream, ToSocketAddrs};
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};
use url::Url;

const ABOUT: &str =
    "Ohayou(おはよう), HTTP load generator, inspired by rakyll/hey with tui animation.";

#[derive(Clone, Copy, Debug)]
enum OutputFormat {
    Text,
    Json,
    Csv,
    Quiet,
}

#[derive(Clone, Copy, Debug)]
enum TimeUnit {
    Ns,
    Us,
    Ms,
    S,
    M,
    H,
}

#[derive(Debug)]
struct Opt {
    n_requests: usize,
    n_connections: usize,
    _h2_parallel: usize,
    duration: Option<Duration>,
    _wait: bool,
    qps: Option<f64>,
    burst_delay: Option<Duration>,
    burst_rate: usize,
    rand_regex_url: bool,
    urls_from_file: bool,
    _max_repeat: usize,
    dump_urls: Option<usize>,
    _latency_correction: bool,
    _no_tui: bool,
    _fps: usize,
    method: String,
    headers: Vec<String>,
    _proxy_headers: Vec<String>,
    timeout: Option<Duration>,
    connect_timeout: Duration,
    accept: Option<String>,
    body_string: Option<String>,
    body_path: Option<PathBuf>,
    body_path_lines: Option<PathBuf>,
    forms: Vec<String>,
    content_type: Option<String>,
    basic_auth: Option<String>,
    _aws_session: Option<String>,
    _aws_sigv4: Option<String>,
    _proxy: Option<String>,
    _proxy_http_version: Option<String>,
    _proxy_http2: bool,
    _http_version: Option<String>,
    _http2: bool,
    host_header: Option<String>,
    _disable_compression: bool,
    _redirect: usize,
    disable_keepalive: bool,
    _no_pre_lookup: bool,
    _ipv6: bool,
    _ipv4: bool,
    _cacert: Option<String>,
    _cert: Option<String>,
    _key: Option<String>,
    _insecure: bool,
    _connect_to: Vec<String>,
    _no_color: bool,
    _unix_socket: Option<String>,
    _stats_success_breakdown: bool,
    _db_url: Option<String>,
    debug: bool,
    output: Option<PathBuf>,
    output_format: OutputFormat,
    time_unit: Option<TimeUnit>,
    url: String,
}

#[derive(Clone)]
struct RequestConfig {
    method: String,
    headers: Vec<(String, String)>,
    body: Vec<u8>,
    timeout: Option<Duration>,
    connect_timeout: Duration,
    disable_keepalive: bool,
    host_header: Option<String>,
}

#[derive(Clone, Debug)]
struct Sample {
    start: f64,
    dns: f64,
    dial: f64,
    response_delay: f64,
    duration: f64,
    bytes: usize,
    status: Option<u16>,
    error: Option<String>,
}

#[derive(Serialize)]
struct JsonOut {
    summary: JsonSummary,
    #[serde(rename = "responseTimeHistogram")]
    histogram: BTreeMap<String, usize>,
    #[serde(rename = "latencyPercentiles")]
    percentiles: JsonPercentiles,
    rps: JsonRps,
    details: JsonDetails,
    #[serde(rename = "statusCodeDistribution")]
    status: BTreeMap<String, usize>,
    #[serde(rename = "errorDistribution")]
    errors: BTreeMap<String, usize>,
}

#[derive(Serialize)]
struct JsonSummary {
    #[serde(rename = "successRate")]
    success_rate: f64,
    total: f64,
    slowest: Option<f64>,
    fastest: Option<f64>,
    average: Option<f64>,
    #[serde(rename = "requestsPerSec")]
    requests_per_sec: f64,
    #[serde(rename = "totalData")]
    total_data: usize,
    #[serde(rename = "sizePerRequest")]
    size_per_request: Option<f64>,
    #[serde(rename = "sizePerSec")]
    size_per_sec: f64,
}

#[derive(Serialize)]
struct JsonPercentiles {
    p10: Option<f64>,
    p25: Option<f64>,
    p50: Option<f64>,
    p75: Option<f64>,
    p90: Option<f64>,
    p95: Option<f64>,
    p99: Option<f64>,
    #[serde(rename = "p99.9")]
    p999: Option<f64>,
    #[serde(rename = "p99.99")]
    p9999: Option<f64>,
}

#[derive(Serialize)]
struct JsonRps {
    mean: Option<f64>,
    stddev: Option<f64>,
    max: Option<f64>,
    min: Option<f64>,
    percentiles: JsonPercentiles,
}

#[derive(Serialize)]
struct JsonDetails {
    #[serde(rename = "DNSDialup")]
    dns_dialup: JsonTriplet,
    #[serde(rename = "DNSLookup")]
    dns_lookup: JsonTriplet,
}

#[derive(Serialize)]
struct JsonTriplet {
    average: Option<f64>,
    fastest: Option<f64>,
    slowest: Option<f64>,
}

fn main() {
    let opt = match parse_args(std::env::args().skip(1).collect()) {
        Ok(Some(opt)) => opt,
        Ok(None) => return,
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(2);
        }
    };
    if let Err(e) = run(opt) {
        eprintln!("Error: {e}");
        std::process::exit(1);
    }
}

fn parse_args(raw_args: Vec<String>) -> Result<Option<Opt>, String> {
    let mut args = Vec::new();
    for a in raw_args {
        if a.starts_with("--") {
            if let Some((k, v)) = a.split_once('=') {
                args.push(k.to_string());
                args.push(v.to_string());
                continue;
            }
        }
        args.push(a);
    }
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_help();
        return Ok(None);
    }
    if args.iter().any(|a| a == "-V" || a == "--version") {
        println!("oha 1.12.1");
        return Ok(None);
    }
    let mut opt = Opt {
        n_requests: 200,
        n_connections: 50,
        _h2_parallel: 1,
        duration: None,
        _wait: false,
        qps: None,
        burst_delay: None,
        burst_rate: 1,
        rand_regex_url: false,
        urls_from_file: false,
        _max_repeat: 4,
        dump_urls: None,
        _latency_correction: false,
        _no_tui: false,
        _fps: 16,
        method: "GET".to_string(),
        headers: Vec::new(),
        _proxy_headers: Vec::new(),
        timeout: None,
        connect_timeout: Duration::from_secs(5),
        accept: None,
        body_string: None,
        body_path: None,
        body_path_lines: None,
        forms: Vec::new(),
        content_type: None,
        basic_auth: None,
        _aws_session: None,
        _aws_sigv4: None,
        _proxy: None,
        _proxy_http_version: None,
        _proxy_http2: false,
        _http_version: None,
        _http2: false,
        host_header: None,
        _disable_compression: false,
        _redirect: 10,
        disable_keepalive: false,
        _no_pre_lookup: false,
        _ipv6: false,
        _ipv4: false,
        _cacert: None,
        _cert: None,
        _key: None,
        _insecure: false,
        _connect_to: Vec::new(),
        _no_color: false,
        _unix_socket: None,
        _stats_success_breakdown: false,
        _db_url: None,
        debug: false,
        output: None,
        output_format: OutputFormat::Text,
        time_unit: None,
        url: String::new(),
    };
    let mut positional = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let val = |i: &mut usize| -> Result<String, String> {
            *i += 1;
            args.get(*i).cloned().ok_or_else(|| format!("error: a value is required for '{a}'"))
        };
        match a.as_str() {
            "-n" => opt.n_requests = parse_count(&val(&mut i)?)?,
            "-c" => opt.n_connections = val(&mut i)?.parse::<usize>().map_err(|e| e.to_string())?,
            "-p" => opt._h2_parallel = val(&mut i)?.parse::<usize>().map_err(|e| e.to_string())?,
            "-z" => opt.duration = Some(parse_duration(&val(&mut i)?)?),
            "-w" | "--wait-ongoing-requests-after-deadline" => opt._wait = true,
            "-q" => opt.qps = Some(val(&mut i)?.parse::<f64>().map_err(|e| e.to_string())?),
            "--burst-delay" => opt.burst_delay = Some(parse_duration(&val(&mut i)?)?),
            "--burst-rate" => opt.burst_rate = val(&mut i)?.parse::<usize>().map_err(|e| e.to_string())?,
            "--rand-regex-url" => opt.rand_regex_url = true,
            "--urls-from-file" => opt.urls_from_file = true,
            "--max-repeat" => opt._max_repeat = val(&mut i)?.parse::<usize>().map_err(|e| e.to_string())?,
            "--dump-urls" => opt.dump_urls = Some(val(&mut i)?.parse::<usize>().map_err(|e| e.to_string())?),
            "--latency-correction" => opt._latency_correction = true,
            "--no-tui" => opt._no_tui = true,
            "--fps" => opt._fps = val(&mut i)?.parse::<usize>().map_err(|e| e.to_string())?,
            "-m" | "--method" => opt.method = val(&mut i)?,
            "-H" => opt.headers.push(val(&mut i)?),
            "--proxy-header" => opt._proxy_headers.push(val(&mut i)?),
            "-t" => opt.timeout = Some(parse_duration(&val(&mut i)?)?),
            "--connect-timeout" => opt.connect_timeout = parse_duration(&val(&mut i)?)?,
            "-A" => opt.accept = Some(val(&mut i)?),
            "-d" => opt.body_string = Some(val(&mut i)?),
            "-D" => opt.body_path = Some(PathBuf::from(val(&mut i)?)),
            "-Z" => opt.body_path_lines = Some(PathBuf::from(val(&mut i)?)),
            "-F" | "--form" => opt.forms.push(val(&mut i)?),
            "-T" => opt.content_type = Some(val(&mut i)?),
            "-a" => opt.basic_auth = Some(val(&mut i)?),
            "--aws-session" => opt._aws_session = Some(val(&mut i)?),
            "--aws-sigv4" => opt._aws_sigv4 = Some(val(&mut i)?),
            "-x" => opt._proxy = Some(val(&mut i)?),
            "--proxy-http-version" => opt._proxy_http_version = Some(val(&mut i)?),
            "--proxy-http2" => opt._proxy_http2 = true,
            "--http-version" => opt._http_version = Some(val(&mut i)?),
            "--http2" => opt._http2 = true,
            "--host" => opt.host_header = Some(val(&mut i)?),
            "--disable-compression" => opt._disable_compression = true,
            "-r" | "--redirect" => opt._redirect = val(&mut i)?.parse::<usize>().map_err(|e| e.to_string())?,
            "--disable-keepalive" => opt.disable_keepalive = true,
            "--no-pre-lookup" => opt._no_pre_lookup = true,
            "--ipv6" => opt._ipv6 = true,
            "--ipv4" => opt._ipv4 = true,
            "--cacert" => opt._cacert = Some(val(&mut i)?),
            "--cert" => opt._cert = Some(val(&mut i)?),
            "--key" => opt._key = Some(val(&mut i)?),
            "--insecure" => opt._insecure = true,
            "--connect-to" => opt._connect_to.push(val(&mut i)?),
            "--no-color" => opt._no_color = true,
            "--unix-socket" => opt._unix_socket = Some(val(&mut i)?),
            "--stats-success-breakdown" => opt._stats_success_breakdown = true,
            "--db-url" => opt._db_url = Some(val(&mut i)?),
            "--debug" => opt.debug = true,
            "-o" | "--output" => opt.output = Some(PathBuf::from(val(&mut i)?)),
            "--output-format" => opt.output_format = parse_output_format(&val(&mut i)?)?,
            "-u" | "--time-unit" => opt.time_unit = Some(parse_time_unit(&val(&mut i)?)?),
            _ if a.starts_with("--output-format=") => opt.output_format = parse_output_format(&a[16..])?,
            _ if a.starts_with("--") => return Err(format!("error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS] <URL>\n\nFor more information, try '--help'.")),
            _ if a.starts_with('-') => return Err(format!("error: unexpected argument '{a}' found")),
            _ => positional.push(a.clone()),
        }
        i += 1;
    }
    if positional.len() != 1 {
        return Err(format!("{ABOUT}\n\nUsage: executable [OPTIONS] <URL>\n\nArguments:\n  <URL>  Target URL or file with multiple URLs.\n\nFor more information, try '--help'."));
    }
    opt.url = positional.remove(0);
    Ok(Some(opt))
}

fn parse_output_format(s: &str) -> Result<OutputFormat, String> {
    match s {
        "text" => Ok(OutputFormat::Text),
        "json" => Ok(OutputFormat::Json),
        "csv" => Ok(OutputFormat::Csv),
        "quiet" => Ok(OutputFormat::Quiet),
        _ => Err(format!("invalid output format: {s}")),
    }
}

fn parse_time_unit(s: &str) -> Result<TimeUnit, String> {
    match s {
        "ns" => Ok(TimeUnit::Ns),
        "us" => Ok(TimeUnit::Us),
        "ms" => Ok(TimeUnit::Ms),
        "s" => Ok(TimeUnit::S),
        "m" => Ok(TimeUnit::M),
        "h" => Ok(TimeUnit::H),
        _ => Err(format!("invalid time unit: {s}")),
    }
}

fn print_help() {
    println!("{ABOUT}\n");
    println!("Usage: executable [OPTIONS] <URL>\n");
    println!("Arguments:\n  <URL>  Target URL or file with multiple URLs.\n");
    println!("Options:");
    println!("  -n <N_REQUESTS>          Number of requests to run. [default: 200]");
    println!("  -c <N_CONNECTIONS>       Number of connections to run concurrently. [default: 50]");
    println!("  -p <N_HTTP2_PARALLEL>    Number of parallel requests to send on HTTP/2. [default: 1]");
    println!("  -z <DURATION>            Duration of application to send requests.");
    println!("  -w, --wait-ongoing-requests-after-deadline");
    println!("  -q <QUERY_PER_SECOND>    Rate limit for all, in queries per second (QPS)");
    println!("      --burst-delay <BURST_DURATION>");
    println!("      --burst-rate <BURST_REQUESTS>");
    println!("      --rand-regex-url");
    println!("      --urls-from-file");
    println!("      --max-repeat <MAX_REPEAT> [default: 4]");
    println!("      --dump-urls <DUMP_URLS>");
    println!("      --latency-correction");
    println!("      --no-tui");
    println!("      --fps <FPS> [default: 16]");
    println!("  -m, --method <METHOD>    HTTP method [default: GET]");
    println!("  -H <HEADERS>             Custom HTTP header. Examples: -H \"foo: bar\"");
    println!("      --proxy-header <PROXY_HEADERS>");
    println!("  -t <TIMEOUT>             Timeout for each request.");
    println!("      --connect-timeout <CONNECT_TIMEOUT> [default: 5s]");
    println!("  -A <ACCEPT_HEADER>");
    println!("  -d <BODY_STRING>");
    println!("  -D <BODY_PATH>");
    println!("  -Z <BODY_PATH_LINES>");
    println!("  -F, --form <FORM>");
    println!("  -T <CONTENT_TYPE>");
    println!("  -a <BASIC_AUTH>");
    println!("      --http-version <HTTP_VERSION>");
    println!("      --http2");
    println!("      --host <HOST>");
    println!("  -r, --redirect <REDIRECT> [default: 10]");
    println!("      --disable-keepalive");
    println!("      --no-color");
    println!("      --debug");
    println!("  -o, --output <OUTPUT>");
    println!("      --output-format <OUTPUT_FORMAT> [default: text] [possible values: text, json, csv, quiet]");
    println!("  -u, --time-unit <TIME_UNIT> [possible values: ns, us, ms, s, m, h]");
    println!("  -h, --help               Print help");
    println!("  -V, --version            Print version");
}

fn run(opt: Opt) -> Result<(), String> {
    let urls = load_urls(&opt)?;
    if let Some(n) = opt.dump_urls {
        let mut out = String::new();
        for i in 0..n {
            out.push_str(&pick_url(&urls, i, opt.rand_regex_url));
            out.push('\n');
        }
        return write_output(&opt, out);
    }

    let body = if let Some(s) = &opt.body_string {
        s.as_bytes().to_vec()
    } else if let Some(path) = &opt.body_path {
        fs::read(path).map_err(|e| e.to_string())?
    } else if let Some(path) = &opt.body_path_lines {
        fs::read(path).map_err(|e| e.to_string())?
    } else if !opt.forms.is_empty() {
        opt.forms.join("&").into_bytes()
    } else {
        Vec::new()
    };

    let mut headers = Vec::new();
    if let Some(a) = &opt.accept {
        headers.push(("Accept".to_string(), a.clone()));
    }
    if let Some(t) = &opt.content_type {
        headers.push(("Content-Type".to_string(), t.clone()));
    }
    if let Some(auth) = &opt.basic_auth {
        headers.push(("Authorization".to_string(), format!("Basic {}", b64(auth.as_bytes()))));
    }
    for h in &opt.headers {
        if let Some((k, v)) = h.split_once(':') {
            headers.push((k.trim().to_string(), v.trim().to_string()));
        }
    }
    let cfg = RequestConfig {
        method: opt.method.clone(),
        headers,
        body,
        timeout: opt.timeout,
        connect_timeout: opt.connect_timeout,
        disable_keepalive: opt.disable_keepalive,
        host_header: opt.host_header.clone(),
    };

    if opt.debug {
        let url = pick_url(&urls, 0, opt.rand_regex_url);
        print_debug_request(&url, &cfg);
        match one_request(&url, &cfg, 0.0) {
            Ok(s) if s.error.is_none() => {}
            Ok(s) => eprintln!("Error: {}", s.error.unwrap_or_else(|| "unknown error".to_string())),
            Err(e) => eprintln!("Error: {e}"),
        }
        return Ok(());
    }

    let started = Instant::now();
    let samples = execute_load(&opt, &urls, cfg)?;
    let elapsed = started.elapsed().as_secs_f64().max(0.000001);
    let rendered = match opt.output_format {
        OutputFormat::Quiet => String::new(),
        OutputFormat::Csv => render_csv(&samples),
        OutputFormat::Json => serde_json::to_string_pretty(&make_json(&samples, elapsed)).unwrap() + "\n",
        OutputFormat::Text => render_text(&samples, elapsed, opt.time_unit),
    };
    write_output(&opt, rendered)
}

fn execute_load(opt: &Opt, urls: &[String], cfg: RequestConfig) -> Result<Vec<Sample>, String> {
    let total = if opt.duration.is_some() { usize::MAX / 2 } else { opt.n_requests };
    let counter = Arc::new(AtomicUsize::new(0));
    let samples = Arc::new(Mutex::new(Vec::new()));
    let deadline = opt.duration.map(|d| Instant::now() + d);
    let concurrency = opt.n_connections.max(1).min(total.max(1));
    let qps = opt.qps;
    let burst_delay = opt.burst_delay;
    let burst_rate = opt.burst_rate.max(1);
    let rand_regex_url = opt.rand_regex_url;

    let mut handles = Vec::new();
    for _ in 0..concurrency {
        let counter = counter.clone();
        let samples = samples.clone();
        let urls = urls.to_vec();
        let cfg = cfg.clone();
        handles.push(thread::spawn(move || {
            loop {
                if let Some(dl) = deadline {
                    if Instant::now() >= dl {
                        break;
                    }
                }
                let idx = counter.fetch_add(1, Ordering::SeqCst);
                if idx >= total {
                    break;
                }
                if let Some(rate) = qps {
                    if rate > 0.0 {
                        thread::sleep(Duration::from_secs_f64(1.0 / rate));
                    }
                } else if let Some(delay) = burst_delay {
                    if idx > 0 && idx % burst_rate == 0 {
                        thread::sleep(delay);
                    }
                }
                let url = pick_url(&urls, idx, rand_regex_url);
                let sample = one_request(&url, &cfg, now_epoch());
                let s = sample.unwrap_or_else(|e| Sample {
                    start: now_epoch(),
                    dns: 0.0,
                    dial: 0.0,
                    response_delay: 0.0,
                    duration: 0.0,
                    bytes: 0,
                    status: None,
                    error: Some(e),
                });
                samples.lock().unwrap().push(s);
            }
        }));
    }
    for h in handles {
        let _ = h.join();
    }
    let mut out = Arc::try_unwrap(samples).unwrap().into_inner().unwrap();
    out.sort_by(|a, b| a.start.partial_cmp(&b.start).unwrap_or(std::cmp::Ordering::Equal));
    Ok(out)
}

fn one_request(url_s: &str, cfg: &RequestConfig, start_epoch: f64) -> Result<Sample, String> {
    let start = Instant::now();
    let url = Url::parse(url_s).map_err(|e| e.to_string())?;
    if url.scheme() != "http" {
        return Err(format!("unsupported URL scheme: {}", url.scheme()));
    }
    let host = url.host_str().ok_or_else(|| "missing host".to_string())?;
    let port = url.port_or_known_default().unwrap_or(80);
    let addr_str = format!("{host}:{port}");
    let dns_start = Instant::now();
    let addr = addr_str
        .to_socket_addrs()
        .map_err(|e| e.to_string())?
        .next()
        .ok_or_else(|| "failed to resolve address".to_string())?;
    let dns = dns_start.elapsed().as_secs_f64();
    let dial_start = Instant::now();
    let mut stream = TcpStream::connect_timeout(&addr, cfg.connect_timeout).map_err(|e| e.to_string())?;
    let dial = dial_start.elapsed().as_secs_f64() + dns;
    if let Some(t) = cfg.timeout {
        let _ = stream.set_read_timeout(Some(t));
        let _ = stream.set_write_timeout(Some(t));
    }
    let path = {
        let mut p = url.path().to_string();
        if p.is_empty() {
            p.push('/');
        }
        if let Some(q) = url.query() {
            p.push('?');
            p.push_str(q);
        }
        p
    };
    let host_value = cfg
        .host_header
        .clone()
        .unwrap_or_else(|| if url.port().is_some() { format!("{host}:{port}") } else { host.to_string() });
    let mut req = format!(
        "{} {} HTTP/1.1\r\nHost: {}\r\nUser-Agent: oha/1.12.1\r\nAccept: */*\r\nAccept-Encoding: gzip, compress, deflate, br\r\n",
        cfg.method, path, host_value
    );
    let _ = cfg.disable_keepalive;
    req.push_str("Connection: close\r\n");
    for (k, v) in &cfg.headers {
        req.push_str(k);
        req.push_str(": ");
        req.push_str(v);
        req.push_str("\r\n");
    }
    if !cfg.body.is_empty() {
        req.push_str(&format!("Content-Length: {}\r\n", cfg.body.len()));
    }
    req.push_str("\r\n");
    stream.write_all(req.as_bytes()).map_err(|e| e.to_string())?;
    if !cfg.body.is_empty() {
        stream.write_all(&cfg.body).map_err(|e| e.to_string())?;
    }
    let mut buf = Vec::new();
    let mut first = [0u8; 1];
    let resp_start = Instant::now();
    stream.read_exact(&mut first).map_err(|e| e.to_string())?;
    let response_delay = resp_start.elapsed().as_secs_f64();
    buf.push(first[0]);
    let _ = stream.read_to_end(&mut buf);
    let duration = start.elapsed().as_secs_f64();
    let text = String::from_utf8_lossy(&buf);
    let status = text
        .lines()
        .next()
        .and_then(|line| line.split_whitespace().nth(1))
        .and_then(|s| s.parse::<u16>().ok());
    let body_start = buf.windows(4).position(|w| w == b"\r\n\r\n").map(|p| p + 4).unwrap_or(buf.len());
    let bytes = buf.len().saturating_sub(body_start);
    Ok(Sample {
        start: start_epoch,
        dns,
        dial,
        response_delay,
        duration,
        bytes,
        status,
        error: None,
    })
}

fn make_json(samples: &[Sample], elapsed: f64) -> JsonOut {
    let successes: Vec<&Sample> = samples.iter().filter(|s| s.error.is_none() && s.status.is_some()).collect();
    let durations: Vec<f64> = successes.iter().map(|s| s.duration).collect();
    let total_data: usize = successes.iter().map(|s| s.bytes).sum();
    let success_count = successes.len();
    let total_count = samples.len();
    let mut status = BTreeMap::new();
    let mut errors = BTreeMap::new();
    for s in samples {
        if let Some(code) = s.status {
            *status.entry(code.to_string()).or_insert(0) += 1;
        }
        if let Some(e) = &s.error {
            *errors.entry(e.clone()).or_insert(0) += 1;
        }
    }
    let mut histogram = BTreeMap::new();
    if durations.is_empty() {
        histogram.insert("NaN".to_string(), 0);
    } else {
        for d in &durations {
            let key = format!("{:.6}", d);
            *histogram.entry(key).or_insert(0) += 1;
        }
    }
    JsonOut {
        summary: JsonSummary {
            success_rate: if total_count == 0 { 0.0 } else { success_count as f64 / total_count as f64 },
            total: elapsed,
            slowest: max_opt(&durations),
            fastest: min_opt(&durations),
            average: avg_opt(&durations),
            requests_per_sec: total_count as f64 / elapsed,
            total_data,
            size_per_request: if success_count == 0 { None } else { Some(total_data as f64 / success_count as f64) },
            size_per_sec: total_data as f64 / elapsed,
        },
        histogram,
        percentiles: percentiles(&durations),
        rps: JsonRps {
            mean: None,
            stddev: None,
            max: None,
            min: None,
            percentiles: percentiles(&[]),
        },
        details: JsonDetails {
            dns_dialup: triplet(&successes.iter().map(|s| s.dial).collect::<Vec<_>>()),
            dns_lookup: triplet(&successes.iter().map(|s| s.dns).collect::<Vec<_>>()),
        },
        status,
        errors,
    }
}

fn render_csv(samples: &[Sample]) -> String {
    let mut out = String::from("request-start,DNS,DNS+dialup,Response-delay,request-duration,bytes,status\n");
    for s in samples {
        if s.error.is_none() {
            out.push_str(&format!(
                "{:.9},{:.9},{:.9},{:.9},{:.9},{},{}\n",
                s.start,
                s.dns,
                s.dial,
                s.response_delay,
                s.duration,
                s.bytes,
                s.status.map(|v| v.to_string()).unwrap_or_default()
            ));
        }
    }
    out
}

fn render_text(samples: &[Sample], elapsed: f64, unit: Option<TimeUnit>) -> String {
    let json = make_json(samples, elapsed);
    let unit = unit.unwrap_or(TimeUnit::Ms);
    let durations: Vec<f64> = samples.iter().filter(|s| s.error.is_none()).map(|s| s.duration).collect();
    let fmt_time = |v: Option<f64>| -> String {
        match v {
            Some(x) => format!("{:.4} {}", convert_time(x, unit), unit_name(unit)),
            None => format!("NaN {}", unit_name(unit)),
        }
    };
    let mut out = String::new();
    out.push_str("Summary:\n");
    out.push_str(&format!("  Success rate:\t{:.2}%\n", json.summary.success_rate * 100.0));
    out.push_str(&format!("  Total:\t{}\n", fmt_time(Some(elapsed))));
    out.push_str(&format!("  Slowest:\t{}\n", fmt_time(json.summary.slowest)));
    out.push_str(&format!("  Fastest:\t{}\n", fmt_time(json.summary.fastest)));
    out.push_str(&format!("  Average:\t{}\n", fmt_time(json.summary.average)));
    out.push_str(&format!("  Requests/sec:\t{:.4}\n\n", json.summary.requests_per_sec));
    out.push_str(&format!("  Total data:\t{} B\n", json.summary.total_data));
    match json.summary.size_per_request {
        Some(v) => out.push_str(&format!("  Size/request:\t{:.0} B\n", v)),
        None => out.push_str("  Size/request:\tNaN\n"),
    }
    out.push_str(&format!("  Size/sec:\t{:.0} B\n\n", json.summary.size_per_sec));
    out.push_str("Response time histogram:\n");
    if durations.is_empty() {
        for _ in 0..11 {
            out.push_str(&format!("    NaN {} [0] |\n", unit_name(unit)));
        }
    } else {
        for d in durations.iter().take(11) {
            out.push_str(&format!("    {:.3} {} [1] |■■\n", convert_time(*d, unit), unit_name(unit)));
        }
    }
    out.push_str("\nResponse time distribution:\n");
    let p = json.percentiles;
    for (label, val) in [
        ("10.00%", p.p10),
        ("25.00%", p.p25),
        ("50.00%", p.p50),
        ("75.00%", p.p75),
        ("90.00%", p.p90),
        ("95.00%", p.p95),
        ("99.00%", p.p99),
        ("99.90%", p.p999),
        ("99.99%", p.p9999),
    ] {
        out.push_str(&format!("  {} in {}\n", label, fmt_time(val)));
    }
    out.push_str("\n\nDetails (average, fastest, slowest):\n");
    out.push_str("  DNS+dialup:\tNaN ms, NaN ms, NaN ms\n");
    out.push_str("  DNS-lookup:\tNaN ms, NaN ms, NaN ms\n\n");
    out.push_str("Status code distribution:\n");
    for (code, n) in json.status {
        out.push_str(&format!("  [{}] {}\n", n, code));
    }
    out.push_str("\nError distribution:\n");
    for (err, n) in json.errors {
        out.push_str(&format!("  [{}] {}\n", n, err));
    }
    out
}

fn percentiles(values: &[f64]) -> JsonPercentiles {
    JsonPercentiles {
        p10: percentile(values, 0.10),
        p25: percentile(values, 0.25),
        p50: percentile(values, 0.50),
        p75: percentile(values, 0.75),
        p90: percentile(values, 0.90),
        p95: percentile(values, 0.95),
        p99: percentile(values, 0.99),
        p999: percentile(values, 0.999),
        p9999: percentile(values, 0.9999),
    }
}

fn percentile(values: &[f64], p: f64) -> Option<f64> {
    if values.is_empty() {
        return None;
    }
    let mut v = values.to_vec();
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let idx = ((v.len() - 1) as f64 * p).ceil() as usize;
    v.get(idx).copied()
}

fn triplet(values: &[f64]) -> JsonTriplet {
    JsonTriplet {
        average: avg_opt(values),
        fastest: min_opt(values),
        slowest: max_opt(values),
    }
}

fn avg_opt(values: &[f64]) -> Option<f64> {
    if values.is_empty() { None } else { Some(values.iter().sum::<f64>() / values.len() as f64) }
}

fn min_opt(values: &[f64]) -> Option<f64> {
    values.iter().copied().reduce(f64::min)
}

fn max_opt(values: &[f64]) -> Option<f64> {
    values.iter().copied().reduce(f64::max)
}

fn write_output(opt: &Opt, text: String) -> Result<(), String> {
    if let Some(path) = &opt.output {
        fs::write(path, text).map_err(|e| e.to_string())
    } else {
        print!("{text}");
        Ok(())
    }
}

fn load_urls(opt: &Opt) -> Result<Vec<String>, String> {
    if opt.urls_from_file {
        let content = fs::read_to_string(&opt.url).map_err(|e| e.to_string())?;
        let urls: Vec<String> = content.lines().map(str::trim).filter(|s| !s.is_empty()).map(str::to_string).collect();
        if urls.is_empty() {
            Err("no URLs found".to_string())
        } else {
            Ok(urls)
        }
    } else {
        Ok(vec![opt.url.clone()])
    }
}

fn pick_url(urls: &[String], idx: usize, rand_regex: bool) -> String {
    if urls.len() == 1 {
        if rand_regex { simple_rand_regex(&urls[0], idx) } else { urls[0].clone() }
    } else {
        urls[idx % urls.len()].clone()
    }
}

fn simple_rand_regex(s: &str, idx: usize) -> String {
    let mut out = String::new();
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'[' {
            if let Some(end) = s[i + 1..].find(']') {
                let cls = &s[i + 1..i + 1 + end];
                if cls == "a-z" {
                    out.push((b'a' + (idx % 26) as u8) as char);
                } else if cls == "0-9" {
                    out.push((b'0' + (idx % 10) as u8) as char);
                } else {
                    out.push_str(cls.chars().next().unwrap_or('x').to_string().as_str());
                }
                i += end + 2;
                continue;
            }
        }
        out.push(bytes[i] as char);
        i += 1;
    }
    out
}

fn parse_count(s: &str) -> Result<usize, String> {
    let lower = s.to_ascii_lowercase();
    let (num, mult) = if let Some(n) = lower.strip_suffix('k') {
        (n, 1_000usize)
    } else if let Some(n) = lower.strip_suffix('m') {
        (n, 1_000_000usize)
    } else {
        (lower.as_str(), 1usize)
    };
    num.parse::<usize>().map(|n| n * mult).map_err(|e| e.to_string())
}

fn parse_duration(s: &str) -> Result<Duration, String> {
    let lower = s.trim().to_ascii_lowercase();
    let (num, mult) = if let Some(v) = lower.strip_suffix("ms") {
        (v, 0.001)
    } else if let Some(v) = lower.strip_suffix("us") {
        (v, 0.000001)
    } else if let Some(v) = lower.strip_suffix("ns") {
        (v, 0.000000001)
    } else if let Some(v) = lower.strip_suffix('s') {
        (v, 1.0)
    } else if let Some(v) = lower.strip_suffix('m') {
        (v, 60.0)
    } else if let Some(v) = lower.strip_suffix('h') {
        (v, 3600.0)
    } else {
        (lower.as_str(), 1.0)
    };
    let n: f64 = num.parse::<f64>().map_err(|e| e.to_string())?;
    Ok(Duration::from_secs_f64(n * mult))
}

fn convert_time(seconds: f64, unit: TimeUnit) -> f64 {
    match unit {
        TimeUnit::Ns => seconds * 1e9,
        TimeUnit::Us => seconds * 1e6,
        TimeUnit::Ms => seconds * 1e3,
        TimeUnit::S => seconds,
        TimeUnit::M => seconds / 60.0,
        TimeUnit::H => seconds / 3600.0,
    }
}

fn unit_name(unit: TimeUnit) -> &'static str {
    match unit {
        TimeUnit::Ns => "ns",
        TimeUnit::Us => "us",
        TimeUnit::Ms => "ms",
        TimeUnit::S => "s",
        TimeUnit::M => "m",
        TimeUnit::H => "h",
    }
}

fn print_debug_request(url_s: &str, cfg: &RequestConfig) {
    let uri = Url::parse(url_s)
        .ok()
        .map(|u| {
            let mut p = u.path().to_string();
            if p.is_empty() {
                p.push('/');
            }
            if let Some(q) = u.query() {
                p.push('?');
                p.push_str(q);
            }
            p
        })
        .unwrap_or_else(|| "/".to_string());
    println!("Request {{");
    println!("    method: {},", cfg.method);
    println!("    uri: {},", uri);
    println!("    version: HTTP/1.1,");
    println!("    headers: {{");
    println!("        \"accept\": \"*/*\",");
    println!("        \"accept-encoding\": \"gzip, compress, deflate, br\",");
    println!("        \"user-agent\": \"oha/1.12.1\",");
    for (k, v) in &cfg.headers {
        println!("        \"{}\": \"{}\",", k.to_ascii_lowercase(), v);
    }
    println!("    }},");
    println!("    body: Full {{");
    if cfg.body.is_empty() {
        println!("        data: None,");
    } else {
        println!("        data: Some({} bytes),", cfg.body.len());
    }
    println!("    }},");
    println!("}}");
}

fn now_epoch() -> f64 {
    SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs_f64()
}

fn b64(input: &[u8]) -> String {
    const T: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::new();
    let mut i = 0;
    while i < input.len() {
        let b0 = input[i];
        let b1 = *input.get(i + 1).unwrap_or(&0);
        let b2 = *input.get(i + 2).unwrap_or(&0);
        out.push(T[(b0 >> 2) as usize] as char);
        out.push(T[(((b0 & 0b11) << 4) | (b1 >> 4)) as usize] as char);
        if i + 1 < input.len() {
            out.push(T[(((b1 & 0b1111) << 2) | (b2 >> 6)) as usize] as char);
        } else {
            out.push('=');
        }
        if i + 2 < input.len() {
            out.push(T[(b2 & 0b111111) as usize] as char);
        } else {
            out.push('=');
        }
        i += 3;
    }
    out
}
