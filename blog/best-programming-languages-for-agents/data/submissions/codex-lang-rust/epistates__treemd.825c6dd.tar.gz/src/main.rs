use std::collections::{BTreeMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::Path;
use std::process;

#[derive(Clone, Debug)]
struct Heading {
    level: usize,
    text: String,
    line: usize,
}

#[derive(Clone, Debug)]
struct CodeBlock {
    lang: String,
    content: String,
}

#[derive(Clone, Debug)]
struct Link {
    text: String,
    url: String,
    image: bool,
}

#[derive(Clone, Debug)]
struct Doc {
    text: String,
    lines: Vec<String>,
    headings: Vec<Heading>,
    codes: Vec<CodeBlock>,
    links: Vec<Link>,
    tables: Vec<Vec<Vec<String>>>,
    lists: Vec<Vec<String>>,
    blockquotes: Vec<String>,
}

#[derive(Clone, Debug)]
enum Item {
    Heading(Heading),
    Code(CodeBlock),
    Link(Link),
    Table(Vec<Vec<String>>),
    List(Vec<String>),
    Blockquote(String),
    Text(String),
    Number(i64),
    Stats,
    Levels,
    Langs,
    Types,
}

#[derive(Default)]
struct Opts {
    list: bool,
    tree: bool,
    count: bool,
    section: Option<String>,
    filter: Option<String>,
    level: Option<usize>,
    output: String,
    query: Option<String>,
    query_output: String,
    setup_completions: bool,
    files: Vec<String>,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    match run(args) {
        Ok(code) => process::exit(code),
        Err((msg, code)) => {
            eprintln!("{msg}");
            process::exit(code);
        }
    }
}

fn run(args: Vec<String>) -> Result<i32, (String, i32)> {
    if args.iter().any(|a| a == "--help") {
        print_long_help();
        return Ok(0);
    }
    if args.iter().any(|a| a == "-h") {
        print_short_help();
        return Ok(0);
    }
    if args.iter().any(|a| a == "-V" || a == "--version") {
        println!("treemd 0.5.7");
        return Ok(0);
    }
    if args.first().map(|s| s.as_str()) == Some("help") {
        print_short_help();
        return Ok(0);
    }
    if args.first().map(|s| s.as_str()) == Some("at-line") {
        if args.get(1).map(|s| s == "-h" || s == "--help").unwrap_or(false) {
            print_at_line_help();
            return Ok(0);
        }
        if args.len() != 2 {
            return Err(("error: unexpected argument found\n\nUsage: executable at-line <LINE>\n\nFor more information, try '--help'.".to_string(), 2));
        }
        let line = args[1].parse::<usize>().unwrap_or(0);
        let input = read_stdin().unwrap_or_default();
        let doc = parse_doc(&input);
        if let Some(h) = doc.headings.into_iter().filter(|h| h.line <= line).last() {
            println!("{} {}", "#".repeat(h.level), h.text);
        }
        return Ok(0);
    }

    let opts = parse_args(&args)?;
    if opts.setup_completions {
        print_completions();
        eprintln!("Error setting up completions: Could not detect shell");
        return Ok(1);
    }
    if opts.query.as_deref() == Some("__query_help__") {
        print_query_help();
        return Ok(0);
    }

    if !(opts.list || opts.tree || opts.count || opts.section.is_some() || opts.query.is_some()) {
        return Err(("Failed to enable raw mode: Cannot open /dev/tty: No such device or address (os error 6). Interactive mode requires a terminal.\nNote: When piping input, ensure you have a controlling terminal.".to_string(), 1));
    }

    let input = read_input(&opts.files)?;
    if input.trim().is_empty() {
        return Err(("Error reading input: Empty input provided".to_string(), 1));
    }
    let doc = parse_doc(&input);

    if let Some(q) = &opts.query {
        return run_query(&doc, q, &opts.query_output).map(|_| 0);
    }
    if opts.count {
        print_count(&doc);
        return Ok(0);
    }
    if let Some(section) = &opts.section {
        return extract_section(&doc, section);
    }
    let heads = filtered_headings(&doc, &opts);
    if opts.output == "json" {
        if opts.list {
            print_document_json(&doc);
        } else {
            print_headings_json(&heads);
        }
    } else if opts.output == "tree" || opts.tree {
        print_tree(&heads);
    } else {
        print_list(&heads);
    }
    Ok(0)
}

fn parse_args(args: &[String]) -> Result<Opts, (String, i32)> {
    let mut opts = Opts { output: "plain".into(), query_output: "plain".into(), ..Default::default() };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-l" | "--list" => opts.list = true,
            "--tree" => opts.tree = true,
            "--count" => opts.count = true,
            "--setup-completions" => opts.setup_completions = true,
            "--query-help" => opts.query = Some("__query_help__".into()),
            "--filter" => { i += 1; opts.filter = args.get(i).cloned(); }
            "-L" | "--level" => { i += 1; opts.level = args.get(i).and_then(|s| s.parse().ok()); }
            "-o" | "--output" => {
                i += 1;
                opts.output = args.get(i).cloned().unwrap_or_default();
                if !["plain", "json", "tree"].contains(&opts.output.as_str()) {
                    return Err((format!("error: invalid value '{}' for '--output <OUTPUT>'\n  [possible values: plain, json, tree]\n\nFor more information, try '--help'.", opts.output), 2));
                }
            }
            "-s" | "--section" => { i += 1; opts.section = args.get(i).cloned(); }
            "-q" | "--query" => { i += 1; opts.query = args.get(i).cloned(); }
            "--query-output" => { i += 1; opts.query_output = args.get(i).cloned().unwrap_or_default(); }
            "--theme" | "--color-mode" => { i += 1; }
            "--no-images" | "--images" => {}
            s if s.starts_with('-') && s != "-" => {}
            _ => opts.files.push(a.clone()),
        }
        i += 1;
    }
    Ok(opts)
}

fn read_stdin() -> io::Result<String> {
    let mut s = String::new();
    io::stdin().read_to_string(&mut s)?;
    Ok(s)
}

fn read_input(files: &[String]) -> Result<String, (String, i32)> {
    if files.is_empty() || files.iter().any(|f| f == "-") {
        return read_stdin().map_err(|e| (format!("Error reading input: I/O error: {e}"), 1));
    }
    let mut out = String::new();
    for f in files {
        let p = Path::new(f);
        if p.is_dir() {
            continue;
        }
        match fs::read_to_string(p) {
            Ok(s) => {
                if !out.is_empty() { out.push('\n'); }
                out.push_str(&s);
            }
            Err(e) => return Err((format!("Error reading input: I/O error: {e}"), 1)),
        }
    }
    Ok(out)
}

fn parse_doc(text: &str) -> Doc {
    let lines: Vec<String> = text.lines().map(|s| s.to_string()).collect();
    let mut headings = Vec::new();
    let mut codes = Vec::new();
    let mut links = Vec::new();
    let mut tables = Vec::new();
    let mut lists = Vec::new();
    let mut blockquotes = Vec::new();
    let mut in_code = false;
    let mut code_lang = String::new();
    let mut code = Vec::new();
    let mut list = Vec::new();
    let mut i = 0;
    while i < lines.len() {
        let line = &lines[i];
        let trim = line.trim_end();
        if trim.starts_with("```") || trim.starts_with("~~~") {
            if in_code {
                codes.push(CodeBlock { lang: code_lang.clone(), content: code.join("\n") });
                code.clear();
                code_lang.clear();
                in_code = false;
            } else {
                in_code = true;
                code_lang = trim[3..].trim().to_string();
            }
            i += 1;
            continue;
        }
        if in_code {
            code.push(line.clone());
            i += 1;
            continue;
        }
        if let Some((lvl, txt)) = parse_heading(trim) {
            flush_list(&mut lists, &mut list);
            headings.push(Heading { level: lvl, text: txt, line: i + 1 });
        } else if trim.trim_start().starts_with('>') {
            flush_list(&mut lists, &mut list);
            blockquotes.push(trim.trim_start().trim_start_matches('>').trim().to_string());
        } else if let Some(item) = parse_list_item(trim) {
            list.push(item);
        } else {
            flush_list(&mut lists, &mut list);
            if looks_like_table(&lines, i) {
                let mut rows = Vec::new();
                while i < lines.len() && lines[i].contains('|') && !lines[i].trim().is_empty() {
                    rows.push(split_table_row(&lines[i]));
                    i += 1;
                }
                if rows.len() >= 2 { tables.push(rows); }
                continue;
            }
        }
        parse_inline_links(trim, &mut links);
        i += 1;
    }
    flush_list(&mut lists, &mut list);
    Doc { text: text.to_string(), lines, headings, codes, links, tables, lists, blockquotes }
}

fn parse_heading(line: &str) -> Option<(usize, String)> {
    let s = line.trim_start();
    let n = s.chars().take_while(|&c| c == '#').count();
    if n == 0 || n > 6 { return None; }
    let rest = &s[n..];
    if !rest.starts_with(' ') && !rest.starts_with('\t') { return None; }
    let mut text = rest.trim().to_string();
    while text.ends_with('#') {
        text.pop();
    }
    Some((n, text.trim().to_string()))
}

fn parse_list_item(line: &str) -> Option<String> {
    let s = line.trim_start();
    if s.starts_with("- ") || s.starts_with("* ") || s.starts_with("+ ") {
        return Some(s[2..].to_string());
    }
    let dot = s.find('.')?;
    if dot > 0 && s[..dot].chars().all(|c| c.is_ascii_digit()) && s[dot+1..].starts_with(' ') {
        Some(s[dot+2..].to_string())
    } else {
        None
    }
}

fn flush_list(lists: &mut Vec<Vec<String>>, cur: &mut Vec<String>) {
    if !cur.is_empty() {
        lists.push(std::mem::take(cur));
    }
}

fn looks_like_table(lines: &[String], i: usize) -> bool {
    i + 1 < lines.len() && lines[i].contains('|') && lines[i + 1].contains('|') && lines[i + 1].contains('-')
}

fn split_table_row(line: &str) -> Vec<String> {
    line.trim().trim_matches('|').split('|').map(|c| c.trim().to_string()).collect()
}

fn parse_inline_links(line: &str, links: &mut Vec<Link>) {
    let bytes = line.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        let image = bytes[i] == b'!' && i + 1 < bytes.len() && bytes[i + 1] == b'[';
        let start = if image { i + 1 } else { i };
        if bytes[start] == b'[' {
            if let Some(close) = line[start + 1..].find(']') {
                let close = start + 1 + close;
                if line[close + 1..].starts_with('(') {
                    if let Some(end) = line[close + 2..].find(')') {
                        let end = close + 2 + end;
                        links.push(Link {
                            text: line[start + 1..close].to_string(),
                            url: line[close + 2..end].split_whitespace().next().unwrap_or("").to_string(),
                            image,
                        });
                        i = end + 1;
                        continue;
                    }
                }
            }
        }
        i += 1;
    }
}

fn filtered_headings(doc: &Doc, opts: &Opts) -> Vec<Heading> {
    doc.headings.iter().filter(|h| {
        opts.level.map(|l| h.level == l).unwrap_or(true)
            && opts.filter.as_ref().map(|f| h.text.to_lowercase().contains(&f.to_lowercase())).unwrap_or(true)
    }).cloned().collect()
}

fn print_list(heads: &[Heading]) {
    for h in heads {
        println!("{} {}", "#".repeat(h.level), h.text);
    }
}

fn print_count(doc: &Doc) {
    println!("Heading counts:");
    let mut total = 0;
    for lvl in 1..=6 {
        let c = doc.headings.iter().filter(|h| h.level == lvl).count();
        if c > 0 {
            println!("  {}: {}", "#".repeat(lvl), c);
            total += c;
        }
    }
    println!("\nTotal: {total}");
}

fn print_tree(heads: &[Heading]) {
    for (idx, h) in heads.iter().enumerate() {
        let last = !heads.iter().skip(idx + 1).any(|x| x.level == h.level)
            || {
                let parent_level = nearest_parent_level(heads, idx);
                !heads.iter().skip(idx + 1).take_while(|x| x.level > parent_level).any(|x| x.level == h.level)
            };
        let mut prefix = String::new();
        for depth in 1..h.level {
            let has_more = heads.iter().skip(idx + 1).any(|x| x.level == depth);
            prefix.push_str(if has_more { "│  " } else { "   " });
        }
        prefix.push_str(if last { "└──" } else { "├──" });
        println!("{prefix}{} {}", "#".repeat(h.level), h.text);
    }
}

fn nearest_parent_level(heads: &[Heading], idx: usize) -> usize {
    let lvl = heads[idx].level;
    heads[..idx].iter().rev().find(|h| h.level < lvl).map(|h| h.level).unwrap_or(0)
}

fn extract_section(doc: &Doc, name: &str) -> Result<i32, (String, i32)> {
    let Some((idx, h)) = doc.headings.iter().enumerate().find(|(_, h)| h.text.eq_ignore_ascii_case(name)) else {
        eprintln!("Section '{name}' not found");
        return Ok(1);
    };
    let end_line = doc.headings.iter().skip(idx + 1)
        .find(|n| n.level <= h.level)
        .map(|n| n.line - 1)
        .unwrap_or(doc.lines.len());
    let mut out = doc.lines[h.line - 1..end_line].join("\n");
    while out.ends_with('\n') || out.ends_with(' ') { out.pop(); }
    println!("{out}");
    Ok(0)
}

fn run_query(doc: &Doc, query: &str, format: &str) -> Result<(), (String, i32)> {
    if !["plain", "json", "jsonl", "md", "tree"].contains(&format) {
        return Err((format!("Error: Unknown output format: {format}"), 1));
    }
    if format == "plain" || format == "md" {
        if query.contains("| stats") {
            println!("{}", stats_lines(doc));
            return Ok(());
        }
        if query.contains("| levels") {
            println!("{}", levels_lines(doc));
            return Ok(());
        }
        if query.contains("| langs") {
            println!("{}", langs_lines(doc));
            return Ok(());
        }
    }
    let mut items = select_items(doc, query);
    apply_functions(doc, query, &mut items);
    match format {
        "json" => println!("{}", items_json(&items)),
        "jsonl" => for item in items { println!("{}", item_json(&item)); },
        "tree" => {
            print_items_tree(&items);
            println!();
        }
        _ => print_items_plain(&items),
    }
    Ok(())
}

fn select_items(doc: &Doc, query: &str) -> Vec<Item> {
    let q = query.trim();
    if q == "." { return vec![]; }
    if q.contains("| stats") { return vec![Item::Stats]; }
    if q.contains("| levels") { return vec![Item::Levels]; }
    if q.contains("| langs") { return vec![Item::Langs]; }
    if q.contains("| types") { return vec![Item::Types]; }
    if q.contains(".code") {
        let mut v: Vec<Item> = doc.codes.iter().cloned().map(Item::Code).collect();
        if bracket_filter(q, ".code").is_some() {
            v.clear();
        }
        return v;
    }
    if q.contains(".link") || q.contains(".a") {
        let mut v: Vec<Item> = doc.links.iter().filter(|l| !l.image).cloned().map(Item::Link).collect();
        if q.contains("[external]") {
            v.retain(|it| matches!(it, Item::Link(l) if l.url.starts_with("http://") || l.url.starts_with("https://")));
        }
        return v;
    }
    if q.contains(".img") {
        return Vec::new();
    }
    if q.contains(".table") { return doc.tables.iter().cloned().map(Item::Table).collect(); }
    if q.contains(".list") { return doc.lists.iter().cloned().map(Item::List).collect(); }
    if q.contains(".blockquote") { return doc.blockquotes.iter().cloned().map(Item::Blockquote).collect(); }
    let mut heads: Vec<Heading> = doc.headings.clone();
    for lvl in 1..=6 {
        if q.contains(&format!(".h{lvl}")) {
            heads.retain(|h| h.level == lvl);
            break;
        }
    }
    if q.contains(".h") || q.contains(".heading") || q.contains("[.h") {
        if let Some(f) = heading_filter(q) {
            heads.retain(|h| h.text.to_lowercase().contains(&f.to_lowercase()));
        }
        return heads.into_iter().map(Item::Heading).collect();
    }
    Vec::new()
}

fn bracket_filter(q: &str, sel: &str) -> Option<String> {
    let pos = q.find(sel)?;
    let rest = &q[pos + sel.len()..];
    if !rest.starts_with('[') { return None; }
    let end = rest.find(']')?;
    Some(rest[1..end].trim_matches('"').to_string())
}

fn heading_filter(q: &str) -> Option<String> {
    if let Some(start) = q.find("contains(") {
        let s = &q[start + 9..];
        let end = s.find(')')?;
        return Some(s[..end].trim_matches('"').to_string());
    }
    if let Some(pos) = q.find(".h") {
        let rest = &q[pos..];
        if let Some(b) = rest.find('[') {
            let s = &rest[b + 1..];
            let end = s.find(']')?;
            let f = s[..end].trim();
            if f.parse::<isize>().is_err() && !f.contains(':') {
                return Some(f.trim_matches('"').to_string());
            }
        }
    }
    None
}

fn apply_functions(doc: &Doc, query: &str, items: &mut Vec<Item>) {
    if query.contains("| text") {
        *items = items.iter().map(|it| Item::Text(match it {
            Item::Heading(h) => h.text.clone(),
            Item::Link(l) => l.text.clone(),
            Item::Code(c) => c.content.clone(),
            Item::Blockquote(s) => s.clone(),
            _ => plain_item(it),
        })).collect();
    } else if query.contains("| url") || query.contains("| href") || query.contains("| src") {
        *items = items.iter().filter_map(|it| match it {
            Item::Link(l) => Some(Item::Text(l.url.clone())),
            _ => None,
        }).collect();
    } else if query.contains("| lang") {
        *items = items.iter().filter_map(|it| match it {
            Item::Code(c) => Some(Item::Text(c.lang.clone())),
            _ => None,
        }).collect();
    } else if query.contains("| count") || query.contains("| length") || query.contains("| len") || query.contains("| size") {
        *items = vec![Item::Number(items.len() as i64)];
    }
    if let Some(n) = func_num(query, "limit").or_else(|| func_num(query, "take")) {
        items.truncate(n);
    }
    if let Some(n) = func_num(query, "skip").or_else(|| func_num(query, "drop")) {
        *items = items.iter().skip(n).cloned().collect();
    }
    if query.contains("| first") || query.contains("| head") {
        items.truncate(1);
    }
    if query.contains("| last") {
        if let Some(x) = items.last().cloned() { *items = vec![x]; }
    }
    if query.contains("| reverse") {
        items.reverse();
    }
    if query.contains("| lower") {
        *items = items.iter().map(|it| Item::Text(plain_item(it).to_lowercase())).collect();
    }
    if query.contains("| upper") {
        *items = items.iter().map(|it| Item::Text(plain_item(it).to_uppercase())).collect();
    }
    if query.contains("| trim") {
        *items = items.iter().map(|it| Item::Text(plain_item(it).trim().to_string())).collect();
    }
    if query.contains("| unique") {
        let mut seen = HashSet::new();
        items.retain(|it| seen.insert(plain_item(it)));
    }
    if query.contains("| lines") {
        *items = vec![Item::Number(doc.text.lines().count() as i64)];
    } else if query.contains("| words") {
        *items = vec![Item::Number(word_count(&doc.text) as i64)];
    } else if query.contains("| chars") {
        *items = vec![Item::Number(doc.text.chars().count() as i64)];
    }
}

fn func_num(q: &str, name: &str) -> Option<usize> {
    let pat = format!("{name}(");
    let start = q.find(&pat)?;
    let s = &q[start + pat.len()..];
    s[..s.find(')')?].trim().parse().ok()
}

fn print_items_plain(items: &[Item]) {
    for item in items {
        println!("{}", plain_item(item));
    }
}

fn print_items_tree(items: &[Item]) {
    for (i, item) in items.iter().enumerate() {
        let prefix = if i + 1 == items.len() { "└──" } else { "├──" };
        println!("{prefix}{}", plain_item(item));
    }
}

fn plain_item(item: &Item) -> String {
    match item {
        Item::Heading(h) => format!("{} {}", "#".repeat(h.level), h.text),
        Item::Code(c) => format!("```{}\n{}\n```", c.lang, c.content),
        Item::Link(l) => format!("[{}]({})", l.text, l.url),
        Item::Table(rows) => rows.iter().map(|r| format!("| {} |", r.join(" | "))).collect::<Vec<_>>().join("\n"),
        Item::List(items) => items.iter().map(|s| format!("- {s}")).collect::<Vec<_>>().join("\n"),
        Item::Blockquote(s) => format!("> {s}"),
        Item::Text(s) => s.clone(),
        Item::Number(n) => n.to_string(),
        Item::Stats => "__STATS__".to_string(),
        Item::Levels => "__LEVELS__".to_string(),
        Item::Langs => "__LANGS__".to_string(),
        Item::Types => "__TYPES__".to_string(),
    }
}

fn item_json(item: &Item) -> String {
    match item {
        Item::Heading(h) => format!("{{\"type\":\"heading\",\"level\":{},\"text\":\"{}\",\"line\":{}}}", h.level, esc(&h.text), h.line),
        Item::Code(c) => format!("{{\"type\":\"code\",\"language\":\"{}\",\"content\":\"{}\"}}", esc(&c.lang), esc(&c.content)),
        Item::Link(l) => format!("{{\"type\":\"link\",\"text\":\"{}\",\"url\":\"{}\"}}", esc(&l.text), esc(&l.url)),
        Item::Text(s) => format!("\"{}\"", esc(s)),
        Item::Number(n) => n.to_string(),
        _ => format!("\"{}\"", esc(&plain_item(item))),
    }
}

fn items_json(items: &[Item]) -> String {
    format!("[{}]", items.iter().map(item_json).collect::<Vec<_>>().join(","))
}

fn print_headings_json(heads: &[Heading]) {
    println!("[");
    for (i, h) in heads.iter().enumerate() {
        println!("  {{");
        println!("    \"level\": {},", h.level);
        println!("    \"text\": \"{}\"", esc(&h.text));
        print!("  }}");
        if i + 1 != heads.len() { println!(","); } else { println!(); }
    }
    println!("]");
}

fn print_document_json(doc: &Doc) {
    println!("{{");
    println!("  \"document\": {{");
    println!("    \"metadata\": {{");
    println!("      \"source\": null,");
    println!("      \"headingCount\": {},", doc.headings.len());
    println!("      \"maxDepth\": {},", doc.headings.iter().map(|h| h.level).max().unwrap_or(0));
    println!("      \"wordCount\": {}", word_count(&doc.text));
    println!("    }},");
    println!("    \"sections\": []");
    println!("  }}");
    println!("}}");
}

fn esc(s: &str) -> String {
    s.chars().flat_map(|c| match c {
        '"' => "\\\"".chars().collect::<Vec<_>>(),
        '\\' => "\\\\".chars().collect(),
        '\n' => "\\n".chars().collect(),
        '\r' => "\\r".chars().collect(),
        '\t' => "\\t".chars().collect(),
        c if c.is_control() => Vec::new(),
        c => vec![c],
    }).collect()
}

fn word_count(s: &str) -> usize {
    s.split_whitespace().count()
}

fn print_short_help() {
    println!("A markdown navigator with tree-based structural navigation\n\nUsage: executable [OPTIONS] [FILE]... [COMMAND]\n\nCommands:\n  at-line  Show heading at specific line number\n  help     Print this message or the help of the given subcommand(s)\n\nArguments:\n  [FILE]...  Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin\n\nOptions:\n  -l, --list                   List all headings in the document (non-interactive)\n      --tree                   Show heading tree structure with box-drawing characters (non-interactive)\n      --filter <PATTERN>       Filter headings by text pattern (case-insensitive)\n  -L, --level <LEVEL>          Show only headings at specific level (1-6)\n  -o, --output <OUTPUT>        Output format for --list and --tree modes [default: plain] [possible values: plain, json, tree]\n  -s, --section <HEADING>      Extract specific section by heading name\n      --count                  Count headings by level (shows statistics)\n      --setup-completions      Set up shell completions interactively\n      --theme <THEME>          Set theme for TUI mode\n      --color-mode <MODE>      Force color mode (auto, rgb, 256) [possible values: auto, rgb, 256]\n      --no-images              Disable image rendering in TUI mode\n      --images                 Enable image rendering in TUI mode (override config)\n  -q, --query <EXPR>           Query expression for selecting/filtering document elements\n      --query-help             Show query language documentation and examples\n      --query-output <FORMAT>  Output format for query results\n  -h, --help                   Print help (see more with '--help')\n  -V, --version                Print version");
}

fn print_long_help() {
    println!("treemd - A modern markdown viewer combining tree-based navigation with interactive TUI.\n\nLaunch without flags for interactive mode with dual-pane interface, vim-style navigation,\nsyntax highlighting, and real-time search. Use flags for CLI mode to extract, filter,\nand analyze markdown structure.\n\nUsage: executable [OPTIONS] [FILE]... [COMMAND]\n\nCommands:\n  at-line  Show heading at specific line number\n  help     Print this message or the help of the given subcommand(s)\n\nArguments:\n  [FILE]...\n          Markdown file(s) to view (.md or .markdown), directory, or '-' for stdin\n\nOptions:\n  -l, --list\n          List all headings in the document (non-interactive)\n\n      --tree\n          Show heading tree structure with box-drawing characters (non-interactive)\n\n      --filter <PATTERN>\n          Filter headings by text pattern (case-insensitive)\n\n  -L, --level <LEVEL>\n          Show only headings at specific level (1-6)\n\n  -o, --output <OUTPUT>\n          Output format for --list and --tree modes\n\n          Possible values:\n          - plain: Plain text output\n          - json:  JSON output\n          - tree:  Tree format with box-drawing\n\n          [default: plain]\n\n  -s, --section <HEADING>\n          Extract specific section by heading name\n\n      --count\n          Count headings by level (shows statistics)\n\n      --setup-completions\n          Set up shell completions interactively\n\n      --theme <THEME>\n          Set theme for TUI mode\n\n      --color-mode <MODE>\n          Force color mode (auto, rgb, 256)\n\n          Possible values:\n          - auto: Automatically detect terminal capabilities\n          - rgb:  Force RGB/true color mode\n          - 256:  Force 256-color mode\n\n      --no-images\n          Disable image rendering in TUI mode\n\n      --images\n          Enable image rendering in TUI mode (override config)\n\n  -q, --query <EXPR>\n          Query expression for selecting/filtering document elements\n\n      --query-help\n          Show query language documentation and examples\n\n      --query-output <FORMAT>\n          Output format for query results\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
}

fn print_at_line_help() {
    println!("Show heading at specific line number\n\nFinds and displays the heading that appears at or before the given line number. Useful for jumping to a specific location in the document structure.\n\nUsage: executable at-line <LINE>\n\nArguments:\n  <LINE>\n          Line number in the markdown file\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')");
}

fn print_query_help() {
    println!("treemd Query Language (tql)\n\nA jq-like query language for navigating and extracting markdown structure.\n\nELEMENT SELECTORS\n    .h, .heading    All headings (any level)\n    .h1 - .h6       Headings by level\n    .code           All code blocks\n    .code[rust]     Code blocks by language\n    .link, .a       All links\n    .link[external] External links only\n    .img            All images\n    .table          All tables\n    .list           All lists\n    .blockquote     All blockquotes\n\nFILTERS & INDEXING\n    .h2[Features]       Heading containing \"Features\" (fuzzy)\n    .h2[0]              First h2\n\nPIPES\n    .h2 | text          Get heading text\n    [.h2] | count       Count all h2s\n    .code | lang        Get code block languages\n    .link | url         Get link URLs\n\nOUTPUT FORMATS (--query-output)\n    plain       Human-readable text (default)\n    json        Compact JSON\n    jsonl       Line-delimited JSON\n    md          Raw markdown\n    tree        Tree structure");
}

fn print_completions() {
    println!("Shell Completion Setup Instructions\n\nAdd the appropriate line to your shell config:\n\nBash (~/.bashrc):\n  source <(COMPLETE=bash treemd)\n\nZsh (~/.zshrc):\n  source <(COMPLETE=zsh treemd)\n\nFish (~/.config/fish/config.fish):\n  COMPLETE=fish treemd | source\n\nAfter adding the line, restart your shell or source the config file.");
}

fn stats_lines(doc: &Doc) -> String {
    format!("headings: {}\ncode_blocks: {}\nlinks: {}\nimages: {}\ntables: {}\nlists: {}\nwords: {}",
        doc.headings.len(),
        doc.codes.len(),
        doc.links.iter().filter(|l| !l.image).count(),
        0,
        doc.tables.len(),
        doc.lists.len(),
        word_count(&doc.text))
}

fn levels_lines(doc: &Doc) -> String {
    (1..=6).filter_map(|l| {
        let c = doc.headings.iter().filter(|h| h.level == l).count();
        if c > 0 { Some(format!("h{l}: {c}")) } else { None }
    }).collect::<Vec<_>>().join("\n")
}

fn langs_lines(doc: &Doc) -> String {
    let mut m = BTreeMap::new();
    for c in &doc.codes { *m.entry(c.lang.clone()).or_insert(0usize) += 1; }
    m.into_iter().map(|(k,v)| format!("{k}: {v}")).collect::<Vec<_>>().join("\n")
}
