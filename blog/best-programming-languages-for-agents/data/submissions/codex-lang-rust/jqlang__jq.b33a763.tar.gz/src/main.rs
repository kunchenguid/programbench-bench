use serde_json::{json, Map, Number, Value};
use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read, Write};

#[derive(Clone, Debug)]
enum Expr {
    Id,
    Lit(Value),
    Var(String),
    Field(Box<Expr>, String, bool),
    Index(Box<Expr>, Box<Expr>, bool),
    Slice(Box<Expr>, Option<Box<Expr>>, Option<Box<Expr>>, bool),
    Iter(Box<Expr>, bool),
    Pipe(Box<Expr>, Box<Expr>),
    Comma(Box<Expr>, Box<Expr>),
    Array(Box<Expr>),
    Obj(Vec<(ObjKey, Expr)>),
    Bin(Box<Expr>, Op, Box<Expr>),
    UnaryNeg(Box<Expr>),
    Call(String, Vec<Expr>),
    If(Box<Expr>, Box<Expr>, Box<Expr>),
}

#[derive(Clone, Debug)]
enum ObjKey {
    Lit(String),
    Expr(Expr),
}

#[derive(Clone, Copy, Debug)]
enum Op {
    Add,
    Sub,
    Mul,
    Div,
    Rem,
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
    And,
    Or,
    Alt,
}

#[derive(Clone, Debug, PartialEq)]
enum Tok {
    Dot,
    Pipe,
    Comma,
    Colon,
    Lp,
    Rp,
    Lb,
    Rb,
    Lc,
    Rc,
    Q,
    Plus,
    Minus,
    Star,
    Slash,
    Alt,
    Percent,
    Eq,
    Ne,
    Lt,
    Le,
    Gt,
    Ge,
    Ident(String),
    Field(String),
    Var(String),
    Str(String),
    Num(String),
}

fn main() {
    let mut cfg = Config::default();
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        print_help();
        return;
    }
    let mut i = 0;
    let mut filter: Option<String> = None;
    let mut files = Vec::new();
    let mut positional_mode: Option<bool> = None;
    while i < args.len() {
        let a = args[i].clone();
        if positional_mode.is_some() {
            files.push(a);
            i += 1;
            continue;
        }
        if a == "--" {
            i += 1;
            if i < args.len() && filter.is_none() {
                filter = Some(args[i].clone());
                i += 1;
            }
            files.extend(args[i..].iter().cloned());
            break;
        } else if !a.starts_with('-') || a == "-" {
            if filter.is_none() {
                filter = Some(a);
            } else {
                files.push(a);
            }
            i += 1;
        } else {
            match a.as_str() {
                "-h" | "--help" => { print_help(); return; }
                "-V" | "--version" => { println!("jq-build-2b77eb1"); return; }
                "--build-configuration" => { println!("--disable-docs --with-oniguruma=builtin --enable-static --enable-all-static --prefix=/usr/local"); return; }
                "-n" | "--null-input" => cfg.null_input = true,
                "-R" | "--raw-input" => cfg.raw_input = true,
                "-s" | "--slurp" => cfg.slurp = true,
                "-c" | "--compact-output" => cfg.compact = true,
                "-r" | "--raw-output" => cfg.raw_output = true,
                "--raw-output0" => { cfg.raw_output = true; cfg.nul = true; }
                "-j" | "--join-output" => { cfg.raw_output = true; cfg.join = true; }
                "-a" | "--ascii-output" => cfg.ascii = true,
                "-S" | "--sort-keys" => cfg.sort_keys = true,
                "-C" | "--color-output" | "-M" | "--monochrome-output" | "--unbuffered" | "--seq" | "--stream" | "--stream-errors" => {}
                "--tab" => cfg.indent = Indent::Tab,
                "--indent" => { i += 1; cfg.indent = Indent::Spaces(args.get(i).and_then(|s| s.parse().ok()).unwrap_or(2).min(7)); }
                "-f" | "--from-file" => {
                    i += 1;
                    let p = args.get(i).cloned().unwrap_or_default();
                    filter = Some(fs::read_to_string(&p).unwrap_or_else(|e| die(&format!("jq: Could not open {}: {}", p, e))));
                }
                "-e" | "--exit-status" => cfg.exit_status = true,
                "--arg" => {
                    let name = args.get(i + 1).cloned().unwrap_or_default();
                    let val = args.get(i + 2).cloned().unwrap_or_default();
                    cfg.vars.insert(name, Value::String(val));
                    i += 2;
                }
                "--argjson" => {
                    let name = args.get(i + 1).cloned().unwrap_or_default();
                    let val = args.get(i + 2).cloned().unwrap_or_default();
                    cfg.vars.insert(name, serde_json::from_str(&val).unwrap_or(Value::Null));
                    i += 2;
                }
                "--rawfile" => {
                    let name = args.get(i + 1).cloned().unwrap_or_default();
                    let path = args.get(i + 2).cloned().unwrap_or_default();
                    cfg.vars.insert(name, Value::String(fs::read_to_string(path).unwrap_or_default()));
                    i += 2;
                }
                "--slurpfile" => {
                    let name = args.get(i + 1).cloned().unwrap_or_default();
                    let path = args.get(i + 2).cloned().unwrap_or_default();
                    cfg.vars.insert(name, Value::Array(parse_json_stream(&fs::read_to_string(path).unwrap_or_default()).unwrap_or_default()));
                    i += 2;
                }
                "--args" | "--jsonargs" => {
                    let json_mode = a == "--jsonargs";
                    i += 1;
                    if filter.is_none() && i < args.len() {
                        filter = Some(args[i].clone());
                        i += 1;
                    }
                    positional_mode = Some(json_mode);
                    files.extend(args[i..].iter().cloned());
                    break;
                }
                "-L" | "--library-path" => { i += 1; }
                _ if a.starts_with("--indent=") => cfg.indent = Indent::Spaces(a[9..].parse::<usize>().unwrap_or(2).min(7)),
                _ => {
                    if a.starts_with('-') && a.len() > 2 {
                        for ch in a[1..].chars() {
                            match ch {
                                'n' => cfg.null_input = true,
                                'R' => cfg.raw_input = true,
                                's' => cfg.slurp = true,
                                'c' => cfg.compact = true,
                                'r' => cfg.raw_output = true,
                                'j' => { cfg.raw_output = true; cfg.join = true; }
                                'a' => cfg.ascii = true,
                                'S' => cfg.sort_keys = true,
                                'e' => cfg.exit_status = true,
                                _ => {}
                            }
                        }
                    }
                }
            }
            i += 1;
        }
    }
    if let Some(json_mode) = positional_mode {
        let vals: Vec<Value> = files.iter().map(|s| if json_mode { serde_json::from_str(s).unwrap_or(Value::Null) } else { Value::String(s.clone()) }).collect();
        cfg.positional = vals;
        files = Vec::new();
    }
    cfg.refresh_args();
    let filter = filter.unwrap_or_else(|| ".".to_string());
    let expr = Parser::new(&filter).parse().unwrap_or_else(|e| die(&format!("jq: error: {}", e)));
    let inputs = read_inputs(&cfg, &files).unwrap_or_else(|e| die(&format!("jq: error: {}", e)));
    let mut outs = Vec::new();
    for input in inputs {
        match eval(&expr, &input, &cfg) {
            Ok(mut v) => outs.append(&mut v),
            Err(e) => die(&format!("jq: error: {}", e)),
        }
    }
    let mut last = Value::Null;
    for v in &outs {
        last = v.clone();
        print_value(v, &cfg);
    }
    if cfg.exit_status {
        if outs.is_empty() { std::process::exit(4); }
        if last == Value::Bool(false) || last == Value::Null { std::process::exit(1); }
    }
}

#[derive(Clone)]
enum Indent { Spaces(usize), Tab }
#[derive(Clone)]
struct Config {
    null_input: bool, raw_input: bool, slurp: bool, compact: bool, raw_output: bool,
    join: bool, nul: bool, ascii: bool, sort_keys: bool, exit_status: bool, indent: Indent,
    vars: BTreeMap<String, Value>, positional: Vec<Value>,
}
impl Default for Config {
    fn default() -> Self {
        let mut c = Self { null_input:false, raw_input:false, slurp:false, compact:false, raw_output:false, join:false, nul:false, ascii:false, sort_keys:false, exit_status:false, indent:Indent::Spaces(2), vars:BTreeMap::new(), positional:Vec::new() };
        c.refresh_args(); c
    }
}
impl Config {
    fn refresh_args(&mut self) {
        let mut named = Map::new();
        for (k,v) in &self.vars { named.insert(k.clone(), v.clone()); }
        self.vars.insert("ARGS".into(), json!({"positional": self.positional, "named": named}));
    }
}

fn die(msg: &str) -> ! { eprintln!("{}", msg); std::process::exit(3) }

fn read_inputs(cfg: &Config, files: &[String]) -> Result<Vec<Value>, String> {
    if cfg.null_input { return Ok(vec![Value::Null]); }
    let mut text = String::new();
    if files.is_empty() {
        io::stdin().read_to_string(&mut text).map_err(|e| e.to_string())?;
    } else {
        for f in files {
            if f == "-" { io::stdin().read_to_string(&mut text).map_err(|e| e.to_string())?; }
            else { text.push_str(&fs::read_to_string(f).map_err(|e| format!("Could not open {}: {}", f, e))?); }
        }
    }
    if cfg.raw_input {
        if cfg.slurp { Ok(vec![Value::String(text)]) }
        else { Ok(text.lines().map(|s| Value::String(s.to_string())).collect()) }
    } else {
        let vals = parse_json_stream(&text)?;
        if cfg.slurp { Ok(vec![Value::Array(vals)]) } else { Ok(vals) }
    }
}

fn parse_json_stream(s: &str) -> Result<Vec<Value>, String> {
    let de = serde_json::Deserializer::from_str(s);
    de.into_iter::<Value>().map(|r| r.map_err(|e| e.to_string())).collect()
}

fn print_help() {
    println!("jq - commandline JSON processor [version build-2b77eb1]\n\nUsage:\tjq [options] <jq filter> [file...]\n\tjq [options] --args <jq filter> [strings...]\n\tjq [options] --jsonargs <jq filter> [JSON_TEXTS...]\n\njq is a tool for processing JSON inputs, applying the given filter to\nits JSON text inputs and producing the filter's results as JSON on\nstandard output.\n\nCommand options:\n  -n, --null-input          use `null` as the single input value;\n  -R, --raw-input           read each line as string instead of JSON;\n  -s, --slurp               read all inputs into an array and use it as\n                            the single input value;\n  -c, --compact-output      compact instead of pretty-printed output;\n  -r, --raw-output          output strings without escapes and quotes;\n      --raw-output0         implies -r and output NUL after each output;\n  -j, --join-output         implies -r and output without newline after\n                            each output;\n  -a, --ascii-output        output strings by only ASCII characters\n                            using escape sequences;\n  -S, --sort-keys           sort keys of each object on output;\n  -f, --from-file           load the filter from a file;\n      --arg name value      set $name to the string value;\n      --argjson name value  set $name to the JSON value;\n      --args                consume remaining arguments as positional\n                            string values;\n      --jsonargs            consume remaining arguments as positional\n                            JSON values;\n  -e, --exit-status         set exit status code based on the output;\n  -V, --version             show the version;\n  -h, --help                show the help;");
}

struct Parser { toks: Vec<Tok>, pos: usize }
impl Parser {
    fn new(src: &str) -> Self { Self { toks: lex(src), pos: 0 } }
    fn parse(&mut self) -> Result<Expr, String> { self.parse_comma() }
    fn peek(&self) -> Option<&Tok> { self.toks.get(self.pos) }
    fn bump(&mut self) -> Option<Tok> { let t = self.toks.get(self.pos).cloned(); if t.is_some(){self.pos+=1}; t }
    fn eat(&mut self, t: &Tok) -> bool { if self.peek()==Some(t) { self.pos+=1; true } else { false } }
    fn parse_comma(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_pipe()?;
        while self.eat(&Tok::Comma) { e = Expr::Comma(Box::new(e), Box::new(self.parse_pipe()?)); }
        Ok(e)
    }
    fn parse_pipe(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_or()?;
        while self.eat(&Tok::Pipe) { e = Expr::Pipe(Box::new(e), Box::new(self.parse_or()?)); }
        Ok(e)
    }
    fn parse_or(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_and()?;
        loop {
            if matches!(self.peek(), Some(Tok::Ident(s)) if s=="or") {
                self.bump(); e = Expr::Bin(Box::new(e), Op::Or, Box::new(self.parse_and()?));
            } else if self.eat(&Tok::Alt) {
                e = Expr::Bin(Box::new(e), Op::Alt, Box::new(self.parse_and()?));
            } else { break; }
        }
        Ok(e)
    }
    fn parse_and(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_cmp()?;
        while matches!(self.peek(), Some(Tok::Ident(s)) if s=="and") { self.bump(); e = Expr::Bin(Box::new(e), Op::And, Box::new(self.parse_cmp()?)); }
        Ok(e)
    }
    fn parse_cmp(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_add()?;
        loop {
            let op = match self.peek() { Some(Tok::Eq)=>Op::Eq, Some(Tok::Ne)=>Op::Ne, Some(Tok::Lt)=>Op::Lt, Some(Tok::Le)=>Op::Le, Some(Tok::Gt)=>Op::Gt, Some(Tok::Ge)=>Op::Ge, _=>break };
            self.bump(); e = Expr::Bin(Box::new(e), op, Box::new(self.parse_add()?));
        }
        Ok(e)
    }
    fn parse_add(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_mul()?;
        loop {
            let op = match self.peek() { Some(Tok::Plus)=>Op::Add, Some(Tok::Minus)=>Op::Sub, _=>break };
            self.bump(); e = Expr::Bin(Box::new(e), op, Box::new(self.parse_mul()?));
        }
        Ok(e)
    }
    fn parse_mul(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_unary()?;
        loop {
            let op = match self.peek() { Some(Tok::Star)=>Op::Mul, Some(Tok::Slash)=>Op::Div, Some(Tok::Percent)=>Op::Rem, _=>break };
            self.bump(); e = Expr::Bin(Box::new(e), op, Box::new(self.parse_unary()?));
        }
        Ok(e)
    }
    fn parse_unary(&mut self) -> Result<Expr,String> {
        if self.eat(&Tok::Minus) { Ok(Expr::UnaryNeg(Box::new(self.parse_unary()?))) }
        else if matches!(self.peek(), Some(Tok::Ident(s)) if s=="not") { self.bump(); Ok(Expr::Call("not".into(), vec![self.parse_unary()?])) }
        else { self.parse_postfix() }
    }
    fn parse_postfix(&mut self) -> Result<Expr,String> {
        let mut e = self.parse_primary()?;
        loop {
            match self.peek() {
                Some(Tok::Dot) => {
                    self.bump();
                }
                Some(Tok::Field(k)) => {
                    let k = k.clone();
                    self.bump();
                    let opt = self.eat(&Tok::Q);
                    e = Expr::Field(Box::new(e), k, opt);
                }
                Some(Tok::Lb) => {
                    self.bump();
                    if self.eat(&Tok::Rb) {
                        let opt = self.eat(&Tok::Q);
                        e = Expr::Iter(Box::new(e), opt);
                    } else {
                        if self.eat(&Tok::Colon) {
                            let end = if self.peek() == Some(&Tok::Rb) { None } else { Some(Box::new(self.parse_pipe()?)) };
                            if !self.eat(&Tok::Rb) { return Err("expected ]".into()); }
                            let opt = self.eat(&Tok::Q);
                            e = Expr::Slice(Box::new(e), None, end, opt);
                        } else {
                            let first = self.parse_pipe()?;
                            if self.eat(&Tok::Colon) {
                                let end = if self.peek() == Some(&Tok::Rb) { None } else { Some(Box::new(self.parse_pipe()?)) };
                                if !self.eat(&Tok::Rb) { return Err("expected ]".into()); }
                                let opt = self.eat(&Tok::Q);
                                e = Expr::Slice(Box::new(e), Some(Box::new(first)), end, opt);
                            } else {
                                if !self.eat(&Tok::Rb) { return Err("expected ]".into()); }
                                let opt = self.eat(&Tok::Q);
                                e = Expr::Index(Box::new(e), Box::new(first), opt);
                            }
                        }
                    }
                }
                Some(Tok::Q) => { self.bump(); }
                _ => break,
            }
        }
        Ok(e)
    }
    fn parse_primary(&mut self) -> Result<Expr,String> {
        match self.bump() {
            Some(Tok::Dot) => {
                Ok(Expr::Id)
            }
            Some(Tok::Field(k)) => { let opt = self.eat(&Tok::Q); Ok(Expr::Field(Box::new(Expr::Id), k, opt)) }
            Some(Tok::Var(v)) => Ok(Expr::Var(v)),
            Some(Tok::Str(s)) => Ok(Expr::Lit(Value::String(s))),
            Some(Tok::Num(s)) => Ok(Expr::Lit(serde_json::from_str(&s).unwrap_or(Value::Null))),
            Some(Tok::Ident(s)) if s=="true" => Ok(Expr::Lit(Value::Bool(true))),
            Some(Tok::Ident(s)) if s=="false" => Ok(Expr::Lit(Value::Bool(false))),
            Some(Tok::Ident(s)) if s=="null" => Ok(Expr::Lit(Value::Null)),
            Some(Tok::Ident(s)) if s=="if" => {
                let c = self.parse_pipe()?;
                expect_ident(self, "then")?;
                let t = self.parse_pipe()?;
                expect_ident(self, "else")?;
                let f = self.parse_pipe()?;
                expect_ident(self, "end")?;
                Ok(Expr::If(Box::new(c), Box::new(t), Box::new(f)))
            }
            Some(Tok::Ident(name)) => {
                if self.eat(&Tok::Lp) {
                    let mut args = Vec::new();
                    if !self.eat(&Tok::Rp) {
                        loop {
                            args.push(self.parse_pipe()?);
                            if self.eat(&Tok::Rp) { break; }
                            if !self.eat(&Tok::Comma) { return Err("expected , or )".into()); }
                        }
                    }
                    Ok(Expr::Call(name, args))
                } else { Ok(Expr::Call(name, Vec::new())) }
            }
            Some(Tok::Lp) => { let e = self.parse_comma()?; if !self.eat(&Tok::Rp){return Err("expected )".into())}; Ok(e) }
            Some(Tok::Lb) => {
                if self.eat(&Tok::Rb) { Ok(Expr::Lit(Value::Array(Vec::new()))) }
                else { let e = self.parse_comma()?; if !self.eat(&Tok::Rb){return Err("expected ]".into())}; Ok(Expr::Array(Box::new(e))) }
            }
            Some(Tok::Lc) => {
                let mut pairs = Vec::new();
                if !self.eat(&Tok::Rc) {
                    loop {
                        let key = match self.bump() {
                            Some(Tok::Ident(s)) => ObjKey::Lit(s),
                            Some(Tok::Str(s)) => ObjKey::Lit(s),
                            Some(Tok::Lp) => { let e = self.parse_comma()?; if !self.eat(&Tok::Rp){return Err("expected )".into())}; ObjKey::Expr(e) }
                            other => return Err(format!("bad object key: {:?}", other)),
                        };
                        let val = if self.eat(&Tok::Colon) { self.parse_pipe()? } else {
                            match &key { ObjKey::Lit(s) => Expr::Field(Box::new(Expr::Id), s.clone(), false), ObjKey::Expr(e) => e.clone() }
                        };
                        pairs.push((key, val));
                        if self.eat(&Tok::Rc) { break; }
                        if !self.eat(&Tok::Comma) { return Err("expected , or }".into()); }
                    }
                }
                Ok(Expr::Obj(pairs))
            }
            t => Err(format!("unexpected token {:?}", t)),
        }
    }
}

fn expect_ident(p: &mut Parser, word: &str) -> Result<(),String> {
    match p.bump() { Some(Tok::Ident(s)) if s==word => Ok(()), _ => Err(format!("expected {}", word)) }
}

fn lex(src: &str) -> Vec<Tok> {
    let mut out = Vec::new();
    let mut it = src.chars().peekable();
    while let Some(c) = it.next() {
        match c {
            ' ' | '\t' | '\n' | '\r' => {}
            '#' => while it.next().is_some_and(|x| x!='\n') {},
            '.' => {
                if it.peek().is_some_and(|x| x.is_alphabetic() || *x=='_') {
                    let mut s = String::new();
                    while it.peek().is_some_and(|x| x.is_alphanumeric() || *x=='_') { s.push(it.next().unwrap()); }
                    out.push(Tok::Field(s));
                } else {
                    out.push(Tok::Dot);
                }
            }
            '|' => out.push(Tok::Pipe), ',' => out.push(Tok::Comma), ':' => out.push(Tok::Colon),
            '(' => out.push(Tok::Lp), ')' => out.push(Tok::Rp), '[' => out.push(Tok::Lb), ']' => out.push(Tok::Rb), '{' => out.push(Tok::Lc), '}' => out.push(Tok::Rc),
            '?' => out.push(Tok::Q), '+' => out.push(Tok::Plus), '*' => out.push(Tok::Star), '%' => out.push(Tok::Percent),
            '/' => { if it.peek()==Some(&'/') { it.next(); out.push(Tok::Alt); } else { out.push(Tok::Slash); } },
            '-' => if it.peek().is_some_and(|x| x.is_ascii_digit()) {
                let mut s = "-".to_string(); read_num(&mut it, &mut s); out.push(Tok::Num(s));
            } else { out.push(Tok::Minus) },
            '=' => { if it.peek()==Some(&'=') { it.next(); out.push(Tok::Eq); } },
            '!' => { if it.peek()==Some(&'=') { it.next(); out.push(Tok::Ne); } },
            '<' => { if it.peek()==Some(&'=') { it.next(); out.push(Tok::Le); } else { out.push(Tok::Lt); } },
            '>' => { if it.peek()==Some(&'=') { it.next(); out.push(Tok::Ge); } else { out.push(Tok::Gt); } },
            '$' => {
                let mut s = String::new();
                while it.peek().is_some_and(|x| x.is_alphanumeric() || *x=='_') { s.push(it.next().unwrap()); }
                out.push(Tok::Var(s));
            }
            '"' => {
                let mut raw = "\"".to_string();
                let mut esc = false;
                while let Some(ch) = it.next() {
                    raw.push(ch);
                    if esc { esc=false; continue; }
                    if ch == '\\' { esc=true; continue; }
                    if ch == '"' { break; }
                }
                out.push(Tok::Str(serde_json::from_str::<String>(&raw).unwrap_or_default()));
            }
            c if c.is_ascii_digit() => { let mut s = c.to_string(); read_num(&mut it, &mut s); out.push(Tok::Num(s)); }
            c if c.is_alphabetic() || c=='_' => {
                let mut s = c.to_string();
                while it.peek().is_some_and(|x| x.is_alphanumeric() || *x=='_') { s.push(it.next().unwrap()); }
                out.push(Tok::Ident(s));
            }
            _ => {}
        }
    }
    out
}
fn read_num<I: Iterator<Item=char>>(it: &mut std::iter::Peekable<I>, s: &mut String) {
    while it.peek().is_some_and(|x| x.is_ascii_digit() || *x=='.' || *x=='e' || *x=='E' || *x=='+' || *x=='-') { s.push(it.next().unwrap()); }
}

fn eval(e: &Expr, input: &Value, cfg: &Config) -> Result<Vec<Value>,String> {
    match e {
        Expr::Id => Ok(vec![input.clone()]),
        Expr::Lit(v) => Ok(vec![v.clone()]),
        Expr::Var(n) => Ok(vec![cfg.vars.get(n).cloned().unwrap_or(Value::Null)]),
        Expr::Field(base, key, opt) => {
            let mut out = Vec::new();
            for v in eval(base,input,cfg)? {
                match v {
                    Value::Object(m) => out.push(m.get(key).cloned().unwrap_or(Value::Null)),
                    Value::Null => out.push(Value::Null),
                    _ if *opt => {}
                    _ => out.push(Value::Null),
                }
            }
            Ok(out)
        }
        Expr::Index(base, idx, opt) => {
            let mut out = Vec::new();
            for v in eval(base,input,cfg)? {
                for ix in eval(idx,input,cfg)? {
                    match (&v, ix) {
                        (Value::Array(a), Value::Number(n)) => {
                            let mut i = n.as_i64().unwrap_or(0);
                            if i < 0 { i += a.len() as i64; }
                            out.push(if i>=0 { a.get(i as usize).cloned().unwrap_or(Value::Null) } else { Value::Null });
                        }
                        (Value::Object(m), Value::String(s)) => out.push(m.get(&s).cloned().unwrap_or(Value::Null)),
                        (Value::String(s), Value::Number(n)) => {
                            let chars: Vec<char> = s.chars().collect();
                            let mut i = n.as_i64().unwrap_or(0); if i<0 { i += chars.len() as i64; }
                            out.push(if i>=0 { chars.get(i as usize).map(|c| Value::String(c.to_string())).unwrap_or(Value::Null) } else { Value::Null });
                        }
                        (Value::Null, _) => out.push(Value::Null),
                        _ if *opt => {}
                        _ => out.push(Value::Null),
                    }
                }
            }
            Ok(out)
        }
        Expr::Iter(base, opt) => {
            let mut out = Vec::new();
            for v in eval(base,input,cfg)? {
                match v { Value::Array(a) => out.extend(a), Value::Object(m) => out.extend(m.into_values()), _ if *opt => {}, _ => {} }
            }
            Ok(out)
        }
        Expr::Slice(base, start, end, opt) => {
            let mut out = Vec::new();
            for v in eval(base,input,cfg)? {
                let st = match start { Some(e) => eval(e,input,cfg)?.into_iter().next().and_then(|v| v.as_i64()).unwrap_or(0), None => 0 };
                let en = match end { Some(e) => eval(e,input,cfg)?.into_iter().next().and_then(|v| v.as_i64()), None => None };
                match v {
                    Value::Array(a) => {
                        let len = a.len() as i64;
                        let s = norm_bound(st, len);
                        let e = norm_bound(en.unwrap_or(len), len);
                        out.push(Value::Array(if e < s { vec![] } else { a[s as usize..e as usize].to_vec() }));
                    }
                    Value::String(sv) => {
                        let chars: Vec<char> = sv.chars().collect();
                        let len = chars.len() as i64;
                        let s = norm_bound(st, len);
                        let e = norm_bound(en.unwrap_or(len), len);
                        out.push(Value::String(if e < s { String::new() } else { chars[s as usize..e as usize].iter().collect() }));
                    }
                    Value::Null => out.push(Value::Null),
                    _ if *opt => {}
                    _ => out.push(Value::Null),
                }
            }
            Ok(out)
        }
        Expr::Pipe(a,b) => {
            let mut out = Vec::new();
            for v in eval(a,input,cfg)? { out.extend(eval(b,&v,cfg)?); }
            Ok(out)
        }
        Expr::Comma(a,b) => { let mut x=eval(a,input,cfg)?; x.extend(eval(b,input,cfg)?); Ok(x) }
        Expr::Array(x) => Ok(vec![Value::Array(eval(x,input,cfg)?)]),
        Expr::Obj(pairs) => {
            let mut m = Map::new();
            for (k,vexpr) in pairs {
                let key = match k {
                    ObjKey::Lit(s) => s.clone(),
                    ObjKey::Expr(e) => eval(e,input,cfg)?.into_iter().next().map(to_key).unwrap_or_default(),
                };
                let vals = eval(vexpr,input,cfg)?;
                m.insert(key, vals.into_iter().next().unwrap_or(Value::Null));
            }
            Ok(vec![Value::Object(m)])
        }
        Expr::UnaryNeg(x) => Ok(eval(x,input,cfg)?.into_iter().map(|v| num_value(-as_f64(&v))).collect()),
        Expr::Bin(a,op,b) => {
            let av = eval(a,input,cfg)?;
            let bv = eval(b,input,cfg)?;
            let mut out = Vec::new();
            for x in &av { for y in &bv { out.push(apply_op(x,y,*op)); } }
            Ok(out)
        }
        Expr::Call(name,args) => call(name,args,input,cfg),
        Expr::If(c,t,f) => {
            let cond = eval(c,input,cfg)?.into_iter().any(|v| truthy(&v));
            if cond { eval(t,input,cfg) } else { eval(f,input,cfg) }
        }
    }
}

fn call(name: &str, args: &[Expr], input: &Value, cfg: &Config) -> Result<Vec<Value>,String> {
    let one = |e: &Expr| -> Result<Value,String> { Ok(eval(e,input,cfg)?.into_iter().next().unwrap_or(Value::Null)) };
    match name {
        "empty" => Ok(vec![]),
        "length" => Ok(vec![num_value(match input { Value::Array(a)=>a.len() as f64, Value::Object(m)=>m.len() as f64, Value::String(s)=>s.chars().count() as f64, Value::Null=>0.0, _=>as_f64(input).abs() })]),
        "type" => Ok(vec![Value::String(match input { Value::Null=>"null", Value::Bool(_)=>"boolean", Value::Number(_)=>"number", Value::String(_)=>"string", Value::Array(_)=>"array", Value::Object(_)=>"object" }.into())]),
        "keys" | "keys_unsorted" => Ok(vec![match input { Value::Object(m)=>Value::Array(m.keys().cloned().map(Value::String).collect()), Value::Array(a)=>Value::Array((0..a.len()).map(|i| num_value(i as f64)).collect()), _=>Value::Array(vec![]) }]),
        "has" => { let k=one(&args[0])?; Ok(vec![Value::Bool(match (input,k) { (Value::Object(m),Value::String(s))=>m.contains_key(&s), (Value::Array(a),Value::Number(n))=>n.as_u64().is_some_and(|i| (i as usize)<a.len()), _=>false })]) }
        "map" => {
            let mut arr = Vec::new();
            if let Some(f) = args.get(0) {
                match input { Value::Array(a)=> for v in a { arr.extend(eval(f,v,cfg)?); }, _=>{} }
            }
            Ok(vec![Value::Array(arr)])
        }
        "select" => {
            if args.get(0).map(|f| eval(f,input,cfg).unwrap_or_default().into_iter().any(|v| truthy(&v))).unwrap_or(false) { Ok(vec![input.clone()]) } else { Ok(vec![]) }
        }
        "add" => {
            if let Value::Array(a)=input { Ok(vec![a.iter().cloned().reduce(|x,y| apply_op(&x,&y,Op::Add)).unwrap_or(Value::Null)]) } else { Ok(vec![Value::Null]) }
        }
        "tostring" => Ok(vec![Value::String(match input { Value::String(s)=>s.clone(), _=>serde_json::to_string(input).unwrap_or_default() })]),
        "tonumber" => Ok(vec![match input { Value::String(s)=>serde_json::from_str(s).unwrap_or(Value::Null), Value::Number(_)=>input.clone(), _=>Value::Null }]),
        "not" => {
            let v = if args.is_empty() { input.clone() } else { one(&args[0])? };
            Ok(vec![Value::Bool(!truthy(&v))])
        }
        "range" => {
            let vals: Vec<i64> = args.iter().map(|e| one(e).unwrap_or(Value::Null).as_i64().unwrap_or(0)).collect();
            let (start,end,step) = match vals.as_slice() { [e] => (0,*e,1), [s,e] => (*s,*e,1), [s,e,st] => (*s,*e,*st), _ => (0,0,1) };
            let mut out=Vec::new(); let mut i=start;
            if step>0 { while i<end { out.push(num_value(i as f64)); i+=step; } }
            else if step<0 { while i>end { out.push(num_value(i as f64)); i+=step; } }
            Ok(out)
        }
        "contains" => { let needle=one(&args[0])?; Ok(vec![Value::Bool(contains(input,&needle))]) }
        "split" => {
            let sep = args.get(0).map(|e| one(e).unwrap_or(Value::String(String::new())).as_str().unwrap_or("").to_string()).unwrap_or_default();
            Ok(vec![Value::Array(input.as_str().unwrap_or("").split(&sep).map(|s| Value::String(s.to_string())).collect())])
        }
        "join" => {
            let sep = args.get(0).map(|e| one(e).unwrap_or(Value::String(String::new())).as_str().unwrap_or("").to_string()).unwrap_or_default();
            let parts: Vec<String> = match input { Value::Array(a) => a.iter().map(|v| match v { Value::String(s)=>s.clone(), Value::Null=>String::new(), _=>serde_json::to_string(v).unwrap_or_default() }).collect(), _ => vec![] };
            Ok(vec![Value::String(parts.join(&sep))])
        }
        "reverse" => Ok(vec![match input { Value::Array(a)=>Value::Array(a.iter().cloned().rev().collect()), Value::String(s)=>Value::String(s.chars().rev().collect()), _=>Value::Null }]),
        "sort" => {
            let mut a = match input { Value::Array(a)=>a.clone(), _=>vec![] };
            a.sort_by(cmp_json);
            Ok(vec![Value::Array(a)])
        }
        "unique" => {
            let mut a = match input { Value::Array(a)=>a.clone(), _=>vec![] };
            a.sort_by(cmp_json);
            a.dedup();
            Ok(vec![Value::Array(a)])
        }
        "min" => Ok(vec![match input { Value::Array(a)=>a.iter().min_by(|x,y| cmp_json(x,y)).cloned().unwrap_or(Value::Null), _=>Value::Null }]),
        "max" => Ok(vec![match input { Value::Array(a)=>a.iter().max_by(|x,y| cmp_json(x,y)).cloned().unwrap_or(Value::Null), _=>Value::Null }]),
        "first" => Ok(vec![match input { Value::Array(a)=>a.first().cloned().unwrap_or(Value::Null), _=>input.clone() }]),
        "last" => Ok(vec![match input { Value::Array(a)=>a.last().cloned().unwrap_or(Value::Null), _=>input.clone() }]),
        "flatten" => Ok(vec![Value::Array(flatten(input))]),
        "to_entries" => Ok(vec![match input {
            Value::Object(m) => Value::Array(m.iter().map(|(k,v)| json!({"key":k,"value":v})).collect()),
            Value::Array(a) => Value::Array(a.iter().enumerate().map(|(i,v)| json!({"key":i,"value":v})).collect()),
            _ => Value::Array(vec![]),
        }]),
        "from_entries" => {
            let mut m = Map::new();
            if let Value::Array(a) = input {
                for e in a {
                    if let Value::Object(o)=e {
                        let k = o.get("key").or_else(|| o.get("Key")).map(|v| match v { Value::String(s)=>s.clone(), _=>serde_json::to_string(v).unwrap_or_default() }).unwrap_or_default();
                        let v = o.get("value").or_else(|| o.get("Value")).cloned().unwrap_or(Value::Null);
                        m.insert(k,v);
                    }
                }
            }
            Ok(vec![Value::Object(m)])
        }
        "values" => if input.is_null() { Ok(vec![]) } else { Ok(vec![input.clone()]) },
        "arrays" => if input.is_array() { Ok(vec![input.clone()]) } else { Ok(vec![]) },
        "objects" => if input.is_object() { Ok(vec![input.clone()]) } else { Ok(vec![]) },
        "strings" => if input.is_string() { Ok(vec![input.clone()]) } else { Ok(vec![]) },
        "numbers" => if input.is_number() { Ok(vec![input.clone()]) } else { Ok(vec![]) },
        "booleans" => if input.is_boolean() { Ok(vec![input.clone()]) } else { Ok(vec![]) },
        "nulls" => if input.is_null() { Ok(vec![input.clone()]) } else { Ok(vec![]) },
        _ => Ok(vec![input.clone()]),
    }
}

fn truthy(v: &Value) -> bool { !matches!(v, Value::Bool(false)|Value::Null) }
fn as_f64(v: &Value) -> f64 { v.as_f64().unwrap_or(0.0) }
fn num_value(f: f64) -> Value {
    if f.fract()==0.0 { Value::Number(Number::from(f as i64)) } else { Number::from_f64(f).map(Value::Number).unwrap_or(Value::Null) }
}
fn to_key(v: Value) -> String { match v { Value::String(s)=>s, _=>serde_json::to_string(&v).unwrap_or_default() } }
fn norm_bound(i: i64, len: i64) -> i64 {
    let x = if i < 0 { len + i } else { i };
    x.max(0).min(len)
}

fn apply_op(a: &Value, b: &Value, op: Op) -> Value {
    match op {
        Op::Add => match (a,b) {
            (Value::Number(_),Value::Number(_)) => num_value(as_f64(a)+as_f64(b)),
            (Value::String(x),Value::String(y)) => Value::String(format!("{}{}",x,y)),
            (Value::Array(x),Value::Array(y)) => { let mut z=x.clone(); z.extend(y.clone()); Value::Array(z) }
            (Value::Object(x),Value::Object(y)) => { let mut z=x.clone(); for (k,v) in y { z.insert(k.clone(),v.clone()); } Value::Object(z) }
            (Value::Null,x)|(x,Value::Null) => x.clone(),
            _ => Value::Null,
        },
        Op::Sub => num_value(as_f64(a)-as_f64(b)),
        Op::Mul => match (a,b) { (Value::Number(_),Value::Number(_))=>num_value(as_f64(a)*as_f64(b)), (Value::String(s),Value::Number(n))|(Value::Number(n),Value::String(s))=>Value::String(s.repeat(n.as_u64().unwrap_or(0) as usize)), _=>Value::Null },
        Op::Div => num_value(as_f64(a)/as_f64(b)),
        Op::Rem => num_value(as_f64(a)%as_f64(b)),
        Op::Eq => Value::Bool(a==b),
        Op::Ne => Value::Bool(a!=b),
        Op::Lt|Op::Le|Op::Gt|Op::Ge => {
            let ord = cmp_json(a,b);
            Value::Bool(match op { Op::Lt=>ord==Ordering::Less, Op::Le=>ord!=Ordering::Greater, Op::Gt=>ord==Ordering::Greater, Op::Ge=>ord!=Ordering::Less, _=>false })
        }
        Op::And => Value::Bool(truthy(a)&&truthy(b)),
        Op::Or => Value::Bool(truthy(a)||truthy(b)),
        Op::Alt => if !a.is_null() && *a != Value::Bool(false) { a.clone() } else { b.clone() },
    }
}
fn cmp_json(a:&Value,b:&Value)->Ordering {
    match (a,b) {
        (Value::Number(_),Value::Number(_)) => as_f64(a).partial_cmp(&as_f64(b)).unwrap_or(Ordering::Equal),
        (Value::String(x),Value::String(y)) => x.cmp(y),
        (Value::Bool(x),Value::Bool(y)) => x.cmp(y),
        _ => rank(a).cmp(&rank(b)),
    }
}
fn rank(v:&Value)->u8 { match v { Value::Null=>0, Value::Bool(false)=>1, Value::Bool(true)=>2, Value::Number(_)=>3, Value::String(_)=>4, Value::Array(_)=>5, Value::Object(_)=>6 } }
fn contains(h:&Value,n:&Value)->bool {
    match (h,n) {
        (Value::String(a),Value::String(b))=>a.contains(b),
        (Value::Array(a),Value::Array(b))=>b.iter().all(|x| a.iter().any(|y| contains(y,x))),
        (Value::Object(a),Value::Object(b))=>b.iter().all(|(k,v)| a.get(k).is_some_and(|x| contains(x,v))),
        _=>h==n,
    }
}
fn flatten(v:&Value)->Vec<Value> {
    match v {
        Value::Array(a) => a.iter().flat_map(flatten).collect(),
        x => vec![x.clone()],
    }
}

fn sort_value(v: &Value) -> Value {
    match v {
        Value::Array(a) => Value::Array(a.iter().map(sort_value).collect()),
        Value::Object(m) => {
            let mut bm = BTreeMap::new();
            for (k,v) in m { bm.insert(k.clone(), sort_value(v)); }
            let mut out=Map::new(); for (k,v) in bm { out.insert(k,v); } Value::Object(out)
        }
        _ => v.clone(),
    }
}

fn print_value(v: &Value, cfg: &Config) {
    let mut stdout = io::stdout();
    if cfg.raw_output {
        match v { Value::String(s) => { let _=stdout.write_all(s.as_bytes()); }, _ => { let _=stdout.write_all(render_json(v,cfg).as_bytes()); } }
    } else {
        let _=stdout.write_all(render_json(v,cfg).as_bytes());
    }
    if cfg.nul { let _=stdout.write_all(&[0]); }
    else if !cfg.join { let _=stdout.write_all(b"\n"); }
}

fn render_json(v: &Value, cfg: &Config) -> String {
    let val = if cfg.sort_keys { sort_value(v) } else { v.clone() };
    let mut s = if cfg.compact { serde_json::to_string(&val).unwrap_or_default() } else { to_pretty(&val, 0, cfg) };
    if cfg.ascii { s = s.chars().flat_map(|c| c.escape_default()).collect(); }
    s
}
fn ind(level: usize, cfg: &Config) -> String {
    match cfg.indent { Indent::Spaces(n)=>" ".repeat(level*n), Indent::Tab=>"\t".repeat(level) }
}
fn to_pretty(v:&Value, level:usize, cfg:&Config)->String {
    match v {
        Value::Array(a) if a.is_empty() => "[]".into(),
        Value::Array(a) => {
            let mut s="[".to_string();
            for (i,x) in a.iter().enumerate() {
                s.push('\n'); s.push_str(&ind(level+1,cfg)); s.push_str(&to_pretty(x,level+1,cfg));
                if i+1<a.len(){s.push(',');}
            }
            s.push('\n'); s.push_str(&ind(level,cfg)); s.push(']'); s
        }
        Value::Object(m) if m.is_empty() => "{}".into(),
        Value::Object(m) => {
            let mut s="{".to_string();
            for (i,(k,x)) in m.iter().enumerate() {
                s.push('\n'); s.push_str(&ind(level+1,cfg)); s.push_str(&serde_json::to_string(k).unwrap()); s.push_str(": "); s.push_str(&to_pretty(x,level+1,cfg));
                if i+1<m.len(){s.push(',');}
            }
            s.push('\n'); s.push_str(&ind(level,cfg)); s.push('}'); s
        }
        _ => serde_json::to_string(v).unwrap_or_default(),
    }
}
