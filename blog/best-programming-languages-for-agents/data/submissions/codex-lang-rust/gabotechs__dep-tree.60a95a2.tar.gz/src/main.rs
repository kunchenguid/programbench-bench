use std::collections::{BTreeMap, BTreeSet, HashMap, HashSet};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "dep-tree version v0.23.4";

const BANNER_HELP: &str = r#"
      ____         _ __       _
     |  _ \   ___ |  _ \    _| |_  _ __  ___   ___
     | | | | / _ \| |_) |  |_   _||  __|/ _ \ / _ \
     | |_| ||  __/| .__/     | |  | |  |  __/|  __/
     |____/  \__| |_|        | \__|_|   \___| \___|

Usage:
  dep-tree [command]

Examples:
$ dep-tree src/index.ts
$ dep-tree entropy src/index.ts
$ dep-tree tree package/main.py --unwrap-exports
$ dep-tree check

Visualize your dependencies graphically
  entropy     (default) Renders a 3d force-directed graph in the browser
  tree        Render the dependency tree starting from the provided entrypoint

Check your dependencies against your own rules
  check       Checks that the dependency rules defined in the configuration file are not broken

Display what are the dependencies between two portions of code
  explain     Shows all the dependencies between two parts of the code

Additional Commands:
  config      Generates a sample config in case that there's not already one present
  help        Help about any command

Flags:
  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)
      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)
      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)
      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)
      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)
      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.
      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.
  -h, --help                                 help for dep-tree
  -v, --version                              version for dep-tree

Use "dep-tree [command] --help" for more information about a command.
"#;

const SAMPLE_CONFIG: &str = r#"# Files that should be completely ignored by dep-tree. It's fine to ignore
# some big files that everyone depends on and that don't add
# value to the visualization, like auto generated code.
exclude:
  - 'some-glob-pattern/**/*.ts'

# The only files that will be included by dep-tree. If a file does not
# match any of the provided patters, it is ignored.
only:
  - 'some-glob-pattern/**/*.ts'

# Whether to unwrap re-exports to the target file or not.
# Imagine that you have the following setup:
#
#  src/index.ts     -> import { foo } from './foo'
#  src/foo/index.ts -> export { bar as foo } from './bar'
#  src/foo/bar.ts   -> export function bar() {}
#
# If `unwrapExports` is true, a dependency will be created from
# `src/index.ts` to `src/foo/bar.ts`, and the middle file `src/foo/index.ts`
# will be ignored, as it's just there for re-exporting the `bar` symbol,
# which is actually declared on `src/foo/bar.ts`
#
# If `unwrapExports` is false, re-exported symbols will not be traced back
# to where they are declared, and instead two dependencies will be created:
# - from `src/index.ts` to `src/foo/index.ts`
# - from `src/foo/index.ts` to `src/foo/bar.ts`
#
# Entropy visualization tends to lead to better results if this is set to `false`,
# but CLI rendering is slightly better with this set to `true`.
unwrapExports: false

# Check configuration for the `dep-tree check` command. Dep Tree will check for dependency
# violation rules declared here, and fail if there is at least one unsatisfied rule.
check:
  # These are the entrypoints to your application. Dependencies will be checked with
  # these files as root nodes. Typically, an application has only one entrypoint, which
  # is the executable file (`src/index.ts`, `main.py`, `src/lib.rs`, ...), but here
  # you can declare as many as you want.
  entrypoints:
    - src/index.ts

  # Whether to allow circular dependencies or not. Languages typically allow
  # having circular dependencies, but that has an impact in execution path
  # traceability, so you might want to disallow it.
  allowCircularDependencies: false

  # map from glob pattern to array of glob patterns that determines the exclusive allowed
  # dependencies that a file matching a key glob pattern might have. If file that
  # matches a key glob pattern depends on another file that does not match any of
  # the glob patterns declared in the values array, the check will fail.
  allow:
    'src/products/**':
      - 'src/products/**'
      - 'src/helpers/**'
    'src/users/**':
      to:
       - 'src/helpers/**'
      reason: The Users domain is only allowed to import helper code, nothing else

  deny:
    'src/products/**':
      - 'src/users/**'
    'src/users/**':
      - to: 'src/products/**'
        reason: The Users domain should not import anything from the Products domain
      - to: 'src/orders/**'
        reason: The Users domain should not import anything from the Orders domain

  aliases:
    'common':
      - 'src/helpers/**'
      - 'src/utils/**'
      - 'src/generated/**'

js:
  workspaces: true
  tsConfigPaths: true

python:
  excludeConditionalImports: false

rust:
"#;

#[derive(Clone, Debug, Default)]
struct Config {
    exclude: Vec<String>,
    only: Vec<String>,
    unwrap_exports: bool,
    py_exclude_conditional: bool,
    check_entrypoints: Vec<String>,
    allow_circular: bool,
    aliases: HashMap<String, Vec<String>>,
    allow: Vec<Rule>,
    deny: Vec<Rule>,
}

#[derive(Clone, Debug)]
struct Rule { from: String, to: Vec<String>, reason: Option<String> }

#[derive(Default)]
struct Opts {
    config: String,
    only: Vec<String>,
    exclude: Vec<String>,
    unwrap_exports: bool,
    py_exclude_conditional: bool,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-v" || a == "--version") { println!("{}", VERSION); return; }
    if args.is_empty() { print!("{}", BANNER_HELP); return; }
    if args.iter().any(|a| a == "-h" || a == "--help") && !args.iter().any(|a| is_command(a)) {
        print!("{}", BANNER_HELP);
        return;
    }
    let (opts, mut rest) = parse_global(args);
    let cmd = if !rest.is_empty() && is_command(&rest[0]) { rest.remove(0) } else { "entropy".to_string() };
    if rest.iter().any(|a| a == "-h" || a == "--help") { print_sub_help(&cmd); return; }
    let mut cfg = load_config(&opts.config).unwrap_or_default();
    cfg.only.extend(opts.only); cfg.exclude.extend(opts.exclude);
    cfg.unwrap_exports |= opts.unwrap_exports;
    cfg.py_exclude_conditional |= opts.py_exclude_conditional;
    let res = match cmd.as_str() {
        "tree" => cmd_tree(&rest, &cfg),
        "explain" => cmd_explain(&rest, &cfg),
        "check" => cmd_check(&cfg, &opts.config),
        "config" | "init" => cmd_config(&opts.config),
        "entropy" => cmd_entropy(&rest, &cfg),
        "help" => { print!("{}", BANNER_HELP); Ok(()) },
        other => Err(format!("{} does not match with any existing file", other)),
    };
    if let Err(e) = res { eprintln!("Error: {}", e); process::exit(1); }
}

fn is_command(s: &str) -> bool { matches!(s, "entropy"|"tree"|"check"|"explain"|"config"|"init"|"help") }

fn parse_global(args: Vec<String>) -> (Opts, Vec<String>) {
    let mut opts = Opts { config: ".dep-tree.yml".into(), ..Default::default() };
    let mut rest = Vec::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-c" | "--config" => { if i + 1 < args.len() { opts.config = args[i+1].clone(); i += 2; } else { i += 1; } }
            "--only" => { if i + 1 < args.len() { opts.only.push(args[i+1].clone()); i += 2; } else { i += 1; } }
            "--exclude" => { if i + 1 < args.len() { opts.exclude.push(args[i+1].clone()); i += 2; } else { i += 1; } }
            "--unwrap-exports" => { opts.unwrap_exports = true; i += 1; }
            "--python-exclude-conditional-imports" => { opts.py_exclude_conditional = true; i += 1; }
            "--js-tsconfig-paths" | "--js-workspaces" => { i += 1; }
            _ => { rest.push(args[i].clone()); i += 1; }
        }
    }
    (opts, rest)
}

fn print_sub_help(cmd: &str) {
    match cmd {
        "entropy" => println!("(default) Renders a 3d force-directed graph in the browser\n\nUsage:\n  dep-tree entropy [flags]\n\nFlags:\n      --enable-gui           Enables a GUI for changing rendering settings\n  -h, --help                 help for entropy\n      --no-browser-open      Disable the automatic browser open while rendering entropy\n      --render-path string   Sets the output path of the rendered html file\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)"),
        "tree" => println!("Render the dependency tree starting from the provided entrypoint\n\nUsage:\n  dep-tree tree [flags]\n\nFlags:\n  -h, --help   help for tree\n      --json   render the dependency tree in a machine readable json format\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)"),
        "check" => println!("Checks that the dependency rules defined in the configuration file are not broken\n\nUsage:\n  dep-tree check [flags]\n\nFlags:\n  -h, --help   help for check\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)"),
        "explain" => println!("Shows all the dependencies between two parts of the code\n\nUsage:\n  dep-tree explain [flags]\n\nFlags:\n  -h, --help            help for explain\n  -l, --overlap-left    When there's an overlap between the files at the left and the right, keep the ones at the left\n  -r, --overlap-right   When there's an overlap between the files at the left and the right, keep the ones at the right\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)"),
        "config" | "init" => println!("Generates a sample config in case that there's not already one present\n\nUsage:\n  dep-tree config [flags]\n\nAliases:\n  config, init\n\nFlags:\n  -h, --help   help for config\n\nGlobal Flags:\n  -c, --config string                        path to dep-tree's config file. (default .dep-tree.yml)\n      --exclude stringArray                  Files that match this glob pattern will be ignored. You can provide an arbitrary number of --exclude flags.\n      --js-tsconfig-paths                    follow the tsconfig.json paths while resolving imports. (default true)\n      --js-workspaces                        take the workspaces attribute in the root package.json into account for resolving paths. (default true)\n      --only stringArray                     Files that do not match this glob pattern will be ignored. You can provide an arbitrary number of --only flags.\n      --python-exclude-conditional-imports   exclude imports wrapped inside if or try statements. (default false)\n      --unwrap-exports                       trace re-exported symbols to the file where they are declared. (default false)"),
        _ => print!("{}", BANNER_HELP),
    }
}

fn cmd_config(path: &str) -> Result<(), String> {
    if Path::new(path).exists() { return Err(format!("cannot generate config file, as one already exists in {}", path)); }
    fs::write(path, SAMPLE_CONFIG).map_err(|e| e.to_string())
}

fn cmd_entropy(args: &[String], cfg: &Config) -> Result<(), String> {
    let mut render = "dep-tree.html".to_string();
    let mut entries = Vec::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--render-path" => { if i+1 < args.len() { render = args[i+1].clone(); i += 2; } else { i += 1; } }
            "--no-browser-open" | "--enable-gui" => i += 1,
            a if a.starts_with('-') => i += 1,
            a => { entries.push(a.to_string()); i += 1; }
        }
    }
    if entries.is_empty() { return Err("requires at least 1 arg(s), only received 0".into()); }
    let graph = build_from_patterns(&entries, cfg)?;
    let html = format!("<!doctype html><html><head><meta charset=\"utf-8\"><title>Dep Tree</title></head><body><pre>{}</pre></body></html>\n", html_escape(&json_graph(&graph)));
    fs::write(&render, html).map_err(|e| e.to_string())?;
    println!("Rendered dependency graph at {}", render);
    Ok(())
}

fn cmd_tree(args: &[String], cfg: &Config) -> Result<(), String> {
    let mut json = false; let mut pats = Vec::new();
    for a in args { if a == "--json" { json = true; } else if !a.starts_with('-') { pats.push(a.clone()); } }
    if pats.is_empty() { return Err("requires at least 1 arg(s), only received 0".into()); }
    let graph = build_from_patterns(&pats, cfg)?;
    if json { println!("{}", json_graph(&graph)); }
    else { for root in &graph.roots { print_tree(root, &graph, 0, &mut HashSet::new()); } }
    Ok(())
}

fn cmd_explain(args: &[String], cfg: &Config) -> Result<(), String> {
    let mut overlap_left = false; let mut overlap_right = false; let mut pats = Vec::new();
    for a in args {
        match a.as_str() { "-l"|"--overlap-left" => overlap_left = true, "-r"|"--overlap-right" => overlap_right = true, s if s.starts_with('-') => {}, _ => pats.push(a.clone()) }
    }
    if pats.len() != 2 { return Err(format!("accepts 2 arg(s), received {}", pats.len())); }
    let mut left: BTreeSet<String> = expand_pattern(&pats[0], cfg)?.into_iter().collect();
    let mut right: BTreeSet<String> = expand_pattern(&pats[1], cfg)?.into_iter().collect();
    let overlap: Vec<String> = left.intersection(&right).cloned().collect();
    if overlap_left { for f in &overlap { right.remove(f); } }
    if overlap_right { for f in &overlap { left.remove(f); } }
    let all: Vec<String> = all_code_files(cfg);
    let graph = build_graph(all, cfg);
    for l in left {
        if let Some(deps) = graph.edges.get(&l) {
            for r in deps { if right.contains(r) { println!("{} -> {}", l, r); } }
        }
    }
    Ok(())
}

fn cmd_check(cfg: &Config, cfg_path: &str) -> Result<(), String> {
    if !Path::new(cfg_path).exists() { return Err("when using the `check` subcommand, a .dep-tree.yml file must be provided, you can create one sample .dep-tree.yml file executing `dep-tree config` in your terminal".into()); }
    let entries = if cfg.check_entrypoints.is_empty() { return Err("no entrypoints were configured for check".into()); } else { cfg.check_entrypoints.clone() };
    let graph = build_from_patterns(&entries, cfg)?;
    let mut violations = Vec::new();
    if !cfg.allow_circular { for c in &graph.circular { violations.push(format!("circular dependency detected: {}", c.join(" -> "))); } }
    for (from, deps) in &graph.edges {
        for dep in deps {
            for rule in &cfg.allow {
                if glob_match(&rule.from, from) {
                    let allowed = expand_aliases(&rule.to, cfg).iter().any(|p| glob_match(p, dep));
                    if !allowed { violations.push(format!("{} -> {} is not allowed{}", from, dep, reason_suffix(&rule.reason))); }
                }
            }
            for rule in &cfg.deny {
                if glob_match(&rule.from, from) && expand_aliases(&rule.to, cfg).iter().any(|p| glob_match(p, dep)) {
                    violations.push(format!("{} -> {} is denied{}", from, dep, reason_suffix(&rule.reason)));
                }
            }
        }
    }
    if violations.is_empty() { println!("dependency check passed"); Ok(()) } else { for v in &violations { eprintln!("{}", v); } Err(format!("{} dependency rule(s) were broken", violations.len())) }
}

fn reason_suffix(r: &Option<String>) -> String { r.as_ref().map(|x| format!(": {}", x)).unwrap_or_default() }
fn expand_aliases(pats: &[String], cfg: &Config) -> Vec<String> { let mut out = Vec::new(); for p in pats { if let Some(v) = cfg.aliases.get(p) { out.extend(v.clone()); } else { out.push(p.clone()); } } out }

#[derive(Default)]
struct Graph { roots: Vec<String>, edges: BTreeMap<String, BTreeSet<String>>, errors: BTreeMap<String, Vec<String>>, circular: Vec<Vec<String>> }

fn build_from_patterns(pats: &[String], cfg: &Config) -> Result<Graph, String> {
    let mut roots = Vec::new();
    for p in pats { roots.extend(expand_pattern(p, cfg)?); }
    if roots.is_empty() { return Err(format!("{} does not match with any existing file", pats[0])); }
    let mut g = Graph { roots: roots.clone(), ..Default::default() };
    let mut visiting = Vec::new(); let mut done = HashSet::new();
    for r in roots { dfs(&r, cfg, &mut g, &mut visiting, &mut done); }
    Ok(g)
}

fn build_graph(files: Vec<String>, cfg: &Config) -> Graph {
    let mut g = Graph { roots: files.clone(), ..Default::default() };
    for f in files { let deps = parse_deps(&f, cfg, &mut g.errors); g.edges.insert(f, deps.into_iter().collect()); }
    g
}

fn dfs(file: &str, cfg: &Config, g: &mut Graph, stack: &mut Vec<String>, done: &mut HashSet<String>) {
    if stack.iter().any(|s| s == file) {
        if let Some(pos) = stack.iter().position(|s| s == file) { let mut c = stack[pos..].to_vec(); c.push(file.to_string()); g.circular.push(c); }
        return;
    }
    if done.contains(file) { return; }
    stack.push(file.to_string());
    let deps = parse_deps(file, cfg, &mut g.errors);
    g.edges.insert(file.to_string(), deps.iter().cloned().collect());
    for d in deps { dfs(&d, cfg, g, stack, done); }
    stack.pop(); done.insert(file.to_string());
}

fn parse_deps(file: &str, cfg: &Config, errors: &mut BTreeMap<String, Vec<String>>) -> Vec<String> {
    let text = match fs::read_to_string(file) { Ok(s) => s, Err(e) => { errors.entry(file.into()).or_default().push(e.to_string()); return Vec::new(); } };
    let ext = Path::new(file).extension().and_then(|s| s.to_str()).unwrap_or("");
    let specs = match ext { "js"|"jsx"|"ts"|"tsx"|"mjs"|"cjs" => parse_js_specs(&text), "py" => parse_py_specs(file, &text, cfg.py_exclude_conditional), "rs" => parse_rust_specs(file, &text), "go" => parse_go_specs(&text), _ => Vec::new() };
    let mut deps = BTreeSet::new();
    for spec in specs {
        if let Some(path) = resolve_spec(file, &spec, ext) { if included(&path, cfg) { deps.insert(path); } }
        else if is_local_like(&spec) { errors.entry(file.into()).or_default().push(format!("could not resolve import '{}'", spec)); }
    }
    deps.into_iter().collect()
}

fn is_local_like(s: &str) -> bool { s.starts_with('.') || s.starts_with("crate::") || s.starts_with("super::") || s.starts_with("self::") || module_prefix().map(|m| s.starts_with(&m)).unwrap_or(false) }

fn parse_js_specs(text: &str) -> Vec<String> {
    let mut out = Vec::new();
    for line in text.lines() {
        let l = strip_comment(line).trim();
        for key in [" from ", "import(", "require("] {
            if let Some(pos) = l.find(key) { if let Some(s) = first_quoted(&l[pos+key.len()..]) { out.push(s); } }
        }
        if l.starts_with("import ") { if let Some(s) = first_quoted(l) { out.push(s); } }
    }
    out
}

fn parse_py_specs(file: &str, text: &str, exclude_cond: bool) -> Vec<String> {
    let mut out = Vec::new();
    let dir = Path::new(file).parent().unwrap_or(Path::new(""));
    for line in text.lines() {
        if exclude_cond && line.starts_with(char::is_whitespace) { continue; }
        let l = line.trim(); if l.starts_with('#') { continue; }
        if let Some(rest) = l.strip_prefix("import ") {
            for part in rest.split(',') { let name = part.trim().split_whitespace().next().unwrap_or(""); if !name.is_empty() { out.push(name.replace('.', "/")); } }
        } else if let Some(rest) = l.strip_prefix("from ") {
            if let Some((module, imports)) = rest.split_once(" import ") {
                let dots = module.chars().take_while(|c| *c == '.').count();
                let base = module.trim_start_matches('.').replace('.', "/");
                if dots > 0 {
                    let mut p = dir.to_path_buf(); for _ in 1..dots { p.pop(); }
                    if !base.is_empty() { p.push(&base); }
                    if imports.trim() != "*" && base.is_empty() { for it in imports.split(',') { let n = it.trim().split_whitespace().next().unwrap_or(""); if !n.is_empty() { out.push(path_join_str(&p, n)); } } }
                    else { out.push(norm_path(&p)); }
                } else {
                    out.push(base.clone());
                    for it in imports.split(',') {
                        let n = it.trim().split_whitespace().next().unwrap_or("");
                        if !n.is_empty() {
                            out.push(format!("{}/{}", base, n));
                        }
                    }
                }
            }
        }
    }
    out
}

fn parse_rust_specs(file: &str, text: &str) -> Vec<String> {
    let mut out = Vec::new();
    let path = Path::new(file);
    let dir = path.parent().unwrap_or(Path::new(""));
    for line in text.lines() {
        let l = strip_comment(line).trim();
        if let Some(rest) = l.strip_prefix("mod ") { let name = rest.trim_end_matches(';').trim(); if !name.contains(' ') { out.push(path_join_str(dir, &name.replace("::", "/"))); } }
        if let Some(rest) = l.strip_prefix("use ") {
            let spec = rest.trim_end_matches(';').trim().trim_start_matches('{').trim_end_matches('}');
            let head = spec.split(&[':', '{', ','][..]).next().unwrap_or("");
            if spec.starts_with("crate::") || spec.starts_with("self::") || spec.starts_with("super::") { out.push(head.to_string()); }
        }
    }
    out
}

fn parse_go_specs(text: &str) -> Vec<String> {
    let mut out = Vec::new(); let mut block = false;
    for line in text.lines() {
        let l = line.trim();
        if l.starts_with("import (") { block = true; continue; }
        if block && l.starts_with(')') { block = false; continue; }
        if block || l.starts_with("import ") { if let Some(s) = first_quoted(l) { out.push(s); } }
    }
    out
}

fn resolve_spec(file: &str, spec: &str, ext: &str) -> Option<String> {
    let p = if spec.starts_with('.') {
        Path::new(file).parent().unwrap_or(Path::new("")).join(spec)
    } else if spec.contains('/') && !spec.contains("::") {
        PathBuf::from(spec)
    } else if ext == "py" && !spec.contains("::") {
        PathBuf::from(spec)
    } else if ext == "rs" {
        resolve_rust_base(file, spec)
    } else if ext == "go" {
        if let Some(m) = module_prefix() { if let Some(rest) = spec.strip_prefix(&m) { PathBuf::from(rest.trim_start_matches('/')) } else { return None; } } else { return None; }
    } else { return None; };
    candidates(&p, ext).into_iter().find(|c| c.is_file()).map(|c| rel(&c))
}

fn resolve_rust_base(file: &str, spec: &str) -> PathBuf {
    let mut parts: Vec<&str> = spec.split("::").collect();
    if parts.first() == Some(&"crate") { parts.remove(0); return PathBuf::from("src").join(parts.join("/")); }
    let mut base = Path::new(file).parent().unwrap_or(Path::new("")).to_path_buf();
    while parts.first() == Some(&"super") { parts.remove(0); base.pop(); }
    if parts.first() == Some(&"self") { parts.remove(0); }
    base.join(parts.join("/"))
}

fn candidates(base: &Path, ext: &str) -> Vec<PathBuf> {
    let mut v = Vec::new();
    if base.extension().is_some() {
        v.push(base.to_path_buf());
    }
    match ext {
        "js"|"jsx"|"ts"|"tsx"|"mjs"|"cjs" => for e in ["ts","tsx","js","jsx","mjs","cjs"] { v.push(with_ext(base, e)); v.push(base.join(format!("index.{}", e))); },
        "py" => { v.push(with_ext(base, "py")); v.push(base.join("__init__.py")); },
        "rs" => { v.push(with_ext(base, "rs")); v.push(base.join("mod.rs")); },
        "go" => { v.push(base.join("*.go")); },
        _ => {}
    }
    if ext == "go" { if let Some(dir) = v.last().and_then(|p| p.parent()) { if let Ok(rd) = fs::read_dir(dir) { for e in rd.flatten() { if e.path().extension().and_then(|s| s.to_str()) == Some("go") { v.push(e.path()); } } } } }
    v
}
fn with_ext(base: &Path, ext: &str) -> PathBuf { let mut p = base.to_path_buf(); p.set_extension(ext); p }

fn first_quoted(s: &str) -> Option<String> {
    let bytes = s.as_bytes();
    for (i,b) in bytes.iter().enumerate() { if *b == b'\'' || *b == b'"' { let q = *b; for j in i+1..bytes.len() { if bytes[j] == q { return Some(s[i+1..j].to_string()); } } } }
    None
}
fn strip_comment(s: &str) -> &str { s.split("//").next().unwrap_or(s) }

fn all_code_files(cfg: &Config) -> Vec<String> {
    let mut out = Vec::new(); walk(Path::new("."), &mut out);
    out.into_iter().filter(|p| is_code(p) && included(p, cfg)).collect()
}
fn walk(dir: &Path, out: &mut Vec<String>) { if let Ok(rd) = fs::read_dir(dir) { for e in rd.flatten() { let p = e.path(); let name = p.file_name().and_then(|s| s.to_str()).unwrap_or(""); if name == ".git" || name == "target" { continue; } if p.is_dir() { walk(&p, out); } else { out.push(rel(&p)); } } } }
fn is_code(p: &str) -> bool { matches!(Path::new(p).extension().and_then(|s| s.to_str()).unwrap_or(""), "js"|"jsx"|"ts"|"tsx"|"mjs"|"cjs"|"py"|"rs"|"go") }
fn included(p: &str, cfg: &Config) -> bool { (cfg.only.is_empty() || cfg.only.iter().any(|g| glob_match(g, p))) && !cfg.exclude.iter().any(|g| glob_match(g, p)) }

fn expand_pattern(pat: &str, cfg: &Config) -> Result<Vec<String>, String> {
    if !has_glob(pat) {
        if Path::new(pat).exists() { let r = rel(Path::new(pat)); return if included(&r, cfg) { Ok(vec![r]) } else { Ok(vec![]) }; }
        return Err(format!("{} does not match with any existing file", pat));
    }
    let mut files = all_code_files(cfg); files.retain(|p| glob_match(pat, p)); Ok(files)
}
fn has_glob(s: &str) -> bool { s.contains('*') || s.contains('?') || s.contains('[') }

fn glob_match(pat: &str, text: &str) -> bool {
    let p = pat.trim_matches('"').trim_matches('\'');
    glob_parts(&split_path(p), &split_path(text))
}
fn split_path(s: &str) -> Vec<&str> { s.trim_start_matches("./").split('/').filter(|x| !x.is_empty()).collect() }
fn glob_parts(p: &[&str], t: &[&str]) -> bool {
    if p.is_empty() { return t.is_empty(); }
    if p[0] == "**" { return glob_parts(&p[1..], t) || (!t.is_empty() && glob_parts(p, &t[1..])); }
    !t.is_empty() && glob_component(p[0], t[0]) && glob_parts(&p[1..], &t[1..])
}
fn glob_component(p: &str, t: &str) -> bool {
    fn inner(p: &[u8], t: &[u8]) -> bool { if p.is_empty() { return t.is_empty(); } match p[0] { b'*' => inner(&p[1..], t) || (!t.is_empty() && inner(p, &t[1..])), b'?' => !t.is_empty() && inner(&p[1..], &t[1..]), c => !t.is_empty() && c == t[0] && inner(&p[1..], &t[1..]) } }
    inner(p.as_bytes(), t.as_bytes())
}

fn json_graph(g: &Graph) -> String {
    let mut s = String::new(); s.push_str("{\n  \"tree\": {");
    for (i,r) in g.roots.iter().enumerate() { if i>0 { s.push(','); } s.push('\n'); s.push_str(&format!("    \"{}\": ", esc(r))); json_node(r, g, &mut HashSet::new(), 4, &mut s); }
    if !g.roots.is_empty() { s.push('\n'); }
    s.push_str("  },\n  \"circularDependencies\": [");
    for (i,c) in g.circular.iter().enumerate() { if i>0 { s.push_str(", "); } s.push('['); for (j,x) in c.iter().enumerate() { if j>0 { s.push_str(", "); } s.push_str(&format!("\"{}\"", esc(x))); } s.push(']'); }
    s.push_str("],\n  \"errors\": ");
    if g.errors.is_empty() {
        s.push_str("{}\n}");
    } else {
        s.push('{');
        for (i,(k,vals)) in g.errors.iter().enumerate() { if i>0 { s.push(','); } s.push_str(&format!("\n    \"{}\": [", esc(k))); for (j,v) in vals.iter().enumerate() { if j>0 { s.push_str(", "); } s.push_str(&format!("\"{}\"", esc(v))); } s.push(']'); }
        s.push_str("\n  }\n}");
    }
    s
}
fn json_node(file: &str, g: &Graph, seen: &mut HashSet<String>, indent: usize, s: &mut String) {
    if !seen.insert(file.to_string()) { s.push_str("null"); return; }
    let deps: Vec<_> = g.edges.get(file).map(|x| x.iter().cloned().collect()).unwrap_or_else(Vec::<String>::new);
    if deps.is_empty() { s.push_str("null"); } else { s.push('{'); for (i,d) in deps.iter().enumerate() { if i>0 { s.push(','); } s.push('\n'); s.push_str(&" ".repeat(indent+2)); s.push_str(&format!("\"{}\": ", esc(d))); json_node(d, g, seen, indent+2, s); } s.push('\n'); s.push_str(&" ".repeat(indent)); s.push('}'); }
    seen.remove(file);
}
fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }
fn html_escape(s: &str) -> String { s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;") }

fn print_tree(file: &str, g: &Graph, depth: usize, seen: &mut HashSet<String>) { println!("{}{}", "  ".repeat(depth), file); if !seen.insert(file.into()) { return; } if let Some(deps) = g.edges.get(file) { for d in deps { print_tree(d, g, depth+1, seen); } } seen.remove(file); }
fn rel(p: &Path) -> String { let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from(".")); let abs = if p.is_absolute() { p.to_path_buf() } else { cwd.join(p) }; let r = abs.strip_prefix(&cwd).unwrap_or(&abs); norm_path(r) }
fn norm_path(p: &Path) -> String {
    let mut parts: Vec<String> = Vec::new();
    for c in p.components() {
        match c {
            std::path::Component::CurDir => {}
            std::path::Component::ParentDir => {
                parts.pop();
            }
            std::path::Component::Normal(x) => parts.push(x.to_string_lossy().to_string()),
            _ => {}
        }
    }
    parts.join("/")
}
fn path_join_str(p: &Path, s: &str) -> String { norm_path(&p.join(s)) }
fn module_prefix() -> Option<String> { let txt = fs::read_to_string("go.mod").ok()?; for l in txt.lines() { if let Some(rest) = l.trim().strip_prefix("module ") { return Some(rest.trim().to_string()); } } None }

fn load_config(path: &str) -> Option<Config> {
    let text = fs::read_to_string(path).ok()?; let mut cfg = Config::default();
    cfg.unwrap_exports = find_bool(&text, "unwrapExports").unwrap_or(false);
    cfg.py_exclude_conditional = find_bool(&text, "excludeConditionalImports").unwrap_or(false);
    cfg.allow_circular = find_bool(&text, "allowCircularDependencies").unwrap_or(false);
    cfg.exclude = top_array(&text, "exclude"); cfg.only = top_array(&text, "only"); cfg.check_entrypoints = nested_array(&text, "check", "entrypoints");
    cfg.aliases = parse_map_arrays(section(&text, "aliases", 2));
    cfg.allow = parse_rules(section(&text, "allow", 2), true);
    cfg.deny = parse_rules(section(&text, "deny", 2), false);
    Some(cfg)
}
fn find_bool(text: &str, key: &str) -> Option<bool> { for l in text.lines() { let t = no_comment(l).trim(); if let Some(rest) = t.strip_prefix(&format!("{}:", key)) { return Some(rest.trim() == "true"); } } None }
fn top_array(text: &str, key: &str) -> Vec<String> { array_after(text, key, 0) }
fn nested_array(text: &str, parent: &str, key: &str) -> Vec<String> { array_after(&section(text, parent, 0), key, 2) }
fn array_after(text: &str, key: &str, indent: usize) -> Vec<String> { let mut out = Vec::new(); let mut in_key = false; for l in text.lines() { let raw = no_comment(l); let sp = count_indent(raw); let t = raw.trim(); if t.is_empty() { continue; } if in_key { if sp <= indent && !t.starts_with('-') { break; } if let Some(v) = t.strip_prefix("- ") { out.push(clean(v)); } } else if sp == indent && t == format!("{}:", key) { in_key = true; } } out }
fn section(text: &str, key: &str, indent: usize) -> String { let mut out = String::new(); let mut in_sec = false; for l in text.lines() { let raw = no_comment(l); let sp = count_indent(raw); let t = raw.trim(); if !in_sec && sp == indent && t == format!("{}:", key) { in_sec = true; continue; } if in_sec { if sp <= indent && !t.is_empty() { break; } out.push_str(l); out.push('\n'); } } out }
fn parse_map_arrays(text: String) -> HashMap<String, Vec<String>> { let mut m = HashMap::new(); let mut cur: Option<String> = None; for l in text.lines() { let t = no_comment(l).trim(); if t.is_empty() { continue; } if t.ends_with(':') && !t.starts_with('-') { cur = Some(clean(t.trim_end_matches(':'))); } else if let Some(v) = t.strip_prefix("- ") { if let Some(c) = &cur { m.entry(c.clone()).or_insert_with(Vec::new).push(clean(v)); } } } m }
fn parse_rules(text: String, allow: bool) -> Vec<Rule> { let mut out = Vec::new(); let mut cur: Option<Rule> = None; for l in text.lines() { let t = no_comment(l).trim(); if t.is_empty() { continue; } if t.ends_with(':') && !t.starts_with('-') && !matches!(t, "to:"|"reason:") { if let Some(r) = cur.take() { out.push(r); } cur = Some(Rule{from: clean(t.trim_end_matches(':')), to: Vec::new(), reason: None}); }
        else if let Some(v) = t.strip_prefix("- to:") { if let Some(r)=&mut cur { r.to.push(clean(v)); } }
        else if let Some(v) = t.strip_prefix("to:") { if let Some(r)=&mut cur { let c=clean(v); if !c.is_empty(){r.to.push(c);} } }
        else if let Some(v) = t.strip_prefix("reason:") { if let Some(r)=&mut cur { r.reason = Some(clean(v)); } }
        else if let Some(v) = t.strip_prefix("- ") { if let Some(r)=&mut cur { if allow || !v.contains("reason:") { r.to.push(clean(v)); } } }
    } if let Some(r) = cur { out.push(r); } out }
fn no_comment(s: &str) -> &str { s.split('#').next().unwrap_or(s) }
fn count_indent(s: &str) -> usize { s.chars().take_while(|c| *c == ' ').count() }
fn clean(s: &str) -> String { s.trim().trim_matches('"').trim_matches('\'').to_string() }
