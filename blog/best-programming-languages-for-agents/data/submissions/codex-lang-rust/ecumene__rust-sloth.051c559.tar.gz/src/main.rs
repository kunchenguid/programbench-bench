use std::collections::HashMap;
use std::env;
use std::f64::consts::PI;
use std::fs;
use std::path::Path;

#[derive(Clone, Copy, Debug, Default)]
struct Vec3 {
    x: f64,
    y: f64,
    z: f64,
}

impl Vec3 {
    fn new(x: f64, y: f64, z: f64) -> Self {
        Self { x, y, z }
    }
    fn sub(self, other: Vec3) -> Vec3 {
        Vec3::new(self.x - other.x, self.y - other.y, self.z - other.z)
    }
    fn cross(self, other: Vec3) -> Vec3 {
        Vec3::new(
            self.y * other.z - self.z * other.y,
            self.z * other.x - self.x * other.z,
            self.x * other.y - self.y * other.x,
        )
    }
    fn dot(self, other: Vec3) -> f64 {
        self.x * other.x + self.y * other.y + self.z * other.z
    }
    fn norm(self) -> Vec3 {
        let len = self.dot(self).sqrt();
        if len <= 1e-12 {
            self
        } else {
            Vec3::new(self.x / len, self.y / len, self.z / len)
        }
    }
}

#[derive(Clone, Copy, Debug)]
struct Color(u8, u8, u8);

#[derive(Clone, Debug)]
struct Tri {
    a: Vec3,
    b: Vec3,
    c: Vec3,
    color: Color,
}

#[derive(Clone, Debug)]
struct Config {
    files: Vec<String>,
    image: bool,
    webify: Option<usize>,
    width: usize,
    height: usize,
    yaw: f64,
    pitch: f64,
    roll: f64,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    match parse_args(&args) {
        Ok(Action::Help(s)) => {
            print!("{s}");
        }
        Ok(Action::Version) => println!("Sloth 0.1"),
        Ok(Action::Run(cfg)) => run(cfg),
        Err(msg) => {
            eprintln!("{msg}");
            std::process::exit(1);
        }
    }
}

enum Action {
    Help(String),
    Version,
    Run(Config),
}

fn parse_args(args: &[String]) -> Result<Action, String> {
    if args.len() == 1 {
        return Err("error: The following required arguments were not provided:\n    <input filename(s)>...\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFor more information try --help".into());
    }
    let has_image = args.iter().any(|a| a == "image");
    if args.iter().any(|a| a == "--help") || (!has_image && args.iter().any(|a| a == "-h")) {
        if args.iter().any(|a| a == "image") {
            return Ok(Action::Help(image_help()));
        }
        return Ok(Action::Help(main_help()));
    }
    if args.iter().any(|a| a == "--version" || a == "-V") {
        return Ok(Action::Version);
    }

    let mut files = Vec::new();
    let mut image = false;
    let mut webify = None;
    let mut width = None;
    let mut height = None;
    let mut yaw = 0.0;
    let mut pitch = 0.0;
    let mut roll = 0.0;
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "image" => image = true,
            "-b" => {}
            "-w" => {
                i += 1;
                width = args.get(i).and_then(|s| s.parse::<usize>().ok());
            }
            "-h" if image => {
                i += 1;
                height = args.get(i).and_then(|s| s.parse::<usize>().ok());
            }
            "-j" | "--webify" => {
                i += 1;
                webify = args.get(i).and_then(|s| s.parse::<usize>().ok());
            }
            "-x" | "--yaw" => {
                i += 1;
                yaw = args.get(i).and_then(|s| s.parse::<f64>().ok()).unwrap_or(0.0);
            }
            "-y" | "--pitch" => {
                i += 1;
                pitch = args.get(i).and_then(|s| s.parse::<f64>().ok()).unwrap_or(0.0);
            }
            "-z" | "--roll" => {
                i += 1;
                roll = args.get(i).and_then(|s| s.parse::<f64>().ok()).unwrap_or(0.0);
            }
            s if s.starts_with('-') => {}
            s => {
                for part in s.split_whitespace() {
                    files.push(part.to_string());
                }
            }
        }
        i += 1;
    }
    if files.is_empty() {
        return Err("error: The following required arguments were not provided:\n    <input filename(s)>...".into());
    }
    Ok(Action::Run(Config {
        files,
        image,
        webify,
        width: width.unwrap_or(80).max(1),
        height: height.unwrap_or_else(|| width.unwrap_or(80)).max(1),
        yaw,
        pitch,
        roll,
    }))
}

fn main_help() -> String {
    "Sloth 0.1\nMitchell Hynes. <mshynes@mun.ca>\nA toy for rendering 3D objects in the command line\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <input filename(s)>... [SUBCOMMAND]\n\nFLAGS:\n    -h, --help       Prints help information\n    -b               Flags the rasterizer to render without color\n    -V, --version    Prints version information\n\nOPTIONS:\n    -x, --yaw <x>      Sets the object's static X rotation (in radians)\n    -y, --pitch <y>    Sets the object's static Y rotation (in radians)\n    -z, --roll <z>     Sets the object's static Z rotation (in radians)\n\nARGS:\n    <input filename(s)>...    Sets the input file to render\n\nSUBCOMMANDS:\n    help     Prints this message or the help of the given subcommand(s)\n    image    Generates a colorless terminal output as lines of text\n".into()
}

fn image_help() -> String {
    "executable-image \nMitchell Hynes <mitchell.hynes@ecumene.xyz>\nGenerates a colorless terminal output as lines of text\n\nUSAGE:\n    executable <input filename(s)>... image [FLAGS] [OPTIONS] -w <width>\n\nFLAGS:\n        --help       Prints help information\n    -b               Flags the rasterizer to render without color\n    -V, --version    Prints version information\n\nOPTIONS:\n    -j, --webify <frame count>    Generates a portable JS based render of your object for the web\n    -h <height>                   Sets the height of the image to generate\n    -w <width>                    Sets the width of the image to generate\n    -x, --yaw <x>                 Sets the object's static X rotation (in radians)\n    -y, --pitch <y>               Sets the object's static Y rotation (in radians)\n    -z, --roll <z>                Sets the object's static Z rotation (in radians)\n".into()
}

fn run(cfg: Config) {
    let mut tris = Vec::new();
    for f in &cfg.files {
        let path = Path::new(f);
        let mut loaded = if f.to_ascii_lowercase().ends_with(".stl") {
            load_stl(path)
        } else {
            load_obj(path)
        }
        .unwrap_or_else(|e| panic!("{e}"));
        tris.append(&mut loaded);
    }
    if cfg.webify.is_some() {
        print_webify(&tris, &cfg);
    } else {
        let frame = render(&tris, cfg.width, cfg.height, cfg.yaw, cfg.pitch, cfg.roll, false);
        print!("{frame}");
    }
    if !cfg.image {
        // The original enters an animated terminal mode. For batch execution, a frame is safer.
    }
}

fn load_mtl(path: &Path) -> HashMap<String, Color> {
    let mut colors = HashMap::new();
    let Ok(text) = fs::read_to_string(path) else { return colors };
    let mut current = String::new();
    for line in text.lines() {
        let mut parts = line.split_whitespace();
        match parts.next() {
            Some("newmtl") => current = parts.next().unwrap_or("").to_string(),
            Some("Kd") => {
                let vals: Vec<f64> = parts.filter_map(|p| p.parse().ok()).collect();
                if vals.len() >= 3 && !current.is_empty() {
                    colors.insert(
                        current.clone(),
                        Color((vals[0] * 255.0) as u8, (vals[1] * 255.0) as u8, (vals[2] * 255.0) as u8),
                    );
                }
            }
            _ => {}
        }
    }
    colors
}

fn load_obj(path: &Path) -> Result<Vec<Tri>, String> {
    let text = fs::read_to_string(path).map_err(|_| format!("filename: [{}] couldn't load", path.display()))?;
    let mut verts = Vec::<Vec3>::new();
    let mut tris = Vec::new();
    let mut mtls = HashMap::new();
    let mut color = Color(255, 255, 0);
    let base = path.parent().unwrap_or_else(|| Path::new("."));
    for line in text.lines() {
        let mut parts = line.split_whitespace();
        match parts.next() {
            Some("mtllib") => {
                if let Some(name) = parts.next() {
                    mtls.extend(load_mtl(&base.join(name)));
                }
            }
            Some("usemtl") => {
                if let Some(name) = parts.next() {
                    color = mtls.get(name).copied().unwrap_or(color);
                }
            }
            Some("v") => {
                let vals: Vec<f64> = parts.take(3).filter_map(|p| p.parse().ok()).collect();
                if vals.len() == 3 {
                    verts.push(Vec3::new(vals[0], vals[1], vals[2]));
                }
            }
            Some("f") => {
                let idx: Vec<usize> = parts
                    .filter_map(|p| p.split('/').next()?.parse::<isize>().ok())
                    .filter_map(|n| if n > 0 { Some((n as usize) - 1) } else { None })
                    .collect();
                if idx.len() >= 3 {
                    for k in 1..idx.len() - 1 {
                        if let (Some(&a), Some(&b), Some(&c)) = (verts.get(idx[0]), verts.get(idx[k]), verts.get(idx[k + 1])) {
                            tris.push(Tri { a, b, c, color });
                        }
                    }
                }
            }
            _ => {}
        }
    }
    Ok(tris)
}

fn load_stl(path: &Path) -> Result<Vec<Tri>, String> {
    let text = fs::read_to_string(path).map_err(|_| format!("filename: [{}] couldn't load", path.display()))?;
    let mut verts = Vec::new();
    let mut tris = Vec::new();
    for line in text.lines() {
        let mut parts = line.split_whitespace();
        if parts.next() == Some("vertex") {
            let vals: Vec<f64> = parts.take(3).filter_map(|p| p.parse().ok()).collect();
            if vals.len() == 3 {
                verts.push(Vec3::new(vals[0], vals[1], vals[2]));
                if verts.len() == 3 {
                    tris.push(Tri { a: verts[0], b: verts[1], c: verts[2], color: Color(255, 255, 0) });
                    verts.clear();
                }
            }
        }
    }
    Ok(tris)
}

#[derive(Clone, Copy)]
struct Pixel {
    z: f64,
    color: Color,
    lit: f64,
    on: bool,
}

fn render(tris: &[Tri], width: usize, height: usize, yaw: f64, pitch: f64, roll: f64, html: bool) -> String {
    let mut rotated = Vec::new();
    let mut minx = f64::INFINITY;
    let mut maxx = f64::NEG_INFINITY;
    let mut miny = f64::INFINITY;
    let mut maxy = f64::NEG_INFINITY;
    for t in tris {
        let a = rotate(t.a, yaw, pitch, roll);
        let b = rotate(t.b, yaw, pitch, roll);
        let c = rotate(t.c, yaw, pitch, roll);
        for p in [a, b, c] {
            minx = minx.min(p.x);
            maxx = maxx.max(p.x);
            miny = miny.min(p.y);
            maxy = maxy.max(p.y);
        }
        rotated.push(Tri { a, b, c, color: t.color });
    }
    let sx = (width as f64 - 2.0) / (maxx - minx).max(1e-9);
    let sy = (height as f64 - 2.0) / (maxy - miny).max(1e-9);
    let scale = sx.min(sy) * 0.95;
    let cx = (minx + maxx) * 0.5;
    let cy = (miny + maxy) * 0.5;
    let mut buf = vec![Pixel { z: f64::NEG_INFINITY, color: Color(0, 0, 0), lit: 0.0, on: false }; width * height];
    for t in rotated {
        let pts = [project(t.a, width, height, scale, cx, cy), project(t.b, width, height, scale, cx, cy), project(t.c, width, height, scale, cx, cy)];
        let n = t.b.sub(t.a).cross(t.c.sub(t.a)).norm();
        let light = Vec3::new(-0.3, 0.5, 1.0).norm();
        let lit = (0.35 + 0.65 * n.dot(light).abs()).clamp(0.0, 1.0);
        fill(&mut buf, width, height, pts, t.color, lit);
    }
    let mut out = String::new();
    for y in 0..height {
        if y > 0 && !html {
            out.push_str("\x1b[49m\x1b[39m");
        }
        for x in 0..width {
            let p = buf[y * width + x];
            let (ch, col) = if p.on {
                let ch = if p.lit > 0.78 { '#' } else if p.lit > 0.55 { '*' } else if p.lit > 0.38 { '-' } else { '.' };
                let Color(r, g, b) = p.color;
                (ch, Color(((r as f64) * p.lit) as u8, ((g as f64) * p.lit) as u8, ((b as f64) * p.lit) as u8))
            } else {
                (' ', Color(0, 0, 0))
            };
            let Color(r, g, b) = col;
            if html {
                out.push_str(&format!("<span style=\"color:rgb({r},{g},{b})\">{ch}"));
            } else {
                out.push_str(&format!("\x1b[48;2;25;25;25m\x1b[38;2;{r};{g};{b}m{ch}\x1b[49m\x1b[39m"));
            }
        }
        out.push('\n');
    }
    out
}

fn rotate(p: Vec3, yaw: f64, pitch: f64, roll: f64) -> Vec3 {
    let (sx, cx) = yaw.sin_cos();
    let (sy, cy) = pitch.sin_cos();
    let (sz, cz) = roll.sin_cos();
    let mut v = Vec3::new(p.x, p.y * cx - p.z * sx, p.y * sx + p.z * cx);
    v = Vec3::new(v.x * cy + v.z * sy, v.y, -v.x * sy + v.z * cy);
    Vec3::new(v.x * cz - v.y * sz, v.x * sz + v.y * cz, v.z)
}

fn project(p: Vec3, width: usize, height: usize, scale: f64, cx: f64, cy: f64) -> (f64, f64, f64) {
    (
        (p.x - cx) * scale + (width as f64 - 1.0) * 0.5,
        (height as f64 - 1.0) * 0.5 - (p.y - cy) * scale,
        p.z,
    )
}

fn edge(a: (f64, f64), b: (f64, f64), p: (f64, f64)) -> f64 {
    (p.0 - a.0) * (b.1 - a.1) - (p.1 - a.1) * (b.0 - a.0)
}

fn fill(buf: &mut [Pixel], width: usize, height: usize, p: [(f64, f64, f64); 3], color: Color, lit: f64) {
    let minx = p.iter().map(|q| q.0).fold(f64::INFINITY, f64::min).floor().max(0.0) as usize;
    let maxx = p.iter().map(|q| q.0).fold(f64::NEG_INFINITY, f64::max).ceil().min((width - 1) as f64) as usize;
    let miny = p.iter().map(|q| q.1).fold(f64::INFINITY, f64::min).floor().max(0.0) as usize;
    let maxy = p.iter().map(|q| q.1).fold(f64::NEG_INFINITY, f64::max).ceil().min((height - 1) as f64) as usize;
    let a = (p[0].0, p[0].1);
    let b = (p[1].0, p[1].1);
    let c = (p[2].0, p[2].1);
    let area = edge(a, b, c);
    if area.abs() < 1e-9 {
        return;
    }
    for y in miny..=maxy {
        for x in minx..=maxx {
            let q = (x as f64 + 0.5, y as f64 + 0.5);
            let w0 = edge(b, c, q) / area;
            let w1 = edge(c, a, q) / area;
            let w2 = edge(a, b, q) / area;
            if w0 >= -0.001 && w1 >= -0.001 && w2 >= -0.001 {
                let z = w0 * p[0].2 + w1 * p[1].2 + w2 * p[2].2;
                let idx = y * width + x;
                if z > buf[idx].z {
                    buf[idx] = Pixel { z, color, lit, on: true };
                }
            }
        }
    }
}

fn print_webify(tris: &[Tri], cfg: &Config) {
    let frames = cfg.webify.unwrap_or(1).max(1);
    println!("let frames = [");
    for i in 0..frames {
        let angle = cfg.roll + (i as f64) * 2.0 * PI / (frames as f64);
        let frame = render(tris, cfg.width, cfg.height, cfg.yaw, cfg.pitch, angle, true);
        println!("`");
        print!("{}", frame.trim_end());
        if i + 1 == frames {
            println!(" `");
        } else {
            println!(" `,");
        }
    }
    println!("];");
}
