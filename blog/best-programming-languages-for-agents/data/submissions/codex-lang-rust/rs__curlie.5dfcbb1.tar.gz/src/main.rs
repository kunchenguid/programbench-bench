use serde_json::{Map, Value};
use std::env;
use std::io::{self, Write};
use std::process::Command;

const METHODS: &[&str] = &["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"];

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    std::process::exit(run(args));
}

fn run(args: Vec<String>) -> i32 {
    if args.is_empty() {
        return exec_curl_help("all");
    }
    if args[0] == "--version" || args[0] == "-V" {
        return exec_passthrough("curl", &["--version".into()]);
    }
    if args[0] == "--help" || args[0] == "-h" {
        let category = if args.len() > 1 { args[1].as_str() } else { "--help" };
        return exec_curl_help(category);
    }

    let mut show_curl = false;
    let mut pretty = false;
    let mut rest = Vec::new();
    for arg in args {
        match arg.as_str() {
            "--curl" => show_curl = true,
            "--pretty" => pretty = true,
            _ => rest.push(arg),
        }
    }

    let parsed = parse(rest);
    if parsed.url.is_empty() {
        eprintln!("Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]");
        return 2;
    }
    eprintln!("{}", display_url(&parsed.url_with_query));

    let mut curl_args = parsed.curl_args;
    if let Some(m) = parsed.method {
        curl_args.push("-X".into());
        curl_args.push(m);
    }
    for h in parsed.headers {
        curl_args.push("-H".into());
        curl_args.push(h);
    }
    if parsed.has_body {
        curl_args.push("-d".into());
        curl_args.push(parsed.body_json);
    }
    curl_args.push(parsed.url_with_query.clone());
    curl_args.push("-s".into());
    curl_args.push("-S".into());
    if pretty {
        curl_args.push("-v".into());
    }
    if !parsed.has_body && !has_explicit_data(&curl_args) {
        curl_args.push("-d@-".into());
    }
    curl_args.push("-H".into());
    curl_args.push("Content-Type: application/json".into());
    curl_args.push("-H".into());
    curl_args.push("Accept: application/json, */*".into());

    if show_curl {
        println!("{}", format_command(&curl_args));
        return 0;
    }

    let out = match Command::new("curl").args(&curl_args).output() {
        Ok(o) => o,
        Err(e) => {
            eprintln!("failed to execute curl: {}", e);
            return 127;
        }
    };
    let _ = io::stderr().write_all(&out.stderr);
    if is_json_like(&out.stdout) {
        match serde_json::from_slice::<Value>(&out.stdout) {
            Ok(v) => print_colored_json(&v),
            Err(_) => {
                let _ = io::stdout().write_all(&out.stdout);
            }
        }
    } else {
        let _ = io::stdout().write_all(&out.stdout);
    }
    out.status.code().unwrap_or(1)
}

struct Parsed {
    curl_args: Vec<String>,
    method: Option<String>,
    url: String,
    url_with_query: String,
    headers: Vec<String>,
    body_json: String,
    has_body: bool,
}

fn parse(tokens: Vec<String>) -> Parsed {
    let mut curl_args = Vec::new();
    let mut pos = Vec::new();
    let mut i = 0;
    while i < tokens.len() {
        let t = &tokens[i];
        if t.starts_with('-') && t != "-" {
            curl_args.push(t.clone());
            if option_takes_value(t) && i + 1 < tokens.len() {
                i += 1;
                curl_args.push(tokens[i].clone());
            }
        } else {
            pos.push(t.clone());
        }
        i += 1;
    }

    let mut method = None;
    let mut idx = 0;
    if pos.len() >= 2 && METHODS.contains(&pos[0].as_str()) {
        method = Some(pos[0].clone());
        idx = 1;
    }
    let url = pos.get(idx).cloned().unwrap_or_default();
    idx += 1;

    let mut headers = Vec::new();
    let mut queries: Vec<(String, String)> = Vec::new();
    let mut body = Map::new();
    let mut passthrough = Vec::new();
    for item in pos.into_iter().skip(idx) {
        if let Some(p) = item.find(":=") {
            let key = &item[..p];
            let raw = &item[p + 2..];
            let val = serde_json::from_str::<Value>(raw).unwrap_or(Value::Null);
            body.insert(key.to_string(), val);
        } else if let Some(p) = item.find("==") {
            queries.push((item[..p].to_string(), item[p + 2..].to_string()));
        } else if let Some(p) = item.find('=') {
            body.insert(item[..p].to_string(), Value::String(item[p + 1..].to_string()));
        } else if item.contains(':') {
            headers.push(item);
        } else {
            passthrough.push(item);
        }
    }
    curl_args.extend(passthrough);

    let has_body = !body.is_empty();
    let body_json = if has_body {
        Value::Object(body).to_string()
    } else {
        String::new()
    };
    let mut url_with_query = url.clone();
    if !queries.is_empty() {
        url_with_query.push(if url_with_query.contains('?') { '&' } else { '?' });
        url_with_query.push_str(
            &queries
                .into_iter()
                .map(|(k, v)| format!("{}={}", k, v))
                .collect::<Vec<_>>()
                .join("&"),
        );
    }

    Parsed { curl_args, method, url, url_with_query, headers, body_json, has_body }
}

fn option_takes_value(opt: &str) -> bool {
    if opt.starts_with("--") {
        if opt.contains('=') {
            return false;
        }
        matches!(
            opt,
            "--header"
                | "--user"
                | "--request"
                | "--data"
                | "--data-raw"
                | "--data-binary"
                | "--data-ascii"
                                | "--url"
                | "--output"
                | "--connect-timeout"
                | "--max-time"
                | "--cookie"
                | "--cookie-jar"
                | "--user-agent"
                | "--referer"
                | "--proxy"
                | "--proxy-user"
                | "--cacert"
                | "--capath"
                | "--cert"
                | "--key"
                | "--request-target"
                | "--resolve"
                | "--write-out"
                | "--dump-header"
                | "--upload-file"
                | "--config"
        )
    } else {
        matches!(
            opt,
            "-H" | "-u" | "-X" | "-d" | "-o" | "-m" | "-A" | "-e" | "-x" | "-U" | "-b" | "-c" | "-D" | "-T" | "-K" | "-w"
        )
    }
}

fn display_url(url: &str) -> String {
    if url.starts_with("http://") || url.starts_with("https://") {
        url.to_string()
    } else {
        format!("http://{}", url)
    }
}

fn format_command(args: &[String]) -> String {
    let mut s = String::from("curl");
    for a in args {
        s.push(' ');
        s.push_str(&quote_arg(a));
    }
    s
}

fn quote_arg(a: &str) -> String {
    if a == "Content-Type: application/json" || a == "Accept: application/json, */*" {
        return format!("\"{}\"", a);
    }
    if a.contains(' ') {
        format!("\"{}\"", a.replace('"', "\\\""))
    } else {
        a.to_string()
    }
}

fn has_explicit_data(args: &[String]) -> bool {
    args.iter().any(|a| a == "-d")
}

fn exec_curl_help(category: &str) -> i32 {
    let out = match Command::new("curl").arg("--help").arg(category).output() {
        Ok(o) => o,
        Err(e) => { eprintln!("curl: {}", e); return 127; }
    };
    let text = String::from_utf8_lossy(&out.stdout);
    let replaced = text.replacen("Usage: curl [options...] <url>", "Usage: ./executable [options...] [METHOD] URL [REQUEST_ITEM [REQUEST_ITEM ...]]", 1);
    print!("{}", replaced);
    let _ = io::stderr().write_all(&out.stderr);
    out.status.code().unwrap_or(1)
}

fn exec_passthrough(cmd: &str, args: &[String]) -> i32 {
    match Command::new(cmd).args(args).status() {
        Ok(s) => s.code().unwrap_or(1),
        Err(e) => {
            eprintln!("{}: {}", cmd, e);
            127
        }
    }
}

fn is_json_like(b: &[u8]) -> bool {
    let s = String::from_utf8_lossy(b);
    let t = s.trim_start();
    t.starts_with('{') || t.starts_with('[')
}

fn print_colored_json(v: &Value) {
    println!("\x1b[37m{}\x1b[0m", serde_json::to_string_pretty(v).unwrap_or_else(|_| v.to_string()));
}
