use regex::Regex;
use std::env;
use std::fs;
use std::io::{self, Read, Write};

const HELP: &str = "tuc 1.3.0
Cut text (or bytes) where a delimiter matches, then keep the desired parts.

USAGE:
    tuc [FLAGS] [OPTIONS] < input
    tuc [FLAGS] [OPTIONS] filepath

FLAGS:
    -g, --greedy-delimiter        Match consecutive delimiters as if it was one
    -p, --compress-delimiter      Print only the first delimiter of a sequence
    -s, --only-delimited          Print only lines containing the delimiter
    -V, --version                 Print version information
    -z, --zero-terminated         Line delimiter is NUL (\\0), not LF (\\n)
    -h, --help                    Print this help and exit
    -m, --complement              Invert fields (e.g. '2' becomes '1,3:')
    -j, --(no-)join               Print selected parts with delimiter in between
    --json                        Print fields as a JSON array of strings
    --no-mmap                     Disable memory mapping

OPTIONS:
    -f, --fields <bounds>         Fields to keep, 1-indexed, comma separated.
    -b, --bytes <bounds>          Same as --fields, but it keeps bytes
    -c, --characters <bounds>     Same as --fields, but it keeps characters
    -l, --lines <bounds>          Same as --fields, but it keeps lines
    -d, --delimiter <delimiter>   Delimiter used by --fields to cut the text
                                  [default: \\t]
    -e, --regex <some regex>      Use a regular expression as delimiter
    -r, --replace-delimiter <new> Replace the delimiter with the provided text.
                                  Implies --join
    -t, --trim <type>             Trim the delimiter (greedy). Valid values are
                                  (l|L)eft, (r|R)ight, (b|B)oth
        --fallback-oob <fallback> Generic fallback output for any field that
                                  cannot be found (oob stands for out of bound).
    -M, --fixed-memory <size>     Read the input in chunks of <size> kilobytes.
";

const SHORT: &str = "tuc 1.3.0 - Created by Riccardo Attilio Galli

Cut text (or bytes) where a delimiter matches, then keep the desired parts.

Some examples:

    $ echo \"a/b/c\" | tuc -d / -f 1,-1
    ac

    $ echo \"a/b/c\" | tuc -d / -f 2:
    b/c

    $ echo \"hello.bak\" | tuc -d . -f 'mv {1:} {1}'
    mv hello.bak hello

    $ printf \"a\\nb\\nc\\nd\\ne\" | tuc -l 2:-2
    b
    c
    d

Run `tuc --help` for more detailed information.
Send bug reports to: https://github.com/riquito/tuc/issues
";

#[derive(Clone, Copy, PartialEq)]
enum Mode {
    Fields,
    Bytes,
    Chars,
    Lines,
}

struct Opts {
    mode: Mode,
    bounds: String,
    delimiter: String,
    regex: Option<Regex>,
    greedy: bool,
    compress: bool,
    only_delimited: bool,
    zero: bool,
    complement: bool,
    join: bool,
    json: bool,
    replace: Option<String>,
    fallback: Option<String>,
    filepath: Option<String>,
}

#[derive(Clone)]
struct Spec {
    start: Option<isize>,
    end: Option<isize>,
    fallback: Option<String>,
    range: bool,
}

fn main() {
    match real_main() {
        Ok(code) => std::process::exit(code),
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(1);
        }
    }
}

fn real_main() -> Result<i32, String> {
    let opts = parse_args()?;
    let mut input = Vec::new();
    if let Some(path) = &opts.filepath {
        input = fs::read(path).map_err(|e| e.to_string())?;
    } else {
        io::stdin().read_to_end(&mut input).map_err(|e| e.to_string())?;
        if input.is_empty() && atty_stdin() {
            eprint!("{SHORT}");
            return Ok(1);
        }
    }
    let (out, err) = match opts.mode {
        Mode::Fields => process_records(&input, &opts, process_fields_record)?,
        Mode::Chars => process_records(&input, &opts, process_chars_record)?,
        Mode::Bytes => (process_bytes(&input, &opts)?, None),
        Mode::Lines => (process_lines(&input, &opts)?, None),
    };
    io::stdout().write_all(&out).map_err(|e| e.to_string())?;
    if let Some(e) = err {
        eprintln!("{e}");
        Ok(1)
    } else {
        Ok(0)
    }
}

fn atty_stdin() -> bool {
    unsafe { libc_isatty(0) == 1 }
}

extern "C" {
    fn isatty(fd: i32) -> i32;
}
unsafe fn libc_isatty(fd: i32) -> i32 {
    isatty(fd)
}

fn parse_args() -> Result<Opts, String> {
    let mut opts = Opts {
        mode: Mode::Fields,
        bounds: "1:".into(),
        delimiter: "\t".into(),
        regex: None,
        greedy: false,
        compress: false,
        only_delimited: false,
        zero: false,
        complement: false,
        join: false,
        json: false,
        replace: None,
        fallback: None,
        filepath: None,
    };
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() && atty_stdin() {
        eprint!("{SHORT}");
        return Err(String::new());
    }
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        match a.as_str() {
            "-h" | "--help" => {
                print!("{HELP}");
                return OkExit::ok();
            }
            "-V" | "--version" => {
                println!("tuc 1.3.0");
                return OkExit::ok();
            }
            "-g" | "--greedy-delimiter" => opts.greedy = true,
            "-p" | "--compress-delimiter" => opts.compress = true,
            "-s" | "--only-delimited" => opts.only_delimited = true,
            "-z" | "--zero-terminated" => opts.zero = true,
            "-m" | "--complement" => opts.complement = true,
            "-j" | "--join" => opts.join = true,
            "--no-join" => opts.join = false,
            "--json" => opts.json = true,
            "--no-mmap" => {}
            "-M" | "--fixed-memory" => {
                i += 1;
                if i >= args.len() { return Err(format!("the '{a}' option doesn't have an associated value")); }
            }
            "-f" | "--fields" | "-b" | "--bytes" | "-c" | "--characters" | "-l" | "--lines"
            | "-d" | "--delimiter" | "-e" | "--regex" | "-r" | "--replace-delimiter"
            | "-t" | "--trim" | "--fallback-oob" => {
                i += 1;
                if i >= args.len() { return Err(format!("the '{a}' option doesn't have an associated value")); }
                let v = args[i].clone();
                match a.as_str() {
                    "-f" | "--fields" => { opts.mode = Mode::Fields; opts.bounds = v; }
                    "-b" | "--bytes" => { opts.mode = Mode::Bytes; opts.bounds = v; }
                    "-c" | "--characters" => { opts.mode = Mode::Chars; opts.bounds = v; }
                    "-l" | "--lines" => { opts.mode = Mode::Lines; opts.bounds = v; opts.join = true; }
                    "-d" | "--delimiter" => opts.delimiter = v,
                    "-e" | "--regex" => opts.regex = Some(Regex::new(&v).map_err(|e| format!("regex parse error: {e}"))?),
                    "-r" | "--replace-delimiter" => { opts.replace = Some(v); opts.join = true; }
                    "-t" | "--trim" => { opts.greedy = true; }
                    "--fallback-oob" => opts.fallback = Some(v),
                    _ => {}
                }
            }
            _ if a.starts_with('-') => return Err(format!("tuc: unexpected arguments: [\"{}\"]\nTry 'tuc --help' for more information.", a)),
            _ => {
                if opts.filepath.is_none() {
                    opts.filepath = Some(a);
                } else {
                    return Err(format!("tuc: unexpected arguments: [\"{}\"]", a));
                }
            }
        }
        i += 1;
    }
    if opts.regex.is_some() && opts.join && opts.replace.is_none() {
        return Err("tuc: runtime error. Cannot use --regex and --join without --replace-delimiter".into());
    }
    Ok(opts)
}

struct OkExit;
impl OkExit {
    fn ok<T>() -> Result<T, String> {
        std::process::exit(0)
    }
}

fn process_records(input: &[u8], opts: &Opts, f: fn(&str, &Opts) -> Result<Vec<String>, String>) -> Result<(Vec<u8>, Option<String>), String> {
    let sep = if opts.zero { b'\0' } else { b'\n' };
    let text = String::from_utf8_lossy(input);
    let mut out = Vec::new();
    let mut any = false;
    for rec in text.split(sep as char) {
        if rec.is_empty() && input.last() == Some(&sep) && !any {
            continue;
        }
        if rec.is_empty() && input.last() == Some(&sep) {
            break;
        }
        if opts.mode == Mode::Fields && opts.only_delimited && !record_has_delim(rec, opts) {
            continue;
        }
        let pieces = match f(rec, opts) {
            Ok(p) => p,
            Err(e) => return Ok((out, Some(e))),
        };
        let line = render(&pieces, opts);
        out.extend_from_slice(line.as_bytes());
        out.push(sep);
        any = true;
    }
    Ok((out, None))
}

fn record_has_delim(rec: &str, opts: &Opts) -> bool {
    if let Some(re) = &opts.regex {
        re.is_match(rec)
    } else {
        rec.contains(&opts.delimiter)
    }
}

fn process_fields_record(rec: &str, opts: &Opts) -> Result<Vec<String>, String> {
    if opts.bounds.contains('{') {
        return Ok(vec![render_template(&opts.bounds, rec, opts)?]);
    }
    let specs = parse_specs(&opts.bounds)?;
    let (fields, delims) = split_fields(rec, opts);
    let mut specs = specs;
    if opts.complement {
        specs = complement_specs(&specs, fields.len());
    }
    select_pieces(&fields, Some(&delims), &specs, opts)
}

fn split_fields(rec: &str, opts: &Opts) -> (Vec<String>, Vec<String>) {
    if let Some(re) = &opts.regex {
        let mut fields = Vec::new();
        let mut delims = Vec::new();
        let mut last = 0;
        for m in re.find_iter(rec) {
            fields.push(rec[last..m.start()].to_string());
            delims.push(m.as_str().to_string());
            last = m.end();
        }
        fields.push(rec[last..].to_string());
        (fields, delims)
    } else {
        let d = opts.delimiter.as_str();
        if d.is_empty() {
            return (vec![rec.to_string()], vec![]);
        }
        let mut fields = Vec::new();
        let mut delims = Vec::new();
        let mut pos = 0;
        while let Some(rel) = rec[pos..].find(d) {
            let idx = pos + rel;
            fields.push(rec[pos..idx].to_string());
            let mut end = idx + d.len();
            if opts.greedy || opts.compress {
                while rec[end..].starts_with(d) {
                    end += d.len();
                }
            }
            delims.push(if opts.compress { d.to_string() } else { rec[idx..end].to_string() });
            pos = end;
        }
        fields.push(rec[pos..].to_string());
        (fields, delims)
    }
}

fn process_chars_record(rec: &str, opts: &Opts) -> Result<Vec<String>, String> {
    let chars: Vec<String> = rec.chars().map(|c| c.to_string()).collect();
    let mut specs = parse_specs(&opts.bounds)?;
    if opts.complement {
        specs = complement_specs(&specs, chars.len());
    }
    select_pieces(&chars, None, &specs, opts)
}

fn process_bytes(input: &[u8], opts: &Opts) -> Result<Vec<u8>, String> {
    let mut specs = parse_specs(&opts.bounds)?;
    if opts.complement {
        specs = complement_specs(&specs, input.len());
    }
    let mut pieces: Vec<Vec<u8>> = Vec::new();
    for spec in &specs {
        if spec.range {
            let st = norm(spec.start, input.len(), 0);
            let en = norm(spec.end, input.len(), input.len().saturating_sub(1));
            match (st, en) {
                (Some(a), Some(b)) if a <= b => pieces.push(input[a..=b].to_vec()),
                _ => pieces.push(fallback(spec, opts)?.into_bytes()),
            }
        } else if let Some(i) = norm(spec.start, input.len(), 0) {
            pieces.push(vec![input[i]]);
        } else {
            pieces.push(fallback(spec, opts)?.into_bytes());
        }
    }
    if opts.json {
        let strings: Vec<String> = pieces.iter().map(|p| String::from_utf8_lossy(p).to_string()).collect();
        Ok(render(&strings, opts).into_bytes())
    } else if opts.join {
        let joiner = opts.replace.as_deref().unwrap_or(&opts.delimiter).as_bytes();
        let mut out = Vec::new();
        for (i, p) in pieces.iter().enumerate() {
            if i > 0 { out.extend_from_slice(joiner); }
            out.extend_from_slice(p);
        }
        Ok(out)
    } else {
        Ok(pieces.concat())
    }
}

fn process_lines(input: &[u8], opts: &Opts) -> Result<Vec<u8>, String> {
    let sep = if opts.zero { b'\0' } else { b'\n' };
    let text = String::from_utf8_lossy(input);
    let mut lines: Vec<String> = text.split(sep as char).map(|s| s.to_string()).collect();
    if input.last() == Some(&sep) {
        lines.pop();
    }
    let mut specs = parse_specs(&opts.bounds)?;
    if opts.complement {
        specs = complement_specs(&specs, lines.len());
    }
    let sep_s = (sep as char).to_string();
    let delims = vec![sep_s.clone(); lines.len().saturating_sub(1)];
    let pieces = select_pieces(&lines, Some(&delims), &specs, opts)?;
    let joiner = opts.replace.as_deref().unwrap_or(&sep_s);
    let s = if opts.join { pieces.join(joiner) } else { pieces.concat() };
    let mut out = s.into_bytes();
    if !out.is_empty() {
        out.push(sep);
    }
    Ok(out)
}

fn parse_specs(s: &str) -> Result<Vec<Spec>, String> {
    let mut specs = Vec::new();
    for raw in s.split(',') {
        if raw.is_empty() { continue; }
        let (part, fb) = match raw.split_once('=') {
            Some((a, b)) => (a, Some(b.to_string())),
            None => (raw, None),
        };
        if let Some((a, b)) = part.split_once(':') {
            specs.push(Spec {
                start: if a.is_empty() { None } else { Some(parse_num(a, s)?) },
                end: if b.is_empty() { None } else { Some(parse_num(b, s)?) },
                fallback: fb,
                range: true,
            });
        } else {
            specs.push(Spec { start: Some(parse_num(part, s)?), end: None, fallback: fb, range: false });
        }
    }
    Ok(specs)
}

fn parse_num(n: &str, whole: &str) -> Result<isize, String> {
    n.parse::<isize>().map_err(|_| format!("failed to parse '{}': Not a number `{}`", whole, n))
}

fn norm(n: Option<isize>, len: usize, default: usize) -> Option<usize> {
    match n {
        None => Some(default),
        Some(v) if v > 0 => {
            let u = v as usize;
            if u >= 1 && u <= len { Some(u - 1) } else { None }
        }
        Some(v) if v < 0 => {
            let idx = len as isize + v;
            if idx >= 0 && idx < len as isize { Some(idx as usize) } else { None }
        }
        _ => None,
    }
}

fn select_pieces(items: &[String], delims: Option<&[String]>, specs: &[Spec], opts: &Opts) -> Result<Vec<String>, String> {
    let mut out = Vec::new();
    for spec in specs {
        if spec.range {
            let st = norm(spec.start, items.len(), 0);
            let en = norm(spec.end, items.len(), items.len().saturating_sub(1));
            match (st, en) {
                (Some(a), Some(b)) if a <= b => {
                    let mut s = String::new();
                    for i in a..=b {
                        s.push_str(&items[i]);
                        if let Some(ds) = delims {
                            if i < b && i < ds.len() {
                                s.push_str(&ds[i]);
                            }
                        }
                    }
                    out.push(s);
                }
                _ => out.push(fallback(spec, opts)?),
            }
        } else {
            let idx = norm(spec.start, items.len(), 0);
            if let Some(i) = idx {
                out.push(items[i].clone());
            } else {
                out.push(fallback(spec, opts)?);
            }
        }
    }
    Ok(out)
}

fn fallback(spec: &Spec, opts: &Opts) -> Result<String, String> {
    if let Some(f) = &spec.fallback {
        Ok(f.clone())
    } else if let Some(f) = &opts.fallback {
        Ok(f.clone())
    } else {
        let n = spec.start.or(spec.end).unwrap_or(0);
        Err(format!("Error: Out of bounds: {n}"))
    }
}

fn complement_specs(specs: &[Spec], len: usize) -> Vec<Spec> {
    let mut selected = vec![false; len];
    for sp in specs {
        let a = norm(sp.start, len, 0);
        let b = if sp.range { norm(sp.end, len, len.saturating_sub(1)) } else { a };
        if let (Some(a), Some(b)) = (a, b) {
            for i in a.min(b)..=a.max(b) {
                if i < len { selected[i] = true; }
            }
        }
    }
    let mut res = Vec::new();
    let mut i = 0;
    while i < len {
        if selected[i] { i += 1; continue; }
        let start = i;
        while i + 1 < len && !selected[i + 1] {
            i += 1;
        }
        if start == i {
            res.push(Spec { start: Some((start + 1) as isize), end: None, fallback: None, range: false });
        } else {
            res.push(Spec { start: Some((start + 1) as isize), end: Some((i + 1) as isize), fallback: None, range: true });
        }
        i += 1;
    }
    res
}

fn render(pieces: &[String], opts: &Opts) -> String {
    if opts.json {
        let mut s = String::from("[");
        for (i, p) in pieces.iter().enumerate() {
            if i > 0 { s.push(','); }
            s.push('"');
            for ch in p.chars() {
                match ch {
                    '"' => s.push_str("\\\""),
                    '\\' => s.push_str("\\\\"),
                    '\n' => s.push_str("\\n"),
                    '\r' => s.push_str("\\r"),
                    '\t' => s.push_str("\\t"),
                    c if c < ' ' => s.push_str(&format!("\\u{:04x}", c as u32)),
                    c => s.push(c),
                }
            }
            s.push('"');
        }
        s.push(']');
        s
    } else if opts.join {
        pieces.join(opts.replace.as_deref().unwrap_or(&opts.delimiter))
    } else {
        pieces.concat()
    }
}

fn render_template(tmpl: &str, rec: &str, opts: &Opts) -> Result<String, String> {
    let (fields, delims) = split_fields(rec, opts);
    let mut out = String::new();
    let mut chars = tmpl.chars().peekable();
    while let Some(ch) = chars.next() {
        if ch == '{' {
            if chars.peek() == Some(&'{') {
                chars.next();
                out.push('{');
                continue;
            }
            let mut inside = String::new();
            while let Some(c) = chars.next() {
                if c == '}' { break; }
                inside.push(c);
            }
            let specs = parse_specs(&inside)?;
            let pieces = select_pieces(&fields, Some(&delims), &specs, opts)?;
            out.push_str(&render(&pieces, opts));
        } else if ch == '}' && chars.peek() == Some(&'}') {
            chars.next();
            out.push('}');
        } else {
            out.push(ch);
        }
    }
    Ok(out)
}
