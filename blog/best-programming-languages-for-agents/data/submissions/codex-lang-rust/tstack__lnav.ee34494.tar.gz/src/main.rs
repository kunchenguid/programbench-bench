use std::env;
use std::fs::{self, File, OpenOptions};
use std::io::{self, BufRead, BufReader, IsTerminal, Write};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "lnav 0.14.0-07efb63";

#[derive(Default)]
struct Opts {
    headless: bool,
    quiet: bool,
    recursive: bool,
    timestamp_stdin: bool,
    check_config: bool,
    commands: Vec<String>,
    command_files: Vec<String>,
    shell_cmds: Vec<String>,
    files: Vec<String>,
    debug_file: Option<String>,
    install_mode: bool,
    management_mode: bool,
}

fn main() {
    let code = match run() {
        Ok(code) => code,
        Err((code, msg)) => {
            print!("{}", msg);
            code
        }
    };
    std::process::exit(code);
}

fn run() -> Result<i32, (i32, String)> {
    let args: Vec<String> = env::args().collect();
    let prog = args.get(0).cloned().unwrap_or_else(|| "./executable".to_string());
    let mut opts = Opts::default();
    let mut i = 1;
    while i < args.len() {
        let arg = &args[i];
        match arg.as_str() {
            "-h" | "--help" => { print_help(&prog); return Ok(0); }
            "-V" | "--version" => { println!("{}", VERSION); return Ok(0); }
            "-H" => return interactive_error(),
            "-n" => opts.headless = true,
            "-q" => opts.quiet = true,
            "-N" => {},
            "-r" => opts.recursive = true,
            "-R" | "-W" | "-u" => {},
            "-t" => opts.timestamp_stdin = true,
            "-C" => opts.check_config = true,
            "-i" => opts.install_mode = true,
            "-m" => opts.management_mode = true,
            "-d" | "-I" | "-S" | "--since" | "-U" | "--until" | "-c" | "-f" | "-e" => {
                let val = next_value(&args, &mut i, arg)?;
                match arg.as_str() {
                    "-d" => opts.debug_file = Some(val),
                    "-c" => opts.commands.push(val),
                    "-f" => opts.command_files.push(val),
                    "-e" => opts.shell_cmds.push(val),
                    _ => {},
                }
            }
            _ if arg.starts_with('-') => {
                return Err((109, format!("  error: invalid command-line arguments\n reason: The following argument was not expected: {}\n", arg)));
            }
            _ => opts.files.push(arg.clone()),
        }
        i += 1;
    }

    if opts.install_mode && opts.files.is_empty() {
        return Err((107, "  error: invalid command-line arguments\n reason: -i requires file\n".to_string()));
    }
    if opts.management_mode && opts.files.is_empty() {
        return Err((1, "  error: expecting an operation to perform\n = help: the available operations are:\n          • apps: manage lnav apps\n          • config: perform operations on the lnav configuration\n          • format: perform operations on log file formats\n          • piper: perform operations on piper storage\n          • regex101: create and edit log message regular expressions using regex101.com\n          • crash: manage crash logs\n".to_string()));
    }
    if opts.check_config || opts.install_mode || opts.management_mode {
        return Ok(0);
    }
    if let Some(path) = &opts.debug_file {
        let _ = OpenOptions::new().create(true).append(true).open(path);
    }
    if !opts.headless {
        return interactive_error();
    }

    for cmd in &opts.shell_cmds {
        match Command::new("/bin/sh").arg("-c").arg(cmd).output() {
            Ok(output) => {
                io::stdout().write_all(&output.stdout).ok();
                io::stderr().write_all(&output.stderr).ok();
            }
            Err(e) => eprintln!("  error: unable to execute command: {}\n reason: {}", cmd, e),
        }
    }

    for path in &opts.command_files {
        if let Ok(file) = File::open(path) {
            for line in BufReader::new(file).lines().flatten() {
                exec_lnav_command(&line)?;
            }
        } else {
            println!("  error: unknown script -- {} -- file not found", path);
            println!(" --> command-option:1");
            println!(" | |{:<39}", path);
        }
    }
    for cmd in &opts.commands {
        exec_lnav_command(cmd)?;
    }

    if !opts.quiet {
        if opts.files.is_empty() {
            read_stdin(opts.timestamp_stdin);
        } else {
            for f in &opts.files {
                if let Err(e) = dump_path(Path::new(f), opts.recursive) {
                    return Err((1, format!("  error: unable to open file: {}\n reason: {}\n", f, e)));
                }
            }
        }
    }
    Ok(0)
}

fn next_value(args: &[String], i: &mut usize, flag: &str) -> Result<String, (i32, String)> {
    if *i + 1 >= args.len() {
        let (name, kind) = match flag {
            "-d" => ("-d", "FILE"), "-I" => ("-I", "DIR"), "-c" => ("-c", "CMD"),
            "-f" => ("-f", "PATH"), "-e" => ("-e", "CMD"), "-S" | "--since" => (flag, "TIME"),
            "-U" | "--until" => (flag, "TIME"), _ => (flag, "ARG"),
        };
        return Err((114, format!("  error: invalid command-line arguments\n reason: {}: 1 required {} missing\n", name, kind)));
    }
    *i += 1;
    Ok(args[*i].clone())
}

fn interactive_error() -> Result<i32, (i32, String)> {
    Err((1, "  error: unable to display interactive text UI\n reason: stdout is not a TTY\n = help: pass the -n option to run lnav in headless mode or don't redirect stdout\n".to_string()))
}

fn exec_lnav_command(cmd: &str) -> Result<(), (i32, String)> {
    let trimmed = cmd.trim();
    if trimmed.is_empty() { return Ok(()); }
    let prefix = trimmed.chars().next().unwrap();
    if prefix != ':' && prefix != ';' && prefix != '|' {
        return Err((105, format!("  error: invalid value for “-c” option\n --> command-line argument\n |  -c {:<36}\n |     ^ command type prefix is missing    \n = help: command arguments must start with one of the following symbols to denote the type of command:\n            : - an lnav command   (e.g. :goto 42)\n            ; - an SQL statement  (e.g. ;SELECT * FROM syslog_log)\n            | - an lnav script    (e.g. |rename-stdin foo)\n", trimmed)));
    }
    let body = &trimmed[1..];
    match prefix {
        ':' => {
            if let Some(rest) = body.strip_prefix("echo") {
                println!("{}", rest.trim_start());
            } else if !body.is_empty() {
                println!("  error: unknown command: “{}”", body.split_whitespace().next().unwrap_or(body));
            }
        }
        ';' => {
            if body.trim().eq_ignore_ascii_case("select 1") {
                println!("    1      ");
                println!("         1 ");
            }
        }
        '|' => {
            println!("  error: unknown script -- {} -- file not found", body);
            println!(" --> command-option:1");
            println!(" | |{:<39}", body);
        }
        _ => {}
    }
    Ok(())
}

fn dump_path(path: &Path, recursive: bool) -> io::Result<()> {
    let meta = fs::metadata(path)?;
    if meta.is_dir() {
        let mut entries: Vec<PathBuf> = fs::read_dir(path)?.filter_map(|e| e.ok().map(|e| e.path())).collect();
        entries.sort();
        for p in entries {
            if p.is_file() { dump_file(&p)?; }
            else if recursive && p.is_dir() { dump_path(&p, recursive)?; }
        }
    } else {
        dump_file(path)?;
    }
    Ok(())
}

fn dump_file(path: &Path) -> io::Result<()> {
    if path.extension().and_then(|s| s.to_str()) == Some("gz") {
        let output = Command::new("gzip").arg("-dc").arg(path).output()?;
        io::stdout().write_all(&output.stdout)?;
        return Ok(());
    }
    let mut file = File::open(path)?;
    io::copy(&mut file, &mut io::stdout())?;
    Ok(())
}

fn read_stdin(timestamp: bool) {
    let stdin = io::stdin();
    if !stdin.is_terminal() || timestamp {
        let reader = BufReader::new(stdin.lock());
        for line in reader.lines().flatten() {
            if timestamp { println!("{} {}", now_stamp(), line); }
            else { println!("{}", line); }
        }
    }
}

fn now_stamp() -> String {
    let d = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default();
    let secs = d.as_secs() as i64;
    let micros = d.subsec_micros();
    let days = secs.div_euclid(86400);
    let sod = secs.rem_euclid(86400);
    let (y, m, day) = civil_from_days(days);
    let h = sod / 3600;
    let min = (sod % 3600) / 60;
    let s = sod % 60;
    format!("{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:06}+0000", y, m, day, h, min, s, micros)
}

fn civil_from_days(days: i64) -> (i64, i64, i64) {
    let z = days + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = mp + if mp < 10 { 3 } else { -9 };
    let year = y + if m <= 2 { 1 } else { 0 };
    (year, m, d)
}

fn print_help(prog: &str) {
    println!("usage: {} [options] [logfile1 logfile2 ...]\n\nA log file viewer for the terminal that indexes log messages to\nmake it easier to navigate through files quickly.\n\nKey Bindings\n  ?    View/leave the online help text.\n  q    Quit the program.\n\nOptions\n  -h         Print this message, then exit.\n  -H         Display the internal help text.\n\n  -I dir     An additional configuration directory.\n  -W         Print warnings related to lnav's configuration.\n  -u         Update formats installed from git repositories.\n  -d file    Write debug messages to the given file.\n  -V         Print version information.\n\n  -S,--since Only index log content since this time.\n  -U,--until Only index log content until this time.\n  -r         Recursively load files from the given directory hierarchies.\n  -R         Load older rotated log files as well.\n  -c cmd     Execute a command after the files have been loaded.\n  -f file    Execute the commands in the given file.\n  -e cmd     Execute a shell command-line.\n  -t         Treat data piped into standard in as a log file.\n  -n         Run without the curses UI. (headless mode)\n  -N         Do not open the default syslog file if no files are given.\n  -q         Do not print informational messages.\n\nOptional arguments\n  logfileN   The log files, directories, or remote paths to view.\n             If a directory is given, all of the files in the\n             directory will be loaded.\n\nManagement-Mode Options\n  -i         Install the given format files and exit.  Pass 'extra'\n             to install the default set of third-party formats.\n  -m         Switch to the management command-line mode.  This mode\n             is used to work with lnav's configuration.\n\nExamples\n • To load and follow the syslog file:\n     $ lnav                                  \n\n • To load all of the files in /var/log:\n     $ lnav /var/log                         \n\n • To watch the output of make:\n     $ lnav -e 'make -j4'                    \n\nPaths\n • This binary:\n    🧭 {}\n • Format files are read from:\n    📂 /etc/lnav\n    📂 /usr/etc/lnav\n • Configuration, session, and format files are stored in:\n    📂 /home/agent/.lnav\n\n • Local copies of remote files, files extracted from\n   archives, execution output, and so on are stored in:\n    📂 /tmp/lnav-user-1000-work\n\nDocumentation: https://docs.lnav.org\nContact\n  💬 https://github.com/tstack/lnav/discussions\n  📫 lnav@googlegroups.com\nVersion: {}", prog, prog, VERSION);
}
