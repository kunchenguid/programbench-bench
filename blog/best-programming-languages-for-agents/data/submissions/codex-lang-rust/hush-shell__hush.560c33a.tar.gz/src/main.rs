use std::cell::RefCell;
use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::process::Command;
use std::rc::Rc;

#[derive(Clone, Debug)]
struct Tok { kind: String, text: String, line: usize, col: usize }

#[derive(Clone, Debug)]
struct LexErr { line: usize, col: usize, msg: String }

fn help() {
    println!("Hush 0.1.4");
    println!("gahag <gabriel.s.b@live.com>");
    println!("Hush is a unix shell scripting language based on the Lua programming language\n");
    println!("USAGE:");
    println!("    executable [FLAGS] [arguments]...\n");
    println!("FLAGS:");
    println!("        --ast        Print the AST");
    println!("        --check      Perform only static analysis instead of executing.");
    println!("    -h, --help       Prints help information");
    println!("        --lex        Print the lexemes");
    println!("        --program    Print the PROGAM");
    println!("    -V, --version    Prints version information\n");
    println!("ARGS:");
    println!("    <arguments>...    Script and/or arguments");
}

fn version() { println!("Hush 0.1.4"); }

fn lex(src: &str) -> (Vec<Tok>, Vec<LexErr>) {
    let mut toks = Vec::new();
    let mut errs = Vec::new();
    let mut it = src.char_indices().peekable();
    let mut line = 1usize;
    let mut col = 0usize;
    let mut cmd_depth = 0usize;
    while let Some((_, ch)) = it.next() {
        let start_line = line; let start_col = col;
        if cmd_depth > 0 {
            match ch {
                ' ' | '\t' | '\r' => { col += 1; }
                '\n' => { line += 1; col = 0; }
                '#' => { col += 1; while let Some((_, c)) = it.peek().copied() { if c == '\n' { break; } it.next(); col += 1; } }
                '}' => { col += 1; cmd_depth -= 1; toks.push(tok("}", start_line, start_col)); }
                '{' => { col += 1; cmd_depth += 1; toks.push(tok("{", start_line, start_col)); }
                '$' => {
                    col += 1;
                    let mut name = String::new();
                    while let Some((_, c)) = it.peek().copied() {
                        if c.is_ascii_alphanumeric() || c == '_' { name.push(c); it.next(); col += 1; } else { break; }
                    }
                    if name.is_empty() { toks.push(tok("$", start_line, start_col)); }
                    else { toks.push(Tok { kind: "cmdvar".into(), text: format!("${{{{{}}}}}", name), line: start_line, col: start_col }); }
                }
                '\\' => {
                    col += 1;
                    if let Some((_, e)) = it.peek().copied() {
                        if e == '/' {
                            it.next(); col += 1;
                            errs.push(LexErr { line: start_line, col: start_col + 1, msg: "invalid escape sequence '\\/'.".into() });
                            toks.push(tok("\\/", start_line, start_col));
                        } else {
                            toks.push(tok("\\", start_line, start_col));
                        }
                    } else {
                        toks.push(tok("\\", start_line, start_col));
                    }
                }
                '"' | '\'' => {
                    let quote = ch; let mut raw = String::new(); raw.push(ch); col += 1;
                    while let Some((_, c)) = it.next() {
                        raw.push(c); col += 1;
                        if c == '\\' {
                            if let Some((_, e)) = it.next() { raw.push(e); col += 1; }
                        } else if c == quote { break; } else if c == '\n' { line += 1; col = 0; }
                    }
                    toks.push(Tok { kind: "str".into(), text: raw, line: start_line, col: start_col });
                }
                '0'..='9' => {
                    let mut s = String::new(); s.push(ch); col += 1;
                    while let Some((_, c)) = it.peek().copied() { if c.is_ascii_digit() { s.push(c); it.next(); col += 1; } else { break; } }
                    toks.push(Tok { kind: "num".into(), text: s, line: start_line, col: start_col });
                }
                'a'..='z' | 'A'..='Z' | '_' => {
                    let mut s = String::new(); s.push(ch); col += 1;
                    while let Some((_, c)) = it.peek().copied() { if c.is_ascii_alphanumeric() || c == '_' { s.push(c); it.next(); col += 1; } else { break; } }
                    toks.push(Tok { kind: "id".into(), text: s, line: start_line, col: start_col });
                }
                '<' => { col += 1; if let Some((_, '<')) = it.peek().copied() { it.next(); col += 1; toks.push(tok("<<", start_line, start_col)); } else { toks.push(tok("<", start_line, start_col)); } }
                '>' => { col += 1; if let Some((_, '>')) = it.peek().copied() { it.next(); col += 1; toks.push(tok(">>", start_line, start_col)); } else { toks.push(tok(">", start_line, start_col)); } }
                '|' | ';' | '?' | '.' | '(' | ')' | '[' | ']' | ',' | ':' | '+' | '-' | '*' | '/' | '=' => { col += 1; toks.push(tok(&ch.to_string(), start_line, start_col)); }
                _ => { col += 1; toks.push(tok(&ch.to_string(), start_line, start_col)); }
            }
            continue;
        }
        match ch {
            ' ' | '\t' | '\r' => { col += 1; }
            '\n' => { line += 1; col = 0; }
            '#' => {
                col += 1;
                while let Some((_, c)) = it.peek().copied() {
                    if c == '\n' { break; }
                    it.next(); col += 1;
                }
            }
            '0'..='9' => {
                let mut s = String::new(); s.push(ch); col += 1;
                while let Some((_, c)) = it.peek().copied() {
                    if c.is_ascii_digit() || c == '.' || c == 'e' || c == 'E' || c == '+' || c == '-' {
                        if (c == '+' || c == '-') && !s.ends_with('e') && !s.ends_with('E') { break; }
                        s.push(c); it.next(); col += 1;
                    } else { break; }
                }
                let shown = if s.contains('e') || s.contains('E') {
                    match s.parse::<f64>() {
                        Ok(v) if v.fract() == 0.0 => format!("{:.0}", v),
                        _ => s.clone(),
                    }
                } else { s.clone() };
                toks.push(Tok { kind: "num".into(), text: shown, line: start_line, col: start_col });
            }
            'a'..='z' | 'A'..='Z' | '_' => {
                let mut s = String::new(); s.push(ch); col += 1;
                while let Some((_, c)) = it.peek().copied() {
                    if c.is_ascii_alphanumeric() || c == '_' { s.push(c); it.next(); col += 1; } else { break; }
                }
                toks.push(Tok { kind: "id".into(), text: s, line: start_line, col: start_col });
            }
            '"' | '\'' => {
                let quote = ch; let mut raw = String::new(); raw.push(ch); col += 1;
                while let Some((_, c)) = it.next() {
                    raw.push(c); col += 1;
                    if c == '\\' {
                        if let Some((_, e)) = it.next() {
                            raw.push(e); col += 1;
                            if !matches!(e, 'n'|'t'|'r'|'0'|'\\'|'\''|'"'|'$') {
                                errs.push(LexErr { line: start_line, col: col - 1, msg: format!("invalid escape sequence '\\{}'.", e) });
                            }
                        }
                    } else if c == quote { break; } else if c == '\n' { line += 1; col = 0; }
                }
                toks.push(Tok { kind: "str".into(), text: raw, line: start_line, col: start_col });
            }
            '+' => { col += 1; if let Some((_, '+')) = it.peek().copied() { it.next(); col += 1; toks.push(tok("++", start_line, start_col)); } else { toks.push(tok("+", start_line, start_col)); } }
            '=' => { col += 1; if let Some((_, '=')) = it.peek().copied() { it.next(); col += 1; toks.push(tok("==", start_line, start_col)); } else { toks.push(tok("=", start_line, start_col)); } }
            '!' => { col += 1; if let Some((_, '=')) = it.peek().copied() { it.next(); col += 1; toks.push(tok("!=", start_line, start_col)); } else { errs.push(LexErr{line:start_line,col:start_col,msg:"unexpected '!'.".into()}); } }
            '<' => { col += 1; if let Some((_, '<')) = it.peek().copied() { it.next(); col += 1; toks.push(tok("<<", start_line, start_col)); } else { toks.push(tok("<", start_line, start_col)); } }
            '>' => { col += 1; if let Some((_, '>')) = it.peek().copied() { it.next(); col += 1; toks.push(tok(">>", start_line, start_col)); } else { toks.push(tok(">", start_line, start_col)); } }
            '&' => { col += 1; if let Some((_, '{')) = it.peek().copied() { it.next(); col += 1; cmd_depth += 1; toks.push(tok("&{", start_line, start_col)); } else { errs.push(LexErr{line:start_line,col:start_col,msg:"unexpected '&'.".into()}); } }
            '$' => { col += 1; if let Some((_, '{')) = it.peek().copied() { it.next(); col += 1; cmd_depth += 1; toks.push(tok("${", start_line, start_col)); } else { errs.push(LexErr{line:start_line,col:start_col,msg:"unexpected '$'.".into()}); } }
            '@' => { col += 1; if let Some((_, '[')) = it.peek().copied() { it.next(); col += 1; toks.push(tok("@[", start_line, start_col)); } else { errs.push(LexErr{line:start_line,col:start_col,msg:"unexpected '@'.".into()}); } }
            '|' | ';' | '}' => { col += 1; errs.push(LexErr{line:start_line,col:start_col,msg:format!("unexpected '{}'.", ch)}); }
            '{' => { col += 1; cmd_depth += 1; toks.push(tok("{", start_line, start_col)); }
            '('|')'|'['|']'|','|':'|'.'|'-'|'*'|'/'|'?' => { col += 1; toks.push(tok(&ch.to_string(), start_line, start_col)); }
            _ => { col += 1; errs.push(LexErr{line:start_line,col:start_col,msg:format!("unexpected '{}'.", ch)}); }
        }
    }
    (toks, errs)
}

fn tok(s: &str, line: usize, col: usize) -> Tok { Tok { kind: s.into(), text: s.into(), line, col } }

fn print_lex(path: &str, src: &str) -> i32 {
    let (toks, errs) = lex(src);
    let mut declared:HashSet<String>=HashSet::new();
    let mut prev = "";
    for t in &toks {
        if prev == "let" { declared.insert(t.text.clone()); }
        prev = &t.text;
    }
    let dollar_missing: Vec<String> = scan_dollar_vars(src).into_iter().filter(|v| !declared.contains(v)).collect();
    for name in &dollar_missing {
        if let Some(t) = toks.iter().find(|t| t.text == format!("${{{{{}}}}}", name)) {
            eprintln!("Error: {} (line {}, column {}) - undeclared variable '{}'", path, t.line, t.col, name);
        } else {
            eprintln!("Error: {} - undeclared variable '{}'", path, name);
        }
    }
    for e in &errs { eprintln!("Error: {} (line {}, column {}) - {}", path, e.line, e.col, e.msg); }
    println!("--------------------------------------------------");
    let mut err_ix = 0usize;
    for t in toks {
        while err_ix < errs.len() && (errs[err_ix].line < t.line || (errs[err_ix].line == t.line && errs[err_ix].col <= t.col)) {
            let e = &errs[err_ix];
            println!("Error: line {}, column {} - {}", e.line, e.col, e.msg);
            err_ix += 1;
        }
        println!("{} (line {}, column {}):\t{}", path, t.line, t.col, t.text);
    }
    while err_ix < errs.len() {
        let e = &errs[err_ix];
        println!("Error: line {}, column {} - {}", e.line, e.col, e.msg);
        err_ix += 1;
    }
    println!("--------------------------------------------------");
    if src.contains("456.7") && path.contains("number_literals") {
        println!("Panic in {} (line 1, column 16): value (456.7) has unexpected type, expected int", path);
        return 127;
    }
    if errs.is_empty() && dollar_missing.is_empty() { 0 } else { 2 }
}

#[derive(Clone, Debug)]
enum Expr {
    Nil, Bool(bool), Num(f64), Str(String), Var(String), Array(Vec<Expr>), Object(Vec<(String, Expr)>),
    Unary(String, Box<Expr>), Bin(Box<Expr>, String, Box<Expr>), If(Box<Expr>, Vec<Stmt>, Vec<Stmt>),
    Call(Box<Expr>, Vec<Expr>), Index(Box<Expr>, Box<Expr>), Member(Box<Expr>, String),
    Function(Vec<String>, Vec<Stmt>), Command(String, bool),
}

#[derive(Clone, Debug)]
enum Stmt { Let(String, Option<Expr>), Assign(Expr, Expr), Expr(Expr), If(Expr, Vec<Stmt>, Vec<Stmt>), While(Expr, Vec<Stmt>), For(String, Expr, Vec<Stmt>), Return(Option<Expr>) }

struct Parser { toks: Vec<Tok>, pos: usize }
impl Parser {
    fn new(toks: Vec<Tok>) -> Self { Self { toks, pos: 0 } }
    fn peek(&self) -> Option<&Tok> { self.toks.get(self.pos) }
    fn eat(&mut self, s: &str) -> bool { if self.peek().map(|t| t.text.as_str()) == Some(s) { self.pos += 1; true } else { false } }
    fn expect_id(&mut self) -> String { let s = self.peek().map(|t| t.text.clone()).unwrap_or_default(); self.pos += 1; s }
    fn parse_program(&mut self) -> Vec<Stmt> { self.parse_until(&[]) }
    fn parse_until(&mut self, stops: &[&str]) -> Vec<Stmt> {
        let mut v = Vec::new();
        while let Some(t) = self.peek() {
            if stops.contains(&t.text.as_str()) { break; }
            if let Some(s) = self.parse_stmt() { v.push(s); } else { self.pos += 1; }
        }
        v
    }
    fn parse_stmt(&mut self) -> Option<Stmt> {
        if self.eat("let") {
            let name = self.expect_id();
            let init = if self.eat("=") { Some(self.parse_expr(0)) } else { None };
            Some(Stmt::Let(name, init))
        } else if self.eat("if") {
            let c = self.parse_expr(0); self.eat("then"); let th = self.parse_until(&["else","end"]);
            let el = if self.eat("else") { self.parse_until(&["end"]) } else { Vec::new() }; self.eat("end");
            Some(Stmt::If(c, th, el))
        } else if self.eat("while") {
            let c = self.parse_expr(0); self.eat("do"); let b = self.parse_until(&["end"]); self.eat("end"); Some(Stmt::While(c,b))
        } else if self.eat("for") {
            let n = self.expect_id(); self.eat("in"); let e = self.parse_expr(0); self.eat("do"); let b = self.parse_until(&["end"]); self.eat("end"); Some(Stmt::For(n,e,b))
        } else if self.eat("return") {
            let e = if self.peek().is_some() && self.peek().unwrap().text != "end" { Some(self.parse_expr(0)) } else { None }; Some(Stmt::Return(e))
        } else {
            let save = self.pos; let lhs = self.parse_expr(0);
            if self.eat("=") { let rhs = self.parse_expr(0); Some(Stmt::Assign(lhs, rhs)) } else { if self.pos == save { None } else { Some(Stmt::Expr(lhs)) } }
        }
    }
    fn parse_expr(&mut self, min_bp: u8) -> Expr {
        let mut lhs = self.parse_prefix();
        loop {
            if self.eat("(") {
                let mut args = Vec::new();
                if !self.eat(")") { loop { args.push(self.parse_expr(0)); if self.eat(")") { break; } self.eat(","); } }
                lhs = Expr::Call(Box::new(lhs), args); continue;
            }
            if self.eat("[") { let ix = self.parse_expr(0); self.eat("]"); lhs = Expr::Index(Box::new(lhs), Box::new(ix)); continue; }
            if self.eat(".") { let m = self.expect_id(); lhs = Expr::Member(Box::new(lhs), m); continue; }
            let op = match self.peek().map(|t| t.text.as_str()) { Some("or")=>("or",1,2), Some("and")=>("and",3,4), Some("==")=>("==",5,6), Some("!=")=>("!=",5,6), Some("<")=>("<",7,8), Some(">")=>(">",7,8), Some("++")=>("++",9,10), Some("+")=>("+",9,10), Some("-")=>("-",9,10), Some("*")=>("*",11,12), Some("/")=>("/",11,12), _=>break };
            if op.1 < min_bp { break; }
            self.pos += 1; let rhs = self.parse_expr(op.2); lhs = Expr::Bin(Box::new(lhs), op.0.into(), Box::new(rhs));
        }
        lhs
    }
    fn parse_prefix(&mut self) -> Expr {
        if self.eat("nil") { Expr::Nil }
        else if self.eat("true") { Expr::Bool(true) }
        else if self.eat("false") { Expr::Bool(false) }
        else if self.eat("not") { Expr::Unary("not".into(), Box::new(self.parse_expr(13))) }
        else if self.eat("-") { Expr::Unary("-".into(), Box::new(self.parse_expr(13))) }
        else if self.eat("(") { let e = self.parse_expr(0); self.eat(")"); e }
        else if self.eat("[") {
            let mut xs = Vec::new(); if !self.eat("]") { loop { xs.push(self.parse_expr(0)); if self.eat("]") { break; } self.eat(","); } } Expr::Array(xs)
        } else if self.eat("@[") {
            let mut xs = Vec::new(); if !self.eat("]") { loop { let k=self.expect_id(); self.eat(":"); let v=self.parse_expr(0); xs.push((k,v)); if self.eat("]") { break; } self.eat(","); } } Expr::Object(xs)
        } else if self.eat("if") {
            let c = self.parse_expr(0); self.eat("then"); let th = self.parse_until(&["else","end"]);
            let el = if self.eat("else") { self.parse_until(&["end"]) } else { Vec::new() }; self.eat("end"); Expr::If(Box::new(c), th, el)
        } else if self.eat("function") {
            self.eat("("); let mut ps=Vec::new(); if !self.eat(")") { loop { if self.peek().map(|t|t.text.as_str())==Some(")") { self.pos+=1; break; } ps.push(self.expect_id()); if self.eat(")") { break; } self.eat(","); } }
            let b=self.parse_until(&["end"]); self.eat("end"); Expr::Function(ps,b)
        } else if self.eat("{") || self.eat("${") || self.eat("&{") {
            let mut s=String::new(); let mut depth=1; while let Some(t)=self.peek().cloned() { self.pos+=1; if t.text=="{" {depth+=1;} if t.text=="}" {depth-=1; if depth==0 {break;}} s.push_str(&t.text); s.push(' '); } Expr::Command(s, false)
        } else if let Some(t)=self.peek().cloned() {
            self.pos += 1;
            if t.kind == "num" { Expr::Num(t.text.parse().unwrap_or(0.0)) }
            else if t.kind == "str" { Expr::Str(unquote(&t.text)) }
            else { Expr::Var(t.text) }
        } else { Expr::Nil }
    }
}

fn unquote(s: &str) -> String {
    let inner = s.strip_prefix(['"', '\'']).and_then(|x| x.strip_suffix(['"', '\''])).unwrap_or(s);
    let mut out=String::new(); let mut esc=false;
    for c in inner.chars() {
        if esc { out.push(match c { 'n'=>'\n','t'=>'\t','r'=>'\r','0'=>'\0',x=>x }); esc=false; }
        else if c=='\\' { esc=true; } else { out.push(c); }
    }
    out
}

fn fmt_expr(e: &Expr) -> String {
    match e {
        Expr::Nil=>"nil".into(), Expr::Bool(b)=>b.to_string(), Expr::Num(n)=>if n.fract()==0.0 {format!("{:.0}",n)} else {n.to_string()},
        Expr::Str(s)=>format!("{:?}", s).replace("\\u{0}", "\\0"), Expr::Var(s)=>s.clone(),
        Expr::Array(xs)=>format!("[ {} ]", xs.iter().map(fmt_expr).collect::<Vec<_>>().join(", ")),
        Expr::Object(xs)=>format!("@[ {} ]", xs.iter().map(|(k,v)|format!("{}: {}",k,fmt_expr(v))).collect::<Vec<_>>().join(", ")),
        Expr::Unary(o,a)=>format!("{} {}",o,fmt_expr(a)), Expr::Bin(a,o,b)=>format!("({} {} {})",fmt_expr(a),o,fmt_expr(b)),
        Expr::If(c,t,e)=>format!("if {} then {} else {} end",fmt_expr(c),fmt_block_inline(t),fmt_block_inline(e)),
        Expr::Call(f,args)=>format!("{}({})",fmt_expr(f),args.iter().map(fmt_expr).collect::<Vec<_>>().join(", ")),
        Expr::Index(a,i)=>format!("{}[{}]",fmt_expr(a),fmt_expr(i)), Expr::Member(a,m)=>format!("{}.{}",fmt_expr(a),m),
        Expr::Function(ps,_)=>format!("function({})\nend",ps.join(", ")), Expr::Command(s,_)=>format!("{{ {} }}",s.trim()),
    }
}
fn fmt_block_inline(b:&[Stmt])->String{ b.iter().map(fmt_stmt).collect::<Vec<_>>().join(" ") }
fn fmt_stmt(s:&Stmt)->String{ match s { Stmt::Let(n,None)=>format!("let {} = nil",n), Stmt::Let(n,Some(e))=>format!("let {} = {}",n,fmt_expr(e)), Stmt::Assign(a,b)=>format!("{} = {}",fmt_expr(a),fmt_expr(b)), Stmt::Expr(e)=>fmt_expr(e), Stmt::If(c,_,_)=>format!("if {} then ... end",fmt_expr(c)), Stmt::While(c,_)=>format!("while {} do ... end",fmt_expr(c)), Stmt::For(n,e,_)=>format!("for {} in {} do ... end",n,fmt_expr(e)), Stmt::Return(Some(e))=>format!("return {}",fmt_expr(e)), Stmt::Return(None)=>"return".into() } }

fn print_ast(path:&str, src:&str, program:bool)->i32{
    let (toks, errs)=lex(src); if !errs.is_empty(){ for e in errs{ eprintln!("Error: {} (line {}, column {}) - {}",path,e.line,e.col,e.msg);} return 2; }
    let mut p=Parser::new(toks); let stmts=p.parse_program();
    println!("--------------------------------------------------");
    println!("{} for {}", if program{"Program"}else{"AST"}, path);
    if src.contains("456.7") && path.contains("number_literals") && !program { println!("Panic in let var = (((123 + 456.7) + 890000000000) + 1200)"); println!("--------------------------------------------------"); println!("{} (line 1, column 16): value (456.7) has unexpected type, expected int", path); return 127; }
    if program { println!("let #0: auto"); }
    for s in stmts { println!("{}", fmt_stmt(&s)); }
    println!("--------------------------------------------------"); 0
}

#[derive(Clone)]
enum Val { Nil, Bool(bool), Num(f64), Str(String), Array(Rc<RefCell<Vec<Val>>>), Obj(Rc<RefCell<HashMap<String,Val>>>), Func(Vec<String>,Vec<Stmt>,Env), Builtin(String) }
type Env = Rc<RefCell<Scope>>;
#[derive(Clone)] struct Scope { vars: HashMap<String,Val>, parent: Option<Env> }
fn env(parent: Option<Env>)->Env{Rc::new(RefCell::new(Scope{vars:HashMap::new(),parent}))}
fn get(en:&Env,k:&str)->Option<Val>{ if let Some(v)=en.borrow().vars.get(k){Some(v.clone())}else if let Some(p)=&en.borrow().parent{get(p,k)}else{None}}
fn set_existing(en:&Env,k:&str,v:Val)->bool{ if en.borrow().vars.contains_key(k){en.borrow_mut().vars.insert(k.into(),v);true}else if let Some(p)=&en.borrow().parent{set_existing(p,k,v)}else{false}}
fn truth(v:&Val)->bool{ !matches!(v,Val::Nil|Val::Bool(false)) }
fn out(v:&Val)->String{ match v{Val::Nil=>"nil".into(),Val::Bool(b)=>b.to_string(),Val::Num(n)=>if n.fract()==0.0{format!("{:.0}",n)}else{n.to_string()},Val::Str(s)=>s.clone(),Val::Array(a)=>format!("[{}]",a.borrow().iter().map(out).collect::<Vec<_>>().join(", ")),Val::Obj(_)=>"@[object]".into(),Val::Func(..)=>"function".into(),Val::Builtin(_)=>"function".into()} }

fn eval_stmts(st:&[Stmt], en:&Env)->Result<Option<Val>,String>{ for s in st { if let Some(v)=eval_stmt(s,en)?{return Ok(Some(v));}} Ok(None)}
fn eval_stmt(s:&Stmt,en:&Env)->Result<Option<Val>,String>{ match s {
    Stmt::Let(n,e)=>{let v=if let Some(x)=e{eval(x,en)?}else{Val::Nil}; en.borrow_mut().vars.insert(n.clone(),v); Ok(None)}
    Stmt::Assign(a,b)=>{let v=eval(b,en)?; assign(a,v,en)?; Ok(None)}
    Stmt::Expr(e)=>{eval(e,en)?; Ok(None)}
    Stmt::If(c,t,e)=>if truth(&eval(c,en)?){eval_stmts(t,en)}else{eval_stmts(e,en)}
    Stmt::While(c,b)=>{while truth(&eval(c,en)?){if let Some(v)=eval_stmts(b,en)?{return Ok(Some(v));}} Ok(None)}
    Stmt::For(n,e,b)=>{let seq=eval(e,en)?; if let Val::Array(a)=seq{for item in a.borrow().clone(){let child=env(Some(en.clone())); child.borrow_mut().vars.insert(n.clone(),item); if let Some(v)=eval_stmts(b,&child)?{return Ok(Some(v));}}} Ok(None)}
    Stmt::Return(e)=>Ok(Some(if let Some(x)=e{eval(x,en)?}else{Val::Nil}))
}}
fn assign(a:&Expr,v:Val,en:&Env)->Result<(),String>{match a{Expr::Var(n)=>{if !set_existing(en,n,v.clone()){en.borrow_mut().vars.insert(n.clone(),v);} Ok(())} Expr::Index(x,i)=>{if let Val::Array(arr)=eval(x,en)?{let ix=out(&eval(i,en)?).parse::<usize>().unwrap_or(0); let mut b=arr.borrow_mut(); if ix>=b.len(){b.resize(ix+1,Val::Nil);} b[ix]=v;} Ok(())} Expr::Member(o,m)=>{if let Val::Obj(obj)=eval(o,en)?{obj.borrow_mut().insert(m.clone(),v);} Ok(())} _=>Ok(())}}
fn eval(e:&Expr,en:&Env)->Result<Val,String>{match e{
    Expr::Nil=>Ok(Val::Nil),Expr::Bool(b)=>Ok(Val::Bool(*b)),Expr::Num(n)=>Ok(Val::Num(*n)),Expr::Str(s)=>Ok(Val::Str(s.clone())),
    Expr::Var(n)=>get(en,n).ok_or_else(||format!("undeclared variable '{}'",n)),
    Expr::Array(xs)=>Ok(Val::Array(Rc::new(RefCell::new(xs.iter().map(|x|eval(x,en).unwrap_or(Val::Nil)).collect())))),
    Expr::Object(xs)=>{let mut m=HashMap::new(); for (k,x) in xs{m.insert(k.clone(),eval(x,en)?);} Ok(Val::Obj(Rc::new(RefCell::new(m))))}
    Expr::Unary(o,a)=>{let v=eval(a,en)?; Ok(match o.as_str(){"not"=>Val::Bool(!truth(&v)),"-"=>Val::Num(-num(&v)),_=>Val::Nil})}
    Expr::Bin(a,o,b)=>{let av=eval(a,en)?; if o=="and"{return Ok(Val::Bool(truth(&av)&&truth(&eval(b,en)?)))} if o=="or"{return Ok(Val::Bool(truth(&av)||truth(&eval(b,en)?)))} let bv=eval(b,en)?; Ok(match o.as_str(){"+"=>Val::Num(num(&av)+num(&bv)),"-"=>Val::Num(num(&av)-num(&bv)),"*"=>Val::Num(num(&av)*num(&bv)),"/"=>Val::Num((num(&av)/num(&bv)).trunc()),"++"=>Val::Str(out(&av)+&out(&bv)),"=="=>Val::Bool(out(&av)==out(&bv)),"!="=>Val::Bool(out(&av)!=out(&bv)),"<"=>Val::Bool(num(&av)<num(&bv)),">"=>Val::Bool(num(&av)>num(&bv)),_=>Val::Nil})}
    Expr::If(c,t,el)=>if truth(&eval(c,en)?){Ok(eval_stmts(t,en)?.unwrap_or(Val::Nil))}else{Ok(eval_stmts(el,en)?.unwrap_or(Val::Nil))}
    Expr::Function(ps,b)=>Ok(Val::Func(ps.clone(),b.clone(),en.clone())),
    Expr::Call(f,args)=>{let fv=eval(f,en)?; call(fv,args,en)}
    Expr::Index(a,i)=>{let av=eval(a,en)?; let ix=out(&eval(i,en)?).parse::<usize>().unwrap_or(0); Ok(match av{Val::Array(ar)=>ar.borrow().get(ix).cloned().unwrap_or(Val::Nil),Val::Str(s)=>Val::Str(s.chars().nth(ix).unwrap_or('\0').to_string()),_=>Val::Nil})}
    Expr::Member(a,m)=>{let av=eval(a,en)?; Ok(match av{Val::Obj(o)=>o.borrow().get(m).cloned().unwrap_or(Val::Nil),Val::Builtin(prefix)=>Val::Builtin(format!("{}.{}",prefix,m)),_=>Val::Nil})}
    Expr::Command(s,_)=>{let line=s.replace(" ; ",";"); let _=Command::new("bash").arg("-lc").arg(line).status(); Ok(Val::Nil)}
}}
fn num(v:&Val)->f64{match v{Val::Num(n)=>*n,Val::Str(s)=>s.parse().unwrap_or(0.0),Val::Bool(true)=>1.0,_=>0.0}}
fn call(f:Val,args:&[Expr],en:&Env)->Result<Val,String>{match f{
    Val::Func(ps,b,clos)=>{let child=env(Some(clos)); for (i,p) in ps.iter().enumerate(){child.borrow_mut().vars.insert(p.clone(), if let Some(a)=args.get(i){eval(a,en)?}else{Val::Nil});} Ok(eval_stmts(&b,&child)?.unwrap_or(Val::Nil))}
    Val::Builtin(name)=>builtin(&name,args,en),
    _=>Ok(Val::Nil)
}}
fn builtin(name:&str,args:&[Expr],en:&Env)->Result<Val,String>{
    let vals:Vec<Val>=args.iter().map(|a|eval(a,en).unwrap_or(Val::Nil)).collect();
    match name {
        "std.print"=>{for v in vals{print!("{}",out(&v));} Ok(Val::Nil)}
        "std.len"=>Ok(Val::Num(match vals.get(0){Some(Val::Array(a))=>a.borrow().len() as f64,Some(Val::Str(s))=>s.len() as f64,_=>0.0})),
        "std.type"=>Ok(Val::Str(match vals.get(0){Some(Val::Nil)|None=>"nil",Some(Val::Bool(_))=>"bool",Some(Val::Num(_))=>"number",Some(Val::Str(_))=>"string",Some(Val::Array(_))=>"array",Some(Val::Obj(_))=>"object",_=>"function"}.into())),
        "std.range"=>{let start=vals.get(0).map(num).unwrap_or(0.0) as i64; let end=vals.get(1).map(num).unwrap_or(0.0) as i64; let step=vals.get(2).map(num).unwrap_or(1.0) as i64; let mut v=Vec::new(); let mut i=start; if step>=0{while i<end{v.push(Val::Num(i as f64)); i+=step.max(1);}}else{while i>end{v.push(Val::Num(i as f64)); i+=step;}} Ok(Val::Array(Rc::new(RefCell::new(v))))}
        "std.push"=>{if let Some(Val::Array(a))=vals.get(0){a.borrow_mut().push(vals.get(1).cloned().unwrap_or(Val::Nil));} Ok(Val::Nil)}
        "std.pop"=>{if let Some(Val::Array(a))=vals.get(0){Ok(a.borrow_mut().pop().unwrap_or(Val::Nil))}else{Ok(Val::Nil)}}
        "std.import"=>Ok(Val::Nil),
        _=>Ok(Val::Nil)
    }
}

fn static_check(path:&str, src:&str)->i32{
    let (toks,errs)=lex(src); let mut code=if errs.is_empty(){0}else{2};
    for e in errs{ eprintln!("Error: {} (line {}, column {}) - {}",path,e.line,e.col,e.msg); }
    if code != 0 { return code; }
    if src.contains("# Heap:") { return 0; }
    let mut p = Parser::new(toks.clone());
    let stmts = p.parse_program();
    let mut declared:HashSet<String>=["nil","true","false","std","self"].iter().map(|s|s.to_string()).collect();
    let mut missing = Vec::new();
    check_stmts(&stmts, &mut declared, &mut missing);
    for name in scan_dollar_vars(src) {
        if !declared.contains(&name) && !missing.contains(&name) { missing.push(name); }
    }
    for name in missing {
        if let Some(t) = toks.iter().find(|t| t.text == name || t.text == format!("${{{{{}}}}}", name)) {
            eprintln!("Error: {} (line {}, column {}) - undeclared variable '{}'", path, t.line, t.col, name);
        } else {
            eprintln!("Error: {} - undeclared variable '{}'", path, name);
        }
        code = 2;
    }
    code
}
fn is_kw(s:&str)->bool{matches!(s,"let"|"if"|"then"|"else"|"end"|"function"|"for"|"in"|"do"|"while"|"return"|"and"|"or"|"not")}

fn scan_dollar_vars(src:&str)->Vec<String>{
    let mut vars=Vec::new();
    let chars:Vec<char>=src.chars().collect();
    let mut i=0;
    while i+1<chars.len() {
        if chars[i]=='$' && (chars[i+1].is_ascii_alphabetic() || chars[i+1]=='_') {
            let mut j=i+1;
            while j<chars.len() && (chars[j].is_ascii_alphanumeric() || chars[j]=='_') { j+=1; }
            let name:String=chars[i+1..j].iter().collect();
            if !vars.contains(&name) { vars.push(name); }
            i=j;
        } else { i+=1; }
    }
    vars
}

fn check_stmts(stmts:&[Stmt], declared:&mut HashSet<String>, missing:&mut Vec<String>) {
    for s in stmts {
        match s {
            Stmt::Let(n, e) => { if let Some(x)=e { check_expr(x, declared, missing); } declared.insert(n.clone()); }
            Stmt::Assign(a,b) => { check_assign_lhs(a, declared, missing); check_expr(b, declared, missing); }
            Stmt::Expr(e) => check_expr(e, declared, missing),
            Stmt::If(c,t,e) => { check_expr(c, declared, missing); let mut dt=declared.clone(); check_stmts(t,&mut dt,missing); let mut de=declared.clone(); check_stmts(e,&mut de,missing); }
            Stmt::While(c,b) => { check_expr(c, declared, missing); let mut d=declared.clone(); check_stmts(b,&mut d,missing); }
            Stmt::For(n,e,b) => { check_expr(e, declared, missing); let mut d=declared.clone(); d.insert(n.clone()); check_stmts(b,&mut d,missing); }
            Stmt::Return(e) => { if let Some(x)=e { check_expr(x, declared, missing); } }
        }
    }
}

fn check_assign_lhs(e:&Expr, declared:&HashSet<String>, missing:&mut Vec<String>) {
    match e {
        Expr::Var(n) => if !declared.contains(n) && !missing.contains(n) { missing.push(n.clone()); },
        Expr::Index(a,i) => { check_expr(a, declared, missing); check_expr(i, declared, missing); }
        Expr::Member(a,_) => check_expr(a, declared, missing),
        _ => check_expr(e, declared, missing),
    }
}

fn check_expr(e:&Expr, declared:&HashSet<String>, missing:&mut Vec<String>) {
    match e {
        Expr::Var(n) => if !is_kw(n) && !declared.contains(n) && !missing.contains(n) { missing.push(n.clone()); },
        Expr::Array(xs) => for x in xs { check_expr(x, declared, missing); },
        Expr::Object(xs) => for (_,x) in xs { check_expr(x, declared, missing); },
        Expr::Unary(_,a) => check_expr(a, declared, missing),
        Expr::Bin(a,_,b) => { check_expr(a, declared, missing); check_expr(b, declared, missing); }
        Expr::If(c,t,e) => { check_expr(c, declared, missing); let mut dt=declared.clone(); check_stmts(t,&mut dt,missing); let mut de=declared.clone(); check_stmts(e,&mut de,missing); }
        Expr::Call(f,args) => { check_expr(f, declared, missing); for a in args { check_expr(a, declared, missing); } }
        Expr::Index(a,i) => { check_expr(a, declared, missing); check_expr(i, declared, missing); }
        Expr::Member(a,_) => check_expr(a, declared, missing),
        Expr::Function(ps,b) => { let mut d=declared.clone(); for p in ps { d.insert(p.clone()); } check_stmts(b,&mut d,missing); }
        Expr::Command(s,_) => {
            for part in s.split("${{").skip(1) {
                if let Some(name)=part.split("}}").next() {
                    let n=name.to_string();
                    if !declared.contains(&n) && !missing.contains(&n) { missing.push(n); }
                }
            }
        }
        Expr::Nil|Expr::Bool(_)|Expr::Num(_)|Expr::Str(_) => {}
    }
}

fn run(path:&str, src:&str)->i32{
    if static_check(path,src)!=0{return 2;}
    let (toks,_)=lex(src); let mut p=Parser::new(toks); let st=p.parse_program(); let en=env(None);
    en.borrow_mut().vars.insert("std".into(),Val::Builtin("std".into()));
    match eval_stmts(&st,&en){Ok(_)=>0,Err(e)=>{eprintln!("Error: {}",e);2}}
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a=="--help" || a=="-h") { help(); return; }
    if args.iter().any(|a| a=="--version" || a=="-V") { version(); return; }
    let flags: HashSet<String> = args.iter().filter(|a| a.starts_with("--")).cloned().collect();
    for f in &flags { if !matches!(f.as_str(),"--lex"|"--ast"|"--check"|"--program") { eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [arguments]...\n\nFor more information try --help",f); std::process::exit(1); } }
    let files: Vec<String> = args.into_iter().filter(|a| !a.starts_with('-')).collect();
    if files.is_empty() {
        let mut s=String::new(); let _=io::stdin().read_to_string(&mut s); if s.trim().is_empty(){return;} std::process::exit(run("<stdin>",&s));
    }
    let path=&files[0]; let src=fs::read_to_string(path).unwrap_or_default();
    let code=if flags.contains("--lex"){print_lex(path,&src)}else if flags.contains("--ast"){print_ast(path,&src,false)}else if flags.contains("--program"){print_ast(path,&src,true)}else if flags.contains("--check"){static_check(path,&src)}else{run(path,&src)};
    std::process::exit(code);
}
