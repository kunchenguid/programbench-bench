use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read, Write};

#[derive(Debug, Clone)]
struct Node {
    name: String,
    attrs: Vec<(String, String)>,
    children: Vec<Item>,
}

#[derive(Debug, Clone)]
enum Item {
    Element(Node),
    Text(String),
    Comment(String),
    Proc(String),
    CData(String),
}

#[derive(Default)]
struct Opts {
    attr: Option<String>,
    color: bool,
    compact: bool,
    depth: i32,
    extract: Option<String>,
    html: bool,
    in_place: bool,
    indent: usize,
    json: bool,
    no_color: bool,
    node: bool,
    query: Option<String>,
    tab: bool,
    xpath: Option<String>,
    file: Option<String>,
}

fn help() -> &'static str {
    "Command-line XML and HTML beautifier and content extractor\n\nUsage:\n  xq [flags]\n\nFlags:\n  -a, --attr string      Extract an attribute value instead of node content for provided CSS query\n  -c, --color            Force colorful output\n      --compact          Compact JSON output (no indentation)\n  -d, --depth int        Maximum nesting depth for JSON output (-1 for unlimited) (default -1)\n  -e, --extract string   Extract a single node from XML\n  -h, --help             Print this help message\n  -m, --html             Use HTML formatter\n  -i, --in-place         Format file in place\n      --indent int       Use the given number of spaces for indentation (default 2)\n  -j, --json             Output the result as JSON\n      --no-color         Disable colorful output\n  -n, --node             Return the node content instead of text\n  -q, --query string     Extract the node(s) using CSS selector\n      --tab              Use tabs for indentation\n  -v, --version          Print version information\n  -x, --xpath string     Extract the node(s) from XML\n"
}

fn main() {
    if let Err(e) = real_main() {
        let target_stdout = e.starts_with("unknown content type");
        if target_stdout {
            println!("Error: {}", e);
        } else {
            eprintln!("Error: {}", e);
        }
        std::process::exit(1);
    }
}

fn real_main() -> Result<(), String> {
    let mut opts = parse_args()?;
    if opts.indent == 0 {
        opts.indent = 2;
    }
    let mut input = String::new();
    if let Some(path) = &opts.file {
        input = fs::read_to_string(path).map_err(|e| format!("open {}: {}", path, e))?;
    } else {
        io::stdin().read_to_string(&mut input).map_err(|e| e.to_string())?;
    }
    if input.trim().is_empty() {
        if opts.in_place && opts.file.is_none() {
            print!("{}", help());
            return Ok(());
        }
        return Err("unknown content type: 3".to_string());
    }
    let (prefix, root) = parse_document(&input, opts.html);
    let output = if opts.json {
        json_output(&root, opts.compact, opts.depth)
    } else if let Some(q) = opts.query.as_deref() {
        css_output(&root, q, opts.attr.as_deref(), opts.node, &opts)
    } else if let Some(x) = opts.extract.as_deref() {
        xpath_output(&root, x, opts.node, true, &opts)
    } else if let Some(x) = opts.xpath.as_deref() {
        xpath_output(&root, x, opts.node, false, &opts)
    } else {
        let mut s = String::new();
        for p in prefix {
            format_item(&p, 0, &opts, &mut s);
        }
        format_node(&root, 0, &opts, &mut s);
        s
    };
    if opts.in_place {
        if let Some(path) = &opts.file {
            fs::write(path, output).map_err(|e| e.to_string())?;
        }
    } else {
        print!("{}", output);
        io::stdout().flush().ok();
    }
    Ok(())
}

fn parse_args() -> Result<Opts, String> {
    let mut opts = Opts { depth: -1, indent: 2, ..Default::default() };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        match a.as_str() {
            "-h" | "--help" => {
                print!("{}", help());
                std::process::exit(0);
            }
            "-v" | "--version" => {
                println!("xq version 1.4.0");
                std::process::exit(0);
            }
            "-a" | "--attr" => opts.attr = Some(take_arg(&args, &mut i, &a)?),
            "-c" | "--color" => opts.color = true,
            "--compact" => opts.compact = true,
            "-d" | "--depth" => {
                let val = take_arg(&args, &mut i, &a)?;
                opts.depth = val.parse::<i32>().map_err(|_| format!("invalid argument \"{}\" for \"{}\" flag: strconv.ParseInt: parsing \"{}\": invalid syntax", val, a, val))?;
            }
            "-e" | "--extract" => opts.extract = Some(take_arg(&args, &mut i, &a)?),
            "-m" | "--html" => opts.html = true,
            "-i" | "--in-place" => opts.in_place = true,
            "--indent" => {
                let val = take_arg(&args, &mut i, &a)?;
                opts.indent = val.parse::<usize>().map_err(|_| format!("invalid argument \"{}\" for \"--indent\" flag: strconv.ParseInt: parsing \"{}\": invalid syntax", val, val))?;
            }
            "-j" | "--json" => opts.json = true,
            "--no-color" => opts.no_color = true,
            "-n" | "--node" => opts.node = true,
            "-q" | "--query" => opts.query = Some(take_arg(&args, &mut i, &a)?),
            "--tab" => opts.tab = true,
            "-x" | "--xpath" => opts.xpath = Some(take_arg(&args, &mut i, &a)?),
            _ if a.starts_with("--") => return Err(format!("unknown flag: {}", a)),
            _ if a.starts_with('-') => return Err(format!("unknown shorthand flag: {}", a)),
            _ => opts.file = Some(a),
        }
        i += 1;
    }
    if opts.in_place && opts.file.is_none() {
        print!("{}", help());
        std::process::exit(0);
    }
    Ok(opts)
}

fn take_arg(args: &[String], i: &mut usize, flag: &str) -> Result<String, String> {
    *i += 1;
    args.get(*i).cloned().ok_or_else(|| format!("flag needs an argument: {}", flag))
}

fn parse_document(input: &str, html: bool) -> (Vec<Item>, Node) {
    let mut pos = 0;
    let mut prefix = Vec::new();
    let mut stack: Vec<Node> = vec![Node { name: "__doc__".into(), attrs: vec![], children: vec![] }];
    while pos < input.len() {
        if input[pos..].starts_with("<!--") {
            if let Some(end) = input[pos + 4..].find("-->") {
                push_item(&mut stack, Item::Comment(input[pos + 4..pos + 4 + end].to_string()));
                pos += 4 + end + 3;
            } else { break; }
        } else if input[pos..].starts_with("<![CDATA[") {
            if let Some(end) = input[pos + 9..].find("]]>") {
                push_item(&mut stack, Item::CData(input[pos + 9..pos + 9 + end].to_string()));
                pos += 9 + end + 3;
            } else { break; }
        } else if input[pos..].starts_with("<?") {
            if let Some(end) = input[pos + 2..].find("?>") {
                let item = Item::Proc(input[pos + 2..pos + 2 + end].trim().to_string());
                if stack.len() == 1 { prefix.push(item); } else { push_item(&mut stack, item); }
                pos += 2 + end + 2;
            } else { break; }
        } else if input.as_bytes()[pos] == b'<' {
            if let Some(end) = find_tag_end(input, pos + 1) {
                let raw = input[pos + 1..end].trim();
                if raw.starts_with('/') {
                    let want = local_name(raw[1..].split_whitespace().next().unwrap_or(""));
                    close_until(&mut stack, &want);
                } else {
                    let self_close = raw.ends_with('/') || (html && html_void_name(raw));
                    let clean = raw.trim_end_matches('/').trim();
                    if !clean.starts_with('!') {
                        let node = parse_tag(clean);
                        if self_close {
                            push_item(&mut stack, Item::Element(node));
                        } else {
                            stack.push(node);
                        }
                    }
                }
                pos = end + 1;
            } else { break; }
        } else {
            let next = input[pos..].find('<').map(|n| pos + n).unwrap_or(input.len());
            let text = decode_entities(&input[pos..next]);
            if !text.trim().is_empty() {
                push_item(&mut stack, Item::Text(text.trim().to_string()));
            }
            pos = next;
        }
    }
    while stack.len() > 2 {
        let n = stack.pop().unwrap();
        push_item(&mut stack, Item::Element(n));
    }
    if stack.len() == 2 {
        (prefix, stack.pop().unwrap())
    } else {
        let doc = stack.pop().unwrap();
        let mut elems: Vec<Node> = doc.children.into_iter().filter_map(|it| if let Item::Element(n) = it { Some(n) } else { None }).collect();
        (prefix, elems.pop().unwrap_or(Node { name: String::new(), attrs: vec![], children: vec![] }))
    }
}

fn push_item(stack: &mut Vec<Node>, item: Item) {
    if let Some(last) = stack.last_mut() {
        last.children.push(item);
    }
}

fn find_tag_end(s: &str, mut p: usize) -> Option<usize> {
    let mut quote = None;
    while p < s.len() {
        let c = s.as_bytes()[p] as char;
        if c == '"' || c == '\'' {
            if quote == Some(c) { quote = None; } else if quote.is_none() { quote = Some(c); }
        } else if c == '>' && quote.is_none() {
            return Some(p);
        }
        p += 1;
    }
    None
}

fn parse_tag(raw: &str) -> Node {
    let mut parts = split_ws_quoted(raw);
    let first = parts.next().unwrap_or_default();
    let name = local_name(&first);
    let mut attrs = Vec::new();
    for p in parts {
        if let Some(eq) = p.find('=') {
            let k = local_name(&p[..eq]);
            let mut v = p[eq + 1..].trim().to_string();
            v = v.trim_matches('"').trim_matches('\'').to_string();
            attrs.push((k, decode_entities(&v)));
        } else if !p.is_empty() {
            attrs.push((local_name(&p), String::new()));
        }
    }
    Node { name, attrs, children: Vec::new() }
}

fn split_ws_quoted(s: &str) -> std::vec::IntoIter<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut quote = None;
    for c in s.chars() {
        if c == '"' || c == '\'' {
            if quote == Some(c) { quote = None; } else if quote.is_none() { quote = Some(c); }
            cur.push(c);
        } else if c.is_whitespace() && quote.is_none() {
            if !cur.is_empty() { out.push(cur.clone()); cur.clear(); }
        } else {
            cur.push(c);
        }
    }
    if !cur.is_empty() { out.push(cur); }
    out.into_iter()
}

fn local_name(s: &str) -> String {
    s.rsplit(':').next().unwrap_or(s).to_string()
}

fn html_void_name(raw: &str) -> bool {
    let name = raw.split_whitespace().next().unwrap_or("").trim_end_matches('/').to_ascii_lowercase();
    matches!(name.as_str(), "area"|"base"|"br"|"col"|"embed"|"hr"|"img"|"input"|"link"|"meta"|"param"|"source"|"track"|"wbr")
}

fn close_until(stack: &mut Vec<Node>, want: &str) {
    while stack.len() > 1 {
        let n = stack.pop().unwrap();
        let matched = n.name == want;
        push_item(stack, Item::Element(n));
        if matched { break; }
    }
}

fn indent(level: usize, opts: &Opts) -> String {
    if opts.tab { "\t".repeat(level) } else { " ".repeat(level * opts.indent) }
}

fn format_item(item: &Item, level: usize, opts: &Opts, out: &mut String) {
    match item {
        Item::Element(n) => format_node(n, level, opts, out),
        Item::Comment(c) => out.push_str(&format!("{}<!--{}-->\n", indent(level, opts), c)),
        Item::Proc(p) => out.push_str(&format!("{}<?{}?>\n", indent(level, opts), p)),
        Item::CData(c) => out.push_str(&format!("{}<![CDATA[{}]]>\n", indent(level, opts), c)),
        Item::Text(t) => out.push_str(&format!("{}{}\n", indent(level, opts), t.trim())),
    }
}

fn format_node(n: &Node, level: usize, opts: &Opts, out: &mut String) {
    let pad = indent(level, opts);
    let tag = tag_open(n);
    let elems = n.children.iter().filter(|c| matches!(c, Item::Element(_))).count();
    let non_elem = n.children.iter().filter(|c| !matches!(c, Item::Element(_))).count();
    if n.children.is_empty() && matches!(n.name.as_str(), "script" | "style" | "textarea") {
        out.push_str(&format!("{}<{}></{}>\n", pad, tag, n.name));
    } else if n.children.is_empty() {
        out.push_str(&format!("{}<{}{}/>\n", pad, tag, ""));
    } else if elems == 0 && non_elem == 1 {
        out.push_str(&format!("{}<{}>{}</{}>\n", pad, tag, text_content(n).trim(), n.name));
    } else if matches!(n.children.first(), Some(Item::Text(_))) {
        if let Some(Item::Text(t)) = n.children.first() {
            out.push_str(&format!("{}<{}>{}\n", pad, tag, t.trim()));
        }
        for child in n.children.iter().skip(1) {
            format_item(child, level + 1, opts, out);
        }
        out.push_str(&format!("{}</{}>\n", pad, n.name));
    } else {
        out.push_str(&format!("{}<{}>\n", pad, tag));
        for child in &n.children {
            format_item(child, level + 1, opts, out);
        }
        out.push_str(&format!("{}</{}>\n", pad, n.name));
    }
}

fn node_fragment(n: &Node, opts: &Opts) -> String {
    let mut s = String::new();
    format_node(n, 0, opts, &mut s);
    s
}

fn tag_open(n: &Node) -> String {
    let mut s = n.name.clone();
    for (k, v) in &n.attrs {
        s.push(' ');
        s.push_str(k);
        s.push_str("=\"");
        s.push_str(&escape_attr(v));
        s.push('"');
    }
    s
}

fn text_content(n: &Node) -> String {
    let mut parts = Vec::new();
    collect_text(n, &mut parts);
    parts.join(" ")
}

fn direct_text(n: &Node) -> String {
    let parts: Vec<String> = n.children.iter().filter_map(|c| match c {
        Item::Text(t) | Item::CData(t) if !t.trim().is_empty() => Some(t.trim().to_string()),
        _ => None,
    }).collect();
    parts.join(" ")
}

fn collect_text(n: &Node, out: &mut Vec<String>) {
    for c in &n.children {
        match c {
            Item::Text(t) | Item::CData(t) => if !t.trim().is_empty() { out.push(t.trim().to_string()); },
            Item::Element(e) => collect_text(e, out),
            _ => {}
        }
    }
}

fn descendants<'a>(n: &'a Node, out: &mut Vec<&'a Node>) {
    out.push(n);
    for c in &n.children {
        if let Item::Element(e) = c {
            descendants(e, out);
        }
    }
}

fn xpath_output(root: &Node, path: &str, node: bool, first: bool, opts: &Opts) -> String {
    let attr_req = path.rsplit_once("/@").map(|(p, a)| (p, a));
    let p = attr_req.map(|x| x.0).unwrap_or(path);
    let mut nodes = if let Some(name) = p.strip_prefix("//") {
        let mut all = Vec::new();
        descendants(root, &mut all);
        all.into_iter().filter(|n| n.name == local_name(name)).collect::<Vec<_>>()
    } else if p.starts_with('/') {
        select_abs(root, p)
    } else {
        Vec::new()
    };
    if first && nodes.len() > 1 { nodes.truncate(1); }
    let mut out = String::new();
    for n in nodes {
        if let Some((_, a)) = attr_req {
            if let Some(v) = get_attr(n, &local_name(a)) { out.push_str(v); out.push('\n'); }
        } else if node {
            out.push_str(&node_fragment(n, opts));
        } else {
            out.push_str(text_content(n).trim());
            out.push('\n');
        }
    }
    out
}

fn select_abs<'a>(root: &'a Node, path: &str) -> Vec<&'a Node> {
    let parts: Vec<String> = path.trim_matches('/').split('/').filter(|p| !p.is_empty()).map(local_name).collect();
    if parts.is_empty() { return vec![]; }
    let mut cur = if root.name == parts[0] { vec![root] } else { vec![] };
    for part in parts.iter().skip(1) {
        let mut next = Vec::new();
        for n in cur {
            for c in &n.children {
                if let Item::Element(e) = c {
                    if &e.name == part { next.push(e); }
                }
            }
        }
        cur = next;
    }
    cur
}

fn css_output(root: &Node, q: &str, attr: Option<&str>, node: bool, opts: &Opts) -> String {
    let mut selected = css_select(root, q);
    let mut out = String::new();
    for n in selected.drain(..) {
        if let Some(a) = attr {
            if let Some(v) = get_attr(n, a) { out.push_str(v); out.push('\n'); }
        } else if node {
            out.push_str(&node_fragment(n, opts));
        } else {
            out.push_str(text_content(n).trim());
            out.push('\n');
        }
    }
    out
}

fn css_select<'a>(root: &'a Node, q: &str) -> Vec<&'a Node> {
    if let Some((parent, child)) = q.split_once('>') {
        let parents = css_select(root, parent.trim());
        let mut out = Vec::new();
        for p in parents {
            for c in &p.children {
                if let Item::Element(e) = c {
                    if css_match(e, child.trim()) { out.push(e); }
                }
            }
        }
        return out;
    }
    if q.contains(' ') {
        let mut parts = q.split_whitespace();
        let first = parts.next().unwrap_or("");
        let rest = parts.collect::<Vec<_>>().join(" ");
        let mut out = Vec::new();
        for p in css_select(root, first) {
            for n in css_select(p, &rest) {
                if !std::ptr::eq(n, p) { out.push(n); }
            }
        }
        return out;
    }
    let mut all = Vec::new();
    descendants(root, &mut all);
    all.into_iter().filter(|n| css_match(n, q.trim())).collect()
}

fn css_match(n: &Node, sel: &str) -> bool {
    if sel.is_empty() { return false; }
    if let Some(cls) = sel.strip_prefix('.') {
        return get_attr(n, "class").map(|v| v.split_whitespace().any(|c| c == cls)).unwrap_or(false);
    }
    if let Some(id) = sel.strip_prefix('#') {
        return get_attr(n, "id") == Some(id);
    }
    if let Some((tag, cls)) = sel.split_once('.') {
        return n.name == tag && get_attr(n, "class").map(|v| v.split_whitespace().any(|c| c == cls)).unwrap_or(false);
    }
    n.name == sel
}

fn get_attr<'a>(n: &'a Node, name: &str) -> Option<&'a str> {
    n.attrs.iter().find(|(k, _)| k == name).map(|(_, v)| v.as_str())
}

#[derive(Clone)]
enum J {
    Obj(BTreeMap<String, J>),
    Arr(Vec<J>),
    Str(String),
}

fn json_output(root: &Node, compact: bool, depth: i32) -> String {
    let mut top = BTreeMap::new();
    top.insert(root.name.clone(), node_json(root, 0, depth));
    let j = J::Obj(top);
    let mut s = String::new();
    write_json(&j, 0, compact, &mut s);
    s.push('\n');
    s
}

fn node_json(n: &Node, level: i32, depth: i32) -> J {
    if depth >= 0 && level >= depth {
        return J::Str(text_content(n));
    }
    let elems: Vec<&Node> = n.children.iter().filter_map(|c| if let Item::Element(e) = c { Some(e) } else { None }).collect();
    let txt = direct_text(n);
    if n.attrs.is_empty() && elems.is_empty() {
        return J::Str(txt);
    }
    let mut map: BTreeMap<String, J> = BTreeMap::new();
    if !txt.is_empty() { map.insert("#text".into(), J::Str(txt)); }
    for (k, v) in &n.attrs { map.insert(format!("@{}", k), J::Str(v.clone())); }
    let mut grouped: BTreeMap<String, Vec<J>> = BTreeMap::new();
    for e in elems {
        grouped.entry(e.name.clone()).or_default().push(node_json(e, level + 1, depth));
    }
    for (k, vals) in grouped {
        if vals.len() == 1 {
            map.insert(k, vals.into_iter().next().unwrap());
        } else {
            map.insert(k, J::Arr(vals));
        }
    }
    J::Obj(map)
}

fn write_json(j: &J, level: usize, compact: bool, out: &mut String) {
    match j {
        J::Str(s) => {
            out.push('"');
            out.push_str(&escape_json(s));
            out.push('"');
        }
        J::Arr(a) => {
            out.push('[');
            for (i, v) in a.iter().enumerate() {
                if i > 0 { out.push(','); }
                if !compact { out.push('\n'); out.push_str(&" ".repeat((level + 1) * 2)); }
                write_json(v, level + 1, compact, out);
            }
            if !a.is_empty() && !compact { out.push('\n'); out.push_str(&" ".repeat(level * 2)); }
            out.push(']');
        }
        J::Obj(m) => {
            out.push('{');
            for (i, (k, v)) in m.iter().enumerate() {
                if i > 0 { out.push(','); }
                if !compact { out.push('\n'); out.push_str(&" ".repeat((level + 1) * 2)); }
                out.push('"'); out.push_str(&escape_json(k)); out.push('"'); out.push_str(": ");
                write_json(v, level + 1, compact, out);
            }
            if !m.is_empty() && !compact { out.push('\n'); out.push_str(&" ".repeat(level * 2)); }
            out.push('}');
        }
    }
}

fn decode_entities(s: &str) -> String {
    s.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", "\"").replace("&apos;", "'").replace("&nbsp;", " ")
}

fn escape_attr(s: &str) -> String {
    s.replace('&', "&amp;").replace('"', "&quot;")
}

fn escape_json(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c < ' ' => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}
