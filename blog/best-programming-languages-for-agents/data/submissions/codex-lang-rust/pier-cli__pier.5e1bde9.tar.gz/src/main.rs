use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};
use std::process::{self, Command};

const VERSION: &str = "0.1.6";

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
struct Config {
    #[serde(default)]
    scripts: BTreeMap<String, Script>,
    #[serde(default)]
    default: BTreeMap<String, toml::Value>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
struct Script {
    command: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    description: Option<String>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    tags: Vec<String>,
}

fn main() {
    let code = match run() {
        Ok(code) => code,
        Err(msg) => {
            eprintln!("error: {}", msg);
            1
        }
    };
    process::exit(code);
}

fn run() -> Result<i32, String> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "--version" || a == "-V") {
        println!("pier {}", VERSION);
        return Ok(0);
    }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_help(args.get(0).map(String::as_str));
        return Ok(0);
    }

    let mut config_file: Option<PathBuf> = None;
    let mut verbose = false;
    let i = 0;
    while i < args.len() {
        if !args[i].starts_with('-') {
            break;
        }
        match args[i].as_str() {
            "-c" | "--config-file" => {
                if i + 1 >= args.len() {
                    return Err("The argument '--config-file <path>' requires a value but none was supplied".into());
                }
                config_file = Some(PathBuf::from(args.remove(i + 1)));
                args.remove(i);
            }
            "-v" | "--verbose" => {
                verbose = true;
                args.remove(i);
            }
            _ => break,
        }
    }
    let _ = verbose;

    let first = args.first().cloned();
    match first.as_deref() {
        None => {
            eprintln!("error: The following required arguments were not provided:\n    <alias>\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <alias> [args]...\n    executable [FLAGS] [OPTIONS] <SUBCOMMAND>\n\nFor more information try --help");
            Ok(1)
        }
        Some("config-init") | Some("init") => config_init(config_file).map(|_| 0),
        Some("add") => add(config_file, &args[1..]).map(|_| 0),
        Some("list") | Some("ls") => list(config_file, &args[1..]).map(|_| 0),
        Some("show") => show(config_file, args.get(1)).map(|_| 0),
        Some("run") => run_alias(config_file, args.get(1), &args[2..]),
        Some("remove") | Some("rm") => remove(config_file, args.get(1)).map(|_| 0),
        Some("copy") | Some("cp") => copy_alias(config_file, &args[1..], false).map(|_| 0),
        Some("move") | Some("mv") | Some("rename") => move_alias(config_file, &args[1..]).map(|_| 0),
        Some("edit") => edit(config_file, args.get(1)).map(|_| 0),
        Some("help") => {
            if args.len() > 1 {
                print_help(args.get(1).map(String::as_str));
            } else {
                print_help(None);
            }
            Ok(0)
        }
        Some(alias) => {
            let path = find_config(config_file)?;
            let cfg = read_config(&path)?;
            if cfg.scripts.contains_key(alias) {
                run_script(&cfg.scripts[alias], &args[1..])
            } else {
                Err(format!("AliasNotFound: No script found by alias {}", alias))
            }
        }
    }
}

fn print_help(topic: Option<&str>) {
    match topic {
        Some("add") => println!("executable-add {VERSION}\nAdd a new script to config.\n\nUSAGE:\n    executable add [FLAGS] [OPTIONS] --alias <alias> [--] [command]\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -a, --alias <alias>                The alias or name for the script.\n    -d, --description <description>    The description for the script.\n    -t, --tag <tags>...                Set which tags the script belongs to.\n\nARGS:\n    <command>    The command/script content to be executed. If this argument is not found it will open your $EDITOR\n                 for you to enter the script into."),
        Some("list") | Some("ls") => println!("executable-list {VERSION}\nalias: ls - List scripts\n\nDisplay options are determined by priority in this order:\n\n1. List only aliases\n\n2. Show full command\n\n3. Command display with (cli option)\n\n4. Command display with (config option)\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n    -l, --cmd_full        \n            Display the full command.\n\n    -h, --help            \n            Prints help information\n\n    -q, --list_aliases    \n            Only displays aliases of the scripts.\n\n    -V, --version         \n            Prints version information\n\n\nOPTIONS:\n    -c, --cmd_width <cmd-width>    \n            The max number of characters to display from the command.\n\n    -t, --tag <tags>...            \n            Filter based on tags."),
        Some("run") => println!("executable-run {VERSION}\nRun a script matching alias.\n\nUSAGE:\n    executable run <alias> [args]...\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>      The alias or name for the script.\n    <args>...    The positional arguments to send to script."),
        Some("show") => println!("executable-show {VERSION}\nShow a script matching alias.\n\nUSAGE:\n    executable show <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script."),
        Some("remove") | Some("rm") => println!("executable-remove {VERSION}\nalias: rm - Remove a script matching alias.\n\nUSAGE:\n    executable remove <alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <alias>    The alias or name for the script."),
        Some("copy") | Some("cp") => println!("executable-copy {VERSION}\nalias: cp - Copy existing alias to the new one\n\nUSAGE:\n    executable copy <from-alias> <to-alias>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be copied.\n    <to-alias>      The new alias of the copy of the script."),
        Some("move") | Some("mv") | Some("rename") => println!("executable-move {VERSION}\nalias: mv, rename - Move/rename existing alias to the new one\n\nUSAGE:\n    executable move [FLAGS] <from-alias> <to-alias>\n\nFLAGS:\n    -f, --force      Allows to overwrite the existing script\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nARGS:\n    <from-alias>    The alias of the script that will be moved.\n    <to-alias>      The new alias of the script."),
        Some("config-init") | Some("init") => println!("executable-config-init {VERSION}\nalias: init - Add a config file.\n\nUSAGE:\n    executable config-init\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information"),
        _ => println!("pier {VERSION}\nBenjamin Scholtz, Isak Johansson\nA simple script management CLI\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] <alias> [args]...\n    executable [FLAGS] [OPTIONS] <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       \n            Prints help information\n\n    -V, --version    \n            Prints version information\n\n    -v, --verbose    \n            The level of verbosity\n\n\nOPTIONS:\n    -c, --config-file <path>    \n            Sets a custom config file.\n\nSUBCOMMANDS:\n    add            Add a new script to config.\n    config-init    alias: init - Add a config file.\n    copy           alias: cp - Copy existing alias to the new one\n    edit           Edit a script matching alias.\n    help           Prints this message or the help of the given subcommand(s)\n    list           alias: ls - List scripts\n    move           alias: mv, rename - Move/rename existing alias to the new one\n    remove         alias: rm - Remove a script matching alias.\n    run            Run a script matching alias.\n    show           Show a script matching alias."),
    }
}

fn candidate_paths() -> Vec<PathBuf> {
    let mut v = Vec::new();
    if let Ok(p) = env::var("PIER_CONFIG_PATH") {
        if !p.is_empty() { v.push(PathBuf::from(p)); }
    }
    v.push(PathBuf::from("pier.toml"));
    if let Ok(xdg) = env::var("XDG_CONFIG_HOME") {
        v.push(PathBuf::from(&xdg).join("pier/config.toml"));
        v.push(PathBuf::from(&xdg).join("pier/config"));
        v.push(PathBuf::from(&xdg).join("pier.toml"));
    }
    if let Ok(home) = env::var("HOME") {
        v.push(PathBuf::from(&home).join(".pier.toml"));
        v.push(PathBuf::from(&home).join(".pier"));
    }
    v
}

fn find_config(given: Option<PathBuf>) -> Result<PathBuf, String> {
    if let Some(p) = given { return Ok(p); }
    for p in candidate_paths() {
        if p.exists() { return Ok(p); }
    }
    Err("No default config file found. See help for more info.".into())
}

fn default_config_path(given: Option<PathBuf>) -> PathBuf {
    if let Some(p) = given { return p; }
    if let Ok(xdg) = env::var("XDG_CONFIG_HOME") {
        return PathBuf::from(xdg).join("pier/config.toml");
    }
    if let Ok(home) = env::var("HOME") {
        return PathBuf::from(home).join(".config/pier/config.toml");
    }
    PathBuf::from("pier.toml")
}

fn read_config(path: &Path) -> Result<Config, String> {
    let s = fs::read_to_string(path).map_err(|e| e.to_string())?;
    if s.trim().is_empty() {
        return Ok(Config::default());
    }
    toml::from_str(&s).map_err(|e| format!("ConfigError: {}", e))
}

fn write_config(path: &Path, cfg: &Config) -> Result<(), String> {
    let mut out = String::new();
    for (alias, script) in &cfg.scripts {
        out.push_str(&format!("[scripts.{}]\n", alias));
        out.push_str(&format!("command = '{}'\n", script.command.replace('\'', "\\'")));
        if let Some(d) = &script.description {
            out.push_str(&format!("description = '{}'\n", d.replace('\'', "\\'")));
        }
        if !script.tags.is_empty() {
            out.push_str("tags = [\n");
            for t in &script.tags {
                out.push_str(&format!("    '{}',\n", t.replace('\'', "\\'")));
            }
            out.push_str("]\n");
        }
        out.push('\n');
    }
    out.push_str("[default]\n");
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| format!("Failed to create directory. {}", e))?;
    }
    fs::write(path, out).map_err(|e| e.to_string())
}

fn config_init(given: Option<PathBuf>) -> Result<(), String> {
    let path = default_config_path(given);
    let mut cfg = Config::default();
    cfg.scripts.insert("hello-pier".into(), Script {
        command: "echo Hello, Pier!".into(),
        description: Some("This is an example command.".into()),
        tags: Vec::new(),
    });
    write_config(&path, &cfg)?;
    println!("Added hello-pier");
    Ok(())
}

fn add(given: Option<PathBuf>, args: &[String]) -> Result<(), String> {
    let mut alias = None;
    let mut desc = None;
    let mut tags = Vec::new();
    let mut force = false;
    let mut cmd = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-a" | "--alias" => { i += 1; alias = args.get(i).cloned(); }
            "-d" | "--description" => { i += 1; desc = args.get(i).cloned(); }
            "-t" | "--tag" => { i += 1; if let Some(t) = args.get(i) { tags.push(t.clone()); } }
            "-f" | "--force" => force = true,
            "--" => { i += 1; if let Some(c) = args.get(i) { cmd = Some(c.clone()); } }
            other if !other.starts_with('-') && cmd.is_none() => cmd = Some(other.to_string()),
            _ => {}
        }
        i += 1;
    }
    let alias = alias.ok_or_else(|| "The following required arguments were not provided:\n    --alias <alias>".to_string())?;
    let command = match cmd {
        Some(c) => c,
        None => editor_input()?,
    };
    let path = find_config(given)?;
    let mut cfg = read_config(&path)?;
    if cfg.scripts.contains_key(&alias) && !force {
        return Err(format!("AliasAlreadyExists:  {}", alias));
    }
    cfg.scripts.insert(alias.clone(), Script { command, description: desc, tags });
    write_config(&path, &cfg)?;
    println!("Added {}", alias);
    Ok(())
}

fn editor_input() -> Result<String, String> {
    let editor = env::var("EDITOR").unwrap_or_else(|_| "vi".into());
    if editor == "-" {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        Ok(s.trim_end().to_string())
    } else {
        Err(format!("EditorError: Failed when trying to get input from editor Failed to open `{}` as a text editor or editor was terminated with errors.", editor))
    }
}

fn list(given: Option<PathBuf>, args: &[String]) -> Result<(), String> {
    let path = find_config(given)?;
    let cfg = read_config(&path)?;
    if cfg.scripts.is_empty() {
        return Err("No scripts exist. Would you like to add a new script?".into());
    }
    let mut aliases_only = false;
    let mut full = false;
    let mut width: Option<usize> = None;
    let mut filters = Vec::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-q" | "--list_aliases" => aliases_only = true,
            "-l" | "--cmd_full" => full = true,
            "-c" | "--cmd_width" => { i += 1; width = args.get(i).and_then(|s| s.parse().ok()); }
            "-t" | "--tag" => { i += 1; if let Some(t) = args.get(i) { filters.push(t.clone()); } }
            _ => {}
        }
        i += 1;
    }
    let rows: Vec<_> = cfg.scripts.iter()
        .filter(|(_, s)| filters.is_empty() || filters.iter().any(|t| s.tags.contains(t)))
        .collect();
    if aliases_only {
        for (a, _) in rows { println!("{}", a); }
        return Ok(());
    }
    let cmd_w = if full { None } else { width };
    print_table(&rows, cmd_w);
    Ok(())
}

fn trim_chars(s: &str, n: Option<usize>) -> String {
    match n {
        Some(w) => s.chars().take(w).collect(),
        None => s.to_string(),
    }
}

fn print_table(rows: &[(&String, &Script)], cmd_width: Option<usize>) {
    let mut data = Vec::new();
    for (a, s) in rows {
        data.push((a.to_string(), s.tags.join(","), trim_chars(&s.command, cmd_width), s.description.clone().unwrap_or_default()));
    }
    let widths = [
        std::cmp::max(5, data.iter().map(|r| r.0.chars().count()).max().unwrap_or(0)),
        std::cmp::max(4, data.iter().map(|r| r.1.chars().count()).max().unwrap_or(0)),
        std::cmp::max(7, data.iter().map(|r| r.2.chars().count()).max().unwrap_or(0)),
        std::cmp::max(11, data.iter().map(|r| r.3.chars().count()).max().unwrap_or(0)),
    ];
    let total: usize = widths.iter().sum::<usize>() + 13;
    println!("{}", "≖".repeat(total));
    println!("⋮ {:<w0$} ⋮ {:<w1$} ⋮ {:<w2$} ⋮ {:<w3$} ⋮", "Alias", "Tags", "Command", "Description", w0=widths[0], w1=widths[1], w2=widths[2], w3=widths[3]);
    println!("{}", "≖".repeat(total));
    for r in data {
        println!("⋮ {:<w0$} ⋮ {:<w1$} ⋮ {:<w2$} ⋮ {:<w3$} ⋮", r.0, r.1, r.2, r.3, w0=widths[0], w1=widths[1], w2=widths[2], w3=widths[3]);
    }
    println!("{}", "≖".repeat(total));
}

fn get_script<'a>(cfg: &'a Config, alias: Option<&String>) -> Result<(&'a String, &'a Script), String> {
    let a = alias.ok_or_else(|| "The following required arguments were not provided:\n    <alias>".to_string())?;
    cfg.scripts.get_key_value(a).ok_or_else(|| format!("AliasNotFound: No script found by alias {}", a))
}

fn show(given: Option<PathBuf>, alias: Option<&String>) -> Result<(), String> {
    let path = find_config(given)?;
    let cfg = read_config(&path)?;
    if cfg.scripts.is_empty() { return Err("No scripts exist. Would you like to add a new script?".into()); }
    let (_, s) = get_script(&cfg, alias)?;
    println!("{}", s.command);
    Ok(())
}

fn run_alias(given: Option<PathBuf>, alias: Option<&String>, pass: &[String]) -> Result<i32, String> {
    let path = find_config(given)?;
    let cfg = read_config(&path)?;
    let (_, s) = get_script(&cfg, alias)?;
    run_script(s, pass)
}

fn run_script(s: &Script, pass: &[String]) -> Result<i32, String> {
    let status = Command::new("sh")
        .arg("-c").arg(&s.command)
        .arg("pier")
        .args(pass)
        .status()
        .map_err(|e| e.to_string())?;
    Ok(status.code().unwrap_or(1))
}

fn remove(given: Option<PathBuf>, alias: Option<&String>) -> Result<(), String> {
    let path = find_config(given)?;
    let mut cfg = read_config(&path)?;
    let a = alias.ok_or_else(|| "The following required arguments were not provided:\n    <alias>".to_string())?.clone();
    if cfg.scripts.remove(&a).is_none() {
        return Err(format!("AliasNotFound: No script found by alias {}", a));
    }
    write_config(&path, &cfg)?;
    println!("Removed {}", a);
    Ok(())
}

fn copy_alias(given: Option<PathBuf>, args: &[String], force: bool) -> Result<(), String> {
    if args.len() < 2 { return Err("The following required arguments were not provided".into()); }
    let path = find_config(given)?;
    let mut cfg = read_config(&path)?;
    let from = &args[0];
    let to = &args[1];
    let script = cfg.scripts.get(from).cloned().ok_or_else(|| format!("AliasNotFound: No script found by alias {}", from))?;
    if cfg.scripts.contains_key(to) && !force {
        return Err(format!("AliasAlreadyExists:  {}", to));
    }
    cfg.scripts.insert(to.clone(), script);
    write_config(&path, &cfg)?;
    println!("Copy from alias {} to new alias {}", from, to);
    Ok(())
}

fn move_alias(given: Option<PathBuf>, args: &[String]) -> Result<(), String> {
    let mut force = false;
    let rest: Vec<String> = args.iter().filter_map(|a| {
        if a == "-f" || a == "--force" { force = true; None } else { Some(a.clone()) }
    }).collect();
    if rest.len() < 2 { return Err("The following required arguments were not provided".into()); }
    let path = find_config(given)?;
    let mut cfg = read_config(&path)?;
    let from = &rest[0];
    let to = &rest[1];
    if cfg.scripts.contains_key(to) && !force {
        return Err(format!("AliasAlreadyExists:  {}", to));
    }
    let script = cfg.scripts.remove(from).ok_or_else(|| format!("AliasNotFound: No script found by alias {}", from))?;
    cfg.scripts.insert(to.clone(), script);
    write_config(&path, &cfg)?;
    println!("Move from alias {} to new alias {}", from, to);
    Ok(())
}

fn edit(given: Option<PathBuf>, alias: Option<&String>) -> Result<(), String> {
    let path = find_config(given)?;
    let mut cfg = read_config(&path)?;
    let a = alias.ok_or_else(|| "The following required arguments were not provided:\n    <alias>".to_string())?.clone();
    let current = cfg.scripts.get(&a).cloned().ok_or_else(|| format!("AliasNotFound: No script found by alias {}", a))?;
    let mut updated = current;
    updated.command = editor_input().unwrap_or(updated.command);
    cfg.scripts.insert(a.clone(), updated);
    write_config(&path, &cfg)?;
    println!("Edited {}", a);
    Ok(())
}
