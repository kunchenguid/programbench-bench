use std::collections::HashSet;
use std::env;
use std::ffi::CString;
use std::fs::{self, File};
use std::io;
use std::os::unix::ffi::OsStrExt;
use std::os::unix::fs::{symlink, MetadataExt, PermissionsExt};
use std::path::{Path, PathBuf};

const HELP_SHORT: &str = r#"A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...  Path list

Options:
  -v, --verbose...
          Verbosity
  -r, --recursive
          Copy directories recursively
  -L, --dereference
          Dereference symlinks in source
  -w, --workers <WORKERS>
          Number of parallel workers [default: 4]
      --block-size <BLOCK_SIZE>
          Block size for operations [default: 1MB]
  -n, --no-clobber
          Do not overwrite an existing file
  -f, --force
          Force (compatability only)
      --gitignore
          Use .gitignore if present
  -g, --glob
          Expand file patterns
      --no-progress
          Disable progress bar
      --no-perms
          Do not copy the file permissions
      --no-timestamps
          Do not copy the file timestamps
  -o, --ownership
          Copy ownership
      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel' [default: parfile]
  -T, --no-target-directory
          Target should not be a directory
      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target
      --fsync
          Sync each file to disk after writing
      --reflink <REFLINK>
          Reflink options [default: auto]
      --backup <BACKUP>
          Backup options [default: none]
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"#;

const HELP_LONG: &str = r#"A (partial) clone of the Unix `cp` command with progress and pluggable drivers.

Usage: executable [OPTIONS] [PATHS]...

Arguments:
  [PATHS]...
          Path list.
          
          Source and destination files, or multiple source(s) to a directory.

Options:
  -v, --verbose...
          Verbosity.
          
          Can be specified multiple times to increase logging.

  -r, --recursive
          Copy directories recursively

  -L, --dereference
          Dereference symlinks in source
          
          Follow symlinks, possibly recursively, when copying source files.

  -w, --workers <WORKERS>
          Number of parallel workers.
          
          Default is 4; if the value is negative or 0 it uses the number of logical CPUs.
          
          [default: 4]

      --block-size <BLOCK_SIZE>
          Block size for operations.
          
          Accepts standard size modifiers like "M" and "GB". Actual usage internally depends on the driver.
          
          [default: 1MB]

  -n, --no-clobber
          Do not overwrite an existing file

  -f, --force
          Force (compatability only)
          
          Overwrite files; this is the default behaviour, this flag is for compatibility with `cp` only. See `--no-clobber` for the inverse flag. Using this in conjunction with `--no-clobber` will cause an error.

      --gitignore
          Use .gitignore if present.
          
          NOTE: This is fairly basic at the moment, and only honours a .gitignore in the directory root for directory copies; global or sub-directory ignores are skipped.

  -g, --glob
          Expand file patterns.
          
          Glob (expand) filename patterns natively (note; the shell may still do its own expansion first)

      --no-progress
          Disable progress bar

      --no-perms
          Do not copy the file permissions

      --no-timestamps
          Do not copy the file timestamps

  -o, --ownership
          Copy ownership.
          
          Whether to copy ownship (user/group).  This option requires root permissions or appropriate capabilities; if the attempt to copy ownership fails a warning is issued but the operation continues.

      --driver <DRIVER>
          Driver to use, defaults to 'file-parallel'.
          
          Currently there are 2; the default "parfile", which parallelises copies across workers at the file level, and an experimental "parblock" driver, which parellelises at the block level. See also '--block-size'.
          
          [default: parfile]

  -T, --no-target-directory
          Target should not be a directory.
          
          Analogous to cp's no-target-directory. Expected behavior is that when copying a directory to another directory, instead of creating a sub-folder in target, overwrite target.

      --target-directory <TARGET_DIRECTORY>
          Copy into a subdirectory of the target

      --fsync
          Sync each file to disk after writing

      --reflink <REFLINK>
          Reflink options.
          
          Whether and how to use reflinks. 'auto' (the default) will attempt to reflink and fallback to a copy if it is not possible, 'always' will return an error if it cannot reflink, and 'never' will always perform a full data copy.
          
          Note: when using Linux accelerated copy operations (the default when available) the kernel may choose to reflink rather than perform a fully copy regardless of this setting.
          
          [default: auto]

      --backup <BACKUP>
          Backup options
          
          Whether to create backups of overwritten files. Current options are 'none'/'off', or 'numbered', or 'auto'. Numbered backups follow the semantics of `cp` numbered backups (e.g. `file.txt.~123~`). 'auto' will only create a numbered backup if a previous backups exists. Default is 'none'.
          
          [default: none]

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version
"#;

#[derive(Clone, Copy, PartialEq)]
enum Backup {
    None,
    Numbered,
    Auto,
}

#[derive(Default)]
struct Opts {
    recursive: bool,
    dereference: bool,
    no_clobber: bool,
    force: bool,
    gitignore: bool,
    glob: bool,
    no_perms: bool,
    no_timestamps: bool,
    ownership: bool,
    no_target_dir: bool,
    fsync: bool,
    target_directory: Option<PathBuf>,
    backup: Backup,
    paths: Vec<String>,
}

impl Default for Backup {
    fn default() -> Self {
        Backup::None
    }
}

fn main() {
    match run() {
        Ok(()) => {}
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(1);
        }
    }
}

fn run() -> Result<(), String> {
    let mut opts = parse_args()?;
    if opts.force && opts.no_clobber {
        return Err(
            "Invalid arguments: --force and --noclobber cannot be set at the same time.".into(),
        );
    }
    if opts.glob {
        opts.paths = expand_globs(&opts.paths);
    }
    if let Some(td) = opts.target_directory.clone() {
        opts.paths.push(td.to_string_lossy().to_string());
    }
    if opts.paths.len() < 2 {
        return Err("Invalid arguments: Insufficient arguments".into());
    }

    let dest = PathBuf::from(opts.paths.last().unwrap());
    let sources: Vec<PathBuf> = opts.paths[..opts.paths.len() - 1]
        .iter()
        .map(PathBuf::from)
        .collect();

    if sources.len() > 1 && !dest.is_dir() {
        return Err(
            "Invalid destination: Multiple sources and destination is not a directory.".into(),
        );
    }

    for src in &sources {
        let target = if sources.len() > 1 {
            dest.join(
                src.file_name()
                    .ok_or_else(|| "Invalid source: Bad source path.".to_string())?,
            )
        } else if dest.is_dir() && !opts.no_target_dir {
            dest.join(
                src.file_name()
                    .ok_or_else(|| "Invalid source: Bad source path.".to_string())?,
            )
        } else {
            dest.clone()
        };
        copy_path(src, &target, &opts, None)?;
    }
    Ok(())
}

fn parse_args() -> Result<Opts, String> {
    let mut opts = Opts {
        backup: Backup::None,
        ..Default::default()
    };
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" => {
                print!("{HELP_SHORT}");
                std::process::exit(0);
            }
            "--help" => {
                print!("{HELP_LONG}");
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("xcp 0.24.3");
                std::process::exit(0);
            }
            "-r" | "--recursive" => opts.recursive = true,
            "-L" | "--dereference" => opts.dereference = true,
            "-n" | "--no-clobber" => opts.no_clobber = true,
            "-f" | "--force" => opts.force = true,
            "--gitignore" => opts.gitignore = true,
            "-g" | "--glob" => opts.glob = true,
            "--no-progress" => {}
            "--no-perms" => opts.no_perms = true,
            "--no-timestamps" => opts.no_timestamps = true,
            "-o" | "--ownership" => opts.ownership = true,
            "-T" | "--no-target-directory" => opts.no_target_dir = true,
            "--fsync" => opts.fsync = true,
            "-v" | "--verbose" => {}
            a if a.starts_with("-v") && a.chars().all(|c| c == '-' || c == 'v') => {}
            "-w" | "--workers" | "--block-size" => {
                it.next().ok_or_else(|| {
                    format!("error: a value is required for '{arg}' but none was supplied")
                })?;
            }
            "--driver" => {
                let v = it.next().ok_or_else(|| {
                    "error: a value is required for '--driver <DRIVER>' but none was supplied"
                        .to_string()
                })?;
                if v != "parfile" && v != "parblock" {
                    return clap_error(&format!(
                        "invalid value '{v}' for '--driver <DRIVER>': Unknown driver: {v}"
                    ));
                }
            }
            "--reflink" => {
                let v = it.next().ok_or_else(|| {
                    "error: a value is required for '--reflink <REFLINK>' but none was supplied"
                        .to_string()
                })?;
                if v != "auto" && v != "always" && v != "never" {
                    return clap_error(&format!("invalid value '{v}' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': {v}"));
                }
            }
            "--backup" => {
                let v = it.next().ok_or_else(|| {
                    "error: a value is required for '--backup <BACKUP>' but none was supplied"
                        .to_string()
                })?;
                opts.backup = match v.as_str() {
                    "none" | "off" => Backup::None,
                    "numbered" => Backup::Numbered,
                    "auto" => Backup::Auto,
                    _ => return clap_error(&format!("invalid value '{v}' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': {v}")),
                };
            }
            "--target-directory" => {
                let v = it.next().ok_or_else(|| "error: a value is required for '--target-directory <TARGET_DIRECTORY>' but none was supplied".to_string())?;
                opts.target_directory = Some(PathBuf::from(v));
            }
            a if a.starts_with("--target-directory=") => {
                opts.target_directory = Some(PathBuf::from(&a["--target-directory=".len()..]));
            }
            a if a.starts_with("--backup=") => {
                let v = &a["--backup=".len()..];
                opts.backup = match v {
                    "none" | "off" => Backup::None,
                    "numbered" => Backup::Numbered,
                    "auto" => Backup::Auto,
                    _ => return clap_error(&format!("invalid value '{v}' for '--backup <BACKUP>': Invalid arguments: Unexpected value for 'backup': {v}")),
                };
            }
            a if a.starts_with("--driver=") => {
                let v = &a["--driver=".len()..];
                if v != "parfile" && v != "parblock" {
                    return clap_error(&format!(
                        "invalid value '{v}' for '--driver <DRIVER>': Unknown driver: {v}"
                    ));
                }
            }
            a if a.starts_with("--reflink=") => {
                let v = &a["--reflink=".len()..];
                if v != "auto" && v != "always" && v != "never" {
                    return clap_error(&format!("invalid value '{v}' for '--reflink <REFLINK>': Invalid arguments: Unexpected value for 'reflink': {v}"));
                }
            }
            a if a.starts_with('-') && a.len() > 1 => {
                return clap_error(&format!("unexpected argument '{a}' found"))
            }
            a => opts.paths.push(a.to_string()),
        }
    }
    Ok(opts)
}

fn clap_error<T>(msg: &str) -> Result<T, String> {
    eprintln!("error: {msg}\n\nFor more information, try '--help'.");
    std::process::exit(2);
}

fn source_meta(path: &Path, dereference: bool) -> io::Result<fs::Metadata> {
    if dereference {
        fs::metadata(path)
    } else {
        fs::symlink_metadata(path)
    }
}

fn copy_path(
    src: &Path,
    dst: &Path,
    opts: &Opts,
    ignore: Option<&IgnoreSet>,
) -> Result<(), String> {
    let meta = source_meta(src, opts.dereference).map_err(|e| format!("Invalid source: {e}"))?;
    let ft = meta.file_type();
    if let Some(ig) = ignore {
        if ig.ignored(src) {
            return Ok(());
        }
    }
    if ft.is_dir() {
        if !opts.recursive {
            return Err(
                "Invalid source: Source is directory and --recursive not specified.".into(),
            );
        }
        copy_dir(src, dst, opts)
    } else if ft.is_symlink() && !opts.dereference {
        copy_symlink(src, dst, opts)
    } else if ft.is_file() {
        copy_file(src, dst, opts)
    } else {
        Err(format!("Unsupported file type: {}", src.display()))
    }
}

fn copy_dir(src: &Path, dst: &Path, opts: &Opts) -> Result<(), String> {
    prepare_dest(dst, opts)?;
    fs::create_dir_all(dst)
        .map_err(|e| format!("Failed to create directory: {e}, {}", dst.display()))?;
    let root_ignore = if opts.gitignore {
        Some(IgnoreSet::load(src))
    } else {
        None
    };
    for entry in fs::read_dir(src)
        .map_err(|e| format!("Failed to read directory: {e}, {}", src.display()))?
    {
        let entry =
            entry.map_err(|e| format!("Failed to read directory: {e}, {}", src.display()))?;
        let child_src = entry.path();
        if let Some(ig) = &root_ignore {
            if ig.ignored_under(src, &child_src) {
                continue;
            }
        }
        let child_dst = dst.join(entry.file_name());
        copy_path(&child_src, &child_dst, opts, None)?;
    }
    apply_metadata(src, dst, opts, false);
    Ok(())
}

fn copy_symlink(src: &Path, dst: &Path, opts: &Opts) -> Result<(), String> {
    prepare_dest(dst, opts)?;
    if lexists(dst) {
        let _ = fs::remove_file(dst);
    }
    let target = fs::read_link(src)
        .map_err(|e| format!("Failed to read symlink: {e}, {}", src.display()))?;
    symlink(&target, dst)
        .map_err(|e| format!("Failed to create symlink: {e}, {}", dst.display()))?;
    apply_metadata(src, dst, opts, true);
    Ok(())
}

fn copy_file(src: &Path, dst: &Path, opts: &Opts) -> Result<(), String> {
    prepare_dest(dst, opts)?;
    if let Some(parent) = dst.parent() {
        if !parent.as_os_str().is_empty() {
            fs::create_dir_all(parent)
                .map_err(|e| format!("Failed to create directory: {e}, {}", parent.display()))?;
        }
    }
    fs::copy(src, dst)
        .map_err(|e| format!("Copy failed: {e}, {} -> {}", src.display(), dst.display()))?;
    if opts.fsync {
        let f = File::options()
            .read(true)
            .open(dst)
            .map_err(|e| format!("Fsync failed: {e}, {}", dst.display()))?;
        f.sync_all()
            .map_err(|e| format!("Fsync failed: {e}, {}", dst.display()))?;
    }
    apply_metadata(src, dst, opts, false);
    Ok(())
}

fn prepare_dest(dst: &Path, opts: &Opts) -> Result<(), String> {
    if lexists(dst) {
        if opts.no_clobber {
            return Err(format!(
                "Destination Exists: Destination file exists and --no-clobber is set., {}",
                dst.display()
            ));
        }
        maybe_backup(dst, opts.backup)?;
    }
    Ok(())
}

fn maybe_backup(dst: &Path, mode: Backup) -> Result<(), String> {
    if mode == Backup::None {
        return Ok(());
    }
    if mode == Backup::Auto && next_backup(dst, false).is_none() {
        return Ok(());
    }
    let backup = next_backup(dst, true)
        .ok_or_else(|| "Backup failed: no available backup name".to_string())?;
    fs::rename(dst, &backup).map_err(|e| format!("Backup failed: {e}, {}", dst.display()))
}

fn next_backup(path: &Path, create: bool) -> Option<PathBuf> {
    let parent = path.parent().unwrap_or_else(|| Path::new(""));
    let name = path.file_name()?.to_string_lossy();
    let mut max_seen = 0u64;
    if let Ok(rd) = fs::read_dir(parent) {
        for e in rd.flatten() {
            let s = e.file_name().to_string_lossy().to_string();
            let prefix = format!("{name}.~");
            if s.starts_with(&prefix) && s.ends_with('~') {
                let mid = &s[prefix.len()..s.len() - 1];
                if let Ok(n) = mid.parse::<u64>() {
                    max_seen = max_seen.max(n);
                }
            }
        }
    }
    if !create {
        return (max_seen > 0).then(|| parent.join(format!("{name}.~{max_seen}~")));
    }
    Some(parent.join(format!("{name}.~{}~", max_seen + 1)))
}

fn lexists(path: &Path) -> bool {
    fs::symlink_metadata(path).is_ok()
}

fn apply_metadata(src: &Path, dst: &Path, opts: &Opts, symlink_path: bool) {
    if let Ok(meta) = fs::symlink_metadata(src) {
        if !opts.no_perms && !symlink_path {
            let _ = fs::set_permissions(dst, fs::Permissions::from_mode(meta.mode() & 0o7777));
        }
        if !opts.no_timestamps {
            let _ = set_times(dst, &meta, symlink_path);
        }
        if opts.ownership {
            let _ = set_owner(dst, meta.uid(), meta.gid(), symlink_path);
        }
    }
}

fn set_times(path: &Path, meta: &fs::Metadata, nofollow: bool) -> io::Result<()> {
    let cpath = CString::new(path.as_os_str().as_bytes())?;
    let times = [
        libc::timespec {
            tv_sec: meta.atime(),
            tv_nsec: meta.atime_nsec(),
        },
        libc::timespec {
            tv_sec: meta.mtime(),
            tv_nsec: meta.mtime_nsec(),
        },
    ];
    let flags = if nofollow {
        libc::AT_SYMLINK_NOFOLLOW
    } else {
        0
    };
    let rc = unsafe { libc::utimensat(libc::AT_FDCWD, cpath.as_ptr(), times.as_ptr(), flags) };
    if rc == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

fn set_owner(path: &Path, uid: u32, gid: u32, nofollow: bool) -> io::Result<()> {
    let cpath = CString::new(path.as_os_str().as_bytes())?;
    let rc = unsafe {
        if nofollow {
            libc::lchown(cpath.as_ptr(), uid, gid)
        } else {
            libc::chown(cpath.as_ptr(), uid, gid)
        }
    };
    if rc == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

#[derive(Default)]
struct IgnoreSet {
    patterns: Vec<String>,
}

impl IgnoreSet {
    fn load(root: &Path) -> Self {
        let mut out = IgnoreSet::default();
        if let Ok(text) = fs::read_to_string(root.join(".gitignore")) {
            for line in text.lines() {
                let line = line.trim();
                if line.is_empty() || line.starts_with('#') || line.starts_with('!') {
                    continue;
                }
                out.patterns.push(line.trim_start_matches('/').to_string());
            }
        }
        out
    }

    fn ignored(&self, path: &Path) -> bool {
        let s = path.to_string_lossy();
        self.patterns.iter().any(|p| wildcard_match(p, &s))
    }

    fn ignored_under(&self, root: &Path, path: &Path) -> bool {
        let rel = path
            .strip_prefix(root)
            .unwrap_or(path)
            .to_string_lossy()
            .replace('\\', "/");
        let base = path
            .file_name()
            .map(|s| s.to_string_lossy().to_string())
            .unwrap_or_default();
        self.patterns.iter().any(|p| {
            let p = p.trim_end_matches('/');
            rel == p
                || rel.starts_with(&format!("{p}/"))
                || base == p
                || wildcard_match(p, &rel)
                || wildcard_match(p, &base)
        })
    }
}

fn expand_globs(paths: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    for p in paths {
        if has_glob(p) {
            let matches = glob_matches(p);
            if matches.is_empty() {
                out.push(p.clone());
            } else {
                out.extend(matches);
            }
        } else {
            out.push(p.clone());
        }
    }
    out
}

fn has_glob(s: &str) -> bool {
    s.contains('*') || s.contains('?') || s.contains('[')
}

fn glob_matches(pattern: &str) -> Vec<String> {
    let path = Path::new(pattern);
    let parent = path
        .parent()
        .filter(|p| !p.as_os_str().is_empty())
        .unwrap_or_else(|| Path::new("."));
    let pat = path
        .file_name()
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_else(|| pattern.to_string());
    let mut seen = HashSet::new();
    let mut out = Vec::new();
    if let Ok(rd) = fs::read_dir(parent) {
        for e in rd.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if wildcard_match(&pat, &name) {
                let candidate = if parent == Path::new(".") {
                    PathBuf::from(&name)
                } else {
                    parent.join(&name)
                };
                let s = candidate.to_string_lossy().to_string();
                if seen.insert(s.clone()) {
                    out.push(s);
                }
            }
        }
    }
    out.sort();
    out
}

fn wildcard_match(pattern: &str, text: &str) -> bool {
    fn inner(p: &[u8], t: &[u8]) -> bool {
        if p.is_empty() {
            return t.is_empty();
        }
        match p[0] {
            b'*' => inner(&p[1..], t) || (!t.is_empty() && inner(p, &t[1..])),
            b'?' => !t.is_empty() && inner(&p[1..], &t[1..]),
            b'[' => {
                if let Some(end) = p.iter().position(|&c| c == b']') {
                    if t.is_empty() {
                        return false;
                    }
                    let class = &p[1..end];
                    let ok = class.contains(&t[0]);
                    ok && inner(&p[end + 1..], &t[1..])
                } else {
                    !t.is_empty() && p[0] == t[0] && inner(&p[1..], &t[1..])
                }
            }
            c => !t.is_empty() && c == t[0] && inner(&p[1..], &t[1..]),
        }
    }
    inner(pattern.as_bytes(), text.as_bytes())
}
