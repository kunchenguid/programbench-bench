use std::env;
use std::process;

const VERSION: &str = "v0.0.0-SNAPSHOT";

const CHECKERS: &[(&str, &str)] = &[
    ("appendAssign", "diagnostic"),
    ("appendCombine", "performance"),
    ("argOrder", "diagnostic"),
    ("assignOp", "style"),
    ("badCall", "diagnostic"),
    ("badCond", "diagnostic"),
    ("badLock", "diagnostic experimental"),
    ("badRegexp", "diagnostic experimental"),
    ("badSorting", "diagnostic experimental"),
    ("badSyncOnceFunc", "diagnostic experimental"),
    ("boolExprSimplify", "style experimental"),
    ("builtinShadow", "style opinionated"),
    ("builtinShadowDecl", "diagnostic experimental"),
    ("captLocal", "style"),
    ("caseOrder", "diagnostic"),
    ("codegenComment", "diagnostic"),
    ("commentFormatting", "style"),
    ("commentedOutCode", "diagnostic experimental"),
    ("commentedOutImport", "style experimental"),
    ("defaultCaseOrder", "style"),
    ("deferInLoop", "diagnostic experimental"),
    ("deferUnlambda", "style experimental"),
    ("deprecatedComment", "diagnostic"),
    ("docStub", "style experimental"),
    ("dupArg", "diagnostic"),
    ("dupBranchBody", "diagnostic"),
    ("dupCase", "diagnostic"),
    ("dupImport", "style experimental"),
    ("dupOption", "diagnostic experimental"),
    ("dupSubExpr", "diagnostic"),
    ("dynamicFmtString", "diagnostic experimental"),
    ("elseif", "style"),
    ("emptyDecl", "diagnostic experimental"),
    ("emptyFallthrough", "style experimental"),
    ("emptyStringTest", "style experimental"),
    ("equalFold", "performance experimental"),
    ("evalOrder", "diagnostic experimental"),
    ("exitAfterDefer", "diagnostic"),
    ("exposedSyncMutex", "style experimental"),
    ("externalErrorReassign", "diagnostic experimental"),
    ("filepathJoin", "diagnostic experimental"),
    ("flagDeref", "diagnostic"),
    ("flagName", "diagnostic"),
    ("hexLiteral", "style experimental"),
    ("httpNoBody", "style experimental"),
    ("hugeParam", "performance"),
    ("ifElseChain", "style"),
    ("importShadow", "style opinionated"),
    ("indexAlloc", "performance"),
    ("initClause", "style opinionated experimental"),
    ("mapKey", "diagnostic"),
    ("methodExprCall", "style experimental"),
    ("nestingReduce", "style opinionated experimental"),
    ("newDeref", "style"),
    ("nilValReturn", "diagnostic experimental"),
    ("octalLiteral", "style experimental opinionated"),
    ("offBy1", "diagnostic"),
    ("paramTypeCombine", "style opinionated"),
    ("preferDecodeRune", "performance experimental"),
    ("preferFilepathJoin", "style experimental"),
    ("preferFprint", "performance experimental"),
    ("preferStringWriter", "performance experimental"),
    ("preferWriteByte", "performance experimental opinionated"),
    ("ptrToRefParam", "style opinionated experimental"),
    ("rangeAppendAll", "diagnostic experimental"),
    ("rangeExprCopy", "performance"),
    ("rangeValCopy", "performance"),
    ("redundantSprint", "style experimental"),
    ("regexpMust", "style"),
    ("regexpPattern", "diagnostic experimental"),
    ("regexpSimplify", "style experimental opinionated"),
    ("returnAfterHttpError", "diagnostic experimental"),
    ("ruleguard", "style experimental"),
    ("singleCaseSwitch", "style"),
    ("sliceClear", "performance experimental"),
    ("sloppyLen", "diagnostic"),
    ("sloppyReassign", "diagnostic experimental"),
    ("sloppyTypeAssert", "diagnostic"),
    ("sortSlice", "diagnostic experimental"),
    ("sprintfQuotedString", "diagnostic experimental"),
    ("sqlQuery", "diagnostic experimental"),
    ("stringConcatSimplify", "style experimental"),
    ("stringXbytes", "performance"),
    ("stringsCompare", "style experimental"),
    ("switchTrue", "style"),
    ("syncMapLoadAndDelete", "diagnostic experimental"),
    ("timeExprSimplify", "style experimental"),
    ("todoCommentWithoutDetail", "style opinionated experimental"),
    ("tooManyResultsChecker", "style opinionated experimental"),
    ("truncateCmp", "diagnostic experimental"),
    ("typeAssertChain", "style experimental"),
    ("typeDefFirst", "style experimental"),
    ("typeSwitchVar", "style"),
    ("typeUnparen", "style opinionated"),
    ("uncheckedInlineErr", "diagnostic experimental"),
    ("underef", "style"),
    ("unlabelStmt", "style experimental"),
    ("unlambda", "style"),
    ("unnamedResult", "style opinionated experimental"),
    ("unnecessaryBlock", "style opinionated experimental"),
    ("unnecessaryDefer", "diagnostic experimental"),
    ("unslice", "style"),
    ("valSwap", "style"),
    ("weakCond", "diagnostic experimental"),
    ("whyNoLint", "style experimental"),
    ("wrapperFunc", "style"),
    ("yodaStyleExpr", "style experimental"),
    ("zeroByteRepeat", "performance"),
];

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        eprintln!("no args provided");
        print_help();
        return;
    }

    match args[0].as_str() {
        "help" => print_help(),
        "version" => println!("go-critic version: {}", VERSION),
        "doc" => doc_cmd(&args[1..]),
        "check" => check_cmd(&args[1..]),
        other => {
            eprintln!("no such command {:?}", other);
            eprintln!("{:?} unknown command", other);
            eprintln!("Run \"go-critic help\" for usage.");
            process::exit(1);
        }
    }
}

fn print_help() {
    println!(
        "Usage:\n\n    go-critic <command> [arguments...]\n\nThe commands are:\n\n    check             run linter over specified targets\n    doc               get installed checkers documentation\n    help              shows help message\n    version           shows version of the application\n\nVersion: {}\n",
        VERSION
    );
}

fn doc_cmd(args: &[String]) {
    if args.first().map(|s| s == "-help" || s == "--help").unwrap_or(false) {
        println!("Usage of go-critic:");
        println!("flag: help requested");
        return;
    }
    if args.is_empty() {
        for (name, tags) in CHECKERS {
            println!("{} [{}]", name, tags);
        }
        return;
    }
    let name = &args[0];
    if let Some((_, tags)) = CHECKERS.iter().find(|(n, _)| n == name) {
        print_checker_doc(name, tags);
    } else {
        eprintln!("checker with name {:?} not found", name);
        process::exit(1);
    }
}

fn print_checker_doc(name: &str, tags: &str) {
    println!("{} checker documentation", name);
    println!("URL: https://github.com/go-critic/go-critic/checkers");
    println!("Tags: [{}]", tags);
    println!();
    match name {
        "appendAssign" => println!("Detects suspicious append result assignments.\n\nNon-compliant code:\np.positives = append(p.negatives, x)\np.negatives = append(p.negatives, y)\n\nCompliant code:\np.positives = append(p.positives, x)\np.negatives = append(p.negatives, y)"),
        "unslice" => println!("Detects slice expressions that can be simplified to sliced expression itself.\n\nNon-compliant code:\ncopy(b[:], values...)\n\nCompliant code:\ncopy(b, values...)"),
        "elseif" => println!("Detects else with nested if statement that can be replaced with else-if."),
        "assignOp" => println!("Detects assignments that can be simplified by using an assignment operator."),
        "regexpMust" => println!("Detects regexp.Compile calls that can be converted to regexp.MustCompile."),
        "singleCaseSwitch" => println!("Detects switch statements that could be better written as if statements."),
        _ => println!("Documentation for {} checker.", name),
    }
}

fn check_cmd(args: &[String]) {
    if args.iter().any(|s| s == "-help" || s == "--help") {
        print_check_help();
        println!("parse args: flag: help requested");
        return;
    }
    for s in args {
        if s.starts_with("-unknown") {
            eprintln!("flag provided but not defined: {}", s.trim_start_matches('-'));
            print_check_help();
            eprintln!("parse args: flag provided but not defined: {}", s.trim_start_matches('-'));
            process::exit(1);
        }
    }
    eprintln!("load packages: err: go command required, not found: exec: \"go\": executable file not found in $PATH: stderr: ");
    process::exit(1);
}

fn print_check_help() {
    println!("Usage of go-critic:");
    println!("  -@captLocal.paramsOnly");
    println!("\twhether to restrict checker to params only (default true)");
    println!("  -@commentedOutCode.minLength int");
    println!("\tmin length of the comment that triggers a warning (default 15)");
    println!("  -@elseif.skipBalanced");
    println!("\twhether to skip balanced if-else pairs (default true)");
    println!("  -@hugeParam.sizeThreshold int");
    println!("\tsize in bytes that makes the warning trigger (default 80)");
    println!("  -@ifElseChain.minThreshold int");
    println!("\tmin number of if-else blocks that makes the warning trigger (default 2)");
    println!("  -@nestingReduce.bodyWidth int");
    println!("\tmin number of statements inside a branch to trigger a warning (default 5)");
    println!("  -@rangeExprCopy.sizeThreshold int");
    println!("\tsize in bytes that makes the warning trigger (default 512)");
    println!("  -@rangeExprCopy.skipTestFuncs");
    println!("\twhether to check test functions (default true)");
    println!("  -@rangeValCopy.sizeThreshold int");
    println!("\tsize in bytes that makes the warning trigger (default 128)");
    println!("  -@rangeValCopy.skipTestFuncs");
    println!("\twhether to check test functions (default true)");
    println!("  -@ruleguard.debug string");
    println!("\tenable debug for the specified named rules group");
    println!("  -@ruleguard.disable string");
    println!("\tcomma-separated list of disabled groups or skip empty to enable everything");
    println!("  -@ruleguard.enable string");
    println!("\tcomma-separated list of enabled groups or skip empty to enable everything (default \"<all>\")");
    println!("  -@ruleguard.failOn string");
    println!("\tDetermines the behavior when an error occurs while parsing ruleguard files.");
    println!("\tIf flag is not set, log error and skip rule files that contain an error.");
    println!("\tIf flag is set, the value must be a comma-separated list of error conditions.");
    println!("\t* 'import': rule refers to a package that cannot be loaded.");
    println!("\t* 'dsl':    gorule file does not comply with the ruleguard DSL.");
    println!("  -@ruleguard.failOnError");
    println!("\tdeprecated, use failOn param; if set to true, identical to failOn='all', otherwise failOn=''");
    println!("  -@ruleguard.rules string");
    println!("\tcomma-separated list of gorule file paths. Glob patterns such as 'rules-*.go' may be specified");
    println!("  -@tooManyResultsChecker.maxResults int");
    println!("\tmaximum number of results (default 5)");
    println!("  -@truncateCmp.skipArchDependent");
    println!("\twhether to skip int/uint/uintptr types (default true)");
    println!("  -@underef.skipRecvDeref");
    println!("\twhether to skip (*x).method() calls where x is a pointer receiver (default true)");
    println!("  -@unnamedResult.checkExported");
    println!("\twhether to check exported functions");
    println!("  -checkGenerated");
    println!("\twhether to check generated files");
    println!("  -checkTests");
    println!("\twhether to check test files (default true)");
    println!("  -concurrency int");
    println!("\thow many concurrent checkers to run (default is runtime.GOMAXPROCS(0)) (default 14)");
    println!("  -cpuprofile string");
    println!("\twrite CPU profile to the specified file");
    println!("  -disable string");
    println!("\tcomma-separated list of checkers to be disabled. Can include #tags");
    println!("  -enable string");
    println!("\tcomma-separated list of enabled checkers. Can include #tags (default \"appendAssign,argOrder,assignOp,badCall,badCond,captLocal,caseOrder,codegenComment,commentFormatting,defaultCaseOrder,deprecatedComment,dupArg,dupBranchBody,dupCase,dupSubExpr,elseif,exitAfterDefer,flagDeref,flagName,ifElseChain,mapKey,newDeref,offBy1,regexpMust,singleCaseSwitch,sloppyLen,sloppyTypeAssert,switchTrue,typeSwitchVar,underef,unlambda,unslice,valSwap,wrapperFunc\")");
    println!("  -enableAll");
    println!("\tidentical to -enable with all checkers listed. If true, -enable is ignored");
    println!("  -exitCode int");
    println!("\texit code to be used when lint issues are found (default 1)");
    println!("  -go string");
    println!("\tselect the Go version to target. Leave as string for the latest");
    println!("  -memprofile string");
    println!("\twrite memory profile to the specified file");
    println!("  -shorterErrLocation");
    println!("\twhether to replace error location prefix with $GOROOT and $GOPATH (default true)");
    println!("  -v\twhether to print output useful during linter debugging");
}
