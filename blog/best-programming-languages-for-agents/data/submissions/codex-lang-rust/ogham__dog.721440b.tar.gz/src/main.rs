use std::env;
use std::fs;
use std::io::{Read, Write};
use std::net::{Ipv4Addr, Ipv6Addr, SocketAddr, TcpStream, ToSocketAddrs, UdpSocket};
use std::time::{Duration, Instant};

const HELP: &str = "dog ● command-line DNS client

Usage:
  dog [OPTIONS] [--] <arguments>

Examples:
  dog example.net                          Query a domain using default settings
  dog example.net MX                       ...looking up MX records instead
  dog example.net MX @1.1.1.1              ...using a specific nameserver instead
  dog example.net MX @1.1.1.1 -T           ...using TCP rather than UDP
  dog -q example.net -t MX -n 1.1.1.1 -T   As above, but using explicit arguments

Query options:
  <arguments>              Human-readable host names, nameservers, types, or classes
  -q, --query=HOST         Host name or domain name to query
  -t, --type=TYPE          Type of the DNS record being queried (A, MX, NS...)
  -n, --nameserver=ADDR    Address of the nameserver to send packets to
  --class=CLASS            Network class of the DNS record being queried (IN, CH, HS)

Sending options:
  --edns=SETTING           Whether to OPT in to EDNS (disable, hide, show)
  --txid=NUMBER            Set the transaction ID to a specific value
  -Z=TWEAKS                Set uncommon protocol-level tweaks

Protocol options:
  -U, --udp                Use the DNS protocol over UDP
  -T, --tcp                Use the DNS protocol over TCP
  -S, --tls                Use the DNS-over-TLS protocol
  -H, --https              Use the DNS-over-HTTPS protocol

Output options:
  -1, --short              Short mode: display nothing but the first result
  -J, --json               Display the output as JSON
  --color, --colour=WHEN   When to colourise the output (always, automatic, never)
  --seconds                Do not format durations, display them as seconds
  --time                   Print how long the response took to arrive

Meta options:
  -?, --help               Print list of command-line options
  -v, --version            Print version information";

const VERSION: &str = "dog ● command-line DNS client
v0.2.0-pre [d3a34280] built on 2026-04-17 (pre-release!)
https://dns.lookup.dog/";

#[derive(Clone, Copy, PartialEq)]
enum Transport {
    Udp,
    Tcp,
    Tls,
    Https,
}

#[derive(Clone)]
struct Config {
    queries: Vec<String>,
    types: Vec<u16>,
    classes: Vec<u16>,
    nameservers: Vec<String>,
    txid: u16,
    short: bool,
    json: bool,
    seconds: bool,
    time: bool,
    transport: Transport,
}

#[derive(Clone)]
struct Record {
    name: String,
    class: u16,
    ttl: u32,
    typ: u16,
    data: RData,
}

#[derive(Clone)]
enum RData {
    A(Ipv4Addr),
    Aaaa(Ipv6Addr),
    Name(String),
    Mx(u16, String),
    Txt(String),
    Soa(String, String, u32, u32, u32, u32, u32),
    Srv(u16, u16, u16, String),
    Caa(u8, String, String),
    Raw(Vec<u8>),
}

struct Response {
    query_name: String,
    query_type: u16,
    query_class: u16,
    answers: Vec<Record>,
    authorities: Vec<Record>,
    additionals: Vec<Record>,
}

fn main() {
    let start = Instant::now();
    match run(start) {
        Ok(code) => std::process::exit(code),
        Err((code, msg)) => {
            if !msg.is_empty() {
                eprintln!("{msg}");
            }
            std::process::exit(code);
        }
    }
}

fn run(start: Instant) -> Result<i32, (i32, String)> {
    let cfg = parse_args()?;
    if cfg.transport == Transport::Tls {
        return net_error("TLS support is unavailable in this build", cfg.json);
    }
    if cfg.transport == Transport::Https {
        return net_error("HTTPS support is unavailable in this build", cfg.json);
    }

    let mut responses = Vec::new();
    let mut had_error = false;
    for q in &cfg.queries {
        for &typ in &cfg.types {
            for &class in &cfg.classes {
                for ns in &cfg.nameservers {
                    match query_once(&cfg, q, typ, class, ns) {
                        Ok(resp) => responses.push(resp),
                        Err(e) => {
                            had_error = true;
                            if cfg.json {
                                println!(
                                    "{{\"error\":true,\"error_phase\":\"network\",\"error_message\":\"{}\"}}",
                                    json_escape(&e)
                                );
                            } else {
                                eprintln!("Error [network]: {e}");
                            }
                        }
                    }
                }
            }
        }
    }

    if cfg.json {
        print_json(&responses);
    } else if cfg.short {
        if let Some(s) = responses.iter().flat_map(|r| r.answers.iter()).next().map(short_data) {
            println!("{s}");
        } else {
            println!("No results");
            return Ok(2);
        }
    } else {
        print_table(&responses, cfg.seconds);
        if cfg.time {
            println!("Ran in {}", format_elapsed(start.elapsed(), false));
        }
    }

    Ok(if had_error { 1 } else { 0 })
}

fn parse_args() -> Result<Config, (i32, String)> {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        println!("{HELP}");
        return Err((3, String::new()));
    }
    let mut cfg = Config {
        queries: Vec::new(),
        types: Vec::new(),
        classes: Vec::new(),
        nameservers: Vec::new(),
        txid: 0x1234,
        short: false,
        json: false,
        seconds: false,
        time: false,
        transport: Transport::Udp,
    };
    let mut positionals = false;
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if !positionals && a == "--" {
            positionals = true;
            i += 1;
            continue;
        }
        if !positionals && (a == "-?" || a == "--help") {
            println!("{HELP}");
            std::process::exit(0);
        } else if !positionals && (a == "-v" || a == "--version") {
            println!("{VERSION}");
            std::process::exit(0);
        } else if !positionals && (a == "-1" || a == "--short") {
            cfg.short = true;
        } else if !positionals && (a == "-J" || a == "--json") {
            cfg.json = true;
        } else if !positionals && a == "--seconds" {
            cfg.seconds = true;
        } else if !positionals && a == "--time" {
            cfg.time = true;
        } else if !positionals && (a == "-U" || a == "--udp") {
            cfg.transport = Transport::Udp;
        } else if !positionals && (a == "-T" || a == "--tcp") {
            cfg.transport = Transport::Tcp;
        } else if !positionals && (a == "-S" || a == "--tls") {
            cfg.transport = Transport::Tls;
        } else if !positionals && (a == "-H" || a == "--https") {
            cfg.transport = Transport::Https;
        } else if !positionals && (a == "-q" || a == "--query") {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'query'"))?.clone();
            cfg.queries.push(v);
        } else if !positionals && a.starts_with("--query=") {
            cfg.queries.push(a[8..].to_string());
        } else if !positionals && (a == "-t" || a == "--type") {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'type'"))?;
            cfg.types.push(parse_type(v)?);
        } else if !positionals && a.starts_with("--type=") {
            cfg.types.push(parse_type(&a[7..])?);
        } else if !positionals && (a == "-n" || a == "--nameserver") {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'nameserver'"))?.clone();
            cfg.nameservers.push(v);
        } else if !positionals && a.starts_with("--nameserver=") {
            cfg.nameservers.push(a[13..].to_string());
        } else if !positionals && a == "--class" {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'class'"))?;
            cfg.classes.push(parse_class(v)?);
        } else if !positionals && a.starts_with("--class=") {
            cfg.classes.push(parse_class(&a[8..])?);
        } else if !positionals && a == "--edns" {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'edns'"))?;
            parse_edns(v)?;
        } else if !positionals && a.starts_with("--edns=") {
            parse_edns(&a[7..])?;
        } else if !positionals && a == "--txid" {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'txid'"))?;
            cfg.txid = parse_txid(v)?;
        } else if !positionals && a.starts_with("--txid=") {
            cfg.txid = parse_txid(&a[7..])?;
        } else if !positionals && a == "-Z" {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'Z'"))?;
            parse_tweak(v)?;
        } else if !positionals && a.starts_with("-Z=") {
            parse_tweak(&a[3..])?;
        } else if !positionals && (a == "--color" || a == "--colour") {
            i += 1;
            let v = args.get(i).ok_or_else(|| invalid("Missing value for option 'color'"))?;
            parse_color(v)?;
        } else if !positionals && a.starts_with("--color=") {
            parse_color(&a[8..])?;
        } else if !positionals && a.starts_with("--colour=") {
            parse_color(&a[9..])?;
        } else if !positionals && a.starts_with('-') {
            return Err(invalid(&format!("Unrecognized option: '{}'", a.trim_start_matches('-'))));
        } else {
            classify_positional(&mut cfg, &a)?;
        }
        i += 1;
    }
    if cfg.queries.is_empty() {
        println!("{HELP}");
        return Err((3, String::new()));
    }
    if cfg.types.is_empty() {
        cfg.types.push(1);
    }
    if cfg.classes.is_empty() {
        cfg.classes.push(1);
    }
    if cfg.nameservers.is_empty() {
        cfg.nameservers = system_nameservers().map_err(|e| (4, e))?;
    }
    Ok(cfg)
}

fn invalid(msg: &str) -> (i32, String) {
    (3, format!("dog: Invalid options: {msg}"))
}

fn parse_edns(v: &str) -> Result<(), (i32, String)> {
    match v {
        "disable" | "hide" | "show" => Ok(()),
        _ => Err(invalid(&format!("Invalid EDNS setting \"{v}\""))),
    }
}

fn parse_color(v: &str) -> Result<(), (i32, String)> {
    match v {
        "always" | "automatic" | "never" => Ok(()),
        _ => Err(invalid(&format!("Invalid colour setting \"{v}\""))),
    }
}

fn parse_tweak(v: &str) -> Result<(), (i32, String)> {
    if matches!(v, "aa" | "ad" | "cd") || v.starts_with("bufsize=") {
        Ok(())
    } else {
        Err(invalid(&format!("Invalid protocol tweak \"{v}\"")))
    }
}

fn parse_txid(v: &str) -> Result<u16, (i32, String)> {
    v.parse::<u16>().map_err(|_| invalid(&format!("Invalid transaction ID \"{v}\"")))
}

fn classify_positional(cfg: &mut Config, a: &str) -> Result<(), (i32, String)> {
    if let Some(ns) = a.strip_prefix('@') {
        cfg.nameservers.push(ns.to_string());
    } else if let Ok(t) = parse_type(a) {
        cfg.types.push(t);
    } else if let Ok(c) = parse_class(a) {
        cfg.classes.push(c);
    } else {
        cfg.queries.push(a.to_string());
    }
    Ok(())
}

fn parse_type(s: &str) -> Result<u16, (i32, String)> {
    let u = s.to_ascii_uppercase();
    let n = match u.as_str() {
        "A" => 1, "NS" => 2, "CNAME" => 5, "SOA" => 6, "PTR" => 12, "HINFO" => 13,
        "MX" => 15, "TXT" => 16, "AAAA" => 28, "SRV" => 33, "NAPTR" => 35, "CAA" => 257,
        "ANY" => 255, "OPT" => 41, "SSHFP" => 44, "TLSA" => 52, "LOC" => 29,
        "IXFR" => 251, "AXFR" => 252, "AFSDB" => 18,
        _ => return s.parse::<u16>().map_err(|_| invalid(&format!("Invalid query type \"{s}\""))),
    };
    Ok(n)
}

fn parse_class(s: &str) -> Result<u16, (i32, String)> {
    let n = match s.to_ascii_uppercase().as_str() {
        "IN" => 1, "CH" => 3, "HS" => 4, "ANY" => 255,
        _ => return s.parse::<u16>().map_err(|_| invalid(&format!("Invalid query class \"{s}\""))),
    };
    Ok(n)
}

fn system_nameservers() -> Result<Vec<String>, String> {
    let text = fs::read_to_string("/etc/resolv.conf").map_err(|e| format!("Error obtaining system nameserver information: {e}"))?;
    let mut out = Vec::new();
    for line in text.lines() {
        let mut parts = line.split_whitespace();
        if parts.next() == Some("nameserver") {
            if let Some(addr) = parts.next() {
                out.push(addr.to_string());
            }
        }
    }
    if out.is_empty() {
        Err("Error obtaining system nameserver information: no nameservers found".to_string())
    } else {
        Ok(out)
    }
}

fn query_once(cfg: &Config, name: &str, typ: u16, class: u16, ns: &str) -> Result<Response, String> {
    let packet = build_query(cfg.txid, name, typ, class);
    let bytes = match cfg.transport {
        Transport::Udp => send_udp(ns, &packet)?,
        Transport::Tcp => send_tcp(ns, &packet)?,
        _ => unreachable!(),
    };
    parse_response(&bytes, name, typ, class)
}

fn socket_addr(ns: &str) -> Result<SocketAddr, String> {
    let addr = if ns.starts_with('[') || ns.rsplit_once(':').map_or(false, |(_, p)| p.parse::<u16>().is_ok()) {
        ns.to_string()
    } else {
        format!("{ns}:53")
    };
    addr.to_socket_addrs().map_err(|e| e.to_string())?.next().ok_or_else(|| "could not resolve nameserver".to_string())
}

fn send_udp(ns: &str, packet: &[u8]) -> Result<Vec<u8>, String> {
    let addr = socket_addr(ns)?;
    let bind = if addr.is_ipv4() { "0.0.0.0:0" } else { "[::]:0" };
    let sock = UdpSocket::bind(bind).map_err(|e| e.to_string())?;
    sock.set_read_timeout(Some(Duration::from_secs(5))).ok();
    sock.send_to(packet, addr).map_err(|e| e.to_string())?;
    let mut buf = vec![0u8; 4096];
    let (len, _) = sock.recv_from(&mut buf).map_err(|e| e.to_string())?;
    buf.truncate(len);
    Ok(buf)
}

fn send_tcp(ns: &str, packet: &[u8]) -> Result<Vec<u8>, String> {
    let addr = socket_addr(ns)?;
    let mut s = TcpStream::connect_timeout(&addr, Duration::from_secs(5)).map_err(|e| e.to_string())?;
    s.set_read_timeout(Some(Duration::from_secs(5))).ok();
    let mut framed = Vec::with_capacity(packet.len() + 2);
    framed.extend_from_slice(&(packet.len() as u16).to_be_bytes());
    framed.extend_from_slice(packet);
    s.write_all(&framed).map_err(|e| e.to_string())?;
    let mut lenb = [0u8; 2];
    s.read_exact(&mut lenb).map_err(|e| e.to_string())?;
    let len = u16::from_be_bytes(lenb) as usize;
    let mut out = vec![0u8; len];
    s.read_exact(&mut out).map_err(|e| e.to_string())?;
    Ok(out)
}

fn build_query(txid: u16, name: &str, typ: u16, class: u16) -> Vec<u8> {
    let mut p = Vec::new();
    p.extend_from_slice(&txid.to_be_bytes());
    p.extend_from_slice(&0x0100u16.to_be_bytes());
    p.extend_from_slice(&1u16.to_be_bytes());
    p.extend_from_slice(&0u16.to_be_bytes());
    p.extend_from_slice(&0u16.to_be_bytes());
    p.extend_from_slice(&0u16.to_be_bytes());
    encode_name(name, &mut p);
    p.extend_from_slice(&typ.to_be_bytes());
    p.extend_from_slice(&class.to_be_bytes());
    p
}

fn encode_name(name: &str, out: &mut Vec<u8>) {
    for part in name.trim_end_matches('.').split('.') {
        out.push(part.len() as u8);
        out.extend_from_slice(part.as_bytes());
    }
    out.push(0);
}

fn parse_response(data: &[u8], qname: &str, qtype: u16, qclass: u16) -> Result<Response, String> {
    if data.len() < 12 { return Err("short DNS response".to_string()); }
    let qd = u16_at(data, 4)? as usize;
    let an = u16_at(data, 6)? as usize;
    let ns = u16_at(data, 8)? as usize;
    let ar = u16_at(data, 10)? as usize;
    let mut off = 12;
    let mut query_name = fqdn(qname);
    let mut query_type = qtype;
    let mut query_class = qclass;
    for idx in 0..qd {
        let n = read_name(data, &mut off)?;
        let t = u16_at(data, off)?; off += 2;
        let c = u16_at(data, off)?; off += 2;
        if idx == 0 { query_name = n; query_type = t; query_class = c; }
    }
    let mut answers = Vec::new();
    let mut authorities = Vec::new();
    let mut additionals = Vec::new();
    for _ in 0..an { answers.push(read_record(data, &mut off, "answers")?); }
    for _ in 0..ns { authorities.push(read_record(data, &mut off, "authorities")?); }
    for _ in 0..ar { additionals.push(read_record(data, &mut off, "additionals")?); }
    Ok(Response { query_name, query_type, query_class, answers, authorities, additionals })
}

fn read_record(data: &[u8], off: &mut usize, _section: &'static str) -> Result<Record, String> {
    let name = read_name(data, off)?;
    let typ = u16_at(data, *off)?; *off += 2;
    let class = u16_at(data, *off)?; *off += 2;
    let ttl = u32_at(data, *off)?; *off += 4;
    let len = u16_at(data, *off)? as usize; *off += 2;
    let start = *off;
    let end = start.checked_add(len).ok_or_else(|| "bad record length".to_string())?;
    if end > data.len() { return Err("record extends past response".to_string()); }
    let data_value = match typ {
        1 if len == 4 => RData::A(Ipv4Addr::new(data[start], data[start+1], data[start+2], data[start+3])),
        28 if len == 16 => {
            let mut b = [0u8; 16]; b.copy_from_slice(&data[start..end]); RData::Aaaa(Ipv6Addr::from(b))
        }
        2 | 5 | 12 => {
            let mut p = start; RData::Name(read_name(data, &mut p)?)
        }
        15 if len >= 3 => {
            let pref = u16_at(data, start)?; let mut p = start + 2; RData::Mx(pref, read_name(data, &mut p)?)
        }
        16 => {
            let mut p = start; let mut parts = Vec::new();
            while p < end {
                let l = data[p] as usize; p += 1;
                if p + l > end { break; }
                parts.push(String::from_utf8_lossy(&data[p..p+l]).to_string());
                p += l;
            }
            RData::Txt(parts.join(" "))
        }
        6 => {
            let mut p = start;
            let m = read_name(data, &mut p)?;
            let r = read_name(data, &mut p)?;
            if p + 20 <= end {
                RData::Soa(m, r, u32_at(data,p)?, u32_at(data,p+4)?, u32_at(data,p+8)?, u32_at(data,p+12)?, u32_at(data,p+16)?)
            } else { RData::Raw(data[start..end].to_vec()) }
        }
        33 if len >= 7 => {
            let pri = u16_at(data, start)?; let w = u16_at(data, start+2)?; let port = u16_at(data, start+4)?;
            let mut p = start + 6; RData::Srv(pri, w, port, read_name(data, &mut p)?)
        }
        257 if len >= 2 => {
            let flags = data[start]; let tag_len = data[start+1] as usize;
            if start + 2 + tag_len <= end {
                let tag = String::from_utf8_lossy(&data[start+2..start+2+tag_len]).to_string();
                let val = String::from_utf8_lossy(&data[start+2+tag_len..end]).to_string();
                RData::Caa(flags, tag, val)
            } else { RData::Raw(data[start..end].to_vec()) }
        }
        _ => RData::Raw(data[start..end].to_vec()),
    };
    *off = end;
    Ok(Record { name, class, ttl, typ, data: data_value })
}

fn read_name(data: &[u8], off: &mut usize) -> Result<String, String> {
    let mut pos = *off;
    let mut jumped = false;
    let mut seen = 0;
    let mut labels = Vec::new();
    loop {
        if pos >= data.len() { return Err("name extends past response".to_string()); }
        seen += 1;
        if seen > 128 { return Err("compressed name loop".to_string()); }
        let len = data[pos];
        if len & 0xc0 == 0xc0 {
            if pos + 1 >= data.len() { return Err("bad compressed name".to_string()); }
            let ptr = (((len & 0x3f) as usize) << 8) | data[pos + 1] as usize;
            if !jumped { *off = pos + 2; }
            jumped = true;
            pos = ptr;
        } else if len == 0 {
            if !jumped { *off = pos + 1; }
            break;
        } else {
            pos += 1;
            let end = pos + len as usize;
            if end > data.len() { return Err("bad name label".to_string()); }
            labels.push(String::from_utf8_lossy(&data[pos..end]).to_string());
            pos = end;
        }
    }
    Ok(if labels.is_empty() { ".".to_string() } else { format!("{}.", labels.join(".")) })
}

fn u16_at(d: &[u8], p: usize) -> Result<u16, String> {
    if p + 2 > d.len() { Err("short DNS response".to_string()) } else { Ok(u16::from_be_bytes([d[p], d[p+1]])) }
}
fn u32_at(d: &[u8], p: usize) -> Result<u32, String> {
    if p + 4 > d.len() { Err("short DNS response".to_string()) } else { Ok(u32::from_be_bytes([d[p], d[p+1], d[p+2], d[p+3]])) }
}

fn print_table(responses: &[Response], seconds: bool) {
    let records: Vec<&Record> = responses.iter().flat_map(|r| r.answers.iter().chain(r.authorities.iter()).chain(r.additionals.iter())).collect();
    let max_type = records.iter().map(|r| type_name(r.typ).len()).max().unwrap_or(0);
    for r in records {
        println!(
            "{:>width$} {} {}   {}",
            type_name(r.typ),
            r.name,
            format_ttl(r.ttl, seconds),
            display_data(r),
            width = max_type
        );
    }
}

fn print_json(responses: &[Response]) {
    print!("{{\"responses\":[");
    for (i, r) in responses.iter().enumerate() {
        if i > 0 { print!(","); }
        print!("{{\"queries\":[{{\"name\":\"{}\",\"class\":\"{}\",\"type\":\"{}\"}}],", json_escape(&r.query_name), class_name(r.query_class), type_name(r.query_type));
        print!("\"answers\":"); print_records_json(&r.answers);
        print!(",\"authorities\":"); print_records_json(&r.authorities);
        print!(",\"additionals\":"); print_records_json(&r.additionals);
        print!("}}");
    }
    println!("]}}");
}

fn print_records_json(records: &[Record]) {
    print!("[");
    for (i, r) in records.iter().enumerate() {
        if i > 0 { print!(","); }
        print!("{{\"name\":\"{}\",\"class\":\"{}\",\"ttl\":{},\"type\":\"{}\",\"data\":", json_escape(&r.name), class_name(r.class), r.ttl, type_name(r.typ));
        print_data_json(r);
        print!("}}");
    }
    print!("]");
}

fn print_data_json(r: &Record) {
    match &r.data {
        RData::A(a) => print!("{{\"address\":\"{}\"}}", a),
        RData::Aaaa(a) => print!("{{\"address\":\"{}\"}}", a),
        RData::Name(n) => print!("{{\"domain\":\"{}\"}}", json_escape(n)),
        RData::Mx(p, n) => print!("{{\"preference\":{},\"exchange\":\"{}\"}}", p, json_escape(n)),
        RData::Txt(t) => print!("{{\"strings\":[\"{}\"]}}", json_escape(t)),
        RData::Srv(p, w, port, t) => print!("{{\"priority\":{},\"weight\":{},\"port\":{},\"target\":\"{}\"}}", p, w, port, json_escape(t)),
        RData::Soa(m, r, s, rf, rt, ex, mn) => print!("{{\"mname\":\"{}\",\"rname\":\"{}\",\"serial\":{},\"refresh\":{},\"retry\":{},\"expire\":{},\"minimum\":{}}}", json_escape(m), json_escape(r), s, rf, rt, ex, mn),
        RData::Caa(f, tag, val) => print!("{{\"flags\":{},\"tag\":\"{}\",\"value\":\"{}\"}}", f, json_escape(tag), json_escape(val)),
        RData::Raw(v) => {
            print!("[");
            for (i, b) in v.iter().enumerate() { if i > 0 { print!(","); } print!("{b}"); }
            print!("]");
        }
    }
}

fn display_data(r: &Record) -> String {
    match &r.data {
        RData::A(a) => a.to_string(),
        RData::Aaaa(a) => a.to_string(),
        RData::Name(n) => n.clone(),
        RData::Mx(p, n) => format!("{p} \"{n}\""),
        RData::Txt(t) => format!("\"{t}\""),
        RData::Srv(p, w, port, t) => format!("{p} {w} {port} \"{t}\""),
        RData::Soa(m, r, s, rf, rt, ex, mn) => format!("\"{m}\" \"{r}\" {s} {rf} {rt} {ex} {mn}"),
        RData::Caa(f, tag, val) => format!("{f} {tag} \"{val}\""),
        RData::Raw(v) => v.iter().map(|b| b.to_string()).collect::<Vec<_>>().join(" "),
    }
}

fn short_data(r: &Record) -> String {
    match &r.data {
        RData::Mx(p, n) => format!("{p} {n}"),
        RData::Txt(t) => t.clone(),
        _ => display_data(r).replace('"', ""),
    }
}

fn format_ttl(ttl: u32, seconds: bool) -> String {
    if seconds { return ttl.to_string(); }
    let h = ttl / 3600;
    let m = (ttl % 3600) / 60;
    let s = ttl % 60;
    if h > 0 { format!("{h}h{m:02}m{s:02}s") } else if m > 0 { format!("{m}m{s:02}s") } else { format!("{s}s") }
}

fn format_elapsed(d: Duration, seconds: bool) -> String {
    if seconds { format!("{:.3}", d.as_secs_f64()) } else { format!("{}ms", d.as_millis().max(1)) }
}

fn type_name(t: u16) -> String {
    match t {
        1=>"A",2=>"NS",5=>"CNAME",6=>"SOA",12=>"PTR",13=>"HINFO",15=>"MX",16=>"TXT",28=>"AAAA",29=>"LOC",33=>"SRV",35=>"NAPTR",41=>"OPT",44=>"SSHFP",52=>"TLSA",257=>"CAA",255=>"ANY",251=>"IXFR",252=>"AXFR",18=>"AFSDB",
        _ => return format!("TYPE{t}"),
    }.to_string()
}

fn class_name(c: u16) -> String {
    match c { 1=>"IN",3=>"CH",4=>"HS",255=>"ANY", _ => return format!("CLASS{c}") }.to_string()
}

fn fqdn(s: &str) -> String {
    if s.ends_with('.') { s.to_string() } else { format!("{s}.") }
}

fn json_escape(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c < ' ' => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

fn net_error(msg: &str, json: bool) -> Result<i32, (i32, String)> {
    if json {
        println!("{{\"error\":true,\"error_phase\":\"network\",\"error_message\":\"{}\"}}", json_escape(msg));
        println!("{{\"responses\":[]}}");
        Ok(1)
    } else {
        Err((1, format!("Error [network]: {msg}")))
    }
}
