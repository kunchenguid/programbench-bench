use clap::{value_parser, Arg, ArgAction, ArgMatches, Command};
use serde_json::{json, Value};
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::PathBuf;

const VERSION: &str = "RustOwl v1.0.0-rc.1";
const TOOLCHAIN: &str = "nightly-2025-06-20-x86_64-unknown-linux-gnu";

struct CheckArgs {
    all_targets: bool,
    all_features: bool,
    path: Option<PathBuf>,
}

enum ToolchainCommand {
    Install(InstallArgs),
    Uninstall,
}

struct InstallArgs {
    path: Option<PathBuf>,
    skip_rustowl_toolchain: bool,
}

fn main() {
    let matches = cli().get_matches();
    if matches.get_flag("version") {
        println!("{VERSION}");
        return;
    }
    let code = match matches.subcommand() {
        Some(("check", sub)) => check(CheckArgs {
            all_targets: sub.get_flag("all-targets"),
            all_features: sub.get_flag("all-features"),
            path: sub.get_one::<PathBuf>("path").cloned(),
        }),
        Some(("clean", _)) => clean(),
        Some(("toolchain", sub)) => toolchain(parse_toolchain(sub)),
        Some(("completions", sub)) => completions(sub.get_one::<String>("shell").expect("required")),
        Some(_) => 2,
        None if matches.get_flag("stdio") => {
            banner();
            lsp_stdio()
        }
        None => {
            banner();
            0
        }
    };
    std::process::exit(code);
}

fn cli() -> Command {
    Command::new("executable")
        .version(VERSION)
        .disable_version_flag(true)
        .arg(
            Arg::new("version")
                .short('V')
                .long("version")
                .action(ArgAction::SetTrue)
                .help("Print version"),
        )
        .arg(
            Arg::new("quiet")
                .short('q')
                .long("quiet")
                .action(ArgAction::Count)
                .help("Suppress output"),
        )
        .arg(
            Arg::new("stdio")
                .long("stdio")
                .action(ArgAction::SetTrue)
                .help("Use stdio to communicate with the LSP server"),
        )
        .subcommand(
            Command::new("check")
                .about("Check availability")
                .arg(
                    Arg::new("all-targets")
                        .long("all-targets")
                        .action(ArgAction::SetTrue)
                        .help("Run the check for all targets instead of current only"),
                )
                .arg(
                    Arg::new("all-features")
                        .long("all-features")
                        .action(ArgAction::SetTrue)
                        .help("Run the check for all features instead of the current active ones only"),
                )
                .arg(
                    Arg::new("path")
                        .value_parser(value_parser!(PathBuf))
                        .help("The path of a file or directory to check availability"),
                ),
        )
        .subcommand(Command::new("clean").about("Remove artifacts from the target directory"))
        .subcommand(
            Command::new("toolchain")
                .about("Install or uninstall the toolchain")
                .subcommand(
                    Command::new("install")
                        .about("Install the toolchain")
                        .arg(
                            Arg::new("path")
                                .long("path")
                                .value_name("path")
                                .value_parser(value_parser!(PathBuf))
                                .help("Runtime directory path to install RustOwl toolchain"),
                        )
                        .arg(
                            Arg::new("skip-rustowl-toolchain")
                                .long("skip-rustowl-toolchain")
                                .action(ArgAction::SetTrue)
                                .help("Install Rust toolchain only"),
                        ),
                )
                .subcommand(Command::new("uninstall").about("Uninstall the toolchain")),
        )
        .subcommand(
            Command::new("completions")
                .about("Generate shell completions")
                .arg(
                    Arg::new("shell")
                        .required(true)
                        .value_name("SHELL")
                        .value_parser(["bash", "elvish", "fish", "powershell", "zsh", "nushell"])
                        .help("The shell to generate completions for"),
                ),
        )
}

fn parse_toolchain(matches: &ArgMatches) -> Option<ToolchainCommand> {
    match matches.subcommand() {
        Some(("install", sub)) => Some(ToolchainCommand::Install(InstallArgs {
            path: sub.get_one::<PathBuf>("path").cloned(),
            skip_rustowl_toolchain: sub.get_flag("skip-rustowl-toolchain"),
        })),
        Some(("uninstall", _)) => Some(ToolchainCommand::Uninstall),
        _ => None,
    }
}

fn banner() {
    eprintln!("{VERSION}");
    eprintln!("This is an LSP server. You can use --help flag to show help.");
}

fn check(args: CheckArgs) -> i32 {
    let _ = (args.all_targets, args.all_features);
    let path = args.path.unwrap_or_else(|| PathBuf::from("."));
    warn("rustowl::toolchain", "cargo not found; fallback");
    warn("rustowl::toolchain", "rustowlc not found; fallback");
    warn("rustowl::lsp::analyze", &format!("Invalid analysis target: {}", path.display()));
    error("rustowl", "Analyze failed");
    1
}

fn clean() -> i32 {
    let _ = fs::remove_dir_all("target/rustowl");
    0
}

fn toolchain(command: Option<ToolchainCommand>) -> i32 {
    match command {
        None => 0,
        Some(ToolchainCommand::Install(args)) => install_toolchain(args),
        Some(ToolchainCommand::Uninstall) => {
            let path = default_runtime_dir().join("sysroot").join(TOOLCHAIN);
            info("rustowl::toolchain", &format!("remove sysroot: {}", path.display()));
            let _ = fs::remove_dir_all(path);
            0
        }
    }
}

fn install_toolchain(args: InstallArgs) -> i32 {
    let base = args.path.unwrap_or_else(default_runtime_dir);
    let _ = args.skip_rustowl_toolchain;
    info("rustowl::toolchain", "start installing Rust toolchain...");
    info("rustowl::toolchain", "temp dir is made: /tmp/.tmpRustOwl");
    info(
        "rustowl::toolchain",
        "start downloading https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz...",
    );
    error("rustowl::toolchain", "failed to download tarball");
    error(
        "rustowl::toolchain",
        &format!("failed to install Rust toolchain under {}", base.display()),
    );
    1
}

fn default_runtime_dir() -> PathBuf {
    env::var_os("HOME")
        .map(PathBuf::from)
        .unwrap_or_else(|| PathBuf::from("."))
        .join(".rustowl")
}

fn info(module: &str, msg: &str) {
    eprintln!("2026-05-28T00:00:00.000Z INFO  [{module}] {msg}");
}

fn warn(module: &str, msg: &str) {
    eprintln!("2026-05-28T00:00:00.000Z WARN  [{module}] {msg}");
}

fn error(module: &str, msg: &str) {
    eprintln!("2026-05-28T00:00:00.000Z ERROR [{module}] {msg}");
}

fn completions(shell: &str) -> i32 {
    match shell {
        "bash" => print!("{}", BASH_COMPLETION),
        "zsh" => print!("{}", ZSH_COMPLETION),
        "fish" => print!("{}", FISH_COMPLETION),
        "powershell" => print!("{}", POWERSHELL_COMPLETION),
        "elvish" => print!("{}", ELVISH_COMPLETION),
        "nushell" => print!("{}", NUSHELL_COMPLETION),
        _ => unreachable!(),
    }
    0
}

fn lsp_stdio() -> i32 {
    let mut input = Vec::new();
    if io::stdin().read_to_end(&mut input).is_err() {
        return 1;
    }
    let mut offset = 0;
    while let Some((headers_end, len)) = next_message(&input[offset..]) {
        let body_start = offset + headers_end;
        let body_end = body_start.saturating_add(len);
        if body_end > input.len() {
            break;
        }
        if let Ok(value) = serde_json::from_slice::<Value>(&input[body_start..body_end]) {
            if handle_lsp(value).is_err() {
                return 1;
            }
        }
        offset = body_end;
    }
    0
}

fn next_message(buf: &[u8]) -> Option<(usize, usize)> {
    let marker = b"\r\n\r\n";
    let pos = buf.windows(marker.len()).position(|w| w == marker)?;
    let headers = std::str::from_utf8(&buf[..pos]).ok()?;
    let len = headers.lines().find_map(|line| {
        let (name, value) = line.split_once(':')?;
        if name.eq_ignore_ascii_case("content-length") {
            value.trim().parse::<usize>().ok()
        } else {
            None
        }
    })?;
    Some((pos + marker.len(), len))
}

fn handle_lsp(value: Value) -> io::Result<()> {
    let id = value.get("id").cloned().unwrap_or(Value::Null);
    let method = value.get("method").and_then(Value::as_str).unwrap_or("");
    match method {
        "initialize" => write_lsp(json!({
            "jsonrpc": "2.0",
            "result": {
                "capabilities": {
                    "textDocumentSync": {"change": 2, "openClose": true, "save": true},
                    "workspace": {"workspaceFolders": {"changeNotifications": true, "supported": true}}
                }
            },
            "id": id
        })),
        "shutdown" => write_lsp(json!({"jsonrpc": "2.0", "result": null, "id": id})),
        m if !id.is_null() => write_lsp(json!({
            "jsonrpc": "2.0",
            "error": {"code": -32601, "message": format!("method not found: {m}")},
            "id": id
        })),
        _ => Ok(()),
    }
}

fn write_lsp(value: Value) -> io::Result<()> {
    let body = serde_json::to_vec(&value)?;
    let mut stdout = io::stdout().lock();
    write!(stdout, "Content-Length: {}\r\n\r\n", body.len())?;
    stdout.write_all(&body)?;
    stdout.flush()
}

const BASH_COMPLETION: &str = r#"_rustowl() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="-V --version -q --quiet --stdio -h --help check clean toolchain completions help"
    case "${prev}" in
        completions) COMPREPLY=( $(compgen -W "bash elvish fish powershell zsh nushell" -- "$cur") ); return 0 ;;
        toolchain) COMPREPLY=( $(compgen -W "install uninstall help" -- "$cur") ); return 0 ;;
    esac
    COMPREPLY=( $(compgen -W "${opts}" -- "$cur") )
}
complete -F _rustowl rustowl
"#;

const ZSH_COMPLETION: &str = r#"#compdef rustowl

_rustowl() {
    _arguments \
        '-V[Print version]' \
        '--version[Print version]' \
        '*-q[Suppress output]' \
        '*--quiet[Suppress output]' \
        '--stdio[Use stdio to communicate with the LSP server]' \
        '-h[Print help]' \
        '--help[Print help]' \
        '1: :((check clean toolchain completions help))'
}
"#;

const FISH_COMPLETION: &str = r#"complete -c rustowl -s V -l version -d 'Print version'
complete -c rustowl -s q -l quiet -d 'Suppress output'
complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'
complete -c rustowl -s h -l help -d 'Print help'
complete -c rustowl -f -n '__fish_use_subcommand' -a check -d 'Check availability'
complete -c rustowl -f -n '__fish_use_subcommand' -a clean -d 'Remove artifacts from the target directory'
complete -c rustowl -f -n '__fish_use_subcommand' -a toolchain -d 'Install or uninstall the toolchain'
complete -c rustowl -f -n '__fish_use_subcommand' -a completions -d 'Generate shell completions'
"#;

const POWERSHELL_COMPLETION: &str = r#"using namespace System.Management.Automation
using namespace System.Management.Automation.Language
Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    'check','clean','toolchain','completions','help','--help','--version','--quiet','--stdio' |
        Where-Object { $_ -like "$wordToComplete*" } |
        ForEach-Object { [CompletionResult]::new($_, $_, 'ParameterValue', $_) }
}
"#;

const ELVISH_COMPLETION: &str = r#"edit:completion:arg-completer[rustowl] = {|@words|
    put check clean toolchain completions help --help --version --quiet --stdio
}
"#;

const NUSHELL_COMPLETION: &str = r#"export extern "rustowl" [
    --version(-V) # Print version
    --quiet(-q) # Suppress output
    --stdio # Use stdio to communicate with the LSP server
]
"#;
