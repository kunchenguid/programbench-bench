use chrono::{SecondsFormat, Utc};
use rand::RngExt;
use serde::Serialize;
use std::collections::{BTreeSet, HashMap};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

const ZERO_TIME: &str = "0001-01-01T00:00:00Z";

#[derive(Clone, Debug, Serialize)]
struct Task {
    uuid: String,
    status: String,
    #[serde(skip_serializing)]
    path: PathBuf,
    id: u32,
    summary: String,
    notes: String,
    tags: Vec<String>,
    project: String,
    priority: String,
    created: String,
    resolved: String,
    due: String,
}

#[derive(Default, Debug)]
struct Attrs {
    summary_words: Vec<String>,
    tags_add: Vec<String>,
    tags_remove: Vec<String>,
    project: Option<String>,
    remove_project: bool,
    priority: Option<String>,
    due: Option<String>,
    note_words: Vec<String>,
    template_id: Option<u32>,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let repo = match ensure_repo() {
        Ok(p) => p,
        Err(e) => {
            eprintln!("error: {e}");
            std::process::exit(1);
        }
    };
    if let Err(e) = run(&repo, args) {
        eprintln!("error: {e}");
        std::process::exit(1);
    }
}

fn run(repo: &Path, args: Vec<String>) -> Result<(), String> {
    if args.first().map(|s| s.as_str()) == Some("--help") || args.is_empty() {
        if args.is_empty() {
            list_cmd(repo, "next", &[], false)?;
        } else {
            print_help(None);
        }
        return Ok(());
    }
    if args.first().map(|s| s.as_str()) == Some("--version") {
        print_version();
        return Ok(());
    }
    let commands = command_names();
    let mut ids = Vec::new();
    let mut cmd_pos = None;
    for (i, a) in args.iter().enumerate() {
        if commands.contains(a.as_str()) {
            cmd_pos = Some(i);
            break;
        }
        if let Ok(n) = a.parse::<u32>() {
            ids.push(n);
        }
    }
    let Some(pos) = cmd_pos else {
        print_help(None);
        return Ok(());
    };
    for a in &args[..pos] {
        if let Ok(n) = a.parse::<u32>() {
            if !ids.contains(&n) {
                ids.push(n);
            }
        }
    }
    let cmd = args[pos].as_str();
    let rest = args[pos + 1..].to_vec();
    for a in &rest {
        if let Ok(n) = a.parse::<u32>() {
            if matches!(cmd, "done" | "start" | "stop" | "remove" | "modify" | "note" | "open") && !ids.contains(&n) {
                ids.push(n);
            }
        }
    }

    match cmd {
        "help" => print_help(rest.first().map(|s| s.as_str())),
        "version" => print_version(),
        "add" => {
            add_task(repo, &rest, "pending")?;
        }
        "template" => {
            add_task(repo, &rest, "template")?;
        }
        "log" => {
            let id = add_task(repo, &rest, "resolved")?;
            let mut tasks = load_tasks(repo)?;
            if let Some(t) = tasks.iter_mut().find(|t| t.id == id || (t.status == "resolved" && t.summary == parse_attrs(&rest, false).summary_words.join(" "))) {
                t.resolved = now();
                save_task(repo, t)?;
            }
        }
        "start" if ids.is_empty() => {
            let id = add_task(repo, &rest, "active")?;
            let task = find_task(repo, id)?;
            println!("Started {}: {}", task.id, task.summary);
            git_commit(repo, &format!("Started {}: {}", task.id, task.summary));
        }
        "start" => change_status(repo, &ids, "active", "Started", None)?,
        "stop" => change_status(repo, &ids, "paused", "Stopped", Some(words_without_ids(&rest)))?,
        "done" => resolve_tasks(repo, &ids, words_without_ids(&rest))?,
        "remove" => remove_tasks(repo, &ids)?,
        "modify" => modify_tasks(repo, &ids, &rest)?,
        "note" => note_task(repo, &ids, words_without_ids(&rest))?,
        "context" => set_context(repo, &rest)?,
        "show-open" | "next" => list_cmd(repo, cmd, &rest, false)?,
        "show-active" => list_status(repo, "active", &rest)?,
        "show-paused" => list_status(repo, "paused", &rest)?,
        "show-resolved" => list_status(repo, "resolved", &rest)?,
        "show-templates" => list_status(repo, "template", &rest)?,
        "show-unorganised" => show_unorganised(repo)?,
        "show-tags" => show_tags(repo)?,
        "show-projects" => show_projects(repo)?,
        "git" => pass_git(repo, &rest)?,
        "sync" => {
            pass_git(repo, &["pull".into(), "--no-edit".into()])?;
            pass_git(repo, &["push".into()])?;
        }
        "undo" => {
            let n = rest.first().and_then(|s| s.parse::<u32>().ok()).unwrap_or(1);
            pass_git(repo, &["reset".into(), "--hard".into(), format!("HEAD~{n}")])?;
        }
        "open" => open_urls(repo, &ids)?,
        "edit" => edit_task(repo, &ids)?,
        "bash-completion" | "fish-completion" | "zsh-completion" | "powershell-completion" => {}
        _ => print_help(None),
    }
    Ok(())
}

fn command_names() -> BTreeSet<&'static str> {
    [
        "next", "add", "template", "log", "start", "note", "stop", "done", "context",
        "modify", "edit", "undo", "sync", "open", "git", "remove", "show-projects",
        "show-tags", "show-active", "show-paused", "show-open", "show-resolved",
        "show-templates", "show-unorganised", "bash-completion", "fish-completion",
        "zsh-completion", "powershell-completion", "help", "version",
    ]
    .into_iter()
    .collect()
}

fn ensure_repo() -> Result<PathBuf, String> {
    let repo = if let Ok(p) = env::var("DSTASK_GIT_REPO") {
        PathBuf::from(p)
    } else {
        let home = env::var("HOME").map_err(|_| "HOME not set".to_string())?;
        PathBuf::from(home).join(".dstask")
    };
    if !repo.exists() {
        fs::create_dir_all(&repo).map_err(|e| e.to_string())?;
        let _ = Command::new("git").arg("-C").arg(&repo).arg("init").status();
        println!("\nAdd a remote repository with:\n\n\tdstask git remote add origin <repo>\n");
    }
    for d in ["pending", "active", "paused", "resolved", "template"] {
        fs::create_dir_all(repo.join(d)).map_err(|e| e.to_string())?;
    }
    Ok(repo)
}

fn parse_attrs(args: &[String], split_note: bool) -> Attrs {
    let mut a = Attrs::default();
    let mut in_note = false;
    for tok in args {
        if tok == "--" {
            continue;
        }
        if split_note && tok == "/" {
            in_note = true;
            continue;
        }
        if in_note {
            a.note_words.push(tok.clone());
            continue;
        }
        if let Some(t) = tok.strip_prefix('+') {
            if !t.is_empty() {
                a.tags_add.push(t.to_string());
            }
        } else if let Some(t) = tok.strip_prefix('-') {
            if let Some(p) = tok.strip_prefix("-project:") {
                if p.is_empty() {
                    a.remove_project = true;
                }
            } else if !t.is_empty() {
                a.tags_remove.push(t.to_string());
            }
        } else if let Some(p) = tok.strip_prefix("project:") {
            a.project = Some(p.to_string());
        } else if let Some(d) = tok.strip_prefix("due:") {
            a.due = Some(format_due(d));
        } else if let Some(t) = tok.strip_prefix("template:") {
            a.template_id = t.parse().ok();
        } else if matches!(tok.as_str(), "P0" | "P1" | "P2" | "P3") {
            a.priority = Some(tok.clone());
        } else if tok.parse::<u32>().is_err() {
            a.summary_words.push(tok.clone());
        }
    }
    a
}

fn add_task(repo: &Path, args: &[String], status: &str) -> Result<u32, String> {
    let mut attrs = parse_attrs(args, true);
    let ctx = if args.iter().any(|s| s == "--") { String::new() } else { current_context(repo) };
    let cattrs = parse_attrs(&ctx.split_whitespace().map(|s| s.to_string()).collect::<Vec<_>>(), false);
    for t in cattrs.tags_add {
        if !attrs.tags_add.contains(&t) {
            attrs.tags_add.push(t);
        }
    }
    if attrs.project.is_none() {
        attrs.project = cattrs.project;
    }
    if let Some(tid) = attrs.template_id {
        if let Ok(t) = find_task(repo, tid) {
            if attrs.summary_words.is_empty() {
                attrs.summary_words = t.summary.split_whitespace().map(|s| s.to_string()).collect();
            }
            for tag in t.tags {
                if !attrs.tags_add.contains(&tag) {
                    attrs.tags_add.push(tag);
                }
            }
            if attrs.project.is_none() {
                attrs.project = Some(t.project);
            }
            if attrs.priority.is_none() {
                attrs.priority = Some(t.priority);
            }
        }
    }
    let summary = attrs.summary_words.join(" ");
    let uuid = make_uuid();
    let mut t = Task {
        uuid: uuid.clone(),
        status: status.to_string(),
        path: repo.join(status).join(format!("{uuid}.yml")),
        id: 0,
        summary: summary.clone(),
        notes: attrs.note_words.join(" "),
        tags: attrs.tags_add,
        project: attrs.project.unwrap_or_default(),
        priority: attrs.priority.unwrap_or_else(|| "P2".into()),
        created: now(),
        resolved: if status == "resolved" { now() } else { ZERO_TIME.into() },
        due: attrs.due.unwrap_or_else(|| ZERO_TIME.into()),
    };
    save_task(repo, &t)?;
    let id = assign_ids(load_tasks(repo)?).into_iter().find(|x| x.uuid == uuid).map(|x| x.id).unwrap_or(0);
    t.id = id;
    let verb = if status == "template" { "Added template" } else { "Added" };
    println!("{verb} {id}: {summary}");
    git_commit(repo, &format!("{verb} {id}: {summary}"));
    Ok(id)
}

fn load_tasks(repo: &Path) -> Result<Vec<Task>, String> {
    let mut out = Vec::new();
    for status in ["pending", "active", "paused", "resolved", "template"] {
        let dir = repo.join(status);
        if !dir.exists() {
            continue;
        }
        for ent in fs::read_dir(&dir).map_err(|e| e.to_string())? {
            let path = ent.map_err(|e| e.to_string())?.path();
            if path.extension().and_then(|s| s.to_str()) == Some("yml") {
                if let Ok(mut t) = read_task(&path, status) {
                    t.path = path;
                    out.push(t);
                }
            }
        }
    }
    Ok(assign_ids(out))
}

fn assign_ids(mut tasks: Vec<Task>) -> Vec<Task> {
    let mut open: Vec<(String, String)> = tasks
        .iter()
        .filter(|t| t.status != "resolved" && t.status != "template")
        .map(|t| (t.created.clone(), t.uuid.clone()))
        .collect();
    open.sort();
    let ids: HashMap<String, u32> = open.into_iter().enumerate().map(|(i, (_, u))| (u, (i + 1) as u32)).collect();
    for t in &mut tasks {
        t.id = *ids.get(&t.uuid).unwrap_or(&0);
    }
    tasks
}

fn read_task(path: &Path, status: &str) -> Result<Task, String> {
    let txt = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let uuid = path.file_stem().unwrap().to_string_lossy().to_string();
    let mut t = Task {
        uuid,
        status: status.to_string(),
        path: path.to_path_buf(),
        id: 0,
        summary: String::new(),
        notes: String::new(),
        tags: Vec::new(),
        project: String::new(),
        priority: "P2".into(),
        created: ZERO_TIME.into(),
        resolved: ZERO_TIME.into(),
        due: ZERO_TIME.into(),
    };
    let lines: Vec<&str> = txt.lines().collect();
    let mut i = 0;
    while i < lines.len() {
        let line = lines[i];
        if let Some(v) = line.strip_prefix("summary: ") {
            t.summary = unquote(v);
        } else if let Some(v) = line.strip_prefix("notes: ") {
            if v.starts_with('|') {
                i += 1;
                let mut ns = Vec::new();
                while i < lines.len() && (lines[i].starts_with("  ") || lines[i].is_empty()) {
                    ns.push(lines[i].strip_prefix("  ").unwrap_or(lines[i]).to_string());
                    i += 1;
                }
                i -= 1;
                t.notes = ns.join("\n");
            } else {
                t.notes = unquote(v);
            }
        } else if line == "tags:" {
            i += 1;
            while i < lines.len() && lines[i].starts_with("- ") {
                t.tags.push(unquote(&lines[i][2..]));
                i += 1;
            }
            i -= 1;
        } else if let Some(v) = line.strip_prefix("project: ") {
            t.project = unquote(v);
        } else if let Some(v) = line.strip_prefix("priority: ") {
            t.priority = unquote(v);
        } else if let Some(v) = line.strip_prefix("created: ") {
            t.created = unquote(v);
        } else if let Some(v) = line.strip_prefix("resolved: ") {
            t.resolved = unquote(v);
        } else if let Some(v) = line.strip_prefix("due: ") {
            t.due = unquote(v);
        }
        i += 1;
    }
    Ok(t)
}

fn save_task(repo: &Path, t: &Task) -> Result<(), String> {
    let dir = repo.join(&t.status);
    fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let path = dir.join(format!("{}.yml", t.uuid));
    let mut s = String::new();
    s.push_str(&format!("summary: {}\n", yaml_scalar(&t.summary)));
    if t.notes.is_empty() {
        s.push_str("notes: \"\"\n");
    } else if t.notes.contains('\n') {
        s.push_str("notes: |-\n");
        for line in t.notes.lines() {
            s.push_str("  ");
            s.push_str(line);
            s.push('\n');
        }
    } else {
        s.push_str(&format!("notes: {}\n", yaml_scalar(&t.notes)));
    }
    s.push_str("tags:\n");
    for tag in &t.tags {
        s.push_str(&format!("- {}\n", yaml_scalar(tag)));
    }
    s.push_str(&format!("project: {}\n", yaml_scalar(&t.project)));
    s.push_str(&format!("priority: {}\n", t.priority));
    s.push_str("delegatedto: \"\"\nsubtasks: []\ndependencies: []\n");
    s.push_str(&format!("created: {}\nresolved: {}\ndue: {}\n", t.created, t.resolved, t.due));
    fs::write(path, s).map_err(|e| e.to_string())
}

fn yaml_scalar(s: &str) -> String {
    if s.is_empty() {
        "\"\"".into()
    } else if s.contains(':') || s.contains('#') || s.starts_with(' ') || s.ends_with(' ') || s.contains('"') {
        format!("{:?}", s)
    } else {
        s.to_string()
    }
}

fn unquote(s: &str) -> String {
    let s = s.trim();
    if s == "\"\"" {
        String::new()
    } else if s.starts_with('"') && s.ends_with('"') && s.len() >= 2 {
        s[1..s.len() - 1].replace("\\\"", "\"")
    } else {
        s.to_string()
    }
}

fn filter_tasks(repo: &Path, mut tasks: Vec<Task>, args: &[String], use_context: bool) -> Vec<Task> {
    let mut terms: Vec<String> = args.iter().filter(|s| s.as_str() != "--" && s.parse::<u32>().is_err()).cloned().collect();
    if use_context && !args.iter().any(|s| s == "--") {
        terms.extend(current_context(repo).split_whitespace().map(|s| s.to_string()));
    }
    for term in terms {
        if let Some(tag) = term.strip_prefix('+') {
            tasks.retain(|t| t.tags.iter().any(|x| x == tag));
        } else if let Some(tag) = term.strip_prefix('-') {
            tasks.retain(|t| !t.tags.iter().any(|x| x == tag));
        } else if let Some(p) = term.strip_prefix("project:") {
            tasks.retain(|t| t.project == p);
        } else if matches!(term.as_str(), "P0" | "P1" | "P2" | "P3") {
            tasks.retain(|t| t.priority == term);
        } else if term != "--json" {
            let q = term.to_lowercase();
            tasks.retain(|t| t.summary.to_lowercase().contains(&q) || t.notes.to_lowercase().contains(&q));
        }
    }
    tasks
}

fn list_cmd(repo: &Path, cmd: &str, args: &[String], include_resolved: bool) -> Result<(), String> {
    let mut tasks: Vec<Task> = load_tasks(repo)?
        .into_iter()
        .filter(|t| include_resolved || (t.status != "resolved" && t.status != "template"))
        .collect();
    tasks = filter_tasks(repo, tasks, args, true);
    sort_tasks(&mut tasks);
    if cmd == "next" && !args.iter().any(|s| s == "--json") {
        tasks.truncate(20);
    }
    print_json(&tasks)
}

fn list_status(repo: &Path, status: &str, args: &[String]) -> Result<(), String> {
    let mut tasks: Vec<Task> = load_tasks(repo)?.into_iter().filter(|t| t.status == status).collect();
    tasks = filter_tasks(repo, tasks, args, true);
    sort_tasks(&mut tasks);
    print_json(&tasks)
}

fn sort_tasks(tasks: &mut [Task]) {
    tasks.sort_by(|a, b| {
        let pa = priority_rank(&a.priority);
        let pb = priority_rank(&b.priority);
        pa.cmp(&pb).then(a.created.cmp(&b.created))
    });
}

fn priority_rank(p: &str) -> u8 {
    match p {
        "P0" => 0,
        "P1" => 1,
        "P2" => 2,
        "P3" => 3,
        _ => 2,
    }
}

fn print_json(tasks: &[Task]) -> Result<(), String> {
    let s = serde_json::to_string_pretty(tasks).map_err(|e| e.to_string())?;
    print!("{s}");
    io::stdout().flush().ok();
    Ok(())
}

fn find_task(repo: &Path, id: u32) -> Result<Task, String> {
    load_tasks(repo)?.into_iter().find(|t| t.id == id || (id == 0 && t.status == "resolved")).ok_or_else(|| format!("task {id} not found"))
}

fn change_status(repo: &Path, ids: &[u32], new_status: &str, verb: &str, note: Option<String>) -> Result<(), String> {
    for id in ids {
        let mut t = find_task(repo, *id)?;
        let old = t.path.clone();
        if let Some(n) = &note {
            append_note(&mut t, n);
        }
        t.status = new_status.to_string();
        save_task(repo, &t)?;
        if old.exists() && old != repo.join(new_status).join(format!("{}.yml", t.uuid)) {
            let _ = fs::remove_file(old);
        }
        println!("{verb} {}: {}", id, t.summary);
        git_commit(repo, &format!("{verb} {}: {}", id, t.summary));
    }
    Ok(())
}

fn resolve_tasks(repo: &Path, ids: &[u32], note: String) -> Result<(), String> {
    for id in ids {
        let mut t = find_task(repo, *id)?;
        let old = t.path.clone();
        append_note(&mut t, &note);
        t.status = "resolved".into();
        t.resolved = now();
        save_task(repo, &t)?;
        if old.exists() {
            let _ = fs::remove_file(old);
        }
        println!("Resolved {}: {}", id, t.summary);
        git_commit(repo, &format!("Resolved {}: {}", id, t.summary));
    }
    Ok(())
}

fn remove_tasks(repo: &Path, ids: &[u32]) -> Result<(), String> {
    for id in ids {
        let t = find_task(repo, *id)?;
        let _ = fs::remove_file(&t.path);
        println!("Removed {}: {}", id, t.summary);
        git_commit(repo, &format!("Removed {}: {}", id, t.summary));
    }
    Ok(())
}

fn modify_tasks(repo: &Path, ids: &[u32], args: &[String]) -> Result<(), String> {
    let attrs = parse_attrs(args, false);
    for id in ids {
        let mut t = find_task(repo, *id)?;
        for tag in &attrs.tags_add {
            if !t.tags.contains(tag) {
                t.tags.push(tag.clone());
            }
        }
        t.tags.retain(|x| !attrs.tags_remove.contains(x));
        if attrs.remove_project {
            t.project.clear();
        }
        if let Some(p) = &attrs.project {
            t.project = p.clone();
        }
        if let Some(p) = &attrs.priority {
            t.priority = p.clone();
        }
        if let Some(d) = &attrs.due {
            t.due = d.clone();
        }
        save_task(repo, &t)?;
        println!("Modified {}: {}", id, t.summary);
        git_commit(repo, &format!("Modified {}: {}", id, t.summary));
    }
    Ok(())
}

fn note_task(repo: &Path, ids: &[u32], text: String) -> Result<(), String> {
    let id = ids.first().copied().ok_or_else(|| "missing task id".to_string())?;
    let mut t = find_task(repo, id)?;
    if text.is_empty() {
        println!("{}", t.notes);
    } else {
        append_note(&mut t, &text);
        save_task(repo, &t)?;
        println!("Noted {}: {}", id, t.summary);
        git_commit(repo, &format!("Noted {}: {}", id, t.summary));
    }
    Ok(())
}

fn append_note(t: &mut Task, note: &str) {
    if note.is_empty() {
        return;
    }
    if !t.notes.is_empty() {
        t.notes.push('\n');
    }
    t.notes.push_str(note);
}

fn words_without_ids(args: &[String]) -> String {
    args.iter().filter(|s| s.parse::<u32>().is_err()).cloned().collect::<Vec<_>>().join(" ")
}

fn set_context(repo: &Path, args: &[String]) -> Result<(), String> {
    let ctx = if args.first().map(|s| s.as_str()) == Some("none") || args.first().map(|s| s.as_str()) == Some("--") {
        String::new()
    } else {
        args.join(" ")
    };
    fs::create_dir_all(repo.join(".git").join("dstask")).ok();
    fs::write(repo.join(".git").join("dstask").join("context"), &ctx).map_err(|e| e.to_string())?;
    if ctx.is_empty() {
        println!("Active context: none");
    } else {
        println!("Active context: {ctx}");
    }
    Ok(())
}

fn current_context(repo: &Path) -> String {
    if let Ok(c) = env::var("DSTASK_CONTEXT") {
        return c;
    }
    fs::read_to_string(repo.join(".git").join("dstask").join("context")).unwrap_or_default()
}

fn show_tags(repo: &Path) -> Result<(), String> {
    let mut tags = BTreeSet::new();
    for t in load_tasks(repo)?.into_iter().filter(|t| t.status != "resolved" && t.status != "template") {
        for tag in t.tags {
            tags.insert(tag);
        }
    }
    for tag in tags {
        println!("{tag}");
    }
    Ok(())
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct ProjectOut {
    name: String,
    task_count: u32,
    resolved_count: u32,
    active: bool,
    created: String,
    resolved: String,
    priority: String,
}

fn show_projects(repo: &Path) -> Result<(), String> {
    let mut map: HashMap<String, ProjectOut> = HashMap::new();
    for t in load_tasks(repo)? {
        if t.project.is_empty() {
            continue;
        }
        let e = map.entry(t.project.clone()).or_insert(ProjectOut {
            name: t.project.clone(),
            task_count: 0,
            resolved_count: 0,
            active: false,
            created: t.created.clone(),
            resolved: ZERO_TIME.into(),
            priority: t.priority.clone(),
        });
        e.task_count += 1;
        if t.status == "resolved" {
            e.resolved_count += 1;
            e.resolved = t.resolved.clone();
        }
        if t.status == "active" {
            e.active = true;
        }
        if t.created < e.created {
            e.created = t.created.clone();
        }
        if priority_rank(&t.priority) < priority_rank(&e.priority) {
            e.priority = t.priority.clone();
        }
    }
    let mut vals: Vec<_> = map.into_values().collect();
    vals.sort_by(|a, b| a.name.cmp(&b.name));
    println!("{}", serde_json::to_string_pretty(&vals).map_err(|e| e.to_string())?);
    Ok(())
}

fn show_unorganised(repo: &Path) -> Result<(), String> {
    let mut tasks: Vec<Task> = load_tasks(repo)?.into_iter().filter(|t| t.status != "resolved" && t.status != "template" && t.tags.is_empty() && t.project.is_empty()).collect();
    sort_tasks(&mut tasks);
    print_json(&tasks)
}

fn pass_git(repo: &Path, args: &[String]) -> Result<(), String> {
    let status = Command::new("git").arg("-C").arg(repo).args(args).status().map_err(|e| e.to_string())?;
    if !status.success() {
        return Err(format!("git failed: {status}"));
    }
    Ok(())
}

fn git_commit(repo: &Path, msg: &str) {
    let _ = Command::new("git").arg("-C").arg(repo).arg("add").arg(".").status();
    let _ = Command::new("git").arg("-C").arg(repo).arg("commit").arg("-m").arg(msg).status();
}

fn open_urls(repo: &Path, ids: &[u32]) -> Result<(), String> {
    for id in ids {
        let t = find_task(repo, *id)?;
        for word in t.summary.split_whitespace().chain(t.notes.split_whitespace()) {
            if word.starts_with("http://") || word.starts_with("https://") {
                println!("{}", word.trim_matches(|c| c == ')' || c == ']' || c == ',' || c == '.'));
            }
        }
    }
    Ok(())
}

fn edit_task(repo: &Path, ids: &[u32]) -> Result<(), String> {
    let id = ids.first().copied().ok_or_else(|| "missing task id".to_string())?;
    let t = find_task(repo, id)?;
    let editor = env::var("EDITOR").unwrap_or_else(|_| "vi".into());
    let _ = Command::new(editor).arg(&t.path).status();
    Ok(())
}

fn make_uuid() -> String {
    let mut rng = rand::rng();
    let mut b = [0u8; 16];
    rng.fill(&mut b);
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7], b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15]
    )
}

fn now() -> String {
    Utc::now().to_rfc3339_opts(SecondsFormat::Nanos, true)
}

fn format_due(d: &str) -> String {
    if d.contains('T') {
        d.to_string()
    } else {
        format!("{d}T00:00:00Z")
    }
}

fn print_version() {
    println!("Version: Unknown");
    println!("Git commit: Unknown");
    println!("Build date: Unknown");
}

fn print_help(cmd: Option<&str>) {
    match cmd {
        Some("add") => println!("Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website"),
        Some("modify") => println!("Usage: dstask <id...> modify <filter>\nUsage: dstask modify <filter>"),
        Some("done") => println!("Usage: dstask <id...> done [closing note]"),
        Some("start") => println!("Usage: dstask <id...> start\nUsage: dstask start [task summary] [--]"),
        Some("stop") => println!("Usage: dstask <id...> stop [text]"),
        Some("note") => println!("Usage: dstask note <id>\nUsage: dstask note <id> <text>"),
        Some("context") => println!("Usage: dstask context <filter>\nExample: dstask context +work -bug\nExample: dstask context none"),
        Some("remove") => println!("Usage: dstask remove <id...>"),
        Some("show-projects") => println!("Usage: dstask show-projects\n\nShow a breakdown of projects with progress information"),
        _ => println!(
            "Usage: dstask [id...] <cmd> [task summary/filter]\n\nAvailable commands:\n\nnext              : Show most important tasks (priority, creation date -- truncated and default)\nadd               : Add a task\ntemplate          : Add a task template\nlog               : Log a task (already resolved)\nstart             : Change task status to active\nnote              : Append to or edit note for a task\nstop              : Change task status to pending\ndone              : Resolve a task\ncontext           : Set global context for task list and new tasks (use \"none\" to set no context)\nmodify            : Change task attributes specified on command line\nedit              : Edit task with text editor\nundo              : Undo last n commits\nsync              : Pull then push to git repository, automatic merge commit.\nopen              : Open all URLs found in summary/annotations\ngit               : Pass a command to git in the repository. Used for push/pull.\nremove            : Remove a task (use to remove tasks added by mistake)\nshow-projects     : List projects with completion status\nshow-tags         : List tags in use\nshow-active       : Show tasks that have been started\nshow-paused       : Show tasks that have been started then stopped\nshow-open         : Show all non-resolved tasks (without truncation)\nshow-resolved     : Show resolved tasks\nshow-templates    : Show task templates\nshow-unorganised  : Show untagged tasks with no projects (global context)\nbash-completion   : Print bash completion script to stdout\nfish-completion   : Print fish completion script to stdout\nzsh-completion    : Print zsh completion script to stdout\nhelp              : Get help on any command or show this message\nversion           : Show dstask version information"
        ),
    }
}
