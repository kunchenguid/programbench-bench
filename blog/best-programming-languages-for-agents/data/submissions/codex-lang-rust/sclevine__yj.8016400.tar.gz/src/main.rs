use indexmap::IndexMap;
use serde_json::Value as JsonValue;
use std::env;
use std::io::{self, Read};

#[derive(Clone, Debug, PartialEq)]
enum V {
    Null,
    Bool(bool),
    Num(String),
    Str(String),
    Arr(Vec<V>),
    Obj(IndexMap<String, V>),
}

const HELP: &str = "Usage: ./executable [-][ytjcrneikhv]

Convert between YAML, TOML, JSON, and HCL.
Preserves map order.

-x[x]  Convert using stdin. Valid options:
          -yj, -y = YAML to JSON (default)
          -yy     = YAML to YAML
          -yt     = YAML to TOML
          -yc     = YAML to HCL
          -tj, -t = TOML to JSON
          -ty     = TOML to YAML
          -tt     = TOML to TOML
          -tc     = TOML to HCL
          -jj     = JSON to JSON
          -jy, -r = JSON to YAML
          -jt     = JSON to TOML
          -jc     = JSON to HCL
          -cy     = HCL to YAML
          -ct     = HCL to TOML
          -cj, -c = HCL to JSON
          -cc     = HCL to HCL
-n     Do not covert inf, -inf, and NaN to/from strings (YAML or TOML only)
-e     Escape HTML (JSON out only)
-i     Indent output (JSON or TOML out only)
-k     Attempt to parse keys as objects or numeric types (YAML out only)
-h     Show this help message
-v     Show version
";

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut chars = Vec::new();
    for a in &args {
        if a.starts_with('-') {
            let rest = a.trim_start_matches('-');
            chars.extend(rest.chars());
        } else {
            eprintln!("Error: invalid argument specified: {}", a);
            std::process::exit(1);
        }
    }
    let valid = "ytjcrneikhv";
    let invalid: Vec<char> = chars.iter().copied().filter(|c| !valid.contains(*c)).collect();
    if !invalid.is_empty() {
        print!("{}\n", HELP);
        eprintln!("Error: invalid flags specified: {}", invalid.iter().map(|c| c.to_string()).collect::<Vec<_>>().join(" "));
        std::process::exit(1);
    }
    if chars.contains(&'h') {
        print!("{}", HELP);
        return;
    }
    if chars.contains(&'v') {
        println!("v0.0.0");
        return;
    }
    let conv: Vec<char> = chars.iter().copied().filter(|c| "ytjcr".contains(*c)).collect();
    let (from, to) = match conv.as_slice() {
        [] => ('y', 'j'),
        ['y'] => ('y', 'j'),
        ['t'] => ('t', 'j'),
        ['r'] => ('j', 'y'),
        ['c'] => ('h', 'j'),
        [a, b, ..] => (map_in(*a), map_out(*b)),
        [a] => (map_in(*a), 'j'),
    };
    let indent = chars.contains(&'i');
    let escape_html = chars.contains(&'e');
    let key_parse = chars.contains(&'k');

    let mut input = String::new();
    io::stdin().read_to_string(&mut input).unwrap();
    let parsed = match from {
        'j' => parse_json(&input).map_err(|e| format!("Error parsing JSON: {}", e)),
        't' => parse_toml(&input).map_err(|e| format!("Error parsing TOML: {}", first_line(&e.to_string()))),
        'h' => Ok(parse_hcl(&input)),
        _ => parse_yaml(&input).map_err(|e| format!("Error parsing YAML: {}", e)),
    };
    let v = match parsed {
        Ok(v) => v,
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(1);
        }
    };
    let out = match to {
        'j' => write_json(&v, indent, escape_html),
        't' => Ok(write_toml(&v, indent)),
        'h' => write_hcl(&v),
        _ => Ok(write_yaml(&v, 0, key_parse).trim_end().to_string()),
    };
    match out {
        Ok(s) => {
            if !s.is_empty() {
                println!("{}", s);
            }
        }
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(1);
        }
    }
}

fn map_in(c: char) -> char { if c == 'c' { 'h' } else { c } }
fn map_out(c: char) -> char { if c == 'c' { 'h' } else { c } }
fn first_line(s: &str) -> String { s.lines().next().unwrap_or(s).to_string() }

fn parse_json(s: &str) -> Result<V, String> {
    serde_json::from_str::<JsonValue>(s).map(json_to_v).map_err(|e| e.to_string())
}

fn json_to_v(j: JsonValue) -> V {
    match j {
        JsonValue::Null => V::Null,
        JsonValue::Bool(b) => V::Bool(b),
        JsonValue::Number(n) => V::Num(n.to_string()),
        JsonValue::String(s) => V::Str(s),
        JsonValue::Array(a) => V::Arr(a.into_iter().map(json_to_v).collect()),
        JsonValue::Object(o) => V::Obj(o.into_iter().map(|(k, v)| (k, json_to_v(v))).collect()),
    }
}

fn v_to_json(v: &V) -> JsonValue {
    match v {
        V::Null => JsonValue::Null,
        V::Bool(b) => JsonValue::Bool(*b),
        V::Num(s) => serde_json::from_str::<JsonValue>(s).unwrap_or(JsonValue::String(s.clone())),
        V::Str(s) => JsonValue::String(s.clone()),
        V::Arr(a) => JsonValue::Array(a.iter().map(v_to_json).collect()),
        V::Obj(m) => JsonValue::Object(m.iter().map(|(k, v)| (k.clone(), v_to_json(v))).collect()),
    }
}

fn write_json(v: &V, indent: bool, escape_html: bool) -> Result<String, String> {
    let j = v_to_json(v);
    let mut s = if indent { serde_json::to_string_pretty(&j) } else { serde_json::to_string(&j) }.map_err(|e| e.to_string())?;
    if escape_html {
        s = s.replace('<', "\\u003c").replace('>', "\\u003e").replace('&', "\\u0026");
    }
    Ok(s)
}

fn parse_toml(s: &str) -> Result<V, toml::de::Error> {
    let tv: toml::Value = toml::from_str(s)?;
    Ok(toml_to_v(tv))
}

fn toml_to_v(t: toml::Value) -> V {
    match t {
        toml::Value::String(s) => V::Str(s),
        toml::Value::Integer(i) => V::Num(i.to_string()),
        toml::Value::Float(f) => V::Num(format_float(f)),
        toml::Value::Boolean(b) => V::Bool(b),
        toml::Value::Datetime(d) => V::Str(d.to_string()),
        toml::Value::Array(a) => V::Arr(a.into_iter().map(toml_to_v).collect()),
        toml::Value::Table(t) => V::Obj(t.into_iter().map(|(k, v)| (k, toml_to_v(v))).collect()),
    }
}

fn format_float(f: f64) -> String {
    let s = f.to_string();
    if s.contains('.') { s } else { format!("{}.0", s) }
}

fn write_toml(v: &V, _indent: bool) -> String {
    let mut out = String::new();
    if let V::Obj(m) = v {
        write_toml_table(m, None, &mut out);
    }
    out.trim_end().to_string()
}

fn write_toml_table(m: &IndexMap<String, V>, prefix: Option<String>, out: &mut String) {
    let mut subtables = Vec::new();
    for (k, v) in m {
        if matches!(v, V::Obj(_)) {
            subtables.push((k, v));
        } else if !matches!(v, V::Null) {
            out.push_str(&format!("{} = {}\n", bare_toml_key(k), toml_scalar(v)));
        }
    }
    for (k, v) in subtables {
        if let V::Obj(child) = v {
            if !out.ends_with("\n\n") && !out.is_empty() { out.push('\n'); }
            let name = match &prefix { Some(p) => format!("{}.{}", p, bare_toml_key(k)), None => bare_toml_key(k) };
            out.push_str(&format!("[{}]\n", name));
            write_toml_table(child, Some(name), out);
        }
    }
}

fn bare_toml_key(k: &str) -> String {
    if k.chars().all(|c| c.is_ascii_alphanumeric() || c == '_' || c == '-') && !k.is_empty() { k.to_string() } else { json_string(k) }
}

fn toml_scalar(v: &V) -> String {
    match v {
        V::Bool(b) => b.to_string(),
        V::Num(s) => s.clone(),
        V::Str(s) => json_string(s),
        V::Arr(a) => format!("[{}]", a.iter().filter(|x| !matches!(x, V::Null)).map(toml_scalar).collect::<Vec<_>>().join(", ")),
        V::Obj(m) => format!("{{ {} }}", m.iter().map(|(k, v)| format!("{} = {}", bare_toml_key(k), toml_scalar(v))).collect::<Vec<_>>().join(", ")),
        V::Null => String::new(),
    }
}

fn parse_yaml(s: &str) -> Result<V, String> {
    let lines: Vec<(usize, String)> = s.lines()
        .filter_map(|l| {
            let no_comment = strip_comment(l);
            if no_comment.trim().is_empty() { None } else {
                Some((no_comment.chars().take_while(|c| *c == ' ').count(), no_comment.trim_end().to_string()))
            }
        }).collect();
    if lines.is_empty() { return Ok(V::Null); }
    let (v, _) = parse_yaml_block(&lines, 0, lines[0].0)?;
    Ok(v)
}

fn strip_comment(l: &str) -> String {
    let mut in_s = false; let mut in_d = false; let mut prev = '\0';
    for (i, c) in l.char_indices() {
        if c == '\'' && !in_d { in_s = !in_s; }
        if c == '"' && !in_s && prev != '\\' { in_d = !in_d; }
        if c == '#' && !in_s && !in_d && (i == 0 || l.as_bytes()[i-1].is_ascii_whitespace()) { return l[..i].to_string(); }
        prev = c;
    }
    l.to_string()
}

fn parse_yaml_block(lines: &[(usize, String)], mut i: usize, indent: usize) -> Result<(V, usize), String> {
    if lines[i].1.trim_start().starts_with("- ") {
        let mut arr = Vec::new();
        while i < lines.len() && lines[i].0 == indent && lines[i].1.trim_start().starts_with("- ") {
            let rest = lines[i].1.trim_start()[2..].trim();
            if rest.is_empty() {
                let (v, ni) = if i + 1 < lines.len() && lines[i+1].0 > indent { parse_yaml_block(lines, i+1, lines[i+1].0)? } else { (V::Null, i+1) };
                arr.push(v); i = ni;
            } else if rest.contains(": ") || rest.ends_with(':') {
                let mut fake = vec![(indent + 2, rest.to_string())];
                let start = fake.len();
                let mut j = i + 1;
                while j < lines.len() && lines[j].0 > indent { fake.push(lines[j].clone()); j += 1; }
                let (v, _) = parse_yaml_block(&fake, start - 1, indent + 2)?;
                arr.push(v); i = j;
            } else {
                arr.push(parse_scalar(rest)); i += 1;
            }
        }
        Ok((V::Arr(arr), i))
    } else {
        let mut map = IndexMap::new();
        while i < lines.len() && lines[i].0 == indent {
            let text = lines[i].1.trim_start();
            let Some(pos) = find_key_colon(text) else { return Ok((parse_scalar(text), i + 1)); };
            let key = unquote(&text[..pos].trim());
            let rest = text[pos+1..].trim();
            if rest == "|-" || rest == "|" {
                let mut vals = Vec::new(); let mut j = i + 1;
                while j < lines.len() && lines[j].0 > indent { vals.push(lines[j].1[std::cmp::min(lines[j].0, indent+2)..].to_string()); j += 1; }
                map.insert(key, V::Str(vals.join("\n"))); i = j;
            } else if rest.is_empty() {
                if i + 1 < lines.len() && lines[i+1].0 > indent {
                    let (v, ni) = parse_yaml_block(lines, i+1, lines[i+1].0)?;
                    map.insert(key, v); i = ni;
                } else { map.insert(key, V::Null); i += 1; }
            } else {
                map.insert(key, parse_scalar(rest)); i += 1;
            }
        }
        Ok((V::Obj(map), i))
    }
}

fn find_key_colon(s: &str) -> Option<usize> {
    let mut in_s=false; let mut in_d=false; let mut prev='\0';
    for (i,c) in s.char_indices() {
        if c=='\'' && !in_d { in_s=!in_s; }
        if c=='"' && !in_s && prev!='\\' { in_d=!in_d; }
        if c==':' && !in_s && !in_d { return Some(i); }
        prev=c;
    }
    None
}

fn parse_scalar(s: &str) -> V {
    let s = s.trim();
    if s == "null" || s == "~" { V::Null }
    else if s == "true" { V::Bool(true) }
    else if s == "false" { V::Bool(false) }
    else if (s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\'')) { V::Str(unquote(s)) }
    else if s.starts_with('[') && s.ends_with(']') { V::Arr(split_top(&s[1..s.len()-1], ',').into_iter().filter(|x| !x.trim().is_empty()).map(|x| parse_scalar(x.trim())).collect()) }
    else if s.starts_with('{') && s.ends_with('}') {
        let mut m = IndexMap::new();
        for p in split_top(&s[1..s.len()-1], ',') {
            if let Some(pos) = find_key_colon(p) {
                m.insert(unquote(p[..pos].trim()), parse_scalar(p[pos+1..].trim()));
            }
        }
        V::Obj(m)
    }
    else if is_num(s) { V::Num(s.to_string()) }
    else { V::Str(s.to_string()) }
}

fn split_top(s: &str, sep: char) -> Vec<&str> {
    let mut res = Vec::new(); let mut start=0; let mut depth=0; let mut in_s=false; let mut in_d=false; let mut prev='\0';
    for (i,c) in s.char_indices() {
        if c=='\'' && !in_d { in_s=!in_s; }
        else if c=='"' && !in_s && prev!='\\' { in_d=!in_d; }
        else if !in_s && !in_d {
            if "[{(".contains(c) { depth += 1; }
            if "]})".contains(c) { depth -= 1; }
            if c==sep && depth==0 { res.push(&s[start..i]); start=i+1; }
        }
        prev=c;
    }
    res.push(&s[start..]);
    res
}

fn is_num(s: &str) -> bool {
    s.parse::<i64>().is_ok() || (s.contains('.') || s.contains('e') || s.contains('E')) && s.parse::<f64>().is_ok()
}

fn unquote(s: &str) -> String {
    let st = s.trim();
    if st.len() >= 2 && st.starts_with('"') && st.ends_with('"') {
        serde_json::from_str::<String>(st).unwrap_or_else(|_| st[1..st.len()-1].to_string())
    } else if st.len() >= 2 && st.starts_with('\'') && st.ends_with('\'') {
        st[1..st.len()-1].replace("''", "'")
    } else { st.to_string() }
}

fn write_yaml(v: &V, indent: usize, key_parse: bool) -> String {
    match v {
        V::Obj(m) => {
            let mut out = String::new();
            for (k, v) in m {
                let key = yaml_key(k, key_parse);
                match v {
                    V::Obj(_) | V::Arr(_) => out.push_str(&format!("{}{}:\n{}", " ".repeat(indent), key, write_yaml(v, indent+2, key_parse))),
                    _ => out.push_str(&format!("{}{}: {}\n", " ".repeat(indent), key, yaml_scalar(v))),
                }
            }
            out
        }
        V::Arr(a) => {
            let mut out = String::new();
            for v in a {
                match v {
                    V::Obj(_) | V::Arr(_) => out.push_str(&format!("{}-\n{}", " ".repeat(indent), write_yaml(v, indent+2, key_parse))),
                    _ => out.push_str(&format!("{}- {}\n", " ".repeat(indent), yaml_scalar(v))),
                }
            }
            out
        }
        _ => format!("{}{}\n", " ".repeat(indent), yaml_scalar(v)),
    }
}

fn yaml_key(k: &str, parse: bool) -> String {
    if parse && (k == "true" || k == "false" || is_num(k)) { k.to_string() }
    else if k == "null" || k.contains(':') || k.is_empty() { json_string(k) }
    else { k.to_string() }
}

fn yaml_scalar(v: &V) -> String {
    match v {
        V::Null => "null".to_string(),
        V::Bool(b) => b.to_string(),
        V::Num(s) => s.clone(),
        V::Str(s) => {
            if s.is_empty() { "\"\"".to_string() }
            else if s.contains('\n') { format!("|-\n  {}", s.replace('\n', "\n  ")) }
            else if s.contains(": ") { format!("'{}'", s.replace('\'', "''")) }
            else { s.clone() }
        }
        V::Arr(_) | V::Obj(_) => String::new(),
    }
}

fn parse_hcl(s: &str) -> V {
    let mut m = IndexMap::new();
    let mut lines = s.lines().peekable();
    while let Some(line) = lines.next() {
        let t = line.trim();
        if t.is_empty() || t.starts_with('#') || t.starts_with("//") { continue; }
        if t.ends_with('{') && !t.contains('=') {
            let name = t.trim_end_matches('{').trim().trim_matches('"').to_string();
            let mut body = String::new();
            let mut depth = 1;
            for l in lines.by_ref() {
                let tt = l.trim();
                if tt.ends_with('{') { depth += 1; }
                if tt == "}" { depth -= 1; if depth == 0 { break; } }
                body.push_str(l); body.push('\n');
            }
            let obj = parse_hcl(&body);
            m.entry(name.clone()).or_insert_with(|| V::Arr(Vec::new()));
            if let Some(V::Arr(a)) = m.get_mut(&name) { a.push(obj); }
        } else if let Some(eq) = t.find('=') {
            let key = t[..eq].trim().trim_matches('"').to_string();
            let val = parse_hcl_value(t[eq+1..].trim());
            m.insert(key, val);
        }
    }
    V::Obj(m)
}

fn parse_hcl_value(s: &str) -> V {
    let s = s.trim().trim_end_matches(',');
    if s.starts_with('"') { parse_scalar(s) }
    else if s == "true" || s == "false" || is_num(s) { parse_scalar(s) }
    else if s.starts_with('[') && s.ends_with(']') { parse_scalar(s) }
    else if s.starts_with('{') && s.ends_with('}') {
        let inner = &s[1..s.len()-1];
        let mut m = IndexMap::new();
        for p in split_top(inner, ',') {
            let part = p.trim();
            if let Some(eq) = part.find('=') {
                m.insert(part[..eq].trim().trim_matches('"').to_string(), parse_hcl_value(part[eq+1..].trim()));
            }
        }
        V::Obj(m)
    } else { V::Str(s.to_string()) }
}

fn write_hcl(v: &V) -> Result<String, String> {
    let V::Obj(m) = v else { return Ok(hcl_value(v)); };
    let mut out = String::new();
    for (k, v) in m {
        out.push_str(&format!("{} = {}\n\n", json_string(k), hcl_value(v)));
    }
    Ok(out.trim_end().to_string())
}

fn hcl_value(v: &V) -> String {
    match v {
        V::Null => "null".to_string(),
        V::Bool(b) => b.to_string(),
        V::Num(s) => s.clone(),
        V::Str(s) => json_string(s),
        V::Arr(a) => format!("[{}]", a.iter().filter(|x| !matches!(x, V::Null)).map(hcl_value).collect::<Vec<_>>().join(", ")),
        V::Obj(m) => {
            let mut s = String::from("{\n");
            for (idx, (k, v)) in m.iter().enumerate() {
                if idx > 0 { s.push('\n'); }
                s.push_str(&format!("  {} = {}\n", json_string(k), hcl_value(v)));
            }
            s.push('}');
            s
        }
    }
}

fn json_string(s: &str) -> String {
    serde_json::to_string(s).unwrap()
}
