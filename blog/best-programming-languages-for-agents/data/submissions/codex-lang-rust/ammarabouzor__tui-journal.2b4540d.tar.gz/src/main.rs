use clap::{Arg, ArgAction, ArgMatches, Command as ClapCommand};
use serde_json::Value;
use std::fs;
use std::path::{Path, PathBuf};

const DEFAULT_THEME: &str = r##"[general.input_block_active]
fg = "LightYellow"
modifiers = ""

[general.input_block_invalid]
fg = "LightRed"
modifiers = ""

[general.input_corsur_active]
fg = "Black"
bg = "LightYellow"
modifiers = ""

[general.input_corsur_invalid]
fg = "Black"
bg = "LightRed"
modifiers = ""

[general.list_item_selected]
fg = "LightYellow"
modifiers = "BOLD"

[general.list_highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[general.list_highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = ""

[journals_list.block_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.block_inactive]
fg = "#AAAAC8"
modifiers = ""

[journals_list.block_multi_select]
fg = "Yellow"
modifiers = "BOLD | ITALIC"

[journals_list.highlight_active]
fg = "Black"
bg = "LightGreen"
modifiers = "BOLD"

[journals_list.highlight_inactive]
fg = "Black"
bg = "LightBlue"
modifiers = "BOLD"

[journals_list.title_active]
fg = "Reset"
modifiers = "BOLD"

[journals_list.title_inactive]
fg = "#AAAAC8"
modifiers = "BOLD"

[journals_list.title_selected]
fg = "Yellow"
modifiers = "BOLD"

[journals_list.date_priority]
fg = "LightBlue"
modifiers = ""

[journals_list.tags_default]
fg = "LightCyan"
modifiers = "DIM"

[editor.block_insert]
fg = "LightGreen"
modifiers = "BOLD"

[editor.block_visual]
fg = "Blue"
modifiers = "BOLD"

[editor.block_normal_active]
fg = "Reset"
modifiers = "BOLD"

[editor.block_normal_inactive]
fg = "#AAAAC8"
modifiers = ""

[editor.cursor_normal]
fg = "Black"
bg = "White"
modifiers = ""

[editor.cursor_insert]
fg = "Black"
bg = "LightGreen"
modifiers = ""

[editor.cursor_visual]
fg = "Black"
bg = "Blue"
modifiers = ""

[editor.selection_style]
fg = "Black"
bg = "White"
modifiers = ""

[msgbox]
error = "LightRed"
warning = "Yellow"
info = "LightGreen"
question = "LightBlue"
"##;

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
enum BackendType {
    Json,
    Sqlite,
}

#[derive(Clone, Debug)]
struct Config {
    backend_type: BackendType,
    scroll_per_page: i64,
    sync_os_clipboard: bool,
    history_limit: i64,
    colored_tags: bool,
    datum_visibility: String,
    app_state_dir: String,
    export_show_confirmation: bool,
    external_editor_auto_save: bool,
    external_editor_temp_file_extension: String,
    json_file_path: String,
    sqlite_file_path: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            backend_type: BackendType::Sqlite,
            scroll_per_page: 5,
            sync_os_clipboard: false,
            history_limit: 10,
            colored_tags: true,
            datum_visibility: "show".to_string(),
            app_state_dir: "/home/agent/.local/state/tui-journal".to_string(),
            export_show_confirmation: true,
            external_editor_auto_save: false,
            external_editor_temp_file_extension: "txt".to_string(),
            json_file_path: "/home/agent/tui-journal/entries.json".to_string(),
            sqlite_file_path: "/home/agent/tui-journal/entries.db".to_string(),
        }
    }
}

fn main() {
    if std::env::args().skip(1).any(|a| a == "--version" || a == "-V") {
        println!("tui-journal 0.16.1");
        return;
    }
    let matches = cli().get_matches();
    let config_arg = matches.get_one::<String>("config").map(PathBuf::from);
    let mut cfg = load_config(config_arg.as_deref());
    apply_cli_config(&mut cfg, &matches);

    let result = match matches.subcommand() {
        Some(("print-config", _)) => {
            print_config(&cfg);
            Ok(())
        }
        Some(("theme", sub)) => handle_theme(sub, config_arg.as_deref()),
        Some(("import-journals", sub)) => {
            let path = PathBuf::from(sub.get_one::<String>("path").expect("required"));
            import_journals(&cfg, &path)
        }
        Some(("assign-priority", sub)) => {
            let priority = sub.get_one::<u64>("priority").copied().expect("required");
            assign_priority(&cfg, priority)
        }
        None => Err("No such device or address (os error 6)".to_string()),
        _ => Ok(()),
    };

    if let Err(err) = result {
        eprintln!("Error: {err}");
        std::process::exit(1);
    }
}

fn cli() -> ClapCommand {
    ClapCommand::new("executable")
        .version("0.16.1")
        .about("Tui app allows writing and managing journals/notes from within the terminal With different local back-ends")
        .arg(Arg::new("json-file-path").short('j').long("json-file-path").value_name("FILE PATH").help("Sets the entries Json file path and starts using it"))
        .arg(Arg::new("sqlite-file-path").short('s').long("sqlite-file-path").value_name("FILE PATH").help("Sets the entries sqlite file path and starts using it"))
        .arg(Arg::new("backend-type").short('b').long("backend-type").value_name("BACKEND_TYPE").value_parser(["json", "sqlite"]).help("Sets the backend type and starts using it"))
        .arg(Arg::new("config").short('c').long("config").value_name("DIR PATH").help("Specifies the path for the configuration directory.\nConfiguration files is considered as root for themes file too.\nIt still accepts the path for configuration file for backward compatibility.\n(default path: /home/agent/.config/tui-journal)"))
        .arg(Arg::new("verbose").short('v').long("verbose").action(ArgAction::Count).help("Increases logging verbosity each use for up to 3 times"))
        .arg(Arg::new("log").short('l').long("log").value_name("FILE PATH").help("Specifies a file to use for logging\n(default file: /home/agent/.cache/tui-journal/tui-journal.log)"))
        .subcommand(ClapCommand::new("print-config").visible_alias("pc").about("Print the current settings including the paths for the back-end files"))
        .subcommand(ClapCommand::new("import-journals").visible_alias("imj").about("Import journals from the given transfer JSON file to the current back-end file").arg(Arg::new("path").short('p').long("path").required(true).value_name("FILE PATH").help("Path of the JSON file to import from")))
        .subcommand(ClapCommand::new("assign-priority").visible_alias("ap").about("Assign priority for all the entries with empty priority field").arg(Arg::new("priority").required(true).value_name("PRIORITY").value_parser(clap::value_parser!(u64)).help("Priority value (Positive number)")))
        .subcommand(
            ClapCommand::new("theme")
                .visible_alias("style")
                .about("Provides commands regarding changing themes and styles of the app")
                .subcommand_required(true)
                .subcommand(ClapCommand::new("print-path").visible_alias("path").about("Prints the path to the user themes file"))
                .subcommand(ClapCommand::new("print-default").visible_alias("default").about("Dumps the styles with the default values to be used as a reference and base for user custom themes"))
                .subcommand(ClapCommand::new("write-defaults").visible_alias("write").about("Creates user custom themes file if doesn't exist then writes the default styles to it")),
        )
}

fn config_file_from_arg(arg: Option<&Path>) -> Option<PathBuf> {
    let p = arg?;
    if p.is_dir() {
        Some(p.join("config.toml"))
    } else {
        Some(p.to_path_buf())
    }
}

fn load_config(arg: Option<&Path>) -> Config {
    let mut cfg = Config::default();
    let Some(path) = config_file_from_arg(arg) else {
        return cfg;
    };
    let Ok(text) = fs::read_to_string(path) else {
        return cfg;
    };
    let Ok(value) = text.parse::<toml::Value>() else {
        return cfg;
    };

    if let Some(v) = value.get("backend_type").and_then(|v| v.as_str()) {
        cfg.backend_type = if v.eq_ignore_ascii_case("json") {
            BackendType::Json
        } else {
            BackendType::Sqlite
        };
    }
    set_i64(&value, "scroll_per_page", &mut cfg.scroll_per_page);
    set_bool(&value, "sync_os_clipboard", &mut cfg.sync_os_clipboard);
    set_i64(&value, "history_limit", &mut cfg.history_limit);
    set_bool(&value, "colored_tags", &mut cfg.colored_tags);
    set_string(&value, "datum_visibility", &mut cfg.datum_visibility);
    set_string(&value, "app_state_dir", &mut cfg.app_state_dir);
    if let Some(export) = value.get("export") {
        set_bool(export, "show_confirmation", &mut cfg.export_show_confirmation);
    }
    if let Some(editor) = value.get("external_editor") {
        set_bool(editor, "auto_save", &mut cfg.external_editor_auto_save);
        set_string(editor, "temp_file_extension", &mut cfg.external_editor_temp_file_extension);
    }
    if let Some(json) = value.get("json_backend") {
        set_string(json, "file_path", &mut cfg.json_file_path);
    }
    if let Some(sqlite) = value.get("sqlite_backend") {
        set_string(sqlite, "file_path", &mut cfg.sqlite_file_path);
    }
    cfg
}

fn set_string(table: &toml::Value, key: &str, dst: &mut String) {
    if let Some(v) = table.get(key).and_then(|v| v.as_str()) {
        *dst = v.to_string();
    }
}

fn set_i64(table: &toml::Value, key: &str, dst: &mut i64) {
    if let Some(v) = table.get(key).and_then(|v| v.as_integer()) {
        *dst = v;
    }
}

fn set_bool(table: &toml::Value, key: &str, dst: &mut bool) {
    if let Some(v) = table.get(key).and_then(|v| v.as_bool()) {
        *dst = v;
    }
}

fn apply_cli_config(cfg: &mut Config, matches: &ArgMatches) {
    if let Some(path) = matches.get_one::<String>("json-file-path") {
        cfg.json_file_path = path.to_string();
        cfg.backend_type = BackendType::Json;
    }
    if let Some(path) = matches.get_one::<String>("sqlite-file-path") {
        cfg.sqlite_file_path = path.to_string();
        cfg.backend_type = BackendType::Sqlite;
    }
    if let Some(backend) = matches.get_one::<String>("backend-type") {
        cfg.backend_type = if backend == "json" { BackendType::Json } else { BackendType::Sqlite };
    }
}

fn print_config(cfg: &Config) {
    println!("backend_type = \"{}\"", backend_display(cfg.backend_type));
    println!("scroll_per_page = {}", cfg.scroll_per_page);
    println!("sync_os_clipboard = {}", cfg.sync_os_clipboard);
    println!("history_limit = {}", cfg.history_limit);
    println!("colored_tags = {}", cfg.colored_tags);
    println!("datum_visibility = \"{}\"", cfg.datum_visibility);
    println!("app_state_dir = \"{}\"", cfg.app_state_dir);
    println!();
    println!("[export]");
    println!("show_confirmation = {}", cfg.export_show_confirmation);
    println!();
    println!("[external_editor]");
    println!("auto_save = {}", cfg.external_editor_auto_save);
    println!("temp_file_extension = \"{}\"", cfg.external_editor_temp_file_extension);
    println!();
    println!("[json_backend]");
    println!("file_path = \"{}\"", cfg.json_file_path);
    println!();
    println!("[sqlite_backend]");
    println!("file_path = \"{}\"", cfg.sqlite_file_path);
    println!();
}

fn backend_display(backend: BackendType) -> &'static str {
    match backend {
        BackendType::Json => "Json",
        BackendType::Sqlite => "Sqlite",
    }
}

fn theme_path(config: Option<&Path>) -> PathBuf {
    if let Some(p) = config {
        if p.is_dir() {
            return p.join("themes.toml");
        }
        println!("INFO: Custom config directory is ignored in themese because it's not a directory.");
    }
    PathBuf::from("/home/agent/.config/tui-journal/themes.toml")
}

fn handle_theme(sub: &ArgMatches, config: Option<&Path>) -> Result<(), String> {
    match sub.subcommand_name() {
        Some("print-path") => {
            println!("{}", theme_path(config).display());
            Ok(())
        }
        Some("print-default") => {
            print!("{DEFAULT_THEME}");
            Ok(())
        }
        Some("write-defaults") => {
            let path = theme_path(config);
            if let Some(parent) = path.parent() {
                fs::create_dir_all(parent).map_err(|e| e.to_string())?;
            }
            fs::write(&path, DEFAULT_THEME).map_err(|e| e.to_string())?;
            println!("Default themes have been written to {}", path.display());
            Ok(())
        }
        _ => Ok(()),
    }
}

fn backend_path(cfg: &Config) -> &str {
    match cfg.backend_type {
        BackendType::Json => &cfg.json_file_path,
        BackendType::Sqlite => &cfg.sqlite_file_path,
    }
}

fn import_journals(cfg: &Config, source: &Path) -> Result<(), String> {
    if cfg.backend_type == BackendType::Sqlite {
        return Err("No such device or address (os error 6)".to_string());
    }
    let incoming = read_json_value(source)?;
    let backend = Path::new(backend_path(cfg));
    let mut current = read_json_value_or_empty(backend)?;

    match (&mut current, incoming) {
        (Value::Array(dst), Value::Array(src)) => dst.extend(src),
        (Value::Array(dst), item) => dst.push(item),
        (dst, src) => {
            let old = dst.take();
            *dst = Value::Array(vec![old, src]);
        }
    }
    write_json_value(backend, &current)
}

fn assign_priority(cfg: &Config, priority: u64) -> Result<(), String> {
    if cfg.backend_type == BackendType::Sqlite {
        return Err("No such device or address (os error 6)".to_string());
    }
    let path = Path::new(backend_path(cfg));
    let mut value = read_json_value_or_empty(path)?;
    assign_priority_in_value(&mut value, priority);
    write_json_value(path, &value)
}

fn read_json_value(path: &Path) -> Result<Value, String> {
    let text = fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&text).map_err(|e| e.to_string())
}

fn read_json_value_or_empty(path: &Path) -> Result<Value, String> {
    if !path.exists() {
        return Ok(Value::Array(Vec::new()));
    }
    read_json_value(path)
}

fn write_json_value(path: &Path, value: &Value) -> Result<(), String> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    let text = serde_json::to_string_pretty(value).map_err(|e| e.to_string())?;
    fs::write(path, format!("{text}\n")).map_err(|e| e.to_string())
}

fn assign_priority_in_value(value: &mut Value, priority: u64) {
    match value {
        Value::Array(items) => {
            for item in items {
                assign_priority_in_value(item, priority);
            }
        }
        Value::Object(map) => {
            let should_assign = match map.get("priority") {
                None | Some(Value::Null) => true,
                Some(Value::String(s)) if s.is_empty() => true,
                _ => false,
            };
            if should_assign {
                map.insert("priority".to_string(), Value::Number(priority.into()));
            }
        }
        _ => {}
    }
}
