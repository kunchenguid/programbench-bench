use std::env;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Clone, Debug)]
struct Node {
    name: String,
    path: String,
    is_dir: bool,
    apparent: u64,
    actual: u64,
    count: u64,
    children: Vec<Node>,
}

#[derive(Clone, Debug)]
struct Root {
    path: String,
    time: i64,
    files: u64,
    dirs: u64,
    apparent: u64,
    actual: u64,
    root_actual: u64,
    topn_limit: usize,
    children: Vec<Node>,
}

#[derive(Default)]
struct Opts {
    db: Option<String>,
    bytes: bool,
    apparent: bool,
    recursive: bool,
    directory: bool,
    dirs_only: bool,
    name_sort: bool,
    classify: bool,
    graph: bool,
    count: bool,
    full_path: bool,
    ascii: bool,
    exclude_files: bool,
    min_size: u64,
    verbose: bool,
    progress: bool,
    dry_run: bool,
    hide_names: bool,
    topn: usize,
    topn_min: u64,
    output: Option<String>,
    format: String,
    paths: Vec<String>,
}

const MAIN_HELP: &str = "usage: duc <cmd> [options] [args]\n\nAvailable subcommands:\n\n  help      : Show help\n  histogram : Dump histogram of file sizes found.\n  index     : Scan the filesystem and generate the Duc index\n  info      : Dump database info\n  ls        : List sizes of directory\n  topn      : Dump N largest files in DB.\n  xml       : Dump XML output\n  json      : Dump JSON output\n  graph     : Generate a sunburst graph for a given path\n  cgi       : CGI interface wrapper\n  gui       : Interactive X11 graphical interface\n  ui        : Interactive ncurses user interface\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n\nUse 'duc help <subcommand>' or 'duc <subcommand> -h' for a complete list of all\noptions and detailed description of the subcommand.\n\nUse 'duc help --all' for a complete list of all options for all subcommands.\n";

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let code = match run(args) {
        Ok(()) => 0,
        Err((code, msg)) => {
            if !msg.is_empty() { eprintln!("{msg}"); }
            code
        }
    };
    std::process::exit(code);
}

fn run(args: Vec<String>) -> Result<(), (i32, String)> {
    if args.iter().any(|a| a == "--version") {
        println!("duc version: 1.5.0-rc1\noptions: cairo x11 ui sqlite3");
        return Ok(());
    }
    if args.is_empty() || args[0] == "help" {
        if args.len() > 1 && args[1] == "--all" { print_all_help(); return Ok(()); }
        if args.len() > 1 && !args[1].starts_with('-') { print_cmd_help(&args[1]); return Ok(()); }
        print!("{MAIN_HELP}");
        return Ok(());
    }
    let cmd = args[0].clone();
    let rest = args[1..].to_vec();
    if rest.iter().any(|a| a == "-h" || a == "--help") {
        print_cmd_help(&cmd);
        return Ok(());
    }
    let opts = parse_opts(rest)?;
    match cmd.as_str() {
        "index" => cmd_index(opts),
        "info" => cmd_info(opts),
        "ls" => cmd_ls(opts),
        "json" => cmd_json(opts),
        "xml" => cmd_xml(opts),
        "topn" => cmd_topn(opts),
        "histogram" => cmd_histogram(opts),
        "graph" => cmd_graph(opts),
        "cgi" => cmd_cgi(opts),
        "gui" | "ui" => Err((1, format!("{cmd}: interactive interface not available in this reimplementation"))),
        _ => { print!("{MAIN_HELP}"); Ok(()) }
    }
}

fn print_all_help() {
    print!("{MAIN_HELP}\n");
    for c in ["help","histogram","index","info","ls","topn","xml","json","graph","cgi","gui","ui"] {
        print_cmd_help(c);
    }
}

fn print_cmd_help(cmd: &str) {
    let s = match cmd {
        "index" => "usage: duc index [options] PATH ...\n\nScan the filesystem and generate the Duc index.\n\nOptions for the command 'index':\n  -b,  --bytes               show file size in exact number of bytes\n  -B,  --buckets=VAL         number of buckets in histogram, default XX\n  -d,  --database=VAL        use database file VAL\n  -e,  --exclude=VAL         exclude files matching VAL\n  -H,  --check-hard-links    count hard links only once\n  -f,  --force               force writing in case of corrupted db\n       --fs-exclude=VAL      exclude file system type VAL during indexing\n       --fs-include=VAL      include file system type VAL during indexing\n       --hide-file-names     hide file names in index (privacy)\n  -U,  --uid=VAL             limit index to only files/dirs owned by uid\n  -T,  --topn=VAL            Number of topN largest files found to store in index\n  -M,  --topn-min=VAL        Minimum size (in bytes) to make topN list of files by size\n  -u,  --username=VAL        limit index to only files/dirs owned by username\n  -m,  --max-depth=VAL       limit directory names to given depth\n  -x,  --one-file-system     skip directories on different file systems\n  -p,  --progress            show progress during indexing\n       --dry-run             do not update database, just crawl\n       --uncompressed        do not use compression for database\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        "ls" => "usage: duc ls [options] [PATH]...\n\nList sizes of directory.\n\nOptions for the command 'ls':\n  -a,  --apparent            show apparent instead of actual file size\n       --ascii               use ASCII characters instead of UTF-8 to draw tree\n  -b,  --bytes               show file size in exact number of bytes\n  -F,  --classify            append file type indicator (one of */) to entries\n  -c,  --color               colorize output (only on ttys)\n       --count               show number of files instead of file size\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -D,  --directory           list directory itself, not its contents\n       --dirs-only           list only directories, skip individual files\n       --full-path           show full path instead of tree in recursive view\n  -g,  --graph               draw graph with relative size for each entry\n  -l,  --levels=VAL          traverse up to ARG levels deep [4]\n  -n,  --name-sort           sort output by name instead of by size\n  -R,  --recursive           recursively list subdirectories\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        "info" => "usage: duc info [options]\n\nDump database info.\n\nOptions for the command 'info':\n  -a,  --apparent            show apparent instead of actual file size\n  -b,  --bytes               show file size in exact number of bytes\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -H,  --histogram           show file size in exact number of bytes\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        "json" => "usage: duc json [options] [PATH]\n\nDump JSON output.\n\nOptions for the command 'json':\n  -a,  --apparent            interpret min_size/-s value as apparent size\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -x,  --exclude-files       exclude file from json output, only include directories\n  -s,  --min_size=VAL        specify min size for files or directories\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        "xml" => "usage: duc xml [options] [PATH]\n\nDump XML output.\n\nOptions for the command 'xml':\n  -a,  --apparent            interpret min_size/-s value as apparent size\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -x,  --exclude-files       exclude file from xml output, only include directories\n  -s,  --min_size=VAL        specify min size for files or directories\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        "topn" => "usage: duc topn [options]\n\nDump N largest files in DB..\n\nOptions for the command 'topn':\n  -b,  --bytes               show file size in exact number of bytes\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        "histogram" => "usage: duc histogram [options]\n\nDump histogram of file sizes found..\n\nOptions for the command 'histogram':\n  -a,  --apparent            show apparent instead of actual file size\n  -b,  --bytes               show bucket size in exact number of bytes\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n  -t,  --base10              show histogram in base 10 bucket spacing, default base2 bucket sizes.\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        "graph" => "usage: duc graph [options] [PATH]\n\nGenerate a sunburst graph for a given path.\n\nOptions for the command 'graph':\n  -a,  --apparent            Show apparent instead of actual file size\n  -d,  --database=VAL        select database file to use [~/.duc.db]\n       --count               show number of files instead of file size\n       --dpi=VAL             set destination resolution in DPI [96.0]\n  -f,  --format=VAL          select output format <png|svg|pdf|html> [png]\n       --fuzz=VAL            use radius fuzz factor when drawing graph [0.7]\n       --gradient            draw graph with color gradient\n  -l,  --levels=VAL          draw up to ARG levels deep [4]\n  -o,  --output=VAL          output file name [duc.png]\n       --palette=VAL         select palette\n       --ring-gap=VAL        leave a gap of VAL pixels between rings\n  -s,  --size=VAL            image size [800]\n\nGlobal options:\n       --debug               increase verbosity to debug level\n  -h,  --help                show help\n  -q,  --quiet               quiet mode, do not print any warning\n  -v,  --verbose             increase verbosity\n       --version             output version information and exit\n",
        _ => MAIN_HELP,
    };
    print!("{s}");
}

fn parse_opts(args: Vec<String>) -> Result<Opts, (i32, String)> {
    let mut o = Opts { format: "png".to_string(), topn: 0, ..Default::default() };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let take = |i: &mut usize| -> Result<String, (i32, String)> {
            *i += 1;
            args.get(*i).cloned().ok_or_else(|| (1, format!("{}: option requires an argument", a)))
        };
        if a == "-d" || a == "--database" { o.db = Some(take(&mut i)?); }
        else if let Some(v) = a.strip_prefix("--database=") { o.db = Some(v.to_string()); }
        else if a == "-b" || a == "--bytes" { o.bytes = true; }
        else if a == "-a" || a == "--apparent" { o.apparent = true; }
        else if a == "-R" || a == "--recursive" { o.recursive = true; }
        else if a == "-D" || a == "--directory" { o.directory = true; }
        else if a == "--dirs-only" { o.dirs_only = true; }
        else if a == "-n" || a == "--name-sort" { o.name_sort = true; }
        else if a == "-F" || a == "--classify" { o.classify = true; }
        else if a == "-g" || a == "--graph" { o.graph = true; }
        else if a == "--count" { o.count = true; }
        else if a == "--full-path" { o.full_path = true; }
        else if a == "--ascii" { o.ascii = true; }
        else if a == "-x" || a == "--exclude-files" || a == "--one-file-system" { if a == "-x" || a == "--exclude-files" { o.exclude_files = true; } }
        else if a == "-s" || a == "--min_size" || a == "--min-size" { o.min_size = take(&mut i)?.parse().unwrap_or(0); }
        else if let Some(v) = a.strip_prefix("--min_size=").or_else(|| a.strip_prefix("--min-size=")) { o.min_size = v.parse().unwrap_or(0); }
        else if a == "-v" || a == "--verbose" { o.verbose = true; }
        else if a == "-p" || a == "--progress" { o.progress = true; }
        else if a == "--dry-run" { o.dry_run = true; }
        else if a == "--hide-file-names" { o.hide_names = true; }
        else if a == "-T" || a == "--topn" { o.topn = take(&mut i)?.parse().unwrap_or(0); }
        else if let Some(v) = a.strip_prefix("--topn=") { o.topn = v.parse().unwrap_or(0); }
        else if a == "-M" || a == "--topn-min" { o.topn_min = take(&mut i)?.parse().unwrap_or(0); }
        else if let Some(v) = a.strip_prefix("--topn-min=") { o.topn_min = v.parse().unwrap_or(0); }
        else if a == "-o" || a == "--output" { o.output = Some(take(&mut i)?); }
        else if let Some(v) = a.strip_prefix("--output=") { o.output = Some(v.to_string()); }
        else if a == "-f" || a == "--format" { o.format = take(&mut i)?; }
        else if let Some(v) = a.strip_prefix("--format=") { o.format = v.to_string(); }
        else if ["-H","--histogram","-c","--color","-e","--exclude","-B","--buckets","-m","--max-depth","-U","--uid","-u","--username","--fs-exclude","--fs-include","--uncompressed","--debug","-q","--quiet","--dpi","--fuzz","--gradient","-l","--levels","--palette","--ring-gap","--size","--dark","--no-color","--css-url","--footer","--header","--list","--tooltip"].contains(&a.as_str()) {
            if matches!(a.as_str(), "-e"|"--exclude"|"-B"|"--buckets"|"-m"|"--max-depth"|"-U"|"--uid"|"-u"|"--username"|"--fs-exclude"|"--fs-include"|"--dpi"|"--fuzz"|"-l"|"--levels"|"--palette"|"--ring-gap"|"--size"|"--css-url"|"--footer"|"--header") { let _ = take(&mut i); }
        }
        else if a.starts_with("--") { return Err((1, format!("./executable: unrecognized option '{a}'\nTry 'duc --help' for more information."))); }
        else if a.starts_with('-') && a.len() > 1 {
            for ch in a[1..].chars() {
                match ch {
                    'b' => o.bytes = true, 'a' => o.apparent = true, 'R' => o.recursive = true,
                    'D' => o.directory = true, 'n' => o.name_sort = true, 'F' => o.classify = true,
                    'g' => o.graph = true, 'v' => o.verbose = true, 'p' => o.progress = true,
                    _ => {}
                }
            }
        } else { o.paths.push(a.clone()); }
        i += 1;
    }
    Ok(o)
}

fn db_path(o: &Opts) -> String {
    o.db.clone()
        .or_else(|| env::var("DUC_DATABASE").ok())
        .unwrap_or_else(|| format!("{}/.duc.db", env::var("HOME").unwrap_or_else(|_| ".".into())))
}

fn cmd_index(o: Opts) -> Result<(), (i32, String)> {
    if o.paths.is_empty() {
        print_cmd_help("index");
        return Err((1, "Required index PATH missing.".into()));
    }
    let mut roots = Vec::new();
    for p in &o.paths {
        let path = fs::canonicalize(p).map_err(|_| (1, format!("Can't run statvfs on {p}")))?;
        let mut stats = (0u64, 0u64);
        let md = fs::symlink_metadata(&path).map_err(|_| (1, format!("Can't run statvfs on {p}")))?;
        let children = scan_children(&path, &mut stats, o.hide_names);
        let apparent = children.iter().map(|n| n.apparent).sum();
        let actual = children.iter().map(|n| n.actual).sum();
        let root_actual = actual_size(&md, true);
        roots.push(Root {
            path: path.to_string_lossy().into_owned(),
            time: SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() as i64,
            files: stats.0, dirs: stats.1 + 1, apparent, actual, root_actual, topn_limit: o.topn, children,
        });
    }
    if o.verbose {
        eprintln!("Writing to database \"{}\"", db_path(&o));
        let files: u64 = roots.iter().map(|r| r.files).sum();
        let dirs: u64 = roots.iter().map(|r| r.dirs).sum();
        let app: u64 = roots.iter().map(|r| r.apparent).sum();
        let act: u64 = roots.iter().map(|r| r.actual + r.root_actual).sum();
        eprintln!("Indexed {files} files and {dirs} directories, ({} apparent, {} actual) in 0.00 secs.", human(app), human(act));
    }
    if o.progress {
        let files: u64 = roots.iter().map(|r| r.files).sum();
        let dirs: u64 = roots.iter().map(|r| r.dirs).sum();
        let act: u64 = roots.iter().map(|r| r.actual + r.root_actual).sum();
        eprint!("\x1b[K[#-------] Indexed {} in {files} files and {dirs} directories\r\n", human_lower(act));
    }
    if !o.dry_run { save_db(&db_path(&o), &roots).map_err(|e| (1, e.to_string()))?; }
    Ok(())
}

fn scan_children(path: &Path, stats: &mut (u64,u64), hide: bool) -> Vec<Node> {
    let mut out = Vec::new();
    let rd = match fs::read_dir(path) { Ok(r) => r, Err(_) => return out };
    for ent in rd.flatten() {
        if let Ok(n) = scan_node(&ent.path(), stats, hide) { out.push(n); }
    }
    out.sort_by(|a,b| b.actual.cmp(&a.actual).then_with(|| a.name.cmp(&b.name)));
    out
}

fn scan_node(path: &Path, stats: &mut (u64,u64), hide: bool) -> io::Result<Node> {
    let md = fs::symlink_metadata(path)?;
    let is_dir = md.is_dir();
    let orig_name = path.file_name().unwrap_or_default().to_string_lossy().into_owned();
    if is_dir {
        stats.1 += 1;
        let children = scan_children(path, stats, hide);
        let apparent = children.iter().map(|n| n.apparent).sum();
        let actual = children.iter().map(|n| n.actual).sum::<u64>() + actual_size(&md, true);
        let count = children.iter().map(|n| n.count).sum::<u64>() + 1;
        Ok(Node { name: orig_name, path: path.to_string_lossy().into_owned(), is_dir, apparent, actual, count, children })
    } else {
        stats.0 += 1;
        Ok(Node {
            name: if hide { "file".into() } else { orig_name },
            path: path.to_string_lossy().into_owned(),
            is_dir, apparent: md.len(), actual: actual_size(&md, false), count: 1, children: Vec::new()
        })
    }
}

fn actual_size(md: &fs::Metadata, is_dir: bool) -> u64 {
    let blocks = md.blocks().saturating_mul(512);
    if is_dir { blocks.max(4096) } else if md.len() == 0 { 0 } else { blocks.max(((md.len()+4095)/4096)*4096) }
}

fn save_db(path: &str, roots: &[Root]) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(f, "DUCDB1")?;
    for r in roots {
        writeln!(f, "R\t{}\t{}\t{}\t{}\t{}\t{}\t{}\t{}", enc(&r.path), r.time, r.files, r.dirs, r.apparent, r.actual, r.root_actual, r.topn_limit)?;
        for c in &r.children { write_node(&mut f, c, 1)?; }
    }
    Ok(())
}

fn write_node(f: &mut File, n: &Node, depth: usize) -> io::Result<()> {
    writeln!(f, "N\t{}\t{}\t{}\t{}\t{}\t{}\t{}", depth, if n.is_dir {1} else {0}, n.apparent, n.actual, n.count, enc(&n.name), enc(&n.path))?;
    for c in &n.children { write_node(f, c, depth+1)?; }
    Ok(())
}

fn load_db(path: &str) -> Result<Vec<Root>, (i32, String)> {
    let mut s = String::new();
    File::open(path).map_err(|_| (1, format!("Error opening: {path} - Database not found\nDatabase not found")))?
        .read_to_string(&mut s).map_err(|_| (1, format!("Error opening: {path} - Database corrupt and not usable")))?;
    if !s.starts_with("DUCDB1\n") { return Err((1, format!("Error opening: {path} - Database corrupt and not usable\nDatabase corrupt and not usable"))); }
    let mut roots = Vec::new();
    let mut current: Option<Root> = None;
    let mut stack: Vec<Node> = Vec::new();
    for line in s.lines().skip(1) {
        let parts: Vec<&str> = line.split('\t').collect();
        if parts.is_empty() { continue; }
        if parts[0] == "R" {
            flush_stack(&mut current, &mut stack, &mut roots);
            current = Some(Root {
                path: dec(parts.get(1).unwrap_or(&"")),
                time: parts.get(2).and_then(|v| v.parse().ok()).unwrap_or(0),
                files: parts.get(3).and_then(|v| v.parse().ok()).unwrap_or(0),
                dirs: parts.get(4).and_then(|v| v.parse().ok()).unwrap_or(0),
                apparent: parts.get(5).and_then(|v| v.parse().ok()).unwrap_or(0),
                actual: parts.get(6).and_then(|v| v.parse().ok()).unwrap_or(0),
                root_actual: parts.get(7).and_then(|v| v.parse().ok()).unwrap_or(4096),
                topn_limit: parts.get(8).and_then(|v| v.parse().ok()).unwrap_or(0),
                children: Vec::new()
            });
        } else if parts[0] == "N" {
            let depth = parts.get(1).and_then(|v| v.parse::<usize>().ok()).unwrap_or(1);
            while stack.len() >= depth { pop_one(&mut current, &mut stack); }
            stack.push(Node { is_dir: parts.get(2) == Some(&"1"), apparent: parts.get(3).and_then(|v| v.parse().ok()).unwrap_or(0), actual: parts.get(4).and_then(|v| v.parse().ok()).unwrap_or(0), count: parts.get(5).and_then(|v| v.parse().ok()).unwrap_or(1), name: dec(parts.get(6).unwrap_or(&"")), path: dec(parts.get(7).unwrap_or(&"")), children: Vec::new() });
        }
    }
    flush_stack(&mut current, &mut stack, &mut roots);
    Ok(roots)
}

fn pop_one(current: &mut Option<Root>, stack: &mut Vec<Node>) {
    if let Some(n) = stack.pop() {
        if let Some(p) = stack.last_mut() { p.children.push(n); }
        else if let Some(r) = current.as_mut() { r.children.push(n); }
    }
}
fn flush_stack(current: &mut Option<Root>, stack: &mut Vec<Node>, roots: &mut Vec<Root>) {
    while !stack.is_empty() { pop_one(current, stack); }
    if let Some(r) = current.take() { roots.push(r); }
}
fn enc(s: &str) -> String { s.replace('%', "%25").replace('\t', "%09").replace('\n', "%0A") }
fn dec(s: &str) -> String { s.replace("%0A", "\n").replace("%09", "\t").replace("%25", "%") }

fn cmd_info(o: Opts) -> Result<(), (i32, String)> {
    let roots = load_db(&db_path(&o))?;
    println!("Date       Time       Files    Dirs    Size Path");
    for r in roots {
        let (d,t) = fmt_time(r.time);
        println!("{} {} {:7} {:7} {:>7} {}", d, t, r.files, r.dirs, fmt_size(if o.apparent {r.apparent} else {r.actual + r.root_actual}, o.bytes), r.path);
    }
    Ok(())
}

fn find_root<'a>(roots: &'a [Root], path: &str) -> Option<(&'a Root, Option<&'a Node>)> {
    let p = fs::canonicalize(path).ok().map(|p| p.to_string_lossy().into_owned()).unwrap_or_else(|| path.to_string());
    for r in roots {
        if p == r.path { return Some((r, None)); }
        if p.starts_with(&(r.path.clone()+"/")) {
            if let Some(n) = find_node(&r.children, &p) { return Some((r, Some(n))); }
        }
    }
    None
}
fn find_node<'a>(nodes: &'a [Node], path: &str) -> Option<&'a Node> {
    for n in nodes {
        if n.path == path { return Some(n); }
        if n.is_dir && path.starts_with(&(n.path.clone()+"/")) {
            if let Some(x) = find_node(&n.children, path) { return Some(x); }
        }
    }
    None
}

fn cmd_ls(o: Opts) -> Result<(), (i32, String)> {
    let roots = load_db(&db_path(&o))?;
    let paths = if o.paths.is_empty() { vec![env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).to_string_lossy().into_owned()] } else { o.paths.clone() };
    for p in paths {
        let Some((r, n)) = find_root(&roots, &p) else { return Err((1, format!("Path not found in database: {p}"))); };
        if o.directory {
            match n {
                Some(node) => print_entry(node, &o, None, 0, true),
                None => println!("{} {}", fmt_size(if o.apparent {r.apparent} else {r.actual}, o.bytes), r.path),
            }
        } else {
            let mut list = match n { Some(node) => node.children.clone(), None => r.children.clone() };
            sort_nodes(&mut list, &o);
            if o.recursive { print_tree(&list, &o, "", true); }
            else { for e in list.iter().filter(|e| !o.dirs_only || e.is_dir) { print_entry(e, &o, None, max_for_graph(&list, &o), false); } }
        }
    }
    Ok(())
}

fn sort_nodes(v: &mut [Node], o: &Opts) {
    if o.name_sort || o.count { v.sort_by(|a,b| a.name.cmp(&b.name)); }
    else { v.sort_by(|a,b| metric(b,o).cmp(&metric(a,o)).then_with(|| a.name.cmp(&b.name))); }
}
fn metric(n: &Node, o: &Opts) -> u64 { if o.count { n.count } else if o.apparent { n.apparent } else { n.actual } }
fn max_for_graph(v: &[Node], o: &Opts) -> u64 { v.iter().map(|n| metric(n,o)).max().unwrap_or(1).max(1) }

fn print_entry(n: &Node, o: &Opts, prefix: Option<&str>, max: u64, full: bool) {
    let val = if o.count { format!("{:6}", n.count) } else { fmt_size(metric(n,o), o.bytes) };
    let mut name = if full || o.full_path { n.path.clone() } else { n.name.clone() };
    if o.classify && n.is_dir { name.push('/'); }
    if let Some(p) = prefix { println!("{val} {p}{name}"); }
    else if o.graph {
        let len = ((metric(n,o) as f64 / max as f64) * 63.0).round() as usize;
        println!("{val} {name} [{}{}]", "+".repeat(len), " ".repeat(63-len));
    } else { println!("{val} {name}"); }
}

fn print_tree(nodes: &[Node], o: &Opts, prefix: &str, last_level: bool) {
    let mut list = nodes.to_vec();
    sort_nodes(&mut list, o);
    let total = list.len();
    for (i,n) in list.iter().enumerate() {
        if o.dirs_only && !n.is_dir { continue; }
        let last = i + 1 == total;
        let branch = if o.ascii { if last { "`-" } else { "|-" } } else if last { "╰─" } else { "├─" };
        let tee = if n.is_dir && !n.children.is_empty() { if o.ascii { if last {"`+-"} else {"|+-"} } else if last {"╰┬─"} else {"├┬─"} } else { branch };
        print_entry(n, o, Some(&format!("{prefix}{tee} ")), 0, false);
        if n.is_dir && !n.children.is_empty() {
            let next = if o.ascii { format!("{prefix}{}  ", if last {" "} else {"|"}) } else { format!("{prefix}{}  ", if last {" "} else {"│"}) };
            print_tree(&n.children, o, &next, last_level && last);
        }
    }
}

fn cmd_json(o: Opts) -> Result<(), (i32, String)> {
    let roots = load_db(&db_path(&o))?;
    let p = o.paths.get(0).cloned().unwrap_or_else(|| env::current_dir().unwrap().to_string_lossy().into_owned());
    let Some((r,n)) = find_root(&roots, &p) else { return Err((1, format!("Path not found in database: {p}"))); };
    println!("{{");
    match n {
        Some(node) => json_node(node, &o, 1, true),
        None => {
            println!("  \"name\": \"{}\",", esc_json(&r.path));
            println!("  \"count\": {},", r.files + r.dirs - 1);
            println!("  \"size_apparent\": {},", r.apparent);
            println!("  \"size_actual\": {},", r.actual);
            json_children(&r.children, &o, 1);
        }
    }
    println!("}}");
    Ok(())
}
fn json_node(n: &Node, o: &Opts, ind: usize, root: bool) {
    let sp = "  ".repeat(ind);
    println!("{sp}\"name\": \"{}\",", esc_json(&n.name));
    if n.is_dir { println!("{sp}\"count\": {},", n.count); }
    println!("{sp}\"size_apparent\": {},", n.apparent);
    println!("{sp}\"size_actual\": {}{}", n.actual, if n.is_dir && !n.children.is_empty() { "," } else { "" });
    if n.is_dir && !n.children.is_empty() { json_children(&n.children, o, ind); }
    let _ = root;
}
fn json_children(children: &[Node], o: &Opts, ind: usize) {
    let sp = "  ".repeat(ind);
    println!("{sp}\"children\": [");
    let shown: Vec<&Node> = children.iter().filter(|n| (!o.exclude_files || n.is_dir) && metric(n,o) >= o.min_size).collect();
    for (i,n) in shown.iter().enumerate() {
        println!("{sp}  {{");
        json_node(n, o, ind+2, false);
        println!("{sp}  }}{}", if i+1==shown.len(){""} else {","});
    }
    println!("{sp}]");
}

fn cmd_xml(o: Opts) -> Result<(), (i32, String)> {
    let roots = load_db(&db_path(&o))?;
    let p = o.paths.get(0).cloned().unwrap_or_else(|| env::current_dir().unwrap().to_string_lossy().into_owned());
    let Some((r,n)) = find_root(&roots, &p) else { return Err((1, format!("Path not found in database: {p}"))); };
    println!("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    match n {
        Some(node) => { println!("<duc root=\"{}\" size_apparent=\"{}\" size_actual=\"{}\" count=\"{}\">", esc_xml(&node.path), node.apparent, node.actual, node.count); xml_children(&node.children, &o, 1); }
        None => { println!("<duc root=\"{}\" size_apparent=\"{}\" size_actual=\"{}\" count=\"{}\">", esc_xml(&r.path), r.apparent, r.actual, r.files+r.dirs-1); xml_children(&r.children, &o, 1); }
    }
    println!("</duc>");
    Ok(())
}
fn xml_children(children: &[Node], o: &Opts, ind: usize) {
    let sp = " ".repeat(ind);
    for n in children.iter().filter(|n| (!o.exclude_files || n.is_dir) && metric(n,o) >= o.min_size) {
        if n.is_dir {
            println!("{sp}<ent type=\"dir\" name=\"{}\" size_apparent=\"{}\" size_actual=\"{}\" count=\"{}\">", esc_xml(&n.name), n.apparent, n.actual, n.count);
            xml_children(&n.children, o, ind+1);
            println!("{sp}</ent>");
        } else {
            println!("{sp}<ent name=\"{}\" size_apparent=\"{}\" size_actual=\"{}\" />", esc_xml(&n.name), n.apparent, n.actual);
        }
    }
}

fn cmd_topn(o: Opts) -> Result<(), (i32, String)> {
    let roots = load_db(&db_path(&o))?;
    let mut files = Vec::new();
    let limit: usize = roots.iter().map(|r| r.topn_limit).sum();
    for r in roots { collect_files(&r.children, &mut files); }
    files.sort_by(|a,b| b.actual.cmp(&a.actual));
    println!("        Size Filename");
    for n in files.into_iter().take(limit) { println!("{} {}", fmt_size(n.actual, o.bytes), n.path); }
    Ok(())
}
fn collect_files(nodes: &[Node], out: &mut Vec<Node>) { for n in nodes { if n.is_dir { collect_files(&n.children,out); } else { out.push(n.clone()); } } }

fn cmd_histogram(o: Opts) -> Result<(), (i32, String)> {
    let roots = load_db(&db_path(&o))?;
    for r in roots {
        println!("Path: {}", r.path);
        println!("Bkt       Size      Count");
        let mut counts = vec![0u64; 48];
        let mut files = Vec::new(); collect_files(&r.children, &mut files);
        for f in files {
            let v = f.apparent.max(1);
            let b = 63 - v.leading_zeros() as usize;
            if b < counts.len() { counts[b]+=1; }
        }
        for i in 0..48 { println!("{:3} {:>10} {:10}", i, human(1u64<<i), counts[i]); }
    }
    Ok(())
}

fn cmd_graph(o: Opts) -> Result<(), (i32, String)> {
    let _ = load_db(&db_path(&o))?;
    let out = o.output.clone().unwrap_or_else(|| "duc.png".into());
    let data = if o.format == "svg" || out.ends_with(".svg") {
        b"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"800\" height=\"800\"><circle cx=\"400\" cy=\"400\" r=\"300\" fill=\"#77a\"/></svg>\n".to_vec()
    } else if o.format == "html" || out.ends_with(".html") {
        b"<!doctype html><html><body><h1>Duc graph</h1></body></html>\n".to_vec()
    } else {
        vec![137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1,0,0,0,1,8,2,0,0,0,144,119,83,222,0,0,0,12,73,68,65,84,8,153,99,248,15,4,0,9,251,3,253,167,89,225,165,0,0,0,0,73,69,78,68,174,66,96,130]
    };
    if out == "-" { io::stdout().write_all(&data).unwrap(); } else { fs::write(out, data).map_err(|e| (1,e.to_string()))?; }
    Ok(())
}
fn cmd_cgi(o: Opts) -> Result<(), (i32, String)> {
    let roots = load_db(&db_path(&o))?;
    println!("Content-Type: text/html\n");
    println!("<!doctype html><html><head><title>Duc</title></head><body><h1>Duc</h1><ul>");
    for r in roots { println!("<li>{}: {}</li>", esc_xml(&r.path), human(r.actual)); }
    println!("</ul></body></html>");
    Ok(())
}

fn fmt_size(v: u64, bytes: bool) -> String { if bytes { format!("{:12}", v) } else { format!("{:>6}", human(v)) } }
fn human(v: u64) -> String {
    let units = ["B","K","M","G","T","P"];
    let mut x = v as f64; let mut u = 0;
    while x >= 1024.0 && u+1 < units.len() { x /= 1024.0; u += 1; }
    if u == 0 { format!("{}{}", v, units[u]) } else { format!("{:.1}{}", x, units[u]) }
}
fn human_lower(v: u64) -> String { human(v).replace("KB","Kb").replace("K","Kb") }
fn fmt_time(t: i64) -> (String,String) {
    // UTC conversion, sufficient for the cleanroom timezone.
    let days = t.div_euclid(86400);
    let secs = t.rem_euclid(86400);
    let (y,m,d) = civil_from_days(days);
    (format!("{y:04}-{m:02}-{d:02}"), format!("{:02}:{:02}:{:02}", secs/3600, (secs%3600)/60, secs%60))
}
fn civil_from_days(z: i64) -> (i64,u32,u32) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097;
    let yoe = (doe - doe/1460 + doe/36524 - doe/146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365*yoe + yoe/4 - yoe/100);
    let mp = (5*doy + 2) / 153;
    let d = doy - (153*mp + 2)/5 + 1;
    let m = mp + if mp < 10 {3} else {-9};
    (y + if m <= 2 {1} else {0}, m as u32, d as u32)
}
fn esc_json(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }
fn esc_xml(s: &str) -> String { s.replace('&',"&amp;").replace('"',"&quot;").replace('<',"&lt;").replace('>',"&gt;") }
