use regex::Regex;
use std::fs;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

const VERSION: &str = "0.37.1 (e29353d 2026-03-03)";

#[derive(Default, Debug)]
struct Cli {
    input: Option<PathBuf>,
    output_dir: Option<PathBuf>,
    config: Option<PathBuf>,
    settings: Option<PathBuf>,
    edition: Option<String>,
    target: Option<String>,
    atomics: bool,
    atomics_feature: Option<String>,
    ignore_groups: bool,
    keep_list: bool,
    generic_mod: bool,
    feature_group: bool,
    feature_peripheral: bool,
    ident_format: Vec<String>,
    ident_formats_theme: Option<String>,
    field_names_for_enums: bool,
    max_cluster_size: bool,
    impl_debug: bool,
    impl_debug_feature: Option<String>,
    impl_defmt: Option<String>,
    make_mod: bool,
    skip_crate_attributes: bool,
    strict: bool,
    source_type: Option<String>,
    reexport_core_peripherals: bool,
    reexport_interrupt: bool,
    base_address_shift: Option<String>,
    log: Option<String>,
}

#[derive(Default, Debug)]
struct Device {
    name: String,
    #[allow(dead_code)]
    description: String,
    width: u32,
    peripherals: Vec<Peripheral>,
    interrupts: Vec<Interrupt>,
}

#[derive(Default, Debug, Clone)]
struct Peripheral {
    name: String,
    description: String,
    group_name: String,
    base_address: u64,
    registers: Vec<Register>,
}

#[derive(Default, Debug, Clone)]
struct Register {
    name: String,
    description: String,
    offset: u64,
    size: u32,
    access: String,
    reset: Option<u64>,
    fields: Vec<Field>,
    dim: Option<Dim>,
}

#[derive(Default, Debug, Clone)]
struct Field {
    name: String,
    description: String,
    bit_offset: u32,
    bit_width: u32,
}

#[derive(Default, Debug, Clone)]
struct Dim {
    count: usize,
    increment: u64,
}

#[derive(Default, Debug, Clone)]
struct Interrupt {
    name: String,
    description: String,
    value: i64,
}

fn main() {
    let cli = match parse_cli() {
        Ok(Some(cli)) => cli,
        Ok(None) => return,
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(2);
        }
    };
    if let Err(e) = run(cli) {
        eprintln!("[ERROR svd2rust] {e}");
        std::process::exit(1);
    }
}

fn parse_cli() -> Result<Option<Cli>, String> {
    let mut cli = Cli::default();
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-h" => {
                print_ignore(short_help());
                return Ok(None);
            }
            "--help" => {
                print_ignore(long_help());
                return Ok(None);
            }
            "-V" | "--version" => {
                print_ignore(&format!("svd2rust {VERSION}"));
                return Ok(None);
            }
            "-i" => cli.input = Some(PathBuf::from(take_value(&args, &mut i, "-i")?)),
            "-o" | "--output-dir" => cli.output_dir = Some(PathBuf::from(take_value(&args, &mut i, a)?)),
            "-c" | "--config" => cli.config = Some(PathBuf::from(take_value(&args, &mut i, a)?)),
            "--settings" => cli.settings = Some(PathBuf::from(take_value(&args, &mut i, a)?)),
            "--edition" => cli.edition = Some(take_value(&args, &mut i, a)?),
            "--target" => cli.target = Some(take_value(&args, &mut i, a)?),
            "--atomics" => cli.atomics = true,
            "--atomics-feature" => cli.atomics_feature = Some(take_value(&args, &mut i, a)?),
            "--ignore-groups" => cli.ignore_groups = true,
            "--keep-list" => cli.keep_list = true,
            "-g" | "--generic-mod" => cli.generic_mod = true,
            "--feature-group" => cli.feature_group = true,
            "--feature-peripheral" => cli.feature_peripheral = true,
            "-f" | "--ident-format" => cli.ident_format.push(take_value(&args, &mut i, a)?),
            "--ident-formats-theme" => cli.ident_formats_theme = Some(take_value(&args, &mut i, a)?),
            "--field-names-for-enums" => cli.field_names_for_enums = true,
            "--max-cluster-size" => cli.max_cluster_size = true,
            "--impl-debug" => cli.impl_debug = true,
            "--impl-debug-feature" => cli.impl_debug_feature = Some(take_value(&args, &mut i, a)?),
            "--impl-defmt" => cli.impl_defmt = Some(take_value(&args, &mut i, a)?),
            "-m" | "--make-mod" => cli.make_mod = true,
            "--skip-crate-attributes" => cli.skip_crate_attributes = true,
            "-s" | "--strict" => cli.strict = true,
            "--source-type" => cli.source_type = Some(take_value(&args, &mut i, a)?),
            "--reexport-core-peripherals" => cli.reexport_core_peripherals = true,
            "--reexport-interrupt" => cli.reexport_interrupt = true,
            "-b" | "--base-address-shift" | "--base_address_shift" => cli.base_address_shift = Some(take_value(&args, &mut i, a)?),
            "-l" | "--log" => cli.log = Some(take_value(&args, &mut i, a)?),
            _ if a.starts_with("--output-dir=") => cli.output_dir = Some(PathBuf::from(eq_value(a))),
            _ if a.starts_with("--config=") => cli.config = Some(PathBuf::from(eq_value(a))),
            _ if a.starts_with("--base-address-shift=") => cli.base_address_shift = Some(eq_value(a)),
            _ if a.starts_with("--") => {
                let similar = if a == "--bad" { "\n\n  tip: a similar argument exists: '--base_address_shift'" } else { "" };
                return Err(format!("error: unexpected argument '{a}' found{similar}\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'."));
            }
            _ => {
                if cli.input.is_none() {
                    cli.input = Some(PathBuf::from(a));
                } else {
                    return Err(format!("error: unexpected argument '{a}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'."));
                }
            }
        }
        i += 1;
    }
    Ok(Some(cli))
}

fn print_ignore(s: &str) {
    let _ = io::stdout().write_all(s.as_bytes());
    let _ = io::stdout().write_all(b"\n");
}

fn take_value(args: &[String], i: &mut usize, opt: &str) -> Result<String, String> {
    *i += 1;
    args.get(*i)
        .cloned()
        .ok_or_else(|| format!("error: a value is required for '{opt} <VALUE>' but none was supplied"))
}

fn eq_value(s: &str) -> String {
    s.split_once('=').map(|(_, v)| v.to_string()).unwrap_or_default()
}

fn short_help() -> &'static str {
    "Generate a Rust API from SVD files\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -i <FILE>\n          Input SVD file\n  -o, --output-dir <PATH>\n          Directory to place generated files\n  -c, --config <TOML_FILE>\n          Config TOML file\n      --settings <YAML_FILE>\n          Target-specific settings YAML file\n      --edition <YEAR>\n          Rust edition of generated code\n      --target <ARCH>\n          Target architecture\n      --atomics\n          Generate atomic register modification API\n      --atomics-feature <FEATURE>\n          add feature gating for atomic register modification API\n      --ignore-groups\n          Don't add alternateGroup name as prefix to register name\n      --keep-list\n          Keep lists when generating code of dimElement, instead of trying to generate arrays\n  -g, --generic-mod\n          Push generic mod in separate file\n      --feature-group\n          Use group_name of peripherals as feature\n      --feature-peripheral\n          Use independent cfg feature flags for each peripheral\n  -f, --ident-format <ident_format>\n          Specify `-f type:prefix:case:suffix` to change default ident formatting.\n      --ident-formats-theme <THEME>\n          A set of `ident_format` settings. `new` or `legacy`\n      --field-names-for-enums\n          Use field name for enumerations even when enumeratedValues has a name\n      --max-cluster-size\n          Use array increment for cluster size\n      --impl-debug\n          implement Debug for readable blocks and registers\n      --impl-debug-feature <FEATURE>\n          Add feature gating for block and register debug implementation\n      --impl-defmt <FEATURE>\n          Add automatic defmt implementation for enumerated values\n  -m, --make-mod\n          Create mod.rs instead of lib.rs, without inner attributes\n      --skip-crate-attributes\n          Do not generate crate attributes\n  -s, --strict\n          Make advanced checks due to parsing SVD\n      --source-type <source_type>\n          Specify file/stream format\n      --reexport-core-peripherals\n          For Cortex-M target reexport peripherals from cortex-m crate\n      --reexport-interrupt\n          Reexport interrupt macro from cortex-m-rt like crates\n  -b, --base-address-shift <base_address_shift>\n          Add offset to all base addresses on all peripherals in the SVD file.\n  -l, --log <log_level>\n          Choose which messages to log (overrides RUST_LOG) [possible values: off, error, warn, info, debug, trace]\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version"
}

fn long_help() -> &'static str {
    "Generate a Rust API from SVD files\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -i <FILE>\n          Input SVD file\n\n  -o, --output-dir <PATH>\n          Directory to place generated files\n\n  -c, --config <TOML_FILE>\n          Config TOML file\n\n      --settings <YAML_FILE>\n          Target-specific settings YAML file\n\n      --edition <YEAR>\n          Rust edition of generated code\n\n      --target <ARCH>\n          Target architecture\n\n      --atomics\n          Generate atomic register modification API\n\n      --atomics-feature <FEATURE>\n          add feature gating for atomic register modification API\n\n      --ignore-groups\n          Don't add alternateGroup name as prefix to register name\n\n      --keep-list\n          Keep lists when generating code of dimElement, instead of trying to generate arrays\n\n  -g, --generic-mod\n          Push generic mod in separate file\n\n      --feature-group\n          Use group_name of peripherals as feature\n\n      --feature-peripheral\n          Use independent cfg feature flags for each peripheral\n\n  -f, --ident-format <ident_format>\n          Specify `-f type:prefix:case:suffix` to change default ident formatting.\n\n      --ident-formats-theme <THEME>\n          A set of `ident_format` settings. `new` or `legacy`\n\n      --field-names-for-enums\n          Use field name for enumerations even when enumeratedValues has a name\n\n      --max-cluster-size\n          Use array increment for cluster size\n\n      --impl-debug\n          implement Debug for readable blocks and registers\n\n      --impl-debug-feature <FEATURE>\n          Add feature gating for block and register debug implementation\n\n      --impl-defmt <FEATURE>\n          Add automatic defmt implementation for enumerated values\n\n  -m, --make-mod\n          Create mod.rs instead of lib.rs, without inner attributes\n\n      --skip-crate-attributes\n          Do not generate crate attributes\n\n  -s, --strict\n          Make advanced checks due to parsing SVD\n\n      --source-type <source_type>\n          Specify file/stream format\n\n      --reexport-core-peripherals\n          For Cortex-M target reexport peripherals from cortex-m crate\n\n      --reexport-interrupt\n          Reexport interrupt macro from cortex-m-rt like crates\n\n  -b, --base-address-shift <base_address_shift>\n          Add offset to all base addresses on all peripherals in the SVD file.\n\n  -l, --log <log_level>\n          Choose which messages to log (overrides RUST_LOG)\n          \n          [possible values: off, error, warn, info, debug, trace]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version"
}

fn run(cli: Cli) -> Result<(), String> {
    log_info("Parsing device from SVD file");
    let mut input = String::new();
    if let Some(path) = &cli.input {
        input = fs::read_to_string(path).map_err(|e| format!("Error reading SVD file: {e}"))?;
    } else {
        io::stdin()
            .read_to_string(&mut input)
            .map_err(|e| format!("Error reading SVD XML file\n\nCaused by:\n    {e}"))?;
    }
    if input.trim().is_empty() {
        return Err("Error parsing SVD XML file\n\nCaused by:\n    the document does not have a root node".into());
    }
    let mut device = parse_device(&input)?;
    let shift = cli
        .base_address_shift
        .as_deref()
        .map(parse_num)
        .transpose()?
        .unwrap_or(0);
    if shift != 0 {
        for p in &mut device.peripherals {
            p.base_address = p.base_address.wrapping_add(shift);
        }
    }
    log_info("Rendering device");
    let out = cli.output_dir.clone().unwrap_or_else(|| PathBuf::from("."));
    let lib_name = if cli.make_mod { "mod.rs" } else { "lib.rs" };
    fs::write(out.join(lib_name), render_lib(&device, &cli)).map_err(|e| format!("Couldn't create output file: {e}"))?;
    fs::write(out.join("build.rs"), render_build()).map_err(|e| format!("Couldn't create output file: {e}"))?;
    fs::write(out.join("device.x"), render_device_x(&device)).map_err(|e| format!("Couldn't create output file: {e}"))?;
    if cli.generic_mod {
        fs::write(out.join("generic.rs"), render_generic()).map_err(|e| format!("Couldn't create output file: {e}"))?;
    }
    Ok(())
}

fn log_info(msg: &str) {
    eprintln!("[INFO  svd2rust] {msg}");
}

fn parse_device(s: &str) -> Result<Device, String> {
    let root = capture_first(s, "device").ok_or_else(|| {
        "Error parsing SVD XML file\n\nCaused by:\n    the document does not have a root node".to_string()
    })?;
    let mut d = Device {
        name: text(&root, "name").unwrap_or_else(|| "Device".into()),
        description: text(&root, "description").unwrap_or_default(),
        width: text(&root, "width").and_then(|v| parse_num(&v).ok()).unwrap_or(32) as u32,
        ..Default::default()
    };
    for periph_xml in capture_all(&root, "peripheral") {
        let mut p = Peripheral {
            name: text(&periph_xml, "name").unwrap_or_else(|| "PERIPHERAL".into()),
            description: text(&periph_xml, "description").unwrap_or_default(),
            group_name: text(&periph_xml, "groupName").unwrap_or_default(),
            base_address: text(&periph_xml, "baseAddress").and_then(|v| parse_num(&v).ok()).unwrap_or(0),
            ..Default::default()
        };
        for int_xml in capture_all(&periph_xml, "interrupt") {
            d.interrupts.push(Interrupt {
                name: text(&int_xml, "name").unwrap_or_else(|| "INTERRUPT".into()),
                description: text(&int_xml, "description").unwrap_or_default(),
                value: text(&int_xml, "value").and_then(|v| v.trim().parse().ok()).unwrap_or(0),
            });
        }
        for reg_xml in capture_all(&periph_xml, "register") {
            let dim = text(&reg_xml, "dim").and_then(|v| {
                Some(Dim {
                    count: v.trim().parse().ok()?,
                    increment: text(&reg_xml, "dimIncrement").and_then(|x| parse_num(&x).ok()).unwrap_or(4),
                })
            });
            let mut r = Register {
                name: text(&reg_xml, "name").unwrap_or_else(|| "REG".into()),
                description: text(&reg_xml, "description").unwrap_or_default(),
                offset: text(&reg_xml, "addressOffset").and_then(|v| parse_num(&v).ok()).unwrap_or(0),
                size: text(&reg_xml, "size").and_then(|v| parse_num(&v).ok()).unwrap_or(d.width as u64) as u32,
                access: text(&reg_xml, "access").unwrap_or_else(|| "read-write".into()),
                reset: text(&reg_xml, "resetValue").and_then(|v| parse_num(&v).ok()),
                fields: Vec::new(),
                dim,
            };
            for field_xml in capture_all(&reg_xml, "field") {
                let (off, wid) = if let Some(range) = text(&field_xml, "bitRange") {
                    parse_bit_range(&range)
                } else {
                    (
                        text(&field_xml, "bitOffset").and_then(|v| parse_num(&v).ok()).unwrap_or(0) as u32,
                        text(&field_xml, "bitWidth").and_then(|v| parse_num(&v).ok()).unwrap_or(1) as u32,
                    )
                };
                r.fields.push(Field {
                    name: text(&field_xml, "name").unwrap_or_else(|| "FIELD".into()),
                    description: text(&field_xml, "description").unwrap_or_default(),
                    bit_offset: off,
                    bit_width: wid,
                });
            }
            p.registers.push(r);
        }
        d.peripherals.push(p);
    }
    Ok(d)
}

fn render_lib(d: &Device, cli: &Cli) -> String {
    let mut out = String::new();
    if !cli.make_mod && !cli.skip_crate_attributes {
        out.push_str(&format!(
            "#![doc = \"Peripheral access API for {} microcontrollers (generated using svd2rust v{})\"]\n#![allow(non_camel_case_types)]\n#![allow(non_snake_case)]\n#![no_std]\n\n",
            d.name.to_ascii_uppercase(),
            VERSION
        ));
    }
    if cli.generic_mod {
        out.push_str("pub mod generic;\npub use generic::*;\n\n");
    } else {
        out.push_str(&render_generic());
    }
    if cli.reexport_interrupt {
        out.push_str("#[cfg(feature = \"rt\")]\npub use cortex_m_rt::interrupt;\n");
    }
    out.push_str(&render_interrupts(&d.interrupts));
    for p in &d.peripherals {
        out.push_str(&render_peripheral(p, cli));
    }
    out.push_str("\nstatic mut DEVICE_PERIPHERALS: bool = false;\n");
    out.push_str("#[doc = r\" All the peripherals.\"]\n#[allow(non_snake_case)]\npub struct Peripherals {\n");
    for p in &d.peripherals {
        if cli.feature_peripheral {
            out.push_str(&format!("#[cfg(feature = \"{}\")]\n", snake(&p.name)));
        }
        out.push_str(&format!("    #[doc = \"{}\"] pub {}: {},\n", p.name, snake(&p.name), type_name(&p.name)));
    }
    out.push_str("}\nimpl Peripherals {\n    #[doc = r\" Returns all the peripherals *once*.\"]\n    pub fn take() -> Option<Self> { unsafe { if DEVICE_PERIPHERALS { None } else { Some(Self::steal()) } } }\n    #[doc = r\" Unchecked version of `Peripherals::take`.\"]\n    pub unsafe fn steal() -> Self { DEVICE_PERIPHERALS = true; Self {\n");
    for p in &d.peripherals {
        if cli.feature_peripheral {
            out.push_str(&format!("#[cfg(feature = \"{}\")]\n", snake(&p.name)));
        }
        out.push_str(&format!("        {}: {}::steal(),\n", snake(&p.name), type_name(&p.name)));
    }
    out.push_str("    } }\n}\n");
    out
}

fn render_generic() -> String {
    r#"
pub mod generic {
    use core::marker;
    pub struct Periph<PER: PeripheralSpec> { _marker: marker::PhantomData<PER> }
    pub trait PeripheralSpec { type RB; const ADDRESS: usize; const NAME: &'static str; }
    unsafe impl<PER: PeripheralSpec> Send for Periph<PER> {}
    impl<PER: PeripheralSpec> Periph<PER> {
        pub const PTR: *const PER::RB = PER::ADDRESS as *const _;
        pub const fn ptr() -> *const PER::RB { Self::PTR }
        pub unsafe fn steal() -> Self { Self { _marker: marker::PhantomData } }
    }
    impl<PER: PeripheralSpec> core::ops::Deref for Periph<PER> {
        type Target = PER::RB;
        fn deref(&self) -> &Self::Target { unsafe { &*Self::PTR } }
    }
    pub trait RegisterSpec { type Ux: Copy + Default; }
    pub trait Readable: RegisterSpec {}
    pub trait Writable: RegisterSpec { type Safety; }
    pub trait Resettable: RegisterSpec { const RESET_VALUE: Self::Ux; fn reset_value() -> Self::Ux { Self::RESET_VALUE } }
    pub struct Safe;
    pub struct Unsafe;
    pub struct R<REG: RegisterSpec> { bits: REG::Ux }
    pub struct W<REG: RegisterSpec> { bits: REG::Ux }
    impl<REG: RegisterSpec> R<REG> { pub const fn bits(&self) -> REG::Ux { self.bits } }
    impl<REG: Writable> W<REG> { pub unsafe fn bits(&mut self, bits: REG::Ux) -> &mut Self { self.bits = bits; self } }
    #[repr(transparent)]
    pub struct Reg<REG: RegisterSpec> { register: core::cell::UnsafeCell<REG::Ux> }
    unsafe impl<REG: RegisterSpec> Sync for Reg<REG> where REG::Ux: Send {}
    impl<REG: RegisterSpec> Reg<REG> {
        pub const fn reset_value() -> REG::Ux where REG: Resettable { REG::RESET_VALUE }
    }
    impl<REG: Readable> Reg<REG> {
        pub fn read(&self) -> R<REG> { R { bits: unsafe { *self.register.get() } } }
    }
    impl<REG: Writable + Resettable> Reg<REG> {
        pub fn write<F>(&self, f: F) where F: FnOnce(&mut W<REG>) -> &mut W<REG> {
            let mut w = W { bits: REG::RESET_VALUE };
            f(&mut w);
            unsafe { *self.register.get() = w.bits; }
        }
        pub fn reset(&self) { unsafe { *self.register.get() = REG::RESET_VALUE; } }
    }
    impl<REG: Readable + Writable> Reg<REG> {
        pub fn modify<F>(&self, f: F) where for<'w> F: FnOnce(&R<REG>, &'w mut W<REG>) -> &'w mut W<REG> {
            let bits = unsafe { *self.register.get() };
            let r = R { bits };
            let mut w = W { bits };
            f(&r, &mut w);
            unsafe { *self.register.get() = w.bits; }
        }
    }
    pub struct BitReader(bool);
    impl BitReader { pub const fn new(bits: bool) -> Self { Self(bits) } pub const fn bit(&self) -> bool { self.0 } pub const fn bit_is_set(&self) -> bool { self.0 } pub const fn bit_is_clear(&self) -> bool { !self.0 } }
    pub struct FieldReader<T = u8>(T);
    impl<T: Copy> FieldReader<T> { pub const fn new(bits: T) -> Self { Self(bits) } pub const fn bits(&self) -> T { self.0 } }
    pub struct BitWriter<'a, REG: Writable> { w: &'a mut W<REG>, o: u8 }
    impl<'a, REG: Writable<Ux = u32>> BitWriter<'a, REG> { pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o } } pub fn bit(self, value: bool) -> &'a mut W<REG> { if value { self.w.bits |= 1u32 << self.o } else { self.w.bits &= !(1u32 << self.o) }; self.w } pub fn set_bit(self) -> &'a mut W<REG> { self.bit(true) } pub fn clear_bit(self) -> &'a mut W<REG> { self.bit(false) } }
    pub struct FieldWriter<'a, REG: Writable, const WI: u8> { w: &'a mut W<REG>, o: u8 }
    impl<'a, REG: Writable<Ux = u32>, const WI: u8> FieldWriter<'a, REG, WI> { pub fn new(w: &'a mut W<REG>, o: u8) -> Self { Self { w, o } } pub unsafe fn bits(self, value: u32) -> &'a mut W<REG> { let mask = if WI == 32 { u32::MAX } else { (1u32 << WI) - 1 }; self.w.bits = (self.w.bits & !(mask << self.o)) | ((value & mask) << self.o); self.w } }
}
pub use generic::*;
"#
    .to_string()
}

fn render_interrupts(ints: &[Interrupt]) -> String {
    let mut out = String::new();
    out.push_str("#[cfg(feature = \"rt\")]\nextern \"C\" {}\n#[doc(hidden)]\n#[repr(C)] pub union Vector { _handler: unsafe extern \"C\" fn(), _reserved: u32 }\n");
    out.push_str("#[doc = r\"Enumeration of all the interrupts.\"]\n#[derive(Copy, Clone, Debug, PartialEq, Eq)]\npub enum Interrupt {\n");
    for i in ints {
        out.push_str(&format!("    #[doc = \"{}\"] {} = {},\n", esc(&i.description), type_name(&i.name), i.value));
    }
    out.push_str("}\n");
    out
}

fn render_peripheral(p: &Peripheral, cli: &Cli) -> String {
    let ty = type_name(&p.name);
    let modn = snake(&p.name);
    let mut out = String::new();
    if cli.feature_group && !p.group_name.is_empty() {
        out.push_str(&format!("#[cfg(feature = \"{}\")]\n", snake(&p.group_name)));
    }
    if cli.feature_peripheral {
        out.push_str(&format!("#[cfg(feature = \"{}\")]\n", modn));
    }
    out.push_str(&format!(
        "#[doc = \"{}\"] pub type {ty} = crate::Periph<{ty}Spec>;\npub struct {ty}Spec;\nimpl crate::PeripheralSpec for {ty}Spec {{ type RB = {modn}::RegisterBlock; const ADDRESS: usize = {:#x}; const NAME: &'static str = \"{ty}\"; }}\n",
        esc(&p.description),
        p.base_address
    ));
    out.push_str(&format!("#[doc = \"{}\"]\npub mod {modn} {{\n", esc(&p.description)));
    out.push_str("    #[repr(C)]\n    #[doc = \"Register block\"]\n    pub struct RegisterBlock {\n");
    let mut cursor = 0u64;
    let mut reserved = 0usize;
    for r in &p.registers {
        if r.offset > cursor {
            out.push_str(&format!("        _reserved{reserved}: [u8; {}],\n", r.offset - cursor));
            reserved += 1;
        }
        let field_ty = type_name(&expand_name(&r.name, 0));
        if let Some(dim) = &r.dim {
            out.push_str(&format!("        pub {}: [{}; {}],\n", snake_array(&r.name), field_ty, dim.count));
            cursor = r.offset + dim.increment * dim.count as u64;
        } else {
            out.push_str(&format!("        pub {}: {},\n", snake(&r.name), field_ty));
            cursor = r.offset + (r.size.max(8) / 8) as u64;
        }
    }
    out.push_str("    }\n    impl RegisterBlock {\n");
    for r in &p.registers {
        let rty = type_name(&expand_name(&r.name, 0));
        let rn = if r.dim.is_some() { snake_array(&r.name) } else { snake(&r.name) };
        out.push_str(&format!("        #[doc = \"0x{:02x} - {}\"] pub const fn {rn}(&self) -> &{} {{ &self.{rn} }}\n", r.offset, esc(&r.description), if r.dim.is_some() { format!("[{rty}]") } else { rty }));
    }
    out.push_str("    }\n");
    for r in &p.registers {
        out.push_str(&render_register(r));
    }
    out.push_str("}\n");
    out
}

fn render_register(r: &Register) -> String {
    let name0 = expand_name(&r.name, 0);
    let ty = type_name(&name0);
    let modn = snake(&name0);
    let spec = format!("{ty}Spec");
    let mut out = String::new();
    out.push_str(&format!("    #[doc = \"{} ({}) register accessor: {}\"]\n    #[doc(alias = \"{}\")]\n    pub type {ty} = crate::Reg<{modn}::{spec}>;\n", esc(&r.name), access_short(&r.access), esc(&r.description), esc(&r.name)));
    out.push_str(&format!("    #[doc = \"{}\"]\n    pub mod {modn} {{\n", esc(&r.description)));
    let readable = is_readable(&r.access);
    let writable = is_writable(&r.access);
    if readable {
        out.push_str(&format!("        #[doc = \"Register `{}` reader\"] pub type R = crate::R<{spec}>;\n", esc(&r.name)));
    }
    if writable {
        out.push_str(&format!("        #[doc = \"Register `{}` writer\"] pub type W = crate::W<{spec}>;\n", esc(&r.name)));
    }
    for f in &r.fields {
        let fty = type_name(&f.name);
        if f.bit_width == 1 {
            out.push_str(&format!("        #[doc = \"Field `{}` reader - {}\"] pub type {fty}R = crate::BitReader;\n", esc(&f.name), esc(&f.description)));
            if writable {
                out.push_str(&format!("        #[doc = \"Field `{}` writer - {}\"] pub type {fty}W<'a, REG> = crate::BitWriter<'a, REG>;\n", esc(&f.name), esc(&f.description)));
            }
        } else {
            out.push_str(&format!("        #[doc = \"Field `{}` reader - {}\"] pub type {fty}R = crate::FieldReader;\n", esc(&f.name), esc(&f.description)));
            if writable {
                out.push_str(&format!("        #[doc = \"Field `{}` writer - {}\"] pub type {fty}W<'a, REG> = crate::FieldWriter<'a, REG, {}>;\n", esc(&f.name), esc(&f.description), f.bit_width));
            }
        }
    }
    if readable && !r.fields.is_empty() {
        out.push_str("        impl R {\n");
        for f in &r.fields {
            let fty = type_name(&f.name);
            let fnm = snake(&f.name);
            if f.bit_width == 1 {
                out.push_str(&format!("            #[doc = \"Bit {} - {}\"] pub fn {fnm}(&self) -> {fty}R {{ {fty}R::new(((self.bits() >> {}) & 1) != 0) }}\n", f.bit_offset, esc(&f.description), f.bit_offset));
            } else {
                let mask = (1u64.checked_shl(f.bit_width).unwrap_or(0)).saturating_sub(1);
                out.push_str(&format!("            #[doc = \"Bits {}:{} - {}\"] pub fn {fnm}(&self) -> {fty}R {{ {fty}R::new(((self.bits() >> {}) & {mask}) as u8) }}\n", f.bit_offset, f.bit_offset + f.bit_width - 1, esc(&f.description), f.bit_offset));
            }
        }
        out.push_str("        }\n");
    }
    if writable && !r.fields.is_empty() {
        out.push_str("        impl W {\n");
        for f in &r.fields {
            let fty = type_name(&f.name);
            let fnm = snake(&f.name);
            if f.bit_width == 1 {
                out.push_str(&format!("            #[doc = \"Bit {} - {}\"] pub fn {fnm}(&mut self) -> {fty}W<'_, {spec}> {{ {fty}W::new(self, {}) }}\n", f.bit_offset, esc(&f.description), f.bit_offset));
            } else {
                out.push_str(&format!("            #[doc = \"Bits {}:{} - {}\"] pub fn {fnm}(&mut self) -> {fty}W<'_, {spec}> {{ {fty}W::new(self, {}) }}\n", f.bit_offset, f.bit_offset + f.bit_width - 1, esc(&f.description), f.bit_offset));
            }
        }
        out.push_str("        }\n");
    }
    out.push_str(&format!("        #[doc = \"{}\"] pub struct {spec};\n        impl crate::RegisterSpec for {spec} {{ type Ux = {}; }}\n", esc(&r.description), uint_ty(r.size)));
    if readable {
        out.push_str(&format!("        impl crate::Readable for {spec} {{}}\n"));
    }
    if writable {
        out.push_str(&format!("        impl crate::Writable for {spec} {{ type Safety = crate::Unsafe; }}\n"));
    }
    out.push_str(&format!("        impl crate::Resettable for {spec} {{ const RESET_VALUE: Self::Ux = {}; }}\n", r.reset.unwrap_or(0)));
    out.push_str("    }\n");
    out
}

fn render_build() -> String {
    "#![doc = r\" Builder file for Peripheral access crate generated by svd2rust tool\"]\nuse std::env; use std::fs::File; use std::io::Write; use std::path::PathBuf;\nfn main() { if env::var_os(\"CARGO_FEATURE_RT\").is_some() { let out = &PathBuf::from(env::var_os(\"OUT_DIR\").unwrap()); File::create(out.join(\"device.x\")).unwrap().write_all(include_bytes!(\"device.x\")).unwrap(); println!(\"cargo:rustc-link-search={}\", out.display()); println!(\"cargo:rerun-if-changed=device.x\"); } println!(\"cargo:rerun-if-changed=build.rs\"); }\n".into()
}

fn render_device_x(d: &Device) -> String {
    let mut out = String::new();
    for i in &d.interrupts {
        out.push_str(&format!("PROVIDE({} = DefaultHandler);\n", type_name(&i.name)));
    }
    out
}

fn capture_first(s: &str, tag: &str) -> Option<String> {
    capture_all(s, tag).into_iter().next()
}

fn capture_all(s: &str, tag: &str) -> Vec<String> {
    let re = Regex::new(&format!(r"(?is)<{tag}(?:\s[^>]*)?>(.*?)</{tag}>")).unwrap();
    re.captures_iter(s).map(|c| c[1].to_string()).collect()
}

fn text(s: &str, tag: &str) -> Option<String> {
    capture_first(s, tag).map(|v| unescape(v.trim()).trim().to_string())
}

fn parse_num(s: &str) -> Result<u64, String> {
    let t = s.trim().replace('_', "");
    if let Some(hex) = t.strip_prefix("0x").or_else(|| t.strip_prefix("0X")) {
        u64::from_str_radix(hex, 16).map_err(|e| e.to_string())
    } else {
        t.parse::<u64>().map_err(|e| e.to_string())
    }
}

fn parse_bit_range(s: &str) -> (u32, u32) {
    let nums: Vec<u32> = Regex::new(r"\d+").unwrap().find_iter(s).filter_map(|m| m.as_str().parse().ok()).collect();
    if nums.len() >= 2 {
        let hi = nums[0].max(nums[1]);
        let lo = nums[0].min(nums[1]);
        (lo, hi - lo + 1)
    } else {
        (0, 1)
    }
}

fn is_readable(access: &str) -> bool {
    !access.contains("write-only")
}

fn is_writable(access: &str) -> bool {
    access.contains("write") || access.contains("read-write")
}

fn access_short(access: &str) -> &'static str {
    match access {
        a if a.contains("read-only") => "r",
        a if a.contains("write-only") => "w",
        _ => "rw",
    }
}

fn uint_ty(bits: u32) -> &'static str {
    match bits {
        0..=8 => "u8",
        9..=16 => "u16",
        17..=32 => "u32",
        _ => "u64",
    }
}

fn type_name(s: &str) -> String {
    words(s).into_iter().map(|w| {
        let mut ch = w.chars();
        match ch.next() {
            Some(c) => c.to_ascii_uppercase().to_string() + &ch.as_str().to_ascii_lowercase(),
            None => String::new(),
        }
    }).collect::<String>().pipe(|v| if v.is_empty() { "X".into() } else { v })
}

fn snake(s: &str) -> String {
    words(s).join("_").to_ascii_lowercase().pipe(|v| if v.is_empty() { "x".into() } else { v })
}

fn snake_array(s: &str) -> String {
    snake(&s.replace("[%s]", "").replace("%s", "").replace("[n]", "").replace("[m]", ""))
}

fn expand_name(s: &str, n: usize) -> String {
    s.replace("[%s]", &n.to_string()).replace("%s", &n.to_string()).replace("[n]", &n.to_string()).replace("[m]", &n.to_string())
}

fn words(s: &str) -> Vec<String> {
    let clean = s.replace("[%s]", "").replace("%s", "").replace("[n]", "").replace("[m]", "");
    let mut words = Vec::new();
    let mut cur = String::new();
    for c in clean.chars() {
        if c.is_ascii_alphanumeric() {
            cur.push(c);
        } else if !cur.is_empty() {
            words.push(cur.clone());
            cur.clear();
        }
    }
    if !cur.is_empty() {
        words.push(cur);
    }
    words
}

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', " ")
}

fn unescape(s: &str) -> String {
    s.replace("&lt;", "<").replace("&gt;", ">").replace("&amp;", "&").replace("&quot;", "\"").replace("&apos;", "'")
}

trait Pipe: Sized {
    fn pipe<T>(self, f: impl FnOnce(Self) -> T) -> T { f(self) }
}
impl<T> Pipe for T {}

#[allow(dead_code)]
fn _exists(path: &Path) -> bool {
    path.exists()
}
