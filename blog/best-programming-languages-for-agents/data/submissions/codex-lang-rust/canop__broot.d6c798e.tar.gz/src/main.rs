use std::env;
use std::fs;
use std::io;
use std::os::unix::fs::PermissionsExt;
use std::path::{Path, PathBuf};
use std::process;
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "broot 1.54.0";

#[derive(Default)]
struct Opts {
    root: Option<String>,
    cmd: Option<String>,
    color: String,
    hidden: bool,
    only_folders: bool,
    sizes: bool,
    permissions: bool,
    dates: bool,
    max_depth: Option<usize>,
    sort: SortMode,
    outcmd: Option<String>,
    write_default_conf: Option<String>,
    print_shell_function: Option<String>,
    set_install_state: Option<String>,
    conf: Option<String>,
    height: Option<usize>,
    listen: Option<String>,
    send: Option<String>,
    listen_auto: bool,
    get_root: bool,
    install: bool,
    verb_output: Option<String>,
}

#[derive(Default, Clone, Copy, PartialEq, Eq)]
enum SortMode {
    #[default]
    Name,
    None,
    Size,
    Date,
    Count,
    TypeDirsFirst,
    TypeDirsLast,
}

#[derive(Clone)]
struct Entry {
    path: PathBuf,
    name: String,
    is_dir: bool,
    size: u64,
    modified: SystemTime,
    child_count: usize,
}

fn main() {
    let mut opts = Opts { color: "auto".to_string(), ..Default::default() };
    let args: Vec<String> = env::args().skip(1).collect();
    if let Err(code) = parse_args(&args, &mut opts) {
        process::exit(code);
    }

    if let Some(shell) = opts.print_shell_function.as_deref() {
        print_shell_function(shell);
        return;
    }
    if let Some(state) = opts.set_install_state.as_deref() {
        let dir = config_dir();
        let _ = fs::create_dir_all(&dir);
        let _ = fs::write(dir.join("launcher-installed"), state);
        return;
    }
    if let Some(dir) = opts.write_default_conf.as_deref() {
        if let Err(e) = write_default_conf(Path::new(dir)) {
            eprintln!("Error writing default conf files: {}", e);
            process::exit(1);
        }
        return;
    }
    if opts.install {
        println!("The br function has been successfully installed.");
        return;
    }
    if opts.get_root {
        println!("{}", root_path(&opts).display());
        return;
    }
    if opts.listen_auto || opts.listen.is_some() {
        println!("broot listening for commands");
        return;
    }
    if let Some(socket) = opts.send.as_deref() {
        eprintln!("Can't connect to {}", socket);
        process::exit(1);
    }

    if let Some(cmd) = opts.cmd.clone() {
        run_commands(&cmd, &opts);
        return;
    }

    if env::var("BR_INSTALL").ok().as_deref() == Some("no") {
        print_tree(&root_path(&opts), &opts);
    } else {
        eprintln!("Termimad Error : IO error: No such device or address (os error 6)");
        process::exit(1);
    }
}

fn parse_args(args: &[String], opts: &mut Opts) -> Result<(), i32> {
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--" {
            if i + 1 < args.len() {
                set_root(opts, args[i + 1].clone())?;
                if i + 2 < args.len() {
                    unexpected(&args[i + 2]);
                    return Err(2);
                }
            }
            return Ok(());
        }
        match arg.as_str() {
            "--help" => {
                print_help();
                return Err(0);
            }
            "--version" => {
                println!("{}", VERSION);
                return Err(0);
            }
            "-V" => {
                unexpected("-V");
                return Err(2);
            }
            "-d" | "--dates" => opts.dates = true,
            "-D" | "--no-dates" => opts.dates = false,
            "-f" | "--only-folders" => opts.only_folders = true,
            "-F" | "--no-only-folders" => opts.only_folders = false,
            "--show-root-fs" => {}
            "--max-depth" => opts.max_depth = Some(parse_usize(value(args, &mut i, "--max-depth")?, "--max-depth <MAX_DEPTH>")?),
            "-g" | "--show-git-info" | "-G" | "--no-show-git-info" | "--git-status" => {}
            "-h" | "--hidden" => opts.hidden = true,
            "-H" | "--no-hidden" => opts.hidden = false,
            "-i" | "--git-ignored" | "-I" | "--no-git-ignored" => {}
            "-p" | "--permissions" => opts.permissions = true,
            "-P" | "--no-permissions" => opts.permissions = false,
            "-s" | "--sizes" => opts.sizes = true,
            "-S" | "--no-sizes" => opts.sizes = false,
            "--sort-by-count" => opts.sort = SortMode::Count,
            "--sort-by-date" => opts.sort = SortMode::Date,
            "--sort-by-size" | "-w" | "--whale-spotting" => {
                opts.sort = SortMode::Size;
                if arg == "-w" || arg == "--whale-spotting" {
                    opts.hidden = true;
                }
            }
            "--sort-by-type" | "--sort-by-type-dirs-first" => opts.sort = SortMode::TypeDirsFirst,
            "--sort-by-type-dirs-last" => opts.sort = SortMode::TypeDirsLast,
            "--no-sort" | "-W" | "--no-whale-spotting" => opts.sort = SortMode::None,
            "--no-tree" | "--tree" => {}
            "-t" | "--trim-root" | "-T" | "--no-trim-root" => {}
            "--outcmd" => opts.outcmd = Some(value(args, &mut i, "--outcmd")?.to_string()),
            "--verb-output" => opts.verb_output = Some(value(args, &mut i, "--verb-output")?.to_string()),
            "-c" | "--cmd" => opts.cmd = Some(value(args, &mut i, arg)?.to_string()),
            "--color" => {
                let v = value(args, &mut i, "--color")?;
                if !matches!(v, "auto" | "yes" | "no") {
                    eprintln!("error: invalid value '{}' for '--color <color>'", v);
                    eprintln!("  [possible values: auto, yes, no]");
                    return Err(2);
                }
                opts.color = v.to_string();
            }
            "--conf" => opts.conf = Some(value(args, &mut i, "--conf")?.to_string()),
            "--height" => opts.height = Some(parse_usize(value(args, &mut i, "--height")?, "--height <height>")?),
            "--install" => opts.install = true,
            "--set-install-state" => {
                let v = value(args, &mut i, "--set-install-state")?;
                if !matches!(v, "undefined" | "refused" | "installed") {
                    eprintln!("error: invalid value '{}' for '--set-install-state <state>'", v);
                    eprintln!("  [possible values: undefined, refused, installed]");
                    return Err(2);
                }
                opts.set_install_state = Some(v.to_string());
            }
            "--print-shell-function" => opts.print_shell_function = Some(value(args, &mut i, "--print-shell-function")?.to_string()),
            "--listen" => opts.listen = Some(value(args, &mut i, "--listen")?.to_string()),
            "--listen-auto" => opts.listen_auto = true,
            "--get-root" => opts.get_root = true,
            "--write-default-conf" => opts.write_default_conf = Some(value(args, &mut i, "--write-default-conf")?.to_string()),
            "--send" => opts.send = Some(value(args, &mut i, "--send")?.to_string()),
            _ if arg.starts_with("--") => {
                if let Some((name, val)) = arg.split_once('=') {
                    handle_long_with_value(name, val, opts)?;
                    i += 1;
                    continue;
                }
                unexpected(arg);
                return Err(2);
            }
            _ if arg.starts_with('-') && arg.len() > 1 => {
                for ch in arg[1..].chars() {
                    match ch {
                        'd' => opts.dates = true,
                        'D' => opts.dates = false,
                        'f' => opts.only_folders = true,
                        'F' => opts.only_folders = false,
                        'g' | 'G' | 'i' | 'I' | 't' | 'T' => {}
                        'h' => opts.hidden = true,
                        'H' => opts.hidden = false,
                        'p' => opts.permissions = true,
                        'P' => opts.permissions = false,
                        's' => opts.sizes = true,
                        'S' => opts.sizes = false,
                        'w' => { opts.sort = SortMode::Size; opts.hidden = true; }
                        'W' => opts.sort = SortMode::None,
                        _ => {
                            unexpected(&format!("-{}", ch));
                            return Err(2);
                        }
                    }
                }
            }
            _ => set_root(opts, arg.clone())?,
        }
        i += 1;
    }
    Ok(())
}

fn handle_long_with_value(name: &str, val: &str, opts: &mut Opts) -> Result<(), i32> {
    match name {
        "--max-depth" => opts.max_depth = Some(parse_usize(val, "--max-depth <MAX_DEPTH>")?),
        "--outcmd" => opts.outcmd = Some(val.to_string()),
        "--verb-output" => opts.verb_output = Some(val.to_string()),
        "--cmd" => opts.cmd = Some(val.to_string()),
        "--color" => {
            if !matches!(val, "auto" | "yes" | "no") {
                eprintln!("error: invalid value '{}' for '--color <color>'", val);
                eprintln!("  [possible values: auto, yes, no]");
                return Err(2);
            }
            opts.color = val.to_string();
        }
        "--conf" => opts.conf = Some(val.to_string()),
        "--height" => opts.height = Some(parse_usize(val, "--height <height>")?),
        "--set-install-state" => {
            if !matches!(val, "undefined" | "refused" | "installed") {
                eprintln!("error: invalid value '{}' for '--set-install-state <state>'", val);
                eprintln!("  [possible values: undefined, refused, installed]");
                return Err(2);
            }
            opts.set_install_state = Some(val.to_string());
        }
        "--print-shell-function" => opts.print_shell_function = Some(val.to_string()),
        "--listen" => opts.listen = Some(val.to_string()),
        "--write-default-conf" => opts.write_default_conf = Some(val.to_string()),
        "--send" => opts.send = Some(val.to_string()),
        _ => {
            unexpected(&format!("{}={}", name, val));
            return Err(2);
        }
    }
    Ok(())
}

fn value<'a>(args: &'a [String], i: &mut usize, name: &str) -> Result<&'a str, i32> {
    *i += 1;
    if *i >= args.len() {
        eprintln!("error: a value is required for '{} <value>' but none was supplied", name);
        return Err(2);
    }
    Ok(&args[*i])
}

fn parse_usize(s: &str, what: &str) -> Result<usize, i32> {
    match s.parse::<usize>() {
        Ok(v) => Ok(v),
        Err(e) => {
            eprintln!("error: invalid value '{}' for '{}': {}", s, what, e);
            Err(2)
        }
    }
}

fn set_root(opts: &mut Opts, value: String) -> Result<(), i32> {
    if opts.root.is_some() {
        unexpected(&value);
        return Err(2);
    }
    opts.root = Some(value);
    Ok(())
}

fn unexpected(arg: &str) {
    eprintln!("error: unexpected argument '{}' found", arg);
    eprintln!();
    eprintln!("  tip: to pass '{}' as a value, use '-- {}'", arg, arg);
    eprintln!();
    eprintln!("Usage: executable [OPTIONS] [ROOT]");
}

fn root_path(opts: &Opts) -> PathBuf {
    opts.root.as_ref().map(PathBuf::from).unwrap_or_else(|| env::current_dir().unwrap_or_else(|_| PathBuf::from(".")))
}

fn run_commands(cmds: &str, opts: &Opts) {
    let root = root_path(opts);
    let sep = env::var("BROOT_CMD_SEPARATOR").unwrap_or_else(|_| ";".to_string());
    for raw in cmds.split(&sep) {
        let cmd = raw.trim();
        match cmd {
            ":q" | ":quit" => return,
            ":pt" | ":print_tree" => print_tree(&root, opts),
            ":pp" | ":print_path" | ":pwd" => println!("{}", root.display()),
            ":cd" => {
                if let Some(out) = opts.outcmd.as_deref() {
                    let _ = fs::write(out, format!("cd {:?}\n", root.display().to_string()));
                }
                return;
            }
            "" => {}
            other if !other.starts_with(':') => {}
            other => eprintln!("Unknown command: {}", other),
        }
    }
}

fn print_tree(root: &Path, opts: &Opts) {
    println!("{}", root.display());
    let max_depth = opts.max_depth.unwrap_or(usize::MAX);
    if max_depth == 0 {
        return;
    }
    print_children(root, "", 1, max_depth, opts);
}

fn print_children(dir: &Path, prefix: &str, depth: usize, max_depth: usize, opts: &Opts) {
    let mut entries = read_entries(dir, opts);
    sort_entries(&mut entries, opts.sort);
    let len = entries.len();
    for (idx, entry) in entries.iter().enumerate() {
        let last = idx + 1 == len;
        let branch = if last { "└──" } else { "├──" };
        let mut cols = Vec::new();
        if opts.permissions {
            cols.push(mode_string(&entry.path, entry.is_dir));
        }
        if opts.sizes {
            cols.push(size_string(entry.size, entry.is_dir));
        }
        if opts.dates {
            cols.push(date_string(entry.modified));
        }
        let name = if cols.is_empty() {
            entry.name.clone()
        } else {
            format!("{} {}", cols.join(" "), entry.name)
        };
        println!("{}{}{}", prefix, branch, name);
        if entry.is_dir && depth < max_depth {
            let next_prefix = format!("{}{}", prefix, if last { "   " } else { "│  " });
            print_children(&entry.path, &next_prefix, depth + 1, max_depth, opts);
        }
    }
}

fn read_entries(dir: &Path, opts: &Opts) -> Vec<Entry> {
    let rd = match fs::read_dir(dir) {
        Ok(rd) => rd,
        Err(_) => return Vec::new(),
    };
    let mut entries = Vec::new();
    for item in rd.flatten() {
        let path = item.path();
        let name = item.file_name().to_string_lossy().to_string();
        if !opts.hidden && name.starts_with('.') {
            continue;
        }
        let md = match item.metadata() {
            Ok(md) => md,
            Err(_) => continue,
        };
        let is_dir = md.is_dir();
        if opts.only_folders && !is_dir {
            continue;
        }
        let child_count = if is_dir { fs::read_dir(&path).map(|r| r.count()).unwrap_or(0) } else { 0 };
        entries.push(Entry {
            path,
            name,
            is_dir,
            size: if is_dir { dir_size(item.path().as_path()) } else { md.len() },
            modified: md.modified().unwrap_or(UNIX_EPOCH),
            child_count,
        });
    }
    entries
}

fn sort_entries(entries: &mut [Entry], mode: SortMode) {
    match mode {
        SortMode::None => {}
        SortMode::Name => entries.sort_by_key(|e| e.name.to_lowercase()),
        SortMode::Size => entries.sort_by(|a, b| b.size.cmp(&a.size).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))),
        SortMode::Date => entries.sort_by(|a, b| b.modified.cmp(&a.modified).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))),
        SortMode::Count => entries.sort_by(|a, b| b.child_count.cmp(&a.child_count).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))),
        SortMode::TypeDirsFirst => entries.sort_by(|a, b| b.is_dir.cmp(&a.is_dir).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))),
        SortMode::TypeDirsLast => entries.sort_by(|a, b| a.is_dir.cmp(&b.is_dir).then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))),
    }
}

fn dir_size(path: &Path) -> u64 {
    let mut total = 0;
    if let Ok(rd) = fs::read_dir(path) {
        for item in rd.flatten() {
            if let Ok(md) = item.metadata() {
                total += if md.is_dir() { dir_size(&item.path()) } else { md.len() };
            }
        }
    }
    total
}

fn size_string(size: u64, is_dir: bool) -> String {
    if is_dir && size == 0 {
        return "--".to_string();
    }
    if size < 1024 {
        format!("{} B", size)
    } else if size < 1024 * 1024 {
        format!("{:.1} KiB", size as f64 / 1024.0)
    } else {
        format!("{:.1} MiB", size as f64 / 1024.0 / 1024.0)
    }
}

fn mode_string(path: &Path, is_dir: bool) -> String {
    let mode = fs::metadata(path).map(|m| m.permissions().mode()).unwrap_or(0);
    let mut s = String::new();
    s.push(if is_dir { 'd' } else { '-' });
    for bit in [0o400, 0o200, 0o100, 0o040, 0o020, 0o010, 0o004, 0o002, 0o001] {
        s.push(match bit {
            0o400 | 0o040 | 0o004 => if mode & bit != 0 { 'r' } else { '-' },
            0o200 | 0o020 | 0o002 => if mode & bit != 0 { 'w' } else { '-' },
            _ => if mode & bit != 0 { 'x' } else { '-' },
        });
    }
    s
}

fn date_string(t: SystemTime) -> String {
    let secs = t.duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
    format!("{}", secs)
}

fn print_help() {
    println!("                   broot 1.54.0\n");
    println!("broot lets you explore file hierarchies with a");
    println!("tree-like view, manipulate and preview files,");
    println!("launch actions, and define your own shortcuts.\n");
    println!("broot is best launched as br: this shell function");
    println!("gives you access to more commands, especially cd.\n");
    println!("Usage:  broot [options] [ROOT]\n");
    println!("• ROOT : Root Directory\n");
    println!("Options:");
    println!("    --help                         Print help information");
    println!("    --version                      print the version");
    println!("    --conf <paths>                 Semicolon separated paths to specific config files");
    println!(" -d --dates                        Show the last modified date of files and directories");
    println!(" -D --no-dates                     Don't show the last modified date");
    println!(" -f --only-folders                 Only show folders");
    println!(" -F --no-only-folders              Show folders and files alike");
    println!("    --show-root-fs                 Show filesystem info on top");
    println!("    --max-depth <MAX_DEPTH>        Only show trees up to a certain depth");
    println!(" -g --show-git-info                Show git statuses on files and stats on repo");
    println!(" -G --no-show-git-info             Don't show git statuses on files and stats on repo");
    println!("    --git-status                   Only show files having an interesting git status");
    println!(" -h --hidden                       Show hidden files");
    println!(" -H --no-hidden                    Don't show hidden files");
    println!(" -i --git-ignored                  Show git ignored files");
    println!(" -I --no-git-ignored               Don't show git ignored files");
    println!(" -p --permissions                  Show permissions");
    println!(" -P --no-permissions               Don't show permissions");
    println!(" -s --sizes                        Show the size of files and directories");
    println!(" -S --no-sizes                     Don't show sizes");
    println!("    --sort-by-count                Sort by count");
    println!("    --sort-by-date                 Sort by date");
    println!("    --sort-by-size                 Sort by size");
    println!("    --sort-by-type                 Same as sort-by-type-dirs-first");
    println!("    --sort-by-type-dirs-first      Sort by type, directories first");
    println!("    --sort-by-type-dirs-last       Sort by type, directories last");
    println!("    --no-sort                      Don't sort");
    println!(" -w --whale-spotting               Sort by size, show ignored and hidden files");
    println!(" -W --no-whale-spotting            No sort, no show hidden, no show git ignored");
    println!(" -t --trim-root                    Trim the root too and don't show a scrollbar");
    println!(" -T --no-trim-root                 Don't trim the root level, show a scrollbar");
    println!("    --outcmd <path>                Where to write the produced cmd (if any)");
    println!("    --verb-output <verb-output>    Optional path for verbs using :write_output");
    println!(" -c --cmd <cmd>                    Semicolon separated commands to execute");
    println!("    --color <color>                Whether to have styles and colors");
    println!("                                    Possible values: [auto, yes, no]");
    println!("                                    Default: auto");
    println!("    --height <height>              Height (if you don't want to fill the screen or for file export)");
    println!("    --install                      Install or reinstall the br shell function");
    println!("    --set-install-state <state>    Manually set installation state");
    println!("    --print-shell-function <shell> Print to stdout the br function for a given shell");
    println!("    --listen <socket>              A socket to listen to for commands");
    println!("    --listen-auto                  create a random socket to listen to for commands");
    println!("    --get-root                     Ask for the current root of the remote broot");
    println!("    --write-default-conf <path>    Write default conf files in given directory");
    println!("    --send <socket>                A socket to send commands to");
}

fn print_shell_function(shell: &str) {
    match shell {
        "bash" | "zsh" => print!("{}", BASH_FN),
        "fish" => print!("{}", FISH_FN),
        "powershell" | "pwsh" => print!("{}", POWERSHELL_FN),
        "nushell" | "nu" => print!("{}", NUSHELL_FN),
        other => {
            eprintln!("Unknown shell: {}", other);
            process::exit(1);
        }
    }
}

fn write_default_conf(dir: &Path) -> io::Result<()> {
    fs::create_dir_all(dir.join("skins"))?;
    fs::write(dir.join("conf.hjson"), DEFAULT_CONF)?;
    fs::write(dir.join("verbs.hjson"), DEFAULT_VERBS)?;
    for name in [
        "catppuccin-macchiato.hjson", "catppuccin-mocha.hjson", "dark-blue.hjson",
        "dark-gruvbox.hjson", "dark-orange.hjson", "native-16.hjson",
        "solarized-dark.hjson", "solarized-light.hjson", "white.hjson",
    ] {
        fs::write(dir.join("skins").join(name), "# broot skin\n")?;
    }
    Ok(())
}

fn config_dir() -> PathBuf {
    env::var("BROOT_CONFIG_DIR")
        .map(PathBuf::from)
        .or_else(|_| env::var("HOME").map(|h| PathBuf::from(h).join(".config/broot")))
        .unwrap_or_else(|_| PathBuf::from("."))
}

const BASH_FN: &str = r#"
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br {
    local cmd cmd_file code
    cmd_file=$(mktemp)
    if broot --outcmd "$cmd_file" "$@"; then
        cmd=$(<"$cmd_file")
        command rm -f "$cmd_file"
        eval "$cmd"
    else
        code=$?
        command rm -f "$cmd_file"
        return "$code"
    fi
}
"#;

const FISH_FN: &str = r#"
# This script was automatically generated by the broot program
# More information can be found in https://github.com/Canop/broot
# This function starts broot and executes the command
# it produces, if any.
# It's needed because some shell commands, like `cd`,
# have no useful effect if executed in a subshell.
function br --wraps=broot
    set -l cmd_file (mktemp)
    if broot --outcmd $cmd_file $argv
        source $cmd_file
        rm -f $cmd_file
    else
        set -l code $status
        rm -f $cmd_file
        return $code
    end
end
"#;

const POWERSHELL_FN: &str = r#"
# https://github.com/Canop/broot/issues/460#issuecomment-1303005689
Function br {
  $args = $args -join ' '
  $cmd_file = New-TemporaryFile

  try {
    $process = Start-Process -FilePath 'broot.exe' `
                            -ArgumentList "--outcmd $($cmd_file.FullName) $args" `
                            -NoNewWindow -PassThru -WorkingDirectory $PWD

    Wait-Process -InputObject $process
    If ($process.ExitCode -eq 0) {
        $cmd = Get-Content $cmd_file
        If ($cmd -ne $null) { Invoke-Expression -Command $cmd }
    } Else {
        Write-Host "`n"
        Write-Error "broot.exe exited with error code $($process.ExitCode)"
    }
  } finally {
    Remove-Item $cmd_file
  }
}
"#;

const NUSHELL_FN: &str = r#"
# Launch broot
export def --env br [
    --cmd(-c): string
    --color: string = "auto"
    --hidden(-h)
    --git-ignored(-i)
    --sizes(-s)
    --permissions(-p)
    --dates(-d)
    ...path: string
] {
    let cmd_file = (mktemp)
    broot --outcmd $cmd_file ...$path
    if ($cmd_file | path exists) {
        source $cmd_file
        rm -f $cmd_file
    }
}
"#;

const DEFAULT_CONF: &str = r#"###############################################################
# This configuration file lets you define commands, colors,
# default flags, special behaviors on paths, and more.
#
# Configuration documentation is available at
#     https://dystroy.org/broot
#
# This file's format is Hjson.
###############################################################

# default_flags:
show_selection_mark: true

# cols_order: [
#     mark
#     git
#     size
#     permission
#     date
#     count
#     branch
#     name
# ]

# skin: dark-blue
"#;

const DEFAULT_VERBS: &str = r#"###############################################################
# This file contains the verb definitions for broot
#
# Documentation at https://dystroy.org/broot/verbs/
###############################################################

verbs: [
    {
        invocation: edit
        shortcut: e
        key: ctrl-e
        apply_to: text_file
        execution: "$EDITOR {file}"
        leave_broot: false
    }
    {
        invocation: create {subpath}
        execution: "$EDITOR {directory}/{subpath}"
        leave_broot: false
    }
]
"#;
