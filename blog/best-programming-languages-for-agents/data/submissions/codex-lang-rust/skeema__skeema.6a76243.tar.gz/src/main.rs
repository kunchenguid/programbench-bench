use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process;
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "skeema version 1.13.2-community, commit a65240e, released 2026-04-17T20:00:03Z";
const COMMANDS: &[&str] = &["add-environment", "diff", "format", "help", "init", "lint", "pull", "push", "version"];

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        print_help("main");
        return;
    }

    if args[0] == "help" {
        if args.len() == 1 { print_help("main"); return; }
        if args.len() == 2 && args[1] == "help" { print_help("main"); return; }
        if args.len() == 2 && is_command(&args[1]) && args[1] != "help" { print_help(&args[1]); return; }
        error_exit(2, &format!("Unknown command {:?}", args.get(1).unwrap_or(&String::new())));
    }

    if args[0] == "--version" || args[0] == "version" {
        if args[0] == "version" && args.len() > 1 && !is_help_arg(&args[1]) {
            error_exit(78, &format!("Extra command-line arg {:?} supplied; command version takes a max of 0 args", args[1]));
        }
        if args.len() > 1 && is_help_arg(&args[1]) { print_help("version"); return; }
        println!("{}", VERSION);
        return;
    }

    if args[0].starts_with("--help=") {
        let c = args[0].trim_start_matches("--help=");
        if is_command(c) && c != "help" { print_help(c); } else { print_help("main"); }
        return;
    }
    if args[0] == "--help" || args[0] == "-?" {
        if args.len() > 1 && is_command(&args[1]) && args[1] != "help" { print_help(&args[1]); } else { print_help("main"); }
        return;
    }

    let cmd_pos = args.iter().position(|a| is_command(a));
    let cmd_pos = match cmd_pos {
        Some(i) => i,
        None => {
            if args[0].starts_with('-') { error_exit(78, &format!("CLI: Unknown option {:?}", args[0].trim_start_matches('-'))); }
            error_exit(78, &format!("Unknown command {:?}", args[0]));
        }
    };
    let command = args[cmd_pos].clone();
    if command == "help" { print_help("main"); return; }
    let mut all_opts = Vec::new();
    all_opts.extend(args.drain(..cmd_pos));
    args.remove(0);
    all_opts.extend(args.clone());

    if all_opts.iter().any(|a| is_help_arg(a)) { print_help(&command); return; }
    if all_opts.iter().any(|a| a == "--version") { println!("{}", VERSION); return; }

    if let Err((code, msg)) = validate_options(&command, &all_opts) { error_exit(code, &msg); }

    match command.as_str() {
        "add-environment" => cmd_add_environment(&args),
        "init" => cmd_init(&args),
        "lint" => cmd_lint(&args),
        "format" => cmd_format(&args),
        "diff" | "push" | "pull" => process::exit(0),
        "version" => println!("{}", VERSION),
        _ => error_exit(78, &format!("Unknown command {:?}", command)),
    }
}

fn is_command(s: &str) -> bool { COMMANDS.contains(&s) }
fn is_help_arg(s: &str) -> bool { s == "--help" || s == "-?" || s.starts_with("--help=") }

fn print_help(name: &str) {
    let text = match name {
        "add-environment" => include_str!("../help/add-environment.txt"),
        "diff" => include_str!("../help/diff.txt"),
        "format" => include_str!("../help/format.txt"),
        "init" => include_str!("../help/init.txt"),
        "lint" => include_str!("../help/lint.txt"),
        "pull" => include_str!("../help/pull.txt"),
        "push" => include_str!("../help/push.txt"),
        "version" => include_str!("../help/version.txt"),
        _ => include_str!("../help/main.txt"),
    };
    print!("{}", text);
}

fn option_takes_value(opt: &str) -> bool {
    matches!(opt,
        "--connect-options"|"-o"|"--host-wrapper"|"-H"|"--ignore-func"|"--ignore-proc"|"--ignore-schema"|"--ignore-table"|
        "--password"|"-p"|"--ssl-mode"|"--user"|"-u"|"--dir"|"-d"|"--host"|"-h"|"--port"|"-P"|"--socket"|"-S"|"--schema"|
        "--alter-wrapper"|"-x"|"--alter-wrapper-min-size"|"--ddl-wrapper"|"-X"|"--alter-algorithm"|"--alter-lock"|"--partitioning"|
        "--allow-auto-inc"|"--allow-charset"|"--allow-compression"|"--allow-definer"|"--allow-engine"|"--allow-pk-type"|
        "--lint-auto-inc"|"--lint-charset"|"--lint-compression"|"--lint-definer"|"--lint-display-width"|"--lint-dupe-index"|"--lint-engine"|
        "--lint-fk-parent"|"--lint-has-enum"|"--lint-has-fk"|"--lint-has-float"|"--lint-has-routine"|"--lint-has-time"|"--lint-name-case"|
        "--lint-pk"|"--lint-pk-type"|"--lint-reserved-word"|"--lint-zero-date"|"--safe-below-size"|"--concurrent-servers"|"-c"|
        "--docker-cleanup"|"--temp-schema"|"-t"|"--temp-schema-binlog"|"--temp-schema-mode"|"--temp-schema-threads"|"--workspace"|"-w")
}

fn option_known(opt: &str) -> bool {
    option_takes_value(opt) || matches!(opt,
        "--debug"|"--my-cnf"|"--skip-my-cnf"|"--include-auto-inc"|"--strip-partitioning"|"--alter-validate-virtual"|"--compare-metadata"|"--exact-match"|
        "--lax-column-order"|"--lax-comments"|"--lint"|"--skip-lint"|"--allow-unsafe"|"--verify"|"--skip-verify"|"--brief"|"-q"|"--first-only"|"-1"|
        "--write"|"--skip-write"|"--format"|"--skip-format"|"--new-schemas"|"--skip-new-schemas"|"--update-partitioning"|"--dry-run"|"--foreign-key-checks")
}

fn validate_options(command: &str, args: &[String]) -> Result<(), (i32, String)> {
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" { break; }
        if a.starts_with('-') {
            let name = a.split('=').next().unwrap();
            if !option_known(name) { return Err((78, format!("CLI: Unknown option {:?}", name.trim_start_matches('-')))); }
            if (name == "--concurrent-servers" || name == "-c") && value_of_current(a, args, i).map(|v| v.parse::<i64>().is_err()).unwrap_or(false) {
                return Err((78, format!("strconv.Atoi: parsing {:?}: invalid syntax", value_of_current(a, args, i).unwrap())));
            }
            if command != "init" && command != "add-environment" && (name == "--host" || name == "-h" || name == "--schema") {
                return Err((78, "The host option cannot be set via command line for this command. For more information, visit https://www.skeema.io/docs/config/#limitations-on-host-and-schema-options".to_string()));
            }
            if option_takes_value(name) && !a.contains('=') { i += 1; }
        }
        i += 1;
    }
    Ok(())
}

fn value_of_current<'a>(a: &'a str, args: &'a [String], i: usize) -> Option<&'a str> {
    if let Some((_, v)) = a.split_once('=') { Some(v) } else { args.get(i + 1).map(|s| s.as_str()) }
}

fn option_value(args: &[String], long: &str, short: &str, default: &str) -> String {
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if let Some(v) = a.strip_prefix(&(long.to_owned() + "=")) { return v.to_string(); }
        if a == long || a == short { if let Some(v) = args.get(i + 1) { return v.clone(); } }
        i += 1;
    }
    default.to_string()
}

fn positionals(args: &[String]) -> Vec<String> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a.starts_with('-') {
            let name = a.split('=').next().unwrap();
            if option_takes_value(name) && !a.contains('=') { i += 2; } else { i += 1; }
        } else { out.push(a.clone()); i += 1; }
    }
    out
}

fn cmd_add_environment(args: &[String]) {
    let pos = positionals(args);
    if pos.is_empty() { error_exit(78, "Too few positional args supplied on command line; command add-environment requires at least 1 args"); }
    if pos.len() > 1 { error_exit(78, &format!("Extra command-line arg {:?} supplied; command add-environment takes a max of 1 args", pos[1])); }
    let env_name = &pos[0];
    let dir = option_value(args, "--dir", "-d", ".");
    let path = Path::new(&dir);
    if !path.is_dir() { error_exit(78, "In add-environment, --dir must refer to a directory that already exists"); }
    let cfg = path.join(".skeema");
    if !cfg.exists() { error_exit(78, &format!("Dir {} does not have an existing .skeema file! Can only use `skeema add-environment` on a dir previously created by `skeema init`", abs_display(path))); }
    let mut content = fs::read_to_string(&cfg).unwrap_or_default();
    if !content.ends_with('\n') { content.push('\n'); }
    content.push('\n');
    content.push_str(&format!("[{}]\n", env_name));
    let host = option_value(args, "--host", "-h", "localhost");
    let port = option_value(args, "--port", "-P", "3306");
    let socket = option_value(args, "--socket", "-S", "/tmp/mysql.sock");
    content.push_str(&format!("host={}\n", host));
    if host == "localhost" && has_option(args, "--socket", "-S") { content.push_str(&format!("socket={}\n", socket)); }
    else { content.push_str(&format!("port={}\n", port)); }
    fs::write(&cfg, content).unwrap();
    warn(&format!("Unable to automatically determine database server's vendor/version. To set manually, use the \"flavor\" option in {}", abs_display(&cfg)));
    info(&format!("Added environment [{}] to {}", env_name, abs_display(&cfg)));
}

fn has_option(args: &[String], long: &str, short: &str) -> bool { args.iter().any(|a| a == long || a == short || a.starts_with(&(long.to_owned()+"="))) }

fn cmd_init(args: &[String]) {
    let host = option_value(args, "--host", "-h", "");
    if host.is_empty() { error_exit(78, "Option --host must be supplied on the command-line"); }
    if has_option(args, "--skip-my-cnf", "") { warn("Option --my-cnf is deprecated. This option will be removed in Skeema v2, and .my.cnf will always be parsed, with additional safety logic already in place. For more information, visit https://www.skeema.io/v2-changes"); }
    let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let dir = option_value(args, "--dir", "-d", &host);
    let base = cwd.join(dir);
    if host == "localhost" {
        let sock = option_value(args, "--socket", "-S", "/tmp/mysql.sock");
        error_exit(2, &format!("Unable to connect to localhost:{} for {}: dial unix {}: connect: no such file or directory", sock, base.display(), sock));
    } else if host.parse::<std::net::IpAddr>().is_ok() {
        let port = option_value(args, "--port", "-P", "3306");
        error_exit(2, &format!("Unable to connect to {}:{} for {}: dial tcp {}:{}: connect: connection refused", host, port, base.display(), host, port));
    } else {
        let port = option_value(args, "--port", "-P", "3306");
        error_exit(2, &format!("Unable to connect to {}:{} for {}: dial tcp: lookup {} on 192.168.65.7:53: dial udp 192.168.65.7:53: connect: network is unreachable", host, port, base.display(), host));
    }
}

fn cmd_lint(args: &[String]) {
    info(&format!("Linting {}", env::current_dir().unwrap().display()));
    if has_sql_files(Path::new(".")) && !Path::new(".skeema").exists() {
        let cwd = env::current_dir().unwrap();
        error(&format!("Skipping directory {} due to error: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment {:?}", cwd.file_name().unwrap_or_default().to_string_lossy(), environment_name(args)));
        error_exit(78, "Skipped 1 operation due to fatal errors");
    }
}

fn cmd_format(args: &[String]) {
    if has_option(args, "--skip-write", "") { info(&format!("Checking format of {}", env::current_dir().unwrap().display())); }
    else { info(&format!("Reformatting {}", env::current_dir().unwrap().display())); }
    if has_sql_files(Path::new(".")) && !Path::new(".skeema").exists() {
        let cwd = env::current_dir().unwrap();
        error_exit(78, &format!("Skipping {}: This command needs either a host (with workspace=temp-schema) or flavor (with workspace=docker), but one is not configured for environment {:?}", cwd.display(), environment_name(args)));
    }
}

fn environment_name(args: &[String]) -> String { positionals(args).get(0).cloned().unwrap_or_else(|| "production".to_string()) }

fn has_sql_files(path: &Path) -> bool {
    if let Ok(rd) = fs::read_dir(path) {
        for ent in rd.flatten() {
            let p = ent.path();
            if p.file_name().map(|n| n == ".git").unwrap_or(false) { continue; }
            if p.extension().map(|e| e == "sql").unwrap_or(false) { return true; }
        }
    }
    false
}

fn abs_display(path: &Path) -> String { fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf()).display().to_string() }

fn log(level: &str, msg: &str) {
    let spaces = if level.len() < 5 { "  " } else { " " };
    eprintln!("{} [{}]{}{}", timestamp(), level, spaces, msg);
}
fn info(msg: &str) { log("INFO", msg); }
fn warn(msg: &str) { log("WARN", msg); }
fn error(msg: &str) { log("ERROR", msg); }
fn error_exit<T: AsRef<str>>(code: i32, msg: T) -> ! { error(msg.as_ref()); process::exit(code); }

fn timestamp() -> String {
    let secs = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() as i64;
    let days = secs.div_euclid(86400);
    let sod = secs.rem_euclid(86400);
    let (y, m, d) = civil_from_days(days);
    format!("{:04}-{:02}-{:02} {:02}:{:02}:{:02}", y, m, d, sod / 3600, (sod / 60) % 60, sod % 60)
}

fn civil_from_days(z: i64) -> (i64, i64, i64) {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = mp + if mp < 10 { 3 } else { -9 };
    (y + if m <= 2 { 1 } else { 0 }, m, d)
}
