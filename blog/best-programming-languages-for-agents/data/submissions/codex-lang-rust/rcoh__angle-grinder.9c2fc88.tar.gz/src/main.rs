use regex::Regex;
use serde_json::{Number, Value as Json};
use std::cmp::Ordering;
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::fs;
use std::io::{self, BufRead};

#[derive(Debug, Default)]
struct Args {
    file: Option<String>,
    format: Option<String>,
    output: Vec<String>,
    _alias_dir: Option<String>,
    _no_alias: bool,
    query: Option<String>,
}

#[derive(Clone, Debug)]
enum Val {
    Null,
    Bool(bool),
    Num(f64),
    Str(String),
    Arr(Vec<Val>),
    Obj(BTreeMap<String, Val>),
}

impl Val {
    fn as_num(&self) -> Option<f64> {
        match self {
            Val::Num(n) => Some(*n),
            Val::Str(s) => s.parse().ok(),
            Val::Bool(b) => Some(if *b { 1.0 } else { 0.0 }),
            _ => None,
        }
    }
    fn truthy(&self) -> bool {
        match self {
            Val::Null => false,
            Val::Bool(b) => *b,
            Val::Num(n) => *n != 0.0,
            Val::Str(s) => !s.is_empty(),
            Val::Arr(a) => !a.is_empty(),
            Val::Obj(o) => !o.is_empty(),
        }
    }
    fn key(&self) -> String {
        match self {
            Val::Null => "null".into(),
            Val::Bool(b) => b.to_string(),
            Val::Num(n) => fmt_num(*n),
            Val::Str(s) => s.clone(),
            Val::Arr(a) => format!("[{}]", a.iter().map(|v| v.key()).collect::<Vec<_>>().join(", ")),
            Val::Obj(o) => {
                let mut m = serde_json::Map::new();
                for (k, v) in o { m.insert(k.clone(), v.to_json()); }
                Json::Object(m).to_string()
            }
        }
    }
    fn to_json(&self) -> Json {
        match self {
            Val::Null => Json::Null,
            Val::Bool(b) => Json::Bool(*b),
            Val::Num(n) if n.is_finite() && n.fract() == 0.0 => Json::Number(Number::from(*n as i64)),
            Val::Num(n) => Number::from_f64(*n).map(Json::Number).unwrap_or(Json::Null),
            Val::Str(s) => Json::String(s.clone()),
            Val::Arr(a) => Json::Array(a.iter().map(|v| v.to_json()).collect()),
            Val::Obj(o) => {
                let mut m = serde_json::Map::new();
                for (k, v) in o { m.insert(k.clone(), v.to_json()); }
                Json::Object(m)
            }
        }
    }
}

fn fmt_num(n: f64) -> String {
    if n.is_finite() && n.fract() == 0.0 {
        format!("{}", n as i64)
    } else {
        let mut s = format!("{:.6}", n);
        while s.contains('.') && s.ends_with('0') { s.pop(); }
        if s.ends_with('.') { s.pop(); }
        s
    }
}

#[derive(Clone, Debug)]
struct Row {
    raw: String,
    fields: Vec<(String, Val)>,
}

impl Row {
    fn new(raw: String) -> Self { Self { raw, fields: Vec::new() } }
    fn get(&self, name: &str) -> Option<Val> {
        if name == "_raw" || name == "raw" { return Some(Val::Str(self.raw.clone())); }
        let (base, rest) = split_path(name);
        let mut v = self.fields.iter().rev().find(|(k, _)| k == &base).map(|(_, v)| v.clone())?;
        for p in rest {
            match (p, v) {
                (PathPart::Index(i), Val::Arr(a)) => {
                    let idx = if i < 0 { a.len() as isize + i } else { i } as usize;
                    v = a.get(idx).cloned().unwrap_or(Val::Null);
                }
                (PathPart::Key(k), Val::Obj(o)) => {
                    v = o.get(&k).cloned().unwrap_or(Val::Null);
                }
                _ => return Some(Val::Null),
            }
        }
        Some(v)
    }
    fn set(&mut self, key: String, val: Val) {
        if let Some((_, v)) = self.fields.iter_mut().find(|(k, _)| k == &key) {
            *v = val;
        } else {
            self.fields.push((key, val));
        }
    }
    fn keep_only(&mut self, keys: &[String]) {
        self.fields.retain(|(k, _)| keys.iter().any(|x| x == k));
    }
    fn drop_keys(&mut self, keys: &[String]) {
        self.fields.retain(|(k, _)| !keys.iter().any(|x| x == k));
    }
}

#[derive(Clone)]
enum PathPart { Key(String), Index(isize) }

fn split_path(name: &str) -> (String, Vec<PathPart>) {
    if name.starts_with("[\"") && name.ends_with("\"]") {
        return (name[2..name.len()-2].to_string(), Vec::new());
    }
    let mut base = String::new();
    let mut parts = Vec::new();
    let mut cur = String::new();
    let mut chars = name.chars().peekable();
    let mut first = true;
    while let Some(ch) = chars.next() {
        match ch {
            '.' => {
                if first { base = cur.clone(); first = false; } else { parts.push(PathPart::Key(cur.clone())); }
                cur.clear();
            }
            '[' => {
                if first { base = cur.clone(); first = false; } else if !cur.is_empty() { parts.push(PathPart::Key(cur.clone())); }
                cur.clear();
                let mut idx = String::new();
                for c in chars.by_ref() {
                    if c == ']' { break; }
                    idx.push(c);
                }
                parts.push(PathPart::Index(idx.parse().unwrap_or(0)));
            }
            _ => cur.push(ch),
        }
    }
    if first { (cur, parts) } else { if !cur.is_empty() { parts.push(PathPart::Key(cur)); } (base, parts) }
}

#[derive(Clone, Copy, PartialEq)]
enum OutFmt { Legacy, Json, Logfmt, Custom }

fn main() {
    let args = parse_args();
    let query = args.query.unwrap_or_else(|| "*".to_string());
    let mut out = OutFmt::Legacy;
    let mut custom = args.format.clone();
    if custom.is_some() { out = OutFmt::Custom; }
    for o in &args.output {
        if o == "json" { out = OutFmt::Json; }
        else if o == "logfmt" { out = OutFmt::Logfmt; }
        else if let Some(f) = o.strip_prefix("format=") { out = OutFmt::Custom; custom = Some(f.to_string()); }
        else if o == "legacy" { out = OutFmt::Legacy; }
    }
    let input = if let Some(path) = args.file {
        fs::read_to_string(path).unwrap_or_else(|e| { eprintln!("error: {}", e); std::process::exit(1); })
    } else {
        let mut s = String::new();
        for line in io::stdin().lock().lines() {
            s.push_str(&line.unwrap_or_default());
            s.push('\n');
        }
        s
    };
    match run(&query, &input) {
        Ok(rows) => render(rows, out, custom.as_deref()),
        Err(e) => { eprintln!("error: {}", e); std::process::exit(1); }
    }
}

fn parse_args() -> Args {
    let mut args = Args::default();
    let mut it = std::env::args().skip(1).peekable();
    while let Some(a) = it.next() {
        match a.as_str() {
            "-h" | "--help" => { print_help(); std::process::exit(0); }
            "-V" | "--version" => { println!("ag 0.19.6"); std::process::exit(0); }
            "-f" | "--file" => args.file = it.next(),
            "-m" | "--format" => args.format = it.next(),
            "-o" | "--output" => if let Some(v) = it.next() { args.output.push(v); },
            "-a" | "--alias-dir" => args._alias_dir = it.next(),
            "--no-alias" => args._no_alias = true,
            x if x.starts_with("--file=") => args.file = Some(x[7..].to_string()),
            x if x.starts_with("--format=") => args.format = Some(x[9..].to_string()),
            x if x.starts_with("--output=") => args.output.push(x[9..].to_string()),
            x if x.starts_with("--alias-dir=") => args._alias_dir = Some(x[12..].to_string()),
            _ => args.query = Some(a),
        }
    }
    args
}

fn print_help() {
    println!("Usage: executable [OPTIONS] [QUERY]\n\nArguments:\n  [QUERY]\n          The query\n\nOptions:\n  -f, --file <FILE>\n          Optionally reads from a file instead of Stdin\n\n  -m, --format <FORMAT>\n          DEPRECATED. Use -o format=... instead. Provide a Rust std::fmt string to format output\n\n  -o, --output <OUTPUT>\n          Set output format. Options: \n          - `json`,\n          - `logfmt`\n          - `format=<rust format string>` (eg. -o format='{{src}} => {{dst}}'\n          - `legacy` The original output format, auto aligning [k=v]\n\n  -a, --alias-dir <ALIAS_DIR>\n          Specifies an alternative directory to use for aliases. Defaults to `.agrind-aliases` in all parent directories.\n\n      --no-alias\n          Disables aliases\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n\nFor more details + docs, see https://github.com/rcoh/angle-grinder");
}

fn run(query: &str, input: &str) -> Result<Vec<Row>, String> {
    let parts = split_pipeline(query);
    let filter = parts.first().cloned().unwrap_or_else(|| "*".into());
    let mut rows: Vec<Row> = input.lines()
        .filter(|l| eval_filter(&filter, l))
        .map(|l| Row::new(l.to_string()))
        .collect();
    for op in parts.into_iter().skip(1) {
        rows = apply_op(rows, op.trim())?;
    }
    Ok(rows)
}

fn split_pipeline(q: &str) -> Vec<String> {
    let mut res = Vec::new();
    let mut cur = String::new();
    let mut quote = false;
    let mut esc = false;
    for ch in q.chars() {
        if esc { cur.push(ch); esc = false; continue; }
        if ch == '\\' { cur.push(ch); esc = true; continue; }
        if ch == '"' { quote = !quote; cur.push(ch); continue; }
        if ch == '|' && !quote { res.push(cur.trim().to_string()); cur.clear(); } else { cur.push(ch); }
    }
    if !cur.trim().is_empty() { res.push(cur.trim().to_string()); }
    res
}

fn eval_filter(expr: &str, line: &str) -> bool {
    let e = expr.trim();
    if e.is_empty() || e == "*" { return true; }
    eval_filter_or(e, line)
}

fn strip_parens(mut s: &str) -> &str {
    loop {
        let t = s.trim();
        if t.starts_with('(') && t.ends_with(')') { s = &t[1..t.len()-1]; } else { return t; }
    }
}

fn eval_filter_or(expr: &str, line: &str) -> bool {
    let expr = strip_parens(expr);
    for p in split_word_top(expr, "OR") {
        if eval_filter_and(&p, line) { return true; }
    }
    false
}
fn eval_filter_and(expr: &str, line: &str) -> bool {
    for p in split_word_top(strip_parens(expr), "AND") {
        let t = p.trim();
        let ok = if let Some(rest) = t.strip_prefix("NOT ") {
            !eval_filter_or(rest, line)
        } else if strip_parens(t).contains(" OR ") || (t.starts_with('(') && t.ends_with(')')) {
            eval_filter_or(t, line)
        } else {
            eval_filter_atom(t, line)
        };
        if !ok { return false; }
    }
    true
}
fn eval_filter_atom(atom: &str, line: &str) -> bool {
    let a = strip_parens(atom);
    if a == "*" { return true; }
    if a.starts_with('"') && a.ends_with('"') && a.len() >= 2 { return line.contains(&a[1..a.len()-1]); }
    let mut pat = String::from("(?i)");
    for ch in a.chars() {
        if ch == '*' { pat.push_str(".*"); } else { pat.push_str(&regex::escape(&ch.to_string())); }
    }
    Regex::new(&pat).map(|r| r.is_match(line)).unwrap_or(false)
}
fn split_word_top(s: &str, word: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut depth = 0i32; let mut quote=false; let mut start=0usize;
    let bytes = s.as_bytes(); let w = word.as_bytes(); let mut i=0;
    while i + w.len() <= bytes.len() {
        let ch = bytes[i] as char;
        if ch == '"' { quote = !quote; i+=1; continue; }
        if !quote {
            if ch == '(' { depth += 1; }
            if ch == ')' { depth -= 1; }
            if depth == 0 && &bytes[i..i+w.len()] == w {
                let before = i == 0 || bytes[i-1].is_ascii_whitespace();
                let after = i+w.len() == bytes.len() || bytes[i+w.len()].is_ascii_whitespace();
                if before && after { out.push(s[start..i].trim().to_string()); i += w.len(); start = i; continue; }
            }
        }
        i += 1;
    }
    out.push(s[start..].trim().to_string()); out
}

fn apply_op(mut rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    if op == "json" || op.starts_with("json ") {
        let from = op.strip_prefix("json from ").map(str::trim);
        rows.retain_mut(|r| {
            let src = from.and_then(|f| r.get(f).map(|v| v.key())).unwrap_or_else(|| r.raw.clone());
            match serde_json::from_str::<Json>(&src) {
                Ok(Json::Object(map)) => {
                    for (k, v) in map { r.set(k, json_to_val(v)); }
                    true
                }
                _ => false,
            }
        });
        return Ok(rows);
    }
    if op == "logfmt" || op.starts_with("logfmt ") {
        let from = op.strip_prefix("logfmt from ").map(str::trim);
        rows.retain_mut(|r| {
            let src = from.and_then(|f| r.get(f).map(|v| v.key())).unwrap_or_else(|| r.raw.clone());
            let kv = parse_logfmt(&src);
            if kv.is_empty() { return false; }
            for (k, v) in kv { r.set(k, auto_val(&v)); }
            true
        });
        return Ok(rows);
    }
    if op.starts_with("parse regex ") { return parse_regex(rows, op); }
    if op.starts_with("parse ") { return parse_glob(rows, op); }
    if op.starts_with("split") { return split_op(rows, op); }
    if op.starts_with("fields") { return fields_op(rows, op); }
    if op.starts_with("total(") { return total_op(rows, op); }
    if let Some(cond) = op.strip_prefix("where ") {
        let mut out = Vec::new();
        for r in rows {
            match eval_expr(cond, &r) {
                Ok(v) if v.truthy() => out.push(r),
                Ok(_) => {}
                Err(e) => eprintln!("error: {}", e),
            }
        }
        return Ok(out);
    }
    if let Some(n) = op.strip_prefix("limit ") {
        let n: isize = n.trim().parse().map_err(|_| "invalid limit".to_string())?;
        if n >= 0 { rows.truncate(n as usize); } else {
            let keep = (-n) as usize;
            if rows.len() > keep { rows = rows.split_off(rows.len() - keep); }
        }
        return Ok(rows);
    }
    if op.starts_with("sort by ") { return sort_rows(rows, op); }
    if is_aggregate(op) { return aggregate(rows, op); }
    if let Some((expr, name)) = split_as(op) {
        for r in &mut rows {
            match eval_expr(expr.trim(), r) { Ok(v) => r.set(name.trim().to_string(), v), Err(e) => eprintln!("error: {}", e) }
        }
        return Ok(rows);
    }
    Ok(rows)
}

fn json_to_val(j: Json) -> Val {
    match j {
        Json::Null => Val::Null, Json::Bool(b) => Val::Bool(b),
        Json::Number(n) => Val::Num(n.as_f64().unwrap_or(0.0)),
        Json::String(s) => auto_val(&s),
        Json::Array(a) => Val::Arr(a.into_iter().map(json_to_val).collect()),
        Json::Object(map) => Val::Obj(map.into_iter().map(|(k, v)| (k, json_to_val(v))).collect()),
    }
}
fn auto_val(s: &str) -> Val {
    if s == "null" { Val::Null }
    else if s == "true" { Val::Bool(true) }
    else if s == "false" { Val::Bool(false) }
    else if let Ok(n) = s.parse::<f64>() { Val::Num(n) }
    else { Val::Str(s.to_string()) }
}
fn parse_logfmt(s: &str) -> Vec<(String, String)> {
    let re = Regex::new(r#"([A-Za-z0-9_.-]+)=("[^"]*"|\S+)"#).unwrap();
    re.captures_iter(s).map(|c| {
        let mut v = c[2].to_string();
        if v.starts_with('"') && v.ends_with('"') { v = v[1..v.len()-1].to_string(); }
        (c[1].to_string(), v)
    }).collect()
}

fn parse_regex(mut rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    let nodrop = op.contains(" nodrop");
    let from = capture_after(op, " from ");
    let re_txt = quoted_after(op, "parse regex ").ok_or("invalid parse regex")?;
    let re = Regex::new(&re_txt).map_err(|e| e.to_string())?;
    rows.retain_mut(|r| {
        let src = from.as_deref().and_then(|f| r.get(f).map(|v| v.key())).unwrap_or_else(|| r.raw.clone());
        if let Some(c) = re.captures(&src) {
            for name in re.capture_names().flatten() {
                if let Some(m) = c.name(name) { r.set(name.to_string(), auto_val(m.as_str())); }
            }
            true
        } else { nodrop }
    });
    Ok(rows)
}

fn parse_glob(mut rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    let nodrop = op.contains(" nodrop");
    let noconv = op.contains(" noconvert");
    let pat = quoted_after(op, "parse ").ok_or("invalid parse")?;
    let mut names_s = op.split(" as ").nth(1).ok_or("invalid parse")?.to_string();
    for marker in [" nodrop", " noconvert"] {
        if let Some(i) = names_s.find(marker) {
            names_s.truncate(i);
        }
    }
    let names: Vec<String> = names_s
        .split(',').map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect();
    let from = capture_after(op, " from ");
    let re = glob_regex(&pat);
    rows.retain_mut(|r| {
        let src = from.as_deref().and_then(|f| r.get(f).map(|v| v.key())).unwrap_or_else(|| r.raw.clone());
        if let Some(c) = re.captures(&src) {
            for (i, name) in names.iter().enumerate() {
                if let Some(m) = c.get(i+1) {
                    r.set(name.clone(), if noconv { Val::Str(m.as_str().to_string()) } else { auto_val(m.as_str()) });
                }
            }
            true
        } else { nodrop }
    });
    Ok(rows)
}
fn glob_regex(pat: &str) -> Regex {
    let mut s = String::from("(?s)^");
    for (i, part) in pat.split('*').enumerate() {
        if i > 0 { s.push_str("(.*)"); }
        let mut esc = regex::escape(part);
        esc = esc.replace(r"\ ", r"\s+");
        s.push_str(&esc);
    }
    s.push('$');
    Regex::new(&s).unwrap()
}
fn quoted_after(s: &str, prefix: &str) -> Option<String> {
    let rest = s.strip_prefix(prefix)?.trim_start();
    if !rest.starts_with('"') { return None; }
    let mut out = String::new(); let mut esc = false;
    for ch in rest[1..].chars() {
        if esc { out.push(ch); esc=false; continue; }
        if ch == '\\' { esc=true; continue; }
        if ch == '"' { return Some(out); }
        out.push(ch);
    }
    None
}
fn capture_after(s: &str, key: &str) -> Option<String> {
    s.find(key).map(|i| s[i+key.len()..].split_whitespace().next().unwrap_or("").trim_matches(',').to_string()).filter(|x| !x.is_empty())
}

fn split_op(mut rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    let input_field = Regex::new(r"split\(([^)]+)\)").unwrap().captures(op).map(|c| c[1].trim().to_string());
    let sep = if let Some(i) = op.find(" on ") { quoted_after(&op[i+4..], "").unwrap_or_else(|| ",".to_string()) } else { ",".to_string() };
    let out_field = if let Some(i) = op.find(" as ") { Some(op[i+4..].trim().to_string()) } else { input_field.clone().or(Some("_split".into())) };
    for r in &mut rows {
        let src = input_field.as_deref().and_then(|f| r.get(f).map(|v| v.key())).unwrap_or_else(|| r.raw.clone());
        let vals = src.split(&sep).map(|s| auto_val(s.trim_matches('"'))).collect();
        r.set(out_field.clone().unwrap(), Val::Arr(vals));
    }
    Ok(rows)
}

fn fields_op(mut rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    let rest = op.strip_prefix("fields").unwrap().trim();
    let (only, list) = if let Some(x) = rest.strip_prefix("only ") { (true, x) }
        else if let Some(x) = rest.strip_prefix("+ ") { (true, x) }
        else if let Some(x) = rest.strip_prefix("except ") { (false, x) }
        else if let Some(x) = rest.strip_prefix("- ") { (false, x) }
        else { (true, rest) };
    let keys: Vec<String> = list.split(',').map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect();
    for r in &mut rows { if only { r.keep_only(&keys); } else { r.drop_keys(&keys); } }
    Ok(rows)
}

fn total_op(mut rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    let (base, alias) = split_as(op).map(|(a, b)| (a.trim(), b.trim().to_string())).unwrap_or((op.trim(), "_total".to_string()));
    let field = inside(base);
    let mut total = 0.0;
    for r in &mut rows {
        if let Some(n) = r.get(&field).and_then(|v| v.as_num()) {
            total += n;
        }
        r.set(alias.clone(), Val::Num(total));
    }
    Ok(rows)
}

fn is_aggregate(op: &str) -> bool {
    ["count", "sum(", "average(", "avg(", "min(", "max(", "p", "pct", "count_distinct("]
        .iter().any(|p| op.trim_start().starts_with(p))
}

#[derive(Clone)]
enum AggKind { Count(Option<String>), Sum(String), Avg(String), Min(String), Max(String), Pct(String, f64), Cd(String) }
#[derive(Clone)]
struct AggSpec { kind: AggKind, name: String }
#[derive(Default, Clone)]
struct AggState { count: usize, sum: f64, min: Option<f64>, max: Option<f64>, vals: Vec<f64>, set: BTreeSet<String> }

fn aggregate(rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    let (agg_s, by_s) = if let Some(i) = op.find(" by ") { (&op[..i], Some(&op[i+4..])) } else { (op, None) };
    let specs = parse_aggs(agg_s)?;
    let by: Vec<String> = by_s.map(|s| s.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect()).unwrap_or_default();
    let mut groups: BTreeMap<Vec<String>, Vec<AggState>> = BTreeMap::new();
    let mut key_vals: HashMap<Vec<String>, Vec<Val>> = HashMap::new();
    for r in &rows {
        let kvals: Vec<Val> = by.iter().map(|b| eval_expr(b, r).unwrap_or_else(|_| r.get(b).unwrap_or(Val::Null))).collect();
        let key: Vec<String> = kvals.iter().map(|v| v.key()).collect();
        key_vals.entry(key.clone()).or_insert(kvals);
        let states = groups.entry(key).or_insert_with(|| vec![AggState::default(); specs.len()]);
        for (st, sp) in states.iter_mut().zip(&specs) {
            match &sp.kind {
                AggKind::Count(cond) => {
                    if cond.as_ref().map(|c| eval_expr(c, r).map(|v| v.truthy()).unwrap_or(false)).unwrap_or(true) { st.count += 1; }
                }
                AggKind::Sum(f) | AggKind::Avg(f) | AggKind::Min(f) | AggKind::Max(f) | AggKind::Pct(f, _) => {
                    if let Ok(v) = eval_expr(f, r) { if let Some(n) = v.as_num() {
                        st.count += 1; st.sum += n; st.vals.push(n);
                        st.min = Some(st.min.map(|m| m.min(n)).unwrap_or(n)); st.max = Some(st.max.map(|m| m.max(n)).unwrap_or(n));
                    }}
                }
                AggKind::Cd(f) => { if let Ok(v) = eval_expr(f, r) { st.set.insert(v.key()); } }
            }
        }
    }
    let mut out = Vec::new();
    for (key, states) in groups {
        let mut r = Row::new(String::new());
        for (i, b) in by.iter().enumerate() { r.set(b.clone(), key_vals.get(&key).and_then(|v| v.get(i).cloned()).unwrap_or(Val::Str(key[i].clone()))); }
        for (st, sp) in states.iter().zip(&specs) {
            let v = match sp.kind {
                AggKind::Count(_) => Val::Num(st.count as f64),
                AggKind::Sum(_) => Val::Num(st.sum),
                AggKind::Avg(_) => Val::Num(if st.count > 0 { st.sum / st.count as f64 } else { 0.0 }),
                AggKind::Min(_) => Val::Num(st.min.unwrap_or(0.0)),
                AggKind::Max(_) => Val::Num(st.max.unwrap_or(0.0)),
                AggKind::Pct(_, p) => {
                    let mut vals = st.vals.clone(); vals.sort_by(|a,b| a.partial_cmp(b).unwrap_or(Ordering::Equal));
                    if vals.is_empty() { Val::Null } else { Val::Num(vals[((vals.len()-1) as f64 * p / 100.0).floor() as usize]) }
                }
                AggKind::Cd(_) => Val::Num(st.set.len() as f64),
            };
            r.set(sp.name.clone(), v);
        }
        out.push(r);
    }
    out.reverse();
    Ok(out)
}

fn parse_aggs(s: &str) -> Result<Vec<AggSpec>, String> {
    let mut v = Vec::new();
    for part in split_commas(s) {
        let (base, alias) = split_as(&part).map(|(a,b)| (a.trim().to_string(), Some(b.trim().to_string()))).unwrap_or((part.trim().to_string(), None));
        let spec = if base == "count" {
            AggSpec { kind: AggKind::Count(None), name: alias.unwrap_or("_count".into()) }
        } else if base.starts_with("count(") {
            let inner = inside(&base); AggSpec { kind: AggKind::Count(Some(inner)), name: alias.unwrap_or("_count".into()) }
        } else if base.starts_with("sum(") {
            AggSpec { kind: AggKind::Sum(inside(&base)), name: alias.unwrap_or("_sum".into()) }
        } else if base.starts_with("average(") || base.starts_with("avg(") {
            AggSpec { kind: AggKind::Avg(inside(&base)), name: alias.unwrap_or("_average".into()) }
        } else if base.starts_with("min(") {
            AggSpec { kind: AggKind::Min(inside(&base)), name: alias.unwrap_or("_min".into()) }
        } else if base.starts_with("max(") {
            AggSpec { kind: AggKind::Max(inside(&base)), name: alias.unwrap_or("_max".into()) }
        } else if base.starts_with("count_distinct(") {
            AggSpec { kind: AggKind::Cd(inside(&base)), name: alias.unwrap_or("count_distinct".into()) }
        } else if base.starts_with('p') || base.starts_with("pct") {
            let digits: String = base.chars().filter(|c| c.is_ascii_digit()).collect();
            let p = digits.parse().unwrap_or(50.0);
            AggSpec { kind: AggKind::Pct(inside(&base), p), name: alias.unwrap_or(format!("p{}", digits)) }
        } else { return Err(format!("unknown aggregate {}", base)); };
        v.push(spec);
    }
    Ok(v)
}
fn inside(s: &str) -> String { s[s.find('(').unwrap()+1..s.rfind(')').unwrap_or(s.len())].trim().to_string() }
fn split_as(s: &str) -> Option<(&str, &str)> { s.rfind(" as ").map(|i| (&s[..i], &s[i+4..])) }
fn split_commas(s: &str) -> Vec<String> {
    let mut out=Vec::new(); let mut start=0; let mut depth=0i32; let mut quote=false;
    for (i,ch) in s.char_indices() {
        if ch=='"' { quote=!quote; }
        if !quote { if ch=='(' { depth+=1; } else if ch==')' { depth-=1; } else if ch==',' && depth==0 { out.push(s[start..i].trim().to_string()); start=i+1; } }
    }
    out.push(s[start..].trim().to_string()); out
}

fn sort_rows(mut rows: Vec<Row>, op: &str) -> Result<Vec<Row>, String> {
    let rest = op.strip_prefix("sort by ").unwrap().trim();
    let desc = rest.ends_with(" desc");
    let asc = rest.ends_with(" asc");
    let exprs = rest.trim_end_matches(" desc").trim_end_matches(" asc");
    let keys = split_commas(exprs);
    rows.sort_by(|a,b| {
        for k in &keys {
            let av = eval_expr(k, a).unwrap_or(Val::Null).key();
            let bv = eval_expr(k, b).unwrap_or(Val::Null).key();
            let ord = match (av.parse::<f64>(), bv.parse::<f64>()) { (Ok(x), Ok(y)) => x.partial_cmp(&y).unwrap_or(Ordering::Equal), _ => av.cmp(&bv) };
            if ord != Ordering::Equal { return if desc && !asc { ord.reverse() } else { ord }; }
        }
        Ordering::Equal
    });
    Ok(rows)
}

fn eval_expr(expr: &str, row: &Row) -> Result<Val, String> {
    let mut p = ExprParser { toks: tokenize(expr), pos: 0, row };
    p.parse_or()
}

#[derive(Clone, Debug, PartialEq)]
enum Tok { Id(String), Num(f64), Str(String), Op(String), Lp, Rp, Comma }
fn tokenize(s: &str) -> Vec<Tok> {
    let mut t=Vec::new(); let mut i=0; let b=s.as_bytes();
    while i<b.len() {
        let c=b[i] as char;
        if c.is_whitespace() { i+=1; continue; }
        if c=='"' {
            let mut j=i+1; let mut out=String::new();
            while j<b.len() { let ch=b[j] as char; if ch=='"' { break; } out.push(ch); j+=1; }
            t.push(Tok::Str(out)); i=j+1; continue;
        }
        if c.is_ascii_digit() || (c=='-' && i+1<b.len() && (b[i+1] as char).is_ascii_digit()) {
            let mut j=i+1; while j<b.len() && ((b[j] as char).is_ascii_digit() || b[j]==b'.') { j+=1; }
            t.push(Tok::Num(s[i..j].parse().unwrap_or(0.0))); i=j; continue;
        }
        if c.is_alphabetic() || c=='_' || c=='[' {
            let mut j=i+1; while j<b.len() && !b[j].is_ascii_whitespace() && !b"(),+-*/<>=!".contains(&b[j]) { j+=1; }
            t.push(Tok::Id(s[i..j].trim_matches(',').to_string())); i=j; continue;
        }
        if c=='(' { t.push(Tok::Lp); i+=1; continue; }
        if c==')' { t.push(Tok::Rp); i+=1; continue; }
        if c==',' { t.push(Tok::Comma); i+=1; continue; }
        let two = if i+1<b.len() { &s[i..i+2] } else { "" };
        if ["==","!=","<>","<=",">=","&&","||"].contains(&two) { t.push(Tok::Op(two.to_string())); i+=2; }
        else { t.push(Tok::Op(c.to_string())); i+=1; }
    }
    t
}
struct ExprParser<'a> { toks: Vec<Tok>, pos: usize, row: &'a Row }
impl<'a> ExprParser<'a> {
    fn peek(&self)->Option<&Tok>{ self.toks.get(self.pos) }
    fn eat_op(&mut self, o:&str)->bool{ if self.peek()==Some(&Tok::Op(o.into())) || self.peek()==Some(&Tok::Id(o.into())) { self.pos+=1; true } else { false } }
    fn parse_or(&mut self)->Result<Val,String>{ let mut v=self.parse_and()?; while self.eat_op("or")||self.eat_op("||"){ let r=self.parse_and()?; v=Val::Bool(v.truthy()||r.truthy()); } Ok(v) }
    fn parse_and(&mut self)->Result<Val,String>{ let mut v=self.parse_cmp()?; while self.eat_op("and")||self.eat_op("&&"){ let r=self.parse_cmp()?; v=Val::Bool(v.truthy()&&r.truthy()); } Ok(v) }
    fn parse_cmp(&mut self)->Result<Val,String>{ let mut v=self.parse_add()?; while let Some(Tok::Op(op))=self.peek().cloned(){ if !["==","!=","<>","<=",">=","<",">"].contains(&op.as_str()){break;} self.pos+=1; let r=self.parse_add()?; v=Val::Bool(compare_vals(&v,&r,&op)); } Ok(v) }
    fn parse_add(&mut self)->Result<Val,String>{ let mut v=self.parse_mul()?; loop{ if self.eat_op("+"){ let r=self.parse_mul()?; v=bin_num(v,r,|a,b|a+b); } else if self.eat_op("-"){ let r=self.parse_mul()?; v=bin_num(v,r,|a,b|a-b); } else {break;} } Ok(v) }
    fn parse_mul(&mut self)->Result<Val,String>{ let mut v=self.parse_unary()?; loop{ if self.eat_op("*"){ let r=self.parse_unary()?; v=bin_num(v,r,|a,b|a*b); } else if self.eat_op("/"){ let r=self.parse_unary()?; v=bin_num(v,r,|a,b|a/b); } else {break;} } Ok(v) }
    fn parse_unary(&mut self)->Result<Val,String>{ if self.eat_op("!") { Ok(Val::Bool(!self.parse_unary()?.truthy())) } else { self.parse_primary() } }
    fn parse_primary(&mut self)->Result<Val,String>{
        match self.peek().cloned() {
            Some(Tok::Num(n)) => { self.pos+=1; Ok(Val::Num(n)) }
            Some(Tok::Str(s)) => { self.pos+=1; Ok(Val::Str(s)) }
            Some(Tok::Lp) => { self.pos+=1; let v=self.parse_or()?; if matches!(self.peek(),Some(Tok::Rp)){self.pos+=1;} Ok(v) }
            Some(Tok::Id(id)) => {
                self.pos+=1;
                if matches!(self.peek(), Some(Tok::Lp)) {
                    self.pos+=1; let mut args=Vec::new();
                    while !matches!(self.peek(), Some(Tok::Rp)|None) { args.push(self.parse_or()?); if matches!(self.peek(), Some(Tok::Comma)){self.pos+=1;} }
                    if matches!(self.peek(), Some(Tok::Rp)){self.pos+=1;}
                    Ok(call_fn(&id,args))
                } else {
                    self.row.get(&id).ok_or_else(|| format!("No value for key \"{}\"", id))
                }
            }
            _ => Ok(Val::Null)
        }
    }
}
fn bin_num(a:Val,b:Val,f:fn(f64,f64)->f64)->Val{ Val::Num(f(a.as_num().unwrap_or(0.0), b.as_num().unwrap_or(0.0))) }
fn compare_vals(a:&Val,b:&Val,op:&str)->bool{
    if let (Some(x),Some(y))=(a.as_num(),b.as_num()) { match op {"=="=>x==y,"!="|"<>"=>x!=y,"<="=>x<=y,">="=>x>=y,"<"=>x<y,">"=>x>y,_=>false} }
    else { let x=a.key(); let y=b.key(); match op {"=="=>x==y,"!="|"<>"=>x!=y,"<="=>x<=y,">="=>x>=y,"<"=>x<y,">"=>x>y,_=>false} }
}
fn call_fn(name:&str,args:Vec<Val>)->Val{
    let n = |i: usize| -> f64 { args.get(i).and_then(|v| v.as_num()).unwrap_or(0.0) };
    let s = |i: usize| -> String { args.get(i).map(|v| v.key()).unwrap_or_default() };
    match name {
        "abs"=>Val::Num(n(0).abs()), "ceil"=>Val::Num(n(0).ceil()), "floor"=>Val::Num(n(0).floor()), "round"=>Val::Num(n(0).round()),
        "sqrt"=>Val::Num(n(0).sqrt()), "sin"=>Val::Num(n(0).sin()), "cos"=>Val::Num(n(0).cos()), "tan"=>Val::Num(n(0).tan()),
        "log"=>Val::Num(n(0).ln()), "log10"=>Val::Num(n(0).log10()), "toDegrees"=>Val::Num(n(0).to_degrees()), "toRadians"=>Val::Num(n(0).to_radians()),
        "concat"=>Val::Str(args.iter().map(|v|v.key()).collect::<Vec<_>>().join("")),
        "contains"=>Val::Bool(s(0).contains(&s(1))), "length"=>Val::Num(s(0).chars().count() as f64),
        "substring"=>{ let st=n(1) as usize; let en=if args.len()>2{n(2) as usize}else{s(0).len()}; Val::Str(s(0).chars().skip(st).take(en.saturating_sub(st)).collect()) },
        "toLowerCase"=>Val::Str(s(0).to_lowercase()), "toUpperCase"=>Val::Str(s(0).to_uppercase()),
        "isNull"=>Val::Bool(matches!(args.get(0),Some(Val::Null)|None)), "isEmpty"=>Val::Bool(matches!(args.get(0),Some(Val::Null)|None) || s(0).is_empty()),
        "isBlank"=>Val::Bool(matches!(args.get(0),Some(Val::Null)|None) || s(0).trim().is_empty()),
        "isNumeric"=>Val::Bool(s(0).parse::<f64>().is_ok()), "num"=>Val::Num(n(0)), "parseHex"=>Val::Num(i64::from_str_radix(s(0).trim_start_matches("0x"),16).unwrap_or(0) as f64),
        "if"=> if args.get(0).map(|v|v.truthy()).unwrap_or(false) { args.get(1).cloned().unwrap_or(Val::Null) } else { args.get(2).cloned().unwrap_or(Val::Null) },
        _=>Val::Null,
    }
}

fn render(rows: Vec<Row>, fmt: OutFmt, custom: Option<&str>) {
    match fmt {
        OutFmt::Json => {
            if rows.iter().any(|r| r.raw.is_empty()) {
                println!("[{}]", rows.iter().map(row_json_string).collect::<Vec<_>>().join(","));
            } else { for r in rows { println!("{}", row_json_string(&r)); } }
        }
        OutFmt::Logfmt => for r in rows { println!("{}", r.fields.iter().map(|(k,v)| format!("{}={}", k, quote_logfmt(&v.key()))).collect::<Vec<_>>().join(" ")); },
        OutFmt::Custom => for r in rows { println!("{}", apply_format(custom.unwrap_or(""), &r)); },
        OutFmt::Legacy => {
            if rows.iter().all(|r| r.raw.is_empty()) { table(rows); }
            else { for r in rows { if r.fields.is_empty(){ println!("{}", r.raw); } else { println!("{}", legacy_row(&r)); } } }
        }
    }
}
fn row_json_string(r:&Row)->String {
    format!("{{{}}}", r.fields.iter().map(|(k,v)| {
        format!("{}:{}", serde_json::to_string(k).unwrap(), val_json_string(v))
    }).collect::<Vec<_>>().join(","))
}
fn val_json_string(v:&Val)->String {
    match v {
        Val::Null => "null".into(),
        Val::Bool(b) => b.to_string(),
        Val::Num(n) if n.is_finite() && n.fract() == 0.0 => (*n as i64).to_string(),
        Val::Num(n) => fmt_num(*n),
        Val::Str(s) => serde_json::to_string(s).unwrap(),
        Val::Arr(a) => format!("[{}]", a.iter().map(val_json_string).collect::<Vec<_>>().join(",")),
        Val::Obj(o) => format!("{{{}}}", o.iter().map(|(k,v)| format!("{}:{}", serde_json::to_string(k).unwrap(), val_json_string(v))).collect::<Vec<_>>().join(",")),
    }
}
fn quote_logfmt(s:&str)->String{ if s.contains(' ') { format!("\"{}\"", s.replace('"',"\\\"")) } else { s.to_string() } }
fn legacy_row(r:&Row)->String{ r.fields.iter().map(|(k,v)| format!("[{}={}]", k, v.key())).collect::<Vec<_>>().join("        ") }
fn apply_format(f:&str,r:&Row)->String{ let re=Regex::new(r"\{([^}]+)\}").unwrap(); re.replace_all(f, |c:&regex::Captures| r.get(&c[1]).map(|v|v.key()).unwrap_or_default()).to_string() }
fn table(rows: Vec<Row>) {
    if rows.is_empty(){return;}
    let headers: Vec<String> = rows[0].fields.iter().map(|(k,_)|k.clone()).collect();
    let mut widths: Vec<usize> = headers.iter().map(|h| h.len()).collect();
    let vals: Vec<Vec<String>> = rows.iter().map(|r| headers.iter().map(|h| r.get(h).map(|v|v.key()).unwrap_or_default()).collect()).collect();
    for row in &vals { for (i,v) in row.iter().enumerate(){ widths[i]=widths[i].max(v.len()); } }
    println!("{}", headers.iter().enumerate().map(|(i,h)| format!("{:<width$}", h, width=widths[i])).collect::<Vec<_>>().join("        "));
    println!("{}", "-".repeat(widths.iter().sum::<usize>() + 8*(widths.len().saturating_sub(1))));
    for row in vals { println!("{}", row.iter().enumerate().map(|(i,v)| format!("{:<width$}", v, width=widths[i])).collect::<Vec<_>>().join("        ")); }
}
