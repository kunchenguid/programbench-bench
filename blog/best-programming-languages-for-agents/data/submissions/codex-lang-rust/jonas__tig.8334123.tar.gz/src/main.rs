use std::env;
use std::io::{self, IsTerminal, Read};
use std::path::Path;
use std::process::{Command, ExitCode, Stdio};

const VERSION: &str = "2.6.0-g87c9c25";

const HELP: &str = concat!(
    "tig 2.6.0-g87c9c25 \n",
    "\n",
    "Usage: tig        [options] [revs] [--] [paths]\n",
    "   or: tig log    [options] [revs] [--] [paths]\n",
    "   or: tig show   [options] [revs] [--] [paths]\n",
    "   or: tig reflog [options] [revs]\n",
    "   or: tig blame  [options] [rev] [--] path\n",
    "   or: tig grep   [options] [pattern]\n",
    "   or: tig refs   [options]\n",
    "   or: tig stash  [options]\n",
    "   or: tig status\n",
    "   or: tig <      [git command output]\n",
    "\n",
    "Options:\n",
    "  +<number>       Select line <number> in the first view\n",
    "  -v, --version   Show version and exit\n",
    "  -h, --help      Show help message and exit\n",
    "  -C <path>       Start in <path>\n",
);

fn main() -> ExitCode {
    let mut args: Vec<String> = env::args().skip(1).collect();

    if args.iter().any(|a| a == "-h" || a == "--help") {
        print!("{}", HELP);
        return ExitCode::SUCCESS;
    }

    if args.iter().any(|a| a == "-v" || a == "--version") {
        println!("tig version {}", VERSION);
        println!("ncursesw version 6.3.20211021");
        return ExitCode::SUCCESS;
    }

    if let Err(message) = handle_chdir(&mut args) {
        eprintln!("tig: {}", message);
        return ExitCode::from(1);
    }

    if should_report_no_revisions(&args) {
        eprintln!("tig: No revisions match the given arguments.");
        return ExitCode::from(1);
    }

    if !io::stdin().is_terminal() {
        let mut sink = Vec::new();
        let _ = io::stdin().read_to_end(&mut sink);
        eprintln!("tig: Failed to open tty for input");
        return ExitCode::from(1);
    }

    if !can_open_tty() {
        eprintln!("tig: Failed to open tty for input");
        return ExitCode::from(1);
    }

    run_tty_fallback(&args)
}

fn handle_chdir(args: &mut Vec<String>) -> Result<(), String> {
    let mut i = 0;
    while i < args.len() {
        let arg = args[i].clone();
        if arg == "-C" {
            if i + 1 >= args.len() {
                return Ok(());
            }
            let path = args.remove(i + 1);
            args.remove(i);
            if let Err(_) = env::set_current_dir(&path) {
                return Err(format!("Failed to change directory to {}", path));
            }
            continue;
        }
        if let Some(path) = arg.strip_prefix("-C") {
            if !path.is_empty() {
                args.remove(i);
                if let Err(_) = env::set_current_dir(path) {
                    return Err(format!("Failed to change directory to {}", path));
                }
                continue;
            }
        }
        i += 1;
    }
    Ok(())
}

fn should_report_no_revisions(args: &[String]) -> bool {
    let effective: Vec<&str> = args.iter().map(String::as_str).collect();
    if matches!(effective.first(), Some(&"log" | &"show" | &"reflog" | &"blame" | &"grep" | &"refs" | &"stash" | &"status")) {
        return false;
    }

    let mut after_double_dash = false;
    let mut first_non_option: Option<&str> = None;
    for arg in effective {
        if after_double_dash {
            if !arg.is_empty() {
                return false;
            }
            continue;
        }
        if arg == "--" {
            after_double_dash = true;
            continue;
        }
        if is_tig_line_arg(arg) {
            continue;
        }
        if arg.starts_with('-') {
            continue;
        }
        first_non_option = Some(arg);
        break;
    }

    let Some(candidate) = first_non_option else {
        return false;
    };

    if Path::new(candidate).exists() {
        return false;
    }

    !git_rev_or_path_exists(candidate)
}

fn is_tig_line_arg(arg: &str) -> bool {
    let Some(rest) = arg.strip_prefix('+') else {
        return false;
    };
    !rest.is_empty() && rest.chars().all(|c| c.is_ascii_digit())
}

fn git_rev_or_path_exists(candidate: &str) -> bool {
    let rev_ok = Command::new("git")
        .arg("rev-parse")
        .arg("--verify")
        .arg("--quiet")
        .arg(candidate)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false);
    if rev_ok {
        return true;
    }

    Command::new("git")
        .arg("ls-files")
        .arg("--error-unmatch")
        .arg(candidate)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map(|s| s.success())
        .unwrap_or(false)
}

fn can_open_tty() -> bool {
    std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open("/dev/tty")
        .is_ok()
}

fn run_tty_fallback(args: &[String]) -> ExitCode {
    let subcmd = args.first().map(String::as_str);
    let git_args: Vec<String> = match subcmd {
        Some("status") => vec!["status".into(), "--short".into()],
        Some("refs") => vec!["show-ref".into(), "--head".into()],
        Some("stash") => vec!["stash".into(), "list".into()],
        Some("reflog") => {
            let mut v = vec!["reflog".into()];
            v.extend(args.iter().skip(1).cloned());
            v
        }
        Some("show") => {
            let mut v = vec!["show".into()];
            v.extend(args.iter().skip(1).cloned());
            v
        }
        Some("log") => {
            let mut v = vec!["log".into(), "--oneline".into(), "--decorate".into()];
            v.extend(args.iter().skip(1).cloned());
            v
        }
        Some("blame") => {
            let mut v = vec!["blame".into()];
            v.extend(args.iter().skip(1).cloned());
            v
        }
        Some("grep") => {
            let mut v = vec!["grep".into()];
            v.extend(args.iter().skip(1).cloned());
            v
        }
        _ => {
            let mut v = vec!["log".into(), "--oneline".into(), "--decorate".into()];
            v.extend(args.iter().filter(|a| !is_tig_line_arg(a)).cloned());
            v
        }
    };

    match Command::new("git").args(git_args).status() {
        Ok(status) if status.success() => ExitCode::SUCCESS,
        Ok(status) => ExitCode::from(status.code().unwrap_or(1) as u8),
        Err(err) => {
            eprintln!("tig: {}", err);
            ExitCode::from(1)
        }
    }
}
