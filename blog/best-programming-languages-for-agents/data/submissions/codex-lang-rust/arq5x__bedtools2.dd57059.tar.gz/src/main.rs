use std::cmp::{max, min, Ordering};
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::env;
use std::io::{self, Read};
use std::process::Command;

#[cfg(unix)]
extern "C" {
    fn signal(sig: i32, handler: usize) -> usize;
}

#[derive(Clone, Debug)]
struct Rec {
    chrom: String,
    start: i64,
    end: i64,
    fields: Vec<String>,
}

impl Rec {
    fn line(&self) -> String { self.fields.join("\t") }
    fn len(&self) -> i64 { (self.end - self.start).max(0) }
    fn strand(&self) -> Option<&str> { self.fields.get(5).map(|s| s.as_str()) }
}

fn main() {
    #[cfg(unix)]
    unsafe {
        signal(13, 0);
    }
    let args: Vec<String> = env::args().collect();
    if args.len() == 1 || args.iter().any(|a| a == "--help") && args.len() == 2 {
        print_main_help();
        return;
    }
    if args[1] == "--version" {
        println!("bedtools b2e3657");
        return;
    }
    if args[1] == "--contact" {
        println!("For help, see the bedtools documentation and mailing list.");
        return;
    }
    let res = match args[1].as_str() {
        "intersect" | "intersectBed" => cmd_intersect(&args[2..]),
        "merge" | "mergeBed" => cmd_merge(&args[2..]),
        "complement" | "complementBed" => cmd_complement(&args[2..]),
        "sort" | "sortBed" => cmd_sort(&args[2..]),
        "closest" | "closestBed" => cmd_closest(&args[2..]),
        "coverage" | "coverageBed" => cmd_coverage(&args[2..]),
        "window" | "windowBed" => cmd_window(&args[2..]),
        "makewindows" => cmd_makewindows(&args[2..]),
        "flank" | "flankBed" => cmd_flank(&args[2..], false),
        "slop" | "slopBed" => cmd_flank(&args[2..], true),
        "subtract" | "subtractBed" => cmd_subtract(&args[2..]),
        "jaccard" => cmd_jaccard(&args[2..]),
        "groupby" | "groupBy" => cmd_groupby(&args[2..]),
        "map" | "mapBed" => cmd_map(&args[2..]),
        "genomecov" | "genomeCoverageBed" => cmd_genomecov(&args[2..]),
        "overlap" => cmd_overlap(&args[2..]),
        _ => { print_main_help(); Ok(()) }
    };
    if let Err(e) = res {
        eprintln!("{}", e);
        std::process::exit(1);
    }
}

fn print_main_help() {
    println!("bedtools is a powerful toolset for genome arithmetic.\n\nVersion:   b2e3657\nUsage:     bedtools <subcommand> [options]\n\nThe bedtools sub-commands include:\n    intersect     Find overlapping intervals in various ways.\n    window        Find overlapping intervals within a window around an interval.\n    closest       Find the closest, potentially non-overlapping interval.\n    coverage      Compute the coverage over defined intervals.\n    map           Apply a function to a column for each overlapping interval.\n    genomecov     Compute the coverage over an entire genome.\n    merge         Combine overlapping/nearby intervals into a single interval.\n    complement    Extract intervals _not_ represented by an interval file.\n    subtract      Remove intervals based on overlaps b/w two files.\n    slop          Adjust the size of intervals.\n    flank         Create new intervals from the flanks of existing intervals.\n    sort          Order the intervals in a file.\n    makewindows   Make interval \"windows\" across a genome.\n    groupby       Group by common cols. & summarize oth. cols.\n\n[ General help ]\n    --help        Print this help menu.\n    --version     What version of bedtools are you using?.");
}

fn opt(args: &[String], names: &[&str]) -> Option<String> {
    let mut i = 0;
    while i < args.len() {
        if names.contains(&args[i].as_str()) && i + 1 < args.len() {
            return Some(args[i + 1].clone());
        }
        i += 1;
    }
    None
}
fn flag(args: &[String], name: &str) -> bool { args.iter().any(|a| a == name) }
fn parse_i(s: Option<String>, d: i64) -> i64 { s.and_then(|x| x.parse().ok()).unwrap_or(d) }
fn parse_f(s: Option<String>, d: f64) -> f64 { s.and_then(|x| x.parse().ok()).unwrap_or(d) }

fn read_text(path: &str) -> Result<String, String> {
    if path == "-" || path == "stdin" {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        return Ok(s);
    }
    if path.ends_with(".gz") {
        let out = Command::new("gzip").arg("-cd").arg(path).output().map_err(|e| e.to_string())?;
        if !out.status.success() { return Err(format!("failed to read {}", path)); }
        return String::from_utf8(out.stdout).map_err(|e| e.to_string());
    }
    std::fs::read_to_string(path).map_err(|e| format!("{}: {}", path, e))
}

fn parse_recs(path: &str) -> Result<Vec<Rec>, String> {
    let text = read_text(path)?;
    let mut v = Vec::new();
    for l in text.lines() {
        if l.trim().is_empty() || l.starts_with('#') || l.starts_with("track") || l.starts_with("browser") { continue; }
        let f: Vec<String> = l.split_whitespace().map(|x| x.to_string()).collect();
        if f.len() < 3 { continue; }
        let start = f[1].parse::<i64>().unwrap_or(0);
        let end = f[2].parse::<i64>().unwrap_or(start);
        v.push(Rec { chrom: f[0].clone(), start, end, fields: f });
    }
    Ok(v)
}

fn parse_genome(path: &str) -> Result<Vec<(String, i64)>, String> {
    Ok(read_text(path)?.lines().filter_map(|l| {
        let f: Vec<_> = l.split_whitespace().collect();
        if f.len() >= 2 { Some((f[0].to_string(), f[1].parse().unwrap_or(0))) } else { None }
    }).collect())
}

fn overlap(a: &Rec, b: &Rec) -> i64 {
    if a.chrom != b.chrom { 0 } else { (min(a.end, b.end) - max(a.start, b.start)).max(0) }
}
fn dist(a: &Rec, b: &Rec) -> i64 {
    if a.chrom != b.chrom { i64::MAX / 4 } else if overlap(a,b) > 0 { 0 } else if a.end <= b.start { b.start - a.end } else { a.start - b.end }
}
fn strand_ok(a:&Rec,b:&Rec,same:bool,opp:bool)->bool {
    if !same && !opp { return true; }
    let eq = a.strand().is_some() && b.strand().is_some() && a.strand()==b.strand();
    (same && eq) || (opp && !eq)
}
fn pass_frac(a:&Rec,b:&Rec,ov:i64,f:f64,ff:f64,recip:bool,either:bool)->bool {
    if ov <= 0 { return false; }
    let pa = ov as f64 / a.len().max(1) as f64 >= f;
    let pb = ov as f64 / b.len().max(1) as f64 >= ff;
    if either { pa || pb } else if recip { pa && pb } else { pa && pb }
}

fn b_files(args:&[String]) -> Vec<String> {
    let mut out=Vec::new(); let mut i=0;
    while i<args.len() {
        if args[i]=="-b" { i+=1; while i<args.len() && !args[i].starts_with('-') { out.push(args[i].clone()); i+=1; } continue; }
        i+=1;
    }
    out
}

fn cmd_intersect(args: &[String]) -> Result<(), String> {
    if flag(args,"-h") { println!("Tool:    bedtools intersect (aka intersectBed)"); return Ok(()); }
    let a = parse_recs(&opt(args,&["-a"]).ok_or("***** ERROR: -a option given, but no database specified. *****")?)?;
    let bpaths=b_files(args); if bpaths.is_empty(){return Err("***** ERROR: -b option given, but no database specified. *****".into())}
    let mut bs=Vec::new(); for (idx,p) in bpaths.iter().enumerate(){ for r in parse_recs(p)? { bs.push((idx+1,r)); } }
    let wa=flag(args,"-wa"); let wb=flag(args,"-wb"); let wo=flag(args,"-wo"); let wao=flag(args,"-wao");
    let u=flag(args,"-u"); let c=flag(args,"-c"); let vflag=flag(args,"-v"); let loj=flag(args,"-loj");
    let f=parse_f(opt(args,&["-f"]),1e-9); let ff=parse_f(opt(args,&["-F"]),1e-9);
    let same=flag(args,"-s"); let opp=flag(args,"-S"); let recip=flag(args,"-r"); let either=flag(args,"-e");
    for ar in &a {
        let mut hits=Vec::new();
        for (idx,br) in &bs { let ov=overlap(ar,br); if strand_ok(ar,br,same,opp) && pass_frac(ar,br,ov,f,ff,recip,either){ hits.push((*idx,br.clone(),ov)); } }
        if c { println!("{}\t{}", ar.line(), hits.len()); }
        else if u { if !hits.is_empty(){ println!("{}", ar.line()); } }
        else if vflag { if hits.is_empty(){ println!("{}", ar.line()); } }
        else if hits.is_empty() { if wao { println!("{}\t.\t-1\t-1\t0", ar.line()); } else if loj { println!("{}\t.\t-1\t-1", ar.line()); } }
        else {
            for (idx,br,ov) in hits {
                if wo || wao { println!("{}\t{}\t{}", ar.line(), br.line(), ov); }
                else if wa && wb { if bpaths.len()>1 { println!("{}\t{}\t{}", ar.line(), idx, br.line()); } else { println!("{}\t{}", ar.line(), br.line()); } }
                else if wa { println!("{}", ar.line()); }
                else if wb { println!("{}\t{}\t{}", max(ar.start,br.start), min(ar.end,br.end), br.line()); }
                else { let mut f=ar.fields.clone(); f[1]=max(ar.start,br.start).to_string(); f[2]=min(ar.end,br.end).to_string(); println!("{}", f.join("\t")); }
            }
        }
    }
    Ok(())
}

fn cmd_merge(args:&[String])->Result<(),String>{
    if flag(args,"-h"){println!("Tool:    bedtools merge (aka mergeBed)"); return Ok(());}
    let mut recs=parse_recs(&opt(args,&["-i"]).unwrap_or("-".into()))?;
    recs.sort_by(cmp_rec); let d=parse_i(opt(args,&["-d"]),0); let same=flag(args,"-s");
    let cols=parse_cols(opt(args,&["-c"]).unwrap_or_default()); let ops=parse_ops(opt(args,&["-o"]).unwrap_or("sum".into())); let delim=opt(args,&["-delim"]).unwrap_or(",".into());
    let mut cur:Option<Rec>=None; let mut group:Vec<Rec>=Vec::new();
    for r in recs { if let Some(c)=&mut cur { let can=c.chrom==r.chrom && r.start <= c.end + d && (!same || c.strand()==r.strand()); if can { c.end=max(c.end,r.end); group.push(r); } else { print_merge(c,&group,&cols,&ops,&delim); cur=Some(r.clone()); group=vec![r]; } } else { cur=Some(r.clone()); group=vec![r]; } }
    if let Some(c)=cur { print_merge(&c,&group,&cols,&ops,&delim); } Ok(())
}
fn cmp_rec(a:&Rec,b:&Rec)->Ordering{ a.chrom.cmp(&b.chrom).then(a.start.cmp(&b.start)) }
fn parse_cols(s:String)->Vec<usize>{ if s.is_empty(){Vec::new()}else{s.split(',').filter_map(|x|x.parse::<usize>().ok().map(|n|n-1)).collect()} }
fn parse_ops(s:String)->Vec<String>{ s.split(',').map(|x|x.to_string()).collect() }
fn print_merge(c:&Rec,g:&[Rec],cols:&[usize],ops:&[String],delim:&str){
    let mut out=vec![c.chrom.clone(),c.start.to_string(),c.end.to_string()];
    if !cols.is_empty(){ for (j,col) in cols.iter().enumerate(){ let op=if ops.len()==1{&ops[0]}else{ops.get(j).unwrap_or(&ops[0])}; let vals:Vec<String>=g.iter().filter_map(|r|r.fields.get(*col).cloned()).collect(); out.push(apply_op(&vals,op,delim)); } }
    println!("{}",out.join("\t"));
}

fn cmd_complement(args:&[String])->Result<(),String>{
    if flag(args,"-h"){println!("Tool:    bedtools complement (aka complementBed)"); return Ok(());}
    let mut recs=parse_recs(&opt(args,&["-i"]).unwrap_or("-".into()))?; recs.sort_by(cmp_rec);
    let genome=parse_genome(&opt(args,&["-g"]).ok_or("no genome file")?)?; let limit=flag(args,"-L");
    let present:BTreeSet<_>=recs.iter().map(|r|r.chrom.clone()).collect();
    for (chrom,size) in genome { if limit && !present.contains(&chrom){continue;} let mut pos=0; for r in recs.iter().filter(|r|r.chrom==chrom){ if r.start>pos{println!("{}\t{}\t{}",chrom,pos,r.start);} pos=max(pos,r.end); } if pos<size{println!("{}\t{}\t{}",chrom,pos,size);} } Ok(())
}

fn cmd_sort(args:&[String])->Result<(),String>{
    if flag(args,"-h"){println!("Tool:    bedtools sort (aka sortBed)"); return Ok(());}
    let mut recs=parse_recs(&opt(args,&["-i"]).unwrap_or("-".into()))?;
    if flag(args,"-sizeA"){recs.sort_by_key(|r|r.len());} else if flag(args,"-sizeD"){recs.sort_by(|a,b|b.len().cmp(&a.len()));} else { recs.sort_by(cmp_rec); }
    for r in recs{println!("{}",r.line());} Ok(())
}

fn cmd_closest(args:&[String])->Result<(),String>{
    if flag(args,"-h"){println!("Tool:    bedtools closest (aka closestBed)"); return Ok(());}
    let a=parse_recs(&opt(args,&["-a"]).ok_or("no -a")?)?; let bs=parse_recs(&b_files(args).get(0).ok_or("no -b")?)?;
    let addd=flag(args,"-d")||args.iter().any(|x|x=="-D"); let ignore_ov=flag(args,"-io"); let tie=opt(args,&["-t"]).unwrap_or("all".into());
    for ar in &a { let mut best=i64::MAX/4; let mut hits=Vec::new(); for br in &bs { let d=dist(ar,br); if ignore_ov && d==0 {continue;} if d<best {best=d; hits.clear(); hits.push(br);} else if d==best {hits.push(br);} }
        if tie=="first" && hits.len()>1 { hits.truncate(1); } else if tie=="last" && hits.len()>1 { let x=*hits.last().unwrap(); hits=vec![x];}
        if hits.is_empty(){ println!("{}\t.\t-1\t-1{}",ar.line(), if addd{"\t-1"}else{""}); } else { for br in hits { if addd{println!("{}\t{}\t{}",ar.line(),br.line(),best);}else{println!("{}\t{}",ar.line(),br.line());} } }
    } Ok(())
}

fn cmd_coverage(args:&[String])->Result<(),String>{
    if flag(args,"-h"){println!("Tool:    bedtools coverage (aka coverageBed)"); return Ok(());}
    let a=parse_recs(&opt(args,&["-a"]).ok_or("no -a")?)?; let b=parse_recs(&b_files(args).get(0).ok_or("no -b")?)?; let counts=flag(args,"-counts");
    for ar in &a { let mut n=0; let mut cov=vec![false; ar.len().max(0) as usize]; for br in &b { let ov=overlap(ar,br); if ov>0 { n+=1; let s=max(ar.start,br.start)-ar.start; let e=min(ar.end,br.end)-ar.start; for i in s..e { if let Some(x)=cov.get_mut(i as usize){*x=true;} } } } let cb=cov.iter().filter(|x|**x).count() as i64; if counts{println!("{}\t{}",ar.line(),n);}else{println!("{}\t{}\t{}\t{}\t{:.7}",ar.line(),n,cb,ar.len(),cb as f64/ar.len().max(1) as f64);} } Ok(())
}

fn cmd_window(args:&[String])->Result<(),String>{
    let a=parse_recs(&opt(args,&["-a"]).ok_or("no -a")?)?; let b=parse_recs(&b_files(args).get(0).ok_or("no -b")?)?; let w=parse_i(opt(args,&["-w"]),1000); let l=parse_i(opt(args,&["-l"]),w); let r=parse_i(opt(args,&["-r"]),w); let u=flag(args,"-u"); let c=flag(args,"-c"); let v=flag(args,"-v");
    for ar in &a { let wr=Rec{chrom:ar.chrom.clone(),start:ar.start-l,end:ar.end+r,fields:vec![]}; let hits:Vec<_>=b.iter().filter(|br|overlap(&wr,br)>0).collect(); if c{println!("{}\t{}",ar.line(),hits.len());} else if u{if !hits.is_empty(){println!("{}",ar.line())}} else if v{if hits.is_empty(){println!("{}",ar.line())}} else { for br in hits{println!("{}\t{}",ar.line(),br.line());} } } Ok(())
}

fn cmd_makewindows(args:&[String])->Result<(),String>{
    if flag(args,"-h"){println!("Tool: bedtools makewindows"); return Ok(());}
    let src=if let Some(g)=opt(args,&["-g"]){ parse_genome(&g)?.into_iter().map(|(c,s)|Rec{chrom:c,start:0,end:s,fields:vec![]}).collect() } else { parse_recs(&opt(args,&["-b"]).ok_or("no input")?)? };
    let w=parse_i(opt(args,&["-w"]),0); let n=parse_i(opt(args,&["-n"]),0); let step=parse_i(opt(args,&["-s"]),w); let id=opt(args,&["-i"]);
    for r in src { if w>0 { let mut s=r.start; let mut num=1; while s<r.end { let e=min(s+w,r.end); print_win(&r,s,e,num,&id); s+=step.max(1); num+=1; if step<=0{break;} } } else if n>0 { for i in 0..n { let s=r.start + (r.len()*i)/n; let e=r.start + (r.len()*(i+1))/n; print_win(&r,s,e,i+1,&id); } } } Ok(())
}
fn print_win(r:&Rec,s:i64,e:i64,num:i64,id:&Option<String>){ let mut out=vec![r.chrom.clone(),s.to_string(),e.to_string()]; if let Some(kind)=id { let name=r.fields.get(3).cloned().unwrap_or_else(||format!("{}_{}_{}",r.chrom,r.start,r.end)); out.push(match kind.as_str(){"winnum"=>num.to_string(),"srcwinnum"=>format!("{}_{}",name,num),_=>name}); } println!("{}",out.join("\t")); }

fn cmd_flank(args:&[String], slop:bool)->Result<(),String>{
    if flag(args,"-h"){println!("Tool:    bedtools {}", if slop{"slop"}else{"flank"}); return Ok(());}
    let recs=parse_recs(&opt(args,&["-i"]).unwrap_or("-".into()))?; let genome:HashMap<_,_>=parse_genome(&opt(args,&["-g"]).ok_or("no genome")?)?.into_iter().collect();
    let b=opt(args,&["-b"]).and_then(|x|x.parse::<i64>().ok()); let base_l=b.unwrap_or(parse_i(opt(args,&["-l"]),0)); let base_r=b.unwrap_or(parse_i(opt(args,&["-r"]),0)); let stranded=flag(args,"-s");
    for r in recs { let size=*genome.get(&r.chrom).unwrap_or(&i64::MAX); let mut l=base_l; let mut rr=base_r; if stranded && r.strand()==Some("-"){ std::mem::swap(&mut l,&mut rr); }
        if slop { let mut f=r.fields.clone(); f[1]=max(0,r.start-l).to_string(); f[2]=min(size,r.end+rr).to_string(); println!("{}",f.join("\t")); }
        else {
            let left=(max(0,r.start-l), r.start); let right=(r.end, min(size,r.end+rr));
            if left.0<left.1 { let mut f=r.fields.clone(); f[1]=left.0.to_string(); f[2]=left.1.to_string(); println!("{}",f.join("\t")); }
            if right.0<right.1 { let mut f=r.fields.clone(); f[1]=right.0.to_string(); f[2]=right.1.to_string(); println!("{}",f.join("\t")); }
        }
    } Ok(())
}

fn cmd_subtract(args:&[String])->Result<(),String>{
    let a=parse_recs(&opt(args,&["-a"]).ok_or("no -a")?)?; let b=parse_recs(&b_files(args).get(0).ok_or("no -b")?)?; let whole=flag(args,"-A");
    for ar in &a { let mut segs=vec![(ar.start,ar.end)]; let mut any=false; for br in &b { if ar.chrom!=br.chrom{continue;} let ov=overlap(ar,br); if ov<=0{continue;} any=true; let os=max(ar.start,br.start); let oe=min(ar.end,br.end); let mut ns=Vec::new(); for (s,e) in segs { if os>s {ns.push((s,min(os,e)));} if oe<e {ns.push((max(oe,s),e));} } segs=ns; } if whole && any {continue;} for (s,e) in segs { if s<e { let mut f=ar.fields.clone(); f[1]=s.to_string(); f[2]=e.to_string(); println!("{}",f.join("\t")); } } } Ok(())
}

fn merged_len(mut v:Vec<Rec>)->i64{ v.sort_by(cmp_rec); let mut sum=0; let mut cur:Option<Rec>=None; for r in v{ if let Some(c)=&mut cur{ if c.chrom==r.chrom && r.start<=c.end { c.end=max(c.end,r.end); } else { sum+=c.len(); cur=Some(r); } } else { cur=Some(r); } } if let Some(c)=cur{sum+=c.len();} sum }
fn cmd_jaccard(args:&[String])->Result<(),String>{
    let a=parse_recs(&opt(args,&["-a"]).ok_or("no -a")?)?;
    let b=parse_recs(&b_files(args).get(0).ok_or("no -b")?)?;
    let mut pieces=Vec::new();
    for ar in &a {
        for br in &b {
            let s=max(ar.start,br.start); let e=min(ar.end,br.end);
            if ar.chrom==br.chrom && s<e {
                pieces.push(Rec{chrom:ar.chrom.clone(),start:s,end:e,fields:vec![]});
            }
        }
    }
    let inter=merged_len(pieces.clone());
    let n=merged_count(pieces);
    let union=merged_len([a.clone(),b.clone()].concat());
    println!("intersection\tunion\tjaccard\tn_intersections");
    println!("{}\t{}\t{:.6}\t{}",inter,union, if union>0{inter as f64/union as f64}else{0.0}, n);
    Ok(())
}
fn merged_count(mut v:Vec<Rec>)->i64{ v.sort_by(cmp_rec); let mut n=0; let mut cur:Option<Rec>=None; for r in v{ if let Some(c)=&mut cur{ if c.chrom==r.chrom && r.start<=c.end { c.end=max(c.end,r.end); } else { n+=1; cur=Some(r); } } else { cur=Some(r); } } if cur.is_some(){n+=1;} n }

fn cmd_groupby(args:&[String])->Result<(),String>{
    if flag(args,"-h"){println!("Tool:    bedtools groupby"); return Ok(());}
    let recs=parse_table(&opt(args,&["-i"]).unwrap_or("-".into()))?; let g=parse_cols(opt(args,&["-g","-grp"]).unwrap_or("1,2,3".into())); let cols=parse_cols(opt(args,&["-c","-opCols"]).ok_or("no -c")?); let ops=parse_ops(opt(args,&["-o","-ops"]).unwrap_or("sum".into())); let delim=opt(args,&["-delim"]).unwrap_or(",".into());
    let mut curkey:Option<Vec<String>>=None; let mut rows:Vec<Vec<String>>=Vec::new();
    for row in recs { let key:Vec<String>=g.iter().filter_map(|i|row.get(*i).cloned()).collect(); if curkey.as_ref().is_some_and(|k|*k!=key){ print_group(curkey.take().unwrap(),&rows,&cols,&ops,&delim); rows.clear(); } curkey=Some(key); rows.push(row); }
    if let Some(k)=curkey{ print_group(k,&rows,&cols,&ops,&delim); } Ok(())
}
fn parse_table(path:&str)->Result<Vec<Vec<String>>,String>{ Ok(read_text(path)?.lines().filter(|l|!l.trim().is_empty()).map(|l|l.split_whitespace().map(|x|x.to_string()).collect()).collect()) }
fn print_group(key:Vec<String>,rows:&[Vec<String>],cols:&[usize],ops:&[String],delim:&str){ let mut out=key; for (j,c) in cols.iter().enumerate(){ let op=if ops.len()==1{&ops[0]}else{ops.get(j).unwrap_or(&ops[0])}; let vals:Vec<String>=rows.iter().filter_map(|r|r.get(*c).cloned()).collect(); out.push(apply_op(&vals,op,delim)); } println!("{}",out.join("\t")); }
fn apply_op(vals:&[String],op:&str,delim:&str)->String{ let nums:Vec<f64>=vals.iter().filter_map(|v|v.parse().ok()).collect(); match op { "count"=>vals.len().to_string(), "count_distinct"=>vals.iter().collect::<BTreeSet<_>>().len().to_string(), "min"=>fmt(nums.iter().cloned().fold(f64::INFINITY,f64::min)), "max"=>fmt(nums.iter().cloned().fold(f64::NEG_INFINITY,f64::max)), "mean"=>fmt(nums.iter().sum::<f64>()/(nums.len().max(1) as f64)), "collapse"=>vals.join(delim), "distinct"=>vals.iter().cloned().collect::<BTreeSet<_>>().into_iter().collect::<Vec<_>>().join(delim), "first"=>vals.first().cloned().unwrap_or(".".into()), "last"=>vals.last().cloned().unwrap_or(".".into()), _=>fmt(nums.iter().sum()) } }
fn fmt(x:f64)->String{ if !x.is_finite(){return ".".into();} if (x-x.round()).abs()<1e-9{format!("{}",x as i64)}else{format!("{:.5}",x).trim_end_matches('0').trim_end_matches('.').to_string()} }

fn cmd_map(args:&[String])->Result<(),String>{ let a=parse_recs(&opt(args,&["-a"]).ok_or("no -a")?)?; let b=parse_recs(&b_files(args).get(0).ok_or("no -b")?)?; let col=parse_cols(opt(args,&["-c"]).unwrap_or("5".into())).get(0).cloned().unwrap_or(4); let op=opt(args,&["-o"]).unwrap_or("sum".into()); for ar in &a{ let vals:Vec<String>=b.iter().filter(|br|overlap(ar,br)>0).filter_map(|br|br.fields.get(col).cloned()).collect(); println!("{}\t{}",ar.line(), if vals.is_empty(){".".into()}else{apply_op(&vals,&op,",")}); } Ok(()) }
fn cmd_genomecov(args:&[String])->Result<(),String>{ let recs=parse_recs(&opt(args,&["-i"]).ok_or("no -i")?)?; let genome=parse_genome(&opt(args,&["-g"]).ok_or("no -g")?)?; let bg=flag(args,"-bg")||flag(args,"-bga"); let bga=flag(args,"-bga"); if bg{ for (chrom,size) in genome{ let mut events:BTreeMap<i64,i64>=BTreeMap::new(); if bga{events.insert(0,0);events.insert(size,0);} for r in recs.iter().filter(|r|r.chrom==chrom){*events.entry(r.start).or_insert(0)+=1;*events.entry(r.end).or_insert(0)-=1;} let mut last=0; let mut depth=0; for (pos,delta) in events{ if pos>last && (depth>0||bga){println!("{}\t{}\t{}\t{}",chrom,last,pos,depth);} depth+=delta; last=pos; } } } Ok(()) }
fn cmd_overlap(args:&[String])->Result<(),String>{ if args.len()>=6{ let a=Rec{chrom:args[0].clone(),start:args[1].parse().unwrap_or(0),end:args[2].parse().unwrap_or(0),fields:vec![]}; let b=Rec{chrom:args[3].clone(),start:args[4].parse().unwrap_or(0),end:args[5].parse().unwrap_or(0),fields:vec![]}; println!("{}",overlap(&a,&b)); } Ok(()) }
