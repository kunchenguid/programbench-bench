use std::cmp::Ordering;
use std::env;
use std::io::{self, Read, Write};
use std::process;

const VERSION: &str = "0.68.0 (5676da4a)";

const HELP: &str = r#"fzf is an interactive filter program for any kind of list.

It implements a "fuzzy" matching algorithm, so you can quickly type in patterns
with omitted characters and still get the results you want.

Project URL: https://github.com/junegunn/fzf
Author: Junegunn Choi <junegunn.c@gmail.com>

* See man page for more information: fzf --man

Usage: fzf [options]

  SEARCH
    -e, --exact              Enable exact-match
    +x, --no-extended        Disable extended-search mode
    -i, --ignore-case        Case-insensitive match
    +i, --no-ignore-case     Case-sensitive match
        --smart-case         Smart-case match (default)
    --scheme=SCHEME          Scoring scheme [default|path|history]
    -n, --nth=N[,..]         Comma-separated list of field index expressions
                             for limiting search scope. Each can be a non-zero
                             integer or a range expression ([BEGIN]..[END]).
    --with-nth=N[,..]        Transform the presentation of each line using
                             field index expressions
    --accept-nth=N[,..]      Define which fields to print on accept
    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)
    +s, --no-sort            Do not sort the result
    --literal                Do not normalize latin script letters
    --tail=NUM               Maximum number of items to keep in memory
    --disabled               Do not perform search
    --tiebreak=CRI[,..]      Comma-separated list of sort criteria to apply
                             when the scores are tied
                             [length|chunk|pathname|begin|end|index] (default: length)

  INPUT/OUTPUT
    --read0                  Read input delimited by ASCII NUL characters
    --print0                 Print output delimited by ASCII NUL characters
    --ansi                   Enable processing of ANSI color codes
    --sync                   Synchronous search for multi-staged filtering

  SCRIPTING
    -q, --query=STR          Start the finder with the given query
    -1, --select-1           Automatically select the only match
    -0, --exit-0             Exit immediately when there's no match
    -f, --filter=STR         Print matches for the initial query and exit
    --print-query            Print query as the first line
    --expect=KEYS            Comma-separated list of keys to complete fzf

  HELP
    --version                Display version information and exit
    --help                   Show this message
    --man                    Show man page
"#;

#[derive(Clone, Debug)]
enum CaseMode {
    Smart,
    Ignore,
    Respect,
}

#[derive(Clone, Debug)]
struct Opts {
    filter: Option<String>,
    query: String,
    exact: bool,
    extended: bool,
    case: CaseMode,
    sort: bool,
    read0: bool,
    print0: bool,
    print_query: bool,
    ansi: bool,
    tac: bool,
    tail: Option<usize>,
    delimiter: Option<String>,
    nth: Option<String>,
    with_nth: Option<String>,
    accept_nth: Option<String>,
    scheme: String,
    tiebreak: Vec<String>,
}

impl Default for Opts {
    fn default() -> Self {
        Self {
            filter: None,
            query: String::new(),
            exact: false,
            extended: true,
            case: CaseMode::Smart,
            sort: true,
            read0: false,
            print0: false,
            print_query: false,
            ansi: false,
            tac: false,
            tail: None,
            delimiter: None,
            nth: None,
            with_nth: None,
            accept_nth: None,
            scheme: "default".to_string(),
            tiebreak: vec!["length".to_string(), "index".to_string()],
        }
    }
}

#[derive(Debug)]
struct Item {
    original: String,
    index: usize,
}

#[derive(Debug)]
struct Match {
    item: Item,
    score: i64,
    begin: usize,
    end: usize,
}

fn main() {
    let mut args = Vec::new();
    if let Ok(file) = env::var("FZF_DEFAULT_OPTS_FILE") {
        if let Ok(s) = std::fs::read_to_string(file) {
            args.extend(shell_words(&s));
        }
    }
    if let Ok(s) = env::var("FZF_DEFAULT_OPTS") {
        args.extend(shell_words(&s));
    }
    args.extend(env::args().skip(1));

    let opts = match parse_args(&args) {
        Ok(ParseOutcome::Run(opts)) => opts,
        Ok(ParseOutcome::Exit(code)) => process::exit(code),
        Err(e) => {
            eprintln!("{e}");
            process::exit(2);
        }
    };

    if opts.filter.is_none() {
        eprintln!("inappropriate ioctl for device");
        process::exit(2);
    }
    let code = run_filter(opts).unwrap_or_else(|e| {
        eprintln!("{e}");
        2
    });
    process::exit(code);
}

enum ParseOutcome {
    Run(Opts),
    Exit(i32),
}

fn parse_args(args: &[String]) -> Result<ParseOutcome, String> {
    let mut opts = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        let (name, inline) = if let Some(pos) = arg.find('=') {
            (&arg[..pos], Some(arg[pos + 1..].to_string()))
        } else {
            (arg.as_str(), None)
        };
        macro_rules! val {
            () => {{
                if let Some(v) = inline.clone() {
                    v
                } else {
                    i += 1;
                    if i >= args.len() {
                        return Err(format!("missing value for {}", arg));
                    }
                    args[i].clone()
                }
            }};
        }
        match name {
            "--help" | "-h" => {
                print!("{HELP}");
                return Ok(ParseOutcome::Exit(0));
            }
            "--version" => {
                println!("{VERSION}");
                return Ok(ParseOutcome::Exit(0));
            }
            "--man" => {
                println!("This system has been minimized by removing packages and content that are");
                println!("not required on a system that users do not log into.");
                println!();
                println!("To restore this content, including manpages, you can run the 'unminimize'");
                println!("command. You will still need to ensure the 'man-db' package is installed.");
                return Ok(ParseOutcome::Exit(0));
            }
            "--bash" | "--zsh" | "--fish" => {
                println!("# fzf shell integration ({})", &name[2..]);
                return Ok(ParseOutcome::Exit(0));
            }
            "-f" | "--filter" => {
                let v = val!();
                opts.query = v.clone();
                opts.filter = Some(v);
            }
            "-q" | "--query" => opts.query = val!(),
            "-e" | "--exact" => opts.exact = true,
            "-i" | "--ignore-case" => opts.case = CaseMode::Ignore,
            "+i" | "--no-ignore-case" => opts.case = CaseMode::Respect,
            "--smart-case" => opts.case = CaseMode::Smart,
            "+x" | "--no-extended" => opts.extended = false,
            "-x" | "--extended" => opts.extended = true,
            "+s" | "--no-sort" => opts.sort = false,
            "--read0" => opts.read0 = true,
            "--print0" => opts.print0 = true,
            "--print-query" => opts.print_query = true,
            "--ansi" => opts.ansi = true,
            "--tac" => opts.tac = true,
            "--literal" | "--disabled" | "--sync" | "--no-bold" | "--no-color" | "--select-1"
            | "-1" | "--exit-0" | "-0" | "--multi" | "-m" | "--cycle" | "--wrap"
            | "--raw" | "--track" | "--keep-right" | "--no-hscroll" | "--no-scrollbar"
            | "--header-first" | "--no-input" | "--filepath-word" | "--no-separator"
            | "--no-multi-line" | "--highlight-line" | "--no-clear" | "--clear"
            | "--version-sort" => {}
            "-n" | "--nth" => {
                let v = val!();
                validate_expr_list(&v)?;
                opts.nth = Some(v);
            }
            "--with-nth" => opts.with_nth = Some(val!()),
            "--accept-nth" => opts.accept_nth = Some(val!()),
            "-d" | "--delimiter" => opts.delimiter = Some(val!()),
            "--tail" => opts.tail = Some(val!().parse().map_err(|_| "invalid tail".to_string())?),
            "--scheme" => {
                let v = val!();
                if !matches!(v.as_str(), "default" | "path" | "history") {
                    return Err(format!("invalid scoring scheme: {v} (expected: default|path|history)"));
                }
                opts.scheme = v;
            }
            "--tiebreak" => {
                let v = val!();
                opts.tiebreak = v.split(',').map(|s| s.to_string()).collect();
            }
            "--algo" | "--height" | "--min-height" | "--tmux" | "--style" | "--color"
            | "--layout" | "--margin" | "--padding" | "--border" | "--border-label"
            | "--border-label-pos" | "--gap" | "--gap-line" | "--freeze-left"
            | "--freeze-right" | "--scroll-off" | "--hscroll-off" | "--jump-labels"
            | "--gutter" | "--gutter-raw" | "--pointer" | "--marker"
            | "--marker-multi-line" | "--ellipsis" | "--tabstop" | "--scrollbar"
            | "--list-border" | "--list-label" | "--list-label-pos" | "--prompt"
            | "--info" | "--info-command" | "--separator" | "--ghost" | "--input-border"
            | "--input-label" | "--input-label-pos" | "--preview" | "--preview-window"
            | "--preview-border" | "--preview-label" | "--preview-label-pos" | "--header"
            | "--header-lines" | "--header-border" | "--header-lines-border"
            | "--header-label" | "--header-label-pos" | "--footer" | "--footer-border"
            | "--footer-label" | "--footer-label-pos" | "--expect" | "--bind"
            | "--with-shell" | "--listen" | "--walker" | "--walker-root" | "--walker-skip"
            | "--history" | "--history-size" => {
                if inline.is_none() && option_needs_value(name) {
                    let _ = val!();
                }
            }
            _ if name.starts_with("--preview-window=") || name.starts_with("--color=") => {}
            _ if !arg.starts_with('-') && !arg.starts_with('+') => {}
            _ => return Err(format!("unknown option: {arg}")),
        }
        i += 1;
    }
    Ok(ParseOutcome::Run(opts))
}

fn option_needs_value(name: &str) -> bool {
    !matches!(
        name,
        "--border" | "--tmux" | "--scrollbar" | "--list-border" | "--input-border"
            | "--preview-border" | "--header-border" | "--header-lines-border" | "--footer-border"
            | "--gap" | "--multi" | "-m" | "--listen"
    )
}

fn validate_expr_list(s: &str) -> Result<(), String> {
    for part in s.split(',') {
        if part.trim() == "0" {
            return Err("invalid format: 0".to_string());
        }
    }
    Ok(())
}

fn run_filter(opts: Opts) -> io::Result<i32> {
    let sep_in = if opts.read0 { b'\0' } else { b'\n' };
    let sep_out = if opts.print0 { b'\0' } else { b'\n' };
    let mut bytes = Vec::new();
    io::stdin().read_to_end(&mut bytes)?;
    let mut lines: Vec<String> = bytes
        .split(|b| *b == sep_in)
        .filter(|chunk| !chunk.is_empty())
        .map(|chunk| String::from_utf8_lossy(chunk).to_string())
        .collect();
    if let Some(n) = opts.tail {
        if lines.len() > n {
            lines = lines.split_off(lines.len() - n);
        }
    }
    if opts.tac {
        lines.reverse();
    }
    let mut matches = Vec::new();
    for (idx, original) in lines.into_iter().enumerate() {
        let display = if let Some(t) = &opts.with_nth {
            transform(&original, t, opts.delimiter.as_deref(), idx)
        } else {
            original.clone()
        };
        let base = if opts.ansi { strip_ansi(&display) } else { display.clone() };
        let search = if let Some(nth) = &opts.nth {
            transform(&base, nth, opts.delimiter.as_deref(), idx)
        } else {
            base
        };
        if let Some((score, begin, end)) = query_match(&search, &opts.query, &opts) {
            matches.push(Match { item: Item { original, index: idx }, score, begin, end });
        }
    }
    if opts.sort {
        matches.sort_by(compare_match);
    }
    let mut out = io::stdout();
    if opts.print_query {
        out.write_all(opts.query.as_bytes())?;
        out.write_all(&[sep_out])?;
    }
    for m in &matches {
        let s = if let Some(t) = &opts.accept_nth {
            transform(&m.item.original, t, opts.delimiter.as_deref(), m.item.index)
        } else {
            m.item.original.clone()
        };
        out.write_all(s.as_bytes())?;
        out.write_all(&[sep_out])?;
    }
    Ok(if matches.is_empty() { 1 } else { 0 })
}

fn compare_match(a: &Match, b: &Match) -> Ordering {
    b.score
        .cmp(&a.score)
        .then_with(|| a.item.original.chars().count().cmp(&b.item.original.chars().count()))
        .then_with(|| a.begin.cmp(&b.begin))
        .then_with(|| a.end.cmp(&b.end))
        .then_with(|| a.item.index.cmp(&b.item.index))
}

fn query_match(text: &str, query: &str, opts: &Opts) -> Option<(i64, usize, usize)> {
    if query.is_empty() {
        return Some((0, 0, 0));
    }
    let ignore_case = match opts.case {
        CaseMode::Ignore => true,
        CaseMode::Respect => false,
        CaseMode::Smart => !query.chars().any(|c| c.is_uppercase()),
    };
    if !opts.extended {
        return term_match(text, query, opts.exact, ignore_case);
    }
    let mut best: Option<(i64, usize, usize)> = None;
    for group in split_or(query) {
        let mut total = 0;
        let mut first = usize::MAX;
        let mut last = 0;
        let mut ok = true;
        for tok in shell_like_terms(&group) {
            if tok.is_empty() {
                continue;
            }
            let inverse = tok.starts_with('!');
            let t = if inverse { &tok[1..] } else { &tok };
            let m = term_match(text, t, opts.exact, ignore_case);
            if inverse {
                if m.is_some() {
                    ok = false;
                    break;
                }
            } else if let Some((score, b, e)) = m {
                total += score;
                first = first.min(b);
                last = last.max(e);
            } else {
                ok = false;
                break;
            }
        }
        if ok {
            let cand = (total, if first == usize::MAX { 0 } else { first }, last);
            if best.map_or(true, |old| cand.0 > old.0) {
                best = Some(cand);
            }
        }
    }
    best
}

fn split_or(query: &str) -> Vec<String> {
    let mut groups = Vec::new();
    let mut cur = Vec::new();
    for part in query.split_whitespace() {
        if part == "|" {
            groups.push(cur.join(" "));
            cur.clear();
        } else {
            cur.push(part);
        }
    }
    groups.push(cur.join(" "));
    groups
}

fn shell_like_terms(s: &str) -> Vec<String> {
    s.split_whitespace().map(|x| x.to_string()).collect()
}

fn term_match(text: &str, term: &str, exact_mode: bool, ignore_case: bool) -> Option<(i64, usize, usize)> {
    let mut t = term;
    let mut exact = exact_mode;
    if let Some(rest) = t.strip_prefix('\'') {
        exact = true;
        t = rest;
    }
    let prefix = t.starts_with('^');
    if prefix {
        t = &t[1..];
        exact = true;
    }
    let suffix = t.ends_with('$') && t.len() > 1;
    if suffix {
        t = &t[..t.len() - 1];
        exact = true;
    }
    let hay = if ignore_case { text.to_lowercase() } else { text.to_string() };
    let needle = if ignore_case { t.to_lowercase() } else { t.to_string() };
    if needle.is_empty() {
        return Some((0, 0, 0));
    }
    if prefix {
        return hay.starts_with(&needle).then_some((1000 - text.len() as i64, 0, needle.len()));
    }
    if suffix {
        return hay.ends_with(&needle).then(|| {
            let b = hay.len().saturating_sub(needle.len());
            (1000 - b as i64, b, hay.len())
        });
    }
    if exact {
        return hay.find(&needle).map(|b| {
            let bonus = boundary_bonus(text, b);
            (800 + bonus - b as i64 - text.len() as i64, b, b + needle.len())
        });
    }
    fuzzy(&hay, &needle).map(|(b, e, gaps)| {
        let consecutive = (e - b == needle.len()) as i64;
        let byte_b = byte_index_for_char(text, b);
        let bonus = boundary_bonus(text, byte_b);
        (600 + bonus + consecutive * 200 - gaps as i64 * 10 - b as i64 - text.len() as i64, b, e)
    })
}

fn byte_index_for_char(text: &str, char_pos: usize) -> usize {
    text.char_indices().nth(char_pos).map(|(i, _)| i).unwrap_or(text.len())
}

fn boundary_bonus(text: &str, byte_pos: usize) -> i64 {
    if byte_pos == 0 {
        return 120;
    }
    let prev = text[..byte_pos].chars().next_back().unwrap_or(' ');
    if prev.is_whitespace() {
        120
    } else if matches!(prev, '/' | '\\' | '_' | '-' | '.') {
        80
    } else {
        0
    }
}

fn fuzzy(hay: &str, needle: &str) -> Option<(usize, usize, usize)> {
    let hs: Vec<char> = hay.chars().collect();
    let ns: Vec<char> = needle.chars().collect();
    let mut best: Option<(usize, usize, usize)> = None;
    for start in 0..hs.len() {
        if hs[start] != ns[0] {
            continue;
        }
        let mut j = 1;
        let mut end = start + 1;
        while j < ns.len() && end < hs.len() {
            if hs[end] == ns[j] {
                j += 1;
            }
            end += 1;
        }
        if j == ns.len() {
            let gaps = end - start - ns.len();
            let cand = (start, end, gaps);
            if best.map_or(true, |b| (cand.2, cand.0, cand.1) < (b.2, b.0, b.1)) {
                best = Some(cand);
            }
        }
    }
    best
}

#[derive(Clone, Copy)]
struct Span {
    start: usize,
    end: usize,
}

fn field_spans(line: &str, delim: Option<&str>) -> Vec<Span> {
    if let Some(d) = delim {
        if d.is_empty() {
            return vec![Span { start: 0, end: line.len() }];
        }
        let mut spans = Vec::new();
        let mut pos = 0;
        while let Some(off) = line[pos..].find(d) {
            spans.push(Span { start: pos, end: pos + off });
            pos += off + d.len();
        }
        spans.push(Span { start: pos, end: line.len() });
        spans
    } else {
        let mut spans = Vec::new();
        let mut in_field = false;
        let mut start = 0;
        for (i, ch) in line.char_indices() {
            if ch.is_whitespace() {
                if in_field {
                    spans.push(Span { start, end: i });
                    in_field = false;
                }
            } else if !in_field {
                start = i;
                in_field = true;
            }
        }
        if in_field {
            spans.push(Span { start, end: line.len() });
        }
        spans
    }
}

fn transform(line: &str, spec: &str, delim: Option<&str>, idx: usize) -> String {
    if spec.contains('{') {
        let mut out = String::new();
        let mut chars = spec.chars().peekable();
        while let Some(c) = chars.next() {
            if c == '{' {
                let mut expr = String::new();
                for nc in chars.by_ref() {
                    if nc == '}' { break; }
                    expr.push(nc);
                }
                if expr == "n" {
                    out.push_str(&idx.to_string());
                } else {
                    out.push_str(&select_fields(line, &expr, delim));
                }
            } else {
                out.push(c);
            }
        }
        out
    } else {
        spec.split(',')
            .map(|expr| select_fields(line, expr.trim(), delim))
            .filter(|s| !s.is_empty())
            .collect::<Vec<_>>()
            .join(if delim.is_some() { delim.unwrap_or("") } else { " " })
    }
}

fn select_fields(line: &str, expr: &str, delim: Option<&str>) -> String {
    let spans = field_spans(line, delim);
    if spans.is_empty() {
        return String::new();
    }
    let n = spans.len() as isize;
    let (beg, end) = if let Some(p) = expr.find("..") {
        let a = &expr[..p];
        let b = &expr[p + 2..];
        let beg = if a.is_empty() { 1 } else { parse_index(a, n) };
        let end = if b.is_empty() { n } else { parse_index(b, n) };
        (beg, end)
    } else {
        let x = parse_index(expr, n);
        (x, x)
    };
    if beg == 0 || end == 0 {
        return String::new();
    }
    let lo = beg.min(end).max(1);
    let hi = beg.max(end).min(n);
    if lo > hi {
        return String::new();
    }
    let s = spans[(lo - 1) as usize].start;
    let e = spans[(hi - 1) as usize].end;
    line[s..e].to_string()
}

fn parse_index(s: &str, n: isize) -> isize {
    let v = s.trim().parse::<isize>().unwrap_or(0);
    if v < 0 { n + v + 1 } else { v }
}

fn strip_ansi(s: &str) -> String {
    let mut out = String::new();
    let mut it = s.chars().peekable();
    while let Some(c) = it.next() {
        if c == '\x1b' && it.peek() == Some(&'[') {
            it.next();
            for x in it.by_ref() {
                if x.is_ascii_alphabetic() { break; }
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn shell_words(s: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut cur = String::new();
    let mut quote: Option<char> = None;
    let mut esc = false;
    for c in s.chars() {
        if esc {
            cur.push(c);
            esc = false;
            continue;
        }
        if c == '\\' && quote != Some('\'') {
            esc = true;
            continue;
        }
        if let Some(q) = quote {
            if c == q {
                quote = None;
            } else {
                cur.push(c);
            }
        } else if c == '\'' || c == '"' {
            quote = Some(c);
        } else if c.is_whitespace() {
            if !cur.is_empty() {
                words.push(std::mem::take(&mut cur));
            }
        } else {
            cur.push(c);
        }
    }
    if !cur.is_empty() {
        words.push(cur);
    }
    words
}
