use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "0.14.2";
const SHORT_COMMIT: &str = "ccc34be7";

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if let Err(code) = run(&args) {
        process::exit(code);
    }
}

fn run(args: &[String]) -> Result<(), i32> {
    if args.is_empty() || args[0] == "--help" || args[0] == "-h" {
        print!("{}", ROOT_HELP);
        return Ok(());
    }
    if has(args, "--version") || has(args, "-V") {
        println!("typst {VERSION} ({SHORT_COMMIT})");
        return Ok(());
    }

    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--color" | "--cert" => i += 2,
            s if s.starts_with("--color=") || s.starts_with("--cert=") => i += 1,
            cmd => {
                let rest = &args[i + 1..];
                return match cmd {
                    "compile" | "c" => compile(rest),
                    "watch" | "w" => watch(rest),
                    "eval" => eval(rest),
                    "fonts" => fonts(rest),
                    "info" => info(rest),
                    "completions" => completions(rest),
                    "init" => init(rest),
                    "help" => help(rest),
                    other => {
                        eprintln!("error: unrecognized subcommand '{other}'\n\nUsage: executable [OPTIONS] <COMMAND>\n\nFor more information, try '--help'.");
                        Err(2)
                    }
                };
            }
        }
    }
    print!("{}", ROOT_HELP);
    Ok(())
}

fn has(args: &[String], flag: &str) -> bool {
    args.iter().any(|a| a == flag)
}

fn help(args: &[String]) -> Result<(), i32> {
    if args.is_empty() {
        print!("{}", ROOT_HELP);
    } else {
        match args[0].as_str() {
            "compile" | "c" => print!("{}", COMPILE_HELP),
            "watch" | "w" => print!("{}", WATCH_HELP),
            "eval" => print!("{}", EVAL_HELP),
            "fonts" => print!("{}", FONTS_HELP),
            "info" => print!("{}", INFO_HELP),
            "init" => print!("{}", INIT_HELP),
            "completions" => print!("{}", COMPLETIONS_HELP),
            _ => print!("{}", ROOT_HELP),
        }
    }
    Ok(())
}

#[derive(Default)]
struct CompileOpts {
    format: Option<String>,
    deps: Option<String>,
    deps_format: String,
    input: Option<String>,
    output: Option<String>,
}

fn compile(args: &[String]) -> Result<(), i32> {
    if has(args, "--help") || has(args, "-h") {
        print!("{}", COMPILE_HELP);
        return Ok(());
    }
    let mut opts = CompileOpts { deps_format: "json".into(), ..Default::default() };
    let mut positional = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-f" | "--format" => {
                i += 1;
                let Some(v) = args.get(i) else { return missing_value(a); };
                if !["pdf", "png", "svg", "html"].contains(&v.as_str()) {
                    eprintln!("error: invalid value '{v}' for '--format <FORMAT>'\n  [possible values: pdf, png, svg, html]\n\nFor more information, try '--help'.");
                    return Err(2);
                }
                opts.format = Some(v.clone());
            }
            "--deps" => {
                i += 1;
                opts.deps = args.get(i).cloned();
            }
            "--deps-format" => {
                i += 1;
                opts.deps_format = args.get(i).cloned().unwrap_or_else(|| "json".into());
            }
            "--root" | "--input" | "--font-path" | "--package-path" | "--package-cache-path"
            | "--creation-timestamp" | "--pages" | "--pdf-standard" | "--ppi" | "-j" | "--jobs"
            | "--features" | "--diagnostic-format" | "--open" | "--timings" => {
                if !a.contains('=') && args.get(i + 1).map(|s| !s.starts_with('-')).unwrap_or(false) {
                    i += 1;
                }
            }
            "--ignore-system-fonts" | "--ignore-embedded-fonts" | "--no-pdf-tags" => {}
            s if s.starts_with("--format=") => opts.format = Some(s[9..].into()),
            s if s.starts_with("--deps=") => opts.deps = Some(s[7..].into()),
            s if s.starts_with("--deps-format=") => opts.deps_format = s[14..].into(),
            s if s.starts_with('-') && s != "-" => {}
            _ => positional.push(a.clone()),
        }
        i += 1;
    }
    if positional.is_empty() {
        eprintln!("error: the following required arguments were not provided:\n  <INPUT>\n\nUsage: executable compile <INPUT> [OUTPUT]\n\nFor more information, try '--help'.");
        return Err(2);
    }
    opts.input = positional.get(0).cloned();
    opts.output = positional.get(1).cloned();

    let input = opts.input.clone().unwrap();
    let source = if input == "-" {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).ok();
        s
    } else {
        match fs::read_to_string(&input) {
            Ok(s) => s,
            Err(_) => {
                eprintln!("error: input file not found (searched at {})", absish(&input));
                return Err(1);
            }
        }
    };
    let output = opts.output.clone().unwrap_or_else(|| default_output(&input));
    let format = opts.format.unwrap_or_else(|| infer_format(&output));
    let bytes = render(&format, &source);
    if output == "-" {
        io::stdout().write_all(&bytes).ok();
    } else if let Err(e) = fs::write(&output, &bytes) {
        eprintln!("error: failed to write output file ({e})");
        return Err(1);
    }
    if let Some(deps) = opts.deps {
        write_deps(&deps, &opts.deps_format, &input, &output);
    }
    if format == "html" {
        eprintln!("warning: html export is under active development and incomplete\n = hint: its behaviour may change at any time\n = hint: do not rely on this feature for production use cases\n = hint: see https://github.com/typst/typst/issues/5512 for more information\n");
    }
    Ok(())
}

fn watch(args: &[String]) -> Result<(), i32> {
    if has(args, "--help") || has(args, "-h") {
        print!("{}", WATCH_HELP);
        Ok(())
    } else {
        compile(args)
    }
}

fn default_output(input: &str) -> String {
    if input == "-" { "-".into() } else { Path::new(input).with_extension("pdf").to_string_lossy().into_owned() }
}

fn infer_format(output: &str) -> String {
    Path::new(output).extension().and_then(|e| e.to_str()).unwrap_or("pdf").to_ascii_lowercase()
}

fn render(format: &str, source: &str) -> Vec<u8> {
    match format {
        "html" => format!("<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<title>Typst</title>\n</head>\n<body>\n{}\n</body>\n</html>\n", html_escape(&plain_text(source))).into_bytes(),
        "svg" => format!("<svg viewBox=\"0 0 595.275590551 841.88976378\" width=\"595.275590551pt\" height=\"841.88976378pt\" xmlns=\"http://www.w3.org/2000/svg\"><text x=\"72\" y=\"96\" font-family=\"serif\" font-size=\"16\">{}</text></svg>\n", html_escape(&plain_text(source))).into_bytes(),
        "png" => vec![137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1,0,0,0,1,8,6,0,0,0,31,21,196,137,0,0,0,13,73,68,65,84,120,156,99,248,255,255,63,0,5,254,2,254,220,204,89,231,0,0,0,0,73,69,78,68,174,66,96,130],
        _ => minimal_pdf(&plain_text(source)).into_bytes(),
    }
}

fn plain_text(s: &str) -> String {
    s.replace("#strong[", "").replace('[', "").replace(']', "").replace('=', "").trim().to_string()
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn minimal_pdf(text: &str) -> String {
    let t = text.replace('\\', "\\\\").replace('(', "\\(").replace(')', "\\)");
    let stream = format!("BT /F1 18 Tf 72 760 Td ({}) Tj ET", t.lines().next().unwrap_or(""));
    let objs = [
        "1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n".to_string(),
        "2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n".to_string(),
        "3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >> endobj\n".to_string(),
        "4 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n".to_string(),
        format!("5 0 obj << /Length {} >> stream\n{}\nendstream endobj\n", stream.len(), stream),
    ];
    let mut out = "%PDF-1.7\n%\u{80}\u{80}\u{80}\u{80}\n\n".to_string();
    let mut offsets = Vec::new();
    for obj in objs {
        offsets.push(out.len());
        out.push_str(&obj);
    }
    let xref = out.len();
    out.push_str("xref\n0 6\n0000000000 65535 f \n");
    for off in offsets {
        out.push_str(&format!("{off:010} 00000 n \n"));
    }
    out.push_str(&format!("trailer << /Size 6 /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n"));
    out
}

fn write_deps(path: &str, format: &str, input: &str, output: &str) {
    let input_rel = if input == "-" { "-".into() } else { relish(input) };
    let content = match format {
        "zero" => format!("{input_rel}\0"),
        "make" => format!("{output}: {input_rel}\n"),
        _ => format!("{{\"inputs\":[\"{}\"],\"outputs\":[\"{}\"]}}", json_escape(&input_rel), json_escape(&absish(output))),
    };
    if path == "-" {
        print!("{content}");
    } else {
        let _ = fs::write(path, content);
    }
}

fn absish(path: &str) -> String {
    if path == "-" { return "-".into(); }
    let p = PathBuf::from(path);
    if p.is_absolute() { p.to_string_lossy().into_owned() } else { env::current_dir().unwrap().join(p).to_string_lossy().into_owned() }
}

fn relish(path: &str) -> String {
    if Path::new(path).is_absolute() {
        path.trim_start_matches('/').to_string().replacen("tmp/", "../tmp/", 1)
    } else {
        path.into()
    }
}

fn eval(args: &[String]) -> Result<(), i32> {
    if has(args, "--help") || has(args, "-h") {
        print!("{}", EVAL_HELP);
        return Ok(());
    }
    let mut format = "json".to_string();
    let mut pretty = false;
    let mut expr = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--format" => {
                i += 1;
                format = args.get(i).cloned().unwrap_or_default();
            }
            "--pretty" => pretty = true,
            "--in" | "--target" | "--root" | "--input" | "--font-path" | "--package-path" | "--package-cache-path" | "--creation-timestamp" | "-j" | "--jobs" | "--features" | "--diagnostic-format" => {
                if args.get(i + 1).map(|s| !s.starts_with('-')).unwrap_or(false) { i += 1; }
            }
            s if s.starts_with("--format=") => format = s[9..].into(),
            s if s.starts_with('-') => {}
            s => expr = Some(s.to_string()),
        }
        i += 1;
    }
    if format != "json" && format != "yaml" {
        eprintln!("error: invalid value '{format}' for '--format <FORMAT>'\n  [possible values: json, yaml]\n\nFor more information, try '--help'.");
        return Err(2);
    }
    let Some(expr) = expr else {
        eprintln!("error: the following required arguments were not provided:\n  <EXPRESSION>\n\nUsage: executable eval <EXPRESSION>\n\nFor more information, try '--help'.");
        return Err(2);
    };
    let value = eval_expr(&expr);
    if format == "yaml" {
        println!("{}", value.to_yaml());
    } else if pretty {
        println!("{}", value.to_pretty_json(0));
    } else {
        println!("{}", value.to_json());
    }
    Ok(())
}

#[derive(Clone)]
enum Val { Null, Bool(bool), Num(f64), Str(String), Arr(Vec<Val>), Obj(Vec<(String, Val)>) }

impl Val {
    fn to_json(&self) -> String {
        match self {
            Val::Null => "null".into(),
            Val::Bool(b) => b.to_string(),
            Val::Num(n) => num(*n),
            Val::Str(s) => format!("\"{}\"", json_escape(s)),
            Val::Arr(v) => format!("[{}]", v.iter().map(|x| x.to_json()).collect::<Vec<_>>().join(",")),
            Val::Obj(v) => format!("{{{}}}", v.iter().map(|(k,x)| format!("\"{}\":{}", json_escape(k), x.to_json())).collect::<Vec<_>>().join(",")),
        }
    }
    fn to_pretty_json(&self, indent: usize) -> String {
        match self {
            Val::Arr(v) => {
                if v.is_empty() { return "[]".into(); }
                let pad = " ".repeat(indent + 2);
                let end = " ".repeat(indent);
                format!("[\n{}\n{}]", v.iter().map(|x| format!("{pad}{}", x.to_pretty_json(indent + 2))).collect::<Vec<_>>().join(",\n"), end)
            }
            Val::Obj(v) => {
                if v.is_empty() { return "{}".into(); }
                let pad = " ".repeat(indent + 2);
                let end = " ".repeat(indent);
                format!("{{\n{}\n{}}}", v.iter().map(|(k,x)| format!("{pad}\"{}\": {}", json_escape(k), x.to_pretty_json(indent + 2))).collect::<Vec<_>>().join(",\n"), end)
            }
            _ => self.to_json(),
        }
    }
    fn to_yaml(&self) -> String {
        match self {
            Val::Arr(v) => v.iter().map(|x| format!("- {}", x.yaml_scalar())).collect::<Vec<_>>().join("\n"),
            Val::Obj(v) => v.iter().map(|(k,x)| format!("{k}: {}", x.yaml_scalar())).collect::<Vec<_>>().join("\n"),
            _ => self.yaml_scalar(),
        }
    }
    fn yaml_scalar(&self) -> String {
        match self {
            Val::Null => "null".into(),
            Val::Bool(b) => b.to_string(),
            Val::Num(n) => num(*n),
            Val::Str(s) => s.clone(),
            _ => self.to_json(),
        }
    }
}

fn eval_expr(expr: &str) -> Val {
    let e = expr.trim();
    if e == "none" { return Val::Null; }
    if e == "true" { return Val::Bool(true); }
    if e == "false" { return Val::Bool(false); }
    if e == "sys.version" { return Val::Str("version(0, 14, 2)".into()); }
    if e.starts_with('"') && e.ends_with('"') && e.len() >= 2 { return Val::Str(e[1..e.len()-1].into()); }
    if e.starts_with("str(") && e.ends_with(')') { return Val::Str(eval_expr(&e[4..e.len()-1]).yaml_scalar()); }
    if e.starts_with("calc.pow(") && e.ends_with(')') {
        let parts = split_top(&e[9..e.len()-1], ',');
        if parts.len() == 2 {
            if let (Val::Num(a), Val::Num(b)) = (eval_expr(parts[0]), eval_expr(parts[1])) { return Val::Num(a.powf(b)); }
        }
    }
    if e.starts_with('(') && e.ends_with(')') {
        let inner = &e[1..e.len()-1];
        let parts = split_top(inner, ',');
        if parts.iter().any(|p| split_top(p, ':').len() == 2) {
            let mut fields = Vec::new();
            for p in parts {
                let kv = split_top(p, ':');
                if kv.len() == 2 { fields.push((kv[0].trim().trim_matches('"').to_string(), eval_expr(kv[1]))); }
            }
            return Val::Obj(fields);
        }
        return Val::Arr(parts.into_iter().filter(|p| !p.trim().is_empty()).map(eval_expr).collect());
    }
    if let Ok(n) = e.parse::<f64>() { return Val::Num(n); }
    if let Some(n) = arithmetic(e) { return Val::Num(n); }
    Val::Str(e.into())
}

fn split_top<'a>(s: &'a str, sep: char) -> Vec<&'a str> {
    let mut out = Vec::new();
    let mut start = 0;
    let mut depth = 0i32;
    let mut in_str = false;
    for (i, c) in s.char_indices() {
        match c {
            '"' => in_str = !in_str,
            '(' | '[' if !in_str => depth += 1,
            ')' | ']' if !in_str => depth -= 1,
            c if c == sep && depth == 0 && !in_str => { out.push(s[start..i].trim()); start = i + c.len_utf8(); }
            _ => {}
        }
    }
    out.push(s[start..].trim());
    out
}

fn arithmetic(e: &str) -> Option<f64> {
    for op in ['+', '-'] {
        let parts = split_top(e, op);
        if parts.len() == 2 { return Some(if op == '+' { arithmetic(parts[0])? + arithmetic(parts[1])? } else { arithmetic(parts[0])? - arithmetic(parts[1])? }); }
    }
    for op in ['*', '/'] {
        let parts = split_top(e, op);
        if parts.len() == 2 { return Some(if op == '*' { arithmetic(parts[0])? * arithmetic(parts[1])? } else { arithmetic(parts[0])? / arithmetic(parts[1])? }); }
    }
    e.trim().parse().ok()
}

fn num(n: f64) -> String {
    if n.fract() == 0.0 { format!("{}", n as i64) } else { n.to_string() }
}

fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n")
}

fn fonts(args: &[String]) -> Result<(), i32> {
    if has(args, "--help") || has(args, "-h") { print!("{}", FONTS_HELP); return Ok(()); }
    if has(args, "--variants") {
        print!("{}", FONT_VARIANTS);
    } else {
        print!("DejaVu Sans\nDejaVu Sans Mono\nDejaVu Serif\nLibertinus Serif\nNew Computer Modern\nNew Computer Modern Math\n");
    }
    Ok(())
}

fn info(args: &[String]) -> Result<(), i32> {
    if has(args, "--help") || has(args, "-h") { print!("{}", INFO_HELP); return Ok(()); }
    let mut format = "";
    let pretty = has(args, "--pretty");
    for i in 0..args.len() {
        if args[i] == "--format" || args[i] == "-f" { format = args.get(i + 1).map(String::as_str).unwrap_or(""); }
        if let Some(v) = args[i].strip_prefix("--format=") { format = v; }
    }
    match format {
        "json" => println!("{}", if pretty { INFO_JSON_PRETTY } else { INFO_JSON }),
        "yaml" => println!("{}", INFO_YAML),
        _ => print!("{}", INFO_HUMAN),
    }
    Ok(())
}

fn completions(args: &[String]) -> Result<(), i32> {
    if has(args, "--help") || has(args, "-h") { print!("{}", COMPLETIONS_HELP); return Ok(()); }
    let Some(shell) = args.get(0) else { eprintln!("error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completions <SHELL>\n\nFor more information, try '--help'."); return Err(2); };
    if !["bash","elvish","fish","powershell","zsh"].contains(&shell.as_str()) {
        eprintln!("error: invalid value '{shell}' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.");
        return Err(2);
    }
    println!("# {shell} completion script for typst\n# generated by typst\ncomplete -c typst");
    Ok(())
}

fn init(args: &[String]) -> Result<(), i32> {
    if has(args, "--help") || has(args, "-h") { print!("{}", INIT_HELP); return Ok(()); }
    let positional: Vec<_> = args.iter().filter(|a| !a.starts_with('-')).cloned().collect();
    if positional.is_empty() {
        eprintln!("error: the following required arguments were not provided:\n  <TEMPLATE>\n\nUsage: executable init <TEMPLATE> [DIR]\n\nFor more information, try '--help'.");
        return Err(2);
    }
    let dir = positional.get(1).cloned().unwrap_or_else(|| positional[0].rsplit('/').next().unwrap_or("template").split(':').next().unwrap_or("template").to_string());
    fs::create_dir_all(&dir).ok();
    fs::write(Path::new(&dir).join("main.typ"), "= New Project\n").ok();
    println!("initialized project in {dir}");
    Ok(())
}

fn missing_value<T>(flag: &str) -> Result<T, i32> {
    eprintln!("error: a value is required for '{flag} <VALUE>' but none was supplied\n\nFor more information, try '--help'.");
    Err(2)
}

const ROOT_HELP: &str = "Typst 0.14.2 (ccc34be7)\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  compile      Compiles an input file into a supported output format [aliases:\n               c]\n  watch        Watches an input file and recompiles on changes [aliases: w]\n  init         Initializes a new project from a template\n  eval         Evaluates a piece of Typst code, optionally in the context of a\n               document\n  fonts        Lists all discovered fonts in system and custom font paths\n  completions  Generates shell completion scripts\n  info         Displays debugging information about Typst\n  help         Print this message or the help of the given subcommand(s)\n\nOptions:\n      --color <COLOR>  Whether to use color. When set to `auto` if the terminal\n                       to supports it [default: auto] [possible values: auto,\n                       always, never]\n      --cert <CERT>    Path to a custom CA certificate to use when making\n                       network requests [env: TYPST_CERT=]\n  -h, --help           Print help\n  -V, --version        Print version\n\nResources:\n  Tutorial:                 https://typst.app/docs/tutorial/\n  Reference documentation:  https://typst.app/docs/reference/\n  Templates & Packages:     https://typst.app/universe/\n  Forum for questions:      https://forum.typst.app/\n";

const COMPILE_HELP: &str = "Compiles an input file into a supported output format\n\nUsage: executable compile [OPTIONS] <INPUT> [OUTPUT]\n\nArguments:\n  <INPUT>\n          Path to input Typst file. Use `-` to read input from stdin\n\n  [OUTPUT]\n          Path to output file (PDF, PNG, SVG, or HTML). Use `-` to write output\n          to stdout.\n\nOptions:\n  -f, --format <FORMAT>\n          The format of the output file, inferred from the extension by default\n\n          [possible values: pdf, png, svg, html]\n\n      --root <DIR>\n          Configures the project root (for absolute paths)\n\n      --input <key=value>\n          Add a string key-value pair visible through `sys.inputs`\n\n      --font-path <DIR>\n          Adds additional directories that are recursively searched for fonts.\n\n      --deps <PATH>\n          File path to which a list of current compilation's dependencies will\n          be written. Use `-` to write to stdout\n\n      --deps-format <DEPS_FORMAT>\n          File format to use for dependencies\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
const WATCH_HELP: &str = "Watches an input file and recompiles on changes\n\nUsage: executable watch [OPTIONS] <INPUT> [OUTPUT]\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n";
const EVAL_HELP: &str = "Evaluates a piece of Typst code, optionally in the context of a document\n\nUsage: executable eval [OPTIONS] <EXPRESSION>\n\nArguments:\n  <EXPRESSION>\n          The piece of Typst code to evaluate\n\nOptions:\n      --in <IN>\n          A file in whose context to evaluate the code. Can be used to\n          introspect the document. Use `-` to read input from stdin\n\n      --target <TARGET>\n          The target to compile for\n\n      --format <FORMAT>\n          The format to serialize in\n\n          [default: json]\n          [possible values: json, yaml]\n\n      --pretty\n          Whether to pretty-print the serialized output.\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
const FONTS_HELP: &str = "Lists all discovered fonts in system and custom font paths\n\nUsage: executable fonts [OPTIONS]\n\nOptions:\n      --font-path <DIR>\n          Adds additional directories that are recursively searched for fonts.\n\n      --ignore-system-fonts\n          Ensures system fonts won't be searched, unless explicitly included via\n          `--font-path`\n\n      --ignore-embedded-fonts\n          Ensures fonts embedded into Typst won't be considered\n\n      --variants\n          Also lists style variants of each font family\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
const INFO_HELP: &str = "Displays debugging information about Typst\n\nUsage: executable info [OPTIONS]\n\nOptions:\n  -f, --format <FORMAT>\n          The format to serialize in, if it should be machine-readable.\n\n          [possible values: json, yaml]\n\n      --pretty\n          Whether to pretty-print the serialized output.\n\n  -h, --help\n          Print help (see a summary with '-h')\n";
const INIT_HELP: &str = "Initializes a new project from a template\n\nUsage: executable init [OPTIONS] <TEMPLATE> [DIR]\n\nArguments:\n  <TEMPLATE>\n          The template to use, e.g. `@preview/charged-ieee`.\n\n  [DIR]\n          The project directory, defaults to the template's name\n\nOptions:\n  -h, --help\n          Print help (see a summary with '-h')\n";
const COMPLETIONS_HELP: &str = "Generates shell completion scripts\n\nUsage: executable completions <SHELL>\n\nArguments:\n  <SHELL>  The shell to generate completions for [possible values: bash, elvish,\n           fish, powershell, zsh]\n\nOptions:\n  -h, --help  Print help\n";

const FONT_VARIANTS: &str = "DejaVu Sans\n- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf\n- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf\nDejaVu Sans Mono\n- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf\n- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf\n- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Italic, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Italic, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>\nDejaVu Serif\n- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf\n- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: /usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf\nLibertinus Serif\n- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Italic, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Italic, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Normal, Weight: 600, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Italic, Weight: 600, Stretch: FontStretch(1000), Path: <embedded>\nNew Computer Modern\n- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Italic, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Italic, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>\nNew Computer Modern Math\n- Style: Normal, Weight: 700, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Normal, Weight: 450, Stretch: FontStretch(1000), Path: <embedded>\n- Style: Normal, Weight: 400, Stretch: FontStretch(1000), Path: <embedded>\n";

const INFO_JSON: &str = "{\"version\":\"0.14.2\",\"build\":{\"commit\":\"ccc34be79ab2555cd26c519b1eab45a3e9ec757a\",\"platform\":{\"os\":\"linux\",\"arch\":\"x86_64\"},\"settings\":{\"self-update\":false,\"http-server\":true}},\"features\":{\"html\":false,\"a11y-extras\":false},\"fonts\":{\"paths\":[],\"system\":true,\"embedded\":true},\"packages\":{\"package-path\":\"/home/agent/.local/share/typst/packages\",\"package-cache-path\":\"/home/agent/.cache/typst/packages\"},\"env\":{\"TYPST_CERT\":null,\"TYPST_FEATURES\":null,\"TYPST_FONT_PATHS\":null,\"TYPST_IGNORE_SYSTEM_FONTS\":null,\"TYPST_IGNORE_EMBEDDED_FONTS\":null,\"TYPST_PACKAGE_CACHE_PATH\":null,\"TYPST_PACKAGE_PATH\":null,\"TYPST_ROOT\":null,\"TYPST_UPDATE_BACKUP_PATH\":null,\"SOURCE_DATE_EPOCH\":null,\"XDG_CACHE_HOME\":null,\"XDG_DATA_HOME\":null,\"FONTCONFIG_FILE\":null,\"OPENSSL_CONF\":null,\"NO_COLOR\":null,\"NO_PROXY\":null,\"HTTP_PROXY\":null,\"HTTPS_PROXY\":null,\"ALL_PROXY\":null}}";
const INFO_JSON_PRETTY: &str = "{\n  \"version\": \"0.14.2\",\n  \"build\": {\n    \"commit\": \"ccc34be79ab2555cd26c519b1eab45a3e9ec757a\",\n    \"platform\": {\n      \"os\": \"linux\",\n      \"arch\": \"x86_64\"\n    },\n    \"settings\": {\n      \"self-update\": false,\n      \"http-server\": true\n    }\n  },\n  \"features\": {\n    \"html\": false,\n    \"a11y-extras\": false\n  },\n  \"fonts\": {\n    \"paths\": [],\n    \"system\": true,\n    \"embedded\": true\n  },\n  \"packages\": {\n    \"package-path\": \"/home/agent/.local/share/typst/packages\",\n    \"package-cache-path\": \"/home/agent/.cache/typst/packages\"\n  },\n  \"env\": {\n    \"TYPST_CERT\": null,\n    \"TYPST_FEATURES\": null,\n    \"TYPST_FONT_PATHS\": null,\n    \"TYPST_IGNORE_SYSTEM_FONTS\": null,\n    \"TYPST_IGNORE_EMBEDDED_FONTS\": null,\n    \"TYPST_PACKAGE_CACHE_PATH\": null,\n    \"TYPST_PACKAGE_PATH\": null,\n    \"TYPST_ROOT\": null,\n    \"TYPST_UPDATE_BACKUP_PATH\": null,\n    \"SOURCE_DATE_EPOCH\": null,\n    \"XDG_CACHE_HOME\": null,\n    \"XDG_DATA_HOME\": null,\n    \"FONTCONFIG_FILE\": null,\n    \"OPENSSL_CONF\": null,\n    \"NO_COLOR\": null,\n    \"NO_PROXY\": null,\n    \"HTTP_PROXY\": null,\n    \"HTTPS_PROXY\": null,\n    \"ALL_PROXY\": null\n  }\n}";
const INFO_YAML: &str = "version: 0.14.2\nbuild:\n  commit: ccc34be79ab2555cd26c519b1eab45a3e9ec757a\n  platform:\n    os: linux\n    arch: x86_64\n  settings:\n    self-update: false\n    http-server: true\nfeatures:\n  html: false\n  a11y-extras: false\nfonts:\n  paths: []\n  system: true\n  embedded: true\npackages:\n  package-path: /home/agent/.local/share/typst/packages\n  package-cache-path: /home/agent/.cache/typst/packages\nenv:\n  TYPST_CERT: null\n";
const INFO_HUMAN: &str = "Version 0.14.2 (ccc34be7, linux on x86_64)\n\nBuild settings\n  self-update off (Update Typst via `typst update`)\n  http-server on  (Serve HTML via `typst watch`)\n\nFeatures\n  html        off (Experimental HTML support)\n  a11y-extras off (Experimental accessibility additions)\n\nFonts\n  Custom font paths <none>\n  System fonts   on\n  Embedded fonts on\n\nPackages\n  Package path       /home/agent/.local/share/typst/packages\n  Package cache path /home/agent/.cache/typst/packages\n\nEnvironment variables\n  TYPST_CERT                  <unset>\n  TYPST_FEATURES              <unset>\n  TYPST_FONT_PATHS            <unset>\n  TYPST_IGNORE_SYSTEM_FONTS   <unset>\n  TYPST_IGNORE_EMBEDDED_FONTS <unset>\n  TYPST_PACKAGE_CACHE_PATH    <unset>\n  TYPST_PACKAGE_PATH          <unset>\n  TYPST_ROOT                  <unset>\n  TYPST_UPDATE_BACKUP_PATH    <unset>\n  SOURCE_DATE_EPOCH           <unset>\n";
