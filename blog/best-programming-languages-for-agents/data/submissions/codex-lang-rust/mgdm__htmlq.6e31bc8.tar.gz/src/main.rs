use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, Read, Write};

use url::Url;

#[derive(Clone, Debug)]
enum NodeData {
    Document,
    Element { name: String, attrs: Vec<(String, String)> },
    Text(String),
}

#[derive(Clone, Debug)]
struct Node {
    parent: Option<usize>,
    children: Vec<usize>,
    data: NodeData,
}

#[derive(Default)]
struct Options {
    text: bool,
    pretty: bool,
    ignore_ws: bool,
    detect_base: bool,
    attribute: Option<String>,
    base: Option<String>,
    filename: Option<String>,
    output: Option<String>,
    removes: Vec<String>,
    selectors: Vec<String>,
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err(msg) => {
            eprintln!("{}", msg);
            std::process::exit(1);
        }
    };

    let mut input = String::new();
    if let Some(path) = &opts.filename {
        input = fs::read_to_string(path).unwrap_or_else(|e| {
            eprintln!("{}: {}", path, e);
            std::process::exit(1);
        });
    } else {
        io::stdin().read_to_string(&mut input).unwrap();
    }

    let mut doc = parse_html(&input);
    ensure_html_document(&mut doc);

    let mut removed = HashSet::new();
    for sel in &opts.removes {
        if let Ok(groups) = parse_selector(sel) {
            for id in select_nodes(&doc, &groups) {
                mark_removed(&doc, id, &mut removed);
            }
        }
    }

    let base = effective_base(&doc, &opts);
    let selector = if opts.selectors.is_empty() {
        "html".to_string()
    } else {
        opts.selectors.join(" ")
    };
    let groups = parse_selector(&selector).unwrap_or_else(|_| {
        eprintln!("Failed to parse CSS selector: {}", selector);
        std::process::exit(101);
    });
    let matches = select_nodes(&doc, &groups);

    let mut out = String::new();
    for id in matches {
        if removed.contains(&id) || has_removed_ancestor(&doc, id, &removed) {
            continue;
        }
        if let Some(attr) = &opts.attribute {
            if let NodeData::Element { attrs, .. } = &doc[id].data {
                if let Some((_, val)) = attrs.iter().find(|(k, _)| k.eq_ignore_ascii_case(attr)) {
                    let mut v = decode_entities(val);
                    if attr.eq_ignore_ascii_case("href") {
                        if let Some(b) = &base {
                            v = absolutize(b, &v);
                        }
                    }
                    out.push_str(&v);
                    out.push('\n');
                }
            }
        } else if opts.text {
            let txt = text_content(&doc, id, &removed, opts.ignore_ws);
            out.push_str(&txt);
            out.push('\n');
        } else {
            if opts.pretty {
                out.push('\n');
                serialize_pretty(&doc, id, &removed, 0, &mut out);
                out.push('\n');
            } else {
                serialize(&doc, id, &removed, &mut out);
                out.push('\n');
            }
        }
    }

    if let Some(path) = &opts.output {
        fs::write(path, out).unwrap();
    } else {
        print!("{}", out);
        io::stdout().flush().ok();
    }
}

fn print_help() {
    println!("htmlq 0.4.0");
    println!("Michael Maclean <michael@mgdm.net>");
    println!("Runs CSS selectors on HTML\n");
    println!("USAGE:");
    println!("    executable [FLAGS] [OPTIONS] [--] [selector]...\n");
    println!("FLAGS:");
    println!("    -B, --detect-base          Try to detect the base URL from the <base> tag in the document");
    println!("    -h, --help                 Prints help information");
    println!("    -w, --ignore-whitespace    When printing text nodes, ignore those that consist entirely of whitespace");
    println!("    -p, --pretty               Pretty-print the serialised output");
    println!("    -t, --text                 Output only the contents of text nodes inside selected elements");
    println!("    -V, --version              Prints version information\n");
    println!("OPTIONS:");
    println!("    -a, --attribute <attribute>         Only return this attribute (if present) from selected elements");
    println!("    -b, --base <base>                   Use this URL as the base for links");
    println!("    -f, --filename <FILE>               The input file. Defaults to stdin");
    println!("    -o, --output <FILE>                 The output file. Defaults to stdout");
    println!("    -r, --remove-nodes <SELECTOR>...    Remove nodes matching this expression before output. May be specified multiple times\n");
    println!("ARGS:");
    println!("    <selector>...    The CSS expression to select [default: html]");
}

fn parse_args() -> Result<Options, String> {
    let mut opts = Options::default();
    let mut args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if a == "--" {
            opts.selectors.extend(args.drain(i + 1..));
            break;
        } else if a == "-h" || a == "--help" {
            print_help();
            std::process::exit(0);
        } else if a == "-V" || a == "--version" {
            println!("htmlq 0.4.0");
            std::process::exit(0);
        } else if a == "--text" {
            opts.text = true;
        } else if a == "--pretty" {
            opts.pretty = true;
        } else if a == "--ignore-whitespace" {
            opts.ignore_ws = true;
        } else if a == "--detect-base" {
            opts.detect_base = true;
        } else if a == "--attribute" || a == "--base" || a == "--filename" || a == "--output" || a == "--remove-nodes" {
            let val = args.get(i + 1).ok_or_else(|| format!("error: The argument '{}' requires a value", a))?.clone();
            match a.as_str() {
                "--attribute" => opts.attribute = Some(val),
                "--base" => opts.base = Some(val),
                "--filename" => opts.filename = Some(val),
                "--output" => opts.output = Some(val),
                "--remove-nodes" => opts.removes.push(val),
                _ => {}
            }
            i += 1;
        } else if let Some(v) = a.strip_prefix("--attribute=") {
            opts.attribute = Some(v.to_string());
        } else if let Some(v) = a.strip_prefix("--base=") {
            opts.base = Some(v.to_string());
        } else if let Some(v) = a.strip_prefix("--filename=") {
            opts.filename = Some(v.to_string());
        } else if let Some(v) = a.strip_prefix("--output=") {
            opts.output = Some(v.to_string());
        } else if let Some(v) = a.strip_prefix("--remove-nodes=") {
            opts.removes.push(v.to_string());
        } else if a.starts_with('-') && a.len() > 1 {
            let mut chars = a[1..].chars().peekable();
            while let Some(c) = chars.next() {
                match c {
                    't' => opts.text = true,
                    'p' => opts.pretty = true,
                    'w' => opts.ignore_ws = true,
                    'B' => opts.detect_base = true,
                    'h' => {
                        print_help();
                        std::process::exit(0);
                    }
                    'V' => {
                        println!("htmlq 0.4.0");
                        std::process::exit(0);
                    }
                    'a' | 'b' | 'f' | 'o' | 'r' => {
                        let rest: String = chars.collect();
                        let val = if rest.is_empty() {
                            i += 1;
                            args.get(i).ok_or_else(|| format!("error: The argument '-{}' requires a value", c))?.clone()
                        } else {
                            rest
                        };
                        match c {
                            'a' => opts.attribute = Some(val),
                            'b' => opts.base = Some(val),
                            'f' => opts.filename = Some(val),
                            'o' => opts.output = Some(val),
                            'r' => opts.removes.push(val),
                            _ => {}
                        }
                        break;
                    }
                    _ => return Err(format!("error: Found argument '-{}' which wasn't expected", c)),
                }
            }
        } else {
            opts.selectors.push(a);
        }
        i += 1;
    }
    Ok(opts)
}

fn parse_html(input: &str) -> Vec<Node> {
    let mut nodes = vec![Node { parent: None, children: Vec::new(), data: NodeData::Document }];
    let mut stack = vec![0usize];
    let bytes = input.as_bytes();
    let mut i = 0usize;
    while i < bytes.len() {
        if bytes[i] == b'<' {
            if input[i..].starts_with("<!--") {
                if let Some(end) = input[i + 4..].find("-->") {
                    i += 4 + end + 3;
                    continue;
                }
            }
            if i + 1 < bytes.len() && bytes[i + 1] == b'!' {
                if let Some(end) = input[i..].find('>') {
                    i += end + 1;
                    continue;
                }
            }
            if i + 1 < bytes.len() && bytes[i + 1] == b'/' {
                if let Some(end) = input[i..].find('>') {
                    let name = input[i + 2..i + end].trim().to_ascii_lowercase();
                    while stack.len() > 1 {
                        let top = *stack.last().unwrap();
                        if element_name(&nodes[top]).map(|n| n == name).unwrap_or(false) {
                            stack.pop();
                            break;
                        }
                        stack.pop();
                    }
                    i += end + 1;
                    continue;
                }
            }
            if let Some(end) = find_tag_end(input, i + 1) {
                let inside = input[i + 1..end].trim();
                if !inside.is_empty() {
                    let self_close = inside.ends_with('/');
                    let content = inside.trim_end_matches('/').trim();
                    let (name, attrs) = parse_tag(content);
                    if !name.is_empty() {
                        let parent = *stack.last().unwrap();
                        let id = nodes.len();
                        nodes.push(Node { parent: Some(parent), children: Vec::new(), data: NodeData::Element { name: name.clone(), attrs } });
                        nodes[parent].children.push(id);
                        if !self_close && !is_void(&name) {
                            stack.push(id);
                        }
                    }
                }
                i = end + 1;
            } else {
                add_text(&mut nodes, *stack.last().unwrap(), &input[i..]);
                break;
            }
        } else {
            let next = input[i..].find('<').map(|p| i + p).unwrap_or(bytes.len());
            add_text(&mut nodes, *stack.last().unwrap(), &input[i..next]);
            i = next;
        }
    }
    nodes
}

fn ensure_html_document(nodes: &mut Vec<Node>) {
    let has_html = nodes[0].children.iter().any(|&c| element_name(&nodes[c]) == Some("html"));
    if has_html {
        return;
    }
    let old = std::mem::take(&mut nodes[0].children);
    let html = nodes.len();
    nodes.push(Node { parent: Some(0), children: Vec::new(), data: NodeData::Element { name: "html".into(), attrs: Vec::new() } });
    let head = nodes.len();
    nodes.push(Node { parent: Some(html), children: Vec::new(), data: NodeData::Element { name: "head".into(), attrs: Vec::new() } });
    let body = nodes.len();
    nodes.push(Node { parent: Some(html), children: old.clone(), data: NodeData::Element { name: "body".into(), attrs: Vec::new() } });
    for c in old {
        nodes[c].parent = Some(body);
    }
    nodes[html].children.push(head);
    nodes[html].children.push(body);
    nodes[0].children.push(html);
}

fn add_text(nodes: &mut Vec<Node>, parent: usize, text: &str) {
    if text.is_empty() {
        return;
    }
    let id = nodes.len();
    nodes.push(Node { parent: Some(parent), children: Vec::new(), data: NodeData::Text(text.to_string()) });
    nodes[parent].children.push(id);
}

fn find_tag_end(s: &str, start: usize) -> Option<usize> {
    let mut quote = None;
    for (off, ch) in s[start..].char_indices() {
        match (quote, ch) {
            (Some(q), c) if c == q => quote = None,
            (None, '"' | '\'') => quote = Some(ch),
            (None, '>') => return Some(start + off),
            _ => {}
        }
    }
    None
}

fn parse_tag(s: &str) -> (String, Vec<(String, String)>) {
    let mut pos = 0usize;
    let chars: Vec<char> = s.chars().collect();
    while pos < chars.len() && !chars[pos].is_whitespace() {
        pos += 1;
    }
    let name: String = chars[..pos].iter().collect::<String>().to_ascii_lowercase();
    let mut attrs = Vec::new();
    while pos < chars.len() {
        while pos < chars.len() && chars[pos].is_whitespace() {
            pos += 1;
        }
        if pos >= chars.len() {
            break;
        }
        let start = pos;
        while pos < chars.len() && !chars[pos].is_whitespace() && chars[pos] != '=' {
            pos += 1;
        }
        let key: String = chars[start..pos].iter().collect::<String>().to_ascii_lowercase();
        while pos < chars.len() && chars[pos].is_whitespace() {
            pos += 1;
        }
        let mut val = String::new();
        if pos < chars.len() && chars[pos] == '=' {
            pos += 1;
            while pos < chars.len() && chars[pos].is_whitespace() {
                pos += 1;
            }
            if pos < chars.len() && (chars[pos] == '"' || chars[pos] == '\'') {
                let q = chars[pos];
                pos += 1;
                let startv = pos;
                while pos < chars.len() && chars[pos] != q {
                    pos += 1;
                }
                val = chars[startv..pos].iter().collect();
                if pos < chars.len() {
                    pos += 1;
                }
            } else {
                let startv = pos;
                while pos < chars.len() && !chars[pos].is_whitespace() {
                    pos += 1;
                }
                val = chars[startv..pos].iter().collect();
            }
        }
        if !key.is_empty() {
            attrs.push((key, val));
        }
    }
    attrs.sort_by(|a, b| a.0.cmp(&b.0));
    (name, attrs)
}

fn is_void(name: &str) -> bool {
    matches!(name, "area" | "base" | "br" | "col" | "embed" | "hr" | "img" | "input" | "link" | "meta" | "param" | "source" | "track" | "wbr")
}

fn element_name(node: &Node) -> Option<&str> {
    match &node.data {
        NodeData::Element { name, .. } => Some(name),
        _ => None,
    }
}

#[derive(Clone, Debug)]
struct Group(Vec<(Combinator, Simple)>);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Combinator {
    Descendant,
    Child,
}

#[derive(Clone, Debug, Default)]
struct Simple {
    tag: Option<String>,
    id: Option<String>,
    classes: Vec<String>,
    attrs: Vec<(String, AttrOp, String)>,
    pseudos: Vec<Pseudo>,
}

#[derive(Clone, Copy, Debug)]
enum AttrOp {
    Exists,
    Eq,
    Includes,
    DashMatch,
    Prefix,
    Suffix,
    Contains,
}

#[derive(Clone, Debug)]
enum Pseudo {
    FirstChild,
    LastChild,
    NthChild(usize),
    NthOdd,
    NthEven,
    FirstOfType,
    LastOfType,
}

fn parse_selector(sel: &str) -> Result<Vec<Group>, ()> {
    let mut groups = Vec::new();
    for part in split_top(sel, ',') {
        let mut items = Vec::new();
        let mut comb = Combinator::Descendant;
        let mut cur = String::new();
        let mut in_attr = 0i32;
        let mut quote = None;
        let mut last_space = false;
        for ch in part.chars() {
            match (quote, ch) {
                (Some(q), c) if c == q => {
                    quote = None;
                    cur.push(ch);
                }
                (Some(_), _) => cur.push(ch),
                (None, '"' | '\'') => {
                    quote = Some(ch);
                    cur.push(ch);
                }
                (None, '[') => {
                    in_attr += 1;
                    cur.push(ch);
                }
                (None, ']') => {
                    in_attr -= 1;
                    cur.push(ch);
                }
                (None, '>') if in_attr == 0 => {
                    push_simple(&mut items, comb, &cur)?;
                    cur.clear();
                    comb = Combinator::Child;
                    last_space = false;
                }
                (None, c) if c.is_whitespace() && in_attr == 0 => {
                    if !cur.trim().is_empty() {
                        push_simple(&mut items, comb, &cur)?;
                        cur.clear();
                        comb = Combinator::Descendant;
                    }
                    last_space = true;
                }
                _ => {
                    if last_space && !cur.is_empty() {
                        push_simple(&mut items, comb, &cur)?;
                        cur.clear();
                        comb = Combinator::Descendant;
                    }
                    last_space = false;
                    cur.push(ch);
                }
            }
        }
        push_simple(&mut items, comb, &cur)?;
        if !items.is_empty() {
            groups.push(Group(items));
        }
    }
    if groups.is_empty() { Err(()) } else { Ok(groups) }
}

fn split_top(s: &str, sep: char) -> Vec<&str> {
    let mut out = Vec::new();
    let mut start = 0usize;
    let mut in_attr = 0i32;
    let mut quote = None;
    for (i, ch) in s.char_indices() {
        match (quote, ch) {
            (Some(q), c) if c == q => quote = None,
            (Some(_), _) => {}
            (None, '"' | '\'') => quote = Some(ch),
            (None, '[') => in_attr += 1,
            (None, ']') => in_attr -= 1,
            (None, c) if c == sep && in_attr == 0 => {
                out.push(s[start..i].trim());
                start = i + ch.len_utf8();
            }
            _ => {}
        }
    }
    out.push(s[start..].trim());
    out
}

fn push_simple(items: &mut Vec<(Combinator, Simple)>, comb: Combinator, s: &str) -> Result<(), ()> {
    let t = s.trim();
    if t.is_empty() {
        return Ok(());
    }
    items.push((comb, parse_simple(t)?));
    Ok(())
}

fn parse_simple(s: &str) -> Result<Simple, ()> {
    let mut simple = Simple::default();
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0usize;
    if i < chars.len() && (chars[i].is_ascii_alphabetic() || chars[i] == '*' || chars[i] == '_') {
        let st = i;
        i += 1;
        while i < chars.len() && (chars[i].is_ascii_alphanumeric() || chars[i] == '-' || chars[i] == '_') {
            i += 1;
        }
        let tag: String = chars[st..i].iter().collect();
        if tag != "*" {
            simple.tag = Some(tag.to_ascii_lowercase());
        }
    }
    while i < chars.len() {
        match chars[i] {
            '#' => {
                i += 1;
                let st = i;
                while i < chars.len() && ident_char(chars[i]) {
                    i += 1;
                }
                simple.id = Some(chars[st..i].iter().collect());
            }
            '.' => {
                i += 1;
                let st = i;
                while i < chars.len() && ident_char(chars[i]) {
                    i += 1;
                }
                simple.classes.push(chars[st..i].iter().collect());
            }
            '[' => {
                i += 1;
                let st = i;
                let mut quote = None;
                while i < chars.len() {
                    match (quote, chars[i]) {
                        (Some(q), c) if c == q => quote = None,
                        (Some(_), _) => {}
                        (None, '"' | '\'') => quote = Some(chars[i]),
                        (None, ']') => break,
                        _ => {}
                    }
                    i += 1;
                }
                let inside: String = chars[st..i].iter().collect();
                if i < chars.len() {
                    i += 1;
                }
                let (key, op, val) = parse_attr_selector(&inside);
                if key.is_empty() {
                    return Err(());
                }
                simple.attrs.push((key, op, val));
            }
            ':' => {
                i += 1;
                let st = i;
                while i < chars.len() && (chars[i].is_ascii_alphabetic() || chars[i] == '-') {
                    i += 1;
                }
                let name: String = chars[st..i].iter().collect::<String>().to_ascii_lowercase();
                let mut arg = String::new();
                if i < chars.len() && chars[i] == '(' {
                    i += 1;
                    let st_arg = i;
                    while i < chars.len() && chars[i] != ')' {
                        i += 1;
                    }
                    arg = chars[st_arg..i].iter().collect::<String>().trim().to_string();
                    if i < chars.len() {
                        i += 1;
                    }
                }
                match name.as_str() {
                    "first-child" => simple.pseudos.push(Pseudo::FirstChild),
                    "last-child" => simple.pseudos.push(Pseudo::LastChild),
                    "first-of-type" => simple.pseudos.push(Pseudo::FirstOfType),
                    "last-of-type" => simple.pseudos.push(Pseudo::LastOfType),
                    "nth-child" => {
                        if let Ok(n) = arg.parse::<usize>() {
                            simple.pseudos.push(Pseudo::NthChild(n));
                        } else if arg.eq_ignore_ascii_case("odd") {
                            simple.pseudos.push(Pseudo::NthOdd);
                        } else if arg.eq_ignore_ascii_case("even") {
                            simple.pseudos.push(Pseudo::NthEven);
                        }
                    }
                    _ => {}
                }
            }
            _ => return Err(()),
        }
    }
    Ok(simple)
}

fn parse_attr_selector(inside: &str) -> (String, AttrOp, String) {
    for (pat, op) in [
        ("~=", AttrOp::Includes),
        ("|=", AttrOp::DashMatch),
        ("^=", AttrOp::Prefix),
        ("$=", AttrOp::Suffix),
        ("*=", AttrOp::Contains),
        ("=", AttrOp::Eq),
    ] {
        if let Some(pos) = inside.find(pat) {
            let key = inside[..pos].trim().to_ascii_lowercase();
            let val = inside[pos + pat.len()..].trim().trim_matches('"').trim_matches('\'').to_string();
            return (key, op, val);
        }
    }
    (inside.trim().to_ascii_lowercase(), AttrOp::Exists, String::new())
}

fn ident_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '-' || c == '_' || c == ':'
}

fn select_nodes(doc: &[Node], groups: &[Group]) -> Vec<usize> {
    let mut out = Vec::new();
    traverse(doc, 0, &mut |id| {
        if matches!(doc[id].data, NodeData::Element { .. }) && groups.iter().any(|g| group_matches(doc, id, g)) {
            out.push(id);
        }
    });
    out
}

fn traverse<F: FnMut(usize)>(doc: &[Node], id: usize, f: &mut F) {
    for &c in &doc[id].children {
        f(c);
        traverse(doc, c, f);
    }
}

fn group_matches(doc: &[Node], id: usize, group: &Group) -> bool {
    if group.0.is_empty() {
        return false;
    }
    match_from(doc, id, group, group.0.len() - 1)
}

fn match_from(doc: &[Node], id: usize, group: &Group, idx: usize) -> bool {
    if !simple_matches(doc, id, &group.0[idx].1) {
        return false;
    }
    if idx == 0 {
        return true;
    }
    match group.0[idx].0 {
        Combinator::Child => doc[id].parent.map(|p| match_from(doc, p, group, idx - 1)).unwrap_or(false),
        Combinator::Descendant => {
            let mut p = doc[id].parent;
            while let Some(pid) = p {
                if match_from(doc, pid, group, idx - 1) {
                    return true;
                }
                p = doc[pid].parent;
            }
            false
        }
    }
}

fn simple_matches(doc: &[Node], id: usize, simple: &Simple) -> bool {
    let node = &doc[id];
    let NodeData::Element { name, attrs } = &node.data else {
        return false;
    };
    if let Some(tag) = &simple.tag {
        if name != tag {
            return false;
        }
    }
    if let Some(id) = &simple.id {
        if attr(attrs, "id") != Some(id.as_str()) {
            return false;
        }
    }
    for class in &simple.classes {
        let Some(v) = attr(attrs, "class") else {
            return false;
        };
        if !v.split_whitespace().any(|c| c == class) {
            return false;
        }
    }
    for (k, op, want) in &simple.attrs {
        let Some(v) = attr(attrs, k) else {
            return false;
        };
        let ok = match op {
            AttrOp::Exists => true,
            AttrOp::Eq => v == want,
            AttrOp::Includes => v.split_whitespace().any(|p| p == want),
            AttrOp::DashMatch => v == want || v.strip_prefix(want).is_some_and(|rest| rest.starts_with('-')),
            AttrOp::Prefix => v.starts_with(want),
            AttrOp::Suffix => v.ends_with(want),
            AttrOp::Contains => v.contains(want),
        };
        if !ok {
            return false;
        }
    }
    for pseudo in &simple.pseudos {
        if !pseudo_matches(doc, id, pseudo) {
            return false;
        }
    }
    true
}

fn pseudo_matches(doc: &[Node], id: usize, pseudo: &Pseudo) -> bool {
    match pseudo {
        Pseudo::FirstChild => sibling_position(doc, id).is_some_and(|(pos, _)| pos == 1),
        Pseudo::LastChild => sibling_position(doc, id).is_some_and(|(pos, total)| pos == total),
        Pseudo::NthChild(n) => {
            sibling_position(doc, id).is_some_and(|(pos, _)| pos == *n)
        }
        Pseudo::NthOdd => sibling_position(doc, id).is_some_and(|(pos, _)| pos % 2 == 1),
        Pseudo::NthEven => sibling_position(doc, id).is_some_and(|(pos, _)| pos % 2 == 0),
        Pseudo::FirstOfType => type_position(doc, id).is_some_and(|(pos, _)| pos == 1),
        Pseudo::LastOfType => type_position(doc, id).is_some_and(|(pos, total)| pos == total),
    }
}

fn sibling_position(doc: &[Node], id: usize) -> Option<(usize, usize)> {
    let parent = doc[id].parent?;
    let sibs: Vec<usize> = doc[parent].children.iter().copied().filter(|&c| matches!(doc[c].data, NodeData::Element { .. })).collect();
    let pos = sibs.iter().position(|&c| c == id)? + 1;
    Some((pos, sibs.len()))
}

fn type_position(doc: &[Node], id: usize) -> Option<(usize, usize)> {
    let parent = doc[id].parent?;
    let my_name = element_name(&doc[id])?;
    let sibs: Vec<usize> = doc[parent].children.iter().copied().filter(|&c| element_name(&doc[c]) == Some(my_name)).collect();
    let pos = sibs.iter().position(|&c| c == id)? + 1;
    Some((pos, sibs.len()))
}

fn attr<'a>(attrs: &'a [(String, String)], key: &str) -> Option<&'a str> {
    attrs.iter().find(|(k, _)| k.eq_ignore_ascii_case(key)).map(|(_, v)| v.as_str())
}

fn mark_removed(doc: &[Node], id: usize, removed: &mut HashSet<usize>) {
    removed.insert(id);
    for &c in &doc[id].children {
        mark_removed(doc, c, removed);
    }
}

fn has_removed_ancestor(doc: &[Node], id: usize, removed: &HashSet<usize>) -> bool {
    let mut p = doc[id].parent;
    while let Some(pid) = p {
        if removed.contains(&pid) {
            return true;
        }
        p = doc[pid].parent;
    }
    false
}

fn serialize(doc: &[Node], id: usize, removed: &HashSet<usize>, out: &mut String) {
    if removed.contains(&id) {
        return;
    }
    match &doc[id].data {
        NodeData::Document => {
            for &c in &doc[id].children {
                serialize(doc, c, removed, out);
            }
        }
        NodeData::Text(t) => out.push_str(t),
        NodeData::Element { name, attrs } => {
            out.push('<');
            out.push_str(name);
            for (k, v) in attrs {
                out.push(' ');
                out.push_str(k);
                out.push_str("=\"");
                out.push_str(&escape_attr(v));
                out.push('"');
            }
            out.push('>');
            for &c in &doc[id].children {
                serialize(doc, c, removed, out);
            }
            if !is_void(name) {
                out.push_str("</");
                out.push_str(name);
                out.push('>');
            }
        }
    }
}

fn serialize_pretty(doc: &[Node], id: usize, removed: &HashSet<usize>, depth: usize, out: &mut String) {
    if removed.contains(&id) {
        return;
    }
    match &doc[id].data {
        NodeData::Text(t) => out.push_str(t.trim()),
        NodeData::Document => {
            for &c in &doc[id].children {
                serialize_pretty(doc, c, removed, depth, out);
            }
        }
        NodeData::Element { name, attrs } => {
            out.push_str(&"  ".repeat(depth));
            out.push('<');
            out.push_str(name);
            for (k, v) in attrs {
                out.push(' ');
                out.push_str(k);
                out.push_str("=\"");
                out.push_str(&escape_attr(v));
                out.push('"');
            }
            out.push('>');
            if is_void(name) {
                return;
            }
            let elem_children: Vec<usize> = doc[id].children.iter().copied().filter(|c| matches!(doc[*c].data, NodeData::Element { .. })).collect();
            if elem_children.is_empty() {
                for &c in &doc[id].children {
                    serialize_pretty(doc, c, removed, 0, out);
                }
                out.push_str("</");
                out.push_str(name);
                out.push('>');
            } else {
                out.push('\n');
                for &c in &doc[id].children {
                    if matches!(doc[c].data, NodeData::Text(_)) {
                        if text_content(doc, c, removed, true).is_empty() {
                            continue;
                        }
                    }
                    serialize_pretty(doc, c, removed, depth + 1, out);
                    out.push('\n');
                }
                out.push_str(&"  ".repeat(depth));
                out.push_str("</");
                out.push_str(name);
                out.push('>');
            }
        }
    }
}

fn escape_attr(s: &str) -> String {
    s.replace('&', "&amp;").replace('"', "&quot;").replace('<', "&lt;").replace('>', "&gt;")
}

fn text_content(doc: &[Node], id: usize, removed: &HashSet<usize>, ignore_ws: bool) -> String {
    if removed.contains(&id) {
        return String::new();
    }
    match &doc[id].data {
        NodeData::Text(t) => {
            let d = decode_entities(t);
            if ignore_ws && d.trim().is_empty() { String::new() } else { d }
        }
        _ => {
            let mut s = String::new();
            for &c in &doc[id].children {
                s.push_str(&text_content(doc, c, removed, ignore_ws));
            }
            s
        }
    }
}

fn decode_entities(s: &str) -> String {
    let mut out = String::new();
    let mut i = 0usize;
    while let Some(pos) = s[i..].find('&') {
        out.push_str(&s[i..i + pos]);
        i += pos;
        if let Some(end) = s[i..].find(';') {
            let ent = &s[i + 1..i + end];
            let repl = match ent {
                "lt" => Some("<".to_string()),
                "gt" => Some(">".to_string()),
                "amp" => Some("&".to_string()),
                "quot" => Some("\"".to_string()),
                "apos" => Some("'".to_string()),
                "nbsp" => Some("\u{a0}".to_string()),
                _ if ent.starts_with("#x") || ent.starts_with("#X") => u32::from_str_radix(&ent[2..], 16).ok().and_then(char::from_u32).map(|c| c.to_string()),
                _ if ent.starts_with('#') => ent[1..].parse::<u32>().ok().and_then(char::from_u32).map(|c| c.to_string()),
                _ => None,
            };
            if let Some(r) = repl {
                out.push_str(&r);
            } else {
                out.push('&');
                out.push_str(ent);
                out.push(';');
            }
            i += end + 1;
        } else {
            out.push('&');
            i += 1;
        }
    }
    out.push_str(&s[i..]);
    out
}

fn effective_base(doc: &[Node], opts: &Options) -> Option<String> {
    if opts.detect_base {
        let groups = parse_selector("base").ok()?;
        for id in select_nodes(doc, &groups) {
            if let NodeData::Element { attrs, .. } = &doc[id].data {
                if let Some(h) = attr(attrs, "href") {
                    return Some(h.to_string());
                }
            }
        }
    }
    opts.base.clone()
}

fn absolutize(base: &str, value: &str) -> String {
    if value.is_empty() {
        return value.to_string();
    }
    if Url::parse(value).is_ok() {
        return value.to_string();
    }
    Url::parse(base).and_then(|b| b.join(value)).map(|u| u.to_string()).unwrap_or_else(|_| value.to_string())
}
