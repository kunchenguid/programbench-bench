use base64::Engine;
use serde_json::{Map, Value};
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{Read, Write};
use std::net::TcpStream;
use std::process;
use std::process::Stdio;
use std::time::Instant;
use url::Url;

const HELP: &str = r#"bat is a Go implemented CLI cURL-like tool for humans.

Usage:

	bat [flags] [METHOD] URL [ITEM [ITEM]]

flags:
  -a, -auth=USER[:PASS]       Pass a username:password pair as the argument
  -b, -bench=false            Sends bench requests to URL
  -b.N=1000                   Number of requests to run
  -b.C=100                    Number of requests to run concurrently
  -body=""                    Send RAW data as body
  -f, -form=false             Submitting the data as a form
  -j, -json=true              Send the data in a JSON object
  -p, -pretty=true            Print Json Pretty Format
  -i, -insecure=false         Allow connections to SSL sites without certs
  -proxy=PROXY_URL            Proxy with host and port
  -print="A"                  String specifying what the output should contain, default will print all information
         "H" request headers
         "B" request body
         "h" response headers
         "b" response body
  -v, -version=true           Show Version Number

METHOD:
  bat defaults to either GET (if there is no request data) or POST (with request data).

URL:
  The only information needed to perform a request is a URL. The default scheme is http://,
  which can be omitted from the argument; example.org works just fine.

ITEM:
  Can be any of:
    Query string   key=value
    Header         key:value
    Post data      key=value
    File upload    key@/path/file

Example:

	bat beego.me

more help information please refer to https://github.com/astaxie/bat
"#;

#[derive(Clone)]
struct Config {
    auth: Option<String>,
    bench: bool,
    bench_n: usize,
    form: bool,
    json: bool,
    pretty: bool,
    body: Option<String>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            auth: None,
            bench: false,
            bench_n: 1000,
            form: false,
            json: true,
            pretty: true,
            body: None,
        }
    }
}

#[derive(Clone)]
struct RequestSpec {
    method: String,
    url: Url,
    display_url: String,
    headers: Vec<(String, String)>,
    body: Vec<u8>,
    content_type: Option<String>,
}

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        print!("{HELP}\n");
        process::exit(2);
    }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print!("{HELP}\n");
        process::exit(2);
    }
    if args.iter().any(|a| a == "--version") {
        println!("Version: 0.1.0");
        return;
    }

    let (cfg, rest) = parse_flags(&mut args).unwrap_or_else(|e| {
        eprintln!("{e}");
        print!("{HELP}\n");
        process::exit(2);
    });

    if rest.is_empty() {
        print!("{HELP}\n");
        process::exit(2);
    }
    let spec = build_request(&cfg, &rest).unwrap_or_else(|e| {
        eprintln!("{e}");
        process::exit(2);
    });

    if cfg.bench {
        bench(&spec, cfg.bench_n);
        return;
    }

    match send(&spec) {
        Ok(resp) => print_response(&resp, cfg.pretty),
        Err(e) => {
            let verb = title_case(&spec.method);
            eprintln!("can't get the url {verb} \"{}\": {e}", spec.display_url);
            process::exit(2);
        }
    }
}

fn parse_flags(args: &mut Vec<String>) -> Result<(Config, Vec<String>), String> {
    let mut cfg = Config::default();
    let mut rest = Vec::new();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if !a.starts_with('-') || a == "-" {
            rest.extend(args[i..].iter().cloned());
            break;
        }
        let (name, inline) = if let Some((n, v)) = a.split_once('=') {
            (n.to_string(), Some(v.to_string()))
        } else {
            (a.to_string(), None)
        };
        let take = |i: &mut usize| -> Result<String, String> {
            if let Some(v) = inline.clone() {
                Ok(v)
            } else {
                *i += 1;
                args.get(*i)
                    .cloned()
                    .ok_or_else(|| format!("flag needs an argument: {name}"))
            }
        };
        match name.as_str() {
            "-v" | "-version" => {
                println!("Version: 0.1.0");
                process::exit(0);
            }
            "-a" | "-auth" => cfg.auth = Some(take(&mut i)?),
            "-b" | "-bench" => cfg.bench = inline.as_deref().map(parse_bool).unwrap_or(true),
            "-b.N" => cfg.bench_n = take(&mut i)?.parse().unwrap_or(1000),
            "-b.C" => {
                let _ = take(&mut i)?;
            }
            "-body" => cfg.body = Some(take(&mut i)?),
            "-f" | "-form" => cfg.form = inline.as_deref().map(parse_bool).unwrap_or(true),
            "-json" => cfg.json = inline.as_deref().map(parse_bool).unwrap_or(true),
            "-p" | "-pretty" => cfg.pretty = inline.as_deref().map(parse_bool).unwrap_or(true),
            "-i" | "-insecure" => {
                let _ = inline.as_deref().map(parse_bool).unwrap_or(true);
            }
            "-proxy" | "-print" => {
                let _ = take(&mut i)?;
            }
            other => return Err(format!("flag provided but not defined: {other}")),
        }
        i += 1;
    }
    Ok((cfg, rest))
}

fn parse_bool(s: &str) -> bool {
    !matches!(s, "false" | "0" | "no" | "False" | "FALSE")
}

fn build_request(cfg: &Config, rest: &[String]) -> Result<RequestSpec, String> {
    let methods = ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"];
    let mut idx = 0;
    let mut method = String::new();
    if methods.contains(&rest[0].to_ascii_uppercase().as_str()) {
        method = rest[0].to_ascii_uppercase();
        idx = 1;
    }
    let url_arg = rest.get(idx).ok_or_else(|| "Miss the URL".to_string())?;
    if methods.contains(&url_arg.to_ascii_uppercase().as_str()) {
        return Err("Miss the URL".to_string());
    }
    idx += 1;

    let mut headers = Vec::new();
    let mut data = BTreeMap::new();
    let mut files = Vec::new();
    for item in &rest[idx..] {
        if let Some((k, v)) = item.split_once(':') {
            headers.push((k.to_string(), v.to_string()));
        } else if let Some((k, v)) = item.split_once('@') {
            files.push((k.to_string(), v.to_string()));
        } else if let Some((k, v)) = item.split_once('=') {
            data.insert(k.to_string(), v.to_string());
        }
    }

    if method.is_empty() {
        method = if cfg.body.is_some() || !data.is_empty() || !files.is_empty() {
            "POST".to_string()
        } else {
            "GET".to_string()
        };
    }

    let normalized_input = if url_arg.contains("://") {
        url_arg.to_string()
    } else {
        format!("http://{url_arg}")
    };
    let mut url = normalize_url(url_arg)?;
    if method == "GET" {
        for (k, v) in &data {
            url.query_pairs_mut().append_pair(k, v);
        }
    }

    let mut body = Vec::new();
    let mut content_type = None;
    if let Some(raw) = &cfg.body {
        body = raw.as_bytes().to_vec();
    } else if method != "GET" && !files.is_empty() {
        let boundary = "------------------------batboundary";
        content_type = Some(format!("multipart/form-data; boundary={boundary}"));
        for (k, p) in files {
            let bytes = fs::read(&p).unwrap_or_default();
            let name = p.rsplit('/').next().unwrap_or(&p);
            body.extend_from_slice(format!("--{boundary}\r\nContent-Disposition: form-data; name=\"{k}\"; filename=\"{name}\"\r\n\r\n").as_bytes());
            body.extend_from_slice(&bytes);
            body.extend_from_slice(b"\r\n");
        }
        body.extend_from_slice(format!("--{boundary}--\r\n").as_bytes());
    } else if method != "GET" && !data.is_empty() {
        if cfg.form || !cfg.json {
            let encoded = url::form_urlencoded::Serializer::new(String::new())
                .extend_pairs(data.iter())
                .finish();
            body = encoded.into_bytes();
            content_type = Some("application/x-www-form-urlencoded".to_string());
        } else {
            let mut obj = Map::new();
            for (k, v) in data {
                obj.insert(k, Value::String(v));
            }
            body = serde_json::to_vec(&Value::Object(obj)).unwrap();
            body.push(b'\n');
            content_type = Some("application/json".to_string());
        }
    }

    if let Some(auth) = cfg.auth.as_ref().or_else(|| {
        if !url.username().is_empty() {
            None
        } else {
            None
        }
    }) {
        let token = base64::engine::general_purpose::STANDARD.encode(auth);
        headers.push(("Authorization".to_string(), format!("Basic {token}")));
    } else if !url.username().is_empty() {
        let user = url.username().to_string();
        let pass = url.password().unwrap_or("");
        let token = base64::engine::general_purpose::STANDARD.encode(format!("{user}:{pass}"));
        headers.push(("Authorization".to_string(), format!("Basic {token}")));
        let _ = url.set_username("");
        let _ = url.set_password(None);
    }

    let display_url = if url.query().is_none()
        && url.path() == "/"
        && !normalized_input.ends_with('/')
    {
        normalized_input
    } else {
        url.to_string()
    };

    Ok(RequestSpec {
        method,
        url,
        display_url,
        headers,
        body,
        content_type,
    })
}

fn normalize_url(s: &str) -> Result<Url, String> {
    let with_scheme = if s.contains("://") {
        s.to_string()
    } else {
        format!("http://{s}")
    };
    Url::parse(&with_scheme).map_err(|e| e.to_string())
}

struct Response {
    status: u16,
    reason: String,
    headers: Vec<(String, String)>,
    body: Vec<u8>,
}

fn send(spec: &RequestSpec) -> Result<Response, String> {
    if spec.url.scheme() != "http" && spec.url.scheme() != "https" {
        return Err("unsupported protocol scheme".to_string());
    }
    let host = spec.url.host_str().ok_or_else(|| "missing host".to_string())?;
    let port = spec
        .url
        .port_or_known_default()
        .unwrap_or(if spec.url.scheme() == "https" { 443 } else { 80 });
    let path = {
        let mut p = spec.url.path().to_string();
        if p.is_empty() {
            p.push('/');
        }
        if let Some(q) = spec.url.query() {
            p.push('?');
            p.push_str(q);
        }
        p
    };
    let mut req = format!("{} {} HTTP/1.1\r\nHost: {}", spec.method, path, host);
    if let Some(port) = spec.url.port() {
        req.push_str(&format!(":{port}"));
    }
    req.push_str("\r\nUser-Agent: bat/0.1.0\r\nConnection: close\r\n");
    if let Some(ct) = &spec.content_type {
        req.push_str(&format!("Content-Type: {ct}\r\n"));
    }
    if !spec.body.is_empty() {
        req.push_str(&format!("Content-Length: {}\r\n", spec.body.len()));
    }
    for (k, v) in &spec.headers {
        req.push_str(&format!("{k}: {v}\r\n"));
    }
    req.push_str("\r\n");
    let mut wire = req.into_bytes();
    wire.extend_from_slice(&spec.body);
    let bytes = if spec.url.scheme() == "https" {
        send_https(host, port, &wire)?
    } else {
        let mut stream = TcpStream::connect((host, port)).map_err(|e| e.to_string())?;
        stream.write_all(&wire).map_err(|e| e.to_string())?;
        let mut bytes = Vec::new();
        stream.read_to_end(&mut bytes).map_err(|e| e.to_string())?;
        bytes
    };
    parse_response(&bytes)
}

fn send_https(host: &str, port: u16, request: &[u8]) -> Result<Vec<u8>, String> {
    let mut child = process::Command::new("openssl")
        .arg("s_client")
        .arg("-quiet")
        .arg("-connect")
        .arg(format!("{host}:{port}"))
        .arg("-servername")
        .arg(host)
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| e.to_string())?;
    {
        let stdin = child.stdin.as_mut().ok_or_else(|| "no stdin".to_string())?;
        stdin.write_all(request).map_err(|e| e.to_string())?;
    }
    drop(child.stdin.take());
    let out = child.wait_with_output().map_err(|e| e.to_string())?;
    Ok(out.stdout)
}

fn parse_response(bytes: &[u8]) -> Result<Response, String> {
    let split = bytes
        .windows(4)
        .position(|w| w == b"\r\n\r\n")
        .ok_or_else(|| "malformed response".to_string())?;
    let head = String::from_utf8_lossy(&bytes[..split]);
    let mut lines = head.lines();
    let status_line = lines.next().unwrap_or("");
    let mut parts = status_line.splitn(3, ' ');
    let _http = parts.next();
    let status = parts.next().unwrap_or("0").parse().unwrap_or(0);
    let reason = parts.next().unwrap_or("").to_string();
    let mut headers = Vec::new();
    let mut chunked = false;
    for line in lines {
        if let Some((k, v)) = line.split_once(':') {
            if k.eq_ignore_ascii_case("Transfer-Encoding") && v.to_ascii_lowercase().contains("chunked") {
                chunked = true;
            }
            headers.push((k.to_string(), v.trim().to_string()));
        }
    }
    let mut body = bytes[split + 4..].to_vec();
    if chunked {
        body = decode_chunked(&body);
    }
    Ok(Response {
        status,
        reason,
        headers,
        body,
    })
}

fn decode_chunked(bytes: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < bytes.len() {
        let Some(end) = bytes[i..].windows(2).position(|w| w == b"\r\n") else { break };
        let size_s = String::from_utf8_lossy(&bytes[i..i + end]);
        let size = usize::from_str_radix(size_s.trim(), 16).unwrap_or(0);
        i += end + 2;
        if size == 0 || i + size > bytes.len() {
            break;
        }
        out.extend_from_slice(&bytes[i..i + size]);
        i += size + 2;
    }
    out
}

fn print_response(resp: &Response, pretty: bool) {
    let _ = (resp.status, &resp.reason, &resp.headers);
    print!("\n");
    if pretty {
        if let Ok(v) = serde_json::from_slice::<Value>(&resp.body) {
            print!("{}", serde_json::to_string_pretty(&v).unwrap());
            return;
        }
    }
    print!("{}", String::from_utf8_lossy(&resp.body));
}

fn bench(spec: &RequestSpec, n: usize) {
    let start = Instant::now();
    let mut errors: BTreeMap<String, usize> = BTreeMap::new();
    let mut ok = 0usize;
    for _ in 0..n {
        match send(spec) {
            Ok(_) => ok += 1,
            Err(e) => {
                let msg = format!("{} \"{}\": {e}", title_case(&spec.method), spec.display_url);
                *errors.entry(msg).or_default() += 1;
            }
        }
    }
    if !errors.is_empty() {
        println!("\nError distribution:");
        for (e, c) in errors {
            println!("  [{c}]\t{e}");
        }
    } else {
        println!("Finished {ok} requests in {:?}", start.elapsed());
    }
}

fn title_case(s: &str) -> String {
    let mut chars = s.chars();
    match chars.next() {
        Some(c) => c.to_uppercase().collect::<String>() + &chars.as_str().to_ascii_lowercase(),
        None => String::new(),
    }
}
