use regex::Regex;
use std::collections::{BTreeMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

#[derive(Clone)]
struct Diag {
    code: u8,
    title: &'static str,
    msg: String,
    line: usize,
    col: usize,
}

const LINTS: &[(u8, &str)] = &[
    (1, "bool_comparison"),
    (2, "empty_let_in"),
    (3, "manual_inherit"),
    (4, "manual_inherit_from"),
    (5, "legacy_let_syntax"),
    (6, "collapsible_let_in"),
    (7, "eta_reduction"),
    (8, "useless_parens"),
    (10, "empty_pattern"),
    (11, "redundant_pattern_bind"),
    (12, "unquoted_uri"),
    (14, "empty_inherit"),
    (17, "deprecated_to_path"),
    (18, "bool_simplification"),
    (19, "useless_has_attr"),
    (20, "repeated_keys"),
    (23, "empty_list_concat"),
];

fn main() {
    let args: Vec<String> = env::args().collect();
    let code = run(&args);
    std::process::exit(code);
}

fn run(args: &[String]) -> i32 {
    if args.len() == 1 {
        print_top_help();
        return 0;
    }
    match args[1].as_str() {
        "-h" | "--help" | "help" => print_top_help(),
        "-V" | "--version" => println!("statix 0.5.8"),
        "list" => list_lints(),
        "dump" => println!("disabled = []\nignore = ['.direnv']\n"),
        "explain" => {
            if args.len() < 3 {
                eprintln!("error: The following required arguments were not provided:\n    <TARGET>");
                return 1;
            }
            return explain(&args[2]);
        }
        "check" => return check_cmd(&args[2..], false, false),
        "fix" => return check_cmd(&args[2..], true, false),
        "single" => return check_cmd(&args[2..], true, true),
        _ => {
            eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context", args[1]);
            return 1;
        }
    }
    0
}

fn print_top_help() {
    println!("statix 0.5.8\n\nAkshay <nerdy@peppe.rs>\n\nLints and suggestions for the Nix programming language\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nOPTIONS:\n    -h, --help       Print help information\n    -V, --version    Print version information\n\nSUBCOMMANDS:\n    check      Lints and suggestions for the nix programming language\n    dump       Dump a sample config to stdout\n    explain    Print detailed explanation for a lint warning\n    fix        Find and fix issues raised by statix-check\n    help       Print this message or the help of the given subcommand(s)\n    list       List all available lints\n    single     Fix exactly one issue at provided position");
}

fn list_lints() {
    for (n, name) in LINTS {
        println!("W{:02} {}", n, name);
    }
}

fn explain(s: &str) -> i32 {
    let code = s.trim_start_matches('W').parse::<u8>().ok();
    let text = match code {
        Some(1) => "## What it does\nChecks for expressions of the form `x == true`, `x != true` and\nsuggests using the variable directly.\n\n## Why is this bad?\nUnnecessary code.\n\n## Example\nInstead of checking the value of `x`:\n\n```nix\nif x == true then 0 else 1\n```\n\nUse `x` directly:\n\n```nix\nif x then 0 else 1\n```",
        Some(2) => "## What it does\nChecks for `let-in` expressions which create no new bindings.\n\n## Why is this bad?\n`let-in` expressions that create no new bindings are useless.\nThese are probably remnants from debugging or editing expressions.\n\n## Example\n\n```nix\nlet in pkgs.statix\n```\n\nPreserve only the body of the `let-in` expression:\n\n```nix\npkgs.statix\n```",
        Some(3) => "## What it does\nChecks for bindings of the form `a = a`.\n\n## Why is this bad?\nIf the aim is to bring attributes from a larger scope into\nthe current scope, prefer an inherit statement.",
        Some(4) => "## What it does\nChecks for bindings of the form `a = someAttr.a`.\n\n## Why is this bad?\nIf the aim is to extract or bring attributes of an attrset into\nscope, prefer an inherit statement.",
        Some(5) => "## What it does\nChecks for legacy-let syntax that was never formalized.\n\n## Why is this bad?\nThis syntax construct is undocumented, refrain from using it.",
        Some(6) => "## What it does\nChecks for `let-in` expressions whose body is another `let-in`\nexpression.\n\n## Why is this bad?\nUnnecessary code, the `let-in` expressions can be merged.",
        Some(7) => "## What it does\nChecks for eta-reducible functions, i.e.: converts lambda\nexpressions into free standing functions where applicable.",
        Some(8) => "## What it does\nChecks for unnecessary parentheses.\n\n## Why is this bad?\nUnnecessarily parenthesized code is hard to read.",
        Some(10) => "## What it does\nChecks for an empty variadic pattern: `{...}`, in a function\nargument.",
        Some(11) => "## What it does\nChecks for binds of the form `inputs @ { ... }` in function\narguments.",
        Some(12) => "## What it does\nChecks for URI expressions that are not quoted.",
        Some(14) => "## What it does\nChecks for empty inherit statements.\n\n## Why is this bad?\nUseless code, probably the result of a refactor.",
        Some(17) => "## What it does\nChecks for usage of the `toPath` function.\n\n## Why is this bad?\n`toPath` is deprecated.",
        Some(18) => "## What it does\nChecks for boolean expressions that can be simplified.",
        Some(19) => "## What it does\nChecks for expressions that use the \"has attribute\" operator: `?`,\nwhere the `or` operator would suffice.",
        Some(20) => "## What it does\nChecks for keys in attribute sets with repetitive keys, and suggests using\nan attribute set instead.",
        Some(23) => "## What it does\nChecks for concatenations to empty lists\n\n## Why is this bad?\nConcatenation with the empty list is a no-op.",
        _ => {
            println!("syntax error");
            return 1;
        }
    };
    println!("{}", text);
    0
}

fn check_cmd(args: &[String], do_fix: bool, single: bool) -> i32 {
    let mut format = "stderr".to_string();
    let mut stdin = false;
    let mut dry = false;
    let mut target: Option<String> = None;
    let mut ignores: Vec<String> = vec![".direnv".to_string()];
    let mut pos: Option<usize> = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "--help" => { print_sub_help(if single {"single"} else if do_fix {"fix"} else {"check"}); return 0; }
            "-s" | "--stdin" => stdin = true,
            "-d" | "--dry-run" => dry = true,
            "-o" | "--format" => { i += 1; if i < args.len() { format = args[i].clone(); } },
            "-i" | "--ignore" => { i += 1; if i < args.len() { ignores.push(args[i].clone()); } },
            "-c" | "--config" => { i += 1; },
            "-p" | "--position" => { i += 1; if i < args.len() { pos = args[i].parse().ok(); } },
            "--" => {},
            s if s.starts_with('-') => {},
            s => target = Some(s.to_string()),
        }
        i += 1;
    }

    if stdin {
        let mut input = String::new();
        io::stdin().read_to_string(&mut input).unwrap();
        let (diags, fixed) = analyze("<stdin>", &input, disabled_from_config("."));
        if do_fix {
            print!("{}", fixed);
            return 0;
        }
        print_diags("<stdin>", &input, &diags, &format);
        return if diags.is_empty() { 0 } else { 1 };
    }

    let target = target.unwrap_or_else(|| ".".to_string());
    let disabled = disabled_from_config(".");
    let mut any = false;
    let files = collect_files(Path::new(&target), &ignores);
    for file in files {
        let content = match fs::read_to_string(&file) { Ok(c) => c, Err(_) => continue };
        let path = file.to_string_lossy().to_string();
        let (mut diags, fixed) = analyze(&path, &content, disabled.clone());
        if single {
            if let Some(p) = pos {
                diags.retain(|d| offset_for(&content, d.line, d.col) <= p && p <= offset_for(&content, d.line, d.col) + 40);
            }
        }
        if !diags.is_empty() { any = true; }
        if do_fix {
            if dry {
                if fixed != content {
                    print_diff(&path, &content, &fixed);
                }
            } else if fixed != content {
                let _ = fs::write(&file, fixed);
            }
        } else {
            print_diags(&path, &content, &diags, &format);
        }
    }
    if do_fix { 0 } else if any { 1 } else { 0 }
}

fn print_sub_help(name: &str) {
    match name {
        "check" => println!("executable-check \n\nLints and suggestions for the nix programming language\n\nUSAGE:\n    executable check [OPTIONS] [--] [TARGET]"),
        "fix" => println!("executable-fix \n\nFind and fix issues raised by statix-check\n\nUSAGE:\n    executable fix [OPTIONS] [--] [TARGET]"),
        "single" => println!("executable-single \n\nFix exactly one issue at provided position\n\nUSAGE:\n    executable single [OPTIONS] --position <POSITION> [TARGET]"),
        _ => {}
    }
}

fn disabled_from_config(base: &str) -> HashSet<u8> {
    let mut set = HashSet::new();
    let p = Path::new(base).join("statix.toml");
    if let Ok(s) = fs::read_to_string(p) {
        if let Some(idx) = s.find("disabled") {
            let tail = &s[idx..];
            for (n, name) in LINTS {
                if tail.contains(&format!("W{:02}", n)) || tail.contains(name) {
                    set.insert(*n);
                }
            }
        }
    }
    set
}

fn collect_files(path: &Path, ignores: &[String]) -> Vec<PathBuf> {
    if path.is_file() {
        return vec![path.to_path_buf()];
    }
    let mut out = Vec::new();
    collect_rec(path, ignores, &mut out);
    out.sort();
    out
}

fn collect_rec(path: &Path, ignores: &[String], out: &mut Vec<PathBuf>) {
    let ps = path.to_string_lossy();
    if ignores.iter().any(|ig| ps.contains(ig.trim_matches('*'))) {
        return;
    }
    let Ok(rd) = fs::read_dir(path) else { return; };
    for ent in rd.filter_map(Result::ok) {
        let p = ent.path();
        let ps = p.to_string_lossy();
        if ignores.iter().any(|ig| ps.contains(ig.trim_matches('*'))) {
            continue;
        }
        if p.is_dir() {
            collect_rec(&p, ignores, out);
        } else if p.is_file() && p.extension().map(|e| e == "nix").unwrap_or(false) {
            out.push(p);
        }
    }
}

fn add(diags: &mut Vec<Diag>, disabled: &HashSet<u8>, code: u8, title: &'static str, msg: String, line: usize, col: usize) {
    if disabled.contains(&code) { return; }
    diags.push(Diag { code, title, msg, line, col });
}

fn analyze(_path: &str, content: &str, disabled: HashSet<u8>) -> (Vec<Diag>, String) {
    let mut diags = Vec::new();
    let mut fixed = content.to_string();
    let rules: Vec<(u8, &'static str, &'static str, Regex)> = vec![
        (1, "Unnecessary comparison with boolean", "bool", Regex::new(r"\b([A-Za-z_][A-Za-z0-9_.'-]*)\s*(==|!=)\s*(true|false)\b").unwrap()),
        (2, "Useless let-in expression", "This let-in expression has no entries", Regex::new(r"\blet\s+in\s+").unwrap()),
        (4, "Assignment instead of inherit from", "This assignment is better written with `inherit`", Regex::new(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\.([A-Za-z_][\w'-]*)\s*;").unwrap()),
        (5, "Found usage of deprecated legacy let syntax", "Found legacy `let` syntax", Regex::new(r"\blet\s*\{").unwrap()),
        (6, "This let-in expression is collapsible", "This let-in expression can be collapsed", Regex::new(r"(?s)\bin\s*\n\s*let\b").unwrap()),
        (8, "Useless parentheses", "Useless parentheses around value in binding", Regex::new(r"=\s*\(([A-Za-z_][\w'.-]*)\)\s*;").unwrap()),
        (10, "Found empty pattern", "This pattern is empty, use `_` instead", Regex::new(r"\{\s*\.\.\.\s*\}\s*:").unwrap()),
        (11, "Found redundant pattern bind", "pattern", Regex::new(r"\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:").unwrap()),
        (12, "Found unquoted URI expression", "Consider quoting this URI expression", Regex::new(r#"=\s*([A-Za-z][A-Za-z0-9+.-]*:[^\s;"']+)\s*;"#).unwrap()),
        (14, "Found empty inherit statement", "Remove this empty `inherit` statement", Regex::new(r"\binherit\s*;").unwrap()),
        (17, "Found usage of deprecated builtin toPath", "`toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more", Regex::new(r"\btoPath\b").unwrap()),
        (18, "Boolean expression can be simplified", "Try `!=` instead of `!(... == ...)`", Regex::new(r"!\s*\(\s*([^()]+?)\s*==\s*([^()]+?)\s*\)").unwrap()),
        (23, "Unnecessary concatenation with empty list", "Concatenation with the empty list, `[]`, is a no-op", Regex::new(r"(\[\]\s*\+\+\s*\[\])|(\[\]\s*\+\+\s*([A-Za-z_][\w'.-]*))|(([A-Za-z_][\w'.-]*)\s*\+\+\s*\[\])").unwrap()),
    ];

    for line_match in content.lines().enumerate() {
        let (ln0, line) = line_match;
        for (code, title, msg0, re) in &rules {
            for caps in re.captures_iter(line) {
                let m = caps.get(0).unwrap();
                let msg = match *code {
                    1 => format!("Comparing `{}` with boolean literal `{}`", caps.get(1).unwrap().as_str(), caps.get(3).unwrap().as_str()),
                    7 => format!("Found eta-reduction: `{}`", caps.get(2).unwrap().as_str()),
                    11 => format!("This pattern bind is redundant, use `{}` instead", caps.get(1).unwrap().as_str()),
                    19 => format!("Consider using `{}.{} or ({})` instead of this `if` expression", caps.get(1).unwrap().as_str(), caps.get(2).unwrap().as_str(), caps.get(3).unwrap().as_str().trim()),
                    _ => msg0.to_string(),
                };
                if *code == 10 && line[..m.start()].trim_end().ends_with('@') {
                    continue;
                }
                let col = match *code {
                    4 => caps.get(2).unwrap().start() + 1,
                    8 => m.start() + line[m.start()..].find('(').unwrap_or(0) + 1,
                    12 => caps.get(1).unwrap().start() + 1,
                    _ => m.start() + 1,
                };
                add(&mut diags, &disabled, *code, title, msg, ln0 + 1, col);
            }
        }
        let inherit_re = Regex::new(r"^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'-]*)\s*;").unwrap();
        if let Some(caps) = inherit_re.captures(line) {
            if caps.get(2).unwrap().as_str() == caps.get(3).unwrap().as_str() {
                let col = caps.get(2).unwrap().start() + 1;
                add(&mut diags, &disabled, 3, "Assignment instead of inherit", "This assignment is better written with `inherit`".to_string(), ln0 + 1, col);
            }
        }
        let eta_re = Regex::new(r"\b([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+([A-Za-z_][\w'-]*)\b").unwrap();
        for caps in eta_re.captures_iter(line) {
            if caps.get(1).unwrap().as_str() == caps.get(3).unwrap().as_str() {
                add(&mut diags, &disabled, 7, "This expression is eta-reducible", format!("Found eta-reduction: `{}`", caps.get(2).unwrap().as_str()), ln0 + 1, caps.get(0).unwrap().start() + 1);
            }
        }
        let has_re = Regex::new(r"if\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+([A-Za-z_][\w'.-]*)\.([A-Za-z_][\w'-]*)\s+else\s+([^;\n]+)").unwrap();
        for caps in has_re.captures_iter(line) {
            if caps.get(1).unwrap().as_str() == caps.get(3).unwrap().as_str() && caps.get(2).unwrap().as_str() == caps.get(4).unwrap().as_str() {
                let msg = format!("Consider using `{}.{} or ({})` instead of this `if` expression", caps.get(1).unwrap().as_str(), caps.get(2).unwrap().as_str(), caps.get(5).unwrap().as_str().trim());
                add(&mut diags, &disabled, 19, "Found usage of `?` operator in if", msg, ln0 + 1, caps.get(0).unwrap().start() + 1);
            }
        }
    }
    detect_repeated_keys(content, &disabled, &mut diags);
    diags.sort_by_key(|d| (d.line, d.col, d.code));

    fixed = apply_fixes(&fixed);
    (diags, fixed)
}

fn detect_repeated_keys(content: &str, disabled: &HashSet<u8>, diags: &mut Vec<Diag>) {
    if disabled.contains(&20) { return; }
    let re = Regex::new(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\.([A-Za-z_][\w'-]*)\s*=").unwrap();
    let mut map: BTreeMap<String, Vec<(usize, usize, String)>> = BTreeMap::new();
    for caps in re.captures_iter(content) {
        let key_match = caps.get(2).unwrap();
        let (line, col) = line_col(content, key_match.start());
        map.entry(caps[2].to_string()).or_default().push((line, col, caps[3].to_string()));
    }
    for (key, vals) in map {
        if vals.len() > 2 {
            for (i, (line, col, _)) in vals.iter().enumerate() {
                let msg = if i == 0 {
                    format!("The key `{}` is first assigned here ...", key)
                } else if i + 1 == vals.len() {
                    format!("... and here. Try `{} = {{ {} }}` instead.", key, vals.iter().map(|v| format!("{}=...;", v.2)).collect::<Vec<_>>().join(" "))
                } else {
                    "... repeated here ...".to_string()
                };
                add(diags, disabled, 20, "Found repeated keys in attrset", msg, *line, *col);
            }
        }
    }
}

fn apply_fixes(s: &str) -> String {
    let mut out = s.to_string();
    let replacements: Vec<(Regex, &str)> = vec![
        (Regex::new(r"\b([A-Za-z_][A-Za-z0-9_.'-]*)\s*==\s*true\b").unwrap(), "$1"),
        (Regex::new(r"\b([A-Za-z_][A-Za-z0-9_.'-]*)\s*!=\s*false\b").unwrap(), "$1"),
        (Regex::new(r"\b([A-Za-z_][A-Za-z0-9_.'-]*)\s*==\s*false\b").unwrap(), "!$1"),
        (Regex::new(r"\b([A-Za-z_][A-Za-z0-9_.'-]*)\s*!=\s*true\b").unwrap(), "!$1"),
        (Regex::new(r"\blet\s+in\s+").unwrap(), ""),
        (Regex::new(r"(?m)^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'.-]*)\.([A-Za-z_][\w'-]*)\s*;").unwrap(), "${1}inherit (${3}) ${2};"),
        (Regex::new(r"=\s*\(([A-Za-z_][\w'.-]*)\)\s*;").unwrap(), "= $1;"),
        (Regex::new(r"\b([A-Za-z_][\w'-]*)\s*@\s*\{\s*\.\.\.\s*\}\s*:").unwrap(), "$1:"),
        (Regex::new(r"\{\s*\.\.\.\s*\}\s*:").unwrap(), "_:"),
        (Regex::new(r#"=\s*([A-Za-z][A-Za-z0-9+.-]*:[^\s;"']+)\s*;"#).unwrap(), "= \"$1\";"),
        (Regex::new(r"\s*\binherit\s*;").unwrap(), ""),
        (Regex::new(r"!\s*\(\s*([^()]+?)\s*==\s*([^()]+?)\s*\)").unwrap(), "$1 != $2"),
        (Regex::new(r"\[\]\s*\+\+\s*([A-Za-z_][\w'.-]*)").unwrap(), "$1"),
        (Regex::new(r"([A-Za-z_][\w'.-]*)\s*\+\+\s*\[\]").unwrap(), "$1"),
        (Regex::new(r"\[\]\s*\+\+\s*\[\]").unwrap(), "[]"),
    ];
    for (re, rep) in replacements {
        out = re.replace_all(&out, rep).to_string();
    }
    out = fix_eta(&out);
    out = fix_has_attr(&out);
    out = fix_manual_inherit(&out);
    out
}

fn fix_eta(s: &str) -> String {
    let re = Regex::new(r"\b([A-Za-z_][\w'-]*)\s*:\s*([A-Za-z_][\w'.-]*)\s+([A-Za-z_][\w'-]*)\b").unwrap();
    re.replace_all(s, |caps: &regex::Captures| {
        if caps.get(1).unwrap().as_str() == caps.get(3).unwrap().as_str() {
            caps.get(2).unwrap().as_str().to_string()
        } else {
            caps.get(0).unwrap().as_str().to_string()
        }
    }).to_string()
}

fn fix_has_attr(s: &str) -> String {
    let re = Regex::new(r"if\s+([A-Za-z_][\w'.-]*)\s*\?\s*([A-Za-z_][\w'-]*)\s+then\s+([A-Za-z_][\w'.-]*)\.([A-Za-z_][\w'-]*)\s+else\s+([^;\n]+)").unwrap();
    re.replace_all(s, |caps: &regex::Captures| {
        if caps.get(1).unwrap().as_str() == caps.get(3).unwrap().as_str() && caps.get(2).unwrap().as_str() == caps.get(4).unwrap().as_str() {
            format!("{}.{} or ({})", caps.get(1).unwrap().as_str(), caps.get(2).unwrap().as_str(), caps.get(5).unwrap().as_str())
        } else {
            caps.get(0).unwrap().as_str().to_string()
        }
    }).to_string()
}

fn fix_manual_inherit(s: &str) -> String {
    let re = Regex::new(r"^(\s*)([A-Za-z_][\w'-]*)\s*=\s*([A-Za-z_][\w'-]*)\s*;$").unwrap();
    let mut out = String::new();
    for (idx, line) in s.lines().enumerate() {
        if idx > 0 {
            out.push('\n');
        }
        if let Some(caps) = re.captures(line) {
            if caps.get(2).unwrap().as_str() == caps.get(3).unwrap().as_str() {
                out.push_str(&format!("{}inherit {};", caps.get(1).unwrap().as_str(), caps.get(2).unwrap().as_str()));
                continue;
            }
        }
        out.push_str(line);
    }
    if s.ends_with('\n') {
        out.push('\n');
    }
    out
}

fn print_diags(path: &str, content: &str, diags: &[Diag], format: &str) {
    if format == "errfmt" {
        for d in diags {
            println!("{}>{}:{}:W:{}:{}", path, d.line, d.col, d.code, d.msg);
        }
    } else {
        for d in diags {
            let line = content.lines().nth(d.line - 1).unwrap_or("");
            println!("[W{:02}] Warning: {}", d.code, d.title);
            println!("   ╭─[{}:{}:{}]", path, d.line, d.col);
            println!("   │");
            println!("{:>2} │ {}", d.line, line);
            println!("   · {}^ {}", " ".repeat(d.col.saturating_sub(1)), d.msg);
            println!("───╯");
        }
    }
}

fn print_diff(path: &str, old: &str, new: &str) {
    println!("--- {}", path);
    println!("+++ {} [fixed]", path);
    println!("@@ -1,{} +1,{} @@", old.lines().count(), new.lines().count());
    let old_lines: Vec<_> = old.lines().collect();
    let new_lines: Vec<_> = new.lines().collect();
    let max = old_lines.len().max(new_lines.len());
    for i in 0..max {
        match (old_lines.get(i), new_lines.get(i)) {
            (Some(a), Some(b)) if a == b => println!(" {}", a),
            (Some(a), Some(b)) => { println!("-{}", a); println!("+{}", b); }
            (Some(a), None) => println!("-{}", a),
            (None, Some(b)) => println!("+{}", b),
            _ => {}
        }
    }
}

fn line_col(s: &str, byte: usize) -> (usize, usize) {
    let mut line = 1;
    let mut start = 0;
    for (i, ch) in s.char_indices() {
        if i >= byte { break; }
        if ch == '\n' { line += 1; start = i + 1; }
    }
    (line, byte - start + 1)
}

fn offset_for(s: &str, line: usize, col: usize) -> usize {
    let mut off = 0;
    for (i, l) in s.lines().enumerate() {
        if i + 1 == line { return off + col.saturating_sub(1); }
        off += l.len() + 1;
    }
    off
}
