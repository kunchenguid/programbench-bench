use serde::Deserialize;
use std::{env, fs};

type Result<T> = std::result::Result<T, String>;

#[derive(Clone, Debug, PartialEq)]
enum Kind {
    Uint(usize),
    Int(usize),
    Bool,
    Address,
    FixedBytes(usize),
    Bytes,
    String,
    Array(Box<Kind>, Option<usize>),
}

#[derive(Clone, Debug)]
enum Token {
    Word([u8; 32]),
    Bytes(Vec<u8>),
    String(String),
    Array(Vec<Token>),
}

#[derive(Deserialize)]
struct AbiItem {
    #[serde(default)]
    r#type: String,
    #[serde(default)]
    name: String,
    #[serde(default)]
    inputs: Vec<AbiParam>,
    #[serde(default)]
    outputs: Vec<AbiParam>,
    #[serde(default)]
    anonymous: bool,
}

#[derive(Deserialize, Clone)]
struct AbiParam {
    #[serde(default)]
    name: String,
    #[serde(rename = "type")]
    typ: String,
    #[serde(default)]
    indexed: bool,
}

fn main() {
    if let Err(e) = run() {
        eprintln!("Error: {e}");
        std::process::exit(1);
    }
}

fn run() -> Result<()> {
    let args: Vec<String> = env::args().collect();
    if args.len() == 1 || has(&args, "-h") || has(&args, "--help") {
        print_help(&args);
        return Ok(());
    }
    if has(&args, "-V") || has(&args, "--version") {
        println!("ethabi-cli 18.0.0");
        return Ok(());
    }
    match args.get(1).map(String::as_str) {
        Some("encode") => encode_cmd(&args[2..]),
        Some("decode") => decode_cmd(&args[2..]),
        Some("help") => {
            print_help(&args);
            Ok(())
        }
        _ => Err("unrecognized subcommand".into()),
    }
}

fn has(args: &[String], s: &str) -> bool {
    args.iter().any(|a| a == s)
}

fn print_help(args: &[String]) {
    let sub = args.iter().skip(1).filter(|a| !a.starts_with('-')).cloned().collect::<Vec<_>>().join(" ");
    match sub.as_str() {
        "encode" => println!("executable-encode 18.0.0\nEncode ABI call\n\nUSAGE:\n    executable encode <SUBCOMMAND>\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    params      Specify types of input params inline"),
        "decode" => println!("executable-decode 18.0.0\nDecode ABI call result\n\nUSAGE:\n    executable decode <SUBCOMMAND>\n\nSUBCOMMANDS:\n    function    Load function from JSON ABI file\n    log         Decode event log\n    params      Specify types of input params inline"),
        _ if sub.contains("encode function") => println!("executable-encode-function 18.0.0\nLoad function from JSON ABI file\n\nUSAGE:\n    executable encode function [FLAGS] [OPTIONS] <abi-path> <function-name-or-signature>"),
        _ if sub.contains("encode params") => println!("executable-encode-params 18.0.0\nSpecify types of input params inline\n\nUSAGE:\n    executable encode params [FLAGS] [OPTIONS]"),
        _ if sub.contains("decode function") => println!("executable-decode-function 18.0.0\nLoad function from JSON ABI file\n\nUSAGE:\n    executable decode function <abi-path> <function-name-or-signature> <data>"),
        _ if sub.contains("decode params") => println!("executable-decode-params 18.0.0\nSpecify types of input params inline\n\nUSAGE:\n    executable decode params [OPTIONS] <data>"),
        _ if sub.contains("decode log") => println!("executable-decode-log 18.0.0\nDecode event log\n\nUSAGE:\n    executable decode log [OPTIONS] <abi-path> <event-name-or-signature> <data>"),
        _ => println!("ethabi-cli 18.0.0\nEthereum ABI coder\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nSUBCOMMANDS:\n    decode    Decode ABI call result\n    encode    Encode ABI call\n    help      Prints this message or the help of the given subcommand(s)"),
    }
}

fn encode_cmd(args: &[String]) -> Result<()> {
    match args.get(0).map(String::as_str) {
        Some("params") => {
            let (lenient, pairs) = parse_values(&args[1..])?;
            let mut kinds = Vec::new();
            let mut toks = Vec::new();
            for (t, v) in pairs {
                let k = parse_type(&t)?;
                toks.push(parse_token(&k, &v, lenient)?);
                kinds.push(k);
            }
            println!("{}", hex(&encode_tuple(&kinds, &toks)));
            Ok(())
        }
        Some("function") => {
            let lenient = has(args, "-l") || has(args, "--lenient");
            let pos: Vec<String> = args[1..].iter().filter(|a| *a != "-l" && *a != "--lenient" && *a != "-p").cloned().collect();
            if pos.len() < 2 { return Err("missing required arguments".into()); }
            let abi = load_abi(&pos[0])?;
            let f = find_item(&abi, "function", &pos[1])?;
            let kinds = f.inputs.iter().map(|p| parse_type(&p.typ)).collect::<Result<Vec<_>>>()?;
            let params = collect_flag_values(args, "-p");
            if params.len() != kinds.len() { return Err("Invalid data".into()); }
            let toks = kinds.iter().zip(params.iter()).map(|(k, v)| parse_token(k, v, lenient)).collect::<Result<Vec<_>>>()?;
            let mut out = keccak256(signature(f).as_bytes())[..4].to_vec();
            out.extend(encode_tuple(&kinds, &toks));
            println!("{}", hex(&out));
            Ok(())
        }
        _ => Err("unrecognized subcommand".into()),
    }
}

fn decode_cmd(args: &[String]) -> Result<()> {
    match args.get(0).map(String::as_str) {
        Some("params") => {
            let types = collect_flag_values(args, "-t");
            let data = args.last().ok_or("missing data")?;
            let kinds = types.iter().map(|t| parse_type(t)).collect::<Result<Vec<_>>>()?;
            let bytes = parse_hex(data)?;
            let toks = decode_tuple(&kinds, &bytes, 0)?;
            for (k, t) in kinds.iter().zip(toks.iter()) {
                println!("{} {}", type_name(k), format_token(k, t));
            }
            Ok(())
        }
        Some("function") => {
            if args.len() < 4 { return Err("missing required arguments".into()); }
            let abi = load_abi(&args[1])?;
            let f = find_item(&abi, "function", &args[2])?;
            let kinds = f.outputs.iter().map(|p| parse_type(&p.typ)).collect::<Result<Vec<_>>>()?;
            let bytes = parse_hex(&args[3])?;
            let toks = decode_tuple(&kinds, &bytes, 0)?;
            for (k, t) in kinds.iter().zip(toks.iter()) {
                println!("{} {}", type_name(k), format_token(k, t));
            }
            Ok(())
        }
        Some("log") => {
            if args.len() < 4 { return Err("missing required arguments".into()); }
            let abi = load_abi(&args[1])?;
            let ev = find_item(&abi, "event", &args[2])?;
            let topics = collect_flag_values(args, "-l").into_iter().map(|x| parse_hex(&x)).collect::<Result<Vec<_>>>()?;
            let data = parse_hex(args.last().unwrap())?;
            let mut topic_i = if ev.anonymous { 0 } else { 1 };
            let data_params: Vec<_> = ev.inputs.iter().filter(|p| !p.indexed).cloned().collect();
            let data_kinds = data_params.iter().map(|p| parse_type(&p.typ)).collect::<Result<Vec<_>>>()?;
            let data_toks = decode_tuple(&data_kinds, &data, 0)?;
            let mut data_i = 0;
            for p in &ev.inputs {
                let k = parse_type(&p.typ)?;
                let tok = if p.indexed {
                    if topic_i >= topics.len() || topics[topic_i].len() != 32 { return Err("Invalid data".into()); }
                    let mut w = [0u8; 32]; w.copy_from_slice(&topics[topic_i]); topic_i += 1;
                    Token::Word(w)
                } else {
                    let t = data_toks[data_i].clone(); data_i += 1; t
                };
                println!("{} {}", p.name, format_token(&k, &tok));
            }
            Ok(())
        }
        _ => Err("unrecognized subcommand".into()),
    }
}

fn parse_values(args: &[String]) -> Result<(bool, Vec<(String, String)>)> {
    let mut lenient = false;
    let mut pairs = Vec::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-l" | "--lenient" => { lenient = true; i += 1; }
            "-v" => {
                if i + 2 >= args.len() { return Err("Invalid data".into()); }
                pairs.push((args[i + 1].clone(), args[i + 2].clone()));
                i += 3;
            }
            _ => i += 1,
        }
    }
    Ok((lenient, pairs))
}

fn collect_flag_values(args: &[String], flag: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut i = 0;
    while i + 1 < args.len() {
        if args[i] == flag {
            out.push(args[i + 1].clone());
            i += 2;
        } else {
            i += 1;
        }
    }
    out
}

fn load_abi(path: &str) -> Result<Vec<AbiItem>> {
    let s = fs::read_to_string(path).map_err(|e| e.to_string())?;
    serde_json::from_str(&s).map_err(|e| e.to_string())
}

fn find_item<'a>(abi: &'a [AbiItem], typ: &str, name: &str) -> Result<&'a AbiItem> {
    if name.contains('(') {
        let fname = name.split('(').next().unwrap_or("");
        let first = abi.iter().find(|i| i.r#type == typ && i.name == fname)
            .ok_or_else(|| format!("Invalid name: {fname}"))?;
        if invalid_signature_syntax(name) || signature(first) != name {
            return Err(format!("invalid {typ} signature `{name}`"));
        }
        return Ok(first);
    }
    let matches: Vec<_> = abi.iter().filter(|i| i.r#type == typ && (i.name == name || signature(i) == name)).collect();
    if matches.is_empty() {
        if name.contains('(') { Err(format!("invalid {typ} signature `{name}`")) } else { Err(format!("Invalid name: {name}")) }
    } else if matches.len() > 1 && !name.contains('(') {
        Err(format!("More than one {typ} found for name `{name}`, try providing the full signature"))
    } else {
        Ok(matches[0])
    }
}

fn invalid_signature_syntax(name: &str) -> bool {
    let Some(open) = name.find('(') else { return false };
    let Some(close) = name.rfind(')') else { return true };
    if close != name.len() - 1 { return true; }
    for t in name[open + 1..close].split(',').filter(|s| !s.is_empty()) {
        let base = t.split('[').next().unwrap_or(t);
        if base.starts_with("uint") || base.starts_with("int") {
            return true;
        }
        if let Some(rest) = base.strip_prefix("bytes") {
            if !rest.is_empty() {
                return true;
            }
        }
    }
    false
}

fn signature(item: &AbiItem) -> String {
    format!("{}({})", item.name, item.inputs.iter().map(|p| p.typ.as_str()).collect::<Vec<_>>().join(","))
}

fn parse_type(s: &str) -> Result<Kind> {
    if let Some(pos) = s.rfind('[') {
        if s.ends_with(']') {
            let inner = parse_type(&s[..pos])?;
            let n = &s[pos + 1..s.len() - 1];
            return Ok(Kind::Array(Box::new(inner), if n.is_empty() { None } else { Some(n.parse().map_err(|_| "Invalid type")?) }));
        }
    }
    if s == "bool" { Ok(Kind::Bool) }
    else if s == "address" { Ok(Kind::Address) }
    else if s == "bytes" { Ok(Kind::Bytes) }
    else if s == "string" { Ok(Kind::String) }
    else if let Some(n) = s.strip_prefix("uint") { Ok(Kind::Uint(if n.is_empty() { 256 } else { n.parse().map_err(|_| "Invalid type")? })) }
    else if let Some(n) = s.strip_prefix("int") { Ok(Kind::Int(if n.is_empty() { 256 } else { n.parse().map_err(|_| "Invalid type")? })) }
    else if let Some(n) = s.strip_prefix("bytes") { Ok(Kind::FixedBytes(n.parse().map_err(|_| "Invalid type")?)) }
    else { Err("Invalid type".into()) }
}

fn type_name(k: &Kind) -> String {
    match k {
        Kind::Uint(n) => format!("uint{n}"),
        Kind::Int(n) => format!("int{n}"),
        Kind::Bool => "bool".into(),
        Kind::Address => "address".into(),
        Kind::FixedBytes(n) => format!("bytes{n}"),
        Kind::Bytes => "bytes".into(),
        Kind::String => "string".into(),
        Kind::Array(inner, None) => format!("{}[]", type_name(inner)),
        Kind::Array(inner, Some(n)) => format!("{}[{n}]", type_name(inner)),
    }
}

fn parse_token(k: &Kind, v: &str, lenient: bool) -> Result<Token> {
    match k {
        Kind::Bool => {
            let b = matches!(v, "1" | "true" | "True" | "TRUE");
            if !b && !matches!(v, "0" | "false" | "False" | "FALSE") { return Err("Invalid data".into()); }
            let mut w = [0u8; 32]; if b { w[31] = 1; } Ok(Token::Word(w))
        }
        Kind::Address => {
            let b = parse_hex(v)?;
            if b.len() != 20 && b.len() != 32 { return Err("Invalid data".into()); }
            let mut w = [0u8; 32]; w[32 - b.len()..].copy_from_slice(&b); Ok(Token::Word(w))
        }
        Kind::Uint(_) | Kind::Int(_) => {
            let w = if lenient {
                decimal_word(v)?
            } else {
                let b = parse_hex(v)?;
                if b.len() != 32 { return Err("Invalid data".into()); }
                let mut w = [0u8; 32];
                w.copy_from_slice(&b);
                w
            };
            Ok(Token::Word(w))
        }
        Kind::FixedBytes(n) => {
            let b = parse_hex(v)?;
            if b.len() != *n { return Err("Invalid data".into()); }
            let mut w = [0u8; 32]; w[..*n].copy_from_slice(&b); Ok(Token::Word(w))
        }
        Kind::Bytes => Ok(Token::Bytes(parse_hex(v)?)),
        Kind::String => Ok(Token::String(v.to_string())),
        Kind::Array(inner, fixed) => {
            let vals = parse_array_values(v)?;
            if let Some(n) = fixed { if vals.len() != *n { return Err("Invalid data".into()); } }
            Ok(Token::Array(vals.iter().map(|x| parse_token(inner, x, lenient)).collect::<Result<Vec<_>>>()?))
        }
    }
}

fn parse_array_values(s: &str) -> Result<Vec<String>> {
    let s = s.trim();
    if !s.starts_with('[') || !s.ends_with(']') { return Err("Invalid data".into()); }
    let inner = &s[1..s.len()-1];
    if inner.trim().is_empty() { return Ok(Vec::new()); }
    Ok(inner.split(',').map(|x| x.trim().to_string()).collect())
}

fn is_dynamic(k: &Kind) -> bool {
    match k {
        Kind::Bytes | Kind::String => true,
        Kind::Array(_inner, None) => true,
        Kind::Array(inner, Some(_)) => is_dynamic(inner),
        _ => false,
    }
}

fn encode_tuple(kinds: &[Kind], toks: &[Token]) -> Vec<u8> {
    let mut head = Vec::new();
    let mut tail = Vec::new();
    let head_len: usize = kinds.iter().map(slot_count).sum::<usize>() * 32;
    for (k, t) in kinds.iter().zip(toks.iter()) {
        if is_dynamic(k) {
            head.extend(word_usize(head_len + tail.len()));
            tail.extend(encode_single(k, t));
        } else {
            head.extend(encode_single(k, t));
        }
    }
    head.extend(tail);
    head
}

fn slot_count(k: &Kind) -> usize {
    match k {
        Kind::Array(inner, Some(n)) if !is_dynamic(inner) => n * slot_count(inner),
        _ => 1,
    }
}

fn encode_single(k: &Kind, t: &Token) -> Vec<u8> {
    match (k, t) {
        (Kind::Bytes, Token::Bytes(b)) => encode_len_bytes(b),
        (Kind::String, Token::String(s)) => encode_len_bytes(s.as_bytes()),
        (Kind::Array(inner, None), Token::Array(vals)) => {
            let kinds = vec![(**inner).clone(); vals.len()];
            let mut out = word_usize(vals.len());
            out.extend(encode_tuple(&kinds, vals));
            out
        }
        (Kind::Array(inner, Some(_)), Token::Array(vals)) => {
            let kinds = vec![(**inner).clone(); vals.len()];
            encode_tuple(&kinds, vals)
        }
        (_, Token::Word(w)) => w.to_vec(),
        _ => Vec::new(),
    }
}

fn encode_len_bytes(b: &[u8]) -> Vec<u8> {
    let mut out = word_usize(b.len());
    out.extend(b);
    while out.len() % 32 != 0 { out.push(0); }
    out
}

fn word_usize(n: usize) -> Vec<u8> {
    let mut w = [0u8; 32];
    let mut x = n;
    for i in (0..32).rev() { w[i] = (x & 0xff) as u8; x >>= 8; }
    w.to_vec()
}

fn decode_tuple(kinds: &[Kind], data: &[u8], base: usize) -> Result<Vec<Token>> {
    let mut out = Vec::new();
    let mut pos = base;
    for k in kinds {
        if is_dynamic(k) {
            let off = read_usize(word(data, pos)?)?;
            out.push(decode_single(k, data, base + off)?);
            pos += 32;
        } else {
            out.push(decode_single(k, data, pos)?);
            pos += slot_count(k) * 32;
        }
    }
    Ok(out)
}

fn decode_single(k: &Kind, data: &[u8], pos: usize) -> Result<Token> {
    match k {
        Kind::Bytes => {
            let len = read_usize(word(data, pos)?)?;
            Ok(Token::Bytes(data.get(pos+32..pos+32+len).ok_or("Invalid data")?.to_vec()))
        }
        Kind::String => {
            let len = read_usize(word(data, pos)?)?;
            let b = data.get(pos+32..pos+32+len).ok_or("Invalid data")?;
            Ok(Token::String(String::from_utf8_lossy(b).to_string()))
        }
        Kind::Array(inner, None) => {
            let len = read_usize(word(data, pos)?)?;
            let kinds = vec![(**inner).clone(); len];
            Ok(Token::Array(decode_tuple(&kinds, data, pos + 32)?))
        }
        Kind::Array(inner, Some(n)) => {
            let kinds = vec![(**inner).clone(); *n];
            Ok(Token::Array(decode_tuple(&kinds, data, pos)?))
        }
        _ => {
            let mut w = [0u8; 32]; w.copy_from_slice(word(data, pos)?); Ok(Token::Word(w))
        }
    }
}

fn word(data: &[u8], pos: usize) -> Result<&[u8]> {
    data.get(pos..pos+32).ok_or_else(|| "Invalid data".into())
}

fn read_usize(w: &[u8]) -> Result<usize> {
    let mut n = 0usize;
    for &b in w {
        n = n.checked_mul(256).and_then(|x| x.checked_add(b as usize)).ok_or("Invalid data")?;
    }
    Ok(n)
}

fn format_token(k: &Kind, t: &Token) -> String {
    match (k, t) {
        (Kind::Bool, Token::Word(w)) => if w[..31].iter().all(|&b| b == 0) && w[31] == 1 { "true".into() } else { "false".into() },
        (Kind::Address, Token::Word(w)) => hex(&w[12..]),
        (Kind::Uint(_), Token::Word(w)) => trim_hex(w),
        (Kind::Int(_), Token::Word(w)) => trim_hex(w),
        (Kind::FixedBytes(n), Token::Word(w)) => hex(&w[..*n]),
        (Kind::Bytes, Token::Bytes(b)) => hex(b),
        (Kind::String, Token::String(s)) => s.clone(),
        (Kind::Array(inner, _), Token::Array(vals)) => format!("[{}]", vals.iter().map(|v| format_token(inner, v)).collect::<Vec<_>>().join(",")),
        (_, Token::Word(w)) => hex(w),
        _ => String::new(),
    }
}

fn trim_hex(w: &[u8; 32]) -> String {
    let s = hex(w);
    let t = s.trim_start_matches('0');
    if t.is_empty() { "0".into() } else { t.into() }
}

fn parse_hex(s: &str) -> Result<Vec<u8>> {
    let s = s.strip_prefix("0x").unwrap_or(s);
    if s.len() % 2 == 1 { return Err("Hex parsing error: Odd number of digits\n\nCaused by:\n    Odd number of digits".into()); }
    let mut out = Vec::new();
    let bs = s.as_bytes();
    for i in (0..bs.len()).step_by(2) {
        let h = hex_val(bs[i]).ok_or_else(|| format!("Hex parsing error: Invalid character '{}' at position {i}\n\nCaused by:\n    Invalid character '{}' at position {i}", bs[i] as char, bs[i] as char))?;
        let l = hex_val(bs[i+1]).ok_or_else(|| format!("Hex parsing error: Invalid character '{}' at position {}\n\nCaused by:\n    Invalid character '{}' at position {}", bs[i+1] as char, i+1, bs[i+1] as char, i+1))?;
        out.push((h << 4) | l);
    }
    Ok(out)
}

fn hex_val(b: u8) -> Option<u8> {
    match b { b'0'..=b'9' => Some(b-b'0'), b'a'..=b'f' => Some(b-b'a'+10), b'A'..=b'F' => Some(b-b'A'+10), _ => None }
}

fn hex(b: &[u8]) -> String {
    const H: &[u8; 16] = b"0123456789abcdef";
    let mut s = String::with_capacity(b.len()*2);
    for &x in b { s.push(H[(x>>4) as usize] as char); s.push(H[(x&15) as usize] as char); }
    s
}

fn decimal_word(s: &str) -> Result<[u8; 32]> {
    let mut w = [0u8; 32];
    for c in s.bytes() {
        if !c.is_ascii_digit() { return Err("Invalid data".into()); }
        let mut carry = (c - b'0') as u16;
        for i in (0..32).rev() {
            let v = w[i] as u16 * 10 + carry;
            w[i] = (v & 0xff) as u8;
            carry = v >> 8;
        }
        if carry != 0 { return Err("Invalid data".into()); }
    }
    Ok(w)
}

fn keccak256(input: &[u8]) -> [u8; 32] {
    const ROUNDS: [u64; 24] = [
        0x0000000000000001,0x0000000000008082,0x800000000000808a,0x8000000080008000,
        0x000000000000808b,0x0000000080000001,0x8000000080008081,0x8000000000008009,
        0x000000000000008a,0x0000000000000088,0x0000000080008009,0x000000008000000a,
        0x000000008000808b,0x800000000000008b,0x8000000000008089,0x8000000000008003,
        0x8000000000008002,0x8000000000000080,0x000000000000800a,0x800000008000000a,
        0x8000000080008081,0x8000000000008080,0x0000000080000001,0x8000000080008008];
    const R: [u32; 25] = [0,1,62,28,27,36,44,6,55,20,3,10,43,25,39,41,45,15,21,8,18,2,61,56,14];
    let mut st = [0u64; 25];
    let rate = 136;
    let mut chunks = input.chunks_exact(rate);
    for chunk in &mut chunks {
        for i in 0..rate/8 { st[i] ^= u64::from_le_bytes(chunk[i*8..i*8+8].try_into().unwrap()); }
        keccak_f(&mut st, &ROUNDS, &R);
    }
    let rem = chunks.remainder();
    let mut block = [0u8; 136];
    block[..rem.len()].copy_from_slice(rem);
    block[rem.len()] = 0x01;
    block[rate-1] |= 0x80;
    for i in 0..rate/8 { st[i] ^= u64::from_le_bytes(block[i*8..i*8+8].try_into().unwrap()); }
    keccak_f(&mut st, &ROUNDS, &R);
    let mut out = [0u8; 32];
    for i in 0..4 { out[i*8..i*8+8].copy_from_slice(&st[i].to_le_bytes()); }
    out
}

fn keccak_f(a: &mut [u64; 25], rc: &[u64; 24], rot: &[u32; 25]) {
    for &round in rc {
        let mut c = [0u64; 5];
        for x in 0..5 { c[x] = a[x] ^ a[x+5] ^ a[x+10] ^ a[x+15] ^ a[x+20]; }
        for x in 0..5 {
            let d = c[(x+4)%5] ^ c[(x+1)%5].rotate_left(1);
            for y in 0..5 { a[x + 5*y] ^= d; }
        }
        let mut b = [0u64; 25];
        for x in 0..5 {
            for y in 0..5 {
                b[y + 5*((2*x + 3*y)%5)] = a[x + 5*y].rotate_left(rot[x + 5*y]);
            }
        }
        for x in 0..5 {
            for y in 0..5 {
                a[x + 5*y] = b[x + 5*y] ^ ((!b[(x+1)%5 + 5*y]) & b[(x+2)%5 + 5*y]);
            }
        }
        a[0] ^= round;
    }
}
