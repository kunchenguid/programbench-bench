use std::env;
use std::io::{self, Write};
use std::process;

const USAGE: &str = "Usage: jplot [OPTIONS] FIELD_SPEC [FIELD_SPEC...]:\n\nOPTIONS:\n  -interval duration\n    \tWhen url is provided, defines the interval between fetches. Note that counter fields are computed based on this interval. (default 1s)\n  -rows int\n    \tLimits the height of the graph output.\n  -steps int\n    \tNumber of values to plot. (default 100)\n  -url string\n    \tURL to fetch every second. Read JSON objects from stdin if not specified.\n\nFIELD_SPEC: [<option>[,<option>...]:]path\n  option:\n    - counter: Computes the difference with the last value. The value must increase monotonically.\n    - marker: When the value is none-zero, a vertical line is drawn.\n  path:\n    JSON field path (eg: field.sub-field).\n";

#[derive(Default)]
struct Config {
    _interval: Option<String>,
    _rows: Option<i64>,
    _steps: Option<i64>,
    _url: Option<String>,
    fields: Vec<String>,
}

fn usage() {
    eprint!("{}", USAGE);
}

fn stdout_probe() {
    print!("\x1b[c");
    let _ = io::stdout().flush();
}

fn parse_int(name: &str, value: &str) -> Result<i64, String> {
    value.parse::<i64>().map_err(|_| {
        format!(
            "invalid value \"{}\" for flag -{}: parse error",
            value, name
        )
    })
}

fn parse_duration(value: &str) -> Result<String, String> {
    if value.is_empty() {
        return Err(format!(
            "invalid value \"{}\" for flag -interval: parse error",
            value
        ));
    }
    let units = ["ns", "us", "µs", "μs", "ms", "s", "m", "h"];
    let mut rest = value;
    let mut saw = false;
    while !rest.is_empty() {
        let bytes = rest.as_bytes();
        let mut i = 0usize;
        if i < bytes.len() && (bytes[i] == b'+' || bytes[i] == b'-') {
            i += 1;
        }
        let start_digits = i;
        while i < bytes.len() && bytes[i].is_ascii_digit() {
            i += 1;
        }
        if i < bytes.len() && bytes[i] == b'.' {
            i += 1;
            while i < bytes.len() && bytes[i].is_ascii_digit() {
                i += 1;
            }
        }
        if i == start_digits
            || (i == start_digits + 1 && matches!(bytes.get(start_digits), Some(b'.')))
        {
            return Err(format!(
                "invalid value \"{}\" for flag -interval: parse error",
                value
            ));
        }
        let mut matched = None;
        for unit in units {
            if rest[i..].starts_with(unit) {
                matched = Some(i + unit.len());
                break;
            }
        }
        let Some(next) = matched else {
            return Err(format!(
                "invalid value \"{}\" for flag -interval: parse error",
                value
            ));
        };
        saw = true;
        rest = &rest[next..];
    }
    if saw {
        Ok(value.to_string())
    } else {
        Err(format!(
            "invalid value \"{}\" for flag -interval: parse error",
            value
        ))
    }
}

fn next_value(args: &[String], i: &mut usize, name: &str) -> Result<String, String> {
    if *i + 1 >= args.len() {
        return Err(format!("flag needs an argument: -{}", name));
    }
    *i += 1;
    Ok(args[*i].clone())
}

fn parse_args(args: &[String]) -> Result<Config, (String, i32)> {
    let mut cfg = Config::default();
    let mut i = 0usize;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--" {
            cfg.fields.extend(args[i + 1..].iter().cloned());
            break;
        }
        if !arg.starts_with('-') || arg == "-" {
            cfg.fields.extend(args[i..].iter().cloned());
            break;
        }

        let raw = if let Some(stripped) = arg.strip_prefix("--") {
            stripped
        } else {
            &arg[1..]
        };
        let (name, inline) = match raw.split_once('=') {
            Some((n, v)) => (n, Some(v.to_string())),
            None => (raw, None),
        };

        match name {
            "h" | "help" => return Err((String::new(), 0)),
            "interval" => {
                let value = match inline {
                    Some(v) => v,
                    None => next_value(args, &mut i, name).map_err(|e| (e, 2))?,
                };
                cfg._interval = Some(parse_duration(&value).map_err(|e| (e, 2))?);
            }
            "rows" => {
                let value = match inline {
                    Some(v) => v,
                    None => next_value(args, &mut i, name).map_err(|e| (e, 2))?,
                };
                cfg._rows = Some(parse_int(name, &value).map_err(|e| (e, 2))?);
            }
            "steps" => {
                let value = match inline {
                    Some(v) => v,
                    None => next_value(args, &mut i, name).map_err(|e| (e, 2))?,
                };
                cfg._steps = Some(parse_int(name, &value).map_err(|e| (e, 2))?);
            }
            "url" => {
                let value = match inline {
                    Some(v) => v,
                    None => next_value(args, &mut i, name).map_err(|e| (e, 2))?,
                };
                cfg._url = Some(value);
            }
            _ => return Err((format!("flag provided but not defined: -{}", name), 2)),
        }
        i += 1;
    }
    Ok(cfg)
}

fn main() {
    stdout_probe();
    let args: Vec<String> = env::args().skip(1).collect();
    match parse_args(&args) {
        Ok(_cfg) => {
            println!("jplot:  iTerm2, Kitty, or DRCS Sixel graphics required");
            process::exit(1);
        }
        Err((msg, code)) => {
            if !msg.is_empty() {
                eprintln!("{}", msg);
            }
            usage();
            process::exit(code);
        }
    }
}
