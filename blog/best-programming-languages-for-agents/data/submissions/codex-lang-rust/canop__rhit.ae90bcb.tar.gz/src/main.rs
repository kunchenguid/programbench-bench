use chrono::{Datelike, NaiveDate, NaiveDateTime, NaiveTime, Timelike};
use regex::Regex;
use std::collections::HashMap;
use std::env;
use std::fs::{self, File};
use std::io::{BufRead, BufReader};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

#[derive(Clone, Debug)]
struct Hit {
    raw: String,
    ip: String,
    dt: NaiveDateTime,
    method: String,
    path: String,
    status: String,
    bytes: u64,
    referer: String,
}

#[derive(Debug)]
struct Opts {
    files: Vec<String>,
    output: String,
    fields: String,
    key: String,
    length: usize,
    all_paths: bool,
    no_name_check: bool,
    changes: bool,
    date: Option<String>,
    time: Option<String>,
    ip: Option<String>,
    method: Option<String>,
    path: Option<String>,
    referer: Option<String>,
    status: Option<String>,
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err(code) => std::process::exit(code),
    };
    let hits = match load_hits(&opts) {
        Ok(h) => h,
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(1);
        }
    };
    let hits: Vec<Hit> = hits.into_iter().filter(|h| matches_filters(h, &opts)).collect();
    match opts.output.as_str() {
        "raw" | "r" => print_raw(&hits),
        "csv" | "c" => print_csv(&hits),
        "json" | "j" => print_json(&hits),
        _ => print_tables(&hits, &opts),
    }
}

fn parse_args() -> Result<Opts, i32> {
    let mut o = Opts {
        files: Vec::new(),
        output: "tables".into(),
        fields: "date,status,ref,path".into(),
        key: "hits".into(),
        length: 1,
        all_paths: false,
        no_name_check: false,
        changes: false,
        date: None,
        time: None,
        ip: None,
        method: None,
        path: None,
        referer: None,
        status: None,
    };
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_help();
        return Err(0);
    }
    if args.iter().any(|a| a == "--version" || a == "-V") {
        println!("rhit 2.0.4");
        return Err(0);
    }
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if !a.starts_with('-') || a == "-" {
            o.files.push(a);
            i += 1;
            continue;
        }
        macro_rules! val {
            () => {{
                i += 1;
                if i >= args.len() {
                    eprintln!("error: a value is required for '{a}'");
                    return Err(2);
                }
                args[i].clone()
            }};
        }
        match a.as_str() {
            "--color" => { let _ = val!(); }
            "-o" | "--output" => o.output = normalize_output(&val!()).unwrap_or_else(|| {
                eprintln!("error: invalid value for '--output'");
                std::process::exit(2);
            }),
            "-f" | "--fields" => o.fields = val!(),
            "-k" | "--key" => o.key = val!(),
            "-l" | "--length" => o.length = val!().parse().unwrap_or(1),
            "-d" | "--date" => o.date = Some(val!()),
            "-t" | "--time" => o.time = Some(val!()),
            "-i" | "--ip" => o.ip = Some(val!()),
            "-m" | "--method" => o.method = Some(val!()),
            "-p" | "--path" => o.path = Some(val!()),
            "-r" | "--referer" => o.referer = Some(val!()),
            "-s" | "--status" => o.status = Some(val!()),
            "-a" | "--all" => o.all_paths = true,
            "-c" | "--changes" => o.changes = true,
            "--no-name-check" => o.no_name_check = true,
            "--silent-load" => {}
            _ => {
                eprintln!("error: unexpected argument '{a}' found");
                return Err(2);
            }
        }
        i += 1;
    }
    Ok(o)
}

fn normalize_output(v: &str) -> Option<String> {
    match v {
        "tables" | "table" | "t" => Some("tables".into()),
        "raw" | "r" => Some("raw".into()),
        "csv" | "c" => Some("csv".into()),
        "json" | "j" => Some("json".into()),
        _ => None,
    }
}

fn print_help() {
    println!("rhit 2.0.4\n\nRhit analyzes your nginx logs.\n\nUsage: rhit [options] [FILES]\n\nOptions:");
    println!("    --help              Print help information");
    println!("    --version           Print the version");
    println!("    --color <color>     Whether to have styles and colors [auto, yes, no]");
    println!(" -k --key <KEY>         Key used in sorting and histogram, hits or bytes");
    println!(" -l --length <LENGTH>   Detail level, from 0 to 6");
    println!(" -f --fields <FIELDS>   Comma separated list of hit fields to display");
    println!(" -c --changes           Add tables with more popular and less popular entries");
    println!(" -d --date <DATE>       Filter dates on a day or inclusive range");
    println!(" -i --ip <IP>           Ip address to filter by, may be negated with !");
    println!(" -m --method <METHOD>   HTTP method to filter by");
    println!(" -p --path <PATH>       Pattern for path filtering");
    println!(" -r --referer <REFERER> Referrer filter");
    println!(" -s --status <STATUS>   Comma separated list of statuses or ranges");
    println!(" -t --time <TIME>       Filter the time of the day");
    println!(" -a --all               Show all paths, including resources");
    println!("    --no-name-check     Try to open all files, whatever their names");
    println!(" -o --output <OUTPUT>   tables, raw, csv, or json");
    println!("    --silent-load       Don't print anything during load");
}

fn load_hits(opts: &Opts) -> Result<Vec<Hit>, String> {
    let files = discover_files(opts)?;
    let re = Regex::new(r#"^(\S+) \S+ \S+ \[([^:]+):(\d\d):(\d\d):(\d\d) ([^\]]+)\] "([^"]*)" (\S+) (\S+) "([^"]*)" "([^"]*)""#).unwrap();
    let mut hits = Vec::new();
    for path in files {
        let lines = read_lines(&path)?;
        for raw in lines {
            if let Some(c) = re.captures(&raw) {
                let date = parse_log_date(&c[2])?;
                let hour: u32 = c[3].parse().unwrap_or(0);
                let min: u32 = c[4].parse().unwrap_or(0);
                let sec: u32 = c[5].parse().unwrap_or(0);
                let time = NaiveTime::from_hms_opt(hour, min, sec).unwrap_or(NaiveTime::MIN);
                let req = c[7].to_string();
                let mut parts = req.split_whitespace();
                let method = parts.next().unwrap_or("").to_string();
                let path_s = parts.next().unwrap_or("").to_string();
                let status = c[8].to_string();
                let bytes = if &c[9] == "-" { 0 } else { c[9].parse().unwrap_or(0) };
                let ip = c[1].to_string();
                let referer = c[10].to_string();
                hits.push(Hit { raw, ip, dt: NaiveDateTime::new(date, time), method, path: path_s, status, bytes, referer });
            }
        }
    }
    hits.sort_by_key(|h| h.dt);
    Ok(hits)
}

fn discover_files(opts: &Opts) -> Result<Vec<PathBuf>, String> {
    let roots: Vec<String> = if opts.files.is_empty() {
        vec!["/var/log/nginx/access.log".into(), "/var/log/nginx".into()]
    } else {
        opts.files.clone()
    };
    let mut out = Vec::new();
    for r in roots {
        let p = PathBuf::from(&r);
        if !p.exists() {
            if opts.files.is_empty() { continue; }
            return Err(format!("PathNotFound(\"{}\")", r));
        }
        if p.is_dir() {
            for e in fs::read_dir(&p).map_err(|e| e.to_string())? {
                let ep = e.map_err(|e| e.to_string())?.path();
                if ep.is_file() && (opts.no_name_check || looks_log(&ep)) {
                    out.push(ep);
                }
            }
        } else if opts.no_name_check || looks_log(&p) || opts.files.iter().any(|f| f == &r) {
            out.push(p);
        }
    }
    out.sort();
    Ok(out)
}

fn looks_log(p: &Path) -> bool {
    let n = p.file_name().and_then(|s| s.to_str()).unwrap_or("");
    n.contains("access") || n.ends_with(".log") || n.ends_with(".log.gz") || n.ends_with(".gz")
}

fn read_lines(path: &Path) -> Result<Vec<String>, String> {
    if path.extension().and_then(|s| s.to_str()) == Some("gz") {
        let out = Command::new("gzip").arg("-cd").arg(path).stdout(Stdio::piped()).output()
            .map_err(|e| e.to_string())?;
        if !out.status.success() {
            return Err(format!("can't read {}", path.display()));
        }
        let s = String::from_utf8_lossy(&out.stdout);
        return Ok(s.lines().map(|l| l.to_string()).collect());
    }
    let f = File::open(path).map_err(|e| e.to_string())?;
    let br = BufReader::new(f);
    Ok(br.lines().filter_map(Result::ok).collect())
}

fn parse_log_date(s: &str) -> Result<NaiveDate, String> {
    let mut it = s.split('/');
    let d: u32 = it.next().unwrap_or("1").parse().unwrap_or(1);
    let mon = match it.next().unwrap_or("") {
        "Jan" => 1, "Feb" => 2, "Mar" => 3, "Apr" => 4, "May" => 5, "Jun" => 6,
        "Jul" => 7, "Aug" => 8, "Sep" => 9, "Oct" => 10, "Nov" => 11, "Dec" => 12,
        _ => 1,
    };
    let y: i32 = it.next().unwrap_or("1970").parse().unwrap_or(1970);
    NaiveDate::from_ymd_opt(y, mon, d).ok_or_else(|| "invalid date".into())
}

fn matches_filters(h: &Hit, o: &Opts) -> bool {
    if let Some(f) = &o.ip { if !match_text(f, &h.ip) { return false; } }
    if let Some(f) = &o.method { if !match_method(f, &h.method) { return false; } }
    if let Some(f) = &o.path { if !match_expr(f, &h.path) { return false; } }
    if let Some(f) = &o.referer { if !match_expr(f, &h.referer) { return false; } }
    if let Some(f) = &o.status { if !match_status(f, &h.status) { return false; } }
    if let Some(f) = &o.date { if !match_date(f, h.dt) { return false; } }
    if let Some(f) = &o.time { if !match_time(f, h.dt.time()) { return false; } }
    true
}

fn match_text(f: &str, value: &str) -> bool {
    let (neg, pat) = f.strip_prefix('!').map_or((false, f), |s| (true, s));
    let m = Regex::new(pat).map(|r| r.is_match(value)).unwrap_or_else(|_| value.contains(pat));
    if neg { !m } else { m }
}

fn match_method(f: &str, value: &str) -> bool {
    let (neg, pat) = f.strip_prefix('!').map_or((false, f), |s| (true, s));
    let m = match pat {
        "none" => value.is_empty(),
        "other" => !matches!(value, "GET"|"POST"|"PUT"|"DELETE"|"HEAD"|"OPTIONS"|"PATCH"|"CONNECT"|"TRACE"),
        _ => value == pat,
    };
    if neg { !m } else { m }
}

fn match_expr(f: &str, value: &str) -> bool {
    eval_text_expr(f.trim(), value)
}

fn eval_text_expr(expr: &str, value: &str) -> bool {
    let expr = strip_outer_parens(expr.trim());
    if let Some(rest) = expr.strip_prefix('!') {
        return !eval_text_expr(rest.trim(), value);
    }
    if let Some(parts) = split_top(expr, '|') {
        return parts.iter().any(|p| eval_text_expr(p, value));
    }
    if let Some(parts) = split_top(expr, '&') {
        return parts.iter().all(|p| eval_text_expr(p, value));
    }
    for part in expr.split(',').map(str::trim).filter(|p| !p.is_empty()) {
        if !match_text(part, value) { return false; }
    }
    true
}

fn strip_outer_parens(mut s: &str) -> &str {
    loop {
        let t = s.trim();
        if !(t.starts_with('(') && t.ends_with(')')) { return t; }
        let mut depth = 0i32;
        let mut wraps = true;
        for (i, ch) in t.char_indices() {
            match ch {
                '(' => depth += 1,
                ')' => {
                    depth -= 1;
                    if depth == 0 && i + ch.len_utf8() < t.len() {
                        wraps = false;
                        break;
                    }
                }
                _ => {}
            }
        }
        if wraps { s = &t[1..t.len()-1]; } else { return t; }
    }
}

fn split_top(s: &str, op: char) -> Option<Vec<&str>> {
    let mut parts = Vec::new();
    let mut start = 0usize;
    let mut depth = 0i32;
    for (i, ch) in s.char_indices() {
        match ch {
            '(' => depth += 1,
            ')' => depth -= 1,
            c if c == op && depth == 0 => {
                parts.push(s[start..i].trim());
                start = i + ch.len_utf8();
            }
            _ => {}
        }
    }
    if parts.is_empty() {
        None
    } else {
        parts.push(s[start..].trim());
        Some(parts)
    }
}

fn match_status(f: &str, status: &str) -> bool {
    let code: i32 = status.parse().unwrap_or(0);
    let mut positive = false;
    let mut pos_match = false;
    for part in f.split(',').map(str::trim).filter(|p| !p.is_empty()) {
        let (neg, p) = part.strip_prefix('!').map_or((false, part), |s| (true, s));
        let m = if p.len() == 3 && p.ends_with("xx") {
            code / 100 == p[..1].parse::<i32>().unwrap_or(-1)
        } else if let Some((a,b)) = p.split_once('-') {
            let a: i32 = a.parse().unwrap_or(-1);
            let b: i32 = b.parse().unwrap_or(-1);
            code >= a && code <= b
        } else {
            status == p
        };
        if neg && m { return false; }
        if !neg { positive = true; pos_match |= m; }
    }
    !positive || pos_match
}

fn parse_filter_date(s: &str, sample_year: i32) -> Option<(NaiveDateTime, NaiveDateTime)> {
    let mut date_time = s.split('T');
    let date = date_time.next()?;
    let nums: Vec<i32> = date.split('/').filter_map(|p| p.parse().ok()).collect();
    let (y,m,d,precision) = match nums.as_slice() {
        [y] => (*y, 1, 1, 1),
        [a,b] if *a > 31 => (*a, *b as u32, 1, 2),
        [m,d] => (sample_year, *m as u32, *d as u32, 3),
        [y,m,d] => (*y, *m as u32, *d as u32, 3),
        _ => return None,
    };
    let time_s = date_time.next().unwrap_or("00:00:00");
    let tparts: Vec<u32> = time_s.split(':').filter_map(|p| p.parse().ok()).collect();
    let start_time = NaiveTime::from_hms_opt(*tparts.get(0).unwrap_or(&0), *tparts.get(1).unwrap_or(&0), *tparts.get(2).unwrap_or(&0))?;
    let start = NaiveDate::from_ymd_opt(y, m, d)?.and_time(start_time);
    let end = if date_time.next().is_some() { start } else if !tparts.is_empty() {
        start + chrono::Duration::seconds(if tparts.len() >= 3 { 0 } else if tparts.len() == 2 { 59 } else { 3599 })
    } else {
        match precision {
            1 => NaiveDate::from_ymd_opt(y, 12, 31)?.and_hms_opt(23,59,59)?,
            2 => {
                let next = if m == 12 { NaiveDate::from_ymd_opt(y+1,1,1)? } else { NaiveDate::from_ymd_opt(y,m+1,1)? };
                next.and_hms_opt(0,0,0)? - chrono::Duration::seconds(1)
            }
            _ => NaiveDate::from_ymd_opt(y,m,d)?.and_hms_opt(23,59,59)?,
        }
    };
    Some((start, end))
}

fn match_date(f: &str, dt: NaiveDateTime) -> bool {
    let (neg, rest) = f.strip_prefix('!').map_or((false, f), |s| (true, s));
    let m = if !rest.contains('-') && !rest.starts_with('>') && !rest.starts_with('<') && !rest.contains('T') {
        let date = dt.date();
        let nums: Vec<i32> = rest.split('/').filter_map(|p| p.parse().ok()).collect();
        match nums.as_slice() {
            [y] => date.year() == *y,
            [a,b] if *a > 31 => date.year() == *a && date.month() == *b as u32,
            [m,d] => date.month() == *m as u32 && date.day() == *d as u32,
            [y,m,d] => date.year() == *y && date.month() == *m as u32 && date.day() == *d as u32,
            _ => false,
        }
    } else if let Some(s) = rest.strip_prefix('>') {
        parse_filter_date(s, dt.year()).map(|(_, e)| dt > e).unwrap_or(false)
    } else if let Some(s) = rest.strip_prefix('<') {
        parse_filter_date(s, dt.year()).map(|(b, _)| dt < b).unwrap_or(false)
    } else if let Some((a,b)) = rest.split_once('-') {
        match (parse_filter_date(a, dt.year()), parse_filter_date(b, dt.year())) {
            (Some((sa,_)), Some((_,eb))) => dt >= sa && dt <= eb,
            _ => false,
        }
    } else {
        parse_filter_date(rest, dt.year()).map(|(a,b)| dt >= a && dt <= b).unwrap_or(false)
    };
    if neg { !m } else { m }
}

fn match_time(f: &str, t: NaiveTime) -> bool {
    let (neg, rest) = f.strip_prefix('!').map_or((false, f), |s| (true, s));
    let cmp = rest.chars().next().filter(|c| *c == '>' || *c == '<');
    let s = if cmp.is_some() { &rest[1..] } else { rest };
    let parts: Vec<u32> = s.split(':').filter_map(|p| p.parse().ok()).collect();
    let ft = NaiveTime::from_hms_opt(*parts.get(0).unwrap_or(&0), *parts.get(1).unwrap_or(&0), *parts.get(2).unwrap_or(&0)).unwrap_or(NaiveTime::MIN);
    let m = match cmp { Some('>') => t > ft, Some('<') => t < ft, _ => t == ft };
    if neg { !m } else { m }
}

fn print_raw(hits: &[Hit]) {
    for h in hits { println!("{}", h.raw); }
}

fn csv_escape(s: &str) -> String {
    format!("\"{}\"", s.replace('"', "\"\""))
}

fn print_csv(hits: &[Hit]) {
    println!("date,time,remote address,method,path,status,bytes sent,referer");
    for h in hits {
        println!("{},{},{},{},{},{},{},{}",
            h.dt.format("%Y/%m/%d"), h.dt.format("%H:%M:%S"), h.ip, h.method,
            csv_escape(&h.path), h.status, h.bytes, csv_escape(&h.referer));
    }
}

fn print_json(hits: &[Hit]) {
    println!("[");
    for (i, h) in hits.iter().enumerate() {
        let comma = if i + 1 == hits.len() { "" } else { "," };
        println!("  {{");
        println!("    \"date\": \"{}\",", h.dt.format("%Y/%m/%d"));
        println!("    \"time\": \"{}\",", h.dt.format("%H:%M:%S"));
        println!("    \"remote_addr\": {},", serde_json::to_string(&h.ip).unwrap());
        println!("    \"method\": {},", serde_json::to_string(&h.method).unwrap());
        println!("    \"path\": {},", serde_json::to_string(&h.path).unwrap());
        println!("    \"status\": {},", serde_json::to_string(&h.status).unwrap());
        println!("    \"bytes_sent\": {},", h.bytes);
        println!("    \"referer\": {}", serde_json::to_string(&h.referer).unwrap());
        println!("  }}{}", comma);
    }
    println!("]");
}

#[derive(Default, Clone)]
struct Agg { hits: usize, bytes: u64 }

fn print_tables(hits: &[Hit], opts: &Opts) {
    let bytes: u64 = hits.iter().map(|h| h.bytes).sum();
    if hits.is_empty() {
        println!("0 hits and 0 bytes");
        return;
    }
    let min = hits.first().unwrap().dt.format("%Y/%m/%d");
    let max = hits.last().unwrap().dt.format("%Y/%m/%d");
    println!("{} hits and {} from {} to {}", hits.len(), bytes, min, max);
    for f in fields(&opts.fields) {
        match f.as_str() {
            "date" => print_hist_date(hits, opts),
            "time" => print_hist_time(hits, opts),
            "method" => print_table(hits, "methods", "method", |h| h.method.clone(), opts),
            "status" => print_table(hits, "HTTP status codes", "status", |h| h.status.clone(), opts),
            "ip" => print_table(hits, "remote IP addresses", "IP address", |h| h.ip.clone(), opts),
            "ref" | "referer" => print_table(hits, "referrers", "referrer", |h| h.referer.clone(), opts),
            "path" => {
                let filtered: Vec<Hit> = if opts.all_paths { hits.to_vec() } else { hits.iter().filter(|h| !is_resource(&h.path)).cloned().collect() };
                print_table(&filtered, if opts.all_paths {"paths"} else {"paths (excluding resources like images, css, etc.)"}, "path", |h| h.path.clone(), opts);
            }
            _ => {}
        }
    }
}

fn fields(spec: &str) -> Vec<String> {
    let default = vec!["date","status","ref","path"].into_iter().map(String::from).collect::<Vec<_>>();
    let all = vec!["date","time","method","status","ip","ref","path"].into_iter().map(String::from).collect::<Vec<_>>();
    let mut out = if spec.starts_with('+') || spec.starts_with('-') { default } else { Vec::new() };
    let norm = spec.replace(',', "+");
    for raw in norm.split('+').filter(|s| !s.is_empty()) {
        let mut token = raw.trim();
        let mut remove = false;
        if let Some(t) = token.strip_prefix('-') { remove = true; token = t; }
        let vals = if token == "a" || token == "all" { all.clone() } else { vec![field_name(token)] };
        for v in vals {
            if remove { out.retain(|x| x != &v); }
            else { out.retain(|x| x != &v); out.push(v); }
        }
    }
    if out.is_empty() { vec!["date".into(),"status".into(),"ref".into(),"path".into()] } else { out }
}

fn field_name(s: &str) -> String {
    match s {
        "d" | "date" => "date",
        "t" | "time" => "time",
        "m" | "method" => "method",
        "s" | "status" => "status",
        "i" | "ip" => "ip",
        "r" | "ref" | "referer" => "ref",
        "p" | "path" | "paths" => "path",
        x => x,
    }.to_string()
}

fn sort_aggs(v: &mut Vec<(String, Agg)>, key: &str) {
    v.sort_by(|a,b| {
        let ka = if key.starts_with('b') { a.1.bytes as i128 } else { a.1.hits as i128 };
        let kb = if key.starts_with('b') { b.1.bytes as i128 } else { b.1.hits as i128 };
        kb.cmp(&ka).then_with(|| a.0.cmp(&b.0))
    });
}

fn print_table<F: Fn(&Hit)->String>(hits: &[Hit], title: &str, col: &str, f: F, opts: &Opts) {
    let mut map: HashMap<String, Agg> = HashMap::new();
    for h in hits {
        if col == "referrer" && h.referer == "-" { continue; }
        let e = map.entry(f(h)).or_default();
        e.hits += 1; e.bytes += h.bytes;
    }
    let mut rows: Vec<_> = map.into_iter().collect();
    sort_aggs(&mut rows, &opts.key);
    let limit = match opts.length { 0 => 5, 1 => 10, 2 => 20, 3 => 40, 4 => 80, 5 => 160, _ => usize::MAX };
    println!("{} {}. ", rows.len(), title);
    println!("#\t{}\thits\t%\tbytes", col);
    for (idx, (name, a)) in rows.into_iter().take(limit).enumerate() {
        let pct = if hits.is_empty() { 0.0 } else { (a.hits as f64) * 100.0 / (hits.len() as f64) };
        println!("{}\t{}\t{}\t{:.1}%\t{}", idx+1, name, a.hits, pct, a.bytes);
    }
}

fn print_hist_date(hits: &[Hit], _opts: &Opts) {
    let mut map: HashMap<String, Agg> = HashMap::new();
    for h in hits {
        let e = map.entry(h.dt.format("%Y/%m/%d").to_string()).or_default();
        e.hits += 1; e.bytes += h.bytes;
    }
    let mut rows: Vec<_> = map.into_iter().collect();
    rows.sort_by(|a,b| a.0.cmp(&b.0));
    println!("date\thits\tbytes");
    for (d,a) in rows { println!("{}\t{}\t{}", d, a.hits, a.bytes); }
}

fn print_hist_time(hits: &[Hit], _opts: &Opts) {
    let mut rows = vec![Agg::default(); 24];
    for h in hits { let e = &mut rows[h.dt.hour() as usize]; e.hits += 1; e.bytes += h.bytes; }
    println!("hour\thits\tbytes");
    for (i,a) in rows.iter().enumerate() { println!("{}\t{}\t{}", i, a.hits, a.bytes); }
}

fn is_resource(path: &str) -> bool {
    let p = path.split('?').next().unwrap_or(path).to_ascii_lowercase();
    [".png",".jpg",".jpeg",".gif",".svg",".ico",".css",".js",".webp",".woff",".woff2",".ttf",".map"].iter().any(|s| p.ends_with(s))
}
