use std::collections::HashMap;
use std::env;
use std::fs;
use std::path::Path;
use std::process;

const MARK1: &str = "##################################################################";
const MARK2: &str = "# Content under this line is handled by hostctl. DO NOT EDIT.";

type AppResult<T> = Result<T, String>;

#[derive(Clone, Debug)]
struct Entry { ip: String, host: String }
#[derive(Clone, Debug)]
struct Profile { name: String, status: String, entries: Vec<Entry> }
#[derive(Clone, Debug)]
struct Hosts { base: Vec<String>, profiles: Vec<Profile> }
#[derive(Clone, Debug)]
struct Config { host_file: String, out: String, raw: bool, quiet: bool, columns: Vec<String>, no_color: bool }

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() { print_root_help(); return; }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_help_for(&args); return;
    }
    if args.iter().any(|a| a == "--version" || a == "-v") { println!("hostctl version dev"); return; }
    match run(args) {
        Ok(()) => {},
        Err(e) => { eprintln!("[✖] error: {}", e); process::exit(1); }
    }
}

fn run(args: Vec<String>) -> AppResult<()> {
    let (cfg, rest) = parse_global(args)?;
    if rest.is_empty() { print_root_help(); return Ok(()); }
    let cmd = rest[0].as_str();
    match cmd {
        "list" => cmd_list(&cfg, &rest[1..]),
        "status" => cmd_status(&cfg, &rest[1..]),
        "add" => cmd_add(&cfg, &rest[1..]),
        "replace" => cmd_replace(&cfg, &rest[1..]),
        "enable" => cmd_set_status(&cfg, &rest[1..], "on"),
        "disable" => cmd_set_status(&cfg, &rest[1..], "off"),
        "toggle" => cmd_toggle(&cfg, &rest[1..]),
        "remove" | "rm" => cmd_remove(&cfg, &rest[1..]),
        "backup" => cmd_backup(&cfg, &rest[1..]),
        "restore" => cmd_restore(&cfg, &rest[1..]),
        "sync" => cmd_sync(&cfg, &rest[1..]),
        "help" => { print_help_for(&rest[1..].to_vec()); Ok(()) },
        other => Err(format!("unknown command {:?} for {:?}", other, "hostctl")),
    }
}

fn parse_global(args: Vec<String>) -> AppResult<(Config, Vec<String>)> {
    let mut cfg = Config { host_file: "/etc/hosts".into(), out: "table".into(), raw: false, quiet: false, columns: vec![], no_color: false };
    let mut rest = Vec::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--host-file" => { i += 1; cfg.host_file = args.get(i).cloned().ok_or("flag needs an argument: --host-file")?; }
            s if s.starts_with("--host-file=") => cfg.host_file = s[12..].into(),
            "-o" | "--out" => { i += 1; cfg.out = args.get(i).cloned().ok_or("flag needs an argument: --out")?; }
            s if s.starts_with("--out=") => cfg.out = s[6..].into(),
            "--raw" => { cfg.raw = true; cfg.out = "raw".into(); }
            "-q" | "--quiet" => cfg.quiet = true,
            "--no-color" => cfg.no_color = true,
            "-c" | "--column" => { i += 1; cfg.columns = split_cols(args.get(i).cloned().ok_or("flag needs an argument: --column")?); }
            s if s.starts_with("--column=") => cfg.columns = split_cols(s[9..].to_string()),
            _ => rest.push(args[i].clone()),
        }
        i += 1;
    }
    Ok((cfg, rest))
}
fn split_cols(s: String) -> Vec<String> { s.split(',').map(|x| x.trim().to_ascii_lowercase()).filter(|x| !x.is_empty()).collect() }

fn load_hosts(cfg: &Config) -> AppResult<Hosts> {
    if !cfg.quiet && cfg.out != "json" { eprintln!("[ℹ] Using hosts file: {}\n", cfg.host_file); }
    let txt = fs::read_to_string(&cfg.host_file).map_err(|e| format!("open {}: {}", cfg.host_file, e))?;
    Ok(parse_hosts(&txt))
}
fn save_hosts(cfg: &Config, hosts: &Hosts) -> AppResult<()> { fs::write(&cfg.host_file, render_hosts(hosts)).map_err(|e| e.to_string()) }

fn parse_hosts(txt: &str) -> Hosts {
    let lines: Vec<String> = txt.lines().map(|s| s.to_string()).collect();
    let marker = lines.iter().position(|l| l.trim() == MARK2);
    let split = marker.map(|m| m.saturating_sub(1)).unwrap_or(lines.len());
    let base = lines[..split].to_vec();
    let mut profiles = Vec::new();
    let mut i = marker.map(|m| m + 2).unwrap_or(lines.len());
    while i < lines.len() {
        let t = lines[i].trim();
        if t.starts_with("# profile.") {
            let mut parts = t.trim_start_matches("# profile.").splitn(2, ' ');
            let status = parts.next().unwrap_or("on").to_string();
            let name = parts.next().unwrap_or("").trim().to_string();
            let mut entries = Vec::new();
            i += 1;
            while i < lines.len() && lines[i].trim() != "# end" {
                if let Some(e) = parse_entry_line(&lines[i], &status) { entries.push(e); }
                i += 1;
            }
            profiles.push(Profile { name, status, entries });
        }
        i += 1;
    }
    Hosts { base, profiles }
}
fn parse_entry_line(line: &str, status: &str) -> Option<Entry> {
    let mut s = line.trim().to_string();
    if status == "off" { s = s.trim_start_matches('#').trim_start().to_string(); }
    if s.is_empty() || s.starts_with('#') { return None; }
    let mut it = s.split_whitespace();
    let ip = it.next()?.to_string();
    let hosts: Vec<String> = it.map(|x| x.to_string()).collect();
    if hosts.is_empty() { None } else { Some(Entry { ip, host: hosts.join(" ") }) }
}
fn render_hosts(hosts: &Hosts) -> String {
    let mut base = hosts.base.clone();
    while base.last().map(|l| l.trim().is_empty()).unwrap_or(false) { base.pop(); }
    let mut out = String::new();
    for l in &base { out.push_str(l); out.push('\n'); }
    if !out.ends_with('\n') { out.push('\n'); }
    out.push('\n'); out.push_str(MARK1); out.push('\n'); out.push_str(MARK2); out.push('\n'); out.push_str(MARK1); out.push_str("\n\n");
    for (idx, p) in hosts.profiles.iter().enumerate() {
        if idx > 0 { out.push('\n'); }
        out.push_str(&format!("# profile.{} {}\n", p.status, p.name));
        for e in &p.entries {
            if p.status == "off" { out.push_str("# "); }
            out.push_str(&format!("{} {}\n", e.ip, e.host));
        }
        out.push_str("# end\n");
    }
    out
}

fn rows_for_list(hosts: &Hosts, filter: &[String], mode: Option<&str>) -> Vec<Vec<String>> {
    let mut rows = Vec::new();
    let include_default = filter.is_empty() && mode != Some("off");
    if include_default {
        for line in &hosts.base {
            if let Some(e) = parse_entry_line(line, "on") {
                for h in e.host.split_whitespace() { rows.push(vec!["default".into(), "on".into(), e.ip.clone(), h.into()]); }
            }
        }
    }
    for p in &hosts.profiles {
        if !filter.is_empty() && !filter.contains(&p.name) { continue; }
        if mode == Some("on") && p.status != "on" { continue; }
        if mode == Some("off") && p.status != "off" { continue; }
        for e in &p.entries { for h in e.host.split_whitespace() { rows.push(vec![p.name.clone(), p.status.clone(), e.ip.clone(), h.into()]); } }
    }
    rows
}
fn rows_for_status(hosts: &Hosts, filter: &[String]) -> Vec<Vec<String>> {
    hosts.profiles.iter().filter(|p| filter.is_empty() || filter.contains(&p.name)).map(|p| vec![p.name.clone(), p.status.clone(), String::new(), String::new()]).collect()
}

fn cmd_list(cfg: &Config, args: &[String]) -> AppResult<()> {
    let mut mode = None; let mut filters = Vec::new();
    for a in args { match a.as_str() { "enabled" | "on" => mode = Some("on"), "disabled" | "off" => mode = Some("off"), _ if !a.starts_with('-') => filters.push(a.clone()), _ => {} } }
    let hosts = load_hosts(cfg)?;
    let rows = rows_for_list(&hosts, &filters, mode);
    let headers = vec!["PROFILE", "STATUS", "IP", "DOMAIN"];
    output(cfg, &headers, &rows, false); Ok(())
}
fn cmd_status(cfg: &Config, args: &[String]) -> AppResult<()> {
    let filters: Vec<String> = args.iter().filter(|a| !a.starts_with('-')).cloned().collect();
    let hosts = load_hosts(cfg)?; let rows = rows_for_status(&hosts, &filters); output(cfg, &["PROFILE", "STATUS"], &rows, true); Ok(())
}
fn cmd_add(cfg: &Config, args: &[String]) -> AppResult<()> {
    if args.first().map(|s| s.as_str()) == Some("domains") || args.first().map(|s| s.as_str()) == Some("domain") { return cmd_add_domains(cfg, &args[1..]); }
    let profile = args.iter().find(|a| !a.starts_with('-')).cloned().ok_or("missing profile name")?;
    let from = val_flag(args, "-f", "--from").unwrap_or_default();
    let entries = read_entries(&from)?;
    let mut hosts = load_hosts(cfg)?;
    if let Some(p) = hosts.profiles.iter_mut().find(|p| p.name == profile) { p.entries.extend(entries.clone()); p.status = "on".into(); } else { hosts.profiles.push(Profile { name: profile.clone(), status: "on".into(), entries: entries.clone() }); }
    save_hosts(cfg, &hosts)?; output_entries(cfg, &profile, "on", &entries); Ok(())
}
fn cmd_replace(cfg: &Config, args: &[String]) -> AppResult<()> {
    let profile = args.iter().find(|a| !a.starts_with('-')).cloned().ok_or("missing profile name")?;
    let from = val_flag(args, "-f", "--from").unwrap_or_default(); let entries = read_entries(&from)?;
    let mut hosts = load_hosts(cfg)?; hosts.profiles.retain(|p| p.name != profile); hosts.profiles.push(Profile { name: profile.clone(), status: "on".into(), entries: entries.clone() });
    save_hosts(cfg, &hosts)?; output_entries(cfg, &profile, "on", &entries); Ok(())
}
fn read_entries(path: &str) -> AppResult<Vec<Entry>> {
    let txt = fs::read_to_string(path).map_err(|e| format!("open {}: {}", path, e))?;
    let mut out = Vec::new();
    for line in txt.lines() { if let Some(e) = parse_entry_line(line, "on") { for h in e.host.split_whitespace() { out.push(Entry{ip:e.ip.clone(), host:h.into()}); } } }
    Ok(out)
}
fn cmd_add_domains(cfg: &Config, args: &[String]) -> AppResult<()> {
    let profile = args.iter().find(|a| !a.starts_with('-')).cloned().ok_or("missing profile name")?;
    let ip = val_flag(args, "", "--ip").unwrap_or_else(|| "127.0.0.1".into());
    let mut domains = Vec::new(); let mut skip = false;
    for (i,a) in args.iter().enumerate() { if skip { skip=false; continue; } if i==0 || a.starts_with('-') { if a=="--ip" {skip=true;} continue; } domains.push(a.clone()); }
    let entries: Vec<Entry> = domains.iter().map(|d| Entry{ip: ip.clone(), host: d.clone()}).collect();
    let mut hosts = load_hosts(cfg)?; if let Some(p)=hosts.profiles.iter_mut().find(|p|p.name==profile){p.entries.extend(entries.clone());p.status="on".into();} else {hosts.profiles.push(Profile{name:profile.clone(),status:"on".into(),entries:entries.clone()});}
    save_hosts(cfg,&hosts)?; if !cfg.quiet && cfg.out != "json" { eprintln!("[✔] Domains '{}' added.\n", domains.join(", ")); } output_entries(cfg,&profile,"on",&entries); Ok(())
}
fn cmd_set_status(cfg: &Config, args: &[String], status: &str) -> AppResult<()> {
    let all = args.iter().any(|a| a == "--all"); let only = args.iter().any(|a| a == "--only");
    let names: Vec<String> = args.iter().filter(|a| !a.starts_with('-')).cloned().collect();
    let mut hosts = load_hosts(cfg)?;
    if !all && names.is_empty() { return Err("missing profile name".into()); }
    let mut changed = Vec::new();
    if all { for p in &mut hosts.profiles { p.status=status.into(); changed.push(p.clone()); } }
    else {
        for n in &names { if !hosts.profiles.iter().any(|p| &p.name==n) { return Err("unknown profile name".into()); } }
        for p in &mut hosts.profiles { if names.contains(&p.name) { p.status=status.into(); changed.push(p.clone()); } else if only { p.status = if status=="on" {"off"} else {"on"}.into(); } }
    }
    save_hosts(cfg,&hosts)?; let rows = changed.iter().flat_map(|p| p.entries.iter().flat_map(move |e| e.host.split_whitespace().map(move |h| vec![p.name.clone(), p.status.clone(), e.ip.clone(), h.into()]))).collect::<Vec<_>>(); output(cfg,&["PROFILE","STATUS","IP","DOMAIN"],&rows,false); Ok(())
}
fn cmd_toggle(cfg: &Config, args: &[String]) -> AppResult<()> {
    let names: Vec<String> = args.iter().filter(|a| !a.starts_with('-')).cloned().collect(); if names.is_empty(){return Err("missing profile name".into())}
    let mut hosts=load_hosts(cfg)?; let mut changed=Vec::new(); for n in &names { if !hosts.profiles.iter().any(|p|&p.name==n){return Err("unknown profile name".into());} }
    for p in &mut hosts.profiles { if names.contains(&p.name){ p.status=if p.status=="on"{"off".into()}else{"on".into()}; changed.push(p.clone()); } }
    save_hosts(cfg,&hosts)?; let rows=changed.iter().flat_map(|p| p.entries.iter().flat_map(move|e| e.host.split_whitespace().map(move|h| vec![p.name.clone(),p.status.clone(),e.ip.clone(),h.into()]))).collect::<Vec<_>>(); output(cfg,&["PROFILE","STATUS","IP","DOMAIN"],&rows,false); Ok(())
}
fn cmd_remove(cfg:&Config,args:&[String])->AppResult<()> {
    if args.first().map(|s|s.as_str())==Some("domains")||args.first().map(|s|s.as_str())==Some("domain"){return cmd_remove_domains(cfg,&args[1..]);}
    let all=args.iter().any(|a|a=="--all"); let names:Vec<String>=args.iter().filter(|a|!a.starts_with('-')).cloned().collect(); if !all&&names.is_empty(){return Err("missing profile name".into())}
    let mut hosts=load_hosts(cfg)?; if !all { for n in &names { if !hosts.profiles.iter().any(|p|&p.name==n){return Err("unknown profile name".into());} } }
    hosts.profiles.retain(|p| !(all || names.contains(&p.name))); save_hosts(cfg,&hosts)?; if !cfg.quiet&&cfg.out!="json"{eprintln!("[✔] Profile(s) '{}' removed.\n", if all{"all".into()}else{names.join(", ")});} Ok(())
}
fn cmd_remove_domains(cfg:&Config,args:&[String])->AppResult<()> {
    let profile=args.iter().find(|a|!a.starts_with('-')).cloned().ok_or("missing profile name")?; let domains:Vec<String>=args.iter().skip(1).filter(|a|!a.starts_with('-')).cloned().collect(); let mut hosts=load_hosts(cfg)?;
    let remaining; if let Some(p)=hosts.profiles.iter_mut().find(|p|p.name==profile){ p.entries.retain(|e| !domains.contains(&e.host)); remaining=Some(p.clone()); } else { return Err("unknown profile name".into()); }
    if let Some(p)=&remaining { if p.entries.is_empty(){ hosts.profiles.retain(|x|x.name!=profile); } }
    save_hosts(cfg,&hosts)?; if !cfg.quiet&&cfg.out!="json"{ if domains.is_empty(){eprintln!("[✔] Profile '{}' removed.\n",profile);}else{eprintln!("[✔] Domains '{}' removed.\n",domains.join(", "));}}
    if let Some(p)=remaining { let pname=p.name.clone(); let pstatus=p.status.clone(); let mut rows=Vec::new(); for e in &p.entries { for h in e.host.split_whitespace() { rows.push(vec![pname.clone(), pstatus.clone(), e.ip.clone(), h.to_string()]); } } output(cfg, &["PROFILE","STATUS","IP","DOMAIN"], &rows, false); } Ok(())
}
fn cmd_backup(cfg:&Config,args:&[String])->AppResult<()> { let path=val_flag(args,"","--path").unwrap_or_else(||".".into()); let data=fs::read(&cfg.host_file).map_err(|e|format!("open {}: {}",cfg.host_file,e))?; let name=Path::new(&cfg.host_file).file_name().unwrap_or_default().to_string_lossy(); let dest=Path::new(&path).join(format!("{}.{}",name,"backup")); fs::write(&dest,data).map_err(|e|e.to_string())?; if !cfg.quiet{println!("{}",dest.display());} Ok(()) }
fn cmd_restore(cfg:&Config,args:&[String])->AppResult<()> { let from=val_flag(args,"","--from").unwrap_or_default(); let data=fs::read(&from).map_err(|e|format!("open {}: {}",from,e))?; fs::write(&cfg.host_file,data).map_err(|e|e.to_string())?; Ok(()) }
fn cmd_sync(_cfg:&Config,args:&[String])->AppResult<()> { if args.is_empty(){ print_sync_help(); return Ok(()); } Err("docker integration is not available in this build".into()) }

fn val_flag(args:&[String], short:&str, long:&str)->Option<String>{ for i in 0..args.len(){ if (!short.is_empty()&&args[i]==short)||(!long.is_empty()&&args[i]==long){return args.get(i+1).cloned();} if !long.is_empty() && args[i].starts_with(&(long.to_string()+"=")){return Some(args[i][long.len()+1..].into());} } None }
fn output_entries(cfg:&Config, profile:&str, status:&str, entries:&[Entry]){ let rows=entries.iter().flat_map(|e| e.host.split_whitespace().map(move|h| vec![profile.into(),status.into(),e.ip.clone(),h.into()])).collect::<Vec<_>>(); output(cfg,&["PROFILE","STATUS","IP","DOMAIN"],&rows,false); }

fn output(cfg:&Config, headers:&[&str], rows:&[Vec<String>], status_mode:bool){ if cfg.quiet && false { return; } let mut idxs:Vec<usize>=(0..headers.len()).collect(); if !cfg.columns.is_empty() && !status_mode { let map:HashMap<&str,usize>=[("profile",0),("status",1),("ip",2),("domain",3),("host",3)].into_iter().collect(); idxs=cfg.columns.iter().filter_map(|c|map.get(c.as_str()).copied()).collect(); if idxs.is_empty(){idxs=(0..headers.len()).collect();} }
    match cfg.out.as_str(){ "json"=>print_json(headers,rows,&idxs,status_mode), "raw"=>print_raw(headers,rows,&idxs), "markdown"=>print_markdown(headers,rows,&idxs), _=>print_table(headers,rows,&idxs) }
}
fn selected(headers:&[&str], rows:&[Vec<String>], idxs:&[usize])->(Vec<String>,Vec<Vec<String>>,Vec<usize>){ let hs=idxs.iter().map(|&i|headers[i].to_string()).collect::<Vec<_>>(); let rs=rows.iter().map(|r|idxs.iter().map(|&i|r.get(i).cloned().unwrap_or_default()).collect::<Vec<_>>()).collect::<Vec<_>>(); let mut w=hs.iter().map(|h|h.len()).collect::<Vec<_>>(); for r in &rs{for(i,c)in r.iter().enumerate(){w[i]=w[i].max(c.len());}} (hs,rs,w) }
fn print_raw(headers:&[&str],rows:&[Vec<String>],idxs:&[usize]){ let(hs,rs,w)=selected(headers,rows,idxs); for(i,h)in hs.iter().enumerate(){print!("{:<width$}\t",h,width=w[i]);} println!(); for r in rs{for(i,c)in r.iter().enumerate(){print!("{:<width$}\t",c,width=w[i]);} println!();} }
fn print_markdown(headers:&[&str],rows:&[Vec<String>],idxs:&[usize]){ let(hs,rs,w)=selected(headers,rows,idxs); print_md_row(&hs,&w); print!("|"); for width in &w{print!("{}|","-".repeat(width+2));} println!(); let mut last=String::new(); for r in rs{ if !last.is_empty()&&r.first()!=Some(&last){print!("|");for width in &w{print!("{}|","-".repeat(width+2));}println!();} last=r.first().cloned().unwrap_or_default(); print_md_row(&r,&w);} }
fn print_md_row(r:&[String],w:&[usize]){ print!("|"); for(i,c)in r.iter().enumerate(){print!(" {:<width$} |",c,width=w[i]);} println!(); }
fn print_table(headers:&[&str],rows:&[Vec<String>],idxs:&[usize]){ let(hs,rs,w)=selected(headers,rows,idxs); let sep=||{print!("+");for width in &w{print!("{}+","-".repeat(width+2));}println!();}; sep(); print_md_row(&hs,&w); sep(); let mut last=String::new(); for r in rs{ if !last.is_empty()&&r.first()!=Some(&last){sep();} last=r.first().cloned().unwrap_or_default(); print_md_row(&r,&w);} sep(); }
fn print_json(headers:&[&str],rows:&[Vec<String>],_idxs:&[usize],status_mode:bool){ let mut first=true; print!("["); for r in rows{ if !first{print!(",");} first=false; let ip=if status_mode{""}else{r.get(2).map(String::as_str).unwrap_or("")}; let host=if status_mode{""}else{r.get(3).map(String::as_str).unwrap_or("")}; print!("{{\"Profile\":\"{}\",\"Status\":\"{}\",\"IP\":\"{}\",\"Host\":\"{}\"}}",esc(&r[0]),esc(&r[1]),esc(ip),esc(host)); } println!("]"); let _=headers; }
fn esc(s:&str)->String{s.replace('\\',"\\\\").replace('"',"\\\"")}

fn print_root_help(){ println!("\nhostctl is a CLI tool to manage your hosts file with ease.\nYou can have multiple profiles, enable/disable exactly what\nyou need each time with a simple interface.\n\nUsage:\n  hostctl [command]\n\nAvailable Commands:\n  add         Add content to a profile in your hosts file.\n  backup      Creates a backup copy of your hosts file\n  disable     Disable a profile from your hosts file.\n  enable      Enable a profile on your hosts file.\n  help        Help about any command\n  list        Shows a detailed list of profiles on your hosts file.\n  remove      Remove a profile from your hosts file.\n  replace     Replace content to a profile in your hosts file.\n  restore     Restore hosts file content from a backup file.\n  status      Shows a list of profile names and statuses on your hosts file.\n  sync        Sync some system IPs with a profile.\n  toggle      Change status of a profile on your hosts file.\n\nFlags:\n  -c, --column strings     Column names to show on lists. comma separated\n  -h, --help               help for hostctl\n      --host-file string   Hosts file path (default \"/etc/hosts\")\n      --no-color           force colorless output\n  -o, --out string         Output type (table|raw|markdown|json) (default \"table\")\n  -q, --quiet              Run command without output\n      --raw                Output without borders (same as -o raw)\n  -v, --version            version for hostctl\n\nUse \"hostctl [command] --help\" for more information about a command."); }
fn print_help_for(args:&Vec<String>){ if args.is_empty(){print_root_help();return;} match args[0].as_str(){"sync"=>print_sync_help(),"add"=>println!("\nReads from a file and set content to a profile in your hosts file.\nIf the profile already exists it will be added to it.\n\nUsage:\n  hostctl add [profiles] [flags]\n  hostctl add [command]\n\nAvailable Commands:\n  domains     Add content in your hosts file.\n\nFlags:\n  -f, --from string     file to read\n  -h, --help            help for add\n  -w, --wait duration   Enables a profile for a specific amount of time. (example: 5m, 1h) (default -1ns)"),"list"=>println!("\nShows a detailed list of profiles on your hosts file with name, ip and host name.\nYou can filter by profile name.\n\nThe \"default\" profile is all the content that is not handled by hostctl tool.\n\nUsage:\n  hostctl list [profiles] [flags]"),"status"=>println!("\nShows a list of unique profile names on your hosts file with its status.\n\nThe \"default\" profile is always on and will be skipped.\n\nUsage:\n  hostctl status [profiles] [flags]"),_=>print_root_help()} }
fn print_sync_help(){ println!("\nReads IPs and names from some local system and sync it with a profile in your hosts file.\n\nUsage:\n  hostctl sync [command]\n\nAvailable Commands:\n  docker         Sync your Docker containers IPs with a profile.\n  docker-compose Sync your docker-compose containers IPs with a profile."); }
