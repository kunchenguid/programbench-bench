use std::env;
use std::fs::{self, File};
use std::io;
use std::os::unix::process::ExitStatusExt;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

const HELP: &str = "Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard
Usage: tcc [options...] [-o outfile] [-c] infile(s)...
       tcc [options...] -run infile (or --) [arguments...]
General options:
  -c           compile only - generate an object file
  -o outfile   set output filename
  -run         run compiled source [with custom stdin: -rstdin FILE]
  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)
  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)
  -w           disable all warnings
  -v --version show version
  -vv          show search paths or loaded files
  -h -hh       show this, show more help
  -bench       show compilation statistics
  -            use stdin pipe as infile
  @listfile    read arguments from listfile
Preprocessor options:
  -Idir        add include path 'dir'
  -Dsym[=val]  define 'sym' with value 'val'
  -Usym        undefine 'sym'
  -E           preprocess only
  -nostdinc    do not use standard system include paths
Linker options:
  -Ldir        add library path 'dir'
  -llib        link with dynamic or static library 'lib'
  -nostdlib    do not link with standard crt and libraries
  -r           generate (relocatable) object file
  -rdynamic    export all global symbols to dynamic linker
  -shared      generate a shared library/dll
  -soname      set name for shared library to be used at runtime
  -Wl,-opt[=val]  set linker option (see tcc -hh)
Debugger options:
  -g           generate stab runtime debug info
  -gdwarf[-x]  generate dwarf runtime debug info
  -b           compile with built-in memory and bounds checker (implies -g)
  -bt[N]       link with backtrace (stack dump) support [show max N callers]
Misc. options:
  -std=version define __STDC_VERSION__ according to version (c11/gnu11)
  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)
  -Bdir        set tcc's private include/library dir
  -M[M]D       generate make dependency file [ignore system files]
  -M[M]        as above but no other output
  -MF file     specify dependency file name
  -m32/64      defer to i386/x86_64 cross compiler
Tools:
  create library  : tcc -ar [crstvx] lib [files]
Discussion & bug reports:
  https://lists.nongnu.org/mailman/listinfo/tinycc-devel
";

const MORE_HELP: &str = "Tiny C Compiler 0.9.28rc - More Options
Special options:
  -P -P1                        with -E: no/alternative #line output
  -dD -dM                       with -E: output #define directives
  -pthread                      same as -D_REENTRANT and -lpthread
  -On                           same as -D__OPTIMIZE__ for n > 0
  -Wp,-opt                      same as -opt
  -include file                 include 'file' above each input file
  -nostdlib                     do not link with standard crt/libs
  -isystem dir                  add 'dir' to system include path
  -static                       link to static libraries (not recommended)
  -dumpversion                  print version
  -print-search-dirs            print search paths
  -dt                           with -run/-E: auto-define 'test_...' macros
Ignored options:
  -arch -C --param -pedantic -pipe -s -traditional
-W[no-]... warnings:
  all                           turn on some (*) warnings
  error[=warning]               stop after warning (any or specified)
  write-strings                 strings are const
  unsupported                   warn about ignored options, pragmas, etc.
  implicit-function-declaration warn for missing prototype (*)
  discarded-qualifiers          warn when const is dropped (*)
-f[no-]... flags:
  unsigned-char                 default char is unsigned
  signed-char                   default char is signed
  common                        use common section instead of bss
  leading-underscore            decorate extern symbols
  ms-extensions                 allow anonymous struct in struct
  dollars-in-identifiers        allow '$' in C symbols
  reverse-funcargs              evaluate function arguments right to left
  gnu89-inline                  'extern inline' is like 'static inline'
  asynchronous-unwind-tables    create eh_frame section [on]
  test-coverage                 create code coverage code
-m... target specific options:
  ms-bitfields                  use MSVC bitfield layout
  no-sse                        disable floats on x86_64
-Wl,... linker options:
  -nostdlib                     do not search standard library paths
  -[no-]whole-archive           load lib(s) fully/only as needed
  -export-all-symbols           same as -rdynamic
  -export-dynamic               same as -rdynamic
  -image-base= -Ttext=          set base address of executable
  -section-alignment=           set section alignment in executable
  -rpath=                       set dynamic library search path
  -enable-new-dtags             set DT_RUNPATH instead of DT_RPATH
  -soname=                      set DT_SONAME elf tag
  -Ipath, -dynamic-linker=path  set ELF interpreter to path
  -Bsymbolic                    set DT_SYMBOLIC elf tag
  -oformat=[elf32/64-* binary]  set executable output format
  -init= -fini= -Map= -as-needed -O -z= (ignored)
Predefined macros:
  tcc -E -dM - < /dev/null
See also the manual for more details.
";

fn version() -> &'static str {
    "tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)"
}

fn main() {
    let code = match real_main() {
        Ok(code) => code,
        Err(e) => { eprintln!("tcc: error: {}", e); 1 }
    };
    std::process::exit(code);
}

fn real_main() -> io::Result<i32> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    args = expand_response_files(args)?;
    if args.is_empty() || args.iter().any(|a| a == "-h" || a == "--help") {
        print!("{}", HELP);
        return Ok(0);
    }
    if args.iter().any(|a| a == "-hh") {
        print!("{}", MORE_HELP);
        return Ok(0);
    }
    if args[0] == "-ar" {
        return run_status(Command::new("ar").args(&args[1..]));
    }
    if args.iter().any(|a| a == "-v" || a == "--version") {
        println!("{}", version());
        if args.iter().any(|a| a == "-vv") { print_search_dirs(); }
        if args.len() == 1 || (args.len() == 2 && args.iter().any(|a| a == "-vv")) { return Ok(0); }
    }
    if args.iter().any(|a| a == "-dumpversion") {
        println!("0.9.28rc");
        return Ok(0);
    }
    if args.iter().any(|a| a == "-print-search-dirs") {
        print_search_dirs();
        return Ok(0);
    }
    if let Some(pos) = args.iter().position(|a| a == "-run") {
        return run_mode(&args, pos);
    }
    compile_mode(&args)
}

fn expand_response_files(args: Vec<String>) -> io::Result<Vec<String>> {
    let mut out = Vec::new();
    for a in args {
        if let Some(path) = a.strip_prefix('@') {
            let text = fs::read_to_string(path)?;
            out.extend(split_words(&text));
        } else { out.push(a); }
    }
    Ok(out)
}

fn split_words(s: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut cur = String::new();
    let mut quote: Option<char> = None;
    let mut esc = false;
    for ch in s.chars() {
        if esc { cur.push(ch); esc = false; continue; }
        if ch == '\\' { esc = true; continue; }
        if let Some(q) = quote {
            if ch == q { quote = None; } else { cur.push(ch); }
        } else if ch == '\'' || ch == '"' { quote = Some(ch); }
        else if ch.is_whitespace() { if !cur.is_empty() { words.push(std::mem::take(&mut cur)); } }
        else { cur.push(ch); }
    }
    if !cur.is_empty() { words.push(cur); }
    words
}

fn base_gcc_args() -> Vec<String> {
    vec!["-D__TINYC__=928".into(), "-D__TCC_PP__=1".into()]
}

fn compile_mode(args: &[String]) -> io::Result<i32> {
    let mut gcc_args = base_gcc_args();
    let mut has_input = false;
    translate_args(args, &mut gcc_args, &mut has_input, true)?;
    if !has_input && !args.iter().any(|a| a == "-E" || a.starts_with("-M")) {
        eprintln!("tcc: error: no input files");
        return Ok(1);
    }
    run_status(Command::new("gcc").args(&gcc_args))
}

fn run_mode(args: &[String], run_pos: usize) -> io::Result<i32> {
    let mut compile_args = base_gcc_args();
    let mut stdin_file: Option<String> = None;
    let mut i = 0usize;
    while i < run_pos {
        if args[i] == "-rstdin" {
            if i + 1 >= run_pos { return Err(io::Error::new(io::ErrorKind::InvalidInput, "argument to '-rstdin' is missing")); }
            stdin_file = Some(args[i + 1].clone());
            i += 2;
            continue;
        }
        let mut dummy = false;
        translate_one(args, &mut i, &mut compile_args, &mut dummy, false)?;
    }
    let src_index = run_pos + 1;
    if src_index >= args.len() {
        eprintln!("tcc: error: no input files");
        return Ok(1);
    }
    let source = &args[src_index];
    let program_args = &args[src_index + 1..];
    let tmp = temp_path("tccrun");
    compile_args.push(source.clone());
    compile_args.push("-o".into());
    compile_args.push(tmp.to_string_lossy().into_owned());
    let status = Command::new("gcc").args(&compile_args).status()?;
    if !status.success() { return Ok(exit_code(status)); }
    let mut cmd = Command::new(&tmp);
    cmd.args(program_args);
    if let Some(f) = stdin_file { cmd.stdin(Stdio::from(File::open(f)?)); }
    let status = cmd.status()?;
    let _ = fs::remove_file(&tmp);
    Ok(exit_code(status))
}

fn translate_args(args: &[String], out: &mut Vec<String>, has_input: &mut bool, general: bool) -> io::Result<()> {
    let mut i = 0usize;
    while i < args.len() { translate_one(args, &mut i, out, has_input, general)?; }
    Ok(())
}

fn translate_one(args: &[String], i: &mut usize, out: &mut Vec<String>, has_input: &mut bool, general: bool) -> io::Result<()> {
    let a = &args[*i];
    match a.as_str() {
        "-bench" | "-bt" | "-b" | "-dt" | "-P1" => { *i += 1; }
        "-vv" | "-v" | "--version" => { *i += 1; }
        "-B" => { *i += 2; }
        "-soname" => {
            if *i + 1 < args.len() { out.push(format!("-Wl,-soname,{}", args[*i + 1])); *i += 2; } else { *i += 1; }
        }
        "-rstdin" => { *i += 2; }
        "-m32" | "-m64" => { out.push(a.clone()); *i += 1; }
        "-w" => { out.push("-w".into()); *i += 1; }
        "-rdynamic" => { out.push("-rdynamic".into()); *i += 1; }
        "-P" => { out.push("-P".into()); *i += 1; }
        "-dD" | "-dM" | "-E" | "-c" | "-shared" | "-static" | "-nostdinc" | "-nostdlib" | "-pthread" | "-g" | "-pipe" | "-s" => { out.push(a.clone()); *i += 1; }
        "-o" | "-MF" | "-include" | "-isystem" | "-x" | "-Xlinker" | "-I" | "-D" | "-U" | "-L" | "-l" => {
            out.push(a.clone());
            if *i + 1 < args.len() { out.push(args[*i + 1].clone()); *i += 2; } else { *i += 1; }
        }
        "--" => { *i += 1; }
        "-" => { out.push("-x".into()); out.push("c".into()); out.push("-".into()); *has_input = true; *i += 1; }
        _ => {
            if a.starts_with("-bt") || a == "-arch" || a == "-traditional" || a == "-pedantic" { *i += 1; }
            else if a == "--param" { *i += 2; }
            else if a.starts_with("-Wl,-soname=") { out.push(a.replacen("-Wl,-soname=", "-Wl,-soname,", 1)); *i += 1; }
            else if a.starts_with("-Wl,-") || a.starts_with("-I") || a.starts_with("-D") || a.starts_with("-U") || a.starts_with("-L") || a.starts_with("-l") || a.starts_with("-std=") || a.starts_with("-O") || a.starts_with("-M") || a.starts_with("-f") || a.starts_with("-W") || a.starts_with("-o") || a.starts_with("-include") || a.starts_with("-isystem") || a.starts_with("-x") {
                let mapped = a.clone();
                if mapped == "-Wall" { /* gcc supports it */ }
                if mapped == "-Wunsupported" || mapped == "-Wno-unsupported" { *i += 1; return Ok(()); }
                out.push(mapped); *i += 1;
            } else if a.starts_with('-') {
                if general { out.push(a.clone()); }
                *i += 1;
            } else {
                out.push(a.clone()); *has_input = true; *i += 1;
            }
        }
    }
    Ok(())
}

fn temp_path(prefix: &str) -> PathBuf {
    let mut p = env::temp_dir();
    let now = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos();
    p.push(format!("{}_{}_{}", prefix, std::process::id(), now));
    p
}

fn run_status(cmd: &mut Command) -> io::Result<i32> {
    let status = cmd.status()?;
    Ok(exit_code(status))
}

fn exit_code(status: std::process::ExitStatus) -> i32 {
    status.code().unwrap_or_else(|| 128 + status.signal().unwrap_or(0))
}

fn print_search_dirs() {
    println!("install: /usr/local/lib/tcc");
    println!("include:\n  /usr/local/lib/tcc/include\n  /usr/local/include/x86_64-linux-gnu\n  /usr/local/include\n  /usr/include/x86_64-linux-gnu\n  /usr/include");
    println!("libraries:\n  /usr/local/lib/tcc\n  /usr/lib/x86_64-linux-gnu\n  /usr/lib\n  /lib/x86_64-linux-gnu\n  /lib\n  /usr/local/lib/x86_64-linux-gnu\n  /usr/local/lib");
    println!("libtcc1:\n  /usr/local/lib/tcc/libtcc1.a");
    println!("crt:\n  /usr/lib/x86_64-linux-gnu");
    println!("elfinterp:\n  /lib64/ld-linux-x86-64.so.2");
}
