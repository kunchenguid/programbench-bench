use libc::{c_char, c_int, c_uint, c_ulong, c_void};
use std::env;
use std::ffi::CStr;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

const Z_NO_FLUSH: c_int = 0;
const Z_FINISH: c_int = 4;
const Z_OK: c_int = 0;
const Z_STREAM_END: c_int = 1;
const Z_DEFLATED: c_int = 8;
const Z_DEFAULT_STRATEGY: c_int = 0;
const Z_HUFFMAN_ONLY: c_int = 2;
const Z_RLE: c_int = 3;

#[repr(C)]
struct ZStream {
    next_in: *mut u8,
    avail_in: c_uint,
    total_in: c_ulong,
    next_out: *mut u8,
    avail_out: c_uint,
    total_out: c_ulong,
    msg: *mut c_char,
    state: *mut c_void,
    zalloc: Option<unsafe extern "C" fn(*mut c_void, c_uint, c_uint) -> *mut c_void>,
    zfree: Option<unsafe extern "C" fn(*mut c_void, *mut c_void)>,
    opaque: *mut c_void,
    data_type: c_int,
    adler: c_ulong,
    reserved: c_ulong,
}

impl Default for ZStream {
    fn default() -> Self {
        ZStream {
            next_in: std::ptr::null_mut(), avail_in: 0, total_in: 0,
            next_out: std::ptr::null_mut(), avail_out: 0, total_out: 0,
            msg: std::ptr::null_mut(), state: std::ptr::null_mut(),
            zalloc: None, zfree: None, opaque: std::ptr::null_mut(),
            data_type: 0, adler: 0, reserved: 0,
        }
    }
}

#[link(name = "z")]
extern "C" {
    fn zlibVersion() -> *const c_char;
    fn deflateInit2_(strm: *mut ZStream, level: c_int, method: c_int, window_bits: c_int,
                     mem_level: c_int, strategy: c_int, version: *const c_char, stream_size: c_int) -> c_int;
    fn deflate(strm: *mut ZStream, flush: c_int) -> c_int;
    fn deflateEnd(strm: *mut ZStream) -> c_int;
    fn inflateInit2_(strm: *mut ZStream, window_bits: c_int, version: *const c_char, stream_size: c_int) -> c_int;
    fn inflate(strm: *mut ZStream, flush: c_int) -> c_int;
    fn inflateEnd(strm: *mut ZStream) -> c_int;
}

#[derive(Clone, Copy, PartialEq)]
enum Format { Gzip, Zlib, Zip }

#[derive(Clone)]
struct Opts {
    decompress: bool, stdout: bool, keep: bool, force: bool, test: bool, list: bool,
    verbose: u32, quiet: bool, recursive: bool, format: Format, suffix: String,
    level: i32, name: bool, time: bool, comment: Option<String>, alias: Option<String>,
    strategy: c_int, files: Vec<String>, program: String,
}

impl Default for Opts {
    fn default() -> Self {
        Opts { decompress: false, stdout: false, keep: false, force: false, test: false, list: false,
            verbose: 0, quiet: false, recursive: false, format: Format::Gzip, suffix: ".gz".into(),
            level: 6, name: true, time: true, comment: None, alias: None, strategy: Z_DEFAULT_STRATEGY,
            files: Vec::new(), program: "pigz".into() }
    }
}

fn zver() -> *const c_char { unsafe { zlibVersion() } }

fn deflate_data(input: &[u8], level: i32, window_bits: c_int, strategy: c_int) -> Result<Vec<u8>, String> {
    unsafe {
        let mut s = ZStream::default();
        let ret = deflateInit2_(&mut s, level as c_int, Z_DEFLATED, window_bits, 8, strategy, zver(), std::mem::size_of::<ZStream>() as c_int);
        if ret != Z_OK { return Err(format!("deflateInit2 failed: {}", ret)); }
        s.next_in = input.as_ptr() as *mut u8;
        s.avail_in = input.len() as c_uint;
        let mut out = Vec::with_capacity(input.len() / 2 + 128);
        let mut buf = [0u8; 32768];
        loop {
            s.next_out = buf.as_mut_ptr();
            s.avail_out = buf.len() as c_uint;
            let r = deflate(&mut s, Z_FINISH);
            let have = buf.len() - s.avail_out as usize;
            out.extend_from_slice(&buf[..have]);
            if r == Z_STREAM_END { break; }
            if r != Z_OK { deflateEnd(&mut s); return Err(format!("deflate failed: {}", r)); }
        }
        deflateEnd(&mut s);
        Ok(out)
    }
}

fn inflate_data(input: &[u8], window_bits: c_int) -> Result<Vec<u8>, String> {
    unsafe {
        let mut s = ZStream::default();
        let ret = inflateInit2_(&mut s, window_bits, zver(), std::mem::size_of::<ZStream>() as c_int);
        if ret != Z_OK { return Err(format!("inflateInit2 failed: {}", ret)); }
        s.next_in = input.as_ptr() as *mut u8;
        s.avail_in = input.len() as c_uint;
        let mut out = Vec::new();
        let mut buf = [0u8; 32768];
        loop {
            s.next_out = buf.as_mut_ptr();
            s.avail_out = buf.len() as c_uint;
            let r = inflate(&mut s, Z_NO_FLUSH);
            let have = buf.len() - s.avail_out as usize;
            out.extend_from_slice(&buf[..have]);
            if r == Z_STREAM_END { break; }
            if r != Z_OK { inflateEnd(&mut s); return Err("corrupt input".into()); }
            if have == 0 && s.avail_in == 0 { inflateEnd(&mut s); return Err("unexpected end of file".into()); }
        }
        inflateEnd(&mut s);
        Ok(out)
    }
}

fn crc32(bytes: &[u8]) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for &b in bytes {
        crc ^= b as u32;
        for _ in 0..8 { crc = if crc & 1 != 0 { (crc >> 1) ^ 0xedb8_8320 } else { crc >> 1 }; }
    }
    !crc
}

fn unix_time(meta: Option<&fs::Metadata>) -> u32 { meta.map(|m| m.mtime().max(0) as u32).unwrap_or(0) }
fn put_u16(v: &mut Vec<u8>, x: u16) { v.extend_from_slice(&x.to_le_bytes()); }
fn put_u32(v: &mut Vec<u8>, x: u32) { v.extend_from_slice(&x.to_le_bytes()); }

fn base_name(path: &str) -> String {
    Path::new(path).file_name().and_then(|s| s.to_str()).unwrap_or(path).to_string()
}

fn gzip_compress(data: &[u8], name: Option<&str>, meta: Option<&fs::Metadata>, opts: &Opts) -> Result<Vec<u8>, String> {
    let mut out = vec![0x1f, 0x8b, 8, 0];
    let mut flags = 0u8;
    if opts.name && name.is_some() { flags |= 8; }
    if opts.comment.is_some() { flags |= 16; }
    out[3] = flags;
    put_u32(&mut out, if opts.time { unix_time(meta) } else { 0 });
    out.push(if opts.level == 9 { 2 } else if opts.level == 1 { 4 } else { 0 });
    out.push(3);
    if let Some(n) = name.filter(|_| opts.name) { out.extend_from_slice(n.as_bytes()); out.push(0); }
    if let Some(c) = &opts.comment { out.extend_from_slice(c.as_bytes()); out.push(0); }
    out.extend(deflate_data(data, opts.level, -15, opts.strategy)?);
    put_u32(&mut out, crc32(data));
    put_u32(&mut out, data.len() as u32);
    Ok(out)
}

fn zlib_compress(data: &[u8], opts: &Opts) -> Result<Vec<u8>, String> {
    deflate_data(data, opts.level, 15, opts.strategy)
}

fn dos_time_date(meta: Option<&fs::Metadata>) -> (u16, u16) {
    let t = unix_time(meta) as i64;
    let (mut days, rem) = (t.div_euclid(86400), t.rem_euclid(86400));
    let hour = (rem / 3600) as u16; let min = ((rem % 3600) / 60) as u16; let sec = (rem % 60) as u16;
    let mut year = 1970;
    loop { let leap = (year % 4 == 0 && year % 100 != 0) || year % 400 == 0; let yd = if leap {366} else {365}; if days < yd { break; } days -= yd; year += 1; }
    let mdays = [31, if (year % 4 == 0 && year % 100 != 0) || year % 400 == 0 {29} else {28},31,30,31,30,31,31,30,31,30,31];
    let mut mon = 1; for d in mdays { if days < d { break; } days -= d; mon += 1; }
    let day = days as u16 + 1;
    let dt = ((hour & 31) << 11) | ((min & 63) << 5) | ((sec / 2) & 31);
    let dd = (((year - 1980).max(0) as u16) << 9) | ((mon as u16) << 5) | day;
    (dt, dd)
}

fn zip_compress(data: &[u8], entry: &str, meta: Option<&fs::Metadata>, opts: &Opts) -> Result<Vec<u8>, String> {
    let comp = deflate_data(data, opts.level, -15, opts.strategy)?;
    let crc = crc32(data); let (dt, dd) = dos_time_date(meta); let name = entry.as_bytes();
    let mut out = Vec::new();
    put_u32(&mut out, 0x04034b50); put_u16(&mut out, 20); put_u16(&mut out, 0); put_u16(&mut out, 8);
    put_u16(&mut out, dt); put_u16(&mut out, dd); put_u32(&mut out, crc); put_u32(&mut out, comp.len() as u32); put_u32(&mut out, data.len() as u32);
    put_u16(&mut out, name.len() as u16); put_u16(&mut out, 0); out.extend_from_slice(name); out.extend_from_slice(&comp);
    let central = out.len() as u32;
    put_u32(&mut out, 0x02014b50); put_u16(&mut out, 0x031e); put_u16(&mut out, 20); put_u16(&mut out, 0); put_u16(&mut out, 8);
    put_u16(&mut out, dt); put_u16(&mut out, dd); put_u32(&mut out, crc); put_u32(&mut out, comp.len() as u32); put_u32(&mut out, data.len() as u32);
    put_u16(&mut out, name.len() as u16); put_u16(&mut out, 0); put_u16(&mut out, 0); put_u16(&mut out, 0); put_u16(&mut out, 0); put_u32(&mut out, 0); put_u32(&mut out, 0);
    out.extend_from_slice(name);
    let csize = out.len() as u32 - central;
    put_u32(&mut out, 0x06054b50); put_u16(&mut out, 0); put_u16(&mut out, 0); put_u16(&mut out, 1); put_u16(&mut out, 1); put_u32(&mut out, csize); put_u32(&mut out, central); put_u16(&mut out, 0);
    Ok(out)
}

fn zip_decompress(input: &[u8]) -> Result<(Vec<u8>, Option<String>), String> {
    if input.len() < 30 || &input[..4] != b"PK\x03\x04" { return Err("not a zip file".into()); }
    let method = u16::from_le_bytes([input[8], input[9]]);
    let nlen = u16::from_le_bytes([input[26], input[27]]) as usize;
    let xlen = u16::from_le_bytes([input[28], input[29]]) as usize;
    let start = 30 + nlen + xlen;
    if input.len() < start { return Err("bad zip header".into()); }
    let name = String::from_utf8_lossy(&input[30..30+nlen]).to_string();
    let mut end = input.len();
    for i in start..input.len().saturating_sub(3) { if &input[i..i+4] == b"PK\x01\x02" || &input[i..i+4] == b"PK\x07\x08" { end = i; break; } }
    let payload = &input[start..end];
    let out = if method == 0 { payload.to_vec() } else if method == 8 { inflate_data(payload, -15)? } else { return Err("unsupported zip method".into()); };
    Ok((out, Some(name)))
}

fn gzip_name(input: &[u8]) -> Option<String> {
    if input.len() < 10 || input[0] != 0x1f || input[1] != 0x8b { return None; }
    let flg = input[3]; let mut p = 10usize;
    if flg & 4 != 0 { if p + 2 > input.len() { return None; } let x = u16::from_le_bytes([input[p], input[p+1]]) as usize; p += 2 + x; }
    if flg & 8 != 0 { let s = p; while p < input.len() && input[p] != 0 { p += 1; } return Some(String::from_utf8_lossy(&input[s..p]).to_string()); }
    None
}

fn decompress_bytes(input: &[u8]) -> Result<(Vec<u8>, Option<String>), String> {
    if input.starts_with(b"PK\x03\x04") { zip_decompress(input) } else { Ok((inflate_data(input, 47)?, gzip_name(input))) }
}

fn usage() { print!("Usage: pigz [options] [files ...]\n  will compress files in place, adding the suffix '.gz'. If no files are\n  specified, stdin will be compressed to stdout. pigz does what gzip does,\n  but spreads the work over multiple processors and cores when compressing.\n\nOptions:\n  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)\n  --fast, --best       Compression levels 1 and 9 respectively\n  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin\n  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)\n  -c, --stdout         Write all processed output to stdout (won't delete)\n  -C, --comment ccc    Put comment ccc in the gzip or zip header\n  -d, --decompress     Decompress the compressed input\n  -f, --force          Force overwrite, compress .gz, links, and to terminal\n  -F  --first          Do iterations first, before block split for -11\n  -h, --help           Display a help screen and quit\n  -H, --huffman        Use only Huffman coding for compression\n  -i, --independent    Compress blocks independently for damage recovery\n  -I, --iterations n   Number of iterations for -11 optimization\n  -J, --maxsplits n    Maximum number of split blocks for -11\n  -k, --keep           Do not delete original file after processing\n  -K, --zip            Compress to PKWare zip (.zip) single entry format\n  -l, --list           List the contents of the compressed input\n  -L, --license        Display the pigz license and quit\n  -m, --no-time        Do not store or restore mod time\n  -M, --time           Store or restore mod time\n  -n, --no-name        Do not store or restore file name or mod time\n  -N, --name           Store or restore file name and mod time\n  -O  --oneblock       Do not split into smaller blocks for -11\n  -p, --processes n    Allow up to n compression threads (default is the\n                       number of online processors, or 8 if unknown)\n  -q, --quiet          Print no messages, even on error\n  -r, --recursive      Process the contents of all subdirectories\n  -R, --rsyncable      Input-determined block locations for rsync\n  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)\n  -t, --test           Test the integrity of the compressed input\n  -U, --rle            Use run-length encoding for compression\n  -v, --verbose        Provide more verbose output\n  -V  --version        Show the version of pigz\n  -Y  --synchronous    Force output file write to permanent storage\n  -z, --zlib           Compress to zlib (.zz) instead of gzip format\n  --                   All arguments after \"--\" are treated as files\n"); }
fn license() { println!("pigz 2.8\nCopyright (C) 2007-2023 Mark Adler\nSubject to the terms of the zlib license.\nNo warranty is provided or implied."); }

fn tokenize_env(s: &str) -> Vec<String> { s.split_whitespace().map(|x| x.to_string()).collect() }

fn parse_args() -> Result<Option<Opts>, i32> {
    let mut opts = Opts::default();
    opts.program = env::args().next().and_then(|p| Path::new(&p).file_name().map(|s| s.to_string_lossy().into_owned())).unwrap_or("pigz".into());
    if opts.program.contains("unpigz") { opts.decompress = true; }
    let mut args = Vec::new();
    if let Ok(s) = env::var("GZIP") { args.extend(tokenize_env(&s)); }
    if let Ok(s) = env::var("PIGZ") { args.extend(tokenize_env(&s)); }
    args.extend(env::args().skip(1));
    let mut i = 0; let mut files_only = false;
    while i < args.len() {
        let a = args[i].clone(); i += 1;
        if files_only || !a.starts_with('-') || a == "-" { opts.files.push(a); continue; }
        if a == "--" { files_only = true; continue; }
        match a.as_str() {
            "--help" => { usage(); return Err(0); }, "--version" => { print_version(opts.verbose); return Err(0); },
            "--license" => { license(); return Err(0); }, "--fast" => opts.level = 1, "--best" => opts.level = 9,
            "--stdout"|"--to-stdout" => opts.stdout = true, "--decompress"|"--uncompress" => opts.decompress = true,
            "--force" => opts.force = true, "--keep" => opts.keep = true, "--zip" => { opts.format = Format::Zip; opts.suffix = ".zip".into(); },
            "--zlib" => { opts.format = Format::Zlib; opts.suffix = ".zz".into(); }, "--test" => opts.test = true,
            "--list" => opts.list = true, "--verbose" => opts.verbose += 1, "--quiet"|"--silent" => opts.quiet = true,
            "--recursive" => opts.recursive = true, "--no-name" => { opts.name = false; opts.time = false; },
            "--name" => { opts.name = true; opts.time = true; }, "--no-time" => opts.time = false, "--time" => opts.time = true,
            "--huffman" => opts.strategy = Z_HUFFMAN_ONLY, "--rle" => opts.strategy = Z_RLE,
            "--alias"|"--comment"|"--blocksize"|"--processes"|"--suffix"|"--iterations"|"--maxsplits" => {
                if i >= args.len() { eprintln!("{}: abort: option {} requires argument", opts.program, a); return Err(22); }
                let val = args[i].clone(); i += 1;
                match a.as_str() { "--alias" => opts.alias = Some(val), "--comment" => opts.comment = Some(val), "--suffix" => opts.suffix = val, _ => {} }
            }
            "--independent"|"--rsyncable"|"--first"|"--oneblock"|"--synchronous" => {}
            _ if a.starts_with("--") => { eprintln!("{}: abort: invalid option: {}", opts.program, a); return Err(22); }
            _ => parse_short(&a, &args, &mut i, &mut opts)?,
        }
    }
    Ok(Some(opts))
}

fn need_arg(args: &[String], i: &mut usize, opt: char, prog: &str) -> Result<String, i32> {
    if *i >= args.len() { eprintln!("{}: abort: option -{} requires argument", prog, opt); Err(22) } else { let v = args[*i].clone(); *i += 1; Ok(v) }
}
fn parse_short(a: &str, args: &[String], i: &mut usize, opts: &mut Opts) -> Result<(), i32> {
    let cs: Vec<char> = a[1..].chars().collect(); let mut j = 0;
    while j < cs.len() {
        let c = cs[j]; j += 1;
        match c {
            '0'..='9' => { if c == '1' && j < cs.len() && cs[j] == '1' { opts.level = 9; j += 1; } else { opts.level = c.to_digit(10).unwrap() as i32; } }
            'A'|'b'|'C'|'I'|'J'|'p'|'S' => { let val = if j < cs.len() { let s: String = cs[j..].iter().collect(); j = cs.len(); s } else { need_arg(args, i, c, &opts.program)? }; match c { 'A' => opts.alias = Some(val), 'C' => opts.comment = Some(val), 'S' => opts.suffix = val, _ => {} } }
            'c' => opts.stdout = true, 'd' => opts.decompress = true, 'f' => opts.force = true, 'h' => { usage(); return Err(0); },
            'H' => opts.strategy = Z_HUFFMAN_ONLY, 'i'|'R'|'F'|'O'|'Y' => {}, 'k' => opts.keep = true,
            'K' => { opts.format = Format::Zip; opts.suffix = ".zip".into(); }, 'l' => opts.list = true,
            'L' => { license(); return Err(0); }, 'm' => opts.time = false, 'M' => opts.time = true,
            'n' => { opts.name = false; opts.time = false; }, 'N' => { opts.name = true; opts.time = true; },
            'q' => opts.quiet = true, 'r' => opts.recursive = true, 't' => opts.test = true,
            'U' => opts.strategy = Z_RLE, 'v' => opts.verbose += 1, 'V' => { print_version(opts.verbose); return Err(0); },
            'z' => { opts.format = Format::Zlib; opts.suffix = ".zz".into(); },
            _ => { eprintln!("{}: abort: invalid option: -{}", opts.program, c); return Err(22); }
        }
    }
    Ok(())
}
fn print_version(verbose: u32) { println!("pigz 2.8"); if verbose > 0 { unsafe { println!("zlib {}", CStr::from_ptr(zver()).to_string_lossy()); } } }

fn read_all(path: Option<&Path>) -> io::Result<Vec<u8>> {
    let mut v = Vec::new();
    match path { Some(p) => File::open(p)?.read_to_end(&mut v)?, None => io::stdin().read_to_end(&mut v)? };
    Ok(v)
}

fn output_name_compress(input: &str, opts: &Opts) -> PathBuf { PathBuf::from(format!("{}{}", input, opts.suffix)) }
fn output_name_decompress(input: &str, embedded: Option<String>, opts: &Opts) -> PathBuf {
    if opts.name { if let Some(n) = embedded.filter(|s| !s.is_empty()) { return PathBuf::from(n); } }
    for suf in [opts.suffix.as_str(), ".gz", ".zz", ".zip", ".z"] { if input.ends_with(suf) { return PathBuf::from(&input[..input.len()-suf.len()]); } }
    PathBuf::from(format!("{}.out", input))
}

fn process_stdin(opts: &Opts) -> Result<(), String> {
    let data = read_all(None).map_err(|e| e.to_string())?;
    if opts.decompress || opts.test {
        let (out, _) = decompress_bytes(&data)?;
        if !opts.test { io::stdout().write_all(&out).map_err(|e| e.to_string())?; }
    } else {
        let name = opts.alias.as_deref().unwrap_or("-");
        let out = match opts.format { Format::Gzip => gzip_compress(&data, Some(name), None, opts)?, Format::Zlib => zlib_compress(&data, opts)?, Format::Zip => zip_compress(&data, name, None, opts)? };
        io::stdout().write_all(&out).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn list_file(path: &str, opts: &Opts) -> Result<(), String> {
    let data = read_all(Some(Path::new(path))).map_err(|e| e.to_string())?;
    let (out, name) = decompress_bytes(&data)?;
    let nm = name.unwrap_or_else(|| path.trim_end_matches(".gz").to_string());
    if opts.verbose > 0 { println!("method    check    timestamp    compressed   original reduced  name"); println!("gzip 8  {:08x}  ????         {:>11} {:>10}   0.0%  {}", crc32(&out), data.len(), out.len(), nm); }
    else { println!("compressed   original reduced  name"); println!("{:>10} {:>10}   0.0%  {}", data.len(), out.len(), nm); }
    Ok(())
}

fn process_file(path: &str, opts: &Opts) -> Result<(), String> {
    let p = Path::new(path);
    if !p.exists() { return Err(format!("skipping: {} does not exist", path)); }
    let meta = fs::metadata(p).map_err(|e| e.to_string())?;
    if meta.is_dir() {
        if !opts.recursive { return Err(format!("skipping: {} is a directory", path)); }
        for ent in fs::read_dir(p).map_err(|e| e.to_string())? { let ep = ent.map_err(|e| e.to_string())?.path(); process_file(&ep.to_string_lossy(), opts)?; }
        return Ok(());
    }
    if opts.list { return list_file(path, opts); }
    let data = read_all(Some(p)).map_err(|e| e.to_string())?;
    if opts.decompress || opts.test {
        if opts.decompress && !opts.stdout && ![".gz", ".zz", ".zip", ".z"].iter().any(|s| path.ends_with(s)) {
            return Err(format!("skipping: {} does not have compressed suffix", path));
        }
        let (out, embedded) = decompress_bytes(&data)?;
        if opts.test { if opts.verbose > 0 && !opts.quiet { eprintln!("{} OK", path); } return Ok(()); }
        if opts.stdout { io::stdout().write_all(&out).map_err(|e| e.to_string())?; return Ok(()); }
        let op = output_name_decompress(path, embedded, opts);
        if op.exists() && !opts.force { return Err(format!("skipping: {} exists", op.display())); }
        fs::write(&op, out).map_err(|e| e.to_string())?;
        if !opts.keep { let _ = fs::remove_file(p); }
    } else {
        if path.ends_with(&opts.suffix) && !opts.force { return Err(format!("skipping: {} already has {} suffix", path, opts.suffix)); }
        let name = Some(base_name(path));
        let out = match opts.format { Format::Gzip => gzip_compress(&data, name.as_deref(), Some(&meta), opts)?, Format::Zlib => zlib_compress(&data, opts)?, Format::Zip => zip_compress(&data, &name.unwrap(), Some(&meta), opts)? };
        if opts.stdout { io::stdout().write_all(&out).map_err(|e| e.to_string())?; return Ok(()); }
        let op = output_name_compress(path, opts);
        if op.exists() && !opts.force { return Err(format!("skipping: {} exists", op.display())); }
        fs::write(&op, out).map_err(|e| e.to_string())?;
        if !opts.keep { let _ = fs::remove_file(p); }
    }
    Ok(())
}

fn main() {
    let opts = match parse_args() { Ok(Some(o)) => o, Err(code) => std::process::exit(code), _ => unreachable!() };
    let mut status = 0;
    if opts.files.is_empty() { if let Err(e) = process_stdin(&opts) { if !opts.quiet { eprintln!("{}: abort: {}", opts.program, e); } status = 1; } }
    else {
        for f in &opts.files { if f == "-" { if let Err(e) = process_stdin(&opts) { if !opts.quiet { eprintln!("{}: abort: {}", opts.program, e); } status = 1; } } else if let Err(e) = process_file(f, &opts) { if !opts.quiet { eprintln!("{}: {}", opts.program, e); } status = 1; } }
    }
    std::process::exit(status);
}
