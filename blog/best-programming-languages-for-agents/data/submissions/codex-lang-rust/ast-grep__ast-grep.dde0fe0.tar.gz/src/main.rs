use regex::Regex;
use serde_json::json;
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

const VERSION: &str = "ast-grep 0.42.1";

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        print_top_help();
        return;
    }
    if args[0] == "--version" || args[0] == "-V" {
        println!("{VERSION}");
        return;
    }
    if args[0] == "--help" || args[0] == "-h" {
        print_top_help();
        return;
    }
    if args[0] == "-c" || args[0] == "--config" {
        if args.len() > 1 {
            args.drain(0..2);
        }
    }
    let cmd = match args.first().map(String::as_str) {
        Some("run") | Some("scan") | Some("test") | Some("new") | Some("lsp") | Some("completions") | Some("help") => args.remove(0),
        _ => "run".to_string(),
    };
    let code = match cmd.as_str() {
        "run" => run_command(&args, None),
        "scan" => scan_command(&args),
        "test" => test_command(&args),
        "new" => new_command(&args),
        "lsp" => {
            eprintln!("Starting ast-grep language server is not supported in this reimplementation.");
            1
        }
        "completions" => completions_command(&args),
        "help" => {
            print_top_help();
            0
        }
        _ => 1,
    };
    std::process::exit(code);
}

#[derive(Clone, Debug)]
struct Opts {
    pattern: Option<String>,
    rewrite: Option<String>,
    lang: Option<String>,
    paths: Vec<String>,
    stdin: bool,
    update_all: bool,
    files_with_matches: bool,
    json: Option<String>,
    before: usize,
    after: usize,
    heading: String,
    color: String,
    debug_query: Option<String>,
    max_results: Option<usize>,
    report_style: Option<String>,
}

impl Default for Opts {
    fn default() -> Self {
        Self {
            pattern: None,
            rewrite: None,
            lang: None,
            paths: vec![],
            stdin: false,
            update_all: false,
            files_with_matches: false,
            json: None,
            before: 0,
            after: 0,
            heading: "auto".to_string(),
            color: "auto".to_string(),
            debug_query: None,
            max_results: None,
            report_style: None,
        }
    }
}

#[derive(Clone, Debug)]
struct Rule {
    id: String,
    language: Option<String>,
    message: String,
    severity: String,
    pattern: String,
    fix: Option<String>,
}

#[derive(Clone, Debug)]
struct CompiledPattern {
    regex: Regex,
    vars: Vec<String>,
}

#[derive(Clone, Debug)]
struct Found {
    text: String,
    file: String,
    start: usize,
    end: usize,
    line: usize,
    column: usize,
    end_line: usize,
    end_column: usize,
    line_text: String,
    leading: usize,
    trailing: usize,
    vars: BTreeMap<String, VarMatch>,
    replacement: Option<String>,
    language: String,
    rule: Option<RuleLite>,
}

#[derive(Clone, Debug)]
struct VarMatch {
    text: String,
    start: usize,
    end: usize,
    line: usize,
    column: usize,
}

#[derive(Clone, Debug)]
struct RuleLite {
    id: String,
    severity: String,
    message: String,
}

fn run_command(args: &[String], forced_rule: Option<Rule>) -> i32 {
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_run_help();
        return 0;
    }
    let mut opts = parse_run_args(args);
    if let Some(rule) = forced_rule.clone() {
        opts.pattern = Some(rule.pattern);
        if opts.lang.is_none() {
            opts.lang = rule.language;
        }
        if opts.rewrite.is_none() {
            opts.rewrite = rule.fix;
        }
    }
    let Some(pattern) = opts.pattern.clone() else {
        eprintln!("error: the following required arguments were not provided:\n  --pattern <PATTERN>\n\nUsage: executable run --pattern <PATTERN> [PATHS]...");
        return 2;
    };
    let cp = match compile_pattern(&pattern) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("error: {e}");
            return 1;
        }
    };
    if let Some(fmt) = opts.debug_query.clone() {
        println!("pattern: {pattern}");
        if fmt == "sexp" {
            println!("({})", pattern.replace(' ', " "));
        }
        return 0;
    }
    let inputs = match collect_inputs(&opts) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("{e}");
            return 1;
        }
    };
    let mut all = Vec::new();
    for (display, content, writable) in inputs {
        let lang = opts.lang.clone().unwrap_or_else(|| language_for_path(&display));
        let mut matches = find_matches(&cp, &content, &display, &lang, opts.rewrite.as_deref(), forced_rule.as_ref());
        if let Some(max) = opts.max_results {
            let remaining = max.saturating_sub(all.len());
            matches.truncate(remaining);
        }
        if opts.update_all && opts.rewrite.is_some() && writable {
            let rewritten = apply_replacements(&content, &matches);
            if rewritten != content {
                let _ = fs::write(&display, rewritten);
            }
        }
        all.extend(matches);
        if let Some(max) = opts.max_results {
            if all.len() >= max {
                break;
            }
        }
    }
    if opts.update_all && opts.rewrite.is_some() {
        println!("Applied {} changes", all.len());
        return 0;
    }
    if opts.files_with_matches {
        let mut prev = String::new();
        for m in &all {
            if m.file != prev {
                println!("{}", m.file);
                prev = m.file.clone();
            }
        }
        return if all.is_empty() { 1 } else { 0 };
    }
    if let Some(style) = opts.json.as_deref() {
        print_json(&all, style, forced_rule.is_some());
        return if all.is_empty() { 1 } else { 0 };
    }
    if forced_rule.is_some() && matches!(opts.report_style.as_deref(), Some("short") | Some("medium")) {
        print_scan_short(&all);
        return if all.is_empty() { 0 } else { 0 };
    }
    if opts.rewrite.is_some() {
        if forced_rule.is_some() {
            print_scan_diff(&all);
        } else {
            let mut grouped: BTreeMap<String, Vec<Found>> = BTreeMap::new();
            for m in all.clone() {
                grouped.entry(m.file.clone()).or_default().push(m);
            }
            for (file, ms) in grouped {
                println!("{file}");
                print_file_diff(&ms);
            }
        }
    } else {
        print_text_matches(&all, &opts);
    }
    if all.is_empty() { 1 } else { 0 }
}

fn parse_run_args(args: &[String]) -> Opts {
    let mut o = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-p" | "--pattern" => {
                i += 1;
                o.pattern = args.get(i).cloned();
            }
            "-r" | "--rewrite" => {
                i += 1;
                o.rewrite = args.get(i).cloned();
            }
            "-l" | "--lang" => {
                i += 1;
                o.lang = args.get(i).cloned();
            }
            "--stdin" => o.stdin = true,
            "-U" | "--update-all" => o.update_all = true,
            "--files-with-matches" => o.files_with_matches = true,
            "--json" => o.json = Some("pretty".to_string()),
            "-A" | "--after" => {
                i += 1;
                o.after = args.get(i).and_then(|s| s.parse().ok()).unwrap_or(0);
            }
            "-B" | "--before" => {
                i += 1;
                o.before = args.get(i).and_then(|s| s.parse().ok()).unwrap_or(0);
            }
            "-C" | "--context" => {
                i += 1;
                let n = args.get(i).and_then(|s| s.parse().ok()).unwrap_or(0);
                o.before = n;
                o.after = n;
            }
            "--heading" => {
                i += 1;
                o.heading = args.get(i).cloned().unwrap_or_else(|| "auto".to_string());
            }
            "--report-style" => {
                i += 1;
                o.report_style = args.get(i).cloned();
            }
            "--color" => {
                i += 1;
                o.color = args.get(i).cloned().unwrap_or_else(|| "auto".to_string());
            }
            "--debug-query" => o.debug_query = Some("pattern".to_string()),
            "--max-results" | "-j" | "--threads" | "--selector" | "--strictness" | "--globs" | "--no-ignore" | "-c" | "--config" | "--inspect" => {
                i += 1;
            }
            "-i" | "--interactive" | "--follow" => {}
            _ if a.starts_with("--json=") => o.json = Some(a[7..].to_string()),
            _ if a.starts_with("--debug-query=") => o.debug_query = Some(a[14..].to_string()),
            _ if a.starts_with("--max-results=") => o.max_results = a[14..].parse().ok(),
            _ if a.starts_with('-') => {}
            _ => o.paths.push(a.clone()),
        }
        i += 1;
    }
    if o.paths.is_empty() && !o.stdin {
        o.paths.push(".".to_string());
    }
    o
}

fn collect_inputs(opts: &Opts) -> Result<Vec<(String, String, bool)>, String> {
    if opts.stdin {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        return Ok(vec![("STDIN".to_string(), s, false)]);
    }
    let mut out = Vec::new();
    for p in &opts.paths {
        let path = PathBuf::from(p);
        if path.is_dir() {
            visit_dir(&path, &mut out)?;
        } else {
            let s = fs::read_to_string(&path).map_err(|e| format!("{}: {e}", path.display()))?;
            out.push((p.clone(), s, true));
        }
    }
    Ok(out)
}

fn visit_dir(path: &Path, out: &mut Vec<(String, String, bool)>) -> Result<(), String> {
    let entries = fs::read_dir(path).map_err(|e| format!("{}: {e}", path.display()))?;
    for entry in entries.flatten() {
        let p = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();
        if name.starts_with('.') || name == "target" || name == "submission.tar.gz" {
            continue;
        }
        if p.is_dir() {
            visit_dir(&p, out)?;
        } else if is_source_file(&p) {
            if let Ok(s) = fs::read_to_string(&p) {
                out.push((p.to_string_lossy().to_string(), s, true));
            }
        }
    }
    Ok(())
}

fn is_source_file(p: &Path) -> bool {
    matches!(p.extension().and_then(|e| e.to_str()).unwrap_or(""),
        "js"|"jsx"|"ts"|"tsx"|"py"|"rs"|"go"|"java"|"c"|"h"|"cpp"|"cc"|"hpp"|"rb"|"php"|"cs"|"json"|"yaml"|"yml"|"html"|"css"|"sh"|"kt"|"swift"|"dart"|"lua"|"scala"|"hs"|"ex"|"exs")
}

fn compile_pattern(pattern: &str) -> Result<CompiledPattern, regex::Error> {
    let mut rx = String::new();
    let mut vars = Vec::new();
    let chars: Vec<char> = pattern.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '$' && i + 1 < chars.len() && (chars[i + 1].is_ascii_uppercase() || chars[i + 1] == '_') {
            let mut j = i + 1;
            while j < chars.len() && (chars[j].is_ascii_uppercase() || chars[j].is_ascii_digit() || chars[j] == '_') {
                j += 1;
            }
            let name: String = chars[i + 1..j].iter().collect();
            if !vars.contains(&name) {
                vars.push(name.clone());
                rx.push_str(&format!("(?P<{name}>[\\s\\S]*?)"));
            } else {
                rx.push_str("[\\s\\S]*?");
            }
            i = j;
        } else if chars[i].is_whitespace() {
            rx.push_str(r"\s+");
            i += 1;
        } else {
            rx.push_str(&regex::escape(&chars[i].to_string()));
            i += 1;
        }
    }
    let bounded = format!(r"(?m){rx}");
    Ok(CompiledPattern { regex: Regex::new(&bounded)?, vars })
}

fn find_matches(cp: &CompiledPattern, content: &str, file: &str, lang: &str, rewrite: Option<&str>, rule: Option<&Rule>) -> Vec<Found> {
    let mut out = Vec::new();
    for caps in cp.regex.captures_iter(content) {
        let Some(m) = caps.get(0) else { continue; };
        if m.start() == m.end() {
            continue;
        }
        let (line, col) = line_col(content, m.start());
        let (end_line, end_col) = line_col(content, m.end());
        let line_text = content.lines().nth(line).unwrap_or("").to_string();
        let line_start = content[..m.start()].rfind('\n').map(|v| v + 1).unwrap_or(0);
        let line_end = content[m.end()..].find('\n').map(|v| m.end() + v).unwrap_or(content.len());
        let mut vars = BTreeMap::new();
        for v in &cp.vars {
            if let Some(vm) = caps.name(v) {
                let (vl, vc) = line_col(content, vm.start());
                vars.insert(v.clone(), VarMatch { text: vm.as_str().to_string(), start: vm.start(), end: vm.end(), line: vl, column: vc });
            }
        }
        let replacement = rewrite.map(|r| expand_rewrite(r, &vars));
        out.push(Found {
            text: m.as_str().to_string(),
            file: file.to_string(),
            start: m.start(),
            end: m.end(),
            line,
            column: col,
            end_line,
            end_column: end_col,
            line_text,
            leading: m.start().saturating_sub(line_start),
            trailing: line_end.saturating_sub(m.end()),
            vars,
            replacement,
            language: normalize_lang(lang),
            rule: rule.map(|r| RuleLite { id: r.id.clone(), severity: r.severity.clone(), message: r.message.clone() }),
        });
    }
    out
}

fn line_col(s: &str, idx: usize) -> (usize, usize) {
    let mut line = 0;
    let mut last = 0;
    for (i, b) in s.bytes().enumerate() {
        if i >= idx { break; }
        if b == b'\n' {
            line += 1;
            last = i + 1;
        }
    }
    (line, idx.saturating_sub(last))
}

fn expand_rewrite(tpl: &str, vars: &BTreeMap<String, VarMatch>) -> String {
    let mut out = String::new();
    let chars: Vec<char> = tpl.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '$' && i + 1 < chars.len() && (chars[i + 1].is_ascii_uppercase() || chars[i + 1] == '_') {
            let mut j = i + 1;
            while j < chars.len() && (chars[j].is_ascii_uppercase() || chars[j].is_ascii_digit() || chars[j] == '_') {
                j += 1;
            }
            let name: String = chars[i + 1..j].iter().collect();
            if let Some(v) = vars.get(&name) {
                out.push_str(&v.text);
            }
            i = j;
        } else {
            out.push(chars[i]);
            i += 1;
        }
    }
    out
}

fn apply_replacements(content: &str, matches: &[Found]) -> String {
    let mut sorted = matches.to_vec();
    sorted.sort_by_key(|m| m.start);
    let mut out = String::new();
    let mut pos = 0;
    for m in sorted {
        if m.start < pos { continue; }
        out.push_str(&content[pos..m.start]);
        out.push_str(m.replacement.as_deref().unwrap_or(&m.text));
        pos = m.end;
    }
    out.push_str(&content[pos..]);
    out
}

fn print_text_matches(matches: &[Found], opts: &Opts) {
    for m in matches {
        if opts.before == 0 && opts.after == 0 {
            println!("{}:{}:{}", m.file, m.line + 1, m.line_text);
        } else if let Ok(content) = fs::read_to_string(&m.file) {
            let lines: Vec<&str> = content.lines().collect();
            let start = m.line.saturating_sub(opts.before);
            let end = usize::min(lines.len(), m.line + opts.after + 1);
            for idx in start..end {
                let sep = if idx == m.line { ":" } else { "-" };
                println!("{}{}{}:{}", m.file, sep, idx + 1, lines[idx]);
            }
        } else {
            println!("{}:{}:{}", m.file, m.line + 1, m.line_text);
        }
    }
}

fn print_json(matches: &[Found], style: &str, scan: bool) {
    let vals: Vec<_> = matches.iter().map(|m| json_match(m, scan)).collect();
    match style {
        "stream" => {
            for v in vals {
                println!("{}", serde_json::to_string(&v).unwrap());
            }
        }
        "compact" => println!("{}", serde_json::to_string(&vals).unwrap()),
        _ => println!("{}", serde_json::to_string_pretty(&vals).unwrap()),
    }
}

fn json_match(m: &Found, scan: bool) -> serde_json::Value {
    let range = json_range(m.start, m.end, m.line, m.column, m.end_line, m.end_column);
    let mut single = serde_json::Map::new();
    for (k, v) in &m.vars {
        single.insert(k.clone(), json!({
            "text": v.text,
            "range": json_range(v.start, v.end, v.line, v.column, v.line, v.column + v.text.len())
        }));
    }
    let mut obj = json!({
        "text": m.text,
        "range": range,
        "file": m.file,
        "lines": m.line_text,
        "charCount": {"leading": m.leading, "trailing": m.trailing},
        "language": m.language,
        "metaVariables": {"single": single, "multi": {}, "transformed": {}}
    });
    if let Some(rep) = &m.replacement {
        obj.as_object_mut().unwrap().insert("replacement".into(), json!(rep));
        obj.as_object_mut().unwrap().insert("replacementOffsets".into(), json!({"start": m.start, "end": m.end}));
    }
    if scan {
        if let Some(r) = &m.rule {
            obj.as_object_mut().unwrap().insert("ruleId".into(), json!(r.id));
            obj.as_object_mut().unwrap().insert("severity".into(), json!(r.severity));
            obj.as_object_mut().unwrap().insert("note".into(), serde_json::Value::Null);
            obj.as_object_mut().unwrap().insert("message".into(), json!(r.message));
            obj.as_object_mut().unwrap().insert("labels".into(), json!([{"text": m.text, "range": json_range(m.start, m.end, m.line, m.column, m.end_line, m.end_column), "style": "primary"}]));
        }
    }
    obj
}

fn json_range(start: usize, end: usize, line: usize, column: usize, end_line: usize, end_column: usize) -> serde_json::Value {
    json!({
        "byteOffset": {"start": start, "end": end},
        "start": {"line": line, "column": column},
        "end": {"line": end_line, "column": end_column}
    })
}

fn print_file_diff(matches: &[Found]) {
    if matches.is_empty() { return; }
    let file = &matches[0].file;
    if let Ok(content) = fs::read_to_string(file) {
        let new = apply_replacements(&content, matches);
        print_simple_diff(&content, &new);
    }
}

fn print_scan_diff(matches: &[Found]) {
    for m in matches {
        println!("{}", m.file);
        if let Some(r) = &m.rule {
            println!("{}[{}]: {}", r.severity, r.id, r.message);
        }
        let old_line = m.line_text.clone();
        let new_line = old_line.replacen(&m.text, m.replacement.as_deref().unwrap_or(&m.text), 1);
        print_simple_diff(&old_line, &new_line);
    }
}

fn print_scan_short(matches: &[Found]) {
    for m in matches {
        if let Some(r) = &m.rule {
            println!("{}:{}:{}: {}[{}]: {}", m.file, m.line + 1, m.column + 1, r.severity, r.id, r.message);
        }
    }
}

fn print_simple_diff(old: &str, new: &str) {
    let old_lines: Vec<&str> = old.lines().collect();
    let new_lines: Vec<&str> = new.lines().collect();
    let n = usize::max(old_lines.len(), new_lines.len());
    println!("@@ -0,{} +0,{} @@", old_lines.len(), new_lines.len());
    for i in 0..n {
        match (old_lines.get(i), new_lines.get(i)) {
            (Some(a), Some(b)) if a == b => println!("{} {}│ {}", i + 1, i + 1, a),
            (Some(a), Some(b)) => {
                println!("{}  │-{}", i + 1, a);
                println!("  {}│+{}", i + 1, b);
            }
            (Some(a), None) => println!("{}  │-{}", i + 1, a),
            (None, Some(b)) => println!("  {}│+{}", i + 1, b),
            _ => {}
        }
    }
}

fn scan_command(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_scan_help();
        return 0;
    }
    let mut rule_file = None;
    let mut inline = None;
    let mut paths = Vec::new();
    let mut pass = Vec::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-r" | "--rule" => {
                i += 1;
                rule_file = args.get(i).cloned();
            }
            "--inline-rules" => {
                i += 1;
                inline = args.get(i).cloned();
            }
            "--format" | "--report-style" | "--filter" | "-c" | "--config" | "--error" | "--warning" | "--info" | "--hint" | "--off" | "-j" | "--threads" | "--color" | "--globs" | "--no-ignore" | "--inspect" | "--max-results" => {
                pass.push(args[i].clone());
                if i + 1 < args.len() && !args[i + 1].starts_with('-') { i += 1; pass.push(args[i].clone()); }
            }
            "--json" | "--stdin" | "-U" | "--update-all" | "--files-with-matches" | "-i" | "--interactive" | "--follow" | "--include-metadata" => pass.push(args[i].clone()),
            a if a.starts_with("--json=") || a.starts_with("--error=") || a.starts_with("--warning=") || a.starts_with("--info=") || a.starts_with("--hint=") || a.starts_with("--off=") => pass.push(args[i].clone()),
            a if a.starts_with('-') => {}
            _ => paths.push(args[i].clone()),
        }
        i += 1;
    }
    let text = if let Some(t) = inline { t } else if let Some(f) = rule_file { fs::read_to_string(&f).unwrap_or_default() } else { find_project_rules().unwrap_or_default() };
    let rules = parse_rules(&text);
    if rules.is_empty() {
        return 0;
    }
    let mut exit = 1;
    for rule in rules {
        let mut a = pass.clone();
        a.push("--pattern".to_string());
        a.push(rule.pattern.clone());
        if let Some(lang) = &rule.language {
            a.push("--lang".to_string());
            a.push(lang.clone());
        }
        if let Some(fix) = &rule.fix {
            a.push("--rewrite".to_string());
            a.push(fix.clone());
        }
        a.extend(paths.clone());
        exit = run_command(&a, Some(rule));
    }
    exit
}

fn parse_rules(text: &str) -> Vec<Rule> {
    text.split("\n---").filter_map(parse_rule).collect()
}

fn parse_rule(text: &str) -> Option<Rule> {
    let mut id = String::new();
    let mut language = None;
    let mut message = String::new();
    let mut severity = "hint".to_string();
    let mut pattern = None;
    let mut fix = None;
    for raw in text.lines() {
        let line = raw.trim();
        if line.starts_with('#') || line.is_empty() { continue; }
        if let Some(v) = line.strip_prefix("id:") { id = clean_yaml(v); }
        else if let Some(v) = line.strip_prefix("language:") { language = Some(clean_yaml(v)); }
        else if let Some(v) = line.strip_prefix("message:") { message = clean_yaml(v); }
        else if let Some(v) = line.strip_prefix("severity:") { severity = clean_yaml(v); }
        else if let Some(v) = line.strip_prefix("pattern:") { pattern = Some(clean_yaml(v)); }
        else if let Some(v) = line.strip_prefix("fix:") { fix = Some(clean_yaml(v)); }
    }
    pattern.map(|p| Rule { id: if id.is_empty() { "rule".into() } else { id }, language, message, severity, pattern: p, fix })
}

fn clean_yaml(v: &str) -> String {
    let s = v.trim();
    if (s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\'')) {
        s[1..s.len().saturating_sub(1)].to_string()
    } else {
        s.to_string()
    }
}

fn find_project_rules() -> Option<String> {
    let cfg = fs::read_to_string("sgconfig.yml").or_else(|_| fs::read_to_string("sgconfig.yaml")).ok()?;
    let mut combined = String::new();
    for line in cfg.lines() {
        let t = line.trim().trim_start_matches('-').trim();
        if t.ends_with("rules") || t.contains("rules") {
            let p = Path::new(t);
            if p.is_dir() {
                for e in fs::read_dir(p).ok()?.flatten() {
                    if e.path().extension().and_then(|x| x.to_str()).map(|x| x == "yml" || x == "yaml").unwrap_or(false) {
                        if let Ok(s) = fs::read_to_string(e.path()) {
                            combined.push_str(&s);
                            combined.push_str("\n---\n");
                        }
                    }
                }
            }
        }
    }
    Some(combined)
}

fn test_command(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_test_help();
    } else {
        println!("No tests found");
    }
    0
}

fn new_command(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_new_help();
        return 0;
    }
    let name = args.iter().find(|a| !a.starts_with('-')).cloned().unwrap_or_else(|| "new-rule".to_string());
    let lang = args.windows(2).find(|w| w[0] == "-l" || w[0] == "--lang").map(|w| w[1].clone()).unwrap_or_else(|| "JavaScript".to_string());
    let content = format!("id: {name}\nlanguage: {lang}\nmessage: TODO\nrule:\n  pattern: TODO\n");
    let path = format!("{name}.yml");
    let _ = fs::write(&path, content);
    println!("Created {path}");
    0
}

fn completions_command(args: &[String]) -> i32 {
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_completions_help();
    } else {
        println!("# completion script generation is not available in this reimplementation");
    }
    0
}

fn language_for_path(path: &str) -> String {
    let ext = Path::new(path).extension().and_then(|e| e.to_str()).unwrap_or("");
    normalize_lang(match ext {
        "js" | "jsx" => "JavaScript",
        "ts" => "TypeScript",
        "tsx" => "Tsx",
        "py" => "Python",
        "rs" => "Rust",
        "go" => "Go",
        "java" => "Java",
        "c" | "h" => "C",
        "cpp" | "cc" | "hpp" => "Cpp",
        "rb" => "Ruby",
        "json" => "Json",
        "yml" | "yaml" => "Yaml",
        "html" => "Html",
        "css" => "Css",
        "sh" => "Bash",
        _ => "JavaScript",
    })
}

fn normalize_lang(lang: &str) -> String {
    match lang.to_ascii_lowercase().as_str() {
        "js" | "javascript" => "JavaScript".into(),
        "ts" | "typescript" => "TypeScript".into(),
        "tsx" => "Tsx".into(),
        "py" | "python" => "Python".into(),
        "rs" | "rust" => "Rust".into(),
        "go" => "Go".into(),
        "json" => "Json".into(),
        "yaml" | "yml" => "Yaml".into(),
        "bash" | "sh" => "Bash".into(),
        other => {
            let mut c = other.chars();
            c.next().map(|f| f.to_uppercase().collect::<String>() + c.as_str()).unwrap_or_default()
        }
    }
}

fn print_top_help() {
    println!("Search and Rewrite code at large scale using AST pattern.\n\nUsage: executable [OPTIONS] <COMMAND>\n\nCommands:\n  run          Run one time search or rewrite in command line. (default command)\n  scan         Scan and rewrite code by configuration\n  test         Test ast-grep rules\n  new          Create new ast-grep project or items like rules/tests\n  lsp          Start language server\n  completions  Generate shell completion script\n  help         Print this message or the help of the given subcommand(s)\n\nOptions:\n  -c, --config <CONFIG_FILE>\n          Path to ast-grep root config, default is sgconfig.yml\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
}

fn print_run_help() {
    println!("Run one time search or rewrite in command line. (default command)\n\nUsage: executable run [OPTIONS] --pattern <PATTERN> [PATHS]...\n\nArguments:\n  [PATHS]...\n          The paths to search. You can provide multiple paths separated by spaces\n          \n          [default: .]\n\nOptions:\n  -p, --pattern <PATTERN>\n          AST pattern to match\n\n  -r, --rewrite <FIX>\n          String to replace the matched AST node\n\n  -l, --lang <LANG>\n          The language of the pattern.\n\n      --stdin\n          Enable search code from StdIn.\n\n  -U, --update-all\n          Apply all rewrite without confirmation if true\n\n      --files-with-matches\n          Print only the paths with at least one match and suppress match contents.\n\n      --json[=<STYLE>]\n          Output matches in structured JSON.\n\n  -A, --after <NUM>\n          Show NUM lines after each match.\n\n  -B, --before <NUM>\n          Show NUM lines before each match.\n\n  -C, --context <NUM>\n          Show NUM lines around each match.\n\n  -h, --help\n          Print help (see a summary with '-h')");
}

fn print_scan_help() {
    println!("Scan and rewrite code by configuration\n\nUsage: executable scan [OPTIONS] [PATHS]...\n\nOptions:\n  -r, --rule <RULE_FILE>\n          Scan the codebase with the single rule located at the path RULE_FILE.\n\n      --inline-rules <RULE_TEXT>\n          Scan the codebase with a rule defined by the provided RULE_TEXT.\n\n      --report-style <REPORT_STYLE>\n          Possible values: rich, medium, short\n\n      --json[=<STYLE>]\n          Output matches in structured JSON.\n\n  -U, --update-all\n          Apply all rewrite without confirmation if true\n\n  -h, --help\n          Print help (see a summary with '-h')");
}

fn print_test_help() {
    println!("Test ast-grep rules\n\nUsage: executable test [OPTIONS]\n\nOptions:\n  -t, --test-dir <TEST_DIR>\n          the directories to search test YAML files\n  -U, --update-all\n          Update the content of all snapshots that have changed in test.\n  -h, --help\n          Print help (see a summary with '-h')");
}

fn print_new_help() {
    println!("Create new ast-grep project or items like rules/tests\n\nUsage: executable new [OPTIONS] [NAME] [COMMAND]\n\nCommands:\n  project  Create an new project by scaffolding\n  rule     Create a new rule\n  test     Create a new test case\n  util     Create a new global utility rule\n  help     Print this message or the help of the given subcommand(s)\n\nOptions:\n  -l, --lang <LANG>\n          The language of the item to create.\n  -y, --yes\n          Accept all default options without interactive input during creation.\n  -h, --help\n          Print help (see a summary with '-h')");
}

fn print_completions_help() {
    println!("Generate shell completion script\n\nUsage: executable completions [OPTIONS] [SHELL]\n\nArguments:\n  [SHELL]  Output the completion file for given shell. [possible values: bash, elvish, fish, powershell, zsh]\n\nOptions:\n  -h, --help                  Print help");
}
