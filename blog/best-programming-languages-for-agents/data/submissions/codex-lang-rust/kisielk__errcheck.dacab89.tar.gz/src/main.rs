use regex::Regex;
use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};

#[derive(Default)]
struct Config {
    abspath: bool,
    asserts: bool,
    blank: bool,
    exclude: Option<String>,
    excludeonly: bool,
    ignoregenerated: bool,
    ignoretests: bool,
    verbose: bool,
    ignorepkg: HashSet<String>,
    ignore: Vec<(Option<String>, Regex)>,
    tags: Option<String>,
    module_mode: Option<String>,
    args: Vec<String>,
}

#[derive(Clone, Debug)]
struct Finding {
    path: PathBuf,
    line: usize,
    col: usize,
    text: String,
}

#[derive(Default, Clone)]
struct FileInfo {
    imports: HashMap<String, String>,
    error_funcs: HashSet<String>,
}

fn main() {
    let cfg = match parse_args() {
        Ok(c) => c,
        Err(code) => std::process::exit(code),
    };

    let excludes = load_excludes(&cfg);
    if cfg.verbose {
        for ex in &excludes {
            eprintln!("excluding {}", ex);
        }
    }

    let files = discover_files(&cfg);
    if files.is_empty() {
        std::process::exit(0);
    }

    let mut all_error_funcs = HashSet::new();
    let mut infos = HashMap::new();
    for file in &files {
        if let Ok(src) = fs::read_to_string(file) {
            let info = collect_file_info(&src);
            for f in &info.error_funcs {
                all_error_funcs.insert(f.clone());
            }
            infos.insert(file.clone(), info);
        }
    }

    let mut findings = Vec::new();
    for file in &files {
        let src = match fs::read_to_string(file) {
            Ok(s) => s,
            Err(e) => {
                eprintln!("error: failed to read {}: {}", file.display(), e);
                std::process::exit(2);
            }
        };
        let info = infos.get(file).cloned().unwrap_or_default();
        scan_file(file, &src, &info, &all_error_funcs, &cfg, &excludes, &mut findings);
    }

    findings.sort_by(|a, b| a.path.cmp(&b.path).then(a.line.cmp(&b.line)).then(a.col.cmp(&b.col)));
    for f in &findings {
        let path = display_path(&f.path, cfg.abspath);
        println!("{}:{}:{}:\t{}", path, f.line, f.col, f.text);
    }

    if findings.is_empty() {
        std::process::exit(0);
    } else {
        std::process::exit(1);
    }
}

fn parse_args() -> Result<Config, i32> {
    let mut cfg = Config::default();
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "--help" | "-h" => {
                print_help();
                return Err(0);
            }
            "-abspath" => cfg.abspath = true,
            "-asserts" => cfg.asserts = true,
            "-blank" => cfg.blank = true,
            "-excludeonly" => cfg.excludeonly = true,
            "-ignoregenerated" => cfg.ignoregenerated = true,
            "-ignoretests" => cfg.ignoretests = true,
            "-verbose" => cfg.verbose = true,
            "-exclude" | "-ignore" | "-ignorepkg" | "-mod" | "-tags" => {
                let val = match it.next() {
                    Some(v) => v,
                    None => {
                        eprintln!("flag needs an argument: {}", arg);
                        print_help();
                        return Err(2);
                    }
                };
                match arg.as_str() {
                    "-exclude" => cfg.exclude = Some(val),
                    "-ignore" => parse_ignore(&mut cfg, &val),
                    "-ignorepkg" => {
                        for p in val.split(',').map(str::trim).filter(|s| !s.is_empty()) {
                            cfg.ignorepkg.insert(p.to_string());
                        }
                    }
                    "-mod" => cfg.module_mode = Some(val),
                    "-tags" => cfg.tags = Some(val),
                    _ => {}
                }
            }
            _ if arg.starts_with("-exclude=") => cfg.exclude = Some(arg[9..].to_string()),
            _ if arg.starts_with("-ignore=") => parse_ignore(&mut cfg, &arg[8..]),
            _ if arg.starts_with("-ignorepkg=") => {
                for p in arg[11..].split(',').map(str::trim).filter(|s| !s.is_empty()) {
                    cfg.ignorepkg.insert(p.to_string());
                }
            }
            _ if arg.starts_with("-mod=") => cfg.module_mode = Some(arg[5..].to_string()),
            _ if arg.starts_with("-tags=") => cfg.tags = Some(arg[6..].to_string()),
            _ if arg.starts_with('-') => {
                eprintln!("flag provided but not defined: {}", arg);
                print_help();
                return Err(2);
            }
            _ => cfg.args.push(arg),
        }
    }
    if cfg.args.is_empty() {
        cfg.args.push(".".to_string());
    }
    Ok(cfg)
}

fn print_help() {
    println!("Usage of ./executable:");
    println!("  -abspath\n    \tprint absolute paths to files");
    println!("  -asserts\n    \tif true, check for ignored type assertion results");
    println!("  -blank\n    \tif true, check for errors assigned to blank identifier");
    println!("  -exclude string\n    \tPath to a file containing a list of functions to exclude from checking");
    println!("  -excludeonly\n    \tUse only excludes from -exclude file");
    println!("  -ignore value\n    \t[deprecated] comma-separated list of pairs of the form pkg:regex\n    \t            the regex is used to ignore names within pkg.");
    println!("  -ignoregenerated\n    \tif true, checking of files with generated code is disabled");
    println!("  -ignorepkg string\n    \tcomma-separated list of package paths to ignore");
    println!("  -ignoretests\n    \tif true, checking of _test.go files is disabled");
    println!("  -mod string\n    \tmodule download mode to use: readonly or vendor. See 'go help modules' for more.");
    println!("  -tags value\n    \tcomma or space-separated list of build tags to include");
    println!("  -verbose\n    \tproduce more verbose logging");
}

fn parse_ignore(cfg: &mut Config, value: &str) {
    for item in value.split(',').map(str::trim).filter(|s| !s.is_empty()) {
        let (pkg, pat) = if let Some((p, r)) = item.split_once(':') {
            (if p.is_empty() { None } else { Some(p.to_string()) }, r)
        } else {
            (None, item)
        };
        if let Ok(re) = Regex::new(pat) {
            cfg.ignore.push((pkg, re));
        }
    }
}

fn load_excludes(cfg: &Config) -> HashSet<String> {
    let mut set = HashSet::new();
    if !cfg.excludeonly {
        for name in [
            "fmt.Print", "fmt.Printf", "fmt.Println", "fmt.Fprint", "fmt.Fprintf", "fmt.Fprintln",
            "bytes.Buffer.Write", "bytes.Buffer.WriteString", "strings.Builder.Write", "strings.Builder.WriteString",
        ] {
            set.insert(name.to_string());
        }
    }
    if let Some(path) = &cfg.exclude {
        match fs::read_to_string(path) {
            Ok(s) => {
                for line in s.lines() {
                    let t = line.trim();
                    if t.is_empty() || t.starts_with("//") { continue; }
                    set.insert(t.to_string());
                }
            }
            Err(e) => {
                eprintln!("error: failed to read exclude file {}: {}", path, e);
                std::process::exit(2);
            }
        }
    }
    set
}

fn discover_files(cfg: &Config) -> Vec<PathBuf> {
    let mut out = Vec::new();
    for arg in &cfg.args {
        if arg == "all" {
            add_dir(Path::new("."), true, cfg, &mut out);
        } else if let Some(prefix) = arg.strip_suffix("/...") {
            let root = if prefix.is_empty() { "." } else { prefix };
            add_dir(Path::new(root), true, cfg, &mut out);
        } else {
            let path = Path::new(arg);
            if path.is_file() {
                maybe_add_file(path, cfg, &mut out);
            } else if path.is_dir() {
                add_dir(path, false, cfg, &mut out);
            }
        }
    }
    out.sort();
    out.dedup();
    out
}

fn add_dir(dir: &Path, recursive: bool, cfg: &Config, out: &mut Vec<PathBuf>) {
    if recursive {
        add_dir_recursive(dir, cfg, out);
    } else if let Ok(rd) = fs::read_dir(dir) {
        for ent in rd.filter_map(Result::ok) {
            let p = ent.path();
            if p.is_file() { maybe_add_file(&p, cfg, out); }
        }
    }
}

fn add_dir_recursive(dir: &Path, cfg: &Config, out: &mut Vec<PathBuf>) {
    let rd = match fs::read_dir(dir) { Ok(r) => r, Err(_) => return };
    for ent in rd.filter_map(Result::ok) {
        let p = ent.path();
        if p.is_dir() {
            let name = p.file_name().and_then(|s| s.to_str()).unwrap_or("");
            if name == ".git" || name == "target" { continue; }
            add_dir_recursive(&p, cfg, out);
        } else if p.is_file() {
            maybe_add_file(&p, cfg, out);
        }
    }
}

fn maybe_add_file(path: &Path, cfg: &Config, out: &mut Vec<PathBuf>) {
    if path.extension().and_then(|s| s.to_str()) != Some("go") { return; }
    let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
    if cfg.ignoretests && name.ends_with("_test.go") { return; }
    if cfg.ignoregenerated {
        if let Ok(s) = fs::read_to_string(path) {
            if is_generated(&s) { return; }
        }
    }
    out.push(path.to_path_buf());
}

fn is_generated(src: &str) -> bool {
    for line in src.lines().take(20) {
        if line.contains("Code generated") && line.contains("DO NOT EDIT") {
            return true;
        }
    }
    false
}

fn collect_file_info(src: &str) -> FileInfo {
    let mut info = FileInfo::default();
    let func_re = Regex::new(r"^\s*func\s+(?:\([^)]*\)\s*)?([A-Za-z_][A-Za-z0-9_]*)\s*\([^)]*\)\s*(.*)").unwrap();
    let import_one = Regex::new(r#"^\s*import\s+(?:(\w+|\.)\s+)?\"([^\"]+)\""#).unwrap();
    let import_line = Regex::new(r#"^\s*(?:(\w+|\.)\s+)?\"([^\"]+)\""#).unwrap();
    let mut in_import = false;
    for raw in src.lines() {
        let line = raw.trim();
        if line.starts_with("import (") { in_import = true; continue; }
        if in_import {
            if line.starts_with(')') { in_import = false; continue; }
            if let Some(c) = import_line.captures(line) {
                add_import(&mut info.imports, c.get(1).map(|m| m.as_str()), c.get(2).unwrap().as_str());
            }
        } else if let Some(c) = import_one.captures(line) {
            add_import(&mut info.imports, c.get(1).map(|m| m.as_str()), c.get(2).unwrap().as_str());
        }
        if let Some(c) = func_re.captures(raw) {
            let name = c.get(1).unwrap().as_str();
            let ret = c.get(2).map(|m| m.as_str()).unwrap_or("");
            if ret.contains("error") {
                info.error_funcs.insert(name.to_string());
            }
        }
    }
    info
}

fn add_import(imports: &mut HashMap<String, String>, alias: Option<&str>, path: &str) {
    if alias == Some("_") || alias == Some(".") { return; }
    let default = path.rsplit('/').next().unwrap_or(path).replace('-', "_");
    imports.insert(alias.unwrap_or(&default).to_string(), path.to_string());
}

fn scan_file(
    path: &Path,
    src: &str,
    info: &FileInfo,
    all_error_funcs: &HashSet<String>,
    cfg: &Config,
    excludes: &HashSet<String>,
    findings: &mut Vec<Finding>,
) {
    let mut in_block_comment = false;
    for (idx, raw) in src.lines().enumerate() {
        let line_no = idx + 1;
        let clean = strip_comments(raw, &mut in_block_comment);
        let line = clean.trim();
        if line.is_empty() || line.starts_with("package ") || line.starts_with("import ") || line.starts_with("func ") || line == "}" {
            continue;
        }
        if cfg.asserts {
            scan_assertion(path, raw, &clean, line_no, findings);
        }
        if is_control_line(line) || line.starts_with("return") {
            continue;
        }
        if let Some((lhs, rhs, op_col)) = split_assignment(&clean) {
            if cfg.blank && lhs.split(',').any(|p| p.trim() == "_") {
                if let Some(call) = first_checkable_call(rhs, info, all_error_funcs, cfg, excludes) {
                    findings.push(Finding { path: path.to_path_buf(), line: line_no, col: op_col + 1, text: format!("{} assigned to blank identifier", call.expr) });
                }
            }
            continue;
        }
        let stmt = line.strip_prefix("defer ").or_else(|| line.strip_prefix("go ")).unwrap_or(line);
        if let Some(call) = first_checkable_call(stmt, info, all_error_funcs, cfg, excludes) {
            let col = raw.find(&call.expr).map(|c| c + 1).unwrap_or_else(|| raw.find(stmt).map(|c| c + 1).unwrap_or(1));
            findings.push(Finding { path: path.to_path_buf(), line: line_no, col, text: call.expr });
        }
    }
}

fn strip_comments(raw: &str, in_block: &mut bool) -> String {
    let mut out = String::new();
    let mut i = 0;
    let bytes = raw.as_bytes();
    while i < bytes.len() {
        if *in_block {
            if i + 1 < bytes.len() && bytes[i] == b'*' && bytes[i + 1] == b'/' {
                *in_block = false;
                i += 2;
            } else { i += 1; }
        } else if i + 1 < bytes.len() && bytes[i] == b'/' && bytes[i + 1] == b'*' {
            *in_block = true;
            i += 2;
        } else if i + 1 < bytes.len() && bytes[i] == b'/' && bytes[i + 1] == b'/' {
            break;
        } else {
            out.push(bytes[i] as char);
            i += 1;
        }
    }
    out
}

fn is_control_line(line: &str) -> bool {
    ["if ", "for ", "switch ", "select ", "case ", "var ", "const ", "type "].iter().any(|p| line.starts_with(p))
}

fn split_assignment(line: &str) -> Option<(&str, &str, usize)> {
    for op in [":=", "="] {
        if let Some(pos) = find_top_level(line, op) {
            if line[..pos].contains("==") || line[..pos].contains("!=") { continue; }
            return Some((&line[..pos], &line[pos + op.len()..], pos));
        }
    }
    None
}

fn find_top_level(s: &str, needle: &str) -> Option<usize> {
    let mut depth = 0i32;
    let bytes = s.as_bytes();
    let n = needle.as_bytes();
    let mut i = 0;
    while i + n.len() <= bytes.len() {
        match bytes[i] {
            b'(' | b'[' | b'{' => depth += 1,
            b')' | b']' | b'}' => depth -= 1,
            _ => {}
        }
        if depth == 0 && &bytes[i..i + n.len()] == n {
            return Some(i);
        }
        i += 1;
    }
    None
}

#[derive(Clone)]
struct Call { expr: String, pkg: Option<String>, name: String }

fn first_checkable_call(
    s: &str,
    info: &FileInfo,
    all_error_funcs: &HashSet<String>,
    cfg: &Config,
    excludes: &HashSet<String>,
) -> Option<Call> {
    for call in extract_calls(s) {
        if is_checkable(&call, info, all_error_funcs, cfg, excludes) {
            return Some(call);
        }
    }
    None
}

fn extract_calls(s: &str) -> Vec<Call> {
    let mut out = Vec::new();
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        if chars[i] == '(' {
            let mut j = i;
            while j > 0 && chars[j - 1].is_whitespace() { j -= 1; }
            let end_name = j;
            while j > 0 && (chars[j - 1].is_alphanumeric() || chars[j - 1] == '_' || chars[j - 1] == '.') { j -= 1; }
            if j < end_name {
                let name: String = chars[j..end_name].iter().collect();
                if !["if", "for", "switch", "func"].contains(&name.as_str()) {
                    if let Some(close) = matching_paren(&chars, i) {
                        let mut expr_start = j;
                        let mut call_name = name.clone();
                        if name.starts_with('.') && j > 0 && chars[j - 1] == '}' {
                            expr_start = composite_literal_start(&chars, j - 1);
                            call_name = chars[expr_start..end_name].iter().collect();
                        }
                        let expr: String = chars[expr_start..=close].iter().collect();
                        let (pkg, fname) = if let Some((p, n)) = call_name.rsplit_once('.') {
                            (if p.is_empty() { None } else { Some(p.to_string()) }, n.to_string())
                        } else {
                            (None, call_name.clone())
                        };
                        out.push(Call { expr: expr.trim().trim_end_matches(';').to_string(), pkg, name: fname });
                        i = close;
                    }
                }
            }
        }
        i += 1;
    }
    out
}

fn composite_literal_start(chars: &[char], close_brace: usize) -> usize {
    let mut depth = 0i32;
    let mut open = close_brace;
    for i in (0..=close_brace).rev() {
        if chars[i] == '}' { depth += 1; }
        else if chars[i] == '{' {
            depth -= 1;
            if depth == 0 { open = i; break; }
        }
    }
    let mut start = open;
    while start > 0 && (chars[start - 1].is_alphanumeric() || chars[start - 1] == '_' || chars[start - 1] == '.') {
        start -= 1;
    }
    start
}

fn matching_paren(chars: &[char], open: usize) -> Option<usize> {
    let mut depth = 0i32;
    let mut quote: Option<char> = None;
    let mut esc = false;
    for i in open..chars.len() {
        let c = chars[i];
        if let Some(q) = quote {
            if esc { esc = false; }
            else if c == '\\' { esc = true; }
            else if c == q { quote = None; }
            continue;
        }
        if c == '"' || c == '\'' || c == '`' { quote = Some(c); continue; }
        if c == '(' { depth += 1; }
        else if c == ')' {
            depth -= 1;
            if depth == 0 { return Some(i); }
        }
    }
    None
}

fn is_checkable(call: &Call, info: &FileInfo, all_error_funcs: &HashSet<String>, cfg: &Config, excludes: &HashSet<String>) -> bool {
    if call.name.is_empty() || is_builtin(&call.name) { return false; }
    let import_path = call.pkg.as_ref().and_then(|p| info.imports.get(p)).cloned();
    let pkg_name = import_path.clone().or_else(|| call.pkg.clone());
    if let Some(pkg) = &pkg_name {
        if cfg.ignorepkg.contains(pkg) || cfg.ignorepkg.contains(call.pkg.as_deref().unwrap_or("")) { return false; }
        if pkg == "fmt" && !has_explicit_ignore_for_pkg(cfg, "fmt") { return false; }
    }
    let full = if let Some(pkg) = &pkg_name { format!("{}.{}", pkg, call.name) } else { call.name.clone() };
    if excludes.contains(&full) || excludes.contains(&call.name) { return false; }
    for (pkg, re) in &cfg.ignore {
        let pkg_matches = match pkg {
            Some(p) => pkg_name.as_deref() == Some(p) || call.pkg.as_deref() == Some(p),
            None => true,
        };
        if pkg_matches && re.is_match(&call.name) { return false; }
    }
    if all_error_funcs.contains(&call.name) { return true; }
    if let Some(pkg) = pkg_name {
        return known_error_func(&pkg, &call.name);
    }
    known_error_method(&call.name)
}

fn has_explicit_ignore_for_pkg(cfg: &Config, pkg: &str) -> bool {
    cfg.ignore.iter().any(|(p, _)| p.as_deref() == Some(pkg))
}

fn is_builtin(name: &str) -> bool {
    matches!(name, "append" | "cap" | "close" | "complex" | "copy" | "delete" | "imag" | "len" | "make" | "new" | "panic" | "print" | "println" | "real" | "recover")
}

fn known_error_func(pkg: &str, name: &str) -> bool {
    match pkg {
        "os" => matches!(name, "Chdir" | "Chmod" | "Chown" | "Chtimes" | "Mkdir" | "MkdirAll" | "Remove" | "RemoveAll" | "Rename" | "Symlink" | "Link" | "WriteFile" | "ReadFile" | "Setenv" | "Unsetenv"),
        "io" => matches!(name, "Copy" | "CopyBuffer" | "CopyN" | "ReadAll" | "ReadAtLeast" | "ReadFull" | "WriteString"),
        "net/http" => matches!(name, "ListenAndServe" | "ListenAndServeTLS" | "Serve" | "ServeTLS" | "Get" | "Post" | "PostForm"),
        "encoding/json" | "encoding/xml" => matches!(name, "Marshal" | "Unmarshal" | "MarshalIndent"),
        "strconv" => matches!(name, "Atoi" | "ParseBool" | "ParseFloat" | "ParseInt" | "ParseUint"),
        "database/sql" => matches!(name, "Open"),
        "net" => matches!(name, "Listen" | "Dial" | "ResolveTCPAddr" | "ResolveUDPAddr"),
        _ => known_error_method(name),
    }
}

fn known_error_method(name: &str) -> bool {
    matches!(name, "Close" | "Flush" | "Sync" | "Write" | "WriteString" | "Read" | "ReadFrom" | "WriteTo" | "Encode" | "Decode" | "Commit" | "Rollback" | "Scan" | "Err")
}

fn scan_assertion(path: &Path, raw: &str, clean: &str, line_no: usize, findings: &mut Vec<Finding>) {
    if let Some(pos) = clean.find(".(") {
        if clean.contains(",") && split_assignment(clean).map(|(lhs, _, _)| lhs.contains(',')).unwrap_or(false) {
            return;
        }
        let start = clean[..pos].rfind(|c: char| !(c.is_alphanumeric() || c == '_' || c == '.')).map(|p| p + 1).unwrap_or(0);
        if let Some(end_rel) = clean[pos + 2..].find(')') {
            let end = pos + 2 + end_rel;
            let expr = clean[start..=end].trim().to_string();
            let col = raw.find(&expr).map(|c| c + 1).unwrap_or(pos + 1);
            findings.push(Finding { path: path.to_path_buf(), line: line_no, col, text: expr });
        }
    }
}

fn display_path(path: &Path, abs: bool) -> String {
    if abs {
        fs::canonicalize(path).unwrap_or_else(|_| path.to_path_buf()).display().to_string()
    } else {
        let s = path.display().to_string();
        s.strip_prefix("./").unwrap_or(&s).to_string()
    }
}
