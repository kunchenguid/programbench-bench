use regex::Regex;
use std::collections::HashSet;
use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::process::{Command, Stdio};
use std::thread;
use std::time::Duration;

#[derive(Clone, Debug, Eq, PartialEq, Hash)]
enum Group {
    Numbers,
    Urls,
    Pointers,
    Dates,
    Paths,
    Quotes,
    KeyValuePairs,
    Uuids,
    IpAddresses,
    Processes,
    Json,
}

impl Group {
    fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "numbers" => Self::Numbers,
            "urls" => Self::Urls,
            "pointers" => Self::Pointers,
            "dates" => Self::Dates,
            "paths" => Self::Paths,
            "quotes" => Self::Quotes,
            "key-value-pairs" => Self::KeyValuePairs,
            "uuids" => Self::Uuids,
            "ip-addresses" => Self::IpAddresses,
            "processes" => Self::Processes,
            "json" => Self::Json,
            _ => return None,
        })
    }
}

const GROUPS: &str = "numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids, ip-addresses, processes, json";

#[derive(Default, Debug)]
struct Cli {
    file: Option<String>,
    follow: bool,
    exec: Option<String>,
    config_path: Option<String>,
    pager: Option<String>,
    highlight: Vec<CustomHighlight>,
    enable: Vec<Group>,
    disable: Vec<Group>,
    disable_builtin_keywords: bool,
}

#[derive(Clone, Debug)]
struct CustomHighlight {
    color: &'static str,
    words: Vec<String>,
}

#[derive(Clone)]
struct Span {
    start: usize,
    end: usize,
    style: &'static str,
}

struct Highlighter {
    custom: Vec<CustomHighlight>,
    enabled: HashSet<Group>,
    builtin_keywords: bool,
    re_date_iso: Regex,
    re_date_syslog: Regex,
    re_time: Regex,
    re_uuid: Regex,
    re_ipv4: Regex,
    re_ipv6: Regex,
    re_url: Regex,
    re_path: Regex,
    re_kv: Regex,
    re_quote: Regex,
    re_process: Regex,
    re_pointer: Regex,
    re_number: Regex,
    re_json_punct: Regex,
    re_words: Regex,
}

fn main() {
    let cli = match parse_args() {
        Ok(c) => c,
        Err((code, msg)) => {
            if code == 0 {
                print!("{msg}");
            } else {
                eprint!("{msg}");
            }
            std::process::exit(code);
        }
    };
    match run(cli) {
        Ok(()) => {}
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(1);
        }
    }
}

fn parse_args() -> Result<Cli, (i32, String)> {
    let mut cli = Cli::default();
    cli.pager = env::var("TAILSPIN_PAGER").ok();
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" => return Err((0, short_help())),
            "--help" => return Err((0, long_help())),
            "-V" | "--version" => return Err((0, "tspin 5.6.0\n".to_string())),
            "-f" | "--follow" => cli.follow = true,
            "-p" | "--print" => {}
            "--disable-builtin-keywords" => cli.disable_builtin_keywords = true,
            "-e" | "--exec" => cli.exec = Some(take_value(&mut args, &arg)?),
            "--config-path" => cli.config_path = Some(take_value(&mut args, &arg)?),
            "--pager" => cli.pager = Some(take_value(&mut args, &arg)?),
            "--highlight" => cli.highlight.push(parse_highlight(&take_value(&mut args, &arg)?).map_err(|e| (2, format!("error: invalid value for '--highlight <COLOR_WORD>': {e}\n\nFor more information, try '--help'.\n")))?),
            "--enable" => parse_groups(&take_value(&mut args, &arg)?, "--enable", &mut cli.enable)?,
            "--disable" => parse_groups(&take_value(&mut args, &arg)?, "--disable", &mut cli.disable)?,
            _ if arg.starts_with("--config-path=") => cli.config_path = Some(arg[14..].to_string()),
            _ if arg.starts_with("--pager=") => cli.pager = Some(arg[8..].to_string()),
            _ if arg.starts_with("--highlight=") => cli.highlight.push(parse_highlight(&arg[12..]).map_err(|e| (2, format!("error: invalid value '{}' for '--highlight <COLOR_WORD>': {e}\n\nFor more information, try '--help'.\n", &arg[12..])))?),
            _ if arg.starts_with("--enable=") => parse_groups(&arg[9..], "--enable", &mut cli.enable)?,
            _ if arg.starts_with("--disable=") => parse_groups(&arg[10..], "--disable", &mut cli.disable)?,
            _ if arg.starts_with('-') => {
                return Err((2, format!("error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n")));
            }
            _ => {
                if cli.file.is_none() {
                    cli.file = Some(arg);
                } else {
                    return Err((2, "error: unexpected argument found\n\nUsage: executable [OPTIONS] [FILE]\n\nFor more information, try '--help'.\n".to_string()));
                }
            }
        }
    }
    Ok(cli)
}

fn take_value<I: Iterator<Item = String>>(args: &mut std::iter::Peekable<I>, flag: &str) -> Result<String, (i32, String)> {
    args.next().ok_or_else(|| (2, format!("error: a value is required for '{flag} <VALUE>' but none was supplied\n\nFor more information, try '--help'.\n")))
}

fn parse_groups(input: &str, flag: &str, out: &mut Vec<Group>) -> Result<(), (i32, String)> {
    for raw in input.split(',') {
        let g = Group::parse(raw).ok_or_else(|| {
            (2, format!("error: invalid value '{raw}' for '{flag} <HIGHLIGHTERS>'\n  [possible values: {GROUPS}]\n\nFor more information, try '--help'.\n"))
        })?;
        out.push(g);
    }
    Ok(())
}

fn parse_highlight(s: &str) -> Result<CustomHighlight, String> {
    let (color, rest) = s
        .split_once(':')
        .ok_or_else(|| "Highlights must be in the form color:word1,word2".to_string())?;
    let code = match color {
        "red" => "\x1b[31m",
        "green" => "\x1b[32m",
        "yellow" => "\x1b[33m",
        "blue" => "\x1b[34m",
        "magenta" => "\x1b[35m",
        "cyan" => "\x1b[36m",
        other => return Err(format!("invalid variant: {other}")),
    };
    Ok(CustomHighlight {
        color: code,
        words: rest.split(',').filter(|w| !w.is_empty()).map(ToOwned::to_owned).collect(),
    })
}

fn short_help() -> String {
    "A log file highlighter\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]  Filepath\n\nOptions:\n  -f, --follow\n          Follow the contents of a file\n  -p, --print\n          Print the output to stdout\n      --config-path <CONFIG_PATH>\n          Provide a custom path to a configuration file\n  -e, --exec <EXEC>\n          Run command and view the output in a pager\n      --highlight <COLOR_WORD>\n          Highlights in the form color:word1,word2\n      --enable <ENABLED_HIGHLIGHTERS>\n          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,\n          quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n      --disable <DISABLED_HIGHLIGHTERS>\n          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,\n          quotes, key-value-pairs, uuids, ip-addresses, processes, json]\n      --disable-builtin-keywords\n          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities\n          and common REST verbs)\n      --pager <PAGER>\n          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`) [env:\n          TAILSPIN_PAGER=]\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version\n".to_string()
}

fn long_help() -> String {
    "A log file highlighter\n\nUsage: executable [OPTIONS] [FILE]\n\nArguments:\n  [FILE]\n          Filepath\n\nOptions:\n  -f, --follow\n          Follow the contents of a file\n\n  -p, --print\n          Print the output to stdout\n\n      --config-path <CONFIG_PATH>\n          Provide a custom path to a configuration file\n\n  -e, --exec <EXEC>\n          Run command and view the output in a pager\n\n      --highlight <COLOR_WORD>\n          Highlights in the form color:word1,word2\n          \n          [possible values: red, green, yellow, blue, magenta, cyan]\n\n      --enable <ENABLED_HIGHLIGHTERS>\n          Enable specific highlighters\n          \n          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,\n          ip-addresses, processes, json]\n\n      --disable <DISABLED_HIGHLIGHTERS>\n          Disable specific highlighters\n          \n          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,\n          ip-addresses, processes, json]\n\n      --disable-builtin-keywords\n          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities\n          and common REST verbs)\n\n      --pager <PAGER>\n          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`)\n          \n          [env: TAILSPIN_PAGER=]\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n".to_string()
}

impl Highlighter {
    fn new(cli: &Cli) -> Result<Self, String> {
        if !cli.enable.is_empty() && !cli.disable.is_empty() {
            return Err("  × cannot both enable and disable highlighters".into());
        }
        let all = [
            Group::Numbers, Group::Urls, Group::Pointers, Group::Dates, Group::Paths, Group::Quotes,
            Group::KeyValuePairs, Group::Uuids, Group::IpAddresses, Group::Processes, Group::Json,
        ];
        let mut enabled: HashSet<Group> = if cli.enable.is_empty() { all.iter().cloned().collect() } else { cli.enable.iter().cloned().collect() };
        for g in &cli.disable { enabled.remove(g); }
        Ok(Self {
            custom: cli.highlight.clone(),
            enabled,
            builtin_keywords: !cli.disable_builtin_keywords,
            re_date_iso: Regex::new(r"\b\d{4}[-/]\d{2}[-/]\d{2}(?:T|\s+)?").unwrap(),
            re_date_syslog: Regex::new(r"\b(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)?\s*(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\s+\d{1,2}\b").unwrap(),
            re_time: Regex::new(r"\b\d{1,2}:\d{2}:\d{2}(?:[.,]\d+)?(?:Z)?\b").unwrap(),
            re_uuid: Regex::new(r"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b").unwrap(),
            re_ipv4: Regex::new(r"\b(?:\d{1,3}\.){3}\d{1,3}\b").unwrap(),
            re_ipv6: Regex::new(r"(?i)\b(?:[0-9a-f]{0,4}:){2,}[0-9a-f:.%]+\b").unwrap(),
            re_url: Regex::new(r#"https?://[^\s\]"'<>]+"#).unwrap(),
            re_path: Regex::new(r#"(?:[A-Za-z]:\\[^\s"']+|/(?:[A-Za-z0-9._-]+/?)+)"#).unwrap(),
            re_kv: Regex::new(r"\b[A-Za-z_][A-Za-z0-9_.-]*=").unwrap(),
            re_quote: Regex::new(r#""([^"\\]|\\.)*"|'([^'\\]|\\.)*'"#).unwrap(),
            re_process: Regex::new(r"\[[^\]\n]{1,80}\]|\([A-Za-z0-9_.-]+\)|\b[A-Za-z0-9_.-]+\[\d+\]").unwrap(),
            re_pointer: Regex::new(r"\b(?:0x[0-9a-fA-F]+|[A-Za-z_][A-Za-z0-9_:.-]*\.[A-Za-z0-9_.$:-]+(?::\d+)?)\b").unwrap(),
            re_number: Regex::new(r"\b\d+(?:\.\d+)?\b").unwrap(),
            re_json_punct: Regex::new(r"[{}\[\],:]").unwrap(),
            re_words: Regex::new(r"\b[A-Za-z][A-Za-z0-9_-]*\b").unwrap(),
        })
    }

    fn highlight_line(&self, line: &str) -> String {
        let mut spans = Vec::new();
        for h in &self.custom {
            for word in &h.words {
                let mut pos = 0;
                while let Some(i) = line[pos..].find(word) {
                    let start = pos + i;
                    spans.push(Span { start, end: start + word.len(), style: h.color });
                    pos = start + word.len();
                }
            }
        }
        if self.builtin_keywords {
            for m in self.re_words.find_iter(line) {
                let lower = m.as_str().to_ascii_lowercase();
                let style = match lower.as_str() {
                    "error" | "err" | "fatal" | "panic" | "fail" | "failed" | "failure" | "critical" => Some("\x1b[31m"),
                    "warn" | "warning" => Some("\x1b[33m"),
                    "info" | "notice" => Some("\x1b[32m"),
                    "debug" => Some("\x1b[34m"),
                    "trace" => Some("\x1b[35m"),
                    "true" | "false" | "null" | "none" | "nil" => Some("\x1b[3;31m"),
                    "get" => Some("\x1b[42;30m"),
                    "post" => Some("\x1b[43;30m"),
                    "put" | "patch" => Some("\x1b[44;30m"),
                    "delete" => Some("\x1b[41;30m"),
                    "head" | "options" => Some("\x1b[45;30m"),
                    _ => None,
                };
                if let Some(style) = style {
                    spans.push(Span { start: m.start(), end: m.end(), style });
                }
            }
        }
        self.add(&mut spans, Group::Dates, &self.re_date_iso, "\x1b[35m", line);
        self.add(&mut spans, Group::Dates, &self.re_date_syslog, "\x1b[35m", line);
        self.add(&mut spans, Group::Dates, &self.re_time, "\x1b[34m", line);
        self.add(&mut spans, Group::Urls, &self.re_url, "\x1b[2;34m", line);
        self.add(&mut spans, Group::Paths, &self.re_path, "\x1b[32m", line);
        self.add(&mut spans, Group::Quotes, &self.re_quote, "\x1b[33m", line);
        self.add(&mut spans, Group::KeyValuePairs, &self.re_kv, "\x1b[2m", line);
        self.add(&mut spans, Group::Uuids, &self.re_uuid, "\x1b[3;35m", line);
        self.add(&mut spans, Group::IpAddresses, &self.re_ipv6, "\x1b[3;34m", line);
        self.add(&mut spans, Group::IpAddresses, &self.re_ipv4, "\x1b[3;34m", line);
        self.add(&mut spans, Group::Processes, &self.re_process, "\x1b[36m", line);
        self.add(&mut spans, Group::Pointers, &self.re_pointer, "\x1b[2;36m", line);
        self.add(&mut spans, Group::Numbers, &self.re_number, "\x1b[36m", line);
        self.add(&mut spans, Group::Json, &self.re_json_punct, "\x1b[37m", line);
        render(line, spans)
    }

    fn add(&self, spans: &mut Vec<Span>, group: Group, re: &Regex, style: &'static str, line: &str) {
        if self.enabled.contains(&group) {
            for m in re.find_iter(line) {
                spans.push(Span { start: m.start(), end: m.end(), style });
            }
        }
    }
}

fn render(line: &str, mut spans: Vec<Span>) -> String {
    spans.retain(|s| s.start < s.end && s.end <= line.len());
    spans.sort_by_key(|s| (s.start, usize::MAX - s.end));
    let mut out = String::with_capacity(line.len() + spans.len() * 10);
    let mut pos = 0;
    for span in spans {
        if span.start < pos { continue; }
        out.push_str(&line[pos..span.start]);
        out.push_str(span.style);
        out.push_str(&line[span.start..span.end]);
        out.push_str("\x1b[0m");
        pos = span.end;
    }
    out.push_str(&line[pos..]);
    out
}

fn run(cli: Cli) -> Result<(), String> {
    let highlighter = Highlighter::new(&cli)?;
    if let Some(cmd) = &cli.exec {
        let mut child = Command::new("sh").arg("-c").arg(cmd).stdout(Stdio::piped()).spawn().map_err(|e| format!("  ⚠ {cmd}: {e}"))?;
        if let Some(stdout) = child.stdout.take() {
            process_reader(BufReader::new(stdout), &highlighter)?;
        }
        let _ = child.wait();
        return Ok(());
    }
    if let Some(path) = &cli.file {
        if cli.follow {
            follow_file(path, &highlighter)
        } else {
            let f = File::open(path).map_err(|e| format!("  ⚠ \x1b[33m{path}\x1b[0m: {}", io_error_text(&e)))?;
            process_reader(BufReader::new(f), &highlighter)
        }
    } else {
        let stdin = io::stdin();
        process_reader(stdin.lock(), &highlighter)
    }
}

fn process_reader<R: BufRead>(mut reader: R, highlighter: &Highlighter) -> Result<(), String> {
    let stdout = io::stdout();
    let mut out = stdout.lock();
    let mut line = String::new();
    loop {
        line.clear();
        let n = reader.read_line(&mut line).map_err(|e| e.to_string())?;
        if n == 0 { break; }
        let had_newline = line.ends_with('\n');
        if had_newline {
            while line.ends_with('\n') || line.ends_with('\r') { line.pop(); }
        }
        write!(out, "{}", highlighter.highlight_line(&line)).map_err(|e| e.to_string())?;
        if had_newline { writeln!(out).map_err(|e| e.to_string())?; }
    }
    Ok(())
}

fn follow_file(path: &str, highlighter: &Highlighter) -> Result<(), String> {
    let mut pos = 0;
    loop {
        let mut f = File::open(path).map_err(|e| format!("  ⚠ \x1b[33m{path}\x1b[0m: {}", io_error_text(&e)))?;
        let mut buf = String::new();
        f.read_to_string(&mut buf).map_err(|e| e.to_string())?;
        if pos < buf.len() {
            process_reader(BufReader::new(buf[pos..].as_bytes()), highlighter)?;
            pos = buf.len();
        }
        thread::sleep(Duration::from_millis(500));
    }
}

fn io_error_text(e: &io::Error) -> String {
    match e.kind() {
        io::ErrorKind::NotFound => "No such file or directory".to_string(),
        io::ErrorKind::PermissionDenied => "Permission denied".to_string(),
        _ => e.to_string(),
    }
}
