use chrono::Local;
use std::env;
use std::fs;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::process;
use std::sync::atomic::{AtomicBool, Ordering};
use std::thread;
use std::time::Duration;

const VERSION: &str = "2025.89";
static TERMINATED: AtomicBool = AtomicBool::new(false);

extern "C" fn mark_terminated(_: i32) {
    TERMINATED.store(true, Ordering::SeqCst);
}

const USAGE: &str = "Dropbear server v2025.89 https://matt.ucc.asn.au/dropbear/dropbear.html
Usage: ./executable [options]
-b bannerfile\tDisplay the contents of bannerfile before user login
\t\t(default: none)
-r keyfile      Specify hostkeys (repeatable)
\t\tdefaults: 
\t\t- rsa /etc/dropbear/dropbear_rsa_host_key
\t\t- ecdsa /etc/dropbear/dropbear_ecdsa_host_key
\t\t- ed25519 /etc/dropbear/dropbear_ed25519_host_key
-D\t\tDirectory containing authorized_keys file
-R\t\tCreate hostkeys as required
-F\t\tDon't fork into background
-e\t\tPass on server process environment to child process
(Syslog support not compiled in, using stderr)
-m\t\tDon't display the motd on login
-w\t\tDisallow root logins
-G\t\tRestrict logins to members of specified group
-s\t\tDisable password logins
-g\t\tDisable password logins for root
-B\t\tAllow blank password logins
-t\t\tEnable two-factor authentication (both password and public key required)
-T\t\tMaximum authentication tries (default 10)
-j\t\tDisable local port forwarding
-k\t\tDisable remote port forwarding
-a\t\tAllow connections to forwarded ports from any host
-c command\tForce executed command
-p [address:]port
\t\tListen on specified tcp port (and optionally address),
\t\tup to 10 can be specified
\t\t(default port is 22 if none specified)
-P PidFile\tCreate pid file PidFile
\t\t(default /var/run/dropbear.pid)
-l <interface>
\t\tinterface to bind on
-i\t\tStart for inetd
-W <receive_window_buffer> (default 24576, larger may be faster, max 10MB)
-K <keepalive>  (0 is never, default 0, in seconds)
-I <idle_timeout>  (0 is never, default 0, in seconds)
-z    disable QoS
-V    Version
";

#[derive(Default)]
struct Opts {
    foreground: bool,
    create_keys: bool,
    inetd: bool,
    ports: Vec<String>,
    hostkeys: Vec<String>,
    pidfile: Option<String>,
}

fn log_line(message: &str) {
    let ts = Local::now().format("%b %e %H:%M:%S").to_string().replace("  ", " ");
    eprintln!("[{}] {} {}", process::id(), ts, message);
}

fn usage() {
    print!("{}", USAGE);
}

fn need_arg(args: &[String], i: &mut usize, rest: &str) -> Result<String, i32> {
    if !rest.is_empty() {
        return Ok(rest.to_string());
    }
    *i += 1;
    if *i >= args.len() {
        log_line("Early exit: Missing argument");
        return Err(1);
    }
    Ok(args[*i].clone())
}

fn nonneg_number(s: &str) -> bool {
    !s.is_empty() && s.bytes().all(|b| b.is_ascii_digit())
}

fn parse_args() -> Result<Opts, i32> {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut opts = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--help" || arg == "--version" {
            println!("Invalid option --");
            usage();
            return Err(1);
        }
        if !arg.starts_with('-') || arg == "-" {
            log_line(&format!("Early exit: Invalid argument: {}", arg));
            return Err(1);
        }
        let bytes = arg.as_bytes();
        let mut pos = 1;
        while pos < bytes.len() {
            let ch = bytes[pos] as char;
            let rest = &arg[pos + 1..];
            match ch {
                'V' => {
                    println!("Dropbear v{}", VERSION);
                    return Err(0);
                }
                'h' => {
                    usage();
                    return Err(0);
                }
                'R' => opts.create_keys = true,
                'F' => opts.foreground = true,
                'e' | 'm' | 'w' | 's' | 'g' | 'B' | 't' | 'j' | 'k' | 'a' | 'z' => {}
                'i' => opts.inetd = true,
                'b' | 'D' | 'G' => {
                    let _ = need_arg(&args, &mut i, rest)?;
                    break;
                }
                'r' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    opts.hostkeys.push(v);
                    break;
                }
                'p' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    opts.ports.push(v);
                    break;
                }
                'P' => {
                    opts.pidfile = Some(need_arg(&args, &mut i, rest)?);
                    break;
                }
                'c' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    log_line(&format!("Forced command set to '{}'", v));
                    break;
                }
                'l' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    log_line(&format!("Binding to interface '{}'", v));
                    break;
                }
                'T' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    if !nonneg_number(&v) {
                        log_line(&format!("Early exit: Bad maxauthtries '{}'", v));
                        return Err(1);
                    }
                    break;
                }
                'K' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    if !nonneg_number(&v) {
                        log_line(&format!("Early exit: Bad keepalive '{}'", v));
                        return Err(1);
                    }
                    break;
                }
                'I' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    if !nonneg_number(&v) {
                        log_line(&format!("Early exit: Bad idle_timeout '{}'", v));
                        return Err(1);
                    }
                    break;
                }
                'W' => {
                    let v = need_arg(&args, &mut i, rest)?;
                    let parsed = v.parse::<i64>().ok();
                    if !matches!(parsed, Some(1..=10_485_760)) {
                        let fallback = if matches!(parsed, Some(n) if n > 10_485_760) {
                            10_485_760
                        } else {
                            24_576
                        };
                        log_line(&format!("Bad recv window '{}', using {}", v, fallback));
                    }
                    break;
                }
                other => {
                    eprintln!("Invalid option -{}", other);
                    usage();
                    return Err(1);
                }
            }
            pos += 1;
        }
        i += 1;
    }
    Ok(opts)
}

fn hostkey_failure(opts: &Opts) -> ! {
    let keys = if opts.hostkeys.is_empty() {
        vec![
            "/etc/dropbear/dropbear_rsa_host_key".to_string(),
            "/etc/dropbear/dropbear_ecdsa_host_key".to_string(),
            "/etc/dropbear/dropbear_ed25519_host_key".to_string(),
        ]
    } else {
        opts.hostkeys.clone()
    };
    for key in keys {
        log_line(&format!("Failed loading {}", key));
    }
    log_line("Early exit: No hostkeys available. 'dropbear -R' may be useful or run dropbearkey.");
    process::exit(1);
}

fn parse_bind(spec: &str) -> String {
    if spec.is_empty() {
        return "0.0.0.0:22".to_string();
    }
    if spec.contains(':') {
        spec.to_string()
    } else {
        format!("0.0.0.0:{}", spec)
    }
}

fn handle_client(mut stream: TcpStream) {
    let peer = stream.peer_addr().map(|p| p.to_string()).unwrap_or_else(|_| "unknown".to_string());
    log_line(&format!("Child connection from {}", peer));
    let _ = stream.write_all(b"SSH-2.0-dropbear_2025.89\r\n");
    let _ = stream.set_read_timeout(Some(Duration::from_secs(1)));
    let mut buf = [0u8; 512];
    let _ = stream.read(&mut buf);
    log_line(&format!("Exit before auth from <{}>: Exited normally", peer));
}

fn run_server(opts: Opts) -> ! {
    if opts.inetd {
        log_line("Early exit: Failed socket address: Socket operation on non-socket");
        process::exit(1);
    }
    if let Some(path) = &opts.pidfile {
        let _ = fs::write(path, format!("{}\n", process::id()));
    }
    if opts.foreground {
        log_line("Not backgrounding");
    } else {
        log_line("Running in background");
        process::exit(0);
    }

    let specs = if opts.ports.is_empty() {
        vec!["22".to_string()]
    } else {
        opts.ports.clone()
    };
    let mut listeners = Vec::new();
    for spec in specs {
        if let Ok(listener) = TcpListener::bind(parse_bind(&spec)) {
            let _ = listener.set_nonblocking(false);
            listeners.push(listener);
        }
    }
    if listeners.is_empty() {
        loop {
            if TERMINATED.load(Ordering::SeqCst) {
                log_line("Early exit: Terminated by signal");
                process::exit(1);
            }
            thread::sleep(Duration::from_secs(1));
        }
    }
    for listener in listeners {
        thread::spawn(move || {
            for stream in listener.incoming().flatten() {
                thread::spawn(move || handle_client(stream));
            }
        });
    }
    loop {
        if TERMINATED.load(Ordering::SeqCst) {
            log_line("Early exit: Terminated by signal");
            process::exit(1);
        }
        thread::sleep(Duration::from_secs(1));
    }
}

fn main() {
    unsafe {
        libc::signal(libc::SIGTERM, mark_terminated as usize);
        libc::signal(libc::SIGINT, mark_terminated as usize);
    }
    let opts = match parse_args() {
        Ok(o) => o,
        Err(code) => process::exit(code),
    };
    if !opts.create_keys {
        hostkey_failure(&opts);
    }
    run_server(opts);
}
