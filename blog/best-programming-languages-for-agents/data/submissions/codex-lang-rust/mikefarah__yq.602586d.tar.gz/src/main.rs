use serde_json::{Map, Number, Value};
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::Path;

#[derive(Debug, Clone)]
struct Opts {
    expr: Option<String>,
    files: Vec<String>,
    cmd: String,
    input_format: String,
    output_format: String,
    inplace: bool,
    null_input: bool,
    exit_status: bool,
    no_doc: bool,
    nul: bool,
    indent: usize,
    from_file: Option<String>,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let code = match run(args) {
        Ok(code) => code,
        Err(e) => {
            eprintln!("Error: {}", e);
            1
        }
    };
    std::process::exit(code);
}

fn run(args: Vec<String>) -> Result<i32, String> {
    if args.len() == 1 {
        print_help();
        return Ok(0);
    }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        if args.get(1).map(|s| s.as_str()) == Some("eval") || args.get(1).map(|s| s.as_str()) == Some("e") {
            print_eval_help();
        } else if args.get(1).map(|s| s.as_str()) == Some("eval-all") || args.get(1).map(|s| s.as_str()) == Some("ea") {
            print_eval_all_help();
        } else {
            print_help();
        }
        return Ok(0);
    }
    if args.iter().any(|a| a == "--version" || a == "-V") {
        println!("yq (https://github.com/mikefarah/yq/) version v4.52.5");
        return Ok(0);
    }
    if args.get(1).map(|s| s.as_str()) == Some("completion") {
        println!("# completion is not available in this reimplementation");
        return Ok(0);
    }

    let opts = parse_args(&args[1..])?;
    let expr = if let Some(f) = &opts.from_file {
        fs::read_to_string(f).map_err(|e| format!("{}: {}", f, e))?
    } else {
        opts.expr.clone().unwrap_or_else(|| ".".to_string())
    };

    if opts.inplace {
        let file = opts.files.first().ok_or("write in place flag only applicable when giving an expression and at least one file")?;
        let mut doc = read_doc(file, &opts.input_format)?;
        let results = eval_expr(&expr, &mut doc, &opts)?;
        let out = format_value(results.first().unwrap_or(&doc), output_kind(&opts, file), opts.indent, false);
        fs::write(file, ensure_nl(out)).map_err(|e| format!("{}: {}", file, e))?;
        return Ok(0);
    }

    let mut docs = Vec::new();
    if opts.null_input {
        docs.push(Value::Null);
    } else if opts.files.is_empty() {
        docs.push(read_stdin(&opts.input_format)?);
    } else {
        for f in &opts.files {
            docs.push(read_doc(f, &opts.input_format)?);
        }
    }

    let mut outputs = Vec::new();
    if opts.cmd == "eval-all" || opts.cmd == "ea" {
        if expr.contains("ireduce") || expr.contains(" * ") {
            let mut merged = Value::Object(Map::new());
            for d in docs {
                merge_values(&mut merged, d);
            }
            outputs.push(merged);
        } else {
            let mut doc = Value::Array(docs);
            outputs = eval_expr(&expr, &mut doc, &opts)?;
        }
    } else if opts.null_input && expr.contains("load(") {
        let mut doc = eval_loads(&expr, &opts)?;
        outputs.push(doc.clone());
        let _ = eval_expr(&expr, &mut doc, &opts);
    } else {
        for mut doc in docs {
            outputs.extend(eval_expr(&expr, &mut doc, &opts)?);
        }
    }

    let mut status = 0;
    if opts.exit_status && (outputs.is_empty() || outputs.iter().any(|v| matches!(v, Value::Null | Value::Bool(false)))) {
        status = 1;
    }
    let sep = if opts.nul { "\0" } else { "\n" };
    let kind = output_kind(&opts, opts.files.first().map(String::as_str).unwrap_or(""));
    for (i, v) in outputs.iter().enumerate() {
        if i > 0 {
            print!("{}", sep);
        }
        print!("{}", format_value(v, kind, opts.indent, scalar_context(v)));
    }
    if !opts.nul {
        println!();
    }
    io::stdout().flush().ok();
    if status != 0 {
        eprintln!("Error: no matches found");
    }
    Ok(status)
}

fn parse_args(args: &[String]) -> Result<Opts, String> {
    let mut opts = Opts {
        expr: None,
        files: Vec::new(),
        cmd: "eval".to_string(),
        input_format: "auto".to_string(),
        output_format: "auto".to_string(),
        inplace: false,
        null_input: false,
        exit_status: false,
        no_doc: false,
        nul: false,
        indent: 2,
        from_file: None,
    };
    let mut pos = Vec::new();
    let mut i = 0;
    if matches!(args.get(0).map(|s| s.as_str()), Some("eval" | "e" | "eval-all" | "ea")) {
        opts.cmd = args[0].clone();
        i = 1;
    }
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-i" | "--inplace" => opts.inplace = true,
            "-n" | "--null-input" => opts.null_input = true,
            "-e" | "--exit-status" => opts.exit_status = true,
            "-N" | "--no-doc" => opts.no_doc = true,
            "-0" | "--nul-output" => opts.nul = true,
            "-P" | "--prettyPrint" => {}
            "-M" | "--no-colors" | "-C" | "--colors" | "-r" | "--unwrapScalar" | "-v" | "--verbose"
            | "--csv-auto-parse" | "--tsv-auto-parse" | "--header-preprocess" | "--xml-keep-namespace"
            | "--xml-raw-token" | "--yaml-compact-seq-indent" | "--yaml-fix-merge-anchor-to-spec"
            | "--security-disable-env-ops" | "--security-disable-file-ops" | "--security-enable-system-operator"
            | "--xml-skip-directives" | "--xml-skip-proc-inst" | "--xml-strict-mode" => {}
            "-p" | "--input-format" => {
                i += 1;
                opts.input_format = args.get(i).ok_or("missing input format")?.clone();
            }
            "-o" | "--output-format" => {
                i += 1;
                opts.output_format = args.get(i).ok_or("missing output format")?.clone();
            }
            "-I" | "--indent" => {
                i += 1;
                opts.indent = args.get(i).and_then(|s| s.parse().ok()).unwrap_or(2);
            }
            "--expression" => {
                i += 1;
                opts.expr = Some(args.get(i).ok_or("missing expression")?.clone());
            }
            "--from-file" => {
                i += 1;
                opts.from_file = Some(args.get(i).ok_or("missing expression file")?.clone());
            }
            "-f" | "--front-matter" | "-s" | "--split-exp" | "--split-exp-file" | "--csv-separator"
            | "--properties-separator" | "--lua-prefix" | "--lua-suffix" | "--shell-key-separator"
            | "--xml-attribute-prefix" | "--xml-content-name" | "--xml-directive-name"
            | "--xml-proc-inst-prefix" => { i += 1; }
            _ if a.starts_with("-o=") => opts.output_format = a[3..].to_string(),
            _ if a.starts_with("-p=") => opts.input_format = a[3..].to_string(),
            _ if a.starts_with("-o") && a.len() > 2 => opts.output_format = a[2..].to_string(),
            _ if a.starts_with("-p") && a.len() > 2 => opts.input_format = a[2..].to_string(),
            _ if a.starts_with("--output-format=") => opts.output_format = a[16..].to_string(),
            _ if a.starts_with("--input-format=") => opts.input_format = a[15..].to_string(),
            _ if a == "--" => {}
            _ if a.starts_with('-') && a.len() > 2 && !a.starts_with("--") => {
                for ch in a[1..].chars() {
                    match ch {
                        'i' => opts.inplace = true,
                        'n' => opts.null_input = true,
                        'e' => opts.exit_status = true,
                        'N' => opts.no_doc = true,
                        '0' => opts.nul = true,
                        'P' | 'M' | 'C' | 'r' | 'v' => {}
                        _ => {}
                    }
                }
            }
            _ => pos.push(a.clone()),
        }
        i += 1;
    }
    if opts.expr.is_none() && opts.from_file.is_none() {
        if pos.len() == 1 && !opts.null_input && Path::new(&pos[0]).exists() {
            opts.expr = Some(".".to_string());
            opts.files.push(pos.remove(0));
        } else if !pos.is_empty() {
            opts.expr = Some(pos.remove(0));
            opts.files = pos;
        } else {
            opts.expr = Some(".".to_string());
        }
    } else {
        opts.files = pos;
    }
    Ok(opts)
}

fn output_kind(opts: &Opts, file: &str) -> &'static str {
    let s = opts.output_format.as_str();
    if matches!(s, "json" | "j") { "json" }
    else if matches!(s, "props" | "properties" | "p") { "props" }
    else if matches!(s, "shell" | "s") { "shell" }
    else if matches!(s, "csv" | "c") { "csv" }
    else if matches!(s, "tsv" | "t") { "tsv" }
    else if matches!(s, "base64") { "base64" }
    else if s == "uri" { "uri" }
    else if matches!(s, "yaml" | "y" | "auto" | "a" | "") {
        if s == "auto" || s == "a" {
            let ext = Path::new(file).extension().and_then(|e| e.to_str()).unwrap_or("");
            if ext.eq_ignore_ascii_case("json") { "json" } else { "yaml" }
        } else { "yaml" }
    } else { "yaml" }
}

fn read_doc(file: &str, fmt: &str) -> Result<Value, String> {
    let s = if file == "-" {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        s
    } else {
        fs::read_to_string(file).map_err(|e| format!("{}: {}", file, e))?
    };
    parse_input(&s, fmt, file)
}

fn read_stdin(fmt: &str) -> Result<Value, String> {
    let mut s = String::new();
    io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
    parse_input(&s, fmt, "")
}

fn parse_input(s: &str, fmt: &str, file: &str) -> Result<Value, String> {
    let kind = if matches!(fmt, "json" | "j") || (matches!(fmt, "auto" | "a") && file.ends_with(".json")) {
        "json"
    } else if matches!(fmt, "csv" | "c") || (matches!(fmt, "auto" | "a") && file.ends_with(".csv")) {
        "csv"
    } else if matches!(fmt, "tsv" | "t") || (matches!(fmt, "auto" | "a") && file.ends_with(".tsv")) {
        "tsv"
    } else if matches!(fmt, "props" | "properties" | "p") || file.ends_with(".properties") {
        "props"
    } else {
        let trimmed = s.trim_start();
        if trimmed.starts_with('{') || trimmed.starts_with('[') { "json" } else { "yaml" }
    };
    match kind {
        "json" => serde_json::from_str(s).map_err(|e| e.to_string()),
        "csv" => Ok(parse_delim(s, ',')),
        "tsv" => Ok(parse_delim(s, '\t')),
        "props" => Ok(parse_props(s)),
        _ => Ok(parse_yaml(s)),
    }
}

fn parse_yaml(s: &str) -> Value {
    let lines: Vec<(usize, String)> = s.lines()
        .filter_map(|raw| {
            let no_comment = strip_comment(raw);
            if no_comment.trim().is_empty() || no_comment.trim() == "---" || no_comment.trim() == "..." { None }
            else { Some((no_comment.chars().take_while(|c| *c == ' ').count(), no_comment.trim().to_string())) }
        }).collect();
    let mut idx = 0;
    parse_block(&lines, &mut idx, 0)
}

fn strip_comment(s: &str) -> String {
    let mut in_s = false;
    let mut in_d = false;
    for (i, c) in s.char_indices() {
        match c {
            '\'' if !in_d => in_s = !in_s,
            '"' if !in_s => in_d = !in_d,
            '#' if !in_s && !in_d && (i == 0 || s[..i].ends_with(' ')) => return s[..i].to_string(),
            _ => {}
        }
    }
    s.to_string()
}

fn parse_block(lines: &[(usize, String)], idx: &mut usize, indent: usize) -> Value {
    if *idx >= lines.len() { return Value::Null; }
    if lines[*idx].0 < indent { return Value::Null; }
    if lines[*idx].1.starts_with("- ") && lines[*idx].0 == indent {
        let mut arr = Vec::new();
        while *idx < lines.len() && lines[*idx].0 == indent && lines[*idx].1.starts_with("- ") {
            let item = lines[*idx].1[2..].trim().to_string();
            *idx += 1;
            let mut val = if item.is_empty() {
                parse_block(lines, idx, indent + 2)
            } else if let Some((k, rest)) = split_keyval(&item) {
                let mut m = Map::new();
                if rest.trim().is_empty() {
                    let child = parse_block(lines, idx, indent + 2);
                    m.insert(k, child);
                } else {
                    m.insert(k, parse_scalar(rest.trim()));
                }
                Value::Object(m)
            } else {
                parse_scalar(&item)
            };
            while *idx < lines.len() && lines[*idx].0 > indent {
                if let Value::Object(m) = &mut val {
                    parse_map_entries(lines, idx, lines[*idx].0, m);
                } else {
                    break;
                }
            }
            arr.push(val);
        }
        Value::Array(arr)
    } else {
        let mut m = Map::new();
        parse_map_entries(lines, idx, indent, &mut m);
        Value::Object(m)
    }
}

fn parse_map_entries(lines: &[(usize, String)], idx: &mut usize, indent: usize, m: &mut Map<String, Value>) {
    while *idx < lines.len() && lines[*idx].0 == indent && !lines[*idx].1.starts_with("- ") {
        let text = lines[*idx].1.clone();
        *idx += 1;
        if let Some((k, rest)) = split_keyval(&text) {
            let v = if rest.trim().is_empty() {
                parse_block(lines, idx, indent + 2)
            } else {
                parse_scalar(rest.trim())
            };
            m.insert(k, v);
        }
    }
}

fn split_keyval(s: &str) -> Option<(String, String)> {
    let mut in_s = false;
    let mut in_d = false;
    for (i, c) in s.char_indices() {
        match c {
            '\'' if !in_d => in_s = !in_s,
            '"' if !in_s => in_d = !in_d,
            ':' if !in_s && !in_d => {
                let after = s[i+1..].chars().next();
                if after.map(|ch| ch.is_whitespace()).unwrap_or(true) {
                    return Some((unquote(s[..i].trim()).to_string(), s[i+1..].trim().to_string()));
                }
            }
            _ => {}
        }
    }
    None
}

fn parse_scalar(s: &str) -> Value {
    let s = s.trim();
    if s == "null" || s == "~" { Value::Null }
    else if s == "true" { Value::Bool(true) }
    else if s == "false" { Value::Bool(false) }
    else if let Ok(i) = s.parse::<i64>() { Value::Number(i.into()) }
    else if let Ok(f) = s.parse::<f64>() { Number::from_f64(f).map(Value::Number).unwrap_or(Value::String(s.to_string())) }
    else if (s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\'')) { Value::String(unquote(s).to_string()) }
    else if s.starts_with('[') || s.starts_with('{') { serde_json::from_str(s).unwrap_or_else(|_| Value::String(s.to_string())) }
    else { Value::String(s.to_string()) }
}

fn unquote(s: &str) -> &str {
    if s.len() >= 2 && ((s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\''))) {
        &s[1..s.len()-1]
    } else { s }
}

fn parse_delim(s: &str, sep: char) -> Value {
    let mut rows = s.lines().filter(|l| !l.trim().is_empty());
    let headers: Vec<String> = rows.next().unwrap_or("").split(sep).map(|x| x.trim().to_string()).collect();
    Value::Array(rows.map(|line| {
        let mut m = Map::new();
        for (h, v) in headers.iter().zip(line.split(sep)) {
            m.insert(h.clone(), parse_scalar(v.trim()));
        }
        Value::Object(m)
    }).collect())
}

fn parse_props(s: &str) -> Value {
    let mut root = Value::Object(Map::new());
    for line in s.lines() {
        let t = line.trim();
        if t.is_empty() || t.starts_with('#') { continue; }
        let (k, v) = t.split_once('=').or_else(|| t.split_once(':')).unwrap_or((t, ""));
        set_path(&mut root, &parse_path(&format!(".{}", k.trim())), parse_scalar(v.trim()));
    }
    root
}

#[derive(Debug, Clone)]
enum Step { Key(String), Index(usize), Each }

fn parse_path(path: &str) -> Vec<Step> {
    let mut steps = Vec::new();
    let mut i = 0;
    let chars: Vec<char> = path.trim().chars().collect();
    if chars.get(0) == Some(&'.') { i = 1; }
    while i < chars.len() {
        if chars[i] == '.' { i += 1; continue; }
        if chars[i] == '[' {
            if i + 1 < chars.len() && chars[i+1] == ']' {
                steps.push(Step::Each);
                i += 2;
            } else {
                let mut j = i + 1;
                while j < chars.len() && chars[j] != ']' { j += 1; }
                let n: usize = chars[i+1..j].iter().collect::<String>().parse().unwrap_or(0);
                steps.push(Step::Index(n));
                i = j + 1;
            }
        } else {
            let start = i;
            while i < chars.len() && chars[i] != '.' && chars[i] != '[' { i += 1; }
            steps.push(Step::Key(chars[start..i].iter().collect()));
        }
    }
    steps
}

fn eval_expr(expr: &str, doc: &mut Value, opts: &Opts) -> Result<Vec<Value>, String> {
    let expr = expr.trim();
    if expr.is_empty() || expr == "." { return Ok(vec![doc.clone()]); }
    if expr.contains('|') && expr.contains('=') && !expr.contains("==") {
        let mut cur = doc.clone();
        for part in expr.split('|') {
            if let Some((lhs, rhs)) = split_assign(part) {
                let v = eval_rhs(rhs.trim());
                set_path(&mut cur, &parse_path(lhs.trim()), v);
            }
        }
        *doc = cur.clone();
        return Ok(vec![cur]);
    }
    if let Some((lhs, rhs)) = split_assign(expr) {
        let v = eval_rhs(rhs.trim());
        set_path(doc, &parse_path(lhs.trim()), v);
        return Ok(vec![doc.clone()]);
    }
    if expr.starts_with('[') && expr.ends_with(']') {
        let inner = &expr[1..expr.len()-1];
        return Ok(vec![Value::Array(eval_pipeline(inner, doc)?)]);
    }
    if expr.contains('|') {
        return eval_pipeline(expr, doc);
    }
    if expr.contains("load(") {
        return Ok(vec![eval_loads(expr, opts)?]);
    }
    Ok(select_path(doc, &parse_path(expr)))
}

fn split_assign(s: &str) -> Option<(&str, &str)> {
    let mut in_s = false;
    let mut in_d = false;
    let bytes = s.as_bytes();
    for (i, c) in s.char_indices() {
        match c {
            '\'' if !in_d => in_s = !in_s,
            '"' if !in_s => in_d = !in_d,
            '=' if !in_s && !in_d && bytes.get(i+1) != Some(&b'=') && i > 0 && bytes.get(i-1) != Some(&b'=') => {
                return Some((&s[..i], &s[i+1..]));
            }
            _ => {}
        }
    }
    None
}

fn eval_rhs(rhs: &str) -> Value {
    let rhs = rhs.trim();
    if rhs.starts_with("strenv(") && rhs.ends_with(')') {
        let name = &rhs[7..rhs.len()-1];
        Value::String(env::var(name).unwrap_or_default())
    } else if rhs.starts_with("env(") && rhs.ends_with(')') {
        let name = &rhs[4..rhs.len()-1];
        parse_scalar(&env::var(name).unwrap_or_default())
    } else {
        parse_scalar(rhs)
    }
}

fn eval_pipeline(expr: &str, doc: &Value) -> Result<Vec<Value>, String> {
    let mut vals = vec![doc.clone()];
    for part in expr.split('|').map(str::trim) {
        if part.starts_with("select(") {
            let cond = part.trim_start_matches("select(").trim_end_matches(')');
            vals = vals.into_iter().filter(|v| test_cond(v, cond)).collect();
        } else if part == "." {
        } else {
            let steps = parse_path(part);
            let mut next = Vec::new();
            for v in &vals {
                next.extend(select_path(v, &steps));
            }
            vals = next;
        }
    }
    Ok(vals)
}

fn test_cond(v: &Value, cond: &str) -> bool {
    if let Some((lhs, rhs)) = cond.split_once("==") {
        let got = select_path(v, &parse_path(lhs.trim())).into_iter().next().unwrap_or(Value::Null);
        got == parse_scalar(rhs.trim())
    } else if let Some((lhs, rhs)) = cond.split_once("!=") {
        let got = select_path(v, &parse_path(lhs.trim())).into_iter().next().unwrap_or(Value::Null);
        got != parse_scalar(rhs.trim())
    } else {
        !matches!(select_path(v, &parse_path(cond)).into_iter().next(), Some(Value::Null) | None | Some(Value::Bool(false)))
    }
}

fn select_path(v: &Value, steps: &[Step]) -> Vec<Value> {
    if steps.is_empty() { return vec![v.clone()]; }
    match &steps[0] {
        Step::Key(k) => match v {
            Value::Object(m) => select_path(m.get(k).unwrap_or(&Value::Null), &steps[1..]),
            _ => vec![Value::Null],
        },
        Step::Index(i) => match v {
            Value::Array(a) => select_path(a.get(*i).unwrap_or(&Value::Null), &steps[1..]),
            _ => vec![Value::Null],
        },
        Step::Each => match v {
            Value::Array(a) => a.iter().flat_map(|x| select_path(x, &steps[1..])).collect(),
            Value::Object(m) => m.values().flat_map(|x| select_path(x, &steps[1..])).collect(),
            _ => vec![],
        },
    }
}

fn set_path(root: &mut Value, steps: &[Step], val: Value) {
    if steps.is_empty() {
        *root = val;
        return;
    }
    match &steps[0] {
        Step::Key(k) => {
            if !root.is_object() { *root = Value::Object(Map::new()); }
            let m = root.as_object_mut().unwrap();
            let child = m.entry(k.clone()).or_insert(Value::Null);
            set_path(child, &steps[1..], val);
        }
        Step::Index(i) => {
            if !root.is_array() { *root = Value::Array(Vec::new()); }
            let a = root.as_array_mut().unwrap();
            while a.len() <= *i { a.push(Value::Null); }
            set_path(&mut a[*i], &steps[1..], val);
        }
        Step::Each => {
            if let Value::Array(a) = root {
                for item in a {
                    set_path(item, &steps[1..], val.clone());
                }
            }
        }
    }
}

fn eval_loads(expr: &str, opts: &Opts) -> Result<Value, String> {
    let mut docs = Vec::new();
    let mut rest = expr;
    while let Some(pos) = rest.find("load(") {
        rest = &rest[pos+5..];
        let quote = rest.chars().next().unwrap_or('"');
        if quote != '"' && quote != '\'' { break; }
        if let Some(end) = rest[1..].find(quote) {
            let path = &rest[1..1+end];
            docs.push(read_doc(path, &opts.input_format)?);
            rest = &rest[1+end+1..];
        } else { break; }
    }
    let mut merged = Value::Object(Map::new());
    for d in docs {
        merge_values(&mut merged, d);
    }
    Ok(merged)
}

fn merge_values(a: &mut Value, b: Value) {
    match (a, b) {
        (Value::Object(am), Value::Object(bm)) => {
            for (k, bv) in bm {
                if let Some(av) = am.get_mut(&k) {
                    merge_values(av, bv);
                } else {
                    am.insert(k, bv);
                }
            }
        }
        (a_slot, bv) => *a_slot = bv,
    }
}

fn scalar_context(v: &Value) -> bool {
    matches!(v, Value::String(_) | Value::Number(_) | Value::Bool(_) | Value::Null)
}

fn format_value(v: &Value, kind: &str, indent: usize, unwrap_scalar: bool) -> String {
    match kind {
        "json" => serde_json::to_string_pretty(v).unwrap_or_else(|_| "null".to_string()),
        "props" => {
            let mut out = Vec::new();
            flatten_props("", v, &mut out, " = ");
            out.join("\n")
        }
        "shell" => {
            let mut out = Vec::new();
            flatten_props("", v, &mut out, "=");
            out.into_iter().map(|l| l.replace('.', "_")).collect::<Vec<_>>().join("\n")
        }
        "csv" => format_delim(v, ','),
        "tsv" => format_delim(v, '\t'),
        "base64" => {
            if let Value::String(s) = v { base64_simple(s.as_bytes()) } else { base64_simple(format_value(v, "yaml", indent, false).as_bytes()) }
        }
        "uri" => {
            if let Value::String(s) = v { uri_encode(s) } else { uri_encode(&format_value(v, "yaml", indent, false)) }
        }
        _ if unwrap_scalar => scalar_string(v),
        _ => yaml_value(v, 0, indent),
    }
}

fn ensure_nl(mut s: String) -> String {
    if !s.ends_with('\n') { s.push('\n'); }
    s
}

fn scalar_string(v: &Value) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => s.clone(),
        _ => yaml_value(v, 0, 2),
    }
}

fn yaml_value(v: &Value, level: usize, ind: usize) -> String {
    match v {
        Value::Null | Value::Bool(_) | Value::Number(_) | Value::String(_) => scalar_yaml(v),
        Value::Array(a) => {
            if a.is_empty() { return "[]".to_string(); }
            let mut lines = Vec::new();
            for item in a {
                match item {
                    Value::Object(m) if !m.is_empty() => {
                        let pad = " ".repeat(level);
                        let mut iter = m.iter();
                        let (k, first) = iter.next().unwrap();
                        if scalar_context(first) {
                            lines.push(format!("{}- {}: {}", pad, quote_key(k), scalar_yaml(first)));
                        } else {
                            lines.push(format!("{}- {}:", pad, quote_key(k)));
                            lines.push(yaml_value(first, level + ind, ind));
                        }
                        for (kk, vv) in iter {
                            if scalar_context(vv) {
                                lines.push(format!("{}{}: {}", " ".repeat(level + ind), quote_key(kk), scalar_yaml(vv)));
                            } else {
                                lines.push(format!("{}{}:", " ".repeat(level + ind), quote_key(kk)));
                                lines.push(yaml_value(vv, level + ind * 2, ind));
                            }
                        }
                    }
                    _ if scalar_context(item) => lines.push(format!("{}- {}", " ".repeat(level), scalar_yaml(item))),
                    _ => {
                        lines.push(format!("{}-", " ".repeat(level)));
                        lines.push(yaml_value(item, level + ind, ind));
                    }
                }
            }
            lines.join("\n")
        }
        Value::Object(m) => {
            if m.is_empty() { return "{}".to_string(); }
            let mut lines = Vec::new();
            for (k, val) in m {
                if scalar_context(val) {
                    lines.push(format!("{}{}: {}", " ".repeat(level), quote_key(k), scalar_yaml(val)));
                } else {
                    lines.push(format!("{}{}:", " ".repeat(level), quote_key(k)));
                    lines.push(yaml_value(val, level + ind, ind));
                }
            }
            lines.join("\n")
        }
    }
}

fn quote_key(k: &str) -> String {
    if k.chars().all(|c| c.is_alphanumeric() || c == '_' || c == '-') { k.to_string() } else { format!("{:?}", k) }
}

fn scalar_yaml(v: &Value) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => {
            if s.is_empty() || s.contains('\n') || matches!(s.as_str(), "true" | "false" | "null" | "~") || s.starts_with(' ') || s.ends_with(' ') {
                serde_json::to_string(s).unwrap()
            } else {
                s.clone()
            }
        }
        _ => unreachable!(),
    }
}

fn flatten_props(prefix: &str, v: &Value, out: &mut Vec<String>, sep: &str) {
    match v {
        Value::Object(m) => for (k, val) in m {
            let p = if prefix.is_empty() { k.clone() } else { format!("{}.{}", prefix, k) };
            flatten_props(&p, val, out, sep);
        },
        Value::Array(a) => for (i, val) in a.iter().enumerate() {
            flatten_props(&format!("{}[{}]", prefix, i), val, out, sep);
        },
        _ => out.push(format!("{}{}{}", prefix, sep, scalar_string(v))),
    }
}

fn format_delim(v: &Value, sep: char) -> String {
    let arr = match v { Value::Array(a) => a, _ => return scalar_string(v) };
    let mut headers = Vec::<String>::new();
    for item in arr {
        if let Value::Object(m) = item {
            for k in m.keys() {
                if !headers.contains(k) { headers.push(k.clone()); }
            }
        }
    }
    let mut lines = vec![headers.join(&sep.to_string())];
    for item in arr {
        let mut row = Vec::new();
        for h in &headers {
            row.push(match item { Value::Object(m) => m.get(h).map(scalar_string).unwrap_or_default(), _ => scalar_string(item) });
        }
        lines.push(row.join(&sep.to_string()));
    }
    lines.join("\n")
}

fn base64_simple(bytes: &[u8]) -> String {
    const T: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::new();
    let mut i = 0;
    while i < bytes.len() {
        let b0 = bytes[i];
        let b1 = *bytes.get(i+1).unwrap_or(&0);
        let b2 = *bytes.get(i+2).unwrap_or(&0);
        out.push(T[(b0 >> 2) as usize] as char);
        out.push(T[(((b0 & 3) << 4) | (b1 >> 4)) as usize] as char);
        out.push(if i + 1 < bytes.len() { T[(((b1 & 15) << 2) | (b2 >> 6)) as usize] as char } else { '=' });
        out.push(if i + 2 < bytes.len() { T[(b2 & 63) as usize] as char } else { '=' });
        i += 3;
    }
    out
}

fn uri_encode(s: &str) -> String {
    let mut out = String::new();
    for b in s.bytes() {
        if b.is_ascii_alphanumeric() || b"-_.~".contains(&b) {
            out.push(b as char);
        } else {
            out.push_str(&format!("%{:02X}", b));
        }
    }
    out
}

fn print_help() {
    println!("yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) ");
    println!("See https://mikefarah.gitbook.io/yq/ for detailed documentation and examples.\n");
    println!("Usage:\n  yq [flags]\n  yq [command]\n");
    println!("Available Commands:\n  completion  Generate the autocompletion script for the specified shell\n  eval        (default) Apply the expression to each document in each yaml file in sequence\n  eval-all    Loads _all_ yaml documents of _all_ yaml files and runs expression once\n  help        Help about any command\n");
    println!("Flags:\n  -e, --exit-status                       set exit status if there are no matches or null or false is returned\n  -h, --help                              help for yq\n  -i, --inplace                           update the file in place of first file given.\n  -n, --null-input                        Don't read input, simply evaluate the expression given.\n  -o, --output-format string              output format type. (default \"auto\")\n  -p, --input-format string               parse format for input. (default \"auto\")\n  -V, --version                           Print version information and quit");
    println!("\nUse \"yq [command] --help\" for more information about a command.");
}

fn print_eval_help() {
    println!("yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) \n\n## Evaluate Sequence ##\nThis command iterates over each yaml document from each given file, applies the \nexpression and prints the result in sequence.\n\nUsage:\n  yq eval [expression] [yaml_file1]... [flags]\n\nAliases:\n  eval, e");
}

fn print_eval_all_help() {
    println!("yq is a portable command-line data file processor (https://github.com/mikefarah/yq/) \n\n## Evaluate All ##\nThis command loads _all_ yaml documents of _all_ yaml files and runs expression once\n\nUsage:\n  yq eval-all [expression] [yaml_file1]... [flags]\n\nAliases:\n  eval-all, ea");
}
