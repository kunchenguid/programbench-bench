use std::env;
use std::fs;
use std::io::{self, Write};
use std::time::{SystemTime, UNIX_EPOCH};

#[derive(Default, Clone)]
struct Config {
    echo: bool,
    help: bool,
    nmap: bool,
    version: bool,
    selftest: bool,
    iflist: bool,
    readscan: Option<String>,
    seed: Option<String>,
    rate: String,
    shard: String,
    ports_raw: Vec<String>,
    ranges: Vec<String>,
    output_filename: Option<String>,
    output_format: Option<String>,
    output_append: bool,
    banners: bool,
    adapter_ip: Option<String>,
    adapter_mac: Option<String>,
    router_mac: Option<String>,
    captures: Vec<(bool, String)>,
    errors: Vec<String>,
    fatal_parse: bool,
}

impl Config {
    fn new() -> Self {
        Self { rate: "100".to_string(), shard: "1/1".to_string(), ..Default::default() }
    }
}

fn main() {
    let mut cfg = Config::new();
    let args: Vec<String> = env::args().skip(1).collect();
    parse_args(&mut cfg, &args);

    for e in &cfg.errors { println!("{}", e); }
    if cfg.fatal_parse { return; }

    if cfg.version { print_version(); return; }
    if cfg.help { print_help(); return; }
    if cfg.nmap { print_nmap(); return; }

    if cfg.selftest {
        print_pcap_fail();
        println!("regression test: success!");
        return;
    }
    if cfg.iflist {
        print_pcap_fail();
        println!("libpcap not loaded");
        return;
    }
    if let Some(file) = &cfg.readscan {
        print_pcap_fail();
        println!("[+] --readscan {}", file);
        match fs::read(file) {
            Ok(bytes) if bytes.starts_with(b"masscan/1.1") => write_empty_output(&cfg),
            Ok(_) => println!("[-] {}: unknown file format (expeced \"masscan/1.1\")", file),
            Err(e) => println!("[-] {}: {}", file, e),
        }
        return;
    }
    if cfg.echo {
        print_pcap_fail();
        print_echo(&cfg);
        return;
    }

    print_pcap_fail();
    if cfg.ports_raw.is_empty() && cfg.ranges.is_empty() {
        print_short_usage();
    } else if cfg.ranges.is_empty() {
        println!("FAIL: target IP address list empty");
        println!(" [hint] try something like \"--range 10.0.0.0/8\"");
        println!(" [hint] try something like \"--range 192.168.0.100-192.168.0.200\"");
    } else if normalized_ports(&cfg.ports_raw).is_empty() {
        println!("FAIL: no ports were specified");
        println!(" [hint] try something like \"-p80,8000-9000\"");
        println!(" [hint] try something like \"--ports 0-65535\"");
    } else if let Some(fmt) = &cfg.output_format {
        if let Some(name) = &cfg.output_filename {
            if name != "-" { let _ = fs::write(name, empty_content(fmt)); }
        }
    }
}

fn parse_args(cfg: &mut Config, args: &[String]) {
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--" { i += 1; continue; }
        if arg == "--help" || arg == "-h" { cfg.help = true; i += 1; continue; }
        if arg == "--nmap" { cfg.nmap = true; i += 1; continue; }
        if arg == "--version" || arg == "-V" { cfg.version = true; i += 1; continue; }
        if arg == "--echo" { cfg.echo = true; i += 1; continue; }
        if arg == "--selftest" || arg == "--regress" { cfg.selftest = true; i += 1; continue; }
        if arg == "--iflist" { cfg.iflist = true; i += 1; continue; }
        if arg == "--banners" { cfg.banners = true; i += 1; continue; }
        if arg == "--open" || arg == "--packet-trace" { i += 1; continue; }
        if arg == "--append-output" { cfg.output_append = true; i += 1; continue; }
        if arg == "-sS" || arg == "-Pn" || arg == "-n" || arg == "--send-eth" || arg == "--randomize-hosts" { i += 1; continue; }
        if arg == "-v" || arg == "-d" || arg.chars().all(|c| c == 'v' || c == '-') || arg.chars().all(|c| c == 'd' || c == '-') { i += 1; continue; }

        if let Some((k, v)) = arg.strip_prefix("--").and_then(|s| s.split_once('=')) {
            apply_option(cfg, k, Some(v.to_string())); i += 1; continue;
        }
        if arg.starts_with("-p") && arg.len() > 2 { apply_option(cfg, "ports", Some(arg[2..].to_string())); i += 1; continue; }
        if is_output_short(arg) {
            let fmt = match arg.as_str() { "-oX"=>"xml", "-oG"=>"grepable", "-oJ"=>"json", "-oL"=>"list", "-oB"=>"binary", "-oD"=>"ndjson", "-oU"=>"unicornscan", _=>"" };
            cfg.output_format = Some(fmt.to_string());
            if let Some(v) = args.get(i+1) { cfg.output_filename = Some(v.clone()); i += 2; } else { println!("{}: empty parameter", &arg[1..]); i += 1; }
            continue;
        }
        if arg.starts_with('-') {
            let key = arg.trim_start_matches('-');
            let needs = takes_value(key);
            if needs {
                if let Some(v) = args.get(i+1) { apply_option(cfg, key, Some(v.clone())); i += 2; } else { println!("{}: empty parameter", key); i += 1; }
            } else if known_flag(key) { apply_option(cfg, key, None); i += 1; }
            else { println!("{}: empty parameter", key); i += 1; }
            continue;
        }
        if looks_like_range(arg) { cfg.ranges.push(arg.clone()); } else { println!("FAIL: unknown command-line parameter \"{}\"", arg); println!(" [hint] did you want \"--{}\"?", arg); cfg.fatal_parse = true; }
        i += 1;
    }
}

fn takes_value(k: &str) -> bool {
    matches!(k, "p"|"ports"|"rate"|"max-rate"|"c"|"conf"|"config"|"seed"|"shard"|"output-format"|"output-filename"|"output-file"|"readscan"|"adapter-ip"|"adapter-mac"|"router-mac"|"source-ip"|"S"|"source-port"|"g"|"e"|"ttl"|"spoof-mac"|"exclude"|"excludefile"|"exclude-file"|"include-file"|"iL"|"capture"|"nocapture"|"hello-file"|"connection-timeout")
}
fn known_flag(k: &str) -> bool { matches!(k, "echo"|"banners"|"open"|"append-output"|"packet-trace") }
fn is_output_short(s: &str) -> bool { matches!(s, "-oX"|"-oG"|"-oJ"|"-oL"|"-oB"|"-oD"|"-oU") }

fn apply_option(cfg: &mut Config, key: &str, val: Option<String>) {
    match key {
        "p"|"ports" => if let Some(v) = val { cfg.ports_raw.push(v); },
        "rate"|"max-rate" => if let Some(v) = val { if v.chars().all(|c| c.is_ascii_digit() || c=='.') { cfg.rate = trim_float(&v); } else { cfg.errors.push(format!("CONF: non-digit in rate spec: rate={}", v)); } },
        "c"|"conf"|"config" => if let Some(v) = val { parse_config_file(cfg, &v); },
        "seed" => cfg.seed = val,
        "shard" => if let Some(v) = val { cfg.shard = v; },
        "output-format" => cfg.output_format = val,
        "output-filename"|"output-file" => cfg.output_filename = val,
        "readscan" => cfg.readscan = val,
        "adapter-ip" => cfg.adapter_ip = val,
        "adapter-mac" => cfg.adapter_mac = val.map(|v| v.replace(':', "-")),
        "router-mac" => cfg.router_mac = val.map(|v| v.replace(':', "-")),
        "exclude" => {},
        "excludefile"|"exclude-file" => {},
        "include-file"|"iL" => if let Some(v) = val { include_ranges(cfg, &v); },
        "capture" => if let Some(v) = val { cfg.captures.push((true, v)); },
        "nocapture" => if let Some(v) = val { cfg.captures.push((false, v)); },
        "hello-file" => if let Some(v) = val { if let Err(e) = fs::read(&v) { cfg.errors.push("[-] [FAILED] --hello-file".to_string()); cfg.errors.push(format!("[-] {}: {}", v, e)); } },
        "banners" => cfg.banners = true,
        "append-output" => cfg.output_append = true,
        _ => {}
    }
}

fn parse_config_file(cfg: &mut Config, path: &str) {
    match fs::read_to_string(path) {
        Ok(s) => for line in s.lines() {
            let l = line.split('#').next().unwrap_or("").trim();
            if l.is_empty() { continue; }
            let (k, v) = if let Some((k,v)) = l.split_once('=') { (k.trim(), v.trim()) } else { let mut sp = l.splitn(2, char::is_whitespace); (sp.next().unwrap_or(""), sp.next().unwrap_or("").trim()) };
            apply_config_key(cfg, k, v);
        },
        Err(e) => { cfg.errors.push(format!("[-] FAIL: could not open configuration file")); cfg.errors.push(format!("[-] {}: {}", path, e)); }
    }
}
fn apply_config_key(cfg: &mut Config, key: &str, v: &str) {
    match key {
        "range" => cfg.ranges.push(v.to_string()),
        "ports" => cfg.ports_raw.push(v.to_string()),
        _ => apply_option(cfg, key, Some(v.to_string())),
    }
}
fn include_ranges(cfg: &mut Config, path: &str) {
    match fs::read_to_string(path) {
        Ok(s) => for line in s.lines() { let l=line.split('#').next().unwrap_or("").trim(); if !l.is_empty() { cfg.ranges.push(l.to_string()); } },
        Err(e) => { cfg.errors.push("[-] FAIL: parsing IP addresses".to_string()); cfg.errors.push(format!("[-] {}: {}", path, e)); cfg.fatal_parse = true; }
    }
}

fn looks_like_range(s: &str) -> bool { s.chars().any(|c| c.is_ascii_digit()) && s.chars().any(|c| c=='.' || c==':' || c=='/' || c=='-') }
fn trim_float(s: &str) -> String { if s.ends_with(".00") { s.trim_end_matches('0').trim_end_matches('.').to_string() } else { s.to_string() } }
fn seed() -> String { SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos().to_string() }

fn normalized_ports(raw: &[String]) -> String {
    let mut tcp = Vec::new(); let mut udp = Vec::new();
    for r in raw { for part in r.split(',') { let p = part.trim(); if p.is_empty(){continue;} let up=p.to_ascii_uppercase(); let (is_udp, val) = if up.starts_with("U:") { (true, &p[2..]) } else if up.starts_with("T:") { (false, &p[2..]) } else { (false, p) }; if valid_port_expr(val) { if is_udp { udp.push(format!("U:{}", val)); } else { tcp.push(val.to_string()); } } } }
    tcp.extend(udp); tcp.join(",")
}
fn valid_port_expr(s: &str) -> bool { !s.is_empty() && s.chars().all(|c| c.is_ascii_digit() || c=='-') && s.chars().any(|c| c.is_ascii_digit()) }

fn print_pcap_fail() { println!("[-] FAIL: failed to load libpcap shared library"); println!("    [hint]: you must install libpcap or WinPcap"); }
fn print_echo(cfg: &Config) {
    println!("seed = {}", cfg.seed.clone().unwrap_or_else(seed));
    println!("rate = {:<10}", cfg.rate);
    println!("shard = {}", cfg.shard);
    if cfg.banners { println!("banners = true"); }
    if cfg.captures.is_empty() { println!("nocapture = servername"); println!("nocapture = servername"); } else { for (on, name) in &cfg.captures { println!("{} = {}", if *on {"capture"} else {"nocapture"}, name); } println!("nocapture = servername"); for (on, name) in &cfg.captures { if *on { println!("capture = {}", name); } } }
    println!();
    if cfg.output_append { println!("output-append = true"); }
    if let Some(f) = &cfg.output_filename { println!("output-filename = {}", f); }
    if let Some(f) = &cfg.output_format { println!("output-format = {}", f); }
    println!();
    if cfg.adapter_ip.is_some() || cfg.adapter_mac.is_some() || cfg.router_mac.is_some() {
        if let Some(v)=&cfg.adapter_ip { println!("adapter-ip = {}", v); }
        if let Some(v)=&cfg.adapter_mac { println!("adapter-mac = {}", v); }
        if let Some(v)=&cfg.router_mac { println!("router-mac-ipv4 = {}", v); println!("router-mac-ipv6 = {}", v); }
    }
    println!("# TARGET SELECTION (IP, PORTS, EXCLUDES)");
    println!("ports = {}", normalized_ports(&cfg.ports_raw));
    for r in &cfg.ranges { println!("range = {}", r); }
}

fn print_version() {
    println!("Masscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )");
    println!("Compiled on: Apr 17 2026 19:59:25");
    println!("Compiler: gcc 11.4.0");
    println!("OS: Linux");
    println!("CPU: x86 (64 bits)");
    println!("GIT version: unknown");
}
fn print_help() { print!("{}", HELP); }
fn print_short_usage() { print!("{}", SHORT_USAGE); }
fn print_nmap() { print!("{}", NMAP); }
fn empty_content(fmt: &str) -> &'static [u8] { match fmt { "xml" => b"<?xml version=\"1.0\"?>\n<masscan>\n</masscan>\n", "json" => b"[\n]\n", "list"|"grepable"|"ndjson"|"unicornscan" => b"", "binary" => b"masscan/1.1\n", _ => b"" } }
fn write_empty_output(cfg: &Config) { if let Some(fmt)=&cfg.output_format { let data=empty_content(fmt); if let Some(name)=&cfg.output_filename { if name == "-" { let _=io::stdout().write_all(data); } else { let _=fs::write(name, data); } } } }

const HELP: &str = "usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]\nMASSCAN is a fast port scanner. The primary input parameters are the\nIP addresses/ranges you want to scan, and the port numbers. An example\nis the following, which scans the 10.x.x.x network for web servers:\n\n    masscan 10.0.0.0/8 -p80\n\nThe program auto-detects network interface/adapter settings. If this\nfails, you'll have to set these manually. The following is an\nexample of all the parameters that are needed:\n\n    --adapter-ip 192.168.10.123\n    --adapter-mac 00-11-22-33-44-55\n    --router-mac 66-55-44-33-22-11\n\nParameters can be set either via the command-line or config-file. The\nnames are the same for both. Thus, the above adapter settings would\nappear as follows in a configuration file:\n\n    adapter-ip = 192.168.10.123\n    adapter-mac = 00-11-22-33-44-55\n    router-mac = 66-55-44-33-22-11\n\nAll single-dash parameters have a spelled out double-dash equivalent,\nso '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).\nTo use the config file, type:\n\n    masscan -c <filename>\n\nTo generate a config-file from the current settings, use the --echo\noption. This stops the program from actually running, and just echoes\nthe current configuration instead. This is a useful way to generate\nyour first config file, or see a list of parameters you didn't know\nabout. I suggest you try it now:\n\n    masscan -p1234 --echo\n\n";
const SHORT_USAGE: &str = "usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]\n\nexamples:\n    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000\n        scan some web ports on 10.x.x.x at 10kpps\n\n    masscan --nmap\n        list those options that are compatible with nmap\n\n    masscan -p80 10.0.0.0/8 --banners -oB <filename>\n        save results of scan in binary format to <filename>\n\n    masscan --open --banners --readscan <filename> -oX <savefile>\n        read binary scan results in <filename> and save them as xml in <savefile>\n";
const NMAP: &str = "Masscan (https://github.com/robertdavidgraham/masscan)\nUsage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}\nTARGET SPECIFICATION:\n  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)\n  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254\n  -iL <inputfilename>: Input from list of hosts/networks\n  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks\n  --excludefile <exclude_file>: Exclude list from file\n  --randomize-hosts: Randomize order of hosts (default)\nHOST DISCOVERY:\n  -Pn: Treat all hosts as online (default)\n  -n: Never do DNS resolution (default)\nSCAN TECHNIQUES:\n  -sS: TCP SYN (always on, default)\nSERVICE/VERSION DETECTION:\n  --banners: get the banners of the listening service if available. The\n    default timeout for waiting to receive data is 30 seconds.\nPORT SPECIFICATION AND SCAN ORDER:\n  -p <port ranges>: Only scan specified ports\n    Ex: -p22; -p1-65535; -p 111,137,80,139,8080\nTIMING AND PERFORMANCE:\n  --max-rate <number>: Send packets no faster than <number> per second\n  --connection-timeout <number>: time in seconds a TCP connection will\n    timeout while waiting for banner data from a port.\nFIREWALL/IDS EVASION AND SPOOFING:\n  -S/--source-ip <IP_Address>: Spoof source address\n  -e <iface>: Use specified interface\n  -g/--source-port <portnum>: Use given port number\n  --ttl <val>: Set IP time-to-live field\n  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address\nOUTPUT:\n  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml\n  --output-file <file>: Write scan results to file. If --output-format is\n     not given default is xml\n  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,\n     respectively, to the given filename. Shortcut for\n     --output-format <format> --output-file <file>\n  -v: Increase verbosity level (use -vv or more for greater effect)\n  -d: Increase debugging level (use -dd or more for greater effect)\n  --open: Only show open (or possibly open) ports\n  --packet-trace: Show all packets sent and received\n  --iflist: Print host interfaces and routes (for debugging)\n  --append-output: Append to rather than clobber specified output files\n  --resume <filename>: Resume an aborted scan\nMISC:\n  --send-eth: Send using raw ethernet frames (default)\n  -V: Print version number\n  -h: Print this help summary page.\nEXAMPLES:\n  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80\n  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan\n  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable\nSEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP\n";
