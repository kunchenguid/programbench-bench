use regex::Regex;
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::process;

const HELP: &str = "A CLI wrapping the Melody language compiler

Usage: executable [OPTIONS] [INPUT_FILE_PATH]

Arguments:
  [INPUT_FILE_PATH]  Read from a file
                     Use '-' and or pipe input to read from stdin

Options:
  -o, --output <OUTPUT_FILE_PATH>           Write to a file
  -n, --no-color                            Print output with no color
  -r, --repl                                Start the Melody REPL
      --generate-completions <completions>  Outputs completions for the selected shell
                                            To use, write the output to the appropriate location for your shell
  -t, --test <test>                         Test the compiled regex against a string
  -f, --test-file <test-file>               Test the compiled regex against the contents of a file
  -h, --help                                Print help
  -V, --version                             Print version
";

#[derive(Default)]
struct Opts {
    input: Option<String>,
    output: Option<String>,
    test: Option<String>,
    test_file: Option<String>,
    repl: bool,
    completions: Option<String>,
}

fn main() {
    let opts = parse_args();
    if opts.repl {
        repl();
        return;
    }
    if let Some(shell) = opts.completions {
        completions(&shell);
        return;
    }
    let source = match read_source(opts.input.as_deref()) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("Error: {}", e);
            process::exit(65);
        }
    };
    let regex = match compile(&source) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("Error: {}", e);
            process::exit(65);
        }
    };
    if let Some(path) = opts.output {
        if let Err(_) = fs::write(&path, &regex) {
            eprintln!("Error: {}", path);
            process::exit(74);
        }
    } else if let Some(s) = opts.test {
        println!("'{}' {}", s, if is_match(&regex, &s) { "matched" } else { "did not match" });
    } else if let Some(path) = opts.test_file {
        match fs::read_to_string(&path) {
            Ok(s) => println!("{} {}", path, if is_match(&regex, &s) { "matched" } else { "did not match" }),
            Err(_) => {
                eprintln!("Error: unable read file at path {}", path);
                process::exit(65);
            }
        }
    } else {
        println!("{}", regex);
    }
}

fn parse_args() -> Opts {
    let mut opts = Opts::default();
    let mut args = env::args().skip(1).peekable();
    while let Some(a) = args.next() {
        match a.as_str() {
            "-h" | "--help" => {
                print!("{}", HELP);
                process::exit(0);
            }
            "-V" | "--version" => {
                println!("melody_cli 0.20.0");
                process::exit(0);
            }
            "-n" | "--no-color" => {}
            "-r" | "--repl" => opts.repl = true,
            "-o" | "--output" => opts.output = args.next(),
            "-t" | "--test" => opts.test = args.next(),
            "-f" | "--test-file" => opts.test_file = args.next(),
            "--generate-completions" => opts.completions = args.next(),
            _ if a.starts_with('-') && a != "-" => {
                eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] [INPUT_FILE_PATH]\n\nFor more information, try '--help'.", a);
                process::exit(2);
            }
            _ => opts.input = Some(a),
        }
    }
    opts
}

fn read_source(input: Option<&str>) -> Result<String, String> {
    match input {
        Some("-") => {
            let mut s = String::new();
            io::stdin().read_to_string(&mut s).map_err(|_| "unable read stdin".to_string())?;
            Ok(s)
        }
        Some(p) => fs::read_to_string(p).map_err(|_| format!("unable read file at path {}", p)),
        None => {
            let mut s = String::new();
            io::stdin().read_to_string(&mut s).map_err(|_| "unable read stdin".to_string())?;
            Ok(s)
        }
    }
}

fn is_match(pattern: &str, text: &str) -> bool {
    Regex::new(pattern).map(|r| r.is_match(text)).unwrap_or_else(|_| text.contains(pattern))
}

fn repl() {
    let mut line = String::new();
    loop {
        print!("> ");
        let _ = io::stdout().flush();
        line.clear();
        if io::stdin().read_line(&mut line).unwrap_or(0) == 0 {
            break;
        }
        match compile(&line) {
            Ok(r) => println!("{}", r),
            Err(e) => eprintln!("Error: {}", e),
        }
    }
}

fn completions(shell: &str) {
    match shell {
        "bash" => println!("_melody() {{\n    COMPREPLY=()\n}}\ncomplete -F _melody melody"),
        "zsh" => println!("#compdef melody\n_arguments '*::arg:_files'"),
        "fish" => println!("complete -c melody -s o -l output -d 'Write to a file' -r"),
        "elvish" | "powershell" => println!(""),
        other => println!("Unknown or unsupported shell: '{}'\nTry one of: 'bash', 'zsh', 'fish', 'elvish', 'powershell'", other),
    }
}

fn compile(src: &str) -> Result<String, String> {
    let mut p = Parser { s: src, pos: 0 };
    let out = p.parse_until(None)?;
    p.ws();
    if !p.eof() {
        return Err(p.err("expected EOI, literal, raw, not, range, quantifier_quantity, group_declaration, assertion_declaration, variable_declaration, or variable_invocation"));
    }
    if out.is_empty() {
        return Err(p.err("expected root"));
    }
    Ok(out)
}

struct Parser<'a> {
    s: &'a str,
    pos: usize,
}

impl<'a> Parser<'a> {
    fn eof(&self) -> bool { self.pos >= self.s.len() }
    fn rest(&self) -> &'a str { &self.s[self.pos..] }
    fn peek(&self) -> Option<char> { self.rest().chars().next() }
    fn bump(&mut self) -> Option<char> {
        let c = self.peek()?;
        self.pos += c.len_utf8();
        Some(c)
    }
    fn ws(&mut self) {
        loop {
            while self.peek().map(|c| c.is_whitespace()).unwrap_or(false) { self.bump(); }
            if self.rest().starts_with("//") {
                while let Some(c) = self.bump() { if c == '\n' { break; } }
            } else if self.rest().starts_with("/*") {
                self.pos += 2;
                while !self.eof() && !self.rest().starts_with("*/") { self.bump(); }
                if self.rest().starts_with("*/") { self.pos += 2; }
            } else { break; }
        }
    }
    fn parse_until(&mut self, end: Option<char>) -> Result<String, String> {
        let mut out = String::new();
        loop {
            self.ws();
            if self.eof() { break; }
            if let Some(e) = end {
                if self.peek() == Some(e) {
                    self.bump();
                    break;
                }
            }
            out.push_str(&self.expr()?);
            self.ws();
            if self.peek() == Some(';') { self.bump(); }
        }
        Ok(out)
    }
    fn expr(&mut self) -> Result<String, String> {
        self.ws();
        if let Some(q) = self.quant()? {
            self.need_word("of")?;
            let atom = self.expr()?;
            return Ok(apply_quant(atom, &q));
        }
        if self.word_is("match") { self.word(); return self.block_seq().map(|x| format!("(?:{})", x)); }
        if self.word_is("either") { self.word(); return self.either(); }
        if self.word_is("capture") { self.word(); return self.capture(); }
        if self.word_is("ahead") { self.word(); return self.look("(?=", ")"); }
        if self.word_is("behind") { self.word(); return self.look("(?<=", ")"); }
        if self.word_is("not") {
            self.word();
            if self.word_is("ahead") { self.word(); return self.look("(?!", ")"); }
            if self.word_is("behind") { self.word(); return self.look("(?<!", ")"); }
            return self.negated_class();
        }
        match self.peek() {
            Some('"') | Some('\'') => self.quoted(true),
            Some('`') => self.quoted(false),
            Some('<') => self.symbol(false),
            _ => Err(self.err("expected root")),
        }
    }
    fn quant(&mut self) -> Result<Option<String>, String> {
        self.ws();
        if self.word_is("some") { self.word(); return Ok(Some("+".into())); }
        if self.word_is("any") { self.word(); return Ok(Some("*".into())); }
        if self.word_is("option") { self.word(); return Ok(Some("?".into())); }
        let save = self.pos;
        if let Some(a) = self.number() {
            self.ws();
            if self.word_is("to") {
                self.word();
                self.ws();
                if let Some(b) = self.number() {
                    return Ok(Some(format!("{{{},{}}}", a, b)));
                }
                self.pos = save;
                return Ok(None);
            }
            return Ok(Some(format!("{{{}}}", a)));
        }
        Ok(None)
    }
    fn number(&mut self) -> Option<String> {
        let start = self.pos;
        while self.peek().map(|c| c.is_ascii_digit()).unwrap_or(false) { self.bump(); }
        if self.pos > start { Some(self.s[start..self.pos].to_string()) } else { None }
    }
    fn block_seq(&mut self) -> Result<String, String> {
        self.ws();
        if self.bump() != Some('{') { return Err(self.err("expected block")); }
        self.parse_until(Some('}'))
    }
    fn either(&mut self) -> Result<String, String> {
        self.ws();
        if self.bump() != Some('{') { return Err(self.err("expected block")); }
        let mut parts = Vec::new();
        loop {
            self.ws();
            if self.peek() == Some('}') { self.bump(); break; }
            parts.push(self.expr()?);
            self.ws();
            if self.peek() == Some(';') { self.bump(); }
        }
        Ok(format!("(?:{})", parts.join("|")))
    }
    fn capture(&mut self) -> Result<String, String> {
        self.ws();
        let mut name = None;
        if self.peek() != Some('{') {
            let start = self.pos;
            while !self.eof() && self.peek() != Some('{') { self.bump(); }
            let n = self.s[start..self.pos].trim();
            if !n.is_empty() { name = Some(n.to_string()); }
        }
        let inner = self.block_seq()?;
        Ok(match name { Some(n) => format!("(?<{}>{})", n, inner), None => format!("({})", inner) })
    }
    fn look(&mut self, pre: &str, post: &str) -> Result<String, String> {
        let inner = self.block_seq()?;
        Ok(format!("{}{}{}", pre, inner, post))
    }
    fn negated_class(&mut self) -> Result<String, String> {
        self.ws();
        if self.peek() == Some('<') {
            let sym = self.symbol_name()?;
            return Ok(match sym.as_str() {
                "digit" => "\\D".into(),
                "whitespace" => "\\S".into(),
                "word" => "\\W".into(),
                "space" => "[^ ]".into(),
                "char" => "[^.]".into(),
                _ => format!("[^{}]", escape_class(&sym)),
            });
        }
        let start = self.pos;
        while !self.eof() && self.peek() != Some(';') && self.peek() != Some('}') { self.bump(); }
        let mut content = self.s[start..self.pos].trim().to_string();
        if let Some((a, b)) = split_to(&content) { content = format!("{}-{}", a, b); }
        Ok(format!("[^{}]", escape_class(&content)))
    }
    fn symbol(&mut self, _neg: bool) -> Result<String, String> {
        let name = self.symbol_name()?;
        match name.as_str() {
            "char" => Ok(".".into()),
            "space" => Ok(" ".into()),
            "whitespace" => Ok("\\s".into()),
            "digit" => Ok("\\d".into()),
            "word" => Ok("\\w".into()),
            "newline" => Ok("\\n".into()),
            "tab" => Ok("\\t".into()),
            "return" => Ok("\\r".into()),
            "feed" => Ok("\\f".into()),
            "null" => Ok("\\0".into()),
            "backspace" => Ok("[\\b]".into()),
            "alphabetic" | "letter" => Ok("[a-zA-Z]".into()),
            "alphanumeric" => Ok("[a-zA-Z0-9]".into()),
            "boundary" => Ok("\\b".into()),
            "start" => Ok("^".into()),
            "end" => Ok("$".into()),
            _ => Err("usage of an unrecognized symbol".into()),
        }
    }
    fn symbol_name(&mut self) -> Result<String, String> {
        if self.bump() != Some('<') { return Err(self.err("expected symbol")); }
        let start = self.pos;
        while !self.eof() && self.peek() != Some('>') { self.bump(); }
        let name = self.s[start..self.pos].trim().to_string();
        if self.peek() == Some('>') { self.bump(); }
        Ok(name)
    }
    fn quoted(&mut self, escape_regex: bool) -> Result<String, String> {
        let quote = self.bump().unwrap();
        let mut val = String::new();
        while let Some(c) = self.bump() {
            if c == quote { break; }
            if c == '\\' {
                if let Some(n) = self.bump() { val.push(match n { 'n' => '\n', 't' => '\t', 'r' => '\r', x => x }); }
            } else { val.push(c); }
        }
        if escape_regex { Ok(escape_regex_literal(&val)) } else { Ok(val) }
    }
    fn word_is(&mut self, w: &str) -> bool {
        self.ws();
        let r = self.rest();
        r.starts_with(w) && r[w.len()..].chars().next().map(|c| !is_ident(c)).unwrap_or(true)
    }
    fn word(&mut self) -> String {
        self.ws();
        let start = self.pos;
        while self.peek().map(is_ident).unwrap_or(false) { self.bump(); }
        self.s[start..self.pos].to_string()
    }
    fn need_word(&mut self, w: &str) -> Result<(), String> {
        if self.word_is(w) { self.word(); Ok(()) } else { Err(self.err("expected of")) }
    }
    fn err(&self, msg: &str) -> String { msg.to_string() }
}

fn is_ident(c: char) -> bool { c.is_ascii_alphanumeric() || c == '_' }

fn apply_quant(atom: String, q: &str) -> String {
    let simple = atom == "." || atom == " " || atom.starts_with('(') || atom.starts_with('\\') && atom.len() <= 2 || (atom.starts_with('[') && atom.ends_with(']'));
    if simple { format!("{}{}", atom, q) } else { format!("(?:{}){}", atom, q) }
}

fn escape_regex_literal(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        match c {
            '.'|'*'|'+'|'?'|'('|')'|'['|']'|'{'|'}'|'\\'|'^'|'$'|'|' => { out.push('\\'); out.push(c); }
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            c => out.push(c),
        }
    }
    out
}

fn escape_class(s: &str) -> String {
    s.replace('\\', "\\\\").replace(']', "\\]")
}

fn split_to(s: &str) -> Option<(String, String)> {
    let parts: Vec<_> = s.split_whitespace().collect();
    if parts.len() == 3 && parts[1] == "to" {
        Some((parts[0].to_string(), parts[2].to_string()))
    } else { None }
}
