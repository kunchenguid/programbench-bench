use chrono::Local;
use libc::{ioctl, winsize, STDIN_FILENO, STDOUT_FILENO, TIOCGWINSZ};
use std::env;
use std::ffi::OsStr;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::os::unix::ffi::OsStrExt;
use std::path::{Path, PathBuf};
use std::process::Command;

const HELP: &str = r#"# felix v2.16.1
A simple TUI file manager with vim-like keymapping.

## Usage
`fx` => Show items in the current directory.
`fx <directory path>` => Show items in the path.
Both relative and absolute path available.

## Options
`--help` | `-h`   => Print help.
`--log`  | `-l`   => Launch the app, automatically generating a log file.
`--init`          => Returns a shell script that can be sourcedfor
                     for shell integration.

## Manual
j / <Down>         :Go down.
k / <Up>           :Go up.
<C-d>              :Go down 1/2 page.
<C-u>>             :Go up 1/2 page.
h / <Left>         :Go to the parent directory if exists.
l / <Right> / <CR> :Open item or change directory.
gg                 :Go to the top.
G                  :Go to the bottom.
z<CR>              :Go to the home directory.
z {keyword}<CR>    :Jump to a directory that matches the keyword.
                    (zoxide required)
<C-o>              :Jump backward.
<C-i>              :Jump forward.
i{file name}<CR>   :Create a new empty file.
I{dir name}<CR>    :Create a new empty directory.
o                  :Open item in a new window.
e                  :Unpack archive/compressed file.
dd                 :Delete and yank item.
yy                 :Yank item.
p                  :Put yanked item(s) from register zero
                    in the current directory.
:reg               :Show registers. To hide it, press v.
"ayy               :Yank item to register a.
"add               :Delete and yank item to register a.
"Ayy               :Append item to register a.
"Add               :Delete and append item to register a.
"ap                :Put item(s) from register a.
V                  :Switch to the linewise visual mode.
  - y              :In the visual mode, yank selected item(s).
  - d              :In the visual mode, delete and yank selected item(s).
  - "ay            :In the visual mode, yank items to register a.
  - "ad            :In the visual mode, delete and yank items to register a.
  - "Ay            :In the visual mode, append items to register a.
  - "Ad            :In the visual mode, delete and append items to register a.
  - c              :Rename selected items in default editor.
u                  :Undo put/delete/rename.
<C-r>              :Redo put/delete/rename.
v                  :Toggle whether to show the preview.
s                  :Toggle between vertical / horizontal split in the preview mode.
<Alt-j>
 / <Alt-<Down>>    :Scroll down the preview text.
<Alt-k> 
 / <Alt-<Up>>      :Scroll up the preview text.
<BS>               :Toggle whether to show hidden items.
t                  :Toggle the sort order (name <-> modified time).
c                  :Switch to the rename mode.
/{keyword}         :Search items by a keyword.
n                  :Go forward to the item that matches the keyword.
N                  :Go backward to the item that matches the keyword.
:                  :Switch to the command line.
  - <C-r>a         :In the command line, paste item name in register a.
:cd<CR>            :Go to the home directory.
:cd {path}<CR>     :Go to the path.
:e<CR>             :Reload the current directory.
:config<CR>        :Go to the directory that contains the config file if exists.
:trash<CR>         :Go to the trash directory.
:empty<CR>         :Empty the trash directory.
:h<CR>             :Show help.
:q<CR>             :Exit.
:{command}         :Execute a command e.g. :zip test *.md
<Esc>              :Return to the normal mode.
<C-h>              :Works as Backspace after `i`, `I`, `c`, `/`, `:` and `z`.
ZZ                 :Exit without cd to last working directory
                    (if `match_vim_exit_behavior` is `false`).
ZQ                 :cd into the last working directory and exit
                    (if shell setting is ready and `match_vim_exit_behavior is `false`).

## Preview feature
By default, text files and directories can be previewed.
To preview images, you need to install chafa (>= v1.10.0).
Please see https://hpjansson.org/chafa/

## Configuration

*Both `config.yaml` and `config.yml` work.*

### Linux
config file    : $XDG_CONFIG_HOME/felix/config.yaml(config.yml)
trash directory: $XDG_DATA_HOME/felix/trash
log files      : $XDG_DATA_HOME/felix/log

### macOS
On macOS, felix looks for the config file in the following locations:

1. `$HOME/Library/Application Support/felix/config.yaml(config.yml)`
2. `$HOME/.config/felix/config.yaml`

trash directory: $HOME/Library/Application Support/felix/trash
log files      : $HOME/Library/Application Support/felix/log

### Windows
config file     : $PROFILE\\AppData\\Roaming\\felix\\config.yaml(config.yml)
trash directory : $PROFILE\\AppData\\Local\\felix\\trash
log files       : $PROFILE\\AppData\\Local\\felix\\log

For more details, visit https://github.com/kyoheiu/felix
"#;

const INIT: &str = r#"# To be eval'ed in the calling shell
  eval "$(
    if [ -n "$XDG_RUNTIME_DIR" ]; then
      runtime_dir="$XDG_RUNTIME_DIR/felix"
    elif [ -n "$TMPDIR" ]; then
      runtime_dir="$TMPDIR/felix"
    else
      runtime_dir=/tmp/felix
    fi

    mkdir -p "$runtime_dir"

    # Clean up leftover LWD files
    find "$runtime_dir" -type f -and -mmin +1 -delete

    cat << EOF
fx() {
  local RUNTIME_DIR="$runtime_dir"
  SHELL_PID=\$\$ command fx "\$@"

  if [ -f "\$RUNTIME_DIR/\$\$" ]; then
    cd "\$(cat "\$RUNTIME_DIR/\$\$")"
    rm "\$RUNTIME_DIR/\$\$"
  fi
}
EOF
  )"
"#;

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.len() > 1 {
        print!("{HELP}");
        return;
    }

    match args.first().map(String::as_str) {
        Some("-h") | Some("--help") => print!("{HELP}"),
        Some("--init") => print!("{INIT}"),
        Some("-l") | Some("--log") => {
            create_log_file();
            launch(env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));
        }
        Some(path) => {
            let p = PathBuf::from(path);
            if !p.exists() {
                println!();
                eprintln!("Invalid path: {path}\n`fx -h` shows help.");
            } else if !p.is_dir() {
                eprintln!("Path should be directory.\n`fx -h` shows help.");
            } else {
                launch(p);
            }
        }
        None => launch(env::current_dir().unwrap_or_else(|_| PathBuf::from("."))),
    }
}

fn create_log_file() {
    let base = env::var_os("XDG_DATA_HOME")
        .filter(|v| !v.is_empty())
        .map(PathBuf::from)
        .or_else(|| env::var_os("HOME").map(|h| PathBuf::from(h).join(".local/share")))
        .unwrap_or_else(|| PathBuf::from("."));
    let dir = base.join("felix/log");
    let _ = fs::create_dir_all(&dir);
    let name = Local::now().format("%Y-%m-%d-%H-%M-%S.log").to_string();
    let _ = File::create(dir.join(name));
}

fn launch(mut cwd: PathBuf) {
    let (rows, cols) = match terminal_size() {
        None => {
            eprintln!("Error: Cannot detect terminal size");
            return;
        }
        Some(size) => size,
    };
    if rows < 10 || cols < 40 {
        eprintln!("Error: Too small window size");
        return;
    }

    let mut term = RawMode::new();
    let _ = term.enable();
    let mut selected = 0usize;
    let mut show_hidden = false;
    let mut command = String::new();
    let mut last = 0u8;

    loop {
        let entries = read_entries(&cwd, show_hidden);
        if selected >= entries.len() {
            selected = entries.len().saturating_sub(1);
        }
        draw(&cwd, &entries, selected, show_hidden, rows, cols);

        let b = match read_byte() {
            Some(b) => b,
            None => break,
        };

        match b {
            b'q' if command.is_empty() => break,
            27 => {
                command.clear();
            }
            b'j' => selected = (selected + 1).min(entries.len().saturating_sub(1)),
            b'k' => selected = selected.saturating_sub(1),
            b'G' => selected = entries.len().saturating_sub(1),
            b'g' if last == b'g' => {
                selected = 0;
                last = 0;
                continue;
            }
            b'\r' | b'\n' | b'l' => {
                if !command.is_empty() {
                    if handle_command(&command, &mut cwd) {
                        break;
                    }
                    command.clear();
                } else if let Some(entry) = entries.get(selected) {
                    if entry.path.is_dir() {
                        cwd = entry.path.clone();
                        selected = 0;
                    } else {
                        open_external(&entry.path);
                    }
                }
            }
            b'h' => {
                if let Some(parent) = cwd.parent() {
                    cwd = parent.to_path_buf();
                    selected = 0;
                }
            }
            0x7f | 0x08 => show_hidden = !show_hidden,
            b':' => {
                command.clear();
                read_line_command(&mut command);
                if handle_command(&command, &mut cwd) {
                    break;
                }
                command.clear();
            }
            b'Z' if last == b'Z' => break,
            b'Q' if last == b'Z' => break,
            b'\x04' => selected = (selected + (rows as usize / 2)).min(entries.len().saturating_sub(1)),
            b'\x15' => selected = selected.saturating_sub(rows as usize / 2),
            _ => {}
        }
        last = b;
    }
    print!("\x1b[?25h\x1b[0m\x1b[2J\x1b[H");
    let _ = io::stdout().flush();
}

fn terminal_size() -> Option<(u16, u16)> {
    unsafe {
        let mut ws: winsize = std::mem::zeroed();
        if ioctl(STDOUT_FILENO, TIOCGWINSZ, &mut ws) == -1 {
            return None;
        }
        Some((ws.ws_row, ws.ws_col))
    }
}

struct RawMode {
    old: Option<libc::termios>,
}

impl RawMode {
    fn new() -> Self {
        Self { old: None }
    }

    fn enable(&mut self) -> io::Result<()> {
        unsafe {
            let mut term: libc::termios = std::mem::zeroed();
            if libc::tcgetattr(STDIN_FILENO, &mut term) != 0 {
                return Err(io::Error::last_os_error());
            }
            self.old = Some(term);
            term.c_lflag &= !(libc::ECHO | libc::ICANON);
            term.c_iflag &= !(libc::IXON | libc::ICRNL);
            term.c_cc[libc::VMIN] = 1;
            term.c_cc[libc::VTIME] = 0;
            if libc::tcsetattr(STDIN_FILENO, libc::TCSANOW, &term) != 0 {
                return Err(io::Error::last_os_error());
            }
        }
        Ok(())
    }
}

impl Drop for RawMode {
    fn drop(&mut self) {
        if let Some(old) = self.old {
            unsafe {
                let _ = libc::tcsetattr(STDIN_FILENO, libc::TCSANOW, &old);
            }
        }
    }
}

#[derive(Clone)]
struct Entry {
    name: String,
    path: PathBuf,
    is_dir: bool,
}

fn read_entries(cwd: &Path, show_hidden: bool) -> Vec<Entry> {
    let mut entries = Vec::new();
    if let Ok(rd) = fs::read_dir(cwd) {
        for item in rd.flatten() {
            let name = os_to_string(&item.file_name());
            if !show_hidden && name.starts_with('.') {
                continue;
            }
            let path = item.path();
            entries.push(Entry {
                is_dir: path.is_dir(),
                name,
                path,
            });
        }
    }
    entries.sort_by(|a, b| {
        b.is_dir
            .cmp(&a.is_dir)
            .then_with(|| a.name.to_lowercase().cmp(&b.name.to_lowercase()))
            .then_with(|| a.name.cmp(&b.name))
    });
    entries
}

fn os_to_string(s: &OsStr) -> String {
    String::from_utf8_lossy(s.as_bytes()).into_owned()
}

fn draw(cwd: &Path, entries: &[Entry], selected: usize, show_hidden: bool, rows: u16, cols: u16) {
    print!("\x1b[?25l\x1b[2J\x1b[H");
    println!("felix v2.16.1  {}", cwd.display());
    println!("{} item(s){}  :q quit  h parent  l open  <BS> hidden", entries.len(), if show_hidden { " including hidden" } else { "" });
    let usable = rows.saturating_sub(4) as usize;
    for (i, entry) in entries.iter().take(usable).enumerate() {
        let marker = if i == selected { ">" } else { " " };
        let suffix = if entry.is_dir { "/" } else { "" };
        let mut name = format!("{marker} {}{suffix}", entry.name);
        if name.len() > cols as usize {
            name.truncate(cols as usize);
        }
        println!("{name}");
    }
    let _ = io::stdout().flush();
}

fn read_byte() -> Option<u8> {
    let mut b = [0u8; 1];
    io::stdin().read_exact(&mut b).ok()?;
    Some(b[0])
}

fn read_line_command(command: &mut String) {
    print!(":");
    let _ = io::stdout().flush();
    while let Some(b) = read_byte() {
        match b {
            b'\r' | b'\n' => break,
            27 => {
                command.clear();
                break;
            }
            0x7f | 0x08 => {
                command.pop();
            }
            b if b.is_ascii_graphic() || b == b' ' => command.push(b as char),
            _ => {}
        }
    }
}

fn handle_command(command: &str, cwd: &mut PathBuf) -> bool {
    let trimmed = command.trim();
    match trimmed {
        "q" => true,
        "h" | "help" => {
            print!("{HELP}");
            false
        }
        "e" => false,
        "cd" => {
            if let Some(home) = env::var_os("HOME") {
                *cwd = PathBuf::from(home);
            }
            false
        }
        s if s.starts_with("cd ") => {
            let p = PathBuf::from(s[3..].trim());
            let next = if p.is_absolute() { p } else { cwd.join(p) };
            if next.is_dir() {
                *cwd = next;
            }
            false
        }
        s if !s.is_empty() => {
            let _ = Command::new("sh").arg("-c").arg(s).current_dir(cwd).status();
            false
        }
        _ => false,
    }
}

fn open_external(path: &Path) {
    let opener = env::var_os("OPENER").or_else(|| env::var_os("EDITOR"));
    if let Some(cmd) = opener {
        let _ = Command::new(cmd).arg(path).status();
    }
}
