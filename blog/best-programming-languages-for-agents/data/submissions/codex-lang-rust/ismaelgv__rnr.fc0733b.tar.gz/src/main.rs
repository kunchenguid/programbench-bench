use chrono::Local;
use clap::{value_parser, Arg, ArgAction, ArgMatches, Command};
use regex::{Captures, Regex};
use serde::{Deserialize, Serialize};
use std::cmp::Reverse;
use std::fs;
use std::path::{Path, PathBuf};

struct Common {
    force: bool,
    backup: bool,
    silent: bool,
    _color: ColorMode,
    dump: bool,
    dump_prefix: String,
    no_dump: bool,
}

struct WalkOpts {
    include_dirs: bool,
    recursive: bool,
    max_depth: Option<usize>,
    hidden: bool,
}

struct RegexCmd {
    common: Common,
    replace_limit: Option<usize>,
    transform: Option<Transform>,
    walk: WalkOpts,
    expression: String,
    replacement: String,
    paths: Vec<PathBuf>,
}

struct FromFileCmd {
    common: Common,
    undo: bool,
    dumpfile: PathBuf,
}

struct ToAsciiCmd {
    common: Common,
    walk: WalkOpts,
    paths: Vec<PathBuf>,
}

enum ColorMode {
    Always,
    Never,
    Auto,
}

enum Transform {
    Upper,
    Lower,
    Ascii,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
struct Operation {
    source: String,
    target: String,
}

#[derive(Serialize, Deserialize)]
struct Dump {
    date: String,
    operations: Vec<Operation>,
}

fn main() {
    let mut argv = std::env::args().collect::<Vec<_>>();
    if argv.len() == 2 && (argv[1] == "--version" || argv[1] == "-V") {
        println!("rnr 0.5.1");
        return;
    }
    if argv.len() == 1 {
        let mut c = cli();
        c.print_help().ok();
        println!();
        return;
    }
    if argv.len() == 2 && matches!(argv[1].as_str(), "regex" | "from-file" | "to-ascii") {
        let mut c = cli();
        if let Some(sub) = c.find_subcommand_mut(&argv[1]) {
            sub.print_help().ok();
            println!();
            return;
        }
    }
    if !argv.is_empty() {
        argv[0] = "executable".to_string();
    }
    let matches = cli().get_matches_from(argv);
    let result = match matches.subcommand() {
        Some(("regex", m)) => run_regex(parse_regex(m)),
        Some(("from-file", m)) => run_from_file(parse_from_file(m)),
        Some(("to-ascii", m)) => run_to_ascii(parse_to_ascii(m)),
        _ => Ok(()),
    };
    if let Err(e) = result {
        eprintln!("{e}");
        std::process::exit(1);
    }
}

fn cli() -> Command {
    Command::new("executable")
        .version("0.5.1")
        .about("RnR is a command-line tool to rename multiple files and directories that\nsupports regular expressions")
        .arg_required_else_help(true)
        .subcommand_required(true)
        .subcommand(Command::new("regex")
            .about("Rename files and directories using a regular expression")
            .arg_required_else_help(true)
            .args(common_args())
            .arg(Arg::new("replace-limit").short('l').long("replace-limit").value_name("LIMIT").value_parser(value_parser!(usize)).help("Limit of replacements, all matches if set to 0"))
            .arg(Arg::new("replace-transform").short('t').long("replace-transform").value_name("REPLACE_TRANSFORM").value_parser(["upper", "lower", "ascii"]).help("Apply a transformation to replacements including captured groups"))
            .args(walk_args())
            .arg(Arg::new("expression").value_name("EXPRESSION").required(true).help("Expression to match (can be a regex)"))
            .arg(Arg::new("replacement").value_name("REPLACEMENT").required(true).help("Expression replacement (use single quotes for capture groups)"))
            .arg(Arg::new("paths").value_name("PATH(S)").required(true).num_args(1..).help("Target paths")))
        .subcommand(Command::new("from-file")
            .about("Read operations from a dump file")
            .arg_required_else_help(true)
            .args(common_args())
            .arg(Arg::new("undo").short('u').long("undo").action(ArgAction::SetTrue).help("Undo the operations from the dump file"))
            .arg(Arg::new("dumpfile").value_name("DUMPFILE").required(true)))
        .subcommand(Command::new("to-ascii")
            .about("Replace file name UTF-8 chars with ASCII chars representation")
            .arg_required_else_help(true)
            .args(common_args())
            .args(walk_args())
            .arg(Arg::new("paths").value_name("PATH(S)").required(true).num_args(1..).help("Target paths")))
}

fn common_args() -> Vec<Arg> {
    vec![
        Arg::new("dry-run").short('n').long("dry-run").action(ArgAction::SetTrue).help("Only show what would be done (default mode)"),
        Arg::new("force").short('f').long("force").action(ArgAction::SetTrue).help("Make actual changes to files"),
        Arg::new("backup").short('b').long("backup").action(ArgAction::SetTrue).help("Generate file backups before renaming"),
        Arg::new("silent").short('s').long("silent").action(ArgAction::SetTrue).help("Do not print any information"),
        Arg::new("color").long("color").value_name("COLOR").default_value("auto").value_parser(["always", "never", "auto"]).help("Set color output mode"),
        Arg::new("dump").long("dump").action(ArgAction::SetTrue).help("Force dumping operations into a file even in dry-run mode"),
        Arg::new("dump-prefix").long("dump-prefix").default_value("rnr-").value_name("DUMP_PREFIX").help("Set the dump file prefix"),
        Arg::new("no-dump").long("no-dump").action(ArgAction::SetTrue).help("Do not dump operations into a file"),
    ]
}

fn walk_args() -> Vec<Arg> {
    vec![
        Arg::new("include-dirs").short('D').long("include-dirs").action(ArgAction::SetTrue).help("Rename matching directories"),
        Arg::new("recursive").short('r').long("recursive").action(ArgAction::SetTrue).help("Recursive mode"),
        Arg::new("max-depth").short('d').long("max-depth").requires("recursive").value_name("LEVEL").value_parser(value_parser!(usize)).help("Set max depth in recursive mode"),
        Arg::new("hidden").short('x').long("hidden").requires("recursive").action(ArgAction::SetTrue).help("Include hidden files and directories"),
    ]
}

fn parse_common(m: &ArgMatches) -> Common {
    Common {
        force: m.get_flag("force"),
        backup: m.get_flag("backup"),
        silent: m.get_flag("silent"),
        _color: match m.get_one::<String>("color").map(String::as_str).unwrap_or("auto") {
            "always" => ColorMode::Always,
            "never" => ColorMode::Never,
            _ => ColorMode::Auto,
        },
        dump: m.get_flag("dump"),
        dump_prefix: m.get_one::<String>("dump-prefix").cloned().unwrap_or_else(|| "rnr-".to_string()),
        no_dump: m.get_flag("no-dump"),
    }
}

fn parse_walk(m: &ArgMatches) -> WalkOpts {
    WalkOpts {
        include_dirs: m.get_flag("include-dirs"),
        recursive: m.get_flag("recursive"),
        max_depth: m.get_one::<usize>("max-depth").copied(),
        hidden: m.get_flag("hidden"),
    }
}

fn parse_regex(m: &ArgMatches) -> RegexCmd {
    RegexCmd {
        common: parse_common(m),
        replace_limit: m.get_one::<usize>("replace-limit").copied(),
        transform: m.get_one::<String>("replace-transform").map(|s| match s.as_str() {
            "upper" => Transform::Upper,
            "lower" => Transform::Lower,
            _ => Transform::Ascii,
        }),
        walk: parse_walk(m),
        expression: m.get_one::<String>("expression").unwrap().clone(),
        replacement: m.get_one::<String>("replacement").unwrap().clone(),
        paths: m.get_many::<String>("paths").unwrap().map(PathBuf::from).collect(),
    }
}

fn parse_from_file(m: &ArgMatches) -> FromFileCmd {
    FromFileCmd {
        common: parse_common(m),
        undo: m.get_flag("undo"),
        dumpfile: PathBuf::from(m.get_one::<String>("dumpfile").unwrap()),
    }
}

fn parse_to_ascii(m: &ArgMatches) -> ToAsciiCmd {
    ToAsciiCmd {
        common: parse_common(m),
        walk: parse_walk(m),
        paths: m.get_many::<String>("paths").unwrap().map(PathBuf::from).collect(),
    }
}

fn run_regex(cmd: RegexCmd) -> Result<(), String> {
    let re = Regex::new(&cmd.expression).map_err(|e| format!("Error: Bad expression provided\n\n{e}"))?;
    let items = collect_paths(&cmd.paths, &cmd.walk)?;
    let mut ops = Vec::new();
    for path in items {
        let Some(name) = path.file_name().and_then(|s| s.to_str()) else { continue };
        let new_name = replace_name(&re, name, &cmd.replacement, cmd.replace_limit.unwrap_or(1), cmd.transform.as_ref());
        if new_name != name {
            let target = path.with_file_name(new_name);
            ops.push(Operation { source: display_path(&path), target: display_path(&target) });
        }
    }
    execute_ops(ops, &cmd.common)
}

fn run_to_ascii(cmd: ToAsciiCmd) -> Result<(), String> {
    let items = collect_paths(&cmd.paths, &cmd.walk)?;
    let mut ops = Vec::new();
    for path in items {
        let Some(name) = path.file_name().and_then(|s| s.to_str()) else { continue };
        let new_name = to_ascii(name);
        if new_name != name {
            let target = path.with_file_name(new_name);
            ops.push(Operation { source: display_path(&path), target: display_path(&target) });
        }
    }
    execute_ops(ops, &cmd.common)
}

fn run_from_file(cmd: FromFileCmd) -> Result<(), String> {
    let text = fs::read_to_string(&cmd.dumpfile).map_err(|e| format!("Error: {e}"))?;
    let mut dump: Dump = serde_json::from_str(&text).map_err(|e| format!("Error: {e}"))?;
    if cmd.undo {
        dump.operations = dump.operations.into_iter().rev().map(|op| Operation {
            source: op.target,
            target: op.source,
        }).collect();
    }
    execute_ops(dump.operations, &cmd.common)
}

fn collect_paths(paths: &[PathBuf], opts: &WalkOpts) -> Result<Vec<PathBuf>, String> {
    let mut out = Vec::new();
    for path in paths {
        if path.is_file() {
            if include_path(path, opts.hidden) {
                out.push(path.clone());
            }
        } else if path.is_dir() {
            if opts.recursive {
                walk_dir(path, 1, opts, &mut out)?;
            }
            if opts.include_dirs && include_path(path, opts.hidden) {
                out.push(path.clone());
            }
        }
    }
    if opts.recursive {
        out.sort_by(|a, b| {
            Reverse(a.components().count())
                .cmp(&Reverse(b.components().count()))
                .then_with(|| a.is_dir().cmp(&b.is_dir()))
        });
    }
    Ok(out)
}

fn walk_dir(dir: &Path, depth: usize, opts: &WalkOpts, out: &mut Vec<PathBuf>) -> Result<(), String> {
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return Ok(()),
    };
    let mut dirs = Vec::new();
    for entry in entries.flatten() {
        let path = entry.path();
        if !include_path(&path, opts.hidden) {
            continue;
        }
        if path.is_dir() {
            if opts.max_depth.map_or(true, |m| depth < m) {
                dirs.push(path.clone());
            }
            if opts.include_dirs {
                out.push(path);
            }
        } else if path.is_file() {
            out.push(path);
        }
    }
    dirs.sort();
    for d in dirs {
        walk_dir(&d, depth + 1, opts, out)?;
    }
    Ok(())
}

fn include_path(path: &Path, hidden: bool) -> bool {
    hidden || !path.file_name().and_then(|s| s.to_str()).is_some_and(|s| s.starts_with('.'))
}

fn replace_name(re: &Regex, name: &str, replacement: &str, limit: usize, transform: Option<&Transform>) -> String {
    let mut count = 0usize;
    re.replace_all(name, |caps: &Captures| {
        if limit != 0 && count >= limit {
            caps.get(0).unwrap().as_str().to_string()
        } else {
            count += 1;
            let mut buf = String::new();
            caps.expand(replacement, &mut buf);
            apply_transform(buf, transform)
        }
    }).to_string()
}

fn apply_transform(s: String, transform: Option<&Transform>) -> String {
    match transform {
        Some(Transform::Upper) => s.to_uppercase(),
        Some(Transform::Lower) => s.to_lowercase(),
        Some(Transform::Ascii) => to_ascii(&s),
        None => s,
    }
}

fn execute_ops(ops: Vec<Operation>, common: &Common) -> Result<(), String> {
    let dry = !common.force;
    if dry && !common.silent {
        println!("This is a DRY-RUN");
    }
    let mut valid = Vec::new();
    for op in ops {
        if Path::new(&op.target).exists() && op.source != op.target {
            if !common.silent {
                println!("Error: Conflict with existing path {} -> {}", op.source, op.target);
            }
            if !dry {
                return Ok(());
            }
            continue;
        }
        valid.push(op);
    }
    for op in &valid {
        if common.backup && !dry {
            let backup = format!("{}.bk", op.source);
            fs::copy(&op.source, &backup).map_err(|e| format!("Error: {e}"))?;
            if !common.silent {
                println!("Info:  Backup created - {} -> {}", op.source, backup);
            }
        }
        if !dry {
            fs::rename(&op.source, &op.target).map_err(|e| format!("Error: {e}"))?;
        }
        if !common.silent {
            println!("{} -> {}", op.source, op.target);
        }
    }
    if should_dump(common, dry) && !valid.is_empty() {
        write_dump(&valid, &common.dump_prefix)?;
    }
    Ok(())
}

fn should_dump(common: &Common, dry: bool) -> bool {
    !common.no_dump && (common.dump || !dry)
}

fn write_dump(ops: &[Operation], prefix: &str) -> Result<(), String> {
    let dump = Dump {
        date: Local::now().format("%Y-%m-%d %H:%M:%S").to_string(),
        operations: ops.to_vec(),
    };
    let name = format!("{}{}.json", prefix, Local::now().format("%Y-%m-%d_%H%M%S"));
    let text = serde_json::to_string_pretty(&dump).map_err(|e| format!("Error: {e}"))?;
    fs::write(name, format!("{text}\n")).map_err(|e| format!("Error: {e}"))
}

fn display_path(path: &Path) -> String {
    path.to_string_lossy().into_owned()
}

fn to_ascii(s: &str) -> String {
    let mut out = String::new();
    for ch in s.chars() {
        if ch.is_ascii() {
            out.push(ch);
        } else {
            out.push_str(translit(ch));
        }
    }
    out
}

fn translit(ch: char) -> &'static str {
    match ch {
        'À' | 'Á' | 'Â' | 'Ã' | 'Ä' | 'Å' | 'Ā' | 'Ă' | 'Ą' | 'Ǎ' => "A",
        'à' | 'á' | 'â' | 'ã' | 'ä' | 'å' | 'ā' | 'ă' | 'ą' | 'ǎ' => "a",
        'Æ' => "Ae",
        'æ' => "ae",
        'Ç' | 'Ć' | 'Ĉ' | 'Ċ' | 'Č' => "C",
        'ç' | 'ć' | 'ĉ' | 'ċ' | 'č' => "c",
        'Ð' | 'Ď' | 'Đ' => "D",
        'ð' | 'ď' | 'đ' => "d",
        'È' | 'É' | 'Ê' | 'Ë' | 'Ē' | 'Ĕ' | 'Ė' | 'Ę' | 'Ě' => "E",
        'è' | 'é' | 'ê' | 'ë' | 'ē' | 'ĕ' | 'ė' | 'ę' | 'ě' => "e",
        'Ĝ' | 'Ğ' | 'Ġ' | 'Ģ' => "G",
        'ĝ' | 'ğ' | 'ġ' | 'ģ' => "g",
        'Ĥ' | 'Ħ' => "H",
        'ĥ' | 'ħ' => "h",
        'Ì' | 'Í' | 'Î' | 'Ï' | 'Ĩ' | 'Ī' | 'Ĭ' | 'Į' | 'İ' | 'Ǐ' => "I",
        'ì' | 'í' | 'î' | 'ï' | 'ĩ' | 'ī' | 'ĭ' | 'į' | 'ı' | 'ǐ' => "i",
        'Ĵ' => "J",
        'ĵ' => "j",
        'Ķ' => "K",
        'ķ' | 'ĸ' => "k",
        'Ĺ' | 'Ļ' | 'Ľ' | 'Ŀ' | 'Ł' => "L",
        'ĺ' | 'ļ' | 'ľ' | 'ŀ' | 'ł' => "l",
        'Ñ' | 'Ń' | 'Ņ' | 'Ň' => "N",
        'ñ' | 'ń' | 'ņ' | 'ň' => "n",
        'Ò' | 'Ó' | 'Ô' | 'Õ' | 'Ö' | 'Ø' | 'Ō' | 'Ŏ' | 'Ő' | 'Ǒ' => "O",
        'ò' | 'ó' | 'ô' | 'õ' | 'ö' | 'ø' | 'ō' | 'ŏ' | 'ő' | 'ǒ' => "o",
        'Œ' => "Oe",
        'œ' => "oe",
        'Ŕ' | 'Ŗ' | 'Ř' => "R",
        'ŕ' | 'ŗ' | 'ř' => "r",
        'Ś' | 'Ŝ' | 'Ş' | 'Š' => "S",
        'ś' | 'ŝ' | 'ş' | 'š' | 'ſ' => "s",
        'ß' => "ss",
        'Ţ' | 'Ť' | 'Ŧ' => "T",
        'ţ' | 'ť' | 'ŧ' => "t",
        'Ù' | 'Ú' | 'Û' | 'Ü' | 'Ũ' | 'Ū' | 'Ŭ' | 'Ů' | 'Ű' | 'Ų' | 'Ǔ' => "U",
        'ù' | 'ú' | 'û' | 'ü' | 'ũ' | 'ū' | 'ŭ' | 'ů' | 'ű' | 'ų' | 'ǔ' => "u",
        'Ŵ' => "W",
        'ŵ' => "w",
        'Ý' | 'Ÿ' | 'Ŷ' => "Y",
        'ý' | 'ÿ' | 'ŷ' => "y",
        'Ź' | 'Ż' | 'Ž' => "Z",
        'ź' | 'ż' | 'ž' => "z",
        'Þ' => "Th",
        'þ' => "th",
        '你' => "Ni",
        '好' => "Hao",
        '中' => "Zhong",
        '国' | '國' => "Guo",
        '日' => "Ri",
        '本' => "Ben",
        '語' | '语' => "Yu",
        _ => "",
    }
}
