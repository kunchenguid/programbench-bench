use serde_json::{json, Map, Value};
use std::collections::{BTreeMap, HashSet};
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

struct Cli {
    columns: Option<usize>,
    exclude: Vec<String>,
    files: bool,
    input_file: Option<String>,
    hidden: bool,
    languages: bool,
    no_ignore: bool,
    no_ignore_parent: bool,
    no_ignore_dot: bool,
    no_ignore_vcs: bool,
    output: Option<String>,
    streaming: Option<Streaming>,
    sort: Option<SortKey>,
    rsort: Option<SortKey>,
    types_: Option<String>,
    num_format: NumFormat,
    verbose: u8,
    version: bool,
    input: Vec<PathBuf>,
}

#[derive(Copy, Clone, Debug)] enum SortKey { Files, Lines, Blanks, Code, Comments }
#[derive(Copy, Clone, Debug)] enum Streaming { Simple, Json }
#[derive(Copy, Clone, Debug, PartialEq)] enum NumFormat { Commas, Dots, Plain, Underscores }

#[derive(Clone, Default, Debug)]
struct Stats { blanks: u64, code: u64, comments: u64, blobs: BTreeMap<String, Stats> }
impl Stats { fn lines(&self) -> u64 { self.blanks + self.code + self.comments } fn add(&mut self, o: &Stats){ self.blanks+=o.blanks; self.code+=o.code; self.comments+=o.comments; for (k,v) in &o.blobs { self.blobs.entry(k.clone()).or_default().add(v); } } }

#[derive(Clone, Debug)] struct Report { stats: Stats, name: String }
#[derive(Clone, Default, Debug)] struct LangTotal { stats: Stats, reports: Vec<Report>, children: BTreeMap<String, Vec<Report>>, inaccurate: bool }

#[derive(Clone)]
struct LangDef { name: &'static str, exts: &'static [&'static str], line: &'static [&'static str], block: &'static [(&'static str,&'static str)], nested: bool, text: bool }


fn parse_args() -> Cli {
    let mut cli = Cli { columns: None, exclude: Vec::new(), files: false, input_file: None, hidden: false, languages: false, no_ignore: false, no_ignore_parent: false, no_ignore_dot: false, no_ignore_vcs: false, output: None, streaming: None, sort: None, rsort: None, types_: None, num_format: NumFormat::Plain, verbose: 0, version: false, input: Vec::new() };
    let mut it = std::env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        let val = |a: &str, it: &mut std::iter::Peekable<std::iter::Skip<std::env::Args>>| -> String {
            if let Some((_, v)) = a.split_once('=') { v.to_string() } else { it.next().unwrap_or_else(|| { eprintln!("error: a value is required for '{}'", a); std::process::exit(2) }) }
        };
        match arg.as_str() {
            "--" => { cli.input.extend(it.map(PathBuf::from)); break; }
            "-h"|"--help" => { print_help(); std::process::exit(0); }
            "-V"|"--version" => cli.version=true,
            "-f"|"--files" => cli.files=true,
            "--hidden" => cli.hidden=true,
            "-l"|"--languages" => cli.languages=true,
            "--no-ignore" => { cli.no_ignore=true; cli.no_ignore_parent=true; cli.no_ignore_dot=true; cli.no_ignore_vcs=true; },
            "--no-ignore-parent" => cli.no_ignore_parent=true,
            "--no-ignore-dot" => cli.no_ignore_dot=true,
            "--no-ignore-vcs" => cli.no_ignore_vcs=true,
            "-v"|"--verbose" => cli.verbose+=1,
            "-c"|"--columns" => cli.columns=val(&arg,&mut it).parse().ok(),
            "-e"|"--exclude" => cli.exclude.push(val(&arg,&mut it)),
            "-i"|"--input" => cli.input_file=Some(val(&arg,&mut it)),
            "-o"|"--output" => cli.output=Some(val(&arg,&mut it)),
            "--streaming" => cli.streaming=parse_stream(&val(&arg,&mut it)),
            "-s"|"--sort" => cli.sort=parse_sort(&val(&arg,&mut it)),
            "-r"|"--rsort" => cli.rsort=parse_sort(&val(&arg,&mut it)),
            "-t"|"--types"|"--type" => cli.types_=Some(val(&arg,&mut it)),
            "-n"|"--num-format" => cli.num_format=parse_num(&val(&arg,&mut it)),
            _ if arg.starts_with("--exclude=") => cli.exclude.push(arg[10..].to_string()),
            _ if arg.starts_with("--input=") => cli.input_file=Some(arg[8..].to_string()),
            _ if arg.starts_with("--output=") => cli.output=Some(arg[9..].to_string()),
            _ if arg.starts_with("--streaming=") => cli.streaming=parse_stream(&arg[12..]),
            _ if arg.starts_with("--sort=") => cli.sort=parse_sort(&arg[7..]),
            _ if arg.starts_with("--rsort=") => cli.rsort=parse_sort(&arg[8..]),
            _ if arg.starts_with("--types=") => cli.types_=Some(arg[8..].to_string()),
            _ if arg.starts_with("--type=") => cli.types_=Some(arg[7..].to_string()),
            _ if arg.starts_with("--num-format=") => cli.num_format=parse_num(&arg[13..]),
            _ if arg.starts_with('-') && arg.len()>2 && arg.chars().skip(1).all(|c| c=='v') => cli.verbose += (arg.len()-1) as u8,
            _ if arg.starts_with('-') => { eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] [input]...\n\nFor more information, try '--help'.", arg); std::process::exit(2); },
            _ => cli.input.push(PathBuf::from(arg)),
        }
    }
    cli
}
fn parse_sort(s:&str)->Option<SortKey>{ match s {"files"=>Some(SortKey::Files),"lines"=>Some(SortKey::Lines),"blanks"=>Some(SortKey::Blanks),"code"=>Some(SortKey::Code),"comments"=>Some(SortKey::Comments),_=>None} }
fn parse_stream(s:&str)->Option<Streaming>{ match s {"simple"=>Some(Streaming::Simple),"json"=>Some(Streaming::Json),_=>None} }
fn parse_num(s:&str)->NumFormat{ match s {"commas"=>NumFormat::Commas,"dots"=>NumFormat::Dots,"underscores"=>NumFormat::Underscores,_=>NumFormat::Plain} }
fn print_help(){ println!("Count your code, quickly.\nSupport this project on GitHub Sponsors: https://github.com/sponsors/XAMPPRocky\n\nUsage: executable [OPTIONS] [input]...\n\nArguments:\n  [input]...  The path(s) to the file or directory to be counted. (default current directory)\n\nOptions:\n  -c, --columns <columns>\n  -e, --exclude <exclude>\n  -f, --files\n  -i, --input <file_input>\n      --hidden\n  -l, --languages\n      --no-ignore\n      --no-ignore-parent\n      --no-ignore-dot\n      --no-ignore-vcs\n  -o, --output <output>\n      --streaming <streaming>          [possible values: simple, json]\n  -s, --sort <sort>                    [possible values: files, lines, blanks, code, comments]\n  -r, --rsort <rsort>                  [possible values: files, lines, blanks, code, comments]\n  -t, --types <types>\n  -n, --num-format <num_format_style>  [possible values: commas, dots, plain, underscores]\n  -v, --verbose...\n  -h, --help                           Print help\n  -V, --version                        Print version"); }
fn glob_match_impl(pat:&[u8], text:&[u8])->bool { if pat.is_empty(){return text.is_empty()} if pat[0]==b'*' { for i in 0..=text.len(){ if glob_match_impl(&pat[1..], &text[i..]){return true;} } false } else if !text.is_empty() && (pat[0]==b'?' || pat[0]==text[0]) { glob_match_impl(&pat[1..], &text[1..]) } else { false } }
fn stats_json(st:&Stats)->Value { let blobs:Map<String,Value>=st.blobs.iter().map(|(k,v)|(k.clone(), stats_json(v))).collect(); json!({"blanks":st.blanks,"code":st.code,"comments":st.comments,"blobs":blobs}) }
fn report_json(r:&Report)->Value { json!({"stats":stats_json(&r.stats),"name":r.name}) }

fn defs() -> Vec<LangDef> { vec![
    LangDef{name:"ABNF",exts:&["abnf"],line:&[";"],block:&[],nested:false,text:false},
    LangDef{name:"AWK",exts:&["awk"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"ABAP",exts:&["abap"],line:&["*","\""],block:&[],nested:false,text:false},
    LangDef{name:"ActionScript",exts:&["as"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Ada",exts:&["ada","adb","ads","pad"],line:&["--"],block:&[],nested:false,text:false},
    LangDef{name:"Agda",exts:&["agda"],line:&["--"],block:&[("{-","-}")],nested:true,text:false},
    LangDef{name:"Assembly",exts:&["asm"],line:&[";","#"],block:&[],nested:false,text:false},
    LangDef{name:"GNU Style Assembly",exts:&["s"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"BASH",exts:&["bash"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Batch",exts:&["bat","btm","cmd"],line:&["rem","::"],block:&[],nested:false,text:false},
    LangDef{name:"Bazel",exts:&["bzl","bazel","bzlmod"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"C",exts:&["c","ec","pgc"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"C Header",exts:&["h"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"CMake",exts:&["cmake"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"C#",exts:&["cs","csx"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"C Shell",exts:&["csh"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"C++",exts:&["cc","cpp","cxx","c++","pcc","tpp"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"C++ Header",exts:&["hh","hpp","hxx","inl","ipp"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"C++ Module",exts:&["cppm","ixx","ccm","mpp","mxx"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"CSS",exts:&["css"],line:&[],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"D",exts:&["d"],line:&["//"],block:&[("/*","*/"),("/+","+/")],nested:true,text:false},
    LangDef{name:"Dart",exts:&["dart"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Dockerfile",exts:&["dockerfile","dockerignore"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Elixir",exts:&["ex","exs"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Elm",exts:&["elm"],line:&["--"],block:&[("{-","-}")],nested:true,text:false},
    LangDef{name:"Erlang",exts:&["erl","hrl"],line:&["%"],block:&[],nested:false,text:false},
    LangDef{name:"F#",exts:&["fs","fsi","fsx"],line:&["//"],block:&[("(*","*)")],nested:true,text:false},
    LangDef{name:"Fortran Modern",exts:&["f90","f95","f03","f08"],line:&["!"],block:&[],nested:false,text:false},
    LangDef{name:"Go",exts:&["go"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"GraphQL",exts:&["graphql","gql"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Groovy",exts:&["groovy","gradle"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Haskell",exts:&["hs","lhs"],line:&["--"],block:&[("{-","-}")],nested:true,text:false},
    LangDef{name:"HTML",exts:&["html","htm"],line:&[],block:&[("<!--","-->")],nested:false,text:false},
    LangDef{name:"Java",exts:&["java"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"JavaScript",exts:&["js","mjs","cjs"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"JSON",exts:&["json"],line:&[],block:&[],nested:false,text:false},
    LangDef{name:"JSX",exts:&["jsx"],line:&["//"],block:&[("/*","*/"),("{/*","*/}")],nested:false,text:false},
    LangDef{name:"Julia",exts:&["jl"],line:&["#"],block:&[("#=","=#")],nested:true,text:false},
    LangDef{name:"Kotlin",exts:&["kt","kts"],line:&["//"],block:&[("/*","*/")],nested:true,text:false},
    LangDef{name:"Less",exts:&["less"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Lisp",exts:&["lisp","lsp","cl"],line:&[";"],block:&[],nested:false,text:false},
    LangDef{name:"Lua",exts:&["lua"],line:&["--"],block:&[("--[[","]]" )],nested:false,text:false},
    LangDef{name:"Makefile",exts:&["makefile","mk"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Markdown",exts:&["md","markdown"],line:&[],block:&[],nested:false,text:true},
    LangDef{name:"Nim",exts:&["nim","nims"],line:&["#"],block:&[("#[","]#")],nested:true,text:false},
    LangDef{name:"Nix",exts:&["nix"],line:&["#"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Objective-C",exts:&["m"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Objective-C++",exts:&["mm"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"OCaml",exts:&["ml","mli"],line:&[],block:&[("(*","*)")],nested:true,text:false},
    LangDef{name:"Perl",exts:&["pl","pm","t"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"PHP",exts:&["php","php3","php4","php5","phtml"],line:&["//","#"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"PowerShell",exts:&["ps1","psm1"],line:&["#"],block:&[("<#","#>")],nested:false,text:false},
    LangDef{name:"Python",exts:&["py","pyw"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"R",exts:&["r","R"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Ruby",exts:&["rb","rake","gemspec"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Rust",exts:&["rs"],line:&["//"],block:&[("/*","*/")],nested:true,text:false},
    LangDef{name:"Sass",exts:&["sass","scss"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Scala",exts:&["scala","sc"],line:&["//"],block:&[("/*","*/")],nested:true,text:false},
    LangDef{name:"Scheme",exts:&["scm","ss"],line:&[";"],block:&[],nested:false,text:false},
    LangDef{name:"Shell",exts:&["sh"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"SQL",exts:&["sql"],line:&["--"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Swift",exts:&["swift"],line:&["//"],block:&[("/*","*/")],nested:true,text:false},
    LangDef{name:"TOML",exts:&["toml"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"TSX",exts:&["tsx"],line:&["//"],block:&[("/*","*/"),("{/*","*/}")],nested:false,text:false},
    LangDef{name:"TypeScript",exts:&["ts","mts","cts"],line:&["//"],block:&[("/*","*/")],nested:false,text:false},
    LangDef{name:"Vim script",exts:&["vim"],line:&["\""],block:&[],nested:false,text:false},
    LangDef{name:"Visual Basic",exts:&["vb"],line:&["'"],block:&[],nested:false,text:false},
    LangDef{name:"Vue",exts:&["vue"],line:&["//"],block:&[("<!--","-->")],nested:false,text:false},
    LangDef{name:"XML",exts:&["xml"],line:&[],block:&[("<!--","-->")],nested:false,text:false},
    LangDef{name:"YAML",exts:&["yaml","yml"],line:&["#"],block:&[],nested:false,text:false},
    LangDef{name:"Zig",exts:&["zig"],line:&["//"],block:&[],nested:false,text:false},
]}

fn main() {
    let cli = parse_args();
    if cli.version { println!("tokei 14.0.0 compiled with serialization support: json"); return; }
    let defs = defs();
    if cli.languages { print_languages(&defs); return; }
    if let Some(fmt) = &cli.output { if fmt != "json" { unsupported_output(fmt); std::process::exit(2); } }
    let type_filter = cli.types_.as_ref().map(|s| s.split(',').map(|x| norm_lang(x)).collect::<HashSet<_>>());
    let mut totals: BTreeMap<String, LangTotal> = BTreeMap::new();
    if let Some(inp) = &cli.input_file { if let Err(e)=merge_input(inp, &mut totals) { eprintln!("Error: {}", e); std::process::exit(1); } }
    let inputs = if cli.input.is_empty() { vec![PathBuf::from(".")] } else { cli.input.clone() };
    for p in inputs { if !p.exists() { eprintln!("Error: '{}' not found.", p.display()); std::process::exit(1); } walk(&p, &cli, &defs, &mut totals); }
    if let Some(filter)=&type_filter { totals.retain(|k,_| filter.contains(&norm_lang(k))); }
    if let Some(stream)=cli.streaming { print_streaming(&totals, stream); return; }
    if cli.output.as_deref()==Some("json") { println!("{}", make_json(&totals)); return; }
    print_table(&totals, &cli);
}

fn norm_lang(s:&str)->String { s.chars().filter(|c| !c.is_whitespace() && *c!='-' && *c!='_' ).flat_map(|c| c.to_lowercase()).collect() }

fn unsupported_output(fmt:&str){ eprintln!("error: invalid value '{}' for '--output <output>': This version of tokei was compiled without any '{}' serialization support, to enable serialization, reinstall tokei with the features flag.\n\n    cargo install tokei --features {}\n\nIf you want to enable all supported serialization formats, you can use the 'all' feature.\n\n    cargo install tokei --features all\n\n\nFor more information, try '--help'.", fmt, fmt, fmt); }

fn print_languages(defs:&[LangDef]){ println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"); println!("┃ {:<37} {:<30} ┃", "Language", "Extensions"); println!("┃━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┃"); for d in defs { let ex=d.exts.join(", "); println!("┃ {:<37} {:<30} ┃", d.name, truncate(&ex,30)); } println!("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"); }
fn truncate(s:&str,n:usize)->String{ if s.chars().count()<=n {s.to_string()} else { let mut t=s.chars().take(n-3).collect::<String>(); t.push_str("..."); t } }

fn walk(path:&Path, cli:&Cli, defs:&[LangDef], totals:&mut BTreeMap<String,LangTotal>){
    if should_skip(path, cli) { return; }
    if path.is_dir() { if let Ok(rd)=fs::read_dir(path){ let mut entries:Vec<_>=rd.filter_map(Result::ok).collect(); entries.sort_by_key(|e| e.path()); for e in entries { walk(&e.path(), cli, defs, totals); } } }
    else if path.is_file() { if let Ok(bytes)=fs::read(path) { let content=String::from_utf8_lossy(&bytes).replace("\r\n","\n"); if let Some(def)=detect(path, defs).or_else(|| detect_shebang(&content, defs)) { let stats= if def.name=="Markdown" { count_markdown(&content, defs) } else { count_code(&content, &def) }; add_report(totals, def.name, path, stats); } else if cli.verbose>0 { eprintln!("Unknown extension: {}", path.display()); } } }
}
fn should_skip(path:&Path, cli:&Cli)->bool{ let name=path.file_name().and_then(|s|s.to_str()).unwrap_or(""); if !cli.hidden && name.starts_with('.') && name!="." { return true; } if name==".git" && !cli.no_ignore { return true; } for pat in &cli.exclude { if matches_pat(path, pat) { return true; } } if !cli.no_ignore && ignored_by_files(path, cli) { return true; } false }

fn ignored_by_files(path:&Path, cli:&Cli)->bool{
    let mut dirs=Vec::new(); let mut cur=if path.is_dir(){Some(path)}else{path.parent()};
    while let Some(d)=cur { dirs.push(d.to_path_buf()); cur=d.parent(); } dirs.reverse();
    for d in dirs {
        let files = [(".gitignore", !cli.no_ignore_vcs), (".ignore", !cli.no_ignore_dot), (".tokeignore", !cli.no_ignore_dot)];
        for (file, enabled) in files { if !enabled { continue; } let p=d.join(file); if let Ok(txt)=fs::read_to_string(&p){ for raw in txt.lines(){ let pat=raw.trim(); if pat.is_empty() || pat.starts_with('#') || pat.starts_with('!') { continue; } let pat=pat.trim_start_matches('/').trim_end_matches('/'); if pat.is_empty(){continue;} if matches_pat(path, pat) { return true; } } } }
    } false
}

fn matches_pat(path:&Path, pat:&str)->bool{ let s=path.to_string_lossy(); let n=path.file_name().and_then(|x|x.to_str()).unwrap_or(""); glob_match(pat,n) || glob_match(pat,&s) }
fn glob_match(pat:&str, text:&str)->bool{ glob_match_impl(pat.as_bytes(), text.as_bytes()) }

fn detect<'a>(path:&Path, defs:&'a[LangDef])->Option<LangDef>{
    let fname=path.file_name()?.to_string_lossy(); let lower=fname.to_lowercase();
    let special = match lower.as_str(){ "makefile"|"gnumakefile" => Some("Makefile"), "dockerfile" => Some("Dockerfile"), "cmakelists.txt" => Some("CMake"), "rakefile" => Some("Ruby"), "gemfile" => Some("Ruby"), "cargo.toml" => Some("TOML"), _=>None };
    if let Some(name)=special { return defs.iter().find(|d|d.name==name).cloned(); }
    let ext=path.extension()?.to_string_lossy();
    defs.iter().find(|d| d.exts.iter().any(|e| e.eq_ignore_ascii_case(&ext))).cloned()
}


fn detect_shebang(content:&str, defs:&[LangDef])->Option<LangDef>{
    let first=content.lines().next()?.to_lowercase(); if !first.starts_with("#!") { return None; }
    let name=if first.contains("python") {"Python"} else if first.contains("ruby") {"Ruby"} else if first.contains("perl") {"Perl"} else if first.contains("bash") {"BASH"} else if first.contains("sh") {"Shell"} else {return None};
    defs.iter().find(|d| d.name==name).cloned()
}

fn add_report(totals:&mut BTreeMap<String,LangTotal>, lang:&str, path:&Path, stats:Stats){
    let name=path.to_string_lossy().trim_start_matches("./").to_string();
    let report=Report{stats:stats.clone(), name};
    let lt=totals.entry(lang.to_string()).or_default(); lt.stats.add(&stats); lt.reports.push(report.clone());
    for (child, st) in stats.blobs.clone(){ let cr=Report{stats:st.clone(), name:report.name.clone()}; lt.children.entry(child).or_default().push(cr); }
}

fn count_markdown(s:&str, defs:&[LangDef])->Stats{
    let mut st=Stats::default(); let mut fence:Option<(String,String)>=None; let mut buf=String::new();
    for line in s.lines(){ let t=line.trim(); if let Some((lang, marker)) = fence.clone(){ if t.starts_with(&marker){ let child_def=defs.iter().find(|d| norm_lang(d.name)==norm_lang(&lang)); if let Some(d)=child_def { let child=count_code(&buf,d); st.blobs.entry(d.name.to_string()).or_default().add(&child); } buf.clear(); fence=None; st.comments+=1; } else { buf.push_str(line); buf.push('\n'); } }
        else if t.starts_with("```") || t.starts_with("~~~") { let marker=t.chars().take(3).collect::<String>(); let lang=t[3..].split_whitespace().next().unwrap_or("").to_string(); fence=Some((lang,marker)); st.comments+=1; }
        else if t.is_empty(){ st.blanks+=1; } else { st.comments+=1; } }
    st
}

fn count_code(s:&str, def:&LangDef)->Stats{
    if def.line.is_empty() && def.block.is_empty() { return count_plain(s, def.text); }
    let mut st=Stats::default(); let mut block_stack: Vec<usize>=Vec::new();
    for line in s.lines(){ let mut i=0usize; let mut has_code=false; let mut has_comment=false; let bytes=line.as_bytes();
        if line.trim().is_empty(){ st.blanks+=1; continue; }
        while i<bytes.len(){ if let Some(&bi)=block_stack.last(){ has_comment=true; let (_start,end)=def.block[bi]; if line[i..].starts_with(end){ i+=end.len(); block_stack.pop(); continue; } if def.nested && line[i..].starts_with(def.block[bi].0){ block_stack.push(bi); i+=def.block[bi].0.len(); continue; } i+=next_char_len(line,i); continue; }
            if line[i..].starts_with('"') || line[i..].starts_with('\'') || line[i..].starts_with('`') { has_code=true; i=skip_string(line,i); continue; }
            let rest=&line[i..]; if rest.chars().next().map(|c|c.is_whitespace()).unwrap_or(false){ i+=next_char_len(line,i); continue; }
            let mut started=false; for (idx,(start,end)) in def.block.iter().enumerate(){ if rest.starts_with(start){ has_comment=true; i+=start.len(); if !rest[start.len()..].contains(end){ block_stack.push(idx); } else { // consume through first end
                    if let Some(pos)=rest[start.len()..].find(end){ i += pos + end.len(); }
                } started=true; break; } }
            if started { continue; }
            if def.line.iter().any(|p| rest.starts_with(p) && (p != &"rem" || rest.to_lowercase().starts_with("rem"))){ has_comment=true; break; }
            has_code=true; i+=next_char_len(line,i);
        }
        if has_code { st.code+=1; } else if has_comment { st.comments+=1; } else { st.blanks+=1; }
    }
    st
}
fn count_plain(s:&str, text:bool)->Stats{ let mut st=Stats::default(); for l in s.lines(){ if l.trim().is_empty(){st.blanks+=1}else if text{st.comments+=1}else{st.code+=1} } st }
fn next_char_len(s:&str,i:usize)->usize{ s[i..].chars().next().map(|c|c.len_utf8()).unwrap_or(1) }
fn skip_string(s:&str, start:usize)->usize{ let quote=s[start..].chars().next().unwrap(); let mut i=start+quote.len_utf8(); let mut esc=false; while i<s.len(){ let c=s[i..].chars().next().unwrap(); i+=c.len_utf8(); if esc { esc=false; continue; } if c=='\\' { esc=true; continue; } if c==quote { break; } } i }

fn make_json(totals:&BTreeMap<String,LangTotal>)->Value{ let mut map=Map::new(); for (lang,lt) in totals { map.insert(lang.clone(), json_lang(lt)); } let total=total_value(totals); map.insert("Total".to_string(), total); Value::Object(map) }
fn json_lang(lt:&LangTotal)->Value{ let children:Map<String,Value>=lt.children.iter().map(|(k,v)|(k.clone(), Value::Array(v.iter().map(|r|report_json(r)).collect()))).collect(); json!({"blanks":lt.stats.blanks,"code":lt.stats.code,"comments":lt.stats.comments,"reports":Value::Array(lt.reports.iter().map(|r|report_json(r)).collect()),"children":children,"inaccurate":lt.inaccurate}) }
fn total_value(totals:&BTreeMap<String,LangTotal>)->Value{ let mut st=Stats::default(); let mut children=Map::new(); for (k,lt) in totals{ st.blanks+=lt.stats.blanks; st.code+=lt.stats.code; st.comments+=lt.stats.comments; children.insert(k.clone(), Value::Array(lt.reports.iter().map(|r|report_json(r)).collect())); } json!({"blanks":st.blanks,"code":st.code,"comments":st.comments,"reports":[],"children":children,"inaccurate":false}) }

fn print_streaming(totals:&BTreeMap<String,LangTotal>, mode:Streaming){ if matches!(mode,Streaming::Simple){ println!("# language                                        path                                          lines         code       comments      blanks   "); println!("########## ################################################################################ ############ ############ ############ ############"); }
    for (lang,lt) in totals { for r in &lt.reports { match mode { Streaming::Simple=>println!("{:>10} {:<80} {:>12} {:>12} {:>12} {:>12}", lang, truncate(&r.name,80), r.stats.lines(), r.stats.code, r.stats.comments, r.stats.blanks), Streaming::Json=>println!("{}", json!({"language":lang,"stats":{"name":r.name,"stats":stats_json(&r.stats)}})) } } } }

fn print_table(totals:&BTreeMap<String,LangTotal>, cli:&Cli){
    let mut rows:Vec<_>=totals.iter().collect(); let key=cli.sort.or(cli.rsort); if let Some(k)=key{ rows.sort_by_key(|(_,lt)| match k{SortKey::Files=>lt.reports.len() as u64, SortKey::Lines=>lt.stats.lines(), SortKey::Blanks=>lt.stats.blanks, SortKey::Code=>lt.stats.code, SortKey::Comments=>lt.stats.comments}); if cli.rsort.is_some(){ rows.reverse(); }}
    let w=81; line('━',w); println!(" {:<18} {:>8} {:>12} {:>12} {:>12} {:>12}","Language","Files","Lines","Code","Comments","Blanks"); line('━',w);
    let mut total_files=0u64; let mut total=Stats::default();
    for (lang,lt) in rows { print_lang_row(lang, lt.reports.len() as u64, &lt.stats, cli.num_format); total_files += lt.reports.len() as u64; total.blanks+=lt.stats.blanks; total.code+=lt.stats.code; total.comments+=lt.stats.comments;
        if !lt.stats.blobs.is_empty(){ for (child,st) in &lt.stats.blobs { println!(" |- {:<15} {:>8} {:>12} {:>12} {:>12} {:>12}", child, 1, fmt_num(st.lines(),cli.num_format), fmt_num(st.code,cli.num_format), fmt_num(st.comments,cli.num_format), fmt_num(st.blanks,cli.num_format)); } println!(" {:<18} {:>8} {:>12} {:>12} {:>12} {:>12}", "(Total)", "", fmt_num(lt.stats.lines()+lt.stats.blobs.values().map(|s|s.lines()).sum::<u64>(),cli.num_format), fmt_num(lt.stats.code+lt.stats.blobs.values().map(|s|s.code).sum::<u64>(),cli.num_format), fmt_num(lt.stats.comments+lt.stats.blobs.values().map(|s|s.comments).sum::<u64>(),cli.num_format), fmt_num(lt.stats.blanks+lt.stats.blobs.values().map(|s|s.blanks).sum::<u64>(),cli.num_format)); }
        if cli.files { line('─',w); for r in &lt.reports { println!(" {:<30} {:>12} {:>12} {:>12} {:>12}", truncate(&r.name,30), fmt_num(r.stats.lines(),cli.num_format), fmt_num(r.stats.code,cli.num_format), fmt_num(r.stats.comments,cli.num_format), fmt_num(r.stats.blanks,cli.num_format)); } }
    }
    line('━',w); println!(" {:<18} {:>8} {:>12} {:>12} {:>12} {:>12}","Total", fmt_num(total_files,cli.num_format), fmt_num(total.lines(),cli.num_format), fmt_num(total.code,cli.num_format), fmt_num(total.comments,cli.num_format), fmt_num(total.blanks,cli.num_format)); line('━',w);
}
fn print_lang_row(lang:&str, files:u64, st:&Stats, nf:NumFormat){ println!(" {:<18} {:>8} {:>12} {:>12} {:>12} {:>12}", truncate(lang,18), fmt_num(files,nf), fmt_num(st.lines(),nf), fmt_num(st.code,nf), fmt_num(st.comments,nf), fmt_num(st.blanks,nf)); }
fn line(c:char,n:usize){ println!("{}", std::iter::repeat(c).take(n).collect::<String>()); }
fn fmt_num(n:u64, f:NumFormat)->String{ let sep=match f{NumFormat::Plain=>return n.to_string(), NumFormat::Commas=>',', NumFormat::Dots=>'.', NumFormat::Underscores=>'_'}; let s=n.to_string(); let mut out=String::new(); for (i,ch) in s.chars().rev().enumerate(){ if i>0 && i%3==0 {out.push(sep);} out.push(ch);} out.chars().rev().collect() }

fn merge_input(inp:&str, totals:&mut BTreeMap<String,LangTotal>)->Result<(),String>{ let mut s=String::new(); if inp=="stdin"{ io::stdin().read_to_string(&mut s).map_err(|e|e.to_string())?; } else { s=fs::read_to_string(inp).map_err(|e|e.to_string())?; } let v:Value=serde_json::from_str(&s).map_err(|e|e.to_string())?; if let Value::Object(map)=v { for (k,val) in map { if k=="Total"{continue;} if let (Some(b),Some(c),Some(cm))=(val.get("blanks").and_then(Value::as_u64),val.get("code").and_then(Value::as_u64),val.get("comments").and_then(Value::as_u64)){ let lt=totals.entry(k).or_default(); lt.stats.blanks+=b; lt.stats.code+=c; lt.stats.comments+=cm; } } } Ok(()) }
