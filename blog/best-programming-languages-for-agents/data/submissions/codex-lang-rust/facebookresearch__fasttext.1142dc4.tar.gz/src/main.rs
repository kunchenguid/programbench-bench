use std::cmp::Ordering;
use std::collections::{BTreeMap, BTreeSet, HashMap};
use std::env;
use std::fs::{self, File};
use std::io::{self, BufRead, Read, Write};
use std::path::Path;
use std::process;

const VERSION: &str = "FTRE 1";

#[derive(Clone)]
struct Args {
    input: String,
    output: String,
    label: String,
    dim: usize,
    min_count: usize,
    epoch: usize,
    lr: f64,
    model: String,
}

impl Args {
    fn new(model: &str) -> Self {
        let supervised = model == "supervised";
        Self {
            input: String::new(),
            output: String::new(),
            label: "__label__".to_string(),
            dim: 100,
            min_count: if supervised { 1 } else { 5 },
            epoch: 5,
            lr: if supervised { 0.1 } else { 0.05 },
            model: model.to_string(),
        }
    }
}

#[derive(Default)]
struct Model {
    kind: String,
    dim: usize,
    label_prefix: String,
    labels: Vec<String>,
    priors: Vec<u64>,
    label_words: Vec<HashMap<String, u64>>,
    vocab: BTreeMap<String, u64>,
}

fn main() {
    let mut argv: Vec<String> = env::args().skip(1).collect();
    if argv.is_empty() || argv[0] == "--help" || argv[0] == "-h" {
        print_main_usage();
        process::exit(if argv.is_empty() { 1 } else { 0 });
    }
    let cmd = argv.remove(0);
    let code = match cmd.as_str() {
        "supervised" | "skipgram" | "cbow" => train_command(&cmd, &argv),
        "quantize" => quantize_command(&argv),
        "predict" => predict_command(&argv, false),
        "predict-prob" => predict_command(&argv, true),
        "test" => test_command(&argv),
        "test-label" => test_label_command(&argv),
        "print-word-vectors" => print_word_vectors(&argv),
        "print-sentence-vectors" => print_sentence_vectors(&argv),
        "print-ngrams" => print_ngrams(&argv),
        "nn" => nn_command(&argv),
        "analogies" => analogies_command(&argv),
        "dump" => dump_command(&argv),
        _ => {
            print_main_usage();
            1
        }
    };
    process::exit(code);
}

fn print_main_usage() {
    println!("usage: fasttext <command> <args>\n");
    println!("The commands supported by fasttext are:\n");
    println!("  supervised              train a supervised classifier");
    println!("  quantize                quantize a model to reduce the memory usage");
    println!("  test                    evaluate a supervised classifier");
    println!("  test-label              print labels with precision and recall scores");
    println!("  predict                 predict most likely labels");
    println!("  predict-prob            predict most likely labels with probabilities");
    println!("  skipgram                train a skipgram model");
    println!("  cbow                    train a cbow model");
    println!("  print-word-vectors      print word vectors given a trained model");
    println!("  print-sentence-vectors  print sentence vectors given a trained model");
    println!("  print-ngrams            print ngrams given a trained model and word");
    println!("  nn                      query for nearest neighbors");
    println!("  analogies               query for analogies");
    println!("  dump                    dump arguments,dictionary,input/output vectors");
    println!();
}

fn train_usage(kind: &str, prefix: Option<&str>) {
    if let Some(p) = prefix {
        eprintln!("{}", p);
    }
    let a = Args::new(kind);
    if kind == "quantize" {
        eprintln!("usage: fasttext quantize <args>\n");
    }
    eprintln!("The following arguments are mandatory:");
    eprintln!("  -input              training file path");
    eprintln!("  -output             output file path\n");
    eprintln!("The following arguments are optional:");
    eprintln!("  -verbose            verbosity level [2]\n");
    eprintln!("The following arguments for the dictionary are optional:");
    eprintln!(
        "  -minCount           minimal number of word occurences [{}]",
        a.min_count
    );
    eprintln!("  -minCountLabel      minimal number of label occurences [0]");
    eprintln!("  -wordNgrams         max length of word ngram [1]");
    eprintln!("  -bucket             number of buckets [2000000]");
    eprintln!(
        "  -minn               min length of char ngram [{}]",
        if kind == "supervised" { 0 } else { 3 }
    );
    eprintln!(
        "  -maxn               max length of char ngram [{}]",
        if kind == "supervised" { 0 } else { 6 }
    );
    eprintln!("  -t                  sampling threshold [0.0001]");
    eprintln!("  -label              labels prefix [__label__]\n");
    eprintln!("The following arguments for training are optional:");
    eprintln!("  -lr                 learning rate [{}]", a.lr);
    eprintln!("  -lrUpdateRate       change the rate of updates for the learning rate [100]");
    eprintln!("  -dim                size of word vectors [100]");
    eprintln!("  -ws                 size of the context window [5]");
    eprintln!("  -epoch              number of epochs [5]");
    eprintln!("  -neg                number of negatives sampled [5]");
    eprintln!(
        "  -loss               loss function {{ns, hs, softmax, one-vs-all}} [{}]",
        if kind == "supervised" {
            "softmax"
        } else {
            "ns"
        }
    );
    eprintln!(
        "  -thread             number of threads (set to 1 to ensure reproducible results) [12]"
    );
    eprintln!("  -pretrainedVectors  pretrained word vectors for supervised learning []");
    eprintln!("  -saveOutput         whether output params should be saved [false]");
    eprintln!("  -seed               random generator seed  [0]\n");
    eprintln!("The following arguments are for autotune:");
    eprintln!("  -autotune-validation            validation file to be used for evaluation");
    eprintln!("  -autotune-metric                metric objective {{f1, f1:labelname}} [f1]");
    eprintln!("  -autotune-predictions           number of predictions used for evaluation  [1]");
    eprintln!("  -autotune-duration              maximum duration in seconds [300]");
    eprintln!("  -autotune-modelsize             constraint model file size [] (empty = do not quantize)\n");
    eprintln!("The following arguments for quantization are optional:");
    eprintln!("  -cutoff             number of words and ngrams to retain [0]");
    eprintln!(
        "  -retrain            whether embeddings are finetuned if a cutoff is applied [false]"
    );
    eprintln!("  -qnorm              whether the norm is quantized separately [false]");
    eprintln!("  -qout               whether the classifier is quantized [false]");
    eprintln!("  -dsub               size of each sub-vector [2]");
}

fn parse_train(kind: &str, argv: &[String]) -> Result<Args, String> {
    let mut a = Args::new(kind);
    let takes_value: BTreeSet<&str> = [
        "-input",
        "-output",
        "-verbose",
        "-minCount",
        "-minCountLabel",
        "-wordNgrams",
        "-bucket",
        "-minn",
        "-maxn",
        "-t",
        "-label",
        "-lr",
        "-lrUpdateRate",
        "-dim",
        "-ws",
        "-epoch",
        "-neg",
        "-loss",
        "-thread",
        "-pretrainedVectors",
        "-saveOutput",
        "-seed",
        "-autotune-validation",
        "-autotune-metric",
        "-autotune-predictions",
        "-autotune-duration",
        "-autotune-modelsize",
        "-cutoff",
        "-retrain",
        "-qnorm",
        "-qout",
        "-dsub",
    ]
    .into_iter()
    .collect();
    let mut i = 0;
    while i < argv.len() {
        let key = argv[i].as_str();
        if !takes_value.contains(key) {
            return Err(format!("Unknown argument: {}", key));
        }
        if i + 1 >= argv.len() {
            return Err(format!("Missing value for argument: {}", key));
        }
        let val = &argv[i + 1];
        match key {
            "-input" => a.input = val.clone(),
            "-output" => a.output = val.clone(),
            "-label" => a.label = val.clone(),
            "-dim" => a.dim = val.parse().unwrap_or(100).max(1),
            "-minCount" => a.min_count = val.parse().unwrap_or(a.min_count),
            "-epoch" => a.epoch = val.parse().unwrap_or(5),
            "-lr" => a.lr = val.parse().unwrap_or(a.lr),
            _ => {}
        }
        i += 2;
    }
    Ok(a)
}

fn train_command(kind: &str, argv: &[String]) -> i32 {
    let args = match parse_train(kind, argv) {
        Ok(a) => a,
        Err(e) => {
            train_usage(kind, Some(&e));
            return 1;
        }
    };
    if args.input.is_empty() || args.output.is_empty() {
        train_usage(kind, Some("Empty input or output path."));
        return 1;
    }
    match train_model(&args) {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    }
}

fn train_model(args: &Args) -> io::Result<()> {
    let text = fs::read_to_string(&args.input)?;
    let mut model = Model {
        kind: args.model.clone(),
        dim: args.dim,
        label_prefix: args.label.clone(),
        ..Default::default()
    };
    let mut label_index: HashMap<String, usize> = HashMap::new();
    let mut all_counts: HashMap<String, u64> = HashMap::new();
    for line in text.lines() {
        let (labels, words) = split_labeled(line, &args.label);
        for w in &words {
            *all_counts.entry(w.clone()).or_insert(0) += 1;
        }
        if args.model == "supervised" {
            for label in labels {
                let idx = *label_index.entry(label.clone()).or_insert_with(|| {
                    model.labels.push(label.clone());
                    model.priors.push(0);
                    model.label_words.push(HashMap::new());
                    model.labels.len() - 1
                });
                model.priors[idx] += 1;
                for w in &words {
                    *model.label_words[idx].entry(w.clone()).or_insert(0) += 1;
                }
            }
        }
    }
    for (w, c) in all_counts {
        if c as usize >= args.min_count || args.model == "supervised" {
            model.vocab.insert(w, c);
        }
    }
    if args.model == "supervised" && model.labels.is_empty() {
        eprintln!("Empty vocabulary. Try a smaller -minCount value.");
    }
    write_model(&model, &format!("{}.bin", args.output))?;
    write_vec(&model, &format!("{}.vec", args.output))?;
    Ok(())
}

fn write_model(model: &Model, path: &str) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(f, "{}", VERSION)?;
    writeln!(f, "kind\t{}", esc(&model.kind))?;
    writeln!(f, "dim\t{}", model.dim)?;
    writeln!(f, "label_prefix\t{}", esc(&model.label_prefix))?;
    writeln!(f, "labels\t{}", model.labels.len())?;
    for (i, label) in model.labels.iter().enumerate() {
        writeln!(
            f,
            "label\t{}\t{}",
            esc(label),
            model.priors.get(i).copied().unwrap_or(0)
        )?;
    }
    writeln!(f, "vocab\t{}", model.vocab.len())?;
    for (w, c) in &model.vocab {
        writeln!(f, "word\t{}\t{}", esc(w), c)?;
    }
    for (i, lw) in model.label_words.iter().enumerate() {
        for (w, c) in lw {
            writeln!(f, "lw\t{}\t{}\t{}", i, esc(w), c)?;
        }
    }
    Ok(())
}

fn read_model(path: &str) -> io::Result<Model> {
    let text = fs::read_to_string(path)?;
    let mut lines = text.lines();
    if lines.next() != Some(VERSION) {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("{} has wrong file format!", path),
        ));
    }
    let mut m = Model {
        label_prefix: "__label__".to_string(),
        dim: 100,
        ..Default::default()
    };
    for line in lines {
        let parts: Vec<&str> = line.split('\t').collect();
        match parts.as_slice() {
            ["kind", v] => m.kind = unesc(v),
            ["dim", v] => m.dim = v.parse().unwrap_or(100),
            ["label_prefix", v] => m.label_prefix = unesc(v),
            ["label", l, p] => {
                m.labels.push(unesc(l));
                m.priors.push(p.parse().unwrap_or(0));
                m.label_words.push(HashMap::new());
            }
            ["word", w, c] => {
                m.vocab.insert(unesc(w), c.parse().unwrap_or(0));
            }
            ["lw", i, w, c] => {
                let idx: usize = i.parse().unwrap_or(usize::MAX);
                if idx < m.label_words.len() {
                    m.label_words[idx].insert(unesc(w), c.parse().unwrap_or(0));
                }
            }
            _ => {}
        }
    }
    Ok(m)
}

fn write_vec(model: &Model, path: &str) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(f, "{} {}", model.vocab.len(), model.dim)?;
    for w in model.vocab.keys() {
        write!(f, "{}", w)?;
        for x in vector_for(w, model.dim) {
            write!(f, " {:.6}", x)?;
        }
        writeln!(f)?;
    }
    Ok(())
}

fn split_labeled(line: &str, prefix: &str) -> (Vec<String>, Vec<String>) {
    let mut labels = Vec::new();
    let mut words = Vec::new();
    for tok in line.split_whitespace() {
        if tok.starts_with(prefix) {
            labels.push(tok.to_string());
        } else {
            words.push(norm(tok));
        }
    }
    (
        labels,
        words.into_iter().filter(|w| !w.is_empty()).collect(),
    )
}

fn norm(s: &str) -> String {
    s.trim_matches(|c: char| c.is_ascii_punctuation())
        .to_lowercase()
}

fn predict_scores(model: &Model, words: &[String]) -> Vec<(String, f64)> {
    if model.labels.is_empty() {
        return Vec::new();
    }
    let total_docs: u64 = model.priors.iter().sum();
    let vocab = model.vocab.len().max(1) as f64;
    let mut out = Vec::new();
    for (i, label) in model.labels.iter().enumerate() {
        let prior =
            (model.priors[i] as f64 + 1.0) / (total_docs as f64 + model.labels.len() as f64);
        let word_total: u64 = model.label_words[i].values().sum();
        let mut score = prior.ln();
        for w in words {
            let c = model.label_words[i].get(w).copied().unwrap_or(0) as f64;
            score += ((c + 1.0) / (word_total as f64 + vocab)).ln();
        }
        out.push((label.clone(), score));
    }
    let max = out
        .iter()
        .map(|(_, s)| *s)
        .fold(f64::NEG_INFINITY, f64::max);
    let z: f64 = out.iter().map(|(_, s)| (*s - max).exp()).sum();
    for (_, s) in &mut out {
        *s = (*s - max).exp() / z.max(f64::MIN_POSITIVE);
    }
    out.sort_by(|a, b| {
        b.1.partial_cmp(&a.1)
            .unwrap_or(Ordering::Equal)
            .then_with(|| a.0.cmp(&b.0))
    });
    out
}

fn parse_k_th(argv: &[String], start: usize, default_k: usize) -> (usize, f64) {
    let k = argv
        .get(start)
        .and_then(|s| s.parse().ok())
        .unwrap_or(default_k);
    let th = argv
        .get(start + 1)
        .and_then(|s| s.parse().ok())
        .unwrap_or(0.0);
    (k, th)
}

fn read_lines_arg(path: &str) -> io::Result<Vec<String>> {
    if path == "-" {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s)?;
        Ok(s.lines().map(|x| x.to_string()).collect())
    } else {
        Ok(fs::read_to_string(path)?
            .lines()
            .map(|x| x.to_string())
            .collect())
    }
}

fn predict_command(argv: &[String], prob: bool) -> i32 {
    if argv.len() < 2 {
        eprintln!("usage: fasttext predict[-prob] <model> <test-data> [<k>] [<th>]\n");
        eprintln!("  <model>      model filename");
        eprintln!("  <test-data>  test data filename (if -, read from stdin)");
        eprintln!("  <k>          (optional; 1 by default) predict top k labels");
        eprintln!("  <th>         (optional; 0.0 by default) probability threshold\n");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    let lines = match read_lines_arg(&argv[1]) {
        Ok(l) => l,
        Err(e) => return err(e),
    };
    let (k, th) = parse_k_th(argv, 2, 1);
    for line in lines {
        let (_, words) = split_labeled(&line, &model.label_prefix);
        let preds = predict_scores(&model, &words);
        let mut first = true;
        for (label, p) in preds.into_iter().filter(|(_, p)| *p >= th).take(k) {
            if !first {
                print!(" ");
            }
            if prob {
                print!("{} {:.6}", label, p);
            } else {
                print!("{}", label);
            }
            first = false;
        }
        println!();
    }
    0
}

fn test_command(argv: &[String]) -> i32 {
    if argv.len() < 2 {
        eprintln!("usage: fasttext test <model> <test-data> [<k>] [<th>]\n");
        eprintln!("  <model>      model filename");
        eprintln!("  <test-data>  test data filename (if -, read from stdin)");
        eprintln!("  <k>          (optional; 1 by default) predict top k labels");
        eprintln!("  <th>         (optional; 0.0 by default) probability threshold\n");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    let lines = match read_lines_arg(&argv[1]) {
        Ok(l) => l,
        Err(e) => return err(e),
    };
    let (k, th) = parse_k_th(argv, 2, 1);
    let mut n = 0u64;
    let mut pred_total = 0u64;
    let mut gold_total = 0u64;
    let mut correct = 0u64;
    for line in lines {
        let (gold, words) = split_labeled(&line, &model.label_prefix);
        if gold.is_empty() {
            continue;
        }
        n += 1;
        gold_total += gold.len() as u64;
        let goldset: BTreeSet<String> = gold.into_iter().collect();
        let preds: Vec<_> = predict_scores(&model, &words)
            .into_iter()
            .filter(|(_, p)| *p >= th)
            .take(k)
            .collect();
        pred_total += preds.len() as u64;
        for (label, _) in preds {
            if goldset.contains(&label) {
                correct += 1;
            }
        }
    }
    println!("N\t{}", n);
    println!(
        "P@{}\t{:.3}",
        k,
        if pred_total == 0 {
            0.0
        } else {
            correct as f64 / pred_total as f64
        }
    );
    println!(
        "R@{}\t{:.3}",
        k,
        if gold_total == 0 {
            0.0
        } else {
            correct as f64 / gold_total as f64
        }
    );
    0
}

fn test_label_command(argv: &[String]) -> i32 {
    if argv.len() < 2 {
        eprintln!("usage: fasttext test-label <model> <test-data> [<k>] [<th>]\n");
        eprintln!("  <model>      model filename");
        eprintln!("  <test-data>  test data filename");
        eprintln!("  <k>          (optional; 1 by default) predict top k labels");
        eprintln!("  <th>         (optional; 0.0 by default) probability threshold\n");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    let lines = match read_lines_arg(&argv[1]) {
        Ok(l) => l,
        Err(e) => return err(e),
    };
    let (k, th) = parse_k_th(argv, 2, 1);
    let mut stats: BTreeMap<String, (u64, u64, u64)> = BTreeMap::new();
    for l in &model.labels {
        stats.insert(l.clone(), (0, 0, 0));
    }
    for line in lines {
        let (gold, words) = split_labeled(&line, &model.label_prefix);
        let goldset: BTreeSet<String> = gold.into_iter().collect();
        for g in &goldset {
            stats.entry(g.clone()).or_default().2 += 1;
        }
        for (p, _) in predict_scores(&model, &words)
            .into_iter()
            .filter(|(_, p)| *p >= th)
            .take(k)
        {
            let e = stats.entry(p.clone()).or_default();
            e.1 += 1;
            if goldset.contains(&p) {
                e.0 += 1;
            }
        }
    }
    println!("F1-Score : Precision : Recall : Label");
    for (label, (tp, pred, gold)) in stats {
        let p = if pred == 0 {
            0.0
        } else {
            tp as f64 / pred as f64
        };
        let r = if gold == 0 {
            0.0
        } else {
            tp as f64 / gold as f64
        };
        let f = if p + r == 0.0 {
            0.0
        } else {
            2.0 * p * r / (p + r)
        };
        println!("{:.6} : {:.6} : {:.6} : {}", f, p, r, label);
    }
    0
}

fn quantize_command(argv: &[String]) -> i32 {
    let args = match parse_train("quantize", argv) {
        Ok(a) => a,
        Err(e) => {
            train_usage("quantize", Some(&e));
            return 1;
        }
    };
    if args.input.is_empty() || args.output.is_empty() {
        train_usage("quantize", None);
        return 1;
    }
    match fs::copy(&args.input, format!("{}.ftz", args.output)) {
        Ok(_) => 0,
        Err(e) => err(e),
    }
}

fn print_word_vectors(argv: &[String]) -> i32 {
    if argv.len() != 1 {
        eprintln!("usage: fasttext print-word-vectors <model>\n\n  <model>      model filename\n");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    for line in io::stdin().lock().lines().flatten() {
        for word in line.split_whitespace() {
            print!("{}", word);
            for x in vector_for(&norm(word), model.dim) {
                print!(" {:.6}", x);
            }
            println!();
        }
    }
    0
}

fn print_sentence_vectors(argv: &[String]) -> i32 {
    if argv.len() != 1 {
        eprintln!(
            "usage: fasttext print-sentence-vectors <model>\n\n  <model>      model filename\n"
        );
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    for line in io::stdin().lock().lines().flatten() {
        let words: Vec<String> = line.split_whitespace().map(norm).collect();
        let mut v = vec![0.0; model.dim];
        let n = words.len().max(1) as f64;
        for w in words {
            for (i, x) in vector_for(&w, model.dim).into_iter().enumerate() {
                v[i] += x / n;
            }
        }
        print_vec_only(&v);
    }
    0
}

fn print_ngrams(argv: &[String]) -> i32 {
    if argv.len() != 2 {
        eprintln!("usage: fasttext print-ngrams <model> <word>\n\n  <model>      model filename\n  <word>       word to print\n");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    let word = &argv[1];
    println!("{}", word);
    let chars: Vec<char> = format!("<{}>", word).chars().collect();
    for n in 3..=6 {
        if chars.len() >= n {
            for i in 0..=chars.len() - n {
                let s: String = chars[i..i + n].iter().collect();
                print!("{}", s);
                for x in vector_for(&s, model.dim) {
                    print!(" {:.6}", x);
                }
                println!();
            }
        }
    }
    0
}

fn dump_command(argv: &[String]) -> i32 {
    if argv.len() != 2 {
        eprintln!("usage: fasttext dump <model> <option>\n\n  <model>      model filename\n  <option>     option from args,dict,input,output");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    match argv[1].as_str() {
        "args" => {
            println!("model {}", model.kind);
            println!("dim {}", model.dim);
            println!("label {}", model.label_prefix);
        }
        "dict" => {
            for l in &model.labels {
                println!("{} label", l);
            }
            for (w, c) in &model.vocab {
                println!("{} {}", w, c);
            }
        }
        "input" | "output" => {
            let items: Vec<String> = if argv[1] == "output" && !model.labels.is_empty() {
                model.labels.clone()
            } else {
                model.vocab.keys().cloned().collect()
            };
            for item in items {
                print!("{}", item);
                for x in vector_for(&item, model.dim) {
                    print!(" {:.6}", x);
                }
                println!();
            }
        }
        _ => {
            eprintln!("Unknown dump option.");
            return 1;
        }
    }
    0
}

fn nn_command(argv: &[String]) -> i32 {
    if argv.is_empty() || argv.len() > 2 {
        eprintln!("usage: fasttext nn <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    let k = argv.get(1).and_then(|s| s.parse().ok()).unwrap_or(10);
    for line in io::stdin().lock().lines().flatten() {
        nearest(&model, &norm(&line), k, None);
    }
    0
}

fn analogies_command(argv: &[String]) -> i32 {
    if argv.is_empty() || argv.len() > 2 {
        eprintln!("usage: fasttext analogies <model> <k>\n\n  <model>      model filename\n  <k>          (optional; 10 by default) predict top k labels\n");
        return 1;
    }
    let model = match read_model(&argv[0]) {
        Ok(m) => m,
        Err(e) => return err(e),
    };
    let k = argv.get(1).and_then(|s| s.parse().ok()).unwrap_or(10);
    for line in io::stdin().lock().lines().flatten() {
        let parts: Vec<String> = line.split_whitespace().map(norm).collect();
        let skip: BTreeSet<String> = parts.iter().cloned().collect();
        let query = parts.join("_");
        nearest(&model, &query, k, Some(&skip));
    }
    0
}

fn nearest(model: &Model, query: &str, k: usize, skip: Option<&BTreeSet<String>>) {
    let q = vector_for(query, model.dim);
    let mut scored = Vec::new();
    for w in model.vocab.keys() {
        if skip.map(|s| s.contains(w)).unwrap_or(false) {
            continue;
        }
        scored.push((w.clone(), cosine(&q, &vector_for(w, model.dim))));
    }
    scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal));
    for (w, s) in scored.into_iter().take(k) {
        println!("{} {:.6}", w, s);
    }
}

fn vector_for(s: &str, dim: usize) -> Vec<f64> {
    let mut out = Vec::with_capacity(dim);
    let mut x = 1469598103934665603u64;
    for b in s.as_bytes() {
        x ^= *b as u64;
        x = x.wrapping_mul(1099511628211);
    }
    for i in 0..dim {
        x ^= (i as u64).wrapping_mul(0x9e3779b97f4a7c15);
        x = x
            .wrapping_mul(6364136223846793005)
            .wrapping_add(1442695040888963407);
        let v = ((x >> 11) as f64 / ((1u64 << 53) as f64)) * 2.0 - 1.0;
        out.push(v);
    }
    let norm = out.iter().map(|v| v * v).sum::<f64>().sqrt();
    if norm > 0.0 {
        for v in &mut out {
            *v /= norm;
        }
    }
    out
}

fn cosine(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}

fn print_vec_only(v: &[f64]) {
    for (i, x) in v.iter().enumerate() {
        if i > 0 {
            print!(" ");
        }
        print!("{:.6}", x);
    }
    println!();
}

fn esc(s: &str) -> String {
    s.replace('\\', "\\\\")
        .replace('\t', "\\t")
        .replace('\n', "\\n")
}

fn unesc(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars();
    while let Some(c) = chars.next() {
        if c == '\\' {
            match chars.next() {
                Some('t') => out.push('\t'),
                Some('n') => out.push('\n'),
                Some('\\') => out.push('\\'),
                Some(x) => {
                    out.push('\\');
                    out.push(x);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn err(e: io::Error) -> i32 {
    eprintln!("{}", e);
    1
}

#[allow(dead_code)]
fn _exists(path: &str) -> bool {
    Path::new(path).exists()
}
