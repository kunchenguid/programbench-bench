use std::cmp::Ordering;
use std::env;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "0.9.9";
const AUTHOR: &str = "Ajeet D'Souza <98ajeet@gmail.com>\nhttps://github.com/ajeetdsouza/zoxide";

#[derive(Clone, Debug)]
struct Entry { path: String, score: f64, ts: u64 }

fn now() -> u64 { SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs() }

fn data_dir() -> PathBuf {
    if let Ok(v) = env::var("_ZO_DATA_DIR") { return PathBuf::from(v); }
    if let Ok(xdg) = env::var("XDG_DATA_HOME") { return PathBuf::from(xdg).join("zoxide"); }
    if let Ok(home) = env::var("HOME") { return PathBuf::from(home).join(".local/share/zoxide"); }
    PathBuf::from(".zoxide")
}
fn db_path() -> PathBuf { data_dir().join("db.zo") }

fn read_u32(b: &[u8], i: &mut usize) -> Option<u32> { if *i+4>b.len(){None}else{let mut a=[0;4];a.copy_from_slice(&b[*i..*i+4]);*i+=4;Some(u32::from_le_bytes(a))} }
fn read_u64(b: &[u8], i: &mut usize) -> Option<u64> { if *i+8>b.len(){None}else{let mut a=[0;8];a.copy_from_slice(&b[*i..*i+8]);*i+=8;Some(u64::from_le_bytes(a))} }
fn read_f64(b: &[u8], i: &mut usize) -> Option<f64> { read_u64(b,i).map(f64::from_bits) }

fn load_db() -> Vec<Entry> {
    let p = db_path();
    let mut f = match File::open(&p) { Ok(f) => f, Err(_) => return Vec::new() };
    let mut b = Vec::new(); if f.read_to_end(&mut b).is_err() { return Vec::new(); }
    let mut i=0usize; let _ver = match read_u32(&b,&mut i){Some(v)=>v,None=>return Vec::new()};
    let n = match read_u64(&b,&mut i){Some(v)=>v as usize,None=>return Vec::new()};
    let mut out=Vec::new();
    for _ in 0..n {
        let len=match read_u64(&b,&mut i){Some(v)=>v as usize,None=>break};
        if i+len>b.len(){break}
        let path=String::from_utf8_lossy(&b[i..i+len]).into_owned(); i+=len;
        let score=match read_f64(&b,&mut i){Some(v)=>v,None=>break};
        let ts=match read_u64(&b,&mut i){Some(v)=>v,None=>break};
        out.push(Entry{path,score,ts});
    }
    out
}
fn save_db(entries: &[Entry]) -> io::Result<()> {
    fs::create_dir_all(data_dir())?;
    let mut tmp = db_path(); tmp.set_extension("zo.tmp");
    let mut f=File::create(&tmp)?;
    f.write_all(&3u32.to_le_bytes())?;
    f.write_all(&(entries.len() as u64).to_le_bytes())?;
    for e in entries {
        f.write_all(&(e.path.as_bytes().len() as u64).to_le_bytes())?;
        f.write_all(e.path.as_bytes())?;
        f.write_all(&e.score.to_bits().to_le_bytes())?;
        f.write_all(&e.ts.to_le_bytes())?;
    }
    fs::rename(tmp, db_path())
}

fn canonicalish(p: &str) -> String {
    let path = PathBuf::from(p);
    let pb = if env::var("_ZO_RESOLVE_SYMLINKS").ok().as_deref()==Some("1") { fs::canonicalize(&path).unwrap_or(path) } else if path.is_absolute() { path } else { env::current_dir().unwrap_or_else(|_|PathBuf::from(".")).join(path) };
    pb.to_string_lossy().trim_end_matches('/').to_string()
}
fn excluded(path: &str) -> bool {
    let spec = env::var("_ZO_EXCLUDE_DIRS").unwrap_or_else(|_| env::var("HOME").unwrap_or_default());
    for pat in spec.split(':').filter(|s| !s.is_empty()) {
        if pat.ends_with("/*") { if path.starts_with(pat.trim_end_matches('*')) { return true; } }
        else if path == pat || path.starts_with(&(pat.to_string()+"/")) { return true; }
    }
    false
}
fn age(entries: &mut [Entry]) {
    let maxage: f64 = env::var("_ZO_MAXAGE").ok().and_then(|s|s.parse().ok()).unwrap_or(10000.0);
    let total: f64 = entries.iter().map(|e| e.score).sum();
    if total > maxage && total > 0.0 { let f = maxage * 0.9 / total; for e in entries { e.score *= f; } }
}

fn print_top_help() {
    println!("zoxide {VERSION}\n{AUTHOR}\n\nA smarter cd command for your terminal\n\nUsage:\n  executable <COMMAND>\n\nCommands:\n  add     Add a new directory or increment its rank\n  edit    Edit the database\n  import  Import entries from another application\n  init    Generate shell configuration\n  query   Search for a directory in the database\n  remove  Remove a directory from the database\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n\nEnvironment variables:\n  _ZO_DATA_DIR          Path for zoxide data files\n  _ZO_ECHO              Print the matched directory before navigating to it when set to 1\n  _ZO_EXCLUDE_DIRS      List of directory globs to be excluded\n  _ZO_FZF_OPTS          Custom flags to pass to fzf\n  _ZO_MAXAGE            Maximum total age after which entries start getting deleted\n  _ZO_RESOLVE_SYMLINKS  Resolve symlinks when storing paths");
}
fn sub_help(name:&str) {
    match name {
        "add"=>println!("zoxide-add {VERSION}\n{AUTHOR}\n\nAdd a new directory or increment its rank\n\nUsage:\n  executable add [OPTIONS] <PATHS>...\n\nOptions:\n  -s, --score <SCORE>  The rank to increment the entry if it exists or initialize it with if it doesn't\n  -h, --help           Print help\n  -V, --version        Print version"),
        "query"=>println!("zoxide-query {VERSION}\n{AUTHOR}\n\nSearch for a directory in the database\n\nUsage:\n  executable query [OPTIONS] [KEYWORDS]...\n\nOptions:\n  -a, --all              Show unavailable directories\n  -i, --interactive      Use interactive selection\n  -l, --list             List all matching directories\n  -s, --score            Print score with results\n      --exclude <path>   Exclude the current directory\n      --base-dir <path>  Only search within this directory\n  -h, --help             Print help\n  -V, --version          Print version"),
        "remove"=>println!("zoxide-remove {VERSION}\n{AUTHOR}\n\nRemove a directory from the database\n\nUsage:\n  executable remove [PATHS]...\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"),
        "import"=>println!("zoxide-import {VERSION}\n{AUTHOR}\n\nImport entries from another application\n\nUsage:\n  executable import [OPTIONS] --from <FROM> <PATH>\n\nOptions:\n      --from <FROM>  Application to import from [possible values: autojump, z]\n      --merge        Merge into existing database\n  -h, --help         Print help\n  -V, --version      Print version"),
        "init"=>println!("zoxide-init {VERSION}\n{AUTHOR}\n\nGenerate shell configuration\n\nUsage:\n  executable init [OPTIONS] <SHELL>\n\nOptions:\n      --no-cmd       Prevents zoxide from defining the `z` and `zi` commands\n      --cmd <CMD>    Changes the prefix of the `z` and `zi` commands [default: z]\n      --hook <HOOK>  Changes how often zoxide increments a directory's score [default: pwd] [possible values: none, prompt, pwd]\n  -h, --help         Print help\n  -V, --version      Print version"),
        "edit"=>println!("zoxide-edit {VERSION}\n{AUTHOR}\n\nEdit the database\n\nUsage:\n  executable edit\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"),
        _=>print_top_help()
    }
}

fn add_cmd(args:&[String])->i32{
    let mut score=1.0; let mut paths=Vec::new(); let mut i=0;
    while i<args.len(){ match args[i].as_str(){"-h"|"--help"=>{sub_help("add");return 0},"-V"|"--version"=>{println!("zoxide-add {VERSION}");return 0},"-s"|"--score"=>{i+=1; score=args.get(i).and_then(|s|s.parse().ok()).unwrap_or(1.0)},"--"=>{paths.extend_from_slice(&args[i+1..]);break},x=>paths.push(x.to_string())}; i+=1; }
    if paths.is_empty(){ eprintln!("error: the following required arguments were not provided:\n  <PATHS>..."); return 2; }
    let mut db=load_db(); let t=now();
    for p in paths { let cp=canonicalish(&p); if excluded(&cp) || !Path::new(&cp).is_dir(){continue}; if let Some(e)=db.iter_mut().find(|e|e.path==cp){e.score+=score;e.ts=t}else{db.push(Entry{path:cp,score,ts:t});} }
    age(&mut db); if let Err(e)=save_db(&db){eprintln!("zoxide: {e}");return 1} 0
}
fn matches_keywords(path:&str, keys:&[String])->bool{
    if keys.is_empty() { return true; }
    let low = path.to_lowercase();
    let base = Path::new(path).file_name().and_then(|s| s.to_str()).unwrap_or(path).to_lowercase();
    if !base.contains(&keys[keys.len()-1].to_lowercase()) { return false; }
    let mut pos = 0usize;
    for k in keys {
        let kk = k.to_lowercase();
        if let Some(found) = low[pos..].find(&kk) { pos += found + kk.len(); } else { return false; }
    }
    true
}
fn frecency(e:&Entry)->f64{ let age=now().saturating_sub(e.ts); let mult= if age<3600{4.0}else if age<86400{2.0}else if age<604800{0.5}else{0.25}; e.score*mult }
fn query_cmd(args:&[String])->i32{
    let mut all=false; let mut list=false; let mut score=false; let mut interactive=false; let mut exclude:Option<String>=None; let mut base:Option<String>=None; let mut keys=Vec::new(); let mut i=0;
    while i<args.len(){ match args[i].as_str(){"-h"|"--help"=>{sub_help("query");return 0},"-V"|"--version"=>{println!("zoxide-query {VERSION}");return 0},"-a"|"--all"=>all=true,"-l"|"--list"=>list=true,"-s"|"--score"=>score=true,"-i"|"--interactive"=>interactive=true,"--exclude"=>{i+=1;exclude=args.get(i).map(|s|canonicalish(s))},"--base-dir"=>{i+=1;base=args.get(i).map(|s|canonicalish(s))},"--"=>{keys.extend_from_slice(&args[i+1..]);break},x if x.starts_with('-') && x.len()>2 => { for ch in x[1..].chars(){ match ch {'a'=>all=true,'l'=>list=true,'s'=>score=true,'i'=>interactive=true,_=>keys.push(format!("-{ch}"))} } },x=>keys.push(x.to_string())}; i+=1; }
    let mut v:Vec<Entry>=load_db().into_iter().filter(|e| (all||Path::new(&e.path).is_dir()) && exclude.as_ref()!=Some(&e.path) && base.as_ref().map_or(true, |b| e.path.starts_with(b)) && matches_keywords(&e.path,&keys)).collect();
    v.sort_by(|a,b| frecency(b).partial_cmp(&frecency(a)).unwrap_or(Ordering::Equal).then_with(|| b.path.cmp(&a.path)));
    if interactive { return interactive_query(v, score); }
    if v.is_empty(){ eprintln!("zoxide: no match found"); return 1; }
    if list { for e in v { if score{println!("{:6.1} {}",frecency(&e),e.path)}else{println!("{}",e.path)} } } else { let e=&v[0]; if score{println!("{:6.1} {}",frecency(e),e.path)}else{println!("{}",e.path)} }
    0
}
fn interactive_query(v:Vec<Entry>, score:bool)->i32{
    if v.is_empty(){eprintln!("zoxide: no match found");return 1}
    let mut child=match Command::new("fzf").args(env::var("_ZO_FZF_OPTS").unwrap_or_default().split_whitespace()).stdin(Stdio::piped()).stdout(Stdio::piped()).spawn(){Ok(c)=>c,Err(_)=>{println!("{}",v[0].path);return 0}};
    if let Some(stdin)=child.stdin.as_mut(){ for e in &v { let _=writeln!(stdin,"{}",e.path); } }
    let out=child.wait_with_output().unwrap(); if !out.status.success(){return out.status.code().unwrap_or(1)}
    let s=String::from_utf8_lossy(&out.stdout).trim().to_string(); if score { if let Some(e)=v.iter().find(|e|e.path==s){println!("{:6.1} {}",frecency(e),e.path);return 0} }
    println!("{s}"); 0
}
fn remove_cmd(args:&[String])->i32{ if args.iter().any(|a|a=="-h"||a=="--help"){sub_help("remove");return 0} if args.iter().any(|a|a=="-V"||a=="--version"){println!("zoxide-remove {VERSION}");return 0} let rem:Vec<String>=args.iter().filter(|a|a.as_str()!="--").map(|s|canonicalish(s)).collect(); let mut db=load_db(); if rem.is_empty(){ db.retain(|e|Path::new(&e.path).is_dir()); } else { db.retain(|e|!rem.contains(&e.path)); } if let Err(e)=save_db(&db){eprintln!("zoxide: {e}");return 1} 0 }
fn import_cmd(args:&[String])->i32{ if args.iter().any(|a|a=="-h"||a=="--help"){sub_help("import");return 0} let mut from="".to_string(); let mut merge=false; let mut file="".to_string(); let mut i=0; while i<args.len(){match args[i].as_str(){"--from"=>{i+=1;from=args.get(i).cloned().unwrap_or_default()},"--merge"=>merge=true,x=>file=x.to_string()}; i+=1;} if from!="z"&&from!="autojump"{eprintln!("error: invalid value '{from}' for '--from <FROM>'");return 2} let txt=match fs::read_to_string(&file){Ok(s)=>s,Err(e)=>{eprintln!("zoxide: {e}");return 1}}; let mut db=load_db(); if !merge && !db.is_empty(){ eprintln!("zoxide: current database is not empty, specify --merge to continue anyway"); return 1; } if !merge { db.clear(); } for line in txt.lines(){ let parts:Vec<&str>=line.split('|').collect(); if parts.len()>=2{ let p=canonicalish(parts[0]); let sc=parts[1].parse().unwrap_or(1.0); let ts=parts.get(2).and_then(|s|s.parse().ok()).unwrap_or_else(now); db.push(Entry{path:p,score:sc,ts}); } else { let mut sp=line.split_whitespace().collect::<Vec<_>>(); if sp.len()>=2{ let sc=sp.pop().unwrap().parse().unwrap_or(1.0); db.push(Entry{path:canonicalish(&sp.join(" ")),score:sc,ts:now()}); } } } if let Err(e)=save_db(&db){eprintln!("zoxide: {e}");return 1} 0 }
fn init_cmd(args:&[String])->i32{ if args.iter().any(|a|a=="-h"||a=="--help"){sub_help("init");return 0} if args.iter().any(|a|a=="-V"||a=="--version"){println!("zoxide-init {VERSION}");return 0} let mut cmd="z".to_string(); let mut no_cmd=false; let mut shell="".to_string(); let mut i=0; while i<args.len(){match args[i].as_str(){"--no-cmd"=>no_cmd=true,"--cmd"=>{i+=1;cmd=args.get(i).cloned().unwrap_or(cmd)},"--hook"=>{i+=1; if let Some(h)=args.get(i){ if !["none","prompt","pwd"].contains(&h.as_str()){ eprintln!("error: invalid value '{h}' for '--hook <HOOK>'"); return 2; } }},x if !x.starts_with('-')=>shell=x.to_string(),_=>{}}; i+=1;} if shell.is_empty(){eprintln!("error: the following required arguments were not provided:\n  <SHELL>");return 2} if !["bash","elvish","fish","nushell","posix","powershell","tcsh","xonsh","zsh"].contains(&shell.as_str()){ eprintln!("error: invalid value '{shell}' for '<SHELL>'"); return 2; } print_init(&shell,&cmd,no_cmd); 0 }
fn print_init(shell:&str, cmd:&str, no_cmd:bool){
    match shell { "bash"|"zsh"|"posix"=>{println!("# shellcheck shell=sh\n__zoxide_pwd() {{ command pwd -L; }}\n__zoxide_cd() {{ command cd \"$@\"; }}\n__zoxide_z() {{\n    if [ \"$#\" -eq 0 ]; then __zoxide_cd ~; elif [ \"$#\" -eq 1 ] && [ -d \"$1\" ]; then __zoxide_cd \"$1\"; else result=$(zoxide query --exclude \"$PWD\" -- \"$@\") && __zoxide_cd \"$result\"; fi\n}}\n__zoxide_zi() {{ result=$(zoxide query -i --exclude \"$PWD\" -- \"$@\") && __zoxide_cd \"$result\"; }}"); if !no_cmd{println!("alias {cmd}=__zoxide_z\nalias {cmd}i=__zoxide_zi");}}
    "fish"=>{println!("function __zoxide_pwd\n    builtin pwd -L\nend\nfunction __zoxide_z\n    set result (zoxide query --exclude (pwd) -- $argv); and cd $result\nend\nfunction __zoxide_zi\n    set result (zoxide query -i --exclude (pwd) -- $argv); and cd $result\nend"); if !no_cmd{println!("alias {cmd}=__zoxide_z\nalias {cmd}i=__zoxide_zi");}}
    "powershell"=>{println!("function global:__zoxide_z {{ $result = zoxide query --exclude $PWD -- $args; if ($LASTEXITCODE -eq 0) {{ Set-Location $result }} }}\nfunction global:__zoxide_zi {{ $result = zoxide query -i --exclude $PWD -- $args; if ($LASTEXITCODE -eq 0) {{ Set-Location $result }} }}"); if !no_cmd{println!("Set-Alias {cmd} __zoxide_z\nSet-Alias {cmd}i __zoxide_zi");}}
    "nushell"=>println!("# Code generated by zoxide. DO NOT EDIT.\ndef --env __zoxide_z [...rest: string] {{ cd (^zoxide query ...$rest | str trim) }}"),
    "elvish"=>println!("fn __zoxide_z {{|@rest| cd (zoxide query $@rest) }}"),
    "tcsh"=>println!("alias __zoxide_z 'set r = `zoxide query \\!*`; cd \"$r\"'"),
    "xonsh"=>println!("def __zoxide_z(args):\n    import os, subprocess\n    os.chdir(subprocess.check_output(['zoxide','query']+args).decode().strip())"),
    _=>eprintln!("error: invalid value '{shell}' for '<SHELL>'"), }
}
fn edit_cmd(args:&[String])->i32{ if args.iter().any(|a|a=="-h"||a=="--help"){sub_help("edit");return 0} let editor=env::var("VISUAL").or_else(|_|env::var("EDITOR")).unwrap_or_else(|_|"vi".into()); let p=db_path(); let _=fs::create_dir_all(data_dir()); Command::new(editor).arg(p).status().ok().and_then(|s|s.code()).unwrap_or(0) }

fn main(){ let args:Vec<String>=env::args().skip(1).collect(); let code= if args.is_empty(){print_top_help();0}else{match args[0].as_str(){"-h"|"--help"=>{print_top_help();0},"-V"|"--version"=>{println!("zoxide {VERSION}");0},"add"=>add_cmd(&args[1..]),"query"=>query_cmd(&args[1..]),"remove"=>remove_cmd(&args[1..]),"import"=>import_cmd(&args[1..]),"init"=>init_cmd(&args[1..]),"edit"=>edit_cmd(&args[1..]),x=>{eprintln!("error: unrecognized subcommand '{x}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.");2}}}; std::process::exit(code); }
