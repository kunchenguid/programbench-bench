use serde_json::{Map, Value};
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::Path;

const HELP: &str = "  json-tui {OPTIONS} [file]\n\n    A JSON terminal UI\n\n  OPTIONS:\n\n      file                              A JSON file. Omit to read from stdin.\n      -h, --help                        Display this help menu.\n      -v, --version                     Print version.\n      -k, --key, --keybinding           Display key binding.\n      -f, --fullscreen                  Display the JSON in fullscreen, in an\n                                        alternate buffer\n      \"--\" can be used to terminate flag options and force all following\n      arguments to be treated as positional options\n\n    If no file is given, json-tui reads JSON from the standard input\n    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues\n";

const KEY_BINDINGS: &str = "┌───────────┬────────────────┐\r\n│\x1b[36m\x1b[49mkeys       \x1b[39m\x1b[49m│\x1b[36m\x1b[49maction          \x1b[39m\x1b[49m│\r\n├───────────┼────────────────┤\r\n│Navigate   │← ↑ ↓ →         │\r\n│           │h j k l         │\r\n│           │Mouse::WheelUp  │\r\n│           │Mouse::WheelDown│\r\n├───────────┼────────────────┤\r\n│Toggle     │enter           │\r\n│           │Mouse::Left     │\r\n├───────────┼────────────────┤\r\n│Deep       │                │\r\n│ - Expand  │+               │\r\n│ - Collapse│-               │\r\n├───────────┼────────────────┤\r\n│Exit       │Escape          │\r\n│           │q               │\r\n├───────────┼────────────────┤\r\n│Navigate   │                │\r\n│ - first   │page-up         │\r\n│ - last    │page-down       │\r\n│ - top     │gg              │\r\n│ - bottom  │G               │\r\n└───────────┴────────────────┘\0";

#[derive(Default)]
struct Args {
    fullscreen: bool,
    file: Option<String>,
    mode: Mode,
}

#[derive(Default, PartialEq, Eq)]
enum Mode {
    #[default]
    Run,
    Help,
    Version,
    Keys,
}

fn main() {
    let code = match run() {
        Ok(()) => 0,
        Err(code) => code,
    };
    std::process::exit(code);
}

fn run() -> Result<(), i32> {
    let args = parse_args()?;
    match args.mode {
        Mode::Help => {
            print!("{HELP}");
            return Ok(());
        }
        Mode::Version => {
            println!("1.4.1");
            return Ok(());
        }
        Mode::Keys => {
            println!("{KEY_BINDINGS}");
            return Ok(());
        }
        Mode::Run => {}
    }

    let input = match args.file.as_deref() {
        Some(path) => match fs::read_to_string(Path::new(path)) {
            Ok(s) => s,
            Err(_) => {
                eprintln!("Could not open file {path}");
                return Err(1);
            }
        },
        None => {
            eprintln!("Reading from stdin...");
            let mut s = String::new();
            if io::stdin().read_to_string(&mut s).is_err() {
                return Err(1);
            }
            s
        }
    };

    let json: Value = match serde_json::from_str(&input) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("{}", nlohmannish_error(&input, &e));
            return Err(1);
        }
    };

    render_app(&json, args.fullscreen);
    Ok(())
}

fn parse_args() -> Result<Args, i32> {
    let mut out = Args::default();
    let mut positional = Vec::new();
    let mut options = true;

    for arg in env::args().skip(1) {
        if options && arg == "--" {
            options = false;
            continue;
        }
        if options && arg.starts_with('-') {
            match arg.as_str() {
                "-h" | "--help" => out.mode = Mode::Help,
                "-v" | "--version" => out.mode = Mode::Version,
                "-k" | "--key" | "--keybinding" => out.mode = Mode::Keys,
                "-f" | "--fullscreen" => out.fullscreen = true,
                _ => {
                    eprintln!("Invalid arguments");
                    return Err(1);
                }
            }
        } else {
            positional.push(arg);
        }
    }

    if positional.len() > 1 {
        eprintln!("Invalid arguments");
        return Err(1);
    }
    out.file = positional.pop();
    Ok(out)
}

fn nlohmannish_error(input: &str, err: &serde_json::Error) -> String {
    if input.is_empty() {
        return "[json.exception.parse_error.101] parse error at line 1, column 1: attempting to parse an empty input; check that your input string or stream contains the expected JSON".to_string();
    }

    let line = err.line();
    let col = err.column().max(1);
    let got = char_at_line_col(input, line, col);
    let unexpected = match got {
        Some(c) if !c.is_control() => format!("unexpected '{}'", c),
        Some(_) => "unexpected control character".to_string(),
        None => "unexpected end of input".to_string(),
    };

    if matches!(got, Some(']' | '}')) {
        return format!("[json.exception.parse_error.101] parse error at line {line}, column {col}: syntax error while parsing value - {unexpected}; expected '[', '{{', or a literal");
    }

    let last = last_read(input, line, col);
    if !last.is_empty() && last.chars().all(|c| c.is_ascii_alphabetic()) {
        return format!("[json.exception.parse_error.101] parse error at line {line}, column {col}: syntax error while parsing value - invalid literal; last read: '{last}'");
    }

    format!("[json.exception.parse_error.101] parse error at line {line}, column {col}: syntax error while parsing value - {unexpected}")
}

fn char_at_line_col(input: &str, line: usize, col: usize) -> Option<char> {
    let mut l = 1;
    let mut c = 1;
    for ch in input.chars() {
        if l == line && c == col {
            return Some(ch);
        }
        if ch == '\n' {
            l += 1;
            c = 1;
        } else {
            c += 1;
        }
    }
    None
}

fn last_read(input: &str, line: usize, col: usize) -> String {
    let mut l = 1;
    let mut c = 1;
    let mut out = String::new();
    for ch in input.chars() {
        if l > line || (l == line && c > col) {
            break;
        }
        if ch.is_ascii_alphabetic() {
            out.push(ch);
        } else {
            out.clear();
        }
        if ch == '\n' {
            l += 1;
            c = 1;
        } else {
            c += 1;
        }
    }
    out
}

fn render_app(json: &Value, fullscreen: bool) {
    let mut out = io::stdout();
    if fullscreen {
        let _ = write!(out, "\x1b[?1049h");
    }
    let _ = write!(
        out,
        "\0\x1bP$q q\x1b\\\x1b[?7l\x1b[?1000h\x1b[?1003h\x1b[?1015h\x1b[?1006h\0\r\x1b[2K"
    );

    let mut lines = Vec::new();
    render_value(json, 0, true, &mut lines);
    let width = lines.iter().map(|l| visible_width(l)).max().unwrap_or(0);
    for (idx, line) in lines.iter().enumerate() {
        if idx == 0 {
            let _ = write!(out, "\x1b[7m{}\x1b[27m{}", line, spaces(width.saturating_sub(visible_width(line))));
        } else {
            let _ = write!(out, "\r\n{}{}", line, spaces(width.saturating_sub(visible_width(line))));
        }
    }
    let _ = write!(
        out,
        "\x1b[{}A\x1b[{}D\x1b[?25l\0\x1b[{}B\x1b[{}C\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1000l\x1b[?7h\x1b[?25h\x1b[1 q\0\r\n",
        lines.len().saturating_sub(1),
        width,
        lines.len().saturating_sub(1),
        width
    );
    if fullscreen {
        let _ = write!(out, "\x1b[?1049l");
    }
    let _ = out.flush();
}

fn render_value(value: &Value, indent: usize, top: bool, out: &mut Vec<String>) {
    match value {
        Value::Object(map) => render_object(map, indent, top, out),
        Value::Array(items) => render_array(items, indent, top, out),
        _ => out.push(format!("{}{}", " ".repeat(indent), scalar(value))),
    }
}

fn render_object(map: &Map<String, Value>, indent: usize, _top: bool, out: &mut Vec<String>) {
    if map.is_empty() {
        out.push(format!("{}{{}}", " ".repeat(indent)));
        return;
    }
    out.push(format!("{}{{", " ".repeat(indent)));
    let len = map.len();
    for (idx, (key, value)) in map.iter().enumerate() {
        let comma = if idx + 1 == len { "" } else { "," };
        let prefix = format!("{}{}: ", " ".repeat(indent + 2), key_style(key));
        match value {
            Value::Object(obj) if !obj.is_empty() => {
                out.push(format!("{}{}", prefix, bold("{")));
                render_object_body(obj, indent + 2, out);
                out.push(format!("{}}}{comma}", " ".repeat(indent + 2)));
            }
            Value::Array(arr) => {
                out.push(format!("{}{}{}", prefix, bold(if arr.is_empty() { "[...]" } else { "[...]" }), comma));
            }
            _ => out.push(format!("{}{}{}", prefix, scalar(value), comma)),
        }
    }
    out.push(format!("{}}}", " ".repeat(indent)));
}

fn render_object_body(map: &Map<String, Value>, indent: usize, out: &mut Vec<String>) {
    let len = map.len();
    for (idx, (key, value)) in map.iter().enumerate() {
        let comma = if idx + 1 == len { "" } else { "," };
        out.push(format!("{}{}: {}{}", " ".repeat(indent + 2), key_style(key), scalar_or_collapsed(value), comma));
    }
}

fn render_array(items: &[Value], indent: usize, _top: bool, out: &mut Vec<String>) {
    if items.is_empty() {
        out.push(format!("{}[]", " ".repeat(indent)));
        return;
    }
    out.push(format!("{}[", " ".repeat(indent)));
    render_array_body(items, indent, out);
    out.push(format!("{}]", " ".repeat(indent)));
}

fn render_array_body(items: &[Value], indent: usize, out: &mut Vec<String>) {
    for (idx, value) in items.iter().enumerate() {
        let comma = if idx + 1 == items.len() { "" } else { "," };
        out.push(format!("{}{}{}", " ".repeat(indent + 2), scalar_or_collapsed(value), comma));
    }
}

fn scalar_or_collapsed(value: &Value) -> String {
    match value {
        Value::Object(_) => bold("{...}"),
        Value::Array(_) => bold("[...]"),
        _ => scalar(value),
    }
}

fn scalar(value: &Value) -> String {
    match value {
        Value::Null => "\x1b[91m\x1b[49mnull\x1b[39m\x1b[49m".to_string(),
        Value::Bool(b) => format!("\x1b[93m\x1b[49m{b}\x1b[39m\x1b[49m"),
        Value::Number(n) => format!("\x1b[96m\x1b[49m{n}\x1b[39m\x1b[49m"),
        Value::String(s) => format!("\x1b[32m\x1b[49m{}\x1b[39m\x1b[49m", serde_json::to_string(s).unwrap()),
        Value::Object(_) => bold("{...}"),
        Value::Array(_) => bold("[...]"),
    }
}

fn key_style(key: &str) -> String {
    format!("\x1b[94m\x1b[49m{}\x1b[39m\x1b[49m", serde_json::to_string(key).unwrap())
}

fn bold(s: &str) -> String {
    format!("\x1b[1m{s}\x1b[22m")
}

fn visible_width(s: &str) -> usize {
    let mut chars = s.chars().peekable();
    let mut width = 0;
    while let Some(ch) = chars.next() {
        if ch == '\x1b' {
            for next in chars.by_ref() {
                if next.is_ascii_alphabetic() {
                    break;
                }
            }
        } else {
            width += 1;
        }
    }
    width
}

fn spaces(n: usize) -> String {
    " ".repeat(n)
}
