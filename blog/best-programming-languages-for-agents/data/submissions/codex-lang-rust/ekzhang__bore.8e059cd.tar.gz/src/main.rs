use anyhow::{anyhow, bail, Context, Result};
use clap::{value_parser, Arg, Command};
use std::collections::HashMap;
use std::io::{self, BufRead, BufReader, Write};
use std::net::{IpAddr, Shutdown, TcpListener, TcpStream, ToSocketAddrs};
use std::sync::{Arc, Condvar, Mutex};
use std::thread;
use std::time::{Duration, Instant};

const CONTROL_PORT: u16 = 7835;

#[derive(Debug, Clone)]
struct LocalArgs {
    local_port: u16,
    local_host: String,
    to: String,
    port: u16,
    secret: Option<String>,
}

#[derive(Debug, Clone)]
struct ServerArgs {
    min_port: u16,
    max_port: u16,
    secret: Option<String>,
    bind_addr: IpAddr,
    bind_tunnels: Option<IpAddr>,
}

struct State {
    pending: Mutex<HashMap<u64, TcpStream>>,
    ready: Condvar,
}

fn main() -> Result<()> {
    let matches = cli().get_matches();
    match matches.subcommand() {
        Some(("local", m)) => run_local(LocalArgs {
            local_port: *m.get_one::<u16>("LOCAL_PORT").unwrap(),
            local_host: m.get_one::<String>("local-host").unwrap().clone(),
            to: m.get_one::<String>("to").unwrap().clone(),
            port: *m.get_one::<u16>("port").unwrap(),
            secret: m.get_one::<String>("secret").cloned(),
        }),
        Some(("server", m)) => run_server(ServerArgs {
            min_port: *m.get_one::<u16>("min-port").unwrap(),
            max_port: *m.get_one::<u16>("max-port").unwrap(),
            secret: m.get_one::<String>("secret").cloned(),
            bind_addr: *m.get_one::<IpAddr>("bind-addr").unwrap(),
            bind_tunnels: m.get_one::<IpAddr>("bind-tunnels").copied(),
        }),
        _ => unreachable!(),
    }
}

fn cli() -> Command {
    Command::new("executable")
        .version("0.6.0")
        .about("A modern, simple TCP tunnel in Rust that exposes local ports to a remote server, bypassing standard NAT connection firewalls.")
        .subcommand_required(true)
        .subcommand(
            Command::new("local")
                .about("Starts a local proxy to the remote server")
                .arg(Arg::new("LOCAL_PORT")
                    .help("The local port to expose")
                    .env("BORE_LOCAL_PORT")
                    .value_parser(value_parser!(u16))
                    .required(true))
                .arg(Arg::new("local-host")
                    .short('l').long("local-host")
                    .value_name("HOST")
                    .help("The local host to expose")
                    .default_value("localhost"))
                .arg(Arg::new("to")
                    .short('t').long("to")
                    .value_name("TO")
                    .help("Address of the remote server to expose local ports to")
                    .env("BORE_SERVER")
                    .required(true))
                .arg(Arg::new("port")
                    .short('p').long("port")
                    .value_name("PORT")
                    .help("Optional port on the remote server to select")
                    .default_value("0")
                    .value_parser(value_parser!(u16)))
                .arg(Arg::new("secret")
                    .short('s').long("secret")
                    .value_name("SECRET")
                    .help("Optional secret for authentication")
                    .env("BORE_SECRET")
                    .hide_env_values(true)),
        )
        .subcommand(
            Command::new("server")
                .about("Runs the remote proxy server")
                .arg(Arg::new("min-port")
                    .long("min-port")
                    .value_name("MIN_PORT")
                    .help("Minimum accepted TCP port number")
                    .env("BORE_MIN_PORT")
                    .default_value("1024")
                    .value_parser(value_parser!(u16)))
                .arg(Arg::new("max-port")
                    .long("max-port")
                    .value_name("MAX_PORT")
                    .help("Maximum accepted TCP port number")
                    .env("BORE_MAX_PORT")
                    .default_value("65535")
                    .value_parser(value_parser!(u16)))
                .arg(Arg::new("secret")
                    .short('s').long("secret")
                    .value_name("SECRET")
                    .help("Optional secret for authentication")
                    .env("BORE_SECRET")
                    .hide_env_values(true))
                .arg(Arg::new("bind-addr")
                    .long("bind-addr")
                    .value_name("BIND_ADDR")
                    .help("IP address to bind to, clients must reach this")
                    .default_value("0.0.0.0")
                    .value_parser(value_parser!(IpAddr)))
                .arg(Arg::new("bind-tunnels")
                    .long("bind-tunnels")
                    .value_name("BIND_TUNNELS")
                    .help("IP address where tunnels will listen on, defaults to --bind-addr")
                    .value_parser(value_parser!(IpAddr))),
        )
}

fn log_info(msg: &str) {
    println!("INFO {msg}");
}

fn run_server(args: ServerArgs) -> Result<()> {
    if args.min_port > args.max_port {
        bail!("minimum port cannot be greater than maximum port");
    }
    let listener = TcpListener::bind((args.bind_addr, CONTROL_PORT))
        .with_context(|| format!("failed to bind control port {CONTROL_PORT}"))?;
    log_info(&format!("server listening addr={}", args.bind_addr));

    let state = Arc::new(State { pending: Mutex::new(HashMap::new()), ready: Condvar::new() });
    let next_id = Arc::new(Mutex::new(1u64));
    for stream in listener.incoming() {
        match stream {
            Ok(stream) => {
                let peer = stream.peer_addr().ok();
                log_info(&format!("incoming connection{}", peer.map(|p| format!(" addr={p}")).unwrap_or_default()));
                let state = Arc::clone(&state);
                let next_id = Arc::clone(&next_id);
                let args = args.clone();
                thread::spawn(move || {
                    if let Err(e) = handle_control(stream, args, state, next_id) {
                        eprintln!("Error: {e:#}");
                    }
                });
            }
            Err(e) => eprintln!("Error: {e}"),
        }
    }
    Ok(())
}

fn handle_control(mut stream: TcpStream, args: ServerArgs, state: Arc<State>, next_id: Arc<Mutex<u64>>) -> Result<()> {
    let mut line = String::new();
    {
        let mut reader = BufReader::new(stream.try_clone()?);
        reader.read_line(&mut line)?;
    }
    let line = line.trim_end_matches(['\r', '\n']);
    let mut parts = line.splitn(3, ' ');
    match parts.next() {
        Some("HELLO") => {
            let requested: u16 = parts.next().ok_or_else(|| anyhow!("invalid hello"))?.parse()?;
            let secret = parts.next().unwrap_or("");
            if let Some(expected) = &args.secret {
                if secret != expected {
                    writeln!(stream, "ERR authentication failed")?;
                    bail!("authentication failed");
                }
            }
            let bind_ip = args.bind_tunnels.unwrap_or(args.bind_addr);
            let tunnel = bind_tunnel(bind_ip, requested, args.min_port, args.max_port)?;
            let remote_port = tunnel.local_addr()?.port();
            writeln!(stream, "OK {remote_port}")?;
            stream.flush()?;
            log_info(&format!("new client host={} port={remote_port}", bind_ip));
            serve_tunnel(tunnel, stream, state, next_id)
        }
        Some("ACCEPT") => {
            let id: u64 = parts.next().ok_or_else(|| anyhow!("invalid accept"))?.parse()?;
            let mut pending = state.pending.lock().unwrap();
            pending.insert(id, stream);
            state.ready.notify_all();
            Ok(())
        }
        _ => bail!("invalid protocol message"),
    }
}

fn bind_tunnel(ip: IpAddr, requested: u16, min: u16, max: u16) -> Result<TcpListener> {
    if requested != 0 {
        if requested < min || requested > max {
            bail!("requested port {requested} outside allowed range {min}-{max}");
        }
        return TcpListener::bind((ip, requested)).with_context(|| format!("failed to bind tunnel port {requested}"));
    }
    if min <= 1024 && max == 65535 {
        return TcpListener::bind((ip, 0)).context("failed to bind tunnel port");
    }
    for port in min..=max {
        if let Ok(listener) = TcpListener::bind((ip, port)) {
            return Ok(listener);
        }
    }
    bail!("no available ports in range {min}-{max}")
}

fn serve_tunnel(listener: TcpListener, mut control: TcpStream, state: Arc<State>, next_id: Arc<Mutex<u64>>) -> Result<()> {
    for incoming in listener.incoming() {
        let public = incoming?;
        let id = {
            let mut guard = next_id.lock().unwrap();
            let id = *guard;
            *guard += 1;
            id
        };
        writeln!(control, "CONN {id}")?;
        control.flush()?;
        let state = Arc::clone(&state);
        thread::spawn(move || {
            match wait_for_accept(&state, id, Duration::from_secs(15)) {
                Some(private) => bridge(public, private),
                None => eprintln!("Error: timed out waiting for tunnel connection"),
            }
        });
    }
    Ok(())
}

fn wait_for_accept(state: &State, id: u64, timeout: Duration) -> Option<TcpStream> {
    let deadline = Instant::now() + timeout;
    let mut pending = state.pending.lock().unwrap();
    loop {
        if let Some(stream) = pending.remove(&id) {
            return Some(stream);
        }
        let now = Instant::now();
        if now >= deadline {
            return None;
        }
        let (guard, _) = state.ready.wait_timeout(pending, deadline - now).unwrap();
        pending = guard;
    }
}

fn run_local(args: LocalArgs) -> Result<()> {
    let server_addr = resolve_control_addr(&args.to)?;
    let mut control = TcpStream::connect(server_addr).with_context(|| format!("failed to connect to server {server_addr}"))?;
    writeln!(control, "HELLO {} {}", args.port, args.secret.as_deref().unwrap_or(""))?;
    control.flush()?;

    let mut reader = BufReader::new(control.try_clone()?);
    let mut first = String::new();
    reader.read_line(&mut first)?;
    let first = first.trim_end_matches(['\r', '\n']);
    if let Some(rest) = first.strip_prefix("OK ") {
        let remote_port: u16 = rest.parse()?;
        log_info(&format!("connected to server remote_port={remote_port}"));
        log_info(&format!("listening at {}:{remote_port}", args.to));
    } else if let Some(err) = first.strip_prefix("ERR ") {
        bail!(err.to_string());
    } else {
        bail!("invalid server response");
    }

    loop {
        let mut line = String::new();
        let n = reader.read_line(&mut line)?;
        if n == 0 {
            break;
        }
        let line = line.trim_end_matches(['\r', '\n']);
        if let Some(id) = line.strip_prefix("CONN ") {
            let id: u64 = id.parse()?;
            let args = args.clone();
            let server_addr = server_addr.to_string();
            thread::spawn(move || {
                if let Err(e) = handle_local_conn(&args, &server_addr, id) {
                    eprintln!("Error: {e:#}");
                }
            });
        }
    }
    Ok(())
}

fn resolve_control_addr(host: &str) -> Result<std::net::SocketAddr> {
    let spec = if host.contains(':') { host.to_string() } else { format!("{host}:{CONTROL_PORT}") };
    spec.to_socket_addrs()?.next().ok_or_else(|| anyhow!("could not resolve server address"))
}

fn handle_local_conn(args: &LocalArgs, server_addr: &str, id: u64) -> Result<()> {
    let mut remote = TcpStream::connect(server_addr)?;
    writeln!(remote, "ACCEPT {id}")?;
    remote.flush()?;
    let local_spec = format!("{}:{}", args.local_host, args.local_port);
    let local = TcpStream::connect(&local_spec).with_context(|| format!("failed to connect to local service {local_spec}"))?;
    bridge(remote, local);
    Ok(())
}

fn bridge(a: TcpStream, b: TcpStream) {
    let mut ar = match a.try_clone() { Ok(s) => s, Err(_) => return };
    let mut bw = match b.try_clone() { Ok(s) => s, Err(_) => return };
    let mut br = b;
    let mut aw = a;
    let t = thread::spawn(move || {
        let _ = io::copy(&mut ar, &mut bw);
        let _ = bw.shutdown(Shutdown::Write);
    });
    let _ = io::copy(&mut br, &mut aw);
    let _ = aw.shutdown(Shutdown::Write);
    let _ = t.join();
}
