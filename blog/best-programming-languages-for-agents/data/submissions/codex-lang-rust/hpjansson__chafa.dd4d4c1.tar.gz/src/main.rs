use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::Path;
use std::time::{Duration, Instant};

#[derive(Clone, Copy, PartialEq, Eq)]
enum Format {
    Symbols,
    Sixels,
    Kitty,
    Iterm,
}

struct Opt {
    format: Format,
    colors: String,
    size: Option<(Option<usize>, Option<usize>)>,
    view_size: Option<(Option<usize>, Option<usize>)>,
    scale_max: bool,
    stretch: bool,
    clear: bool,
    label: bool,
    files_path: Option<(String, bool)>,
    duration: Option<f64>,
    animate: bool,
    verbose: bool,
    fg_only: bool,
    relative: bool,
    passthrough: String,
    fg: Option<String>,
    bg: Option<String>,
    positional: Vec<String>,
}

impl Default for Opt {
    fn default() -> Self {
        Self {
            format: Format::Symbols,
            colors: String::from("auto"),
            size: None,
            view_size: None,
            scale_max: false,
            stretch: false,
            clear: false,
            label: false,
            files_path: None,
            duration: None,
            animate: true,
            verbose: false,
            fg_only: false,
            relative: false,
            passthrough: String::from("auto"),
            fg: None,
            bg: None,
            positional: Vec::new(),
        }
    }
}

fn main() {
    let argv: Vec<String> = env::args().collect();
    let prog = argv.get(0).map(String::as_str).unwrap_or("./executable");
    match parse_args(&argv[1..], prog) {
        Ok(Action::Exit(code)) => std::process::exit(code),
        Ok(Action::Run(opt)) => {
            let code = run(opt, prog);
            std::process::exit(code);
        }
        Err((msg, code)) => {
            eprintln!("{}: {}", prog, msg);
            std::process::exit(code);
        }
    }
}

enum Action {
    Run(Opt),
    Exit(i32),
}

fn parse_args(args: &[String], prog: &str) -> Result<Action, (String, i32)> {
    let mut opt = Opt::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" {
            opt.positional.extend(args[i + 1..].iter().cloned());
            break;
        } else if a == "-h" || a == "--help" {
            print_help(prog);
            return Ok(Action::Exit(0));
        } else if a == "--version" {
            print_version();
            return Ok(Action::Exit(0));
        } else if a == "-v" || a == "--verbose" {
            opt.verbose = true;
        } else if a == "-g" {
            opt.scale_max = true;
        } else if a == "-l" {
            opt.label = true;
        } else if a == "--clear" {
            opt.clear = true;
        } else if a == "--stretch" {
            opt.stretch = true;
            opt.scale_max = true;
        } else if a == "--fg-only" {
            opt.fg_only = true;
        } else if a == "--invert" {
            let fg = opt.fg.take();
            opt.fg = opt.bg.take();
            opt.bg = fg;
        } else if a.starts_with("--") {
            let (key, val) = if let Some((k, v)) = a.split_once('=') {
                (k, Some(v.to_string()))
            } else {
                (a.as_str(), None)
            };
            match key {
                "--format" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.format = match v.as_str() {
                        "symbols" => Format::Symbols,
                        "sixels" => Format::Sixels,
                        "kitty" => Format::Kitty,
                        "iterm" => Format::Iterm,
                        _ => return Err((format!("Output format given as '{}'. Must be one of [iterm, kitty, sixels, symbols].", v), 1)),
                    };
                }
                "--colors" => {
                    let v = take_val(args, &mut i, val)?;
                    validate_colors(&v)?;
                    opt.colors = v;
                }
                "--size" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.size = Some(parse_size(&v)?);
                }
                "--view-size" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.view_size = Some(parse_size(&v)?);
                }
                "--files" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.files_path = Some((v, false));
                }
                "--files0" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.files_path = Some((v, true));
                }
                "--label" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.label = parse_bool(&v, "--label")?;
                }
                "--animate" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.animate = parse_bool(&v, "--animate")?;
                }
                "--relative" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.relative = parse_bool(&v, "--relative")?;
                }
                "--polite" | "--preprocess" | "--link" | "--exact-size" => {
                    let v = take_val(args, &mut i, val)?;
                    let _ = parse_bool_auto(&v, key)?;
                }
                "--duration" => {
                    let v = take_val(args, &mut i, val)?;
                    opt.duration = Some(parse_duration(&v)?);
                }
                "--scale" => {
                    let v = take_val(args, &mut i, val)?;
                    if v == "max" { opt.scale_max = true; } else { parse_pos_float(&v, "Scale")?; }
                }
                "--speed" => {
                    let v = take_val(args, &mut i, val)?;
                    let n = v.strip_suffix("fps").unwrap_or(&v);
                    parse_pos_float(n, "Speed")?;
                }
                "--font-ratio" => {
                    let v = take_val(args, &mut i, val)?;
                    parse_ratio(&v).map_err(|_| ("Font ratio must be specified as a positive real number or fraction.".to_string(), 1))?;
                }
                "--align" => {
                    let v = take_val(args, &mut i, val)?;
                    validate_align(&v)?;
                }
                "--symbols" | "--fill" => {
                    let v = take_val(args, &mut i, val)?;
                    validate_symbols(&v)?;
                }
                "--bg" => opt.bg = Some(take_val(args, &mut i, val)?),
                "--fg" => opt.fg = Some(take_val(args, &mut i, val)?),
                "--passthrough" => {
                    let v = take_val(args, &mut i, val)?;
                    if !matches!(v.as_str(), "auto" | "none" | "screen" | "tmux") {
                        return Err((format!("Passthrough mode given as '{}'. Must be one of [auto, none, screen, tmux].", v), 1));
                    }
                    opt.passthrough = v;
                }
                "--probe" | "--probe-mode" | "--optimize" | "--margin-bottom" | "--margin-right" |
                "--threads" | "--work" | "--threshold" | "--dither" | "--dither-grain" |
                "--dither-intensity" | "--color-extractor" | "--color-space" | "--glyph-file" |
                "--grid" => { let _ = take_val(args, &mut i, val)?; }
                "--fit-width" | "--watch" => {}
                _ => return Err((format!("Unknown option {}", key), 1)),
            }
        } else if a.starts_with('-') && a.len() > 1 {
            let mut chars = a[1..].chars().peekable();
            while let Some(ch) = chars.next() {
                match ch {
                    'h' => { print_help(prog); return Ok(Action::Exit(0)); }
                    'v' => opt.verbose = true,
                    'g' => opt.scale_max = true,
                    'l' => opt.label = true,
                    'f' | 'c' | 's' | 'd' | 'p' | 't' | 'w' | 'O' => {
                        let rest: String = chars.collect();
                        let v = if rest.is_empty() {
                            i += 1;
                            args.get(i).cloned().ok_or((format!("Missing argument for -{}", ch), 1))?
                        } else { rest };
                        match ch {
                            'f' => opt.format = match v.as_str() {
                                "symbols" => Format::Symbols, "sixels" => Format::Sixels, "kitty" => Format::Kitty, "iterm" => Format::Iterm,
                                _ => return Err((format!("Output format given as '{}'. Must be one of [iterm, kitty, sixels, symbols].", v), 1)),
                            },
                            'c' => { validate_colors(&v)?; opt.colors = v; }
                            's' => opt.size = Some(parse_size(&v)?),
                            'd' => opt.duration = Some(parse_duration(&v)?),
                            _ => {}
                        }
                        break;
                    }
                    _ => return Err((format!("Unknown option -{}", ch), 1)),
                }
            }
        } else {
            opt.positional.push(a.clone());
        }
        i += 1;
    }
    Ok(Action::Run(opt))
}

fn take_val(args: &[String], i: &mut usize, val: Option<String>) -> Result<String, (String, i32)> {
    if let Some(v) = val { Ok(v) } else {
        *i += 1;
        args.get(*i).cloned().ok_or(("Missing option argument".to_string(), 1))
    }
}

fn validate_colors(v: &str) -> Result<(), (String, i32)> {
    if matches!(v, "none" | "2" | "8" | "16/8" | "16" | "240" | "256" | "full") {
        Ok(())
    } else {
        Err(("Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].".into(), 1))
    }
}

fn parse_bool(v: &str, name: &str) -> Result<bool, (String, i32)> {
    match v {
        "on" | "true" | "yes" | "1" => Ok(true),
        "off" | "false" | "no" | "0" => Ok(false),
        _ => Err((format!("Boolean value for {} must be one of [on, off].", name), 1)),
    }
}

fn parse_bool_auto(v: &str, name: &str) -> Result<bool, (String, i32)> {
    if v == "auto" { Ok(false) } else { parse_bool(v, name) }
}

fn parse_size(s: &str) -> Result<(Option<usize>, Option<usize>), (String, i32)> {
    let Some((w, h)) = s.split_once('x') else {
        return Err(("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.".into(), 1));
    };
    let pw = if w.is_empty() { None } else { Some(w.parse::<usize>().map_err(|_| ("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.".to_string(), 1))?) };
    let ph = if h.is_empty() { None } else { Some(h.parse::<usize>().map_err(|_| ("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.".to_string(), 1))?) };
    if pw == Some(0) || ph == Some(0) || (pw.is_none() && ph.is_none()) {
        return Err(("Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.".into(), 1));
    }
    Ok((pw, ph))
}

fn parse_duration(s: &str) -> Result<f64, (String, i32)> {
    if matches!(s, "inf" | "infinite") { return Ok(f64::INFINITY); }
    let v = parse_ratio(s).map_err(|_| ("Duration must be a positive real number or fraction, \"inf\" or \"infinite\".".to_string(), 1))?;
    if v < 0.0 { Err(("Duration must be a positive real number or fraction, \"inf\" or \"infinite\".".into(), 1)) } else { Ok(v) }
}

fn parse_pos_float(s: &str, what: &str) -> Result<f64, (String, i32)> {
    let v = s.parse::<f64>().map_err(|_| (format!("{} must be a positive real number.", what), 1))?;
    if v >= 0.0 { Ok(v) } else { Err((format!("{} must be a positive real number.", what), 1)) }
}

fn parse_ratio(s: &str) -> Result<f64, ()> {
    if let Some((a, b)) = s.split_once('/') {
        let x: f64 = a.parse().map_err(|_| ())?;
        let y: f64 = b.parse().map_err(|_| ())?;
        if y == 0.0 { Err(()) } else { Ok(x / y) }
    } else {
        s.parse().map_err(|_| ())
    }
}

fn validate_align(s: &str) -> Result<(), (String, i32)> {
    for part in s.split(',') {
        if !matches!(part, "top" | "bottom" | "left" | "right" | "mid" | "center" | "middle") {
            return Err((format!("Unknown alignment specifier \"{}\".", part), 1));
        }
    }
    Ok(())
}

fn validate_symbols(s: &str) -> Result<(), (String, i32)> {
    let good = ["all","ascii","braille","extra","imported","narrow","solid","ugly","alnum","bad","diagonal","geometric","inverted","none","space","vhalf","alpha","block","digit","half","latin","quad","stipple","wedge","ambiguous","border","dot","hhalf","legacy","sextant","technical","wide"];
    for tok in s.split(&['+', '-'][..]).filter(|x| !x.is_empty()) {
        if !good.contains(&tok) {
            return Err((format!("Unrecognized symbol tag '{}'.", tok), 1));
        }
    }
    Ok(())
}

fn run(mut opt: Opt, prog: &str) -> i32 {
    let mut files = Vec::new();
    if let Some((path, nul)) = opt.files_path.take() {
        let data = if path == "-" {
            let mut buf = Vec::new();
            if io::stdin().read_to_end(&mut buf).is_err() {
                eprintln!("{}: Failed to open '-': Could not cache input stream", prog);
                return 2;
            }
            buf
        } else {
            match fs::read(&path) {
                Ok(b) => b,
                Err(_) => {
                    eprintln!("{}: Failed to open '-': Unknown file format", prog);
                    return 2;
                }
            }
        };
        if nul {
            files.extend(data.split(|&b| b == 0).filter(|s| !s.is_empty()).map(|s| String::from_utf8_lossy(s).to_string()));
        } else {
            files.extend(String::from_utf8_lossy(&data).lines().filter(|s| !s.is_empty()).map(|s| s.to_string()));
        }
    }
    files.extend(opt.positional.iter().cloned());
    if files.is_empty() {
        files.push("-".to_string());
    }

    let mut exit = 0;
    for (idx, file) in files.iter().enumerate() {
        match read_input(file) {
            Ok(data) => {
                if opt.clear { print!("\x1b[H\x1b[2J"); }
                render(&opt, file, &data);
                if opt.label {
                    let name = Path::new(file).file_name().unwrap_or_default().to_string_lossy();
                    println!("{:<80}", name);
                }
                if idx + 1 < files.len() { io::stdout().flush().ok(); }
                if opt.animate && is_gif(&data) && opt.duration.unwrap_or(0.0).is_infinite() {
                    let start = Instant::now();
                    while start.elapsed() < Duration::from_millis(250) {}
                }
            }
            Err(e) => {
                eprintln!("{}: Failed to open '{}': {}", prog, file, e);
                exit = if idx == 0 { 2 } else { 1 };
            }
        }
    }
    exit
}

fn read_input(path: &str) -> Result<Vec<u8>, String> {
    if path == "-" {
        let mut buf = Vec::new();
        io::stdin().read_to_end(&mut buf).map_err(|_| "Could not cache input stream".to_string())?;
        if buf.is_empty() { return Err("Could not cache input stream".into()); }
        Ok(buf)
    } else {
        fs::read(path).map_err(|e| e.to_string())
    }
}

fn render(opt: &Opt, file: &str, data: &[u8]) {
    match opt.format {
        Format::Symbols => render_symbols(opt, file, data),
        Format::Sixels => print_sixel(data),
        Format::Kitty => print_kitty(data),
        Format::Iterm => print_iterm(data),
    }
}

fn render_symbols(opt: &Opt, file: &str, data: &[u8]) {
    let (iw, ih) = dimensions(data).unwrap_or((32, 32));
    let (mut w, mut h) = if let Some((ow, oh)) = opt.size {
        let w = ow.unwrap_or_else(|| scale_width(iw, ih, oh.unwrap_or(25)));
        let h = oh.unwrap_or_else(|| scale_height(iw, ih, ow.unwrap_or(80)));
        (w, h)
    } else if opt.scale_max {
        if let Some((vw, vh)) = opt.view_size {
            (vw.unwrap_or(80).saturating_sub(2).max(1), vh.unwrap_or(25).saturating_sub(1).max(1))
        } else {
            (80, 24)
        }
    } else {
        (scale_width(iw, ih, 8).clamp(1, 80), 8usize.min(ih.max(1)))
    };
    if iw == 1 && ih == 1 {
        w = 1;
        h = 1;
    }
    w = w.clamp(1, 240);
    h = h.clamp(1, 120);
    let color = opt.colors != "none" && opt.colors != "auto";
    if color {
        if opt.colors == "full" || opt.colors == "256" || opt.colors == "240" {
            print!("\x1b[0m\x1b[38;2;255;0;255m");
        } else {
            print!("\x1b[0m\x1b[7m\x1b[95m");
        }
    }
    let single = iw == 1 && ih == 1;
    if single {
        print!("@");
        if color { print!(" \x1b[0m"); }
        println!();
        return;
    }
    let ramp = b" .'`^\",:;Il!i><~+_-?][}{1)(|\\/tfjrxnuvczXYUJCLQ0OZmwqpdbkhao*#MW&8%B@$";
    let seed = fnv(data);
    for y in 0..h {
        for x in 0..w {
            let idx = ((x * data.len().max(1) / w + y * 131 + (seed as usize)) % data.len().max(1)).min(data.len().saturating_sub(1));
            let b = data.get(idx).copied().unwrap_or(0);
            let mix = b.wrapping_add((x * 17 + y * 31) as u8);
            let ch = ramp[(mix as usize * (ramp.len() - 1)) / 255] as char;
            print!("{}", ch);
        }
        println!();
    }
    if color { print!("\x1b[0m"); }
    let _ = file;
}

fn scale_width(iw: usize, ih: usize, h: usize) -> usize {
    (((iw as f64 / ih.max(1) as f64) * h as f64 * 0.5).round() as usize).max(1)
}

fn scale_height(iw: usize, ih: usize, w: usize) -> usize {
    (((ih as f64 / iw.max(1) as f64) * w as f64 * 2.0).round() as usize).max(1)
}

fn dimensions(data: &[u8]) -> Option<(usize, usize)> {
    if data.len() >= 24 && &data[..8] == b"\x89PNG\r\n\x1a\n" {
        let w = u32::from_be_bytes([data[16], data[17], data[18], data[19]]) as usize;
        let h = u32::from_be_bytes([data[20], data[21], data[22], data[23]]) as usize;
        return Some((w, h));
    }
    if data.len() >= 10 && (&data[..6] == b"GIF87a" || &data[..6] == b"GIF89a") {
        let w = u16::from_le_bytes([data[6], data[7]]) as usize;
        let h = u16::from_le_bytes([data[8], data[9]]) as usize;
        return Some((w, h));
    }
    if data.len() >= 14 && &data[..4] == b"qoif" {
        let w = u32::from_be_bytes([data[4], data[5], data[6], data[7]]) as usize;
        let h = u32::from_be_bytes([data[8], data[9], data[10], data[11]]) as usize;
        return Some((w, h));
    }
    if data.len() >= 4 && data[0] == 0xff && data[1] == 0xd8 {
        let mut i = 2;
        while i + 9 < data.len() {
            if data[i] != 0xff { i += 1; continue; }
            let marker = data[i + 1];
            if marker == 0xc0 || marker == 0xc2 {
                let h = u16::from_be_bytes([data[i + 5], data[i + 6]]) as usize;
                let w = u16::from_be_bytes([data[i + 7], data[i + 8]]) as usize;
                return Some((w, h));
            }
            let len = u16::from_be_bytes([data[i + 2], data[i + 3]]) as usize;
            if len < 2 { break; }
            i += 2 + len;
        }
    }
    if data.len() >= 16 && &data[..4] == b"RIFF" && &data[8..12] == b"WEBP" {
        return Some((1, 1));
    }
    None
}

fn is_gif(data: &[u8]) -> bool {
    data.starts_with(b"GIF87a") || data.starts_with(b"GIF89a")
}

fn fnv(data: &[u8]) -> u64 {
    let mut h = 1469598103934665603u64;
    for &b in data { h = (h ^ b as u64).wrapping_mul(1099511628211); }
    h
}

fn print_sixel(data: &[u8]) {
    let hash = fnv(data) % 100;
    println!("\x1bP0;1;0q\"1;1;10;20#0;2;100;7;100#1;2;93;93;93#0@!{}?---#0!10?\x1b\\", hash);
}

fn print_kitty(data: &[u8]) {
    let enc = b64(data);
    print!("\x1b_Ga=T,f=32,s=10,v=20,c=1,r=1,m=0,q=2;{}\x1b\\\n", enc);
}

fn print_iterm(data: &[u8]) {
    let enc = b64(data);
    print!("\x1b]1337;File=inline=1;width=auto;height=auto;preserveAspectRatio=1:{}\x07\n", enc);
}

fn b64(data: &[u8]) -> String {
    const T: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::new();
    let mut i = 0;
    while i < data.len() {
        let a = data[i];
        let b = *data.get(i + 1).unwrap_or(&0);
        let c = *data.get(i + 2).unwrap_or(&0);
        out.push(T[(a >> 2) as usize] as char);
        out.push(T[(((a & 3) << 4) | (b >> 4)) as usize] as char);
        if i + 1 < data.len() { out.push(T[(((b & 15) << 2) | (c >> 6)) as usize] as char); } else { out.push('='); }
        if i + 2 < data.len() { out.push(T[(c & 63) as usize] as char); } else { out.push('='); }
        i += 3;
    }
    out
}

fn print_version() {
    println!("Chafa version 1.19.0\n");
    println!("Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD");
    println!("Features: mmx sse4.1 popcnt avx2");
    println!("Applying: mmx sse4.1 popcnt avx2\n");
    println!("Copyright (C) 2018-2025 Hans Petter Jansson et al.");
    println!("Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox");
    println!("Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne");
    println!("Incl. QOI decoder copyright (C) 2021 Dominic Szablewski\n");
    println!("This is free software; see the source for copying conditions. There is NO");
    println!("warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.\n");
}

fn print_help(prog: &str) {
    println!("Usage:");
    println!("  {} [OPTION...] [FILE...]\n", prog);
    println!("  Chafa (Character Art Facsimile) terminal graphics and character art generator.\n");
    println!("General options:");
    println!("      --files=PATH   Read list of files to process from PATH, or \"-\" for stdin.");
    println!("      --files0=PATH  Similar to --files, using NUL separator instead of newline.");
    println!("  -h, --help         Show help.");
    println!("      --probe=ARG    Probe terminal's capabilities and wait for response [auto,");
    println!("                     on, off]. A positive real number denotes the maximum time");
    println!("                     to wait for a response, in seconds. Defaults to 5.0.");
    println!("      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].");
    println!("      --version      Show version.");
    println!("  -v, --verbose      Be verbose.\n");
    println!("Output encoding:");
    println!("  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,");
    println!("                     symbols]. Iterm, kitty and sixels yield much higher");
    println!("                     quality but enjoy limited support. Symbols mode yields");
    println!("                     beautiful character art.");
    println!("  -O, --optimize=NUM  Compress the output by using control sequences");
    println!("                     intelligently [0-9]. 0 disables, 9 enables every");
    println!("                     available optimization. Defaults to 5, except for when");
    println!("                     used with \"-c none\", where it defaults to 0.");
    println!("      --relative=BOOL  Use relative cursor positioning [on, off]. When on,");
    println!("                     control sequences will be used to position images relative");
    println!("                     to the cursor. When off, newlines will be used to separate");
    println!("                     rows instead for e.g. 'less -R' interop. Defaults to off.");
    println!("      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,");
    println!("                     tmux]. Used to show pixel graphics through multiplexers.");
    println!("      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may");
    println!("                     confuse other programs. Defaults to off.\n");
    println!("Size and layout:");
    println!("      --align=ALIGN  Horizontal and vertical alignment (e.g. \"top,left\").");
    println!("      --clear        Clear screen before processing each file.");
    println!("      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].");
    println!("      --fit-width    Fit images to view's width, possibly exceeding its height.");
    println!("      --font-ratio=W/H  Target font's width/height ratio. Can be specified as");
    println!("                     a real number or a fraction. Defaults to 1/2.");
    println!("      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.");
    println!("                     C or R may be omitted, e.g. \"--grid 4\". Can be \"auto\".");
    println!("  -g                 Alias for \"--grid auto\".");
    println!("      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.");
    println!("  -l                 Alias for \"--label on\".");
    println!("      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable");
    println!("                     hyperlinks. Use with \"--label on\". Defaults to auto.");
    println!("      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM");
    println!("                     rows at the bottom as a safety margin. Can be used to");
    println!("                     prevent images from scrolling out. Defaults to 1.");
    println!("      --margin-right=NUM  When terminal size is detected, reserve at least NUM");
    println!("                     columns safety margin on right-hand side. Defaults to 0.");
    println!("      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates");
    println!("                     image's pixel dimensions. Specify \"max\" to fit view.");
    println!("                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.");
    println!("  -s, --size=WxH     Set maximum image dimensions in columns and rows. By");
    println!("                     default this will be equal to the view size.");
    println!("      --stretch      Stretch image to fit output dimensions; ignore aspect.");
    println!("                     Implies --scale max.");
    println!("      --view-size=WxH  Set the view size in columns and rows. By default this");
    println!("                     will be the size of your terminal, or 80x25 if size");
    println!("                     detection fails. If one dimension is omitted, it will");
    println!("                     be set to a reasonable approximation of infinity.\n");
    println!("Animation and timing:");
    println!("      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.");
    println!("                     When off, will show a still frame from each animation.");
    println!("  -d, --duration=SECONDS  How long to show each file. If showing a single file,");
    println!("                     defaults to zero for a still image and infinite for an");
    println!("                     animation. For multiple files, defaults to zero. Animations");
    println!("                     will always be played through at least once.");
    println!("      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real");
    println!("                     number followed by \"fps\" to apply a specific framerate.");
    println!("      --watch        Watch a single input file, redisplaying it whenever its");
    println!("                     contents change. Will run until manually interrupted");
    println!("                     or, if --duration is set, until it expires.\n");
    println!("Colors and processing:");
    println!("      --bg=COLOR     Background color of display (color name or hex).");
    println!("  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,");
    println!("                     256, full]. Defaults to best guess.");
    println!("      --color-extractor=EXTR  Method for extracting color from an area");
    println!("                     [average, median]. Average is the default.");
    println!("      --color-space=CS  Color space used for quantization; one of [rgb, din99d].");
    println!("                     Defaults to rgb, which is faster but less accurate.");
    println!("      --dither=DITHER  Set output dither mode; one of [none, ordered,");
    println!("                     diffusion, noise]. No effect with 24-bit color. Defaults to");
    println!("                     noise for sixels, none otherwise.");
    println!("      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a");
    println!("                     character cell [1, 2, 4, 8]. Defaults to 4x4.");
    println!("      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].");
    println!("                     Defaults to 1.0.");
    println!("      --fg=COLOR     Foreground color of display (color name or hex).");
    println!("      --invert       Swaps --fg and --bg. Useful with light terminal background.");
    println!("  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16");
    println!("                     colors or lower, off otherwise.");
    println!("  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].\n");
    println!("Resource allocation:");
    println!("      --threads=NUM  Maximum number of CPU threads to use. If left unspecified");
    println!("                     or negative, this will equal available CPU cores.");
    println!("  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the");
    println!("                     cheapest, 9 is the most accurate. Defaults to 5.\n");
    println!("Extra options for symbol encoding:");
    println!("      --fg-only      Leave the background color untouched. This produces");
    println!("                     character-cell output using foreground colors only.");
    println!("      --fill=SYMS    Specify character symbols to use for fill/gradients.");
    println!("                     Defaults to none. See below for full usage.");
    println!("      --glyph-file=FILE  Load glyph information from FILE, which can be any");
    println!("                     font file supported by FreeType (TTF, PCF, etc).");
    println!("      --symbols=SYMS  Specify character symbols to employ in final output.");
    println!("                     See below for full usage and a list of symbol classes.\n");
    println!("Accepted classes for --symbols and --fill:");
    println!("  all        ascii   braille   extra      imported  narrow   solid      ugly");
    println!("  alnum      bad     diagonal  geometric  inverted  none     space      vhalf");
    println!("  alpha      block   digit     half       latin     quad     stipple    wedge");
    println!("  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide\n");
    println!("  These can be combined with + and -, e.g. block+border-diagonal or all-wide.\n");
    println!("Examples:");
    println!("  $ chafa --scale max in.jpg                           # As big as will fit");
    println!("  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow");
    println!("  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art");
    println!("  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)\n");
    println!("If your OS comes with manual pages, you can type 'man chafa' for more.");
}
