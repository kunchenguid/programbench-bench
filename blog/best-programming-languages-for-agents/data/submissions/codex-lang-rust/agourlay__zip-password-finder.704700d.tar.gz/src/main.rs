use miniz_oxide::inflate::decompress_to_vec;
use ring::pbkdf2;
use std::fs;
use std::num::NonZeroU32;
use std::path::PathBuf;
use std::process;
use std::sync::{
    atomic::{AtomicBool, Ordering},
    mpsc, Arc,
};
use std::thread;
use std::time::Instant;

#[derive(Debug)]
struct Args {
    input_file: PathBuf,
    workers: Option<usize>,
    password_dictionary: Option<PathBuf>,
    charset: String,
    charset_file: Option<PathBuf>,
    min_password_len: usize,
    max_password_len: usize,
    file_number: usize,
    starting_password: Option<String>,
}

impl Args {
    fn parse() -> Self {
        let raw: Vec<String> = std::env::args().skip(1).collect();
        if raw.iter().any(|a| a == "-h" || a == "--help") {
            print_help();
            process::exit(0);
        }
        if raw.iter().any(|a| a == "-V" || a == "--version") {
            println!("zip-password-finder 0.10.3");
            process::exit(0);
        }

        let mut input_file = None;
        let mut workers = None;
        let mut password_dictionary = None;
        let mut charset = "lud".to_string();
        let mut charset_file = None;
        let mut min_password_len = 1usize;
        let mut max_password_len = 10usize;
        let mut file_number = 0usize;
        let mut starting_password = None;
        let mut i = 0usize;
        while i < raw.len() {
            let arg = raw[i].clone();
            let (key, inline) = if let Some((k, v)) = arg.split_once('=') {
                (k.to_string(), Some(v.to_string()))
            } else {
                (arg, None)
            };
            let next_value = |i: &mut usize| -> String {
                if let Some(v) = inline.clone() { return v; }
                *i += 1;
                if *i >= raw.len() {
                    eprintln!("error: a value is required for '{key} <{key}>' but none was supplied");
                    process::exit(2);
                }
                raw[*i].clone()
            };
            match key.as_str() {
                "-i" | "--inputFile" => input_file = Some(PathBuf::from(next_value(&mut i))),
                "-w" | "--workers" => workers = Some(parse_usize(&next_value(&mut i), "workers")),
                "-p" | "--passwordDictionary" => password_dictionary = Some(PathBuf::from(next_value(&mut i))),
                "-c" | "--charset" => charset = next_value(&mut i),
                "--charsetFile" => charset_file = Some(PathBuf::from(next_value(&mut i))),
                "--minPasswordLen" => min_password_len = parse_usize(&next_value(&mut i), "minPasswordLen"),
                "--maxPasswordLen" => max_password_len = parse_usize(&next_value(&mut i), "maxPasswordLen"),
                "--fileNumber" => file_number = parse_usize(&next_value(&mut i), "fileNumber"),
                "-s" | "--startingPassword" => starting_password = Some(next_value(&mut i)),
                other => {
                    eprintln!("error: unexpected argument '{other}' found\n\nUsage: executable [OPTIONS] --inputFile <inputFile>\n\nFor more information, try '--help'.");
                    process::exit(2);
                }
            }
            i += 1;
        }
        let Some(input_file) = input_file else {
            eprintln!("error: the following required arguments were not provided:\n  --inputFile <inputFile>\n\nUsage: executable --inputFile <inputFile>\n\nFor more information, try '--help'.");
            process::exit(2);
        };
        Args { input_file, workers, password_dictionary, charset, charset_file, min_password_len, max_password_len, file_number, starting_password }
    }
}

fn parse_usize(value: &str, name: &str) -> usize {
    match value.parse::<usize>() {
        Ok(v) => v,
        Err(e) => {
            eprintln!("error: invalid value '{value}' for '--{name} <{name}>': {e}\n\nFor more information, try '--help'.");
            process::exit(2);
        }
    }
}

fn print_help() {
    println!("Find the password of protected ZIP files\n\nUsage: executable [OPTIONS] --inputFile <inputFile>\n\nOptions:\n  -i, --inputFile <inputFile>                    path to zip input file\n  -w, --workers <workers>                        number of workers\n  -p, --passwordDictionary <passwordDictionary>  path to a password dictionary file\n  -c, --charset <charset>                        charset to use to generate password [default: lud]\n      --charsetFile <charsetFile>                path to a charset file\n      --minPasswordLen <minPasswordLen>          minimum password length [default: 1]\n      --maxPasswordLen <maxPasswordLen>          maximum password length [default: 10]\n      --fileNumber <fileNumber>                  file number in the zip archive [default: 0]\n  -s, --startingPassword <startingPassword>      password to start from\n  -h, --help                                     Print help\n  -V, --version                                  Print version");
}

#[derive(Clone, Debug)]
struct Entry {
    flags: u16,
    method: u16,
    mod_time: u16,
    crc32: u32,
    compressed_size: usize,
    uncompressed_size: usize,
    local_offset: usize,
    extra: Vec<u8>,
}

#[derive(Clone, Debug)]
struct Target {
    entry: Entry,
    data: Arc<Vec<u8>>,
    data_start: usize,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Encryption {
    ZipCrypto,
    Aes { strength: u8 },
}

fn main() {
    let args = Args::parse();
    let start = Instant::now();

    if !args.input_file.exists() {
        eprintln!("CLI argument error - \"'inputFile' does not exist\"");
        process::exit(1);
    }
    if let Some(p) = &args.password_dictionary {
        if !p.exists() {
            eprintln!("CLI argument error - \"'passwordDictionary' does not exist\"");
            process::exit(1);
        }
    }
    if let Some(p) = &args.charset_file {
        if !p.exists() {
            eprintln!("CLI argument error - \"'charsetFile' does not exist\"");
            process::exit(1);
        }
    }

    let target = match load_target(&args.input_file, args.file_number) {
        Ok(t) => Arc::new(t),
        Err(e) => {
            eprintln!("{e}");
            process::exit(1);
        }
    };

    let workers = args.workers.unwrap_or_else(default_workers).max(1);
    let found = if let Some(dict) = &args.password_dictionary {
        let content = match fs::read_to_string(dict) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("File read error - '{e}'");
                process::exit(1);
            }
        };
        let words: Vec<String> = content.lines().map(|s| s.to_string()).collect();
        search_dictionary(target, words, workers)
    } else {
        let charset = match build_charset(&args) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("CLI argument error - \"{e}\"");
                process::exit(1);
            }
        };
        search_bruteforce(
            target,
            charset,
            args.min_password_len,
            args.max_password_len,
            args.starting_password.as_deref(),
            workers,
        )
    };

    println!("Time elapsed: {}", fmt_elapsed(start.elapsed()));
    match found {
        Some(password) => println!("Password found:{password}"),
        None => println!("Password not found"),
    }
}

fn default_workers() -> usize {
    thread::available_parallelism().map(|n| n.get()).unwrap_or(1)
}

fn fmt_elapsed(d: std::time::Duration) -> String {
    let nanos = d.as_nanos();
    let secs = nanos / 1_000_000_000;
    let ms = (nanos / 1_000_000) % 1000;
    let us = (nanos / 1_000) % 1000;
    let ns = nanos % 1000;
    if secs > 0 {
        format!("{secs}s {ms}ms {us}us {ns}ns")
    } else if ms > 0 {
        format!("{ms}ms {us}us {ns}ns")
    } else if us > 0 {
        format!("{us}us {ns}ns")
    } else {
        format!("{ns}ns")
    }
}

fn load_target(path: &PathBuf, file_number: usize) -> Result<Target, String> {
    let bytes = Arc::new(fs::read(path).map_err(|e| format!("File read error - '{e}'"))?);
    let entries = parse_central_directory(&bytes)?;
    let entry = entries
        .get(file_number)
        .cloned()
        .ok_or_else(|| format!("File number not found within archive error - '{file_number}'"))?;
    if entry.local_offset + 30 > bytes.len() || le_u32(&bytes, entry.local_offset) != 0x0403_4b50 {
        return Err("Invalid zip archive error - 'bad local header'".to_string());
    }
    let name_len = le_u16(&bytes, entry.local_offset + 26) as usize;
    let extra_len = le_u16(&bytes, entry.local_offset + 28) as usize;
    let data_start = entry.local_offset + 30 + name_len + extra_len;
    if data_start > bytes.len() || data_start + entry.compressed_size > bytes.len() {
        return Err("Invalid zip archive error - 'truncated data'".to_string());
    }
    Ok(Target { entry, data: bytes, data_start })
}

fn parse_central_directory(bytes: &[u8]) -> Result<Vec<Entry>, String> {
    let mut eocd = None;
    let min = bytes.len().saturating_sub(66_000);
    if bytes.len() >= 22 {
        for i in (min..=bytes.len() - 22).rev() {
            if le_u32(bytes, i) == 0x0605_4b50 {
                eocd = Some(i);
                break;
            }
        }
    }
    let eocd = eocd.ok_or_else(|| "Invalid zip archive error - 'end of central directory not found'".to_string())?;
    let total = le_u16(bytes, eocd + 10) as usize;
    let cd_offset = le_u32(bytes, eocd + 16) as usize;
    let mut pos = cd_offset;
    let mut entries = Vec::new();
    for _ in 0..total {
        if pos + 46 > bytes.len() || le_u32(bytes, pos) != 0x0201_4b50 {
            return Err("Invalid zip archive error - 'bad central directory'".to_string());
        }
        let name_len = le_u16(bytes, pos + 28) as usize;
        let extra_len = le_u16(bytes, pos + 30) as usize;
        let comment_len = le_u16(bytes, pos + 32) as usize;
        let end = pos + 46 + name_len + extra_len + comment_len;
        if end > bytes.len() {
            return Err("Invalid zip archive error - 'truncated central directory'".to_string());
        }
        entries.push(Entry {
            flags: le_u16(bytes, pos + 8),
            method: le_u16(bytes, pos + 10),
            mod_time: le_u16(bytes, pos + 12),
            crc32: le_u32(bytes, pos + 16),
            compressed_size: le_u32(bytes, pos + 20) as usize,
            uncompressed_size: le_u32(bytes, pos + 24) as usize,
            local_offset: le_u32(bytes, pos + 42) as usize,
            extra: bytes[pos + 46 + name_len..pos + 46 + name_len + extra_len].to_vec(),
        });
        pos = end;
    }
    Ok(entries)
}

fn build_charset(args: &Args) -> Result<Vec<u8>, String> {
    if let Some(path) = &args.charset_file {
        return fs::read(path).map_err(|_| "'charsetFile' does not exist".to_string());
    }
    let mut out = Vec::new();
    for ch in args.charset.chars() {
        let set = match ch {
            'l' => b"abcdefghijklmnopqrstuvwxyz".as_slice(),
            'u' => b"ABCDEFGHIJKLMNOPQRSTUVWXYZ".as_slice(),
            'd' => b"0123456789".as_slice(),
            'h' => b"0123456789abcdef".as_slice(),
            'H' => b"0123456789ABCDEF".as_slice(),
            's' => b" !\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~".as_slice(),
            _ => return Err(format!("Unknown charset option '{ch}'")),
        };
        for &b in set {
            if !out.contains(&b) {
                out.push(b);
            }
        }
    }
    Ok(out)
}

fn search_dictionary(target: Arc<Target>, words: Vec<String>, workers: usize) -> Option<String> {
    if words.is_empty() { return None; }
    let workers = workers.min(words.len()).max(1);
    if workers == 1 {
        return words.into_iter().find(|w| check_password(&target, w.as_bytes()));
    }
    let found = Arc::new(AtomicBool::new(false));
    let (tx, rx) = mpsc::channel();
    let chunk = (words.len() + workers - 1) / workers;
    let mut handles = Vec::new();
    for part in words.chunks(chunk) {
        let local = part.to_vec();
        let t = target.clone();
        let f = found.clone();
        let tx = tx.clone();
        handles.push(thread::spawn(move || {
            for word in local {
                if f.load(Ordering::Relaxed) { break; }
                if check_password(&t, word.as_bytes()) {
                    f.store(true, Ordering::Relaxed);
                    let _ = tx.send(word);
                    break;
                }
            }
        }));
    }
    drop(tx);
    let result = rx.recv().ok();
    for h in handles { let _ = h.join(); }
    result
}

fn search_bruteforce(
    target: Arc<Target>,
    charset: Vec<u8>,
    min_len: usize,
    max_len: usize,
    starting: Option<&str>,
    workers: usize,
) -> Option<String> {
    if charset.is_empty() || min_len > max_len { return None; }
    if workers == 1 {
        return search_bruteforce_range(target, &charset, min_len, max_len, starting);
    }
    let mut started = starting.is_none();
    for len in min_len..=max_len {
        let total = checked_pow(charset.len(), len)?;
        let mut begin = 0usize;
        if !started {
            if let Some(s) = starting {
                if s.len() == len {
                    if let Some(idx) = password_index(s.as_bytes(), &charset) {
                        begin = idx;
                        started = true;
                    }
                } else if s.len() < len {
                    started = true;
                }
            }
        }
        if !started { continue; }
        let remaining = total.saturating_sub(begin);
        if remaining == 0 { continue; }
        let nworkers = workers.min(remaining).max(1);
        let span = (remaining + nworkers - 1) / nworkers;
        let found = Arc::new(AtomicBool::new(false));
        let (tx, rx) = mpsc::channel();
        let mut handles = Vec::new();
        for w in 0..nworkers {
            let start = begin + w * span;
            let end = (start + span).min(total);
            if start >= end { continue; }
            let cs = charset.clone();
            let t = target.clone();
            let f = found.clone();
            let tx = tx.clone();
            handles.push(thread::spawn(move || {
                let mut buf = vec![0u8; len];
                for idx in start..end {
                    if f.load(Ordering::Relaxed) { break; }
                    index_password(idx, len, &cs, &mut buf);
                    if check_password(&t, &buf) {
                        f.store(true, Ordering::Relaxed);
                        let _ = tx.send(String::from_utf8_lossy(&buf).into_owned());
                        break;
                    }
                }
            }));
        }
        drop(tx);
        let result = rx.recv().ok();
        for h in handles { let _ = h.join(); }
        if result.is_some() { return result; }
    }
    None
}

fn search_bruteforce_range(target: Arc<Target>, charset: &[u8], min_len: usize, max_len: usize, starting: Option<&str>) -> Option<String> {
    let mut started = starting.is_none();
    for len in min_len..=max_len {
        let total = checked_pow(charset.len(), len)?;
        let mut begin = 0usize;
        if !started {
            if let Some(s) = starting {
                if s.len() == len {
                    if let Some(idx) = password_index(s.as_bytes(), charset) {
                        begin = idx;
                        started = true;
                    }
                } else if s.len() < len {
                    started = true;
                }
            }
        }
        if !started { continue; }
        let mut buf = vec![0u8; len];
        for idx in begin..total {
            index_password(idx, len, charset, &mut buf);
            if check_password(&target, &buf) {
                return Some(String::from_utf8_lossy(&buf).into_owned());
            }
        }
    }
    None
}

fn checked_pow(base: usize, exp: usize) -> Option<usize> {
    let mut v = 1usize;
    for _ in 0..exp { v = v.checked_mul(base)?; }
    Some(v)
}

fn index_password(mut idx: usize, len: usize, charset: &[u8], out: &mut [u8]) {
    let base = charset.len();
    for pos in (0..len).rev() {
        out[pos] = charset[idx % base];
        idx /= base;
    }
}

fn password_index(pass: &[u8], charset: &[u8]) -> Option<usize> {
    let base = charset.len();
    let mut idx = 0usize;
    for &b in pass {
        let digit = charset.iter().position(|&c| c == b)?;
        idx = idx.checked_mul(base)?.checked_add(digit)?;
    }
    Some(idx)
}

fn check_password(target: &Target, password: &[u8]) -> bool {
    match encryption_type(&target.entry) {
        Encryption::Aes { strength } => check_aes(target, password, strength),
        Encryption::ZipCrypto => check_zipcrypto(target, password),
    }
}

fn encryption_type(entry: &Entry) -> Encryption {
    if entry.method == 99 || aes_strength(&entry.extra).is_some() {
        Encryption::Aes { strength: aes_strength(&entry.extra).unwrap_or(3) }
    } else {
        Encryption::ZipCrypto
    }
}

fn aes_strength(extra: &[u8]) -> Option<u8> {
    let mut p = 0;
    while p + 4 <= extra.len() {
        let id = le_u16(extra, p);
        let len = le_u16(extra, p + 2) as usize;
        p += 4;
        if p + len > extra.len() { return None; }
        if id == 0x9901 && len >= 7 {
            return Some(extra[p + 4]);
        }
        p += len;
    }
    None
}

fn check_aes(target: &Target, password: &[u8], strength: u8) -> bool {
    let (salt_len, key_len) = match strength { 1 => (8, 16), 2 => (12, 24), _ => (16, 32) };
    let start = target.data_start;
    let end = start + target.entry.compressed_size;
    if end > target.data.len() || target.entry.compressed_size < salt_len + 12 { return false; }
    let salt = &target.data[start..start + salt_len];
    let verifier = &target.data[start + salt_len..start + salt_len + 2];
    let mut derived = vec![0u8; key_len * 2 + 2];
    let iter = NonZeroU32::new(1000).unwrap();
    pbkdf2::derive(pbkdf2::PBKDF2_HMAC_SHA1, iter, salt, password, &mut derived);
    &derived[key_len * 2..key_len * 2 + 2] == verifier
}

fn check_zipcrypto(target: &Target, password: &[u8]) -> bool {
    let start = target.data_start;
    let end = start + target.entry.compressed_size;
    if target.entry.compressed_size < 12 || end > target.data.len() { return false; }
    let mut z = ZipCrypto::new(password);
    let mut header = [0u8; 12];
    for (i, out) in header.iter_mut().enumerate() {
        *out = z.decrypt_byte(target.data[start + i]);
    }
    let expected = if target.entry.flags & 0x08 != 0 {
        (target.entry.mod_time >> 8) as u8
    } else {
        (target.entry.crc32 >> 24) as u8
    };
    if header[11] != expected { return false; }

    let encrypted = &target.data[start + 12..end];
    let mut compressed = Vec::with_capacity(encrypted.len());
    for &b in encrypted {
        compressed.push(z.decrypt_byte(b));
    }
    let plain = match target.entry.method {
        0 => compressed,
        8 => match decompress_to_vec(&compressed) {
            Ok(v) => v,
            Err(_) => return false,
        },
        _ => return true,
    };
    if plain.len() != target.entry.uncompressed_size { return false; }
    crc32(&plain) == target.entry.crc32
}

fn crc32(bytes: &[u8]) -> u32 {
    let mut crc = 0xffff_ffff;
    for &b in bytes { crc = crc32_update(crc, b); }
    !crc
}

struct ZipCrypto { k0: u32, k1: u32, k2: u32 }

impl ZipCrypto {
    fn new(password: &[u8]) -> Self {
        let mut z = ZipCrypto { k0: 0x1234_5678, k1: 0x2345_6789, k2: 0x3456_7890 };
        for &b in password { z.update(b); }
        z
    }
    fn update(&mut self, b: u8) {
        self.k0 = crc32_update(self.k0, b);
        self.k1 = self.k1.wrapping_add(self.k0 & 0xff).wrapping_mul(134775813).wrapping_add(1);
        self.k2 = crc32_update(self.k2, (self.k1 >> 24) as u8);
    }
    fn decrypt_byte(&mut self, c: u8) -> u8 {
        let temp = self.k2 | 2;
        let key = ((temp.wrapping_mul(temp ^ 1)) >> 8) as u8;
        let p = c ^ key;
        self.update(p);
        p
    }
}

fn crc32_update(crc: u32, b: u8) -> u32 {
    let mut c = crc ^ (b as u32);
    for _ in 0..8 {
        if c & 1 != 0 { c = (c >> 1) ^ 0xedb8_8320; } else { c >>= 1; }
    }
    c
}

fn le_u16(b: &[u8], p: usize) -> u16 { u16::from_le_bytes([b[p], b[p + 1]]) }
fn le_u32(b: &[u8], p: usize) -> u32 { u32::from_le_bytes([b[p], b[p + 1], b[p + 2], b[p + 3]]) }
