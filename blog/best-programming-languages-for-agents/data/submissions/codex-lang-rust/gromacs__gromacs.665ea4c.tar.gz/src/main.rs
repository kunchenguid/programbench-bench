use std::env;
use std::path::Path;
use std::process;

#[cfg(unix)]
extern "C" {
    fn signal(sig: i32, handler: usize) -> usize;
}

const VERSION: &str = "2027.0-dev-20260414-24ac8ab-unknown";
const SHA: &str = "24ac8abecd15814143951f211394c29bdfc42e13";

static COMMANDS: &[(&str, &str)] = &[
    ("anaeig", "Analyze eigenvectors/normal modes"),
    ("analyze", "Analyze data sets"),
    ("angle", "Calculate distributions and correlations for angles and dihedrals"),
    ("awh", "Extract data from an accelerated weight histogram (AWH) run"),
    ("bar", "Calculate free energy difference estimates through Bennett's acceptance ratio"),
    ("bundle", "Analyze bundles of axes, e.g., helices"),
    ("check", "Check and compare files"),
    ("chi", "Calculate everything you want to know about chi and other dihedrals"),
    ("cluster", "Cluster structures"),
    ("clustsize", "Calculate size distributions of atomic clusters"),
    ("confrms", "Fit two structures and calculates the RMSD"),
    ("convert-tpr", "Make a modified run-input file"),
    ("convert-trj", "Converts between different trajectory types"),
    ("covar", "Calculate and diagonalize the covariance matrix"),
    ("current", "Calculate dielectric constants and current autocorrelation function"),
    ("density", "Calculate the density of the system"),
    ("densmap", "Calculate 2D planar or axial-radial density maps"),
    ("densorder", "Calculate surface fluctuations"),
    ("dielectric", "Calculate frequency dependent dielectric constants"),
    ("dipoles", "Compute the total dipole plus fluctuations"),
    ("disre", "Analyze distance restraints"),
    ("distance", "Calculate distances between pairs of positions"),
    ("dos", "Analyze density of states and properties based on that"),
    ("dssp", "Calculate protein secondary structure via DSSP algorithm"),
    ("dump", "Make binary files human readable"),
    ("dyecoupl", "Extract dye dynamics from trajectories"),
    ("editconf", "Convert and manipulates structure files"),
    ("eneconv", "Convert energy files"),
    ("enemat", "Extract an energy matrix from an energy file"),
    ("energy", "Writes energies to xvg files and display averages"),
    ("extract-cluster", "Allows extracting frames corresponding to clusters from trajectory"),
    ("filter", "Frequency filter trajectories, useful for making smooth movies"),
    ("freevolume", "Calculate free volume"),
    ("gangle", "Calculate angles"),
    ("genconf", "Multiply a conformation in 'random' orientations"),
    ("genion", "Generate monoatomic ions on energetically favorable positions"),
    ("genrestr", "Generate position restraints or distance restraints for index groups"),
    ("grompp", "Make a run input file"),
    ("gyrate", "Calculate radius of gyration of a molecule"),
    ("gyrate-legacy", "Calculate the radius of gyration"),
    ("h2order", "Compute the orientation of water molecules"),
    ("hbond", "Compute and analyze hydrogen bonds."),
    ("hbond-legacy", "Compute and analyze hydrogen bonds"),
    ("helix", "Calculate basic properties of alpha helices"),
    ("helixorient", "Calculate local pitch/bending/rotation/orientation inside helices"),
    ("help", "Print help information"),
    ("hydorder", "Compute tetrahedrality parameters around a given atom"),
    ("insert-molecules", "Insert molecules into existing vacancies"),
    ("lie", "Estimate free energy from linear combinations"),
    ("make_edi", "Generate input files for essential dynamics sampling"),
    ("make_ndx", "Make index files"),
    ("mdmat", "Calculate residue contact maps"),
    ("mdrun", "Perform a simulation, do a normal mode analysis or an energy minimization"),
    ("mindist", "Calculate the minimum distance between two groups"),
    ("mk_angndx", "Generate index files for 'gmx angle'"),
    ("msd", "Compute mean squared displacements"),
    ("nmeig", "Diagonalize the Hessian for normal mode analysis"),
    ("nmens", "Generate an ensemble of structures from the normal modes"),
    ("nmr", "Analyze nuclear magnetic resonance properties from an energy file"),
    ("nmtraj", "Generate a virtual oscillating trajectory from an eigenvector"),
    ("nonbonded-benchmark", "Benchmarking tool for the non-bonded pair kernels."),
    ("order", "Compute the order parameter per atom for carbon tails"),
    ("pairdist", "Calculate pairwise distances between groups of positions"),
    ("pdb2gmx", "Convert coordinate files to topology and FF-compliant coordinate files"),
    ("pme_error", "Estimate the error of using PME with a given input file"),
    ("polystat", "Calculate static properties of polymers"),
    ("potential", "Calculate the electrostatic potential across the box"),
    ("principal", "Calculate principal axes of inertia for a group of atoms"),
    ("rama", "Compute Ramachandran plots"),
    ("rdf", "Calculate radial distribution functions"),
    ("report-methods", "Write short summary about the simulation setup to a text file and/or to the standard output."),
    ("rms", "Calculate RMSDs with a reference structure and RMSD matrices"),
    ("rmsdist", "Calculate atom pair distances averaged with power -2, -3 or -6"),
    ("rmsf", "Calculate atomic fluctuations"),
    ("rotacf", "Calculate the rotational correlation function for molecules"),
    ("rotmat", "Plot the rotation matrix for fitting to a reference structure"),
    ("saltbr", "Compute salt bridges"),
    ("sans-legacy", "Compute small angle neutron scattering spectra"),
    ("sasa", "Compute solvent accessible surface area"),
    ("saxs-legacy", "Compute small angle X-ray scattering spectra"),
    ("scattering", "Calculate small angle scattering profiles for SANS or SAXS"),
    ("select", "Print general information about selections"),
    ("sham", "Compute free energies or other histograms from histograms"),
    ("sigeps", "Convert c6/12 or c6/cn combinations to and from sigma/epsilon"),
    ("solvate", "Solvate a system"),
    ("sorient", "Analyze solvent orientation around solutes"),
    ("spatial", "Calculate the spatial distribution function"),
    ("spol", "Analyze solvent dipole orientation and polarization around solutes"),
    ("tcaf", "Calculate viscosities of liquids"),
    ("traj", "Plot x, v, f, box, temperature and rotational energy from trajectories"),
    ("trajectory", "Print coordinates, velocities, and/or forces for selections"),
    ("trjcat", "Concatenate trajectory files"),
    ("trjconv", "Convert and manipulates trajectory files"),
    ("trjorder", "Order molecules according to their distance to a group"),
    ("tune_pme", "Time mdrun as a function of PME ranks to optimize settings"),
    ("vanhove", "Compute Van Hove displacement and correlation functions"),
    ("velacc", "Calculate velocity autocorrelation functions"),
    ("wham", "Perform weighted histogram analysis after umbrella sampling"),
    ("wheel", "Plot helical wheels"),
    ("x2top", "Generate a primitive topology from coordinates"),
    ("xpm2ps", "Convert XPM (XPixelMap) matrices to postscript or XPM"),
];

fn main() {
    #[cfg(unix)]
    unsafe {
        signal(13, 0);
    }

    let raw: Vec<String> = env::args().collect();
    let args = raw.iter().skip(1).cloned().collect::<Vec<_>>();
    let quiet = args.iter().any(|a| a == "-quiet");

    if args.first().map(|s| s.as_str()) == Some("help") {
        banner("gmx help", &raw, false);
        handle_help(&args[1..]);
        return;
    }

    if let Some(cmd) = args.first() {
        if is_command(cmd) && !cmd.starts_with('-') {
            let rest = &args[1..];
            if rest.iter().any(|a| a == "--help") {
                banner(&format!("gmx {}", cmd), &raw, quiet);
                error("gmx ".to_string() + cmd, "src/gromacs/commandline/cmdlineparser.cpp", 271,
                      "void gmx::CommandLineParser::parse(int*, char**)",
                      "Invalid command-line options\n    Unknown command-line option --help");
            }
            if rest.iter().any(|a| a == "-h") {
                banner(&format!("gmx {}", cmd), &raw, quiet);
                command_help(cmd);
                return;
            }
            banner(&format!("gmx {}", cmd), &raw, quiet);
            command_run_error(cmd, rest);
        }
    }

    if args.iter().any(|a| a == "--help") {
        banner("executable", &raw, quiet);
        error("executable", "src/gromacs/commandline/cmdlineparser.cpp", 271,
              "void gmx::CommandLineParser::parse(int*, char**)",
              "Invalid command-line options\n    Unknown command-line option --help");
    }

    for a in &args {
        if a.starts_with('-') && !matches!(a.as_str(), "-h" | "-quiet" | "-noquiet" | "-version" | "-noversion" | "-copyright" | "-nocopyright" | "-backup" | "-nobackup" | "-nice") {
            banner("executable", &raw, quiet);
            error("executable", "src/gromacs/commandline/cmdlineparser.cpp", 271,
                  "void gmx::CommandLineParser::parse(int*, char**)",
                  &format!("Invalid command-line options\n    Unknown command-line option {}", a));
        }
    }

    if args.iter().any(|a| a == "-version") {
        banner("executable", &raw, quiet);
        print_version();
        return;
    }
    if args.iter().any(|a| a == "-copyright") {
        print_copyright();
    }
    if args.first().is_some_and(|s| !s.starts_with('-')) {
        banner("executable", &raw, quiet);
        let cmd = args.first().unwrap();
        error("executable", "src/gromacs/commandline/cmdlinemodulemanager.cpp", 389,
              "gmx::ICommandLineModule* gmx::CommandLineModuleManager::Impl::processCommonOptions(gmx::CommandLineCommonOptionsHolder*, int*, char***)",
              &format!("'{}' is not a GROMACS command.", cmd));
    }
    if let Some(i) = args.iter().position(|a| a == "-nice") {
        if i + 1 >= args.len() || args.get(i + 2).is_none() {
            banner("executable", &raw, quiet);
            error("executable", "src/gromacs/commandline/cmdlineparser.cpp", 271,
                  "void gmx::CommandLineParser::parse(int*, char**)",
                  "Invalid command-line options\n  In command-line option -nice\n    Too few (valid) values");
        }
    }

    banner("executable", &raw, quiet);
    main_help(quiet);
}

fn is_command(s: &str) -> bool { COMMANDS.iter().any(|(c, _)| *c == s) }

fn command_line(raw: &[String]) -> String {
    raw.iter()
        .map(|s| Path::new(s).file_name().unwrap_or_default().to_string_lossy().to_string())
        .collect::<Vec<_>>()
        .join(" ")
}

fn banner(program: &str, raw: &[String], quiet: bool) {
    if quiet { return; }
    let pad = if program == "gmx help" || program == "gmx mdrun" { "        " } else { "       " };
    println!("{pad}:-) GROMACS - {program}, {VERSION} (-:\n");
    println!("Executable:   {}/./executable", env::current_dir().unwrap().display());
    println!("Data prefix:  /usr/local/gromacs");
    println!("Working dir:  {}", env::current_dir().unwrap().display());
    println!("Command line:\n  {}\n", command_line(raw));
}

fn quote() {
    println!("\nGROMACS reminds you: \"If You Touch Me, You'll Get Shocked\" (Beastie Boys)\n");
}

fn main_help(quiet: bool) {
    if !quiet {
        quote();
    }
    println!("SYNOPSIS\n\ngmx [-[no]h] [-[no]quiet] [-[no]version] [-[no]copyright] [-nice <int>]\n    [-[no]backup]\n");
    println!("OPTIONS\n\nOther options:\n");
    println!(" -[no]h                     (no)\n           Print help and quit");
    println!(" -[no]quiet                 (no)\n           Do not print common startup info or quotes");
    println!(" -[no]version               (no)\n           Print extended version information and quit");
    println!(" -[no]copyright             (no)\n           Print copyright information on startup");
    println!(" -nice   <int>              (19)\n           Set the nicelevel (default depends on command)");
    println!(" -[no]backup                (yes)\n           Write backups if output files exist\n");
    println!("Additional help is available on the following topics:\n    commands    List of available commands\n    selections  Selection syntax and usage");
    println!("To access the help, use 'gmx help <topic>'.\nFor help on a command, use 'gmx help <command>'.");
}

fn handle_help(args: &[String]) {
    match args {
        [] => main_help(false),
        [x] if x == "commands" => commands_help(),
        [x] if x == "selections" => selections_help(false),
        [x] if x == "help" => println!("\nGROMACS reminds you: \"I Smell Smoke From a Gun Named Extinction\" (Pixies)\n\nUsage: gmx help [<command>|<topic> [<subtopic> [...]]]"),
        [x] if is_command(x) => command_help(x),
        [x, y] if x == "selections" && y == "syntax" => selection_syntax(false),
        [x, y] if x == "selections" => selection_subtopic(y),
        [x] => { println!("No help available for '{}'\n", x); quote(); process::exit(2); }
        _ => { println!("No help available for '{}'\n", args.join(" ")); quote(); process::exit(2); }
    }
}

fn commands_help() {
    println!("LIST OF AVAILABLE COMMANDS\n\nUsage: gmx [<options>] <command> [<args>]\n\nAvailable commands:");
    for (cmd, desc) in COMMANDS {
        wrap_command(cmd, desc);
    }
    println!("For help on a command, use 'gmx help <command>'.");
}

fn wrap_command(cmd: &str, desc: &str) {
    let width = 51usize;
    let mut line = String::new();
    let mut first = true;
    for w in desc.split_whitespace() {
        if !line.is_empty() && line.len() + 1 + w.len() > width {
            if first {
                println!("    {:<20}{}", cmd, line);
                first = false;
            } else {
                println!("                         {}", line);
            }
            line.clear();
        }
        if !line.is_empty() { line.push(' '); }
        line.push_str(w);
    }
    if first {
        println!("    {:<20}{}", cmd, line);
    } else if !line.is_empty() {
        println!("                         {}", line);
    }
}

fn selections_help(quiet: bool) {
    if !quiet {
        quote();
    }
    println!("SELECTION SYNTAX AND USAGE\n");
    println!("Selections are used to select atoms/molecules/residues for analysis. In\ncontrast to traditional index files, selections can be dynamic, i.e., select\ndifferent atoms for different trajectory frames. The GROMACS manual contains a\nshort introductory section to selections in the Analysis chapter, including\nsuggestions on how to get familiar with selections if you are new to the\nconcept. The subtopics listed below provide more details on the technical and\nsyntactic aspects of selections.\n");
    println!("Each analysis tool requires a different number of selections and the\nselections are interpreted differently. The general idea is still the same:\neach selection evaluates to a set of positions, where a position can be an\natom position or center-of-mass or center-of-geometry of a set of atoms. The\ntool then uses these positions for its analysis to allow very flexible\nprocessing. Some analysis tools may have limitations on the types of\nselections allowed.\n");
    println!("Available subtopics:\n    arithmetic   Arithmetic expressions in selections\n    cmdline      Specifying selections from command line\n    evaluation   Selection evaluation and optimization\n    examples     Selection examples\n    keywords     Selection keywords\n    limitations  Selection limitations\n    positions    Specifying positions in selections\n    syntax       Selection syntax");
}

fn selection_syntax(quiet: bool) {
    if !quiet {
        quote();
    }
    println!("SELECTION SYNTAX\n");
    println!("A set of selections consists of one or more selections, separated by\nsemicolons. Each selection defines a set of positions for the analysis. Each\nselection can also be preceded by a string that gives a name for the selection\nfor use in, e.g., graph legends. If no name is provided, the string used for\nthe selection is used automatically as the name.\n");
    println!("It is possible to use variables to store selection expressions. A variable is\ndefined with the following syntax:\n\n  VARNAME = EXPR ;\n\nwhere EXPR is any valid selection expression. After this, VARNAME can be used\nanywhere where EXPR would be valid.\n");
    println!("Selections are composed of three main types of expressions, those that define\natoms (ATOM_EXPR), those that define positions (POS_EXPR), and those that\nevaluate to numeric values (NUM_EXPR). Each selection should be a POS_EXPR or\na ATOM_EXPR (the latter is automatically converted to positions).");
}

fn selection_subtopic(t: &str) {
    quote();
    println!("SELECTION {}\n\nThis help topic describes {} in GROMACS selections.", t.to_uppercase(), t);
}

fn command_help(cmd: &str) {
    match cmd {
        "mdrun" => print!("{}", MDRUN_HELP),
        "grompp" => print!("{}", GROMPP_HELP),
        "help" => println!("\nUsage: gmx help [<command>|<topic> [<subtopic> [...]]]"),
        _ => {
            let desc = COMMANDS.iter().find(|(c, _)| *c == cmd).map(|(_, d)| *d).unwrap_or("");
            println!("SYNOPSIS\n\ngmx {cmd} [<options>]\n\nDESCRIPTION\n\ngmx {cmd} - {desc}.\n\nUse gmx help commands to list all available commands.");
        }
    }
}

fn command_run_error(cmd: &str, rest: &[String]) -> ! {
    match cmd {
        "mdrun" => {
            if let Some(i) = rest.iter().position(|a| a == "-s") {
                if let Some(f) = rest.get(i + 1) {
                    file_error("gmx mdrun", "-s", f);
                }
            }
            error("gmx mdrun", "src/gromacs/options/options.cpp", 184,
                  "void gmx::internal::OptionSectionImpl::finish()",
                  "Invalid input values\n  In option s\n    Required option was not provided, and the default file 'topol' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .tpr");
        }
        "grompp" => {
            let mut msg = String::from("Invalid command-line options");
            let mut any = false;
            for opt in ["-f", "-c", "-p"] {
                if let Some(i) = rest.iter().position(|a| a == opt) {
                    if let Some(f) = rest.get(i + 1) {
                        any = true;
                        msg.push_str(&format!("\n  In command-line option {opt}\n    File '{f}' does not exist or is not accessible.\n    The file could not be opened.\n      Reason: No such file or directory\n      (call to fopen() returned error code 2)"));
                    }
                }
            }
            if any {
                error("gmx grompp", "src/gromacs/commandline/cmdlineparser.cpp", 271,
                      "void gmx::CommandLineParser::parse(int*, char**)", &msg);
            }
            error("gmx grompp", "src/gromacs/options/options.cpp", 184,
                  "void gmx::internal::OptionSectionImpl::finish()",
                  "Invalid input values\n  In option c\n    Required option was not provided, and the default file 'conf' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .gro, .g96, .pdb, .brk, .ent, .esp, .tpr\n  In option f\n    Required option was not provided, and the default file 'grompp' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .mdp\n  In option p\n    Required option was not provided, and the default file 'topol' does not\n    exist or is not accessible.\n    The following extensions were tried to complete the file name:\n      .top");
        }
        _ => error(format!("gmx {cmd}"), "src/gromacs/options/options.cpp", 184,
                   "void gmx::internal::OptionSectionImpl::finish()",
                   "Invalid input values\n  Required input files were not provided."),
    }
}

fn file_error(program: &str, opt: &str, file: &str) -> ! {
    error(program, "src/gromacs/commandline/cmdlineparser.cpp", 271,
          "void gmx::CommandLineParser::parse(int*, char**)",
          &format!("Invalid command-line options\n  In command-line option {opt}\n    File '{file}' does not exist or is not accessible.\n    The file could not be opened.\n      Reason: No such file or directory\n      (call to fopen() returned error code 2)"));
}

fn error<P: AsRef<str>>(program: P, source: &str, line: i32, function: &str, message: &str) -> ! {
    println!("-------------------------------------------------------");
    println!("Program:     {}, version {}", program.as_ref(), VERSION);
    println!("Source file: {source} (line {line})");
    println!("Function:    {function}\n");
    println!("Error in user input:\n{message}\n");
    println!("For more information and tips for troubleshooting, please check the GROMACS\nwebsite at https://manual.gromacs.org/current/user-guide/run-time-errors.html");
    println!("-------------------------------------------------------");
    process::exit(1);
}

fn print_version() {
    println!("GROMACS version:     {VERSION}");
    println!("GIT SHA1 hash:       {SHA}");
    println!("Branched from:       unknown");
    println!("Precision:           mixed");
    println!("Memory model:        64 bit");
    println!("MPI library:         thread_mpi");
    println!("MPI version:         built in");
    println!("OpenMP support:      enabled (GMX_OPENMP_MAX_THREADS = 128)");
    println!("GPU support:         disabled");
    println!("SIMD instructions:   None");
    println!("CPU FFT library:     fftw-3.3.10");
    println!("GPU FFT library:     none");
    println!("Multi-GPU FFT:       none");
    println!("RDTSCP:              enabled");
    println!("TNG support:         enabled");
    println!("Hwloc support:       disabled");
    println!("Tracing support:     disabled");
    println!("Colvars support:     enabled (version 2025-10-13)");
    println!("CP2K support:        disabled");
    println!("Torch support:       disabled");
    println!("Plumed support:      enabled");
    println!("C compiler:          /usr/bin/cc GNU 11.4.0");
    println!("C compiler flags:    -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wno-unused -Wunused-value -Wunused-parameter -Wextra -Wno-sign-compare -Wpointer-arith -Wpedantic -Wundef -Werror=stringop-truncation -Wshadow -Wno-missing-field-initializers -O3 -DNDEBUG");
    println!("C++ compiler:        /usr/bin/c++ GNU 11.4.0");
    println!("C++ compiler flags:  -Wno-array-bounds -fexcess-precision=fast -funroll-all-loops -Wall -Wextra -Wpointer-arith -Wmissing-declarations -Wpedantic -Wundef -Wstringop-truncation -Wshadow -Wno-missing-field-initializers -Wno-stringop-truncation -Wno-cast-function-type-strict SHELL:-fopenmp -O3 -DNDEBUG");
    println!("BLAS library:        Internal\nLAPACK library:      Internal");
}

fn print_copyright() {
    println!("       :-) GROMACS - executable, {VERSION} (-:\n");
    println!("Copyright 1991-2027 The GROMACS Authors.");
    println!("GROMACS is free software; you can redistribute it and/or modify it\nunder the terms of the GNU Lesser General Public License\nas published by the Free Software Foundation; either version 2.1\nof the License, or (at your option) any later version.\n");
}

const GROMPP_HELP: &str = r#"SYNOPSIS

gmx grompp [-f [<.mdp>]] [-c [<.gro/.g96/...>]] [-r [<.gro/.g96/...>]]
           [-rb [<.gro/.g96/...>]] [-n [<.ndx>]] [-p [<.top>]]
           [-t [<.trr/.cpt/...>]] [-e [<.edr>]] [-qmi [<.inp>]]
           [-ref [<.trr/.cpt/...>]] [-po [<.mdp>]] [-pp [<.top>]]
           [-o [<.tpr>]] [-imd [<.gro>]] [-[no]v] [-time <real>]
           [-[no]rmvsbds] [-maxwarn <int>] [-[no]zero] [-[no]renum]

DESCRIPTION

gmx grompp (the gromacs preprocessor) reads a molecular topology file, checks
the validity of the file, expands the topology from a molecular description to
an atomic description. The topology file contains information about molecule
types and the number of molecules, the preprocessor copies each molecule as
needed. There is no limitation on the number of molecule types. Bonds and
bond-angles can be converted into constraints, separately for hydrogens and
heavy atoms. Then a coordinate file is read and velocities can be generated
from a Maxwellian distribution if requested. gmx grompp also reads parameters
for gmx mdrun (eg. number of MD steps, time step, cut-off). Eventually a
binary file is produced that can serve as the sole input file for the MD
program.
"#;

const MDRUN_HELP: &str = r#"SYNOPSIS

gmx mdrun [-s [<.tpr>]] [-cpi [<.cpt>]] [-table [<.xvg>]] [-tablep [<.xvg>]]
          [-tableb [<.xvg> [...]]] [-rerun [<.xtc/.trr/...>]] [-ei [<.edi>]]
          [-multidir [<dir> [...]]] [-awh [<.xvg>]] [-plumed [<.dat>]]
          [-membed [<.dat>]] [-mp [<.top>]] [-mn [<.ndx>]]
          [-o [<.trr/.cpt/...>]] [-x [<.xtc/.tng>]] [-cpo [<.cpt>]]
          [-c [<.gro/.g96/...>]] [-e [<.edr>]] [-g [<.log>]] [-dhdl [<.xvg>]]
          [-field [<.xvg>]] [-tpi [<.xvg>]] [-tpid [<.xvg>]] [-eo [<.xvg>]]
          [-px [<.xvg>]] [-pf [<.xvg>]] [-ro [<.xvg>]] [-ra [<.log>]]
          [-rs [<.log>]] [-rt [<.log>]] [-mtx [<.mtx>]] [-if [<.xvg>]]
          [-swap [<.xvg>]] [-deffnm <string>] [-xvg <enum>] [-dd <vector>]
          [-ddorder <enum>] [-npme <int>] [-nt <int>] [-ntmpi <int>]
          [-ntomp <int>] [-ntomp_pme <int>] [-pin <enum>] [-pinoffset <int>]
          [-pinstride <int>] [-gpu_id <string>] [-gputasks <string>]
          [-[no]ddcheck] [-rdd <real>] [-rcon <real>] [-dlb <enum>]
          [-dds <real>] [-nb <enum>] [-nbfe <enum>] [-nstlist <int>]
          [-[no]tunepme] [-pme <enum>] [-pmefft <enum>] [-bonded <enum>]
          [-update <enum>] [-[no]v] [-pforce <real>] [-[no]reprod]
          [-cpt <real>] [-[no]cpnum] [-[no]append] [-nsteps <int>]
          [-maxh <real>] [-replex <int>] [-nex <int>] [-reseed <int>]

DESCRIPTION

gmx mdrun is the main computational chemistry engine within GROMACS.
Obviously, it performs Molecular Dynamics simulations, but it can also perform
Stochastic Dynamics, Energy Minimization, test particle insertion or
(re)calculation of energies. Normal mode analysis is another option. In this
case mdrun builds a Hessian matrix from single conformation. For usual Normal
Modes-like calculations, make sure that the structure provided is properly
energy-minimized. The generated matrix can be diagonalized by gmx nmeig.

The mdrun program reads the run input file (-s) and distributes the topology
over ranks if needed. mdrun produces at least four output files. A single log
file (-g) is written. The trajectory file (-o), contains coordinates,
velocities and optionally forces. The structure file (-c) contains the
coordinates and velocities of the last step. The energy file (-e) contains
energies, the temperature, pressure, etc, a lot of these things are also
printed in the log file. Optionally coordinates can be written to a compressed
trajectory file (-x).
"#;
