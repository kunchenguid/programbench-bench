use base64::Engine;
use chrono::Local;
use sha2::{Digest, Sha256};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};

const COMMUNITY_NOTICE: &str = "Notice: This Atlas edition lacks support for features such as checkpoints,\ntesting, down migrations, and more. Additionally, advanced database objects such as views, \ntriggers, and stored procedures are not supported. To read more: https://atlasgo.io/community-edition\n\nTo install the non-community version of Atlas, use the following command:\n\n\tcurl -sSf https://atlasgo.sh | sh\n\nOr, visit the website to see all installation options:\n\n\thttps://atlasgo.io/docs#installation\n";

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let code = run(&args);
    std::process::exit(code);
}

fn run(args: &[String]) -> i32 {
    if args.is_empty() || has_help(args) {
        return help_dispatch(args);
    }
    match args[0].as_str() {
        "help" => {
            if args.len() == 1 { print_help_help(); } else { help_dispatch(&args[1..]); }
            0
        }
        "version" => {
            println!("atlas unofficial version - development");
            println!("https://github.com/ariga/atlas/releases/latest");
            println!("To download an official version, visit: https://atlasgo.io/getting-started#installation");
            0
        }
        "license" => {
            println!("LICENSE");
            println!("Atlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE.");
            0
        }
        "completion" => completion(args),
        "schema" => schema(args),
        "migrate" => migrate(args),
        x if x.starts_with('-') => {
            eprintln!("Error: unknown flag: {}", x);
            1
        }
        x => {
            eprintln!("Error: unknown command {:?} for \"atlas\"", x);
            eprintln!("Run 'atlas --help' for usage.");
            eprintln!("You're running the community build of Atlas, which may differ from the official version.");
            eprintln!("If this error persists, try installing the official version as a troubleshooting step:\n");
            eprintln!("  curl -sSf https://atlasgo.sh | sh\n");
            eprintln!("More installation options: https://atlasgo.io/docs#installation");
            1
        }
    }
}

fn has_help(args: &[String]) -> bool {
    args.iter().any(|a| a == "-h" || a == "--help")
}

fn help_dispatch(args: &[String]) -> i32 {
    match args {
        [] => print_root_help(),
        [c] if c == "version" => print_version_help(),
        [c] if c == "license" => print_license_help(),
        [c] if c == "completion" => print_completion_help(),
        [c] if c == "schema" => print_schema_help(),
        [c] if c == "migrate" => print_migrate_help(),
        [c] if c == "help" => print_help_help(),
        [a, b, ..] if a == "schema" => print_schema_sub_help(b),
        [a, b, ..] if a == "migrate" => print_migrate_sub_help(b),
        [a, b, ..] if a == "completion" => print_completion_sub_help(b),
        _ => print_root_help(),
    }
    0
}

fn print_root_help() {
    println!("Manage your database schema as code\n");
    println!("Usage:\n  atlas [command]\n");
    println!("Available Commands:");
    println!("  completion  Generate the autocompletion script for the specified shell");
    println!("  help        Help about any command");
    println!("  license     Display license information");
    println!("  migrate     Manage versioned migration files");
    println!("  schema      Work with atlas schemas.");
    println!("  version     Prints this Atlas CLI version information.\n");
    println!("Flags:\n  -h, --help   help for atlas\n");
    println!("Use \"atlas [command] --help\" for more information about a command.");
}

fn print_help_help() {
    println!("Help provides help for any command in the application.");
    println!("Simply type atlas help [path to command] for full details.\n");
    println!("Usage:\n  atlas help [command] [flags]\n");
    println!("Flags:\n  -h, --help   help for help");
}

fn print_version_help() {
    println!("Prints this Atlas CLI version information.\n");
    println!("Usage:\n  atlas version [flags]\n");
    println!("Flags:\n  -h, --help   help for version");
}

fn print_license_help() {
    println!("Display license information\n");
    println!("Usage:\n  atlas license [flags]\n");
    println!("Flags:\n  -h, --help   help for license");
}

fn print_completion_help() {
    println!("Generate the autocompletion script for atlas for the specified shell.");
    println!("See each sub-command's help for details on how to use the generated script.\n");
    println!("Usage:\n  atlas completion [command]\n");
    println!("Available Commands:");
    println!("  bash        Generate the autocompletion script for bash");
    println!("  fish        Generate the autocompletion script for fish");
    println!("  powershell  Generate the autocompletion script for powershell");
    println!("  zsh         Generate the autocompletion script for zsh\n");
    println!("Flags:\n  -h, --help   help for completion\n");
    println!("Use \"atlas completion [command] --help\" for more information about a command.");
}

fn print_schema_help() {
    println!("The `atlas schema` command groups subcommands working with declarative Atlas schemas.\n");
    println!("Usage:\n  atlas schema [command]\n");
    println!("Available Commands:");
    println!("  apply       Apply an atlas schema to a target database.");
    println!("  clean       Removes all objects from the connected database.");
    println!("  diff        Calculate and print the diff between two schemas.");
    println!("  fmt         Formats Atlas HCL files");
    println!("  inspect     Inspect a database and print its schema in Atlas DDL syntax.\n");
    print_global_flags("schema");
    println!("Use \"atlas schema [command] --help\" for more information about a command.");
}

fn print_migrate_help() {
    println!("'atlas migrate' wraps several sub-commands for migration management.\n");
    println!("Usage:\n  atlas migrate [command]\n");
    println!("Available Commands:");
    println!("  apply       Applies pending migration files on the connected database.");
    println!("  diff        Compute the diff between the migration directory and a desired state and create a new migration file.");
    println!("  hash        Hash (re-)creates an integrity hash file for the migration directory.");
    println!("  import      Import a migration directory from another migration management tool to the Atlas format.");
    println!("  lint        Run analysis on the migration directory");
    println!("  new         Creates a new empty migration file in the migration directory.");
    println!("  set         Set the current version of the migration history table.");
    println!("  status      Get information about the current migration status.");
    println!("  validate    Validates the migration directories checksum and SQL statements.\n");
    print_global_flags("migrate");
    println!("Use \"atlas migrate [command] --help\" for more information about a command.");
}

fn print_global_flags(name: &str) {
    println!("Flags:");
    println!("  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")");
    println!("      --env string           set which env from the config file to use");
    println!("  -h, --help                 help for {}", name);
    println!("      --var <name>=<value>   input variables (default [])\n");
}

fn print_schema_sub_help(cmd: &str) {
    match cmd {
        "fmt" => {
            println!("'atlas schema fmt' formats all \".hcl\" files under the given paths using");
            println!("canonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.");
            println!("Unless stated otherwise, the fmt command will use the current directory.\n");
            println!("After running, the command will print the names of the files it has formatted. If all");
            println!("files in the directory are formatted, no input will be printed out.\n");
            println!("Usage:\n  atlas schema fmt [path ...] [flags]\n");
            println!("Flags:\n  -h, --help   help for fmt\n");
            println!("Global Flags:");
            println!("  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")");
            println!("      --env string           set which env from the config file to use");
            println!("      --var <name>=<value>   input variables (default [])");
        }
        "inspect" => {
            println!("'atlas schema inspect' connects to the given database and inspects its schema.");
            println!("It then prints to the screen the schema of that database in Atlas DDL syntax. This output can be");
            println!("saved to a file, commonly by redirecting the output to a file named with a \".hcl\" suffix:\n");
            println!("  atlas schema inspect -u \"mysql://user:pass@localhost:3306/dbname\" > schema.hcl\n");
            println!("Usage:\n  atlas schema inspect [flags]\n");
            println!("Flags:");
            println!("  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format");
            println!("      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format");
            println!("  -s, --schema strings    set schema names");
            println!("      --exclude strings   list of glob patterns used to filter resources from applying");
            println!("      --format string     Go template to use to format the output");
            println!("  -h, --help              help for inspect\n");
            println!("Global Flags:");
            println!("  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")");
            println!("      --env string           set which env from the config file to use");
            println!("      --var <name>=<value>   input variables (default [])");
        }
        "diff" => generic_schema_help("diff", "Calculate and print the diff between two schemas."),
        "apply" => generic_schema_help("apply", "Apply an atlas schema to a target database."),
        "clean" => generic_schema_help("clean", "Removes all objects from the connected database."),
        _ => print_schema_help(),
    }
}

fn generic_schema_help(cmd: &str, desc: &str) {
    println!("{}\n", desc);
    println!("Usage:\n  atlas schema {} [flags]\n", cmd);
    println!("Flags:\n  -h, --help   help for {}\n", cmd);
    println!("Global Flags:");
    println!("  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")");
    println!("      --env string           set which env from the config file to use");
    println!("      --var <name>=<value>   input variables (default [])");
}

fn print_migrate_sub_help(cmd: &str) {
    match cmd {
        "new" => {
            println!("'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.\n");
            println!("Usage:\n  atlas migrate new [flags] [name]\n");
            println!("Examples:\n  atlas migrate new my-new-migration\n");
            println!("Flags:");
            println!("      --dir string          select migration directory using URL format (default \"file://migrations\")");
            println!("      --dir-format string   select migration file format (default \"atlas\")");
            println!("      --edit                edit the created migration file(s)");
            println!("  -h, --help                help for new\n");
            println!("Global Flags:");
            println!("  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")");
            println!("      --env string           set which env from the config file to use");
            println!("      --var <name>=<value>   input variables (default [])");
        }
        "hash" | "validate" | "status" | "apply" | "diff" | "lint" | "import" | "set" => {
            println!("Usage:\n  atlas migrate {} [flags]\n", cmd);
            println!("Flags:");
            println!("      --dir string          select migration directory using URL format (default \"file://migrations\")");
            println!("      --dir-format string   select migration file format (default \"atlas\")");
            println!("  -h, --help                help for {}", cmd);
        }
        _ => print_migrate_help(),
    }
}

fn print_completion_sub_help(shell: &str) {
    match shell {
        "bash" | "zsh" | "fish" | "powershell" => {
            println!("Generate the autocompletion script for the {} shell.\n", shell);
            println!("Usage:\n  atlas completion {} [flags]\n", shell);
            println!("Flags:\n  -h, --help              help for {}", shell);
            println!("      --no-descriptions   disable completion descriptions");
        }
        _ => print_completion_help(),
    }
}

fn completion(args: &[String]) -> i32 {
    if args.len() < 2 {
        print_completion_help();
        return 0;
    }
    if has_help(args) {
        print_completion_sub_help(&args[1]);
        return 0;
    }
    println!("# completion script for atlas {}", args[1]);
    0
}

fn schema(args: &[String]) -> i32 {
    if args.len() < 2 || !matches!(args[1].as_str(), "fmt" | "inspect" | "diff" | "apply" | "clean") {
        print_schema_help();
        return 0;
    }
    if unknown_flag(args) {
        return 1;
    }
    match args[1].as_str() {
        "fmt" => schema_fmt(&args[2..]),
        "inspect" => schema_inspect(&args[2..]),
        "diff" => required("from\", \"to"),
        "apply" | "clean" => required("url"),
        _ => 0,
    }
}

fn unknown_flag(args: &[String]) -> bool {
    let known = [
        "-u", "--url", "--dev-url", "-s", "--schema", "--exclude", "--include", "--format", "-c",
        "--config", "--env", "--var", "--to", "-t", "--from", "-f", "--dir", "--dir-format",
        "--edit", "--dry-run", "--auto-approve", "--lock-timeout", "--baseline", "--tx-mode",
        "--exec-order", "--allow-dirty", "--latest", "--git-base", "--git-dir", "--revisions-schema",
        "--plan", "--qualifier",
    ];
    let flags_with_value = known;
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a.starts_with('-') && !known.iter().any(|k| a == k || a.starts_with(&format!("{}=", k))) {
            eprintln!("Error: unknown flag: {}", a);
            return true;
        }
        if flags_with_value.contains(&a.as_str()) && !matches!(a.as_str(), "--edit" | "--dry-run" | "--auto-approve" | "--allow-dirty") {
            i += 1;
        }
        i += 1;
    }
    false
}

fn required(name: &str) -> i32 {
    eprintln!("Error: required flag(s) \"{}\" not set", name);
    1
}

fn schema_inspect(args: &[String]) -> i32 {
    let url = value_of(args, "--url").or_else(|| value_of(args, "-u"));
    let env_name = value_of(args, "--env");
    let config = value_of(args, "--config").or_else(|| value_of(args, "-c"));
    if url.is_none() && env_name.is_none() {
        return required("url");
    }
    if let Some(cfg) = config {
        let p = strip_file_url(&cfg);
        if let Ok(s) = fs::read_to_string(p) {
            if s.contains("invalid syntax") {
                eprintln!("Error: sql/migrate: stat migrations: no such file or directory");
                eprintln!("efinition required; An argument or block definition is required here.");
                return 1;
            }
            if let Some(env_name) = &env_name {
                let needle = format!("env \"{}\"", env_name);
                if !s.contains(&needle) {
                    return 1;
                }
            }
        }
    }
    if let Some(u) = url {
        if !u.starts_with("sqlite://") && !u.starts_with("sqlite3://") {
            eprintln!("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
            return 1;
        }
        eprintln!("{}", COMMUNITY_NOTICE);
    }
    println!("schema \"main\" {{");
    println!("}}");
    0
}

fn schema_fmt(args: &[String]) -> i32 {
    let mut paths: Vec<String> = args.iter().filter(|a| !a.starts_with('-')).cloned().collect();
    if paths.is_empty() {
        paths.push(".".to_string());
    }
    for p in paths {
        let path = Path::new(&p);
        if path.is_dir() {
            fmt_dir(path);
        } else {
            fmt_one(path);
        }
    }
    0
}

fn fmt_dir(path: &Path) {
    let Ok(rd) = fs::read_dir(path) else { return; };
    let mut entries: Vec<_> = rd.flatten().map(|e| e.path()).collect();
    entries.sort();
    for ep in entries {
        if ep.is_dir() {
            fmt_dir(&ep);
        } else if ep.extension().and_then(|s| s.to_str()) == Some("hcl") {
            fmt_one(&ep);
        }
    }
}

fn fmt_one(path: &Path) {
    let Ok(orig) = fs::read_to_string(path) else { return; };
    let formatted = format_hcl(&orig);
    if formatted != orig {
        let _ = fs::write(path, formatted);
        println!("{}", path.display());
    }
}

fn format_hcl(input: &str) -> String {
    let mut out = String::new();
    let mut indent = 0usize;
    let mut prev_blank = false;
    for raw in input.lines() {
        let mut line = raw.trim().to_string();
        if line.is_empty() {
            if !prev_blank {
                out.push('\n');
            }
            prev_blank = true;
            continue;
        }
        line = normalize_spaces(&line);
        if line.starts_with('}') && indent > 0 {
            indent -= 1;
        }
        out.push_str(&"  ".repeat(indent));
        out.push_str(&line);
        out.push('\n');
        prev_blank = false;
        if line.ends_with('{') {
            indent += 1;
        }
    }
    while out.ends_with("\n\n") {
        out.pop();
    }
    out
}

fn normalize_spaces(line: &str) -> String {
    let mut s = String::new();
    let mut chars = line.chars().peekable();
    let mut in_str = false;
    let mut last_space = false;
    while let Some(c) = chars.next() {
        if c == '"' {
            in_str = !in_str;
            s.push(c);
            last_space = false;
        } else if !in_str && c.is_whitespace() {
            if !last_space {
                s.push(' ');
                last_space = true;
            }
        } else {
            s.push(c);
            last_space = false;
        }
    }
    let mut s = s.trim().replace(" = ", "=").replace("= ", "=").replace(" =", "=");
    s = s.replace("=", " = ");
    s = s.replace("   ", " ").replace("  ", " ");
    s = s.replace(" {", " {");
    s
}

fn migrate(args: &[String]) -> i32 {
    if args.len() < 2 || !matches!(args[1].as_str(), "new" | "hash" | "validate" | "status" | "apply" | "diff" | "lint" | "import" | "set") {
        print_migrate_help();
        return 0;
    }
    if unknown_flag(args) {
        return 1;
    }
    match args[1].as_str() {
        "new" => migrate_new(&args[2..]),
        "hash" => migrate_hash(&args[2..]),
        "validate" => migrate_validate(&args[2..]),
        "status" | "apply" => {
            let dir = dir_path(args);
            if !dir.exists() {
                eprintln!("Error: sql/migrate: stat {}: no such file or directory", dir.display());
                return 1;
            }
            eprintln!("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
            1
        }
        "diff" => required("to\", \"dev-url"),
        "lint" => required("dev-url"),
        "import" => {
            eprintln!("Error: cannot import a migration directory already in \"atlas\" format");
            1
        }
        "set" => {
            eprintln!("Error: sql/sqlclient: missing driver. See: https://atlasgo.io/url");
            1
        }
        _ => 0,
    }
}

fn migrate_new(args: &[String]) -> i32 {
    let dir = dir_path_from(args);
    let name = args.iter().find(|a| !a.starts_with('-')).cloned().unwrap_or_else(|| "migration".to_string());
    if let Err(e) = fs::create_dir_all(&dir) {
        eprintln!("Error: {}", e);
        return 1;
    }
    let file = dir.join(format!("{}_{}.sql", Local::now().format("%Y%m%d%H%M%S"), sanitize_name(&name)));
    if let Err(e) = fs::write(&file, "") {
        eprintln!("Error: {}", e);
        return 1;
    }
    write_atlas_sum(&dir);
    0
}

fn migrate_hash(args: &[String]) -> i32 {
    let dir = dir_path_from(args);
    if !dir.exists() {
        eprintln!("Error: sql/migrate: stat {}: no such file or directory", dir.display());
        return 1;
    }
    write_atlas_sum(&dir);
    0
}

fn migrate_validate(args: &[String]) -> i32 {
    let dir = dir_path_from(args);
    if !dir.exists() {
        eprintln!("Error: sql/migrate: stat {}: no such file or directory", dir.display());
        return 1;
    }
    0
}

fn write_atlas_sum(dir: &Path) {
    let files = migration_files(dir);
    let mut lines = Vec::new();
    for f in files {
        let data = fs::read(&f).unwrap_or_default();
        let hash = b64_sha256(&data);
        let name = f.file_name().unwrap().to_string_lossy();
        lines.push(format!("{} h1:{}", name, hash));
    }
    let all = lines.join("\n");
    let root = b64_sha256(all.as_bytes());
    let mut content = format!("h1:{}\n", root);
    if !lines.is_empty() {
        content.push_str(&all);
        content.push('\n');
    }
    let _ = fs::write(dir.join("atlas.sum"), content);
}

fn migration_files(dir: &Path) -> Vec<PathBuf> {
    let mut files: Vec<_> = fs::read_dir(dir)
        .ok()
        .into_iter()
        .flat_map(|rd| rd.flatten())
        .map(|e| e.path())
        .filter(|p| p.is_file() && p.file_name().and_then(|s| s.to_str()) != Some("atlas.sum"))
        .collect();
    files.sort();
    files
}

fn b64_sha256(data: &[u8]) -> String {
    base64::engine::general_purpose::STANDARD.encode(Sha256::digest(data))
}

fn dir_path(args: &[String]) -> PathBuf {
    dir_path_from(args)
}

fn dir_path_from(args: &[String]) -> PathBuf {
    let d = value_of(args, "--dir").unwrap_or_else(|| "file://migrations".to_string());
    PathBuf::from(strip_file_url(&d))
}

fn value_of(args: &[String], flag: &str) -> Option<String> {
    let prefix = format!("{}=", flag);
    for i in 0..args.len() {
        if args[i] == flag {
            return args.get(i + 1).cloned();
        }
        if args[i].starts_with(&prefix) {
            return Some(args[i][prefix.len()..].to_string());
        }
    }
    None
}

fn strip_file_url(s: &str) -> String {
    s.strip_prefix("file://").unwrap_or(s).to_string()
}

fn sanitize_name(s: &str) -> String {
    s.chars()
        .map(|c| if c.is_ascii_alphanumeric() { c.to_ascii_lowercase() } else { '_' })
        .collect::<String>()
        .trim_matches('_')
        .to_string()
}
