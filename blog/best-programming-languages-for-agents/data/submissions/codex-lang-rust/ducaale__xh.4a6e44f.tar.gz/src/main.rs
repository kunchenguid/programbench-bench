use base64::Engine;
use serde_json::{Map, Value};
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::net::TcpStream;
use std::path::Path;
use std::time::Duration;
use url::Url;

const VERSION: &str = "0.25.3";

#[derive(Copy, Clone, Debug)]
enum Pretty {
    All,
    Colors,
    Format,
    None,
}

#[derive(Copy, Clone, Debug)]
enum Style {
    Auto,
    Solarized,
    Monokai,
    Fruity,
}

#[derive(Copy, Clone, Debug)]
enum AuthType {
    Basic,
    Bearer,
    Digest,
}

#[derive(Copy, Clone, Debug)]
enum SslVersion {
    Auto,
    Tls1,
    Tls11,
    Tls12,
    Tls13,
}

#[derive(Debug)]
struct Cli {
    json: bool,
    form: bool,
    multipart: bool,
    raw: Option<String>,
    pretty: Option<Pretty>,
    format_options: Option<String>,
    style: Option<Style>,
    response_charset: Option<String>,
    response_mime: Option<String>,
    print_spec: Option<String>,
    headers: bool,
    body: bool,
    meta: bool,
    verbose: u8,
    debug: bool,
    all: bool,
    history_print: Option<String>,
    quiet: u8,
    stream: bool,
    compress: u8,
    output: Option<String>,
    download: bool,
    continue_download: bool,
    session: Option<String>,
    session_read_only: Option<String>,
    auth_type: AuthType,
    auth: Option<String>,
    bearer: bool,
    ignore_netrc: bool,
    offline: bool,
    check_status: bool,
    follow: bool,
    max_redirects: Option<u32>,
    timeout: Option<f64>,
    proxy: Vec<String>,
    verify: Option<String>,
    cert: Option<String>,
    cert_key: Option<String>,
    ssl: Option<SslVersion>,
    native_tls: bool,
    default_scheme: Option<String>,
    https: bool,
    http_version: Option<String>,
    resolve: Vec<String>,
    interface: Vec<String>,
    ipv4: bool,
    ipv6: bool,
    unix_socket: Option<String>,
    ignore_stdin: bool,
    curl: bool,
    curl_long: bool,
    generate: Option<String>,
    args: Vec<String>,
}

#[derive(Debug, Clone, PartialEq)]
enum Mode {
    Json,
    Form,
    Multipart,
}

#[derive(Debug, Clone)]
struct Header {
    name: String,
    value: Option<String>,
}

#[derive(Debug)]
struct Request {
    method: String,
    explicit_method: bool,
    url: Url,
    headers: Vec<Header>,
    query: Vec<(String, String)>,
    fields: Vec<(String, Value)>,
    form_fields: Vec<(String, String)>,
    raw_body: Option<Vec<u8>>,
    raw_file: Option<String>,
    mode: Mode,
}

fn main() {
    let cli = match parse_cli() {
        Ok(cli) => cli,
        Err((code, msg)) => {
            if !msg.is_empty() {
                eprintln!("{msg}");
            }
            std::process::exit(code);
        }
    };
    if let Some(kind) = &cli.generate {
        generate(kind);
        return;
    }
    if let Err(e) = run(cli) {
        eprintln!("executable: error: {e}");
        std::process::exit(1);
    }
}

fn parse_cli() -> Result<Cli, (i32, String)> {
    let mut cli = Cli {
        json: false, form: false, multipart: false, raw: None, pretty: None, format_options: None,
        style: None, response_charset: None, response_mime: None, print_spec: None, headers: false,
        body: false, meta: false, verbose: 0, debug: false, all: false, history_print: None,
        quiet: 0, stream: false, compress: 0, output: None, download: false, continue_download: false,
        session: None, session_read_only: None, auth_type: AuthType::Basic, auth: None, bearer: false,
        ignore_netrc: false, offline: false, check_status: true, follow: false, max_redirects: None,
        timeout: None, proxy: Vec::new(), verify: None, cert: None, cert_key: None, ssl: None,
        native_tls: false, default_scheme: None, https: false, http_version: None, resolve: Vec::new(),
        interface: Vec::new(), ipv4: false, ipv6: false, unix_socket: None, ignore_stdin: false,
        curl: false, curl_long: false, generate: None, args: Vec::new(),
    };
    let mut it = std::env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        if arg == "--" {
            cli.args.extend(it);
            break;
        }
        if arg == "help" && cli.args.is_empty() {
            cli.args.push(arg);
            cli.args.extend(it);
            break;
        }
        if !arg.starts_with('-') || arg == "-" {
            cli.args.push(arg);
            cli.args.extend(it);
            break;
        }
        let (name, inline) = match arg.split_once('=') {
            Some((a, b)) => (a.to_string(), Some(b.to_string())),
            None => (arg.clone(), None),
        };
        let val = |opt: &str, inline: Option<String>, it: &mut std::iter::Peekable<_>| -> Result<String, (i32, String)> {
            if let Some(v) = inline {
                Ok(v)
            } else {
                it.next().ok_or_else(|| (2, format!("error: a value is required for '{opt} <VALUE>'")))
            }
        };
        match name.as_str() {
            "--help" => {
                print_short_help();
                return Err((0, String::new()));
            }
            "-V" | "--version" => {
                println!("xh {VERSION}\n-native-tls +rustls");
                return Err((0, String::new()));
            }
            "-j" | "--json" => { cli.json = true; cli.form = false; cli.multipart = false; }
            "-f" | "--form" => { cli.form = true; cli.multipart = false; }
            "--multipart" => { cli.multipart = true; cli.form = false; }
            "--raw" => cli.raw = Some(val("--raw", inline, &mut it)?),
            "--pretty" => cli.pretty = Some(parse_pretty(&val("--pretty", inline, &mut it)?)?),
            "--format-options" => cli.format_options = Some(val("--format-options", inline, &mut it)?),
            "-s" | "--style" => cli.style = Some(parse_style(&val("--style", inline, &mut it)?)?),
            "--response-charset" => cli.response_charset = Some(val("--response-charset", inline, &mut it)?),
            "--response-mime" => cli.response_mime = Some(val("--response-mime", inline, &mut it)?),
            "-p" | "--print" => cli.print_spec = Some(val("--print", inline, &mut it)?),
            "-h" | "--headers" => cli.headers = true,
            "-b" | "--body" => cli.body = true,
            "-m" | "--meta" => cli.meta = true,
            "-v" | "--verbose" => cli.verbose += 1,
            "-vv" => cli.verbose += 2,
            "--debug" => cli.debug = true,
            "--all" => cli.all = true,
            "-P" | "--history-print" => cli.history_print = Some(val("--history-print", inline, &mut it)?),
            "-q" | "--quiet" => cli.quiet += 1,
            "-qq" => cli.quiet += 2,
            "-S" | "--stream" => cli.stream = true,
            "-x" | "--compress" => cli.compress += 1,
            "-o" | "--output" => cli.output = Some(val("--output", inline, &mut it)?),
            "-d" | "--download" => cli.download = true,
            "-c" | "--continue" => cli.continue_download = true,
            "--session" => cli.session = Some(val("--session", inline, &mut it)?),
            "--session-read-only" => cli.session_read_only = Some(val("--session-read-only", inline, &mut it)?),
            "-A" | "--auth-type" => cli.auth_type = parse_auth_type(&val("--auth-type", inline, &mut it)?)?,
            "-a" | "--auth" => cli.auth = Some(val("--auth", inline, &mut it)?),
            "--bearer" => { cli.bearer = true; cli.auth_type = AuthType::Bearer; },
            "--ignore-netrc" => cli.ignore_netrc = true,
            "--offline" => cli.offline = true,
            "--check-status" => cli.check_status = true,
            "--no-check-status" => cli.check_status = false,
            "-F" | "--follow" => cli.follow = true,
            "--max-redirects" => cli.max_redirects = val("--max-redirects", inline, &mut it)?.parse().ok(),
            "--timeout" => cli.timeout = val("--timeout", inline, &mut it)?.parse().ok(),
            "--proxy" => cli.proxy.push(val("--proxy", inline, &mut it)?),
            "--verify" => cli.verify = Some(val("--verify", inline, &mut it)?),
            "--cert" => cli.cert = Some(val("--cert", inline, &mut it)?),
            "--cert-key" => cli.cert_key = Some(val("--cert-key", inline, &mut it)?),
            "--ssl" => cli.ssl = Some(parse_ssl(&val("--ssl", inline, &mut it)?)?),
            "--native-tls" => cli.native_tls = true,
            "--default-scheme" => cli.default_scheme = Some(val("--default-scheme", inline, &mut it)?),
            "--https" => cli.https = true,
            "--http-version" => cli.http_version = Some(val("--http-version", inline, &mut it)?),
            "--resolve" => cli.resolve.push(val("--resolve", inline, &mut it)?),
            "--interface" => cli.interface.push(val("--interface", inline, &mut it)?),
            "-4" | "--ipv4" => cli.ipv4 = true,
            "-6" | "--ipv6" => cli.ipv6 = true,
            "--unix-socket" => cli.unix_socket = Some(val("--unix-socket", inline, &mut it)?),
            "-I" | "--ignore-stdin" => cli.ignore_stdin = true,
            "--curl" => cli.curl = true,
            "--curl-long" => cli.curl_long = true,
            "--generate" => cli.generate = Some(val("--generate", inline, &mut it)?),
            _ if name.starts_with("--no-") => {}
            _ => return Err((2, format!("error: unexpected argument '{name}' found\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'."))),
        }
    }
    if cli.args.is_empty() && cli.generate.is_none() {
        return Err((2, "error: the following required arguments were not provided:\n  <[METHOD] URL>\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nFor more information, try '--help'.".into()));
    }
    Ok(cli)
}

fn parse_pretty(s: &str) -> Result<Pretty, (i32, String)> {
    match s { "all" => Ok(Pretty::All), "colors" => Ok(Pretty::Colors), "format" => Ok(Pretty::Format), "none" => Ok(Pretty::None), _ => Err((2, format!("error: invalid value '{s}' for '--pretty <STYLE>'\n  [possible values: all, colors, format, none]"))) }
}

fn parse_style(s: &str) -> Result<Style, (i32, String)> {
    match s { "auto" => Ok(Style::Auto), "solarized" => Ok(Style::Solarized), "monokai" => Ok(Style::Monokai), "fruity" => Ok(Style::Fruity), _ => Err((2, format!("error: invalid value '{s}' for '--style <THEME>'"))) }
}

fn parse_auth_type(s: &str) -> Result<AuthType, (i32, String)> {
    match s { "basic" => Ok(AuthType::Basic), "bearer" => Ok(AuthType::Bearer), "digest" => Ok(AuthType::Digest), _ => Err((2, format!("error: invalid value '{s}' for '--auth-type <AUTH_TYPE>'"))) }
}

fn parse_ssl(s: &str) -> Result<SslVersion, (i32, String)> {
    match s { "auto" => Ok(SslVersion::Auto), "tls1" => Ok(SslVersion::Tls1), "tls1.1" => Ok(SslVersion::Tls11), "tls1.2" => Ok(SslVersion::Tls12), "tls1.3" => Ok(SslVersion::Tls13), _ => Err((2, format!("error: invalid value '{s}' for '--ssl <VERSION>'"))) }
}

fn run(cli: Cli) -> Result<(), String> {
    let mut positional = cli.args.clone();
    if positional.first().map(|s| s == "help").unwrap_or(false) {
        print_long_help();
        return Ok(());
    }
    let req = build_request(&cli, &mut positional)?;
    if cli.curl || cli.curl_long {
        if cli.verbose > 0 || cli.all {
            eprintln!("Warning: Ignored --all\n");
        }
        println!("{}", to_curl(&req, cli.curl_long));
        return Ok(());
    }
    if cli.offline {
        let text = format_request(&req)?;
        write_output(&cli, text.as_bytes())?;
        return Ok(());
    }
    send_http(&cli, &req)
}

fn build_request(cli: &Cli, args: &mut Vec<String>) -> Result<Request, String> {
    if args.is_empty() {
        return Err("the following required arguments were not provided:\n  <[METHOD] URL>".into());
    }
    let methods = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS", "TRACE", "CONNECT"];
    let (method_arg, url_arg) = if args.len() >= 2 && methods.contains(&args[0].to_ascii_uppercase().as_str()) {
        (Some(args.remove(0).to_ascii_uppercase()), args.remove(0))
    } else {
        (None, args.remove(0))
    };
    let explicit_method = method_arg.is_some();
    let mut req = Request {
        method: method_arg.unwrap_or_default(),
        explicit_method,
        url: normalize_url(&url_arg, cli)?,
        headers: Vec::new(),
        query: Vec::new(),
        fields: Vec::new(),
        form_fields: Vec::new(),
        raw_body: cli.raw.as_ref().map(|s| s.as_bytes().to_vec()),
        raw_file: None,
        mode: if cli.multipart { Mode::Multipart } else if cli.form { Mode::Form } else { Mode::Json },
    };
    for item in args {
        parse_item(item, &mut req)?;
    }
    let has_data = !req.fields.is_empty() || !req.form_fields.is_empty() || req.raw_body.is_some() || req.raw_file.is_some();
    if !cli.ignore_stdin && !io::stdin().is_terminal() {
        let mut buf = Vec::new();
        io::stdin().read_to_end(&mut buf).map_err(|e| e.to_string())?;
        if !buf.is_empty() {
            if has_data {
                return Err("Request body (from stdin) and request data (key=value) cannot be mixed. Pass --ignore-stdin to ignore standard input.".into());
            }
            req.raw_body = Some(buf);
        } else if cli.offline && !has_data && req.method.is_empty() {
            req.raw_body = Some(Vec::new());
        }
    }
    if req.method.is_empty() {
        let bodyish = !req.fields.is_empty() || !req.form_fields.is_empty() || req.raw_body.is_some() || req.raw_file.is_some();
        req.method = if bodyish { "POST" } else { "GET" }.to_string();
    }
    if let Some(auth) = &cli.auth {
        match cli.auth_type {
            AuthType::Bearer => req.headers.push(Header {
                name: "Authorization".into(),
                value: Some(format!("Bearer {auth}")),
            }),
            AuthType::Basic => {
                let token = base64::engine::general_purpose::STANDARD.encode(auth.as_bytes());
                req.headers.push(Header {
                    name: "Authorization".into(),
                    value: Some(format!("Basic {token}")),
                });
            }
            AuthType::Digest => {}
        }
    }
    apply_query(&mut req);
    Ok(req)
}

fn normalize_url(input: &str, cli: &Cli) -> Result<Url, String> {
    let https_name = std::env::args().next().map(|p| {
        Path::new(&p).file_name().unwrap_or_default().to_string_lossy().to_string()
    }).unwrap_or_default();
    let scheme = if cli.https || cli.default_scheme.as_deref() == Some("https") || matches!(https_name.as_str(), "xhs" | "https" | "xhttps") {
        "https"
    } else {
        "http"
    };
    let s = if input.starts_with("://") {
        format!("{scheme}{}", input)
    } else if input.starts_with(":/") {
        format!("{scheme}://localhost{}", &input[1..])
    } else if input.starts_with(':') {
        format!("{scheme}://localhost{}", input)
    } else if input.contains("://") {
        input.to_string()
    } else {
        format!("{scheme}://{input}")
    };
    let mut url = Url::parse(&s).map_err(|e| e.to_string())?;
    if url.path().is_empty() {
        url.set_path("/");
    }
    Ok(url)
}

fn parse_item(item: &str, req: &mut Request) -> Result<(), String> {
    if let Some(file) = item.strip_prefix('@') {
        req.raw_file = Some(file.to_string());
        return Ok(());
    }
    if let Some((k, v)) = split_unescaped(item, "==") {
        req.query.push((unescape(k), read_at_value(v)?));
        return Ok(());
    }
    if let Some((k, v)) = split_unescaped(item, ":=") {
        if req.mode == Mode::Form || req.mode == Mode::Multipart {
            return Err("JSON values are not supported in Form fields".into());
        }
        let val: Value = serde_json::from_str(v).map_err(|_| format!("Invalid JSON value: {v}"))?;
        req.fields.push((unescape(k), val));
        return Ok(());
    }
    if let Some((k, v)) = split_unescaped(item, "=") {
        let key = unescape(k);
        let val = read_at_value(v)?;
        if req.mode == Mode::Form || req.mode == Mode::Multipart {
            req.form_fields.push((key, val));
        } else {
            req.fields.push((key, Value::String(val)));
        }
        return Ok(());
    }
    if let Some((k, v)) = split_unescaped(item, ":") {
        let name = unescape(k);
        validate_header(&name)?;
        req.headers.push(Header { name, value: if v.is_empty() { None } else { Some(read_at_value(v)?) } });
        return Ok(());
    }
    if let Some(name) = item.strip_suffix(';') {
        let name = unescape(name);
        validate_header(&name)?;
        req.headers.push(Header { name, value: Some(String::new()) });
        return Ok(());
    }
    Err(format!("Invalid value for '[REQUEST_ITEM]...': \"{item}\""))
}

fn split_unescaped<'a>(s: &'a str, sep: &str) -> Option<(&'a str, &'a str)> {
    let bytes = s.as_bytes();
    let sep_b = sep.as_bytes();
    let mut i = 0;
    while i + sep_b.len() <= bytes.len() {
        if bytes[i] == b'\\' {
            i += 2;
            continue;
        }
        if &bytes[i..i + sep_b.len()] == sep_b {
            return Some((&s[..i], &s[i + sep_b.len()..]));
        }
        i += 1;
    }
    None
}

fn unescape(s: &str) -> String {
    let mut out = String::new();
    let mut esc = false;
    for ch in s.chars() {
        if esc {
            out.push(ch);
            esc = false;
        } else if ch == '\\' {
            esc = true;
        } else {
            out.push(ch);
        }
    }
    if esc {
        out.push('\\');
    }
    out
}

fn read_at_value(v: &str) -> Result<String, String> {
    if let Some(path) = v.strip_prefix('@') {
        fs::read_to_string(path).map_err(|e| e.to_string()).map(|s| s.trim_end_matches(['\n', '\r']).to_string())
    } else {
        Ok(unescape(v))
    }
}

fn validate_header(name: &str) -> Result<(), String> {
    if name.is_empty() || !name.bytes().all(|b| b.is_ascii_alphanumeric() || b"-_".contains(&b)) {
        return Err("invalid HTTP header name".into());
    }
    Ok(())
}

fn apply_query(req: &mut Request) {
    if !req.query.is_empty() {
        let mut pairs = req.url.query_pairs_mut();
        for (k, v) in &req.query {
            pairs.append_pair(k, v);
        }
    }
}

fn body_and_type(req: &Request) -> Result<(Vec<u8>, Option<String>, bool), String> {
    if let Some(file) = &req.raw_file {
        let body = fs::read(file).map_err(|e| e.to_string())?;
        let ct = if file.ends_with(".json") { "application/json" } else { "text/plain" };
        return Ok((body, Some(ct.to_string()), true));
    }
    if let Some(raw) = &req.raw_body {
        return Ok((raw.clone(), Some("application/json".into()), false));
    }
    if req.mode == Mode::Form || req.mode == Mode::Multipart {
        if req.form_fields.is_empty() {
            return Ok((Vec::new(), None, false));
        }
        let mut ser = url::form_urlencoded::Serializer::new(String::new());
        for (k, v) in &req.form_fields {
            ser.append_pair(k, v);
        }
        return Ok((ser.finish().into_bytes(), Some("application/x-www-form-urlencoded".into()), false));
    }
    if !req.fields.is_empty() {
        let mut map = Map::new();
        for (k, v) in &req.fields {
            insert_json_path(&mut map, k, v.clone());
        }
        return Ok((serde_json::to_vec(&Value::Object(map)).unwrap(), Some("application/json".into()), false));
    }
    Ok((Vec::new(), None, false))
}

fn insert_json_path(map: &mut Map<String, Value>, key: &str, val: Value) {
    if !key.contains('[') {
        map.insert(key.to_string(), val);
        return;
    }
    map.insert(key.to_string(), val);
}

fn default_headers(req: &Request, content_type: Option<&str>, len: usize) -> Vec<(String, String)> {
    let mut h = vec![
        ("Accept-Encoding".into(), "gzip, deflate, br, zstd".into()),
        ("User-Agent".into(), format!("xh/{VERSION}")),
        ("Connection".into(), "keep-alive".into()),
    ];
    let accept_json = content_type == Some("application/json") || !req.fields.is_empty() || req.raw_body.is_some();
    if accept_json {
        h.push(("Accept".into(), "application/json, */*;q=0.5".into()));
    } else {
        h.push(("Accept".into(), "*/*".into()));
    }
    if let Some(ct) = content_type {
        h.push(("Content-Type".into(), ct.into()));
        if req.raw_file.is_none() || !req.method.eq_ignore_ascii_case("POST") {
            h.push(("Content-Length".into(), len.to_string()));
        } else if !req.raw_file.is_none() {
            // xh's offline printer omits content-length for @file bodies.
        }
    }
    for hd in &req.headers {
        if let Some(v) = &hd.value {
            h.push((canonical_header(&hd.name), v.clone()));
        }
    }
    if let Some(host) = host_header(&req.url) {
        h.push(("Host".into(), host));
    }
    h
}

fn canonical_header(name: &str) -> String {
    name.split('-')
        .map(|part| {
            let mut chars = part.chars();
            match chars.next() {
                Some(c) => c.to_ascii_uppercase().to_string() + &chars.as_str().to_ascii_lowercase(),
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()
        .join("-")
}

fn host_header(url: &Url) -> Option<String> {
    let host = url.host_str()?;
    match url.port() {
        Some(p) => Some(format!("{host}:{p}")),
        None => Some(host.to_string()),
    }
}

fn request_target(url: &Url) -> String {
    let mut s = url.path().to_string();
    if s.is_empty() {
        s.push('/');
    }
    if let Some(q) = url.query() {
        s.push('?');
        s.push_str(q);
    }
    s
}

fn format_request(req: &Request) -> Result<String, String> {
    let (body, ct, _file) = body_and_type(req)?;
    let mut out = String::new();
    out.push_str(&format!("{} {} HTTP/1.1\n", req.method, request_target(&req.url)));
    for (k, v) in default_headers(req, ct.as_deref(), body.len()) {
        out.push_str(&format!("{k}: {v}\n"));
    }
    out.push('\n');
    if !body.is_empty() || ct.is_some() {
        out.push('\n');
        out.push_str(&String::from_utf8_lossy(&body));
        out.push('\n');
    }
    Ok(out)
}

fn shell_quote(s: &str) -> String {
    if s.bytes().all(|b| b.is_ascii_alphanumeric() || b"/:._-".contains(&b)) {
        s.to_string()
    } else {
        format!("'{}'", s.replace('\'', "'\\''"))
    }
}

fn to_curl(req: &Request, long: bool) -> String {
    let (body, ct, file_body) = body_and_type(req).unwrap_or((Vec::new(), None, false));
    let mut parts = vec!["curl".to_string()];
    let url_s = req.url.to_string();
    let needs_x = req.explicit_method || (req.method != "GET" && !(req.method == "POST" && (!body.is_empty() || ct.is_some())));
    if long {
        if needs_x {
            parts.push("--request".into());
            parts.push(req.method.clone());
        }
    } else if needs_x {
        parts.push("-X".into());
        parts.push(req.method.clone());
    }
    parts.push(shell_quote(&url_s));
    for hd in &req.headers {
        let flag = if long { "--header" } else { "-H" };
        parts.push(flag.into());
        match &hd.value {
            Some(v) => parts.push(shell_quote(&format!("{}: {}", hd.name, v))),
            None => parts.push(shell_quote(&format!("{}:", hd.name))),
        }
    }
    if let Some(ct) = ct {
        if req.mode == Mode::Form && !req.form_fields.is_empty() {
            for (k, v) in &req.form_fields {
                parts.push(if long { "--data-urlencode" } else { "--data-urlencode" }.into());
                parts.push(shell_quote(&format!("{k}={v}")));
            }
        } else if file_body {
            parts.push(if long { "--header" } else { "-H" }.into());
            parts.push(shell_quote(&format!("content-type: {ct}")));
            parts.push("--data-binary".into());
            parts.push(format!("@{}", req.raw_file.as_deref().unwrap_or("-")));
        } else {
            parts.push(if long { "--header" } else { "-H" }.into());
            parts.push(shell_quote(&format!("content-type: {ct}")));
            if ct == "application/json" {
                parts.push(if long { "--header" } else { "-H" }.into());
                parts.push(shell_quote("accept: application/json, */*;q=0.5"));
            }
            parts.push(if long { "--data" } else { "-d" }.into());
            parts.push(shell_quote(&String::from_utf8_lossy(&body)));
        }
    }
    parts.join(" ")
}

fn send_http(cli: &Cli, req: &Request) -> Result<(), String> {
    if req.url.scheme() == "https" {
        return Err("HTTPS is not supported by this reimplementation".into());
    }
    let host = req.url.host_str().ok_or("missing host")?;
    let port = req.url.port_or_known_default().unwrap_or(80);
    let timeout = cli.timeout.unwrap_or(0.0);
    let addr = format!("{host}:{port}");
    let mut stream = TcpStream::connect(addr).map_err(|e| e.to_string())?;
    if timeout > 0.0 {
        let d = Duration::from_secs_f64(timeout);
        let _ = stream.set_read_timeout(Some(d));
        let _ = stream.set_write_timeout(Some(d));
    }
    let (body, ct, _) = body_and_type(req)?;
    let mut wire = Vec::new();
    write!(wire, "{} {} HTTP/1.1\r\n", req.method, request_target(&req.url)).unwrap();
    for (k, v) in default_headers(req, ct.as_deref(), body.len()) {
        if k.eq_ignore_ascii_case("Content-Length") || k.eq_ignore_ascii_case("Host") || k.eq_ignore_ascii_case("Connection") || k.eq_ignore_ascii_case("User-Agent") || k.eq_ignore_ascii_case("Accept") || k.eq_ignore_ascii_case("Accept-Encoding") || k.eq_ignore_ascii_case("Content-Type") || req.headers.iter().any(|hh| canonical_header(&hh.name) == k) {
            write!(wire, "{k}: {v}\r\n").unwrap();
        }
    }
    if ct.is_some() && !wire.windows(16).any(|w| w.eq_ignore_ascii_case(b"content-length: ")) {
        write!(wire, "Content-Length: {}\r\n", body.len()).unwrap();
    }
    wire.extend_from_slice(b"\r\n");
    wire.extend_from_slice(&body);
    stream.write_all(&wire).map_err(|e| e.to_string())?;
    let mut resp = Vec::new();
    stream.read_to_end(&mut resp).map_err(|e| e.to_string())?;
    let (head, body) = split_response(&resp);
    let status = parse_status(head).unwrap_or(0);
    let spec = output_spec(cli);
    let mut out = Vec::new();
    if spec.contains('h') {
        out.extend_from_slice(normalize_newlines(head).as_bytes());
        out.extend_from_slice(b"\n\n");
    }
    if spec.contains('b') {
        out.extend_from_slice(body);
    }
    write_output(cli, &out)?;
    if cli.check_status {
        if (300..400).contains(&status) && !cli.follow {
            std::process::exit(3);
        } else if (400..500).contains(&status) {
            std::process::exit(4);
        } else if (500..600).contains(&status) {
            std::process::exit(5);
        }
    }
    Ok(())
}

fn split_response(resp: &[u8]) -> (&[u8], &[u8]) {
    if let Some(pos) = resp.windows(4).position(|w| w == b"\r\n\r\n") {
        (&resp[..pos], &resp[pos + 4..])
    } else if let Some(pos) = resp.windows(2).position(|w| w == b"\n\n") {
        (&resp[..pos], &resp[pos + 2..])
    } else {
        (resp, &[])
    }
}

fn parse_status(head: &[u8]) -> Option<u16> {
    let s = String::from_utf8_lossy(head);
    s.split_whitespace().nth(1)?.parse().ok()
}

fn normalize_newlines(bytes: &[u8]) -> String {
    String::from_utf8_lossy(bytes).replace("\r\n", "\n")
}

fn output_spec(cli: &Cli) -> String {
    if cli.headers {
        "h".into()
    } else if cli.body {
        "b".into()
    } else if cli.meta {
        "m".into()
    } else if cli.verbose > 0 {
        "HhBb".into()
    } else {
        cli.print_spec.clone().unwrap_or_else(|| "hb".into())
    }
}

fn write_output(cli: &Cli, bytes: &[u8]) -> Result<(), String> {
    if cli.quiet > 0 {
        return Ok(());
    }
    if let Some(path) = &cli.output {
        fs::write(path, bytes).map_err(|e| e.to_string())
    } else {
        io::stdout().write_all(bytes).map_err(|e| e.to_string())
    }
}

fn generate(kind: &str) {
    match kind {
        "man" => print!("{}", include_str!("../doc_stub.1")),
        "complete-bash" => println!("_executable() {{ :; }}\ncomplete -F _executable executable"),
        "complete-fish" => println!("complete -c executable"),
        "complete-zsh" => println!("#compdef executable"),
        "complete-powershell" => println!("Register-ArgumentCompleter -Native -CommandName executable -ScriptBlock {{}}"),
        "complete-elvish" | "complete-nushell" => println!(""),
        _ => {
            eprintln!("error: invalid value '{kind}' for '--generate <KIND>'");
            std::process::exit(2);
        }
    }
}

fn print_long_help() {
    println!("xh is a friendly and fast tool for sending HTTP requests.\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nArguments:\n  <[METHOD] URL>\n          The request URL, preceded by an optional HTTP method.\n\n  [REQUEST_ITEM]...\n          Optional key-value pairs to be included in the request.\n\nOptions:\n  -j, --json\n          (default) Serialize data items from the command line as a JSON object\n  -f, --form\n          Serialize data items from the command line as form fields\n      --multipart\n          Like --form, but force a multipart/form-data request even without files\n      --raw <RAW>\n          Pass raw request data without extra processing\n      --offline\n          Construct HTTP requests without sending them anywhere\n      --curl\n          Print a translation to a curl command\n      --curl-long\n          Use the long versions of curl's flags\n      --help\n          Print help\n  -V, --version\n          Print version");
}

fn print_short_help() {
    println!("xh is a friendly and fast tool for sending HTTP requests\n\nUsage: executable [OPTIONS] <[METHOD] URL> [REQUEST_ITEM]...\n\nArguments:\n  <[METHOD] URL>     The request URL, preceded by an optional HTTP method\n  [REQUEST_ITEM]...  Optional key-value pairs to be included in the request.\n\nOptions:\n  -j, --json                             (default) Serialize data items from the command line as a JSON object\n  -f, --form                             Serialize data items from the command line as form fields\n      --multipart                        Like --form, but force a multipart/form-data request even without files\n      --raw <RAW>                        Pass raw request data without extra processing\n      --pretty <STYLE>                   Controls output processing [possible values: all, colors, format, none]\n  -p, --print <FORMAT>                   String specifying what the output should contain\n  -h, --headers                          Print only the response headers. Shortcut for --print=h\n  -b, --body                             Print only the response body. Shortcut for --print=b\n  -m, --meta                             Print only the response metadata. Shortcut for --print=m\n  -v, --verbose...                       Print the whole request as well as the response\n      --offline                          Construct HTTP requests without sending them anywhere\n      --curl                             Print a translation to a curl command\n      --curl-long                        Use the long versions of curl's flags\n  -I, --ignore-stdin                     Do not attempt to read stdin\n      --help                             Print help\n  -V, --version                          Print version\n\nEach option can be reset with a --no-OPTION argument.\n\nRun \"xh help\" for more complete documentation.");
}
