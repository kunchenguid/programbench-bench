use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "Cppcheck 2.19 dev";
const HELP: &str = r#"Cppcheck - A tool for static C/C++ code analysis

Syntax:
    cppcheck [OPTIONS] [files or paths]

If a directory is given instead of a filename, *.cpp, *.cxx, *.cc, *.c++, *.c, *.ipp,
*.ixx, *.tpp, and *.txx files are checked recursively from the given directory.

Options:
    --addon=<addon>      Execute addon. i.e. --addon=misra.
    --check-config       Check cppcheck configuration. The normal code analysis is disabled by this flag.
    --disable=<severity> Disable checks with the given severity.
    -D<ID>               Define preprocessor symbol.
    -E                   Print preprocessor output on stdout and don't do any further processing.
    --enable=<severity>  Enable additional checks grouped by severity.
                         The available severities are: warning, performance, portability,
                         information, style, unusedFunction, missingInclude, all.
    --error-exitcode=<n> If errors are found, integer [n] is returned instead of the default '0'.
    --errorlist          Print a list of all the error messages in XML format.
    -h, --help           Print this help.
    -I <dir>             Give path to search for include files.
    --inline-suppr       Enable inline suppressions.
    -j <jobs>            Start [jobs] threads to do the checking simultaneously.
    -q, --quiet          Do not show progress reports.
    --std=<id>           Set standard.
    --suppress=<spec>    Suppress warnings that match <spec>.
    --template='<text>'  Format the error messages.
    -U<ID>               Undefine preprocessor symbol.
    -v, --verbose        Output more detailed error information.
    --version            Print out version number.
    --xml                Write results in xml format to error stream (stderr).

Example usage:
  cppcheck file.c
  cppcheck --enable=all --inconclusive test.cpp
"#;

#[derive(Clone, Debug)]
struct Options {
    quiet: bool,
    xml: bool,
    preprocess: bool,
    check_config: bool,
    inline_suppr: bool,
    error_exitcode: i32,
    template: Option<String>,
    enabled: HashSet<String>,
    disabled: HashSet<String>,
    suppress: Vec<String>,
    inputs: Vec<String>,
}

#[derive(Clone, Debug)]
struct Diagnostic {
    file: String,
    line: usize,
    column: usize,
    severity: &'static str,
    id: &'static str,
    message: String,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    match parse_args(&args) {
        Ok(ParseResult::Exit(code)) => process::exit(code),
        Ok(ParseResult::Run(opt)) => process::exit(run(opt)),
        Err(msg) => {
            println!("cppcheck: error: {}", msg);
            process::exit(1);
        }
    }
}

enum ParseResult {
    Exit(i32),
    Run(Options),
}

fn parse_args(args: &[String]) -> Result<ParseResult, String> {
    let mut opt = Options {
        quiet: false,
        xml: false,
        preprocess: false,
        check_config: false,
        inline_suppr: false,
        error_exitcode: 0,
        template: None,
        enabled: HashSet::new(),
        disabled: HashSet::new(),
        suppress: Vec::new(),
        inputs: Vec::new(),
    };
    if args.is_empty() {
        print!("{}", HELP);
        return Ok(ParseResult::Exit(0));
    }
    let known_enable = [
        "warning",
        "performance",
        "portability",
        "information",
        "style",
        "unusedFunction",
        "missingInclude",
        "all",
    ];
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-h" | "--help" => {
                print!("{}", HELP);
                return Ok(ParseResult::Exit(0));
            }
            "--version" => {
                println!("{}", VERSION);
                return Ok(ParseResult::Exit(0));
            }
            "--errorlist" => {
                print_errorlist();
                return Ok(ParseResult::Exit(0));
            }
            "-q" | "--quiet" => opt.quiet = true,
            "--xml" => opt.xml = true,
            "-E" => opt.preprocess = true,
            "--check-config" => opt.check_config = true,
            "--inline-suppr" => opt.inline_suppr = true,
            "--inconclusive" | "--force" | "-f" | "--check-library" | "--safety"
            | "--report-progress" | "-v" | "--verbose" | "--dump" => {}
            "-I"
            | "-j"
            | "--addon"
            | "--addon-python"
            | "--cppcheck-build-dir"
            | "--checkers-report"
            | "--clang"
            | "--config-exclude"
            | "--config-excludes-file"
            | "--file-filter"
            | "--file-list"
            | "--includes-file"
            | "--include"
            | "-i"
            | "--library"
            | "--max-configs"
            | "--output-file"
            | "--platform"
            | "--project"
            | "--project-configuration"
            | "--relative-paths"
            | "-rp"
            | "--report-type"
            | "--rule"
            | "--rule-file"
            | "--showtime"
            | "--std"
            | "--suppressions-list"
            | "--suppress-xml"
            | "--template"
            | "--template-location"
            | "--xml-version" => {
                i += 1;
            }
            _ if a.starts_with("--enable=") => {
                for p in a[9..].split(',').filter(|s| !s.is_empty()) {
                    if !known_enable.contains(&p) {
                        return Err(format!("--enable parameter with the unknown name '{}'", p));
                    }
                    opt.enabled.insert(p.to_string());
                }
            }
            _ if a.starts_with("--disable=") => {
                for p in a[10..].split(',') {
                    opt.disabled.insert(p.to_string());
                }
            }
            _ if a.starts_with("--error-exitcode=") => {
                opt.error_exitcode = a[17..].parse().unwrap_or(1)
            }
            _ if a.starts_with("--template=") => {
                opt.template = Some(trim_quotes(&a[11..]).to_string())
            }
            _ if a.starts_with("--suppress=") => opt.suppress.push(a[11..].to_string()),
            _ if a.starts_with("--std=")
                || a.starts_with("-D")
                || a.starts_with("-U")
                || a.starts_with("-I")
                || a.starts_with("-j")
                || a.starts_with("--addon=")
                || a.starts_with("--addon-python=")
                || a.starts_with("--cppcheck-build-dir=")
                || a.starts_with("--file-filter=")
                || a.starts_with("--library=")
                || a.starts_with("--output-file=")
                || a.starts_with("--platform=")
                || a.starts_with("--project=")
                || a.starts_with("--report-type=")
                || a.starts_with("--showtime=")
                || a.starts_with("--xml-version=")
                || a.starts_with("--template-location=") => {}
            _ if a.starts_with('-') => {
                return Err(format!("unrecognized command line option: \"{}\".", a))
            }
            _ => opt.inputs.push(a.clone()),
        }
        i += 1;
    }
    Ok(ParseResult::Run(opt))
}

fn trim_quotes(s: &str) -> &str {
    s.trim_matches('\'').trim_matches('"')
}

fn run(opt: Options) -> i32 {
    let files = collect_inputs(&opt.inputs);
    if files.is_empty() {
        eprintln!("cppcheck: error: could not find or open any of the paths given.");
        return 1;
    }
    if opt.check_config {
        if !opt.quiet {
            for f in &files {
                println!("Checking {}...", display_path(f));
            }
        }
        return 0;
    }
    if opt.preprocess {
        for f in files {
            match fs::read_to_string(&f) {
                Ok(s) => print!("{}", s),
                Err(e) => eprintln!("cppcheck: error: {}: {}", display_path(&f), e),
            }
        }
        return 0;
    }
    let mut all = Vec::new();
    let total = files.len();
    for (idx, f) in files.iter().enumerate() {
        if !opt.quiet {
            println!("Checking {}...", display_path(f));
        }
        match fs::read_to_string(f) {
            Ok(src) => all.extend(analyze_file(&display_path(f), &src, &opt)),
            Err(e) => eprintln!("cppcheck: error: {}: {}", display_path(f), e),
        }
        if !opt.quiet && total > 1 {
            println!(
                "{}/{} files checked {}% done",
                idx + 1,
                total,
                ((idx + 1) * 100) / total
            );
        }
    }
    all.retain(|d| !is_suppressed(d, &opt));
    if opt.xml {
        emit_xml(&all);
    } else {
        for d in &all {
            println!("{}", format_diag(d, opt.template.as_deref()));
        }
    }
    if all.iter().any(|d| d.severity == "error") && opt.error_exitcode != 0 {
        opt.error_exitcode
    } else {
        0
    }
}

fn collect_inputs(inputs: &[String]) -> Vec<PathBuf> {
    let mut out = Vec::new();
    if inputs.is_empty() {
        return out;
    }
    for inp in inputs {
        let p = PathBuf::from(inp);
        if p.is_file() {
            out.push(p);
        } else if p.is_dir() {
            collect_dir(&p, &mut out);
        }
    }
    out.sort_by(|a, b| display_path(a).cmp(&display_path(b)));
    out
}

fn collect_dir(dir: &Path, out: &mut Vec<PathBuf>) {
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    let mut paths: Vec<PathBuf> = entries.filter_map(|e| e.ok().map(|x| x.path())).collect();
    paths.sort();
    for p in paths {
        if p.is_dir() {
            collect_dir(&p, out);
        } else if is_source(&p) {
            out.push(p);
        }
    }
}

fn is_source(p: &Path) -> bool {
    matches!(
        p.extension().and_then(|s| s.to_str()).unwrap_or(""),
        "c" | "cc" | "cpp" | "cxx" | "c++" | "ipp" | "ixx" | "tpp" | "txx" | "h" | "hpp"
    )
}

fn display_path(p: &Path) -> String {
    p.to_string_lossy().to_string()
}

fn analyze_file(file: &str, src: &str, opt: &Options) -> Vec<Diagnostic> {
    let clean = strip_comments(src);
    let mut diags = Vec::new();
    let mut arrays: HashMap<String, usize> = HashMap::new();
    let mut initialized: HashSet<String> = HashSet::new();
    let mut declared: HashMap<String, usize> = HashMap::new();
    let mut mallocs: HashMap<String, usize> = HashMap::new();
    let mut frees: HashSet<String> = HashSet::new();
    let mut functions: HashSet<String> = HashSet::new();
    let mut calls: HashSet<String> = HashSet::new();

    for (idx, line) in clean.lines().enumerate() {
        let n = idx + 1;
        let t = line.trim();
        if t.is_empty() || t.starts_with('#') {
            continue;
        }
        if opt.inline_suppr && line.contains("cppcheck-suppress") {
            continue;
        }

        let is_array_decl = if let Some((name, size)) = parse_array_decl(t) {
            arrays.insert(name, size);
            true
        } else {
            false
        };
        if !is_array_decl {
            for (name, index, col) in find_array_accesses(line) {
                if let Some(size) = arrays.get(&name) {
                    if index >= *size {
                        diags.push(Diagnostic {
                            file: file.to_string(),
                            line: n,
                            column: col,
                            severity: "error",
                            id: "arrayIndexOutOfBounds",
                            message: format!(
                                "Array '{}[{}]' index {} out of bounds",
                                name, size, index
                            ),
                        });
                    }
                }
            }
        }
        if contains_div_zero(t) {
            diags.push(Diagnostic {
                file: file.to_string(),
                line: n,
                column: 1,
                severity: "error",
                id: "zerodiv",
                message: "Division by zero.".to_string(),
            });
        }
        if is_null_deref(t) {
            diags.push(Diagnostic {
                file: file.to_string(),
                line: n,
                column: 1,
                severity: "error",
                id: "nullPointer",
                message: "Null pointer dereference".to_string(),
            });
        }
        if let Some(v) = assigned_malloc(t) {
            mallocs.insert(v, n);
        }
        if let Some(v) = freed_var(t) {
            frees.insert(v);
        }
        let is_var_decl = if let Some((typ, name, has_init)) = parse_var_decl(t) {
            if !["void", "return", "if", "for", "while", "switch"].contains(&typ.as_str()) {
                declared.entry(name.clone()).or_insert(n);
                if has_init {
                    initialized.insert(name);
                }
            }
            true
        } else {
            false
        };
        if let Some(name) = assigned_var(t) {
            initialized.insert(name);
        }
        if !is_var_decl {
            for name in used_vars(t) {
                if declared.contains_key(&name)
                    && !initialized.contains(&name)
                    && !is_left_side_assignment(t, &name)
                {
                    diags.push(Diagnostic {
                        file: file.to_string(),
                        line: n,
                        column: 1,
                        severity: "error",
                        id: "uninitvar",
                        message: format!("Uninitialized variable: {}", name),
                    });
                    initialized.insert(name);
                }
            }
        }
        if let Some(f) = function_def_name(t) {
            functions.insert(f);
        }
        for c in call_names(t) {
            calls.insert(c);
        }
    }
    if opt.enabled.contains("all")
        || opt.enabled.contains("style")
        || opt.enabled.contains("unusedFunction")
    {
        for f in functions {
            if f != "main" && !calls.contains(&f) {
                diags.push(Diagnostic {
                    file: file.to_string(),
                    line: 1,
                    column: 1,
                    severity: "style",
                    id: "unusedFunction",
                    message: format!("The function '{}' is never used.", f),
                });
            }
        }
    }
    for (v, line) in mallocs {
        if !frees.contains(&v) {
            diags.push(Diagnostic {
                file: file.to_string(),
                line,
                column: 1,
                severity: "error",
                id: "memleak",
                message: format!("Memory leak: {}", v),
            });
        }
    }
    diags
}

fn strip_comments(src: &str) -> String {
    let mut out = String::new();
    let mut chars = src.chars().peekable();
    let mut block = false;
    while let Some(c) = chars.next() {
        if block {
            if c == '*' && chars.peek() == Some(&'/') {
                chars.next();
                block = false;
            } else if c == '\n' {
                out.push('\n');
            }
        } else if c == '/' && chars.peek() == Some(&'*') {
            chars.next();
            block = true;
        } else if c == '/' && chars.peek() == Some(&'/') {
            for x in chars.by_ref() {
                if x == '\n' {
                    out.push('\n');
                    break;
                }
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn parse_array_decl(t: &str) -> Option<(String, usize)> {
    let lb = t.find('[')?;
    let rb = t[lb + 1..].find(']')? + lb + 1;
    let size = t[lb + 1..rb].trim().parse().ok()?;
    let before = t[..lb].trim_end();
    let mut words = before.split_whitespace().collect::<Vec<_>>();
    if words.len() < 2 {
        return None;
    }
    let types = [
        "int", "char", "short", "long", "float", "double", "bool", "size_t", "unsigned", "signed",
    ];
    if !words.iter().any(|w| types.contains(&w.trim_matches('*'))) {
        return None;
    }
    let name = words.pop()?.trim_matches('*').to_string();
    if name.chars().all(|c| c.is_alphanumeric() || c == '_') {
        Some((name, size))
    } else {
        None
    }
}

fn find_array_accesses(line: &str) -> Vec<(String, usize, usize)> {
    let bytes = line.as_bytes();
    let mut res = Vec::new();
    for i in 0..bytes.len() {
        if bytes[i] == b'[' {
            let mut j = i + 1;
            while j < bytes.len() && bytes[j].is_ascii_whitespace() {
                j += 1;
            }
            let start = j;
            while j < bytes.len() && bytes[j].is_ascii_digit() {
                j += 1;
            }
            if start == j {
                continue;
            }
            let idx: usize = line[start..j].parse().unwrap_or(0);
            while j < bytes.len() && bytes[j].is_ascii_whitespace() {
                j += 1;
            }
            if j >= bytes.len() || bytes[j] != b']' {
                continue;
            }
            let mut k = i;
            while k > 0 && bytes[k - 1].is_ascii_whitespace() {
                k -= 1;
            }
            let end = k;
            while k > 0 && (bytes[k - 1].is_ascii_alphanumeric() || bytes[k - 1] == b'_') {
                k -= 1;
            }
            if k < end {
                res.push((line[k..end].to_string(), idx, k + 1));
            }
        }
    }
    res
}

fn contains_div_zero(t: &str) -> bool {
    t.contains("/ 0") || t.contains("/0") || t.contains("% 0") || t.contains("%0")
}
fn is_null_deref(t: &str) -> bool {
    t.contains("*(0)") || t.contains("*NULL") || t.contains("= NULL;") && t.contains("*")
}

fn assigned_malloc(t: &str) -> Option<String> {
    if !t.contains("malloc(") && !t.contains("calloc(") && !t.contains("realloc(") {
        return None;
    }
    let eq = t.find('=')?;
    Some(
        t[..eq]
            .split_whitespace()
            .last()?
            .trim_matches('*')
            .to_string(),
    )
}
fn freed_var(t: &str) -> Option<String> {
    let s = t.find("free(")? + 5;
    let e = t[s..].find(')')? + s;
    Some(t[s..e].trim().to_string())
}

fn parse_var_decl(t: &str) -> Option<(String, String, bool)> {
    let first = t.split_whitespace().next()?.trim().to_string();
    let types = [
        "int", "char", "short", "long", "float", "double", "bool", "size_t", "unsigned", "signed",
    ];
    if !types.contains(&first.as_str()) {
        return None;
    }
    if t.contains('(') && t.contains(')') && t.contains('{') {
        return None;
    }
    let rest = t[first.len()..].trim();
    let name_raw = rest
        .split(|c: char| c == '=' || c == ';' || c == ',' || c == '[')
        .next()?
        .trim();
    let name = name_raw
        .trim_start_matches('*')
        .trim_start_matches('&')
        .trim()
        .to_string();
    if name.is_empty() {
        return None;
    }
    Some((first, name, t.contains('=')))
}

fn assigned_var(t: &str) -> Option<String> {
    if t.contains("==") || t.contains("<=") || t.contains(">=") || t.contains("!=") {
        return None;
    }
    let eq = t.find('=')?;
    let left = t[..eq].trim();
    let name = left
        .split(|c: char| !c.is_alphanumeric() && c != '_')
        .filter(|s| !s.is_empty())
        .last()?;
    Some(name.to_string())
}

fn used_vars(t: &str) -> Vec<String> {
    let keywords: HashSet<&str> = [
        "int", "char", "short", "long", "float", "double", "bool", "return", "if", "for", "while",
        "switch", "sizeof", "NULL", "true", "false",
    ]
    .into_iter()
    .collect();
    t.split(|c: char| !c.is_alphanumeric() && c != '_')
        .filter(|s| {
            !s.is_empty() && !s.chars().next().unwrap().is_ascii_digit() && !keywords.contains(*s)
        })
        .map(|s| s.to_string())
        .collect()
}
fn is_left_side_assignment(t: &str, name: &str) -> bool {
    t.find('=')
        .map(|eq| t[..eq].contains(name))
        .unwrap_or(false)
}

fn function_def_name(t: &str) -> Option<String> {
    if !t.contains('(') || !t.contains(')') || !t.contains('{') {
        return None;
    }
    let before = t.split('(').next()?.trim();
    Some(
        before
            .split_whitespace()
            .last()?
            .trim_matches('*')
            .to_string(),
    )
}
fn call_names(t: &str) -> Vec<String> {
    let mut res = Vec::new();
    for part in t.split('(').take_while(|_| true) {
        let name = part
            .split(|c: char| !c.is_alphanumeric() && c != '_')
            .filter(|s| !s.is_empty())
            .last();
        if let Some(n) = name {
            if !["if", "for", "while", "switch", "return", "sizeof"].contains(&n) {
                res.push(n.to_string());
            }
        }
    }
    res
}

fn is_suppressed(d: &Diagnostic, opt: &Options) -> bool {
    opt.disabled.contains(d.severity)
        || opt.disabled.contains(d.id)
        || opt
            .suppress
            .iter()
            .any(|s| s == d.id || s == "*" || s.starts_with(&format!("{}:", d.id)))
}

fn format_diag(d: &Diagnostic, template: Option<&str>) -> String {
    if let Some(t) = template {
        if t == "gcc" {
            return format!(
                "{}:{}:{}: {}: {} [{}]",
                d.file, d.line, d.column, d.severity, d.message, d.id
            );
        }
        if !["cppcheck1", "vs", "edit"].contains(&t) {
            return t
                .replace("{file}", &d.file)
                .replace("{line}", &d.line.to_string())
                .replace("{column}", &d.column.to_string())
                .replace("{severity}", d.severity)
                .replace("{message}", &d.message)
                .replace("{id}", d.id)
                .replace("\\n", "\n")
                .replace("\\t", "\t");
        }
    }
    format!("[{}:{}]: ({}) {}", d.file, d.line, d.severity, d.message)
}

fn emit_xml(diags: &[Diagnostic]) {
    eprintln!("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    eprintln!("<results version=\"2\">");
    eprintln!("    <cppcheck version=\"2.19 dev\"/>");
    eprintln!("    <errors>");
    for d in diags {
        eprintln!(
            "        <error id=\"{}\" severity=\"{}\" msg=\"{}\" verbose=\"{}\">",
            d.id,
            d.severity,
            xml_escape(&d.message),
            xml_escape(&d.message)
        );
        eprintln!(
            "            <location file=\"{}\" line=\"{}\" column=\"{}\"/>",
            xml_escape(&d.file),
            d.line,
            d.column
        );
        eprintln!("        </error>");
    }
    eprintln!("    </errors>");
    eprintln!("</results>");
}

fn print_errorlist() {
    println!("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    println!("<results version=\"2\">");
    println!("    <cppcheck version=\"2.19 dev\"/>");
    println!("    <errors>");
    for (id, sev, msg) in [
        (
            "arrayIndexOutOfBounds",
            "error",
            "Array 'arr[16]' index 16 out of bounds",
        ),
        ("zerodiv", "error", "Division by zero."),
        ("nullPointer", "error", "Null pointer dereference"),
        ("uninitvar", "error", "Uninitialized variable"),
        ("memleak", "error", "Memory leak"),
        ("unusedFunction", "style", "The function is never used."),
    ] {
        println!(
            "        <error id=\"{}\" severity=\"{}\" msg=\"{}\" verbose=\"{}\"/>",
            id,
            sev,
            xml_escape(msg),
            xml_escape(msg)
        );
    }
    println!("    </errors>");
    println!("</results>");
}
fn xml_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}
