use anyhow::{anyhow, bail, Context, Result};
use base64::Engine as Base64Engine;
use regex::Regex;
use serde_json::{json, Map, Number, Value};
use sha2::{Digest, Sha256, Sha512};
use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

#[derive(Clone, Debug)]
enum Node {
    Text(String),
    Expr(String),
    If {
        expr: String,
        yes: Vec<Node>,
        no: Vec<Node>,
    },
    With {
        expr: String,
        yes: Vec<Node>,
        no: Vec<Node>,
    },
    Range {
        spec: RangeSpec,
        body: Vec<Node>,
        no: Vec<Node>,
    },
}

#[derive(Clone, Debug)]
struct RangeSpec {
    key: Option<String>,
    val: Option<String>,
    expr: String,
}

#[derive(Clone, Debug)]
struct Cli {
    datasources: HashMap<String, String>,
    contexts: Vec<(String, String)>,
    files: Vec<String>,
    outs: Vec<String>,
    inline: Option<String>,
    input_dir: Option<String>,
    output_dir: String,
    output_map: Option<String>,
    includes: Vec<String>,
    excludes: Vec<String>,
    exclude_processing: Vec<String>,
    templates: HashMap<String, String>,
    left: String,
    right: String,
    missing_key: String,
    chmod: Option<u32>,
    config_path: Option<String>,
    help: bool,
    version: bool,
}

impl Default for Cli {
    fn default() -> Self {
        Self {
            datasources: HashMap::new(),
            contexts: vec![],
            files: vec!["-".into()],
            outs: vec!["-".into()],
            inline: None,
            input_dir: None,
            output_dir: ".".into(),
            output_map: None,
            includes: vec![],
            excludes: vec![],
            exclude_processing: vec![],
            templates: HashMap::new(),
            left: env::var("GOMPLATE_LEFT_DELIM").unwrap_or_else(|_| "{{".into()),
            right: env::var("GOMPLATE_RIGHT_DELIM").unwrap_or_else(|_| "}}".into()),
            missing_key: "error".into(),
            chmod: None,
            config_path: env::var("GOMPLATE_CONFIG")
                .ok()
                .or_else(|| Some(".gomplate.yaml".into())),
            help: false,
            version: false,
        }
    }
}

#[derive(Clone)]
struct Engine {
    ds: HashMap<String, String>,
    stdin_cache: Option<String>,
    templates: HashMap<String, Vec<Node>>,
    missing_key: String,
    left: String,
    right: String,
}

#[derive(Clone)]
struct Scope {
    dot: Value,
    vars: HashMap<String, Value>,
}

fn main() {
    if let Err(e) = real_main() {
        eprintln!(
            r#"{{"time":"{}","level":"ERROR","msg":"","err":"{}"}}"#,
            chrono::Utc::now().to_rfc3339_opts(chrono::SecondsFormat::Nanos, true),
            esc_json(&format!("{:#}", e))
        );
        std::process::exit(1);
    }
}

fn real_main() -> Result<()> {
    let mut cli = parse_cli(env::args().skip(1).collect())?;
    apply_config(&mut cli);
    if cli.help {
        print_help();
        return Ok(());
    }
    if cli.version {
        println!("gomplate version 0.0.0");
        return Ok(());
    }

    let mut engine = Engine {
        ds: cli.datasources.clone(),
        stdin_cache: None,
        templates: HashMap::new(),
        missing_key: cli.missing_key.clone(),
        left: cli.left.clone(),
        right: cli.right.clone(),
    };
    for (name, src) in &cli.templates {
        let txt = read_url_text(src, &mut engine)?;
        engine.templates.insert(
            name.clone(),
            parse_template(&txt, &engine.left, &engine.right)?,
        );
    }

    let mut root = context_value();
    for (alias, url) in &cli.contexts {
        let v = load_datasource_value(url, &mut engine)?;
        if alias == "." {
            root = v;
        } else if let Value::Object(ref mut m) = root {
            m.insert(alias.clone(), v);
        }
    }

    if let Some(dir) = &cli.input_dir {
        process_dir(&cli, &mut engine, &root, dir)?;
        return Ok(());
    }

    let inputs = if let Some(s) = &cli.inline {
        vec![(
            "<arg>".to_string(),
            s.clone(),
            cli.outs.get(0).cloned().unwrap_or_else(|| "-".into()),
        )]
    } else {
        let mut v = vec![];
        for (idx, f) in cli.files.iter().enumerate() {
            let out = cli.outs.get(idx).cloned().unwrap_or_else(|| "-".into());
            v.push((f.clone(), read_input_file(f)?, out));
        }
        v
    };

    for (_name, text, out) in inputs {
        let nodes = parse_template(&text, &engine.left, &engine.right)?;
        let mut scope = Scope {
            dot: root.clone(),
            vars: HashMap::new(),
        };
        let rendered = render_nodes(&nodes, &mut engine, &mut scope)?;
        write_output(&out, &rendered, cli.chmod)?;
    }
    Ok(())
}

fn parse_cli(args: Vec<String>) -> Result<Cli> {
    let mut c = Cli::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let mut val: Option<String> = None;
        let key = if let Some((k, v)) = a.split_once('=') {
            val = Some(v.to_string());
            k
        } else {
            a.as_str()
        };
        macro_rules! take {
            () => {{
                if let Some(v) = val.take() {
                    v
                } else {
                    i += 1;
                    args.get(i)
                        .cloned()
                        .ok_or_else(|| anyhow!("flag needs an argument: {}", a))?
                }
            }};
        }
        match key {
            "-h" | "--help" => c.help = true,
            "-v" | "--version" => c.version = true,
            "-V" | "--verbose" | "--experimental" | "--exec-pipe" => {}
            "-d" | "--datasource" => add_pair(&mut c.datasources, &take!())?,
            "-c" | "--context" => {
                let s = take!();
                let (k, v) = parse_pair(&s)?;
                c.contexts.push((k, v));
            }
            "-H" | "--datasource-header" | "--plugin" => {
                let _ = take!();
            }
            "--config" => c.config_path = Some(take!()),
            "-f" | "--file" => {
                if c.files == ["-"] {
                    c.files.clear();
                }
                c.files.push(take!());
            }
            "-i" | "--in" => c.inline = Some(take!()),
            "-o" | "--out" => {
                if c.outs == ["-"] {
                    c.outs.clear();
                }
                c.outs.push(take!());
            }
            "-t" | "--template" => add_pair(&mut c.templates, &take!())?,
            "--input-dir" => c.input_dir = Some(take!()),
            "--output-dir" => c.output_dir = take!(),
            "--output-map" => c.output_map = Some(take!()),
            "--include" => c.includes.push(take!()),
            "--exclude" => c.excludes.push(take!()),
            "--exclude-processing" => c.exclude_processing.push(take!()),
            "--left-delim" => c.left = take!(),
            "--right-delim" => c.right = take!(),
            "--missing-key" => c.missing_key = take!(),
            "--chmod" => c.chmod = Some(u32::from_str_radix(take!().trim_start_matches("0o"), 8)?),
            _ if key.starts_with('-') => {
                print_help();
                bail!("unknown flag: {}", key);
            }
            _ => {}
        }
        i += 1;
    }
    if c.outs.is_empty() {
        c.outs.push("-".into());
    }
    Ok(c)
}

fn print_help() {
    println!("Process text files with Go templates\n\nUsage:\n  gomplate [flags]\n\nFlags:\n  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.\n  -H, --datasource-header header     HTTP header field in 'alias=Name: value' form to be provided on HTTP-based data sources. Multiples can be set.\n  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias `.` to set the root context.\n      --plugin strings               plug in an external command as a function in name=path form. Can be specified multiple times\n  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])\n  -i, --in string                    Template string to process (alternative to --file and --input-dir)\n      --input-dir directory          directory which is examined recursively for templates (alternative to --file and --in)\n      --exclude strings              glob of files to not parse\n      --exclude-processing strings   glob of files to be copied without parsing\n      --include strings              glob of files to parse\n  -o, --out file                     output file name. Omit to use standard output. (default [-])\n  -t, --template strings             Additional template file(s)\n      --output-dir directory         directory to store the processed templates. Only used for --input-dir (default \".\")\n      --output-map string            Template string to map the input file to an output path\n      --chmod string                 set the mode for output file(s). Omit to inherit from input file(s)\n      --exec-pipe                    pipe the output to the post-run exec command\n      --left-delim delimiter         override the default left-delimiter [$GOMPLATE_LEFT_DELIM] (default \"{{{{\")\n      --right-delim delimiter        override the default right-delimiter [$GOMPLATE_RIGHT_DELIM] (default \"}}}}\")\n      --missing-key string           Control the behavior during execution if a map is indexed with a key that is not present in the map. error (default) - return an error, zero - fallback to zero value, default/invalid - print <no value> (default \"error\")\n      --experimental                 enable experimental features [$GOMPLATE_EXPERIMENTAL]\n  -V, --verbose                      output extra information about what gomplate is doing\n      --config string                config file (overridden by commandline flags) (default \".gomplate.yaml\")\n  -h, --help                         help for gomplate\n  -v, --version                      version for gomplate");
}

fn apply_config(cli: &mut Cli) {
    let Some(path) = cli.config_path.clone() else {
        return;
    };
    if path.is_empty() || !Path::new(&path).exists() {
        return;
    }
    let Ok(text) = fs::read_to_string(path) else {
        return;
    };
    let cfg = parse_yaml_simple(&text);
    let Some(m) = cfg.as_object() else {
        return;
    };
    if cli.inline.is_none() {
        if let Some(v) = m.get("in") {
            cli.inline = Some(display(v));
        }
    }
    if cli.input_dir.is_none() {
        if let Some(v) = m.get("inputDir") {
            cli.input_dir = Some(display(v));
        }
    }
    if cli.output_dir == "." {
        if let Some(v) = m.get("outputDir") {
            cli.output_dir = display(v);
        }
    }
    if cli.output_map.is_none() {
        if let Some(v) = m.get("outputMap") {
            cli.output_map = Some(display(v));
        }
    }
    if cli.left == "{{" {
        if let Some(v) = m.get("leftDelim") {
            cli.left = display(v);
        }
    }
    if cli.right == "}}" {
        if let Some(v) = m.get("rightDelim") {
            cli.right = display(v);
        }
    }
    if let Some(Value::Object(ds)) = m.get("datasources") {
        for (k, v) in ds {
            if cli.datasources.contains_key(k) {
                continue;
            }
            let url = v
                .as_object()
                .and_then(|o| o.get("url"))
                .map(display)
                .unwrap_or_else(|| display(v));
            cli.datasources.insert(k.clone(), url);
        }
    }
    if let Some(Value::Object(ctx)) = m.get("context") {
        for (k, v) in ctx {
            let url = v
                .as_object()
                .and_then(|o| o.get("url"))
                .map(display)
                .unwrap_or_else(|| display(v));
            cli.contexts.push((k.clone(), url));
        }
    }
}

fn parse_pair(s: &str) -> Result<(String, String)> {
    if let Some((k, v)) = s.split_once('=') {
        return Ok((k.to_string(), v.to_string()));
    }
    let p = Path::new(s);
    let stem = p.file_stem().and_then(|x| x.to_str()).unwrap_or(s);
    Ok((stem.to_string(), s.to_string()))
}

fn add_pair(map: &mut HashMap<String, String>, s: &str) -> Result<()> {
    let (k, v) = parse_pair(s)?;
    map.insert(k, v);
    Ok(())
}

fn context_value() -> Value {
    let mut envm = Map::new();
    for (k, v) in env::vars() {
        envm.insert(k, Value::String(v));
    }
    json!({"Env": Value::Object(envm)})
}

fn read_input_file(f: &str) -> Result<String> {
    if f == "-" {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s)?;
        Ok(s)
    } else {
        Ok(fs::read_to_string(f).with_context(|| format!("read {}", f))?)
    }
}

fn write_output(out: &str, text: &str, chmod: Option<u32>) -> Result<()> {
    if out == "-" {
        print!("{}", text);
        io::stdout().flush()?;
    } else {
        if let Some(p) = Path::new(out).parent() {
            if !p.as_os_str().is_empty() {
                fs::create_dir_all(p)?;
            }
        }
        fs::write(out, text)?;
        #[cfg(unix)]
        if let Some(mode) = chmod {
            use std::os::unix::fs::PermissionsExt;
            fs::set_permissions(out, fs::Permissions::from_mode(mode))?;
        }
    }
    Ok(())
}

fn parse_template(input: &str, left: &str, right: &str) -> Result<Vec<Node>> {
    let mut pos = 0;
    let (nodes, _) = parse_until(input, &mut pos, left, right, &[])?;
    Ok(nodes)
}

fn parse_until(
    input: &str,
    pos: &mut usize,
    left: &str,
    right: &str,
    stops: &[&str],
) -> Result<(Vec<Node>, Option<String>)> {
    let mut nodes = Vec::new();
    while *pos < input.len() {
        let Some(rel) = input[*pos..].find(left) else {
            nodes.push(Node::Text(input[*pos..].to_string()));
            *pos = input.len();
            break;
        };
        let start = *pos + rel;
        nodes.push(Node::Text(input[*pos..start].to_string()));
        let mut act_start = start + left.len();
        let trim_left = input[act_start..].starts_with('-');
        if trim_left {
            act_start += 1;
            trim_last_text(&mut nodes);
        }
        let end_rel = input[act_start..]
            .find(right)
            .ok_or_else(|| anyhow!("unclosed action"))?;
        let mut act_end = act_start + end_rel;
        let mut trim_right = false;
        if act_end > act_start && input[..act_end].ends_with('-') {
            trim_right = true;
            act_end -= 1;
        }
        let action = input[act_start..act_end].trim().to_string();
        *pos = act_start + end_rel + right.len();
        if trim_right {
            while *pos < input.len() && input.as_bytes()[*pos].is_ascii_whitespace() {
                *pos += 1;
            }
        }
        if stops
            .iter()
            .any(|s| action == *s || action.starts_with(&format!("{} ", s)))
        {
            return Ok((nodes, Some(action)));
        }
        if let Some(rest) = action.strip_prefix("if ") {
            let (yes, stop) = parse_until(input, pos, left, right, &["else", "end"])?;
            let no = if matches!(stop.as_deref(), Some("else"))
                || stop.as_deref().unwrap_or("").starts_with("else ")
            {
                let (n, _) = parse_until(input, pos, left, right, &["end"])?;
                n
            } else {
                Vec::new()
            };
            nodes.push(Node::If {
                expr: rest.trim().to_string(),
                yes,
                no,
            });
        } else if let Some(rest) = action.strip_prefix("range ") {
            let spec = parse_range_spec(rest);
            let (body, stop) = parse_until(input, pos, left, right, &["else", "end"])?;
            let no = if matches!(stop.as_deref(), Some("else"))
                || stop.as_deref().unwrap_or("").starts_with("else ")
            {
                let (n, _) = parse_until(input, pos, left, right, &["end"])?;
                n
            } else {
                Vec::new()
            };
            nodes.push(Node::Range { spec, body, no });
        } else if let Some(rest) = action.strip_prefix("with ") {
            let (yes, stop) = parse_until(input, pos, left, right, &["else", "end"])?;
            let no = if matches!(stop.as_deref(), Some("else"))
                || stop.as_deref().unwrap_or("").starts_with("else ")
            {
                let (n, _) = parse_until(input, pos, left, right, &["end"])?;
                n
            } else {
                Vec::new()
            };
            nodes.push(Node::With {
                expr: rest.trim().to_string(),
                yes,
                no,
            });
        } else if action == "end" || action == "else" {
            return Ok((nodes, Some(action)));
        } else {
            nodes.push(Node::Expr(action));
        }
    }
    Ok((nodes, None))
}

fn trim_last_text(nodes: &mut [Node]) {
    if let Some(Node::Text(t)) = nodes.last_mut() {
        while t.ends_with(char::is_whitespace) {
            t.pop();
        }
    }
}

fn parse_range_spec(s: &str) -> RangeSpec {
    if let Some((lhs, rhs)) = s.split_once(":=") {
        let names: Vec<_> = lhs
            .split(',')
            .map(|x| x.trim().trim_start_matches('$').to_string())
            .collect();
        RangeSpec {
            key: if names.len() == 2 {
                Some(names[0].clone())
            } else {
                None
            },
            val: Some(names.last().unwrap().clone()),
            expr: rhs.trim().to_string(),
        }
    } else {
        RangeSpec {
            key: None,
            val: None,
            expr: s.trim().to_string(),
        }
    }
}

fn render_nodes(nodes: &[Node], engine: &mut Engine, scope: &mut Scope) -> Result<String> {
    let mut out = String::new();
    for n in nodes {
        match n {
            Node::Text(t) => out.push_str(t),
            Node::Expr(e) => {
                if let Some((name, rhs)) = parse_assignment(e) {
                    let v = eval_expr(rhs, engine, scope)?;
                    scope.vars.insert(name.to_string(), v);
                } else if e.starts_with("/*") {
                } else {
                    let v = eval_expr(e, engine, scope)?;
                    if !v.is_null() {
                        out.push_str(&display(&v));
                    }
                }
            }
            Node::If { expr, yes, no } => {
                if truthy(&eval_expr(expr, engine, scope)?) {
                    out.push_str(&render_nodes(yes, engine, scope)?);
                } else {
                    out.push_str(&render_nodes(no, engine, scope)?);
                }
            }
            Node::With { expr, yes, no } => {
                let v = eval_expr(expr, engine, scope)?;
                if truthy(&v) {
                    let old = scope.dot.clone();
                    scope.dot = v;
                    out.push_str(&render_nodes(yes, engine, scope)?);
                    scope.dot = old;
                } else {
                    out.push_str(&render_nodes(no, engine, scope)?);
                }
            }
            Node::Range { spec, body, no } => {
                let v = eval_expr(&spec.expr, engine, scope)?;
                let mut any = false;
                match v {
                    Value::Array(a) => {
                        for (idx, item) in a.iter().enumerate() {
                            any = true;
                            let old_dot = scope.dot.clone();
                            scope.dot = item.clone();
                            if let Some(k) = &spec.key {
                                scope.vars.insert(k.clone(), json!(idx));
                            }
                            if let Some(vn) = &spec.val {
                                scope.vars.insert(vn.clone(), item.clone());
                            }
                            out.push_str(&render_nodes(body, engine, scope)?);
                            scope.dot = old_dot;
                        }
                    }
                    Value::Object(m) => {
                        let mut keys: Vec<_> = m.keys().cloned().collect();
                        keys.sort();
                        for k in keys {
                            any = true;
                            let item = m.get(&k).cloned().unwrap_or(Value::Null);
                            let old_dot = scope.dot.clone();
                            scope.dot = item.clone();
                            if let Some(kn) = &spec.key {
                                scope.vars.insert(kn.clone(), Value::String(k));
                            }
                            if let Some(vn) = &spec.val {
                                scope.vars.insert(vn.clone(), item.clone());
                            }
                            out.push_str(&render_nodes(body, engine, scope)?);
                            scope.dot = old_dot;
                        }
                    }
                    _ => {}
                }
                if !any {
                    out.push_str(&render_nodes(no, engine, scope)?);
                }
            }
        }
    }
    Ok(out)
}

fn parse_assignment(e: &str) -> Option<(&str, &str)> {
    if let Some((lhs, rhs)) = e.split_once(":=") {
        return lhs.trim().strip_prefix('$').map(|n| (n.trim(), rhs.trim()));
    }
    if let Some((lhs, rhs)) = e.split_once(" = ") {
        return lhs.trim().strip_prefix('$').map(|n| (n.trim(), rhs.trim()));
    }
    None
}

fn eval_expr(expr: &str, engine: &mut Engine, scope: &mut Scope) -> Result<Value> {
    let parts = split_top(expr, '|');
    let mut val = eval_command(parts[0].trim(), engine, scope, None)?;
    for p in parts.iter().skip(1) {
        val = eval_command(p.trim(), engine, scope, Some(val))?;
    }
    Ok(val)
}

fn eval_command(
    cmd: &str,
    engine: &mut Engine,
    scope: &mut Scope,
    piped: Option<Value>,
) -> Result<Value> {
    let toks = tokenize(cmd);
    if toks.is_empty() {
        return Ok(piped.unwrap_or(Value::Null));
    }
    if toks.len() == 1 && piped.is_none() {
        return eval_atom(&toks[0], engine, scope);
    }
    let name = toks[0].as_str();
    let mut args = Vec::new();
    for t in toks.iter().skip(1) {
        args.push(eval_atom(t, engine, scope)?);
    }
    if let Some(v) = piped {
        args.push(v);
    }
    call_func(name, args, engine, scope)
}

fn eval_atom(tok: &str, engine: &mut Engine, scope: &mut Scope) -> Result<Value> {
    let tok = tok.trim();
    if tok.is_empty() {
        return Ok(Value::Null);
    }
    if tok.starts_with('(') {
        if let Some(end) = matching_paren(tok) {
            let inner = &tok[1..end];
            let mut v = eval_expr(inner, engine, scope)?;
            let rest = tok[end + 1..].trim();
            if rest.starts_with('.') {
                v = get_path(&v, rest, engine)?;
            }
            return Ok(v);
        }
    }
    if tok.starts_with('"') || tok.starts_with('`') {
        return Ok(Value::String(unquote(tok)));
    }
    if tok == "true" {
        return Ok(Value::Bool(true));
    }
    if tok == "false" {
        return Ok(Value::Bool(false));
    }
    if tok == "nil" || tok == "null" {
        return Ok(Value::Null);
    }
    if tok == "." {
        return Ok(scope.dot.clone());
    }
    if tok.starts_with('.') {
        return get_path(&scope.dot, tok, engine);
    }
    if tok == "env.Env" {
        return call_func("env.Env", Vec::new(), engine, scope);
    }
    if let Some(rest) = tok.strip_prefix("env.Env.") {
        let envv = call_func("env.Env", Vec::new(), engine, scope)?;
        return get_path(&envv, &format!(".{}", rest), engine);
    }
    if let Some(name) = tok.strip_prefix('$') {
        let mut parts = name.splitn(2, '.');
        let base = parts.next().unwrap();
        let v = scope.vars.get(base).cloned().unwrap_or(Value::Null);
        if let Some(rest) = parts.next() {
            return get_path(&v, &format!(".{}", rest), engine);
        }
        return Ok(v);
    }
    if let Some(n) = parse_number(tok) {
        return Ok(n);
    }
    Ok(Value::String(tok.to_string()))
}

fn matching_paren(s: &str) -> Option<usize> {
    let mut depth = 0;
    let mut in_str = false;
    let mut quote = '\0';
    for (i, c) in s.char_indices() {
        if in_str {
            if c == quote {
                in_str = false;
            }
            continue;
        }
        match c {
            '"' | '`' => {
                in_str = true;
                quote = c;
            }
            '(' => depth += 1,
            ')' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            _ => {}
        }
    }
    None
}

fn parse_number(s: &str) -> Option<Value> {
    if s.contains('.') || s.contains('e') || s.contains('E') {
        return s
            .parse::<f64>()
            .ok()
            .and_then(Number::from_f64)
            .map(Value::Number);
    }
    let neg = s.starts_with('-');
    let body = s.trim_start_matches('-');
    let parsed = if let Some(h) = body.strip_prefix("0x").or_else(|| body.strip_prefix("0X")) {
        i64::from_str_radix(h, 16).ok()
    } else if body.len() > 1 && body.starts_with('0') {
        i64::from_str_radix(&body[1..], 8).ok()
    } else {
        body.parse::<i64>().ok()
    }?;
    Some(json!(if neg { -parsed } else { parsed }))
}

fn get_path(v: &Value, path: &str, engine: &Engine) -> Result<Value> {
    let mut cur = v.clone();
    for p in path.trim_start_matches('.').split('.') {
        if p.is_empty() {
            continue;
        }
        cur = match cur {
            Value::Object(m) => m.get(p).cloned().unwrap_or_else(|| {
                if engine.missing_key == "error" {
                    Value::String(format!("__MISSING__{}", p))
                } else {
                    Value::String("<no value>".into())
                }
            }),
            Value::Array(a) => p
                .parse::<usize>()
                .ok()
                .and_then(|i| a.get(i).cloned())
                .unwrap_or(Value::Null),
            _ => Value::Null,
        };
        if let Value::String(s) = &cur {
            if let Some(k) = s.strip_prefix("__MISSING__") {
                bail!("map has no entry for key \"{}\"", k);
            }
        }
    }
    Ok(cur)
}

fn split_top(s: &str, sep: char) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut depth = 0;
    let mut in_str = false;
    let mut quote = '\0';
    let mut esc = false;
    for c in s.chars() {
        if in_str {
            cur.push(c);
            if esc {
                esc = false;
            } else if c == '\\' {
                esc = true;
            } else if c == quote {
                in_str = false;
            }
            continue;
        }
        match c {
            '"' | '`' => {
                in_str = true;
                quote = c;
                cur.push(c);
            }
            '(' => {
                depth += 1;
                cur.push(c);
            }
            ')' => {
                depth -= 1;
                cur.push(c);
            }
            c if c == sep && depth == 0 => {
                out.push(cur.trim().to_string());
                cur.clear();
            }
            _ => cur.push(c),
        }
    }
    out.push(cur.trim().to_string());
    out
}

fn tokenize(s: &str) -> Vec<String> {
    let mut toks = Vec::new();
    let mut cur = String::new();
    let mut depth = 0;
    let mut in_str = false;
    let mut quote = '\0';
    let mut esc = false;
    for c in s.chars() {
        if in_str {
            cur.push(c);
            if esc {
                esc = false;
            } else if c == '\\' {
                esc = true;
            } else if c == quote {
                in_str = false;
            }
            continue;
        }
        match c {
            '"' | '`' => {
                in_str = true;
                quote = c;
                cur.push(c);
            }
            '(' => {
                depth += 1;
                cur.push(c);
            }
            ')' => {
                depth -= 1;
                cur.push(c);
            }
            c if c.is_whitespace() && depth == 0 => {
                if !cur.is_empty() {
                    toks.push(cur.clone());
                    cur.clear();
                }
            }
            _ => cur.push(c),
        }
    }
    if !cur.is_empty() {
        toks.push(cur);
    }
    toks
}

fn unquote(s: &str) -> String {
    if s.starts_with('`') && s.ends_with('`') {
        return s[1..s.len() - 1].to_string();
    }
    serde_json::from_str::<String>(s).unwrap_or_else(|_| s.trim_matches('"').to_string())
}

fn call_func(
    name: &str,
    args: Vec<Value>,
    engine: &mut Engine,
    scope: &mut Scope,
) -> Result<Value> {
    let n = name.rsplit('.').next().unwrap_or(name);
    if n == "Join" && (name.contains("path") || name.contains("filepath")) {
        let mut p = PathBuf::new();
        for a in &args {
            p.push(display(a));
        }
        return Ok(Value::String(p.to_string_lossy().to_string()));
    }
    match n {
        "print" => Ok(Value::String(args.iter().map(display).collect::<Vec<_>>().join(""))),
        "printf" => Ok(Value::String(fmt_printf(args))),
        "eq" => Ok(Value::Bool(args.windows(2).all(|w| cmpv(&w[0], &w[1]) == 0))),
        "ne" => Ok(Value::Bool(args.len() >= 2 && cmpv(&args[0], &args[1]) != 0)),
        "lt" => Ok(Value::Bool(args.len() >= 2 && cmpv(&args[0], &args[1]) < 0)),
        "le" => Ok(Value::Bool(args.len() >= 2 && cmpv(&args[0], &args[1]) <= 0)),
        "gt" => Ok(Value::Bool(args.len() >= 2 && cmpv(&args[0], &args[1]) > 0)),
        "ge" => Ok(Value::Bool(args.len() >= 2 && cmpv(&args[0], &args[1]) >= 0)),
        "not" => Ok(Value::Bool(!truthy(args.get(0).unwrap_or(&Value::Null)))),
        "and" => Ok(args.into_iter().find(|v| !truthy(v)).unwrap_or_else(|| Value::Bool(true))),
        "or" => Ok(args.into_iter().find(|v| truthy(v)).unwrap_or(Value::Bool(false))),
        "index" => {
            let mut v = args.get(0).cloned().unwrap_or(Value::Null);
            for k in args.iter().skip(1) { v = index_value(&v, k); }
            Ok(v)
        }
        "Add" | "add" => num_fold(args, 0.0, |a, b| a + b),
        "Mul" | "mul" => num_fold(args, 1.0, |a, b| a * b),
        "Sub" | "sub" => {
            let mut it = args.iter().map(to_f64);
            let first = it.next().unwrap_or(0.0);
            Ok(num_out(it.fold(first, |a, b| a - b), args.iter().any(is_float_like)))
        }
        "Div" | "div" => {
            let a = to_f64(args.get(0).unwrap_or(&Value::Null));
            let b = to_f64(args.get(1).unwrap_or(&Value::Null));
            if b == 0.0 { bail!("division by zero"); }
            Ok(num_out(a / b, true))
        }
        "Pow" | "pow" => Ok(num_out(to_f64(args.get(0).unwrap_or(&Value::Null)).powf(to_f64(args.get(1).unwrap_or(&Value::Null))), true)),
        "Rem" | "rem" => Ok(json!((to_f64(args.get(0).unwrap_or(&Value::Null)) as i64) % (to_f64(args.get(1).unwrap_or(&Value::Null)) as i64))),
        "Abs" => Ok(num_out(to_f64(args.get(0).unwrap_or(&Value::Null)).abs(), is_float_like(args.get(0).unwrap_or(&Value::Null)))),
        "IsNum" => Ok(Value::Bool(args.get(0).map(|v| v.is_number() || matches!(v, Value::String(s) if parse_number(s).is_some() || s.parse::<f64>().is_ok())).unwrap_or(false))),
        "IsInt" => Ok(Value::Bool(args.get(0).map(|v| !is_float_like(v) && (v.is_i64() || matches!(v, Value::String(s) if parse_number(s).is_some()))).unwrap_or(false))),
        "IsFloat" => Ok(Value::Bool(args.get(0).map(is_float_like).unwrap_or(false))),
        "Max" => Ok(num_out(args.iter().map(to_f64).fold(f64::NEG_INFINITY, f64::max), args.iter().any(is_float_like))),
        "Min" => Ok(num_out(args.iter().map(to_f64).fold(f64::INFINITY, f64::min), args.iter().any(is_float_like))),
        "Ceil" => Ok(num_out(to_f64(args.get(0).unwrap_or(&Value::Null)).ceil(), true)),
        "Floor" => Ok(num_out(to_f64(args.get(0).unwrap_or(&Value::Null)).floor(), true)),
        "Round" => Ok(num_out(to_f64(args.get(0).unwrap_or(&Value::Null)).round(), true)),
        "Seq" | "seq" => Ok(Value::Array(seq_args(&args).into_iter().map(|x| json!(x)).collect())),
        "Getenv" | "getenv" => Ok(Value::String(getenv_func(&args))),
        "HasEnv" => Ok(Value::Bool(args.get(0).and_then(Value::as_str).map(env::var_os).flatten().is_some())),
        "ExpandEnv" => Ok(Value::String(expand_env(args.get(0).map(display).unwrap_or_default()))),
        "Env" => Ok(context_value().get("Env").cloned().unwrap_or(Value::Null)),
        "ToUpper" | "toUpper" => Ok(Value::String(args.get(0).map(display).unwrap_or_default().to_uppercase())),
        "ToLower" | "toLower" => Ok(Value::String(args.get(0).map(display).unwrap_or_default().to_lowercase())),
        "Title" | "title" => Ok(Value::String(title_case(&args.get(0).map(display).unwrap_or_default()))),
        "ReplaceAll" | "replaceAll" => {
            let old = args.get(0).map(display).unwrap_or_default();
            let new = args.get(1).map(display).unwrap_or_default();
            let input = args.get(2).map(display).unwrap_or_default();
            Ok(Value::String(input.replace(&old, &new)))
        }
        "replace" => {
            let input = args.get(0).map(display).unwrap_or_default();
            let old = args.get(1).map(display).unwrap_or_default();
            let new = args.get(2).map(display).unwrap_or_default();
            Ok(Value::String(input.replace(&old, &new)))
        }
        "Contains" | "contains" => Ok(Value::Bool(args.get(1).map(display).unwrap_or_default().contains(&args.get(0).map(display).unwrap_or_default()))),
        "HasPrefix" | "hasPrefix" => Ok(Value::Bool(args.get(1).map(display).unwrap_or_default().starts_with(&args.get(0).map(display).unwrap_or_default()))),
        "HasSuffix" | "hasSuffix" => Ok(Value::Bool(args.get(1).map(display).unwrap_or_default().ends_with(&args.get(0).map(display).unwrap_or_default()))),
        "Trim" | "trim" => Ok(Value::String(args.get(0).map(display).unwrap_or_default().trim().to_string())),
        "Quote" | "quote" => Ok(Value::String(format!("{:?}", args.get(0).map(display).unwrap_or_default()))),
        "Repeat" | "repeat" => {
            let count = to_f64(args.get(0).unwrap_or(&Value::Null)) as usize;
            Ok(Value::String(args.get(1).map(display).unwrap_or_default().repeat(count)))
        }
        "Split" | "split" => {
            let sep = args.get(0).map(display).unwrap_or_default();
            let input = args.get(1).map(display).unwrap_or_default();
            Ok(Value::Array(input.split(&sep).map(|s| Value::String(s.to_string())).collect()))
        }
        "SplitN" | "splitN" => {
            let sep = args.get(0).map(display).unwrap_or_default();
            let count = to_f64(args.get(1).unwrap_or(&Value::Null)) as usize;
            let input = args.get(2).map(display).unwrap_or_default();
            Ok(Value::Array(input.splitn(count, &sep).map(|s| Value::String(s.to_string())).collect()))
        }
        "Slice" | "slice" => Ok(Value::Array(args)),
        "Append" | "append" => {
            let mut a = args.get(0).and_then(Value::as_array).cloned().unwrap_or_default();
            a.extend(args.iter().skip(1).cloned());
            Ok(Value::Array(a))
        }
        "Prepend" | "prepend" => {
            let mut a = args.last().and_then(Value::as_array).cloned().unwrap_or_default();
            for v in args.iter().take(args.len().saturating_sub(1)).rev() { a.insert(0, v.clone()); }
            Ok(Value::Array(a))
        }
        "Reverse" | "reverse" => {
            let mut a = args.get(0).and_then(Value::as_array).cloned().unwrap_or_default();
            a.reverse();
            Ok(Value::Array(a))
        }
        "Sort" | "sort" => {
            let mut a = args.get(0).and_then(Value::as_array).cloned().unwrap_or_default();
            a.sort_by_key(display);
            Ok(Value::Array(a))
        }
        "Keys" | "keys" => {
            let mut keys: Vec<_> = args.get(0).and_then(Value::as_object).map(|m| m.keys().cloned().collect()).unwrap_or_else(Vec::new);
            keys.sort();
            Ok(Value::Array(keys.into_iter().map(Value::String).collect()))
        }
        "Values" | "values" => {
            let mut vals: Vec<_> = args.get(0).and_then(Value::as_object).map(|m| m.iter().map(|(_, v)| v.clone()).collect()).unwrap_or_else(Vec::new);
            vals.sort_by_key(display);
            Ok(Value::Array(vals))
        }
        "Join" | "join" => {
            let (arr_v, sep_v) = if args.get(0).map(Value::is_array).unwrap_or(false) {
                (args.get(0), args.get(1))
            } else {
                (args.get(1), args.get(0))
            };
            let arr = arr_v.and_then(Value::as_array).cloned().unwrap_or_default();
            let sep = sep_v.map(display).unwrap_or_default();
            Ok(Value::String(arr.iter().map(display).collect::<Vec<_>>().join(&sep)))
        }
        "len" => Ok(json!(match args.get(0).unwrap_or(&Value::Null) {
            Value::Array(a) => a.len(),
            Value::Object(o) => o.len(),
            Value::String(s) => s.chars().count(),
            _ => 0,
        })),
        "Dict" | "dict" => {
            let mut m = Map::new();
            let mut it = args.iter();
            while let Some(k) = it.next() {
                if let Some(v) = it.next() { m.insert(display(k), v.clone()); }
            }
            Ok(Value::Object(m))
        }
        "Has" | "has" => {
            let key = args.get(0).map(display).unwrap_or_default();
            Ok(Value::Bool(args.get(1).and_then(Value::as_object).map(|m| m.contains_key(&key)).unwrap_or(false)))
        }
        "Default" | "default" => Ok(if args.len() >= 2 && !truthy(&args[1]) { args[0].clone() } else { args.get(1).cloned().unwrap_or(Value::Null) }),
        "JSON" | "json" => Ok(serde_json::from_str(&args.get(0).map(display).unwrap_or_default())?),
        "YAML" => Ok(parse_yaml_simple(&args.get(0).map(display).unwrap_or_default())),
        "TOML" => Ok(toml_to_json(toml::from_str(&args.get(0).map(display).unwrap_or_default())?)),
        "CSV" => Ok(Value::Array(args.get(0).map(display).unwrap_or_default().lines().map(|l| Value::Array(l.split(',').map(|x| Value::String(x.trim().to_string())).collect())).collect())),
        "ToJSON" | "toJSON" | "toJson" => Ok(Value::String(serde_json::to_string(args.get(0).unwrap_or(&Value::Null))?)),
        "ToJSONPretty" | "toJSONPretty" => Ok(Value::String(serde_json::to_string_pretty(args.get(0).unwrap_or(&Value::Null))?)),
        "ToString" | "toString" => Ok(Value::String(args.get(0).map(display).unwrap_or_default())),
        "ToInt" | "ToInt64" | "toInt" | "toInt64" | "Atoi" => Ok(json!(to_f64(args.get(0).unwrap_or(&Value::Null)) as i64)),
        "ToFloat64" | "toFloat64" => Ok(num_out(to_f64(args.get(0).unwrap_or(&Value::Null)), true)),
        "ToBool" | "toBool" | "Bool" => Ok(Value::Bool(truthy(args.get(0).unwrap_or(&Value::Null)))),
        "datasource" | "ds" => {
            let alias = args.get(0).map(display).unwrap_or_default();
            let mut v = datasource_alias(&alias, engine)?;
            for sub in args.iter().skip(1) { v = index_value(&v, sub); }
            Ok(v)
        }
        "include" => {
            let alias = args.get(0).map(display).unwrap_or_default();
            let url = engine.ds.get(&alias).cloned().unwrap_or(alias);
            Ok(Value::String(read_url_text(&url, engine)?))
        }
        "datasourceExists" => Ok(Value::Bool(args.get(0).map(display).map(|a| engine.ds.contains_key(&a)).unwrap_or(false))),
        "listDatasources" => {
            let mut keys: Vec<_> = engine.ds.keys().cloned().collect();
            keys.sort();
            Ok(Value::Array(keys.into_iter().map(Value::String).collect()))
        }
        "defineDatasource" => {
            if args.len() >= 2 {
                let k = display(&args[0]);
                engine.ds.entry(k).or_insert_with(|| display(&args[1]));
            }
            Ok(Value::Null)
        }
        "Read" => Ok(Value::String(fs::read_to_string(args.get(0).map(display).unwrap_or_default())?)),
        "Exists" => Ok(Value::Bool(Path::new(&args.get(0).map(display).unwrap_or_default()).exists())),
        "IsDir" => Ok(Value::Bool(Path::new(&args.get(0).map(display).unwrap_or_default()).is_dir())),
        "Base" => Ok(Value::String(Path::new(&args.get(0).map(display).unwrap_or_default()).file_name().and_then(|x| x.to_str()).unwrap_or("").to_string())),
        "Dir" => Ok(Value::String(Path::new(&args.get(0).map(display).unwrap_or_default()).parent().and_then(|x| x.to_str()).unwrap_or(".").to_string())),
        "Ext" => Ok(Value::String(Path::new(&args.get(0).map(display).unwrap_or_default()).extension().and_then(|x| x.to_str()).map(|x| format!(".{}", x)).unwrap_or_default())),
        "Clean" => Ok(Value::String(Path::new(&args.get(0).map(display).unwrap_or_default()).components().as_path().to_string_lossy().to_string())),
        "Match" | "match" => Ok(Value::Bool(args.len() >= 2 && glob_simple(&display(&args[1]), &display(&args[0])))),
        "Find" => Ok(Value::String(Regex::new(&display(args.get(0).unwrap_or(&Value::Null)))?.find(&display(args.get(1).unwrap_or(&Value::Null))).map(|m| m.as_str().to_string()).unwrap_or_default())),
        "FindAll" => {
            let re = Regex::new(&display(args.get(0).unwrap_or(&Value::Null)))?;
            Ok(Value::Array(re.find_iter(&display(args.get(1).unwrap_or(&Value::Null))).map(|m| Value::String(m.as_str().to_string())).collect()))
        }
        "MatchString" | "MatchRegexp" => Ok(Value::Bool(Regex::new(&display(args.get(0).unwrap_or(&Value::Null)))?.is_match(&display(args.get(1).unwrap_or(&Value::Null))))),
        "QuoteMeta" => Ok(Value::String(regex::escape(&display(args.get(0).unwrap_or(&Value::Null))))),
        "Replace" | "ReplaceLiteral" => Ok(Value::String(Regex::new(&display(args.get(0).unwrap_or(&Value::Null)))?.replace_all(&display(args.get(2).unwrap_or(&Value::Null)), display(args.get(1).unwrap_or(&Value::Null))).to_string())),
        "template" => {
            let name = args.get(0).map(display).unwrap_or_default();
            let data = args.get(1).cloned().unwrap_or_else(|| scope.dot.clone());
            let nodes = engine.templates.get(&name).cloned().ok_or_else(|| anyhow!("template {:?} not found", name))?;
            let mut sc = Scope { dot: data, vars: scope.vars.clone() };
            Ok(Value::String(render_nodes(&nodes, engine, &mut sc)?))
        }
        "Encode" => Ok(Value::String(base64::engine::general_purpose::STANDARD.encode(args.get(0).map(display).unwrap_or_default()))),
        "Decode" => Ok(Value::String(String::from_utf8_lossy(&base64::engine::general_purpose::STANDARD.decode(args.get(0).map(display).unwrap_or_default())?).to_string())),
        "SHA256" | "sha256" => Ok(Value::String(hex_bytes(&Sha256::digest(args.get(0).map(display).unwrap_or_default().as_bytes())))),
        "SHA512" | "sha512" => Ok(Value::String(hex_bytes(&Sha512::digest(args.get(0).map(display).unwrap_or_default().as_bytes())))),
        "required" => {
            if args.get(0).map(truthy).unwrap_or(false) { Ok(args[0].clone()) } else { bail!("can not render template: a required value was not set") }
        }
        _ => bail!("function {:?} not defined", name),
    }
}

fn num_fold(args: Vec<Value>, init: f64, f: fn(f64, f64) -> f64) -> Result<Value> {
    let is_float = args.iter().any(is_float_like);
    Ok(num_out(args.iter().map(to_f64).fold(init, f), is_float))
}

fn to_f64(v: &Value) -> f64 {
    match v {
        Value::Number(n) => n.as_f64().unwrap_or(0.0),
        Value::String(s) => parse_number(s)
            .and_then(|v| v.as_f64())
            .unwrap_or_else(|| s.parse().unwrap_or(0.0)),
        Value::Bool(b) => {
            if *b {
                1.0
            } else {
                0.0
            }
        }
        _ => 0.0,
    }
}

fn is_float_like(v: &Value) -> bool {
    match v {
        Value::Number(n) => n.as_f64().map(|f| f.fract() != 0.0).unwrap_or(false),
        Value::String(s) => {
            s.contains('.') || s.contains('e') || s.contains('E') || s == "NaN" || s == "Inf"
        }
        _ => false,
    }
}

fn num_out(n: f64, as_float: bool) -> Value {
    if as_float {
        Number::from_f64(n)
            .map(Value::Number)
            .unwrap_or_else(|| Value::String(n.to_string()))
    } else {
        json!(n as i64)
    }
}

fn seq_args(args: &[Value]) -> Vec<i64> {
    let (start, end, mut step) = match args.len() {
        0 => return vec![],
        1 => (1, to_f64(&args[0]) as i64, 1),
        2 => (to_f64(&args[0]) as i64, to_f64(&args[1]) as i64, 1),
        _ => (
            to_f64(&args[0]) as i64,
            to_f64(&args[1]) as i64,
            to_f64(&args[2]) as i64,
        ),
    };
    if step == 0 {
        return vec![];
    }
    if end < start && step > 0 {
        step = -step;
    }
    if end > start && step < 0 {
        step = -step;
    }
    let adjusted = end - (end - start) % step;
    let mut out = vec![start];
    let mut last = start;
    while last != adjusted {
        last += step;
        out.push(last);
        if out.len() > 1_000_000 {
            break;
        }
    }
    out
}

fn getenv_func(args: &[Value]) -> String {
    let key = args.get(0).map(display).unwrap_or_default();
    if let Ok(v) = env::var(&key) {
        return v;
    }
    if let Ok(path) = env::var(format!("{}_FILE", key)) {
        if let Ok(s) = fs::read_to_string(path) {
            return s.trim_end_matches('\n').to_string();
        }
    }
    args.get(1).map(display).unwrap_or_default()
}

fn expand_env(s: String) -> String {
    let re = Regex::new(r"\$\{([A-Za-z_][A-Za-z0-9_]*)\}|\$([A-Za-z_][A-Za-z0-9_]*)").unwrap();
    re.replace_all(&s, |caps: &regex::Captures| {
        let k = caps.get(1).or_else(|| caps.get(2)).unwrap().as_str();
        getenv_func(&[Value::String(k.to_string())])
    })
    .to_string()
}

fn title_case(s: &str) -> String {
    s.split_whitespace()
        .map(|w| {
            let mut ch = w.chars();
            match ch.next() {
                Some(c) => c.to_uppercase().collect::<String>() + ch.as_str(),
                None => String::new(),
            }
        })
        .collect::<Vec<_>>()
        .join(" ")
}

fn fmt_printf(args: Vec<Value>) -> String {
    let fmt = args.get(0).map(display).unwrap_or_default();
    if fmt == "%#v" {
        return args.get(1).map(debug_display).unwrap_or_default();
    }
    let mut out = fmt;
    for a in args.iter().skip(1) {
        if out.contains("%s") {
            out = out.replacen("%s", &display(a), 1);
        } else if out.contains("%d") {
            out = out.replacen("%d", &(to_f64(a) as i64).to_string(), 1);
        } else if out.contains("%v") {
            out = out.replacen("%v", &display(a), 1);
        }
    }
    out.replace("\\n", "\n")
}

fn cmpv(a: &Value, b: &Value) -> i8 {
    if (a.is_number() || b.is_number()) && (to_f64(a) - to_f64(b)).abs() < f64::EPSILON {
        return 0;
    }
    let aa = if a.is_number() || b.is_number() {
        to_f64(a).to_string()
    } else {
        display(a)
    };
    let bb = if a.is_number() || b.is_number() {
        to_f64(b).to_string()
    } else {
        display(b)
    };
    aa.cmp(&bb) as i8
}

fn index_value(v: &Value, k: &Value) -> Value {
    match (v, k) {
        (Value::Array(a), Value::Number(n)) => n
            .as_u64()
            .and_then(|i| a.get(i as usize).cloned())
            .unwrap_or(Value::Null),
        (Value::Object(m), _) => m.get(&display(k)).cloned().unwrap_or(Value::Null),
        _ => Value::Null,
    }
}

fn truthy(v: &Value) -> bool {
    match v {
        Value::Null => false,
        Value::Bool(b) => *b,
        Value::Number(n) => n.as_f64().unwrap_or(0.0) != 0.0,
        Value::String(s) => !s.is_empty() && s != "<no value>",
        Value::Array(a) => !a.is_empty(),
        Value::Object(o) => !o.is_empty(),
    }
}

fn display(v: &Value) -> String {
    match v {
        Value::Null => "<no value>".into(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => s.clone(),
        Value::Array(a) => format!("[{}]", a.iter().map(display).collect::<Vec<_>>().join(" ")),
        Value::Object(o) => {
            let mut parts: Vec<_> = o
                .iter()
                .map(|(k, v)| format!("{}:{}", k, display(v)))
                .collect();
            parts.sort();
            format!("map[{}]", parts.join(" "))
        }
    }
}

fn debug_display(v: &Value) -> String {
    match v {
        Value::String(s) => format!("{:?}", s),
        _ => display(v),
    }
}

fn esc_json(s: &str) -> String {
    s.replace('\\', "\\\\")
        .replace('"', "\\\"")
        .replace('\n', "\\n")
}

fn hex_bytes(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect()
}

fn datasource_alias(alias: &str, engine: &mut Engine) -> Result<Value> {
    let url = engine
        .ds
        .get(alias)
        .cloned()
        .unwrap_or_else(|| alias.to_string());
    load_datasource_value(&url, engine)
}

fn load_datasource_value(url: &str, engine: &mut Engine) -> Result<Value> {
    let text = read_url_text(url, engine)?;
    let kind = mime_hint(url);
    if kind == "json" {
        return Ok(serde_json::from_str(&text)?);
    }
    if kind == "toml" {
        let t: toml::Value = toml::from_str(&text)?;
        return Ok(toml_to_json(t));
    }
    if kind == "envfile" {
        return Ok(parse_envfile(&text));
    }
    if kind == "yaml" {
        return Ok(parse_yaml_simple(&text));
    }
    if text.trim_start().starts_with('{') || text.trim_start().starts_with('[') {
        return Ok(serde_json::from_str(&text)?);
    }
    Ok(Value::String(text))
}

fn read_url_text(url: &str, engine: &mut Engine) -> Result<String> {
    if url.starts_with("stdin:") || url == "-" {
        if engine.stdin_cache.is_none() {
            let mut s = String::new();
            io::stdin().read_to_string(&mut s)?;
            engine.stdin_cache = Some(s);
        }
        return Ok(engine.stdin_cache.clone().unwrap());
    }
    if let Some(var) = url.strip_prefix("env:///") {
        let key = var.split('?').next().unwrap_or(var);
        return Ok(env::var(key).unwrap_or_default());
    }
    if let Some(path) = url.strip_prefix("file://") {
        return Ok(fs::read_to_string(path.split('?').next().unwrap_or(path))?);
    }
    if url.starts_with("http://") || url.starts_with("https://") {
        bail!("remote datasources are not supported in this reimplementation");
    }
    Ok(fs::read_to_string(url.split('?').next().unwrap_or(url))?)
}

fn mime_hint(url: &str) -> &'static str {
    if url.contains("type=application/json") {
        return "json";
    }
    if url.contains("type=application/yaml") {
        return "yaml";
    }
    if url.contains("type=application/toml") {
        return "toml";
    }
    let p = url.split('?').next().unwrap_or(url);
    if p.ends_with(".json") {
        "json"
    } else if p.ends_with(".toml") {
        "toml"
    } else if p.ends_with(".env") {
        "envfile"
    } else if p.ends_with(".yaml") || p.ends_with(".yml") {
        "yaml"
    } else {
        "text"
    }
}

fn toml_to_json(v: toml::Value) -> Value {
    match v {
        toml::Value::String(s) => Value::String(s),
        toml::Value::Integer(i) => json!(i),
        toml::Value::Float(f) => Number::from_f64(f)
            .map(Value::Number)
            .unwrap_or(Value::Null),
        toml::Value::Boolean(b) => Value::Bool(b),
        toml::Value::Datetime(d) => Value::String(d.to_string()),
        toml::Value::Array(a) => Value::Array(a.into_iter().map(toml_to_json).collect()),
        toml::Value::Table(t) => {
            Value::Object(t.into_iter().map(|(k, v)| (k, toml_to_json(v))).collect())
        }
    }
}

fn parse_envfile(s: &str) -> Value {
    let mut m = Map::new();
    for line in s.lines() {
        let line = line.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        if let Some((k, v)) = line.split_once('=') {
            m.insert(
                k.trim().to_string(),
                Value::String(v.trim().trim_matches('"').to_string()),
            );
        }
    }
    Value::Object(m)
}

fn parse_yaml_simple(s: &str) -> Value {
    let lines: Vec<_> = s
        .lines()
        .filter(|l| !l.trim().is_empty() && !l.trim_start().starts_with('#'))
        .collect();
    let (v, _) = parse_yaml_block(&lines, 0, 0);
    v
}

fn parse_yaml_block(lines: &[&str], mut i: usize, indent: usize) -> (Value, usize) {
    let mut m = Map::new();
    let mut arr = Vec::new();
    let mut is_arr = false;
    while i < lines.len() {
        let line = lines[i];
        let nindent = line.chars().take_while(|c| *c == ' ').count();
        if nindent < indent {
            break;
        }
        if nindent > indent {
            i += 1;
            continue;
        }
        let t = line.trim();
        if let Some(rest) = t.strip_prefix("- ") {
            is_arr = true;
            arr.push(parse_scalar(rest));
            i += 1;
            continue;
        }
        if let Some((k, v)) = t.split_once(':') {
            let key = k.trim().to_string();
            let val = v.trim();
            if val.is_empty() {
                let (child, ni) = parse_yaml_block(lines, i + 1, indent + 2);
                m.insert(key, child);
                i = ni;
            } else {
                m.insert(key, parse_scalar(val));
                i += 1;
            }
        } else {
            i += 1;
        }
    }
    if is_arr {
        (Value::Array(arr), i)
    } else {
        (Value::Object(m), i)
    }
}

fn parse_scalar(s: &str) -> Value {
    let s = s.trim().trim_matches('"').trim_matches('\'');
    if s.starts_with('[') && s.ends_with(']') {
        let inner = &s[1..s.len() - 1];
        return Value::Array(inner.split(',').map(|x| parse_scalar(x.trim())).collect());
    }
    if s == "true" {
        Value::Bool(true)
    } else if s == "false" {
        Value::Bool(false)
    } else if let Some(v) = parse_number(s) {
        v
    } else {
        Value::String(s.to_string())
    }
}

fn process_dir(cli: &Cli, engine: &mut Engine, root: &Value, dir: &str) -> Result<()> {
    let base = PathBuf::from(dir);
    let mut files = Vec::new();
    collect_files(&base, &mut files)?;
    for p in files {
        let rel = p.strip_prefix(&base).unwrap().to_string_lossy().to_string();
        if is_excluded(&rel, &cli.excludes) {
            continue;
        }
        let out_path = if let Some(map_t) = &cli.output_map {
            let mut sc = Scope {
                dot: root.clone(),
                vars: HashMap::new(),
            };
            if let Value::Object(ref mut m) = sc.dot {
                m.insert("in".into(), Value::String(rel.clone()));
                m.insert("ctx".into(), root.clone());
            }
            render_nodes(
                &parse_template(map_t, &engine.left, &engine.right)?,
                engine,
                &mut sc,
            )?
            .trim()
            .to_string()
        } else {
            Path::new(&cli.output_dir)
                .join(&rel)
                .to_string_lossy()
                .to_string()
        };
        if is_excluded(&rel, &cli.exclude_processing) {
            if let Some(parent) = Path::new(&out_path).parent() {
                fs::create_dir_all(parent)?;
            }
            fs::copy(&p, &out_path)?;
            continue;
        }
        if !cli.includes.is_empty() && !is_excluded(&rel, &cli.includes) {
            continue;
        }
        let text = fs::read_to_string(&p)?;
        let nodes = parse_template(&text, &engine.left, &engine.right)?;
        let mut scope = Scope {
            dot: root.clone(),
            vars: HashMap::new(),
        };
        let rendered = render_nodes(&nodes, engine, &mut scope)?;
        write_output(&out_path, &rendered, cli.chmod)?;
    }
    Ok(())
}

fn collect_files(dir: &Path, out: &mut Vec<PathBuf>) -> Result<()> {
    for e in fs::read_dir(dir)? {
        let e = e?;
        let p = e.path();
        if p.is_dir() {
            collect_files(&p, out)?;
        } else {
            out.push(p);
        }
    }
    Ok(())
}

fn is_excluded(path: &str, pats: &[String]) -> bool {
    pats.iter().any(|p| glob_simple(path, p))
}

fn glob_simple(path: &str, pat: &str) -> bool {
    let mut r = String::from("^");
    for c in pat.chars() {
        match c {
            '*' => r.push_str(".*"),
            '?' => r.push('.'),
            '.' => r.push_str("\\."),
            '/' => r.push('/'),
            c => r.push_str(&regex::escape(&c.to_string())),
        }
    }
    r.push('$');
    Regex::new(&r).map(|re| re.is_match(path)).unwrap_or(false)
}
