use std::collections::HashMap;
use std::env;
use std::f64::consts::{FRAC_PI_2, FRAC_PI_4, PI};
use std::fs::File;
use std::io::{self, BufRead, BufReader, Write};

const REL: &str = "Rel. 9.9.0, September 15th, 2026";

#[derive(Clone)]
struct Cfg {
    proj: String,
    inverse: bool,
    echo: bool,
    reverse_in: bool,
    reverse_out: bool,
    fmt: String,
    params: HashMap<String, String>,
    files: Vec<String>,
}

#[derive(Clone, Copy)]
struct Ellps {
    a: f64,
    e2: f64,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let prog = env::args().next().unwrap_or_else(|| "executable".to_string());
    match parse_args(args) {
        Ok(Action::Usage) => {
            println!("{}", REL);
            println!("usage: {} [-bdeEfiIlmorsStTvVwW [args]] [+opt[=arg] ...] [file ...]", prog);
        }
        Ok(Action::List(kind, verbose)) => list(kind.as_deref(), verbose),
        Ok(Action::Run(cfg)) => {
            if let Err((code, msg)) = validate(&cfg).and_then(|_| run(&cfg)) {
                if !msg.is_empty() {
                    eprint!("{}", msg);
                }
                std::process::exit(code);
            }
        }
        Err(msg) => {
            eprintln!("{}", REL);
            eprintln!("{}: ", prog);
            eprintln!("{}", msg);
            eprintln!("program abnormally terminated");
            std::process::exit(1);
        }
    }
}

enum Action {
    Usage,
    List(Option<String>, bool),
    Run(Cfg),
}

fn parse_args(args: Vec<String>) -> Result<Action, String> {
    if args.is_empty() {
        return Ok(Action::Usage);
    }
    let mut cfg = Cfg {
        proj: "merc".to_string(),
        inverse: false,
        echo: false,
        reverse_in: false,
        reverse_out: false,
        fmt: "%.2f".to_string(),
        params: HashMap::new(),
        files: Vec::new(),
    };
    let mut i = 0;
    let mut verbose_list = false;
    while i < args.len() {
        let a = &args[i];
        if a == "--help" || a.starts_with("--") {
            return Err("invalid option: --".to_string());
        } else if a.starts_with('+') {
            let s = &a[1..];
            let mut parts = s.splitn(2, '=');
            let k = parts.next().unwrap().to_string();
            let v = parts.next().unwrap_or("true").to_string();
            if k == "proj" {
                cfg.proj = v.clone();
            }
            cfg.params.insert(k, v);
        } else if a.starts_with('-') && a.len() > 1 {
            let mut chars = a[1..].chars().peekable();
            while let Some(c) = chars.next() {
                match c {
                    'I' => cfg.inverse = true,
                    'E' => cfg.echo = true,
                    'r' => cfg.reverse_in = true,
                    's' => cfg.reverse_out = true,
                    'v' | 'V' => {
                        verbose(&cfg);
                        return Ok(Action::Run(cfg));
                    }
                    'l' => {
                        let rest: String = chars.collect();
                        let kind = if !rest.is_empty() {
                            Some(rest)
                        } else if i + 1 < args.len() && !args[i + 1].starts_with('-') && !args[i + 1].starts_with('+') {
                            i += 1;
                            Some(args[i].clone())
                        } else {
                            None
                        };
                        return Ok(Action::List(kind, verbose_list));
                    }
                    'P' => verbose_list = true,
                    'f' => {
                        if i + 1 >= args.len() {
                            return Err("missing argument for -f".to_string());
                        }
                        i += 1;
                        cfg.fmt = args[i].clone();
                    }
                    'm' | 'W' | 'w' | 'e' | 'b' | 'd' | 'i' | 'o' | 'S' | 't' | 'T' => {
                        if matches!(c, 'm' | 'W' | 'w' | 'e' | 't') && i + 1 < args.len() && !args[i + 1].starts_with('+') && !args[i + 1].starts_with('-') {
                            i += 1;
                        }
                    }
                    _ => return Err(format!("invalid option: -{}", c)),
                }
                if c == 'l' { break; }
            }
        } else {
            cfg.files.push(a.clone());
        }
        i += 1;
    }
    Ok(Action::Run(cfg))
}

fn validate(cfg: &Cfg) -> Result<(), (i32, String)> {
    let known = ["merc", "webmerc", "utm", "tmerc", "lcc", "aea", "eqc", "cea", "laea", "aeqd", "stere", "sterea"];
    if cfg.proj == "longlat" || cfg.proj == "latlong" || cfg.proj == "lonlat" {
        return Err((3, format!("{}\n<executable>: \ncan't initialize operations that produce angular output coordinates\nprogram abnormally terminated\n", REL)));
    }
    if !known.contains(&cfg.proj.as_str()) {
        return Err((3, format!("proj_create: Error 1027 (Invalid value for an argument): Unknown projection\n{}\n<executable>: \nprojection initialization failure\ncause: Invalid value for an argument\nprogram abnormally terminated\n", REL)));
    }
    Ok(())
}

fn run(cfg: &Cfg) -> Result<(), (i32, String)> {
    if cfg.files.is_empty() {
        let stdin = io::stdin();
        process_reader(cfg, stdin.lock()).map_err(|e| (2, format!("{}\n", e)))?;
    } else {
        for f in &cfg.files {
            let file = File::open(f).map_err(|e| (2, format!("{}: {}\n", f, e)))?;
            process_reader(cfg, BufReader::new(file)).map_err(|e| (2, format!("{}\n", e)))?;
        }
    }
    Ok(())
}

fn process_reader<R: BufRead>(cfg: &Cfg, reader: R) -> io::Result<()> {
    let mut out = io::BufWriter::new(io::stdout());
    for line in reader.lines() {
        let line = line?;
        let (x, y, suffix) = parse_line(&line);
        let (mut a, mut b) = if cfg.reverse_in { (y, x) } else { (x, y) };
        if cfg.inverse {
            (a, b) = inverse_project(cfg, a, b);
        } else {
            (a, b) = forward_project(cfg, a, b);
        }
        if cfg.reverse_out {
            std::mem::swap(&mut a, &mut b);
        }
        if cfg.echo {
            write!(out, "{}\t", line)?;
        }
        if cfg.inverse {
            write!(out, "{}\t{}", dms(a, true), dms(b, false))?;
        } else {
            write!(out, "{}\t{}", fmt_num(a, &cfg.fmt), fmt_num(b, &cfg.fmt))?;
        }
        if !suffix.is_empty() && !cfg.echo {
            write!(out, "{}", suffix)?;
        }
        writeln!(out)?;
    }
    Ok(())
}

fn parse_line(line: &str) -> (f64, f64, String) {
    let bytes = line.as_bytes();
    let mut toks: Vec<(usize, usize)> = Vec::new();
    let mut in_tok = false;
    let mut start = 0;
    for (i, b) in bytes.iter().enumerate() {
        if b.is_ascii_whitespace() {
            if in_tok {
                toks.push((start, i));
                in_tok = false;
            }
        } else if !in_tok {
            start = i;
            in_tok = true;
        }
    }
    if in_tok { toks.push((start, line.len())); }
    let x = toks.get(0).map(|&(s,e)| parse_coord(&line[s..e])).unwrap_or(0.0);
    let y = toks.get(1).map(|&(s,e)| parse_coord(&line[s..e])).unwrap_or(0.0);
    let suffix = if toks.len() > 2 {
        line[toks[2].0.saturating_sub(0)..].to_string()
    } else if toks.len() < 2 {
        line.to_string()
    } else {
        String::new()
    };
    (x, y, suffix)
}

fn parse_coord(s: &str) -> f64 {
    let mut t = s.trim().to_string();
    let mut sign = 1.0;
    if t.starts_with('-') {
        sign = -1.0;
        t.remove(0);
    }
    if t.ends_with('W') || t.ends_with('S') || t.ends_with('w') || t.ends_with('s') {
        sign *= -1.0;
        t.pop();
    } else if t.ends_with('E') || t.ends_with('N') || t.ends_with('e') || t.ends_with('n') {
        t.pop();
    }
    if t.contains('d') || t.contains('D') || t.contains('\'') || t.contains('"') {
        let cleaned = t.replace(['D', 'd', '\'', '"'], " ");
        let vals: Vec<f64> = cleaned.split_whitespace().filter_map(|p| p.parse().ok()).collect();
        if vals.is_empty() { return 0.0; }
        sign * (vals[0] + vals.get(1).copied().unwrap_or(0.0) / 60.0 + vals.get(2).copied().unwrap_or(0.0) / 3600.0)
    } else {
        s.parse().unwrap_or(0.0)
    }
}

fn ellps(cfg: &Cfg) -> Ellps {
    if let Some(r) = val(cfg, "R") {
        return Ellps { a: r, e2: 0.0 };
    }
    let a = val(cfg, "a").unwrap_or(6378137.0);
    let e2 = if let Some(b) = val(cfg, "b") {
        1.0 - (b * b) / (a * a)
    } else if let Some(rf) = val(cfg, "rf") {
        let f = 1.0 / rf;
        2.0 * f - f * f
    } else if let Some(e) = val(cfg, "e") {
        e * e
    } else if let Some(es) = val(cfg, "es") {
        es
    } else {
        match cfg.params.get("ellps").map(|s| s.as_str()) {
            Some("sphere") => 0.0,
            Some("WGS84") => 0.0066943799901413165,
            Some("clrk66") => 0.006768657997,
            _ => 0.006694380022900787,
        }
    };
    Ellps { a, e2 }
}

fn val(cfg: &Cfg, k: &str) -> Option<f64> {
    cfg.params.get(k).and_then(|v| v.parse::<f64>().ok())
}

fn rad(d: f64) -> f64 { d * PI / 180.0 }
fn deg(r: f64) -> f64 { r * 180.0 / PI }

fn forward_project(cfg: &Cfg, lon_deg: f64, lat_deg: f64) -> (f64, f64) {
    let e = ellps(cfg);
    let lam0 = rad(val(cfg, "lon_0").unwrap_or_else(|| if cfg.proj == "utm" {
        let z = val(cfg, "zone").unwrap_or(31.0);
        z * 6.0 - 183.0
    } else { 0.0 }));
    let phi0 = rad(val(cfg, "lat_0").unwrap_or(0.0));
    let x0 = val(cfg, "x_0").unwrap_or_else(|| if cfg.proj == "utm" { 500000.0 } else { 0.0 });
    let y0 = val(cfg, "y_0").unwrap_or_else(|| if cfg.proj == "utm" && cfg.params.contains_key("south") { 10000000.0 } else { 0.0 });
    let k0 = val(cfg, "k").or_else(|| val(cfg, "k_0")).unwrap_or_else(|| if cfg.proj == "utm" { 0.9996 } else { 1.0 });
    let lam = rad(lon_deg);
    let phi = rad(lat_deg);
    match cfg.proj.as_str() {
        "merc" => merc_fwd(e, lam - lam0, phi, x0, y0, k0),
        "webmerc" => (x0 + e.a * k0 * (lam - lam0), y0 + e.a * k0 * (FRAC_PI_4 + phi / 2.0).tan().ln()),
        "utm" | "tmerc" => tmerc_fwd(e, lam, phi, lam0, phi0, x0, y0, k0),
        "lcc" => lcc_fwd(cfg, e, lam, phi, lam0, phi0, x0, y0),
        "aea" => aea_fwd(cfg, e, lam, phi, lam0, phi0, x0, y0),
        "eqc" => {
            let lat_ts = rad(val(cfg, "lat_ts").unwrap_or(0.0));
            (x0 + e.a * k0 * (lam - lam0) * lat_ts.cos(), y0 + e.a * k0 * (phi - phi0))
        }
        "cea" => {
            let lat_ts = rad(val(cfg, "lat_ts").unwrap_or(0.0));
            (x0 + e.a * (lam - lam0) * lat_ts.cos(), y0 + e.a * phi.sin() / lat_ts.cos())
        }
        "laea" => {
            let dlam = lam - lam0;
            let den = 1.0 + phi0.sin() * phi.sin() + phi0.cos() * phi.cos() * dlam.cos();
            let k = (2.0 / den).sqrt();
            (x0 + e.a * k * phi.cos() * dlam.sin(), y0 + e.a * k * (phi0.cos() * phi.sin() - phi0.sin() * phi.cos() * dlam.cos()))
        }
        "aeqd" => {
            let dlam = lam - lam0;
            let c = (phi0.sin() * phi.sin() + phi0.cos() * phi.cos() * dlam.cos()).acos();
            let k = if c.abs() < 1e-12 { 1.0 } else { c / c.sin() };
            (x0 + e.a * k * phi.cos() * dlam.sin(), y0 + e.a * k * (phi0.cos() * phi.sin() - phi0.sin() * phi.cos() * dlam.cos()))
        }
        "stere" | "sterea" => {
            let dlam = lam - lam0;
            let k = 2.0 * k0 / (1.0 + phi0.sin() * phi.sin() + phi0.cos() * phi.cos() * dlam.cos());
            (x0 + e.a * k * phi.cos() * dlam.sin(), y0 + e.a * k * (phi0.cos() * phi.sin() - phi0.sin() * phi.cos() * dlam.cos()))
        }
        _ => (lon_deg, lat_deg),
    }
}

fn inverse_project(cfg: &Cfg, x: f64, y: f64) -> (f64, f64) {
    let e = ellps(cfg);
    let lam0 = rad(val(cfg, "lon_0").unwrap_or_else(|| if cfg.proj == "utm" { val(cfg, "zone").unwrap_or(31.0) * 6.0 - 183.0 } else { 0.0 }));
    let phi0 = rad(val(cfg, "lat_0").unwrap_or(0.0));
    let x0 = val(cfg, "x_0").unwrap_or_else(|| if cfg.proj == "utm" { 500000.0 } else { 0.0 });
    let y0 = val(cfg, "y_0").unwrap_or_else(|| if cfg.proj == "utm" && cfg.params.contains_key("south") { 10000000.0 } else { 0.0 });
    let k0 = val(cfg, "k").or_else(|| val(cfg, "k_0")).unwrap_or_else(|| if cfg.proj == "utm" { 0.9996 } else { 1.0 });
    match cfg.proj.as_str() {
        "merc" | "webmerc" => merc_inv(e, x, y, lam0, x0, y0, k0),
        "utm" | "tmerc" => tmerc_inv(e, x, y, lam0, phi0, x0, y0, k0),
        _ => (deg(lam0 + (x - x0) / e.a), deg(phi0 + (y - y0) / e.a)),
    }
}

fn merc_fwd(e: Ellps, lam: f64, phi: f64, x0: f64, y0: f64, k0: f64) -> (f64, f64) {
    if e.e2 == 0.0 {
        return (x0 + e.a * k0 * lam, y0 + e.a * k0 * (FRAC_PI_4 + phi / 2.0).tan().ln());
    }
    let ecc = e.e2.sqrt();
    let s = phi.sin();
    let y = (FRAC_PI_4 + phi / 2.0).tan().ln() - ecc / 2.0 * ((1.0 + ecc * s) / (1.0 - ecc * s)).ln();
    (x0 + e.a * k0 * lam, y0 + e.a * k0 * y)
}

fn merc_inv(e: Ellps, x: f64, y: f64, lam0: f64, x0: f64, y0: f64, k0: f64) -> (f64, f64) {
    let lam = lam0 + (x - x0) / (e.a * k0);
    let ts = (-(y - y0) / (e.a * k0)).exp();
    let ecc = e.e2.sqrt();
    let mut phi = FRAC_PI_2 - 2.0 * ts.atan();
    for _ in 0..12 {
        let con = ecc * phi.sin();
        let next = FRAC_PI_2 - 2.0 * (ts * ((1.0 - con) / (1.0 + con)).powf(ecc / 2.0)).atan();
        if (next - phi).abs() < 1e-14 { break; }
        phi = next;
    }
    (deg(lam), deg(phi))
}

fn tmerc_fwd(e: Ellps, lam: f64, phi: f64, lam0: f64, phi0: f64, x0: f64, y0: f64, k0: f64) -> (f64, f64) {
    let ep2 = e.e2 / (1.0 - e.e2);
    let n = e.a / (1.0 - e.e2 * phi.sin().powi(2)).sqrt();
    let t = phi.tan().powi(2);
    let c = ep2 * phi.cos().powi(2);
    let a = (lam - lam0) * phi.cos();
    let m = merid(e, phi);
    let m0 = merid(e, phi0);
    let x = x0 + k0 * n * (a + (1.0 - t + c) * a.powi(3) / 6.0 + (5.0 - 18.0*t + t*t + 72.0*c - 58.0*ep2) * a.powi(5) / 120.0);
    let y = y0 + k0 * (m - m0 + n * phi.tan() * (a*a/2.0 + (5.0 - t + 9.0*c + 4.0*c*c) * a.powi(4)/24.0 + (61.0 - 58.0*t + t*t + 600.0*c - 330.0*ep2) * a.powi(6)/720.0));
    (x, y)
}

fn tmerc_inv(e: Ellps, x: f64, y: f64, lam0: f64, phi0: f64, x0: f64, y0: f64, k0: f64) -> (f64, f64) {
    let ep2 = e.e2 / (1.0 - e.e2);
    let m0 = merid(e, phi0);
    let m = m0 + (y - y0) / k0;
    let mu = m / (e.a * (1.0 - e.e2/4.0 - 3.0*e.e2*e.e2/64.0 - 5.0*e.e2.powi(3)/256.0));
    let e1 = (1.0 - (1.0 - e.e2).sqrt()) / (1.0 + (1.0 - e.e2).sqrt());
    let fp = mu + (3.0*e1/2.0 - 27.0*e1.powi(3)/32.0) * (2.0*mu).sin()
        + (21.0*e1*e1/16.0 - 55.0*e1.powi(4)/32.0) * (4.0*mu).sin()
        + (151.0*e1.powi(3)/96.0) * (6.0*mu).sin()
        + (1097.0*e1.powi(4)/512.0) * (8.0*mu).sin();
    let c1 = ep2 * fp.cos().powi(2);
    let t1 = fp.tan().powi(2);
    let n1 = e.a / (1.0 - e.e2 * fp.sin().powi(2)).sqrt();
    let r1 = e.a * (1.0 - e.e2) / (1.0 - e.e2 * fp.sin().powi(2)).powf(1.5);
    let d = (x - x0) / (n1 * k0);
    let phi = fp - (n1 * fp.tan() / r1) * (d*d/2.0 - (5.0 + 3.0*t1 + 10.0*c1 - 4.0*c1*c1 - 9.0*ep2) * d.powi(4)/24.0
        + (61.0 + 90.0*t1 + 298.0*c1 + 45.0*t1*t1 - 252.0*ep2 - 3.0*c1*c1) * d.powi(6)/720.0);
    let lam = lam0 + (d - (1.0 + 2.0*t1 + c1) * d.powi(3)/6.0 + (5.0 - 2.0*c1 + 28.0*t1 - 3.0*c1*c1 + 8.0*ep2 + 24.0*t1*t1) * d.powi(5)/120.0) / fp.cos();
    (deg(lam), deg(phi))
}

fn merid(e: Ellps, phi: f64) -> f64 {
    let es = e.e2;
    e.a * ((1.0 - es/4.0 - 3.0*es*es/64.0 - 5.0*es.powi(3)/256.0) * phi
        - (3.0*es/8.0 + 3.0*es*es/32.0 + 45.0*es.powi(3)/1024.0) * (2.0*phi).sin()
        + (15.0*es*es/256.0 + 45.0*es.powi(3)/1024.0) * (4.0*phi).sin()
        - (35.0*es.powi(3)/3072.0) * (6.0*phi).sin())
}

fn lcc_fwd(cfg: &Cfg, e: Ellps, lam: f64, phi: f64, lam0: f64, phi0: f64, x0: f64, y0: f64) -> (f64, f64) {
    let p1 = rad(val(cfg, "lat_1").unwrap_or(33.0));
    let p2 = rad(val(cfg, "lat_2").unwrap_or(p1.to_degrees()));
    let n = if (p1 - p2).abs() < 1e-12 { p1.sin() } else { (p1.cos().ln() - p2.cos().ln()) / ((FRAC_PI_4 + p2/2.0).tan().ln() - (FRAC_PI_4 + p1/2.0).tan().ln()) };
    let f = p1.cos() * (FRAC_PI_4 + p1/2.0).tan().powf(n) / n;
    let rho = e.a * f / (FRAC_PI_4 + phi/2.0).tan().powf(n);
    let rho0 = e.a * f / (FRAC_PI_4 + phi0/2.0).tan().powf(n);
    let th = n * (lam - lam0);
    (x0 + rho * th.sin(), y0 + rho0 - rho * th.cos())
}

fn aea_fwd(cfg: &Cfg, e: Ellps, lam: f64, phi: f64, lam0: f64, phi0: f64, x0: f64, y0: f64) -> (f64, f64) {
    let p1 = rad(val(cfg, "lat_1").unwrap_or(29.5));
    let p2 = rad(val(cfg, "lat_2").unwrap_or(45.5));
    let n = 0.5 * (p1.sin() + p2.sin());
    let c = p1.cos().powi(2) + 2.0*n*p1.sin();
    let theta = n * (lam - lam0);
    let rho = e.a * ((c - 2.0*n*phi.sin()).max(0.0)).sqrt() / n;
    let rho0 = e.a * ((c - 2.0*n*phi0.sin()).max(0.0)).sqrt() / n;
    (x0 + rho * theta.sin(), y0 + rho0 - rho * theta.cos())
}

fn fmt_num(v: f64, fmt: &str) -> String {
    let v = if v.abs() < 0.00000001 { 0.0 } else { v };
    if let Some(p) = fmt.strip_prefix("%.").and_then(|s| s.strip_suffix('f')).and_then(|s| s.parse::<usize>().ok()) {
        format!("{:.*}", p, v)
    } else if fmt == "%f" {
        format!("{:.6}", v)
    } else {
        format!("{:.2}", v)
    }
}

fn dms(v: f64, ew: bool) -> String {
    let hemi = if ew { if v < 0.0 { 'W' } else { 'E' } } else if v < 0.0 { 'S' } else { 'N' };
    let total_ms = (v.abs() * 3_600_000.0).round() as i64;
    let mut d = total_ms / 3_600_000;
    let rem = total_ms % 3_600_000;
    let mut m = rem / 60_000;
    let mut sec_ms = rem % 60_000;
    if m >= 60 {
        d += 1;
        m -= 60;
    }
    if sec_ms >= 60_000 {
        m += 1;
        sec_ms -= 60_000;
    }
    if sec_ms == 0 && m == 0 {
        format!("{}d{}", d, hemi)
    } else if sec_ms == 0 {
        format!("{}d{}'{}", d, m, hemi)
    } else {
        format!("{}d{}'{:.3}\"{}", d, m, sec_ms as f64 / 1000.0, hemi)
    }
}

fn verbose(cfg: &Cfg) {
    let name = match cfg.proj.as_str() {
        "merc" => "Mercator",
        "utm" => "Universal Transverse Mercator (UTM)",
        "tmerc" => "Transverse Mercator",
        "lcc" => "Lambert Conformal Conic",
        "aea" => "Albers Equal Area",
        _ => "Projection",
    };
    println!("#{}", name);
    println!("#\t{}", if cfg.proj == "merc" { "Cyl, Sph&Ell" } else { "Sph&Ell" });
    println!("# +proj={} +break_cs2cs_recursion +ellps=GRS80", cfg.proj);
}

fn list(kind: Option<&str>, verbose: bool) {
    match kind {
        Some("e") => {
            println!("    MERIT a=6378137.0      rf=298.257       MERIT 1983");
            println!("    GRS80 a=6378137.0      rf=298.257222101 GRS 1980(IUGG, 1980)");
            println!("    WGS84 a=6378137.0      rf=298.257223563 WGS 84");
            println!("   clrk66 a=6378206.4      b=6356583.8      Clarke 1866");
            println!("   sphere a=6370997.0      b=6370997.0      Normal Sphere (r=6370997)");
        }
        Some("u") => {
            println!("          mm 0.001                millimetre");
            println!("          cm 0.01                 centimetre");
            println!("           m 1                    metre");
            println!("          ft 0.3048               foot");
            println!("       us-ft 0.304800609601219    US survey foot");
            println!("          km 1000                 kilometre");
        }
        _ => {
            let rows = [
                ("aea", "Albers Equal Area", "Conic Sph&Ell"),
                ("aeqd", "Azimuthal Equidistant", "Azi, Sph&Ell"),
                ("cea", "Equal Area Cylindrical", "Cyl, Sph"),
                ("eqc", "Equidistant Cylindrical (Plate Caree)", "Cyl, Sph"),
                ("laea", "Lambert Azimuthal Equal Area", "Azi, Sph"),
                ("lcc", "Lambert Conformal Conic", "Conic Sph&Ell"),
                ("merc", "Mercator", "Cyl, Sph&Ell"),
                ("stere", "Stereographic", "Azi, Sph&Ell"),
                ("tmerc", "Transverse Mercator", "Cyl, Sph&Ell"),
                ("utm", "Universal Transverse Mercator (UTM)", "Cyl, Ell"),
                ("webmerc", "Web Mercator / Pseudo Mercator", "Cyl, Sph"),
            ];
            for (id, name, detail) in rows {
                println!("{} : {}", id, name);
                if verbose { println!("\t{}", detail); }
            }
        }
    }
}
