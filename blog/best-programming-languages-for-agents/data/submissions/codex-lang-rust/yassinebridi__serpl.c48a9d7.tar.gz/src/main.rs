use std::env;
use std::io::{self, IsTerminal, Read, Write};
use std::path::PathBuf;
use std::process;

const HELP: &str = "A simple terminal UI for search and replace, ala VS Code

Usage: executable [OPTIONS]

Options:
  -p, --project-root <PATH>  Path to the project root [default: .]
  -h, --help                 Print help
  -V, --version              Print version
";

const VERSION: &str = "serpl 0.3.4- (2026-04-20)

Authors: Yassine Bridi <ybridi@gmail.com>

Config directory: /home/agent/.config/serpl
";

#[derive(Debug)]
struct Args {
    project_root: PathBuf,
}

enum Action {
    Help,
    Version,
    Run(Args),
}

fn main() {
    match parse_args(env::args().skip(1).collect()) {
        Ok(Action::Help) => {
            print!("{HELP}");
        }
        Ok(Action::Version) => {
            print!("{VERSION}");
        }
        Ok(Action::Run(args)) => {
            if let Err(err) = run(args) {
                eprintln!("{err}");
                process::exit(1);
            }
        }
        Err(message) => {
            eprintln!("{message}");
            process::exit(2);
        }
    }
}

fn parse_args(args: Vec<String>) -> Result<Action, String> {
    let mut project_root = PathBuf::from(".");
    let mut i = 0;

    while i < args.len() {
        let arg = &args[i];
        match arg.as_str() {
            "-h" | "--help" => return Ok(Action::Help),
            "-V" | "--version" => return Ok(Action::Version),
            "-p" | "--project-root" => {
                i += 1;
                if i >= args.len() {
                    return Err(
                        "error: a value is required for '--project-root <PATH>' but none was supplied\n\nFor more information, try '--help'."
                            .to_string(),
                    );
                }
                project_root = PathBuf::from(&args[i]);
            }
            _ if arg.starts_with("--project-root=") => {
                let value = &arg["--project-root=".len()..];
                if value.is_empty() {
                    project_root = PathBuf::new();
                } else {
                    project_root = PathBuf::from(value);
                }
            }
            _ if arg.starts_with("-p") && arg.len() > 2 => {
                project_root = PathBuf::from(&arg[2..]);
            }
            _ if arg.starts_with('-') => {
                return Err(format!(
                    "error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'."
                ));
            }
            _ => {
                return Err(format!(
                    "error: unexpected argument '{arg}' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'."
                ));
            }
        }
        i += 1;
    }

    Ok(Action::Run(Args { project_root }))
}

fn run(args: Args) -> Result<(), String> {
    if !io::stdin().is_terminal() || !io::stdout().is_terminal() {
        return Err(
            "serpl error: Something went wrong\nError: \n   0: \u{1b}[91mResource temporarily unavailable (os error 11)\u{1b}[0m"
                .to_string(),
        );
    }

    interactive(args)
}

fn interactive(args: Args) -> Result<(), String> {
    let mut stdout = io::stdout();
    write!(
        stdout,
        "\u{1b}[?1049h\u{1b}[?25l\u{1b}[2J\u{1b}[H\
         serpl 0.3.4\n\
         Project root: {}\n\n\
         Search: \n\
         Replace: \n\n\
         Ctrl-D / Ctrl-C: Quit    Tab: switch field    Ctrl-O: replace\n\
         \u{1b}[?25h",
        args.project_root.display()
    )
    .map_err(|e| e.to_string())?;
    stdout.flush().map_err(|e| e.to_string())?;

    let mut stdin = io::stdin();
    let mut buffer = [0_u8; 1];
    loop {
        match stdin.read(&mut buffer) {
            Ok(0) => break,
            Ok(_) => match buffer[0] {
                3 | 4 => break,
                byte if byte.is_ascii_graphic() || byte == b' ' => {
                    write!(stdout, "{}", byte as char).map_err(|e| e.to_string())?;
                    stdout.flush().map_err(|e| e.to_string())?;
                }
                _ => {}
            },
            Err(e) => return Err(e.to_string()),
        }
    }

    write!(stdout, "\u{1b}[?1049l\u{1b}[?25h").map_err(|e| e.to_string())?;
    stdout.flush().map_err(|e| e.to_string())?;
    Ok(())
}
