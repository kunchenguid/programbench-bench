use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::env;
use std::ffi::OsStr;
use std::fs;
use std::io::{self, Read};
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

const VERSION: &str = "0.21.1";

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum BytesFormat { Plain, Metric, Binary }

#[derive(Copy, Clone, Debug, PartialEq, Eq)]
enum Quantity { ApparentSize, BlockSize, BlockCount }

#[derive(Debug)]
struct Cli {
    json_input: bool,
    json_output: bool,
    bytes_format: BytesFormat,
    deduplicate_hardlinks: bool,
    top_down: bool,
    align_right: bool,
    quantity: Quantity,
    max_depth: usize,
    total_width: Option<usize>,
    column_width: Option<Vec<usize>>,
    min_ratio: f64,
    no_sort: bool,
    silent_errors: bool,
    progress: bool,
    threads: String,
    omit_json_shared_details: bool,
    omit_json_shared_summary: bool,
    files: Vec<PathBuf>,
}

impl Default for Cli {
    fn default() -> Self { Self { json_input:false, json_output:false, bytes_format:BytesFormat::Metric, deduplicate_hardlinks:false, top_down:false, align_right:false, quantity:Quantity::BlockSize, max_depth:10, total_width:None, column_width:None, min_ratio:0.01, no_sort:false, silent_errors:false, progress:false, threads:"auto".into(), omit_json_shared_details:false, omit_json_shared_summary:false, files:Vec::new() } }
}

fn parse_depth(s: &str) -> Result<usize, String> {
    if s == "inf" { return Ok(usize::MAX); }
    let n: usize = s.parse().map_err(|_| "Value is neither \"inf\" nor a positive integer: invalid digit found in string".to_string())?;
    if n == 0 { Err("Value is neither \"inf\" nor a positive integer: number would be zero for non-zero type".into()) } else { Ok(n) }
}

fn need_value(args: &mut impl Iterator<Item=String>, opt: &str) -> String {
    args.next().unwrap_or_else(|| { eprintln!("error: a value is required for '{opt}' but none was supplied"); std::process::exit(2); })
}
fn parse_args() -> Cli {
    let mut cli = Cli::default();
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        let (key, val) = if let Some((k,v)) = arg.split_once('=') { (k.to_string(), Some(v.to_string())) } else { (arg.clone(), None) };
        let mut value = |name: &str| val.clone().unwrap_or_else(|| need_value(&mut it, name));
        match key.as_str() {
            "-h"|"--help" => { print_help(false); std::process::exit(0); }
            "-V"|"--version" => { println!("pdu {VERSION}"); std::process::exit(0); }
            "--json-input" => cli.json_input = true,
            "--json-output" => cli.json_output = true,
            "-H"|"--deduplicate-hardlinks"|"--detect-links"|"--dedupe-links" => cli.deduplicate_hardlinks = true,
            "--top-down" => cli.top_down = true,
            "--align-right" => cli.align_right = true,
            "--no-sort" => cli.no_sort = true,
            "-s"|"--silent-errors"|"--no-errors" => cli.silent_errors = true,
            "-p"|"--progress" => cli.progress = true,
            "--omit-json-shared-details" => cli.omit_json_shared_details = true,
            "--omit-json-shared-summary" => cli.omit_json_shared_summary = true,
            "-b"|"--bytes-format" => cli.bytes_format = match value(&key).as_str() { "plain"=>BytesFormat::Plain, "metric"=>BytesFormat::Metric, "binary"=>BytesFormat::Binary, v=>bad_value(&key,v,"[possible values: plain, metric, binary]") },
            "-q"|"--quantity" => cli.quantity = match value(&key).as_str() { "apparent-size"=>Quantity::ApparentSize, "block-size"=>Quantity::BlockSize, "block-count"=>Quantity::BlockCount, v=>bad_value(&key,v,"[possible values: apparent-size, block-size, block-count]") },
            "-d"|"--max-depth"|"--depth" => { let v=value(&key); cli.max_depth = parse_depth(&v).unwrap_or_else(|e| { eprintln!("error: invalid value '{v}' for '--max-depth <MAX_DEPTH>': {e}\n\nFor more information, try '--help'."); std::process::exit(2); }); },
            "-w"|"--total-width"|"--width" => cli.total_width = value(&key).parse().ok(),
            "--column-width" => { let a=value(&key).parse().unwrap_or(40); let b=need_value(&mut it,"--column-width").parse().unwrap_or(60); cli.column_width=Some(vec![a,b]); },
            "-m"|"--min-ratio" => cli.min_ratio = value(&key).parse().unwrap_or(0.01),
            "--threads" => cli.threads = value(&key),
            "--" => { cli.files.extend(it.map(PathBuf::from)); break; }
            x if x.starts_with('-') => { eprintln!("error: unexpected argument '{x}' found\n\n  tip: to pass '{x}' as a value, use '-- {x}'\n\nUsage: executable [OPTIONS] [FILES]...\n\nFor more information, try '--help'."); std::process::exit(2); }
            _ => cli.files.push(PathBuf::from(arg)),
        }
    }
    cli
}
fn bad_value<T>(opt:&str, v:&str, msg:&str) -> T { eprintln!("error: invalid value '{v}' for '{opt}': {msg}\n\nFor more information, try '--help'."); std::process::exit(2); }
fn print_help(_long: bool) { println!("Summarize disk usage of the set of files, recursively for directories.\n\nUsage: executable [OPTIONS] [FILES]...\n\nArguments:\n  [FILES]...  List of files and/or directories\n\nOptions:\n      --json-input          Read JSON data from stdin\n      --json-output         Print JSON data instead of an ASCII chart\n  -b, --bytes-format <BYTES_FORMAT>  How to display the numbers of bytes [default: metric] [possible values: plain, metric, binary]\n  -H, --deduplicate-hardlinks        Detect and subtract the sizes of hardlinks from their parent directory totals [aliases: --detect-links, --dedupe-links]\n      --top-down           Print the tree top-down instead of bottom-up\n      --align-right        Set the root of the bars to the right\n  -q, --quantity <QUANTITY>  Aspect of the files/directories to be measured [default: block-size] [possible values: apparent-size, block-size, block-count]\n  -d, --max-depth <MAX_DEPTH>  Maximum depth to display the data. Could be either \"inf\" or a positive integer [default: 10] [aliases: --depth]\n  -w, --total-width <TOTAL_WIDTH>  Width of the visualization [aliases: --width]\n      --column-width <TREE_WIDTH> <BAR_WIDTH>  Maximum widths of the tree column and width of the bar column\n  -m, --min-ratio <MIN_RATIO>  Minimal size proportion required to appear [default: 0.01]\n      --no-sort            Do not sort the branches in the tree\n  -s, --silent-errors      Prevent filesystem error messages from appearing in stderr [aliases: --no-errors]\n  -p, --progress           Report progress being made at the expense of performance\n      --threads <THREADS>  Set the maximum number of threads to spawn. Could be either \"auto\", \"max\", or a positive integer [default: auto]\n      --omit-json-shared-details   Do not output `.shared.details` in the JSON output\n      --omit-json-shared-summary   Do not output `.shared.summary` in the JSON output\n  -h, --help               Print help (see more with '--help')\n  -V, --version            Print version"); }

#[derive(Clone, Debug, Serialize, Deserialize)]
struct Node { name: String, size: u64, #[serde(default)] children: Vec<Node> }

#[derive(Clone, Debug, Serialize, Deserialize)]
struct SharedDetail { ino: u64, size: u64, links: u64, paths: Vec<String> }
#[derive(Clone, Debug, Serialize, Deserialize)]
struct SharedSummary { inodes: u64, exclusive_inodes: u64, all_links: u64, detected_links: u64, exclusive_links: u64, shared_size: u64, exclusive_shared_size: u64 }
#[derive(Clone, Debug, Serialize, Deserialize)]
struct Shared { #[serde(skip_serializing_if = "Option::is_none")] details: Option<Vec<SharedDetail>>, #[serde(skip_serializing_if = "Option::is_none")] summary: Option<SharedSummary> }
#[derive(Clone, Debug, Serialize, Deserialize)]
struct Output { #[serde(rename = "schema-version")] schema_version: String, pdu: String, unit: String, tree: Node, #[serde(skip_serializing_if = "Option::is_none")] shared: Option<Shared> }

#[derive(Clone)]
struct RawNode { name: String, size: u64, dev: u64, ino: u64, nlink: u64, path: String, is_dir: bool, children: Vec<RawNode> }

fn main() {
    let cli = parse_args();
    if let Err(e) = run(cli) { eprintln!("[error] {e}"); std::process::exit(3); }
}

fn run(cli: Cli) -> Result<(), String> {
    let mut out = if cli.json_input {
        let mut s = String::new(); io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        serde_json::from_str::<Output>(&s).map_err(|e| format!("DeserializationFailure: {e}"))?
    } else {
        build_output(&cli)
    };
    filter_tree(&mut out.tree, cli.max_depth, cli.min_ratio);
    if cli.json_output {
        if let Some(shared) = out.shared.as_mut() {
            if cli.omit_json_shared_details { shared.details = None; }
            if cli.omit_json_shared_summary { shared.summary = None; }
            if shared.details.is_none() && shared.summary.is_none() { out.shared = None; }
        }
        println!("{}", serde_json::to_string(&out).map_err(|e| e.to_string())?);
    } else { print_chart(&out.tree, &cli); }
    Ok(())
}

fn build_output(cli: &Cli) -> Output {
    let paths = if cli.files.is_empty() { vec![PathBuf::from(".")] } else { cli.files.clone() };
    let mut errors = Vec::new();
    let mut roots = Vec::new();
    for p in &paths { roots.push(scan(p, cli.quantity, &mut errors, cli.silent_errors)); }
    for e in errors { eprintln!("[error] {e}"); }
    let mut raw = if roots.len() == 1 { roots.remove(0) } else {
        let size = roots.iter().map(|n| n.size).sum();
        RawNode { name: "(total)".into(), size, dev: 0, ino: 0, nlink: 1, path: "(total)".into(), is_dir: true, children: roots }
    };
    if !cli.no_sort { sort_raw(&mut raw); }
    let (shared, subtract) = if cli.deduplicate_hardlinks { hardlink_info(&raw) } else { (None, HashMap::new()) };
    let mut seen_links = std::collections::HashSet::new();
    apply_dedupe(&mut raw, &subtract, &mut seen_links);
    Output { schema_version: "2024-11-02".into(), pdu: VERSION.into(), unit: if cli.quantity == Quantity::BlockCount { "blocks" } else { "bytes" }.into(), tree: to_node(&raw), shared }
}

fn scan(path: &Path, q: Quantity, errors: &mut Vec<String>, silent: bool) -> RawNode {
    match fs::symlink_metadata(path) {
        Ok(md) => {
            let is_dir = md.is_dir();
            let own = match q { Quantity::ApparentSize => md.size(), Quantity::BlockSize => md.blocks() * 512, Quantity::BlockCount => md.blocks() };
            let name = display_name(path);
            let mut node = RawNode { name, size: own, dev: md.dev(), ino: md.ino(), nlink: md.nlink(), path: path.to_string_lossy().into_owned(), is_dir, children: Vec::new() };
            if is_dir {
                match fs::read_dir(path) {
                    Ok(rd) => for ent in rd { match ent { Ok(e) => node.children.push(scan(&e.path(), q, errors, silent)), Err(e) => if !silent { errors.push(format!("read_dir {:?}: {e}", path)); } } },
                    Err(e) => if !silent { errors.push(format!("read_dir {:?}: {e}", path)); },
                }
                node.size += node.children.iter().map(|c| c.size).sum::<u64>();
            }
            node
        }
        Err(e) => { if !silent { errors.push(format!("symlink_metadata {:?}: {e}", path)); } RawNode { name: path.to_string_lossy().into_owned(), size: 0, dev: 0, ino: 0, nlink: 1, path: path.to_string_lossy().into_owned(), is_dir: false, children: Vec::new() } }
    }
}

fn display_name(path: &Path) -> String {
    if path == Path::new(".") { return ".".into(); }
    path.file_name().and_then(OsStr::to_str).map(|s| s.to_string()).unwrap_or_else(|| path.to_string_lossy().into_owned())
}
fn sort_raw(n: &mut RawNode) { for c in &mut n.children { sort_raw(c); } n.children.sort_by(|a,b| b.size.cmp(&a.size)); }
fn to_node(r: &RawNode) -> Node { Node { name: r.name.clone(), size: r.size, children: r.children.iter().map(to_node).collect() } }

fn hardlink_info(root: &RawNode) -> (Option<Shared>, HashMap<(u64,u64), u64>) {
    let mut map: HashMap<(u64,u64), Vec<&RawNode>> = HashMap::new(); collect_links(root, &mut map);
    let mut details = Vec::new(); let mut subtract = HashMap::new();
    for ((dev, ino), nodes) in map {
        if ino != 0 && nodes.len() > 1 {
            let size = nodes[0].size; let links = nodes[0].nlink;
            subtract.insert((dev, ino), size.saturating_mul(nodes.len().saturating_sub(1) as u64));
            details.push(SharedDetail { ino, size, links, paths: nodes.iter().map(|n| n.path.clone()).collect() });
        }
    }
    details.sort_by_key(|d| d.ino);
    if details.is_empty() { return (None, subtract); }
    let inodes = details.len() as u64;
    let all_links = details.iter().map(|d| d.links).sum();
    let detected_links = details.iter().map(|d| d.paths.len() as u64).sum();
    let shared_size = details.iter().map(|d| d.size).sum();
    let summary = SharedSummary { inodes, exclusive_inodes: inodes, all_links, detected_links, exclusive_links: detected_links, shared_size, exclusive_shared_size: shared_size };
    (Some(Shared { details: Some(details), summary: Some(summary) }), subtract)
}
fn collect_links<'a>(n: &'a RawNode, map: &mut HashMap<(u64,u64), Vec<&'a RawNode>>) { if !n.is_dir && n.nlink > 1 { map.entry((n.dev,n.ino)).or_default().push(n); } for c in &n.children { collect_links(c, map); } }
fn apply_dedupe(n: &mut RawNode, sub: &HashMap<(u64,u64), u64>, seen: &mut std::collections::HashSet<(u64,u64)>) -> u64 { let mut total = 0; for c in &mut n.children { total += apply_dedupe(c, sub, seen); } if n.is_dir { n.size = n.size.saturating_sub(total); } else if sub.contains_key(&(n.dev,n.ino)) && !seen.insert((n.dev,n.ino)) { total += n.size; } total }

fn filter_tree(n: &mut Node, max_depth: usize, min_ratio: f64) { let total = n.size; filter_rec(n, 0, max_depth, min_ratio, total); }
fn filter_rec(n: &mut Node, depth: usize, max_depth: usize, min_ratio: f64, total: u64) { if max_depth != usize::MAX && depth + 1 >= max_depth { n.children.clear(); return; } for c in &mut n.children { filter_rec(c, depth+1, max_depth, min_ratio, total); } n.children.retain(|c| total == 0 || (c.size as f64 / total as f64) >= min_ratio); }

fn print_chart(root: &Node, cli: &Cli) {
    let mut rows = Vec::new(); flatten(root, 0, cli.top_down, &mut rows);
    let tree_w = cli.column_width.as_ref().map(|v| v[0]).unwrap_or(40).min(80);
    let bar_w = cli.column_width.as_ref().map(|v| v[1]).or(cli.total_width.map(|w| w.saturating_sub(tree_w+16))).unwrap_or(60).max(1).min(160);
    let root_size = root.size.max(1);
    for (depth, node) in rows {
        let pct = (node.size as f64 * 100.0 / root_size as f64).round() as u64;
        let fill = ((node.size as f64 * bar_w as f64 / root_size as f64).round() as usize).min(bar_w);
        let bar = format!("{}{}", "█".repeat(fill), " ".repeat(bar_w-fill));
        let label = format!("{}{}", "  ".repeat(depth), node.name);
        let size = format_size(node.size, cli.bytes_format);
        if cli.align_right { println!("{:>6} {:>width$} │{}│{:>3}%", size, label, bar, pct, width=tree_w); }
        else { println!("{:>6} {:<width$} │{}│{:>3}%", size, label, bar, pct, width=tree_w); }
    }
}
fn flatten<'a>(n: &'a Node, depth: usize, top: bool, rows: &mut Vec<(usize, &'a Node)>) { if top { rows.push((depth,n)); } for c in &n.children { flatten(c, depth+1, top, rows); } if !top { rows.push((depth,n)); } }
fn format_size(n: u64, fmt: BytesFormat) -> String { match fmt { BytesFormat::Plain => n.to_string(), BytesFormat::Metric => human(n as f64, 1000.0), BytesFormat::Binary => human(n as f64, 1024.0) } }
fn human(mut v: f64, base: f64) -> String { let units = ["", "K", "M", "G", "T", "P"]; let mut i=0; while v >= base && i < units.len()-1 { v/=base; i+=1; } if i==0 { format!("{}", v as u64) } else { format!("{:.1}{}", v, units[i]) } }
