use serde_json::{Map, Number, Value};
use std::collections::{BTreeMap, BTreeSet};
use std::env;
use std::ffi::{CStr, CString};
use std::fs;
use std::io::{self, Read};
use std::os::raw::{c_char, c_double, c_int, c_void};
use std::path::Path;
use std::ptr;

#[allow(non_camel_case_types)]
type sqlite3 = c_void;
#[allow(non_camel_case_types)]
type sqlite3_stmt = c_void;

#[link(name = "dl")]
extern "C" {
    fn dlopen(filename: *const c_char, flags: c_int) -> *mut c_void;
    fn dlsym(handle: *mut c_void, symbol: *const c_char) -> *mut c_void;
}

const RTLD_NOW: c_int = 2;
const SQLITE_ROW: c_int = 100;
const SQLITE_DONE: c_int = 101;
const SQLITE_INTEGER: c_int = 1;
const SQLITE_FLOAT: c_int = 2;
const SQLITE_TEXT: c_int = 3;
const SQLITE_NULL: c_int = 5;

type SqliteOpen = unsafe extern "C" fn(*const c_char, *mut *mut sqlite3) -> c_int;
type SqliteClose = unsafe extern "C" fn(*mut sqlite3) -> c_int;
type SqliteExec = unsafe extern "C" fn(
    *mut sqlite3,
    *const c_char,
    Option<unsafe extern "C" fn(*mut c_void, c_int, *mut *mut c_char, *mut *mut c_char) -> c_int>,
    *mut c_void,
    *mut *mut c_char,
) -> c_int;
type SqlitePrepare = unsafe extern "C" fn(
    *mut sqlite3,
    *const c_char,
    c_int,
    *mut *mut sqlite3_stmt,
    *mut *const c_char,
) -> c_int;
type SqliteStep = unsafe extern "C" fn(*mut sqlite3_stmt) -> c_int;
type SqliteFinalize = unsafe extern "C" fn(*mut sqlite3_stmt) -> c_int;
type SqliteColumnCount = unsafe extern "C" fn(*mut sqlite3_stmt) -> c_int;
type SqliteColumnName = unsafe extern "C" fn(*mut sqlite3_stmt, c_int) -> *const c_char;
type SqliteColumnType = unsafe extern "C" fn(*mut sqlite3_stmt, c_int) -> c_int;
type SqliteColumnText = unsafe extern "C" fn(*mut sqlite3_stmt, c_int) -> *const u8;
type SqliteColumnInt64 = unsafe extern "C" fn(*mut sqlite3_stmt, c_int) -> i64;
type SqliteColumnDouble = unsafe extern "C" fn(*mut sqlite3_stmt, c_int) -> c_double;
type SqliteErrmsg = unsafe extern "C" fn(*mut sqlite3) -> *const c_char;
type SqliteFree = unsafe extern "C" fn(*mut c_void);

struct SqliteApi {
    open: SqliteOpen,
    close: SqliteClose,
    exec: SqliteExec,
    prepare: SqlitePrepare,
    step: SqliteStep,
    finalize: SqliteFinalize,
    column_count: SqliteColumnCount,
    column_name: SqliteColumnName,
    column_type: SqliteColumnType,
    column_text: SqliteColumnText,
    column_int64: SqliteColumnInt64,
    column_double: SqliteColumnDouble,
    errmsg: SqliteErrmsg,
    free: SqliteFree,
}

impl SqliteApi {
    unsafe fn load() -> Result<Self, String> {
        let lib = CString::new("libsqlite3.so.0").unwrap();
        let handle = dlopen(lib.as_ptr(), RTLD_NOW);
        if handle.is_null() {
            return Err("failed to load sqlite3".to_string());
        }
        unsafe fn sym<T>(handle: *mut c_void, name: &str) -> T {
            let cname = CString::new(name).unwrap();
            let ptr = dlsym(handle, cname.as_ptr());
            std::mem::transmute_copy(&ptr)
        }
        Ok(Self {
            open: sym(handle, "sqlite3_open"),
            close: sym(handle, "sqlite3_close"),
            exec: sym(handle, "sqlite3_exec"),
            prepare: sym(handle, "sqlite3_prepare_v2"),
            step: sym(handle, "sqlite3_step"),
            finalize: sym(handle, "sqlite3_finalize"),
            column_count: sym(handle, "sqlite3_column_count"),
            column_name: sym(handle, "sqlite3_column_name"),
            column_type: sym(handle, "sqlite3_column_type"),
            column_text: sym(handle, "sqlite3_column_text"),
            column_int64: sym(handle, "sqlite3_column_int64"),
            column_double: sym(handle, "sqlite3_column_double"),
            errmsg: sym(handle, "sqlite3_errmsg"),
            free: sym(handle, "sqlite3_free"),
        })
    }
}

#[derive(Clone, Debug)]
struct Row(BTreeMap<String, Cell>, Vec<String>);

#[derive(Clone, Debug)]
enum Cell {
    Null,
    Text(String),
    Integer(i64),
    Float(f64),
    Bool(bool),
}

impl Cell {
    fn to_json(&self) -> Value {
        match self {
            Cell::Null => Value::Null,
            Cell::Text(s) => Value::String(s.clone()),
            Cell::Integer(n) => Value::Number(Number::from(*n)),
            Cell::Float(f) => Number::from_f64(*f).map(Value::Number).unwrap_or(Value::Null),
            Cell::Bool(b) => Value::Bool(*b),
        }
    }
    fn display(&self) -> String {
        match self {
            Cell::Null => String::new(),
            Cell::Text(s) => s.clone(),
            Cell::Integer(n) => n.to_string(),
            Cell::Float(f) => {
                let mut s = f.to_string();
                if s.ends_with(".0") {
                    s.truncate(s.len() - 2);
                }
                s
            }
            Cell::Bool(b) => b.to_string(),
        }
    }
    fn schema_kind(&self) -> &'static str {
        match self {
            Cell::Integer(_) | Cell::Float(_) => "number",
            Cell::Bool(_) => "boolean",
            Cell::Null => "null",
            Cell::Text(_) => "string",
        }
    }
}

struct Opts {
    pretty: bool,
    schema: bool,
    stream_format: Option<String>,
    query_file: Option<String>,
    interactive: bool,
    args: Vec<String>,
}

fn print_help() {
    println!(
        "dsq (Version latest) - commandline SQL engine for data files\n\nUsage:  dsq [file...] $query\n        dsq $file [query]\n        cat $file | dsq -s $filetype [query]\n        dsq $file -f $queryfile\n\ndsq is a tool for running SQL on one or more data files. It uses\nSQLite's SQL dialect. Files as tables are accessible via \"{{N}}\" where N\nis the 0-based index of the file in the commandline.\n\nThe shorthand \"{{}}\" is replaced with \"{{0}}\".\n\nExamples:\n\n    # This simply dumps the CSV as JSON\n    $ dsq test.csv\n\n    # This dumps the first 10 rows of the parquet file as JSON.\n    $ dsq data.parquet \"SELECT * FROM {{}} LIMIT 10\"\n\n    # This joins two datasets of differing origin types (CSV and JSON).\n    $ dsq testdata/join/users.csv testdata/join/ages.json \\\n          \"select {{0}}.name, {{1}}.age from {{0}} join {{1}} on {{0}}.id = {{1}}.id\"\n\nSee the repo for more details: https://github.com/multiprocessio/dsq"
    );
}

fn parse_args() -> Result<Opts, i32> {
    let mut pretty = false;
    let mut schema = false;
    let mut stream_format = None;
    let mut query_file = None;
    let mut interactive = false;
    let mut rest = Vec::new();
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                print_help();
                return Err(0);
            }
            "--version" | "-v" => {
                println!("dsq latest");
                return Err(0);
            }
            "-p" | "--pretty" => pretty = true,
            "--schema" => schema = true,
            "-C" | "--cache" => {}
            "-i" | "--interactive" => interactive = true,
            "-s" | "--source" => {
                if let Some(v) = it.next() {
                    stream_format = Some(v);
                } else {
                    eprintln!("Missing source format.");
                    return Err(1);
                }
            }
            "-f" | "--file" => {
                if let Some(v) = it.next() {
                    query_file = Some(v);
                } else {
                    eprintln!("Missing query file.");
                    return Err(1);
                }
            }
            _ => rest.push(arg),
        }
    }
    Ok(Opts { pretty, schema, stream_format, query_file, interactive, args: rest })
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err(code) => std::process::exit(code),
    };
    if opts.interactive {
        eprintln!("Interactive mode is not supported in this reimplementation.");
        std::process::exit(1);
    }
    if let Err(e) = run(opts) {
        eprintln!("{e}");
        std::process::exit(1);
    }
}

fn run(opts: Opts) -> Result<(), String> {
    let mut inputs: Vec<(String, String, String)> = Vec::new();
    let mut query: Option<String> = None;
    if let Some(fmt) = opts.stream_format.clone() {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        inputs.push(("stdin".to_string(), fmt, s));
        if !opts.args.is_empty() {
            query = Some(opts.args.join(" "));
        }
    } else {
        if opts.args.is_empty() {
            return Err("No input files.".to_string());
        }
        let mut files = opts.args.clone();
        if let Some(last) = files.last() {
            let is_file = Path::new(last).exists();
            if !is_file || looks_like_sql(last) {
                query = files.pop();
            }
        }
        for path in files {
            let fmt = format_for_path(&path)?;
            let content = fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?;
            inputs.push((path, fmt, content));
        }
    }
    if let Some(qf) = opts.query_file {
        query = Some(fs::read_to_string(&qf).map_err(|e| format!("{qf}: {e}"))?);
    }
    if inputs.is_empty() {
        return Err("No input files.".to_string());
    }
    if inputs.iter().any(|(_, fmt, _)| fmt == "raw") {
        if opts.schema {
            println!("{{\n  \"kind\": \"scalar\",\n  \"scalar\": \"string\"\n}}");
            return Ok(());
        }
        if query.is_some() {
            return Err(format!("Input is not an array of objects: {}.", inputs[0].0));
        }
        println!("{}", serde_json::to_string(&inputs[0].2).unwrap());
        return Ok(());
    }
    let mut tables = Vec::new();
    for (_, fmt, content) in &inputs {
        tables.push(parse_content(fmt, content)?);
    }
    if opts.schema {
        println!("{}", serde_json::to_string_pretty(&schema_json(&tables[0])).unwrap());
        return Ok(());
    }
    if query.is_none() {
        if opts.pretty {
            print_table(&tables[0]);
        } else {
            print_json_rows(&tables[0]);
        }
        return Ok(());
    }
    let sql = query.unwrap();
    let rows = execute_sql(&tables, &rewrite_query(&sql, tables.len()))?;
    if opts.pretty {
        print_table(&rows);
    } else {
        print_json_rows(&rows);
    }
    Ok(())
}

fn looks_like_sql(s: &str) -> bool {
    let l = s.trim_start().to_ascii_lowercase();
    l.starts_with("select") || l.starts_with("with") || l.starts_with("pragma")
}

fn format_for_path(path: &str) -> Result<String, String> {
    let ext = Path::new(path).extension().and_then(|s| s.to_str()).unwrap_or("").to_ascii_lowercase();
    match ext.as_str() {
        "csv" => Ok("csv".to_string()),
        "tsv" => Ok("tsv".to_string()),
        "json" => Ok("json".to_string()),
        "ndjson" | "jsonl" => Ok("ndjson".to_string()),
        "logfmt" => Ok("logfmt".to_string()),
        "txt" | "text" => Ok("raw".to_string()),
        "" => Err(format!("Unknown mimetype for file: {path}.")),
        _ => Err(format!("Unknown mimetype for file: {path}.")),
    }
}

fn parse_content(fmt: &str, content: &str) -> Result<Vec<Row>, String> {
    match fmt.to_ascii_lowercase().as_str() {
        "csv" => parse_delimited(content, ','),
        "tsv" => parse_delimited(content, '\t'),
        "json" => parse_jsonish(content),
        "ndjson" | "jsonl" => parse_ndjson(content),
        "logfmt" => Ok(parse_logfmt(content)),
        other => Err(format!("Unknown source format: {other}")),
    }
}

fn parse_delimited(content: &str, delim: char) -> Result<Vec<Row>, String> {
    let records = parse_records(content, delim);
    if records.is_empty() {
        return Ok(Vec::new());
    }
    let headers = records[0].clone();
    let mut rows = Vec::new();
    for rec in records.into_iter().skip(1) {
        if rec.len() == 1 && rec[0].is_empty() {
            continue;
        }
        let mut map = BTreeMap::new();
        for (i, h) in headers.iter().enumerate() {
            map.insert(h.clone(), Cell::Text(rec.get(i).cloned().unwrap_or_default()));
        }
        rows.push(Row(map, headers.clone()));
    }
    Ok(rows)
}

fn parse_records(content: &str, delim: char) -> Vec<Vec<String>> {
    let mut out = Vec::new();
    let mut row = Vec::new();
    let mut field = String::new();
    let mut chars = content.chars().peekable();
    let mut quoted = false;
    while let Some(ch) = chars.next() {
        if quoted {
            if ch == '"' {
                if chars.peek() == Some(&'"') {
                    chars.next();
                    field.push('"');
                } else {
                    quoted = false;
                }
            } else {
                field.push(ch);
            }
        } else if ch == '"' && field.is_empty() {
            quoted = true;
        } else if ch == delim {
            row.push(std::mem::take(&mut field));
        } else if ch == '\n' {
            row.push(std::mem::take(&mut field));
            out.push(std::mem::take(&mut row));
        } else if ch == '\r' {
        } else {
            field.push(ch);
        }
    }
    if !field.is_empty() || !row.is_empty() {
        row.push(field);
        out.push(row);
    }
    out
}

fn parse_jsonish(content: &str) -> Result<Vec<Row>, String> {
    match serde_json::from_str::<Value>(content) {
        Ok(Value::Array(a)) => Ok(a.iter().map(value_to_row).collect()),
        Ok(v @ Value::Object(_)) => Ok(vec![value_to_row(&v)]),
        Ok(_) => Ok(Vec::new()),
        Err(_) => parse_ndjson(content),
    }
}

fn parse_ndjson(content: &str) -> Result<Vec<Row>, String> {
    let mut rows = Vec::new();
    for line in content.lines() {
        if line.trim().is_empty() {
            continue;
        }
        let v: Value = serde_json::from_str(line).map_err(|e| e.to_string())?;
        rows.push(value_to_row(&v));
    }
    Ok(rows)
}

fn value_to_row(v: &Value) -> Row {
    let mut map = BTreeMap::new();
    let mut order = Vec::new();
    if let Value::Object(obj) = v {
        for (k, v) in obj {
            order.push(k.clone());
            map.insert(k.clone(), value_to_cell(v));
        }
    } else {
        order.push("value".to_string());
        map.insert("value".to_string(), value_to_cell(v));
    }
    Row(map, order)
}

fn value_to_cell(v: &Value) -> Cell {
    match v {
        Value::Null => Cell::Null,
        Value::Bool(b) => Cell::Bool(*b),
        Value::Number(n) => n.as_i64().map(Cell::Integer).unwrap_or_else(|| Cell::Float(n.as_f64().unwrap_or(0.0))),
        Value::String(s) => Cell::Text(s.clone()),
        other => Cell::Text(serde_json::to_string(other).unwrap_or_default()),
    }
}

fn parse_logfmt(content: &str) -> Vec<Row> {
    let mut rows = Vec::new();
    for line in content.lines() {
        let mut map = BTreeMap::new();
        let mut order = Vec::new();
        let mut i = 0;
        let bytes = line.as_bytes();
        while i < bytes.len() {
            while i < bytes.len() && bytes[i].is_ascii_whitespace() {
                i += 1;
            }
            let start = i;
            while i < bytes.len() && bytes[i] != b'=' && !bytes[i].is_ascii_whitespace() {
                i += 1;
            }
            if i >= bytes.len() || bytes[i] != b'=' {
                while i < bytes.len() && !bytes[i].is_ascii_whitespace() {
                    i += 1;
                }
                continue;
            }
            let key = &line[start..i];
            i += 1;
            let val = if i < bytes.len() && bytes[i] == b'"' {
                i += 1;
                let start = i;
                while i < bytes.len() && bytes[i] != b'"' {
                    i += 1;
                }
                let v = line[start..i].to_string();
                if i < bytes.len() {
                    i += 1;
                }
                v
            } else {
                let start = i;
                while i < bytes.len() && !bytes[i].is_ascii_whitespace() {
                    i += 1;
                }
                line[start..i].to_string()
            };
            let key = key.to_string();
            order.push(key.clone());
            map.insert(key, Cell::Text(val));
        }
        if !map.is_empty() {
            rows.push(Row(map, order));
        }
    }
    rows
}

fn schema_json(rows: &[Row]) -> Value {
    let mut fields = Map::new();
    let mut keys = Vec::new();
    let mut seen = BTreeSet::new();
    for row in rows {
        let row_keys: Vec<String> = if row.1.is_empty() { row.0.keys().cloned().collect() } else { row.1.clone() };
        for k in row_keys {
            if row.0.contains_key(&k) && seen.insert(k.clone()) {
                keys.push(k);
            }
        }
    }
    for k in keys {
        let kind = rows.iter().find_map(|r| r.0.get(&k)).map(|c| c.schema_kind()).unwrap_or("string");
        let mut scalar = Map::new();
        scalar.insert("kind".to_string(), Value::String("scalar".to_string()));
        scalar.insert("scalar".to_string(), Value::String(kind.to_string()));
        fields.insert(k, Value::Object(scalar));
    }
    let mut object = Map::new();
    object.insert("kind".to_string(), Value::String("object".to_string()));
    object.insert("object".to_string(), Value::Object(fields));
    let mut array = Map::new();
    array.insert("kind".to_string(), Value::String("array".to_string()));
    array.insert("array".to_string(), Value::Object(object));
    Value::Object(array)
}

fn rewrite_query(sql: &str, n: usize) -> String {
    let mut s = sql.replace("{}", "t0");
    for i in 0..n {
        s = s.replace(&format!("{{{i}}}"), &format!("t{i}"));
    }
    s
}

fn quote_ident(s: &str) -> String {
    format!("\"{}\"", s.replace('"', "\"\""))
}

fn sql_lit(cell: &Cell) -> String {
    match cell {
        Cell::Null => "NULL".to_string(),
        Cell::Integer(n) => n.to_string(),
        Cell::Float(f) => f.to_string(),
        Cell::Bool(b) => if *b { "1" } else { "0" }.to_string(),
        Cell::Text(s) => format!("'{}'", s.replace('\'', "''")),
    }
}

fn execute_sql(tables: &[Vec<Row>], query: &str) -> Result<Vec<Row>, String> {
    unsafe {
        let api = SqliteApi::load()?;
        let mut db: *mut sqlite3 = ptr::null_mut();
        let mem = CString::new(":memory:").unwrap();
        if (api.open)(mem.as_ptr(), &mut db) != 0 {
            return Err("failed to open sqlite database".to_string());
        }
        for (i, table) in tables.iter().enumerate() {
            load_table(&api, db, &format!("t{i}"), table)?;
        }
        let result = query_rows(&api, db, query);
        (api.close)(db);
        result
    }
}

unsafe fn exec(api: &SqliteApi, db: *mut sqlite3, sql: &str) -> Result<(), String> {
    let csql = CString::new(sql).map_err(|_| "invalid sql".to_string())?;
    let mut err: *mut c_char = ptr::null_mut();
    let rc = (api.exec)(db, csql.as_ptr(), None, ptr::null_mut(), &mut err);
    if rc != 0 {
        let msg = if !err.is_null() {
            let s = CStr::from_ptr(err).to_string_lossy().into_owned();
            (api.free)(err as *mut c_void);
            s
        } else {
            CStr::from_ptr((api.errmsg)(db)).to_string_lossy().into_owned()
        };
        Err(msg)
    } else {
        Ok(())
    }
}

unsafe fn load_table(api: &SqliteApi, db: *mut sqlite3, name: &str, rows: &[Row]) -> Result<(), String> {
    let mut cols = BTreeSet::new();
    for r in rows {
        for k in r.0.keys() {
            cols.insert(k.clone());
        }
    }
    if cols.is_empty() {
        cols.insert("value".to_string());
    }
    let col_vec: Vec<String> = cols.into_iter().collect();
    let defs: Vec<String> = col_vec
        .iter()
        .map(|c| {
            let text_only = rows.iter().all(|r| matches!(r.0.get(c), None | Some(Cell::Null) | Some(Cell::Text(_))));
            let ty = if text_only { "TEXT" } else { "ANY" };
            format!("{} {}", quote_ident(c), ty)
        })
        .collect();
    exec(api, db, &format!("CREATE TABLE {} ({})", quote_ident(name), defs.join(",")))?;
    for row in rows {
        let vals: Vec<String> = col_vec.iter().map(|c| row.0.get(c).map(sql_lit).unwrap_or_else(|| "NULL".to_string())).collect();
        exec(api, db, &format!(
            "INSERT INTO {} ({}) VALUES ({})",
            quote_ident(name),
            col_vec.iter().map(|c| quote_ident(c)).collect::<Vec<_>>().join(","),
            vals.join(",")
        ))?;
    }
    Ok(())
}

unsafe fn query_rows(api: &SqliteApi, db: *mut sqlite3, query: &str) -> Result<Vec<Row>, String> {
    let csql = CString::new(query.trim()).map_err(|_| "invalid query".to_string())?;
    let mut stmt: *mut sqlite3_stmt = ptr::null_mut();
    let rc = (api.prepare)(db, csql.as_ptr(), -1, &mut stmt, ptr::null_mut());
    if rc != 0 {
        return Err(CStr::from_ptr((api.errmsg)(db)).to_string_lossy().into_owned());
    }
    let mut out = Vec::new();
    loop {
        let step = (api.step)(stmt);
        if step == SQLITE_ROW {
            let count = (api.column_count)(stmt);
            let mut map = BTreeMap::new();
            for i in 0..count {
                let name_ptr = (api.column_name)(stmt, i);
                let name = if name_ptr.is_null() {
                    format!("column{i}")
                } else {
                    CStr::from_ptr(name_ptr).to_string_lossy().into_owned()
                };
                let cell = match (api.column_type)(stmt, i) {
                    SQLITE_INTEGER => Cell::Integer((api.column_int64)(stmt, i)),
                    SQLITE_FLOAT => {
                        let f = (api.column_double)(stmt, i);
                        if f.is_finite() && f.fract() == 0.0 && f >= i64::MIN as f64 && f <= i64::MAX as f64 {
                            Cell::Integer(f as i64)
                        } else {
                            Cell::Float(f)
                        }
                    }
                    SQLITE_TEXT => {
                        let p = (api.column_text)(stmt, i);
                        if p.is_null() {
                            Cell::Null
                        } else {
                            Cell::Text(CStr::from_ptr(p as *const c_char).to_string_lossy().into_owned())
                        }
                    }
                    SQLITE_NULL => Cell::Null,
                    _ => Cell::Text(String::new()),
                };
                map.insert(name, cell);
            }
            out.push(Row(map, (0..count).map(|i| {
                let name_ptr = (api.column_name)(stmt, i);
                if name_ptr.is_null() {
                    format!("column{i}")
                } else {
                    CStr::from_ptr(name_ptr).to_string_lossy().into_owned()
                }
            }).collect()));
        } else if step == SQLITE_DONE {
            break;
        } else {
            let msg = CStr::from_ptr((api.errmsg)(db)).to_string_lossy().into_owned();
            (api.finalize)(stmt);
            return Err(msg);
        }
    }
    (api.finalize)(stmt);
    Ok(out)
}

fn print_json_rows(rows: &[Row]) {
    let arr: Vec<Value> = rows
        .iter()
        .map(|r| {
            let mut m = Map::new();
            let order: Vec<String> = if r.1.is_empty() { r.0.keys().cloned().collect() } else { r.1.clone() };
            for k in order {
                if let Some(v) = r.0.get(&k) {
                    m.insert(k, v.to_json());
                }
            }
            Value::Object(m)
        })
        .collect();
    let s = serde_json::to_string(&arr).unwrap();
    if arr.len() > 1 {
        println!("{}", s.replace("},{", "},\n{"));
    } else {
        println!("{s}");
    }
}

fn print_table(rows: &[Row]) {
    let mut cols = BTreeSet::new();
    for r in rows {
        for k in r.0.keys() {
            cols.insert(k.clone());
        }
    }
    let cols: Vec<String> = cols.into_iter().collect();
    if cols.is_empty() {
        println!("(0 rows)");
        return;
    }
    let mut widths: Vec<usize> = cols.iter().map(|c| c.len()).collect();
    let values: Vec<Vec<String>> = rows
        .iter()
        .map(|r| {
            cols.iter()
                .enumerate()
                .map(|(i, c)| {
                    let v = r.0.get(c).map(|x| x.display()).unwrap_or_default();
                    widths[i] = widths[i].max(v.len());
                    v
                })
                .collect()
        })
        .collect();
    let sep = format!("+{}+", widths.iter().map(|w| "-".repeat(w + 2)).collect::<Vec<_>>().join("+"));
    println!("{sep}");
    println!("| {} |", cols.iter().enumerate().map(|(i, c)| format!("{:<width$}", c, width = widths[i])).collect::<Vec<_>>().join(" | "));
    println!("{sep}");
    for row in values {
        println!("| {} |", row.iter().enumerate().map(|(i, v)| {
            if v.parse::<f64>().is_ok() && !v.is_empty() {
                format!("{:>width$}", v, width = widths[i])
            } else {
                format!("{:<width$}", v, width = widths[i])
            }
        }).collect::<Vec<_>>().join(" | "));
    }
    println!("{sep}");
    println!("({} rows)", rows.len());
}
