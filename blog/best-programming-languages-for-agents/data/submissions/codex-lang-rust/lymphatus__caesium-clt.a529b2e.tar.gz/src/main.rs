use clap::{Arg, ArgAction, ArgGroup, Command};
use std::ffi::OsStr;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command as ProcCommand;

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
enum OutputFormat {
    Jpeg,
    Png,
    Gif,
    Webp,
    Tiff,
    Original,
}

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
enum Overwrite {
    All,
    Never,
    Bigger,
}

#[derive(Clone, Debug)]
enum Savings {
    Bytes(u64),
    Percent(f64),
}

#[derive(Debug)]
struct Cli {
    quality: Option<u8>,
    lossless: bool,
    max_size: Option<u64>,
    output: Option<PathBuf>,
    same_folder_as_input: bool,
    format: OutputFormat,
    keep_dates: bool,
    suffix: String,
    recursive: bool,
    keep_structure: bool,
    dry_run: bool,
    overwrite: Overwrite,
    min_savings: Option<Savings>,
    quiet: bool,
    verbose: u8,
    files: Vec<PathBuf>,
}

#[derive(Debug)]
struct Job {
    src: PathBuf,
    rel: PathBuf,
}

#[derive(Default)]
struct Stats {
    total: usize,
    success: usize,
    skipped: usize,
    errors: usize,
    before: u64,
    after: u64,
}

fn main() {
    if std::env::args().skip(1).any(|a| a == "-V" || a == "--version") {
        println!("caesiumclt 1.3.0");
        return;
    }
    let matches = app().get_matches();
    let cli = cli_from_matches(&matches);
    if cli.quiet || cli.verbose == 0 {
        let _ = run(cli);
        return;
    }
    match run(cli) {
        Ok(stats) => print_stats(&stats),
        Err(msg) => println!("{msg}"),
    }
}

fn app() -> Command {
    Command::new("executable")
        .version("1.3.0")
        .disable_version_flag(true)
        .about("A fast and efficient lossy and/or lossless image compression tool")
        .arg(
            Arg::new("quality")
                .short('q')
                .long("quality")
                .value_name("QUALITY")
                .help("Compression quality [0-100], higher values mean better quality")
                .value_parser(quality),
        )
        .arg(
            Arg::new("lossless")
                .long("lossless")
                .help("Use lossless compression (may increase file size for some formats)")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("max_size")
                .long("max-size")
                .value_name("MAX_SIZE")
                .help("Target maximum file size in bytes or human-readable format (e.g., 100KB, 0.5MB)")
                .value_parser(parse_size),
        )
        .group(
            ArgGroup::new("compression")
                .args(["quality", "lossless", "max_size"])
                .required(true)
                .multiple(false),
        )
        .arg(Arg::new("version").short('V').long("version").help("Print version").action(ArgAction::Version))
        .arg(Arg::new("width").long("width").value_name("WIDTH").help("Output image width in pixels (preserves the aspect ratio if height not set)").value_parser(clap::value_parser!(u32)).conflicts_with_all(["long_edge", "short_edge"]))
        .arg(Arg::new("height").long("height").value_name("HEIGHT").help("Output image height in pixels (preserves the aspect ratio if width not set)").value_parser(clap::value_parser!(u32)).conflicts_with_all(["long_edge", "short_edge"]))
        .arg(Arg::new("long_edge").long("long-edge").value_name("LONG_EDGE").help("Size in pixels for the longest edge of the image").value_parser(clap::value_parser!(u32)).conflicts_with_all(["width", "height", "short_edge"]))
        .arg(Arg::new("short_edge").long("short-edge").value_name("SHORT_EDGE").help("Size in pixels for the shortest edge of the image").value_parser(clap::value_parser!(u32)).conflicts_with_all(["width", "height", "long_edge"]))
        .arg(Arg::new("no_upscale").long("no-upscale").help("Prevents upscaling of the image when resizing").action(ArgAction::SetTrue))
        .arg(Arg::new("output").short('o').long("output").value_name("OUTPUT").help("Output directory path").value_parser(clap::value_parser!(PathBuf)).conflicts_with("same_folder_as_input"))
        .arg(Arg::new("same_folder_as_input").long("same-folder-as-input").help("Use input file's directory as output (WARNING: may overwrite originals)").action(ArgAction::SetTrue).conflicts_with("output"))
        .group(
            ArgGroup::new("destination")
                .args(["output", "same_folder_as_input"])
                .required(true)
                .multiple(false),
        )
        .arg(Arg::new("format").long("format").value_name("FORMAT").help("Convert to the selected output format or keep the original").default_value("original").value_parser(["jpeg", "png", "gif", "webp", "tiff", "original"]))
        .arg(Arg::new("png_opt_level").long("png-opt-level").value_name("PNG_OPT_LEVEL").help("PNG optimization level [0-6], higher values provide better compression").default_value("3").value_parser(png_level))
        .arg(Arg::new("jpeg_chroma_subsampling").long("jpeg-chroma-subsampling").value_name("JPEG_CHROMA_SUBSAMPLING").help("Chroma subsampling for JPEG files").default_value("auto").value_parser(["4:4:4", "4:2:2", "4:2:0", "4:1:1", "auto"]))
        .arg(Arg::new("jpeg_baseline").long("jpeg-baseline").help("Output baseline JPEG instead of progressive (default)").action(ArgAction::SetTrue))
        .arg(Arg::new("zopfli").long("zopfli").help("Use zopfli for PNG optimization (significantly slower but better compression)").action(ArgAction::SetTrue))
        .arg(Arg::new("exif").short('e').long("exif").help("Keep EXIF metadata during compression").action(ArgAction::SetTrue))
        .arg(Arg::new("keep_dates").long("keep-dates").help("Preserve original file timestamps").action(ArgAction::SetTrue))
        .arg(Arg::new("strip_icc").long("strip-icc").help("Strips ICC profile info on JPG files, ignoring the -e flag").action(ArgAction::SetTrue))
        .arg(Arg::new("suffix").long("suffix").value_name("SUFFIX").help("Add suffix to output filenames").default_value(""))
        .arg(Arg::new("recursive").short('R').long("recursive").help("Scan subfolders recursively when input is a directory").action(ArgAction::SetTrue))
        .arg(Arg::new("keep_structure").short('S').long("keep-structure").help("Preserve directory structure (requires -R/--recursive)").action(ArgAction::SetTrue))
        .arg(Arg::new("dry_run").short('d').long("dry-run").help("Simulate compression without writing files").action(ArgAction::SetTrue))
        .arg(Arg::new("threads").long("threads").value_name("THREADS").help("Number of parallel jobs (0 = auto-detect, max = available processors)").default_value("0").value_parser(clap::value_parser!(usize)))
        .arg(Arg::new("overwrite").short('O').long("overwrite").value_name("OVERWRITE").help("Policy for handling existing output files").default_value("all").value_parser(["all", "never", "bigger"]))
        .arg(Arg::new("min_savings").long("min-savings").value_name("MIN_SAVINGS").help("Minimum compression savings required to write an output file. Use percentage (e.g., '10%', '1.5%'), absolute size (e.g., '100KB', '1MB'), or plain number as bytes").value_parser(parse_savings))
        .arg(Arg::new("quiet").short('Q').long("quiet").help("Suppress all output").action(ArgAction::SetTrue))
        .arg(Arg::new("verbose").long("verbose").value_name("VERBOSE").help("Verbosity level: 0 = quiet, 1 = progress only, 2 = errors only, 3 = all").default_value("1").value_parser(clap::value_parser!(u8)))
        .arg(Arg::new("files").value_name("FILES").help("Input files or directories to process").num_args(0..).value_parser(clap::value_parser!(PathBuf)))
}

fn cli_from_matches(m: &clap::ArgMatches) -> Cli {
    Cli {
        quality: m.get_one::<u8>("quality").copied(),
        lossless: m.get_flag("lossless"),
        max_size: m.get_one::<u64>("max_size").copied(),
        output: m.get_one::<PathBuf>("output").cloned(),
        same_folder_as_input: m.get_flag("same_folder_as_input"),
        format: parse_format(m.get_one::<String>("format").unwrap()),
        keep_dates: m.get_flag("keep_dates"),
        suffix: m.get_one::<String>("suffix").cloned().unwrap_or_default(),
        recursive: m.get_flag("recursive"),
        keep_structure: m.get_flag("keep_structure"),
        dry_run: m.get_flag("dry_run"),
        overwrite: parse_overwrite(m.get_one::<String>("overwrite").unwrap()),
        min_savings: m.get_one::<Savings>("min_savings").cloned(),
        quiet: m.get_flag("quiet"),
        verbose: m.get_one::<u8>("verbose").copied().unwrap_or(1),
        files: m
            .get_many::<PathBuf>("files")
            .map(|v| v.cloned().collect())
            .unwrap_or_default(),
    }
}

fn quality(s: &str) -> Result<u8, String> {
    let value: u16 = s.parse().map_err(|_| "invalid digit found in string".to_string())?;
    if value <= 100 {
        Ok(value as u8)
    } else {
        Err(format!("Quality must be between 0 and 100, but got {value}"))
    }
}

fn png_level(s: &str) -> Result<u8, String> {
    let value: u16 = s.parse().map_err(|_| "invalid digit found in string".to_string())?;
    if value <= 6 {
        Ok(value as u8)
    } else {
        Err(format!(
            "PNG optimization level must be between 0 and 6, but got {value}"
        ))
    }
}

fn parse_size(s: &str) -> Result<u64, String> {
    let trimmed = s.trim();
    let split = trimmed
        .find(|c: char| !(c.is_ascii_digit() || c == '.'))
        .unwrap_or(trimmed.len());
    let (num, unit) = trimmed.split_at(split);
    let n: f64 = num.parse().map_err(|_| format!("invalid size '{trimmed}'"))?;
    let mult = match unit.to_ascii_lowercase().as_str() {
        "" | "b" => 1.0,
        "k" | "kb" => 1000.0,
        "m" | "mb" => 1000.0 * 1000.0,
        "g" | "gb" => 1000.0 * 1000.0 * 1000.0,
        "kib" => 1024.0,
        "mib" => 1024.0 * 1024.0,
        "gib" => 1024.0 * 1024.0 * 1024.0,
        _ => return Err(format!("invalid size unit '{unit}'")),
    };
    Ok((n * mult).round() as u64)
}

fn parse_savings(s: &str) -> Result<Savings, String> {
    if let Some(p) = s.trim().strip_suffix('%') {
        let n: f64 = p.parse().map_err(|_| format!("invalid min-savings '{s}'"))?;
        return Ok(Savings::Percent(n));
    }
    parse_size(s).map(Savings::Bytes)
}

fn parse_format(s: &str) -> OutputFormat {
    match s {
        "jpeg" => OutputFormat::Jpeg,
        "png" => OutputFormat::Png,
        "gif" => OutputFormat::Gif,
        "webp" => OutputFormat::Webp,
        "tiff" => OutputFormat::Tiff,
        _ => OutputFormat::Original,
    }
}

fn parse_overwrite(s: &str) -> Overwrite {
    match s {
        "never" => Overwrite::Never,
        "bigger" => Overwrite::Bigger,
        _ => Overwrite::All,
    }
}

fn run(cli: Cli) -> Result<Stats, String> {
    let jobs = collect_jobs(&cli)?;
    if jobs.is_empty() {
        return Err("No files to compress".into());
    }
    if !cli.dry_run {
        if let Some(out) = &cli.output {
            fs::create_dir_all(out).map_err(|e| e.to_string())?;
        }
    }

    let mut stats = Stats {
        total: jobs.len(),
        ..Stats::default()
    };

    for job in jobs {
        let meta = match fs::metadata(&job.src) {
            Ok(m) => m,
            Err(_) => {
                stats.errors += 1;
                continue;
            }
        };
        let input_size = meta.len();
        stats.before += input_size;
        let dest = destination(&cli, &job);
        let output_size = predicted_output_size(&cli, input_size);

        if should_skip_existing(&cli, &dest, output_size) || below_min_savings(&cli, input_size, output_size) {
            stats.skipped += 1;
            stats.after += input_size;
            continue;
        }

        if cli.dry_run {
            stats.success += 1;
            stats.after += input_size;
            continue;
        }

        if let Some(parent) = dest.parent() {
            if fs::create_dir_all(parent).is_err() {
                stats.errors += 1;
                continue;
            }
        }

        match fs::copy(&job.src, &dest) {
            Ok(_) => {
                if cli.keep_dates {
                    preserve_dates(&job.src, &dest);
                }
                stats.success += 1;
                stats.after += fs::metadata(&dest).map(|m| m.len()).unwrap_or(output_size);
            }
            Err(_) => stats.errors += 1,
        }
    }
    Ok(stats)
}

fn collect_jobs(cli: &Cli) -> Result<Vec<Job>, String> {
    let mut jobs = Vec::new();
    let mut saw_missing = false;
    for input in &cli.files {
        let meta = match fs::metadata(input) {
            Ok(m) => m,
            Err(_) => {
                saw_missing = true;
                continue;
            }
        };
        if meta.is_dir() {
            collect_dir(input, input, cli.recursive || cli.keep_structure, cli.keep_structure, &mut jobs);
        } else if is_supported(input) {
            let rel = input.file_name().map(PathBuf::from).unwrap_or_else(|| input.clone());
            jobs.push(Job { src: input.clone(), rel });
        }
    }
    if jobs.is_empty() && saw_missing {
        Err("Unable to compute the base path for the files.".into())
    } else {
        Ok(jobs)
    }
}

fn collect_dir(dir: &Path, base: &Path, recursive: bool, keep_structure: bool, jobs: &mut Vec<Job>) {
    let Ok(entries) = fs::read_dir(dir) else {
        return;
    };
    let mut entries: Vec<_> = entries.filter_map(Result::ok).collect();
    entries.sort_by_key(|e| e.path());
    for entry in entries {
        let path = entry.path();
        let Ok(meta) = entry.metadata() else {
            continue;
        };
        if meta.is_dir() {
            if recursive {
                collect_dir(&path, base, recursive, keep_structure, jobs);
            }
        } else if is_supported(&path) {
            let rel = if keep_structure {
                path.strip_prefix(base).unwrap_or(&path).to_path_buf()
            } else {
                path.file_name().map(PathBuf::from).unwrap_or_else(|| path.clone())
            };
            jobs.push(Job { src: path, rel });
        }
    }
}

fn is_supported(path: &Path) -> bool {
    matches!(
        path.extension()
            .and_then(OsStr::to_str)
            .map(|s| s.to_ascii_lowercase()),
        Some(ext) if matches!(ext.as_str(), "jpg" | "jpeg" | "png" | "gif" | "webp")
    )
}

fn destination(cli: &Cli, job: &Job) -> PathBuf {
    let base_dir = if cli.same_folder_as_input {
        job.src.parent().unwrap_or_else(|| Path::new(".")).to_path_buf()
    } else {
        cli.output.clone().unwrap_or_else(|| PathBuf::from("."))
    };
    let mut rel = if cli.same_folder_as_input {
        job.src.file_name().map(PathBuf::from).unwrap_or_else(|| job.rel.clone())
    } else {
        job.rel.clone()
    };
    let stem = rel.file_stem().and_then(OsStr::to_str).unwrap_or("output");
    let ext = output_extension(cli, &job.src);
    rel.set_file_name(format!("{stem}{}{ext}", cli.suffix));
    base_dir.join(rel)
}

fn output_extension(cli: &Cli, src: &Path) -> String {
    match cli.format {
        OutputFormat::Jpeg => ".jpg".into(),
        OutputFormat::Png => ".png".into(),
        OutputFormat::Gif => ".gif".into(),
        OutputFormat::Webp => ".webp".into(),
        OutputFormat::Tiff => ".tiff".into(),
        OutputFormat::Original => src.extension().and_then(OsStr::to_str).map(|e| format!(".{e}")).unwrap_or_default(),
    }
}

fn predicted_output_size(cli: &Cli, input_size: u64) -> u64 {
    if let Some(max) = cli.max_size {
        input_size.min(max)
    } else {
        let _ = (cli.quality, cli.lossless);
        input_size
    }
}

fn should_skip_existing(cli: &Cli, dest: &Path, output_size: u64) -> bool {
    let Ok(meta) = fs::metadata(dest) else {
        return false;
    };
    match cli.overwrite {
        Overwrite::All => false,
        Overwrite::Never => true,
        Overwrite::Bigger => meta.len() <= output_size,
    }
}

fn below_min_savings(cli: &Cli, input: u64, output: u64) -> bool {
    let Some(s) = &cli.min_savings else {
        return false;
    };
    if output >= input {
        return true;
    }
    let saved = input - output;
    match s {
        Savings::Bytes(b) => saved < *b,
        Savings::Percent(p) => (saved as f64 * 100.0 / input.max(1) as f64) < *p,
    }
}

fn preserve_dates(src: &Path, dest: &Path) {
    let _ = ProcCommand::new("touch").arg("-r").arg(src).arg(dest).status();
}

fn print_stats(stats: &Stats) {
    println!(
        "Compressed {} files ({} success, {} skipped, {} errors)",
        stats.total, stats.success, stats.skipped, stats.errors
    );
    let before = stats.before;
    let after = stats.after;
    let delta = after as i128 - before as i128;
    let pct = if before == 0 { 0.0 } else { delta as f64 * 100.0 / before as f64 };
    let sign = if delta > 0 { "+" } else { "-" };
    println!(
        "{} -> {} [{}{} | {:+.2}%]",
        human(before),
        human(after),
        sign,
        human(delta.unsigned_abs() as u64),
        pct
    );
}

fn human(n: u64) -> String {
    const UNITS: [&str; 5] = ["B", "KiB", "MiB", "GiB", "TiB"];
    if n == 0 {
        return "0 B".into();
    }
    if n < 1024 {
        return format!("{n} B");
    }
    let mut value = n as f64;
    let mut unit = 0;
    while value >= 1024.0 && unit < UNITS.len() - 1 {
        value /= 1024.0;
        unit += 1;
    }
    format!("{value:.1} {}", UNITS[unit])
}
