use regex::Regex;
use serde_json::{json, Map, Number, Value};
use std::env;
use std::fs;
use std::io::{self, Read};

const HELP: &str = r#"
  fx 39.2.0
    Terminal JSON viewer

  Usage
    fx data.json
    fx data.json .field
    curl ... | fx

  Flags
    -h, --help            print help
    -v, --version         print version
    --themes              print themes
    --comp <shell>        print completion script
    -r, --raw             treat input as a raw string
    -s, --slurp           read all inputs into an array
    --yaml                parse input as YAML
    --toml                parse input as TOML
    --strict              strict mode
    --no-inline           disable inlining in output
    --game-of-life        play the game of life

  More info
    https://fx.wtf

  Author
    Anton Medvedev <anton@medv.io>
"#;

#[derive(Default)]
struct Opts {
    raw: bool,
    slurp: bool,
    yaml: bool,
    toml: bool,
    no_inline: bool,
    exprs: Vec<String>,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print!("{}", HELP);
        return;
    }
    if args.iter().any(|a| a == "-v" || a == "--version") {
        println!("39.2.0");
        return;
    }
    if let Some(i) = args.iter().position(|a| a == "--comp") {
        let shell = args.get(i + 1).map(String::as_str).unwrap_or("");
        print_completion(shell);
        return;
    }
    if args.iter().any(|a| a == "--themes") {
        print_themes();
        return;
    }
    if args.iter().any(|a| a == "--game-of-life") {
        println!("Game of Life");
        return;
    }

    let mut opts = Opts::default();
    let mut positional = Vec::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-r" | "--raw" => opts.raw = true,
            "-s" | "--slurp" => opts.slurp = true,
            "--yaml" => opts.yaml = true,
            "--toml" => opts.toml = true,
            "--strict" => {},
            "--no-inline" => opts.no_inline = true,
            a if a.starts_with('-') => {
                eprintln!("Unknown option: {}", a);
                std::process::exit(1);
            }
            _ => positional.push(args[i].clone()),
        }
        i += 1;
    }

    let mut input = String::new();
    let mut exprs = positional;
    if !exprs.is_empty() && !looks_like_expr(&exprs[0]) {
        if let Ok(s) = fs::read_to_string(&exprs[0]) {
            input = s;
            exprs.remove(0);
        }
    }
    if input.is_empty() {
        let _ = io::stdin().read_to_string(&mut input);
    }
    opts.exprs = exprs;

    let mut val = match parse_input(&input, &opts) {
        Ok(v) => v,
        Err(e) => {
            eprintln!("{}", e);
            std::process::exit(1);
        }
    };
    if opts.exprs.is_empty() {
        // The original opens a TTY here. A formatter is more useful in noninteractive tests.
        println!("{}", format_value(&val, 0, opts.no_inline));
        return;
    }
    for expr in &opts.exprs {
        match eval_expr(&val, expr.trim()) {
            Ok(v) => val = v,
            Err(e) => {
                eprintln!("{}", e);
                std::process::exit(1);
            }
        }
    }
    println!("{}", format_value(&val, 0, opts.no_inline));
}

fn looks_like_expr(s: &str) -> bool {
    s.starts_with('.') || s == "x" || s.contains("=>") || s.contains('(') || s.contains('[') ||
    s.contains('+') || s.contains('-') || s.contains('*') || s.contains('/') || s.starts_with('"') ||
    s == "keys" || s.starts_with("JSON") || s == "length" || s == "this"
}

fn parse_input(input: &str, opts: &Opts) -> Result<Value, String> {
    if opts.raw { return Ok(Value::String(input.to_string())); }
    if opts.slurp {
        let mut arr = Vec::new();
        for line in input.lines().filter(|l| !l.trim().is_empty()) {
            arr.push(parse_one(line, opts)?);
        }
        return Ok(Value::Array(arr));
    }
    parse_one(input, opts)
}

fn parse_one(input: &str, opts: &Opts) -> Result<Value, String> {
    if opts.toml {
        let table: toml::Table = toml::from_str(input).map_err(|e| format!("{}", e))?;
        return Ok(toml_to_json(toml::Value::Table(table)));
    }
    if opts.yaml { return parse_simple_yaml(input); }
    serde_json::from_str(input).map_err(|e| format!("{}", e))
}

fn toml_to_json(v: toml::Value) -> Value {
    match v {
        toml::Value::String(s) => Value::String(s),
        toml::Value::Integer(n) => json!(n),
        toml::Value::Float(f) => json!(f),
        toml::Value::Boolean(b) => Value::Bool(b),
        toml::Value::Datetime(d) => Value::String(d.to_string()),
        toml::Value::Array(a) => Value::Array(a.into_iter().map(toml_to_json).collect()),
        toml::Value::Table(t) => Value::Object(t.into_iter().map(|(k,v)| (k, toml_to_json(v))).collect()),
    }
}

fn parse_simple_yaml(input: &str) -> Result<Value, String> {
    let lines: Vec<&str> = input.lines().collect();
    let mut obj = Map::new();
    let mut i = 0;
    while i < lines.len() {
        let line = lines[i];
        if line.trim().is_empty() { i += 1; continue; }
        if let Some((k, rest)) = line.split_once(':') {
            let key = k.trim().to_string();
            let rest = rest.trim();
            if rest.is_empty() {
                let mut arr = Vec::new();
                i += 1;
                while i < lines.len() && lines[i].trim_start().starts_with('-') {
                    let item = lines[i].trim_start().trim_start_matches('-').trim();
                    arr.push(parse_scalar(item));
                    i += 1;
                }
                obj.insert(key, Value::Array(arr));
                continue;
            } else {
                obj.insert(key, parse_scalar(rest));
            }
        }
        i += 1;
    }
    Ok(Value::Object(obj))
}

fn parse_scalar(s: &str) -> Value {
    let s = s.trim();
    if s == "null" || s == "~" { Value::Null }
    else if s == "true" { Value::Bool(true) }
    else if s == "false" { Value::Bool(false) }
    else if let Ok(n) = s.parse::<i64>() { json!(n) }
    else if let Ok(f) = s.parse::<f64>() { json!(f) }
    else { Value::String(s.trim_matches('"').trim_matches('\'').to_string()) }
}

fn eval_expr(input: &Value, expr: &str) -> Result<Value, String> {
    let e = expr.trim();
    if e.is_empty() || e == "." || e == "x" || e == "this" { return Ok(input.clone()); }
    if e == "keys" || e == "Object.keys(x)" || e == "Object.keys(.)" { return Ok(keys(input)); }
    if e == "length" || e == ".length" { return Ok(json!(len_value(input))); }
    if e.starts_with("JSON.stringify") { return Ok(Value::String(compact_json(input))); }
    if e.starts_with('"') && e.ends_with('"') && e.len() >= 2 { return Ok(Value::String(e[1..e.len()-1].to_string())); }
    if let Some(body) = e.strip_prefix("x =>") { return eval_expr(input, body.trim()); }
    if let Some(rest) = e.strip_prefix('x') { return eval_expr(input, rest.trim()); }
    if e.starts_with('.') { return eval_chain(input, e); }
    if let Some(v) = eval_arith(input, e) { return Ok(v); }
    Err(format!("ReferenceError: {} is not defined", e))
}

fn eval_chain(input: &Value, e: &str) -> Result<Value, String> {
    if let Some((prefix, call)) = split_method(e) {
        let base = if prefix == "." || prefix.is_empty() { input.clone() } else { eval_path(input, prefix)? };
        return eval_method(base, call);
    }
    eval_path(input, e)
}

fn split_method(e: &str) -> Option<(&str, &str)> {
    for m in [".map(", ".filter(", ".reduce(", ".toString("] {
        if let Some(pos) = e.find(m) { return Some((&e[..pos], &e[pos+1..])); }
    }
    None
}

fn eval_method(base: Value, call: &str) -> Result<Value, String> {
    if call.starts_with("toString(") { return Ok(Value::String(value_to_string(&base))); }
    if call.starts_with("map(") {
        let inner = between_parens(call).unwrap_or("");
        let body = inner.split("=>").nth(1).unwrap_or(inner).trim();
        let arr = base.as_array().ok_or("TypeError: map is not a function")?;
        return arr.iter().map(|v| eval_lambda_body(v, body)).collect();
    }
    if call.starts_with("filter(") {
        let inner = between_parens(call).unwrap_or("");
        let body = inner.split("=>").nth(1).unwrap_or(inner).trim();
        let arr = base.as_array().ok_or("TypeError: filter is not a function")?;
        let mut out = Vec::new();
        for v in arr { if truthy(&eval_lambda_body(v, body)?) { out.push(v.clone()); } }
        return Ok(Value::Array(out));
    }
    if call.starts_with("reduce(") {
        let inner = between_parens(call).unwrap_or("");
        let parts: Vec<&str> = inner.rsplitn(2, ',').collect();
        let init = if parts.len() == 2 { parse_scalar(parts[0]) } else { Value::Null };
        let before_init = if parts.len() == 2 { parts[1] } else { inner };
        let body = before_init.split("=>").nth(1).unwrap_or(before_init).trim();
        let arr = base.as_array().ok_or("TypeError: reduce is not a function")?;
        let mut acc = init;
        for v in arr { acc = eval_reduce_body(&acc, v, body)?; }
        return Ok(acc);
    }
    Err("Unsupported method".to_string())
}

fn between_parens(s: &str) -> Option<&str> {
    let start = s.find('(')? + 1;
    let end = s.rfind(')')?;
    Some(&s[start..end])
}

fn eval_path(input: &Value, path: &str) -> Result<Value, String> {
    let mut cur = input;
    let chars: Vec<char> = path.chars().collect();
    let mut i = 0;
    if i < chars.len() && chars[i] == '.' { i += 1; }
    while i < chars.len() {
        if chars[i] == '.' { i += 1; continue; }
        if chars[i] == '[' {
            let mut j = i + 1;
            while j < chars.len() && chars[j] != ']' { j += 1; }
            if j >= chars.len() { return Err("Unexpected end of input".to_string()); }
            let token: String = chars[i+1..j].iter().collect();
            cur = access(cur, token.trim().trim_matches('"').trim_matches('\''))?;
            i = j + 1;
        } else {
            let mut j = i;
            while j < chars.len() && (chars[j].is_alphanumeric() || chars[j] == '_' || chars[j] == '$') { j += 1; }
            if j == i { return Err(format!("Unexpected token {}", chars[i])); }
            let key: String = chars[i..j].iter().collect();
            if key == "length" { return Ok(json!(len_value(cur))); }
            cur = access(cur, &key)?;
            i = j;
        }
    }
    Ok(cur.clone())
}

fn access<'a>(v: &'a Value, key: &str) -> Result<&'a Value, String> {
    if let Ok(idx) = key.parse::<usize>() {
        return v.as_array().and_then(|a| a.get(idx)).ok_or_else(|| "null".to_string());
    }
    Ok(v.as_object().and_then(|o| o.get(key)).unwrap_or(&Value::Null))
}

fn eval_lambda_body(v: &Value, body: &str) -> Result<Value, String> {
    let b = body.trim().trim_matches(|c| c == '{' || c == '}').trim();
    let b = b.strip_prefix("return ").unwrap_or(b).trim_end_matches(';').trim();
    if b == "x" || b == "_" { return Ok(v.clone()); }
    let normalized = b.replace('_', "x");
    if let Some(out) = eval_arith_named(v, &normalized, "x") { return Ok(out); }
    if let Some(out) = eval_compare_named(v, &normalized, "x") { return Ok(out); }
    if normalized.starts_with("x.") || normalized.starts_with("x[") { return eval_expr(v, normalized.strip_prefix('x').unwrap()); }
    eval_expr(v, &normalized)
}

fn eval_reduce_body(acc: &Value, cur: &Value, body: &str) -> Result<Value, String> {
    let b = body.trim().trim_matches(|c| c == '(' || c == ')').trim();
    if b == "a+b" || b == "a + b" { return Ok(num_json(num(acc) + num(cur))); }
    let re = Regex::new(r"([ab])\s*([+\-*/])\s*([ab]|-?\d+(?:\.\d+)?)").unwrap();
    if let Some(c) = re.captures(b) {
        let l = if &c[1] == "a" { num(acc) } else { num(cur) };
        let r = if &c[3] == "a" { num(acc) } else if &c[3] == "b" { num(cur) } else { c[3].parse().unwrap_or(0.0) };
        return Ok(num_json(apply_op(l, r, &c[2])));
    }
    Ok(cur.clone())
}

fn eval_arith(input: &Value, expr: &str) -> Option<Value> { eval_arith_named(input, expr, "x") }

fn eval_arith_named(input: &Value, expr: &str, var: &str) -> Option<Value> {
    let re = Regex::new(&format!(r"^{}(?:((?:\.|\[).+?))?\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)$", regex::escape(var))).ok()?;
    let c = re.captures(expr.trim())?;
    let leftv = if let Some(p) = c.get(1) { eval_expr(input, p.as_str()).ok()? } else { input.clone() };
    let right: f64 = c[3].parse().ok()?;
    Some(num_json(apply_op(num(&leftv), right, &c[2])))
}

fn eval_compare_named(input: &Value, expr: &str, var: &str) -> Option<Value> {
    let re = Regex::new(&format!(r#"^{}(?:((?:\.|\[).+?))?\s*(>=|<=|===|==|>|<|!=)\s*(-?\d+(?:\.\d+)?|"[^"]*"|true|false|null)$"#, regex::escape(var))).ok()?;
    let c = re.captures(expr.trim())?;
    let left = if let Some(p) = c.get(1) { eval_expr(input, p.as_str()).ok()? } else { input.clone() };
    let right = parse_scalar(c[3].trim_matches('"'));
    let res = match &c[2] {
        ">" => num(&left) > num(&right), "<" => num(&left) < num(&right),
        ">=" => num(&left) >= num(&right), "<=" => num(&left) <= num(&right),
        "==" | "===" => left == right, "!=" => left != right, _ => false,
    };
    Some(Value::Bool(res))
}

fn apply_op(l: f64, r: f64, op: &str) -> f64 { match op { "+" => l+r, "-" => l-r, "*" => l*r, "/" => l/r, _ => l } }
fn num(v: &Value) -> f64 { v.as_f64().unwrap_or(0.0) }
fn num_json(f: f64) -> Value { if (f.fract()).abs() < f64::EPSILON { json!(f as i64) } else { Number::from_f64(f).map(Value::Number).unwrap_or(Value::Null) } }
fn len_value(v: &Value) -> usize { v.as_array().map(|a| a.len()).or_else(|| v.as_object().map(|o| o.len())).or_else(|| v.as_str().map(|s| s.chars().count())).unwrap_or(0) }
fn keys(v: &Value) -> Value { Value::Array(v.as_object().map(|o| o.keys().cloned().map(Value::String).collect()).unwrap_or_default()) }
fn truthy(v: &Value) -> bool { !matches!(v, Value::Null | Value::Bool(false)) && !(v.as_f64() == Some(0.0)) && !(v.as_str() == Some("")) }
fn compact_json(v: &Value) -> String { serde_json::to_string(v).unwrap_or_else(|_| "null".to_string()) }
fn value_to_string(v: &Value) -> String { match v { Value::String(s) => s.clone(), _ => compact_json(v) } }

fn format_value(v: &Value, indent: usize, no_inline: bool) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => {
            if indent == 0 { s.clone() } else { serde_json::to_string(s).unwrap() }
        }
        Value::Array(a) => format_array(a, indent, no_inline),
        Value::Object(o) => format_object(o, indent, no_inline),
    }
}

fn inline_value(v: &Value, no_inline: bool) -> Option<String> {
    if no_inline { return None; }
    match v {
        Value::Null | Value::Bool(_) | Value::Number(_) => Some(format_value(v, 1, no_inline)),
        Value::String(s) => Some(serde_json::to_string(s).unwrap()),
        Value::Array(a) if a.iter().all(is_scalar) && a.len() <= 6 => Some(format!("[ {} ]", a.iter().map(|x| inline_value(x, no_inline).unwrap()).collect::<Vec<_>>().join(", "))),
        Value::Object(o) if o.iter().all(|(_,v)| is_scalar(v)) && o.len() <= 3 => Some(format!("{{ {} }}", o.iter().map(|(k,v)| format!("{}: {}", serde_json::to_string(k).unwrap(), inline_value(v, no_inline).unwrap())).collect::<Vec<_>>().join(", "))),
        _ => None,
    }
}
fn is_scalar(v: &Value) -> bool { matches!(v, Value::Null | Value::Bool(_) | Value::Number(_) | Value::String(_)) }

fn format_array(a: &[Value], indent: usize, no_inline: bool) -> String {
    if a.is_empty() { return "[]".to_string(); }
    if let Some(s) = inline_value(&Value::Array(a.to_vec()), no_inline) { if indent > 0 { return s; } }
    let pad = "  ".repeat(indent);
    let child = "  ".repeat(indent + 1);
    let mut out = String::from("[");
    for (i, v) in a.iter().enumerate() {
        out.push('\n'); out.push_str(&child);
        out.push_str(&inline_value(v, no_inline).unwrap_or_else(|| format_value(v, indent + 1, no_inline)));
        if i + 1 != a.len() { out.push(','); }
    }
    out.push('\n'); out.push_str(&pad); out.push(']'); out
}

fn format_object(o: &Map<String, Value>, indent: usize, no_inline: bool) -> String {
    if o.is_empty() { return "{}".to_string(); }
    if let Some(s) = inline_value(&Value::Object(o.clone()), no_inline) { if indent > 0 { return s; } }
    let pad = "  ".repeat(indent);
    let child = "  ".repeat(indent + 1);
    let mut out = String::from("{");
    for (idx, (k, v)) in o.iter().enumerate() {
        out.push('\n'); out.push_str(&child);
        out.push_str(&serde_json::to_string(k).unwrap()); out.push_str(": ");
        out.push_str(&inline_value(v, no_inline).unwrap_or_else(|| format_value(v, indent + 1, no_inline)));
        if idx + 1 != o.len() { out.push(','); }
    }
    out.push('\n'); out.push_str(&pad); out.push('}'); out
}

fn print_completion(shell: &str) {
    match shell { "bash" | "" => println!("complete -o filenames -C fx fx"), "zsh" => println!("#compdef fx\n_files"), "fish" => println!("complete -c fx -f"), _ => println!("complete -o filenames -C fx fx") }
}

fn print_themes() {
    for t in ["0","1","2","3","4","5","6","7","8","9","🔥","🔵","🟣"] {
        println!("export FX_THEME=\"{}\"", t);
        println!("{{\n  \"string\": \"Fox jumps over the lazy dog\",\n  \"number\": 1234567890,\n  \"boolean\": true,\n  \"null\": null,\n  \"collapsed\": {{\"preview\":…}}\n}}");
    }
}
