use std::env;
use std::fs::{self, File};
use std::io::{Read, Write};
use std::path::PathBuf;
use std::process;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
struct Date {
    y: i32,
    m: u32,
    d: u32,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
struct Time {
    h: u32,
    m: u32,
}

#[derive(Clone, Debug)]
enum CalKind {
    Event,
    Apt { end: Date, start_time: Time, end_time: Time },
}

#[derive(Clone, Debug)]
struct CalItem {
    start: Date,
    kind: CalKind,
    recur: Option<Recur>,
    note: Option<String>,
    msg: String,
    raw: String,
}

#[derive(Clone, Debug)]
struct Recur {
    freq: char,
    interval: i64,
    until: Option<Date>,
}

#[derive(Clone, Debug)]
struct Todo {
    pri: i32,
    done: bool,
    msg: String,
    raw: String,
}

#[derive(Clone, Debug)]
struct Opts {
    datadir: PathBuf,
    confdir: PathBuf,
    calfile: Option<PathBuf>,
    input_fmt: u8,
    output_fmt: String,
    op: Op,
    from: Option<Date>,
    to: Option<Date>,
    days: Option<i64>,
    filter_type: Option<String>,
    search: Option<String>,
    limit: Option<usize>,
    todo_pri: Option<i32>,
    todo_done: Option<bool>,
    format_apt: String,
    format_event: String,
    format_todo: String,
    export_format: String,
    import_file: Option<String>,
    quiet: bool,
    dump_imported: bool,
}

#[derive(Clone, Debug, PartialEq)]
enum Op {
    Interactive,
    Help,
    Version,
    Status,
    Query { cal: bool, todo: bool },
    Grep,
    Purge,
    Export,
    Import,
    Gc,
    Daemon,
    Next,
}

fn main() {
    let mut opts = default_opts();
    if let Err(e) = parse_args(&mut opts) {
        eprintln!("{}", e);
        process::exit(1);
    }
    let code = match run(&opts) {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("{}", e);
            1
        }
    };
    process::exit(code);
}

fn default_opts() -> Opts {
    let home = env::var("HOME").unwrap_or_else(|_| ".".to_string());
    let old = PathBuf::from(format!("{}/.calcurse", home));
    let (datadir, confdir) = if old.exists() {
        (old.clone(), old)
    } else {
        let xd = env::var("XDG_DATA_HOME").unwrap_or_else(|_| format!("{}/.local/share", home));
        let xc = env::var("XDG_CONFIG_HOME").unwrap_or_else(|_| format!("{}/.config", home));
        (PathBuf::from(xd).join("calcurse"), PathBuf::from(xc).join("calcurse"))
    };
    Opts {
        datadir,
        confdir,
        calfile: None,
        input_fmt: 1,
        output_fmt: "%D".to_string(),
        op: Op::Interactive,
        from: None,
        to: None,
        days: None,
        filter_type: None,
        search: None,
        limit: None,
        todo_pri: None,
        todo_done: None,
        format_apt: " - %S -> %E\n\t%m\n".to_string(),
        format_event: " * %m\n".to_string(),
        format_todo: "%p. %m\n".to_string(),
        export_format: "ical".to_string(),
        import_file: None,
        quiet: false,
        dump_imported: false,
    }
}

fn parse_args(opts: &mut Opts) -> Result<(), String> {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let take = |i: &mut usize| -> Result<String, String> {
            *i += 1;
            args.get(*i).cloned().ok_or_else(|| format!("{} requires an argument", a))
        };
        match a.as_str() {
            "-h" | "--help" => opts.op = Op::Help,
            "-v" | "--version" => opts.op = Op::Version,
            "--status" => opts.op = Op::Status,
            "--daemon" => opts.op = Op::Daemon,
            "-g" | "--gc" => opts.op = Op::Gc,
            "-Q" | "--query" => opts.op = Op::Query { cal: true, todo: true },
            "-G" | "--grep" => opts.op = Op::Grep,
            "-P" | "--purge" | "-F" | "--filter" => opts.op = Op::Purge,
            "-a" | "--appointment" => {
                opts.op = Op::Query { cal: true, todo: false };
                opts.filter_type = Some("cal".to_string());
                opts.from = Some(today());
                opts.days = Some(1);
            }
            "-n" | "--next" => opts.op = Op::Next,
            "-q" | "--quiet" => opts.quiet = true,
            "--read-only" | "--export-uid" => {}
            "--dump-imported" => opts.dump_imported = true,
            "-D" | "--datadir" => opts.datadir = PathBuf::from(take(&mut i)?),
            "-C" | "--confdir" => opts.confdir = PathBuf::from(take(&mut i)?),
            "-c" | "--calendar" => opts.calfile = Some(PathBuf::from(take(&mut i)?)),
            "-i" | "--import" => {
                opts.op = Op::Import;
                opts.import_file = Some(take(&mut i)?);
            }
            "-x" | "--export" => opts.op = Op::Export,
            "--from" => opts.from = Some(parse_input_date(&take(&mut i)?, opts.input_fmt)?),
            "--to" => opts.to = Some(parse_input_date(&take(&mut i)?, opts.input_fmt)?),
            "--days" => opts.days = Some(take(&mut i)?.parse().map_err(|_| "invalid range".to_string())?),
            "--input-datefmt" => opts.input_fmt = take(&mut i)?.parse().unwrap_or(1),
            "--output-datefmt" => opts.output_fmt = take(&mut i)?,
            "-l" | "--limit" => opts.limit = Some(take(&mut i)?.parse().unwrap_or(usize::MAX)),
            "-S" | "--search" | "--filter-pattern" => opts.search = Some(take(&mut i)?),
            "--filter-type" => opts.filter_type = Some(take(&mut i)?),
            "--filter-priority" => {
                opts.filter_type = Some("todo".to_string());
                opts.search = opts.search.take();
                let _ = take(&mut i)?;
            }
            "--format-apt" | "--format-recur-apt" => opts.format_apt = take(&mut i)?,
            "--format-event" | "--format-recur-event" => opts.format_event = take(&mut i)?,
            "--format-todo" => opts.format_todo = take(&mut i)?,
            _ if a.starts_with("-d") && a.len() > 2 => set_day(opts, &a[2..])?,
            "-d" | "--day" => {
                let v = take(&mut i)?;
                set_day(opts, &v)?;
            }
            _ if a.starts_with("-r") && a.len() > 2 => set_range(opts, &a[2..])?,
            "-r" | "--range" => set_range(opts, "1")?,
            _ if a.starts_with("-s") && a.len() > 2 => set_start(opts, &a[2..])?,
            "-s" | "--startday" => set_start(opts, "today")?,
            _ if a.starts_with("-t") && a.len() > 2 => set_todo(opts, Some(&a[2..]))?,
            "-t" | "--todo" => set_todo(opts, None)?,
            _ if a.starts_with("-x") && a.len() > 2 => {
                opts.op = Op::Export;
                opts.export_format = a[2..].to_string();
            }
            _ if a.starts_with("--export=") => {
                opts.op = Op::Export;
                opts.export_format = a[9..].to_string();
            }
            _ if a.starts_with("--") && a.contains("filter-") => {
                if i + 1 < args.len() && !args[i + 1].starts_with('-') {
                    i += 1;
                }
            }
            _ => return Err(format!("unknown option: {}", a)),
        }
        i += 1;
    }
    Ok(())
}

fn set_day(opts: &mut Opts, v: &str) -> Result<(), String> {
    opts.op = Op::Query { cal: true, todo: false };
    opts.filter_type = Some("cal".to_string());
    if let Ok(n) = v.parse::<i64>() {
        opts.days = Some(n);
    } else {
        opts.from = Some(parse_input_date(v, opts.input_fmt)?);
        opts.days = Some(1);
    }
    Ok(())
}

fn set_range(opts: &mut Opts, v: &str) -> Result<(), String> {
    opts.op = Op::Query { cal: true, todo: false };
    opts.filter_type = Some("cal".to_string());
    opts.days = Some(v.parse().unwrap_or(1));
    Ok(())
}

fn set_start(opts: &mut Opts, v: &str) -> Result<(), String> {
    opts.op = Op::Query { cal: true, todo: false };
    opts.filter_type = Some("cal".to_string());
    opts.from = Some(parse_input_date(v, opts.input_fmt)?);
    opts.days = Some(1);
    Ok(())
}

fn set_todo(opts: &mut Opts, _v: Option<&str>) -> Result<(), String> {
    opts.op = Op::Query { cal: false, todo: true };
    opts.filter_type = Some("todo".to_string());
    if let Some(v) = _v {
        let n: i32 = v.parse().unwrap_or(-1);
        if n == 0 {
            opts.todo_done = Some(true);
        } else if n > 0 {
            opts.todo_done = Some(false);
            opts.todo_pri = Some(n);
        }
    }
    Ok(())
}

fn run(opts: &Opts) -> Result<(), String> {
    match opts.op {
        Op::Help => {
            print_help();
            Ok(())
        }
        Op::Version => {
            println!("calcurse 4.8.2 -- text-based organizer\n\nCopyright (c) 2004-2023 calcurse Development Team.\nThis is free software; see the source for copying conditions.");
            Ok(())
        }
        Op::Status => {
            println!("calcurse is not running");
            Ok(())
        }
        Op::Gc => Ok(()),
        Op::Daemon => Ok(()),
        Op::Interactive => {
            eprintln!("Interactive mode is not available in this reimplementation.");
            Ok(())
        }
        Op::Import => import_ical(opts),
        Op::Export => {
            let (cal, todo) = load_data(opts);
            export_ical(&cal, &todo);
            Ok(())
        }
        Op::Grep => {
            let (cal, todo) = load_data(opts);
            for t in &todo {
                if todo_matches(t, opts) && type_allows("todo", opts) {
                    if opts.format_todo == "%p. %m\n" {
                        println!("{}", t.raw);
                    } else {
                        print!("{}", apply_todo_format(&opts.format_todo, t));
                    }
                }
            }
            for c in &cal {
                let typ = if matches!(c.kind, CalKind::Event) { "event" } else { "apt" };
                if item_matches(&c.msg, opts) && type_allows(typ, opts) {
                    if matches!(c.kind, CalKind::Event) && opts.format_event != " * %m\n" {
                        print!("{}", apply_cal_format(&opts.format_event, c, c.start));
                    } else if matches!(c.kind, CalKind::Apt { .. }) && opts.format_apt != " - %S -> %E\n\t%m\n" {
                        print!("{}", apply_cal_format(&opts.format_apt, c, c.start));
                    } else {
                        println!("{}", c.raw);
                    }
                }
            }
            Ok(())
        }
        Op::Purge => {
            let (cal, todo) = load_data(opts);
            save_data(opts, &cal, &todo)?;
            Ok(())
        }
        Op::Next => {
            println!("No upcoming appointment.");
            Ok(())
        }
        Op::Query { cal, todo } => {
            let (items, todos) = load_data(opts);
            if todo {
                print_todos(&todos, opts, cal);
            }
            if cal {
                print_calendar(&items, opts);
            }
            Ok(())
        }
    }
}

fn paths(opts: &Opts) -> (PathBuf, PathBuf) {
    let cal = opts.calfile.clone().unwrap_or_else(|| opts.datadir.join("apts"));
    let todo = opts.datadir.join("todo");
    (cal, todo)
}

fn load_data(opts: &Opts) -> (Vec<CalItem>, Vec<Todo>) {
    let (calp, todop) = paths(opts);
    let mut cal = Vec::new();
    if let Ok(s) = fs::read_to_string(calp) {
        for line in s.lines() {
            if let Some(x) = parse_cal_line(line) {
                cal.push(x);
            }
        }
    }
    cal.sort_by_key(|c| (c.start, item_time(c)));
    let mut todo = Vec::new();
    if let Ok(s) = fs::read_to_string(todop) {
        for line in s.lines() {
            if let Some(t) = parse_todo_line(line) {
                todo.push(t);
            }
        }
    }
    todo.sort_by_key(|t| (t.done, t.pri.abs()));
    (cal, todo)
}

fn save_data(opts: &Opts, cal: &[CalItem], todo: &[Todo]) -> Result<(), String> {
    fs::create_dir_all(&opts.datadir).map_err(|e| e.to_string())?;
    let (calp, todop) = paths(opts);
    let mut cf = File::create(calp).map_err(|e| e.to_string())?;
    for c in cal {
        writeln!(cf, "{}", c.raw).map_err(|e| e.to_string())?;
    }
    let mut tf = File::create(todop).map_err(|e| e.to_string())?;
    for t in todo {
        writeln!(tf, "{}", t.raw).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn parse_cal_line(line: &str) -> Option<CalItem> {
    let raw = line.to_string();
    let (main, msg) = split_msg(line);
    if let Some(at) = main.find(" @ ") {
        let start = parse_mmddyyyy(&main[..at])?;
        let rest = &main[at + 3..];
        let arrow = rest.find(" -> ")?;
        let st = parse_time(&rest[..arrow])?;
        let rest2 = &rest[arrow + 4..];
        let at2 = rest2.find(" @ ")?;
        let end = parse_mmddyyyy(&rest2[..at2])?;
        let tail = &rest2[at2 + 3..];
        let etxt = tail.split_whitespace().next().unwrap_or(tail);
        let et = parse_time(etxt)?;
        let recur = parse_recur(tail);
        Some(CalItem { start, kind: CalKind::Apt { end, start_time: st, end_time: et }, recur, note: parse_note(tail), msg, raw })
    } else if let Some(br) = main.find('[') {
        let start = parse_mmddyyyy(main[..br].trim())?;
        let rb = main[br + 1..].find(']')?;
        let _days: i64 = main[br + 1..br + 1 + rb].trim().parse().unwrap_or(1);
        let recur = parse_recur(&main);
        Some(CalItem { start, kind: CalKind::Event, recur, note: parse_note(&main), msg, raw })
    } else {
        None
    }
}

fn split_msg(line: &str) -> (String, String) {
    if let Some(p) = line.rfind('|') {
        (line[..p].trim_end().to_string(), line[p + 1..].to_string())
    } else if let Some(p) = line.find(']') {
        (line[..=p].to_string(), line[p + 1..].trim_start().to_string())
    } else {
        (line.to_string(), String::new())
    }
}

fn parse_note(s: &str) -> Option<String> {
    s.find('>').map(|p| s[p + 1..].split_whitespace().next().unwrap_or("").to_string())
}

fn parse_recur(s: &str) -> Option<Recur> {
    let lb = s.find('{')?;
    let rb = s[lb + 1..].find('}')? + lb + 1;
    let mut parts = s[lb + 1..rb].split_whitespace();
    let first = parts.next()?;
    let freq = first.chars().last()?;
    let interval = first[..first.len() - 1].parse().unwrap_or(1);
    let mut until = None;
    while let Some(p) = parts.next() {
        if p == "->" {
            until = parts.next().and_then(parse_mmddyyyy);
            break;
        }
    }
    Some(Recur { freq, interval, until })
}

fn parse_todo_line(line: &str) -> Option<Todo> {
    let rb = line.find(']')?;
    let n: i32 = line.get(1..rb)?.trim().parse().ok()?;
    let done = n < 0;
    Some(Todo { pri: n.abs(), done, msg: line[rb + 1..].trim_start().to_string(), raw: line.to_string() })
}

fn print_todos(todos: &[Todo], opts: &Opts, with_calendar: bool) {
    let mut count = 0usize;
    if !with_calendar {
        let completed_only = env::args().any(|a| a == "-t0" || a == "--todo=0");
        if completed_only {
            println!("completed tasks:");
        } else {
            println!("to do:");
        }
        for t in todos {
                if completed_only != t.done || !todo_matches(t, opts) {
                continue;
            }
            print!("{}", apply_todo_format(&opts.format_todo, t));
            count += 1;
            if opts.limit == Some(count) { break; }
        }
    } else {
        println!("to do:");
        for t in todos {
            if !todo_matches(t, opts) { continue; }
            print!("{}", apply_todo_format(&opts.format_todo, t));
        }
        println!();
    }
}

fn print_calendar(items: &[CalItem], opts: &Opts) {
    let (from, to) = query_range(opts);
    let mut day = from;
    let mut printed = 0usize;
    while day <= to {
        let todays: Vec<&CalItem> = items.iter()
            .filter(|c| occurs_on(c, day) && item_matches(&c.msg, opts))
            .collect();
        if !todays.is_empty() {
            println!("{}:", format_date_out(day, &opts.output_fmt));
            for c in todays {
                match c.kind {
        CalKind::Event => print!("{}", apply_cal_format(&opts.format_event, c, day)),
                    CalKind::Apt { .. } => print!("{}", apply_cal_format(&opts.format_apt, c, day)),
                }
                printed += 1;
                if opts.limit == Some(printed) { return; }
            }
            println!();
        }
        day = add_days(day, 1);
    }
}

fn query_range(opts: &Opts) -> (Date, Date) {
    let mut from = opts.from.unwrap_or_else(today);
    if let Some(days) = opts.days {
        if days < 0 {
            let to = from;
            from = add_days(from, days + 1);
            (from, to)
        } else {
            (from, add_days(from, days - 1))
        }
    } else if let Some(to) = opts.to {
        (from, to)
    } else {
        (from, from)
    }
}

fn occurs_on(c: &CalItem, day: Date) -> bool {
    if let Some(r) = &c.recur {
        if day < c.start { return false; }
        if let Some(u) = r.until {
            if day > u { return false; }
        }
        let diff = days_between(c.start, day);
        return match r.freq {
            'D' => diff % r.interval == 0,
            'W' => diff % (7 * r.interval) == 0,
            'M' => month_diff(c.start, day) % r.interval == 0 && c.start.d == day.d,
            'Y' => (day.y - c.start.y) as i64 % r.interval == 0 && c.start.m == day.m && c.start.d == day.d,
            _ => day == c.start,
        };
    }
    match c.kind {
        CalKind::Event => day == c.start,
        CalKind::Apt { end, .. } => day >= c.start && day <= end,
    }
}

fn item_matches(msg: &str, opts: &Opts) -> bool {
    if let Some(s) = &opts.search {
        msg.contains(s)
    } else {
        true
    }
}

fn todo_matches(t: &Todo, opts: &Opts) -> bool {
    if let Some(done) = opts.todo_done {
        if t.done != done { return false; }
    }
    if let Some(pri) = opts.todo_pri {
        if t.pri != pri { return false; }
    }
    item_matches(&t.msg, opts)
}

fn type_allows(kind: &str, opts: &Opts) -> bool {
    let Some(f) = &opts.filter_type else { return true; };
    if f == "cal" { return kind == "event" || kind == "apt"; }
    f.split(',').any(|x| x == kind || (x == "todo" && kind == "todo"))
}

fn apply_todo_format(fmt: &str, t: &Todo) -> String {
    fmt.replace("\\n", "\n").replace("%p", &t.pri.to_string()).replace("%m", &t.msg).replace("%(raw)", &t.raw)
}

fn apply_cal_format(fmt: &str, c: &CalItem, day: Date) -> String {
    let mut s = fmt.replace("\\n", "\n").replace("\\t", "\t");
    match c.kind {
        CalKind::Event => {
            s = s.replace("%m", &c.msg).replace("%(raw)", &c.raw);
        }
        CalKind::Apt { end, start_time, end_time } => {
            let ss = if day > c.start { "..:..".to_string() } else { fmt_time(start_time) };
            let ee = if end > day { "..:..".to_string() } else { fmt_time(end_time) };
            let dur = duration_secs(c);
            s = s.replace("%S", &ss)
                .replace("%E", &ee)
                .replace("%m", &c.msg)
                .replace("%d", &dur.to_string())
                .replace("%(raw)", &c.raw);
        }
    }
    if let Some(n) = &c.note {
        s = s.replace("%n", n);
    }
    s.replace("%N", "")
}

fn duration_secs(c: &CalItem) -> i64 {
    if let CalKind::Apt { end, start_time, end_time } = c.kind {
        days_between(c.start, end) * 86400 + (end_time.h as i64 * 3600 + end_time.m as i64 * 60) - (start_time.h as i64 * 3600 + start_time.m as i64 * 60)
    } else {
        0
    }
}

fn item_time(c: &CalItem) -> Time {
    match c.kind {
        CalKind::Apt { start_time, .. } => start_time,
        _ => Time { h: 0, m: 0 },
    }
}

fn import_ical(opts: &Opts) -> Result<(), String> {
    let file = opts.import_file.as_ref().ok_or("missing import file")?;
    let mut s = String::new();
    File::open(file).map_err(|e| e.to_string())?.read_to_string(&mut s).map_err(|e| e.to_string())?;
    let mut cal = Vec::new();
    let mut todos = Vec::new();
    let lines: Vec<&str> = s.lines().collect();
    let mut i = 0;
    while i < lines.len() {
        if lines[i] == "BEGIN:VEVENT" {
            let mut dt = None;
            let mut dur = 0i64;
            let mut summary = String::new();
            let mut rrule = None;
            i += 1;
            while i < lines.len() && lines[i] != "END:VEVENT" {
                let l = lines[i];
                if l.starts_with("DTSTART") { dt = l.split(':').nth(1).and_then(parse_ical_dt); }
                if l.starts_with("DURATION:") { dur = parse_duration(&l[9..]); }
                if l.starts_with("SUMMARY:") { summary = unescape_ical(&l[8..]); }
                if l.starts_with("RRULE:") { rrule = Some(l[6..].to_string()); }
                i += 1;
            }
            if let Some((d, t, is_date)) = dt {
                let raw = if is_date || dur % 86400 == 0 && t.h == 0 && t.m == 0 {
                    format!("{} [{}] {}", fmt_mmddyyyy(d), std::cmp::max(1, dur / 86400), summary)
                } else {
                    let end_dt = add_minutes(d, t, dur / 60);
                    let rec = rrule.as_ref().and_then(|r| rrule_to_recur(r));
                    format!("{} @ {} -> {} @ {}{}|{}", fmt_mmddyyyy(d), fmt_time(t), fmt_mmddyyyy(end_dt.0), fmt_time(end_dt.1), rec.unwrap_or_default(), summary)
                };
                if let Some(ci) = parse_cal_line(&raw) { cal.push(ci); }
            }
        } else if lines[i] == "BEGIN:VTODO" {
            let mut pri = 0;
            let mut done = false;
            let mut summary = String::new();
            i += 1;
            while i < lines.len() && lines[i] != "END:VTODO" {
                let l = lines[i];
                if let Some(v) = l.strip_prefix("PRIORITY:") { pri = v.parse().unwrap_or(0); }
                if l == "STATUS:COMPLETED" { done = true; }
                if let Some(v) = l.strip_prefix("SUMMARY:") { summary = unescape_ical(v); }
                i += 1;
            }
            let n = if done { -pri } else { pri };
            if let Some(t) = parse_todo_line(&format!("[{}] {}", n, summary)) { todos.push(t); }
        }
        i += 1;
    }
    fs::create_dir_all(&opts.datadir).map_err(|e| e.to_string())?;
    let (calp, todop) = paths(opts);
    let mut cf = File::options().create(true).append(true).open(calp).map_err(|e| e.to_string())?;
    for c in &cal { writeln!(cf, "{}", c.raw).map_err(|e| e.to_string())?; }
    let mut tf = File::options().create(true).append(true).open(todop).map_err(|e| e.to_string())?;
    for t in &todos { writeln!(tf, "{}", t.raw).map_err(|e| e.to_string())?; }
    if !opts.quiet {
                    println!("{} apps / {} events / {} todos / 0 skipped", cal.iter().filter(|c| matches!(c.kind, CalKind::Apt { .. })).count(), cal.iter().filter(|c| matches!(c.kind, CalKind::Event)).count(), todos.len());
    }
    Ok(())
}

fn rrule_to_recur(r: &str) -> Option<String> {
    let mut freq = "D";
    let mut interval = "1";
    let mut until = None;
    for p in r.split(';') {
        if let Some(v) = p.strip_prefix("FREQ=") {
            freq = match v { "DAILY" => "D", "WEEKLY" => "W", "MONTHLY" => "M", "YEARLY" => "Y", _ => "D" };
        }
        if let Some(v) = p.strip_prefix("INTERVAL=") { interval = v; }
        if let Some(v) = p.strip_prefix("UNTIL=") { until = parse_ical_date8(v).map(fmt_mmddyyyy); }
    }
    Some(if let Some(u) = until { format!(" {{{}{} -> {}}} ", interval, freq, u) } else { format!(" {{{}{}}} ", interval, freq) })
}

fn export_ical(cal: &[CalItem], todos: &[Todo]) {
    println!("BEGIN:VCALENDAR");
    println!("VERSION:2.0");
    println!("PRODID:-//calcurse//NONSGML v4.8.2//EN");
    for c in cal {
        println!("BEGIN:VEVENT");
        match c.kind {
            CalKind::Event => {
                println!("DTSTART;VALUE=DATE:{}{:02}{:02}", c.start.y, c.start.m, c.start.d);
                println!("SUMMARY:{}", escape_ical(&c.msg));
            }
            CalKind::Apt { end: _, start_time, .. } => {
                println!("DTSTART:{}{:02}{:02}T{:02}{:02}00", c.start.y, c.start.m, c.start.d, start_time.h, start_time.m);
                let d = duration_secs(c);
                println!("DURATION:P{}DT{}H{}M{}S", d / 86400, (d % 86400) / 3600, (d % 3600) / 60, d % 60);
                println!("SUMMARY:{}", escape_ical(&c.msg));
            }
        }
        println!("END:VEVENT");
    }
    for t in todos {
        println!("BEGIN:VTODO");
        println!("PRIORITY:{}", t.pri);
        println!("SUMMARY:{}", escape_ical(&t.msg));
        if t.done { println!("STATUS:COMPLETED"); }
        println!("END:VTODO");
    }
    println!("END:VCALENDAR");
}

fn print_help() {
    print!("Usage:\ncalcurse [-D <directory>] [-C <directory>] [-c <calendar file>]\ncalcurse -Q [--from <date>] [--to <date>] [--days <number>]\ncalcurse -a | -d <date> | -d <number> | -n | -r[<number>] | -s[<date>] | -t[<number>]\ncalcurse -h | -v | --status | -G | -P | -g | -i <file> | -x[<format>] | --daemon\n\nOperations in command line mode:\n  -Q, --query   Print items in a given query range\n  -G, --grep    Grep items from the data files\n  -P, --purge   Read items and write them back\nQuery short forms:\n-a, -d <date>|<number>, -n, -r[<number>], -s[<date>], -t<number>\n\nNote that filter, format and day-range options affect input or output:\n  --filter-*              Filter items loaded by -Q, -G, -P and -x\n  --format-*              Rewrite output from -Q, -G and --dump-imported\n  --from <date>           Limit day range of -Q.\n  --to <date>             Limit day range of -Q.\n  --days <number>         Limit day range of -Q.\n\n  --limit, -l <number>    Limit number of query results\n  --search, -S <regexp>   Match regular expression in queries\nConsult the man page for details.\n\nMiscellaneous:\n  -c, --calendar <file>   The calendar data file to use\n  -C, --confdir <dir>     The configuration directory to use\n  --daemon                Run notification daemon in the background\n  -D, --datadir <dir>     The data directory to use\n  -g, --gc                Run the garbage collector\n  -h, --help              Show this help text\n  -i, --import <file>     Import iCal data from file\n  -q, --quiet             Suppress import/export result message\n  --read-only             Do not save configuration or data files\n  --status                Display status of running instances\n  -v, --version           Show version information\n  -x, --export[<format>]  Export to stdout in ical (default) or pcal format\n\nFor more information, type '?' from within calcurse, or read the manpage.\nSubmit feature requests and suggestions to <misc@calcurse.org>.\nSubmit bug reports to <bugs@calcurse.org>.\n");
}

fn today() -> Date {
    if let Ok(out) = std::process::Command::new("date").arg("+%Y-%m-%d").output() {
        if let Ok(s) = String::from_utf8(out.stdout) {
            if let Some(d) = parse_yyyy_mm_dd(s.trim()) { return d; }
        }
    }
    Date { y: 2026, m: 5, d: 29 }
}

fn parse_input_date(s: &str, fmt: u8) -> Result<Date, String> {
    let sl = s.to_lowercase();
    let t = today();
    match sl.as_str() {
        "today" | "now" => return Ok(t),
        "tomorrow" => return Ok(add_days(t, 1)),
        "yesterday" => return Ok(add_days(t, -1)),
        "mon" | "monday" | "tue" | "tuesday" | "wed" | "wednesday" | "thu" | "thursday" | "fri" | "friday" | "sat" | "saturday" | "sun" | "sunday" => {
            let target = weekday_name(&sl);
            let cur = weekday(t);
            let mut delta = (target + 7 - cur) % 7;
            if delta == 0 { delta = 7; }
            return Ok(add_days(t, delta as i64));
        }
        _ => {}
    }
    let datepart = s.split_whitespace().next().unwrap_or(s);
    let d = match fmt {
        4 => parse_yyyy_mm_dd(datepart),
        3 => parse_yyyy_mm_dd_slash(datepart),
        2 => parse_ddmmyyyy(datepart),
        _ => parse_mmddyyyy(datepart),
    };
    d.ok_or_else(|| format!("args.c: 797: invalid date: {}", s))
}

fn parse_mmddyyyy(s: &str) -> Option<Date> {
    let p: Vec<_> = s.trim().split('/').collect();
    if p.len() != 3 { return None; }
    valid(Date { m: p[0].parse().ok()?, d: p[1].parse().ok()?, y: p[2].parse().ok()? })
}

fn parse_ddmmyyyy(s: &str) -> Option<Date> {
    let p: Vec<_> = s.trim().split('/').collect();
    if p.len() != 3 { return None; }
    valid(Date { d: p[0].parse().ok()?, m: p[1].parse().ok()?, y: p[2].parse().ok()? })
}

fn parse_yyyy_mm_dd_slash(s: &str) -> Option<Date> {
    let p: Vec<_> = s.trim().split('/').collect();
    if p.len() != 3 { return None; }
    valid(Date { y: p[0].parse().ok()?, m: p[1].parse().ok()?, d: p[2].parse().ok()? })
}

fn parse_yyyy_mm_dd(s: &str) -> Option<Date> {
    let p: Vec<_> = s.trim().split('-').collect();
    if p.len() != 3 { return None; }
    valid(Date { y: p[0].parse().ok()?, m: p[1].parse().ok()?, d: p[2].parse().ok()? })
}

fn parse_time(s: &str) -> Option<Time> {
    let p: Vec<_> = s.trim().split(':').collect();
    if p.len() != 2 { return None; }
    let t = Time { h: p[0].parse().ok()?, m: p[1].parse().ok()? };
    if t.h < 24 && t.m < 60 { Some(t) } else { None }
}

fn parse_ical_dt(s: &str) -> Option<(Date, Time, bool)> {
    if s.len() >= 8 {
        let d = parse_ical_date8(s)?;
        if let Some(tpos) = s.find('T') {
            let t = &s[tpos + 1..];
            let h = t.get(0..2)?.parse().ok()?;
            let m = t.get(2..4)?.parse().ok()?;
            return Some((d, Time { h, m }, false));
        }
        return Some((d, Time { h: 0, m: 0 }, true));
    }
    None
}

fn parse_ical_date8(s: &str) -> Option<Date> {
    Some(valid(Date { y: s.get(0..4)?.parse().ok()?, m: s.get(4..6)?.parse().ok()?, d: s.get(6..8)?.parse().ok()? })?)
}

fn parse_duration(s: &str) -> i64 {
    let mut n = String::new();
    let mut secs = 0;
    for ch in s.chars() {
        if ch.is_ascii_digit() {
            n.push(ch);
        } else {
            let v: i64 = n.parse().unwrap_or(0);
            n.clear();
            match ch {
                'D' => secs += v * 86400,
                'H' => secs += v * 3600,
                'M' => secs += v * 60,
                'S' => secs += v,
                _ => {}
            }
        }
    }
    secs
}

fn unescape_ical(s: &str) -> String {
    s.replace("\\,", ",").replace("\\n", "\n").replace("\\\\", "\\")
}

fn escape_ical(s: &str) -> String {
    s.replace('\\', "\\\\").replace(',', "\\,").replace('\n', "\\n")
}

fn fmt_mmddyyyy(d: Date) -> String { format!("{:02}/{:02}/{:04}", d.m, d.d, d.y) }
fn fmt_time(t: Time) -> String { format!("{:02}:{:02}", t.h, t.m) }

fn format_date_out(d: Date, fmt: &str) -> String {
    let yy = ((d.y % 100) + 100) % 100;
    fmt.replace("%D", &format!("{:02}/{:02}/{:02}", d.m, d.d, yy))
        .replace("%Y", &format!("{:04}", d.y))
        .replace("%m", &format!("{:02}", d.m))
        .replace("%d", &format!("{:02}", d.d))
}

fn valid(d: Date) -> Option<Date> {
    if d.m >= 1 && d.m <= 12 && d.d >= 1 && d.d <= dim(d.y, d.m) { Some(d) } else { None }
}

fn leap(y: i32) -> bool { (y % 4 == 0 && y % 100 != 0) || y % 400 == 0 }
fn dim(y: i32, m: u32) -> u32 {
    match m { 1|3|5|7|8|10|12 => 31, 4|6|9|11 => 30, 2 => if leap(y) { 29 } else { 28 }, _ => 0 }
}

fn days_from_civil(d: Date) -> i64 {
    let mut y = d.y as i64;
    let m = d.m as i64;
    let dd = d.d as i64;
    y -= (m <= 2) as i64;
    let era = if y >= 0 { y } else { y - 399 } / 400;
    let yoe = y - era * 400;
    let mp = m + if m > 2 { -3 } else { 9 };
    let doy = (153 * mp + 2) / 5 + dd - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    era * 146097 + doe - 719468
}

fn civil_from_days(z: i64) -> Date {
    let z = z + 719468;
    let era = if z >= 0 { z } else { z - 146096 } / 146097;
    let doe = z - era * 146097;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = mp + if mp < 10 { 3 } else { -9 };
    Date { y: (y + (m <= 2) as i64) as i32, m: m as u32, d: d as u32 }
}

fn add_days(d: Date, n: i64) -> Date { civil_from_days(days_from_civil(d) + n) }
fn days_between(a: Date, b: Date) -> i64 { days_from_civil(b) - days_from_civil(a) }
fn month_diff(a: Date, b: Date) -> i64 { (b.y - a.y) as i64 * 12 + b.m as i64 - a.m as i64 }

fn add_minutes(d: Date, t: Time, mins: i64) -> (Date, Time) {
    let total = t.h as i64 * 60 + t.m as i64 + mins;
    let days = total.div_euclid(1440);
    let rem = total.rem_euclid(1440);
    (add_days(d, days), Time { h: (rem / 60) as u32, m: (rem % 60) as u32 })
}

fn weekday(d: Date) -> u32 {
    ((days_from_civil(d) + 4).rem_euclid(7)) as u32
}

fn weekday_name(s: &str) -> u32 {
    match &s[..3] {
        "sun" => 0, "mon" => 1, "tue" => 2, "wed" => 3, "thu" => 4, "fri" => 5, "sat" => 6, _ => 0
    }
}
