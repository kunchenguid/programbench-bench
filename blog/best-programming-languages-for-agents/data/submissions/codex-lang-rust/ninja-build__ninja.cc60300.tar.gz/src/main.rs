use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};
use std::time::UNIX_EPOCH;

const VERSION: &str = "1.14.0.git";

#[derive(Clone, Default)]
struct Env {
    vars: HashMap<String, String>,
}

impl Env {
    fn get(&self, k: &str) -> String {
        self.vars.get(k).cloned().unwrap_or_default()
    }
    fn set(&mut self, k: String, v: String) {
        self.vars.insert(k, v);
    }
}

#[derive(Clone, Default)]
struct Rule {
    name: String,
    vars: HashMap<String, String>,
}

#[derive(Clone, Default)]
struct Edge {
    rule: String,
    explicit_outs: Vec<String>,
    implicit_outs: Vec<String>,
    explicit_ins: Vec<String>,
    implicit_ins: Vec<String>,
    order_only: Vec<String>,
    validations: Vec<String>,
    vars: HashMap<String, String>,
}

impl Edge {
    fn all_outs(&self) -> Vec<String> {
        let mut v = self.explicit_outs.clone();
        v.extend(self.implicit_outs.clone());
        v
    }
    fn all_ins(&self) -> Vec<String> {
        let mut v = self.explicit_ins.clone();
        v.extend(self.implicit_ins.clone());
        v.extend(self.order_only.clone());
        v
    }
}

#[derive(Default)]
struct Manifest {
    env: Env,
    rules: HashMap<String, Rule>,
    edges: Vec<Edge>,
    out_to_edge: HashMap<String, usize>,
    defaults: Vec<String>,
}

fn main() {
    let code = match real_main() {
        Ok(c) => c,
        Err(e) => {
            eprintln!("ninja: error: {}", e);
            1
        }
    };
    std::process::exit(code);
}

fn real_main() -> Result<i32, String> {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "--version") {
        println!("{}", VERSION);
        return Ok(0);
    }
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_help();
        return Ok(1);
    }

    let mut file = "build.ninja".to_string();
    let mut chdir: Option<String> = None;
    let mut verbose = false;
    let mut quiet = false;
    let mut dry_run = false;
    let mut jobs = None::<usize>;
    let mut keep_going = 1usize;
    let mut tool: Option<(String, Vec<String>)> = None;
    let mut targets = Vec::new();

    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        match a.as_str() {
            "-v" | "--verbose" => verbose = true,
            "--quiet" => quiet = true,
            "-n" | "--dry-run" => dry_run = true,
            "-C" => {
                i += 1;
                chdir = Some(args.get(i).ok_or("option requires an argument -- C")?.clone());
            }
            "-f" => {
                i += 1;
                file = args.get(i).ok_or("option requires an argument -- f")?.clone();
            }
            "-j" => {
                i += 1;
                jobs = Some(args.get(i).ok_or("option requires an argument -- j")?.parse().unwrap_or(1));
            }
            "-k" => {
                i += 1;
                keep_going = args.get(i).ok_or("option requires an argument -- k")?.parse().unwrap_or(1);
            }
            "-l" => {
                i += 1;
                let _ = args.get(i);
            }
            "-d" => {
                i += 1;
                if args.get(i).map(|s| s.as_str()) == Some("list") {
                    print_debug_modes();
                    return Ok(1);
                }
            }
            "-w" => {
                i += 1;
                if args.get(i).map(|s| s.as_str()) == Some("list") {
                    print_warnings();
                    return Ok(1);
                }
            }
            "-t" => {
                i += 1;
                let name = args.get(i).ok_or("option requires an argument -- t")?.clone();
                tool = Some((name, args[i + 1..].to_vec()));
                break;
            }
            _ if a.starts_with("-j") && a.len() > 2 => {
                jobs = Some(a[2..].parse().unwrap_or(1));
            }
            _ if a.starts_with("-k") && a.len() > 2 => {
                keep_going = a[2..].parse().unwrap_or(1);
            }
            _ if a.starts_with("-C") && a.len() > 2 => {
                chdir = Some(a[2..].to_string());
            }
            _ if a.starts_with("-f") && a.len() > 2 => {
                file = a[2..].to_string();
            }
            _ if a.starts_with("-l") && a.len() > 2 => {}
            _ if a.starts_with("-") => return Err(format!("unknown option '{}', did you mean '-h'?", a)),
            _ => targets.push(a),
        }
        i += 1;
    }

    if let Some(dir) = chdir {
        println!("ninja: Entering directory `{}`", dir);
        env::set_current_dir(&dir).map_err(|e| format!("chdir to '{}': {}", dir, e))?;
    }
    if let Some((name, rest)) = &tool {
        if name == "list" {
            return run_tool(&Manifest::default(), name, rest, verbose, dry_run);
        }
    }
    let manifest = parse_manifest(Path::new(&file))?;
    if let Some((name, rest)) = tool {
        return run_tool(&manifest, &name, &rest, verbose, dry_run);
    }
    let _ = jobs;
    run_build(&manifest, targets, verbose, quiet, dry_run, keep_going)
}

fn print_help() {
    println!("usage: ninja [options] [targets...]\n");
    println!("if targets are unspecified, builds the 'default' target (see manual).\n");
    println!("options:");
    println!("  --version      print ninja version (\"{}\")", VERSION);
    println!("  -v, --verbose  show all command lines while building");
    println!("  --quiet        don't show progress status, just command output\n");
    println!("  -C DIR   change to DIR before doing anything else");
    println!("  -f FILE  specify input build file [default=build.ninja]\n");
    println!("  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]");
    println!("  -k N     keep going until N jobs fail (0 means infinity) [default=1]");
    println!("  -l N     do not start new jobs if the load average is greater than N");
    println!("  -n       dry run (don't run commands but act like they succeeded)\n");
    println!("  -d MODE  enable debugging (use '-d list' to list modes)");
    println!("  -t TOOL  run a subtool (use '-t list' to list subtools)");
    println!("    terminates toplevel options; further flags are passed to the tool");
    println!("  -w FLAG  adjust warnings (use '-w list' to list warnings)");
}

fn print_debug_modes() {
    println!("debugging modes:");
    println!("  stats        print operation counts/timing info");
    println!("  explain      explain what caused a command to execute");
    println!("  keepdepfile  don't delete depfiles after they're read by ninja");
    println!("  keeprsp      don't delete @response files on success");
    println!("multiple modes can be enabled via -d FOO -d BAR");
}

fn print_warnings() {
    println!("warning flags:");
    println!("  phonycycle={{err,warn}}  phony build statement references itself");
}

fn parse_manifest(path: &Path) -> Result<Manifest, String> {
    let mut m = Manifest::default();
    m.rules.insert("phony".to_string(), Rule { name: "phony".to_string(), vars: HashMap::new() });
    parse_file(path, &mut m, &mut Env::default())
        .map_err(|e| format!("loading '{}': {}", path.display(), e))?;
    Ok(m)
}

fn parse_file(path: &Path, m: &mut Manifest, parent_env: &mut Env) -> Result<(), String> {
    let content = fs::read_to_string(path).map_err(|e| {
        if e.kind() == io::ErrorKind::NotFound {
            "No such file or directory".to_string()
        } else {
            e.to_string()
        }
    })?;
    let base = path.parent().unwrap_or(Path::new(".")).to_path_buf();
    let lines = logical_lines(&content);
    let mut i = 0usize;
    while i < lines.len() {
        let raw = &lines[i];
        let trimmed = strip_comment(raw).trim_end().to_string();
        if trimmed.trim().is_empty() {
            i += 1;
            continue;
        }
        if raw.starts_with(' ') || raw.starts_with('\t') {
            return Err(format!("{}: unexpected indent", i + 1));
        }
        if let Some(rest) = trimmed.strip_prefix("rule ") {
            let name = rest.trim().to_string();
            let mut rule = Rule { name: name.clone(), vars: HashMap::new() };
            i += 1;
            while i < lines.len() && is_indented(&lines[i]) {
                if let Some((k, v)) = parse_binding(&lines[i]) {
                    rule.vars.insert(k, v);
                }
                i += 1;
            }
            m.rules.insert(name, rule);
            continue;
        }
        if let Some(rest) = trimmed.strip_prefix("pool ") {
            i += 1;
            while i < lines.len() && is_indented(&lines[i]) {
                i += 1;
            }
            let _ = rest;
            continue;
        }
        if let Some(rest) = trimmed.strip_prefix("build ") {
            let mut edge = parse_build(rest, parent_env)?;
            i += 1;
            while i < lines.len() && is_indented(&lines[i]) {
                if let Some((k, v)) = parse_binding(&lines[i]) {
                    edge.vars.insert(k, expand_vars(&v, parent_env, &HashMap::new()));
                }
                i += 1;
            }
            let idx = m.edges.len();
            for o in edge.all_outs() {
                m.out_to_edge.insert(o, idx);
            }
            m.edges.push(edge);
            continue;
        }
        if let Some(rest) = trimmed.strip_prefix("default ") {
            let toks = parse_path_list(rest, parent_env);
            m.defaults.extend(toks);
            i += 1;
            continue;
        }
        if let Some(rest) = trimmed.strip_prefix("include ") {
            let p = expand_vars(rest.trim(), parent_env, &HashMap::new());
            parse_file(&base.join(p), m, parent_env)?;
            i += 1;
            continue;
        }
        if let Some(rest) = trimmed.strip_prefix("subninja ") {
            let p = expand_vars(rest.trim(), parent_env, &HashMap::new());
            let mut child = parent_env.clone();
            parse_file(&base.join(p), m, &mut child)?;
            i += 1;
            continue;
        }
        if let Some((k, v)) = parse_binding(&trimmed) {
            let expanded = expand_vars(&v, parent_env, &HashMap::new());
            parent_env.set(k.clone(), expanded.clone());
            m.env.set(k, expanded);
            i += 1;
            continue;
        }
        return Err(format!("{}: expected '=', got identifier", i + 1));
    }
    Ok(())
}

fn logical_lines(content: &str) -> Vec<String> {
    let mut res = Vec::new();
    let mut cur = String::new();
    let mut cont = false;
    for line in content.lines() {
        let mut l = line.to_string();
        if cont {
            l = l.trim_start().to_string();
            cont = false;
        }
        if l.ends_with('$') {
            l.pop();
            cur.push_str(&l);
            cont = true;
        } else {
            cur.push_str(&l);
            res.push(cur.clone());
            cur.clear();
        }
    }
    if !cur.is_empty() {
        res.push(cur);
    }
    res
}

fn strip_comment(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c == '$' {
            out.push(c);
            if let Some(n) = chars.next() { out.push(n); }
        } else if c == '#' {
            break;
        } else {
            out.push(c);
        }
    }
    out
}

fn is_indented(s: &str) -> bool {
    s.starts_with(' ') || s.starts_with('\t')
}

fn parse_binding(s: &str) -> Option<(String, String)> {
    let t = s.trim_start();
    let pos = t.find('=')?;
    let k = t[..pos].trim().to_string();
    let v = t[pos + 1..].trim_start().to_string();
    Some((k, v))
}

fn parse_build(rest: &str, env: &Env) -> Result<Edge, String> {
    let colon = find_unescaped_colon(rest).ok_or("expected ':' in build line")?;
    let outs_part = &rest[..colon];
    let rhs = rest[colon + 1..].trim_start();
    let mut out_tokens = parse_path_list(outs_part, env);
    let pipe_pos = out_tokens.iter().position(|t| t == "|");
    let implicit_outs = if let Some(p) = pipe_pos { out_tokens.split_off(p + 1) } else { Vec::new() };
    if pipe_pos.is_some() { out_tokens.pop(); }
    let toks = parse_path_list(rhs, env);
    if toks.is_empty() {
        return Err("expected rule name".to_string());
    }
    let rule = toks[0].clone();
    let mut explicit = Vec::new();
    let mut implicit = Vec::new();
    let mut order = Vec::new();
    let mut validations = Vec::new();
    let mut mode = 0;
    for t in toks.into_iter().skip(1) {
        match t.as_str() {
            "|" => mode = 1,
            "||" => mode = 2,
            "|@" => mode = 3,
            _ => match mode {
                0 => explicit.push(t),
                1 => implicit.push(t),
                2 => order.push(t),
                _ => validations.push(t),
            }
        }
    }
    Ok(Edge {
        rule,
        explicit_outs: out_tokens,
        implicit_outs,
        explicit_ins: explicit,
        implicit_ins: implicit,
        order_only: order,
        validations,
        vars: HashMap::new(),
    })
}

fn find_unescaped_colon(s: &str) -> Option<usize> {
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'$' {
            i += 2;
            continue;
        }
        if bytes[i] == b':' {
            return Some(i);
        }
        i += 1;
    }
    None
}

fn parse_path_list(s: &str, env: &Env) -> Vec<String> {
    let mut raw = Vec::new();
    let mut cur = String::new();
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c.is_whitespace() {
            if !cur.is_empty() {
                raw.push(cur.clone());
                cur.clear();
            }
        } else if c == '$' {
            match chars.peek().copied() {
                Some(' ') => { chars.next(); cur.push(' '); }
                Some(':') => { chars.next(); cur.push(':'); }
                Some('$') => { chars.next(); cur.push('$'); }
                Some('{') => {
                    chars.next();
                    let mut name = String::new();
                    while let Some(ch) = chars.next() {
                        if ch == '}' { break; }
                        name.push(ch);
                    }
                    cur.push_str(&env.get(&name));
                }
                Some(ch) if is_var_char(ch) => {
                    let mut name = String::new();
                    while let Some(ch2) = chars.peek().copied() {
                        if is_var_char(ch2) {
                            name.push(ch2);
                            chars.next();
                        } else {
                            break;
                        }
                    }
                    cur.push_str(&env.get(&name));
                }
                Some(ch) => { chars.next(); cur.push(ch); }
                None => cur.push('$'),
            }
        } else {
            cur.push(c);
        }
    }
    if !cur.is_empty() {
        raw.push(cur);
    }
    raw
}

fn is_var_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_'
}

fn expand_vars(s: &str, env: &Env, local: &HashMap<String, String>) -> String {
    let mut out = String::new();
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c != '$' {
            out.push(c);
            continue;
        }
        match chars.peek().copied() {
            Some('$') => { chars.next(); out.push('$'); }
            Some(' ') => { chars.next(); out.push(' '); }
            Some(':') => { chars.next(); out.push(':'); }
            Some('^') => { chars.next(); out.push('\n'); }
            Some('{') => {
                chars.next();
                let mut name = String::new();
                while let Some(ch) = chars.next() {
                    if ch == '}' { break; }
                    name.push(ch);
                }
                out.push_str(local.get(&name).cloned().unwrap_or_else(|| env.get(&name)).as_str());
            }
            Some(ch) if is_var_char(ch) => {
                let mut name = String::new();
                while let Some(ch2) = chars.peek().copied() {
                    if is_var_char(ch2) {
                        name.push(ch2);
                        chars.next();
                    } else {
                        break;
                    }
                }
                out.push_str(local.get(&name).cloned().unwrap_or_else(|| env.get(&name)).as_str());
            }
            Some(ch) => { chars.next(); out.push(ch); }
            None => out.push('$'),
        }
    }
    out
}

fn run_tool(m: &Manifest, name: &str, args: &[String], verbose: bool, dry_run: bool) -> Result<i32, String> {
    match name {
        "list" => {
            println!("ninja subtools:");
            for (n, d) in [
                ("browse", "browse dependency graph in a web browser"),
                ("clean", "clean built files"),
                ("commands", "list all commands required to rebuild given targets"),
                ("inputs", "list all inputs required to rebuild given targets"),
                ("multi-inputs", "print one or more sets of inputs required to build targets"),
                ("deps", "show dependencies stored in the deps log"),
                ("missingdeps", "check deps log dependencies on generated files"),
                ("graph", "output graphviz dot file for targets"),
                ("query", "show inputs/outputs for a path"),
                ("targets", "list targets by their rule or depth in the DAG"),
                ("compdb", "dump JSON compilation database to stdout"),
                ("compdb-targets", "dump JSON compilation database for a given list of targets to stdout"),
                ("recompact", "recompacts ninja-internal data structures"),
                ("restat", "restats all outputs in the build log"),
                ("rules", "list all rules"),
                ("cleandead", "clean built files that are no longer produced by the manifest"),
            ] {
                println!("{:>11}  {}", n, d);
            }
        }
        "rules" => {
            let desc = args.iter().any(|a| a == "-d");
            let mut names: Vec<_> = m.rules.keys().cloned().collect();
            names.sort();
            names.retain(|n| n != "phony");
            names.push("phony".to_string());
            for n in names {
                if desc {
                    let d = m.rules.get(&n).and_then(|r| r.vars.get("description")).cloned().unwrap_or_default();
                    println!("{}: {}", n, d);
                } else {
                    println!("{}", n);
                }
            }
        }
        "targets" => tool_targets(m, args),
        "query" => {
            if args.is_empty() { return Err("expected target for query".to_string()); }
            for t in args { tool_query(m, t); }
        }
        "commands" => {
            let mut final_only = false;
            let mut t: Vec<String> = args.to_vec();
            t.retain(|a| { if a == "-s" { final_only = true; false } else { true } });
            if t.is_empty() { t = default_targets(m); }
            let mut order = Vec::new();
            collect_edges(m, &t, &mut HashSet::new(), &mut order)?;
            if final_only {
                if let Some(e) = order.last() { println!("{}", command_for(m, *e)); }
            } else {
                for e in order { if m.edges[e].rule != "phony" { println!("{}", command_for(m, e)); } }
            }
        }
        "inputs" => {
            let no_escape = args.iter().any(|a| a == "--no-shell-escape");
            let ts: Vec<String> = args.iter().filter(|a| !a.starts_with("--")).cloned().collect();
            let mut set = Vec::new();
            collect_inputs(m, &if ts.is_empty() { default_targets(m) } else { ts }, &mut HashSet::new(), &mut set)?;
            set.sort(); set.dedup();
            for x in set {
                println!("{}", if no_escape { x } else { shell_quote(&x) });
            }
        }
        "multi-inputs" => {
            let mut delim = "\t".to_string();
            let mut nul = false;
            let mut ts = Vec::new();
            let mut i = 0;
            while i < args.len() {
                if args[i] == "--print0" { nul = true; }
                else if args[i] == "--delimiter" && i + 1 < args.len() { i += 1; delim = args[i].clone(); }
                else { ts.push(args[i].clone()); }
                i += 1;
            }
            for t in ts {
                let mut ins = Vec::new();
                collect_inputs(m, &[t.clone()], &mut HashSet::new(), &mut ins)?;
                ins.sort(); ins.dedup();
                for inp in ins {
                    print!("{}{}{}{}", t, delim, inp, if nul { "\0" } else { "\n" });
                }
            }
        }
        "graph" => tool_graph(m, args)?,
        "compdb" => tool_compdb(m, args, false)?,
        "compdb-targets" => tool_compdb(m, args, true)?,
        "clean" => return tool_clean(m, args, verbose, dry_run),
        "deps" => println!(".ninja_deps: deps log not found"),
        "missingdeps" => println!("Processed 0 nodes.\nNo missing dependencies on generated files found."),
        "recompact" | "restat" | "cleandead" => {}
        _ => return Err(format!("unknown tool '{}'", name)),
    }
    Ok(0)
}

fn tool_targets(m: &Manifest, args: &[String]) {
    if args.first().map(|s| s.as_str()) == Some("all") {
        for e in &m.edges {
            for o in e.all_outs() {
                println!("{}: {}", o, e.rule);
            }
        }
    } else if args.first().map(|s| s.as_str()) == Some("rule") {
        if let Some(rule) = args.get(1) {
            for e in &m.edges {
                if &e.rule == rule {
                    for o in e.all_outs() { println!("{}", o); }
                }
            }
        }
    } else {
        let depth: usize = if args.first().map(|s| s.as_str()) == Some("depth") {
            args.get(1).and_then(|s| s.parse().ok()).unwrap_or(1)
        } else { 1 };
        let roots = default_targets(m);
        for t in roots { print_target_depth(m, &t, 0, depth); }
    }
}

fn print_target_depth(m: &Manifest, t: &str, ind: usize, max: usize) {
    if let Some(&ei) = m.out_to_edge.get(t) {
        println!("{}{}: {}", "  ".repeat(ind), t, m.edges[ei].rule);
        if max == 0 || ind + 1 < max {
            for inp in m.edges[ei].all_ins() {
                print_target_depth(m, &inp, ind + 1, max);
            }
        }
    } else {
        println!("{}{}", "  ".repeat(ind), t);
    }
}

fn tool_query(m: &Manifest, t: &str) {
    println!("{}:", t);
    if let Some(&ei) = m.out_to_edge.get(t) {
        let e = &m.edges[ei];
        println!("  input: {}", e.rule);
        for x in &e.explicit_ins { println!("    {}", x); }
        for x in &e.implicit_ins { println!("    | {}", x); }
        for x in &e.order_only { println!("    || {}", x); }
    }
    println!("  outputs:");
    for e in &m.edges {
        if e.all_ins().iter().any(|i| i == t) {
            for o in e.all_outs() { println!("    {}", o); }
        }
    }
}

fn tool_graph(m: &Manifest, args: &[String]) -> Result<(), String> {
    let targets = if args.is_empty() { default_targets(m) } else { args.to_vec() };
    println!("digraph ninja {{");
    println!("rankdir=\"LR\"");
    println!("node [fontsize=10, shape=box, height=0.25]");
    println!("edge [fontsize=10]");
    let mut seen = HashSet::new();
    for t in targets { graph_node(m, &t, &mut seen)?; }
    println!("}}");
    Ok(())
}

fn graph_node(m: &Manifest, t: &str, seen: &mut HashSet<String>) -> Result<(), String> {
    if !seen.insert(t.to_string()) { return Ok(()); }
    let id = dot_id(t);
    println!("\"{}\" [label=\"{}\"]", id, t.replace('"', "\\\""));
    if let Some(&ei) = m.out_to_edge.get(t) {
        let e = &m.edges[ei];
        for inp in e.all_ins() {
            graph_node(m, &inp, seen)?;
            println!("\"{}\" -> \"{}\" [label=\" {}\"]", dot_id(&inp), id, e.rule);
        }
    }
    Ok(())
}

fn dot_id(s: &str) -> String { format!("n{}", simple_hash(s)) }

fn tool_compdb(m: &Manifest, args: &[String], by_targets: bool) -> Result<(), String> {
    let mut expand_rsp = false;
    let items: Vec<String> = args.iter().filter_map(|a| {
        if a == "-x" { expand_rsp = true; None } else { Some(a.clone()) }
    }).collect();
    if by_targets && items.is_empty() { return Err("compdb-targets expects targets".to_string()); }
    let mut edges = Vec::new();
    if by_targets {
        collect_edges(m, &items, &mut HashSet::new(), &mut edges)?;
    } else {
        for (i, e) in m.edges.iter().enumerate() {
            if items.is_empty() || items.contains(&e.rule) { edges.push(i); }
        }
    }
    let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    println!("[");
    let mut first = true;
    for ei in edges {
        let e = &m.edges[ei];
        if e.rule == "phony" || e.explicit_ins.is_empty() { continue; }
        if !first { println!(","); }
        first = false;
        let mut cmd = command_for(m, ei);
        if expand_rsp { cmd = expand_rspfiles(m, ei, &cmd); }
        print!("  {{\n    \"directory\": \"{}\",\n    \"command\": \"{}\",\n    \"file\": \"{}\",\n    \"output\": \"{}\"\n  }}",
            json_escape(&cwd.display().to_string()),
            json_escape(&cmd),
            json_escape(&e.explicit_ins[0]),
            json_escape(e.explicit_outs.first().map(|s| s.as_str()).unwrap_or("")));
    }
    println!("\n]");
    Ok(())
}

fn expand_rspfiles(m: &Manifest, ei: usize, cmd: &str) -> String {
    let rsp = eval_var(m, ei, "rspfile");
    if rsp.is_empty() { return cmd.to_string(); }
    let content = eval_var(m, ei, "rspfile_content");
    cmd.replace(&format!("@{}", rsp), &content)
}

fn tool_clean(m: &Manifest, args: &[String], verbose: bool, dry_run: bool) -> Result<i32, String> {
    let mut removed = 0;
    let mut targets: HashSet<String> = HashSet::new();
    let mut rules: HashSet<String> = HashSet::new();
    let mut by_rule = false;
    for a in args {
        if a == "-r" { by_rule = true; continue; }
        if a == "-g" { continue; }
        if by_rule { rules.insert(a.clone()); } else { targets.insert(a.clone()); }
    }
    let mut files = Vec::new();
    if !rules.is_empty() {
        for e in &m.edges { if rules.contains(&e.rule) { files.extend(e.all_outs()); } }
    } else if !targets.is_empty() {
        let ts: Vec<String> = targets.into_iter().collect();
        let mut edges = Vec::new();
        collect_edges(m, &ts, &mut HashSet::new(), &mut edges)?;
        for ei in edges { files.extend(m.edges[ei].all_outs()); }
    } else {
        for e in &m.edges { if e.vars.get("generator").map(|v| v != "0").unwrap_or(false) { continue; } files.extend(e.all_outs()); }
    }
    files.sort(); files.dedup();
    for f in files {
        if Path::new(&f).exists() {
            if verbose || dry_run { println!("Remove {}", f); }
            if !dry_run { let _ = fs::remove_file(&f); }
            removed += 1;
        }
    }
    println!("Cleaning... {} files.", removed);
    Ok(0)
}

fn default_targets(m: &Manifest) -> Vec<String> {
    if !m.defaults.is_empty() { return m.defaults.clone(); }
    let mut inputs = HashSet::new();
    for e in &m.edges { for i in e.all_ins() { inputs.insert(i); } }
    let mut roots = Vec::new();
    for e in &m.edges {
        for o in e.all_outs() {
            if !inputs.contains(&o) { roots.push(o); }
        }
    }
    roots
}

fn run_build(m: &Manifest, targets: Vec<String>, verbose: bool, quiet: bool, dry_run: bool, keep_going: usize) -> Result<i32, String> {
    let targets = if targets.is_empty() { default_targets(m) } else { resolve_caret_targets(m, targets) };
    for t in &targets {
        if !m.out_to_edge.contains_key(t) && !Path::new(t).exists() {
            return Err(format!("unknown target '{}'", t));
        }
    }
    let mut order = Vec::new();
    collect_edges(m, &targets, &mut HashSet::new(), &mut order)?;
    let log = read_log();
    let mut dirty_edges = Vec::new();
    for ei in order {
        if is_dirty(m, ei, &log)? { dirty_edges.push(ei); }
    }
    if dirty_edges.is_empty() {
        println!("ninja: no work to do.");
        return Ok(0);
    }
    let total = dirty_edges.iter().filter(|&&ei| m.edges[ei].rule != "phony").count();
    let mut finished = 0usize;
    let mut failures = 0usize;
    let mut newlog = log;
    for ei in dirty_edges {
        let e = &m.edges[ei];
        if e.rule == "phony" { continue; }
        finished += 1;
        let cmd = command_for(m, ei);
        if !quiet {
            let text = if verbose { cmd.clone() } else {
                let d = eval_var(m, ei, "description");
                if d.is_empty() { cmd.clone() } else { d }
            };
            println!("{}{}", status_prefix(finished, total), text);
        }
        if !dry_run {
            create_output_dirs(e);
            let rsp = eval_var(m, ei, "rspfile");
            if !rsp.is_empty() {
                if let Some(p) = Path::new(&rsp).parent() { let _ = fs::create_dir_all(p); }
                fs::write(&rsp, eval_var(m, ei, "rspfile_content")).map_err(|er| er.to_string())?;
            }
            let out = Command::new("sh").arg("-c").arg(&cmd).stdout(Stdio::piped()).stderr(Stdio::piped()).output()
                .map_err(|er| format!("failed to run command '{}': {}", cmd, er))?;
            if !out.stdout.is_empty() { io::stdout().write_all(&out.stdout).ok(); }
            if !out.stderr.is_empty() { io::stderr().write_all(&out.stderr).ok(); }
            if !rsp.is_empty() { let _ = fs::remove_file(&rsp); }
            if !out.status.success() {
                failures += 1;
                if keep_going == 1 || (keep_going != 0 && failures >= keep_going) {
                    return Ok(1);
                }
            } else {
                let depfile = eval_var(m, ei, "depfile");
                let parsed_deps = if depfile.is_empty() { Vec::new() } else { parse_depfile(Path::new(&depfile)) };
                for o in e.all_outs() {
                    newlog.insert(o.clone(), (mtime_secs_path(Path::new(e.explicit_outs.first().map(|s| s.as_str()).unwrap_or(""))), simple_hash(&cmd)));
                    if !parsed_deps.is_empty() {
                        write_deps_for(&o, &parsed_deps);
                    }
                }
                if eval_var(m, ei, "deps") == "gcc" && !depfile.is_empty() {
                    let _ = fs::remove_file(&depfile);
                }
            }
        }
    }
    if !dry_run { write_log(&newlog); }
    Ok(if failures == 0 { 0 } else { 1 })
}

fn resolve_caret_targets(m: &Manifest, targets: Vec<String>) -> Vec<String> {
    targets.into_iter().map(|t| {
        if let Some(src) = t.strip_suffix('^') {
            for e in &m.edges {
                if e.all_ins().iter().any(|i| i == src) {
                    return e.explicit_outs.first().cloned().unwrap_or_else(|| t.clone());
                }
            }
        }
        t
    }).collect()
}

fn collect_edges(m: &Manifest, targets: &[String], seen: &mut HashSet<usize>, order: &mut Vec<usize>) -> Result<(), String> {
    for t in targets {
        if let Some(&ei) = m.out_to_edge.get(t) {
            if seen.contains(&ei) { continue; }
            let inputs = m.edges[ei].all_ins();
            collect_edges(m, &inputs, seen, order)?;
            seen.insert(ei);
            order.push(ei);
        } else if !Path::new(t).exists() {
            return Err(format!("'{}', needed by '{}', missing and no known rule to make it", t, targets.first().unwrap_or(t)));
        }
    }
    Ok(())
}

fn collect_inputs(m: &Manifest, targets: &[String], seen: &mut HashSet<String>, out: &mut Vec<String>) -> Result<(), String> {
    for t in targets {
        if let Some(&ei) = m.out_to_edge.get(t) {
            for inp in m.edges[ei].all_ins() {
                if seen.insert(inp.clone()) {
                    if m.out_to_edge.contains_key(&inp) {
                        collect_inputs(m, &[inp], seen, out)?;
                    } else {
                        out.push(inp);
                    }
                }
            }
        }
    }
    Ok(())
}

fn is_dirty(m: &Manifest, ei: usize, log: &HashMap<String, (u64, u64)>) -> Result<bool, String> {
    let e = &m.edges[ei];
    if e.rule == "phony" {
        for i in e.all_ins() {
            if let Some(&dep) = m.out_to_edge.get(&i) {
                if is_dirty(m, dep, log)? { return Ok(true); }
            } else if !Path::new(&i).exists() {
                return Ok(true);
            }
        }
        return Ok(false);
    }
    for i in e.all_ins() {
        if !Path::new(&i).exists() && !m.out_to_edge.contains_key(&i) {
            return Err(format!("'{}', needed by '{}', missing and no known rule to make it", i, e.explicit_outs.first().unwrap_or(&i)));
        }
    }
    let cmd_hash = simple_hash(&command_for(m, ei));
    let mut oldest_out = u64::MAX;
    for o in e.all_outs() {
        let mt = mtime_secs_path(Path::new(&o));
        if mt == 0 { return Ok(true); }
        oldest_out = oldest_out.min(mt);
        if log.get(&o).map(|(_, h)| *h != cmd_hash).unwrap_or(true) {
            return Ok(true);
        }
    }
    for i in e.explicit_ins.iter().chain(e.implicit_ins.iter()) {
        if mtime_secs_path(Path::new(i)) > oldest_out { return Ok(true); }
    }
    let depfile = eval_var(m, ei, "depfile");
    let mut extra_deps = if depfile.is_empty() { Vec::new() } else { parse_depfile(Path::new(&depfile)) };
    for o in e.all_outs() {
        extra_deps.extend(read_deps_for(&o));
    }
    extra_deps.sort();
    extra_deps.dedup();
    for d in extra_deps {
        let mt = mtime_secs_path(Path::new(&d));
        if mt > oldest_out { return Ok(true); }
    }
    Ok(false)
}

fn command_for(m: &Manifest, ei: usize) -> String {
    eval_var(m, ei, "command")
}

fn eval_var(m: &Manifest, ei: usize, key: &str) -> String {
    let e = &m.edges[ei];
    let mut local = HashMap::new();
    local.insert("in".to_string(), quote_list(&e.explicit_ins));
    local.insert("in_newline".to_string(), e.explicit_ins.join("\n"));
    local.insert("out".to_string(), quote_list(&e.explicit_outs));
    for (k, v) in &e.vars { local.insert(k.clone(), v.clone()); }
    if let Some(rule) = m.rules.get(&e.rule) {
        for (k, v) in &rule.vars {
            if !local.contains_key(k) {
                local.insert(k.clone(), v.clone());
            }
        }
    }
    let raw = local.get(key).cloned().unwrap_or_default();
    let mut env = m.env.clone();
    for (k, v) in local.clone() {
        if k != key { env.set(k, v); }
    }
    expand_vars(&raw, &env, &local)
}

fn quote_list(xs: &[String]) -> String {
    xs.iter().map(|x| shell_quote(x)).collect::<Vec<_>>().join(" ")
}

fn shell_quote(s: &str) -> String {
    if s.is_empty() { return "''".to_string(); }
    if s.bytes().all(|b| b.is_ascii_alphanumeric() || b"-_./".contains(&b)) {
        s.to_string()
    } else {
        format!("'{}'", s.replace('\'', "'\\''"))
    }
}

fn status_prefix(done: usize, total: usize) -> String {
    let fmt = env::var("NINJA_STATUS").unwrap_or_else(|_| "[%f/%t] ".to_string());
    fmt.replace("%f", &done.to_string())
        .replace("%s", &done.to_string())
        .replace("%t", &total.to_string())
        .replace("%r", "1")
        .replace("%u", &total.saturating_sub(done).to_string())
        .replace("%p", &if total == 0 { "100".to_string() } else { (done * 100 / total).to_string() })
        .replace("%%", "%")
}

fn create_output_dirs(e: &Edge) {
    for o in e.all_outs() {
        if let Some(p) = Path::new(&o).parent() {
            if !p.as_os_str().is_empty() { let _ = fs::create_dir_all(p); }
        }
    }
}

fn mtime_secs_path(p: &Path) -> u64 {
    fs::metadata(p).and_then(|m| m.modified()).ok()
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok()).map(|d| d.as_secs()).unwrap_or(0)
}

fn read_log() -> HashMap<String, (u64, u64)> {
    let mut h = HashMap::new();
    if let Ok(s) = fs::read_to_string(".ninja_log") {
        for l in s.lines() {
            if l.starts_with("#") { continue; }
            let parts: Vec<_> = l.split('\t').collect();
            if parts.len() >= 3 {
                if let (Ok(mt), Ok(ch)) = (parts[1].parse(), parts[2].parse()) {
                    h.insert(parts[0].to_string(), (mt, ch));
                }
            }
        }
    }
    h
}

fn write_log(h: &HashMap<String, (u64, u64)>) {
    let mut s = String::from("# ninja log v5\n");
    let mut keys: Vec<_> = h.keys().collect();
    keys.sort();
    for k in keys {
        let (mt, ch) = h[k];
        s.push_str(&format!("{}\t{}\t{}\n", k, mt, ch));
    }
    let _ = fs::write(".ninja_log", s);
}

fn parse_depfile(path: &Path) -> Vec<String> {
    let s = match fs::read_to_string(path) {
        Ok(s) => s,
        Err(_) => return Vec::new(),
    };
    let s = s.replace("\\\n", " ");
    let Some(colon) = find_unescaped_colon(&s) else { return Vec::new(); };
    parse_dep_tokens(&s[colon + 1..])
}

fn parse_dep_tokens(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        match c {
            '\\' => {
                if let Some(n) = chars.next() {
                    cur.push(n);
                }
            }
            c if c.is_whitespace() => {
                if !cur.is_empty() {
                    out.push(cur.clone());
                    cur.clear();
                }
            }
            _ => cur.push(c),
        }
    }
    if !cur.is_empty() {
        out.push(cur);
    }
    out
}

fn deps_db_path() -> PathBuf {
    PathBuf::from(".ninja_deps_simple")
}

fn read_all_deps() -> HashMap<String, Vec<String>> {
    let mut h = HashMap::new();
    if let Ok(s) = fs::read_to_string(deps_db_path()) {
        for l in s.lines() {
            let mut parts = l.split('\t');
            if let Some(out) = parts.next() {
                let deps = parts.map(|p| p.to_string()).collect::<Vec<_>>();
                if !deps.is_empty() {
                    h.insert(out.to_string(), deps);
                }
            }
        }
    }
    h
}

fn read_deps_for(out: &str) -> Vec<String> {
    read_all_deps().remove(out).unwrap_or_default()
}

fn write_deps_for(out: &str, deps: &[String]) {
    let mut all = read_all_deps();
    all.insert(out.to_string(), deps.to_vec());
    let mut keys: Vec<_> = all.keys().cloned().collect();
    keys.sort();
    let mut s = String::new();
    for k in keys {
        s.push_str(&k);
        for d in &all[&k] {
            s.push('\t');
            s.push_str(d);
        }
        s.push('\n');
    }
    let _ = fs::write(deps_db_path(), s);
}

fn simple_hash(s: &str) -> u64 {
    let mut h = 1469598103934665603u64;
    for b in s.as_bytes() {
        h ^= *b as u64;
        h = h.wrapping_mul(1099511628211);
    }
    h
}

fn json_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n").replace('\t', "\\t")
}
