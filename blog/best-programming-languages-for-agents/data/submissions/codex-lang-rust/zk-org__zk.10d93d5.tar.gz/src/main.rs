use std::collections::{BTreeMap, BTreeSet, HashSet};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};
use std::process::{self, Command};
use std::time::{SystemTime, UNIX_EPOCH};

const DEFAULT_CONFIG: &str = r#"# zk configuration file
#
# Uncomment the properties you want to customize.

# NOTE SETTINGS
#
# Defines the default options used when generating new notes.
[note]

# Language used when writing notes.
# This is used to generate slugs or with date formats.
#language = "en"

# The default title used for new note, if no `--title` flag is provided.
#default-title = "Untitled"

# Template used to generate a note's filename, without extension.
#filename = "{{id}}"

# The file extension used for the notes.
#extension = "md"

# Template used to generate a note's content.
# If not an absolute path or "~/unix/path", it's relative to .zk/templates/
template = "default.md"

# MARKDOWN SETTINGS
[format.markdown]

# Format used to generate links between notes.
link-format = "wiki"

# Enable support for #hashtags.
hashtags = true
# Enable support for :colon:separated:tags:.
colon-tags = false
# Enable support for Bear's #multi-word tags#
multiword-tags = false

[tool]

[lsp]

[lsp.diagnostics]
dead-link = "error"

[lsp.completion]

[filter]
"#;

const DEFAULT_TEMPLATE: &str = "# {{title}}\n\n{{content}}\n";

#[derive(Default, Debug)]
struct Global {
    notebook_dir: Option<PathBuf>,
    working_dir: Option<PathBuf>,
    no_input: bool,
}

#[derive(Clone, Debug)]
struct Note {
    path: PathBuf,
    rel: String,
    title: String,
    body: String,
    tags: BTreeSet<String>,
    links: BTreeSet<String>,
    created: Option<SystemTime>,
    modified: Option<SystemTime>,
}

#[derive(Default)]
struct Query {
    paths: Vec<String>,
    exclude: Vec<String>,
    tags: Vec<String>,
    matches: Vec<String>,
    limit: Option<usize>,
    sort: Vec<String>,
    tagless: bool,
    orphan: bool,
    link_to: Vec<String>,
    linked_by: Vec<String>,
}

fn main() {
    let code = match run() {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("zk: error: {e}");
            1
        }
    };
    process::exit(code);
}

fn run() -> Result<(), String> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        print_main_help();
        if find_notebook(&env::current_dir().unwrap_or_else(|_| PathBuf::from("."))).is_none() {
            eprintln!("zk: error: failed to open notebook: no notebook found in {} or a parent directory", env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).display());
        }
        return Ok(());
    }

    if args.first().map(|s| s == "-h" || s == "--help").unwrap_or(false) {
        print_main_help();
        return Ok(());
    }

    let mut global = Global::default();
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if a == "--no-input" {
            global.no_input = true;
            args.remove(i);
        } else if a == "-W" || a == "--working-dir" {
            if i + 1 >= args.len() { return Err("expected value for --working-dir".into()); }
            global.working_dir = Some(PathBuf::from(args.remove(i + 1)));
            args.remove(i);
        } else if let Some(v) = a.strip_prefix("--working-dir=") {
            global.working_dir = Some(PathBuf::from(v));
            args.remove(i);
        } else if a == "--notebook-dir" {
            if i + 1 >= args.len() { return Err("expected value for --notebook-dir".into()); }
            global.notebook_dir = Some(PathBuf::from(args.remove(i + 1)));
            args.remove(i);
        } else if let Some(v) = a.strip_prefix("--notebook-dir=") {
            global.notebook_dir = Some(PathBuf::from(v));
            args.remove(i);
        } else {
            i += 1;
        }
    }

    let wd = global.working_dir.clone().unwrap_or_else(|| env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));
    let cmd = args.get(0).map(|s| s.as_str()).unwrap_or("");
    let rest = if args.len() > 1 { args[1..].to_vec() } else { Vec::new() };
    match cmd {
        "init" => cmd_init(rest, &global, &wd),
        "index" => cmd_index(rest, &global, &wd),
        "new" => cmd_new(rest, &global, &wd),
        "list" => cmd_list(rest, &global, &wd),
        "graph" => cmd_graph(rest, &global, &wd),
        "edit" => cmd_edit(rest, &global, &wd),
        "tag" => cmd_tag(rest, &global, &wd),
        other if other.starts_with('-') => Err(format!("unknown flag {other}")),
        other => Err(format!("unexpected argument {other}")),
    }
}

fn cmd_init(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_init_help();
        return Ok(());
    }
    let dir = args.iter().find(|a| !a.starts_with('-')).map(PathBuf::from).unwrap_or_else(|| wd.to_path_buf());
    let dir = absolutize(wd, &dir);
    let zk = dir.join(".zk");
    fs::create_dir_all(zk.join("templates")).map_err(|e| e.to_string())?;
    write_if_missing(&zk.join("config.toml"), DEFAULT_CONFIG)?;
    write_if_missing(&zk.join("templates/default.md"), DEFAULT_TEMPLATE)?;
    if !global.no_input {
        println!("Initialized notebook in {}", dir.display());
    }
    Ok(())
}

fn cmd_index(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_index_help();
        return Ok(());
    }
    let quiet = args.iter().any(|a| a == "-q" || a == "--quiet");
    let nb = notebook(global, wd)?;
    let notes = read_notes(&nb)?;
    if !quiet {
        println!("{} notes indexed", notes.len());
    }
    Ok(())
}

fn cmd_new(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_new_help();
        return Ok(());
    }
    let nb = notebook(global, wd)?;
    let mut title: Option<String> = None;
    let mut id: Option<String> = None;
    let mut template: Option<PathBuf> = None;
    let mut print_path = false;
    let mut dry = false;
    let mut interactive = false;
    let mut date: Option<String> = None;
    let mut extras: BTreeMap<String, String> = BTreeMap::new();
    let mut dir_arg: Option<String> = None;
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-t" | "--title" => { i += 1; title = args.get(i).cloned(); }
            "--id" => { i += 1; id = args.get(i).cloned(); }
            "--template" => { i += 1; template = args.get(i).map(PathBuf::from); }
            "--date" => { i += 1; date = args.get(i).cloned(); }
            "--extra" => { i += 1; parse_extras(args.get(i), &mut extras); }
            "-p" | "--print-path" => print_path = true,
            "-n" | "--dry-run" => dry = true,
            "-i" | "--interactive" => interactive = true,
            "-g" | "--group" => { i += 1; }
            s if s.starts_with("--title=") => title = Some(s[8..].to_string()),
            s if s.starts_with("--id=") => id = Some(s[5..].to_string()),
            s if s.starts_with("--template=") => template = Some(PathBuf::from(&s[11..])),
            s if s.starts_with("--date=") => date = Some(s[7..].to_string()),
            s if s.starts_with("--extra=") => parse_extras(Some(&s[8..].to_string()), &mut extras),
            s if s.starts_with('-') => {}
            s => if dir_arg.is_none() { dir_arg = Some(s.to_string()); },
        }
        i += 1;
    }
    let title = title.unwrap_or_else(|| "Untitled".to_string());
    let id = id.unwrap_or_else(|| gen_id());
    let sub = dir_arg.unwrap_or_default();
    let rel_dir = PathBuf::from(sub);
    let filename = format!("{}.md", id);
    let rel_path = rel_dir.join(filename);
    let path = nb.join(&rel_path);
    let mut content = String::new();
    if interactive {
        io::stdin().read_to_string(&mut content).map_err(|e| e.to_string())?;
    }
    let tmpl_path = template.unwrap_or_else(|| nb.join(".zk/templates/default.md"));
    let tmpl = fs::read_to_string(&tmpl_path).unwrap_or_else(|_| DEFAULT_TEMPLATE.to_string());
    let mut rendered = tmpl.replace("{{title}}", &title).replace("{{content}}", &content).replace("{{id}}", &id);
    rendered = rendered.replace("{{date}}", date.as_deref().unwrap_or(""));
    for (k, v) in extras {
        rendered = rendered.replace(&format!("{{{{extra.{k}}}}}"), &v);
    }
    if dry {
        eprintln!("{}", rel_path.to_string_lossy());
        print!("{rendered}");
        return Ok(());
    }
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    fs::write(&path, rendered).map_err(|e| e.to_string())?;
    if print_path {
        println!("{}", rel_path.to_string_lossy());
    } else if let Ok(editor) = env::var("EDITOR") {
        let _ = Command::new(editor).arg(&path).status();
    }
    Ok(())
}

fn cmd_list(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_list_help();
        return Ok(());
    }
    let nb = notebook(global, wd)?;
    let (query, opts) = parse_query_and_format(&args);
    let notes = apply_query(read_notes(&nb)?, &query);
    let mut out = String::new();
    out.push_str(&opts.header);
    if opts.format == "json" {
        out.push('[');
        out.push_str(&notes.iter().map(note_json).collect::<Vec<_>>().join(","));
        out.push(']');
    } else {
        let rendered: Vec<String> = notes.iter().map(|n| format_note(n, &opts.format)).collect();
        out.push_str(&rendered.join(&opts.delimiter));
        if !rendered.is_empty() && !opts.footer.is_empty() && opts.footer != "\n" {
            out.push_str(&opts.delimiter);
        }
    }
    out.push_str(&opts.footer);
    print!("{out}");
    if !opts.quiet && opts.format != "json" && opts.format != "jsonl" {
        eprintln!("{} notes found", notes.len());
    }
    Ok(())
}

fn cmd_graph(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_graph_help();
        return Ok(());
    }
    let nb = notebook(global, wd)?;
    let (query, opts) = parse_query_and_format(&args);
    let notes = apply_query(read_notes(&nb)?, &query);
    let titles: HashSet<String> = notes.iter().map(|n| n.title.clone()).collect();
    let mut s = String::new();
    s.push_str("{\"nodes\":[");
    for (i, n) in notes.iter().enumerate() {
        if i > 0 { s.push(','); }
        s.push_str(&format!("{{\"path\":\"{}\",\"title\":\"{}\"}}", json(&n.rel), json(&n.title)));
    }
    s.push_str("],\"links\":[");
    let mut first = true;
    for n in &notes {
        for l in &n.links {
            if titles.contains(l) {
                if !first { s.push(','); }
                first = false;
                s.push_str(&format!("{{\"source\":\"{}\",\"target\":\"{}\"}}", json(&n.title), json(l)));
            }
        }
    }
    s.push_str("]}");
    println!("{s}");
    if !opts.quiet {
        eprintln!("{} notes found", notes.len());
    }
    Ok(())
}

fn cmd_edit(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_edit_help();
        return Ok(());
    }
    let nb = notebook(global, wd)?;
    let (query, _) = parse_query_and_format(&args);
    let notes = apply_query(read_notes(&nb)?, &query);
    if notes.is_empty() {
        return Err("no notes found".into());
    }
    if let Ok(editor) = env::var("EDITOR") {
        let mut cmd = Command::new(editor);
        for n in notes { cmd.arg(n.path); }
        let _ = cmd.status();
    } else {
        for n in notes {
            println!("{}", n.rel);
        }
    }
    Ok(())
}

fn cmd_tag(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") && args.first().map(|s| s.as_str()) != Some("list") {
        print_tag_help();
        return Ok(());
    }
    match args.first().map(|s| s.as_str()) {
        Some("list") => cmd_tag_list(args[1..].to_vec(), global, wd),
        Some(other) => Err(format!("unexpected argument {other}")),
        None => {
            print_tag_help();
            Ok(())
        }
    }
}

fn cmd_tag_list(args: Vec<String>, global: &Global, wd: &Path) -> Result<(), String> {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print_tag_list_help();
        return Ok(());
    }
    let nb = notebook(global, wd)?;
    let (_, opts) = parse_query_and_format(&args);
    let mut counts: BTreeMap<String, usize> = BTreeMap::new();
    for n in read_notes(&nb)? {
        for t in n.tags {
            *counts.entry(t).or_default() += 1;
        }
    }
    let vals: Vec<String> = counts.iter().map(|(t, c)| match opts.format.as_str() {
        "json" | "jsonl" => format!("{{\"name\":\"{}\",\"note-count\":{}}}", json(t), c),
        "full" => format!("{t} {c}"),
        _ => t.clone(),
    }).collect();
    if opts.format == "json" {
        println!("[{}]", vals.join(","));
    } else {
        print!("{}{}{}", opts.header, vals.join(&opts.delimiter), opts.footer);
    }
    if !opts.quiet && opts.format != "json" && opts.format != "jsonl" {
        eprintln!("{} tags found", counts.len());
    }
    Ok(())
}

#[derive(Default)]
struct FormatOpts {
    format: String,
    header: String,
    footer: String,
    delimiter: String,
    quiet: bool,
}

fn parse_query_and_format(args: &[String]) -> (Query, FormatOpts) {
    let mut q = Query::default();
    let mut o = FormatOpts { format: "oneline".into(), footer: "\n".into(), delimiter: "\n".into(), ..Default::default() };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-f" | "--format" => { i += 1; if let Some(v) = args.get(i) { o.format = v.clone(); } }
            "--header" => { i += 1; if let Some(v) = args.get(i) { o.header = unescape(v); } }
            "--footer" => { i += 1; if let Some(v) = args.get(i) { o.footer = unescape(v); } }
            "-d" | "--delimiter" => { i += 1; if let Some(v) = args.get(i) { o.delimiter = unescape(v); } }
            "-0" | "--delimiter0" => o.delimiter = "\0".into(),
            "-q" | "--quiet" => o.quiet = true,
            "-P" | "--no-pager" | "-i" | "--interactive" | "-r" | "--recursive" | "--force" => {}
            "-n" | "--limit" => { i += 1; q.limit = args.get(i).and_then(|v| v.parse().ok()); }
            "-m" | "--match" => { i += 1; split_push(args.get(i), &mut q.matches); }
            "-x" | "--exclude" => { i += 1; split_push(args.get(i), &mut q.exclude); }
            "-t" | "--tag" => { i += 1; split_push(args.get(i), &mut q.tags); }
            "-s" | "--sort" => { i += 1; split_push(args.get(i), &mut q.sort); }
            "-l" | "--link-to" => { i += 1; split_push(args.get(i), &mut q.link_to); }
            "-L" | "--linked-by" => { i += 1; split_push(args.get(i), &mut q.linked_by); }
            "--tagless" => q.tagless = true,
            "--orphan" => q.orphan = true,
            s if s.starts_with("--format=") => o.format = s[9..].into(),
            s if s.starts_with("--header=") => o.header = unescape(&s[9..]),
            s if s.starts_with("--footer=") => o.footer = unescape(&s[9..]),
            s if s.starts_with("--delimiter=") => o.delimiter = unescape(&s[12..]),
            s if s.starts_with("--limit=") => q.limit = s[8..].parse().ok(),
            s if s.starts_with("--match=") => split_push(Some(&s[8..].to_string()), &mut q.matches),
            s if s.starts_with("--exclude=") => split_push(Some(&s[10..].to_string()), &mut q.exclude),
            s if s.starts_with("--tag=") => split_push(Some(&s[6..].to_string()), &mut q.tags),
            s if s.starts_with("--sort=") => split_push(Some(&s[7..].to_string()), &mut q.sort),
            s if s.starts_with("--") => {}
            s if s.starts_with('-') => {}
            s => q.paths.push(s.to_string()),
        }
        i += 1;
    }
    (q, o)
}

fn apply_query(mut notes: Vec<Note>, q: &Query) -> Vec<Note> {
    if !q.paths.is_empty() {
        notes.retain(|n| q.paths.iter().any(|p| n.rel.starts_with(p.trim_start_matches("./"))));
    }
    if !q.exclude.is_empty() {
        notes.retain(|n| !q.exclude.iter().any(|p| n.rel.starts_with(p.trim_start_matches("./"))));
    }
    if !q.tags.is_empty() {
        notes.retain(|n| q.tags.iter().all(|t| n.tags.contains(t.trim_start_matches('#'))));
    }
    if q.tagless {
        notes.retain(|n| n.tags.is_empty());
    }
    if !q.matches.is_empty() {
        notes.retain(|n| q.matches.iter().all(|m| n.title.to_lowercase().contains(&m.to_lowercase()) || n.body.to_lowercase().contains(&m.to_lowercase())));
    }
    if !q.link_to.is_empty() {
        let targets: Vec<String> = q.link_to.iter().map(|p| titleish(p)).collect();
        notes.retain(|n| targets.iter().any(|t| n.links.contains(t)));
    }
    if !q.sort.is_empty() {
        for s in q.sort.iter().rev() {
            match s.as_str() {
                "title" => notes.sort_by(|a, b| a.title.cmp(&b.title)),
                "title-" => notes.sort_by(|a, b| b.title.cmp(&a.title)),
                "path-" => notes.sort_by(|a, b| b.rel.cmp(&a.rel)),
                "created" => notes.sort_by_key(|n| n.created),
                "created-" => notes.sort_by_key(|n| std::cmp::Reverse(n.created)),
                "modified" => notes.sort_by_key(|n| n.modified),
                "modified-" => notes.sort_by_key(|n| std::cmp::Reverse(n.modified)),
                _ => notes.sort_by(|a, b| a.rel.cmp(&b.rel)),
            }
        }
    } else {
        notes.sort_by(|a, b| a.rel.cmp(&b.rel));
    }
    if let Some(l) = q.limit {
        notes.truncate(l);
    }
    notes
}

fn format_note(n: &Note, fmt: &str) -> String {
    match fmt {
        "short" => n.title.clone(),
        "medium" => format!("{}\t{}", n.rel, n.title),
        "long" | "full" => format!("{}\n  title: {}\n  tags: {}", n.rel, n.title, n.tags.iter().cloned().collect::<Vec<_>>().join(", ")),
        "json" => note_json(n),
        "jsonl" => note_json(n),
        f if f.contains("{{") => f.replace("{{path}}", &n.rel).replace("{{title}}", &n.title).replace("{{filename}}", Path::new(&n.rel).file_name().and_then(|s| s.to_str()).unwrap_or("")),
        _ => format!("{} {}", n.rel, n.title),
    }
}

fn note_json(n: &Note) -> String {
    let tags = n.tags.iter().map(|t| format!("\"{}\"", json(t))).collect::<Vec<_>>().join(",");
    format!("{{\"path\":\"{}\",\"title\":\"{}\",\"tags\":[{}]}}", json(&n.rel), json(&n.title), tags)
}

fn read_notes(nb: &Path) -> Result<Vec<Note>, String> {
    let mut files = Vec::new();
    collect_md(nb, nb, &mut files)?;
    let mut notes = Vec::new();
    for path in files {
        let body = fs::read_to_string(&path).unwrap_or_default();
        let rel = path.strip_prefix(nb).unwrap_or(&path).to_string_lossy().replace('\\', "/");
        let title = extract_title(&body).unwrap_or_else(|| titleish(&rel));
        let tags = extract_tags(&body);
        let links = extract_links(&body);
        let meta = fs::metadata(&path).ok();
        notes.push(Note {
            path, rel, title, body, tags, links,
            created: meta.as_ref().and_then(|m| m.created().ok()),
            modified: meta.as_ref().and_then(|m| m.modified().ok()),
        });
    }
    Ok(notes)
}

fn collect_md(root: &Path, dir: &Path, out: &mut Vec<PathBuf>) -> Result<(), String> {
    for ent in fs::read_dir(dir).map_err(|e| e.to_string())? {
        let ent = ent.map_err(|e| e.to_string())?;
        let path = ent.path();
        let rel = path.strip_prefix(root).unwrap_or(&path);
        if rel.components().next().map(|c| c.as_os_str() == ".zk").unwrap_or(false) {
            continue;
        }
        if path.is_dir() {
            collect_md(root, &path, out)?;
        } else if path.extension().and_then(|s| s.to_str()).map(|s| s.eq_ignore_ascii_case("md")).unwrap_or(false) {
            out.push(path);
        }
    }
    Ok(())
}

fn extract_title(body: &str) -> Option<String> {
    if body.starts_with("---\n") {
        if let Some(end) = body[4..].find("\n---") {
            for line in body[4..4 + end].lines() {
                if let Some(v) = line.trim().strip_prefix("title:") {
                    return Some(v.trim().trim_matches('"').trim_matches('\'').to_string());
                }
            }
        }
    }
    for line in body.lines() {
        let t = line.trim();
        if let Some(v) = t.strip_prefix("# ") {
            return Some(v.trim().to_string());
        }
    }
    None
}

fn extract_tags(body: &str) -> BTreeSet<String> {
    let mut set = BTreeSet::new();
    if body.starts_with("---\n") {
        if let Some(end) = body[4..].find("\n---") {
            for line in body[4..4 + end].lines() {
                let t = line.trim();
                if let Some(v) = t.strip_prefix("tags:") {
                    let v = v.trim().trim_matches(['[', ']']);
                    for p in v.split([',', ' ']) {
                        let tag = p.trim().trim_matches('"').trim_matches('\'').trim_start_matches('#');
                        if !tag.is_empty() { set.insert(tag.to_string()); }
                    }
                }
            }
        }
    }
    let bytes = body.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'#' && (i == 0 || !is_word(bytes[i - 1] as char)) {
            let start = i + 1;
            let mut j = start;
            while j < bytes.len() {
                let c = bytes[j] as char;
                if c.is_alphanumeric() || c == '-' || c == '_' || c == '/' { j += 1; } else { break; }
            }
            if j > start {
                set.insert(body[start..j].to_string());
            }
            i = j;
        } else {
            i += 1;
        }
    }
    set
}

fn extract_links(body: &str) -> BTreeSet<String> {
    let mut set = BTreeSet::new();
    let mut rest = body;
    while let Some(i) = rest.find("[[") {
        rest = &rest[i + 2..];
        if let Some(j) = rest.find("]]") {
            let target = rest[..j].split('|').next().unwrap_or("").trim();
            if !target.is_empty() { set.insert(titleish(target)); }
            rest = &rest[j + 2..];
        } else { break; }
    }
    let mut r = body;
    while let Some(i) = r.find("](") {
        r = &r[i + 2..];
        if let Some(j) = r.find(')') {
            let target = r[..j].trim();
            if target.ends_with(".md") { set.insert(titleish(target)); }
            r = &r[j + 1..];
        } else { break; }
    }
    set
}

fn notebook(global: &Global, wd: &Path) -> Result<PathBuf, String> {
    if let Some(d) = &global.notebook_dir {
        let p = absolutize(wd, d);
        if p.join(".zk").exists() || p.exists() { return Ok(p); }
    }
    find_notebook(wd).ok_or_else(|| format!("failed to open notebook: no notebook found in {} or a parent directory", wd.display()))
}

fn find_notebook(start: &Path) -> Option<PathBuf> {
    let mut p = start.to_path_buf();
    loop {
        if p.join(".zk").is_dir() { return Some(p); }
        if !p.pop() { break; }
    }
    None
}

fn absolutize(wd: &Path, p: &Path) -> PathBuf {
    if p.is_absolute() { p.to_path_buf() } else { wd.join(p) }
}

fn write_if_missing(path: &Path, content: &str) -> Result<(), String> {
    if !path.exists() {
        fs::write(path, content).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn gen_id() -> String {
    let mut n = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_nanos();
    let chars = b"abcdefghijklmnopqrstuvwxyz0123456789";
    let mut s = String::new();
    for _ in 0..4 {
        s.push(chars[(n as usize) % chars.len()] as char);
        n /= chars.len() as u128;
    }
    s
}

fn split_push(v: Option<&String>, out: &mut Vec<String>) {
    if let Some(v) = v {
        for p in v.split(',') {
            let p = p.trim();
            if !p.is_empty() { out.push(p.trim_start_matches('#').to_string()); }
        }
    }
}

fn parse_extras(v: Option<&String>, out: &mut BTreeMap<String, String>) {
    if let Some(v) = v {
        for kv in v.split(',') {
            if let Some((k, val)) = kv.split_once('=') {
                out.insert(k.to_string(), val.to_string());
            }
        }
    }
}

fn unescape(s: &str) -> String {
    s.replace("\\n", "\n").replace("\\t", "\t").replace("\\0", "\0")
}

fn titleish(s: &str) -> String {
    let mut p = s.trim().trim_end_matches(".md").rsplit('/').next().unwrap_or(s).to_string();
    p = p.replace(['-', '_'], " ");
    let mut chars = p.chars();
    match chars.next() {
        Some(c) => c.to_uppercase().collect::<String>() + chars.as_str(),
        None => p,
    }
}

fn is_word(c: char) -> bool {
    c.is_alphanumeric() || c == '_' || c == '-'
}

fn json(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n").replace('\r', "\\r").replace('\t', "\\t")
}

fn print_main_help() {
    println!(r#"Usage: zk <command>

Commands:

NOTEBOOK
  A notebook is a directory containing a collection of notes

  init     Create a new notebook in the given directory.
  index    Index the notes to be searchable.

NOTES
  Edit or browse your notes

  new      Create a new note in the given notebook directory.
  list     List notes matching the given criteria.
  graph    Produce a graph of the notes matching the given criteria.
  edit     Edit notes matching the given criteria.
  tag      Manage the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Run "zk <command> --help" for more information on a command."#);
}

fn print_init_help() { println!(r#"Usage: zk init [<directory>]

Create a new notebook in the given directory.

Arguments:
  [<directory>]    Directory containing the notebook.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation."#); }

fn print_index_help() { println!(r#"Usage: zk index

Index the notes to be searchable.

You usually do not need to run `zk index` manually, as notes are indexed
automatically when needed.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Force indexing all the notes.
  -v, --verbose              Print detailed information about the indexing
                             process.
  -q, --quiet                Do not print statistics nor progress."#); }

fn print_new_help() { println!(r#"Usage: zk new [<directory>]

Create a new note in the given notebook directory.

Arguments:
  [<directory>]    Directory in which to create the note.

Flags:
  -h, --help                   Show context-sensitive help.
      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually
                               the notebook where commands are run.
  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the
                               current working directory.
      --no-input               Never prompt or ask for confirmation.

  -i, --interactive            Read contents from standard input.
  -t, --title=TITLE            Title of the new note.
      --date=DATE              Set the current date.
  -g, --group=NAME             Name of the config group this note belongs to.
      --extra=KEY=VALUE,...    Extra variables passed to the templates.
      --template=PATH          Custom template used to render the note.
  -p, --print-path             Print the path of the created note instead of
                               editing it.
  -n, --dry-run                Don't actually create the note. Instead, prints
                               its content on stdout and the generated path on
                               stderr.
      --id=ID                  Skip id generation and use provided value."#); }

fn print_list_help() { println!(r#"Usage: zk list [<path> ...]

List notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: oneline, short, medium,
                           long, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\n"     Print notes delimited by the given separator.
  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This
                           is useful when used in conjunction with `xargs -0`.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of notes found.

Filtering
  -i, --interactive                Select notes interactively with fzf.
  -n, --limit=COUNT                Limit the number of notes found.
  -m, --match=QUERY,...            Terms to search for in the notes.
  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.
  -x, --exclude=PATH,...           Ignore notes matching the given path,
                                   including its descendants.
  -t, --tag=TAG,...                Find notes tagged with the given tags.
      --tagless                    Find notes which have no tags.

Sorting
  -s, --sort=TERM,...    Order the notes by the given criterion."#); }

fn print_graph_help() { println!(r#"Usage: zk graph --format=STRING [<path> ...]

Produce a graph of the notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=STRING    Format of the graph among: json.
  -q, --quiet            Do not print the total number of notes found."#); }

fn print_edit_help() { println!(r#"Usage: zk edit [<path> ...]

Edit notes matching the given criteria.

Arguments:
  [<path> ...]    Find notes matching the given path, including its descendants.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

  -f, --force                Do not confirm before editing many notes at the
                             same time."#); }

fn print_tag_help() { println!(r#"Usage: zk tag <command>

Manage the note tags.

Commands:
  tag list    List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation."#); }

fn print_tag_list_help() { println!(r#"Usage: zk tag list

List all the note tags.

Flags:
  -h, --help                 Show context-sensitive help.
      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually
                             the notebook where commands are run.
  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the
                             current working directory.
      --no-input             Never prompt or ask for confirmation.

Formatting
  -f, --format=TEMPLATE    Pretty print the list using a custom template or one
                           of the predefined formats: name, full, json, jsonl.
      --header=STRING      Arbitrary text printed at the start of the list.
      --footer="\n"       Arbitrary text printed at the end of the list.
  -d, --delimiter="\n"     Print tags delimited by the given separator.
  -0, --delimiter0         Print tags delimited by ASCII NUL characters.
  -P, --no-pager           Do not pipe output into a pager.
  -q, --quiet              Do not print the total number of tags found.

Sorting
  -s, --sort=TERM,...    Order the tags by the given criterion."#); }
