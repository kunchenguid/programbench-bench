use std::env;
use std::ffi::OsStr;
use std::fs::{self, File, OpenOptions};
use std::io::{self, Read, Write};
use std::os::fd::AsRawFd;
use std::path::{Path, PathBuf};

const VERSION: &str = "v1.13.0";
const HELP: &str = r#"
  walk v1.13.0

  Usage: walk [path]

    arrows, hjkl  Move cursor
    enter         Enter directory
    backspace     Exit directory
    space         Toggle preview
    esc, q        Exit with cd
    ctrl+c        Exit without cd
    /             Fuzzy search
    d, delete     Delete file or dir
    y             Copy to clipboard
    .             Hide hidden files
    ?             Show help

  Flags:

    --icons        display icons
    --dir-only     show dirs only
    --hide-hidden  hide hidden files
    --preview      display preview
    --with-border  preview with border
    --fuzzy        fuzzy mode
"#;

#[derive(Clone, Debug)]
struct Config {
    icons: bool,
    dir_only: bool,
    hide_hidden: bool,
    preview: bool,
    with_border: bool,
    fuzzy: bool,
    path: PathBuf,
}

#[derive(Clone, Debug)]
struct Entry {
    name: String,
    path: PathBuf,
    is_dir: bool,
}

struct RawMode {
    fd: i32,
    original: libc::termios,
}

impl RawMode {
    fn new(file: &File) -> io::Result<Self> {
        let fd = file.as_raw_fd();
        let mut original = unsafe { std::mem::zeroed::<libc::termios>() };
        if unsafe { libc::tcgetattr(fd, &mut original) } != 0 {
            return Err(io::Error::last_os_error());
        }
        let mut raw = original;
        raw.c_iflag &= !(libc::BRKINT
            | libc::ICRNL
            | libc::INPCK
            | libc::ISTRIP
            | libc::IXON);
        raw.c_oflag &= !libc::OPOST;
        raw.c_cflag |= libc::CS8;
        raw.c_lflag &= !(libc::ECHO | libc::ICANON | libc::IEXTEN | libc::ISIG);
        raw.c_cc[libc::VMIN] = 1;
        raw.c_cc[libc::VTIME] = 0;
        if unsafe { libc::tcsetattr(fd, libc::TCSAFLUSH, &raw) } != 0 {
            return Err(io::Error::last_os_error());
        }
        Ok(Self { fd, original })
    }
}

impl Drop for RawMode {
    fn drop(&mut self) {
        unsafe {
            libc::tcsetattr(self.fd, libc::TCSAFLUSH, &self.original);
        }
    }
}

fn main() {
    let cfg = match parse_args() {
        Action::Help => {
            eprint!("{HELP}");
            std::process::exit(1);
        }
        Action::Version => {
            println!("{VERSION}");
            return;
        }
        Action::Run(cfg) => cfg,
    };

    if let Err(err) = run(cfg) {
        if err.kind() == io::ErrorKind::NotFound
            || err.raw_os_error() == Some(libc::ENXIO)
            || err.to_string().contains("No such device or address")
        {
            print_go_tty_panic();
            std::process::exit(2);
        }
        eprintln!("{err}");
        std::process::exit(1);
    }
}

enum Action {
    Help,
    Version,
    Run(Config),
}

fn parse_args() -> Action {
    let mut cfg = Config {
        icons: false,
        dir_only: false,
        hide_hidden: false,
        preview: false,
        with_border: false,
        fuzzy: false,
        path: PathBuf::from("."),
    };

    let mut args = env::args_os().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.to_string_lossy().as_ref() {
            "--help" | "-h" => return Action::Help,
            "--version" | "-v" => return Action::Version,
            "--icons" => cfg.icons = true,
            "--dir-only" => cfg.dir_only = true,
            "--hide-hidden" => cfg.hide_hidden = true,
            "--preview" => cfg.preview = true,
            "--with-border" => cfg.with_border = true,
            "--fuzzy" => cfg.fuzzy = true,
            _ => cfg.path = PathBuf::from(arg),
        }
    }

    Action::Run(cfg)
}

fn run(mut cfg: Config) -> io::Result<()> {
    // Match the Go program's user-visible failure when no controlling tty exists.
    let mut tty = OpenOptions::new().read(true).write(true).open("/dev/tty")?;
    write!(tty, "\x1b]11;?\x1b\\\x1b[6n")?;
    tty.flush()?;
    let _raw = RawMode::new(&tty)?;
    write!(tty, "\x1b[?25l\x1b[?2004h")?;

    if cfg.path.is_file() {
        if let Some(parent) = cfg.path.parent() {
            cfg.path = parent.to_path_buf();
        }
    }
    if let Ok(canon) = fs::canonicalize(&cfg.path) {
        cfg.path = canon;
    }

    let mut selected = 0usize;
    let mut show_help = false;
    let mut entries = read_entries(&cfg.path, &cfg)?;
    render(&mut tty, &cfg, &entries, selected, show_help)?;

    let mut buf = [0u8; 8];
    loop {
        let n = tty.read(&mut buf)?;
        if n == 0 {
            continue;
        }
        match key(&buf[..n]) {
            Key::QuitWithCd => {
                cleanup(&mut tty, entries.len())?;
                println!("{}", cfg.path.display());
                return Ok(());
            }
            Key::QuitWithoutCd => {
                cleanup(&mut tty, entries.len())?;
                return Ok(());
            }
            Key::Down => {
                if selected + 1 < entries.len() {
                    selected += 1;
                }
            }
            Key::Up => {
                selected = selected.saturating_sub(1);
            }
            Key::Home => selected = 0,
            Key::End => {
                if !entries.is_empty() {
                    selected = entries.len() - 1;
                }
            }
            Key::Enter => {
                if let Some(ent) = entries.get(selected) {
                    if ent.is_dir {
                        cfg.path = ent.path.clone();
                        selected = 0;
                        entries = read_entries(&cfg.path, &cfg)?;
                    }
                }
            }
            Key::Back => {
                if let Some(parent) = cfg.path.parent() {
                    cfg.path = parent.to_path_buf();
                    selected = 0;
                    entries = read_entries(&cfg.path, &cfg)?;
                }
            }
            Key::ToggleHidden => {
                cfg.hide_hidden = !cfg.hide_hidden;
                selected = 0;
                entries = read_entries(&cfg.path, &cfg)?;
            }
            Key::TogglePreview => cfg.preview = !cfg.preview,
            Key::Help => show_help = !show_help,
            Key::Search => {
                fuzzy_search(&mut tty, &mut cfg, &mut entries, &mut selected)?;
            }
            Key::Other => {}
        }
        render(&mut tty, &cfg, &entries, selected, show_help)?;
    }
}

fn read_entries(dir: &Path, cfg: &Config) -> io::Result<Vec<Entry>> {
    let mut entries = Vec::new();
    for item in fs::read_dir(dir)? {
        let item = item?;
        let name = item.file_name().to_string_lossy().to_string();
        if cfg.hide_hidden && name.starts_with('.') {
            continue;
        }
        let ty = item.file_type()?;
        if cfg.dir_only && !ty.is_dir() {
            continue;
        }
        entries.push(Entry {
            name,
            path: item.path(),
            is_dir: ty.is_dir(),
        });
    }
    entries.sort_by(|a, b| a.name.cmp(&b.name));
    Ok(entries)
}

fn render(tty: &mut File, cfg: &Config, entries: &[Entry], selected: usize, help: bool) -> io::Result<()> {
    write!(tty, "\r{}\x1b[K\r\n", cfg.path.display())?;
    if help {
        for line in HELP.lines().skip(1).take(22) {
            write!(tty, "{line}\x1b[K\r\n")?;
        }
        write!(tty, "\x1b[{}A", 23)?;
        tty.flush()?;
        return Ok(());
    }

    let max = if cfg.preview { 18 } else { 40 };
    for (idx, ent) in entries.iter().take(max).enumerate() {
        let mark = if idx == selected { "" } else { "" };
        let icon = if cfg.icons {
            if ent.is_dir { "  " } else { "  " }
        } else {
            ""
        };
        let slash = if ent.is_dir { "/" } else { "" };
        write!(tty, "{mark}{icon}{}{slash}\x1b[K\r\n", ent.name)?;
    }
    if cfg.preview {
        render_preview(tty, cfg, entries.get(selected))?;
    }
    let lines = 1 + entries.len().min(max) + if cfg.preview { 8 } else { 0 };
    write!(tty, "\x1b[{}A", lines)?;
    tty.flush()
}

fn render_preview(tty: &mut File, cfg: &Config, ent: Option<&Entry>) -> io::Result<()> {
    if cfg.with_border {
        write!(tty, "──────── preview ────────\x1b[K\r\n")?;
    }
    if let Some(ent) = ent {
        if ent.is_dir {
            write!(tty, "{}\x1b[K\r\n", ent.path.display())?;
            let mut count = 0;
            if let Ok(rd) = fs::read_dir(&ent.path) {
                for item in rd.flatten().take(6) {
                    write!(tty, "  {}\x1b[K\r\n", item.file_name().to_string_lossy())?;
                    count += 1;
                }
            }
            for _ in count..6 {
                write!(tty, "\x1b[K\r\n")?;
            }
        } else if let Ok(mut file) = File::open(&ent.path) {
            let mut s = String::new();
            let _ = file.read_to_string(&mut s);
            for line in s.lines().take(7) {
                write!(tty, "{}\x1b[K\r\n", truncate(line, 78))?;
            }
        } else {
            write!(tty, "{}\x1b[K\r\n", ent.path.display())?;
        }
    }
    Ok(())
}

fn truncate(s: &str, n: usize) -> String {
    s.chars().take(n).collect()
}

fn fuzzy_search(
    tty: &mut File,
    cfg: &mut Config,
    entries: &mut Vec<Entry>,
    selected: &mut usize,
) -> io::Result<()> {
    let all = read_entries(&cfg.path, cfg)?;
    let mut query = String::new();
    loop {
        write!(tty, "\r/{}\x1b[K", query)?;
        tty.flush()?;
        let mut b = [0u8; 1];
        tty.read_exact(&mut b)?;
        match b[0] {
            b'\r' | b'\n' | 27 => break,
            3 => {
                cleanup(tty, entries.len())?;
                std::process::exit(0);
            }
            8 | 127 => {
                query.pop();
            }
            c if !c.is_ascii_control() => query.push(c as char),
            _ => {}
        }
        *entries = all
            .iter()
            .filter(|e| fuzzy_match(&e.name, &query))
            .cloned()
            .collect();
        *selected = 0;
    }
    Ok(())
}

fn fuzzy_match(name: &str, query: &str) -> bool {
    if query.is_empty() {
        return true;
    }
    let mut chars = query.chars().map(|c| c.to_ascii_lowercase());
    let mut want = match chars.next() {
        Some(c) => c,
        None => return true,
    };
    for c in name.chars().map(|c| c.to_ascii_lowercase()) {
        if c == want {
            match chars.next() {
                Some(next) => want = next,
                None => return true,
            }
        }
    }
    false
}

fn cleanup(tty: &mut File, rows: usize) -> io::Result<()> {
    let clear_rows = rows.min(40) + 2;
    write!(
        tty,
        "\x1b[{}A\r\x1b[2K\x1b[?2004l\x1b[?25h\x1b[?1002l\x1b[?1003l\x1b[?1006l",
        clear_rows
    )?;
    tty.flush()
}

#[derive(Copy, Clone, Eq, PartialEq)]
enum Key {
    Up,
    Down,
    Home,
    End,
    Enter,
    Back,
    QuitWithCd,
    QuitWithoutCd,
    ToggleHidden,
    TogglePreview,
    Help,
    Search,
    Other,
}

fn key(bytes: &[u8]) -> Key {
    match bytes {
        [3] => Key::QuitWithoutCd,
        [27] | [b'q'] => Key::QuitWithCd,
        [b'j'] | [27, 91, 66] => Key::Down,
        [b'k'] | [27, 91, 65] => Key::Up,
        [b'h'] | [127] | [8] => Key::Back,
        [b'l'] | [b'\r'] | [b'\n'] => Key::Enter,
        [b' '] => Key::TogglePreview,
        [b'.'] => Key::ToggleHidden,
        [b'?'] => Key::Help,
        [b'/'] => Key::Search,
        [27, 91, 72] | [27, 91, 49, 59, 50, 65] | [27, 91, 49, 59, 53, 65] => Key::Home,
        [27, 91, 70] | [27, 91, 49, 59, 50, 66] | [27, 91, 49, 59, 53, 66] => Key::End,
        _ => Key::Other,
    }
}

fn print_go_tty_panic() {
    eprintln!("panic: could not open a new TTY: open /dev/tty: no such device or address");
    eprintln!();
    eprintln!("goroutine 1 [running]:");
    eprintln!("main.main()");
    eprintln!("\t/workspace/main.go:135 +0x87d");
}

#[allow(dead_code)]
fn _is_hidden(name: &OsStr) -> bool {
    name.to_string_lossy().starts_with('.')
}
