use serde_json::{json, Map, Value};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::process;

const HELP: &str = "Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable\n\nUsage:\n  gron [OPTIONS] [FILE|URL|-]\n\nOptions:\n  -u, --ungron     Reverse the operation (turn assignments back into JSON)\n  -v, --values     Print just the values of provided assignments\n  -c, --colorize   Colorize output (default on tty)\n  -m, --monochrome Monochrome (don't colorize output)\n  -s, --stream     Treat each line of input as a separate JSON object\n  -k, --insecure   Disable certificate validation\n  -x, --proxy      Set proxy configuration\n      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.\n  -j, --json       Represent gron data as JSON stream\n      --no-sort    Don't sort output (faster)\n      --version    Print version information\n\nExit Codes:\n  0\tOK\n  1\tFailed to open file\n  2\tFailed to read input\n  3\tFailed to form statements\n  4\tFailed to fetch URL\n  5\tFailed to parse statements\n  6\tFailed to encode JSON\n\nExamples:\n  gron /tmp/apiresponse.json\n  gron http://jsonplaceholder.typicode.com/users/1 \n  curl -s http://jsonplaceholder.typicode.com/users/1 | gron\n  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron\n";

#[derive(Default)]
struct Opts {
    ungron: bool,
    values: bool,
    stream: bool,
    json_stream: bool,
    no_sort: bool,
    input: Option<String>,
}

#[derive(Clone, Debug, PartialEq, Eq, PartialOrd, Ord)]
enum PathElem { Key(String), Index(usize) }

fn main() {
    let opts = parse_args();
    if opts.values {
        let input = read_input(opts.input.as_deref()).unwrap_or_else(|c| process::exit(c));
        process_values(&input);
        return;
    }
    if opts.ungron {
        let input = read_input(opts.input.as_deref()).unwrap_or_else(|c| process::exit(c));
        let res = if opts.json_stream { ungron_json_stream(&input) } else { ungron_assignments(&input) };
        match res {
            Ok(v) => match serde_json::to_string_pretty(&v) {
                Ok(s) => println!("{}", s),
                Err(e) => { eprintln!("failed to encode JSON: {}", e); process::exit(6); }
            },
            Err(e) => { eprintln!("{}", e); process::exit(5); }
        }
        return;
    }
    let input = read_input(opts.input.as_deref()).unwrap_or_else(|c| process::exit(c));
    let mut values = Vec::new();
    if opts.stream {
        let mut arr = Vec::new();
        for line in input.lines() {
            if line.trim().is_empty() { continue; }
            match serde_json::from_str::<Value>(line) {
                Ok(v) => arr.push(v),
                Err(e) => { eprintln!("failed to form statements: {}", e); process::exit(3); }
            }
        }
        values.push((Vec::new(), Value::Array(arr)));
    } else {
        match serde_json::from_str::<Value>(&input) {
            Ok(v) => values.push((Vec::new(), v)),
            Err(e) => { eprintln!("failed to form statements: {}", e); process::exit(3); }
        }
    }

    let mut stmts = Vec::new();
    for (base, v) in values { flatten(&v, &mut base.clone(), &mut stmts); }
    if !opts.no_sort { stmts.sort_by(|a, b| cmp_path(&a.0, &b.0)); }
    for (path, val) in stmts {
        if opts.json_stream {
            let pv = path_to_json(&path);
            println!("{}", compact(&Value::Array(vec![pv, val])));
        } else {
            println!("{} = {};", format_path(&path), compact(&val));
        }
    }
}

fn parse_args() -> Opts {
    let mut opts = Opts::default();
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "--help" | "-h" => { print!("{}", HELP); process::exit(0); }
            "--version" => { println!("gron version dev"); process::exit(0); }
            "--ungron" | "-u" => opts.ungron = true,
            "--values" | "-v" => opts.values = true,
            "--stream" | "-s" => opts.stream = true,
            "--json" | "-j" => opts.json_stream = true,
            "--no-sort" => opts.no_sort = true,
            "--colorize" | "-c" | "--monochrome" | "-m" | "--insecure" | "-k" => {}
            "--proxy" | "-x" | "--noproxy" => { i += 1; if i >= args.len() { eprintln!("flag needs an argument: {}", a); process::exit(2); } }
            _ if a.starts_with("--") => { eprintln!("flag provided but not defined: -{}", a.trim_start_matches('-')); print!("{}", HELP); process::exit(2); }
            _ if a.starts_with('-') && a != "-" => {
                let chars: Vec<char> = a[1..].chars().collect();
                let mut consumed = false;
                for ch in chars {
                    match ch {
                        'u' => opts.ungron = true,
                        'v' => opts.values = true,
                        's' => opts.stream = true,
                        'j' => opts.json_stream = true,
                        'c' | 'm' | 'k' => {}
                        'x' => { i += 1; consumed = true; if i >= args.len() { eprintln!("flag needs an argument: -x"); process::exit(2); } break; }
                        _ => { eprintln!("flag provided but not defined: -{}", ch); print!("{}", HELP); process::exit(2); }
                    }
                }
                if consumed {}
            }
            _ => {
                if opts.input.is_none() { opts.input = Some(a.clone()); }
                else { eprintln!("too many arguments"); process::exit(2); }
            }
        }
        i += 1;
    }
    opts
}

fn read_input(input: Option<&str>) -> Result<String, i32> {
    match input {
        None | Some("-") => {
            let mut s = String::new();
            if let Err(e) = io::stdin().read_to_string(&mut s) { eprintln!("failed to read input: {}", e); return Err(2); }
            Ok(s)
        }
        Some(p) if p.starts_with("http://") || p.starts_with("https://") => { eprintln!("failed to fetch URL: network disabled"); Err(4) }
        Some(p) => fs::read_to_string(p).map_err(|e| {
            let msg = e.to_string().replace(" (os error 2)", "");
            eprintln!("open {}: {}", p, msg.to_lowercase());
            1
        })
    }
}

fn flatten(v: &Value, path: &mut Vec<PathElem>, out: &mut Vec<(Vec<PathElem>, Value)>) {
    let emitted = match v { Value::Object(_) => Value::Object(Map::new()), Value::Array(_) => Value::Array(Vec::new()), _ => v.clone() };
    out.push((path.clone(), emitted));
    match v {
        Value::Object(m) => {
            for (k, child) in m { path.push(PathElem::Key(k.clone())); flatten(child, path, out); path.pop(); }
        }
        Value::Array(a) => {
            for (idx, child) in a.iter().enumerate() { path.push(PathElem::Index(idx)); flatten(child, path, out); path.pop(); }
        }
        _ => {}
    }
}

fn cmp_path(a: &[PathElem], b: &[PathElem]) -> std::cmp::Ordering { format_path(a).cmp(&format_path(b)) }

fn format_path(path: &[PathElem]) -> String {
    let mut s = String::from("json");
    for e in path {
        match e {
            PathElem::Index(i) => s.push_str(&format!("[{}]", i)),
            PathElem::Key(k) => {
                if is_ident(k) { s.push('.'); s.push_str(k); }
                else { s.push('['); s.push_str(&serde_json::to_string(k).unwrap()); s.push(']'); }
            }
        }
    }
    s
}

fn is_ident(s: &str) -> bool {
    let mut chars = s.chars();
    let Some(first) = chars.next() else { return false; };
    if !(first == '$' || first == '_' || first.is_alphabetic()) { return false; }
    chars.all(|c| c == '$' || c == '_' || c.is_alphanumeric())
}

fn compact(v: &Value) -> String { serde_json::to_string(v).unwrap() }

fn path_to_json(path: &[PathElem]) -> Value {
    Value::Array(path.iter().map(|e| match e { PathElem::Key(k) => Value::String(k.clone()), PathElem::Index(i) => json!(*i) }).collect())
}

fn parse_assignment(line: &str) -> Result<Option<(Vec<PathElem>, Value)>, String> {
    let t = line.trim();
    if t.is_empty() { return Ok(None); }
    let Some(eq) = t.find('=') else { return Err("no statements were parsed".into()); };
    let left = t[..eq].trim();
    let mut right = t[eq+1..].trim();
    if let Some(r) = right.strip_suffix(';') { right = r.trim_end(); }
    let path = parse_path(left).map_err(|bad| format!("ungron failed for `{}`: invalid statement", bad))?;
    let val: Value = serde_json::from_str(right).map_err(|e| format!("failed to parse statements: {}", e))?;
    Ok(Some((path, val)))
}

fn parse_path(s: &str) -> Result<Vec<PathElem>, String> {
    if !s.starts_with("json") { return Err(s.to_string()); }
    let mut i = 4usize;
    let bytes = s.as_bytes();
    let mut path = Vec::new();
    while i < bytes.len() {
        match bytes[i] as char {
            '.' => {
                i += 1;
                let start = i;
                while i < bytes.len() {
                    let ch = s[i..].chars().next().unwrap();
                    if ch == '.' || ch == '[' || ch.is_whitespace() { break; }
                    i += ch.len_utf8();
                }
                if i == start { return Err(s[..i].to_string()); }
                path.push(PathElem::Key(s[start..i].to_string()));
            }
            '[' => {
                i += 1;
                if i >= bytes.len() { return Err(s.to_string()); }
                if bytes[i] as char == '"' {
                    let start = i;
                    i += 1;
                    let mut esc = false;
                    while i < bytes.len() {
                        let c = bytes[i] as char;
                        if esc { esc = false; i += 1; continue; }
                        if c == '\\' { esc = true; i += 1; continue; }
                        if c == '"' { i += 1; break; }
                        i += 1;
                    }
                    if i >= bytes.len() || bytes[i] as char != ']' { return Err(s.to_string()); }
                    let raw = &s[start..i];
                    let key: String = serde_json::from_str(raw).map_err(|_| s.to_string())?;
                    i += 1;
                    path.push(PathElem::Key(key));
                } else {
                    let start = i;
                    while i < bytes.len() && (bytes[i] as char).is_ascii_digit() { i += 1; }
                    if i == start || i >= bytes.len() || bytes[i] as char != ']' { return Err(s.to_string()); }
                    let idx = s[start..i].parse::<usize>().map_err(|_| s.to_string())?;
                    i += 1;
                    path.push(PathElem::Index(idx));
                }
            }
            _ => return Err(s[..i+1.min(s.len()-i)].to_string()),
        }
    }
    Ok(path)
}

fn ungron_assignments(input: &str) -> Result<Value, String> {
    let mut root = Value::Null;
    let mut parsed = 0;
    for line in input.lines() {
        if let Some((path, val)) = parse_assignment(line)? {
            parsed += 1;
            insert_value(&mut root, &path, val);
        }
    }
    if parsed == 0 { return Err("no statements were parsed".into()); }
    Ok(root)
}

fn ungron_json_stream(input: &str) -> Result<Value, String> {
    let mut root = Value::Null;
    let mut parsed = 0;
    for line in input.lines() {
        let t = line.trim();
        if t.is_empty() { continue; }
        let v: Value = serde_json::from_str(t).map_err(|e| format!("failed to parse statements: {}", e))?;
        let arr = v.as_array().ok_or_else(|| "failed to parse statements: expected array".to_string())?;
        if arr.len() != 2 { return Err("failed to parse statements: expected [path,value]".into()); }
        let parr = arr[0].as_array().ok_or_else(|| "failed to parse statements: expected path array".to_string())?;
        let mut path = Vec::new();
        for pe in parr {
            if let Some(s) = pe.as_str() { path.push(PathElem::Key(s.to_string())); }
            else if let Some(u) = pe.as_u64() { path.push(PathElem::Index(u as usize)); }
            else { return Err("failed to parse statements: invalid path element".into()); }
        }
        insert_value(&mut root, &path, arr[1].clone());
        parsed += 1;
    }
    if parsed == 0 { return Err("no statements were parsed".into()); }
    Ok(root)
}

fn insert_value(root: &mut Value, path: &[PathElem], val: Value) {
    if path.is_empty() { *root = val; return; }
    ensure_container(root, &path[0]);
    let mut cur = root;
    for (i, elem) in path.iter().enumerate() {
        let last = i == path.len() - 1;
        match elem {
            PathElem::Key(k) => {
                if !cur.is_object() { *cur = Value::Object(Map::new()); }
                let map = cur.as_object_mut().unwrap();
                if last { map.insert(k.clone(), val); return; }
                let next = map.entry(k.clone()).or_insert(Value::Null);
                ensure_container(next, &path[i+1]);
                cur = next;
            }
            PathElem::Index(idx) => {
                if !cur.is_array() { *cur = Value::Array(Vec::new()); }
                let arr = cur.as_array_mut().unwrap();
                while arr.len() <= *idx { arr.push(Value::Null); }
                if last { arr[*idx] = val; return; }
                ensure_container(&mut arr[*idx], &path[i+1]);
                cur = &mut arr[*idx];
            }
        }
    }
}

fn ensure_container(v: &mut Value, next: &PathElem) {
    match next {
        PathElem::Key(_) if !v.is_object() => *v = Value::Object(Map::new()),
        PathElem::Index(_) if !v.is_array() => *v = Value::Array(Vec::new()),
        _ => {}
    }
}

fn process_values(input: &str) {
    for line in input.lines() {
        if let Ok(Some((_p, v))) = parse_assignment(line) {
            match v {
                Value::Object(_) | Value::Array(_) => {}
                Value::String(s) => println!("{}", s),
                other => println!("{}", compact(&other)),
            }
        }
    }
}
