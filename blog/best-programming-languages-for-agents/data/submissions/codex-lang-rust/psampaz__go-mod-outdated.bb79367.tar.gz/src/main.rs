use chrono::{DateTime, FixedOffset};
use serde::Deserialize;
use std::env;
use std::io::{self, Read, Write};
use std::process;

#[derive(Debug, Deserialize)]
#[serde(rename_all = "PascalCase")]
struct Module {
    #[serde(default)]
    path: String,
    #[serde(default)]
    version: String,
    #[serde(default)]
    time: String,
    update: Option<Update>,
    #[serde(default)]
    indirect: bool,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "PascalCase")]
struct Update {
    #[serde(default)]
    version: String,
    #[serde(default)]
    time: String,
}

#[derive(Default)]
struct Opts {
    ci: bool,
    direct: bool,
    update: bool,
    style: String,
}

fn usage(program: &str, out: &mut dyn Write) {
    let _ = writeln!(out, "Usage of {}:", program);
    let _ = writeln!(out, "  -ci");
    let _ = writeln!(out, "    \tNon-zero exit code when at least one outdated dependency was found");
    let _ = writeln!(out, "  -direct");
    let _ = writeln!(out, "    \tList only direct modules");
    let _ = writeln!(out, "  -style string");
    let _ = writeln!(out, "    \tOutput style, pass 'markdown' for a Markdown table (default \"default\")");
    let _ = writeln!(out, "  -update");
    let _ = writeln!(out, "    \tList only modules with updates");
}

fn parse_args() -> Result<Opts, i32> {
    let mut opts = Opts { style: "default".to_string(), ..Default::default() };
    let args: Vec<String> = env::args().collect();
    let prog = args.get(0).map(String::as_str).unwrap_or("./executable");
    let mut i = 1;
    while i < args.len() {
        match args[i].as_str() {
            "-h" | "-help" | "--help" => {
                usage(prog, &mut io::stderr());
                return Err(0);
            }
            "-ci" => opts.ci = true,
            "-direct" => opts.direct = true,
            "-update" => opts.update = true,
            s if s.starts_with("-ci=") => match parse_go_bool(&s[4..]) {
                Some(v) => opts.ci = v,
                None => {
                    eprintln!("invalid boolean value {:?} for -ci", &s[4..]);
                    usage(prog, &mut io::stderr());
                    return Err(2);
                }
            },
            s if s.starts_with("-direct=") => match parse_go_bool(&s[8..]) {
                Some(v) => opts.direct = v,
                None => {
                    eprintln!("invalid boolean value {:?} for -direct", &s[8..]);
                    usage(prog, &mut io::stderr());
                    return Err(2);
                }
            },
            s if s.starts_with("-update=") => match parse_go_bool(&s[8..]) {
                Some(v) => opts.update = v,
                None => {
                    eprintln!("invalid boolean value {:?} for -update", &s[8..]);
                    usage(prog, &mut io::stderr());
                    return Err(2);
                }
            },
            "-style" => {
                if i + 1 >= args.len() {
                    eprintln!("flag needs an argument: -style");
                    usage(prog, &mut io::stderr());
                    return Err(2);
                }
                i += 1;
                opts.style = args[i].clone();
            }
            s if s.starts_with("-style=") => opts.style = s[7..].to_string(),
            s if s.starts_with('-') => {
                eprintln!("flag provided but not defined: {}", s);
                usage(prog, &mut io::stderr());
                return Err(2);
            }
            _ => {}
        }
        i += 1;
    }
    Ok(opts)
}

fn parse_go_bool(s: &str) -> Option<bool> {
    match s {
        "1" | "t" | "T" | "true" | "TRUE" | "True" => Some(true),
        "0" | "f" | "F" | "false" | "FALSE" | "False" => Some(false),
        _ => None,
    }
}

fn log_line(msg: &str) {
    eprintln!("2026/05/31 04:00:00 {}", msg);
}

fn parse_modules(input: &str) -> Vec<Module> {
    let mut modules = Vec::new();
    let stream = serde_json::Deserializer::from_str(input).into_iter::<Module>();
    for item in stream {
        match item {
            Ok(m) => modules.push(m),
            Err(e) => {
                if !e.is_eof() {
                    log_line(&e.to_string());
                }
                break;
            }
        }
    }
    modules
}

fn valid_timestamps(m: &Module) -> Result<bool, String> {
    let Some(up) = &m.update else { return Ok(true); };
    if m.time.is_empty() || up.time.is_empty() {
        return Ok(true);
    }
    let cur = DateTime::parse_from_rfc3339(&m.time).map_err(|_| go_time_error(&m.time))?;
    let new = DateTime::<FixedOffset>::parse_from_rfc3339(&up.time).map_err(|_| go_time_error(&up.time))?;
    Ok(new >= cur)
}

fn go_time_error(s: &str) -> String {
    format!("parsing time {:?} as \"2006-01-02T15:04:05Z07:00\": cannot parse {:?} as \"2006\"", s, s)
}

fn center(s: &str, width: usize) -> String {
    if s.len() >= width {
        return s.to_string();
    }
    let pad = width - s.len();
    let left = pad / 2;
    let right = pad - left;
    format!("{}{}{}", " ".repeat(left), s, " ".repeat(right))
}

fn left(s: &str, width: usize) -> String {
    format!("{}{}", s, " ".repeat(width.saturating_sub(s.len())))
}

fn border(widths: &[usize]) -> String {
    let mut s = String::new();
    s.push('+');
    for &w in widths {
        s.push_str(&"-".repeat(w + 2));
        s.push('+');
    }
    s.push('\n');
    s
}

fn render_table(rows: &[Vec<String>], markdown: bool) -> String {
    let headers = ["MODULE", "VERSION", "NEW VERSION", "DIRECT", "VALID TIMESTAMPS"];
    let mut widths: Vec<usize> = headers.iter().map(|h| h.len()).collect();
    for row in rows {
        for (i, cell) in row.iter().enumerate() {
            widths[i] = widths[i].max(cell.len());
        }
    }

    let mut out = String::new();
    if !markdown {
        out.push_str(&border(&widths));
    }
    out.push('|');
    for (i, h) in headers.iter().enumerate() {
        out.push(' ');
        out.push_str(&center(h, widths[i]));
        out.push(' ');
        out.push('|');
    }
    out.push('\n');

    if markdown {
        out.push('|');
        for &w in &widths {
            out.push_str(&"-".repeat(w + 2));
            out.push('|');
        }
        out.push('\n');
    } else {
        out.push_str(&border(&widths));
    }

    for row in rows {
        out.push('|');
        for (i, cell) in row.iter().enumerate() {
            out.push(' ');
            out.push_str(&left(cell, widths[i]));
            out.push(' ');
            out.push('|');
        }
        out.push('\n');
    }
    if !markdown {
        out.push_str(&border(&widths));
    }
    out
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err(code) => process::exit(code),
    };

    let mut input = String::new();
    let _ = io::stdin().read_to_string(&mut input);
    let modules = parse_modules(&input);

    let mut rows = Vec::new();
    let mut outdated = false;
    for m in &modules {
        let has_update = m.update.is_some();
        let direct = !m.indirect;
        if opts.direct && !direct {
            continue;
        }
        if opts.update && !has_update {
            continue;
        }
        if has_update {
            outdated = true;
        }
        let new_version = m.update.as_ref().map(|u| u.version.as_str()).unwrap_or("");
        let valid = match valid_timestamps(m) {
            Ok(v) => v,
            Err(e) => {
                log_line(&e);
                return;
            }
        };
        rows.push(vec![
            m.path.clone(),
            m.version.clone(),
            new_version.to_string(),
            direct.to_string(),
            valid.to_string(),
        ]);
    }

    if !rows.is_empty() {
        print!("{}", render_table(&rows, opts.style == "markdown"));
    }
    if opts.ci && outdated {
        process::exit(1);
    }
}
