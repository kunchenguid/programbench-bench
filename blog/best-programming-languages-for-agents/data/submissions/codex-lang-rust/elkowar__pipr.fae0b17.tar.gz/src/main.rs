use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::process::{Command, Stdio};

const CONFIG_REFERENCE: &str = r#"
#  ____  _
# |  _ \(_)_ __  _ __       .________.
# | |_) | | '_ \| '__|      |________|
# |  __/| | |_) | |          |_    -|
# |_|   |_| .__/|_|     xX  xXx___x_|
#         |_|
#
# A commandline utility by
# Leon Kowarschick

# finish_hook: Executed once you close pipr, getting the command you constructed piped into stdin.
# finish_hook = "xclip -selection clipboard -in"

# Paranoid history mode writes every sucessfully running command into the history in autoeval mode.
paranoid_history_mode_default = false

autoeval_mode_default = true

history_size = 500
cmdlist_always_show_preview = false
cmd_timeout_millis = 2000

highlighting_enabled = true

eval_environment = ["bash", "-c"]

# Snippets can be used to quickly insert common bits of shell
# use || (two pipes) where you want your cursor to be after insertion
[snippets]
s = " | sed -r 's/||//g'"

[help_viewers]
'm' = "man ??"
'h' = "?? --help | less"

[output_viewers]
'l' = "less"

"#;

#[derive(Default)]
struct Opts {
    default_text: Option<String>,
    out_file: Option<String>,
    in_file: Option<String>,
    config_reference: bool,
    raw_mode: bool,
    no_isolation: bool,
    help: bool,
}

fn usage(program: &str) -> String {
    format!(
        r#"Usage: {program} [options]

Options:
    -d, --default TEXT  text inserted into the textfield on startup
    -o, --out-file FILE write final command to file
        --in-file FILE  read initial command from file
        --config-reference 
                        print out the default configuration file
    -r, --raw-mode      keep linebreaks in finished command when closing
        --no-isolation  disable isolation. This will run the commands directly
                        on your system, without protection. Take care.
    -h, --help          print this help menu
"#
    )
}

fn option_error(program: &str, msg: &str) -> ! {
    eprintln!("{program}: {msg}");
    std::process::exit(1);
}

fn parse_args(program: &str, args: &[String]) -> Opts {
    let mut opts = Opts::default();
    let mut i = 0usize;
    let mut positional_only = false;

    while i < args.len() {
        let arg = &args[i];
        if positional_only || arg == "-" || !arg.starts_with('-') {
            i += 1;
            continue;
        }
        if arg == "--" {
            positional_only = true;
            i += 1;
            continue;
        }
        if let Some(long) = arg.strip_prefix("--") {
            let (name, value) = match long.split_once('=') {
                Some((n, v)) => (n, Some(v.to_string())),
                None => (long, None),
            };
            match name {
                "default" => opts.default_text = Some(take_value(program, "default", value, args, &mut i)),
                "out-file" => opts.out_file = Some(take_value(program, "out-file", value, args, &mut i)),
                "in-file" => opts.in_file = Some(take_value(program, "in-file", value, args, &mut i)),
                "config-reference" => opts.config_reference = true,
                "raw-mode" => opts.raw_mode = true,
                "no-isolation" => opts.no_isolation = true,
                "help" => opts.help = true,
                other => option_error(program, &format!("Unrecognized option: '{other}'")),
            }
            i += 1;
            continue;
        }

        let chars: Vec<char> = arg[1..].chars().collect();
        let mut j = 0usize;
        while j < chars.len() {
            match chars[j] {
                'h' => {
                    opts.help = true;
                    j += 1;
                }
                'r' => {
                    opts.raw_mode = true;
                    j += 1;
                }
                'd' | 'o' => {
                    let opt = chars[j];
                    let rest: String = chars[j + 1..].iter().collect();
                    let value = if rest.is_empty() {
                        if i + 1 >= args.len() {
                            option_error(program, &format!("Argument to option '{opt}' missing"));
                        }
                        i += 1;
                        args[i].clone()
                    } else {
                        rest
                    };
                    if opt == 'd' {
                        opts.default_text = Some(value);
                    } else {
                        opts.out_file = Some(value);
                    }
                    break;
                }
                other => option_error(program, &format!("Unrecognized option: '{other}'")),
            }
        }
        i += 1;
    }
    opts
}

fn take_value(
    program: &str,
    name: &str,
    inline: Option<String>,
    args: &[String],
    i: &mut usize,
) -> String {
    if let Some(v) = inline {
        return v;
    }
    if *i + 1 >= args.len() {
        option_error(program, &format!("Argument to option '{name}' missing"));
    }
    *i += 1;
    args[*i].clone()
}

fn bwrap_available() -> bool {
    let Some(path) = env::var_os("PATH") else {
        return false;
    };
    env::split_paths(&path).any(|dir| {
        let candidate = dir.join("bwrap");
        candidate.is_file()
    })
}

fn read_initial(opts: &Opts) -> io::Result<String> {
    if let Some(path) = &opts.in_file {
        return fs::read_to_string(path);
    }
    Ok(opts.default_text.clone().unwrap_or_default())
}

fn write_final(opts: &Opts, command: &str) -> io::Result<()> {
    let mut text = command.to_string();
    if !opts.raw_mode {
        text = text.replace('\n', " ");
    }
    if let Some(path) = &opts.out_file {
        fs::write(path, text)
    } else {
        println!("{text}");
        Ok(())
    }
}

fn eval_command(command: &str) -> String {
    if command.trim().is_empty() {
        return String::new();
    }
    match Command::new("bash")
        .arg("-c")
        .arg(command)
        .stdin(Stdio::null())
        .output()
    {
        Ok(out) => {
            let mut s = String::new();
            s.push_str(&String::from_utf8_lossy(&out.stdout));
            s.push_str(&String::from_utf8_lossy(&out.stderr));
            s
        }
        Err(e) => format!("Error: {e}\n"),
    }
}

fn run_noninteractive(opts: &Opts, command: &str) -> ! {
    if !io::stdin().is_terminal() {
        eprint!("\x1b[?1049hError: No such device or address (os error 6)\n");
        std::process::exit(1);
    }
    let _ = write_final(opts, command);
    std::process::exit(0);
}

fn run_tty(opts: &Opts, mut command: String) -> io::Result<()> {
    print!("\x1b[?1049h\x1b[2J\x1b[H");
    io::stdout().flush()?;
    draw(&command);

    let mut stdin = io::stdin();
    let mut buf = [0u8; 1];
    loop {
        match stdin.read(&mut buf) {
            Ok(0) => {
                break;
            }
            Ok(_) => match buf[0] {
                3 => {
                    print!("\x1b[?1049l");
                    io::stdout().flush()?;
                    std::process::exit(130);
                }
                4 | 27 => break,
                b'\r' | b'\n' => {
                    let output = eval_command(&command);
                    draw_with_output(&command, &output);
                }
                8 | 127 => {
                    command.pop();
                    draw(&command);
                }
                byte if byte.is_ascii_graphic() || byte == b' ' || byte == b'\t' => {
                    command.push(byte as char);
                    draw(&command);
                }
                _ => {}
            },
            Err(_) => break,
        }
    }
    print!("\x1b[?1049l");
    io::stdout().flush()?;
    write_final(opts, &command)
}

fn draw(command: &str) {
    let output = eval_command(command);
    draw_with_output(command, &output);
}

fn draw_with_output(command: &str, output: &str) {
    print!(
        "\x1b[H\x1b[2J┌ Command [Autoeval] ────────────────────────────────────────────────────────┐\n\
│{:<76}│\n\
└────────────────────────────────────────────────────────────────────────────┘\n\
┌ Output [+] ────────────────────────────────────────────────────────────────┐\n",
        command.chars().take(76).collect::<String>()
    );
    for line in output.lines().take(18) {
        println!("│{:<76}│", line.chars().take(76).collect::<String>());
    }
    println!("└──────────────────────────────────────────────────────────────────Help: F1──┘");
    let _ = io::stdout().flush();
}

fn main() {
    let mut argv: Vec<String> = env::args().collect();
    let program = argv.remove(0);
    let opts = parse_args(&program, &argv);

    if opts.help {
        print!("{}", usage(&program));
        return;
    }
    if opts.config_reference {
        print!("{CONFIG_REFERENCE}");
        return;
    }
    if !opts.no_isolation && !bwrap_available() {
        eprintln!("bubblewrap installation not found. Please make sure you have `bwrap` on your path, or supply --no-isolation to disable safe-mode");
        std::process::exit(1);
    }

    let command = match read_initial(&opts) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("Error: {e}");
            std::process::exit(1);
        }
    };

    if !io::stdin().is_terminal() {
        run_noninteractive(&opts, &command);
    }

    if let Err(e) = run_tty(&opts, command) {
        eprintln!("Error: {e}");
        std::process::exit(1);
    }
}
