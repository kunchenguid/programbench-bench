use std::env;
use std::io;
use std::mem;
use std::net::{IpAddr, ToSocketAddrs};
use std::os::fd::RawFd;
use std::thread::sleep;
use std::time::{Duration, Instant};

const VERSION: &str = "pingu: v-rev9c2e3df";
const HELP: &str = "Usage:\n  pingu [OPTIONS] HOST\n\n`ping` command but with pingu\n\nApplication Options:\n  -c, --count=     Stop after <count> replies (default: 20)\n  -P, --privilege  Enable privileged mode\n  -V, --version    Show version\n\nHelp Options:\n  -h, --help       Show this help message\n";
const PAYLOAD_SIZE: usize = 32;

const ART: [&str; 20] = [
    " ...        .     ...   ..    ..     .........           ",
    " ...     ....          ..  ..      ... .....  .. ..      ",
    " ...    .......      ...         ... . ..... #######     ",
    ".....  ........ .###############.....  ... ##########.  .",
    " .... ........#####################.  ... ###########    ",
    "      ....... ######################.... ############    ",
    ".    .  .... ########################... ###########     ",
    "   ..   ....#########################.. .###########     ",
    "   ..  .... #########################...##########       ",
    "       .... #########################...#########        ",
    "      ..... #########################..#########         ",
    "     ...... #########################..########          ",
    "    ....... #########################.########           ",
    "   ........ #########################.#######            ",
    "  ......... #########################..#####             ",
    " .......... #########################...###              ",
    "..........  #########################....#               ",
    ".........   #########################....                ",
    "........    #########################                    ",
    ".......     #########################                    ",
];

#[derive(Clone, Debug)]
struct Args {
    count: i64,
    privilege: bool,
    host: String,
}

fn main() {
    match parse_args() {
        ParseOutcome::Run(args) => {
            let code = run(args);
            std::process::exit(code);
        }
        ParseOutcome::Exit(code) => std::process::exit(code),
    }
}

enum ParseOutcome {
    Run(Args),
    Exit(i32),
}

fn parse_args() -> ParseOutcome {
    let mut count = 20_i64;
    let mut privilege = false;
    let mut hosts: Vec<String> = Vec::new();
    let mut it = env::args().skip(1).peekable();

    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                print!("{}", HELP);
                return ParseOutcome::Exit(0);
            }
            "-V" | "--version" => {
                println!("{}", VERSION);
                return ParseOutcome::Exit(0);
            }
            "-P" | "--privilege" => privilege = true,
            "-c" | "--count" => {
                let Some(v) = it.next() else {
                    parse_error("expected argument for flag `-c, --count'");
                    return ParseOutcome::Exit(1);
                };
                match parse_count(&v) {
                    Ok(n) => count = n,
                    Err(msg) => {
                        parse_error(&msg);
                        return ParseOutcome::Exit(1);
                    }
                }
            }
            _ if arg.starts_with("--count=") => {
                let v = &arg[8..];
                match parse_count(v) {
                    Ok(n) => count = n,
                    Err(msg) => {
                        parse_error(&msg);
                        return ParseOutcome::Exit(1);
                    }
                }
            }
            _ if arg.starts_with("-c") && arg.len() > 2 => {
                let v = &arg[2..];
                match parse_count(v) {
                    Ok(n) => count = n,
                    Err(msg) => {
                        parse_error(&msg);
                        return ParseOutcome::Exit(1);
                    }
                }
            }
            _ if arg.starts_with("--") => {
                let name = &arg[2..];
                let msg = format!("unknown flag `{}'", name);
                parse_error(&msg);
                return ParseOutcome::Exit(1);
            }
            _ if arg.starts_with('-') && arg != "-" => {
                let name = arg.trim_start_matches('-');
                let msg = format!("unknown flag `{}'", name);
                parse_error(&msg);
                return ParseOutcome::Exit(1);
            }
            _ => hosts.push(arg),
        }
    }

    if hosts.is_empty() {
        eprintln!("[ ERROR ] must requires an argument");
        return ParseOutcome::Exit(1);
    }
    if hosts.len() > 1 {
        eprintln!("[ ERROR ] too many arguments");
        return ParseOutcome::Exit(1);
    }

    ParseOutcome::Run(Args {
        count,
        privilege,
        host: hosts.remove(0),
    })
}

fn parse_count(s: &str) -> Result<i64, String> {
    s.parse::<i64>().map_err(|_| {
        format!(
            "invalid argument for flag `-c, --count' (expected int): strconv.ParseInt: parsing \"{}\": invalid syntax",
            s
        )
    })
}

fn parse_error(msg: &str) {
    eprintln!("{}", msg);
    eprintln!("[ ERROR ] parse error: {}", msg);
}

fn run(args: Args) -> i32 {
    let addr = match resolve_host(&args.host) {
        Ok(ip) => ip,
        Err(e) => {
            eprintln!("[ ERROR ] an error occurred when running ping: {}", e);
            return 2;
        }
    };

    println!("PING {} ({}) type `Ctrl-C` to abort", args.host, addr);

    let mut pinger = match Pinger::new(addr, args.privilege) {
        Ok(p) => p,
        Err(e) => {
            eprintln!("[ ERROR ] an error occurred when running ping: {}", e);
            return 2;
        }
    };

    let limit = if args.count <= 0 {
        None
    } else {
        Some(args.count as usize)
    };
    let mut seq: u16 = 0;
    let mut transmitted = 0_usize;
    let mut received = 0_usize;
    let mut times = Vec::new();

    loop {
        if let Some(n) = limit {
            if transmitted >= n {
                break;
            }
        }
        transmitted += 1;
        match pinger.ping(seq) {
            Ok(d) => {
                received += 1;
                times.push(d);
                let art = ART[(seq as usize).min(ART.len() - 1)];
                println!(
                    "{} seq={} {}bytes from {}: ttl=64 time={}",
                    art,
                    seq,
                    PAYLOAD_SIZE,
                    addr,
                    fmt_duration(d)
                );
            }
            Err(e) => {
                eprintln!("[ ERROR ] an error occurred when running ping: {}", e);
                if args.privilege {
                    return 2;
                }
            }
        }
        seq = seq.wrapping_add(1);
        if limit.map_or(true, |n| transmitted < n) {
            sleep(Duration::from_secs(1));
        }
    }

    print_stats(&args.host, transmitted, received, &times);
    0
}

fn resolve_host(host: &str) -> io::Result<IpAddr> {
    if let Ok(ip) = host.parse::<IpAddr>() {
        return Ok(ip);
    }
    let mut addrs: Vec<IpAddr> = (host, 0).to_socket_addrs()?.map(|s| s.ip()).collect();
    addrs.sort_by_key(|ip| if ip.is_ipv4() { 0 } else { 1 });
    addrs.dedup();
    addrs
        .into_iter()
        .next()
        .ok_or_else(|| io::Error::new(io::ErrorKind::NotFound, "no such host"))
}

fn print_stats(host: &str, tx: usize, rx: usize, times: &[Duration]) {
    println!();
    println!("───────── {} ping statistics ─────────", host);
    let loss = if tx == 0 { 0 } else { ((tx - rx) * 100) / tx };
    println!(
        "PACKET STATISTICS: {} transmitted => {} received ({}% loss)",
        tx, rx, loss
    );
    if times.is_empty() {
        println!("ROUND TRIP: min=0s avg=0s max=0s stddev=0s");
        return;
    }
    let vals: Vec<f64> = times.iter().map(|d| d.as_nanos() as f64).collect();
    let min = *times.iter().min().unwrap();
    let max = *times.iter().max().unwrap();
    let avg_ns = vals.iter().sum::<f64>() / vals.len() as f64;
    let var = vals.iter().map(|v| (v - avg_ns).powi(2)).sum::<f64>() / vals.len() as f64;
    let avg = Duration::from_nanos(avg_ns.round() as u64);
    let stddev = Duration::from_nanos(var.sqrt().round() as u64);
    println!(
        "ROUND TRIP: min={} avg={} max={} stddev={}",
        fmt_duration(min),
        fmt_duration(avg),
        fmt_duration(max),
        fmt_duration(stddev)
    );
}

fn fmt_duration(d: Duration) -> String {
    let ns = d.as_nanos();
    if ns == 0 {
        return "0s".to_string();
    }
    if ns < 1_000_000 {
        let whole = ns / 1_000;
        let frac = ns % 1_000;
        if frac == 0 {
            format!("{}µs", whole)
        } else {
            format!("{}.{:03}µs", whole, frac)
                .trim_end_matches('0')
                .trim_end_matches('.')
                .to_string()
        }
    } else if ns < 1_000_000_000 {
        let whole = ns / 1_000_000;
        let frac = ns % 1_000_000;
        if frac == 0 {
            format!("{}ms", whole)
        } else {
            format!("{}.{:06}ms", whole, frac)
                .trim_end_matches('0')
                .trim_end_matches('.')
                .to_string()
        }
    } else {
        let whole = ns / 1_000_000_000;
        let frac = ns % 1_000_000_000;
        if frac == 0 {
            format!("{}s", whole)
        } else {
            format!("{}.{:09}s", whole, frac)
                .trim_end_matches('0')
                .trim_end_matches('.')
                .to_string()
        }
    }
}

struct Pinger {
    fd: RawFd,
    addr: IpAddr,
    ident: u16,
    raw: bool,
}

impl Pinger {
    fn new(addr: IpAddr, privilege: bool) -> io::Result<Self> {
        let (domain, proto) = match addr {
            IpAddr::V4(_) => (libc::AF_INET, libc::IPPROTO_ICMP),
            IpAddr::V6(_) => (libc::AF_INET6, libc::IPPROTO_ICMPV6),
        };
        let sock_type = if privilege {
            libc::SOCK_RAW
        } else {
            libc::SOCK_DGRAM
        };
        let fd = unsafe { libc::socket(domain, sock_type, proto) };
        if fd < 0 {
            let e = io::Error::last_os_error();
            if privilege && e.raw_os_error() == Some(libc::EPERM) {
                let proto_name = if matches!(addr, IpAddr::V4(_)) {
                    "ip4:icmp"
                } else {
                    "ip6:ipv6-icmp"
                };
                return Err(io::Error::new(
                    io::ErrorKind::PermissionDenied,
                    format!("listen {} : socket: operation not permitted", proto_name),
                ));
            }
            return Err(e);
        }
        let tv = libc::timeval {
            tv_sec: 3,
            tv_usec: 0,
        };
        unsafe {
            libc::setsockopt(
                fd,
                libc::SOL_SOCKET,
                libc::SO_RCVTIMEO,
                &tv as *const _ as *const _,
                mem::size_of_val(&tv) as libc::socklen_t,
            );
        }
        Ok(Self {
            fd,
            addr,
            ident: std::process::id() as u16,
            raw: privilege,
        })
    }

    fn ping(&mut self, seq: u16) -> io::Result<Duration> {
        match self.addr {
            IpAddr::V4(ip) => self.ping_v4(ip, seq),
            IpAddr::V6(ip) => self.ping_v6(ip, seq),
        }
    }

    fn ping_v4(&mut self, ip: std::net::Ipv4Addr, seq: u16) -> io::Result<Duration> {
        let mut pkt = vec![0_u8; 8 + PAYLOAD_SIZE];
        pkt[0] = 8;
        pkt[1] = 0;
        pkt[4..6].copy_from_slice(&self.ident.to_be_bytes());
        pkt[6..8].copy_from_slice(&seq.to_be_bytes());
        for (i, b) in pkt[8..].iter_mut().enumerate() {
            *b = i as u8;
        }
        let c = checksum(&pkt);
        pkt[2..4].copy_from_slice(&c.to_be_bytes());

        let mut sockaddr: libc::sockaddr_in = unsafe { mem::zeroed() };
        sockaddr.sin_family = libc::AF_INET as libc::sa_family_t;
        sockaddr.sin_addr = libc::in_addr {
            s_addr: u32::from_ne_bytes(ip.octets()),
        };
        let start = Instant::now();
        let sent = unsafe {
            libc::sendto(
                self.fd,
                pkt.as_ptr() as *const _,
                pkt.len(),
                0,
                &sockaddr as *const _ as *const libc::sockaddr,
                mem::size_of_val(&sockaddr) as libc::socklen_t,
            )
        };
        if sent < 0 {
            return Err(io::Error::last_os_error());
        }

        let mut buf = [0_u8; 1500];
        loop {
            let n = unsafe { libc::recv(self.fd, buf.as_mut_ptr() as *mut _, buf.len(), 0) };
            if n < 0 {
                return Err(io::Error::last_os_error());
            }
            let n = n as usize;
            let off = if self.raw && n >= 28 {
                ((buf[0] & 0x0f) as usize) * 4
            } else {
                0
            };
            if n >= off + 8 && buf[off] == 0 {
                let rseq = u16::from_be_bytes([buf[off + 6], buf[off + 7]]);
                if !self.raw || rseq == seq {
                    return Ok(start.elapsed());
                }
            }
        }
    }

    fn ping_v6(&mut self, ip: std::net::Ipv6Addr, seq: u16) -> io::Result<Duration> {
        let mut pkt = vec![0_u8; 8 + PAYLOAD_SIZE];
        pkt[0] = 128;
        pkt[1] = 0;
        pkt[4..6].copy_from_slice(&self.ident.to_be_bytes());
        pkt[6..8].copy_from_slice(&seq.to_be_bytes());
        for (i, b) in pkt[8..].iter_mut().enumerate() {
            *b = i as u8;
        }

        let mut sockaddr: libc::sockaddr_in6 = unsafe { mem::zeroed() };
        sockaddr.sin6_family = libc::AF_INET6 as libc::sa_family_t;
        sockaddr.sin6_addr = libc::in6_addr {
            s6_addr: ip.octets(),
        };
        let start = Instant::now();
        let sent = unsafe {
            libc::sendto(
                self.fd,
                pkt.as_ptr() as *const _,
                pkt.len(),
                0,
                &sockaddr as *const _ as *const libc::sockaddr,
                mem::size_of_val(&sockaddr) as libc::socklen_t,
            )
        };
        if sent < 0 {
            return Err(io::Error::last_os_error());
        }
        let mut buf = [0_u8; 1500];
        loop {
            let n = unsafe { libc::recv(self.fd, buf.as_mut_ptr() as *mut _, buf.len(), 0) };
            if n < 0 {
                return Err(io::Error::last_os_error());
            }
            let n = n as usize;
            if n >= 8 && (buf[0] == 129 || buf[0] == 0) {
                let rseq = u16::from_be_bytes([buf[6], buf[7]]);
                if !self.raw || rseq == seq {
                    return Ok(start.elapsed());
                }
            }
        }
    }
}

impl Drop for Pinger {
    fn drop(&mut self) {
        unsafe {
            libc::close(self.fd);
        }
    }
}

fn checksum(data: &[u8]) -> u16 {
    let mut sum = 0_u32;
    let mut chunks = data.chunks_exact(2);
    for c in &mut chunks {
        sum += u16::from_be_bytes([c[0], c[1]]) as u32;
    }
    if let Some(&b) = chunks.remainder().first() {
        sum += (b as u32) << 8;
    }
    while (sum >> 16) != 0 {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    !(sum as u16)
}
