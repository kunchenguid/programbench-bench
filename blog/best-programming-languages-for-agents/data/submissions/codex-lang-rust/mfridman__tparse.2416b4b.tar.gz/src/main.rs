use serde::Deserialize;
use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::env;
use std::fs::File;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::process;

#[derive(Debug, Default)]
struct Opts {
    help: bool,
    version: bool,
    all: bool,
    pass: bool,
    skip: bool,
    notests: bool,
    smallscreen: bool,
    slow: usize,
    sort: String,
    nocolor: bool,
    format: String,
    file: Option<String>,
    follow: bool,
    follow_output: Option<String>,
    include_timestamp: bool,
    progress: bool,
    compare: Option<String>,
    trimpath: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "PascalCase")]
struct Event {
    #[serde(default)] time: String,
    #[serde(default)] action: String,
    #[serde(default)] package: String,
    #[serde(default)] test: String,
    #[serde(default)] output: String,
    #[serde(default)] elapsed: f64,
}

#[derive(Debug, Clone)]
struct TestRec { package: String, name: String, status: String, elapsed: f64, output: String }

#[derive(Debug, Clone)]
struct PkgRec {
    name: String,
    status: String,
    elapsed: f64,
    cover: Option<String>,
    pass: usize,
    fail: usize,
    skip: usize,
    output: String,
    notest: bool,
    notest_msg: String,
}

impl PkgRec {
    fn new(name: &str) -> Self {
        Self { name: name.to_string(), status: String::new(), elapsed: 0.0, cover: None, pass: 0, fail: 0, skip: 0, output: String::new(), notest: false, notest_msg: String::new() }
    }
}

fn usage() -> &'static str {
"Usage:
    go test ./... -json | tparse [options...]
    go test [packages...] -json | tparse [options...]
    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out

Options:
    -h                 Show help.
    -v                 Show version.
    -all               Display table event for pass and skip. (Failed items always displayed)
    -pass              Display table for passed tests.
    -skip              Display table for skipped tests.
    -notests           Display packages containing no test files or empty test files.
    -smallscreen       Split subtest names vertically to fit on smaller screens.
    -slow              Number of slowest tests to display. Default is 0, display all.
    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.
    -nocolor           Disable all colors. (NO_COLOR also supported)
    -format            The output format for tables [basic, plain, markdown]. Default is basic.
    -file              Read test output from a file.
    -follow            Follow raw output from go test to stdout.
    -follow-output     Write raw output from go test to a file (takes precedence over -follow).
    -include-timestamp Include timestamps in follow output. 
    -progress          Print a single summary line for each package. Useful for long running test suites.
    -compare           Compare against a previous test output file. (experimental)
    -trimpath          Remove path prefix from package names in output, simplifying their display.
"
}

fn parse_args() -> Result<Opts, i32> {
    let mut o = Opts { sort: "name".into(), format: "basic".into(), ..Default::default() };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0usize;
    while i < args.len() {
        let arg = args[i].clone();
        let (key, inline) = if let Some(p) = arg.find('=') { (arg[..p].to_string(), Some(arg[p+1..].to_string())) } else { (arg, None) };
        let mut val = || -> String { if let Some(v)=inline.clone(){v} else { i+=1; args.get(i).cloned().unwrap_or_default() } };
        match key.as_str() {
            "-h" | "--help" => o.help = true,
            "-v" | "--version" => o.version = true,
            "-all" => o.all = true,
            "-pass" => o.pass = true,
            "-skip" => o.skip = true,
            "-notests" => o.notests = true,
            "-smallscreen" => o.smallscreen = true,
            "-slow" => o.slow = val().parse().unwrap_or(0),
            "-sort" => o.sort = val(),
            "-nocolor" => o.nocolor = true,
            "-format" => o.format = val(),
            "-file" => o.file = Some(val()),
            "-follow" => o.follow = true,
            "-follow-output" => o.follow_output = Some(val()),
            "-include-timestamp" => o.include_timestamp = true,
            "-progress" => o.progress = true,
            "-compare" => o.compare = Some(val()),
            "-trimpath" => o.trimpath = Some(val()),
            x if x.starts_with('-') => { eprintln!("flag provided but not defined: {}", x); print!("{}", usage()); return Err(2); }
            _ => {}
        }
        i += 1;
    }
    if env::var_os("NO_COLOR").is_some() { o.nocolor = true; }
    Ok(o)
}

fn color(s: &str, code: &str, opts: &Opts) -> String { if opts.nocolor { s.to_string() } else { format!("\x1b[{}m{}\x1b[0m", code, s) } }
fn status_color(st: &str, opts: &Opts) -> String { match st { "PASS" => color(st,"92",opts), "FAIL" => color(st,"91",opts), "SKIP" => color(st,"93",opts), _ => st.to_string() } }
fn trim_pkg(s: &str, opts: &Opts) -> String { if let Some(p) = &opts.trimpath { s.strip_prefix(p).unwrap_or(s).to_string() } else { s.to_string() } }

fn extract_cover(out: &str) -> Option<String> {
    if let Some(i) = out.find("coverage:") {
        let rest = &out[i+9..];
        if let Some(p) = rest.find('%') { return Some(rest[..=p].trim().to_string()); }
    }
    None
}

fn read_events(opts: &Opts) -> io::Result<(Vec<Event>, bool)> {
    let input: Box<dyn Read> = match &opts.file { Some(p) => Box::new(File::open(p)?), None => Box::new(io::stdin()) };
    let mut reader = BufReader::new(input);
    let mut line = String::new();
    let mut events = Vec::new();
    let mut parsed_any = false;
    let mut follow_file: Option<File> = match &opts.follow_output { Some(p) => Some(File::create(p)?), None => None };
    loop {
        line.clear();
        let n = reader.read_line(&mut line)?;
        if n == 0 { break; }
        if line.trim().is_empty() { continue; }
        if let Ok(ev) = serde_json::from_str::<Event>(&line) {
            parsed_any = true;
            if opts.follow || follow_file.is_some() {
                let out = if opts.include_timestamp && !ev.time.is_empty() && !ev.output.is_empty() { format!("{} {}", ev.time, ev.output) } else { ev.output.clone() };
                if let Some(f) = follow_file.as_mut() { let _ = f.write_all(out.as_bytes()); }
                else if opts.follow { print!("{}", out); }
            }
            events.push(ev);
        }
    }
    Ok((events, parsed_any))
}

fn analyze(events: &[Event]) -> (Vec<TestRec>, Vec<PkgRec>) {
    let mut pkgs: BTreeMap<String, PkgRec> = BTreeMap::new();
    let mut tests: BTreeMap<(String,String), TestRec> = BTreeMap::new();
    for ev in events {
        if ev.package.is_empty() { continue; }
        pkgs.entry(ev.package.clone()).or_insert_with(|| PkgRec::new(&ev.package));
        let pkg = pkgs.get_mut(&ev.package).unwrap();
        if ev.action == "output" {
            if let Some(c) = extract_cover(&ev.output) { pkg.cover = Some(c); }
            if ev.output.contains("[no test files]") || ev.output.contains("[no tests to run]") {
                pkg.notest = true;
                pkg.notest_msg = if ev.output.contains("[no test files]") { "[no test files]".into() } else { "[no tests to run]".into() };
            }
            if ev.test.is_empty() { pkg.output.push_str(&ev.output); }
            else { tests.entry((ev.package.clone(), ev.test.clone())).or_insert(TestRec{package:ev.package.clone(),name:ev.test.clone(),status:String::new(),elapsed:0.0,output:String::new()}).output.push_str(&ev.output); }
        } else if ev.test.is_empty() {
            if matches!(ev.action.as_str(), "pass"|"fail"|"skip") {
                pkg.status = ev.action.to_uppercase(); pkg.elapsed = ev.elapsed; if ev.action == "skip" && pkg.notest { pkg.status = "NOTEST".into(); }
            }
        } else if matches!(ev.action.as_str(), "pass"|"fail"|"skip") {
            let tr = tests.entry((ev.package.clone(), ev.test.clone())).or_insert(TestRec{package:ev.package.clone(),name:ev.test.clone(),status:String::new(),elapsed:0.0,output:String::new()});
            tr.status = ev.action.to_uppercase(); tr.elapsed = ev.elapsed;
        }
    }
    for tr in tests.values() { if let Some(p) = pkgs.get_mut(&tr.package) { match tr.status.as_str() { "PASS" => p.pass += 1, "FAIL" => p.fail += 1, "SKIP" => p.skip += 1, _=>{} } } }
    let tv = tests.into_values().collect();
    let mut pv: Vec<PkgRec> = pkgs.into_values().collect();
    for p in &mut pv { if p.status.is_empty() { p.status = if p.fail > 0 {"FAIL"} else {"PASS"}.into(); } }
    (tv, pv)
}

fn cmp_float_desc(a: f64, b: f64) -> Ordering { b.partial_cmp(&a).unwrap_or(Ordering::Equal) }
fn status_rank(s: &str) -> i32 { match s { "PASS" => 0, "SKIP" => 1, "FAIL" => 2, _ => 3 } }
fn sort_tests(rows: &mut [TestRec], opts: &Opts) { match opts.sort.as_str() { "elapsed" => rows.sort_by(|a,b| cmp_float_desc(a.elapsed,b.elapsed)), _ => rows.sort_by(|a,b| status_rank(&a.status).cmp(&status_rank(&b.status)).then(a.name.cmp(&b.name)).then(a.package.cmp(&b.package))) } }
fn sort_pkgs(rows: &mut [PkgRec], opts: &Opts) { match opts.sort.as_str() { "elapsed" => rows.sort_by(|a,b| cmp_float_desc(a.elapsed,b.elapsed)), "cover" => rows.sort_by(|a,b| b.cover.cmp(&a.cover)), _ => rows.sort_by(|a,b| a.name.cmp(&b.name)) } }

fn center(s: &str, w: usize) -> String { let len = visible_len(s); if len >= w { return s.to_string(); } let l=(w-len)/2; let r=w-len-l; format!("{}{}{}", " ".repeat(l), s, " ".repeat(r)) }
fn visible_len(s: &str) -> usize { let mut n=0; let mut esc=false; for c in s.chars(){ if esc { if c=='m'{esc=false;} continue;} if c=='\x1b'{esc=true; continue;} n+=1;} n }
fn pad_vis(s: &str, w: usize) -> String { let len=visible_len(s); if len>=w {s.to_string()} else {format!("{}{}", s, " ".repeat(w-len))} }

fn basic_table(headers: &[&str], rows: &[Vec<String>], _opts: &Opts) {
    if rows.is_empty() { return; }
    let mut widths: Vec<usize> = headers.iter().map(|h| h.chars().count()).collect();
    for r in rows { for (i,c) in r.iter().enumerate() { for line in c.lines() { widths[i] = widths[i].max(visible_len(line)); } } }
    print_border(&widths, &["╭","┬","╮","─"]); print_row(headers.iter().map(|s| s.to_string()).collect(), &widths); print_border(&widths, &["├","┼","┤","─"]);
    for r in rows { print_row(r.clone(), &widths); }
    print_border(&widths, &["╰","┴","╯","─"]);
}
fn print_border(widths:&[usize], p:&[&str;4]) { print!("{}",p[0]); for (i,w) in widths.iter().enumerate(){ print!("{}", p[3].repeat(*w+2)); if i+1==widths.len(){println!("{}",p[2]);}else{print!("{}",p[1]);} } }
fn print_row(cols: Vec<String>, widths:&[usize]) {
    let split: Vec<Vec<&str>> = cols.iter().map(|c| if c.contains('\n') { c.lines().collect() } else { vec![c.as_str()] }).collect();
    let max = split.iter().map(|v| v.len()).max().unwrap_or(1);
    for line in 0..max { print!("│"); for (i,parts) in split.iter().enumerate(){ let c = parts.get(line).copied().unwrap_or(""); let s=center(c,widths[i]); print!(" {} │", pad_vis(&s,widths[i])); } println!(); }
}

fn plain_table(headers: &[&str], rows: &[Vec<String>]) {
    if rows.is_empty(){return;} let mut widths:Vec<usize>=headers.iter().map(|h|h.len()).collect(); for r in rows{for(i,c)in r.iter().enumerate(){for line in c.lines(){widths[i]=widths[i].max(visible_len(line));}}}
    for (i,h) in headers.iter().enumerate(){print!(" {} ", center(h,widths[i]+2));} println!("\n{}", " ".repeat(widths.iter().sum::<usize>()+headers.len()*4));
    for r in rows{ for(i,c)in r.iter().enumerate(){let c=c.lines().next().unwrap_or(""); print!(" {} ", center(c,widths[i]+2));} println!(); }
}
fn markdown_table(headers:&[&str], rows:&[Vec<String>]) { if rows.is_empty(){return;} println!("| {} |", headers.join(" | ")); println!("|{}|", headers.iter().map(|h| "-".repeat(h.len().max(3)+2)).collect::<Vec<_>>().join("|")); for r in rows{println!("| {} |", r.join(" | "));} }

fn test_rows(tests:&[TestRec], pkgs:&[PkgRec], opts:&Opts) -> Vec<Vec<String>> {
    let mut rows:Vec<TestRec>=tests.iter().filter(|t| t.status=="FAIL" || opts.all || (opts.pass&&t.status=="PASS") || (opts.skip&&t.status=="SKIP")).cloned().collect();
    sort_tests(&mut rows, opts); if opts.slow>0 && rows.len()>opts.slow { rows.truncate(opts.slow); }
    let mut out:Vec<Vec<String>>=rows.into_iter().map(|t| vec![status_color(&t.status,opts), format!("{:.2}",t.elapsed), t.name, trim_pkg(&t.package,opts)]).collect();
    for p in pkgs { if p.notest && (opts.all || opts.notests) { out.push(vec!["".into(),"".into(),"".into(),"".into()]); } }
    out
}
fn pkg_rows(pkgs:&[PkgRec], opts:&Opts) -> Vec<Vec<String>> {
    let mut rows:Vec<PkgRec>=pkgs.iter().filter(|p| !p.notest || opts.notests).cloned().collect(); sort_pkgs(&mut rows, opts);
    rows.into_iter().map(|p| { if p.notest { vec!["NOTEST".into(), format!("{:.2}s",p.elapsed), format!("{}\n{}", trim_pkg(&p.name,opts), p.notest_msg), "--".into(), "--".into(), "--".into(), "--".into()] } else { vec![status_color(&p.status,opts), format!("{:.2}s",p.elapsed), trim_pkg(&p.name,opts), p.cover.unwrap_or_else(||"--".into()), p.pass.to_string(), p.fail.to_string(), p.skip.to_string()] } }).collect()
}

fn print_tests(tests:&[TestRec], pkgs:&[PkgRec], opts:&Opts) { let rows=test_rows(tests,pkgs,opts); if rows.is_empty(){return;} match opts.format.as_str(){ "plain"=>plain_table(&["Status","Elapsed","Test","Package"],&rows), "markdown"=>{}, _=>basic_table(&["Status","Elapsed","Test","Package"],&rows,opts)} }
fn print_pkg_summary(pkgs:&[PkgRec], opts:&Opts) { let rows=pkg_rows(pkgs,opts); if rows.is_empty(){return;} match opts.format.as_str(){ "plain"=>plain_table(&["Status","Elapsed","Package","Cover","Pass","Fail","Skip"],&rows), "markdown"=>markdown_table(&["Status","Elapsed","Package","Cover","Pass","Fail","Skip"],&rows), _=>basic_table(&["Status","Elapsed","Package","Cover","Pass","Fail","Skip"],&rows,opts)} }

fn print_banner(pkg:&PkgRec, opts:&Opts) {
    if opts.format=="markdown" { println!("## {} • {}\n", pkg.status, pkg.name); return; }
    let text=format!("   {}  package: {}   ", status_color(&pkg.status,opts), pkg.name); let width=visible_len(&text); let line="━".repeat(width);
    println!("{}{}{}", color("┏","38;5;103",opts), color(&line,"38;5;103",opts), color("┓","38;5;103",opts));
    println!("{}{}{}", color("┃","38;5;103",opts), text, color("┃","38;5;103",opts));
    println!("{}{}{}", color("┗","38;5;103",opts), color(&line,"38;5;103",opts), color("┛","38;5;103",opts));
}
fn print_failures(pkgs:&[PkgRec], tests:&[TestRec], opts:&Opts) {
    for p in pkgs.iter().filter(|p| p.fail>0 || p.status=="FAIL") {
        print_banner(p,opts);
        if opts.format=="markdown" { println!("```"); }
        println!();
        let mut body=String::new();
        for line in p.output.lines() {
            if !line.contains("coverage:") && !line.contains("[no test files]") && !line.contains("[no tests to run]") { body.push_str(line); body.push('\n'); }
        }
        for t in tests.iter().filter(|t| t.package==p.name && t.status=="FAIL") {
            for line in t.output.lines() {
                if !line.starts_with("=== RUN") { body.push_str(line); body.push('\n'); }
            }
        }
        print!("{}", body);
        if opts.format=="markdown" { println!("\n```"); }
    }
}

fn print_markdown_tests(tests:&[TestRec], pkgs:&[PkgRec], opts:&Opts) {
    let mut by_pkg:BTreeMap<String,Vec<TestRec>>=BTreeMap::new(); for t in tests { if t.status=="FAIL"||opts.all||(opts.pass&&t.status=="PASS")||(opts.skip&&t.status=="SKIP"){by_pkg.entry(t.package.clone()).or_default().push(t.clone());} }
    for p in pkgs { if let Some(mut ts)=by_pkg.remove(&p.name){ sort_tests(&mut ts,opts); println!("## 📦 Package **`{}`**\n", p.name); println!("Tests: ✓ {} passed | {} skipped | {} failed\n", p.pass,p.skip,p.fail); println!("<details>\n\n<summary>Click for test summary</summary>\n"); let rows=ts.into_iter().map(|t|vec![format!("  {}  ",t.status),format!(" {:.2}  ",t.elapsed),t.name]).collect::<Vec<_>>(); markdown_table(&["Status","Elapsed","Test"],&rows); println!("</details>\n"); } }
}

fn main() {
    let opts = match parse_args(){Ok(o)=>o,Err(c)=>process::exit(c)};
    if opts.help { print!("{}", usage()); return; }
    if opts.version { println!("tparse version: (devel)"); return; }
    let (events, any) = match read_events(&opts){Ok(x)=>x,Err(e)=>{eprintln!("{}", e); process::exit(1)}};
    if !any { eprintln!("no parsable events: Make sure to run go test with -json flag"); process::exit(1); }
    let (tests, pkgs) = analyze(&events);
    if opts.progress { for p in &pkgs { if !p.notest || opts.notests { println!("[{}]\t{:>9.2}s\t{}", p.status, p.elapsed, trim_pkg(&p.name,&opts)); } } }
    if opts.format=="markdown" { print_markdown_tests(&tests,&pkgs,&opts); } else { print_tests(&tests,&pkgs,&opts); }
    print_failures(&pkgs,&tests,&opts);
    println!();
    print_pkg_summary(&pkgs,&opts);
    if pkgs.iter().any(|p| p.status=="FAIL") { process::exit(1); }
}
