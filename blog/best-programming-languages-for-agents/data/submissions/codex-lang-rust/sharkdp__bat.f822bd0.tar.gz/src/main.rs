use std::env;
use std::fs;
use std::io::{self, Read};
use std::process;

const VERSION: &str = "bat 0.26.1 (610b77c)";
const SHORT_HELP: &str = r#"A cat(1) clone with wings.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...  File(s) to print / concatenate. Use '-' for standard input.

Options:
  -A, --show-all
          Show non-printable characters (space, tab, newline, ..).
      --nonprintable-notation <notation>
          Set notation for non-printable characters.
      --binary <behavior>
          How to treat binary content. (default: no-printing)
  -p, --plain...
          Show plain style (alias for '--style=plain').
  -l, --language <language>
          Set the language for syntax highlighting.
      --fallback-syntax <fallback-syntax>
          Set a fallback language for undetected syntaxes. [aliases: --fallback-language]
  -H, --highlight-line <N:M>
          Highlight lines N through M.
      --file-name <name>
          Specify the name to display for a file.
  -d, --diff
          Only show lines that have been added/removed/modified.
      --tabs <T>
          Set the tab width to T spaces.
      --wrap <mode>
          Specify the text-wrapping mode (*auto*, never, character, word).
  -S, --chop-long-lines
          Truncate all lines longer than screen width. Alias for '--wrap=never'.
  -n, --number
          Show line numbers (alias for '--style=numbers').
      --color <when>
          When to use colors (*auto*, never, always).
      --italic-text <when>
          Use italics in output (always, *never*)
      --decorations <when>
          When to show the decorations (*auto*, never, always).
      --paging <when>
          Specify when to use the pager, or use `-P` to disable (*auto*, never, always).
  -m, --map-syntax <glob:syntax>
          Use the specified syntax for files matching the glob pattern ('*.cpp:C++').
      --theme <theme>
          Set the color theme for syntax highlighting.
      --theme-light <theme>
          Sets the color theme for syntax highlighting used for light backgrounds.
      --theme-dark <theme>
          Sets the color theme for syntax highlighting used for dark backgrounds.
      --list-themes
          Display all supported highlighting themes.
  -s, --squeeze-blank
          Squeeze consecutive empty lines.
      --style <components>
          Comma-separated list of style elements to display (*default*, auto, full, plain, changes,
          header, header-filename, header-filesize, grid, rule, numbers, snip).
  -r, --line-range <N:M>
          Only print the lines from N to M.
  -L, --list-languages
          Display all supported languages.
  -u, --unbuffered
          Enable unbuffered input reading for streaming use cases.
      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]
  -E, --quiet-empty
          Produce no output when the input is empty.
  -h, --help
          Print help (see more with '--help')
  -V, --version
          Print version
"#;

const LONG_HELP: &str = r#"A cat(1) clone with syntax highlighting and Git integration.

Usage: bat [OPTIONS] [FILE]...
       bat <COMMAND>

Arguments:
  [FILE]...
          File(s) to print / concatenate. Use a dash ('-') or no argument at all to read from
          standard input.

Options:
  -A, --show-all
          Show non-printable characters like space, tab or newline. This option can also be used to
          print binary files. Use '--tabs' to control the width of the tab-placeholders.

      --nonprintable-notation <notation>
          Set notation for non-printable characters.
          
          Possible values:
            * unicode (␇, ␊, ␀, ..)
            * caret   (^G, ^J, ^@, ..)

      --binary <behavior>
          How to treat binary content. (default: no-printing)
          
          Possible values:
            * no-printing: do not print any binary content
            * as-text: treat binary content as normal text

  -p, --plain...
          Only show plain style, no decorations. This is an alias for '--style=plain'. When '-p' is
          used twice ('-pp'), it also disables automatic paging (alias for '--style=plain
          --paging=never').

  -l, --language <language>
          Explicitly set the language for syntax highlighting.

      --fallback-syntax <fallback-syntax>
          Set a fallback language for syntax highlighting when auto-detection fails.

  -H, --highlight-line <N:M>
          Highlight the specified line ranges with a different background color

      --file-name <name>
          Specify the name to display for a file.

  -d, --diff
          Only show lines that have been added/removed/modified with respect to the Git index.

      --diff-context <N>
          Include N lines of context around added/removed/modified lines when using '--diff'.

      --tabs <T>
          Set the tab width to T spaces. Use a width of 0 to pass tabs through directly

      --wrap <mode>
          Specify the text-wrapping mode (*auto*, never, character, word).

  -S, --chop-long-lines
          Truncate all lines longer than screen width. Alias for '--wrap=never'.

      --terminal-width <width>
          Explicitly set the width of the terminal instead of determining it automatically.

  -n, --number
          Only show line numbers, no other decorations. This is an alias for '--style=numbers'

      --color <when>
          Specify when to use colored output. Possible values: *auto*, never, always.

      --italic-text <when>
          Specify when to use ANSI sequences for italic text in the output.

      --decorations <when>
          Specify when to use the decorations that have been specified via '--style'.

  -f, --force-colorization
          Alias for '--decorations=always --color=always'.

      --paging <when>
          Specify when to use the pager. Possible values: *auto*, never, always.

      --pager <command>
          Determine which pager is used.

  -m, --map-syntax <glob:syntax>
          Map a glob pattern to an existing syntax name.

      --ignored-suffix <ignored-suffix>
          Ignore extension.

      --theme <theme>
          Set the theme for syntax highlighting. Use '--list-themes' to see all available themes.

      --theme-light <theme>
          Sets the theme name for syntax highlighting used when the terminal uses a light
          background.

      --theme-dark <theme>
          Sets the theme name for syntax highlighting used when the terminal uses a dark background.

      --list-themes
          Display a list of supported themes for syntax highlighting.

  -s, --squeeze-blank
          Squeeze consecutive empty lines into a single empty line.

      --squeeze-limit <squeeze-limit>
          Set the maximum number of consecutive empty lines to be printed.

      --strip-ansi <when>
          Specify when to strip ANSI escape sequences from the input.

      --style <components>
          Configure which elements (line numbers, file headers, grid borders, Git modifications, ..)
          to display in addition to the file contents.

  -r, --line-range <N:M>
          Only print the specified range of lines for each file.

  -L, --list-languages
          Display a list of supported languages for syntax highlighting.

  -u, --unbuffered
          Enable unbuffered input reading.

      --completion <SHELL>
          Show shell completion for a certain shell. [possible values: bash, fish, zsh, ps1]

      --diagnostic
          Show diagnostic information for bug reports.

  -E, --quiet-empty
          When this flag is set, bat will produce no output at all when the input is empty.

      --acknowledgements
          Show acknowledgements.

      --set-terminal-title
          Sets terminal title to filenames when using a pager.

  -h, --help
          Print help (see a summary with '-h')

  -V, --version
          Print version

You can use 'bat cache' to customize syntaxes and themes. See 'bat cache --help' for more
information
"#;

const THEMES: &[&str] = &[
    "1337", "Catppuccin Frappe", "Catppuccin Latte", "Catppuccin Macchiato",
    "Catppuccin Mocha", "Coldark-Cold", "Coldark-Dark", "DarkNeon", "Dracula",
    "GitHub", "Monokai Extended", "Monokai Extended Bright", "Monokai Extended Light",
    "Monokai Extended Origin", "Nord", "OneHalfDark", "OneHalfLight",
    "Solarized (dark)", "Solarized (light)", "Sublime Snazzy", "TwoDark",
    "Visual Studio Dark+", "ansi", "base16", "base16-256", "gruvbox-dark",
    "gruvbox-light", "zenburn",
];

const LANGUAGES: &[&str] = &[
    "ActionScript:as", "Ada:adb,ads,gpr", "Apache Conf:envvars,htaccess,HTACCESS,httpd.conf",
    "AppleScript:applescript,script editor", "ARM Assembly:s,S",
    "AsciiDoc (Asciidoctor):adoc,ad,asciidoc", "ASP:asa", "AWK:awk",
    "Batch File:bat,cmd", "BibTeX:bib", "Bourne Again Shell (bash):sh,bash,zsh,ash,.bashrc,.profile",
    "C:c", "C#:cs,csx", "C++:cpp,cc,cp,cxx,c++,h,hh,hpp,hxx,h++,inl,ipp,*.h",
    "Cabal:cabal", "Clojure:clj,cljc,cljs,edn", "CMake:CMakeLists.txt,cmake",
    "CoffeeScript:coffee,Cakefile", "Command Help:cmd-help,help", "Crystal:cr",
    "CSS:css", "D:d,di", "Dart:dart", "Diff:diff,patch,*.debdiff",
    "Dockerfile:Dockerfile,dockerfile,.Dockerfile,Containerfile", "DotENV:.env,.env.example,.envrc",
    "Elixir:ex,exs", "Elm:elm", "Erlang:erl,hrl", "F#:fs,fsi,fsx,*.fs",
    "Fish:fish", "Fortran (Fixed Form):f,F,f77,F77,for,FOR", "Fortran (Modern):f90,F90,f95,F95",
    "Git Attributes:attributes,gitattributes,.gitattributes", "Git Config:gitconfig,.gitconfig,.gitmodules",
    "Git Ignore:exclude,gitignore,.gitignore,.gcloudignore", "Git Log:gitlog",
    "Go:go", "Gomod:go.mod,go.work", "Gosum:go.sum", "GraphQL:graphql,graphqls,gql",
    "Graphviz (DOT):dot,DOT,gv", "Groff/troff:groff,troff,1,2,3,4,5,6,7,8,9",
    "Haskell:hs", "HTML:html,htm,shtml,xhtml", "INI:ini,INF,reg,cfg,desktop,url",
    "Java:java,bsh", "JavaScript:js,jsx,es6,mjs,cjs", "JSON:json,sublime-settings",
    "Julia:jl", "Kotlin:kt,kts", "LaTeX:tex,ltx", "Less:less", "Lisp:lisp,cl,clisp,lsp",
    "Lua:lua", "Makefile:Makefile,makefile,GNUmakefile,make", "Markdown:md,mdown,markdown,mkd",
    "Nim:nim", "Nix:nix", "Objective-C:m,h", "OCaml:ml,mli", "Org:org",
    "Pascal:pas,p,pp", "Perl:pl,pm,pod,t,PL", "PHP:php,php3,php4,php5,phtml",
    "Plain Text:txt", "PowerShell:ps1,psm1,psd1", "Protocol Buffer:proto",
    "Python:py,py3,pyw,pyi,SConstruct,SConscript", "R:r,R,Rprofile", "Ruby:rb,rbw,rake,gemspec",
    "Rust:rs", "Scala:scala,sbt", "SCSS:scss", "SQL:sql,ddl,dml", "Swift:swift",
    "TOML:toml,Cargo.lock", "TypeScript:ts,tsx", "VimL:vim", "XML:xml,xsd,svg",
    "YAML:yml,yaml",
];

#[derive(Default)]
struct Opt {
    files: Vec<String>,
    number: bool,
    show_all: bool,
    squeeze: bool,
    squeeze_limit: Option<usize>,
    quiet_empty: bool,
    line_ranges: Vec<String>,
    tabs: usize,
    notation: String,
    decorations_always: bool,
    style_numbers: bool,
    style_header: bool,
    style_grid: bool,
    force_color: bool,
    color_always: bool,
    plain: bool,
}

#[derive(Clone)]
struct Line {
    number: usize,
    text: String,
    newline: bool,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.first().map(|s| s == "cache").unwrap_or(false) {
        println!("Modify the syntax-definition and theme cache\n\nUsage: executable cache [OPTIONS]\n\nOptions:\n  -h, --help  Print help\n  -V, --version  Print version");
        return;
    }
    if args.first().map(|s| s == "config").unwrap_or(false) {
        print!("{}", LONG_HELP);
        return;
    }

    let mut opt = Opt { tabs: 4, notation: "unicode".to_string(), ..Opt::default() };
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if a == "--" {
            opt.files.extend(args[i + 1..].iter().cloned());
            break;
        } else if a == "-h" {
            print!("{}", SHORT_HELP);
            return;
        } else if a == "--help" {
            print!("{}", LONG_HELP);
            return;
        } else if a == "-V" || a == "--version" {
            println!("{}", VERSION);
            return;
        } else if a == "--list-themes" {
            for t in THEMES { println!("{}", t); }
            return;
        } else if a == "-L" || a == "--list-languages" {
            for l in LANGUAGES { println!("{}", l); }
            return;
        } else if a == "--acknowledgements" {
            print_acknowledgements();
            return;
        } else if a == "--diagnostic" {
            print_diagnostic();
            return;
        } else if a == "--completion" {
            let shell = take_value(&args, &mut i, "--completion");
            print_completion(&shell);
            return;
        } else if let Some(v) = a.strip_prefix("--completion=") {
            print_completion(v);
            return;
        } else if a == "-A" || a == "--show-all" {
            opt.show_all = true;
        } else if a == "-n" || a == "--number" {
            opt.number = true;
        } else if a == "-s" || a == "--squeeze-blank" {
            opt.squeeze = true;
        } else if a == "-E" || a == "--quiet-empty" {
            opt.quiet_empty = true;
        } else if a == "-p" || a == "--plain" {
            opt.plain = true;
        } else if a == "-pp" {
            opt.plain = true;
        } else if a == "-f" || a == "--force-colorization" {
            opt.force_color = true;
            opt.color_always = true;
            opt.decorations_always = true;
        } else if a == "-P" || a == "--chop-long-lines" || a == "-S" || a == "-d" || a == "-u" || a == "--set-terminal-title" {
        } else if a == "-r" || a == "--line-range" {
            opt.line_ranges.push(take_value(&args, &mut i, &a));
        } else if let Some(v) = a.strip_prefix("--line-range=") {
            opt.line_ranges.push(v.to_string());
        } else if a == "--tabs" {
            opt.tabs = take_value(&args, &mut i, "--tabs").parse().unwrap_or(4);
        } else if let Some(v) = a.strip_prefix("--tabs=") {
            opt.tabs = v.parse().unwrap_or(4);
        } else if a == "--squeeze-limit" {
            opt.squeeze_limit = take_value(&args, &mut i, "--squeeze-limit").parse().ok();
        } else if let Some(v) = a.strip_prefix("--squeeze-limit=") {
            opt.squeeze_limit = v.parse().ok();
        } else if a == "--nonprintable-notation" {
            opt.notation = take_value(&args, &mut i, "--nonprintable-notation");
        } else if let Some(v) = a.strip_prefix("--nonprintable-notation=") {
            opt.notation = v.to_string();
        } else if a == "--style" {
            apply_style(&mut opt, &take_value(&args, &mut i, "--style"));
        } else if let Some(v) = a.strip_prefix("--style=") {
            apply_style(&mut opt, v);
        } else if a == "--decorations" {
            let v = take_value(&args, &mut i, "--decorations");
            opt.decorations_always = v == "always";
        } else if let Some(v) = a.strip_prefix("--decorations=") {
            opt.decorations_always = v == "always";
        } else if a == "--color" {
            let v = take_value(&args, &mut i, "--color");
            validate_when("--color", &v);
            opt.color_always = v == "always";
        } else if let Some(v) = a.strip_prefix("--color=") {
            validate_when("--color", v);
            opt.color_always = v == "always";
        } else if takes_ignored_value(&a) {
            if !a.contains('=') { i += 1; }
        } else if a.starts_with("--") {
            eprintln!("error: unexpected argument '{}' found\n\n  tip: to pass '{}' as a value, use '-- {}'\n\nUsage: executable [OPTIONS] [FILE]...\n\nFor more information, try '--help'.", a, a, a);
            process::exit(2);
        } else if a.starts_with('-') && a.len() > 2 {
            for c in a[1..].chars() {
                match c {
                    'A' => opt.show_all = true,
                    'n' => opt.number = true,
                    's' => opt.squeeze = true,
                    'p' => opt.plain = true,
                    'P' => {},
                    'L' => { for l in LANGUAGES { println!("{}", l); } return; },
                    'V' => { println!("{}", VERSION); return; },
                    'h' => { print!("{}", SHORT_HELP); return; },
                    _ => opt.files.push(format!("-{}", c)),
                }
            }
        } else {
            opt.files.push(a);
        }
        i += 1;
    }

    if opt.files.is_empty() {
        opt.files.push("-".to_string());
    }
    if opt.squeeze_limit.is_some() {
        opt.squeeze = true;
    }
    let code = run(opt);
    process::exit(code);
}

fn take_value(args: &[String], i: &mut usize, name: &str) -> String {
    *i += 1;
    if *i >= args.len() {
        eprintln!("error: a value is required for '{}' but none was supplied", name);
        process::exit(2);
    }
    args[*i].clone()
}

fn takes_ignored_value(a: &str) -> bool {
    let names = [
        "-l", "--language", "--fallback-syntax", "--fallback-language", "-H", "--highlight-line",
        "--file-name", "--diff-context", "--wrap", "--terminal-width", "--italic-text",
        "--paging", "--pager", "-m", "--map-syntax", "--ignored-suffix", "--theme",
        "--theme-light", "--theme-dark", "--strip-ansi", "--binary",
    ];
    names.iter().any(|n| a == *n || a.starts_with(&format!("{}=", n)))
}

fn validate_when(name: &str, v: &str) {
    if !matches!(v, "auto" | "never" | "always") {
        eprintln!("error: invalid value '{}' for '{} <when>'\n  [possible values: auto, never, always]", v, name);
        process::exit(2);
    }
}

fn apply_style(opt: &mut Opt, style: &str) {
    if style == "plain" {
        opt.plain = true;
        opt.style_numbers = false;
        opt.style_header = false;
        opt.style_grid = false;
        return;
    }
    for part in style.split(',') {
        match part {
            "numbers" => opt.style_numbers = true,
            "header" | "header-filename" => opt.style_header = true,
            "grid" => opt.style_grid = true,
            "full" => {
                opt.style_numbers = true;
                opt.style_header = true;
                opt.style_grid = true;
            }
            "default" => {
                opt.style_numbers = true;
                opt.style_header = true;
                opt.style_grid = true;
            }
            _ => {}
        }
    }
}

fn run(opt: Opt) -> i32 {
    let mut status = 0;
    for (idx, file) in opt.files.iter().enumerate() {
        if file != "-" {
            if let Ok(meta) = fs::metadata(file) {
                if meta.is_dir() {
                    eprintln!("\x1b[31m[bat error]\x1b[0m: '{}' is a directory.", file);
                    status = 1;
                    continue;
                }
            }
        }
        let data = if file == "-" {
            let mut buf = Vec::new();
            if let Err(e) = io::stdin().read_to_end(&mut buf) {
                print_error("-", &e.to_string());
                status = 1;
                continue;
            }
            buf
        } else {
            match fs::read(file) {
                Ok(d) => d,
                Err(e) => {
                    print_error(file, &e.to_string());
                    status = 1;
                    continue;
                }
            }
        };
        if opt.quiet_empty && data.is_empty() {
            continue;
        }
        let text = String::from_utf8_lossy(&data).to_string();
        if idx > 0 && (opt.decorations_always && opt.style_header) {
            println!();
        }
        print_content(&opt, file, &text);
    }
    status
}

fn print_content(opt: &Opt, file: &str, text: &str) {
    let mut lines = split_lines(text);
    if !opt.line_ranges.is_empty() {
        let total = lines.len();
        let mut selected = Vec::new();
        for r in &opt.line_ranges {
            match parse_range(r, total) {
                Ok((start, end)) => {
                    for line in &lines {
                        if line.number >= start && line.number <= end {
                            selected.push(line.clone());
                        }
                    }
                }
                Err(e) => {
                    print_bat_error(&e);
                    process::exit(1);
                }
            }
        }
        lines = selected;
    }
    if opt.squeeze {
        let limit = opt.squeeze_limit.unwrap_or(0);
        let mut out = Vec::new();
        let mut blanks = 0usize;
        for item in lines {
            if item.text.is_empty() {
                if blanks <= limit {
                    out.push(item);
                }
                blanks += 1;
            } else {
                blanks = 0;
                out.push(item);
            }
        }
        lines = out;
    }

    let decorated = opt.decorations_always && !opt.plain;
    if decorated && opt.style_header && file != "-" {
        if opt.style_grid {
            println!("{}", "─".repeat(80));
            println!("     │ File: {}", file);
            if let Ok(meta) = fs::metadata(file) {
                println!("     │ Size: {} B", meta.len());
            }
            println!("{}", "─".repeat(5) + "┼" + &"─".repeat(74));
        } else {
            println!("File: {}", file);
        }
    } else if decorated && opt.style_grid {
        println!("{}", "─".repeat(80));
    }

    let number = opt.number || (decorated && opt.style_numbers);
    for line_item in lines {
        let n = line_item.number;
        let had_newline = line_item.newline;
        let mut line = line_item.text;
        if opt.show_all {
            line = show_nonprintables(&line, opt.tabs, &opt.notation, had_newline);
        }
        if opt.force_color && opt.color_always && number {
            println!("\x1b[38;5;246m{:>4}\x1b[0m \x1b[38;5;231m{}\x1b[0m", n, line);
        } else if number && decorated && opt.style_grid {
            println!("{:>4} │ {}", n, line);
        } else if number {
            println!("{:>4} {}", n, line);
        } else if had_newline {
            println!("{}", line);
        } else {
            print!("{}", line);
        }
    }
    if decorated && opt.style_grid {
        println!("{}", "─".repeat(80));
    }
}

fn split_lines(text: &str) -> Vec<Line> {
    if text.is_empty() {
        return Vec::new();
    }
    let mut s = text.replace("\r\n", "\n");
    let had_final = s.ends_with('\n');
    if had_final {
        s.pop();
    }
    let parts: Vec<&str> = s.split('\n').collect();
    let len = parts.len();
    parts
        .into_iter()
        .enumerate()
        .map(|(i, x)| Line {
            number: i + 1,
            text: x.to_string(),
            newline: had_final || i + 1 < len,
        })
        .collect()
}

fn parse_range(spec: &str, total: usize) -> Result<(usize, usize), String> {
    if spec == ":" {
        return Err("cannot parse integer from empty string".to_string());
    }
    if !spec.contains(':') {
        let n: isize = spec.parse().map_err(|e| format!("{}", e))?;
        let n = if n <= 0 { 1 } else { n as usize };
        return Ok((n, n));
    }
    let parts: Vec<&str> = spec.split(':').collect();
    if parts.len() == 3 && parts[1].is_empty() {
        let center: isize = parts[0].parse().map_err(|e| format!("{}", e))?;
        let ctx: isize = parts[2].parse().map_err(|e| format!("{}", e))?;
        let start = (center - ctx).max(1) as usize;
        let end = (center + ctx).max(0) as usize;
        return Ok((start, end));
    }
    let ctx = if parts.len() >= 3 {
        parts[2].parse::<isize>().unwrap_or(0)
    } else { 0 };
    let mut start = if parts[0].is_empty() {
        1
    } else {
        let v: isize = parts[0].parse().map_err(|e| format!("{}", e))?;
        if v < 0 {
            (total as isize + v + 1).max(1) as usize
        } else {
            v.max(1) as usize
        }
    };
    let mut end = if parts.len() < 2 || parts[1].is_empty() {
        total
    } else if let Some(rest) = parts[1].strip_prefix('+') {
        let plus: usize = rest.parse().map_err(|e| format!("{}", e))?;
        start + plus
    } else {
        let v: isize = parts[1].parse().map_err(|e| format!("{}", e))?;
        if v < 0 { 0 } else { v as usize }
    };
    if ctx > 0 {
        start = start.saturating_sub(ctx as usize).max(1);
        end += ctx as usize;
    }
    Ok((start, end))
}

fn show_nonprintables(line: &str, tabs: usize, notation: &str, had_newline: bool) -> String {
    let mut out = String::new();
    for ch in line.chars() {
        match ch {
            '\t' => {
                if notation == "caret" {
                    out.push_str("^I");
                } else if tabs == 0 {
                    out.push_str("├─┤");
                } else if tabs <= 2 {
                    out.push('↹');
                } else {
                    out.push('├');
                    for _ in 0..tabs.saturating_sub(3) {
                        out.push('─');
                    }
                    out.push('┤');
                }
            }
            ' ' => {
                if notation == "caret" { out.push(' '); } else { out.push('·'); }
            }
            c if c.is_control() => {
                if notation == "caret" {
                    out.push('^');
                    out.push(((c as u8) ^ 0x40) as char);
                } else {
                    out.push('␀');
                }
            }
            c => out.push(c),
        }
    }
    if had_newline {
        if notation == "caret" {
            out.push_str("$");
        } else {
            out.push('␊');
        }
    }
    out
}

fn print_error(file: &str, msg: &str) {
    eprintln!("\x1b[31m[bat error]\x1b[0m: '{}': {}", file, msg);
}

fn print_bat_error(msg: &str) {
    eprintln!("\x1b[31m[bat error]\x1b[0m: {}", msg);
}

fn print_acknowledgements() {
    println!("Copyright (c) 2018-2021 bat-developers (https://github.com/sharkdp/bat).\n\nbat is made available under the terms of either the MIT License or the Apache\nLicense 2.0, at your option.\n\nThis build includes syntax definitions, themes, and open source dependencies.");
}

fn print_diagnostic() {
    println!("#### Software version\n\n{}\n\n#### Operating system\n\n{}\n\n#### Command-line\n\n{:?}", VERSION, env::consts::OS, env::args().collect::<Vec<_>>());
}

fn print_completion(shell: &str) {
    match shell {
        "bash" => println!("# shellcheck disable=SC2207\n\n_bat() {{\n    COMPREPLY=()\n}}\ncomplete -F _bat bat executable"),
        "fish" => println!("complete -c bat -s h -l help -d 'Print help'\ncomplete -c bat -s V -l version -d 'Print version'"),
        "zsh" => println!("#compdef bat\n_arguments '*:file:_files'"),
        "ps1" => println!("Register-ArgumentCompleter -Native -CommandName bat -ScriptBlock {{ }}"),
        _ => {
            eprintln!("error: invalid value '{}' for '--completion <SHELL>'\n  [possible values: bash, fish, zsh, ps1]", shell);
            process::exit(2);
        }
    }
}
