use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process;
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "3.0.0-20260303205914-9926ea38658f";
const HELP: &str = "Usage of ./executable:\n  -apply-to-generated-files\n    \tApply imports sorting and formatting(if the option is set) to generated files. Generated file is a file with first comment which starts with comment '// Code generated'. Optional parameter.\n  -company-prefixes string\n    \tCompany package prefixes which will be placed after 3rd-party group by default(if defined). Values should be comma-separated. Optional parameters.\n  -excludes string\n    \tExclude files or dirs, example: '.git/,proto/*.go'.\n  -file-path string\n    \tDeprecated. Put file name as an argument(last item) of command line.\n  -format\n    \tOption will perform additional formatting. Optional parameter.\n  -imports-order string\n    \tYour imports groups can be sorted in your way. \n    \tstd - std import group; \n    \tgeneral - libs for general purpose; \n    \tcompany - inter-org or your company libs(if you set '-company-prefixes'-option, then 4th group will be split separately. In other case, it will be the part of general purpose libs); \n    \tproject - your local project dependencies;\n    \tblanked - imports with \"_\" alias;\n    \tdotted - imports with \".\" alias.\n    \tOptional parameter. (default \"std,general,company,project\")\n  -list-diff\n    \tOption will list files whose formatting differs from goimports-reviser. Optional parameter.\n  -local string\n    \tDeprecated\n  -output string\n    \tCan be \"file\", \"write\" or \"stdout\". Whether to write the formatted content back to the file or to stdout. When \"write\" together with \"-list-diff\" will list the file name and write back to the file. Optional parameter. (default \"file\")\n  -project-name string\n    \tYour project name(ex.: github.com/incu6us/goimports-reviser). Optional parameter.\n  -recursive\n    \tApply rules recursively if target is a directory. In case of ./... execution will be recursively applied by default. Optional parameter.\n  -rm-unused\n    \tRemove unused imports. Optional parameter.\n  -separate-named\n    \tOption will separate named imports from the rest of the imports, per group. Optional parameter.\n  -set-alias\n    \tSet alias for versioned package names, like 'github.com/go-pg/pg/v9'. In this case import will be set as 'pg \"github.com/go-pg/pg/v9\"'. Optional parameter.\n  -set-exit-status\n    \tset the exit status to 1 if a change is needed/made. Optional parameter.\n  -use-cache\n    \tUse cache to improve performance. Optional parameter.\n  -version\n    \tShow version information\n  -version-only\n    \tShow only the version string\n";

#[derive(Clone)]
struct Opts {
    apply_generated: bool,
    company_prefixes: Vec<String>,
    excludes: Vec<String>,
    file_path: Option<String>,
    imports_order: Vec<String>,
    list_diff: bool,
    output: String,
    project_name: Option<String>,
    recursive: bool,
    rm_unused: bool,
    separate_named: bool,
    set_alias: bool,
    set_exit_status: bool,
    paths: Vec<String>,
}

#[derive(Clone, Debug)]
struct ImportSpec {
    alias: Option<String>,
    path: String,
    comment: String,
}

fn main() {
    let opts = match parse_args() {
        Ok(Some(o)) => o,
        Ok(None) => return,
        Err((msg, code)) => {
            eprintln!("{}", msg);
            eprint!("{}", HELP);
            process::exit(code);
        }
    };

    let mut paths = opts.paths.clone();
    if let Some(fp) = &opts.file_path { paths.push(fp.clone()); }
    if paths.is_empty() {
        print!("{}", HELP);
        log_err("no file(s) or directory(ies) specified on input");
        process::exit(1);
    }
    log_err(&format!("Paths: [{}]", paths.join(" ")));

    let files = match collect_files(&paths, &opts) {
        Ok(f) => f,
        Err(e) => { log_err(&e); process::exit(1); }
    };
    let mut changed_any = false;
    for file in files {
        log_err(&format!("Processing {}", file.display()));
        let project = match opts.project_name.clone().or_else(|| find_module_name(&file)) {
            Some(p) => p,
            None => {
                print!("{}", HELP);
                log_err(&format!("Could not determine project name for path {}: open go.mod: no such file or directory", file.display()));
                process::exit(1);
            }
        };
        let original = match fs::read_to_string(&file) {
            Ok(s) => s,
            Err(e) => { log_err(&format!("Failed to read file: {}", e)); process::exit(1); }
        };
        let fixed = revise_go(&original, &project, &opts);
        let changed = fixed != original;
        changed_any |= changed;
        match opts.output.as_str() {
            "stdout" => print!("{}", fixed),
            "write" => {
                if opts.list_diff && changed { println!("{}", abs_display(&file)); }
                if changed { if let Err(e) = fs::write(&file, fixed) { log_err(&format!("Failed to write file: {}", e)); process::exit(1); } }
            }
            "file" | "" => {
                if opts.list_diff && changed { println!("{}", abs_display(&file)); }
                if changed { if let Err(e) = fs::write(&file, fixed) { log_err(&format!("Failed to write file: {}", e)); process::exit(1); } }
            }
            _ => {
                print!("{}", HELP);
                log_err(&format!("Unknown output format: {}", opts.output));
                process::exit(1);
            }
        }
    }
    if opts.set_exit_status && changed_any { process::exit(1); }
}

fn parse_args() -> Result<Option<Opts>, (String, i32)> {
    let mut opts = Opts { apply_generated: false, company_prefixes: vec![], excludes: vec![], file_path: None, imports_order: split_csv("std,general,company,project"), list_diff: false, output: "file".into(), project_name: None, recursive: false, rm_unused: false, separate_named: false, set_alias: false, set_exit_status: false, paths: vec![] };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--help" || a == "-h" { print!("{}", HELP); return Ok(None); }
        if a == "-version" {
            println!("version: {}", VERSION);
            println!("built with: go1.26.0");
            println!("tag: v{}", VERSION);
            println!("commit: n/a");
            println!("source: github.com/incu6us/goimports-reviser/v3");
            return Ok(None);
        }
        if a == "-version-only" { println!("{}", VERSION); return Ok(None); }
        if !a.starts_with('-') || a == "-" { opts.paths.push(a.clone()); i += 1; continue; }
        let (key, inline) = if let Some((k, v)) = a.split_once('=') { (k.to_string(), Some(v.to_string())) } else { (a.clone(), None) };
        let val = |i: &mut usize| -> Result<String, (String, i32)> {
            if let Some(v) = inline.clone() { return Ok(v); }
            *i += 1;
            if *i >= args.len() { return Err((format!("flag needs an argument: {}", key), 2)); }
            Ok(args[*i].clone())
        };
        match key.as_str() {
            "-apply-to-generated-files" => opts.apply_generated = true,
            "-format" => {},
            "-list-diff" => opts.list_diff = true,
            "-recursive" => opts.recursive = true,
            "-rm-unused" => opts.rm_unused = true,
            "-separate-named" => opts.separate_named = true,
            "-set-alias" => opts.set_alias = true,
            "-set-exit-status" => opts.set_exit_status = true,
            "-use-cache" => {},
            "-company-prefixes" => opts.company_prefixes = split_csv(&val(&mut i)?),
            "-excludes" => opts.excludes = split_csv(&val(&mut i)?),
            "-file-path" => opts.file_path = Some(val(&mut i)?),
            "-imports-order" => opts.imports_order = split_csv(&val(&mut i)?),
            "-local" => { let _ = val(&mut i)?; },
            "-output" => opts.output = val(&mut i)?,
            "-project-name" => opts.project_name = Some(val(&mut i)?),
            _ => return Err((format!("flag provided but not defined: {}", key), 2)),
        }
        i += 1;
    }
    Ok(Some(opts))
}

fn split_csv(s: &str) -> Vec<String> { s.split(',').map(|x| x.trim().to_string()).filter(|x| !x.is_empty()).collect() }

fn collect_files(paths: &[String], opts: &Opts) -> Result<Vec<PathBuf>, String> {
    let mut out = Vec::new();
    for p in paths {
        if p == "./..." || p.ends_with("/...") {
            let base = if p == "./..." { PathBuf::from(".") } else { PathBuf::from(p.trim_end_matches("/...")) };
            walk(&base, opts, &mut out)?;
        } else {
            let pb = PathBuf::from(p);
            if pb.is_dir() {
                if opts.recursive { walk(&pb, opts, &mut out)?; }
                else { for ent in fs::read_dir(&pb).map_err(|e| e.to_string())? { let path = ent.map_err(|e| e.to_string())?.path(); if is_go_file(&path) && !excluded(&path, opts) { out.push(path); } } }
            } else if is_go_file(&pb) && !excluded(&pb, opts) { out.push(pb); }
            else if pb.exists() { out.push(pb); }
        }
    }
    out.sort(); out.dedup(); Ok(out)
}
fn walk(dir: &Path, opts: &Opts, out: &mut Vec<PathBuf>) -> Result<(), String> {
    for ent in fs::read_dir(dir).map_err(|e| e.to_string())? {
        let path = ent.map_err(|e| e.to_string())?.path();
        if excluded(&path, opts) { continue; }
        if path.is_dir() { walk(&path, opts, out)?; }
        else if is_go_file(&path) { out.push(path); }
    }
    Ok(())
}
fn is_go_file(p: &Path) -> bool { p.extension().and_then(|s| s.to_str()) == Some("go") }
fn excluded(p: &Path, opts: &Opts) -> bool {
    let s = p.to_string_lossy().replace("\\", "/");
    opts.excludes.iter().any(|e| {
        let e = e.trim().trim_start_matches("./");
        if e.is_empty() { return false; }
        if e.ends_with('/') { s.contains(e.trim_end_matches('/')) }
        else if e.contains('*') { glob_match(e, &s) }
        else { s.ends_with(e) || s.contains(&format!("/{}", e)) }
    })
}
fn glob_match(pat: &str, text: &str) -> bool {
    let parts: Vec<&str> = pat.split('*').collect();
    let mut pos = 0usize;
    for (idx, part) in parts.iter().enumerate() {
        if part.is_empty() { continue; }
        if let Some(found) = text[pos..].find(part) {
            if idx == 0 && !pat.starts_with('*') && found != 0 && !text[pos+found..].ends_with(part) {}
            pos += found + part.len();
        } else { return false; }
    }
    true
}
fn abs_display(p: &Path) -> String { fs::canonicalize(p).unwrap_or_else(|_| p.to_path_buf()).display().to_string() }

fn find_module_name(path: &Path) -> Option<String> {
    let mut dir = if path.is_dir() { path.to_path_buf() } else { path.parent().unwrap_or(Path::new(".")).to_path_buf() };
    loop {
        let gm = dir.join("go.mod");
        if let Ok(s) = fs::read_to_string(&gm) {
            for line in s.lines() {
                let t = line.trim();
                if let Some(rest) = t.strip_prefix("module ") { return Some(rest.trim().to_string()); }
            }
        }
        if !dir.pop() { break; }
    }
    None
}

fn revise_go(src: &str, project: &str, opts: &Opts) -> String {
    if !opts.apply_generated && is_generated(src) { return src.to_string(); }
    let (mut specs, start, end) = match parse_imports(src) { Some(x) => x, None => return simple_format(src) };
    if opts.set_alias { for s in &mut specs { maybe_set_alias(s); } }
    if opts.rm_unused { specs = remove_unused(specs, src); }
    specs = dedup(specs);
    let block = render_imports(&specs, project, opts);
    let mut res = String::new();
    res.push_str(&src[..start]);
    res.push_str(&block);
    res.push_str(&src[end..]);
    simple_format(&res)
}

fn is_generated(src: &str) -> bool {
    for line in src.lines() {
        let t = line.trim_start();
        if t.is_empty() { continue; }
        return t.starts_with("// Code generated");
    }
    false
}

fn parse_imports(src: &str) -> Option<(Vec<ImportSpec>, usize, usize)> {
    let mut specs = Vec::new();
    let mut first_start = None;
    let mut last_end = 0usize;
    let mut offset = 0usize;
    let lines: Vec<&str> = src.split_inclusive('\n').collect();
    let mut i = 0usize;
    while i < lines.len() {
        let line = lines[i];
        let trimmed = line.trim_start();
        if trimmed.starts_with("import ") || trimmed.trim_end() == "import" || trimmed.starts_with("import(") {
            let line_start = offset;
            if first_start.is_none() { first_start = Some(line_start); }
            let after = trimmed.strip_prefix("import").unwrap().trim_start();
            if after.starts_with('(') {
                i += 1; offset += line.len();
                while i < lines.len() {
                    let l = lines[i];
                    if l.trim_start().starts_with(')') { offset += l.len(); i += 1; break; }
                    if let Some(sp) = parse_spec(l) { specs.push(sp); }
                    offset += l.len(); i += 1;
                }
                last_end = offset;
                continue;
            } else if let Some(sp) = parse_spec(after) {
                specs.push(sp);
                offset += line.len(); i += 1; last_end = offset; continue;
            }
        }
        offset += line.len(); i += 1;
    }
    first_start.map(|s| (specs, s, last_end))
}

fn parse_spec(line: &str) -> Option<ImportSpec> {
    let mut t = line.trim();
    if t.is_empty() || t.starts_with("//") { return None; }
    let q1 = t.find('"')?;
    let before = t[..q1].trim();
    t = &t[q1+1..];
    let q2 = t.find('"')?;
    let path = t[..q2].to_string();
    let comment = t[q2+1..].trim_end().to_string();
    let alias = if before.is_empty() { None } else { Some(before.to_string()) };
    Some(ImportSpec { alias, path, comment })
}

fn dedup(specs: Vec<ImportSpec>) -> Vec<ImportSpec> {
    let mut seen = HashSet::new(); let mut out = Vec::new();
    for s in specs { let key = format!("{}\0{}", s.alias.clone().unwrap_or_default(), s.path); if seen.insert(key) { out.push(s); } }
    out
}

fn maybe_set_alias(s: &mut ImportSpec) {
    if s.alias.is_some() { return; }
    let parts: Vec<&str> = s.path.split('/').collect();
    if parts.len() >= 2 {
        let last = parts[parts.len()-1];
        if last.len() >= 2 && last.starts_with('v') && last[1..].chars().all(|c| c.is_ascii_digit()) && last[1..].parse::<u32>().unwrap_or(0) >= 2 {
            let alias = sanitize_alias(parts[parts.len()-2]);
            if !alias.is_empty() { s.alias = Some(alias); }
        }
    }
}
fn sanitize_alias(s: &str) -> String { s.chars().filter(|c| c.is_ascii_alphanumeric() || *c == '_').collect() }

fn remove_unused(specs: Vec<ImportSpec>, src: &str) -> Vec<ImportSpec> {
    let body = if let Some((_, _, end)) = parse_imports(src) { &src[end..] } else { src };
    specs.into_iter().filter(|s| {
        if matches!(s.alias.as_deref(), Some("_") | Some(".")) { return true; }
        let name = s.alias.clone().unwrap_or_else(|| package_name(&s.path));
        body.contains(&format!("{}.", name)) || body.contains(&format!("{} ", name)) || body.contains(&format!("{}\n", name))
    }).collect()
}
fn package_name(path: &str) -> String {
    let mut seg = path.rsplit('/').next().unwrap_or(path).to_string();
    if seg.starts_with('v') && seg[1..].chars().all(|c| c.is_ascii_digit()) { seg = path.split('/').rev().nth(1).unwrap_or(&seg).to_string(); }
    sanitize_alias(&seg.replace('-', ""))
}

fn render_imports(specs: &[ImportSpec], project: &str, opts: &Opts) -> String {
    if specs.is_empty() { return String::new(); }
    if specs.len() == 1 {
        return format!("import {}\n", format_spec(&specs[0]));
    }
    let order_index: HashMap<String, usize> = opts.imports_order.iter().enumerate().map(|(i, g)| (g.clone(), i)).collect();
    let mut groups: HashMap<String, Vec<ImportSpec>> = HashMap::new();
    for s in specs {
        let g = classify(s, project, opts, &order_index);
        groups.entry(g).or_default().push(s.clone());
    }
    for vals in groups.values_mut() { vals.sort_by(|a, b| a.path.cmp(&b.path).then(a.alias.cmp(&b.alias))); }
    let mut ordered: Vec<String> = opts.imports_order.clone();
    for k in ["std", "general", "company", "project", "blanked", "dotted"] { if !ordered.iter().any(|x| x == k) { ordered.push(k.to_string()); } }
    let mut sections: Vec<Vec<ImportSpec>> = Vec::new();
    for g in ordered {
        if let Some(vals) = groups.remove(&g) {
            if opts.separate_named {
                let (plain, named): (Vec<_>, Vec<_>) = vals.into_iter().partition(|s| s.alias.is_none());
                if !plain.is_empty() { sections.push(plain); }
                if !named.is_empty() { sections.push(named); }
            } else { sections.push(vals); }
        }
    }
    for (_, vals) in groups { if !vals.is_empty() { sections.push(vals); } }
    let mut out = String::from("import (\n");
    for (si, sec) in sections.iter().enumerate() {
        if si > 0 { out.push('\n'); }
        for s in sec { out.push('\t'); out.push_str(&format_spec(s)); out.push('\n'); }
    }
    out.push_str(")\n"); out
}

fn classify(s: &ImportSpec, project: &str, opts: &Opts, order_index: &HashMap<String, usize>) -> String {
    if s.alias.as_deref() == Some("_") && order_index.contains_key("blanked") { return "blanked".into(); }
    if s.alias.as_deref() == Some(".") && order_index.contains_key("dotted") { return "dotted".into(); }
    let first = s.path.split('/').next().unwrap_or("");
    if !first.contains('.') { return "std".into(); }
    if !project.is_empty() && s.path.starts_with(project) { return "project".into(); }
    if !opts.company_prefixes.is_empty() && opts.company_prefixes.iter().any(|p| s.path.starts_with(p)) { return "company".into(); }
    "general".into()
}
fn format_spec(s: &ImportSpec) -> String {
    let mut out = String::new();
    if let Some(a) = &s.alias { out.push_str(a); out.push(' '); }
    out.push('"'); out.push_str(&s.path); out.push('"');
    if !s.comment.trim().is_empty() { out.push(' '); out.push_str(s.comment.trim()); }
    out
}

fn simple_format(src: &str) -> String {
    let mut s = src.replace("\r\n", "\n");
    s = s.replace("    ", "\t");
    s = compact_func_lines(&s);
    while s.contains("\n\n\n") { s = s.replace("\n\n\n", "\n\n"); }
    if !s.ends_with('\n') { s.push('\n'); }
    s
}
fn compact_func_lines(src: &str) -> String {
    let mut out = String::new();
    for line in src.lines() {
        let t = line.trim();
        if t.starts_with("func ") && t.ends_with('}') && t.contains("{") {
            let mut x = t.replace("(){", "() {").replace("){", ") {");
            x = x.replace("; ", "; ");
            if let Some(b) = x.find("{") { if x.ends_with("}") && b + 1 < x.len() { let inner = x[b+1..x.len()-1].trim().to_string(); if !inner.is_empty() { x = format!("{} {{ {} }}", x[..b].trim_end(), inner); } } }
            out.push_str(&x); out.push('\n');
        } else { out.push_str(line); out.push('\n'); }
    }
    out
}

fn log_err(msg: &str) { let _ = writeln!(io::stderr(), "{} {}", timestamp(), msg); }
fn timestamp() -> String {
    // The exact local time is not important for tests; this mirrors Go log's shape.
    let secs = SystemTime::now().duration_since(UNIX_EPOCH).unwrap_or_default().as_secs();
    let days = secs / 86400;
    let year = 1970 + days / 365;
    format!("{:04}/01/01 00:00:00", year)
}
