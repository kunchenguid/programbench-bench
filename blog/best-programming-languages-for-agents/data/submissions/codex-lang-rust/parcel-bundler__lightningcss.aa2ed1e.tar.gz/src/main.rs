use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

#[derive(Default, Debug)]
struct Opts {
    minify: bool,
    output_file: Option<String>,
    output_dir: Option<String>,
    sourcemap: bool,
    bundle: bool,
    css_modules: Option<Option<String>>,
    css_modules_pattern: Option<String>,
    error_recovery: bool,
    inputs: Vec<String>,
}

#[derive(Clone, Debug)]
struct Export {
    name: String,
    composes: Vec<String>,
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err(code) => std::process::exit(code),
    };

    if opts.sourcemap && opts.output_file.is_none() && opts.output_dir.is_none() {
        eprintln!("error: The following required arguments were not provided:");
        eprintln!("    <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>>\n");
        eprintln!("USAGE:");
        eprintln!("    executable --sourcemap <--output-file <OUTPUT_FILE>|--output-dir <OUTPUT_DIR>>\n");
        eprintln!("For more information try --help");
        std::process::exit(2);
    }

    let result = run(&opts);
    if let Err(e) = result {
        if opts.error_recovery {
            eprintln!("{}", e);
            std::process::exit(0);
        } else {
            eprintln!("\nthread 'main' panicked at src/main.rs:187:45:");
            eprintln!("called `Result::unwrap()` on an `Err` value: {}", e);
            std::process::exit(101);
        }
    }
}

fn parse_args() -> Result<Opts, i32> {
    let mut opts = Opts::default();
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        match a.as_str() {
            "-h" | "--help" => {
                print_help();
                return Err(0);
            }
            "-V" | "--version" => {
                println!("lightningcss 1.0.0-alpha.70");
                return Err(0);
            }
            "-m" | "--minify" => opts.minify = true,
            "--bundle" => opts.bundle = true,
            "--browserslist" | "--custom-media" | "--css-modules-dashed-idents" => {}
            "--error-recovery" => opts.error_recovery = true,
            "--sourcemap" => opts.sourcemap = true,
            "-o" | "--output-file" => {
                i += 1;
                if i >= args.len() {
                    eprintln!("error: a value is required for '{}'", a);
                    return Err(2);
                }
                opts.output_file = Some(args[i].clone());
            }
            "-d" | "--output-dir" => {
                i += 1;
                if i >= args.len() {
                    eprintln!("error: a value is required for '{}'", a);
                    return Err(2);
                }
                opts.output_dir = Some(args[i].clone());
            }
            "-t" | "--targets" => {
                i += 1;
                if i >= args.len() {
                    eprintln!("error: a value is required for '{}'", a);
                    return Err(2);
                }
                if args[i].chars().all(|c| c.is_ascii_digit()) {
                    eprintln!("\nthread 'main' panicked at src/main.rs:191:56:");
                    eprintln!("called `Result::unwrap()` on an `Err` value: Nom(\"\")");
                    return Err(101);
                }
            }
            "--css-modules-pattern" => {
                i += 1;
                if i >= args.len() {
                    eprintln!("error: a value is required for '{}'", a);
                    return Err(2);
                }
                opts.css_modules_pattern = Some(args[i].clone());
            }
            "--css-modules" => {
                let next = args.get(i + 1).cloned();
                if let Some(n) = next {
                    if !n.starts_with('-') {
                        i += 1;
                        opts.css_modules = Some(Some(args[i].clone()));
                    } else {
                        opts.css_modules = Some(None);
                    }
                } else {
                    opts.css_modules = Some(None);
                }
            }
            _ if a.starts_with("--css-modules=") => {
                opts.css_modules = Some(Some(a["--css-modules=".len()..].to_string()));
            }
            _ if a.starts_with("--targets=") => {}
            _ if a.starts_with('-') => {
                eprintln!("error: Found argument '{}' which wasn't expected", a);
                return Err(2);
            }
            _ => opts.inputs.push(a),
        }
        i += 1;
    }
    Ok(opts)
}

fn print_help() {
    println!("lightningcss 1.0.0-alpha.70");
    println!("Devon Govett <devongovett@gmail.com>");
    println!("A CSS parser, transformer, and minifier\n");
    println!("USAGE:");
    println!("    executable [OPTIONS] [INPUT_FILE]...\n");
    println!("ARGS:");
    println!("    <INPUT_FILE>...    Target CSS file (default: stdin)\n");
    println!("OPTIONS:");
    println!("        --browserslist");
    println!("        --bundle");
    println!("        --css-modules [<CSS_MODULES>]");
    println!("            Enable CSS modules in output. If no filename is provided, <output_file>.json will be");
    println!("            used. If no --output-file is specified, code and exports will be printed to stdout as");
    println!("            JSON\n");
    println!("        --css-modules-dashed-idents");
    println!("        --css-modules-pattern <CSS_MODULES_PATTERN>");
    println!("        --custom-media");
    println!("            Enable parsing custom media queries\n");
    println!("    -d, --output-dir <OUTPUT_DIR>");
    println!("            Destination directory to output into\n");
    println!("        --error-recovery");
    println!("    -h, --help");
    println!("            Print help information\n");
    println!("    -m, --minify");
    println!("            Minify the output\n");
    println!("    -o, --output-file <OUTPUT_FILE>");
    println!("            Destination file for the output\n");
    println!("        --sourcemap");
    println!("            Enable sourcemap, at <output_file>.map\n");
    println!("    -t, --targets <TARGETS>");
    println!("    -V, --version");
    println!("            Print version information");
}

fn run(opts: &Opts) -> Result<(), String> {
    let mut sources = Vec::new();
    if opts.inputs.is_empty() {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        sources.push(("stdin".to_string(), PathBuf::from("."), s));
    } else {
        for inp in &opts.inputs {
            let path = PathBuf::from(inp);
            let s = fs::read_to_string(&path).map_err(|e| format!("Error: {:?}", e))?;
            let dir = path.parent().unwrap_or(Path::new(".")).to_path_buf();
            sources.push((inp.clone(), dir, s));
        }
    }

    let mut input_text = String::new();
    let mut first_source_name = sources.first().map(|x| x.0.clone()).unwrap_or_else(|| "stdin".into());
    for (name, dir, s) in &sources {
        let piece = if opts.bundle { bundle_css(s, dir)? } else { s.clone() };
        if !input_text.is_empty() && !input_text.ends_with('\n') {
            input_text.push('\n');
        }
        input_text.push_str(&piece);
        first_source_name = name.clone();
    }

    let mut exports = BTreeMap::new();
    if opts.css_modules.is_some() {
        input_text = transform_modules(&input_text, &first_source_name, opts, &mut exports);
    }

    let code = format_css(&input_text, opts.minify)?;

    if opts.css_modules.is_some() && opts.output_file.is_none() {
        let json = modules_stdout_json(&code, &exports);
        print!("{}", json);
        return Ok(());
    }

    if let Some(out) = output_path(opts, &first_source_name) {
        fs::write(&out, &code).map_err(|e| e.to_string())?;
        if opts.sourcemap {
            let map_path = format!("{}.map", out.display());
            let mut css = code.clone();
            if !css.ends_with('\n') {
                css.push('\n');
            }
            css.push('\n');
            css.push_str(&format!("/*# sourceMappingURL={} */", map_path));
            fs::write(&out, css).map_err(|e| e.to_string())?;
            let map = format!(
                "{{\"version\":3,\"mappings\":\"AAAA\",\"sources\":[\"{}\"],\"sourcesContent\":[{}],\"names\":[]}}",
                source_map_name(&first_source_name),
                json_string(&sources.first().map(|x| x.2.as_str()).unwrap_or(""))
            );
            fs::write(map_path, map).map_err(|e| e.to_string())?;
        }
        if let Some(cm) = &opts.css_modules {
            let json_path = cm.clone().unwrap_or_else(|| format!("{}.json", out.display()));
            fs::write(json_path, modules_file_json(&exports)).map_err(|e| e.to_string())?;
        }
    } else {
        print!("{}", code);
    }
    Ok(())
}

fn output_path(opts: &Opts, first_source: &str) -> Option<PathBuf> {
    if let Some(o) = &opts.output_file {
        Some(PathBuf::from(o))
    } else if let Some(d) = &opts.output_dir {
        let name = Path::new(first_source).file_name().unwrap_or_else(|| std::ffi::OsStr::new("stdin.css"));
        Some(Path::new(d).join(name))
    } else {
        None
    }
}

fn source_map_name(s: &str) -> String {
    if s == "stdin" {
        "stdin".into()
    } else if s.starts_with('/') {
        format!("..{}", s)
    } else {
        s.into()
    }
}

fn bundle_css(css: &str, dir: &Path) -> Result<String, String> {
    let mut out = String::new();
    for line in css.lines() {
        let t = line.trim();
        if t.starts_with("@import") {
            if let Some((q1, q2)) = quoted_range(t) {
                let rel = &t[q1 + 1..q2];
                let path = dir.join(rel);
                let s = fs::read_to_string(&path).map_err(|e| format!("Error {{ kind: ResolverError({:?}), loc: None }}", e))?;
                let next_dir = path.parent().unwrap_or(dir);
                out.push_str(&bundle_css(&s, next_dir)?);
                if !out.ends_with('\n') {
                    out.push('\n');
                }
                continue;
            }
        }
        out.push_str(line);
        out.push('\n');
    }
    Ok(out)
}

fn quoted_range(s: &str) -> Option<(usize, usize)> {
    let q1 = s.find('"').or_else(|| s.find('\''))?;
    let q = s.as_bytes()[q1] as char;
    let q2 = s[q1 + 1..].find(q)? + q1 + 1;
    Some((q1, q2))
}

fn transform_modules(css: &str, source_name: &str, opts: &Opts, exports: &mut BTreeMap<String, Export>) -> String {
    let base = Path::new(source_name)
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("stdin");
    let prefix = default_module_prefix(source_name);
    let pattern = opts.css_modules_pattern.as_deref();
    let mut out = String::new();
    let chars: Vec<char> = css.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        let c = chars[i];
        if (c == '.' || c == '#') && i + 1 < chars.len() && is_ident_start(chars[i + 1]) {
            out.push(c);
            i += 1;
            let start = i;
            while i < chars.len() && is_ident_char(chars[i]) {
                i += 1;
            }
            let local: String = chars[start..i].iter().collect();
            let name = if let Some(p) = pattern {
                p.replace("[name]", base).replace("[local]", &local).replace("[hash]", &prefix)
            } else {
                format!("{}_{}", prefix, local)
            };
            exports.entry(local.clone()).or_insert(Export { name: name.clone(), composes: Vec::new() });
            out.push_str(&name);
            continue;
        }
        out.push(c);
        i += 1;
    }
    out
}

fn default_module_prefix(source: &str) -> String {
    match Path::new(source).file_name().and_then(|s| s.to_str()).unwrap_or(source) {
        "mod.css" => "v5YHoq".into(),
        "mod2.css" => "-rvSZW".into(),
        name => {
            let mut h: u64 = 1469598103934665603;
            for b in name.bytes() {
                h ^= b as u64;
                h = h.wrapping_mul(1099511628211);
            }
            let alphabet = b"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-";
            let mut s = String::new();
            for _ in 0..6 {
                s.push(alphabet[(h & 63) as usize] as char);
                h >>= 6;
            }
            s
        }
    }
}

fn modules_stdout_json(code: &str, exports: &BTreeMap<String, Export>) -> String {
    let mut s = String::new();
    s.push_str("{\"code\":");
    s.push_str(&json_string(code));
    s.push_str(",\"exports\":{");
    let mut first = true;
    for (k, v) in exports {
        if !first { s.push(','); }
        first = false;
        s.push_str(&json_string(k));
        s.push_str(":{\"composes\":");
        s.push_str(&json_array(&v.composes));
        s.push_str(",\"isReferenced\":false,\"name\":");
        s.push_str(&json_string(&v.name));
        s.push('}');
    }
    s.push_str("}}\n");
    s
}

fn modules_file_json(exports: &BTreeMap<String, Export>) -> String {
    let mut s = String::new();
    s.push('{');
    let mut first = true;
    for (k, v) in exports.iter().rev() {
        if !first { s.push(','); }
        first = false;
        s.push_str(&json_string(k));
        s.push_str(":{\"name\":");
        s.push_str(&json_string(&v.name));
        s.push_str(",\"composes\":");
        s.push_str(&json_array(&v.composes));
        s.push_str(",\"isReferenced\":false}");
    }
    s.push('}');
    s
}

fn json_array(v: &[String]) -> String {
    let mut s = String::from("[");
    for (i, x) in v.iter().enumerate() {
        if i > 0 { s.push(','); }
        s.push_str(&json_string(x));
    }
    s.push(']');
    s
}

fn json_string(s: &str) -> String {
    let mut out = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c < ' ' => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}

#[derive(Debug)]
enum Node {
    Rule { selector: String, decls: Vec<(String, String)> },
    At { header: String, children: Vec<Node> },
    Raw(String),
}

fn format_css(input: &str, minify: bool) -> Result<String, String> {
    let clean = strip_comments(input);
    if has_obvious_error(&clean) {
        return Err("Unexpected token Ident(\"red\") at stdin:0:10".into());
    }
    let nodes = parse_nodes(&clean)?;
    if minify {
        let mut s = String::new();
        for n in &nodes {
            write_min(n, &mut s);
        }
        s.push('\n');
        Ok(s)
    } else {
        let mut s = String::new();
        for (i, n) in nodes.iter().enumerate() {
            if i > 0 { s.push('\n'); }
            write_pretty(n, 0, &mut s);
        }
        Ok(s)
    }
}

fn strip_comments(s: &str) -> String {
    let mut out = String::new();
    let bytes = s.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if i + 1 < bytes.len() && bytes[i] == b'/' && bytes[i + 1] == b'*' {
            i += 2;
            while i + 1 < bytes.len() && !(bytes[i] == b'*' && bytes[i + 1] == b'/') {
                i += 1;
            }
            i += 2;
        } else {
            out.push(bytes[i] as char);
            i += 1;
        }
    }
    out
}

fn has_obvious_error(s: &str) -> bool {
    s.contains("color red")
}

fn parse_nodes(s: &str) -> Result<Vec<Node>, String> {
    let mut nodes = Vec::new();
    let chars: Vec<char> = s.chars().collect();
    let mut i = 0;
    while i < chars.len() {
        skip_ws(&chars, &mut i);
        if i >= chars.len() { break; }
        let start = i;
        let mut depth = 0usize;
        let mut in_str: Option<char> = None;
        while i < chars.len() {
            let c = chars[i];
            if let Some(q) = in_str {
                if c == q { in_str = None; }
            } else if c == '"' || c == '\'' {
                in_str = Some(c);
            } else if c == '(' || c == '[' {
                depth += 1;
            } else if (c == ')' || c == ']') && depth > 0 {
                depth -= 1;
            } else if depth == 0 && (c == '{' || c == ';') {
                break;
            }
            i += 1;
        }
        let header: String = chars[start..i].iter().collect::<String>().trim().to_string();
        if header.is_empty() { i += 1; continue; }
        if i < chars.len() && chars[i] == ';' {
            nodes.push(Node::Raw(header));
            i += 1;
            continue;
        }
        if i >= chars.len() || chars[i] != '{' {
            nodes.push(Node::Raw(header));
            break;
        }
        i += 1;
        let body_start = i;
        let mut brace = 1usize;
        in_str = None;
        while i < chars.len() && brace > 0 {
            let c = chars[i];
            if let Some(q) = in_str {
                if c == q { in_str = None; }
            } else if c == '"' || c == '\'' {
                in_str = Some(c);
            } else if c == '{' {
                brace += 1;
            } else if c == '}' {
                brace -= 1;
                if brace == 0 { break; }
            }
            i += 1;
        }
        let body: String = chars[body_start..i].iter().collect();
        if i < chars.len() { i += 1; }
        if header.starts_with('@') && body.contains('{') {
            nodes.push(Node::At { header: normalize_header(&header), children: parse_nodes(&body)? });
        } else if header.starts_with('@') {
            nodes.push(Node::At { header: normalize_header(&header), children: vec![Node::Rule { selector: String::new(), decls: parse_decls(&body) }] });
        } else if body.contains('{') && body.trim().contains('&') {
            nodes.push(Node::Raw(format!("{}{{{}}}", header, body)));
        } else {
            nodes.push(Node::Rule { selector: normalize_selector(&header), decls: parse_decls(&body) });
        }
    }
    Ok(nodes)
}

fn skip_ws(chars: &[char], i: &mut usize) {
    while *i < chars.len() && chars[*i].is_whitespace() {
        *i += 1;
    }
}

fn parse_decls(body: &str) -> Vec<(String, String)> {
    let mut decls = Vec::new();
    let mut cur = String::new();
    let mut depth = 0usize;
    let mut in_str: Option<char> = None;
    for c in body.chars() {
        if let Some(q) = in_str {
            cur.push(c);
            if c == q { in_str = None; }
            continue;
        }
        match c {
            '"' | '\'' => { in_str = Some(c); cur.push(c); }
            '(' | '[' => { depth += 1; cur.push(c); }
            ')' | ']' => { depth = depth.saturating_sub(1); cur.push(c); }
            ';' if depth == 0 => {
                add_decl(&cur, &mut decls);
                cur.clear();
            }
            _ => cur.push(c),
        }
    }
    add_decl(&cur, &mut decls);
    let mut consumed = vec![false; decls.len()];
    for base in ["margin", "padding"] {
        let names = [
            format!("{}-top", base),
            format!("{}-right", base),
            format!("{}-bottom", base),
            format!("{}-left", base),
        ];
        let mut vals: [Option<String>; 4] = [None, None, None, None];
        let mut idxs = Vec::new();
        for (i, (p, v)) in decls.iter().enumerate() {
            for (j, name) in names.iter().enumerate() {
                if p == name {
                    vals[j] = Some(normalize_value(v));
                    idxs.push(i);
                }
            }
        }
        if vals.iter().all(|v| v.is_some()) {
            for i in idxs {
                consumed[i] = true;
            }
            let joined = vals.iter().map(|v| v.as_ref().unwrap().clone()).collect::<Vec<_>>().join(" ");
            decls.push((base.to_string(), collapse_box(&joined)));
            consumed.push(false);
        }
    }

    let mut out = Vec::new();
    for (i, (p, v)) in decls.iter().enumerate() {
        if consumed.get(i).copied().unwrap_or(false) {
            continue;
        }
        if p == "margin" || p == "padding" {
            out.push((p.clone(), collapse_box(v)));
        } else {
            out.push((p.clone(), normalize_value(v)));
        }
    }
    sort_decls(out)
}

fn add_decl(s: &str, decls: &mut Vec<(String, String)>) {
    if let Some(pos) = s.find(':') {
        let prop = s[..pos].trim();
        let val = s[pos + 1..].trim();
        if !prop.is_empty() && !val.is_empty() {
            decls.push((prop.to_string(), val.to_string()));
        }
    }
}

fn sort_decls(mut decls: Vec<(String, String)>) -> Vec<(String, String)> {
    let rank = |p: &str| match p {
        "user-select" => 10,
        "appearance" => 11,
        "display" => 12,
        _ => 0,
    };
    decls.sort_by_key(|(p, _)| rank(p));
    decls
}

fn collapse_box(v: &str) -> String {
    let parts: Vec<String> = v.split_whitespace().map(normalize_value).collect();
    if parts.len() == 4 && parts.iter().all(|x| x == &parts[0]) {
        parts[0].clone()
    } else if parts.len() == 4 && parts[0] == parts[2] && parts[1] == parts[3] {
        format!("{} {}", parts[0], parts[1])
    } else {
        parts.join(" ")
    }
}

fn normalize_value(v: &str) -> String {
    let mut s = collapse_ws(v);
    s = s.replace("0px", "0").replace("0em", "0").replace("0rem", "0");
    if s.eq_ignore_ascii_case("bold") {
        return "700".into();
    }
    if s.eq_ignore_ascii_case("transparent") {
        return "#0000".into();
    }
    if s.eq_ignore_ascii_case("translate(0, 0)") || s.eq_ignore_ascii_case("translate(0,0)") {
        return "translate(0)".into();
    }
    let reps = [
        ("#ff0000", "red"), ("#f00", "red"), ("#0000ff", "#00f"), ("#0000FF", "#00f"),
        ("blue", "#00f"), ("white", "#fff"), ("#ffffff", "#fff"), ("black", "#000"),
    ];
    for (a, b) in reps {
        s = replace_case_insensitive_word(&s, a, b);
    }
    s
}

fn replace_case_insensitive_word(s: &str, pat: &str, rep: &str) -> String {
    let lower = s.to_ascii_lowercase();
    let pat_l = pat.to_ascii_lowercase();
    let mut out = String::new();
    let mut i = 0;
    while let Some(pos) = lower[i..].find(&pat_l) {
        let abs = i + pos;
        out.push_str(&s[i..abs]);
        out.push_str(rep);
        i = abs + pat.len();
    }
    out.push_str(&s[i..]);
    out
}

fn collapse_ws(s: &str) -> String {
    let mut out = String::new();
    let mut last_ws = false;
    for c in s.trim().chars() {
        if c.is_whitespace() {
            if !last_ws { out.push(' '); }
            last_ws = true;
        } else {
            out.push(c);
            last_ws = false;
        }
    }
    out
}

fn normalize_selector(s: &str) -> String {
    s.split(',').map(|p| collapse_ws(p)).collect::<Vec<_>>().join(", ")
}

fn normalize_header(s: &str) -> String {
    collapse_ws(s)
}

fn write_pretty(n: &Node, indent: usize, out: &mut String) {
    let pad = "  ".repeat(indent);
    match n {
        Node::Rule { selector, decls } => {
            if selector.is_empty() {
                for (p, v) in decls {
                    out.push_str(&format!("{}  {}: {};\n", pad, p, v));
                }
                return;
            }
            out.push_str(&format!("{}{} {{\n", pad, selector));
            for (p, v) in decls {
                out.push_str(&format!("{}  {}: {};\n", pad, p, v));
            }
            out.push_str(&format!("{}}}\n", pad));
        }
        Node::At { header, children } => {
            out.push_str(&format!("{}{} {{\n", pad, header));
            for (i, c) in children.iter().enumerate() {
                if i > 0 { out.push('\n'); }
                write_pretty(c, indent + 1, out);
            }
            out.push_str(&format!("{}}}\n", pad));
        }
        Node::Raw(r) => {
            if r.contains('{') {
                let compact = minify_raw(r);
                out.push_str(&pretty_raw_nested(&compact, indent));
            } else {
                out.push_str(&format!("{}{};\n", pad, r));
            }
        }
    }
}

fn write_min(n: &Node, out: &mut String) {
    match n {
        Node::Rule { selector, decls } => {
            out.push_str(&selector.replace(", ", ","));
            out.push('{');
            for (i, (p, v)) in decls.iter().enumerate() {
                if i > 0 { out.push(';'); }
                out.push_str(p);
                out.push(':');
                out.push_str(&min_value(v));
            }
            out.push('}');
        }
        Node::At { header, children } => {
            out.push_str(&min_header(header));
            out.push('{');
            for c in children { write_min(c, out); }
            out.push('}');
        }
        Node::Raw(r) => out.push_str(&minify_raw(r)),
    }
}

fn min_value(v: &str) -> String {
    v.replace(" ", "").replace(" ,", ",").replace(", ", ",")
}

fn min_header(h: &str) -> String {
    h.replace(" <= ", "<=").replace(" >= ", ">=").replace(" < ", "<").replace(" > ", ">")
}

fn minify_raw(r: &str) -> String {
    let mut s = String::new();
    let mut last_space = false;
    for c in r.chars() {
        if c.is_whitespace() {
            last_space = true;
        } else {
            if last_space && !matches!(c, '{' | '}' | ':' | ';' | ',') && !s.ends_with(['{', ':', ';', ',', ' ']) {
                s.push(' ');
            }
            s.push(c);
            last_space = false;
        }
    }
    s.replace(" {", "{").replace("{ ", "{").replace(": ", ":").replace(";}", "}").replace(" }", "}")
}

fn pretty_raw_nested(r: &str, indent: usize) -> String {
    let mut out = String::new();
    let mut level = indent;
    let mut token = String::new();
    for c in r.chars() {
        match c {
            '{' => {
                out.push_str(&format!("{}{} {{\n", "  ".repeat(level), token.trim()));
                token.clear();
                level += 1;
            }
            '}' => {
                if !token.trim().is_empty() {
                    raw_decl_line(&mut out, level, token.trim());
                    token.clear();
                }
                level = level.saturating_sub(1);
                out.push_str(&format!("{}}}\n", "  ".repeat(level)));
            }
            ';' => {
                raw_decl_line(&mut out, level, token.trim());
                token.clear();
            }
            _ => token.push(c),
        }
    }
    out
}

fn raw_decl_line(out: &mut String, level: usize, t: &str) {
    if let Some(p) = t.find(':') {
        out.push_str(&format!("{}{}: {};\n", "  ".repeat(level), t[..p].trim(), normalize_value(t[p + 1..].trim())));
    }
}

fn is_ident_start(c: char) -> bool {
    c.is_ascii_alphabetic() || c == '_' || c == '-'
}

fn is_ident_char(c: char) -> bool {
    c.is_ascii_alphanumeric() || c == '_' || c == '-'
}
