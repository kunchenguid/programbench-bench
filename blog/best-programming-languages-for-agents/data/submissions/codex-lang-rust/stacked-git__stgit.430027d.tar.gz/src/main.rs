use std::collections::HashMap;
use std::env;
use std::fs;
use std::path::PathBuf;
use std::process::{Command, ExitCode, Stdio};

const VERSION: &str = "Stacked Git 2.5.5";

#[derive(Clone, Debug)]
struct Patch { name: String, commit: String, message: String, hidden: bool }

#[derive(Clone, Debug, Default)]
struct State { base: String, applied: Vec<String>, unapplied: Vec<String>, hidden: Vec<String>, patches: HashMap<String, Patch> }

fn main() -> ExitCode {
    let mut args: Vec<String> = env::args().skip(1).collect();
    let mut cwd: Option<PathBuf> = None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-C" => {
                if i + 1 >= args.len() { eprintln!("error: a value is required for '-C <path>'"); return ExitCode::from(2); }
                let p = PathBuf::from(args.remove(i + 1)); args.remove(i);
                cwd = Some(if p.is_absolute() { p } else { cwd.unwrap_or_else(|| env::current_dir().unwrap()).join(p) });
            }
            "--color" => { if i + 1 < args.len() { args.drain(i..=i+1); } else { args.remove(i); } }
            "--version" => { print_version(); return ExitCode::SUCCESS; }
            "-h" | "--help" if args.len() == 1 => { print_main_help(args[0] == "--help"); return ExitCode::SUCCESS; }
            _ => i += 1,
        }
    }
    if let Some(dir) = cwd { if let Err(e) = env::set_current_dir(&dir) { eprintln!("stg: {}: {}", dir.display(), e); return ExitCode::from(1); } }
    if args.is_empty() { print_main_help(false); return ExitCode::from(2); }
    let cmd = args.remove(0);
    let res = match cmd.as_str() {
        "version" => { print_version(); Ok(()) }
        "help" => { if args.is_empty() { print_main_help(true); Ok(()) } else { print_cmd_help(&args[0]); Ok(()) } }
        "init" => cmd_init(&args),
        "new" => cmd_new(&args),
        "refresh" => cmd_refresh(&args),
        "series" => cmd_series(&args),
        "top" => cmd_top(&args),
        "next" => cmd_next(&args),
        "prev" => cmd_prev(&args),
        "pop" => cmd_pop(&args),
        "push" => cmd_push(&args),
        "id" => cmd_id(&args),
        "name" => cmd_name(&args),
        "files" => cmd_files(&args),
        "diff" => cmd_diff(&args),
        "show" => cmd_show(&args),
        "branch" => cmd_branch(&args),
        "log" => { println!("Stack log unavailable in this reimplementation"); Ok(()) }
        "completion" => cmd_completion(&args),
        "status" => run_git_passthrough(&["status", "-s"], &args),
        "add" | "resolved" => run_git_passthrough(&["add"], &args),
        "rm" => run_git_passthrough(&["rm"], &args),
        "mv" => run_git_passthrough(&["mv"], &args),
        "delete" => cmd_delete(&args),
        "rename" => cmd_rename(&args),
        "clean" => Ok(()),
        other => { eprintln!("error: unrecognized subcommand '{}'\n\nUsage: stg [OPTIONS] <command> [...]\n       stg [OPTIONS] <-h|--help>\n       stg --version\n\nFor more information, try '--help'.", other); Err(1) }
    };
    match res { Ok(()) => ExitCode::SUCCESS, Err(c) => ExitCode::from(c as u8) }
}

fn git(args: &[&str]) -> Result<String, i32> {
    let out = Command::new("git").args(args).output().map_err(|e| { eprintln!("stg: failed to run git: {}", e); 1 })?;
    if out.status.success() { Ok(String::from_utf8_lossy(&out.stdout).trim_end().to_string()) } else { eprint!("{}", String::from_utf8_lossy(&out.stderr)); Err(out.status.code().unwrap_or(1)) }
}
fn git_ok(args: &[&str]) -> Result<(), i32> { git(args).map(|_| ()) }

fn git_silent(args: &[&str]) -> Result<(), i32> {
    let out = Command::new("git").args(args).stdout(Stdio::null()).output().map_err(|e| { eprintln!("stg: failed to run git: {}", e); 1 })?;
    if out.status.success() { Ok(()) } else { eprint!("{}", String::from_utf8_lossy(&out.stderr)); Err(out.status.code().unwrap_or(1)) }
}
fn git_status(args: &[&str]) -> Result<(), i32> {
    let st = Command::new("git").args(args).status().map_err(|e| { eprintln!("stg: failed to run git: {}", e); 1 })?;
    if st.success() { Ok(()) } else { Err(st.code().unwrap_or(1)) }
}
fn run_git_passthrough(prefix: &[&str], rest: &[String]) -> Result<(), i32> {
    let mut c = Command::new("git"); c.args(prefix).args(rest);
    let st = c.status().map_err(|e| { eprintln!("stg: failed to run git: {}", e); 1 })?;
    if st.success() { Ok(()) } else { Err(st.code().unwrap_or(1)) }
}
fn branch_name() -> Result<String, i32> { git(&["rev-parse", "--abbrev-ref", "HEAD"]) }
fn git_dir() -> Result<PathBuf, i32> { Ok(PathBuf::from(git(&["rev-parse", "--git-dir"])?)) }
fn state_path(branch: &str) -> Result<PathBuf, i32> { Ok(git_dir()?.join("stg-lite").join(sanitize(branch)).join("state")) }
fn sanitize(s: &str) -> String { s.replace('/', "__") }
fn ensure_repo() -> Result<(), i32> { git_ok(&["rev-parse", "--git-dir"]) }

fn load_state_for(branch: &str) -> Result<Option<State>, i32> {
    let p = state_path(branch)?; if !p.exists() { return Ok(None); }
    let txt = fs::read_to_string(p).map_err(|e| { eprintln!("stg: cannot read state: {}", e); 1 })?;
    let mut st = State::default();
    for line in txt.lines() {
        if let Some(v) = line.strip_prefix("base=") { st.base = unesc(v); }
        else if let Some(v) = line.strip_prefix("applied=") { st.applied = list(v); }
        else if let Some(v) = line.strip_prefix("unapplied=") { st.unapplied = list(v); }
        else if let Some(v) = line.strip_prefix("hidden=") { st.hidden = list(v); }
        else if let Some(v) = line.strip_prefix("patch=") {
            let parts: Vec<&str> = v.splitn(4, '|').collect();
            if parts.len() == 4 { let pa = Patch{name:unesc(parts[0]), commit:unesc(parts[1]), message:unesc(parts[2]), hidden:parts[3]=="1"}; st.patches.insert(pa.name.clone(), pa); }
        }
    }
    Ok(Some(st))
}
fn load_state() -> Result<State, i32> { let b = branch_name()?; load_state_for(&b)?.ok_or_else(|| { eprintln!("stg: branch '{}' is not initialized", b); 1 }) }
fn save_state_for(branch: &str, st: &State) -> Result<(), i32> {
    let p = state_path(branch)?; fs::create_dir_all(p.parent().unwrap()).map_err(|e| { eprintln!("stg: cannot create state: {}", e); 1 })?;
    let mut s = String::new();
    s.push_str(&format!("base={}\n", esc(&st.base))); s.push_str(&format!("applied={}\n", join(&st.applied))); s.push_str(&format!("unapplied={}\n", join(&st.unapplied))); s.push_str(&format!("hidden={}\n", join(&st.hidden)));
    let mut names: Vec<_> = st.patches.keys().cloned().collect(); names.sort();
    for n in names { let p = &st.patches[&n]; s.push_str(&format!("patch={}|{}|{}|{}\n", esc(&p.name), esc(&p.commit), esc(&p.message), if p.hidden {"1"} else {"0"})); }
    fs::write(p, s).map_err(|e| { eprintln!("stg: cannot write state: {}", e); 1 })
}
fn save_state(st: &State) -> Result<(), i32> { let b = branch_name()?; save_state_for(&b, st) }
fn esc(s: &str) -> String { s.replace('%', "%25").replace('|', "%7C").replace('\n', "%0A").replace(',', "%2C") }
fn unesc(s: &str) -> String { s.replace("%0A", "\n").replace("%2C", ",").replace("%7C", "|").replace("%25", "%") }
fn join(v: &[String]) -> String { v.iter().map(|x| esc(x)).collect::<Vec<_>>().join(",") }
fn list(s: &str) -> Vec<String> { if s.is_empty() { vec![] } else { s.split(',').map(unesc).collect() } }

fn auto_init() -> Result<State, i32> { let b = branch_name()?; if let Some(s) = load_state_for(&b)? { Ok(s) } else { let base = git(&["rev-parse", "HEAD"])?; let st = State { base, ..Default::default() }; save_state_for(&b, &st)?; Ok(st) } }
fn cmd_init(args: &[String]) -> Result<(), i32> { ensure_repo()?; if has_help(args) { print_cmd_help("init"); return Ok(()); } let b = opt_value(args, "-b", "--branch").unwrap_or(branch_name()?); let base = git(&["rev-parse", &format!("{}", b)])?; let st = State { base, ..Default::default() }; save_state_for(&b, &st) }

fn cmd_new(args: &[String]) -> Result<(), i32> {
    if has_help(args) { print_cmd_help("new"); return Ok(()); }
    let mut st = auto_init()?; let mut name: Option<String> = opt_value(args, "-n", "--name"); let mut msg: Option<String> = None; let mut refresh = false; let mut paths = Vec::new(); let mut after_dd = false; let mut i=0;
    while i<args.len() { let a=&args[i]; if after_dd { paths.push(a.clone()); i+=1; continue; } match a.as_str() { "--" => after_dd=true, "-m"|"--message" => { if i+1<args.len(){ msg=Some(args[i+1].clone()); i+=1; } }, "-r"|"--refresh" => refresh=true, "-i"|"--index"|"-F"|"--force"|"-e"|"--edit"|"-d"|"--diff" => {}, x if x.starts_with('-') => {}, x => if name.is_none(){ name=Some(x.trim_start_matches('\\').to_string()) } else { paths.push(x.to_string()) } } i+=1; }
    let message = msg.unwrap_or_else(|| name.clone().unwrap_or_else(|| "patch".into()));
    let pname = name.unwrap_or_else(|| slug(&message));
    if st.patches.contains_key(&pname) { eprintln!("stg: patch '{}' already exists", pname); return Err(1); }
    if refresh || !paths.is_empty() { if paths.is_empty() { git_ok(&["add", "-A"])?; } else { let mut v=vec!["add"]; for p in &paths { v.push(p); } git_ok(&v)?; } git_ok(&["commit", "--allow-empty", "-m", &message])?; } else { git_ok(&["commit", "--allow-empty", "-m", &message])?; }
    let commit = git(&["rev-parse", "HEAD"])?; update_patch_ref(&pname, &commit).ok();
    st.applied.push(pname.clone()); st.patches.insert(pname.clone(), Patch{name:pname.clone(), commit, message, hidden:false}); save_state(&st)?; println!("> {} (new)", pname); Ok(())
}
fn slug(s: &str) -> String { let mut out = String::new(); for c in s.to_lowercase().chars() { if c.is_ascii_alphanumeric() { out.push(c) } else if c.is_whitespace() || c=='-' || c=='_' { if !out.ends_with('-') { out.push('-') } } } let out=out.trim_matches('-').to_string(); if out.is_empty(){"patch".into()} else {out} }
fn update_patch_ref(name: &str, commit: &str) -> Result<(), i32> { let b=branch_name()?; git_ok(&["update-ref", &format!("refs/patches/{}/{}", b, name), commit]) }

fn cmd_refresh(args: &[String]) -> Result<(), i32> {
    if has_help(args) { print_cmd_help("refresh"); return Ok(()); }
    let mut st = load_state()?; let patch = opt_value(args,"-p","--patch").or_else(|| st.applied.last().cloned()).ok_or_else(|| { eprintln!("stg: no patches applied"); 1 })?;
    if Some(&patch) != st.applied.last() { eprintln!("stg: refreshing non-top patches is not supported"); return Err(1); }
    let paths: Vec<String> = args.iter().filter(|a| !a.starts_with('-')).cloned().collect();
    if paths.is_empty() { git_ok(&["add", "-A"])?; } else { let mut v=vec!["add"]; for p in &paths { v.push(p); } git_ok(&v)?; }
    git_ok(&["commit", "--amend", "--allow-empty", "--no-edit"])?;
    let commit=git(&["rev-parse","HEAD"])?; if let Some(p)=st.patches.get_mut(&patch){p.commit=commit.clone();} update_patch_ref(&patch,&commit).ok(); save_state(&st)
}
fn cmd_series(args: &[String]) -> Result<(), i32> { if has_help(args){print_cmd_help("series");return Ok(());} let st=load_state()?; let count=args.iter().any(|a|a=="-c"||a=="--count"); let all=args.iter().any(|a|a=="-a"||a=="--all"); let only_a=args.iter().any(|a|a=="-A"||a=="--applied"); let only_u=args.iter().any(|a|a=="-U"||a=="--unapplied"); let only_h=args.iter().any(|a|a=="-H"||a=="--hidden"); let desc=args.iter().any(|a|a=="-d"||a=="--description"); let cid=args.iter().any(|a|a.starts_with("--commit-id")||a=="-i"); let reverse=args.iter().any(|a|a=="--reverse"); let mut rows:Vec<(char,String)>=Vec::new(); if !only_u&&!only_h { for (idx,n) in st.applied.iter().enumerate(){ rows.push((if idx+1==st.applied.len(){'>'}else{'+'},n.clone())); }} if !only_a&&!only_h { for n in &st.unapplied{rows.push(('-',n.clone()));}} if (all||only_h)&&!only_a&&!only_u { for n in &st.hidden{rows.push(('!',n.clone()));}} if reverse{rows.reverse();} if count{println!("{}",rows.len());return Ok(());} for (p,n) in rows{ let pa=st.patches.get(&n); if cid { let id=pa.map(|x|x.commit.as_str()).unwrap_or(""); let id=&id[..std::cmp::min(id.len(),8)]; if desc { println!("{} {} {} # {}",p,id,n,pa.map(|x|x.message.as_str()).unwrap_or("")); } else { println!("{} {} {}",p,id,n); } } else if desc { println!("{} {} # {}",p,n,pa.map(|x|x.message.as_str()).unwrap_or("")); } else { println!("{} {}",p,n); } } Ok(()) }
fn cmd_top(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("top");return Ok(());} let st=load_state()?; if let Some(n)=st.applied.last(){println!("{}",n);Ok(())}else{eprintln!("error: no patches applied");Err(2)}}
fn cmd_next(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("next");return Ok(());} let st=load_state()?; if let Some(n)=st.unapplied.first(){println!("{}",n);Ok(())}else{eprintln!("error: no unapplied patches");Err(2)}}
fn cmd_prev(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("prev");return Ok(());} let st=load_state()?; if st.applied.len()>=2{println!("{}",st.applied[st.applied.len()-2]);Ok(())}else{eprintln!("error: not enough patches applied");Err(2)}}
fn cmd_pop(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("pop");return Ok(());} let mut st=load_state()?; let n=if args.iter().any(|a|a=="-a"||a=="--all"){st.applied.len()}else{opt_value(args,"-n","--number").and_then(|x|x.parse::<isize>().ok()).map(|x|if x<0{st.applied.len().saturating_sub((-x)as usize)}else{x as usize}).unwrap_or(1)}; for _ in 0..n { let name=st.applied.pop().ok_or_else(||{eprintln!("stg: no patches applied");1})?; git_ok(&["reset","--hard","HEAD^"])?; st.unapplied.insert(0,name.clone()); println!("- {}",name); } save_state(&st) }
fn cmd_push(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("push");return Ok(());} let mut st=load_state()?; let n=if args.iter().any(|a|a=="-a"||a=="--all"){st.unapplied.len()}else{opt_value(args,"-n","--number").and_then(|x|x.parse::<isize>().ok()).map(|x|if x<0{st.unapplied.len().saturating_sub((-x)as usize)}else{x as usize}).unwrap_or(1)}; for _ in 0..n { let name=st.unapplied.first().cloned().ok_or_else(||{eprintln!("stg: no unapplied patches");1})?; let commit=st.patches.get(&name).unwrap().commit.clone(); git_silent(&["cherry-pick","--allow-empty",&commit])?; let newc=git(&["rev-parse","HEAD"])?; if let Some(p)=st.patches.get_mut(&name){p.commit=newc.clone();} update_patch_ref(&name,&newc).ok(); st.unapplied.remove(0); st.applied.push(name.clone()); println!("> {}",name); } save_state(&st) }
fn resolve_rev(st:&State, rev:Option<&String>)->Result<String,i32>{ let r=rev.map(|s|s.as_str()).unwrap_or("HEAD"); if r=="{base}"||r=="base"{return Ok(st.base.clone())} let name=r.split(':').last().unwrap_or(r).trim_end_matches('^'); if let Some(p)=st.patches.get(name){ if r.ends_with('^'){return Ok(format!("{}^",p.commit))} return Ok(p.commit.clone()) } Ok(r.to_string()) }
fn cmd_id(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("id");return Ok(());} let st=load_state().unwrap_or_default(); let rev=resolve_rev(&st,args.iter().find(|a|!a.starts_with('-')))?; println!("{}",git(&["rev-parse",&rev])?); Ok(()) }
fn cmd_name(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("name");return Ok(());} let st=load_state()?; let rev = resolve_rev(&st,args.iter().find(|a|!a.starts_with('-')))?; let target=git(&["rev-parse",&rev])?; for p in st.patches.values(){ if git(&["rev-parse",&p.commit])?==target{println!("{}",p.name);return Ok(());} } Err(1) }
fn cmd_files(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("files");return Ok(());} let st=load_state()?; let stat=args.iter().any(|a|a=="-s"||a=="--stat"); let rev=resolve_rev(&st,args.iter().find(|a|!a.starts_with('-')))?; if stat{run_git_passthrough(&["diff","--stat",&format!("{}^",rev),&rev],&[])}else{let out=git(&["diff","--name-only",&format!("{}^",rev),&rev])?; if !out.is_empty(){println!("{}",out);} Ok(())} }
fn cmd_diff(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("diff");return Ok(());} let stat=args.iter().any(|a|a=="-s"||a=="--stat"); let mut range=None; let mut paths=Vec::new(); let mut i=0; while i<args.len(){ if args[i]=="-r"||args[i]=="--range"{ if i+1<args.len(){range=Some(args[i+1].clone());i+=1;} } else if !args[i].starts_with('-'){paths.push(args[i].clone());} i+=1;} let st=load_state().unwrap_or_default(); let mut prefix:Vec<String>=vec!["diff".into()]; if stat{prefix.push("--stat".into())} if let Some(r)=range{ let ps:Vec<&str>=r.split("..").collect(); if ps.len()==2{prefix.push(resolve_rev(&st,Some(&ps[0].to_string()))?);prefix.push(resolve_rev(&st,Some(&ps[1].to_string()))?);}else{prefix.push(r)} } prefix.extend(paths); run_cmd("git",&prefix) }
fn cmd_show(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("show");return Ok(());} let st=load_state().unwrap_or_default(); let stat=args.iter().any(|a|a=="-s"||a=="--stat"); let mut revs:Vec<String>=args.iter().filter(|a|!a.starts_with('-')).cloned().collect(); if revs.is_empty(){ if let Some(n)=st.applied.last(){revs.push(n.clone())}else{revs.push("HEAD".into())} } let mut a=vec!["show".to_string()]; if stat{a.push("--stat".into())} for r in revs{a.push(resolve_rev(&st,Some(&r))?)} run_cmd("git",&a) }
fn run_cmd(prog:&str,args:&[String])->Result<(),i32>{ let st=Command::new(prog).args(args).status().map_err(|e|{eprintln!("stg: {}",e);1})?; if st.success(){Ok(())}else{Err(st.code().unwrap_or(1))} }
fn cmd_branch(args:&[String])->Result<(),i32>{ if has_help(args){print_cmd_help("branch");return Ok(());} if args.is_empty(){println!("{}",branch_name()?);return Ok(());} if args[0]=="-l"||args[0]=="--list"{ let cur=branch_name()?; let branches=git(&["branch","--format=%(refname:short)"])?; for b in branches.lines(){ if b==cur{println!("> s \t{}  |", b)}else{println!("  s \t{}  |", b)} } return Ok(())} if args[0]=="-c"||args[0]=="--create"{ if args.len()<2{return Err(1)}; let start=args.get(2).map(|s|s.as_str()).unwrap_or("HEAD"); git_ok(&["checkout","-b",&args[1],start])?; return cmd_init(&[])} if args[0]=="-D"||args[0]=="--delete"{ if args.len()<2{return Err(1)}; return git_ok(&["branch","-D",&args[1]])} if args[0]=="-r"||args[0]=="--rename"{return run_git_passthrough(&["branch","-m"],&args[1..])} git_ok(&["checkout",&args[0]]) }
fn cmd_delete(args:&[String])->Result<(),i32>{ let mut st=load_state()?; for n in args.iter().filter(|a|!a.starts_with('-')){ st.applied.retain(|x|x!=n); st.unapplied.retain(|x|x!=n); st.hidden.retain(|x|x!=n); st.patches.remove(n); } save_state(&st) }
fn cmd_rename(args:&[String])->Result<(),i32>{ let mut vals=args.iter().filter(|a|!a.starts_with('-')); let old=vals.next().ok_or(1)?.clone(); let new=vals.next().ok_or(1)?.clone(); let mut st=load_state()?; if let Some(mut p)=st.patches.remove(&old){p.name=new.clone(); st.patches.insert(new.clone(),p); for v in [&mut st.applied,&mut st.unapplied,&mut st.hidden]{for x in v.iter_mut(){if *x==old{*x=new.clone()}}} save_state(&st)}else{Err(1)} }
fn cmd_completion(args:&[String])->Result<(),i32>{ if args.first().map(|s|s.as_str())==Some("list"){println!("branch\nclean\ndiff\nfiles\nid\ninit\nnew\nnext\npop\nprev\npush\nrefresh\nseries\nshow\nstatus\ntop\nversion");} Ok(()) }
fn opt_value(args:&[String], short:&str, long:&str)->Option<String>{ let mut i=0; while i<args.len(){ if args[i]==short||args[i]==long{ return args.get(i+1).cloned(); } if let Some(v)=args[i].strip_prefix(&(long.to_string()+"=")){return Some(v.to_string())} i+=1;} None }
fn has_help(args:&[String])->bool{args.iter().any(|a|a=="-h"||a=="--help")}
fn print_version(){ println!("{}",VERSION); println!("Copyright (C) 2005-2025 StGit authors"); println!("This is free software: you are free to change and redistribute it."); println!("There is NO WARRANTY, to the extent permitted by law."); println!("SPDX-License-Identifier: GPL-2.0-only"); if let Ok(v)=git(&["--version"]){println!("{}",v)} }
fn print_main_help(long:bool){ println!("Maintain a stack of patches on top of a Git branch.\n\nUsage: stg [OPTIONS] <command> [...]\n       stg [OPTIONS] <-h|--help>\n       stg --version\n"); println!("Patch inspection commands:\n  diff   Show a diff\n  files  Show files modified by a patch\n  id     Print git hash of a StGit revision\n  name   Print patch name of a StGit revision\n  show   Show patch commits\n"); println!("Patch manipulation commands:\n  new      Create a new patch at top of the stack\n  refresh  Incorporate worktree changes into current patch\n  rename   Rename a patch\n"); println!("Stack inspection commands:\n  next     Print the name of the next patch\n  prev     Print the name of the previous patch\n  series   Display the patch series\n  top      Print the name of the top patch\n"); println!("Stack manipulation commands:\n  branch  Branch operations\n  init    Initialize a StGit stack on a branch\n  pop     Pop patches\n  push    Push patches\n\nAdministration commands:\n  completion  Support for shell completions\n  version     Print version information and exit\n\nAliases:\n  add mv resolved rm status\n"); if long{println!("Options:\n      --version       Print version information\n  -C <path>           Run as if started in <path>\n      --color <when>  When to colorize output: auto, always, ansi, never\n  -h, --help          Print help");} }
fn print_cmd_help(c:&str){ match c { "new"=>println!("Create a new, empty patch on the current stack.\n\nUsage: stg new [OPTIONS] [patchname] [-- <path>...]\n\nOptions:\n  -m, --message <message>\n  -n, --name <name>\n  -r, --refresh\n  -h, --help"), "series"=>println!("Show all the patches in the series.\n\nUsage: stg series [OPTIONS]\n\nOptions:\n  -a, --all\n  -A, --applied\n  -U, --unapplied\n  -H, --hidden\n  -c, --count\n  -d, --description\n  -i, --commit-id[=<length>]\n  -h, --help"), _=>println!("Usage: stg {} [OPTIONS]",c) } }
