use std::env;
use std::fs;
use std::os::unix::fs::MetadataExt;
use std::path::{Path, PathBuf};

const HELP: &str = "Usage: ./executable [options] <path> [<path>..]\n\nOptions:\n    -d, --depth [DEPTH] show directories up to depth N (def 1)\n    -a, --aggr [N[KMG]] aggregate smaller than N B/KiB/MiB/GiB (def 1M)\n    -s, --summary       equivalent to -da, or -d1 -a1M\n    -u, --usage         report real disk usage instead of file size\n    -b, --bytes         print sizes in bytes\n    -f, --files-only    skip directories for a fast local overview\n    -x, --exclude NAME  exclude matching files or directories\n    -H, --no-hidden     exclude hidden files\n    -A, --ascii         ASCII characters only, no colors\n    -h, --help          show help\n    -v, --version       print version number\n";

#[derive(Clone)]
struct Opts {
    depth: usize,
    aggr: u64,
    usage: bool,
    bytes: bool,
    files_only: bool,
    no_hidden: bool,
    ascii: bool,
    excludes: Vec<String>,
    paths: Vec<String>,
}

#[derive(Clone)]
struct Node {
    name: String,
    size: u64,
    is_dir: bool,
    children: Vec<Node>,
}

fn main() {
    let mut opts = Opts {
        depth: usize::MAX / 4,
        aggr: 0,
        usage: false,
        bytes: false,
        files_only: false,
        no_hidden: false,
        ascii: false,
        excludes: Vec::new(),
        paths: Vec::new(),
    };

    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0usize;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-h" | "--help" => { print!("{}", HELP); return; }
            "-v" | "--version" => { println!("dutree version 0.2.18"); return; }
            "-u" | "--usage" => opts.usage = true,
            "-b" | "--bytes" => opts.bytes = true,
            "-f" | "--files-only" => opts.files_only = true,
            "-H" | "--no-hidden" => opts.no_hidden = true,
            "-A" | "--ascii" => opts.ascii = true,
            "-s" | "--summary" => { opts.depth = 1; opts.aggr = 1024 * 1024; }
            "-d" | "--depth" => {
                opts.depth = 1;
                if i + 1 < args.len() {
                    if let Ok(n) = args[i + 1].parse::<usize>() {
                        opts.depth = n;
                        i += 1;
                    }
                }
            }
            "-a" | "--aggr" => {
                opts.aggr = 1024 * 1024;
                if i + 1 < args.len() {
                    if let Some(n) = parse_size(&args[i + 1]) {
                        opts.aggr = n;
                        i += 1;
                    } else {
                        eprintln!("invalid argument '{}'", args[i + 1]);
                        std::process::exit(1);
                    }
                }
            }
            "-x" | "--exclude" => {
                if i + 1 < args.len() {
                    opts.excludes.push(args[i + 1].clone());
                    i += 1;
                }
            }
            _ if a.starts_with("--depth=") => {
                opts.depth = a[8..].parse().unwrap_or(1);
            }
            _ if a.starts_with("--aggr=") => {
                opts.aggr = parse_size(&a[7..]).unwrap_or(1024 * 1024);
            }
            _ if a.starts_with('-') && a.len() > 1 => {
                print!("{}", HELP);
                let ch = a.trim_start_matches('-').chars().next().unwrap_or('?');
                eprintln!("Unrecognized option: '{}'", ch);
                std::process::exit(1);
            }
            _ => opts.paths.push(a.clone()),
        }
        i += 1;
    }
    if opts.paths.is_empty() { opts.paths.push(".".to_string()); }

    let mut roots = Vec::new();
    for p in &opts.paths {
        let path = PathBuf::from(p);
        if !path.exists() {
            eprintln!("path {} doesn't exist", p);
            std::process::exit(1);
        }
        if let Some(n) = build_node(&path, &opts) { roots.push(n); }
    }

    if roots.is_empty() { return; }
    let root = if roots.len() == 1 {
        roots.remove(0)
    } else {
        let total = roots.iter().map(|n| n.size).sum();
        Node { name: "<collection>".to_string(), size: total, is_dir: true, children: roots }
    };

    println!("[ {} {} ]", root.name, fmt_size(root.size, opts.bytes));
    print_children(&root.children, root.size, "", opts.depth, &opts);
}

fn parse_size(s: &str) -> Option<u64> {
    if s.is_empty() { return None; }
    let mut digits = String::new();
    let mut suffix = String::new();
    for c in s.chars() {
        if c.is_ascii_digit() { digits.push(c); } else { suffix.push(c); }
    }
    if digits.is_empty() { return None; }
    let base: u64 = digits.parse().ok()?;
    let mult = match suffix.as_str() {
        "" | "B" | "b" => 1,
        "K" | "k" => 1024,
        "M" | "m" => 1024 * 1024,
        "G" | "g" => 1024 * 1024 * 1024,
        _ => return Some(base),
    };
    Some(base.saturating_mul(mult))
}

fn build_node(path: &Path, opts: &Opts) -> Option<Node> {
    let name = display_name(path);
    if excluded(&name, opts) { return None; }
    let md = fs::symlink_metadata(path).ok()?;
    let is_dir = md.is_dir();
    let own = if opts.usage { md.blocks().saturating_mul(512) } else { md.size() };
    if is_dir && !opts.files_only {
        let mut children = Vec::new();
        if let Ok(rd) = fs::read_dir(path) {
            for ent in rd.flatten() {
                if let Some(child) = build_node(&ent.path(), opts) { children.push(child); }
            }
        }
        children.sort_by(|a, b| b.size.cmp(&a.size).then_with(|| a.name.cmp(&b.name)));
        let total = own.saturating_add(children.iter().map(|c| c.size).sum::<u64>());
        Some(Node { name, size: total, is_dir: true, children })
    } else if is_dir && opts.files_only {
        let mut children = Vec::new();
        if let Ok(rd) = fs::read_dir(path) {
            for ent in rd.flatten() {
                let p = ent.path();
                if fs::symlink_metadata(&p).map(|m| !m.is_dir()).unwrap_or(false) {
                    if let Some(child) = build_node(&p, opts) { children.push(child); }
                }
            }
        }
        children.sort_by(|a, b| b.size.cmp(&a.size).then_with(|| a.name.cmp(&b.name)));
        let total = own.saturating_add(children.iter().map(|c| c.size).sum::<u64>());
        Some(Node { name, size: total, is_dir: true, children })
    } else {
        Some(Node { name, size: own, is_dir: false, children: Vec::new() })
    }
}

fn display_name(path: &Path) -> String {
    if path == Path::new(".") {
        env::current_dir().ok().and_then(|p| p.file_name().map(|s| s.to_string_lossy().to_string())).unwrap_or_else(|| ".".into())
    } else {
        path.file_name().map(|s| s.to_string_lossy().to_string()).unwrap_or_else(|| path.display().to_string())
    }
}

fn excluded(name: &str, opts: &Opts) -> bool {
    if opts.no_hidden && name.starts_with('.') { return true; }
    opts.excludes.iter().any(|x| x == name || name.contains(x))
}

fn print_children(children: &[Node], parent_size: u64, prefix: &str, depth: usize, opts: &Opts) {
    if depth == 0 { return; }
    let mut visible: Vec<Node> = Vec::new();
    let mut agg = 0u64;
    for c in children {
        if c.size < opts.aggr {
            agg = agg.saturating_add(c.size);
        } else {
            visible.push(c.clone());
        }
    }
    if agg > 0 {
        visible.push(Node { name: "<aggregated>".into(), size: agg, is_dir: false, children: Vec::new() });
    }
    visible.sort_by(|a, b| b.size.cmp(&a.size).then_with(|| a.name.cmp(&b.name)));
    let max_sib = visible.iter().map(|n| n.size).max().unwrap_or(1);
    for (idx, n) in visible.iter().enumerate() {
        let last = idx + 1 == visible.len();
        print_line(n, parent_size, max_sib, prefix, last, opts);
        if n.is_dir && !n.children.is_empty() {
            let next_prefix = format!("{}{}", prefix, if last { "   " } else { "│  " });
            print_children(&n.children, n.size, &next_prefix, depth - 1, opts);
        }
    }
}

fn print_line(n: &Node, parent_size: u64, max_sib: u64, prefix: &str, last: bool, opts: &Opts) {
    let connector = if last { "└─" } else { "├─" };
    let raw_name = truncate_chars(&n.name, 22usize.saturating_sub(prefix.chars().count()));
    let label = format!("{}{} {}", prefix, connector, raw_name);
    let label_width = 26usize;
    let pad = label_width.saturating_sub(label.chars().count());
    let pct = if parent_size == 0 { 0 } else { ((n.size as f64 / parent_size as f64) * 100.0).floor() as u64 };
    let bar = make_bar(n.size, max_sib, opts.ascii);
    println!("{}{}│ {}│{:>4}% {:>12}", label, " ".repeat(pad), bar, pct, fmt_size(n.size, opts.bytes));
}

fn make_bar(size: u64, max: u64, ascii: bool) -> String {
    let width = 32usize;
    let ch = if ascii { '#' } else { '█' };
    let filled = if max == 0 || size == 0 { 0 } else { ((size as f64 / max as f64) * width as f64).floor() as usize };
    let filled = filled.min(width);
    format!("{}{}", " ".repeat(width - filled), ch.to_string().repeat(filled))
}

fn truncate_chars(s: &str, max: usize) -> String {
    if s.chars().count() <= max { s.to_string() } else { s.chars().take(max).collect() }
}

fn fmt_size(n: u64, bytes: bool) -> String {
    if bytes { return format!("{} B", n); }
    if n < 1024 { return format!("{} B", n); }
    let kib = n as f64 / 1024.0;
    if kib < 1024.0 { return format!("{:.2} KiB", kib); }
    let mib = kib / 1024.0;
    if mib < 1024.0 { return format!("{:.2} MiB", mib); }
    format!("{:.2} GiB", mib / 1024.0)
}
