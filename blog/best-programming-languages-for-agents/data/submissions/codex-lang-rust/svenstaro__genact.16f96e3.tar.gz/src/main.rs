use rand::{rngs::SmallRng, RngExt};
use std::env;
use std::io::{self, Write};
use std::process;
use std::thread;
use std::time::{Duration, Instant};

const MODULES: &[&str] = &[
    "ansible",
    "bootlog",
    "botnet",
    "bruteforce",
    "cargo",
    "cc",
    "composer",
    "cryptomining",
    "docker_build",
    "docker_image_rm",
    "download",
    "julia",
    "kernel_compile",
    "memdump",
    "mkinitcpio",
    "rkhunter",
    "simcity",
    "terraform",
    "uv",
    "weblog",
    "wpt",
];

#[derive(Clone)]
struct Config {
    modules: Vec<String>,
    speed: f64,
    instant: usize,
    exit_after_modules: Option<usize>,
    exit_after_time: Option<Duration>,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let cfg = parse_or_exit(&args);
    run(cfg);
}

fn parse_or_exit(args: &[String]) -> Config {
    let mut cfg = Config {
        modules: Vec::new(),
        speed: 1.0,
        instant: 0,
        exit_after_modules: None,
        exit_after_time: None,
    };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-h" | "--help" => {
                print_help();
                process::exit(0);
            }
            "-V" | "--version" => {
                println!("genact 1.5.1");
                process::exit(0);
            }
            "-l" | "--list-modules" => {
                print_modules();
                process::exit(0);
            }
            "--print-manpage" => {
                print_manpage();
                process::exit(0);
            }
            "--inhibit" => {}
            "-m" | "--modules" => {
                i += 1;
                let v = require_value(args, i, a);
                if !MODULES.contains(&v) {
                    invalid_module(v);
                }
                cfg.modules.push(v.to_string());
            }
            "-s" | "--speed-factor" => {
                i += 1;
                let v = require_value(args, i, a);
                cfg.speed = v.parse::<f64>().unwrap_or_else(|_| {
                    eprintln!(
                        "error: invalid value '{}' for '--speed-factor <SPEED_FACTOR>': invalid float literal\n\nFor more information, try '--help'.",
                        v
                    );
                    process::exit(2);
                });
            }
            "-i" | "--instant-print-lines" => {
                i += 1;
                let v = require_value(args, i, a);
                cfg.instant = v.parse::<usize>().unwrap_or_else(|_| {
                    eprintln!(
                        "error: invalid value '{}' for '--instant-print-lines <INSTANT_PRINT_LINES>': invalid digit found in string\n\nFor more information, try '--help'.",
                        v
                    );
                    process::exit(2);
                });
            }
            "--exit-after-modules" => {
                i += 1;
                let v = require_value(args, i, a);
                cfg.exit_after_modules = Some(v.parse::<usize>().unwrap_or_else(|_| {
                    eprintln!(
                        "error: invalid value '{}' for '--exit-after-modules <EXIT_AFTER_MODULES>': invalid digit found in string\n\nFor more information, try '--help'.",
                        v
                    );
                    process::exit(2);
                }));
            }
            "--exit-after-time" => {
                i += 1;
                let v = require_value(args, i, a);
                cfg.exit_after_time = Some(parse_duration(v).unwrap_or_else(|| {
                    eprintln!("Error: failed to parse duration");
                    process::exit(1);
                }));
            }
            "--print-completions" => {
                i += 1;
                let shell = require_value(args, i, a);
                print_completion(shell);
                process::exit(0);
            }
            _ if a.starts_with("--modules=") => {
                let v = &a["--modules=".len()..];
                if !MODULES.contains(&v) {
                    invalid_module(v);
                }
                cfg.modules.push(v.to_string());
            }
            _ if a.starts_with("--speed-factor=") => {
                let v = &a["--speed-factor=".len()..];
                cfg.speed = v.parse().unwrap_or(1.0);
            }
            _ => {
                eprintln!("error: unexpected argument '{}'\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.", a);
                process::exit(2);
            }
        }
        i += 1;
    }
    if cfg.modules.is_empty() {
        cfg.modules = MODULES.iter().map(|s| s.to_string()).collect();
    }
    cfg
}

fn require_value<'a>(args: &'a [String], i: usize, opt: &str) -> &'a str {
    if i >= args.len() {
        eprintln!("error: a value is required for '{}' but none was supplied\n\nFor more information, try '--help'.", opt);
        process::exit(2);
    }
    &args[i]
}

fn invalid_module(v: &str) -> ! {
    eprintln!(
        "error: invalid value '{}' for '--modules <MODULES>'\n  [possible values: {}]\n\nFor more information, try '--help'.",
        v,
        MODULES.join(", ")
    );
    process::exit(2);
}

fn parse_duration(s: &str) -> Option<Duration> {
    let mut total = 0u64;
    let mut num = String::new();
    let mut unit = String::new();
    for c in s.chars() {
        if c.is_ascii_digit() {
            if !unit.is_empty() {
                total += unit_to_secs(num.parse().ok()?, &unit)?;
                num.clear();
                unit.clear();
            }
            num.push(c);
        } else {
            unit.push(c);
        }
    }
    if !num.is_empty() {
        total += unit_to_secs(num.parse().ok()?, if unit.is_empty() { "s" } else { &unit })?;
    }
    Some(Duration::from_secs(total.max(1)))
}

fn unit_to_secs(n: u64, u: &str) -> Option<u64> {
    match u {
        "s" | "sec" | "secs" | "second" | "seconds" => Some(n),
        "m" | "min" | "mins" | "minute" | "minutes" => Some(n * 60),
        "h" | "hr" | "hrs" | "hour" | "hours" => Some(n * 3600),
        _ => None,
    }
}

fn print_help() {
    println!(
        "A nonsense activity generator\n\nUsage: executable [OPTIONS]\n\nOptions:\n  -l, --list-modules\n          List available modules\n  -m, --modules <MODULES>\n          Run only these modules [possible values: ansible, bootlog, botnet, bruteforce, cargo, cc,\n          composer, cryptomining, docker_build, docker_image_rm, download, julia, kernel_compile,\n          memdump, mkinitcpio, rkhunter, simcity, terraform, uv, weblog, wpt]\n  -s, --speed-factor <SPEED_FACTOR>\n          Global speed factor [default: 1]\n  -i, --instant-print-lines <INSTANT_PRINT_LINES>\n          Instantly print this many lines [default: 0]\n      --inhibit\n          Keep the computer awake and the display on while genact is running\n      --exit-after-time <EXIT_AFTER_TIME>\n          Exit after running for this long (format example: 2h10min)\n      --exit-after-modules <EXIT_AFTER_MODULES>\n          Exit after running this many modules\n      --print-completions <shell>\n          Generate completion file for a shell [possible values: bash, elvish, fish, powershell,\n          zsh]\n      --print-manpage\n          Generate man page\n  -h, --help\n          Print help\n  -V, --version\n          Print version"
    );
}

fn print_modules() {
    println!("Available modules:");
    for m in MODULES {
        println!("  {}", m);
    }
}

fn print_completion(shell: &str) {
    match shell {
        "bash" => println!("{}", BASH_COMPLETION),
        "fish" => println!("complete -c genact -s l -l list-modules -d 'List available modules'\ncomplete -c genact -s m -l modules -xa '{}'\ncomplete -c genact -s h -l help -d 'Print help'\ncomplete -c genact -s V -l version -d 'Print version'", MODULES.join(" ")),
        "zsh" => println!("#compdef genact\n_arguments '-l[List available modules]' '-m[Run only these modules]:MODULES:({})' '-h[Print help]' '-V[Print version]'", MODULES.join(" ")),
        "elvish" => println!("edit:completion:arg-completer[genact] = {{|@words| put -- --help --version --list-modules --modules }}"),
        "powershell" => println!("Register-ArgumentCompleter -Native -CommandName 'genact' -ScriptBlock {{ param($wordToComplete) '--help','--version','--list-modules','--modules' | Where-Object {{ $_ -like \"$wordToComplete*\" }} }}"),
        _ => {
            eprintln!("error: invalid value '{}' for '--print-completions <shell>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.", shell);
            process::exit(2);
        }
    }
}

const BASH_COMPLETION: &str = r#"_genact() {
    local i cur prev opts cmd
    COMPREPLY=()
    cur="${COMP_WORDS[COMP_CWORD]}"
    prev="${COMP_WORDS[COMP_CWORD-1]}"
    opts="-l -m -s -i -h -V --list-modules --modules --speed-factor --instant-print-lines --inhibit --exit-after-time --exit-after-modules --print-completions --print-manpage --help --version"
    case "${prev}" in
        --modules|-m)
            COMPREPLY=($(compgen -W "ansible bootlog botnet bruteforce cargo cc composer cryptomining docker_build docker_image_rm download julia kernel_compile memdump mkinitcpio rkhunter simcity terraform uv weblog wpt" -- "${cur}"))
            return 0
            ;;
        --print-completions)
            COMPREPLY=($(compgen -W "bash elvish fish powershell zsh" -- "${cur}"))
            return 0
            ;;
    esac
    COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
    return 0
}
complete -F _genact -o nosort -o bashdefault -o default genact"#;

fn print_manpage() {
    println!(".ie \\n(.g .ds Aq \\(aq\n.el .ds Aq '\n.TH genact 1  \"genact 1.5.1\" \n.SH NAME\ngenact \\- A nonsense activity generator\n.SH SYNOPSIS\n\\fBgenact\\fR [\\fB\\-l\\fR|\\fB\\-\\-list\\-modules\\fR] [\\fB\\-m\\fR|\\fB\\-\\-modules\\fR] [\\fB\\-s\\fR|\\fB\\-\\-speed\\-factor\\fR] [\\fB\\-i\\fR|\\fB\\-\\-instant\\-print\\-lines\\fR] [\\fB\\-\\-inhibit\\fR] [\\fB\\-\\-exit\\-after\\-time\\fR] [\\fB\\-\\-exit\\-after\\-modules\\fR] [\\fB\\-\\-print\\-completions\\fR] [\\fB\\-\\-print\\-manpage\\fR] [\\fB\\-h\\fR|\\fB\\-\\-help\\fR] [\\fB\\-V\\fR|\\fB\\-\\-version\\fR] \n.SH DESCRIPTION\nA nonsense activity generator\n.SH OPTIONS\n.TP\n\\fB\\-l\\fR, \\fB\\-\\-list\\-modules\\fR\nList available modules\n.TP\n\\fB\\-m\\fR, \\fB\\-\\-modules\\fR \\fI<MODULES>\\fR\nRun only these modules\n.br\n\n.br\n\\fIPossible values:\\fR");
    for m in MODULES {
        println!(".IP \\(bu 2\n{}", m);
    }
    println!(".TP\n\\fB\\-s\\fR, \\fB\\-\\-speed\\-factor\\fR \\fI<SPEED_FACTOR>\\fR [default: 1]\nGlobal speed factor\n.TP\n\\fB\\-i\\fR, \\fB\\-\\-instant\\-print\\-lines\\fR \\fI<INSTANT_PRINT_LINES>\\fR [default: 0]\nInstantly print this many lines\n.TP\n\\fB\\-\\-inhibit\\fR\nKeep the computer awake and the display on while genact is running\n.TP\n\\fB\\-\\-exit\\-after\\-time\\fR \\fI<EXIT_AFTER_TIME>\\fR\nExit after running for this long (format example: 2h10min)\n.TP\n\\fB\\-\\-exit\\-after\\-modules\\fR \\fI<EXIT_AFTER_MODULES>\\fR\nExit after running this many modules\n.TP\n\\fB\\-\\-print\\-completions\\fR \\fI<shell>\\fR\nGenerate completion file for a shell\n.TP\n\\fB\\-\\-print\\-manpage\\fR\nGenerate man page\n.TP\n\\fB\\-h\\fR, \\fB\\-\\-help\\fR\nPrint help\n.TP\n\\fB\\-V\\fR, \\fB\\-\\-version\\fR\nPrint version\n.SH VERSION\nv1.5.1\n.SH AUTHORS\nSven\\-Hendrik Haase <svenstaro@gmail.com>");
}

fn run(cfg: Config) {
    let start = Instant::now();
    let limit = cfg.exit_after_modules.unwrap_or(usize::MAX);
    let mut rng: SmallRng = rand::make_rng();
    let mut done = 0usize;
    'outer: loop {
        let mods = cfg.modules.clone();
        for m in mods {
            if done >= limit {
                break 'outer;
            }
            if let Some(d) = cfg.exit_after_time {
                if start.elapsed() >= d {
                    break 'outer;
                }
            }
            run_module(&m, &cfg, &mut rng, start);
            done += 1;
            if cfg.exit_after_modules.is_none() && cfg.exit_after_time.is_none() {
                continue;
            }
        }
        if cfg.exit_after_modules.is_some() || cfg.exit_after_time.is_some() {
            if cfg.exit_after_modules.map_or(false, |n| done >= n) {
                break;
            }
        }
    }
}

fn run_module(name: &str, cfg: &Config, rng: &mut SmallRng, start: Instant) {
    let lines = if cfg.instant > 0 { cfg.instant.max(4) } else { 60 };
    for i in 0..lines {
        if let Some(d) = cfg.exit_after_time {
            if start.elapsed() >= d {
                break;
            }
        }
        println!("{}", module_line(name, i, rng));
        let _ = io::stdout().flush();
        if i >= cfg.instant {
            let ms = (80.0 / cfg.speed.max(0.01)) as u64;
            thread::sleep(Duration::from_millis(ms.min(500)));
        }
    }
}

fn module_line(name: &str, i: usize, rng: &mut SmallRng) -> String {
    match name {
        "cargo" => format!("\x1b[1;32m Downloading\x1b[0m {} v{}.{}.{}", pick(rng, &["serde", "tokio", "syn", "rand", "clap", "libcratesio", "amethyst_engine"]), rng.random_range(0..3), rng.random_range(0..20), rng.random_range(0..150)),
        "cc" | "kernel_compile" => format!("clang -c -O{} -Wall -Wextra -Wno-parentheses -funroll-loops -mtune=generic -I{} -D{} -o {}", rng.random_range(0..3), pick(rng, &["arch/x86/kernel", "drivers/gpu/drm", "net/ipv4", "sound/core", "kernel/trace"]), pick(rng, &["DEBUG", "NDEBUG", "PIC", "NAMESPACE=lib"]), object_path(rng)),
        "ansible" => format!("TASK [{}] {}", pick(rng, &["Gathering Facts", "Install packages", "Template configuration", "Restart service"]), stars(i)),
        "bootlog" => format!("[  {:>5}.{:06}] {}: {}", rng.random_range(0..999), rng.random_range(0..999999), pick(rng, &["systemd", "kernel", "udevd", "NetworkManager"]), pick(rng, &["Started session", "Reached target", "Mounted filesystem", "Link is up"])),
        "botnet" => format!("{}:{} accepted command {} bytes={}", ip(rng), rng.random_range(1024..65535), pick(rng, &["PING", "UPDATE", "SCAN", "EXEC"]), rng.random_range(32..8192)),
        "bruteforce" => format!("Trying password '{}' for user {} ... {}", word(rng), pick(rng, &["root", "admin", "oracle", "deploy"]), pick(rng, &["failed", "denied", "timeout"])),
        "composer" => format!("  - Installing {} ({})", pick(rng, &["symfony/console", "psr/log", "monolog/monolog", "laravel/framework"]), version(rng)),
        "cryptomining" => format!("[{} H/s] accepted share {} diff {}", rng.random_range(20..950), rng.random_range(100000..999999), rng.random_range(1..4096)),
        "docker_build" => format!("Step {}/{} : {}", (i % 12) + 1, 12, pick(rng, &["FROM ubuntu:22.04", "RUN apt-get update", "COPY . /app", "RUN cargo build --release"])),
        "docker_image_rm" => format!("Untagged: {}:{}", pick(rng, &["ubuntu", "alpine", "redis", "postgres"]), pick(rng, &["latest", "stable", "dev"])),
        "download" => format!("Downloading {} [{:>3}%] {} KB/s", pick(rng, &["backup.tar.zst", "dataset.bin", "video.mp4", "image.raw"]), rng.random_range(0..100), rng.random_range(50..9999)),
        "julia" => format!("  Activating project at `~/src/{}`\nPrecompiling project... {} dependencies successfully precompiled", pick(rng, &["Stats", "Plots", "DifferentialEquations"]), rng.random_range(1..38)),
        "memdump" => format!("{:08x}: {}", i * 16, (0..16).map(|_| format!("{:02x}", rng.random::<u8>())).collect::<Vec<_>>().join(" ")),
        "mkinitcpio" => format!("==> {} {}", pick(rng, &["Building image", "Generating module dependencies", "Creating gzip-compressed initcpio image", "Image generation successful"]), pick(rng, &["/boot/initramfs-linux.img", "/lib/modules", ""])),
        "rkhunter" => format!("Checking {} ... [ {} ]", pick(rng, &["system commands", "rootkits", "network ports", "startup files"]), pick(rng, &["OK", "Not found", "Warning"])),
        "simcity" => format!("{} zone demand: {}  population: {}", pick(rng, &["Residential", "Commercial", "Industrial"]), rng.random_range(-200..800), rng.random_range(1000..900000)),
        "terraform" => format!("{}: {} {}", pick(rng, &["aws_instance.web", "aws_vpc.main", "random_id.bucket", "module.database"]), pick(rng, &["Refreshing state...", "Creating...", "Still creating...", "Creation complete after"]), rng.random_range(1..50)),
        "uv" => format!("Resolved {} packages in {}ms", rng.random_range(10..240), rng.random_range(20..3000)),
        "weblog" => format!("{} - - [31/May/2026:20:{:02}:{:02} +0000] \"{} {} HTTP/1.1\" {} {}", ip(rng), rng.random_range(0..59), rng.random_range(0..59), pick(rng, &["GET", "POST", "PUT"]), pick(rng, &["/", "/api/v1/users", "/favicon.ico", "/wp-login.php"]), pick(rng, &["200", "301", "404", "500"]), rng.random_range(128..65536)),
        "wpt" => format!("Test {} ... {}", pick(rng, &["css/css-grid", "html/dom", "fetch/api", "websockets/basic"]), pick(rng, &["PASS", "OK", "TIMEOUT", "FAIL"])),
        _ => format!("{}: working...", name),
    }
}

fn pick<'a>(rng: &mut SmallRng, xs: &'a [&str]) -> &'a str {
    xs[rng.random_range(0..xs.len())]
}
fn object_path(rng: &mut SmallRng) -> String {
    format!("{}/{}.o", pick(rng, &["arch/alpha/kernel", "arch/x86/mm", "drivers/net", "fs/ext4", "kernel/sched"]), pick(rng, &["init", "module", "main", "inode", "irq"]))
}
fn ip(rng: &mut SmallRng) -> String {
    format!("{}.{}.{}.{}", rng.random_range(1..224), rng.random_range(0..255), rng.random_range(0..255), rng.random_range(1..255))
}
fn word(rng: &mut SmallRng) -> &'static str {
    pick(rng, &["password", "123456", "letmein", "qwerty", "hunter2", "admin"])
}
fn version(rng: &mut SmallRng) -> String {
    format!("v{}.{}.{}", rng.random_range(0..9), rng.random_range(0..20), rng.random_range(0..50))
}
fn stars(i: usize) -> String {
    "*".repeat((i % 20) + 1)
}
