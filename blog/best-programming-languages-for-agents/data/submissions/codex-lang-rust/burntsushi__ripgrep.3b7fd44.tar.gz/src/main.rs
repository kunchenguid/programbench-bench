use regex::{Regex, RegexBuilder};
use serde_json::json;
use std::collections::{HashSet, VecDeque};
use std::env;
use std::ffi::OsStr;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

const VERSION: &str = "ripgrep 14.1.1 (rev 719e15af5e)";

#[derive(Default, Debug)]
struct Opts {
    patterns: Vec<String>,
    pattern_files: Vec<String>,
    paths: Vec<String>,
    fixed: bool,
    ignore_case: bool,
    smart_case: bool,
    invert: bool,
    word: bool,
    line: bool,
    files: bool,
    type_list: bool,
    json: bool,
    quiet: bool,
    count: bool,
    count_matches: bool,
    files_with_matches: bool,
    files_without_match: bool,
    only_matching: bool,
    line_number: Option<bool>,
    with_filename: Option<bool>,
    column: bool,
    byte_offset: bool,
    hidden: bool,
    unrestricted: u8,
    no_ignore: bool,
    follow: bool,
    max_depth: Option<usize>,
    max_count: Option<usize>,
    after: usize,
    before: usize,
    context: usize,
    replace: Option<String>,
    glob: Vec<String>,
    sort: bool,
    null: bool,
    no_messages: bool,
    passthru: bool,
    trim: bool,
    max_columns: Option<usize>,
}

#[derive(Clone)]
struct MatchLine {
    path: Option<String>,
    line_no: usize,
    byte_offset: usize,
    text: String,
    ranges: Vec<(usize, usize)>,
    is_context: bool,
}

fn main() {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.is_empty() {
        print_short_help();
        std::process::exit(0);
    }
    expand_config(&mut args);
    let opts = match parse(args) {
        Ok(o) => o,
        Err(e) => {
            eprintln!("rg: {e}");
            std::process::exit(2);
        }
    };
    if opts.type_list {
        print_type_list();
        return;
    }
    if opts.files {
        let code = run_files(&opts);
        std::process::exit(code);
    }
    let code = run_search(&opts);
    std::process::exit(code);
}

fn expand_config(args: &mut Vec<String>) {
    if args.iter().any(|a| a == "--no-config") {
        return;
    }
    let mut cfg = Vec::new();
    if let Ok(path) = env::var("RIPGREP_CONFIG_PATH") {
        if !path.is_empty() {
            if let Ok(s) = fs::read_to_string(path) {
                for line in s.lines() {
                    let t = line.trim();
                    if !t.is_empty() && !t.starts_with('#') {
                        cfg.push(t.to_string());
                    }
                }
            }
        }
    }
    if !cfg.is_empty() {
        cfg.extend(args.clone());
        *args = cfg;
    }
}

fn parse(args: Vec<String>) -> Result<Opts, String> {
    let mut opts = Opts::default();
    let mut positional = Vec::new();
    let mut i = 0;
    let mut only_pos = false;
    while i < args.len() {
        let a = &args[i];
        if only_pos || !a.starts_with('-') || a == "-" {
            positional.push(a.clone());
            i += 1;
            continue;
        }
        if a == "--" {
            only_pos = true;
            i += 1;
            continue;
        }
        match a.as_str() {
            "-h" | "--help" => {
                if a == "-h" { print_short_help(); } else { print_long_help(); }
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("{VERSION}\n\nfeatures:-pcre2\nsimd(compile):+SSE2,-SSSE3,-AVX2\nsimd(runtime):+SSE2,+SSSE3,+AVX2\n\nPCRE2 is not available in this build of ripgrep.");
                std::process::exit(0);
            }
            "--pcre2-version" => {
                println!("PCRE2 is not available in this build of ripgrep.");
                std::process::exit(0);
            }
            "--type-list" => opts.type_list = true,
            "--files" => opts.files = true,
            "--json" => opts.json = true,
            "-F" | "--fixed-strings" => opts.fixed = true,
            "--no-fixed-strings" => opts.fixed = false,
            "-i" | "--ignore-case" => opts.ignore_case = true,
            "-s" | "--case-sensitive" => { opts.ignore_case = false; opts.smart_case = false; }
            "-S" | "--smart-case" => opts.smart_case = true,
            "-v" | "--invert-match" => opts.invert = true,
            "-w" | "--word-regexp" => opts.word = true,
            "-x" | "--line-regexp" => opts.line = true,
            "-n" | "--line-number" => opts.line_number = Some(true),
            "-N" | "--no-line-number" => opts.line_number = Some(false),
            "-H" | "--with-filename" => opts.with_filename = Some(true),
            "-I" | "--no-filename" => opts.with_filename = Some(false),
            "-c" | "--count" => opts.count = true,
            "--count-matches" => opts.count_matches = true,
            "-l" | "--files-with-matches" => opts.files_with_matches = true,
            "--files-without-match" => opts.files_without_match = true,
            "-o" | "--only-matching" => opts.only_matching = true,
            "--column" => opts.column = true,
            "-b" | "--byte-offset" => opts.byte_offset = true,
            "-q" | "--quiet" => opts.quiet = true,
            "-." | "--hidden" => opts.hidden = true,
            "-u" | "--unrestricted" => opts.unrestricted = opts.unrestricted.saturating_add(1),
            "-uu" => opts.unrestricted = opts.unrestricted.max(2),
            "-uuu" => opts.unrestricted = opts.unrestricted.max(3),
            "--no-ignore" => opts.no_ignore = true,
            "-L" | "--follow" => opts.follow = true,
            "--passthru" => opts.passthru = true,
            "--trim" => opts.trim = true,
            "--no-messages" => opts.no_messages = true,
            "--sort" | "--sortr" => { let _ = take_value(&args, &mut i, a)?; opts.sort = true; }
            "--sort-files" => opts.sort = true,
            "--color" | "--colors" | "--engine" | "--encoding" | "-E" | "--dfa-size-limit" | "--regex-size-limit" | "--threads" | "-j" | "--max-filesize" | "--path-separator" | "--context-separator" | "--field-context-separator" | "--field-match-separator" | "--hyperlink-format" | "--hostname-bin" | "--pre" | "--pre-glob" | "--type-add" | "--type-clear" | "-t" | "-T" | "--type" | "--type-not" | "--ignore-file" => {
                let _ = take_value(&args, &mut i, a)?;
            }
            "--mmap" | "--no-mmap" | "--multiline" | "-U" | "--multiline-dotall" | "--no-unicode" | "--null-data" | "--crlf" | "--no-crlf" | "--text" | "-a" | "--binary" | "--glob-case-insensitive" | "--ignore-file-case-insensitive" | "--no-ignore-dot" | "--no-ignore-exclude" | "--no-ignore-files" | "--no-ignore-global" | "--no-ignore-parent" | "--no-ignore-vcs" | "--no-require-git" | "--one-file-system" | "--block-buffered" | "--line-buffered" | "--include-zero" | "--max-columns-preview" | "--pretty" | "-p" | "--vimgrep" | "--debug" | "--trace" | "--stats" | "--no-ignore-messages" | "--search-zip" | "-z" | "--no-search-zip" | "--auto-hybrid-regex" | "--pcre2" | "-P" | "--no-pcre2-unicode" | "--no-config" => {}
            "-0" | "--null" => opts.null = true,
            _ if a.starts_with("--regexp=") => opts.patterns.push(a[9..].to_string()),
            _ if a.starts_with("-e") && a.len() > 2 => opts.patterns.push(a[2..].to_string()),
            "-e" | "--regexp" => opts.patterns.push(take_value(&args, &mut i, a)?),
            _ if a.starts_with("--file=") => opts.pattern_files.push(a[7..].to_string()),
            _ if a.starts_with("-f") && a.len() > 2 => opts.pattern_files.push(a[2..].to_string()),
            "-f" | "--file" => opts.pattern_files.push(take_value(&args, &mut i, a)?),
            _ if a.starts_with("--glob=") => opts.glob.push(a[7..].to_string()),
            _ if a.starts_with("-g") && a.len() > 2 => opts.glob.push(a[2..].to_string()),
            "-g" | "--glob" | "--iglob" => opts.glob.push(take_value(&args, &mut i, a)?),
            _ if a.starts_with("--max-depth=") => opts.max_depth = a[12..].parse().ok(),
            "-d" | "--max-depth" => opts.max_depth = take_value(&args, &mut i, a)?.parse().ok(),
            _ if a.starts_with("-d") && a.len() > 2 => opts.max_depth = a[2..].parse().ok(),
            _ if a.starts_with("--max-count=") => opts.max_count = a[12..].parse().ok(),
            "-m" | "--max-count" => opts.max_count = take_value(&args, &mut i, a)?.parse().ok(),
            _ if a.starts_with("-m") && a.len() > 2 => opts.max_count = a[2..].parse().ok(),
            "-A" | "--after-context" => opts.after = take_value(&args, &mut i, a)?.parse().unwrap_or(0),
            _ if a.starts_with("-A") && a.len() > 2 => opts.after = a[2..].parse().unwrap_or(0),
            "-B" | "--before-context" => opts.before = take_value(&args, &mut i, a)?.parse().unwrap_or(0),
            _ if a.starts_with("-B") && a.len() > 2 => opts.before = a[2..].parse().unwrap_or(0),
            "-C" | "--context" => opts.context = take_value(&args, &mut i, a)?.parse().unwrap_or(0),
            _ if a.starts_with("-C") && a.len() > 2 => opts.context = a[2..].parse().unwrap_or(0),
            "-M" | "--max-columns" => opts.max_columns = take_value(&args, &mut i, a)?.parse().ok(),
            _ if a.starts_with("-M") && a.len() > 2 => opts.max_columns = a[2..].parse().ok(),
            "-r" | "--replace" => opts.replace = Some(take_value(&args, &mut i, a)?),
            _ if a.starts_with("-r") && a.len() > 2 => opts.replace = Some(a[2..].to_string()),
            _ if short_cluster(a, &mut opts) => {}
            _ => return Err(format!("unrecognized flag {a}")),
        }
        i += 1;
    }
    for pf in opts.pattern_files.clone() {
        let s = if pf == "-" {
            let mut buf = String::new();
            io::stdin().read_to_string(&mut buf).map_err(|e| e.to_string())?;
            buf
        } else {
            fs::read_to_string(&pf).map_err(|e| format!("{pf}: {e}"))?
        };
        opts.patterns.extend(s.lines().map(|l| l.to_string()));
    }
    if opts.patterns.is_empty() && !opts.files && !opts.type_list {
        if positional.is_empty() {
            return Err("a pattern is required".to_string());
        }
        opts.patterns.push(positional.remove(0));
    }
    opts.paths = positional;
    if opts.context > 0 {
        opts.before = opts.context;
        opts.after = opts.context;
    }
    if opts.unrestricted >= 2 {
        opts.hidden = true;
    }
    if opts.unrestricted >= 1 {
        opts.no_ignore = true;
    }
    Ok(opts)
}

fn take_value(args: &[String], i: &mut usize, flag: &str) -> Result<String, String> {
    if let Some((_, v)) = flag.split_once('=') {
        return Ok(v.to_string());
    }
    *i += 1;
    args.get(*i).cloned().ok_or_else(|| format!("the argument '{flag}' requires a value"))
}

fn short_cluster(a: &str, o: &mut Opts) -> bool {
    if !a.starts_with('-') || a.starts_with("--") || a.len() <= 2 {
        return false;
    }
    for ch in a[1..].chars() {
        match ch {
            'i' => o.ignore_case = true,
            'S' => o.smart_case = true,
            'F' => o.fixed = true,
            'v' => o.invert = true,
            'w' => o.word = true,
            'x' => o.line = true,
            'n' => o.line_number = Some(true),
            'N' => o.line_number = Some(false),
            'H' => o.with_filename = Some(true),
            'I' => o.with_filename = Some(false),
            'c' => o.count = true,
            'l' => o.files_with_matches = true,
            'o' => o.only_matching = true,
            'q' => o.quiet = true,
            'u' => o.unrestricted = o.unrestricted.saturating_add(1),
            _ => return false,
        }
    }
    true
}

fn build_regex(opts: &Opts) -> Result<Regex, String> {
    let mut pats = if opts.patterns.is_empty() { vec!["".to_string()] } else { opts.patterns.clone() };
    for p in &mut pats {
        if opts.fixed {
            *p = regex::escape(p);
        }
        if opts.word {
            *p = format!(r"\b(?:{})\b", p);
        }
        if opts.line {
            *p = format!(r"^(?:{})$", p);
        }
    }
    let pat = if pats.len() == 1 { pats[0].clone() } else { format!("(?:{})", pats.join(")|(?:")) };
    let ignore_case = opts.ignore_case || (opts.smart_case && !opts.patterns.iter().any(|p| p.chars().any(|c| c.is_uppercase())));
    RegexBuilder::new(&pat).case_insensitive(ignore_case).build().map_err(|e| e.to_string())
}

fn run_search(opts: &Opts) -> i32 {
    let re = match build_regex(opts) {
        Ok(r) => r,
        Err(e) => {
            eprintln!("rg: regex parse error:\n    {e}");
            return 2;
        }
    };
    let files = collect_paths(opts);
    let mut had_match = false;
    let mut had_error = false;
    let stdin_only = files.len() == 1 && files[0] == Path::new("-");
    let show_path = opts.with_filename.unwrap_or(!stdin_only && (files.len() > 1 || paths_are_recursive(opts)));
    let show_line = opts.line_number.unwrap_or(false);
    if opts.json {
        println!("{}", json!({"type":"begin","data":{"path":{"text":""}}}));
    }
    for path in files {
        match search_file(&path, &re, opts, show_path, show_line) {
            Ok(m) => {
                if opts.files_without_match {
                    had_match |= !m;
                } else {
                    had_match |= m;
                }
            }
            Err(e) => {
                had_error = true;
                if !opts.no_messages {
                    eprintln!("rg: {}: IO error for operation on {}: {}", path.display(), path.display(), e);
                }
            }
        }
        if opts.quiet && had_match {
            return 0;
        }
    }
    if opts.json {
        println!("{}", json!({"type":"summary","data":{"stats":{"matches":0,"matched_lines":0,"searches":0,"searches_with_match":0,"bytes_searched":0,"bytes_printed":0},"elapsed_total":{"secs":0,"nanos":0,"human":"0.000000s"}}}));
    }
    if had_error { 2 } else if had_match { 0 } else { 1 }
}

fn run_files(opts: &Opts) -> i32 {
    let mut files = collect_paths(opts);
    if opts.sort {
        files.sort();
    }
    let sep = if opts.null { "\0" } else { "\n" };
    for f in files {
        print!("{}{}", display_path(&f), sep);
    }
    0
}

fn collect_paths(opts: &Opts) -> Vec<PathBuf> {
    let roots: Vec<PathBuf> = if opts.paths.is_empty() {
        if !opts.files && stdin_is_pipe() {
            vec![PathBuf::from("-")]
        } else {
            vec![PathBuf::from(".")]
        }
    } else { opts.paths.iter().map(PathBuf::from).collect() };
    let mut out = Vec::new();
    for root in roots {
        if root.is_file() || (opts.follow && fs::metadata(&root).map(|m| m.is_file()).unwrap_or(false)) {
            out.push(root);
        } else if root.is_dir() {
            walk(&root, 0, opts, &mut out);
        } else {
            out.push(root);
        }
    }
    if opts.sort {
        out.sort();
    }
    out
}

fn stdin_is_pipe() -> bool {
    fs::read_link("/proc/self/fd/0")
        .map(|p| p.to_string_lossy().starts_with("pipe:"))
        .unwrap_or(false)
}

fn walk(dir: &Path, depth: usize, opts: &Opts, out: &mut Vec<PathBuf>) {
    if opts.max_depth.map(|m| depth > m).unwrap_or(false) {
        return;
    }
    let entries = match fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    let mut dirs = Vec::new();
    let mut files = Vec::new();
    for ent in entries.flatten() {
        let path = ent.path();
        let name = ent.file_name();
        if should_skip(&path, &name, opts, path.is_dir()) {
            continue;
        }
        let ft = if opts.follow { fs::metadata(&path).ok() } else { ent.metadata().ok() };
        if let Some(md) = ft {
            if md.is_dir() {
                dirs.push(path);
            } else if md.is_file() {
                if glob_ok(&path, opts) {
                    files.push(path);
                }
            }
        }
    }
    dirs.sort();
    files.sort();
    for d in dirs {
        walk(&d, depth + 1, opts, out);
    }
    out.extend(files);
}

fn should_skip(path: &Path, name: &OsStr, opts: &Opts, is_dir: bool) -> bool {
    let s = name.to_string_lossy();
    if !opts.hidden && s.starts_with('.') {
        return true;
    }
    if is_dir && (s == ".git" || s == "target") {
        return true;
    }
    if !opts.no_ignore && ignored_by_simple_gitignore(path) {
        return true;
    }
    false
}

fn ignored_by_simple_gitignore(path: &Path) -> bool {
    let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
    let mut dir = path.parent();
    while let Some(d) = dir {
        for fname in [".ignore", ".rgignore", ".gitignore"] {
            let f = d.join(fname);
            if let Ok(s) = fs::read_to_string(f) {
                for line in s.lines() {
                    let t = line.trim();
                    if t.is_empty() || t.starts_with('#') || t.starts_with('!') {
                        continue;
                    }
                    let pat = t.trim_end_matches('/');
                    if pat == name || pat == "*" || (pat.starts_with("*.") && name.ends_with(&pat[1..])) {
                        return true;
                    }
                }
            }
        }
        dir = d.parent();
    }
    false
}

fn glob_ok(path: &Path, opts: &Opts) -> bool {
    if opts.glob.is_empty() {
        return true;
    }
    let s = path.to_string_lossy();
    let mut ok = true;
    for g in &opts.glob {
        let neg = g.starts_with('!');
        let pat = if neg { &g[1..] } else { g.as_str() };
        if simple_glob(&s, pat) || path.file_name().and_then(|n| n.to_str()).map(|n| simple_glob(n, pat)).unwrap_or(false) {
            ok = !neg;
        }
    }
    ok
}

fn simple_glob(text: &str, pat: &str) -> bool {
    if pat == "*" { return true; }
    if let Some(rest) = pat.strip_prefix("*.") { return text.ends_with(&format!(".{rest}")); }
    if pat.contains('*') {
        let parts: Vec<_> = pat.split('*').collect();
        let mut pos = 0;
        for part in parts {
            if part.is_empty() { continue; }
            if let Some(i) = text[pos..].find(part) { pos += i + part.len(); } else { return false; }
        }
        true
    } else {
        text == pat || text.ends_with(&format!("/{pat}"))
    }
}

fn search_file(path: &Path, re: &Regex, opts: &Opts, show_path: bool, show_line: bool) -> io::Result<bool> {
    let data = if path == Path::new("-") {
        let mut data = Vec::new();
        io::stdin().read_to_end(&mut data)?;
        data
    } else {
        fs::read(path)?
    };
    if opts.unrestricted < 3 && !opts.passthru && data.iter().take(1024).any(|&b| b == 0) {
        return Ok(false);
    }
    let text = String::from_utf8_lossy(&data).into_owned();
    let mut had = false;
    let mut match_count = 0usize;
    let mut line_count = 0usize;
    let mut before_buf: VecDeque<MatchLine> = VecDeque::new();
    let mut printed_context: HashSet<usize> = HashSet::new();
    let mut pending_after = 0usize;
    let mut byte = 0usize;
    for (idx, raw) in text.split_inclusive('\n').enumerate() {
        let line_no = idx + 1;
        let line = raw.trim_end_matches('\n').trim_end_matches('\r').to_string();
        let ranges: Vec<(usize, usize)> = re.find_iter(&line).map(|m| (m.start(), m.end())).collect();
        let is_match = (!ranges.is_empty()) ^ opts.invert;
        if is_match || opts.passthru {
            if is_match {
                had = true;
                line_count += 1;
                match_count += if opts.invert { 1 } else { ranges.len().max(1) };
            }
            if opts.quiet {
                return Ok(true);
            }
            if !opts.count && !opts.count_matches && !opts.files_with_matches && !opts.files_without_match {
                if is_match {
                    while let Some(ctx) = before_buf.pop_front() {
                        if ctx.is_context && printed_context.insert(ctx.line_no) {
                            print_line(&ctx, opts, show_path, show_line, true);
                        }
                    }
                }
                if is_match || opts.passthru {
                    let ml = MatchLine { path: Some(display_path(path)), line_no, byte_offset: byte, text: line.clone(), ranges: ranges.clone(), is_context: !is_match };
                    print_line(&ml, opts, show_path, show_line, !is_match);
                    printed_context.insert(line_no);
                    pending_after = if is_match { opts.after } else { pending_after.saturating_sub(1) };
                }
            }
        } else if pending_after > 0 && !opts.count && !opts.count_matches {
            let ml = MatchLine { path: Some(display_path(path)), line_no, byte_offset: byte, text: line.clone(), ranges: Vec::new(), is_context: true };
            if printed_context.insert(line_no) {
                print_line(&ml, opts, show_path, show_line, true);
            }
            pending_after -= 1;
        }
        if opts.before > 0 {
            let ml = MatchLine { path: Some(display_path(path)), line_no, byte_offset: byte, text: line, ranges, is_context: !is_match };
            before_buf.push_back(ml);
            while before_buf.len() > opts.before {
                before_buf.pop_front();
            }
        }
        byte += raw.len();
        if opts.max_count.map(|m| line_count >= m).unwrap_or(false) {
            break;
        }
    }
    if opts.count || opts.count_matches {
        let n = if opts.count_matches { match_count } else { line_count };
        if show_path { print!("{}:", display_path(path)); }
        println!("{n}");
    } else if opts.files_with_matches && had {
        println!("{}", display_path(path));
    } else if opts.files_without_match && !had {
        println!("{}", display_path(path));
    }
    Ok(had)
}

fn print_line(ml: &MatchLine, opts: &Opts, show_path: bool, show_line: bool, context: bool) {
    if opts.json {
        if !context {
            println!("{}", json!({"type":"match","data":{"path":{"text":ml.path.clone().unwrap_or_default()},"lines":{"text":format!("{}\n", ml.text)},"line_number":ml.line_no,"absolute_offset":ml.byte_offset,"submatches":ml.ranges.iter().map(|(s,e)| json!({"match":{"text":&ml.text[*s..*e]},"start":s,"end":e})).collect::<Vec<_>>()}}));
        }
        return;
    }
    let sep = if context || ml.is_context { "-" } else { ":" };
    if opts.only_matching && !context && !opts.invert {
        for (s, e) in &ml.ranges {
            print_prefix(ml, opts, show_path, show_line, sep, Some(*s));
            println!("{}", &ml.text[*s..*e]);
        }
        return;
    }
    print_prefix(ml, opts, show_path, show_line, sep, None);
    let mut out = if let Some(rep) = &opts.replace {
        if !context { build_regex_for_replace(opts).map(|r| r.replace_all(&ml.text, rep.as_str()).to_string()).unwrap_or_else(|| ml.text.clone()) } else { ml.text.clone() }
    } else {
        ml.text.clone()
    };
    if opts.trim {
        out = out.trim_start().to_string();
    }
    if let Some(m) = opts.max_columns {
        if out.chars().count() > m {
            return;
        }
    }
    println!("{out}");
}

fn build_regex_for_replace(opts: &Opts) -> Option<Regex> {
    build_regex(opts).ok()
}

fn print_prefix(ml: &MatchLine, opts: &Opts, show_path: bool, show_line: bool, sep: &str, col: Option<usize>) {
    if show_path {
        print!("{}{}", ml.path.as_deref().unwrap_or(""), sep);
    }
    if show_line {
        print!("{}{}", ml.line_no, sep);
    }
    if opts.column {
        let c = col.unwrap_or_else(|| ml.ranges.first().map(|r| r.0).unwrap_or(0)) + 1;
        print!("{c}{sep}");
    }
    if opts.byte_offset {
        let b = ml.byte_offset + col.unwrap_or(0);
        print!("{b}{sep}");
    }
}

fn display_path(p: &Path) -> String {
    let s = p.to_string_lossy();
    s.strip_prefix("./").unwrap_or(&s).to_string()
}

fn paths_are_recursive(opts: &Opts) -> bool {
    opts.paths.is_empty() || opts.paths.iter().any(|p| Path::new(p).is_dir())
}

fn print_short_help() {
    println!("{VERSION}\nAndrew Gallant <jamslam@gmail.com>\n\nripgrep (rg) recursively searches the current directory for lines matching\na regex pattern. By default, ripgrep will respect gitignore rules and\nautomatically skip hidden files/directories and binary files.\n\nUSAGE:\n  rg [OPTIONS] PATTERN [PATH ...]\n\nCommon options: -i, -F, -n, -H, -I, -c, -l, -o, -v, -w, -x, -A, -B, -C, --files, --type-list, --help, --version");
}

fn print_long_help() {
    println!("{VERSION}\nAndrew Gallant <jamslam@gmail.com>\n\nripgrep (rg) recursively searches the current directory for lines matching\na regex pattern. By default, ripgrep will respect gitignore rules and\nautomatically skip hidden files/directories and binary files.\n\nUse -h for short descriptions and --help for more details.\n\nUSAGE:\n    rg [OPTIONS] PATTERN [PATH ...]\n    rg [OPTIONS] -e PATTERN ... [PATH ...]\n    rg [OPTIONS] -f PATTERNFILE ... [PATH ...]\n    rg [OPTIONS] --files [PATH ...]\n    rg [OPTIONS] --type-list\n    command | rg [OPTIONS] PATTERN\n\nSEARCH OPTIONS:\n    -F, --fixed-strings    Treat all patterns as literals.\n    -i, --ignore-case      Case insensitive search.\n    -S, --smart-case       Smart case search.\n    -v, --invert-match     Invert matching.\n    -w, --word-regexp      Show matches surrounded by word boundaries.\n    -x, --line-regexp      Show matches surrounded by line boundaries.\n\nOUTPUT OPTIONS:\n    -n, --line-number      Show line numbers.\n    -H, --with-filename    Print the file path with each matching line.\n    -I, --no-filename      Never print the path with each matching line.\n    -o, --only-matching    Print only matched parts of a line.\n    -c, --count            Show count of matching lines for each file.\n    -l, --files-with-matches Print the paths with at least one match.\n\nOTHER BEHAVIORS:\n    --files                Print each file that would be searched.\n    --type-list            Show all supported file types.\n    -V, --version          Print ripgrep's version.");
}

fn print_type_list() {
    let types = [
        ("rust", "*.rs"), ("py", "*.py"), ("python", "*.py"), ("c", "*.c, *.h"),
        ("cpp", "*.cpp, *.cc, *.hpp"), ("js", "*.js, *.jsx"), ("ts", "*.ts, *.tsx"),
        ("go", "*.go"), ("java", "*.java"), ("md", "*.md, *.markdown"),
        ("json", "*.json"), ("toml", "*.toml"), ("yaml", "*.yaml, *.yml"),
        ("html", "*.html, *.htm"), ("css", "*.css"), ("sh", "*.sh, *.bash"),
    ];
    for (name, globs) in types {
        println!("{name}: {globs}");
    }
}
