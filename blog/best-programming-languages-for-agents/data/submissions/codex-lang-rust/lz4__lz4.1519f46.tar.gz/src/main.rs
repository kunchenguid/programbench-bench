use std::env;
use std::fs::{self, File};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

const VERSION: &str = "*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***";
const MAGIC: u32 = 0x184D2204;
const LEGACY_MAGIC: u32 = 0x184C2102;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Mode {
    Auto,
    Compress,
    Decompress,
    Test,
    List,
    Benchmark,
}

struct Config {
    mode: Mode,
    force: bool,
    stdout: bool,
    multiple: bool,
    recursive: bool,
    remove: bool,
    quiet: u8,
    content_size: bool,
    no_frame_crc: bool,
    block_size_id: u8,
    block_checksum: bool,
    legacy: bool,
    positional: Vec<String>,
}

fn main() {
    let code = match run() {
        Ok(()) => 0,
        Err(e) => {
            if e.quiet < 2 && !e.message.is_empty() {
                eprintln!("{}", e.message);
            }
            e.code
        }
    };
    std::process::exit(code);
}

struct CliError {
    code: i32,
    quiet: u8,
    message: String,
}

impl CliError {
    fn new(code: i32, quiet: u8, message: impl Into<String>) -> Self {
        Self { code, quiet, message: message.into() }
    }
}

fn run() -> Result<(), CliError> {
    let mut cfg = Config {
        mode: Mode::Auto,
        force: false,
        stdout: false,
        multiple: false,
        recursive: false,
        remove: false,
        quiet: 0,
        content_size: false,
        no_frame_crc: false,
        block_size_id: 7,
        block_checksum: false,
        legacy: false,
        positional: Vec::new(),
    };

    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0usize;
    while i < args.len() {
        let a = &args[i];
        if a == "--" {
            cfg.positional.extend(args[i + 1..].iter().cloned());
            break;
        } else if !a.starts_with('-') || a == "-" {
            cfg.positional.push(a.clone());
        } else if a == "--help" {
            print_help(false);
            return Ok(());
        } else if a == "--version" {
            println!("{}", VERSION);
            return Ok(());
        } else if a == "--compress" {
            cfg.mode = Mode::Compress;
        } else if a == "--decompress" || a == "--uncompress" {
            cfg.mode = Mode::Decompress;
        } else if a == "--test" {
            cfg.mode = Mode::Test;
        } else if a == "--list" {
            cfg.mode = Mode::List;
        } else if a == "--rm" {
            cfg.remove = true;
        } else if a == "--keep" {
            cfg.remove = false;
        } else if a == "--force" {
            cfg.force = true;
        } else if a == "--quiet" {
            cfg.quiet = cfg.quiet.saturating_add(1);
        } else if a == "--content-size" {
            cfg.content_size = true;
        } else if a == "--no-frame-crc" {
            cfg.no_frame_crc = true;
        } else if a == "--best" {
        } else if a == "--no-sparse" || a == "--sparse" || a == "--favor-decSpeed" {
        } else if a.starts_with("--fast") {
        } else if a.starts_with('-') {
            parse_short(a, &args, &mut i, &mut cfg)?;
        }
        i += 1;
    }

    if cfg.mode == Mode::Benchmark {
        return benchmark(&cfg);
    }
    if cfg.mode == Mode::List {
        return list_files(&cfg);
    }
    let mode = effective_mode(&cfg);
    if cfg.multiple || cfg.recursive || cfg.positional.len() > 2 {
        return process_multiple(&cfg, mode);
    }
    process_single(&cfg, mode)
}

fn parse_short(a: &str, args: &[String], i: &mut usize, cfg: &mut Config) -> Result<(), CliError> {
    let s = &a[1..];
    if s.is_empty() {
        cfg.positional.push(a.to_string());
        return Ok(());
    }
    let bytes = s.as_bytes();
    let mut p = 0usize;
    while p < bytes.len() {
        let c = bytes[p] as char;
        match c {
            'h' => {
                print_help(false);
                std::process::exit(0);
            }
            'H' => {
                print_help(true);
                std::process::exit(0);
            }
            'V' => {
                println!("{}", VERSION);
                std::process::exit(0);
            }
            'd' => cfg.mode = Mode::Decompress,
            'z' => cfg.mode = Mode::Compress,
            't' => cfg.mode = Mode::Test,
            'f' => cfg.force = true,
            'k' => cfg.remove = false,
            'c' => cfg.stdout = true,
            'm' => cfg.multiple = true,
            'r' => {
                cfg.recursive = true;
                cfg.multiple = true;
            }
            'q' => cfg.quiet = cfg.quiet.saturating_add(1),
            'v' => {}
            'l' => cfg.legacy = true,
            'B' => {
                let rest = &s[p + 1..];
                if rest == "I" {
                    p = bytes.len();
                    continue;
                } else if rest == "D" {
                    p = bytes.len();
                    continue;
                } else if rest == "X" {
                    cfg.block_checksum = true;
                    p = bytes.len();
                    continue;
                } else if !rest.is_empty() {
                    cfg.block_size_id = parse_block_size(rest);
                    p = bytes.len();
                    continue;
                }
            }
            'D' | 'T' | 'i' | 'e' => {
                if p + 1 == bytes.len() {
                    *i += 1;
                    if *i >= args.len() {
                        return Err(incorrect(cfg.quiet));
                    }
                }
                p = bytes.len();
                continue;
            }
            'b' => {
                cfg.mode = Mode::Benchmark;
                p = bytes.len();
                continue;
            }
            '0'..='9' => {}
            _ => return Err(incorrect(cfg.quiet)),
        }
        p += 1;
    }
    Ok(())
}

fn parse_block_size(s: &str) -> u8 {
    if let Ok(n) = s.parse::<usize>() {
        match n {
            4..=7 => n as u8,
            0..=65_536 => 4,
            65_537..=262_144 => 5,
            262_145..=1_048_576 => 6,
            _ => 7,
        }
    } else {
        7
    }
}

fn incorrect(quiet: u8) -> CliError {
    let mut msg = String::from("Incorrect parameters\n");
    msg.push_str(&usage_text());
    CliError::new(1, quiet, msg)
}

fn effective_mode(cfg: &Config) -> Mode {
    if cfg.mode != Mode::Auto {
        return cfg.mode;
    }
    if let Some(first) = cfg.positional.first() {
        if first != "-" && first.ends_with(".lz4") {
            return Mode::Decompress;
        }
    }
    Mode::Compress
}

fn process_single(cfg: &Config, mode: Mode) -> Result<(), CliError> {
    let input = cfg.positional.get(0).map(String::as_str).unwrap_or("-");
    let out_arg = cfg.positional.get(1).map(String::as_str);
    match mode {
        Mode::Compress => {
            let data = read_input(input, cfg.quiet)?;
            let out = encode_frame(&data, cfg);
            write_output(cfg, input, out_arg, true, &out)?;
            if cfg.remove && input != "-" {
                let _ = fs::remove_file(input);
            }
            if cfg.quiet == 0 && input != "-" && !cfg.stdout {
                eprintln!("Compressed {} bytes into {} bytes ==> {:.2}%", data.len(), out.len(), pct(out.len(), data.len()));
            }
            Ok(())
        }
        Mode::Decompress => {
            if !cfg.stdout && cfg.positional.get(1).is_none() && input != "-" && output_name(input, false).is_none() {
                let mut m = String::from("Cannot determine an output filename \nIncorrect parameters\n");
                m.push_str(&usage_text());
                return Err(CliError::new(1, cfg.quiet, m));
            }
            let data = read_input(input, cfg.quiet)?;
            let decoded = decode_all_frames(&data).map_err(|m| CliError::new(44, cfg.quiet, m))?;
            write_output(cfg, input, out_arg, false, &decoded)?;
            if cfg.remove && input != "-" {
                let _ = fs::remove_file(input);
            }
            Ok(())
        }
        Mode::Test => {
            let data = read_input(input, cfg.quiet)?;
            let _ = decode_all_frames(&data).map_err(|m| CliError::new(40, cfg.quiet, m))?;
            if cfg.quiet == 0 {
                eprintln!("{}: decoded {} bytes", input, data.len());
            }
            Ok(())
        }
        _ => Ok(()),
    }
}

fn process_multiple(cfg: &Config, mode: Mode) -> Result<(), CliError> {
    if cfg.positional.is_empty() {
        return process_single(cfg, mode);
    }
    let mut files = Vec::new();
    for p in &cfg.positional {
        let path = PathBuf::from(p);
        if path.is_dir() && cfg.recursive {
            collect_files(&path, &mut files);
        } else {
            files.push(path);
        }
    }
    let mut failed = false;
    for p in files {
        let mut c2 = Config { positional: vec![p.to_string_lossy().to_string()], ..cfg_clone(cfg) };
        c2.multiple = false;
        c2.recursive = false;
        if process_single(&c2, mode).is_err() {
            failed = true;
        }
    }
    if failed { Err(CliError::new(1, cfg.quiet, "")) } else { Ok(()) }
}

fn cfg_clone(c: &Config) -> Config {
    Config {
        mode: c.mode, force: c.force, stdout: c.stdout, multiple: c.multiple,
        recursive: c.recursive, remove: c.remove, quiet: c.quiet,
        content_size: c.content_size, no_frame_crc: c.no_frame_crc,
        block_size_id: c.block_size_id, block_checksum: c.block_checksum,
        legacy: c.legacy, positional: c.positional.clone(),
    }
}

fn collect_files(dir: &Path, out: &mut Vec<PathBuf>) {
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let p = e.path();
            if p.is_dir() {
                collect_files(&p, out);
            } else if p.is_file() {
                out.push(p);
            }
        }
    }
}

fn read_input(input: &str, quiet: u8) -> Result<Vec<u8>, CliError> {
    let mut data = Vec::new();
    if input == "-" {
        io::stdin().read_to_end(&mut data).map_err(|e| CliError::new(1, quiet, e.to_string()))?;
    } else {
        File::open(input)
            .and_then(|mut f| f.read_to_end(&mut data))
            .map_err(|e| CliError::new(1, quiet, format!("{}: {}", input, e)))?;
    }
    Ok(data)
}

fn output_name(input: &str, compress: bool) -> Option<String> {
    if input == "-" {
        return Some("-".to_string());
    }
    if compress {
        Some(format!("{}.lz4", input))
    } else if input.ends_with(".lz4") {
        Some(input[..input.len() - 4].to_string())
    } else {
        None
    }
}

fn write_output(cfg: &Config, input: &str, out_arg: Option<&str>, compress: bool, bytes: &[u8]) -> Result<(), CliError> {
    if cfg.stdout || out_arg == Some("-") || out_arg == Some("stdout") || (out_arg.is_none() && input == "-") {
        io::stdout().write_all(bytes).map_err(|e| CliError::new(1, cfg.quiet, e.to_string()))?;
        return Ok(());
    }
    if out_arg == Some("null") {
        return Ok(());
    }
    let name = match out_arg {
        Some(s) => s.to_string(),
        None => output_name(input, compress).ok_or_else(|| {
            let mut m = String::from("Cannot determine an output filename \n");
            m.push_str(&help_text(false));
            CliError::new(1, cfg.quiet, m)
        })?,
    };
    if Path::new(&name).exists() && !cfg.force {
        return Err(CliError::new(1, cfg.quiet, format!("{} already exists; not overwritten  ", name)));
    }
    let mut f = File::create(&name).map_err(|e| CliError::new(1, cfg.quiet, format!("{}: {}", name, e)))?;
    f.write_all(bytes).map_err(|e| CliError::new(1, cfg.quiet, e.to_string()))?;
    Ok(())
}

fn encode_frame(data: &[u8], cfg: &Config) -> Vec<u8> {
    let max_block = match cfg.block_size_id { 4 => 64 * 1024, 5 => 256 * 1024, 6 => 1024 * 1024, _ => 4 * 1024 * 1024 };
    let mut out = Vec::new();
    if cfg.legacy {
        out.extend_from_slice(&LEGACY_MAGIC.to_le_bytes());
        for chunk in data.chunks(8 * 1024 * 1024) {
            out.extend_from_slice(&(chunk.len() as u32 | 0x8000_0000).to_le_bytes());
            out.extend_from_slice(chunk);
        }
        return out;
    }
    out.extend_from_slice(&MAGIC.to_le_bytes());
    let mut flg = 0x60u8;
    if cfg.content_size { flg |= 0x08; }
    if !cfg.no_frame_crc { flg |= 0x04; }
    if cfg.block_checksum { flg |= 0x10; }
    let bd = (cfg.block_size_id.clamp(4, 7)) << 4;
    let mut header = vec![flg, bd];
    if cfg.content_size {
        header.extend_from_slice(&(data.len() as u64).to_le_bytes());
    }
    let hc = ((xxh32(&header, 0) >> 8) & 0xff) as u8;
    out.extend_from_slice(&header);
    out.push(hc);
    for chunk in data.chunks(max_block) {
        out.extend_from_slice(&((chunk.len() as u32) | 0x8000_0000).to_le_bytes());
        out.extend_from_slice(chunk);
        if cfg.block_checksum {
            out.extend_from_slice(&xxh32(chunk, 0).to_le_bytes());
        }
    }
    out.extend_from_slice(&0u32.to_le_bytes());
    if !cfg.no_frame_crc {
        out.extend_from_slice(&xxh32(data, 0).to_le_bytes());
    }
    out
}

fn decode_all_frames(data: &[u8]) -> Result<Vec<u8>, String> {
    let mut pos = 0usize;
    let mut out = Vec::new();
    while pos < data.len() {
        if pos + 4 > data.len() {
            return Err("Error 40 : Unrecognized header : Magic Number unreadable ".to_string());
        }
        let magic = u32le(&data[pos..pos + 4]);
        pos += 4;
        if magic == MAGIC {
            decode_frame(data, &mut pos, &mut out)?;
        } else if magic == LEGACY_MAGIC {
            decode_legacy(data, &mut pos, &mut out)?;
        } else if magic & 0xFFFF_FFF0 == 0x184D_2A50 {
            if pos + 4 > data.len() { return Err("Error 40 : skippable frame incomplete".to_string()); }
            let len = u32le(&data[pos..pos + 4]) as usize;
            pos += 4 + len;
            if pos > data.len() { return Err("Error 40 : skippable frame incomplete".to_string()); }
        } else {
            return Err("Error 40 : Unrecognized header : Magic Number unreadable ".to_string());
        }
    }
    Ok(out)
}

fn decode_frame(data: &[u8], pos: &mut usize, out: &mut Vec<u8>) -> Result<(), String> {
    if *pos + 3 > data.len() { return Err("Error 40 : frame header incomplete".to_string()); }
    let flg = data[*pos];
    let bd = data[*pos + 1];
    *pos += 2;
    if flg >> 6 != 1 { return Err("Error 44 : unsupported frame version".to_string()); }
    if flg & 0x08 != 0 { *pos += 8; }
    if flg & 0x01 != 0 { *pos += 4; }
    if *pos >= data.len() { return Err("Error 40 : frame header incomplete".to_string()); }
    *pos += 1; // header checksum
    let max_block = match (bd >> 4) & 7 { 4 => 64 * 1024, 5 => 256 * 1024, 6 => 1024 * 1024, 7 => 4 * 1024 * 1024, _ => return Err("Error 44 : invalid block size".to_string()) };
    let frame_start = out.len();
    loop {
        if *pos + 4 > data.len() { return Err("Error 40 : block size unreadable".to_string()); }
        let raw = u32le(&data[*pos..*pos + 4]);
        *pos += 4;
        if raw == 0 { break; }
        let uncompressed = raw & 0x8000_0000 != 0;
        let len = (raw & 0x7fff_ffff) as usize;
        if len > max_block { return Err("Error 44 : block size too large".to_string()); }
        if *pos + len > data.len() { return Err("Error 40 : block truncated".to_string()); }
        let block = &data[*pos..*pos + len];
        *pos += len;
        if uncompressed {
            out.extend_from_slice(block);
        } else {
            decode_lz4_block(block, out)?;
        }
        if flg & 0x10 != 0 { *pos += 4; }
    }
    if flg & 0x04 != 0 {
        if *pos + 4 > data.len() { return Err("Error 40 : checksum unreadable".to_string()); }
        let expected = u32le(&data[*pos..*pos + 4]);
        *pos += 4;
        let got = xxh32(&out[frame_start..], 0);
        if expected != got { return Err("Error 44 : content checksum error".to_string()); }
    }
    Ok(())
}

fn decode_legacy(data: &[u8], pos: &mut usize, out: &mut Vec<u8>) -> Result<(), String> {
    while *pos < data.len() {
        if *pos + 4 > data.len() { return Err("Error 40 : block size unreadable".to_string()); }
        let len = (u32le(&data[*pos..*pos + 4]) & 0x7fff_ffff) as usize;
        *pos += 4;
        if *pos + len > data.len() { return Err("Error 40 : block truncated".to_string()); }
        let block = &data[*pos..*pos + len];
        *pos += len;
        if decode_lz4_block(block, out).is_err() {
            out.extend_from_slice(block);
        }
    }
    Ok(())
}

fn decode_lz4_block(input: &[u8], out: &mut Vec<u8>) -> Result<(), String> {
    let mut ip = 0usize;
    while ip < input.len() {
        let token = input[ip];
        ip += 1;
        let mut lit_len = (token >> 4) as usize;
        if lit_len == 15 { lit_len += read_len(input, &mut ip)?; }
        if ip + lit_len > input.len() { return Err("Error 44 : malformed literals".to_string()); }
        out.extend_from_slice(&input[ip..ip + lit_len]);
        ip += lit_len;
        if ip >= input.len() { break; }
        if ip + 2 > input.len() { return Err("Error 44 : malformed offset".to_string()); }
        let offset = (input[ip] as usize) | ((input[ip + 1] as usize) << 8);
        ip += 2;
        if offset == 0 || offset > out.len() { return Err("Error 44 : malformed offset".to_string()); }
        let mut match_len = (token & 0x0f) as usize + 4;
        if (token & 0x0f) == 15 { match_len += read_len(input, &mut ip)?; }
        let start = out.len() - offset;
        for j in 0..match_len {
            let b = out[start + j % offset];
            out.push(b);
        }
    }
    Ok(())
}

fn read_len(input: &[u8], ip: &mut usize) -> Result<usize, String> {
    let mut n = 0usize;
    loop {
        if *ip >= input.len() { return Err("Error 44 : malformed length".to_string()); }
        let b = input[*ip] as usize;
        *ip += 1;
        n += b;
        if b != 255 { return Ok(n); }
    }
}

fn u32le(b: &[u8]) -> u32 {
    u32::from_le_bytes([b[0], b[1], b[2], b[3]])
}

fn xxh32(input: &[u8], seed: u32) -> u32 {
    const P1: u32 = 2_654_435_761;
    const P2: u32 = 2_246_822_519;
    const P3: u32 = 3_266_489_917;
    const P4: u32 = 668_265_263;
    const P5: u32 = 374_761_393;
    fn round(mut acc: u32, input: u32) -> u32 {
        acc = acc.wrapping_add(input.wrapping_mul(P2));
        acc = acc.rotate_left(13);
        acc.wrapping_mul(P1)
    }
    let mut i = 0usize;
    let mut h;
    if input.len() >= 16 {
        let mut v1 = seed.wrapping_add(P1).wrapping_add(P2);
        let mut v2 = seed.wrapping_add(P2);
        let mut v3 = seed;
        let mut v4 = seed.wrapping_sub(P1);
        while i <= input.len() - 16 {
            v1 = round(v1, u32le(&input[i..i + 4])); i += 4;
            v2 = round(v2, u32le(&input[i..i + 4])); i += 4;
            v3 = round(v3, u32le(&input[i..i + 4])); i += 4;
            v4 = round(v4, u32le(&input[i..i + 4])); i += 4;
        }
        h = v1.rotate_left(1).wrapping_add(v2.rotate_left(7)).wrapping_add(v3.rotate_left(12)).wrapping_add(v4.rotate_left(18));
    } else {
        h = seed.wrapping_add(P5);
    }
    h = h.wrapping_add(input.len() as u32);
    while i + 4 <= input.len() {
        h = h.wrapping_add(u32le(&input[i..i + 4]).wrapping_mul(P3));
        h = h.rotate_left(17).wrapping_mul(P4);
        i += 4;
    }
    while i < input.len() {
        h = h.wrapping_add((input[i] as u32).wrapping_mul(P5));
        h = h.rotate_left(11).wrapping_mul(P1);
        i += 1;
    }
    h ^= h >> 15;
    h = h.wrapping_mul(P2);
    h ^= h >> 13;
    h = h.wrapping_mul(P3);
    h ^ (h >> 16)
}

fn list_files(cfg: &Config) -> Result<(), CliError> {
    println!("    Frames           Type Block  Compressed  Uncompressed    Ratio   Filename");
    let files = if cfg.positional.is_empty() { vec!["-".to_string()] } else { cfg.positional.clone() };
    let mut failed = false;
    for f in files {
        let data = match read_input(&f, cfg.quiet) {
            Ok(d) => d,
            Err(e) => return Err(e),
        };
        match decode_all_frames(&data) {
            Ok(decoded) => {
                let ratio = pct(data.len(), decoded.len());
                println!("{:10} {:>14} {:>5} {:>11} {:>13} {:>7.2}%   {}", 1, "LZ4Frame", "B7I", data.len(), decoded.len(), ratio, f);
            }
            Err(e) => {
                if cfg.quiet < 2 { eprintln!("{}", e); }
                failed = true;
            }
        }
    }
    if failed { Err(CliError::new(40, cfg.quiet, "")) } else { Ok(()) }
}

fn benchmark(cfg: &Config) -> Result<(), CliError> {
    if cfg.quiet < 2 {
        eprintln!("*** LZ4 speed analyzer 64-bits, by Yann Collet ***");
        eprintln!("Benchmark mode is approximated in this clean-room implementation");
    }
    Ok(())
}

fn pct(a: usize, b: usize) -> f64 {
    if b == 0 { 0.0 } else { (a as f64) * 100.0 / (b as f64) }
}

fn print_help(long: bool) {
    print!("{}", help_text(long));
}

fn help_text(long: bool) -> String {
    let mut s = format!("{VERSION}\n{}", usage_text());
    if long {
        s.push_str("\n****************************\n***** Advanced comment *****\n****************************\n\nWhich values can [output] have ? \n---------------------------------\n[output] : a filename \n          'stdout', or '-' for standard output (pipe mode)\n          'null' to discard output (test mode) \n[output] can be left empty. In this case, it receives the following value :\n          - if stdout is not the console, then [output] = stdout \n          - if stdout is console : \n               + for compression, output to filename.lz4 \n               + for decompression, output to filename without '.lz4'\n                    > if input filename has no '.lz4' extension : error \n\nCompression levels : \n---------------------\n-0  => Default level, identical to -1 \n-1  => Fast compression \n-2 .. -12 => High compression; higher number == more compression but slower\n--best    => Highest available compression level (-12) \n--fast=#  => Faster compression; higher number == faster but compress less\n");
    }
    s
}

fn usage_text() -> String {
    String::from("Usage : \n      executable [arg] [input] [output] \n\ninput   : a filename \n          with no FILE, or when FILE is - or stdin, read standard input\nArguments : \n -1     : fast compression (default) \n -12    : slowest compression level \n -T#    : use # threads for compression (default:0==auto) \n -d     : decompression (default for .lz4 extension)\n -f     : overwrite output without prompting \n -k     : preserve source files(s)  (default) \n--rm    : remove source file(s) after successful de/compression \n -h/-H  : display help/long help and exit \n\nAdvanced arguments :\n -V     : display Version number and exit \n -v     : verbose mode \n -q     : suppress warnings; specify twice to suppress errors too\n -c     : force write to standard output, even if it is the console\n -t     : test compressed file integrity\n -m     : multiple input files (implies automatic output filenames)\n -r     : operate recursively on directories (sets also -m) \n -l     : compress using Legacy format (Linux kernel compression)\n -z     : force compression \n -D FILE: use FILE as dictionary (compression & decompression)\n -B#    : cut file into blocks of size # bytes [32+] \n                     or predefined block size [4-7] (default: 7) \n -BI    : Block Independence (default) \n -BD    : Block dependency (improves compression ratio) \n -BX    : enable block checksum (default:disabled) \n--no-frame-crc : disable stream checksum (default:enabled) \n--content-size : compressed frame includes original size (default:not present)\n--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)\n--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)\n--favor-decSpeed: compressed files decompress faster, but are less compressed \n--fast[=#]: switch to ultra fast compression level (default: 1)\n--best  : same as -12\nBenchmark arguments : \n -b#    : benchmark file(s), using # compression level (default : 1) \n -e#    : test all compression levels from -bX to # (default : 1)\n -i#    : minimum evaluation time in seconds (default : 3s) \n")
}
