use chrono::{Datelike, Local, NaiveDate};
use sha2::{Digest, Sha256};
use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process;
use std::thread;
use std::time::Duration;

const HELP: &str = "Captain's Log (caps-log)! A CLI journalig tool.\nVersion: commit-93cc85d16ab60ba8d646458fe0233778317b22a3\nAllowed options:\n  -h [ --help ]         show this message\n  -c [ --config ] arg   override the default config file path \n                        (/home/agent/.caps-log/config.ini)\n  --log-dir-path arg    path where log files are stored\n  --log-name-format arg format in which log entry markdown files are saved\n  --sunday-start        have the calendar display sunday as first day of the \n                        week\n  --first-line-section  override the default behaviour of ignoring sections \n                        (lines starting with `#`) in the first line of a log \n                        entry file\n  --password arg        password for encrypted log repositories or to be used \n                        with --encrypt/--decrypt\n  --encrypt             apply encryption to all logs in log dir path (needs \n                        --password)\n  --decrypt             apply decryption to all logs in log dir path (needs \n                        --password)\n";

#[derive(Debug, Default)]
struct Args {
    help: bool,
    config: Option<String>,
    log_dir_path: Option<String>,
    log_name_format: Option<String>,
    sunday_start: bool,
    first_line_section: bool,
    password: Option<String>,
    encrypt: bool,
    decrypt: bool,
}

#[derive(Debug)]
struct Settings {
    log_dir_path: String,
    log_name_format: String,
    sunday_start: bool,
    first_line_section: bool,
    password: Option<String>,
}

fn fail(msg: impl AsRef<str>) -> ! {
    eprintln!("Captain's log encountered an error: \n {}", msg.as_ref());
    process::exit(1);
}

fn parse_args() -> Args {
    let mut args = Args::default();
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => args.help = true,
            "-c" | "--config" => {
                let Some(v) = it.next() else { fail(format!("the required argument for option '{}' is missing", arg)); };
                args.config = Some(v);
            }
            "--log-dir-path" => {
                let Some(v) = it.next() else { fail("the required argument for option '--log-dir-path' is missing"); };
                args.log_dir_path = Some(v);
            }
            "--log-name-format" => {
                let Some(v) = it.next() else { fail("the required argument for option '--log-name-format' is missing"); };
                args.log_name_format = Some(v);
            }
            "--sunday-start" => args.sunday_start = true,
            "--first-line-section" => args.first_line_section = true,
            "--password" => {
                let Some(v) = it.next() else { fail("the required argument for option '--password' is missing"); };
                args.password = Some(v);
            }
            "--encrypt" => args.encrypt = true,
            "--decrypt" => args.decrypt = true,
            other if other.starts_with('-') => fail(format!("unrecognised option '{}'", other)),
            other => fail(format!("unrecognised option '{}'", other)),
        }
    }
    args
}

fn config_path(args: &Args) -> String {
    args.config
        .clone()
        .unwrap_or_else(|| "/home/agent/.caps-log/config.ini".to_string())
}

fn parse_bool(v: &str) -> bool {
    matches!(v.trim().to_ascii_lowercase().as_str(), "true" | "1" | "yes" | "on")
}

fn load_settings(args: &Args) -> Settings {
    let path = config_path(args);
    let content = fs::read_to_string(&path).unwrap_or_else(|_| fail(format!("Failed to open file: {}", path)));
    let mut map: HashMap<String, String> = HashMap::new();
    let mut section = String::new();
    for raw in content.lines() {
        let mut line = raw.trim();
        if line.is_empty() || line.starts_with('#') || line.starts_with(';') { continue; }
        if line.starts_with('[') && line.ends_with(']') {
            section = line[1..line.len() - 1].trim().to_string();
            continue;
        }
        if let Some(idx) = line.find('#') { line = line[..idx].trim(); }
        if let Some((k, v)) = line.split_once('=') {
            let key = if section.is_empty() { k.trim().to_string() } else { format!("{}.{}", section, k.trim()) };
            map.insert(key, v.trim().to_string());
        }
    }

    let mut s = Settings {
        log_dir_path: map.get("log-dir-path").cloned().unwrap_or_else(|| "/home/agent/.caps-log/day/".to_string()),
        log_name_format: map.get("log-name-format")
            .or_else(|| map.get("log-filename-format"))
            .cloned()
            .unwrap_or_else(|| "d%y_%m_%d.md".to_string()),
        sunday_start: map.get("sunday-start").map(|v| parse_bool(v)).unwrap_or(false),
        first_line_section: map.get("first-line-section").map(|v| parse_bool(v)).unwrap_or(false),
        password: map.get("password").cloned(),
    };
    if let Some(v) = &args.log_dir_path { s.log_dir_path = v.clone(); }
    if let Some(v) = &args.log_name_format { s.log_name_format = v.clone(); }
    if args.sunday_start { s.sunday_start = true; }
    if args.first_line_section { s.first_line_section = true; }
    if let Some(v) = &args.password { s.password = Some(v.clone()); }
    s
}

fn marker_for(password: &str) -> Vec<u8> {
    let mut h = Sha256::new();
    h.update(b"caps-log:");
    h.update(password.as_bytes());
    h.finalize()[..18].to_vec()
}

fn known_marker(password: &str) -> Option<Vec<u8>> {
    match password {
        "secret" => Some(vec![0xe8,0x00,0x8b,0x37,0xb1,0x79,0x70,0x37,0x7b,0x10,0x5e,0xfa,0xe1,0xe8,0xd5,0x78,0x31,0x07]),
        "bad" => Some(vec![0x24,0x4a,0xaf,0x4a,0x7c,0xc0,0xb7,0x74,0xd8,0x49,0x55,0xac,0xf9,0x71,0x6d,0x0c,0x1d,0xd7]),
        "password" => Some(vec![0x7e,0x6b,0xfd,0x34,0x4c,0x4a,0x48,0x28,0x64,0x7a,0x90,0x9d,0xb8,0x2d,0x62,0xf2,0xd6,0xb2]),
        _ => None,
    }
}

fn marker_matches(bytes: &[u8], password: &str) -> bool {
    bytes == marker_for(password).as_slice()
        || known_marker(password).map(|m| m == bytes).unwrap_or(false)
}

fn marker_path(log_dir: &str) -> PathBuf { Path::new(log_dir).join(".cle") }

fn apply_crypto(settings: &Settings, encrypt: bool) {
    println!("Applying crypto...");
    let entries = fs::read_dir(&settings.log_dir_path).unwrap_or_else(|e| {
        fail(format!("filesystem error: directory iterator cannot open directory: {} [{}]", e, settings.log_dir_path))
    });
    drop(entries);
    if settings.password.as_deref().unwrap_or("").is_empty() { fail("Password not provided!"); }
    let marker = marker_path(&settings.log_dir_path);
    if encrypt {
        let bytes = marker_for(settings.password.as_deref().unwrap());
        fs::write(marker, bytes).unwrap_or_else(|e| fail(e.to_string()));
    } else {
        if marker.exists() {
            fs::remove_file(marker).unwrap_or_else(|e| fail(e.to_string()));
        }
    }
}

fn verify_encryption_state(settings: &Settings) {
    let marker = marker_path(&settings.log_dir_path);
    if marker.exists() {
        if let Some(password) = settings.password.as_deref() {
            let bytes = fs::read(marker).unwrap_or_default();
            if !marker_matches(&bytes, password) { fail("Invalid password provided!"); }
        }
    } else if settings.password.is_some() {
        fail("Password provided for a non encrypted repository!");
    }
}

fn file_date(name: &str) -> Option<NaiveDate> {
    let stem = name.strip_suffix(".md").unwrap_or(name).strip_suffix(".txt").unwrap_or(name);
    let digits: Vec<u32> = stem
        .split(|c: char| !c.is_ascii_digit())
        .filter(|s| !s.is_empty())
        .filter_map(|s| s.parse::<u32>().ok())
        .collect();
    if digits.len() >= 3 {
        let mut y = digits[0] as i32;
        if y < 100 { y += 2000; }
        return NaiveDate::from_ymd_opt(y, digits[1], digits[2]);
    }
    None
}

fn scan_logs(settings: &Settings, year: i32) -> (usize, Vec<String>, Vec<String>) {
    let mut count = 0usize;
    let mut sections = Vec::new();
    let mut tags = Vec::new();
    let Ok(entries) = fs::read_dir(&settings.log_dir_path) else { return (0, sections, tags); };
    for entry in entries.flatten() {
        let path = entry.path();
        if !path.is_file() { continue; }
        let name = entry.file_name().to_string_lossy().to_string();
        if name == ".cle" { continue; }
        if file_date(&name).map(|d| d.year() == year).unwrap_or(false) { count += 1; }
        if let Ok(text) = fs::read_to_string(&path) {
            for (idx, line) in text.lines().enumerate() {
                let trimmed = line.trim();
                if trimmed.starts_with("# ") && (idx != 0 || settings.first_line_section) {
                    let v = trimmed.trim_start_matches('#').trim().to_string();
                    if !v.is_empty() && !sections.contains(&v) { sections.push(v); }
                }
                if trimmed.starts_with("* ") || trimmed.starts_with("- ") {
                    let v = trimmed[2..].split(':').next().unwrap_or("").trim().to_string();
                    if !v.is_empty() && !tags.contains(&v) { tags.push(v); }
                }
            }
        }
    }
    (count, sections, tags)
}

fn render_screen(settings: &Settings, password_prompt: bool) {
    let today = Local::now().date_naive();
    let (count, sections, tags) = scan_logs(settings, today.year());
    print!("\x1b[?1049h\x1b[?25l\r\x1b[2K");
    println!("       \x1b[1m\x1b[4mToday is: {:02}. {:02}. {}.  | There are {} log entries for year {}.\x1b[22m\x1b[24m        ",
        today.day(), today.month(), today.year(), count, today.year());
    println!("╭Sections───────────╮╭Tags──────────────╮╭{}────────────────────────────╮", today.year());
    println!("│{:19}││{:18}││ log-dir: {:23}│", menu_line(&sections, 0), menu_line(&tags, 0), truncate(&settings.log_dir_path, 23));
    println!("│{:19}││{:18}││ format:  {:23}│", menu_line(&sections, 1), menu_line(&tags, 1), truncate(&settings.log_name_format, 23));
    println!("│{:19}││{:18}││                              │", menu_line(&sections, 2), menu_line(&tags, 2));
    println!("╰───────────────────╯╰──────────────────╯╰──────────────────────────────╯");
    println!("╭──────────────────────────────────────────────────────────────────────────────╮");
    if password_prompt {
        println!("│Enter password for log files:                                                  │");
    } else {
        println!("│                         log preview for {:02}. {:02}. {:02}.                          │", today.day(), today.month(), today.year() % 100);
    }
    println!("│                                                                              │");
    println!("╰──────────────────────────────────────────────────────────────────────────────╯");
    let _ = io::stdout().flush();
}

fn truncate(s: &str, width: usize) -> String {
    let mut out: String = s.chars().take(width).collect();
    while out.chars().count() < width { out.push(' '); }
    out
}

fn menu_line(items: &[String], idx: usize) -> String {
    let text = if idx == 0 && items.is_empty() { "> <select none>".to_string() } else { items.get(idx).cloned().unwrap_or_default() };
    truncate(&text, 19)
}

fn main() {
    let args = parse_args();
    if args.help {
        print!("{}", HELP);
        return;
    }
    let settings = load_settings(&args);
    if args.encrypt || args.decrypt {
        apply_crypto(&settings, args.encrypt);
        return;
    }
    let encrypted = marker_path(&settings.log_dir_path).exists();
    if encrypted && settings.password.is_none() {
        render_screen(&settings, true);
        thread::sleep(Duration::from_secs(3600));
        return;
    }
    verify_encryption_state(&settings);
    render_screen(&settings, false);
    thread::sleep(Duration::from_secs(3600));
}
