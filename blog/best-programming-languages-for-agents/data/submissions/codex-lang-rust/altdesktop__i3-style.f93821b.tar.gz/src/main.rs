use std::collections::HashMap;
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::Command;

#[derive(Clone, Debug)]
struct Theme {
    bar: HashMap<&'static str, Vec<String>>,
    win: HashMap<&'static str, Vec<String>>,
}

#[derive(Default)]
struct Args {
    list: bool,
    reload: bool,
    save: bool,
    config: Option<String>,
    output: Option<String>,
    to_theme: Option<String>,
    theme: Option<String>,
}

fn main() {
    let matches = parse_args();

    if matches.list {
        print_theme_list();
        return;
    }

    if let Some(to_theme) = matches.to_theme.as_deref() {
        if !validate_config(to_theme) {
            eprintln!("Could not validate config.\nUse `i3 -C -c {}` to see validation errors.", to_theme);
            std::process::exit(1);
        }
        match fs::read_to_string(to_theme) {
            Ok(s) => {
                let out = config_to_theme(&s);
                write_output(&matches, to_theme, &out);
            }
            Err(e) => die(&format!("Could not open config: {} - {}", to_theme, e)),
        }
        return;
    }

    let theme_arg = match matches.theme.as_deref() {
        Some(t) => t,
        None => {
            eprintln!("USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nSelect a theme as the first argument. Use `--list-all` to see the themes.");
            std::process::exit(1);
        }
    };

    let config = matches.config.as_ref().map(PathBuf::from).unwrap_or_else(default_config_path);
    let config_s = config.to_string_lossy().to_string();
    if !config.exists() {
        eprintln!("Could not find i3 config");
        std::process::exit(1);
    }
    if !validate_config(&config_s) {
        eprintln!("Could not validate config.\nUse `i3 -C -c {}` to see validation errors.", config_s);
        std::process::exit(1);
    }
    let input = fs::read_to_string(&config).unwrap_or_else(|e| {
        die(&format!("Could not open config: {} - {}", config_s, e));
        String::new()
    });
    let theme = load_theme(theme_arg).unwrap_or_else(|msg| {
        eprintln!("{}", msg);
        std::process::exit(1);
    });
    let rendered = apply_theme(&input, &theme);
    write_output(&matches, &config_s, &rendered);
    if matches.reload {
        let _ = Command::new("i3-msg").arg("reload").status();
    }
}

fn parse_args() -> Args {
    let mut out = Args::default();
    let mut it = env::args().skip(1).peekable();
    while let Some(a) = it.next() {
        match a.as_str() {
            "-h" | "--help" => { print_help(); std::process::exit(0); }
            "-V" | "--version" => { println!("i3-style 1.0"); std::process::exit(0); }
            "-l" | "--list-all" => out.list = true,
            "-r" | "--reload" => out.reload = true,
            "-s" | "--save" => out.save = true,
            "-c" | "--config" => out.config = it.next(),
            "-o" | "--output" => out.output = it.next(),
            "-t" | "--to-theme" => out.to_theme = it.next(),
            x if x.starts_with("--config=") => out.config = Some(x[9..].to_string()),
            x if x.starts_with("--output=") => out.output = Some(x[9..].to_string()),
            x if x.starts_with("--to-theme=") => out.to_theme = Some(x[11..].to_string()),
            x if x.starts_with('-') => {
                eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFor more information try --help", x);
                std::process::exit(1);
            }
            x => out.theme = Some(x.to_string()),
        }
    }
    out
}

fn print_help() {
    println!("i3-style 1.0\nMake your i3 config a bit more stylish\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFLAGS:\n    -h, --help        Prints help information\n    -l, --list-all    Print a list of all available themes\n    -r, --reload      Apply the theme by reloading the config\n    -s, --save        Set the output file to the path of the input file\n    -V, --version     Prints version information\n\nOPTIONS:\n    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.\n    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>\n    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others\n                             [default: ]\n\nARGS:\n    <theme>    The theme to use");
}

fn die(msg: &str) {
    eprintln!("{}", msg);
    std::process::exit(1);
}

fn default_config_path() -> PathBuf {
    if let Ok(home) = env::var("HOME") {
        let p = PathBuf::from(&home).join(".config/i3/config");
        if p.exists() {
            return p;
        }
        return PathBuf::from(home).join(".i3/config");
    }
    PathBuf::from(".i3/config")
}

fn validate_config(path: &str) -> bool {
    Command::new("i3").arg("-C").arg("-c").arg(path).status().map(|s| s.success()).unwrap_or(false)
}

fn write_output(matches: &Args, input_path: &str, text: &str) {
    let out = if matches.save {
        Some(input_path.to_string())
    } else {
        matches.output.clone()
    };
    match out {
        Some(path) => {
            eprintln!("saving config at {} to /tmp/i3-style/0/config-input", input_path);
            if let Err(e) = fs::write(&path, text) {
                die(&format!("Could not write config: {} - {}", path, e));
            }
        }
        None => {
            print!("{}", text);
            let _ = io::stdout().flush();
        }
    }
}

fn theme(bar_rows: &[(&'static str, &[&str])], win_rows: &[(&'static str, &[&str])]) -> Theme {
    let mut bar = HashMap::new();
    let mut win = HashMap::new();
    for (k, v) in bar_rows {
        bar.insert(*k, v.iter().map(|s| s.to_string()).collect());
    }
    for (k, v) in win_rows {
        win.insert(*k, v.iter().map(|s| s.to_string()).collect());
    }
    Theme { bar, win }
}

fn builtins() -> HashMap<&'static str, Theme> {
    let mut m = HashMap::new();
    macro_rules! ins {
        ($name:expr, $sep:expr, $bg:expr, $status:expr, $fw:expr, $aw:expr, $iw:expr, $uw:expr, $cf:expr, $cfi:expr, $cu:expr, $cur:expr) => {
            m.insert($name, theme(&[
                ("separator", &[$sep][..]), ("background", &[$bg][..]), ("statusline", &[$status][..]),
                ("focused_workspace", &$fw[..]), ("active_workspace", &$aw[..]), ("inactive_workspace", &$iw[..]), ("urgent_workspace", &$uw[..]),
            ], &[
                ("focused", &$cf[..]), ("focused_inactive", &$cfi[..]), ("unfocused", &$cu[..]), ("urgent", &$cur[..]),
            ]));
        };
    }
    ins!("slate", "#586e75","#002b36","#aea79f", ["#586e75","#586e75","#ffffff"], ["#073642","#073642","#ffffff"], ["#002b36","#002b36","#aea79f"], ["#77216f","#77216f","#ffffff"], ["#586e75","#586e75","#fdf6e3","#268bd2"], ["#073642","#073642","#93a1a1","#002b36"], ["#002b36","#002b36","#586e75","#002b36"], ["#dc322f","#dc322f","#fdf6e3","#dc322f"]);
    ins!("alphare", "#000000","#FDF6E3","#002B36", ["#000000","#268BD2","#FFFFFF"], ["#333333","#222222","#FFFFFF"], ["#333333","#222222","#888888"], ["#2F343A","#900000","#FFFFFF"], ["#000000","#FDF6E3","#002B36","#000000"], ["#000000","#5F676A","#FDF6E3","#484E50"], ["#000000","#000000","#FDF6E3","#000000"], ["#000000","#DC322F","#FDF6E3","#DC322F"]);
    ins!("ubuntu", "#333333","#2c001e","#aea79f", ["#dd4814","#dd4814","#ffffff"], ["#902a07","#902a07","#aea79f"], ["#902a07","#902a07","#aea79f"], ["#77216f","#77216f","#ffffff"], ["#dd4814","#dd4814","#ffffff","#902a07"], ["#5e2750","#5e2750","#aea79f","#5e2750"], ["#5e2750","#5e2750","#aea79f","#5e2750"], ["#77216f","#77216f","#ffffff","#efb73e"]);
    ins!("purple", "#AAAAAA","#222133","#FFFFFF", ["#664477","#664477","#cccccc"], ["#DCCD69","#DCCD69","#181715"], ["#222133","#222133","#AAAAAA"], ["#CE4045","#CE4045","#FFFFFF"], ["#664477","#664477","#cccccc","#e7d8b1"], ["#e7d8b1","#e7d8b1","#181715","#A074C4"], ["#222133","#222133","#AAAAAA","#A074C4"], ["#CE4045","#CE4045","#e7d8b1","#DCCD69"]);
    ins!("archlinux", "#666666","#222222","#dddddd", ["#0088CC","#0088CC","#ffffff"], ["#333333","#333333","#ffffff"], ["#333333","#333333","#888888"], ["#2f343a","#900000","#ffffff"], ["#0088CC","#0088CC","#ffffff","#dddddd"], ["#333333","#333333","#888888","#292d2e"], ["#333333","#333333","#888888","#292d2e"], ["#2f343a","#900000","#ffffff","#900000"]);
    ins!("default", "#666666","#000000","#ffffff", ["#4c7899","#285577","#ffffff"], ["#333333","#5f676a","#ffffff"], ["#333333","#222222","#888888"], ["#2f343a","#900000","#ffffff"], ["#4c7899","#285577","#ffffff","#2e9ef4"], ["#333333","#5f676a","#ffffff","#484e50"], ["#333333","#222222","#888888","#292d2e"], ["#2f343a","#900000","#ffffff","#900000"]);
    ins!("debian", "#444444","#222222","#666666", ["#d70a53","#d70a53","#ffffff"], ["#333333","#333333","#888888"], ["#333333","#333333","#888888"], ["#eb709b","#eb709b","#ffffff"], ["#d70a53","#d70a53","#ffffff","#8c0333"], ["#333333","#333333","#888888","#333333"], ["#333333","#333333","#888888","#333333"], ["#eb709b","#eb709b","#ffffff","#eb709b"]);
    ins!("oceanic-next", "#65737E","#1B2B34","#D8DEE9", ["#6699CC","#6699CC","#1B2B34"], ["#5FB3B3","#5FB3B3","#1B2B34"], ["#343D46","#343D46","#D8DEE9"], ["#EC5f67","#EC5f67","#1B2B34"], ["#6699CC","#6699CC","#1B2B34","#6699CC"], ["#5FB3B3","#5FB3B3","#D8DEE9","#A7ADBA"], ["#343D46","#343D46","#D8DEE9","#343D46"], ["#EC5f67","#EC5f67","#1B2B34","#EC5f67"]);
    ins!("base16-tomorrow", "#969896","#1d1f21","#c5c8c6", ["#81a2be","#81a2be","#1d1f21"], ["#373b41","#373b41","#ffffff"], ["#282a2e","#282a2e","#969896"], ["#cc6666","#cc6666","#ffffff"], ["#81a2be","#81a2be","#1d1f21","#282a2e"], ["#373b41","#373b41","#969896","#282a2e"], ["#282a2e","#282a2e","#969896","#282a2e"], ["#373b41","#cc6666","#ffffff","#cc6666"]);
    ins!("okraits", "#666666","#333333","#bbbbbb", ["#888888","#dddddd","#222222"], ["#333333","#555555","#bbbbbb"], ["#333333","#555555","#bbbbbb"], ["#2f343a","#900000","#ffffff"], ["#888888","#dddddd","#222222","#2e9ef4"], ["#333333","#555555","#bbbbbb","#484e50"], ["#333333","#333333","#888888","#292d2e"], ["#2f343a","#900000","#ffffff","#900000"]);
    ins!("icelines", "#7d7d7d","#141414","#00b0ef", ["#00b0ef","#141414","#00b0ef"], ["#141414","#141414","#00b0ef"], ["#141414","#141414","#7d7d7d"], ["#ff7066","#141414","#ff7066"], ["#00b0ef","#00b0ef","#141414","#ff7066"], ["#141414","#141414","#00b0ef","#472b2a"], ["#141414","#141414","#7d7d7d","#141414"], ["#ff7066","#ff7066","#141414","#ff7066"]);
    ins!("solarized", "#dc322f","#002b36","#268bd2", ["#fdf6e3","#859900","#fdf6e3"], ["#fdf6e3","#6c71c4","#fdf6e3"], ["#586e75","#93a1a1","#002b36"], ["#d33682","#d33682","#fdf6e3"], ["#859900","#859900","#fdf6e3","#6c71c4"], ["#073642","#073642","#eee8d5","#6c71c4"], ["#073642","#073642","#93a1a1","#586e75"], ["#d33682","#d33682","#fdf6e3","#dc322f"]);
    ins!("deep-purple", "#666666","#000000","#ffffff", ["#551a8b","#551a8b","#ffffff"], ["#333333","#5f676a","#ffffff"], ["#000000","#000000","#888888"], ["#2f343a","#900000","#ffffff"], ["#3b1261","#3b1261","#ffffff","#662b9c"], ["#333333","#5f676a","#ffffff","#484e50"], ["#222222","#222222","#888888","#292d2e"], ["#2f343a","#900000","#ffffff","#900000"]);
    ins!("tomorrow-night-80s", "#515151","#2d2d2d","#cccccc", ["#99cc99","#99cc99","#000000"], ["#333333","#333333","#ffffff"], ["#2d2d2d","#2d2d2d","#999999"], ["#f2777a","#f2777a","#ffffff"], ["#99cc99","#99cc99","#000000","#2d2d2d"], ["#393939","#393939","#888888","#292d2e"], ["#2d2d2d","#2d2d2d","#999999","#292d2e"], ["#2f343a","#900000","#ffffff","#900000"]);
    ins!("seti", "#AAAAAA","#1f2326","#FFFFFF", ["#9FCA56","#9FCA56","#151718"], ["#DCCD69","#DCCD69","#151718"], ["#1f2326","#1f2326","#AAAAAA"], ["#CE4045","#CE4045","#FFFFFF"], ["#4F99D3","#4F99D3","#151718","#9FCA56"], ["#9FCA56","#9FCA56","#151718","#A074C4"], ["#1f2326","#1f2326","#AAAAAA","#A074C4"], ["#CE4045","#CE4045","#FFFFFF","#DCCD69"]);
    ins!("lime", "#888888","#333333","#FFFFFF", ["#4E9C00","#4E9C00","#FFFFFF"], ["#333333","#333333","#FFFFFF"], ["#333333","#333333","#888888"], ["#C20000","#C20000","#FFFFFF"], ["#4E9C00","#4E9C00","#FFFFFF","#FFFFFF"], ["#1B3600","#1B3600","#888888","#FFFFFF"], ["#333333","#333333","#888888","#FFFFFF"], ["#C20000","#C20000","#FFFFFF","#FFFFFF"]);
    ins!("gruvbox", "#928374","#282828","#ebdbb2", ["#689d6a","#689d6a","#282828"], ["#1d2021","#1d2021","#928374"], ["#32302f","#32302f","#928374"], ["#cc241d","#cc241d","#ebdbb2"], ["#689d6a","#689d6a","#282828","#282828"], ["#1d2021","#1d2021","#928374","#282828"], ["#32302f","#32302f","#928374","#282828"], ["#cc241d","#cc241d","#ebdbb2","#282828"]);
    ins!("mate", "#ffffff","#3c3b37","#ffffff", ["#526532","#526532","#ffffff"], ["#aea79f","#aea79f","#3c3b37"], ["#3c3b37","#3c3b37","#aea79f"], ["#FF0000","#FF0000","#ffffff"], ["#526532","#526532","#ffffff","#a4cb64"], ["#aea79f","#aea79f","#3c3b37","#aea79f"], ["#3c3b37","#3c3b37","#aea79f","#3c3b37"], ["#FF0000","#FF0000","#ffffff","#FF0000"]);
    m.insert("flat-gray", theme(&[
        ("separator", &["#111111"]), ("background", &["#333333"]), ("statusline", &["#AAAAAA"]),
        ("focused_workspace", &["#282828","#282828","#FFFFFF"]), ("inactive_workspace", &["#333333","#333333","#AAAAAA"]),
    ], &[
        ("focused", &["#000000","#000000","#FFFFFF","#000000"]), ("focused_inactive", &["#333333","#333333","#FFFFFF","#000000"]), ("unfocused", &["#333333","#333333","#FFFFFF","#333333"]),
    ]));
    m
}

fn print_theme_list() {
    println!("i3-style 1.0\n\nAvailable themes:\n");
    let rows = [
        ("slate","Slate theme by Jody Ribton <jody@ribton.me>"), ("alphare","A beige theme by Alphare"),
        ("ubuntu","Ubuntu theme by lasers"), ("flat-gray","flat gray based theme"), ("purple","Purple theme by AAlakkad <http://aalakkad.me>"),
        ("archlinux","Archlinux theme by okraits <http://okraits.de>"), ("default","Default theme for i3wm <http://i3wm.org>"),
        ("debian","Debian theme by lasers"), ("oceanic-next","Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)"),
        ("base16-tomorrow","Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)"), ("okraits","A simple theme by okraits <http://okraits.de>"),
        ("icelines","icelines theme by mbfraga"), ("solarized","Solarized theme by lasers"), ("deep-purple","Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>"),
        ("tomorrow-night-80s","Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>"), ("seti","seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui"),
        ("lime","Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>"), ("gruvbox","Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>"),
        ("mate","Theme for blending i3 into MATE"),
    ];
    for (name, desc) in rows {
        println!("  {:18} - {}", name, desc);
    }
}

fn load_theme(arg: &str) -> Result<Theme, String> {
    if let Some(t) = builtins().get(arg) {
        return Ok(t.clone());
    }
    let p = Path::new(arg);
    let content = fs::read_to_string(p).map_err(|e| format!("Could not open theme: {} - {}\n Use `i3-style --list-all` to see the available themes.", arg, e))?;
    parse_yaml_theme(&content).map_err(|e| format!("Could not load theme: {}", e))
}

fn resolve_color(name: &str, colors: &HashMap<String, String>) -> String {
    let unq = name.trim().trim_matches('"').trim_matches('\'');
    if unq.starts_with('#') { unq.to_string() } else { colors.get(unq).cloned().unwrap_or_else(|| unq.to_string()) }
}

fn parse_yaml_theme(s: &str) -> Result<Theme, String> {
    let mut colors = HashMap::new();
    let mut out = Theme { bar: HashMap::new(), win: HashMap::new() };
    let lines: Vec<&str> = s.lines().collect();
    let mut section = "";
    let mut subsection = String::new();
    let mut i = 0usize;
    while i < lines.len() {
        let line = lines[i];
        let indent = line.chars().take_while(|c| *c == ' ').count();
        let t = line.trim();
        if t.is_empty() || t == "---" || t.starts_with('#') { i += 1; continue; }
        if indent == 0 && t.ends_with(':') {
            section = t.trim_end_matches(':');
            subsection.clear();
            i += 1;
            continue;
        }
        if section == "colors" && indent == 2 {
            if let Some((k, v)) = split_yaml_kv(t) {
                colors.insert(k.to_string(), clean_yaml_value(v).to_string());
            }
        } else if section == "bar_colors" && indent == 2 {
            if let Some((k, v)) = split_yaml_kv(t) {
                if v.is_empty() {
                    subsection = k.to_string();
                } else {
                    out.bar.insert(Box::leak(k.to_string().into_boxed_str()), vec![resolve_color(v, &colors)]);
                    subsection.clear();
                }
            }
        } else if section == "bar_colors" && indent == 4 && !subsection.is_empty() {
            let vals = collect_subvalues(&lines, &mut i, 4, &colors, &["border","background","text"]);
            if !vals.is_empty() {
                out.bar.insert(Box::leak(subsection.clone().into_boxed_str()), vals);
                subsection.clear();
                continue;
            }
        } else if section == "window_colors" && indent == 2 {
            if let Some((k, v)) = split_yaml_kv(t) {
                if v.is_empty() { subsection = k.to_string(); }
            }
        } else if section == "window_colors" && indent == 4 && !subsection.is_empty() {
            let vals = collect_subvalues(&lines, &mut i, 4, &colors, &["border","background","text","indicator"]);
            if !vals.is_empty() {
                out.win.insert(Box::leak(subsection.clone().into_boxed_str()), vals);
                subsection.clear();
                continue;
            }
        }
        i += 1;
    }
    Ok(out)
}

fn split_yaml_kv(t: &str) -> Option<(&str, &str)> {
    let (k, v) = t.split_once(':')?;
    Some((k.trim(), v.trim()))
}

fn clean_yaml_value(v: &str) -> &str {
    v.trim().trim_matches('"').trim_matches('\'')
}

fn collect_subvalues(lines: &[&str], i: &mut usize, indent: usize, colors: &HashMap<String,String>, keys: &[&str]) -> Vec<String> {
    let start = *i;
    let mut found = HashMap::new();
    let mut j = start;
    while j < lines.len() {
        let ind = lines[j].chars().take_while(|c| *c == ' ').count();
        let t = lines[j].trim();
        if ind != indent || t.is_empty() { break; }
        if let Some((k, v)) = split_yaml_kv(t) {
            found.insert(k.to_string(), resolve_color(clean_yaml_value(v), colors));
        }
        j += 1;
    }
    *i = j;
    keys.iter().filter_map(|k| found.get(*k).cloned()).collect()
}

fn apply_theme(input: &str, theme: &Theme) -> String {
    let mut out = Vec::new();
    let mut seen_bar: HashMap<&str, bool> = HashMap::new();
    let mut seen_win: HashMap<&str, bool> = HashMap::new();
    let mut in_bar = false;
    let mut in_colors = false;
    let mut bar_depth = 0i32;
    let mut colors_depth = 0i32;
    let mut inserted_colors = false;
    for line in input.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with("bar") && trimmed.ends_with('{') {
            in_bar = true; bar_depth = 1; inserted_colors = false;
            out.push(line.to_string());
            continue;
        }
        if in_bar && trimmed.starts_with("colors") && trimmed.ends_with('{') {
            in_colors = true; colors_depth = 1;
            inserted_colors = true;
            out.push(line.to_string());
            continue;
        }
        if in_colors {
            if let Some((key, old_extra)) = parse_bar_line(trimmed) {
                if let Some(vals) = theme.bar.get(key) {
                    seen_bar.insert(key, true);
                    let mut v = vals.clone();
                    if key.ends_with("_workspace") && old_extra.len() > vals.len() {
                        v.extend_from_slice(&old_extra[vals.len()..]);
                    }
                    out.push(format!("    {} {}", key, v.join(" ")));
                } else {
                    out.push(line.to_string());
                }
            } else if trimmed == "}" {
                for l in missing_bar_lines(theme, &seen_bar) { out.push(l); }
                out.push(line.to_string());
                in_colors = false;
            } else {
                out.push(line.to_string());
            }
            colors_depth += count_braces(line);
            continue;
        }
        if let Some(key) = trimmed.strip_prefix("client.").and_then(|r| r.split_whitespace().next()) {
            if let Some(vals) = theme.win.get(key) {
                seen_win.insert(key, true);
                out.push(format!("client.{} {}", key, vals.join(" ")));
                continue;
            }
        }
        if in_bar && trimmed == "}" && !inserted_colors {
            out.extend(bar_colors_block(theme));
            inserted_colors = true;
        }
        out.push(line.to_string());
        if in_bar {
            bar_depth += count_braces(line);
            if bar_depth <= 0 { in_bar = false; }
        }
        if in_colors {
            colors_depth += count_braces(line);
            if colors_depth <= 0 { in_colors = false; }
        }
    }
    for k in ["focused","focused_inactive","unfocused","urgent"] {
        if !seen_win.contains_key(k) {
            if let Some(vals) = theme.win.get(k) {
                out.push(format!("client.{} {}", k, vals.join(" ")));
            }
        }
    }
    let mut s = out.join("\n");
    s.push('\n');
    s
}

fn count_braces(line: &str) -> i32 {
    line.chars().map(|c| if c == '{' { 1 } else if c == '}' { -1 } else { 0 }).sum()
}

fn parse_bar_line(trimmed: &str) -> Option<(&'static str, Vec<String>)> {
    let mut parts = trimmed.split_whitespace();
    let key = parts.next()?;
    let stable = match key {
        "separator" => "separator", "background" => "background", "statusline" => "statusline",
        "focused_workspace" => "focused_workspace", "active_workspace" => "active_workspace",
        "inactive_workspace" => "inactive_workspace", "urgent_workspace" => "urgent_workspace",
        _ => return None,
    };
    Some((stable, parts.map(|s| s.to_string()).collect()))
}

fn bar_colors_block(theme: &Theme) -> Vec<String> {
    let mut v = vec!["  colors {".to_string()];
    v.extend(missing_bar_lines(theme, &HashMap::new()));
    v.push("  }".to_string());
    v
}

fn missing_bar_lines(theme: &Theme, seen: &HashMap<&str, bool>) -> Vec<String> {
    let mut v = Vec::new();
    for k in ["separator","background","statusline","focused_workspace","active_workspace","inactive_workspace","urgent_workspace"] {
        if !seen.contains_key(k) {
            if let Some(vals) = theme.bar.get(k) {
                let suffix = if k.ends_with("_workspace") { " " } else { "" };
                v.push(format!("    {} {}{}", k, vals.join(" "), suffix));
            }
        }
    }
    v
}

fn extract_hexes(line: &str) -> Vec<String> {
    line.split_whitespace().filter(|p| p.starts_with('#') && p.len() >= 7).map(|s| s.trim_end_matches(',').to_uppercase()).collect()
}

fn config_to_theme(s: &str) -> String {
    let mut bar: HashMap<&str, Vec<String>> = HashMap::new();
    let mut win: HashMap<&str, Vec<String>> = HashMap::new();
    for line in s.lines() {
        let t = line.trim();
        if let Some((k, vals)) = parse_bar_line(t) { bar.insert(k, vals.into_iter().take(3).collect()); }
        if let Some(rest) = t.strip_prefix("client.") {
            if let Some(k) = rest.split_whitespace().next() {
                let stable = match k { "focused"=>"focused", "focused_inactive"=>"focused_inactive", "unfocused"=>"unfocused", "urgent"=>"urgent", _=>continue };
                win.insert(stable, extract_hexes(t).into_iter().take(4).collect());
            }
        }
    }
    let mut colors: Vec<String> = Vec::new();
    for k in ["separator","background","statusline","focused_workspace","urgent_workspace"] {
        if let Some(v) = bar.get(k) { colors.extend(v.clone()); }
    }
    for k in ["focused","focused_inactive","unfocused","urgent"] {
        if let Some(v) = win.get(k) { colors.extend(v.clone()); }
    }
    let mut names = HashMap::new();
    let mut out = String::from("---\nmeta:\n  description: AUTOMATICALLY GENERATED THEME\ncolors:\n");
    for (i, c) in colors.iter().enumerate() {
        let n = if i == 0 { "color".to_string() } else { format!("color-{}", i) };
        names.insert(c.clone(), n.clone());
        out.push_str(&format!("  {}: \"{}\"\n", n, c));
    }
    let name_of = |c: &String, names: &HashMap<String,String>| names.get(c).cloned().unwrap_or_else(|| c.clone());
    out.push_str("window_colors:\n");
    for k in ["focused","focused_inactive","unfocused","urgent"] {
        if let Some(v) = win.get(k) {
            out.push_str(&format!("  {}:\n    border: {}\n    background: {}\n    text: {}\n    indicator: {}\n", k, name_of(&v[0], &names), name_of(&v[1], &names), name_of(&v[2], &names), name_of(&v[3], &names)));
        }
    }
    out.push_str("bar_colors:\n");
    for k in ["background","statusline","separator"] {
        if let Some(v) = bar.get(k) { out.push_str(&format!("  {}: {}\n", k, name_of(&v[0], &names))); }
    }
    for k in ["focused_workspace","urgent_workspace"] {
        if let Some(v) = bar.get(k) {
            out.push_str(&format!("  {}:\n    border: {}\n    background: {}\n    text: {}\n", k, name_of(&v[0], &names), name_of(&v[1], &names), name_of(&v[2], &names)));
        }
    }
    out
}
