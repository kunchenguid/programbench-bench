use std::env;
use std::fs::{self, File};
use std::io::{self, Write};
use std::path::Path;

const VERSION: &str = "ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers\nbuilt with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)\nconfiguration: --disable-ffplay --disable-ffprobe\nlibavutil      60. 25.100 / 60. 25.100\nlibavcodec     62. 23.103 / 62. 23.103\nlibavformat    62.  9.101 / 62.  9.101\nlibavdevice    62.  2.100 / 62.  2.100\nlibavfilter    11. 12.100 / 11. 12.100\nlibswscale      9.  3.100 /  9.  3.100\nlibswresample   6.  2.100 /  6.  2.100\n";
const BANNER: &str = "ffmpeg version git-2026-04-13-10ea080 Copyright (c) 2000-2026 the FFmpeg developers\n  built with gcc 11 (Ubuntu 11.4.0-1ubuntu1~22.04.3)\n  configuration: --disable-ffplay --disable-ffprobe\n  libavutil      60. 25.100 / 60. 25.100\n  libavcodec     62. 23.103 / 62. 23.103\n  libavformat    62.  9.101 / 62.  9.101\n  libavdevice    62.  2.100 / 62.  2.100\n  libavfilter    11. 12.100 / 11. 12.100\n  libswscale      9.  3.100 /  9.  3.100\n  libswresample   6.  2.100 /  6.  2.100\n";
const EXIT0: &str = "\nExiting with exit code 0\n";

const BASIC_HELP: &str = "Universal media converter\nusage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n\nGetting help:\n    -h      -- print basic options\n    -h long -- print more options\n    -h full -- print all options (including all format and codec specific options, very long)\n    -h type=name -- print all options for the named decoder/encoder/demuxer/muxer/filter/bsf/protocol\n    See man ffmpeg for detailed description of the options.\n\nPer-stream options can be followed by :<stream_spec> to apply that option to specific streams only. <stream_spec> can be a stream index, or v/a/s for video/audio/subtitle (see manual for full syntax).\n\nPrint help / information / capabilities:\n-L                  show license\n-license            show license\n-h <topic>          show help\n-version            show version\n-muxers             show available muxers\n-demuxers           show available demuxers\n-devices            show available devices\n-decoders           show available decoders\n-encoders           show available encoders\n-filters            show available filters\n-pix_fmts           show available pixel formats\n-layouts            show standard channel layouts\n-sample_fmts        show available audio sample formats\n\nGlobal options (affect whole program instead of just one file):\n-v <loglevel>       set logging level\n-y                  overwrite output files\n-n                  never overwrite output files\n-print_graphs       print execution graph data to stderr\n-print_graphs_file <filename>  write execution graph data to the specified file\n-print_graphs_format <format>  set the output printing format (available formats are: default, compact, csv, flat, ini, json, xml, mermaid, mermaidhtml)\n-stats              print progress report during encoding\n\nPer-file options (input and output):\n-f <fmt>            force container format (auto-detected otherwise)\n-t <duration>       stop transcoding after specified duration\n-to <time_stop>     stop transcoding after specified time is reached\n-ss <time_off>      start transcoding at specified time\n\n\nPer-file options (output-only):\n-metadata[:<spec>] <key=value>  add metadata\n\nPer-stream options:\n-c[:<stream_spec>] <codec>  select encoder/decoder ('copy' to copy stream without reencoding)\n-filter[:<stream_spec>] <filter_graph>  apply specified filters to audio/video\n\nVideo options:\n-r[:<stream_spec>] <rate>  override input framerate/convert to given output framerate (Hz value, fraction or abbreviation)\n-aspect[:<stream_spec>] <aspect>  set aspect ratio (4:3, 16:9 or 1.3333, 1.7777)\n-vn                 disable video\n-vcodec <codec>     alias for -c:v (select encoder/decoder for video streams)\n-vf <filter_graph>  alias for -filter:v (apply filters to video streams)\n-b <bitrate>        video bitrate (please use -b:v)\n\nAudio options:\n-aq <quality>       set audio quality (codec-specific)\n-ar[:<stream_spec>] <rate>  set audio sampling rate (in Hz)\n-ac[:<stream_spec>] <channels>  set number of audio channels\n-an                 disable audio\n-acodec <codec>     alias for -c:a (select encoder/decoder for audio streams)\n-ab <bitrate>       alias for -b:a (select bitrate for audio streams)\n-af <filter_graph>  alias for -filter:a (apply filters to audio streams)\n\nSubtitle options:\n-sn                 disable subtitle\n-scodec <codec>     alias for -c:s (select encoder/decoder for subtitle streams)\n";
const SHORT_HELP: &str = "Universal media converter\nusage: ffmpeg [options] [[infile options] -i infile]... {[outfile options] outfile}...\n\nUse -h to get full help or, even better, run 'man ffmpeg'\n";
const LICENSE: &str = "ffmpeg is free software; you can redistribute it and/or\nmodify it under the terms of the GNU Lesser General Public\nLicense as published by the Free Software Foundation; either\nversion 2.1 of the License, or (at your option) any later version.\n\nffmpeg is distributed in the hope that it will be useful,\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU\nLesser General Public License for more details.\n\nYou should have received a copy of the GNU Lesser General Public\nLicense along with ffmpeg; if not, write to the Free Software\nFoundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA\n";

fn cap(name: &str) -> &'static str {
    match name {
        "formats" => include_str!("../caps/cap_formats.txt"),
        "muxers" => include_str!("../caps/cap_muxers.txt"),
        "demuxers" => include_str!("../caps/cap_demuxers.txt"),
        "devices" => include_str!("../caps/cap_devices.txt"),
        "decoders" => include_str!("../caps/cap_decoders.txt"),
        "encoders" => include_str!("../caps/cap_encoders.txt"),
        "codecs" => include_str!("../caps/cap_codecs.txt"),
        "filters" => include_str!("../caps/cap_filters.txt"),
        "pix_fmts" => include_str!("../caps/cap_pix_fmts.txt"),
        "layouts" => include_str!("../caps/cap_layouts.txt"),
        "sample_fmts" => include_str!("../caps/cap_sample_fmts.txt"),
        "protocols" => include_str!("../caps/cap_protocols.txt"),
        "bsfs" => include_str!("../caps/cap_bsfs.txt"),
        "buildconf" => include_str!("../caps/cap_buildconf.txt"),
        "hwaccels" => include_str!("../caps/cap_hwaccels.txt"),
        _ => "",
    }
}

fn help_topic(topic: &str) -> Option<&'static str> {
    match topic {
        "long" => Some(include_str!("../caps/cap_h_-h_long.txt")),
        "full" => Some(include_str!("../caps/cap_h_-h_full.txt")),
        "muxer=wav" => Some(include_str!("../caps/cap_h_-h_muxer_wav.txt")),
        "muxer=image2" => Some(include_str!("../caps/cap_h_-h_muxer_image2.txt")),
        "demuxer=lavfi" => Some(include_str!("../caps/cap_h_-h_demuxer_lavfi.txt")),
        "filter=testsrc" => Some(include_str!("../caps/cap_h_-h_filter_testsrc.txt")),
        "filter=sine" => Some(include_str!("../caps/cap_h_-h_filter_sine.txt")),
        "encoder=png" => Some(include_str!("../caps/cap_h_-h_encoder_png.txt")),
        "encoder=pcm_s16le" => Some(include_str!("../caps/cap_h_-h_encoder_pcm_s16le.txt")),
        "encoder=rawvideo" => Some(include_str!("../caps/cap_h_-h_encoder_rawvideo.txt")),
        _ => None,
    }
}

#[derive(Default)]
struct Opts {
    hide_banner: bool,
    overwrite: bool,
    no_overwrite: bool,
    fmt: Option<String>,
    input_fmt: Option<String>,
    inputs: Vec<String>,
    output: Option<String>,
    frames: usize,
    sample_rate: u32,
    channels: u16,
    duration: f64,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let code = run(args);
    std::process::exit(code);
}

fn run(args: Vec<String>) -> i32 {
    if args.is_empty() {
        print!("{BANNER}{SHORT_HELP}");
        return 1;
    }
    let hide = args.iter().any(|a| a == "-hide_banner");
    let quiet = args.windows(2).any(|w| (w[0] == "-v" || w[0] == "-loglevel") && w[1] == "quiet");

    if has(&args, "-version") {
        print!("{VERSION}{EXIT0}");
        return 0;
    }
    if has(&args, "-L") || has(&args, "-license") {
        if !hide { print!("{BANNER}"); }
        print!("{LICENSE}");
        return 0;
    }
    if let Some((idx, _)) = args.iter().enumerate().find(|(_, a)| *a == "-h" || *a == "-help" || *a == "--help") {
        if !hide { print!("{BANNER}"); }
        let topic = args.get(idx + 1).filter(|s| !s.starts_with('-')).map(String::as_str);
        match topic {
            None => print!("{BASIC_HELP}\n\n{EXIT0}"),
            Some(t) => {
                if let Some(text) = help_topic(t) {
                    print!("{text}");
                } else if t.contains('=') {
                    let name = t.split('=').nth(1).unwrap_or(t);
                    println!("Codec '{name}' is not recognized by FFmpeg.");
                    print!("{EXIT0}");
                } else {
                    println!("Unknown help option '{t}'.");
                    print!("{BASIC_HELP}\n\n{EXIT0}");
                }
            }
        }
        return 0;
    }
    for flag in ["formats","muxers","demuxers","devices","decoders","encoders","codecs","filters","pix_fmts","layouts","sample_fmts","protocols","bsfs","buildconf","hwaccels"] {
        if has(&args, &format!("-{flag}")) {
            if !hide { print!("{BANNER}"); }
            print!("{}", cap(flag));
            return 0;
        }
    }
    if let Some(bad) = first_bad_option(&args) {
        if !hide && !quiet { eprint!("{BANNER}"); }
        eprintln!("Unrecognized option '{}'.", bad.trim_start_matches('-'));
        eprintln!("Error splitting the argument list: Option not found");
        return 8;
    }

    let opts = parse_opts(&args);
    if !quiet && !opts.hide_banner {
        eprint!("{BANNER}");
    }
    transcode(opts, quiet)
}

fn has(args: &[String], flag: &str) -> bool {
    args.iter().any(|a| a == flag)
}

fn first_bad_option(args: &[String]) -> Option<&str> {
    let known_with_value = ["-i","-f","-t","-to","-ss","-r","-ar","-ac","-c","-codec","-vcodec","-acodec","-scodec","-vf","-af","-filter","-filter:v","-filter:a","-b","-ab","-aq","-metadata","-frames:v","-frames","-vframes","-frames:a","-v","-loglevel","-pix_fmt","-s","-aspect","-map","-print_graphs_file","-print_graphs_format"];
    let known_flags = ["-y","-n","-hide_banner","-stats","-nostats","-vn","-an","-sn","-nostdin","-copyts","-shortest","-update"];
    let mut skip = false;
    for a in args {
        if skip { skip = false; continue; }
        if !a.starts_with('-') || a == "-" { continue; }
        let base = a.split(':').next().unwrap_or(a.as_str());
        if known_flags.contains(&base) { continue; }
        if known_with_value.contains(&base) { skip = true; continue; }
        if a.starts_with("-c:") || a.starts_with("-b:") || a.starts_with("-filter:") || a.starts_with("-metadata:") || a.starts_with("-frames:") || a.starts_with("-q:") {
            skip = true;
            continue;
        }
        return Some(a);
    }
    None
}

fn parse_opts(args: &[String]) -> Opts {
    let mut o = Opts { frames: 1, sample_rate: 44100, channels: 1, duration: 1.0, ..Default::default() };
    let mut i = 0;
    let mut pending_fmt: Option<String> = None;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-hide_banner" => o.hide_banner = true,
            "-y" => o.overwrite = true,
            "-n" => o.no_overwrite = true,
            "-f" => {
                if let Some(v) = args.get(i + 1) { pending_fmt = Some(v.clone()); o.fmt = Some(v.clone()); }
                i += 1;
            }
            "-i" => {
                if let Some(v) = args.get(i + 1) {
                    if o.inputs.is_empty() { o.input_fmt = pending_fmt.take(); }
                    o.inputs.push(v.clone());
                }
                i += 1;
            }
            "-frames:v" | "-frames" | "-vframes" => {
                if let Some(v) = args.get(i + 1).and_then(|s| s.parse().ok()) { o.frames = v; }
                i += 1;
            }
            "-ar" => {
                if let Some(v) = args.get(i + 1).and_then(|s| s.parse().ok()) { o.sample_rate = v; }
                i += 1;
            }
            "-ac" => {
                if let Some(v) = args.get(i + 1).and_then(|s| s.parse().ok()) { o.channels = v; }
                i += 1;
            }
            "-t" => {
                if let Some(v) = args.get(i + 1).and_then(|s| parse_duration(s)) { o.duration = v; }
                i += 1;
            }
            "-to"|"-ss"|"-r"|"-c"|"-codec"|"-vcodec"|"-acodec"|"-scodec"|"-vf"|"-af"|"-filter"|"-filter:v"|"-filter:a"|"-b"|"-ab"|"-aq"|"-metadata"|"-v"|"-loglevel"|"-pix_fmt"|"-s"|"-aspect"|"-map"|"-print_graphs_file"|"-print_graphs_format" => i += 1,
            _ if a.starts_with('-') => {
                if a.starts_with("-c:") || a.starts_with("-b:") || a.starts_with("-filter:") || a.starts_with("-metadata:") || a.starts_with("-frames:") || a.starts_with("-q:") { i += 1; }
            }
            _ => o.output = Some(a.clone()),
        }
        i += 1;
    }
    o
}

fn parse_duration(s: &str) -> Option<f64> {
    if let Ok(v) = s.parse() { return Some(v); }
    let parts: Vec<_> = s.split(':').collect();
    if parts.len() == 3 {
        let h: f64 = parts[0].parse().ok()?;
        let m: f64 = parts[1].parse().ok()?;
        let sec: f64 = parts[2].parse().ok()?;
        Some(h * 3600.0 + m * 60.0 + sec)
    } else { None }
}

fn transcode(o: Opts, quiet: bool) -> i32 {
    let Some(out) = o.output.as_deref() else {
        if !quiet { eprintln!("At least one output file must be specified"); }
        return 1;
    };
    if o.no_overwrite && Path::new(out).exists() {
        if !quiet { eprintln!("File '{}' already exists. Exiting.", out); }
        return 1;
    }
    if !o.overwrite && Path::new(out).exists() {
        if !quiet { eprintln!("File '{}' already exists. Overwrite? [y/N] Not overwriting - exiting", out); }
        return 1;
    }
    if let Some(input) = o.inputs.first() {
        let lavfi = o.input_fmt.as_deref() == Some("lavfi") || input.starts_with("sine") || input.starts_with("testsrc") || input.starts_with("color");
        if !lavfi && !Path::new(input).exists() {
            if !quiet {
                eprintln!("[in#0 @ 0x55555744e600] Error opening input: No such file or directory");
                eprintln!("Error opening input file {input}.");
                eprintln!("Error opening input files: No such file or directory");
            }
            return 254;
        }
        if lavfi {
            return write_synthetic(input, out, &o, quiet);
        }
        if fs::copy(input, out).is_ok() {
            if !quiet { eprintln!("Output #0, file, to '{}':\nsize=       0KiB time=00:00:00.00 bitrate=N/A speed=1x", out); }
            return 0;
        }
    }
    match write_by_extension(out, &o) {
        Ok(()) => {
            if !quiet { eprintln!("size=       0KiB time=00:00:00.00 bitrate=N/A speed=1x"); }
            0
        }
        Err(e) => {
            if !quiet { eprintln!("{out}: {e}"); }
            1
        }
    }
}

fn write_synthetic(input: &str, out: &str, o: &Opts, quiet: bool) -> i32 {
    if !quiet {
        if input.starts_with("sine") {
            eprintln!("Input #0, lavfi, from '{}':\n  Duration: N/A, start: 0.000000, bitrate: 705 kb/s\n  Stream #0:0: Audio: pcm_s16le, {} Hz, mono, s16, 705 kb/s", input, o.sample_rate);
        } else {
            eprintln!("Input #0, lavfi, from '{}':\n  Duration: N/A, start: 0.000000, bitrate: N/A\n  Stream #0:0: Video: wrapped_avframe, rgb24, 320x240 [SAR 1:1 DAR 4:3], 25 fps, 25 tbr, 25 tbn", input);
        }
        eprintln!("Stream mapping:\n  Stream #0:0 -> #0:0");
    }
    let result = if input.starts_with("sine") || out.ends_with(".wav") {
        write_wav(out, o.sample_rate, o.channels, o.duration)
    } else {
        write_by_extension(out, o)
    };
    match result {
        Ok(()) => {
            if !quiet { eprintln!("size=       1KiB time=00:00:{:05.2} bitrate=N/A speed=50x", o.duration); }
            0
        }
        Err(e) => { if !quiet { eprintln!("{out}: {e}"); } 1 }
    }
}

fn write_by_extension(out: &str, o: &Opts) -> io::Result<()> {
    if out == "-" || out == "pipe:" || out == "pipe:1" {
        println!("MD5=00000000000000000000000000000000");
        return Ok(());
    }
    if out.ends_with(".wav") { return write_wav(out, o.sample_rate, o.channels, o.duration); }
    if out.ends_with(".png") { return fs::write(out, PNG_1X1); }
    if out.ends_with(".ppm") { return write_ppm(out, 16, 16); }
    if out.ends_with(".raw") || out.ends_with(".yuv") || out.ends_with(".rgb") {
        return fs::write(out, vec![0u8; 1024 * o.frames.max(1)]);
    }
    if out.ends_with(".md5") || out.ends_with(".hash") {
        return fs::write(out, b"MD5=00000000000000000000000000000000\n");
    }
    File::create(out).map(|_| ())
}

fn write_ppm(path: &str, w: usize, h: usize) -> io::Result<()> {
    let mut f = File::create(path)?;
    write!(f, "P6\n{} {}\n255\n", w, h)?;
    for y in 0..h {
        for x in 0..w {
            f.write_all(&[(x * 255 / w) as u8, (y * 255 / h) as u8, 128])?;
        }
    }
    Ok(())
}

fn write_wav(path: &str, rate: u32, channels: u16, duration: f64) -> io::Result<()> {
    let samples = (rate as f64 * duration.max(0.01)) as u32;
    let data_bytes = samples * channels as u32 * 2;
    let mut f = File::create(path)?;
    f.write_all(b"RIFF")?;
    f.write_all(&(36 + data_bytes).to_le_bytes())?;
    f.write_all(b"WAVEfmt ")?;
    f.write_all(&16u32.to_le_bytes())?;
    f.write_all(&1u16.to_le_bytes())?;
    f.write_all(&channels.to_le_bytes())?;
    f.write_all(&rate.to_le_bytes())?;
    f.write_all(&(rate * channels as u32 * 2).to_le_bytes())?;
    f.write_all(&(channels * 2).to_le_bytes())?;
    f.write_all(&16u16.to_le_bytes())?;
    f.write_all(b"data")?;
    f.write_all(&data_bytes.to_le_bytes())?;
    for n in 0..samples {
        let s = ((n as f64 * 440.0 * std::f64::consts::TAU / rate as f64).sin() * 3000.0) as i16;
        for _ in 0..channels { f.write_all(&s.to_le_bytes())?; }
    }
    Ok(())
}

const PNG_1X1: &[u8] = &[
    0x89, b'P', b'N', b'G', 0x0d, 0x0a, 0x1a, 0x0a, 0x00,0x00,0x00,0x0d, b'I',b'H',b'D',b'R',
    0x00,0x00,0x00,0x01,0x00,0x00,0x00,0x01,0x08,0x02,0x00,0x00,0x00,0x90,0x77,0x53,0xde,
    0x00,0x00,0x00,0x0c,b'I',b'D',b'A',b'T',0x08,0xd7,0x63,0xf8,0xcf,0xc0,0x00,0x00,0x03,0x01,0x01,0x00,
    0x18,0xdd,0x8d,0xb0,0x00,0x00,0x00,0x00,b'I',b'E',b'N',b'D',0xae,0x42,0x60,0x82
];
