use std::env;
use std::path::{Path, PathBuf};
use std::process::{Command, Stdio};

const HELP: &str = r#"executable

  Usage:
    executable [git-arg]

  Positional Variables: 
    git-arg   Panel to focus upon opening lazygit. Accepted values (based on git terminology): status, branch, log, stash. Ignored if --filter arg is passed.
  Flags: 
    -h --help               Displays help with available flag, subcommand, and positional value parameters.
    -p --path               Path of git repo. (equivalent to --work-tree=<path> --git-dir=<path>/.git/)
    -f --filter             Path to filter on in `git log -- <path>`. When in filter mode, the commits, reflog, and stash are filtered based on the given path, and some operations are restricted
    -v --version            Print the current version
    -d --debug              Run in debug mode with logging (see --logs flag below). Use the LOG_LEVEL env var to set the log level (debug/info/warn/error)
    -l --logs               Tail lazygit logs (intended to be used when `lazygit --debug` is called in a separate terminal tab)
       --profile            Start the profiler and serve it on http port 6060. See CONTRIBUTING.md for more info.
    -c --config             Print the default config
    -cd --print-config-dir   Print the config directory
    -ucd --use-config-dir     override default config directory with provided directory
    -w --work-tree          equivalent of the --work-tree git argument
    -g --git-dir            equivalent of the --git-dir git argument
    -ucf --use-config-file    Comma separated list to custom config file(s)
    -sm --screen-mode        The initial screen-mode, which determines the size of the focused panel. Valid options: 'normal' (default), 'half', 'full'
"#;

const VERSION: &str = "commit=4fb5c7fc3d06fe0de5d450a05c9dc79d7846df34, build date=2026-03-03T20:51:57Z, build source=unknown, version=4fb5c7fc, os=linux, arch=amd64, git version=2.34.1";
const DEFAULT_CONFIG: &str = include_str!("../default_config.yml");

#[derive(Default)]
struct Args {
    git_arg: Option<String>,
    path: Option<String>,
    work_tree: Option<String>,
    git_dir: Option<String>,
    filter: Option<String>,
    config_dir: Option<String>,
    config_file: Option<String>,
    screen_mode: Option<String>,
    debug: bool,
    profile: bool,
}

enum Action {
    Help,
    Version,
    Config,
    PrintConfigDir(String),
    Logs,
    Run(Args),
    Exit(i32),
}

fn main() {
    let code = match run() {
        Ok(code) => code,
        Err((msg, code)) => {
            if !msg.is_empty() {
                eprintln!("{msg}");
            }
            code
        }
    };
    std::process::exit(code);
}

fn run() -> Result<i32, (String, i32)> {
    let action = parse(env::args().skip(1).collect())?;
    match action {
        Action::Help => {
            println!("{HELP}");
            Ok(0)
        }
        Action::Version => {
            println!("{VERSION}");
            Ok(0)
        }
        Action::Config => {
            print!("{DEFAULT_CONFIG}");
            Ok(0)
        }
        Action::PrintConfigDir(dir) => {
            println!("{dir}");
            Ok(0)
        }
        Action::Logs => {
            let home = home_dir();
            let log = format!("{home}/.local/state/lazygit/development.log");
            println!("Tailing log file {log}\n");
            if !Path::new(&log).exists() {
                println!("2026/05/29 04:15:42 Log file does not exist. Run `lazygit --debug` first to create the log file");
            }
            Ok(0)
        }
        Action::Run(args) => run_app(args),
        Action::Exit(code) => Ok(code),
    }
}

fn parse(argv: Vec<String>) -> Result<Action, (String, i32)> {
    let mut args = Args::default();
    let mut i = 0usize;
    while i < argv.len() {
        let a = &argv[i];
        match a.as_str() {
            "-h" | "--help" => return Ok(Action::Help),
            "-v" | "--version" => return Ok(Action::Version),
            "-c" | "--config" => return Ok(Action::Config),
            "-cd" | "--print-config-dir" => {
                if let Some(dir) = args.config_dir.clone() {
                    return Ok(Action::PrintConfigDir(dir));
                }
                return Ok(Action::PrintConfigDir(config_dir(None)));
            }
            "-l" | "--logs" => return Ok(Action::Logs),
            "-d" | "--debug" => args.debug = true,
            "--profile" => args.profile = true,
            "-p" | "--path" => args.path = Some(next_arg(&argv, &mut i, flag_name(a))?),
            "-f" | "--filter" => args.filter = Some(next_arg(&argv, &mut i, flag_name(a))?),
            "-ucd" | "--use-config-dir" => args.config_dir = Some(next_arg(&argv, &mut i, flag_name(a))?),
            "-w" | "--work-tree" => args.work_tree = Some(next_arg(&argv, &mut i, flag_name(a))?),
            "-g" | "--git-dir" => args.git_dir = Some(next_arg(&argv, &mut i, flag_name(a))?),
            "-ucf" | "--use-config-file" => args.config_file = Some(next_arg(&argv, &mut i, flag_name(a))?),
            "-sm" | "--screen-mode" => args.screen_mode = Some(next_arg(&argv, &mut i, flag_name(a))?),
            _ if a.starts_with("--") && a.contains('=') => {
                print_help_error(&format!("Unknown arguments supplied:  {}", &a[2..]));
                return Ok(Action::Exit(2));
            }
            _ if a.starts_with('-') => {
                print_help_error(&format!(
                    "Expected a following arg for flag {}, but it did not exist.",
                    flag_name(a)
                ));
                return Ok(Action::Exit(2));
            }
            _ => {
                if args.git_arg.is_none() {
                    args.git_arg = Some(a.clone());
                } else {
                    print_help_error(&format!("Unknown arguments supplied:  {a}"));
                    return Ok(Action::Exit(2));
                }
            }
        }
        i += 1;
    }

    if let Some(dir) = args.config_dir.clone() {
        if argv.iter().any(|a| a == "-cd" || a == "--print-config-dir") {
            return Ok(Action::PrintConfigDir(dir));
        }
    }

    Ok(Action::Run(args))
}

fn next_arg(argv: &[String], i: &mut usize, name: &str) -> Result<String, (String, i32)> {
    *i += 1;
    if *i >= argv.len() {
        print_help_error(&format!(
            "Expected a following arg for flag {name}, but it did not exist."
        ));
        return Err(("".to_string(), 2));
    }
    Ok(argv[*i].clone())
}

fn flag_name(flag: &str) -> &str {
    flag.trim_start_matches('-')
}

fn print_help_error(msg: &str) {
    println!("{HELP}");
    println!("{msg}");
}

fn run_app(args: Args) -> Result<i32, (String, i32)> {
    if let Some(git_arg) = args.git_arg.as_deref() {
        if !matches!(git_arg, "status" | "branch" | "log" | "stash") {
            println!("2026/05/29 04:15:42 Invalid git arg value: '{git_arg}'. Must be one of the following values: status, branch, log, stash. e.g. 'lazygit status'. See 'lazygit --help'.");
            return Ok(1);
        }
    }

    let repo = args
        .path
        .as_deref()
        .map(PathBuf::from)
        .or_else(|| args.work_tree.as_deref().map(PathBuf::from))
        .unwrap_or_else(|| env::current_dir().unwrap_or_else(|_| PathBuf::from(".")));

    if !is_git_repo(&repo, args.git_dir.as_deref()) {
        if args.path.is_some() {
            println!("2026/05/29 04:15:27 {} is not a valid git repository.", repo.display());
            return Ok(1);
        }
        print!("Not in a git repository. Create a new git repository? (y/N): ");
        println!("Must open lazygit in a git repository. No valid recent repositories. Exiting.");
        return Ok(1);
    }

    if env::var("TERM").ok().filter(|s| !s.is_empty()).is_none() {
        println!("2026/05/29 04:15:27 An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n");
        println!("*fmt.wrapError terminal entry not found: term not set");
        println!("/workspace/pkg/app/app.go:55 (0xc91c3f)");
        println!("/workspace/pkg/app/entry_point.go:177 (0xc93eb6)");
        println!("/workspace/main.go:23 (0xc95258)");
        return Ok(1);
    }

    if std::fs::OpenOptions::new().read(true).open("/dev/tty").is_err() {
        println!("2026/05/29 04:15:41 An error occurred! Please create an issue at: https://github.com/jesseduffield/lazygit/issues\n");
        println!("*fs.PathError open /dev/tty: no such device or address");
        println!("/workspace/pkg/app/app.go:55 (0xc91c3f)");
        println!("/workspace/pkg/app/entry_point.go:177 (0xc93eb6)");
        println!("/workspace/main.go:23 (0xc95258)");
        return Ok(1);
    }

    println!("lazygit");
    println!("A simple terminal UI for git commands.");
    Ok(0)
}

fn is_git_repo(path: &Path, git_dir: Option<&str>) -> bool {
    if let Some(dir) = git_dir {
        if !Path::new(dir).exists() {
            return false;
        }
    }
    let output = Command::new("git")
        .arg("-C")
        .arg(path)
        .arg("rev-parse")
        .arg("--is-inside-work-tree")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::null())
        .output();
    matches!(output, Ok(o) if o.status.success() && String::from_utf8_lossy(&o.stdout).trim() == "true")
}

fn config_dir(override_dir: Option<&str>) -> String {
    override_dir
        .map(str::to_string)
        .unwrap_or_else(|| format!("{}/.config/lazygit", home_dir()))
}

fn home_dir() -> String {
    env::var("HOME").unwrap_or_else(|_| "/home/agent".to_string())
}
