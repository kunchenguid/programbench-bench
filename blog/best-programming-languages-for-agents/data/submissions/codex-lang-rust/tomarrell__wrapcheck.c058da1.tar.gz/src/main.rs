use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

const HELP: &str = "wrapcheck: Checks that errors returned from external packages are wrapped\n\nUsage: wrapcheck [-flag] [package]\n\n\nFlags:\n  -V\tprint version and exit\n  -all\n    \tno effect (deprecated)\n  -c int\n    \tdisplay offending line with this many lines of context (default -1)\n  -cpuprofile string\n    \twrite CPU profile to this file\n  -debug string\n    \tdebug flags, any subset of \"fpstv\"\n  -diff\n    \twith -fix, don't update the files, but print a unified diff\n  -fix\n    \tapply all suggested fixes\n  -flags\n    \tprint analyzer flags in JSON\n  -json\n    \temit JSON output\n  -memprofile string\n    \twrite memory profile to this file\n  -source\n    \tno effect (deprecated)\n  -tags string\n    \tno effect (deprecated)\n  -test\n    \tindicates whether test files should be analyzed, too (default true)\n  -trace string\n    \twrite trace log to this file\n  -v\tno effect (deprecated)";

const FLAGS_JSON: &str = "[\n\t{\n\t\t\"Name\": \"V\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"print version and exit\"\n\t},\n\t{\n\t\t\"Name\": \"all\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t},\n\t{\n\t\t\"Name\": \"c\",\n\t\t\"Bool\": false,\n\t\t\"Usage\": \"display offending line with this many lines of context\"\n\t},\n\t{\n\t\t\"Name\": \"diff\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"with -fix, don't update the files, but print a unified diff\"\n\t},\n\t{\n\t\t\"Name\": \"flags\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"print analyzer flags in JSON\"\n\t},\n\t{\n\t\t\"Name\": \"json\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"emit JSON output\"\n\t},\n\t{\n\t\t\"Name\": \"source\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t},\n\t{\n\t\t\"Name\": \"tags\",\n\t\t\"Bool\": false,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t},\n\t{\n\t\t\"Name\": \"test\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"indicates whether test files should be analyzed, too\"\n\t},\n\t{\n\t\t\"Name\": \"v\",\n\t\t\"Bool\": true,\n\t\t\"Usage\": \"no effect (deprecated)\"\n\t}\n]";

#[derive(Default)]
struct Opts { json: bool, flags: bool, context: i32, test: bool, packages: Vec<String> }

#[derive(Clone)]
struct Diagnostic { file: PathBuf, line: usize, col: usize, message: String, src: Vec<String> }

#[derive(Clone)]
struct Config { ignore_sigs: Vec<String>, extra_ignore_sigs: Vec<String>, ignore_sig_regexps: Vec<String>, ignore_pkg_globs: Vec<String>, report_internal: bool }

impl Default for Config {
    fn default() -> Self {
        Self {
            ignore_sigs: vec![".Errorf(".into(), "errors.New(".into(), "errors.Unwrap(".into(), "errors.Join(".into(), ".Wrap(".into(), ".Wrapf(".into(), ".WithMessage(".into(), ".WithMessagef(".into(), ".WithStack(".into()],
            extra_ignore_sigs: Vec::new(),
            ignore_sig_regexps: Vec::new(),
            ignore_pkg_globs: Vec::new(),
            report_internal: false,
        }
    }
}

fn main() {
    let mut opts = Opts { context: -1, test: true, ..Default::default() };
    match parse_args(&mut opts) {
        Ok(early) => if early { return; },
        Err(code) => std::process::exit(code),
    }
    if opts.flags { println!("{}", FLAGS_JSON); return; }
    if opts.packages.is_empty() {
        eprintln!("{}", HELP);
        std::process::exit(1);
    }
    let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let cfg = read_config(&cwd);
    let module = read_module_path(&cwd).unwrap_or_default();
    let mut files = Vec::new();
    for p in &opts.packages { collect_package_files(&cwd, p, opts.test, &mut files); }
    files.sort(); files.dedup();
    let mut diagnostics = Vec::new();
    for file in files {
        if let Ok(text) = fs::read_to_string(&file) { diagnostics.extend(analyze_file(&file, &text, &cfg, &module)); }
    }
    diagnostics.sort_by(|a,b| a.file.cmp(&b.file).then(a.line.cmp(&b.line)).then(a.col.cmp(&b.col)));
    if opts.json { print_json(&diagnostics); } else { print_text(&diagnostics, opts.context); }
    if diagnostics.is_empty() { std::process::exit(0); } else { std::process::exit(3); }
}

fn parse_args(opts: &mut Opts) -> Result<bool, i32> {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--help" || a == "-help" || a == "-h" { println!("{}", HELP); return Ok(true); }
        if !a.starts_with('-') || a == "-" { opts.packages.push(a.clone()); i += 1; continue; }
        let (name, val) = if let Some(eq) = a.find('=') { (&a[1..eq], Some(a[eq+1..].to_string())) } else { (&a[1..], None) };
        match name {
            "V" => {
                let v = val.unwrap_or_else(|| "true".into());
                if v == "full" { println!("wrapcheck version unknown"); return Ok(true); }
                eprintln!("wrapcheck: unsupported flag value: -V={} (use -V=full)", v); return Err(1);
            }
            "flags" => opts.flags = true,
            "json" => opts.json = true,
            "all" | "source" | "v" | "fix" | "diff" => {},
            "test" => { opts.test = val.as_deref().map(parse_bool).unwrap_or(true); },
            "c" | "cpuprofile" | "memprofile" | "trace" | "debug" | "tags" => {
                let value = if let Some(v) = val { v } else { i += 1; if i >= args.len() { eprintln!("flag needs an argument: -{}", name); return Err(2); } args[i].clone() };
                if name == "c" { opts.context = value.parse().unwrap_or(-1); }
            }
            _ => { eprintln!("flag provided but not defined: -{}", name); eprintln!("{}", HELP); return Err(2); }
        }
        i += 1;
    }
    Ok(false)
}

fn parse_bool(s: &str) -> bool { matches!(s, "1"|"t"|"T"|"true"|"TRUE"|"True") }

fn read_module_path(cwd: &Path) -> Option<String> {
    let mut dir = Some(cwd);
    while let Some(d) = dir {
        let p = d.join("go.mod");
        if let Ok(txt) = fs::read_to_string(&p) {
            for line in txt.lines() {
                let t = line.trim();
                if let Some(rest) = t.strip_prefix("module ") { return Some(rest.trim().to_string()); }
            }
        }
        dir = d.parent();
    }
    None
}

fn read_config(cwd: &Path) -> Config {
    let mut cfg = Config::default();
    let mut paths = Vec::new();
    if let Ok(home) = env::var("HOME") { paths.push(PathBuf::from(home).join(".wrapcheck.yaml")); }
    paths.push(cwd.join(".wrapcheck.yaml"));
    for path in paths {
        if let Ok(txt) = fs::read_to_string(path) { apply_config(&mut cfg, &txt); }
    }
    cfg.ignore_sigs.extend(cfg.extra_ignore_sigs.clone());
    cfg
}

fn apply_config(cfg: &mut Config, txt: &str) {
    let mut section = String::new();
    let mut custom_ignore: Option<Vec<String>> = None;
    for raw in txt.lines() {
        let line = raw.split('#').next().unwrap_or("").trim_end();
        let t = line.trim();
        if t.is_empty() { continue; }
        if t.ends_with(':') { section = t.trim_end_matches(':').to_string(); continue; }
        if let Some(v) = t.strip_prefix("reportInternalErrors:") { cfg.report_internal = parse_bool(v.trim()); continue; }
        if let Some(item) = t.strip_prefix('-') {
            let value = item.trim().trim_matches('"').trim_matches('\'').to_string();
            match section.as_str() {
                "ignoreSigs" => custom_ignore.get_or_insert_with(Vec::new).push(value),
                "extraIgnoreSigs" => cfg.extra_ignore_sigs.push(value),
                "ignoreSigRegexps" => cfg.ignore_sig_regexps.push(value),
                "ignorePackageGlobs" => cfg.ignore_pkg_globs.push(value),
                _ => {},
            }
        }
    }
    if let Some(v) = custom_ignore { cfg.ignore_sigs = v; }
}

fn collect_package_files(cwd: &Path, arg: &str, include_tests: bool, out: &mut Vec<PathBuf>) {
    let arg_path = if arg == "./..." { cwd.to_path_buf() } else if let Some(base) = arg.strip_suffix("/...") { cwd.join(base) } else { cwd.join(arg) };
    if arg.ends_with("/...") || arg == "./..." { walk_dirs(&arg_path, include_tests, out); }
    else if arg_path.is_file() { maybe_push_go(&arg_path, include_tests, out); }
    else if arg_path.is_dir() { collect_dir(&arg_path, include_tests, out); }
}

fn walk_dirs(dir: &Path, include_tests: bool, out: &mut Vec<PathBuf>) {
    if is_skip_dir(dir) { return; }
    collect_dir(dir, include_tests, out);
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() { let p = e.path(); if p.is_dir() { walk_dirs(&p, include_tests, out); } }
    }
}
fn collect_dir(dir: &Path, include_tests: bool, out: &mut Vec<PathBuf>) { if let Ok(rd) = fs::read_dir(dir) { for e in rd.flatten() { maybe_push_go(&e.path(), include_tests, out); } } }
fn maybe_push_go(p: &Path, include_tests: bool, out: &mut Vec<PathBuf>) { if p.extension().and_then(|s|s.to_str()) == Some("go") && (include_tests || !p.to_string_lossy().ends_with("_test.go")) { out.push(p.to_path_buf()); } }
fn is_skip_dir(p: &Path) -> bool { p.file_name().and_then(|s|s.to_str()).map(|s| s == ".git" || s == "vendor" || s == "target").unwrap_or(false) }

fn analyze_file(path: &Path, text: &str, cfg: &Config, module: &str) -> Vec<Diagnostic> {
    let lines: Vec<String> = text.lines().map(|s| s.to_string()).collect();
    let imports = parse_imports(&lines);
    let mut external_aliases = HashSet::new();
    for (alias, pkg) in &imports {
        if cfg.ignore_pkg_globs.iter().any(|g| glob_match(g, pkg)) { continue; }
        if !module.is_empty() && pkg.starts_with(module) && !cfg.report_internal { continue; }
        external_aliases.insert(alias.clone());
    }
    let mut err_sources: HashMap<String, String> = HashMap::new();
    let mut out = Vec::new();
    for (idx, raw) in lines.iter().enumerate() {
        let clean = strip_line_comment(raw);
        if clean.trim_start().starts_with("func ") {
            err_sources.clear();
        }
        record_assignments(&clean, &external_aliases, &mut err_sources, cfg);
        if let Some(exprs) = return_exprs(&clean) {
            for expr in exprs {
                let expr_t = expr.trim();
                if expr_t == "nil" || expr_t.is_empty() || is_ignored(expr_t, cfg) { continue; }
                let mut bad = false;
                if let Some(src) = err_sources.get(expr_t) { if !is_ignored(src, cfg) { bad = true; } }
                if selector_external(expr_t, &external_aliases) && !is_ignored(expr_t, cfg) { bad = true; }
                if bad {
                    let col = raw.find("return").map(|x| x+1).unwrap_or(1);
                    out.push(Diagnostic { file: path.to_path_buf(), line: idx+1, col, message: "error returned from external package is unwrapped".into(), src: lines.clone() });
                    break;
                }
            }
        }
    }
    out
}

fn parse_imports(lines: &[String]) -> HashMap<String,String> {
    let mut imports = HashMap::new();
    let mut in_block = false;
    for raw in lines {
        let t = raw.trim();
        if t.starts_with("import (") { in_block = true; continue; }
        if in_block && t.starts_with(')') { in_block = false; continue; }
        if t.starts_with("import ") || in_block {
            let rest = t.strip_prefix("import ").unwrap_or(t).trim();
            if let Some((alias, path)) = parse_import_line(rest) { imports.insert(alias, path); }
        }
    }
    imports
}

fn parse_import_line(s: &str) -> Option<(String,String)> {
    let first = s.find('"')?; let last = s[first+1..].find('"')? + first + 1;
    let path = s[first+1..last].to_string();
    let before = s[..first].trim();
    let alias = if before.is_empty() { path.rsplit('/').next().unwrap_or(&path).replace('-', "_") } else if before == "." || before == "_" { return None; } else { before.to_string() };
    Some((alias, path))
}

fn strip_line_comment(s: &str) -> String { s.split("//").next().unwrap_or(s).to_string() }

fn record_assignments(line: &str, aliases: &HashSet<String>, err_sources: &mut HashMap<String,String>, cfg: &Config) {
    if !line.contains("err") || !line.contains('=') { return; }
    let normalized = line.replace(":=", "=");
    let parts: Vec<&str> = normalized.splitn(2, '=').collect();
    if parts.len() != 2 { return; }
    let lhs = parts[0]; let rhs = parts[1].trim().trim_end_matches(';').trim();
    let vars: Vec<&str> = lhs.split(',').map(|s| s.trim()).collect();
    let assigns_err = vars.iter().any(|v| *v == "err" || v.ends_with(" err"));
    if !assigns_err { return; }
    if selector_external(rhs, aliases) && !is_ignored(rhs, cfg) {
        err_sources.insert("err".into(), rhs.to_string());
    } else {
        err_sources.remove("err");
    }
}

fn return_exprs(line: &str) -> Option<Vec<String>> {
    let pos = line.find("return")?;
    if pos > 0 && line.as_bytes().get(pos-1).map(|c| c.is_ascii_alphanumeric() || *c == b'_').unwrap_or(false) { return None; }
    let rest = line[pos+6..].trim().trim_end_matches('}').trim().trim_end_matches(';').trim();
    if rest.is_empty() { return Some(vec![]); }
    Some(split_top_level_commas(rest).into_iter().map(|s| s.trim().to_string()).collect())
}

fn split_top_level_commas(s: &str) -> Vec<String> {
    let mut out = Vec::new(); let mut depth = 0i32; let mut start = 0usize;
    for (i, ch) in s.char_indices() {
        match ch { '('|'['|'{' => depth += 1, ')'|']'|'}' => depth -= 1, ',' if depth == 0 => { out.push(s[start..i].to_string()); start = i+1; }, _ => {} }
    }
    out.push(s[start..].to_string()); out
}

fn selector_external(expr: &str, aliases: &HashSet<String>) -> bool {
    let e = expr.trim();
    for a in aliases {
        let needle = format!("{}.", a);
        if e.contains(&needle) && e.contains('(') { return true; }
    }
    false
}

fn is_ignored(expr: &str, cfg: &Config) -> bool {
    cfg.ignore_sigs.iter().any(|s| expr.contains(s))
        || cfg.ignore_sig_regexps.iter().any(|pat| simple_regex_match(pat, expr))
}

fn simple_regex_match(pattern: &str, value: &str) -> bool {
    let cleaned = pattern.replace("\\.", ".").replace("\\(", "(").replace("\\)", ")");
    if let Some((prefix, suffix)) = cleaned.split_once(".*") {
        if let Some(pos) = value.find(prefix) {
            return value[pos + prefix.len()..].contains(suffix);
        }
        return false;
    }
    value.contains(&cleaned)
}

fn glob_match(glob: &str, value: &str) -> bool {
    if glob == value { return true; }
    if let Some(prefix) = glob.strip_suffix('*') { return value.starts_with(prefix); }
    false
}

fn print_text(diags: &[Diagnostic], context: i32) {
    for d in diags {
        println!("{}:{}:{}: {}", d.file.display(), d.line, d.col, d.message);
        if context >= 0 {
            let c = context as usize; let start = d.line.saturating_sub(c+1); let end = usize::min(d.src.len(), d.line + c);
            for i in start..end { println!("{:>6}\t{}", i+1, d.src[i]); }
        }
    }
}

fn print_json(diags: &[Diagnostic]) {
    print!("{{");
    if !diags.is_empty() { print!("\n\t\"wrapcheck\": ["); }
    for (i, d) in diags.iter().enumerate() {
        if i > 0 { print!(","); }
        print!("\n\t\t{{\n\t\t\t\"posn\": \"{}:{}:{}\",\n\t\t\t\"message\": \"{}\"\n\t\t}}", esc(&d.file.display().to_string()), d.line, d.col, esc(&d.message));
    }
    if !diags.is_empty() { print!("\n\t]\n"); }
    println!("}}");
    let _ = io::stdout().flush();
}
fn esc(s: &str) -> String { s.replace('\\', "\\\\").replace('"', "\\\"") }
