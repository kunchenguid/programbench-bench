use regex::Regex;
use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, BufRead};
use std::path::{Path, PathBuf};

const SHORT_HELP: &str = "A command-line tool to prevent committing secret keys into your source code\n\nUsage: executable [OPTIONS] [Source files]...\n\nArguments:\n  [Source files]...  Source files. Can be files or directories. Defaults to '.'\n\nOptions:\n      --install-pre-commit\n          Install `ripsecrets` as a pre-commit hook automatically in git directory provided\n      --strict-ignore\n          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit\n      --only-matching\n          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line\n      --additional-pattern <ADDITIONAL_PATTERNS>\n          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret\n  -h, --help\n          Print help (see more with '--help')\n  -V, --version\n          Print version\n";

const LONG_HELP: &str = "ripsecrets searches files and directories recursively for secret API keys.\nIt's primarily designed to be used as a pre-commit to prevent committing\nsecrets into version control.\n\nUsage: executable [OPTIONS] [Source files]...\n\nArguments:\n  [Source files]...\n          Source files. Can be files or directories. Defaults to '.'\n\nOptions:\n      --install-pre-commit\n          Install `ripsecrets` as a pre-commit hook automatically in git directory provided\n\n      --strict-ignore\n          If you pass a path as an argument that's ignored by .secretsignore it will be scanned by default. --strict-ignore will override this behavior and not search the paths passed as arguments that are excluded by the .secretsignore file. This is useful when invoking secrets as a pre-commit\n\n      --only-matching\n          Print only the matched (non-empty) parts of a matching line, with each such part on a separate output line\n\n      --additional-pattern <ADDITIONAL_PATTERNS>\n          Additional regex patterns used to find secrets. If there is a matching group in the regex the matched group will be tested for randomness before being reported as a secret\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version\n";

#[derive(Debug)]
struct Args {
    install_pre_commit: bool,
    strict_ignore: bool,
    only_matching: bool,
    additional: Vec<String>,
    paths: Vec<String>,
}

#[derive(Clone)]
struct SecretMatch { start: usize, end: usize, text: String }
struct Pattern { re: Regex, group: Option<usize>, random: bool }
#[derive(Default)]
struct IgnoreRules { path_patterns: Vec<String>, secrets: HashSet<String> }

fn main() {
    let args = match parse_args() { Ok(a) => a, Err(code) => std::process::exit(code) };
    if args.install_pre_commit { install_pre_commit(); return; }

    let mut patterns = builtin_patterns();
    for p in &args.additional {
        match Regex::new(p) {
            Ok(re) => {
                let group = if re.captures_len() > 1 { Some(1) } else { Some(0) };
                patterns.push(Pattern { re, group, random: group == Some(1) });
            }
            Err(e) => { eprintln!("error: {e}"); std::process::exit(2); }
        }
    }

    let roots: Vec<String> = if args.paths.is_empty() { vec![".".to_string()] } else { args.paths.clone() };
    let ignore = load_ignore(Path::new(".secretsignore"));
    let mut files = Vec::new();
    for root in &roots {
        let p = Path::new(root);
        if !p.exists() {
            println!("{}: No such file or directory (os error 2)", root);
            continue;
        }
        let apply_to_root = args.strict_ignore || args.paths.is_empty();
        collect_files(p, &mut files, &ignore, apply_to_root);
    }

    let mut found = false;
    for file in files {
        if scan_file(&file, &patterns, &ignore.secrets, args.only_matching) { found = true; }
    }
    if found { std::process::exit(1); }
}

fn parse_args() -> Result<Args, i32> {
    let mut args = Args { install_pre_commit: false, strict_ignore: false, only_matching: false, additional: Vec::new(), paths: Vec::new() };
    let mut iter = env::args().skip(1).peekable();
    while let Some(arg) = iter.next() {
        match arg.as_str() {
            "-h" => { print!("{}", SHORT_HELP); return Err(0); }
            "--help" => { print!("{}", LONG_HELP); return Err(0); }
            "-V" | "--version" => { println!("ripsecrets 0.1.11"); return Err(0); }
            "--install-pre-commit" => args.install_pre_commit = true,
            "--strict-ignore" => args.strict_ignore = true,
            "--only-matching" => args.only_matching = true,
            "--additional-pattern" => {
                if let Some(v) = iter.next() { args.additional.push(v); } else { eprintln!("error: a value is required for '--additional-pattern <ADDITIONAL_PATTERNS>' but none was supplied"); return Err(2); }
            }
            "--" => { args.paths.extend(iter); break; }
            a if a.starts_with("--additional-pattern=") => args.additional.push(a[21..].to_string()),
            a if a.starts_with('-') => {
                eprintln!("error: unexpected argument '{a}' found\n\n  tip: to pass '{a}' as a value, use '-- {a}'\n\nUsage: executable [OPTIONS] [Source files]...\n\nFor more information, try '--help'.");
                return Err(2);
            }
            _ => args.paths.push(arg),
        }
    }
    Ok(args)
}

fn builtin_patterns() -> Vec<Pattern> {
    let specs: &[(&str, Option<usize>, bool)] = &[
        (r#"(?i)(?:aws_access_key_id|aws.{0,20}access.{0,20}key.{0,20}id)\s*[:=]\s*['\"]?(AKIA[0-9A-Z]{16})"#, Some(1), false),
        (r#"(?i)(?:aws_secret_access_key|aws.{0,20}secret.{0,20}(?:access)?.{0,20}key)\s*[:=]\s*['\"]?([A-Za-z0-9/+=]{40})"#, Some(1), true),
        (r#"AIza[0-9A-Za-z_\-]{35}"#, Some(0), false),
        (r#"[A-Za-z]+://\S{3,50}:(\S{8,50})@[\dA-Za-z#%&+./:=?_~-]+"#, Some(1), true),
        (r#"\beyJ[\dA-Za-z=_-]+(?:\.[\dA-Za-z=_-]{3,}){1,4}"#, Some(0), false),
        (r#"xox[aboprs]-(?:\d+-)+[\da-z]+"#, Some(0), false),
        (r#"(?:gh[oprsu]|github_pat)_[\dA-Za-z_]{36}"#, Some(0), false),
        (r#"github_pat_[A-Za-z0-9_]{22,}_[A-Za-z0-9_]{59,}"#, Some(0), false),
        (r#"glpat-[\dA-Za-z_=-]{20,22}"#, Some(0), false),
        (r#"[rs]k_live_[\dA-Za-z]{24,247}"#, Some(0), false),
        (r#"sq0i[a-z]{2}-[\dA-Za-z_-]{22,43}"#, Some(0), false),
        (r#"sq0c[a-z]{2}-[\dA-Za-z_-]{40,50}"#, Some(0), false),
        (r#"EAAA[\dA-Za-z+=-]{60}"#, Some(0), false),
        (r#"AccountKey=[\d+/=A-Za-z]{88}"#, Some(0), false),
        (r#"npm_[\dA-Za-z]{36}"#, Some(0), false),
        (r#"//.+/:_authToken=[\dA-Za-z_-]+"#, Some(0), false),
        (r#"https://hooks\.slack\.com/services/T[\dA-Za-z_]+/B[\dA-Za-z_]+/[\dA-Za-z_]+"#, Some(0), false),
        (r#"SG\.[\dA-Za-z_-]{22}\.[\dA-Za-z_-]{43}"#, Some(0), false),
        (r#"(?:AC|SK)[\da-z]{32}"#, Some(0), false),
        (r#"[\da-f]{32}-us\d{1,2}"#, Some(0), false),
        (r#"AGE-SECRET-KEY-1[\dA-Z]{58}"#, Some(0), false),
        (r#"(?i)-----BEGIN (?:RSA |DSA |EC |OPENSSH |PGP |SSH2 ENCRYPTED )?(?:PRIVATE KEY|PRIVATE KEY BLOCK)-----"#, Some(0), false),
        (r#"(?i)(?:key|token|secret|password)\w*["']?]?\s*(?:[:=]|:=|=>|<-|>)\s*[\t "'`]?(\w[\w+./=~\-\`^]{14,89})(?:[\t \n"'`]|</|$)"#, Some(1), true),
    ];
    specs.iter().map(|(s, g, r)| Pattern { re: Regex::new(s).unwrap(), group: *g, random: *r }).collect()
}

fn install_pre_commit() {
    let git = Path::new(".git/hooks");
    let _ = fs::create_dir_all(git);
    let hook = git.join("pre-commit");
    let content = "ripsecrets --strict-ignore `git diff --cached --name-only --diff-filter=ACM`\n";
    if let Err(e) = fs::write(&hook, content) { eprintln!("{e}"); return; }
    #[cfg(unix)]
    {
        use std::os::unix::fs::PermissionsExt;
        let _ = fs::set_permissions(&hook, fs::Permissions::from_mode(0o744));
    }
}

fn load_ignore(path: &Path) -> IgnoreRules {
    let mut rules = IgnoreRules::default();
    let Ok(text) = fs::read_to_string(path) else { return rules; };
    let mut in_secrets = false;
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        if line.eq_ignore_ascii_case("[secrets]") { in_secrets = true; continue; }
        if in_secrets { rules.secrets.insert(line.to_string()); } else { rules.path_patterns.push(line.to_string()); }
    }
    rules
}

fn collect_files(path: &Path, out: &mut Vec<PathBuf>, ignore: &IgnoreRules, apply_ignore: bool) {
    if apply_ignore && is_ignored(path, ignore) { return; }
    match fs::metadata(path) {
        Ok(md) if md.is_file() => out.push(path.to_path_buf()),
        Ok(md) if md.is_dir() => {
            let Ok(entries) = fs::read_dir(path) else { return; };
            let mut entries: Vec<_> = entries.filter_map(Result::ok).collect();
            entries.sort_by_key(|e| e.path());
            for e in entries {
                let p = e.path();
                if p.file_name().and_then(|s| s.to_str()) == Some(".git") { continue; }
                collect_files(&p, out, ignore, true);
            }
        }
        _ => {}
    }
}

fn is_ignored(path: &Path, ignore: &IgnoreRules) -> bool {
    let s = normalize(path);
    let base = path.file_name().and_then(|x| x.to_str()).unwrap_or("");
    for pat in &ignore.path_patterns {
        let p = pat.trim_start_matches("./");
        if p.ends_with('/') {
            let d = p.trim_end_matches('/');
            if s == d || s.starts_with(&format!("{d}/")) || base == d { return true; }
        } else if p.contains('*') || p.contains('?') {
            if glob_match(p, &s) || glob_match(p, base) { return true; }
        } else if s == p || s.ends_with(&format!("/{p}")) || base == p { return true; }
    }
    false
}

fn normalize(path: &Path) -> String {
    let mut s = path.to_string_lossy().replace('\\', "/");
    while s.starts_with("./") { s = s[2..].to_string(); }
    s
}

fn display_path(path: &Path) -> String {
    path.to_string_lossy().replace('\\', "/")
}

fn glob_match(pat: &str, text: &str) -> bool {
    let mut re = String::from("^");
    for ch in pat.chars() {
        match ch { '*' => re.push_str(".*"), '?' => re.push('.'), '.' => re.push_str("\\."), '/' => re.push('/'), c => re.push_str(&regex::escape(&c.to_string())) }
    }
    re.push('$');
    Regex::new(&re).map(|r| r.is_match(text)).unwrap_or(false)
}

fn scan_file(path: &Path, patterns: &[Pattern], ignored_secrets: &HashSet<String>, only: bool) -> bool {
    let Ok(f) = fs::File::open(path) else { return false; };
    let reader = io::BufReader::new(f);
    let mut found_any = false;
    for (idx, line_res) in reader.lines().enumerate() {
        let Ok(line) = line_res else { continue; };
        let mut matches = Vec::new();
        for pat in patterns {
            for caps in pat.re.captures_iter(&line) {
                let m = caps.get(pat.group.unwrap_or(0)).or_else(|| caps.get(0));
                if let Some(m) = m {
                    let text = m.as_str().trim_matches(|c| c == '\'' || c == '"').to_string();
                    if text.is_empty() || ignored_secrets.contains(&text) { continue; }
                    if pat.random && !looks_random(&text) { continue; }
                    matches.push(SecretMatch { start: m.start(), end: m.end(), text });
                }
            }
        }
        if matches.is_empty() { continue; }
        matches.sort_by_key(|m| (m.start, m.end));
        matches.dedup_by(|a, b| a.start == b.start && a.end == b.end && a.text == b.text);
        found_any = true;
        let display = display_path(path);
        if only { for m in matches { println!("{}:{}:{}", display, idx + 1, m.text); } }
        else { println!("{}:{}:{}", display, idx + 1, line); }
    }
    found_any
}

fn looks_random(s: &str) -> bool {
    let len = s.len();
    let low = s.to_ascii_lowercase();
    if low.chars().all(|c| c == low.chars().next().unwrap_or('\0')) { return false; }
    if low.contains("abcdefghijklmnopqrstuvwxyz") || low.contains("0123456789") { return false; }
    if len == 4 { return true; }
    if len >= 32 { return true; }
    if len < 4 { return false; }
    let classes = [
        s.chars().any(|c| c.is_ascii_lowercase()),
        s.chars().any(|c| c.is_ascii_uppercase()),
        s.chars().any(|c| c.is_ascii_digit()),
        s.chars().any(|c| "_-/+=".contains(c)),
    ].iter().filter(|x| **x).count();
    classes >= 2 || len >= 8
}
