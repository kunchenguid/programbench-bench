use regex::{Regex, RegexBuilder};
use std::collections::HashSet;
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};

const HELP: &str = r#"
Usage: ag [FILE-TYPE] [OPTIONS] PATTERN [PATH]

  Recursively search for PATTERN in PATH.
  Like grep or ack, but faster.

Example:
  ag -i foo /bar/

Output Options:
     --ackmate            Print results in AckMate-parseable format
  -A --after [LINES]      Print lines after match (Default: 2)
  -B --before [LINES]     Print lines before match (Default: 2)
     --[no]break          Print newlines between matches in different files
                          (Enabled by default)
  -c --count              Only print the number of matches in each file.
                          (This often differs from the number of matching lines)
     --[no]color          Print color codes in results (Enabled by default)
     --color-line-number  Color codes for line numbers (Default: 1;33)
     --color-match        Color codes for result match numbers (Default: 30;43)
     --color-path         Color codes for path names (Default: 1;32)
     --column             Print column numbers in results
     --[no]filename       Print file names (Enabled unless searching a single file)
  -H --[no]heading        Print file names before each file's matches
                          (Enabled by default)
  -C --context [LINES]    Print lines before and after matches (Default: 2)
     --[no]group          Same as --[no]break --[no]heading
  -g --filename-pattern PATTERN
                          Print filenames matching PATTERN
  -l --files-with-matches Only print filenames that contain matches
                          (don't print the matching lines)
  -L --files-without-matches
                          Only print filenames that don't contain matches
     --print-all-files    Print headings for all files searched, even those that
                          don't contain matches
     --[no]numbers        Print line numbers. Default is to omit line numbers
                          when searching streams
  -o --only-matching      Prints only the matching part of the lines
     --print-long-lines   Print matches on very long lines (Default: >2k characters)
     --passthrough        When searching a stream, print all lines even if they
                          don't match
     --silent             Suppress all log messages, including errors
     --stats              Print stats (files scanned, time taken, etc.)
     --stats-only         Print stats and nothing else.
                          (Same as --count when searching a single file)
     --vimgrep            Print results like vim's :vimgrep /pattern/g would
                          (it reports every match on the line)
  -0 --null --print0      Separate filenames with null (for 'xargs -0')

Search Options:
  -a --all-types          Search all files (doesn't include hidden files
                          or patterns from ignore files)
  -D --debug              Ridiculous debugging (probably not useful)
     --depth NUM          Search up to NUM directories deep (Default: 25)
  -f --follow             Follow symlinks
  -F --fixed-strings      Alias for --literal for compatibility with grep
  -G --file-search-regex  PATTERN Limit search to filenames matching PATTERN
     --hidden             Search hidden files (obeys .*ignore files)
  -i --ignore-case        Match case insensitively
     --ignore PATTERN     Ignore files/directories matching PATTERN
                          (literal file/directory names also allowed)
     --ignore-dir NAME    Alias for --ignore for compatibility with ack.
  -m --max-count NUM      Skip the rest of a file after NUM matches (Default: 10,000)
     --one-device         Don't follow links to other devices.
  -p --path-to-ignore STRING
                          Use .ignore file at STRING
  -Q --literal            Don't parse PATTERN as a regular expression
  -s --case-sensitive     Match case sensitively
  -S --smart-case         Match case insensitively unless PATTERN contains
                          uppercase characters (Enabled by default)
     --search-binary      Search binary files for matches
  -t --all-text           Search all text files (doesn't include hidden files)
  -u --unrestricted       Search all files (ignore .ignore, .gitignore, etc.;
                          searches binary and hidden files as well)
  -U --skip-vcs-ignores   Ignore VCS ignore files
                          (.gitignore, .hgignore; still obey .ignore)
  -v --invert-match
  -w --word-regexp        Only match whole words
  -W --width NUM          Truncate match lines after NUM characters
  -z --search-zip         Search contents of compressed (e.g., gzip) files

File Types:
The search can be restricted to certain types of files. Example:
  ag --html needle
  - Searches for 'needle' in files with suffix .htm, .html, .shtml or .xhtml.

For a list of supported file types run:
  ag --list-file-types

ag was originally created by Geoff Greer. More information (and the latest release)
can be found at http://geoff.greer.fm/ag
"#;

const FILE_TYPES_TEXT: &str = include_str!("filetypes.txt");

#[derive(Clone, Copy, PartialEq)]
enum CaseMode {
    Smart,
    Insensitive,
    Sensitive,
}

#[derive(Default)]
struct Opts {
    after: usize,
    before: usize,
    count: bool,
    files_with: bool,
    files_without: bool,
    only_matching: bool,
    column: bool,
    vimgrep: bool,
    ackmate: bool,
    filename: Option<bool>,
    numbers: Option<bool>,
    color: bool,
    literal: bool,
    invert: bool,
    word: bool,
    hidden: bool,
    unrestricted: bool,
    all_types: bool,
    all_text: bool,
    search_binary: bool,
    no_recurse: bool,
    follow: bool,
    depth: isize,
    max_count: usize,
    null_sep: bool,
    passthrough: bool,
    silent: bool,
    stats: bool,
    stats_only: bool,
    print_all_files: bool,
    width: Option<usize>,
    file_regex: Option<String>,
    filename_pattern: Option<String>,
    ignores: Vec<String>,
    explicit_ignore_files: Vec<PathBuf>,
    case_mode: CaseMode,
    type_exts: Option<HashSet<String>>,
}

impl Default for CaseMode {
    fn default() -> Self {
        CaseMode::Smart
    }
}

#[derive(Clone)]
struct MatchLine {
    line_no: usize,
    text: String,
    spans: Vec<(usize, usize)>,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    match run(args) {
        Ok(code) => std::process::exit(code),
        Err((msg, code)) => {
            eprint!("{}", msg);
            std::process::exit(code);
        }
    }
}

fn run(args: Vec<String>) -> Result<i32, (String, i32)> {
    let mut opts = Opts { depth: 25, max_count: 10000, case_mode: CaseMode::Smart, ..Default::default() };
    let mut positionals: Vec<String> = Vec::new();
    let mut i = 0;
    let mut end_opts = false;
    while i < args.len() {
        let arg = &args[i];
        if end_opts || !arg.starts_with('-') || arg == "-" {
            positionals.push(arg.clone());
            i += 1;
            continue;
        }
        if arg == "--" {
            end_opts = true;
            i += 1;
            continue;
        }
        match arg.as_str() {
            "--help" | "-h" => {
                print!("{}", HELP);
                return Ok(0);
            }
            "--version" | "-V" => {
                println!("ag version 2.2.0\n\nFeatures:\n  +jit +lzma +zlib");
                return Ok(0);
            }
            "--list-file-types" => {
                print!("{}", FILE_TYPES_TEXT);
                return Ok(0);
            }
            "-i" | "--ignore-case" => opts.case_mode = CaseMode::Insensitive,
            "-s" | "--case-sensitive" => opts.case_mode = CaseMode::Sensitive,
            "-S" | "--smart-case" => opts.case_mode = CaseMode::Smart,
            "-Q" | "--literal" | "-F" | "--fixed-strings" => opts.literal = true,
            "-v" | "--invert-match" => opts.invert = true,
            "-w" | "--word-regexp" => opts.word = true,
            "-c" | "--count" => opts.count = true,
            "-l" | "--files-with-matches" => opts.files_with = true,
            "-L" | "--files-without-matches" => opts.files_without = true,
            "-o" | "--only-matching" => opts.only_matching = true,
            "--column" => opts.column = true,
            "--vimgrep" => { opts.vimgrep = true; opts.column = true; }
            "--ackmate" => opts.ackmate = true,
            "--filename" => opts.filename = Some(true),
            "--nofilename" | "--no-filename" => opts.filename = Some(false),
            "--numbers" => opts.numbers = Some(true),
            "--nonumbers" | "--no-numbers" => opts.numbers = Some(false),
            "--group" | "--nogroup" | "--no-group" | "--break" | "--nobreak" | "--no-break" | "-H" | "--heading" | "--noheading" | "--no-heading" => {}
            "--color" => opts.color = true,
            "--nocolor" | "--no-color" => opts.color = false,
            "--hidden" => opts.hidden = true,
            "-u" | "--unrestricted" => { opts.unrestricted = true; opts.hidden = true; opts.search_binary = true; }
            "-a" | "--all-types" => { opts.all_types = true; opts.search_binary = true; }
            "-t" | "--all-text" => opts.all_text = true,
            "--search-binary" => opts.search_binary = true,
            "-n" | "--norecurse" => opts.no_recurse = true,
            "-r" | "--recurse" => opts.no_recurse = false,
            "-f" | "--follow" => opts.follow = true,
            "--nofollow" | "--no-follow" => opts.follow = false,
            "--passthrough" | "--passthru" => opts.passthrough = true,
            "--silent" => opts.silent = true,
            "--stats" => opts.stats = true,
            "--stats-only" => opts.stats_only = true,
            "--print-all-files" => opts.print_all_files = true,
            "-0" | "--null" | "--print0" => opts.null_sep = true,
            "-D" | "--debug" | "--mmap" | "--nommap" | "--no-mmap" | "--multiline" | "--nomultiline" | "--no-multiline" | "--parallel" | "--one-device" | "--affinity" | "--noaffinity" | "--no-affinity" | "-z" | "--search-zip" => {}
            _ if arg == "-A" || arg == "--after" => opts.after = parse_optional_context(&args, &mut i, 2),
            _ if arg.starts_with("-A") && arg.len() > 2 => opts.after = parse_num(Some(&arg[2..].to_string()), "-A")?,
            _ if arg == "-B" || arg == "--before" => opts.before = parse_optional_context(&args, &mut i, 2),
            _ if arg.starts_with("-B") && arg.len() > 2 => opts.before = parse_num(Some(&arg[2..].to_string()), "-B")?,
            _ if arg == "-C" || arg == "--context" => { let n = parse_optional_context(&args, &mut i, 2); opts.before = n; opts.after = n; }
            _ if arg.starts_with("-C") && arg.len() > 2 => { let n = parse_num(Some(&arg[2..].to_string()), "-C")?; opts.before = n; opts.after = n; }
            "-m" | "--max-count" => { i += 1; opts.max_count = parse_num(args.get(i), arg)?; }
            "-W" | "--width" => { i += 1; opts.width = Some(parse_num(args.get(i), arg)?); }
            "--depth" => { i += 1; opts.depth = parse_num_signed(args.get(i), arg)?; }
            "-G" | "--file-search-regex" => { i += 1; opts.file_regex = Some(req_arg(args.get(i), arg)?); }
            "-g" | "--filename-pattern" => { i += 1; opts.filename_pattern = Some(req_arg(args.get(i), arg)?); }
            "--ignore" | "--ignore-dir" => { i += 1; opts.ignores.push(req_arg(args.get(i), arg)?); }
            "-p" | "--path-to-ignore" => { i += 1; opts.explicit_ignore_files.push(PathBuf::from(req_arg(args.get(i), arg)?)); }
            x if x.starts_with("--color-") || x == "--pager" || x == "--workers" => {
                if x == "--pager" || x == "--workers" {
                    i += 1;
                }
            }
            x if x.starts_with("--") => {
                if let Some(exts) = file_type_exts(&x[2..]) {
                    opts.type_exts = Some(exts.iter().map(|s| s.to_string()).collect());
                } else {
                    return Err((format!("/workspace/executable: unrecognized option '{}'\n{}", x, HELP), 1));
                }
            }
            x => return Err((format!("/workspace/executable: unrecognized option '{}'\n{}", x, HELP), 1)),
        }
        i += 1;
    }

    if let Some(pat) = opts.filename_pattern.clone() {
        let paths = if positionals.is_empty() { vec![PathBuf::from(".")] } else { positionals.iter().map(PathBuf::from).collect() };
        let re = build_regex(&pat, &opts)?;
        let mut found = false;
        for f in collect_files(&paths, &opts) {
            let s = display_path(&f);
            if re.is_match(&s) {
                print_name(&s, opts.null_sep);
                found = true;
            }
        }
        return Ok(if found { 0 } else { 1 });
    }

    if positionals.is_empty() {
        print!("{}", HELP);
        return Ok(1);
    }
    let pattern = positionals.remove(0);
    let paths: Vec<PathBuf> = if positionals.is_empty() { vec![PathBuf::from(".")] } else { positionals.iter().map(PathBuf::from).collect() };
    let re = build_regex(&pattern, &opts)?;

    if paths.len() == 1 && paths[0] == Path::new("-") {
        return search_stdin(&re, &opts);
    }

    let mut files = collect_files(&paths, &opts);
    let single_file = files.len() == 1 && paths.len() == 1 && paths[0].is_file();
    let mut any = false;
    let mut scanned = 0usize;
    for file in files.drain(..) {
        scanned += 1;
        let hit = search_file(&file, &re, &opts, single_file)?;
        any |= hit;
    }
    if opts.stats || opts.stats_only {
        println!("{} files searched", scanned);
    }
    Ok(if any { 0 } else { 1 })
}

fn parse_num(v: Option<&String>, opt: &str) -> Result<usize, (String, i32)> {
    req_arg(v, opt)?.parse::<usize>().map_err(|_| (format!("ERR: invalid value for {}\n", opt), 1))
}

fn parse_optional_context(args: &[String], i: &mut usize, default: usize) -> usize {
    if let Some(next) = args.get(*i + 1) {
        if let Ok(n) = next.parse::<usize>() {
            *i += 1;
            return n;
        }
    }
    default
}

fn parse_num_signed(v: Option<&String>, opt: &str) -> Result<isize, (String, i32)> {
    req_arg(v, opt)?.parse::<isize>().map_err(|_| (format!("ERR: invalid value for {}\n", opt), 1))
}

fn req_arg(v: Option<&String>, opt: &str) -> Result<String, (String, i32)> {
    v.cloned().ok_or_else(|| (format!("ERR: option {} requires an argument\n", opt), 1))
}

fn build_regex(pattern: &str, opts: &Opts) -> Result<Regex, (String, i32)> {
    let mut pat = if opts.literal { regex::escape(pattern) } else { pattern.to_string() };
    if opts.word {
        pat = format!(r"\b(?:{})\b", pat);
    }
    let insensitive = match opts.case_mode {
        CaseMode::Insensitive => true,
        CaseMode::Sensitive => false,
        CaseMode::Smart => !pattern.chars().any(|c| c.is_uppercase()),
    };
    RegexBuilder::new(&pat)
        .case_insensitive(insensitive)
        .multi_line(true)
        .build()
        .map_err(|e| (format!("ERR: Bad regex! {}\nIf you meant to search for a literal string, run ag with -Q\n", e), 2))
}

fn collect_files(paths: &[PathBuf], opts: &Opts) -> Vec<PathBuf> {
    let mut out = Vec::new();
    let mut ignores = opts.ignores.clone();
    if !opts.unrestricted {
        if let Some(home) = env::var_os("HOME") {
            read_ignore_file(&PathBuf::from(home).join(".agignore"), &mut ignores);
        }
        for p in &opts.explicit_ignore_files {
            read_ignore_file(p, &mut ignores);
        }
    }
    for p in paths {
        visit(p, p, opts, 0, &mut ignores.clone(), &mut out);
    }
    out
}

fn visit(path: &Path, root: &Path, opts: &Opts, depth: isize, ignores: &mut Vec<String>, out: &mut Vec<PathBuf>) {
    let meta = if opts.follow { fs::metadata(path) } else { fs::symlink_metadata(path) };
    let Ok(meta) = meta else {
        if !opts.silent {
            eprintln!("ERR: Error stat()ing: {}", path.display());
        }
        return;
    };
    let name = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
    if path != root && should_skip_name(name, path, opts, ignores) {
        return;
    }
    if meta.is_dir() {
        if path != root && opts.no_recurse {
            return;
        }
        if !opts.unrestricted {
            read_ignore_file(&path.join(".ignore"), ignores);
            read_ignore_file(&path.join(".agignore"), ignores);
            read_ignore_file(&path.join(".gitignore"), ignores);
            read_ignore_file(&path.join(".hgignore"), ignores);
        }
        if opts.depth >= 0 && depth > opts.depth {
            return;
        }
        let Ok(rd) = fs::read_dir(path) else { return; };
        let mut entries: Vec<PathBuf> = rd.filter_map(|e| e.ok().map(|e| e.path())).collect();
        entries.sort_by(|a, b| a.file_name().cmp(&b.file_name()));
        for e in entries {
            visit(&e, root, opts, depth + 1, &mut ignores.clone(), out);
        }
    } else if meta.is_file() {
        if file_allowed(path, opts) {
            out.push(path.to_path_buf());
        }
    }
}

fn read_ignore_file(path: &Path, ignores: &mut Vec<String>) {
    if let Ok(s) = fs::read_to_string(path) {
        for line in s.lines() {
            let t = line.trim();
            if !t.is_empty() && !t.starts_with('#') {
                ignores.push(t.trim_end_matches('/').to_string());
            }
        }
    }
}

fn should_skip_name(name: &str, path: &Path, opts: &Opts, ignores: &[String]) -> bool {
    if !opts.hidden && name.starts_with('.') {
        return true;
    }
    if opts.unrestricted {
        return false;
    }
    if name == ".git" || name == ".hg" || name == ".svn" {
        return true;
    }
    let full = display_path(path);
    ignores.iter().any(|p| glob_match(p, name) || glob_match(p, &full))
}

fn file_allowed(path: &Path, opts: &Opts) -> bool {
    if let Some(exts) = &opts.type_exts {
        let e = path.extension().and_then(|s| s.to_str()).unwrap_or("");
        let fname = path.file_name().and_then(|s| s.to_str()).unwrap_or("");
        if !exts.contains(e) && !exts.contains(fname) {
            return false;
        }
    }
    if let Some(pat) = &opts.file_regex {
        if let Ok(re) = Regex::new(pat) {
            if !re.is_match(&display_path(path)) {
                return false;
            }
        }
    }
    true
}

fn glob_match(pat: &str, text: &str) -> bool {
    if pat == text {
        return true;
    }
    if let Some(rest) = pat.strip_prefix("*.") {
        return text.ends_with(&format!(".{}", rest));
    }
    if pat.contains('*') {
        let parts: Vec<&str> = pat.split('*').collect();
        let mut pos = 0usize;
        for (idx, part) in parts.iter().enumerate() {
            if part.is_empty() {
                continue;
            }
            if idx == 0 && !text.starts_with(part) {
                return false;
            }
            if let Some(found) = text[pos..].find(part) {
                pos += found + part.len();
            } else {
                return false;
            }
        }
        if !pat.ends_with('*') && !text.ends_with(parts.last().unwrap_or(&"")) {
            return false;
        }
        return true;
    }
    text.contains(pat)
}

fn search_stdin(re: &Regex, opts: &Opts) -> Result<i32, (String, i32)> {
    let mut s = String::new();
    io::stdin().read_to_string(&mut s).map_err(|e| (format!("ERR: {}\n", e), 1))?;
    let matches = find_matches(&s, re, opts);
    if opts.passthrough {
        print!("{}", s);
        return Ok(0);
    }
    for m in &matches {
        if opts.only_matching {
            for (a, b) in &m.spans {
                println!("{}", &m.text[*a..*b]);
            }
        } else {
            println!("{}", m.text);
        }
    }
    Ok(if matches.is_empty() { 1 } else { 0 })
}

fn search_file(path: &Path, re: &Regex, opts: &Opts, single_file: bool) -> Result<bool, (String, i32)> {
    let bytes = match fs::read(path) {
        Ok(b) => b,
        Err(e) => {
            if !opts.silent { eprintln!("ERR: Error opening file {}: {}", path.display(), e); }
            return Ok(false);
        }
    };
    let is_binary = bytes.contains(&0);
    let text = String::from_utf8_lossy(&bytes).to_string();
    let matches = find_matches(&text, re, opts);
    if is_binary && !opts.search_binary && !opts.all_types {
        return Ok(false);
    }
    let has = !matches.is_empty();
    if is_binary && has && opts.search_binary && !opts.only_matching && !opts.count && !opts.files_with && !opts.files_without {
        println!("Binary file {} matches.", display_path(path));
        return Ok(true);
    }
    if opts.stats_only {
        return Ok(has);
    }
    let show_file = !single_file && opts.filename != Some(false);
    let show_nums = opts.numbers.unwrap_or(opts.filename != Some(false));
    let name = display_path(path);
    if opts.files_with {
        if has { print_name(&name, opts.null_sep); }
        return Ok(has);
    }
    if opts.files_without {
        if !has { print_name(&name, opts.null_sep); }
        return Ok(!has);
    }
    if opts.count {
        if has || opts.print_all_files {
            let c: usize = matches.iter().map(|m| if opts.invert { 1 } else { m.spans.len().max(1) }).sum();
            if show_file { println!("{}:{}", name, c); } else { println!("{}", c); }
        }
        return Ok(has);
    }
    if opts.ackmate {
        if has {
            println!(":{}", name);
            for m in &matches {
                let spans = m.spans.iter().map(|(a,b)| format!("{} {}", a, b-a)).collect::<Vec<_>>().join(",");
                println!("{};{}:{}", m.line_no, spans, m.text);
            }
            println!();
        }
        return Ok(has);
    }
    let lines: Vec<&str> = text.split('\n').collect();
    let matched_lines: HashSet<usize> = matches.iter().map(|m| m.line_no).collect();
    let mut printed_context = HashSet::new();
    for m in &matches {
        if opts.only_matching {
            for (a, b) in &m.spans {
                print_prefix(&name, m.line_no, *a + 1, show_file, show_nums, opts, ':');
                println!("{}", &m.text[*a..*b]);
            }
            continue;
        }
        if opts.vimgrep {
            for (a, _) in &m.spans {
                print_prefix(&name, m.line_no, *a + 1, show_file, true, opts, ':');
                println!("{}", truncate(&m.text, opts.width));
            }
            continue;
        }
        let start = m.line_no.saturating_sub(opts.before + 1) + 1;
        let end = usize::min(lines.len(), m.line_no + opts.after);
        for ln in start..=end {
            if !printed_context.insert(ln) { continue; }
            let is_match_line = matched_lines.contains(&ln);
            let sep = if is_match_line { ':' } else { '-' };
            let spans_for_line: &[(usize, usize)] = if ln == m.line_no { &m.spans } else { &[] };
            let col = if ln == m.line_no { m.spans.first().map(|s| s.0 + 1).unwrap_or(1) } else { 1 };
            print_prefix(&name, ln, col, show_file, show_nums, opts, sep);
            let line = lines.get(ln - 1).unwrap_or(&"");
            if opts.color && sep == ':' {
                println!("{}", color_line(line, spans_for_line));
            } else {
                println!("{}", truncate(line, opts.width));
            }
        }
    }
    Ok(has)
}

fn find_matches(text: &str, re: &Regex, opts: &Opts) -> Vec<MatchLine> {
    let mut out = Vec::new();
    for (idx, line) in text.split('\n').enumerate() {
        if idx == text.split('\n').count() - 1 && line.is_empty() && text.ends_with('\n') {
            continue;
        }
        let spans: Vec<(usize, usize)> = re.find_iter(line).map(|m| (m.start(), m.end())).collect();
        let is_match = !spans.is_empty();
        if is_match ^ opts.invert {
            out.push(MatchLine {
                line_no: idx + 1,
                text: line.to_string(),
                spans: if opts.invert { vec![(0, line.len())] } else { spans },
            });
            if opts.max_count > 0 && out.len() >= opts.max_count {
                break;
            }
        }
    }
    out
}

fn print_prefix(name: &str, line: usize, col: usize, show_file: bool, show_nums: bool, opts: &Opts, sep: char) {
    if opts.color {
        if show_file {
            print!("\x1b[1;32m{}\x1b[0m\x1b[K{}", name, sep);
        }
        if show_nums {
            print!("\x1b[1;33m{}\x1b[0m\x1b[K{}", line, sep);
            if opts.column || opts.vimgrep {
                print!("{}{}", col, sep);
            }
        }
    } else {
        if show_file { print!("{}{}", name, sep); }
        if show_nums {
            print!("{}{}", line, sep);
            if opts.column || opts.vimgrep { print!("{}{}", col, sep); }
        }
    }
}

fn color_line(line: &str, spans: &[(usize, usize)]) -> String {
    let mut out = String::new();
    let mut last = 0;
    for (a, b) in spans {
        if *a >= last && *b <= line.len() {
            out.push_str(&line[last..*a]);
            out.push_str("\x1b[30;43m");
            out.push_str(&line[*a..*b]);
            out.push_str("\x1b[0m\x1b[K");
            last = *b;
        }
    }
    out.push_str(&line[last..]);
    out
}

fn truncate(s: &str, w: Option<usize>) -> String {
    if let Some(width) = w {
        s.chars().take(width).collect()
    } else {
        s.to_string()
    }
}

fn print_name(s: &str, null_sep: bool) {
    if null_sep {
        print!("{}\0", s);
    } else {
        println!("{}", s);
    }
}

fn display_path(path: &Path) -> String {
    let p = path.to_string_lossy().to_string();
    if let Some(rest) = p.strip_prefix("./") {
        rest.to_string()
    } else {
        p
    }
}

fn file_type_exts(name: &str) -> Option<&'static [&'static str]> {
    match name {
        "actionscript" => Some(&["as", "mxml"]),
        "ada" => Some(&["ada", "adb", "ads"]),
        "asciidoc" => Some(&["adoc", "ad", "asc", "asciidoc"]),
        "asm" => Some(&["asm", "s"]),
        "asp" | "aspx" => Some(&["asp", "asa", "aspx", "asax", "ashx", "ascx", "asmx"]),
        "batch" => Some(&["bat", "cmd"]),
        "cc" => Some(&["c", "h", "xs"]),
        "cpp" => Some(&["cpp", "cc", "C", "cxx", "m", "hpp", "hh", "h", "H", "hxx", "tpp"]),
        "css" => Some(&["css"]),
        "go" => Some(&["go"]),
        "html" => Some(&["htm", "html", "shtml", "xhtml"]),
        "java" => Some(&["java", "properties"]),
        "js" => Some(&["es6", "js", "jsx", "vue"]),
        "json" => Some(&["json"]),
        "markdown" | "md" => Some(&["markdown", "mdown", "mdwn", "mkdn", "mkd", "md"]),
        "perl" => Some(&["pl", "pm", "pm6", "pod", "t"]),
        "php" => Some(&["php", "phpt", "php3", "php4", "php5", "phtml"]),
        "python" => Some(&["py"]),
        "rs" | "rust" => Some(&["rs"]),
        "ruby" => Some(&["rb", "rhtml", "rjs", "rxml", "erb", "rake", "spec"]),
        "shell" => Some(&["sh", "bash", "csh", "tcsh", "ksh", "zsh", "fish"]),
        "toml" => Some(&["toml"]),
        "ts" => Some(&["ts", "tsx"]),
        "txt" => Some(&["txt"]),
        "xml" => Some(&["xml", "dtd", "xsl", "xslt", "xsd", "ent", "tld", "plist", "wsdl"]),
        "yaml" => Some(&["yaml", "yml"]),
        _ => None,
    }
}
