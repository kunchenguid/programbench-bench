use std::env;
use std::fs;
use std::io::{self, BufRead, BufReader, Read, Write};
use std::os::unix::process::ExitStatusExt;
use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::sync::Arc;
use std::thread;

#[derive(Clone, Copy, PartialEq)]
enum LabelType { Long, Short, None }

#[derive(Clone)]
struct Style {
    hide: bool,
    bold: bool,
    foreground: Option<String>,
}

impl Style {
    fn new(fg: Option<&str>, bold: bool, hide: bool) -> Self {
        Self { hide, bold, foreground: fg.map(|s| s.to_string()) }
    }
}

#[derive(Clone)]
struct Config {
    label_type: LabelType,
    build: Style,
    start: Style,
    pass: Style,
    fail: Style,
    skip: Style,
    file: Style,
    line: Style,
    pass_pkg: Style,
    fail_pkg: Style,
    covered: Style,
    uncovered: Style,
    cover_threshold: f64,
    removals: Vec<String>,
    leave_test_prefix: bool,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            label_type: LabelType::Long,
            build: Style::new(Some("yellow"), true, false),
            start: Style::new(Some("lightBlack"), false, false),
            pass: Style::new(Some("green"), false, false),
            fail: Style::new(Some("red"), true, false),
            skip: Style::new(Some("lightBlack"), false, false),
            file: Style::new(Some("cyan"), false, false),
            line: Style::new(Some("magenta"), false, false),
            pass_pkg: Style::new(Some("green"), false, true),
            fail_pkg: Style::new(Some("red"), true, true),
            covered: Style::new(Some("green"), false, false),
            uncovered: Style::new(Some("yellow"), true, false),
            cover_threshold: 50.0,
            removals: Vec::new(),
            leave_test_prefix: false,
        }
    }
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    let cfg = Arc::new(load_config());
    let color = force_color() || io::stdout().is_terminal();

    if args.first().map(|s| s.as_str()) == Some("testfilter") {
        let stdin = io::stdin();
        let mut out = io::stdout();
        filter_reader(stdin.lock(), &mut out, &cfg, color);
        return;
    }

    let status = run_go(args, cfg, color);
    std::process::exit(status);
}

trait IsTerminal { fn is_terminal(&self) -> bool; }
impl IsTerminal for io::Stdout {
    fn is_terminal(&self) -> bool { std::io::IsTerminal::is_terminal(self) }
}

fn run_go(args: Vec<String>, cfg: Arc<Config>, color: bool) -> i32 {
    let mut cmd = Command::new("go");
    cmd.args(&args).stdout(Stdio::piped()).stderr(Stdio::piped());
    let mut child = match cmd.spawn() {
        Ok(c) => c,
        Err(e) => {
            eprintln!("panic: exec: {:?}: {}", "go", e);
            eprintln!("\ngoroutine 1 [running]:\nmain.main()\n\t/workspace/main.go:74 +0x465");
            return 2;
        }
    };

    let stdout = child.stdout.take().unwrap();
    let stderr = child.stderr.take().unwrap();
    let cfg1 = cfg.clone();
    let cfg2 = cfg.clone();
    let t1 = thread::spawn(move || {
        let mut out = io::stdout();
        filter_reader(BufReader::new(stdout), &mut out, &cfg1, color);
    });
    let t2 = thread::spawn(move || {
        let mut err = io::stderr();
        filter_reader(BufReader::new(stderr), &mut err, &cfg2, color);
    });
    let status = child.wait().ok();
    let _ = t1.join();
    let _ = t2.join();
    match status {
        Some(s) => s.code().unwrap_or_else(|| 128 + s.signal().unwrap_or(0)),
        None => 1,
    }
}

fn force_color() -> bool {
    matches!(env::var("RICHGO_FORCE_COLOR"), Ok(v) if v == "1" || v.eq_ignore_ascii_case("true"))
}

fn load_config() -> Config {
    let mut cfg = Config::default();
    for path in config_paths() {
        if let Ok(text) = fs::read_to_string(&path) {
            parse_config(&text, &mut cfg);
            break;
        }
    }
    cfg
}

fn config_paths() -> Vec<PathBuf> {
    let names = [".richstyle", ".richstyle.yaml", ".richstyle.yml"];
    let mut dirs = Vec::new();
    if let Ok(cwd) = env::current_dir() { dirs.push(cwd); }
    if env::var("RICHGO_LOCAL").ok().as_deref() != Some("1") {
        for var in ["GOPATH", "GOROOT", "HOME"] {
            if let Ok(v) = env::var(var) { if !v.is_empty() { dirs.push(PathBuf::from(v)); } }
        }
    }
    let mut paths = Vec::new();
    for d in dirs { for n in names { paths.push(d.join(n)); } }
    paths
}

fn parse_config(text: &str, cfg: &mut Config) {
    let mut section = String::new();
    let mut in_removals = false;
    for raw in text.lines() {
        let no_comment = raw.split('#').next().unwrap_or("");
        if no_comment.trim().is_empty() { continue; }
        let indent = raw.chars().take_while(|c| c.is_whitespace()).count();
        let line = no_comment.trim();
        if in_removals && line.starts_with('-') {
            cfg.removals.push(unquote(line[1..].trim()).to_string());
            continue;
        }
        in_removals = false;
        if indent == 0 {
            section.clear();
            if let Some((k, v)) = line.split_once(':') {
                let key = k.trim();
                let val = unquote(v.trim());
                match key {
                    "labelType" => cfg.label_type = match val.to_ascii_lowercase().as_str() {
                        "short" => LabelType::Short,
                        "none" => LabelType::None,
                        _ => LabelType::Long,
                    },
                    "coverThreshold" => if let Ok(n) = val.parse() { cfg.cover_threshold = n; },
                    "leaveTestPrefix" => cfg.leave_test_prefix = parse_bool(val),
                    "removals" => in_removals = true,
                    k if k.ends_with("Style") => section = k.to_string(),
                    _ => {}
                }
            }
        } else if let Some((k, v)) = line.split_once(':') {
            let key = k.trim();
            let val = unquote(v.trim());
            if let Some(style) = style_mut(cfg, &section) {
                match key {
                    "hide" => style.hide = parse_bool(val),
                    "bold" => style.bold = parse_bool(val),
                    "foreground" => style.foreground = if val.is_empty() { None } else { Some(val.to_string()) },
                    _ => {}
                }
            }
        }
    }
}

fn unquote(s: &str) -> &str {
    let s = s.trim();
    if s.len() >= 2 && ((s.starts_with('"') && s.ends_with('"')) || (s.starts_with('\'') && s.ends_with('\''))) { &s[1..s.len()-1] } else { s }
}
fn parse_bool(s: &str) -> bool { matches!(s.to_ascii_lowercase().as_str(), "true" | "yes" | "1") }

fn style_mut<'a>(cfg: &'a mut Config, name: &str) -> Option<&'a mut Style> {
    match name {
        "buildStyle" => Some(&mut cfg.build),
        "startStyle" => Some(&mut cfg.start),
        "passStyle" => Some(&mut cfg.pass),
        "failStyle" => Some(&mut cfg.fail),
        "skipStyle" => Some(&mut cfg.skip),
        "fileStyle" => Some(&mut cfg.file),
        "lineStyle" => Some(&mut cfg.line),
        "passPackageStyle" => Some(&mut cfg.pass_pkg),
        "failPackageStyle" => Some(&mut cfg.fail_pkg),
        "coveredStyle" => Some(&mut cfg.covered),
        "uncoveredStyle" => Some(&mut cfg.uncovered),
        _ => None,
    }
}

fn filter_reader<R: Read, W: Write>(reader: R, out: &mut W, cfg: &Config, color: bool) {
    let mut state = State::default();
    let br = BufReader::new(reader);
    for res in br.lines() {
        let line = match res { Ok(l) => l, Err(_) => break };
        if !color { let _ = writeln!(out, "{}", line); continue; }
        if cfg.removals.iter().any(|r| !r.is_empty() && line.contains(r)) { continue; }
        if let Some(rendered) = transform_line(&line, cfg, &mut state, color) {
            let _ = writeln!(out, "{}", rendered);
        }
    }
}

#[derive(Default)]
struct State { failing: bool }

enum Kind { Start, Pass, Fail, Skip, PassPkg, FailPkg, Cover(bool) }

fn transform_line(line: &str, cfg: &Config, state: &mut State, color: bool) -> Option<String> {
    if let Some(name) = line.strip_prefix("=== RUN   ") {
        state.failing = false;
        return labeled(Kind::Start, clean_test_name(name, cfg), cfg, color);
    }
    if let Some(rest) = line.strip_prefix("--- PASS: ") {
        state.failing = false;
        return labeled(Kind::Pass, clean_result(rest, cfg), cfg, color);
    }
    if let Some(rest) = line.strip_prefix("--- FAIL: ") {
        state.failing = true;
        return labeled(Kind::Fail, clean_result(rest, cfg), cfg, color);
    }
    if let Some(rest) = line.strip_prefix("--- SKIP: ") {
        state.failing = false;
        return labeled(Kind::Skip, clean_result(rest, cfg), cfg, color);
    }
    if line == "PASS" { return if cfg.pass_pkg.hide { None } else { Some(apply_style("PASS", &cfg.pass_pkg, color)) }; }
    if line == "FAIL" { return if cfg.fail_pkg.hide { None } else { Some(apply_style("FAIL", &cfg.fail_pkg, color)) }; }
    if let Some(rest) = line.strip_prefix("ok  ").or_else(|| line.strip_prefix("ok\t")) {
        let text = package_text(rest);
        let mut c = cfg.clone(); c.pass_pkg.hide = false; return labeled(Kind::PassPkg, text, &c, color);
    }
    if let Some(rest) = line.strip_prefix("FAIL\t").or_else(|| line.strip_prefix("FAIL  ")) {
        let text = package_text(rest);
        let mut c = cfg.clone(); c.fail_pkg.hide = false; return labeled(Kind::FailPkg, text, &c, color);
    }
    if let Some(rest) = line.strip_prefix("coverage: ") {
        let pct = parse_percent(rest).unwrap_or(0.0);
        let bar = coverage_bar(pct);
        return labeled(Kind::Cover(pct >= cfg.cover_threshold), format!("{:.1}% {}", pct, bar), cfg, color);
    }
    if state.failing {
        return Some(format_failure_detail(line, cfg, color));
    }
    Some(line.to_string())
}

fn clean_test_name(s: &str, cfg: &Config) -> String {
    if cfg.leave_test_prefix { s.to_string() } else { strip_test_prefix_path(s).to_string() }
}
fn clean_result(s: &str, cfg: &Config) -> String {
    if cfg.leave_test_prefix { s.to_string() } else { strip_test_prefix_path(s).to_string() }
}
fn strip_test_prefix_path(s: &str) -> &str {
    if let Some(rest) = s.strip_prefix("Test") { rest } else { s }
}

fn package_text(rest: &str) -> String {
    let mut parts = rest.split_whitespace();
    let pkg = parts.next().unwrap_or(rest).to_string();
    let tail: Vec<&str> = parts.collect();
    if let Some(i) = tail.iter().position(|&p| p == "coverage:") {
        format!("{} {}", pkg, tail[i..].join(" "))
    } else {
        pkg
    }
}

fn parse_percent(s: &str) -> Option<f64> {
    let pct = s.split('%').next()?;
    pct.trim().parse().ok()
}
fn coverage_bar(pct: f64) -> String {
    let filled = ((pct / 10.0).floor() as usize).min(10);
    format!("[{}{}]", "#".repeat(filled), "_".repeat(10 - filled))
}

fn labeled(kind: Kind, text: String, cfg: &Config, color: bool) -> Option<String> {
    let (label_long, label_short, style) = match kind {
        Kind::Start => ("START", ">", &cfg.start),
        Kind::Pass => ("PASS ", "o", &cfg.pass),
        Kind::Fail => ("FAIL ", "x", &cfg.fail),
        Kind::Skip => ("SKIP ", "-", &cfg.skip),
        Kind::PassPkg => ("PASS ", "o", &cfg.pass_pkg),
        Kind::FailPkg => ("FAIL ", "x", &cfg.fail_pkg),
        Kind::Cover(true) => ("COVER", "%", &cfg.covered),
        Kind::Cover(false) => ("COVER", "%", &cfg.uncovered),
    };
    if style.hide { return None; }
    let body = match cfg.label_type {
        LabelType::Long => format!("{}| {}", label_long, text),
        LabelType::Short => format!("{}  {}", label_short, text),
        LabelType::None => text,
    };
    Some(apply_style(&body, style, color))
}

fn format_failure_detail(line: &str, cfg: &Config, color: bool) -> String {
    let mut text = line.to_string();
    if let Some((file_start, colon1, colon2)) = find_file_line(&text) {
        if color {
            let prefix = &text[..file_start];
            let file = &text[file_start..colon1];
            let num = &text[colon1..colon2];
            let rest = &text[colon2..];
            text = format!("{}{}{}{}{}{}", prefix, apply_style(file, &cfg.file, true), apply_style(num, &cfg.line, true), ansi_for(&cfg.fail), rest, "\x1b[0m");
        }
    }
    match cfg.label_type {
        LabelType::Long | LabelType::Short => apply_style(&format!("     | {}", text), &cfg.fail, color),
        LabelType::None => apply_style(&text, &cfg.fail, color),
    }
}

fn find_file_line(s: &str) -> Option<(usize, usize, usize)> {
    let bytes = s.as_bytes();
    for i in 0..s.len().saturating_sub(4) {
        if s[i..].starts_with(".go:") {
            let file_start = s[..i].rfind(char::is_whitespace).map(|p| p + 1).unwrap_or(0);
            let colon1 = i + 3;
            let mut j = colon1 + 1;
            while j < bytes.len() && bytes[j].is_ascii_digit() { j += 1; }
            if j > colon1 + 1 && j < bytes.len() && bytes[j] == b':' { return Some((file_start, colon1, j)); }
        }
    }
    None
}

fn apply_style(s: &str, style: &Style, color: bool) -> String {
    if !color { return s.to_string(); }
    format!("{}{}\x1b[0m", ansi_for(style), s)
}

fn ansi_for(style: &Style) -> String {
    let mut out = String::new();
    if let Some(fg) = &style.foreground { out.push_str(color_code(fg)); }
    if style.bold { out.push_str("\x1b[1m"); }
    out
}

fn color_code(name: &str) -> &'static str {
    match name.trim().to_ascii_lowercase().as_str() {
        "black" => "\x1b[30m",
        "red" => "\x1b[31m",
        "green" => "\x1b[32m",
        "yellow" => "\x1b[33m",
        "blue" => "\x1b[34m",
        "magenta" => "\x1b[35m",
        "cyan" => "\x1b[36m",
        "white" => "\x1b[37m",
        "lightblack" | "brightblack" | "gray" | "grey" => "\x1b[90m",
        "lightred" => "\x1b[91m",
        "lightgreen" => "\x1b[92m",
        "lightyellow" => "\x1b[93m",
        "lightblue" => "\x1b[94m",
        "lightmagenta" => "\x1b[95m",
        "lightcyan" => "\x1b[96m",
        "lightwhite" => "\x1b[97m",
        _ => "",
    }
}
