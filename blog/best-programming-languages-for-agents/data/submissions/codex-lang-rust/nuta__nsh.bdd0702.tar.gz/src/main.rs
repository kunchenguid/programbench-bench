use std::env;
use std::fs;
use std::io::Write;
use std::os::unix::process::ExitStatusExt;
use std::process::{Command, Stdio};

const HELP: &str = "nsh 0.4.2
A command-line shell that focuses on performance and productivity.

USAGE:
    executable [FLAGS] [OPTIONS] [FILE]

FLAGS:
    -h, --help       Prints help information
    -l, --login      Behave like a login shell
        --norc       Don't load nshrc
        --version    Print the version

OPTIONS:
    -c <command>        The command to be executed

ARGS:
    <FILE>    The file to be executed
";

fn main() {
    let code = match run_main() {
        Ok(code) => code,
        Err(code) => code,
    };
    std::process::exit(code);
}

#[derive(Default)]
struct Opts {
    command: Option<String>,
    file: Option<String>,
    norc: bool,
    login: bool,
}

fn run_main() -> Result<i32, i32> {
    let mut opts = Opts::default();
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                print!("{}", HELP);
                return Ok(0);
            }
            "--version" => {
                println!("0.4.2");
                return Ok(0);
            }
            "--norc" => opts.norc = true,
            "-l" | "--login" => opts.login = true,
            "-c" => match args.next() {
                Some(cmd) => {
                    opts.command = Some(cmd);
                    // clap in the original accepts a trailing positional after -c; it is
                    // not visible to simple command execution, so ignore remaining args.
                    break;
                }
                None => {
                    eprintln!("error: The argument '-c <command>' requires a value but none was supplied\n");
                    eprintln!("USAGE:\n    executable -c <command>\n");
                    eprintln!("For more information try --help");
                    return Err(1);
                }
            },
            s if s.starts_with('-') => {
                eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context\n", s);
                eprintln!("USAGE:\n    executable [FLAGS] [OPTIONS] [FILE]\n");
                eprintln!("For more information try --help");
                return Err(1);
            }
            other => {
                opts.file = Some(other.to_string());
                break;
            }
        }
    }

    if let Some(ref cmd) = opts.command {
        return Ok(run_script(&cmd, &opts));
    }
    if let Some(ref file) = opts.file {
        match fs::read_to_string(&file) {
            Ok(script) => return Ok(run_script(&script, &opts)),
            Err(e) => {
                eprintln!("nsh: panicked at src/main.rs:114:34:");
                eprintln!("failed to open the file: {:?}", e);
                eprintln!("nsh: Something went wrong. Check out ~/.nsh.log and please file this bug on GitHub: https://github.com/nuta/nsh/issues");
                return Ok(101);
            }
        }
    }

    interactive(&opts)
}

fn run_script(input: &str, opts: &Opts) -> i32 {
    let script = build_bash_script(input, opts);
    run_bash(&script, opts.login)
}

fn build_bash_script(input: &str, opts: &Opts) -> String {
    let mut out = String::new();
    out.push_str("command_not_found_handle() { printf 'nsh: command not found `%'\\''s'\\''\\n' \"$1\" >&2; return 1; }\n");
    out.push_str("shopt -s expand_aliases 2>/dev/null || true\n");
    out.push_str("enable -n history 2>/dev/null || true\n");
    if !opts.norc {
        out.push_str(&rc_loader());
    }
    let transformed = transform_script(input);
    out.push_str(&transformed);
    out
}

fn rc_loader() -> String {
    let mut s = String::new();
    s.push_str("if [ -n \"$XDG_CONFIG_HOME\" ] && [ -r \"$XDG_CONFIG_HOME/nsh/nshrc\" ]; then . \"$XDG_CONFIG_HOME/nsh/nshrc\"; ");
    s.push_str("elif [ -r \"$HOME/.nshrc\" ]; then . \"$HOME/.nshrc\"; fi\n");
    s
}

fn run_bash(script: &str, login: bool) -> i32 {
    let mut cmd = Command::new("/bin/bash");
    if login {
        cmd.arg("-l");
    }
    let status = cmd.arg("-c").arg(script).status();
    match status {
        Ok(st) => st.code().unwrap_or_else(|| 128 + st.signal().unwrap_or(0)),
        Err(e) => {
            eprintln!("nsh: failed to execute bash: {}", e);
            1
        }
    }
}

fn interactive(opts: &Opts) -> Result<i32, i32> {
    let prelude = build_bash_script("", opts);
    let mut child = Command::new("/bin/bash")
        .arg(if opts.login { "-l" } else { "-i" })
        .stdin(Stdio::piped())
        .spawn()
        .map_err(|e| {
            eprintln!("nsh: failed to start interactive shell: {}", e);
            1
        })?;
    if let Some(mut stdin) = child.stdin.take() {
        let _ = stdin.write_all(prelude.as_bytes());
    }
    let status = child.wait().map_err(|_| 1)?;
    Ok(status.code().unwrap_or(0))
}

fn transform_script(input: &str) -> String {
    let first = replace_or_operators(input);
    rewrite_aliases(&first)
}

fn replace_or_operators(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let mut chars = input.chars().peekable();
    let mut single = false;
    let mut double = false;
    let mut escaped = false;
    while let Some(c) = chars.next() {
        if escaped {
            out.push(c);
            escaped = false;
            continue;
        }
        if c == '\\' && !single {
            out.push(c);
            escaped = true;
            continue;
        }
        match c {
            '\'' if !double => {
                single = !single;
                out.push(c);
            }
            '"' if !single => {
                double = !double;
                out.push(c);
            }
            '|' if !single && !double && chars.peek() == Some(&'|') => {
                chars.next();
                out.push(';');
            }
            _ => out.push(c),
        }
    }
    out
}

fn rewrite_aliases(input: &str) -> String {
    let mut parts = split_top_level(input);
    let mut out = String::new();
    for part in parts.drain(..) {
        let trimmed = part.trim();
        if let Some((name, value)) = parse_alias(trimmed) {
            out.push_str(&format!("{}() {{ {} \"$@\"; }}", name, value));
            out.push(';');
        } else {
            out.push_str(&part);
            out.push(';');
        }
    }
    if out.ends_with(';') {
        out.pop();
    }
    out
}

fn split_top_level(input: &str) -> Vec<String> {
    let mut parts = Vec::new();
    let mut buf = String::new();
    let mut single = false;
    let mut double = false;
    let mut escaped = false;
    for c in input.chars() {
        if escaped {
            buf.push(c);
            escaped = false;
            continue;
        }
        if c == '\\' && !single {
            buf.push(c);
            escaped = true;
            continue;
        }
        match c {
            '\'' if !double => {
                single = !single;
                buf.push(c);
            }
            '"' if !single => {
                double = !double;
                buf.push(c);
            }
            ';' | '\n' if !single && !double => {
                parts.push(buf.clone());
                buf.clear();
            }
            _ => buf.push(c),
        }
    }
    if !buf.is_empty() {
        parts.push(buf);
    }
    parts
}

fn parse_alias(s: &str) -> Option<(String, String)> {
    let rest = s.strip_prefix("alias ")?.trim();
    let eq = rest.find('=')?;
    let name = rest[..eq].trim();
    if !is_ident(name) {
        return None;
    }
    let value = unquote(rest[eq + 1..].trim())?;
    Some((name.to_string(), value))
}

fn is_ident(s: &str) -> bool {
    let mut chars = s.chars();
    match chars.next() {
        Some(c) if c == '_' || c.is_ascii_alphabetic() => {}
        _ => return false,
    }
    chars.all(|c| c == '_' || c.is_ascii_alphanumeric())
}

fn unquote(s: &str) -> Option<String> {
    if (s.starts_with('\'') && s.ends_with('\'')) || (s.starts_with('"') && s.ends_with('"')) {
        Some(s[1..s.len() - 1].to_string())
    } else if !s.is_empty() {
        Some(s.to_string())
    } else {
        None
    }
}
