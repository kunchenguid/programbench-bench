use std::collections::HashSet;
use std::fs;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

#[derive(Clone, Copy, Debug)]
enum Shell {
    Bash,
    Elvish,
    Fish,
    Powershell,
    Zsh,
}

#[derive(Debug, Default)]
struct Cli {
    check: bool,
    print_out: bool,
    fail_on_change: bool,
    nowrap: bool,
    wraplen: usize,
    tabsize: usize,
    usetabs: bool,
    stdin: bool,
    config: Option<PathBuf>,
    noconfig: bool,
    verbose: bool,
    quiet: bool,
    trace: bool,
    completion: Option<Shell>,
    man: bool,
    args: bool,
    recursive: bool,
    files: Vec<PathBuf>,
}

#[derive(Clone, Debug)]
struct Config {
    check: bool,
    print_out: bool,
    fail_on_change: bool,
    wrap: bool,
    wraplen: usize,
    wrapmin: usize,
    tabsize: usize,
    tabchar: TabChar,
    stdin: bool,
    verbosity: String,
    lists: Vec<String>,
    verbatims: Vec<String>,
    no_indent_envs: Vec<String>,
    wrap_chars: Vec<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
enum TabChar {
    Space,
    Tab,
}

fn main() {
    let cli = parse_cli();
    let mut cfg = load_config(&cli);
    apply_cli(&mut cfg, &cli);

    if cli.man {
        print_man();
        return;
    }
    if let Some(shell) = cli.completion {
        print_completion(shell);
        return;
    }
    if cli.args {
        print_args(&cfg, &cli.files);
        return;
    }

    let code = match run(&cfg, &cli) {
        Ok(changed) => {
            if (cfg.check || cfg.fail_on_change) && changed {
                1
            } else {
                0
            }
        }
        Err(()) => 1,
    };
    std::process::exit(code);
}

fn parse_cli() -> Cli {
    let mut cli = Cli { wraplen: 80, tabsize: 2, ..Cli::default() };
    let mut args = std::env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-c" | "--check" => cli.check = true,
            "-p" | "--print" => cli.print_out = true,
            "-f" | "--fail-on-change" => cli.fail_on_change = true,
            "-n" | "--nowrap" => cli.nowrap = true,
            "--usetabs" => cli.usetabs = true,
            "-s" | "--stdin" => cli.stdin = true,
            "--noconfig" => cli.noconfig = true,
            "-v" | "--verbose" => cli.verbose = true,
            "-q" | "--quiet" => cli.quiet = true,
            "--trace" => cli.trace = true,
            "--man" => cli.man = true,
            "--args" => cli.args = true,
            "-r" | "--recursive" => cli.recursive = true,
            "-h" | "--help" => {
                print_help();
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("tex-fmt 0.5.6");
                std::process::exit(0);
            }
            "-l" | "--wraplen" => {
                cli.wraplen = next_usize(&mut args, &arg);
            }
            "-t" | "--tabsize" => {
                cli.tabsize = next_usize(&mut args, &arg);
            }
            "--config" => {
                cli.config = Some(PathBuf::from(args.next().unwrap_or_else(|| missing_value(&arg))));
            }
            "--completion" => {
                let s = args.next().unwrap_or_else(|| missing_value(&arg));
                cli.completion = Some(match s.as_str() {
                    "bash" => Shell::Bash,
                    "elvish" => Shell::Elvish,
                    "fish" => Shell::Fish,
                    "powershell" => Shell::Powershell,
                    "zsh" => Shell::Zsh,
                    _ => {
                        eprintln!("error: invalid value '{s}' for '--completion <SHELL>'");
                        std::process::exit(2);
                    }
                });
            }
            _ if arg.starts_with("--wraplen=") => {
                cli.wraplen = arg["--wraplen=".len()..].parse().unwrap_or(80);
            }
            _ if arg.starts_with("--tabsize=") => {
                cli.tabsize = arg["--tabsize=".len()..].parse().unwrap_or(2);
            }
            _ if arg.starts_with("--config=") => {
                cli.config = Some(PathBuf::from(&arg["--config=".len()..]));
            }
            _ if arg.starts_with("--completion=") => {
                let s = &arg["--completion=".len()..];
                cli.completion = Some(match s {
                    "bash" => Shell::Bash,
                    "elvish" => Shell::Elvish,
                    "fish" => Shell::Fish,
                    "powershell" => Shell::Powershell,
                    "zsh" => Shell::Zsh,
                    _ => {
                        eprintln!("error: invalid value '{s}' for '--completion <SHELL>'");
                        std::process::exit(2);
                    }
                });
            }
            _ if arg.starts_with('-') && arg.len() > 2 => {
                for ch in arg[1..].chars() {
                    match ch {
                        'c' => cli.check = true,
                        'p' => cli.print_out = true,
                        'f' => cli.fail_on_change = true,
                        'n' => cli.nowrap = true,
                        's' => cli.stdin = true,
                        'v' => cli.verbose = true,
                        'q' => cli.quiet = true,
                        'r' => cli.recursive = true,
                        'h' => { print_help(); std::process::exit(0); }
                        'V' => { println!("tex-fmt 0.5.6"); std::process::exit(0); }
                        _ => {
                            eprintln!("error: unexpected argument '-{ch}'");
                            std::process::exit(2);
                        }
                    }
                }
            }
            _ => cli.files.push(PathBuf::from(arg)),
        }
    }
    cli
}

fn next_usize<I: Iterator<Item = String>>(args: &mut std::iter::Peekable<I>, flag: &str) -> usize {
    args.next()
        .unwrap_or_else(|| missing_value(flag))
        .parse()
        .unwrap_or_else(|_| {
            eprintln!("error: invalid value for '{flag}'");
            std::process::exit(2);
        })
}

fn missing_value(flag: &str) -> String {
    eprintln!("error: a value is required for '{flag}'");
    std::process::exit(2);
}

fn print_help() {
    println!("tex-fmt 0.5.6\n");
    println!("LaTeX formatter written in Rust\n");
    println!("Usage: executable [OPTIONS] [files]...\n");
    println!("Arguments:");
    println!("  [files]...  List of files to be formatted\n");
    println!("Options:");
    println!("  -c, --check               Check formatting, do not modify files");
    println!("  -p, --print               Print to stdout, do not modify files");
    println!("  -f, --fail-on-change      Format files and return non-zero exit code if files are modified");
    println!("  -n, --nowrap              Do not wrap long lines");
    println!("  -l, --wraplen <N>         Line length for wrapping [default: 80]");
    println!("  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]");
    println!("      --usetabs             Use tabs instead of spaces for indentation");
    println!("  -s, --stdin               Process stdin as a single file, output to stdout");
    println!("      --config <PATH>       Path to config file");
    println!("      --noconfig            Do not read any config file");
    println!("  -v, --verbose             Show info messages");
    println!("  -q, --quiet               Hide warning messages");
    println!("      --trace               Show trace messages");
    println!("      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]");
    println!("      --man                 Generate man page");
    println!("      --args                Print arguments passed to tex-fmt and exit");
    println!("  -r, --recursive           Recursively search for files to format");
    println!("  -h, --help                Print help");
    println!("  -V, --version             Print version");
}

fn default_config() -> Config {
    Config {
        check: false,
        print_out: false,
        fail_on_change: false,
        wrap: true,
        wraplen: 80,
        wrapmin: 70,
        tabsize: 2,
        tabchar: TabChar::Space,
        stdin: false,
        verbosity: "warn".into(),
        lists: vec![
            "itemize".into(),
            "enumerate".into(),
            "description".into(),
            "inlineroman".into(),
            "inventory".into(),
        ],
        verbatims: vec![
            "verbatim".into(),
            "Verbatim".into(),
            "lstlisting".into(),
            "minted".into(),
            "comment".into(),
        ],
        no_indent_envs: vec!["document".into()],
        wrap_chars: Vec::new(),
    }
}

fn load_config(cli: &Cli) -> Config {
    let mut cfg = default_config();
    if cli.noconfig {
        return cfg;
    }
    let path = if let Some(p) = &cli.config {
        Some(p.clone())
    } else {
        find_config()
    };
    if let Some(path) = path {
        if let Ok(text) = fs::read_to_string(path) {
            if let Ok(value) = text.parse::<toml::Value>() {
                merge_toml(&mut cfg, &value);
            }
        }
    }
    cfg
}

fn find_config() -> Option<PathBuf> {
    let cwd = std::env::current_dir().ok()?;
    let local = cwd.join("tex-fmt.toml");
    if local.exists() {
        return Some(local);
    }
    for ancestor in cwd.ancestors() {
        if ancestor.join(".git").exists() {
            let p = ancestor.join("tex-fmt.toml");
            if p.exists() {
                return Some(p);
            }
            break;
        }
    }
    if let Ok(home) = std::env::var("HOME") {
        let p = Path::new(&home).join(".config/tex-fmt/tex-fmt.toml");
        if p.exists() {
            return Some(p);
        }
    }
    None
}

fn merge_toml(cfg: &mut Config, v: &toml::Value) {
    let Some(t) = v.as_table() else { return; };
    if let Some(x) = t.get("check").and_then(|x| x.as_bool()) { cfg.check = x; }
    if let Some(x) = t.get("print").and_then(|x| x.as_bool()) { cfg.print_out = x; }
    if let Some(x) = t.get("fail-on-change").and_then(|x| x.as_bool()) { cfg.fail_on_change = x; }
    if let Some(x) = t.get("wrap").and_then(|x| x.as_bool()) { cfg.wrap = x; }
    if let Some(x) = t.get("wraplen").and_then(|x| x.as_integer()) { cfg.wraplen = x.max(1) as usize; }
    if let Some(x) = t.get("wrapmin").and_then(|x| x.as_integer()) { cfg.wrapmin = x.max(1) as usize; }
    if let Some(x) = t.get("tabsize").and_then(|x| x.as_integer()) { cfg.tabsize = x.max(0) as usize; }
    if let Some(x) = t.get("stdin").and_then(|x| x.as_bool()) { cfg.stdin = x; }
    if let Some(x) = t.get("verbosity").and_then(|x| x.as_str()) { cfg.verbosity = x.into(); }
    if let Some(x) = t.get("tabchar").and_then(|x| x.as_str()) {
        cfg.tabchar = if x == "tab" { TabChar::Tab } else { TabChar::Space };
    }
    append_array(t.get("lists"), &mut cfg.lists);
    append_array(t.get("verbatims"), &mut cfg.verbatims);
    append_array(t.get("no-indent-envs"), &mut cfg.no_indent_envs);
    append_array(t.get("wrap-chars"), &mut cfg.wrap_chars);
}

fn append_array(v: Option<&toml::Value>, dst: &mut Vec<String>) {
    if let Some(arr) = v.and_then(|x| x.as_array()) {
        for x in arr {
            if let Some(s) = x.as_str() {
                if !dst.iter().any(|e| e == s) {
                    dst.push(s.to_string());
                }
            }
        }
    }
}

fn apply_cli(cfg: &mut Config, cli: &Cli) {
    if cli.check { cfg.check = true; }
    if cli.print_out { cfg.print_out = true; }
    if cli.fail_on_change { cfg.fail_on_change = true; }
    if cli.nowrap { cfg.wrap = false; }
    if cli.wraplen != 80 { cfg.wraplen = cli.wraplen; cfg.wrapmin = cli.wraplen.saturating_sub(10); }
    if cli.tabsize != 2 { cfg.tabsize = cli.tabsize; }
    if cli.usetabs { cfg.tabchar = TabChar::Tab; }
    if cli.stdin { cfg.stdin = true; }
    if cli.trace { cfg.verbosity = "trace".into(); }
    else if cli.verbose { cfg.verbosity = "info".into(); }
    else if cli.quiet { cfg.verbosity = "error".into(); }
}

fn run(cfg: &Config, cli: &Cli) -> Result<bool, ()> {
    if cfg.stdin {
        let mut input = String::new();
        io::stdin().read_to_string(&mut input).map_err(|_| ())?;
        let output = format_tex(&input, cfg);
        print!("{output}");
        return Ok(input != output);
    }

    let files = gather_files(&cli.files, cli.recursive);
    let mut any_changed = false;
    for path in files {
        let input = match fs::read_to_string(&path) {
            Ok(s) => s,
            Err(_) => {
                if cfg.verbosity != "error" {
                    eprintln!("ERROR: tex-fmt {}: Could not open file. ", path.display());
                }
                return Err(());
            }
        };
        let output = format_tex(&input, cfg);
        let changed = input != output;
        any_changed |= changed;
        if cfg.check {
            if changed && cfg.verbosity != "error" {
                eprintln!("ERROR: tex-fmt {}: Incorrect formatting. ", path.display());
            }
        } else if cfg.print_out {
            print!("{output}");
        } else {
            if let Err(_) = fs::write(&path, output) {
                if cfg.verbosity != "error" {
                    eprintln!("ERROR: tex-fmt {}: Could not write file. ", path.display());
                }
                return Err(());
            }
        }
    }
    Ok(any_changed)
}

fn gather_files(files: &[PathBuf], recursive: bool) -> Vec<PathBuf> {
    let roots: Vec<PathBuf> = if files.is_empty() { vec![PathBuf::from(".")] } else { files.to_vec() };
    if !recursive {
        return roots;
    }
    let mut out = Vec::new();
    for root in roots {
        if root.is_file() {
            if is_tex_file(&root) { out.push(root); }
        } else if root.is_dir() {
            walk(&root, &mut out);
        }
    }
    out.sort();
    out
}

fn walk(dir: &Path, out: &mut Vec<PathBuf>) {
    let Ok(rd) = fs::read_dir(dir) else { return; };
    for ent in rd.flatten() {
        let p = ent.path();
        let name = ent.file_name();
        if name.to_string_lossy().starts_with(".git") || name == "target" {
            continue;
        }
        if p.is_dir() {
            walk(&p, out);
        } else if is_tex_file(&p) {
            out.push(p);
        }
    }
}

fn is_tex_file(p: &Path) -> bool {
    matches!(p.extension().and_then(|s| s.to_str()), Some("tex" | "bib" | "cls" | "sty"))
}

fn format_tex(input: &str, cfg: &Config) -> String {
    let list_envs: HashSet<&str> = cfg.lists.iter().map(String::as_str).collect();
    let verb_envs: HashSet<&str> = cfg.verbatims.iter().map(String::as_str).collect();
    let no_indent: HashSet<&str> = cfg.no_indent_envs.iter().map(String::as_str).collect();
    let mut out: Vec<String> = Vec::new();
    let mut indent = 0usize;
    let mut item_depth = 0usize;
    let mut verbatim: Option<String> = None;
    let mut fmt_off = false;
    let had_final_newline = input.ends_with('\n');

    for raw in input.lines() {
        let line = raw.trim_end_matches('\r');
        let trimmed = line.trim_start();

        if fmt_off {
            out.push(line.to_string());
            if trimmed.contains("tex-fmt: on") {
                fmt_off = false;
            }
            continue;
        }
        if trimmed.contains("tex-fmt: off") {
            out.push(line.to_string());
            fmt_off = true;
            continue;
        }
        if trimmed.contains("tex-fmt: skip") {
            out.push(line.to_string());
            continue;
        }
        if let Some(env) = verbatim.clone() {
            out.push(line.to_string());
            if end_env(trimmed).as_deref() == Some(env.as_str()) {
                verbatim = None;
            }
            continue;
        }

        if trimmed.is_empty() {
            out.push(String::new());
            continue;
        }

        let math_end = trimmed == "\\]";
        let end = end_env(trimmed);
        if math_end {
            indent = indent.saturating_sub(1);
        }
        if let Some(env) = end.as_deref() {
            if !no_indent.contains(env) {
                indent = indent.saturating_sub(1);
            }
            if list_envs.contains(env) {
                item_depth = item_depth.saturating_sub(1);
            }
        }

        let mut line_indent = indent;
        let is_item = starts_item(trimmed);
        if is_item {
            line_indent = indent;
        } else if item_depth > 0 && end.is_none() {
            line_indent += 1;
        }

        let prefix = make_indent(line_indent, cfg);
        let formatted_line = format!("{prefix}{trimmed}");
        if cfg.wrap && should_wrap(trimmed) {
            out.extend(wrap_line(&formatted_line, line_indent, is_item, cfg));
        } else {
            out.push(formatted_line);
        }

        if trimmed == "\\[" {
            indent += 1;
        } else if let Some(env) = begin_env(trimmed) {
            if verb_envs.contains(env.as_str()) {
                verbatim = Some(env);
            } else {
                if list_envs.contains(env.as_str()) {
                    item_depth += 1;
                }
                if !no_indent.contains(env.as_str()) {
                    indent += 1;
                }
            }
        }
    }

    let mut s = out.join("\n");
    if had_final_newline {
        s.push('\n');
    }
    s
}

fn begin_env(s: &str) -> Option<String> {
    parse_env_command(s, "\\begin{")
}

fn end_env(s: &str) -> Option<String> {
    parse_env_command(s, "\\end{")
}

fn parse_env_command(s: &str, prefix: &str) -> Option<String> {
    if !s.starts_with(prefix) {
        return None;
    }
    let rest = &s[prefix.len()..];
    let end = rest.find('}')?;
    Some(rest[..end].to_string())
}

fn starts_item(s: &str) -> bool {
    s == "\\item" || s.starts_with("\\item ") || s.starts_with("\\item[")
}

fn make_indent(level: usize, cfg: &Config) -> String {
    match cfg.tabchar {
        TabChar::Space => " ".repeat(level * cfg.tabsize),
        TabChar::Tab => "\t".repeat(level * cfg.tabsize),
    }
}

fn visual_len(s: &str) -> usize {
    s.chars().count()
}

fn should_wrap(s: &str) -> bool {
    !(s.starts_with('\\') && !starts_item(s)) && !s.starts_with('%')
}

fn wrap_line(line: &str, level: usize, is_item: bool, cfg: &Config) -> Vec<String> {
    if visual_len(line) <= cfg.wraplen {
        return vec![line.to_string()];
    }
    let words: Vec<&str> = line.split_whitespace().collect();
    if words.len() <= 1 {
        return vec![line.to_string()];
    }
    let first_prefix = make_indent(level, cfg);
    let cont_prefix = if is_item {
        make_indent(level + 1, cfg)
    } else {
        first_prefix.clone()
    };
    let content = line.trim_start();
    let words: Vec<&str> = content.split_whitespace().collect();
    let mut out = Vec::new();
    let mut current = first_prefix.clone();
    let mut prefix_len = visual_len(&first_prefix);
    let mut first_word = true;
    let mut first_line = true;
    for word in words {
        let add = if first_word { word.len() } else { word.len() + 1 };
        if !first_word && visual_len(&current) + add >= cfg.wraplen && visual_len(&current) >= cfg.wrapmin.min(cfg.wraplen) {
            out.push(current);
            current = cont_prefix.clone();
            prefix_len = visual_len(&cont_prefix);
            first_word = true;
            first_line = false;
        }
        if !first_word {
            current.push(' ');
        }
        if first_word && visual_len(&current) == prefix_len && !first_line && word.is_empty() {
            continue;
        }
        current.push_str(word);
        first_word = false;
    }
    if !current.trim().is_empty() {
        out.push(current);
    }
    out
}

fn print_args(cfg: &Config, files: &[PathBuf]) {
    println!("tex-fmt");
    println!("  check:                   {}", cfg.check);
    println!("  print:                   {}", cfg.print_out);
    println!("  fail-on-change:          {}", cfg.fail_on_change);
    println!("  wrap:                    {}", cfg.wrap);
    println!("  wraplen:                 {}", cfg.wraplen);
    println!("  wrapmin:                 {}", cfg.wrapmin);
    println!("  tabsize:                 {}", cfg.tabsize);
    println!("  tabchar:                 {}", if cfg.tabchar == TabChar::Tab { "tab" } else { "space" });
    println!("  stdin:                   {}", cfg.stdin);
    println!("  config:                  None");
    println!("  verbosity:               {}", cfg.verbosity);
    print_list("lists", &cfg.lists);
    print_list("verbatims", &cfg.verbatims);
    print_list("no-indent-envs", &cfg.no_indent_envs);
    print_list("wrap-chars", &cfg.wrap_chars);
    if files.is_empty() {
        println!("  files:                   ");
    } else {
        print!("  files:                   {}", files[0].display());
        println!();
        for f in &files[1..] {
            println!("                           {}", f.display());
        }
    }
}

fn print_list(name: &str, items: &[String]) {
    let label = format!("  {name}:");
    if items.is_empty() {
        println!("{label:<27}");
    } else {
        println!("{label:<27}{}", items[0]);
        for item in &items[1..] {
            println!("                           {item}");
        }
    }
}

fn print_man() {
    println!(".TH tex-fmt 1  \"tex-fmt 0.5.6\"");
    println!(".SH NAME");
    println!("tex\\-fmt \\- LaTeX formatter written in Rust");
    println!(".SH SYNOPSIS");
    println!("tex\\-fmt [OPTIONS] [files]");
    println!(".SH VERSION");
    println!("v0.5.6");
}

fn print_completion(shell: Shell) {
    match shell {
        Shell::Bash => println!("_tex-fmt() {{ :; }}\ncomplete -F _tex-fmt tex-fmt"),
        Shell::Fish => println!("complete -c tex-fmt"),
        Shell::Zsh => println!("#compdef tex-fmt\n_arguments '*:files:_files'"),
        Shell::Elvish => println!("set edit:completion:arg-completer[tex-fmt] = {{ }}"),
        Shell::Powershell => println!("Register-ArgumentCompleter -Native -CommandName tex-fmt -ScriptBlock {{}}"),
    }
    let _ = io::stdout().flush();
}
