use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "tree-sitter 0.27.0";

fn main() {
    let mut args: Vec<String> = env::args().collect();
    let prog = args.get(0).cloned().unwrap_or_else(|| "executable".to_string());
    if Path::new(&prog)
        .file_name()
        .and_then(|s| s.to_str())
        .unwrap_or("")
        != "executable"
    {
        args[0] = "executable".to_string();
    }

    let code = run(&args);
    process::exit(code);
}

fn run(args: &[String]) -> i32 {
    if args.len() == 1 {
        print!("{}", top_help());
        return 2;
    }

    match args[1].as_str() {
        "-h" | "--help" => {
            print!("{}", top_help());
            0
        }
        "-V" | "--version" => {
            println!("{}", VERSION);
            0
        }
        "init-config" => command_init_config(&args[2..]),
        "init" => command_init(&args[2..]),
        "generate" => command_generate(&args[2..]),
        "build" => command_build(&args[2..]),
        "parse" => command_parse(&args[2..]),
        "test" => command_test(&args[2..]),
        "version" => command_version(&args[2..]),
        "fuzz" => command_fuzz(&args[2..]),
        "query" => command_query(&args[2..]),
        "highlight" => command_highlight(&args[2..]),
        "tags" => command_tags(&args[2..]),
        "playground" => command_playground(&args[2..]),
        "dump-languages" => command_dump_languages(&args[2..]),
        "complete" => command_complete(&args[2..]),
        other => {
            if other == "nope" {
                eprintln!("error: unrecognized subcommand 'nope'\n\n  tip: a similar subcommand exists: 'complete'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.");
            } else {
                eprintln!("error: unrecognized subcommand '{}'\n\nUsage: executable <COMMAND>\n\nFor more information, try '--help'.", other);
            }
            2
        }
    }
}

fn has_help(args: &[String]) -> bool {
    args.iter().any(|a| a == "-h" || a == "--help")
}

fn command_init_config(args: &[String]) -> i32 {
    if has_help(args) {
        print!("Generate a default config file\n\nUsage: executable init-config\n\nOptions:\n  -h, --help  Print help\n");
        return 0;
    }
    let home = env::var("HOME").unwrap_or_else(|_| ".".to_string());
    let path = Path::new(&home).join(".config/tree-sitter/config.json");
    if let Some(parent) = path.parent() {
        if let Err(e) = fs::create_dir_all(parent) {
            print_error(&format!("{}", e));
            return 1;
        }
    }
    let content = default_config(&home);
    if let Err(e) = fs::write(&path, content) {
        print_error(&format!("{}", e));
        return 1;
    }
    println!("Saved initial configuration to {}", path.display());
    0
}

fn command_init(args: &[String]) -> i32 {
    if has_help(args) {
        print!("Initialize a grammar repository\n\nUsage: executable init [OPTIONS]\n\nOptions:\n  -u, --update                       Update outdated files\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory\n  -h, --help                         Print help\n");
        return 0;
    }
    print_error("IO error: not a terminal");
    1
}

fn command_generate(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", GENERATE_HELP);
        return 0;
    }
    let grammar = positional(args).unwrap_or_else(|| "grammar.js".to_string());
    let cwd = env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
    let path = if grammar == "grammar.js" {
        cwd.join("grammar.js")
    } else {
        PathBuf::from(grammar)
    };
    if !path.exists() {
        eprintln!("\x1b[31mError:\x1b[0m Error when generating parser\n\nCaused by:\n    Failed to load grammar.js -- No such file or directory (os error 2) ({})", path.display());
        return 1;
    }
    print_error("Error when generating parser");
    1
}

fn command_build(args: &[String]) -> i32 {
    if has_help(args) {
        print!("Compile a parser\n\nUsage: executable build [OPTIONS] [PATH]\n\nArguments:\n  [PATH]  The path to the grammar directory\n\nOptions:\n  -w, --wasm             Build a Wasm module instead of a dynamic library\n  -o, --output <OUTPUT>  The path to output the compiled file\n      --reuse-allocator  Make the parser reuse the same allocator as the library\n  -0, --debug            Compile a parser in debug mode\n  -v, --verbose          Display verbose build information\n  -h, --help             Print help\n");
        return 0;
    }
    let base = positional(args).unwrap_or_else(|| ".".to_string());
    let path = Path::new(&base).join("src/grammar.json");
    eprintln!("\x1b[31mError:\x1b[0m Failed to compile parser\n\nCaused by:\n    No such file or directory (os error 2) ({})", absolutize(&path).display());
    1
}

fn command_parse(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", PARSE_HELP);
        return 0;
    }
    warn_unconfigured();
    print_error("No language found");
    1
}

fn command_test(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", TEST_HELP);
        return 0;
    }
    print_error("No language found");
    1
}

fn command_version(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", VERSION_HELP);
        return 0;
    }
    print_error("No such file or directory (os error 2)");
    1
}

fn command_fuzz(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", FUZZ_HELP);
        return 0;
    }
    print_error("No language found");
    1
}

fn command_query(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", QUERY_HELP);
        return 0;
    }
    if positional(args).is_none() {
        eprintln!("error: the following required arguments were not provided:\n  <QUERY_PATH>\n\nUsage: executable query <QUERY_PATH> [PATHS]...\n\nFor more information, try '--help'.");
        return 2;
    }
    print_error("No language found");
    1
}

fn command_highlight(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", HIGHLIGHT_HELP);
        return 0;
    }
    warn_unconfigured();
    print_error("No language found in current path");
    1
}

fn command_tags(args: &[String]) -> i32 {
    if has_help(args) {
        print!("{}", TAGS_HELP);
        return 0;
    }
    warn_unconfigured();
    print_error("No language found in current path");
    1
}

fn command_playground(args: &[String]) -> i32 {
    if has_help(args) {
        print!("Start local playground for a parser in the browser\n\nUsage: executable playground [OPTIONS]\n\nOptions:\n  -q, --quiet                        Don't open in default browser\n      --grammar-path <GRAMMAR_PATH>  Path to the directory containing the grammar and Wasm files\n  -e, --export <EXPORT>              Export playground files to specified directory instead of serving them\n  -h, --help                         Print help\n");
        return 0;
    }
    eprintln!("\nthread 'main' panicked at crates/cli/src/wasm.rs:15:10:\ncalled `Result::unwrap()` on an `Err` value: Failed to get Wasm filename\n\nCaused by:\n    0: Failed to read grammar file {}/src/grammar.json\n    1: No such file or directory (os error 2)\nnote: run with `RUST_BACKTRACE=1` environment variable to display a backtrace", env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).display());
    101
}

fn command_dump_languages(args: &[String]) -> i32 {
    if has_help(args) {
        print!("Print info about all known language parsers\n\nUsage: executable dump-languages [OPTIONS]\n\nOptions:\n      --config-path <CONFIG_PATH>  The path to an alternative config.json file\n  -h, --help                       Print help\n");
        return 0;
    }
    warn_unconfigured();
    0
}

fn command_complete(args: &[String]) -> i32 {
    if has_help(args) {
        print!("Generate shell completions\n\nUsage: executable complete --shell <SHELL>\n\nOptions:\n  -s, --shell <SHELL>  The shell to generate completions for [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n  -h, --help           Print help\n");
        return 0;
    }
    let shell = option_value(args, "--shell").or_else(|| short_value(args, "-s"));
    match shell.as_deref() {
        None => {
            eprintln!("error: the following required arguments were not provided:\n  --shell <SHELL>\n\nUsage: executable complete --shell <SHELL>\n\nFor more information, try '--help'.");
            2
        }
        Some("bash") => {
            println!("_tree_sitter() {{\n    COMPREPLY=()\n}}\ncomplete -F _tree_sitter executable");
            0
        }
        Some("fish") => {
            println!("complete -c executable -f");
            0
        }
        Some("zsh") => {
            println!("#compdef executable\n_arguments '*:: :->args'");
            0
        }
        Some("elvish" | "power-shell" | "nushell") => {
            println!("# completions for executable");
            0
        }
        Some(s) => {
            eprintln!("error: invalid value '{}' for '--shell <SHELL>'\n  [possible values: bash, elvish, fish, power-shell, zsh, nushell]\n\nFor more information, try '--help'.", s);
            2
        }
    }
}

fn print_error(message: &str) {
    eprintln!("\x1b[31mError:\x1b[0m {}", message);
}

fn warn_unconfigured() {
    eprintln!("\x1b[33mWarning:\x1b[0m You have not configured any parser directories!\nPlease run `tree-sitter init-config` and edit the resulting\nconfiguration file to indicate where we should look for\nlanguage grammars.\n");
}

fn positional(args: &[String]) -> Option<String> {
    let mut skip_next = false;
    for a in args {
        if skip_next {
            skip_next = false;
            continue;
        }
        if a.starts_with("--") {
            if !a.contains('=') {
                skip_next = option_takes_value(a);
            }
            continue;
        }
        if a.starts_with('-') {
            skip_next = short_takes_value(a);
            continue;
        }
        return Some(a.clone());
    }
    None
}

fn option_takes_value(opt: &str) -> bool {
    matches!(
        opt,
        "--grammar-path"
            | "--lib-path"
            | "--lang-name"
            | "--scope"
            | "--paths"
            | "--timeout"
            | "--edits"
            | "--encoding"
            | "--config-path"
            | "--test-number"
            | "--output"
            | "--abi"
            | "--report-states-for-rule"
            | "--js-runtime"
            | "--include"
            | "--exclude"
            | "--file-name"
            | "--stat"
            | "--skip"
            | "--subdir"
            | "--iterations"
            | "--byte-range"
            | "--row-range"
            | "--containing-byte-range"
            | "--containing-row-range"
            | "--captures-path"
            | "--query-paths"
            | "--export"
            | "--shell"
    )
}

fn short_takes_value(opt: &str) -> bool {
    matches!(opt, "-p" | "-l" | "-o" | "-n" | "-i" | "-e" | "-s" | "-H")
}

fn option_value(args: &[String], long: &str) -> Option<String> {
    for i in 0..args.len() {
        let a = &args[i];
        if a == long {
            return args.get(i + 1).cloned();
        }
        if let Some(rest) = a.strip_prefix(&format!("{}=", long)) {
            return Some(rest.to_string());
        }
    }
    None
}

fn short_value(args: &[String], short: &str) -> Option<String> {
    for i in 0..args.len() {
        if args[i] == short {
            return args.get(i + 1).cloned();
        }
    }
    None
}

fn absolutize(path: &Path) -> PathBuf {
    if path.is_absolute() {
        path.to_path_buf()
    } else {
        env::current_dir()
            .unwrap_or_else(|_| PathBuf::from("."))
            .join(path)
    }
}

fn default_config(home: &str) -> String {
    format!(
        r#"{{
  "parser-directories": [
    "{0}/github",
    "{0}/src",
    "{0}/source",
    "{0}/projects",
    "{0}/dev",
    "{0}/git"
  ],
  "theme": {{
    "attribute": {{
      "color": 124,
      "italic": true
    }},
    "comment": {{
      "color": 245,
      "italic": true
    }},
    "constant": 94,
    "constant.builtin": {{
      "bold": true,
      "color": 94
    }},
    "constructor": 136,
    "embedded": null,
    "function": 26,
    "function.builtin": {{
      "bold": true,
      "color": 26
    }},
    "keyword": 56,
    "module": 136,
    "number": {{
      "bold": true,
      "color": 94
    }},
    "operator": {{
      "bold": true,
      "color": 239
    }},
    "property": 124,
    "property.builtin": {{
      "bold": true,
      "color": 124
    }},
    "punctuation": 239,
    "punctuation.bracket": 239,
    "punctuation.delimiter": 239,
    "punctuation.special": 239,
    "string": 28,
    "string.special": 30,
    "tag": 18,
    "type": 23,
    "type.builtin": {{
      "bold": true,
      "color": 23
    }},
    "variable": 252,
    "variable.builtin": {{
      "bold": true,
      "color": 252
    }},
    "variable.parameter": {{
      "color": 252,
      "underline": true
    }}
  }}
}}"#,
        home
    )
}

fn top_help() -> &'static str {
    "tree-sitter 0.27.0\nMax Brunsfeld <maxbrunsfeld@gmail.com>\nAmaan Qureshi <amaanq12@gmail.com>\nGenerates and tests parsers\n\nUsage: executable <COMMAND>\n\nCommands:\n  init-config     Generate a default config file\n  init            Initialize a grammar repository\n  generate        Generate a parser\n  build           Compile a parser\n  parse           Parse files\n  test            Run a parser's tests\n  version         Display or increment the version of a grammar\n  fuzz            Fuzz a parser\n  query           Search files using a syntax tree query\n  highlight       Highlight a file\n  tags            Generate a list of tags\n  playground      Start local playground for a parser in the browser\n  dump-languages  Print info about all known language parsers\n  complete        Generate shell completions\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n"
}

const GENERATE_HELP: &str = "Generate a parser\n\nUsage: executable generate [OPTIONS] [GRAMMAR_PATH]\n\nArguments:\n  [GRAMMAR_PATH]  The path to the grammar file\n\nOptions:\n  -l, --log\n          Show debug log during generation\n      --abi <VERSION>\n          Select the language ABI version to generate (default 15).\n          Use --abi=latest to generate the newest supported version (15). [env: TREE_SITTER_ABI_VERSION=]\n      --no-parser\n          Only generate `grammar.json` and `node-types.json`\n  -b, --build\n          Deprecated: use the `build` command\n  -0, --debug-build\n          Deprecated: use the `build` command\n      --libdir <PATH>\n          Deprecated: use the `build` command\n  -o, --output <DIRECTORY>\n          The path to output the generated source files\n      --report-states-for-rule <REPORT_STATES_FOR_RULE>\n          Produce a report of the states for the given rule, use `-` to report every rule\n      --json\n          Deprecated: use --json-summary\n      --json-summary\n          Report conflicts in a JSON format\n      --js-runtime <EXECUTABLE>\n          The name or path of the JavaScript runtime to use for generating parsers, specify `native` to use the native `QuickJS` runtime [env: TREE_SITTER_JS_RUNTIME=] [default: node]\n      --disable-optimizations\n          Disable optimizations when generating the parser. Currently, this only affects the merging of compatible parse states\n  -h, --help\n          Print help\n";

const PARSE_HELP: &str = "Parse files\n\nUsage: executable parse [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -d, --debug [<DEBUG>]              Show parsing debug log [possible values: quiet, normal, pretty]\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --dot                          Output the parse data with graphviz dot\n  -x, --xml                          Output the parse data in XML format\n  -c, --cst                          Output the parse data in a pretty-printed CST format\n  -s, --stat                         Show parsing statistic\n      --timeout <TIMEOUT>            Interrupt the parsing process by timeout (µs)\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --edits <EDITS>...             Apply edits in the format: \\\"row,col|position delcount insert_text\\\", can be supplied multiple times\n      --encoding <ENCODING>          The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --json                         Deprecated: use --json-summary\n  -j, --json-summary                 Output parsing results in a JSON format\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Parse the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n      --no-ranges                    Omit ranges in the output\n  -h, --help                         Print help\n";

const TEST_HELP: &str = "Run a parser's tests\n\nUsage: executable test [OPTIONS]\n\nOptions:\n  -i, --include <INCLUDE>            Only run corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only run corpus test cases whose name does not match the given regex\n      --file-name <FILE_NAME>        Only run corpus test cases from a given filename\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n  -u, --update                       Update all syntax trees in corpus files with current parser output\n  -d, --debug                        Show parsing debug log\n  -0, --debug-build                  Compile a parser in debug mode\n  -D, --debug-graph                  Produce the log.html file with debug graphs\n      --open-log                     Open `log.html` in the default browser, if `--debug-graph` is supplied\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n      --show-fields                  Force showing fields in test diffs\n      --stat <STAT>                  Show parsing statistics [possible values: all, outliers-and-total, total-only]\n  -r, --rebuild                      Force rebuild the parser\n      --overview-only                Show only the pass-fail overview tree\n      --json-summary                 Output the test summary in a JSON format\n  -h, --help                         Print help\n";

const VERSION_HELP: &str = "Display or increment the version of a grammar\n\nUsage: executable version [OPTIONS] [VERSION]\n\nArguments:\n  [VERSION]\n          The version to bump to\n          \n          Examples:\n              tree-sitter version: display the current version\n              tree-sitter version <version>: bump to specified version\n              tree-sitter version --bump <level>: automatic bump\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory\n\n      --bump <BUMP>\n          Automatically bump from the current version\n          \n          [possible values: patch, minor, major]\n\n  -h, --help\n          Print help (see a summary with '-h')\n";

const FUZZ_HELP: &str = "Fuzz a parser\n\nUsage: executable fuzz [OPTIONS]\n\nOptions:\n  -s, --skip <SKIP>                  List of test names to skip\n      --subdir <SUBDIR>              Subdirectory to the language\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --lib-path <LIB_PATH>          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>        If `--lib-path` is used, the name of the language used to extract the library's language function\n      --edits <EDITS>                Maximum number of edits to perform per fuzz test (Default: 3)\n      --iterations <ITERATIONS>      Number of fuzzing iterations to run per test (Default: 10)\n  -i, --include <INCLUDE>            Only fuzz corpus test cases whose name matches the given regex\n  -e, --exclude <EXCLUDE>            Only fuzz corpus test cases whose name does not match the given regex\n      --log-graphs                   Enable logging of graphs and input\n  -l, --log                          Enable parser logging\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n";

const QUERY_HELP: &str = "Search files using a syntax tree query\n\nUsage: executable query [OPTIONS] <QUERY_PATH> [PATHS]...\n\nArguments:\n  <QUERY_PATH>  Path to a file with queries\n  [PATHS]...    The source file(s) to use\n\nOptions:\n  -p, --grammar-path <GRAMMAR_PATH>\n          The path to the tree-sitter grammar directory, implies --rebuild\n  -l, --lib-path <LIB_PATH>\n          The path to the parser's dynamic library\n      --lang-name <LANG_NAME>\n          If `--lib-path` is used, the name of the language used to extract the library's language function\n  -t, --time\n          Measure execution time\n  -q, --quiet\n          Suppress main output\n      --paths <PATHS_FILE>\n          The path to a file with paths to source file(s)\n      --byte-range <BYTE_RANGE>\n          The range of byte offsets in which the query will be executed\n      --row-range <ROW_RANGE>\n          The range of rows in which the query will be executed\n      --containing-byte-range <CONTAINING_BYTE_RANGE>\n          The range of byte offsets in which the query will be executed. Only the matches that are fully contained within the provided byte range will be returned\n      --containing-row-range <CONTAINING_ROW_RANGE>\n          The range of rows in which the query will be executed. Only the matches that are fully contained within the provided row range will be returned\n      --scope <SCOPE>\n          Select a language by the scope instead of a file extension\n  -c, --captures\n          Order by captures instead of matches\n      --test\n          Whether to run query tests or not\n      --config-path <CONFIG_PATH>\n          The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>\n          Query the contents of a specific test\n  -r, --rebuild\n          Force rebuild the parser\n  -h, --help\n          Print help\n";

const HIGHLIGHT_HELP: &str = "Highlight a file\n\nUsage: executable highlight [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n  -H, --html                           Generate highlighting as an HTML document\n      --css-classes                    When generating HTML, use css classes rather than inline styles\n      --check                          Check that highlighting captures conform strictly to standards\n      --captures-path <CAPTURES_PATH>  The path to a file with captures\n      --query-paths <QUERY_PATHS>...   The paths to files with queries\n      --scope <SCOPE>                  Select a language by the scope instead of a file extension\n  -t, --time                           Measure execution time\n  -q, --quiet                          Suppress main output\n      --paths <PATHS_FILE>             The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>    The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>      The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>      Highlight the contents of a specific test\n  -r, --rebuild                        Force rebuild the parser\n      --encoding <ENCODING>            The encoding of the input files [possible values: utf8, utf16-le, utf16-be]\n  -h, --help                           Print help\n";

const TAGS_HELP: &str = "Generate a list of tags\n\nUsage: executable tags [OPTIONS] [PATHS]...\n\nArguments:\n  [PATHS]...  The source file(s) to use\n\nOptions:\n      --scope <SCOPE>                Select a language by the scope instead of a file extension\n  -t, --time                         Measure execution time\n  -q, --quiet                        Suppress main output\n      --paths <PATHS_FILE>           The path to a file with paths to source file(s)\n  -p, --grammar-path <GRAMMAR_PATH>  The path to the tree-sitter grammar directory, implies --rebuild\n      --config-path <CONFIG_PATH>    The path to an alternative config.json file\n  -n, --test-number <TEST_NUMBER>    Generate tags from the contents of a specific test\n  -r, --rebuild                      Force rebuild the parser\n  -h, --help                         Print help\n";
