use clap::{Arg, ArgAction, Command};
use std::fs;
use std::io::{self, Read, Write};
use std::path::PathBuf;
use unicode_width::{UnicodeWidthChar, UnicodeWidthStr};

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
enum StyleName {
    None,
    Ascii,
    Ascii2,
    Sharp,
    Rounded,
    Reinforced,
    Markdown,
    Grid,
}

#[derive(Copy, Clone, Debug, Eq, PartialEq)]
enum AlignName {
    Left,
    Center,
    Right,
}

struct Args {
    no_headers: bool,
    number: bool,
    tsv: bool,
    delimiter: char,
    style: StyleName,
    padding: usize,
    indent: usize,
    sniff: usize,
    header_align: AlignName,
    body_align: AlignName,
    _disable_pager: bool,
    file: Option<PathBuf>,
}

fn main() {
    let raw_args: Vec<String> = std::env::args().collect();
    if raw_args.len() == 2 && (raw_args[1] == "--help" || raw_args[1] == "-h") {
        print_help();
        return;
    }
    if raw_args.len() == 2 && (raw_args[1] == "--version" || raw_args[1] == "-V") {
        println!("csview 1.3.4");
        return;
    }
    let mut args = parse_args();
    if args.tsv {
        args.delimiter = '\t';
    }

    if let Err(err) = run(args) {
        let _ = writeln!(io::stderr(), "csview: {err}");
        std::process::exit(1);
    }
}

fn print_help() {
    println!(r#"A high performance csv viewer with cjk/emoji support.

Usage: executable [OPTIONS] [FILE]

Arguments:
  [FILE]
          File to view

Options:
  -H, --no-headers
          Specify that the input has no header row
  -n, --number
          Prepend a column of line numbers to the table
  -t, --tsv
          Use '\t' as delimiter for tsv
  -d, --delimiter <DELIMITER>
          Specify the field delimiter [default: ,]
  -s, --style <STYLE>
          Specify the border style [default: sharp] [possible values: none, ascii, ascii2, sharp,
          rounded, reinforced, markdown, grid]
  -p, --padding <PADDING>
          Specify padding for table cell [default: 1]
  -i, --indent <INDENT>
          Specify global indent for table [default: 0]
      --sniff <LIMIT>
          Limit column widths sniffing to the specified number of rows. Specify "0" to cancel limit
          [default: 1000]
      --header-align <HEADER_ALIGN>
          Specify the alignment of the table header [default: center] [possible values: left,
          center, right]
      --body-align <BODY_ALIGN>
          Specify the alignment of the table body [default: left] [possible values: left, center,
          right]
  -P, --disable-pager
          Disable pager
  -h, --help
          Print help
  -V, --version
          Print version"#);
}

fn parse_args() -> Args {
    let matches = Command::new("executable")
        .about("A high performance csv viewer with cjk/emoji support.")
        .disable_help_subcommand(true)
        .next_line_help(true)
        .arg(
            Arg::new("no_headers")
                .short('H')
                .long("no-headers")
                .help("Specify that the input has no header row")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("number")
                .short('n')
                .long("number")
                .help("Prepend a column of line numbers to the table")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("tsv")
                .short('t')
                .long("tsv")
                .help("Use '\\t' as delimiter for tsv")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("delimiter")
                .short('d')
                .long("delimiter")
                .help("Specify the field delimiter")
                .default_value(",")
                .value_parser(clap::value_parser!(char))
                .value_name("DELIMITER"),
        )
        .arg(
            Arg::new("style")
                .short('s')
                .long("style")
                .help("Specify the border style")
                .default_value("sharp")
                .value_parser(clap::builder::PossibleValuesParser::new([
                    "none",
                    "ascii",
                    "ascii2",
                    "sharp",
                    "rounded",
                    "reinforced",
                    "markdown",
                    "grid",
                ]))
                .value_name("STYLE"),
        )
        .arg(
            Arg::new("padding")
                .short('p')
                .long("padding")
                .help("Specify padding for table cell")
                .default_value("1")
                .value_parser(clap::value_parser!(usize))
                .value_name("PADDING"),
        )
        .arg(
            Arg::new("indent")
                .short('i')
                .long("indent")
                .help("Specify global indent for table")
                .default_value("0")
                .value_parser(clap::value_parser!(usize))
                .value_name("INDENT"),
        )
        .arg(
            Arg::new("sniff")
                .long("sniff")
                .help("Limit column widths sniffing to the specified number of rows. Specify \"0\" to cancel limit")
                .default_value("1000")
                .value_parser(clap::value_parser!(usize))
                .value_name("LIMIT"),
        )
        .arg(
            Arg::new("header_align")
                .long("header-align")
                .help("Specify the alignment of the table header")
                .default_value("center")
                .value_parser(clap::builder::PossibleValuesParser::new(["left", "center", "right"]))
                .value_name("HEADER_ALIGN"),
        )
        .arg(
            Arg::new("body_align")
                .long("body-align")
                .help("Specify the alignment of the table body")
                .default_value("left")
                .value_parser(clap::builder::PossibleValuesParser::new(["left", "center", "right"]))
                .value_name("BODY_ALIGN"),
        )
        .arg(
            Arg::new("disable_pager")
                .short('P')
                .long("disable-pager")
                .help("Disable pager")
                .action(ArgAction::SetTrue),
        )
        .arg(
            Arg::new("version")
                .short('V')
                .long("version")
                .help("Print version")
                .action(ArgAction::SetTrue),
        )
        .arg(Arg::new("file").value_name("FILE").help("File to view"))
        .get_matches();

    if matches.get_flag("version") {
        println!("csview 1.3.4");
        std::process::exit(0);
    }

    let delimiter = *matches.get_one::<char>("delimiter").unwrap();

    Args {
        no_headers: matches.get_flag("no_headers"),
        number: matches.get_flag("number"),
        tsv: matches.get_flag("tsv"),
        delimiter,
        style: parse_style(matches.get_one::<String>("style").unwrap()),
        padding: *matches.get_one::<usize>("padding").unwrap(),
        indent: *matches.get_one::<usize>("indent").unwrap(),
        sniff: *matches.get_one::<usize>("sniff").unwrap(),
        header_align: parse_align(matches.get_one::<String>("header_align").unwrap()),
        body_align: parse_align(matches.get_one::<String>("body_align").unwrap()),
        _disable_pager: matches.get_flag("disable_pager"),
        file: matches.get_one::<String>("file").map(PathBuf::from),
    }
}

fn parse_style(s: &str) -> StyleName {
    match s {
        "none" => StyleName::None,
        "ascii" => StyleName::Ascii,
        "ascii2" => StyleName::Ascii2,
        "sharp" => StyleName::Sharp,
        "rounded" => StyleName::Rounded,
        "reinforced" => StyleName::Reinforced,
        "markdown" => StyleName::Markdown,
        "grid" => StyleName::Grid,
        _ => unreachable!(),
    }
}

fn parse_align(s: &str) -> AlignName {
    match s {
        "left" => AlignName::Left,
        "center" => AlignName::Center,
        "right" => AlignName::Right,
        _ => unreachable!(),
    }
}

fn run(args: Args) -> Result<(), String> {
    let input = if let Some(path) = &args.file {
        fs::read_to_string(path).map_err(|e| e.to_string())?
    } else {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        s
    };

    let mut records = parse_csv(&input, args.delimiter)?;
    if args.no_headers && (input.is_empty() || input == "\n" || input == "\r\n") {
        records.clear();
    }
    let output = render(records, &args);
    print!("{output}");
    Ok(())
}

#[derive(Clone, Debug)]
struct Record {
    fields: Vec<String>,
    line: usize,
    byte: usize,
}

fn parse_csv(input: &str, delimiter: char) -> Result<Vec<Vec<String>>, String> {
    if input.is_empty() || input == "\n" || input == "\r\n" {
        return Ok(vec![vec![String::new()]]);
    }

    let mut records = Vec::new();
    let mut fields = Vec::new();
    let mut field = String::new();
    let mut in_quotes = false;
    let mut at_field_start = true;
    let mut record_start_line = 1usize;
    let mut record_start_byte = 0usize;
    let mut line = 1usize;
    let mut iter = input.char_indices().peekable();

    while let Some((idx, ch)) = iter.next() {
        if in_quotes {
            if ch == '"' {
                if let Some((_, '"')) = iter.peek().copied() {
                    field.push('"');
                    iter.next();
                } else {
                    in_quotes = false;
                }
            } else {
                if ch == '\n' {
                    line += 1;
                }
                field.push(ch);
            }
            continue;
        }

        if at_field_start && ch == '"' {
            in_quotes = true;
            at_field_start = false;
            continue;
        }

        if ch == delimiter {
            fields.push(std::mem::take(&mut field));
            at_field_start = true;
        } else if ch == '\n' {
            fields.push(std::mem::take(&mut field));
            records.push(Record {
                fields: std::mem::take(&mut fields),
                line: record_start_line,
                byte: record_start_byte,
            });
            line += 1;
            record_start_line = line;
            record_start_byte = idx + ch.len_utf8();
            at_field_start = true;
        } else if ch == '\r' {
            if let Some((next_idx, '\n')) = iter.peek().copied() {
                iter.next();
                fields.push(std::mem::take(&mut field));
                records.push(Record {
                    fields: std::mem::take(&mut fields),
                    line: record_start_line,
                    byte: record_start_byte,
                });
                line += 1;
                record_start_line = line;
                record_start_byte = next_idx + 1;
                at_field_start = true;
            } else {
                field.push(ch);
                at_field_start = false;
            }
        } else {
            field.push(ch);
            at_field_start = false;
        }
    }

    if in_quotes {
        return Err("CSV error: unterminated quote".to_string());
    }

    if !field.is_empty() || !fields.is_empty() || !input.ends_with('\n') {
        fields.push(field);
        records.push(Record {
            fields,
            line: record_start_line,
            byte: record_start_byte,
        });
    }

    if records.is_empty() {
        records.push(Record {
            fields: vec![String::new()],
            line: 1,
            byte: 0,
        });
    }

    let expected = records[0].fields.len();
    for (idx, rec) in records.iter().enumerate().skip(1) {
        if rec.fields.len() != expected {
            return Err(format!(
                "CSV error: record {} (line: {}, byte: {}): found record with {} fields, but the previous record has {} fields",
                idx,
                rec.line,
                rec.byte,
                rec.fields.len(),
                expected
            ));
        }
    }

    Ok(records.into_iter().map(|r| r.fields).collect())
}

fn render(records: Vec<Vec<String>>, args: &Args) -> String {
    let mut rows = records;
    if args.number {
        if args.no_headers {
            for (i, row) in rows.iter_mut().enumerate() {
                row.insert(0, (i + 1).to_string());
            }
        } else {
            if let Some(header) = rows.first_mut() {
                header.insert(0, "#".to_string());
            }
            for (i, row) in rows.iter_mut().enumerate().skip(1) {
                row.insert(0, i.to_string());
            }
        }
    }

    let columns = rows
        .iter()
        .map(|r| r.len())
        .max()
        .unwrap_or(if args.number { 1 } else { 0 });
    for row in &mut rows {
        row.resize(columns, String::new());
    }

    let mut widths = vec![0usize; columns];
    if rows.is_empty() && args.number && columns == 1 {
        widths[0] = 1;
    }
    let sniff_limit = if args.sniff == 0 { usize::MAX } else { args.sniff };
    for (ri, row) in rows.iter().enumerate() {
        let use_for_width = if args.no_headers {
            ri < sniff_limit
        } else {
            ri == 0 || ri <= sniff_limit
        };
        if !use_for_width {
            continue;
        }
        for (ci, cell) in row.iter().enumerate() {
            widths[ci] = widths[ci].max(UnicodeWidthStr::width(cell.as_str()));
        }
    }

    let spec = StyleSpec::new(args.style);
    let indent = " ".repeat(args.indent);
    let mut out = String::new();

    if spec.top {
        out.push_str(&indent);
        out.push_str(&border_line(&widths, args.padding, &spec, BorderKind::Top));
        out.push('\n');
    }

    for (ri, row) in rows.iter().enumerate() {
        let align = if !args.no_headers && ri == 0 {
            args.header_align
        } else {
            args.body_align
        };
        out.push_str(&indent);
        out.push_str(&row_line(row, &widths, args.padding, align, &spec));
        out.push('\n');

        if !args.no_headers && ri == 0 && spec.header_sep {
            out.push_str(&indent);
            out.push_str(&border_line(&widths, args.padding, &spec, BorderKind::Middle));
            out.push('\n');
        } else if args.style == StyleName::Grid && ri + 1 < rows.len() {
            out.push_str(&indent);
            out.push_str(&border_line(&widths, args.padding, &spec, BorderKind::Middle));
            out.push('\n');
        }
    }

    if spec.bottom {
        out.push_str(&indent);
        out.push_str(&border_line(&widths, args.padding, &spec, BorderKind::Bottom));
        out.push('\n');
    }

    out
}

#[derive(Copy, Clone)]
enum BorderKind {
    Top,
    Middle,
    Bottom,
}

struct StyleSpec {
    left: &'static str,
    sep: &'static str,
    right: &'static str,
    top_left: &'static str,
    top_sep: &'static str,
    top_right: &'static str,
    mid_left: &'static str,
    mid_sep: &'static str,
    mid_right: &'static str,
    bot_left: &'static str,
    bot_sep: &'static str,
    bot_right: &'static str,
    horiz: &'static str,
    top: bool,
    bottom: bool,
    header_sep: bool,
}

impl StyleSpec {
    fn new(style: StyleName) -> Self {
        match style {
            StyleName::None => Self {
                left: "",
                sep: "",
                right: "",
                top_left: "",
                top_sep: "",
                top_right: "",
                mid_left: "",
                mid_sep: "",
                mid_right: "",
                bot_left: "",
                bot_sep: "",
                bot_right: "",
                horiz: "",
                top: false,
                bottom: false,
                header_sep: false,
            },
            StyleName::Ascii => Self::boxed("+", "+", "+", "+", "+", "+", "+", "+", "+", "-", "|", "|", "|", true, true, true),
            StyleName::Sharp | StyleName::Grid => Self::boxed("┌", "┬", "┐", "├", "┼", "┤", "└", "┴", "┘", "─", "│", "│", "│", true, true, true),
            StyleName::Rounded => Self::boxed("╭", "┬", "╮", "├", "┼", "┤", "╰", "┴", "╯", "─", "│", "│", "│", true, true, true),
            StyleName::Reinforced => Self::boxed("┏", "┬", "┓", "├", "┼", "┤", "┗", "┴", "┛", "─", "│", "│", "│", true, true, true),
            StyleName::Markdown => Self::boxed("", "|", "", "|", "|", "|", "", "|", "", "-", "|", "|", "|", false, false, true),
            StyleName::Ascii2 => Self::boxed("", "|", "", " ", "+", " ", "", "+", "", "-", " ", "|", " ", false, false, true),
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn boxed(
        tl: &'static str,
        ts: &'static str,
        tr: &'static str,
        ml: &'static str,
        ms: &'static str,
        mr: &'static str,
        bl: &'static str,
        bs: &'static str,
        br: &'static str,
        h: &'static str,
        left: &'static str,
        sep: &'static str,
        right: &'static str,
        top: bool,
        bottom: bool,
        header_sep: bool,
    ) -> Self {
        Self {
            left,
            sep,
            right,
            top_left: tl,
            top_sep: ts,
            top_right: tr,
            mid_left: ml,
            mid_sep: ms,
            mid_right: mr,
            bot_left: bl,
            bot_sep: bs,
            bot_right: br,
            horiz: h,
            top,
            bottom,
            header_sep,
        }
    }
}

fn border_line(widths: &[usize], padding: usize, spec: &StyleSpec, kind: BorderKind) -> String {
    let (left, sep, right) = match kind {
        BorderKind::Top => (spec.top_left, spec.top_sep, spec.top_right),
        BorderKind::Middle => (spec.mid_left, spec.mid_sep, spec.mid_right),
        BorderKind::Bottom => (spec.bot_left, spec.bot_sep, spec.bot_right),
    };
    let mut s = String::new();
    s.push_str(left);
    for (i, width) in widths.iter().enumerate() {
        if i > 0 {
            s.push_str(sep);
        }
        s.push_str(&spec.horiz.repeat(width + padding * 2));
    }
    s.push_str(right);
    s
}

fn row_line(row: &[String], widths: &[usize], padding: usize, align: AlignName, spec: &StyleSpec) -> String {
    let mut s = String::new();
    s.push_str(spec.left);
    for (i, width) in widths.iter().enumerate() {
        if i > 0 {
            s.push_str(spec.sep);
        }
        s.push_str(&format_cell(row.get(i).map(String::as_str).unwrap_or(""), *width, padding, align));
    }
    s.push_str(spec.right);
    s
}

fn format_cell(cell: &str, width: usize, padding: usize, align: AlignName) -> String {
    let clipped = clip_width(cell, width);
    let cw = UnicodeWidthStr::width(clipped.as_str());
    let extra = width.saturating_sub(cw);
    let (left_extra, right_extra) = match align {
        AlignName::Left => (0, extra),
        AlignName::Right => (extra, 0),
        AlignName::Center => (extra / 2, extra - (extra / 2)),
    };
    format!(
        "{}{}{}{}{}",
        " ".repeat(padding + left_extra),
        clipped,
        " ".repeat(right_extra),
        "",
        " ".repeat(padding)
    )
}

fn clip_width(s: &str, max_width: usize) -> String {
    let mut out = String::new();
    let mut width = 0usize;
    for ch in s.chars() {
        let cw = UnicodeWidthChar::width(ch).unwrap_or(0);
        if width + cw > max_width {
            break;
        }
        out.push(ch);
        width += cw;
    }
    out
}
