use regex::Regex;
use serde::{Deserialize, Serialize};
use std::cmp::Ordering;
use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::Path;

const VERSION: &str = "3.54.0 2026-04-14 20:02:49 49b3bac482c831f503c7f90c35959e7ea731950e991baba86b2ab95987d2539b (64-bit)";

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(untagged)]
enum Value {
    Null,
    Int(i64),
    Float(f64),
    Text(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct Table {
    columns: Vec<String>,
    types: Vec<String>,
    create_sql: String,
    rows: Vec<Vec<Value>>,
}

#[derive(Debug, Default, Serialize, Deserialize)]
struct Database {
    tables: BTreeMap<String, Table>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
enum Mode {
    List,
    Csv,
    Tabs,
    Column,
    Line,
    Json,
    Quote,
    Html,
    Insert,
    Markdown,
    Table,
    Box,
}

struct Shell {
    db: Database,
    db_path: Option<String>,
    mode: Mode,
    headers: bool,
    col_sep: String,
    row_sep: String,
    null_value: String,
    echo: bool,
    bail: bool,
    exit_code: i32,
    output: Box<dyn Write>,
}

#[derive(Clone)]
struct QueryResult {
    headers: Vec<String>,
    rows: Vec<Vec<Value>>,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-help" || a == "--help") {
        print_help();
        return;
    }
    if args.iter().any(|a| a == "-version" || a == "--version") {
        println!("{}", VERSION);
        return;
    }

    let mut mode = Mode::List;
    let mut headers = false;
    let mut col_sep = "|".to_string();
    let mut row_sep = "\n".to_string();
    let mut null_value = String::new();
    let mut echo = false;
    let mut bail = false;
    let mut ifexists = false;
    let mut cmds = Vec::new();
    let mut positional = Vec::new();
    let mut i = 0;
    let mut stop_opts = false;
    while i < args.len() {
        let a = args[i].clone();
        if !stop_opts && a == "--" {
            stop_opts = true;
            i += 1;
            continue;
        }
        if !stop_opts && a.starts_with('-') {
            match a.as_str() {
                "-batch" | "-interactive" | "-noinit" | "-safe" | "-unsafe-testing"
                | "-readonly" | "-append" | "-deserialize" | "-nofollow"
                | "-no-rowid-in-view" | "-stats" | "-zip" | "-memtrace" | "-pcachetrace"
                | "-vfstrace" => {}
                "-echo" => echo = true,
                "-bail" => bail = true,
                "-header" | "-headers" => headers = true,
                "-noheader" | "-noheaders" => headers = false,
                "-list" => mode = Mode::List,
                "-csv" => mode = Mode::Csv,
                "-tabs" => {
                    mode = Mode::Tabs;
                    col_sep = "\t".to_string();
                }
                "-ascii" => {
                    mode = Mode::List;
                    col_sep = "\x1f".to_string();
                    row_sep = "\x1e".to_string();
                }
                "-column" => mode = Mode::Column,
                "-line" => mode = Mode::Line,
                "-json" => mode = Mode::Json,
                "-quote" => mode = Mode::Quote,
                "-html" => mode = Mode::Html,
                "-markdown" => mode = Mode::Markdown,
                "-table" => mode = Mode::Table,
                "-box" => mode = Mode::Box,
                "-ifexists" => ifexists = true,
                "-cmd" => {
                    i += 1;
                    if i >= args.len() { die_unknown_arg("-cmd requires an argument"); }
                    cmds.push(args[i].clone());
                }
                "-init" | "-separator" | "-newline" | "-nullvalue" | "-escape" | "-mmap"
                | "-maxsize" | "-vfs" | "-screenwidth" | "-nonce" => {
                    i += 1;
                    if i >= args.len() { die_unknown_arg(&format!("{} requires an argument", a)); }
                    match a.as_str() {
                        "-separator" => col_sep = args[i].clone(),
                        "-newline" => row_sep = args[i].clone(),
                        "-nullvalue" => null_value = args[i].clone(),
                        _ => {}
                    }
                }
                "-lookaside" | "-pagecache" => {
                    i += 2;
                    if i >= args.len() { die_unknown_arg(&format!("{} requires arguments", a)); }
                }
                "-A" => {
                    return;
                }
                _ => {
                    eprintln!("./executable: Error: unknown option: {}", a);
                    eprintln!("Use -help for a list of options.");
                    std::process::exit(1);
                }
            }
        } else {
            positional.push(a);
        }
        i += 1;
    }

    let (db_path, sql_text) = if positional.is_empty() {
        (None, None)
    } else if positional.len() == 1 {
        let first = positional[0].clone();
        if looks_like_sql_or_dot(&first) {
            (None, Some(first))
        } else {
            (Some(first), None)
        }
    } else {
        (Some(positional[0].clone()), Some(positional[1..].join(" ")))
    };

    if ifexists {
        if let Some(p) = &db_path {
            if p != ":memory:" && !Path::new(p).exists() {
                eprintln!("Error: unable to open database \"{}\": unable to open database file", p);
                std::process::exit(1);
            }
        }
    }

    let db = load_db(db_path.as_deref());
    let mut shell = Shell {
        db,
        db_path: db_path.filter(|p| p != ":memory:"),
        mode,
        headers,
        col_sep,
        row_sep,
        null_value,
        echo,
        bail,
        exit_code: 0,
        output: Box::new(io::stdout()),
    };

    for c in cmds {
        shell.run_script(&c);
        if shell.bail && shell.exit_code != 0 { break; }
    }
    if shell.exit_code == 0 {
        if let Some(sql) = sql_text {
            shell.run_script(&sql);
        } else {
            let mut input = String::new();
            let _ = io::stdin().read_to_string(&mut input);
            shell.run_script(&input);
        }
    }
    shell.save();
    std::process::exit(shell.exit_code);
}

fn die_unknown_arg(msg: &str) -> ! {
    eprintln!("./executable: Error: {}", msg);
    std::process::exit(1);
}

fn looks_like_sql_or_dot(s: &str) -> bool {
    let t = s.trim_start().to_lowercase();
    t.starts_with('.') || ["select", "create", "insert", "update", "delete", "drop", "pragma", "with", "begin", "commit"]
        .iter().any(|k| t.starts_with(k))
}

fn load_db(path: Option<&str>) -> Database {
    let Some(path) = path else { return Database::default(); };
    if path == ":memory:" || !Path::new(path).exists() {
        return Database::default();
    }
    let data = fs::read_to_string(path).unwrap_or_default();
    serde_json::from_str(&data).unwrap_or_default()
}

impl Shell {
    fn save(&mut self) {
        if let Some(p) = &self.db_path {
            if let Ok(s) = serde_json::to_string(&self.db) {
                let _ = fs::write(p, s);
            }
        }
    }

    fn run_script(&mut self, script: &str) {
        let mut pending = String::new();
        for line in script.lines() {
            let trimmed = line.trim();
            if trimmed.starts_with('.') && pending.trim().is_empty() {
                if self.echo { let _ = writeln!(self.output, "{}", line); }
                self.dot_command(trimmed);
                if self.bail && self.exit_code != 0 { return; }
            } else {
                pending.push_str(line);
                pending.push('\n');
                if has_complete_statement(&pending) {
                    for stmt in split_statements(&pending) {
                        let s = stmt.trim();
                        if s.is_empty() { continue; }
                        if self.echo { let _ = writeln!(self.output, "{}", s); }
                        if let Err(e) = self.exec_sql(s) {
                            eprintln!("Parse error: {}", e);
                            self.exit_code = 1;
                        }
                        if self.bail && self.exit_code != 0 { return; }
                    }
                    pending.clear();
                }
            }
        }
        for stmt in split_statements(&pending) {
            let s = stmt.trim();
            if s.is_empty() { continue; }
            if self.echo { let _ = writeln!(self.output, "{}", s); }
            if s.starts_with('.') {
                self.dot_command(s);
            } else if let Err(e) = self.exec_sql(s) {
                eprintln!("Parse error: {}", e);
                self.exit_code = 1;
            }
            if self.bail && self.exit_code != 0 { return; }
        }
    }

    fn dot_command(&mut self, line: &str) {
        let parts = shell_words(line);
        if parts.is_empty() { return; }
        match parts[0].as_str() {
            ".help" => print_dot_help(),
            ".quit" | ".exit" => {
                if parts.len() > 1 { self.exit_code = parts[1].parse().unwrap_or(0); }
            }
            ".print" => {
                let text = line.trim_start_matches(".print").trim_start();
                let _ = writeln!(self.output, "{}", text);
            }
            ".headers" | ".header" => {
                if parts.len() == 1 { let _ = writeln!(self.output, "{}", if self.headers {"on"} else {"off"}); }
                else { self.headers = parse_onoff(&parts[1]); }
            }
            ".mode" => {
                if parts.len() == 1 { let _ = writeln!(self.output, "current output mode: {}", mode_name(self.mode)); }
                else { self.set_mode(&parts[1]); }
            }
            ".separator" => {
                if parts.len() > 1 { self.col_sep = unescape_arg(&parts[1]); }
                if parts.len() > 2 { self.row_sep = unescape_arg(&parts[2]); }
            }
            ".nullvalue" => {
                self.null_value = parts.get(1).cloned().unwrap_or_default();
            }
            ".tables" => {
                let names: Vec<_> = self.db.tables.keys().cloned().collect();
                if !names.is_empty() { let _ = writeln!(self.output, "{}", names.join(" ")); }
            }
            ".schema" => {
                for t in self.db.tables.values() {
                    let _ = writeln!(self.output, "{}", t.create_sql);
                }
            }
            ".dump" => self.dump(),
            ".read" => {
                if let Some(path) = parts.get(1) {
                    match fs::read_to_string(path) {
                        Ok(s) => self.run_script(&s),
                        Err(e) => {
                            eprintln!("Error: cannot open \"{}\": {}", path, e);
                            self.exit_code = 1;
                        }
                    }
                }
            }
            ".output" | ".once" => {
                if parts.len() == 1 || parts[1] == "stdout" {
                    self.output = Box::new(io::stdout());
                } else if let Ok(f) = fs::File::create(&parts[1]) {
                    self.output = Box::new(f);
                }
            }
            ".open" => {
                if let Some(p) = parts.last() {
                    self.save();
                    self.db_path = if p == ":memory:" { None } else { Some(p.clone()) };
                    self.db = load_db(Some(p));
                }
            }
            ".version" => {
                let _ = writeln!(self.output, "SQLite {}", VERSION);
                let _ = writeln!(self.output, "zlib version 1.2.11");
                let _ = writeln!(self.output, "gcc-11.4.0");
            }
            ".databases" => {
                let file = self.db_path.clone().unwrap_or_default();
                let _ = writeln!(self.output, "main: {} r/w", file);
            }
            ".bail" => if parts.len() > 1 { self.bail = parse_onoff(&parts[1]); },
            ".echo" => if parts.len() > 1 { self.echo = parse_onoff(&parts[1]); },
            ".changes" | ".timer" | ".stats" | ".eqp" | ".explain" | ".timeout" | ".limit" => {}
            other => {
                eprintln!("Error: unknown command or invalid arguments: \"{}\". Enter \".help\" for help", other);
                self.exit_code = 1;
            }
        }
    }

    fn set_mode(&mut self, m: &str) {
        match m.to_lowercase().as_str() {
            "list" => self.mode = Mode::List,
            "csv" => self.mode = Mode::Csv,
            "tabs" => { self.mode = Mode::List; self.col_sep = "\t".to_string(); }
            "column" => self.mode = Mode::Column,
            "line" => self.mode = Mode::Line,
            "json" => self.mode = Mode::Json,
            "quote" => self.mode = Mode::Quote,
            "html" => self.mode = Mode::Html,
            "insert" => self.mode = Mode::Insert,
            "markdown" => self.mode = Mode::Markdown,
            "table" => self.mode = Mode::Table,
            "box" => self.mode = Mode::Box,
            _ => eprintln!("Error: mode should be one of: ascii box column csv html insert json line list markdown quote table tabs tcl"),
        }
    }

    fn exec_sql(&mut self, sql: &str) -> Result<(), String> {
        let s = sql.trim().trim_end_matches(';').trim();
        let low = s.to_lowercase();
        if low.starts_with("create table") { self.create_table(s) }
        else if low.starts_with("insert into") { self.insert_into(s) }
        else if low.starts_with("select") || low.starts_with("with") { self.select(s).map(|r| self.print_query(&r)) }
        else if low.starts_with("drop table") { self.drop_table(s) }
        else if low.starts_with("delete from") { self.delete_from(s) }
        else if low.starts_with("update") { self.update_table(s) }
        else if low.starts_with("pragma") { self.pragma(s) }
        else if low == "begin" || low == "commit" || low == "rollback" || low.starts_with("vacuum") { Ok(()) }
        else { Err(format!("near \"{}\": syntax error", first_word(s))) }
    }

    fn create_table(&mut self, s: &str) -> Result<(), String> {
        let re = Regex::new(r"(?is)^create\s+table\s+(?:if\s+not\s+exists\s+)?([A-Za-z_][\w]*)\s*\((.*)\)$").unwrap();
        let caps = re.captures(s).ok_or_else(|| "near \"create\": syntax error".to_string())?;
        let name = caps[1].to_string();
        let defs = split_top_level(&caps[2], ',');
        let mut cols = Vec::new();
        let mut types = Vec::new();
        for d in defs {
            let p = shell_words(&d);
            if p.is_empty() { continue; }
            let c = unquote_ident(&p[0]);
            let cl = c.to_lowercase();
            if ["primary", "foreign", "unique", "check", "constraint"].contains(&cl.as_str()) { continue; }
            cols.push(c);
            types.push(p.get(1).cloned().unwrap_or_default());
        }
        let create_sql = format!("CREATE TABLE {}({});", name, caps[2].trim());
        self.db.tables.entry(name).or_insert(Table { columns: cols, types, create_sql, rows: Vec::new() });
        Ok(())
    }

    fn insert_into(&mut self, s: &str) -> Result<(), String> {
        let re = Regex::new(r"(?is)^insert\s+into\s+([A-Za-z_][\w]*)(?:\s*\((.*?)\))?\s+values\s*(.*)$").unwrap();
        let caps = re.captures(s).ok_or_else(|| "near \"insert\": syntax error".to_string())?;
        let name = caps[1].to_string();
        let table = self.db.tables.get_mut(&name).ok_or_else(|| format!("no such table: {}", name))?;
        let target_cols: Vec<String> = caps.get(2).map(|m| split_top_level(m.as_str(), ',').into_iter().map(|x| unquote_ident(x.trim())).collect()).unwrap_or_else(|| table.columns.clone());
        let groups = parse_value_groups(caps.get(3).unwrap().as_str())?;
        for g in groups {
            let vals = split_top_level(&g, ',').into_iter().map(|x| eval_expr(&x, None, table).unwrap_or(Value::Null)).collect::<Vec<_>>();
            let mut row = vec![Value::Null; table.columns.len()];
            for (idx, col) in target_cols.iter().enumerate() {
                if let Some(pos) = table.columns.iter().position(|c| c.eq_ignore_ascii_case(col)) {
                    row[pos] = vals.get(idx).cloned().unwrap_or(Value::Null);
                }
            }
            table.rows.push(row);
        }
        Ok(())
    }

    fn drop_table(&mut self, s: &str) -> Result<(), String> {
        let name = s.split_whitespace().last().ok_or("near \"drop\": syntax error")?.trim_matches(';');
        self.db.tables.remove(&unquote_ident(name));
        Ok(())
    }

    fn delete_from(&mut self, s: &str) -> Result<(), String> {
        let re = Regex::new(r"(?is)^delete\s+from\s+([A-Za-z_][\w]*)(?:\s+where\s+(.*))?$").unwrap();
        let caps = re.captures(s).ok_or_else(|| "near \"delete\": syntax error".to_string())?;
        let name = caps[1].to_string();
        let table = self.db.tables.get_mut(&name).ok_or_else(|| format!("no such table: {}", name))?;
        if let Some(w) = caps.get(2) {
            let where_s = w.as_str().to_string();
            let columns = table.columns.clone();
            let dummy = Table { columns, types: vec![], create_sql: String::new(), rows: vec![] };
            table.rows.retain(|r| !eval_condition(&where_s, r, &dummy));
        } else {
            table.rows.clear();
        }
        Ok(())
    }

    fn update_table(&mut self, s: &str) -> Result<(), String> {
        let re = Regex::new(r"(?is)^update\s+([A-Za-z_][\w]*)\s+set\s+(.*?)(?:\s+where\s+(.*))?$").unwrap();
        let caps = re.captures(s).ok_or_else(|| "near \"update\": syntax error".to_string())?;
        let name = caps[1].to_string();
        let table = self.db.tables.get_mut(&name).ok_or_else(|| format!("no such table: {}", name))?;
        let assigns = split_top_level(&caps[2], ',');
        let where_s = caps.get(3).map(|m| m.as_str().to_string());
        let clone_table = Table { columns: table.columns.clone(), types: vec![], create_sql: String::new(), rows: vec![] };
        for row in &mut table.rows {
            if where_s.as_ref().map(|w| eval_condition(w, row, &clone_table)).unwrap_or(true) {
                for a in &assigns {
                    if let Some((c, e)) = a.split_once('=') {
                        if let Some(pos) = table.columns.iter().position(|x| x.eq_ignore_ascii_case(c.trim())) {
                            row[pos] = eval_expr(e, Some(row), &clone_table).unwrap_or(Value::Null);
                        }
                    }
                }
            }
        }
        Ok(())
    }

    fn pragma(&mut self, s: &str) -> Result<(), String> {
        let low = s.to_lowercase();
        if low.contains("table_info") {
            let name = s.split(['(', ')']).nth(1).unwrap_or("").trim_matches('\'').trim_matches('"');
            if let Some(t) = self.db.tables.get(name) {
                let rows = t.columns.iter().enumerate().map(|(i, c)| vec![
                    Value::Int(i as i64), Value::Text(c.clone()), Value::Text(t.types.get(i).cloned().unwrap_or_default()),
                    Value::Int(0), Value::Null, Value::Int(0)
                ]).collect();
                self.print_query(&QueryResult { headers: vec!["cid".into(),"name".into(),"type".into(),"notnull".into(),"dflt_value".into(),"pk".into()], rows });
            }
        }
        Ok(())
    }

    fn select(&self, s: &str) -> Result<QueryResult, String> {
        let (select_part, rest) = split_select_from(s)?;
        let exprs = split_top_level(select_part, ',');
        let mut table_opt: Option<&Table> = None;
        let mut source_rows: Vec<Vec<Value>> = vec![Vec::new()];
        let mut where_clause = None::<String>;
        let mut order_by = None::<String>;
        let mut limit = None::<usize>;
        if let Some(r) = rest {
            let (table_name, rem) = take_word(r.trim());
            let table = self.db.tables.get(&unquote_ident(table_name)).ok_or_else(|| format!("no such table: {}", table_name))?;
            table_opt = Some(table);
            source_rows = table.rows.clone();
            let mut rems = rem.trim().to_string();
            if let Some(idx) = find_keyword_top(&rems, "where") {
                let after = rems[idx + 5..].trim().to_string();
                rems = rems[..idx].trim().to_string();
                let end = find_keyword_top(&after, "order by").or_else(|| find_keyword_top(&after, "limit")).unwrap_or(after.len());
                where_clause = Some(after[..end].trim().to_string());
                rems.push(' ');
                rems.push_str(after[end..].trim());
            }
            if let Some(idx) = find_keyword_top(&rems, "order by") {
                let after = rems[idx + 8..].trim().to_string();
                let end = find_keyword_top(&after, "limit").unwrap_or(after.len());
                order_by = Some(after[..end].trim().to_string());
                rems = after[end..].trim().to_string();
            }
            if let Some(idx) = find_keyword_top(&rems, "limit") {
                limit = rems[idx + 5..].trim().parse().ok();
            }
            if let Some(w) = &where_clause {
                source_rows.retain(|row| eval_condition(w, row, table));
            }
            if let Some(ob) = &order_by {
                let desc = ob.to_lowercase().ends_with(" desc");
                let col = ob.split_whitespace().next().unwrap_or("");
                if let Some(pos) = table.columns.iter().position(|c| c.eq_ignore_ascii_case(col)) {
                    source_rows.sort_by(|a, b| cmp_value(&a[pos], &b[pos]));
                    if desc { source_rows.reverse(); }
                }
            }
        }
        if let Some(n) = limit { source_rows.truncate(n); }
        let table = table_opt.cloned().unwrap_or(Table { columns: Vec::new(), types: Vec::new(), create_sql: String::new(), rows: Vec::new() });
        if exprs.len() == 1 && exprs[0].trim() == "*" {
            return Ok(QueryResult { headers: table.columns.clone(), rows: source_rows });
        }
        if exprs.iter().any(|e| is_aggregate(e)) {
            let mut headers = Vec::new();
            let mut row = Vec::new();
            for e in exprs {
                let (expr, alias) = split_alias(&e);
                headers.push(alias.unwrap_or_else(|| expr.trim().to_string()));
                row.push(eval_aggregate(expr.trim(), &source_rows, &table));
            }
            return Ok(QueryResult { headers, rows: vec![row] });
        }
        let mut headers = Vec::new();
        let parsed: Vec<_> = exprs.iter().map(|e| {
            let (expr, alias) = split_alias(e);
            headers.push(alias.unwrap_or_else(|| default_header(expr.trim())));
            expr.trim().to_string()
        }).collect();
        let rows = source_rows.iter().map(|r| parsed.iter().map(|e| eval_expr(e, Some(r), &table).unwrap_or(Value::Null)).collect()).collect();
        Ok(QueryResult { headers, rows })
    }

    fn print_query(&mut self, q: &QueryResult) {
        match self.mode {
            Mode::Json => self.print_json(q),
            Mode::Line => self.print_line(q),
            Mode::Column => self.print_column(q, false),
            Mode::Table | Mode::Box => self.print_column(q, true),
            Mode::Markdown => self.print_markdown(q),
            Mode::Csv => self.print_sep(q, ",", true),
            Mode::Quote => self.print_quote(q),
            Mode::Html => self.print_html(q),
            Mode::List | Mode::Tabs | Mode::Insert => self.print_sep(q, &self.col_sep.clone(), false),
        }
    }

    fn val(&self, v: &Value) -> String {
        match v {
            Value::Null => self.null_value.clone(),
            Value::Int(i) => i.to_string(),
            Value::Float(f) => fmt_float(*f),
            Value::Text(s) => s.clone(),
        }
    }
    fn print_sep(&mut self, q: &QueryResult, sep: &str, csv: bool) {
        if self.headers {
            let line = q.headers.iter().map(|h| if csv { csv_escape(h) } else { h.clone() }).collect::<Vec<_>>().join(sep);
            let _ = write!(self.output, "{}{}", line, self.row_sep);
        }
        for r in &q.rows {
            let line = r.iter().map(|v| if csv { csv_escape(&self.val(v)) } else { self.val(v) }).collect::<Vec<_>>().join(sep);
            let _ = write!(self.output, "{}{}", line, self.row_sep);
        }
    }
    fn print_quote(&mut self, q: &QueryResult) {
        if self.headers {
            let _ = writeln!(self.output, "{}", q.headers.iter().map(|h| quote_sql(&Value::Text(h.clone()))).collect::<Vec<_>>().join(","));
        }
        for r in &q.rows {
            let _ = writeln!(self.output, "{}", r.iter().map(quote_sql).collect::<Vec<_>>().join(","));
        }
    }
    fn print_json(&mut self, q: &QueryResult) {
        let arr: Vec<_> = q.rows.iter().map(|r| {
            let mut m = serde_json::Map::new();
            for (i, v) in r.iter().enumerate() {
                m.insert(q.headers.get(i).cloned().unwrap_or_default(), to_json(v));
            }
            serde_json::Value::Object(m)
        }).collect();
        let _ = writeln!(self.output, "{}", serde_json::Value::Array(arr));
    }
    fn print_line(&mut self, q: &QueryResult) {
        for (ri, r) in q.rows.iter().enumerate() {
            if ri > 0 { let _ = writeln!(self.output); }
            for (i, v) in r.iter().enumerate() {
                let _ = writeln!(self.output, "{:>12} = {}", q.headers.get(i).unwrap_or(&String::new()), self.val(v));
            }
        }
    }
    fn print_column(&mut self, q: &QueryResult, bordered: bool) {
        let widths: Vec<usize> = q.headers.iter().enumerate().map(|(i, h)| {
            let mut w = h.len();
            for r in &q.rows { w = w.max(self.val(r.get(i).unwrap_or(&Value::Null)).len()); }
            w
        }).collect();
        if bordered {
            self.print_border(&widths);
        }
        if self.headers {
            let line = q.headers.iter().enumerate().map(|(i, h)| format!("{:<width$}", h, width=widths[i])).collect::<Vec<_>>().join(if bordered {" | "} else {"  "});
            if bordered { let _ = writeln!(self.output, "| {} |", line); self.print_border(&widths); }
            else { let _ = writeln!(self.output, "{}", line); let _ = writeln!(self.output, "{}", widths.iter().map(|w| "-".repeat(*w)).collect::<Vec<_>>().join("  ")); }
        }
        for r in &q.rows {
            let line = r.iter().enumerate().map(|(i, v)| format!("{:<width$}", self.val(v), width=widths[i])).collect::<Vec<_>>().join(if bordered {" | "} else {"  "});
            if bordered { let _ = writeln!(self.output, "| {} |", line); } else { let _ = writeln!(self.output, "{}", line); }
        }
        if bordered { self.print_border(&widths); }
    }
    fn print_border(&mut self, widths: &[usize]) {
        let mid = widths.iter().map(|w| "-".repeat(*w + 2)).collect::<Vec<_>>().join("+");
        let _ = writeln!(self.output, "+{}+", mid);
    }
    fn print_markdown(&mut self, q: &QueryResult) {
        let _ = writeln!(self.output, "| {} |", q.headers.join(" | "));
        let _ = writeln!(self.output, "|{}|", q.headers.iter().map(|_| "---").collect::<Vec<_>>().join("|"));
        for r in &q.rows { let _ = writeln!(self.output, "| {} |", r.iter().map(|v| self.val(v)).collect::<Vec<_>>().join(" | ")); }
    }
    fn print_html(&mut self, q: &QueryResult) {
        for r in &q.rows {
            let _ = writeln!(self.output, "<TR>{}</TR>", r.iter().map(|v| format!("<TD>{}</TD>", html_escape(&self.val(v)))).collect::<Vec<_>>().join(""));
        }
    }
    fn dump(&mut self) {
        let _ = writeln!(self.output, "PRAGMA foreign_keys=OFF;");
        let _ = writeln!(self.output, "BEGIN TRANSACTION;");
        for (name, t) in self.db.tables.clone() {
            let _ = writeln!(self.output, "{}", t.create_sql);
            for r in t.rows {
                let vals = r.iter().map(quote_sql).collect::<Vec<_>>().join(",");
                let _ = writeln!(self.output, "INSERT INTO {} VALUES({});", name, vals);
            }
        }
        let _ = writeln!(self.output, "COMMIT;");
    }
}

fn has_complete_statement(s: &str) -> bool {
    let mut quote = None;
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if let Some(q) = quote {
            if c == q {
                if chars.peek() == Some(&q) { let _ = chars.next(); } else { quote = None; }
            }
        } else if c == '\'' || c == '"' {
            quote = Some(c);
        } else if c == ';' {
            return true;
        }
    }
    false
}

fn split_statements(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut quote = None;
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        cur.push(c);
        if let Some(q) = quote {
            if c == q {
                if chars.peek() == Some(&q) { cur.push(chars.next().unwrap()); } else { quote = None; }
            }
        } else if c == '\'' || c == '"' {
            quote = Some(c);
        } else if c == ';' {
            out.push(cur.clone());
            cur.clear();
        }
    }
    if !cur.trim().is_empty() { out.push(cur); }
    out
}

fn split_top_level(s: &str, delim: char) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut depth = 0;
    let mut quote = None;
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if let Some(q) = quote {
            cur.push(c);
            if c == q {
                if chars.peek() == Some(&q) { cur.push(chars.next().unwrap()); } else { quote = None; }
            }
            continue;
        }
        match c {
            '\'' | '"' => { quote = Some(c); cur.push(c); }
            '(' => { depth += 1; cur.push(c); }
            ')' => { if depth > 0 { depth -= 1; } cur.push(c); }
            _ if c == delim && depth == 0 => { out.push(cur.trim().to_string()); cur.clear(); }
            _ => cur.push(c),
        }
    }
    if !cur.trim().is_empty() { out.push(cur.trim().to_string()); }
    out
}

fn parse_value_groups(s: &str) -> Result<Vec<String>, String> {
    let mut groups = Vec::new();
    let mut cur = String::new();
    let mut depth = 0;
    let mut quote = None;
    for c in s.chars() {
        if let Some(q) = quote {
            cur.push(c);
            if c == q { quote = None; }
        } else {
            match c {
                '\'' | '"' => { quote = Some(c); cur.push(c); }
                '(' => { if depth > 0 { cur.push(c); } depth += 1; }
                ')' => {
                    depth -= 1;
                    if depth == 0 { groups.push(cur.trim().to_string()); cur.clear(); } else { cur.push(c); }
                }
                _ => if depth > 0 { cur.push(c); },
            }
        }
    }
    if groups.is_empty() { Err("near \"values\": syntax error".into()) } else { Ok(groups) }
}

fn split_select_from(s: &str) -> Result<(&str, Option<&str>), String> {
    let body = s.trim().strip_prefix(|c: char| c.eq_ignore_ascii_case(&'s')).and_then(|_| {
        if s.len() >= 6 && s[..6].eq_ignore_ascii_case("select") { Some(s[6..].trim()) } else { None }
    }).ok_or_else(|| "near \"select\": syntax error".to_string())?;
    if let Some(idx) = find_keyword_top(body, "from") {
        Ok((body[..idx].trim(), Some(body[idx+4..].trim())))
    } else {
        Ok((body.trim(), None))
    }
}

fn find_keyword_top(s: &str, kw: &str) -> Option<usize> {
    let sl = s.to_lowercase();
    let bytes = sl.as_bytes();
    let kwb = kw.as_bytes();
    let mut depth = 0;
    let mut quote = None;
    let chars: Vec<(usize, char)> = sl.char_indices().collect();
    for (idx, c) in chars {
        if let Some(q) = quote {
            if c == q { quote = None; }
            continue;
        }
        match c {
            '\'' | '"' => quote = Some(c),
            '(' => depth += 1,
            ')' => if depth > 0 { depth -= 1; },
            _ => {
                if depth == 0 && idx + kwb.len() <= bytes.len() && &bytes[idx..idx+kwb.len()] == kwb {
                    let before = idx == 0 || !bytes[idx-1].is_ascii_alphanumeric();
                    let after = idx + kwb.len() == bytes.len() || !bytes[idx+kwb.len()].is_ascii_alphanumeric();
                    if before && after { return Some(idx); }
                }
            }
        }
    }
    None
}

fn eval_expr(expr: &str, row: Option<&Vec<Value>>, table: &Table) -> Result<Value, String> {
    let e = expr.trim();
    if e.is_empty() { return Ok(Value::Null); }
    let el = e.to_lowercase();
    if el == "null" { return Ok(Value::Null); }
    if el == "true" { return Ok(Value::Int(1)); }
    if el == "false" { return Ok(Value::Int(0)); }
    if el == "sqlite_version()" { return Ok(Value::Text("3.54.0".into())); }
    if (e.starts_with('\'') && e.ends_with('\'')) || (e.starts_with('"') && e.ends_with('"')) {
        return Ok(Value::Text(unquote_string(e)));
    }
    if let Ok(i) = e.parse::<i64>() { return Ok(Value::Int(i)); }
    if let Ok(f) = e.parse::<f64>() { return Ok(Value::Float(f)); }
    if let Some(pos) = find_op(e, '+') { return numeric_bin(&eval_expr(&e[..pos], row, table)?, &eval_expr(&e[pos+1..], row, table)?, '+'); }
    if let Some(pos) = find_op(e, '-') { if pos > 0 { return numeric_bin(&eval_expr(&e[..pos], row, table)?, &eval_expr(&e[pos+1..], row, table)?, '-'); } }
    if let Some(pos) = find_op(e, '*') { return numeric_bin(&eval_expr(&e[..pos], row, table)?, &eval_expr(&e[pos+1..], row, table)?, '*'); }
    if let Some(pos) = find_op(e, '/') { return numeric_bin(&eval_expr(&e[..pos], row, table)?, &eval_expr(&e[pos+1..], row, table)?, '/'); }
    if el.starts_with("upper(") && e.ends_with(')') { return Ok(Value::Text(value_to_string(&eval_expr(&e[6..e.len()-1], row, table)?).to_uppercase())); }
    if el.starts_with("lower(") && e.ends_with(')') { return Ok(Value::Text(value_to_string(&eval_expr(&e[6..e.len()-1], row, table)?).to_lowercase())); }
    if el.starts_with("length(") && e.ends_with(')') { return Ok(Value::Int(value_to_string(&eval_expr(&e[7..e.len()-1], row, table)?).chars().count() as i64)); }
    if let Some(r) = row {
        let col = e.split('.').last().unwrap_or(e);
        if let Some(pos) = table.columns.iter().position(|c| c.eq_ignore_ascii_case(col)) {
            return Ok(r.get(pos).cloned().unwrap_or(Value::Null));
        }
    }
    Err(format!("no such column: {}", e))
}

fn find_op(e: &str, op: char) -> Option<usize> {
    let mut depth = 0;
    let mut quote = None;
    for (idx, c) in e.char_indices().rev() {
        if let Some(q) = quote {
            if c == q { quote = None; }
            continue;
        }
        match c {
            '\'' | '"' => quote = Some(c),
            ')' => depth += 1,
            '(' => if depth > 0 { depth -= 1; },
            _ if c == op && depth == 0 => return Some(idx),
            _ => {}
        }
    }
    None
}

fn numeric_bin(a: &Value, b: &Value, op: char) -> Result<Value, String> {
    let af = to_f64(a);
    let bf = to_f64(b);
    let res = match op { '+' => af + bf, '-' => af - bf, '*' => af * bf, '/' => af / bf, _ => 0.0 };
    if matches!(op, '+'|'-'|'*') && (res.fract().abs() < 1e-12) { Ok(Value::Int(res as i64)) } else { Ok(Value::Float(res)) }
}

fn eval_condition(cond: &str, row: &Vec<Value>, table: &Table) -> bool {
    for op in ["!=", "<>", ">=", "<=", "=", ">", "<"] {
        if let Some(pos) = cond.find(op) {
            let a = eval_expr(&cond[..pos], Some(row), table).unwrap_or(Value::Null);
            let b = eval_expr(&cond[pos+op.len()..], Some(row), table).unwrap_or(Value::Null);
            let ord = cmp_value(&a, &b);
            return match op { "=" => a == b, "!=" | "<>" => a != b, ">" => ord == Ordering::Greater, "<" => ord == Ordering::Less, ">=" => ord != Ordering::Less, "<=" => ord != Ordering::Greater, _ => false };
        }
    }
    !matches!(eval_expr(cond, Some(row), table).unwrap_or(Value::Null), Value::Null | Value::Int(0))
}

fn is_aggregate(e: &str) -> bool {
    let l = e.to_lowercase();
    ["count(", "sum(", "avg(", "min(", "max("].iter().any(|p| l.trim_start().starts_with(p))
}

fn eval_aggregate(expr: &str, rows: &[Vec<Value>], table: &Table) -> Value {
    let l = expr.to_lowercase();
    let arg = expr.split_once('(').and_then(|(_, r)| r.rsplit_once(')').map(|x| x.0)).unwrap_or("*").trim();
    if l.starts_with("count(") {
        if arg == "*" { return Value::Int(rows.len() as i64); }
        return Value::Int(rows.iter().filter(|r| !matches!(eval_expr(arg, Some(r), table).unwrap_or(Value::Null), Value::Null)).count() as i64);
    }
    let vals: Vec<Value> = rows.iter().map(|r| eval_expr(arg, Some(r), table).unwrap_or(Value::Null)).filter(|v| !matches!(v, Value::Null)).collect();
    if vals.is_empty() { return Value::Null; }
    if l.starts_with("sum(") { return float_or_int(vals.iter().map(to_f64).sum()); }
    if l.starts_with("avg(") { return Value::Float(vals.iter().map(to_f64).sum::<f64>() / vals.len() as f64); }
    if l.starts_with("min(") { return vals.into_iter().min_by(cmp_value).unwrap_or(Value::Null); }
    if l.starts_with("max(") { return vals.into_iter().max_by(cmp_value).unwrap_or(Value::Null); }
    Value::Null
}

fn split_alias(e: &str) -> (&str, Option<String>) {
    if let Some(idx) = find_keyword_top(e, "as") {
        return (e[..idx].trim(), Some(unquote_ident(e[idx+2..].trim())));
    }
    (e, None)
}

fn default_header(e: &str) -> String { e.to_string() }
fn first_word(s: &str) -> &str { s.split_whitespace().next().unwrap_or(s) }
fn take_word(s: &str) -> (&str, &str) {
    let mut it = s.splitn(2, char::is_whitespace);
    let w = it.next().unwrap_or("");
    let r = it.next().unwrap_or("");
    (w, r)
}

fn shell_words(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut cur = String::new();
    let mut quote = None;
    for c in s.chars() {
        if let Some(q) = quote {
            if c == q { quote = None; } else { cur.push(c); }
        } else if c == '\'' || c == '"' {
            quote = Some(c);
        } else if c.is_whitespace() {
            if !cur.is_empty() { out.push(cur.clone()); cur.clear(); }
        } else { cur.push(c); }
    }
    if !cur.is_empty() { out.push(cur); }
    out
}

fn unquote_ident(s: &str) -> String { s.trim().trim_matches('"').trim_matches('`').trim_matches('[').trim_matches(']').to_string() }
fn unquote_string(s: &str) -> String {
    let inner = &s[1..s.len()-1];
    inner.replace("''", "'").replace("\"\"", "\"")
}
fn unescape_arg(s: &str) -> String {
    s.replace("\\n", "\n").replace("\\t", "\t").replace("\\r", "\r")
}
fn parse_onoff(s: &str) -> bool { matches!(s.to_lowercase().as_str(), "on" | "yes" | "true" | "1") }
fn mode_name(m: Mode) -> &'static str {
    match m { Mode::List => "list", Mode::Csv => "csv", Mode::Tabs => "tabs", Mode::Column => "column", Mode::Line => "line", Mode::Json => "json", Mode::Quote => "quote", Mode::Html => "html", Mode::Insert => "insert", Mode::Markdown => "markdown", Mode::Table => "table", Mode::Box => "box" }
}
fn to_f64(v: &Value) -> f64 {
    match v { Value::Int(i) => *i as f64, Value::Float(f) => *f, Value::Text(s) => s.parse().unwrap_or(0.0), Value::Null => 0.0 }
}
fn float_or_int(f: f64) -> Value { if f.fract().abs() < 1e-12 { Value::Int(f as i64) } else { Value::Float(f) } }
fn fmt_float(f: f64) -> String {
    let mut s = format!("{}", f);
    if s.contains('.') { while s.ends_with('0') { s.pop(); } if s.ends_with('.') { s.push('0'); } }
    s
}
fn value_to_string(v: &Value) -> String { match v { Value::Null => String::new(), Value::Int(i) => i.to_string(), Value::Float(f) => fmt_float(*f), Value::Text(s) => s.clone() } }
fn cmp_value(a: &Value, b: &Value) -> Ordering {
    match (a, b) {
        (Value::Int(_)|Value::Float(_), Value::Int(_)|Value::Float(_)) => to_f64(a).partial_cmp(&to_f64(b)).unwrap_or(Ordering::Equal),
        _ => value_to_string(a).cmp(&value_to_string(b)),
    }
}
fn quote_sql(v: &Value) -> String {
    match v {
        Value::Null => "NULL".into(),
        Value::Int(i) => i.to_string(),
        Value::Float(f) => fmt_float(*f),
        Value::Text(s) => format!("'{}'", s.replace('\'', "''")),
    }
}
fn csv_escape(s: &str) -> String {
    if s.contains([',', '"', '\n', '\r']) { format!("\"{}\"", s.replace('"', "\"\"")) } else { s.to_string() }
}
fn html_escape(s: &str) -> String { s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;") }
fn to_json(v: &Value) -> serde_json::Value {
    match v { Value::Null => serde_json::Value::Null, Value::Int(i) => (*i).into(), Value::Float(f) => serde_json::json!(f), Value::Text(s) => s.clone().into() }
}

fn print_help() {
    println!("Usage: ./executable [OPTIONS] [FILENAME [SQL...]]");
    println!("FILENAME is the name of an SQLite database. A new database is created");
    println!("if the file does not previously exist. Defaults to :memory:.");
    println!("OPTIONS include:");
    println!("   --                   treat no subsequent arguments as options");
    println!("   -cmd COMMAND         run \"COMMAND\" before reading stdin");
    println!("   -[no]header          turn headers on or off");
    println!("   -csv|-list|-column|-line|-json|-quote|-html|-table|-box");
    println!("                        set output mode");
    println!("   -separator SEP       set output column separator. Default: '|'");
    println!("   -nullvalue TEXT      set text string for NULL values. Default ''");
    println!("   -version             show SQLite version");
    println!("   -help                show this message");
}

fn print_dot_help() {
    println!(".backup ?DB? FILE        Backup DB (default \"main\") to FILE");
    println!(".bail on|off             Stop after hitting an error.  Default OFF");
    println!(".databases               List names and files of attached databases");
    println!(".dump ?OBJECTS?          Render database content as SQL");
    println!(".echo on|off             Turn command echo on or off");
    println!(".exit ?CODE?             Exit this program with return-code CODE");
    println!(".headers on|off          Turn display of headers on or off");
    println!(".help ?-all? ?PATTERN?   Show help text for PATTERN");
    println!(".mode ?MODE? ?OPTIONS?   Set output mode");
    println!(".nullvalue STRING        Use STRING in place of NULL values");
    println!(".once ?OPTIONS? ?FILE?   Output for the next SQL command only to FILE");
    println!(".open ?OPTIONS? ?FILE?   Close existing database and reopen FILE");
    println!(".output ?FILE?           Send output to FILE or stdout if FILE is omitted");
    println!(".print STRING...         Print literal STRING");
    println!(".quit                    Stop interpreting input stream, exit if primary.");
    println!(".read FILE               Read input from FILE");
    println!(".schema ?PATTERN?        Show the CREATE statements matching PATTERN");
    println!(".separator COL ?ROW?     Change the column and row separators");
    println!(".tables ?TABLE?          List names of tables matching LIKE pattern TABLE");
    println!(".version                 Show source, library and compiler versions");
}
