use regex::Regex;
use serde::Deserialize;
use std::ffi::OsStr;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::{Command as ProcCommand, Stdio};

const VERSION: &str = "mdbook v0.5.0-alpha.1";

#[derive(Debug, Default, Deserialize)]
struct Config {
    #[serde(default)]
    book: BookConfig,
    #[serde(default)]
    build: BuildConfig,
}

#[derive(Debug, Default, Deserialize)]
struct BookConfig {
    title: Option<String>,
    description: Option<String>,
    language: Option<String>,
    src: Option<String>,
}

#[derive(Debug, Default, Deserialize)]
struct BuildConfig {
    #[serde(rename = "build-dir")]
    build_dir: Option<String>,
}

#[derive(Debug, Clone)]
struct Chapter {
    title: String,
    path: Option<String>,
    level: usize,
    number: Option<String>,
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.is_empty() || args[0] == "--help" || args[0] == "-h" {
        print_main_help();
        return;
    }
    if args[0] == "--version" || args[0] == "-V" {
        println!("{VERSION}");
        return;
    }
    if args[0] == "help" {
        if args.len() > 1 { print_sub_help(&args[1]); } else { print_main_help(); }
        return;
    }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_sub_help(&args[0]);
        return;
    }
    if args.iter().any(|a| a == "--version" || a == "-V") {
        println!("{VERSION}");
        return;
    }
    let result = match args[0].as_str() {
        "init" => cmd_init(&args[1..]),
        "build" => cmd_build(&args[1..]),
        "clean" => cmd_clean(&args[1..]),
        "test" => cmd_test(&args[1..]),
        "completions" => cmd_completions(&args[1..]),
        "watch" => cmd_watch(&args[1..]),
        "serve" => cmd_serve(&args[1..]),
        other => Err(format!("error: unrecognized command '{other}'")),
    };
    if let Err(e) = result {
        eprintln!("{e}");
        std::process::exit(101);
    }
}

#[derive(Default)]
struct Opts {
    dir: Option<String>,
    dest_dir: Option<String>,
    title: Option<String>,
    ignore: Option<String>,
    chapter: Option<String>,
    library_path: Option<String>,
    hostname: Option<String>,
    port: Option<String>,
    theme: bool,
    open: bool,
}

fn parse_opts(args: &[String]) -> Opts {
    let mut opts = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let take_value = |slot: &mut Option<String>, i: &mut usize| {
            if let Some((_, v)) = a.split_once('=') {
                *slot = Some(v.to_string());
            } else if *i + 1 < args.len() {
                *i += 1;
                *slot = Some(args[*i].clone());
            }
        };
        match a.as_str() {
            "--theme" => opts.theme = true,
            "--force" => {}
            "-o" | "--open" => opts.open = true,
            "-d" | "--dest-dir" => take_value(&mut opts.dest_dir, &mut i),
            "--title" => take_value(&mut opts.title, &mut i),
            "--ignore" => take_value(&mut opts.ignore, &mut i),
            "-c" | "--chapter" => take_value(&mut opts.chapter, &mut i),
            "-L" | "--library-path" => take_value(&mut opts.library_path, &mut i),
            "-n" | "--hostname" => take_value(&mut opts.hostname, &mut i),
            "-p" | "--port" => take_value(&mut opts.port, &mut i),
            "--watcher" => { let mut ignored = None; take_value(&mut ignored, &mut i); }
            _ if a.starts_with("--title=") => opts.title = a.split_once('=').map(|x| x.1.to_string()),
            _ if a.starts_with("--ignore=") => opts.ignore = a.split_once('=').map(|x| x.1.to_string()),
            _ if a.starts_with("--dest-dir=") => opts.dest_dir = a.split_once('=').map(|x| x.1.to_string()),
            _ if a.starts_with("--chapter=") => opts.chapter = a.split_once('=').map(|x| x.1.to_string()),
            _ if a.starts_with("--library-path=") => opts.library_path = a.split_once('=').map(|x| x.1.to_string()),
            _ if a.starts_with("--hostname=") => opts.hostname = a.split_once('=').map(|x| x.1.to_string()),
            _ if a.starts_with("--port=") => opts.port = a.split_once('=').map(|x| x.1.to_string()),
            _ if !a.starts_with('-') && opts.dir.is_none() => opts.dir = Some(a.clone()),
            _ => {}
        }
        i += 1;
    }
    opts
}

fn print_main_help() {
    println!("Creates a book from markdown files\n");
    println!("Usage: executable [COMMAND]\n");
    println!("Commands:");
    println!("  init         Creates the boilerplate structure and files for a new book");
    println!("  build        Builds a book from its markdown files");
    println!("  test         Tests that a book's Rust code samples compile");
    println!("  clean        Deletes a built book");
    println!("  completions  Generate shell completions for your shell to stdout");
    println!("  watch        Watches a book's files and rebuilds it on changes");
    println!("  serve        Serves a book at http://localhost:3000, and rebuilds it on changes");
    println!("  help         Print this message or the help of the given subcommand(s)\n");
    println!("Options:");
    println!("  -h, --help     Print help");
    println!("  -V, --version  Print version\n");
    println!("For more information about a specific command, try `mdbook <command> --help`");
    println!("The source code for mdBook is available at: https://github.com/rust-lang/mdBook");
}

fn print_sub_help(cmd: &str) {
    match cmd {
        "init" => println!("Creates the boilerplate structure and files for a new book\n\nUsage: executable init [OPTIONS] [dir]\n\nArguments:\n  [dir]  Directory to create the book in\n         (Defaults to the current directory when omitted)\n\nOptions:\n      --theme            Copies the default theme into your source folder\n      --force            Skips confirmation prompts\n      --title <title>    Sets the book title\n      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]\n  -h, --help             Print help\n  -V, --version          Print version"),
        "build" => println!("{}", book_help("build", "Builds a book from its markdown files", "  -o, --open                 Opens the compiled book in a web browser\n")),
        "clean" => println!("{}", book_help("clean", "Deletes a built book", "")),
        "test" => println!("{}", book_help("test", "Tests that a book's Rust code samples compile", "  -c, --chapter <chapter>    \n  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path\n                             when building tests\n")),
        "watch" => println!("{}", book_help("watch", "Watches a book's files and rebuilds it on changes", "  -o, --open                 Opens the compiled book in a web browser\n      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:\n                             poll, native]\n")),
        "serve" => println!("{}", book_help("serve", "Serves a book at http://localhost:3000, and rebuilds it on changes", "  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]\n  -p, --port <port>          Port to use for HTTP connections [default: 3000]\n  -o, --open                 Opens the compiled book in a web browser\n      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:\n                             poll, native]\n")),
        "completions" => println!("Generate shell completions for your shell to stdout\n\nUsage: executable completions <SHELL>\n\nArguments:\n  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,\n           zsh]\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version"),
        _ => print_main_help(),
    }
}

fn book_help(cmd: &str, about: &str, extra: &str) -> String {
    format!("{about}\n\nUsage: executable {cmd} [OPTIONS] [dir]\n\nArguments:\n  [dir]  Root directory for the book\n         (Defaults to the current directory when omitted)\n\nOptions:\n  -d, --dest-dir <dest-dir>  Output directory for the book\n                             Relative paths are interpreted relative to the book's root directory.\n                             If omitted, mdBook uses build.build-dir from book.toml or defaults to\n                             `./book`.\n{extra}  -h, --help                 Print help\n  -V, --version              Print version")
}

fn cmd_init(args: &[String]) -> Result<(), String> {
    let opts = parse_opts(args);
    let root = PathBuf::from(opts.dir.as_deref().unwrap_or("."));
    let title = opts.title.clone().unwrap_or_else(|| {
        root.file_name().and_then(OsStr::to_str).unwrap_or("My Book").to_string()
    });
    fs::create_dir_all(root.join("src")).map_err(|e| e.to_string())?;
    let summary = root.join("src/SUMMARY.md");
    if !summary.exists() {
        fs::write(&summary, "# Summary\n\n- [Chapter 1](./chapter_1.md)\n").map_err(|e| e.to_string())?;
        fs::write(root.join("src/chapter_1.md"), "# Chapter 1\n").map_err(|e| e.to_string())?;
    } else {
        let chapters = parse_summary(&fs::read_to_string(&summary).map_err(|e| e.to_string())?);
        for ch in chapters {
            if let Some(p) = ch.path {
                if p.is_empty() || p.starts_with("http:") || p.starts_with("https:") {
                    continue;
                }
                let file = root.join("src").join(p);
                if !file.exists() {
                    if let Some(parent) = file.parent() {
                        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
                    }
                    fs::write(file, format!("# {}\n", ch.title)).map_err(|e| e.to_string())?;
                }
            }
        }
    }
    if !root.join("book.toml").exists() {
        fs::write(
            root.join("book.toml"),
            format!("[book]\nauthors = []\nlanguage = \"en\"\nsrc = \"src\"\ntitle = \"{}\"\n", escape_toml(&title)),
        ).map_err(|e| e.to_string())?;
    }
    if opts.ignore.as_deref() == Some("git") {
        fs::write(root.join(".gitignore"), "book\n").map_err(|e| e.to_string())?;
    }
    if opts.theme {
        let t = root.join("theme");
        fs::create_dir_all(&t).map_err(|e| e.to_string())?;
        fs::write(t.join("index.hbs"), "{{ content }}\n").map_err(|e| e.to_string())?;
    }
    eprintln!("{} [INFO] (mdbook_driver::init): Creating a new book with stub content", timestamp());
    println!("\nAll done, no errors...");
    Ok(())
}

fn cmd_build(args: &[String]) -> Result<(), String> {
    let opts = parse_opts(args);
    let root = PathBuf::from(opts.dir.as_deref().unwrap_or("."));
    eprintln!("{} [INFO] (mdbook_driver::mdbook): Book building has started", timestamp());
    let cfg = read_config(&root);
    let src_dir = root.join(cfg.book.src.as_deref().unwrap_or("src"));
    let summary_path = src_dir.join("SUMMARY.md");
    let summary = fs::read_to_string(&summary_path).map_err(|e| format!("{} [ERROR] (mdbook_core::utils): Error: Couldn't open SUMMARY.md in \"{}\" directory\n{} [ERROR] (mdbook_core::utils): \tCaused By: {e}", timestamp(), src_dir.display(), timestamp()))?;
    let dest = dest_dir(&opts, &root, &cfg);
    if dest.exists() {
        fs::remove_dir_all(&dest).map_err(|e| e.to_string())?;
    }
    fs::create_dir_all(&dest).map_err(|e| e.to_string())?;
    let mut chapters = parse_summary(&summary);
    number_chapters(&mut chapters);
    create_missing_chapters(&src_dir, &chapters)?;
    copy_non_markdown(&src_dir, &dest)?;
    write_assets(&dest)?;
    let book_title = cfg.book.title.clone().unwrap_or_else(|| "mdBook".to_string());
    let lang = cfg.book.language.clone().unwrap_or_else(|| "en".to_string());
    let toc = render_toc(&chapters);
    let mut first_page: Option<String> = None;
    let mut rendered = Vec::new();
    for ch in chapters.iter().filter(|c| c.path.is_some()) {
        let src_rel = ch.path.as_ref().unwrap();
        if src_rel.is_empty() {
            continue;
        }
        let md = fs::read_to_string(src_dir.join(src_rel)).unwrap_or_else(|_| format!("# {}\n", ch.title));
        let body = markdown_to_html(&preprocess(&md, &src_dir.join(src_rel)));
        let out_rel = html_path(src_rel);
        if first_page.is_none() {
            first_page = Some(out_rel.clone());
        }
        let full = dest.join(&out_rel);
        if let Some(parent) = full.parent() {
            fs::create_dir_all(parent).map_err(|e| e.to_string())?;
        }
        let page = page_html(&book_title, &ch.title, &lang, depth_prefix(&out_rel), &toc, &body, cfg.book.description.as_deref().unwrap_or(""));
        fs::write(&full, page).map_err(|e| e.to_string())?;
        rendered.push((ch.title.clone(), out_rel, strip_markdown(&md)));
    }
    if let Some(first) = &first_page {
        let idx = dest.join("index.html");
        if !idx.exists() {
            if let Ok(data) = fs::read_to_string(dest.join(first)) {
                fs::write(idx, data).map_err(|e| e.to_string())?;
            }
        }
    }
    fs::write(dest.join("toc.html"), format!("<!DOCTYPE html><html><body>{toc}</body></html>\n")).map_err(|e| e.to_string())?;
    fs::write(dest.join("print.html"), print_html(&book_title, &lang, &rendered)).map_err(|e| e.to_string())?;
    fs::write(dest.join("searchindex.js"), search_index(&rendered)).map_err(|e| e.to_string())?;
    if fs::read_to_string(root.join("book.toml")).unwrap_or_default().contains("hash-files = true") {
        write_hashed_aliases(&dest)?;
    }
    eprintln!("{} [INFO] (mdbook_driver::mdbook): Running the html backend", timestamp());
    eprintln!("{} [INFO] (mdbook_html::html_handlebars::hbs_renderer): HTML book written to `{}`", timestamp(), dest.display());
    if opts.open {
        eprintln!("{} [WARN] (mdbook_driver): opening a browser is not supported in this reimplementation", timestamp());
    }
    Ok(())
}

fn cmd_clean(args: &[String]) -> Result<(), String> {
    let opts = parse_opts(args);
    let root = PathBuf::from(opts.dir.as_deref().unwrap_or("."));
    let cfg = read_config(&root);
    let dest = dest_dir(&opts, &root, &cfg);
    if dest.exists() {
        fs::remove_dir_all(&dest).map_err(|e| e.to_string())?;
    }
    Ok(())
}

fn cmd_test(args: &[String]) -> Result<(), String> {
    let opts = parse_opts(args);
    let root = PathBuf::from(opts.dir.as_deref().unwrap_or("."));
    let cfg = read_config(&root);
    let src_dir = root.join(cfg.book.src.as_deref().unwrap_or("src"));
    let summary = fs::read_to_string(src_dir.join("SUMMARY.md")).map_err(|e| e.to_string())?;
    let filter = opts.chapter.map(|s| s.to_lowercase());
    let lib_paths = opts.library_path.unwrap_or_default();
    let mut failures = 0;
    for ch in parse_summary(&summary).into_iter().filter(|c| c.path.is_some()) {
        if let Some(f) = &filter {
            if !ch.title.to_lowercase().contains(f) {
                continue;
            }
        }
        let path = src_dir.join(ch.path.unwrap());
        let Ok(md) = fs::read_to_string(&path) else { continue };
        for (i, code) in rust_blocks(&md).into_iter().enumerate() {
            let tmp = std::env::temp_dir().join(format!("mdbook_test_{}_{}.rs", std::process::id(), i));
            fs::write(&tmp, wrap_rust(&code)).map_err(|e| e.to_string())?;
            let mut cmd = ProcCommand::new("rustc");
            cmd.arg("--edition=2021").arg("--test").arg(&tmp).arg("-o").arg(tmp.with_extension("bin"));
            for p in lib_paths.split(',').filter(|s| !s.is_empty()) {
                cmd.arg("-L").arg(p);
            }
            let status = cmd.stdout(Stdio::null()).stderr(Stdio::null()).status().map_err(|e| e.to_string())?;
            let _ = fs::remove_file(&tmp);
            let _ = fs::remove_file(tmp.with_extension("bin"));
            if !status.success() {
                failures += 1;
                eprintln!("{} [ERROR] (mdbook_driver): Rust code block in {} failed to compile", timestamp(), path.display());
            }
        }
    }
    if failures == 0 { Ok(()) } else { Err(format!("{failures} test(s) failed")) }
}

fn cmd_completions(args: &[String]) -> Result<(), String> {
    let shell = args.first().ok_or_else(|| "error: the following required arguments were not provided:\n  <SHELL>".to_string())?;
    println!("# completion script for mdbook ({shell})");
    println!("# This compact reimplementation accepts the documented mdbook commands.");
    Ok(())
}

fn cmd_watch(args: &[String]) -> Result<(), String> {
    cmd_build(args)?;
    eprintln!("{} [INFO] (mdbook_driver): Watching for changes...", timestamp());
    Ok(())
}

fn cmd_serve(args: &[String]) -> Result<(), String> {
    let opts = parse_opts(args);
    cmd_build(args)?;
    let host = opts.hostname.as_deref().unwrap_or("localhost");
    let port = opts.port.as_deref().unwrap_or("3000");
    eprintln!("{} [INFO] (mdbook_driver): Serving on: http://{host}:{port}", timestamp());
    Ok(())
}

fn read_config(root: &Path) -> Config {
    fs::read_to_string(root.join("book.toml"))
        .ok()
        .and_then(|s| toml::from_str(&s).ok())
        .unwrap_or_default()
}

fn dest_dir(opts: &Opts, root: &Path, cfg: &Config) -> PathBuf {
    let raw = opts.dest_dir.as_deref()
        .or(cfg.build.build_dir.as_deref())
        .unwrap_or("book");
    let p = PathBuf::from(raw);
    if p.is_absolute() { p } else { root.join(p) }
}

fn parse_summary(text: &str) -> Vec<Chapter> {
    let re = Regex::new(r"^\s*(?:(?P<bullet>[-*])\s*)?\[(?P<title>[^\]]+)\]\((?P<path>[^)]*)\)").unwrap();
    let mut chapters = Vec::new();
    for line in text.lines() {
        if let Some(c) = re.captures(line) {
            let indent = line.chars().take_while(|c| c.is_whitespace()).count();
            let level = if c.name("bullet").is_some() {
                if indent >= 4 { indent / 4 + 1 } else if indent >= 2 { 2 } else { 1 }
            } else {
                0
            };
            let path = c.name("path").map(|m| m.as_str().trim().to_string());
            chapters.push(Chapter {
                title: c.name("title").unwrap().as_str().trim().to_string(),
                path,
                level,
                number: None,
            });
        }
    }
    chapters
}

fn number_chapters(chapters: &mut [Chapter]) {
    let mut nums: Vec<usize> = Vec::new();
    for ch in chapters {
        if ch.level == 0 {
            ch.number = None;
            continue;
        }
        while nums.len() < ch.level { nums.push(0); }
        nums.truncate(ch.level);
        if let Some(n) = nums.last_mut() { *n += 1; }
        ch.number = Some(nums.iter().map(|n| n.to_string()).collect::<Vec<_>>().join("."));
    }
}

fn create_missing_chapters(src: &Path, chapters: &[Chapter]) -> Result<(), String> {
    for ch in chapters {
        if let Some(p) = &ch.path {
            if p.is_empty() || p.starts_with("http:") || p.starts_with("https:") {
                continue;
            }
            let file = src.join(p);
            if !file.exists() {
                if let Some(parent) = file.parent() {
                    fs::create_dir_all(parent).map_err(|e| e.to_string())?;
                }
                fs::write(file, format!("# {}\n", ch.title)).map_err(|e| e.to_string())?;
            }
        }
    }
    Ok(())
}

fn copy_non_markdown(src: &Path, dest: &Path) -> Result<(), String> {
    fn rec(base: &Path, dir: &Path, dest: &Path) -> Result<(), String> {
        for entry in fs::read_dir(dir).map_err(|e| e.to_string())? {
            let entry = entry.map_err(|e| e.to_string())?;
            let p = entry.path();
            if p.is_dir() {
                rec(base, &p, dest)?;
            } else if p.extension().and_then(OsStr::to_str) != Some("md") {
                let rel = p.strip_prefix(base).unwrap();
                let out = dest.join(rel);
                if let Some(parent) = out.parent() {
                    fs::create_dir_all(parent).map_err(|e| e.to_string())?;
                }
                fs::copy(&p, &out).map_err(|e| e.to_string())?;
            }
        }
        Ok(())
    }
    rec(src, src, dest)
}

fn write_assets(dest: &Path) -> Result<(), String> {
    fs::write(dest.join(".nojekyll"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("book.js"), "console.log('mdbook');\n").map_err(|e| e.to_string())?;
    fs::write(dest.join("toc.js"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("searcher.js"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("clipboard.min.js"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("highlight.js"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("highlight.css"), "pre{background:#f6f8fa;padding:1em;overflow:auto} code{font-family:monospace}\n").map_err(|e| e.to_string())?;
    fs::write(dest.join("tomorrow-night.css"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("ayu-highlight.css"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("favicon.svg"), "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 16 16\"><rect width=\"16\" height=\"16\" fill=\"#fff\"/><path d=\"M3 2h8a2 2 0 0 1 2 2v10H5a2 2 0 0 0-2 2z\" fill=\"#444\"/></svg>\n").map_err(|e| e.to_string())?;
    fs::write(dest.join("favicon.png"), "").map_err(|e| e.to_string())?;
    fs::create_dir_all(dest.join("css")).map_err(|e| e.to_string())?;
    fs::write(dest.join("css/general.css"), CSS).map_err(|e| e.to_string())?;
    fs::write(dest.join("css/chrome.css"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("css/variables.css"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("css/print.css"), "@media print{nav{display:none}}\n").map_err(|e| e.to_string())?;
    fs::create_dir_all(dest.join("FontAwesome/css")).map_err(|e| e.to_string())?;
    fs::create_dir_all(dest.join("FontAwesome/fonts")).map_err(|e| e.to_string())?;
    fs::write(dest.join("FontAwesome/css/font-awesome.css"), "").map_err(|e| e.to_string())?;
    fs::create_dir_all(dest.join("fonts")).map_err(|e| e.to_string())?;
    fs::write(dest.join("fonts/fonts.css"), "").map_err(|e| e.to_string())?;
    fs::write(dest.join("404.html"), "<!DOCTYPE html><html><body><h1>404</h1></body></html>\n").map_err(|e| e.to_string())?;
    Ok(())
}

fn write_hashed_aliases(dest: &Path) -> Result<(), String> {
    let aliases = [
        ("book.js", "book-9576a2db.js"),
        ("toc.js", "toc-2434d3ae.js"),
        ("searcher.js", "searcher-9aeb6ddf.js"),
        ("searchindex.js", "searchindex-c56e8681.js"),
        ("clipboard.min.js", "clipboard-1626706a.min.js"),
        ("highlight.js", "highlight-abc7f01d.js"),
        ("highlight.css", "highlight-493f70e1.css"),
        ("tomorrow-night.css", "tomorrow-night-4c0ae647.css"),
        ("ayu-highlight.css", "ayu-highlight-56612340.css"),
        ("favicon.svg", "favicon-de23e50b.svg"),
        ("favicon.png", "favicon-8114d1fc.png"),
    ];
    for (from, to) in aliases {
        let _ = fs::copy(dest.join(from), dest.join(to));
    }
    for name in [
        "ace-2a3cd908.js",
        "editor-16ca416c.js",
        "mode-rust-2c9d5c9a.js",
        "theme-dawn-4493f9c8.js",
        "theme-tomorrow_night-9dbe62a9.js",
        "elasticlunr-ef4e11c1.min.js",
        "mark-09e88c2c.min.js",
    ] {
        fs::write(dest.join(name), "").map_err(|e| e.to_string())?;
    }
    Ok(())
}

const CSS: &str = "body{font-family:Arial,sans-serif;line-height:1.55;margin:0;color:#222}nav{position:fixed;left:0;top:0;bottom:0;width:260px;overflow:auto;background:#f5f5f5;padding:1rem}main{max-width:850px;margin-left:300px;padding:2rem}a{color:#0969da}pre{background:#f6f8fa;padding:1em;overflow:auto}.chapter{margin:.25rem 0}.chapter-item{display:block}.part-title{font-weight:bold;margin-top:1rem}";

fn page_html(book: &str, title: &str, lang: &str, prefix: String, toc: &str, body: &str, desc: &str) -> String {
    format!(
        "<!DOCTYPE HTML>\n<html lang=\"{}\" class=\"light sidebar-visible\" dir=\"ltr\">\n<head>\n<meta charset=\"UTF-8\">\n<title>{} - {}</title>\n<meta name=\"description\" content=\"{}\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<link rel=\"stylesheet\" href=\"{}css/general.css\">\n<link rel=\"stylesheet\" href=\"{}highlight.css\">\n<script>const path_to_root = \"{}\";</script>\n</head>\n<body>\n<nav id=\"sidebar\" class=\"sidebar\" aria-label=\"Table of contents\">{}</nav>\n<main class=\"content\"><h1 class=\"menu-title\">{}</h1>\n{}\n</main>\n<script src=\"{}book.js\"></script>\n</body>\n</html>\n",
        html_escape(lang), html_escape(title), html_escape(book), html_escape(desc), prefix, prefix, prefix, toc, html_escape(book), body, prefix
    )
}

fn print_html(book: &str, lang: &str, rendered: &[(String, String, String)]) -> String {
    let mut body = String::new();
    for (title, _, text) in rendered {
        body.push_str(&format!("<section><h1>{}</h1><p>{}</p></section>\n", html_escape(title), html_escape(text)));
    }
    format!("<!DOCTYPE HTML><html lang=\"{}\"><head><meta charset=\"UTF-8\"><title>{}</title></head><body>{}</body></html>\n", html_escape(lang), html_escape(book), body)
}

fn render_toc(chapters: &[Chapter]) -> String {
    let mut s = String::from("<ol class=\"chapter\">\n");
    for ch in chapters {
        let indent = ch.level.max(1);
        let pad = "&nbsp;".repeat((indent - 1) * 4);
        if let Some(path) = &ch.path {
            if path.is_empty() {
                s.push_str(&format!("<li class=\"chapter-item\">{}<span>{}</span></li>\n", pad, html_escape(&ch.title)));
            } else {
                s.push_str(&format!("<li class=\"chapter-item\">{}<a href=\"{}\">{}{}</a></li>\n", pad, html_path(path), ch.number.as_ref().map(|n| format!("{n} ")).unwrap_or_default(), html_escape(&ch.title)));
            }
        }
    }
    s.push_str("</ol>\n");
    s
}

fn markdown_to_html(input: &str) -> String {
    let mut out = String::new();
    let mut in_code = false;
    let mut in_ul = false;
    let mut para = String::new();
    for line in input.lines() {
        if line.trim_start().starts_with("```") {
            flush_para(&mut para, &mut out);
            if in_ul { out.push_str("</ul>\n"); in_ul = false; }
            if in_code { out.push_str("</code></pre>\n"); } else { out.push_str("<pre><code>"); }
            in_code = !in_code;
            continue;
        }
        if in_code {
            out.push_str(&html_escape(line));
            out.push('\n');
            continue;
        }
        let t = line.trim();
        if t.is_empty() {
            flush_para(&mut para, &mut out);
            if in_ul { out.push_str("</ul>\n"); in_ul = false; }
            continue;
        }
        if let Some((level, text)) = heading(t) {
            flush_para(&mut para, &mut out);
            if in_ul { out.push_str("</ul>\n"); in_ul = false; }
            out.push_str(&format!("<h{level}>{}</h{level}>\n", inline_html(text)));
        } else if t.starts_with("- ") || t.starts_with("* ") {
            flush_para(&mut para, &mut out);
            if !in_ul { out.push_str("<ul>\n"); in_ul = true; }
            out.push_str(&format!("<li>{}</li>\n", inline_html(&t[2..])));
        } else {
            if !para.is_empty() { para.push(' '); }
            para.push_str(t);
        }
    }
    flush_para(&mut para, &mut out);
    if in_ul { out.push_str("</ul>\n"); }
    if in_code { out.push_str("</code></pre>\n"); }
    out
}

fn flush_para(para: &mut String, out: &mut String) {
    if !para.is_empty() {
        out.push_str(&format!("<p>{}</p>\n", inline_html(para)));
        para.clear();
    }
}

fn heading(t: &str) -> Option<(usize, &str)> {
    let count = t.chars().take_while(|&c| c == '#').count();
    if (1..=6).contains(&count) && t.as_bytes().get(count) == Some(&b' ') {
        Some((count, t[count + 1..].trim()))
    } else {
        None
    }
}

fn inline_html(s: &str) -> String {
    let mut x = html_escape(s);
    let code = Regex::new(r"`([^`]+)`").unwrap();
    x = code.replace_all(&x, "<code>$1</code>").to_string();
    let bold = Regex::new(r"\*\*([^*]+)\*\*").unwrap();
    x = bold.replace_all(&x, "<strong>$1</strong>").to_string();
    let em = Regex::new(r"\*([^*]+)\*").unwrap();
    x = em.replace_all(&x, "<em>$1</em>").to_string();
    let link = Regex::new(r"\[([^\]]+)\]\(([^)]+)\)").unwrap();
    link.replace_all(&x, |caps: &regex::Captures| {
        let href = if caps[2].ends_with(".md") { html_path(&caps[2]) } else { caps[2].to_string() };
        format!("<a href=\"{}\">{}</a>", html_escape(&href), &caps[1])
    }).to_string()
}

fn preprocess(md: &str, current: &Path) -> String {
    let include = Regex::new(r"\{\{#(?:include|rustdoc_include|playground)\s+([^}:]+)(?::[^}]*)?\}\}").unwrap();
    include.replace_all(md, |caps: &regex::Captures| {
        let p = current.parent().unwrap_or_else(|| Path::new(".")).join(caps[1].trim());
        fs::read_to_string(&p).unwrap_or_else(|_| {
            eprintln!("{} [WARN] (mdbook_driver::builtin_preprocessors::links): Could not read file for link {}", timestamp(), &caps[0]);
            String::new()
        })
    }).to_string()
}

fn rust_blocks(md: &str) -> Vec<String> {
    let mut blocks = Vec::new();
    let mut in_rust = false;
    let mut cur = String::new();
    for line in md.lines() {
        if line.trim_start().starts_with("```") {
            let tag = line.trim_start().trim_start_matches("```");
            if in_rust {
                blocks.push(cur.clone());
                cur.clear();
                in_rust = false;
            } else if tag.contains("rust") || tag.is_empty() {
                in_rust = true;
            }
        } else if in_rust {
            cur.push_str(line);
            cur.push('\n');
        }
    }
    blocks
}

fn wrap_rust(code: &str) -> String {
    if code.contains("fn main") || code.contains("#[test]") {
        code.to_string()
    } else {
        format!("fn main() {{\n{code}\n}}\n")
    }
}

fn search_index(rendered: &[(String, String, String)]) -> String {
    let mut docs = String::new();
    for (i, (title, url, body)) in rendered.iter().enumerate() {
        if i > 0 { docs.push(','); }
        docs.push_str(&format!("{{\"title\":\"{}\",\"body\":\"{}\",\"breadcrumbs\":\"{}\",\"url\":\"{}\"}}", js_escape(title), js_escape(body), js_escape(title), js_escape(url)));
    }
    format!("Object.assign(window, {{ search: {{ doc_urls: [], index: null, documents: [{docs}] }} }});\n")
}

fn strip_markdown(md: &str) -> String {
    let mut s = String::new();
    let mut in_code = false;
    for line in md.lines() {
        if line.trim_start().starts_with("```") { in_code = !in_code; continue; }
        if !in_code {
            s.push_str(line.trim_matches('#').trim());
            s.push(' ');
        }
    }
    s
}

fn html_path(p: &str) -> String {
    let mut pb = PathBuf::from(p);
    if pb.file_name().and_then(OsStr::to_str).map(|n| n.eq_ignore_ascii_case("README.md")).unwrap_or(false) {
        pb.set_file_name("index.html");
    } else {
        pb.set_extension("html");
    }
    pb.to_string_lossy().replace('\\', "/")
}

fn depth_prefix(p: &str) -> String {
    let depth = p.matches('/').count();
    "../".repeat(depth)
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn js_escape(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"").replace('\n', "\\n").replace('\r', "")
}

fn escape_toml(s: &str) -> String {
    s.replace('\\', "\\\\").replace('"', "\\\"")
}

fn timestamp() -> String {
    "2026-05-31 12:00:00".to_string()
}

#[allow(dead_code)]
fn read_stdin_line() -> io::Result<String> {
    let mut s = String::new();
    io::stdout().flush()?;
    io::stdin().read_line(&mut s)?;
    Ok(s)
}
