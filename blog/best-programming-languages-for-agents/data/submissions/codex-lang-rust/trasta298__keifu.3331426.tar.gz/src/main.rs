use std::cmp::min;
use std::env;
use std::ffi::OsStr;
use std::fs::File;
use std::io::{self, Read, Write};
use std::process::{Command, Stdio};

#[derive(Clone, Debug)]
struct Commit {
    hash: String,
    short: String,
    date: String,
    author: String,
    refs: String,
    subject: String,
    body: String,
    files: Vec<FileStat>,
}

#[derive(Clone, Debug)]
struct FileStat {
    added: String,
    deleted: String,
    path: String,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    if let Some(code) = handle_args(&args) {
        std::process::exit(code);
    }

    if let Err(e) = ensure_git_repo() {
        eprintln!("{e}");
        std::process::exit(1);
    }

    if File::options().read(true).write(true).open("/dev/tty").is_err() {
        eprintln!("Error: No such device or address (os error 6)");
        std::process::exit(1);
    }

    if let Err(e) = run_tui() {
        let _ = Command::new("stty").arg("sane").status();
        eprintln!("Error: {e}");
        std::process::exit(1);
    }
}

fn handle_args(args: &[String]) -> Option<i32> {
    let program = args
        .get(0)
        .and_then(|s| std::path::Path::new(s).file_name())
        .and_then(OsStr::to_str)
        .unwrap_or("executable");

    if args.len() == 1 {
        return None;
    }
    match args[1].as_str() {
        "-h" | "--help" if args.len() == 2 => {
            println!("A TUI tool to visualize Git commit graphs with branch genealogy\n");
            println!("Usage: {program}\n");
            println!("Options:");
            println!("  -h, --help     Print help");
            println!("  -V, --version  Print version");
            Some(0)
        }
        "-V" | "--version" if args.len() == 2 => {
            println!("keifu 0.2.3");
            Some(0)
        }
        other => {
            eprintln!("error: unexpected argument '{other}' found\n");
            eprintln!("Usage: {program}\n");
            eprintln!("For more information, try '--help'.");
            Some(2)
        }
    }
}

fn ensure_git_repo() -> Result<(), String> {
    let out = Command::new("git")
        .args(["rev-parse", "--show-toplevel"])
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status();
    match out {
        Ok(s) if s.success() => Ok(()),
        _ => Err("Error: Git repository not found. Please run inside a Git repository.\n\nCaused by:\n    could not find repository at '.'; class=Repository (6); code=NotFound (-3)".to_string()),
    }
}

fn run_tui() -> io::Result<()> {
    let mut commits = load_commits();
    if commits.is_empty() {
        commits.push(Commit {
            hash: String::new(),
            short: String::new(),
            date: String::new(),
            author: String::new(),
            refs: String::new(),
            subject: "No commits".to_string(),
            body: String::new(),
            files: Vec::new(),
        });
    }

    let _guard = TerminalGuard::enter()?;
    let mut selected = 0usize;
    let mut offset = 0usize;
    let mut show_help = false;

    loop {
        let (rows, cols) = term_size();
        draw(&commits, selected, offset, show_help, rows, cols)?;
        let key = read_key()?;
        match key.as_str() {
            "q" | "\u{1b}" => break,
            "j" | "down" => {
                if selected + 1 < commits.len() {
                    selected += 1;
                }
            }
            "k" | "up" => {
                selected = selected.saturating_sub(1);
            }
            "g" | "home" => selected = 0,
            "G" | "end" => selected = commits.len().saturating_sub(1),
            "\u{4}" => selected = min(commits.len().saturating_sub(1), selected + 10),
            "\u{15}" => selected = selected.saturating_sub(10),
            "?" => show_help = !show_help,
            "R" => commits = load_commits(),
            "f" => {
                let _ = Command::new("git").args(["fetch", "origin"]).status();
                commits = load_commits();
            }
            "\n" | "\r" => checkout_selected(commits.get(selected)),
            "b" => create_branch(commits.get(selected))?,
            "d" => delete_branch(commits.get(selected))?,
            _ => {}
        }

        let list_height = rows.saturating_sub(6).max(1) as usize;
        if selected < offset {
            offset = selected;
        } else if selected >= offset + list_height {
            offset = selected + 1 - list_height;
        }
    }
    Ok(())
}

struct TerminalGuard;

impl TerminalGuard {
    fn enter() -> io::Result<Self> {
        Command::new("stty").args(["raw", "-echo"]).status().ok();
        print!("\x1b[?1049h\x1b[?25l");
        io::stdout().flush()?;
        Ok(Self)
    }
}

impl Drop for TerminalGuard {
    fn drop(&mut self) {
        print!("\x1b[?25h\x1b[?1049l\x1b[0m");
        let _ = io::stdout().flush();
        let _ = Command::new("stty").arg("sane").status();
    }
}

fn load_commits() -> Vec<Commit> {
    let format = "%H%x1f%h%x1f%ad%x1f%an%x1f%D%x1f%s%x1f%B%x1e";
    let output = Command::new("git")
        .args([
            "log",
            "--all",
            "--max-count=500",
            "--date=short",
            &format!("--pretty=format:{format}"),
        ])
        .output();
    let text = output
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).into_owned())
        .unwrap_or_default();

    text.split('\x1e')
        .filter_map(|record| {
            let rec = record.trim_matches('\n');
            if rec.is_empty() {
                return None;
            }
            let mut parts = rec.splitn(7, '\x1f');
            let hash = parts.next()?.to_string();
            let short = parts.next().unwrap_or("").to_string();
            let date = parts.next().unwrap_or("").to_string();
            let author = parts.next().unwrap_or("").to_string();
            let refs = clean_refs(parts.next().unwrap_or(""));
            let subject = parts.next().unwrap_or("").to_string();
            let body = parts.next().unwrap_or("").trim().to_string();
            let files = load_file_stats(&hash);
            Some(Commit {
                hash,
                short,
                date,
                author,
                refs,
                subject,
                body,
                files,
            })
        })
        .collect()
}

fn clean_refs(raw: &str) -> String {
    raw.split(',')
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(|s| s.strip_prefix("HEAD -> ").unwrap_or(s))
        .collect::<Vec<_>>()
        .join(", ")
}

fn load_file_stats(hash: &str) -> Vec<FileStat> {
    let spec = if parent_count(hash) == 0 {
        hash.to_string()
    } else {
        format!("{hash}^..{hash}")
    };
    let output = Command::new("git")
        .args(["diff", "--numstat", "--find-renames", &spec])
        .output();
    let text = output
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).into_owned())
        .unwrap_or_default();
    text.lines()
        .take(50)
        .filter_map(|line| {
            let mut parts = line.splitn(3, '\t');
            Some(FileStat {
                added: parts.next()?.to_string(),
                deleted: parts.next()?.to_string(),
                path: parts.next()?.to_string(),
            })
        })
        .collect()
}

fn parent_count(hash: &str) -> usize {
    let output = Command::new("git")
        .args(["rev-list", "--parents", "-n", "1", hash])
        .output();
    output
        .ok()
        .map(|o| String::from_utf8_lossy(&o.stdout).split_whitespace().skip(1).count())
        .unwrap_or(0)
}

fn term_size() -> (u16, u16) {
    let output = Command::new("stty").arg("size").output();
    if let Ok(out) = output {
        let s = String::from_utf8_lossy(&out.stdout);
        let mut it = s.split_whitespace();
        if let (Some(r), Some(c)) = (it.next(), it.next()) {
            if let (Ok(rows), Ok(cols)) = (r.parse::<u16>(), c.parse::<u16>()) {
                return (rows.max(10), cols.max(40));
            }
        }
    }
    (24, 80)
}

fn draw(
    commits: &[Commit],
    selected: usize,
    offset: usize,
    show_help: bool,
    rows: u16,
    cols: u16,
) -> io::Result<()> {
    let mut out = String::new();
    out.push_str("\x1b[H\x1b[2J\x1b[39m\x1b[49m\x1b[0m");
    let width = cols as usize;
    line(&mut out, width, "keifu");
    line(&mut out, width, "Graph      Date        Author             Commit    Message");
    line(&mut out, width, &"─".repeat(width.min(120)));

    let list_height = rows.saturating_sub(9).max(1) as usize;
    for (idx, commit) in commits.iter().enumerate().skip(offset).take(list_height) {
        let marker = if idx == selected { ">" } else { " " };
        let refs = if commit.refs.is_empty() {
            String::new()
        } else {
            format!(" [{}]", commit.refs)
        };
        let msg = format!("{}{}", commit.subject, refs);
        let row = format!(
            "{marker} ●        {:10}  {:17} {:8}  {}",
            commit.date,
            trunc(&commit.author, 17),
            commit.short,
            msg
        );
        line(&mut out, width, &row);
    }

    while out.matches('\n').count() < rows.saturating_sub(6) as usize {
        out.push_str("\r\n");
    }

    if let Some(commit) = commits.get(selected) {
        line(&mut out, width, &"─".repeat(width.min(120)));
        line(
            &mut out,
            width,
            &format!("{}  {}  {}", commit.hash, commit.author, commit.date),
        );
        line(&mut out, width, &commit.body);
        if commit.files.is_empty() {
            line(&mut out, width, "No changed files");
        } else {
            for f in commit.files.iter().take(3) {
                line(
                    &mut out,
                    width,
                    &format!("+{} -{} {}", f.added, f.deleted, f.path),
                );
            }
        }
    }

    if show_help {
        line(
            &mut out,
            width,
            "j/k move  g/G top/bottom  Enter checkout  b branch  d delete  f fetch  R refresh  q quit",
        );
    } else {
        line(&mut out, width, "? help  q quit");
    }
    print!("{out}");
    io::stdout().flush()
}

fn line(out: &mut String, width: usize, s: &str) {
    let mut text = s.replace('\n', " ");
    if text.chars().count() > width {
        text = trunc(&text, width.saturating_sub(1));
    }
    out.push_str(&text);
    out.push_str("\r\n");
}

fn trunc(s: &str, n: usize) -> String {
    if s.chars().count() <= n {
        return s.to_string();
    }
    let keep = n.saturating_sub(1);
    let mut out: String = s.chars().take(keep).collect();
    out.push('…');
    out
}

fn read_key() -> io::Result<String> {
    let mut b = [0u8; 1];
    io::stdin().read_exact(&mut b)?;
    if b[0] == b'\x1b' {
        let mut seq = [0u8; 2];
        if io::stdin().read(&mut seq)? >= 2 && seq[0] == b'[' {
            return Ok(match seq[1] {
                b'A' => "up",
                b'B' => "down",
                b'H' => "home",
                b'F' => "end",
                _ => "\u{1b}",
            }
            .to_string());
        }
        return Ok("\u{1b}".to_string());
    }
    Ok((b[0] as char).to_string())
}

fn checkout_selected(commit: Option<&Commit>) {
    if let Some(c) = commit {
        let target = c
            .refs
            .split(',')
            .next()
            .map(str::trim)
            .filter(|s| !s.is_empty())
            .unwrap_or(&c.hash);
        let _ = Command::new("git").args(["checkout", target]).status();
    }
}

fn create_branch(commit: Option<&Commit>) -> io::Result<()> {
    let Some(c) = commit else { return Ok(()); };
    print!("\r\nBranch name: ");
    io::stdout().flush()?;
    let _ = Command::new("stty").arg("sane").status();
    let mut name = String::new();
    io::stdin().read_line(&mut name)?;
    Command::new("stty").args(["raw", "-echo"]).status().ok();
    let name = name.trim();
    if !name.is_empty() {
        let _ = Command::new("git").args(["branch", name, &c.hash]).status();
    }
    Ok(())
}

fn delete_branch(commit: Option<&Commit>) -> io::Result<()> {
    let Some(c) = commit else { return Ok(()); };
    let branch = c.refs.split(',').next().map(str::trim).unwrap_or("");
    if branch.is_empty() || branch == "HEAD" || branch.starts_with("origin/") {
        return Ok(());
    }
    let _ = Command::new("git").args(["branch", "-d", branch]).status();
    Ok(())
}
