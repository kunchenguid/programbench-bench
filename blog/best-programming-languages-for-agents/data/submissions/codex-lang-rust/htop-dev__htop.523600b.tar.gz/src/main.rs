use std::collections::{HashMap, HashSet};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::Path;
use std::process;

const VERSION: &str = "htop 3.5.0-dev-878e0ce";

const HELP: &str = "htop 3.5.0-dev-878e0ce
(C) 2004-2019 Hisham Muhammad. (C) 2020-2026 htop dev team.
Released under the GNU GPLv2+.

-C --no-color                   Use a monochrome color scheme
-d --delay=DELAY                Set the delay between updates, in tenths of seconds
-F --filter=FILTER              Show only the commands matching the given filter
   --no-function-bar             Hide the function bar
-h --help                       Print this help screen
-H --highlight-changes[=DELAY]  Highlight new and old processes
-M --no-mouse                   Disable the mouse
   --no-meters                  Hide meters
-n --max-iterations=NUMBER      Exit htop after NUMBER iterations/frame updates
-p --pid=PID[,PID,PID...]       Show only the given PIDs
   --readonly                   Disable all system and process changing features
-s --sort-key=COLUMN            Sort by COLUMN in list view (try --sort-key=help for a list)
-t --tree                       Show the tree view (can be combined with -s)
-u --user[=USERNAME]            Show only processes for a given user (or $USER)
-U --no-unicode                 Do not use unicode but plain ASCII
-V --version                    Print version info

Press F1 inside htop for online help.
See 'man htop' for more information.
";

const SORT_HELP: &str = "                PID Process/thread ID
            Command Command line (insert as last column only)
              STATE Process state (S sleeping, R running, D disk, Z zombie, T traced, W paging, I idle)
               PPID Parent process ID
               PGRP Process group ID
            SESSION Process's session ID
                TTY Controlling terminal
              TPGID Process ID of the fg process group of the controlling terminal
             MINFLT Number of minor faults which have not required loading a memory page from disk
            CMINFLT Children processes' minor faults
             MAJFLT Number of major faults which have required loading a memory page from disk
            CMAJFLT Children processes' major faults
              UTIME User CPU time - time the process spent executing in user mode
              STIME System CPU time - time the kernel spent running system calls for this process
             CUTIME Children processes' user CPU time
             CSTIME Children processes' system CPU time
           PRIORITY Kernel's internal priority for the process
               NICE Nice value (the higher the value, the more it lets other processes take priority)
          STARTTIME Time the process was started
          PROCESSOR Id of the CPU the process last executed on
             M_VIRT Total program size in virtual memory
         M_RESIDENT Resident set size, size of the text and data sections, plus stack usage
            M_SHARE Size of the process's shared pages
              M_TRS Size of the .text segment of the process (CODE)
              M_DRS Size of the .data segment plus stack usage of the process (DATA)
              M_LRS The library size of the process (calculated from memory maps)
             ST_UID User ID of the process owner
        PERCENT_CPU Percentage of the CPU time the process used in the last sampling
        PERCENT_MEM Percentage of the memory the process is using, based on resident memory size
               USER Username of the process owner (or user ID if name cannot be determined)
               TIME Total time the process has spent in user and system time
               NLWP Number of threads in the process
               TGID Thread group ID (i.e. process ID)
   PERCENT_NORM_CPU Normalized percentage of the CPU time the process used in the last sampling (normalized by cpu count)
            ELAPSED Time since the process was started
    SCHEDULERPOLICY Current scheduling policy of the process
              RCHAR Number of bytes the process has read
              WCHAR Number of bytes the process has written
              SYSCR Number of read(2) syscalls for the process
              SYSCW Number of write(2) syscalls for the process
             RBYTES Bytes of read(2) I/O for the process
             WBYTES Bytes of write(2) I/O for the process
             CNCLWB Bytes of cancelled write(2) I/O
       IO_READ_RATE The I/O rate of read(2) in bytes per second for the process
      IO_WRITE_RATE The I/O rate of write(2) in bytes per second for the process
            IO_RATE Total I/O rate in bytes per second
             CGROUP Which cgroup the process is in
                OOM OOM (Out-of-Memory) killer score
        IO_PRIORITY I/O priority
              M_PSS proportional set size, same as M_RESIDENT but each page is divided by the number of processes sharing it
             M_SWAP Size of the process's swapped pages
            M_PSSWP shows proportional swap share of this mapping, unlike \"Swap\", this does not take into account swapped out page of underlying shmem objects
               CTXT Context switches (incremental sum of voluntary_ctxt_switches and nonvoluntary_ctxt_switches)
            SECATTR Security attribute of the process (e.g. SELinux or AppArmor)
               COMM comm string of the process from /proc/[pid]/comm
                EXE Basename of exe of the process from /proc/[pid]/exe
                CWD The current working directory of the process
       AUTOGROUP_ID The autogroup identifier of the process
     AUTOGROUP_NICE Nice value (the higher the value, the more other processes take priority) associated with the process autogroup
            CCGROUP Which cgroup the process is in (condensed to essentials)
          CONTAINER Name of the container the process is in (guessed by heuristics)
             M_PRIV The private memory size of the process - resident set size minus shared memory
           GPU_TIME Total GPU time
        GPU_PERCENT Percentage of the GPU time the process used in the last sampling
        ISCONTAINER Whether the process is running inside a child container
";

#[derive(Default)]
struct Config {
    pids: Option<HashSet<i32>>,
    user: Option<String>,
    filter: Option<Vec<String>>,
    sort_key: String,
    iterations: Option<u32>,
    tree: bool,
    no_color: bool,
    no_unicode: bool,
    no_function_bar: bool,
    no_meters: bool,
    readonly: bool,
    no_mouse: bool,
    highlight: Option<Option<String>>,
    delay: u32,
}

#[derive(Clone)]
struct ProcInfo {
    pid: i32,
    ppid: i32,
    uid: u32,
    user: String,
    pri: i64,
    nice: i64,
    virt_kb: u64,
    res_kb: u64,
    shr_kb: u64,
    state: char,
    time_ticks: u64,
    command: String,
}

fn main() {
    let argv0 = env::args().next().unwrap_or_else(|| "htop".to_string());
    let mut cfg = Config { sort_key: "PERCENT_CPU".to_string(), delay: 15, ..Default::default() };
    if let Err(code) = parse_args(&argv0, &mut cfg) {
        process::exit(code);
    }

    if terminal_unknown() {
        eprintln!("Error opening terminal: unknown.");
        process::exit(1);
    }

    let iterations = cfg.iterations.unwrap_or(0);
    if iterations == 0 {
        render(&cfg);
        return;
    }
    for _ in 0..iterations {
        render(&cfg);
    }
}

fn parse_args(argv0: &str, cfg: &mut Config) -> Result<(), i32> {
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" {
            break;
        } else if a == "--help" {
            print!("{HELP}");
            return Err(0);
        } else if a == "--version" {
            println!("{VERSION}");
            return Err(0);
        } else if a == "--no-color" || a == "--no-colour" {
            cfg.no_color = true;
        } else if a == "--no-function-bar" {
            cfg.no_function_bar = true;
        } else if a == "--no-meters" {
            cfg.no_meters = true;
        } else if a == "--readonly" {
            cfg.readonly = true;
        } else if a == "--no-mouse" {
            cfg.no_mouse = true;
        } else if a == "--no-unicode" {
            cfg.no_unicode = true;
        } else if a == "--tree" {
            cfg.tree = true;
        } else if a == "--user" {
            cfg.user = Some(env::var("USER").unwrap_or_default());
        } else if let Some(v) = a.strip_prefix("--user=") {
            validate_user(v)?;
            cfg.user = Some(v.to_string());
        } else if a == "--highlight-changes" {
            cfg.highlight = Some(None);
        } else if let Some(v) = a.strip_prefix("--highlight-changes=") {
            cfg.highlight = Some(Some(v.to_string()));
        } else if let Some(v) = a.strip_prefix("--delay=") {
            cfg.delay = parse_num(v, "delay value")?.clamp(1, 100);
        } else if a == "--delay" {
            need_long(argv0, "delay", &args, &mut i)?;
            cfg.delay = parse_num(&args[i], "delay value")?.clamp(1, 100);
        } else if let Some(v) = a.strip_prefix("--filter=") {
            set_filter(v, cfg)?;
        } else if a == "--filter" {
            need_long(argv0, "filter", &args, &mut i)?;
            set_filter(&args[i], cfg)?;
        } else if let Some(v) = a.strip_prefix("--max-iterations=") {
            cfg.iterations = Some(parse_num(v, "maximum iteration count")?);
        } else if a == "--max-iterations" {
            need_long(argv0, "max-iterations", &args, &mut i)?;
            cfg.iterations = Some(parse_num(&args[i], "maximum iteration count")?);
        } else if let Some(v) = a.strip_prefix("--pid=") {
            cfg.pids = Some(parse_pids(v));
        } else if a == "--pid" {
            need_long(argv0, "pid", &args, &mut i)?;
            cfg.pids = Some(parse_pids(&args[i]));
        } else if let Some(v) = a.strip_prefix("--sort-key=") {
            set_sort(v, cfg)?;
        } else if a == "--sort-key" {
            need_long(argv0, "sort-key", &args, &mut i)?;
            set_sort(&args[i], cfg)?;
        } else if a.starts_with("--") {
            eprintln!("{argv0}: unrecognized option '{}'", a);
            return Err(1);
        } else if a.starts_with('-') && a.len() > 1 {
            parse_short(argv0, &args, &mut i, cfg)?;
        } else {
            eprintln!("{argv0}: invalid option -- '{}'", a);
            return Err(1);
        }
        i += 1;
    }
    Ok(())
}

fn parse_short(argv0: &str, args: &[String], i: &mut usize, cfg: &mut Config) -> Result<(), i32> {
    let s = &args[*i];
    let mut chars = s[1..].char_indices().peekable();
    while let Some((idx, c)) = chars.next() {
        let rest_start = idx + 1 + c.len_utf8();
        match c {
            'h' => {
                print!("{HELP}");
                return Err(0);
            }
            'V' | 'v' => {
                println!("{VERSION}");
                return Err(0);
            }
            'C' => cfg.no_color = true,
            'U' => cfg.no_unicode = true,
            'M' => cfg.no_mouse = true,
            't' => cfg.tree = true,
            'u' => {
                if rest_start < s.len() {
                    let v = &s[rest_start..];
                    validate_user(v)?;
                    cfg.user = Some(v.to_string());
                } else if *i + 1 < args.len() && !args[*i + 1].starts_with('-') {
                    *i += 1;
                    let v = &args[*i];
                    validate_user(v)?;
                    cfg.user = Some(v.clone());
                } else {
                    cfg.user = Some(env::var("USER").unwrap_or_default());
                }
                break;
            }
            'H' => {
                if rest_start < s.len() {
                    cfg.highlight = Some(Some(s[rest_start..].to_string()));
                } else if *i + 1 < args.len() && !args[*i + 1].starts_with('-') {
                    *i += 1;
                    cfg.highlight = Some(Some(args[*i].clone()));
                } else {
                    cfg.highlight = Some(None);
                }
                break;
            }
            'd' | 'F' | 'n' | 'p' | 's' => {
                let val = if rest_start < s.len() {
                    s[rest_start..].to_string()
                } else {
                    if *i + 1 >= args.len() {
                        eprintln!("{argv0}: option requires an argument -- '{}'", c);
                        return Err(1);
                    }
                    *i += 1;
                    args[*i].clone()
                };
                match c {
                    'd' => cfg.delay = parse_num(&val, "delay value")?.clamp(1, 100),
                    'F' => set_filter(&val, cfg)?,
                    'n' => cfg.iterations = Some(parse_num(&val, "maximum iteration count")?),
                    'p' => cfg.pids = Some(parse_pids(&val)),
                    's' => set_sort(&val, cfg)?,
                    _ => {}
                }
                break;
            }
            other => {
                eprintln!("{argv0}: invalid option -- '{}'", other);
                return Err(1);
            }
        }
    }
    Ok(())
}

fn need_long(argv0: &str, opt: &str, args: &[String], i: &mut usize) -> Result<(), i32> {
    if *i + 1 >= args.len() {
        eprintln!("{argv0}: option '--{opt}' requires an argument");
        return Err(1);
    }
    *i += 1;
    Ok(())
}

fn parse_num(v: &str, label: &str) -> Result<u32, i32> {
    match v.parse::<u32>() {
        Ok(n) => Ok(n),
        Err(_) => {
            eprintln!("Error: invalid {label} \"{v}\".");
            Err(1)
        }
    }
}

fn set_filter(v: &str, cfg: &mut Config) -> Result<(), i32> {
    if v.is_empty() {
        eprintln!("Error: invalid filter value \"\".");
        return Err(1);
    }
    cfg.filter = Some(v.split('|').map(|s| s.to_ascii_lowercase()).collect());
    Ok(())
}

fn parse_pids(v: &str) -> HashSet<i32> {
    v.split(',').filter_map(|p| p.parse::<i32>().ok()).collect()
}

fn set_sort(v: &str, cfg: &mut Config) -> Result<(), i32> {
    if v.eq_ignore_ascii_case("help") {
        print!("{SORT_HELP}");
        return Err(0);
    }
    let up = v.to_ascii_uppercase().replace('-', "_");
    if valid_sort(&up) {
        cfg.sort_key = up;
        Ok(())
    } else {
        eprintln!("Error: invalid column \"{v}\".");
        Err(1)
    }
}

fn valid_sort(s: &str) -> bool {
    matches!(s, "PID" | "COMMAND" | "STATE" | "PPID" | "PGRP" | "SESSION" | "TTY" | "TPGID"
        | "MINFLT" | "CMINFLT" | "MAJFLT" | "CMAJFLT" | "UTIME" | "STIME" | "CUTIME" | "CSTIME"
        | "PRIORITY" | "NICE" | "STARTTIME" | "PROCESSOR" | "M_VIRT" | "M_RESIDENT" | "M_SHARE"
        | "M_TRS" | "M_DRS" | "M_LRS" | "ST_UID" | "PERCENT_CPU" | "PERCENT_MEM" | "USER"
        | "TIME" | "NLWP" | "TGID" | "PERCENT_NORM_CPU" | "ELAPSED" | "SCHEDULERPOLICY"
        | "RCHAR" | "WCHAR" | "SYSCR" | "SYSCW" | "RBYTES" | "WBYTES" | "CNCLWB"
        | "IO_READ_RATE" | "IO_WRITE_RATE" | "IO_RATE" | "CGROUP" | "OOM" | "IO_PRIORITY"
        | "M_PSS" | "M_SWAP" | "M_PSSWP" | "CTXT" | "SECATTR" | "COMM" | "EXE" | "CWD"
        | "AUTOGROUP_ID" | "AUTOGROUP_NICE" | "CCGROUP" | "CONTAINER" | "M_PRIV" | "GPU_TIME"
        | "GPU_PERCENT" | "ISCONTAINER")
}

fn validate_user(v: &str) -> Result<(), i32> {
    if v.is_empty() {
        eprintln!("Error: invalid user \"\".");
        return Err(1);
    }
    if v.parse::<u32>().is_ok() || passwd_map().values().any(|name| name == v) {
        Ok(())
    } else {
        eprintln!("Error: invalid user \"{v}\".");
        Err(1)
    }
}

fn terminal_unknown() -> bool {
    match env::var("TERM") {
        Ok(term) => term.is_empty() || term == "unknown",
        Err(_) => true,
    }
}

fn render(cfg: &Config) {
    let mut procs = read_processes();
    apply_filters(&mut procs, cfg);
    sort_processes(&mut procs, &cfg.sort_key);
    let total = procs.len();
    let running = procs.iter().filter(|p| p.state == 'R').count();
    let (mem_used, mem_total) = mem_info();
    let load = fs::read_to_string("/proc/loadavg").unwrap_or_default();
    let load_fields: Vec<&str> = load.split_whitespace().take(3).collect();
    let load_text = if load_fields.len() == 3 { load_fields.join(" ") } else { "0.00 0.00 0.00".to_string() };

    print!("\x1b[?1049h\x1b[H\x1b[2J");
    if !cfg.no_meters {
        println!("  0[          0.0%]   1[          0.0%]");
        println!("  Mem[{}] Tasks: {}, 0 thr, 0 kthr; {} running", meter(mem_used, mem_total), total, running);
        println!("  Swp[                    ] Load average: {}", load_text);
        println!("  Uptime: {}", uptime_text());
    }
    println!("  [Main] [I/O]");
    println!("  PID USER       PRI  NI  VIRT   RES   SHR S  CPU% MEM%   TIME+  Command");
    let max_rows = env::var("LINES").ok().and_then(|v| v.parse::<usize>().ok()).unwrap_or(24).saturating_sub(8).max(5);
    for p in procs.iter().take(max_rows) {
        println!(
            "{:5} {:<10.10} {:>3} {:>3} {:>5} {:>5} {:>5} {} {:>5.1} {:>4.1} {:>8} {}",
            p.pid,
            p.user,
            p.pri,
            p.nice,
            fmt_kb(p.virt_kb),
            fmt_kb(p.res_kb),
            fmt_kb(p.shr_kb),
            p.state,
            0.0,
            0.0,
            fmt_time(p.time_ticks),
            p.command
        );
    }
    if !cfg.no_function_bar {
        println!("F1Help  F2Setup F3Search F4Filter F5Tree F6SortBy F9Kill F10Quit");
    }
    print!("\x1b[?1049l");
    let _ = io::stdout().flush();
}

fn apply_filters(procs: &mut Vec<ProcInfo>, cfg: &Config) {
    if let Some(pids) = &cfg.pids {
        procs.retain(|p| pids.contains(&p.pid));
    }
    if let Some(user) = &cfg.user {
        procs.retain(|p| &p.user == user || p.uid.to_string() == *user);
    }
    if let Some(terms) = &cfg.filter {
        procs.retain(|p| {
            let c = p.command.to_ascii_lowercase();
            terms.iter().any(|t| c.contains(t))
        });
    }
}

fn sort_processes(procs: &mut [ProcInfo], key: &str) {
    match key {
        "PID" => procs.sort_by_key(|p| p.pid),
        "PPID" => procs.sort_by_key(|p| p.ppid),
        "USER" => procs.sort_by(|a, b| a.user.cmp(&b.user).then(a.pid.cmp(&b.pid))),
        "COMMAND" | "COMM" | "EXE" => procs.sort_by(|a, b| a.command.cmp(&b.command).then(a.pid.cmp(&b.pid))),
        "M_RESIDENT" | "PERCENT_MEM" => procs.sort_by(|a, b| b.res_kb.cmp(&a.res_kb)),
        "M_VIRT" => procs.sort_by(|a, b| b.virt_kb.cmp(&a.virt_kb)),
        "TIME" | "UTIME" | "STIME" => procs.sort_by(|a, b| b.time_ticks.cmp(&a.time_ticks)),
        _ => procs.sort_by_key(|p| p.pid),
    }
}

fn read_processes() -> Vec<ProcInfo> {
    let users = passwd_map();
    let page_kb = 4_u64;
    let mut out = Vec::new();
    if let Ok(entries) = fs::read_dir("/proc") {
        for ent in entries.flatten() {
            let name = ent.file_name();
            let pid_s = name.to_string_lossy();
            let Ok(pid) = pid_s.parse::<i32>() else { continue };
            let dir = ent.path();
            if let Some(p) = read_proc(pid, &dir, &users, page_kb) {
                out.push(p);
            }
        }
    }
    out
}

fn read_proc(pid: i32, dir: &Path, users: &HashMap<u32, String>, page_kb: u64) -> Option<ProcInfo> {
    let stat = fs::read_to_string(dir.join("stat")).ok()?;
    let rparen = stat.rfind(')')?;
    let comm = stat.get(1..rparen).unwrap_or("").to_string();
    let rest: Vec<&str> = stat.get(rparen + 2..)?.split_whitespace().collect();
    if rest.len() < 22 {
        return None;
    }
    let state = rest[0].chars().next().unwrap_or('?');
    let ppid = rest[1].parse().unwrap_or(0);
    let utime = rest[11].parse::<u64>().unwrap_or(0);
    let stime = rest[12].parse::<u64>().unwrap_or(0);
    let pri = rest[15].parse::<i64>().unwrap_or(0);
    let nice = rest[16].parse::<i64>().unwrap_or(0);
    let virt_kb = rest[20].parse::<u64>().unwrap_or(0) / 1024;
    let res_kb = rest[21].parse::<i64>().unwrap_or(0).max(0) as u64 * page_kb;

    let status = fs::read_to_string(dir.join("status")).unwrap_or_default();
    let uid = status.lines()
        .find_map(|l| l.strip_prefix("Uid:"))
        .and_then(|l| l.split_whitespace().next())
        .and_then(|v| v.parse::<u32>().ok())
        .unwrap_or(0);
    let shr_kb = status.lines()
        .find_map(|l| l.strip_prefix("RssFile:").or_else(|| l.strip_prefix("RssShmem:")))
        .and_then(|l| l.split_whitespace().next())
        .and_then(|v| v.parse::<u64>().ok())
        .unwrap_or(0);
    let user = users.get(&uid).cloned().unwrap_or_else(|| uid.to_string());
    let command = read_cmdline(dir).unwrap_or(comm);
    Some(ProcInfo { pid, ppid, uid, user, pri, nice, virt_kb, res_kb, shr_kb, state, time_ticks: utime + stime, command })
}

fn read_cmdline(dir: &Path) -> Option<String> {
    let bytes = fs::read(dir.join("cmdline")).ok()?;
    if bytes.is_empty() {
        return None;
    }
    let mut s = String::from_utf8_lossy(&bytes).replace('\0', " ");
    while s.ends_with(' ') {
        s.pop();
    }
    if s.is_empty() { None } else { Some(s) }
}

fn passwd_map() -> HashMap<u32, String> {
    let mut m = HashMap::new();
    if let Ok(text) = fs::read_to_string("/etc/passwd") {
        for line in text.lines() {
            let parts: Vec<&str> = line.split(':').collect();
            if parts.len() >= 3 {
                if let Ok(uid) = parts[2].parse::<u32>() {
                    m.insert(uid, parts[0].to_string());
                }
            }
        }
    }
    m
}

fn mem_info() -> (u64, u64) {
    let text = fs::read_to_string("/proc/meminfo").unwrap_or_default();
    let mut total: u64 = 0;
    let mut avail: u64 = 0;
    for line in text.lines() {
        if line.starts_with("MemTotal:") {
            total = line.split_whitespace().nth(1).and_then(|v| v.parse().ok()).unwrap_or(0);
        } else if line.starts_with("MemAvailable:") {
            avail = line.split_whitespace().nth(1).and_then(|v| v.parse().ok()).unwrap_or(0);
        }
    }
    (total.saturating_sub(avail), total)
}

fn meter(used: u64, total: u64) -> String {
    let width = 20;
    let filled = if total == 0 { 0 } else { ((used as f64 / total as f64) * width as f64).round() as usize }.min(width);
    format!("{}{} {}/{}", "|".repeat(filled), " ".repeat(width - filled), fmt_kb(used), fmt_kb(total))
}

fn fmt_kb(kb: u64) -> String {
    if kb >= 1024 * 1024 {
        format!("{:.1}G", kb as f64 / 1024.0 / 1024.0)
    } else if kb >= 1024 {
        format!("{}M", kb / 1024)
    } else {
        format!("{}", kb)
    }
}

fn fmt_time(ticks: u64) -> String {
    let secs = ticks / 100;
    format!("{}:{:02}.{:02}", secs / 60, secs % 60, ticks % 100)
}

fn uptime_text() -> String {
    let text = fs::read_to_string("/proc/uptime").unwrap_or_default();
    let secs = text.split_whitespace().next().and_then(|v| v.parse::<f64>().ok()).unwrap_or(0.0) as u64;
    let days = secs / 86400;
    let hours = (secs % 86400) / 3600;
    let mins = (secs % 3600) / 60;
    if days > 0 {
        format!("{} day{}, {:02}:{:02}", days, if days == 1 { "" } else { "s" }, hours, mins)
    } else {
        format!("{:02}:{:02}", hours, mins)
    }
}
