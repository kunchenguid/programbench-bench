use regex::Regex;
use std::env;
use std::fs;
use std::io::{self, IsTerminal, Read, Write};
use std::process::{self, Command, Stdio};

const HELP: &str = r#"Usage: peco [options] [FILE]

Options:
  -h, --help            show this help message and exit
  --query               initial value for query
  --rcfile              path to the settings file
  --version             print the version and exit
  -b, --buffer-size     number of lines to keep in search buffer
  --null                expect NUL (\0) as separator for target/output
  --initial-index       position of the initial index of the selection (0 base)
  --initial-filter      specify the default filter
  --prompt              specify the prompt string
  --layout              layout to be used. 'top-down', 'bottom-up', or 'top-down-query-bottom'. default is 'top-down'
  --select-1            select first item and immediately exit if the input contains only 1 item
  --exit-0              exit immediately with status 1 if the input is empty
  --select-all          select all items and immediately exit
  --on-cancel           specify action on user cancel. 'success' or 'error'.
                        default is 'success'. This may change in future versions
  --selection-prefix    use a prefix instead of changing line color to indicate currently selected lines.
                        default is to use colors. This option is experimental
  --exec                execute command instead of finishing/terminating peco.
                        Please note that this command will receive selected line(s) from stdin,
                        and will be executed via '/bin/sh -c' or 'cmd /c'
  --print-query         print out the current query as first line of output
  --ansi                enable ANSI color code support
  --height              display height in lines or percentage (e.g. '10', '50%')
"#;

#[derive(Clone)]
struct Item {
    display: String,
    output: String,
    plain: String,
}

struct Opts {
    query: String,
    rcfile: Option<String>,
    buffer_size: Option<usize>,
    null: bool,
    initial_index: usize,
    filter: String,
    prompt: String,
    layout: String,
    select_1: bool,
    exit_0: bool,
    select_all: bool,
    on_cancel_error: bool,
    selection_prefix: Option<String>,
    exec_cmd: Option<String>,
    print_query: bool,
    ansi: bool,
    height: Option<String>,
    file: Option<String>,
}

impl Default for Opts {
    fn default() -> Self {
        Self {
            query: String::new(),
            rcfile: None,
            buffer_size: None,
            null: false,
            initial_index: 0,
            filter: "IgnoreCase".to_string(),
            prompt: "QUERY>".to_string(),
            layout: "top-down".to_string(),
            select_1: false,
            exit_0: false,
            select_all: false,
            on_cancel_error: false,
            selection_prefix: None,
            exec_cmd: None,
            print_query: false,
            ansi: false,
            height: None,
            file: None,
        }
    }
}

fn main() {
    let opts = match parse_args() {
        Ok(ParseResult::Help) => {
            print!("\n{}\n", HELP);
            return;
        }
        Ok(ParseResult::Version) => {
            println!("peco version v0.5.11 (built with go1.25.0)");
            return;
        }
        Ok(ParseResult::Run(o)) => o,
        Err(e) => {
            eprintln!("{}\n\n{}\nError: failed to setup peco: failed to parse command line: failed to parse command line options: invalid command line options: {}", e, HELP, e);
            process::exit(1);
        }
    };

    if !valid_filter(&opts.filter) {
        eprintln!("Error: failed to setup peco: failed to apply configuration: failed to populate initial filter: failed to set filter: specified filter was not found");
        process::exit(1);
    }
    if !matches!(opts.layout.as_str(), "top-down" | "bottom-up" | "top-down-query-bottom") {
        eprintln!("Error: failed to setup peco: failed to apply configuration: invalid layout: {}", opts.layout);
        process::exit(1);
    }
    if let Some(path) = &opts.rcfile {
        if fs::metadata(path).is_err() {
            eprintln!("Error: failed to setup peco: failed to apply configuration: failed to load config file: open {}: no such file or directory", path);
            process::exit(1);
        }
    }

    let input = match read_input(opts.file.as_deref()) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("{}", e);
            process::exit(1);
        }
    };
    let mut items = parse_items(&input, opts.null, opts.ansi);
    if let Some(max) = opts.buffer_size {
        if items.len() > max {
            let start = items.len() - max;
            items = items[start..].to_vec();
        }
    }

    if opts.exit_0 && items.is_empty() {
        process::exit(1);
    }
    if opts.select_1 && items.len() == 1 {
        emit(&opts, &[items[0].clone()]);
        return;
    }

    if !io::stdin().is_terminal() || !io::stdout().is_terminal() {
        terminal_error();
    }

    if opts.select_all {
        emit(&opts, &items);
        return;
    }

    interactive(opts, items);
}

enum ParseResult {
    Help,
    Version,
    Run(Opts),
}

fn parse_args() -> Result<ParseResult, String> {
    let mut opts = Opts::default();
    let mut want_help = false;
    let mut want_version = false;
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => want_help = true,
            "--version" => want_version = true,
            "--query" => opts.query = need_value(&mut args, "--query")?,
            "--rcfile" => opts.rcfile = Some(need_value(&mut args, "--rcfile")?),
            "-b" | "--buffer-size" => {
                let v = need_value(&mut args, "-b, --buffer-size")?;
                opts.buffer_size = Some(v.parse::<usize>().map_err(|_| format!("invalid argument for flag `-b, --buffer-size' (expected int): strconv.ParseInt: parsing \"{}\": invalid syntax", v))?);
            }
            "--null" => opts.null = true,
            "--initial-index" => {
                let v = need_value(&mut args, "--initial-index")?;
                opts.initial_index = v.parse::<usize>().map_err(|_| format!("invalid argument for flag `--initial-index' (expected int): strconv.ParseInt: parsing \"{}\": invalid syntax", v))?;
            }
            "--initial-filter" => opts.filter = need_value(&mut args, "--initial-filter")?,
            "--prompt" => opts.prompt = need_value(&mut args, "--prompt")?,
            "--layout" => opts.layout = need_value(&mut args, "--layout")?,
            "--select-1" => opts.select_1 = true,
            "--exit-0" => opts.exit_0 = true,
            "--select-all" => opts.select_all = true,
            "--on-cancel" => {
                let v = need_value(&mut args, "--on-cancel")?;
                match v.as_str() {
                    "success" => opts.on_cancel_error = false,
                    "error" => opts.on_cancel_error = true,
                    _ => return Err(format!("invalid argument for flag `--on-cancel': {}", v)),
                }
            }
            "--selection-prefix" => opts.selection_prefix = Some(need_value(&mut args, "--selection-prefix")?),
            "--exec" => opts.exec_cmd = Some(need_value(&mut args, "--exec")?),
            "--print-query" => opts.print_query = true,
            "--ansi" => opts.ansi = true,
            "--height" => opts.height = Some(need_value(&mut args, "--height")?),
            _ if arg.starts_with("--query=") => opts.query = arg[8..].to_string(),
            _ if arg.starts_with("--rcfile=") => opts.rcfile = Some(arg[9..].to_string()),
            _ if arg.starts_with("--initial-filter=") => opts.filter = arg[17..].to_string(),
            _ if arg.starts_with("--prompt=") => opts.prompt = arg[9..].to_string(),
            _ if arg.starts_with("--layout=") => opts.layout = arg[9..].to_string(),
            _ if arg.starts_with("--on-cancel=") => opts.on_cancel_error = &arg[12..] == "error",
            _ if arg.starts_with("--height=") => opts.height = Some(arg[9..].to_string()),
            _ if arg.starts_with('-') => return Err(format!("unknown flag `{}`", arg.trim_start_matches('-'))),
            _ => {
                if opts.file.is_some() {
                    return Err(format!("unexpected argument `{}`", arg));
                }
                opts.file = Some(arg);
            }
        }
    }
    if want_help {
        Ok(ParseResult::Help)
    } else if want_version {
        Ok(ParseResult::Version)
    } else {
        Ok(ParseResult::Run(opts))
    }
}

fn need_value<I>(args: &mut std::iter::Peekable<I>, name: &str) -> Result<String, String>
where
    I: Iterator<Item = String>,
{
    args.next()
        .ok_or_else(|| format!("expected argument for flag `{}`", name))
}

fn valid_filter(name: &str) -> bool {
    matches!(name, "IgnoreCase" | "CaseSensitive" | "SmartCase" | "IRegexp" | "Regexp" | "Fuzzy")
}

fn read_input(path: Option<&str>) -> Result<String, String> {
    let mut data = String::new();
    if let Some(path) = path {
        fs::File::open(path)
            .map_err(|_| "Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address".to_string())?
            .read_to_string(&mut data)
            .map_err(|e| format!("Error: failed to read input: {}", e))?;
    } else {
        io::stdin()
            .read_to_string(&mut data)
            .map_err(|e| format!("Error: failed to read input: {}", e))?;
    }
    Ok(data)
}

fn parse_items(input: &str, nul: bool, ansi: bool) -> Vec<Item> {
    input
        .split_inclusive('\n')
        .map(|s| s.trim_end_matches('\n').trim_end_matches('\r'))
        .filter(|s| !s.is_empty())
        .map(|line| {
            let (display, output) = if nul {
                if let Some((d, o)) = line.split_once('\0') {
                    (d.to_string(), o.to_string())
                } else {
                    (line.to_string(), line.to_string())
                }
            } else {
                (line.to_string(), line.to_string())
            };
            let plain = if ansi { strip_ansi(&display) } else { display.clone() };
            Item { display, output, plain }
        })
        .collect()
}

fn terminal_error() -> ! {
    if env::var_os("TERM").is_none() {
        eprintln!("Error: failed to initialize screen: failed to create tcell screen: terminal entry not found: term not set");
    } else {
        eprintln!("Error: failed to initialize screen: failed to initialize tcell screen: open /dev/tty: no such device or address");
    }
    process::exit(1);
}

fn interactive(opts: Opts, items: Vec<Item>) {
    let mut query = opts.query.clone();
    let mut index = opts.initial_index;
    loop {
        let matches = filtered(&items, &query, &opts.filter);
        if !matches.is_empty() && index >= matches.len() {
            index = matches.len() - 1;
        }
        render(&opts, &query, &matches, index);
        let mut b = [0u8; 1];
        if io::stdin().read_exact(&mut b).is_err() {
            cancel(&opts);
        }
        match b[0] {
            b'\r' | b'\n' => {
                let selected = matches.get(index).cloned().into_iter().collect::<Vec<_>>();
                if let Some(cmd) = &opts.exec_cmd {
                    run_exec(cmd, &selected);
                    continue;
                }
                emit_query_and_items(&opts, &query, &selected);
                return;
            }
            0x1b | 0x03 => cancel(&opts),
            0x7f | 0x08 => {
                query.pop();
                index = 0;
            }
            byte if byte >= 0x20 => {
                query.push(byte as char);
                index = 0;
            }
            _ => {}
        }
    }
}

fn render(opts: &Opts, query: &str, matches: &[Item], index: usize) {
    eprint!("\r{} {} [{} ({}/{})]  ", opts.prompt, query, opts.filter, matches.len(), index.saturating_add(1));
    if let Some(item) = matches.get(index) {
        eprint!("{}", item.display);
    }
    let _ = io::stderr().flush();
}

fn cancel(opts: &Opts) -> ! {
    if opts.on_cancel_error {
        process::exit(1);
    }
    process::exit(0);
}

fn emit(opts: &Opts, items: &[Item]) {
    emit_query_and_items(opts, &opts.query, items);
}

fn emit_query_and_items(opts: &Opts, query: &str, items: &[Item]) {
    if opts.print_query {
        println!("{}", query);
    }
    for item in items {
        println!("{}", item.output);
    }
}

fn run_exec(cmd: &str, items: &[Item]) {
    let mut child = match Command::new("/bin/sh")
        .arg("-c")
        .arg(cmd)
        .stdin(Stdio::piped())
        .spawn()
    {
        Ok(c) => c,
        Err(_) => return,
    };
    if let Some(stdin) = child.stdin.as_mut() {
        for item in items {
            let _ = writeln!(stdin, "{}", item.output);
        }
    }
    let _ = child.wait();
}

fn filtered(items: &[Item], query: &str, filter: &str) -> Vec<Item> {
    let terms = parse_query(query);
    if terms.is_empty() {
        return items.to_vec();
    }
    items
        .iter()
        .filter(|item| matches_terms(&item.plain, &terms, filter))
        .cloned()
        .collect()
}

fn parse_query(query: &str) -> Vec<(bool, String)> {
    query
        .split_whitespace()
        .map(|term| {
            if term == "-" {
                (false, "-".to_string())
            } else if let Some(rest) = term.strip_prefix("\\-") {
                (false, format!("-{}", rest))
            } else if let Some(rest) = term.strip_prefix('-') {
                (true, rest.to_string())
            } else {
                (false, term.to_string())
            }
        })
        .filter(|(_, t)| !t.is_empty())
        .collect()
}

fn matches_terms(line: &str, terms: &[(bool, String)], filter: &str) -> bool {
    for (negative, term) in terms {
        let matched = match filter {
            "CaseSensitive" => line.contains(term),
            "SmartCase" => {
                if terms.iter().all(|(_, t)| t.chars().all(|c| !c.is_uppercase())) {
                    line.to_lowercase().contains(&term.to_lowercase())
                } else {
                    line.contains(term)
                }
            }
            "Regexp" => Regex::new(term).map(|r| r.is_match(line)).unwrap_or(false),
            "IRegexp" => Regex::new(&format!("(?i){}", term)).map(|r| r.is_match(line)).unwrap_or(false),
            "Fuzzy" => fuzzy_match(line, term),
            _ => line.to_lowercase().contains(&term.to_lowercase()),
        };
        if *negative && matched {
            return false;
        }
        if !*negative && !matched {
            return false;
        }
    }
    true
}

fn fuzzy_match(line: &str, pat: &str) -> bool {
    let mut chars = pat.chars().map(|c| c.to_ascii_lowercase());
    let mut want = chars.next();
    if want.is_none() {
        return true;
    }
    for c in line.chars().map(|c| c.to_ascii_lowercase()) {
        if Some(c) == want {
            want = chars.next();
            if want.is_none() {
                return true;
            }
        }
    }
    false
}

fn strip_ansi(s: &str) -> String {
    let re = Regex::new(r"\x1b\[[0-9;?]*[ -/]*[@-~]").unwrap();
    re.replace_all(s, "").into_owned()
}
