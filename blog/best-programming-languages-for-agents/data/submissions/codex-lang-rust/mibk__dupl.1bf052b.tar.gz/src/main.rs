use std::collections::{BTreeMap, BTreeSet};
use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::{Path, PathBuf};
use std::process;

const USAGE: &str = "Usage: dupl [flags] [paths]\n\nPaths:\n  If the given path is a file, dupl will use it regardless of\n  the file extension. If it is a directory, it will recursively\n  search for *.go files in that directory.\n\n  If no path is given, dupl will recursively search for *.go\n  files in the current directory.\n\nFlags:\n  -files\n    \tread file names from stdin one at each line\n  -html\n    \toutput the results as HTML, including duplicate code fragments\n  -plumbing\n    \tplumbing (easy-to-parse) output for consumption by scripts or tools\n  -t, -threshold size\n    \tminimum token sequence size as a clone (default 15)\n  -vendor\n    \tcheck files in vendor directory\n  -v, -verbose\n    \texplain what is being done\n\nExamples:\n  dupl -t 100\n    \tSearch clones in the current directory of size at least\n    \t100 tokens.\n  dupl $(find app/ -name '*_test.go')\n    \tSearch for clones in tests in the app directory.\n  find app/ -name '*_test.go' |dupl -files\n    \tThe same as above.\n";

#[derive(Default)]
struct Opts {
    files_stdin: bool,
    html: bool,
    plumbing: bool,
    threshold: usize,
    vendor: bool,
    verbose: bool,
    paths: Vec<String>,
}

#[derive(Clone)]
struct FileData {
    path: String,
    text: String,
    line_offsets: Vec<usize>,
}

#[derive(Clone)]
struct Token {
    kind: String,
    file: usize,
    line: usize,
}

#[derive(Clone, Debug, Eq, PartialEq, Hash, Ord, PartialOrd)]
struct Span {
    file: usize,
    start_tok: usize,
    end_tok: usize,
    start_line: usize,
    end_line: usize,
}

#[derive(Clone)]
struct Group {
    spans: Vec<Span>,
}

fn main() {
    let opts = match parse_args() {
        Ok(o) => o,
        Err((msg, code)) => {
            eprint!("{}", msg);
            eprint!("{}", USAGE);
            process::exit(code);
        }
    };

    let mut paths = if opts.files_stdin {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).unwrap();
        s.lines().map(|l| l.to_string()).filter(|l| !l.is_empty()).collect()
    } else if opts.paths.is_empty() {
        vec![".".to_string()]
    } else {
        opts.paths.clone()
    };
    if paths.is_empty() {
        paths.push(".".to_string());
    }

    let files = match collect_files(&paths, opts.vendor) {
        Ok(f) => f,
        Err(e) => {
            eprintln!("{}", e);
            process::exit(1);
        }
    };

    let mut all_tokens = Vec::new();
    let mut good_files = Vec::new();
    for p in files {
        match fs::read_to_string(&p) {
            Ok(text) => {
                let idx = good_files.len();
                let display = clean_path(&p);
                let f = FileData { path: display, line_offsets: line_offsets(&text), text: text.clone() };
                let toks = lex(&text, idx);
                if toks.is_empty() && looks_invalid_go(&text) {
                    eprintln!("{}:1:1: expected 'package', found 'EOF'", f.path);
                }
                all_tokens.extend(toks);
                good_files.push(f);
            }
            Err(e) => eprintln!("{}", e),
        }
    }

    if opts.verbose {
        eprintln!("2026/05/29 00:00:00 Building suffix tree");
        eprintln!("2026/05/29 00:00:00 Searching for clones");
    }

    let groups = find_groups(&all_tokens, opts.threshold.max(1));
    if opts.html {
        print_html(&groups, &good_files);
    } else if opts.plumbing {
        print_plumbing(&groups, &good_files);
    } else {
        print_default(&groups, &good_files);
    }
}

fn parse_args() -> Result<Opts, (String, i32)> {
    let mut o = Opts { threshold: 15, ..Default::default() };
    let args: Vec<String> = env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if !a.starts_with('-') || a == "-" {
            o.paths.extend(args[i..].iter().cloned());
            break;
        }
        match a.as_str() {
            "-h" | "--help" | "-help" => return Err((String::new(), 2)),
            "-files" => o.files_stdin = true,
            "-html" => o.html = true,
            "-plumbing" => o.plumbing = true,
            "-vendor" => o.vendor = true,
            "-v" | "-verbose" => o.verbose = true,
            "-t" | "-threshold" => {
                i += 1;
                if i >= args.len() { return Err((format!("flag needs an argument: {}\n", a), 2)); }
                o.threshold = args[i].parse().map_err(|_| (format!("invalid value {:?} for flag -t: parse error\n", args[i]), 2))?;
            }
            _ if a.starts_with("-t=") => {
                let v = &a[3..];
                o.threshold = v.parse().map_err(|_| (format!("invalid value {:?} for flag -t: parse error\n", v), 2))?;
            }
            _ if a.starts_with("-threshold=") => {
                let v = &a[11..];
                o.threshold = v.parse().map_err(|_| (format!("invalid value {:?} for flag -threshold: parse error\n", v), 2))?;
            }
            _ => return Err((format!("flag provided but not defined: {}\n", a), 2)),
        }
        i += 1;
    }
    Ok(o)
}

fn collect_files(paths: &[String], include_vendor: bool) -> Result<Vec<PathBuf>, String> {
    let mut out = Vec::new();
    for p in paths {
        let path = PathBuf::from(p);
        let md = fs::metadata(&path).map_err(|e| format!("lstat {}: {}", p, e))?;
        if md.is_file() {
            out.push(path);
        } else if md.is_dir() {
            walk_dir(&path, include_vendor, &mut out)?;
        }
    }
    out.sort_by(|a,b| clean_path(a).cmp(&clean_path(b)));
    Ok(out)
}

fn walk_dir(dir: &Path, include_vendor: bool, out: &mut Vec<PathBuf>) -> Result<(), String> {
    let mut ents = Vec::new();
    for e in fs::read_dir(dir).map_err(|e| format!("{}", e))? {
        ents.push(e.map_err(|e| format!("{}", e))?.path());
    }
    ents.sort();
    for p in ents {
        let name = p.file_name().and_then(|s| s.to_str()).unwrap_or("");
        if name.starts_with('.') { continue; }
        if p.is_dir() {
            if !include_vendor && name == "vendor" { continue; }
            walk_dir(&p, include_vendor, out)?;
        } else if p.extension().and_then(|s| s.to_str()) == Some("go") {
            out.push(p);
        }
    }
    Ok(())
}

fn clean_path(p: &Path) -> String {
    let s = p.to_string_lossy().to_string();
    if let Some(rest) = s.strip_prefix("./") { rest.to_string() } else { s }
}

fn line_offsets(s: &str) -> Vec<usize> {
    let mut v = vec![0];
    for (i, b) in s.bytes().enumerate() { if b == b'\n' { v.push(i + 1); } }
    v
}

fn lex(s: &str, file: usize) -> Vec<Token> {
    let bytes = s.as_bytes();
    let mut out = Vec::new();
    let mut i = 0usize;
    let mut line = 1usize;
    while i < bytes.len() {
        let c = bytes[i];
        if c == b'\n' { line += 1; i += 1; continue; }
        if c.is_ascii_whitespace() { i += 1; continue; }
        if c == b'/' && i + 1 < bytes.len() && bytes[i+1] == b'/' {
            i += 2;
            while i < bytes.len() && bytes[i] != b'\n' { i += 1; }
            continue;
        }
        if c == b'/' && i + 1 < bytes.len() && bytes[i+1] == b'*' {
            i += 2;
            while i + 1 < bytes.len() && !(bytes[i] == b'*' && bytes[i+1] == b'/') {
                if bytes[i] == b'\n' { line += 1; }
                i += 1;
            }
            i = (i + 2).min(bytes.len());
            continue;
        }
        if is_ident_start(c) {
            let start = i;
            i += 1;
            while i < bytes.len() && is_ident_continue(bytes[i]) { i += 1; }
            let word = &s[start..i];
            let kind = if is_keyword(word) { word.to_string() } else { "ID".to_string() };
            out.push(Token { kind, file, line });
            continue;
        }
        if c.is_ascii_digit() {
            i += 1;
            while i < bytes.len() && (bytes[i].is_ascii_alphanumeric() || bytes[i] == b'.' || bytes[i] == b'_') { i += 1; }
            out.push(Token { kind: "LIT".to_string(), file, line });
            continue;
        }
        if c == b'"' || c == b'\'' || c == b'`' {
            let quote = c;
            i += 1;
            while i < bytes.len() {
                if bytes[i] == b'\n' { line += 1; }
                if quote != b'`' && bytes[i] == b'\\' { i = (i + 2).min(bytes.len()); continue; }
                if bytes[i] == quote { i += 1; break; }
                i += 1;
            }
            out.push(Token { kind: "LIT".to_string(), file, line });
            continue;
        }
        let two = if i + 1 < bytes.len() { Some(&s[i..i+2]) } else { None };
        let three = if i + 2 < bytes.len() { Some(&s[i..i+3]) } else { None };
        if let Some(op) = three { if ["...", "<<=", ">>=", "&^="].contains(&op) { out.push(Token{kind:op.to_string(),file,line}); i+=3; continue; } }
        if let Some(op) = two { if [":=", "++", "--", "==", "!=", "<=", ">=", "&&", "||", "<-", "+=", "-=", "*=", "/=", "%=", "&=", "|=", "^=", "<<", ">>", "&^"].contains(&op) { out.push(Token{kind:op.to_string(),file,line}); i+=2; continue; } }
        if c != b';' { out.push(Token { kind: (c as char).to_string(), file, line }); }
        i += 1;
    }
    out
}

fn is_ident_start(c: u8) -> bool { c == b'_' || c.is_ascii_alphabetic() }
fn is_ident_continue(c: u8) -> bool { is_ident_start(c) || c.is_ascii_digit() }
fn is_keyword(w: &str) -> bool {
    matches!(w, "break"|"default"|"func"|"interface"|"select"|"case"|"defer"|"go"|"map"|"struct"|"chan"|"else"|"goto"|"package"|"switch"|"const"|"fallthrough"|"if"|"range"|"type"|"continue"|"for"|"import"|"return"|"var")
}
fn looks_invalid_go(s: &str) -> bool { !s.trim().is_empty() && !s.contains("package") }

fn find_groups(tokens: &[Token], threshold: usize) -> Vec<Group> {
    let mut by_sig: BTreeMap<Vec<String>, BTreeSet<Span>> = BTreeMap::new();
    for (start, end) in candidate_spans(tokens, threshold) {
        let sig: Vec<String> = tokens[start..end].iter().map(|t| t.kind.clone()).collect();
        by_sig.entry(sig).or_default().insert(make_span(tokens, start, end));
    }
    let mut groups: Vec<Group> = by_sig.into_values()
        .filter(|s| s.len() >= 2)
        .map(|s| Group { spans: s.into_iter().collect() })
        .collect();
    groups.sort_by(|a,b| a.spans[0].cmp(&b.spans[0]));
    groups
}

fn candidate_spans(tokens: &[Token], threshold: usize) -> Vec<(usize, usize)> {
    let mut spans = Vec::new();
    let mut i = 0usize;
    while i < tokens.len() {
        if tokens[i].kind == "func" {
            if let Some(end) = balanced_construct_end(tokens, i) {
                if end - i >= threshold { spans.push((i, end)); }
                i = end;
                continue;
            }
        }
        i += 1;
    }
    for i in 0..tokens.len() {
        if matches!(tokens[i].kind.as_str(), "for" | "if" | "switch" | "select") {
            if let Some(end) = balanced_construct_end(tokens, i) {
                if end - i >= threshold { spans.push((i, end)); }
            }
        }
    }
    spans
}

fn balanced_construct_end(tokens: &[Token], start: usize) -> Option<usize> {
    let file = tokens[start].file;
    let mut brace = None;
    for i in start..tokens.len() {
        if tokens[i].file != file { break; }
        if tokens[i].kind == "{" { brace = Some(i); break; }
        if tokens[i].kind == ";" { break; }
    }
    let b = brace?;
    let mut depth = 0isize;
    for i in b..tokens.len() {
        if tokens[i].file != file { break; }
        if tokens[i].kind == "{" { depth += 1; }
        if tokens[i].kind == "}" {
            depth -= 1;
            if depth == 0 { return Some(i + 1); }
        }
    }
    None
}
fn make_span(tokens: &[Token], start: usize, end: usize) -> Span {
    Span { file: tokens[start].file, start_tok: start, end_tok: end, start_line: tokens[start].line, end_line: tokens[end-1].line }
}
fn print_default(groups: &[Group], files: &[FileData]) {
    for g in groups {
        println!("found {} clones:", g.spans.len());
        for s in &g.spans {
            println!("  {}:{},{}", files[s.file].path, s.start_line, s.end_line);
        }
        println!();
    }
    println!("Found total {} clone groups.", groups.len());
}

fn print_plumbing(groups: &[Group], files: &[FileData]) {
    for g in groups {
        for i in 0..g.spans.len() {
            let a = &g.spans[i];
            let b = &g.spans[(i+1)%g.spans.len()];
            println!("{}:{}-{}: duplicate of {}:{}-{}", files[a.file].path, a.start_line, a.end_line, files[b.file].path, b.start_line, b.end_line);
        }
    }
}

fn print_html(groups: &[Group], files: &[FileData]) {
    println!("<!DOCTYPE html>\n<meta charset=\"utf-8\"/>\n<title>Duplicates</title>\n<style>\n\tpre {{\n\t\tbackground-color: #FFD;\n\t\tborder: 1px solid #E2E2E2;\n\t\tpadding: 1ex;\n\t}}\n</style>");
    for (idx, g) in groups.iter().enumerate() {
        println!("<h1>#{} found {} clones</h1>", idx + 1, g.spans.len());
        for s in &g.spans {
            println!("<h2>{}:{}</h2>", files[s.file].path, s.start_line);
            println!("<pre>{}</pre>", html_escape(&snippet(&files[s.file], s.start_line, s.end_line)));
        }
    }
}

fn snippet(file: &FileData, start_line: usize, end_line: usize) -> String {
    let start = *file.line_offsets.get(start_line.saturating_sub(1)).unwrap_or(&0);
    let end = if end_line < file.line_offsets.len() { file.line_offsets[end_line].saturating_sub(1) } else { file.text.len() };
    file.text[start..end.min(file.text.len())].to_string()
}

fn html_escape(s: &str) -> String {
    let mut out = String::new();
    for ch in s.chars() {
        match ch { '&' => out.push_str("&amp;"), '<' => out.push_str("&lt;"), '>' => out.push_str("&gt;"), '"' => out.push_str("&#34;"), '\'' => out.push_str("&#39;"), _ => out.push(ch) }
    }
    out
}
