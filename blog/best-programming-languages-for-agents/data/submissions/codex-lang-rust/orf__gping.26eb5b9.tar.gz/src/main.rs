use clap::{Arg, ArgAction, Command};
use std::io::{self, IsTerminal, Write};
use std::net::ToSocketAddrs;
use std::process::{Command as ProcessCommand, Stdio};
use std::thread;
use std::time::{Duration, Instant};

const ABOUT: &str = "Ping, but with a graph.";
const LONG_VERSION: &str = "gping 1.20.1\ncommit_hash: d67d2aeb\nbuild_time: 2026-04-17 19:59:37 +00:00\nbuild_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu";

#[derive(Debug)]
struct Opts {
    cmd: bool,
    watch_interval: Option<f64>,
    buffer: u64,
    ipv4: bool,
    ipv6: bool,
    interface: Option<String>,
    simple_graphics: bool,
    vertical_margin: u64,
    horizontal_margin: u64,
    colors: Vec<String>,
    clear: bool,
    ping_args: Vec<String>,
    targets: Vec<String>,
}

fn cli() -> Command {
    Command::new("executable")
        .bin_name("executable")
        .about(ABOUT)
        .version(LONG_VERSION)
        .disable_help_flag(true)
        .disable_version_flag(true)
        .arg(Arg::new("cmd").long("cmd").help("Graph the execution time for a list of commands rather than pinging hosts").action(ArgAction::SetTrue))
        .arg(Arg::new("watch_interval").short('n').long("watch-interval").value_name("WATCH_INTERVAL").help("Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5").value_parser(clap::value_parser!(f64)))
        .arg(Arg::new("buffer").short('b').long("buffer").value_name("BUFFER").help("Determines the number of seconds to display in the graph").default_value("30").value_parser(clap::value_parser!(u64)))
        .arg(Arg::new("ipv4").short('4').help("Resolve ping targets to IPv4 address").action(ArgAction::SetTrue).conflicts_with("ipv6"))
        .arg(Arg::new("ipv6").short('6').help("Resolve ping targets to IPv6 address").action(ArgAction::SetTrue))
        .arg(Arg::new("interface").short('i').long("interface").value_name("INTERFACE").help("Interface to use when pinging"))
        .arg(Arg::new("simple_graphics").short('s').long("simple-graphics").help("").action(ArgAction::SetTrue))
        .arg(Arg::new("vertical_margin").long("vertical-margin").value_name("VERTICAL_MARGIN").help("Vertical margin around the graph (top and bottom)").default_value("1").value_parser(clap::value_parser!(u64)))
        .arg(Arg::new("horizontal_margin").long("horizontal-margin").value_name("HORIZONTAL_MARGIN").help("Horizontal margin around the graph (left and right)").default_value("0").value_parser(clap::value_parser!(u64)))
        .arg(
            Arg::new("color")
                .short('c')
                .long("color")
                .value_name("color")
                .help("Assign color to a graph entry.\n\nThis option can be defined more than once as a comma separated string, and the\norder which the colors are provided will be matched against the hosts or\ncommands passed to gping.\n\nHexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the\nfollowing color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',\n'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',\n'light-blue', 'light-magenta', 'light-cyan', and 'white'")
                .action(ArgAction::Append)
                .value_delimiter(','),
        )
        .arg(Arg::new("clear").long("clear").help("Clear the graph from the terminal after closing the program").action(ArgAction::SetTrue))
        .arg(Arg::new("ping_args").long("ping-args").value_name("PING_ARGS").help("Extra arguments to pass to `ping`. These are platform dependent").num_args(0..).trailing_var_arg(true).allow_hyphen_values(true))
        .arg(Arg::new("help").short('h').long("help").help("Print help").action(ArgAction::Help))
        .arg(Arg::new("version").short('V').long("version").help("Print version").action(ArgAction::SetTrue))
        .arg(
            Arg::new("hosts_or_commands")
                .value_name("HOSTS_OR_COMMANDS")
                .help("Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1")
                .num_args(0..),
        )
}

fn main() {
    let matches = cli().get_matches();
    if matches.get_flag("version") {
        println!("{LONG_VERSION}");
        return;
    }
    let opts = Opts {
        cmd: matches.get_flag("cmd"),
        watch_interval: matches.get_one::<f64>("watch_interval").copied(),
        buffer: *matches.get_one::<u64>("buffer").unwrap_or(&30),
        ipv4: matches.get_flag("ipv4"),
        ipv6: matches.get_flag("ipv6"),
        interface: matches.get_one::<String>("interface").cloned(),
        simple_graphics: matches.get_flag("simple_graphics"),
        vertical_margin: *matches.get_one::<u64>("vertical_margin").unwrap_or(&1),
        horizontal_margin: *matches.get_one::<u64>("horizontal_margin").unwrap_or(&0),
        colors: matches
            .get_many::<String>("color")
            .map(|vals| vals.cloned().collect())
            .unwrap_or_default(),
        clear: matches.get_flag("clear"),
        ping_args: matches
            .get_many::<String>("ping_args")
            .map(|vals| vals.cloned().collect())
            .unwrap_or_default(),
        targets: matches
            .get_many::<String>("hosts_or_commands")
            .map(|vals| vals.cloned().collect())
            .unwrap_or_default(),
    };

    if let Err(err) = run(opts) {
        eprintln!("{err}");
        std::process::exit(1);
    }
}

fn run(opts: Opts) -> Result<(), String> {
    if opts.targets.is_empty() {
        return Err("Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.".to_string());
    }
    validate_colors(&opts.colors)?;

    let interval = opts.watch_interval.unwrap_or(if opts.cmd { 0.5 } else { 0.2 });
    let interval = if interval.is_sign_negative() { 0.0 } else { interval };

    if opts.cmd {
        if !io::stdout().is_terminal() {
            return Err("Error: No such device or address (os error 6)".to_string());
        }
        run_cmd_loop(&opts.targets, interval, opts.clear)
    } else {
        let expanded: Vec<String> = opts.targets.iter().map(|h| expand_cloud(h)).collect();
        for host in &expanded {
            resolve_host(host, opts.ipv4, opts.ipv6)?;
        }
        detect_ping()?;
        if !io::stdout().is_terminal() {
            return Err("Error: No such device or address (os error 6)".to_string());
        }
        run_ping_loop(&expanded, interval, opts)
    }
}

fn expand_cloud(host: &str) -> String {
    if let Some(region) = host.strip_prefix("aws:") {
        format!("ec2.{region}.amazonaws.com")
    } else {
        host.to_string()
    }
}

fn resolve_host(host: &str, ipv4: bool, ipv6: bool) -> Result<(), String> {
    let query = if host.contains(':') && !host.starts_with('[') && host.matches(':').count() > 1 {
        format!("[{host}]:0")
    } else {
        format!("{host}:0")
    };
    match query.to_socket_addrs() {
        Ok(addrs) => {
            let found = addrs.into_iter().any(|addr| {
                (!ipv4 && !ipv6) || (ipv4 && addr.is_ipv4()) || (ipv6 && addr.is_ipv6())
            });
            if found {
                Ok(())
            } else {
                Err(format!("Error: Resolving {host}\n\nCaused by:\n    no address found"))
            }
        }
        Err(err) => Err(format!("Error: Resolving {host}\n\nCaused by:\n    {err}")),
    }
}

fn detect_ping() -> Result<(), String> {
    match ProcessCommand::new("ping")
        .arg("-V")
        .stdin(Stdio::null())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .output()
    {
        Ok(output) if output.status.success() || !output.stdout.is_empty() || !output.stderr.is_empty() => Ok(()),
        _ => Err("Error: Could not detect ping. Stderr: []\nStdout: []".to_string()),
    }
}

fn validate_colors(colors: &[String]) -> Result<(), String> {
    for color in colors {
        if is_color(color) {
            continue;
        }
        return Err(format!(
            "Error: Invalid color code: `{color}`\n\nCaused by:\n    Failed to parse Colors"
        ));
    }
    Ok(())
}

fn is_color(color: &str) -> bool {
    matches!(
        color,
        "black"
            | "red"
            | "green"
            | "yellow"
            | "blue"
            | "magenta"
            | "cyan"
            | "gray"
            | "grey"
            | "dark-gray"
            | "dark-grey"
            | "light-gray"
            | "light-grey"
            | "light-red"
            | "light-green"
            | "light-yellow"
            | "light-blue"
            | "light-magenta"
            | "light-cyan"
            | "white"
    ) || is_hex_color(color)
}

fn is_hex_color(color: &str) -> bool {
    color.len() == 7
        && color.starts_with('#')
        && color.as_bytes()[1..].iter().all(|b| b.is_ascii_hexdigit())
}

fn run_cmd_loop(commands: &[String], interval: f64, clear: bool) -> Result<(), String> {
    print!("\x1b[?1049h\x1b[?25l");
    let _ = io::stdout().flush();
    loop {
        print!("\x1b[2J\x1b[H");
        println!("gping");
        for command in commands {
            let start = Instant::now();
            let status = ProcessCommand::new("sh")
                .arg("-c")
                .arg(command)
                .stdin(Stdio::null())
                .stdout(Stdio::null())
                .stderr(Stdio::null())
                .status();
            let elapsed = start.elapsed().as_secs_f64() * 1000.0;
            match status {
                Ok(status) => println!("{command}: {:.0} ms ({status})", elapsed),
                Err(err) => println!("{command}: {err}"),
            }
        }
        let _ = io::stdout().flush();
        thread::sleep(Duration::from_secs_f64(interval));
        if clear {
            print!("\x1b[2J\x1b[H");
        }
    }
}

fn run_ping_loop(hosts: &[String], interval: f64, opts: Opts) -> Result<(), String> {
    let _ = (
        opts.buffer,
        opts.interface.as_deref(),
        opts.simple_graphics,
        opts.vertical_margin,
        opts.horizontal_margin,
        opts.ping_args.len(),
    );
    print!("\x1b[?1049h\x1b[?25l");
    let _ = io::stdout().flush();
    loop {
        print!("\x1b[2J\x1b[H");
        println!("gping");
        for host in hosts {
            println!("{host}: waiting for ping data");
        }
        let _ = io::stdout().flush();
        thread::sleep(Duration::from_secs_f64(interval));
    }
}
