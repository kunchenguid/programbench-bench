use std::env;
use std::fs::File;
use std::io::{self, Read, Write};
use std::process;

#[derive(Clone, Copy, PartialEq, Eq)]
enum Format {
    Octal,
    LowerHex,
    UpperHex,
    Binary,
}

#[derive(Default)]
struct Opts {
    cols: Option<usize>,
    len: Option<usize>,
    format: Option<Format>,
    color: Option<bool>,
    array: Option<char>,
    func: Option<usize>,
    places: Option<usize>,
    prefix: Option<bool>,
    input: Option<String>,
}

fn main() {
    let opts = match parse_args(env::args().skip(1).collect()) {
        Ok(ParseResult::Run(opts)) => opts,
        Ok(ParseResult::Exit) => return,
        Err(msg) => {
            eprintln!("{msg}");
            process::exit(2);
        }
    };

    if let Some(n) = opts.func {
        let places = opts.places.unwrap_or(4);
        print_func(n, places);
        return;
    }

    let mut data = match read_input(opts.input.as_deref()) {
        Ok(data) => data,
        Err(err) => {
            eprintln!("error: {err}");
            process::exit(1);
        }
    };
    if let Some(len) = opts.len {
        if len > 0 && len < data.len() {
            data.truncate(len);
        }
    }

    if let Some(array) = opts.array {
        print_array(&data, array);
    } else {
        print_dump(&data, &opts);
    }
}

enum ParseResult {
    Run(Opts),
    Exit,
}

fn parse_args(args: Vec<String>) -> Result<ParseResult, String> {
    let mut opts = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "-h" || arg == "--help" {
            print_help();
            return Ok(ParseResult::Exit);
        }
        if arg == "-V" || arg == "--version" {
            println!("hx 0.7.0");
            return Ok(ParseResult::Exit);
        }
        if arg == "--" {
            if i + 1 < args.len() {
                opts.input = Some(args[i + 1].clone());
            }
            break;
        }

        if let Some(value) = arg.strip_prefix("--cols=") {
            opts.cols = Some(parse_usize("-c, --cols <integer>", value)?);
        } else if arg == "--cols" || arg == "-c" {
            i += 1;
            opts.cols = Some(parse_usize("-c, --cols <integer>", need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-c").filter(|s| !s.is_empty()) {
            opts.cols = Some(parse_usize("-c, --cols <integer>", value)?);
        } else if let Some(value) = arg.strip_prefix("--len=") {
            opts.len = Some(parse_usize("-l, --len <integer>", value)?);
        } else if arg == "--len" || arg == "-l" {
            i += 1;
            opts.len = Some(parse_usize("-l, --len <integer>", need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-l").filter(|s| !s.is_empty()) {
            opts.len = Some(parse_usize("-l, --len <integer>", value)?);
        } else if let Some(value) = arg.strip_prefix("--format=") {
            opts.format = Some(parse_format(value)?);
        } else if arg == "--format" || arg == "-f" {
            i += 1;
            opts.format = Some(parse_format(need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-f").filter(|s| !s.is_empty()) {
            opts.format = Some(parse_format(value)?);
        } else if let Some(value) = arg.strip_prefix("--color=") {
            opts.color = Some(parse_bool_choice("--color <color>", value)?);
        } else if arg == "--color" || arg == "-t" {
            i += 1;
            opts.color = Some(parse_bool_choice("--color <color>", need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-t").filter(|s| !s.is_empty()) {
            opts.color = Some(parse_bool_choice("--color <color>", value)?);
        } else if let Some(value) = arg.strip_prefix("--array=") {
            opts.array = Some(parse_array(value)?);
        } else if arg == "--array" || arg == "-a" {
            i += 1;
            opts.array = Some(parse_array(need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-a").filter(|s| !s.is_empty()) {
            opts.array = Some(parse_array(value)?);
        } else if let Some(value) = arg.strip_prefix("--func=") {
            opts.func = Some(parse_usize("-u, --func <integer>", value)?);
        } else if arg == "--func" || arg == "-u" {
            i += 1;
            opts.func = Some(parse_usize("-u, --func <integer>", need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-u").filter(|s| !s.is_empty()) {
            opts.func = Some(parse_usize("-u, --func <integer>", value)?);
        } else if let Some(value) = arg.strip_prefix("--places=") {
            opts.places = Some(parse_usize("-p, --places <integer>", value)?);
        } else if arg == "--places" || arg == "-p" {
            i += 1;
            opts.places = Some(parse_usize("-p, --places <integer>", need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-p").filter(|s| !s.is_empty()) {
            opts.places = Some(parse_usize("-p, --places <integer>", value)?);
        } else if let Some(value) = arg.strip_prefix("--prefix=") {
            opts.prefix = Some(parse_bool_choice("--prefix <prefix>", value)?);
        } else if arg == "--prefix" || arg == "-r" {
            i += 1;
            opts.prefix = Some(parse_bool_choice("--prefix <prefix>", need_value(arg, &args, i)?)?);
        } else if let Some(value) = arg.strip_prefix("-r").filter(|s| !s.is_empty()) {
            opts.prefix = Some(parse_bool_choice("--prefix <prefix>", value)?);
        } else if arg.starts_with('-') {
            return Err(format!(
                "error: unexpected argument '{arg}' found\n\n  tip: to pass '{arg}' as a value, use '-- {arg}'\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'."
            ));
        } else {
            opts.input = Some(arg.clone());
        }
        i += 1;
    }
    Ok(ParseResult::Run(opts))
}

fn need_value<'a>(flag: &str, args: &'a [String], i: usize) -> Result<&'a str, String> {
    args.get(i)
        .map(String::as_str)
        .ok_or_else(|| format!("error: a value is required for '{flag}' but none was supplied"))
}

fn parse_usize(label: &str, value: &str) -> Result<usize, String> {
    value.parse::<usize>().map_err(|e| format!("{label} expected. {e:?}\nerror: {e}"))
}

fn parse_format(value: &str) -> Result<Format, String> {
    match value {
        "o" => Ok(Format::Octal),
        "x" => Ok(Format::LowerHex),
        "X" => Ok(Format::UpperHex),
        "b" => Ok(Format::Binary),
        _ => Err(format!("error: invalid value '{value}' for '--format <format>'\n  [possible values: o, x, X, b]\n\nFor more information, try '--help'.")),
    }
}

fn parse_array(value: &str) -> Result<char, String> {
    let mut chars = value.chars();
    let ch = chars.next().unwrap_or('\0');
    if chars.next().is_none() && matches!(ch, 'r' | 'c' | 'g' | 'p' | 'k' | 'j' | 's' | 'f') {
        Ok(ch)
    } else {
        Err(format!("error: invalid value '{value}' for '--array <array_format>'\n  [possible values: r, c, g, p, k, j, s, f]\n\nFor more information, try '--help'."))
    }
}

fn parse_bool_choice(label: &str, value: &str) -> Result<bool, String> {
    match value {
        "0" => Ok(false),
        "1" => Ok(true),
        _ => Err(format!("error: invalid value '{value}' for '{label}'\n  [possible values: 0, 1]\n\nFor more information, try '--help'.")),
    }
}

fn print_help() {
    println!("Futuristic take on hexdump, made in Rust.\n");
    println!();
    println!("Usage: executable [OPTIONS] [INPUTFILE]\n");
    println!("Arguments:");
    println!("  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin\n");
    println!("Options:");
    println!("  -c, --cols <columns>        Set column length");
    println!("  -l, --len <len>             Set <len> bytes to read");
    println!("  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]");
    println!("  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]");
    println!("  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]");
    println!("  -u, --func <func_length>    Set function wave length");
    println!("  -p, --places <func_places>  Set function wave output decimal places");
    println!("  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]");
    println!("  -h, --help                  Print help");
    println!("  -V, --version               Print version");
}

fn read_input(path: Option<&str>) -> io::Result<Vec<u8>> {
    let mut data = Vec::new();
    match path {
        Some(path) => File::open(path)?.read_to_end(&mut data)?,
        None => io::stdin().read_to_end(&mut data)?,
    };
    Ok(data)
}

fn print_func(len: usize, places: usize) {
    let mut out = String::new();
    for i in 0..len {
        let value = ((i as f64) * std::f64::consts::PI / (2.0 * len as f64)).sin();
        out.push_str(&format!("{value:.places$},"));
    }
    println!("{out}");
}

fn octet(byte: u8, format: Format, prefix: bool) -> String {
    match (format, prefix) {
        (Format::Octal, true) => format!("0o{byte:04o}"),
        (Format::Octal, false) => format!("{byte:04o}"),
        (Format::LowerHex, true) => format!("0x{byte:02x}"),
        (Format::LowerHex, false) => format!("{byte:02x}"),
        (Format::UpperHex, true) => format!("0x{byte:02X}"),
        (Format::UpperHex, false) => format!("{byte:02X}"),
        (Format::Binary, true) => format!("0b{byte:08b}"),
        (Format::Binary, false) => format!("{byte:08b}"),
    }
}

fn colorize(s: &str, byte: u8, color: bool) -> String {
    if color {
        format!("\x1b[38;5;{byte}m{s}\x1b[0m")
    } else {
        s.to_string()
    }
}

fn printable(byte: u8) -> char {
    if (0x20..=0x7e).contains(&byte) {
        byte as char
    } else {
        '.'
    }
}

fn print_dump(data: &[u8], opts: &Opts) {
    let raw_cols = opts.cols.unwrap_or(10);
    let cols = raw_cols.max(1);
    let format = opts.format.unwrap_or(Format::LowerHex);
    let prefix = opts.prefix.unwrap_or(true);
    let color = opts.color.unwrap_or(false);
    let mut offset = 0usize;

    loop {
        let remaining = data.len().saturating_sub(offset);
        let take = remaining.min(cols);
        let chunk = &data[offset..offset + take];
        print!("0x{offset:06x}: ");
        for &byte in chunk {
            let text = octet(byte, format, prefix);
            print!("{} ", colorize(&text, byte, color));
        }
        let pad_slots = if raw_cols == 0 && chunk.is_empty() {
            0
        } else {
            cols - chunk.len()
        };
        for _ in 0..pad_slots {
            print!("     ");
        }
        for &byte in chunk {
            let ch = printable(byte).to_string();
            print!("{}", colorize(&ch, byte, color));
        }
        println!();

        if offset + take >= data.len() {
            if !data.is_empty() && data.len() % cols != 0 {
                break;
            }
            if data.is_empty() || take == 0 {
                break;
            }
            offset += cols;
            continue;
        }
        offset += cols;
    }
    println!("   bytes: {}", data.len());
    io::stdout().flush().ok();
}

fn print_array(data: &[u8], lang: char) {
    match lang {
        'r' => println!("let ARRAY: [u8; {}] = [", data.len()),
        'c' => println!("unsigned char ARRAY[{}] = {{", data.len()),
        'g' => println!("a := [{}]byte{{", data.len()),
        'p' => println!("a = ["),
        'k' => println!("val a = byteArrayOf("),
        'j' => println!("byte[] a = new byte[]{{"),
        's' => println!("let a: [UInt8] = ["),
        'f' => println!("let a = [|"),
        _ => unreachable!(),
    }

    let suffix = if lang == 'f' { "uy" } else { "" };
    for (line_idx, chunk) in data.chunks(10).enumerate() {
        let start = line_idx * 10;
        print!("    ");
        for (idx, &byte) in chunk.iter().enumerate() {
            let absolute = start + idx;
            let sep = if lang == 'f' { ";" } else { "," };
            let last = absolute + 1 == data.len();
            if lang == 'g' || !last {
                print!("0x{byte:02x}{suffix}{sep} ");
            } else {
                print!("0x{byte:02x}{suffix}");
            }
        }
        println!();
    }
    if data.is_empty() {
        println!("    ");
    }

    match lang {
        'r' => println!("];"),
        'c' | 'j' => println!("}};"),
        'g' => println!("}}"),
        'p' | 's' => println!("]"),
        'k' => println!(")"),
        'f' => println!("|]"),
        _ => unreachable!(),
    }
}
