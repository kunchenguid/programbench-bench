use regex::Regex;
use serde::Deserialize;
use serde_json::{Map, Value};
use std::collections::{BTreeMap, HashMap, HashSet};
use std::fs::File;
use std::io::{self, BufRead, BufReader};

const BOLD: &str = "\x1b[1m";
const DIM: &str = "\x1b[2m";
const RESET: &str = "\x1b[0m";

#[derive(Debug, Default)]
struct Cli {
    input: String,
    additional_values: Vec<String>,
    config_file: Option<String>,
    message_keys: Vec<String>,
    print_lua: bool,
    time_keys: Vec<String>,
    level_keys: Vec<String>,
    map_levels: Vec<String>,
    dump_all: bool,
    excluded_values: Vec<String>,
    with_prefix: bool,
    filter: Option<String>,
    no_implicit_filter_return_statement: bool,
    main_line_format: Option<String>,
    additional_value_format: Option<String>,
    substitute: bool,
    context_key: Option<String>,
    placeholder_format: Option<String>,
}

#[derive(Debug, Deserialize, Default)]
struct FileConfig {
    message_keys: Option<Vec<String>>,
    time_keys: Option<Vec<String>>,
    level_keys: Option<Vec<String>>,
    dump_all_exclude: Option<Vec<String>>,
    always_print_fields: Option<Vec<String>>,
    main_line_format: Option<String>,
    additional_value_format: Option<String>,
    level_map: Option<HashMap<String, String>>,
}

#[derive(Clone)]
struct Config {
    message_keys: Vec<String>,
    time_keys: Vec<String>,
    level_keys: Vec<String>,
    dump_all_exclude: Vec<String>,
    always_print_fields: Vec<String>,
    main_line_format: Option<String>,
    additional_value_format: Option<String>,
    level_map: HashMap<String, String>,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            message_keys: vec!["short_message".into(), "msg".into(), "message".into()],
            time_keys: vec!["timestamp".into(), "time".into(), "@timestamp".into()],
            level_keys: vec!["level".into(), "severity".into(), "log.level".into(), "loglevel".into()],
            dump_all_exclude: vec![],
            always_print_fields: vec![],
            main_line_format: None,
            additional_value_format: None,
            level_map: HashMap::new(),
        }
    }
}

fn parse_args() -> Cli {
    let mut cli = Cli { input: "-".to_string(), ..Cli::default() };
    let mut args = std::env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                print_help();
                std::process::exit(0);
            }
            "-V" | "--version" => {
                println!("fblog 4.17.0");
                std::process::exit(0);
            }
            "-a" | "--additional-value" => push_next(&mut args, &mut cli.additional_values, &arg),
            "--config-file" => cli.config_file = Some(next_arg(&mut args, &arg)),
            "-m" | "--message-key" => push_next(&mut args, &mut cli.message_keys, &arg),
            "--print-lua" => cli.print_lua = true,
            "-t" | "--time-key" => push_next(&mut args, &mut cli.time_keys, &arg),
            "-l" | "--level-key" => push_next(&mut args, &mut cli.level_keys, &arg),
            "--map-level" => push_next(&mut args, &mut cli.map_levels, &arg),
            "-d" | "--dump-all" => cli.dump_all = true,
            "-x" | "--excluded-value" => push_next(&mut args, &mut cli.excluded_values, &arg),
            "-p" | "--with-prefix" => cli.with_prefix = true,
            "-f" | "--filter" => cli.filter = Some(next_arg(&mut args, &arg)),
            "--no-implicit-filter-return-statement" => cli.no_implicit_filter_return_statement = true,
            "--main-line-format" => cli.main_line_format = Some(next_arg(&mut args, &arg)),
            "--additional-value-format" => cli.additional_value_format = Some(next_arg(&mut args, &arg)),
            "-s" | "--substitute" => cli.substitute = true,
            "-c" | "--context-key" => cli.context_key = Some(next_arg(&mut args, &arg)),
            "-F" | "--placeholder-format" => cli.placeholder_format = Some(next_arg(&mut args, &arg)),
            _ if arg.starts_with("--additional-value=") => cli.additional_values.push(after_eq(&arg)),
            _ if arg.starts_with("--config-file=") => cli.config_file = Some(after_eq(&arg)),
            _ if arg.starts_with("--message-key=") => cli.message_keys.push(after_eq(&arg)),
            _ if arg.starts_with("--time-key=") => cli.time_keys.push(after_eq(&arg)),
            _ if arg.starts_with("--level-key=") => cli.level_keys.push(after_eq(&arg)),
            _ if arg.starts_with("--map-level=") => cli.map_levels.push(after_eq(&arg)),
            _ if arg.starts_with("--excluded-value=") => cli.excluded_values.push(after_eq(&arg)),
            _ if arg.starts_with("--filter=") => cli.filter = Some(after_eq(&arg)),
            _ if arg.starts_with("--main-line-format=") => cli.main_line_format = Some(after_eq(&arg)),
            _ if arg.starts_with("--additional-value-format=") => cli.additional_value_format = Some(after_eq(&arg)),
            _ if arg.starts_with("--context-key=") => cli.context_key = Some(after_eq(&arg)),
            _ if arg.starts_with("--placeholder-format=") => cli.placeholder_format = Some(after_eq(&arg)),
            _ if arg.starts_with('-') => {
                eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] [INPUT]\n\nFor more information, try '--help'.", arg);
                std::process::exit(2);
            }
            _ => cli.input = arg,
        }
    }
    cli
}

fn next_arg<I: Iterator<Item = String>>(args: &mut std::iter::Peekable<I>, opt: &str) -> String {
    args.next().unwrap_or_else(|| {
        eprintln!("error: a value is required for '{}' but none was supplied", opt);
        std::process::exit(2);
    })
}

fn push_next<I: Iterator<Item = String>>(args: &mut std::iter::Peekable<I>, dst: &mut Vec<String>, opt: &str) {
    dst.push(next_arg(args, opt));
}

fn after_eq(s: &str) -> String {
    s.split_once('=').map(|(_, v)| v.to_string()).unwrap_or_default()
}

fn print_help() {
    println!("json log viewer\n");
    println!("Usage: executable [OPTIONS] [INPUT]\n");
    println!("Arguments:");
    println!("  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]\n");
    println!("Options:");
    println!("  -a, --additional-value <additional-value>\n          adds additional values");
    println!("      --config-file <config-file>\n          configuration file to load");
    println!("  -m, --message-key <message-key>\n          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.");
    println!("      --print-lua\n          Prints lua init expressions. Used for fblog debugging.");
    println!("  -t, --time-key <time-key>\n          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.");
    println!("  -l, --level-key <level-key>\n          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.");
    println!("      --map-level <from=to>\n          Rewrite the log level from one value to another.");
    println!("  -d, --dump-all\n          dumps all values");
    println!("  -x, --excluded-value <excluded-value>\n          Excludes values (--dump-all is enabled implicitly)");
    println!("  -p, --with-prefix\n          consider all text before opening curly brace as prefix");
    println!("  -f, --filter <filter>\n          lua expression to filter log entries. `message ~= nil and string.find(message, \"text.*\") ~= nil`");
    println!("      --no-implicit-filter-return-statement\n          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.");
    println!("      --main-line-format <main-line-format>\n          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.");
    println!("      --additional-value-format <additional-value-format>\n          Formats the additional value fblog output.");
    println!("  -s, --substitute\n          Enable substitution of placeholders in the log messages with their corresponding values from the context.");
    println!("  -c, --context-key <context-key>\n          Use this key as the source of substitutions for the message. Value can either be an array ({{1}}) or an object ({{key}}).");
    println!("  -F, --placeholder-format <placeholder-format>\n          The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${{key}}.");
    println!("  -h, --help\n          Print help");
    println!("  -V, --version\n          Print version");
}

fn main() {
    let cli = parse_args();
    if cli.print_lua {
        return;
    }

    let mut cfg = Config::default();
    if let Some(path) = &cli.config_file {
        let text = std::fs::read_to_string(path).expect("Could not load config file.");
        let file_cfg: FileConfig = toml::from_str(&text).expect("Could not parse config file.");
        merge_config(&mut cfg, file_cfg);
    }
    cfg.message_keys.extend(cli.message_keys.clone());
    cfg.time_keys.extend(cli.time_keys.clone());
    cfg.level_keys.extend(cli.level_keys.clone());
    if let Some(s) = cli.main_line_format.clone().or(cfg.main_line_format.clone()) {
        cfg.main_line_format = Some(s);
    }
    if let Some(s) = cli.additional_value_format.clone().or(cfg.additional_value_format.clone()) {
        cfg.additional_value_format = Some(s);
    }
    for m in &cli.map_levels {
        if let Some((from, to)) = m.split_once('=') {
            cfg.level_map.insert(from.to_string(), to.to_string());
        }
    }

    let reader: Box<dyn BufRead> = if cli.input == "-" {
        Box::new(BufReader::new(io::stdin()))
    } else {
        Box::new(BufReader::new(File::open(&cli.input).unwrap_or_else(|e| {
            eprintln!("{}: {}", cli.input, e);
            std::process::exit(1);
        })))
    };

    for line in reader.lines() {
        let Ok(line) = line else { continue };
        process_line(&line, &cli, &cfg);
    }
}

fn merge_config(cfg: &mut Config, fc: FileConfig) {
    if let Some(v) = fc.message_keys { cfg.message_keys = v; }
    if let Some(v) = fc.time_keys { cfg.time_keys = v; }
    if let Some(v) = fc.level_keys { cfg.level_keys = v; }
    if let Some(v) = fc.dump_all_exclude { cfg.dump_all_exclude = v; }
    if let Some(v) = fc.always_print_fields { cfg.always_print_fields = v; }
    if let Some(v) = fc.main_line_format { cfg.main_line_format = Some(v); }
    if let Some(v) = fc.additional_value_format { cfg.additional_value_format = Some(v); }
    if let Some(v) = fc.level_map { cfg.level_map = v; }
}

fn process_line(line: &str, cli: &Cli, cfg: &Config) {
    let (prefix, json_text) = if cli.with_prefix {
        match line.find('{') {
            Some(i) => (Some(line[..i].trim_end().to_string()), &line[i..]),
            None => (None, line),
        }
    } else {
        (None, line)
    };

    let parsed: Result<Value, _> = serde_json::from_str(json_text);
    let Ok(value) = parsed else {
        println!("\x1b[1;38;2;255;135;22m??? >\x1b[0m {}", line);
        return;
    };

    if !matches_filter(cli.filter.as_deref(), &value) {
        return;
    }

    let mut fields = BTreeMap::new();
    flatten("", &value, &mut fields);

    let message_key = first_existing(&cfg.message_keys, &value);
    let time_key = first_existing(&cfg.time_keys, &value);
    let level_key = first_existing(&cfg.level_keys, &value);

    let mut message = message_key
        .and_then(|k| lookup(&value, k))
        .map(display_scalar)
        .unwrap_or_default();
    if cli.substitute {
        let context_key = cli.context_key.as_deref().unwrap_or("context");
        if let Some(ctx) = lookup(&value, context_key) {
            let fmt = cli.placeholder_format.as_deref().unwrap_or("{key}");
            message = substitute(&message, ctx, fmt);
        }
    }
    let raw_time = time_key.and_then(|k| lookup(&value, k)).map(display_scalar).unwrap_or_default();
    let time = format_time(&raw_time);
    let mut level = level_key.and_then(|k| lookup(&value, k)).map(display_scalar).unwrap_or_else(|| "UNKNOWN".to_string());
    if let Some(mapped) = cfg.level_map.get(&level) {
        level = mapped.clone();
    }

    let mut vars = HashMap::new();
    vars.insert("fblog_timestamp".to_string(), raw_time.clone());
    vars.insert("fblog_level".to_string(), level.clone());
    vars.insert("fblog_message".to_string(), message.clone());
    vars.insert("fblog_prefix".to_string(), prefix.clone().unwrap_or_default());
    for (k, v) in &fields {
        vars.insert(sanitize_var(k), v.clone());
        vars.insert(k.clone(), v.clone());
    }

    if let Some(fmt) = &cfg.main_line_format {
        if is_default_main_format(fmt) {
            println!("{} {}:{}{}", bold(&fixed(&time, 19)), style_level(&level), prefix_part(prefix.as_deref()), message);
        } else {
            println!("{}", render_template(fmt, &vars));
        }
    } else {
        println!("{} {}:{}{}", bold(&fixed(&time, 19)), style_level(&level), prefix_part(prefix.as_deref()), message);
    }

    let mut excludes: HashSet<String> = cfg.dump_all_exclude.iter().cloned().collect();
    excludes.extend(cli.excluded_values.iter().cloned());
    let dump_all = cli.dump_all || !cli.excluded_values.is_empty();
    if dump_all {
        for (k, v) in &fields {
            if !is_core_key(k, cfg) && !excludes.contains(k) {
                print_additional(k, v, cfg);
            }
        }
    }
    for key in cfg.always_print_fields.iter().chain(cli.additional_values.iter()) {
        if dump_all {
            continue;
        }
        if let Some(v) = lookup(&value, key) {
            let mut flat = BTreeMap::new();
            flatten(key, v, &mut flat);
            for (k, val) in flat {
                print_additional(&k, &val, cfg);
            }
        }
    }
}

fn first_existing<'a>(keys: &'a [String], v: &Value) -> Option<&'a str> {
    keys.iter().map(String::as_str).find(|k| lookup(v, k).is_some())
}

fn lookup<'a>(v: &'a Value, key: &str) -> Option<&'a Value> {
    if let Value::Object(map) = v {
        if let Some(x) = map.get(key) {
            return Some(x);
        }
    }
    if key.contains(" > ") {
        let mut cur = v;
        for part in key.split(" > ").map(str::trim) {
            cur = lookup_part(cur, part)?;
        }
        return Some(cur);
    }
    lookup_part(v, key)
}

fn lookup_part<'a>(v: &'a Value, part: &str) -> Option<&'a Value> {
    let (name, rest) = part.split_once('[').map(|(a, b)| (a, Some(b))).unwrap_or((part, None));
    let mut cur = if name.is_empty() {
        v
    } else {
        match v {
            Value::Object(map) => map.get(name)?,
            _ => return None,
        }
    };
    if let Some(mut r) = rest {
        loop {
            let end = r.find(']')?;
            let idx: usize = r[..end].parse().ok()?;
            cur = cur.as_array()?.get(idx)?;
            if end + 1 >= r.len() {
                break;
            }
            r = r[end + 1..].strip_prefix('[')?;
        }
    }
    Some(cur)
}

fn flatten(prefix: &str, v: &Value, out: &mut BTreeMap<String, String>) {
    match v {
        Value::Object(map) => {
            let mut entries: Vec<_> = map.iter().collect();
            entries.sort_by_key(|(k, _)| *k);
            for (k, val) in entries {
                let p = if prefix.is_empty() { k.clone() } else { format!("{} > {}", prefix, k) };
                flatten(&p, val, out);
            }
        }
        Value::Array(arr) => {
            for (idx, val) in arr.iter().enumerate() {
                let p = format!("{}[{}]", prefix, idx);
                flatten(&p, val, out);
            }
        }
        _ => {
            out.insert(prefix.to_string(), display_scalar(v));
        }
    }
}

fn display_scalar(v: &Value) -> String {
    match v {
        Value::Null => "null".to_string(),
        Value::Bool(b) => b.to_string(),
        Value::Number(n) => n.to_string(),
        Value::String(s) => s.clone(),
        _ => compact_json(v),
    }
}

fn compact_json(v: &Value) -> String {
    serde_json::to_string(v).unwrap_or_default()
}

fn format_time(raw: &str) -> String {
    if raw.chars().all(|c| c.is_ascii_digit()) {
        if let Ok(ms) = raw.parse::<i64>() {
            if raw.len() >= 12 {
                if let Some(dt) = chrono::DateTime::from_timestamp(ms / 1000, ((ms % 1000) * 1_000_000) as u32) {
                    return dt.naive_utc().format("%Y-%m-%dT%H:%M:%S").to_string();
                }
            }
        }
    }
    if raw.len() >= 20 && raw.as_bytes().get(4) == Some(&b'-') && raw.as_bytes().get(10) == Some(&b'T') {
        return raw.chars().take(19).collect();
    }
    raw.chars().take(19).collect()
}

fn fixed(s: &str, width: usize) -> String {
    let len = s.chars().count();
    if len > width {
        s.chars().take(width).collect()
    } else {
        format!("{:>width$}", s, width = width)
    }
}

fn bold(s: &str) -> String {
    format!("{}{}{}", BOLD, s, RESET)
}

fn style_level(level: &str) -> String {
    let up = level.to_ascii_uppercase();
    let shown = fixed(&up, 5);
    let color = match up.as_str() {
        "INFO" | "INFORMATION" => "32",
        "WARN" => "33",
        "ERROR" | "ERR" | "FATAL" | "CRITICAL" => "31",
        "DEBUG" | "TRACE" => "34",
        _ => "35",
    };
    format!("\x1b[1;{}m{}\x1b[0m", color, shown)
}

fn prefix_part(prefix: Option<&str>) -> String {
    match prefix.filter(|p| !p.is_empty()) {
        Some(p) => format!(" {}\x1b[1m\x1b[36m{}\x1b[0m{} ", "", p, RESET),
        None => " ".to_string(),
    }
}

fn print_additional(key: &str, value: &str, cfg: &Config) {
    let mut vars = HashMap::new();
    vars.insert("key".to_string(), key.to_string());
    vars.insert("value".to_string(), value.to_string());
    if let Some(fmt) = &cfg.additional_value_format {
        if is_default_additional_format(fmt) {
            println!("{}\x1b[38;2;150;150;150m{}\x1b[0m{}: {}", BOLD, min_width(key, 25), RESET, value);
            return;
        }
        println!("{}", render_template(fmt, &vars));
    } else {
        println!("{}\x1b[38;2;150;150;150m{}\x1b[0m{}: {}", BOLD, min_width(key, 25), RESET, value);
    }
}

fn min_width(s: &str, width: usize) -> String {
    if s.chars().count() < width {
        format!("{:>width$}", s, width = width)
    } else {
        s.to_string()
    }
}

fn is_default_main_format(fmt: &str) -> bool {
    fmt.contains("fixed_size 19 fblog_timestamp") && fmt.contains("level_style") && fmt.contains("fblog_message")
}

fn is_default_additional_format(fmt: &str) -> bool {
    fmt.contains("color_rgb 150 150 150") && fmt.contains("min_size 25 key")
}

fn is_core_key(k: &str, cfg: &Config) -> bool {
    cfg.message_keys.iter().chain(&cfg.time_keys).chain(&cfg.level_keys).any(|x| x == k)
}

fn matches_filter(filter: Option<&str>, v: &Value) -> bool {
    let Some(mut f) = filter.map(str::trim) else { return true };
    if let Some(rest) = f.strip_prefix("return ") {
        f = rest.trim();
    }
    let re = Regex::new(r#"^([A-Za-z0-9_@.\-]+)\s*(==|~=|!=|>=|<=|>|<)\s*(?:"([^"]*)"|'([^']*)'|([^\s]+))$"#).unwrap();
    let Some(caps) = re.captures(f) else { return true };
    let key = caps.get(1).unwrap().as_str();
    let op = caps.get(2).unwrap().as_str();
    let rhs = caps.get(3).or_else(|| caps.get(4)).or_else(|| caps.get(5)).map(|m| m.as_str()).unwrap_or("");
    let Some(lhs_v) = lookup(v, key) else { return false };
    let lhs = display_scalar(lhs_v);
    match op {
        "==" => lhs == rhs,
        "!=" | "~=" => lhs != rhs,
        ">" | "<" | ">=" | "<=" => {
            let ln = lhs.parse::<f64>();
            let rn = rhs.parse::<f64>();
            if let (Ok(a), Ok(b)) = (ln, rn) {
                match op { ">" => a > b, "<" => a < b, ">=" => a >= b, "<=" => a <= b, _ => false }
            } else {
                match op { ">" => lhs.as_str() > rhs, "<" => lhs.as_str() < rhs, ">=" => lhs.as_str() >= rhs, "<=" => lhs.as_str() <= rhs, _ => false }
            }
        }
        _ => true,
    }
}

fn substitute(message: &str, ctx: &Value, fmt: &str) -> String {
    let re = Regex::new(&regex::escape(fmt).replace("key", r"([^}#\]\)$]+)")).unwrap_or_else(|_| Regex::new(r"\{([^}]+)\}").unwrap());
    re.replace_all(message, |caps: &regex::Captures| {
        let key = caps.get(1).map(|m| m.as_str()).unwrap_or("");
        let val = match ctx {
            Value::Array(arr) => key.parse::<usize>().ok().and_then(|i| arr.get(i)),
            Value::Object(map) => map.get(key),
            _ => None,
        };
        val.map(color_value).unwrap_or_else(|| color_missing(&caps[0]))
    }).to_string()
}

fn color_missing(s: &str) -> String {
    if s.starts_with('{') && s.ends_with('}') {
        let inner = &s[1..s.len() - 1];
        format!("{}{{{}{}{}{}{}{}", DIM, RESET, "\x1b[1;31m", inner, RESET, DIM, "}\x1b[0m")
    } else {
        s.to_string()
    }
}

fn color_value(v: &Value) -> String {
    match v {
        Value::Bool(true) => "\x1b[1;32mtrue\x1b[0m".to_string(),
        Value::Bool(false) => "\x1b[1;31mfalse\x1b[0m".to_string(),
        Value::Number(n) => format!("\x1b[1;36m{}\x1b[0m", n),
        Value::String(s) => format!("\x1b[1;33m{}\x1b[0m", s),
        Value::Array(a) => {
            let parts: Vec<_> = a.iter().map(color_value).collect();
            format!("{}[{}{}{}]", DIM, RESET, parts.join(&format!("{}{}, ", DIM, RESET)), DIM) + RESET
        }
        Value::Object(m) => color_object(m),
        Value::Null => "null".to_string(),
    }
}

fn color_object(m: &Map<String, Value>) -> String {
    let mut parts = Vec::new();
    let mut keys: Vec<_> = m.keys().collect();
    keys.sort();
    for k in keys {
        parts.push(format!("\x1b[35m{}\x1b[0m{}: {}{}", k, DIM, RESET, color_value(&m[k])));
    }
    format!("{}{{{}{}{}{}{}", DIM, RESET, parts.join(&format!("{}{}, ", DIM, RESET)), DIM, "}", RESET)
}

fn render_template(fmt: &str, vars: &HashMap<String, String>) -> String {
    let mut out = fmt.to_string();
    let if_re = Regex::new(r"\{\{#if ([^} ]+)\}\}(.*?)\{\{/if\}\}").unwrap();
    while let Some(c) = if_re.captures(&out.clone()) {
        let whole = c.get(0).unwrap().as_str();
        let key = c.get(1).unwrap().as_str();
        let body = c.get(2).unwrap().as_str();
        let replacement = if vars.get(key).map(|v| !v.is_empty()).unwrap_or(false) { body } else { "" };
        out = out.replacen(whole, replacement, 1);
    }
    let var_re = Regex::new(r"\{\{\s*([^{}() ]+)\s*\}\}").unwrap();
    out = var_re.replace_all(&out, |caps: &regex::Captures| {
        vars.get(caps.get(1).unwrap().as_str()).cloned().unwrap_or_default()
    }).to_string();
    render_functions(&out, vars)
}

fn render_functions(s: &str, vars: &HashMap<String, String>) -> String {
    let mut out = s.to_string();
    let patterns = [
        (r"\{\{uppercase \(?([^{}() ]+)\)?\}\}", "upper"),
        (r"\{\{bold \(?([^{}()]+)\)?\}\}", "bold"),
        (r"\{\{cyan \(?([^{}()]+)\)?\}\}", "cyan"),
        (r"\{\{fixed_size ([0-9]+) ([^{}() ]+)\}\}", "fixed"),
        (r"\{\{min_size ([0-9]+) ([^{}() ]+)\}\}", "min"),
        (r"\{\{level_style \(?([^{}() ]+)\)?\}\}", "level"),
    ];
    for (pat, kind) in patterns {
        let re = Regex::new(pat).unwrap();
        loop {
            let snapshot = out.clone();
            let Some(c) = re.captures(&snapshot) else { break };
            let whole = c.get(0).unwrap().as_str().to_string();
            let replacement = match kind {
                "upper" => val(vars, c.get(1).unwrap().as_str()).to_ascii_uppercase(),
                "bold" => bold(&resolve_text(c.get(1).unwrap().as_str(), vars)),
                "cyan" => format!("\x1b[36m{}\x1b[0m", resolve_text(c.get(1).unwrap().as_str(), vars)),
                "fixed" => fixed(&val(vars, c.get(2).unwrap().as_str()), c.get(1).unwrap().as_str().parse().unwrap_or(0)),
                "min" => {
                    let text = val(vars, c.get(2).unwrap().as_str());
                    let w = c.get(1).unwrap().as_str().parse().unwrap_or(0);
                    if text.len() < w { format!("{:>width$}", text, width = w) } else { text }
                }
                "level" => style_level(&val(vars, c.get(1).unwrap().as_str())),
                _ => String::new(),
            };
            out = out.replacen(&whole, &replacement, 1);
        }
    }
    let var_re = Regex::new(r"\{\{\s*([^{}() ]+)\s*\}\}").unwrap();
    var_re.replace_all(&out, |caps: &regex::Captures| val(vars, caps.get(1).unwrap().as_str())).to_string()
}

fn val(vars: &HashMap<String, String>, key: &str) -> String {
    vars.get(key.trim()).cloned().unwrap_or_else(|| key.trim().to_string())
}

fn resolve_text(s: &str, vars: &HashMap<String, String>) -> String {
    val(vars, s.trim())
}

fn sanitize_var(k: &str) -> String {
    k.chars().map(|c| if c.is_ascii_alphanumeric() { c } else { '_' }).collect()
}
