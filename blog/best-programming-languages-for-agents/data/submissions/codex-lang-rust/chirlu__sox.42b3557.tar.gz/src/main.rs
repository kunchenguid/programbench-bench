use std::env;
use std::f64::consts::PI;
use std::fs;
use std::io::{self, Read, Write};
use std::path::Path;

const VERSION: &str = "SoX v14.4.2";

#[derive(Clone, Debug)]
struct Opts {
    rate: Option<u32>,
    channels: Option<u16>,
    bits: Option<u16>,
    encoding: Option<String>,
    typ: Option<String>,
    volume: f64,
}

impl Default for Opts {
    fn default() -> Self {
        Self { rate: None, channels: None, bits: None, encoding: None, typ: None, volume: 1.0 }
    }
}

#[derive(Clone, Debug)]
struct Spec {
    name: String,
    opts: Opts,
}

#[derive(Clone, Debug)]
struct Audio {
    rate: u32,
    channels: u16,
    bits: u16,
    encoding: String,
    samples: Vec<f64>,
}

fn main() {
    let args: Vec<String> = env::args().collect();
    let prog = args.get(0).map(|s| s.as_str()).unwrap_or("./executable");
    let code = match run(prog, &args[1..]) {
        Ok(()) => 0,
        Err(e) => {
            eprintln!("{} FAIL {}", prog, e);
            if args.len() == 1 || e == "sox: invalid option" {
                print_help(prog);
            }
            1
        }
    };
    std::process::exit(code);
}

fn run(prog: &str, args: &[String]) -> Result<(), String> {
    if args.iter().any(|a| a == "--version") {
        println!("{}:      {}", prog, VERSION);
        return Ok(());
    }
    if args.iter().any(|a| a == "--help" || a == "-h") {
        print_help(prog);
        return Ok(());
    }
    if let Some(i) = args.iter().position(|a| a == "--help-effect") {
        let name = args.get(i + 1).map(|s| s.as_str()).unwrap_or("");
        print_help_effect(prog, name);
        return Ok(());
    }
    if let Some(i) = args.iter().position(|a| a == "--help-format") {
        let name = args.get(i + 1).map(|s| s.as_str()).unwrap_or("");
        print_help_format(prog, name);
        return Ok(());
    }
    let invoked_soxi = Path::new(prog).file_name().and_then(|s| s.to_str()).unwrap_or("").contains("soxi");
    if invoked_soxi || args.iter().any(|a| a == "--i" || a == "--info") {
        return soxi(prog, args);
    }
    sox(prog, args)
}

fn print_help(prog: &str) {
    println!("{prog}:      {VERSION}\n");
    println!("Usage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...\n");
    println!("SPECIAL FILENAMES (infile, outfile):");
    println!("-                        Pipe/redirect input/output (stdin/stdout); may need -t");
    println!("-d, --default-device     Use the default audio device (where available)");
    println!("-n, --null               Use the `null' file handler; e.g. with synth effect");
    println!("-p, --sox-pipe           Alias for `-t sox -'\n");
    println!("GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):");
    println!("--buffer BYTES           Set the size of all processing buffers (default 8192)");
    println!("--clobber                Don't prompt to overwrite output file (default)");
    println!("--combine concatenate    Concatenate all input files (default for sox, rec)");
    println!("-D, --no-dither          Don't dither automatically");
    println!("-h, --help               Display version number and usage information");
    println!("--help-effect NAME       Show usage of effect NAME, or NAME=all for all");
    println!("--help-format NAME       Show info on format NAME, or NAME=all for all");
    println!("--i, --info              Behave as soxi(1)");
    println!("-m, --combine mix        Mix multiple input files (instead of concatenating)");
    println!("-M, --combine merge      Merge multiple input files (instead of concatenating)");
    println!("--norm                   Guard (see --guard) & normalise");
    println!("-q, --no-show-progress   Run in quiet mode; opposite of -S");
    println!("--version                Display version number of SoX and exit");
    println!("-V[LEVEL]                Increment or set verbosity level (default 2); levels:");
    println!("                           1: failure messages");
    println!("                           2: warnings");
    println!("                           3: details of processing");
    println!("                           4-6: increasing levels of debug messages");
    println!("FORMAT OPTIONS (fopts):");
    println!("-v|--volume FACTOR       Input file volume adjustment factor (real number)");
    println!("-t|--type FILETYPE       File type of audio");
    println!("-e|--encoding ENCODING   Set encoding");
    println!("-b|--bits BITS           Encoded sample size in bits");
    println!("-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo");
    println!("-r|--rate RATE           Sample rate of audio");
    println!("\nAUDIO FILE FORMATS: raw s16 s32 u8 wav wavpcm");
    println!("EFFECTS: channels fade gain norm rate repeat reverse speed stat stats synth trim vol");
    println!("EFFECT OPTIONS (effopts): effect dependent; see --help-effect");
}

fn print_help_effect(prog: &str, name: &str) {
    println!("{prog}:      {VERSION}\n\nEffect usage:\n");
    let usage = match name {
        "trim" => "trim {position}",
        "synth" => "synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}",
        "stat" => "stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]",
        "stats" => "stats [-b bits|-x bits|-s scale] [-w window-time]",
        "rate" => "rate [-q|-l|-m|-h|-v] [override-options] RATE[k]",
        "channels" => "channels CHANNELS",
        "gain" => "gain [ -e|-B|-b|-r ] [ -n ] [ -l|-h ] [ gain-dB ]",
        "vol" => "vol GAIN [TYPE [LIMITERGAIN]]",
        "all" => "channels CHANNELS\nfade [type] fade-in-length [stop-time [fade-out-length]]\ngain [gain-dB]\nnorm [level]\nrate RATE[k]\nrepeat count\nreverse\nspeed factor\nstat\nstats\nsynth ...\ntrim start [length]\nvol gain",
        _ => "effect-name [effect-options]",
    };
    println!("{usage}\n");
}

fn print_help_format(prog: &str, name: &str) {
    println!("{prog}:      {VERSION}\n");
    match name {
        "wav" | "wavpcm" | "all" => {
            println!("Format: wav");
            println!("Description: Microsoft audio format");
            println!("Also handles: wavpcm amb");
            println!("Reads: yes");
            println!("Writes:");
            println!("  16-bit Signed Integer PCM (16-bit precision)");
            println!("  24-bit Signed Integer PCM (24-bit precision)");
            println!("  32-bit Signed Integer PCM (32-bit precision)");
            println!("   8-bit Unsigned Integer PCM (8-bit precision)");
        }
        "raw" | _ => {
            println!("Format: raw");
            println!("Description: Raw PCM, mu-law, or A-law");
            println!("Reads: yes");
            println!("Writes:");
            println!("  32-bit Signed Integer PCM (32-bit precision)");
            println!("  24-bit Signed Integer PCM (24-bit precision)");
            println!("  16-bit Signed Integer PCM (16-bit precision)");
            println!("   8-bit Signed Integer PCM (8-bit precision)");
            println!("   8-bit Unsigned Integer PCM (8-bit precision)");
        }
    }
}

fn soxi(prog: &str, args: &[String]) -> Result<(), String> {
    let mut field: Option<char> = None;
    let mut total = false;
    let mut files = Vec::new();
    let mut skip = false;
    for (i, a) in args.iter().enumerate() {
        if skip { skip = false; continue; }
        match a.as_str() {
            "--i" | "--info" => {}
            "-T" => total = true,
            "-t" | "-r" | "-c" | "-s" | "-d" | "-D" | "-b" | "-B" | "-p" | "-e" | "-a" => {
                field = a.chars().last();
            }
            "-V" => {}
            x if x.starts_with("-V") => {}
            "-n" => files.push(a.clone()),
            "-h" | "--help" => { print_help(prog); return Ok(()); }
            x if x.starts_with('-') && (x == "-t" || x == "-r") => {}
            _ => {
                if i > 0 || a != "--i" {
                    files.push(a.clone());
                }
            }
        }
    }
    if files.is_empty() {
        return Err("soxi: missing filename".into());
    }
    let mut total_samples: u64 = 0;
    let mut total_dur = 0.0;
    let multiple = files.len() > 1;
    for f in &files {
        let audio = read_audio(&Spec { name: f.clone(), opts: Opts::default() })?;
        total_samples += frames(&audio) as u64;
        total_dur += frames(&audio) as f64 / audio.rate as f64;
        if total && matches!(field, Some('s' | 'd' | 'D')) { continue; }
        if let Some(ch) = field {
            print_field(ch, &audio, f, multiple);
        } else {
            print_info(&audio, f);
        }
    }
    if total {
        match field {
            Some('s') => println!("{total_samples}"),
            Some('D') => println!("{total_dur:.6}"),
            Some('d') => println!("{}", fmt_duration(total_dur, true)),
            _ => {}
        }
    }
    Ok(())
}

fn print_field(ch: char, a: &Audio, f: &str, multiple: bool) {
    let prefix = if multiple { format!("{f}: ") } else { String::new() };
    match ch {
        't' => println!("{}{}", prefix, file_type(f, None)),
        'r' => println!("{}{}", prefix, a.rate),
        'c' => println!("{}{}", prefix, a.channels),
        's' => println!("{}{}", prefix, frames(a)),
        'd' => println!("{}{}", prefix, fmt_duration(frames(a) as f64 / a.rate as f64, true)),
        'D' => println!("{}{:.6}", prefix, frames(a) as f64 / a.rate as f64),
        'b' | 'p' => println!("{}{}", prefix, a.bits),
        'B' => println!("{}{}", prefix, bitrate(a, f)),
        'e' => println!("{}{}", prefix, encoding_name(a)),
        'a' => {}
        _ => {}
    }
}

fn print_info(a: &Audio, f: &str) {
    let dur = frames(a) as f64 / a.rate as f64;
    println!();
    println!("Input File     : '{}'", f);
    println!("Channels       : {}", a.channels);
    println!("Sample Rate    : {}", a.rate);
    println!("Precision      : {}-bit", a.bits);
    println!("Duration       : {} = {} samples ~ {:.2} CDDA sectors", fmt_duration(dur, true), frames(a), dur * 44100.0 / 588.0);
    if let Ok(md) = fs::metadata(f) {
        println!("File Size      : {}", md.len());
    }
    println!("Bit Rate       : {}", bitrate(a, f));
    println!("Sample Encoding: {}-bit {}", a.bits, encoding_name(a));
    println!();
}

fn sox(prog: &str, args: &[String]) -> Result<(), String> {
    if args.is_empty() {
        return Err("sox: No input filenames specified".into());
    }
    let mut pending = Opts::default();
    let mut specs: Vec<Spec> = Vec::new();
    let mut effects: Vec<String> = Vec::new();
    let mut combine = "concat";
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if is_effect(a) && specs.len() >= 2 {
            effects = args[i..].to_vec();
            break;
        }
        match a.as_str() {
            "-q" | "-S" | "-D" | "-G" | "-R" | "-L" | "-B" | "-x" | "-N" | "-X" |
            "--guard" | "--norm" | "--clobber" | "--no-clobber" | "--no-show-progress" |
            "--show-progress" | "--multi-threaded" | "--single-threaded" | "--ignore-length" |
            "--no-glob" => {
                if a == "--norm" { effects.push("norm".into()); }
            }
            "-m" => combine = "mix",
            "-M" => combine = "merge",
            "-T" => combine = "multiply",
            "--combine" => {
                i += 1;
                combine = args.get(i).map(String::as_str).unwrap_or("concat");
            }
            "-r" | "--rate" => { i += 1; pending.rate = Some(parse_rate(args.get(i).ok_or("sox: missing rate")?)?); }
            "-c" | "--channels" => { i += 1; pending.channels = Some(args.get(i).ok_or("sox: missing channels")?.parse().map_err(|_| "sox: bad channels")?); }
            "-b" | "--bits" => { i += 1; pending.bits = Some(args.get(i).ok_or("sox: missing bits")?.parse().map_err(|_| "sox: bad bits")?); }
            "-e" | "--encoding" => { i += 1; pending.encoding = Some(args.get(i).ok_or("sox: missing encoding")?.clone()); }
            "-t" | "--type" => { i += 1; pending.typ = Some(args.get(i).ok_or("sox: missing type")?.clone()); }
            "-v" | "--volume" => { i += 1; pending.volume *= args.get(i).ok_or("sox: missing volume")?.parse::<f64>().map_err(|_| "sox: bad volume")?; }
            "-C" | "--compression" | "--comment" | "--add-comment" | "--comment-file" | "--endian" |
            "--buffer" | "--input-buffer" | "--dft-min" | "--effects-file" | "--play-rate-arg" |
            "--plot" | "--replay-gain" | "--temp" => { i += 1; }
            "-n" | "-p" | "-" => {
                specs.push(Spec { name: a.clone(), opts: pending.clone() });
                pending = Opts::default();
            }
            x if x.starts_with("--") => {
                eprintln!("{prog} WARN getopt: parameter not recognized from `{x}'");
                return Err("sox: invalid option".into());
            }
            x if x.starts_with('-') && x.len() > 1 => return Err("sox: invalid option".into()),
            _ => {
                specs.push(Spec { name: a.clone(), opts: pending.clone() });
                pending = Opts::default();
            }
        }
        i += 1;
    }
    if specs.is_empty() {
        return Err("sox: No input filenames specified".into());
    }
    if specs.len() < 2 {
        return Err("sox: Not enough input filenames specified".into());
    }
    let out = specs.pop().unwrap();
    let inputs = specs;
    let mut audio = if inputs.len() == 1 && inputs[0].name == "-n" {
        null_audio(&inputs[0], &out, &effects)
    } else {
        let mut audios = Vec::new();
        for s in &inputs {
            let mut a = read_audio(s)?;
            if (s.opts.volume - 1.0).abs() > f64::EPSILON {
                for v in &mut a.samples { *v *= s.opts.volume; }
            }
            audios.push(a);
        }
        combine_audio(audios, combine)
    };
    apply_effects(&mut audio, &effects)?;
    if let Some(r) = out.opts.rate {
        resample(&mut audio, r);
    }
    if let Some(c) = out.opts.channels {
        convert_channels(&mut audio, c);
    }
    if let Some(b) = out.opts.bits {
        audio.bits = b;
    }
    if let Some(e) = &out.opts.encoding {
        audio.encoding = e.clone();
    }
    write_audio(&out, &audio)
}

fn is_effect(s: &str) -> bool {
    matches!(s, "channels" | "fade" | "gain" | "norm" | "rate" | "remix" | "repeat" | "reverse" | "speed" | "stat" | "stats" | "synth" | "trim" | "vol")
}

fn null_audio(input: &Spec, out: &Spec, effects: &[String]) -> Audio {
    let rate = out.opts.rate.or(input.opts.rate).unwrap_or(48000);
    let channels = out.opts.channels.or(input.opts.channels).unwrap_or(1);
    let bits = out.opts.bits.or(input.opts.bits).unwrap_or(32);
    let mut len = 0.0;
    if let Some(pos) = effects.iter().position(|e| e == "synth") {
        if let Some(v) = effects.get(pos + 1).and_then(|x| parse_time(x).ok()) {
            len = v;
        }
    }
    let n = (len * rate as f64).round().max(0.0) as usize;
    Audio { rate, channels, bits, encoding: "signed-integer".into(), samples: vec![0.0; n * channels as usize] }
}

fn combine_audio(mut audios: Vec<Audio>, mode: &str) -> Audio {
    if audios.is_empty() {
        return Audio { rate: 48000, channels: 1, bits: 32, encoding: "signed-integer".into(), samples: vec![] };
    }
    let mut base = audios.remove(0);
    for mut a in audios {
        if a.rate != base.rate { resample(&mut a, base.rate); }
        if a.channels != base.channels { convert_channels(&mut a, base.channels); }
        match mode {
            "mix" | "mix-power" | "multiply" => {
                let len = base.samples.len().max(a.samples.len());
                base.samples.resize(len, 0.0);
                for (j, v) in a.samples.iter().enumerate() {
                    if mode == "multiply" { base.samples[j] *= *v; } else { base.samples[j] += *v; }
                }
                if mode == "mix-power" {
                    for v in &mut base.samples { *v /= 2f64.sqrt(); }
                }
            }
            "merge" => {
                let frames = frames(&base).min(frames(&a));
                let mut out = Vec::with_capacity(frames * (base.channels + a.channels) as usize);
                for f in 0..frames {
                    out.extend_from_slice(&base.samples[f * base.channels as usize..(f + 1) * base.channels as usize]);
                    out.extend_from_slice(&a.samples[f * a.channels as usize..(f + 1) * a.channels as usize]);
                }
                base.channels += a.channels;
                base.samples = out;
            }
            _ => base.samples.extend_from_slice(&a.samples),
        }
    }
    base
}

fn apply_effects(a: &mut Audio, effects: &[String]) -> Result<(), String> {
    let mut i = 0;
    while i < effects.len() {
        match effects[i].as_str() {
            "synth" => {
                let mut j = i + 1;
                let mut len = None;
                if j < effects.len() {
                    if let Ok(t) = parse_time(&effects[j]) { len = Some(t); j += 1; }
                }
                if let Some(t) = len {
                    a.samples.resize((t * a.rate as f64).round() as usize * a.channels as usize, 0.0);
                }
                synth_into(a, &effects[j..]);
                while j < effects.len() && !is_effect(&effects[j]) { j += 1; }
                i = j;
                continue;
            }
            "trim" => {
                let start = effects.get(i + 1).and_then(|x| parse_time(x).ok()).unwrap_or(0.0);
                let len = effects.get(i + 2).and_then(|x| parse_time(x).ok());
                trim(a, start, len);
                i += 1 + if len.is_some() { 2 } else { 1 };
            }
            "channels" | "remix" => {
                if let Some(c) = effects.get(i + 1).and_then(|x| x.parse::<u16>().ok()) { convert_channels(a, c); }
                i += 2;
            }
            "rate" => {
                let mut j = i + 1;
                while j < effects.len() && effects[j].starts_with('-') { j += 1; }
                if let Some(r) = effects.get(j).and_then(|x| parse_rate(x).ok()) { resample(a, r); }
                i = j + 1;
            }
            "speed" => {
                let factor = effects.get(i + 1).and_then(|x| x.parse::<f64>().ok()).unwrap_or(1.0);
                speed(a, factor);
                i += 2;
            }
            "vol" => {
                let g = effects.get(i + 1).and_then(|x| x.parse::<f64>().ok()).unwrap_or(1.0);
                for v in &mut a.samples { *v *= g; }
                i += 2;
            }
            "gain" => {
                let db = effects.iter().skip(i + 1).take_while(|x| !is_effect(x)).find_map(|x| x.parse::<f64>().ok()).unwrap_or(0.0);
                let g = 10f64.powf(db / 20.0);
                for v in &mut a.samples { *v *= g; }
                i += 1;
                while i < effects.len() && !is_effect(&effects[i]) { i += 1; }
            }
            "norm" => { normalize(a, effects.get(i + 1).and_then(|x| x.parse::<f64>().ok()).unwrap_or(0.0)); i += 1; }
            "reverse" => { reverse(a); i += 1; }
            "repeat" => {
                let n = effects.get(i + 1).and_then(|x| x.parse::<usize>().ok()).unwrap_or(1);
                let orig = a.samples.clone();
                for _ in 0..n { a.samples.extend_from_slice(&orig); }
                i += 2;
            }
            "fade" => { apply_fade(a, &effects[i + 1..]); i += 1; while i < effects.len() && !is_effect(&effects[i]) { i += 1; } }
            "stat" | "stats" => { print_stats(a); i += 1; while i < effects.len() && !is_effect(&effects[i]) { i += 1; } }
            _ => i += 1,
        }
    }
    Ok(())
}

fn synth_into(a: &mut Audio, args: &[String]) {
    let mut tones = Vec::new();
    let mut i = 0;
    while i < args.len() {
        if is_effect(&args[i]) { break; }
        let typ = args[i].as_str();
        if matches!(typ, "sine" | "sin" | "square" | "sawtooth" | "saw" | "tri" | "triangle" | "noise" | "pinknoise" | "brownnoise" | "pluck" | "pl") {
            let freq = args.get(i + 1).map(|s| parse_freq(s)).unwrap_or(Ok(440.0)).unwrap_or(440.0);
            tones.push((typ.to_string(), freq));
            i += 2;
        } else {
            i += 1;
        }
    }
    if tones.is_empty() { tones.push(("sine".into(), 440.0)); }
    let ch = a.channels as usize;
    for f in 0..frames(a) {
        let t = f as f64 / a.rate as f64;
        let mut v = 0.0;
        for (typ, freq) in &tones {
            let x = 2.0 * PI * freq * t;
            v += match typ.as_str() {
                "square" => if x.sin() >= 0.0 { 0.75 } else { -0.75 },
                "saw" | "sawtooth" => 2.0 * (freq * t - (freq * t + 0.5).floor()),
                "tri" | "triangle" => (2.0 / PI) * x.sin().asin(),
                "noise" | "pinknoise" | "brownnoise" => pseudo_noise(f as u64) * 0.5,
                "pluck" | "pl" => (x.sin() * (1.0 - t / 2.0).max(0.0)) * 0.8,
                _ => x.sin() * 0.8,
            };
        }
        v /= tones.len() as f64;
        for c in 0..ch { a.samples[f * ch + c] = v; }
    }
}

fn pseudo_noise(n: u64) -> f64 {
    let mut x = n.wrapping_mul(6364136223846793005).wrapping_add(1);
    x ^= x >> 33;
    ((x & 0xffff) as f64 / 32768.0) - 1.0
}

fn read_audio(spec: &Spec) -> Result<Audio, String> {
    if spec.name == "-n" {
        return Ok(null_audio(spec, spec, &[]));
    }
    let mut data = Vec::new();
    if spec.name == "-" {
        io::stdin().read_to_end(&mut data).map_err(|e| format!("formats: can't read input file `-': {e}"))?;
    } else {
        data = fs::read(&spec.name).map_err(|e| format!("formats: can't open input file `{}`: {}", spec.name, e))?;
    }
    let typ = file_type(&spec.name, spec.opts.typ.as_deref());
    let mut a = if typ == "wav" || data.starts_with(b"RIFF") || data.starts_with(b"RIFX") {
        read_wav(&data)?
    } else {
        read_raw(&data, &spec.opts, &spec.name)
    };
    if let Some(r) = spec.opts.rate { a.rate = r; }
    if let Some(c) = spec.opts.channels { a.channels = c; }
    if let Some(b) = spec.opts.bits { a.bits = b; }
    if let Some(e) = &spec.opts.encoding { a.encoding = e.clone(); }
    Ok(a)
}

fn read_wav(data: &[u8]) -> Result<Audio, String> {
    if data.len() < 44 || &data[0..4] != b"RIFF" && &data[0..4] != b"RIFX" || &data[8..12] != b"WAVE" {
        return Err("formats: can't open input file: WAVE: RIFF header not found".into());
    }
    let be = &data[0..4] == b"RIFX";
    let u16r = |b: &[u8]| if be { u16::from_be_bytes([b[0], b[1]]) } else { u16::from_le_bytes([b[0], b[1]]) };
    let u32r = |b: &[u8]| if be { u32::from_be_bytes([b[0], b[1], b[2], b[3]]) } else { u32::from_le_bytes([b[0], b[1], b[2], b[3]]) };
    let mut pos = 12;
    let mut fmt = 1u16;
    let mut channels = 1u16;
    let mut rate = 8000u32;
    let mut bits = 16u16;
    let mut pcm = &[][..];
    while pos + 8 <= data.len() {
        let id = &data[pos..pos + 4];
        let len = u32r(&data[pos + 4..pos + 8]) as usize;
        pos += 8;
        if pos + len > data.len() { break; }
        if id == b"fmt " && len >= 16 {
            fmt = u16r(&data[pos..pos + 2]);
            channels = u16r(&data[pos + 2..pos + 4]);
            rate = u32r(&data[pos + 4..pos + 8]);
            bits = u16r(&data[pos + 14..pos + 16]);
        } else if id == b"data" {
            pcm = &data[pos..pos + len];
        }
        pos += len + (len % 2);
    }
    let samples = decode_samples(pcm, bits, if fmt == 3 { "floating-point" } else if bits == 8 { "unsigned-integer" } else { "signed-integer" }, be);
    let encoding = if fmt == 3 { "floating-point" } else if bits == 8 { "unsigned-integer" } else { "signed-integer" };
    Ok(Audio { rate, channels, bits, encoding: encoding.into(), samples })
}

fn read_raw(data: &[u8], opts: &Opts, name: &str) -> Audio {
    let bits = opts.bits.unwrap_or_else(|| ext_bits(name).unwrap_or(16));
    let enc = opts.encoding.clone().unwrap_or_else(|| if name.ends_with(".u8") || name.ends_with(".u16") || name.ends_with(".u32") { "unsigned-integer".into() } else { "signed-integer".into() });
    let rate = opts.rate.unwrap_or(8000);
    let channels = opts.channels.unwrap_or(1);
    Audio { rate, channels, bits, encoding: enc.clone(), samples: decode_samples(data, bits, &enc, false) }
}

fn decode_samples(data: &[u8], bits: u16, enc: &str, be: bool) -> Vec<f64> {
    let mut out = Vec::new();
    match (bits, enc) {
        (8, "unsigned-integer") => out.extend(data.iter().map(|b| (*b as f64 - 128.0) / 128.0)),
        (8, _) => out.extend(data.iter().map(|b| (*b as i8 as f64) / 128.0)),
        (16, "unsigned-integer") => for c in data.chunks_exact(2) {
            let v = if be { u16::from_be_bytes([c[0], c[1]]) } else { u16::from_le_bytes([c[0], c[1]]) };
            out.push((v as f64 - 32768.0) / 32768.0);
        },
        (16, _) => for c in data.chunks_exact(2) {
            let v = if be { i16::from_be_bytes([c[0], c[1]]) } else { i16::from_le_bytes([c[0], c[1]]) };
            out.push(v as f64 / 32768.0);
        },
        (24, _) => for c in data.chunks_exact(3) {
            let raw = if be { ((c[0] as i32) << 16) | ((c[1] as i32) << 8) | c[2] as i32 } else { ((c[2] as i32) << 16) | ((c[1] as i32) << 8) | c[0] as i32 };
            let v = (raw << 8) >> 8;
            out.push(v as f64 / 8388608.0);
        },
        (32, "floating-point") => for c in data.chunks_exact(4) {
            let v = if be { f32::from_be_bytes([c[0], c[1], c[2], c[3]]) } else { f32::from_le_bytes([c[0], c[1], c[2], c[3]]) };
            out.push(v as f64);
        },
        (32, "unsigned-integer") => for c in data.chunks_exact(4) {
            let v = if be { u32::from_be_bytes([c[0], c[1], c[2], c[3]]) } else { u32::from_le_bytes([c[0], c[1], c[2], c[3]]) };
            out.push((v as f64 - 2147483648.0) / 2147483648.0);
        },
        _ => for c in data.chunks_exact(4) {
            let v = if be { i32::from_be_bytes([c[0], c[1], c[2], c[3]]) } else { i32::from_le_bytes([c[0], c[1], c[2], c[3]]) };
            out.push(v as f64 / 2147483648.0);
        },
    }
    out
}

fn write_audio(spec: &Spec, a: &Audio) -> Result<(), String> {
    let typ = file_type(&spec.name, spec.opts.typ.as_deref());
    let bytes = if typ == "wav" || typ == "wavpcm" { encode_wav(a) } else { encode_raw(a) };
    if spec.name == "-" {
        io::stdout().write_all(&bytes).map_err(|e| format!("formats: can't write output file `-': {e}"))
    } else {
        fs::write(&spec.name, bytes).map_err(|e| format!("formats: can't open output file `{}`: {}", spec.name, e))
    }
}

fn encode_wav(a: &Audio) -> Vec<u8> {
    let data = encode_raw(a);
    let fmt_size = 16u32;
    let audio_format = if a.encoding == "floating-point" { 3u16 } else { 1u16 };
    let block_align = a.channels * ((a.bits + 7) / 8);
    let byte_rate = a.rate * block_align as u32;
    let mut out = Vec::with_capacity(44 + data.len());
    out.extend_from_slice(b"RIFF");
    out.extend_from_slice(&(36u32 + data.len() as u32).to_le_bytes());
    out.extend_from_slice(b"WAVEfmt ");
    out.extend_from_slice(&fmt_size.to_le_bytes());
    out.extend_from_slice(&audio_format.to_le_bytes());
    out.extend_from_slice(&a.channels.to_le_bytes());
    out.extend_from_slice(&a.rate.to_le_bytes());
    out.extend_from_slice(&byte_rate.to_le_bytes());
    out.extend_from_slice(&block_align.to_le_bytes());
    out.extend_from_slice(&a.bits.to_le_bytes());
    out.extend_from_slice(b"data");
    out.extend_from_slice(&(data.len() as u32).to_le_bytes());
    out.extend_from_slice(&data);
    out
}

fn encode_raw(a: &Audio) -> Vec<u8> {
    let mut out = Vec::new();
    for &s in &a.samples {
        let x = s.clamp(-1.0, 1.0);
        match (a.bits, a.encoding.as_str()) {
            (8, "unsigned-integer") => out.push(((x * 127.0 + 128.0).round() as i32).clamp(0, 255) as u8),
            (8, _) => out.push(((x * 127.0).round() as i8) as u8),
            (16, "unsigned-integer") => out.extend_from_slice(&((x * 32767.0 + 32768.0).round() as u16).to_le_bytes()),
            (16, _) => out.extend_from_slice(&((x * 32767.0).round() as i16).to_le_bytes()),
            (24, _) => {
                let v = ((x * 8388607.0).round() as i32).to_le_bytes();
                out.extend_from_slice(&v[..3]);
            }
            (32, "floating-point") => out.extend_from_slice(&(x as f32).to_le_bytes()),
            (32, "unsigned-integer") => out.extend_from_slice(&((x * 2147483647.0 + 2147483648.0).round() as u32).to_le_bytes()),
            _ => out.extend_from_slice(&((x * 2147483647.0).round() as i32).to_le_bytes()),
        }
    }
    out
}

fn frames(a: &Audio) -> usize {
    if a.channels == 0 { 0 } else { a.samples.len() / a.channels as usize }
}

fn trim(a: &mut Audio, start: f64, len: Option<f64>) {
    let ch = a.channels as usize;
    let s = (start * a.rate as f64).round().max(0.0) as usize;
    let e = len.map(|l| s + (l * a.rate as f64).round().max(0.0) as usize).unwrap_or_else(|| frames(a));
    let sidx = (s * ch).min(a.samples.len());
    let eidx = (e * ch).min(a.samples.len());
    a.samples = a.samples[sidx..eidx].to_vec();
}

fn convert_channels(a: &mut Audio, channels: u16) {
    if channels == a.channels || channels == 0 { return; }
    let old = a.channels as usize;
    let new = channels as usize;
    let mut out = Vec::with_capacity(frames(a) * new);
    for f in 0..frames(a) {
        let frame = &a.samples[f * old..(f + 1) * old];
        for c in 0..new {
            let v = if old == 1 { frame[0] } else if new == 1 { frame.iter().sum::<f64>() / old as f64 } else { frame[c.min(old - 1)] };
            out.push(v);
        }
    }
    a.channels = channels;
    a.samples = out;
}

fn resample(a: &mut Audio, new_rate: u32) {
    if new_rate == a.rate || a.rate == 0 { return; }
    let old_frames = frames(a);
    let new_frames = ((old_frames as f64) * new_rate as f64 / a.rate as f64).round() as usize;
    let ch = a.channels as usize;
    let mut out = vec![0.0; new_frames * ch];
    for nf in 0..new_frames {
        let src = nf as f64 * a.rate as f64 / new_rate as f64;
        let i0 = src.floor() as usize;
        let i1 = (i0 + 1).min(old_frames.saturating_sub(1));
        let frac = src - i0 as f64;
        for c in 0..ch {
            let v0 = a.samples.get(i0 * ch + c).copied().unwrap_or(0.0);
            let v1 = a.samples.get(i1 * ch + c).copied().unwrap_or(v0);
            out[nf * ch + c] = v0 * (1.0 - frac) + v1 * frac;
        }
    }
    a.rate = new_rate;
    a.samples = out;
}

fn speed(a: &mut Audio, factor: f64) {
    if factor <= 0.0 { return; }
    let old_rate = a.rate;
    resample(a, (a.rate as f64 * factor).round() as u32);
    a.rate = old_rate;
}

fn reverse(a: &mut Audio) {
    let ch = a.channels as usize;
    let mut out = Vec::with_capacity(a.samples.len());
    for f in (0..frames(a)).rev() {
        out.extend_from_slice(&a.samples[f * ch..(f + 1) * ch]);
    }
    a.samples = out;
}

fn normalize(a: &mut Audio, db: f64) {
    let peak = a.samples.iter().fold(0.0_f64, |m, v| m.max(v.abs()));
    if peak > 0.0 {
        let target = 10f64.powf(db / 20.0);
        for v in &mut a.samples { *v *= target / peak; }
    }
}

fn apply_fade(a: &mut Audio, args: &[String]) {
    let vals: Vec<f64> = args.iter().take_while(|x| !is_effect(x)).filter_map(|x| parse_time(x).ok()).collect();
    let fade_in = vals.get(0).copied().unwrap_or(0.0);
    let stop = vals.get(1).copied();
    let fade_out = vals.get(2).copied().unwrap_or(0.0);
    if let Some(stop_t) = stop {
        let end = (stop_t * a.rate as f64).round() as usize;
        a.samples.truncate(end.min(frames(a)) * a.channels as usize);
    }
    let ch = a.channels as usize;
    let fi = (fade_in * a.rate as f64).round() as usize;
    for f in 0..fi.min(frames(a)) {
        let g = f as f64 / fi.max(1) as f64;
        for c in 0..ch { a.samples[f * ch + c] *= g; }
    }
    let fo = (fade_out * a.rate as f64).round() as usize;
    let n = frames(a);
    for k in 0..fo.min(n) {
        let f = n - 1 - k;
        let g = k as f64 / fo.max(1) as f64;
        for c in 0..ch { a.samples[f * ch + c] *= g; }
    }
}

fn print_stats(a: &Audio) {
    let n = a.samples.len().max(1) as f64;
    let min = a.samples.iter().fold(0.0_f64, |m, v| m.min(*v));
    let max = a.samples.iter().fold(0.0_f64, |m, v| m.max(*v));
    let mean = a.samples.iter().sum::<f64>() / n;
    let rms = (a.samples.iter().map(|v| v * v).sum::<f64>() / n).sqrt();
    eprintln!("Samples read:           {}", frames(a));
    eprintln!("Length (seconds):      {:.6}", frames(a) as f64 / a.rate as f64);
    eprintln!("Scaled by:         2147483647.0");
    eprintln!("Maximum amplitude:     {:.6}", max);
    eprintln!("Minimum amplitude:     {:.6}", min);
    eprintln!("Mean    amplitude:     {:.6}", mean);
    eprintln!("RMS     amplitude:     {:.6}", rms);
}

fn parse_rate(s: &str) -> Result<u32, String> {
    let lower = s.to_ascii_lowercase();
    if let Some(v) = lower.strip_suffix('k') {
        Ok((v.parse::<f64>().map_err(|_| "sox: bad rate")? * 1000.0).round() as u32)
    } else {
        Ok(lower.parse::<f64>().map_err(|_| "sox: bad rate")?.round() as u32)
    }
}

fn parse_freq(s: &str) -> Result<f64, String> {
    let mut t = s.trim_start_matches('%').to_ascii_lowercase();
    if let Some(v) = t.strip_suffix('k') {
        return Ok(v.parse::<f64>().map_err(|_| "bad freq")? * 1000.0);
    }
    if t.contains(':') { t = t.split(':').next().unwrap_or(&t).to_string(); }
    t.parse::<f64>().map_err(|_| "bad freq".into())
}

fn parse_time(s: &str) -> Result<f64, String> {
    let parts: Vec<&str> = s.split(':').collect();
    if parts.len() == 1 {
        return parts[0].parse::<f64>().map_err(|_| "bad time".into());
    }
    let mut total = 0.0;
    for p in parts {
        total = total * 60.0 + p.parse::<f64>().map_err(|_| "bad time")?;
    }
    Ok(total)
}

fn file_type(name: &str, forced: Option<&str>) -> String {
    if let Some(t) = forced { return t.to_string(); }
    let ext = Path::new(name).extension().and_then(|s| s.to_str()).unwrap_or("").to_ascii_lowercase();
    match ext.as_str() {
        "wav" | "wave" | "amb" => "wav".into(),
        "s16" | "s32" | "s8" | "u8" | "u16" | "u32" | "raw" => "raw".into(),
        "" if name == "-" => "raw".into(),
        _ => ext,
    }
}

fn ext_bits(name: &str) -> Option<u16> {
    let ext = Path::new(name).extension()?.to_str()?;
    match ext {
        "s8" | "u8" => Some(8),
        "s16" | "u16" => Some(16),
        "s24" | "u24" => Some(24),
        "s32" | "u32" => Some(32),
        _ => None,
    }
}

fn fmt_duration(sec: f64, hundredths: bool) -> String {
    let h = (sec / 3600.0).floor() as u64;
    let m = ((sec - h as f64 * 3600.0) / 60.0).floor() as u64;
    let s = sec - h as f64 * 3600.0 - m as f64 * 60.0;
    if hundredths {
        format!("{h:02}:{m:02}:{s:05.2}")
    } else {
        format!("{h:02}:{m:02}:{s:02.0}")
    }
}

fn encoding_name(a: &Audio) -> String {
    match a.encoding.as_str() {
        "unsigned-integer" => "Unsigned Integer PCM".into(),
        "floating-point" => "Floating Point PCM".into(),
        "mu-law" => "u-law".into(),
        "a-law" => "A-law".into(),
        _ => "Signed Integer PCM".into(),
    }
}

fn bitrate(a: &Audio, path: &str) -> String {
    let dur = frames(a) as f64 / a.rate as f64;
    let bits = if let Ok(md) = fs::metadata(path) {
        if dur > 0.0 { (md.len() as f64 * 8.0 / dur / 1000.0).round() as u64 } else { 0 }
    } else {
        (a.rate as u64 * a.channels as u64 * a.bits as u64) / 1000
    };
    format!("{bits}k")
}
