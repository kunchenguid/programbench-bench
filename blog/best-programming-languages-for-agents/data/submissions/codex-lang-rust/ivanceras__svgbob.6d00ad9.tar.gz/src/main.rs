use std::env;
use std::fs;
use std::io::{self, Read};
use std::path::Path;

const VERSION: &str = "svgbob 0.7.6";

#[derive(Clone)]
struct Opt {
    background: String,
    fill_color: String,
    stroke_color: String,
    font_family: String,
    font_size: String,
    stroke_width: String,
    scale: f32,
    output: Option<String>,
    inline: bool,
    input: Option<String>,
}

impl Default for Opt {
    fn default() -> Self {
        Self {
            background: "white".into(),
            fill_color: "black".into(),
            stroke_color: "black".into(),
            font_family: "Iosevka Fixed, monospace".into(),
            font_size: "14".into(),
            stroke_width: "2".into(),
            scale: 1.0,
            output: None,
            inline: false,
            input: None,
        }
    }
}

#[derive(Clone)]
enum Shape {
    Rect { x: i32, y: i32, w: i32, h: i32 },
    Line { x1: i32, y1: i32, x2: i32, y2: i32 },
    Poly { points: String },
}

#[derive(Clone)]
struct Text {
    x: i32,
    y: i32,
    s: String,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    if args.first().map(|s| s.as_str()) == Some("build") {
        build_cmd(&args[1..]);
        return;
    }
    let opt = match parse_args(&args) {
        Ok(o) => o,
        Err(code) => std::process::exit(code),
    };
    let input = match read_input(&opt) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(1);
        }
    };
    let svg = render(&input, &opt);
    if let Some(path) = &opt.output {
        if let Err(e) = fs::write(path, svg) {
            eprintln!("Failed to write output file {path}: {e}");
            std::process::exit(1);
        }
    } else {
        print!("{svg}");
    }
}

fn parse_args(args: &[String]) -> Result<Opt, i32> {
    let mut opt = Opt::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        match a.as_str() {
            "-h" | "--help" => {
                print_help();
                return Err(0);
            }
            "-V" | "--version" => {
                println!("{VERSION}");
                return Err(0);
            }
            "-s" | "--inline" => opt.inline = true,
            "-o" | "--output" => {
                i += 1;
                if i >= args.len() { missing(a); return Err(1); }
                opt.output = Some(args[i].clone());
            }
            "--background" => { i += 1; if i >= args.len() { missing(a); return Err(1); } opt.background = args[i].clone(); }
            "--fill-color" => { i += 1; if i >= args.len() { missing(a); return Err(1); } opt.fill_color = args[i].clone(); }
            "--stroke-color" => { i += 1; if i >= args.len() { missing(a); return Err(1); } opt.stroke_color = args[i].clone(); }
            "--font-family" => { i += 1; if i >= args.len() { missing(a); return Err(1); } opt.font_family = args[i].clone(); }
            "--font-size" => { i += 1; if i >= args.len() { missing(a); return Err(1); } opt.font_size = args[i].clone(); }
            "--stroke-width" => { i += 1; if i >= args.len() { missing(a); return Err(1); } opt.stroke_width = args[i].clone(); }
            "--scale" => {
                i += 1;
                if i >= args.len() { missing(a); return Err(1); }
                opt.scale = args[i].parse().unwrap_or(1.0);
            }
            _ if a.starts_with('-') => {
                eprintln!("error: Found argument '{}' which wasn't expected, or isn't valid in this context\n", a);
                eprintln!("USAGE:\n    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]\n\nFor more information try --help");
                return Err(1);
            }
            _ => {
                if opt.input.is_none() {
                    opt.input = Some(a.clone());
                }
            }
        }
        i += 1;
    }
    Ok(opt)
}

fn missing(a: &str) {
    eprintln!("error: The argument '{}' requires a value but none was supplied", a);
}

fn read_input(opt: &Opt) -> Result<String, String> {
    if opt.inline {
        return Ok(decode_inline(&opt.input.clone().unwrap_or_default()));
    }
    if let Some(path) = &opt.input {
        fs::read_to_string(path).map_err(|e| format!("Failed to open input file {path}: {e}"))
    } else {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| e.to_string())?;
        Ok(s)
    }
}

fn decode_inline(s: &str) -> String {
    let mut out = String::new();
    let mut chars = s.chars();
    while let Some(c) = chars.next() {
        if c == '\\' {
            match chars.next() {
                Some('n') => out.push('\n'),
                Some('t') => out.push('\t'),
                Some('\\') => out.push('\\'),
                Some(other) => {
                    out.push('\\');
                    out.push(other);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(c);
        }
    }
    out
}

fn render(input: &str, opt: &Opt) -> String {
    let raw_lines: Vec<&str> = input.trim_end_matches('\n').split('\n').collect();
    let lines: Vec<Vec<char>> = if input.is_empty() {
        vec![vec![]]
    } else {
        raw_lines.iter().map(|l| l.chars().collect()).collect()
    };
    let rows = lines.len();
    let cols = lines.iter().map(|l| l.len()).max().unwrap_or(0);
    let width = scale_dim(((cols + 1) * 8) as f32, opt.scale);
    let height = scale_dim(((rows + 1) * 16) as f32, opt.scale);
    let mut used = vec![vec![false; cols.max(1)]; rows.max(1)];
    let mut shapes = Vec::new();

    detect_rects(&lines, &mut used, &mut shapes);
    detect_arrows_and_hlines(&lines, &mut used, &mut shapes);
    detect_vlines(&lines, &mut used, &mut shapes);
    detect_diagonals(&lines, &mut used, &mut shapes);
    let texts = collect_text(&lines, &used);

    let mut out = String::new();
    out.push_str(&format!("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{}\" height=\"{}\" class=\"svgbob\">\n", width, height));
    out.push_str(&style(opt));
    out.push_str("  <defs>\n");
    out.push_str("    <marker id=\"arrow\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <polygon points=\"0,0 0,4 4,2 0,0\"></polygon>\n    </marker>\n");
    out.push_str("    <marker id=\"diamond\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <polygon points=\"0,2 2,0 4,2 2,4 0,2\"></polygon>\n    </marker>\n");
    out.push_str("    <marker id=\"circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"filled\"></circle>\n    </marker>\n");
    out.push_str("    <marker id=\"open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"bg_filled\"></circle>\n    </marker>\n");
    out.push_str("    <marker id=\"big_open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"3\" class=\"bg_filled\"></circle>\n    </marker>\n  </defs>\n");
    out.push_str(&format!("  <rect class=\"backdrop\" x=\"0\" y=\"0\" width=\"{}\" height=\"{}\"></rect>\n", width, height));
    for sh in shapes {
        match sh {
            Shape::Rect { x, y, w, h } => out.push_str(&format!("  <rect x=\"{}\" y=\"{}\" width=\"{}\" height=\"{}\" class=\"solid nofill\" rx=\"0\"></rect>\n", sx(x,opt), sx(y,opt), sx(w,opt), sx(h,opt))),
            Shape::Line { x1, y1, x2, y2 } => out.push_str(&format!("  <line x1=\"{}\" y1=\"{}\" x2=\"{}\" y2=\"{}\" class=\"solid\"></line>\n", sx(x1,opt), sx(y1,opt), sx(x2,opt), sx(y2,opt))),
            Shape::Poly { points } => out.push_str(&format!("  <polygon points=\"{}\" class=\"filled\"></polygon>\n", scale_points(&points, opt.scale))),
        }
    }
    for t in texts {
        out.push_str(&format!("  <text x=\"{}\" y=\"{}\" >{}</text>\n", sx(t.x,opt), sx(t.y,opt), escape(&t.s)));
    }
    out.push_str("</svg>\n");
    out
}

fn detect_rects(lines: &[Vec<char>], used: &mut [Vec<bool>], shapes: &mut Vec<Shape>) {
    for r1 in 0..lines.len() {
        for c1 in 0..lines[r1].len() {
            if lines[r1][c1] != '+' { continue; }
            for c2 in c1 + 2..lines[r1].len() {
                if lines[r1][c2] != '+' { continue; }
                if !(c1+1..c2).all(|c| lines[r1].get(c) == Some(&'-')) { continue; }
                for r2 in r1 + 2..lines.len() {
                    if lines[r2].get(c1) != Some(&'+') || lines[r2].get(c2) != Some(&'+') { continue; }
                    if !(c1+1..c2).all(|c| lines[r2].get(c) == Some(&'-')) { continue; }
                    if !(r1+1..r2).all(|r| lines[r].get(c1) == Some(&'|') && lines[r].get(c2) == Some(&'|')) { continue; }
                    shapes.push(Shape::Rect { x: c1 as i32 * 8 + 4, y: r1 as i32 * 16 + 8, w: (c2-c1) as i32 * 8, h: (r2-r1) as i32 * 16 });
                    for c in c1..=c2 { used[r1][c]=true; used[r2][c]=true; }
                    for r in r1..=r2 { used[r][c1]=true; used[r][c2]=true; }
                    break;
                }
            }
        }
    }
}

fn detect_arrows_and_hlines(lines: &[Vec<char>], used: &mut [Vec<bool>], shapes: &mut Vec<Shape>) {
    for (r, line) in lines.iter().enumerate() {
        let mut c = 0;
        while c < line.len() {
            let left_arrow = line[c] == '<' && c + 1 < line.len() && line[c+1] == '-' && !used[r][c+1];
            if (line[c] == '-' && !used[r][c]) || left_arrow {
                let start = c;
                if left_arrow { c += 1; }
                while c < line.len() && line[c] == '-' && !used[r][c] { c += 1; }
                let right_arrow = c < line.len() && line[c] == '>';
                let end = if right_arrow { c } else { c.saturating_sub(1) };
                if end > start {
                    let y = r as i32 * 16 + 8;
                    let x1 = if left_arrow { (start as i32 + 1) * 8 } else { start as i32 * 8 };
                    let x2 = if right_arrow { end as i32 * 8 } else { (end as i32 + 1) * 8 };
                    shapes.push(Shape::Line { x1, y1: y, x2, y2: y });
                    if left_arrow {
                        shapes.push(Shape::Poly { points: format!("{},{} {},{} {},{}", start*8+8, y-4, start*8, y, start*8+8, y+4) });
                    }
                    if right_arrow {
                        shapes.push(Shape::Poly { points: format!("{},{} {},{} {},{}", end*8, y-4, end*8+8, y, end*8, y+4) });
                    }
                    for cc in start..=end.min(line.len()-1) { used[r][cc] = true; }
                    if right_arrow { c += 1; }
                    continue;
                }
            }
            c += 1;
        }
    }
}

fn detect_vlines(lines: &[Vec<char>], used: &mut [Vec<bool>], shapes: &mut Vec<Shape>) {
    let cols = lines.iter().map(|l| l.len()).max().unwrap_or(0);
    for c in 0..cols {
        let mut r = 0;
        while r < lines.len() {
            if lines[r].get(c) == Some(&'|') && !used[r][c] {
                let start = r;
                while r < lines.len() && lines[r].get(c) == Some(&'|') && !used[r][c] { r += 1; }
                if r > start {
                    let x = c as i32 * 8 + 4;
                    shapes.push(Shape::Line { x1: x, y1: start as i32 * 16 - 4, x2: x, y2: r as i32 * 16 + 4 });
                    for rr in start..r { used[rr][c] = true; }
                }
            } else {
                r += 1;
            }
        }
        for r0 in 0..lines.len() {
            if lines[r0].get(c) == Some(&'^') {
                let y = r0 as i32 * 16;
                shapes.push(Shape::Poly { points: format!("{},{} {},{} {},{}", c*8, y+12, c*8+4, y, c*8+8, y+12) });
                used[r0][c] = true;
            } else if lines[r0].get(c) == Some(&'v') {
                let y = r0 as i32 * 16;
                shapes.push(Shape::Poly { points: format!("{},{} {},{} {},{}", c*8, y+4, c*8+8, y+4, c*8+4, y+16) });
                used[r0][c] = true;
            }
        }
    }
}

fn detect_diagonals(lines: &[Vec<char>], used: &mut [Vec<bool>], shapes: &mut Vec<Shape>) {
    for (r, line) in lines.iter().enumerate() {
        for (c, ch) in line.iter().enumerate() {
            if used[r][c] { continue; }
            let x = c as i32 * 8;
            let y = r as i32 * 16;
            if *ch == '/' {
                shapes.push(Shape::Line { x1: x+8, y1: y, x2: x, y2: y+16 });
                used[r][c] = true;
            } else if *ch == '\\' {
                shapes.push(Shape::Line { x1: x, y1: y, x2: x+8, y2: y+16 });
                used[r][c] = true;
            }
        }
    }
}

fn collect_text(lines: &[Vec<char>], used: &[Vec<bool>]) -> Vec<Text> {
    let mut texts = Vec::new();
    for (r, line) in lines.iter().enumerate() {
        let mut c = 0;
        while c < line.len() {
            while c < line.len() && (used[r][c] || line[c] == ' ') { c += 1; }
            let start = c;
            let mut s = String::new();
            while c < line.len() && !used[r][c] && !is_shape(line[c]) {
                s.push(line[c]);
                c += 1;
            }
            let s = s.trim_end().to_string();
            if !s.trim().is_empty() {
                texts.push(Text { x: start as i32 * 8 + 2, y: r as i32 * 16 + 12, s });
            }
            c += 1;
        }
    }
    texts
}

fn is_shape(c: char) -> bool {
    matches!(c, '+' | '-' | '|' | '/' | '\\' | '<' | '>' | '^' | 'v')
}

fn style(opt: &Opt) -> String {
    format!(r#"  <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {{
  stroke: {};
  stroke-width: {};
  stroke-opacity: 1;
  fill-opacity: 1;
  stroke-linecap: round;
  stroke-linejoin: miter;
}}

.svgbob text {{
  white-space: pre;
  fill: {};
  font-family: {};
  font-size: {}px;
}}

.svgbob rect.backdrop {{
  stroke: none;
  fill: {};
}}

.svgbob .broken {{
  stroke-dasharray: 8;
}}

.svgbob .filled {{
  fill: {};
}}

.svgbob .bg_filled {{
  fill: {};
  stroke-width: 1;
}}

.svgbob .nofill {{
  fill: {};
}}

.svgbob .end_marked_arrow {{
  marker-end: url(#arrow);
}}

.svgbob .start_marked_arrow {{
  marker-start: url(#arrow);
}}

.svgbob .end_marked_diamond {{
  marker-end: url(#diamond);
}}

.svgbob .start_marked_diamond {{
  marker-start: url(#diamond);
}}

.svgbob .end_marked_circle {{
  marker-end: url(#circle);
}}

.svgbob .start_marked_circle {{
  marker-start: url(#circle);
}}

.svgbob .end_marked_open_circle {{
  marker-end: url(#open_circle);
}}

.svgbob .start_marked_open_circle {{
  marker-start: url(#open_circle);
}}

.svgbob .end_marked_big_open_circle {{
  marker-end: url(#big_open_circle);
}}

.svgbob .start_marked_big_open_circle {{
  marker-start: url(#big_open_circle);
}}

</style>
"#, opt.stroke_color, opt.stroke_width, opt.stroke_color, opt.font_family, opt.font_size, opt.background, opt.fill_color, opt.background, opt.background)
}

fn escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;")
}

fn sx(v: i32, opt: &Opt) -> String {
    scale_dim(v as f32, opt.scale)
}

fn scale_dim(v: f32, scale: f32) -> String {
    let n = v * scale;
    if (n.fract()).abs() < 0.0001 { format!("{}", n as i32) } else { format!("{:.2}", n) }
}

fn scale_points(points: &str, scale: f32) -> String {
    if (scale - 1.0).abs() < 0.0001 { return points.to_string(); }
    points.split_whitespace().map(|p| {
        let mut it = p.split(',');
        let x: f32 = it.next().unwrap_or("0").parse().unwrap_or(0.0);
        let y: f32 = it.next().unwrap_or("0").parse().unwrap_or(0.0);
        format!("{},{}", scale_dim(x, scale), scale_dim(y, scale))
    }).collect::<Vec<_>>().join(" ")
}

fn print_help() {
    println!("svgbob 0.7.6\nSvgBobRus is an ascii to svg converter\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]\n\nFLAGS:\n    -h, --help       Prints help information\n    -s               parse an inline string\n    -V, --version    Prints version information\n\nOPTIONS:\n        --background <background>        backdrop background will be filled with this color (default: 'white')\n        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')\n        --font-family <font-family>      text will be rendered with this font (default: 'arial')\n        --font-size <font-size>          text will be rendered with this font size (default: 14)\n    -o, --output <output>                where to write svg output [default: STDOUT]\n        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor\n                                         (default: 1)\n        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')\n        --stroke-width <stroke-width>    stroke width for all lines (default: 2)\n\nARGS:\n    <input>    svgbob text file or inline string to parse [default: STDIN]\n\nSUBCOMMANDS:\n    build    Batch convert files to svg.\n    help     Prints this message or the help of the given subcommand(s)");
}

fn build_cmd(args: &[String]) {
    if args.iter().any(|a| a == "-h" || a == "--help") {
        println!("executable-build 0.0.1\nBatch convert files to svg.\n\nUSAGE:\n    executable build [OPTIONS]\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob\n    -o, --outdir <outdir>    set dir of svg files");
        return;
    }
    if args.iter().any(|a| a == "-V" || a == "--version") {
        println!("executable-build 0.0.1");
        return;
    }
    let mut input = String::new();
    let mut outdir = String::new();
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "-i" | "--input" => { i += 1; if i < args.len() { input = args[i].clone(); } }
            "-o" | "--outdir" => { i += 1; if i < args.len() { outdir = args[i].clone(); } }
            _ => {}
        }
        i += 1;
    }
    if outdir.is_empty() || !Path::new(&outdir).is_dir() {
        println!("[Error]: No such dir name is {} !", outdir);
        std::process::exit(1);
    }
    let files = expand_simple_glob(&input);
    for f in files {
        if let Ok(data) = fs::read_to_string(&f) {
            let opt = Opt::default();
            let svg = render(&data, &opt);
            let stem = Path::new(&f).file_stem().unwrap_or_default().to_string_lossy();
            let out = Path::new(&outdir).join(format!("{stem}.svg"));
            let _ = fs::write(out, svg);
        }
    }
}

fn expand_simple_glob(pattern: &str) -> Vec<String> {
    if !pattern.contains('*') {
        return vec![pattern.to_string()];
    }
    let path = Path::new(pattern);
    let dir = path.parent().filter(|p| !p.as_os_str().is_empty()).unwrap_or_else(|| Path::new("."));
    let pat = path.file_name().unwrap_or_default().to_string_lossy();
    let suffix = pat.trim_start_matches('*');
    let prefix = pat.trim_end_matches(suffix).trim_end_matches('*');
    let mut out = Vec::new();
    if let Ok(rd) = fs::read_dir(dir) {
        for e in rd.flatten() {
            let name = e.file_name().to_string_lossy().to_string();
            if name.starts_with(prefix) && name.ends_with(suffix) {
                out.push(e.path().to_string_lossy().to_string());
            }
        }
    }
    out.sort();
    out
}
