use chrono::{DateTime, Local};
use std::cmp::Ordering;
use std::collections::HashMap;
use std::env;
use std::fs::{self, Metadata};
use std::os::unix::fs::{FileTypeExt, MetadataExt};
use std::path::{Path, PathBuf};
use std::time::{SystemTime, UNIX_EPOCH};

const VERSION: &str = "pls 0.0.1-beta.9";
const ARROW: &str = "\u{f0054}";

#[derive(Clone)]
struct Opts {
    details: Vec<String>,
    header: bool,
    unit: String,
    grid: bool,
    down: bool,
    icon: bool,
    suffix: bool,
    sym: bool,
    collapse: bool,
    align: bool,
    types: Vec<String>,
    imp: i32,
    exclude: Vec<String>,
    only: Vec<String>,
    sort: Vec<String>,
    paths: Vec<String>,
}

impl Default for Opts {
    fn default() -> Self {
        Self {
            details: vec!["none".into()],
            header: true,
            unit: "binary".into(),
            grid: false,
            down: false,
            icon: true,
            suffix: true,
            sym: true,
            collapse: true,
            align: true,
            types: vec!["all".into()],
            imp: 0,
            exclude: vec![],
            only: vec![],
            sort: vec!["cat".into(), "cname".into()],
            paths: vec![],
        }
    }
}

#[derive(Clone)]
struct Node {
    name: String,
    md: Metadata,
    link_target: Option<String>,
    from_dir: bool,
}

fn main() {
    let mut opts = Opts::default();
    if let Err(code) = parse_args(&mut opts) {
        std::process::exit(code);
    }
    if opts.paths.is_empty() {
        opts.paths.push(".".into());
    }

    let multi = opts.paths.len() > 1;
    let mut first_section = true;
    for p in &opts.paths {
        let path = Path::new(p);
        match fs::symlink_metadata(path) {
            Ok(md) if md.is_dir() => {
                if multi {
                    if !first_section {
                        println!();
                    } else {
                        println!();
                    }
                    println!("{}:", display_path_arg(p));
                }
                let nodes = read_dir_nodes(path, &opts);
                print_nodes(&nodes, &opts);
            }
            Ok(md) => {
                let node = make_node(path.to_path_buf(), path.file_name().and_then(|s| s.to_str()).unwrap_or(p).to_string(), md, false);
                print_nodes(&[node], &opts);
            }
            Err(e) => {
                println!("{}:", p);
                println!("\terror: {}", e);
            }
        }
        first_section = false;
    }
}

fn display_path_arg(p: &str) -> String {
    if p == "." { ".".into() } else { p.trim_end_matches('/').into() }
}

fn parse_args(opts: &mut Opts) -> Result<(), i32> {
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => {
                print_help();
                return Err(0);
            }
            "-V" | "--version" => {
                println!("{}", VERSION);
                return Err(0);
            }
            "-d" | "--det" => push_val(&mut it, &arg, &mut opts.details, DETAILS)?,
            "-H" | "--header" => opts.header = parse_bool(&next_val(&mut it, &arg)?, "--header")?,
            "-u" | "--unit" => opts.unit = parse_choice(&next_val(&mut it, &arg)?, "--unit", &["binary","decimal","none"])?,
            "-g" | "--grid" => opts.grid = parse_bool(&next_val(&mut it, &arg)?, "--grid")?,
            "-D" | "--down" => opts.down = parse_bool(&next_val(&mut it, &arg)?, "--down")?,
            "-i" | "--icon" => opts.icon = parse_bool(&next_val(&mut it, &arg)?, "--icon")?,
            "-S" | "--suffix" => opts.suffix = parse_bool(&next_val(&mut it, &arg)?, "--suffix")?,
            "-l" | "--sym" => opts.sym = parse_bool(&next_val(&mut it, &arg)?, "--sym")?,
            "-c" | "--collapse" => opts.collapse = parse_bool(&next_val(&mut it, &arg)?, "--collapse")?,
            "-a" | "--align" => opts.align = parse_bool(&next_val(&mut it, &arg)?, "--align")?,
            "-t" | "--typ" => push_val(&mut it, &arg, &mut opts.types, TYPES)?,
            "-I" | "--imp" => opts.imp = next_val(&mut it, &arg)?.parse().unwrap_or(0),
            "-e" | "--exclude" => opts.exclude.push(next_val(&mut it, &arg)?),
            "-o" | "--only" => opts.only.push(next_val(&mut it, &arg)?),
            "-s" | "--sort" => push_val(&mut it, &arg, &mut opts.sort, SORTS)?,
            "--" => {
                opts.paths.extend(it);
                break;
            }
            _ if arg.starts_with('-') => {
                eprintln!("error: unexpected argument '{}' found", arg);
                eprintln!();
                eprintln!("  tip: to pass '{}' as a value, use '-- {}'", arg, arg);
                eprintln!();
                eprintln!("Usage: executable [OPTIONS] [PATHS]...");
                eprintln!();
                eprintln!("For more information, try '--help'.");
                return Err(2);
            }
            _ => opts.paths.push(arg),
        }
    }
    if opts.details.len() > 1 {
        opts.details.retain(|d| d != "none");
    }
    if opts.types.len() > 1 {
        opts.types.retain(|d| d != "all");
    }
    if opts.sort.len() > 2 || (opts.sort.len() > 1 && opts.sort[0] == "cat" && opts.sort[1] == "cname") {
        if opts.sort.len() > 2 {
            opts.sort.drain(0..2);
        }
    }
    Ok(())
}

fn next_val<I: Iterator<Item = String>>(it: &mut std::iter::Peekable<I>, flag: &str) -> Result<String, i32> {
    it.next().ok_or_else(|| {
        eprintln!("error: a value is required for '{} <{}>'", flag, flag.trim_start_matches('-').to_uppercase());
        2
    })
}

fn push_val<I: Iterator<Item = String>>(it: &mut std::iter::Peekable<I>, flag: &str, out: &mut Vec<String>, choices: &[&str]) -> Result<(), i32> {
    let v = next_val(it, flag)?;
    if choices.contains(&v.as_str()) {
        out.push(v);
        Ok(())
    } else {
        eprintln!("error: invalid value '{}' for '{} <{}>'", v, flag, flag.trim_start_matches('-').to_uppercase());
        eprintln!("  [possible values: {}]", choices.join(", "));
        eprintln!();
        eprintln!("For more information, try '--help'.");
        Err(2)
    }
}

fn parse_choice(v: &str, flag: &str, choices: &[&str]) -> Result<String, i32> {
    if choices.contains(&v) {
        Ok(v.into())
    } else {
        eprintln!("error: invalid value '{}' for '{} <{}>'", v, flag, flag.trim_start_matches('-').to_uppercase());
        eprintln!("  [possible values: {}]", choices.join(", "));
        Err(2)
    }
}

fn parse_bool(v: &str, flag: &str) -> Result<bool, i32> {
    match v {
        "true" => Ok(true),
        "false" => Ok(false),
        _ => {
            eprintln!("error: invalid value '{}' for '{} <{}>'", v, flag, flag.trim_start_matches('-').to_uppercase());
            eprintln!("  [possible values: true, false]");
            Err(2)
        }
    }
}

const DETAILS: &[&str] = &["dev","ino","nlink","typ","perm","oct","user","uid","group","gid","size","blocks","btime","ctime","mtime","atime","git","none","std","all"];
const TYPES: &[&str] = &["dir","symlink","fifo","socket","block-device","char-device","file","none","all"];
const SORTS: &[&str] = &["dev","ino","nlink","typ","cat","user","uid","group","gid","size","blocks","btime","ctime","mtime","atime","name","cname","ext","inode_","nlinks_","typ_","cat_","user_","uid_","group_","gid_","size_","blocks_","btime_","ctime_","mtime_","atime_","name_","cname_","ext_","none"];

fn print_help() {
    println!("pls is a prettier and powerful ls(1) for the pros.\n");
    println!("Read docs: https://pls.cli.rs/");
    println!("Get source: https://github.com/pls-rs/pls/");
    println!("Sponsor: https://github.com/sponsors/dhruvkb/\n");
    println!("Usage: executable [OPTIONS] [PATHS]...\n");
    println!("Arguments:");
    println!("  [PATHS]...\n          the paths to list, each of which may be a file or directory\n          \n          [default: .]\n");
    println!("Options:");
    println!("  -h, --help\n          Print help (see a summary with '-h')\n");
    println!("  -V, --version\n          Print version\n");
    println!("Detail view:");
    println!("  -d, --det <DETAILS>\n          the data points to show about each node\n          \n          [default: none]\n          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,\n          btime, ctime, mtime, atime, git, none, std, all]\n");
    println!("  -H, --header <HEADER>\n          show headers above columnar data\n          \n          [default: true]\n          [possible values: true, false]\n");
    println!("  -u, --unit <UNIT>\n          the type of units to use for the node sizes\n          \n          [default: binary]\n          [possible values: binary, decimal, none]\n");
    println!("Grid view:");
    println!("  -g, --grid <GRID>\n          display node names in multiple columns\n          \n          [default: false]\n          [possible values: true, false]\n");
    println!("  -D, --down <DOWN>\n          display node names column-first\n          \n          [default: false]\n          [possible values: true, false]\n");
    println!("Presentation:");
    println!("  -i, --icon <ICON>\n          display icons next to node names\n          \n          [default: true]\n          [possible values: true, false]\n");
    println!("  -S, --suffix <SUFFIX>\n          display node type suffixes after the node name\n          \n          [default: true]\n          [possible values: true, false]\n");
    println!("  -l, --sym <SYM>\n          show symlink targets\n          \n          [default: true]\n          [possible values: true, false]\n");
    println!("  -c, --collapse <COLLAPSE>\n          show dependent nodes as children of their principal nodes\n          \n          [default: true]\n          [possible values: true, false]\n");
    println!("  -a, --align <ALIGN>\n          align items accounting for leading dots\n          \n          [default: true]\n          [possible values: true, false]\n");
    println!("Filtering:");
    println!("  -t, --typ <TYPES>\n          the set of node types to include in the output\n          \n          [default: all]\n          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]\n");
    println!("  -I, --imp <IMP>\n          the importance cutoff to dim or hide unimportant files\n          \n          [default: 0]\n");
    println!("  -e, --exclude <EXCLUDE>\n          the pattern of files to selectively hide from the output\n");
    println!("  -o, --only <ONLY>\n          the pattern of files to exclusively show in the output\n");
    println!("Sorting:");
    println!("  -s, --sort <SORT_BASES>\n          the set of fields to sort by, trailing `_` reverses the direction\n          \n          [default: cat cname]\n          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,\n          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,\n          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]");
}

fn read_dir_nodes(path: &Path, opts: &Opts) -> Vec<Node> {
    let mut out = vec![];
    if let Ok(rd) = fs::read_dir(path) {
        for ent in rd.flatten() {
            let name = ent.file_name().to_string_lossy().to_string();
            if let Ok(md) = fs::symlink_metadata(ent.path()) {
                let node = make_node(ent.path(), name, md, true);
                if include_node(&node, opts) {
                    out.push(node);
                }
            }
        }
    }
    sort_nodes(&mut out, opts);
    out
}

fn make_node(path: PathBuf, name: String, md: Metadata, from_dir: bool) -> Node {
    let link_target = if md.file_type().is_symlink() {
        fs::read_link(&path).ok().map(|p| p.to_string_lossy().to_string())
    } else {
        None
    };
    Node { name, md, link_target, from_dir }
}

fn include_node(n: &Node, opts: &Opts) -> bool {
    if opts.types.iter().any(|t| t == "none") {
        return false;
    }
    if !opts.types.iter().any(|t| t == "all") && !opts.types.iter().any(|t| type_name(n) == t.as_str()) {
        return false;
    }
    if !opts.only.is_empty() && !opts.only.iter().any(|p| pat_match(p, &n.name)) {
        return false;
    }
    if opts.exclude.iter().any(|p| pat_match(p, &n.name)) {
        return false;
    }
    true
}

fn pat_match(p: &str, name: &str) -> bool {
    if p == name || name.contains(p) {
        return true;
    }
    if p.contains('*') {
        let parts: Vec<_> = p.split('*').collect();
        let mut pos = 0usize;
        for (i, part) in parts.iter().enumerate() {
            if part.is_empty() { continue; }
            if let Some(found) = name[pos..].find(part) {
                if i == 0 && !p.starts_with('*') && found != 0 { return false; }
                pos += found + part.len();
            } else {
                return false;
            }
        }
        if !p.ends_with('*') && !name.ends_with(parts.last().unwrap_or(&"")) { return false; }
        return true;
    }
    false
}

fn sort_nodes(nodes: &mut [Node], opts: &Opts) {
    nodes.sort_by(|a, b| {
        for s in &opts.sort {
            if s == "none" { return Ordering::Equal; }
            let rev = s.ends_with('_');
            let base = s.trim_end_matches('_');
            let ord = cmp_by(base, a, b);
            if ord != Ordering::Equal {
                return if rev { ord.reverse() } else { ord };
            }
        }
        Ordering::Equal
    });
}

fn cmp_by(base: &str, a: &Node, b: &Node) -> Ordering {
    match base {
        "dev" => a.md.dev().cmp(&b.md.dev()),
        "ino" | "inode" => a.md.ino().cmp(&b.md.ino()),
        "nlink" | "nlinks" => a.md.nlink().cmp(&b.md.nlink()),
        "typ" => type_letter(a).cmp(&type_letter(b)),
        "cat" => cat_rank(a).cmp(&cat_rank(b)),
        "user" => user_name(a.md.uid()).cmp(&user_name(b.md.uid())),
        "uid" => a.md.uid().cmp(&b.md.uid()),
        "group" => group_name(a.md.gid()).cmp(&group_name(b.md.gid())),
        "gid" => a.md.gid().cmp(&b.md.gid()),
        "size" => a.md.size().cmp(&b.md.size()),
        "blocks" => a.md.blocks().cmp(&b.md.blocks()),
        "btime" | "ctime" => a.md.ctime().cmp(&b.md.ctime()),
        "mtime" => a.md.mtime().cmp(&b.md.mtime()),
        "atime" => a.md.atime().cmp(&b.md.atime()),
        "name" => a.name.cmp(&b.name),
        "cname" => clean_name(&a.name).cmp(&clean_name(&b.name)),
        "ext" => ext(&a.name).cmp(&ext(&b.name)).then_with(|| clean_name(&a.name).cmp(&clean_name(&b.name))),
        _ => Ordering::Equal,
    }
}

fn print_nodes(nodes: &[Node], opts: &Opts) {
    let fields = expand_details(&opts.details);
    if fields.is_empty() {
        for n in nodes {
            let mut line = String::new();
            if n.from_dir && opts.align && !opts.icon && !n.name.starts_with('.') {
                line.push(' ');
            }
            line.push_str(&rendered_name(n, opts, !opts.grid));
            println!("{}", line);
        }
        return;
    }
    let rows: Vec<Vec<String>> = nodes.iter().map(|n| fields.iter().map(|f| detail_value(f, n, opts)).collect()).collect();
    let headers: Vec<String> = fields.iter().map(|f| header_for(f).into()).collect();
    let mut widths: Vec<usize> = headers.iter().map(|h| h.len()).collect();
    for row in &rows {
        for (i, val) in row.iter().enumerate() {
            widths[i] = widths[i].max(display_width(val));
        }
    }
    if opts.header {
        println!("{}", format_row(&headers, &widths, &fields, None, opts));
    }
    for (n, row) in nodes.iter().zip(rows.iter()) {
        println!("{}", format_row(row, &widths, &fields, Some(n), opts));
    }
}

fn expand_details(ds: &[String]) -> Vec<String> {
    let mut out = vec![];
    for d in ds {
        match d.as_str() {
            "none" => {}
            "std" => out.extend(["nlink","typ","perm","user","group","size","mtime"].iter().map(|s| s.to_string())),
            "all" => out.extend(["dev","ino","nlink","typ","perm","oct","user","uid","group","gid","size","blocks","btime","ctime","mtime","atime","git"].iter().map(|s| s.to_string())),
            other => out.push(other.to_string()),
        }
    }
    if out.is_empty() {
        return out;
    }
    out.push("name".into());
    out
}

fn format_row(row: &[String], widths: &[usize], fields: &[String], node: Option<&Node>, opts: &Opts) -> String {
    let mut s = String::new();
    for (i, val) in row.iter().enumerate() {
        if i > 0 { s.push(' '); }
        let right = matches!(fields[i].as_str(), "dev"|"ino"|"nlink"|"oct"|"uid"|"gid"|"size"|"blocks");
        if fields[i] == "name" {
            if node.is_some() && opts.align && !val.starts_with('.') { s.push(' '); }
            s.push_str(val);
        } else if right {
            s.push_str(&format!("{:>width$}", val, width = widths[i]));
        } else {
            s.push_str(&format!("{:<width$}", val, width = widths[i]));
        }
    }
    s
}

fn header_for(f: &str) -> &'static str {
    match f {
        "dev" => "Device", "ino" => "inode", "nlink" => "Link#", "typ" => "T", "perm" => "Permissions",
        "oct" => "SUGO", "user" => "User", "uid" => "UID", "group" => "Group", "gid" => "GID",
        "size" => "Size", "blocks" => "Blocks", "btime" => "Created", "ctime" => "Changed",
        "mtime" => "Modified", "atime" => "Accessed", "git" => "Git", "name" => "Name", _ => "",
    }
}

fn detail_value(f: &str, n: &Node, opts: &Opts) -> String {
    match f {
        "dev" => n.md.dev().to_string(),
        "ino" => n.md.ino().to_string(),
        "nlink" => n.md.nlink().to_string(),
        "typ" => type_letter(n).to_string(),
        "perm" => perms(n.md.mode()),
        "oct" => format!("{:o}", n.md.mode() & 0o777),
        "user" => user_name(n.md.uid()),
        "uid" => n.md.uid().to_string(),
        "group" => group_name(n.md.gid()),
        "gid" => n.md.gid().to_string(),
        "size" => if n.md.is_dir() { String::new() } else { format_size(n.md.size(), &opts.unit) },
        "blocks" => n.md.blocks().to_string(),
        "btime" => fmt_time(n.md.ctime(), n.md.ctime_nsec()),
        "ctime" => fmt_time(n.md.ctime(), n.md.ctime_nsec()),
        "mtime" => fmt_time(n.md.mtime(), n.md.mtime_nsec()),
        "atime" => fmt_time(n.md.atime(), n.md.atime_nsec()),
        "git" => String::new(),
        "name" => rendered_name(n, opts, true),
        _ => String::new(),
    }
}

fn rendered_name(n: &Node, opts: &Opts, show_target: bool) -> String {
    let mut s = String::new();
    if opts.icon {
        let ic = icon(n);
        if ic.is_empty() { s.push_str("  "); } else { s.push_str(ic); s.push_str("  "); }
    }
    s.push_str(&n.name);
    if opts.suffix {
        s.push_str(suffix(n));
    }
    if opts.sym && show_target {
        if let Some(t) = &n.link_target {
            s.push(' ');
            s.push_str(ARROW);
            s.push(' ');
            s.push_str(t);
        }
    }
    s
}

fn type_name(n: &Node) -> &'static str {
    let ft = n.md.file_type();
    if ft.is_dir() { "dir" } else if ft.is_symlink() { "symlink" } else if ft.is_fifo() { "fifo" } else if ft.is_socket() { "socket" } else if ft.is_block_device() { "block-device" } else if ft.is_char_device() { "char-device" } else { "file" }
}

fn type_letter(n: &Node) -> char {
    match type_name(n) {
        "dir" => 'd', "symlink" => 'l', "fifo" => 'p', "socket" => 's', "block-device" => 'b', "char-device" => 'c', _ => 'f'
    }
}

fn suffix(n: &Node) -> &'static str {
    match type_name(n) {
        "dir" => "/",
        "symlink" => "@",
        "fifo" => "|",
        "socket" => "=",
        _ if n.md.mode() & 0o111 != 0 => "*",
        _ => "",
    }
}

fn cat_rank(n: &Node) -> u8 {
    match type_name(n) {
        "dir" => 0, _ => 1
    }
}

fn icon(n: &Node) -> &'static str {
    if n.md.is_dir() { "\u{f07b}" }
    else if n.md.file_type().is_symlink() { "\u{f0339}" }
    else if n.md.file_type().is_fifo() { "\u{f07e5}" }
    else {
        match ext(&n.name).as_str() {
            "md" => "\u{f02d}",
            "rs" => "\u{e68b}",
            "txt" => "\u{e612}",
            _ => "",
        }
    }
}

fn perms(mode: u32) -> String {
    let mut s = String::new();
    for shift in [6, 3, 0] {
        s.push(if mode & (0o4 << shift) != 0 { 'r' } else { '-' });
        s.push(if mode & (0o2 << shift) != 0 { 'w' } else { '-' });
        s.push(if mode & (0o1 << shift) != 0 { 'x' } else { '-' });
        if shift != 0 { s.push(' '); }
    }
    s
}

fn format_size(size: u64, unit: &str) -> String {
    if unit == "none" {
        return format!("{} B", size);
    }
    let base = if unit == "decimal" { 1000.0 } else { 1024.0 };
    let labels = if unit == "decimal" { ["B","KB","MB","GB","TB"] } else { ["B","KiB","MiB","GiB","TiB"] };
    let mut v = size as f64;
    let mut i = 0usize;
    while v >= base && i + 1 < labels.len() {
        v /= base;
        i += 1;
    }
    if i == 0 {
        format!("{:.1}   B", v)
    } else {
        format!("{:.1} {}", v, labels[i])
    }
}

fn fmt_time(sec: i64, nsec: i64) -> String {
    let st = if sec >= 0 {
        UNIX_EPOCH + std::time::Duration::new(sec as u64, nsec.max(0) as u32)
    } else {
        SystemTime::now()
    };
    let dt: DateTime<Local> = st.into();
    dt.format("%Y-%b-%d %I:%M%P").to_string()
}

fn clean_name(s: &str) -> String {
    s.trim_start_matches('.').to_ascii_lowercase()
}

fn ext(s: &str) -> String {
    Path::new(s).extension().and_then(|e| e.to_str()).unwrap_or("").to_ascii_lowercase()
}

fn display_width(s: &str) -> usize { s.chars().count() }

fn user_name(uid: u32) -> String {
    passwd_map().get(&uid).cloned().unwrap_or_else(|| uid.to_string())
}

fn group_name(gid: u32) -> String {
    group_map().get(&gid).cloned().unwrap_or_else(|| gid.to_string())
}

fn passwd_map() -> HashMap<u32, String> {
    let mut m = HashMap::new();
    if let Ok(s) = fs::read_to_string("/etc/passwd") {
        for line in s.lines() {
            let parts: Vec<_> = line.split(':').collect();
            if parts.len() > 2 {
                if let Ok(id) = parts[2].parse() { m.insert(id, parts[0].to_string()); }
            }
        }
    }
    m
}

fn group_map() -> HashMap<u32, String> {
    let mut m = HashMap::new();
    if let Ok(s) = fs::read_to_string("/etc/group") {
        for line in s.lines() {
            let parts: Vec<_> = line.split(':').collect();
            if parts.len() > 2 {
                if let Ok(id) = parts[2].parse() { m.insert(id, parts[0].to_string()); }
            }
        }
    }
    m
}
