use chrono::Local;
use serde::Serialize;
use std::env;
use std::fs::{self, OpenOptions};
use std::io::{self, Write};
use std::process::{Command, Stdio};
use std::thread;
use std::time::{Duration, Instant};

const VERSION: &str = "0.3.19";
const HELP: &str = r#"A modern alternative to the watch command, records the differences in execution results and can check this differences at after.

Usage: executable [OPTIONS] [command]...

Arguments:
  [command]...  

Options:
  -b, --batch                         output execution results to stdout
  -B, --beep                          beep if command has a change result
      --border                        Surround each pane with a border frame
      --with-scrollbar                When the border option is enabled, display scrollbar on the right side of watch pane.
      --mouse                         enable mouse wheel support. With this option, copying text with your terminal may be harder. Try holding the Shift key.
  -c, --color                         interpret ANSI color and style sequences
  -r, --reverse                       display text upside down.
  -C, --compress                      Compress data in memory. Note: If the output of the command is small, you may not get the desired effect.
  -t, --no-title                      hide the UI on start. Use `t` to toggle it.
      --enable-summary-char           collect character-level diff count in summary.
  -N, --line-number                   show line number
      --no-help-banner                hide the "Display help with h key" message
      --no-summary                    disable the calculation for summary that is running behind the scenes, and disable the summary function in the first place.
  -x, --exec                          Run the command directly, not through the shell. Much like the `-x` option of the watch command.
  -O, --diff-output-only              Display only the lines with differences during `line` diff and `word` diff.
  -A, --aftercommand <after_command>  Executes the specified command if the output changes. Information about changes is stored in json format in environment variable ${HWATCH_DATA}.
  -l, --logfile [<logfile>]           logging file. if a log file is already used, its contents will be read and executed.
  -s, --shell <shell_command>         shell to use at runtime. can also insert the command to the location specified by {COMMAND}. [default: "sh -c"]
  -n, --interval <interval>           seconds to wait between updates [default: 2]
      --precise                       Attempt to run as close to the interval as possible, regardless of how long the command takes to run
  -L, --limit <limit>                 Set the number of history records to keep. only work in watch mode. Set `0` for unlimited recording. (default: 5000) [default: 5000]
      --tab-size <tab_size>           Specifying tab display size [default: 4]
  -d, --differences [<differences>]   highlight changes between updates [possible values: none, watch, line, word]
  -o, --output [<output>]             Select command output. [default: output] [possible values: output, stdout, stderr]
  -K, --keymap <keymap>               Add keymap
  -h, --help                          Print help
  -V, --version                       Print version
"#;

#[derive(Clone, Copy, PartialEq)]
enum OutputMode { Output, Stdout, Stderr }

struct Config {
    batch: bool,
    exec: bool,
    reverse: bool,
    line_number: bool,
    interval: f64,
    precise: bool,
    shell: String,
    logfile: Option<String>,
    after: Option<String>,
    output: OutputMode,
    command: Vec<String>,
}

#[derive(Serialize, Clone)]
struct Record {
    timestamp: String,
    command: String,
    status: bool,
    output: String,
    stdout: String,
    stderr: String,
}

fn main() {
    match run() {
        Ok(code) => std::process::exit(code),
        Err((msg, code)) => {
            if !msg.is_empty() { eprintln!("{msg}"); }
            std::process::exit(code);
        }
    }
}

fn run() -> Result<i32, (String, i32)> {
    let args = merged_args();
    let cfg = parse_args(&args)?;
    if cfg.command.is_empty() {
        if let Some(path) = &cfg.logfile {
            if fs::metadata(path).map(|m| m.len() > 0).unwrap_or(false) {
                replay_log(path)?;
                return Ok(0);
            }
        }
        return Err(("error: command not specified and logfile is empty.\n\nUsage: hwatch [OPTIONS] [command]...\n\nFor more information, try '--help'.".to_string(), 2));
    }

    if !cfg.batch {
        eprintln!("Display help with h key");
    }

    if let Some(path) = &cfg.logfile {
        if fs::metadata(path).map(|m| m.len() == 0).unwrap_or(true) {
            let blank = Record { timestamp: String::new(), command: String::new(), status: true, output: String::new(), stdout: String::new(), stderr: String::new() };
            append_log(path, &blank).map_err(|e| (format!("error: {e}"), 1))?;
        }
    }

    let mut previous: Option<String> = None;
    loop {
        let started = Instant::now();
        let rec = execute_once(&cfg);
        let selected = select_output(&rec, cfg.output).to_string();
        let changed = previous.as_ref().map(|p| p != &selected).unwrap_or(true);
        if changed {
            print_record(&cfg, &rec, &selected).map_err(|e| (format!("error: {e}"), 1))?;
            if let Some(path) = &cfg.logfile {
                append_log(path, &rec).map_err(|e| (format!("error: {e}"), 1))?;
            }
            if previous.is_some() {
                if let Some(after) = &cfg.after {
                    run_after(after, &rec);
                }
            }
        }
        previous = Some(selected);
        let interval = Duration::from_secs_f64(cfg.interval.max(0.001));
        if cfg.precise {
            if let Some(left) = interval.checked_sub(started.elapsed()) { thread::sleep(left); }
        } else {
            thread::sleep(interval);
        }
    }
}

fn merged_args() -> Vec<String> {
    let mut out = Vec::new();
    if let Ok(defaults) = env::var("HWATCH") {
        if let Some(parts) = shlex::split(&defaults) { out.extend(parts); }
    }
    out.extend(env::args().skip(1));
    out
}

fn parse_args(args: &[String]) -> Result<Config, (String, i32)> {
    let mut cfg = Config { batch: false, exec: false, reverse: false, line_number: false, interval: 2.0, precise: false, shell: "sh -c".into(), logfile: None, after: None, output: OutputMode::Output, command: Vec::new() };
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if a == "--" { cfg.command.extend_from_slice(&args[i+1..]); break; }
        if a == "-h" || a == "--help" { print!("{HELP}"); return Err((String::new(), 0)); }
        if a == "-V" || a == "--version" { println!("hwatch {VERSION}"); return Err((String::new(), 0)); }
        match a.as_str() {
            "-b" | "--batch" => cfg.batch = true,
            "-B" | "--beep" | "--border" | "--with-scrollbar" | "--mouse" | "-c" | "--color" | "-C" | "--compress" | "-t" | "--no-title" | "--enable-summary-char" | "--no-help-banner" | "--no-summary" | "-O" | "--diff-output-only" => {},
            "-r" | "--reverse" => cfg.reverse = true,
            "-N" | "--line-number" => cfg.line_number = true,
            "-x" | "--exec" => cfg.exec = true,
            "--precise" => cfg.precise = true,
            "-n" | "--interval" => { i += 1; let v = need(args, i, a)?; cfg.interval = parse_float(v, "--interval <interval>")?; },
            "-L" | "--limit" | "--tab-size" | "-K" | "--keymap" => { i += 1; let _ = need(args, i, a)?; },
            "-A" | "--aftercommand" => { i += 1; cfg.after = Some(need(args, i, a)?.to_string()); },
            "-s" | "--shell" => { i += 1; cfg.shell = need(args, i, a)?.to_string(); },
            "-d" | "--differences" => {
                let mut val = "watch".to_string();
                if i + 1 < args.len() && !args[i+1].starts_with('-') { i += 1; val = args[i].clone(); }
                if !["none", "watch", "line", "word"].contains(&val.as_str()) {
                    return Err((format!("error: invalid value '{val}' for '--differences [<differences>]'\n  [possible values: none, watch, line, word]\n\nFor more information, try '--help'."), 2));
                }
            },
            "-o" | "--output" => {
                let mut val = "output".to_string();
                if i + 1 < args.len() && !args[i+1].starts_with('-') { i += 1; val = args[i].clone(); }
                cfg.output = match val.as_str() {
                    "output" => OutputMode::Output,
                    "stdout" => OutputMode::Stdout,
                    "stderr" => OutputMode::Stderr,
                    _ => return Err((format!("error: invalid value '{val}' for '--output [<output>]'\n  [possible values: output, stdout, stderr]\n\nFor more information, try '--help'."), 2)),
                };
            },
            "-l" | "--logfile" => {
                if i + 1 < args.len() && !args[i+1].starts_with('-') { i += 1; cfg.logfile = Some(args[i].clone()); }
                else { cfg.logfile = Some("hwatch.log".into()); }
            },
            _ => { cfg.command.extend_from_slice(&args[i..]); break; }
        }
        i += 1;
    }
    Ok(cfg)
}

fn need<'a>(args: &'a [String], i: usize, opt: &str) -> Result<&'a str, (String, i32)> {
    args.get(i).map(|s| s.as_str()).ok_or_else(|| (format!("error: a value is required for '{opt}' but none was supplied\n\nFor more information, try '--help'."), 2))
}

fn parse_float(v: &str, name: &str) -> Result<f64, (String, i32)> {
    let normalized = v.replace(',', ".");
    normalized.parse::<f64>().map_err(|e| (format!("error: invalid value '{v}' for '{name}': {e}\n\nFor more information, try '--help'."), 2))
}

fn execute_once(cfg: &Config) -> Record {
    let command_string = cfg.command.join(" ");
    let timestamp = Local::now().format("%Y-%m-%d %H:%M:%S%.3f").to_string();
    let result = if cfg.exec { exec_direct(&cfg.command) } else { exec_shell(&cfg.shell, &command_string) };
    match result {
        Ok((status, stdout, stderr)) => Record { timestamp, command: command_string, status, output: format!("{}{}", stderr, stdout), stdout, stderr },
        Err(e) => Record { timestamp, command: command_string, status: false, output: format!("{e}\n"), stdout: String::new(), stderr: format!("{e}\n") },
    }
}

fn exec_direct(args: &[String]) -> io::Result<(bool, String, String)> {
    let mut c = Command::new(&args[0]);
    c.args(&args[1..]);
    let out = c.output()?;
    Ok((out.status.success(), String::from_utf8_lossy(&out.stdout).into_owned(), String::from_utf8_lossy(&out.stderr).into_owned()))
}

fn exec_shell(shell: &str, cmd: &str) -> io::Result<(bool, String, String)> {
    let mut parts = shlex::split(shell).unwrap_or_else(|| vec!["sh".into(), "-c".into()]);
    if parts.is_empty() { parts = vec!["sh".into(), "-c".into()]; }
    let program = parts.remove(0);
    let mut args = Vec::new();
    let mut inserted = false;
    for p in parts {
        if p.contains("{COMMAND}") { args.push(p.replace("{COMMAND}", cmd)); inserted = true; }
        else { args.push(p); }
    }
    if !inserted { args.push(cmd.to_string()); }
    let out = Command::new(program).args(args).output()?;
    Ok((out.status.success(), String::from_utf8_lossy(&out.stdout).into_owned(), String::from_utf8_lossy(&out.stderr).into_owned()))
}

fn select_output(rec: &Record, mode: OutputMode) -> &str {
    match mode { OutputMode::Output => &rec.output, OutputMode::Stdout => &rec.stdout, OutputMode::Stderr => &rec.stderr }
}

fn print_record(cfg: &Config, rec: &Record, selected: &str) -> io::Result<()> {
    let mut out = io::stdout();
    writeln!(out, "\x1b[38;5;240m=====[{}]=========================\x1b[0m", rec.timestamp)?;
    let mut lines: Vec<&str> = selected.split_inclusive('\n').collect();
    if !selected.ends_with('\n') && !selected.is_empty() && lines.is_empty() { lines.push(selected); }
    if cfg.reverse { lines.reverse(); }
    for (idx, line) in lines.iter().enumerate() {
        if cfg.line_number { write!(out, "{:>6}  ", idx + 1)?; }
        write!(out, "{line}")?;
    }
    if !selected.ends_with('\n') && !selected.is_empty() { writeln!(out)?; }
    writeln!(out)?;
    out.flush()
}

fn append_log(path: &str, rec: &Record) -> io::Result<()> {
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    serde_json::to_writer(&mut f, rec).map_err(io::Error::other)?;
    writeln!(f)
}

fn replay_log(path: &str) -> Result<(), (String, i32)> {
    let data = fs::read_to_string(path).map_err(|e| (format!("error: {e}"), 1))?;
    print!("{data}");
    Ok(())
}

fn run_after(after: &str, rec: &Record) {
    let data = serde_json::to_string(rec).unwrap_or_default();
    let _ = Command::new("sh")
        .arg("-c")
        .arg(after)
        .env("HWATCH_DATA", data)
        .stdin(Stdio::null())
        .status();
}
