use miniz_oxide::inflate::decompress_to_vec_zlib;
use std::env;
use std::fs;
use std::io::{self, Write};

const VERSION: &str = "1.3.2";

#[derive(Clone, Copy, Debug, Default)]
struct Pixel {
    r: u8,
    g: u8,
    b: u8,
    a: u8,
}

#[derive(Clone)]
struct Image {
    w: usize,
    h: usize,
    p: Vec<Pixel>,
}

#[derive(Clone, Copy)]
enum Scale {
    Resize,
    Fill,
    Fit,
}

struct Opts {
    dither: u8,
    go: bool,
    matte: Pixel,
    nobg: bool,
    scale: Scale,
    tc: usize,
    tr: usize,
    input: Option<String>,
}

fn logo() -> String {
    format!(
"   ___  _____  ____
  / _ \\/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau
 / ___// /_>  </ __/ -_) __/  ' \\ https://github.com/eliukblau/pixterm
/_/  /___/_/|_|\\__/\\__/_/ /_/_/_/                {VERSION}
"
    )
}

fn help() -> String {
    format!(
"{}
USAGE:

  executable [options] image/url

  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.
  Supported URL protocols: HTTP, HTTPS.

OPTIONS:

  -credits
    \tshow some love to contributors <3
  -d mode
    \tdithering mode:
    \t   0 - no dithering (default)
    \t   1 - with blocks
    \t   2 - with chars
  -go
    \toutput Go code to 'fmt.Print()' the image
  -m color
    \tmatte color for transparency or background
    \t(optional, hex format, default: 000000)
  -nobg
    \tdisable background color
    \t(optional, only in dithering mode, ignores matte color)
  -s method
    \tscale method:
    \t   0 - resize (default)
    \t   1 - fill
    \t   2 - fit
  -tc columns
    \tterminal columns (optional, >=2; when piping, default: 80)
  -tr rows
    \tterminal rows (optional, >=2; when piping, default: 24)
  -version
    \tshow PIXterm version
  -help
\tprints this message :D LOL
", logo())
}

fn credits() -> String {
    format!(
"{}
CONTRIBUTORS:

  > @disq - https://github.com/disq
      + Original code for image transparency support.

  > @timob - https://github.com/timob
      + Fix for ANSIpixel type: use 8bit color component for output.

  > @HongjiangHuang - https://github.com/HongjiangHuang
      + Original code for image download support.

  > @brutestack - https://github.com/brutestack
      + Color support for Windows (Command Prompt & PowerShell).
      + Original code for disable background color in dithering mode.
      + Original code for output Go code to 'fmt.Print()' the image.

  > @diamondburned - https://github.com/diamondburned
      + NewFromImage() & NewScaledFromImage() for ANSImage API.

  > @MichaelMure - https://github.com/MichaelMure
      + More conventional 'go.mod' file at repository.

  > @Calinou - https://github.com/Calinou
      + Use HTTPS URLs everywhere.
      + Other awesome contributions.

  > @danirod - https://github.com/danirod
  > @Xpktro - https://github.com/Xpktro
      + Moral support.
", logo())
}

fn pixerr(msg: &str) -> ! {
    eprintln!("[PIXTERM ERROR] {}", msg);
    std::process::exit(1);
}

fn parse_hex(s: &str) -> Option<Pixel> {
    let t = s.strip_prefix('#').unwrap_or(s);
    if t.len() != 6 || !t.bytes().all(|b| b.is_ascii_hexdigit()) {
        return None;
    }
    let r = u8::from_str_radix(&t[0..2], 16).ok()?;
    let g = u8::from_str_radix(&t[2..4], 16).ok()?;
    let b = u8::from_str_radix(&t[4..6], 16).ok()?;
    Some(Pixel { r, g, b, a: 255 })
}

fn parse_args() -> Result<Option<Opts>, ()> {
    let mut opts = Opts {
        dither: 0,
        go: false,
        matte: Pixel { r: 0, g: 0, b: 0, a: 255 },
        nobg: false,
        scale: Scale::Resize,
        tc: 80,
        tr: 24,
        input: None,
    };
    let mut it = env::args().skip(1).peekable();
    if it.peek().is_none() {
        print!("{}", help());
        return Ok(None);
    }
    while let Some(a) = it.next() {
        match a.as_str() {
            "-help" | "--help" => {
                print!("{}", help());
                return Ok(None);
            }
            "-version" | "--version" => {
                println!("{VERSION}");
                return Ok(None);
            }
            "-credits" => {
                print!("{}", credits());
                return Ok(None);
            }
            "-go" => opts.go = true,
            "-nobg" => opts.nobg = true,
            "-d" => {
                let v = it.next().ok_or(())?;
                opts.dither = v.parse().map_err(|_| ())?;
                if opts.dither > 2 { return Err(()); }
            }
            "-s" => {
                let v: u8 = it.next().ok_or(())?.parse().map_err(|_| ())?;
                opts.scale = match v {
                    0 => Scale::Resize,
                    1 => Scale::Fill,
                    2 => Scale::Fit,
                    _ => return Err(()),
                };
            }
            "-m" => {
                let v = it.next().ok_or(())?;
                opts.matte = parse_hex(&v).unwrap_or_else(|| pixerr(&format!("matte color : {v} is not a hex-color")));
            }
            "-tc" => {
                opts.tc = it.next().ok_or(())?.parse().map_err(|_| ())?;
                if opts.tc < 2 { return Err(()); }
            }
            "-tr" => {
                opts.tr = it.next().ok_or(())?.parse().map_err(|_| ())?;
                if opts.tr < 2 { return Err(()); }
            }
            _ if a.starts_with('-') => return Err(()),
            _ => opts.input = Some(a),
        }
    }
    if opts.input.is_none() {
        print!("{}", help());
        return Ok(None);
    }
    Ok(Some(opts))
}

fn read_u16le(b: &[u8], o: usize) -> u16 { u16::from_le_bytes([b[o], b[o + 1]]) }
fn read_u32le(b: &[u8], o: usize) -> u32 { u32::from_le_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]) }
fn read_u32be(b: &[u8], o: usize) -> u32 { u32::from_be_bytes([b[o], b[o + 1], b[o + 2], b[o + 3]]) }

fn decode_bmp(data: &[u8]) -> Result<Image, String> {
    if data.len() < 54 || &data[0..2] != b"BM" { return Err("invalid BMP".into()); }
    let off = read_u32le(data, 10) as usize;
    let dib = read_u32le(data, 14) as usize;
    if dib < 40 || data.len() < 14 + dib { return Err("unsupported BMP".into()); }
    let w = read_u32le(data, 18) as i32;
    let h_raw = read_u32le(data, 22) as i32;
    let planes = read_u16le(data, 26);
    let bpp = read_u16le(data, 28);
    let comp = read_u32le(data, 30);
    if planes != 1 || comp != 0 || !(bpp == 24 || bpp == 32) || w <= 0 || h_raw == 0 {
        return Err("unsupported BMP".into());
    }
    let w = w as usize;
    let top_down = h_raw < 0;
    let h = h_raw.unsigned_abs() as usize;
    let stride = ((w * bpp as usize + 31) / 32) * 4;
    if data.len() < off + stride * h { return Err("truncated BMP".into()); }
    let mut p = vec![Pixel::default(); w * h];
    for y in 0..h {
        let sy = if top_down { y } else { h - 1 - y };
        let row = off + sy * stride;
        for x in 0..w {
            let i = row + x * (bpp as usize / 8);
            p[y * w + x] = Pixel { b: data[i], g: data[i + 1], r: data[i + 2], a: if bpp == 32 { data[i + 3] } else { 255 } };
        }
    }
    Ok(Image { w, h, p })
}

fn paeth(a: u8, b: u8, c: u8) -> u8 {
    let (a, b, c) = (a as i32, b as i32, c as i32);
    let p = a + b - c;
    let pa = (p - a).abs();
    let pb = (p - b).abs();
    let pc = (p - c).abs();
    if pa <= pb && pa <= pc { a as u8 } else if pb <= pc { b as u8 } else { c as u8 }
}

fn decode_png(data: &[u8]) -> Result<Image, String> {
    if data.len() < 33 || &data[0..8] != b"\x89PNG\r\n\x1a\n" { return Err("invalid PNG".into()); }
    let mut pos = 8;
    let mut w = 0usize;
    let mut h = 0usize;
    let mut bit = 0u8;
    let mut color = 0u8;
    let mut palette: Vec<Pixel> = Vec::new();
    let mut trns: Vec<u8> = Vec::new();
    let mut idat = Vec::new();
    while pos + 12 <= data.len() {
        let len = read_u32be(data, pos) as usize;
        pos += 4;
        if pos + 4 + len + 4 > data.len() { return Err("truncated PNG".into()); }
        let typ = &data[pos..pos + 4];
        pos += 4;
        let chunk = &data[pos..pos + len];
        pos += len + 4;
        match typ {
            b"IHDR" => {
                w = read_u32be(chunk, 0) as usize;
                h = read_u32be(chunk, 4) as usize;
                bit = chunk[8];
                color = chunk[9];
                if chunk[10] != 0 || chunk[11] != 0 || chunk[12] != 0 { return Err("unsupported PNG".into()); }
            }
            b"PLTE" => {
                palette.clear();
                for c in chunk.chunks_exact(3) {
                    palette.push(Pixel { r: c[0], g: c[1], b: c[2], a: 255 });
                }
            }
            b"tRNS" => trns = chunk.to_vec(),
            b"IDAT" => idat.extend_from_slice(chunk),
            b"IEND" => break,
            _ => {}
        }
    }
    if w == 0 || h == 0 || bit != 8 { return Err("unsupported PNG".into()); }
    for (i, a) in trns.iter().copied().enumerate() {
        if i < palette.len() { palette[i].a = a; }
    }
    let (channels, bpp) = match color {
        0 => (1usize, 1usize),
        2 => (3, 3),
        3 => (1, 1),
        4 => (2, 2),
        6 => (4, 4),
        _ => return Err("unsupported PNG".into()),
    };
    let raw = decompress_to_vec_zlib(&idat).map_err(|_| "PNG inflate failed")?;
    let row_len = w * channels;
    if raw.len() < (row_len + 1) * h { return Err("truncated PNG data".into()); }
    let mut recon = vec![0u8; row_len * h];
    let mut rp = 0;
    for y in 0..h {
        let filter = raw[rp];
        rp += 1;
        for x in 0..row_len {
            let val = raw[rp + x];
            let left = if x >= bpp { recon[y * row_len + x - bpp] } else { 0 };
            let up = if y > 0 { recon[(y - 1) * row_len + x] } else { 0 };
            let ul = if y > 0 && x >= bpp { recon[(y - 1) * row_len + x - bpp] } else { 0 };
            recon[y * row_len + x] = match filter {
                0 => val,
                1 => val.wrapping_add(left),
                2 => val.wrapping_add(up),
                3 => val.wrapping_add(((left as u16 + up as u16) / 2) as u8),
                4 => val.wrapping_add(paeth(left, up, ul)),
                _ => return Err("bad PNG filter".into()),
            };
        }
        rp += row_len;
    }
    let mut p = Vec::with_capacity(w * h);
    for px in recon.chunks_exact(channels) {
        let out = match color {
            0 => Pixel { r: px[0], g: px[0], b: px[0], a: 255 },
            2 => Pixel { r: px[0], g: px[1], b: px[2], a: 255 },
            3 => *palette.get(px[0] as usize).ok_or("bad PNG palette")?,
            4 => Pixel { r: px[0], g: px[0], b: px[0], a: px[1] },
            6 => Pixel { r: px[0], g: px[1], b: px[2], a: px[3] },
            _ => unreachable!(),
        };
        p.push(out);
    }
    Ok(Image { w, h, p })
}

fn load_image(path: &str) -> Result<Image, String> {
    if path.starts_with("http://") || path.starts_with("https://") {
        return Err("URL fetching is not available in this build".into());
    }
    let data = fs::read(path).map_err(|e| e.to_string())?;
    if data.starts_with(b"BM") {
        decode_bmp(&data)
    } else if data.starts_with(b"\x89PNG\r\n\x1a\n") {
        decode_png(&data)
    } else {
        Err("unsupported image format".into())
    }
}

fn blend_matte(mut p: Pixel, matte: Pixel) -> Pixel {
    if p.a == 255 { return p; }
    let a = p.a as u16;
    p.r = ((p.r as u16 * a + matte.r as u16 * (255 - a)) / 255) as u8;
    p.g = ((p.g as u16 * a + matte.g as u16 * (255 - a)) / 255) as u8;
    p.b = ((p.b as u16 * a + matte.b as u16 * (255 - a)) / 255) as u8;
    p.a = 255;
    p
}

fn sample(img: &Image, x: f32, y: f32, matte: Pixel) -> Pixel {
    let x = x.clamp(0.0, (img.w - 1) as f32);
    let y = y.clamp(0.0, (img.h - 1) as f32);
    let x0 = x.floor() as usize;
    let y0 = y.floor() as usize;
    let x1 = (x0 + 1).min(img.w - 1);
    let y1 = (y0 + 1).min(img.h - 1);
    let tx = x - x0 as f32;
    let ty = y - y0 as f32;
    let c00 = blend_matte(img.p[y0 * img.w + x0], matte);
    let c10 = blend_matte(img.p[y0 * img.w + x1], matte);
    let c01 = blend_matte(img.p[y1 * img.w + x0], matte);
    let c11 = blend_matte(img.p[y1 * img.w + x1], matte);
    let interp = |a: u8, b: u8, c: u8, d: u8| -> u8 {
        let top = a as f32 * (1.0 - tx) + b as f32 * tx;
        let bot = c as f32 * (1.0 - tx) + d as f32 * tx;
        (top * (1.0 - ty) + bot * ty).round().clamp(0.0, 255.0) as u8
    };
    Pixel { r: interp(c00.r, c10.r, c01.r, c11.r), g: interp(c00.g, c10.g, c01.g, c11.g), b: interp(c00.b, c10.b, c01.b, c11.b), a: 255 }
}

fn resize(img: &Image, out_w: usize, out_h: usize, opts: &Opts) -> Image {
    let mut out = vec![opts.matte; out_w * out_h];
    let (scale, dx, dy) = match opts.scale {
        Scale::Resize => (0.0, 0isize, 0isize),
        Scale::Fill => {
            let s = (out_w as f32 / img.w as f32).max(out_h as f32 / img.h as f32);
            let sw = (img.w as f32 * s).round() as isize;
            let sh = (img.h as f32 * s).round() as isize;
            (s, (out_w as isize - sw) / 2, (out_h as isize - sh) / 2)
        }
        Scale::Fit => {
            let s = (out_w as f32 / img.w as f32).min(out_h as f32 / img.h as f32);
            let sw = (img.w as f32 * s).round() as isize;
            let sh = (img.h as f32 * s).round() as isize;
            (s, (out_w as isize - sw) / 2, (out_h as isize - sh) / 2)
        }
    };
    for y in 0..out_h {
        for x in 0..out_w {
            let (sx, sy, inside) = if matches!(opts.scale, Scale::Resize) {
                (
                    (x as f32 + 0.5) * img.w as f32 / out_w as f32 - 0.5,
                    (y as f32 + 0.5) * img.h as f32 / out_h as f32 - 0.5,
                    true,
                )
            } else {
                let sx = (x as isize - dx) as f32 / scale;
                let sy = (y as isize - dy) as f32 / scale;
                (sx, sy, sx >= 0.0 && sy >= 0.0 && sx < img.w as f32 && sy < img.h as f32)
            };
            if inside {
                out[y * out_w + x] = sample(img, sx, sy, opts.matte);
            }
        }
    }
    Image { w: out_w, h: out_h, p: out }
}

fn esc_fg(p: Pixel) -> String { format!("\x1b[38;2;{};{};{}m", p.r, p.g, p.b) }
fn esc_bg(p: Pixel) -> String { format!("\x1b[48;2;{};{};{}m", p.r, p.g, p.b) }

fn brightness(p: Pixel) -> f32 {
    (0.299 * p.r as f32 + 0.587 * p.g as f32 + 0.114 * p.b as f32) / 255.0
}

fn render(img: &Image, opts: &Opts) -> String {
    let mut s = String::new();
    for y in 0..opts.tr {
        for x in 0..opts.tc {
            let top = img.p[(y * 2) * img.w + x];
            let bot = img.p[((y * 2 + 1).min(img.h - 1)) * img.w + x];
            if opts.dither == 0 {
                s.push_str(&esc_bg(top));
                s.push_str(&esc_fg(bot));
                s.push('▄');
            } else {
                let avg = Pixel {
                    r: ((top.r as u16 + bot.r as u16) / 2) as u8,
                    g: ((top.g as u16 + bot.g as u16) / 2) as u8,
                    b: ((top.b as u16 + bot.b as u16) / 2) as u8,
                    a: 255,
                };
                if !opts.nobg { s.push_str(&esc_bg(opts.matte)); }
                s.push_str(&esc_fg(avg));
                let chars = if opts.dither == 1 { [" ", "░", "▒", "▓", "█"] } else { [" ", ".", "X", "&", "#"] };
                let idx = (brightness(avg) * 4.0).round().clamp(0.0, 4.0) as usize;
                s.push_str(chars[idx]);
            }
        }
        s.push_str("\x1b[0m\n");
    }
    s
}

fn go_escape(line: &str) -> String {
    let mut out = String::new();
    for ch in line.chars() {
        match ch {
            '\x1b' => out.push_str("\\033"),
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            _ => out.push(ch),
        }
    }
    out
}

fn main() {
    let opts = match parse_args() {
        Ok(Some(o)) => o,
        Ok(None) => return,
        Err(()) => {
            print!("{}", help());
            return;
        }
    };
    let img = load_image(opts.input.as_ref().unwrap()).unwrap_or_else(|e| pixerr(&e));
    let scaled = resize(&img, opts.tc, opts.tr * 2, &opts);
    let out = render(&scaled, &opts);
    if opts.go {
        for line in out.split_inclusive('\n') {
            println!("fmt.Print(\"{}\")", go_escape(line));
        }
    } else {
        let _ = io::stdout().write_all(out.as_bytes());
    }
}
