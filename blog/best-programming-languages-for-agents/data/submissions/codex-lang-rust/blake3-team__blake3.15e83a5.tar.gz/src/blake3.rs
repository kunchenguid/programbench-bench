const IV: [u32; 8] = [
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
];
const MSG_PERMUTATION: [usize; 16] = [2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8];
const CHUNK_LEN: usize = 1024;
const BLOCK_LEN: usize = 64;
const CHUNK_START: u32 = 1;
const CHUNK_END: u32 = 2;
const PARENT: u32 = 4;
const ROOT: u32 = 8;
pub const KEYED_HASH: u32 = 16;
pub const DERIVE_KEY_CONTEXT: u32 = 32;
pub const DERIVE_KEY_MATERIAL: u32 = 64;

#[derive(Clone)]
pub struct Output {
    input_cv: [u32; 8],
    block: [u8; 64],
    counter: u64,
    block_len: u32,
    flags: u32,
}

fn g(v: &mut [u32; 16], a: usize, b: usize, c: usize, d: usize, mx: u32, my: u32) {
    v[a] = v[a].wrapping_add(v[b]).wrapping_add(mx);
    v[d] = (v[d] ^ v[a]).rotate_right(16);
    v[c] = v[c].wrapping_add(v[d]);
    v[b] = (v[b] ^ v[c]).rotate_right(12);
    v[a] = v[a].wrapping_add(v[b]).wrapping_add(my);
    v[d] = (v[d] ^ v[a]).rotate_right(8);
    v[c] = v[c].wrapping_add(v[d]);
    v[b] = (v[b] ^ v[c]).rotate_right(7);
}

fn round(v: &mut [u32; 16], m: &[u32; 16]) {
    g(v, 0, 4, 8, 12, m[0], m[1]);
    g(v, 1, 5, 9, 13, m[2], m[3]);
    g(v, 2, 6, 10, 14, m[4], m[5]);
    g(v, 3, 7, 11, 15, m[6], m[7]);
    g(v, 0, 5, 10, 15, m[8], m[9]);
    g(v, 1, 6, 11, 12, m[10], m[11]);
    g(v, 2, 7, 8, 13, m[12], m[13]);
    g(v, 3, 4, 9, 14, m[14], m[15]);
}

fn permute(m: [u32; 16]) -> [u32; 16] {
    let mut out = [0u32; 16];
    for i in 0..16 {
        out[i] = m[MSG_PERMUTATION[i]];
    }
    out
}

fn words_from_block(block: &[u8; 64]) -> [u32; 16] {
    let mut words = [0u32; 16];
    for (i, chunk) in block.chunks_exact(4).enumerate() {
        words[i] = u32::from_le_bytes(chunk.try_into().unwrap());
    }
    words
}

fn words_from_key(key: &[u8; 32]) -> [u32; 8] {
    let mut words = [0u32; 8];
    for (i, chunk) in key.chunks_exact(4).enumerate() {
        words[i] = u32::from_le_bytes(chunk.try_into().unwrap());
    }
    words
}

fn compress(cv: [u32; 8], block_words: [u32; 16], counter: u64, block_len: u32, flags: u32) -> [u32; 16] {
    let mut v = [
        cv[0], cv[1], cv[2], cv[3], cv[4], cv[5], cv[6], cv[7],
        IV[0], IV[1], IV[2], IV[3],
        counter as u32, (counter >> 32) as u32, block_len, flags,
    ];
    let mut m = block_words;
    for _ in 0..7 {
        round(&mut v, &m);
        m = permute(m);
    }
    [
        v[0] ^ v[8], v[1] ^ v[9], v[2] ^ v[10], v[3] ^ v[11],
        v[4] ^ v[12], v[5] ^ v[13], v[6] ^ v[14], v[7] ^ v[15],
        v[8] ^ cv[0], v[9] ^ cv[1], v[10] ^ cv[2], v[11] ^ cv[3],
        v[12] ^ cv[4], v[13] ^ cv[5], v[14] ^ cv[6], v[15] ^ cv[7],
    ]
}

fn first8(words: [u32; 16]) -> [u32; 8] {
    words[..8].try_into().unwrap()
}

impl Output {
    fn chaining_value(&self) -> [u32; 8] {
        first8(compress(
            self.input_cv,
            words_from_block(&self.block),
            self.counter,
            self.block_len,
            self.flags,
        ))
    }

    pub fn fill(&self, seek: u64, out: &mut [u8]) {
        let mut written = 0usize;
        let mut block_counter = seek / 64;
        let mut offset = (seek % 64) as usize;
        while written < out.len() {
            let words = compress(
                self.input_cv,
                words_from_block(&self.block),
                block_counter,
                self.block_len,
                self.flags | ROOT,
            );
            let mut block_bytes = [0u8; 64];
            for (i, word) in words.iter().enumerate() {
                block_bytes[i * 4..i * 4 + 4].copy_from_slice(&word.to_le_bytes());
            }
            let take = (64 - offset).min(out.len() - written);
            out[written..written + take].copy_from_slice(&block_bytes[offset..offset + take]);
            written += take;
            block_counter += 1;
            offset = 0;
        }
    }
}

fn chunk_output(chunk: &[u8], chunk_counter: u64, key: [u32; 8], flags: u32) -> Output {
    let mut cv = key;
    let mut pos = 0usize;
    loop {
        let remaining = chunk.len() - pos;
        let take = remaining.min(BLOCK_LEN);
        let mut block = [0u8; 64];
        block[..take].copy_from_slice(&chunk[pos..pos + take]);
        let mut block_flags = flags;
        if pos == 0 {
            block_flags |= CHUNK_START;
        }
        if pos + take == chunk.len() {
            block_flags |= CHUNK_END;
            return Output {
                input_cv: cv,
                block,
                counter: chunk_counter,
                block_len: take as u32,
                flags: block_flags,
            };
        }
        cv = first8(compress(cv, words_from_block(&block), chunk_counter, take as u32, block_flags));
        pos += take;
    }
}

fn parent_output(left: [u32; 8], right: [u32; 8], key: [u32; 8], flags: u32) -> Output {
    let mut block = [0u8; 64];
    for (i, word) in left.iter().chain(right.iter()).enumerate() {
        block[i * 4..i * 4 + 4].copy_from_slice(&word.to_le_bytes());
    }
    Output { input_cv: key, block, counter: 0, block_len: 64, flags: flags | PARENT }
}

fn largest_power_of_two_less_than(n: usize) -> usize {
    1usize << (usize::BITS - 1 - (n - 1).leading_zeros())
}

fn subtree_output(input: &[u8], chunk_offset: u64, key: [u32; 8], flags: u32) -> Output {
    if input.len() <= CHUNK_LEN {
        return chunk_output(input, chunk_offset, key, flags);
    }
    let chunks = (input.len() + CHUNK_LEN - 1) / CHUNK_LEN;
    let left_chunks = largest_power_of_two_less_than(chunks);
    let split = left_chunks * CHUNK_LEN;
    let left_cv = subtree_output(&input[..split], chunk_offset, key, flags).chaining_value();
    let right_cv = subtree_output(&input[split..], chunk_offset + left_chunks as u64, key, flags).chaining_value();
    parent_output(left_cv, right_cv, key, flags)
}

pub fn hash_xof(input: &[u8], key_words: [u32; 8], flags: u32, seek: u64, len: usize) -> Vec<u8> {
    let output = subtree_output(input, 0, key_words, flags);
    let mut out = vec![0u8; len];
    output.fill(seek, &mut out);
    out
}

pub fn default_key() -> [u32; 8] {
    IV
}

pub fn keyed_key(key: &[u8; 32]) -> [u32; 8] {
    words_from_key(key)
}

pub fn derive_context_key(context: &str) -> [u8; 32] {
    let context_key = hash_xof(context.as_bytes(), IV, DERIVE_KEY_CONTEXT, 0, 32);
    context_key.try_into().unwrap()
}
