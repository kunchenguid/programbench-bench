mod blake3;

use std::fs::File;
use std::io::{self, Read, Write};
use std::path::PathBuf;

#[derive(Debug)]
struct Args {
    keyed: bool,
    derive_key: Option<String>,
    length: usize,
    seek: u64,
    _num_threads: Option<usize>,
    _no_mmap: bool,
    no_names: bool,
    raw: bool,
    tag: bool,
    check: bool,
    quiet: bool,
    files: Vec<PathBuf>,
}

impl Default for Args {
    fn default() -> Self {
        Self {
            keyed: false,
            derive_key: None,
            length: 32,
            seek: 0,
            _num_threads: None,
            _no_mmap: false,
            no_names: false,
            raw: false,
            tag: false,
            check: false,
            quiet: false,
            files: Vec::new(),
        }
    }
}

const SHORT_HELP: &str = "Usage: executable [OPTIONS] [FILE]...\n\nArguments:\n  [FILE]...  Files to hash, or checkfiles to check\n\nOptions:\n      --keyed                 Use the keyed mode, reading the 32-byte key from stdin\n      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string\n  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]\n      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]\n      --num-threads <NUM>     The maximum number of threads to use\n      --no-mmap               Disable memory mapping\n      --no-names              Omit filenames in the output\n      --raw                   Write raw output bytes to stdout, rather than hex\n      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them\n      --quiet                 Skip printing OK for each checked file\n  -h, --help                  Print help (see more with '--help')\n  -V, --version               Print version\n";

fn print_long_help() {
    println!("Usage: executable [OPTIONS] [FILE]...\n\nArguments:\n  [FILE]...\n          Files to hash, or checkfiles to check\n          \n          When no file is given, or when - is given, read standard input.\n\nOptions:\n      --keyed\n          Use the keyed mode, reading the 32-byte key from stdin\n\n      --derive-key <CONTEXT>\n          Use the key derivation mode, with the given context string\n          \n          Cannot be used with --keyed.\n\n  -l, --length <LEN>\n          The number of output bytes, before hex encoding\n          \n          [default: 32]\n\n      --seek <SEEK>\n          The starting output byte offset, before hex encoding\n          \n          [default: 0]\n\n      --num-threads <NUM>\n          The maximum number of threads to use\n          \n          By default, this is the number of logical cores. If this flag is omitted, or if its value\n          is 0, RAYON_NUM_THREADS is also respected.\n\n      --no-mmap\n          Disable memory mapping\n          \n          Currently this also disables multithreading.\n\n      --no-names\n          Omit filenames in the output\n\n      --raw\n          Write raw output bytes to stdout, rather than hex\n          \n          --no-names is implied. In this case, only a single input is allowed.\n\n      --tag\n          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n\n  -c, --check\n          Read BLAKE3 sums from the [FILE]s and check them\n\n      --quiet\n          Skip printing OK for each checked file\n          \n          Must be used with --check.\n\n  -h, --help\n          Print help (see a summary with '-h')\n\n  -V, --version\n          Print version");
}

fn need_value(args: &[String], i: &mut usize, flag: &str) -> Result<String, i32> {
    if let Some((_, value)) = args[*i].split_once('=') {
        return Ok(value.to_string());
    }
    *i += 1;
    if *i >= args.len() {
        eprintln!("error: a value is required for '{flag} <{}>' but none was supplied\n\nFor more information, try '--help'.", if flag == "--derive-key" { "CONTEXT" } else if flag == "--length" || flag == "-l" { "LEN" } else { "SEEK" });
        return Err(2);
    }
    Ok(args[*i].clone())
}

fn parse_args() -> Result<Args, i32> {
    let argv: Vec<String> = std::env::args().skip(1).collect();
    let mut out = Args::default();
    let mut i = 0usize;
    while i < argv.len() {
        let arg = &argv[i];
        match arg.as_str() {
            "-h" => {
                print!("{}", SHORT_HELP);
                return Err(0);
            }
            "--help" => {
                print_long_help();
                return Err(0);
            }
            "-V" | "--version" => {
                println!("b3sum 1.8.4");
                return Err(0);
            }
            "--keyed" => out.keyed = true,
            "--derive-key" => out.derive_key = Some(need_value(&argv, &mut i, "--derive-key")?),
            "-l" | "--length" => {
                let value = need_value(&argv, &mut i, arg)?;
                out.length = value.parse().map_err(|e| {
                    eprintln!("error: invalid value '{}' for '--length <LEN>': {e}\n\nFor more information, try '--help'.", value);
                    2
                })?;
            }
            "--seek" => {
                let value = need_value(&argv, &mut i, "--seek")?;
                out.seek = value.parse().map_err(|e| {
                    eprintln!("error: invalid value '{}' for '--seek <SEEK>': {e}\n\nFor more information, try '--help'.", value);
                    2
                })?;
            }
            "--num-threads" => {
                let value = need_value(&argv, &mut i, "--num-threads")?;
                out._num_threads = value.parse().ok();
            }
            "--no-mmap" => out._no_mmap = true,
            "--no-names" => out.no_names = true,
            "--raw" => out.raw = true,
            "--tag" => out.tag = true,
            "-c" | "--check" => out.check = true,
            "--quiet" => out.quiet = true,
            "--" => {
                out.files.extend(argv[i + 1..].iter().map(PathBuf::from));
                break;
            }
            s if s.starts_with("--derive-key=") => out.derive_key = Some(s["--derive-key=".len()..].to_string()),
            s if s.starts_with("--length=") => {
                let value = &s["--length=".len()..];
                out.length = value.parse().map_err(|e| {
                    eprintln!("error: invalid value '{}' for '--length <LEN>': {e}\n\nFor more information, try '--help'.", value);
                    2
                })?;
            }
            s if s.starts_with("--seek=") => {
                let value = &s["--seek=".len()..];
                out.seek = value.parse().map_err(|e| {
                    eprintln!("error: invalid value '{}' for '--seek <SEEK>': {e}\n\nFor more information, try '--help'.", value);
                    2
                })?;
            }
            s if s.starts_with("--num-threads=") => {
                out._num_threads = s["--num-threads=".len()..].parse().ok();
            }
            s if s.starts_with('-') && s.len() > 1 => {
                eprintln!("error: unexpected argument '{}' found\n\nUsage: executable [OPTIONS] [FILE]...\n\nFor more information, try '--help'.", s);
                return Err(2);
            }
            s => out.files.push(PathBuf::from(s)),
        }
        i += 1;
    }
    if out.keyed && out.derive_key.is_some() {
        eprintln!("error: the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'\n\nUsage: executable --keyed <FILE>...\n\nFor more information, try '--help'.");
        return Err(2);
    }
    if out.quiet && !out.check {
        eprintln!("error: the following required arguments were not provided:\n  --check\n\nUsage: executable --check --quiet [FILE]...\n\nFor more information, try '--help'.");
        return Err(2);
    }
    Ok(out)
}

fn read_input(path: Option<&PathBuf>) -> io::Result<Vec<u8>> {
    let mut input = Vec::new();
    match path {
        None => io::stdin().read_to_end(&mut input)?,
        Some(p) if p.as_os_str() == "-" => io::stdin().read_to_end(&mut input)?,
        Some(p) => File::open(p)?.read_to_end(&mut input)?,
    };
    Ok(input)
}

fn hex(bytes: &[u8]) -> String {
    const TABLE: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for &b in bytes {
        out.push(TABLE[(b >> 4) as usize] as char);
        out.push(TABLE[(b & 0xf) as usize] as char);
    }
    out
}

fn decode_hex(s: &str) -> Option<Vec<u8>> {
    if s.len() % 2 != 0 {
        return None;
    }
    let mut out = Vec::with_capacity(s.len() / 2);
    let b = s.as_bytes();
    for i in (0..b.len()).step_by(2) {
        let hi = (b[i] as char).to_digit(16)?;
        let lo = (b[i + 1] as char).to_digit(16)?;
        out.push(((hi << 4) | lo) as u8);
    }
    Some(out)
}

fn hash_bytes(args: &Args, data: &[u8], key_words: [u32; 8], flags: u32) -> Vec<u8> {
    blake3::hash_xof(data, key_words, flags, args.seek, args.length)
}

fn format_name(path: Option<&PathBuf>) -> String {
    path.map(|p| p.to_string_lossy().into_owned()).unwrap_or_else(|| "-".to_string())
}

fn escape_name(name: &str) -> (String, bool) {
    let needs_escape = name.contains('\\') || name.contains('\n');
    if !needs_escape {
        return (name.to_string(), false);
    }
    let mut out = String::new();
    for ch in name.chars() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            _ => out.push(ch),
        }
    }
    (out, true)
}

fn unescape_name(name: &str) -> String {
    let mut out = String::new();
    let mut chars = name.chars();
    while let Some(ch) = chars.next() {
        if ch == '\\' {
            match chars.next() {
                Some('n') => out.push('\n'),
                Some('\\') => out.push('\\'),
                Some(other) => {
                    out.push('\\');
                    out.push(other);
                }
                None => out.push('\\'),
            }
        } else {
            out.push(ch);
        }
    }
    out
}

fn run_hash(args: &Args) -> i32 {
    if args.raw && args.files.len() > 1 {
        eprintln!("Error: Only one filename can be provided when using --raw");
        return 1;
    }
    if args.keyed && args.files.is_empty() {
        eprintln!("error: the following required arguments were not provided:\n  <FILE>...\n\nUsage: executable --keyed <FILE>...\n\nFor more information, try '--help'.");
        return 2;
    }

    let (key_words, flags) = if args.keyed {
        let mut key = [0u8; 32];
        if let Err(e) = io::stdin().read_exact(&mut key) {
            eprintln!("b3sum: failed to read 32-byte key from stdin: {e}");
            return 1;
        }
        (blake3::keyed_key(&key), blake3::KEYED_HASH)
    } else if let Some(context) = &args.derive_key {
        (blake3::keyed_key(&blake3::derive_context_key(context)), blake3::DERIVE_KEY_MATERIAL)
    } else {
        (blake3::default_key(), 0)
    };

    let paths: Vec<Option<&PathBuf>> = if args.files.is_empty() {
        vec![None]
    } else {
        args.files.iter().map(Some).collect()
    };
    let mut status = 0;
    for path in paths {
        match read_input(path) {
            Ok(data) => {
                let digest = hash_bytes(args, &data, key_words, flags);
                if args.raw {
                    io::stdout().write_all(&digest).ok();
                } else if args.tag {
                    println!("BLAKE3 ({}) = {}", format_name(path), hex(&digest));
                } else if args.no_names {
                    println!("{}", hex(&digest));
                } else {
                    let (name, escaped) = escape_name(&format_name(path));
                    println!("{}{}  {}", if escaped { "\\" } else { "" }, hex(&digest), name);
                }
            }
            Err(e) => {
                eprintln!("b3sum: {}: {}", format_name(path), e);
                status = 1;
            }
        }
    }
    status
}

fn parse_check_line(line: &str) -> Result<(String, String), &'static str> {
    let (line, escaped) = if let Some(rest) = line.strip_prefix('\\') {
        (rest, true)
    } else {
        (line, false)
    };
    if let Some(rest) = line.strip_prefix("BLAKE3 (") {
        if let Some((name, hash)) = rest.split_once(") = ") {
            return Ok((hash.trim().to_string(), name.to_string()));
        }
    }
    let mut parts = line.splitn(2, "  ");
    let hash = parts.next().unwrap_or("");
    let name = parts.next().ok_or("Invalid line")?;
    let name = name.trim_start_matches('*');
    Ok((hash.to_string(), if escaped { unescape_name(name) } else { name.to_string() }))
}

fn run_check(args: &Args) -> i32 {
    let paths: Vec<Option<&PathBuf>> = if args.files.is_empty() {
        vec![None]
    } else {
        args.files.iter().map(Some).collect()
    };
    let mut mismatches = 0usize;
    let mut status = 0;
    for path in paths {
        let content = match read_input(path) {
            Ok(c) => c,
            Err(e) => {
                eprintln!("b3sum: {}: {}", format_name(path), e);
                status = 1;
                continue;
            }
        };
        for line in String::from_utf8_lossy(&content).lines() {
            if line.trim().is_empty() {
                continue;
            }
            let (expected_hex, name) = match parse_check_line(line) {
                Ok(x) => x,
                Err(_) => {
                    eprintln!("b3sum: Invalid line");
                    status = 1;
                    continue;
                }
            };
            let expected = match decode_hex(&expected_hex) {
                Some(x) if !x.is_empty() => x,
                _ => {
                    eprintln!("b3sum: Invalid hash length");
                    mismatches += 1;
                    status = 1;
                    continue;
                }
            };
            let data = match read_input(Some(&PathBuf::from(&name))) {
                Ok(d) => d,
                Err(e) => {
                    println!("{}: FAILED ({})", name, e);
                    mismatches += 1;
                    status = 1;
                    continue;
                }
            };
            let digest = blake3::hash_xof(&data, blake3::default_key(), 0, 0, expected.len());
            if digest == expected {
                if !args.quiet {
                    println!("{}: OK", name);
                }
            } else {
                println!("{}: FAILED", name);
                mismatches += 1;
                status = 1;
            }
        }
    }
    if mismatches > 0 {
        eprintln!("b3sum: WARNING: {} computed checksum{} did NOT match", mismatches, if mismatches == 1 { "" } else { "s" });
    }
    status
}

fn main() {
    let args = match parse_args() {
        Ok(args) => args,
        Err(code) => std::process::exit(code),
    };
    let code = if args.check { run_check(&args) } else { run_hash(&args) };
    std::process::exit(code);
}
