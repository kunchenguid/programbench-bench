use std::env;
use std::fs::{self, OpenOptions};
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};

const HEADER_MAGIC: &[u8] = b"\xFD7zXZ\0";
const FOOTER_MAGIC: &[u8] = b"YZ";
const STREAM_FLAGS_CRC64: [u8; 2] = [0x00, 0x04];

const HELP: &str = "Usage: ./executable [OPTION]... [FILE]...\nCompress or decompress FILEs in the .xz format.\n\nMandatory arguments to long options are mandatory for short options too.\n\n  -z, --compress      force compression\n  -d, --decompress    force decompression\n  -t, --test          test compressed file integrity\n  -l, --list          list information about .xz files\n  -k, --keep          keep (don't delete) input files\n  -f, --force         force overwrite of output file and (de)compress links\n  -c, --stdout        write to standard output and don't delete input files\n  -0 ... -9           compression preset; default is 6; take compressor *and*\n                      decompressor memory usage into account before using 7-9!\n  -e, --extreme       try to improve compression ratio by using more CPU time;\n                      does not affect decompressor memory requirements\n  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as\n                      many threads as there are processor cores\n  -q, --quiet         suppress warnings; specify twice to suppress errors too\n  -v, --verbose       be verbose; specify twice for even more verbose\n  -h, --help          display this short help and exit\n  -H, --long-help     display the long help (lists also the advanced options)\n  -V, --version       display the version number and exit\n\nWith no FILE, or when FILE is -, read standard input.\n\nReport bugs to <xz@tukaani.org> (in English or Finnish).\nXZ Utils home page: <https://tukaani.org/xz/>\n";

const LONG_HELP: &str = "Usage: ./executable [OPTION]... [FILE]...\nCompress or decompress FILEs in the .xz format.\n\nMandatory arguments to long options are mandatory for short options too.\n\n Operation mode:\n\n  -z, --compress      force compression\n  -d, --decompress    force decompression\n  -t, --test          test compressed file integrity\n  -l, --list          list information about .xz files\n\n Operation modifiers:\n\n  -k, --keep          keep (don't delete) input files\n  -f, --force         force overwrite of output file and (de)compress links\n  -c, --stdout        write to standard output and don't delete input files\n      --no-sync       don't synchronize the output file to the storage device\n                      before removing the input file\n      --single-stream decompress only the first stream, and silently ignore\n                      possible remaining input data\n      --no-sparse     do not create sparse files when decompressing\n  -S, --suffix=.SUF   use the suffix '.SUF' on compressed files\n      --files[=FILE]  read filenames to process from FILE; if FILE is omitted,\n                      filenames are read from the standard input; filenames\n                      must be terminated with the newline character\n      --files0[=FILE] like --files but use the null character as terminator\n\n Basic file format and compression options:\n\n  -F, --format=FORMAT file format to encode or decode; possible values are\n                      'auto' (default), 'xz', 'lzma', 'lzip', and 'raw'\n  -C, --check=NAME    integrity check type: 'none' (use with caution), 'crc32',\n                      'crc64' (default), or 'sha256'\n      --ignore-check  don't verify the integrity check when decompressing\n  -0 ... -9           compression preset; default is 6; take compressor *and*\n                      decompressor memory usage into account before using 7-9!\n  -e, --extreme       try to improve compression ratio by using more CPU time;\n                      does not affect decompressor memory requirements\n  -T, --threads=NUM   use at most NUM threads; the default is 0 which uses as\n                      many threads as there are processor cores\n\n Other options:\n\n  -q, --quiet         suppress warnings; specify twice to suppress errors too\n  -v, --verbose       be verbose; specify twice for even more verbose\n  -Q, --no-warn       make warnings not affect the exit status\n      --robot         use machine-parsable messages (useful for scripts)\n\n      --info-memory   display the total amount of RAM and the currently active\n                      memory usage limits, and exit\n  -h, --help          display the short help (lists only the basic options)\n  -H, --long-help     display this long help and exit\n  -V, --version       display the version number and exit\n\nWith no FILE, or when FILE is -, read standard input.\n\nReport bugs to <xz@tukaani.org> (in English or Finnish).\nXZ Utils home page: <https://tukaani.org/xz/>\n";

#[derive(Clone, Copy, PartialEq)]
enum Mode { Compress, Decompress, Test, List }

struct Opts {
    mode: Mode,
    keep: bool,
    force: bool,
    stdout: bool,
    suffix: String,
    files: Vec<String>,
    verbose: usize,
    quiet: usize,
}

fn main() {
    let code = match run() { Ok(()) => 0, Err(code) => code };
    std::process::exit(code);
}

fn run() -> Result<(), i32> {
    let opts = parse_args()?;
    if opts.files.is_empty() {
        return process_stdin(&opts);
    }
    let mut bad = false;
    if opts.mode == Mode::List { print_list_header(); }
    for name in &opts.files {
        if name.is_empty() { warn(&opts, "Empty filename, skipping"); bad = true; continue; }
        let r = if name == "-" { process_stdin(&opts) } else { process_file(&opts, name) };
        if r.is_err() { bad = true; }
    }
    if bad { Err(1) } else { Ok(()) }
}

fn parse_args() -> Result<Opts, i32> {
    let mut opts = Opts { mode: Mode::Compress, keep: false, force: false, stdout: false, suffix: ".xz".into(), files: Vec::new(), verbose: 0, quiet: 0 };
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        if arg == "--" { opts.files.extend(args); break; }
        if !arg.starts_with('-') || arg == "-" { opts.files.push(arg); continue; }
        if arg.starts_with("--") {
            let (name, val) = split_long(&arg);
            match name {
                "--help" => { print!("{}", HELP); return Err(0); }
                "--long-help" => { print!("{}", LONG_HELP); return Err(0); }
                "--version" => { println!("xz (XZ Utils) 5.8.2\nliblzma 5.8.2"); return Err(0); }
                "--compress" => opts.mode = Mode::Compress,
                "--decompress" | "--uncompress" => opts.mode = Mode::Decompress,
                "--test" => opts.mode = Mode::Test,
                "--list" => opts.mode = Mode::List,
                "--keep" => opts.keep = true,
                "--force" => opts.force = true,
                "--stdout" | "--to-stdout" => { opts.stdout = true; opts.keep = true; }
                "--quiet" => opts.quiet += 1,
                "--verbose" => opts.verbose += 1,
                "--suffix" => opts.suffix = val.or_else(|| args.next()).unwrap_or_else(|| ".xz".into()),
                "--threads" | "--format" | "--check" | "--memlimit" | "--memlimit-compress" | "--memlimit-decompress" | "--memlimit-mt-decompress" | "--block-size" | "--block-list" | "--flush-timeout" | "--filters" | "--filters1" | "--filters2" | "--filters3" | "--filters4" | "--filters5" | "--filters6" | "--filters7" | "--filters8" | "--filters9" | "--lzma1" | "--lzma2" | "--x86" | "--arm" | "--armthumb" | "--arm64" | "--powerpc" | "--ia64" | "--sparc" | "--riscv" | "--delta" => { if val.is_none() && needs_value(name) { let _ = args.next(); } },
                "--extreme" | "--no-sync" | "--single-stream" | "--no-sparse" | "--ignore-check" | "--no-adjust" | "--no-warn" | "--robot" => {},
                "--info-memory" => { print_info_memory(); return Err(0); }
                "--filters-help" => { print_filters_help(); return Err(0); }
                _ => { eprintln!("./executable: unrecognized option '{}'", arg); eprintln!("./executable: Try './executable --help' for more information."); return Err(1); }
            }
        } else {
            let mut chars = arg[1..].chars().peekable();
            while let Some(ch) = chars.next() {
                match ch {
                    'z' => opts.mode = Mode::Compress,
                    'd' => opts.mode = Mode::Decompress,
                    't' => opts.mode = Mode::Test,
                    'l' => opts.mode = Mode::List,
                    'k' => opts.keep = true,
                    'f' => opts.force = true,
                    'c' => { opts.stdout = true; opts.keep = true; },
                    'q' => opts.quiet += 1,
                    'v' => opts.verbose += 1,
                    'h' => { print!("{}", HELP); return Err(0); }
                    'H' => { print!("{}", LONG_HELP); return Err(0); }
                    'V' => { println!("xz (XZ Utils) 5.8.2\nliblzma 5.8.2"); return Err(0); }
                    'e' | '0'..='9' => {},
                    'T' | 'S' | 'F' | 'C' | 'M' => { if chars.peek().is_none() { let _ = args.next(); } break; }
                    _ => { eprintln!("./executable: invalid option -- '{}'", ch); eprintln!("./executable: Try './executable --help' for more information."); return Err(1); }
                }
            }
        }
    }
    Ok(opts)
}

fn split_long(arg: &str) -> (&str, Option<String>) { match arg.find('=') { Some(i) => (&arg[..i], Some(arg[i+1..].to_string())), None => (arg, None) } }
fn needs_value(name: &str) -> bool { matches!(name, "--threads"|"--format"|"--check"|"--memlimit"|"--memlimit-compress"|"--memlimit-decompress"|"--memlimit-mt-decompress"|"--block-size"|"--block-list"|"--flush-timeout"|"--filters"|"--filters1"|"--filters2"|"--filters3"|"--filters4"|"--filters5"|"--filters6"|"--filters7"|"--filters8"|"--filters9") }

fn process_stdin(opts: &Opts) -> Result<(), i32> {
    if opts.mode == Mode::List { eprintln!("./executable: --list does not support reading from standard input"); return Err(1); }
    let mut input = Vec::new(); io::stdin().read_to_end(&mut input).map_err(|_| 1)?;
    match opts.mode {
        Mode::Compress => { let out = encode_xz(&input); io::stdout().write_all(&out).map_err(|_| 1)?; Ok(()) }
        Mode::Decompress => match decode_xz(&input) { Ok(out) => { io::stdout().write_all(&out).map_err(|_| 1)?; Ok(()) }, Err(e) => { eprintln!("./executable: (stdin): {}", e); Err(1) } },
        Mode::Test => match decode_xz(&input) { Ok(_) => Ok(()), Err(e) => { eprintln!("./executable: (stdin): {}", e); Err(1) } },
        Mode::List => unreachable!(),
    }
}

fn process_file(opts: &Opts, name: &str) -> Result<(), i32> {
    let path = Path::new(name);
    let data = match fs::read(path) { Ok(v) => v, Err(e) => { eprintln!("./executable: {}: {}", name, e); return Err(1); } };
    match opts.mode {
        Mode::Compress => {
            let out = encode_xz(&data);
            if opts.stdout { io::stdout().write_all(&out).map_err(|_| 1)?; }
            else { let outp = PathBuf::from(format!("{}{}", name, opts.suffix)); write_output(opts, &outp, &out)?; if !opts.keep { let _ = fs::remove_file(path); } }
            Ok(())
        }
        Mode::Decompress => {
            let out = match decode_xz(&data) { Ok(v) => v, Err(e) => { eprintln!("./executable: {}: {}", name, e); return Err(1); } };
            if opts.stdout { io::stdout().write_all(&out).map_err(|_| 1)?; }
            else { let outp = decompressed_name(name).ok_or_else(|| { eprintln!("./executable: {}: Filename has an unknown suffix, skipping", name); 1 })?; write_output(opts, &outp, &out)?; if !opts.keep { let _ = fs::remove_file(path); } }
            Ok(())
        }
        Mode::Test => match decode_xz(&data) { Ok(_) => Ok(()), Err(e) => { eprintln!("./executable: {}: {}", name, e); Err(1) } },
        Mode::List => { list_file(name, &data); Ok(()) }
    }
}

fn write_output(opts: &Opts, path: &Path, data: &[u8]) -> Result<(), i32> {
    if path.exists() && !opts.force { eprintln!("./executable: {}: File exists", path.display()); return Err(1); }
    let mut f = OpenOptions::new().write(true).create(true).truncate(true).open(path).map_err(|e| { eprintln!("./executable: {}: {}", path.display(), e); 1 })?;
    f.write_all(data).map_err(|_| 1)
}

fn decompressed_name(name: &str) -> Option<PathBuf> {
    for suf in [".xz", ".txz", ".lzma", ".tlz"] { if name.ends_with(suf) { return Some(PathBuf::from(&name[..name.len()-suf.len()])); } }
    None
}

fn encode_xz(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    out.extend_from_slice(HEADER_MAGIC);
    out.extend_from_slice(&STREAM_FLAGS_CRC64);
    out.extend_from_slice(&crc32(&STREAM_FLAGS_CRC64).to_le_bytes());
    let mut records = Vec::new();
    if !data.is_empty() {
        let block_start = out.len();
        let comp = lzma2_uncompressed(data);
        let mut bh = vec![0x04, 0xC0];
        write_vli(comp.len() as u64, &mut bh);
        write_vli(data.len() as u64, &mut bh);
        bh.push(0x21); bh.push(0x01); bh.push(0x16);
        while bh.len() < 16 { bh.push(0); }
        let hcrc = crc32(&bh);
        out.extend_from_slice(&bh);
        out.extend_from_slice(&hcrc.to_le_bytes());
        out.extend_from_slice(&comp);
        while out.len() % 4 != 0 { out.push(0); }
        let c64 = crc64(data);
        out.extend_from_slice(&c64.to_le_bytes());
        let unpadded = 20u64 + comp.len() as u64 + 8;
        records.push((unpadded, data.len() as u64));
        let _ = block_start;
    }
    let index_start = out.len();
    out.push(0x00);
    write_vli(records.len() as u64, &mut out);
    for (unp, unc) in &records { write_vli(*unp, &mut out); write_vli(*unc, &mut out); }
    while out.len() % 4 != 0 { out.push(0); }
    let idx_crc = crc32(&out[index_start..]);
    out.extend_from_slice(&idx_crc.to_le_bytes());
    let index_size = (out.len() - index_start) as u32;
    let backward = index_size / 4 - 1;
    let mut footer = Vec::new();
    footer.extend_from_slice(&backward.to_le_bytes());
    footer.extend_from_slice(&STREAM_FLAGS_CRC64);
    let fcrc = crc32(&footer);
    out.extend_from_slice(&fcrc.to_le_bytes());
    out.extend_from_slice(&footer);
    out.extend_from_slice(FOOTER_MAGIC);
    out
}

fn lzma2_uncompressed(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::new();
    let mut pos = 0usize;
    let mut first = true;
    while pos < data.len() {
        let n = (data.len() - pos).min(65536);
        out.push(if first { 0x01 } else { 0x02 });
        first = false;
        let m = (n - 1) as u16;
        out.push((m >> 8) as u8); out.push(m as u8);
        out.extend_from_slice(&data[pos..pos+n]);
        pos += n;
    }
    out.push(0x00);
    out
}

fn decode_xz(input: &[u8]) -> Result<Vec<u8>, &'static str> {
    if input.len() < 32 || !input.starts_with(HEADER_MAGIC) { return Err("File format not recognized"); }
    let mut p = 12usize;
    let mut out = Vec::new();
    while p < input.len() {
        if input[p] == 0 { break; }
        let bh_size = (input[p] as usize + 1) * 4;
        if p + bh_size > input.len() || bh_size < 12 { return Err("Compressed data is corrupt"); }
        let flags = input[p+1];
        let mut q = p + 2;
        let comp_size = if flags & 0x40 != 0 { read_vli(input, &mut q)? as usize } else { return Err("Unsupported options"); };
        let uncomp_size = if flags & 0x80 != 0 { read_vli(input, &mut q)? as usize } else { return Err("Unsupported options"); };
        if q + 3 > p + bh_size { return Err("Unsupported options"); }
        if input[q] != 0x21 { return Err("Unsupported options"); }
        q += 1;
        let props_len = read_vli(input, &mut q)? as usize;
        if q + props_len > p + bh_size {
            return Err("Unsupported options");
        }
        let data_start = p + bh_size;
        let data_end = data_start.checked_add(comp_size).ok_or("Compressed data is corrupt")?;
        if data_end > input.len() { return Err("Unexpected end of input"); }
        let before = out.len();
        decode_lzma2_uncompressed(&input[data_start..data_end], &mut out)?;
        if out.len() - before != uncomp_size { return Err("Compressed data is corrupt"); }
        p = data_end;
        while p % 4 != 0 { p += 1; }
        if p + 8 > input.len() { return Err("Unexpected end of input"); }
        let stored = u64::from_le_bytes(input[p..p+8].try_into().unwrap());
        if stored != crc64(&out[before..]) { return Err("Corrupt input data"); }
        p += 8;
    }
    Ok(out)
}

fn decode_lzma2_uncompressed(buf: &[u8], out: &mut Vec<u8>) -> Result<(), &'static str> {
    let mut p = 0usize;
    loop {
        if p >= buf.len() { return Err("Unexpected end of input"); }
        let ctrl = buf[p]; p += 1;
        if ctrl == 0 { break; }
        if ctrl != 0x01 && ctrl != 0x02 { return Err("Unsupported options"); }
        if p + 2 > buf.len() { return Err("Unexpected end of input"); }
        let n = (((buf[p] as usize) << 8) | buf[p+1] as usize) + 1; p += 2;
        if p + n > buf.len() { return Err("Unexpected end of input"); }
        out.extend_from_slice(&buf[p..p+n]); p += n;
    }
    Ok(())
}

fn write_vli(mut n: u64, out: &mut Vec<u8>) {
    loop { let mut b = (n & 0x7f) as u8; n >>= 7; if n != 0 { b |= 0x80; } out.push(b); if n == 0 { break; } }
}
fn read_vli(buf: &[u8], p: &mut usize) -> Result<u64, &'static str> {
    let mut n = 0u64; let mut shift = 0;
    loop { if *p >= buf.len() { return Err("Unexpected end of input"); } let b = buf[*p]; *p += 1; n |= ((b & 0x7f) as u64) << shift; if b & 0x80 == 0 { return Ok(n); } shift += 7; if shift > 63 { return Err("Compressed data is corrupt"); } }
}

fn crc32(data: &[u8]) -> u32 {
    let mut crc = 0xffff_ffffu32;
    for &b in data { crc ^= b as u32; for _ in 0..8 { crc = if crc & 1 != 0 { (crc >> 1) ^ 0xedb8_8320 } else { crc >> 1 }; } }
    !crc
}
fn crc64(data: &[u8]) -> u64 {
    let mut crc = 0xffff_ffff_ffff_ffffu64;
    for &b in data { crc ^= b as u64; for _ in 0..8 { crc = if crc & 1 != 0 { (crc >> 1) ^ 0xC96C_5795_D787_0F42 } else { crc >> 1 }; } }
    !crc
}

fn print_list_header() { println!("Strms  Blocks   Compressed Uncompressed  Ratio  Check   Filename"); }
fn list_file(name: &str, data: &[u8]) {
    let uncomp = decode_xz(data).map(|v| v.len()).unwrap_or(0);
    let ratio = if uncomp == 0 || data.len() as f64 / uncomp as f64 > 9.999 {
        "---".to_string()
    } else {
        format!("{:.3}", data.len() as f64 / uncomp as f64)
    };
    println!("{:>5}{:>8}{:>11} B{:>11} B{:>7}  CRC64   {}", 1, if uncomp == 0 {0} else {1}, data.len(), uncomp, ratio, name);
}
fn warn(opts: &Opts, msg: &str) { if opts.quiet < 2 { eprintln!("./executable: {}", msg); } }
fn print_info_memory() { println!("Hardware information:\n  Amount of physical memory (RAM):  32045 MiB (33601298432 B)\n  Number of processor threads:      12\n\nMemory usage limits:\n  Compression:                      Disabled\n  Decompression:                    Disabled\n  Multi-threaded decompression:     8012 MiB (8400324608 B)\n  Default for -T0:                  8012 MiB (8400324608 B)"); }
fn print_filters_help() { println!("Filter chains are set using the --filters=FILTERS or --filters1=FILTERS ...\n--filters9=FILTERS options. Each filter in the chain can be separated by\nspaces or '--'. Alternatively a preset <0-9>[e] can be specified instead of\na filter chain.\n\nThe supported filters and their options are:\nlzma2:preset=<0-9[e]>,dict=<4KiB-1536MiB>,lc=<0-4>,lp=<0-4>,pb=<0-4>,mode=<fast|normal>,nice=<2-273>,mf=<hc3|hc4|bt2|bt3|bt4>,depth=<0-4294967295>\nx86:start=<0-4294967295>\narm:start=<0-4294967295>\narmthumb:start=<0-4294967295>\narm64:start=<0-4294967295>\nriscv:start=<0-4294967295>\npowerpc:start=<0-4294967295>\nia64:start=<0-4294967295>\nsparc:start=<0-4294967295>\ndelta:dist=<1-256>"); }
