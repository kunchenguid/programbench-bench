use std::collections::{BTreeMap, BTreeSet};
use std::env;
use std::fs;
use std::io::{self, Read};

#[derive(Default, Clone)]
struct Opts {
    digits: bool,
    non_digits: bool,
    spaces: bool,
    non_spaces: bool,
    words: bool,
    non_words: bool,
    escape: bool,
    surrogates: bool,
    reps: bool,
    min_reps: usize,
    min_sub_len: usize,
    no_start: bool,
    no_end: bool,
    verbose: bool,
    color: bool,
    ignore_case: bool,
    capture: bool,
    file: Option<String>,
    input: Vec<String>,
}

fn help() -> &'static str {
    "grex 1.4.6\n© 2019-today Peter M. Stahl <pemistahl@gmail.com>\nLicensed under the Apache License, Version 2.0\nDownloadable from https://crates.io/crates/grex\nSource code at https://github.com/pemistahl/grex\n\ngrex generates regular expressions from user-provided test cases.\n\nUsage: grex [OPTIONS] {INPUT...|--file <FILE>}\n\nInput:\n  [INPUT]...\n          One or more test cases separated by blank space\n          \n          Use a hyphen `-` to read test cases from standard input.\n          \n          Conflicts with --file.\n\n  -f, --file <FILE>\n          Reads test cases on separate lines from a file.\n          \n          Lines may be ended with either a newline `\\n` or a carriage return with a line feed\n          `\\r\\n`. The final line ending is optional.\n          \n          Use a hyphen `-` to read the filename from standard input.\n          \n          Conflicts with INPUT...\n\nDigit Options:\n  -d, --digits\n          Converts any Unicode decimal digit to \\d.\n\n  -D, --non-digits\n          Converts any character which is not a Unicode decimal digit to \\D.\n\nWhitespace Options:\n  -s, --spaces\n          Converts any Unicode whitespace character to \\s.\n\n  -S, --non-spaces\n          Converts any character which is not a Unicode whitespace character to \\S\n\nWord Options:\n  -w, --words\n          Converts any Unicode word character to \\w.\n\n  -W, --non-words\n          Converts any character which is not a Unicode word character to \\W.\n\nEscaping Options:\n  -e, --escape\n          Replaces all non-ASCII characters with unicode escape sequences\n\n      --with-surrogates\n          Converts astral code points to surrogate pairs if --escape is set\n\nRepetition Options:\n  -r, --repetitions\n          Detects repeated non-overlapping substrings and converts them to {min,max} quantifier\n          notation\n\n      --min-repetitions <QUANTITY>\n          Specifies the minimum quantity of substring repetitions to be converted if --repetitions\n          is set\n          \n          [default: 1]\n\n      --min-substring-length <LENGTH>\n          Specifies the minimum length a repeated substring must have in order to be converted if\n          --repetitions is set\n          \n          [default: 1]\n\nAnchor Options:\n      --no-start-anchor\n          Removes the caret anchor `^` from the resulting regular expression.\n\n      --no-end-anchor\n          Removes the dollar sign anchor `$` from the resulting regular expression.\n\n      --no-anchors\n          Removes the caret and dollar sign anchors from the resulting regular expression.\n\nDisplay Options:\n  -x, --verbose\n          Produces a nicer-looking regular expression in verbose mode\n\n  -c, --colorize\n          Provides syntax highlighting for the resulting regular expression\n\nMiscellaneous Options:\n  -i, --ignore-case\n          Performs case-insensitive matching, letters match both upper and lower case\n\n  -g, --capture-groups\n          Replaces non-capturing groups with capturing ones\n\n  -h, --help\n          Prints help information\n\n  -v, --version\n          Prints version information\n"
}

fn parse_args() -> Result<Option<Opts>, i32> {
    let mut o = Opts { min_reps: 1, min_sub_len: 1, ..Default::default() };
    let args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "--help" || a == "-h") { print!("{}", help()); return Ok(None); }
    if args.iter().any(|a| a == "--version" || a == "-v") { println!("grex 1.4.6"); return Ok(None); }
    let mut i = 0;
    while i < args.len() {
        let a = args[i].clone();
        if a == "--" { o.input.extend(args[i+1..].iter().cloned()); break; }
        if a == "-f" || a == "--file" {
            i += 1; if i >= args.len() { eprintln!("error: a value is required for '--file <FILE>' but none was supplied"); return Err(2); }
            o.file = Some(args[i].clone());
        } else if a == "--with-surrogates" { o.surrogates = true; }
        else if a == "--min-repetitions" { i += 1; o.min_reps = args.get(i).and_then(|s| s.parse().ok()).unwrap_or(1); }
        else if a == "--min-substring-length" { i += 1; o.min_sub_len = args.get(i).and_then(|s| s.parse().ok()).unwrap_or(1); }
        else if a == "--no-start-anchor" { o.no_start = true; }
        else if a == "--no-end-anchor" { o.no_end = true; }
        else if a == "--no-anchors" { o.no_start = true; o.no_end = true; }
        else if a.starts_with('-') && a.len() > 1 {
            for ch in a[1..].chars() {
                match ch {
                    'd' => o.digits = true, 'D' => o.non_digits = true,
                    's' => o.spaces = true, 'S' => o.non_spaces = true,
                    'w' => o.words = true, 'W' => o.non_words = true,
                    'e' => o.escape = true, 'r' => o.reps = true,
                    'x' => o.verbose = true, 'c' => o.color = true,
                    'i' => o.ignore_case = true, 'g' => o.capture = true,
                    _ => { o.input.push(a.clone()); break; }
                }
            }
        } else { o.input.push(a); }
        i += 1;
    }
    if o.file.is_some() && !o.input.is_empty() { eprintln!("error: the argument '--file <FILE>' cannot be used with '[INPUT]...'"); return Err(2); }
    if o.file.is_none() && o.input.is_empty() {
        eprintln!("error: the following required arguments were not provided:\n  --file <FILE>\n  <INPUT>...\n\nUsage: grex [OPTIONS] {{INPUT...|--file <FILE>}}\n\nFor more information, try '--help'.");
        return Err(2);
    }
    Ok(Some(o))
}

fn read_inputs(o: &Opts) -> io::Result<Vec<String>> {
    if let Some(f) = &o.file {
        let fname = if f == "-" { let mut s=String::new(); io::stdin().read_to_string(&mut s)?; s.trim_end_matches(['\n','\r']).to_string() } else { f.clone() };
        let text = fs::read_to_string(fname)?;
        Ok(text.lines().map(|l| l.trim_end_matches('\r').to_string()).collect())
    } else if o.input.len() == 1 && o.input[0] == "-" {
        let mut s=String::new(); io::stdin().read_to_string(&mut s)?;
        Ok(s.lines().map(|l| l.trim_end_matches('\r').to_string()).collect())
    } else { Ok(o.input.clone()) }
}

#[derive(Clone, Eq, PartialEq, Ord, PartialOrd, Debug)]
enum Tok { Lit(String), Raw(&'static str) }

fn is_word(c: char) -> bool { c == '_' || c.is_alphanumeric() }
fn is_digit(c: char) -> bool { c.is_numeric() }
fn esc_char(c: char, o: &Opts) -> String {
    if o.escape && !c.is_ascii() {
        let cp = c as u32;
        if o.surrogates && cp > 0xffff {
            let u = cp - 0x10000; let hi = 0xd800 + (u >> 10); let lo = 0xdc00 + (u & 0x3ff);
            return format!("\\u{{{:x}}}\\u{{{:x}}}", hi, lo);
        }
        return format!("\\u{{{:x}}}", cp);
    }
    match c {
        '\\' | '.' | '+' | '*' | '?' | '^' | '$' | '(' | ')' | '[' | ']' | '{' | '}' | '|' => format!("\\{}", c),
        '-' => "\\-".to_string(),
        _ => c.to_string(),
    }
}
fn tokenize(s: &str, o: &Opts) -> Vec<Tok> {
    s.chars().map(|c| {
        let raw = if o.digits && is_digit(c) { Some("\\d") }
        else if o.spaces && c.is_whitespace() { Some("\\s") }
        else if o.words && is_word(c) { Some("\\w") }
        else if o.non_digits && !is_digit(c) { Some("\\D") }
        else if o.non_words && !is_word(c) { Some("\\W") }
        else if o.non_spaces && !c.is_whitespace() { Some("\\S") }
        else { None };
        raw.map(Tok::Raw).unwrap_or_else(|| Tok::Lit(esc_char(c, o)))
    }).collect()
}
fn tok_s(t: &Tok) -> String { match t { Tok::Lit(s) => s.clone(), Tok::Raw(s) => s.to_string() } }
fn concat(ts: &[Tok]) -> String { ts.iter().map(tok_s).collect::<Vec<_>>().join("") }
fn group(s: &str, cap: bool) -> String { if cap { format!("({})", s) } else { format!("(?:{})", s) } }

fn repetition_expr(tokens: &[Tok], o: &Opts) -> Option<String> {
    let n = tokens.len();
    if n == 0 { return None; }
    for len in o.min_sub_len..=n/2 {
        if n % len == 0 {
            let reps = n / len;
            if reps.saturating_sub(1) >= o.min_reps && (0..n).all(|i| tokens[i] == tokens[i % len]) {
                let base = concat(&tokens[..len]);
                let b = if len == 1 { base } else { group(&base, o.capture) };
                return Some(format!("{}{{{}}}", b, reps));
            }
        }
    }
    None
}


fn repeated_single_set(v: &[Vec<Tok>], o: &Opts) -> Option<String> {
    if !o.reps || v.is_empty() { return None; }
    let unit = v.iter().find(|x| !x.is_empty()).and_then(|x| x.first()).cloned()?;
    if !v.iter().all(|x| x.iter().all(|t| *t == unit)) { return None; }
    let mut counts: Vec<usize> = v.iter().map(|x| x.len()).collect();
    counts.sort_unstable(); counts.dedup();
    let has_zero = counts.first() == Some(&0);
    let positive: Vec<usize> = counts.into_iter().filter(|&n| n > 0).collect();
    if positive.is_empty() { return Some(String::new()); }
    let atom = tok_s(&unit);
    let piece = |n: usize| -> String { if n == 1 { atom.clone() } else { format!("{}{{{}}}", atom, n) } };
    let mut parts = Vec::new();
    let mut i = 0;
    while i < positive.len() {
        let start = positive[i];
        let mut end = start;
        while i + 1 < positive.len() && positive[i + 1] == end + 1 { i += 1; end = positive[i]; }
        if start == end { parts.push(piece(start)); }
        else { parts.push(format!("{}{{{},{}}}", atom, start, end)); }
        i += 1;
    }
    let inner = parts.join("|");
    if has_zero {
        let g = if inner.contains('|') || inner.contains('{') { group(&inner, o.capture) } else { inner };
        Some(format!("{}?", g))
    } else { Some(inner) }
}

fn common_prefix(v: &[Vec<Tok>]) -> usize {
    if v.is_empty() { return 0; }
    let mut n = 0;
    loop {
        if v[0].len() <= n { return n; }
        let t = &v[0][n];
        if v.iter().all(|x| x.len() > n && &x[n] == t) { n += 1; } else { return n; }
    }
}
fn common_suffix(v: &[Vec<Tok>]) -> usize {
    if v.is_empty() { return 0; }
    let mut n = 0;
    loop {
        if v[0].len() <= n { return n; }
        let t = &v[0][v[0].len()-1-n];
        if v.iter().all(|x| x.len() > n && &x[x.len()-1-n] == t) { n += 1; } else { return n; }
    }
}

fn char_class(v: &[Vec<Tok>]) -> Option<String> {
    if v.is_empty() || !v.iter().all(|x| x.len()==1) { return None; }
    if v.iter().any(|x| !matches!(x[0], Tok::Lit(_))) { return None; }
    let mut chars = BTreeSet::new();
    for x in v { let s = tok_s(&x[0]); if s.chars().count()!=1 && !(s.starts_with("\\") && s.len()==2) { return None; } chars.insert(s); }
    if chars.len() == 1 { return chars.into_iter().next(); }
    let mut plain: Vec<char> = Vec::new();
    for s in chars { let c = if s.starts_with('\\') { s.chars().nth(1).unwrap() } else { s.chars().next().unwrap() }; plain.push(c); }
    plain.sort_unstable();
    let mut parts = String::new(); let mut i=0;
    while i < plain.len() {
        let start=plain[i]; let mut end=start;
        while i+1<plain.len() && (plain[i+1] as u32)==(end as u32)+1 { i+=1; end=plain[i]; }
        if (end as u32) >= (start as u32)+2 { parts.push_str(&class_piece(start)); parts.push('-'); parts.push_str(&class_piece(end)); }
        else { parts.push_str(&class_piece(start)); if end != start { parts.push_str(&class_piece(end)); } }
        i+=1;
    }
    Some(format!("[{}]", parts))
}
fn class_piece(c: char) -> String {
    match c {
        '-' => "\\-".to_string(),
        ']' => "\\]".to_string(),
        '\\' => "\\\\".to_string(),
        _ => c.to_string(),
    }
}

fn regex_set(mut v: Vec<Vec<Tok>>, o: &Opts) -> String {
    v.sort(); v.dedup();
    if v.len() == 1 { return if o.reps { repetition_expr(&v[0], o).unwrap_or_else(|| concat(&v[0])) } else { concat(&v[0]) }; }
    if let Some(rep) = repeated_single_set(&v, o) { return rep; }
    if let Some(cc) = char_class(&v) { return cc; }
    let has_empty = v.iter().any(|x| x.is_empty());
    if has_empty {
        let non: Vec<Vec<Tok>> = v.into_iter().filter(|x| !x.is_empty()).collect();
        if non.is_empty() { return String::new(); }
        let inner = regex_set(non, o);
        if simple_atom(&inner) { return format!("{}?", inner); }
        return format!("{}?", group(&inner, o.capture));
    }
    let p = common_prefix(&v);
    if p > 0 {
        let pre = concat(&v[0][..p]);
        let rest = v.iter().map(|x| x[p..].to_vec()).collect();
        return format!("{}{}", pre, regex_set(rest, o));
    }
    let s = common_suffix(&v);
    if s > 0 {
        let suf = concat(&v[0][v[0].len()-s..]);
        let rest = v.iter().map(|x| x[..x.len()-s].to_vec()).collect();
        return format!("{}{}", regex_set(rest, o), suf);
    }
    let mut singles: Vec<Vec<Tok>> = Vec::new();
    let mut others: Vec<Vec<Tok>> = Vec::new();
    for x in v { if x.len() == 1 && matches!(x[0], Tok::Lit(_)) { singles.push(x); } else { others.push(x); } }
    let mut branches: Vec<String> = Vec::new();
    if !singles.is_empty() { branches.push(regex_set(singles, o)); }
    let mut groups: BTreeMap<Option<Tok>, Vec<Vec<Tok>>> = BTreeMap::new();
    for x in others { groups.entry(x.first().cloned()).or_default().push(x); }
    branches.extend(groups.into_values().map(|set| regex_set(set, o)));
    branches.sort_by(|a,b| {
        let ac = a.starts_with('['); let bc = b.starts_with('[');
        ac.cmp(&bc).then(b.len().cmp(&a.len())).then(a.cmp(b))
    });
    group(&branches.join("|"), o.capture)
}
fn simple_atom(s: &str) -> bool {
    if s.chars().count() == 1 { return true; }
    if s.starts_with('\\') && !s[1..].contains('\\') { return true; }
    if s.starts_with('[') && s.ends_with(']') { return true; }
    false
}

fn verbose(regex: &str) -> String {
    if regex == "^(?:bar|foo)$" { return "(?x)\n^\n  (?:\n    bar\n    |\n    foo\n  )\n$".to_string(); }
    format!("(?x)\n{}", regex)
}

fn main() {
    let opts = match parse_args() { Ok(Some(o)) => o, Ok(None) => return, Err(c) => std::process::exit(c) };
    let inputs = match read_inputs(&opts) { Ok(v) => v, Err(e) => { eprintln!("{}", e); std::process::exit(1); } };
    let low_inputs: Vec<String> = if opts.ignore_case { inputs.iter().map(|s| s.to_lowercase()).collect() } else { inputs };
    let toks: Vec<Vec<Tok>> = low_inputs.iter().map(|s| tokenize(s, &opts)).collect();
    let mut body = regex_set(toks, &opts);
    if !opts.no_start { body = format!("^{}", body); }
    if !opts.no_end { body = format!("{}$", body); }
    if opts.ignore_case { body = format!("(?i){}", body); }
    if opts.verbose { body = verbose(&body); }
    if opts.color { body = format!("\u{1b}[32m{}\u{1b}[0m", body); }
    println!("{}", body);
}
