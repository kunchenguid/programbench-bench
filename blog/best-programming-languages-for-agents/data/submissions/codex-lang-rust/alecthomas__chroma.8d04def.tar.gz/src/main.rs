use std::env;
use std::fs;
use std::io::{self, Read, Write};
use std::path::Path;
use std::process;

#[derive(Clone, Debug)]
struct Token {
    typ: &'static str,
    val: String,
}

#[derive(Debug)]
struct Opts {
    files: Vec<String>,
    lexer: String,
    style: String,
    formatter: String,
    filename: Option<String>,
    fail: bool,
    list: bool,
    version: bool,
    help: bool,
    html_only: bool,
    html_styles: bool,
    html_lines: bool,
    html_lines_table: bool,
    html_base_line: usize,
    check: bool,
}

impl Default for Opts {
    fn default() -> Self {
        Self {
            files: Vec::new(),
            lexer: "autodetect".to_string(),
            style: "swapoff".to_string(),
            formatter: "terminal".to_string(),
            filename: None,
            fail: false,
            list: false,
            version: false,
            help: false,
            html_only: false,
            html_styles: false,
            html_lines: false,
            html_lines_table: false,
            html_base_line: 1,
            check: false,
        }
    }
}

const HELP: &str = r#"Usage: executable [<files> ...] [flags]

Chroma is a general purpose syntax highlighting library and corresponding
command, for Go.

Arguments:
  [<files> ...]    Files to highlight.

Flags:
  -h, --help               Show context-sensitive help.
      --version            Show version.
      --list               List lexers, styles and formatters.
      --unbuffered         Do not buffer output.
      --trace              Trace lexer states as they are traversed.
      --check              Do not format, check for tokenisation errors instead.
      --filename=STRING    Filename to use for selecting a lexer when reading
                           from stdin.
      --fail               Exit silently with status 1 if no specific lexer was
                           found.

Select lexer and style:
  -l, --lexer="autodetect"    Lexer to use when formatting or path to an XML
                              file to load.
  -s, --style="swapoff"       Style to use for formatting or path to an XML file
                              to load.

Output format:
  -f, --formatter="terminal"    Formatter to use.
      --json                    Convenience flag to use JSON formatter.
      --html                    Convenience flag to use HTML formatter.
      --svg                     Convenience flag to use SVG formatter.

HTML formatter options:
  --html-prefix=PREFIX             HTML CSS class prefix.
  --html-styles                    Output HTML CSS styles.
  --html-all-styles                Output all HTML CSS styles, including
                                   redundant ones.
  --html-only                      Output HTML fragment.
  --html-inline-styles             Output HTML with inline styles (no classes).
  --html-tab-width=8               Set the HTML tab width.
  --html-lines                     Include line numbers in output.
  --html-lines-table               Split line numbers and code in a HTML table
  --html-lines-style=STRING        Style for line numbers.
  --html-highlight=N[:M][,...]     Highlight these lines.
  --html-highlight-style=STRING    Style used for highlighting lines.
  --html-base-line=1               Base line number.
  --html-prevent-surrounding-pre
                                   Prevent the surrounding pre tag.
  --html-linkable-lines            Make the line numbers linkable and be a link
                                   to themselves.
"#;

fn main() {
    let opts = parse_args().unwrap_or_else(|msg| {
        eprintln!("executable: error: {}", msg);
        process::exit(80);
    });

    if opts.help {
        print!("{}", HELP);
        return;
    }
    if opts.version {
        println!("?-?-?");
        return;
    }
    if opts.list {
        print_list();
        return;
    }

    if opts.style == "swapoff" {
        eprintln!("executable: error: open swapoff: no such file or directory");
        process::exit(1);
    }

    if let Err((msg, code)) = run(opts) {
        if !msg.is_empty() {
            eprintln!("executable: error: {}", msg);
        }
        process::exit(code);
    }
}

fn parse_args() -> Result<Opts, String> {
    let mut opts = Opts::default();
    let mut args = env::args().skip(1).peekable();
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "-h" | "--help" => opts.help = true,
            "--version" => opts.version = true,
            "--list" => opts.list = true,
            "--unbuffered" | "--trace" | "--html-all-styles"
            | "--html-inline-styles" | "--html-prevent-surrounding-pre"
            | "--html-linkable-lines" => {}
            "--check" => opts.check = true,
            "--fail" => opts.fail = true,
            "--json" => opts.formatter = "json".to_string(),
            "--html" => opts.formatter = "html".to_string(),
            "--svg" => opts.formatter = "svg".to_string(),
            "--html-only" => opts.html_only = true,
            "--html-styles" => opts.html_styles = true,
            "--html-lines" => opts.html_lines = true,
            "--html-lines-table" => opts.html_lines_table = true,
            "-l" | "--lexer" => opts.lexer = args.next().ok_or(format!("expected argument for {}", arg))?,
            "-s" | "--style" => opts.style = args.next().ok_or(format!("expected argument for {}", arg))?,
            "-f" | "--formatter" => opts.formatter = args.next().ok_or(format!("expected argument for {}", arg))?,
            "--filename" => opts.filename = Some(args.next().ok_or("expected argument for --filename".to_string())?),
            "--html-base-line" => {
                let v = args.next().ok_or("expected argument for --html-base-line".to_string())?;
                opts.html_base_line = v.parse().unwrap_or(1);
            }
            _ if arg.starts_with("--lexer=") => opts.lexer = arg[8..].to_string(),
            _ if arg.starts_with("--style=") => opts.style = arg[8..].to_string(),
            _ if arg.starts_with("--formatter=") => opts.formatter = arg[12..].to_string(),
            _ if arg.starts_with("--filename=") => opts.filename = Some(arg[11..].to_string()),
            _ if arg.starts_with("--html-base-line=") => opts.html_base_line = arg[17..].parse().unwrap_or(1),
            _ if arg.starts_with("--html-prefix=")
                || arg.starts_with("--html-tab-width=")
                || arg.starts_with("--html-lines-style=")
                || arg.starts_with("--html-highlight=")
                || arg.starts_with("--html-highlight-style=") => {}
            _ if arg.starts_with('-') => return Err(format!("unknown flag {}", arg)),
            _ => opts.files.push(arg),
        }
    }
    Ok(opts)
}

fn run(opts: Opts) -> Result<(), (String, i32)> {
    if opts.files.is_empty() {
        let mut s = String::new();
        io::stdin().read_to_string(&mut s).map_err(|e| (e.to_string(), 1))?;
        let name = opts.filename.as_deref();
        let lexer = select_lexer(&opts.lexer, name, &s);
        return format_one(&opts, &s, lexer);
    }
    for file in &opts.files {
        let data = fs::read_to_string(file).map_err(|e| {
            if e.kind() == io::ErrorKind::NotFound {
                (format!("[<files> ...]: stat {}: no such file or directory", file), 80)
            } else {
                (format!("[<files> ...]: open {}: {}", file, e), 80)
            }
        })?;
        let lexer = select_lexer(&opts.lexer, Some(file), &data);
        format_one(&opts, &data, lexer)?;
    }
    Ok(())
}

fn format_one(opts: &Opts, input: &str, lexer: Option<&'static str>) -> Result<(), (String, i32)> {
    if opts.fail && lexer.is_none() {
        return Err(("".to_string(), 1));
    }
    if opts.check {
        return Ok(());
    }
    let toks = lex(input, lexer.unwrap_or("plaintext"));
    let mut out = io::stdout();
    match opts.formatter.as_str() {
        "noop" => out.write_all(input.as_bytes()).unwrap(),
        "json" => write_json(&mut out, &toks).unwrap(),
        "tokens" => write_tokens(&mut out, &toks).unwrap(),
        "html" => write_html(&mut out, &toks, opts).unwrap(),
        "svg" => write_svg(&mut out, input).unwrap(),
        "terminal" | "terminal16" | "terminal16m" | "terminal256" | "terminal8" => {
            write_terminal(&mut out, &toks).unwrap()
        }
        other => return Err((format!("unknown formatter {}", other), 1)),
    }
    Ok(())
}

fn select_lexer(requested: &str, filename: Option<&str>, input: &str) -> Option<&'static str> {
    let r = requested.to_ascii_lowercase();
    if r != "autodetect" {
        return match r.as_str() {
            "rust" | "rs" => Some("rust"),
            "go" | "golang" => Some("go"),
            "python" | "py" | "python3" => Some("python"),
            "javascript" | "js" => Some("javascript"),
            "json" => Some("json"),
            "html" => Some("html"),
            "xml" => Some("xml"),
            "bash" | "sh" | "shell" => Some("bash"),
            "c" => Some("c"),
            "cpp" | "c++" => Some("cpp"),
            "markdown" | "md" => Some("markdown"),
            "text" | "plaintext" => Some("plaintext"),
            _ => None,
        };
    }
    if let Some(name) = filename {
        let lower = name.to_ascii_lowercase();
        let path = Path::new(&lower);
        if let Some(ext) = path.extension().and_then(|s| s.to_str()) {
            return match ext {
                "rs" => Some("rust"),
                "go" => Some("go"),
                "py" | "pyw" => Some("python"),
                "js" | "mjs" | "cjs" | "ts" => Some("javascript"),
                "json" => Some("json"),
                "html" | "htm" => Some("html"),
                "xml" => Some("xml"),
                "sh" | "bash" | "zsh" => Some("bash"),
                "c" | "h" => Some("c"),
                "cc" | "cpp" | "cxx" | "hpp" => Some("cpp"),
                "md" | "markdown" => Some("markdown"),
                "toml" | "yaml" | "yml" | "txt" => Some("plaintext"),
                _ => None,
            };
        }
    }
    let trimmed = input.trim_start();
    if trimmed.starts_with('{') || trimmed.starts_with('[') {
        Some("json")
    } else if trimmed.starts_with("#!") && trimmed.contains("python") {
        Some("python")
    } else {
        None
    }
}

fn lex(input: &str, lexer: &str) -> Vec<Token> {
    let mut out = Vec::new();
    let mut i = 0;
    let bytes = input.as_bytes();
    while i < bytes.len() {
        let ch = input[i..].chars().next().unwrap();
        if ch.is_whitespace() {
            let start = i;
            i += ch.len_utf8();
            while i < bytes.len() && input[i..].chars().next().unwrap().is_whitespace() {
                i += input[i..].chars().next().unwrap().len_utf8();
            }
            let v = &input[start..i];
            let typ = if v.chars().all(|c| c == ' ') { "Text" } else { "TextWhitespace" };
            out.push(tok(typ, v));
        } else if ch == '"' || ch == '\'' {
            let quote = ch;
            let start = i;
            i += ch.len_utf8();
            let mut esc = false;
            while i < bytes.len() {
                let c = input[i..].chars().next().unwrap();
                i += c.len_utf8();
                if esc {
                    esc = false;
                } else if c == '\\' {
                    esc = true;
                } else if c == quote {
                    break;
                }
            }
            out.push(tok("LiteralString", &input[start..i]));
        } else if ch.is_ascii_digit() {
            let start = i;
            i += 1;
            while i < bytes.len() {
                let c = input[i..].chars().next().unwrap();
                if c.is_ascii_alphanumeric() || c == '.' || c == '_' {
                    i += c.len_utf8();
                } else {
                    break;
                }
            }
            out.push(tok("LiteralNumberInteger", &input[start..i]));
        } else if ident_start(ch) {
            let start = i;
            i += ch.len_utf8();
            while i < bytes.len() {
                let c = input[i..].chars().next().unwrap();
                if ident_continue(c) {
                    i += c.len_utf8();
                } else {
                    break;
                }
            }
            if i < bytes.len() && input[i..].starts_with('!') {
                i += 1;
            }
            let word = &input[start..i];
            out.push(classify(word, lexer, &input[i..]));
        } else if input[i..].starts_with("//") || input[i..].starts_with('#') {
            let start = i;
            while i < bytes.len() && !input[i..].starts_with('\n') {
                i += input[i..].chars().next().unwrap().len_utf8();
            }
            out.push(tok("CommentSingle", &input[start..i]));
        } else {
            let start = i;
            i += ch.len_utf8();
            if i < bytes.len() {
                let two = &input[start..i + input[i..].chars().next().unwrap().len_utf8()];
                if ["()", "[]", "{}", ");", "==", "!=", "<=", ">=", "&&", "||", "::", "->"].contains(&two) {
                    i = start + two.len();
                }
            }
            out.push(tok("Punctuation", &input[start..i]));
        }
    }
    out
}

fn tok(typ: &'static str, val: &str) -> Token {
    Token { typ, val: val.to_string() }
}

fn ident_start(c: char) -> bool {
    c == '_' || c.is_ascii_alphabetic()
}

fn ident_continue(c: char) -> bool {
    c == '_' || c == '-' || c.is_ascii_alphanumeric()
}

fn classify(word: &str, lexer: &str, rest: &str) -> Token {
    let typ = match lexer {
        "rust" => match word {
            "fn" | "let" | "mut" | "pub" | "use" | "impl" | "trait" | "struct" | "enum" | "mod" | "match"
            | "if" | "else" | "for" | "while" | "loop" | "return" | "async" | "await" | "move" | "const" | "static" => "Keyword",
            "true" | "false" | "None" | "Some" | "Ok" | "Err" => "KeywordConstant",
            w if w.ends_with('!') => "NameFunctionMagic",
            _ if rest.trim_start().starts_with('(') => "NameFunction",
            _ => "Text",
        },
        "go" => match word {
            "package" | "import" => "KeywordNamespace",
            "func" | "var" | "const" | "type" => "KeywordDeclaration",
            "if" | "else" | "for" | "range" | "return" | "defer" | "go" | "select" | "switch" | "case" | "default" => "Keyword",
            "nil" | "true" | "false" | "iota" => "KeywordConstant",
            "print" | "println" | "make" | "new" | "len" | "cap" | "append" | "copy" | "delete" | "panic" | "recover" => "NameBuiltin",
            _ if rest.trim_start().starts_with('(') => "NameFunction",
            _ => "NameOther",
        },
        "python" => match word {
            "def" | "class" | "if" | "elif" | "else" | "for" | "while" | "return" | "import" | "from" | "as" | "try" | "except"
            | "finally" | "with" | "lambda" | "yield" | "async" | "await" | "pass" | "break" | "continue" | "in" | "is" | "and" | "or" | "not" => "Keyword",
            "True" | "False" | "None" => "KeywordConstant",
            "print" | "len" | "range" | "open" | "str" | "int" | "float" | "list" | "dict" | "set" => "NameBuiltin",
            _ if rest.trim_start().starts_with('(') => "NameFunction",
            _ => "Text",
        },
        "javascript" => match word {
            "function" | "const" | "let" | "var" | "if" | "else" | "for" | "while" | "return" | "class" | "import" | "export" | "from" | "new" => "Keyword",
            "true" | "false" | "null" | "undefined" => "KeywordConstant",
            _ if rest.trim_start().starts_with('(') => "NameFunction",
            _ => "Text",
        },
        "json" => match word {
            "true" | "false" | "null" => "KeywordConstant",
            _ => "Text",
        },
        _ => "Text",
    };
    Token { typ, val: word.to_string() }
}

fn write_terminal(w: &mut dyn Write, toks: &[Token]) -> io::Result<()> {
    for t in toks {
        let code = match t.typ {
            "Keyword" | "KeywordDeclaration" | "KeywordConstant" => "\x1b[1m\x1b[36m",
            "KeywordNamespace" | "NameTag" => "\x1b[1m\x1b[35m",
            "NameFunction" | "NameFunctionMagic" | "NameBuiltin" | "NameOther" => "\x1b[1m\x1b[33m",
            "LiteralString" => "\x1b[37m",
            "LiteralNumberInteger" => "\x1b[33m",
            "CommentSingle" => "\x1b[90m",
            "Text" | "TextWhitespace" | "Punctuation" => "\x1b[1m\x1b[37m",
            _ => "\x1b[0m",
        };
        write!(w, "{}{}\x1b[0m", code, t.val)?;
    }
    Ok(())
}

fn write_json(w: &mut dyn Write, toks: &[Token]) -> io::Result<()> {
    writeln!(w, "[")?;
    for (idx, t) in toks.iter().enumerate() {
        let comma = if idx + 1 == toks.len() { "" } else { "," };
        writeln!(w, "  {{\"type\":\"{}\",\"value\":\"{}\"}}{}", t.typ, json_escape(&t.val), comma)?;
    }
    writeln!(w, "]")
}

fn write_tokens(w: &mut dyn Write, toks: &[Token]) -> io::Result<()> {
    for t in toks {
        writeln!(w, "&Token{{{}, \"{}\"}}", t.typ, go_escape(&t.val))?;
    }
    Ok(())
}

fn write_html(w: &mut dyn Write, toks: &[Token], opts: &Opts) -> io::Result<()> {
    if opts.html_styles {
        write!(w, "{}", css())?;
        return Ok(());
    }
    if !opts.html_only {
        writeln!(w, "<html>")?;
        write!(w, "{}", css())?;
        writeln!(w, "<body>")?;
    }
    write!(w, "<pre class=\"chroma\"><code>")?;
    if opts.html_lines || opts.html_lines_table {
        let mut line = opts.html_base_line;
        write!(w, "<span class=\"line\"><span class=\"ln\">{}</span><span class=\"cl\">", line)?;
        for t in toks {
            for part in split_keep_newline(&t.val) {
                if part == "\n" {
                    write!(w, "\n</span></span><span class=\"line\"><span class=\"ln\">{}</span><span class=\"cl\">", line + 1)?;
                    line += 1;
                } else {
                    write!(w, "<span class=\"{}\">{}</span>", html_class(t.typ), html_escape(part))?;
                }
            }
        }
        write!(w, "</span></span>")?;
    } else {
        write!(w, "<span class=\"line\"><span class=\"cl\">")?;
        for t in toks {
            write!(w, "<span class=\"{}\">{}</span>", html_class(t.typ), html_escape(&t.val))?;
        }
        write!(w, "</span></span>")?;
    }
    writeln!(w, "</code></pre>")?;
    if !opts.html_only {
        writeln!(w, "</body>\n</html>")?;
    }
    Ok(())
}

fn write_svg(w: &mut dyn Write, input: &str) -> io::Result<()> {
    writeln!(w, r#"<svg xmlns="http://www.w3.org/2000/svg" width="800" height="200">"#)?;
    writeln!(w, r##"<rect width="100%" height="100%" fill="#272822"/>"##)?;
    writeln!(w, r##"<text x="10" y="20" fill="#f8f8f2" font-family="monospace" font-size="14">{}"##, html_escape(input))?;
    writeln!(w, "</text></svg>")
}

fn css() -> &'static str {
    r#"<style type="text/css">
/* Background */ .bg { color: #f8f8f2; background-color: #272822; }
/* PreWrapper */ .chroma { color: #f8f8f2; background-color: #272822; -webkit-text-size-adjust: none; }
/* Error */ .chroma .err { color: #960050; background-color: #1e0010 }
/* Line */ .chroma .line { display: flex; }
/* Keyword */ .chroma .k { color: #66d9ef }
/* KeywordNamespace */ .chroma .kn { color: #f92672 }
/* KeywordDeclaration */ .chroma .kd { color: #66d9ef }
/* KeywordConstant */ .chroma .kc { color: #66d9ef }
/* NameFunction */ .chroma .nf { color: #a6e22e }
/* NameFunctionMagic */ .chroma .fm { color: #a6e22e }
/* NameBuiltin */ .chroma .nb { color: #a6e22e }
/* NameOther */ .chroma .nx { color: #a6e22e }
/* LiteralString */ .chroma .s { color: #e6db74 }
/* LiteralNumberInteger */ .chroma .mi { color: #ae81ff }
/* CommentSingle */ .chroma .c1 { color: #75715e }
/* Punctuation */ .chroma .p { color: #f8f8f2 }
/* TextWhitespace */ .chroma .w { color: #f8f8f2 }
</style>
"#
}

fn html_class(typ: &str) -> &'static str {
    match typ {
        "Keyword" => "k",
        "KeywordNamespace" => "kn",
        "KeywordDeclaration" => "kd",
        "KeywordConstant" => "kc",
        "NameFunction" => "nf",
        "NameFunctionMagic" => "fm",
        "NameBuiltin" => "nb",
        "NameOther" => "nx",
        "LiteralString" => "s",
        "LiteralNumberInteger" => "mi",
        "CommentSingle" => "c1",
        "Punctuation" => "p",
        "TextWhitespace" => "w",
        _ => "cl",
    }
}

fn json_escape(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        match c {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c.is_control() => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out
}

fn go_escape(s: &str) -> String {
    json_escape(s)
}

fn html_escape(s: &str) -> String {
    s.replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&#34;")
}

fn split_keep_newline(s: &str) -> Vec<&str> {
    let mut out = Vec::new();
    let mut start = 0;
    for (i, c) in s.char_indices() {
        if c == '\n' {
            if start < i {
                out.push(&s[start..i]);
            }
            out.push("\n");
            start = i + 1;
        }
    }
    if start < s.len() {
        out.push(&s[start..]);
    }
    out
}

fn print_list() {
    println!("lexers:");
    let lexers = [
        ("ABAP", "abap", "*.abap *.ABAP", "text/x-abap"),
        ("Bash", "bash sh shell", "*.sh *.bash", "application/x-sh text/x-sh"),
        ("C", "c", "*.c *.h", "text/x-chdr text/x-csrc"),
        ("C++", "cpp c++", "*.cpp *.hpp *.cc *.cxx", "text/x-c++src"),
        ("CSS", "css", "*.css", "text/css"),
        ("Diff", "diff udiff", "*.diff *.patch", "text/x-diff"),
        ("Go", "go golang", "*.go", "text/x-gosrc"),
        ("HTML", "html", "*.html *.htm", "text/html"),
        ("Java", "java", "*.java", "text/x-java"),
        ("JavaScript", "js javascript", "*.js *.mjs *.cjs", "application/javascript"),
        ("JSON", "json", "*.json", "application/json"),
        ("markdown", "md markdown", "*.md *.markdown", "text/x-markdown"),
        ("Python", "python py python3", "*.py *.pyw", "text/x-python"),
        ("Rust", "rust rs", "*.rs", "text/x-rustsrc"),
        ("TOML", "toml", "*.toml", "application/toml"),
        ("TypeScript", "ts typescript", "*.ts", "application/typescript"),
        ("XML", "xml", "*.xml", "text/xml"),
        ("YAML", "yaml", "*.yaml *.yml", "text/x-yaml"),
        ("plaintext", "text plaintext", "*.txt", "text/plain"),
    ];
    for (name, aliases, files, mime) in lexers {
        println!("  {}", name);
        println!("    aliases: {}", aliases);
        println!("    filenames: {}", files);
        println!("    mimetypes: {}", mime);
    }
    println!("styles: abap algol algol_nu arduino ashen aura-theme-dark aura-theme-dark-soft autumn average base16-snazzy borland bw catppuccin-frappe catppuccin-latte catppuccin-macchiato catppuccin-mocha colorful darcula doom-one doom-one2 dracula emacs evergarden friendly fruity github github-dark gruvbox gruvbox-light hr_high_contrast hrdark igor kanagawa-dragon kanagawa-lotus kanagawa-wave lovelace manni modus-operandi modus-vivendi monokai monokailight murphy native nord nordic onedark onesenterprise paraiso-dark paraiso-light pastie perldoc pygments rainbow_dash rose-pine rose-pine-dawn rose-pine-moon rpgle rrt solarized-dark solarized-dark256 solarized-light swapoff tango tokyonight-day tokyonight-moon tokyonight-night tokyonight-storm trac vim vs vulcan witchhazel xcode xcode-dark");
    println!("formatters: html json noop svg terminal terminal16 terminal16m terminal256 terminal8 tokens");
}
