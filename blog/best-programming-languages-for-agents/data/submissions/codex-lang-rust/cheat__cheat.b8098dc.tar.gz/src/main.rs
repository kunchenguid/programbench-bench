use regex::Regex;
use std::collections::{BTreeSet, HashSet};
use std::env;
use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};
use std::process::{self, Command};

#[derive(Clone, Debug)]
struct CheatPath {
    name: String,
    path: PathBuf,
    tags: Vec<String>,
    readonly: bool,
}

#[derive(Clone, Debug)]
struct Config {
    editor: String,
    pager: String,
    colorize: bool,
    paths: Vec<CheatPath>,
}

#[derive(Clone, Debug)]
struct Sheet {
    title: String,
    file: PathBuf,
    path_name: String,
    tags: Vec<String>,
    body: String,
    readonly: bool,
}

#[derive(Default)]
struct Opts {
    all: bool,
    brief: bool,
    colorize: bool,
    completion: Option<String>,
    conf: bool,
    dirs: bool,
    edit: Option<String>,
    init: bool,
    list: bool,
    path: Option<String>,
    regex: bool,
    rm: Option<String>,
    search: Option<String>,
    tag: Option<String>,
    tags: bool,
    update: bool,
    version: bool,
    help: bool,
    positional: Vec<String>,
}

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    match run(args) {
        Ok(code) => process::exit(code),
        Err((msg, code)) => {
            eprintln!("{}", msg);
            process::exit(code);
        }
    }
}

fn run(args: Vec<String>) -> Result<i32, (String, i32)> {
    let opts = parse_args(&args)?;
    if opts.help || args.is_empty() {
        print_help();
        return Ok(0);
    }
    if opts.version {
        println!("5.1.0");
        return Ok(0);
    }
    if opts.init {
        print_init();
        return Ok(0);
    }
    if let Some(shell) = opts.completion.as_ref() {
        return completion(shell);
    }

    let conf_path = find_config_path();
    if opts.conf {
        if let Some(path) = conf_path {
            println!("{}", path.display());
            return Ok(0);
        }
        return Err(("A config file was not found. Would you like to create one now? [Y/n]: failed to create config: failed to prompt: EOF".to_string(), 1));
    }

    let config_path = match conf_path {
        Some(path) => path,
        None => return Err(("A config file was not found. Would you like to create one now? [Y/n]: failed to create config: failed to prompt: EOF".to_string(), 1)),
    };
    let mut config = parse_config(&config_path).map_err(|e| (format!("failed to load config: {}", e), 1))?;
    add_directory_scoped_path(&mut config);

    if let Some(name) = opts.path.as_ref() {
        if !config.paths.iter().any(|p| &p.name == name) {
            return Err((format!("invalid option --path: cheatpath does not exist: {}", name), 1));
        }
    }

    if opts.dirs {
        print_dirs(&config);
        return Ok(0);
    }
    if opts.update {
        update_paths(&config, opts.path.as_deref());
        return Ok(0);
    }
    if let Some(name) = opts.edit.as_ref() {
        edit_sheet(&config, opts.path.as_deref(), name)?;
        return Ok(0);
    }
    if let Some(name) = opts.rm.as_ref() {
        return remove_sheet(&config, opts.path.as_deref(), name);
    }

    let sheets = discover_sheets(&config);
    let filtered = filter_sheets(sheets, opts.path.as_deref(), opts.tag.as_deref());

    if opts.tags {
        let mut set = BTreeSet::new();
        for sheet in &filtered {
            for tag in &sheet.tags {
                set.insert(tag.clone());
            }
        }
        for tag in set {
            println!("{}", tag);
        }
        return Ok(0);
    }

    if opts.list || opts.brief {
        let title_filter = opts.positional.first().map(|s| s.as_str());
        let listed: Vec<Sheet> = filtered
            .into_iter()
            .filter(|s| title_filter.map(|f| s.title.contains(f)).unwrap_or(true))
            .collect();
        if opts.brief {
            print_brief(&listed);
        } else {
            print_list(&listed);
        }
        return Ok(0);
    }

    if let Some(phrase) = opts.search.as_ref() {
        return search_sheets(&filtered, phrase, opts.regex, opts.colorize || config.colorize);
    }

    if let Some(name) = opts.positional.first() {
        let mut matches: Vec<Sheet> = filtered.into_iter().filter(|s| &s.title == name).collect();
        if matches.is_empty() {
            return Err((format!("No cheatsheet found for '{}'.", name), 2));
        }
        if opts.all {
            print_all_matches(&matches);
        } else {
            let sheet = matches.pop().unwrap();
            print!("{}", ensure_trailing_newline(&sheet.body));
        }
        return Ok(0);
    }

    print_help();
    Ok(0)
}

fn parse_args(args: &[String]) -> Result<Opts, (String, i32)> {
    let mut o = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let arg = &args[i];
        if arg == "--" {
            o.positional.extend_from_slice(&args[i + 1..]);
            break;
        } else if !arg.starts_with('-') || arg == "-" {
            o.positional.push(arg.clone());
        } else if let Some((flag, val)) = arg.split_once('=') {
            set_opt_value(&mut o, flag, val.to_string())?;
        } else {
            match arg.as_str() {
                "-a" | "--all" => o.all = true,
                "-b" | "--brief" => o.brief = true,
                "-c" | "--colorize" => o.colorize = true,
                "--conf" => o.conf = true,
                "-d" | "--directories" => o.dirs = true,
                "-h" | "--help" => o.help = true,
                "--init" => o.init = true,
                "-l" | "--list" => o.list = true,
                "-r" | "--regex" => o.regex = true,
                "-T" | "--tags" => o.tags = true,
                "-u" | "--update" => o.update = true,
                "-v" | "--version" => o.version = true,
                "-e" | "--edit" | "-p" | "--path" | "-s" | "--search" | "-t" | "--tag" | "--rm" | "--completion" => {
                    i += 1;
                    if i >= args.len() {
                        return Err((format!("flag needs an argument: {}", arg), 1));
                    }
                    set_opt_value(&mut o, arg, args[i].clone())?;
                }
                _ => return Err((format!("unknown flag: {}", arg), 1)),
            }
        }
        i += 1;
    }
    Ok(o)
}

fn set_opt_value(o: &mut Opts, flag: &str, val: String) -> Result<(), (String, i32)> {
    match flag {
        "-e" | "--edit" => o.edit = Some(val),
        "-p" | "--path" => o.path = Some(val),
        "-s" | "--search" => o.search = Some(val),
        "-t" | "--tag" => o.tag = Some(val),
        "--rm" => o.rm = Some(val),
        "--completion" => o.completion = Some(val),
        _ => return Err((format!("unknown flag: {}", flag), 1)),
    }
    Ok(())
}

fn find_config_path() -> Option<PathBuf> {
    if let Ok(p) = env::var("CHEAT_CONFIG_PATH") {
        let path = expand_tilde(&p);
        if path.exists() {
            return Some(path);
        }
        return None;
    }
    let mut candidates = Vec::new();
    if let Ok(xdg) = env::var("XDG_CONFIG_HOME") {
        candidates.push(PathBuf::from(xdg).join("cheat/conf.yml"));
    }
    if let Ok(home) = env::var("HOME") {
        candidates.push(PathBuf::from(&home).join(".config/cheat/conf.yml"));
        candidates.push(PathBuf::from(&home).join(".cheat/conf.yml"));
    }
    candidates.push(PathBuf::from("/etc/cheat/conf.yml"));
    candidates.into_iter().find(|p| p.exists())
}

fn parse_config(path: &Path) -> io::Result<Config> {
    let text = fs::read_to_string(path)?;
    let mut config = Config {
        editor: "vi".to_string(),
        pager: "cat".to_string(),
        colorize: false,
        paths: Vec::new(),
    };
    let mut current: Option<CheatPath> = None;
    let mut in_paths = false;
    for raw in text.lines() {
        let line = raw.split('#').next().unwrap_or("").trim_end();
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }
        if trimmed == "cheatpaths:" {
            in_paths = true;
            continue;
        }
        if !in_paths {
            if let Some(v) = trimmed.strip_prefix("editor:") {
                config.editor = v.trim().trim_matches('"').to_string();
            } else if let Some(v) = trimmed.strip_prefix("pager:") {
                config.pager = v.trim().trim_matches('"').to_string();
            } else if let Some(v) = trimmed.strip_prefix("colorize:") {
                config.colorize = v.trim() == "true";
            }
            continue;
        }
        if trimmed.starts_with("- ") {
            if let Some(cp) = current.take() {
                config.paths.push(cp);
            }
            current = Some(CheatPath {
                name: String::new(),
                path: PathBuf::new(),
                tags: Vec::new(),
                readonly: false,
            });
            let rest = trimmed.trim_start_matches("- ").trim();
            if let Some(v) = rest.strip_prefix("name:") {
                current.as_mut().unwrap().name = v.trim().trim_matches('"').to_string();
            }
            continue;
        }
        if let Some(cp) = current.as_mut() {
            if let Some(v) = trimmed.strip_prefix("name:") {
                cp.name = v.trim().trim_matches('"').to_string();
            } else if let Some(v) = trimmed.strip_prefix("path:") {
                cp.path = expand_tilde(v.trim().trim_matches('"'));
            } else if let Some(v) = trimmed.strip_prefix("tags:") {
                cp.tags = parse_tags(v.trim());
            } else if let Some(v) = trimmed.strip_prefix("readonly:") {
                cp.readonly = v.trim() == "true";
            }
        }
    }
    if let Some(cp) = current.take() {
        config.paths.push(cp);
    }
    Ok(config)
}

fn parse_tags(v: &str) -> Vec<String> {
    let s = v.trim().trim_start_matches('[').trim_end_matches(']');
    s.split(',')
        .map(|x| x.trim().trim_matches('"').trim_matches('\'').to_string())
        .filter(|x| !x.is_empty())
        .collect()
}

fn expand_tilde(s: &str) -> PathBuf {
    if s == "~" || s.starts_with("~/") {
        if let Ok(home) = env::var("HOME") {
            return PathBuf::from(home).join(s.trim_start_matches("~/"));
        }
    }
    PathBuf::from(s)
}

fn add_directory_scoped_path(config: &mut Config) {
    let Ok(mut dir) = env::current_dir() else { return; };
    loop {
        let candidate = dir.join(".cheat");
        if candidate.is_dir() {
            config.paths.push(CheatPath {
                name: ".cheat".to_string(),
                path: candidate,
                tags: vec![".cheat".to_string()],
                readonly: false,
            });
            break;
        }
        if !dir.pop() {
            break;
        }
    }
}

fn discover_sheets(config: &Config) -> Vec<Sheet> {
    let mut out = Vec::new();
    for cp in &config.paths {
        if cp.path.is_dir() {
            walk_path(&cp.path, &cp.path, cp, &mut out);
        }
    }
    out.sort_by(|a, b| a.title.cmp(&b.title).then(a.file.cmp(&b.file)));
    out
}

fn walk_path(root: &Path, dir: &Path, cp: &CheatPath, out: &mut Vec<Sheet>) {
    let Ok(read) = fs::read_dir(dir) else { return; };
    let mut entries: Vec<_> = read.filter_map(Result::ok).collect();
    entries.sort_by_key(|e| e.path());
    for e in entries {
        let path = e.path();
        let name = e.file_name();
        if name.to_string_lossy().starts_with('.') {
            continue;
        }
        if path.is_dir() {
            walk_path(root, &path, cp, out);
        } else if path.is_file() {
            let Ok(text) = fs::read_to_string(&path) else { continue; };
            let (mut tags, body) = split_frontmatter(&text);
            tags.extend(cp.tags.clone());
            tags.sort();
            tags.dedup();
            let title = path.strip_prefix(root).unwrap_or(&path).to_string_lossy().replace('\\', "/");
            out.push(Sheet {
                title,
                file: path,
                path_name: cp.name.clone(),
                tags,
                body,
                readonly: cp.readonly,
            });
        }
    }
}

fn split_frontmatter(text: &str) -> (Vec<String>, String) {
    if !text.starts_with("---\n") {
        return (Vec::new(), text.to_string());
    }
    let mut lines = text.lines();
    lines.next();
    let mut tags = Vec::new();
    let mut body_lines = Vec::new();
    let mut in_front = true;
    for line in lines {
        if in_front && line.trim() == "---" {
            in_front = false;
            continue;
        }
        if in_front {
            if let Some(v) = line.trim().strip_prefix("tags:") {
                tags.extend(parse_tags(v.trim()));
            }
        } else {
            body_lines.push(line);
        }
    }
    let mut body = body_lines.join("\n");
    if text.ends_with('\n') && !body.is_empty() {
        body.push('\n');
    }
    (tags, body)
}

fn filter_sheets(sheets: Vec<Sheet>, path: Option<&str>, tag: Option<&str>) -> Vec<Sheet> {
    sheets
        .into_iter()
        .filter(|s| path.map(|p| s.path_name == p).unwrap_or(true))
        .filter(|s| tag.map(|t| s.tags.iter().any(|x| x == t)).unwrap_or(true))
        .collect()
}

fn print_dirs(config: &Config) {
    let width = config.paths.iter().map(|p| p.name.len()).max().unwrap_or(0);
    for p in &config.paths {
        let spaces = " ".repeat(width.saturating_sub(p.name.len()) + 1);
        println!("{}:{}{}", p.name, spaces, p.path.display());
    }
}

fn print_list(sheets: &[Sheet]) {
    let tw = sheets.iter().map(|s| s.title.len()).chain([6]).max().unwrap();
    let fw = sheets.iter().map(|s| s.file.display().to_string().len()).chain([5]).max().unwrap();
    println!("{:<tw$} {:<fw$} tags:", "title:", "file:", tw = tw, fw = fw);
    for s in sheets {
        println!("{:<tw$} {:<fw$} {}", s.title, s.file.display(), s.tags.join(","), tw = tw, fw = fw);
    }
}

fn print_brief(sheets: &[Sheet]) {
    let tw = sheets.iter().map(|s| s.title.len()).chain([6]).max().unwrap();
    println!("{:<tw$} tags:", "title:", tw = tw);
    for s in sheets {
        println!("{:<tw$} {}", s.title, s.tags.join(","), tw = tw);
    }
}

fn search_sheets(sheets: &[Sheet], phrase: &str, is_regex: bool, colorize: bool) -> Result<i32, (String, i32)> {
    let re = if is_regex {
        Some(Regex::new(phrase).map_err(|e| (format!("invalid regex: {}", e), 1))?)
    } else {
        None
    };
    let mut found = Vec::new();
    for s in sheets {
        let matched = if let Some(re) = &re {
            re.is_match(&s.body)
        } else {
            s.body.contains(phrase)
        };
        if matched {
            found.push(s);
        }
    }
    if found.is_empty() {
        return Ok(2);
    }
    for (idx, s) in found.iter().enumerate() {
        if idx > 0 {
            println!();
        }
        println!("{} ({})", s.title, s.path_name);
        for line in s.body.lines() {
            if colorize && !is_regex && !phrase.is_empty() {
                println!("\t{}", line.replace(phrase, &format!("\x1b[31m{}\x1b[0m", phrase)));
            } else {
                println!("\t{}", line);
            }
        }
    }
    Ok(0)
}

fn print_all_matches(matches: &[Sheet]) {
    for (idx, s) in matches.iter().enumerate() {
        if idx > 0 {
            println!();
        }
        println!("{} ({})", s.title, s.path_name);
        for line in s.body.lines() {
            println!("\t{}", line);
        }
    }
}

fn ensure_trailing_newline(s: &str) -> String {
    if s.ends_with('\n') { s.to_string() } else { format!("{}\n", s) }
}

fn edit_sheet(config: &Config, path_filter: Option<&str>, name: &str) -> Result<(), (String, i32)> {
    let sheets = filter_sheets(discover_sheets(config), path_filter, None);
    let existing = sheets.into_iter().filter(|s| s.title == name).last();
    let target = if let Some(sheet) = existing {
        if !sheet.readonly {
            sheet.file
        } else {
            let cp = writable_path(config, path_filter).ok_or_else(|| ("no writable cheatpath available".to_string(), 1))?;
            let dest = cp.path.join(name);
            if let Some(parent) = dest.parent() {
                fs::create_dir_all(parent).map_err(|e| (e.to_string(), 1))?;
            }
            fs::copy(sheet.file, &dest).map_err(|e| (e.to_string(), 1))?;
            dest
        }
    } else {
        let cp = writable_path(config, path_filter).ok_or_else(|| ("no writable cheatpath available".to_string(), 1))?;
        let dest = cp.path.join(name);
        if let Some(parent) = dest.parent() {
            fs::create_dir_all(parent).map_err(|e| (e.to_string(), 1))?;
        }
        if !dest.exists() {
            fs::File::create(&dest).map_err(|e| (e.to_string(), 1))?;
        }
        dest
    };
    let editor = env::var("VISUAL").or_else(|_| env::var("EDITOR")).unwrap_or_else(|_| config.editor.clone());
    let status = Command::new(editor).arg(target).status().map_err(|e| (format!("failed to launch editor: {}", e), 1))?;
    if status.success() { Ok(()) } else { Err(("editor exited unsuccessfully".to_string(), 1)) }
}

fn writable_path<'a>(config: &'a Config, path_filter: Option<&str>) -> Option<&'a CheatPath> {
    config.paths.iter().rev().find(|p| !p.readonly && path_filter.map(|f| p.name == f).unwrap_or(true))
}

fn remove_sheet(config: &Config, path_filter: Option<&str>, name: &str) -> Result<i32, (String, i32)> {
    let sheets = filter_sheets(discover_sheets(config), path_filter, None);
    let mut target = sheets.into_iter().filter(|s| s.title == name && !s.readonly).last();
    if target.is_none() {
        target = filter_sheets(discover_sheets(config), path_filter, None).into_iter().filter(|s| s.title == name).last();
    }
    let Some(sheet) = target else {
        return Err((format!("No cheatsheet found for '{}'.", name), 2));
    };
    if sheet.readonly {
        return Err((format!("cheatsheet is read-only: {}", name), 1));
    }
    fs::remove_file(sheet.file).map_err(|e| (e.to_string(), 1))?;
    Ok(0)
}

fn update_paths(config: &Config, path_filter: Option<&str>) {
    let mut seen = HashSet::new();
    for cp in &config.paths {
        if path_filter.map(|p| p != cp.name).unwrap_or(false) {
            continue;
        }
        if !seen.insert(cp.path.clone()) {
            continue;
        }
        if cp.path.join(".git").is_dir() {
            let _ = Command::new("git").arg("-C").arg(&cp.path).arg("pull").status();
        }
    }
}

fn completion(shell: &str) -> Result<i32, (String, i32)> {
    match shell {
        "bash" => println!("# bash completion V2 for cheat                                -*- shell-script -*-\ncomplete -F _cheat cheat"),
        "zsh" => println!("#compdef cheat\ncompdef _cheat cheat\n\n# zsh completion for cheat                                -*- shell-script -*-"),
        "fish" => println!("# fish completion for cheat                                -*- shell-script -*-\ncomplete -c cheat -f"),
        "powershell" => println!("# powershell completion for cheat                                -*- shell-script -*-"),
        other => return Err((format!("unsupported shell: {} (valid: bash, zsh, fish, powershell)", other), 1)),
    }
    Ok(0)
}

fn print_help() {
    println!(r#"cheat allows you to create and view interactive cheatsheets on the
command-line. It was designed to help remind *nix system administrators of
options for commands that they use frequently, but not frequently enough to
remember.

Usage:
  cheat [cheatsheet] [flags]

Examples:
  To initialize a config file:
    mkdir -p ~/.config/cheat && cheat --init > ~/.config/cheat/conf.yml

  To view the tar cheatsheet:
    cheat tar

  To edit (or create) the foo cheatsheet:
    cheat -e foo

  To edit (or create) the foo/bar cheatsheet on the "work" cheatpath:
    cheat -p work -e foo/bar

  To view all cheatsheet directories:
    cheat -d

  To list all available cheatsheets:
    cheat -l

  To briefly list all cheatsheets whose titles match "apt":
    cheat -b apt

  To list all tags in use:
    cheat -T

  To list available cheatsheets that are tagged as "personal":
    cheat -l -t personal

  To search for "ssh" among all cheatsheets, and colorize matches:
    cheat -c -s ssh

  To search (by regex) for cheatsheets that contain an IP address:
    cheat -c -r -s '(?:[0-9]{{1,3}}\.){{3}}[0-9]{{1,3}}'

  To remove (delete) the foo/bar cheatsheet:
    cheat --rm foo/bar

  To update all git-backed cheatpaths:
    cheat --update

  To view the configuration file path:
    cheat --conf

  To generate shell completions (bash, zsh, fish, powershell):
    cheat --completion bash

Flags:
  -a, --all                Search among all cheatpaths
  -b, --brief              List cheatsheets without file paths
  -c, --colorize           Colorize output
      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)
      --conf               Display the config file path
  -d, --directories        List cheatsheet directories
  -e, --edit cheatsheet    Edit cheatsheet
  -h, --help               help for cheat
      --init               Write a default config file to stdout
  -l, --list               List cheatsheets
  -p, --path name          Return only sheets found on cheatpath name
  -r, --regex              Treat search <phrase> as a regex
      --rm cheatsheet      Remove (delete) cheatsheet
  -s, --search phrase      Search cheatsheets for phrase
  -t, --tag tag            Return only sheets matching tag
  -T, --tags               List all tags in use
  -u, --update             Update git-backed cheatpaths
  -v, --version            Print the version number"#);
}

fn print_init() {
    let home = env::var("HOME").unwrap_or_else(|_| "/home/agent".to_string());
    let editor = env::var("EDITOR").unwrap_or_else(|_| "EDITOR_PATH".to_string());
    println!(r#"---
# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.
editor: {}

# Should 'cheat' always colorize output?
colorize: false

# Which 'chroma' colorscheme should be applied to the output?
style: monokai

# Which 'chroma' "formatter" should be applied?
formatter: terminal256

# Through which pager should output be piped?
pager: /usr/bin/pager

# The paths at which cheatsheets are available. Tags associated with a cheatpath
# are automatically attached to all cheatsheets residing on that path.
cheatpaths:

  # Cheatsheets that are tagged "personal" are stored here by default:
  - name: personal
    path: {}/.config/cheat/cheatsheets/personal
    tags: [ personal ]
    readonly: false

  # Cheatsheets that are tagged "work" are stored here by default:
  - name: work
    path: {}/.config/cheat/cheatsheets/work
    tags: [ work ]
    readonly: false"#, editor, home, home);
    let _ = io::stdout().flush();
}
