use chrono::{Datelike, Duration, Local, NaiveDate, NaiveDateTime, NaiveTime, Weekday};
use std::collections::{BTreeMap, BTreeSet};
use std::env;
use std::fs;
use std::io;
use std::path::PathBuf;
use std::process::{Command, exit};

struct Cli {
    file: Option<PathBuf>,
    command: Option<Cmd>,
}

enum Cmd {
    Start(ActArgs),
    Stop(TimeArg),
    Cancel,
    Change(OptActArgs),
    Check,
    Continue(ContinueArgs),
    Current,
    Edit(EditArgs),
    Last(LastArgs),
    List(QueryArgs),
    Projects(ProjectArgs),
    Report(QueryArgs),
    Sanity,
    Search { search_term: String },
    Status { project: Option<String> },
}

#[derive(Clone, Default)]
struct ActArgs {
    description: String,
    project: String,
    time: Option<String>,
}

#[derive(Clone, Default)]
struct OptActArgs {
    description: Option<String>,
    project: Option<String>,
    time: Option<String>,
}

#[derive(Clone)]
struct ContinueArgs {
    number: usize,
    description: Option<String>,
    project: Option<String>,
    time: Option<String>,
}

#[derive(Clone, Default)]
struct TimeArg {
    time: Option<String>,
}

struct EditArgs {
    editor: Option<String>,
}

struct LastArgs {
    number: usize,
}

#[derive(Clone, Default)]
struct QueryArgs {
    today: bool,
    yesterday: bool,
    current_week: bool,
    last_week: bool,
    no_grouping: bool,
    date: Option<String>,
    from: Option<String>,
    to: Option<String>,
    number: Option<usize>,
    project: Option<String>,
    round: Option<String>,
}

#[derive(Default)]
struct ProjectArgs {
    current: bool,
    no_quotes: bool,
}

#[derive(Clone, Debug)]
struct Activity {
    start: NaiveDateTime,
    end: Option<NaiveDateTime>,
    project: String,
    description: String,
    line: usize,
}

fn main() {
    let cli = parse_cli();
    let Some(cmd) = cli.command else {
        print_help();
        exit(1);
    };
    if let Err(e) = run(cli.file, cmd) {
        eprintln!("Error: {}", e);
        exit(1);
    }
}

fn parse_cli() -> Cli {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") && args.len() == 1 { print_help(); exit(0); }
    if args.iter().any(|a| a == "-V" || a == "--version") { println!("bartib 1.1.0"); exit(0); }
    let mut file = env::var("BARTIB_FILE").ok().map(PathBuf::from);
    let mut i = 0;
    while i < args.len() {
        if args[i] == "-f" {
            if i+1 < args.len() { file = Some(PathBuf::from(args.remove(i+1))); args.remove(i); } else { break; }
        } else { i += 1; }
    }
    if args.is_empty() { return Cli { file, command: None }; }
    if args[0] == "help" {
        if args.len() > 1 { print_sub_help(&args[1]); } else { print_help(); }
        exit(0);
    }
    if args.len() > 1 && (args[1] == "-h" || args[1] == "--help") { print_sub_help(&args[0]); exit(0); }
    let sub = args.remove(0);
    let command = match sub.as_str() {
        "start" => {
            let o = parse_opts(args);
            let d = req(&o, "description", "d");
            let p = req(&o, "project", "p");
            Some(Cmd::Start(ActArgs { description: d, project: p, time: val(&o,"time","t") }))
        }
        "stop" => Some(Cmd::Stop(TimeArg { time: val(&parse_opts(args),"time","t") })),
        "cancel" => Some(Cmd::Cancel),
        "change" => {
            let o = parse_opts(args);
            Some(Cmd::Change(OptActArgs { description: val(&o,"description","d"), project: val(&o,"project","p"), time: val(&o,"time","t") }))
        }
        "check" => Some(Cmd::Check),
        "continue" => {
            let o = parse_opts(args);
            let n = o.free.first().and_then(|s| s.parse().ok()).unwrap_or(0);
            Some(Cmd::Continue(ContinueArgs { number: n, description: val(&o,"description","d"), project: val(&o,"project","p"), time: val(&o,"time","t") }))
        }
        "current" => Some(Cmd::Current),
        "edit" => Some(Cmd::Edit(EditArgs { editor: val(&parse_opts(args), "editor", "e") })),
        "last" => {
            let o = parse_opts(args);
            Some(Cmd::Last(LastArgs { number: val(&o,"number","n").and_then(|s| s.parse().ok()).unwrap_or(10) }))
        }
        "list" => Some(Cmd::List(parse_query(args))),
        "projects" => {
            Some(Cmd::Projects(ProjectArgs {
                current: args.iter().any(|a| a == "-c" || a == "--current"),
                no_quotes: args.iter().any(|a| a == "-n" || a == "--no-quotes"),
            }))
        }
        "report" => Some(Cmd::Report(parse_query(args))),
        "sanity" => Some(Cmd::Sanity),
        "search" => Some(Cmd::Search { search_term: args.first().cloned().unwrap_or_default() }),
        "status" => {
            let o = parse_opts(args);
            Some(Cmd::Status { project: val(&o,"project","p") })
        }
        _ => { eprintln!("error: Found argument '{}' which wasn't expected", sub); exit(1); }
    };
    Cli { file, command }
}

#[derive(Default)]
struct Opts { pairs: Vec<(String,String)>, flags: BTreeSet<String>, free: Vec<String> }
fn parse_opts(args: Vec<String>) -> Opts {
    let mut o = Opts::default();
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        let key = if let Some(k)=a.strip_prefix("--") { Some(k.replace('-', "_")) } else if let Some(k)=a.strip_prefix('-') { Some(k.to_string()) } else { None };
        if let Some(k) = key {
            if matches!(k.as_str(), "today"|"yesterday"|"current_week"|"last_week"|"no_grouping"|"current"|"c"|"no_quotes") {
                o.flags.insert(k);
            } else if i+1 < args.len() {
                o.pairs.push((k, args[i+1].clone()));
                i += 1;
            }
        } else { o.free.push(a.clone()); }
        i += 1;
    }
    o
}
fn val(o: &Opts, long: &str, short: &str) -> Option<String> { o.pairs.iter().rev().find(|(k,_)| k==long || k==short).map(|(_,v)| v.clone()) }
fn flag(o: &Opts, long: &str, short: &str) -> bool { o.flags.contains(long) || o.flags.contains(short) }
fn req(o: &Opts, long: &str, short: &str) -> String {
    val(o,long,short).unwrap_or_else(|| { eprintln!("error: The following required arguments were not provided:\n    --{} <{}>", long, long.to_uppercase()); exit(1); })
}
fn parse_query(args: Vec<String>) -> QueryArgs {
    let o = parse_opts(args);
    QueryArgs {
        today: flag(&o,"today",""), yesterday: flag(&o,"yesterday",""),
        current_week: flag(&o,"current_week",""), last_week: flag(&o,"last_week",""),
        no_grouping: flag(&o,"no_grouping",""), date: val(&o,"date","d"),
        from: val(&o,"from",""), to: val(&o,"to",""), number: val(&o,"number","n").and_then(|s| s.parse().ok()),
        project: val(&o,"project","p"), round: val(&o,"round",""),
    }
}

fn print_help() {
    println!("bartib 1.1.0\nNikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>\nA simple timetracker\n\nUSAGE:\n    executable [OPTIONS] <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]\n\nSUBCOMMANDS:\n    cancel      cancels all currently running activities\n    change      changes the current activity\n    check       checks file and reports parsing errors\n    continue    continues a previous activity\n    current     lists all currently running activities\n    edit        opens the activity log in an editor\n    help        Prints this message or the help of the given subcommand(s)\n    last        displays the descriptions and projects of recent activities\n    list        list recent activities\n    projects    list all projects\n    report      reports duration of tracked activities\n    sanity      checks sanity of bartib log\n    search      search for existing descriptions and projects\n    start       starts a new activity\n    status      shows current status and time reports for today, current week, and current month\n    stop        stops all currently running activities");
}
fn print_sub_help(s: &str) {
    match s {
        "start" => println!("executable-start \nstarts a new activity\n\nUSAGE:\n    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>"),
        "stop" => println!("executable-stop \nstops all currently running activities\n\nUSAGE:\n    executable stop [OPTIONS]"),
        "list" => println!("executable-list \nlist recent activities\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]"),
        "report" => println!("executable-report \nreports duration of tracked activities\n\nUSAGE:\n    executable report [FLAGS] [OPTIONS]"),
        _ => print_help(),
    }
}

fn run(file: Option<PathBuf>, cmd: Cmd) -> Result<(), String> {
    let path = match file {
        Some(p) => p,
        None => return Err("Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable".into()),
    };
    match cmd {
        Cmd::Start(a) => {
            let mut acts = load_ok(&path)?;
            let at = datetime_for(a.time.as_deref())?;
            stop_running(&mut acts, at, true);
            let act = Activity { start: at, end: None, project: a.project, description: a.description, line: acts.len()+1 };
            println!("Started activity: \"{}\" ({}) at {}", act.description, act.project, fmt_dt(act.start));
            acts.push(act);
            save(&path, &acts)?;
        }
        Cmd::Stop(t) => {
            let mut acts = load_ok(&path)?;
            let at = datetime_for(t.time.as_deref())?;
            stop_running(&mut acts, at, true);
            save(&path, &acts)?;
        }
        Cmd::Cancel => {
            let acts = load_ok(&path)?;
            let mut kept = Vec::new();
            for a in acts.into_iter() {
                if a.end.is_none() {
                    println!("Canceled activity: \"{}\" ({}) started at {}", a.description, a.project, fmt_dt(a.start));
                } else {
                    kept.push(a);
                }
            }
            save(&path, &kept)?;
        }
        Cmd::Change(a) => {
            let mut acts = load_ok(&path)?;
            let at = datetime_for(a.time.as_deref())?;
            let prev = acts.iter().rev().find(|x| x.end.is_none()).cloned()
                .or_else(|| acts.iter().rev().find(|x| x.end.is_some()).cloned());
            acts.retain(|x| x.end.is_some());
            let desc = a.description.or_else(|| prev.as_ref().map(|x| x.description.clone())).unwrap_or_default();
            let proj = a.project.or_else(|| prev.as_ref().map(|x| x.project.clone())).unwrap_or_default();
            println!("Changed activity: \"{}\" ({}) started at {}", desc, proj, fmt_dt(at));
            acts.push(Activity { start: at, end: None, project: proj, description: desc, line: acts.len()+1 });
            save(&path, &acts)?;
        }
        Cmd::Continue(c) => {
            let mut acts = load_ok(&path)?;
            let at = datetime_for(c.time.as_deref())?;
            let recent = unique_recent(&acts);
            let chosen = recent.get(c.number).cloned();
            let desc = c.description.or_else(|| chosen.as_ref().map(|x| x.description.clone())).unwrap_or_default();
            let proj = c.project.or_else(|| chosen.as_ref().map(|x| x.project.clone())).unwrap_or_default();
            stop_running(&mut acts, at, true);
            println!("Started activity: \"{}\" ({}) at {}", desc, proj, fmt_dt(at));
            acts.push(Activity { start: at, end: None, project: proj, description: desc, line: acts.len()+1 });
            save(&path, &acts)?;
        }
        Cmd::Check => check(&path)?,
        Cmd::Current => {
            let acts = load_ok(&path)?;
            let running: Vec<_> = acts.iter().filter(|a| a.end.is_none()).collect();
            if running.is_empty() { println!("No Activity is currently running"); }
            else {
                println!("\nStarted At       Description Project Duration");
                for a in running { println!("{} {:<11} {:<7} {}", fmt_dt(a.start), a.description, a.project, dur(duration(a))); }
            }
        }
        Cmd::Edit(e) => {
            let ed = e.editor.or_else(|| env::var("EDITOR").ok()).unwrap_or_else(|| "vi".to_string());
            Command::new(ed).arg(&path).status().map_err(|x| x.to_string())?;
        }
        Cmd::Last(l) => show_last(&load_ok(&path)?, l.number, ""),
        Cmd::List(q) => show_list(&load_ok(&path)?, q)?,
        Cmd::Projects(p) => {
            let acts = load_ok(&path)?;
            let mut set = BTreeSet::new();
            for a in acts {
                if !p.current || a.end.is_none() { set.insert(a.project); }
            }
            for pr in set {
                if p.no_quotes { println!("{}", pr); } else { println!("\"{}\"", pr); }
            }
        }
        Cmd::Report(q) => show_report(&load_ok(&path)?, q)?,
        Cmd::Sanity => sanity(&load_ok(&path)?),
        Cmd::Search { search_term } => show_last(&load_ok(&path)?, usize::MAX, &search_term),
        Cmd::Status { project } => status(&load_ok(&path)?, project),
    }
    Ok(())
}

fn now() -> NaiveDateTime { Local::now().naive_local().with_second(0).unwrap().with_nanosecond(0).unwrap() }

trait StripSecs { fn with_second(&self, s: u32) -> Option<NaiveDateTime>; fn with_nanosecond(&self, n: u32) -> Option<NaiveDateTime>; }
impl StripSecs for NaiveDateTime {
    fn with_second(&self, s: u32) -> Option<NaiveDateTime> { chrono::Timelike::with_second(self, s) }
    fn with_nanosecond(&self, n: u32) -> Option<NaiveDateTime> { chrono::Timelike::with_nanosecond(self, n) }
}

fn datetime_for(t: Option<&str>) -> Result<NaiveDateTime, String> {
    let n = now();
    if let Some(s) = t {
        let tm = NaiveTime::parse_from_str(s, "%H:%M").map_err(|_| "could not parse time".to_string())?;
        Ok(NaiveDateTime::new(n.date(), tm))
    } else { Ok(n) }
}

fn load(path: &PathBuf) -> io::Result<(Vec<Activity>, Vec<(usize,String)>)> {
    let text = fs::read_to_string(path).or_else(|e| if e.kind()==io::ErrorKind::NotFound { Ok(String::new()) } else { Err(e) })?;
    let mut ok = Vec::new();
    let mut bad = Vec::new();
    for (i, line) in text.lines().enumerate() {
        if line.trim().is_empty() { continue; }
        match parse_line(line, i+1) {
            Some(a) => ok.push(a),
            None => bad.push((i+1, line.to_string())),
        }
    }
    Ok((ok,bad))
}

fn load_ok(path: &PathBuf) -> Result<Vec<Activity>, String> {
    Ok(load(path).map_err(|e| e.to_string())?.0)
}

fn parse_line(line: &str, line_no: usize) -> Option<Activity> {
    let parts: Vec<&str> = line.splitn(3, " | ").collect();
    if parts.len() < 2 { return None; }
    let times = parts[0];
    let (start_s, end_s) = if let Some((a,b)) = times.split_once(" - ") { (a, Some(b)) } else { (times, None) };
    let start = NaiveDateTime::parse_from_str(start_s.trim(), "%Y-%m-%d %H:%M").ok()?;
    let end = match end_s { Some(s) => Some(NaiveDateTime::parse_from_str(s.trim(), "%Y-%m-%d %H:%M").ok()?), None => None };
    Some(Activity {
        start,
        end,
        project: parts.get(1).unwrap_or(&"").to_string(),
        description: parts.get(2).unwrap_or(&"").to_string(),
        line: line_no,
    })
}

fn save(path: &PathBuf, acts: &[Activity]) -> Result<(), String> {
    let mut s = String::new();
    for a in acts {
        if let Some(e) = a.end {
            s.push_str(&format!("{} - {} | {} | {}\n", fmt_dt(a.start), fmt_dt(e), a.project, a.description));
        } else {
            s.push_str(&format!("{} | {} | {}\n", fmt_dt(a.start), a.project, a.description));
        }
    }
    fs::write(path, s).map_err(|e| e.to_string())
}

fn fmt_dt(d: NaiveDateTime) -> String { d.format("%Y-%m-%d %H:%M").to_string() }
fn fmt_date(d: NaiveDate) -> String { d.format("%Y-%m-%d").to_string() }
fn duration(a: &Activity) -> Duration { a.end.unwrap_or_else(now) - a.start }
fn dur(d: Duration) -> String {
    let mins = d.num_minutes();
    if mins <= 0 { return "<1m".to_string(); }
    let h = mins / 60; let m = mins % 60;
    if h > 0 { format!("{}h {:02}m", h, m) } else { format!("{}m", m) }
}

fn stop_running(acts: &mut [Activity], at: NaiveDateTime, print: bool) {
    for a in acts.iter_mut().filter(|a| a.end.is_none()) {
        a.end = Some(at);
        if print {
            println!("Stopped activity: \"{}\" ({}) started at {} ({})", a.description, a.project, fmt_dt(a.start), dur(at - a.start));
        }
    }
}

fn check(path: &PathBuf) -> Result<(), String> {
    let (_, bad) = load(path).map_err(|e| e.to_string())?;
    if bad.is_empty() { println!("All lines in the file have been successfully parsed as activities."); }
    else {
        println!("Found {} line(s) with parsing errors\n", bad.len());
        for (n,l) in bad { println!("{}\n  -> could not parse activity (Line: {})", l, n); }
    }
    Ok(())
}

fn unique_recent(acts: &[Activity]) -> Vec<Activity> {
    let mut out = Vec::new();
    let mut seen = BTreeSet::new();
    for a in acts.iter().rev() {
        let key = format!("{}\0{}", a.description, a.project);
        if seen.insert(key) { out.push(a.clone()); }
    }
    out
}

fn show_last(acts: &[Activity], n: usize, term: &str) {
    let term_l = term.to_lowercase();
    let rows: Vec<_> = unique_recent(acts).into_iter()
        .filter(|a| term_l.is_empty() || a.description.to_lowercase().contains(&term_l) || a.project.to_lowercase().contains(&term_l))
        .take(n).collect();
    if rows.is_empty() && term.is_empty() { println!("No activities have been tracked yet"); return; }
    println!("\n #  Description Project");
    for (i,a) in rows.iter().enumerate().rev() {
        println!("[{}] {:<11} {}", i, a.description, a.project);
    }
}

fn range(q: &QueryArgs) -> Result<(Option<NaiveDate>, Option<NaiveDate>), String> {
    let today = now().date();
    if q.today { return Ok((Some(today), Some(today))); }
    if q.yesterday { let d=today-Duration::days(1); return Ok((Some(d), Some(d))); }
    if q.date.is_some() { let d=parse_date(q.date.as_ref().unwrap())?; return Ok((Some(d), Some(d))); }
    if q.current_week {
        let start = week_start(today);
        return Ok((Some(start), Some(start+Duration::days(6))));
    }
    if q.last_week {
        let start = week_start(today)-Duration::days(7);
        return Ok((Some(start), Some(start+Duration::days(6))));
    }
    Ok((q.from.as_ref().map(|s| parse_date(s)).transpose()?, q.to.as_ref().map(|s| parse_date(s)).transpose()?))
}

fn parse_date(s: &str) -> Result<NaiveDate, String> {
    NaiveDate::parse_from_str(s, "%Y-%m-%d").map_err(|_| "could not parse date".to_string())
}
fn week_start(d: NaiveDate) -> NaiveDate {
    let days = match d.weekday() { Weekday::Mon=>0, Weekday::Tue=>1, Weekday::Wed=>2, Weekday::Thu=>3, Weekday::Fri=>4, Weekday::Sat=>5, Weekday::Sun=>6 };
    d - Duration::days(days)
}
fn in_query(a: &Activity, q: &QueryArgs) -> Result<bool, String> {
    let (from,to) = range(q)?;
    if let Some(p)=&q.project { if &a.project != p { return Ok(false); } }
    let d = a.start.date();
    if let Some(f)=from { if d < f { return Ok(false); } }
    if let Some(t)=to { if d > t { return Ok(false); } }
    Ok(true)
}

fn show_list(acts: &[Activity], q: QueryArgs) -> Result<(), String> {
    let _ = range(&q)?;
    let mut rows = Vec::new();
    for a in acts {
        if in_query(a, &q)? {
            rows.push(rounded(a.clone(), &q)?);
        }
    }
    rows.sort_by_key(|a| a.start);
    if let Some(n) = q.number {
        if rows.len() > n { rows = rows.split_off(rows.len()-n); }
    }
    if rows.is_empty() { println!("No activity to display"); return Ok(()); }
    println!("\nStarted          Stopped Description Project Duration");
    if q.no_grouping {
        for a in rows { print_row(&a, true); }
    } else {
        let multi = rows.iter().map(|a| a.start.date()).collect::<BTreeSet<_>>().len() > 1;
        let mut by: BTreeMap<NaiveDate, Vec<Activity>> = BTreeMap::new();
        for a in rows { by.entry(a.start.date()).or_default().push(a); }
        for (d, xs) in by {
            if multi { println!("\n{}\t{}", fmt_date(d), dur(xs.iter().map(duration).fold(Duration::zero(), |a,b| a+b))); }
            for a in xs { print_row(&a, false); }
        }
    }
    Ok(())
}

fn print_row(a: &Activity, date: bool) {
    let st = if date { fmt_dt(a.start) } else { a.start.format("%H:%M").to_string() };
    let en = a.end.map(|e| e.format("%H:%M").to_string()).unwrap_or_else(|| "-".to_string());
    println!("{:<16} {:<7} {:<11} {:<7} {}", st, en, a.description, a.project, dur(duration(a)));
}

fn show_report(acts: &[Activity], q: QueryArgs) -> Result<(), String> {
    let _ = range(&q)?;
    let mut rows = Vec::new();
    for a in acts {
        if in_query(a, &q)? {
            rows.push(rounded(a.clone(), &q)?);
        }
    }
    let mut projects: BTreeMap<String, BTreeMap<String, Duration>> = BTreeMap::new();
    for a in rows {
        *projects.entry(a.project).or_default().entry(a.description).or_insert(Duration::zero()) = projects.get(&a.project).and_then(|m| m.get(&a.description)).cloned().unwrap_or(Duration::zero()) + duration(&a);
    }
    let mut total = Duration::zero();
    println!();
    for (p, ds) in &projects {
        let pt = ds.values().cloned().fold(Duration::zero(), |a,b| a+b);
        total = total + pt;
        println!("{} {}", p, dur(pt));
        for (d, tm) in ds { println!("    {:<12} {}", d, dur(*tm)); }
        println!();
    }
    println!("Total {}", dur(total));
    println!();
    Ok(())
}

fn rounded(mut a: Activity, q: &QueryArgs) -> Result<Activity, String> {
    let Some(r) = &q.round else { return Ok(a); };
    let mins = if let Some(v) = r.strip_suffix('m') {
        v.parse::<i64>().map_err(|_| "could not parse duration".to_string())?
    } else if let Some(v) = r.strip_suffix('h') {
        v.parse::<i64>().map_err(|_| "could not parse duration".to_string())? * 60
    } else {
        r.parse::<i64>().map_err(|_| "could not parse duration".to_string())?
    };
    if mins <= 0 { return Ok(a); }
    a.start = round_dt(a.start, mins);
    a.end = a.end.map(|e| round_dt(e, mins));
    Ok(a)
}

fn round_dt(dt: NaiveDateTime, step_min: i64) -> NaiveDateTime {
    let step = step_min * 60;
    let ts = dt.and_utc().timestamp();
    let rem = ts.rem_euclid(step);
    let down = ts - rem;
    let up = down + step;
    let out = if rem * 2 < step { down } else { up };
    chrono::DateTime::from_timestamp(out, 0).unwrap().naive_local()
}

fn sanity(acts: &[Activity]) {
    let mut any = false;
    for a in acts {
        if let Some(e)=a.end {
            if e < a.start {
                any = true;
                println!("Activity has negative duration\n{} (Started: {}, Ended: {}, Line: {})\n", a.description, fmt_dt(a.start), fmt_dt(e), a.line);
            }
        }
    }
    if !any { println!("No unusual activities."); }
}

fn status(acts: &[Activity], project: Option<String>) {
    let label = project.clone().unwrap_or_else(|| "ALL".into());
    let filtered: Vec<_> = acts.iter().filter(|a| project.as_ref().map(|p| &a.project == p).unwrap_or(true)).cloned().collect();
    println!("\n ======= Status for {} projects ======= \n", label);
    if let Some(a) = filtered.iter().rev().find(|a| a.end.is_none()) {
        println!("  NOW: {} on {} ...... {}\n", a.description, a.project, dur(duration(a)));
    } else {
        println!("  NOW:  NO Activity\n");
    }
    let today = now().date();
    let week = week_start(today);
    let month = NaiveDate::from_ymd_opt(today.year(), today.month(), 1).unwrap();
    println!("  Today......................... {}", dur(sum_since(&filtered, today)));
    println!("  Current week.................. {}", dur(sum_from(&filtered, week)));
    println!("  Current month................. {}", dur(sum_from(&filtered, month)));
    println!();
}

fn sum_since(acts: &[Activity], d: NaiveDate) -> Duration {
    acts.iter().filter(|a| a.start.date()==d).map(duration).fold(Duration::zero(), |a,b| a+b)
}
fn sum_from(acts: &[Activity], d: NaiveDate) -> Duration {
    acts.iter().filter(|a| a.start.date()>=d).map(duration).fold(Duration::zero(), |a,b| a+b)
}
