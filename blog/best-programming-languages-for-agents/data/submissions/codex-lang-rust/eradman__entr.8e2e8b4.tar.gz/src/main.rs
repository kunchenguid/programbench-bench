use std::collections::HashMap;
use std::env;
use std::ffi::{c_char, c_int, c_void, CString};
use std::fs::{self, OpenOptions};
use std::io::{self, Read, Write};
use std::os::unix::process::ExitStatusExt;
use std::path::{Path, PathBuf};
use std::process::{Child, Command, ExitStatus};
use std::time::Duration;

const RELEASE: &str = "5.7";
const O_NONBLOCK: c_int = 0o0004000;
const IN_CLOEXEC: c_int = 0o2000000;
const POLLIN: i16 = 0x0001;

const IN_ACCESS: u32 = 0x0000_0001;
const IN_MODIFY: u32 = 0x0000_0002;
const IN_ATTRIB: u32 = 0x0000_0004;
const IN_CLOSE_WRITE: u32 = 0x0000_0008;
const IN_MOVED_FROM: u32 = 0x0000_0040;
const IN_MOVED_TO: u32 = 0x0000_0080;
const IN_CREATE: u32 = 0x0000_0100;
const IN_DELETE: u32 = 0x0000_0200;
const IN_DELETE_SELF: u32 = 0x0000_0400;
const IN_MOVE_SELF: u32 = 0x0000_0800;
const IN_IGNORED: u32 = 0x0000_8000;
const WATCH_MASK: u32 = IN_MODIFY
    | IN_ATTRIB
    | IN_CLOSE_WRITE
    | IN_MOVED_FROM
    | IN_MOVED_TO
    | IN_CREATE
    | IN_DELETE
    | IN_DELETE_SELF
    | IN_MOVE_SELF;

#[repr(C)]
struct PollFd {
    fd: c_int,
    events: i16,
    revents: i16,
}

extern "C" {
    fn inotify_init1(flags: c_int) -> c_int;
    fn inotify_add_watch(fd: c_int, pathname: *const c_char, mask: u32) -> c_int;
    fn read(fd: c_int, buf: *mut c_void, count: usize) -> isize;
    fn poll(fds: *mut PollFd, nfds: usize, timeout: c_int) -> c_int;
}

#[derive(Clone, Default)]
struct Opts {
    all_events: bool,
    clear_count: u8,
    dir_count: u8,
    non_interactive: bool,
    postpone: bool,
    reload: bool,
    shell: bool,
    status_count: u8,
    exit_after: bool,
}

struct Config {
    opts: Opts,
    cmd: Vec<String>,
}

#[derive(Clone)]
struct WatchPath {
    input: String,
    watch: String,
    is_dir_watch: bool,
}

struct EventInfo {
    path: Option<String>,
    dir_altered: bool,
}

fn usage_hint() {
    eprintln!("release: {}", RELEASE);
    eprintln!("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames");
    eprintln!("hint: use -h to display option summary");
}

fn usage_summary() {
    eprintln!("release: {}", RELEASE);
    eprintln!("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames");
    eprintln!("summary:");
    eprintln!("    -a  Do not consolidate events");
    eprintln!("    -c  Clear screen before execution");
    eprintln!("    -d  Track files added or removed from directories");
    eprintln!("    -n  Non-interactive mode");
    eprintln!("    -p  Wait for first event");
    eprintln!("    -r  Run as a background process, use signal to restart");
    eprintln!("    -s  Evaluate using a shell");
    eprintln!("    -x  Format exit status");
    eprintln!("    -z  Exit after the utility completes");
    eprintln!("docs:");
    eprintln!("    man entr");
}

fn parse_args() -> Result<Config, i32> {
    let mut opts = Opts::default();
    let mut idx = 1usize;
    let args: Vec<String> = env::args().collect();
    while idx < args.len() {
        let a = &args[idx];
        if a == "--" {
            idx += 1;
            break;
        }
        if !a.starts_with('-') || a == "-" {
            break;
        }
        if a.len() == 1 {
            break;
        }
        for ch in a[1..].chars() {
            match ch {
                'a' => opts.all_events = true,
                'c' => opts.clear_count = opts.clear_count.saturating_add(1),
                'd' => opts.dir_count = opts.dir_count.saturating_add(1),
                'n' => opts.non_interactive = true,
                'p' => opts.postpone = true,
                'r' => opts.reload = true,
                's' => opts.shell = true,
                'x' => opts.status_count = opts.status_count.saturating_add(1),
                'z' => opts.exit_after = true,
                'h' => {
                    usage_summary();
                    return Err(1);
                }
                bad => {
                    eprintln!("./executable: invalid option -- '{}'", bad);
                    usage_hint();
                    return Err(1);
                }
            }
        }
        idx += 1;
    }
    let cmd = args[idx..].to_vec();
    if cmd.is_empty() {
        usage_hint();
        return Err(1);
    }
    if opts.shell && cmd.len() != 1 {
        eprintln!("executable: -s requires commands to be formatted as a single argument");
        return Err(1);
    }
    Ok(Config { opts, cmd })
}

fn read_watch_paths(opts: &Opts) -> Vec<WatchPath> {
    let mut input = String::new();
    let _ = io::stdin().read_to_string(&mut input);
    let mut paths = Vec::new();
    for raw in input.lines() {
        if raw.is_empty() {
            continue;
        }
        match fs::metadata(raw) {
            Ok(md) => {
                paths.push(WatchPath {
                    input: raw.to_string(),
                    watch: raw.to_string(),
                    is_dir_watch: md.is_dir(),
                });
                if opts.dir_count > 0 && !md.is_dir() {
                    if let Some(parent) = Path::new(raw).parent() {
                        let p = if parent.as_os_str().is_empty() { "." } else { parent.to_str().unwrap_or(".") };
                        paths.push(WatchPath { input: raw.to_string(), watch: p.to_string(), is_dir_watch: true });
                    }
                }
            }
            Err(_) => eprintln!("executable: unable to stat '{}'", raw),
        }
    }
    paths
}

fn default_trigger(paths: &[WatchPath]) -> String {
    paths.first().map(|p| p.input.clone()).unwrap_or_default()
}

fn clear_screen(count: u8) {
    if count == 0 { return; }
    if count >= 2 { print!("\x1b[2J\x1b[3J\x1b[H"); }
    else { print!("\x1b[2J\x1b[H"); }
    let _ = io::stdout().flush();
}

fn status_code(st: ExitStatus) -> i32 {
    if let Some(c) = st.code() { c } else { st.signal().unwrap_or(1) + 128 }
}

fn maybe_create_status_script() {
    let path = env::var("ENTR_STATUS_SCRIPT").ok().map(PathBuf::from).unwrap_or_else(|| {
        let home = env::var("HOME").unwrap_or_else(|_| ".".into());
        Path::new(&home).join(".entr/status.awk")
    });
    if path.exists() { return; }
    if let Some(parent) = path.parent() { let _ = fs::create_dir_all(parent); }
    if let Ok(mut f) = OpenOptions::new().create_new(true).write(true).open(&path) {
        let _ = f.write_all(b"# http://eradman.com/entrproject/status-filters.html\n/^signal/ { print $3, \"terminated by signal\", $2; }\n/^exit/ { print $3, \"returned exit code\", $2; }\n");
        eprintln!("entr: created '{}'", path.display());
    }
}

fn build_command(cfg: &Config, trigger: &str) -> Command {
    if cfg.opts.shell {
        let shell = env::var("SHELL").unwrap_or_else(|_| "/bin/sh".into());
        let mut c = Command::new(shell);
        c.arg("-c").arg(&cfg.cmd[0]).arg(trigger);
        c.env("PAGER", env::var("PAGER").unwrap_or_else(|_| "/bin/cat".into()));
        c
    } else {
        let mut c = Command::new(&cfg.cmd[0]);
        for arg in cfg.cmd.iter().skip(1) {
            if arg == "/_" { c.arg(trigger); } else { c.arg(arg); }
        }
        c.env("PAGER", env::var("PAGER").unwrap_or_else(|_| "/bin/cat".into()));
        c
    }
}

fn run_once(cfg: &Config, trigger: &str) -> i32 {
    if cfg.opts.status_count > 0 { maybe_create_status_script(); }
    clear_screen(cfg.opts.clear_count);
    let mut cmd = build_command(cfg, trigger);
    match cmd.status() {
        Ok(st) => {
            let code = status_code(st);
            if cfg.opts.status_count >= 2 && code != 0 {
                let name = if cfg.opts.shell { cfg.cmd[0].as_str() } else { cfg.cmd[0].as_str() };
                if code >= 128 { println!("{} terminated by signal {}", name, code - 128); }
                else { println!("{} returned exit code {}", name, code); }
            }
            code
        }
        Err(e) => {
            eprintln!("executable: {}: {}", cfg.cmd[0], e);
            1
        }
    }
}

fn spawn_child(cfg: &Config, trigger: &str) -> Option<Child> {
    if cfg.opts.status_count > 0 { maybe_create_status_script(); }
    clear_screen(cfg.opts.clear_count);
    match build_command(cfg, trigger).spawn() {
        Ok(ch) => Some(ch),
        Err(e) => { eprintln!("executable: {}: {}", cfg.cmd[0], e); None }
    }
}

fn setup_inotify(paths: &[WatchPath]) -> io::Result<(c_int, HashMap<c_int, WatchPath>)> {
    unsafe {
        let fd = inotify_init1(IN_NONBLOCK_FLAG() | IN_CLOEXEC);
        if fd < 0 { return Err(io::Error::last_os_error()); }
        let mut map = HashMap::new();
        for wp in paths {
            if let Ok(cpath) = CString::new(wp.watch.as_str()) {
                let wd = inotify_add_watch(fd, cpath.as_ptr(), WATCH_MASK);
                if wd >= 0 { map.insert(wd, wp.clone()); }
            }
        }
        Ok((fd, map))
    }
}

#[allow(non_snake_case)]
const fn IN_NONBLOCK_FLAG() -> c_int { O_NONBLOCK }

fn read_events(fd: c_int, watches: &HashMap<c_int, WatchPath>, opts: &Opts) -> Vec<EventInfo> {
    let mut out = Vec::new();
    let mut buf = vec![0u8; 16384];
    loop {
        let n = unsafe { read(fd, buf.as_mut_ptr() as *mut c_void, buf.len()) };
        if n <= 0 { break; }
        let mut off = 0usize;
        while off + 16 <= n as usize {
            let wd = i32::from_ne_bytes(buf[off..off+4].try_into().unwrap());
            let mask = u32::from_ne_bytes(buf[off+4..off+8].try_into().unwrap());
            let len = u32::from_ne_bytes(buf[off+12..off+16].try_into().unwrap()) as usize;
            let name = if len > 0 && off + 16 + len <= n as usize {
                let bytes = &buf[off+16..off+16+len];
                let end = bytes.iter().position(|&b| b == 0).unwrap_or(bytes.len());
                String::from_utf8_lossy(&bytes[..end]).to_string()
            } else { String::new() };
            if let Some(wp) = watches.get(&wd) {
                let create_delete = (mask & (IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO)) != 0;
                let ignored_self = (mask & (IN_IGNORED | IN_DELETE_SELF | IN_MOVE_SELF)) != 0;
                let hidden = name.starts_with('.');
                let dir_altered = wp.is_dir_watch && create_delete && (opts.dir_count > 1 || !hidden);
                let path = if !name.is_empty() {
                    Some(Path::new(&wp.watch).join(&name).to_string_lossy().to_string())
                } else {
                    Some(wp.input.clone())
                };
                if (mask & IN_ACCESS) == 0 || create_delete || ignored_self {
                    out.push(EventInfo { path, dir_altered });
                }
            }
            off += 16 + len;
        }
    }
    out
}

fn wait_for_events(fd: c_int, watches: &HashMap<c_int, WatchPath>, opts: &Opts) -> Vec<EventInfo> {
    loop {
        let mut pfd = PollFd { fd, events: POLLIN, revents: 0 };
        let rc = unsafe { poll(&mut pfd as *mut PollFd, 1, 250) };
        if rc > 0 && (pfd.revents & POLLIN) != 0 {
            let events = read_events(fd, watches, opts);
            if !events.is_empty() { return events; }
        }
    }
}

fn main() {
    let cfg = match parse_args() { Ok(c) => c, Err(code) => std::process::exit(code) };
    let paths = read_watch_paths(&cfg.opts);
    if paths.is_empty() {
        eprintln!("executable: No regular files to watch");
        std::process::exit(1);
    }
    let trigger_default = default_trigger(&paths);

    if !cfg.opts.postpone && !cfg.opts.reload {
        let code = run_once(&cfg, &trigger_default);
        if cfg.opts.exit_after { std::process::exit(code); }
    } else if !cfg.opts.postpone && cfg.opts.reload {
        let mut child = spawn_child(&cfg, &trigger_default);
        if cfg.opts.exit_after {
            if let Some(mut ch) = child.take() {
                match ch.wait() { Ok(st) => std::process::exit(status_code(st)), Err(_) => std::process::exit(1) }
            }
        }
        let _ = child;
    }

    let (fd, watches) = match setup_inotify(&paths) {
        Ok(v) => v,
        Err(e) => { eprintln!("executable: {}", e); std::process::exit(1); }
    };
    let _ = read_events(fd, &watches, &cfg.opts);
    let mut child: Option<Child> = None;
    if cfg.opts.reload && !cfg.opts.postpone { child = spawn_child(&cfg, &trigger_default); }

    loop {
        if cfg.opts.reload {
            if let Some(ch) = child.as_mut() {
                if let Ok(Some(_)) = ch.try_wait() { child = None; }
            }
        }
        let events = wait_for_events(fd, &watches, &cfg.opts);
        if events.iter().any(|e| e.dir_altered) {
            eprintln!("executable: directory altered");
            std::process::exit(2);
        }
        let trigger = events.iter().find_map(|e| e.path.clone()).unwrap_or_else(|| trigger_default.clone());
        if cfg.opts.reload {
            if let Some(mut ch) = child.take() {
                let _ = ch.kill();
                let _ = ch.wait();
            }
            child = spawn_child(&cfg, &trigger);
            if cfg.opts.exit_after {
                if let Some(mut ch) = child.take() {
                    match ch.wait() { Ok(st) => std::process::exit(status_code(st)), Err(_) => std::process::exit(1) }
                }
            }
        } else {
            let code = run_once(&cfg, &trigger);
            if cfg.opts.exit_after { std::process::exit(code); }
            if !cfg.opts.all_events { std::thread::sleep(Duration::from_millis(50)); let _ = read_events(fd, &watches, &cfg.opts); }
        }
    }
}
