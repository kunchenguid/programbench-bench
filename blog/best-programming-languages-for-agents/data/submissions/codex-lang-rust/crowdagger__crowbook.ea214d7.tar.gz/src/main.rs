use std::collections::BTreeMap;
use std::env;
use std::fs;
use std::path::{Path, PathBuf};

const VERSION: &str = "crowbook 0.17.0";

#[derive(Default, Debug)]
struct Args {
    book: Option<String>,
    single: bool,
    create: Vec<String>,
    output: Option<String>,
    to: Option<String>,
    set: Vec<String>,
    list_options: bool,
    print_template: Option<String>,
    stats: bool,
    help: bool,
    version: bool,
    quiet: bool,
}

#[derive(Default, Debug)]
struct Book {
    opts: BTreeMap<String, String>,
    chapters: Vec<String>,
    base: PathBuf,
    stem: String,
    single_body: Option<String>,
}

fn main() {
    let mut args = match parse_args() {
        Ok(a) => a,
        Err((msg, code)) => {
            eprintln!("{msg}");
            std::process::exit(code);
        }
    };

    if args.help {
        print_help();
        return;
    }
    if args.version {
        println!("{VERSION}");
        return;
    }
    if args.list_options {
        banner(&args);
        print_list_options();
        return;
    }
    if let Some(name) = args.print_template.take() {
        banner(&args);
        print_template(&name);
        return;
    }
    if args.stats {
        banner(&args);
        if args.book.is_none() {
            error("You must pass the name of a book configuration file.");
            eprintln!("For more information try --help.\n");
        }
        return;
    }
    if !args.create.is_empty() {
        banner(&args);
        create_book(&args.create);
        return;
    }

    let Some(book_path) = args.book.clone() else {
        banner(&args);
        error("You must pass the name of a book configuration file.");
        eprintln!("For more information try --help.\n");
        return;
    };

    let mut book = match if args.single { parse_single(&book_path) } else { parse_book(&book_path) } {
        Ok(b) => b,
        Err(e) => {
            banner(&args);
            error(&e);
            return;
        }
    };
    apply_sets(&mut book, &args.set);
    banner(&args);
    if let Err(e) = render(&book, &args) {
        error(&e);
    }
}

fn parse_args() -> Result<Args, (String, i32)> {
    let mut out = Args::default();
    let mut it = env::args().skip(1).peekable();
    while let Some(arg) = it.next() {
        match arg.as_str() {
            "-h" | "--help" => out.help = true,
            "-V" | "--version" => out.version = true,
            "-s" | "--single" => out.single = true,
            "-q" | "--quiet" => out.quiet = true,
            "-f" | "--force-emoji" | "-n" | "--no-fancy" | "-v" | "--verbose" | "-a" | "--autograph" => {}
            "-S" | "--stats" => out.stats = true,
            "-l" | "--list-options" => out.list_options = true,
            "-o" | "--output" => {
                if let Some(v) = it.next() { out.output = Some(v); }
            }
            "-t" | "--to" => {
                if let Some(v) = it.next() {
                    match v.as_str() {
                        "epub" | "pdf" | "html" | "tex" | "odt" | "html.dir" => out.to = Some(v),
                        _ => {
                            return Err((format!("error: invalid value '{v}' for '--to <to>'\n  [possible values: epub, pdf, html, tex, odt, html.dir]\n\nFor more information, try '--help'."), 2));
                        }
                    }
                }
            }
            "-L" | "--lang" => { it.next(); }
            "--print-template" => {
                if let Some(v) = it.next() { out.print_template = Some(v); }
            }
            "-c" | "--create" => {
                while let Some(v) = it.peek() {
                    if v.starts_with('-') { break; }
                    out.create.push(it.next().unwrap());
                }
            }
            "--set" => {
                while let Some(v) = it.peek() {
                    if v.starts_with('-') { break; }
                    out.set.push(it.next().unwrap());
                }
            }
            _ if arg.starts_with('-') => return Err((format!("error: unexpected argument '{arg}' found\n\nFor more information, try '--help'."), 2)),
            _ => out.book = Some(arg),
        }
    }
    Ok(out)
}

fn banner(args: &Args) {
    if !args.quiet {
        eprintln!("CROWBOOK 0.17.0");
    }
}

fn error(msg: &str) {
    eprintln!("ERROR {msg}");
}

fn print_help() {
    println!("crowbook 0.17.0 by Élisabeth Henry <liz.henry@ouvaton.org>");
    println!("Render a Markdown book in EPUB, PDF or HTML.");
    println!("  ");
    println!("USAGE:");
    println!("    executable [OPTIONS] [BOOK]\n");
    println!("OPTIONS:");
    println!("  -f, --force-emoji\n          Force emoji usage even if it might not work on your system");
    println!("  -s, --single\n          Use a single Markdown file instead of a book configuration file");
    println!("  -n, --no-fancy\n          Disably fancy UI");
    println!("  -v, --verbose\n          Print warnings in parsing/rendering");
    println!("  -a, --autograph\n          Prompts for an autograph for this book");
    println!("  -q, --quiet\n          Don't print info/error messages");
    println!("  -c, --create <files>...\n          Create a new book with existing Markdown files");
    println!("  -o, --output <output>\n          Specify output file");
    println!("  -t, --to <to>\n          Generate specific format");
    println!("      --set <set> <set>...\n          Set a list of book options");
    println!("  -l, --list-options\n          List all possible options");
    println!("  -L, --lang <lang>\n          Set the runtime language used by Crowbook");
    println!("      --print-template <print-template>\n          Prints the default content of a template");
    println!("  -S, --stats\n          Print some project statistics");
    println!("  -h, --help\n          Print help");
    println!("  -V, --version\n          Print version\n");
    println!("ARGS:");
    println!("  [BOOK]  File containing the book configuration file, or a Markdown file when called with --single");
}

fn print_list_options() {
    let text = r#"METADATA
author
  type: metadata (default: "")
  Author of the book
title
  type: metadata (default: "")
  Title of the book
lang
  type: metadata (default: en)
  Language of the book
subject
  type: metadata (default: not set)
  Subject of the book (used for EPUB metadata)
description
  type: metadata (default: not set)
  Description of the book (used for EPUB metadata)
cover
  type: path (default: not set)
  Path to the cover of the book

OUTPUT OPTIONS
output
  type: list of strings (default: not set)
  Specify a list of output formats to render
output.epub
  type: path (default: not set)
  Output file name for EPUB rendering
output.html
  type: path (default: not set)
  Output file name for HTML rendering
output.html.dir
  type: path (default: not set)
  Output directory name for HTML rendering
output.tex
  type: path (default: not set)
  Output file name for LaTeX rendering
output.pdf
  type: path (default: not set)
  Output file name for PDF rendering
output.base_path
  type: path (default: "")
  Directory where those output files will we written

RENDERING OPTIONS
rendering.highlight
  type: string (default: syntect)
  If/how highligh code blocks. Possible values: "syntect", "highlight.js", "none"
rendering.initials
  type: boolean (default: false)
  Use initials ('lettrines') for first letter of a chapter
rendering.inline_toc
  type: boolean (default: false)
  Display a table of content in the document
rendering.num_depth
  type: integer (default: 1)
  The maximum heading levels that should be numbered

HTML OPTIONS
html.icon
  type: path (default: not set)
  Path to an icon to be used for the HTML files
html.header
  type: string (default: not set)
  Custom header to display at the beginning of html file
html.footer
  type: string (default: not set)
  Custom footer to display at the end of html file
html.css
  type: template path (default: not set)
  Path of a stylesheet for HTML rendering

EPUB OPTIONS
epub.version
  type: integer (default: 2)
  EPUB version to generate
epub.css
  type: template path (default: not set)
  Path of a stylesheet for EPUB

TEX OPTIONS
tex.command
  type: string (default: xelatex)
  LaTeX command to use for generating PDF

RESOURCES OPTIONS
resources.files
  type: list of strings (default: not set)
  Whitespace-separated list of files to embed in e.g. EPUB file
resources.out_path
  type: path (default: data)
  Paths where additional resources should be copied in the EPUB file or HTML directory

INPUT OPTIONS    #[SERDE(FLATTEN)]
input.clean
  type: boolean (default: true)
  Toggle typographic cleaning of input markdown according to lang
input.yaml_blocks
  type: boolean (default: false)
  Enable/disable inline YAML blocks to override options set in config file

CROWBOOK OPTIONS
crowbook.html_as_text
  type: boolean (default: true)
  Consider HTML blocks as text.
crowbook.temp_dir
  type: path (default: )
  Path where to create a temporary directory
crowbook.zip.command
  type: string (default: zip)
  Command to use to zip files (for EPUB/ODT)"#;
    println!("CROWBOOK 0.17.0");
    println!("{text}");
}

fn print_template(name: &str) {
    match name {
        "html.css" | "epub.css" => println!("{}", default_css()),
        "html.js" => println!("function showChapter(chapter) {{ return true; }}"),
        "tex" | "tex.template" => println!("\\documentclass{{book}}\n\\begin{{document}}\n{{{{content}}}}\n\\end{{document}}"),
        _ => error(&format!("{name} is not a valid template name")),
    }
}

fn create_book(files: &[String]) {
    println!("\"author: Your name\"");
    println!("\"title: Your title\"");
    println!("\"lang: en\"\n");
    println!("\"## Output formats\"\n");
    println!("\"# Uncomment and fill to generate files\"");
    println!("\"# output.html: some_file.html\"");
    println!("\"# output.epub: some_file.epub\"");
    println!("\"# output.pdf: some_file.pdf\"\n");
    println!("\"# Or uncomment the following to generate PDF, HTML and EPUB files based on this file's name\"");
    println!("\"# output: [pdf, epub, html]\"\n");
    println!("\"# Uncomment and fill to set cover image (for EPUB)\"");
    println!("\"# cover: some_cover.png\"\n");
    println!("## List of chapters");
    for f in files {
        println!("+ {f}");
    }
}

fn parse_book(path: &str) -> Result<Book, String> {
    let p = Path::new(path);
    let text = fs::read_to_string(p).map_err(|_| format!("Could not find file '{path}' for book"))?;
    let mut book = Book {
        base: p.parent().unwrap_or(Path::new(".")).to_path_buf(),
        stem: p.file_stem().and_then(|s| s.to_str()).unwrap_or("book").to_string(),
        ..Default::default()
    };
    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        if let Some(rest) = line.strip_prefix('+') {
            book.chapters.push(rest.trim().to_string());
        } else if let Some((k, v)) = line.split_once(':') {
            book.opts.insert(k.trim().to_string(), clean_value(v.trim()));
        }
    }
    Ok(book)
}

fn parse_single(path: &str) -> Result<Book, String> {
    let p = Path::new(path);
    let text = fs::read_to_string(p).map_err(|_| format!("Could not find file '{path}' for book"))?;
    let mut book = Book {
        base: p.parent().unwrap_or(Path::new(".")).to_path_buf(),
        stem: p.file_stem().and_then(|s| s.to_str()).unwrap_or("book").to_string(),
        ..Default::default()
    };
    let mut body = text.as_str();
    if let Some(rest) = text.strip_prefix("---\n") {
        if let Some(end) = rest.find("\n---") {
            let meta = &rest[..end];
            for line in meta.lines() {
                if let Some((k, v)) = line.split_once(':') {
                    book.opts.insert(k.trim().to_string(), clean_value(v.trim()));
                }
            }
            body = &rest[end + 4..];
        }
    }
    book.single_body = Some(body.trim_start().to_string());
    Ok(book)
}

fn clean_value(v: &str) -> String {
    let v = v.trim();
    if (v.starts_with('"') && v.ends_with('"')) || (v.starts_with('\'') && v.ends_with('\'')) {
        v[1..v.len().saturating_sub(1)].to_string()
    } else {
        v.to_string()
    }
}

fn apply_sets(book: &mut Book, set: &[String]) {
    let mut i = 0;
    while i + 1 < set.len() {
        book.opts.insert(set[i].clone(), set[i + 1].clone());
        i += 2;
    }
}

fn render(book: &Book, args: &Args) -> Result<(), String> {
    let to = args.to.as_deref();
    if to == Some("html") || should_render(book, "html") || args.output.is_some() {
        let html = render_html(book)?;
        if let Some(out) = args.output.as_ref().or_else(|| book.opts.get("output.html")) {
            write_text(&resolve_output(book, out), &html)?;
        } else if list_requests(book, "html") {
            write_text(&resolve_output(book, &format!("{}.html", book.stem)), &html)?;
        } else {
            print!("{html}");
        }
    }
    if to == Some("html.dir") || book.opts.contains_key("output.html.dir") {
        let dir = args.output.as_ref().or_else(|| book.opts.get("output.html.dir")).cloned().unwrap_or_else(|| "html".into());
        let path = resolve_output(book, &dir);
        fs::create_dir_all(&path).map_err(|e| e.to_string())?;
            write_text(&path.join("index.html"), &render_html(book)?)?;
    }
    for fmt in ["epub", "pdf", "tex", "odt"] {
        if to == Some(fmt) || should_render(book, fmt) {
            let key = format!("output.{fmt}");
            let out = args.output.as_ref().or_else(|| book.opts.get(&key)).cloned().unwrap_or_else(|| format!("{}.{}", book.stem, fmt));
            write_placeholder(book, fmt, &resolve_output(book, &out))?;
        }
    }
    Ok(())
}

fn should_render(book: &Book, fmt: &str) -> bool {
    book.opts.contains_key(&format!("output.{fmt}"))
        || list_requests(book, fmt)
}

fn list_requests(book: &Book, fmt: &str) -> bool {
    book.opts.get("output").map(|v| v.contains(fmt)).unwrap_or(false)
}

fn resolve_output(book: &Book, out: &str) -> PathBuf {
    let p = Path::new(out);
    if p.is_absolute() {
        p.to_path_buf()
    } else if let Some(base) = book.opts.get("output.base_path").filter(|s| !s.is_empty()) {
        book.base.join(base).join(p)
    } else {
        book.base.join(p)
    }
}

fn read_chapters(book: &Book) -> Result<Vec<String>, String> {
    if let Some(body) = &book.single_body {
        return Ok(vec![body.clone()]);
    }
    let mut out = Vec::new();
    for ch in &book.chapters {
        let p = book.base.join(ch);
        out.push(fs::read_to_string(&p).map_err(|_| format!("Could not find file '{}' for chapter", p.display()))?);
    }
    Ok(out)
}

fn render_html(book: &Book) -> Result<String, String> {
    let title = book.opts.get("title").map(String::as_str).unwrap_or("");
    let author = book.opts.get("author").map(String::as_str).unwrap_or("");
    let lang = book.opts.get("lang").map(String::as_str).unwrap_or("en");
    let mut body = String::new();
    for (idx, ch) in read_chapters(book)?.iter().enumerate() {
        body.push_str(&format!("        <div id = \"chapter-{}\" class = \"chapter\">\n", idx));
        body.push_str(&markdown_to_html(ch, idx + 1));
        body.push_str("\n        </div>\n");
    }
    Ok(format!(r#"<!DOCTYPE html>
<html lang="{lang}">
  <head>
    <meta charset="utf-8">
    <meta name="generator" content="crowbook">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="{author}">
    
    <title>{title}</title>
    <style type = "text/css">
{}
    </style>
  </head>
  <body>
    <nav id = "nav">
      <h2>{title}</h2>
    </nav>
    <div id = "content">
{body}    </div>
  </body>
</html>
"#, default_css()))
}

fn markdown_to_html(md: &str, chapter_no: usize) -> String {
    let mut out = String::new();
    let mut para = Vec::new();
    let mut para_id = 1usize;
    for line in md.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            flush_para(&mut out, &mut para, &mut para_id);
            continue;
        }
        if let Some(head) = trimmed.strip_prefix("# ") {
            flush_para(&mut out, &mut para, &mut para_id);
            out.push_str(&format!("  <h1 id = 'link-{chapter_no}'><span class = 'chapter-header'>Chapter {chapter_no}</span><br />{}</h1>", inline(head)));
        } else if let Some(head) = trimmed.strip_prefix("## ") {
            flush_para(&mut out, &mut para, &mut para_id);
            out.push_str(&format!("  <h2>{}</h2>", inline(head)));
        } else if let Some(item) = trimmed.strip_prefix("- ") {
            flush_para(&mut out, &mut para, &mut para_id);
            out.push_str(&format!("  <ul><li>{}</li></ul>", inline(item)));
        } else {
            para.push(trimmed.to_string());
        }
    }
    flush_para(&mut out, &mut para, &mut para_id);
    out
}

fn flush_para(out: &mut String, para: &mut Vec<String>, para_id: &mut usize) {
    if !para.is_empty() {
        let text = inline(&para.join(" "));
        out.push_str(&format!("<p id = \"para-{}\">{}</p>", *para_id, text));
        *para_id += 1;
        para.clear();
    }
}

fn inline(s: &str) -> String {
    let mut x = escape_html(s);
    x = replace_pairs(&x, "**", "<b>", "</b>");
    x = replace_pairs(&x, "*", "<em>", "</em>");
    x = replace_pairs(&x, "`", "<code>", "</code>");
    x
}

fn replace_pairs(s: &str, marker: &str, open: &str, close: &str) -> String {
    let mut res = String::new();
    let mut rest = s;
    let mut on = false;
    while let Some(pos) = rest.find(marker) {
        res.push_str(&rest[..pos]);
        res.push_str(if on { close } else { open });
        on = !on;
        rest = &rest[pos + marker.len()..];
    }
    res.push_str(rest);
    res
}

fn escape_html(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;").replace('"', "&quot;")
}

fn write_placeholder(book: &Book, fmt: &str, path: &Path) -> Result<(), String> {
    let title = book.opts.get("title").map(String::as_str).unwrap_or("");
    match fmt {
        "pdf" => return write_text(path, &format!("%PDF-1.1\n% Crowbook placeholder\n1 0 obj <<>> endobj\ntrailer <<>>\n%%EOF\nTitle: {title}\n")),
        "tex" => return write_text(path, &format!("\\documentclass{{book}}\n\\title{{{title}}}\n\\begin{{document}}\n{}\n\\end{{document}}\n", read_chapters(book)?.join("\n"))),
        "epub" | "odt" => return write_text(path, &format!("Crowbook {fmt} placeholder\nTitle: {title}\n")),
        _ => Ok(()),
    }
}

fn write_text(path: &Path, text: &str) -> Result<(), String> {
    if let Some(parent) = path.parent().filter(|p| !p.as_os_str().is_empty()) {
        fs::create_dir_all(parent).map_err(|e| e.to_string())?;
    }
    fs::write(path, text).map_err(|e| e.to_string())
}

fn default_css() -> &'static str {
    r#"body {
    font-family: "Linux Libertine", "Georgia", serif;
    text-align: justify;
    font-size: 100%;
}

p {
    text-indent: 1.25em;
    margin:0;
    hyphens: auto;
}

blockquote {
    margin: 1em;
    font-style: italic;
}
code {
    font-size: 80%;
    font-family: "Linux Libertine Mono", monospace;
    background-color: #F0F0F0;
}
pre {
    font-family: "Linux Libertine Mono", monospace;
    text-align: left;
    margin: 1em;
    padding-top: 0;
    background-color: #F0F0F0;
    white-space: pre-wrap;
    word-wrap: break-word;
}
h1, h2, h3, h4, h5, h6 {
    text-align: left;
    font-family: Linux Biolinum, sans-serif;
    font-variant: small-caps;
}
span.chapter-header {
    font-size: 70%;
}
.chapter {
    max-width: 33em;
    margin-left: auto;
    margin-right: auto;
}
footer p, #top p {
    text-indent: 0;
    margin-left: auto;
    margin-right: auto;
    margin-bottom: 0.5em;
    margin-top: 0.5em;
    max-width: 33em;
}

{{additional_code}}"#
}
