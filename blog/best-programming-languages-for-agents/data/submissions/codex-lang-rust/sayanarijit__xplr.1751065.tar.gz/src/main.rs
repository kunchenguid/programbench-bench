use std::env;
use std::fs::OpenOptions;
use std::io::{self, Read, Write};
use std::path::{Path, PathBuf};
use std::process;

const VERSION: &str = "xplr 1.1.0";
const HELP: &str = "xplr 1.1.0
Arijit Basu <hi@arijitbasu.in>
A hackable, minimal, fast TUI file explorer

USAGE:
    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...

FLAGS:
  -                            Reads new-line (\\n) separated paths from stdin
  --                           Denotes the end of command-line flags and options
      --force-focus            Focuses on the given <PATH>, even if it is a directory
  -h, --help                   Prints help information
  -m, --pipe-msg-in            Helps safely passing messages to the active xplr
                                 session, use %%, %s and %q as the placeholders
  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of
                                 passing to the active xplr session
      --print-pwd-as-result    Prints the present working directory when quitting
                                 with `PrintResultAndQuit`
      --read-only              Enables read-only mode (config.general.read_only)
      --read0                  Reads paths separated using the null character (\\0)
      --write0                 Prints paths separated using the null character (\\0)
  -0  --null                   Combines --read0 and --write0
  -V, --version                Prints version information

OPTIONS:
  -c, --config <PATH>             Specifies a custom config file (default is
                                    \"$HOME/.config/xplr/init.lua\")
  -C, --extra-config <PATH>...    Specifies extra config files to load
      --on-load <MESSAGE>...      Sends messages when xplr loads
      --vroot <PATH>              Treats the specified path as the virtual root

ARGS:
  <PATH>            Path to focus on, or enter if directory, (default is `.`)
  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly
";

#[derive(Default)]
struct Opts {
    read_stdin: bool,
    read0: bool,
    write0: bool,
    force_focus: bool,
    print_pwd_as_result: bool,
    on_load: Vec<String>,
    path: Option<String>,
    selections: Vec<String>,
}

fn main() {
    if let Err(code) = run() {
        process::exit(code);
    }
}

fn run() -> Result<(), i32> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    if args.iter().any(|a| a == "-h" || a == "--help") {
        print!("{HELP}");
        return Ok(());
    }
    if args.iter().any(|a| a == "-V" || a == "--version") {
        println!("{VERSION}");
        return Ok(());
    }

    if let Some(pos) = args.iter().position(|a| a == "-M" || a == "--print-msg-in") {
        if pos + 1 >= args.len() {
            eprintln!("error: usage: xplr -M FORMAT [ARGUMENT]...");
            return Err(1);
        }
        let fmt = args.remove(pos + 1);
        args.remove(pos);
        match render_msg(&fmt, &args[pos..]) {
            Ok(msg) => print!("{msg}"),
            Err(e) => {
                eprintln!("error: {e}");
                return Err(1);
            }
        }
        return Ok(());
    }

    if let Some(pos) = args.iter().position(|a| a == "-m" || a == "--pipe-msg-in") {
        if pos + 1 >= args.len() {
            eprintln!("error: usage: xplr -m FORMAT [ARGUMENT]...");
            return Err(1);
        }
        let fmt = args.remove(pos + 1);
        args.remove(pos);
        let msg = match render_msg(&fmt, &args[pos..]) {
            Ok(m) => m,
            Err(e) => {
                eprintln!("error: {e}");
                return Err(1);
            }
        };
        let pipe = match env::var("XPLR_PIPE_MSG_IN") {
            Ok(p) => p,
            Err(e) => {
                eprintln!("error: {e}");
                return Err(1);
            }
        };
        if let Err(e) = OpenOptions::new().append(true).create(true).open(&pipe)
            .and_then(|mut f| f.write_all(msg.as_bytes()))
        {
            eprintln!("error: {e}");
            return Err(1);
        }
        return Ok(());
    }

    let opts = match parse_args(&args) {
        Ok(o) => o,
        Err(e) => {
            eprintln!("error: {e}");
            return Err(1);
        }
    };

    if let Err(e) = validate_paths(&opts) {
        eprintln!("error: {e}");
        return Err(1);
    }

    let mut selections = opts.selections.clone();
    if opts.read_stdin || opts.read0 {
        selections.extend(read_paths(opts.read0));
    }

    if !opts.on_load.is_empty() {
        return handle_on_load(&opts, &selections);
    }

    eprintln!("error: No such device or address (os error 6)");
    Err(1)
}

fn parse_args(args: &[String]) -> Result<Opts, String> {
    let mut opts = Opts::default();
    let mut positional = false;
    let mut i = 0;
    while i < args.len() {
        let a = &args[i];
        if !positional && a == "--" {
            positional = true;
            i += 1;
            continue;
        }
        if !positional && a == "-" {
            opts.read_stdin = true;
        } else if !positional && a == "--force-focus" {
            opts.force_focus = true;
        } else if !positional && a == "--print-pwd-as-result" {
            opts.print_pwd_as_result = true;
        } else if !positional && a == "--read-only" {
        } else if !positional && a == "--read0" {
            opts.read0 = true;
        } else if !positional && a == "--write0" {
            opts.write0 = true;
        } else if !positional && (a == "-0" || a == "--null") {
            opts.read0 = true;
            opts.write0 = true;
        } else if !positional && (a == "-c" || a == "--config" || a == "--vroot") {
            if i + 1 >= args.len() {
                return Err(format!("usage: xplr {} PATH", a));
            }
            let p = abs(&args[i + 1]);
            if !p.exists() {
                return Err(format!("path doesn't exist: {}", p.display()));
            }
            i += 1;
        } else if !positional && (a == "-C" || a == "--extra-config") {
            if i + 1 >= args.len() {
                return Err("No such device or address (os error 6)".into());
            }
            let p = abs(&args[i + 1]);
            if !p.exists() {
                return Err(format!("path doesn't exist: {}", p.display()));
            }
            i += 1;
        } else if !positional && a == "--on-load" {
            if i + 1 >= args.len() {
                return Err("No such device or address (os error 6)".into());
            }
            opts.on_load.push(args[i + 1].clone());
            i += 1;
        } else if !positional && a.starts_with('-') {
            return Err(format!("invalid argument: \"{}\", try `-- \"{}\"` or `--help`", a, a));
        } else if opts.path.is_none() {
            opts.path = Some(a.clone());
        } else {
            opts.selections.push(a.clone());
        }
        i += 1;
    }
    Ok(opts)
}

fn validate_paths(opts: &Opts) -> Result<(), String> {
    if let Some(p) = &opts.path {
        let ap = abs(p);
        if !ap.exists() {
            return Err(format!("path doesn't exist: {}", ap.display()));
        }
    }
    for s in &opts.selections {
        let ap = abs(s);
        if !ap.exists() {
            return Err(format!("path doesn't exist: {}", ap.display()));
        }
    }
    Ok(())
}

fn handle_on_load(opts: &Opts, selections: &[String]) -> Result<(), i32> {
    let sep = if opts.write0 { "\0" } else { "\n" };
    for msg in &opts.on_load {
        match msg.as_str() {
            "Quit" | "Terminate" => return Ok(()),
            "PrintPwdAndQuit" => {
                print!("{}{}", env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).display(), sep);
                return Ok(());
            }
            "PrintFocusPathAndQuit" => {
                print!("{}{}", focus_path(opts).display(), sep);
                return Ok(());
            }
            "PrintSelectionAndQuit" => {
                for s in selections {
                    print!("{}{}", abs(s).display(), sep);
                }
                return Ok(());
            }
            "PrintResultAndQuit" => {
                if opts.print_pwd_as_result {
                    print!("{}{}", env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).display(), sep);
                } else if !selections.is_empty() {
                    for s in selections {
                        print!("{}{}", abs(s).display(), sep);
                    }
                } else {
                    print!("{}{}", focus_path(opts).display(), sep);
                }
                return Ok(());
            }
            _ => {}
        }
    }
    eprintln!("error: No such device or address (os error 6)");
    Err(1)
}

fn focus_path(opts: &Opts) -> PathBuf {
    let p = opts.path.as_deref().unwrap_or(".");
    let ap = abs(p);
    if !opts.force_focus && ap.is_dir() {
        ap
    } else {
        ap
    }
}

fn abs(p: &str) -> PathBuf {
    let path = Path::new(p);
    if path.is_absolute() {
        path.to_path_buf()
    } else {
        env::current_dir().unwrap_or_else(|_| PathBuf::from(".")).join(path)
    }
}

fn read_paths(null_sep: bool) -> Vec<String> {
    let mut buf = Vec::new();
    let _ = io::stdin().read_to_end(&mut buf);
    let sep = if null_sep { 0 } else { b'\n' };
    buf.split(|b| *b == sep)
        .filter(|s| !s.is_empty())
        .map(|s| String::from_utf8_lossy(s).into_owned())
        .collect()
}

fn render_msg(fmt: &str, vals: &[String]) -> Result<String, String> {
    let mut out = String::new();
    let mut used = 0usize;
    let mut chars = fmt.chars().peekable();
    while let Some(c) = chars.next() {
        if c != '%' {
            out.push(c);
            continue;
        }
        let Some(n) = chars.next() else {
            return Err("xplr -m: invalid placeholder '%' at column 1, use one of '%s' or '%q', or escape it using '%%'".into());
        };
        match n {
            '%' => out.push('%'),
            's' => {
                let v = vals.get(used).ok_or_else(|| "xplr -m: not enough positional values".to_string())?;
                out.push_str(v);
                used += 1;
            }
            'q' => {
                let v = vals.get(used).ok_or_else(|| "xplr -m: not enough positional values".to_string())?;
                out.push_str(&json_quote(v));
                used += 1;
            }
            other => return Err(format!("xplr -m: invalid placeholder '%{}' at column 1, use one of '%s' or '%q', or escape it using '%%'", other)),
        }
    }
    if used < vals.len() {
        return Err("xplr -m: too many positional values, not enough positional placeholders".into());
    }
    yamlish_to_json(&out)
}

fn yamlish_to_json(s: &str) -> Result<String, String> {
    let t = s.trim();
    if t.is_empty() {
        return Err("xplr -m: yaml: did not find expected node content".into());
    }
    if !t.contains(':') {
        return Ok(json_quote(t));
    }
    let mut parts = t.splitn(2, ':');
    let key = parts.next().unwrap().trim();
    let val = parts.next().unwrap().trim();
    if key.is_empty() {
        return Err("xplr -m: yaml: did not find expected key".into());
    }
    let value = if val.starts_with('"') && val.ends_with('"') {
        val.to_string()
    } else {
        json_quote(val)
    };
    Ok(format!("{{{}:{}}}", json_quote(key), value))
}

fn json_quote(s: &str) -> String {
    let mut out = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c.is_control() => out.push_str(&format!("\\u{:04x}", c as u32)),
            c => out.push(c),
        }
    }
    out.push('"');
    out
}
