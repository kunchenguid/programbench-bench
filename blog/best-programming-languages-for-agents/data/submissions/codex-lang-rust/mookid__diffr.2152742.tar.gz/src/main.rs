use std::env;
use std::io::{self, Read, Write};

const RESET: &str = "\x1b[0m";

const LONG_HELP: &str = r#"diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...
            Configure color settings for console ouput.

            There are four faces to customize:
            +----------------+--------------+----------------+
            |  line prefix   |      +       |       -        |
            +----------------+--------------+----------------+
            | common segment |    added     |    removed     |
            | unique segment | refine-added | refine-removed |
            +----------------+--------------+----------------+

            The customization allows
            - to change the foreground or background color;
            - to set or unset the attributes 'bold', 'intense', 'underline';
            - to clear all attributes.

            Customization is done passing a color_spec argument.
            This flag may be provided multiple times.

            The syntax is the following:

            color_spec = face-name + ':' + attributes
            attributes = attribute
                       | attribute + ':' + attributes
            attribute  = ('foreground' | 'background') + ':' + color
                       | (<empty> | 'no') + font-flag
                       | 'none'
            font-flag  = 'italic'
                       | 'bold'
                       | 'intense'
                       | 'underline'
            color      = 'none'
                       | [0-255]
                       | [0-255] + ',' + [0-255] + ',' + [0-255]
                       | ('black', 'blue', 'green', 'red',
                          'cyan', 'magenta', 'yellow', 'white')

            For example, the color_spec

                'refine-added:background:blue:bold'

            sets the color of unique added segments with
            a blue background, written with a bold font.

        --line-numbers <compact|aligned>
            Display line numbers. Style is optional.
            When style = 'compact', take as little width as possible.
            When style = 'aligned', align to tab stops (useful if tab is used for indentation). [default: compact]

    -h, --help
            Prints help information

    -V, --version
            Prints version information
"#;

const SHORT_HELP: &str = r#"diffr 0.1.5
Nathan Moreau <nathan.moreau@m4x.org>

diffr adds word-level diff on top of unified diffs.
word-level diff information is displayed using text attributes.

USAGE:
    diffr reads from standard input and writes to standard output.

    Typical usage is for interactive use of diff:
    diff -u <file1> <file2> | diffr
    git show | diffr

OPTIONS:
        --colors <COLOR_SPEC>...    Configure color settings.
        --line-numbers              Display line numbers.
    -h, --help                      Prints help information
    -V, --version                   Prints version information
"#;

#[derive(Clone, Debug)]
struct Style {
    codes: Vec<String>,
}

impl Style {
    fn new(codes: &[&str]) -> Self {
        Self { codes: codes.iter().map(|s| s.to_string()).collect() }
    }

    fn ansi(&self) -> String {
        self.codes.iter().map(|c| format!("\x1b[{}m", c)).collect()
    }
}

#[derive(Clone)]
struct Faces {
    added: Style,
    removed: Style,
    refine_added: Style,
    refine_removed: Style,
}

impl Default for Faces {
    fn default() -> Self {
        Self {
            added: Style::new(&["32"]),
            removed: Style::new(&["31"]),
            refine_added: Style::new(&["1", "38;2;255;255;255", "42"]),
            refine_removed: Style::new(&["1", "38;2;255;255;255", "41"]),
        }
    }
}

#[derive(Clone, Copy, PartialEq)]
enum LineNums {
    None,
    Compact,
    Aligned,
    Fixed,
}

struct Opts {
    faces: Faces,
    line_nums: LineNums,
}

fn main() {
    let opts = match parse_args() {
        Ok(Some(o)) => o,
        Ok(None) => return,
        Err(msg) => {
            eprintln!("{}", msg);
            if msg.starts_with("bad argument:") {
                std::process::exit(2);
            }
            std::process::exit(-1);
        }
    };

    let mut input = String::new();
    io::stdin().read_to_string(&mut input).unwrap();
    let output = process(&input, &opts);
    io::stdout().write_all(output.as_bytes()).unwrap();
}

fn parse_args() -> Result<Option<Opts>, String> {
    let mut args: Vec<String> = env::args().skip(1).collect();
    let mut faces = Faces::default();
    let mut line_nums = LineNums::None;
    let mut i = 0;
    while i < args.len() {
        match args[i].as_str() {
            "--help" => {
                print!("{}", LONG_HELP);
                return Ok(None);
            }
            "-h" => {
                print!("{}", SHORT_HELP);
                return Ok(None);
            }
            "--version" | "-V" => {
                println!("diffr 0.1.5");
                return Ok(None);
            }
            "--colors" => {
                i += 1;
                if i >= args.len() {
                    return Err("missing value for --colors".to_string());
                }
                apply_color_spec(&mut faces, &args[i])?;
            }
            "--line-numbers" => {
                line_nums = LineNums::Compact;
                if i + 1 < args.len() && !args[i + 1].starts_with('-') {
                    i += 1;
                    line_nums = match args[i].as_str() {
                        "compact" => LineNums::Compact,
                        "aligned" => LineNums::Aligned,
                        "fixed" => LineNums::Fixed,
                        other => {
                            return Err(format!(
                                "unexpected line number style: got '{}', expected aligned|compact|fixed",
                                other
                            ));
                        }
                    };
                }
            }
            other => {
                let mut s = format!("bad argument: '{}'\n", other);
                s.push_str(SHORT_HELP);
                return Err(s.trim_end_matches('\n').to_string());
            }
        }
        i += 1;
    }
    args.clear();
    Ok(Some(Opts { faces, line_nums }))
}

fn apply_color_spec(faces: &mut Faces, spec: &str) -> Result<(), String> {
    let parts: Vec<&str> = spec.split(':').collect();
    if parts.is_empty() {
        return Ok(());
    }
    let target = parts[0];
    if !matches!(target, "added" | "removed" | "refine-added" | "refine-removed") {
        return Err(format!(
            "unexpected face name: got '{}', expected added|refine-added|removed|refine-removed",
            target
        ));
    }
    let mut style = match target {
        "added" => faces.added.clone(),
        "removed" => faces.removed.clone(),
        "refine-added" => faces.refine_added.clone(),
        _ => faces.refine_removed.clone(),
    };

    let mut i = 1;
    while i < parts.len() {
        match parts[i] {
            "none" => style.codes.clear(),
            "bold" => add_code(&mut style, "1"),
            "nobold" => remove_code(&mut style, "1"),
            "italic" => add_code(&mut style, "3"),
            "noitalic" => remove_code(&mut style, "3"),
            "intense" => add_code(&mut style, "1"),
            "nointense" => remove_code(&mut style, "1"),
            "underline" => add_code(&mut style, "4"),
            "nounderline" => remove_code(&mut style, "4"),
            "foreground" | "background" => {
                let kind = parts[i];
                i += 1;
                if i >= parts.len() {
                    return Err(format!("missing color value for {}", kind));
                }
                set_color(&mut style, kind == "foreground", parts[i])?;
            }
            "" => {}
            other => return Err(format!("unexpected color attribute: '{}'", other)),
        }
        i += 1;
    }

    match target {
        "added" => faces.added = style,
        "removed" => faces.removed = style,
        "refine-added" => faces.refine_added = style,
        _ => faces.refine_removed = style,
    }
    Ok(())
}

fn add_code(style: &mut Style, code: &str) {
    if !style.codes.iter().any(|c| c == code) {
        style.codes.insert(0, code.to_string());
    }
}

fn remove_code(style: &mut Style, code: &str) {
    style.codes.retain(|c| c != code);
}

fn set_color(style: &mut Style, fg: bool, color: &str) -> Result<(), String> {
    style.codes.retain(|c| {
        if fg {
            !(c.starts_with("3") || c.starts_with("38;"))
        } else {
            !(c.starts_with("4") || c.starts_with("48;"))
        }
    });
    if color == "none" {
        return Ok(());
    }
    let code = if let Some(named) = named_color(color, fg) {
        named.to_string()
    } else if color.contains(',') {
        let nums: Vec<&str> = color.split(',').collect();
        if nums.len() != 3 {
            return Err(format!("unexpected color value: '{}'", color));
        }
        let mut vals = Vec::new();
        for n in nums {
            let v: u8 = n.parse().map_err(|_| format!("unexpected color value: '{}'", color))?;
            vals.push(v);
        }
        format!("{};2;{};{};{}", if fg { 38 } else { 48 }, vals[0], vals[1], vals[2])
    } else if let Ok(v) = color.parse::<u8>() {
        format!("{};5;{}", if fg { 38 } else { 48 }, v)
    } else {
        return Err(format!(
            "unexpected color value: unrecognized color name '{}'. Choose from: black, blue, green, red, cyan, magenta, yellow, white",
            color
        ));
    };
    style.codes.push(code);
    Ok(())
}

fn named_color(name: &str, fg: bool) -> Option<&'static str> {
    let base = match name {
        "black" => 0,
        "red" => 1,
        "green" => 2,
        "yellow" => 3,
        "blue" => 4,
        "magenta" => 5,
        "cyan" => 6,
        "white" => 7,
        _ => return None,
    };
    Some(match (fg, base) {
        (true, 0) => "30",
        (true, 1) => "31",
        (true, 2) => "32",
        (true, 3) => "33",
        (true, 4) => "34",
        (true, 5) => "35",
        (true, 6) => "36",
        (true, 7) => "37",
        (false, 0) => "40",
        (false, 1) => "41",
        (false, 2) => "42",
        (false, 3) => "43",
        (false, 4) => "44",
        (false, 5) => "45",
        (false, 6) => "46",
        _ => "47",
    })
}

#[derive(Clone)]
struct DiffLine {
    sign: char,
    text: String,
    old_no: Option<usize>,
    new_no: Option<usize>,
    width: usize,
}

fn process(input: &str, opts: &Opts) -> String {
    let mut out = String::new();
    let lines: Vec<&str> = input.split_inclusive('\n').collect();
    let mut old_no = 0usize;
    let mut new_no = 0usize;
    let mut num_width = 3usize;
    let mut in_hunk = false;
    let mut i = 0;
    while i < lines.len() {
        let line_with_nl = lines[i];
        let has_nl = line_with_nl.ends_with('\n');
        let line = line_with_nl.trim_end_matches('\n');
        if let Some((o, oc, n, nc)) = parse_hunk(line) {
            flush_plain(&mut out, line, has_nl);
            old_no = o;
            new_no = n;
            let max_no = (o + oc.saturating_sub(1)).max(n + nc.saturating_sub(1));
            let digits = max_no.max(1).to_string().len();
            num_width = digits * 2 + 1;
            in_hunk = true;
            i += 1;
            continue;
        }

        if in_hunk && (line.starts_with('-') || line.starts_with('+')) && !line.starts_with("--- ") && !line.starts_with("+++ ") {
            let mut block = Vec::new();
            while i < lines.len() {
                let lwn = lines[i];
                let hnl = lwn.ends_with('\n');
                let l = lwn.trim_end_matches('\n');
                if !((l.starts_with('-') || l.starts_with('+')) && !l.starts_with("--- ") && !l.starts_with("+++ ")) {
                    break;
                }
                let sign = l.as_bytes()[0] as char;
                let text = l[1..].to_string();
                let (on, nn) = match sign {
                    '-' => {
                        let n = old_no;
                        old_no += 1;
                        (Some(n), None)
                    }
                    '+' => {
                        let n = new_no;
                        new_no += 1;
                        (None, Some(n))
                    }
                    _ => (None, None),
                };
                block.push((DiffLine { sign, text, old_no: on, new_no: nn, width: num_width }, hnl));
                i += 1;
            }
            flush_block(&mut out, &block, opts);
            continue;
        }

        if in_hunk && line.starts_with(' ') {
            let dl = DiffLine {
                sign: ' ',
                text: line[1..].to_string(),
                old_no: Some(old_no),
                new_no: Some(new_no),
                width: num_width,
            };
            old_no += 1;
            new_no += 1;
            flush_context(&mut out, &dl, has_nl, opts);
        } else {
            flush_plain(&mut out, line, has_nl);
        }
        i += 1;
    }
    out
}

fn parse_hunk(line: &str) -> Option<(usize, usize, usize, usize)> {
    if !line.starts_with("@@ ") {
        return None;
    }
    let mut parts = line.split_whitespace();
    parts.next()?;
    let old = parts.next()?;
    let new = parts.next()?;
    if !old.starts_with('-') || !new.starts_with('+') {
        return None;
    }
    let (os, oc) = parse_range(&old[1..]);
    let (ns, nc) = parse_range(&new[1..]);
    Some((os, oc, ns, nc))
}

fn parse_range(s: &str) -> (usize, usize) {
    let mut it = s.split(',');
    let start = it.next().unwrap_or("0").parse().unwrap_or(0);
    let count = it.next().unwrap_or("1").parse().unwrap_or(1);
    (start, count)
}

fn flush_plain(out: &mut String, line: &str, nl: bool) {
    out.push_str(RESET);
    out.push_str(line);
    out.push_str(RESET);
    if nl {
        out.push('\n');
    }
}

fn flush_context(out: &mut String, line: &DiffLine, nl: bool, opts: &Opts) {
    if opts.line_nums == LineNums::None {
        flush_plain(out, &format!(" {}", line.text), nl);
    } else {
        let n = line.new_no.or(line.old_no).unwrap_or(0);
        out.push_str(&format!("{:>width$}", n, width = line.width));
        if opts.line_nums == LineNums::Aligned {
            out.push('\t');
            out.push_str(RESET);
            out.push(' ');
        } else {
            out.push_str(RESET);
            out.push(' ');
        }
        out.push_str(&line.text);
        out.push_str(RESET);
        if nl {
            out.push('\n');
        }
    }
}

fn flush_block(out: &mut String, block: &[(DiffLine, bool)], opts: &Opts) {
    let removed_idx: Vec<usize> = block.iter().enumerate().filter(|(_, (l, _))| l.sign == '-').map(|(i, _)| i).collect();
    let added_idx: Vec<usize> = block.iter().enumerate().filter(|(_, (l, _))| l.sign == '+').map(|(i, _)| i).collect();
    let pair_count = removed_idx.len().min(added_idx.len());
    let mut render: Vec<Option<(Vec<(bool, String)>, bool)>> = vec![None; block.len()];
    for p in 0..pair_count {
        let r = removed_idx[p];
        let a = added_idx[p];
        let (rs, as_) = refine(&block[r].0.text, &block[a].0.text);
        render[r] = Some((rs, false));
        render[a] = Some((as_, false));
    }
    for (idx, (line, nl)) in block.iter().enumerate() {
        let (segs, unpaired) = render[idx].clone().unwrap_or_else(|| (vec![(true, line.text.clone())], true));
        render_changed(out, line, *nl, &segs, unpaired, opts);
    }
}

fn render_changed(out: &mut String, line: &DiffLine, nl: bool, segs: &[(bool, String)], unpaired: bool, opts: &Opts) {
    let (base, refine) = if line.sign == '-' {
        (&opts.faces.removed, &opts.faces.refine_removed)
    } else {
        (&opts.faces.added, &opts.faces.refine_added)
    };
    let base_ansi = base.ansi();
    let ref_ansi = refine.ansi();
    out.push_str(RESET);
    if opts.line_nums != LineNums::None {
        out.push_str(&base_ansi);
        let num = if line.sign == '-' { line.old_no.unwrap_or(0) } else { line.new_no.unwrap_or(0) };
        if line.sign == '-' {
            out.push_str(&format!("{:<width$}", num, width = line.width));
        } else {
            out.push_str(&format!("{:>width$}", num, width = line.width));
        }
        out.push_str(RESET);
        if opts.line_nums == LineNums::Aligned {
            out.push('\t');
        }
        out.push_str(RESET);
    }
    out.push_str(&base_ansi);
    out.push(line.sign);
    out.push_str(RESET);
    for (changed, text) in segs {
        out.push_str(RESET);
        if *changed {
            out.push_str(&ref_ansi);
        } else {
            out.push_str(&base_ansi);
        }
        out.push_str(text);
        out.push_str(RESET);
    }
    let last_changed = segs.last().map(|(changed, _)| *changed).unwrap_or(false);
    if unpaired || last_changed {
        out.push_str(RESET);
        out.push_str(&base_ansi);
        out.push_str(RESET);
    }
    if nl {
        out.push('\n');
    }
}

#[derive(Clone, Debug, PartialEq)]
struct Tok(String);

fn tokenize(s: &str) -> Vec<Tok> {
    let mut toks = Vec::new();
    let mut cur = String::new();
    let mut kind: Option<u8> = None;
    for ch in s.chars() {
        let k = if ch.is_alphanumeric() || ch == '_' {
            1
        } else if ch.is_whitespace() {
            2
        } else {
            3
        };
        if kind == Some(k) {
            cur.push(ch);
        } else {
            if !cur.is_empty() {
                toks.push(Tok(cur.clone()));
                cur.clear();
            }
            cur.push(ch);
            kind = Some(k);
        }
    }
    if !cur.is_empty() {
        toks.push(Tok(cur));
    }
    toks
}

fn refine(a: &str, b: &str) -> (Vec<(bool, String)>, Vec<(bool, String)>) {
    let ta = tokenize(a);
    let tb = tokenize(b);
    let n = ta.len();
    let m = tb.len();
    let mut dp = vec![vec![0usize; m + 1]; n + 1];
    for i in (0..n).rev() {
        for j in (0..m).rev() {
            dp[i][j] = if ta[i] == tb[j] {
                dp[i + 1][j + 1] + 1
            } else {
                dp[i + 1][j].max(dp[i][j + 1])
            };
        }
    }
    let mut keep_a = vec![false; n];
    let mut keep_b = vec![false; m];
    let (mut i, mut j) = (0, 0);
    while i < n && j < m {
        if ta[i] == tb[j] {
            keep_a[i] = true;
            keep_b[j] = true;
            i += 1;
            j += 1;
        } else if dp[i + 1][j] >= dp[i][j + 1] {
            i += 1;
        } else {
            j += 1;
        }
    }
    (merge_segments(&ta, &keep_a), merge_segments(&tb, &keep_b))
}

fn merge_segments(toks: &[Tok], keep: &[bool]) -> Vec<(bool, String)> {
    let mut out: Vec<(bool, String)> = Vec::new();
    for (t, k) in toks.iter().zip(keep.iter()) {
        let changed = !*k;
        if let Some((last_changed, s)) = out.last_mut() {
            if *last_changed == changed {
                s.push_str(&t.0);
                continue;
            }
        }
        out.push((changed, t.0.clone()));
    }
    if out.is_empty() {
        out.push((false, String::new()));
    }
    out
}
