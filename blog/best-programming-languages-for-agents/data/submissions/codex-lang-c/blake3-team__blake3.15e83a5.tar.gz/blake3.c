#include "blake3.h"

#include <string.h>

enum {
  CHUNK_START = 1,
  CHUNK_END = 2,
  PARENT = 4,
  ROOT = 8,
  KEYED_HASH = 16,
  DERIVE_KEY_CONTEXT = 32,
  DERIVE_KEY_MATERIAL = 64
};

static const uint32_t IV[8] = {
    0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
    0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
};

static const uint8_t MSG_PERMUTATION[16] = {2, 6,  3,  10, 7, 0, 4, 13,
                                            1, 11, 12, 5,  9, 14, 15, 8};

typedef struct {
  uint32_t input_cv[8];
  uint32_t block_words[16];
  uint64_t counter;
  uint8_t block_len;
  uint8_t flags;
} output_t;

static uint32_t rotr32(uint32_t w, uint32_t c) {
  return (w >> c) | (w << (32 - c));
}

static uint32_t load32(const void *src) {
  const uint8_t *p = (const uint8_t *)src;
  return ((uint32_t)p[0]) | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) |
         ((uint32_t)p[3] << 24);
}

static void store32(void *dst, uint32_t w) {
  uint8_t *p = (uint8_t *)dst;
  p[0] = (uint8_t)w;
  p[1] = (uint8_t)(w >> 8);
  p[2] = (uint8_t)(w >> 16);
  p[3] = (uint8_t)(w >> 24);
}

static void words_from_little_endian_bytes(const uint8_t bytes[64],
                                           uint32_t words[16]) {
  for (size_t i = 0; i < 16; i++) {
    words[i] = load32(bytes + 4 * i);
  }
}

static void g(uint32_t state[16], size_t a, size_t b, size_t c, size_t d,
              uint32_t mx, uint32_t my) {
  state[a] = state[a] + state[b] + mx;
  state[d] = rotr32(state[d] ^ state[a], 16);
  state[c] = state[c] + state[d];
  state[b] = rotr32(state[b] ^ state[c], 12);
  state[a] = state[a] + state[b] + my;
  state[d] = rotr32(state[d] ^ state[a], 8);
  state[c] = state[c] + state[d];
  state[b] = rotr32(state[b] ^ state[c], 7);
}

static void round_fn(uint32_t state[16], const uint32_t m[16]) {
  g(state, 0, 4, 8, 12, m[0], m[1]);
  g(state, 1, 5, 9, 13, m[2], m[3]);
  g(state, 2, 6, 10, 14, m[4], m[5]);
  g(state, 3, 7, 11, 15, m[6], m[7]);
  g(state, 0, 5, 10, 15, m[8], m[9]);
  g(state, 1, 6, 11, 12, m[10], m[11]);
  g(state, 2, 7, 8, 13, m[12], m[13]);
  g(state, 3, 4, 9, 14, m[14], m[15]);
}

static void permute(const uint32_t in[16], uint32_t out[16]) {
  uint32_t tmp[16];
  for (size_t i = 0; i < 16; i++) {
    tmp[i] = in[MSG_PERMUTATION[i]];
  }
  memcpy(out, tmp, sizeof(tmp));
}

static void compress(const uint32_t cv[8], const uint32_t block_words[16],
                     uint64_t counter, uint32_t block_len, uint32_t flags,
                     uint32_t out[16]) {
  uint32_t state[16];
  uint32_t m[16];
  memcpy(state, cv, 8 * sizeof(uint32_t));
  memcpy(state + 8, IV, 4 * sizeof(uint32_t));
  state[12] = (uint32_t)counter;
  state[13] = (uint32_t)(counter >> 32);
  state[14] = block_len;
  state[15] = flags;
  memcpy(m, block_words, sizeof(m));

  for (size_t round = 0; round < 7; round++) {
    round_fn(state, m);
    if (round != 6) {
      permute(m, m);
    }
  }

  for (size_t i = 0; i < 8; i++) {
    out[i] = state[i] ^ state[i + 8];
    out[i + 8] = state[i + 8] ^ cv[i];
  }
}

static void output_chaining_value(const output_t *self, uint32_t cv[8]) {
  uint32_t out[16];
  compress(self->input_cv, self->block_words, self->counter, self->block_len,
           self->flags, out);
  memcpy(cv, out, 8 * sizeof(uint32_t));
}

static void output_root_bytes(const output_t *self, uint64_t seek, uint8_t *out,
                              size_t out_len) {
  uint64_t output_block_counter = seek / 64;
  size_t offset = (size_t)(seek % 64);
  uint8_t wide[64];

  while (out_len > 0) {
    uint32_t words[16];
    compress(self->input_cv, self->block_words, output_block_counter,
             self->block_len, (uint32_t)(self->flags | ROOT), words);
    for (size_t i = 0; i < 16; i++) {
      store32(wide + 4 * i, words[i]);
    }
    size_t take = 64 - offset;
    if (take > out_len) {
      take = out_len;
    }
    memcpy(out, wide + offset, take);
    out += take;
    out_len -= take;
    output_block_counter++;
    offset = 0;
  }
}

static void chunk_state_init(blake3_chunk_state *self, const uint32_t key[8],
                             uint64_t chunk_counter, uint8_t flags) {
  memcpy(self->cv, key, 8 * sizeof(uint32_t));
  self->chunk_counter = chunk_counter;
  self->buf_len = 0;
  self->blocks_compressed = 0;
  self->flags = flags;
}

static size_t chunk_state_len(const blake3_chunk_state *self) {
  return (size_t)BLAKE3_BLOCK_LEN * self->blocks_compressed + self->buf_len;
}

static uint8_t chunk_state_start_flag(const blake3_chunk_state *self) {
  return self->blocks_compressed == 0 ? CHUNK_START : 0;
}

static void chunk_state_update(blake3_chunk_state *self, const uint8_t *input,
                               size_t input_len) {
  if (self->buf_len > 0) {
    size_t take = BLAKE3_BLOCK_LEN - self->buf_len;
    if (take > input_len) {
      take = input_len;
    }
    memcpy(self->buf + self->buf_len, input, take);
    self->buf_len += (uint8_t)take;
    input += take;
    input_len -= take;
    if (input_len > 0) {
      uint32_t block_words[16], out[16];
      words_from_little_endian_bytes(self->buf, block_words);
      compress(self->cv, block_words, self->chunk_counter, BLAKE3_BLOCK_LEN,
               self->flags | chunk_state_start_flag(self), out);
      memcpy(self->cv, out, 8 * sizeof(uint32_t));
      self->blocks_compressed++;
      self->buf_len = 0;
    }
  }

  while (input_len > BLAKE3_BLOCK_LEN) {
    uint32_t block_words[16], out[16];
    words_from_little_endian_bytes(input, block_words);
    compress(self->cv, block_words, self->chunk_counter, BLAKE3_BLOCK_LEN,
             self->flags | chunk_state_start_flag(self), out);
    memcpy(self->cv, out, 8 * sizeof(uint32_t));
    self->blocks_compressed++;
    input += BLAKE3_BLOCK_LEN;
    input_len -= BLAKE3_BLOCK_LEN;
  }

  memcpy(self->buf + self->buf_len, input, input_len);
  self->buf_len += (uint8_t)input_len;
}

static output_t chunk_state_output(const blake3_chunk_state *self) {
  uint8_t block[BLAKE3_BLOCK_LEN] = {0};
  output_t ret;
  memcpy(block, self->buf, self->buf_len);
  memcpy(ret.input_cv, self->cv, 8 * sizeof(uint32_t));
  words_from_little_endian_bytes(block, ret.block_words);
  ret.counter = self->chunk_counter;
  ret.block_len = self->buf_len;
  ret.flags = self->flags | chunk_state_start_flag(self) | CHUNK_END;
  return ret;
}

static output_t parent_output(const uint32_t left_child_cv[8],
                              const uint32_t right_child_cv[8],
                              const uint32_t key[8], uint8_t flags) {
  output_t ret;
  memcpy(ret.input_cv, key, 8 * sizeof(uint32_t));
  memcpy(ret.block_words, left_child_cv, 8 * sizeof(uint32_t));
  memcpy(ret.block_words + 8, right_child_cv, 8 * sizeof(uint32_t));
  ret.counter = 0;
  ret.block_len = BLAKE3_BLOCK_LEN;
  ret.flags = flags | PARENT;
  return ret;
}

static void parent_cv(const uint32_t left_child_cv[8],
                      const uint32_t right_child_cv[8], const uint32_t key[8],
                      uint8_t flags, uint32_t out[8]) {
  output_t o = parent_output(left_child_cv, right_child_cv, key, flags);
  output_chaining_value(&o, out);
}

static void hasher_init_internal(blake3_hasher *self, const uint32_t key[8],
                                 uint8_t flags) {
  memcpy(self->key, key, 8 * sizeof(uint32_t));
  chunk_state_init(&self->chunk, key, 0, flags);
  self->cv_stack_len = 0;
  self->flags = flags;
}

void blake3_hasher_init(blake3_hasher *self) {
  hasher_init_internal(self, IV, 0);
}

void blake3_hasher_init_keyed(blake3_hasher *self,
                              const uint8_t key[BLAKE3_KEY_LEN]) {
  uint32_t key_words[8];
  for (size_t i = 0; i < 8; i++) {
    key_words[i] = load32(key + 4 * i);
  }
  hasher_init_internal(self, key_words, KEYED_HASH);
}

void blake3_hasher_update(blake3_hasher *self, const void *input,
                          size_t input_len) {
  const uint8_t *bytes = (const uint8_t *)input;
  while (input_len > 0) {
    if (chunk_state_len(&self->chunk) == BLAKE3_CHUNK_LEN) {
      uint32_t chunk_cv[8];
      output_t chunk_output = chunk_state_output(&self->chunk);
      uint64_t total_chunks = self->chunk.chunk_counter + 1;
      output_chaining_value(&chunk_output, chunk_cv);
      while ((total_chunks & 1) == 0) {
        uint32_t parent[8];
        self->cv_stack_len--;
        parent_cv(&self->cv_stack[self->cv_stack_len * 8], chunk_cv, self->key,
                  self->flags, parent);
        memcpy(chunk_cv, parent, sizeof(parent));
        total_chunks >>= 1;
      }
      memcpy(&self->cv_stack[self->cv_stack_len * 8], chunk_cv,
             8 * sizeof(uint32_t));
      self->cv_stack_len++;
      chunk_state_init(&self->chunk, self->key, self->chunk.chunk_counter + 1,
                       self->flags);
    }

    size_t want = BLAKE3_CHUNK_LEN - chunk_state_len(&self->chunk);
    if (want > input_len) {
      want = input_len;
    }
    chunk_state_update(&self->chunk, bytes, want);
    bytes += want;
    input_len -= want;
  }
}

void blake3_hasher_finalize_seek(const blake3_hasher *self, uint64_t seek,
                                 uint8_t *out, size_t out_len) {
  output_t output = chunk_state_output(&self->chunk);
  uint32_t cv[8];
  for (size_t i = self->cv_stack_len; i > 0; i--) {
    output_chaining_value(&output, cv);
    output = parent_output(&self->cv_stack[(i - 1) * 8], cv, self->key,
                           self->flags);
  }
  output_root_bytes(&output, seek, out, out_len);
}

void blake3_hasher_finalize(const blake3_hasher *self, uint8_t *out,
                            size_t out_len) {
  blake3_hasher_finalize_seek(self, 0, out, out_len);
}

void blake3_hasher_init_derive_key(blake3_hasher *self, const char *context) {
  blake3_hasher context_hasher;
  uint8_t context_key[BLAKE3_KEY_LEN];
  uint32_t context_key_words[8];

  hasher_init_internal(&context_hasher, IV, DERIVE_KEY_CONTEXT);
  blake3_hasher_update(&context_hasher, context, strlen(context));
  blake3_hasher_finalize(&context_hasher, context_key, BLAKE3_KEY_LEN);
  for (size_t i = 0; i < 8; i++) {
    context_key_words[i] = load32(context_key + 4 * i);
  }
  hasher_init_internal(self, context_key_words, DERIVE_KEY_MATERIAL);
}
