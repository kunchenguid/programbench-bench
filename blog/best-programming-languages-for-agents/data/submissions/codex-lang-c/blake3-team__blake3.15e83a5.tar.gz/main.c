#define _GNU_SOURCE
#include "blake3.h"

#include <ctype.h>
#include <errno.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  bool keyed;
  const char *derive_context;
  uint64_t length;
  uint64_t seek;
  bool no_names;
  bool raw;
  bool tag;
  bool check;
  bool quiet;
  const char **files;
  int file_count;
} options_t;

static void print_short_help(void) {
  puts("Usage: executable [OPTIONS] [FILE]...\n");
  puts("Arguments:");
  puts("  [FILE]...  Files to hash, or checkfiles to check\n");
  puts("Options:");
  puts("      --keyed                 Use the keyed mode, reading the 32-byte key from stdin");
  puts("      --derive-key <CONTEXT>  Use the key derivation mode, with the given context string");
  puts("  -l, --length <LEN>          The number of output bytes, before hex encoding [default: 32]");
  puts("      --seek <SEEK>           The starting output byte offset, before hex encoding [default: 0]");
  puts("      --num-threads <NUM>     The maximum number of threads to use");
  puts("      --no-mmap               Disable memory mapping");
  puts("      --no-names              Omit filenames in the output");
  puts("      --raw                   Write raw output bytes to stdout, rather than hex");
  puts("      --tag                   Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]");
  puts("  -c, --check                 Read BLAKE3 sums from the [FILE]s and check them");
  puts("      --quiet                 Skip printing OK for each checked file");
  puts("  -h, --help                  Print help (see more with '--help')");
  puts("  -V, --version               Print version");
}

static void print_long_help(void) {
  puts("Usage: executable [OPTIONS] [FILE]...\n");
  puts("Arguments:");
  puts("  [FILE]...");
  puts("          Files to hash, or checkfiles to check");
  puts("          ");
  puts("          When no file is given, or when - is given, read standard input.\n");
  puts("Options:");
  puts("      --keyed");
  puts("          Use the keyed mode, reading the 32-byte key from stdin\n");
  puts("      --derive-key <CONTEXT>");
  puts("          Use the key derivation mode, with the given context string");
  puts("          ");
  puts("          Cannot be used with --keyed.\n");
  puts("  -l, --length <LEN>");
  puts("          The number of output bytes, before hex encoding");
  puts("          ");
  puts("          [default: 32]\n");
  puts("      --seek <SEEK>");
  puts("          The starting output byte offset, before hex encoding");
  puts("          ");
  puts("          [default: 0]\n");
  puts("      --num-threads <NUM>");
  puts("          The maximum number of threads to use");
  puts("          ");
  puts("          By default, this is the number of logical cores. If this flag is omitted, or if its value");
  puts("          is 0, RAYON_NUM_THREADS is also respected.\n");
  puts("      --no-mmap");
  puts("          Disable memory mapping");
  puts("          ");
  puts("          Currently this also disables multithreading.\n");
  puts("      --no-names");
  puts("          Omit filenames in the output\n");
  puts("      --raw");
  puts("          Write raw output bytes to stdout, rather than hex");
  puts("          ");
  puts("          --no-names is implied. In this case, only a single input is allowed.\n");
  puts("      --tag");
  puts("          Output BSD-style checksums: BLAKE3 ([FILE]) = [HASH]\n");
  puts("  -c, --check");
  puts("          Read BLAKE3 sums from the [FILE]s and check them\n");
  puts("      --quiet");
  puts("          Skip printing OK for each checked file");
  puts("          ");
  puts("          Must be used with --check.\n");
  puts("  -h, --help");
  puts("          Print help (see a summary with '-h')\n");
  puts("  -V, --version");
  puts("          Print version");
}

static bool parse_u64(const char *s, uint64_t *out) {
  if (*s == '\0' || *s == '-') {
    return false;
  }
  errno = 0;
  char *end = NULL;
  unsigned long long value = strtoull(s, &end, 10);
  if (errno || *end != '\0') {
    return false;
  }
  *out = (uint64_t)value;
  return true;
}

static int hex_val(int c) {
  if (c >= '0' && c <= '9') return c - '0';
  if (c >= 'a' && c <= 'f') return c - 'a' + 10;
  if (c >= 'A' && c <= 'F') return c - 'A' + 10;
  return -1;
}

static void print_hex(const uint8_t *buf, size_t len) {
  static const char *hex = "0123456789abcdef";
  for (size_t i = 0; i < len; i++) {
    putchar(hex[buf[i] >> 4]);
    putchar(hex[buf[i] & 15]);
  }
}

static void init_hasher(blake3_hasher *h, const options_t *opt,
                        const uint8_t key[BLAKE3_KEY_LEN]) {
  if (opt->keyed) {
    blake3_hasher_init_keyed(h, key);
  } else if (opt->derive_context) {
    blake3_hasher_init_derive_key(h, opt->derive_context);
  } else {
    blake3_hasher_init(h);
  }
}

static int hash_stream(FILE *f, blake3_hasher *h) {
  uint8_t buf[32768];
  for (;;) {
    size_t n = fread(buf, 1, sizeof(buf), f);
    if (n) {
      blake3_hasher_update(h, buf, n);
    }
    if (n < sizeof(buf)) {
      if (ferror(f)) {
        return -1;
      }
      return 0;
    }
  }
}

static int hash_input(const char *path, const options_t *opt,
                      const uint8_t key[BLAKE3_KEY_LEN], uint8_t *out,
                      size_t out_len) {
  blake3_hasher h;
  init_hasher(&h, opt, key);

  if (path == NULL || strcmp(path, "-") == 0) {
    if (hash_stream(stdin, &h) != 0) {
      fprintf(stderr, "Error: failed to read standard input\n");
      return 1;
    }
  } else {
    FILE *f = fopen(path, "rb");
    if (!f) {
      fprintf(stderr, "Error: %s: %s\n", path, strerror(errno));
      return 1;
    }
    int rc = hash_stream(f, &h);
    if (fclose(f) != 0 || rc != 0) {
      fprintf(stderr, "Error: %s: failed to read file\n", path);
      return 1;
    }
  }

  blake3_hasher_finalize_seek(&h, opt->seek, out, out_len);
  return 0;
}

static int run_hashes(const options_t *opt, const uint8_t key[BLAKE3_KEY_LEN]) {
  int count = opt->file_count ? opt->file_count : 1;
  if (opt->raw && count > 1) {
    fprintf(stderr, "Error: Only one filename can be provided when using --raw\n");
    return 1;
  }

  size_t out_len = (size_t)opt->length;
  uint8_t *out = out_len ? malloc(out_len) : NULL;
  if (out_len && !out) {
    fprintf(stderr, "Error: allocation failed\n");
    return 1;
  }

  int status = 0;
  for (int i = 0; i < count; i++) {
    const char *path = opt->file_count ? opt->files[i] : "-";
    if (hash_input(path, opt, key, out, out_len) != 0) {
      status = 1;
      continue;
    }
    if (opt->raw) {
      if (out_len && fwrite(out, 1, out_len, stdout) != out_len) {
        status = 1;
      }
    } else if (opt->tag && !opt->no_names) {
      printf("BLAKE3 (%s) = ", path);
      print_hex(out, out_len);
      putchar('\n');
    } else {
      print_hex(out, out_len);
      if (!opt->no_names) {
        printf("  %s", path);
      }
      putchar('\n');
    }
  }
  free(out);
  return status;
}

static char *trim_newline(char *s) {
  size_t len = strlen(s);
  while (len && (s[len - 1] == '\n' || s[len - 1] == '\r')) {
    s[--len] = '\0';
  }
  return s;
}

static bool parse_check_line(char *line, char **hex, char **name) {
  trim_newline(line);
  if (strncmp(line, "BLAKE3 (", 8) == 0) {
    char *close = strstr(line + 8, ") = ");
    if (!close) return false;
    *close = '\0';
    *name = line + 8;
    *hex = close + 4;
    return **hex != '\0';
  }

  char *p = line;
  while (isxdigit((unsigned char)*p)) p++;
  if (p == line || ((p - line) & 1)) return false;
  if (p[0] == ' ' && p[1] == ' ') {
    *p = '\0';
    *hex = line;
    *name = p + 2;
    if (**name == '*' || **name == ' ') (*name)++;
    return **name != '\0';
  }
  return false;
}

static bool decode_hex(const char *hex, uint8_t **bytes, size_t *len) {
  size_t n = strlen(hex);
  if ((n & 1) || n == 0) return false;
  uint8_t *out = malloc(n / 2);
  if (!out) return false;
  for (size_t i = 0; i < n / 2; i++) {
    int hi = hex_val((unsigned char)hex[2 * i]);
    int lo = hex_val((unsigned char)hex[2 * i + 1]);
    if (hi < 0 || lo < 0) {
      free(out);
      return false;
    }
    out[i] = (uint8_t)((hi << 4) | lo);
  }
  *bytes = out;
  *len = n / 2;
  return true;
}

static int check_one_file(FILE *checkfile, const char *checkfile_name,
                          const options_t *opt, const uint8_t key[BLAKE3_KEY_LEN]) {
  char *line = NULL;
  size_t cap = 0;
  ssize_t nread;
  int failures = 0, malformed = 0, total = 0;

  while ((nread = getline(&line, &cap, checkfile)) >= 0) {
    (void)nread;
    char *hex = NULL, *name = NULL;
    if (!parse_check_line(line, &hex, &name)) {
      malformed++;
      continue;
    }
    uint8_t *expected = NULL;
    size_t len = 0;
    if (!decode_hex(hex, &expected, &len)) {
      malformed++;
      continue;
    }
    options_t local = *opt;
    local.length = len;
    local.seek = 0;
    uint8_t *actual = len ? malloc(len) : NULL;
    if (len && !actual) {
      free(expected);
      free(line);
      return 1;
    }
    total++;
    bool ok = hash_input(name, &local, key, actual, len) == 0 &&
              memcmp(expected, actual, len) == 0;
    if (ok) {
      if (!opt->quiet) printf("%s: OK\n", name);
    } else {
      printf("%s: FAILED\n", name);
      failures++;
    }
    free(expected);
    free(actual);
  }
  free(line);

  if (malformed) {
    fprintf(stderr, "executable: %s: %d improperly formatted checksum line%s\n",
            checkfile_name, malformed, malformed == 1 ? "" : "s");
  }
  if (failures) {
    fprintf(stderr, "executable: WARNING: %d computed checksum did NOT match\n",
            failures);
  }
  if (total == 0 && malformed) {
    return 1;
  }
  return failures || malformed ? 1 : 0;
}

static int run_check(const options_t *opt, const uint8_t key[BLAKE3_KEY_LEN]) {
  int count = opt->file_count ? opt->file_count : 1;
  int status = 0;
  for (int i = 0; i < count; i++) {
    const char *path = opt->file_count ? opt->files[i] : "-";
    FILE *f = stdin;
    if (strcmp(path, "-") != 0) {
      f = fopen(path, "rb");
      if (!f) {
        fprintf(stderr, "Error: %s: %s\n", path, strerror(errno));
        status = 1;
        continue;
      }
    }
    if (check_one_file(f, path, opt, key) != 0) {
      status = 1;
    }
    if (f != stdin) fclose(f);
  }
  return status;
}

static int parse_args(int argc, char **argv, options_t *opt) {
  memset(opt, 0, sizeof(*opt));
  opt->length = 32;
  opt->files = calloc((size_t)argc, sizeof(char *));
  if (!opt->files) return 1;

  for (int i = 1; i < argc; i++) {
    const char *a = argv[i];
    const char *value = NULL;
    if (strcmp(a, "--help") == 0) {
      print_long_help();
      exit(0);
    } else if (strcmp(a, "-h") == 0) {
      print_short_help();
      exit(0);
    } else if (strcmp(a, "--version") == 0 || strcmp(a, "-V") == 0) {
      puts("b3sum 1.8.4");
      exit(0);
    } else if (strcmp(a, "--keyed") == 0) {
      opt->keyed = true;
    } else if (strcmp(a, "--derive-key") == 0) {
      if (++i >= argc) {
        fprintf(stderr, "error: a value is required for '--derive-key <CONTEXT>'\n");
        return 2;
      }
      opt->derive_context = argv[i];
    } else if (strncmp(a, "--derive-key=", 13) == 0) {
      opt->derive_context = a + 13;
    } else if (strcmp(a, "-l") == 0 || strcmp(a, "--length") == 0) {
      if (++i >= argc || !parse_u64(argv[i], &opt->length)) {
        fprintf(stderr, "error: invalid value for '--length <LEN>'\n");
        return 2;
      }
    } else if (strncmp(a, "--length=", 9) == 0) {
      if (!parse_u64(a + 9, &opt->length)) return 2;
    } else if (strncmp(a, "-l", 2) == 0 && a[2]) {
      if (!parse_u64(a + 2, &opt->length)) return 2;
    } else if (strcmp(a, "--seek") == 0) {
      if (++i >= argc || !parse_u64(argv[i], &opt->seek)) {
        fprintf(stderr, "error: invalid value for '--seek <SEEK>'\n");
        return 2;
      }
    } else if (strncmp(a, "--seek=", 7) == 0) {
      if (!parse_u64(a + 7, &opt->seek)) return 2;
    } else if (strcmp(a, "--num-threads") == 0) {
      if (++i >= argc || !parse_u64(argv[i], &(uint64_t){0})) return 2;
    } else if (strncmp(a, "--num-threads=", 14) == 0) {
      uint64_t dummy;
      if (!parse_u64(a + 14, &dummy)) return 2;
    } else if (strcmp(a, "--no-mmap") == 0) {
    } else if (strcmp(a, "--no-names") == 0) {
      opt->no_names = true;
    } else if (strcmp(a, "--raw") == 0) {
      opt->raw = true;
      opt->no_names = true;
    } else if (strcmp(a, "--tag") == 0) {
      opt->tag = true;
    } else if (strcmp(a, "-c") == 0 || strcmp(a, "--check") == 0) {
      opt->check = true;
    } else if (strcmp(a, "--quiet") == 0) {
      opt->quiet = true;
    } else if (strcmp(a, "--") == 0) {
      while (++i < argc) opt->files[opt->file_count++] = argv[i];
      break;
    } else if (a[0] == '-' && a[1] != '\0') {
      fprintf(stderr, "error: unexpected argument '%s'\n", a);
      return 2;
    } else {
      (void)value;
      opt->files[opt->file_count++] = a;
    }
  }

  if (opt->keyed && opt->derive_context) {
    fprintf(stderr,
            "error: the argument '--keyed' cannot be used with '--derive-key <CONTEXT>'\n\n");
    fprintf(stderr, "Usage: executable --keyed <FILE>...\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
  }
  if (opt->quiet && !opt->check) {
    fprintf(stderr, "error: the argument '--quiet' requires '--check'\n");
    return 2;
  }
  return 0;
}

int main(int argc, char **argv) {
  options_t opt;
  int rc = parse_args(argc, argv, &opt);
  if (rc) return rc;

  uint8_t key[BLAKE3_KEY_LEN] = {0};
  if (opt.keyed) {
    size_t n = fread(key, 1, BLAKE3_KEY_LEN, stdin);
    if (n != BLAKE3_KEY_LEN) {
      fprintf(stderr, "Error: expected 32 key bytes from stdin, found %zu\n", n);
      return 1;
    }
  }

  rc = opt.check ? run_check(&opt, key) : run_hashes(&opt, key);
  free(opt.files);
  return rc;
}
