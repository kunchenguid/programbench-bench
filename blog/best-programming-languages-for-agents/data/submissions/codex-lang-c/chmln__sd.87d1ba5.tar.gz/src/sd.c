#include <ctype.h>
#include <errno.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct {
    char *name;
    int index;
} Name;

typedef struct {
    char *data;
    size_t len;
    size_t cap;
} Buf;

typedef struct {
    bool preview;
    bool fixed;
    bool case_sensitive;
    bool dot_newline;
    bool multiline;
    bool word;
    size_t max_repl;
    const char *find;
    const char *replace;
    char **files;
    int nfiles;
} Opts;

static void die(const char *msg) {
    fprintf(stderr, "%s\n", msg);
    exit(1);
}

static void buf_init(Buf *b) {
    b->data = NULL;
    b->len = 0;
    b->cap = 0;
}

static void buf_reserve(Buf *b, size_t need) {
    if (need <= b->cap) return;
    size_t nc = b->cap ? b->cap * 2 : 256;
    while (nc < need) nc *= 2;
    char *p = realloc(b->data, nc);
    if (!p) die("error: out of memory");
    b->data = p;
    b->cap = nc;
}

static void buf_addn(Buf *b, const char *s, size_t n) {
    if (n == 0) return;
    buf_reserve(b, b->len + n + 1);
    memcpy(b->data + b->len, s, n);
    b->len += n;
    b->data[b->len] = 0;
}

static void buf_addc(Buf *b, char c) {
    buf_reserve(b, b->len + 2);
    b->data[b->len++] = c;
    b->data[b->len] = 0;
}

static char *xstrndup(const char *s, size_t n) {
    char *p = malloc(n + 1);
    if (!p) die("error: out of memory");
    memcpy(p, s, n);
    p[n] = 0;
    return p;
}

static void print_help_long(void) {
    puts("sd v1.0.0");
    puts("An intuitive find & replace CLI\n");
    puts("Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n");
    puts("Arguments:");
    puts("  <FIND>\n          The regexp or string (if using `-F`) to search for\n");
    puts("  <REPLACE_WITH>\n          What to replace each match with. Unless in string mode, you may use captured values like\n          $1, $2, etc\n");
    puts("  [FILES]...\n          The path to file(s). This is optional - sd can also read from STDIN.\n          \n          Note: sd modifies files in-place by default. See documentation for examples.\n");
    puts("Options:");
    puts("  -p, --preview\n          Display changes in a human reviewable format (the specifics of the format are likely to\n          change in the future)\n");
    puts("  -F, --fixed-strings\n          Treat FIND and REPLACE_WITH args as literal strings\n");
    puts("  -n, --max-replacements <LIMIT>\n          Limit the number of replacements that can occur per file. 0 indicates unlimited\n          replacements\n          \n          [default: 0]\n");
    puts("  -f, --flags <FLAGS>\n          Regex flags. May be combined (like `-f mc`).\n          \n          c - case-sensitive\n          \n          e - disable multi-line matching\n          \n          i - case-insensitive\n          \n          m - multi-line matching\n          \n          s - make `.` match newlines\n          \n          w - match full words only\n");
    puts("  -h, --help\n          Print help (see a summary with '-h')\n");
    puts("  -V, --version\n          Print version");
}

static void print_help_short(void) {
    puts("sd v1.0.0");
    puts("An intuitive find & replace CLI\n");
    puts("Usage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n");
    puts("Arguments:");
    puts("  <FIND>          The regexp or string (if using `-F`) to search for");
    puts("  <REPLACE_WITH>  What to replace each match with. Unless in string mode, you may use captured");
    puts("                  values like $1, $2, etc");
    puts("  [FILES]...      The path to file(s). This is optional - sd can also read from STDIN\n");
    puts("Options:");
    puts("  -p, --preview                   Display changes in a human reviewable format (the specifics of the");
    puts("                                  format are likely to change in the future)");
    puts("  -F, --fixed-strings             Treat FIND and REPLACE_WITH args as literal strings");
    puts("  -n, --max-replacements <LIMIT>  Limit the number of replacements that can occur per file. 0");
    puts("                                  indicates unlimited replacements [default: 0]");
    puts("  -f, --flags <FLAGS>             Regex flags. May be combined (like `-f mc`).");
    puts("  -h, --help                      Print help (see more with '--help')");
    puts("  -V, --version                   Print version");
}

static void usage_missing(int have) {
    if (have == 0) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <FIND>\n  <REPLACE_WITH>\n\n");
        fprintf(stderr, "Usage: executable <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.\n");
    } else {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <REPLACE_WITH>\n\n");
        fprintf(stderr, "Usage: executable <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.\n");
    }
    exit(2);
}

static void add_name(Name **names, int *count, const char *s, size_t n, int idx) {
    *names = realloc(*names, (size_t)(*count + 1) * sizeof(Name));
    if (!*names) die("error: out of memory");
    (*names)[*count].name = xstrndup(s, n);
    (*names)[*count].index = idx;
    (*count)++;
}

static char *translate_regex(const char *pat, Name **names, int *name_count, bool word) {
    Buf b; buf_init(&b);
    int group = 0;
    if (word) buf_addn(&b, "\\<", 2);
    for (size_t i = 0; pat[i]; i++) {
        char c = pat[i];
        if (c == '\\' && pat[i + 1]) {
            char n = pat[++i];
            if (n == 'n') buf_addc(&b, '\n');
            else if (n == 't') buf_addc(&b, '\t');
            else if (n == 'r') buf_addc(&b, '\r');
            else if (n == 'd') buf_addn(&b, "[[:digit:]]", 11);
            else if (n == 'D') buf_addn(&b, "[^[:digit:]]", 12);
            else if (n == 'w') buf_addn(&b, "[[:alnum:]_]", 12);
            else if (n == 'W') buf_addn(&b, "[^[:alnum:]_]", 13);
            else if (n == 's') buf_addn(&b, "[[:space:]]", 11);
            else if (n == 'S') buf_addn(&b, "[^[:space:]]", 12);
            else {
                buf_addc(&b, '\\');
                buf_addc(&b, n);
            }
        } else if (c == '(' && pat[i + 1] == '?' && pat[i + 2] == 'P' && pat[i + 3] == '<') {
            size_t j = i + 4;
            while (pat[j] && pat[j] != '>') j++;
            if (pat[j] == '>') {
                group++;
                add_name(names, name_count, pat + i + 4, j - (i + 4), group);
                buf_addc(&b, '(');
                i = j;
            } else {
                buf_addc(&b, c);
            }
        } else if (c == '(' && pat[i + 1] == '?' && pat[i + 2] == ':') {
            buf_addc(&b, '(');
            i += 2;
        } else {
            if (c == '(') group++;
            buf_addc(&b, c);
        }
    }
    if (word) buf_addn(&b, "\\>", 2);
    return b.data ? b.data : strdup("");
}

static int name_index(Name *names, int count, const char *s, size_t n) {
    for (int i = 0; i < count; i++) {
        if (strlen(names[i].name) == n && strncmp(names[i].name, s, n) == 0) return names[i].index;
    }
    return -1;
}

static void append_group(Buf *out, const char *base, regmatch_t *m, size_t nmatch, int idx) {
    if (idx >= 0 && (size_t)idx < nmatch && m[idx].rm_so >= 0) {
        buf_addn(out, base + m[idx].rm_so, (size_t)(m[idx].rm_eo - m[idx].rm_so));
    }
}

static void expand_repl(Buf *out, const char *repl, const char *match_base, regmatch_t *m,
                        size_t nmatch, Name *names, int name_count, bool fixed) {
    if (fixed) {
        buf_addn(out, repl, strlen(repl));
        return;
    }
    for (size_t i = 0; repl[i]; i++) {
        if (repl[i] != '$') {
            buf_addc(out, repl[i]);
            continue;
        }
        if (repl[i + 1] == '$') {
            buf_addc(out, '$');
            i++;
        } else if (isdigit((unsigned char)repl[i + 1])) {
            int idx = 0;
            i++;
            while (isdigit((unsigned char)repl[i])) {
                idx = idx * 10 + (repl[i] - '0');
                i++;
            }
            i--;
            append_group(out, match_base, m, nmatch, idx);
        } else if (repl[i + 1] == '{') {
            size_t j = i + 2;
            while (repl[j] && repl[j] != '}') j++;
            if (repl[j] == '}') {
                int idx = name_index(names, name_count, repl + i + 2, j - (i + 2));
                append_group(out, match_base, m, nmatch, idx);
                i = j;
            } else {
                buf_addc(out, '$');
            }
        } else if (isalpha((unsigned char)repl[i + 1]) || repl[i + 1] == '_') {
            size_t j = i + 1;
            while (isalnum((unsigned char)repl[j]) || repl[j] == '_') j++;
            int idx = name_index(names, name_count, repl + i + 1, j - (i + 1));
            append_group(out, match_base, m, nmatch, idx);
            i = j - 1;
        } else {
            buf_addc(out, '$');
        }
    }
}

static char *read_stream(FILE *f, size_t *len) {
    Buf b; buf_init(&b);
    char tmp[8192];
    size_t n;
    while ((n = fread(tmp, 1, sizeof(tmp), f)) > 0) buf_addn(&b, tmp, n);
    if (ferror(f)) die("error: failed reading input");
    if (!b.data) b.data = strdup("");
    *len = b.len;
    return b.data;
}

static char *read_file(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "error: could not read %s: %s\n", path, strerror(errno));
        exit(1);
    }
    char *s = read_stream(f, len);
    fclose(f);
    return s;
}

static int write_file(const char *path, const char *data, size_t len) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    size_t n = fwrite(data, 1, len, f);
    int ok = (n == len && fclose(f) == 0);
    return ok ? 0 : -1;
}

static char *replace_fixed(const char *input, size_t len, const Opts *o, size_t *outlen) {
    Buf out; buf_init(&out);
    const char *find = o->find;
    size_t flen = strlen(find), rlen = strlen(o->replace);
    size_t pos = 0, count = 0;
    if (flen == 0) {
        buf_addn(&out, input, len);
        *outlen = out.len;
        return out.data;
    }
    while (pos <= len) {
        void *p = NULL;
        if (o->case_sensitive) {
            p = memmem(input + pos, len - pos, find, flen);
        } else {
            for (size_t i = pos; i + flen <= len; i++) {
                size_t j = 0;
                for (; j < flen; j++) {
                    if (tolower((unsigned char)input[i + j]) != tolower((unsigned char)find[j])) break;
                }
                if (j == flen) { p = (void *)(input + i); break; }
            }
        }
        if (!p || (o->max_repl && count >= o->max_repl)) break;
        size_t off = (const char *)p - input;
        if (o->word) {
            bool left = off == 0 || !(isalnum((unsigned char)input[off - 1]) || input[off - 1] == '_');
            bool right = off + flen >= len || !(isalnum((unsigned char)input[off + flen]) || input[off + flen] == '_');
            if (!left || !right) {
                buf_addn(&out, input + pos, off + 1 - pos);
                pos = off + 1;
                continue;
            }
        }
        buf_addn(&out, input + pos, off - pos);
        buf_addn(&out, o->replace, rlen);
        pos = off + flen;
        count++;
    }
    buf_addn(&out, input + pos, len - pos);
    *outlen = out.len;
    return out.data ? out.data : strdup("");
}

static char *replace_regex(const char *input, size_t len, const Opts *o, size_t *outlen) {
    Name *names = NULL;
    int name_count = 0;
    char *pat = translate_regex(o->find, &names, &name_count, o->word);
    regex_t re;
    int cflags = REG_EXTENDED;
    if (!o->case_sensitive) cflags |= REG_ICASE;
    if (o->multiline && !o->dot_newline) cflags |= REG_NEWLINE;
    int rc = regcomp(&re, pat, cflags);
    if (rc != 0) {
        char err[512];
        regerror(rc, &re, err, sizeof(err));
        fprintf(stderr, "error: regex parse error: %s\n", err);
        exit(1);
    }
    size_t nmatch = re.re_nsub + 1;
    regmatch_t *m = calloc(nmatch, sizeof(regmatch_t));
    if (!m) die("error: out of memory");
    Buf out; buf_init(&out);
    size_t pos = 0, count = 0;
    while (pos <= len) {
        if (o->max_repl && count >= o->max_repl) break;
        rc = regexec(&re, input + pos, nmatch, m, 0);
        if (rc == REG_NOMATCH) break;
        if (rc != 0) break;
        size_t so = pos + (size_t)m[0].rm_so;
        size_t eo = pos + (size_t)m[0].rm_eo;
        buf_addn(&out, input + pos, so - pos);
        expand_repl(&out, o->replace, input + pos, m, nmatch, names, name_count, false);
        count++;
        if (eo == so) {
            if (eo < len) {
                buf_addc(&out, input[eo]);
                pos = eo + 1;
            } else {
                pos = eo;
                break;
            }
        } else {
            pos = eo;
        }
    }
    buf_addn(&out, input + pos, len - pos);
    *outlen = out.len;
    regfree(&re);
    free(m);
    free(pat);
    for (int i = 0; i < name_count; i++) free(names[i].name);
    free(names);
    return out.data ? out.data : strdup("");
}

static void apply_flags(Opts *o, const char *flags) {
    for (const char *p = flags; *p; p++) {
        switch (*p) {
            case 'c': o->case_sensitive = true; break;
            case 'i': o->case_sensitive = false; break;
            case 'm': o->multiline = true; break;
            case 'e': o->multiline = false; break;
            case 's': o->dot_newline = true; break;
            case 'w': o->word = true; break;
            default: break;
        }
    }
}

static void parse_args(int argc, char **argv, Opts *o) {
    memset(o, 0, sizeof(*o));
    o->case_sensitive = false;
    o->multiline = true;
    int vals_start = 1;
    bool end_opts = false;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!end_opts && strcmp(a, "--") == 0) {
            vals_start = i + 1;
            end_opts = true;
            break;
        } else if (!end_opts && (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0)) {
            if (strcmp(a, "-h") == 0) print_help_short(); else print_help_long();
            exit(0);
        } else if (!end_opts && (strcmp(a, "-V") == 0 || strcmp(a, "--version") == 0)) {
            puts("sd 1.0.0");
            exit(0);
        } else if (!end_opts && (strcmp(a, "-p") == 0 || strcmp(a, "--preview") == 0)) {
            o->preview = true;
            vals_start = i + 1;
        } else if (!end_opts && (strcmp(a, "-F") == 0 || strcmp(a, "--fixed-strings") == 0)) {
            o->fixed = true;
            vals_start = i + 1;
        } else if (!end_opts && strncmp(a, "--max-replacements=", 19) == 0) {
            char *end = NULL;
            errno = 0;
            unsigned long v = strtoul(a + 19, &end, 10);
            if (errno || !end || *end) {
                fprintf(stderr, "error: invalid value '%s' for '--max-replacements <LIMIT>': invalid digit found in string\n\nFor more information, try '--help'.\n", a + 19);
                exit(2);
            }
            o->max_repl = (size_t)v;
            vals_start = i + 1;
        } else if (!end_opts && (strcmp(a, "-n") == 0 || strcmp(a, "--max-replacements") == 0)) {
            if (i + 1 >= argc) usage_missing(0);
            char *end = NULL;
            errno = 0;
            unsigned long v = strtoul(argv[++i], &end, 10);
            if (errno || !end || *end) {
                fprintf(stderr, "error: invalid value '%s' for '--max-replacements <LIMIT>': invalid digit found in string\n\nFor more information, try '--help'.\n", argv[i]);
                exit(2);
            }
            o->max_repl = (size_t)v;
            vals_start = i + 1;
        } else if (!end_opts && strncmp(a, "-n", 2) == 0 && a[2]) {
            char *end = NULL;
            unsigned long v = strtoul(a + 2, &end, 10);
            if (!end || *end) exit(2);
            o->max_repl = (size_t)v;
            vals_start = i + 1;
        } else if (!end_opts && strncmp(a, "--flags=", 8) == 0) {
            apply_flags(o, a + 8);
            vals_start = i + 1;
        } else if (!end_opts && (strcmp(a, "-f") == 0 || strcmp(a, "--flags") == 0)) {
            if (i + 1 >= argc) usage_missing(0);
            apply_flags(o, argv[++i]);
            vals_start = i + 1;
        } else if (!end_opts && strncmp(a, "-f", 2) == 0 && a[2]) {
            apply_flags(o, a + 2);
            vals_start = i + 1;
        } else if (!end_opts && a[0] == '-' && a[1] && a[1] != '-') {
            bool ok = true;
            for (int j = 1; a[j]; j++) {
                if (a[j] == 'p') o->preview = true;
                else if (a[j] == 'F') o->fixed = true;
                else ok = false;
            }
            if (!ok) {
                fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.\n", a);
                exit(2);
            }
            vals_start = i + 1;
        } else if (!end_opts && a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] <FIND> <REPLACE_WITH> [FILES]...\n\nFor more information, try '--help'.\n", a, a, a);
            exit(2);
        } else {
            vals_start = i;
            break;
        }
    }
    int nvals = argc - vals_start;
    if (nvals < 2) usage_missing(nvals);
    o->find = argv[vals_start];
    o->replace = argv[vals_start + 1];
    o->files = argv + vals_start + 2;
    o->nfiles = nvals - 2;
}

static char *do_replace(const char *input, size_t len, const Opts *o, size_t *outlen) {
    if (o->fixed) return replace_fixed(input, len, o, outlen);
    return replace_regex(input, len, o, outlen);
}

int main(int argc, char **argv) {
    Opts o;
    parse_args(argc, argv, &o);
    if (o.nfiles == 0) {
        size_t len, outlen;
        char *in = read_stream(stdin, &len);
        char *out = do_replace(in, len, &o, &outlen);
        fwrite(out, 1, outlen, stdout);
        free(in);
        free(out);
        return 0;
    }
    for (int i = 0; i < o.nfiles; i++) {
        size_t len, outlen;
        char *in = read_file(o.files[i], &len);
        char *out = do_replace(in, len, &o, &outlen);
        if (o.preview) {
            fwrite(out, 1, outlen, stdout);
        } else if (write_file(o.files[i], out, outlen) != 0) {
            fprintf(stderr, "error: could not write %s: %s\n", o.files[i], strerror(errno));
            free(in);
            free(out);
            return 1;
        }
        free(in);
        free(out);
    }
    return 0;
}
