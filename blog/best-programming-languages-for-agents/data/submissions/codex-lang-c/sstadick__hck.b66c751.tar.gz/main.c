#include <ctype.h>
#include <errno.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>

typedef struct {
    char *ptr;
    size_t len;
} Field;

typedef struct {
    int start;
    int end; /* 0 means through end */
} Range;

typedef struct {
    Range *v;
    size_t n, cap;
} Ranges;

typedef struct {
    char **v;
    size_t n, cap;
} Strings;

typedef struct {
    char **inputs;
    size_t ninputs, capinputs;
    char *output;
    char *delim;
    char *outdelim;
    bool literal_delim;
    bool use_input_delim;
    bool header_regex;
    bool try_decompress;
    bool try_compress;
    bool crlf;
    bool outdelim_set;
    Ranges fields;
    Ranges excludes;
    Strings header_fields;
    Strings exclude_headers;
} Opts;

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n);
    if (!q) {
        perror("realloc");
        exit(1);
    }
    return q;
}

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) {
        perror("strdup");
        exit(1);
    }
    return p;
}

static void push_string(Strings *s, const char *v) {
    if (s->n == s->cap) {
        s->cap = s->cap ? s->cap * 2 : 8;
        s->v = xrealloc(s->v, s->cap * sizeof(char *));
    }
    s->v[s->n++] = xstrdup(v);
}

static void push_input(Opts *o, const char *v) {
    if (o->ninputs == o->capinputs) {
        o->capinputs = o->capinputs ? o->capinputs * 2 : 8;
        o->inputs = xrealloc(o->inputs, o->capinputs * sizeof(char *));
    }
    o->inputs[o->ninputs++] = xstrdup(v);
}

static void push_range(Ranges *r, int start, int end) {
    if (r->n == r->cap) {
        r->cap = r->cap ? r->cap * 2 : 8;
        r->v = xrealloc(r->v, r->cap * sizeof(Range));
    }
    r->v[r->n++] = (Range){start, end};
}

static void log_error(const char *msg, const char *arg) {
    time_t t = time(NULL);
    struct tm tm;
    gmtime_r(&t, &tm);
    char buf[64];
    strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &tm);
    if (arg)
        fprintf(stderr, "[%s ERROR hck] %s%s\n", buf, msg, arg);
    else
        fprintf(stderr, "[%s ERROR hck] %s\n", buf, msg);
}

static void usage_short(FILE *f) {
    fprintf(f, "Usage: executable [OPTIONS] [INPUT]...\n\n");
    fprintf(f, "For more information, try '--help'.\n");
}

static void help(bool full) {
    if (full) {
        puts("* `delimiter` is a regex by default and a fixed substring with `-L` * `header-fields` allows for specifying a literal or a regex to match header names to select columns * both `header-fields` and `fields` order dictate the order of the output columns * input files (not stdin) are automatically compressed * the output delimiter can specified with `-D`\n");
    }
    puts("Usage: executable [OPTIONS] [INPUT]...\n");
    puts("Arguments:");
    puts("  [INPUT]...  Input files to parse, defaults to stdin\n");
    puts("Options:");
    puts("  -o, --output <OUTPUT>");
    puts("          Output file to write to, defaults to stdout");
    puts("  -d, --delimiter <DELIMITER>");
    puts("          Delimiter to use on input files [default: \\s+]");
    puts("  -L, --delim-is-literal");
    puts("          Treat the delimiter as a string literal");
    puts("  -I, --use-input-delim");
    puts("          Use the input delimiter as the output delimiter if the input is literal");
    puts("  -D, --output-delimiter <OUTPUT_DELIMITER>");
    puts("          Delimiter string to use on outputs [default: \"\\t\"]");
    puts("  -f, --fields <FIELDS>");
    puts("          Fields to keep in the output");
    puts("  -e, --exclude <EXCLUDE>");
    puts("          Fields to exclude from the output");
    puts("  -E, --exclude-header <EXCLUDE_HEADER>");
    puts("          Headers to exclude from the output");
    puts("  -F, --header-field <HEADER_FIELD>");
    puts("          A string literal or regex to select headers");
    puts("  -r, --header-is-regex");
    puts("          Treat the header_fields as regexs instead of string literals");
    puts("  -z, --try-decompress");
    puts("          Try to find the correct decompression method based on the file extensions");
    puts("  -Z, --try-compress");
    puts("          Try to gzip compress the output");
    puts("  -t, --compression-threads <COMPRESSION_THREADS>");
    puts("          Threads to use for compression [default: 4]");
    puts("  -l, --compression-level <COMPRESSION_LEVEL>");
    puts("          Compression level [default: 6]");
    puts("      --no-mmap");
    puts("          Disallow the possibility of using mmap");
    puts("      --crlf");
    puts("          Support CRLF newlines");
    puts("  -h, --help");
    puts("          Print help (see more with '--help')");
    puts("  -V, --version");
    puts("          Print version");
}

static bool parse_positive(const char *s, int *out) {
    if (!*s) return false;
    long v = 0;
    for (const char *p = s; *p; p++) {
        if (!isdigit((unsigned char)*p)) return false;
        v = v * 10 + (*p - '0');
        if (v > 2147483647) return false;
    }
    *out = (int)v;
    return true;
}

static void parse_ranges(Ranges *ranges, const char *spec) {
    char *copy = xstrdup(spec);
    char *save = NULL;
    for (char *tok = strtok_r(copy, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        char *dash = strchr(tok, '-');
        int a = 0, b = 0;
        if (!dash) {
            if (!parse_positive(tok, &a)) {
                log_error("Failed to parse field: ", tok);
                exit(1);
            }
            if (a < 1) {
                log_error("Fields and positions are numbered from 1: ", tok);
                exit(1);
            }
            push_range(ranges, a, a);
        } else {
            *dash = 0;
            char *right = dash + 1;
            if (*tok && !parse_positive(tok, &a)) {
                log_error("Failed to parse field: ", tok);
                exit(1);
            }
            if (*right && !parse_positive(right, &b)) {
                log_error("Failed to parse field: ", right);
                exit(1);
            }
            if (!*tok) a = 1;
            if (a < 1 || (*right && b < 1)) {
                log_error("Fields and positions are numbered from 1: ", a < 1 ? tok : right);
                exit(1);
            }
            push_range(ranges, a, *right ? b : 0);
        }
    }
    free(copy);
}

static char *take_arg(int *i, int argc, char **argv, const char *opt) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\n", opt);
        usage_short(stderr);
        exit(2);
    }
    return argv[++(*i)];
}

static void parse_args(int argc, char **argv, Opts *o) {
    o->delim = xstrdup("\\s+");
    o->outdelim = xstrdup("\t");
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "--")) {
            while (++i < argc) push_input(o, argv[i]);
            break;
        } else if (!strcmp(a, "-h")) {
            help(false); exit(0);
        } else if (!strcmp(a, "--help")) {
            help(true); exit(0);
        } else if (!strcmp(a, "-V") || !strcmp(a, "--version")) {
            puts("hck git:23bebe8-modified"); exit(0);
        } else if (!strcmp(a, "-L") || !strcmp(a, "--delim-is-literal")) o->literal_delim = true;
        else if (!strcmp(a, "-I") || !strcmp(a, "--use-input-delim")) o->use_input_delim = true;
        else if (!strcmp(a, "-r") || !strcmp(a, "--header-is-regex")) o->header_regex = true;
        else if (!strcmp(a, "-z") || !strcmp(a, "--try-decompress")) o->try_decompress = true;
        else if (!strcmp(a, "-Z") || !strcmp(a, "--try-compress")) o->try_compress = true;
        else if (!strcmp(a, "--crlf")) o->crlf = true;
        else if (!strcmp(a, "--no-mmap")) {}
        else if (!strcmp(a, "-o") || !strcmp(a, "--output")) { free(o->output); o->output = xstrdup(take_arg(&i, argc, argv, a)); }
        else if (!strcmp(a, "-d") || !strcmp(a, "--delimiter")) { free(o->delim); o->delim = xstrdup(take_arg(&i, argc, argv, a)); }
        else if (!strcmp(a, "-D") || !strcmp(a, "--output-delimiter")) { free(o->outdelim); o->outdelim = xstrdup(take_arg(&i, argc, argv, a)); o->outdelim_set = true; }
        else if (!strcmp(a, "-f") || !strcmp(a, "--fields")) parse_ranges(&o->fields, take_arg(&i, argc, argv, a));
        else if (!strcmp(a, "-e") || !strcmp(a, "--exclude")) parse_ranges(&o->excludes, take_arg(&i, argc, argv, a));
        else if (!strcmp(a, "-F") || !strcmp(a, "--header-field")) push_string(&o->header_fields, take_arg(&i, argc, argv, a));
        else if (!strcmp(a, "-E") || !strcmp(a, "--exclude-header")) push_string(&o->exclude_headers, take_arg(&i, argc, argv, a));
        else if (!strcmp(a, "-t") || !strcmp(a, "--compression-threads") || !strcmp(a, "-l") || !strcmp(a, "--compression-level")) (void)take_arg(&i, argc, argv, a);
        else if (a[0] == '-' && a[1] == 'L' && a[2]) {
            o->literal_delim = true;
            char *v = a + 3;
            if (a[2] == 'd') { free(o->delim); o->delim = xstrdup(v); }
            else if (a[2] == 'D') { free(o->outdelim); o->outdelim = xstrdup(v); o->outdelim_set = true; }
            else if (a[2] == 'f') parse_ranges(&o->fields, v);
            else if (a[2] == 'e') parse_ranges(&o->excludes, v);
            else if (a[2] == 'F') push_string(&o->header_fields, v);
            else if (a[2] == 'E') push_string(&o->exclude_headers, v);
            else if (a[2] == 'o') { free(o->output); o->output = xstrdup(v); }
            else { fprintf(stderr, "error: unexpected argument '%s' found\n\n", a); usage_short(stderr); exit(2); }
        } else if (a[0] == '-' && a[1] == 'r' && a[2]) {
            o->header_regex = true;
            char *v = a + 3;
            if (a[2] == 'F') push_string(&o->header_fields, v);
            else if (a[2] == 'E') push_string(&o->exclude_headers, v);
            else { fprintf(stderr, "error: unexpected argument '%s' found\n\n", a); usage_short(stderr); exit(2); }
        } else if (a[0] == '-' && a[1] && (!strncmp(a, "-d", 2) || !strncmp(a, "-D", 2) || !strncmp(a, "-f", 2) || !strncmp(a, "-e", 2) || !strncmp(a, "-F", 2) || !strncmp(a, "-E", 2) || !strncmp(a, "-o", 2)) ) {
            char opt[3] = {a[0], a[1], 0};
            char *v = a + 2;
            if (a[1] == 'd') { free(o->delim); o->delim = xstrdup(v); }
            else if (a[1] == 'D') { free(o->outdelim); o->outdelim = xstrdup(v); o->outdelim_set = true; }
            else if (a[1] == 'f') parse_ranges(&o->fields, v);
            else if (a[1] == 'e') parse_ranges(&o->excludes, v);
            else if (a[1] == 'F') push_string(&o->header_fields, v);
            else if (a[1] == 'E') push_string(&o->exclude_headers, v);
            else if (a[1] == 'o') { free(o->output); o->output = xstrdup(v); }
            (void)opt;
        } else if (a[0] == '-' && a[1]) {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n", a);
            usage_short(stderr);
            exit(2);
        } else push_input(o, a);
    }
    if (o->literal_delim && o->use_input_delim) {
        free(o->outdelim);
        o->outdelim = xstrdup(o->delim);
    }
}

static void trim_newline(char *line, size_t *len, bool crlf) {
    if (*len && line[*len - 1] == '\n') line[--(*len)] = 0;
    if (crlf && *len && line[*len - 1] == '\r') line[--(*len)] = 0;
    else if (!crlf && *len && line[*len - 1] == '\r') line[--(*len)] = 0;
}

static Field *split_literal(char *line, const char *delim, size_t *outn) {
    size_t cap = 8, n = 0, dlen = strlen(delim);
    Field *f = xrealloc(NULL, cap * sizeof(Field));
    char *p = line;
    if (dlen == 0) {
        f[n++] = (Field){line, strlen(line)};
        *outn = n; return f;
    }
    while (1) {
        char *q = strstr(p, delim);
        if (n == cap) { cap *= 2; f = xrealloc(f, cap * sizeof(Field)); }
        if (!q) {
            f[n++] = (Field){p, strlen(p)};
            break;
        }
        f[n++] = (Field){p, (size_t)(q - p)};
        p = q + dlen;
    }
    *outn = n;
    return f;
}

static void regex_die(const char *prefix, const char *pat, int err, regex_t *re, int code) {
    char buf[512];
    regerror(err, re, buf, sizeof(buf));
    if (prefix) fprintf(stderr, "%s '%s': %s\n", prefix, pat, buf);
    else fprintf(stderr, "Error: %s\n", buf);
    exit(code);
}

static char *translate_regex(const char *pat) {
    size_t cap = strlen(pat) * 16 + 16, n = 0;
    char *out = xrealloc(NULL, cap);
    for (size_t i = 0; pat[i]; i++) {
        if (pat[i] == '\\' && pat[i + 1]) {
            const char *rep = NULL;
            if (pat[i + 1] == 's') rep = "[[:space:]]";
            else if (pat[i + 1] == 'd') rep = "[[:digit:]]";
            else if (pat[i + 1] == 'w') rep = "[[:alnum:]_]";
            else if (pat[i + 1] == 't') rep = "\t";
            else if (pat[i + 1] == 'n') rep = "\n";
            else if (pat[i + 1] == 'r') rep = "\r";
            if (rep) {
                size_t rl = strlen(rep);
                if (n + rl + 1 > cap) { cap = (n + rl + 1) * 2; out = xrealloc(out, cap); }
                memcpy(out + n, rep, rl);
                n += rl;
                i++;
                continue;
            }
        }
        if (n + 2 > cap) { cap *= 2; out = xrealloc(out, cap); }
        out[n++] = pat[i];
    }
    out[n] = 0;
    return out;
}

static Field *split_regex(char *line, regex_t *re, size_t *outn) {
    size_t cap = 8, n = 0;
    Field *f = xrealloc(NULL, cap * sizeof(Field));
    char *p = line;
    while (1) {
        regmatch_t m;
        int rc = regexec(re, p, 1, &m, 0);
        if (rc == REG_NOMATCH) {
            if (n == cap) { cap *= 2; f = xrealloc(f, cap * sizeof(Field)); }
            f[n++] = (Field){p, strlen(p)};
            break;
        } else if (rc) {
            regex_die(NULL, "", rc, re, 1);
        }
        if (n == cap) { cap *= 2; f = xrealloc(f, cap * sizeof(Field)); }
        f[n++] = (Field){p, (size_t)m.rm_so};
        size_t adv = (size_t)m.rm_eo;
        if (adv == 0) adv = 1;
        p += adv;
        if (!*p && (size_t)m.rm_eo != 0) {
            if (n == cap) { cap *= 2; f = xrealloc(f, cap * sizeof(Field)); }
            f[n++] = (Field){p, 0};
            break;
        }
    }
    *outn = n;
    return f;
}

static bool in_ranges(const Ranges *r, int idx, int total) {
    for (size_t i = 0; i < r->n; i++) {
        int end = r->v[i].end ? r->v[i].end : total;
        if (idx >= r->v[i].start && idx <= end) return true;
    }
    return false;
}

static bool selected_once(bool *used, int idx) {
    if (idx < 1 || used[idx]) return false;
    used[idx] = true;
    return true;
}

static bool match_literal(Field f, const char *s) {
    return strlen(s) == f.len && strncmp(f.ptr, s, f.len) == 0;
}

static bool match_re(Field f, const char *pat) {
    regex_t re;
    char *tp = translate_regex(pat);
    int rc = regcomp(&re, tp, REG_EXTENDED | REG_NOSUB);
    if (rc) {
        fprintf(stderr, "error: invalid value '%s' for '--header-field <HEADER_FIELD>': ", pat);
        regex_die(NULL, pat, rc, &re, 2);
    }
    char old = f.ptr[f.len];
    f.ptr[f.len] = 0;
    rc = regexec(&re, f.ptr, 0, NULL, 0);
    f.ptr[f.len] = old;
    regfree(&re);
    free(tp);
    return rc == 0;
}

static int *build_header_indices(Opts *o, Field *h, size_t hn, size_t *outn) {
    bool *used = calloc(hn + 1, sizeof(bool));
    int *idx = NULL;
    size_t n = 0, cap = 0;
    for (size_t s = 0; s < o->fields.n; s++) {
        int end = o->fields.v[s].end ? o->fields.v[s].end : (int)hn;
        for (int i = o->fields.v[s].start; i <= end && i <= (int)hn; i++) {
            if (selected_once(used, i)) {
                if (n == cap) { cap = cap ? cap * 2 : 8; idx = xrealloc(idx, cap * sizeof(int)); }
                idx[n++] = i;
            }
        }
    }
    for (size_t s = 0; s < o->header_fields.n; s++) {
        for (int i = 1; i <= (int)hn; i++) {
            bool m = o->header_regex ? match_re(h[i-1], o->header_fields.v[s]) : match_literal(h[i-1], o->header_fields.v[s]);
            if (m && selected_once(used, i)) {
                if (n == cap) { cap = cap ? cap * 2 : 8; idx = xrealloc(idx, cap * sizeof(int)); }
                idx[n++] = i;
            }
        }
    }
    if (o->fields.n == 0 && o->header_fields.n == 0) {
        for (int i = 1; i <= (int)hn; i++) {
            if (n == cap) { cap = cap ? cap * 2 : 8; idx = xrealloc(idx, cap * sizeof(int)); }
            idx[n++] = i;
        }
    }
    size_t w = 0;
    for (size_t j = 0; j < n; j++) {
        int i = idx[j];
        bool ex = in_ranges(&o->excludes, i, (int)hn);
        for (size_t s = 0; s < o->exclude_headers.n && !ex; s++)
            ex = o->header_regex ? match_re(h[i-1], o->exclude_headers.v[s]) : match_literal(h[i-1], o->exclude_headers.v[s]);
        if (!ex) idx[w++] = i;
    }
    free(used);
    if (o->header_fields.n && w == 0) {
        log_error("No headers matched", NULL);
        exit(1);
    }
    *outn = w;
    return idx;
}

static int *build_line_indices(Opts *o, size_t fn, size_t *outn) {
    bool *used = calloc(fn + 1, sizeof(bool));
    int *idx = NULL;
    size_t n = 0, cap = 0;
    if (o->fields.n == 0) {
        for (int i = 1; i <= (int)fn; i++) {
            if (!in_ranges(&o->excludes, i, (int)fn)) {
                if (n == cap) { cap = cap ? cap * 2 : 8; idx = xrealloc(idx, cap * sizeof(int)); }
                idx[n++] = i;
            }
        }
    } else {
        for (size_t s = 0; s < o->fields.n; s++) {
            int end = o->fields.v[s].end ? o->fields.v[s].end : (int)fn;
            for (int i = o->fields.v[s].start; i <= end && i <= (int)fn; i++) {
                if (!in_ranges(&o->excludes, i, (int)fn) && selected_once(used, i)) {
                    if (n == cap) { cap = cap ? cap * 2 : 8; idx = xrealloc(idx, cap * sizeof(int)); }
                    idx[n++] = i;
                }
            }
        }
    }
    free(used);
    *outn = n;
    return idx;
}

static void write_selected(FILE *out, Field *f, size_t fn, int *idx, size_t n, const char *od) {
    for (size_t j = 0; j < n; j++) {
        if (j) fputs(od, out);
        int i = idx[j];
        if (i >= 1 && i <= (int)fn) fwrite(f[i-1].ptr, 1, f[i-1].len, out);
    }
    fputc('\n', out);
}

static bool gz_ext(const char *p) {
    size_t n = strlen(p);
    return (n > 3 && !strcmp(p + n - 3, ".gz")) || (n > 4 && !strcmp(p + n - 4, ".bgz"));
}

static FILE *open_input(Opts *o, const char *path, bool *pipep) {
    *pipep = false;
    if (!path) return stdin;
    if (o->try_decompress && gz_ext(path)) {
        char cmd[4096];
        snprintf(cmd, sizeof(cmd), "gzip -cd -- '%s'", path);
        FILE *p = popen(cmd, "r");
        if (p) { *pipep = true; return p; }
    }
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "Error: %s: %s\n", path, strerror(errno));
        exit(1);
    }
    return f;
}

static FILE *open_output(Opts *o, bool *pipep) {
    *pipep = false;
    if (o->try_compress) {
        char cmd[4096];
        if (o->output) snprintf(cmd, sizeof(cmd), "gzip -c > '%s'", o->output);
        else snprintf(cmd, sizeof(cmd), "gzip -c");
        FILE *p = popen(cmd, "w");
        if (!p) { perror("gzip"); exit(1); }
        *pipep = true; return p;
    }
    if (!o->output) return stdout;
    FILE *f = fopen(o->output, "w");
    if (!f) { fprintf(stderr, "Error: %s: %s\n", o->output, strerror(errno)); exit(1); }
    return f;
}

static void process_stream(Opts *o, FILE *in, FILE *out, regex_t *delim_re, int **hidx, size_t *hidxn, bool *have_header) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t len;
    while ((len = getline(&line, &cap, in)) >= 0) {
        size_t l = (size_t)len;
        trim_newline(line, &l, o->crlf);
        size_t fn = 0;
        Field *f = o->literal_delim ? split_literal(line, o->delim, &fn) : split_regex(line, delim_re, &fn);
        int *idx = NULL;
        size_t idxn = 0;
        if (o->header_fields.n || o->exclude_headers.n) {
            if (!*have_header) {
                *hidx = build_header_indices(o, f, fn, hidxn);
                *have_header = true;
                write_selected(out, f, fn, *hidx, *hidxn, o->outdelim);
                free(f);
                continue;
            } else {
                idx = *hidx; idxn = *hidxn;
            }
        } else {
            idx = build_line_indices(o, fn, &idxn);
        }
        write_selected(out, f, fn, idx, idxn, o->outdelim);
        if (!(o->header_fields.n || o->exclude_headers.n)) free(idx);
        free(f);
    }
    free(line);
}

int main(int argc, char **argv) {
    Opts o;
    memset(&o, 0, sizeof(o));
    parse_args(argc, argv, &o);

    regex_t delim_re;
    char *translated_delim = NULL;
    if (!o.literal_delim) {
        translated_delim = translate_regex(o.delim);
        int rc = regcomp(&delim_re, translated_delim, REG_EXTENDED);
        if (rc) regex_die(NULL, o.delim, rc, &delim_re, 1);
    }

    bool outpipe = false;
    FILE *out = open_output(&o, &outpipe);
    int *hidx = NULL;
    size_t hidxn = 0;
    bool have_header = false;

    if (o.ninputs == 0) {
        process_stream(&o, stdin, out, &delim_re, &hidx, &hidxn, &have_header);
    } else {
        for (size_t i = 0; i < o.ninputs; i++) {
            bool inpipe = false;
            FILE *in = open_input(&o, o.inputs[i], &inpipe);
            process_stream(&o, in, out, &delim_re, &hidx, &hidxn, &have_header);
            if (inpipe) pclose(in); else fclose(in);
        }
    }
    if (hidx) free(hidx);
    if (!o.literal_delim) {
        regfree(&delim_re);
        free(translated_delim);
    }
    if (outpipe) {
        int st = pclose(out);
        if (st == -1 || !WIFEXITED(st) || WEXITSTATUS(st) != 0) return 1;
    } else if (out != stdout) fclose(out);
    return 0;
}
