#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef enum { V_NULL, V_BOOL, V_NUM, V_STR, V_ARR, V_OBJ } Type;

typedef struct Value Value;
typedef struct Pair Pair;

struct Value {
  Type type;
  char *text;
  bool boolean;
  Value **items;
  size_t count;
  Pair *pairs;
};

struct Pair {
  char *key;
  Value *value;
};

typedef struct {
  const char *s;
  size_t len;
  size_t pos;
  int line;
  int col;
  char err[256];
} Parser;

static const char *HELP =
"  json-tui {OPTIONS} [file]\n"
"\n"
"    A JSON terminal UI\n"
"\n"
"  OPTIONS:\n"
"\n"
"      file                              A JSON file. Omit to read from stdin.\n"
"      -h, --help                        Display this help menu.\n"
"      -v, --version                     Print version.\n"
"      -k, --key, --keybinding           Display key binding.\n"
"      -f, --fullscreen                  Display the JSON in fullscreen, in an\n"
"                                        alternate buffer\n"
"      \"--\" can be used to terminate flag options and force all following\n"
"      arguments to be treated as positional options\n"
"\n"
"    If no file is given, json-tui reads JSON from the standard input\n"
"    Please report bugs to:https://github.com/ArthurSonzogni/json-tui/issues\n";

static void print_keybinding(void) {
  fputs("┌───────────┬────────────────┐\r\n", stdout);
  fputs("│\033[36m\033[49mkeys       \033[39m\033[49m│\033[36m\033[49maction          \033[39m\033[49m│\r\n", stdout);
  fputs("├───────────┼────────────────┤\r\n", stdout);
  fputs("│Navigate   │← ↑ ↓ →         │\r\n", stdout);
  fputs("│           │h j k l         │\r\n", stdout);
  fputs("│           │Mouse::WheelUp  │\r\n", stdout);
  fputs("│           │Mouse::WheelDown│\r\n", stdout);
  fputs("├───────────┼────────────────┤\r\n", stdout);
  fputs("│Toggle     │enter           │\r\n", stdout);
  fputs("│           │Mouse::Left     │\r\n", stdout);
  fputs("├───────────┼────────────────┤\r\n", stdout);
  fputs("│Deep       │                │\r\n", stdout);
  fputs("│ - Expand  │+               │\r\n", stdout);
  fputs("│ - Collapse│-               │\r\n", stdout);
  fputs("├───────────┼────────────────┤\r\n", stdout);
  fputs("│Exit       │Escape          │\r\n", stdout);
  fputs("│           │q               │\r\n", stdout);
  fputs("├───────────┼────────────────┤\r\n", stdout);
  fputs("│Navigate   │                │\r\n", stdout);
  fputs("│ - first   │page-up         │\r\n", stdout);
  fputs("│ - last    │page-down       │\r\n", stdout);
  fputs("│ - top     │gg              │\r\n", stdout);
  fputs("│ - bottom  │G               │\r\n", stdout);
  fputs("└───────────┴────────────────┘", stdout);
  fputc('\0', stdout);
  fputc('\n', stdout);
}

static void *xcalloc(size_t n, size_t s) {
  void *p = calloc(n, s);
  if (!p) {
    fputs("Out of memory\n", stderr);
    exit(1);
  }
  return p;
}

static char *xstrndup(const char *s, size_t n) {
  char *p = malloc(n + 1);
  if (!p) {
    fputs("Out of memory\n", stderr);
    exit(1);
  }
  memcpy(p, s, n);
  p[n] = 0;
  return p;
}

static void adv(Parser *p) {
  if (p->pos >= p->len) return;
  if (p->s[p->pos] == '\n') {
    p->line++;
    p->col = 1;
  } else {
    p->col++;
  }
  p->pos++;
}

static void seterr(Parser *p, const char *msg) {
  if (p->err[0]) return;
  snprintf(p->err, sizeof(p->err),
           "[json.exception.parse_error.101] parse error at line %d, column %d: syntax error while parsing value - %s",
           p->line, p->col, msg);
}

static void ws(Parser *p) {
  while (p->pos < p->len && strchr(" \t\r\n", p->s[p->pos])) adv(p);
}

static bool consume(Parser *p, char c) {
  if (p->pos < p->len && p->s[p->pos] == c) {
    adv(p);
    return true;
  }
  return false;
}

static Value *parse_value(Parser *p);

static char *parse_string_text(Parser *p) {
  if (!consume(p, '"')) {
    seterr(p, "expected string literal");
    return NULL;
  }
  size_t cap = 32, n = 0;
  char *out = malloc(cap);
  if (!out) exit(1);
  while (p->pos < p->len) {
    unsigned char c = (unsigned char)p->s[p->pos];
    if (c == '"') {
      adv(p);
      out[n] = 0;
      return out;
    }
    if (c < 0x20) {
      seterr(p, "invalid string: control character");
      free(out);
      return NULL;
    }
    if (c == '\\') {
      adv(p);
      if (p->pos >= p->len) {
        seterr(p, "invalid string: missing escape");
        free(out);
        return NULL;
      }
      c = (unsigned char)p->s[p->pos];
      switch (c) {
        case '"': case '\\': case '/': break;
        case 'b': c = '\b'; break;
        case 'f': c = '\f'; break;
        case 'n': c = '\n'; break;
        case 'r': c = '\r'; break;
        case 't': c = '\t'; break;
        case 'u': {
          for (int i = 0; i < 4; i++) {
            adv(p);
            if (p->pos >= p->len || !isxdigit((unsigned char)p->s[p->pos])) {
              seterr(p, "invalid string: ill-formed \\u escape");
              free(out);
              return NULL;
            }
          }
          c = '?';
          break;
        }
        default:
          seterr(p, "invalid string: forbidden character after backslash");
          free(out);
          return NULL;
      }
    }
    if (n + 4 >= cap) {
      cap *= 2;
      out = realloc(out, cap);
      if (!out) exit(1);
    }
    out[n++] = (char)c;
    adv(p);
  }
  seterr(p, "invalid string: missing closing quote");
  free(out);
  return NULL;
}

static Value *new_value(Type t) {
  Value *v = xcalloc(1, sizeof(Value));
  v->type = t;
  return v;
}

static Value *parse_number(Parser *p) {
  size_t start = p->pos;
  consume(p, '-');
  if (consume(p, '0')) {
  } else if (p->pos < p->len && isdigit((unsigned char)p->s[p->pos])) {
    while (p->pos < p->len && isdigit((unsigned char)p->s[p->pos])) adv(p);
  } else {
    seterr(p, "invalid number");
    return NULL;
  }
  if (consume(p, '.')) {
    if (p->pos >= p->len || !isdigit((unsigned char)p->s[p->pos])) {
      seterr(p, "invalid number");
      return NULL;
    }
    while (p->pos < p->len && isdigit((unsigned char)p->s[p->pos])) adv(p);
  }
  if (p->pos < p->len && (p->s[p->pos] == 'e' || p->s[p->pos] == 'E')) {
    adv(p);
    if (p->pos < p->len && (p->s[p->pos] == '+' || p->s[p->pos] == '-')) adv(p);
    if (p->pos >= p->len || !isdigit((unsigned char)p->s[p->pos])) {
      seterr(p, "invalid number");
      return NULL;
    }
    while (p->pos < p->len && isdigit((unsigned char)p->s[p->pos])) adv(p);
  }
  Value *v = new_value(V_NUM);
  v->text = xstrndup(p->s + start, p->pos - start);
  return v;
}

static bool literal(Parser *p, const char *lit) {
  size_t n = strlen(lit);
  if (p->pos + n <= p->len && memcmp(p->s + p->pos, lit, n) == 0) {
    for (size_t i = 0; i < n; i++) adv(p);
    return true;
  }
  return false;
}

static Value *parse_array(Parser *p) {
  consume(p, '[');
  Value *v = new_value(V_ARR);
  ws(p);
  if (consume(p, ']')) return v;
  while (!p->err[0]) {
    ws(p);
    Value *item = parse_value(p);
    if (!item) return v;
    v->items = realloc(v->items, sizeof(Value *) * (v->count + 1));
    if (!v->items) exit(1);
    v->items[v->count++] = item;
    ws(p);
    if (consume(p, ']')) return v;
    if (!consume(p, ',')) {
      seterr(p, "expected ',' or ']'");
      return v;
    }
  }
  return v;
}

static Value *parse_object(Parser *p) {
  consume(p, '{');
  Value *v = new_value(V_OBJ);
  ws(p);
  if (consume(p, '}')) return v;
  while (!p->err[0]) {
    ws(p);
    char *key = parse_string_text(p);
    if (!key) return v;
    ws(p);
    if (!consume(p, ':')) {
      free(key);
      seterr(p, "expected ':'");
      return v;
    }
    ws(p);
    Value *val = parse_value(p);
    if (!val) {
      free(key);
      return v;
    }
    v->pairs = realloc(v->pairs, sizeof(Pair) * (v->count + 1));
    if (!v->pairs) exit(1);
    v->pairs[v->count].key = key;
    v->pairs[v->count].value = val;
    v->count++;
    ws(p);
    if (consume(p, '}')) return v;
    if (!consume(p, ',')) {
      seterr(p, "expected ',' or '}'");
      return v;
    }
  }
  return v;
}

static Value *parse_value(Parser *p) {
  ws(p);
  if (p->pos >= p->len) {
    seterr(p, "unexpected end of input");
    return NULL;
  }
  char c = p->s[p->pos];
  if (c == '"') {
    Value *v = new_value(V_STR);
    v->text = parse_string_text(p);
    if (!v->text) {
      free(v);
      return NULL;
    }
    return v;
  }
  if (c == '{') return parse_object(p);
  if (c == '[') return parse_array(p);
  if (c == '-' || isdigit((unsigned char)c)) return parse_number(p);
  if (literal(p, "true")) {
    Value *v = new_value(V_BOOL);
    v->boolean = true;
    return v;
  }
  if (literal(p, "false")) {
    Value *v = new_value(V_BOOL);
    v->boolean = false;
    return v;
  }
  if (literal(p, "null")) return new_value(V_NULL);
  seterr(p, "invalid literal");
  return NULL;
}

static void free_value(Value *v) {
  if (!v) return;
  free(v->text);
  for (size_t i = 0; i < v->count; i++) {
    if (v->type == V_ARR) free_value(v->items[i]);
    if (v->type == V_OBJ) {
      free(v->pairs[i].key);
      free_value(v->pairs[i].value);
    }
  }
  free(v->items);
  free(v->pairs);
  free(v);
}

static char *read_all(FILE *f) {
  size_t cap = 8192, n = 0;
  char *buf = malloc(cap + 1);
  if (!buf) exit(1);
  for (;;) {
    if (n == cap) {
      cap *= 2;
      buf = realloc(buf, cap + 1);
      if (!buf) exit(1);
    }
    size_t r = fread(buf + n, 1, cap - n, f);
    n += r;
    if (r == 0) {
      if (ferror(f)) {
        free(buf);
        return NULL;
      }
      break;
    }
  }
  buf[n] = 0;
  return buf;
}

static void indent(int n) {
  for (int i = 0; i < n; i++) fputs("  ", stdout);
}

static void print_escaped(const char *s) {
  fputc('"', stdout);
  for (; *s; s++) {
    unsigned char c = (unsigned char)*s;
    switch (c) {
      case '"': fputs("\\\"", stdout); break;
      case '\\': fputs("\\\\", stdout); break;
      case '\b': fputs("\\b", stdout); break;
      case '\f': fputs("\\f", stdout); break;
      case '\n': fputs("\\n", stdout); break;
      case '\r': fputs("\\r", stdout); break;
      case '\t': fputs("\\t", stdout); break;
      default:
        if (c < 0x20) printf("\\u%04x", c);
        else fputc(c, stdout);
    }
  }
  fputc('"', stdout);
}

static void print_value(Value *v, int depth);

static void print_scalar(Value *v) {
  switch (v->type) {
    case V_NULL:
      fputs("\033[90m\033[49mnull\033[39m\033[49m", stdout);
      break;
    case V_BOOL:
      fputs("\033[96m\033[49m", stdout);
      fputs(v->boolean ? "true" : "false", stdout);
      fputs("\033[39m\033[49m", stdout);
      break;
    case V_NUM:
      fputs("\033[96m\033[49m", stdout);
      fputs(v->text, stdout);
      fputs("\033[39m\033[49m", stdout);
      break;
    case V_STR:
      fputs("\033[32m\033[49m", stdout);
      print_escaped(v->text);
      fputs("\033[39m\033[49m", stdout);
      break;
    default:
      print_value(v, 0);
  }
}

static void print_value(Value *v, int depth) {
  switch (v->type) {
    case V_OBJ:
      if (v->count == 0) {
        fputs("{}", stdout);
        return;
      }
      fputs("{\n", stdout);
      for (size_t i = 0; i < v->count; i++) {
        indent(depth + 1);
        fputs("\033[94m\033[49m", stdout);
        print_escaped(v->pairs[i].key);
        fputs("\033[39m\033[49m: ", stdout);
        print_value(v->pairs[i].value, depth + 1);
        if (i + 1 != v->count) fputc(',', stdout);
        fputc('\n', stdout);
      }
      indent(depth);
      fputc('}', stdout);
      break;
    case V_ARR:
      if (v->count == 0) {
        fputs("[]", stdout);
        return;
      }
      fputs("[\n", stdout);
      for (size_t i = 0; i < v->count; i++) {
        indent(depth + 1);
        print_value(v->items[i], depth + 1);
        if (i + 1 != v->count) fputc(',', stdout);
        fputc('\n', stdout);
      }
      indent(depth);
      fputc(']', stdout);
      break;
    default:
      print_scalar(v);
  }
}

static int render_json(const char *input, bool fullscreen) {
  Parser p = {input, strlen(input), 0, 1, 1, {0}};
  Value *root = parse_value(&p);
  ws(&p);
  if (!p.err[0] && p.pos < p.len) {
    snprintf(p.err, sizeof(p.err),
             "[json.exception.parse_error.101] parse error at line %d, column %d: syntax error while parsing value - unexpected trailing input",
             p.line, p.col);
  }
  if (p.err[0]) {
    puts(p.err);
    free_value(root);
    return 1;
  }
  if (fullscreen) fputs("\033[?1049h", stdout);
  print_value(root, 0);
  fputc('\n', stdout);
  if (fullscreen) fputs("\033[?1049l", stdout);
  free_value(root);
  return 0;
}

int main(int argc, char **argv) {
  bool fullscreen = false;
  const char *file = NULL;
  bool positional = false;
  for (int i = 1; i < argc; i++) {
    const char *a = argv[i];
    if (!positional && strcmp(a, "--") == 0) {
      positional = true;
      continue;
    }
    if (!positional && (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0)) {
      fputs(HELP, stdout);
      return 0;
    }
    if (!positional && (strcmp(a, "-v") == 0 || strcmp(a, "--version") == 0)) {
      puts("1.4.1");
      return 0;
    }
    if (!positional && (strcmp(a, "-k") == 0 || strcmp(a, "--key") == 0 ||
                        strcmp(a, "--keybinding") == 0 || strcmp(a, "-key") == 0 ||
                        strcmp(a, "-keybinding") == 0)) {
      print_keybinding();
      return 0;
    }
    if (!positional && (strcmp(a, "-f") == 0 || strcmp(a, "--fullscreen") == 0)) {
      fullscreen = true;
      continue;
    }
    if (!positional && a[0] == '-') {
      puts("Invalid arguments");
      return 1;
    }
    if (file) {
      puts("Invalid arguments");
      return 1;
    }
    file = a;
  }

  char *input = NULL;
  if (file) {
    FILE *f = fopen(file, "rb");
    if (!f) {
      printf("Could not open file %s\n", file);
      return 1;
    }
    input = read_all(f);
    fclose(f);
    if (!input) {
      printf("Could not open file %s\n", file);
      return 1;
    }
  } else {
    puts("Reading from stdin...");
    input = read_all(stdin);
    if (!input) return 1;
  }
  int rc = render_json(input, fullscreen);
  free(input);
  return rc;
}
