#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <stdint.h>
#include <sys/stat.h>
#include <zlib.h>

#define PROG "./executable"

typedef struct { int w,h; unsigned char r,g,b,a; int ok; } Image;
typedef struct { int w,h; int have_size; char format[16]; char colors[16]; char symbols[128]; int label; } Opt;

static const char *help_text =
"Usage:\n"
"  ./executable [OPTION...] [FILE...]\n"
"\n"
"  Chafa (Character Art Facsimile) terminal graphics and character art generator.\n"
"\n"
"General options:\n"
"      --files=PATH   Read list of files to process from PATH, or \"-\" for stdin.\n"
"      --files0=PATH  Similar to --files, using NUL separator instead of newline.\n"
"  -h, --help         Show help.\n"
"      --probe=ARG    Probe terminal's capabilities and wait for response [auto,\n"
"                     on, off]. A positive real number denotes the maximum time\n"
"                     to wait for a response, in seconds. Defaults to 5.0.\n"
"      --probe-mode=ARG  How to probe the terminal [any, ctty, stdio].\n"
"      --version      Show version.\n"
"  -v, --verbose      Be verbose.\n"
"\n"
"Output encoding:\n"
"  -f, --format=FORMAT  Set output format; one of [iterm, kitty, sixels,\n"
"                     symbols]. Iterm, kitty and sixels yield much higher\n"
"                     quality but enjoy limited support. Symbols mode yields\n"
"                     beautiful character art.\n"
"  -O, --optimize=NUM  Compress the output by using control sequences\n"
"                     intelligently [0-9]. 0 disables, 9 enables every\n"
"                     available optimization. Defaults to 5, except for when\n"
"                     used with \"-c none\", where it defaults to 0.\n"
"      --relative=BOOL  Use relative cursor positioning [on, off]. When on,\n"
"                     control sequences will be used to position images relative\n"
"                     to the cursor. When off, newlines will be used to separate\n"
"                     rows instead for e.g. 'less -R' interop. Defaults to off.\n"
"      --passthrough=MODE  Graphics protocol passthrough [auto, none, screen,\n"
"                     tmux]. Used to show pixel graphics through multiplexers.\n"
"      --polite=BOOL  Polite mode [on, off]. Inhibits escape sequences that may\n"
"                     confuse other programs. Defaults to off.\n"
"\n"
"Size and layout:\n"
"      --align=ALIGN  Horizontal and vertical alignment (e.g. \"top,left\").\n"
"      --clear        Clear screen before processing each file.\n"
"      --exact-size=MODE  Try to match the input's size exactly [auto, on, off].\n"
"      --fit-width    Fit images to view's width, possibly exceeding its height.\n"
"      --font-ratio=W/H  Target font's width/height ratio. Can be specified as\n"
"                     a real number or a fraction. Defaults to 1/2.\n"
"      --grid=CxR     Lay out images in a grid of CxR columns/rows per screenful.\n"
"                     C or R may be omitted, e.g. \"--grid 4\". Can be \"auto\".\n"
"  -g                 Alias for \"--grid auto\".\n"
"      --label=BOOL   Labeling [on, off]. Filenames below images. Default off.\n"
"  -l                 Alias for \"--label on\".\n"
"      --link=BOOL    Link labels [auto, on, off]. Turns labels into clickable\n"
"                     hyperlinks. Use with \"--label on\". Defaults to auto.\n"
"      --margin-bottom=NUM  When terminal size is detected, reserve at least NUM\n"
"                     rows at the bottom as a safety margin. Can be used to\n"
"                     prevent images from scrolling out. Defaults to 1.\n"
"      --margin-right=NUM  When terminal size is detected, reserve at least NUM\n"
"                     columns safety margin on right-hand side. Defaults to 0.\n"
"      --scale=NUM    Scale image, respecting view's dimensions. 1.0 approximates\n"
"                     image's pixel dimensions. Specify \"max\" to fit view.\n"
"                     Defaults to 1.0 for pixel graphics and 4.0 for symbols.\n"
"  -s, --size=WxH     Set maximum image dimensions in columns and rows. By\n"
"                     default this will be equal to the view size.\n"
"      --stretch      Stretch image to fit output dimensions; ignore aspect.\n"
"                     Implies --scale max.\n"
"      --view-size=WxH  Set the view size in columns and rows. By default this\n"
"                     will be the size of your terminal, or 80x25 if size\n"
"                     detection fails. If one dimension is omitted, it will\n"
"                     be set to a reasonable approximation of infinity.\n"
"\n"
"Animation and timing:\n"
"      --animate=BOOL  Whether to allow animation [on, off]. Defaults to on.\n"
"                     When off, will show a still frame from each animation.\n"
"  -d, --duration=SECONDS  How long to show each file. If showing a single file,\n"
"                     defaults to zero for a still image and infinite for an\n"
"                     animation. For multiple files, defaults to zero. Animations\n"
"                     will always be played through at least once.\n"
"      --speed=SPEED  Animation speed. Either a unitless multiplier, or a real\n"
"                     number followed by \"fps\" to apply a specific framerate.\n"
"      --watch        Watch a single input file, redisplaying it whenever its\n"
"                     contents change. Will run until manually interrupted\n"
"                     or, if --duration is set, until it expires.\n"
"\n"
"Colors and processing:\n"
"      --bg=COLOR     Background color of display (color name or hex).\n"
"  -c, --colors=MODE  Set output color mode; one of [none, 2, 8, 16/8, 16, 240,\n"
"                     256, full]. Defaults to best guess.\n"
"      --color-extractor=EXTR  Method for extracting color from an area\n"
"                     [average, median]. Average is the default.\n"
"      --color-space=CS  Color space used for quantization; one of [rgb, din99d].\n"
"                     Defaults to rgb, which is faster but less accurate.\n"
"      --dither=DITHER  Set output dither mode; one of [none, ordered,\n"
"                     diffusion, noise]. No effect with 24-bit color. Defaults to\n"
"                     noise for sixels, none otherwise.\n"
"      --dither-grain=WxH  Set dimensions of dither grains in 1/8ths of a\n"
"                     character cell [1, 2, 4, 8]. Defaults to 4x4.\n"
"      --dither-intensity=NUM  Multiplier for dither intensity [0.0 - inf].\n"
"                     Defaults to 1.0.\n"
"      --fg=COLOR     Foreground color of display (color name or hex).\n"
"      --invert       Swaps --fg and --bg. Useful with light terminal background.\n"
"  -p, --preprocess=BOOL  Image preprocessing [on, off]. Defaults to on with 16\n"
"                     colors or lower, off otherwise.\n"
"  -t, --threshold=NUM  Lower threshold for full transparency [0.0 - 1.0].\n"
"\n"
"Resource allocation:\n"
"      --threads=NUM  Maximum number of CPU threads to use. If left unspecified\n"
"                     or negative, this will equal available CPU cores.\n"
"  -w, --work=NUM     How hard to work in terms of CPU and memory [1-9]. 1 is the\n"
"                     cheapest, 9 is the most accurate. Defaults to 5.\n"
"\n"
"Extra options for symbol encoding:\n"
"      --fg-only      Leave the background color untouched. This produces\n"
"                     character-cell output using foreground colors only.\n"
"      --fill=SYMS    Specify character symbols to use for fill/gradients.\n"
"                     Defaults to none. See below for full usage.\n"
"      --glyph-file=FILE  Load glyph information from FILE, which can be any\n"
"                     font file supported by FreeType (TTF, PCF, etc).\n"
"      --symbols=SYMS  Specify character symbols to employ in final output.\n"
"                     See below for full usage and a list of symbol classes.\n"
"\n"
"Accepted classes for --symbols and --fill:\n"
"  all        ascii   braille   extra      imported  narrow   solid      ugly\n"
"  alnum      bad     diagonal  geometric  inverted  none     space      vhalf\n"
"  alpha      block   digit     half       latin     quad     stipple    wedge\n"
"  ambiguous  border  dot       hhalf      legacy    sextant  technical  wide\n"
"\n"
"  These can be combined with + and -, e.g. block+border-diagonal or all-wide.\n"
"\n"
"Examples:\n"
"  $ chafa --scale max in.jpg                           # As big as will fit\n"
"  $ chafa --clear --align mid,mid -d 5 *.gif           # Centered slideshow\n"
"  $ chafa -f symbols --symbols ascii -c none in.png    # Old-school ASCII art\n"
"  $ find /usr -type f -print0 | chafa --files0 - -g -l # System images (Unix)\n"
"\n"
"If your OS comes with manual pages, you can type 'man chafa' for more.\n";

static void version(void){
    puts("Chafa version 1.19.0\n");
    puts("Loaders:  GIF JPEG PNG QOI SVG TIFF WebP XWD");
    puts("Features: mmx sse4.1 popcnt avx2");
    puts("Applying: mmx sse4.1 popcnt avx2\n");
    puts("Copyright (C) 2018-2025 Hans Petter Jansson et al.");
    puts("Incl. libnsgif copyright (C) 2004 Richard Wilson, copyright (C) 2008 Sean Fox");
    puts("Incl. LodePNG copyright (C) 2005-2018 Lode Vandevenne");
    puts("Incl. QOI decoder copyright (C) 2021 Dominic Szablewski\n");
    puts("This is free software; see the source for copying conditions. There is NO");
    puts("warranty; not even for MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.");
}
static int in_list(const char *s, const char **v){ for(int i=0;v[i];i++) if(!strcmp(s,v[i])) return 1; return 0; }
static int parse_size(const char *s,int *w,int *h){ const char *x=strchr(s,'x'); if(!x) return 0; if(x==s) *w=80; else { char *e; long n=strtol(s,&e,10); if(e!=x||n<1) return 0; *w=(int)n; } if(!x[1]) *h=25; else { char *e; long n=strtol(x+1,&e,10); if(*e||n<1) return 0; *h=(int)n; } return 1; }
static unsigned read32(const unsigned char *p){ return ((unsigned)p[0]<<24)|((unsigned)p[1]<<16)|((unsigned)p[2]<<8)|p[3]; }
static unsigned char paeth(unsigned char a,unsigned char b,unsigned char c){ int p=a+b-c, pa=abs(p-a), pb=abs(p-b), pc=abs(p-c); return pa<=pb&&pa<=pc?a:(pb<=pc?b:c); }
static unsigned char *read_file(const char *path,size_t *len){ FILE *f=!strcmp(path,"-")?stdin:fopen(path,"rb"); if(!f) return NULL; size_t cap=4096,n=0; unsigned char *b=malloc(cap); int c; while((c=fgetc(f))!=EOF){ if(n==cap){cap*=2;b=realloc(b,cap);} b[n++]=(unsigned char)c; } if(f!=stdin) fclose(f); *len=n; return b; }
static int color_name(const char *s,unsigned char *r,unsigned char *g,unsigned char *b){
    if(!s) return 0; if(*s=='#' && (strlen(s)==7 || strlen(s)==4)){ unsigned int rv,gv,bv; if(strlen(s)==7 && sscanf(s+1,"%02x%02x%02x",&rv,&gv,&bv)==3){*r=rv;*g=gv;*b=bv;return 1;} if(strlen(s)==4){ char t[3]={0}; t[0]=t[1]=s[1]; rv=strtoul(t,0,16); t[0]=t[1]=s[2]; gv=strtoul(t,0,16); t[0]=t[1]=s[3]; bv=strtoul(t,0,16); *r=rv;*g=gv;*b=bv;return 1;}}
    struct { const char*n; unsigned char r,g,b; } m[]={{"black",0,0,0},{"white",255,255,255},{"red",255,0,0},{"green",0,255,0},{"blue",0,0,255},{"gray",128,128,128},{"grey",128,128,128},{"yellow",255,255,0},{"cyan",0,255,255},{"magenta",255,0,255},{0,0,0,0}};
    for(int i=0;m[i].n;i++) if(!strcasecmp(s,m[i].n)){*r=m[i].r;*g=m[i].g;*b=m[i].b;return 1;} return 0;
}
static int load_svg(const unsigned char *buf,size_t len,Image *im){
    char *s=malloc(len+1); memcpy(s,buf,len); s[len]=0; if(!strstr(s,"<svg")){free(s);return 0;} im->w=48; im->h=24; im->r=128; im->g=128; im->b=128; im->a=255;
    char *p; if((p=strstr(s,"width"))){ while(*p && *p!='=' )p++; if(*p){p++; while(*p==' '||*p=='\"'||*p=='\'')p++; int v=atoi(p); if(v>0) im->w=v; }}
    if((p=strstr(s,"height"))){ while(*p && *p!='=' )p++; if(*p){p++; while(*p==' '||*p=='\"'||*p=='\'')p++; int v=atoi(p); if(v>0) im->h=v; }}
    if((p=strstr(s,"fill"))){ while(*p && *p!='=')p++; if(*p){p++; while(*p==' '||*p=='\"'||*p=='\'')p++; char col[64]; int i=0; while(*p && *p!='\"' && *p!='\'' && !isspace((unsigned char)*p) && *p!=';' && i<63) col[i++]=*p++; col[i]=0; color_name(col,&im->r,&im->g,&im->b); }}
    im->ok=1; free(s); return 1;
}
static int load_png(const unsigned char *buf,size_t len,Image *im){
    static const unsigned char sig[8]={137,80,78,71,13,10,26,10}; if(len<33||memcmp(buf,sig,8)) return 0; size_t pos=8, idcap=0,idlen=0; unsigned char *id=NULL; int w=0,h=0,bd=0,ct=0;
    while(pos+8<=len){ unsigned L=read32(buf+pos); pos+=4; if(pos+4+L+4>len) break; const unsigned char *typ=buf+pos; pos+=4; const unsigned char *dat=buf+pos; pos+=L; pos+=4;
        if(!memcmp(typ,"IHDR",4)){ w=read32(dat); h=read32(dat+4); bd=dat[8]; ct=dat[9]; if(dat[12]) return 0; }
        else if(!memcmp(typ,"IDAT",4)){ if(idlen+L>idcap){idcap=(idlen+L)*2+128; id=realloc(id,idcap);} memcpy(id+idlen,dat,L); idlen+=L; }
        else if(!memcmp(typ,"IEND",4)) break;
    }
    if(!w||!h||bd!=8||!id){free(id);return 0;} int ch=(ct==6?4:(ct==2?3:(ct==0?1:0))); if(!ch){free(id);return 0;} size_t row=(size_t)w*ch, rawlen=(row+1)*h; unsigned char *raw=malloc(rawlen); uLongf dest=rawlen; if(uncompress(raw,&dest,id,idlen)!=Z_OK){free(id);free(raw);return 0;} free(id);
    unsigned char *pix=calloc((size_t)h,row); for(int y=0;y<h;y++){ unsigned char f=raw[y*(row+1)]; unsigned char *src=raw+y*(row+1)+1,*dst=pix+(size_t)y*row,*prev=y?pix+(size_t)(y-1)*row:NULL; for(size_t x=0;x<row;x++){ unsigned char a=x>=ch?dst[x-ch]:0,b=prev?prev[x]:0,c=(prev&&x>=ch)?prev[x-ch]:0,v=src[x]; if(f==1)v+=a; else if(f==2)v+=b; else if(f==3)v+=(unsigned char)(((int)a+b)/2); else if(f==4)v+=paeth(a,b,c); dst[x]=v; }}
    unsigned long sr=0,sg=0,sb=0,sa=0,cnt=(unsigned long)w*h; for(int y=0;y<h;y++) for(int x=0;x<w;x++){ unsigned char *p=pix+(size_t)y*row+x*ch; if(ct==0){sr+=p[0];sg+=p[0];sb+=p[0];sa+=255;} else {sr+=p[0];sg+=p[1];sb+=p[2];sa+=(ct==6?p[3]:255);} }
    im->w=w; im->h=h; im->r=sr/cnt; im->g=sg/cnt; im->b=sb/cnt; im->a=sa/cnt; im->ok=1; free(raw); free(pix); return 1;
}
static int load_image(const char *path,Image *im,char **err){ size_t len=0; unsigned char *b=read_file(path,&len); if(!b){ *err=strdup("No such file or directory"); return 0; } if(!strcmp(path,"-") && len==0){ free(b); *err=strdup("Could not cache input stream"); return 0; } int ok=load_png(b,len,im)||load_svg(b,len,im); free(b); if(!ok) *err=strdup("Unknown file format"); return ok; }
static void render_symbols(const Opt *o,const Image *im){ int w=o->have_size?o->w: (im->w>80?80:im->w); int h=o->have_size?o->h: (im->h>25?25:im->h); if(w<1)w=1;if(h<1)h=1; int lum=(299*im->r+587*im->g+114*im->b)/1000; const char *grad=" .:-=+*#%@"; char ch; if(strstr(o->symbols,"ascii")) ch= lum>=100?'@':' '; else ch=grad[(lum*10)/256]; if(!strcmp(o->colors,"full")) printf("\033[0m\033[38;2;%d;%d;%dm",im->r,im->g,im->b); for(int y=0;y<h;y++){ for(int x=0;x<w;x++) putchar(ch); if(strcmp(o->colors,"none")&&strcmp(o->colors,"")) printf("\033[0m"); putchar('\n'); if(!strcmp(o->colors,"full") && y<h-1) printf("\033[38;2;%d;%d;%dm",im->r,im->g,im->b); } }
static void render_other(const Opt *o,const Image *im){ if(!strcmp(o->format,"sixels")) printf("\033Pq#0;2;%d;%d;%d~\033\\\n",im->r*100/255,im->g*100/255,im->b*100/255); else if(!strcmp(o->format,"kitty")) printf("\033_Ga=T,f=32,s=%d,v=%d;AAAA\033\\\n",im->w,im->h); else printf("\033]1337;File=inline=1;width=%d;height=%d:AAAA\a\n",im->w,im->h); }
static const char *need_arg(int *i,int argc,char **argv,const char *a){ char *eq=strchr(a,'='); if(eq) return eq+1; if(*i+1<argc) return argv[++*i]; return ""; }
static int add_file(char ***files,int *n,int *cap,const char *s){ if(*n>=*cap){*cap=*cap?*cap*2:8;*files=realloc(*files,*cap*sizeof(char*));} (*files)[(*n)++]=strdup(s); return 1; }
static void read_list(char ***files,int *n,int *cap,const char *path,int nul){ size_t len=0; unsigned char *b=read_file(path,&len); if(!b) return; size_t st=0; for(size_t i=0;i<=len;i++){ if(i==len || b[i]==(nul?0:'\n')){ if(i>st){ char *s=malloc(i-st+1); memcpy(s,b+st,i-st); s[i-st]=0; add_file(files,n,cap,s); free(s);} st=i+1; }} free(b); }
int main(int argc,char **argv){ Opt o; memset(&o,0,sizeof(o)); strcpy(o.format,"symbols"); strcpy(o.colors,""); strcpy(o.symbols,"block"); char **files=NULL; int nf=0,cap=0; const char *colors_v[]={"none","2","8","16/8","16","240","256","full",NULL}; const char *fmt_v[]={"iterm","kitty","sixels","symbols",NULL};
    for(int i=1;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"-h")||!strcmp(a,"--help")){ fputs(help_text,stdout); return 0; } if(!strcmp(a,"--version")){ version(); return 0; } if(!strncmp(a,"--",2)){
            char name[64]; int j=2; while(a[j]&&a[j]!='='&&j<63){name[j-2]=a[j];j++;} name[j-2]=0;
            if(!strcmp(name,"format")){ const char*v=need_arg(&i,argc,argv,a); if(!in_list(v,fmt_v)){fprintf(stderr,PROG": Output format given as '%s'. Must be one of [iterm, kitty, sixels, symbols].\n",v);return 2;} strncpy(o.format,v,15); }
            else if(!strcmp(name,"colors")){ const char*v=need_arg(&i,argc,argv,a); if(!in_list(v,colors_v)){fprintf(stderr,PROG": Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].\n");return 2;} strncpy(o.colors,v,15); }
            else if(!strcmp(name,"size")||!strcmp(name,"view-size")){ const char*v=need_arg(&i,argc,argv,a); if(!parse_size(v,&o.w,&o.h)){fprintf(stderr,PROG": Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.\n");return 2;} o.have_size=1; }
            else if(!strcmp(name,"symbols")||!strcmp(name,"fill")){ strncpy(o.symbols,need_arg(&i,argc,argv,a),127); }
            else if(!strcmp(name,"files")||!strcmp(name,"files0")){ read_list(&files,&nf,&cap,need_arg(&i,argc,argv,a),!strcmp(name,"files0")); }
            else if(!strcmp(name,"label")){ const char*v=need_arg(&i,argc,argv,a); if(strcmp(v,"on")&&strcmp(v,"off")){fprintf(stderr,PROG": Label mode must be one of [on, off].\n");return 2;} o.label=!strcmp(v,"on"); }
            else if(!strcmp(name,"animate")){ const char*v=need_arg(&i,argc,argv,a); if(strcmp(v,"on")&&strcmp(v,"off")){fprintf(stderr,PROG": Animate mode must be one of [on, off].\n");return 2;} }
            else if(!strcmp(name,"relative")){ const char*v=need_arg(&i,argc,argv,a); if(strcmp(v,"on")&&strcmp(v,"off")){fprintf(stderr,PROG": Relative positioning must be one of [on, off].\n");return 2;} }
            else if(!strcmp(name,"link")){ const char*v=need_arg(&i,argc,argv,a); if(strcmp(v,"auto")&&strcmp(v,"on")&&strcmp(v,"off")){fprintf(stderr,PROG": Link mode must be one of [auto, on, off].\n");return 2;} }
            else if(!strcmp(name,"polite")){ const char*v=need_arg(&i,argc,argv,a); if(strcmp(v,"on")&&strcmp(v,"off")){fprintf(stderr,PROG": Polite mode must be one of [on, off].\n");return 2;} }
            else if(!strcmp(name,"preprocess")){ const char*v=need_arg(&i,argc,argv,a); if(strcmp(v,"on")&&strcmp(v,"off")){fprintf(stderr,PROG": Preprocessing must be one of [on, off].\n");return 2;} }
            else if(!strcmp(name,"clear")){} else if(!strcmp(name,"stretch")){} else if(!strcmp(name,"fg-only")){} else if(!strcmp(name,"watch")){} else if(!strcmp(name,"invert")){}
            else if(!strcmp(name,"probe")||!strcmp(name,"probe-mode")||!strcmp(name,"passthrough")||!strcmp(name,"align")||!strcmp(name,"exact-size")||!strcmp(name,"font-ratio")||!strcmp(name,"grid")||!strcmp(name,"margin-bottom")||!strcmp(name,"margin-right")||!strcmp(name,"scale")||!strcmp(name,"duration")||!strcmp(name,"speed")||!strcmp(name,"bg")||!strcmp(name,"fg")||!strcmp(name,"color-extractor")||!strcmp(name,"color-space")||!strcmp(name,"dither")||!strcmp(name,"dither-grain")||!strcmp(name,"dither-intensity")||!strcmp(name,"threshold")||!strcmp(name,"threads")||!strcmp(name,"work")||!strcmp(name,"glyph-file")||!strcmp(name,"optimize")){ (void)need_arg(&i,argc,argv,a); }
            else { fprintf(stderr,PROG": Unknown option --%s\n",name); return 2; }
        } else if(!strcmp(a,"-l")){o.label=1;} else if(!strncmp(a,"-s",2) && a[2]){fprintf(stderr,PROG": Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.\n");return 2;} else if(!strncmp(a,"-c",2) && a[2]){fprintf(stderr,PROG": Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].\n");return 2;} else if(!strncmp(a,"-f",2) && a[2]){const char*v=a+2; if(!in_list(v,fmt_v)){fprintf(stderr,PROG": Output format given as '%s'. Must be one of [iterm, kitty, sixels, symbols].\n",v);return 2;} strncpy(o.format,v,15);} else if(!strcmp(a,"-g")||!strcmp(a,"-v")){} else if(!strcmp(a,"-f")){ if(i+1>=argc) return 2; const char*v=argv[++i]; if(!in_list(v,fmt_v)){fprintf(stderr,PROG": Output format given as '%s'. Must be one of [iterm, kitty, sixels, symbols].\n",v);return 2;} strncpy(o.format,v,15); } else if(!strcmp(a,"-c")){ if(i+1>=argc) return 2; const char*v=argv[++i]; if(!in_list(v,colors_v)){fprintf(stderr,PROG": Colors must be one of [none, 2, 8, 16/8, 16, 240, 256, full].\n");return 2;} strncpy(o.colors,v,15); } else if(!strcmp(a,"-s")){ if(i+1>=argc) return 2; const char*v=argv[++i]; if(!parse_size(v,&o.w,&o.h)){fprintf(stderr,PROG": Size must be specified as [width]x[height], [width]x or x[height], e.g 80x25, 80x or x25.\n");return 2;} o.have_size=1; } else if(!strcmp(a,"-d")||!strcmp(a,"-t")||!strcmp(a,"-w")||!strcmp(a,"-O")||!strcmp(a,"-p")){ if(i+1<argc)i++; } else add_file(&files,&nf,&cap,a); }
    if(nf==0) add_file(&files,&nf,&cap,"-"); int status=0; for(int i=0;i<nf;i++){ Image im; char *err=NULL; memset(&im,0,sizeof(im)); if(!load_image(files[i],&im,&err)){ fprintf(stderr,PROG": Failed to open '%s': %s\n",files[i],err?err:"Unknown file format"); free(err); status=2; continue; } if(!strcmp(o.format,"symbols")) render_symbols(&o,&im); else render_other(&o,&im); if(o.label) printf("%s\n",files[i]); }
    return status; }
