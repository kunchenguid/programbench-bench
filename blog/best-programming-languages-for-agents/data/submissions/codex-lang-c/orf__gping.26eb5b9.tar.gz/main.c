#define _GNU_SOURCE

#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct {
    bool cmd;
    bool ipv4;
    bool ipv6;
    bool after_double_dash;
    int host_count;
    char **hosts;
} Options;

static void print_help(void) {
    puts("Ping, but with a graph.\n");
    puts("Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n");
    puts("Arguments:");
    puts("  [HOSTS_OR_COMMANDS]...  Hosts or IPs to ping, or commands to run if --cmd is provided. Can use cloud shorthands like aws:eu-west-1\n");
    puts("Options:");
    puts("      --cmd");
    puts("          Graph the execution time for a list of commands rather than pinging hosts");
    puts("  -n, --watch-interval <WATCH_INTERVAL>");
    puts("          Watch interval seconds (provide partial seconds like '0.5'). Default for ping is 0.2, default for cmd is 0.5");
    puts("  -b, --buffer <BUFFER>");
    puts("          Determines the number of seconds to display in the graph [default: 30]");
    puts("  -4");
    puts("          Resolve ping targets to IPv4 address");
    puts("  -6");
    puts("          Resolve ping targets to IPv6 address");
    puts("  -i, --interface <INTERFACE>");
    puts("          Interface to use when pinging");
    puts("  -s, --simple-graphics");
    puts("          ");
    puts("      --vertical-margin <VERTICAL_MARGIN>");
    puts("          Vertical margin around the graph (top and bottom) [default: 1]");
    puts("      --horizontal-margin <HORIZONTAL_MARGIN>");
    puts("          Horizontal margin around the graph (left and right) [default: 0]");
    puts("  -c, --color <color>");
    puts("          Assign color to a graph entry.");
    puts("          ");
    puts("          This option can be defined more than once as a comma separated string, and the");
    puts("          order which the colors are provided will be matched against the hosts or");
    puts("          commands passed to gping.");
    puts("          ");
    puts("          Hexadecimal RGB color codes are accepted in the form of '#RRGGBB' or the");
    puts("          following color names: 'black', 'red', 'green', 'yellow', 'blue', 'magenta',");
    puts("          'cyan', 'gray', 'dark-gray', 'light-red', 'light-green', 'light-yellow',");
    puts("          'light-blue', 'light-magenta', 'light-cyan', and 'white'");
    puts("      --clear");
    puts("          Clear the graph from the terminal after closing the program");
    puts("      --ping-args [<PING_ARGS>...]");
    puts("          Extra arguments to pass to `ping`. These are platform dependent");
    puts("  -h, --help");
    puts("          Print help");
    puts("  -V, --version");
    puts("          Print version");
}

static void print_version(void) {
    puts("gping 1.20.1");
    puts("commit_hash: d67d2aeb");
    puts("build_time: 2026-04-17 19:59:37 +00:00");
    puts("build_env: rustc 1.92.0 (ded5c06cf 2025-12-08),1.92.0-x86_64-unknown-linux-gnu");
}

static int parse_error_unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    fprintf(stderr, "Usage: executable [OPTIONS] [HOSTS_OR_COMMANDS]...\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int parse_error_missing(const char *name, const char *value_name) {
    fprintf(stderr, "error: a value is required for '%s <%s>' but none was supplied\n\n", name, value_name);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static int parse_error_invalid(const char *name, const char *value_name, const char *value, const char *msg) {
    fprintf(stderr, "error: invalid value '%s' for '%s <%s>': %s\n\n", value, name, value_name, msg);
    fprintf(stderr, "For more information, try '--help'.\n");
    return 2;
}

static bool is_float_value(const char *s) {
    char *end = NULL;
    if (!s || !*s) return false;
    errno = 0;
    strtod(s, &end);
    return errno == 0 && end && *end == '\0';
}

static bool is_uint_value(const char *s) {
    if (!s || !*s) return false;
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        if (!isdigit(*p)) return false;
    }
    return true;
}

static bool is_hex_color(const char *s) {
    if (!s || strlen(s) != 7 || s[0] != '#') return false;
    for (int i = 1; i < 7; i++) {
        if (!isxdigit((unsigned char)s[i])) return false;
    }
    return true;
}

static bool is_named_color(const char *s) {
    static const char *names[] = {
        "black", "red", "green", "yellow", "blue", "magenta", "cyan", "gray",
        "dark-gray", "light-red", "light-green", "light-yellow", "light-blue",
        "light-magenta", "light-cyan", "white", NULL
    };
    for (int i = 0; names[i]; i++) {
        if (strcmp(s, names[i]) == 0) return true;
    }
    return false;
}

static int validate_color(const char *value) {
    char first[128];
    size_t n = strcspn(value, ",");
    if (n >= sizeof(first)) n = sizeof(first) - 1;
    memcpy(first, value, n);
    first[n] = '\0';
    if (is_hex_color(first) || is_named_color(first)) return 0;
    fprintf(stderr, "Error: Invalid color code: `%s`\n\nCaused by:\n    Failed to parse Colors\n", first);
    return 1;
}

static char *expand_target(const char *host) {
    if (strncmp(host, "aws:", 4) == 0 && host[4]) {
        char *out = NULL;
        if (asprintf(&out, "ec2.%s.amazonaws.com", host + 4) < 0) return NULL;
        return out;
    }
    if (strncmp(host, "gcp:", 4) == 0 && host[4]) {
        char *out = NULL;
        if (asprintf(&out, "storage.%s.rep.googleapis.com", host + 4) < 0) return NULL;
        return out;
    }
    return strdup(host);
}

static int add_host(Options *opt, char *arg) {
    char **next = realloc(opt->hosts, sizeof(char *) * (size_t)(opt->host_count + 1));
    if (!next) return 1;
    opt->hosts = next;
    opt->hosts[opt->host_count++] = arg;
    return 0;
}

static int parse_args(int argc, char **argv, Options *opt) {
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i];
        if (opt->after_double_dash) {
            if (add_host(opt, argv[i])) return 1;
            continue;
        }
        if (strcmp(a, "--") == 0) {
            opt->after_double_dash = true;
            continue;
        }
        if (strcmp(a, "--help") == 0 || strcmp(a, "-h") == 0) {
            print_help();
            exit(0);
        }
        if (strcmp(a, "--version") == 0 || strcmp(a, "-V") == 0) {
            print_version();
            exit(0);
        }
        if (strcmp(a, "--cmd") == 0) {
            opt->cmd = true;
            continue;
        }
        if (strcmp(a, "-4") == 0) {
            opt->ipv4 = true;
            continue;
        }
        if (strcmp(a, "-6") == 0) {
            opt->ipv6 = true;
            continue;
        }
        if (strcmp(a, "-s") == 0 || strcmp(a, "--simple-graphics") == 0 || strcmp(a, "--clear") == 0) {
            continue;
        }
        if (strcmp(a, "--ping-args") == 0) {
            break;
        }
        if (strncmp(a, "--watch-interval=", 17) == 0) {
            const char *v = a + 17;
            if (!is_float_value(v)) return parse_error_invalid("--watch-interval", "WATCH_INTERVAL", v, "invalid float literal");
            continue;
        }
        if (strncmp(a, "-n", 2) == 0 && a[2] != '\0') {
            const char *v = a + 2;
            if (!is_float_value(v)) return parse_error_invalid("--watch-interval", "WATCH_INTERVAL", v, "invalid float literal");
            continue;
        }
        if (strcmp(a, "-n") == 0 || strcmp(a, "--watch-interval") == 0) {
            const char *name = "--watch-interval";
            if (++i >= argc) return parse_error_missing(name, "WATCH_INTERVAL");
            if (argv[i][0] == '-') return parse_error_unexpected(argv[i]);
            if (!is_float_value(argv[i])) return parse_error_invalid(name, "WATCH_INTERVAL", argv[i], "invalid float literal");
            continue;
        }
        if (strncmp(a, "--buffer=", 9) == 0) {
            const char *v = a + 9;
            if (!is_uint_value(v)) return parse_error_invalid("--buffer", "BUFFER", v, "invalid digit found in string");
            continue;
        }
        if (strncmp(a, "-b", 2) == 0 && a[2] != '\0') {
            const char *v = a + 2;
            if (!is_uint_value(v)) return parse_error_invalid("--buffer", "BUFFER", v, "invalid digit found in string");
            continue;
        }
        if (strcmp(a, "-b") == 0 || strcmp(a, "--buffer") == 0) {
            const char *name = "--buffer";
            if (++i >= argc) return parse_error_missing(name, "BUFFER");
            if (argv[i][0] == '-') return parse_error_unexpected(argv[i]);
            if (!is_uint_value(argv[i])) return parse_error_invalid(name, "BUFFER", argv[i], "invalid digit found in string");
            continue;
        }
        if (strncmp(a, "--vertical-margin=", 18) == 0) {
            const char *v = a + 18;
            if (!is_uint_value(v)) return parse_error_invalid("--vertical-margin", "VERTICAL_MARGIN", v, "invalid digit found in string");
            continue;
        }
        if (strcmp(a, "--vertical-margin") == 0) {
            if (++i >= argc) return parse_error_missing("--vertical-margin", "VERTICAL_MARGIN");
            if (argv[i][0] == '-') return parse_error_unexpected(argv[i]);
            if (!is_uint_value(argv[i])) return parse_error_invalid("--vertical-margin", "VERTICAL_MARGIN", argv[i], "invalid digit found in string");
            continue;
        }
        if (strncmp(a, "--horizontal-margin=", 20) == 0) {
            const char *v = a + 20;
            if (!is_uint_value(v)) return parse_error_invalid("--horizontal-margin", "HORIZONTAL_MARGIN", v, "invalid digit found in string");
            continue;
        }
        if (strcmp(a, "--horizontal-margin") == 0) {
            if (++i >= argc) return parse_error_missing("--horizontal-margin", "HORIZONTAL_MARGIN");
            if (argv[i][0] == '-') return parse_error_unexpected(argv[i]);
            if (!is_uint_value(argv[i])) return parse_error_invalid("--horizontal-margin", "HORIZONTAL_MARGIN", argv[i], "invalid digit found in string");
            continue;
        }
        if (strncmp(a, "--interface=", 12) == 0) {
            continue;
        }
        if (strncmp(a, "-i", 2) == 0 && a[2] != '\0') {
            continue;
        }
        if (strcmp(a, "-i") == 0 || strcmp(a, "--interface") == 0) {
            if (++i >= argc) return parse_error_missing("--interface", "INTERFACE");
            if (argv[i][0] == '-') return parse_error_unexpected(argv[i]);
            continue;
        }
        if (strncmp(a, "--color=", 8) == 0) {
            int rc = validate_color(a + 8);
            if (rc) return rc;
            continue;
        }
        if (strncmp(a, "-c", 2) == 0 && a[2] != '\0') {
            int rc = validate_color(a + 2);
            if (rc) return rc;
            continue;
        }
        if (strcmp(a, "-c") == 0 || strcmp(a, "--color") == 0) {
            if (++i >= argc) return parse_error_missing("--color", "color");
            int rc = validate_color(argv[i]);
            if (rc) return rc;
            continue;
        }
        if (a[0] == '-') {
            return parse_error_unexpected(a);
        }
        if (add_host(opt, argv[i])) return 1;
    }

    if (opt->ipv4 && opt->ipv6) {
        fprintf(stderr, "error: the argument '-4' cannot be used with '-6'\n\n");
        fprintf(stderr, "Usage: executable -4 <HOSTS_OR_COMMANDS>...\n\n");
        fprintf(stderr, "For more information, try '--help'.\n");
        return 2;
    }
    return 0;
}

static int no_hosts(void) {
    fprintf(stderr, "Error: At least one host or command must be given (i.e gping google.com). Use --help for a full list of arguments.\n");
    return 1;
}

static int run_ping_mode(const Options *opt) {
    if (opt->host_count == 0) return no_hosts();

    for (int i = 0; i < opt->host_count; i++) {
        char *target = expand_target(opt->hosts[i]);
        if (!target) return 1;
        struct addrinfo hints;
        memset(&hints, 0, sizeof(hints));
        hints.ai_socktype = SOCK_STREAM;
        if (opt->ipv4) hints.ai_family = AF_INET;
        if (opt->ipv6) hints.ai_family = AF_INET6;
        struct addrinfo *res = NULL;
        int rc = getaddrinfo(target, NULL, &hints, &res);
        if (rc != 0) {
            fprintf(stderr, "Error: Resolving %s\n\nCaused by:\n    failed to lookup address information: %s\n", target, gai_strerror(rc));
            free(target);
            return 1;
        }
        freeaddrinfo(res);
        free(target);
    }

    fprintf(stderr, "Error: Could not detect ping. Stderr: []\nStdout: []\n");
    return 1;
}

static int run_cmd_mode(const Options *opt) {
    if (opt->host_count == 0) return no_hosts();
    if (!isatty(STDOUT_FILENO) || !isatty(STDIN_FILENO)) {
        fprintf(stderr, "Error: No such device or address (os error 6)\n");
        return 1;
    }
    fprintf(stderr, "Error: No such device or address (os error 6)\n");
    return 1;
}

int main(int argc, char **argv) {
    Options opt;
    memset(&opt, 0, sizeof(opt));
    int rc = parse_args(argc, argv, &opt);
    if (rc != 0) return rc;
    if (opt.cmd) return run_cmd_mode(&opt);
    return run_ping_mode(&opt);
}
