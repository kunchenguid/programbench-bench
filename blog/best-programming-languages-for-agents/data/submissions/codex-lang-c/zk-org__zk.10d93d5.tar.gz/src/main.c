#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct { char **v; int n, cap; } StrList;
typedef struct { char *path; char *title; char *body; StrList tags; } Note;
typedef struct { Note *v; int n, cap; } NoteList;

typedef struct {
    char notebook_dir[PATH_MAX];
    char working_dir[PATH_MAX];
    bool no_input;
} Global;

static void die(const char *fmt, ...) {
    va_list ap;
    fprintf(stderr, "zk: error: ");
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static char *xstrdup(const char *s) { char *r = strdup(s ? s : ""); if (!r) die("out of memory"); return r; }
static void sl_add(StrList *l, const char *s) { if (l->n == l->cap) { l->cap = l->cap ? l->cap*2 : 8; l->v = realloc(l->v, l->cap*sizeof(char*)); if(!l->v) die("out of memory"); } l->v[l->n++] = xstrdup(s); }
static bool sl_has(StrList *l, const char *s) { for(int i=0;i<l->n;i++) if(strcmp(l->v[i],s)==0) return true; return false; }
static void sl_add_unique(StrList *l, const char *s) { if (!sl_has(l,s)) sl_add(l,s); }
static void notes_add(NoteList *l, Note n) { if (l->n == l->cap) { l->cap = l->cap ? l->cap*2 : 16; l->v = realloc(l->v, l->cap*sizeof(Note)); if(!l->v) die("out of memory"); } l->v[l->n++] = n; }

static int mkdir_p(const char *path) {
    char tmp[PATH_MAX]; size_t len = strlen(path); if (len >= sizeof(tmp)) return -1; strcpy(tmp,path);
    if (len && tmp[len-1]=='/') tmp[len-1]=0;
    for(char *p=tmp+1; *p; p++) if (*p=='/') { *p=0; if (mkdir(tmp,0777) && errno!=EEXIST) return -1; *p='/'; }
    if (mkdir(tmp,0777) && errno!=EEXIST) return -1;
    return 0;
}
static bool is_dir(const char *p) { struct stat st; return stat(p,&st)==0 && S_ISDIR(st.st_mode); }
static bool is_file(const char *p) { struct stat st; return stat(p,&st)==0 && S_ISREG(st.st_mode); }
static void path_join(char *out, size_t n, const char *a, const char *b) { snprintf(out,n,"%s%s%s",a, (a[0]&&a[strlen(a)-1]=='/')?"":"/", b); }
static const char *base_name(const char *p) { const char *s=strrchr(p,'/'); return s?s+1:p; }

static bool has_suffix(const char *s, const char *suf) { size_t a=strlen(s), b=strlen(suf); return a>=b && strcmp(s+a-b,suf)==0; }
static char *read_file(const char *path) {
    FILE *f=fopen(path,"rb"); if(!f) return NULL; fseek(f,0,SEEK_END); long sz=ftell(f); rewind(f);
    char *buf=malloc((sz<0?0:sz)+1); if(!buf) die("out of memory"); size_t got=fread(buf,1,sz<0?0:(size_t)sz,f); buf[got]=0; fclose(f); return buf;
}
static char *read_stdin_all(void) {
    size_t cap=4096,n=0; char *b=malloc(cap); if(!b) die("out of memory"); int c;
    while((c=getchar())!=EOF){ if(n+2>=cap){cap*=2;b=realloc(b,cap);if(!b)die("out of memory");} b[n++]=(char)c; } b[n]=0; return b;
}
static void write_text(const char *path, const char *text) { FILE *f=fopen(path,"wb"); if(!f) die("failed to write %s: %s", path, strerror(errno)); fputs(text,f); fclose(f); }

static void json_str(const char *s) { putchar('"'); for(; *s; s++){ unsigned char c=*s; if(c=='"'||c=='\\') printf("\\%c",c); else if(c=='\n') printf("\\n"); else if(c=='\r') printf("\\r"); else if(c=='\t') printf("\\t"); else if(c<32) printf("\\u%04x",c); else putchar(c);} putchar('"'); }

static const char *ROOT_HELP =
"Usage: zk <command>\n\n"
"Commands:\n\n"
"NOTEBOOK\n  A notebook is a directory containing a collection of notes\n\n"
"  init     Create a new notebook in the given directory.\n"
"  index    Index the notes to be searchable.\n\n"
"NOTES\n  Edit or browse your notes\n\n"
"  new      Create a new note in the given notebook directory.\n"
"  list     List notes matching the given criteria.\n"
"  graph    Produce a graph of the notes matching the given criteria.\n"
"  edit     Edit notes matching the given criteria.\n"
"  tag      Manage the note tags.\n\n"
"Flags:\n  -h, --help                 Show context-sensitive help.\n"
"      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n"
"  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n"
"      --no-input             Never prompt or ask for confirmation.\n\n"
"Run \"zk <command> --help\" for more information on a command.\n";

static const char *INIT_HELP =
"Usage: zk init [<directory>]\n\nCreate a new notebook in the given directory.\n\nArguments:\n  [<directory>]    Directory containing the notebook.\n\nFlags:\n  -h, --help                 Show context-sensitive help.\n      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n      --no-input             Never prompt or ask for confirmation.\n";
static const char *INDEX_HELP =
"Usage: zk index\n\nIndex the notes to be searchable.\n\nYou usually do not need to run `zk index` manually, as notes are indexed\nautomatically when needed.\n\nFlags:\n  -h, --help                 Show context-sensitive help.\n      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n      --no-input             Never prompt or ask for confirmation.\n\n  -f, --force                Force indexing all the notes.\n  -v, --verbose              Print detailed information about the indexing\n                             process.\n  -q, --quiet                Do not print statistics nor progress.\n";
static const char *NEW_HELP =
"Usage: zk new [<directory>]\n\nCreate a new note in the given notebook directory.\n\nArguments:\n  [<directory>]    Directory in which to create the note.\n\nFlags:\n  -h, --help                   Show context-sensitive help.\n      --notebook-dir=PATH      Turn off notebook auto-discovery and set manually\n                               the notebook where commands are run.\n  -W, --working-dir=PATH       Run as if zk was started in <PATH> instead of the\n                               current working directory.\n      --no-input               Never prompt or ask for confirmation.\n\n  -i, --interactive            Read contents from standard input.\n  -t, --title=TITLE            Title of the new note.\n      --date=DATE              Set the current date.\n  -g, --group=NAME             Name of the config group this note belongs to.\n                               Takes precedence over the config of the\n                               directory.\n      --extra=KEY=VALUE,...    Extra variables passed to the templates.\n      --template=PATH          Custom template used to render the note.\n  -p, --print-path             Print the path of the created note instead of\n                               editing it.\n  -n, --dry-run                Don't actually create the note. Instead, prints\n                               its content on stdout and the generated path on\n                               stderr.\n      --id=ID                  Skip id generation and use provided value.\n";
static const char *LIST_HELP =
"Usage: zk list [<path> ...]\n\nList notes matching the given criteria.\n\nArguments:\n  [<path> ...]    Find notes matching the given path, including its descendants.\n\nFlags:\n  -h, --help                 Show context-sensitive help.\n      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n      --no-input             Never prompt or ask for confirmation.\n\nFormatting\n  -f, --format=TEMPLATE    Pretty print the list using a custom template or one\n                           of the predefined formats: oneline, short, medium,\n                           long, full, json, jsonl.\n      --header=STRING      Arbitrary text printed at the start of the list.\n      --footer=\"\\\\n\"       Arbitrary text printed at the end of the list.\n  -d, --delimiter=\"\\n\"     Print notes delimited by the given separator.\n  -0, --delimiter0         Print notes delimited by ASCII NUL characters. This\n                           is useful when used in conjunction with `xargs -0`.\n  -P, --no-pager           Do not pipe output into a pager.\n  -q, --quiet              Do not print the total number of notes found.\n\nFiltering\n  -i, --interactive                Select notes interactively with fzf.\n  -n, --limit=COUNT                Limit the number of notes found.\n  -m, --match=QUERY,...            Terms to search for in the notes.\n  -M, --match-strategy=STRATEGY    Text matching strategy among: fts, re, exact.\n  -x, --exclude=PATH,...           Ignore notes matching the given path,\n                                   including its descendants.\n  -t, --tag=TAG,...                Find notes tagged with the given tags.\n      --orphan                     Find notes which are not linked by any other\n                                   note.\n      --tagless                    Find notes which have no tags.\n  -r, --recursive                  Follow links recursively.\n\nSorting\n  -s, --sort=TERM,...    Order the notes by the given criterion.\n";
static const char *GRAPH_HELP =
"Usage: zk graph --format=STRING [<path> ...]\n\nProduce a graph of the notes matching the given criteria.\n\nArguments:\n  [<path> ...]    Find notes matching the given path, including its descendants.\n\nFlags:\n  -h, --help                 Show context-sensitive help.\n      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n      --no-input             Never prompt or ask for confirmation.\n\nFormatting\n  -f, --format=STRING    Format of the graph among: json.\n  -q, --quiet            Do not print the total number of notes found.\n";
static const char *EDIT_HELP =
"Usage: zk edit [<path> ...]\n\nEdit notes matching the given criteria.\n\nArguments:\n  [<path> ...]    Find notes matching the given path, including its descendants.\n\nFlags:\n  -h, --help                 Show context-sensitive help.\n      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n      --no-input             Never prompt or ask for confirmation.\n\n  -f, --force                Do not confirm before editing many notes at the\n                             same time.\n";
static const char *TAG_HELP =
"Usage: zk tag <command>\n\nManage the note tags.\n\nCommands:\n  tag list    List all the note tags.\n\nFlags:\n  -h, --help                 Show context-sensitive help.\n      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n      --no-input             Never prompt or ask for confirmation.\n";
static const char *TAG_LIST_HELP =
"Usage: zk tag list\n\nList all the note tags.\n\nFlags:\n  -h, --help                 Show context-sensitive help.\n      --notebook-dir=PATH    Turn off notebook auto-discovery and set manually\n                             the notebook where commands are run.\n  -W, --working-dir=PATH     Run as if zk was started in <PATH> instead of the\n                             current working directory.\n      --no-input             Never prompt or ask for confirmation.\n\nFormatting\n  -f, --format=TEMPLATE    Pretty print the list using a custom template or one\n                           of the predefined formats: name, full, json, jsonl.\n      --header=STRING      Arbitrary text printed at the start of the list.\n      --footer=\"\\\\n\"       Arbitrary text printed at the end of the list.\n  -d, --delimiter=\"\\n\"     Print tags delimited by the given separator.\n  -0, --delimiter0         Print tags delimited by ASCII NUL characters. This is\n                           useful when used in conjunction with `xargs -0`.\n  -P, --no-pager           Do not pipe output into a pager.\n  -q, --quiet              Do not print the total number of tags found.\n\nSorting\n  -s, --sort=TERM,...    Order the tags by the given criterion.\n";

static int parse_global(int argc, char **argv, Global *g, char **cmd, int *cmdi) {
    getcwd(g->working_dir, sizeof(g->working_dir)); g->notebook_dir[0]=0; g->no_input=false;
    for(int i=1;i<argc;i++) {
        char *a=argv[i];
        if(strcmp(a,"--version")==0){ puts("zk dev"); exit(0); }
        if(strcmp(a,"-h")==0||strcmp(a,"--help")==0){ fputs(ROOT_HELP, stdout); exit(0); }
        if(strcmp(a,"--no-input")==0){ g->no_input=true; continue; }
        if(strcmp(a,"-W")==0 || strcmp(a,"--working-dir")==0){ if(++i>=argc) die("expected value for %s", a); strncpy(g->working_dir, argv[i], sizeof(g->working_dir)-1); continue; }
        if(strncmp(a,"--working-dir=",14)==0){ strncpy(g->working_dir, a+14, sizeof(g->working_dir)-1); continue; }
        if(strcmp(a,"--notebook-dir")==0){ if(++i>=argc) die("expected value for %s", a); strncpy(g->notebook_dir, argv[i], sizeof(g->notebook_dir)-1); continue; }
        if(strncmp(a,"--notebook-dir=",15)==0){ strncpy(g->notebook_dir, a+15, sizeof(g->notebook_dir)-1); continue; }
        *cmd=a; *cmdi=i; return 1;
    }
    fputs(ROOT_HELP, stdout); exit(0);
}

static void require_notebook(Global *g, char *out) {
    if (chdir(g->working_dir)!=0) die("failed to change working directory: %s", strerror(errno));
    if (g->notebook_dir[0]) { realpath(g->notebook_dir,out); if(!is_dir(out)) die("failed to open notebook: no notebook found in %s", g->notebook_dir); return; }
    char cur[PATH_MAX]; getcwd(cur,sizeof(cur)); char start[PATH_MAX]; strcpy(start,cur);
    while(1) { char zk[PATH_MAX]; path_join(zk,sizeof(zk),cur,".zk"); if(is_dir(zk)){ strcpy(out,cur); return; }
        if(strcmp(cur,"/")==0) break; char *slash=strrchr(cur,'/'); if(!slash) break; if(slash==cur) cur[1]=0; else *slash=0; }
    die("failed to open notebook: no notebook found in %s or a parent directory", start);
}

static void init_notebook(const char *dir) {
    if (mkdir_p(dir)!=0) die("failed to create notebook: %s", strerror(errno));
    char zk[PATH_MAX], tmpldir[PATH_MAX], def[PATH_MAX], cfg[PATH_MAX], db[PATH_MAX];
    path_join(zk,sizeof(zk),dir,".zk"); path_join(tmpldir,sizeof(tmpldir),zk,"templates");
    if(mkdir_p(tmpldir)!=0) die("failed to create notebook: %s", strerror(errno));
    path_join(def,sizeof(def),tmpldir,"default.md"); path_join(cfg,sizeof(cfg),zk,"config.toml"); path_join(db,sizeof(db),zk,"notebook.db");
    if(!is_file(def)) write_text(def,"# {{title}}\n\n{{content}}\n");
    if(!is_file(cfg)) write_text(cfg,"# zk configuration file\n\n[note]\ntemplate = \"default.md\"\n\n[extra]\n\n[format.markdown]\nlink-format = \"markdown\"\n");
    if(!is_file(db)) { FILE *f=fopen(db,"wb"); if(f) fclose(f); }
}

static void make_id(char *out, size_t n) {
    const char *cs="abcdefghijklmnopqrstuvwxyz0123456789"; srand((unsigned)(time(NULL)^getpid()));
    for(int i=0;i<4 && (size_t)i+1<n;i++) out[i]=cs[rand()%36];
    out[4<n?4:n-1]=0;
}
static void sanitize_slug(const char *in, char *out, size_t n) {
    size_t j=0; bool dash=false; for(size_t i=0; in[i] && j+1<n; i++){ unsigned char c=in[i]; if(isalnum(c)){ out[j++]=(char)tolower(c); dash=false; } else if(!dash && j>0){ out[j++]='-'; dash=true; }} if(j&&out[j-1]=='-')j--; out[j]=0; if(!j) snprintf(out,n,"untitled");
}

static void parse_tags(Note *note) {
    char *b=note->body; for(size_t i=0;b && b[i];i++) if(b[i]=='#' && (i==0 || !isalnum((unsigned char)b[i-1]))) { size_t j=i+1; if(!isalnum((unsigned char)b[j]) && b[j]!='_') continue; char tag[128]; size_t k=0; while((isalnum((unsigned char)b[j])||b[j]=='_'||b[j]=='-'||b[j]=='/') && k+1<sizeof(tag)) tag[k++]=b[j++]; tag[k]=0; if(k) sl_add_unique(&note->tags,tag); }
}
static char *extract_title(const char *body, const char *path) {
    if(body && body[0]=='#' && body[1]==' ') { const char *e=strchr(body,'\n'); size_t len=e?(size_t)(e-body-2):strlen(body+2); char *t=malloc(len+1); memcpy(t,body+2,len); t[len]=0; return t; }
    char tmp[PATH_MAX]; strncpy(tmp, base_name(path), sizeof(tmp)-1); tmp[sizeof(tmp)-1]=0; char *dot=strrchr(tmp,'.'); if(dot) *dot=0; return xstrdup(tmp);
}

static bool path_match(const char *path, StrList *paths) { if(paths->n==0) return true; for(int i=0;i<paths->n;i++){ const char *p=paths->v[i]; size_t l=strlen(p); if(strcmp(path,p)==0 || (strncmp(path,p,l)==0 && (path[l]=='/' || p[l-1]=='/'))) return true; } return false; }
static bool contains_ci(const char *hay, const char *needle) { if(!needle||!*needle) return true; size_t nl=strlen(needle); for(size_t i=0; hay&&hay[i]; i++){ size_t j=0; while(j<nl && hay[i+j] && tolower((unsigned char)hay[i+j])==tolower((unsigned char)needle[j])) j++; if(j==nl) return true; } return false; }

static void scan_dir(const char *root, const char *rel, NoteList *notes) {
    char dirp[PATH_MAX]; if(rel[0]) path_join(dirp,sizeof(dirp),root,rel); else strcpy(dirp,root);
    DIR *d=opendir(dirp); if(!d) return; struct dirent *e;
    while((e=readdir(d))) { if(strcmp(e->d_name,".")==0||strcmp(e->d_name,"..")==0||strcmp(e->d_name,".zk")==0) continue;
        char childrel[PATH_MAX]; if(rel[0]) snprintf(childrel,sizeof(childrel),"%s/%s",rel,e->d_name); else snprintf(childrel,sizeof(childrel),"%s",e->d_name);
        char full[PATH_MAX]; path_join(full,sizeof(full),root,childrel); struct stat st; if(stat(full,&st)!=0) continue;
        if(S_ISDIR(st.st_mode)) scan_dir(root,childrel,notes); else if(S_ISREG(st.st_mode) && (has_suffix(e->d_name,".md")||has_suffix(e->d_name,".markdown"))) { Note n={0}; n.path=xstrdup(childrel); n.body=read_file(full); n.title=extract_title(n.body,childrel); parse_tags(&n); notes_add(notes,n); }
    }
    closedir(d);
}
static int cmp_note(const void *a,const void*b){ const Note *x=a,*y=b; return strcmp(x->path,y->path); }
static int cmp_strp(const void *a,const void*b){ char *const*x=a,*const*y=b; return strcmp(*x,*y); }

static void split_csv(StrList *l, const char *s) {
    const char *start = s;
    for (const char *p = s;; p++) {
        if (*p == ',' || *p == '\0') {
            size_t len = (size_t)(p - start);
            if (len) {
                char *tok = malloc(len + 1);
                if (!tok) die("out of memory");
                memcpy(tok, start, len);
                tok[len] = 0;
                sl_add(l, tok);
                free(tok);
            }
            if (*p == '\0') break;
            start = p + 1;
        }
    }
}

static void output_note(Note *n, const char *format) {
    if(format && strcmp(format,"json")==0) { putchar('{'); printf("\"path\":"); json_str(n->path); printf(",\"title\":"); json_str(n->title); printf(",\"tags\":["); for(int i=0;i<n->tags.n;i++){ if(i) putchar(','); json_str(n->tags.v[i]); } printf("]}"); }
    else if(format && strcmp(format,"full")==0) printf("%s\n%s\n", n->path, n->body?n->body:"");
    else if(format && (strcmp(format,"oneline")==0||strcmp(format,"short")==0||strcmp(format,"medium")==0||strcmp(format,"long")==0)) printf("%s %s", n->path, n->title);
    else printf("%s", n->path);
}

static void cmd_list(Global *g, int argc, char **argv, int i) {
    char nb[PATH_MAX]; require_notebook(g,nb); const char *format=NULL,*header=NULL,*footer=NULL,*delim="\n"; int limit=-1; bool nul=false, json_array=false, tagless=false; StrList paths={0}, tags={0}, matches={0};
    for(;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"-h")||!strcmp(a,"--help")){ fputs(LIST_HELP, stdout); return; } else if(!strcmp(a,"-f")||!strcmp(a,"--format")){ if(++i>=argc) die("expected value for %s",a); format=argv[i]; } else if(!strncmp(a,"--format=",9)) format=a+9; else if(!strcmp(a,"--header")){ if(++i>=argc) die("expected value for --header"); header=argv[i]; } else if(!strncmp(a,"--header=",9)) header=a+9; else if(!strcmp(a,"--footer")){ if(++i>=argc) die("expected value for --footer"); footer=argv[i]; } else if(!strncmp(a,"--footer=",9)) footer=a+9; else if(!strcmp(a,"-d")||!strcmp(a,"--delimiter")){ if(++i>=argc) die("expected value for %s",a); delim=argv[i]; } else if(!strncmp(a,"--delimiter=",12)) delim=a+12; else if(!strcmp(a,"-0")||!strcmp(a,"--delimiter0")){ nul=true; delim="\0"; } else if(!strcmp(a,"-n")||!strcmp(a,"--limit")){ if(++i>=argc) die("expected value for %s",a); limit=atoi(argv[i]); } else if(!strncmp(a,"--limit=",8)) limit=atoi(a+8); else if(!strcmp(a,"-m")||!strcmp(a,"--match")){ if(++i>=argc) die("expected value for %s",a); split_csv(&matches,argv[i]); } else if(!strncmp(a,"--match=",8)) split_csv(&matches,a+8); else if(!strcmp(a,"-t")||!strcmp(a,"--tag")){ if(++i>=argc) die("expected value for %s",a); split_csv(&tags,argv[i]); } else if(!strncmp(a,"--tag=",6)) split_csv(&tags,a+6); else if(!strcmp(a,"--tagless")) tagless=true; else if(a[0]=='-') { if(i+1<argc && argv[i+1][0]!='-') i++; } else sl_add(&paths,a); }
    NoteList notes={0}; scan_dir(nb,"",&notes); qsort(notes.v,notes.n,sizeof(Note),cmp_note); if(format && strcmp(format,"json")==0) json_array=true; if(header) fputs(header,stdout); if(json_array) putchar('['); int out=0;
    for(int k=0;k<notes.n;k++){ Note *n=&notes.v[k]; if(!path_match(n->path,&paths)) continue; bool ok=true; for(int t=0;t<tags.n;t++) if(!sl_has(&n->tags,tags.v[t])) ok=false; if(tagless && n->tags.n) ok=false; for(int m=0;m<matches.n;m++) if(!contains_ci(n->body,matches.v[m])&&!contains_ci(n->title,matches.v[m])) ok=false; if(!ok) continue; if(limit>=0 && out>=limit) break; if(out){ if(json_array) putchar(','); else if(nul) putchar('\0'); else fputs(delim,stdout); } output_note(n,format); out++; }
    if(json_array) putchar(']');
    if(footer) fputs(footer,stdout);
    else if(!nul) putchar('\n');
}

static void cmd_new(Global *g, int argc, char **argv, int i) {
    char nb[PATH_MAX]; require_notebook(g,nb); const char *title="Untitled", *id=NULL, *dir="", *template_path=NULL; bool print_path=false,dry=false,interactive=false;
    for(;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"-h")||!strcmp(a,"--help")){ fputs(NEW_HELP, stdout); return; } else if(!strcmp(a,"-t")||!strcmp(a,"--title")){ if(++i>=argc) die("expected value for %s",a); title=argv[i]; } else if(!strncmp(a,"--title=",8)) title=a+8; else if(!strcmp(a,"--id")){ if(++i>=argc) die("expected value for --id"); id=argv[i]; } else if(!strncmp(a,"--id=",5)) id=a+5; else if(!strcmp(a,"-p")||!strcmp(a,"--print-path")) print_path=true; else if(!strcmp(a,"-n")||!strcmp(a,"--dry-run")) dry=true; else if(!strcmp(a,"-i")||!strcmp(a,"--interactive")) interactive=true; else if(!strcmp(a,"--template")){ if(++i<argc) template_path=argv[i]; } else if(!strncmp(a,"--template=",11)) template_path=a+11; else if(a[0]=='-') { if(i+1<argc && argv[i+1][0]!='-') i++; } else dir=a; }
    char genid[64]; if(!id){ make_id(genid,sizeof(genid)); id=genid; }
    char rel_dir[PATH_MAX]; strcpy(rel_dir,dir); char full_dir[PATH_MAX]; path_join(full_dir,sizeof(full_dir),nb,rel_dir); if(!dry && mkdir_p(full_dir)!=0) die("failed to create directory: %s", strerror(errno));
    char filename[PATH_MAX]; snprintf(filename,sizeof(filename),"%s.md",id); char rel[PATH_MAX]; if(rel_dir[0]) snprintf(rel,sizeof(rel),"%s/%s",rel_dir,filename); else snprintf(rel,sizeof(rel),"%s",filename); char full[PATH_MAX]; path_join(full,sizeof(full),nb,rel);
    char *content = interactive ? read_stdin_all() : xstrdup(""); char *rendered=NULL;
    if(template_path){ char tp[PATH_MAX]; if(template_path[0]=='/') strcpy(tp,template_path); else path_join(tp,sizeof(tp),nb,template_path); char *tmpl=read_file(tp); if(tmpl){ rendered=tmpl; } }
    if(!rendered){ size_t sz=strlen(title)+strlen(content)+8; rendered=malloc(sz); snprintf(rendered,sz,"# %s\n\n%s",title,content); }
    if(dry){ fputs(rendered,stdout); if(rendered[strlen(rendered)-1]!='\n') putchar('\n'); fprintf(stderr,"%s\n",rel); }
    else { write_text(full,rendered); if(print_path || !isatty(STDOUT_FILENO)) printf("%s\n",rel); }
    free(content); free(rendered);
}

static void collect_tags(NoteList *notes, StrList *tags) { for(int i=0;i<notes->n;i++) for(int j=0;j<notes->v[i].tags.n;j++) sl_add_unique(tags,notes->v[i].tags.v[j]); qsort(tags->v,tags->n,sizeof(char*),cmp_strp); }
static void cmd_tag_list(Global *g, int argc, char **argv, int i) {
    char nb[PATH_MAX]; require_notebook(g,nb); const char *format=NULL,*delim="\n",*header=NULL,*footer=NULL; bool nul=false;
    for(;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"-h")||!strcmp(a,"--help")){ fputs(TAG_LIST_HELP, stdout); return; } else if(!strcmp(a,"-f")||!strcmp(a,"--format")){ if(++i<argc) format=argv[i]; } else if(!strncmp(a,"--format=",9)) format=a+9; else if(!strcmp(a,"-d")||!strcmp(a,"--delimiter")){ if(++i<argc) delim=argv[i]; } else if(!strncmp(a,"--delimiter=",12)) delim=a+12; else if(!strcmp(a,"-0")||!strcmp(a,"--delimiter0")){ nul=true; delim="\0"; } else if(!strcmp(a,"--header")){ if(++i<argc) header=argv[i]; } else if(!strncmp(a,"--header=",9)) header=a+9; else if(!strcmp(a,"--footer")){ if(++i<argc) footer=argv[i]; } else if(!strncmp(a,"--footer=",9)) footer=a+9; }
    NoteList notes={0}; StrList tags={0}; scan_dir(nb,"",&notes); collect_tags(&notes,&tags); if(header) fputs(header,stdout); if(format&&strcmp(format,"json")==0){ putchar('['); for(int k=0;k<tags.n;k++){ if(k) putchar(','); json_str(tags.v[k]); } putchar(']'); }
    else { for(int k=0;k<tags.n;k++){ if(k){ if(nul) putchar('\0'); else fputs(delim,stdout); } if(format&&strcmp(format,"full")==0) printf("%s %d",tags.v[k],1); else fputs(tags.v[k],stdout); } }
    if(footer) fputs(footer,stdout); else if(!nul) putchar('\n');
}

static void cmd_graph(Global *g, int argc, char **argv, int i) {
    char nb[PATH_MAX]; require_notebook(g,nb); const char *format=NULL; for(;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"-h")||!strcmp(a,"--help")){ fputs(GRAPH_HELP, stdout); return; } else if(!strcmp(a,"-f")||!strcmp(a,"--format")){ if(++i<argc) format=argv[i]; } else if(!strncmp(a,"--format=",9)) format=a+9; }
    if(!format) die("missing flags: --format=STRING");
    if(strcmp(format,"json")!=0) die("invalid value \"%s\" for --format", format);
    NoteList notes={0}; scan_dir(nb,"",&notes); qsort(notes.v,notes.n,sizeof(Note),cmp_note); printf("{\"nodes\":["); for(int k=0;k<notes.n;k++){ if(k) putchar(','); printf("{\"path\":"); json_str(notes.v[k].path); printf(",\"title\":"); json_str(notes.v[k].title); putchar('}'); } printf("],\"links\":[]}\n");
}
static void cmd_edit(Global *g, int argc, char **argv, int i) { for(;i<argc;i++) if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")){ fputs(EDIT_HELP, stdout); return; } char nb[PATH_MAX]; require_notebook(g,nb); const char *ed=getenv("EDITOR"); if(!ed) ed="vi"; (void)ed; cmd_list(g,argc,argv,i); }

int main(int argc, char **argv) {
    Global g; char *cmd=NULL; int i=0; parse_global(argc,argv,&g,&cmd,&i);
    if(strcmp(cmd,"init")==0){ for(int j=i+1;j<argc;j++) if(!strcmp(argv[j],"-h")||!strcmp(argv[j],"--help")){ fputs(INIT_HELP, stdout); return 0; } if(chdir(g.working_dir)!=0) die("failed to change working directory: %s", strerror(errno)); const char *dir = (i+1<argc && argv[i+1][0]!='-') ? argv[i+1] : "."; init_notebook(dir); return 0; }
    if(strcmp(cmd,"index")==0){ for(int j=i+1;j<argc;j++) if(!strcmp(argv[j],"-h")||!strcmp(argv[j],"--help")){ fputs(INDEX_HELP, stdout); return 0; } char nb[PATH_MAX]; require_notebook(&g,nb); return 0; }
    if(strcmp(cmd,"new")==0){ cmd_new(&g,argc,argv,i+1); return 0; }
    if(strcmp(cmd,"list")==0){ cmd_list(&g,argc,argv,i+1); return 0; }
    if(strcmp(cmd,"graph")==0){ cmd_graph(&g,argc,argv,i+1); return 0; }
    if(strcmp(cmd,"edit")==0){ cmd_edit(&g,argc,argv,i+1); return 0; }
    if(strcmp(cmd,"tag")==0){ if(i+1>=argc || !strcmp(argv[i+1],"-h")||!strcmp(argv[i+1],"--help")){ fputs(TAG_HELP, stdout); return 0; } if(strcmp(argv[i+1],"list")==0){ cmd_tag_list(&g,argc,argv,i+2); return 0; } die("unexpected argument %s", argv[i+1]); }
    die("unexpected argument %s", cmd);
    return 0;
}
