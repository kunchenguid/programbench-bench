#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <termios.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct {
    char *name;
    int is_dir;
    int hidden;
} Entry;

typedef struct {
    Entry *items;
    size_t len;
    size_t cap;
} Entries;

static const char *help_text =
"\n"
"  walk v1.13.0\n"
"\n"
"  Usage: walk [path]\n"
"\n"
"    arrows, hjkl  Move cursor\n"
"    enter         Enter directory\n"
"    backspace     Exit directory\n"
"    space         Toggle preview\n"
"    esc, q        Exit with cd\n"
"    ctrl+c        Exit without cd\n"
"    /             Fuzzy search\n"
"    d, delete     Delete file or dir\n"
"    y             Copy to clipboard\n"
"    .             Hide hidden files\n"
"    ?             Show help\n"
"\n"
"  Flags:\n"
"\n"
"    --icons        display icons\n"
"    --dir-only     show dirs only\n"
"    --hide-hidden  hide hidden files\n"
"    --preview      display preview\n"
"    --with-border  preview with border\n"
"    --fuzzy        fuzzy mode\n"
"\n";

static struct termios saved_termios;
static int tty_fd = -1;
static bool term_saved = false;

static void tty_write(const char *s) {
    if (tty_fd >= 0) {
        ssize_t ignored = write(tty_fd, s, strlen(s));
        (void)ignored;
    }
}

static void die_no_tty(void) {
    fputs("panic: could not open a new TTY: open /dev/tty: no such device or address\n\n", stderr);
    fputs("goroutine 1 [running]:\n", stderr);
    fputs("main.main()\n", stderr);
    fputs("\t/workspace/main.go:135 +0x87d\n", stderr);
    exit(2);
}

static void restore_term(void) {
    if (term_saved && tty_fd >= 0) {
        tcsetattr(tty_fd, TCSAFLUSH, &saved_termios);
        tty_write("\033[?25h\033[0m\033[?1049l");
    }
}

static char *xstrdup(const char *s) {
    char *p = strdup(s);
    if (!p) {
        perror("strdup");
        exit(1);
    }
    return p;
}

static int cmp_entries(const void *a, const void *b) {
    const Entry *ea = (const Entry *)a;
    const Entry *eb = (const Entry *)b;
    if (ea->is_dir != eb->is_dir) return eb->is_dir - ea->is_dir;
    return strcasecmp(ea->name, eb->name);
}

static void entries_free(Entries *e) {
    for (size_t i = 0; i < e->len; i++) free(e->items[i].name);
    free(e->items);
    e->items = NULL;
    e->len = e->cap = 0;
}

static void entries_push(Entries *e, const char *name, int is_dir, int hidden) {
    if (e->len == e->cap) {
        size_t ncap = e->cap ? e->cap * 2 : 32;
        Entry *n = realloc(e->items, ncap * sizeof(*n));
        if (!n) {
            perror("realloc");
            exit(1);
        }
        e->items = n;
        e->cap = ncap;
    }
    e->items[e->len].name = xstrdup(name);
    e->items[e->len].is_dir = is_dir;
    e->items[e->len].hidden = hidden;
    e->len++;
}

static int load_entries(const char *path, Entries *out, bool dir_only, bool hide_hidden) {
    entries_free(out);
    DIR *d = opendir(path);
    if (!d) return -1;
    struct dirent *de;
    while ((de = readdir(d)) != NULL) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) continue;
        int hidden = de->d_name[0] == '.';
        if (hide_hidden && hidden) continue;

        char full[PATH_MAX];
        snprintf(full, sizeof(full), "%s/%s", path, de->d_name);
        struct stat st;
        int is_dir = 0;
        if (stat(full, &st) == 0) is_dir = S_ISDIR(st.st_mode);

        if (dir_only && !is_dir) continue;
        entries_push(out, de->d_name, is_dir, hidden);
    }
    closedir(d);
    qsort(out->items, out->len, sizeof(Entry), cmp_entries);
    return 0;
}

static void join_path(char *dst, size_t n, const char *base, const char *name) {
    if (strcmp(base, "/") == 0) snprintf(dst, n, "/%s", name);
    else snprintf(dst, n, "%s/%s", base, name);
}

static void parent_path(char *path) {
    size_t len = strlen(path);
    if (len <= 1) {
        strcpy(path, "/");
        return;
    }
    while (len > 1 && path[len - 1] == '/') path[--len] = '\0';
    char *slash = strrchr(path, '/');
    if (!slash || slash == path) strcpy(path, "/");
    else *slash = '\0';
}

static void term_size(int *rows, int *cols) {
    struct winsize ws;
    *rows = 24;
    *cols = 80;
    if (tty_fd >= 0 && ioctl(tty_fd, TIOCGWINSZ, &ws) == 0) {
        if (ws.ws_row > 0) *rows = ws.ws_row;
        if (ws.ws_col > 0) *cols = ws.ws_col;
    }
}

static void draw(const char *cwd, const Entries *entries, size_t cursor, bool icons, bool preview, bool border) {
    int rows, cols;
    term_size(&rows, &cols);
    dprintf(tty_fd, "\033[?25l\033[H\033[2J");
    dprintf(tty_fd, "\033[1mwalk\033[0m %s\n", cwd);
    int list_rows = rows - 3;
    if (list_rows < 1) list_rows = 1;
    size_t start = 0;
    if (cursor >= (size_t)list_rows) start = cursor - (size_t)list_rows + 1;
    int left_width = preview ? cols / 2 : cols;
    if (left_width < 20) left_width = cols;
    for (int r = 0; r < list_rows; r++) {
        size_t i = start + (size_t)r;
        if (i < entries->len) {
            const Entry *e = &entries->items[i];
            dprintf(tty_fd, "%s", i == cursor ? "\033[7m" : "");
            const char *icon = "";
            if (icons) icon = e->is_dir ? "d " : "f ";
            char suffix = e->is_dir ? '/' : ' ';
            dprintf(tty_fd, " %-*.*s%s%c\033[0m", left_width - 5, left_width - 5, icon, e->name, suffix);
        }
        dprintf(tty_fd, "\033[K\r\n");
    }
    if (preview) {
        dprintf(tty_fd, "\033[%d;1H%s preview %s\033[K", rows - 1, border ? "+" : "", border ? "+" : "");
    }
    dprintf(tty_fd, "\033[%d;1H%d item%s  q/esc: select  ctrl+c: cancel\033[K", rows, (int)entries->len, entries->len == 1 ? "" : "s");
    (void)cols;
}

static int read_key(void) {
    unsigned char c;
    ssize_t n = read(tty_fd, &c, 1);
    if (n <= 0) return -1;
    if (c == 27) {
        unsigned char seq[3];
        int flags = fcntl(tty_fd, F_GETFL, 0);
        fcntl(tty_fd, F_SETFL, flags | O_NONBLOCK);
        ssize_t a = read(tty_fd, &seq[0], 1);
        ssize_t b = a == 1 ? read(tty_fd, &seq[1], 1) : 0;
        fcntl(tty_fd, F_SETFL, flags);
        if (a == 1 && b == 1 && seq[0] == '[') {
            if (seq[1] == 'A') return 'k';
            if (seq[1] == 'B') return 'j';
            if (seq[1] == 'H') return 'g';
            if (seq[1] == 'F') return 'G';
        }
        return 27;
    }
    return c;
}

static int interactive(char *cwd, bool icons, bool dir_only, bool hide_hidden, bool preview, bool border) {
    tty_fd = open("/dev/tty", O_RDWR);
    if (tty_fd < 0) die_no_tty();
    if (tcgetattr(tty_fd, &saved_termios) == 0) {
        struct termios raw = saved_termios;
        raw.c_lflag &= (tcflag_t)~(ECHO | ICANON | IEXTEN);
        raw.c_iflag &= (tcflag_t)~(IXON | ICRNL);
        raw.c_cc[VMIN] = 1;
        raw.c_cc[VTIME] = 0;
        tcsetattr(tty_fd, TCSAFLUSH, &raw);
        term_saved = true;
        atexit(restore_term);
    }
    tty_write("\033[?1049h");

    Entries entries = {0};
    size_t cursor = 0;
    if (load_entries(cwd, &entries, dir_only, hide_hidden) != 0) {
        entries_push(&entries, "(empty)", 0, 0);
    }
    for (;;) {
        if (cursor >= entries.len && entries.len) cursor = entries.len - 1;
        draw(cwd, &entries, cursor, icons, preview, border);
        int k = read_key();
        if (k == -1 || k == 3) {
            entries_free(&entries);
            return 130;
        }
        if (k == 'q' || k == 27) {
            entries_free(&entries);
            return 0;
        }
        if ((k == 'j' || k == 'l' || k == 'n') && cursor + 1 < entries.len) cursor++;
        else if ((k == 'k' || k == 'h' || k == 'p') && cursor > 0) cursor--;
        else if (k == 'g') cursor = 0;
        else if (k == 'G' && entries.len) cursor = entries.len - 1;
        else if (k == ' ') preview = !preview;
        else if (k == '.') {
            hide_hidden = !hide_hidden;
            load_entries(cwd, &entries, dir_only, hide_hidden);
            cursor = 0;
        } else if (k == 127 || k == 8) {
            parent_path(cwd);
            load_entries(cwd, &entries, dir_only, hide_hidden);
            cursor = 0;
        } else if (k == '\r' || k == '\n') {
            if (entries.len && entries.items[cursor].is_dir) {
                char next[PATH_MAX];
                join_path(next, sizeof(next), cwd, entries.items[cursor].name);
                if (realpath(next, cwd)) {
                    load_entries(cwd, &entries, dir_only, hide_hidden);
                    cursor = 0;
                }
            }
        }
    }
}

int main(int argc, char **argv) {
    bool icons = false, dir_only = false, hide_hidden = false, preview = false, border = false;
    const char *path_arg = NULL;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--help") == 0 || strcmp(argv[i], "-h") == 0) {
            fputs(help_text, stderr);
            return 1;
        } else if (strcmp(argv[i], "--version") == 0 || strcmp(argv[i], "-v") == 0) {
            puts("v1.13.0");
            return 0;
        } else if (strcmp(argv[i], "--icons") == 0) icons = true;
        else if (strcmp(argv[i], "--dir-only") == 0) dir_only = true;
        else if (strcmp(argv[i], "--hide-hidden") == 0) hide_hidden = true;
        else if (strcmp(argv[i], "--preview") == 0) preview = true;
        else if (strcmp(argv[i], "--with-border") == 0) border = true;
        else if (strcmp(argv[i], "--fuzzy") == 0) {
            /* Fuzzy mode changes interactive filtering in the original. */
        } else if (!path_arg) path_arg = argv[i];
    }

    char cwd[PATH_MAX];
    if (path_arg) {
        if (!realpath(path_arg, cwd)) {
            char tmp[PATH_MAX];
            if (path_arg[0] == '/') {
                strncpy(cwd, path_arg, sizeof(cwd) - 1);
                cwd[sizeof(cwd) - 1] = '\0';
            } else if (getcwd(tmp, sizeof(tmp))) {
                size_t used = snprintf(cwd, sizeof(cwd), "%s/", tmp);
                if (used < sizeof(cwd)) {
                    strncat(cwd, path_arg, sizeof(cwd) - strlen(cwd) - 1);
                }
            } else {
                strncpy(cwd, path_arg, sizeof(cwd) - 1);
                cwd[sizeof(cwd) - 1] = '\0';
            }
        }
        struct stat st;
        if (stat(cwd, &st) == 0 && !S_ISDIR(st.st_mode)) parent_path(cwd);
    } else if (!getcwd(cwd, sizeof(cwd))) {
        strcpy(cwd, ".");
    }

    int rc = interactive(cwd, icons, dir_only, hide_hidden, preview, border);
    restore_term();
    if (rc == 0) {
        printf("%s\n", cwd);
        fflush(stdout);
    }
    return rc == 130 ? 1 : rc;
}
