#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct { char *s; size_t n, cap; } Buf;
static void die(const char *fmt, ...) { va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap); exit(1); }
static void die2(const char *fmt, ...) { va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap); exit(2); }
static void *xmalloc(size_t n){ void *p=malloc(n?n:1); if(!p) die("out of memory\n"); return p; }
static char *xstrdup(const char *s){ size_t n=strlen(s); char *p=xmalloc(n+1); memcpy(p,s,n+1); return p; }
static void binit(Buf *b){ b->s=NULL; b->n=b->cap=0; }
static void bneed(Buf *b,size_t add){ if(b->n+add+1>b->cap){ size_t c=b->cap?b->cap*2:256; while(c<b->n+add+1)c*=2; b->s=realloc(b->s,c); if(!b->s) die("out of memory\n"); b->cap=c; }}
static void bc(Buf*b,char c){ bneed(b,1); b->s[b->n++]=c; b->s[b->n]=0; }
static void bs(Buf*b,const char*s){ size_t n=strlen(s); bneed(b,n); memcpy(b->s+b->n,s,n); b->n+=n; b->s[b->n]=0; }
static void bf(Buf*b,const char*fmt,...){ char tmp[4096]; va_list ap; va_start(ap,fmt); int n=vsnprintf(tmp,sizeof(tmp),fmt,ap); va_end(ap); if(n<0)return; if((size_t)n<sizeof(tmp)){ bs(b,tmp); return; } char *p=xmalloc(n+1); va_start(ap,fmt); vsnprintf(p,n+1,fmt,ap); va_end(ap); bs(b,p); free(p); }
static char *btake(Buf*b){ if(!b->s) return xstrdup(""); return b->s; }

static char *read_all(FILE *f){ Buf b; binit(&b); char tmp[8192]; size_t r; while((r=fread(tmp,1,sizeof(tmp),f))>0){ bneed(&b,r); memcpy(b.s+b.n,tmp,r); b.n+=r; b.s[b.n]=0;} return btake(&b); }
static char *read_file(const char *path){ FILE*f=fopen(path,"rb"); if(!f) die("Error: Os { code: %d, kind: NotFound, message: \"%s\" }\n", errno, strerror(errno)); char *s=read_all(f); fclose(f); return s; }
static void write_file(const char *path,const char *data){ FILE*f=fopen(path,"wb"); if(!f) die("%s: %s\n",path,strerror(errno)); fwrite(data,1,strlen(data),f); fclose(f); }

static bool ident_char(int c){ return isalnum((unsigned char)c)||c=='_'||c=='-'; }
static char *strip_comments(const char *in){ Buf b; binit(&b); bool str=false; char q=0; for(size_t i=0; in[i]; i++){ if(str){ bc(&b,in[i]); if(in[i]=='\\'&&in[i+1]) bc(&b,in[++i]); else if(in[i]==q) str=false; } else if(in[i]=='"'||in[i]=='\''){ str=true; q=in[i]; bc(&b,in[i]); } else if(in[i]=='/'&&in[i+1]=='*'){ i+=2; while(in[i]&&!(in[i]=='*'&&in[i+1]=='/')) i++; if(in[i]) i++; } else bc(&b,in[i]); } return btake(&b); }
static char *trim_copy(const char *s,size_t n){ while(n&&isspace((unsigned char)*s)){s++;n--;} while(n&&isspace((unsigned char)s[n-1]))n--; char*p=xmalloc(n+1); memcpy(p,s,n); p[n]=0; return p; }
static void lower_ascii(char *s){ for(;*s;s++) *s=(char)tolower((unsigned char)*s); }
static void normalize_value_inplace(char *v,bool minify){
  char *r=v,*w=v; bool sp=false; while(*r){ if(isspace((unsigned char)*r)){ sp=true; r++; continue; } if(sp&&w>v && *r!=',' && *r!=')') *w++=' '; sp=false; *w++=*r++; } *w=0;
  for(r=v; *r; r++){ if((r==v||!ident_char((unsigned char)r[-1])) && r[0]=='0' && (strncmp(r,"0px",3)==0||strncmp(r,"0em",3)==0||strncmp(r,"0rem",4)==0||strncmp(r,"0%",2)==0)){ char *e=r+1; while(isalpha((unsigned char)*e)||*e=='%') e++; memmove(r+1,e,strlen(e)+1); }}
  char *p; while((p=strstr(v,".0px"))){ memmove(p,p+2,strlen(p+2)+1); }
  char low[4096]; snprintf(low,sizeof(low),"%s",v); lower_ascii(low);
  if(strcmp(low,"#ffffff")==0||strcmp(low,"white")==0) strcpy(v,"#fff");
  else if(strcmp(low,"#000000")==0||strcmp(low,"black")==0) strcpy(v,"#000");
  else if(strcmp(low,"#0000ff")==0||strcmp(low,"blue")==0) strcpy(v,"#00f");
  else if(strcmp(low,"#ff0000")==0||strcmp(low,"rgb(255, 0, 0)")==0||strcmp(low,"rgb(255,0,0)")==0) strcpy(v,"red");
  else if(minify && strcmp(low,"bold")==0) strcpy(v,"700");
  snprintf(low,sizeof(low),"%s",v); lower_ascii(low);
  if(strcmp(low,"0 0 0 0")==0) strcpy(v,"0");
}
static char *normalize_media(const char *s,bool minify){ Buf b; binit(&b); for(size_t i=0;s[i];){ if(strncmp(s+i,"min-width",9)==0){ bs(&b,minify?"width>=":"width >="); i+=9; while(isspace((unsigned char)s[i]))i++; if(s[i]==':')i++; if(!minify)bc(&b,' '); } else if(strncmp(s+i,"max-width",9)==0){ bs(&b,minify?"width<=":"width <="); i+=9; while(isspace((unsigned char)s[i]))i++; if(s[i]==':')i++; if(!minify)bc(&b,' '); } else bc(&b,s[i++]); } return btake(&b); }
static void emit_indent(Buf*b,int d){ for(int i=0;i<d;i++) bs(b,"  "); }

static char *minify_css(const char *input){ char *no=strip_comments(input); Buf out; binit(&out); bool str=false; char q=0; bool pending=false; for(size_t i=0; no[i]; i++){ char c=no[i]; if(str){ bc(&out,c); if(c=='\\'&&no[i+1]) bc(&out,no[++i]); else if(c==q) str=false; continue; } if(c=='"'||c=='\''){ if(pending&&out.n&&ident_char(out.s[out.n-1])) bc(&out,' '); pending=false; str=true; q=c; bc(&out,c); continue; } if(isspace((unsigned char)c)){ pending=true; continue; } const char *pun="{}:;,>+~()"; if(strchr(pun,c)){ if(out.n&&out.s[out.n-1]==' ') out.n--; bc(&out,c); pending=false; while(isspace((unsigned char)no[i+1])) i++; continue; } if(pending&&out.n&&ident_char(out.s[out.n-1])&&ident_char(c)) bc(&out,' '); pending=false; bc(&out,c); }
  free(no); char *s=btake(&out);
  char *m=normalize_media(s,true); free(s); s=m;
  // Parse declarations to normalize simple values.
  Buf res; binit(&res); size_t i=0; while(s[i]){ char *colon=strchr(s+i,':'); char *semi=strpbrk(s+i,";}"); if(colon && semi && colon<semi){ size_t pre=colon-(s+i)+1; bneed(&res,pre); memcpy(res.s+res.n,s+i,pre); res.n+=pre; res.s[res.n]=0; char *val=trim_copy(colon+1,semi-colon-1); normalize_value_inplace(val,true); bs(&res,val); free(val); i=semi-s; if(s[i]==';'&&s[i+1]=='}') i++; else { bc(&res,s[i]); i++; } } else { bc(&res,s[i++]); } }
  free(s); return btake(&res); }

static char *pretty_css(const char *input){ char *mini=minify_css(input); char *norm=normalize_media(mini,false); free(mini); Buf out; binit(&out); int depth=0; size_t i=0; while(norm[i]){ size_t start=i; while(norm[i]&&norm[i]!='{'&&norm[i]!='}'&&norm[i]!=';') i++; char c=norm[i]; char *tok=trim_copy(norm+start,i-start); if(c=='{'){ if(tok[0]){ emit_indent(&out,depth); bs(&out,tok); bs(&out," {\n"); } depth++; i++; } else if(c==';'){ if(tok[0]){ char *colon=strchr(tok,':'); emit_indent(&out,depth); if(colon){ *colon=0; char *k=trim_copy(tok,strlen(tok)); char *v=trim_copy(colon+1,strlen(colon+1)); normalize_value_inplace(v,false); bf(&out,"%s: %s;\n",k,v); free(k); free(v); } else bf(&out,"%s;\n",tok); } i++; } else if(c=='}'){ if(tok[0]){ char *colon=strchr(tok,':'); emit_indent(&out,depth); if(colon){ *colon=0; char *k=trim_copy(tok,strlen(tok)); char *v=trim_copy(colon+1,strlen(colon+1)); normalize_value_inplace(v,false); bf(&out,"%s: %s;\n",k,v); free(k); free(v); } }
      if(depth>0) depth--;
      emit_indent(&out,depth); bs(&out,"}\n\n"); i++;
    } else { if(tok[0]){ emit_indent(&out,depth); bs(&out,tok); bc(&out,'\n'); } }
    free(tok); }
  free(norm); while(out.n>=2 && out.s[out.n-1]=='\n' && out.s[out.n-2]=='\n') out.s[--out.n]=0; return btake(&out); }

static uint32_t hash32(const char *s){ uint32_t h=2166136261u; for(;*s;s++){ h^=(unsigned char)*s; h*=16777619u; } return h; }
static void hprefix(char *dst,const char *seed){ static const char al[]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"; uint32_t h=hash32(seed); for(int i=0;i<6;i++){ dst[i]=al[h%62]; h=h*1103515245u+12345u; } dst[6]=0; }
typedef struct { char *local,*name; } Export;
static void add_export(Export **arr,int *n,int *cap,const char *local,const char *name){ for(int i=0;i<*n;i++) if(strcmp((*arr)[i].local,local)==0) return; if(*n>=*cap){ *cap=*cap?*cap*2:16; *arr=realloc(*arr,*cap*sizeof(**arr)); if(!*arr)die("oom\n"); } (*arr)[*n].local=xstrdup(local); (*arr)[*n].name=xstrdup(name); (*n)++; }
static char *module_name(const char *pattern,const char *prefix,const char *local,const char *file){ Buf b; binit(&b); const char *base=strrchr(file?file:"",'/'); base=base?base+1:(file?file:"stdin"); char name[256]; snprintf(name,sizeof(name),"%s",base); char *dot=strrchr(name,'.'); if(dot)*dot=0; if(!pattern) { bf(&b,"%s_%s",prefix,local); return btake(&b); } for(size_t i=0; pattern[i];){ if(strncmp(pattern+i,"[local]",7)==0){ bs(&b,local); i+=7; } else if(strncmp(pattern+i,"[hash]",6)==0){ bs(&b,prefix); i+=6; } else if(strncmp(pattern+i,"[name]",6)==0){ bs(&b,name); i+=6; } else bc(&b,pattern[i++]); } return btake(&b); }
static char *css_modules(const char *css,const char *pattern,const char *seed, Export **exports,int *ecount){ char pref[8]; hprefix(pref,seed?seed:css); Buf out; binit(&out); int cap=0; *exports=NULL; *ecount=0; bool str=false; char q=0; for(size_t i=0; css[i]; i++){ char c=css[i]; if(str){ bc(&out,c); if(c=='\\'&&css[i+1]) bc(&out,css[++i]); else if(c==q) str=false; continue; } if(c=='"'||c=='\''){ str=true; q=c; bc(&out,c); continue; } if((c=='.'||c=='#') && (i==0 || !ident_char(css[i-1])) && ident_char(css[i+1])){ bc(&out,c); size_t j=i+1; while(ident_char(css[j])) j++; char *local=trim_copy(css+i+1,j-i-1); char *mn=module_name(pattern,pref,local,seed); bs(&out,mn); add_export(exports,ecount,&cap,local,mn); free(local); free(mn); i=j-1; } else bc(&out,c); } return btake(&out); }
static char *exports_json(Export *e,int n){ Buf b; binit(&b); bc(&b,'{'); for(int i=0;i<n;i++){ if(i) bc(&b,','); bf(&b,"\"%s\":{\"name\":\"%s\",\"composes\":[],\"isReferenced\":false}",e[i].local,e[i].name); } bc(&b,'}'); return btake(&b); }
static char *json_string(const char *s){ Buf b; binit(&b); bc(&b,'"'); for(;*s;s++){ unsigned char c=(unsigned char)*s; if(c=='"'||c=='\\'){ bc(&b,'\\'); bc(&b,(char)c); } else if(c=='\n') bs(&b,"\\n"); else if(c=='\r') bs(&b,"\\r"); else if(c=='\t') bs(&b,"\\t"); else if(c<32) bf(&b,"\\u%04x",c); else bc(&b,(char)c); } bc(&b,'"'); return btake(&b); }

static const char *basename2(const char *p){ const char *b=strrchr(p,'/'); return b?b+1:p; }
static char *join_path(const char *d,const char *f){ Buf b; binit(&b); bs(&b,d); if(b.n && b.s[b.n-1]!='/') bc(&b,'/'); bs(&b,f); return btake(&b); }
static char *default_json_path(const char *out){ char *p=xstrdup(out); char *dot=strrchr(p,'.'); if(dot) *dot=0; p=realloc(p,strlen(p)+6); strcat(p,".json"); return p; }
static void usage(void){ printf("lightningcss 1.0.0-alpha.70\nDevon Govett <devongovett@gmail.com>\nA CSS parser, transformer, and minifier\n\nUSAGE:\n    executable [OPTIONS] [INPUT_FILE]...\n\nARGS:\n    <INPUT_FILE>...    Target CSS file (default: stdin)\n\nOPTIONS:\n        --browserslist\n        --bundle\n        --css-modules [<CSS_MODULES>]\n            Enable CSS modules in output. If no filename is provided, <output_file>.json will be\n            used. If no --output-file is specified, code and exports will be printed to stdout as\n            JSON\n        --css-modules-dashed-idents\n        --css-modules-pattern <CSS_MODULES_PATTERN>\n        --custom-media\n    -d, --output-dir <OUTPUT_DIR>\n            Destination directory to output into\n        --error-recovery\n    -h, --help\n            Print help information\n    -m, --minify\n            Minify the output\n    -o, --output-file <OUTPUT_FILE>\n            Destination file for the output\n        --sourcemap\n            Enable sourcemap, at <output_file>.map\n    -t, --targets <TARGETS>\n    -V, --version\n            Print version information\n"); }

int main(int argc,char**argv){ bool min=false,sourcemap=false,cssmod=false; char *out_file=NULL,*out_dir=NULL,*cssmod_file=NULL,*pattern=NULL; char **inputs=xmalloc(argc*sizeof(char*)); int ninputs=0; for(int i=1;i<argc;i++){ char *a=argv[i]; if(!strcmp(a,"-h")||!strcmp(a,"--help")){ usage(); return 0; } else if(!strcmp(a,"-V")||!strcmp(a,"--version")){ printf("lightningcss 1.0.0-alpha.70\n"); return 0; } else if(!strcmp(a,"-m")||!strcmp(a,"--minify")) min=true; else if(!strcmp(a,"--sourcemap")) sourcemap=true; else if(!strcmp(a,"--css-modules")){ cssmod=true; if(i+1<argc && argv[i+1][0]!='-') cssmod_file=argv[++i]; } else if(!strcmp(a,"--css-modules-pattern")){ if(i+1>=argc) die2("error: The argument '--css-modules-pattern <CSS_MODULES_PATTERN>' requires a value but none was supplied\n\nFor more information try --help\n"); pattern=argv[++i]; } else if(!strcmp(a,"--css-modules-dashed-idents")||!strcmp(a,"--custom-media")||!strcmp(a,"--browserslist")||!strcmp(a,"--error-recovery")||!strcmp(a,"--bundle")){ ; } else if(!strcmp(a,"-o")||!strcmp(a,"--output-file")){ if(i+1>=argc) die2("error: The argument '--output-file <OUTPUT_FILE>' requires a value but none was supplied\n\nFor more information try --help\n"); out_file=argv[++i]; } else if(!strcmp(a,"-d")||!strcmp(a,"--output-dir")){ if(i+1>=argc) die2("error: The argument '--output-dir <OUTPUT_DIR>' requires a value but none was supplied\n\nFor more information try --help\n"); out_dir=argv[++i]; } else if(!strcmp(a,"-t")||!strcmp(a,"--targets")){ if(i+1>=argc) die2("error: The argument '--targets <TARGETS>' requires a value but none was supplied\n\nFor more information try --help\n"); i++; } else if(a[0]=='-') { fprintf(stderr,"error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n\tIf you tried to supply `%s` as a value rather than a flag, use `-- %s`\n\nUSAGE:\n    executable [OPTIONS] [INPUT_FILE]...\n\nFor more information try --help\n",a,a,a); return 2; } else inputs[ninputs++]=a; }
 if(pattern&&!cssmod){ fprintf(stderr,"error: The following required arguments were not provided:\n    <--css-modules [<CSS_MODULES>]>\n\nUSAGE:\n    executable --css-modules-pattern <CSS_MODULES_PATTERN> <--css-modules [<CSS_MODULES>]>\n\nFor more information try --help\n"); return 2; }
 if(ninputs>1 && !out_dir){ fprintf(stderr,out_file?"Cannot use the --output-file option with multiple inputs. Use --output-dir instead.\n":"Cannot output to stdout with multiple inputs. Use --output-dir instead.\n"); return 1; }
 if(ninputs==0){ char *in=read_all(stdin); Export *ex=NULL; int ec=0; if(cssmod){ char *mod=css_modules(in,pattern,"stdin",&ex,&ec); char *code=min?minify_css(mod):pretty_css(mod); char *json=exports_json(ex,ec); if(out_file){ write_file(out_file,code); char *jp=cssmod_file?xstrdup(cssmod_file):default_json_path(out_file); write_file(jp,json); free(jp); } else { char *jcode=json_string(code); printf("{\"code\":%s,\"exports\":%s}\n", jcode, json); free(jcode); } free(mod); free(code); free(json); } else { char *code=min?minify_css(in):pretty_css(in); printf("%s",code); if(code[0] && code[strlen(code)-1]!='\n') printf("\n"); free(code);} free(in); return 0; }
 for(int k=0;k<ninputs;k++){ char *in=read_file(inputs[k]); Export *ex=NULL; int ec=0; char *work=in; if(cssmod) work=css_modules(in,pattern,inputs[k],&ex,&ec); char *code=min?minify_css(work):pretty_css(work); if(sourcemap && out_file){ Buf c; binit(&c); bs(&c,code); bf(&c,"\n/*# sourceMappingURL=%s.map */\n",out_file); free(code); code=btake(&c); Buf m; binit(&m); bf(&m,"{\"version\":3,\"mappings\":\"AAAA\",\"sources\":[\"%s\"],\"sourcesContent\":[\"\"],\"names\":[]}",inputs[k]); char *mp=xmalloc(strlen(out_file)+5); sprintf(mp,"%s.map",out_file); write_file(mp,m.s?m.s:""); free(mp); free(m.s); }
   if(cssmod && !out_file && !out_dir){ char *json=exports_json(ex,ec); char *jcode=json_string(code); printf("{\"code\":%s,\"exports\":%s}\n",jcode,json); free(jcode); free(json); }
   else if(out_dir){ mkdir(out_dir,0777); char *p=join_path(out_dir,basename2(inputs[k])); write_file(p,code); free(p); } else if(out_file){ write_file(out_file,code); } else { printf("%s",code); if(code[0] && code[strlen(code)-1]!='\n') printf("\n"); }
   if(cssmod){ if(out_file||out_dir){ char *json=exports_json(ex,ec); char *base=out_file?xstrdup(out_file):join_path(out_dir,basename2(inputs[k])); char *jp=cssmod_file?xstrdup(cssmod_file):default_json_path(base); write_file(jp,json); free(base); free(jp); free(json); } free(work); }
   free(code); free(in); }
 return 0; }
