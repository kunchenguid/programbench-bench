#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct { char *s; } Str;
typedef struct { Str *v; int n, cap; } StrVec;
typedef struct { char *norm; int line; int col; int off; } Tok;
typedef struct { Tok *v; int n, cap; } TokVec;
typedef struct { char *path; char *src; long len; int *line_start; int lines; TokVec toks; } File;
typedef struct { File *v; int n, cap; } FileVec;
typedef struct { int file; int start_line, end_line; int start_tok, end_tok; char *key; unsigned long hash; int tok_count; } Seg;
typedef struct { Seg *v; int n, cap; } SegVec;

typedef struct { int *v; int n, cap; } IntVec;

static const char *usage =
"Usage: dupl [flags] [paths]\n\n"
"Paths:\n"
"  If the given path is a file, dupl will use it regardless of\n"
"  the file extension. If it is a directory, it will recursively\n"
"  search for *.go files in that directory.\n\n"
"  If no path is given, dupl will recursively search for *.go\n"
"  files in the current directory.\n\n"
"Flags:\n"
"  -files\n"
"    \tread file names from stdin one at each line\n"
"  -html\n"
"    \toutput the results as HTML, including duplicate code fragments\n"
"  -plumbing\n"
"    \tplumbing (easy-to-parse) output for consumption by scripts or tools\n"
"  -t, -threshold size\n"
"    \tminimum token sequence size as a clone (default 15)\n"
"  -vendor\n"
"    \tcheck files in vendor directory\n"
"  -v, -verbose\n"
"    \texplain what is being done\n\n"
"Examples:\n"
"  dupl -t 100\n"
"    \tSearch clones in the current directory of size at least\n"
"    \t100 tokens.\n"
"  dupl $(find app/ -name '*_test.go')\n"
"    \tSearch for clones in tests in the app directory.\n"
"  find app/ -name '*_test.go' |dupl -files\n"
"    \tThe same as above.\n";

static int threshold = 15;
static bool opt_files=false, opt_html=false, opt_plumbing=false, opt_vendor=false, opt_verbose=false;

static void *xmalloc(size_t n){ void *p=malloc(n?n:1); if(!p){perror("malloc"); exit(2);} return p; }
static void *xrealloc(void *p,size_t n){ p=realloc(p,n?n:1); if(!p){perror("realloc"); exit(2);} return p; }
static char *xstrdup(const char *s){ char *r=strdup(s?s:""); if(!r){perror("strdup"); exit(2);} return r; }
static char *xstrndup2(const char *s, size_t n){ char *r=xmalloc(n+1); memcpy(r,s,n); r[n]=0; return r; }
static void strvec_push(StrVec *a, const char *s){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:16; a->v=xrealloc(a->v,a->cap*sizeof*a->v);} a->v[a->n++].s=xstrdup(s); }
static void tok_push(TokVec *a, const char *norm, int line, int col, int off){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:256; a->v=xrealloc(a->v,a->cap*sizeof*a->v);} a->v[a->n++]=(Tok){xstrdup(norm),line,col,off}; }
static void file_push(FileVec *a, File f){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:16; a->v=xrealloc(a->v,a->cap*sizeof*a->v);} a->v[a->n++]=f; }
static void seg_push(SegVec *a, Seg s){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:128; a->v=xrealloc(a->v,a->cap*sizeof*a->v);} a->v[a->n++]=s; }
static void int_push(IntVec *a, int x){ if(a->n==a->cap){a->cap=a->cap?a->cap*2:8; a->v=xrealloc(a->v,a->cap*sizeof*a->v);} a->v[a->n++]=x; }

static void vlogmsg(const char *msg){ if(!opt_verbose) return; time_t t=time(NULL); struct tm tm; localtime_r(&t,&tm); char buf[64]; strftime(buf,sizeof buf,"%Y/%m/%d %H:%M:%S",&tm); fprintf(stderr,"%s %s\n",buf,msg); }
static void logerr(const char *fmt, ...){ time_t t=time(NULL); struct tm tm; localtime_r(&t,&tm); char buf[64]; strftime(buf,sizeof buf,"%Y/%m/%d %H:%M:%S",&tm); fprintf(stderr,"%s ",buf); va_list ap; va_start(ap,fmt); vfprintf(stderr,fmt,ap); va_end(ap); fputc('\n',stderr); }

static bool has_suffix(const char *s,const char *suf){ size_t a=strlen(s), b=strlen(suf); return a>=b && strcmp(s+a-b,suf)==0; }
static const char *base_name(const char *p){ const char *q=strrchr(p,'/'); return q?q+1:p; }
static bool path_has_vendor(const char *p){ const char *q=p; while((q=strstr(q,"vendor"))){ bool left=(q==p||q[-1]=='/'); bool right=(q[6]==0||q[6]=='/'); if(left&&right) return true; q+=6;} return false; }
static int cmp_str(const void *a,const void *b){ const Str *x=a,*y=b; return strcmp(x->s,y->s); }

static void collect_dir(StrVec *paths, const char *path){
    struct stat st; if(lstat(path,&st)!=0){ logerr("lstat %s: %s", path, strerror(errno)); return; }
    if(S_ISDIR(st.st_mode)){
        DIR *d=opendir(path); if(!d){ logerr("open %s: %s", path, strerror(errno)); return; }
        struct dirent *e; StrVec sub={0};
        while((e=readdir(d))){ if(strcmp(e->d_name,".")==0||strcmp(e->d_name,"..")==0) continue; if(!opt_vendor && strcmp(e->d_name,"vendor")==0) continue; size_t n=strlen(path)+strlen(e->d_name)+2; char *p=xmalloc(n); snprintf(p,n,"%s/%s",path,e->d_name); strvec_push(&sub,p); free(p); }
        closedir(d); qsort(sub.v,sub.n,sizeof*sub.v,cmp_str);
        for(int i=0;i<sub.n;i++){ collect_dir(paths,sub.v[i].s); free(sub.v[i].s); } free(sub.v);
    } else if(S_ISREG(st.st_mode)){
        if(has_suffix(path,".go") && (opt_vendor || !path_has_vendor(path))) strvec_push(paths,path);
    }
}

static void add_input_path(StrVec *out, const char *path, bool direct_file){
    struct stat st;
    if(lstat(path,&st)!=0){ logerr("lstat %s: %s", path, strerror(errno)); return; }
    if(S_ISDIR(st.st_mode)) collect_dir(out, path);
    else if(S_ISREG(st.st_mode)) { if(direct_file || has_suffix(path,".go")) strvec_push(out, path); }
}

static char *read_file(const char *path, long *len){
    FILE *f=fopen(path,"rb"); if(!f){ logerr("open %s: %s",path,strerror(errno)); return NULL; }
    if(fseek(f,0,SEEK_END)!=0){ fclose(f); return NULL; } long n=ftell(f); rewind(f);
    char *buf=xmalloc((size_t)n+1); size_t r=fread(buf,1,(size_t)n,f); fclose(f); buf[r]=0; *len=(long)r; return buf;
}

static bool is_kw(const char *s){
    static const char *kw[] = {"break","case","chan","const","continue","default","defer","else","fallthrough","for","func","go","goto","if","import","interface","map","package","range","return","select","struct","switch","type","var",NULL};
    for(int i=0;kw[i];i++) if(strcmp(s,kw[i])==0) return true; return false;
}

static void add_line_starts(File *f){
    int cap=64; f->line_start=xmalloc(cap*sizeof(int)); f->lines=1; f->line_start[0]=0;
    for(long i=0;i<f->len;i++) if(f->src[i]=='\n'){ if(f->lines==cap){cap*=2; f->line_start=xrealloc(f->line_start,cap*sizeof(int));} f->line_start[f->lines++]=(int)i+1; }
}

static void tokenize(File *f){
    int line=1,col=1; char *s=f->src; long n=f->len;
    for(long i=0;i<n;){ unsigned char c=s[i];
        if(c==' '||c=='\t'||c=='\r'){ i++; col++; continue; }
        if(c=='\n'){ i++; line++; col=1; continue; }
        if(c=='/' && i+1<n && s[i+1]=='/'){ i+=2; col+=2; while(i<n && s[i]!='\n'){i++; col++;} continue; }
        if(c=='/' && i+1<n && s[i+1]=='*'){ i+=2; col+=2; while(i+1<n && !(s[i]=='*'&&s[i+1]=='/')){ if(s[i]=='\n'){line++; col=1; i++;} else {i++; col++;} } if(i+1<n){i+=2; col+=2;} continue; }
        int start_col=col, start_off=(int)i;
        if(isalpha(c)||c=='_'){
            long j=i+1; while(j<n && (isalnum((unsigned char)s[j])||s[j]=='_')) j++;
            char *w=xstrndup2(s+i,(size_t)(j-i)); tok_push(&f->toks,is_kw(w)?w:"ID",line,start_col,start_off); free(w); col+=(int)(j-i); i=j; continue;
        }
        if(isdigit(c)){
            long j=i+1; while(j<n && (isalnum((unsigned char)s[j])||s[j]=='_'||s[j]=='.')) j++; tok_push(&f->toks,"LIT",line,start_col,start_off); col+=(int)(j-i); i=j; continue;
        }
        if(c=='"' || c=='\'' || c=='`'){
            char quote=c; i++; col++; if(quote=='`'){ while(i<n && s[i]!='`'){ if(s[i]=='\n'){line++; col=1; i++;} else {i++; col++;} } if(i<n){i++; col++;} }
            else { while(i<n){ if(s[i]=='\\' && i+1<n){i+=2; col+=2; continue;} if(s[i]==quote){i++; col++; break;} if(s[i]=='\n'){line++; col=1; i++;} else {i++; col++;} } }
            tok_push(&f->toks,"LIT",line,start_col,start_off); continue;
        }
        if(strchr("{}()[];,:.",c)){ char buf[2]={(char)c,0}; tok_push(&f->toks,buf,line,start_col,start_off); i++; col++; continue; }
        if(strchr("+-*/%=&|!<>^~",c)){ tok_push(&f->toks,"OP",line,start_col,start_off); i++; col++; while(i<n && strchr("+-*/%=&|!<>^~",(unsigned char)s[i])){i++; col++;} continue; }
        i++; col++;
    }
}

static char *make_key(File *f, int a, int b, unsigned long *hash){
    size_t cap=64,len=0; char *r=xmalloc(cap); r[0]=0; unsigned long h=1469598103934665603ULL;
    for(int i=a;i<=b;i++){ const char *p=f->toks.v[i].norm; for(;*p;p++){ h^=(unsigned char)*p; h*=1099511628211ULL; if(len+2>=cap){cap*=2; r=xrealloc(r,cap);} r[len++]=*p; } if(len+2>=cap){cap*=2; r=xrealloc(r,cap);} r[len++]=' '; h^=' '; h*=1099511628211ULL; }
    r[len]=0; *hash=h; return r;
}

static int find_matching(File *f, int open_idx){ int depth=0; for(int i=open_idx;i<f->toks.n;i++){ char *t=f->toks.v[i].norm; if(strcmp(t,"{")==0) depth++; else if(strcmp(t,"}")==0){ depth--; if(depth==0) return i; } } return -1; }

static bool overlaps_same_file(Seg *a, Seg *b){ return a->file==b->file && !(a->end_line < b->start_line || b->end_line < a->start_line); }

static void build_segments(FileVec *files, SegVec *segs){
    for(int fi=0; fi<files->n; fi++){
        File *f=&files->v[fi];
        for(int i=0;i<f->toks.n;i++){
            if(strcmp(f->toks.v[i].norm,"func")!=0) continue;
            int open=-1; for(int j=i+1;j<f->toks.n && j<i+80;j++){ if(strcmp(f->toks.v[j].norm,"{")==0){open=j; break;} if(strcmp(f->toks.v[j].norm,";")==0) break; }
            if(open<0) continue; int close=find_matching(f,open); if(close<0) continue;
            int count=close-i+1; if(count>=threshold){ unsigned long h; char *key=make_key(f,i,close,&h); Seg s={fi,f->toks.v[i].line,f->toks.v[close].line,i,close,key,h,count}; seg_push(segs,s); }
            i=close;
        }
        /* For files without complete funcs, let whole-file package fragments match. */
        if(segs->n==0 && f->toks.n>=threshold){ unsigned long h; char *key=make_key(f,0,f->toks.n-1,&h); Seg s={fi,f->toks.v[0].line,f->toks.v[f->toks.n-1].line,0,f->toks.n-1,key,h,f->toks.n}; seg_push(segs,s); }
    }
}

static int cmp_seg(const void *a,const void *b){ const Seg *x=a,*y=b; if(x->hash<y->hash) return -1; if(x->hash>y->hash) return 1; int c=strcmp(x->key,y->key); if(c) return c; if(x->file!=y->file) return x->file-y->file; if(x->start_line!=y->start_line) return x->start_line-y->start_line; return x->end_line-y->end_line; }

static void html_escape(FILE *out, const char *s, int n){ for(int i=0;i<n;i++){ char c=s[i]; if(c=='&') fputs("&amp;",out); else if(c=='<') fputs("&lt;",out); else if(c=='>') fputs("&gt;",out); else fputc(c,out); } }
static void print_fragment(File *f,int a,int b){ int start=f->line_start[a-1]; int end=(b<f->lines?f->line_start[b]-1:(int)f->len); if(end<start) end=start; html_escape(stdout,f->src+start,end-start); }

static void output_groups(FileVec *files, SegVec *segs){
    qsort(segs->v,segs->n,sizeof*segs->v,cmp_seg);
    if(opt_html){ puts("<!DOCTYPE html>\n<meta charset=\"utf-8\"/>\n<title>Duplicates</title>\n<style>\n\tpre {\n\t\tbackground-color: #FFD;\n\t\tborder: 1px solid #E2E2E2;\n\t\tpadding: 1ex;\n\t}\n</style>"); }
    int groups=0;
    for(int i=0;i<segs->n;){ int j=i+1; while(j<segs->n && segs->v[j].hash==segs->v[i].hash && strcmp(segs->v[j].key,segs->v[i].key)==0) j++;
        IntVec members={0};
        for(int k=i;k<j;k++){
            bool dup=false; for(int m=0;m<members.n;m++){ Seg *a=&segs->v[members.v[m]]; if(a->file==segs->v[k].file && a->start_line==segs->v[k].start_line && a->end_line==segs->v[k].end_line){dup=true; break;} }
            if(!dup) int_push(&members,k);
        }
        if(members.n>=2){
            groups++;
            if(opt_plumbing){ for(int m=0;m<members.n;m++){ Seg *a=&segs->v[members.v[m]], *b=&segs->v[members.v[(m+1)%members.n]]; printf("%s:%d-%d: duplicate of %s:%d-%d\n",files->v[a->file].path,a->start_line,a->end_line,files->v[b->file].path,b->start_line,b->end_line); } }
            else if(opt_html){ printf("<h1>#%d found %d clones</h1>\n",groups,members.n); for(int m=0;m<members.n;m++){ Seg *a=&segs->v[members.v[m]]; printf("<h2>%s:%d</h2>\n<pre>",files->v[a->file].path,a->start_line); print_fragment(&files->v[a->file],a->start_line,a->end_line); puts("</pre>"); } }
            else { printf("found %d clones:\n",members.n); for(int m=0;m<members.n;m++){ Seg *a=&segs->v[members.v[m]]; printf("  %s:%d,%d\n",files->v[a->file].path,a->start_line,a->end_line); } putchar('\n'); }
        }
        free(members.v); i=j;
    }
    if(!opt_plumbing && !opt_html) printf("Found total %d clone groups.\n",groups);
}

int main(int argc, char **argv){
    StrVec paths={0};
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(strcmp(a,"--help")==0 || strcmp(a,"-h")==0){ fputs(usage,stdout); return 2; }
        else if(strcmp(a,"-files")==0) opt_files=true;
        else if(strcmp(a,"-html")==0) opt_html=true;
        else if(strcmp(a,"-plumbing")==0) opt_plumbing=true;
        else if(strcmp(a,"-vendor")==0) opt_vendor=true;
        else if(strcmp(a,"-v")==0 || strcmp(a,"-verbose")==0) opt_verbose=true;
        else if(strcmp(a,"-t")==0 || strcmp(a,"-threshold")==0){ if(i+1>=argc){ fprintf(stderr,"flag needs an argument: %s\n%s",a,usage); return 2;} threshold=atoi(argv[++i]); if(threshold<1) threshold=1; }
        else if(strncmp(a,"-threshold=",11)==0){ threshold=atoi(a+11); if(threshold<1) threshold=1; }
        else if(strncmp(a,"-t=",3)==0){ threshold=atoi(a+3); if(threshold<1) threshold=1; }
        else if(a[0]=='-'){ fprintf(stderr,"flag provided but not defined: %s\n%s",a,usage); return 2; }
        else strvec_push(&paths,a);
    }
    if(opt_files){ char *line=NULL; size_t cap=0; ssize_t n; while((n=getline(&line,&cap,stdin))!=-1){ while(n>0 && (line[n-1]=='\n'||line[n-1]=='\r')) line[--n]=0; if(n>0) strvec_push(&paths,line); } free(line); }
    if(paths.n==0) strvec_push(&paths,".");
    StrVec files_to_read={0}; for(int i=0;i<paths.n;i++) add_input_path(&files_to_read,paths.v[i].s,true);
    FileVec files={0};
    for(int i=0;i<files_to_read.n;i++){ long len=0; char *src=read_file(files_to_read.v[i].s,&len); if(!src) continue; File f={0}; f.path=xstrdup(files_to_read.v[i].s); f.src=src; f.len=len; add_line_starts(&f); tokenize(&f); file_push(&files,f); }
    vlogmsg("Building suffix tree");
    SegVec segs={0}; build_segments(&files,&segs);
    vlogmsg("Searching for clones");
    output_groups(&files,&segs);
    return 0;
}
