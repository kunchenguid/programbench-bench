#define _GNU_SOURCE
#include <arpa/inet.h>
#include <ctype.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct { char *s; size_t n, cap; } Str;
typedef struct { char *url, *error; int status; } Link;
typedef struct { char *url; Link *links; size_t n, cap; bool html; char *body; } Page;
typedef struct { char *scheme, *host, *path; int port; } Url;

static Page *pages; static size_t page_n, page_cap;
static char **queue, **visited; static size_t qn, qpos, qcap, vn, vcap;
static int verbose_flag, one_page, ignore_fragments, max_redir = 64, timeout_sec = 10;
static char format_name[16] = "text";
static bool accepted[600];

static void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap);
    fputc('\n', stderr); exit(1);
}
static char *xstrdup(const char *s){ char *r=strdup(s?s:""); if(!r) exit(2); return r; }
static char *xstrndup(const char *s,size_t n){ char *r=malloc(n+1); if(!r) exit(2); memcpy(r,s,n); r[n]=0; return r; }
static void str_add(Str *b, const char *s, size_t n){ if(b->n+n+1>b->cap){ b->cap=(b->n+n+1)*2+64; b->s=realloc(b->s,b->cap); if(!b->s) exit(2);} memcpy(b->s+b->n,s,n); b->n+=n; b->s[b->n]=0; }
static void str_printf(Str *b, const char *fmt, ...){ char tmp[4096]; va_list ap; va_start(ap,fmt); int n=vsnprintf(tmp,sizeof tmp,fmt,ap); va_end(ap); if(n>0){ if((size_t)n<sizeof tmp) str_add(b,tmp,n); else { char *p=malloc(n+1); va_start(ap,fmt); vsnprintf(p,n+1,fmt,ap); va_end(ap); str_add(b,p,n); free(p);} } }

static int ci_eqn(const char *a,const char *b,size_t n){ for(size_t i=0;i<n;i++) if(tolower((unsigned char)a[i])!=tolower((unsigned char)b[i])) return 0; return 1; }
static char *lower_dup(const char *s){ char *r=xstrdup(s); for(char *p=r;*p;p++) *p=tolower((unsigned char)*p); return r; }
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1])) *--e=0; return s; }

static bool parse_url(const char *u, Url *out) {
    memset(out,0,sizeof *out);
    const char *p=strstr(u,"://"); if(!p) return false;
    out->scheme=xstrndup(u,p-u); char *ls=lower_dup(out->scheme); free(out->scheme); out->scheme=ls;
    p+=3; const char *h=p; while(*p && *p!='/' && *p!='#') p++;
    const char *hend=p, *colon=NULL; for(const char *x=h;x<hend;x++) if(*x==':') colon=x;
    if(colon){ out->host=xstrndup(h,colon-h); out->port=atoi(colon+1); } else { out->host=xstrndup(h,hend-h); out->port=!strcmp(out->scheme,"https")?443:80; }
    if(!*p) out->path=xstrdup("/");
    else out->path=xstrdup(p);
    if(out->port<=0) out->port=80;
    return out->host[0] != 0;
}
static void free_url(Url *u){ free(u->scheme); free(u->host); free(u->path); }
static char *url_no_frag(const char *u){ const char *p=strchr(u,'#'); return p?xstrndup(u,p-u):xstrdup(u); }
static char *frag_part(const char *u){ const char *p=strchr(u,'#'); return p?xstrdup(p+1):NULL; }
static char *origin_of(const char *u){ Url x; if(!parse_url(u,&x)) return xstrdup(""); Str b={0}; if((!strcmp(x.scheme,"http")&&x.port==80)||(!strcmp(x.scheme,"https")&&x.port==443)) str_printf(&b,"%s://%s",x.scheme,x.host); else str_printf(&b,"%s://%s:%d",x.scheme,x.host,x.port); free_url(&x); return b.s; }
static char *dir_of_path(const char *path){ const char *q=strchr(path,'?'); size_t n=q?(size_t)(q-path):strlen(path); char *r=xstrndup(path,n); char *s=strrchr(r,'/'); if(s) s[1]=0; else strcpy(r,"/"); return r; }

static char *normalize_path(const char *p) {
    char *work=xstrdup(p), *frag=NULL, *query=NULL;
    frag=strchr(work,'#'); if(frag){ *frag++=0; frag=xstrdup(frag); }
    query=strchr(work,'?'); if(query){ *query++=0; query=xstrdup(query); }
    char **seg=calloc(strlen(work)+2,sizeof(char*)); size_t sn=0;
    for(char *tok=strtok(work,"/"); tok; tok=strtok(NULL,"/")){
        if(!strcmp(tok,".")||!*tok) continue;
        if(!strcmp(tok,"..")){ if(sn) sn--; } else seg[sn++]=tok;
    }
    Str b={0}; str_add(&b,"/",1); for(size_t i=0;i<sn;i++){ if(i) str_add(&b,"/",1); str_add(&b,seg[i],strlen(seg[i])); }
    if(p[strlen(p)-1]=='/' && (b.n==0 || b.s[b.n-1]!='/')) str_add(&b,"/",1);
    if(query){ str_add(&b,"?",1); str_add(&b,query,strlen(query)); free(query); }
    if(frag){ str_add(&b,"#",1); str_add(&b,frag,strlen(frag)); free(frag); }
    free(seg); free(work); return b.s;
}
static char *resolve_url(const char *base, const char *ref) {
    if(!ref || !*ref) return NULL;
    if(!strncmp(ref,"mailto:",7)||!strncmp(ref,"tel:",4)||!strncmp(ref,"javascript:",11)||!strncmp(ref,"data:",5)) return NULL;
    if(strstr(ref,"://")) return xstrdup(ref);
    Url b; if(!parse_url(base,&b)) return NULL; Str out={0};
    if(!strncmp(ref,"//",2)) str_printf(&out,"%s:%s",b.scheme,ref);
    else {
        char *path;
        if(ref[0]=='/') path=normalize_path(ref);
        else if(ref[0]=='#') { char *nf=url_no_frag(b.path); Str t={0}; str_add(&t,nf,strlen(nf)); str_add(&t,ref,strlen(ref)); path=normalize_path(t.s); free(t.s); free(nf); }
        else { char *d=dir_of_path(b.path); Str t={0}; str_add(&t,d,strlen(d)); str_add(&t,ref,strlen(ref)); path=normalize_path(t.s); free(t.s); free(d); }
        if((!strcmp(b.scheme,"http")&&b.port==80)||(!strcmp(b.scheme,"https")&&b.port==443)) str_printf(&out,"%s://%s%s",b.scheme,b.host,path);
        else str_printf(&out,"%s://%s:%d%s",b.scheme,b.host,b.port,path);
        free(path);
    }
    free_url(&b); return out.s;
}

static bool in_list(char **a,size_t n,const char *s){ for(size_t i=0;i<n;i++) if(!strcmp(a[i],s)) return true; return false; }
static void enqueue(const char *u){ char *nf=url_no_frag(u); if(!in_list(visited,vn,nf)&&!in_list(queue+qpos, qn-qpos, nf)){ if(qn==qcap){qcap=qcap?2*qcap:32;queue=realloc(queue,qcap*sizeof*queue);} queue[qn++]=nf; } else free(nf); }
static Page *add_page(const char *u){ if(page_n==page_cap){page_cap=page_cap?2*page_cap:32;pages=realloc(pages,page_cap*sizeof*pages);} Page *p=&pages[page_n++]; memset(p,0,sizeof*p); p->url=xstrdup(u); return p; }
static void add_link(Page *p,const char *u,const char *err,int st){ if(p->n==p->cap){p->cap=p->cap?2*p->cap:8;p->links=realloc(p->links,p->cap*sizeof*p->links);} p->links[p->n].url=xstrdup(u); p->links[p->n].error=err?xstrdup(err):NULL; p->links[p->n].status=st; p->n++; }

typedef struct { int status; char *ctype; char *body; char *err; } Resp;
static Resp http_get(const char *url) {
    Resp r={0}; Url u; if(!parse_url(url,&u)){ r.err=xstrdup("unsupported protocol scheme"); return r; }
    if(strcmp(u.scheme,"http")){ r.err=xstrdup("unsupported protocol scheme"); free_url(&u); return r; }
    char port[16]; snprintf(port,sizeof port,"%d",u.port);
    struct addrinfo hints={0}, *res=NULL; hints.ai_socktype=SOCK_STREAM; hints.ai_family=AF_UNSPEC;
    if(getaddrinfo(u.host,port,&hints,&res)){ Str e={0}; str_printf(&e,"error when dialing %s:%d: lookup failed",u.host,u.port); r.err=e.s; free_url(&u); return r; }
    int fd=-1; for(struct addrinfo *ai=res; ai; ai=ai->ai_next){ fd=socket(ai->ai_family,ai->ai_socktype,ai->ai_protocol); if(fd<0) continue; struct timeval tv={timeout_sec,0}; setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&tv,sizeof tv); setsockopt(fd,SOL_SOCKET,SO_SNDTIMEO,&tv,sizeof tv); if(connect(fd,ai->ai_addr,ai->ai_addrlen)==0) break; close(fd); fd=-1; }
    freeaddrinfo(res); if(fd<0){ Str e={0}; str_printf(&e,"error when dialing %s:%d: connect: connection refused",u.host,u.port); r.err=e.s; free_url(&u); return r; }
    char *path=url_no_frag(u.path); Str req={0}; str_printf(&req,"GET %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: muffet/2.11.1\r\nConnection: close\r\n\r\n",path,u.host); free(path);
    send(fd,req.s,req.n,0); free(req.s); Str raw={0}; char buf[8192]; ssize_t n; while((n=recv(fd,buf,sizeof buf,0))>0) str_add(&raw,buf,n); close(fd);
    if(!raw.s){ r.err=xstrdup("empty response"); free_url(&u); return r; }
    char *head_end=strstr(raw.s,"\r\n\r\n"); size_t hlen=head_end?(size_t)(head_end-raw.s):raw.n; char *head=xstrndup(raw.s,hlen);
    sscanf(head,"HTTP/%*s %d",&r.status);
    char *ct=strcasestr(head,"Content-Type:"); if(ct){ ct+=13; char *e=strchr(ct,'\n'); r.ctype=xstrndup(trim(ct), e?(size_t)(e-ct):strlen(ct)); char *cr=strchr(r.ctype,'\r'); if(cr)*cr=0; } else r.ctype=xstrdup("");
    r.body=xstrdup(head_end?head_end+4:""); free(head); free(raw.s); free_url(&u); return r;
}

static bool has_fragment(const char *body,const char *frag){
    if(!frag || !*frag) return true;
    Str a={0}, b={0}, c={0}, d={0}, e={0}, f={0};
    str_printf(&a,"id=\"%s\"",frag); str_printf(&b,"name=\"%s\"",frag);
    str_printf(&c,"id='%s'",frag); str_printf(&d,"name='%s'",frag);
    str_printf(&e,"id=%s",frag); str_printf(&f,"name=%s",frag);
    bool ok=strstr(body,a.s)||strstr(body,b.s)||strstr(body,c.s)||strstr(body,d.s)||strstr(body,e.s)||strstr(body,f.s);
    free(a.s); free(b.s); free(c.s); free(d.s); free(e.s); free(f.s); return ok;
}
static void scan_links(Page *p, const char *root_origin) {
    (void)root_origin;
    const char *attrs[]={"href","src","action"}; char *html=p->body;
    for(char *s=html; *s; s++) {
        for(size_t ai=0; ai<3; ai++) {
            size_t al=strlen(attrs[ai]); if((s==html||!isalnum((unsigned char)s[-1])) && ci_eqn(s,attrs[ai],al)) {
                char *q=s+al; while(isspace((unsigned char)*q))q++; if(*q!='=') continue; q++; while(isspace((unsigned char)*q))q++;
                char quote=0; if(*q=='\''||*q=='"') quote=*q++;
                char *start=q; while(*q && ((quote && *q!=quote) || (!quote && !isspace((unsigned char)*q) && *q!='>'))) q++;
                if(q>start){ char *ref=xstrndup(start,q-start); char *abs=resolve_url(p->url,ref); free(ref); if(abs){ add_link(p,abs,NULL,0); free(abs); } }
            }
        }
    }
}
static bool same_or_index(const char *a, const char *b){
    if(!strcmp(a,b)) return true;
    Url ua, ub; if(!parse_url(a,&ua)||!parse_url(b,&ub)) return false;
    bool ok=false;
    if(!strcmp(ua.scheme,ub.scheme)&&!strcmp(ua.host,ub.host)&&ua.port==ub.port){
        char *pa=url_no_frag(ua.path), *pb=url_no_frag(ub.path);
        Str ai={0}, bi={0};
        if(pa[strlen(pa)-1]=='/') str_printf(&ai,"%sindex.html",pa); else str_printf(&ai,"%s",pa);
        if(pb[strlen(pb)-1]=='/') str_printf(&bi,"%sindex.html",pb); else str_printf(&bi,"%s",pb);
        ok=!strcmp(pa,pb)||!strcmp(ai.s,pb)||!strcmp(bi.s,pa)||!strcmp(ai.s,bi.s);
        free(pa); free(pb); free(ai.s); free(bi.s);
    }
    free_url(&ua); free_url(&ub); return ok;
}
static bool seen_page_equiv(const char *u){
    char *nf=url_no_frag(u);
    for(size_t i=0;i<vn;i++) if(same_or_index(visited[i],nf)){ free(nf); return true; }
    for(size_t i=qpos;i<qn;i++) if(same_or_index(queue[i],nf)){ free(nf); return true; }
    free(nf); return false;
}
static Page *find_page_equiv(const char *u){
    char *nf=url_no_frag(u);
    for(size_t i=0;i<page_n;i++) if(same_or_index(pages[i].url,nf)){ free(nf); return &pages[i]; }
    free(nf); return NULL;
}

static char *json_escape(const char *s){ Str b={0}; for(;*s;s++){ if(*s=='"'||*s=='\\'){str_add(&b,"\\",1);str_add(&b,s,1);} else if(*s=='\n') str_add(&b,"\\n",2); else str_add(&b,s,1);} return b.s?b.s:xstrdup(""); }
static void xml_print_esc(const char *s){ for(;*s;s++){ if(*s=='&') printf("&amp;"); else if(*s=='<') printf("&lt;"); else if(*s=='>') printf("&gt;"); else if(*s=='\"') printf("&quot;"); else putchar(*s); } }

static int failures(void){ int f=0; for(size_t i=0;i<page_n;i++) for(size_t j=0;j<pages[i].n;j++) if(pages[i].links[j].error) f++; return f; }
static void output_text(void){ for(size_t i=0;i<page_n;i++){ bool show=verbose_flag; for(size_t j=0;j<pages[i].n;j++) if(pages[i].links[j].error) show=true; if(!show) continue; printf("%s\n",pages[i].url); for(size_t j=0;j<pages[i].n;j++){ Link *l=&pages[i].links[j]; if(verbose_flag||l->error) printf("\t%s\t%s\n", l->error?l->error:"200", l->url); } } }
static void output_json(void){ printf("["); bool firstp=true; for(size_t i=0;i<page_n;i++){ bool show=verbose_flag; for(size_t j=0;j<pages[i].n;j++) if(pages[i].links[j].error) show=true; if(!show) continue; if(!firstp) printf(","); firstp=false; char *u=json_escape(pages[i].url); printf("{\"url\":\"%s\",\"links\":[",u); free(u); bool fl=true; for(size_t j=0;j<pages[i].n;j++){ Link *l=&pages[i].links[j]; if(!verbose_flag&&!l->error) continue; if(!fl) printf(","); fl=false; char *lu=json_escape(l->url); printf("{\"url\":\"%s\"",lu); free(lu); if(l->error){ char *e=json_escape(l->error); printf(",\"error\":\"%s\"",e); free(e); } printf("}"); } printf("]}"); } printf("]\n"); }
static void output_junit(void){ printf("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<testsuites>\n"); for(size_t i=0;i<page_n;i++){ int fail=0; for(size_t j=0;j<pages[i].n;j++) if(pages[i].links[j].error) fail++; printf("  <testsuite name=\""); xml_print_esc(pages[i].url); printf("\" tests=\"%zu\" failures=\"%d\" skipped=\"0\">",pages[i].n,fail); if(pages[i].n) putchar('\n'); for(size_t j=0;j<pages[i].n;j++){ Link *l=&pages[i].links[j]; printf("    <testcase name=\""); xml_print_esc(l->url); printf("\" classname=\""); xml_print_esc(pages[i].url); printf("\""); if(l->error){ printf(">\n      <failure message=\""); xml_print_esc(l->error); printf("\"></failure>\n    </testcase>\n"); } else printf("></testcase>\n"); } if(pages[i].n) printf("  </testsuite>\n"); else printf("</testsuite>\n"); } printf("</testsuites>\n"); }

static void usage(void){ puts("Usage:\n  executable [options] <url>\n\nApplication Options:\n      --accepted-status-codes=<codes>       Accepted HTTP response status codes\n                                            (e.g. '200..300,403') (default:\n                                            200..300)\n  -b, --buffer-size=<size>                  HTTP response buffer size in bytes\n                                            (default: 4096)\n  -c, --max-connections=<count>             Maximum number of HTTP connections\n                                            (default: 512)\n      --max-connections-per-host=<count>    Maximum number of HTTP connections\n                                            per host (default: 512)\n      --max-response-body-size=<size>       Maximum response body size to read\n                                            (default: 10000000)\n  -e, --exclude=<pattern>...                Exclude URLs matched with given\n                                            regular expressions\n  -i, --include=<pattern>...                Include URLs matched with given\n                                            regular expressions\n      --follow-robots-txt                   Follow robots.txt when scraping\n                                            pages\n      --follow-sitemap-xml                  Scrape only pages listed in\n                                            sitemap.xml (deprecated)\n      --header=<header>...                  Custom headers\n  -f, --ignore-fragments                    Ignore URL fragments\n      --max-retries=<count>                 Maximum retry count for network\n                                            errors (default: 0)\n      --dns-resolver=<address>              Custom DNS resolver\n      --format=[text|json|junit]            Output format (default: text)\n      --json                                Output results in JSON (deprecated)\n      --experimental-verbose-json           Include successful results in JSON\n                                            (deprecated)\n      --junit                               Output results as JUnit XML file\n                                            (deprecated)\n  -r, --max-redirections=<count>            Maximum number of redirections\n                                            (default: 64)\n      --rate-limit=<rate>                   Max requests per second\n  -t, --timeout=<seconds>                   Timeout for HTTP requests in\n                                            seconds (default: 10)\n  -v, --verbose                             Show successful results too\n      --proxy=<host>                        HTTP proxy host\n      --skip-tls-verification               Skip TLS certificate verification\n      --one-page-only                       Only check links found in the given\n                                            URL\n      --color=[auto|always|never]           Color output (default: auto)\n  -h, --help                                Show this help\n      --version                             Show version"); }
static void set_accepted(const char *s){ memset(accepted,0,sizeof accepted); char *w=xstrdup(s); for(char *tok=strtok(w,","); tok; tok=strtok(NULL,",")){ int a,b; if(sscanf(tok,"%d..%d",&a,&b)==2){ if(a<0)a=0; if(b>599)b=599; for(int i=a;i<b;i++) accepted[i]=true; } else { a=atoi(tok); if(a>=0&&a<600) accepted[a]=true; } } free(w); }

int main(int argc,char **argv){
    for(int i=200;i<300;i++) accepted[i]=true;
    char *root=NULL;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--help")||!strcmp(a,"-h")){ usage(); return 0; }
        else if(!strcmp(a,"--version")){ puts("2.11.1"); return 0; }
        else if(!strcmp(a,"-v")||!strcmp(a,"--verbose")) verbose_flag=1;
        else if(!strcmp(a,"-f")||!strcmp(a,"--ignore-fragments")) ignore_fragments=1;
        else if(!strcmp(a,"--one-page-only")) one_page=1;
        else if(!strcmp(a,"--json")) strcpy(format_name,"json");
        else if(!strcmp(a,"--junit")) strcpy(format_name,"junit");
        else if(!strncmp(a,"--format=",9)){ strncpy(format_name,a+9,sizeof(format_name)-1); }
        else if(!strcmp(a,"--format") && i+1<argc){ strncpy(format_name,argv[++i],sizeof(format_name)-1); }
        else if(!strncmp(a,"--accepted-status-codes=",24)) set_accepted(a+24);
        else if(!strcmp(a,"--accepted-status-codes") && i+1<argc) set_accepted(argv[++i]);
        else if((!strcmp(a,"-t")||!strcmp(a,"--timeout")) && i+1<argc) timeout_sec=atoi(argv[++i]);
        else if(!strncmp(a,"--timeout=",10)) timeout_sec=atoi(a+10);
        else if((!strcmp(a,"-r")||!strcmp(a,"--max-redirections")) && i+1<argc) max_redir=atoi(argv[++i]);
        else if(!strncmp(a,"--max-redirections=",19)) max_redir=atoi(a+19);
        else if(a[0]=='-' && strcmp(a,"-")) { if(strlen(a)>2 && a[0]=='-' && a[1]!='-') { for(char *p=a+1;*p;p++){ if(*p=='v') verbose_flag=1; else if(*p=='f') ignore_fragments=1; else die("unknown flag `%c'",*p); } } else { char *n=a+2; char *eq=strchr(n,'='); if(eq)*eq=0; die("unknown flag `%s'",n); } }
        else { if(root) die("invalid number of arguments"); root=a; }
    }
    if(!root) die("invalid number of arguments");
    if(strcmp(format_name,"text")&&strcmp(format_name,"json")&&strcmp(format_name,"junit")) die("invalid format: %s",format_name);
    char *root_abs=resolve_url("http://dummy/",root); if(!root_abs) root_abs=xstrdup(root);
    char *root_origin=origin_of(root_abs); enqueue(root_abs);
    while(qpos<qn){
        char *u=queue[qpos++];
        if(vn==vcap){vcap=vcap?2*vcap:32;visited=realloc(visited,vcap*sizeof*visited);}
        visited[vn++]=xstrdup(u);
        Page *p=add_page(u);
        Resp r=http_get(u);
        if(r.err){ if(page_n==1) die("failed to fetch root page: %s",r.err); add_link(p,u,r.err,0); free(r.err); continue; }
        p->body=r.body;
        char ebuf[64];
        if(r.status<0||r.status>=600||!accepted[r.status]){ snprintf(ebuf,sizeof ebuf,"%d",r.status); add_link(p,u,ebuf,r.status); }
        char *ct=lower_dup(r.ctype);
        p->html=strstr(ct,"text/html") || strstr(p->body,"<html") || strstr(p->body,"href=");
        free(ct); free(r.ctype);
        if(!p->html) continue;
        scan_links(p,root_origin);
        for(size_t li=0; li<p->n; li++){
            Link *l=&p->links[li];
            if(l->error) continue;
            char *nf=url_no_frag(l->url);
            Resp lr=http_get(nf);
            if(lr.err){ l->error=lr.err; free(nf); continue; }
            l->status=lr.status;
            if(lr.status<0||lr.status>=600||!accepted[lr.status]){
                char tmp[64]; snprintf(tmp,sizeof tmp,"%d",lr.status); l->error=xstrdup(tmp);
            }
            char *lct=lower_dup(lr.ctype);
            bool lhtml=strstr(lct,"text/html") || strstr(lr.body,"<html") || strstr(lr.body,"href=");
            char *org=origin_of(nf);
            if(!l->error && lhtml && !one_page && !strcmp(org,root_origin) && !seen_page_equiv(nf)) enqueue(nf);
            free(org); free(lct); free(lr.ctype); free(lr.body); free(nf);
        }
    }
    if(!ignore_fragments){ for(size_t i=0;i<page_n;i++) for(size_t j=0;j<pages[i].n;j++){ Link *l=&pages[i].links[j]; if(l->error) continue; char *fr=frag_part(l->url); if(fr && *fr){ Page *target=find_page_equiv(l->url); if(target && target->body && !has_fragment(target->body,fr)){ Str e={0}; str_printf(&e,"id #%s not found",fr); l->error=e.s; } } free(fr); } }
    int f=failures(); if(!strcmp(format_name,"json")) output_json(); else if(!strcmp(format_name,"junit")) output_junit(); else output_text();
    free(root_abs); free(root_origin); return f?1:0;
}
