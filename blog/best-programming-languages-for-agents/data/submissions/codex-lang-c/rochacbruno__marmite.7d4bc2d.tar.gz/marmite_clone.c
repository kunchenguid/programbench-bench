#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

typedef struct { char *s; size_t n, cap; } Str;
typedef struct {
    char *path, *rel, *title, *slug, *date, *html, *text, *stream;
    char **tags; int ntags;
    char **authors; int nauthors;
    bool page;
} Item;
typedef struct {
    char *name, *tagline, *url, *footer, *language, *content_path;
    int pagination;
    bool enable_search, json_feed, toc, publish_md, build_sitemap, publish_urls_json;
} Config;

static char *opt_name=NULL,*opt_tagline=NULL,*opt_url=NULL,*opt_language=NULL,*opt_content_path=NULL;
static int opt_pagination=-1;
static int opt_enable_search=-1,opt_json_feed=-1,opt_toc=-1,opt_publish_md=-1,opt_build_sitemap=-1,opt_publish_urls_json=-1;

static void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap); fputc('\n', stderr); exit(1);
}
static char *xstrdup(const char *s){ char *r=strdup(s?s:""); if(!r) die("oom"); return r; }
static void str_init(Str *b){ b->s=NULL; b->n=0; b->cap=0; }
static void str_reserve(Str *b,size_t add){ if(b->n+add+1>b->cap){ size_t nc=b->cap?b->cap*2:256; while(nc<b->n+add+1) nc*=2; b->s=realloc(b->s,nc); if(!b->s) die("oom"); b->cap=nc; } }
static void str_catn(Str *b,const char *s,size_t n){ str_reserve(b,n); memcpy(b->s+b->n,s,n); b->n+=n; b->s[b->n]=0; }
static void str_cat(Str *b,const char *s){ str_catn(b,s,strlen(s)); }
static void str_printf(Str *b,const char *fmt,...){ va_list ap; va_start(ap,fmt); char *tmp=NULL; int n=vasprintf(&tmp,fmt,ap); va_end(ap); if(n<0) die("oom"); str_catn(b,tmp,(size_t)n); free(tmp); }
static char *str_take(Str *b){ if(!b->s) return xstrdup(""); char *s=b->s; b->s=NULL; b->n=b->cap=0; return s; }

static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s && isspace((unsigned char)e[-1])) *--e=0; return s; }
static bool starts(const char *s,const char *p){ return strncmp(s,p,strlen(p))==0; }
static bool ends(const char *s,const char *p){ size_t a=strlen(s),b=strlen(p); return a>=b && strcmp(s+a-b,p)==0; }
static bool exists_dir(const char *p){ struct stat st; return stat(p,&st)==0 && S_ISDIR(st.st_mode); }
static bool exists_file(const char *p){ struct stat st; return stat(p,&st)==0 && S_ISREG(st.st_mode); }
static void mkdir_p(const char *path){ char tmp[PATH_MAX]; snprintf(tmp,sizeof tmp,"%s",path); for(char *p=tmp+1;*p;p++){ if(*p=='/'){ *p=0; mkdir(tmp,0777); *p='/'; } } mkdir(tmp,0777); }
static void parent_mkdir(const char *path){ char tmp[PATH_MAX]; snprintf(tmp,sizeof tmp,"%s",path); char *p=strrchr(tmp,'/'); if(p){ *p=0; mkdir_p(tmp); } }
static char *path_join(const char *a,const char *b){ char *r; if(!a||!*a) asprintf(&r,"%s",b); else asprintf(&r,"%s/%s",a,b); if(!r) die("oom"); return r; }
static char *read_file(const char *p){ FILE *f=fopen(p,"rb"); if(!f) return NULL; fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET); char *s=malloc((size_t)n+1); if(!s) die("oom"); fread(s,1,(size_t)n,f); s[n]=0; fclose(f); return s; }
static void write_file(const char *p,const char *s){ parent_mkdir(p); FILE *f=fopen(p,"wb"); if(!f) die("cannot write %s: %s",p,strerror(errno)); fwrite(s,1,strlen(s),f); fclose(f); }
static void copy_file(const char *src,const char *dst){ char *s=read_file(src); if(s){ write_file(dst,s); free(s); } }

static char *slugify(const char *in){
    Str b; str_init(&b); bool dash=false;
    for(const unsigned char *p=(const unsigned char*)in; *p; p++){
        if(isalnum(*p)){ char c=(char)tolower(*p); str_catn(&b,&c,1); dash=false; }
        else if(!dash && b.n){ str_cat(&b,"-"); dash=true; }
    }
    while(b.n && b.s[b.n-1]=='-') b.s[--b.n]=0;
    if(!b.n) str_cat(&b,"untitled");
    return str_take(&b);
}
static char *html_escape(const char *in){
    Str b; str_init(&b);
    for(const char *p=in; *p; p++){
        if(*p=='&') str_cat(&b,"&amp;"); else if(*p=='<') str_cat(&b,"&lt;");
        else if(*p=='>') str_cat(&b,"&gt;"); else if(*p=='\"') str_cat(&b,"&quot;");
        else str_catn(&b,p,1);
    }
    return str_take(&b);
}
static char *json_escape(const char *in){
    Str b; str_init(&b);
    for(const char *p=in; *p; p++){ if(*p=='\\'||*p=='"') { str_cat(&b,"\\"); str_catn(&b,p,1); } else if(*p=='\n') str_cat(&b,"\\n"); else if((unsigned char)*p>=32) str_catn(&b,p,1); }
    return str_take(&b);
}
static void inline_md(Str *out,const char *s){
    for(size_t i=0;s[i];){
        if(s[i]=='`'){ size_t j=i+1; while(s[j]&&s[j]!='`') j++; if(s[j]){ char *t=strndup(s+i+1,j-i-1),*e=html_escape(t); str_printf(out,"<code>%s</code>",e); free(t); free(e); i=j+1; continue; } }
        if(s[i]=='*'&&s[i+1]=='*'){ size_t j=i+2; while(s[j]&&!(s[j]=='*'&&s[j+1]=='*')) j++; if(s[j]){ char *t=strndup(s+i+2,j-i-2); str_cat(out,"<strong>"); inline_md(out,t); str_cat(out,"</strong>"); free(t); i=j+2; continue; } }
        if(s[i]=='*'){ size_t j=i+1; while(s[j]&&s[j]!='*') j++; if(s[j]){ char *t=strndup(s+i+1,j-i-1); str_cat(out,"<em>"); inline_md(out,t); str_cat(out,"</em>"); free(t); i=j+1; continue; } }
        if(s[i]=='['){ char *mid=strchr(s+i,']'); if(mid&&mid[1]=='('){ char *end=strchr(mid+2,')'); if(end){ char *txt=strndup(s+i+1,mid-s-i-1),*url=strndup(mid+2,end-mid-2),*eu=html_escape(url); str_printf(out,"<a href=\"%s\">",eu); inline_md(out,txt); str_cat(out,"</a>"); free(txt); free(url); free(eu); i=(end-s)+1; continue; } } }
        char ch=s[i++]; if(ch=='&') str_cat(out,"&amp;"); else if(ch=='<') str_cat(out,"&lt;"); else if(ch=='>') str_cat(out,"&gt;"); else str_catn(out,&ch,1);
    }
}
static char *format_inline(const char *s){ Str b; str_init(&b); inline_md(&b,s); return str_take(&b); }

static void add_text(Str *txt,const char *s){ for(const char *p=s;*p;p++){ if(!strchr("#>*`[]()_-",*p)) str_catn(txt,p,1); } str_cat(txt," "); }
static char *markdown_to_html(const char *md, bool toc, char **toc_html, char **plain){
    Str out, tocb, txt; str_init(&out); str_init(&tocb); str_init(&txt); if(toc) str_cat(&tocb,"<ul>\n");
    char *copy=xstrdup(md), *save=NULL, *line=strtok_r(copy,"\n",&save); bool in_ul=false,in_ol=false,in_pre=false,in_bq=false;
    while(line){
        char *raw=line; char *t=trim(raw);
        if(starts(t,"```")){ if(!in_pre){ char *lang=trim(t+3); char *e=html_escape(lang); str_printf(&out,"<pre><code%s%s%s>",*e?" class=\"language-":"",e,*e?"\"":""); free(e); in_pre=true; } else { str_cat(&out,"</code></pre>\n"); in_pre=false; } line=strtok_r(NULL,"\n",&save); continue; }
        if(in_pre){ char *e=html_escape(raw); str_cat(&out,e); str_cat(&out,"\n"); add_text(&txt,raw); free(e); line=strtok_r(NULL,"\n",&save); continue; }
        if(!*t){ if(in_ul){str_cat(&out,"</ul>\n");in_ul=false;} if(in_ol){str_cat(&out,"</ol>\n");in_ol=false;} if(in_bq){str_cat(&out,"</blockquote>\n");in_bq=false;} line=strtok_r(NULL,"\n",&save); continue; }
        if(starts(t,"#")){
            if(in_ul){str_cat(&out,"</ul>\n");in_ul=false;} if(in_ol){str_cat(&out,"</ol>\n");in_ol=false;} if(in_bq){str_cat(&out,"</blockquote>\n");in_bq=false;}
            int lvl=0; while(t[lvl]=='#') lvl++; if(lvl>6) lvl=6; char *h=trim(t+lvl); char *id=slugify(h); char *ih=format_inline(h);
            str_printf(&out,"<h%d><a href=\"#%s\" aria-hidden=\"true\" class=\"anchor\" id=\"%s\"></a>%s</h%d>\n",lvl,id,id,ih,lvl);
            if(toc) str_printf(&tocb,"<li><a href=\"#%s\">%s</a></li>\n",id,ih);
            add_text(&txt,h); free(id); free(ih);
        } else if(starts(t,"- ")||starts(t,"* ")){
            if(!in_ul){ if(in_ol){str_cat(&out,"</ol>\n");in_ol=false;} str_cat(&out,"<ul>\n"); in_ul=true; }
            char *ih=format_inline(trim(t+2)); str_printf(&out,"<li>%s</li>\n",ih); add_text(&txt,t+2); free(ih);
        } else if(isdigit((unsigned char)t[0]) && strstr(t,". ")){
            char *p=strstr(t,". "); if(!in_ol){ if(in_ul){str_cat(&out,"</ul>\n");in_ul=false;} str_cat(&out,"<ol>\n"); in_ol=true; }
            char *ih=format_inline(trim(p+2)); str_printf(&out,"<li>%s</li>\n",ih); add_text(&txt,p+2); free(ih);
        } else if(starts(t,">")){
            if(!in_bq){ str_cat(&out,"<blockquote>\n"); in_bq=true; }
            char *ih=format_inline(trim(t+1)); str_printf(&out,"<p>%s</p>\n",ih); add_text(&txt,t+1); free(ih);
        } else {
            if(in_ul){str_cat(&out,"</ul>\n");in_ul=false;} if(in_ol){str_cat(&out,"</ol>\n");in_ol=false;} if(in_bq){str_cat(&out,"</blockquote>\n");in_bq=false;}
            char *ih=format_inline(t); str_printf(&out,"<p>%s</p>\n",ih); add_text(&txt,t); free(ih);
        }
        line=strtok_r(NULL,"\n",&save);
    }
    if(in_ul) str_cat(&out,"</ul>\n"); if(in_ol) str_cat(&out,"</ol>\n"); if(in_bq) str_cat(&out,"</blockquote>\n"); if(in_pre) str_cat(&out,"</code></pre>\n");
    if(toc) str_cat(&tocb,"</ul>\n"); *toc_html=str_take(&tocb); *plain=str_take(&txt); free(copy); return str_take(&out);
}

static const char *default_footer="<div>Powered by <a href=\"https://github.com/rochacbruno/marmite\">Marmite</a> | <small><a href=\"https://creativecommons.org/licenses/by-nc-sa/4.0/\">CC-BY_NC-SA</a></small></div>";
static void cfg_default(Config *c){ memset(c,0,sizeof *c); c->name=xstrdup("Home"); c->tagline=xstrdup(""); c->url=xstrdup(""); c->footer=xstrdup(default_footer); c->language=xstrdup("en"); c->content_path=xstrdup("content"); c->pagination=10; c->build_sitemap=true; c->publish_urls_json=true; }
static const char *config_text =
"name: Home\n"
"tagline: ''\n"
"url: ''\n"
"https: null\n"
"footer: <div>Powered by <a href=\"https://github.com/rochacbruno/marmite\">Marmite</a> | <small><a href=\"https://creativecommons.org/licenses/by-nc-sa/4.0/\">CC-BY_NC-SA</a></small></div>\n"
"language: ''\n"
"pagination: 10\n"
"pages_title: Pages\n"
"tags_title: Tags\n"
"tags_content_title: Posts tagged with '$tag'\n"
"archives_title: Archive\n"
"archives_content_title: Posts from '$year'\n"
"streams_title: Streams\n"
"streams_content_title: Posts from '$stream'\n"
"series_title: Series\n"
"series_content_title: Posts from '$series' series\n"
"default_author: ''\n"
"authors_title: Authors\n"
"enable_search: false\n"
"enable_related_content: false\n"
"search_title: ''\n"
"content_path: content\n"
"site_path: ''\n"
"templates_path: templates\n"
"static_path: static\n"
"media_path: media\n"
"card_image: ''\n"
"banner_image: ''\n"
"logo_image: ''\n"
"default_date_format: '%b %e, %Y'\n"
"menu:\n- - Tags\n  - tags.html\n- - Archive\n  - archive.html\n- - Authors\n  - authors.html\n"
"extra: null\nauthors: {}\nstreams: {}\nseries: {}\ntoc: false\njson_feed: false\nshow_next_prev_links: true\npublish_md: false\nsource_repository: null\nimage_provider: null\nmarkdown_parser: null\ntheme: null\nfile_mapping: []\nenable_shortcodes: true\nshortcode_pattern: null\nbuild_sitemap: true\npublish_urls_json: true\ngallery_path: gallery\ngallery_create_thumbnails: true\ngallery_thumb_size: 50\nskip_image_resize: false\n";
static char *unquote(char *v){ v=trim(v); size_t n=strlen(v); if(n>=2 && ((v[0]=='\''&&v[n-1]=='\'')||(v[0]=='"'&&v[n-1]=='"'))){ v[n-1]=0; v++; } return v; }
static void cfg_set(Config *c,const char *k,char *v){
    v=unquote(v);
    if(!strcmp(k,"name")){free(c->name);c->name=xstrdup(v);} else if(!strcmp(k,"tagline")){free(c->tagline);c->tagline=xstrdup(v);}
    else if(!strcmp(k,"url")){free(c->url);c->url=xstrdup(v);} else if(!strcmp(k,"footer")){free(c->footer);c->footer=xstrdup(v);}
    else if(!strcmp(k,"language")){free(c->language);c->language=xstrdup(*v?v:"en");} else if(!strcmp(k,"content_path")){free(c->content_path);c->content_path=xstrdup(v);}
    else if(!strcmp(k,"pagination")) c->pagination=atoi(v); else if(!strcmp(k,"enable_search")) c->enable_search=!strcmp(v,"true");
    else if(!strcmp(k,"json_feed")) c->json_feed=!strcmp(v,"true"); else if(!strcmp(k,"toc")) c->toc=!strcmp(v,"true");
    else if(!strcmp(k,"publish_md")) c->publish_md=!strcmp(v,"true"); else if(!strcmp(k,"build_sitemap")) c->build_sitemap=strcmp(v,"false");
    else if(!strcmp(k,"publish_urls_json")) c->publish_urls_json=strcmp(v,"false");
}
static void read_config(Config *c,const char *input,const char *custom){
    char *p= custom?xstrdup(custom):path_join(input,"marmite.yaml"); char *s=read_file(p); free(p); if(!s) return;
    char *save=NULL,*line=strtok_r(s,"\n",&save); while(line){ char *t=trim(line); char *col=strchr(t,':'); if(col){ *col=0; cfg_set(c,trim(t),col+1); } line=strtok_r(NULL,"\n",&save); } free(s);
}
static void apply_overrides(Config *c){
    if(opt_name){ free(c->name); c->name=xstrdup(opt_name); }
    if(opt_tagline){ free(c->tagline); c->tagline=xstrdup(opt_tagline); }
    if(opt_url){ free(c->url); c->url=xstrdup(opt_url); }
    if(opt_language){ free(c->language); c->language=xstrdup(opt_language); }
    if(opt_content_path){ free(c->content_path); c->content_path=xstrdup(opt_content_path); }
    if(opt_pagination>0) c->pagination=opt_pagination;
    if(opt_enable_search!=-1) c->enable_search=opt_enable_search;
    if(opt_json_feed!=-1) c->json_feed=opt_json_feed;
    if(opt_toc!=-1) c->toc=opt_toc;
    if(opt_publish_md!=-1) c->publish_md=opt_publish_md;
    if(opt_build_sitemap!=-1) c->build_sitemap=opt_build_sitemap;
    if(opt_publish_urls_json!=-1) c->publish_urls_json=opt_publish_urls_json;
}

static void parse_list(char *v,char ***arr,int *n){
    v=unquote(v); if(*v=='['){ v++; char *e=strrchr(v,']'); if(e)*e=0; }
    char *save=NULL,*tok=strtok_r(v,",",&save); while(tok){ tok=unquote(tok); if(*tok){ *arr=realloc(*arr,sizeof(char*)*(*n+1)); (*arr)[(*n)++]=xstrdup(tok); } tok=strtok_r(NULL,",",&save); }
}
static void parse_front(Item *it,char *front){
    char *save=NULL,*line=strtok_r(front,"\n",&save); while(line){ char *t=trim(line),*col=strchr(t,':'); if(col){ *col=0; char *k=trim(t),*v=trim(col+1);
        if(!strcmp(k,"title")) it->title=xstrdup(unquote(v)); else if(!strcmp(k,"date")) it->date=xstrdup(unquote(v));
        else if(!strcmp(k,"tags")) parse_list(v,&it->tags,&it->ntags); else if(!strcmp(k,"authors")||!strcmp(k,"author")) parse_list(v,&it->authors,&it->nauthors);
        else if(!strcmp(k,"page")) it->page=!strcmp(unquote(v),"true"); else if(!strcmp(k,"stream")) it->stream=xstrdup(unquote(v));
    } line=strtok_r(NULL,"\n",&save); }
}
static void collect_md(const char *base,const char *dir,Item **items,int *n,int *cap,Config *cfg){
    DIR *d=opendir(dir); if(!d) return; struct dirent *e;
    while((e=readdir(d))){ if(e->d_name[0]=='.') continue; char *p=path_join(dir,e->d_name); struct stat st; if(stat(p,&st)==0 && S_ISDIR(st.st_mode)) collect_md(base,p,items,n,cap,cfg); else if(ends(e->d_name,".md") && e->d_name[0]!='_'){
            char *s=read_file(p); if(s){ if(*n>=*cap){*cap=*cap?*cap*2:16; *items=realloc(*items,sizeof(Item)*(*cap));} Item *it=&(*items)[(*n)++]; memset(it,0,sizeof *it); it->path=xstrdup(p); it->rel=xstrdup(p+strlen(base)+1);
                char *body=s; if(starts(s,"---\n")){ char *end=strstr(s+4,"\n---"); if(end){ *end=0; parse_front(it,s+4); body=end+4; if(*body=='\n') body++; } }
                if(!it->title){ char *tmp=xstrdup(body),*save=NULL,*ln=strtok_r(tmp,"\n",&save); while(ln){ char *t=trim(ln); if(starts(t,"#")){ int i=0; while(t[i]=='#')i++; it->title=xstrdup(trim(t+i)); break; } ln=strtok_r(NULL,"\n",&save); } free(tmp); }
                if(!it->title){ char *bn=xstrdup(e->d_name); char *dot=strrchr(bn,'.'); if(dot)*dot=0; it->title=slugify(bn); free(bn); }
                if(!it->date){ if(strlen(e->d_name)>=10 && isdigit(e->d_name[0])&&e->d_name[4]=='-'&&e->d_name[7]=='-') it->date=strndup(e->d_name,10); else it->date=xstrdup(""); }
                if(!it->page && !*it->date) it->page=true;
                char *toc=NULL,*plain=NULL; it->html=markdown_to_html(body,cfg->toc,&toc,&plain); it->text=plain; free(toc);
                char *sl=slugify(it->title); if(it->stream&&*it->stream){ char *ss=slugify(it->stream); asprintf(&it->slug,"%s-%s",ss,sl); free(ss); free(sl); } else it->slug=sl;
                free(s);
            }
        } free(p);
    }
    closedir(d);
}
static int cmp_items(const void *a,const void*b){ const Item *x=a,*y=b; int c=strcmp(y->date,x->date); return c?c:strcmp(x->title,y->title); }
static char *base_url(Config *c){ if(!c->url||!*c->url) return xstrdup(""); char *r=xstrdup(c->url); while(strlen(r)>0 && r[strlen(r)-1]=='/') r[strlen(r)-1]=0; return r; }
static char *href(Config *c,const char *file){ char *b=base_url(c); char *r; if(*b) asprintf(&r,"%s/%s",b,file); else asprintf(&r,"/%s",file); free(b); return r; }
static char *date_fmt(const char *d){ if(!d||strlen(d)<10) return xstrdup(""); static const char *mon[]={"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"}; int y,m,da; if(sscanf(d,"%d-%d-%d",&y,&m,&da)==3&&m>=1&&m<=12){ char *r; asprintf(&r,"%s %2d, %04d",mon[m-1],da,y); return r;} return xstrdup(d); }
static char *year_of(const char *d){ return d&&strlen(d)>=4?strndup(d,4):xstrdup(""); }

static void page_wrap(Str *b,Config *c,const char *title,const char *body){
    char *bu=base_url(c); const char *root=*bu?bu:"";
    str_printf(b,"<!DOCTYPE html>\n<html lang=\"%s\">\n<head>\n<meta charset=\"UTF-8\">\n<link rel=\"icon\" type=\"image/x-icon\" href=\"%s/static/favicon.ico\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<meta name=\"color-scheme\" content=\"light dark\" />\n<meta name=\"generator\" content=\"Marmite\" />\n<title>%s | %s</title>\n<link rel=\"stylesheet\" type=\"text/css\" href=\"%s/static/pico.min.css\">\n<link rel=\"stylesheet\" type=\"text/css\" href=\"%s/static/marmite.css\">\n<link rel=\"stylesheet\" type=\"text/css\" href=\"%s/static/custom.css\">\n</head>\n<body>\n<main class=\"container\">\n<header class=\"header-content\"><nav class=\"header-nav\"><ul class=\"header-name\"><li><hgroup class=\"h-card\"><h2><a href=\"%s/\" class=\"contrast p-name u-url\">%s</a></h2>%s%s%s</hgroup></li></ul><button id=\"menu-toggle\" class=\"hamburger\">&#9776;</button><ul class=\"header-menu\" id=\"header-menu\"><li><a class=\"menu-item secondary\" href=\"%s/tags.html\">Tags</a></li><li><a class=\"menu-item secondary\" href=\"%s/archive.html\">Archive</a></li><li><a class=\"menu-item secondary\" href=\"%s/authors.html\">Authors</a></li>%s</ul></nav></header>\n<section class=\"main-content\">\n%s\n</section>\n<footer class=\"footer-content grid\">%s</footer>\n</main><script src=\"%s/static/marmite.js\"></script><script src=\"%s/static/custom.js\"></script>%s</body></html>\n",
        c->language&&*c->language?c->language:"en",root,title,c->name,root,root,root,root,c->name,*c->tagline?"<p class=\"p-note\">":"",c->tagline,*c->tagline?"</p>":"",root,root,root,c->enable_search?"<li><a href=\"#\" id=\"search-toggle\" class=\"secondary\">Search</a></li>":"",body,c->footer,root,root,c->enable_search?"<script type=\"module\" src=\"/static/search.js\"></script>":"");
    free(bu);
}
static void write_content(Config *c,const char *out,Item *it){
    Str body,b; str_init(&body); char *url; asprintf(&url,"%s.html",it->slug); char *h=href(c,url); char *df=date_fmt(it->date);
    str_printf(&body,"<article class=\"h-entry\"><data class=\"p-name\" value=\"%s\"></data><a class=\"u-url\" href=\"%s\" style=\"display: none;\"></a>",it->title,h);
    if(*it->date) str_printf(&body,"<time class=\"dt-published\" datetime=\"%sT00:00:00+00:00\" style=\"display: none;\">%s</time>",it->date,df);
    str_printf(&body,"<div class=\"content-html e-content\">%s</div>",it->html);
    str_cat(&body,"<footer class=\"data-tags-footer\"><div class=\"date-tags-container\"><div class=\"content-date\"><span class=\"content-date\"><small>");
    if(*df) str_printf(&body," %s - &#10710; 1 min",df); str_cat(&body,"</small></span>");
    if(it->stream&&*it->stream){ char *ss=slugify(it->stream); char *sh=href(c,""); free(sh); str_printf(&body,"<div class=\"content-stream\"><small><a href=\"%s.html\">%s</a></small></div>",ss,it->stream); free(ss); }
    str_cat(&body,"</div><ul class=\"content-tags\">"); for(int i=0;i<it->ntags;i++){ char *ts=slugify(it->tags[i]); char *fn; asprintf(&fn,"tag-%s.html",ts); char *th=href(c,fn); str_printf(&body,"<li><a href=\"%s\" class=\"p-category\">%s</a></li>",th,it->tags[i]); free(ts); free(fn); free(th); } str_cat(&body,"</ul></div></footer>");
    if(c->publish_md){ str_printf(&body,"<article><div class=\"content-source\"><a href=\"%s\" rel=\"nofollow\">📄 View source</a></div></article>",it->rel); }
    str_cat(&body,"</article>"); str_init(&b); page_wrap(&b,c,it->title,body.s); char *p; asprintf(&p,"%s/%s",out,url); write_file(p,b.s); free(p); free(url); free(h); free(df); free(body.s); free(b.s);
}
static void write_list_page(Config *c,const char *out,const char *file,const char *title,Item *items,int n,bool want_pages,const char *filter_kind,const char *filter){
    Str body,b; str_init(&body); str_printf(&body,"<div class=\"content-list h-feed\"><h1 class=\"p-name\">%s</h1><div class=\"left\">",title); int count=0;
    for(int i=0;i<n;i++){ Item *it=&items[i]; if(it->page!=want_pages) continue; bool ok=true; if(filter_kind){ ok=false; if(!strcmp(filter_kind,"tag")){ for(int j=0;j<it->ntags;j++) if(!strcmp(it->tags[j],filter)) ok=true; } else if(!strcmp(filter_kind,"author")){ for(int j=0;j<it->nauthors;j++) if(!strcmp(it->authors[j],filter)) ok=true; } else if(!strcmp(filter_kind,"stream")) ok=it->stream&&!strcmp(it->stream,filter); else if(!strcmp(filter_kind,"year")){ char *y=year_of(it->date); ok=!strcmp(y,filter); free(y); } } if(!ok) continue;
        char *fn; asprintf(&fn,"%s.html",it->slug); char *u=href(c,fn); char *df=date_fmt(it->date); str_printf(&body,"<article class=\"content-list-item left h-entry\"><h2 class=\"content-title\"><a class=\"u-url p-name\" href=\"%s\">%s</a></h2><p class=\"content-excerpt\">%s</p><small>%s</small></article>\n",u,it->title,it->text?it->text:"",df); free(fn); free(u); free(df); count++; }
    if(!count) str_cat(&body,"<article class=\"content-list-item left\"><h2 class=\"content-title\">No content found</h2><p class=\"content-excerpt\">Add some markdown content and generate the site. &rarr; <a target=\"_blank\" href=\"https://marmite.blog/getting-started.html\">Getting Started</a></p></article>");
    str_cat(&body,"</div></div>"); str_init(&b); page_wrap(&b,c,title,body.s); char *p; asprintf(&p,"%s/%s",out,file); write_file(p,b.s); free(p); free(body.s); free(b.s);
}
static bool seen(char **arr,int n,const char *s){ for(int i=0;i<n;i++) if(!strcmp(arr[i],s)) return true; return false; }
static void write_feed(Config*c,const char*out,const char*file,const char*title,Item*items,int n,bool json);
static void write_group_index(Config *c,const char*out,const char*file,const char*title,Item*items,int n,const char*kind){
    Str body,b; str_init(&body); str_printf(&body,"<div class=\"list-title\"><article><strong> %s </strong></article></div><article class=\"group-details h-feed\"><h1 class=\"p-name\" style=\"display: none;\">%s</h1>",title,title);
    char **vals=NULL; int nv=0; for(int i=0;i<n;i++){ if(!strcmp(kind,"tag")) for(int j=0;j<items[i].ntags;j++) if(!seen(vals,nv,items[i].tags[j])){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=items[i].tags[j]; }
        else if(!strcmp(kind,"author")) for(int j=0;j<items[i].nauthors;j++) if(!seen(vals,nv,items[i].authors[j])){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=items[i].authors[j]; }
        else if(!strcmp(kind,"stream")&&items[i].stream&&*items[i].stream&&!seen(vals,nv,items[i].stream)){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=items[i].stream; }
        else if(!strcmp(kind,"year")&&*items[i].date){ char *y=year_of(items[i].date); if(!seen(vals,nv,y)){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=y; } else free(y); } }
    for(int v=0;v<nv;v++){ int cnt=0; for(int i=0;i<n;i++){ if(!strcmp(kind,"tag")){ for(int j=0;j<items[i].ntags;j++) if(!strcmp(vals[v],items[i].tags[j])) cnt++; } else if(!strcmp(kind,"author")){ for(int j=0;j<items[i].nauthors;j++) if(!strcmp(vals[v],items[i].authors[j])) cnt++; } else if(!strcmp(kind,"stream")&&items[i].stream&&!strcmp(vals[v],items[i].stream)) cnt++; else if(!strcmp(kind,"year")){ char *y=year_of(items[i].date); if(!strcmp(vals[v],y)) cnt++; free(y); } }
        char *sl=slugify(vals[v]); const char *pre=!strcmp(kind,"year")?"archive":kind; char *fn; if(!strcmp(kind,"stream")) asprintf(&fn,"%s.html",sl); else asprintf(&fn,"%s-%s.html",pre,sl); str_printf(&body,"<details %s><summary role=\"button\" class=\"outline contrast tag-group-title\">%s <sup>%d</sup></summary><ul><li><a href=\"%s\">more &rarr;</a></li></ul></details>",v==0?"open":"",vals[v],cnt,fn); free(sl); free(fn); if(!strcmp(kind,"year")) free(vals[v]); }
    free(vals); str_cat(&body,"</article>"); str_init(&b); page_wrap(&b,c,title,body.s); char *p; asprintf(&p,"%s/%s",out,file); write_file(p,b.s); free(p); free(body.s); free(b.s);
}
static void write_group_detail_pages(Config *c,const char*out,Item*items,int n,const char*kind){
    char **vals=NULL; int nv=0;
    for(int i=0;i<n;i++){
        if(!strcmp(kind,"tag")){
            for(int j=0;j<items[i].ntags;j++) if(!seen(vals,nv,items[i].tags[j])){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=items[i].tags[j]; }
        } else if(!strcmp(kind,"author")){
            for(int j=0;j<items[i].nauthors;j++) if(!seen(vals,nv,items[i].authors[j])){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=items[i].authors[j]; }
        } else if(!strcmp(kind,"stream")){
            if(items[i].stream&&*items[i].stream&&!seen(vals,nv,items[i].stream)){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=items[i].stream; }
        } else if(!strcmp(kind,"year")&&*items[i].date){
            char *y=year_of(items[i].date); if(!seen(vals,nv,y)){ vals=realloc(vals,sizeof(char*)*(nv+1)); vals[nv++]=y; } else free(y);
        }
    }
    for(int v=0;v<nv;v++){
        char *sl=slugify(vals[v]); char *file=NULL; const char *title=vals[v];
        if(!strcmp(kind,"tag")) asprintf(&file,"tag-%s.html",sl);
        else if(!strcmp(kind,"author")) asprintf(&file,"author-%s.html",sl);
        else if(!strcmp(kind,"stream")) asprintf(&file,"%s.html",sl);
        else asprintf(&file,"archive-%s.html",sl);
        write_list_page(c,out,file,title,items,n,false,!strcmp(kind,"year")?"year":kind,vals[v]);
        char *p1; asprintf(&p1,"%s-1.html",sl);
        char *pagefile;
        if(!strcmp(kind,"tag")) asprintf(&pagefile,"tag-%s",p1);
        else if(!strcmp(kind,"author")) asprintf(&pagefile,"author-%s",p1);
        else if(!strcmp(kind,"stream")) pagefile=xstrdup(p1);
        else asprintf(&pagefile,"archive-%s",p1);
        write_list_page(c,out,pagefile,title,items,n,false,!strcmp(kind,"year")?"year":kind,vals[v]);
        free(pagefile); free(p1);
        char *rss=strdup(file); char *dot=strrchr(rss,'.'); if(dot) strcpy(dot,".rss"); write_feed(c,out,rss,title,items,n,false); free(rss);
        if(c->json_feed){ char *js=strdup(file); dot=strrchr(js,'.'); if(dot) strcpy(dot,".json"); write_feed(c,out,js,title,items,n,true); free(js); }
        free(file); free(sl); if(!strcmp(kind,"year")) free(vals[v]);
    }
    free(vals);
}
static void write_feed(Config*c,const char*out,const char*file,const char*title,Item*items,int n,bool json){
    Str b; str_init(&b); if(json){ str_printf(&b,"{\"version\":\"https://jsonfeed.org/version/1.1\",\"title\":\"%s\",\"items\":[",title); int k=0; for(int i=0;i<n;i++) if(!items[i].page){ char *fn; asprintf(&fn,"%s.html",items[i].slug); char *u=href(c,fn); char *jt=json_escape(items[i].title); if(k++) str_cat(&b,","); str_printf(&b,"{\"id\":\"%s\",\"url\":\"%s\",\"title\":\"%s\",\"content_html\":\"%s\"}",u,u,jt,items[i].html); free(fn); free(u); free(jt);} str_cat(&b,"]}\n"); }
    else { str_printf(&b,"<?xml version=\"1.0\" encoding=\"UTF-8\"?><rss version=\"2.0\"><channel><title>%s</title>",title); for(int i=0;i<n;i++) if(!items[i].page){ char *fn; asprintf(&fn,"%s.html",items[i].slug); char *u=href(c,fn); str_printf(&b,"<item><title>%s</title><link>%s</link><description><![CDATA[%s]]></description></item>",items[i].title,u,items[i].html); free(fn); free(u);} str_cat(&b,"</channel></rss>\n"); }
    char *p; asprintf(&p,"%s/%s",out,file); write_file(p,b.s); free(p); free(b.s);
}
static void write_static(const char*out){
    char *sd=path_join(out,"static"); mkdir_p(sd); const char *css="body{font-family:sans-serif}.container{max-width:900px;margin:auto}.content-tags{display:flex;gap:.5rem;list-style:none;padding:0}.avatar{width:32px}.content-list-item{margin:1rem 0}.anchor{text-decoration:none}";
    char *p=path_join(sd,"marmite.css"); write_file(p,css); free(p); p=path_join(sd,"pico.min.css"); write_file(p,""); free(p); p=path_join(sd,"custom.css"); write_file(p,"/* Custom CSS */"); free(p); p=path_join(sd,"marmite.js"); write_file(p,""); free(p); p=path_join(sd,"custom.js"); write_file(p,"// Custom JS"); free(p); p=path_join(sd,"search.js"); write_file(p,""); free(p); p=path_join(sd,"robots.txt"); write_file(p,"User-agent: *\nAllow: /\n"); free(p); p=path_join(sd,"favicon.ico"); write_file(p,""); free(p); p=path_join(sd,"logo.png"); write_file(p,""); free(p); p=path_join(sd,"avatar-placeholder.png"); write_file(p,""); free(p); p=path_join(sd,"Atkinson-Hyperlegible-Regular-102.woff"); write_file(p,""); free(p); free(sd);
}
static void write_urls(Config*c,const char*out,Item*items,int n,bool print_only){
    Str b; str_init(&b); int posts=0,pages=1,tags=1,authors=1,archives=1,streams=1,feeds=0,pag=0; for(int i=0;i<n;i++){ if(items[i].page) pages++; else posts++; }
    str_cat(&b,"{\n  \"posts\": ["); int k=0; for(int i=0;i<n;i++) if(!items[i].page){ char *fn; asprintf(&fn,"%s.html",items[i].slug); char *u=href(c,fn); str_printf(&b,"%s\n    \"%s\"",k++?",":"",u); free(fn); free(u);} str_cat(&b,"\n  ],\n  \"pages\": ["); k=0; for(int i=0;i<n;i++) if(items[i].page){ char *fn; asprintf(&fn,"%s.html",items[i].slug); char *u=href(c,fn); str_printf(&b,"%s\n    \"%s\"",k++?",":"",u); free(fn); free(u);} char *u=href(c,"pages.html"); str_printf(&b,"%s\n    \"%s\"\n  ],\n",k?",":"",u); free(u);
    str_cat(&b,"  \"tags\": [\n    \"/tags.html\"\n  ],\n  \"authors\": [\n    \"/authors.html\"\n  ],\n  \"series\": [],\n  \"streams\": [\n    \"/streams.html\"\n  ],\n  \"archives\": [\n    \"/archive.html\"\n  ],\n  \"feeds\": [\n    \"/index.rss\"\n  ],\n  \"pagination\": [],\n  \"file_mappings\": [],\n  \"misc\": [\n    \"/index.html\"\n  ],\n");
    str_printf(&b,"  \"summary\": {\"posts\": %d, \"pages\": %d, \"tags\": %d, \"authors\": %d, \"series\": 0, \"streams\": %d, \"archives\": %d, \"feeds\": %d, \"pagination\": %d, \"file_mappings\": 0, \"misc\": 1, \"total\": %d, \"meta\": {\"url\": \"%s\", \"absolute_urls\": %s}}\n}\n",posts,pages,tags,authors,streams,archives,feeds,pag,posts+pages+tags+authors+streams+archives+feeds+pag+1,c->url,*c->url?"true":"false");
    if(print_only) fputs(b.s,stdout); else { char *p=path_join(out,"urls.json"); write_file(p,b.s); free(p); } free(b.s);
}
static void generate(Config*c,const char*input,const char*out,const char*config_path,bool show_urls){
    read_config(c,input,config_path); apply_overrides(c); char *content=path_join(input,c->content_path); const char *base=exists_dir(content)?content:input; Item *items=NULL; int n=0,cap=0; collect_md(base,base,&items,&n,&cap,c); free(content); qsort(items,n,sizeof(Item),cmp_items);
    if(show_urls){ write_urls(c,out,items,n,true); return; }
    mkdir_p(out); write_static(out); for(int i=0;i<n;i++){ write_content(c,out,&items[i]); if(c->publish_md){ char *dst=path_join(out,items[i].rel); copy_file(items[i].path,dst); free(dst); } }
    write_list_page(c,out,"index.html","Welcome to Marmite",items,n,false,NULL,NULL); write_list_page(c,out,"pages.html","Pages",items,n,true,NULL,NULL);
    write_group_index(c,out,"tags.html","Tags",items,n,"tag"); write_group_index(c,out,"authors.html","Authors",items,n,"author"); write_group_index(c,out,"streams.html","Streams",items,n,"stream"); write_group_index(c,out,"archive.html","Archive",items,n,"year");
    write_group_detail_pages(c,out,items,n,"tag"); write_group_detail_pages(c,out,items,n,"author"); write_group_detail_pages(c,out,items,n,"stream"); write_group_detail_pages(c,out,items,n,"year");
    char *p=path_join(out,"404.html"); write_file(p,"<!DOCTYPE html><html><body><h1>Not Found</h1></body></html>\n"); free(p); p=path_join(out,"robots.txt"); write_file(p,"User-agent: *\nAllow: /\n"); free(p);
    if(c->build_sitemap){ Str sm; str_init(&sm); str_cat(&sm,"<?xml version=\"1.0\" encoding=\"UTF-8\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n"); for(int i=0;i<n;i++){ char *fn; asprintf(&fn,"%s.html",items[i].slug); char *u=href(c,fn); str_printf(&sm,"<url><loc>%s</loc></url>\n",u); free(fn); free(u);} str_cat(&sm,"</urlset>\n"); p=path_join(out,"sitemap.xml"); write_file(p,sm.s); free(p); free(sm.s); }
    write_feed(c,out,"index.rss",c->name,items,n,false); if(c->json_feed) write_feed(c,out,"index.json",c->name,items,n,true);
    if(c->enable_search){ Str sj; str_init(&sj); str_cat(&sj,"["); for(int i=0;i<n;i++){ char *jt=json_escape(items[i].title),*jx=json_escape(items[i].text?items[i].text:""); str_printf(&sj,"%s{\"title\":\"%s\",\"description\":null,\"tags\":[],\"slug\":\"%s\",\"html\":\"%s\"}",i?",":"",jt,items[i].slug,jx); free(jt); free(jx);} str_cat(&sj,"]"); p=path_join(out,"static/search_index.json"); write_file(p,sj.s); free(p); free(sj.s); }
    if(c->publish_urls_json) write_urls(c,out,items,n,false);
    Str mj; str_init(&mj); str_printf(&mj,"{\"marmite_version\":\"0.2.7\",\"posts\":%d,\"pages\":%d,\"config\":{\"name\":\"%s\"}}\n",n,c->name?0:0,c->name); p=path_join(out,"marmite.json"); write_file(p,mj.s); free(p); free(mj.s);
}
static void init_site(const char *dir){
    mkdir_p(dir); char *p=path_join(dir,"marmite.yaml"); write_file(p,config_text); free(p); char *c=path_join(dir,"content"); mkdir_p(c);
    time_t now=time(NULL); struct tm *tm=gmtime(&now); char fn[128]; snprintf(fn,sizeof fn,"%04d-%02d-%02d-welcome.md",tm->tm_year+1900,tm->tm_mon+1,tm->tm_mday); p=path_join(c,fn); write_file(p,"# Welcome to Marmite\n\nThis is your first post!\n\n## Edit this content\n\nedit on `content/{date}-welcome.md`\n\n## Add more content\n\ncreate new markdown files in the `content` folder\n\nuse `marmite --new` to create new content\n\n## Customize your site\n\nedit `marmite.yaml` to change site settings\n\nedit the files starting with `_` in the `content` folder to change the layout\n\nor edit the templates to create a custom layout\n\n## Deploy your site\n\nread more on [marmite documentation](https://marmite.blog)\n"); free(p);
    p=path_join(c,"about.md"); write_file(p,"# About\n\nHi, edit `about.md` to change this content.\n        "); free(p); p=path_join(c,"_404.md"); write_file(p,"# Not Found"); free(p); p=path_join(dir,"custom.css"); write_file(p,"/* Custom CSS */"); free(p); p=path_join(dir,"custom.js"); write_file(p,"// Custom JS"); free(p); free(c);
}
static void init_templates(const char*dir){ const char*names[]={"base.html","base_feeds.html","comments.html","content.html","content_authors.html","content_date.html","content_title.html","custom_index.html.example","group.html","group_author_avatar.html","json_ld_author.html","json_ld_content.html","json_ld_index.html","list.html","pagination.html","sitemap.xml"}; char*t=path_join(dir,"templates"); mkdir_p(t); for(size_t i=0;i<sizeof(names)/sizeof(names[0]);i++){ char*p=path_join(t,names[i]); write_file(p,"{# Marmite template placeholder #}\n"); fprintf(stderr,"[INFO marmite::templates] Generated %s\n",p); free(p);} free(t); }
static void print_help(void){ puts("Marmite is the easiest static site generator.\n\nUsage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nArguments:\n  <INPUT_FOLDER>   Input folder containing markdown files\n  [OUTPUT_FOLDER]  Output folder to generate the site [default: `input_folder/site`]\n\nOptions:\n  -v, --verbose...          Verbosity level (0-4)\n  -w, --watch               Detect changes and rebuild the site automatically\n      --serve               Serve the site with a built-in HTTP server\n      --bind <BIND>         Address to bind the server [default: 0.0.0.0:8000]\n  -c, --config <CONFIG>     Path to custom configuration file [default: marmite.yaml]\n      --init-templates      Initialize templates in the project\n      --start-theme <START_THEME>\n      --set-theme <SET_THEME>\n      --generate-config     Generate the configuration file\n      --init-site           Init a new site with sample content and default configuration\n      --force               Force the rebuild of the site even if no changes detected\n      --shortcodes          List all available shortcodes\n      --show-urls           Show all site URLs organized by content type\n      --new <NEW>           Create a new post with the given title\n  -e                        Edit the file in the default editor\n  -p                        Set the new content as a page\n  -t <TAGS>                 Set the tags for the new content tags are comma separated\n  -h, --help                Print help\n  -V, --version             Print version"); }
static void shortcodes(void){ puts("Shortcodes:\nEnabled: true\nPattern: <!-- \\.(\\w+)(?:\\s+([^-][\\s\\S]*?))?\\s*-->\n\nReusable blocks of content that can be used in your markdown files.\nThey are defined in the shortcodes/ directory and are rendered using the Tera template engine.\nCheck the documentation for details on how to use and create shortcodes.\n================\nExamples based on your configuration:\n  <!-- .toc -->\n  <!-- .pages -->\n  <!-- .pages param=value -->\n  <!-- .gallery -->\n  <!-- .gallery param=value -->\n\nNote: Replace 'param' and 'value' with actual parameter names and values.\n--------------------------------\nAvailable shortcodes:\n  - authors: Display a list of all authors with post counts. Params: ord=desc, items=0\n  - card: Display a card for content based on slug with optional parameter overrides\n  - gallery: Display a gallery of images\n  - pages: Display a list of all pages. Params: ord=asc, items=0\n  - posts: Display a list of recent posts. Params: ord=desc, items=10\n  - series: Display a list of all content series with post counts. Params: ord=desc, items=0\n  - socials: Display social network links\n  - spotify: Embed Spotify content with custom dimensions\n  - streams: Display a list of all content streams with post counts. Params: ord=desc, items=0\n  - tags: Display a list of all tags with post counts. Params: ord=desc, items=0\n  - toc: Display table of contents for the current content\n  - youtube: Embed a YouTube video"); }
int main(int argc,char**argv){
    bool genconf=false,initsite=false,inittpl=false,shows=false,showurls=false,newpage=false; char *newtitle=NULL,*input=NULL,*output=NULL,*cfgpath=NULL,*tags=NULL;
    for(int i=1;i<argc;i++){ char*a=argv[i]; if(!strcmp(a,"-h")||!strcmp(a,"--help")){print_help();return 0;} else if(!strcmp(a,"-V")||!strcmp(a,"--version")){puts("marmite 0.2.7");return 0;}
        else if(!strcmp(a,"--generate-config")) genconf=true; else if(!strcmp(a,"--init-site")) initsite=true; else if(!strcmp(a,"--init-templates")) inittpl=true; else if(!strcmp(a,"--shortcodes")) shows=true; else if(!strcmp(a,"--show-urls")) showurls=true; else if(!strcmp(a,"-p")) newpage=true;
        else if(!strcmp(a,"--new")&&i+1<argc) newtitle=argv[++i]; else if(!strcmp(a,"-t")&&i+1<argc) tags=argv[++i]; else if((!strcmp(a,"-c")||!strcmp(a,"--config"))&&i+1<argc) cfgpath=argv[++i];
        else if(!strcmp(a,"--name")&&i+1<argc) opt_name=argv[++i]; else if(!strcmp(a,"--tagline")&&i+1<argc) opt_tagline=argv[++i]; else if(!strcmp(a,"--url")&&i+1<argc) opt_url=argv[++i];
        else if(!strcmp(a,"--language")&&i+1<argc) opt_language=argv[++i]; else if(!strcmp(a,"--content-path")&&i+1<argc) opt_content_path=argv[++i]; else if(!strcmp(a,"--pagination")&&i+1<argc) opt_pagination=atoi(argv[++i]);
        else if(!strcmp(a,"--enable-search")&&i+1<argc) opt_enable_search=!strcmp(argv[++i],"true"); else if(!strcmp(a,"--json-feed")&&i+1<argc) opt_json_feed=!strcmp(argv[++i],"true");
        else if(!strcmp(a,"--toc")&&i+1<argc) opt_toc=!strcmp(argv[++i],"true"); else if(!strcmp(a,"--publish-md")&&i+1<argc) opt_publish_md=!strcmp(argv[++i],"true");
        else if(!strcmp(a,"--build-sitemap")&&i+1<argc) opt_build_sitemap=!strcmp(argv[++i],"true"); else if(!strcmp(a,"--publish-urls-json")&&i+1<argc) opt_publish_urls_json=!strcmp(argv[++i],"true");
        else if(!strcmp(a,"--bind")&&i+1<argc){ i++; } else if(starts(a,"-")) { if((!strcmp(a,"--serve"))||(!strcmp(a,"--watch"))||(!strcmp(a,"--force"))||!strcmp(a,"-e")){} else if(i+1<argc && argv[i+1][0]!='-') i++; }
        else if(!input) input=a; else if(!output) output=a; }
    if(!input){ fprintf(stderr,"error: the following required arguments were not provided:\n  <INPUT_FOLDER>\n\nUsage: executable [OPTIONS] <INPUT_FOLDER> [OUTPUT_FOLDER]\n\nFor more information, try '--help'.\n"); return 2; }
    if(initsite){ init_site(input); fprintf(stderr,"[INFO marmite::site] Site initialized in %s\n",input); return 0; }
    if(genconf){ mkdir_p(input); char*p=path_join(input,"marmite.yaml"); write_file(p,config_text); fprintf(stderr,"[INFO marmite::config] Config file generated: %s\n",p); free(p); return 0; }
    if(inittpl){ init_templates(input); return 0; }
    if(shows){ shortcodes(); return 0; }
    if(newtitle){ mkdir_p(input); time_t now=time(NULL); struct tm*tm=gmtime(&now); char *sl=slugify(newtitle),fn[256]; snprintf(fn,sizeof fn,"%04d-%02d-%02d-%02d-%02d-%02d-%s.md",tm->tm_year+1900,tm->tm_mon+1,tm->tm_mday,tm->tm_hour,tm->tm_min,tm->tm_sec,sl); char*p=path_join(input,fn); Str s; str_init(&s); if(newpage||tags) { str_cat(&s,"---\n"); if(newpage) str_cat(&s,"page: true\n"); if(tags) str_printf(&s,"tags: %s\n",tags); str_cat(&s,"---\n"); } str_printf(&s,"# %s\n",newtitle); write_file(p,s.s); free(p); free(sl); free(s.s); return 0; }
    if(!exists_dir(input)){ fprintf(stderr,"[ERROR marmite] Input folder does not exist: \"%s\"\n",input); return 1; }
    if(!output){ output=path_join(input,"site"); }
    Config c; cfg_default(&c); generate(&c,input,output,cfgpath,showurls); return 0;
}
