#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <grp.h>
#include <ctype.h>
#include <locale.h>
#include <pwd.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>
#include <unistd.h>

typedef enum { FT_DIR, FT_SYMLINK, FT_FIFO, FT_SOCKET, FT_BLOCK, FT_CHAR, FT_FILE, FT_OTHER } FType;

typedef struct {
    char *path, *name, *target;
    struct stat st;
    FType type;
} Node;

typedef struct { Node *v; size_t n, cap; } Nodes;

typedef struct {
    bool header, grid, down, icon, suffix, sym, collapse, align;
    char unit[16];
    char **details; int ndetails;
    char **sorts; int nsorts;
    char **types; int ntypes;
    int imp;
    char *exclude_pat, *only_pat;
    regex_t exclude_re, only_re;
    bool has_exclude, has_only;
} Opt;

static Opt opt = {
    .header=true,.grid=false,.down=false,.icon=true,.suffix=true,.sym=true,.collapse=true,.align=true,
    .unit="binary",.imp=0
};

static void die_oom(void){ fprintf(stderr,"out of memory\n"); exit(1); }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) die_oom(); return p; }
static char *xasprintf(const char *a,const char *b){ size_t n=strlen(a)+strlen(b)+2; char *p=malloc(n); if(!p) die_oom(); snprintf(p,n,"%s/%s",a,b); return p; }
static void addstr(char ***arr,int *n,const char *s){ char **p=realloc(*arr,(*n+1)*sizeof(char*)); if(!p) die_oom(); *arr=p; (*arr)[(*n)++]=xstrdup(s); }
static void push_node(Nodes *ns, Node node){ if(ns->n==ns->cap){ ns->cap=ns->cap?ns->cap*2:32; ns->v=realloc(ns->v,ns->cap*sizeof(Node)); if(!ns->v) die_oom(); } ns->v[ns->n++]=node; }

static void print_help(bool longh){
    if(longh) {
        puts("pls is a prettier and powerful ls(1) for the pros.\n");
        puts("Read docs: https://pls.cli.rs/");
        puts("Get source: https://github.com/pls-rs/pls/");
        puts("Sponsor: https://github.com/sponsors/dhruvkb/\n");
        puts("Usage: executable [OPTIONS] [PATHS]...\n");
        puts("Arguments:");
        puts("  [PATHS]...\n          the paths to list, each of which may be a file or directory\n          \n          [default: .]\n");
        puts("Options:");
        puts("  -h, --help\n          Print help (see a summary with '-h')\n");
        puts("  -V, --version\n          Print version\n");
        puts("Detail view:");
        puts("  -d, --det <DETAILS>\n          the data points to show about each node\n          \n          [default: none]\n          [possible values: dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,\n          btime, ctime, mtime, atime, git, none, std, all]\n");
        puts("  -H, --header <HEADER>\n          show headers above columnar data\n          \n          [default: true]\n          [possible values: true, false]\n");
        puts("  -u, --unit <UNIT>\n          the type of units to use for the node sizes\n          \n          [default: binary]\n          [possible values: binary, decimal, none]\n");
        puts("Grid view:");
        puts("  -g, --grid <GRID>\n          display node names in multiple columns\n          \n          [default: false]\n          [possible values: true, false]\n");
        puts("  -D, --down <DOWN>\n          display node names column-first\n          \n          [default: false]\n          [possible values: true, false]\n");
        puts("Presentation:");
        puts("  -i, --icon <ICON>\n          display icons next to node names\n          \n          [default: true]\n          [possible values: true, false]\n");
        puts("  -S, --suffix <SUFFIX>\n          display node type suffixes after the node name\n          \n          [default: true]\n          [possible values: true, false]\n");
        puts("  -l, --sym <SYM>\n          show symlink targets\n          \n          [default: true]\n          [possible values: true, false]\n");
        puts("  -c, --collapse <COLLAPSE>\n          show dependent nodes as children of their principal nodes\n          \n          [default: true]\n          [possible values: true, false]\n");
        puts("  -a, --align <ALIGN>\n          align items accounting for leading dots\n          \n          [default: true]\n          [possible values: true, false]\n");
        puts("Filtering:");
        puts("  -t, --typ <TYPES>\n          the set of node types to include in the output\n          \n          [default: all]\n          [possible values: dir, symlink, fifo, socket, block-device, char-device, file, none, all]\n");
        puts("  -I, --imp <IMP>\n          the importance cutoff to dim or hide unimportant files\n          \n          [default: 0]\n");
        puts("  -e, --exclude <EXCLUDE>\n          the pattern of files to selectively hide from the output\n");
        puts("  -o, --only <ONLY>\n          the pattern of files to exclusively show in the output\n");
        puts("Sorting:");
        puts("  -s, --sort <SORT_BASES>\n          the set of fields to sort by, trailing `_` reverses the direction\n          \n          [default: cat cname]\n          [possible values: dev, ino, nlink, typ, cat, user, uid, group, gid, size, blocks, btime,\n          ctime, mtime, atime, name, cname, ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_,\n          gid_, size_, blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]");
    } else {
        puts("pls is a prettier and powerful ls(1) for the pros.\n");
        puts("Usage: executable [OPTIONS] [PATHS]...\n");
        puts("Arguments:");
        puts("  [PATHS]...  the paths to list, each of which may be a file or directory [default: .]\n");
        puts("Options:");
        puts("  -h, --help     Print help (see more with '--help')");
        puts("  -V, --version  Print version\n");
        puts("Detail view:");
        puts("  -d, --det <DETAILS>    the data points to show about each node [default: none] [possible values:\n                         dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks,\n                         btime, ctime, mtime, atime, git, none, std, all]");
        puts("  -H, --header <HEADER>  show headers above columnar data [default: true] [possible values: true,\n                         false]");
        puts("  -u, --unit <UNIT>      the type of units to use for the node sizes [default: binary] [possible\n                         values: binary, decimal, none]\n");
        puts("Grid view:");
        puts("  -g, --grid <GRID>  display node names in multiple columns [default: false] [possible values: true,\n                     false]");
        puts("  -D, --down <DOWN>  display node names column-first [default: false] [possible values: true, false]\n");
        puts("Presentation:");
        puts("  -i, --icon <ICON>          display icons next to node names [default: true] [possible values:\n                             true, false]");
        puts("  -S, --suffix <SUFFIX>      display node type suffixes after the node name [default: true]\n                             [possible values: true, false]");
        puts("  -l, --sym <SYM>            show symlink targets [default: true] [possible values: true, false]");
        puts("  -c, --collapse <COLLAPSE>  show dependent nodes as children of their principal nodes [default:\n                             true] [possible values: true, false]");
        puts("  -a, --align <ALIGN>        align items accounting for leading dots [default: true] [possible\n                             values: true, false]\n");
        puts("Filtering:");
        puts("  -t, --typ <TYPES>        the set of node types to include in the output [default: all] [possible\n                           values: dir, symlink, fifo, socket, block-device, char-device, file,\n                           none, all]");
        puts("  -I, --imp <IMP>          the importance cutoff to dim or hide unimportant files [default: 0]");
        puts("  -e, --exclude <EXCLUDE>  the pattern of files to selectively hide from the output");
        puts("  -o, --only <ONLY>        the pattern of files to exclusively show in the output\n");
        puts("Sorting:");
        puts("  -s, --sort <SORT_BASES>  the set of fields to sort by, trailing `_` reverses the direction\n                           [default: cat cname] [possible values: dev, ino, nlink, typ, cat, user,\n                           uid, group, gid, size, blocks, btime, ctime, mtime, atime, name, cname,\n                           ext, inode_, nlinks_, typ_, cat_, user_, uid_, group_, gid_, size_,\n                           blocks_, btime_, ctime_, mtime_, atime_, name_, cname_, ext_, none]");
    }
}

static int parse_bool(const char *optname,const char *v,bool *out){
    if(strcmp(v,"true")==0){*out=true; return 0;} if(strcmp(v,"false")==0){*out=false; return 0;}
    fprintf(stderr,"error: invalid value '%s' for '%s <%s>'\n  [possible values: true, false]\n\nFor more information, try '--help'.\n",v,optname,optname[1]=='-'?optname+2:optname);
    return 2;
}
static bool in_list(const char *v,const char *const *lst,int n){ for(int i=0;i<n;i++) if(strcmp(v,lst[i])==0) return true; return false; }
static int invalid_value(const char *flag,const char *name,const char *v,const char *vals){
    fprintf(stderr,"error: invalid value '%s' for '%s <%s>'\n  [possible values: %s]\n\nFor more information, try '--help'.\n",v,flag,name,vals); return 2;
}

static FType ftype(mode_t m){
    if(S_ISDIR(m)) return FT_DIR; if(S_ISLNK(m)) return FT_SYMLINK; if(S_ISFIFO(m)) return FT_FIFO;
    if(S_ISSOCK(m)) return FT_SOCKET; if(S_ISBLK(m)) return FT_BLOCK; if(S_ISCHR(m)) return FT_CHAR;
    if(S_ISREG(m)) return FT_FILE; return FT_OTHER;
}
static char type_ch(FType t){ return t==FT_DIR?'d':t==FT_SYMLINK?'l':t==FT_FIFO?'p':t==FT_SOCKET?'s':t==FT_BLOCK?'b':t==FT_CHAR?'c':'f'; }
static int cat(FType t){ return t==FT_DIR?0:t==FT_FILE?1:t==FT_SYMLINK?2:3; }
static const char *suffix(Node *n){
    if(!opt.suffix) return "";
    if(n->type==FT_DIR) return "/"; if(n->type==FT_SYMLINK) return "@"; if(n->type==FT_FIFO) return "|"; if(n->type==FT_SOCKET) return "=";
    if((n->st.st_mode&S_IXUSR)&&n->type==FT_FILE) return ""; return "";
}
static const char *icon(Node *n){
    if(!opt.icon) return "";
    if(n->type==FT_DIR) return "\xef\x81\xbb ";
    if(n->type==FT_SYMLINK) return "\xf3\xb0\x8c\xb9 ";
    if(n->type==FT_FIFO) return "\xf3\xb0\x9f\xa5 ";
    const char *nm=n->name, *dot=strrchr(nm,'.');
    if(strcmp(nm,"Makefile")==0 || strcmp(nm,"makefile")==0) return "\xf3\xb0\x9c\x8e ";
    if(dot && strcmp(dot,".rs")==0) return "\xee\x9a\x8b ";
    if(dot && strcmp(dot,".txt")==0) return "\xee\x98\x92 ";
    return "  ";
}
static const char *lead(Node *n){
    if(opt.icon) return icon(n);
    if(opt.align && n->name[0]!='.') return " ";
    return "";
}

static char *display_name(Node *n){
    char buf[4096];
    if(n->type==FT_SYMLINK && opt.sym && n->target)
        snprintf(buf,sizeof(buf),"%s%s%s \xf3\xb0\x81\x94 %s",lead(n),n->name,suffix(n),n->target);
    else snprintf(buf,sizeof(buf),"%s%s%s",lead(n),n->name,suffix(n));
    return xstrdup(buf);
}

static char *perms(mode_t m){
    char *p=malloc(12); if(!p) die_oom();
    snprintf(p,12,"%c%c%c %c%c%c %c%c%c",
        m&S_IRUSR?'r':'-',m&S_IWUSR?'w':'-',m&S_IXUSR?'x':'-',
        m&S_IRGRP?'r':'-',m&S_IWGRP?'w':'-',m&S_IXGRP?'x':'-',
        m&S_IROTH?'r':'-',m&S_IWOTH?'w':'-',m&S_IXOTH?'x':'-');
    return p;
}
static char *octal(mode_t m){ char *p=malloc(8); if(!p) die_oom(); snprintf(p,8,"%4o",(unsigned)(m&07777)); return p; }
static char *uname_s(uid_t uid){ struct passwd *pw=getpwuid(uid); char b[32]; if(pw) return xstrdup(pw->pw_name); snprintf(b,sizeof b,"%u",(unsigned)uid); return xstrdup(b); }
static char *gname_s(gid_t gid){ struct group *gr=getgrgid(gid); char b[32]; if(gr) return xstrdup(gr->gr_name); snprintf(b,sizeof b,"%u",(unsigned)gid); return xstrdup(b); }
static char *size_s(off_t sz){
    char *p=malloc(32); if(!p) die_oom();
    if(strcmp(opt.unit,"none")==0) snprintf(p,32,"%lld",(long long)sz);
    else {
        double v=(double)sz; const char *u[]={"B","KiB","MiB","GiB","TiB"}; const char *d[]={"B","KB","MB","GB","TB"}; int i=0; double base=strcmp(opt.unit,"decimal")==0?1000.0:1024.0;
        while(v>=base && i<4){v/=base;i++;}
        snprintf(p,32,"%.1f %3s",v,strcmp(opt.unit,"decimal")==0?d[i]:u[i]);
    }
    return p;
}
static char *time_s(time_t t){
    char *p=malloc(64); if(!p) die_oom();
    struct tm tm; localtime_r(&t,&tm);
    strftime(p,64,"%Y-%b-%d %I:%M%p",&tm);
    size_t l=strlen(p);
    if(l>=2){ p[l-2]=(char)tolower((unsigned char)p[l-2]); p[l-1]=(char)tolower((unsigned char)p[l-1]); }
    return p;
}

static bool detail_is(const char *s){
    if(opt.ndetails==0) return false;
    for(int i=0;i<opt.ndetails;i++){
        if(strcmp(opt.details[i],"none")==0) return false;
        if(strcmp(opt.details[i],"all")==0) return true;
        if(strcmp(opt.details[i],"std")==0 && (strcmp(s,"nlink")==0||strcmp(s,"typ")==0||strcmp(s,"perm")==0||strcmp(s,"user")==0||strcmp(s,"group")==0||strcmp(s,"size")==0||strcmp(s,"mtime")==0)) return true;
        if(strcmp(opt.details[i],s)==0) return true;
    }
    return false;
}
static void header_print(void){
    if(!opt.header || opt.ndetails==0 || detail_is("none")) return;
    if(detail_is("dev")) printf("Dev ");
    if(detail_is("ino")) printf("Inode ");
    if(detail_is("nlink")) printf("Link# ");
    if(detail_is("typ")) printf("T ");
    if(detail_is("perm")) printf("Permissions ");
    if(detail_is("oct")) printf("SUGO ");
    if(detail_is("user")) printf("User ");
    if(detail_is("uid")) printf("UID ");
    if(detail_is("group")) printf("Group ");
    if(detail_is("gid")) printf("GID ");
    if(detail_is("size")) printf("Size ");
    if(detail_is("blocks")) printf("Blocks ");
    if(detail_is("btime")) printf("Created ");
    if(detail_is("ctime")) printf("Changed ");
    if(detail_is("mtime")) printf("Modified ");
    if(detail_is("atime")) printf("Accessed ");
    if(detail_is("git")) printf("Git ");
    puts("Name");
}
static void print_node(Node *n){
    if(opt.ndetails>0 && !detail_is("none")){
        if(detail_is("dev")) printf("%llu ",(unsigned long long)n->st.st_dev);
        if(detail_is("ino")) printf("%llu ",(unsigned long long)n->st.st_ino);
        if(detail_is("nlink")) printf("%5llu ",(unsigned long long)n->st.st_nlink);
        if(detail_is("typ")) printf("%c ",type_ch(n->type));
        if(detail_is("perm")){ char *p=perms(n->st.st_mode); printf("%s ",p); free(p); }
        if(detail_is("oct")){ char *p=octal(n->st.st_mode); printf("%s ",p); free(p); }
        if(detail_is("user")){ char *p=uname_s(n->st.st_uid); printf("%s ",p); free(p); }
        if(detail_is("uid")) printf("%u ",(unsigned)n->st.st_uid);
        if(detail_is("group")){ char *p=gname_s(n->st.st_gid); printf("%s ",p); free(p); }
        if(detail_is("gid")) printf("%u ",(unsigned)n->st.st_gid);
        if(detail_is("size")){ if(n->type==FT_DIR) printf("       "); else { char *p=size_s(n->st.st_size); printf("%s ",p); free(p);} }
        if(detail_is("blocks")) printf("%lld ",(long long)n->st.st_blocks);
        if(detail_is("btime")){ char *p=time_s(n->st.st_ctime); printf("%s ",p); free(p); }
        if(detail_is("ctime")){ char *p=time_s(n->st.st_ctime); printf("%s ",p); free(p); }
        if(detail_is("mtime")){ char *p=time_s(n->st.st_mtime); printf("%s ",p); free(p); }
        if(detail_is("atime")){ char *p=time_s(n->st.st_atime); printf("%s ",p); free(p); }
        if(detail_is("git")) printf("  ");
    }
    char *d=display_name(n); puts(d); free(d);
}

static const char *canon_name(const char *s){ while(*s=='.') s++; return *s?s:"."; }
static const char *ext_name(const char *s){ const char *d=strrchr(s,'.'); return d?d+1:""; }
static int cmp_base(Node *a,Node *b,const char *key){
    char k[32]; strncpy(k,key,sizeof(k)-1); k[sizeof(k)-1]=0; size_t l=strlen(k); bool rev=false; if(l&&k[l-1]=='_'){rev=true;k[l-1]=0;}
    int r=0;
    if(strcmp(k,"none")==0) r=0;
    else if(strcmp(k,"cat")==0) r=cat(a->type)-cat(b->type);
    else if(strcmp(k,"typ")==0) r=(int)a->type-(int)b->type;
    else if(strcmp(k,"name")==0) r=strcmp(a->name,b->name);
    else if(strcmp(k,"cname")==0) r=strcasecmp(canon_name(a->name),canon_name(b->name));
    else if(strcmp(k,"ext")==0) r=strcasecmp(ext_name(a->name),ext_name(b->name));
    else if(strcmp(k,"size")==0) r=(a->st.st_size>b->st.st_size)-(a->st.st_size<b->st.st_size);
    else if(strcmp(k,"ino")==0||strcmp(k,"inode")==0) r=(a->st.st_ino>b->st.st_ino)-(a->st.st_ino<b->st.st_ino);
    else if(strcmp(k,"nlink")==0||strcmp(k,"nlinks")==0) r=(a->st.st_nlink>b->st.st_nlink)-(a->st.st_nlink<b->st.st_nlink);
    else if(strcmp(k,"blocks")==0) r=(a->st.st_blocks>b->st.st_blocks)-(a->st.st_blocks<b->st.st_blocks);
    else if(strcmp(k,"mtime")==0) r=(a->st.st_mtime>b->st.st_mtime)-(a->st.st_mtime<b->st.st_mtime);
    else if(strcmp(k,"ctime")==0||strcmp(k,"btime")==0) r=(a->st.st_ctime>b->st.st_ctime)-(a->st.st_ctime<b->st.st_ctime);
    else if(strcmp(k,"atime")==0) r=(a->st.st_atime>b->st.st_atime)-(a->st.st_atime<b->st.st_atime);
    else if(strcmp(k,"uid")==0) r=(a->st.st_uid>b->st.st_uid)-(a->st.st_uid<b->st.st_uid);
    else if(strcmp(k,"gid")==0) r=(a->st.st_gid>b->st.st_gid)-(a->st.st_gid<b->st.st_gid);
    else if(strcmp(k,"dev")==0) r=(a->st.st_dev>b->st.st_dev)-(a->st.st_dev<b->st.st_dev);
    if(rev) r=-r; return r;
}
static int cmp_nodes(const void *pa,const void *pb){
    Node *a=(Node*)pa,*b=(Node*)pb;
    if(opt.nsorts==0){ int r=cmp_base(a,b,"cat"); if(r) return r; return cmp_base(a,b,"cname"); }
    for(int i=0;i<opt.nsorts;i++){ int r=cmp_base(a,b,opt.sorts[i]); if(r) return r; }
    return 0;
}
static bool type_allowed(FType t){
    if(opt.ntypes==0) return true;
    bool any=false;
    for(int i=0;i<opt.ntypes;i++){
        const char *s=opt.types[i];
        if(strcmp(s,"none")==0) return false;
        if(strcmp(s,"all")==0) any=true;
        if((strcmp(s,"dir")==0&&t==FT_DIR)||(strcmp(s,"symlink")==0&&t==FT_SYMLINK)||(strcmp(s,"fifo")==0&&t==FT_FIFO)||
           (strcmp(s,"socket")==0&&t==FT_SOCKET)||(strcmp(s,"block-device")==0&&t==FT_BLOCK)||(strcmp(s,"char-device")==0&&t==FT_CHAR)||(strcmp(s,"file")==0&&t==FT_FILE)) any=true;
    }
    return any;
}
static bool pass_filters(const char *name,FType t){
    if(!type_allowed(t)) return false;
    if(opt.has_exclude && regexec(&opt.exclude_re,name,0,NULL,0)==0) return false;
    if(opt.has_only && regexec(&opt.only_re,name,0,NULL,0)!=0) return false;
    return true;
}

static Node make_node(const char *path,const char *name){
    Node n={0}; n.path=xstrdup(path); n.name=xstrdup(name);
    if(lstat(path,&n.st)!=0) memset(&n.st,0,sizeof n.st);
    n.type=ftype(n.st.st_mode);
    if(n.type==FT_SYMLINK){
        char buf[4096]; ssize_t r=readlink(path,buf,sizeof(buf)-1);
        if(r>=0){ buf[r]=0; n.target=xstrdup(buf); }
    }
    return n;
}
static int read_dir_nodes(const char *path,Nodes *out){
    DIR *d=opendir(path); if(!d) return -1;
    struct dirent *de;
    while((de=readdir(d))){
        if(strcmp(de->d_name,".")==0||strcmp(de->d_name,"..")==0) continue;
        char *p=xasprintf(path,de->d_name); Node n=make_node(p,de->d_name); free(p);
        if(pass_filters(n.name,n.type)) push_node(out,n);
    }
    closedir(d); qsort(out->v,out->n,sizeof(Node),cmp_nodes); return 0;
}
static void print_nodes(Nodes *ns){ header_print(); for(size_t i=0;i<ns->n;i++) print_node(&ns->v[i]); }

static int need_value(const char *flag){ fprintf(stderr,"error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.\n",flag); return 2; }
static int parse_args(int argc,char **argv,char ***paths,int *npaths){
    static const char *dvals[]={"dev","ino","nlink","typ","perm","oct","user","uid","group","gid","size","blocks","btime","ctime","mtime","atime","git","none","std","all"};
    static const char *tvals[]={"dir","symlink","fifo","socket","block-device","char-device","file","none","all"};
    static const char *uvals[]={"binary","decimal","none"};
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(strcmp(a,"--")==0){ while(++i<argc) addstr(paths,npaths,argv[i]); break; }
        if(strcmp(a,"-h")==0){ print_help(false); exit(0); }
        if(strcmp(a,"--help")==0){ print_help(true); exit(0); }
        if(strcmp(a,"-V")==0||strcmp(a,"--version")==0){ puts("pls 0.0.1-beta.9"); exit(0); }
        if(a[0]=='-'){
            char *val=NULL; char flag[64]; strncpy(flag,a,sizeof(flag)-1); flag[sizeof(flag)-1]=0;
            char *eq=strchr(flag,'='); if(eq){ *eq=0; val=eq+1; }
            #define NEXT() (val?val:(i+1<argc?argv[++i]:NULL))
            if(strcmp(flag,"-d")==0||strcmp(flag,"--det")==0){ char *v=NEXT(); if(!v) return need_value("--det <DETAILS>"); if(!in_list(v,dvals,20)) return invalid_value("--det","DETAILS",v,"dev, ino, nlink, typ, perm, oct, user, uid, group, gid, size, blocks, btime, ctime, mtime, atime, git, none, std, all"); addstr(&opt.details,&opt.ndetails,v); }
            else if(strcmp(flag,"-H")==0||strcmp(flag,"--header")==0){ char *v=NEXT(); if(!v) return need_value("--header <HEADER>"); int r=parse_bool("--header",v,&opt.header); if(r) return r; }
            else if(strcmp(flag,"-u")==0||strcmp(flag,"--unit")==0){ char *v=NEXT(); if(!v) return need_value("--unit <UNIT>"); if(!in_list(v,uvals,3)) return invalid_value("--unit","UNIT",v,"binary, decimal, none"); strncpy(opt.unit,v,sizeof(opt.unit)-1); }
            else if(strcmp(flag,"-g")==0||strcmp(flag,"--grid")==0){ char *v=NEXT(); if(!v) return need_value("--grid <GRID>"); int r=parse_bool("--grid",v,&opt.grid); if(r) return r; }
            else if(strcmp(flag,"-D")==0||strcmp(flag,"--down")==0){ char *v=NEXT(); if(!v) return need_value("--down <DOWN>"); int r=parse_bool("--down",v,&opt.down); if(r) return r; }
            else if(strcmp(flag,"-i")==0||strcmp(flag,"--icon")==0){ char *v=NEXT(); if(!v) return need_value("--icon <ICON>"); int r=parse_bool("--icon",v,&opt.icon); if(r) return r; }
            else if(strcmp(flag,"-S")==0||strcmp(flag,"--suffix")==0){ char *v=NEXT(); if(!v) return need_value("--suffix <SUFFIX>"); int r=parse_bool("--suffix",v,&opt.suffix); if(r) return r; }
            else if(strcmp(flag,"-l")==0||strcmp(flag,"--sym")==0){ char *v=NEXT(); if(!v) return need_value("--sym <SYM>"); int r=parse_bool("--sym",v,&opt.sym); if(r) return r; }
            else if(strcmp(flag,"-c")==0||strcmp(flag,"--collapse")==0){ char *v=NEXT(); if(!v) return need_value("--collapse <COLLAPSE>"); int r=parse_bool("--collapse",v,&opt.collapse); if(r) return r; }
            else if(strcmp(flag,"-a")==0||strcmp(flag,"--align")==0){ char *v=NEXT(); if(!v) return need_value("--align <ALIGN>"); int r=parse_bool("--align",v,&opt.align); if(r) return r; }
            else if(strcmp(flag,"-t")==0||strcmp(flag,"--typ")==0){ char *v=NEXT(); if(!v) return need_value("--typ <TYPES>"); if(!in_list(v,tvals,9)) return invalid_value("--typ","TYPES",v,"dir, symlink, fifo, socket, block-device, char-device, file, none, all"); addstr(&opt.types,&opt.ntypes,v); }
            else if(strcmp(flag,"-I")==0||strcmp(flag,"--imp")==0){ char *v=NEXT(); if(!v) return need_value("--imp <IMP>"); opt.imp=atoi(v); }
            else if(strcmp(flag,"-e")==0||strcmp(flag,"--exclude")==0){ char *v=NEXT(); if(!v) return need_value("--exclude <EXCLUDE>"); int r=regcomp(&opt.exclude_re,v,REG_EXTENDED|REG_NOSUB); if(r){ char buf[256]; regerror(r,&opt.exclude_re,buf,sizeof buf); fprintf(stderr,"error: invalid value '%s' for '--exclude <EXCLUDE>': %s\n\nFor more information, try '--help'.\n",v,buf); return 2;} opt.has_exclude=true; }
            else if(strcmp(flag,"-o")==0||strcmp(flag,"--only")==0){ char *v=NEXT(); if(!v) return need_value("--only <ONLY>"); int r=regcomp(&opt.only_re,v,REG_EXTENDED|REG_NOSUB); if(r){ char buf[256]; regerror(r,&opt.only_re,buf,sizeof buf); fprintf(stderr,"error: invalid value '%s' for '--only <ONLY>': %s\n\nFor more information, try '--help'.\n",v,buf); return 2;} opt.has_only=true; }
            else if(strcmp(flag,"-s")==0||strcmp(flag,"--sort")==0){ char *v=NEXT(); if(!v) return need_value("--sort <SORT_BASES>"); addstr(&opt.sorts,&opt.nsorts,v); }
            else { fprintf(stderr,"error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [PATHS]...\n\nFor more information, try '--help'.\n",a,a,a); return 2; }
            #undef NEXT
        } else addstr(paths,npaths,a);
    }
    if(*npaths==0) addstr(paths,npaths,".");
    return 0;
}

int main(int argc,char **argv){
    setlocale(LC_ALL, "");
    char **paths=NULL; int npaths=0; int pr=parse_args(argc,argv,&paths,&npaths); if(pr) return pr;
    int status=0; bool multi=npaths>1;
    for(int i=0;i<npaths;i++){
        struct stat st; if(lstat(paths[i],&st)!=0){ printf("%s:\n\terror: %s (os error %d)\n",paths[i],strerror(errno),errno); status=1; continue; }
        FType t=ftype(st.st_mode);
        if(t==FT_DIR){
            if(multi) printf("%s:\n",paths[i]);
            Nodes ns={0}; if(read_dir_nodes(paths[i],&ns)!=0){ printf("\terror: %s (os error %d)\n",strerror(errno),errno); status=1; }
            else print_nodes(&ns);
            if(multi && i<npaths-1) putchar('\n');
        } else {
            Node n=make_node(paths[i],strrchr(paths[i],'/')?strrchr(paths[i],'/')+1:paths[i]);
            if(pass_filters(n.name,n.type)) print_node(&n);
            if(multi && i<npaths-1) putchar('\n');
        }
    }
    return status;
}
