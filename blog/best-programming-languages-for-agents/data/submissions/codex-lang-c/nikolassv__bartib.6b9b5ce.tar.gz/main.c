#define _GNU_SOURCE
#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    time_t start, end;
    int has_end, valid, line;
    char start_s[17], end_s[17];
    char *project, *desc, *raw;
} Activity;

typedef struct {
    Activity *v;
    size_t n, cap;
    int parse_errors;
    char **bad_lines;
    int *bad_nums;
} Log;

static void die_file(void) {
    fprintf(stderr, "Error: Please specify a file with your activity log either as -f option or as BARTIB_FILE environment variable\n");
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) exit(2);
    return r;
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static void push(Log *l, Activity a) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 32;
        l->v = realloc(l->v, l->cap * sizeof(Activity));
        if (!l->v) exit(2);
    }
    l->v[l->n++] = a;
}

static int parse_dt(const char *s, time_t *out) {
    struct tm tm;
    memset(&tm, 0, sizeof tm);
    tm.tm_isdst = -1;
    char *p = strptime(s, "%Y-%m-%d %H:%M", &tm);
    if (!p || *p) return 0;
    *out = mktime(&tm);
    return 1;
}

static void fmt_dt(time_t t, char out[17]) {
    struct tm tm;
    localtime_r(&t, &tm);
    strftime(out, 17, "%Y-%m-%d %H:%M", &tm);
}

static void fmt_date(time_t t, char out[11]) {
    struct tm tm;
    localtime_r(&t, &tm);
    strftime(out, 11, "%Y-%m-%d", &tm);
}

static void fmt_time(time_t t, char out[6]) {
    struct tm tm;
    localtime_r(&t, &tm);
    strftime(out, 6, "%H:%M", &tm);
}

static void duration_s(long sec, char out[32]) {
    if (sec < 60) { strcpy(out, "<1m"); return; }
    long m = sec / 60;
    long h = m / 60;
    m %= 60;
    if (h) snprintf(out, 32, "%ldh %02ldm", h, m);
    else snprintf(out, 32, "%ldm", m);
}

static int same_day(time_t a, time_t b) {
    char da[11], db[11];
    fmt_date(a, da); fmt_date(b, db);
    return strcmp(da, db) == 0;
}

static time_t parse_date_start(const char *s) {
    char buf[32];
    snprintf(buf, sizeof buf, "%s 00:00", s);
    time_t t = 0;
    return parse_dt(buf, &t) ? t : (time_t)-1;
}

static int weekday_monday0(time_t t) {
    struct tm tm;
    localtime_r(&t, &tm);
    return (tm.tm_wday + 6) % 7;
}

static time_t day_floor(time_t t) {
    struct tm tm;
    localtime_r(&t, &tm);
    tm.tm_hour = tm.tm_min = tm.tm_sec = 0;
    return mktime(&tm);
}

static int parse_line(const char *line_in, int num, Activity *a) {
    memset(a, 0, sizeof *a);
    a->line = num;
    a->raw = xstrdup(line_in);
    char *line = xstrdup(line_in);
    char *p1 = strstr(line, " | ");
    if (!p1) { free(line); return 0; }
    *p1 = 0;
    char *p2 = strstr(p1 + 3, " | ");
    if (!p2) { free(line); return 0; }
    *p2 = 0;
    char *times = trim(line);
    char *proj = trim(p1 + 3);
    char *desc = trim(p2 + 3);
    size_t dl = strlen(desc);
    if (dl && desc[dl-1] == '\n') desc[--dl] = 0;
    char *dash = strstr(times, " - ");
    if (dash) {
        *dash = 0;
        strncpy(a->start_s, times, 16); a->start_s[16] = 0;
        strncpy(a->end_s, dash + 3, 16); a->end_s[16] = 0;
        if (!parse_dt(a->start_s, &a->start) || !parse_dt(a->end_s, &a->end)) { free(line); return 0; }
        a->has_end = 1;
    } else {
        strncpy(a->start_s, times, 16); a->start_s[16] = 0;
        if (!parse_dt(a->start_s, &a->start)) { free(line); return 0; }
    }
    a->project = xstrdup(proj);
    a->desc = xstrdup(desc);
    a->valid = 1;
    free(line);
    return 1;
}

static Log read_log(const char *path, int warn) {
    Log l;
    memset(&l, 0, sizeof l);
    FILE *f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "Error: Could not read from file: %s\n\nCaused by:\n    %s (os error %d)\n", path, strerror(errno), errno);
        exit(1);
    }
    char *line = NULL;
    size_t z = 0;
    int num = 1;
    while (getline(&line, &z, f) != -1) {
        Activity a;
        if (parse_line(line, num, &a)) push(&l, a);
        else {
            l.parse_errors++;
            l.bad_lines = realloc(l.bad_lines, l.parse_errors * sizeof(char*));
            l.bad_nums = realloc(l.bad_nums, l.parse_errors * sizeof(int));
            l.bad_lines[l.parse_errors-1] = xstrdup(line);
            l.bad_nums[l.parse_errors-1] = num;
        }
        num++;
    }
    free(line);
    fclose(f);
    if (warn && l.parse_errors)
        printf("Warning: Ignoring line %d. Please see `bartib check` for further information\n\n", l.bad_nums[0]);
    return l;
}

static void rewrite_log(const char *path, Log *l) {
    FILE *f = fopen(path, "w");
    if (!f) {
        fprintf(stderr, "Error: Could not write to file: %s\n", path);
        exit(1);
    }
    for (size_t i = 0; i < l->n; i++) {
        Activity *a = &l->v[i];
        if (!a->valid) continue;
        char ss[17], es[17];
        fmt_dt(a->start, ss);
        if (a->has_end) {
            fmt_dt(a->end, es);
            fprintf(f, "%s - %s | %s | %s\n", ss, es, a->project, a->desc);
        } else {
            fprintf(f, "%s | %s | %s\n", ss, a->project, a->desc);
        }
    }
    fclose(f);
}

static void append_activity(const char *path, time_t st, const char *proj, const char *desc) {
    FILE *f = fopen(path, "a");
    if (!f) {
        fprintf(stderr, "Error: Could not write to file: %s\n", path);
        exit(1);
    }
    char ss[17]; fmt_dt(st, ss);
    fprintf(f, "%s | %s | %s\n", ss, proj, desc);
    fclose(f);
}

static int parse_hhmm(const char *s, time_t *out) {
    if (!s || strlen(s) != 5 || !isdigit((unsigned char)s[0]) || !isdigit((unsigned char)s[1]) || s[2] != ':' || !isdigit((unsigned char)s[3]) || !isdigit((unsigned char)s[4])) return 0;
    int h = (s[0]-'0')*10 + s[1]-'0', m = (s[3]-'0')*10 + s[4]-'0';
    if (h > 23 || m > 59) return 0;
    time_t now = time(NULL);
    struct tm tm;
    localtime_r(&now, &tm);
    tm.tm_hour = h; tm.tm_min = m; tm.tm_sec = 0;
    *out = mktime(&tm);
    return 1;
}

static time_t option_time(const char *s) {
    time_t t;
    if (s && parse_hhmm(s, &t)) return t;
    if (s) printf("Can not parse \"%s\" as time. Argument for -t/--time is ignored (input contains invalid characters)\n", s);
    return time(NULL);
}

static void stop_running(Log *l, time_t end, int print) {
    int any = 0;
    for (size_t i = 0; i < l->n; i++) if (!l->v[i].has_end) {
        l->v[i].end = end;
        l->v[i].has_end = 1;
        any = 1;
        if (print) {
            char ss[17], d[32]; fmt_dt(l->v[i].start, ss); duration_s((long)difftime(end, l->v[i].start), d);
            printf("Stopped activity: \"%s\" (%s) started at %s (%s)\n", l->v[i].desc, l->v[i].project, ss, d);
        }
    }
    (void)any;
}

static void start_cmd(const char *file, const char *desc, const char *proj, time_t st) {
    Log l = read_log(file, 0);
    stop_running(&l, st, 1);
    rewrite_log(file, &l);
    append_activity(file, st, proj, desc);
    char ss[17]; fmt_dt(st, ss);
    printf("Started activity: \"%s\" (%s) at %s\n", desc, proj, ss);
}

static void cancel_cmd(const char *file) {
    Log l = read_log(file, 0);
    for (size_t i = 0; i < l.n; i++) if (!l.v[i].has_end) {
        char ss[17]; fmt_dt(l.v[i].start, ss);
        printf("Canceled activity: \"%s\" (%s) started at %s\n", l.v[i].desc, l.v[i].project, ss);
        l.v[i].valid = 0;
    }
    rewrite_log(file, &l);
}

static void change_cmd(const char *file, const char *desc, const char *proj, time_t st) {
    Log l = read_log(file, 0);
    for (size_t i = 0; i < l.n; i++) if (!l.v[i].has_end) l.v[i].valid = 0;
    rewrite_log(file, &l);
    append_activity(file, st, proj, desc);
    char ss[17]; fmt_dt(st, ss);
    printf("Changed activity: \"%s\" (%s) started at %s\n", desc, proj, ss);
}

static int cmpstr(const void *a, const void *b) {
    return strcmp(*(char * const *)a, *(char * const *)b);
}

static int seen_pair(Activity **arr, int n, Activity *a) {
    for (int i = 0; i < n; i++) if (!strcmp(arr[i]->desc, a->desc) && !strcmp(arr[i]->project, a->project)) return 1;
    return 0;
}

static Activity **recent_unique(Log *l, int *outn) {
    Activity **r = calloc(l->n ? l->n : 1, sizeof(Activity*));
    int n = 0;
    for (int i = (int)l->n - 1; i >= 0; i--) {
        if (!seen_pair(r, n, &l->v[i])) r[n++] = &l->v[i];
    }
    *outn = n;
    return r;
}

static void print_last_like(Log *l, int max, const char *term) {
    int n; Activity **r = recent_unique(l, &n);
    printf("\n\033[4m # \033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \n");
    int start = n - 1, end = 0;
    for (int i = start; i >= end; i--) {
        if (max >= 0 && i >= max) continue;
        if (term && !strcasestr(r[i]->desc, term) && !strcasestr(r[i]->project, term)) continue;
        printf("[%d] %-11s %-7s \n", i, r[i]->desc, r[i]->project);
    }
    free(r);
}

static void projects_cmd(const char *file, int current, int no_quotes) {
    Log l = read_log(file, 0);
    char **p = calloc(l.n ? l.n : 1, sizeof(char*));
    int n = 0;
    for (size_t i = 0; i < l.n; i++) {
        if (current && l.v[i].has_end) continue;
        int seen = 0;
        for (int j = 0; j < n; j++) if (!strcmp(p[j], l.v[i].project)) seen = 1;
        if (!seen) p[n++] = l.v[i].project;
    }
    qsort(p, n, sizeof(char*), cmpstr);
    for (int i = 0; i < n; i++) printf(no_quotes ? "%s\n" : "\"%s\"\n", p[i]);
    free(p);
}

typedef struct {
    int today, yesterday, curweek, lastweek, nogroup, number;
    char *date, *from, *to, *project, *rounds;
} Filter;

static int round_minutes(const char *s) {
    if (!s || !*s) return 0;
    int v = atoi(s);
    if (v <= 0) return 0;
    char c = s[strlen(s)-1];
    if (c == 'h') return v * 60;
    return v;
}

static time_t round_time(time_t t, int mins) {
    if (!mins) return t;
    long step = mins * 60L;
    long v = (long)t;
    long r = ((v + step / 2) / step) * step;
    return (time_t)r;
}

static int filter_match(Activity *a, Filter *f) {
    if (f->project && strcmp(a->project, f->project)) return 0;
    time_t now = time(NULL);
    time_t start = 0, end = LLONG_MAX;
    if (f->today) { start = day_floor(now); end = start + 86400; }
    if (f->yesterday) { end = day_floor(now); start = end - 86400; }
    if (f->curweek) { start = day_floor(now) - weekday_monday0(now) * 86400; end = start + 7 * 86400; }
    if (f->lastweek) { end = day_floor(now) - weekday_monday0(now) * 86400; start = end - 7 * 86400; }
    if (f->date) { start = parse_date_start(f->date); end = start + 86400; }
    if (f->from) start = parse_date_start(f->from);
    if (f->to) end = parse_date_start(f->to) + 86400;
    return a->start >= start && a->start < end;
}

static long activity_duration(Activity *a, int rnd) {
    time_t s = round_time(a->start, rnd), e = round_time(a->has_end ? a->end : time(NULL), rnd);
    return (long)difftime(e, s);
}

static void list_cmd(const char *file, Filter *f) {
    Log l = read_log(file, 1);
    int rnd = round_minutes(f->rounds);
    int *idx = calloc(l.n ? l.n : 1, sizeof(int));
    int n = 0;
    for (size_t i = 0; i < l.n; i++) if (filter_match(&l.v[i], f)) idx[n++] = (int)i;
    int start_i = 0;
    if (f->number >= 0 && n > f->number) start_i = n - f->number;
    printf("\n\033[4mStarted\033[0m \033[4mStopped\033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \033[4mDuration\033[0m \n");
    char lastdate[11] = "";
    for (int k = start_i; k < n; k++) {
        Activity *a = &l.v[idx[k]];
        char ds[11], st[6], en[6], dur[32], sfull[17];
        time_t rs = round_time(a->start, rnd), re = round_time(a->has_end ? a->end : time(NULL), rnd);
        fmt_date(rs, ds); fmt_time(rs, st); fmt_time(re, en); fmt_dt(rs, sfull);
        duration_s((long)difftime(re, rs), dur);
        if (!f->nogroup && !f->today && !f->yesterday && !f->date && !f->from && !f->to) {
            if (strcmp(ds, lastdate)) {
                long total = 0;
                for (int j = start_i; j < n; j++) {
                    char d2[11]; fmt_date(l.v[idx[j]].start, d2);
                    if (!strcmp(d2, ds)) total += activity_duration(&l.v[idx[j]], rnd);
                }
                char td[32]; duration_s(total, td);
                printf("\n\033[1m%s\t%s\033[0m\n", ds, td);
                strcpy(lastdate, ds);
            }
            printf("%-7s %-7s %-11s %-7s %-8s \n", st, a->has_end ? en : "-", a->desc, a->project, dur);
        } else {
            const char *first = (f->nogroup || (!f->today && !f->yesterday && !f->date && !f->from && !f->to)) ? sfull : st;
            printf("%-16s %-7s %-11s %-7s %-8s \n", first, a->has_end ? en : "-", a->desc, a->project, dur);
        }
    }
    free(idx);
}

typedef struct { char *project, *desc; long sec; } Sum;

static void report_cmd(const char *file, Filter *f) {
    Log l = read_log(file, 1);
    int rnd = round_minutes(f->rounds);
    Sum *s = calloc((l.n ? l.n : 1), sizeof(Sum));
    int n = 0;
    long total = 0;
    for (size_t i = 0; i < l.n; i++) if (filter_match(&l.v[i], f)) {
        long d = activity_duration(&l.v[i], rnd);
        total += d;
        int found = -1;
        for (int j = 0; j < n; j++) if (!strcmp(s[j].project, l.v[i].project) && !strcmp(s[j].desc, l.v[i].desc)) found = j;
        if (found < 0) { found = n++; s[found].project = l.v[i].project; s[found].desc = l.v[i].desc; }
        s[found].sec += d;
    }
    for (int i = 0; i < n; i++) {
        int first = 1; long psum = 0;
        for (int j = 0; j < n; j++) if (!strcmp(s[j].project, s[i].project)) psum += s[j].sec;
        for (int p = 0; p < i; p++) if (!strcmp(s[p].project, s[i].project)) first = 0;
        if (!first) continue;
        char pd[32]; duration_s(psum, pd);
        printf("\n\033[1m%s.... %s\033[0m\n", s[i].project, pd);
        for (int j = 0; j < n; j++) if (!strcmp(s[j].project, s[i].project)) {
            char dd[32]; duration_s(s[j].sec, dd);
            printf("    %s %s\n", s[j].desc, dd);
        }
    }
    char td[32]; duration_s(total, td);
    printf("\n\033[1mTotal %s\033[0m\n", td);
    free(s);
}

static void check_cmd(const char *file) {
    Log l = read_log(file, 0);
    if (!l.parse_errors) { printf("No parsing errors found\n"); return; }
    printf("Found %d line(s) with parsing errors\n\n", l.parse_errors);
    for (int i = 0; i < l.parse_errors; i++) printf("%s  -> could not parse activity (Line: %d)\n", l.bad_lines[i], l.bad_nums[i]);
}

static void sanity_cmd(const char *file) {
    Log l = read_log(file, 0);
    int any = 0;
    for (size_t i = 0; i < l.n; i++) {
        if (l.v[i].has_end && l.v[i].end < l.v[i].start) {
            printf("Activity has negative duration\n%s (Started: %s, Ended: %s, Line: %d)\n\n", l.v[i].desc, l.v[i].start_s, l.v[i].end_s, l.v[i].line);
            any = 1;
        }
        for (size_t j = 0; j < i; j++) if (l.v[j].has_end && l.v[i].start < l.v[j].end && (l.v[i].has_end ? l.v[i].end : time(NULL)) > l.v[j].start) {
            printf("Activity started before another activity ended\n%s (Started: %s, Ended: %s, Line: %d)\n\n", l.v[i].desc, l.v[i].start_s, l.v[i].has_end ? l.v[i].end_s : "-", l.v[i].line);
            any = 1; break;
        }
    }
    if (!any) printf("No sanity issues found\n");
}

static void current_cmd(const char *file) {
    Log l = read_log(file, 1);
    int any = 0;
    for (size_t i = 0; i < l.n; i++) if (!l.v[i].has_end) any = 1;
    if (!any) { printf("No Activity is currently running\n"); return; }
    printf("\n\033[4mStarted At\033[0m \033[4mDescription\033[0m \033[4mProject\033[0m \033[4mDuration\033[0m \n");
    for (size_t i = 0; i < l.n; i++) if (!l.v[i].has_end) {
        char ss[17], d[32]; fmt_dt(l.v[i].start, ss); duration_s((long)difftime(time(NULL), l.v[i].start), d);
        printf("%-16s %-11s %-7s %-8s \n", ss, l.v[i].desc, l.v[i].project, d);
    }
}

static void status_cmd(const char *file, const char *project) {
    Log l = read_log(file, 1);
    printf("\033[2m\n =======\033[0m\033[3m Status for \033[0m\033[1m%s\033[0m\033[3m projects \033[0m\033[2m ======= \n\033[0m", project ? project : "ALL");
    printf("\033[2;3m\n  NOW: \033[0m");
    int any = 0;
    for (size_t i = 0; i < l.n; i++) if (!l.v[i].has_end && (!project || !strcmp(project, l.v[i].project))) {
        printf("\033[1m%s (%s)\n\033[0m", l.v[i].desc, l.v[i].project); any = 1;
    }
    if (!any) printf("\033[1m NO Activity\n\n\033[0m");
    Filter f; memset(&f, 0, sizeof f); f.number = -1; f.project = (char*)project;
    f.today = 1; long vals[3] = {0,0,0};
    time_t now = time(NULL), mstart = day_floor(now) - weekday_monday0(now)*86400;
    struct tm mt; localtime_r(&now, &mt); mt.tm_mday = 1; mt.tm_hour = mt.tm_min = mt.tm_sec = 0; time_t mostart = mktime(&mt);
    for (size_t i = 0; i < l.n; i++) if (!project || !strcmp(project, l.v[i].project)) {
        long d = activity_duration(&l.v[i], 0);
        if (same_day(l.v[i].start, now)) vals[0] += d;
        if (l.v[i].start >= mstart) vals[1] += d;
        if (l.v[i].start >= mostart) vals[2] += d;
    }
    char d0[32], d1[32], d2[32]; duration_s(vals[0], d0); duration_s(vals[1], d1); duration_s(vals[2], d2);
    printf("\033[3m \033[0m\033[2;3m Today......................... \033[0m\033[1m%s\033[0m\033[3m\n", d0);
    printf("\033[0m\033[3m \033[0m\033[2;3m Current week.................. \033[0m\033[1m%s\033[0m\033[3m\n", d1);
    printf("\033[0m\033[3m \033[0m\033[2;3m Current month................. \033[0m\033[1m%s\033[0m\n", d2);
}

static void version(void) {
    printf("bartib 1.1.0\n");
}

static void help_main(void) {
    printf("bartib 1.1.0\nNikolas Schmidt-Voigt <nikolas.schmidt-voigt@posteo.de>\nA simple timetracker\n\nUSAGE:\n    executable [OPTIONS] <SUBCOMMAND>\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -f <FILE>        the file in which bartib tracks all the activities [env: BARTIB_FILE=]\n\nSUBCOMMANDS:\n    cancel      cancels all currently running activities\n    change      changes the current activity\n    check       checks file and reports parsing errors\n    continue    continues a previous activity\n    current     lists all currently running activities\n    edit        opens the activity log in an editor\n    last        displays the descriptions and projects of recent activities\n    list        list recent activities\n    projects    list all projects\n    report      reports duration of tracked activities\n    sanity      checks sanity of bartib log\n    search      search for existing descriptions and projects\n    start       starts a new activity\n    status      shows current status and time reports for today, current week, and current month\n    stop        stops all currently running activities\n");
}

static void help_sub(const char *c) {
    if (!strcmp(c, "start"))
        printf("executable-start \nstarts a new activity\n\nUSAGE:\n    executable start [OPTIONS] --description <DESCRIPTION> --project <PROJECT>\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)\n");
    else if (!strcmp(c, "stop"))
        printf("executable-stop \nstops all currently running activities\n\nUSAGE:\n    executable stop [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -t, --time <TIME>    the time for changing the activity status (HH:MM)\n");
    else if (!strcmp(c, "cancel") || !strcmp(c, "check") || !strcmp(c, "current") || !strcmp(c, "sanity"))
        printf("executable-%s \n\nUSAGE:\n    executable %s\n\nFLAGS:\n    -h, --help    Prints help information\n", c, c);
    else if (!strcmp(c, "change"))
        printf("executable-change \nchanges the current activity\n\nUSAGE:\n    executable change [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)\n");
    else if (!strcmp(c, "continue"))
        printf("executable-continue \ncontinues a previous activity\n\nUSAGE:\n    executable continue [OPTIONS] [NUMBER]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -d, --description <DESCRIPTION>    the description of the new activity\n    -p, --project <PROJECT>            the project to which the new activity belongs\n    -t, --time <TIME>                  the time for changing the activity status (HH:MM)\n\nARGS:\n    <NUMBER>    the number of the activity to continue (see subcommand `last`) [default: 0]\n");
    else if (!strcmp(c, "edit"))
        printf("executable-edit \nopens the activity log in an editor\n\nUSAGE:\n    executable edit [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -e <editor>        the command to start your preferred text editor [env: EDITOR=]\n");
    else if (!strcmp(c, "last"))
        printf("executable-last \ndisplays the descriptions and projects of recent activities\n\nUSAGE:\n    executable last [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -n, --number <NUMBER>    maximum number of lines to display [default: 10]\n");
    else if (!strcmp(c, "projects"))
        printf("executable-projects \nlist all projects\n\nUSAGE:\n    executable projects [FLAGS]\n\nFLAGS:\n    -c, --current      prints currently running projects only\n    -h, --help         Prints help information\n    -n, --no-quotes    prints projects without quotes\n");
    else if (!strcmp(c, "search"))
        printf("executable-search \nsearch for existing descriptions and projects\n\nUSAGE:\n    executable search <SEARCH_TERM>\n\nFLAGS:\n    -h, --help    Prints help information\n\nARGS:\n    <SEARCH_TERM>    the search term [default: '']\n");
    else if (!strcmp(c, "status"))
        printf("executable-status \nshows current status and time reports for today, current week, and current month\n\nUSAGE:\n    executable status [OPTIONS]\n\nFLAGS:\n    -h, --help    Prints help information\n\nOPTIONS:\n    -p, --project <PROJECT>    show status for this project only\n");
    else if (!strcmp(c, "list"))
        printf("executable-list \nlist recent activities\n\nUSAGE:\n    executable list [FLAGS] [OPTIONS]\n\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --no_grouping     do not group activities by date in list\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -n, --number <NUMBER>      maximum number of activities to display\n    -p, --project <PROJECT>    do list activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or\n                               hours. E.g. 15m or 4h\n        --to <TO_DATE>         end of date range (inclusive)\n");
    else if (!strcmp(c, "report"))
        printf("executable-report \nreports duration of tracked activities\n\nUSAGE:\n    executable report [FLAGS] [OPTIONS]\n\nFLAGS:\n        --current_week    show activities of the current week\n    -h, --help            Prints help information\n        --last_week       show activities of the last week\n        --today           show activities of the current day\n        --yesterday       show yesterdays' activities\n\nOPTIONS:\n    -d, --date <DATE>          show activities of a certain date only\n        --from <FROM_DATE>     begin of date range (inclusive)\n    -p, --project <PROJECT>    do report activities for this project only\n        --round <round>        rounds the start and end time to the nearest duration. Durations can be in minutes or\n                               hours. E.g. 15m or 4h\n        --to <DATE>            end of date range (inclusive)\n");
    else help_main();
}

static char *argval(int *i, int argc, char **argv) {
    if (*i + 1 >= argc) return NULL;
    return argv[++*i];
}

int main(int argc, char **argv) {
    const char *file = getenv("BARTIB_FILE");
    int i = 1;
    for (; i < argc; i++) {
        if (!strcmp(argv[i], "-f")) file = argval(&i, argc, argv);
        else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { help_main(); return 0; }
        else if (!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version")) { version(); return 0; }
        else break;
    }
    if (i >= argc) { help_main(); return 0; }
    char *cmd = argv[i++];
    if (!strcmp(cmd, "help")) { help_main(); return 0; }
    for (int j = i; j < argc; j++) if (!strcmp(argv[j], "-h") || !strcmp(argv[j], "--help")) { help_sub(cmd); return 0; }
    if (!file || !*file) die_file();
    if (!strcmp(cmd, "start") || !strcmp(cmd, "change")) {
        char *d = NULL, *p = NULL, *ts = NULL;
        for (; i < argc; i++) {
            if (!strcmp(argv[i], "-d") || !strcmp(argv[i], "--description")) d = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--project")) p = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "-t") || !strcmp(argv[i], "--time")) ts = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { help_main(); return 0; }
        }
        if (!d) d = "";
        if (!p) p = "";
        time_t t = option_time(ts);
        if (!strcmp(cmd, "start")) start_cmd(file, d, p, t); else change_cmd(file, d, p, t);
    } else if (!strcmp(cmd, "stop")) {
        char *ts = NULL;
        for (; i < argc; i++) if (!strcmp(argv[i], "-t") || !strcmp(argv[i], "--time")) ts = argval(&i, argc, argv);
        Log l = read_log(file, 0); stop_running(&l, option_time(ts), 1); rewrite_log(file, &l);
    } else if (!strcmp(cmd, "cancel")) cancel_cmd(file);
    else if (!strcmp(cmd, "current")) current_cmd(file);
    else if (!strcmp(cmd, "check")) check_cmd(file);
    else if (!strcmp(cmd, "sanity")) sanity_cmd(file);
    else if (!strcmp(cmd, "projects")) {
        int cur = 0, noq = 0;
        for (; i < argc; i++) { if (!strcmp(argv[i], "-c") || !strcmp(argv[i], "--current")) cur = 1; if (!strcmp(argv[i], "-n") || !strcmp(argv[i], "--no-quotes")) noq = 1; }
        projects_cmd(file, cur, noq);
    } else if (!strcmp(cmd, "last")) {
        int n = 10;
        for (; i < argc; i++) if (!strcmp(argv[i], "-n") || !strcmp(argv[i], "--number")) n = atoi(argval(&i, argc, argv));
        Log l = read_log(file, 0); print_last_like(&l, n, NULL);
    } else if (!strcmp(cmd, "search")) {
        char *term = (i < argc) ? argv[i] : "";
        Log l = read_log(file, 0); print_last_like(&l, -1, term);
    } else if (!strcmp(cmd, "continue")) {
        char *d = NULL, *p = NULL, *ts = NULL; int num = 0;
        for (; i < argc; i++) {
            if (!strcmp(argv[i], "-d") || !strcmp(argv[i], "--description")) d = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--project")) p = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "-t") || !strcmp(argv[i], "--time")) ts = argval(&i, argc, argv);
            else num = atoi(argv[i]);
        }
        Log l = read_log(file, 0);
        if (!d || !p) {
            int n; Activity **r = recent_unique(&l, &n);
            if (num >= 0 && num < n) { if (!d) d = r[num]->desc; if (!p) p = r[num]->project; }
            free(r);
        }
        if (!d) d = "";
        if (!p) p = "";
        start_cmd(file, d, p, option_time(ts));
    } else if (!strcmp(cmd, "list") || !strcmp(cmd, "report")) {
        Filter f; memset(&f, 0, sizeof f); f.number = -1;
        for (; i < argc; i++) {
            if (!strcmp(argv[i], "--today")) f.today = 1; else if (!strcmp(argv[i], "--yesterday")) f.yesterday = 1;
            else if (!strcmp(argv[i], "--current_week") || !strcmp(argv[i], "--current-week")) f.curweek = 1;
            else if (!strcmp(argv[i], "--last_week") || !strcmp(argv[i], "--last-week")) f.lastweek = 1;
            else if (!strcmp(argv[i], "--no_grouping")) f.nogroup = 1;
            else if (!strcmp(argv[i], "-d") || !strcmp(argv[i], "--date")) f.date = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "--from")) f.from = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "--to")) f.to = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--project")) f.project = argval(&i, argc, argv);
            else if (!strcmp(argv[i], "-n") || !strcmp(argv[i], "--number")) f.number = atoi(argval(&i, argc, argv));
            else if (!strcmp(argv[i], "--round")) f.rounds = argval(&i, argc, argv);
        }
        if (!strcmp(cmd, "list")) list_cmd(file, &f); else report_cmd(file, &f);
    } else if (!strcmp(cmd, "status")) {
        char *p = NULL;
        for (; i < argc; i++) if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--project")) p = argval(&i, argc, argv);
        status_cmd(file, p);
    } else if (!strcmp(cmd, "edit")) {
        char *ed = getenv("EDITOR");
        for (; i < argc; i++) if (!strcmp(argv[i], "-e")) ed = argval(&i, argc, argv);
        if (!ed || !*ed) ed = "vi";
        char buf[PATH_MAX + 128]; snprintf(buf, sizeof buf, "%s %s", ed, file); return system(buf);
    } else {
        help_main(); return 1;
    }
    return 0;
}
