#define _XOPEN_SOURCE 700
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <libgen.h>
#include <limits.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char *src;
    char *dst;
} Operation;

typedef struct {
    Operation *v;
    size_t n, cap;
} OpList;

typedef struct {
    bool dry, force, backup, silent, dump, no_dump;
    bool include_dirs, recursive, hidden, undo;
    int max_depth;
    int limit;
    const char *dump_prefix;
    const char *transform;
} Opts;

static void die_oom(void) { fprintf(stderr, "out of memory\n"); exit(1); }

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) die_oom();
    return p;
}

static char *xstrndup(const char *s, size_t n) {
    char *p = malloc(n + 1);
    if (!p) die_oom();
    memcpy(p, s, n);
    p[n] = 0;
    return p;
}

static void append_str(char **buf, size_t *len, size_t *cap, const char *s, size_t n) {
    if (*len + n + 1 > *cap) {
        size_t nc = *cap ? *cap * 2 : 64;
        while (*len + n + 1 > nc) nc *= 2;
        char *p = realloc(*buf, nc);
        if (!p) die_oom();
        *buf = p; *cap = nc;
    }
    memcpy(*buf + *len, s, n);
    *len += n;
    (*buf)[*len] = 0;
}

static void add_op(OpList *ops, const char *src, const char *dst) {
    if (ops->n == ops->cap) {
        size_t nc = ops->cap ? ops->cap * 2 : 16;
        Operation *p = realloc(ops->v, nc * sizeof(*p));
        if (!p) die_oom();
        ops->v = p; ops->cap = nc;
    }
    ops->v[ops->n].src = xstrdup(src);
    ops->v[ops->n].dst = xstrdup(dst);
    ops->n++;
}

static const char *base_name_const(const char *path) {
    const char *s = strrchr(path, '/');
    return s ? s + 1 : path;
}

static char *join_dir_base(const char *path, const char *base) {
    const char *s = strrchr(path, '/');
    if (!s) return xstrdup(base);
    size_t n = (size_t)(s - path + 1);
    char *out = malloc(n + strlen(base) + 1);
    if (!out) die_oom();
    memcpy(out, path, n);
    strcpy(out + n, base);
    return out;
}

static void transform_text(char *s, const char *kind) {
    if (!kind) return;
    for (char *p = s; *p; p++) {
        unsigned char c = (unsigned char)*p;
        if (!strcmp(kind, "upper")) *p = (char)toupper(c);
        else if (!strcmp(kind, "lower")) *p = (char)tolower(c);
    }
}

static char *ascii_name(const char *s) {
    char *out = NULL; size_t len = 0, cap = 0;
    for (const unsigned char *p = (const unsigned char *)s; *p;) {
        if (*p < 128) {
            append_str(&out, &len, &cap, (const char *)p, 1);
            p++;
        } else if (p[0] == 0xc3 && p[1]) {
            char c = 0;
            switch (p[1]) {
                case 0xa0: case 0xa1: case 0xa2: case 0xa3: case 0xa4: case 0xa5: c='a'; break;
                case 0x80: case 0x81: case 0x82: case 0x83: case 0x84: case 0x85: c='A'; break;
                case 0xa7: c='c'; break; case 0x87: c='C'; break;
                case 0xa8: case 0xa9: case 0xaa: case 0xab: c='e'; break;
                case 0x88: case 0x89: case 0x8a: case 0x8b: c='E'; break;
                case 0xac: case 0xad: case 0xae: case 0xaf: c='i'; break;
                case 0x8c: case 0x8d: case 0x8e: case 0x8f: c='I'; break;
                case 0xb1: c='n'; break; case 0x91: c='N'; break;
                case 0xb2: case 0xb3: case 0xb4: case 0xb5: case 0xb6: case 0xb8: c='o'; break;
                case 0x92: case 0x93: case 0x94: case 0x95: case 0x96: case 0x98: c='O'; break;
                case 0xb9: case 0xba: case 0xbb: case 0xbc: c='u'; break;
                case 0x99: case 0x9a: case 0x9b: case 0x9c: c='U'; break;
                case 0xbd: case 0xbf: c='y'; break; case 0x9d: c='Y'; break;
            }
            if (c) append_str(&out, &len, &cap, &c, 1);
            p += 2;
        } else {
            p++;
        }
    }
    if (!out) return xstrdup("");
    return out;
}

static char *expand_repl(const char *name, const char *repl, regmatch_t *m, size_t nm, const char *transform) {
    char *out = NULL; size_t len = 0, cap = 0;
    for (size_t i = 0; repl[i];) {
        if (repl[i] == '$') {
            if (repl[i+1] == '{' && isdigit((unsigned char)repl[i+2])) {
                int k = repl[i+2] - '0'; size_t j = i + 3;
                if (repl[j] == '}') {
                    if ((size_t)k < nm && m[k].rm_so >= 0) {
                        char *seg = xstrndup(name + m[k].rm_so, (size_t)(m[k].rm_eo - m[k].rm_so));
                        transform_text(seg, transform);
                        if (transform && !strcmp(transform, "ascii")) {
                            char *a = ascii_name(seg); free(seg); seg = a;
                        }
                        append_str(&out, &len, &cap, seg, strlen(seg)); free(seg);
                    }
                    i = j + 1; continue;
                }
            } else if (isdigit((unsigned char)repl[i+1]) && !isalnum((unsigned char)repl[i+2]) && repl[i+2] != '_') {
                int k = repl[i+1] - '0';
                if ((size_t)k < nm && m[k].rm_so >= 0) {
                    char *seg = xstrndup(name + m[k].rm_so, (size_t)(m[k].rm_eo - m[k].rm_so));
                    transform_text(seg, transform);
                    if (transform && !strcmp(transform, "ascii")) {
                        char *a = ascii_name(seg); free(seg); seg = a;
                    }
                    append_str(&out, &len, &cap, seg, strlen(seg)); free(seg);
                }
                i += 2; continue;
            } else {
                i++;
                while (isalnum((unsigned char)repl[i]) || repl[i] == '_') i++;
                continue;
            }
        }
        append_str(&out, &len, &cap, repl + i, 1);
        i++;
    }
    if (!out) return xstrdup("");
    return out;
}

static char *regex_replace_name(regex_t *rx, const char *name, const char *repl, int limit, const char *transform) {
    char *out = NULL; size_t len = 0, cap = 0, pos = 0; int count = 0;
    size_t n = strlen(name);
    regmatch_t m[10];
    while (pos <= n && (limit == 0 || count < limit) && regexec(rx, name + pos, 10, m, 0) == 0) {
        if (m[0].rm_so < 0) break;
        size_t so = pos + (size_t)m[0].rm_so, eo = pos + (size_t)m[0].rm_eo;
        append_str(&out, &len, &cap, name + pos, so - pos);
        regmatch_t adj[10];
        for (int i = 0; i < 10; i++) {
            adj[i] = m[i];
            if (adj[i].rm_so >= 0) { adj[i].rm_so += (regoff_t)pos; adj[i].rm_eo += (regoff_t)pos; }
        }
        char *r = expand_repl(name, repl, adj, 10, transform);
        if (transform && (!strcmp(transform, "upper") || !strcmp(transform, "lower"))) transform_text(r, transform);
        else if (transform && !strcmp(transform, "ascii")) { char *a = ascii_name(r); free(r); r = a; }
        append_str(&out, &len, &cap, r, strlen(r));
        free(r);
        count++;
        if (eo == pos) {
            if (pos < n) append_str(&out, &len, &cap, name + pos, 1);
            pos++;
        } else pos = eo;
    }
    append_str(&out, &len, &cap, name + pos, n - pos);
    return out ? out : xstrdup(name);
}

static bool is_dir_path(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}

static bool exists_path(const char *p) {
    struct stat st;
    return lstat(p, &st) == 0;
}

static void collect_path(OpList *ops, regex_t *rx, const char *repl, const char *path, const Opts *o, int depth);

static int cmpstrp(const void *a, const void *b) {
    const char *const *pa = a, *const *pb = b;
    return strcmp(*pa, *pb);
}

static void collect_dir(OpList *ops, regex_t *rx, const char *repl, const char *path, const Opts *o, int depth) {
    if (!o->recursive) return;
    if (o->max_depth >= 0 && depth >= o->max_depth) return;
    DIR *d = opendir(path);
    if (!d) return;
    char **names = NULL; size_t n = 0, cap = 0;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        if (!o->hidden && e->d_name[0] == '.') continue;
        if (n == cap) {
            size_t nc = cap ? cap * 2 : 16;
            char **p = realloc(names, nc * sizeof(*p));
            if (!p) die_oom();
            names = p; cap = nc;
        }
        names[n++] = xstrdup(e->d_name);
    }
    closedir(d);
    qsort(names, n, sizeof(char *), cmpstrp);
    for (size_t pass = 0; pass < 2; pass++) {
      for (size_t i = 0; i < n; i++) {
        char child[PATH_MAX];
        snprintf(child, sizeof(child), "%s/%s", path, names[i]);
        bool dchild = is_dir_path(child);
        if ((pass == 0 && dchild) || (pass == 1 && !dchild))
            collect_path(ops, rx, repl, child, o, depth + 1);
      }
    }
    for (size_t i = 0; i < n; i++) free(names[i]);
    free(names);
}

static void collect_one(OpList *ops, regex_t *rx, const char *repl, const char *path, const Opts *o) {
    bool dir = is_dir_path(path);
    if (dir && !o->include_dirs) return;
    const char *base = base_name_const(path);
    char *newbase = regex_replace_name(rx, base, repl, o->limit, o->transform);
    if (strcmp(base, newbase)) {
        char *dst = join_dir_base(path, newbase);
        add_op(ops, path, dst);
        free(dst);
    }
    free(newbase);
}

static void collect_path(OpList *ops, regex_t *rx, const char *repl, const char *path, const Opts *o, int depth) {
    if (!exists_path(path)) return;
    if (is_dir_path(path)) {
        collect_dir(ops, rx, repl, path, o, depth);
        collect_one(ops, rx, repl, path, o);
    } else collect_one(ops, rx, repl, path, o);
}

static void collect_ascii_path(OpList *ops, const char *path, const Opts *o, int depth);

static void collect_ascii_dir(OpList *ops, const char *path, const Opts *o, int depth) {
    if (!o->recursive) return;
    if (o->max_depth >= 0 && depth >= o->max_depth) return;
    DIR *d = opendir(path);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
        if (!o->hidden && e->d_name[0] == '.') continue;
        char child[PATH_MAX]; snprintf(child, sizeof(child), "%s/%s", path, e->d_name);
        collect_ascii_path(ops, child, o, depth + 1);
    }
    closedir(d);
}

static void collect_ascii_path(OpList *ops, const char *path, const Opts *o, int depth) {
    if (!exists_path(path)) return;
    if (is_dir_path(path)) {
        collect_ascii_dir(ops, path, o, depth);
        if (!o->include_dirs) return;
    }
    const char *base = base_name_const(path);
    char *newbase = ascii_name(base);
    if (strcmp(base, newbase)) {
        char *dst = join_dir_base(path, newbase);
        add_op(ops, path, dst);
        free(dst);
    }
    free(newbase);
}

static void print_help_main(void) {
    puts("RnR is a command-line tool to rename multiple files and directories that\nsupports regular expressions\n");
    puts("Usage: executable <COMMAND>\n");
    puts("Commands:\n  regex      Rename files and directories using a regular expression\n  from-file  Read operations from a dump file\n  to-ascii   Replace file name UTF-8 chars with ASCII chars representation\n  help       Print this message or the help of the given subcommand(s)\n");
    puts("Options:\n  -h, --help     Print help\n  -V, --version  Print version");
}

static void print_help_regex(void) {
    puts("Rename files and directories using a regular expression\n\nUsage: executable regex [OPTIONS] <EXPRESSION> <REPLACEMENT> <PATH(S)>...\n");
    puts("Arguments:\n  <EXPRESSION>   Expression to match (can be a regex)\n  <REPLACEMENT>  Expression replacement (use single quotes for capture groups)\n  <PATH(S)>...   Target paths\n");
    puts("Options:\n  -n, --dry-run\n          Only show what would be done (default mode)\n  -f, --force\n          Make actual changes to files\n  -b, --backup\n          Generate file backups before renaming\n  -s, --silent\n          Do not print any information\n      --color <COLOR>\n          Set color output mode [default: auto] [possible values: always, never, auto]\n      --dump\n          Force dumping operations into a file even in dry-run mode\n      --dump-prefix <DUMP_PREFIX>\n          Set the dump file prefix [default: rnr-]\n      --no-dump\n          Do not dump operations into a file\n  -l, --replace-limit <LIMIT>\n          Limit of replacements, all matches if set to 0\n  -t, --replace-transform <REPLACE_TRANSFORM>\n          Apply a transformation to replacements including captured groups [possible values: upper, lower, ascii]\n  -D, --include-dirs\n          Rename matching directories\n  -r, --recursive\n          Recursive mode\n  -d, --max-depth <LEVEL>\n          Set max depth in recursive mode\n  -x, --hidden\n          Include hidden files and directories\n  -h, --help\n          Print help");
}

static void print_help_from(void) {
    puts("Read operations from a dump file\n\nUsage: executable from-file [OPTIONS] <DUMPFILE>\n");
    puts("Arguments:\n  <DUMPFILE>  \n\nOptions:\n  -n, --dry-run                    Only show what would be done (default mode)\n  -f, --force                      Make actual changes to files\n  -b, --backup                     Generate file backups before renaming\n  -s, --silent                     Do not print any information\n      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]\n      --dump                       Force dumping operations into a file even in dry-run mode\n      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]\n      --no-dump                    Do not dump operations into a file\n  -u, --undo                       Undo the operations from the dump file\n  -h, --help                       Print help");
}

static void print_help_ascii(void) {
    puts("Replace file name UTF-8 chars with ASCII chars representation\n\nUsage: executable to-ascii [OPTIONS] <PATH(S)>...\n");
    puts("Arguments:\n  <PATH(S)>...  Target paths\n\nOptions:\n  -n, --dry-run                    Only show what would be done (default mode)\n  -f, --force                      Make actual changes to files\n  -b, --backup                     Generate file backups before renaming\n  -s, --silent                     Do not print any information\n      --color <COLOR>              Set color output mode [default: auto] [possible values: always, never, auto]\n      --dump                       Force dumping operations into a file even in dry-run mode\n      --dump-prefix <DUMP_PREFIX>  Set the dump file prefix [default: rnr-]\n      --no-dump                    Do not dump operations into a file\n  -D, --include-dirs               Rename matching directories\n  -r, --recursive                  Recursive mode\n  -d, --max-depth <LEVEL>          Set max depth in recursive mode\n  -x, --hidden                     Include hidden files and directories\n  -h, --help                       Print help");
}

static void init_opts(Opts *o) {
    memset(o, 0, sizeof(*o));
    o->dry = true; o->dump_prefix = "rnr-"; o->max_depth = -1; o->limit = 1;
}

static int parse_common(Opts *o, int argc, char **argv, int *i, bool ascii, bool from) {
    char *a = argv[*i];
    if (!strcmp(a, "-n") || !strcmp(a, "--dry-run")) { o->dry = true; o->force = false; return 1; }
    if (!strcmp(a, "-f") || !strcmp(a, "--force")) { o->force = true; o->dry = false; return 1; }
    if (!strcmp(a, "-b") || !strcmp(a, "--backup")) { o->backup = true; return 1; }
    if (!strcmp(a, "-s") || !strcmp(a, "--silent")) { o->silent = true; return 1; }
    if (!strcmp(a, "--dump")) { o->dump = true; return 1; }
    if (!strcmp(a, "--no-dump")) { o->no_dump = true; return 1; }
    if (!strcmp(a, "--dump-prefix") && *i + 1 < argc) { o->dump_prefix = argv[++*i]; return 1; }
    if (!strcmp(a, "--color") && *i + 1 < argc) { ++*i; return 1; }
    if (!from && (!strcmp(a, "-D") || !strcmp(a, "--include-dirs"))) { o->include_dirs = true; return 1; }
    if (!from && (!strcmp(a, "-r") || !strcmp(a, "--recursive"))) { o->recursive = true; return 1; }
    if (!from && (!strcmp(a, "-x") || !strcmp(a, "--hidden"))) { o->hidden = true; return 1; }
    if (!from && (!strcmp(a, "-d") || !strcmp(a, "--max-depth")) && *i + 1 < argc) { o->max_depth = atoi(argv[++*i]); return 1; }
    if (!ascii && !from && (!strcmp(a, "-l") || !strcmp(a, "--replace-limit")) && *i + 1 < argc) { o->limit = atoi(argv[++*i]); return 1; }
    if (!ascii && !from && (!strcmp(a, "-t") || !strcmp(a, "--replace-transform")) && *i + 1 < argc) { o->transform = argv[++*i]; return 1; }
    if (from && (!strcmp(a, "-u") || !strcmp(a, "--undo"))) { o->undo = true; return 1; }
    return 0;
}

static int execute_ops(OpList *ops, const Opts *o);

static void json_escape(FILE *f, const char *s) {
    for (; *s; s++) {
        if (*s == '\\' || *s == '"') fprintf(f, "\\%c", *s);
        else if (*s == '\n') fputs("\\n", f);
        else fputc(*s, f);
    }
}

static void write_dump(OpList *ops, const Opts *o) {
    if (o->no_dump || ops->n == 0) return;
    if (o->dry && !o->dump) return;
    time_t t = time(NULL); struct tm tmv; localtime_r(&t, &tmv);
    char stamp[64], fname[PATH_MAX];
    strftime(stamp, sizeof(stamp), "%Y-%m-%d_%H%M%S", &tmv);
    snprintf(fname, sizeof(fname), "%s%s.json", o->dump_prefix, stamp);
    FILE *f = fopen(fname, "w");
    if (!f) return;
    char date[64]; strftime(date, sizeof(date), "%Y-%m-%d %H:%M:%S", &tmv);
    fprintf(f, "{\n  \"date\": \"%s\",\n  \"operations\": [\n", date);
    for (size_t i = 0; i < ops->n; i++) {
        fprintf(f, "    {\n      \"source\": \""); json_escape(f, ops->v[i].src);
        fprintf(f, "\",\n      \"target\": \""); json_escape(f, ops->v[i].dst);
        fprintf(f, "\"\n    }%s\n", i + 1 == ops->n ? "" : ",");
    }
    fputs("  ]\n}", f);
    fclose(f);
}

static int execute_ops(OpList *ops, const Opts *o) {
    int rc = 0;
    if (o->dry && !o->silent) puts("This is a DRY-RUN");
    for (size_t i = 0; i < ops->n; i++) {
        if (exists_path(ops->v[i].dst) && strcmp(ops->v[i].src, ops->v[i].dst)) {
            if (!o->silent) fprintf(stderr, "Error: Conflict with existing path %s -> %s\n", ops->v[i].src, ops->v[i].dst);
            rc = 1; continue;
        }
        if (o->force) {
            if (o->backup) {
                char *bk = malloc(strlen(ops->v[i].src) + 4);
                if (!bk) die_oom();
                sprintf(bk, "%s.bk", ops->v[i].src);
                FILE *in = fopen(ops->v[i].src, "rb");
                FILE *out = fopen(bk, "wb");
                if (in && out) {
                    char buf[8192]; size_t n;
                    while ((n = fread(buf, 1, sizeof(buf), in))) fwrite(buf, 1, n, out);
                    if (!o->silent) printf("Info:  Backup created - %s -> %s\n", ops->v[i].src, bk);
                }
                if (in) fclose(in);
                if (out) fclose(out);
                free(bk);
            }
            if (!o->silent) printf("%s -> %s\n", ops->v[i].src, ops->v[i].dst);
            if (rename(ops->v[i].src, ops->v[i].dst) != 0) rc = 1;
        } else {
            if (!o->silent) printf("%s -> %s\n", ops->v[i].src, ops->v[i].dst);
        }
    }
    write_dump(ops, o);
    return rc;
}

static char *read_file(const char *p) {
    FILE *f = fopen(p, "rb"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); rewind(f);
    char *buf = malloc((size_t)n + 1); if (!buf) die_oom();
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = 0; fclose(f); return buf;
}

static char *json_string_after(char **p, const char *key) {
    char *k = strstr(*p, key); if (!k) return NULL;
    char *q = strchr(k + strlen(key), '"'); if (!q) return NULL; q++;
    char *out = NULL; size_t len = 0, cap = 0;
    while (*q && *q != '"') {
        if (*q == '\\' && q[1]) q++;
        append_str(&out, &len, &cap, q, 1); q++;
    }
    *p = q;
    return out ? out : xstrdup("");
}

static int cmd_from_file(int argc, char **argv) {
    Opts o; init_opts(&o);
    int i = 2;
    for (; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { print_help_from(); return 0; }
        if (!parse_common(&o, argc, argv, &i, false, true)) break;
    }
    if (i >= argc) { print_help_from(); return 2; }
    char *buf = read_file(argv[i]);
    if (!buf) return 1;
    OpList ops = {0};
    char *p = buf;
    while ((p = strstr(p, "\"source\""))) {
        char *src = json_string_after(&p, "\"source\"");
        char *dst = json_string_after(&p, "\"target\"");
        if (!src || !dst) break;
        if (o.undo) add_op(&ops, dst, src); else add_op(&ops, src, dst);
        free(src); free(dst);
    }
    free(buf);
    int rc = execute_ops(&ops, &o);
    return rc;
}

static int cmd_regex(int argc, char **argv) {
    Opts o; init_opts(&o);
    int i = 2;
    for (; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { print_help_regex(); return 0; }
        if (!parse_common(&o, argc, argv, &i, false, false)) break;
    }
    if (i + 2 >= argc) { print_help_regex(); return 2; }
    const char *expr = argv[i++], *repl = argv[i++];
    regex_t rx;
    if (regcomp(&rx, expr, REG_EXTENDED)) return 1;
    OpList ops = {0};
    for (; i < argc; i++) collect_path(&ops, &rx, repl, argv[i], &o, 0);
    regfree(&rx);
    return execute_ops(&ops, &o);
}

static int cmd_ascii(int argc, char **argv) {
    Opts o; init_opts(&o);
    int i = 2;
    for (; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { print_help_ascii(); return 0; }
        if (!parse_common(&o, argc, argv, &i, true, false)) break;
    }
    if (i >= argc) { print_help_ascii(); return 2; }
    OpList ops = {0};
    for (; i < argc; i++) collect_ascii_path(&ops, argv[i], &o, 0);
    return execute_ops(&ops, &o);
}

int main(int argc, char **argv) {
    if (argc < 2 || !strcmp(argv[1], "-h") || !strcmp(argv[1], "--help") || !strcmp(argv[1], "help")) {
        if (argc >= 3 && !strcmp(argv[2], "regex")) print_help_regex();
        else if (argc >= 3 && !strcmp(argv[2], "from-file")) print_help_from();
        else if (argc >= 3 && !strcmp(argv[2], "to-ascii")) print_help_ascii();
        else print_help_main();
        return 0;
    }
    if (!strcmp(argv[1], "-V") || !strcmp(argv[1], "--version")) { puts("rnr 0.5.1"); return 0; }
    if (!strcmp(argv[1], "regex")) return cmd_regex(argc, argv);
    if (!strcmp(argv[1], "from-file")) return cmd_from_file(argc, argv);
    if (!strcmp(argv[1], "to-ascii")) return cmd_ascii(argc, argv);
    print_help_main();
    return 2;
}
