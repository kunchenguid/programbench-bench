#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <time.h>

typedef enum { JNULL, JBOOL, JNUM, JSTR, JOBJ, JARR } JType;

typedef struct JVal JVal;
typedef struct {
    char *key;
    JVal *val;
} Pair;

struct JVal {
    JType type;
    char *s;
    double n;
    bool b;
    Pair *pairs;
    int count, cap;
    JVal **items;
    int icount, icap;
};

typedef struct {
    char **add;
    int addn;
    char **exclude;
    int exn;
    char **msg_keys;
    int msgn;
    char **time_keys;
    int timen;
    char **level_keys;
    int leveln;
    char **ctx_keys;
    int ctxn;
    char **map_from, **map_to;
    int mapn;
    char *input;
    char *filter;
    char *placeholder;
    char *main_fmt;
    char *add_fmt;
    bool dump_all, with_prefix, substitute, print_lua, no_return;
} Opt;

static char *xstrdup(const char *s) {
    if (!s) return NULL;
    char *r = strdup(s);
    if (!r) { perror("strdup"); exit(1); }
    return r;
}

static void add_str(char ***arr, int *n, const char *s) {
    *arr = realloc(*arr, sizeof(char*) * (*n + 1));
    (*arr)[(*n)++] = xstrdup(s);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static JVal *jnew(JType t) {
    JVal *v = calloc(1, sizeof(*v));
    if (!v) exit(1);
    v->type = t;
    return v;
}

static void jfree(JVal *v) {
    if (!v) return;
    free(v->s);
    for (int i = 0; i < v->count; i++) { free(v->pairs[i].key); jfree(v->pairs[i].val); }
    for (int i = 0; i < v->icount; i++) jfree(v->items[i]);
    free(v->pairs); free(v->items); free(v);
}

static void skip_ws(const char **p) {
    while (isspace((unsigned char)**p)) (*p)++;
}

static char *parse_string(const char **p) {
    if (**p != '"') return NULL;
    (*p)++;
    size_t cap = 64, len = 0;
    char *out = malloc(cap);
    while (**p && **p != '"') {
        unsigned char c = (unsigned char)*(*p)++;
        if (c == '\\') {
            c = (unsigned char)*(*p)++;
            switch (c) {
                case 'n': c = '\n'; break;
                case 'r': c = '\r'; break;
                case 't': c = '\t'; break;
                case 'b': c = '\b'; break;
                case 'f': c = '\f'; break;
                case 'u':
                    for (int i = 0; i < 4 && isxdigit((unsigned char)**p); i++) (*p)++;
                    c = '?';
                    break;
                default: break;
            }
        }
        if (len + 2 >= cap) { cap *= 2; out = realloc(out, cap); }
        out[len++] = (char)c;
    }
    if (**p != '"') { free(out); return NULL; }
    (*p)++;
    out[len] = 0;
    return out;
}

static JVal *parse_val(const char **p);

static JVal *parse_obj(const char **p) {
    if (**p != '{') return NULL;
    (*p)++;
    JVal *o = jnew(JOBJ);
    skip_ws(p);
    if (**p == '}') { (*p)++; return o; }
    while (**p) {
        skip_ws(p);
        char *k = parse_string(p);
        if (!k) { jfree(o); return NULL; }
        skip_ws(p);
        if (**p != ':') { free(k); jfree(o); return NULL; }
        (*p)++;
        JVal *v = parse_val(p);
        if (!v) { free(k); jfree(o); return NULL; }
        if (o->count == o->cap) {
            o->cap = o->cap ? o->cap * 2 : 8;
            o->pairs = realloc(o->pairs, sizeof(Pair) * o->cap);
        }
        o->pairs[o->count++] = (Pair){k, v};
        skip_ws(p);
        if (**p == '}') { (*p)++; return o; }
        if (**p != ',') { jfree(o); return NULL; }
        (*p)++;
    }
    jfree(o);
    return NULL;
}

static JVal *parse_arr(const char **p) {
    if (**p != '[') return NULL;
    (*p)++;
    JVal *a = jnew(JARR);
    skip_ws(p);
    if (**p == ']') { (*p)++; return a; }
    while (**p) {
        JVal *v = parse_val(p);
        if (!v) { jfree(a); return NULL; }
        if (a->icount == a->icap) {
            a->icap = a->icap ? a->icap * 2 : 8;
            a->items = realloc(a->items, sizeof(JVal*) * a->icap);
        }
        a->items[a->icount++] = v;
        skip_ws(p);
        if (**p == ']') { (*p)++; return a; }
        if (**p != ',') { jfree(a); return NULL; }
        (*p)++;
        skip_ws(p);
    }
    jfree(a);
    return NULL;
}

static JVal *parse_val(const char **p) {
    skip_ws(p);
    if (**p == '"') {
        char *s = parse_string(p);
        if (!s) return NULL;
        JVal *v = jnew(JSTR); v->s = s; return v;
    }
    if (**p == '{') return parse_obj(p);
    if (**p == '[') return parse_arr(p);
    if (!strncmp(*p, "true", 4)) { *p += 4; JVal *v = jnew(JBOOL); v->b = true; return v; }
    if (!strncmp(*p, "false", 5)) { *p += 5; JVal *v = jnew(JBOOL); return v; }
    if (!strncmp(*p, "null", 4)) { *p += 4; return jnew(JNULL); }
    if (**p == '-' || isdigit((unsigned char)**p)) {
        char *end = NULL;
        errno = 0;
        double n = strtod(*p, &end);
        if (end == *p || errno) return NULL;
        JVal *v = jnew(JNUM); v->n = n; v->s = strndup(*p, (size_t)(end - *p)); *p = end; return v;
    }
    return NULL;
}

static JVal *json_parse(const char *s) {
    const char *p = s;
    JVal *v = parse_val(&p);
    if (!v) return NULL;
    skip_ws(&p);
    if (*p) { jfree(v); return NULL; }
    return v;
}

static JVal *obj_get(JVal *o, const char *key) {
    if (!o || o->type != JOBJ) return NULL;
    for (int i = 0; i < o->count; i++) if (!strcmp(o->pairs[i].key, key)) return o->pairs[i].val;
    return NULL;
}

static JVal *path_get(JVal *root, const char *path) {
    char *tmp = xstrdup(path), *s = trim(tmp);
    JVal *cur = root;
    char *save = NULL;
    for (char *tok = strtok_r(s, ">", &save); tok; tok = strtok_r(NULL, ">", &save)) {
        tok = trim(tok);
        char *p = tok;
        char name[512];
        int ni = 0;
        while (*p && *p != '[' && ni < (int)sizeof(name)-1) name[ni++] = *p++;
        name[ni] = 0;
        char *nt = trim(name);
        if (*nt) cur = obj_get(cur, nt);
        while (cur && *p == '[') {
            p++;
            int idx = atoi(p);
            while (*p && *p != ']') p++;
            if (*p == ']') p++;
            if (cur->type != JARR || idx < 0 || idx >= cur->icount) cur = NULL;
            else cur = cur->items[idx];
        }
        if (!cur) break;
    }
    free(tmp);
    return cur;
}

static JVal *find_first(JVal *root, char **keys, int n) {
    for (int i = 0; i < n; i++) {
        JVal *v = path_get(root, keys[i]);
        if (v) return v;
    }
    return NULL;
}

static char *val_plain(JVal *v, bool quote_strings);
static void sb_append(char **buf, size_t *len, size_t *cap, const char *s) {
    size_t n = strlen(s);
    if (*len + n + 1 > *cap) {
        while (*len + n + 1 > *cap) *cap = *cap ? *cap * 2 : 128;
        *buf = realloc(*buf, *cap);
    }
    memcpy(*buf + *len, s, n + 1);
    *len += n;
}
static void sb_printf(char **buf, size_t *len, size_t *cap, const char *fmt, ...) {
    va_list ap, cp;
    va_start(ap, fmt); va_copy(cp, ap);
    int n = vsnprintf(NULL, 0, fmt, ap);
    va_end(ap);
    char *tmp = malloc((size_t)n + 1);
    vsnprintf(tmp, (size_t)n + 1, fmt, cp);
    va_end(cp);
    sb_append(buf, len, cap, tmp);
    free(tmp);
}

static char *val_plain(JVal *v, bool quote_strings) {
    if (!v) return xstrdup("");
    if (v->type == JSTR) {
        if (!quote_strings) return xstrdup(v->s);
        size_t cap = strlen(v->s) * 2 + 3, len = 0; char *b = malloc(cap); b[len++] = '"';
        for (char *p = v->s; *p; p++) {
            if (*p == '"' || *p == '\\') { b[len++]='\\'; b[len++]=*p; }
            else if (*p == '\n') { b[len++]='\\'; b[len++]='n'; }
            else b[len++] = *p;
        }
        b[len++] = '"'; b[len] = 0; return b;
    }
    if (v->type == JNUM) return xstrdup(v->s ? v->s : "0");
    if (v->type == JBOOL) return xstrdup(v->b ? "true" : "false");
    if (v->type == JNULL) return xstrdup("null");
    size_t len = 0, cap = 0; char *b = NULL;
    if (v->type == JARR) {
        sb_append(&b, &len, &cap, "[");
        for (int i = 0; i < v->icount; i++) {
            if (i) sb_append(&b, &len, &cap, ", ");
            char *x = val_plain(v->items[i], v->items[i]->type == JSTR);
            sb_append(&b, &len, &cap, x); free(x);
        }
        sb_append(&b, &len, &cap, "]");
    } else {
        sb_append(&b, &len, &cap, "{");
        for (int i = 0; i < v->count; i++) {
            if (i) sb_append(&b, &len, &cap, ", ");
            sb_append(&b, &len, &cap, v->pairs[i].key);
            sb_append(&b, &len, &cap, ": ");
            char *x = val_plain(v->pairs[i].val, v->pairs[i].val->type == JSTR);
            sb_append(&b, &len, &cap, x); free(x);
        }
        sb_append(&b, &len, &cap, "}");
    }
    return b ? b : xstrdup("");
}

static char *time_norm(const char *s) {
    if (!s) return xstrdup("                   ");
    bool allnum = *s != 0;
    for (const char *p = s; *p; p++) if (!isdigit((unsigned char)*p)) allnum = false;
    if (allnum && strlen(s) >= 10) {
        long long ms = atoll(s);
        time_t sec = (time_t)(strlen(s) > 10 ? ms / 1000 : ms);
        struct tm tmv;
        gmtime_r(&sec, &tmv);
        char out[32];
        strftime(out, sizeof(out), "%Y-%m-%dT%H:%M:%S", &tmv);
        return xstrdup(out);
    }
    char *r = xstrdup(s);
    char *z = strchr(r, 'Z'); if (z) *z = 0;
    char *dot = strchr(r, '.'); if (dot) *dot = 0;
    if (strlen(r) > 19) r[19] = 0;
    return r;
}

static const char *level_color(const char *lvl) {
    if (!lvl) return "\033[1;35m";
    if (!strcasecmp(lvl, "info")) return "\033[1;32m";
    if (!strcasecmp(lvl, "warn")) return "\033[1;33m";
    if (!strcasecmp(lvl, "error") || !strcasecmp(lvl, "err") || !strcasecmp(lvl, "fatal")) return "\033[1;31m";
    if (!strcasecmp(lvl, "debug") || !strcasecmp(lvl, "trace")) return "\033[1;34m";
    return "\033[1;35m";
}

static char *upper_fixed(const char *lvl) {
    char tmp[128];
    if (!lvl || !*lvl) strcpy(tmp, "UNKNOWN"); else snprintf(tmp, sizeof(tmp), "%s", lvl);
    for (char *p = tmp; *p; p++) *p = (char)toupper((unsigned char)*p);
    char out[16];
    if (strlen(tmp) >= 5) snprintf(out, sizeof(out), "%.5s", tmp);
    else snprintf(out, sizeof(out), "%5s", tmp);
    return xstrdup(out);
}

static bool excluded(Opt *o, const char *path) {
    for (int i = 0; i < o->exn; i++) if (!strcmp(o->exclude[i], path)) return true;
    return false;
}

static void print_add_line(const char *key, JVal *v) {
    bool quote = v && (v->type == JARR || (v->type == JSTR && strchr(key, '[')));
    char *value = val_plain(v, quote);
    printf("\033[1m\033[38;2;150;150;150m%25s\033[0m\033[0m: %s\n", key, value);
    free(value);
}

static void flatten_print(Opt *o, const char *path, JVal *v) {
    if (!v || excluded(o, path)) return;
    if (v->type == JOBJ) {
        for (int i = 0; i < v->count; i++) {
            char np[1024];
            snprintf(np, sizeof(np), "%s%s%s", path, *path ? " > " : "", v->pairs[i].key);
            flatten_print(o, np, v->pairs[i].val);
        }
    } else if (v->type == JARR) {
        for (int i = 0; i < v->icount; i++) {
            char np[1024];
            snprintf(np, sizeof(np), "%s[%d]", path, i);
            flatten_print(o, np, v->items[i]);
        }
    } else {
        print_add_line(path, v);
    }
}

static char *substitute_msg(const char *msg, JVal *ctx, const char *fmt) {
    if (!msg || !ctx) return xstrdup(msg ? msg : "");
    const char *pre = "{", *post = "}";
    char *fp = strstr(fmt ? fmt : "{key}", "key");
    char prebuf[64] = "{", postbuf[64] = "}";
    if (fp) {
        size_t pn = (size_t)(fp - fmt);
        snprintf(prebuf, sizeof(prebuf), "%.*s", (int)pn, fmt);
        snprintf(postbuf, sizeof(postbuf), "%s", fp + 3);
        pre = prebuf; post = postbuf;
    }
    size_t len = 0, cap = 0; char *out = NULL;
    const char *p = msg;
    while (*p) {
        const char *a = strstr(p, pre);
        if (!a) { sb_append(&out, &len, &cap, p); break; }
        sb_printf(&out, &len, &cap, "%.*s", (int)(a - p), p);
        const char *k0 = a + strlen(pre);
        const char *b = strstr(k0, post);
        if (!b) { sb_append(&out, &len, &cap, a); break; }
        char key[256];
        snprintf(key, sizeof(key), "%.*s", (int)(b - k0), k0);
        JVal *v = NULL;
        if (ctx->type == JARR && isdigit((unsigned char)key[0])) {
            int idx = atoi(key);
            if (idx >= 0 && idx < ctx->icount) v = ctx->items[idx];
        } else v = path_get(ctx, key);
        if (v) {
            char *plain = val_plain(v, false);
            if (v->type == JSTR) sb_printf(&out, &len, &cap, "\033[1;33m%s\033[0m", plain);
            else if (v->type == JNUM) sb_printf(&out, &len, &cap, "\033[1;36m%s\033[0m", plain);
            else if (v->type == JBOOL) sb_printf(&out, &len, &cap, "\033[1;%dm%s\033[0m", v->b ? 32 : 31, plain);
            else sb_append(&out, &len, &cap, plain);
            free(plain);
        } else {
            sb_printf(&out, &len, &cap, "\033[2m%s\033[0m\033[1;31m%s\033[0m\033[2m%s\033[0m", pre, key, post);
        }
        p = b + strlen(post);
    }
    return out ? out : xstrdup("");
}

static int cmp_value(JVal *v, const char *op, const char *rhs) {
    if (!v) return 0;
    char *val = val_plain(v, false);
    char *r = xstrdup(rhs);
    r = trim(r);
    if ((*r == '"' && r[strlen(r)-1] == '"') || (*r == '\'' && r[strlen(r)-1] == '\'')) {
        r[strlen(r)-1] = 0; r++;
    }
    int ok = 0;
    if (!strcmp(op, "==")) ok = !strcmp(val, r);
    else if (!strcmp(op, "~=") || !strcmp(op, "!=")) ok = strcmp(val, r) != 0;
    else {
        double a = v->type == JNUM ? v->n : atof(val), b = atof(r);
        if (!strcmp(op, ">")) ok = a > b;
        else if (!strcmp(op, "<")) ok = a < b;
        else if (!strcmp(op, ">=")) ok = a >= b;
        else if (!strcmp(op, "<=")) ok = a <= b;
    }
    free(val);
    return ok;
}

static JVal *filter_value(Opt *o, JVal *root, const char *lhs) {
    JVal *v = path_get(root, lhs);
    if (v) return v;
    if (!strcmp(lhs, "level") || !strcmp(lhs, "fblog_level")) return find_first(root, o->level_keys, o->leveln);
    if (!strcmp(lhs, "message") || !strcmp(lhs, "fblog_message")) return find_first(root, o->msg_keys, o->msgn);
    if (!strcmp(lhs, "timestamp") || !strcmp(lhs, "time") || !strcmp(lhs, "fblog_timestamp")) return find_first(root, o->time_keys, o->timen);
    return NULL;
}

static bool apply_filter(Opt *o, JVal *root) {
    if (!o->filter) return true;
    char *f = xstrdup(o->filter);
    char *ops[] = {"==", "~=", "!=", ">=", "<=", ">", "<", NULL};
    for (int i = 0; ops[i]; i++) {
        char *p = strstr(f, ops[i]);
        if (p) {
            *p = 0;
            char *lhs = trim(f), *rhs = trim(p + strlen(ops[i]));
            JVal *v = filter_value(o, root, lhs);
            bool ok = cmp_value(v, ops[i], rhs);
            free(f);
            return ok;
        }
    }
    free(f);
    return true;
}

static void process_line(Opt *o, char *line) {
    char *orig = line;
    size_t ln = strlen(line);
    while (ln && (line[ln-1] == '\n' || line[ln-1] == '\r')) line[--ln] = 0;
    char *json = line, *prefix = NULL;
    if (o->with_prefix) {
        char *b = strchr(line, '{');
        if (b && b != line) {
            prefix = strndup(line, (size_t)(b - line));
            char *pt = trim(prefix);
            if (pt != prefix) memmove(prefix, pt, strlen(pt) + 1);
            json = b;
        }
    }
    JVal *root = json_parse(json);
    if (!root || root->type != JOBJ) {
        printf("\033[1;38;2;255;135;22m??? >\033[0m %s\n", orig);
        jfree(root); free(prefix); return;
    }
    if (!apply_filter(o, root)) { jfree(root); free(prefix); return; }
    JVal *mv = find_first(root, o->msg_keys, o->msgn);
    JVal *tv = find_first(root, o->time_keys, o->timen);
    JVal *lv = find_first(root, o->level_keys, o->leveln);
    char *msg = val_plain(mv, false);
    char *time_s = val_plain(tv, false);
    char *lvl = val_plain(lv, false);
    for (int i = 0; i < o->mapn; i++) if (!strcasecmp(lvl, o->map_from[i])) { free(lvl); lvl = xstrdup(o->map_to[i]); break; }
    if (o->substitute && mv && mv->type == JSTR) {
        JVal *ctx = find_first(root, o->ctx_keys, o->ctxn);
        char *sm = substitute_msg(mv->s, ctx, o->placeholder);
        free(msg); msg = sm;
    }
    char *tn = time_norm(tv ? time_s : NULL);
    char *lf = upper_fixed(lv ? lvl : NULL);
    printf("\033[1m%-19.19s\033[0m %s%s\033[0m:", tn, level_color(lv ? lvl : NULL), lf);
    if (prefix && *prefix) printf(" \033[1m\033[36m%s\033[0m\033[0m", prefix);
    printf(" %s\n", msg);
    if (o->dump_all) {
        for (int i = 0; i < root->count; i++) flatten_print(o, root->pairs[i].key, root->pairs[i].val);
    }
    for (int i = 0; i < o->addn; i++) {
        JVal *v = path_get(root, o->add[i]);
        if (v) flatten_print(o, o->add[i], v);
    }
    free(msg); free(time_s); free(lvl); free(tn); free(lf); free(prefix); jfree(root);
}

static void usage(void) {
    puts("json log viewer\n\nUsage: executable [OPTIONS] [INPUT]\n\nArguments:\n  [INPUT]  Sets the input file to use, otherwise assumes stdin [default: -]\n\nOptions:\n  -a, --additional-value <additional-value>\n          adds additional values\n      --config-file <config-file>\n          configuration file to load\n  -m, --message-key <message-key>\n          Adds an additional key to detect the message in the log entry. The first matching key will be assigned to `fblog_message`.\n      --print-lua\n          Prints lua init expressions. Used for fblog debugging.\n  -t, --time-key <time-key>\n          Adds an additional key to detect the time in the log entry. The first matching key will be assigned to `fblog_timestamp`.\n  -l, --level-key <level-key>\n          Adds an additional key to detect the level in the log entry. The first matching key will be assigned to `fblog_level`.\n      --map-level <from=to>\n          Rewrite the log level from one value to another.\n  -d, --dump-all\n          dumps all values\n  -x, --excluded-value <excluded-value>\n          Excludes values (--dump-all is enabled implicitly)\n  -p, --with-prefix\n          consider all text before opening curly brace as prefix\n  -f, --filter <filter>\n          lua expression to filter log entries. `message ~= nil and string.find(message, \"text.*\") ~= nil`\n      --no-implicit-filter-return-statement\n          if you pass a filter expression 'return' is automatically prepended. Pass this switch to disable the implicit return.\n      --main-line-format <main-line-format>\n          Formats the main fblog output. All log values can be used. fblog provides sanitized variables starting with `fblog_`.\n      --additional-value-format <additional-value-format>\n          Formats the additional value fblog output.\n  -s, --substitute\n          Enable substitution of placeholders in the log messages with their corresponding values from the context.\n  -c, --context-key <context-key>\n          Use this key as the source of substitutions for the message. Value can either be an array ({1}) or an object ({key}).\n  -F, --placeholder-format <placeholder-format>\n          The format that should be used for substituting values in the message, where the key is the literal word `key`. Example: [[key]] or ${key}.\n  -h, --help\n          Print help\n  -V, --version\n          Print version");
}

static void defaults(Opt *o) {
    memset(o, 0, sizeof(*o));
    add_str(&o->msg_keys, &o->msgn, "short_message");
    add_str(&o->msg_keys, &o->msgn, "msg");
    add_str(&o->msg_keys, &o->msgn, "message");
    add_str(&o->time_keys, &o->timen, "timestamp");
    add_str(&o->time_keys, &o->timen, "time");
    add_str(&o->time_keys, &o->timen, "@timestamp");
    add_str(&o->level_keys, &o->leveln, "level");
    add_str(&o->level_keys, &o->leveln, "severity");
    add_str(&o->level_keys, &o->leveln, "log.level");
    add_str(&o->level_keys, &o->leveln, "loglevel");
    add_str(&o->ctx_keys, &o->ctxn, "context");
    o->input = "-";
    o->placeholder = xstrdup("{key}");
}

static void parse_config(Opt *o, const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) return;
    char *line = NULL; size_t cap = 0;
    while (getline(&line, &cap, f) > 0) {
        char *s = trim(line);
        if (!strncmp(s, "message_keys", 12) || !strncmp(s, "time_keys", 9) || !strncmp(s, "level_keys", 10)) {
            char ***arr = NULL; int *n = NULL;
            if (!strncmp(s, "message_keys", 12)) { arr = &o->msg_keys; n = &o->msgn; }
            else if (!strncmp(s, "time_keys", 9)) { arr = &o->time_keys; n = &o->timen; }
            else { arr = &o->level_keys; n = &o->leveln; }
            char *lb = strchr(s, '['), *rb = strrchr(s, ']');
            if (lb && rb) {
                for (char *p = lb; p < rb; p++) if (*p == '"') {
                    char *q = strchr(p + 1, '"'); if (!q || q > rb) break;
                    char old = *q; *q = 0; add_str(arr, n, p + 1); *q = old; p = q;
                }
            }
        }
    }
    free(line); fclose(f);
}

int main(int argc, char **argv) {
    Opt o; defaults(&o);
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage(); return 0; }
        else if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("fblog 4.17.0"); return 0; }
        else if (!strcmp(a, "--print-lua")) o.print_lua = true;
        else if (!strcmp(a, "-d") || !strcmp(a, "--dump-all")) o.dump_all = true;
        else if (!strcmp(a, "-p") || !strcmp(a, "--with-prefix")) o.with_prefix = true;
        else if (!strcmp(a, "-s") || !strcmp(a, "--substitute")) o.substitute = true;
        else if (!strcmp(a, "--no-implicit-filter-return-statement")) o.no_return = true;
        else if ((!strcmp(a, "-a") || !strcmp(a, "--additional-value")) && i + 1 < argc) add_str(&o.add, &o.addn, argv[++i]);
        else if ((!strcmp(a, "-x") || !strcmp(a, "--excluded-value")) && i + 1 < argc) { add_str(&o.exclude, &o.exn, argv[++i]); o.dump_all = true; }
        else if ((!strcmp(a, "-m") || !strcmp(a, "--message-key")) && i + 1 < argc) add_str(&o.msg_keys, &o.msgn, argv[++i]);
        else if ((!strcmp(a, "-t") || !strcmp(a, "--time-key")) && i + 1 < argc) add_str(&o.time_keys, &o.timen, argv[++i]);
        else if ((!strcmp(a, "-l") || !strcmp(a, "--level-key")) && i + 1 < argc) add_str(&o.level_keys, &o.leveln, argv[++i]);
        else if ((!strcmp(a, "-c") || !strcmp(a, "--context-key")) && i + 1 < argc) add_str(&o.ctx_keys, &o.ctxn, argv[++i]);
        else if ((!strcmp(a, "-F") || !strcmp(a, "--placeholder-format")) && i + 1 < argc) { free(o.placeholder); o.placeholder = xstrdup(argv[++i]); }
        else if ((!strcmp(a, "-f") || !strcmp(a, "--filter")) && i + 1 < argc) o.filter = xstrdup(argv[++i]);
        else if (!strcmp(a, "--config-file") && i + 1 < argc) parse_config(&o, argv[++i]);
        else if (!strcmp(a, "--map-level") && i + 1 < argc) {
            char *m = xstrdup(argv[++i]), *eq = strchr(m, '=');
            if (eq) { *eq = 0; add_str(&o.map_from, &o.mapn, m); o.map_to = realloc(o.map_to, sizeof(char*) * o.mapn); o.map_to[o.mapn - 1] = xstrdup(eq + 1); }
            free(m);
        } else if (!strcmp(a, "--main-line-format") && i + 1 < argc) o.main_fmt = xstrdup(argv[++i]);
        else if (!strcmp(a, "--additional-value-format") && i + 1 < argc) o.add_fmt = xstrdup(argv[++i]);
        else o.input = a;
    }
    if (o.print_lua) return 0;
    FILE *f = !strcmp(o.input, "-") ? stdin : fopen(o.input, "r");
    if (!f) { fprintf(stderr, "Error: %s: %s\n", o.input, strerror(errno)); return 1; }
    char *line = NULL; size_t cap = 0;
    while (getline(&line, &cap, f) > 0) process_line(&o, line);
    free(line);
    if (f != stdin) fclose(f);
    return 0;
}
