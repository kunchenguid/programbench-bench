#define _XOPEN_SOURCE 700
#include <zlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <utime.h>

typedef unsigned char uchar;

typedef struct {
    int decompress, stdout_flag, force, keep, test, list, verbose, quiet;
    int zlib_fmt, zip_fmt, no_name, name, no_time, time_flag;
    int recursive, level, strategy;
    char *suffix, *comment, *alias;
} Opt;

static const char *prog = "executable";
static int exit_code = 0;

static char *xstrndup(const char *s, size_t n) {
    char *r = malloc(n + 1);
    if (!r) return NULL;
    memcpy(r, s, n);
    r[n] = 0;
    return r;
}

static void put16(uchar *p, uint16_t v){ p[0]=v&255; p[1]=(v>>8)&255; }
static void put32(uchar *p, uint32_t v){ p[0]=v&255; p[1]=(v>>8)&255; p[2]=(v>>16)&255; p[3]=(v>>24)&255; }

static void help(void) {
    puts("Usage: pigz [options] [files ...]\n"
"  will compress files in place, adding the suffix '.gz'. If no files are\n"
"  specified, stdin will be compressed to stdout. pigz does what gzip does,\n"
"  but spreads the work over multiple processors and cores when compressing.\n\n"
"Options:\n"
"  -0 to -9, -11        Compression level (level 11, zopfli, is much slower)\n"
"  --fast, --best       Compression levels 1 and 9 respectively\n"
"  -A, --alias xxx      Use xxx as the name for any --zip entry from stdin\n"
"  -b, --blocksize mmm  Set compression block size to mmmK (default 128K)\n"
"  -c, --stdout         Write all processed output to stdout (won't delete)\n"
"  -C, --comment ccc    Put comment ccc in the gzip or zip header\n"
"  -d, --decompress     Decompress the compressed input\n"
"  -f, --force          Force overwrite, compress .gz, links, and to terminal\n"
"  -F  --first          Do iterations first, before block split for -11\n"
"  -h, --help           Display a help screen and quit\n"
"  -H, --huffman        Use only Huffman coding for compression\n"
"  -i, --independent    Compress blocks independently for damage recovery\n"
"  -I, --iterations n   Number of iterations for -11 optimization\n"
"  -J, --maxsplits n    Maximum number of split blocks for -11\n"
"  -k, --keep           Do not delete original file after processing\n"
"  -K, --zip            Compress to PKWare zip (.zip) single entry format\n"
"  -l, --list           List the contents of the compressed input\n"
"  -L, --license        Display the pigz license and quit\n"
"  -m, --no-time        Do not store or restore mod time\n"
"  -M, --time           Store or restore mod time\n"
"  -n, --no-name        Do not store or restore file name or mod time\n"
"  -N, --name           Store or restore file name and mod time\n"
"  -O  --oneblock       Do not split into smaller blocks for -11\n"
"  -p, --processes n    Allow up to n compression threads (default is the\n"
"                       number of online processors, or 8 if unknown)\n"
"  -q, --quiet          Print no messages, even on error\n"
"  -r, --recursive      Process the contents of all subdirectories\n"
"  -R, --rsyncable      Input-determined block locations for rsync\n"
"  -S, --suffix .sss    Use suffix .sss instead of .gz (for compression)\n"
"  -t, --test           Test the integrity of the compressed input\n"
"  -U, --rle            Use run-length encoding for compression\n"
"  -v, --verbose        Provide more verbose output\n"
"  -V  --version        Show the version of pigz\n"
"  -Y  --synchronous    Force output file write to permanent storage\n"
"  -z, --zlib           Compress to zlib (.zz) instead of gzip format\n"
"  --                   All arguments after \"--\" are treated as files");
}

static void license(void) {
    puts("pigz 2.8\nCopyright (C) 2007-2023 Mark Adler\nSubject to the terms of the zlib license.\nNo warranty is provided or implied.");
}

static void msg(const Opt *o, const char *fmt, ...) {
    if (o->quiet) return;
    va_list ap; va_start(ap, fmt);
    fprintf(stderr, "%s: ", prog);
    vfprintf(stderr, fmt, ap);
    fputc('\n', stderr);
    va_end(ap);
}

static int read_all(FILE *f, uchar **out, size_t *len) {
    size_t cap = 65536, n = 0;
    uchar *buf = malloc(cap);
    if (!buf) return -1;
    for (;;) {
        if (n == cap) {
            cap *= 2;
            uchar *nb = realloc(buf, cap);
            if (!nb) { free(buf); return -1; }
            buf = nb;
        }
        size_t got = fread(buf + n, 1, cap - n, f);
        n += got;
        if (got == 0) {
            if (ferror(f)) { free(buf); return -1; }
            break;
        }
    }
    *out = buf; *len = n; return 0;
}

static int write_all(FILE *f, const uchar *p, size_t n) {
    return fwrite(p, 1, n, f) == n ? 0 : -1;
}

static const char *base_name(const char *s) {
    const char *p = strrchr(s, '/');
    return p ? p + 1 : s;
}

static char *strip_suffix(const char *name, const char *suf) {
    size_t n = strlen(name), s = strlen(suf);
    if (s && n > s && strcmp(name + n - s, suf) == 0) {
        char *r = malloc(n - s + 1);
        memcpy(r, name, n - s); r[n - s] = 0; return r;
    }
    if (n > 3 && strcmp(name + n - 3, ".gz") == 0) {
        char *r = malloc(n - 2); memcpy(r, name, n - 3); r[n - 3] = 0; return r;
    }
    if (n > 3 && strcmp(name + n - 3, ".zz") == 0) {
        char *r = malloc(n - 2); memcpy(r, name, n - 3); r[n - 3] = 0; return r;
    }
    if (n > 4 && strcmp(name + n - 4, ".zip") == 0) {
        char *r = malloc(n - 3); memcpy(r, name, n - 4); r[n - 4] = 0; return r;
    }
    return NULL;
}

static char *add_suffix(const char *name, const char *suf) {
    size_t n = strlen(name), s = strlen(suf);
    char *r = malloc(n + s + 1);
    memcpy(r, name, n); memcpy(r+n, suf, s+1); return r;
}

static int deflate_mem(const uchar *in, size_t inlen, int level, int strategy, int window, uchar **out, size_t *outlen) {
    z_stream z; memset(&z, 0, sizeof(z));
    if (deflateInit2(&z, level, Z_DEFLATED, window, 8, strategy) != Z_OK) return -1;
    size_t cap = deflateBound(&z, inlen) + 64;
    uchar *buf = malloc(cap);
    if (!buf) { deflateEnd(&z); return -1; }
    z.next_in = (Bytef *)in; z.avail_in = (uInt)inlen;
    z.next_out = buf; z.avail_out = (uInt)cap;
    int ret = deflate(&z, Z_FINISH);
    if (ret != Z_STREAM_END) { free(buf); deflateEnd(&z); return -1; }
    *outlen = z.total_out; *out = buf;
    deflateEnd(&z); return 0;
}

static int inflate_mem_window(const uchar *in, size_t inlen, int window, uchar **out, size_t *outlen) {
    z_stream z; memset(&z, 0, sizeof(z));
    if (inflateInit2(&z, window) != Z_OK) return -1;
    size_t cap = inlen ? inlen * 3 + 1024 : 1024, n = 0;
    uchar *buf = malloc(cap);
    if (!buf) { inflateEnd(&z); return -1; }
    z.next_in = (Bytef *)in; z.avail_in = (uInt)inlen;
    for (;;) {
        if (n == cap) {
            cap *= 2;
            uchar *nb = realloc(buf, cap);
            if (!nb) { free(buf); inflateEnd(&z); return -1; }
            buf = nb;
        }
        z.next_out = buf + n; z.avail_out = (uInt)(cap - n);
        int ret = inflate(&z, Z_NO_FLUSH);
        n = z.total_out;
        if (ret == Z_STREAM_END) break;
        if (ret != Z_OK) { free(buf); inflateEnd(&z); return -1; }
        if (z.avail_out != 0 && z.avail_in == 0) { free(buf); inflateEnd(&z); return -1; }
    }
    *out = buf; *outlen = n; inflateEnd(&z); return 0;
}

static int gzip_name(const uchar *in, size_t len, char **name, uint32_t *mtime) {
    *name = NULL; *mtime = 0;
    if (len < 10 || in[0] != 0x1f || in[1] != 0x8b) return -1;
    int flg = in[3]; *mtime = (uint32_t)in[4] | ((uint32_t)in[5]<<8) | ((uint32_t)in[6]<<16) | ((uint32_t)in[7]<<24);
    size_t p = 10;
    if (flg & 4) { if (p + 2 > len) return -1; unsigned x = in[p] | (in[p+1]<<8); p += 2 + x; }
    if ((flg & 8) && p < len) {
        size_t s = p; while (p < len && in[p]) p++;
        if (p < len) { *name = xstrndup((const char *)in+s, p-s); p++; }
    }
    return 0;
}

static int zip_extract(const uchar *in, size_t len, uchar **out, size_t *outlen, char **name) {
    if (len < 30 || memcmp(in, "PK\003\004", 4)) return -1;
    uint16_t method = in[8] | (in[9]<<8), nlen = in[26] | (in[27]<<8), xlen = in[28] | (in[29]<<8);
    uint32_t csize = (uint32_t)in[18] | ((uint32_t)in[19]<<8) | ((uint32_t)in[20]<<16) | ((uint32_t)in[21]<<24);
    if (30u + nlen + xlen > len) return -1;
    if (name) *name = xstrndup((const char *)in + 30, nlen);
    const uchar *data = in + 30 + nlen + xlen;
    if (csize == 0xffffffffu || csize == 0) csize = (uint32_t)(len - (data - in));
    if ((size_t)(data - in) + csize > len) csize = (uint32_t)(len - (data - in));
    if (method == 0) {
        uchar *buf = malloc(csize ? csize : 1); if (!buf) return -1;
        memcpy(buf, data, csize); *out = buf; *outlen = csize; return 0;
    }
    if (method != 8) return -1;
    return inflate_mem_window(data, csize, -15, out, outlen);
}

static int make_gzip(const Opt *o, const uchar *in, size_t inlen, const char *name, time_t mt, uchar **out, size_t *outlen) {
    uchar *def; size_t deflen;
    if (deflate_mem(in, inlen, o->level == 11 ? 9 : o->level, o->strategy, -15, &def, &deflen)) return -1;
    const char *bn = (name && !o->no_name) ? base_name(name) : NULL;
    size_t nlen = bn ? strlen(bn) + 1 : 0, clen = o->comment ? strlen(o->comment) + 1 : 0;
    size_t total = 10 + nlen + clen + deflen + 8;
    uchar *buf = malloc(total); if (!buf) { free(def); return -1; }
    size_t p = 0; buf[p++]=0x1f; buf[p++]=0x8b; buf[p++]=8; buf[p++]=(bn?8:0)|(o->comment?16:0);
    uint32_t m = (!o->no_time && name) ? (uint32_t)mt : 0; put32(buf+p,m); p+=4;
    buf[p++] = o->level == 9 ? 2 : (o->level == 1 ? 4 : 0); buf[p++] = 3;
    if (bn) { memcpy(buf+p,bn,nlen); p+=nlen; }
    if (o->comment) { memcpy(buf+p,o->comment,clen); p+=clen; }
    memcpy(buf+p,def,deflen); p+=deflen; free(def);
    put32(buf+p, crc32(0L, in, inlen)); p+=4; put32(buf+p, (uint32_t)inlen); p+=4;
    *out=buf; *outlen=p; return 0;
}

static int make_zlib(const Opt *o, const uchar *in, size_t inlen, uchar **out, size_t *outlen) {
    return deflate_mem(in, inlen, o->level == 11 ? 9 : o->level, o->strategy, 15, out, outlen);
}

static int make_zip(const Opt *o, const uchar *in, size_t inlen, const char *name, time_t mt, uchar **out, size_t *outlen) {
    uchar *def; size_t deflen;
    if (deflate_mem(in, inlen, o->level == 11 ? 9 : o->level, o->strategy, -15, &def, &deflen)) return -1;
    const char *bn = name ? base_name(name) : (o->alias ? o->alias : "-");
    uint16_t nlen = (uint16_t)strlen(bn), clen = o->comment ? (uint16_t)strlen(o->comment) : 0;
    size_t local = 30 + nlen, central = 46 + nlen + clen, total = local + deflen + central + 22 + clen;
    uchar *buf = calloc(1, total); if (!buf) { free(def); return -1; }
    uint32_t crc = crc32(0L, in, inlen); size_t p = 0;
    time_t tt = mt ? mt : time(NULL); struct tm *tm = localtime(&tt);
    uint16_t dost = tm ? (uint16_t)((tm->tm_hour<<11)|(tm->tm_min<<5)|(tm->tm_sec/2)) : 0;
    uint16_t dosd = tm ? (uint16_t)(((tm->tm_year-80)<<9)|((tm->tm_mon+1)<<5)|tm->tm_mday) : 0;
    memcpy(buf+p,"PK\003\004",4); p+=4; put16(buf+p,20); p+=2; put16(buf+p,0); p+=2; put16(buf+p,8); p+=2;
    put16(buf+p,dost); p+=2; put16(buf+p,dosd); p+=2; put32(buf+p,crc); p+=4; put32(buf+p,(uint32_t)deflen); p+=4; put32(buf+p,(uint32_t)inlen); p+=4;
    put16(buf+p,nlen); p+=2; put16(buf+p,0); p+=2; memcpy(buf+p,bn,nlen); p+=nlen; memcpy(buf+p,def,deflen); p+=deflen;
    size_t coff = p; memcpy(buf+p,"PK\001\002",4); p+=4; put16(buf+p,45); p+=2; put16(buf+p,20); p+=2; put16(buf+p,0); p+=2; put16(buf+p,8); p+=2;
    put16(buf+p,dost); p+=2; put16(buf+p,dosd); p+=2; put32(buf+p,crc); p+=4; put32(buf+p,(uint32_t)deflen); p+=4; put32(buf+p,(uint32_t)inlen); p+=4;
    put16(buf+p,nlen); p+=2; put16(buf+p,0); p+=2; put16(buf+p,clen); p+=2; p+=8; put32(buf+p,0); p+=4; memcpy(buf+p,bn,nlen); p+=nlen;
    if (clen) { memcpy(buf+p,o->comment,clen); p+=clen; }
    memcpy(buf+p,"PK\005\006",4); p+=4; p+=4; put16(buf+p,1); p+=2; put16(buf+p,1); p+=2; put32(buf+p,(uint32_t)central); p+=4; put32(buf+p,(uint32_t)coff); p+=4; put16(buf+p,clen); p+=2;
    if (clen) { memcpy(buf+p,o->comment,clen); p+=clen; }
    free(def); *out=buf; *outlen=p; return 0;
}

static int do_decompress_buf(const uchar *in, size_t inlen, uchar **out, size_t *outlen, char **hname, uint32_t *mtime) {
    if (hname) *hname = NULL;
    if (mtime) *mtime = 0;
    if (inlen >= 4 && !memcmp(in, "PK\003\004", 4)) return zip_extract(in, inlen, out, outlen, hname);
    if (hname && mtime) gzip_name(in, inlen, hname, mtime);
    return inflate_mem_window(in, inlen, 15 + 32, out, outlen);
}

static FILE *open_out(const Opt *o, const char *path) {
    if (!o->force && access(path, F_OK) == 0) {
        msg(o, "skipping: %s exists", path); exit_code = 1; return NULL;
    }
    FILE *f = fopen(path, "wb");
    if (!f) { msg(o, "write error on %s: %s", path, strerror(errno)); exit_code = 1; }
    return f;
}

static int process_one(const Opt *o, const char *path);

static int process_dir(const Opt *o, const char *path) {
    DIR *d = opendir(path);
    if (!d) { msg(o, "skipping: %s is a directory", path); return -1; }
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name,".") || !strcmp(e->d_name,"..")) continue;
        char *p = malloc(strlen(path)+strlen(e->d_name)+2);
        sprintf(p, "%s/%s", path, e->d_name);
        process_one(o, p); free(p);
    }
    closedir(d); return 0;
}

static int compress_path(const Opt *o, const char *path) {
    struct stat st; FILE *infile = stdin; const char *name = NULL; time_t mt = 0;
    if (path && strcmp(path,"-")) {
        if (stat(path, &st)) { msg(o, "skipping: %s does not exist", path); exit_code = 1; return -1; }
        if (S_ISDIR(st.st_mode)) return o->recursive ? process_dir(o, path) : (msg(o, "skipping: %s is a directory", path), -1);
        if (!o->force && !o->zlib_fmt && !o->zip_fmt) {
            size_t n=strlen(path), s=strlen(o->suffix);
            if (n > s && !strcmp(path+n-s, o->suffix)) { msg(o, "skipping: %s ends with %s", path, o->suffix); return 0; }
        }
        infile = fopen(path, "rb"); if (!infile) { msg(o, "skipping: %s does not exist", path); exit_code=1; return -1; }
        name = path; mt = st.st_mtime;
    }
    uchar *in, *out; size_t inlen, outlen;
    if (read_all(infile, &in, &inlen)) { msg(o, "read error"); if (infile!=stdin) fclose(infile); return -1; }
    if (infile != stdin) fclose(infile);
    int ret = o->zip_fmt ? make_zip(o,in,inlen,name,mt,&out,&outlen) : (o->zlib_fmt ? make_zlib(o,in,inlen,&out,&outlen) : make_gzip(o,in,inlen,name,mt,&out,&outlen));
    free(in); if (ret) { msg(o, "compression failed"); return -1; }
    FILE *of = stdout; char *oname = NULL;
    if (!o->stdout_flag && path && strcmp(path,"-")) {
        oname = add_suffix(path, o->zip_fmt ? ".zip" : (o->zlib_fmt ? ".zz" : o->suffix));
        of = open_out(o, oname); if (!of) { free(oname); free(out); return -1; }
    }
    ret = write_all(of, out, outlen); free(out);
    if (of != stdout) {
        fclose(of); chmod(oname, st.st_mode & 0777);
        struct utimbuf ut = { st.st_atime, st.st_mtime }; utime(oname, &ut);
        if (!o->keep && path && strcmp(path,"-")) unlink(path);
        free(oname);
    }
    if (ret) { msg(o, "write error"); return -1; }
    return 0;
}

static int decompress_path(const Opt *o, const char *path) {
    struct stat st; FILE *infile = stdin; int have_file = path && strcmp(path,"-");
    if (have_file) {
        if (stat(path, &st)) { msg(o, "skipping: %s does not exist", path); exit_code=1; return -1; }
        if (S_ISDIR(st.st_mode)) return o->recursive ? process_dir(o, path) : (msg(o, "skipping: %s is a directory", path), -1);
        infile = fopen(path, "rb"); if (!infile) { msg(o, "skipping: %s does not exist", path); exit_code=1; return -1; }
    }
    uchar *in,*out; size_t inlen,outlen; char *hname=NULL; uint32_t mt=0;
    if (read_all(infile,&in,&inlen)) { msg(o,"read error"); if(have_file)fclose(infile); return -1; }
    if (have_file) fclose(infile);
    if (do_decompress_buf(in,inlen,&out,&outlen,&hname,&mt)) { msg(o, "corrupt input"); free(in); free(hname); exit_code=1; return -1; }
    free(in);
    if (o->test) { free(out); free(hname); return 0; }
    FILE *of = stdout; char *oname = NULL;
    if (!o->stdout_flag && have_file) {
        if (o->name && hname && *hname) oname = strdup(hname); else oname = strip_suffix(path, o->suffix);
        if (!oname) { msg(o, "skipping: %s unknown suffix -- ignored", path); free(out); free(hname); return -1; }
        of = open_out(o, oname); if (!of) { free(out); free(hname); free(oname); return -1; }
    }
    int ret = write_all(of,out,outlen); free(out);
    if (of != stdout) {
        fclose(of); chmod(oname, st.st_mode & 0777);
        struct utimbuf ut = { st.st_atime, (o->time_flag && mt) ? (time_t)mt : st.st_mtime }; utime(oname,&ut);
        if (!o->keep) unlink(path);
        free(oname);
    }
    free(hname); if (ret) { msg(o,"write error"); return -1; } return 0;
}

static int list_path(const Opt *o, const char *path) {
    FILE *f = (path && strcmp(path,"-")) ? fopen(path,"rb") : stdin;
    if (!f) { msg(o, "skipping: %s does not exist", path); exit_code=1; return -1; }
    uchar *in,*out; size_t inlen,outlen; char *hname=NULL; uint32_t mt=0;
    if (read_all(f,&in,&inlen)) return -1;
    if (f!=stdin) fclose(f);
    int ok = do_decompress_buf(in,inlen,&out,&outlen,&hname,&mt);
    if (ok) { msg(o,"corrupt input"); free(in); return -1; }
    uint32_t crc = crc32(0L,out,outlen); (void)crc;
    const char *nm = hname && *hname ? hname : (path ? base_name(path) : "-");
    if (!o->verbose) {
        printf("compressed   original reduced  name\n%10lu %10lu ", (unsigned long)(inlen > 18 ? inlen - 24 : inlen), (unsigned long)outlen);
        if (outlen) printf("%5.1f%%  %s\n", 100.0*(1.0-(double)(inlen>18?inlen-24:inlen)/(double)outlen), nm); else printf(" unk    %s\n", nm);
    } else {
        char tb[32]=""; if (mt) { time_t tt = (time_t)mt; strftime(tb,sizeof(tb),"%b %d %H:%M",localtime(&tt)); }
        printf("method    check    timestamp    compressed   original reduced  name\n");
        printf("gzip 8  %08lx  %s  %10lu %10lu ", (unsigned long)crc, mt?tb:"", (unsigned long)(inlen > 18 ? inlen - 24 : inlen), (unsigned long)outlen);
        if (outlen) printf("%5.1f%%  %s\n", 100.0*(1.0-(double)(inlen>18?inlen-24:inlen)/(double)outlen), nm); else printf(" unk    %s\n", nm);
    }
    free(in); free(out); free(hname); return 0;
}

static int process_one(const Opt *o, const char *path) {
    if (o->list) return list_path(o,path);
    if (o->decompress || o->test) return decompress_path(o,path);
    return compress_path(o,path);
}

static void need_arg(int *i, int argc, char **argv, char **dst, const Opt *o, const char *opt) {
    if (*i + 1 >= argc) { msg(o, "abort: %s missing argument", opt); exit(1); }
    *dst = argv[++*i];
}

static int parse_one(Opt *o, int *i, int argc, char **argv) {
    char *a = argv[*i];
    if (!strcmp(a,"--")) return 1;
    if (a[0] != '-' || !a[1]) return 1;
    if (!strcmp(a,"--help")) { help(); exit(0); }
    if (!strcmp(a,"--version")) { puts("pigz 2.8"); exit(0); }
    if (!strcmp(a,"--license")) { license(); exit(0); }
    if (!strcmp(a,"--fast")) { o->level=1; return 0; }
    if (!strcmp(a,"--best")) { o->level=9; return 0; }
    if (!strcmp(a,"--stdout") || !strcmp(a,"--to-stdout")) { o->stdout_flag=1; return 0; }
    if (!strcmp(a,"--decompress") || !strcmp(a,"--uncompress")) { o->decompress=1; return 0; }
    if (!strcmp(a,"--force")) { o->force=1; return 0; }
    if (!strcmp(a,"--keep")) { o->keep=1; return 0; }
    if (!strcmp(a,"--zip")) { o->zip_fmt=1; return 0; }
    if (!strcmp(a,"--zlib")) { o->zlib_fmt=1; return 0; }
    if (!strcmp(a,"--list")) { o->list=1; return 0; }
    if (!strcmp(a,"--test")) { o->test=1; return 0; }
    if (!strcmp(a,"--verbose")) { o->verbose++; return 0; }
    if (!strcmp(a,"--quiet") || !strcmp(a,"--silent")) { o->quiet=1; return 0; }
    if (!strcmp(a,"--recursive")) { o->recursive=1; return 0; }
    if (!strcmp(a,"--no-name")) { o->no_name=1; o->no_time=1; o->name=0; o->time_flag=0; return 0; }
    if (!strcmp(a,"--name")) { o->name=1; o->time_flag=1; o->no_name=0; o->no_time=0; return 0; }
    if (!strcmp(a,"--no-time")) { o->no_time=1; o->time_flag=0; return 0; }
    if (!strcmp(a,"--time")) { o->time_flag=1; o->no_time=0; return 0; }
    if (!strcmp(a,"--huffman")) { o->strategy=Z_HUFFMAN_ONLY; return 0; }
    if (!strcmp(a,"--rle")) { o->strategy=Z_RLE; return 0; }
    if (!strcmp(a,"--suffix")) { need_arg(i,argc,argv,&o->suffix,o,"--suffix"); return 0; }
    if (!strcmp(a,"--comment")) { need_arg(i,argc,argv,&o->comment,o,"--comment"); return 0; }
    if (!strcmp(a,"--alias")) { need_arg(i,argc,argv,&o->alias,o,"--alias"); return 0; }
    if (a[0]=='-' && a[1]=='-') { msg(o, "abort: invalid option: %s", a); exit(1); }
    for (int j=1; a[j]; j++) {
        char c=a[j];
        if (c=='1' && a[j+1]=='1') { o->level=11; j++; continue; }
        if (c>='0' && c<='9') { o->level=c-'0'; continue; }
        switch(c) {
            case 'h': help(); exit(0);
            case 'V': if (o->verbose) { puts("pigz 2.8"); printf("zlib %s\n", zlibVersion()); } else puts("pigz 2.8"); exit(0);
            case 'L': license(); exit(0);
            case 'c': o->stdout_flag=1; break; case 'd': o->decompress=1; break; case 'f': o->force=1; break; case 'k': o->keep=1; break;
            case 'K': o->zip_fmt=1; break; case 'z': o->zlib_fmt=1; break; case 'l': o->list=1; break; case 't': o->test=1; break;
            case 'v': o->verbose++; break; case 'q': o->quiet=1; break; case 'r': o->recursive=1; break;
            case 'n': o->no_name=1; o->no_time=1; o->name=0; o->time_flag=0; break;
            case 'N': o->name=1; o->time_flag=1; o->no_name=0; o->no_time=0; break;
            case 'm': o->no_time=1; o->time_flag=0; break; case 'M': o->time_flag=1; o->no_time=0; break;
            case 'H': o->strategy=Z_HUFFMAN_ONLY; break; case 'U': o->strategy=Z_RLE; break;
            case 'S': if (a[j+1]) { o->suffix=&a[j+1]; j=(int)strlen(a)-1; } else need_arg(i,argc,argv,&o->suffix,o,"-S"); break;
            case 'C': if (a[j+1]) { o->comment=&a[j+1]; j=(int)strlen(a)-1; } else need_arg(i,argc,argv,&o->comment,o,"-C"); break;
            case 'A': if (a[j+1]) { o->alias=&a[j+1]; j=(int)strlen(a)-1; } else need_arg(i,argc,argv,&o->alias,o,"-A"); break;
            case 'p': case 'b': case 'I': case 'J': if (!a[j+1]) (*i)++; j=(int)strlen(a)-1; break;
            case 'i': case 'R': case 'Y': case 'F': case 'O': break;
            default: msg(o, "abort: invalid option: -%c", c); exit(1);
        }
    }
    return 0;
}

int main(int argc, char **argv) {
    prog = base_name(argv[0]);
    Opt o; memset(&o,0,sizeof(o)); o.level=6; o.suffix=".gz"; o.name=1; o.time_flag=1;
    if (strstr(prog, "unpigz")) o.decompress=1;
    int first = 1;
    for (; first < argc; first++) if (parse_one(&o,&first,argc,argv)) break;
    if (o.zlib_fmt && !o.zip_fmt && !strcmp(o.suffix,".gz")) o.suffix=".zz";
    if (first >= argc) {
        o.stdout_flag = 1;
        process_one(&o, "-");
    } else {
        for (int i=first; i<argc; i++) process_one(&o, argv[i]);
    }
    return exit_code;
}
