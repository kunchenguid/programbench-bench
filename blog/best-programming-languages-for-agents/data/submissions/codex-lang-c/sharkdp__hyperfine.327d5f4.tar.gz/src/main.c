#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct { char *var; char **vals; int n; } Param;
typedef struct {
    int warmup, min_runs, max_runs, runs;
    double step;
    char *setup, *cleanup, *shell, *style, *sort, *time_unit, *input;
    char *export_csv, *export_json, *export_md, *export_adoc, *export_org;
    char *reference, *reference_name;
    char **prepare; int n_prepare;
    char **conclude; int n_conclude;
    char **outputs; int n_outputs;
    char **names; int n_names;
    Param params[16]; int n_params;
    bool shell_none, show_output, ignore_all;
    int ignore_codes[256], n_ignore_codes;
} Opts;

typedef struct {
    char *cmd, *name;
    double *times;
    long *mems;
    int *codes;
    int n;
    double mean, stddev, median, min, max, user, sys;
} Result;

static void *xcalloc(size_t n, size_t s){ void *p=calloc(n,s); if(!p){perror("calloc"); exit(2);} return p; }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p){perror("strdup"); exit(2);} return p; }
static void push_str(char ***a, int *n, const char *s){ *a=realloc(*a, sizeof(char*)*(*n+1)); if(!*a){perror("realloc"); exit(2);} (*a)[(*n)++]=xstrdup(s); }
static bool starts(const char *s,const char*p){ return strncmp(s,p,strlen(p))==0; }

static void usage_short(void){ fprintf(stderr,"Usage: executable [OPTIONS] <command>...\n\nFor more information, try '--help'.\n"); }

static void print_help(void){
puts("A command-line benchmarking tool.\n\nUsage: executable [OPTIONS] <command>...\n\nArguments:\n  <command>...\n          The command to benchmark. This can be the name of an executable, a\n          command line like \"grep -i todo\" or a shell command like \"sleep 0.5 &&\n          echo test\". The latter is only available if the shell is not\n          explicitly disabled via '--shell=none'. If multiple commands are\n          given, hyperfine will show a comparison of the respective runtimes.\n\nOptions:\n  -w, --warmup <NUM>\n          Perform NUM warmup runs before the actual benchmark.\n  -m, --min-runs <NUM>\n          Perform at least NUM runs for each command (default: 10).\n  -M, --max-runs <NUM>\n          Perform at most NUM runs for each command.\n  -r, --runs <NUM>\n          Perform exactly NUM runs for each command.\n  -s, --setup <CMD>\n          Execute CMD before each set of timing runs.\n      --reference <CMD>\n          The reference command for the relative comparison of results.\n      --reference-name <CMD>\n          Give a meaningful name to the reference command.\n  -p, --prepare <CMD>\n          Execute CMD before each timing run.\n  -C, --conclude <CMD>\n          Execute CMD after each timing run.\n  -c, --cleanup <CMD>\n          Execute CMD after the completion of all benchmarking runs.\n  -P, --parameter-scan <VAR> <MIN> <MAX>\n          Perform benchmark runs for each value in the range MIN..MAX.\n  -D, --parameter-step-size <DELTA>\n          Traverse the parameter range in steps of DELTA.\n  -L, --parameter-list <VAR> <VALUES>\n          Perform benchmark runs for each value in the comma-separated list.\n  -S, --shell <SHELL>\n          Set the shell to use for executing benchmarked commands.\n  -N\n          An alias for '--shell=none'.\n  -i, --ignore-failure[=<MODE>]\n          Ignore failures of the benchmarked programs.\n      --style <TYPE>\n          Set output style type (default: auto).\n      --sort <METHOD>\n          Specify the sort order of the speed comparison summary.\n  -u, --time-unit <UNIT>\n          Set the time unit to be used.\n      --export-asciidoc <FILE>\n          Export the timing summary statistics as an AsciiDoc table.\n      --export-csv <FILE>\n          Export the timing summary statistics as CSV.\n      --export-json <FILE>\n          Export the timing summary statistics and individual timings as JSON.\n      --export-markdown <FILE>\n          Export the timing summary statistics as a Markdown table.\n      --export-orgmode <FILE>\n          Export the timing summary statistics as an Emacs org-mode table.\n      --show-output\n          Print the stdout and stderr of the benchmark.\n      --output <WHERE>\n          Control where benchmark output is redirected.\n      --input <WHERE>\n          Control where benchmark input comes from.\n  -n, --command-name <NAME>\n          Give a meaningful name to a command.\n  -h, --help\n          Print help\n  -V, --version\n          Print version");
}

static int to_int(const char *s){ char *e; long v=strtol(s,&e,10); if(!*s||*e||v<0){fprintf(stderr,"error: invalid value '%s'\n",s); exit(2);} return (int)v; }
static char *need_arg(int *i,int argc,char **argv,const char *opt){ if(*i+1>=argc){fprintf(stderr,"error: a value is required for '%s'\n\n",opt); usage_short(); exit(2);} return argv[++*i]; }
static char *value_of(int *i,int argc,char **argv,const char *arg,const char *name){
    size_t l=strlen(name); if(starts(arg,name)&&arg[l]=='=') return (char*)arg+l+1; return need_arg(i,argc,argv,arg);
}

static void add_list_param(Opts *o, const char *var, const char *values){
    if(o->n_params>=16) return; Param *p=&o->params[o->n_params++]; p->var=xstrdup(var); p->vals=NULL; p->n=0;
    char *tmp=xstrdup(values), *save=NULL, *tok=strtok_r(tmp,",",&save);
    while(tok){ push_str(&p->vals,&p->n,tok); tok=strtok_r(NULL,",",&save); }
    free(tmp);
}

static void add_scan_param(Opts *o, const char *var, const char *mn, const char *mx){
    double a=atof(mn), b=atof(mx), st=o->step>0?o->step:1.0; if(st<=0) st=1.0;
    if(o->n_params>=16) return; Param *p=&o->params[o->n_params++]; p->var=xstrdup(var); p->vals=NULL; p->n=0;
    int decimals = (strchr(mn,'.')||strchr(mx,'.')||fabs(st-round(st))>1e-9) ? 10 : 0;
    for(double x=a; x<=b+1e-9; x+=st){
        char buf[64]; if(decimals){ snprintf(buf,sizeof buf,"%.10g",x); } else snprintf(buf,sizeof buf,"%lld",(long long)llround(x));
        push_str(&p->vals,&p->n,buf);
        if(p->n>10000) break;
    }
}

static void parse_ignore(Opts *o, const char *v){
    if(!v || strcmp(v,"all-non-zero")==0){ o->ignore_all=true; return; }
    char *tmp=xstrdup(v), *save=NULL, *tok=strtok_r(tmp,",",&save);
    while(tok && o->n_ignore_codes<256){ o->ignore_codes[o->n_ignore_codes++]=atoi(tok); tok=strtok_r(NULL,",",&save); }
    free(tmp);
}

static void parse(int argc,char **argv,Opts *o,char ***cmds,int *ncmd){
    o->min_runs=10; o->step=1.0; o->style=xstrdup("auto"); o->sort=xstrdup("auto"); o->shell=xstrdup("default"); o->input=xstrdup("null");
    *cmds=NULL; *ncmd=0;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(strcmp(a,"--")==0){ while(++i<argc) push_str(cmds,ncmd,argv[i]); break; }
        if(a[0]!='-' || strcmp(a,"-")==0){ push_str(cmds,ncmd,a); continue; }
        if(!strcmp(a,"-h")||!strcmp(a,"--help")){ print_help(); exit(0); }
        if(!strcmp(a,"-V")||!strcmp(a,"--version")){ puts("hyperfine 1.20.0"); exit(0); }
        if(!strcmp(a,"-N")){ o->shell_none=true; free(o->shell); o->shell=xstrdup("none"); continue; }
        if(!strcmp(a,"-i")||!strcmp(a,"--ignore-failure")){ parse_ignore(o,NULL); continue; }
        if(starts(a,"--ignore-failure=")){ parse_ignore(o,a+17); continue; }
        if(!strcmp(a,"--show-output")){ o->show_output=true; continue; }
        if(!strcmp(a,"-w")||starts(a,"--warmup")){ o->warmup=to_int(value_of(&i,argc,argv,a,"--warmup")); continue; }
        if(!strcmp(a,"-m")||starts(a,"--min-runs")){ o->min_runs=to_int(value_of(&i,argc,argv,a,"--min-runs")); continue; }
        if(!strcmp(a,"-M")||starts(a,"--max-runs")){ o->max_runs=to_int(value_of(&i,argc,argv,a,"--max-runs")); continue; }
        if(!strcmp(a,"-r")||starts(a,"--runs")){ o->runs=to_int(value_of(&i,argc,argv,a,"--runs")); continue; }
        if(!strcmp(a,"-s")||starts(a,"--setup")){ o->setup=xstrdup(value_of(&i,argc,argv,a,"--setup")); continue; }
        if(!strcmp(a,"-c")||starts(a,"--cleanup")){ o->cleanup=xstrdup(value_of(&i,argc,argv,a,"--cleanup")); continue; }
        if(!strcmp(a,"-p")||starts(a,"--prepare")){ push_str(&o->prepare,&o->n_prepare,value_of(&i,argc,argv,a,"--prepare")); continue; }
        if(!strcmp(a,"-C")||starts(a,"--conclude")){ push_str(&o->conclude,&o->n_conclude,value_of(&i,argc,argv,a,"--conclude")); continue; }
        if(!strcmp(a,"-S")||starts(a,"--shell")){ free(o->shell); o->shell=xstrdup(value_of(&i,argc,argv,a,"--shell")); o->shell_none=!strcmp(o->shell,"none"); continue; }
        if(!strcmp(a,"-u")||starts(a,"--time-unit")){ o->time_unit=xstrdup(value_of(&i,argc,argv,a,"--time-unit")); continue; }
        if(!strcmp(a,"--style")||starts(a,"--style=")){ free(o->style); o->style=xstrdup(value_of(&i,argc,argv,a,"--style")); continue; }
        if(!strcmp(a,"--sort")||starts(a,"--sort=")){ free(o->sort); o->sort=xstrdup(value_of(&i,argc,argv,a,"--sort")); continue; }
        if(!strcmp(a,"--output")||starts(a,"--output=")){ push_str(&o->outputs,&o->n_outputs,value_of(&i,argc,argv,a,"--output")); continue; }
        if(!strcmp(a,"--input")||starts(a,"--input=")){ free(o->input); o->input=xstrdup(value_of(&i,argc,argv,a,"--input")); continue; }
        if(!strcmp(a,"-n")||starts(a,"--command-name")){ push_str(&o->names,&o->n_names,value_of(&i,argc,argv,a,"--command-name")); continue; }
        if(!strcmp(a,"--export-csv")||starts(a,"--export-csv=")){ o->export_csv=xstrdup(value_of(&i,argc,argv,a,"--export-csv")); continue; }
        if(!strcmp(a,"--export-json")||starts(a,"--export-json=")){ o->export_json=xstrdup(value_of(&i,argc,argv,a,"--export-json")); continue; }
        if(!strcmp(a,"--export-markdown")||starts(a,"--export-markdown=")){ o->export_md=xstrdup(value_of(&i,argc,argv,a,"--export-markdown")); continue; }
        if(!strcmp(a,"--export-asciidoc")||starts(a,"--export-asciidoc=")){ o->export_adoc=xstrdup(value_of(&i,argc,argv,a,"--export-asciidoc")); continue; }
        if(!strcmp(a,"--export-orgmode")||starts(a,"--export-orgmode=")){ o->export_org=xstrdup(value_of(&i,argc,argv,a,"--export-orgmode")); continue; }
        if(!strcmp(a,"--reference")||starts(a,"--reference=")){ o->reference=xstrdup(value_of(&i,argc,argv,a,"--reference")); continue; }
        if(!strcmp(a,"--reference-name")||starts(a,"--reference-name=")){ o->reference_name=xstrdup(value_of(&i,argc,argv,a,"--reference-name")); continue; }
        if(!strcmp(a,"-D")||starts(a,"--parameter-step-size")){ o->step=atof(value_of(&i,argc,argv,a,"--parameter-step-size")); continue; }
        if(!strcmp(a,"-L")||!strcmp(a,"--parameter-list")){
            char *v=need_arg(&i,argc,argv,a), *vals=need_arg(&i,argc,argv,a); add_list_param(o,v,vals); continue;
        }
        if(!strcmp(a,"-P")||!strcmp(a,"--parameter-scan")){
            char *v=need_arg(&i,argc,argv,a), *mn=need_arg(&i,argc,argv,a), *mx=need_arg(&i,argc,argv,a); add_scan_param(o,v,mn,mx); continue;
        }
        fprintf(stderr,"error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\n",a,a,a); usage_short(); exit(2);
    }
    if(o->show_output && strcmp(o->style,"auto") && strcmp(o->style,"full")){
        fprintf(stderr,"error: the argument '--style <TYPE>' cannot be used with '--show-output'\n\n"); usage_short(); exit(2);
    }
    if(*ncmd==0){ fprintf(stderr,"error: the following required arguments were not provided:\n  <command>...\n\nUsage: executable <command>...\n\nFor more information, try '--help'.\n"); exit(2); }
}

static char *replace_all(const char *s,const char *needle,const char *rep){
    size_t nl=strlen(needle), rl=strlen(rep), cap=strlen(s)+1; char *out=xcalloc(cap,1); size_t oi=0;
    for(size_t i=0;s[i];){
        if(nl && strncmp(s+i,needle,nl)==0){ while(oi+rl+1>cap){cap*=2; out=realloc(out,cap);} memcpy(out+oi,rep,rl); oi+=rl; i+=nl; }
        else { if(oi+2>cap){cap*=2; out=realloc(out,cap);} out[oi++]=s[i++]; }
    }
    out[oi]=0; return out;
}
static char *expand_one(const char *s, Param *ps, int *idx, int n){
    char *r=xstrdup(s);
    for(int i=0;i<n;i++){ char pat[256]; snprintf(pat,sizeof pat,"{%s}",ps[i].var); char *nr=replace_all(r,pat,ps[i].vals[idx[i]]); free(r); r=nr; }
    return r;
}
static void gen_cmds_rec(char ***out,int *n,const char *cmd,Param *ps,int pn,int depth,int *idx){
    if(depth==pn){ char *e=expand_one(cmd,ps,idx,pn); push_str(out,n,e); free(e); return; }
    for(int i=0;i<ps[depth].n;i++){ idx[depth]=i; gen_cmds_rec(out,n,cmd,ps,pn,depth+1,idx); }
}

static char *expand_for_index(const char *s, Opts *o, int cmd_index){
    if(!s || o->n_params==0) return xstrdup(s?s:"");
    int product=1; for(int i=0;i<o->n_params;i++) product *= o->params[i].n ? o->params[i].n : 1;
    int combo = product ? (cmd_index % product) : 0;
    int idx[16]={0};
    for(int i=0;i<o->n_params;i++){
        int block=1; for(int j=i+1;j<o->n_params;j++) block *= o->params[j].n ? o->params[j].n : 1;
        idx[i] = block ? (combo / block) % o->params[i].n : 0;
    }
    return expand_one(s,o->params,idx,o->n_params);
}

static double now_sec(void){ struct timespec ts; clock_gettime(CLOCK_MONOTONIC,&ts); return ts.tv_sec+ts.tv_nsec/1e9; }
static int ignored(Opts *o,int code){ if(code==0) return 1; if(o->ignore_all) return 1; for(int i=0;i<o->n_ignore_codes;i++) if(o->ignore_codes[i]==code) return 1; return 0; }

static int split_words(const char *s,char ***argv){
    char *tmp=xstrdup(s), *p=tmp; int n=0; *argv=NULL;
    while(*p){ while(isspace((unsigned char)*p)) p++; if(!*p) break; char quote=0; char *start=p, *buf=xcalloc(strlen(p)+1,1); int bi=0;
        while(*p && (quote || !isspace((unsigned char)*p))){ if((*p=='\''||*p=='"')){ if(!quote){quote=*p++; continue;} if(quote==*p){quote=0; p++; continue;} } buf[bi++]=*p++; }
        (void)start; push_str(argv,&n,buf); free(buf);
    }
    free(tmp); return n;
}

static int run_command(const char *cmd, Opts *o, const char *outwhere, double *elapsed, double *ut, double *st, long *mem){
    double t0=now_sec(); struct rusage before, after; getrusage(RUSAGE_CHILDREN,&before);
    pid_t pid=fork(); if(pid<0){perror("fork"); return 127;}
    if(pid==0){
        if(!o->show_output){
            if(outwhere && strcmp(outwhere,"inherit")==0) {}
            else if(outwhere && strcmp(outwhere,"pipe")==0) { int fd=open("/dev/null",O_WRONLY); dup2(fd,1); dup2(fd,2); if(fd>2) close(fd); }
            else if(outwhere && strcmp(outwhere,"null") && strlen(outwhere)>0){ int fd=open(outwhere,O_CREAT|O_WRONLY|O_TRUNC,0666); if(fd>=0){dup2(fd,1); dup2(fd,2); if(fd>2) close(fd);} }
            else { int fd=open("/dev/null",O_WRONLY); dup2(fd,1); dup2(fd,2); if(fd>2) close(fd); }
        }
        if(o->input && strcmp(o->input,"null")){ int fd=open(o->input,O_RDONLY); if(fd>=0){dup2(fd,0); if(fd>2) close(fd);} }
        else { int fd=open("/dev/null",O_RDONLY); if(fd>=0){dup2(fd,0); if(fd>2) close(fd);} }
        if(o->shell_none){
            char **av=NULL; int n=split_words(cmd,&av); if(n==0) _exit(127); av=realloc(av,sizeof(char*)*(n+1)); av[n]=NULL; execvp(av[0],av); _exit(127);
        } else {
            const char *sh = (!o->shell || !strcmp(o->shell,"default")) ? "/bin/sh" : o->shell;
            if(strchr(sh,' ')){ char **av=NULL; int n=split_words(sh,&av); av=realloc(av,sizeof(char*)*(n+3)); av[n++]=(char*)"-c"; av[n++]=(char*)cmd; av[n]=NULL; execvp(av[0],av); }
            else execlp(sh,sh,"-c",cmd,(char*)NULL);
            _exit(127);
        }
    }
    int status; waitpid(pid,&status,0); getrusage(RUSAGE_CHILDREN,&after); *elapsed=now_sec()-t0;
    *ut=(after.ru_utime.tv_sec-before.ru_utime.tv_sec)+(after.ru_utime.tv_usec-before.ru_utime.tv_usec)/1e6;
    *st=(after.ru_stime.tv_sec-before.ru_stime.tv_sec)+(after.ru_stime.tv_usec-before.ru_stime.tv_usec)/1e6;
    *mem=after.ru_maxrss>before.ru_maxrss?after.ru_maxrss*1024L:0;
    if(WIFEXITED(status)) return WEXITSTATUS(status); if(WIFSIGNALED(status)) return 128+WTERMSIG(status); return 1;
}

static int cmp_d(const void*a,const void*b){ double x=*(double*)a,y=*(double*)b; return (x>y)-(x<y); }
static void stats(Result *r){
    r->min=1e99; r->max=0; double sum=0; for(int i=0;i<r->n;i++){ double t=r->times[i]; if(t<r->min)r->min=t; if(t>r->max)r->max=t; sum+=t; }
    r->mean=sum/r->n; double ss=0; for(int i=0;i<r->n;i++){ double d=r->times[i]-r->mean; ss+=d*d; }
    r->stddev = r->n>1 ? sqrt(ss/(r->n-1)) : 0;
    double *tmp=xcalloc(r->n,sizeof(double)); memcpy(tmp,r->times,r->n*sizeof(double)); qsort(tmp,r->n,sizeof(double),cmp_d);
    r->median = r->n%2 ? tmp[r->n/2] : (tmp[r->n/2-1]+tmp[r->n/2])/2; free(tmp);
}

static const char *unit_name(const char *u,double val){
    if(u){ if(starts(u,"micro")) return "us"; if(starts(u,"milli")) return "ms"; if(starts(u,"second")) return "s"; }
    if(val < 0.001) return "us"; if(val < 1.0) return "ms"; return "s";
}
static double scale_for(const char *un){ return !strcmp(un,"us")?1e6:(!strcmp(un,"ms")?1e3:1.0); }
static void fmt_time(char *buf,size_t n,double sec,const char *un){ snprintf(buf,n,"%.1f %s",sec*scale_for(un),!strcmp(un,"us")?"µs":un); }

static void warn_fast(void){ fprintf(stderr," \n  Warning: Command took less than 5 ms to complete. Note that the results might be inaccurate because hyperfine can not calibrate the shell startup time much more precise than this limit. You can try to use the `-N`/`--shell=none` option to disable the shell completely.\n"); }

static void bench(Result *r, Opts *o, int idx, int total){
    int runs=o->runs?o->runs:o->min_runs; if(o->max_runs && runs>o->max_runs) runs=o->max_runs; if(runs<1) runs=1;
    r->times=xcalloc(runs,sizeof(double)); r->mems=xcalloc(runs,sizeof(long)); r->codes=xcalloc(runs,sizeof(int)); r->n=runs;
    if(strcmp(o->style,"none")) {
        printf("Benchmark %d: %s\n",idx+1,r->name);
        fflush(stdout);
    }
    double e,u,s; long m; int code;
    if(o->setup){ char *x=expand_for_index(o->setup,o,idx); run_command(x,o,"inherit",&e,&u,&s,&m); free(x); }
    for(int i=0;i<o->warmup;i++) run_command(r->cmd,o,"null",&e,&u,&s,&m);
    for(int i=0;i<runs;i++){
        char iter[32]; snprintf(iter,sizeof iter,"%d",i+1); setenv("HYPERFINE_ITERATION",iter,1);
        char *prep = o->n_prepare ? o->prepare[(o->n_prepare==total)?idx:0] : NULL;
        if(prep){ char *x=expand_for_index(prep,o,idx); run_command(x,o,"inherit",&e,&u,&s,&m); free(x); }
        const char *ow = o->n_outputs ? o->outputs[(o->n_outputs==total)?idx:0] : "null";
        code=run_command(r->cmd,o,ow,&e,&u,&s,&m);
        r->times[i]=e; r->user+=u; r->sys+=s; r->mems[i]=m; r->codes[i]=code;
        char *con = o->n_conclude ? o->conclude[(o->n_conclude==total)?idx:0] : NULL;
        if(con){ char *x=expand_for_index(con,o,idx); run_command(x,o,"inherit",&e,&u,&s,&m); free(x); }
        if(!ignored(o,code)){
            fprintf(stderr,"Error: Command terminated with non-zero exit code %d in the first benchmark run. Use the '-i'/'--ignore-failure' option if you want to ignore this. Alternatively, use the '--show-output' option to debug what went wrong.\n",code);
            exit(1);
        }
    }
    stats(r); r->user/=runs; r->sys/=runs;
    if(strcmp(o->style,"none")){
        const char *un=unit_name(o->time_unit,r->mean); char a[64],b[64],c[64],d[64]; fmt_time(a,sizeof a,r->mean,un); fmt_time(b,sizeof b,r->stddev,un); fmt_time(c,sizeof c,r->min,un); fmt_time(d,sizeof d,r->max,un);
        if(runs==1) printf("  Time (abs ≡):     %12s               [User: %.1f ms, System: %.1f ms]\n",a,r->user*1000,r->sys*1000);
        else printf("  Time (mean ± σ):  %12s ± %8s    [User: %.1f ms, System: %.1f ms]\n  Range (min … max): %10s … %8s    %d runs\n",a,b,r->user*1000,r->sys*1000,c,d,runs);
        fflush(stdout);
    }
    if(r->mean < 0.005) warn_fast();
    bool any_nonzero=false; for(int i=0;i<runs;i++) if(r->codes[i]) any_nonzero=true; if(any_nonzero && strcmp(o->style,"none")) printf("  Warning: Ignoring non-zero exit code.\n");
    if(o->cleanup){ char *x=expand_for_index(o->cleanup,o,idx); run_command(x,o,"inherit",&e,&u,&s,&m); free(x); }
}

static double rel_err(Result *r,double ref){ return r->stddev>0 ? r->stddev/ref : 0; }
static void summary(Result *rs,int n,Opts*o){
    if(n<2 || !strcmp(o->style,"none")) return; int best=0; for(int i=1;i<n;i++) if(rs[i].mean<rs[best].mean) best=i;
    printf(" \nSummary\n  %s ran\n",rs[best].name);
    for(int i=0;i<n;i++) if(i!=best) printf("    %.2f times faster than %s\n",rs[i].mean/rs[best].mean,rs[i].name);
}
static FILE *xfopen(const char *p){ FILE*f=fopen(p,"w"); if(!f){perror(p); exit(1);} return f; }
static void json_escape(FILE*f,const char*s){ for(;*s;s++){ if(*s=='"'||*s=='\\') fputc('\\',f); if(*s=='\n') fputs("\\n",f); else fputc(*s,f);} }

static void exports(Result *rs,int n,Opts*o){
    if(o->export_json){ FILE*f=xfopen(o->export_json); fprintf(f,"{\n  \"results\": [\n"); for(int i=0;i<n;i++){ Result*r=&rs[i]; fprintf(f,"    {\n      \"command\": \""); json_escape(f,r->name); fprintf(f,"\",\n      \"mean\": %.17g,\n      \"stddev\": %.17g,\n      \"median\": %.17g,\n      \"user\": %.17g,\n      \"system\": %.17g,\n      \"min\": %.17g,\n      \"max\": %.17g,\n      \"times\": [",r->mean,r->stddev,r->median,r->user,r->sys,r->min,r->max); for(int j=0;j<r->n;j++) fprintf(f,"%s\n        %.17g",j?",":"",r->times[j]); fprintf(f,"\n      ],\n      \"memory_usage_byte\": ["); for(int j=0;j<r->n;j++) fprintf(f,"%s\n        %ld",j?",":"",r->mems[j]); fprintf(f,"\n      ],\n      \"exit_codes\": ["); for(int j=0;j<r->n;j++) fprintf(f,"%s\n        %d",j?",":"",r->codes[j]); fprintf(f,"\n      ]\n    }%s\n",i==n-1?"":","); } fprintf(f,"  ]\n}\n"); fclose(f); }
    if(o->export_csv){ FILE*f=xfopen(o->export_csv); fprintf(f,"command,mean,stddev,median,user,system,min,max\n"); for(int i=0;i<n;i++) fprintf(f,"%s,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g,%.17g\n",rs[i].name,rs[i].mean,rs[i].stddev,rs[i].median,rs[i].user,rs[i].sys,rs[i].min,rs[i].max); fclose(f); }
    const char *un=unit_name(o->time_unit, rs[0].mean); double sc=scale_for(un); const char *pun=!strcmp(un,"us")?"µs":un; int best=0; for(int i=1;i<n;i++) if(rs[i].mean<rs[best].mean) best=i;
    if(o->export_md){ FILE*f=xfopen(o->export_md); fprintf(f,"| Command | Mean [%s] | Min [%s] | Max [%s] | Relative |\n|:---|---:|---:|---:|---:|\n",pun,pun,pun); for(int i=0;i<n;i++) fprintf(f,"| `%s` | %.1f ± %.1f | %.1f | %.1f | %.2f |\n",rs[i].name,rs[i].mean*sc,rs[i].stddev*sc,rs[i].min*sc,rs[i].max*sc,rs[i].mean/rs[best].mean); fclose(f); }
    if(o->export_adoc){ FILE*f=xfopen(o->export_adoc); fprintf(f,"[cols=\"<,>,>,>,>\"]\n|===\n| Command \n| Mean [%s] \n| Min [%s] \n| Max [%s] \n| Relative \n\n",pun,pun,pun); for(int i=0;i<n;i++) fprintf(f,"| `%s` \n| %.1f ± %.1f \n| %.1f \n| %.1f \n| %.2f \n",rs[i].name,rs[i].mean*sc,rs[i].stddev*sc,rs[i].min*sc,rs[i].max*sc,rs[i].mean/rs[best].mean); fprintf(f,"|===\n"); fclose(f); }
    if(o->export_org){ FILE*f=xfopen(o->export_org); fprintf(f,"| Command  |  Mean [%s] |  Min [%s] |  Max [%s] |  Relative |\n|--+--+--+--+--|\n",pun,pun,pun); for(int i=0;i<n;i++) fprintf(f,"| =%s=  |  %.1f ± %.1f |  %.1f |  %.1f |  %.2f |\n",rs[i].name,rs[i].mean*sc,rs[i].stddev*sc,rs[i].min*sc,rs[i].max*sc,rs[i].mean/rs[best].mean); fclose(f); }
}

int main(int argc,char **argv){
    Opts o={0}; char **base=NULL; int nbase=0; parse(argc,argv,&o,&base,&nbase);
    char **cmds=NULL; int ncmd=0; int idx[16]={0};
    for(int i=0;i<nbase;i++){ if(o.n_params) gen_cmds_rec(&cmds,&ncmd,base[i],o.params,o.n_params,0,idx); else push_str(&cmds,&ncmd,base[i]); }
    if(o.n_names>ncmd){ fprintf(stderr,"Error: Too many --command-name options: Expected %d at most\n",ncmd); return 1; }
    Result *rs=xcalloc(ncmd,sizeof(Result));
    for(int i=0;i<ncmd;i++){ rs[i].cmd=cmds[i]; rs[i].name=(i<o.n_names)?o.names[i]:cmds[i]; bench(&rs[i],&o,i,ncmd); if(i<ncmd-1 && strcmp(o.style,"none")) puts(" "); }
    summary(rs,ncmd,&o); exports(rs,ncmd,&o); return 0;
}
