#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#define _GNU_SOURCE

#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

#define VERSION "0.4.3"
#define CTRL_KEY(k) ((k) & 0x1f)

typedef struct {
    char *s;
    size_t len, cap;
} Line;

typedef struct {
    char *name;
    Line *line;
    int nline, capline;
    int cx, cy, rowoff, dirty;
} Buffer;

typedef struct {
    int rows, cols, current, nbuf;
    Buffer *bufs;
    struct termios orig;
    char msg[256];
    int quit_warn;
} Editor;

static Editor E;

static const char *HELP =
"./executable: A tiny UTF-8 terminal text editor\n"
"\n"
"Kiro is a tiny UTF-8 text editor on terminals for Unix-like systems.\n"
"Specify file paths to edit as a command argument or run without argument to\n"
"start to write a new text.\n"
"Help can show up with key mapping Ctrl-?.\n"
"\n"
"Usage:\n"
"    ./executable [options] [FILES...]\n"
"\n"
"Mappings:\n"
"    Ctrl-Q                        : Quit\n"
"    Ctrl-S                        : Save to file\n"
"    Ctrl-O                        : Open text buffer\n"
"    Ctrl-X                        : Next text buffer\n"
"    Alt-X                         : Previous text buffer\n"
"    Ctrl-P or UP                  : Move cursor up\n"
"    Ctrl-N or DOWN                : Move cursor down\n"
"    Ctrl-F or RIGHT               : Move cursor right\n"
"    Ctrl-B or LEFT                : Move cursor left\n"
"    Ctrl-A or Alt-LEFT or HOME    : Move cursor to head of line\n"
"    Ctrl-E or Alt-RIGHT or END    : Move cursor to end of line\n"
"    Ctrl-[ or Ctrl-V or PAGE DOWN : Next page\n"
"    Ctrl-] or Alt-V or PAGE UP    : Previous page\n"
"    Alt-F or Ctrl-RIGHT           : Move cursor to next word\n"
"    Alt-B or Ctrl-LEFT            : Move cursor to previous word\n"
"    Alt-N or Ctrl-DOWN            : Move cursor to next paragraph\n"
"    Alt-P or Ctrl-UP              : Move cursor to previous paragraph\n"
"    Alt-<                         : Move cursor to top of file\n"
"    Alt->                         : Move cursor to bottom of file\n"
"    Ctrl-H or BACKSPACE           : Delete character\n"
"    Ctrl-D or DELETE              : Delete next character\n"
"    Ctrl-W                        : Delete a word\n"
"    Ctrl-J                        : Delete until head of line\n"
"    Ctrl-K                        : Delete until end of line\n"
"    Ctrl-U                        : Undo last change\n"
"    Ctrl-R                        : Redo last undo change\n"
"    Ctrl-G                        : Search text\n"
"    Ctrl-M                        : New line\n"
"    Ctrl-L                        : Refresh screen\n"
"    Ctrl-?                        : Show this help\n"
"\n"
"Options:\n"
"    -v, --version       Print version\n"
"    -h, --help          Print this help\n"
"\n";

static void die_errno(void) {
    fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
    exit(1);
}

static void ab_append(char **ab, size_t *len, const char *s, size_t n) {
    char *p = realloc(*ab, *len + n + 1);
    if (!p) exit(1);
    memcpy(p + *len, s, n);
    *len += n;
    p[*len] = 0;
    *ab = p;
}

static void ab_printf(char **ab, size_t *len, const char *fmt, ...) {
    char tmp[512];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(tmp, sizeof(tmp), fmt, ap);
    va_end(ap);
    if (n > 0) ab_append(ab, len, tmp, (size_t)n);
}

static void line_insert(Line *l, int at, const char *s, int n) {
    if (at < 0) at = 0;
    if ((size_t)at > l->len) at = (int)l->len;
    if (l->len + n + 1 > l->cap) {
        l->cap = (l->len + n + 32) * 2;
        l->s = realloc(l->s, l->cap);
        if (!l->s) exit(1);
    }
    memmove(l->s + at + n, l->s + at, l->len - at + 1);
    memcpy(l->s + at, s, n);
    l->len += n;
}

static void line_del(Line *l, int at, int n) {
    if (at < 0 || (size_t)at >= l->len || n <= 0) return;
    if ((size_t)(at + n) > l->len) n = (int)l->len - at;
    memmove(l->s + at, l->s + at + n, l->len - at - n + 1);
    l->len -= n;
}

static void buf_insert_line(Buffer *b, int at, const char *s, size_t n) {
    if (at < 0) at = 0;
    if (at > b->nline) at = b->nline;
    if (b->nline + 1 > b->capline) {
        b->capline = b->capline ? b->capline * 2 : 8;
        b->line = realloc(b->line, sizeof(Line) * b->capline);
        if (!b->line) exit(1);
    }
    memmove(&b->line[at + 1], &b->line[at], sizeof(Line) * (b->nline - at));
    b->line[at].s = calloc(n + 1, 1);
    if (!b->line[at].s) exit(1);
    memcpy(b->line[at].s, s, n);
    b->line[at].len = n;
    b->line[at].cap = n + 1;
    b->nline++;
}

static Buffer new_buffer(const char *name) {
    Buffer b;
    memset(&b, 0, sizeof(b));
    b.name = name ? strdup(name) : NULL;
    buf_insert_line(&b, 0, "", 0);
    return b;
}

static void free_buffer(Buffer *b) {
    for (int i = 0; i < b->nline; i++) free(b->line[i].s);
    free(b->line);
    free(b->name);
}

static void load_file(Buffer *b) {
    if (!b->name) return;
    FILE *f = fopen(b->name, "rb");
    if (!f) return;
    for (int i = 0; i < b->nline; i++) free(b->line[i].s);
    b->nline = 0;
    char *line = NULL;
    size_t cap = 0;
    ssize_t n;
    while ((n = getline(&line, &cap, f)) != -1) {
        while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r')) n--;
        buf_insert_line(b, b->nline, line, (size_t)n);
    }
    if (b->nline == 0) buf_insert_line(b, 0, "", 0);
    free(line);
    fclose(f);
    b->dirty = 0;
}

static Buffer *cur(void) { return &E.bufs[E.current]; }

static void set_msg(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(E.msg, sizeof(E.msg), fmt, ap);
    va_end(ap);
}

static int any_dirty(void) {
    for (int i = 0; i < E.nbuf; i++) if (E.bufs[i].dirty) return 1;
    return 0;
}

static void enable_raw(void) {
    if (tcgetattr(STDIN_FILENO, &E.orig) == -1) die_errno();
    struct termios raw = E.orig;
    raw.c_iflag &= ~(BRKINT | ICRNL | INPCK | ISTRIP | IXON);
    raw.c_oflag &= ~(OPOST);
    raw.c_cflag |= CS8;
    raw.c_lflag &= ~(ECHO | ICANON | IEXTEN | ISIG);
    raw.c_cc[VMIN] = 0;
    raw.c_cc[VTIME] = 1;
    if (tcsetattr(STDIN_FILENO, TCSAFLUSH, &raw) == -1) die_errno();
}

static void disable_raw(void) {
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &E.orig);
    const char *s = "\x1b[?1049l\x1b[H";
    write(STDOUT_FILENO, s, strlen(s));
}

static void get_window(void) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws) == -1 || ws.ws_col == 0) {
        E.rows = 24;
        E.cols = 80;
    } else {
        E.rows = ws.ws_row;
        E.cols = ws.ws_col;
    }
    if (E.rows < 3) E.rows = 24;
    if (E.cols < 20) E.cols = 80;
}

enum { ARROW_LEFT = 1000, ARROW_RIGHT, ARROW_UP, ARROW_DOWN, DEL_KEY, HOME_KEY, END_KEY, PAGE_UP, PAGE_DOWN, ALT_X, ALT_LT, ALT_GT };

static int read_key(void) {
    char c;
    while (read(STDIN_FILENO, &c, 1) != 1) ;
    if (c == '\x1b') {
        char seq[4] = {0};
        if (read(STDIN_FILENO, &seq[0], 1) != 1) return CTRL_KEY('[');
        if (read(STDIN_FILENO, &seq[1], 1) != 1) {
            if (seq[0] == 'x' || seq[0] == 'X') return ALT_X;
            if (seq[0] == '<') return ALT_LT;
            if (seq[0] == '>') return ALT_GT;
            return CTRL_KEY('[');
        }
        if (seq[0] == '[') {
            if (seq[1] >= '0' && seq[1] <= '9') {
                read(STDIN_FILENO, &seq[2], 1);
                if (seq[2] == '~') {
                    if (seq[1] == '1' || seq[1] == '7') return HOME_KEY;
                    if (seq[1] == '3') return DEL_KEY;
                    if (seq[1] == '4' || seq[1] == '8') return END_KEY;
                    if (seq[1] == '5') return PAGE_UP;
                    if (seq[1] == '6') return PAGE_DOWN;
                }
            } else {
                if (seq[1] == 'A') return ARROW_UP;
                if (seq[1] == 'B') return ARROW_DOWN;
                if (seq[1] == 'C') return ARROW_RIGHT;
                if (seq[1] == 'D') return ARROW_LEFT;
                if (seq[1] == 'H') return HOME_KEY;
                if (seq[1] == 'F') return END_KEY;
            }
        }
        return CTRL_KEY('[');
    }
    return (unsigned char)c;
}

static void scroll(void) {
    Buffer *b = cur();
    int screenrows = E.rows - 2;
    if (b->cy < b->rowoff) b->rowoff = b->cy;
    if (b->cy >= b->rowoff + screenrows) b->rowoff = b->cy - screenrows + 1;
}

static void draw(void) {
    scroll();
    Buffer *b = cur();
    char *ab = NULL;
    size_t len = 0;
#define APP(s) ab_append(&ab, &len, (s), strlen(s))
    APP("\x1b[?25l\x1b[39;0m");
    int screenrows = E.rows - 2;
    for (int y = 0; y < screenrows; y++) {
        int filerow = y + b->rowoff;
        ab_printf(&ab, &len, "\x1b[%dH", y + 1);
        if (filerow >= b->nline) {
            APP("\x1b[37m~\x1b[39;0m");
            if (b->nline == 1 && b->line[0].len == 0 && y == screenrows / 3) {
                const char *w = "Kiro editor -- version " VERSION;
                int pad = (E.cols - (int)strlen(w)) / 2;
                while (pad-- > 0) ab_append(&ab, &len, " ", 1);
                ab_append(&ab, &len, w, strlen(w));
            }
        } else {
            int n = (int)b->line[filerow].len;
            if (n > E.cols) n = E.cols;
            ab_append(&ab, &len, b->line[filerow].s, (size_t)n);
            ab_append(&ab, &len, "\x1b[39;0m", 7);
        }
        APP("\x1b[K");
    }
    ab_printf(&ab, &len, "\x1b[%dH\x1b[7m", E.rows - 1);
    char left[256], right[64];
    snprintf(left, sizeof(left), "\"%s\" - %d/%d%s", b->name ? b->name : "[No Name]", E.current + 1, E.nbuf, b->dirty ? " (modified)" : "");
    snprintf(right, sizeof(right), "plain %d/%d", b->cy + 1, b->nline);
    int l = (int)strlen(left), r = (int)strlen(right);
    if (l > E.cols) l = E.cols;
    ab_append(&ab, &len, left, (size_t)l);
    while (l < E.cols) {
        if (E.cols - l == r) { ab_append(&ab, &len, right, (size_t)r); break; }
        ab_append(&ab, &len, " ", 1); l++;
    }
    APP("\x1b[39;0m");
    ab_printf(&ab, &len, "\x1b[%dH", E.rows);
    if (E.msg[0]) ab_append(&ab, &len, E.msg, strnlen(E.msg, (size_t)E.cols));
    else APP("Ctrl-? for help");
    APP("\x1b[K");
    int cx = b->cx + 1;
    int cy = b->cy - b->rowoff + 1;
    if (cy < 1) cy = 1;
    if (cy > screenrows) cy = screenrows;
    if (cx < 1) cx = 1;
    if (cx > E.cols) cx = E.cols;
    ab_printf(&ab, &len, "\x1b[%d;%dH\x1b[?25h", cy, cx);
    write(STDOUT_FILENO, ab, len);
    free(ab);
#undef APP
}

static void insert_char(int c) {
    Buffer *b = cur();
    char ch = (char)c;
    line_insert(&b->line[b->cy], b->cx, &ch, 1);
    b->cx++;
    b->dirty = 1;
    E.quit_warn = 0;
}

static void insert_newline(void) {
    Buffer *b = cur();
    Line *l = &b->line[b->cy];
    buf_insert_line(b, b->cy + 1, l->s + b->cx, l->len - (size_t)b->cx);
    l = &b->line[b->cy];
    l->len = (size_t)b->cx;
    l->s[l->len] = 0;
    b->cy++;
    b->cx = 0;
    b->dirty = 1;
    E.quit_warn = 0;
}

static void del_char_back(void) {
    Buffer *b = cur();
    if (b->cy == 0 && b->cx == 0) return;
    if (b->cx > 0) {
        line_del(&b->line[b->cy], b->cx - 1, 1);
        b->cx--;
    } else {
        int oldlen = (int)b->line[b->cy - 1].len;
        line_insert(&b->line[b->cy - 1], oldlen, b->line[b->cy].s, (int)b->line[b->cy].len);
        free(b->line[b->cy].s);
        memmove(&b->line[b->cy], &b->line[b->cy + 1], sizeof(Line) * (b->nline - b->cy - 1));
        b->nline--;
        b->cy--;
        b->cx = oldlen;
    }
    b->dirty = 1;
    E.quit_warn = 0;
}

static void del_char_forward(void) {
    Buffer *b = cur();
    if (b->cx < (int)b->line[b->cy].len) {
        line_del(&b->line[b->cy], b->cx, 1);
        b->dirty = 1;
    } else if (b->cy + 1 < b->nline) {
        line_insert(&b->line[b->cy], b->cx, b->line[b->cy + 1].s, (int)b->line[b->cy + 1].len);
        free(b->line[b->cy + 1].s);
        memmove(&b->line[b->cy + 1], &b->line[b->cy + 2], sizeof(Line) * (b->nline - b->cy - 2));
        b->nline--;
        b->dirty = 1;
    }
}

static void move_cursor(int key) {
    Buffer *b = cur();
    Line *l = &b->line[b->cy];
    switch (key) {
        case ARROW_LEFT: case CTRL_KEY('b'): if (b->cx) b->cx--; else if (b->cy) { b->cy--; b->cx = (int)b->line[b->cy].len; } break;
        case ARROW_RIGHT: case CTRL_KEY('f'): if (b->cx < (int)l->len) b->cx++; else if (b->cy + 1 < b->nline) { b->cy++; b->cx = 0; } break;
        case ARROW_UP: case CTRL_KEY('p'): if (b->cy) b->cy--; break;
        case ARROW_DOWN: case CTRL_KEY('n'): if (b->cy + 1 < b->nline) b->cy++; break;
        case HOME_KEY: case CTRL_KEY('a'): b->cx = 0; break;
        case END_KEY: case CTRL_KEY('e'): b->cx = (int)l->len; break;
        case PAGE_UP: b->cy -= E.rows - 2; if (b->cy < 0) b->cy = 0; break;
        case PAGE_DOWN: b->cy += E.rows - 2; if (b->cy >= b->nline) b->cy = b->nline - 1; break;
        case ALT_LT: b->cy = 0; b->cx = 0; break;
        case ALT_GT: b->cy = b->nline - 1; b->cx = (int)b->line[b->cy].len; break;
    }
    if (b->cx > (int)b->line[b->cy].len) b->cx = (int)b->line[b->cy].len;
}

static void save_buffer(void) {
    Buffer *b = cur();
    if (!b->name) {
        set_msg("No file name");
        return;
    }
    FILE *f = fopen(b->name, "wb");
    if (!f) {
        set_msg("Failed to save: %s", strerror(errno));
        return;
    }
    for (int i = 0; i < b->nline; i++) {
        fwrite(b->line[i].s, 1, b->line[i].len, f);
        if (i != b->nline - 1) fputc('\n', f);
    }
    fclose(f);
    b->dirty = 0;
    E.quit_warn = 0;
    set_msg("Saved to %s", b->name);
}

static void process_key(int c) {
    switch (c) {
        case CTRL_KEY('q'):
            if (any_dirty() && !E.quit_warn) {
                E.quit_warn = 1;
                set_msg("At least one file has unsaved changes! Press ^Q again to quit or ^S to save");
                return;
            }
            write(STDOUT_FILENO, "\x1b[?25h", 6);
            exit(0);
        case CTRL_KEY('s'): save_buffer(); break;
        case CTRL_KEY('x'): if (E.nbuf) E.current = (E.current + 1) % E.nbuf; break;
        case ALT_X: if (E.nbuf) E.current = (E.current + E.nbuf - 1) % E.nbuf; break;
        case CTRL_KEY('m'): insert_newline(); break;
        case CTRL_KEY('h'): case 127: del_char_back(); break;
        case CTRL_KEY('d'): case DEL_KEY: del_char_forward(); break;
        case CTRL_KEY('k'): cur()->line[cur()->cy].len = (size_t)cur()->cx; cur()->line[cur()->cy].s[cur()->cx] = 0; cur()->dirty = 1; break;
        case CTRL_KEY('j'): line_del(&cur()->line[cur()->cy], 0, cur()->cx); cur()->cx = 0; cur()->dirty = 1; break;
        case CTRL_KEY('?'): set_msg("Ctrl-Q quit | Ctrl-S save | Ctrl-X next buffer | Ctrl-G search"); break;
        case CTRL_KEY('l'): break;
        case ARROW_UP: case ARROW_DOWN: case ARROW_LEFT: case ARROW_RIGHT:
        case CTRL_KEY('p'): case CTRL_KEY('n'): case CTRL_KEY('b'): case CTRL_KEY('f'):
        case HOME_KEY: case END_KEY: case PAGE_UP: case PAGE_DOWN: case ALT_LT: case ALT_GT:
            move_cursor(c); break;
        default:
            if (c >= 32 && c != 127) insert_char(c);
            break;
    }
}

static void usage_version_parse(int argc, char **argv, int *first_file) {
    *first_file = 1;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (a[0] != '-' || strcmp(a, "--") == 0) { *first_file = i; return; }
        if (!strcmp(a, "--help")) { fputs(HELP, stdout); exit(0); }
        if (!strcmp(a, "--version")) { puts(VERSION); exit(0); }
        if (a[1] == '-') {
            fprintf(stderr, "Error: Unrecognized option: '%s'. Please see --help for more details\n", a + 2);
            exit(1);
        }
        for (int j = 1; a[j]; j++) {
            if (a[j] == 'v') { puts(VERSION); exit(0); }
            if (a[j] == 'h') { fputs(HELP, stdout); exit(0); }
            fprintf(stderr, "Error: Unrecognized option: '%c'. Please see --help for more details\n", a[j]);
            exit(1);
        }
    }
    *first_file = argc;
}

int main(int argc, char **argv) {
    int first_file;
    usage_version_parse(argc, argv, &first_file);
    E.nbuf = argc - first_file;
    if (E.nbuf <= 0) E.nbuf = 1;
    E.bufs = calloc((size_t)E.nbuf, sizeof(Buffer));
    if (!E.bufs) return 1;
    if (first_file < argc) {
        for (int i = first_file; i < argc; i++) {
            E.bufs[i - first_file] = new_buffer(argv[i]);
            load_file(&E.bufs[i - first_file]);
        }
    } else {
        E.bufs[0] = new_buffer(NULL);
    }
    enable_raw();
    atexit(disable_raw);
    get_window();
    const char *alts = "\x1b[?1049h";
    write(STDOUT_FILENO, alts, strlen(alts));
    set_msg("Ctrl-? for help");
    for (;;) {
        draw();
        int c = read_key();
        process_key(c);
    }
    for (int i = 0; i < E.nbuf; i++) free_buffer(&E.bufs[i]);
    free(E.bufs);
    return 0;
}
