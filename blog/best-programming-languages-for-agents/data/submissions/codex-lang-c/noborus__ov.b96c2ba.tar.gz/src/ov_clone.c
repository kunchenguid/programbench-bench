#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

static const char *HELP_TEXT =
"ov is a feature rich pager(such as more/less).\n"
"It supports various compressed files(gzip, bzip2, zstd, lz4, and xz).\n"
"\n"
"Usage:\n"
"  ov [flags] [FILE]...\n"
"\n"
"Flags:\n"
"Short   Long                                    Purpose\n"
"  -l, --align                                   align the output columns for better readability\n"
"  -C, --alternate-rows                          alternately change the line color\n"
"      --caption string                          custom caption\n"
"  -i, --case-sensitive                          case-sensitive in search\n"
"  -d, --column-delimiter character              column delimiter character (default \",\")\n"
"  -c, --column-mode                             column mode\n"
"      --column-rainbow                          column mode to rainbow\n"
"      --column-width                            column mode for width\n"
"      --completion string                       generate completion script [bash|zsh|fish|powershell]\n"
"      --config file                             config file (default is $XDG_CONFIG_HOME/ov/config.yaml)\n"
"      --converter string                        converter [es|raw|align] (default \"es\")\n"
"      --debug                                   debug mode\n"
"      --disable-column-cycle                    disable column cycling\n"
"      --disable-mouse                           disable mouse support\n"
"  -e, --exec                                    command execution result instead of file\n"
"  -X, --exit-write                              output the current screen when exiting\n"
"  -a, --exit-write-after int                    number after the current lines when exiting\n"
"  -b, --exit-write-before int                   number before the current lines when exiting\n"
"      --filter string                           filter search pattern\n"
"  -A, --follow-all                              follow multiple files and show the most recently updated one\n"
"  -f, --follow-mode                             monitor file and display new content as it is written\n"
"      --follow-name                             follow mode to monitor by file name\n"
"      --follow-section                          section-by-section follow mode\n"
"      --force-screen                            display screen even when redirecting output\n"
"  -H, --header int                              number of header lines to be displayed constantly\n"
"  -Y, --header-column int                       number of columns to display as a vertical header\n"
"  -h, --help                                    help for ov\n"
"      --help-key                                display key bind information\n"
"      --hide-other-section                      hide other section\n"
"      --hscroll-width [int|int%|.int]           width to scroll horizontally [int|int%|.int] (default \"10%\")\n"
"      --incsearch[=true|false]                  incremental search (default true)\n"
"  -j, --jump-target [int|int%|.int|'section']   jump target [int|int%|.int|'section']\n"
"  -n, --line-number                             line number mode\n"
"      --list-view-modes                         list available view modes defined in the configuration file\n"
"      --memory-limit int                        number of chunks to limit in memory (default -1)\n"
"      --memory-limit-file int                   number of chunks to limit in memory for the file (default 100)\n"
"  -M, --multi-color strings                     comma separated words(regexp) to color .e.g. \"ERROR,WARNING\"\n"
"      --non-match-filter string                 filter non match search pattern\n"
"      --notify-eof int                          notify at the end of the file\n"
"      --pattern string                          search pattern\n"
"  -p, --plain                                   disable original decoration\n"
"  -F, --quit-if-one-screen                      quit if the output fits on one screen\n"
"  -r, --raw                                     raw escape sequences without processing\n"
"      --regexp-search                           regular expression search\n"
"      --ruler int                               display ruler (=0: none, =1: relative, =2: absolute)\n"
"      --section-delimiter regexp                regexp for section delimiter .e.g. \"^#\"\n"
"      --section-header                          enable section-delimiter line as Header\n"
"      --section-header-num int                  number of section header lines (default 1)\n"
"      --section-start int                       section start position\n"
"      --set-terminal-title                      set terminal title\n"
"      --skip-extract                            skip extracting compressed files\n"
"      --skip-lines int                          skip the number of lines\n"
"      --smart-case-sensitive                    smart case-sensitive in search\n"
"      --status-line[=true|false]                status line (default true)\n"
"  -x, --tab-width int                           tab stop width (default 8)\n"
"  -v, --version                                 display version information\n"
"  -y, --vertical-header int                     number of characters to display as a vertical header\n"
"  -m, --view-mode string                        apply predefined settings for a specific mode\n"
"  -T, --watch seconds                           watch mode interval(seconds)\n"
"  -w, --wrap[=true|false]                       wrap mode (default true)\n";

static const char *HELP_KEY_TEXT =
"ov is a feature rich pager\n"
" Key                            Action\n"
"\n"
"\tGeneral\n"
" [Escape], [q]                  * quit\n"
" [ctrl+c]                       * cancel\n"
" [Q]                            * output screen and quit\n"
" [ctrl+q]                       * set output screen and quit\n"
" [alt+shift+F8]                 * set output original screen and quit\n"
" [ctrl+z]                       * suspend\n"
" [alt+v]                        * edit current document\n"
" [h], [ctrl+F1], [ctrl+alt+c]   * display help screen\n"
" [ctrl+F2], [ctrl+alt+e]        * display log screen\n"
" [ctrl+l]                       * screen sync\n"
" [ctrl+f]                       * follow mode toggle\n"
" [ctrl+a]                       * follow all mode toggle\n"
" [ctrl+F8], [ctrl+alt+r]        * enable/disable mouse\n"
" [S]                            * save buffer to file\n"
"\n"
"\tMoving\n"
" [Enter], [Down], [ctrl+n]      * forward by one line\n"
" [Up], [ctrl+p]                 * backward by one line\n"
" [Home]                         * go to top of document\n"
" [End]                          * go to end of document\n"
" [PageDown], [ctrl+v]           * forward by page\n"
" [PageUp], [ctrl+b]             * backward by page\n"
" [ctrl+d]                       * forward a half page\n"
" [ctrl+u]                       * backward a half page\n"
" [left]                         * scroll left\n"
" [right]                        * scroll right\n"
" [ctrl+left]                    * scroll left half screen\n"
" [ctrl+right]                   * scroll right half screen\n"
" [alt+left]                     * scroll left specified width\n"
" [alt+right]                    * scroll right specified width\n"
" [shift+Home]                   * go to beginning of line\n"
" [shift+End]                    * go to end of line\n"
" [g]                            * go to line(input number or `.n` or `n%` allowed)\n"
" [,]                            * go to mark number(input number allowed)\n"
"\n"
"\tSidebar\n"
" [alt+h]                        * show/hide help in sidebar\n"
" [alt+m]                        * show mark list in sidebar\n"
" [alt+l]                        * show document list in sidebar\n"
" [shift+Up]                     * scroll up in sidebar\n"
" [shift+Down]                   * scroll down in sidebar\n"
" [shift+Left]                   * scroll left in sidebar\n"
" [shift+Right]                  * scroll right in sidebar\n"
"\n"
"\tMove document\n"
" []]                            * next document\n"
" [[]                            * previous document\n"
" [ctrl+k]                       * close current document\n"
" [K]                            * close all filtered documents\n"
"\n"
"\tMark position\n"
" [m]                            * mark current position\n"
" [M]                            * remove mark current position\n"
" [ctrl+delete]                  * remove all mark\n"
" [>]                            * move to next marked position\n"
" [<]                            * move to previous marked position\n"
" [*]                            * mark by pattern mode\n"
"\n"
"\tSearch\n"
" [/]                            * forward search mode\n"
" [?]                            * backward search mode\n"
" [n]                            * repeat forward search\n"
" [N]                            * repeat backward search\n"
" [&]                            * filter search mode\n"
"\n"
"\tChange display\n"
" [w], [W]                       * wrap/nowrap toggle\n"
" [c]                            * column mode toggle\n"
" [alt+o]                        * column width toggle\n"
" [ctrl+r]                       * column rainbow toggle\n"
" [C]                            * alternate rows of style toggle\n"
" [G]                            * line number toggle\n"
" [ctrl+e]                       * original decoration toggle(plain)\n"
" [alt+f]                        * align columns\n"
" [alt+r]                        * raw output\n"
" [alt+shift+F9]                 * ruler toggle\n"
" [ctrl+F10]                     * status line toggle\n"
"\n"
"general\n";

static const char *value_opts[] = {
    "column-delimiter","completion","config","converter","exit-write-after",
    "exit-write-before","filter","header","header-column","hscroll-width",
    "jump-target","memory-limit","memory-limit-file","multi-color",
    "non-match-filter","pattern","section-delimiter","section-header-num",
    "section-start","skip-lines","tab-width","vertical-header","view-mode",
    "watch", NULL
};

static const char *optional_value_opts[] = {
    "caption","notify-eof","ruler","incsearch","status-line","wrap", NULL
};

static const char *bool_opts[] = {
    "align","alternate-rows","case-sensitive","column-mode","column-rainbow",
    "column-width","debug","disable-column-cycle","disable-mouse","exec",
    "exit-write","follow-all","follow-mode","follow-name","follow-section",
    "force-screen","help-key","hide-other-section","line-number",
    "list-view-modes","plain","quit-if-one-screen","raw","regexp-search",
    "section-header","set-terminal-title","skip-extract",
    "smart-case-sensitive","version","help", NULL
};

static int in_list(const char *s, const char **list) {
    for (int i = 0; list[i]; i++) if (strcmp(s, list[i]) == 0) return 1;
    return 0;
}

static int copy_fd(int fd) {
    char buf[32768];
    for (;;) {
        ssize_t n = read(fd, buf, sizeof buf);
        if (n == 0) return 0;
        if (n < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        ssize_t off = 0;
        while (off < n) {
            ssize_t w = write(STDOUT_FILENO, buf + off, (size_t)(n - off));
            if (w < 0) {
                if (errno == EINTR) continue;
                return -1;
            }
            off += w;
        }
    }
}

static int copy_file(const char *path) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) {
        char errbuf[256];
        snprintf(errbuf, sizeof errbuf, "%s", strerror(errno));
        if (errbuf[0]) errbuf[0] = (char)tolower((unsigned char)errbuf[0]);
        fprintf(stderr, "Error: open %s: %s\n", path, errbuf);
        return 1;
    }
    int rc = copy_fd(fd);
    close(fd);
    if (rc < 0) {
        fprintf(stderr, "Error: %s\n", strerror(errno));
        return 1;
    }
    return 0;
}

static int is_bool_literal(const char *s) {
    return strcmp(s, "true") == 0 || strcmp(s, "false") == 0 ||
           strcmp(s, "1") == 0 || strcmp(s, "0") == 0 ||
           strcmp(s, "t") == 0 || strcmp(s, "f") == 0 ||
           strcmp(s, "TRUE") == 0 || strcmp(s, "FALSE") == 0;
}

static int print_completion(const char *shell) {
    if (!shell || (strcmp(shell, "bash") && strcmp(shell, "zsh") &&
                   strcmp(shell, "fish") && strcmp(shell, "powershell"))) {
        fprintf(stderr, "Error: requires one of the arguments bash/zsh/fish/powershell\n");
        return 1;
    }
    printf("# %s completion for ov                                   -*- shell-script -*-\n\n", shell);
    if (strcmp(shell, "zsh") == 0) {
        puts("#compdef ov\ncompdef _ov ov\n\n_ov() {\n    _arguments '*:filename:_files'\n}");
    } else if (strcmp(shell, "fish") == 0) {
        puts("complete -c ov -f -a '(__fish_complete_path)'");
    } else if (strcmp(shell, "powershell") == 0) {
        puts("Register-ArgumentCompleter -CommandName ov -ScriptBlock { param($wordToComplete) }");
    } else {
        puts("__start_ov() { COMPREPLY=(); }\ncomplete -F __start_ov ov");
    }
    return 0;
}

static int short_needs_value(char c) {
    return c == 'a' || c == 'b' || c == 'd' || c == 'H' || c == 'Y' ||
           c == 'j' || c == 'M' || c == 'x' || c == 'y' || c == 'm' || c == 'T';
}

int main(int argc, char **argv) {
    const char *first_file = NULL;
    for (int i = 1; i < argc; i++) {
        char *arg = argv[i];
        if (arg[0] != '-' || strcmp(arg, "-") == 0) {
            if (!first_file) first_file = arg;
            continue;
        }
        if (strcmp(arg, "--") == 0) {
            if (i + 1 < argc && !first_file) first_file = argv[i + 1];
            break;
        }
        if (strcmp(arg, "-h") == 0 || strcmp(arg, "--help") == 0) {
            fputs(HELP_TEXT, stdout);
            return 0;
        }
        if (strcmp(arg, "-v") == 0 || strcmp(arg, "--version") == 0) {
            puts("ov version dev rev:HEAD");
            return 0;
        }
        if (strcmp(arg, "--help-key") == 0) {
            fputs(HELP_KEY_TEXT, stdout);
            return 0;
        }
        if (strcmp(arg, "--list-view-modes") == 0) {
            puts("general");
            return 0;
        }
        if (strncmp(arg, "--completion=", 13) == 0) {
            return print_completion(arg + 13);
        }
        if (strcmp(arg, "--completion") == 0) {
            if (i + 1 >= argc) {
                fprintf(stderr, "Error: flag needs an argument: --completion\n");
                return 1;
            }
            return print_completion(argv[++i]);
        }
        if (strncmp(arg, "--wrap=", 7) == 0) {
            const char *v = arg + 7;
            if (!is_bool_literal(v)) {
                fprintf(stderr, "Error: invalid argument \"%s\" for \"-w, --wrap\" flag: strconv.ParseBool: parsing \"%s\": invalid syntax\n", v, v);
                return 1;
            }
            continue;
        }
        if (strncmp(arg, "--", 2) == 0) {
            char *name = arg + 2;
            char *eq = strchr(name, '=');
            char tmp[128];
            if (eq) {
                size_t len = (size_t)(eq - name);
                if (len >= sizeof tmp) len = sizeof tmp - 1;
                memcpy(tmp, name, len);
                tmp[len] = 0;
                name = tmp;
            }
            if (in_list(name, value_opts)) {
                if (!eq) {
                    if (i + 1 >= argc) {
                        fprintf(stderr, "Error: flag needs an argument: --%s\n", name);
                        return 1;
                    }
                    i++;
                }
                continue;
            }
            if (in_list(name, optional_value_opts) || in_list(name, bool_opts)) continue;
            fprintf(stderr, "Error: unknown flag: --%s\n", name);
            return 1;
        }
        if (arg[0] == '-' && arg[1]) {
            char c = arg[1];
            const char *known = "lCidceXAbAfFHpPrvn";
            if (short_needs_value(c)) {
                if (arg[2] == '\0') {
                    if (i + 1 >= argc) {
                        fprintf(stderr, "Error: flag needs an argument: '%c' in -%c\n", c, c);
                        return 1;
                    }
                    i++;
                }
                continue;
            }
            if (c == 'w') {
                if (arg[2] && !is_bool_literal(arg + 2)) {
                    fprintf(stderr, "Error: invalid argument \"%s\" for \"-w, --wrap\" flag: strconv.ParseBool: parsing \"%s\": invalid syntax\n", arg + 2, arg + 2);
                    return 1;
                }
                continue;
            }
            if (strchr(known, c)) continue;
            fprintf(stderr, "Error: unknown shorthand flag: '%c' in -%c\n", c, c);
            return 1;
        }
    }
    if (first_file) return copy_file(first_file);
    return copy_fd(STDIN_FILENO) < 0 ? 1 : 0;
}
