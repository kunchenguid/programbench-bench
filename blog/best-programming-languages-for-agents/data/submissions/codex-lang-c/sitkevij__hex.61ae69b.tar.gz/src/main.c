#include <errno.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#define VERSION "hx 0.7.0"

typedef struct {
    int cols;
    int cols_zero;
    long len;
    char fmt;
    int color;
    int prefix;
    char array;
    int func_set;
    int func_len;
    int places;
    const char *input;
} Opts;

static void print_help(const char *prog) {
    const char *slash = strrchr(prog, '/');
    prog = slash ? slash + 1 : prog;
    printf("Futuristic take on hexdump, made in Rust.\n\n\n");
    printf("Usage: %s [OPTIONS] [INPUTFILE]\n\n", prog);
    printf("Arguments:\n");
    printf("  [INPUTFILE]  Pass file path as an argument, or input data may be passed via stdin\n\n");
    printf("Options:\n");
    printf("  -c, --cols <columns>        Set column length\n");
    printf("  -l, --len <len>             Set <len> bytes to read\n");
    printf("  -f, --format <format>       Set format of octet: Octal (o), LowerHex (x), UpperHex (X), Binary (b) [possible values: o, x, X, b]\n");
    printf("  -t, --color <color>         Set color tint terminal output. 0 to disable, 1 to enable [possible values: 0, 1]\n");
    printf("  -a, --array <array_format>  Set source code format output: rust (r), C (c), golang (g), python (p), kotlin (k), java (j), swift (s), fsharp (f) [possible values: r, c, g, p, k, j, s, f]\n");
    printf("  -u, --func <func_length>    Set function wave length\n");
    printf("  -p, --places <func_places>  Set function wave output decimal places\n");
    printf("  -r, --prefix <prefix>       Include prefix in output (e.g. 0x/0b/0o). 0 to disable, 1 to enable [possible values: 0, 1]\n");
    printf("  -h, --help                  Print help\n");
    printf("  -V, --version               Print version\n");
}

static int parse_long(const char *s, long *out, const char *flag, const char *name) {
    char *end = NULL;
    errno = 0;
    long v = strtol(s, &end, 10);
    if (errno || !s[0] || *end) {
        fprintf(stderr, "%s, --%s <integer> expected. ParseIntError { kind: InvalidDigit }\n", flag, name);
        fprintf(stderr, "error: invalid digit found in string\n");
        return 1;
    }
    *out = v;
    return 0;
}

static int need_value(int *i, int argc, char **argv, const char **val, const char *arg) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.\n", arg);
        return 1;
    }
    *val = argv[++(*i)];
    return 0;
}

static int parse_args(int argc, char **argv, Opts *o) {
    o->cols = 10; o->cols_zero = 0; o->len = -1; o->fmt = 'x'; o->color = isatty(STDOUT_FILENO) ? 1 : 0; o->prefix = 1;
    o->array = 0; o->func_set = 0; o->func_len = 0; o->places = 4; o->input = NULL;
    if (getenv("NO_COLOR")) o->color = 0;
    for (int i=1;i<argc;i++) {
        const char *a = argv[i], *v = NULL;
        char optbuf[64];
        const char *opt = a;
        char *eq = (strncmp(a, "--", 2) == 0) ? strchr(a, '=') : NULL;
        if (eq) {
            size_t l = (size_t)(eq - a);
            if (l >= sizeof(optbuf)) l = sizeof(optbuf) - 1;
            memcpy(optbuf, a, l); optbuf[l] = 0;
            opt = optbuf; v = eq + 1;
        } else if (a[0]=='-' && a[1] && a[2] && strchr("cluftarp", a[1])) {
            optbuf[0] = '-'; optbuf[1] = a[1]; optbuf[2] = 0;
            opt = optbuf; v = a + 2;
        }
        if (!strcmp(opt,"-h") || !strcmp(opt,"--help")) { print_help(argv[0]); exit(0); }
        if (!strcmp(opt,"-V") || !strcmp(opt,"--version")) { printf(VERSION "\n"); exit(0); }
        if (!strcmp(opt,"-c") || !strcmp(opt,"--cols")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; long x; if (parse_long(v,&x,"-c","cols")) return 1; o->cols_zero = (x <= 0); o->cols = x<=0?1:(int)x; continue; }
        if (!strcmp(opt,"-l") || !strcmp(opt,"--len")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; long x; if (parse_long(v,&x,"-l","len")) return 1; o->len = x<=0?-1:x; continue; }
        if (!strcmp(opt,"-u") || !strcmp(opt,"--func")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; long x; if (parse_long(v,&x,"-u","func")) return 1; o->func_set=1; o->func_len=(int)x; continue; }
        if (!strcmp(opt,"-p") || !strcmp(opt,"--places")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; long x; if (parse_long(v,&x,"-p","places")) return 1; o->places=(int)x; continue; }
        if (!strcmp(opt,"-t") || !strcmp(opt,"--color")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; if (strcmp(v,"0")&&strcmp(v,"1")) { fprintf(stderr,"error: invalid value '%s' for '--color <color>'\n  [possible values: 0, 1]\n\nFor more information, try '--help'.\n",v); return 2;} o->color=atoi(v); continue; }
        if (!strcmp(opt,"-r") || !strcmp(opt,"--prefix")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; if (strcmp(v,"0")&&strcmp(v,"1")) { fprintf(stderr,"error: invalid value '%s' for '--prefix <prefix>'\n  [possible values: 0, 1]\n\nFor more information, try '--help'.\n",v); return 2;} o->prefix=atoi(v); continue; }
        if (!strcmp(opt,"-f") || !strcmp(opt,"--format")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; if (strlen(v)!=1 || !strchr("oxXb",v[0])) { fprintf(stderr,"error: invalid value '%s' for '--format <format>'\n  [possible values: o, x, X, b]\n\nFor more information, try '--help'.\n",v); return 2;} o->fmt=v[0]; continue; }
        if (!strcmp(opt,"-a") || !strcmp(opt,"--array")) { if (!v && need_value(&i,argc,argv,&v,a)) return 1; if (strlen(v)!=1 || !strchr("rcgpkjsf",v[0])) { fprintf(stderr,"error: invalid value '%s' for '--array <array_format>'\n  [possible values: r, c, g, p, k, j, s, f]\n\nFor more information, try '--help'.\n",v); return 2;} o->array=v[0]; continue; }
        if (a[0]=='-') { fprintf(stderr,"error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'.\n",a,a,a); return 2; }
        if (!o->input) o->input = a; else { fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [INPUTFILE]\n\nFor more information, try '--help'.\n",a); return 2; }
    }
    return 0;
}

static unsigned char *read_all(const char *path, size_t *len, long limit) {
    FILE *f = path ? fopen(path,"rb") : stdin;
    if (!f) { fprintf(stderr,"error: %s (os error %d)\n", strerror(errno), errno); return NULL; }
    size_t cap = 4096, n = 0; unsigned char *buf = malloc(cap ? cap : 1);
    if (!buf) exit(1);
    while (limit < 0 || (long)n < limit) {
        if (n == cap) { cap *= 2; buf = realloc(buf, cap); if (!buf) exit(1); }
        size_t want = cap - n; if (limit >= 0 && want > (size_t)(limit - (long)n)) want = (size_t)(limit - (long)n);
        size_t r = fread(buf+n,1,want,f); n += r;
        if (r < want) break;
    }
    if (path) fclose(f);
    *len = n; return buf;
}

static void format_token(char *out, unsigned char b, Opts *o) {
    if (o->fmt=='b') {
        char bits[9]; for (int i=7;i>=0;i--) bits[7-i] = (b&(1<<i))?'1':'0'; bits[8]=0;
        sprintf(out, "%s%s", o->prefix?"0b":"", bits);
    } else if (o->fmt=='o') sprintf(out, o->prefix?"0o%04o":"%04o", b);
    else if (o->fmt=='X') sprintf(out, o->prefix?"0x%02X":"%02X", b);
    else sprintf(out, o->prefix?"0x%02x":"%02x", b);
}
static int printable(unsigned char b) { return b >= 32 && b <= 126; }
static void print_colored_token(const char *s, unsigned char b, int color) {
    if (color) printf("\033[38;5;%um%s\033[0m", b, s); else printf("%s", s);
}
static void print_colored_char(char c, unsigned char b, int color) {
    if (color) printf("\033[38;5;%um%c\033[0m", b, c); else putchar(c);
}
static void dump(unsigned char *buf, size_t n, Opts *o) {
    int cols = o->cols;
    size_t off = 0;
    if (n == 0) {
        printf("0x%06x: ", 0);
        for (int i=0;i<(o->cols_zero?0:cols*5);i++) putchar(' ');
        putchar('\n');
        printf("   bytes: 0\n");
        return;
    }
    while (off < n) {
        size_t rem = n - off, cnt = rem < (size_t)cols ? rem : (size_t)cols;
        printf("0x%06zx: ", off);
        for (size_t i=0;i<cnt;i++) { char tok[32]; format_token(tok, buf[off+i], o); print_colored_token(tok, buf[off+i], o->color); if (i + 1 < (size_t)cols) putchar(' '); }
        int missing = cols - (int)cnt;
        int pad = missing ? missing * 5 : 1;
        for (int i=0;i<pad;i++) putchar(' ');
        for (size_t i=0;i<cnt;i++) print_colored_char(printable(buf[off+i])?(char)buf[off+i]:'.', buf[off+i], o->color);
        putchar('\n'); off += cnt;
    }
    if (n > 0 && n % (size_t)cols == 0) {
        printf("0x%06zx: ", n);
        for (int i=0;i<(o->cols_zero?0:cols*5);i++) putchar(' ');
        putchar('\n');
    }
    printf("   bytes: %zu\n", n);
}

static void array_out(unsigned char *b, size_t n, char a) {
    if (a=='r') printf("let ARRAY: [u8; %zu] = [\n", n);
    else if (a=='c') printf("unsigned char ARRAY[%zu] = {\n", n);
    else if (a=='g') printf("a := [%zu]byte{\n", n);
    else if (a=='p') printf("a = [\n");
    else if (a=='k') printf("val a = byteArrayOf(\n");
    else if (a=='j') printf("byte[] a = new byte[]{\n");
    else if (a=='s') printf("let a: [UInt8] = [\n");
    else if (a=='f') printf("let a = [|\n");
    for (size_t i=0;i<n;i++) {
        if (i % 10 == 0) printf("    ");
        if (a=='f') printf("0x%02xuy%s", b[i], (i+1<n)?"; ":"");
        else printf("0x%02x%s", b[i], (i+1<n || a=='g')?", ":"");
        if (i % 10 == 9 && i+1<n) printf("\n");
    }
    if (n) printf("\n");
    if (a=='r') printf("];\n");
    else if (a=='p' || a=='s') printf("]\n");
    else if (a=='c' || a=='j') printf("};\n");
    else if (a=='g') printf("}\n");
    else if (a=='k') printf(")\n");
    else if (a=='f') printf("|]\n");
}

static void wave(int len, int places) {
    if (len <= 0) { putchar('\n'); return; }
    if (places < 0) places = 0;
    if (places > 20) places = 20;
    char fmt[32]; sprintf(fmt, "%%.%df,", places);
    for (int i=0;i<len;i++) {
        const double pi = 3.14159265358979323846;
        double v = sin(((double)i * pi) / ((double)len * 2.0));
        printf(fmt, v);
        if (i % 10 == 9 && i+1<len) putchar('\n');
    }
    putchar('\n');
}

int main(int argc, char **argv) {
    Opts o; int rc = parse_args(argc, argv, &o); if (rc) return rc;
    if (o.func_set) { wave(o.func_len, o.places); return 0; }
    size_t n = 0; unsigned char *buf = read_all(o.input, &n, o.len); if (!buf) return 1;
    if (o.array) array_out(buf, n, o.array); else dump(buf, n, &o);
    free(buf); return 0;
}
