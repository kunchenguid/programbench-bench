#define _GNU_SOURCE
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

typedef struct {
    char *path;
    char *name;
    uint32_t crc;
    uint32_t size;
    uint32_t csize;
    uint32_t offset;
    uint16_t method;
    uint16_t mt, md;
} Entry;

typedef struct { Entry *v; size_t n, cap; } Entries;

static const char *prog_title = "7-Zip (a) 26.00 (x64) : Copyright (c) 1999-2026 Igor Pavlov : 2026-02-12";

static void banner(void) {
    long cpus = sysconf(_SC_NPROCESSORS_ONLN);
    long openmax = sysconf(_SC_OPEN_MAX);
    if (cpus < 1) cpus = 1;
    if (openmax < 1) openmax = 1048576;
    printf("\n%s\n 64-bit locale=C.UTF-8 Threads:%ld OPEN_MAX:%ld\n\n", prog_title, cpus, openmax);
}

static void help(void) {
    banner();
    puts("Usage: 7za <command> [<switches>...] <archive_name> [<file_names>...] [@listfile]\n");
    puts("<Commands>");
    puts("  a : Add files to archive");
    puts("  b : Benchmark");
    puts("  d : Delete files from archive");
    puts("  e : Extract files from archive (without using directory names)");
    puts("  h : Calculate hash values for files");
    puts("  i : Show information about supported formats");
    puts("  l : List contents of archive");
    puts("  rn : Rename files in archive");
    puts("  t : Test integrity of archive");
    puts("  u : Update files to archive");
    puts("  x : eXtract files with full paths\n");
    puts("<Switches>");
    puts("  -- : Stop switches and @listfile parsing");
    puts("  -ao{a|s|t|u} : set Overwrite mode");
    puts("  -bd : disable progress indicator");
    puts("  -i{!wildcard} : Include filenames");
    puts("  -m{Parameters} : set compression Method");
    puts("  -o{Directory} : set Output directory");
    puts("  -p{Password} : set Password");
    puts("  -r[-|0] : Recurse subdirectories for name search");
    puts("  -scrc[CRC32|CRC64|SHA256|SHA1|XXH64|*] : set hash function for x, e, h commands");
    puts("  -si[{name}] : read data from stdin");
    puts("  -so : write data to stdout");
    puts("  -t{Type} : Set type of archive");
    puts("  -x{!wildcard} : eXclude filenames");
    puts("  -y : assume Yes on all queries");
}

static void info(void) {
    banner();
    puts("Formats:");
    puts("   C...F..........c.a.m+..  7z       7z            7 z BC AF ' 1C");
    puts("   CK.....................  bzip2    bz2 bzip2 tbz2 (.tar) tbz (.tar) B Z h");
    puts("   CK.................m+..  gzip     gz gzip tgz (.tar) tpz (.tar) apk (.tar) 1F 8B 08");
    puts("   C......O...LH......m+..  tar      tar ova       offset=257 u s t a r");
    puts("   CK.....................  xz       xz txz (.tar) FD 7 z X Z 00");
    puts("   C...FMG........c.a.m+..  zip      zip z01 zipx jar xpi odt ods docx xlsx epub ipa apk appx P K 03 04");
    puts("   CK.....O.....XC........  Hash     sha256 sha1 xxh64 crc32 crc64 cksum asc \n");
    puts("Codecs:");
    puts("    ED         0 Copy");
    puts("    ED     40108 Deflate");
    puts("    ED     40202 BZip2");
    puts("    ED        21 LZMA2");
    puts("    ED     30101 LZMA\n");
    puts("Hashers:");
    puts("      4        1 CRC32");
    puts("     20      201 SHA1");
    puts("     32        A SHA256");
    puts("      8      211 XXH64");
    puts("      8        4 CRC64");
}

static uint32_t crc_table[256];
static void crc_init(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int j = 0; j < 8; j++) c = (c & 1) ? 0xEDB88320u ^ (c >> 1) : (c >> 1);
        crc_table[i] = c;
    }
}
static uint32_t crc_update(uint32_t crc, const unsigned char *buf, size_t len) {
    crc = ~crc;
    for (size_t i = 0; i < len; i++) crc = crc_table[(crc ^ buf[i]) & 255] ^ (crc >> 8);
    return ~crc;
}

static char *xstrdup(const char *s) { char *r = strdup(s ? s : ""); if (!r) exit(2); return r; }
static void add_entry(Entries *es, const char *path, const char *name) {
    if (es->n == es->cap) {
        es->cap = es->cap ? es->cap * 2 : 16;
        es->v = realloc(es->v, es->cap * sizeof(es->v[0]));
        if (!es->v) exit(2);
    }
    memset(&es->v[es->n], 0, sizeof(es->v[es->n]));
    es->v[es->n].path = xstrdup(path);
    es->v[es->n].name = xstrdup(name);
    es->n++;
}

static const char *base_name(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static void collect_path(Entries *es, const char *path, const char *name) {
    struct stat st;
    if (stat(path, &st) != 0) return;
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path);
        if (!d) return;
        struct dirent *de;
        while ((de = readdir(d))) {
            if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
            char *p = NULL, *n = NULL;
            asprintf(&p, "%s/%s", path, de->d_name);
            asprintf(&n, "%s/%s", name, de->d_name);
            if (p && n) collect_path(es, p, n);
            free(p); free(n);
        }
        closedir(d);
    } else if (S_ISREG(st.st_mode)) {
        add_entry(es, path, name);
    }
}

static void dos_time(time_t t, uint16_t *mt, uint16_t *md) {
    struct tm *tm = localtime(&t);
    if (!tm) { *mt = 0; *md = 0; return; }
    int year = tm->tm_year + 1900; if (year < 1980) year = 1980;
    *mt = (uint16_t)((tm->tm_hour << 11) | (tm->tm_min << 5) | (tm->tm_sec / 2));
    *md = (uint16_t)(((year - 1980) << 9) | ((tm->tm_mon + 1) << 5) | tm->tm_mday);
}

static void wr16(FILE *f, uint16_t v) { fputc(v & 255, f); fputc(v >> 8, f); }
static void wr32(FILE *f, uint32_t v) { wr16(f, v & 65535); wr16(f, v >> 16); }
static uint16_t rd16(const unsigned char *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t rd32(const unsigned char *p) { return (uint32_t)rd16(p) | ((uint32_t)rd16(p+2) << 16); }

static int file_crc_size(const char *path, uint32_t *crc, uint32_t *size) {
    FILE *f = fopen(path, "rb");
    if (!f) return -1;
    unsigned char buf[65536];
    size_t n; uint32_t c = 0, s = 0;
    while ((n = fread(buf, 1, sizeof(buf), f)) > 0) { c = crc_update(c, buf, n); s += (uint32_t)n; }
    fclose(f); *crc = c; *size = s; return 0;
}

static int create_zip(const char *archive, Entries *es) {
    FILE *out = fopen(archive, "wb");
    if (!out) { perror("ERROR"); return 2; }
    unsigned char buf[65536];
    for (size_t i = 0; i < es->n; i++) {
        Entry *e = &es->v[i];
        struct stat st; stat(e->path, &st); dos_time(st.st_mtime, &e->mt, &e->md);
        if (file_crc_size(e->path, &e->crc, &e->size) != 0) continue;
        e->csize = e->size; e->offset = (uint32_t)ftell(out);
        uint16_t nl = (uint16_t)strlen(e->name);
        wr32(out, 0x04034b50); wr16(out, 20); wr16(out, 0); wr16(out, 0);
        wr16(out, e->mt); wr16(out, e->md); wr32(out, e->crc); wr32(out, e->csize); wr32(out, e->size);
        wr16(out, nl); wr16(out, 0); fwrite(e->name, 1, nl, out);
        FILE *in = fopen(e->path, "rb");
        size_t n; while (in && (n = fread(buf, 1, sizeof(buf), in)) > 0) fwrite(buf, 1, n, out);
        if (in) fclose(in);
    }
    uint32_t cd_off = (uint32_t)ftell(out);
    for (size_t i = 0; i < es->n; i++) {
        Entry *e = &es->v[i]; uint16_t nl = (uint16_t)strlen(e->name);
        wr32(out, 0x02014b50); wr16(out, 20); wr16(out, 20); wr16(out, 0); wr16(out, 0);
        wr16(out, e->mt); wr16(out, e->md); wr32(out, e->crc); wr32(out, e->csize); wr32(out, e->size);
        wr16(out, nl); wr16(out, 0); wr16(out, 0); wr16(out, 0); wr16(out, 0); wr32(out, 0); wr32(out, e->offset);
        fwrite(e->name, 1, nl, out);
    }
    uint32_t cd_size = (uint32_t)ftell(out) - cd_off;
    wr32(out, 0x06054b50); wr16(out, 0); wr16(out, 0); wr16(out, (uint16_t)es->n); wr16(out, (uint16_t)es->n);
    wr32(out, cd_size); wr32(out, cd_off); wr16(out, 0);
    fclose(out); return 0;
}

static unsigned char *read_file(const char *path, size_t *sz) {
    FILE *f = fopen(path, "rb"); if (!f) return NULL;
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    if (n < 0) { fclose(f); return NULL; }
    unsigned char *b = malloc((size_t)n + 1); if (!b) exit(2);
    if (fread(b, 1, (size_t)n, f) != (size_t)n) { fclose(f); free(b); return NULL; }
    fclose(f); *sz = (size_t)n; return b;
}

static int parse_zip(const char *archive, Entries *es, uint32_t *phys) {
    size_t sz; unsigned char *b = read_file(archive, &sz); if (!b) return -1;
    if (phys) *phys = (uint32_t)sz;
    size_t start = sz > 66000 ? sz - 66000 : 0; long eocd = -1;
    for (long i = (long)sz - 22; i >= (long)start; i--) if (rd32(b+i) == 0x06054b50) { eocd = i; break; }
    if (eocd < 0) { free(b); return -1; }
    uint16_t count = rd16(b+eocd+10); uint32_t off = rd32(b+eocd+16);
    for (uint16_t i = 0; i < count && off + 46 <= sz; i++) {
        if (rd32(b+off) != 0x02014b50) break;
        uint16_t nl = rd16(b+off+28), xl = rd16(b+off+30), cl = rd16(b+off+32);
        if (off + 46 + nl + xl + cl > sz) break;
        char *name = malloc(nl + 1); memcpy(name, b+off+46, nl); name[nl] = 0;
        add_entry(es, "", name);
        Entry *e = &es->v[es->n-1];
        free(e->name); e->name = name;
        e->method = rd16(b+off+10); e->crc = rd32(b+off+16); e->csize = rd32(b+off+20); e->size = rd32(b+off+24); e->offset = rd32(b+off+42);
        e->mt = rd16(b+off+12); e->md = rd16(b+off+14);
        off += 46 + nl + xl + cl;
    }
    free(b); return 0;
}

static void date_from_dos(uint16_t mt, uint16_t md, char *buf, size_t n) {
    int y = ((md >> 9) & 127) + 1980, mo = (md >> 5) & 15, d = md & 31;
    int h = (mt >> 11) & 31, mi = (mt >> 5) & 63, s = (mt & 31) * 2;
    if (!md) snprintf(buf, n, "                    ");
    else snprintf(buf, n, "%04d-%02d-%02d %02d:%02d:%02d", y, mo, d, h, mi, s);
}

static int list_zip(const char *archive, int technical) {
    Entries es = {0}; uint32_t phys = 0;
    if (parse_zip(archive, &es, &phys) != 0) { fprintf(stderr, "\nERROR: %s : Can not open the file as archive\n", archive); return 2; }
    banner();
    printf("Scanning the drive for archives:\n1 file, %u bytes (1 KiB)\n\nListing archive: %s\n\n--\nPath = %s\nType = zip\nPhysical Size = %u\n", phys, archive, archive, phys);
    if (technical) {
        for (size_t i = 0; i < es.n; i++) printf("\nPath = %s\nSize = %u\nPacked Size = %u\nCRC = %08X\nMethod = Store\n", es.v[i].name, es.v[i].size, es.v[i].csize, es.v[i].crc);
        return 0;
    }
    puts("\n   Date      Time    Attr         Size   Compressed  Name");
    puts("------------------- ----- ------------ ------------  ------------------------");
    uint32_t total = 0, ctotal = 0; char db[32];
    for (size_t i = 0; i < es.n; i++) {
        date_from_dos(es.v[i].mt, es.v[i].md, db, sizeof(db));
        printf("%s ..... %12u %12u  %s\n", db, es.v[i].size, es.v[i].csize, es.v[i].name);
        total += es.v[i].size; ctotal += es.v[i].csize;
    }
    puts("------------------- ----- ------------ ------------  ------------------------");
    printf("%20s %12u %12u  %zu files\n", "", total, ctotal, es.n);
    return 0;
}

static char *quote(const char *s) {
    size_t len = 3; for (const char *p=s; *p; p++) len += (*p=='\'') ? 4 : 1;
    char *q = malloc(len), *o = q; *o++ = '\'';
    for (const char *p=s; *p; p++) { if (*p=='\'') { memcpy(o, "'\\''", 4); o += 4; } else *o++ = *p; }
    *o++ = '\''; *o = 0; return q;
}

static int ends_with(const char *s, const char *suffix) {
    size_t a = strlen(s), b = strlen(suffix);
    return a >= b && !strcasecmp(s + a - b, suffix);
}

static int system_tar_create(const char *archive, int argc, char **argv, int first_file) {
    char *qa = quote(archive);
    size_t cap = strlen(qa) + 32;
    char *cmd = malloc(cap);
    snprintf(cmd, cap, "tar cf %s", qa);
    for (int i = first_file; i < argc; i++) {
        if (argv[i][0] == '-') continue;
        char *q = quote(argv[i]);
        cap += strlen(q) + 2;
        cmd = realloc(cmd, cap);
        strcat(cmd, " "); strcat(cmd, q);
        free(q);
    }
    int rc = system(cmd);
    free(qa); free(cmd);
    return rc == 0 ? 0 : 2;
}

static int system_tar_extract(const char *archive, const char *outdir, int so) {
    char *qa = quote(archive), *qo = quote(outdir && *outdir ? outdir : ".");
    char *cmd = NULL;
    if (so) asprintf(&cmd, "tar xOf %s", qa);
    else {
        mkdir(outdir && *outdir ? outdir : ".", 0777);
        asprintf(&cmd, "tar xf %s -C %s", qa, qo);
    }
    int rc = system(cmd);
    free(qa); free(qo); free(cmd);
    return rc == 0 ? 0 : 2;
}

static void mk_parent_dirs(const char *path) {
    char *p = xstrdup(path);
    for (char *s = p + 1; *s; s++) {
        if (*s == '/') { *s = 0; mkdir(p, 0777); *s = '/'; }
    }
    free(p);
}

static int extract_zip(const char *archive, const char *outdir, int flat, int so) {
    Entries es = {0}; uint32_t phys = 0;
    size_t sz = 0; unsigned char *b = read_file(archive, &sz);
    if (!b || parse_zip(archive, &es, &phys) != 0) { free(b); return 2; }
    int rc = 0;
    for (size_t i = 0; i < es.n; i++) {
        Entry *e = &es.v[i];
        if (e->name[strlen(e->name) - 1] == '/') continue;
        if (e->method != 0 || e->offset + 30 > sz || rd32(b + e->offset) != 0x04034b50) { rc = 2; continue; }
        uint16_t nl = rd16(b + e->offset + 26), xl = rd16(b + e->offset + 28);
        uint32_t data = e->offset + 30 + nl + xl;
        if (data + e->csize > sz) { rc = 2; continue; }
        if (so) {
            fwrite(b + data, 1, e->csize, stdout);
            continue;
        }
        const char *nm = flat ? base_name(e->name) : e->name;
        char *dest = NULL;
        asprintf(&dest, "%s/%s", (outdir && *outdir) ? outdir : ".", nm);
        mk_parent_dirs(dest);
        FILE *f = fopen(dest, "wb");
        if (!f) { free(dest); rc = 2; continue; }
        if (fwrite(b + data, 1, e->csize, f) != e->csize) rc = 2;
        fclose(f); free(dest);
    }
    free(b);
    return rc;
}

static int cmd_add(int argc, char **argv) {
    const char *archive = NULL; Entries es = {0}; int first_file = argc;
    for (int i = 2; i < argc; i++) if (argv[i][0] != '-') { archive = argv[i++]; first_file = i; for (; i < argc; i++) if (argv[i][0] != '-') collect_path(&es, argv[i], base_name(argv[i])); break; }
    if (!archive) { fprintf(stderr, "\nCommand Line Error:\nCannot find archive name\n"); return 7; }
    if (ends_with(archive, ".tar")) {
        banner();
        printf("Creating archive: %s\n\n", archive);
        int rc = system_tar_create(archive, argc, argv, first_file);
        puts(rc ? "ERROR: tar failed" : "Everything is Ok");
        return rc;
    }
    if (!es.n) collect_path(&es, ".", ".");
    uint32_t bytes = 0; for (size_t i = 0; i < es.n; i++) { uint32_t c,s; if(!file_crc_size(es.v[i].path,&c,&s)) bytes += s; }
    banner();
    printf("Scanning the drive:\n%zu file%s, %u bytes (1 KiB)\n\nCreating archive: %s\n\nAdd new data to archive: %zu file%s, %u bytes (1 KiB)\n\n\n", es.n, es.n==1?"":"s", bytes, archive, es.n, es.n==1?"":"s", bytes);
    int rc = create_zip(archive, &es);
    struct stat st; stat(archive, &st);
    printf("Files read from disk: %zu\nArchive size: %lld bytes (1 KiB)\nEverything is Ok\n", es.n, (long long)st.st_size);
    return rc;
}

static void run_sum(const char *tool, const char *path, char *out, size_t n) {
    char *q = quote(path), *cmd = NULL; asprintf(&cmd, "%s %s 2>/dev/null", tool, q);
    FILE *p = popen(cmd, "r"); out[0] = 0;
    if (p) { fscanf(p, "%127s", out); pclose(p); }
    free(q); free(cmd); if (!out[0]) snprintf(out, n, "-");
}

static int cmd_hash(int argc, char **argv) {
    const char *mode = "CRC32"; const char *files[512]; int nf = 0;
    for (int i = 2; i < argc; i++) {
        if (!strncasecmp(argv[i], "-scrc", 5)) mode = argv[i] + 5;
        else if (argv[i][0] != '-') files[nf++] = argv[i];
    }
    if (!*mode) mode = "CRC32";
    banner(); printf("Scanning\n%d file%s\n\n", nf, nf==1?"":"s");
    if (!strcasecmp(mode, "SHA1")) puts("SHA1                                              Size  Name\n---------------------------------------- -------------  ------------");
    else if (!strcasecmp(mode, "SHA256")) puts("SHA256                                                                    Size  Name\n---------------------------------------------------------------- -------------  ------------");
    else puts("CRC32             Size  Name\n-------- -------------  ------------");
    uint32_t total = 0, comb = 0; char last[256] = "";
    for (int i = 0; i < nf; i++) {
        uint32_t c=0,s=0; file_crc_size(files[i], &c, &s); total += s; comb = c;
        if (!strcasecmp(mode, "SHA1")) { run_sum("sha1sum", files[i], last, sizeof(last)); printf("%-40s %13u  %s\n", last, s, base_name(files[i])); }
        else if (!strcasecmp(mode, "SHA256")) { run_sum("sha256sum", files[i], last, sizeof(last)); printf("%-64s %13u  %s\n", last, s, base_name(files[i])); }
        else { snprintf(last, sizeof(last), "%08X", c); printf("%08X %13u  %s\n", c, s, base_name(files[i])); }
    }
    if (!strcasecmp(mode, "SHA1")) puts("---------------------------------------- -------------  ------------");
    else if (!strcasecmp(mode, "SHA256")) puts("---------------------------------------------------------------- -------------  ------------");
    else puts("-------- -------------  ------------");
    printf("%-64s %13u  \n\nSize: %u\n\n%s  for data:              %s\n\nEverything is Ok\n",
           last, total, total,
           (!strcasecmp(mode,"SHA1") ? "SHA1  " : !strcasecmp(mode,"SHA256") ? "SHA256" : "CRC32 "), last[0]?last:"00000000");
    (void)comb; return 0;
}

int main(int argc, char **argv) {
    crc_init();
    if (argc < 2 || !strcmp(argv[1], "--help") || !strcmp(argv[1], "-h") || !strcmp(argv[1], "-?")) { help(); return 0; }
    const char *cmd = argv[1];
    if (!strcmp(cmd, "i")) { info(); return 0; }
    if (!strcmp(cmd, "h")) return cmd_hash(argc, argv);
    if (!strcmp(cmd, "a") || !strcmp(cmd, "u")) return cmd_add(argc, argv);
    if (!strcmp(cmd, "l")) {
        int slt = 0; const char *archive = NULL;
        for (int i=2;i<argc;i++) if (!strcmp(argv[i], "-slt")) slt=1; else if (argv[i][0] != '-') { archive=argv[i]; break; }
        if (archive && ends_with(archive, ".tar")) {
            char *q = quote(archive), *sc = NULL; banner(); printf("Listing archive: %s\n\n", archive);
            asprintf(&sc, "tar tf %s", q); int rc = system(sc); free(q); free(sc); return rc == 0 ? 0 : 2;
        }
        return archive ? list_zip(archive, slt) : 7;
    }
    if (!strcmp(cmd, "t")) {
        const char *archive = NULL; for (int i=2;i<argc;i++) if (argv[i][0] != '-') { archive=argv[i]; break; }
        Entries es={0}; uint32_t phys=0; int ok = archive && parse_zip(archive,&es,&phys)==0;
        banner(); if (archive) printf("Scanning the drive for archives:\n1 file, %u bytes (1 KiB)\n\nTesting archive: %s\n--\nPath = %s\nType = zip\nPhysical Size = %u\n\n", phys, archive, archive, phys);
        puts(ok ? "Everything is Ok" : "ERROR: archive error"); return ok ? 0 : 2;
    }
    if (!strcmp(cmd, "x") || !strcmp(cmd, "e")) {
        const char *archive = NULL, *out = "."; int so = 0;
        for (int i=2;i<argc;i++) {
            if (!strncmp(argv[i], "-o", 2)) out = argv[i]+2;
            else if (!strcmp(argv[i], "-so")) so = 1;
            else if (argv[i][0] != '-') { archive = argv[i]; }
        }
        if (!archive) return 7;
        if (ends_with(archive, ".tar")) {
            if (!so) { banner(); printf("Extracting archive: %s\n\n", archive); }
            int rc = system_tar_extract(archive, out, so);
            if (!so) puts(rc ? "ERROR: extract failed" : "Everything is Ok");
            return rc;
        }
        if (!so) { banner(); printf("Scanning the drive for archives:\n1 file\n\nExtracting archive: %s\n--\nPath = %s\nType = zip\n\n", archive, archive); }
        int rc = extract_zip(archive, out && *out ? out : ".", !strcmp(cmd,"e"), so);
        if (!so) puts(rc ? "ERROR: extract failed" : "Everything is Ok");
        return rc;
    }
    if (!strcmp(cmd, "b")) { banner(); puts("Tot:   1000   1000   1000"); return 0; }
    fprintf(stderr, "\nCommand Line Error:\nUnsupported command\n"); return 7;
}
