#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

typedef enum { V_NULL, V_STR, V_NUM, V_BOOL, V_ARR, V_OBJ } VType;
typedef struct Val Val;
typedef struct Pair { char *k; Val *v; } Pair;
struct Val {
  VType t;
  char *s;
  double n;
  int b;
  Val **a; int alen;
  Pair *o; int olen;
};

typedef struct { char *p; size_t len, cap; } Buf;
typedef struct { char *name; char *url; Val *cache; } DS;
typedef struct { char *name; Val *v; } Var;
typedef struct {
  DS *ds; int nds;
  Var *vars; int nvars;
  Val *dot;
  int missing_error;
  char *left;
  char *right;
} Ctx;

static void die(const char *fmt, ...) {
  va_list ap; va_start(ap, fmt);
  fprintf(stderr, "{\"time\":\"\",\"level\":\"ERROR\",\"msg\":\"\",\"err\":\"");
  vfprintf(stderr, fmt, ap);
  fprintf(stderr, "\"}\n");
  va_end(ap);
  exit(1);
}
static char *xstrdup(const char *s){ if(!s) return NULL; char *r=strdup(s); if(!r) exit(2); return r; }
static void *xrealloc(void *p,size_t n){ void *r=realloc(p,n?n:1); if(!r) exit(2); return r; }
static void binit(Buf *b){ b->cap=256; b->len=0; b->p=malloc(b->cap); b->p[0]=0; }
static void baddn(Buf *b,const char*s,size_t n){ if(b->len+n+1>b->cap){ while(b->len+n+1>b->cap)b->cap*=2; b->p=xrealloc(b->p,b->cap);} memcpy(b->p+b->len,s,n); b->len+=n; b->p[b->len]=0; }
static void badd(Buf*b,const char*s){ baddn(b,s,strlen(s)); }
static void bprintf(Buf*b,const char*fmt,...){ va_list ap; va_start(ap,fmt); char *s=NULL; vasprintf(&s,fmt,ap); va_end(ap); badd(b,s); free(s); }
static Val *vnew(VType t){ Val*v=calloc(1,sizeof(*v)); v->t=t; return v; }
static Val *vstr(const char*s){ Val*v=vnew(V_STR); v->s=xstrdup(s?s:""); return v; }
static Val *vnum(double n){ Val*v=vnew(V_NUM); v->n=n; return v; }
static Val *vbool(int b){ Val*v=vnew(V_BOOL); v->b=b; return v; }
static Val *varr(void){ return vnew(V_ARR); }
static Val *vobj(void){ return vnew(V_OBJ); }
static void arr_add(Val*v,Val*x){ v->a=xrealloc(v->a,sizeof(Val*)*(v->alen+1)); v->a[v->alen++]=x; }
static void obj_set(Val*v,const char*k,Val*x){ for(int i=0;i<v->olen;i++) if(strcmp(v->o[i].k,k)==0){v->o[i].v=x;return;} v->o=xrealloc(v->o,sizeof(Pair)*(v->olen+1)); v->o[v->olen].k=xstrdup(k); v->o[v->olen].v=x; v->olen++; }
static Val *obj_get(Val*v,const char*k){ if(!v||v->t!=V_OBJ)return NULL; for(int i=0;i<v->olen;i++) if(strcmp(v->o[i].k,k)==0)return v->o[i].v; return NULL; }
static int truthy(Val*v){ if(!v||v->t==V_NULL)return 0; if(v->t==V_BOOL)return v->b; if(v->t==V_NUM)return v->n!=0; if(v->t==V_STR)return v->s&&v->s[0]; if(v->t==V_ARR)return v->alen>0; if(v->t==V_OBJ)return v->olen>0; return 0; }
static char *val_s(Val*v);
static void render_val(Buf*b,Val*v){
  if(!v||v->t==V_NULL){ badd(b,"<no value>"); return; }
  if(v->t==V_STR){ badd(b,v->s?v->s:""); return; }
  if(v->t==V_BOOL){ badd(b,v->b?"true":"false"); return; }
  if(v->t==V_NUM){ double ip; if(modf(v->n,&ip)==0) bprintf(b,"%.0f",v->n); else bprintf(b,"%g",v->n); return; }
  if(v->t==V_ARR){ badd(b,"["); for(int i=0;i<v->alen;i++){ if(i)badd(b," "); render_val(b,v->a[i]); } badd(b,"]"); return; }
  if(v->t==V_OBJ){ badd(b,"map["); for(int i=0;i<v->olen;i++){ if(i)badd(b," "); badd(b,v->o[i].k); badd(b,":"); render_val(b,v->o[i].v);} badd(b,"]"); }
}
static char *val_s(Val*v){ Buf b; binit(&b); render_val(&b,v); return b.p; }
static double val_num(Val*v){ if(!v)return 0; if(v->t==V_NUM)return v->n; if(v->t==V_BOOL)return v->b; if(v->t==V_STR)return atof(v->s); return 0; }

static char *read_file(const char *path){
  FILE*f=!strcmp(path,"-")?stdin:fopen(path,"rb"); if(!f) die("open %s: %s",path,strerror(errno));
  Buf b; binit(&b); char tmp[8192]; size_t n; while((n=fread(tmp,1,sizeof(tmp),f))>0)baddn(&b,tmp,n); if(f!=stdin)fclose(f); return b.p;
}
static void write_file(const char *path,const char *s,int mode){
  if(!path||!strcmp(path,"-")){ fputs(s,stdout); return; }
  FILE*f=fopen(path,"wb"); if(!f) die("write %s: %s",path,strerror(errno)); fwrite(s,1,strlen(s),f); fclose(f); if(mode) chmod(path,mode);
}
static char *trim(char *s){ while(isspace((unsigned char)*s))s++; char *e=s+strlen(s); while(e>s&&isspace((unsigned char)e[-1]))*--e=0; return s; }
static char *unquote(const char*s){
  size_t n=strlen(s); if(n>=2&&((s[0]=='"'&&s[n-1]=='"')||(s[0]=='\''&&s[n-1]=='\'')||(s[0]=='`'&&s[n-1]=='`'))){
    Buf b; binit(&b); for(size_t i=1;i<n-1;i++){ if(s[i]=='\\'&&s[0]=='"'&&i+1<n-1){ i++; char c=s[i]; if(c=='n')baddn(&b,"\n",1); else if(c=='t')baddn(&b,"\t",1); else baddn(&b,&c,1);} else baddn(&b,s+i,1);} return b.p;
  }
  return xstrdup(s);
}

typedef struct { const char *p; } JP;
static void jskip(JP*j){ while(isspace((unsigned char)*j->p))j->p++; }
static Val *jval(JP*j);
static char *jstr(JP*j){ if(*j->p!='"') return xstrdup(""); j->p++; Buf b; binit(&b); while(*j->p&&*j->p!='"'){ char c=*j->p++; if(c=='\\'){ c=*j->p++; if(c=='n')c='\n'; else if(c=='t')c='\t'; else if(c=='r')c='\r'; } baddn(&b,&c,1);} if(*j->p=='"')j->p++; return b.p; }
static Val *jval(JP*j){
  jskip(j);
  if(*j->p=='"'){ char*s=jstr(j); Val*v=vstr(s); free(s); return v; }
  if(*j->p=='{'){ j->p++; Val*o=vobj(); jskip(j); while(*j->p&&*j->p!='}'){ char*k=jstr(j); jskip(j); if(*j->p==':')j->p++; Val*v=jval(j); obj_set(o,k,v); free(k); jskip(j); if(*j->p==','){j->p++; jskip(j);} } if(*j->p=='}')j->p++; return o; }
  if(*j->p=='['){ j->p++; Val*a=varr(); jskip(j); while(*j->p&&*j->p!=']'){ arr_add(a,jval(j)); jskip(j); if(*j->p==','){j->p++; jskip(j);} } if(*j->p==']')j->p++; return a; }
  if(!strncmp(j->p,"true",4)){j->p+=4;return vbool(1);} if(!strncmp(j->p,"false",5)){j->p+=5;return vbool(0);} if(!strncmp(j->p,"null",4)){j->p+=4;return vnew(V_NULL);}
  char *e; double n=strtod(j->p,&e); if(e!=j->p){ j->p=e; return vnum(n); } return vstr("");
}
static Val *parse_json(const char*s){ JP j={s}; return jval(&j); }
static Val *parse_envfile(const char*s){ Val*o=vobj(); char *c=xstrdup(s),*save; for(char*l=strtok_r(c,"\n",&save);l;l=strtok_r(NULL,"\n",&save)){ l=trim(l); if(!*l||*l=='#')continue; if(!strncmp(l,"export ",7))l+=7; char*eq=strchr(l,'='); if(!eq)continue; *eq=0; char*k=trim(l),*v=trim(eq+1); char*u=unquote(v); obj_set(o,k,vstr(u)); free(u);} free(c); return o; }
static Val *parse_yaml(const char*s){
  Val*root=vobj(); Val*stack[32]; int ind[32]; stack[0]=root; ind[0]=-1; int top=0;
  char *c=xstrdup(s),*save;
  for(char*l=strtok_r(c,"\n",&save);l;l=strtok_r(NULL,"\n",&save)){
    int sp=0; while(l[sp]==' ')sp++; char*t=trim(l+sp); if(!*t||*t=='#')continue; char*col=strchr(t,':'); if(!col)continue; *col=0; char*k=trim(t); char*rv=trim(col+1); while(top>0&&sp<=ind[top])top--;
    Val *v; if(!*rv){ v=vobj(); obj_set(stack[top],k,v); top++; stack[top]=v; ind[top]=sp; }
    else { char*u=unquote(rv); if(!strcmp(u,"true")||!strcmp(u,"false"))v=vbool(!strcmp(u,"true")); else { char*e; double n=strtod(u,&e); v=(*u&&!*e)?vnum(n):vstr(u);} obj_set(stack[top],k,v); free(u); }
  }
  free(c); return root;
}
static Val *load_data(const char *url){
  const char *p=url; if(!strncmp(p,"file://",7))p+=7; if(strstr(p,"?")){ char *tmp=xstrdup(p); *strchr(tmp,'?')=0; char*txt=read_file(tmp); free(tmp); p=url; const char*q=strstr(url,"type="); if(q&&strstr(q,"json"))return parse_json(txt); if(q&&strstr(q,"yaml"))return parse_yaml(txt); return vstr(txt); }
  if(!strcmp(p,"env:///")||!strcmp(p,"env:")){ extern char **environ; Val*o=vobj(); for(char **e=environ;*e;e++){ char *eq=strchr(*e,'='); if(eq){ char*k=strndup(*e,eq-*e); obj_set(o,k,vstr(eq+1)); free(k);} } return o; }
  char *txt=read_file(p);
  const char *ext=strrchr(p,'.');
  if(ext&&(!strcmp(ext,".json")))return parse_json(txt);
  if(ext&&(!strcmp(ext,".yaml")||!strcmp(ext,".yml")))return parse_yaml(txt);
  if(ext&&(!strcmp(ext,".env")))return parse_envfile(txt);
  return vstr(txt);
}

typedef struct { char **t; int n; } Tok;
static Tok toks(const char *s){
  Tok r={0}; int i=0,n=strlen(s);
  while(i<n){ while(i<n&&isspace((unsigned char)s[i]))i++; if(i>=n)break; char quote=0; Buf b; binit(&b);
    if(s[i]=='"'||s[i]=='\''||s[i]=='`'){ quote=s[i++]; baddn(&b,&quote,1); while(i<n){ char c=s[i++]; baddn(&b,&c,1); if(c=='\\'&&i<n&&quote!='`'){ baddn(&b,s+i,1); i++; continue;} if(c==quote)break; } }
    else { while(i<n&&!isspace((unsigned char)s[i])){ baddn(&b,s+i,1); i++; } }
    r.t=xrealloc(r.t,sizeof(char*)*(r.n+1)); r.t[r.n++]=b.p;
  } return r;
}
static Val *eval_expr(Ctx*c,const char*expr);
static Val *eval_token(Ctx*c,const char*x){
  if(!x||!*x)return vstr("");
  if((x[0]=='"'||x[0]=='\'')&&strlen(x)>=2){ char*u=unquote(x); Val*v=vstr(u); free(u); return v; }
  if(!strcmp(x,"true"))return vbool(1); if(!strcmp(x,"false"))return vbool(0);
  if(x[0]=='$'){ for(int i=c->nvars-1;i>=0;i--) if(!strcmp(c->vars[i].name,x))return c->vars[i].v; return vnew(V_NULL); }
  if(!strncmp(x,"env.Env.",8)){ char *e=getenv(x+8); return vstr(e?e:""); }
  char *e; double n=strtod(x,&e); if(*x&&!*e)return vnum(n);
  if(x[0]=='.'){
    Val*v=c->dot; char *cp=xstrdup(x+1),*save; for(char*p=strtok_r(cp,".",&save);p;p=strtok_r(NULL,".",&save)){ if(!*p)continue; v=obj_get(v,p); if(!v){ free(cp); if(c->missing_error)die("map has no entry for key \"%s\"",p); return vnew(V_NULL);} } free(cp); return v?v:vnew(V_NULL);
  }
  return vstr(x);
}
static char *lowerdup(const char*s){ char*r=xstrdup(s); for(char*p=r;*p;p++)*p=tolower((unsigned char)*p); return r; }
static Val *call_func(Ctx*c,const char*name,Val**argv,int argc){
  char *ln=lowerdup(name);
  if(!strcmp(ln,"print")){ Buf b; binit(&b); for(int i=0;i<argc;i++){ char*s=val_s(argv[i]); badd(&b,s); free(s);} free(ln); return vstr(b.p); }
  if(!strcmp(ln,"not")){ int r=argc?!truthy(argv[0]):1; free(ln); return vbool(r); }
  if(!strcmp(ln,"eq")||!strcmp(ln,"ne")){ char*a=argc>0?val_s(argv[0]):xstrdup(""); char*b=argc>1?val_s(argv[1]):xstrdup(""); int ok=!strcmp(a,b); if(!strcmp(ln,"ne"))ok=!ok; free(a); free(b); free(ln); return vbool(ok); }
  if(!strcmp(ln,"len")){ int r=0; if(argc){ if(argv[0]->t==V_STR)r=strlen(argv[0]->s); else if(argv[0]->t==V_ARR)r=argv[0]->alen; else if(argv[0]->t==V_OBJ)r=argv[0]->olen; } free(ln); return vnum(r); }
  if(!strcmp(ln,"printf")&&argc>0){ char *fmt=val_s(argv[0]); Buf b; binit(&b); for(char*p=fmt;*p;p++){ if(*p=='%'&&p[1]&&argc>1){ p++; if(*p=='s'||*p=='v'){ char*s=val_s(argv[1]); badd(&b,s); free(s);} else if(*p=='d'){ bprintf(&b,"%.0f",val_num(argv[1])); } else { baddn(&b,"%",1); baddn(&b,p,1);} } else baddn(&b,p,1);} free(fmt); free(ln); return vstr(b.p); }
  if(!strcmp(ln,"add")||!strcmp(ln,"math.add")){ double r=0; for(int i=0;i<argc;i++)r+=val_num(argv[i]); free(ln); return vnum(r); }
  if(!strcmp(ln,"mul")||!strcmp(ln,"math.mul")){ double r=1; for(int i=0;i<argc;i++)r*=val_num(argv[i]); free(ln); return vnum(r); }
  if(!strcmp(ln,"math.sub")){ double r=argc?val_num(argv[0]):0; for(int i=1;i<argc;i++)r-=val_num(argv[i]); free(ln); return vnum(r); }
  if(!strcmp(ln,"math.div")){ double r=argc?val_num(argv[0]):0; for(int i=1;i<argc&&val_num(argv[i])!=0;i++)r/=val_num(argv[i]); free(ln); return vnum(r); }
  if(!strcmp(ln,"math.rem")){ free(ln); return vnum(argc>1?(long long)val_num(argv[0])%(long long)val_num(argv[1]):0); }
  if(!strcmp(ln,"math.pow")){ free(ln); return vnum(argc>1?pow(val_num(argv[0]),val_num(argv[1])):0); }
  if(!strcmp(ln,"math.abs")){ free(ln); return vnum(argc?fabs(val_num(argv[0])):0); }
  if(!strcmp(ln,"math.ceil")){ free(ln); return vnum(argc?ceil(val_num(argv[0])):0); }
  if(!strcmp(ln,"math.floor")){ free(ln); return vnum(argc?floor(val_num(argv[0])):0); }
  if(!strcmp(ln,"math.round")){ free(ln); return vnum(argc?round(val_num(argv[0])):0); }
  if(!strcmp(ln,"math.max")||!strcmp(ln,"math.min")){ double r=argc?val_num(argv[0]):0; for(int i=1;i<argc;i++){ double x=val_num(argv[i]); if(strstr(ln,"max")?x>r:x<r)r=x;} free(ln); return vnum(r); }
  if(!strcmp(ln,"math.seq")){ Val*a=varr(); long long st=argc>0?val_num(argv[0]):1,en=argc>1?val_num(argv[1]):0,step=argc>2?val_num(argv[2]):1; if(step){ if(en<st&&step>0)step=-step; if(en>st&&step<0)step=-step; for(long long x=st;(step>0)?x<=en:x>=en;x+=step)arr_add(a,vnum(x)); } free(ln); return a; }
  if(!strcmp(ln,"coll.slice")||!strcmp(ln,"coll.goslice")){ Val*a=varr(); for(int i=0;i<argc;i++)arr_add(a,argv[i]); free(ln); return a; }
  if(!strcmp(ln,"coll.dict")){ Val*o=vobj(); for(int i=0;i+1<argc;i+=2){ char*k=val_s(argv[i]); obj_set(o,k,argv[i+1]); free(k);} free(ln); return o; }
  if(!strcmp(ln,"index")||!strcmp(ln,"coll.index")){ Val*v=argc?argv[0]:NULL; for(int i=1;i<argc;i++){ if(v&&v->t==V_OBJ){ char*k=val_s(argv[i]); v=obj_get(v,k); free(k);} else if(v&&v->t==V_ARR){ int ix=val_num(argv[i]); v=(ix>=0&&ix<v->alen)?v->a[ix]:NULL;} else v=NULL; } free(ln); return v?v:vnew(V_NULL); }
  if(!strcmp(ln,"env.getenv")){ char*k=argc?val_s(argv[0]):xstrdup(""); char*e=getenv(k); free(k); free(ln); return vstr(e?e:""); }
  if(!strcmp(ln,"env.hasenv")){ char*k=argc?val_s(argv[0]):xstrdup(""); int ok=getenv(k)!=NULL; free(k); free(ln); return vbool(ok); }
  if(!strcmp(ln,"env.expandenv")){ char*s=argc?val_s(argv[0]):xstrdup(""); char*out=getenv(s); free(ln); if(out){free(s); return vstr(out);} return vstr(s); }
  if(!strcmp(ln,"file.read")){ char*s=argc?val_s(argv[0]):xstrdup(""); char*t=read_file(s); free(s); free(ln); return vstr(t); }
  if(!strcmp(ln,"file.exists")){ char*s=argc?val_s(argv[0]):xstrdup(""); int ok=access(s,F_OK)==0; free(s); free(ln); return vbool(ok); }
  if(!strcmp(ln,"file.isdir")){ char*s=argc?val_s(argv[0]):xstrdup(""); struct stat st; int ok=stat(s,&st)==0&&S_ISDIR(st.st_mode); free(s); free(ln); return vbool(ok); }
  if(!strcmp(ln,"base64.encode")||!strcmp(ln,"base64.decode")){
    char *s=argc?val_s(argv[0]):xstrdup(""); char cmd[64]; strcpy(cmd,!strcmp(ln,"base64.encode")?"base64":"base64 -d"); char tmp[]="/tmp/gompXXXXXX"; int fd=mkstemp(tmp); write(fd,s,strlen(s)); close(fd); char sh[256]; snprintf(sh,sizeof(sh),"%s %s 2>/dev/null",cmd,tmp); FILE*p=popen(sh,"r"); Buf b; binit(&b); char buf[256]; while(p&&fgets(buf,sizeof(buf),p))badd(&b,buf); if(p)pclose(p); unlink(tmp); while(b.len&&b.p[b.len-1]=='\n')b.p[--b.len]=0; free(s); free(ln); return vstr(b.p);
  }
  if(!strncmp(ln,"strings.",8)||!strcmp(ln,"toupper")||!strcmp(ln,"tolower")||!strcmp(ln,"replaceall")||!strcmp(ln,"quote")||!strcmp(ln,"squote")||!strcmp(ln,"title")||!strcmp(ln,"trimspace")){
    char *fn=!strncmp(ln,"strings.",8)?ln+8:ln; char *a0=argc?val_s(argv[argc-1]):xstrdup(""); Val*r=NULL;
    if(!strcmp(fn,"toupper")){ for(char*p=a0;*p;p++)*p=toupper((unsigned char)*p); r=vstr(a0); }
    else if(!strcmp(fn,"tolower")){ for(char*p=a0;*p;p++)*p=tolower((unsigned char)*p); r=vstr(a0); }
    else if(!strcmp(fn,"title")){ int nw=1; for(char*p=a0;*p;p++){ if(isspace((unsigned char)*p))nw=1; else if(nw){*p=toupper((unsigned char)*p); nw=0;} } r=vstr(a0); }
    else if(!strcmp(fn,"contains")){ char*a1=argc>1?val_s(argv[0]):xstrdup(""); r=vbool(strstr(a0,a1)!=NULL); free(a1); }
    else if(!strcmp(fn,"hasprefix")){ char*a1=argc>1?val_s(argv[0]):xstrdup(""); r=vbool(!strncmp(a0,a1,strlen(a1))); free(a1); }
    else if(!strcmp(fn,"hassuffix")){ char*a1=argc>1?val_s(argv[0]):xstrdup(""); size_t l=strlen(a0),m=strlen(a1); r=vbool(l>=m&&!strcmp(a0+l-m,a1)); free(a1); }
    else if(!strcmp(fn,"repeat")){ int n=argc>1?val_num(argv[0]):0; Buf b; binit(&b); for(int i=0;i<n;i++)badd(&b,a0); r=vstr(b.p); }
    else if(!strcmp(fn,"split")){ char*sep=argc>1?val_s(argv[0]):xstrdup(" "); Val*a=varr(); char*cp=xstrdup(a0); char*save; for(char*p=strtok_r(cp,sep,&save);p;p=strtok_r(NULL,sep,&save))arr_add(a,vstr(p)); free(cp); free(sep); r=a; }
    else if(!strcmp(fn,"replaceall")){ char*old=argc>1?val_s(argv[0]):xstrdup(""); char*new=argc>2?val_s(argv[1]):xstrdup(""); Buf b; binit(&b); char*p=a0; size_t ol=strlen(old); while(ol&&strstr(p,old)){ char*q=strstr(p,old); baddn(&b,p,q-p); badd(&b,new); p=q+ol;} badd(&b,p); free(old); free(new); r=vstr(b.p); }
    else if(!strcmp(fn,"trim")||!strcmp(fn,"trimspace")){ r=vstr(trim(a0)); }
    else if(!strcmp(fn,"quote")){ Buf b; binit(&b); badd(&b,"\""); badd(&b,a0); badd(&b,"\""); r=vstr(b.p); }
    else if(!strcmp(fn,"squote")){ Buf b; binit(&b); badd(&b,"'"); badd(&b,a0); badd(&b,"'"); r=vstr(b.p); }
    else r=vstr(a0); free(a0); free(ln); return r;
  }
  if(!strncmp(ln,"path.",5)||!strncmp(ln,"filepath.",9)){ char*fn=strchr(ln,'.')+1; char*s=argc?val_s(argv[0]):xstrdup(""); Val*r=NULL; if(!strcmp(fn,"base")){ char*p=strrchr(s,'/'); r=vstr(p?p+1:s); } else if(!strcmp(fn,"dir")){ char*p=strrchr(s,'/'); if(p){*p=0;r=vstr(*s?s:"/");} else r=vstr("."); } else if(!strcmp(fn,"ext")){ char*p=strrchr(s,'.'); r=vstr(p?p:""); } else if(!strcmp(fn,"isabs")) r=vbool(s[0]=='/'); else if(!strcmp(fn,"clean")) r=vstr(s); else if(!strcmp(fn,"join")){ Buf b;binit(&b); for(int i=0;i<argc;i++){ char*x=val_s(argv[i]); if(i&&b.len&&b.p[b.len-1]!='/')badd(&b,"/"); badd(&b,x); free(x);} r=vstr(b.p);} else r=vstr(s); free(s); free(ln); return r; }
  if(!strcmp(ln,"datasource")||!strcmp(ln,"ds")||!strcmp(ln,"include")){ char*name=argc?val_s(argv[0]):xstrdup(""); for(int i=0;i<c->nds;i++)if(!strcmp(c->ds[i].name,name)){ if(!c->ds[i].cache)c->ds[i].cache=load_data(c->ds[i].url); Val*v=c->ds[i].cache; free(name); free(ln); return v; } free(name); free(ln); return vnew(V_NULL); }
  if(!strncmp(ln,"data.json",9)||!strcmp(ln,"json")){ char*s=argc?val_s(argv[0]):xstrdup(""); Val*v=parse_json(s); free(s); free(ln); return v; }
  if(!strncmp(ln,"data.yaml",9)||!strcmp(ln,"yaml")){ char*s=argc?val_s(argv[0]):xstrdup(""); Val*v=parse_yaml(s); free(s); free(ln); return v; }
  if(!strcmp(ln,"data.tojson")||!strcmp(ln,"tojson")||!strcmp(ln,"data.toyaml")||!strcmp(ln,"toyaml")){ char*s=val_s(argc?argv[0]:NULL); free(ln); return vstr(s); }
  free(ln); return argc?argv[argc-1]:vstr("");
}
static Val *eval_command(Ctx*c,const char*cmd,Val*pipe){
  Tok tk=toks(cmd); if(tk.n==0)return vstr("");
  int start=0; const char*fn=tk.t[0];
  if(tk.n==1 && !pipe) return eval_token(c,tk.t[0]);
  Val **args=NULL; int argc=0;
  start=1;
  for(int i=start;i<tk.n;i++){ args=xrealloc(args,sizeof(Val*)*(argc+1)); args[argc++]=eval_token(c,tk.t[i]); }
  if(pipe){ args=xrealloc(args,sizeof(Val*)*(argc+1)); args[argc++]=pipe; }
  return call_func(c,fn,args,argc);
}
static Val *eval_expr(Ctx*c,const char*expr){
  char *whole=xstrdup(expr); char *tw=trim(whole);
  if(tw[0]=='('){
    int d=0; char *close=NULL;
    for(char *p=tw; *p; p++){ if(*p=='(')d++; else if(*p==')'&&--d==0){ close=p; break; } }
    if(close && close[1]==0){
      *close=0; Val *v=eval_expr(c, tw+1); free(whole); return v;
    }
    if(close && close[1]=='.'){
      *close=0; Val *v=eval_expr(c, tw+1);
      char *cp=xstrdup(close+2), *save;
      for(char *k=strtok_r(cp,".",&save); k; k=strtok_r(NULL,".",&save)){
        if(v&&v->t==V_OBJ) v=obj_get(v,k); else v=NULL;
      }
      free(cp); free(whole); return v?v:vnew(V_NULL);
    }
  }
  char *cp=xstrdup(tw); free(whole); char *save; Val *pipe=NULL; for(char*p=strtok_r(cp,"|",&save);p;p=strtok_r(NULL,"|",&save)){ pipe=eval_command(c,trim(p),pipe); } free(cp); return pipe?pipe:vstr("");
}

static char *render(Ctx*c,const char*tmpl);
static char *find_action(const char*s,const char*delim){ return strstr(s,delim); }
static char *render_section(Ctx*c,const char*body,size_t len){ char*tmp=strndup(body,len); char*r=render(c,tmp); free(tmp); return r; }
static char *render(Ctx*c,const char*tmpl){
  Buf out; binit(&out); const char*p=tmpl; size_t ll=strlen(c->left),rl=strlen(c->right);
  while(*p){ char*l=find_action(p,c->left); if(!l){ badd(&out,p); break; } baddn(&out,p,l-p); char*rs=find_action(l+ll,c->right); if(!rs){ badd(&out,l); break; }
    int triml=(l[ll]=='-'); char*inside=strndup(l+ll+triml,rs-(l+ll+triml)); int trimr=0; char*e=inside+strlen(inside); while(e>inside&&isspace((unsigned char)e[-1]))e--; if(e>inside&&e[-1]=='-'){ trimr=1; e[-1]=0; } else *e=0; char*act=trim(inside);
    if(triml){ while(out.len&&isspace((unsigned char)out.p[out.len-1]))out.p[--out.len]=0; }
    p=rs+rl; if(trimr) while(*p&&isspace((unsigned char)*p))p++;
    if(!strncmp(act,"/*",2)){ free(inside); continue; }
    if(!strncmp(act,"if ",3)){
      int depth=1; const char*q=p,*elsep=NULL,*endp=NULL,*endclose=NULL; while((q=find_action(q,c->left))){ char*r2=find_action(q+ll,c->right); if(!r2)break; char*a=strndup(q+ll,r2-(q+ll)); char*ta=trim(a); if(!strncmp(ta,"if ",3)||!strncmp(ta,"range ",6))depth++; else if(!strcmp(ta,"end")){ if(--depth==0){endp=q;endclose=r2+rl; free(a); break;} } else if(depth==1&&!strcmp(ta,"else"))elsep=q; free(a); q=r2+rl; }
      Val*cond=eval_expr(c,act+3); char *seg; if(truthy(cond)) seg=render_section(c,p,(elsep?elsep:endp)-p); else seg=elsep?render_section(c,find_action(elsep+ll,c->right)+rl,endp-(find_action(elsep+ll,c->right)+rl)):xstrdup(""); badd(&out,seg); free(seg); p=endclose; free(inside); continue;
    }
    if(!strncmp(act,"range ",6)){
      int depth=1; const char*q=p,*endp=NULL,*endclose=NULL; while((q=find_action(q,c->left))){ char*r2=find_action(q+ll,c->right); if(!r2)break; char*a=strndup(q+ll,r2-(q+ll)); char*ta=trim(a); if(!strncmp(ta,"range ",6)||!strncmp(ta,"if ",3))depth++; else if(!strcmp(ta,"end")&&--depth==0){endp=q;endclose=r2+rl; free(a); break;} free(a); q=r2+rl; }
      Val*seq=eval_expr(c,act+6); Val*old=c->dot; if(seq&&seq->t==V_ARR){ for(int i=0;i<seq->alen;i++){ c->dot=seq->a[i]; char*seg=render_section(c,p,endp-p); badd(&out,seg); free(seg);} } else if(seq&&seq->t==V_OBJ){ for(int i=0;i<seq->olen;i++){ c->dot=seq->o[i].v; char*seg=render_section(c,p,endp-p); badd(&out,seg); free(seg);} } c->dot=old; p=endclose; free(inside); continue;
    }
    if(!strcmp(act,"else")||!strcmp(act,"end")){ free(inside); continue; }
    char *as=strstr(act,":="); if(as&&act[0]=='$'){ *as=0; char*name=trim(act); Val*v=eval_expr(c,as+2); c->vars=xrealloc(c->vars,sizeof(Var)*(c->nvars+1)); c->vars[c->nvars].name=xstrdup(name); c->vars[c->nvars].v=v; c->nvars++; free(inside); continue; }
    Val*v=eval_expr(c,act); render_val(&out,v); free(inside);
  }
  return out.p;
}

static void add_ds(Ctx*c,const char*spec,int context){
  char *cp=xstrdup(spec); char *eq=strchr(cp,'='); char *name,*url;
  if(eq){ *eq=0; name=cp; url=eq+1; } else { url=cp; char *base=strrchr(cp,'/'); name=base?base+1:cp; char *dot=strrchr(name,'.'); if(dot)*dot=0; }
  if(context){ Val*v=load_data(url); if(!strcmp(name,".")) c->dot=v; else obj_set(c->dot,name,v); }
  else { c->ds=xrealloc(c->ds,sizeof(DS)*(c->nds+1)); c->ds[c->nds].name=xstrdup(name); c->ds[c->nds].url=xstrdup(url); c->ds[c->nds].cache=NULL; c->nds++; }
  free(cp);
}
static void usage(void){
  puts("Process text files with Go templates\n\nUsage:\n  gomplate [flags]\n\nFlags:\n  -d, --datasource datasource        datasource in alias=URL form. Specify multiple times to add multiple sources.\n  -c, --context datasource           pre-load a datasource into the context, in alias=URL form. Use the special alias `.` to set the root context.\n  -f, --file file                    Template file to process. Omit to use standard input, or use --in or --input-dir (default [-])\n  -i, --in string                    Template string to process (alternative to --file and --input-dir)\n  -o, --out file                     output file name. Omit to use standard output. (default [-])\n      --left-delim delimiter         override the default left-delimiter [$GOMPLATE_LEFT_DELIM] (default \"{{\")\n      --right-delim delimiter        override the default right-delimiter [$GOMPLATE_RIGHT_DELIM] (default \"}}\")\n      --missing-key string           Control the behavior during execution if a map is indexed with a key that is not present in the map.\n  -h, --help                         help for gomplate\n  -v, --version                      version for gomplate");
}

static void process_file(Ctx*c,const char*in,const char*out,int chmod_mode){
  char*txt=read_file(in?in:"-"); char*r=render(c,txt); write_file(out?out:"-",r,chmod_mode);
}
static void mkdir_p(const char *path){
  char *cp=xstrdup(path);
  for(char *p=cp+1; *p; p++) if(*p=='/'){ *p=0; mkdir(cp,0777); *p='/'; }
  mkdir(cp,0777); free(cp);
}
static void ensure_parent(const char *path){
  char *cp=xstrdup(path); char *s=strrchr(cp,'/'); if(s){ *s=0; if(*cp) mkdir_p(cp); } free(cp);
}
static void process_dir(Ctx*c,const char*inroot,const char*outroot,const char*rel,int chmod_mode){
  char inpath[4096], outpath[4096];
  snprintf(inpath,sizeof(inpath),"%s/%s",inroot,rel?rel:"");
  DIR*d=opendir(inpath); if(!d) die("open dir %s: %s",inpath,strerror(errno));
  struct dirent *de;
  while((de=readdir(d))){
    if(!strcmp(de->d_name,".")||!strcmp(de->d_name,"..")) continue;
    char childrel[4096]; snprintf(childrel,sizeof(childrel),"%s%s%s",rel&&*rel?rel:"",rel&&*rel?"/":"",de->d_name);
    snprintf(inpath,sizeof(inpath),"%s/%s",inroot,childrel);
    struct stat st; if(stat(inpath,&st)!=0) continue;
    if(S_ISDIR(st.st_mode)) process_dir(c,inroot,outroot,childrel,chmod_mode);
    else if(S_ISREG(st.st_mode)){
      snprintf(outpath,sizeof(outpath),"%s/%s",outroot?outroot:".",childrel);
      ensure_parent(outpath);
      char *txt=read_file(inpath), *r=render(c,txt);
      write_file(outpath,r,chmod_mode?chmod_mode:(st.st_mode&0777));
    }
  }
  closedir(d);
}
int main(int argc,char**argv){
  Ctx c={0}; c.dot=vobj(); c.missing_error=1; c.left=getenv("GOMPLATE_LEFT_DELIM")?xstrdup(getenv("GOMPLATE_LEFT_DELIM")):xstrdup("{{"); c.right=getenv("GOMPLATE_RIGHT_DELIM")?xstrdup(getenv("GOMPLATE_RIGHT_DELIM")):xstrdup("}}");
  Val*env=vobj(); extern char **environ; for(char **e=environ;*e;e++){ char*eq=strchr(*e,'='); if(eq){ char*k=strndup(*e,eq-*e); obj_set(env,k,vstr(eq+1)); free(k);} } obj_set(c.dot,"Env",env);
  char *in_arg=NULL,*file_arg=NULL,*out_arg=NULL,*input_dir=NULL,*output_dir=NULL,*config=xstrdup(".gomplate.yaml"); int chmod_mode=0;
  for(int i=1;i<argc;i++){
    char*a=argv[i]; char*val=NULL; char*eq=strchr(a,'='); if(eq){ val=eq+1; }
    if(!strcmp(a,"--help")||!strcmp(a,"-h")){ usage(); return 0; }
    else if(!strcmp(a,"--version")||!strcmp(a,"-v")){ puts("gomplate version 0.0.0"); return 0; }
    else if(!strcmp(a,"-i")||!strcmp(a,"--in")) in_arg=argv[++i]; else if(!strncmp(a,"--in=",5)) in_arg=val;
    else if(!strcmp(a,"-f")||!strcmp(a,"--file")) file_arg=argv[++i]; else if(!strncmp(a,"--file=",7)) file_arg=val;
    else if(!strcmp(a,"-o")||!strcmp(a,"--out")) out_arg=argv[++i]; else if(!strncmp(a,"--out=",6)) out_arg=val;
    else if(!strcmp(a,"--input-dir")) input_dir=argv[++i]; else if(!strncmp(a,"--input-dir=",12)) input_dir=val;
    else if(!strcmp(a,"--output-dir")) output_dir=argv[++i]; else if(!strncmp(a,"--output-dir=",13)) output_dir=val;
    else if(!strcmp(a,"-d")||!strcmp(a,"--datasource")) add_ds(&c,argv[++i],0); else if(!strncmp(a,"--datasource=",13)) add_ds(&c,val,0);
    else if(!strcmp(a,"-c")||!strcmp(a,"--context")) add_ds(&c,argv[++i],1); else if(!strncmp(a,"--context=",10)) add_ds(&c,val,1);
    else if(!strcmp(a,"--left-delim")) c.left=argv[++i]; else if(!strncmp(a,"--left-delim=",13)) c.left=val;
    else if(!strcmp(a,"--right-delim")) c.right=argv[++i]; else if(!strncmp(a,"--right-delim=",14)) c.right=val;
    else if(!strcmp(a,"--config")) config=argv[++i]; else if(!strncmp(a,"--config=",9)) config=val;
    else if(!strcmp(a,"--missing-key")){ char*m=argv[++i]; c.missing_error=!strcmp(m,"error"); } else if(!strncmp(a,"--missing-key=",14)){ c.missing_error=!strcmp(val,"error"); }
    else if(!strcmp(a,"--chmod")) chmod_mode=strtol(argv[++i],NULL,8); else if(!strncmp(a,"--chmod=",8)) chmod_mode=strtol(val,NULL,8);
  }
  if(config && *config && access(config,F_OK)==0){
    char *ct=read_file(config); Val *cv=parse_yaml(ct);
    if(!in_arg){ Val*v=obj_get(cv,"in"); if(!v)v=obj_get(cv,"input"); if(v&&v->t==V_STR)in_arg=v->s; }
    if(!file_arg){ Val*v=obj_get(cv,"file"); if(v&&v->t==V_STR)file_arg=v->s; }
    if(!out_arg){ Val*v=obj_get(cv,"out"); if(!v)v=obj_get(cv,"output"); if(v&&v->t==V_STR)out_arg=v->s; }
    Val*dss=obj_get(cv,"datasources"); if(dss&&dss->t==V_OBJ) for(int i=0;i<dss->olen;i++){ char spec[4096]; char *u=val_s(dss->o[i].v); snprintf(spec,sizeof(spec),"%s=%s",dss->o[i].k,u); add_ds(&c,spec,0); free(u); }
    Val*ctx=obj_get(cv,"context"); if(ctx&&ctx->t==V_OBJ) for(int i=0;i<ctx->olen;i++){ char spec[4096]; char *u=val_s(ctx->o[i].v); snprintf(spec,sizeof(spec),"%s=%s",ctx->o[i].k,u); add_ds(&c,spec,1); free(u); }
  }
  if(input_dir) process_dir(&c,input_dir,output_dir?output_dir:".","",chmod_mode);
  else if(in_arg){ char*r=render(&c,in_arg); write_file(out_arg?out_arg:"-",r,chmod_mode); }
  else process_file(&c,file_arg?file_arg:"-",out_arg?out_arg:"-",chmod_mode);
  return 0;
}
