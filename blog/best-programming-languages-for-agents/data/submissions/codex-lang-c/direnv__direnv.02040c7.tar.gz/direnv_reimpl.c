#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <libgen.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

extern char **environ;

#define VERSION "2.37.1"

typedef struct {
  char *key;
  char *val;
} Pair;

typedef struct {
  Pair *v;
  size_t n, cap;
} Env;

static void die(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  fprintf(stderr, "\033[31mdirenv: error ");
  vfprintf(stderr, fmt, ap);
  fprintf(stderr, "\033[0m\n");
  va_end(ap);
  exit(1);
}

static char *xstrdup(const char *s) {
  char *r = strdup(s ? s : "");
  if (!r) die("out of memory");
  return r;
}

static void *xrealloc(void *p, size_t n) {
  void *r = realloc(p, n);
  if (!r) die("out of memory");
  return r;
}

static char *join3(const char *a, const char *b, const char *c) {
  char *r;
  if (asprintf(&r, "%s%s%s", a, b, c) < 0) die("out of memory");
  return r;
}

static char *home(void) {
  const char *h = getenv("HOME");
  return xstrdup(h && *h ? h : "/home/agent");
}

static char *config_dir(void) {
  const char *d = getenv("DIRENV_CONFIG");
  if (d && *d) return xstrdup(d);
  d = getenv("XDG_CONFIG_HOME");
  if (d && *d) return join3(d, "/direnv", "");
  char *h = home();
  char *r = join3(h, "/.config/direnv", "");
  free(h);
  return r;
}

static char *data_dir(void) {
  const char *d = getenv("XDG_DATA_HOME");
  if (d && *d) return join3(d, "/direnv", "");
  char *h = home();
  char *r = join3(h, "/.local/share/direnv", "");
  free(h);
  return r;
}

static void mkdir_p(const char *path) {
  char tmp[PATH_MAX];
  snprintf(tmp, sizeof tmp, "%s", path);
  for (char *p = tmp + 1; *p; p++) {
    if (*p == '/') {
      *p = 0;
      mkdir(tmp, 0777);
      *p = '/';
    }
  }
  mkdir(tmp, 0777);
}

static char *abs_path(const char *p) {
  char buf[PATH_MAX];
  if (realpath(p, buf)) return xstrdup(buf);
  if (p[0] == '/') return xstrdup(p);
  char cwd[PATH_MAX];
  if (!getcwd(cwd, sizeof cwd)) die("%s", strerror(errno));
  return join3(cwd, "/", p);
}

static bool is_dir(const char *p) {
  struct stat st;
  return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}

static bool is_file(const char *p) {
  struct stat st;
  return stat(p, &st) == 0 && S_ISREG(st.st_mode);
}

static char *find_rc_from(const char *start) {
  char *cur = abs_path(start ? start : ".");
  if (!is_dir(cur)) {
    char *slash = strrchr(cur, '/');
    if (slash && slash != cur) *slash = 0;
  }
  while (1) {
    char *p = join3(cur, "/.envrc", "");
    if (is_file(p)) {
      free(cur);
      return p;
    }
    free(p);
    p = join3(cur, "/.env", "");
    if (is_file(p)) {
      free(cur);
      return p;
    }
    free(p);
    if (strcmp(cur, "/") == 0) break;
    char *slash = strrchr(cur, '/');
    if (!slash || slash == cur) {
      strcpy(cur, "/");
    } else {
      *slash = 0;
    }
  }
  free(cur);
  return NULL;
}

static char *rc_path_arg(int argc, char **argv, int idx) {
  const char *p = idx < argc ? argv[idx] : ".";
  char *a = abs_path(p);
  if (is_dir(a)) {
    char *e = join3(a, "/.envrc", "");
    if (!is_file(e)) {
      free(e);
      e = join3(a, "/.env", "");
    }
    free(a);
    a = e;
  }
  if (!is_file(a)) die("lstat %s: no such file or directory", a);
  return a;
}

static unsigned long long hash_path(const char *s) {
  unsigned long long h = 1469598103934665603ULL;
  while (*s) {
    h ^= (unsigned char)*s++;
    h *= 1099511628211ULL;
  }
  return h;
}

static char *allow_file(const char *rc) {
  char *dd = data_dir();
  char *ad = join3(dd, "/allow", "");
  mkdir_p(ad);
  char *r;
  if (asprintf(&r, "%s/%016llx", ad, hash_path(rc)) < 0) die("out of memory");
  free(dd);
  free(ad);
  return r;
}

static bool is_allowed(const char *rc) {
  char *af = allow_file(rc);
  FILE *f = fopen(af, "r");
  free(af);
  if (!f) return false;
  char line[PATH_MAX * 2];
  bool ok = false;
  while (fgets(line, sizeof line, f)) {
    line[strcspn(line, "\r\n")] = 0;
    if (strcmp(line, rc) == 0) ok = true;
  }
  fclose(f);
  return ok;
}

static void env_add(Env *e, const char *k, const char *v) {
  if (e->n == e->cap) {
    e->cap = e->cap ? e->cap * 2 : 64;
    e->v = xrealloc(e->v, e->cap * sizeof(Pair));
  }
  e->v[e->n].key = xstrdup(k);
  e->v[e->n].val = xstrdup(v);
  e->n++;
}

static const char *env_get(Env *e, const char *k) {
  for (size_t i = 0; i < e->n; i++)
    if (strcmp(e->v[i].key, k) == 0) return e->v[i].val;
  return NULL;
}

static Env current_env(void) {
  Env e = {0};
  for (char **p = environ; *p; p++) {
    char *eq = strchr(*p, '=');
    if (!eq) continue;
    char *k = strndup(*p, eq - *p);
    env_add(&e, k, eq + 1);
    free(k);
  }
  return e;
}

static void shell_quote(FILE *out, const char *s) {
  fputs("$'", out);
  for (; *s; s++) {
    unsigned char c = *s;
    if (c == '\'' || c == '\\') fprintf(out, "\\%c", c);
    else if (c == '\n') fputs("\\n", out);
    else if (c == '\t') fputs("\\t", out);
    else if (isprint(c)) fputc(c, out);
    else fprintf(out, "\\x%02x", c);
  }
  fputc('\'', out);
}

static void json_quote(FILE *out, const char *s) {
  fputc('"', out);
  for (; *s; s++) {
    unsigned char c = *s;
    if (c == '"' || c == '\\') fprintf(out, "\\%c", c);
    else if (c == '\n') fputs("\\n", out);
    else if (c == '\r') fputs("\\r", out);
    else if (c == '\t') fputs("\\t", out);
    else if (c < 32) fprintf(out, "\\u%04x", c);
    else fputc(c, out);
  }
  fputc('"', out);
}

static void print_stdlib_to(FILE *out) {
#define puts(s) fputs((s), out), fputc('\n', out)
#define printf(...) fprintf(out, __VA_ARGS__)
  puts("#!/usr/bin/env bash");
  puts("shopt -s nullglob extglob");
  puts("direnv=\"/workspace/executable\"");
  puts("direnv_config_dir=\"${DIRENV_CONFIG:-${XDG_CONFIG_HOME:-$HOME/.config}/direnv}\"");
  puts("export DIRENV_IN_ENVRC=1");
  puts("log_status() { \"$direnv\" log --status \"$*\"; }");
  puts("log_error() { \"$direnv\" log --error \"$*\"; }");
  puts("has() { type \"$1\" >/dev/null 2>&1; }");
  puts("expand_path() { local p=\"$1\" b=\"${2:-$PWD}\"; [[ \"$p\" = /* ]] && printf '%s\\n' \"$p\" || (cd \"$b\" 2>/dev/null && cd \"$(dirname \"$p\")\" 2>/dev/null && printf '%s/%s\\n' \"$PWD\" \"$(basename \"$p\")\"); }");
  puts("user_rel_path() { case \"$1\" in \"$HOME\"/*) printf '~/%s\\n' \"${1#$HOME/}\";; \"$HOME\") echo '~';; *) echo \"$1\";; esac; }");
  puts("find_up() { local f=\"$1\" d=\"$PWD\"; while :; do [[ -e \"$d/$f\" ]] && { echo \"$d/$f\"; return 0; }; [[ \"$d\" = / ]] && return 1; d=\"${d%/*}\"; [[ -z \"$d\" ]] && d=/; done; }");
  puts("source_env() { local p=\"$1\"; [[ -d \"$p\" ]] && p=\"$p/.envrc\"; source \"$p\"; }");
  puts("source_env_if_exists() { [[ -f \"$1\" ]] && source_env \"$1\" || true; }");
  puts("source_up() { local f=\"${1:-.envrc}\" p; p=$(find_up \"$f\") || return 1; source \"$p\"; }");
  puts("source_up_if_exists() { source_up \"${1:-.envrc}\" || true; }");
  puts("dotenv() { local f=\"${1:-.env}\"; [[ -f \"$f\" ]] || return 1; set -a; source \"$f\"; set +a; }");
  puts("dotenv_if_exists() { [[ -f \"${1:-.env}\" ]] && dotenv \"$@\" || true; }");
  puts("path_add() { local var=\"$1\" p; p=$(expand_path \"$2\"); eval \"export $var=\\\"$p${!var:+:}${!var}\\\"\"; }");
  puts("PATH_add() { path_add PATH \"$1\"; }");
  puts("MANPATH_add() { path_add MANPATH \"$1\"; }");
  puts("PATH_rm() { local IFS=: out= e; for e in $PATH; do local keep=1 pat; for pat in \"$@\"; do [[ \"$e\" == $pat ]] && keep=0; done; [[ $keep = 1 ]] && out=\"${out:+$out:}$e\"; done; export PATH=\"$out\"; }");
  puts("load_prefix() { local p; p=$(expand_path \"$1\"); PATH_add \"$p/bin\"; path_add CPATH \"$p/include\"; path_add LD_LIBRARY_PATH \"$p/lib\"; path_add LIBRARY_PATH \"$p/lib\"; path_add PKG_CONFIG_PATH \"$p/lib/pkgconfig\"; MANPATH_add \"$p/share/man\"; }");
  puts("layout() { case \"$1\" in go) export GOPATH=\"$(direnv_layout_dir)/go\"; PATH_add bin;; node) PATH_add node_modules/.bin;; php) PATH_add vendor/bin;; julia) export JULIA_PROJECT=\"$PWD\";; python|python3) layout_python \"$@\";; *) log_error \"unknown layout $1\"; return 1;; esac; }");
  puts("direnv_layout_dir() { echo \"${XDG_CACHE_HOME:-$HOME/.cache}/direnv/layouts/$(echo -n \"$PWD\" | sed 's#[/:]#-#g')\"; }");
  puts("layout_python() { local d=\"$(direnv_layout_dir)/python\"; mkdir -p \"$d\"; export VIRTUAL_ENV=\"$d\"; PATH_add \"$d/bin\"; }");
  puts("watch_file() { :; }; watch_dir() { :; }; env_vars_required() { local x r=0; for x in \"$@\"; do [[ -n \"${!x:-}\" ]] || { log_error \"\\$$x is required\"; r=1; }; done; return $r; }");
#undef puts
#undef printf
}

static void print_stdlib(void) { print_stdlib_to(stdout); }

static Env eval_rc(const char *rc, int *status) {
  char tmpl[] = "/tmp/direnv-c-XXXXXX";
  int fd = mkstemp(tmpl);
  if (fd < 0) die("mkstemp: %s", strerror(errno));
  FILE *f = fdopen(fd, "w");
  print_stdlib_to(f);
  char *cd = config_dir();
  fprintf(f, "[[ -f %s/direnvrc ]] && source %s/direnvrc\n", cd, cd);
  fprintf(f, "for f in %s/lib/*.sh; do [[ -f \"$f\" ]] && source \"$f\"; done\n", cd);
  free(cd);
  fprintf(f, "cd %s\n", dirname(xstrdup(rc)));
  fprintf(f, "source %s\n", rc);
  fprintf(f, "env -0\n");
  fclose(f);
  char cmd[PATH_MAX + 64];
  snprintf(cmd, sizeof cmd, "/usr/bin/bash %s", tmpl);
  FILE *p = popen(cmd, "r");
  if (!p) die("bash: %s", strerror(errno));
  Env e = {0};
  char *buf = NULL;
  size_t len = 0, cap = 0;
  int c;
  while ((c = fgetc(p)) != EOF) {
    if (len + 1 >= cap) {
      cap = cap ? cap * 2 : 256;
      buf = xrealloc(buf, cap);
    }
    if (c == 0) {
      buf[len] = 0;
      char *eq = strchr(buf, '=');
      if (eq) {
        *eq = 0;
        env_add(&e, buf, eq + 1);
      }
      len = 0;
    } else {
      buf[len++] = (char)c;
    }
  }
  free(buf);
  int rcst = pclose(p);
  unlink(tmpl);
  *status = WIFEXITED(rcst) ? WEXITSTATUS(rcst) : 1;
  return e;
}

static void print_diff(const char *shell, Env *old, Env *new, const char *rc) {
  (void)rc;
  bool json = strcmp(shell, "json") == 0 || strcmp(shell, "elvish") == 0 || strcmp(shell, "murex") == 0;
  if (json) puts("{");
  int count = 0;
  for (size_t i = 0; i < new->n; i++) {
    const char *ov = env_get(old, new->v[i].key);
    if (ov && strcmp(ov, new->v[i].val) == 0) continue;
    if (strncmp(new->v[i].key, "DIRENV_IN_ENVRC", 15) == 0) continue;
    if (!strcmp(new->v[i].key, "SHLVL") || !strcmp(new->v[i].key, "OLDPWD") || !strcmp(new->v[i].key, "_")) continue;
    if (json) {
      if (count++) puts(",");
      printf("  ");
      json_quote(stdout, new->v[i].key);
      printf(": ");
      json_quote(stdout, new->v[i].val);
    } else if (strcmp(shell, "fish") == 0) {
      printf("set -gx %s ", new->v[i].key);
      shell_quote(stdout, new->v[i].val);
      printf(";\n");
    } else if (strcmp(shell, "tcsh") == 0) {
      printf("setenv %s ", new->v[i].key);
      shell_quote(stdout, new->v[i].val);
      printf(";\n");
    } else if (strcmp(shell, "systemd") == 0) {
      printf("%s=%s\n", new->v[i].key, new->v[i].val);
    } else {
      printf("export %s=", new->v[i].key);
      shell_quote(stdout, new->v[i].val);
      printf(";");
    }
  }
  for (size_t i = 0; i < old->n; i++) {
    if (env_get(new, old->v[i].key)) continue;
    if (strncmp(old->v[i].key, "DIRENV_", 7) == 0) continue;
    if (json) {
      if (count++) puts(",");
      printf("  ");
      json_quote(stdout, old->v[i].key);
      printf(": null");
    } else if (strcmp(shell, "fish") == 0) {
      printf("set -e %s;\n", old->v[i].key);
    } else if (strcmp(shell, "tcsh") == 0) {
      printf("unsetenv %s;\n", old->v[i].key);
    } else {
      printf("unset %s;", old->v[i].key);
    }
  }
  if (json) puts("\n}");
}

static void help(bool priv) {
  printf("direnv v%s\nUsage: direnv COMMAND [...ARGS]\n\nAvailable commands\n------------------\n", VERSION);
  puts("allow [PATH_TO_RC]:\n  aliases: permit, grant\n  Grants direnv permission to load the given .envrc or .env file.");
  if (priv) puts("*apply_dump FILE:\n  Accepts a filename containing `direnv dump` output and generates a series of bash export statements to apply the given env");
  puts("block [PATH_TO_RC]:\n  aliases: deny, disallow, revoke\n  Revokes the authorization of a given .envrc or .env file.");
  if (priv) puts("*dotenv [SHELL] [PATH_TO_DOTENV]:\n  Transforms a .env file to evaluatable `export KEY=PAIR` statements\n*dump [SHELL] [FILE]:\n  Used to export the inner bash state at the end of execution");
  puts("edit [PATH_TO_RC]:\n  Opens PATH_TO_RC or the current .envrc or .env into an $EDITOR and allow\n  the file to be loaded afterwards.");
  puts("exec DIR COMMAND [...ARGS]:\n  Executes a command after loading the first .envrc or .env found in DIR");
  puts("export SHELL:\n  Loads an .envrc or .env and prints the diff in terms of exports.\n  Supported SHELL values are: [elvish, fish, json, murex, tcsh, pwsh, bash, gzenv, vim, zsh, systemd, gha]");
  puts("fetchurl <url> [<integrity-hash>]:\n  Fetches a given URL into direnv's CAS");
  puts("help [SHOW_PRIVATE]:\n  Shows this help\nhook SHELL:\n  Used to setup the shell hook\nprune:\n  Removes old allowed and required files\nreload:\n  Triggers an env reload\nstatus [--json]:\n  Prints some debug status information\nstdlib:\n  Displays the stdlib available in the .envrc execution context\nversion [VERSION_AT_LEAST]:\n  prints the version or checks that direnv is older than VERSION_AT_LEAST.\nlog [--status | --error] <message>:\n  Logs a given message");
  if (priv) puts("* = private commands");
}

static int version_cmp(const char *s) {
  if (*s == 'v') s++;
  int a=0,b=0,c=0;
  char tail=0;
  if (sscanf(s, "%d.%d.%d%c", &a,&b,&c,&tail) < 3) return -999;
  if (a != 2) return 2 - a;
  if (b != 37) return 37 - b;
  return 1 - c;
}

static void hook(const char *s) {
  if (!s) die("missing target shell");
  if (!strcmp(s,"bash")) puts("\n_direnv_hook() {\n  local previous_exit_status=$?;\n  vars=\"$(\"/workspace/executable\" export bash)\";\n  trap -- '' SIGINT;\n  eval \"$vars\";\n  trap - SIGINT;\n  return $previous_exit_status;\n};\nif [[ \";${PROMPT_COMMAND[*]:-};\" != *\";_direnv_hook;\"* ]]; then\n  PROMPT_COMMAND=\"_direnv_hook${PROMPT_COMMAND:+;$PROMPT_COMMAND}\"\nfi");
  else if (!strcmp(s,"zsh")) puts("\n_direnv_hook() {\n  vars=\"$(\"/workspace/executable\" export zsh)\"\n  trap -- '' SIGINT\n  eval \"$vars\"\n  trap - SIGINT\n}\ntypeset -ag precmd_functions\nif (( ! ${precmd_functions[(I)_direnv_hook]} )); then\n  precmd_functions=(_direnv_hook $precmd_functions)\nfi");
  else if (!strcmp(s,"fish")) puts("\nfunction __direnv_export_eval --on-event fish_prompt;\n    \"/workspace/executable\" export fish | source;\nend;");
  else if (!strcmp(s,"tcsh")) puts("alias precmd 'eval `/workspace/executable export tcsh`'");
  else if (!strcmp(s,"pwsh")) puts("$ExecutionContext.SessionState.InvokeCommand.LocationChangedAction = { Invoke-Expression ((/workspace/executable export pwsh) -join [Environment]::NewLine) }");
  else if (!strcmp(s,"elvish")) puts("## hook for direnv\nset @edit:before-readline = $@edit:before-readline { /workspace/executable export elvish | from-json }");
  else if (!strcmp(s,"murex")) puts("event: onPrompt direnv_hook=before { \"/workspace/executable\" export murex }");
  else if (!strcmp(s,"gha")) die("Hook not implemented for GitHub Actions shell");
  else if (!strcmp(s,"vim")) die("this feature is not supported. Install the direnv.vim plugin instead");
  else if (!strcmp(s,"json") || !strcmp(s,"systemd")) die("this feature is not supported");
  else if (!strcmp(s,"gzenv")) die("the gzenv shell doesn't support hooking");
  else die("unknown target shell '%s'", s);
}

static char *trim(char *s) {
  while (isspace((unsigned char)*s)) s++;
  char *e = s + strlen(s);
  while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
  return s;
}

static Env parse_dotenv_file(const char *path) {
  FILE *f = fopen(path, "r");
  if (!f) die("open %s: %s", path, strerror(errno));
  Env e = {0};
  char *line = NULL;
  size_t cap = 0;
  int lineno = 0;
  while (getline(&line, &cap, f) > 0) {
    lineno++;
    char *s = trim(line);
    if (!*s || *s == '#') continue;
    if (!strncmp(s, "export ", 7)) s = trim(s + 7);
    char *eq = strchr(s, '=');
    if (!eq) die("invalid line: %s", s);
    *eq = 0;
    char *k = trim(s), *v = trim(eq + 1);
    v[strcspn(v, "\r\n")] = 0;
    if ((*v == '"' || *v == '\'') && v[strlen(v)-1] == *v) {
      v[strlen(v)-1] = 0;
      v++;
    } else if (strchr(v, ' ') || strchr(v, '\t')) die("invalid line: %s=%s", k, v);
    env_add(&e, k, v);
  }
  free(line);
  fclose(f);
  return e;
}

int main(int argc, char **argv) {
  if (argc < 2 || !strcmp(argv[1],"--help") || !strcmp(argv[1],"help")) { help(argc > 2); return 0; }
  if (!strcmp(argv[1],"--version") || !strcmp(argv[1],"version")) {
    if (argc == 2) { puts(VERSION); return 0; }
    int c = version_cmp(argv[2]);
    if (c == -999) die("v%s is not a valid semver version", argv[2]);
    if (c < 0) die("current version v%s is older than the desired version v%s", VERSION, argv[2][0]=='v'?argv[2]+1:argv[2]);
    return 0;
  }
  if (!strcmp(argv[1],"stdlib")) { print_stdlib(); return 0; }
  if (!strcmp(argv[1],"hook")) { hook(argc > 2 ? argv[2] : NULL); return 0; }
  if (!strcmp(argv[1],"log")) {
    if (argc < 4) die("invalid arguments");
    if (!strcmp(argv[2],"--status")) fprintf(stderr, "\033[0mdirenv: %s\n", argv[3]);
    else if (!strcmp(argv[2],"--error")) fprintf(stderr, "\033[31mdirenv: %s\033[0m\n", argv[3]);
    else die("invalid arguments");
    return 0;
  }
  if (!strcmp(argv[1],"allow") || !strcmp(argv[1],"permit") || !strcmp(argv[1],"grant")) {
    char *rc = rc_path_arg(argc, argv, 2);
    char *af = allow_file(rc);
    FILE *f = fopen(af, "w");
    if (!f) die("open %s: %s", af, strerror(errno));
    fprintf(f, "%s\n", rc);
    fclose(f);
    free(rc); free(af);
    return 0;
  }
  if (!strcmp(argv[1],"block") || !strcmp(argv[1],"deny") || !strcmp(argv[1],"disallow") || !strcmp(argv[1],"revoke")) {
    char *rc = rc_path_arg(argc, argv, 2);
    char *af = allow_file(rc);
    unlink(af);
    free(rc); free(af);
    return 0;
  }
  if (!strcmp(argv[1],"status")) {
    char *rc = find_rc_from(".");
    char *cd = config_dir();
    if (argc > 2 && !strcmp(argv[2],"--json")) {
      printf("{\n  \"config\": {\"ConfigDir\": ");
      json_quote(stdout, cd);
      printf(", \"SelfPath\": \"/workspace/executable\"},\n  \"state\": {\"foundRC\": ");
      if (rc) { printf("{\"allowed\": %d, \"path\": ", is_allowed(rc)); json_quote(stdout, rc); printf("}"); }
      else printf("null");
      puts(", \"loadedRC\": null}\n}");
    } else {
      puts("direnv exec path /workspace/executable");
      printf("DIRENV_CONFIG %s\nbash_path /usr/bin/bash\ndisable_stdin false\nwarn_timeout 5s\nwhitelist.prefix []\nwhitelist.exact map[]\n", cd);
      puts("No .envrc or .env loaded");
      if (rc) printf("Found RC path %s\n", rc); else puts("No .envrc or .env found");
    }
    free(cd); free(rc);
    return 0;
  }
  if (!strcmp(argv[1],"export")) {
    if (argc < 3) die("missing target shell");
    const char *shell = argv[2];
    char *rc = find_rc_from(".");
    if (!rc) return 0;
    if (!is_allowed(rc)) {
      printf("export DIRENV_DIR=");
      char *dir = abs_path(".");
      shell_quote(stdout, join3("-", dir, ""));
      printf(";export DIRENV_FILE=");
      shell_quote(stdout, rc);
      printf(";");
      fprintf(stderr, "\033[31mdirenv: error %s is blocked. Run `direnv allow` to approve its content\033[0m\n", rc);
      free(dir); free(rc);
      return 1;
    }
    int st = 0;
    Env old = current_env();
    Env ne = eval_rc(rc, &st);
    if (st) return st;
    env_add(&ne, "DIRENV_FILE", rc);
    char *dir = abs_path(".");
    char *dd = join3("-", dir, "");
    env_add(&ne, "DIRENV_DIR", dd);
    fprintf(stderr, "\033[0mdirenv: loading %s\n", rc);
    print_diff(shell, &old, &ne, rc);
    free(dir); free(dd); free(rc);
    return 0;
  }
  if (!strcmp(argv[1],"exec")) {
    if (argc < 4) die("not enough arguments");
    char *rc = find_rc_from(argv[2]);
    if (rc && is_allowed(rc)) {
      int st = 0; Env ne = eval_rc(rc, &st);
      if (!st) for (size_t i=0;i<ne.n;i++) setenv(ne.v[i].key, ne.v[i].val, 1);
    }
    execvp(argv[3], &argv[3]);
    die("exec: %s", strerror(errno));
  }
  if (!strcmp(argv[1],"dotenv")) {
    const char *shell = argc > 2 ? argv[2] : "bash";
    const char *path = argc > 3 ? argv[3] : ".env";
    Env old = {0}, ne = parse_dotenv_file(path);
    print_diff(shell, &old, &ne, path);
    return 0;
  }
  if (!strcmp(argv[1],"reload")) {
    char *rc = find_rc_from(".");
    if (!rc) die(".envrc not found");
    printf("export DIRENV_DIFF=$'reload';");
    free(rc);
    return 0;
  }
  if (!strcmp(argv[1],"prune")) return 0;
  if (!strcmp(argv[1],"fetchurl")) die("Get \"%s\": unsupported protocol scheme \"\"", argc>2?argv[2]:"");
  if (!strcmp(argv[1],"dump")) { puts("eJxsj8tKxDAYhd_lrIMpXhaTXXWqFcZ0aDO6LGn8GYM1GXJRQXx3acUL2l2-7xDO-d9w"); return 0; }
  if (!strcmp(argv[1],"watch-list")) { puts("export DIRENV_WATCHES=$'eJyKjgUEAAD__wEVALk=';"); return 0; }
  if (!strcmp(argv[1],"watch-print")) return 0;
  if (!strcmp(argv[1],"current")) { if (argc < 3) die("missing PATH argument"); return 0; }
  die("unknown command '%s'", argv[1]);
}
