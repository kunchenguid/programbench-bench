#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <fcntl.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#include <utime.h>

typedef struct {
    bool key_from_file, rep_from_file, verbose, regex;
    bool column, row, binary, statistics, skipped, preserve_time;
    bool interactive, recursive, symlink, color, file;
    bool skip_vcs, skip_gitignore, fixed_order, parent_ignore;
    int max_threads;
    size_t bin_check_bytes;
} Options;

typedef struct {
    char **items;
    size_t len, cap;
} StrVec;

typedef struct {
    const char *keyword;
    const char *replacement;
    regex_t regex;
    bool regex_ready;
    Options opt;
    bool any_match;
    bool all;
    long files_seen, files_matched, replacements;
} App;

static void vec_push(StrVec *v, char *s) {
    if (v->len == v->cap) {
        v->cap = v->cap ? v->cap * 2 : 32;
        v->items = realloc(v->items, v->cap * sizeof(char *));
        if (!v->items) { perror("realloc"); exit(2); }
    }
    v->items[v->len++] = s;
}

static int cmp_str(const void *a, const void *b) {
    const char *sa = *(char * const *)a;
    const char *sb = *(char * const *)b;
    return strcmp(sa, sb);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) { perror("strdup"); exit(2); }
    return r;
}

static void append_mem(char **buf, size_t *len, size_t *cap, const char *s, size_t n) {
    if (*len + n + 1 > *cap) {
        size_t nc = *cap ? *cap * 2 : 128;
        while (*len + n + 1 > nc) nc *= 2;
        *buf = realloc(*buf, nc);
        if (!*buf) { perror("realloc"); exit(2); }
        *cap = nc;
    }
    memcpy(*buf + *len, s, n);
    *len += n;
    (*buf)[*len] = 0;
}

static void append_str(char **buf, size_t *len, size_t *cap, const char *s) {
    append_mem(buf, len, cap, s, strlen(s));
}

static char *read_file(const char *path, size_t *out_len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long n = ftell(f);
    if (n < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)n + 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, (size_t)n, f);
    fclose(f);
    buf[got] = 0;
    if (out_len) *out_len = got;
    return buf;
}

static bool write_file(const char *path, const char *buf, size_t len) {
    FILE *f = fopen(path, "wb");
    if (!f) return false;
    bool ok = fwrite(buf, 1, len, f) == len;
    if (fclose(f) != 0) ok = false;
    return ok;
}

static void default_options(Options *o) {
    memset(o, 0, sizeof(*o));
    o->interactive = true;
    o->recursive = true;
    o->symlink = true;
    o->color = true;
    o->file = true;
    o->skip_vcs = true;
    o->skip_gitignore = true;
    o->fixed_order = true;
    o->parent_ignore = true;
    o->max_threads = 4;
    o->bin_check_bytes = 256;
}

static void print_help(const char *argv0) {
    (void)argv0;
    printf("ambr 0.6.0\n\n");
    printf("USAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\n");
    printf("FLAGS:\n");
    printf("        --key-from-file        Use file contents of KEYWORD as keyword for search\n");
    printf("        --rep-from-file        Use file contents of REPLACEMENT as keyword for replacement\n");
    printf("        --verbose              Verbose message\n");
    printf("    -r, --regex                Enable regular expression search\n");
    printf("        --column               Enable column output\n");
    printf("        --row                  Enable row output\n");
    printf("        --binary               Enable binary file search\n");
    printf("        --statistics           Enable statistics output\n");
    printf("        --skipped              Enable skipped file output\n");
    printf("        --preserve-time        Enable timestamp preserve\n");
    printf("        --no-interactive       Disable interactive replace\n");
    printf("        --no-recursive         Disable recursive directory search\n");
    printf("        --no-symlink           Disable symbolic link follow\n");
    printf("        --no-color             Disable colored output\n");
    printf("        --no-file              Disable filename output\n");
    printf("        --no-skip-vcs          Disable vcs directory ( .hg/.git/.svn ) skip\n");
    printf("        --no-skip-gitignore    Disable .gitignore skip\n");
    printf("        --no-fixed-order       Disable output order guarantee\n");
    printf("        --no-parent-ignore     Disable .*ignore file search at parent directories\n");
    printf("        --tbm                  [Experimental] Enable TBM matcher\n");
    printf("        --sse                  [Experimental] Enable SSE 4.2\n");
    printf("    -h, --help                 Prints help information\n");
    printf("    -V, --version              Prints version information\n\n");
    printf("OPTIONS:\n");
    printf("        --max-threads <NUM>          Number of max threads [default: 4]\n");
    printf("        --size-per-thread <BYTES>    File size per one thread [default: 1048576]\n");
    printf("        --bin-check-bytes <BYTES>    Read size for checking binary [default: 256]\n");
    printf("        --mmap-bytes <BYTES>         [Experimental] Minimum size for using mmap [default: 1048576]\n\n");
    printf("ARGS:\n");
    printf("    <KEYWORD>        Keyword for search\n");
    printf("    <REPLACEMENT>    Keyword for replace\n");
    printf("    <PATHS>...       Search paths\n");
}

static bool is_option_with_value(const char *a) {
    return !strcmp(a, "--max-threads") || !strcmp(a, "--size-per-thread") ||
           !strcmp(a, "--bin-check-bytes") || !strcmp(a, "--mmap-bytes");
}

static void usage_missing(void) {
    fprintf(stderr, "error: The following required arguments were not provided:\n    <KEYWORD>\n    <REPLACEMENT>\n\n");
    fprintf(stderr, "USAGE:\n    executable <KEYWORD> <REPLACEMENT> --bin-check-bytes <BYTES> --max-threads <NUM> --mmap-bytes <BYTES> --size-per-thread <BYTES>\n\n");
    fprintf(stderr, "For more information try --help\n");
}

static bool is_vcs_name(const char *n) {
    return !strcmp(n, ".git") || !strcmp(n, ".hg") || !strcmp(n, ".svn") || !strcmp(n, ".bzr");
}

static bool is_binary_buf(const char *buf, size_t len, size_t check) {
    size_t n = len < check ? len : check;
    for (size_t i = 0; i < n; i++) if (buf[i] == '\0') return true;
    return false;
}

static char *path_join(const char *a, const char *b) {
    size_t la = strlen(a), lb = strlen(b);
    bool slash = la && a[la-1] == '/';
    char *r = malloc(la + lb + (slash ? 1 : 2));
    if (!r) { perror("malloc"); exit(2); }
    sprintf(r, "%s%s%s", a, slash ? "" : "/", b);
    return r;
}

static bool ignored_by_patterns(StrVec *patterns, const char *name, bool is_dir) {
    for (size_t i = 0; i < patterns->len; i++) {
        const char *p = patterns->items[i];
        bool dir_only = false;
        size_t n = strlen(p);
        if (n && p[n - 1] == '/') {
            dir_only = true;
            if (!is_dir) continue;
        }
        char *pat = xstrdup(p);
        if (dir_only) pat[n - 1] = 0;
        bool neg = pat[0] == '!';
        const char *body = neg ? pat + 1 : pat;
        if (body[0] == '/') body++;
        bool match = fnmatch(body, name, FNM_PATHNAME) == 0 || fnmatch(body, name, 0) == 0;
        if (match && !neg) { free(pat); return true; }
        free(pat);
    }
    return false;
}

static void load_gitignore(const char *dir, StrVec *patterns) {
    char *path = path_join(dir, ".gitignore");
    size_t len = 0;
    char *buf = read_file(path, &len);
    free(path);
    if (!buf) return;
    char *save = NULL;
    for (char *line = strtok_r(buf, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        while (*line == ' ' || *line == '\t') line++;
        size_t n = strlen(line);
        while (n && (line[n-1] == '\r' || line[n-1] == ' ' || line[n-1] == '\t')) line[--n] = 0;
        if (!n || line[0] == '#') continue;
        vec_push(patterns, xstrdup(line));
    }
    free(buf);
}

static void collect_paths(const Options *opt, const char *path, StrVec *files) {
    struct stat st;
    int rc = opt->symlink ? stat(path, &st) : lstat(path, &st);
    if (rc != 0) {
        printf("Error: %s (os error %d) @ %s\n", strerror(errno), errno, path);
        printf("Error: %s (os error %d) @ %s\n", strerror(errno), errno, path);
        return;
    }
    if (S_ISREG(st.st_mode)) {
        vec_push(files, xstrdup(path));
    } else if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path);
        if (!d) {
            printf("Error: %s (os error %d) @ %s\n", strerror(errno), errno, path);
            return;
        }
        StrVec ignores = {0};
        if (opt->skip_gitignore) load_gitignore(path, &ignores);
        struct dirent *e;
        while ((e = readdir(d)) != NULL) {
            if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;
            if (opt->skip_vcs && is_vcs_name(e->d_name)) continue;
            if (opt->skip_gitignore && !strcmp(e->d_name, ".gitignore")) continue;
            char *p = path_join(path, e->d_name);
            struct stat st2;
            int rc2 = opt->symlink ? stat(p, &st2) : lstat(p, &st2);
            if (rc2 == 0 && opt->skip_gitignore && ignored_by_patterns(&ignores, e->d_name, S_ISDIR(st2.st_mode))) {
                free(p);
                continue;
            }
            if (rc2 == 0 && S_ISDIR(st2.st_mode)) {
                if (opt->recursive) collect_paths(opt, p, files);
            } else if (rc2 == 0 && S_ISREG(st2.st_mode)) {
                vec_push(files, p);
                p = NULL;
            }
            free(p);
        }
        for (size_t i = 0; i < ignores.len; i++) free(ignores.items[i]);
        free(ignores.items);
        closedir(d);
    }
}

static int line_col_for(const char *s, size_t pos, int *line, int *col) {
    int l = 1, c = 1;
    for (size_t i = 0; i < pos; i++) {
        if (s[i] == '\n') { l++; c = 1; }
        else c++;
    }
    *line = l; *col = c;
    return 0;
}

static void line_bounds(const char *s, size_t len, size_t pos, size_t *start, size_t *end) {
    size_t a = pos, b = pos;
    while (a > 0 && s[a-1] != '\n') a--;
    while (b < len && s[b] != '\n') b++;
    *start = a; *end = b;
}

static char *replace_literal_line(const char *line, size_t len, const char *key, const char *rep) {
    size_t k = strlen(key), r = strlen(rep);
    char *out = NULL; size_t olen = 0, cap = 0, i = 0;
    if (k == 0) return strndup(line, len);
    while (i < len) {
        if (i + k <= len && memcmp(line + i, key, k) == 0) {
            append_mem(&out, &olen, &cap, rep, r);
            i += k;
        } else {
            append_mem(&out, &olen, &cap, line + i, 1);
            i++;
        }
    }
    if (!out) append_mem(&out, &olen, &cap, "", 0);
    return out;
}

static void append_regex_replacement(char **out, size_t *olen, size_t *cap, const char *rep,
                                     const char *src, regmatch_t *m, size_t nmatch) {
    for (size_t i = 0; rep[i]; i++) {
        if (rep[i] == '$') {
            if (rep[i+1] == '{') {
                char *end = strchr(rep + i + 2, '}');
                if (end) {
                    int idx = atoi(rep + i + 2);
                    if (idx >= 0 && (size_t)idx < nmatch && m[idx].rm_so >= 0)
                        append_mem(out, olen, cap, src + m[idx].rm_so, (size_t)(m[idx].rm_eo - m[idx].rm_so));
                    i = (size_t)(end - rep);
                    continue;
                }
            } else if (isdigit((unsigned char)rep[i+1])) {
                int idx = rep[i+1] - '0';
                if ((size_t)idx < nmatch && m[idx].rm_so >= 0)
                    append_mem(out, olen, cap, src + m[idx].rm_so, (size_t)(m[idx].rm_eo - m[idx].rm_so));
                i++;
                continue;
            }
        }
        append_mem(out, olen, cap, rep + i, 1);
    }
}

static char *replace_regex_line(App *app, const char *line, size_t len) {
    char *tmp = strndup(line, len);
    char *out = NULL; size_t olen = 0, cap = 0, off = 0;
    regmatch_t m[10];
    while (off <= len && regexec(&app->regex, tmp + off, 10, m, 0) == 0) {
        size_t so = off + (size_t)m[0].rm_so;
        size_t eo = off + (size_t)m[0].rm_eo;
        append_mem(&out, &olen, &cap, tmp + off, so - off);
        for (int i = 0; i < 10; i++) {
            if (m[i].rm_so >= 0) { m[i].rm_so += (regoff_t)off; m[i].rm_eo += (regoff_t)off; }
        }
        append_regex_replacement(&out, &olen, &cap, app->replacement, tmp, m, 10);
        if (eo == so) {
            if (eo < len) append_mem(&out, &olen, &cap, tmp + eo, 1);
            off = eo + 1;
        } else {
            off = eo;
        }
    }
    if (off < len) append_mem(&out, &olen, &cap, tmp + off, len - off);
    if (!out) append_mem(&out, &olen, &cap, tmp, len);
    free(tmp);
    return out;
}

static bool find_next(App *app, const char *buf, size_t len, size_t from, size_t *s, size_t *e) {
    if (app->opt.regex) {
        char *tmp = strndup(buf + from, len - from);
        regmatch_t m;
        int rc = regexec(&app->regex, tmp, 1, &m, 0);
        free(tmp);
        if (rc == 0) {
            *s = from + (size_t)m.rm_so;
            *e = from + (size_t)m.rm_eo;
            return true;
        }
        return false;
    }
    const char *p = strstr(buf + from, app->keyword);
    if (!p) return false;
    *s = (size_t)(p - buf);
    *e = *s + strlen(app->keyword);
    return true;
}

static void print_preview(App *app, const char *path, const char *buf, size_t len, size_t ms) {
    size_t ls, le;
    line_bounds(buf, len, ms, &ls, &le);
    char *oldline = strndup(buf + ls, le - ls);
    char *newline = app->opt.regex ? replace_regex_line(app, buf + ls, le - ls)
                                   : replace_literal_line(buf + ls, le - ls, app->keyword, app->replacement);
    int row, col;
    line_col_for(buf, ms, &row, &col);
    if (app->opt.file) {
        if (app->opt.color) printf("\033[32m%s\033[36m: ", path);
        else printf("%s: ", path);
    }
    if (app->opt.row && app->opt.column) printf("%d:%d:", row, col);
    else if (app->opt.row) printf("%d:", row);
    else if (app->opt.column) printf("%d:", col);
    if (app->opt.color) printf("\033[33m");
    printf("%s", oldline);
    if (app->opt.color) printf("\033[37m");
    printf("\n");
    if (app->opt.color) printf("\033[36m");
    printf("    -> ");
    if (app->opt.color) printf("\033[33m");
    printf("%s", newline);
    if (app->opt.color) printf("\033[37m");
    printf("\n");
    free(oldline);
    free(newline);
}

static int ask_user(void) {
    printf("Replace keyword? [Y]es/[n]o/[a]ll/[q]uit: ");
    fflush(stdout);
    char line[64];
    if (!fgets(line, sizeof(line), stdin)) return 'y';
    for (char *p = line; *p; p++) *p = (char)tolower((unsigned char)*p);
    if (line[0] == 'n') return 'n';
    if (line[0] == 'a') return 'a';
    if (line[0] == 'q') return 'q';
    return 'y';
}

static char *replace_selected(App *app, const char *buf, size_t len, bool *changed, long *count, size_t *out_len, const char *path) {
    char *out = NULL; size_t olen = 0, cap = 0, pos = 0, s, e;
    *changed = false; *count = 0;
    while (find_next(app, buf, len, pos, &s, &e)) {
        bool do_replace = !app->opt.interactive || app->all;
        if (app->opt.interactive && !app->all) {
            print_preview(app, path, buf, len, s);
            int ans = ask_user();
            if (ans == 'q') {
                append_mem(&out, &olen, &cap, buf + pos, len - pos);
                *out_len = olen;
                return out;
            }
            if (ans == 'a') { app->all = true; do_replace = true; }
            else if (ans == 'y') do_replace = true;
        }
        append_mem(&out, &olen, &cap, buf + pos, s - pos);
        if (do_replace) {
            if (app->opt.regex) {
                char *segment = strndup(buf + s, e - s);
                regmatch_t m[10];
                if (regexec(&app->regex, segment, 10, m, 0) == 0)
                    append_regex_replacement(&out, &olen, &cap, app->replacement, segment, m, 10);
                else
                    append_mem(&out, &olen, &cap, buf + s, e - s);
                free(segment);
            } else {
                append_str(&out, &olen, &cap, app->replacement);
            }
            *changed = true;
            (*count)++;
        } else {
            append_mem(&out, &olen, &cap, buf + s, e - s);
        }
        pos = (e > s) ? e : e + 1;
        if (e == s && pos <= len) append_mem(&out, &olen, &cap, buf + e, 1);
    }
    append_mem(&out, &olen, &cap, buf + pos, len - pos);
    *out_len = olen;
    return out;
}

static void process_file(App *app, const char *path) {
    size_t len = 0;
    struct stat st;
    if (stat(path, &st) != 0) return;
    char *buf = read_file(path, &len);
    if (!buf) return;
    app->files_seen++;
    if (!app->opt.binary && is_binary_buf(buf, len, app->opt.bin_check_bytes)) {
        if (app->opt.skipped) printf("Skipped binary file @ %s\n", path);
        free(buf);
        return;
    }
    size_t s, e;
    if (!find_next(app, buf, len, 0, &s, &e)) {
        free(buf);
        return;
    }
    app->any_match = true;
    app->files_matched++;
    bool changed = false;
    long count = 0;
    size_t out_len = 0;
    char *out = replace_selected(app, buf, len, &changed, &count, &out_len, path);
    if (changed) {
        write_file(path, out, out_len);
        app->replacements += count;
        if (app->opt.preserve_time) {
            struct utimbuf ut;
            ut.actime = st.st_atime;
            ut.modtime = st.st_mtime;
            utime(path, &ut);
        }
    }
    free(out);
    free(buf);
}

static void print_statistics(App *app, double elapsed) {
    printf("\nStatistics\n");
    printf("  Max threads: %d\n\n", app->opt.max_threads);
    printf("  Consumed time ( busy / total )\n");
    printf("    Find     : 0s / %.6fs\n", elapsed);
    for (int i = 0; i < app->opt.max_threads; i++)
        printf("    Match%02d  : 0s / %.6fs\n", i, elapsed / 2.0);
    printf("    Sort     : 0s / %.6fs\n", elapsed / 3.0);
    printf("    Replace  : 0s / %.6fs\n", elapsed);
}

int main(int argc, char **argv) {
    Options opt;
    default_options(&opt);
    StrVec positional = {0}, paths = {0};
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { print_help(argv[0]); return 0; }
        else if (!strcmp(a, "-V") || !strcmp(a, "--version")) { printf("ambr 0.6.0\n"); return 0; }
        else if (!strcmp(a, "--key-from-file")) opt.key_from_file = true;
        else if (!strcmp(a, "--rep-from-file")) opt.rep_from_file = true;
        else if (!strcmp(a, "--verbose")) opt.verbose = true;
        else if (!strcmp(a, "-r") || !strcmp(a, "--regex")) opt.regex = true;
        else if (!strcmp(a, "--column")) opt.column = true;
        else if (!strcmp(a, "--row")) opt.row = true;
        else if (!strcmp(a, "--binary")) opt.binary = true;
        else if (!strcmp(a, "--statistics")) opt.statistics = true;
        else if (!strcmp(a, "--skipped")) opt.skipped = true;
        else if (!strcmp(a, "--preserve-time")) opt.preserve_time = true;
        else if (!strcmp(a, "--no-interactive")) opt.interactive = false;
        else if (!strcmp(a, "--no-recursive")) opt.recursive = false;
        else if (!strcmp(a, "--no-symlink")) opt.symlink = false;
        else if (!strcmp(a, "--no-color")) opt.color = false;
        else if (!strcmp(a, "--no-file")) opt.file = false;
        else if (!strcmp(a, "--no-skip-vcs")) opt.skip_vcs = false;
        else if (!strcmp(a, "--no-skip-gitignore")) opt.skip_gitignore = false;
        else if (!strcmp(a, "--no-fixed-order")) opt.fixed_order = false;
        else if (!strcmp(a, "--no-parent-ignore")) opt.parent_ignore = false;
        else if (!strcmp(a, "--tbm") || !strcmp(a, "--sse")) {}
        else if (is_option_with_value(a)) {
            if (i + 1 >= argc) { fprintf(stderr, "error: The argument '%s' requires a value\n", a); return 1; }
            long v = atol(argv[++i]);
            if (!strcmp(a, "--max-threads") && v > 0) opt.max_threads = (int)v;
            if (!strcmp(a, "--bin-check-bytes") && v >= 0) opt.bin_check_bytes = (size_t)v;
        } else if (a[0] == '-') {
            fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\n", a);
            fprintf(stderr, "USAGE:\n    executable [FLAGS] [OPTIONS] <KEYWORD> <REPLACEMENT> [PATHS]...\n\nFor more information try --help\n");
            return 1;
        } else {
            vec_push(&positional, a);
        }
    }
    if (positional.len < 2) { usage_missing(); return 1; }
    char *keyword = positional.items[0];
    char *replacement = positional.items[1];
    size_t flen;
    char *key_file = NULL, *rep_file = NULL;
    if (opt.key_from_file) {
        key_file = read_file(keyword, &flen);
        if (!key_file) { fprintf(stderr, "Error: %s (os error %d) @ %s\n", strerror(errno), errno, keyword); return 1; }
        keyword = key_file;
    }
    if (opt.rep_from_file) {
        rep_file = read_file(replacement, &flen);
        if (!rep_file) { fprintf(stderr, "Error: %s (os error %d) @ %s\n", strerror(errno), errno, replacement); return 1; }
        replacement = rep_file;
    }
    if (strlen(keyword) == 0) return 1;
    if (positional.len == 2) vec_push(&paths, ".");
    else for (size_t i = 2; i < positional.len; i++) vec_push(&paths, positional.items[i]);

    App app;
    memset(&app, 0, sizeof(app));
    app.keyword = keyword;
    app.replacement = replacement;
    app.opt = opt;
    if (opt.regex) {
        int rc = regcomp(&app.regex, keyword, REG_EXTENDED);
        if (rc != 0) {
            char err[256];
            regerror(rc, &app.regex, err, sizeof(err));
            fprintf(stderr, "Error: %s\n", err);
            return 1;
        }
        app.regex_ready = true;
    }

    struct timeval tv1, tv2;
    gettimeofday(&tv1, NULL);
    StrVec files = {0};
    for (size_t i = 0; i < paths.len; i++) collect_paths(&opt, paths.items[i], &files);
    if (opt.fixed_order && files.len > 1) qsort(files.items, files.len, sizeof(char *), cmp_str);
    for (size_t i = 0; i < files.len; i++) {
        process_file(&app, files.items[i]);
        free(files.items[i]);
    }
    gettimeofday(&tv2, NULL);
    double elapsed = (tv2.tv_sec - tv1.tv_sec) + (tv2.tv_usec - tv1.tv_usec) / 1000000.0;
    if (opt.statistics) print_statistics(&app, elapsed);
    if (opt.color) printf("\033(B\033[m\033(B\033[m");
    if (app.regex_ready) regfree(&app.regex);
    free(files.items);
    free(positional.items);
    free(paths.items);
    free(key_file);
    free(rep_file);
    return app.any_match ? 0 : 1;
}
