#include <ctype.h>
#include <errno.h>
#include <locale.h>
#include <ncurses.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static volatile sig_atomic_t stop_now = 0;

typedef struct {
    int async;
    int bold_mode;
    int oldstyle;
    int screensaver;
    int rainbow;
    int lambda;
    int change;
    int linux_mode;
    int force_linux;
    int x_mode;
    int lock_mode;
    int delay;
    int color;
    const char *message;
    const char *tty;
} Options;

typedef struct {
    int head;
    int length;
    int speed;
    int tick;
    int active;
} Column;

static const char *usage_text =
" Usage: cmatrix -[abBcfhlsmVxk] [-u delay] [-C color] [-t tty] [-M message]\n"
" -a: Asynchronous scroll\n"
" -b: Bold characters on\n"
" -B: All bold characters (overrides -b)\n"
" -c: Use Japanese characters as seen in the original matrix. Requires appropriate fonts\n"
" -f: Force the linux $TERM type to be on\n"
" -l: Linux mode (uses matrix console font)\n"
" -L: Lock mode (can be closed from another terminal)\n"
" -o: Use old-style scrolling\n"
" -h: Print usage and exit\n"
" -n: No bold characters (overrides -b and -B, default)\n"
" -s: \"Screensaver\" mode, exits on first keystroke\n"
" -x: X window mode, use if your xterm is using mtx.pcf\n"
" -V: Print version information and exit\n"
" -M [message]: Prints your message in the center of the screen. Overrides -L's default message.\n"
" -u delay (0 - 10, default 4): Screen update delay\n"
" -C [color]: Use this color for matrix (default green)\n"
" -r: rainbow mode\n"
" -m: lambda mode\n"
" -k: Characters change while scrolling. (Works without -o opt.)\n"
" -t [tty]: Set tty to use\n";

static void print_usage(void) {
    fputs(usage_text, stdout);
}

static void print_version(void) {
    puts(" CMatrix version 2.0 (compiled 19:59:42, Apr 17 2026)");
    puts("Email: abishekvashok@gmail.com");
    puts("Web: https://github.com/abishekvashok/cmatrix");
}

static int color_from_name(const char *name) {
    if (strcmp(name, "green") == 0) return COLOR_GREEN;
    if (strcmp(name, "red") == 0) return COLOR_RED;
    if (strcmp(name, "blue") == 0) return COLOR_BLUE;
    if (strcmp(name, "white") == 0) return COLOR_WHITE;
    if (strcmp(name, "yellow") == 0) return COLOR_YELLOW;
    if (strcmp(name, "cyan") == 0) return COLOR_CYAN;
    if (strcmp(name, "magenta") == 0) return COLOR_MAGENTA;
    if (strcmp(name, "black") == 0) return COLOR_BLACK;
    return -1;
}

static int parse_options(int argc, char **argv, Options *opt) {
    int ch;
    opterr = 0;
    while ((ch = getopt(argc, argv, "abBcfhlLo?nsmVxru:C:M:t:k")) != -1) {
        switch (ch) {
        case 'a': opt->async = 1; break;
        case 'b': opt->bold_mode = 1; break;
        case 'B': opt->bold_mode = 2; break;
        case 'c': break;
        case 'f': opt->force_linux = 1; break;
        case 'l': opt->linux_mode = 1; break;
        case 'L': opt->lock_mode = 1; break;
        case 'o': opt->oldstyle = 1; break;
        case 'n': opt->bold_mode = 0; break;
        case 's': opt->screensaver = 1; break;
        case 'm': opt->lambda = 1; break;
        case 'x': opt->x_mode = 1; break;
        case 'r': opt->rainbow = 1; break;
        case 'k': opt->change = 1; break;
        case 'h':
        case '?':
            print_usage();
            exit(0);
        case 'V':
            print_version();
            exit(0);
        case 'u':
            opt->delay = atoi(optarg);
            break;
        case 'C': {
            int c = color_from_name(optarg);
            if (c < 0) {
                puts(" Invalid color selection");
                puts(" Valid colors are green, red, blue, white, yellow, cyan, magenta and black.");
                exit(0);
            }
            opt->color = c;
            break;
        }
        case 'M':
            opt->message = optarg;
            break;
        case 't':
            opt->tty = optarg;
            break;
        default:
            print_usage();
            exit(0);
        }
    }
    return 0;
}

static void on_signal(int sig) {
    (void)sig;
    stop_now = 1;
}

static int rand_between(int min, int max) {
    if (max <= min) return min;
    return min + rand() % (max - min + 1);
}

static char matrix_char(const Options *opt) {
    static const char chars[] =
        "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        "!@#$%^&*()-_=+[]{};:,.<>/?|";
    if (opt->lambda) return '\\';
    return chars[rand() % (int)(sizeof(chars) - 1)];
}

static void init_colors(void) {
    if (!has_colors()) return;
    start_color();
    use_default_colors();
    init_pair(1, COLOR_GREEN, -1);
    init_pair(2, COLOR_RED, -1);
    init_pair(3, COLOR_BLUE, -1);
    init_pair(4, COLOR_WHITE, -1);
    init_pair(5, COLOR_YELLOW, -1);
    init_pair(6, COLOR_CYAN, -1);
    init_pair(7, COLOR_MAGENTA, -1);
    init_pair(8, COLOR_BLACK, -1);
}

static int pair_for_color(int color) {
    switch (color) {
    case COLOR_RED: return 2;
    case COLOR_BLUE: return 3;
    case COLOR_WHITE: return 4;
    case COLOR_YELLOW: return 5;
    case COLOR_CYAN: return 6;
    case COLOR_MAGENTA: return 7;
    case COLOR_BLACK: return 8;
    case COLOR_GREEN:
    default: return 1;
    }
}

static int color_for_key(int ch, int fallback) {
    switch (ch) {
    case '!': return COLOR_RED;
    case '@': return COLOR_GREEN;
    case '#': return COLOR_YELLOW;
    case '$': return COLOR_BLUE;
    case '%': return COLOR_MAGENTA;
    case '^': return COLOR_CYAN;
    case '&': return COLOR_WHITE;
    case ')': return COLOR_BLACK;
    default: return fallback;
    }
}

static void reset_column(Column *col, int rows, const Options *opt) {
    col->head = -rand_between(0, rows);
    col->length = rand_between(4, rows > 5 ? rows : 5);
    col->speed = opt->async ? rand_between(1, 4) : 1;
    col->tick = 0;
    col->active = 1;
}

static void draw_message(const Options *opt, int rows, int cols) {
    const char *msg = opt->message;
    if (!msg && opt->lock_mode) msg = "Computer locked.";
    if (!msg || !*msg) return;
    int len = (int)strlen(msg);
    int x = (cols - len) / 2;
    int y = rows / 2;
    if (x < 0) x = 0;
    attron(A_BOLD);
    mvaddnstr(y, x, msg, cols - x);
    attroff(A_BOLD);
}

static void draw_frame(Column *cols_state, int rows, int cols, Options *opt) {
    int base_pair = pair_for_color(opt->color);
    erase();
    for (int x = 0; x < cols; x += 2) {
        Column *col = &cols_state[x];
        if (!col->active) reset_column(col, rows, opt);
        if (++col->tick >= col->speed) {
            col->head++;
            col->tick = 0;
        }
        if (col->head - col->length > rows) reset_column(col, rows, opt);

        for (int j = 0; j < col->length; j++) {
            int y = col->head - j;
            if (y < 0 || y >= rows) continue;
            int pair = opt->rainbow ? 1 + rand() % 7 : base_pair;
            attr_t attrs = COLOR_PAIR(pair);
            if (j == 0 || opt->bold_mode == 2 || (opt->bold_mode == 1 && rand() % 3 == 0))
                attrs |= A_BOLD;
            attron(attrs);
            mvaddch(y, x, (chtype)matrix_char(opt));
            attroff(attrs);
        }
    }
    draw_message(opt, rows, cols);
    refresh();
}

static void run_matrix(Options *opt) {
    if (opt->force_linux || opt->linux_mode) {
        setenv("TERM", "linux", 0);
    }
    FILE *tty_file = NULL;
    if (opt->tty) {
        tty_file = fopen(opt->tty, "r+");
        if (tty_file) {
            SCREEN *screen = newterm(NULL, tty_file, tty_file);
            if (screen) set_term(screen);
            else initscr();
        } else {
            initscr();
        }
    } else {
        initscr();
    }

    cbreak();
    noecho();
    nodelay(stdscr, TRUE);
    keypad(stdscr, TRUE);
    curs_set(0);
    init_colors();
    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    srand((unsigned int)(time(NULL) ^ getpid()));

    int rows = 0, cols = 0;
    getmaxyx(stdscr, rows, cols);
    if (rows < 1) rows = 24;
    if (cols < 1) cols = 80;
    Column *state = calloc((size_t)cols + 1, sizeof(*state));
    if (!state) {
        endwin();
        if (tty_file) fclose(tty_file);
        fprintf(stderr, "Out of memory\n");
        exit(1);
    }

    int sleep_units = opt->delay;
    if (sleep_units < 0) sleep_units = 0;
    if (sleep_units > 10) sleep_units = 10;
    while (!stop_now) {
        int nr = 0, nc = 0;
        getmaxyx(stdscr, nr, nc);
        if (nr != rows || nc != cols) {
            rows = nr > 0 ? nr : rows;
            cols = nc > 0 ? nc : cols;
            Column *grown = realloc(state, ((size_t)cols + 1) * sizeof(*state));
            if (grown) {
                state = grown;
                memset(state, 0, ((size_t)cols + 1) * sizeof(*state));
            }
        }
        int ch = getch();
        if (ch != ERR) {
            if (opt->screensaver) break;
            if (ch == 'q' && !opt->lock_mode) break;
            if (ch == 'a') opt->async = !opt->async;
            else if (ch == 'b') opt->bold_mode = 1;
            else if (ch == 'B') opt->bold_mode = 2;
            else if (ch == 'n') opt->bold_mode = 0;
            else if (isdigit(ch)) sleep_units = ch - '0';
            else opt->color = color_for_key(ch, opt->color);
        }
        draw_frame(state, rows, cols, opt);
        napms(10 + sleep_units * 10);
    }

    free(state);
    curs_set(1);
    endwin();
    if (tty_file) fclose(tty_file);
}

int main(int argc, char **argv) {
    Options opt;
    memset(&opt, 0, sizeof(opt));
    opt.delay = 4;
    opt.color = COLOR_GREEN;
    setlocale(LC_ALL, "");
    parse_options(argc, argv, &opt);
    run_matrix(&opt);
    return 0;
}
