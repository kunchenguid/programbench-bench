#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  char *buf;
  size_t len;
  size_t cap;
} Str;

static const char *HELP =
"xplr 1.1.0\n"
"Arijit Basu <hi@arijitbasu.in>\n"
"A hackable, minimal, fast TUI file explorer\n"
"\n"
"USAGE:\n"
"    xplr [FLAG]... [OPTION]... [PATH] [SELECTION]...\n"
"\n"
"FLAGS:\n"
"  -                            Reads new-line (\\n) separated paths from stdin\n"
"  --                           Denotes the end of command-line flags and options\n"
"      --force-focus            Focuses on the given <PATH>, even if it is a directory\n"
"  -h, --help                   Prints help information\n"
"  -m, --pipe-msg-in            Helps safely passing messages to the active xplr\n"
"                                 session, use %%, %s and %q as the placeholders\n"
"  -M, --print-msg-in           Like --pipe-msg-in, but prints the message instead of\n"
"                                 passing to the active xplr session\n"
"      --print-pwd-as-result    Prints the present working directory when quitting\n"
"                                 with `PrintResultAndQuit`\n"
"      --read-only              Enables read-only mode (config.general.read_only)\n"
"      --read0                  Reads paths separated using the null character (\\0)\n"
"      --write0                 Prints paths separated using the null character (\\0)\n"
"  -0  --null                   Combines --read0 and --write0\n"
"  -V, --version                Prints version information\n"
"\n"
"OPTIONS:\n"
"  -c, --config <PATH>             Specifies a custom config file (default is\n"
"                                    \"$HOME/.config/xplr/init.lua\")\n"
"  -C, --extra-config <PATH>...    Specifies extra config files to load\n"
"      --on-load <MESSAGE>...      Sends messages when xplr loads\n"
"      --vroot <PATH>              Treats the specified path as the virtual root\n"
"\n"
"ARGS:\n"
"  <PATH>            Path to focus on, or enter if directory, (default is `.`)\n"
"  <SELECTION>...    Paths to select, requires <PATH> to be set explicitly\n";

static void die(const char *fmt, ...) {
  va_list ap;
  fprintf(stderr, "error: ");
  va_start(ap, fmt);
  vfprintf(stderr, fmt, ap);
  va_end(ap);
  fputc('\n', stderr);
  exit(1);
}

static void str_init(Str *s) {
  s->cap = 128;
  s->len = 0;
  s->buf = malloc(s->cap);
  if (!s->buf) die("out of memory");
  s->buf[0] = 0;
}

static void str_reserve(Str *s, size_t add) {
  if (s->len + add + 1 <= s->cap) return;
  while (s->len + add + 1 > s->cap) s->cap *= 2;
  char *p = realloc(s->buf, s->cap);
  if (!p) die("out of memory");
  s->buf = p;
}

static void str_addn(Str *s, const char *p, size_t n) {
  str_reserve(s, n);
  memcpy(s->buf + s->len, p, n);
  s->len += n;
  s->buf[s->len] = 0;
}

static void str_add(Str *s, const char *p) {
  str_addn(s, p, strlen(p));
}

static void json_quote(Str *s, const char *p) {
  str_addn(s, "\"", 1);
  for (; *p; p++) {
    unsigned char c = (unsigned char)*p;
    switch (c) {
    case '"': str_add(s, "\\\""); break;
    case '\\': str_add(s, "\\\\"); break;
    case '\n': str_add(s, "\\n"); break;
    case '\r': str_add(s, "\\r"); break;
    case '\t': str_add(s, "\\t"); break;
    case '\b': str_add(s, "\\b"); break;
    case '\f': str_add(s, "\\f"); break;
    default:
      if (c < 0x20) {
        char tmp[8];
        snprintf(tmp, sizeof tmp, "\\u%04x", c);
        str_add(s, tmp);
      } else {
        str_addn(s, (const char *)&c, 1);
      }
    }
  }
  str_addn(s, "\"", 1);
}

static bool is_bare_word(const char *s) {
  if (!*s) return false;
  for (; *s; s++) {
    if (!(isalnum((unsigned char)*s) || *s == '_')) return false;
  }
  return true;
}

static char *trim_dup(const char *s) {
  while (isspace((unsigned char)*s)) s++;
  size_t n = strlen(s);
  while (n && isspace((unsigned char)s[n - 1])) n--;
  char *r = malloc(n + 1);
  if (!r) die("out of memory");
  memcpy(r, s, n);
  r[n] = 0;
  return r;
}

static char *format_template(const char *tmpl, int argc, char **argv) {
  Str out;
  int ai = 0;
  str_init(&out);
  for (size_t i = 0; tmpl[i]; i++) {
    if (tmpl[i] != '%') {
      str_addn(&out, &tmpl[i], 1);
      continue;
    }
    i++;
    if (!tmpl[i]) str_addn(&out, "%", 1);
    else if (tmpl[i] == '%') str_addn(&out, "%", 1);
    else if (tmpl[i] == 's') {
      if (ai < argc) str_add(&out, argv[ai++]);
    } else if (tmpl[i] == 'q') {
      if (ai < argc) json_quote(&out, argv[ai++]);
      else str_add(&out, "null");
    } else if (tmpl[i] == '*' && (tmpl[i + 1] == 'q' || tmpl[i + 1] == 's')) {
      char mode = tmpl[++i];
      for (int j = ai; j < argc; j++) {
        if (j > ai) str_addn(&out, ",", 1);
        if (mode == 'q') json_quote(&out, argv[j]);
        else str_add(&out, argv[j]);
      }
      ai = argc;
    } else {
      str_addn(&out, "%", 1);
      str_addn(&out, &tmpl[i], 1);
    }
  }
  return out.buf;
}

static char *remove_spaces_outside_strings(const char *s) {
  Str out;
  bool in = false, esc = false;
  str_init(&out);
  for (; *s; s++) {
    char c = *s;
    if (in) {
      str_addn(&out, &c, 1);
      if (esc) esc = false;
      else if (c == '\\') esc = true;
      else if (c == '"') in = false;
    } else {
      if (c == '"') {
        in = true;
        str_addn(&out, &c, 1);
      } else if (!isspace((unsigned char)c)) {
        str_addn(&out, &c, 1);
      }
    }
  }
  return out.buf;
}

static char *quote_object_keys(const char *s) {
  Str out;
  bool in = false, esc = false;
  str_init(&out);
  for (size_t i = 0; s[i]; i++) {
    char c = s[i];
    if (in) {
      str_addn(&out, &c, 1);
      if (esc) esc = false;
      else if (c == '\\') esc = true;
      else if (c == '"') in = false;
      continue;
    }
    if (c == '"') {
      in = true;
      str_addn(&out, &c, 1);
      continue;
    }
    if ((c == '{' || c == ',') &&
        (isalpha((unsigned char)s[i + 1]) || s[i + 1] == '_')) {
      str_addn(&out, &c, 1);
      size_t j = i + 1;
      while (isalnum((unsigned char)s[j]) || s[j] == '_') j++;
      if (s[j] == ':') {
        str_addn(&out, "\"", 1);
        str_addn(&out, s + i + 1, j - i - 1);
        str_addn(&out, "\"", 1);
        i = j - 1;
        continue;
      }
    }
    str_addn(&out, &c, 1);
  }
  return out.buf;
}

static char *normalize_message(const char *msg) {
  char *t = trim_dup(msg);
  if (is_bare_word(t)) {
    Str out;
    str_init(&out);
    json_quote(&out, t);
    free(t);
    return out.buf;
  }

  char *colon = strchr(t, ':');
  if (colon) {
    bool simple_key = true;
    for (char *p = t; p < colon; p++) {
      if (!(isalnum((unsigned char)*p) || *p == '_')) simple_key = false;
    }
    if (simple_key) {
      *colon = 0;
      char *val = trim_dup(colon + 1);
      char *compact = remove_spaces_outside_strings(val);
      char *jsonish = quote_object_keys(compact);
      Str out;
      str_init(&out);
      str_addn(&out, "{", 1);
      json_quote(&out, t);
      str_addn(&out, ":", 1);
      str_add(&out, jsonish);
      str_addn(&out, "}", 1);
      free(t);
      free(val);
      free(compact);
      free(jsonish);
      return out.buf;
    }
  }
  return t;
}

static char *absolute_path(const char *path) {
  char *rp = realpath(path, NULL);
  if (rp) return rp;
  if (path[0] == '/') return strdup(path);
  char cwd[PATH_MAX];
  if (!getcwd(cwd, sizeof cwd)) strcpy(cwd, ".");
  Str s;
  str_init(&s);
  str_add(&s, cwd);
  str_addn(&s, "/", 1);
  str_add(&s, path);
  return s.buf;
}

static void check_exists(const char *path) {
  struct stat st;
  if (stat(path, &st) != 0) {
    char *abs = absolute_path(path);
    die("path doesn't exist: %s", abs);
  }
}

static void check_opt_path(const char *path) {
  struct stat st;
  if (stat(path, &st) != 0) die("path doesn't exist: %s", path);
}

static void read_stdin_paths(bool read0) {
  Str cur;
  str_init(&cur);
  int c;
  while ((c = getchar()) != EOF) {
    if ((!read0 && c == '\n') || (read0 && c == '\0')) {
      if (cur.len) {
        check_exists(cur.buf);
        cur.len = 0;
        cur.buf[0] = 0;
      }
    } else {
      char ch = (char)c;
      str_addn(&cur, &ch, 1);
    }
  }
  if (cur.len) check_exists(cur.buf);
  free(cur.buf);
}

static int handle_print_or_pipe(bool pipe_mode, const char *tmpl, int argc, char **argv) {
  char *fmt = format_template(tmpl, argc, argv);
  char *msg = normalize_message(fmt);
  free(fmt);
  if (!pipe_mode) {
    printf("%s", msg);
    free(msg);
    return 0;
  }

  const char *pipe = getenv("XPLR_PIPE_MSG_IN");
  if (!pipe || !*pipe) {
    printf("%s\n", msg);
    free(msg);
    return 0;
  }
  FILE *fp = fopen(pipe, "ab");
  if (!fp) die("%s (os error %d)", strerror(errno), errno);
  fputs(msg, fp);
  fputc('\n', fp);
  fclose(fp);
  free(msg);
  return 0;
}

int main(int argc, char **argv) {
  bool read0 = false, read_stdin = false, endopts = false;
  int first_arg = -1;

  for (int i = 1; i < argc; i++) {
    char *a = argv[i];
    if (!endopts && strcmp(a, "--") == 0) {
      endopts = true;
      continue;
    }
    if (!endopts && strcmp(a, "-") == 0) {
      read_stdin = true;
      continue;
    }
    if (!endopts && (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0)) {
      fputs(HELP, stdout);
      return 0;
    }
    if (!endopts && (strcmp(a, "-V") == 0 || strcmp(a, "--version") == 0)) {
      puts("xplr 1.1.0");
      return 0;
    }
    if (!endopts && (strcmp(a, "-m") == 0 || strcmp(a, "--pipe-msg-in") == 0 ||
                     strcmp(a, "-M") == 0 || strcmp(a, "--print-msg-in") == 0)) {
      bool pm = (strcmp(a, "-m") == 0 || strcmp(a, "--pipe-msg-in") == 0);
      if (i + 1 >= argc) die("usage: xplr %s FORMAT [ARGUMENT]...", a);
      return handle_print_or_pipe(pm, argv[i + 1], argc - i - 2, argv + i + 2);
    }
    if (!endopts && (strcmp(a, "-0") == 0 || strcmp(a, "--null") == 0)) {
      read0 = true;
      continue;
    }
    if (!endopts && (strcmp(a, "--read0") == 0 || strcmp(a, "--write0") == 0 ||
                     strcmp(a, "--force-focus") == 0 ||
                     strcmp(a, "--print-pwd-as-result") == 0 ||
                     strcmp(a, "--read-only") == 0)) {
      if (strcmp(a, "--read0") == 0) read0 = true;
      continue;
    }
    if (!endopts && (strcmp(a, "-c") == 0 || strcmp(a, "--config") == 0 ||
                     strcmp(a, "--vroot") == 0)) {
      if (i + 1 >= argc) die("usage: xplr %s PATH", a);
      check_opt_path(argv[++i]);
      continue;
    }
    if (!endopts && (strcmp(a, "-C") == 0 || strcmp(a, "--extra-config") == 0 ||
                     strcmp(a, "--on-load") == 0)) {
      if (i + 1 >= argc) die("usage: xplr %s PATH", a);
      i++;
      continue;
    }
    if (!endopts && a[0] == '-') {
      die("invalid argument: \"%s\", try `-- \"%s\"` or `--help`", a, a);
    }
    first_arg = i;
    break;
  }

  if (read_stdin) read_stdin_paths(read0);
  if (first_arg >= 0) {
    for (int i = first_arg; i < argc; i++) check_exists(argv[i]);
  } else {
    check_exists(".");
  }

  die("No such device or address (os error 6)");
  return 1;
}
