#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

typedef struct {
    int rate, channels, bits, encoding; /* 1 signed PCM, 2 unsigned PCM */
    uint64_t samples;
    unsigned char *data;
    size_t data_size;
    char type[16];
    char name[256];
} Audio;

static const char *prog = "./executable";

static uint16_t rd16(const unsigned char *p){ return (uint16_t)p[0] | ((uint16_t)p[1]<<8); }
static uint32_t rd32(const unsigned char *p){ return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24); }
static void wr16(FILE *f, uint16_t v){ fputc(v&255,f); fputc((v>>8)&255,f); }
static void wr32(FILE *f, uint32_t v){ wr16(f, v&65535); wr16(f, v>>16); }

static int endswith(const char *s, const char *suf) {
    size_t a=strlen(s), b=strlen(suf);
    return a>=b && strcasecmp(s+a-b, suf)==0;
}

static double parse_num(const char *s) {
    char *end = NULL;
    double v = strtod(s, &end);
    if (end && (*end=='k' || *end=='K')) v *= 1000.0;
    return v;
}

static double parse_time(const char *s) {
    if (strchr(s, ':')) {
        double parts[3] = {0,0,0};
        char tmp[128]; strncpy(tmp, s, sizeof(tmp)-1); tmp[sizeof(tmp)-1]=0;
        int n=0; char *tok=strtok(tmp, ":");
        while (tok && n<3) { parts[n++]=atof(tok); tok=strtok(NULL, ":"); }
        if (n==3) return parts[0]*3600 + parts[1]*60 + parts[2];
        if (n==2) return parts[0]*60 + parts[1];
    }
    return atof(s);
}

static int is_effect_name(const char *s) {
    const char *names[] = {"allpass","band","bandpass","bandreject","bass","bend","biquad","chorus","channels","compand","contrast","dcshift","deemph","delay","dither","downsample","earwax","echo","echos","equalizer","fade","fir","flanger","gain","highpass","loudness","lowpass","mcompand","noiseprof","noisered","norm","oops","overdrive","pad","phaser","pitch","rate","remix","repeat","reverb","reverse","riaa","silence","sinc","speed","splice","stat","stats","stretch","swap","synth","tempo","treble","tremolo","trim","upsample","vad","vol",NULL};
    for (int i=0; names[i]; i++) if (!strcmp(s,names[i])) return 1;
    return 0;
}

static void version(void) {
    printf("%s:      SoX v14.4.2\n", prog);
}

static void help(void) {
    version();
    puts("\nUsage summary: [gopts] [[fopts] infile]... [fopts] outfile [effect [effopt]]...\n");
    puts("SPECIAL FILENAMES (infile, outfile):");
    puts("-                        Pipe/redirect input/output (stdin/stdout); may need -t");
    puts("-d, --default-device     Use the default audio device (where available)");
    puts("-n, --null               Use the `null' file handler; e.g. with synth effect");
    puts("-p, --sox-pipe           Alias for `-t sox -'\n");
    puts("GLOBAL OPTIONS (gopts) (can be specified at any point before the first effect):");
    puts("--buffer BYTES           Set the size of all processing buffers (default 8192)");
    puts("--clobber                Don't prompt to overwrite output file (default)");
    puts("--combine concatenate    Concatenate all input files (default for sox, rec)");
    puts("-D, --no-dither          Don't dither automatically");
    puts("-h, --help               Display version number and usage information");
    puts("--help-effect NAME       Show usage of effect NAME, or NAME=all for all");
    puts("--help-format NAME       Show info on format NAME, or NAME=all for all");
    puts("--i, --info              Behave as soxi(1)");
    puts("-m, --combine mix        Mix multiple input files (instead of concatenating)");
    puts("-M, --combine merge      Merge multiple input files (instead of concatenating)");
    puts("-q, --no-show-progress   Run in quiet mode; opposite of -S");
    puts("-S, --show-progress      Display progress while processing audio data");
    puts("--version                Display version number of SoX and exit");
    puts("-V[LEVEL]                Increment or set verbosity level (default 2)\n");
    puts("FORMAT OPTIONS (fopts):");
    puts("-v|--volume FACTOR       Input file volume adjustment factor (real number)");
    puts("-t|--type FILETYPE       File type of audio");
    puts("-e|--encoding ENCODING   Set encoding");
    puts("-b|--bits BITS           Encoded sample size in bits");
    puts("-c|--channels CHANNELS   Number of channels of audio data; e.g. 2 = stereo");
    puts("-r|--rate RATE           Sample rate of audio\n");
    puts("AUDIO FILE FORMATS: raw s8 u8 s16 u16 s24 s32 wav wavpcm");
    puts("\nEFFECTS: gain norm stat stats synth trim vol");
    puts("EFFECT OPTIONS (effopts): effect dependent; see --help-effect");
}

static void help_effect(const char *e) {
    version();
    puts("\nEffect usage:\n");
    if (!e || !strcmp(e,"all")) {
        puts("gain [-e|-n] [dB]");
        puts("norm [dB]");
        puts("stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]");
        puts("stats");
        puts("synth [-j KEY] [-n] [length ...] {type ... freq ...}");
        puts("trim {position} [length]");
        puts("vol GAIN [TYPE [LIMITERGAIN]]");
    } else if (!strcmp(e,"synth")) puts("synth [-j KEY] [-n] [length [offset [phase [p1 [p2 [p3]]]]]]] {type [combine] [[%]freq[k][:|+|/|-[%]freq2[k]] [offset [phase [p1 [p2 [p3]]]]]]}");
    else if (!strcmp(e,"trim")) puts("trim {position}");
    else if (!strcmp(e,"stat")) puts("stat [ -s N ] [ -rms ] [-freq] [ -v ] [ -d ]");
    else if (!strcmp(e,"vol")) puts("vol GAIN [TYPE [LIMITERGAIN]]\n\t(default TYPE=amplitude: 1 is constant, < 0 change phase;\n\tTYPE=power 1 is constant; TYPE=dB: 0 is constant, +6 doubles ampl.)");
    else printf("%s\n", e);
}

static void help_format(const char *fmt) {
    version();
    if (!fmt || !strcmp(fmt,"all")) {
        puts("\nAUDIO FILE FORMATS: raw s8 u8 s16 u16 wav wavpcm");
        return;
    }
    printf("\nFormat: %s\n", fmt);
    if (!strcmp(fmt,"wav") || !strcmp(fmt,"wavpcm")) {
        puts("Description: Microsoft audio format");
        puts("Also handles: wavpcm amb");
        puts("Reads: yes");
        puts("Writes:");
        puts("  16-bit Signed Integer PCM (16-bit precision)");
        puts("  24-bit Signed Integer PCM (24-bit precision)");
        puts("  32-bit Signed Integer PCM (32-bit precision)");
        puts("   8-bit Unsigned Integer PCM (8-bit precision)");
    } else if (!strcmp(fmt,"raw")) {
        puts("Description: Raw PCM, mu-law, or A-law");
        puts("Reads: yes");
        puts("Writes: yes");
    } else puts("Reads: yes\nWrites: yes");
}

static int read_file(const char *path, unsigned char **buf, size_t *len) {
    FILE *f = !strcmp(path,"-") ? stdin : fopen(path,"rb");
    if (!f) return -1;
    size_t cap=8192, n=0; unsigned char *b=malloc(cap);
    int c;
    while ((c=fgetc(f)) != EOF) {
        if (n==cap) { cap*=2; b=realloc(b,cap); }
        b[n++]=(unsigned char)c;
    }
    if (f!=stdin) fclose(f);
    *buf=b; *len=n; return 0;
}

static int load_wav(const char *path, Audio *a) {
    unsigned char *b=NULL; size_t n=0;
    if (read_file(path,&b,&n)) { fprintf(stderr,"%s FAIL formats: can't open input file `%s': %s\n", prog,path,strerror(errno)); return 2; }
    if (n<44 || memcmp(b,"RIFF",4) || memcmp(b+8,"WAVE",4)) {
        fprintf(stderr,"%s FAIL formats: can't open input file `%s': WAVE: RIFF header not found\n", prog,path);
        free(b); return 2;
    }
    size_t pos=12, data_pos=0, data_len=0; int gotfmt=0;
    while (pos+8<=n) {
        char id[5]; memcpy(id,b+pos,4); id[4]=0;
        uint32_t sz=rd32(b+pos+4); pos+=8;
        if (pos+sz>n) break;
        if (!memcmp(id,"fmt ",4) && sz>=16) {
            uint16_t af=rd16(b+pos);
            a->channels=rd16(b+pos+2); a->rate=(int)rd32(b+pos+4);
            a->bits=rd16(b+pos+14); a->encoding = (a->bits==8 ? 2 : 1);
            if (af != 1) a->encoding = 1;
            gotfmt=1;
        } else if (!memcmp(id,"data",4)) { data_pos=pos; data_len=sz; }
        pos += sz + (sz&1);
    }
    if (!gotfmt || !data_pos) { free(b); return 2; }
    a->data=malloc(data_len); memcpy(a->data,b+data_pos,data_len); a->data_size=data_len;
    uint64_t bytes_per_sample=(uint64_t)a->channels*((a->bits+7)/8);
    a->samples = bytes_per_sample ? data_len/bytes_per_sample : 0;
    strcpy(a->type,"wav"); strncpy(a->name,path,sizeof(a->name)-1);
    free(b); return 0;
}

static int load_raw(const char *path, Audio *a, int rate, int ch, int bits, int enc) {
    unsigned char *b=NULL; size_t n=0;
    if (read_file(path,&b,&n)) { fprintf(stderr,"%s FAIL formats: can't open input file `%s': %s\n", prog,path,strerror(errno)); return 2; }
    a->rate=rate?rate:8000; a->channels=ch?ch:1; a->bits=bits?bits:8; a->encoding=enc?enc:(a->bits==8?2:1);
    a->data=b; a->data_size=n;
    uint64_t frame=(uint64_t)a->channels*((a->bits+7)/8);
    a->samples = frame ? n/frame : 0;
    strcpy(a->type,"raw"); strncpy(a->name,path,sizeof(a->name)-1);
    return 0;
}

static int write_wav(const char *path, const Audio *a) {
    FILE *f = !strcmp(path,"-") ? stdout : fopen(path,"wb");
    if (!f) { fprintf(stderr,"%s FAIL formats: can't open output file `%s': %s\n", prog,path,strerror(errno)); return 2; }
    uint16_t block = a->channels * ((a->bits+7)/8);
    uint32_t byte_rate = a->rate * block;
    uint32_t data = (uint32_t)a->data_size;
    fwrite("RIFF",1,4,f); wr32(f,36+data); fwrite("WAVEfmt ",1,8,f);
    wr32(f,16); wr16(f,1); wr16(f,a->channels); wr32(f,a->rate); wr32(f,byte_rate);
    wr16(f,block); wr16(f,a->bits); fwrite("data",1,4,f); wr32(f,data);
    fwrite(a->data,1,a->data_size,f);
    if (f!=stdout) fclose(f);
    return 0;
}

static int write_raw(const char *path, const Audio *a) {
    FILE *f = !strcmp(path,"-") ? stdout : fopen(path,"wb");
    if (!f) return 2;
    fwrite(a->data,1,a->data_size,f);
    if (f!=stdout) fclose(f);
    return 0;
}

static double get_sample(const Audio *a, uint64_t i) {
    if (a->bits==8) {
        unsigned char v=a->data[i];
        return a->encoding==2 ? ((int)v-128)/128.0 : ((int8_t)v)/128.0;
    }
    if (a->bits==16) {
        size_t p=i*2; int16_t v=(int16_t)rd16(a->data+p); return v/32768.0;
    }
    if (a->bits==24) {
        size_t p=i*3; int32_t v=a->data[p]|(a->data[p+1]<<8)|(a->data[p+2]<<16); if (v&0x800000) v|=~0xffffff; return v/8388608.0;
    }
    if (a->bits==32) {
        size_t p=i*4; int32_t v=(int32_t)rd32(a->data+p); return v/2147483648.0;
    }
    return 0;
}

static void set_sample(Audio *a, uint64_t i, double x) {
    if (x>0.999969) x=0.999969; if (x<-1) x=-1;
    if (a->bits==8) {
        int v = a->encoding==2 ? (int)lrint(x*127.0+128.0) : (int)lrint(x*127.0);
        if (v<0) v=0; if (v>255) v=255; a->data[i]=(unsigned char)v;
    } else if (a->bits==16) {
        int v=(int)lrint(x*32767.0); size_t p=i*2; a->data[p]=v&255; a->data[p+1]=(v>>8)&255;
    } else if (a->bits==24) {
        int32_t v=(int32_t)lrint(x*8388607.0); size_t p=i*3; a->data[p]=v&255; a->data[p+1]=(v>>8)&255; a->data[p+2]=(v>>16)&255;
    } else if (a->bits==32) {
        int32_t v=(int32_t)lrint(x*2147483647.0); size_t p=i*4; a->data[p]=v&255; a->data[p+1]=(v>>8)&255; a->data[p+2]=(v>>16)&255; a->data[p+3]=(v>>24)&255;
    }
}

static Audio synth(double dur, int rate, int ch, int bits, double freq, const char *type) {
    Audio a; memset(&a,0,sizeof(a));
    a.rate=rate?rate:48000; a.channels=ch?ch:1; a.bits=bits?bits:32; a.encoding=a.bits==8?2:1; strcpy(a.type,"wav"); strcpy(a.name,"");
    a.samples=(uint64_t)llround(dur*a.rate); if (a.samples<1) a.samples=1;
    size_t total=(size_t)a.samples*a.channels*((a.bits+7)/8); a.data=calloc(1,total); a.data_size=total;
    uint64_t idx=0;
    for (uint64_t i=0;i<a.samples;i++) {
        double t=(double)i/a.rate, x;
        if (type && (!strcmp(type,"square"))) x = sin(2*M_PI*freq*t)>=0 ? .7 : -.7;
        else if (type && (!strcmp(type,"triangle"))) x = asin(sin(2*M_PI*freq*t))*2/M_PI*.7;
        else if (type && (!strcmp(type,"noise")||!strcmp(type,"whitenoise"))) x = ((rand()/(double)RAND_MAX)*2-1)*.7;
        else x = sin(2*M_PI*freq*t)*.7;
        for (int c=0;c<a.channels;c++) set_sample(&a, idx++, x);
    }
    return a;
}

static void trim_audio(Audio *a, double start, double len) {
    uint64_t s=(uint64_t)llround(start*a->rate); if (s>a->samples) s=a->samples;
    uint64_t n = len>=0 ? (uint64_t)llround(len*a->rate) : (a->samples-s);
    if (s+n>a->samples) n=a->samples-s;
    size_t frame=a->channels*((a->bits+7)/8), bytes=(size_t)n*frame;
    memmove(a->data, a->data+(size_t)s*frame, bytes);
    a->data=realloc(a->data, bytes?bytes:1); a->data_size=bytes; a->samples=n;
}

static void scale_audio(Audio *a, double gain) {
    uint64_t total=a->samples*a->channels;
    for (uint64_t i=0;i<total;i++) set_sample(a,i,get_sample(a,i)*gain);
}

static void convert_channels(Audio *a, int newch) {
    if (newch <= 0 || newch == a->channels) return;
    int bytes=(a->bits+7)/8;
    unsigned char *out=calloc((size_t)a->samples*newch*bytes,1);
    Audio b=*a; b.channels=newch; b.data=out; b.data_size=(size_t)a->samples*newch*bytes;
    for (uint64_t f=0; f<a->samples; f++) {
        double mono=0;
        for (int c=0;c<a->channels;c++) mono += get_sample(a, f*a->channels+c);
        mono /= a->channels;
        for (int c=0;c<newch;c++) {
            double v = (a->channels==1) ? get_sample(a, f*a->channels) : mono;
            set_sample(&b, f*newch+c, v);
        }
    }
    free(a->data); a->data=out; a->channels=newch; a->data_size=b.data_size;
}

static void resample_audio(Audio *a, int newrate) {
    if (newrate <= 0 || newrate == a->rate || a->samples == 0) return;
    uint64_t ns=(uint64_t)llround((double)a->samples*newrate/a->rate);
    if (ns < 1) ns=1;
    int bytes=(a->bits+7)/8;
    unsigned char *out=calloc((size_t)ns*a->channels*bytes,1);
    Audio b=*a; b.rate=newrate; b.samples=ns; b.data=out; b.data_size=(size_t)ns*a->channels*bytes;
    for (uint64_t f=0; f<ns; f++) {
        double srcpos=(double)f*a->rate/newrate;
        uint64_t s0=(uint64_t)floor(srcpos), s1=s0+1; double frac=srcpos-s0;
        if (s0>=a->samples) s0=a->samples-1; if (s1>=a->samples) s1=a->samples-1;
        for (int c=0;c<a->channels;c++) {
            double v0=get_sample(a,s0*a->channels+c), v1=get_sample(a,s1*a->channels+c);
            set_sample(&b,f*a->channels+c,v0+(v1-v0)*frac);
        }
    }
    free(a->data); a->data=out; a->rate=newrate; a->samples=ns; a->data_size=b.data_size;
}

static double peak_audio(const Audio *a) {
    double p=0; uint64_t total=a->samples*a->channels;
    for (uint64_t i=0;i<total;i++) { double v=fabs(get_sample(a,i)); if (v>p) p=v; }
    return p;
}

static void print_duration(double sec, char *buf, size_t sz) {
    int h=(int)(sec/3600); sec-=h*3600; int m=(int)(sec/60); sec-=m*60;
    snprintf(buf,sz,"%02d:%02d:%05.2f",h,m,sec);
}

static const char *enc_name(const Audio *a) {
    if (a->encoding==2) return "Unsigned Integer PCM";
    return "Signed Integer PCM";
}

static void soxi_one(const Audio *a, const char *opt) {
    double sec = a->rate ? (double)a->samples/a->rate : 0;
    if (opt) {
        if (!strcmp(opt,"-t")) puts(a->type);
        else if (!strcmp(opt,"-r")) printf("%d\n",a->rate);
        else if (!strcmp(opt,"-c")) printf("%d\n",a->channels);
        else if (!strcmp(opt,"-s")) printf("%llu\n",(unsigned long long)a->samples);
        else if (!strcmp(opt,"-d")) { char b[32]; print_duration(sec,b,sizeof(b)); puts(b); }
        else if (!strcmp(opt,"-D")) printf("%.6f\n",sec);
        else if (!strcmp(opt,"-b") || !strcmp(opt,"-p")) printf("%d\n",a->bits);
        else if (!strcmp(opt,"-B")) printf("%gk\n", sec>0 ? (a->data_size*8/sec)/1000.0 : 0);
        else if (!strcmp(opt,"-e")) puts(enc_name(a));
        else if (!strcmp(opt,"-a")) ;
        return;
    }
    char dur[32]; print_duration(sec,dur,sizeof(dur));
    double sectors = sec*75.0;
    long fsize = (long)a->data_size + 44;
    printf("\nInput File     : '%s'\n", a->name);
    printf("Channels       : %d\n", a->channels);
    printf("Sample Rate    : %d\n", a->rate);
    printf("Precision      : %d-bit\n", a->bits);
    printf("Duration       : %s = %llu samples ~ %.3g CDDA sectors\n", dur, (unsigned long long)a->samples, sectors);
    printf("File Size      : %ld\n", fsize);
    printf("Bit Rate       : %.3gk\n", sec>0 ? (fsize*8/sec)/1000.0 : 0);
    printf("Sample Encoding: %d-bit %s\n\n", a->bits, enc_name(a));
}

static void stat_audio(const Audio *a) {
    uint64_t total=a->samples*a->channels;
    double max=-9,min=9,sum=0,abssum=0,sq=0,maxd=0,mind=9,dsum=0,dsq=0,last=0;
    for (uint64_t i=0;i<total;i++) {
        double v=get_sample(a,i); if (v>max) max=v; if (v<min) min=v; sum+=v; abssum+=fabs(v); sq+=v*v;
        if (i) { double d=fabs(v-last); if (d>maxd) maxd=d; if (d<mind) mind=d; dsum+=d; dsq+=d*d; }
        last=v;
    }
    double n=total?total:1, dn=total>1?total-1:1, sec=a->rate?(double)a->samples/a->rate:0, peak=fmax(fabs(max),fabs(min));
    fprintf(stderr,"Samples read:        %10llu\n",(unsigned long long)a->samples);
    fprintf(stderr,"Length (seconds): %13.6f\n",sec);
    fprintf(stderr,"Scaled by:         2147483647.0\n");
    fprintf(stderr,"Maximum amplitude: %12.6f\n",max);
    fprintf(stderr,"Minimum amplitude: %12.6f\n",min);
    fprintf(stderr,"Midline amplitude: %12.6f\n",(max+min)/2);
    fprintf(stderr,"Mean    norm:      %12.6f\n",abssum/n);
    fprintf(stderr,"Mean    amplitude: %12.6f\n",sum/n);
    fprintf(stderr,"RMS     amplitude: %12.6f\n",sqrt(sq/n));
    fprintf(stderr,"Maximum delta:     %12.6f\n",maxd);
    fprintf(stderr,"Minimum delta:     %12.6f\n",total>1?mind:0);
    fprintf(stderr,"Mean    delta:     %12.6f\n",dsum/dn);
    fprintf(stderr,"RMS     delta:     %12.6f\n",sqrt(dsq/dn));
    fprintf(stderr,"Rough   frequency: %12d\n",0);
    fprintf(stderr,"Volume adjustment: %12.3f\n\n", peak>0 ? 1.0/peak : 0);
}

int main(int argc, char **argv) {
    prog = argv[0];
    if (argc < 2) { fprintf(stderr,"%s FAIL sox: No input filenames specified\n\n", prog); help(); return 1; }
    int info=0, rate=0, ch=0, bits=0, enc=0; const char *type=NULL, *outtype=NULL, *infoopt=NULL;
    const char *files[64]; int nf=0, i=1;
    for (; i<argc; i++) {
        char *arg=argv[i];
        if (nf > 0 && is_effect_name(arg)) break;
        if (!strcmp(arg,"--version")) { version(); return 0; }
        if (!strcmp(arg,"--help") || !strcmp(arg,"-h")) { help(); return 0; }
        if (!strcmp(arg,"--help-effect") && i+1<argc) { help_effect(argv[i+1]); return 0; }
        if (!strcmp(arg,"--help-format") && i+1<argc) { help_format(argv[i+1]); return 0; }
        if (!strcmp(arg,"--i") || !strcmp(arg,"--info")) { info=1; continue; }
        if (info && (!strcmp(arg,"-t")||!strcmp(arg,"-r")||!strcmp(arg,"-c")||!strcmp(arg,"-s")||!strcmp(arg,"-d")||!strcmp(arg,"-D")||!strcmp(arg,"-b")||!strcmp(arg,"-B")||!strcmp(arg,"-p")||!strcmp(arg,"-e")||!strcmp(arg,"-a"))) { infoopt=arg; continue; }
        if (!strcmp(arg,"-V") || !strncmp(arg,"-V",2) || !strcmp(arg,"-q") || !strcmp(arg,"-S") || !strcmp(arg,"--clobber") || !strcmp(arg,"--no-clobber") || !strcmp(arg,"-D")) continue;
        if ((!strcmp(arg,"-r")||!strcmp(arg,"--rate")) && i+1<argc) { rate=(int)parse_num(argv[++i]); continue; }
        if ((!strcmp(arg,"-c")||!strcmp(arg,"--channels")) && i+1<argc) { ch=atoi(argv[++i]); continue; }
        if ((!strcmp(arg,"-b")||!strcmp(arg,"--bits")) && i+1<argc) { bits=atoi(argv[++i]); continue; }
        if ((!strcmp(arg,"-e")||!strcmp(arg,"--encoding")) && i+1<argc) { char *e=argv[++i]; enc=strstr(e,"unsigned")?2:1; continue; }
        if ((!strcmp(arg,"-t")||!strcmp(arg,"--type")) && i+1<argc) { if (nf==0) type=argv[++i]; else outtype=argv[++i]; continue; }
        if (!strcmp(arg,"-v") && i+1<argc) { i++; continue; }
        if (arg[0]=='-' && strcmp(arg,"-n") && strcmp(arg,"-")) { fprintf(stderr,"%s WARN getopt: parameter not recognized from `%s'\n%s FAIL sox: invalid option\n\n", prog,arg,prog); help(); return 1; }
        files[nf++]=arg;
    }
    if (info || strstr(prog,"soxi")) {
        for (int k=0;k<nf || i<argc;k++) {
            const char *fn = k<nf ? files[k] : argv[i++];
            Audio a; memset(&a,0,sizeof(a));
            int rc = (type && !strcmp(type,"raw")) ? load_raw(fn,&a,rate,ch,bits,enc) : load_wav(fn,&a);
            if (rc) return rc;
            soxi_one(&a, infoopt); free(a.data);
        }
        return 0;
    }
    if (nf < 2 && !(nf==1 && !strcmp(files[0],"-n"))) { fprintf(stderr,"%s FAIL sox: Not enough input filenames specified\n", prog); return 1; }
    const char *in = files[0], *out = nf>=2 ? files[nf-1] : NULL;
    Audio a; memset(&a,0,sizeof(a)); int rc=0;
    if (!strcmp(in,"-n")) {
        if (!out && i<argc) out=argv[i++];
        double dur=1.0, freq=440; const char *wave="sine";
        for (int j=i;j<argc;j++) if (!strcmp(argv[j],"synth")) {
            if (j+1<argc) dur=parse_time(argv[++j]);
            if (j+1<argc) wave=argv[++j];
            if (j+1<argc) freq=parse_num(argv[++j]);
            break;
        }
        a=synth(dur,rate,ch,bits,freq,wave);
    } else {
        if ((type && !strcmp(type,"raw")) || (type && !strcmp(type,"s8")) || (type && !strcmp(type,"u8")) || endswith(in,".raw")) rc=load_raw(in,&a,rate,ch,bits,enc);
        else if (endswith(in,".wav") || !type) rc=load_wav(in,&a);
        else rc=load_raw(in,&a,rate,ch,bits,enc);
        if (rc) return rc;
        for (int fi=1; fi<nf-1; fi++) {
            Audio b; memset(&b,0,sizeof(b));
            rc = ((type && !strcmp(type,"raw")) ? load_raw(files[fi],&b,rate,ch,bits,enc) : load_wav(files[fi],&b));
            if (rc) { free(a.data); return rc; }
            if (b.rate==a.rate && b.channels==a.channels && b.bits==a.bits && b.encoding==a.encoding) {
                a.data = realloc(a.data, a.data_size + b.data_size);
                memcpy(a.data + a.data_size, b.data, b.data_size);
                a.data_size += b.data_size;
                a.samples += b.samples;
            }
            free(b.data);
        }
    }
    for (; i<argc; i++) {
        if (!strcmp(argv[i],"trim") && i+1<argc) { double st=parse_time(argv[++i]); double len=-1; if (i+1<argc && argv[i+1][0]!='-') len=parse_time(argv[++i]); trim_audio(&a,st,len); }
        else if (!strcmp(argv[i],"vol") && i+1<argc) scale_audio(&a, atof(argv[++i]));
        else if (!strcmp(argv[i],"channels") && i+1<argc) convert_channels(&a, atoi(argv[++i]));
        else if (!strcmp(argv[i],"rate") && i+1<argc) resample_audio(&a, (int)parse_num(argv[++i]));
        else if (!strcmp(argv[i],"gain") && i+1<argc) { double db=0; if (!strcmp(argv[i+1],"-n")) { double p=peak_audio(&a); if (p>0) scale_audio(&a,1.0/p); i++; } else { db=atof(argv[++i]); scale_audio(&a,pow(10,db/20)); } }
        else if (!strcmp(argv[i],"norm")) { double p=peak_audio(&a); if (p>0) scale_audio(&a,1.0/p); }
        else if (!strcmp(argv[i],"stat") || !strcmp(argv[i],"stats")) stat_audio(&a);
    }
    if (!out || !strcmp(out, "-n")) { free(a.data); return 0; }
    if ((outtype && !strcmp(outtype,"raw")) || endswith(out,".raw")) rc=write_raw(out,&a);
    else rc=write_wav(out,&a);
    free(a.data);
    return rc;
}
