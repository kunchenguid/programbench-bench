#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <grp.h>
#include <math.h>
#include <pwd.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

typedef struct { char **v; int n, cap; } StrVec;
typedef struct { char *abs, *rel, *root; int depth; struct stat st; } Row;
typedef struct { Row *v; int n, cap; } Rows;

static void dieoom(void){ fprintf(stderr,"out of memory\n"); exit(1); }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) dieoom(); return p; }
static char *xstrndup(const char *s,size_t n){ char *p=strndup(s,n); if(!p) dieoom(); return p; }
static void sv_push(StrVec *a, char *s){ if(a->n==a->cap){ a->cap=a->cap?a->cap*2:16; a->v=realloc(a->v,a->cap*sizeof(char*)); if(!a->v) dieoom(); } a->v[a->n++]=s; }
static void rows_push(Rows *r, Row row){ if(r->n==r->cap){ r->cap=r->cap?r->cap*2:128; r->v=realloc(r->v,r->cap*sizeof(Row)); if(!r->v) dieoom(); } r->v[r->n++]=row; }
static int streqi(const char *a,const char *b){ for(;*a&&*b;a++,b++) if(tolower((unsigned char)*a)!=tolower((unsigned char)*b)) return 0; return !*a&&!*b; }
static int is_kw(const char *s,const char *kw){ return streqi(s,kw); }
static char *lower_dup(const char *s){ char *r=xstrdup(s); for(char*p=r;*p;p++) *p=tolower((unsigned char)*p); return r; }
static void trim_inplace(char *s){
    while(isspace((unsigned char)*s)) memmove(s,s+1,strlen(s));
    size_t n=strlen(s);
    while(n && isspace((unsigned char)s[n-1])) s[--n]=0;
}

static char *join_args(int argc,char **argv,int start){
    size_t len=0; for(int i=start;i<argc;i++) len+=strlen(argv[i])+1;
    char *s=calloc(1,len+1); if(!s) dieoom();
    for(int i=start;i<argc;i++){ if(i>start) strcat(s," "); strcat(s,argv[i]); }
    return s;
}

static StrVec tokenize(const char *q){
    StrVec t={0};
    for(size_t i=0;q[i];){
        if(isspace((unsigned char)q[i])){ i++; continue; }
        if(q[i]=='\''||q[i]=='"'||q[i]=='`'){
            char quote=q[i++]; size_t start=i; char *buf=calloc(1,strlen(q+start)+1); if(!buf) dieoom(); size_t k=0;
            while(q[i] && q[i]!=quote){ if(q[i]=='\\'&&q[i+1]) i++; buf[k++]=q[i++]; }
            if(q[i]==quote) i++; buf[k]=0; sv_push(&t,buf); continue;
        }
        if(strchr(",()",q[i])){ char b[2]={q[i++],0}; sv_push(&t,xstrdup(b)); continue; }
        if(strchr("<>!=~",q[i])){
            size_t start=i; i++;
            while(strchr("<>!=~",q[i])) i++;
            sv_push(&t,xstrndup(q+start,i-start)); continue;
        }
        size_t start=i;
        while(q[i] && !isspace((unsigned char)q[i]) && !strchr(",()<>!=~",q[i])) i++;
        sv_push(&t,xstrndup(q+start,i-start));
    }
    return t;
}

typedef struct {
    StrVec toks, cols, roots, order_cols;
    int where_start, where_end;
    int limit, offset;
    int mindepth, maxdepth;
    char *format;
    int order_desc;
} Query;

static char *tokens_join(StrVec *t,int a,int b,const char *sep){
    size_t len=1; for(int i=a;i<b;i++) len+=strlen(t->v[i])+strlen(sep);
    char *s=calloc(1,len); if(!s) dieoom();
    for(int i=a;i<b;i++){ if(i>a) strcat(s,sep); strcat(s,t->v[i]); }
    return s;
}

static void split_expr_list(StrVec *out, StrVec *t, int a, int b){
    int depth=0,start=a;
    for(int i=a;i<=b;i++){
        int cut=(i==b);
        if(!cut){
            if(!strcmp(t->v[i],"(")) depth++;
            else if(!strcmp(t->v[i],")")) depth--;
            else if(!strcmp(t->v[i],",") && depth==0) cut=1;
        }
        if(cut){
            while(start<i && !strcmp(t->v[start],",")) start++;
            if(start<i) sv_push(out,tokens_join(t,start,i," "));
            start=i+1;
        }
    }
}

static Query parse_query(char *qstr){
    Query q={0}; q.limit=-1; q.offset=0; q.mindepth=0; q.maxdepth=2147483647; q.format=xstrdup("tabs");
    q.toks=tokenize(qstr);
    int n=q.toks.n, start=0;
    if(n>0 && is_kw(q.toks.v[0],"select")) start=1;
    int from=n, where=n, group=n, order=n, limit=n, offset=n, into=n, depth=0;
    for(int i=start;i<n;i++){
        char *tok=q.toks.v[i];
        if(!strcmp(tok,"(")) depth++; else if(!strcmp(tok,")")) depth--;
        if(depth) continue;
        if(is_kw(tok,"from") && from==n) from=i;
        else if(is_kw(tok,"where") && where==n) where=i;
        else if(is_kw(tok,"group") && group==n) group=i;
        else if(is_kw(tok,"order") && order==n) order=i;
        else if(is_kw(tok,"limit") && limit==n) limit=i;
        else if(is_kw(tok,"offset") && offset==n) offset=i;
        else if(is_kw(tok,"into") && into==n) into=i;
    }
    int first_clause=n; int clauses[]={from,where,group,order,limit,offset,into};
    for(size_t i=0;i<sizeof(clauses)/sizeof(clauses[0]);i++) if(clauses[i]<first_clause) first_clause=clauses[i];
    split_expr_list(&q.cols,&q.toks,start,first_clause);
    if(q.cols.n==0) sv_push(&q.cols,xstrdup("path"));
    if(from<n){
        int end=n; int cs[]={where,group,order,limit,offset,into};
        for(size_t i=0;i<sizeof(cs)/sizeof(cs[0]);i++) if(cs[i]>from && cs[i]<end) end=cs[i];
        int rstart=from+1;
        for(int i=from+1;i<=end;i++){
            if(i==end || !strcmp(q.toks.v[i],",")){
                if(rstart<i) {
                    char *root=xstrdup(q.toks.v[rstart]);
                    sv_push(&q.roots,root);
                }
                rstart=i+1;
            } else if(is_kw(q.toks.v[i],"depth")||is_kw(q.toks.v[i],"maxdepth")) {
                if(i+1<end) q.maxdepth=atoi(q.toks.v[i+1]); i++;
            } else if(is_kw(q.toks.v[i],"mindepth")) {
                if(i+1<end) q.mindepth=atoi(q.toks.v[i+1]); i++;
            } else if(is_kw(q.toks.v[i],"as")) {
                i++;
            } else if(is_kw(q.toks.v[i],"symlinks")||is_kw(q.toks.v[i],"archives")||is_kw(q.toks.v[i],"bfs")||is_kw(q.toks.v[i],"dfs")||is_kw(q.toks.v[i],"gitignore")||is_kw(q.toks.v[i],"git")) {
            }
        }
    }
    if(q.roots.n==0) sv_push(&q.roots,xstrdup("."));
    q.where_start = where<n ? where+1 : -1;
    q.where_end = n;
    int ends[]={group,order,limit,offset,into};
    if(where<n) for(size_t i=0;i<sizeof(ends)/sizeof(ends[0]);i++) if(ends[i]>where && ends[i]<q.where_end) q.where_end=ends[i];
    if(order<n){
        int s=order+1; if(s<n && is_kw(q.toks.v[s],"by")) s++;
        int e=n; int oe[]={limit,offset,into}; for(size_t i=0;i<3;i++) if(oe[i]>order&&oe[i]<e) e=oe[i];
        if(e>s){ split_expr_list(&q.order_cols,&q.toks,s,e); char *last=q.order_cols.v[q.order_cols.n-1]; char *p=strrchr(last,' '); if(p && streqi(p+1,"desc")){ *p=0; q.order_desc=1; } else if(p && streqi(p+1,"asc")) *p=0; }
    }
    if(limit<n && limit+1<n) q.limit=atoi(q.toks.v[limit+1]);
    if(offset<n && offset+1<n) q.offset=atoi(q.toks.v[offset+1]);
    if(into<n && into+1<n){ free(q.format); q.format=lower_dup(q.toks.v[into+1]); }
    return q;
}

static char *path_join(const char *a,const char *b){ char *r; if(asprintf(&r,"%s%s%s",a, (a[0]&&a[strlen(a)-1]=='/')?"":"/", b)<0) dieoom(); return r; }
static char *dirname_dup(const char *p){ char *s=xstrdup(p); char *slash=strrchr(s,'/'); if(!slash){ s[0]=0; return s; } if(slash==s) slash[1]=0; else *slash=0; return s; }
static const char *base_name(const char *p){ const char *s=strrchr(p,'/'); return s?s+1:p; }
static char *abs_path(const char *p){ char *r=realpath(p,NULL); if(r) return r; if(p[0]=='/') return xstrdup(p); char cwd[4096]; getcwd(cwd,sizeof(cwd)); return path_join(cwd,p); }

static void traverse_root(Rows *rows, const char *root_in){
    char *root_abs=abs_path(root_in);
    struct stat rst; if(lstat(root_abs,&rst)!=0){ fprintf(stderr,"%s: could not canonicalize path: %s (os error %d)\n",root_in,strerror(errno),errno); free(root_abs); exit(1); }
    StrVec q={0}; sv_push(&q,xstrdup(root_abs));
    int head=0;
    while(head<q.n){
        char *dir=q.v[head++];
        DIR *d=opendir(dir); if(!d) continue;
        struct dirent *de;
        while((de=readdir(d))){
            if(!strcmp(de->d_name,".")||!strcmp(de->d_name,"..")) continue;
            char *ap=path_join(dir,de->d_name);
            struct stat st; if(lstat(ap,&st)!=0){ free(ap); continue; }
            const char *rel=ap+strlen(root_abs); if(*rel=='/') rel++;
            int dep=1; for(const char *p=rel; *p; p++) if(*p=='/') dep++;
            Row row={ap,xstrdup(rel),xstrdup(root_abs),dep,st}; rows_push(rows,row);
            if(S_ISDIR(st.st_mode)) sv_push(&q,xstrdup(ap));
        }
        closedir(d);
    }
}

static char file_type(mode_t m){ if(S_ISDIR(m))return 'd'; if(S_ISLNK(m))return 'l'; if(S_ISFIFO(m))return 'p'; if(S_ISSOCK(m))return 's'; if(S_ISCHR(m))return 'c'; if(S_ISBLK(m))return 'b'; return '-'; }
static char *mode_string(mode_t m){
    char *s=calloc(11,1); s[0]=file_type(m);
    const char *rwx="rwx"; for(int i=0;i<9;i++) s[i+1]=(m&(1<<(8-i)))?rwx[i%3]:'-';
    if(m&S_ISUID) s[3]=(s[3]=='x')?'s':'S'; if(m&S_ISGID) s[6]=(s[6]=='x')?'s':'S'; if(m&S_ISVTX) s[9]=(s[9]=='x')?'t':'T';
    return s;
}
static char *fmt_time(time_t tt){ char buf[64]; struct tm tm; localtime_r(&tt,&tm); strftime(buf,sizeof(buf),"%Y-%m-%d %H:%M:%S",&tm); return xstrdup(buf); }
static char *human_size(long long n){ char buf[64]; if(n<1024) snprintf(buf,sizeof(buf),"%lld",n); else if(n<1024LL*1024) snprintf(buf,sizeof(buf),"%.1fK",(double)n/1024); else if(n<1024LL*1024*1024) snprintf(buf,sizeof(buf),"%.1fM",(double)n/(1024*1024)); else snprintf(buf,sizeof(buf),"%.1fG",(double)n/(1024*1024*1024)); return xstrdup(buf); }
static char *noext(const char *name){ char *s=xstrdup(name); char *dot=strrchr(s,'.'); if(dot && dot!=s) *dot=0; return s; }
static char *ext_dup(const char *name){ const char *dot=strrchr(name,'.'); return (dot&&dot!=name)?xstrdup(dot+1):xstrdup(""); }
static int ext_in(const char *e,const char *list){ char *el=lower_dup(e); char pat[64]; snprintf(pat,sizeof(pat),".%s,",el); free(el); return strstr(list,pat)!=NULL; }

static char *col_value(Row *r, const char *col){
    while(isspace((unsigned char)*col)) col++;
    char *lc=lower_dup(col);
    char *sp=strchr(lc,' '); if(sp) *sp=0;
    const char *bn=base_name(r->rel); char buf[128];
    if(streqi(lc,"name")) { free(lc); return xstrdup(bn); }
    if(streqi(lc,"path")) { free(lc); return xstrdup(r->rel); }
    if(streqi(lc,"abspath")) { free(lc); return xstrdup(r->abs); }
    if(streqi(lc,"dir")||streqi(lc,"directory")||streqi(lc,"dirname")) { free(lc); return dirname_dup(r->rel); }
    if(streqi(lc,"absdir")) { free(lc); return dirname_dup(r->abs); }
    if(streqi(lc,"filename")||streqi(lc,"fname")) { free(lc); return noext(bn); }
    if(streqi(lc,"ext")||streqi(lc,"extension")) { free(lc); return ext_dup(bn); }
    if(streqi(lc,"size")) { snprintf(buf,sizeof(buf),"%lld",(long long)r->st.st_size); free(lc); return xstrdup(buf); }
    if(streqi(lc,"fsize")||streqi(lc,"hsize")) { free(lc); return human_size(r->st.st_size); }
    if(streqi(lc,"uid")) { snprintf(buf,sizeof(buf),"%u",(unsigned)r->st.st_uid); free(lc); return xstrdup(buf); }
    if(streqi(lc,"gid")) { snprintf(buf,sizeof(buf),"%u",(unsigned)r->st.st_gid); free(lc); return xstrdup(buf); }
    if(streqi(lc,"user")) { struct passwd *pw=getpwuid(r->st.st_uid); free(lc); return xstrdup(pw?pw->pw_name:""); }
    if(streqi(lc,"group")) { struct group *gr=getgrgid(r->st.st_gid); free(lc); return xstrdup(gr?gr->gr_name:""); }
    if(streqi(lc,"modified")) { free(lc); return fmt_time(r->st.st_mtime); }
    if(streqi(lc,"accessed")) { free(lc); return fmt_time(r->st.st_atime); }
    if(streqi(lc,"created")) { free(lc); return fmt_time(r->st.st_ctime); }
    if(streqi(lc,"mtime")) { snprintf(buf,sizeof(buf),"%lld",(long long)r->st.st_mtime); free(lc); return xstrdup(buf); }
    if(streqi(lc,"atime")) { snprintf(buf,sizeof(buf),"%lld",(long long)r->st.st_atime); free(lc); return xstrdup(buf); }
    if(streqi(lc,"ctime")) { snprintf(buf,sizeof(buf),"%lld",(long long)r->st.st_ctime); free(lc); return xstrdup(buf); }
    if(streqi(lc,"mode")) { free(lc); return mode_string(r->st.st_mode); }
    if(streqi(lc,"inode")) { snprintf(buf,sizeof(buf),"%llu",(unsigned long long)r->st.st_ino); free(lc); return xstrdup(buf); }
    if(streqi(lc,"blocks")) { snprintf(buf,sizeof(buf),"%lld",(long long)r->st.st_blocks*2); free(lc); return xstrdup(buf); }
    if(streqi(lc,"hardlinks")) { snprintf(buf,sizeof(buf),"%llu",(unsigned long long)r->st.st_nlink); free(lc); return xstrdup(buf); }
    if(streqi(lc,"is_dir")) snprintf(buf,sizeof(buf),"%s",S_ISDIR(r->st.st_mode)?"true":"false");
    else if(streqi(lc,"is_file")) snprintf(buf,sizeof(buf),"%s",S_ISREG(r->st.st_mode)?"true":"false");
    else if(streqi(lc,"is_symlink")) snprintf(buf,sizeof(buf),"%s",S_ISLNK(r->st.st_mode)?"true":"false");
    else if(streqi(lc,"is_pipe")||streqi(lc,"is_fifo")) snprintf(buf,sizeof(buf),"%s",S_ISFIFO(r->st.st_mode)?"true":"false");
    else if(streqi(lc,"is_socket")) snprintf(buf,sizeof(buf),"%s",S_ISSOCK(r->st.st_mode)?"true":"false");
    else if(streqi(lc,"is_char")||streqi(lc,"is_character")) snprintf(buf,sizeof(buf),"%s",S_ISCHR(r->st.st_mode)?"true":"false");
    else if(streqi(lc,"is_block")) snprintf(buf,sizeof(buf),"%s",S_ISBLK(r->st.st_mode)?"true":"false");
    else if(streqi(lc,"is_hidden")) snprintf(buf,sizeof(buf),"%s",bn[0]=='.'?"true":"false");
    else if(streqi(lc,"user_read")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IRUSR)?"true":"false");
    else if(streqi(lc,"user_write")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IWUSR)?"true":"false");
    else if(streqi(lc,"user_exec")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IXUSR)?"true":"false");
    else if(streqi(lc,"group_read")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IRGRP)?"true":"false");
    else if(streqi(lc,"group_write")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IWGRP)?"true":"false");
    else if(streqi(lc,"group_exec")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IXGRP)?"true":"false");
    else if(streqi(lc,"other_read")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IROTH)?"true":"false");
    else if(streqi(lc,"other_write")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IWOTH)?"true":"false");
    else if(streqi(lc,"other_exec")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_IXOTH)?"true":"false");
    else if(streqi(lc,"suid")||streqi(lc,"is_suid")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_ISUID)?"true":"false");
    else if(streqi(lc,"sgid")||streqi(lc,"is_sgid")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_ISGID)?"true":"false");
    else if(streqi(lc,"sticky")||streqi(lc,"is_sticky")) snprintf(buf,sizeof(buf),"%s",(r->st.st_mode&S_ISVTX)?"true":"false");
    else if(streqi(lc,"is_empty")) snprintf(buf,sizeof(buf),"%s",(S_ISREG(r->st.st_mode)&&r->st.st_size==0)?"true":"false");
    else if(streqi(lc,"is_archive")) { char *e=ext_dup(bn); snprintf(buf,sizeof(buf),"%s",ext_in(e,".7z,.bz2,.bzip2,.gz,.gzip,.lz,.rar,.tar,.xz,.zip,")?"true":"false"); free(e); }
    else if(streqi(lc,"is_audio")) { char *e=ext_dup(bn); snprintf(buf,sizeof(buf),"%s",ext_in(e,".aac,.aiff,.amr,.flac,.gsm,.m4a,.m4b,.m4p,.mp3,.ogg,.wav,.wma,")?"true":"false"); free(e); }
    else if(streqi(lc,"is_book")) { char *e=ext_dup(bn); snprintf(buf,sizeof(buf),"%s",ext_in(e,".azw3,.chm,.djv,.djvu,.epub,.fb2,.mobi,.pdf,")?"true":"false"); free(e); }
    else if(streqi(lc,"is_doc")) { char *e=ext_dup(bn); snprintf(buf,sizeof(buf),"%s",ext_in(e,".doc,.docx,.odt,.pdf,.ppt,.pptx,.rtf,.xls,.xlsx,.xps,")?"true":"false"); free(e); }
    else if(streqi(lc,"is_image")) { char *e=ext_dup(bn); snprintf(buf,sizeof(buf),"%s",ext_in(e,".bmp,.gif,.jpeg,.jpg,.png,.svg,.tiff,.webp,")?"true":"false"); free(e); }
    else if(streqi(lc,"is_source")) { char *e=ext_dup(bn); snprintf(buf,sizeof(buf),"%s",ext_in(e,".c,.cc,.cpp,.h,.hpp,.java,.js,.py,.rb,.rs,.go,.ts,.tsx,.php,.pl,.sh,.lua,.swift,.zig,")?"true":"false"); free(e); }
    else { free(lc); return xstrdup(col); }
    free(lc); return xstrdup(buf);
}

static char *eval_expr(Row *r, const char *expr){
    char *s=xstrdup(expr); while(isspace((unsigned char)*s)) memmove(s,s+1,strlen(s));
    size_t L=strlen(s); while(L&&isspace((unsigned char)s[L-1])) s[--L]=0;
    if((s[0]=='\''&&s[L-1]=='\'')||(s[0]=='"'&&s[L-1]=='"')){ s[L-1]=0; char *ret=xstrdup(s+1); free(s); return ret; }
    char *lp=strchr(s,'('); char *rp=strrchr(s,')');
    if(lp && rp && rp>lp){
        *lp=0; *rp=0; trim_inplace(s); char *fn=lower_dup(s); char *arg=lp+1; trim_inplace(arg); char *v=eval_expr(r,arg);
        if(streqi(fn,"upper")||streqi(fn,"uppercase")||streqi(fn,"ucase")) for(char*p=v;*p;p++) *p=toupper((unsigned char)*p);
        else if(streqi(fn,"lower")||streqi(fn,"lowercase")||streqi(fn,"lcase")) for(char*p=v;*p;p++) *p=tolower((unsigned char)*p);
        else if(streqi(fn,"length")||streqi(fn,"len")){ char b[64]; snprintf(b,sizeof(b),"%zu",strlen(v)); free(v); v=xstrdup(b); }
        else if(streqi(fn,"year")){ char b[8]={0}; strncpy(b,v,4); free(v); v=xstrdup(b); }
        else if(streqi(fn,"format_size")||streqi(fn,"format_filesize")){ long long n=atoll(v); free(v); v=human_size(n); }
        free(fn); free(s); return v;
    }
    char *ret=col_value(r,s); free(s); return ret;
}

typedef struct { Query *q; Row *r; int pos; } Ectx;
static int parse_or(Ectx *e);
static int truthy(const char *v){ return v && *v && !streqi(v,"false") && strcmp(v,"0"); }
static long long parse_size(const char *s){ char *end; double v=strtod(s,&end); while(isspace((unsigned char)*end)) end++; char *u=lower_dup(end); long long mult=1; if(!strcmp(u,"k")||!strcmp(u,"kib")) mult=1024; else if(!strcmp(u,"kb")) mult=1000; else if(!strcmp(u,"m")||!strcmp(u,"mib")) mult=1024LL*1024; else if(!strcmp(u,"mb")) mult=1000LL*1000; else if(!strcmp(u,"g")||!strcmp(u,"gib")) mult=1024LL*1024*1024; else if(!strcmp(u,"gb")) mult=1000LL*1000*1000; free(u); return (long long)(v*mult); }
static int cmp_values(const char *a,const char *op,const char *b){
    if(streqi(op,"=")||streqi(op,"==")||streqi(op,"eq")) return (strpbrk(b,"*?[")?fnmatch(b,a,0)==0:strcmp(a,b)==0);
    if(streqi(op,"===")||streqi(op,"eeq")) return strcmp(a,b)==0;
    if(streqi(op,"!=")||streqi(op,"<>")||streqi(op,"ne")) return !(strpbrk(b,"*?[")?fnmatch(b,a,0)==0:strcmp(a,b)==0);
    if(streqi(op,"!==")||streqi(op,"ene")) return strcmp(a,b)!=0;
    if(streqi(op,"like")||streqi(op,"notlike")){ char *pat=xstrdup(b); for(char*p=pat;*p;p++){ if(*p=='%')*p='*'; else if(*p=='_')*p='?'; } int ok=fnmatch(pat,a,0)==0; free(pat); return streqi(op,"notlike")?!ok:ok; }
    if(streqi(op,"=~")||streqi(op,"~=")||streqi(op,"regexp")||streqi(op,"rx")||streqi(op,"!=~")||streqi(op,"!~=")||streqi(op,"notrx")){ regex_t re; int ok=0; if(regcomp(&re,b,REG_EXTENDED|REG_NOSUB)==0){ ok=regexec(&re,a,0,NULL,0)==0; regfree(&re);} return (op[0]=='!'||streqi(op,"notrx"))?!ok:ok; }
    long long na=parse_size(a), nb=parse_size(b);
    if(streqi(op,">")||streqi(op,"gt")) return na>nb; if(streqi(op,">=")||streqi(op,"gte")||streqi(op,"ge")) return na>=nb;
    if(streqi(op,"<")||streqi(op,"lt")) return na<nb; if(streqi(op,"<=")||streqi(op,"lte")||streqi(op,"le")) return na<=nb;
    return 0;
}
static int parse_primary(Ectx *e){
    if(e->pos>=e->q->where_end) return 1;
    if(!strcmp(e->q->toks.v[e->pos],"(")){ e->pos++; int v=parse_or(e); if(e->pos<e->q->where_end && !strcmp(e->q->toks.v[e->pos],")")) e->pos++; return v; }
    char *left=e->q->toks.v[e->pos++];
    if(e->pos>=e->q->where_end){ char *v=eval_expr(e->r,left); int ok=truthy(v); free(v); return ok; }
    char *op=e->q->toks.v[e->pos];
    if(is_kw(op,"and")||is_kw(op,"or")||!strcmp(op,")")){ char *v=eval_expr(e->r,left); int ok=truthy(v); free(v); return ok; }
    e->pos++;
    if(is_kw(op,"between") && e->pos+2<e->q->where_end){ char *a=e->q->toks.v[e->pos++]; if(is_kw(e->q->toks.v[e->pos],"and")) e->pos++; char *b=e->q->toks.v[e->pos++]; char *v=eval_expr(e->r,left); long long n=parse_size(v); int ok=n>=parse_size(a)&&n<=parse_size(b); free(v); return ok; }
    if(e->pos>=e->q->where_end) return 0;
    char *right=e->q->toks.v[e->pos++];
    char *lv=eval_expr(e->r,left); int ok=cmp_values(lv,op,right); free(lv); return ok;
}
static int parse_and(Ectx *e){ int v=parse_primary(e); while(e->pos<e->q->where_end && is_kw(e->q->toks.v[e->pos],"and")){ e->pos++; v = parse_primary(e) && v; } return v; }
static int parse_or(Ectx *e){ int v=parse_and(e); while(e->pos<e->q->where_end && is_kw(e->q->toks.v[e->pos],"or")){ e->pos++; v = parse_and(e) || v; } return v; }
static int row_match(Query *q, Row *r){
    if(r->depth < q->mindepth || r->depth > q->maxdepth) return 0;
    if(q->where_start<0) return 1;
    Ectx e={q,r,q->where_start}; return parse_or(&e);
}

static Query *sort_q;
static int row_cmp(const void *A,const void *B){
    Row *a=(Row*)A,*b=(Row*)B; if(sort_q->order_cols.n==0) return 0;
    char *va=eval_expr(a,sort_q->order_cols.v[0]); char *vb=eval_expr(b,sort_q->order_cols.v[0]);
    long long na=parse_size(va), nb=parse_size(vb); int c;
    if((isdigit((unsigned char)va[0])||va[0]=='-') && (isdigit((unsigned char)vb[0])||vb[0]=='-')) c=(na>nb)-(na<nb); else c=strcmp(va,vb);
    free(va); free(vb); return sort_q->order_desc?-c:c;
}

static int is_agg(const char *c){
    char *l=lower_dup(c); trim_inplace(l);
    int r=!strncmp(l,"count",5)||!strncmp(l,"sum",3)||!strncmp(l,"min",3)||!strncmp(l,"max",3)||!strncmp(l,"avg",3);
    free(l); return r;
}
static char *agg_value(const char *c, Rows *rows, int *idxs, int n){
    char *l=lower_dup(c); trim_inplace(l); char *lp=strchr(l,'('), *rp=strrchr(l,')'); char arg[128]="size"; if(lp&&rp&&rp>lp+1){ *rp=0; char *a=lp+1; trim_inplace(a); strncpy(arg,a,sizeof(arg)-1); }
    if(!strncmp(l,"count",5)){ char b[64]; snprintf(b,sizeof(b),"%d",n); free(l); return xstrdup(b); }
    long long sum=0,min=0,max=0; for(int i=0;i<n;i++){ char *v=eval_expr(&rows->v[idxs[i]],arg); long long x=parse_size(v); free(v); if(i==0||x<min)min=x; if(i==0||x>max)max=x; sum+=x; }
    char b[128];
    if(!strncmp(l,"sum",3)) snprintf(b,sizeof(b),"%lld",sum);
    else if(!strncmp(l,"min",3)) snprintf(b,sizeof(b),"%lld",n?min:0);
    else if(!strncmp(l,"max",3)) snprintf(b,sizeof(b),"%lld",n?max:0);
    else snprintf(b,sizeof(b),"%lld",n?sum/n:0);
    free(l); return xstrdup(b);
}

static char *json_key(const char *c){ char *s=xstrdup(c); char *lp=strchr(s,'('); if(lp) *lp=0; for(char*p=s;*p;p++) *p=tolower((unsigned char)*p); s[0]=toupper((unsigned char)s[0]); return s; }
static void print_escaped(const char *s, int json){ for(;*s;s++){ if(json && (*s=='"'||*s=='\\')) putchar('\\'); if(json && *s=='\n') printf("\\n"); else putchar(*s); } }
static void output(Query *q, Rows *rows, int *idxs, int n, const char *title){
    int agg=0; for(int c=0;c<q->cols.n;c++) if(is_agg(q->cols.v[c])) agg=1;
    int matched_n=n;
    int rows_to_print=agg ? 1 : n;
    if(streqi(q->format,"json")) putchar('[');
    if(streqi(q->format,"html")){ printf("<html><head><title>"); print_escaped(title,0); printf("</title></head><body><table><tr><th colspan=\"%d\">",q->cols.n); print_escaped(title,0); printf("</th></tr>"); }
    for(int i=0;i<rows_to_print;i++){
        if(streqi(q->format,"json")){ if(i) putchar(','); putchar('{'); }
        if(streqi(q->format,"html")) printf("<tr>");
        for(int c=0;c<q->cols.n;c++){
            char *v=agg?agg_value(q->cols.v[c],rows,idxs,matched_n):eval_expr(&rows->v[idxs[i]],q->cols.v[c]);
            if(streqi(q->format,"json")){ if(c) putchar(','); char *k=json_key(q->cols.v[c]); printf("\"%s\":\"",k); print_escaped(v,1); printf("\""); free(k); }
            else if(streqi(q->format,"html")){ printf("<td>"); print_escaped(v,0); printf("</td>"); }
            else if(streqi(q->format,"lines")) { print_escaped(v,0); putchar('\n'); }
            else { if(c){ if(streqi(q->format,"csv")) putchar(','); else if(streqi(q->format,"list")) putchar('\0'); else putchar('\t'); } print_escaped(v,0); }
            free(v);
        }
        if(streqi(q->format,"json")) putchar('}');
        else if(streqi(q->format,"html")) printf("</tr>");
        else if(streqi(q->format,"list")) putchar('\0');
        else if(!streqi(q->format,"lines")) putchar('\n');
    }
    if(streqi(q->format,"json")) putchar(']');
    if(streqi(q->format,"html")) printf("</table></body></html>");
}

static void help(int color){
    (void)color;
    printf("fselect 0.10.0\nFind files with SQL-like queries.\nhttps://github.com/jhspetersson/fselect\n\n");
    printf("Usage: fselect [ARGS] COLUMN[, COLUMN...] [from PATH[, PATH...]] [where EXPR] [group by COLUMN, ...] [order by COLUMN (asc|desc), ...] [limit N] [offset N] [into FORMAT]\n");
}

int main(int argc,char **argv){
    int start=1,color=getenv("NO_COLOR")==NULL;
    for(;start<argc;start++){
        if(!strcmp(argv[start],"--help")||!strcmp(argv[start],"-h")||!strcmp(argv[start],"/?")){ help(color); return 0; }
        if(!strcmp(argv[start],"--version")||!strcmp(argv[start],"-V")){ help(color); return 0; }
        if(!strcmp(argv[start],"--nocolor")||!strcmp(argv[start],"--no-color")||!strcmp(argv[start],"--no-errors")) continue;
        if((!strcmp(argv[start],"--config")||!strcmp(argv[start],"-c")) && start+1<argc){ start++; continue; }
        break;
    }
    if(start>=argc){ help(color); return 0; }
    if(!strcmp(argv[start],"-i")||!strcmp(argv[start],"--interactive")){
        char line[4096]; while(fgets(line,sizeof(line),stdin)){ if(!strncmp(line,"exit",4)||!strncmp(line,"quit",4)) break; char *av[3]={argv[0],line,NULL}; main(2,av); } return 0;
    }
    char *query=join_args(argc,argv,start);
    Query q=parse_query(query);
    Rows rows={0}; for(int i=0;i<q.roots.n;i++) traverse_root(&rows,q.roots.v[i]);
    if(q.order_cols.n){ sort_q=&q; qsort(rows.v,rows.n,sizeof(Row),row_cmp); }
    int *idxs=malloc(sizeof(int)*rows.n); if(!idxs) dieoom(); int n=0;
    for(int i=0;i<rows.n;i++) if(row_match(&q,&rows.v[i])) idxs[n++]=i;
    int off=q.offset; if(off<0) off=0; if(off>n) off=n; int outn=n-off; if(q.limit>=0 && q.limit<outn) outn=q.limit;
    output(&q,&rows,idxs+off,outn,query);
    free(query); free(idxs); return 0;
}
