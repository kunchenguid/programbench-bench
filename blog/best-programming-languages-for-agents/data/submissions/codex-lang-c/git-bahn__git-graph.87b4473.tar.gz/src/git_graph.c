#define _POSIX_C_SOURCE 200809L

#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>

typedef struct {
    char *path;
    char *model;
    char *max_count;
    char *color;
    char *format;
    char *style;
    bool no_color;
    bool reverse;
    bool local;
    bool svg;
    bool debug;
    bool sparse;
    bool skip_owner;
    int wrap_args;
    char **wrap_vals;
} Options;

static void print_help(void) {
    puts("Structured Git graphs for your branching model.");
    puts("    https://github.com/mlange-42/git-graph");
    puts("");
    puts("EXAMPES:");
    puts("    git-graph                   -> Show graph");
    puts("    git-graph --style round     -> Show graph in a different style");
    puts("    git-graph --model <model>   -> Show graph using a certain <model>");
    puts("    git-graph model --list      -> List available branching models");
    puts("    git-graph model             -> Show repo's current branching models");
    puts("    git-graph model <model>     -> Permanently set model <model> for this repo");
    puts("");
    puts("Usage: executable [OPTIONS] [COMMAND]");
    puts("");
    puts("Commands:");
    puts("  model  Prints or permanently sets the branching model for a repository.");
    puts("  help   Print this message or the help of the given subcommand(s)");
    puts("");
    puts("Options:");
    puts("  -p, --path <path>");
    puts("          Open repository from this path or above. Default '.'");
    puts("");
    puts("      --skip-repo-owner-validation");
    puts("          Skip owner validation for the repository.");
    puts("          This will turn off libgit2's owner validation, which may increase security risks.");
    puts("          Please do not disable this validation for repositories you do not trust.");
    puts("");
    puts("  -m, --model <model>");
    puts("          Branching model. Available presets are [simple|git-flow|none].");
    puts("          Default: git-flow. ");
    puts("          Permanently set the model for a repository with");
    puts("          > git-graph model <model>");
    puts("");
    puts("  -n, --max-count <n>");
    puts("          Maximum number of commits");
    puts("");
    puts("      --color <color>");
    puts("          Specify when colors should be used. One of [auto|always|never].");
    puts("          Default: auto.");
    puts("");
    puts("      --no-color");
    puts("          Print without colors. Missing color support should be detected");
    puts("          automatically (e.g. when piping to a file).");
    puts("          Overrides option '--color'");
    puts("");
    puts("  -w, --wrap [<wrap>...]");
    puts("          Line wrapping for formatted commit text. Default: 'auto 0 8'");
    puts("          Argument format: [<width>|auto|none[ <indent1>[ <indent2>]]]");
    puts("");
    puts("  -f, --format <format>");
    puts("          Commit format. One of [oneline|short|medium|full|\"<string>\"].");
    puts("");
    puts("  -r, --reverse");
    puts("          Reverse the order of commits.");
    puts("");
    puts("  -l, --local");
    puts("          Show only local branches, no remotes.");
    puts("");
    puts("      --svg");
    puts("          Render graph as SVG instead of text-based.");
    puts("");
    puts("  -d, --debug");
    puts("          Additional debug output and graphics.");
    puts("");
    puts("  -S, --sparse");
    puts("          Print a less compact graph: merge lines point to target lines");
    puts("          rather than merge commits.");
    puts("");
    puts("  -s, --style <style>");
    puts("          Output style. One of [normal/thin|round|bold|double|ascii].");
    puts("            (First character can be used as abbreviation, e.g. '-s r')");
    puts("");
    puts("  -h, --help");
    puts("          Print help (see a summary with '-h')");
    puts("");
    puts("  -V, --version");
    puts("          Print version");
}

static void print_model_help(void) {
    puts("Prints or permanently sets the branching model for a repository.");
    puts("");
    puts("Usage: executable model [OPTIONS] [model]");
    puts("");
    puts("Arguments:");
    puts("  [model]  The branching model to be used. Available presets are [simple|git-flow|none].");
    puts("           When not given, prints the currently set model.");
    puts("");
    puts("Options:");
    puts("  -l, --list  List all available branching models.");
    puts("  -h, --help  Print help");
}

static bool is_model(const char *s) {
    return s && (!strcmp(s, "none") || !strcmp(s, "simple") || !strcmp(s, "git-flow"));
}

static bool is_style(const char *s) {
    return s && (!strcmp(s, "normal") || !strcmp(s, "thin") || !strcmp(s, "round") ||
                 !strcmp(s, "bold") || !strcmp(s, "double") || !strcmp(s, "ascii") ||
                 !strcmp(s, "n") || !strcmp(s, "t") || !strcmp(s, "r") ||
                 !strcmp(s, "b") || !strcmp(s, "d") || !strcmp(s, "a"));
}

static bool is_color(const char *s) {
    return s && (!strcmp(s, "auto") || !strcmp(s, "always") || !strcmp(s, "never"));
}

static char *shell_quote(const char *s) {
    size_t n = 3;
    for (const char *p = s; *p; p++) n += (*p == '\'') ? 4 : 1;
    char *out = malloc(n);
    if (!out) exit(125);
    char *q = out;
    *q++ = '\'';
    for (const char *p = s; *p; p++) {
        if (*p == '\'') {
            memcpy(q, "'\\''", 4);
            q += 4;
        } else {
            *q++ = *p;
        }
    }
    *q++ = '\'';
    *q = 0;
    return out;
}

static char *fmt(const char *format, ...) {
    va_list ap;
    va_start(ap, format);
    va_list aq;
    va_copy(aq, ap);
    int len = vsnprintf(NULL, 0, format, aq);
    va_end(aq);
    if (len < 0) exit(125);
    char *buf = malloc((size_t)len + 1);
    if (!buf) exit(125);
    vsnprintf(buf, (size_t)len + 1, format, ap);
    va_end(ap);
    return buf;
}

static int run_command(const char *cmd) {
    int rc = system(cmd);
    if (rc == -1) return 127;
    if (WIFEXITED(rc)) return WEXITSTATUS(rc);
    return 1;
}

static char *read_command(const char *cmd, int *status) {
    FILE *fp = popen(cmd, "r");
    if (!fp) {
        if (status) *status = 127;
        return strdup("");
    }
    size_t cap = 256, len = 0;
    char *buf = malloc(cap);
    if (!buf) exit(125);
    int c;
    while ((c = fgetc(fp)) != EOF) {
        if (len + 1 >= cap) {
            cap *= 2;
            buf = realloc(buf, cap);
            if (!buf) exit(125);
        }
        buf[len++] = (char)c;
    }
    buf[len] = 0;
    int rc = pclose(fp);
    if (status) *status = (rc != -1 && WIFEXITED(rc)) ? WEXITSTATUS(rc) : 1;
    while (len && (buf[len - 1] == '\n' || buf[len - 1] == '\r')) buf[--len] = 0;
    return buf;
}

static char *repo_root(const char *path, bool quiet) {
    char *qp = shell_quote(path ? path : ".");
    char *cmd = fmt("git -C %s rev-parse --show-toplevel 2>/dev/null", qp);
    int st = 0;
    char *out = read_command(cmd, &st);
    free(qp);
    free(cmd);
    if (st != 0 || !*out) {
        if (!quiet) {
            fprintf(stderr, "ERROR: could not find repository at '%s'\n", path ? path : ".");
            fprintf(stderr, "       Navigate into a repository before running git-graph, or use option --path\n");
        }
        free(out);
        return NULL;
    }
    return out;
}

static const char *next_arg(int *i, int argc, char **argv, const char *opt) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "error: a value is required for '%s' but none was supplied\n", opt);
        exit(2);
    }
    return argv[++(*i)];
}

static void parse_global(int argc, char **argv, Options *o, int start) {
    o->path = ".";
    o->color = "auto";
    o->format = "oneline";
    for (int i = start; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            print_help();
            exit(0);
        } else if (!strcmp(a, "-V") || !strcmp(a, "--version")) {
            puts("git-graph 0.7.0");
            exit(0);
        } else if (!strcmp(a, "-p") || !strcmp(a, "--path")) {
            o->path = (char *)next_arg(&i, argc, argv, a);
        } else if (!strcmp(a, "-m") || !strcmp(a, "--model")) {
            o->model = (char *)next_arg(&i, argc, argv, a);
        } else if (!strcmp(a, "-n") || !strcmp(a, "--max-count")) {
            o->max_count = (char *)next_arg(&i, argc, argv, a);
        } else if (!strcmp(a, "--color")) {
            o->color = (char *)next_arg(&i, argc, argv, a);
        } else if (!strcmp(a, "--no-color")) {
            o->no_color = true;
        } else if (!strcmp(a, "-f") || !strcmp(a, "--format")) {
            o->format = (char *)next_arg(&i, argc, argv, a);
        } else if (!strcmp(a, "-r") || !strcmp(a, "--reverse")) {
            o->reverse = true;
        } else if (!strcmp(a, "-l") || !strcmp(a, "--local")) {
            o->local = true;
        } else if (!strcmp(a, "--svg")) {
            o->svg = true;
        } else if (!strcmp(a, "-d") || !strcmp(a, "--debug")) {
            o->debug = true;
        } else if (!strcmp(a, "-S") || !strcmp(a, "--sparse")) {
            o->sparse = true;
        } else if (!strcmp(a, "-s") || !strcmp(a, "--style")) {
            o->style = (char *)next_arg(&i, argc, argv, a);
        } else if (!strcmp(a, "--skip-repo-owner-validation")) {
            o->skip_owner = true;
        } else if (!strcmp(a, "-w") || !strcmp(a, "--wrap")) {
            o->wrap_vals = &argv[i + 1];
            while (i + 1 < argc && argv[i + 1][0] != '-') {
                i++;
                o->wrap_args++;
                if (o->wrap_args == 3) break;
            }
        } else if (!strcmp(a, "help")) {
            if (i + 1 < argc && !strcmp(argv[i + 1], "model")) print_model_help();
            else print_help();
            exit(0);
        } else if (!strcmp(a, "model")) {
            fprintf(stderr, "error: unexpected argument 'model' found\n");
            exit(2);
        } else {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n", a);
            fprintf(stderr, "Usage: executable [OPTIONS] [COMMAND]\n\n");
            fprintf(stderr, "For more information, try '--help'.\n");
            exit(2);
        }
    }
}

static int handle_model(int argc, char **argv) {
    char *path = ".";
    bool list = false;
    char *set = NULL;
    for (int i = 2; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            print_model_help();
            return 0;
        } else if (!strcmp(a, "-l") || !strcmp(a, "--list")) {
            list = true;
        } else if (!strcmp(a, "-p") || !strcmp(a, "--path")) {
            path = (char *)next_arg(&i, argc, argv, a);
        } else if (a[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n", a);
            return 2;
        } else if (!set) {
            set = a;
        } else {
            fprintf(stderr, "error: unexpected argument '%s' found\n", a);
            return 2;
        }
    }
    if (list) {
        puts("none");
        puts("simple");
        puts("git-flow");
        return 0;
    }
    if (set && !is_model(set)) {
        fprintf(stderr, "ERROR: No branching model named '%s' found in /home/agent/.config/git-graph/models\n", set);
        fprintf(stderr, "       Available models are: none, simple, git-flow\n");
        return 1;
    }
    char *root = repo_root(path, false);
    if (!root) return 1;
    char *qr = shell_quote(root);
    int rc;
    if (set) {
        char *qs = shell_quote(set);
        char *cmd = fmt("git -C %s config git-graph.model %s", qr, qs);
        rc = run_command(cmd);
        if (rc == 0) printf("Branching model set to '%s'\n", set);
        free(qs);
        free(cmd);
    } else {
        char *cmd = fmt("git -C %s config --get git-graph.model 2>/dev/null", qr);
        int st = 0;
        char *val = read_command(cmd, &st);
        if (st == 0 && *val) printf("%s", val);
        else printf("No branching model set");
        free(val);
        free(cmd);
        rc = 0;
    }
    free(qr);
    free(root);
    return rc;
}

static char *pretty_format(const char *f) {
    if (!f || !*f || !strcmp(f, "oneline") || !strcmp(f, "o")) return strdup("format:%h%d %s");
    if (!strcmp(f, "short") || !strcmp(f, "s")) return strdup("short");
    if (!strcmp(f, "medium") || !strcmp(f, "m")) return strdup("medium");
    if (!strcmp(f, "full") || !strcmp(f, "f")) return strdup("full");
    return fmt("format:%s", f);
}

static int render_svg(const char *root, Options *o) {
    (void)o;
    char *qr = shell_quote(root);
    char *cmd = fmt("git -C %s log --all --decorate=short --abbrev-commit --pretty=format:'%%h%%d %%s' 2>/dev/null", qr);
    FILE *fp = popen(cmd, "r");
    if (!fp) {
        free(qr);
        free(cmd);
        return 1;
    }
    puts("<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"960\" height=\"600\">");
    puts("<style>text{font-family:monospace;font-size:14px}.dot{fill:#333}</style>");
    char line[4096];
    int y = 24, idx = 0;
    while (fgets(line, sizeof line, fp)) {
        line[strcspn(line, "\n")] = 0;
        printf("<circle class=\"dot\" cx=\"24\" cy=\"%d\" r=\"5\"/>", y - 5);
        printf("<text x=\"42\" y=\"%d\">", y);
        for (char *p = line; *p; p++) {
            if (*p == '&') fputs("&amp;", stdout);
            else if (*p == '<') fputs("&lt;", stdout);
            else if (*p == '>') fputs("&gt;", stdout);
            else putchar(*p);
        }
        puts("</text>");
        y += 22;
        idx++;
    }
    if (!idx) puts("<text x=\"20\" y=\"24\">No commits</text>");
    puts("</svg>");
    int rc = pclose(fp);
    free(qr);
    free(cmd);
    return (rc != -1 && WIFEXITED(rc)) ? WEXITSTATUS(rc) : 1;
}

static int run_graph(Options *o) {
    if (o->model && !is_model(o->model)) {
        fprintf(stderr, "ERROR: No branching model named '%s' found in /home/agent/.config/git-graph/models\n", o->model);
        fprintf(stderr, "       Available models are: none, simple, git-flow\n");
        return 1;
    }
    if (o->style && !is_style(o->style)) {
        fprintf(stderr, "Unknown characters/style '%s'. Must be one of [normal|thin|round|bold|double|ascii]\n", o->style);
        return 1;
    }
    if (o->color && !is_color(o->color)) {
        fprintf(stderr, "Unknown color mode '%s'. Supports [auto|always|never].\n", o->color);
        return 1;
    }
    char *root = repo_root(o->path, false);
    if (!root) return 1;
    if (o->svg) {
        int rc = render_svg(root, o);
        free(root);
        return rc;
    }
    char *qr = shell_quote(root);
    char *pretty = pretty_format(o->format);
    char *qp = shell_quote(pretty);
    char *maxopt = o->max_count ? fmt("--max-count=%s", o->max_count) : strdup("");
    char *gitcmd = fmt("git -C %s log --graph --decorate=short --date=default --abbrev-commit %s %s %s --pretty=%s %s 2>&1",
                    qr,
                    o->no_color ? "--color=never" : (!strcmp(o->color, "always") ? "--color=always" : "--color=auto"),
                    o->reverse ? "--reverse" : "",
                    maxopt,
                    qp,
                    o->local ? "--branches --tags" : "--all");
    char *cmd = fmt("%s; rc=$?; printf '\\n'; exit $rc", gitcmd);
    int rc = run_command(cmd);
    free(qr);
    free(root);
    free(pretty);
    free(qp);
    free(maxopt);
    free(gitcmd);
    free(cmd);
    return rc;
}

int main(int argc, char **argv) {
    if (argc > 1 && !strcmp(argv[1], "model")) return handle_model(argc, argv);
    if (argc > 1 && !strcmp(argv[1], "help")) {
        if (argc > 2 && !strcmp(argv[2], "model")) print_model_help();
        else print_help();
        return 0;
    }
    Options o;
    memset(&o, 0, sizeof o);
    parse_global(argc, argv, &o, 1);
    return run_graph(&o);
}
