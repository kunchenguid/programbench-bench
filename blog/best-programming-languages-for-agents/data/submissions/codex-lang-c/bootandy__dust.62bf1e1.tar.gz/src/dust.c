#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <regex.h>
#include <time.h>
#include <limits.h>
#include <stdint.h>
#include <ctype.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct Node Node;
struct Node { char *path,*name; long long size; int is_dir,is_leaf,depth; Node **children; int nchild,cap; };

typedef struct { char **v; int n,cap; } StrList;
typedef struct {
    int depth_set,max_depth,threads,full_paths,deref,apparent,reverse,no_bars,bars_right,screen_reader,skip_total,filecount,ignore_hidden,file_types,only_dir,only_file,json,no_progress,print_errors,limit_fs;
    int width,nlines; long long min_size; char output[8]; char filetime; regex_t filter_re, inv_re; int has_filter, has_inv; StrList ignores, collapses, paths; int time_kind, time_op, time_days;
} Opt;

static void sl_add(StrList *l, const char *s){ if(l->n==l->cap){l->cap=l->cap?l->cap*2:8; l->v=realloc(l->v,l->cap*sizeof(char*));} l->v[l->n++]=strdup(s); }
static char *xstrdup(const char*s){ char *r=strdup(s?s:""); if(!r){perror("strdup"); exit(1);} return r; }
static const char *base_name(const char *p){ const char *b=strrchr(p,'/'); return b?b+1:p; }
static int is_hidden_name(const char *p){ const char *b=base_name(p); return b[0]=='.' && strcmp(b,".") && strcmp(b,".."); }
static int ignore_match(Opt*o,const char*p){ for(int i=0;i<o->ignores.n;i++){ if(strcmp(p,o->ignores.v[i])==0 || strcmp(base_name(p),o->ignores.v[i])==0) return 1; } return 0; }
static int collapse_match(Opt*o,const char*p){ for(int i=0;i<o->collapses.n;i++){ if(strcmp(p,o->collapses.v[i])==0 || strcmp(base_name(p),o->collapses.v[i])==0) return 1; } return 0; }
static long long node_own_size(struct stat *st, Opt*o){ if(o->filecount) return S_ISREG(st->st_mode)?1:0; if(o->filetime){ long long t=o->filetime=='a'?st->st_atime:o->filetime=='c'?st->st_ctime:st->st_mtime; return t; } return o->apparent ? (long long)st->st_size : (long long)st->st_blocks*512LL; }
static int time_ok(struct stat *st, Opt*o){ if(!o->time_kind) return 1; time_t t=o->time_kind==1?st->st_mtime:o->time_kind==2?st->st_atime:st->st_ctime; double days=difftime(time(NULL),t)/86400.0; int d=(int)(days<0?0:days); if(o->time_op>0) return d>o->time_days; if(o->time_op<0) return d<o->time_days; return d==o->time_days; }
static int filter_ok(const char*p, struct stat*st, Opt*o){ if(o->ignore_hidden && is_hidden_name(p)) return 0; if(ignore_match(o,p)) return 0; if(!time_ok(st,o)) return 0; if(o->has_filter && regexec(&o->filter_re,p,0,NULL,0)!=0) return 0; if(o->has_inv && regexec(&o->inv_re,p,0,NULL,0)==0) return 0; return 1; }
static void add_child(Node*n, Node*c){ if(n->nchild==n->cap){n->cap=n->cap?n->cap*2:8; n->children=realloc(n->children,n->cap*sizeof(Node*));} n->children[n->nchild++]=c; }
static Node *new_node(const char*path, int depth, Opt*o){ Node*n=calloc(1,sizeof(Node)); n->path=xstrdup(path); n->name=xstrdup(o->full_paths?path:base_name(path)); n->depth=depth; return n; }
static int cmp_size_asc(const void*a,const void*b){ Node*na=*(Node**)a,*nb=*(Node**)b; if(na->size<nb->size)return -1; if(na->size>nb->size)return 1; return strcmp(na->name,nb->name); }
static int cmp_size_desc(const void*a,const void*b){ return -cmp_size_asc(a,b); }
static int cmp_strptr(const void*a,const void*b){ const char * const *sa=a, * const *sb=b; return strcmp(*sa,*sb); }

static Node *scan_path(const char *path, int depth, Opt*o, dev_t rootdev, int is_root){
    struct stat st; int rc=o->deref?stat(path,&st):lstat(path,&st);
    if(rc){ if(is_root || o->print_errors) fprintf(stderr,"%s: %s\n", strerror(errno), path); return NULL; }
    if(o->limit_fs && !is_root && st.st_dev!=rootdev) return NULL;
    if(!is_root && !filter_ok(path,&st,o)) return NULL;
    Node*n=new_node(path,depth,o); n->is_dir=S_ISDIR(st.st_mode); n->is_leaf=!n->is_dir;
    long long own=node_own_size(&st,o), sum=own;
    int filtered=o->has_filter||o->has_inv||o->time_kind;
    if(n->is_dir && !collapse_match(o,path)){
        DIR*d=opendir(path); if(d){
            Node **tmp=NULL; int nt=0,cap=0; struct dirent*de;
            while((de=readdir(d))){ if(!strcmp(de->d_name,".")||!strcmp(de->d_name,"..")) continue; char buf[PATH_MAX]; snprintf(buf,sizeof(buf),"%s/%s",path,de->d_name); if(ignore_match(o,buf) || (o->ignore_hidden&&is_hidden_name(buf))) continue; if(nt==cap){cap=cap?cap*2:16; tmp=realloc(tmp,cap*sizeof(Node*));} tmp[nt++]=(Node*)xstrdup(buf); }
            closedir(d); qsort(tmp,nt,sizeof(char*),cmp_strptr);
            for(int i=0;i<nt;i++){ char *cp=(char*)tmp[i]; Node*c=scan_path(cp,depth+1,o,rootdev,0); free(cp); if(c){ add_child(n,c); if(o->filetime){ if(c->size>sum) sum=c->size; } else sum += c->size; }} free(tmp);
        } else if(o->print_errors) fprintf(stderr,"%s: %s\n", strerror(errno), path);
    }
    if(filtered && n->is_dir){ sum=0; for(int i=0;i<n->nchild;i++) sum += n->children[i]->size; }
    n->size=sum; if(n->nchild>0) n->is_leaf=0;
    if(!is_root && filtered && n->size==0 && n->nchild==0 && n->is_dir) { /* keep matching empty dirs only */ }
    return n;
}

static void collect_display(Node*n, Opt*o, Node***arr,int*cnt,int*cap,int root){
    if(o->only_file){
        if(!o->reverse){
            for(int i=0;i<n->nchild;i++) collect_display(n->children[i],o,arr,cnt,cap,0);
        }
        int include = root || n->nchild==0;
        if(o->min_size && n->size < o->min_size) include=0;
        if(o->depth_set && !root && n->depth > o->max_depth) include=0;
        if(include){
            if(*cnt==*cap){*cap=*cap?*cap*2:32; *arr=realloc(*arr,*cap*sizeof(Node*));}
            (*arr)[(*cnt)++]=n;
        }
        if(o->reverse){
            for(int i=0;i<n->nchild;i++) collect_display(n->children[i],o,arr,cnt,cap,0);
        }
        return;
    }
    int include=1;
    if(o->only_dir && !n->is_dir && !S_ISLNK(0)) include=0;
    if(o->only_dir && !root) include = n->is_dir || n->nchild==0; /* close to dust for symlinks/empty dirs */
    if(o->min_size && n->size < o->min_size) include=0;
    if(o->depth_set && !root && n->depth > o->max_depth) include=0;
    if(!o->reverse){ for(int i=0;i<n->nchild;i++) collect_display(n->children[i],o,arr,cnt,cap,0); }
    if(include){ if(*cnt==*cap){*cap=*cap?*cap*2:32; *arr=realloc(*arr,*cap*sizeof(Node*));} (*arr)[(*cnt)++]=n; }
    if(o->reverse){ for(int i=0;i<n->nchild;i++) collect_display(n->children[i],o,arr,cnt,cap,0); }
}

static void sort_tree(Node*n, Opt*o){
    for(int i=0;i<n->nchild;i++) sort_tree(n->children[i],o);
    qsort(n->children,n->nchild,sizeof(Node*), o->reverse?cmp_size_desc:cmp_size_asc);
}

static void fmt_size(long long s, Opt*o, char*out, size_t len){
    if(o->filecount){ snprintf(out,len,"%lld",s); return; }
    if(o->filetime){ time_t t=(time_t)s; struct tm tm; localtime_r(&t,&tm); strftime(out,len,"%Y-%m-%d",&tm); return; }
    const char *fmt=o->output; if(!fmt[0]) fmt="bin";
    double val=(double)s;
    if(!strcmp(fmt,"b")){ snprintf(out,len,"%lldB",s); return; }
    if(!strcmp(fmt,"k")){ snprintf(out,len,"%lldK",(long long)(s/1024)); return; }
    if(!strcmp(fmt,"m")){ snprintf(out,len,"%lldM",(long long)(s/1024/1024)); return; }
    if(!strcmp(fmt,"g")){ snprintf(out,len,"%lldG",(long long)(s/1024/1024/1024)); return; }
    if(!strcmp(fmt,"t")){ snprintf(out,len,"%lldT",(long long)(s/1024/1024/1024/1024)); return; }
    if(!strcmp(fmt,"kb")){ snprintf(out,len,"%lldK",(long long)(s/1000)); return; }
    if(!strcmp(fmt,"mb")){ snprintf(out,len,"%lldM",(long long)(s/1000/1000)); return; }
    if(!strcmp(fmt,"gb")){ snprintf(out,len,"%lldG",(long long)(s/1000/1000/1000)); return; }
    if(!strcmp(fmt,"tb")){ snprintf(out,len,"%lldT",(long long)(s/1000/1000/1000/1000)); return; }
    int si=!strcmp(fmt,"si"); double base=si?1000.0:1024.0; const char*units[] = {"B","K","M","G","T","P"}; int u=0; while(val>=base && u<5){val/=base; u++;}
    const char *unit=units[u]; if(u==0) snprintf(out,len,"%lldB",s); else if(val<10) snprintf(out,len,"%.1f%s",val,unit); else snprintf(out,len,"%.0f%s",val,unit);
}

static void emit_bar(long long size,long long total,int width){ int pct= total? (int)((100.0*size/total)+0.5):0; int bw=width; if(bw<1)bw=1; int fill= total? (int)((double)size/total*bw+0.5):0; if(fill<1)fill=1; if(fill>bw)fill=bw; printf("│"); for(int i=0;i<bw;i++) fputs(i<fill?"█":"░",stdout); printf(" │ %3d%%",pct); }
static void print_text(Node**arr,int cnt,Opt*o,long long total){
    int maxs=0,maxn=0; char buf[64]; for(int i=0;i<cnt;i++){ fmt_size(arr[i]->size,o,buf,sizeof buf); int l=strlen(buf); if(l>maxs)maxs=l; l=strlen(arr[i]->name)+arr[i]->depth*2+4; if(l>maxn)maxn=l; }
    int barw=o->width - maxs - maxn - 12; if(barw<8) barw=8;
    for(int i=0;i<cnt;i++){
        Node*n=arr[i]; fmt_size(n->size,o,buf,sizeof buf); if(o->screen_reader){ printf("%d %*s %s\n", n->depth, maxs, buf, o->full_paths?n->path:n->name); continue; }
        printf("%*s ",maxs,buf); int indent=n->depth*2; for(int k=0;k<indent;k++) putchar(' ');
        const char *sym="├──"; if(i==cnt-1 || n->depth==0) sym=o->reverse?"└─┬":"┌─┴"; else if(n->nchild>0) sym=o->reverse?"├─┬":"├─┴"; printf("%s %s",sym,o->full_paths?n->path:n->name);
        int used=indent+4+(int)strlen(o->full_paths?n->path:n->name); for(int sp=used; sp<maxn; sp++) putchar(' ');
        if(!o->no_bars){ if(o->bars_right) printf(" "); emit_bar(n->size,total,barw); }
        putchar('\n');
    }
}

static void json_escape(const char*s){ putchar('"'); for(;*s;s++){ if(*s=='"'||*s=='\\') printf("\\%c",*s); else if((unsigned char)*s<32) printf("\\u%04x",(unsigned char)*s); else putchar(*s);} putchar('"'); }
static void print_json_node(Node*n,Opt*o){ char b[64]; fmt_size(n->size,o,b,sizeof b); printf("{\"size\":"); json_escape(b); printf(",\"name\":"); json_escape(o->full_paths?n->path:n->path); printf(",\"children\":["); qsort(n->children,n->nchild,sizeof(Node*),cmp_size_desc); int first=1; for(int i=0;i<n->nchild;i++){ Node*c=n->children[i]; if(o->only_file && c->nchild) { /* flatten handled elsewhere */ } if(o->min_size && c->size<o->min_size) continue; if(o->depth_set && c->depth>o->max_depth) continue; if(!first) putchar(','); first=0; print_json_node(c,o);} printf("]}"); }
static void collect_leaves(Node*n, Node***arr, int*cnt, int*cap){
    if(n->nchild==0){
        if(*cnt==*cap){*cap=*cap?*cap*2:32; *arr=realloc(*arr,*cap*sizeof(Node*));}
        (*arr)[(*cnt)++]=n;
        return;
    }
    for(int i=0;i<n->nchild;i++) collect_leaves(n->children[i],arr,cnt,cap);
}
static void print_json_flat_files(Node*root, Opt*o){
    Node **leaves=NULL; int cnt=0,cap=0; collect_leaves(root,&leaves,&cnt,&cap);
    qsort(leaves,cnt,sizeof(Node*),cmp_size_desc);
    char b[64]; fmt_size(root->size,o,b,sizeof b); printf("{\"size\":"); json_escape(b); printf(",\"name\":"); json_escape(root->path); printf(",\"children\":[");
    int first=1; for(int i=0;i<cnt;i++){ if(o->min_size && leaves[i]->size<o->min_size) continue; if(!first) putchar(','); first=0; char sb[64]; fmt_size(leaves[i]->size,o,sb,sizeof sb); printf("{\"size\":"); json_escape(sb); printf(",\"name\":"); json_escape(leaves[i]->path); printf(",\"children\":[]}"); }
    printf("]}\n"); free(leaves);
}

typedef struct { char ext[64]; long long size; } Group;
static void collect_types(Node*n,Group**g,int*ng,int*cap,Opt*o){ if(n->nchild==0){ const char*bn=base_name(n->path); const char*dot=strrchr(bn,'.'); const char*e=(dot&&dot!=bn)?dot:"(no extension)"; int idx=-1; for(int i=0;i<*ng;i++) if(!strcmp((*g)[i].ext,e)) idx=i; if(idx<0){ if(*ng==*cap){*cap=*cap?*cap*2:8; *g=realloc(*g,*cap*sizeof(Group));} idx=(*ng)++; strncpy((*g)[idx].ext,e,63); (*g)[idx].ext[63]=0; (*g)[idx].size=0;} (*g)[idx].size+=n->size; } for(int i=0;i<n->nchild;i++) collect_types(n->children[i],g,ng,cap,o); }
static int cmp_group(const void*a,const void*b){ const Group*ga=a,*gb=b; if(ga->size<gb->size)return -1; if(ga->size>gb->size)return 1; return strcmp(ga->ext,gb->ext); }

static long long parse_size(const char*s){ char *end; double v=strtod(s,&end); while(isspace((unsigned char)*end))end++; long long mult=1; if(*end){ char c=tolower((unsigned char)*end); if(c=='k')mult=1024LL; else if(c=='m')mult=1024LL*1024; else if(c=='g')mult=1024LL*1024*1024; else if(c=='t')mult=1024LL*1024*1024*1024; } return (long long)(v*mult); }
static void read_paths_file(Opt*o,const char*file,int nul){ FILE*f=!strcmp(file,"-")?stdin:fopen(file,"rb"); if(!f){fprintf(stderr,"%s: %s\n",strerror(errno),file); exit(1);} char *buf=NULL; size_t cap=0,len=0; int ch; while((ch=fgetc(f))!=EOF){ if((nul&&ch=='\0')||(!nul&&ch=='\n')){ if(len){buf[len]=0; sl_add(&o->paths,buf); len=0;} } else { if(len+1>=cap){cap=cap?cap*2:256; buf=realloc(buf,cap);} buf[len++]=ch; }} if(len){buf[len]=0; sl_add(&o->paths,buf);} free(buf); if(f!=stdin)fclose(f); }
static void read_ignore_file(Opt*o,const char*file){ FILE*f=fopen(file,"r"); if(!f){fprintf(stderr,"%s: %s\n",strerror(errno),file); exit(1);} char line[1024]; while(fgets(line,sizeof line,f)){ line[strcspn(line,"\r\n")]=0; if(line[0]) sl_add(&o->ignores,line);} fclose(f); }

static void help(int full){ (void)full; printf("Like du but more intuitive\n\nUsage: executable [OPTIONS] [PATH]...\n\nArguments:\n  [PATH]...  Input files or directories\n\nOptions:\n  -d, --depth <DEPTH>              Depth to show\n  -T, --threads <THREADS>          Number of threads to use\n      --config <FILE>              Specify a config file to use\n  -n, --number-of-lines <NUMBER>   Number of lines of output to show. (Default is terminal_height - 10)\n  -p, --full-paths                 Subdirectories will not have their path shortened\n  -X, --ignore-directory <PATH>    Exclude any file or directory with this path\n  -I, --ignore-all-in-file <FILE>  Exclude any file or directory with a regex matching that listed in this file, the file entries will be added to the ignore regexs provided by --invert_filter\n  -L, --dereference-links          dereference sym links - Treat sym links as directories and go into them\n  -x, --limit-filesystem           Only count the files and directories on the same filesystem as the supplied directory\n  -s, --apparent-size              Use file length instead of blocks\n  -r, --reverse                    Print tree upside down (biggest highest)\n  -c, --no-colors                  No colors will be printed (Useful for commands like: watch)\n  -C, --force-colors               Force colors print\n  -b, --no-percent-bars            No percent bars or percentages will be displayed\n  -B, --bars-on-right              percent bars moved to right side of screen\n  -z, --min-size <MIN_SIZE>        Minimum size file to include in output\n  -R, --screen-reader              For screen readers. Removes bars. Adds new column: depth level (May want to use -p too for full path)\n      --skip-total                 No total row will be displayed\n  -f, --filecount                  Directory '\''size'\'' is number of child files instead of disk size\n  -i, --ignore-hidden              Do not display hidden files\n  -v, --invert-filter <REGEX>      Exclude filepaths matching this regex. To ignore png files type: -v \"\\.png$\"\n  -e, --filter <REGEX>             Only include filepaths matching this regex. For png files type: -e \"\\.png$\"\n  -t, --file-types                 show only these file types\n  -w, --terminal-width <WIDTH>     Specify width of output overriding the auto detection of terminal width\n  -P, --no-progress                Disable the progress indication\n      --print-errors               Print path with errors\n  -D, --only-dir                   Only directories will be displayed\n  -F, --only-file                  Only files will be displayed. (Finds your largest files)\n  -o, --output-format <FORMAT>     Changes output display size. si will print sizes in powers of 1000. b k m g t kb mb gb tb will print the whole tree in that size [possible values: si, b, k, m, g, t, kb, mb, gb, tb]\n  -S, --stack-size <STACK_SIZE>    Specify memory to use as stack size - use if you see: '\''fatal runtime error: stack overflow'\'' (default low memory=1048576, high memory=1073741824)\n  -j, --output-json                Output the directory tree as json to the current directory\n  -M, --mtime <MTIME>              +/-n matches files modified more/less than n days ago\n  -A, --atime <ATIME>              just like -mtime, but based on file access time\n  -y, --ctime <CTIME>              just like -mtime, but based on file change time\n      --files0-from <FILES0_FROM>  Read NUL-terminated paths from FILE (use `-` for stdin)\n      --files-from <FILES_FROM>    Read newline-terminated paths from FILE (use `-` for stdin)\n      --collapse <COLLAPSE>        Keep these directories collapsed\n  -m, --filetime <FILETIME>        Directory '\''size'\'' is max filetime of child files instead of disk size. while a/c/m for last accessed/changed/modified time [possible values: a, c, m]\n  -h, --help                       Print help (see more with '\''--help'\'')\n  -V, --version                    Print version\n"); }
static int valid_format(const char*s){ const char*v[]={"si","b","k","m","g","t","kb","mb","gb","tb",NULL}; for(int i=0;v[i];i++) if(!strcmp(s,v[i]))return 1; return 0; }
static void needarg(int i,int argc,const char*arg){ if(i+1>=argc){ fprintf(stderr,"error: a value is required for '%s' but none was supplied\n\nFor more information, try '--help'.\n",arg); exit(2);} }
static void parse_time_arg(Opt*o,const char*s,int kind){ o->time_kind=kind; if(*s=='+'){o->time_op=1;s++;} else if(*s=='-'){o->time_op=-1;s++;} else o->time_op=0; o->time_days=atoi(s); }
int main(int argc,char**argv){ Opt o; memset(&o,0,sizeof o); o.width=80; o.nlines=0; for(int i=1;i<argc;i++){ char*a=argv[i]; if(!strcmp(a,"--")){ while(++i<argc) sl_add(&o.paths,argv[i]); break; } if(a[0]=='-'&&a[1]){
#define ARG() (needarg(i,argc,a), argv[++i])
        if(!strcmp(a,"-h")||!strcmp(a,"--help")){help(!strcmp(a,"--help"));return 0;} else if(!strcmp(a,"-V")||!strcmp(a,"--version")){puts("Dust 1.2.3");return 0;}
        else if(!strcmp(a,"-d")||!strcmp(a,"--depth")){o.depth_set=1;o.max_depth=atoi(ARG());}
        else if(!strcmp(a,"-T")||!strcmp(a,"--threads")||!strcmp(a,"-S")||!strcmp(a,"--stack-size")||!strcmp(a,"--config")){ARG();}
        else if(!strcmp(a,"-n")||!strcmp(a,"--number-of-lines")){o.nlines=atoi(ARG());}
        else if(!strcmp(a,"-p")||!strcmp(a,"--full-paths")){o.full_paths=1;} else if(!strcmp(a,"-L")||!strcmp(a,"--dereference-links")){o.deref=1;}
        else if(!strcmp(a,"-x")||!strcmp(a,"--limit-filesystem")){o.limit_fs=1;} else if(!strcmp(a,"-s")||!strcmp(a,"--apparent-size")){o.apparent=1;}
        else if(!strcmp(a,"-r")||!strcmp(a,"--reverse")){o.reverse=1;} else if(!strcmp(a,"-c")||!strcmp(a,"--no-colors")){;}
        else if(!strcmp(a,"-C")||!strcmp(a,"--force-colors")){;} else if(!strcmp(a,"-b")||!strcmp(a,"--no-percent-bars")){o.no_bars=1;}
        else if(!strcmp(a,"-B")||!strcmp(a,"--bars-on-right")){o.bars_right=1;} else if(!strcmp(a,"-R")||!strcmp(a,"--screen-reader")){o.screen_reader=1;o.no_bars=1;}
        else if(!strcmp(a,"--skip-total")){o.skip_total=1;} else if(!strcmp(a,"-f")||!strcmp(a,"--filecount")){o.filecount=1;}
        else if(!strcmp(a,"-i")||!strcmp(a,"--ignore-hidden")){o.ignore_hidden=1;} else if(!strcmp(a,"-t")||!strcmp(a,"--file-types")){o.file_types=1;}
        else if(!strcmp(a,"-P")||!strcmp(a,"--no-progress")){o.no_progress=1;} else if(!strcmp(a,"--print-errors")){o.print_errors=1;}
        else if(!strcmp(a,"-D")||!strcmp(a,"--only-dir")){o.only_dir=1;} else if(!strcmp(a,"-F")||!strcmp(a,"--only-file")){o.only_file=1;}
        else if(!strcmp(a,"-j")||!strcmp(a,"--output-json")){o.json=1;} else if(!strcmp(a,"-w")||!strcmp(a,"--terminal-width")){o.width=atoi(ARG());}
        else if(!strcmp(a,"-z")||!strcmp(a,"--min-size")){o.min_size=parse_size(ARG());}
        else if(!strcmp(a,"-X")||!strcmp(a,"--ignore-directory")){sl_add(&o.ignores,ARG());}
        else if(!strcmp(a,"--collapse")){sl_add(&o.collapses,ARG());}
        else if(!strcmp(a,"-I")||!strcmp(a,"--ignore-all-in-file")){read_ignore_file(&o,ARG());}
        else if(!strcmp(a,"-e")||!strcmp(a,"--filter")){ const char*s=ARG(); if(regcomp(&o.filter_re,s,REG_EXTENDED|REG_NOSUB)){fprintf(stderr,"Invalid regex: %s\n",s);return 2;} o.has_filter=1; }
        else if(!strcmp(a,"-v")||!strcmp(a,"--invert-filter")){ const char*s=ARG(); if(regcomp(&o.inv_re,s,REG_EXTENDED|REG_NOSUB)){fprintf(stderr,"Invalid regex: %s\n",s);return 2;} o.has_inv=1; }
        else if(!strcmp(a,"-o")||!strcmp(a,"--output-format")){ const char*s=ARG(); if(!valid_format(s)){fprintf(stderr,"error: invalid value '%s' for '--output-format <FORMAT>'\n  [possible values: si, b, k, m, g, t, kb, mb, gb, tb]\n\nFor more information, try '--help'.\n",s); return 2;} strncpy(o.output,s,sizeof(o.output)-1); }
        else if(!strcmp(a,"-M")||!strcmp(a,"--mtime")){parse_time_arg(&o,ARG(),1);} else if(!strcmp(a,"-A")||!strcmp(a,"--atime")){parse_time_arg(&o,ARG(),2);} else if(!strcmp(a,"-y")||!strcmp(a,"--ctime")){parse_time_arg(&o,ARG(),3);} 
        else if(!strcmp(a,"--files-from")){read_paths_file(&o,ARG(),0);} else if(!strcmp(a,"--files0-from")){read_paths_file(&o,ARG(),1);} else if(!strcmp(a,"-m")||!strcmp(a,"--filetime")){ const char*s=ARG(); o.filetime=*s; }
        else { fprintf(stderr,"error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable [OPTIONS] [PATH]...\n\nFor more information, try '--help'.\n",a,a,a); return 2; }
#undef ARG
    } else sl_add(&o.paths,a); }
    if(o.paths.n==0) sl_add(&o.paths,".");
    Node *root=NULL; if(o.paths.n==1){ struct stat st; dev_t dev=0; if((o.deref?stat(o.paths.v[0],&st):lstat(o.paths.v[0],&st))==0) dev=st.st_dev; root=scan_path(o.paths.v[0],0,&o,dev,1); if(!root) return 1; }
    else { root=new_node("(total)",0,&o); free(root->name); root->name=xstrdup("(total)"); root->is_dir=1; long long sum=0; for(int i=0;i<o.paths.n;i++){ struct stat st; dev_t dev=0; if((o.deref?stat(o.paths.v[i],&st):lstat(o.paths.v[i],&st))==0) dev=st.st_dev; Node*c=scan_path(o.paths.v[i],1,&o,dev,1); if(c){add_child(root,c); sum+=c->size;} else return 1; } root->size=sum; }
    sort_tree(root,&o);
    if(o.file_types){ Group*g=NULL; int ng=0,cap=0; collect_types(root,&g,&ng,&cap,&o); qsort(g,ng,sizeof(Group),cmp_group); Node**arr=NULL; int cnt=0,ac=0; long long total=0; for(int i=0;i<ng;i++) total+=g[i].size; for(int i=0;i<ng;i++){ Node*n=new_node(g[i].ext,1,&o); free(n->name); n->name=xstrdup(g[i].ext); n->size=g[i].size; if(cnt==ac){ac=ac?ac*2:8;arr=realloc(arr,ac*sizeof(Node*));} arr[cnt++]=n;} Node*tot=new_node("(total)",0,&o); free(tot->name); tot->name=xstrdup("(total)"); tot->size=total; if(!o.skip_total){ if(cnt==ac){ac=ac?ac*2:8;arr=realloc(arr,ac*sizeof(Node*));} arr[cnt++]=tot;} print_text(arr,cnt,&o,total); return 0; }
    if(o.json){ if(o.only_file) print_json_flat_files(root,&o); else { print_json_node(root,&o); putchar('\n'); } return 0; }
    Node**arr=NULL; int cnt=0,cap=0; collect_display(root,&o,&arr,&cnt,&cap,1); if(o.skip_total && cnt>0){ for(int i=0;i<cnt;i++) if(arr[i]==root){ memmove(&arr[i],&arr[i+1],(cnt-i-1)*sizeof(Node*)); cnt--; break; } }
    if(o.nlines>0 && cnt>o.nlines) { if(o.reverse) cnt=o.nlines; else memmove(arr, arr+(cnt-o.nlines), o.nlines*sizeof(Node*)), cnt=o.nlines; }
    print_text(arr,cnt,&o,root->size); return 0; }
