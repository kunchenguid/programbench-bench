#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

#define MAX_TASKS 4096
#define MAX_TAGS 64
#define STR 2048

typedef struct {
    char uuid[80], status[32], summary[STR], notes[STR * 4], project[256], priority[8], created[80], resolved[80], due[80];
    char tags[MAX_TAGS][128];
    int tag_count;
    int id;
    char path[PATH_MAX];
    bool is_template;
} Task;

static Task tasks[MAX_TASKS];
static int task_count = 0;
static char repo[PATH_MAX];

static void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap); fputc('\n', stderr); exit(1);
}
static bool starts(const char *s, const char *p) { return strncmp(s,p,strlen(p))==0; }
static char *trim(char *s) { while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s && isspace((unsigned char)e[-1])) *--e=0; return s; }
static void stripq(char *s) { size_t n=strlen(s); if(n>=2 && s[0]=='"' && s[n-1]=='"'){ memmove(s,s+1,n-2); s[n-2]=0; } }
static void ensure_dir(const char *p){ struct stat st; if(stat(p,&st)!=0) mkdir(p,0777); }
static void path_join(char *out, const char *a, const char *b){ snprintf(out, PATH_MAX, "%s/%s", a, b); }
static void init_repo(void){
    const char *e=getenv("DSTASK_GIT_REPO");
    if(e && *e) snprintf(repo,sizeof(repo),"%s",e); else { const char *h=getenv("HOME"); snprintf(repo,sizeof(repo),"%s/.dstask", h?h:"."); }
    ensure_dir(repo);
    char p[PATH_MAX]; const char *dirs[]={"pending","active","paused","resolved","template",NULL};
    for(int i=0;dirs[i];i++){ path_join(p,repo,dirs[i]); ensure_dir(p); }
}
static void now_iso(char *out){
    struct timespec ts; clock_gettime(CLOCK_REALTIME,&ts); struct tm tm; gmtime_r(&ts.tv_sec,&tm);
    char b[64]; strftime(b,sizeof(b),"%Y-%m-%dT%H:%M:%S",&tm); snprintf(out,80,"%s.%09ldZ",b,ts.tv_nsec);
}
static void uuid_new(char *out){
    struct timespec ts; clock_gettime(CLOCK_REALTIME,&ts); unsigned long a=(unsigned long)ts.tv_nsec, b=(unsigned long)getpid(), c=(unsigned long)time(NULL), d=(unsigned long)rand();
    snprintf(out,80,"%08lx-%04lx-%04lx-%04lx-%012lx", (c^d)&0xffffffffUL, a&0xffffUL, b&0xffffUL, (a>>16)&0xffffUL, ((c<<20)^d^a)&0xffffffffffffUL);
}
static bool has_tag(Task *t,const char *tag){ for(int i=0;i<t->tag_count;i++) if(strcmp(t->tags[i],tag)==0) return true; return false; }
static void add_tag(Task *t,const char *tag){ if(!*tag||has_tag(t,tag)||t->tag_count>=MAX_TAGS) return; snprintf(t->tags[t->tag_count++],128,"%s",tag); }
static void del_tag(Task *t,const char *tag){ for(int i=0;i<t->tag_count;i++) if(strcmp(t->tags[i],tag)==0){ for(int j=i;j<t->tag_count-1;j++) strcpy(t->tags[j],t->tags[j+1]); t->tag_count--; return; } }
static void yaml_quote(FILE *f,const char *s){ if(!*s){ fprintf(f,"\"\""); return; } bool q=false; for(const char*p=s;*p;p++) if(*p==':'||*p=='#'||*p=='\n'||*p=='"') q=true; if(!q){ fprintf(f,"%s",s); return; } fputc('"',f); for(const char*p=s;*p;p++){ if(*p=='"'||*p=='\\') fputc('\\',f); if(*p=='\n') fprintf(f,"\\n"); else fputc(*p,f);} fputc('"',f); }
static void save_ids(void){ char p[PATH_MAX]; path_join(p,repo,".dstask_ids"); FILE*f=fopen(p,"w"); if(!f)return; for(int i=0;i<task_count;i++) if(tasks[i].id>0) fprintf(f,"%s %d\n",tasks[i].uuid,tasks[i].id); fclose(f); }
static int id_for_uuid(const char *u){ char p[PATH_MAX], line[256], idu[100]; int id; path_join(p,repo,".dstask_ids"); FILE*f=fopen(p,"r"); if(!f) return 0; while(fgets(line,sizeof(line),f)) if(sscanf(line,"%99s %d",idu,&id)==2 && strcmp(idu,u)==0){ fclose(f); return id; } fclose(f); return 0; }
static void save_task(Task *t){
    char dir[PATH_MAX], path[PATH_MAX]; path_join(dir,repo,t->is_template?"template":t->status); snprintf(path,sizeof(path),"%s/%s.yml",dir,t->uuid);
    if(t->path[0] && strcmp(t->path,path)!=0) unlink(t->path);
    FILE*f=fopen(path,"w"); if(!f) die("cannot write %s",path);
    fprintf(f,"summary: "); yaml_quote(f,t->summary); fprintf(f,"\nnotes: "); yaml_quote(f,t->notes); fprintf(f,"\ntags:");
    if(t->tag_count==0) fprintf(f," []\n"); else { fputc('\n',f); for(int i=0;i<t->tag_count;i++) fprintf(f,"- %s\n",t->tags[i]); }
    fprintf(f,"project: "); yaml_quote(f,t->project); fprintf(f,"\npriority: %s\ndelegatedto: \"\"\nsubtasks: []\ndependencies: []\ncreated: %s\nresolved: %s\ndue: %s\n", t->priority, t->created, t->resolved, t->due);
    fclose(f); snprintf(t->path,sizeof(t->path),"%s",path); save_ids();
}
static void parse_file(const char *path,const char *status,bool templ){
    if(task_count>=MAX_TASKS) return; FILE*f=fopen(path,"r"); if(!f)return; Task*t=&tasks[task_count]; memset(t,0,sizeof(*t)); strcpy(t->status,status); strcpy(t->priority,"P2"); strcpy(t->resolved,"0001-01-01T00:00:00Z"); strcpy(t->due,"0001-01-01T00:00:00Z"); t->is_template=templ; snprintf(t->path,sizeof(t->path),"%s",path);
    const char *base=strrchr(path,'/'); base=base?base+1:path; snprintf(t->uuid,sizeof(t->uuid),"%s",base); char *dot=strrchr(t->uuid,'.'); if(dot)*dot=0;
    char line[4096]; bool in_tags=false;
    while(fgets(line,sizeof(line),f)){ char *s=trim(line); if(starts(s,"- ") && in_tags){ add_tag(t,trim(s+2)); continue; } in_tags=false;
        if(starts(s,"summary:")){ snprintf(t->summary,sizeof(t->summary),"%s",trim(s+8)); stripq(t->summary); }
        else if(starts(s,"notes:")){ snprintf(t->notes,sizeof(t->notes),"%s",trim(s+6)); stripq(t->notes); }
        else if(strcmp(s,"tags:")==0){ in_tags=true; }
        else if(starts(s,"tags: []")){ }
        else if(starts(s,"project:")){ snprintf(t->project,sizeof(t->project),"%s",trim(s+8)); stripq(t->project); }
        else if(starts(s,"priority:")){ snprintf(t->priority,sizeof(t->priority),"%s",trim(s+9)); }
        else if(starts(s,"created:")){ snprintf(t->created,sizeof(t->created),"%s",trim(s+8)); }
        else if(starts(s,"resolved:")){ snprintf(t->resolved,sizeof(t->resolved),"%s",trim(s+9)); }
        else if(starts(s,"due:")){ snprintf(t->due,sizeof(t->due),"%s",trim(s+4)); }
    }
    fclose(f); if(!*t->created) now_iso(t->created); t->id=id_for_uuid(t->uuid); task_count++;
}
static int cmp_task(const void*a,const void*b){ const Task*x=a,*y=b; int px=x->priority[1]?x->priority[1]-'0':2, py=y->priority[1]?y->priority[1]-'0':2; if(px!=py) return px-py; return strcmp(x->created,y->created); }
static void load_dir(const char *d,const char *st,bool templ){ char dir[PATH_MAX]; path_join(dir,repo,d); DIR*dp=opendir(dir); if(!dp)return; struct dirent*de; while((de=readdir(dp))){ if(de->d_name[0]=='.'||!strstr(de->d_name,".yml"))continue; char p[PATH_MAX]; snprintf(p,sizeof(p),"%s/%s",dir,de->d_name); parse_file(p,st,templ);} closedir(dp); }
static void load_tasks(void){ task_count=0; load_dir("pending","pending",false); load_dir("active","active",false); load_dir("paused","paused",false); load_dir("resolved","resolved",false); load_dir("template","pending",true); qsort(tasks,task_count,sizeof(Task),cmp_task); int max=0; for(int i=0;i<task_count;i++) if(tasks[i].id>max) max=tasks[i].id; for(int i=0;i<task_count;i++) if(tasks[i].id<=0 && strcmp(tasks[i].status,"resolved")!=0) tasks[i].id=++max; save_ids(); }
static void json_str(const char*s){ putchar('"'); for(;*s;s++){ unsigned char c=*s; if(c=='"'||c=='\\') printf("\\%c",c); else if(c=='\n') printf("\\n"); else if(c=='\r') printf("\\r"); else if(c=='\t') printf("\\t"); else if(c<32) printf("\\u%04x",c); else putchar(c);} putchar('"'); }
static bool match_filters(Task*t,int n,char**f,bool use_context);
static void print_tasks(bool (*pred)(Task*),int n,char**f,bool ctx){
    bool first=true; printf("["); for(int i=0;i<task_count;i++){ Task*t=&tasks[i]; if(pred&&!pred(t))continue; if(!match_filters(t,n,f,ctx))continue; if(!first) printf(","); first=false;
        printf("\n  {\n    \"uuid\": "); json_str(t->uuid); printf(",\n    \"status\": "); json_str(t->status); printf(",\n    \"id\": %d,\n    \"summary\": ", strcmp(t->status,"resolved")==0?0:t->id); json_str(t->summary);
        printf(",\n    \"notes\": "); json_str(t->notes); printf(",\n    \"tags\": ["); for(int j=0;j<t->tag_count;j++){ if(j)printf(","); printf("\n      "); json_str(t->tags[j]); } if(t->tag_count) printf("\n    "); printf("],\n    \"project\": "); json_str(t->project); printf(",\n    \"priority\": "); json_str(t->priority); printf(",\n    \"created\": "); json_str(t->created); printf(",\n    \"resolved\": "); json_str(t->resolved); printf(",\n    \"due\": "); json_str(t->due); printf("\n  }"); }
    if(!first) printf("\n"); printf("]"); }
static bool pred_open(Task*t){ return !t->is_template && strcmp(t->status,"resolved")!=0; }
static bool pred_res(Task*t){ return !t->is_template && strcmp(t->status,"resolved")==0; }
static bool pred_active(Task*t){ return !t->is_template && strcmp(t->status,"active")==0; }
static bool pred_paused(Task*t){ return !t->is_template && strcmp(t->status,"paused")==0; }
static bool pred_template(Task*t){ return t->is_template; }
static bool pred_unorg(Task*t){ return pred_open(t)&&t->tag_count==0&&!*t->project; }
static void get_context(char*out,size_t n){ const char*e=getenv("DSTASK_CONTEXT"); if(e){snprintf(out,n,"%s",e);return;} char p[PATH_MAX]; path_join(p,repo,"context"); FILE*f=fopen(p,"r"); if(!f){*out=0;return;} fgets(out,n,f); fclose(f); char *s=trim(out); memmove(out,s,strlen(s)+1); }
static bool one_filter(Task*t,const char*f){ if(!*f||strcmp(f,"--")==0) return true; if(f[0]=='+') return has_tag(t,f+1); if(f[0]=='-') return !has_tag(t,f+1); if(starts(f,"project:")) return strcmp(t->project,f+8)==0; if(starts(f,"priority:")) return strcmp(t->priority,f+9)==0; if(strlen(f)==2&&f[0]=='P'&&isdigit((unsigned char)f[1])) return strcmp(t->priority,f)==0; if(starts(f,"due:")) return starts(t->due,f+4); return strstr(t->summary,f)||strstr(t->notes,f); }
static bool match_filters(Task*t,int n,char**f,bool use_context){ if(use_context){ char c[1024]; get_context(c,sizeof(c)); char *save=NULL,*tok=strtok_r(c," ",&save); while(tok){ if(!one_filter(t,tok)) return false; tok=strtok_r(NULL," ",&save);} } for(int i=0;i<n;i++) if(strcmp(f[i],"--")&& !one_filter(t,f[i])) return false; return true; }
static Task *find_id(int id){ for(int i=0;i<task_count;i++) if(tasks[i].id==id && strcmp(tasks[i].status,"resolved")!=0) return &tasks[i]; return NULL; }
static void apply_attr(Task*t,const char*arg){ if(starts(arg,"-project:")) *t->project=0; else if(arg[0]=='+') add_tag(t,arg+1); else if(arg[0]=='-') del_tag(t,arg+1); else if(starts(arg,"project:")) snprintf(t->project,sizeof(t->project),"%s",arg+8); else if(starts(arg,"priority:")) snprintf(t->priority,sizeof(t->priority),"%s",arg+9); else if(strlen(arg)==2&&arg[0]=='P'&&isdigit((unsigned char)arg[1])) snprintf(t->priority,sizeof(t->priority),"%s",arg); else if(starts(arg,"due:")) snprintf(t->due,sizeof(t->due),"%sT00:00:00Z",arg+4); }
static bool is_attr(const char*a){ return a[0]=='+'||a[0]=='-'||starts(a,"project:")||starts(a,"priority:")||starts(a,"due:")||(strlen(a)==2&&a[0]=='P'&&isdigit((unsigned char)a[1]))||starts(a,"template:"); }
static int next_id(void){ int m=0; for(int i=0;i<task_count;i++) if(tasks[i].id>m)m=tasks[i].id; return m+1; }
static void add_like(int argc,char**argv,bool templ,bool resolved){ Task t; memset(&t,0,sizeof(t)); uuid_new(t.uuid); strcpy(t.status,resolved?"resolved":"pending"); strcpy(t.priority,"P2"); strcpy(t.resolved,"0001-01-01T00:00:00Z"); strcpy(t.due,"0001-01-01T00:00:00Z"); now_iso(t.created); if(resolved) now_iso(t.resolved); t.id=next_id(); t.is_template=templ; bool ignore_ctx=false, note=false; char summary[STR]="", notes[STR*4]="";
    for(int i=0;i<argc;i++) if(strcmp(argv[i],"--")==0) ignore_ctx=true;
    if(!ignore_ctx){ char c[1024]; get_context(c,sizeof(c)); char *save=NULL,*tok=strtok_r(c," ",&save); while(tok){ apply_attr(&t,tok); tok=strtok_r(NULL," ",&save);} }
    for(int i=0;i<argc;i++){ char*a=argv[i]; if(strcmp(a,"--")==0) continue; if(strcmp(a,"/")==0){ note=true; continue; } if(note){ if(*notes) strcat(notes," "); strncat(notes,a,sizeof(notes)-strlen(notes)-1); continue; } if(is_attr(a)){ apply_attr(&t,a); continue; } if(*summary) strcat(summary," "); strncat(summary,a,sizeof(summary)-strlen(summary)-1); }
    snprintf(t.summary,sizeof(t.summary),"%s",summary); snprintf(t.notes,sizeof(t.notes),"%s",notes); tasks[task_count++]=t; save_task(&tasks[task_count-1]); printf("\n%s %d: %s\n", resolved?"Logged":(templ?"Templated":"Added"), t.id, t.summary); }
static void usage(void){ printf("Usage: dstask [id...] <cmd> [task summary/filter]\n\nAvailable commands:\n\nnext              : Show most important tasks (priority, creation date -- truncated and default)\nadd               : Add a task\ntemplate          : Add a task template\nlog               : Log a task (already resolved)\nstart             : Change task status to active\nnote              : Append to or edit note for a task\nstop              : Change task status to pending\ndone              : Resolve a task\ncontext           : Set global context for task list and new tasks (use \"none\" to set no context)\nmodify            : Change task attributes specified on command line\nedit              : Edit task with text editor\nundo              : Undo last n commits\nsync              : Pull then push to git repository, automatic merge commit.\nopen              : Open all URLs found in summary/annotations\ngit               : Pass a command to git in the repository. Used for push/pull.\nremove            : Remove a task (use to remove tasks added by mistake)\nshow-projects     : List projects with completion status\nshow-tags         : List tags in use\nshow-active       : Show tasks that have been started\nshow-paused       : Show tasks that have been started then stopped\nshow-open         : Show all non-resolved tasks (without truncation)\nshow-resolved     : Show resolved tasks\nshow-templates    : Show task templates\nshow-unorganised  : Show untagged tasks with no projects (global context)\nbash-completion   : Print bash completion script to stdout\nfish-completion   : Print fish completion script to stdout\nzsh-completion    : Print zsh completion script to stdout\nhelp              : Get help on any command or show this message\nversion           : Show dstask version information\n"); }
static void help_cmd(const char*c){ if(!c){usage();return;} if(strcmp(c,"add")==0) printf("Usage: dstask add [template:<id>] [task summary] [--]\nExample: dstask add Fix main web page 500 error +bug P1 project:website\n"); else if(strcmp(c,"context")==0) printf("Usage: dstask context <filter>\nExample: dstask context +work -bug\nExample: dstask context none\n"); else if(strcmp(c,"modify")==0) printf("Usage: dstask <id...> modify <filter>\nUsage: dstask modify <filter>\n"); else if(strcmp(c,"note")==0) printf("Usage: dstask note <id>\nUsage: dstask note <id> <text>\n"); else usage(); }
static void show_tags(void){ char seen[1024][128]; int n=0; for(int i=0;i<task_count;i++) if(pred_open(&tasks[i])) for(int j=0;j<tasks[i].tag_count;j++){ bool ok=true; for(int k=0;k<n;k++) if(strcmp(seen[k],tasks[i].tags[j])==0) ok=false; if(ok&&n<1024) strcpy(seen[n++],tasks[i].tags[j]); } for(int i=0;i<n;i++) printf("%s\n",seen[i]); }
static void show_projects(void){ printf("["); bool first=true; for(int i=0;i<task_count;i++){ Task*t=&tasks[i]; if(!*t->project)continue; bool seen=false; for(int j=0;j<i;j++) if(strcmp(tasks[j].project,t->project)==0) seen=true; if(seen)continue; int cnt=0,res=0; bool act=false; for(int j=0;j<task_count;j++) if(strcmp(tasks[j].project,t->project)==0){cnt++; if(strcmp(tasks[j].status,"resolved")==0)res++; if(strcmp(tasks[j].status,"active")==0)act=true;} if(!first)printf(","); first=false; printf("\n  {\n    \"name\": "); json_str(t->project); printf(",\n    \"taskCount\": %d,\n    \"resolvedCount\": %d,\n    \"active\": %s,\n    \"created\": ",cnt,res,act?"true":"false"); json_str(t->created); printf(",\n    \"resolved\": "); json_str(t->resolved); printf(",\n    \"priority\": "); json_str(t->priority); printf("\n  }"); } if(!first)printf("\n"); printf("]"); }
int main(int argc,char**argv){ srand(time(NULL)^getpid()); init_repo(); load_tasks(); if(argc<=1){ print_tasks(pred_open,0,NULL,true); return 0; }
    int ids[128], nid=0, cmdi=1; while(cmdi<argc && isdigit((unsigned char)argv[cmdi][0])) ids[nid++]=atoi(argv[cmdi++]); char*cmd= cmdi<argc?argv[cmdi]:"next"; if(strcmp(cmd,"--help")==0||strcmp(cmd,"help")==0){ help_cmd(cmdi+1<argc?argv[cmdi+1]:NULL); return 0; } if(strcmp(cmd,"version")==0){ printf("Version: Unknown\nGit commit: Unknown\nBuild date: Unknown\n"); return 0; }
    if(strcmp(cmd,"bash-completion")==0){ puts("# wire bash completions to dstask completion engine.\n_dstask() { COMPREPLY=( $(dstask _completions \"${COMP_WORDS[@]}\") ); }\ncomplete -F _dstask dstask"); return 0; }
    if(strcmp(cmd,"zsh-completion")==0){ puts("#compdef dstask\n_dstask() { compadd -- $(dstask _completions \"${words[@]}\") }\ncompdef _dstask dstask"); return 0; }
    if(strcmp(cmd,"fish-completion")==0){ puts("#!/usr/bin/env fish\ncomplete -f -c dstask -a (echo (dstask _completions) | string collect)"); return 0; }
    if(strcmp(cmd,"_completions")==0){ puts("next add template log start note stop done context modify edit undo sync open git remove show-projects show-tags show-active show-paused show-open show-resolved show-templates show-unorganised help version"); return 0; }
    if(strcmp(cmd,"add")==0){ add_like(argc-cmdi-1,argv+cmdi+1,false,false); return 0; } if(strcmp(cmd,"template")==0){ add_like(argc-cmdi-1,argv+cmdi+1,true,false); return 0; } if(strcmp(cmd,"log")==0){ add_like(argc-cmdi-1,argv+cmdi+1,false,true); return 0; }
    if(strcmp(cmd,"context")==0){ char p[PATH_MAX]; path_join(p,repo,"context"); FILE*f=fopen(p,"w"); if(!f)return 1; if(cmdi+1<argc && strcmp(argv[cmdi+1],"none")!=0){ for(int i=cmdi+1;i<argc;i++){ if(i>cmdi+1)fputc(' ',f); fputs(argv[i],f);} fclose(f); printf("\033[33mActive context: "); for(int i=cmdi+1;i<argc;i++) printf("%s%s",i>cmdi+1?" ":"",argv[i]); printf("\033[0m\n"); } else fclose(f); return 0; }
    if(strcmp(cmd,"next")==0||strcmp(cmd,"show-open")==0){ bool ctx=true; char**f=argv+cmdi+1; int n=argc-cmdi-1; for(int i=0;i<n;i++) if(strcmp(f[i],"--")==0)ctx=false; print_tasks(pred_open,n,f,ctx); return 0; }
    if(starts(cmd,"show-")){ if(strcmp(cmd,"show-resolved")==0) print_tasks(pred_res,argc-cmdi-1,argv+cmdi+1,false); else if(strcmp(cmd,"show-active")==0) print_tasks(pred_active,0,NULL,false); else if(strcmp(cmd,"show-paused")==0) print_tasks(pred_paused,0,NULL,false); else if(strcmp(cmd,"show-templates")==0) print_tasks(pred_template,argc-cmdi-1,argv+cmdi+1,false); else if(strcmp(cmd,"show-unorganised")==0) print_tasks(pred_unorg,0,NULL,false); else if(strcmp(cmd,"show-tags")==0) show_tags(); else if(strcmp(cmd,"show-projects")==0) show_projects(); return 0; }
    if(nid==0 && isdigit((unsigned char)cmd[0])){ ids[nid++]=atoi(cmd); cmd="next"; cmdi++; }
    if(strcmp(cmd,"start")==0||strcmp(cmd,"stop")==0||strcmp(cmd,"done")==0||strcmp(cmd,"remove")==0||strcmp(cmd,"modify")==0||strcmp(cmd,"note")==0){ if(nid==0 && cmdi+1<argc && isdigit((unsigned char)argv[cmdi+1][0])) ids[nid++]=atoi(argv[++cmdi]); for(int k=0;k<nid;k++){ Task*t=find_id(ids[k]); if(!t){ fprintf(stderr,"\033[31mno open task with ID %d exists\033[0m\n",ids[k]); continue; } if(strcmp(cmd,"start")==0){ strcpy(t->status,"active"); printf("\nStarted %d: %s\n",t->id,t->summary); save_task(t); } else if(strcmp(cmd,"stop")==0){ strcpy(t->status,"paused"); printf("\nStopped %d: %s\n",t->id,t->summary); save_task(t); } else if(strcmp(cmd,"done")==0){ strcpy(t->status,"resolved"); now_iso(t->resolved); printf("\nResolved %d: %s\n",t->id,t->summary); save_task(t); } else if(strcmp(cmd,"remove")==0){ printf("\nRemoved %d: %s\n",t->id,t->summary); unlink(t->path); } else if(strcmp(cmd,"modify")==0){ for(int i=cmdi+1;i<argc;i++) apply_attr(t,argv[i]); printf("\nModified %d: %s\n",t->id,t->summary); save_task(t); } else if(strcmp(cmd,"note")==0){ for(int i=cmdi+1;i<argc;i++){ if(isdigit((unsigned char)argv[i][0]))continue; if(*t->notes) strncat(t->notes,"\n",sizeof(t->notes)-strlen(t->notes)-1); strncat(t->notes,argv[i],sizeof(t->notes)-strlen(t->notes)-1); } save_task(t); } } return 0; }
    if(strcmp(cmd,"git")==0){ char buf[4096]="git -C '"; strcat(buf,repo); strcat(buf,"'"); for(int i=cmdi+1;i<argc;i++){ strcat(buf," '"); strcat(buf,argv[i]); strcat(buf,"'"); } return system(buf); }
    if(strcmp(cmd,"sync")==0){ return system("git pull && git push"); } if(strcmp(cmd,"undo")==0){ puts("Undo is not implemented in this reimplementation."); return 0; }
    print_tasks(pred_open,argc-1,argv+1,true); return 0; }
