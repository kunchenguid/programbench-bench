#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    char *data;
    size_t len, cap;
} Str;

typedef struct {
    char **v;
    int n, cap;
} List;

typedef struct {
    bool check, print, fail_on_change, wrap, stdin_mode, recursive;
    bool verbose, quiet, trace, noconfig, usetabs, args;
    int wraplen, tabsize;
    char *config, *completion;
    List files;
} Opt;

static void die_oom(void) { fputs("out of memory\n", stderr); exit(2); }
static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) die_oom(); return p; }

static void s_reserve(Str *s, size_t add) {
    if (s->len + add + 1 <= s->cap) return;
    size_t nc = s->cap ? s->cap * 2 : 256;
    while (nc < s->len + add + 1) nc *= 2;
    char *p = realloc(s->data, nc);
    if (!p) die_oom();
    s->data = p; s->cap = nc;
}
static void s_addn(Str *s, const char *p, size_t n) { s_reserve(s, n); memcpy(s->data + s->len, p, n); s->len += n; s->data[s->len] = 0; }
static void s_adds(Str *s, const char *p) { s_addn(s, p, strlen(p)); }
static void s_addc(Str *s, char c) { s_reserve(s, 1); s->data[s->len++] = c; s->data[s->len] = 0; }
static void list_add(List *l, char *s) {
    if (l->n == l->cap) {
        l->cap = l->cap ? l->cap * 2 : 16;
        l->v = realloc(l->v, sizeof(char*) * l->cap);
        if (!l->v) die_oom();
    }
    l->v[l->n++] = s;
}

static char *trim_left(char *s) { while (*s && isspace((unsigned char)*s) && *s != '\n') s++; return s; }
static void rstrip(char *s) {
    size_t n = strlen(s);
    while (n && (s[n-1] == '\n' || s[n-1] == '\r' || s[n-1] == ' ' || s[n-1] == '\t')) s[--n] = 0;
}
static bool starts(const char *s, const char *p) { return strncmp(s, p, strlen(p)) == 0; }
static bool contains(const char *s, const char *p) { return strstr(s, p) != NULL; }

static char *indent_str(int level, const Opt *o) {
    if (level < 0) level = 0;
    int n = level * o->tabsize;
    char *p = malloc((size_t)n + 1);
    if (!p) die_oom();
    memset(p, o->usetabs ? '\t' : ' ', (size_t)n);
    p[n] = 0;
    return p;
}

static bool env_name(const char *line, const char *cmd, char *buf, size_t bufsz) {
    size_t l = strlen(cmd);
    if (strncmp(line, cmd, l) != 0 || line[l] != '{') return false;
    const char *p = line + l + 1, *q = strchr(p, '}');
    if (!q || q == p) return false;
    size_t n = (size_t)(q - p);
    if (n >= bufsz) n = bufsz - 1;
    memcpy(buf, p, n); buf[n] = 0;
    return true;
}
static bool is_noindent_env(const char *e) { return strcmp(e, "document") == 0; }
static bool is_list_env(const char *e) {
    return !strcmp(e,"itemize") || !strcmp(e,"enumerate") || !strcmp(e,"description") ||
           !strcmp(e,"inlineroman") || !strcmp(e,"inventory");
}
static bool is_verbatim_env(const char *e) {
    return !strcmp(e,"verbatim") || !strcmp(e,"Verbatim") || !strcmp(e,"lstlisting") ||
           !strcmp(e,"minted") || !strcmp(e,"comment");
}
static bool is_section_cmd(const char *s) {
    const char *cmds[] = {"\\part{","\\chapter{","\\section{","\\subsection{","\\subsubsection{","\\paragraph{","\\subparagraph{",NULL};
    for (int i=0; cmds[i]; i++) if (starts(s, cmds[i])) return true;
    return false;
}
static bool is_display_close(const char *s) { return starts(s, "\\]") || starts(s, "\\)") || starts(s, "$$"); }
static bool is_display_open(const char *s) { return starts(s, "\\[") || starts(s, "\\(") || starts(s, "$$"); }

static void add_wrapped(Str *out, const char *indent, const char *cont_indent, const char *text, const Opt *o) {
    int width = o->wraplen;
    if (width > 50) width -= 10;
    if (!o->wrap || (int)(strlen(indent) + strlen(text)) <= width) {
        s_adds(out, indent); s_adds(out, text); s_addc(out, '\n'); return;
    }
    char *copy = xstrdup(text), *p = copy;
    const char *curind = indent;
    int col = (int)strlen(curind);
    s_adds(out, curind);
    bool first_word = true;
    while (*p) {
        while (*p && isspace((unsigned char)*p)) p++;
        if (!*p) break;
        char *w = p;
        while (*p && !isspace((unsigned char)*p)) p++;
        int wl = (int)(p - w);
        if (!first_word && col + 1 + wl >= width && col > (int)strlen(curind)) {
            s_addc(out, '\n');
            curind = cont_indent;
            s_adds(out, curind);
            col = (int)strlen(curind);
            first_word = true;
        }
        if (!first_word) { s_addc(out, ' '); col++; }
        s_addn(out, w, (size_t)wl); col += wl; first_word = false;
    }
    s_addc(out, '\n');
    free(copy);
}

static char *format_text(const char *input, const Opt *o) {
    Str out = {0};
    int depth = 0, list_depth = 0, bib_depth = 0;
    bool off = false, verb = false;
    const char *pos = input;
    while (*pos) {
        const char *nl = strchr(pos, '\n');
        size_t line_len = nl ? (size_t)(nl - pos) : strlen(pos);
        char *line = malloc(line_len + 1);
        if (!line) die_oom();
        memcpy(line, pos, line_len);
        line[line_len] = 0;
        pos = nl ? nl + 1 : pos + line_len;
        rstrip(line);
        char *t = trim_left(line);
        char env[128];
        if (off) {
            s_adds(&out, line); s_addc(&out, '\n');
            if (contains(t, "% tex-fmt: on")) off = false;
            free(line);
            continue;
        }
        if (contains(t, "% tex-fmt: off")) { off = true; s_adds(&out, line); s_addc(&out, '\n'); free(line); continue; }
        if (contains(t, "% tex-fmt: skip")) { s_adds(&out, line); s_addc(&out, '\n'); free(line); continue; }
        if (verb) {
            s_adds(&out, line); s_addc(&out, '\n');
            if (env_name(t, "\\end", env, sizeof env) && is_verbatim_env(env)) {
                verb = false;
                if (depth > 0) depth--;
            }
            free(line);
            continue;
        }
        if (*t == 0) { s_addc(&out, '\n'); free(line); continue; }

        if (bib_depth && t[0] == '}') bib_depth--;
        if (env_name(t, "\\end", env, sizeof env)) {
            if (is_list_env(env) && list_depth > 0) list_depth--;
            if (!is_noindent_env(env) && depth > 0) depth--;
        } else if (is_display_close(t) && depth > 0) {
            depth--;
        }

        int ind_level = depth;
        bool item = starts(t, "\\item");
        if (bib_depth) ind_level = bib_depth;
        if (item) ind_level = depth;
        if (list_depth && !item && !starts(t, "\\begin") && !starts(t, "\\end")) ind_level = depth + 1;
        if (is_section_cmd(t)) ind_level = depth;
        if (t[0] == '}') ind_level = 0;
        char *ind = indent_str(ind_level, o);
        char *cont = indent_str(ind_level + (item ? 1 : 0), o);
        add_wrapped(&out, ind, cont, t, o);
        free(ind); free(cont);

        if (env_name(t, "\\begin", env, sizeof env)) {
            if (is_verbatim_env(env)) verb = true;
            if (!is_noindent_env(env)) depth++;
            if (is_list_env(env)) list_depth++;
        } else if (is_display_open(t)) {
            depth++;
        } else if (t[0] == '@' && strchr(t, '{') && !strchr(t, '}')) {
            bib_depth++;
        } else if (strchr(t, '{') && t[strlen(t)-1] == '%' && !starts(t, "\\begin")) {
            depth++;
        }
        free(line);
    }
    if (!out.data) return xstrdup("");
    return out.data;
}

static char *read_all(FILE *f) {
    Str s = {0};
    char buf[8192];
    size_t n;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) s_addn(&s, buf, n);
    return s.data ? s.data : xstrdup("");
}
static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    char *s = read_all(f);
    fclose(f);
    return s;
}
static bool write_file(const char *path, const char *s) {
    FILE *f = fopen(path, "wb");
    if (!f) return false;
    fputs(s, f);
    fclose(f);
    return true;
}

static void apply_config_file(Opt *o, const char *path) {
    char *txt = read_file(path);
    if (!txt) return;
    char *save = NULL;
    for (char *line = strtok_r(txt, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *hash = strchr(line, '#');
        if (hash) *hash = 0;
        char *t = trim_left(line);
        rstrip(t);
        char *eq = strchr(t, '=');
        if (!eq) continue;
        *eq = 0;
        char *key = trim_left(t), *val = trim_left(eq + 1);
        rstrip(key); rstrip(val);
        bool btrue = starts(val, "true");
        bool bfalse = starts(val, "false");
        if (!strcmp(key, "check") && (btrue || bfalse)) o->check = btrue;
        else if (!strcmp(key, "print") && (btrue || bfalse)) o->print = btrue;
        else if (!strcmp(key, "fail-on-change") && (btrue || bfalse)) o->fail_on_change = btrue;
        else if (!strcmp(key, "wrap") && (btrue || bfalse)) o->wrap = btrue;
        else if (!strcmp(key, "stdin") && (btrue || bfalse)) o->stdin_mode = btrue;
        else if (!strcmp(key, "wraplen")) o->wraplen = atoi(val);
        else if (!strcmp(key, "tabsize")) o->tabsize = atoi(val);
        else if (!strcmp(key, "tabchar") && contains(val, "tab")) o->usetabs = true;
        else if (!strcmp(key, "tabchar") && contains(val, "space")) o->usetabs = false;
        else if (!strcmp(key, "verbosity")) {
            o->quiet = contains(val, "error");
            o->verbose = contains(val, "info");
            o->trace = contains(val, "trace");
        }
    }
    free(txt);
}

static void apply_default_config(Opt *o, int argc, char **argv) {
    bool noconfig = false;
    const char *cfg = NULL;
    for (int i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--noconfig")) noconfig = true;
        else if (!strcmp(argv[i], "--config") && i + 1 < argc) cfg = argv[++i];
    }
    if (noconfig) return;
    if (cfg) { apply_config_file(o, cfg); return; }
    if (!access("tex-fmt.toml", R_OK)) apply_config_file(o, "tex-fmt.toml");
}

static char *display_path(const char *arg) {
    if (strchr(arg, '.') || arg[strlen(arg)-1] == '/') return xstrdup(arg);
    Str s = {0}; s_adds(&s, arg); s_adds(&s, ".tex"); return s.data;
}
static bool allowed_ext(const char *p) {
    const char *d = strrchr(p, '.');
    return d && (!strcmp(d,".tex") || !strcmp(d,".bib") || !strcmp(d,".cls") || !strcmp(d,".sty"));
}
static int process_path(const char *arg, const Opt *o) {
    char *path = display_path(arg);
    char *in = read_file(path);
    if (!in) { fprintf(stderr, "ERROR: tex-fmt %s: Could not open file. \n", path); free(path); return 1; }
    char *fmt = format_text(in, o);
    int changed = strcmp(in, fmt) != 0;
    int rc = 0;
    if (o->check) {
        if (changed) { fprintf(stderr, "ERROR: tex-fmt %s: Incorrect formatting. \n", path); rc = 1; }
    } else if (o->print) {
        fputs(fmt, stdout);
    } else {
        if (changed && !write_file(path, fmt)) { fprintf(stderr, "ERROR: tex-fmt %s: Could not write file. \n", path); rc = 1; }
        if (changed && o->fail_on_change) rc = 1;
    }
    free(path); free(in); free(fmt);
    return rc;
}

static void scan_dir(const char *dir, List *files) {
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name,".") || !strcmp(e->d_name,"..") || !strcmp(e->d_name,".git")) continue;
        Str p={0}; s_adds(&p, dir); if (p.len && p.data[p.len-1] != '/') s_addc(&p, '/'); s_adds(&p, e->d_name);
        struct stat st;
        if (!stat(p.data, &st)) {
            if (S_ISDIR(st.st_mode)) scan_dir(p.data, files);
            else if (S_ISREG(st.st_mode) && allowed_ext(p.data)) list_add(files, p.data);
            else free(p.data);
        } else free(p.data);
    }
    closedir(d);
}

static void print_help(void) {
    puts("tex-fmt 0.5.6\n\nLaTeX formatter written in Rust\n\nUsage: executable [OPTIONS] [files]...\n\nArguments:\n  [files]...  List of files to be formatted\n\nOptions:\n  -c, --check               Check formatting, do not modify files\n  -p, --print               Print to stdout, do not modify files\n  -f, --fail-on-change      Format files and return non-zero exit code if files are modified\n  -n, --nowrap              Do not wrap long lines\n  -l, --wraplen <N>         Line length for wrapping [default: 80]\n  -t, --tabsize <N>         Number of characters to use as tab size [default: 2]\n      --usetabs             Use tabs instead of spaces for indentation\n  -s, --stdin               Process stdin as a single file, output to stdout\n      --config <PATH>       Path to config file\n      --noconfig            Do not read any config file\n  -v, --verbose             Show info messages\n  -q, --quiet               Hide warning messages\n      --trace               Show trace messages\n      --completion <SHELL>  Generate shell completion script [possible values: bash, elvish, fish, powershell, zsh]\n      --man                 Generate man page\n      --args                Print arguments passed to tex-fmt and exit\n  -r, --recursive           Recursively search for files to format\n  -h, --help                Print help\n  -V, --version             Print version");
}
static void print_args(const Opt *o) {
    printf("tex-fmt\n  check:                   %s\n  print:                   %s\n  fail-on-change:          %s\n  wrap:                    %s\n  wraplen:                 %d\n  wrapmin:                 %d\n  tabsize:                 %d\n  tabchar:                 %s\n  stdin:                   %s\n  config:                  %s\n  verbosity:               %s\n  lists:                   itemize\n                           enumerate\n                           description\n                           inlineroman\n                           inventory\n  verbatims:               verbatim\n                           Verbatim\n                           lstlisting\n                           minted\n                           comment\n  no-indent-envs:          document\n  wrap-chars:               \n",
        o->check?"true":"false", o->print?"true":"false", o->fail_on_change?"true":"false",
        o->wrap?"true":"false", o->wraplen, o->wrap ? (o->wraplen > 10 ? o->wraplen-10 : o->wraplen) : o->wraplen,
        o->tabsize, o->usetabs?"tab":"space", o->stdin_mode?"true":"false", o->config?o->config:"None",
        o->trace?"trace":(o->verbose?"info":(o->quiet?"error":"warn")));
}

static int parse_int_arg(int *i, int argc, char **argv) {
    if (*i + 1 >= argc) { fprintf(stderr, "error: a value is required\n"); exit(2); }
    return atoi(argv[++*i]);
}
int main(int argc, char **argv) {
    Opt o = {.wrap=true, .wraplen=80, .tabsize=2};
    apply_default_config(&o, argc, argv);
    for (int i=1; i<argc; i++) {
        char *a = argv[i];
        if (!strcmp(a,"--help") || !strcmp(a,"-h")) { print_help(); return 0; }
        else if (!strcmp(a,"--version") || !strcmp(a,"-V")) { puts("tex-fmt 0.5.6"); return 0; }
        else if (!strcmp(a,"--check") || !strcmp(a,"-c")) o.check=true;
        else if (!strcmp(a,"--print") || !strcmp(a,"-p")) o.print=true;
        else if (!strcmp(a,"--fail-on-change") || !strcmp(a,"-f")) o.fail_on_change=true;
        else if (!strcmp(a,"--nowrap") || !strcmp(a,"-n")) o.wrap=false;
        else if (!strcmp(a,"--wraplen") || !strcmp(a,"-l")) o.wraplen=parse_int_arg(&i,argc,argv);
        else if (!strcmp(a,"--tabsize") || !strcmp(a,"-t")) o.tabsize=parse_int_arg(&i,argc,argv);
        else if (!strcmp(a,"--usetabs")) o.usetabs=true;
        else if (!strcmp(a,"--stdin") || !strcmp(a,"-s")) o.stdin_mode=true;
        else if (!strcmp(a,"--recursive") || !strcmp(a,"-r")) o.recursive=true;
        else if (!strcmp(a,"--noconfig")) o.noconfig=true;
        else if (!strcmp(a,"--config")) o.config=argv[++i];
        else if (!strcmp(a,"--verbose") || !strcmp(a,"-v")) o.verbose=true;
        else if (!strcmp(a,"--quiet") || !strcmp(a,"-q")) o.quiet=true;
        else if (!strcmp(a,"--trace")) o.trace=true;
        else if (!strcmp(a,"--args")) o.args=true;
        else if (!strcmp(a,"--completion")) o.completion=argv[++i];
        else if (!strcmp(a,"--man")) { puts(".TH tex-fmt 1\n.SH NAME\ntex-fmt - LaTeX formatter"); return 0; }
        else if (a[0] == '-') { fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS] [files]...\n\nFor more information, try '--help'.\n", a); return 2; }
        else list_add(&o.files, a);
    }
    if (o.completion) { printf("# completion for %s\n", o.completion); return 0; }
    if (o.args) { print_args(&o); return 0; }
    if (o.stdin_mode) {
        char *in = read_all(stdin), *fmt = format_text(in, &o);
        fputs(fmt, stdout); free(in); free(fmt); return 0;
    }
    if (o.recursive) {
        if (o.files.n == 0) scan_dir(".", &o.files);
        else {
            List roots = o.files; o.files.v = NULL; o.files.n = o.files.cap = 0;
            for (int i=0;i<roots.n;i++) scan_dir(roots.v[i], &o.files);
        }
    }
    int rc = 0;
    for (int i=0; i<o.files.n; i++) if (process_path(o.files.v[i], &o)) rc = 1;
    return rc;
}
