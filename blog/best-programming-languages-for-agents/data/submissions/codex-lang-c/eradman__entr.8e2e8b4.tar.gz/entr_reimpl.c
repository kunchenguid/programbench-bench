#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/inotify.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <termios.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct {
    char *input;
    char *abs;
    char *dir;
    char *base;
    int is_dir;
    int wd;
} Watch;

static const char *prog = "executable";
static volatile sig_atomic_t stop_requested = 0;
static volatile sig_atomic_t child_signal_seen = 0;
static pid_t child_pid = -1;
static pid_t child_pgid = -1;

static void on_signal(int sig) {
    if (sig == SIGCHLD)
        child_signal_seen = 1;
    else
        stop_requested = sig;
}

static void warnx(const char *fmt, ...) {
    va_list ap;
    fprintf(stderr, "%s: ", prog);
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
}

static void usage(void) {
    fprintf(stderr, "release: 5.7\n");
    fprintf(stderr, "usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames\n");
    fprintf(stderr, "hint: use -h to display option summary\n");
}

static void help(void) {
    puts("summary:");
    puts("    -a  Do not consolidate events");
    puts("    -c  Clear screen before execution");
    puts("    -d  Track files added or removed from directories");
    puts("    -n  Non-interactive mode");
    puts("    -p  Wait for first event");
    puts("    -r  Run as a background process, use signal to restart");
    puts("    -s  Evaluate using a shell");
    puts("    -x  Format exit status");
    puts("    -z  Exit after the utility completes");
    puts("docs:");
    puts("    man entr");
    puts("release: 5.7");
    puts("usage: entr [-acdnprsxz] utility [argument [/_] ...] < filenames");
}

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) {
        perror("strdup");
        exit(1);
    }
    return p;
}

static char *dirname_dup(const char *path) {
    char *s = xstrdup(path);
    char *slash = strrchr(s, '/');
    if (!slash) {
        free(s);
        return xstrdup(".");
    }
    if (slash == s) {
        slash[1] = '\0';
        return s;
    }
    *slash = '\0';
    return s;
}

static char *basename_dup(const char *path) {
    const char *slash = strrchr(path, '/');
    return xstrdup(slash ? slash + 1 : path);
}

static char *absolute_path(const char *path) {
    char buf[PATH_MAX];
    if (realpath(path, buf))
        return xstrdup(buf);
    if (path[0] == '/')
        return xstrdup(path);
    char cwd[PATH_MAX];
    if (!getcwd(cwd, sizeof(cwd)))
        return xstrdup(path);
    char *out = NULL;
    if (asprintf(&out, "%s/%s", cwd, path) < 0)
        exit(1);
    return out;
}

static void clear_screen(int level) {
    if (level <= 0)
        return;
    if (level >= 2)
        fputs("\033[3J", stdout);
    fputs("\033[H\033[2J", stdout);
    fflush(stdout);
}

static int signal_number_from_env(void) {
    const char *s = getenv("ENTR_RESTART_SIGNAL");
    if (!s || !*s)
        return SIGTERM;
    if (!strcasecmp(s, "HUP") || !strcasecmp(s, "SIGHUP")) return SIGHUP;
    if (!strcasecmp(s, "INT") || !strcasecmp(s, "SIGINT")) return SIGINT;
    if (!strcasecmp(s, "QUIT") || !strcasecmp(s, "SIGQUIT")) return SIGQUIT;
    if (!strcasecmp(s, "TERM") || !strcasecmp(s, "SIGTERM")) return SIGTERM;
    if (!strcasecmp(s, "USR1") || !strcasecmp(s, "SIGUSR1")) return SIGUSR1;
    if (!strcasecmp(s, "USR2") || !strcasecmp(s, "SIGUSR2")) return SIGUSR2;
    return SIGTERM;
}

static char **build_argv(int argc, char **argv, int shell_mode, const char *file_name) {
    if (shell_mode) {
        const char *shell = getenv("SHELL");
        if (!shell || !*shell)
            shell = "/bin/sh";
        char **v = calloc(5, sizeof(char *));
        if (!v) exit(1);
        v[0] = (char *)shell;
        v[1] = "-c";
        v[2] = argv[0];
        v[3] = (char *)file_name;
        v[4] = NULL;
        return v;
    }

    char **v = calloc((size_t)argc + 1, sizeof(char *));
    if (!v) exit(1);
    for (int i = 0; i < argc; i++)
        v[i] = !strcmp(argv[i], "/_") ? (char *)file_name : argv[i];
    v[argc] = NULL;
    return v;
}

static int wait_for_child(pid_t pid) {
    int st;
    for (;;) {
        if (waitpid(pid, &st, 0) == pid)
            break;
        if (errno == EINTR)
            continue;
        return 1;
    }
    child_pid = -1;
    child_pgid = -1;
    if (WIFEXITED(st))
        return WEXITSTATUS(st);
    if (WIFSIGNALED(st))
        return 128 + WTERMSIG(st);
    return 1;
}

static pid_t start_child(int argc, char **argv, int shell_mode, const char *file_name,
                         int clear_level, int restart_mode) {
    clear_screen(clear_level);
    char **v = build_argv(argc, argv, shell_mode, file_name);
    pid_t pid = fork();
    if (pid < 0) {
        warnx("fork: %s", strerror(errno));
        free(v);
        return -1;
    }
    if (pid == 0) {
        signal(SIGINT, SIG_DFL);
        signal(SIGTERM, SIG_DFL);
        signal(SIGQUIT, SIG_DFL);
        signal(SIGCHLD, SIG_DFL);
        if (restart_mode)
            setpgid(0, 0);
        execvp(v[0], v);
        fprintf(stderr, "%s: %s: %s\n", prog, v[0], strerror(errno));
        _exit(127);
    }
    if (restart_mode) {
        setpgid(pid, pid);
        child_pgid = pid;
    }
    child_pid = pid;
    free(v);
    return pid;
}

static int run_sync(int argc, char **argv, int shell_mode, const char *file_name,
                    int clear_level) {
    pid_t pid = start_child(argc, argv, shell_mode, file_name, clear_level, 0);
    if (pid < 0)
        return 1;
    return wait_for_child(pid);
}

static int read_watch_list(Watch **out) {
    Watch *watches = NULL;
    size_t cap = 0, n = 0;
    char *line = NULL;
    size_t len = 0;
    while (getline(&line, &len, stdin) != -1) {
        size_t l = strlen(line);
        while (l && (line[l - 1] == '\n' || line[l - 1] == '\r'))
            line[--l] = '\0';
        if (l == 0)
            continue;
        struct stat st;
        if (stat(line, &st) != 0) {
            warnx("unable to stat '%s'", line);
            continue;
        }
        if (!S_ISREG(st.st_mode) && !S_ISDIR(st.st_mode))
            continue;
        if (n == cap) {
            cap = cap ? cap * 2 : 16;
            watches = realloc(watches, cap * sizeof(*watches));
            if (!watches) exit(1);
        }
        watches[n].input = xstrdup(line);
        watches[n].abs = absolute_path(line);
        watches[n].dir = dirname_dup(watches[n].abs);
        watches[n].base = basename_dup(watches[n].abs);
        watches[n].is_dir = S_ISDIR(st.st_mode);
        watches[n].wd = -1;
        n++;
    }
    free(line);
    *out = watches;
    return (int)n;
}

static int add_watches(int fd, Watch *watches, int count, int dir_mode) {
    uint32_t filemask = IN_CLOSE_WRITE | IN_MODIFY | IN_ATTRIB | IN_MOVED_FROM |
                        IN_MOVED_TO | IN_CREATE | IN_DELETE | IN_DELETE_SELF |
                        IN_MOVE_SELF;
    for (int i = 0; i < count; i++) {
        const char *target = (dir_mode || watches[i].is_dir) ? watches[i].abs : watches[i].abs;
        watches[i].wd = inotify_add_watch(fd, target, filemask);
        if (watches[i].wd < 0) {
            warnx("unable to watch '%s': %s", watches[i].input, strerror(errno));
            return -1;
        }
        if (dir_mode && !watches[i].is_dir) {
            int wd = inotify_add_watch(fd, watches[i].dir, filemask);
            if (wd >= 0)
                watches[i].wd = wd;
        }
    }
    return 0;
}

static const char *file_for_event(Watch *watches, int count, int wd, const char *name,
                                  uint32_t mask, int dir_mode, int d_twice, int *dir_changed) {
    for (int i = 0; i < count; i++) {
        if (watches[i].wd != wd)
            continue;
        if (dir_mode || watches[i].is_dir) {
            if (name && *name) {
                if (!d_twice && name[0] == '.')
                    return NULL;
                if (dir_changed && (mask & (IN_CREATE | IN_DELETE | IN_MOVED_FROM | IN_MOVED_TO)))
                    *dir_changed = 1;
                static char path[PATH_MAX];
                snprintf(path, sizeof(path), "%s/%s", watches[i].is_dir ? watches[i].abs : watches[i].dir, name);
                return path;
            }
            return watches[i].input;
        }
        return watches[i].input;
    }
    return count > 0 ? watches[0].input : "";
}

int main(int argc, char **argv) {
    if (argc > 0) {
        const char *slash = strrchr(argv[0], '/');
        prog = slash ? slash + 1 : argv[0];
    }

    int opt;
    int opt_a = 0, clear_level = 0, dir_mode = 0, noninteractive = 0;
    int postpone = 0, restart_mode = 0, shell_mode = 0, opt_x = 0, exit_after = 0;
    opterr = 0;
    while ((opt = getopt(argc, argv, "acdnprsxzh")) != -1) {
        switch (opt) {
        case 'a': opt_a = 1; break;
        case 'c': clear_level++; break;
        case 'd': dir_mode++; break;
        case 'n': noninteractive = 1; break;
        case 'p': postpone = 1; break;
        case 'r': restart_mode = 1; break;
        case 's': shell_mode = 1; break;
        case 'x': opt_x++; break;
        case 'z': exit_after = 1; break;
        case 'h': help(); return 0;
        default:
            fprintf(stderr, "%s: invalid option -- '%c'\n", argv[0], optopt ? optopt : '?');
            usage();
            return 1;
        }
    }
    (void)opt_a;
    (void)opt_x;

    int cmd_argc = argc - optind;
    char **cmd_argv = argv + optind;
    if (cmd_argc <= 0) {
        usage();
        return 1;
    }
    if (shell_mode && cmd_argc != 1) {
        warnx("-s requires commands to be formatted as a single argument");
        return 1;
    }
    if (!noninteractive) {
        struct termios t;
        if (tcgetattr(STDIN_FILENO, &t) != 0 && !isatty(STDIN_FILENO)) {
            warnx("unable to get terminal attributes, use '-n' to run non-interactively");
            return 1;
        }
    }

    Watch *watches = NULL;
    int watch_count = read_watch_list(&watches);
    if (watch_count <= 0) {
        warnx("No regular files to watch");
        return 1;
    }
    const char *default_file = watches[0].input;

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);
    signal(SIGCHLD, on_signal);

    if (!postpone) {
        if (restart_mode) {
            start_child(cmd_argc, cmd_argv, shell_mode, default_file, clear_level, 1);
            if (exit_after && child_pid > 0)
                return wait_for_child(child_pid);
        } else {
            int st = run_sync(cmd_argc, cmd_argv, shell_mode, default_file, clear_level);
            if (exit_after)
                return st;
        }
    }

    int fd = inotify_init1(IN_NONBLOCK | IN_CLOEXEC);
    if (fd < 0) {
        warnx("inotify_init: %s", strerror(errno));
        return 1;
    }
    if (add_watches(fd, watches, watch_count, dir_mode) != 0)
        return 1;

    while (!stop_requested) {
        fd_set rfds;
        FD_ZERO(&rfds);
        FD_SET(fd, &rfds);
        int maxfd = fd;
        if (!noninteractive) {
            FD_SET(STDIN_FILENO, &rfds);
            if (STDIN_FILENO > maxfd) maxfd = STDIN_FILENO;
        }
        int r = select(maxfd + 1, &rfds, NULL, NULL, NULL);
        if (r < 0) {
            if (errno == EINTR)
                continue;
            break;
        }
        const char *trigger = NULL;
        int dir_changed = 0;
        if (!noninteractive && FD_ISSET(STDIN_FILENO, &rfds)) {
            char ch;
            if (read(STDIN_FILENO, &ch, 1) == 1) {
                if (ch == 'q')
                    break;
                if (ch == ' ')
                    trigger = default_file;
            }
        }
        if (FD_ISSET(fd, &rfds)) {
            char buf[8192] __attribute__((aligned(__alignof__(struct inotify_event))));
            ssize_t len;
            while ((len = read(fd, buf, sizeof(buf))) > 0) {
                for (char *p = buf; p < buf + len; ) {
                    struct inotify_event *ev = (struct inotify_event *)p;
                    const char *name = ev->len ? ev->name : NULL;
                    const char *f = file_for_event(watches, watch_count, ev->wd, name, ev->mask, dir_mode, dir_mode > 1, &dir_changed);
                    if (f && !trigger)
                        trigger = f;
                    p += sizeof(struct inotify_event) + ev->len;
                }
            }
        }
        if (!trigger)
            continue;

        if (restart_mode && child_pid > 0) {
            int sig = signal_number_from_env();
            if (child_pgid > 0)
                kill(-child_pgid, sig);
            else
                kill(child_pid, sig);
            wait_for_child(child_pid);
        }
        if (restart_mode) {
            start_child(cmd_argc, cmd_argv, shell_mode, trigger, clear_level, 1);
            if (exit_after && child_pid > 0)
                return wait_for_child(child_pid);
        } else {
            int st = run_sync(cmd_argc, cmd_argv, shell_mode, trigger, clear_level);
            if (exit_after)
                return st;
        }
        if (dir_changed)
            return 2;
    }
    if (child_pid > 0) {
        if (child_pgid > 0)
            kill(-child_pgid, SIGTERM);
        else
            kill(child_pid, SIGTERM);
        wait_for_child(child_pid);
    }
    return 0;
}
