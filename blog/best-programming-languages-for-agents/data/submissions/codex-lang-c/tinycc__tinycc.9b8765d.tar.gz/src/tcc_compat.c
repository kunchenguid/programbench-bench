#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    char **v;
    int n;
    int cap;
} Vec;

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s);
    if (!r) die("out of memory");
    return r;
}

static void push(Vec *a, const char *s) {
    if (a->n == a->cap) {
        a->cap = a->cap ? a->cap * 2 : 32;
        a->v = realloc(a->v, (size_t)a->cap * sizeof(char *));
        if (!a->v) die("out of memory");
    }
    a->v[a->n++] = s ? xstrdup(s) : NULL;
}

static void push_owned(Vec *a, char *s) {
    if (a->n == a->cap) {
        a->cap = a->cap ? a->cap * 2 : 32;
        a->v = realloc(a->v, (size_t)a->cap * sizeof(char *));
        if (!a->v) die("out of memory");
    }
    a->v[a->n++] = s;
}

static void free_vec(Vec *a) {
    for (int i = 0; i < a->n; i++) free(a->v[i]);
    free(a->v);
}

static void print_help(void) {
    puts("Tiny C Compiler 0.9.28rc - Copyright (C) 2001-2006 Fabrice Bellard");
    puts("Usage: tcc [options...] [-o outfile] [-c] infile(s)...");
    puts("       tcc [options...] -run infile (or --) [arguments...]");
    puts("General options:");
    puts("  -c           compile only - generate an object file");
    puts("  -o outfile   set output filename");
    puts("  -run         run compiled source [with custom stdin: -rstdin FILE]");
    puts("  -fflag       set or reset (with 'no-' prefix) 'flag' (see tcc -hh)");
    puts("  -Wwarning    set or reset (with 'no-' prefix) 'warning' (see tcc -hh)");
    puts("  -w           disable all warnings");
    puts("  -v --version show version");
    puts("  -vv          show search paths or loaded files");
    puts("  -h -hh       show this, show more help");
    puts("  -bench       show compilation statistics");
    puts("  -            use stdin pipe as infile");
    puts("  @listfile    read arguments from listfile");
    puts("Preprocessor options:");
    puts("  -Idir        add include path 'dir'");
    puts("  -Dsym[=val]  define 'sym' with value 'val'");
    puts("  -Usym        undefine 'sym'");
    puts("  -E           preprocess only");
    puts("  -nostdinc    do not use standard system include paths");
    puts("Linker options:");
    puts("  -Ldir        add library path 'dir'");
    puts("  -llib        link with dynamic or static library 'lib'");
    puts("  -nostdlib    do not link with standard crt and libraries");
    puts("  -r           generate (relocatable) object file");
    puts("  -rdynamic    export all global symbols to dynamic linker");
    puts("  -shared      generate a shared library/dll");
    puts("  -soname      set name for shared library to be used at runtime");
    puts("  -Wl,-opt[=val]  set linker option (see tcc -hh)");
    puts("Debugger options:");
    puts("  -g           generate stab runtime debug info");
    puts("  -gdwarf[-x]  generate dwarf runtime debug info");
    puts("  -b           compile with built-in memory and bounds checker (implies -g)");
    puts("  -bt[N]       link with backtrace (stack dump) support [show max N callers]");
    puts("Misc. options:");
    puts("  -std=version define __STDC_VERSION__ according to version (c11/gnu11)");
    puts("  -x[c|a|b|n]  specify type of the next infile (C,ASM,BIN,NONE)");
    puts("  -Bdir        set tcc's private include/library dir");
    puts("  -M[M]D       generate make dependency file [ignore system files]");
    puts("  -M[M]        as above but no other output");
    puts("  -MF file     specify dependency file name");
    puts("  -m32/64      defer to i386/x86_64 cross compiler");
    puts("Tools:");
    puts("  create library  : tcc -ar [crstvx] lib [files]");
    puts("Discussion & bug reports:");
    puts("  https://lists.nongnu.org/mailman/listinfo/tinycc-devel");
}

static void print_more_help(void) {
    puts("Tiny C Compiler 0.9.28rc - More Options");
    puts("Special options:");
    puts("  -P -P1                        with -E: no/alternative #line output");
    puts("  -dD -dM                       with -E: output #define directives");
    puts("  -pthread                      same as -D_REENTRANT and -lpthread");
    puts("  -On                           same as -D__OPTIMIZE__ for n > 0");
    puts("  -Wp,-opt                      same as -opt");
    puts("  -include file                 include 'file' above each input file");
    puts("  -nostdlib                     do not link with standard crt/libs");
    puts("  -isystem dir                  add 'dir' to system include path");
    puts("  -static                       link to static libraries (not recommended)");
    puts("  -dumpversion                  print version");
    puts("  -print-search-dirs            print search paths");
    puts("Ignored options:");
    puts("  -arch -C --param -pedantic -pipe -s -traditional");
    puts("-W[no-]... warnings:");
    puts("  all                           turn on some (*) warnings");
    puts("  error[=warning]               stop after warning (any or specified)");
    puts("-f[no-]... flags:");
    puts("  unsigned-char                 default char is unsigned");
    puts("  signed-char                   default char is signed");
    puts("  common                        use common section instead of bss");
    puts("-Wl,... linker options:");
    puts("  -soname=                      set DT_SONAME elf tag");
    puts("Predefined macros:");
    puts("  tcc -E -dM - < /dev/null");
    puts("See also the manual for more details.");
}

static void print_version(void) {
    puts("tcc version 0.9.28rc 2026-04-21 build@237d0db* (x86_64 Linux)");
}

static void print_dirs(void) {
    puts("install: /usr/local/lib/tcc");
    puts("include:");
    puts("  /usr/local/lib/tcc/include");
    puts("  /usr/local/include/x86_64-linux-gnu");
    puts("  /usr/local/include");
    puts("  /usr/include/x86_64-linux-gnu");
    puts("  /usr/include");
    puts("libraries:");
    puts("  /usr/local/lib/tcc");
    puts("  /usr/lib/x86_64-linux-gnu");
    puts("  /usr/lib");
    puts("  /lib/x86_64-linux-gnu");
    puts("  /lib");
    puts("  /usr/local/lib/x86_64-linux-gnu");
    puts("  /usr/local/lib");
    puts("libtcc1:");
    puts("  /usr/local/lib/tcc/libtcc1.a");
    puts("crt:");
    puts("  /usr/lib/x86_64-linux-gnu");
    puts("elfinterp:");
    puts("  /lib64/ld-linux-x86-64.so.2");
}

static int run_cmd(Vec *args) {
    push(args, NULL);
    pid_t p = fork();
    if (p < 0) die("fork: %s", strerror(errno));
    if (p == 0) {
        execvp(args->v[0], args->v);
        fprintf(stderr, "tcc: could not execute %s: %s\n", args->v[0], strerror(errno));
        _exit(127);
    }
    int st = 0;
    if (waitpid(p, &st, 0) < 0) die("waitpid: %s", strerror(errno));
    if (WIFEXITED(st)) return WEXITSTATUS(st);
    if (WIFSIGNALED(st)) return 128 + WTERMSIG(st);
    return 1;
}

static char *read_listfile(const char *path, Vec *out) {
    FILE *f = fopen(path, "r");
    if (!f) return NULL;
    int c;
    char buf[4096];
    int n = 0;
    bool quote = false;
    while ((c = fgetc(f)) != EOF) {
        if (c == '"') {
            quote = !quote;
        } else if (!quote && (c == ' ' || c == '\t' || c == '\n' || c == '\r')) {
            if (n) {
                buf[n] = 0;
                push(out, buf);
                n = 0;
            }
        } else if (n < (int)sizeof(buf) - 1) {
            buf[n++] = (char)c;
        }
    }
    if (n) {
        buf[n] = 0;
        push(out, buf);
    }
    fclose(f);
    return (char *)1;
}

static void expand_args(int argc, char **argv, Vec *out) {
    for (int i = 1; i < argc; i++) {
        if (argv[i][0] == '@' && argv[i][1]) {
            if (!read_listfile(argv[i] + 1, out)) push(out, argv[i]);
        } else {
            push(out, argv[i]);
        }
    }
}

static bool starts(const char *s, const char *p) {
    return strncmp(s, p, strlen(p)) == 0;
}

static char *join2(const char *a, const char *b) {
    size_t na = strlen(a), nb = strlen(b);
    char *r = malloc(na + nb + 1);
    if (!r) die("out of memory");
    memcpy(r, a, na);
    memcpy(r + na, b, nb + 1);
    return r;
}

static const char *maybe_sanitize_shebang(const char *path, Vec *temps) {
    FILE *in = fopen(path, "r");
    if (!in) return path;
    int c1 = fgetc(in), c2 = fgetc(in);
    if (c1 != '#' || c2 != '!') {
        fclose(in);
        return path;
    }
    char tmpl[] = "/tmp/tccsrcXXXXXX.c";
    int fd = mkstemps(tmpl, 2);
    if (fd < 0) {
        fclose(in);
        return path;
    }
    FILE *out = fdopen(fd, "w");
    if (!out) {
        close(fd);
        fclose(in);
        unlink(tmpl);
        return path;
    }
    int c;
    while ((c = fgetc(in)) != EOF && c != '\n') {
    }
    fputc('\n', out);
    while ((c = fgetc(in)) != EOF) fputc(c, out);
    fclose(in);
    fclose(out);
    push(temps, tmpl);
    return temps->v[temps->n - 1];
}

static void translate_wl(Vec *gcc, const char *arg) {
    if (strcmp(arg, "-soname") == 0) {
        push(gcc, "-Wl,-soname");
    } else if (starts(arg, "-soname=")) {
        push_owned(gcc, join2("-Wl,", arg));
    } else {
        push(gcc, arg);
    }
}

int main(int argc, char **argv) {
    Vec args = {0}, gcc = {0}, run_argv = {0}, temps = {0};
    expand_args(argc, argv, &args);
    if (args.n == 0) {
        print_help();
        return 0;
    }

    bool run = false, preprocess = false, compile_only = false, verbose_paths = false;
    bool seen_input = false, stop_opts = false, make_ar = false;
    const char *outfile = NULL, *run_stdin = NULL;

    for (int i = 0; i < args.n; i++) {
        const char *a = args.v[i];
        if (run && seen_input) {
            push(&run_argv, a);
            continue;
        }
        if (!stop_opts && strcmp(a, "--") == 0) {
            if (run) {
                stop_opts = true;
                continue;
            }
            push(&gcc, a);
            continue;
        }
        if (!stop_opts && (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0)) {
            print_help();
            return 0;
        }
        if (!stop_opts && strcmp(a, "-hh") == 0) {
            print_more_help();
            return 0;
        }
        if (!stop_opts && (strcmp(a, "-v") == 0 || strcmp(a, "--version") == 0)) {
            print_version();
            return 0;
        }
        if (!stop_opts && strcmp(a, "-vv") == 0) {
            print_version();
            print_dirs();
            return 0;
        }
        if (!stop_opts && strcmp(a, "-dumpversion") == 0) {
            puts("0.9.28rc");
            return 0;
        }
        if (!stop_opts && strcmp(a, "-print-search-dirs") == 0) {
            print_dirs();
            return 0;
        }
        if (!stop_opts && strcmp(a, "-run") == 0) {
            run = true;
            continue;
        }
        if (!stop_opts && strcmp(a, "-rstdin") == 0 && i + 1 < args.n) {
            run_stdin = args.v[++i];
            continue;
        }
        if (!stop_opts && strcmp(a, "-o") == 0 && i + 1 < args.n) {
            outfile = args.v[++i];
            push(&gcc, "-o");
            push(&gcc, outfile);
            continue;
        }
        if (!stop_opts && starts(a, "-o") && a[2]) {
            outfile = a + 2;
            push(&gcc, a);
            continue;
        }
        if (!stop_opts && strcmp(a, "-c") == 0) compile_only = true;
        if (!stop_opts && strcmp(a, "-E") == 0) preprocess = true;
        if (!stop_opts && strcmp(a, "-ar") == 0) {
            make_ar = true;
            continue;
        }
        if (!stop_opts && (strcmp(a, "-bench") == 0 || strcmp(a, "-bt") == 0 || starts(a, "-bt") ||
                           strcmp(a, "-b") == 0 || strcmp(a, "-dt") == 0 || strcmp(a, "-P1") == 0)) {
            if (strcmp(a, "-P1") == 0) push(&gcc, "-P");
            continue;
        }
        if (!stop_opts && starts(a, "-Wp,")) {
            push(&gcc, a + 4);
            continue;
        }
        if (!stop_opts && strcmp(a, "-pthread") == 0) {
            push(&gcc, "-pthread");
            continue;
        }
        if (!stop_opts && starts(a, "-gdwarf")) {
            push(&gcc, "-g");
            continue;
        }
        if (!stop_opts && starts(a, "-std=")) {
            if (strcmp(a + 5, "c11") == 0 || strcmp(a + 5, "gnu11") == 0 || strcmp(a + 5, "c99") == 0 ||
                strcmp(a + 5, "gnu99") == 0 || strcmp(a + 5, "c89") == 0 || strcmp(a + 5, "gnu89") == 0)
                push(&gcc, a);
            continue;
        }
        if (!stop_opts && strcmp(a, "-soname") == 0 && i + 1 < args.n) {
            push(&gcc, "-Wl,-soname");
            push(&gcc, args.v[++i]);
            continue;
        }
        if (!stop_opts && starts(a, "-Wl,")) {
            push(&gcc, a);
            continue;
        }
        if (!stop_opts && a[0] == '-' && a[1] && strchr("IDULlmfWOgxB", a[1])) {
            push(&gcc, a);
            if ((strcmp(a, "-I") == 0 || strcmp(a, "-D") == 0 || strcmp(a, "-U") == 0 ||
                 strcmp(a, "-L") == 0 || strcmp(a, "-l") == 0 || strcmp(a, "-x") == 0 ||
                 strcmp(a, "-B") == 0 || strcmp(a, "-include") == 0 || strcmp(a, "-isystem") == 0 ||
                 strcmp(a, "-MF") == 0 || strcmp(a, "-MT") == 0 || strcmp(a, "-MQ") == 0) && i + 1 < args.n) {
                push(&gcc, args.v[++i]);
            }
            continue;
        }
        if (!stop_opts && (strcmp(a, "-shared") == 0 || strcmp(a, "-static") == 0 ||
                           strcmp(a, "-nostdinc") == 0 || strcmp(a, "-nostdlib") == 0 ||
                           strcmp(a, "-rdynamic") == 0 || strcmp(a, "-r") == 0 ||
                           strcmp(a, "-MD") == 0 || strcmp(a, "-MMD") == 0 ||
                           strcmp(a, "-M") == 0 || strcmp(a, "-MM") == 0 ||
                           strcmp(a, "-P") == 0 || strcmp(a, "-dD") == 0 || strcmp(a, "-dM") == 0)) {
            translate_wl(&gcc, a);
            continue;
        }
        if (!stop_opts && (strcmp(a, "-w") == 0 || strcmp(a, "-Wall") == 0 || starts(a, "-Werror") ||
                           starts(a, "-Wno-") || starts(a, "-f") || starts(a, "-m"))) {
            push(&gcc, a);
            continue;
        }
        if (!stop_opts && (strcmp(a, "-C") == 0 || strcmp(a, "-pipe") == 0 || strcmp(a, "-s") == 0 ||
                           strcmp(a, "-pedantic") == 0 || strcmp(a, "-traditional") == 0 ||
                           strcmp(a, "-arch") == 0 || strcmp(a, "--param") == 0)) {
            if ((strcmp(a, "-arch") == 0 || strcmp(a, "--param") == 0) && i + 1 < args.n) i++;
            continue;
        }
        if (strcmp(a, "-") == 0) {
            push(&gcc, "-x");
            push(&gcc, "c");
            push(&gcc, "-");
            seen_input = true;
            continue;
        }
        if (a[0] != '-') {
            a = maybe_sanitize_shebang(a, &temps);
        }
        push(&gcc, a);
        if (a[0] != '-') seen_input = true;
    }

    if (make_ar) {
        Vec ar = {0};
        push(&ar, "ar");
        for (int i = 0; i < gcc.n; i++) push(&ar, gcc.v[i]);
        int rc = run_cmd(&ar);
        free_vec(&ar);
        return rc;
    }

    if (!seen_input && !preprocess) {
        fputs("tcc: no input files\n", stderr);
        return 1;
    }

    if (run) {
        char tmpl[] = "/tmp/tccrunXXXXXX";
        int fd = mkstemp(tmpl);
        if (fd < 0) die("mkstemp: %s", strerror(errno));
        close(fd);
        unlink(tmpl);
        Vec cg = {0};
        push(&cg, "gcc");
        push(&cg, "-std=gnu99");
        push(&cg, "-D__TINYC__=928");
        push(&cg, "-o");
        push(&cg, tmpl);
        for (int i = 0; i < gcc.n; i++) {
            if (strcmp(gcc.v[i], "-o") == 0 && i + 1 < gcc.n) {
                i++;
                continue;
            }
            push(&cg, gcc.v[i]);
        }
        int rc = run_cmd(&cg);
        free_vec(&cg);
        if (rc != 0) {
            unlink(tmpl);
            return rc;
        }
        Vec rg = {0};
        push(&rg, tmpl);
        for (int i = 0; i < run_argv.n; i++) push(&rg, run_argv.v[i]);
        if (run_stdin) {
            pid_t p = fork();
            if (p < 0) die("fork: %s", strerror(errno));
            if (p == 0) {
                int in = open(run_stdin, O_RDONLY);
                if (in < 0) {
                    fprintf(stderr, "tcc: could not open %s: %s\n", run_stdin, strerror(errno));
                    _exit(1);
                }
                dup2(in, STDIN_FILENO);
                close(in);
                push(&rg, NULL);
                execv(tmpl, rg.v);
                _exit(127);
            }
            int st = 0;
            waitpid(p, &st, 0);
            rc = WIFEXITED(st) ? WEXITSTATUS(st) : 1;
        } else {
            rc = run_cmd(&rg);
        }
        unlink(tmpl);
        for (int i = 0; i < temps.n; i++) unlink(temps.v[i]);
        free_vec(&rg);
        return rc;
    }

    Vec cg = {0};
    push(&cg, "gcc");
    push(&cg, "-std=gnu99");
    push(&cg, "-D__TINYC__=928");
    for (int i = 0; i < gcc.n; i++) push(&cg, gcc.v[i]);
    if (!outfile && !compile_only && !preprocess) {
        /* TCC's default output is a.out, the same as GCC. */
    }
    int rc = run_cmd(&cg);
    for (int i = 0; i < temps.n; i++) unlink(temps.v[i]);
    free_vec(&cg);
    free_vec(&args);
    free_vec(&gcc);
    free_vec(&run_argv);
    free_vec(&temps);
    (void)verbose_paths;
    return rc;
}
