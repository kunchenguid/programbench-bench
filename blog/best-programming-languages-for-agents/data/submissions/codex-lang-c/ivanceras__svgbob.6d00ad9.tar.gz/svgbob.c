#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <glob.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct {
    char **v;
    int n;
    int maxw;
} Lines;

typedef struct {
    const char *background;
    const char *fill;
    const char *stroke;
    const char *font;
    double font_size;
    double stroke_width;
    double scale;
    const char *output;
    int inline_mode;
} Opt;

static char *read_stream(FILE *f) {
    size_t cap = 4096, len = 0;
    char *buf = malloc(cap);
    if (!buf) exit(1);
    for (;;) {
        if (len + 2048 >= cap) {
            cap *= 2;
            buf = realloc(buf, cap);
            if (!buf) exit(1);
        }
        size_t n = fread(buf + len, 1, cap - len - 1, f);
        len += n;
        if (n == 0) break;
    }
    buf[len] = 0;
    return buf;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "Failed to open input file %s: %s (os error %d)\n", path, strerror(errno), errno);
        exit(1);
    }
    char *s = read_stream(f);
    fclose(f);
    return s;
}

static char *decode_inline(const char *s) {
    size_t n = strlen(s);
    char *out = malloc(n + 1);
    if (!out) exit(1);
    size_t j = 0;
    for (size_t i = 0; i < n; i++) {
        if (s[i] == '\\' && s[i + 1] == 'n') {
            out[j++] = '\n';
            i++;
        } else if (s[i] == '\\' && s[i + 1] == 't') {
            out[j++] = '\t';
            i++;
        } else {
            out[j++] = s[i];
        }
    }
    out[j] = 0;
    return out;
}

static Lines split_lines(char *text) {
    Lines l = {0};
    int cap = 8;
    l.v = calloc(cap, sizeof(char *));
    if (!l.v) exit(1);
    char *start = text;
    for (char *p = text;; p++) {
        if (*p == '\r') *p = '\n';
        if (*p == '\n' || *p == 0) {
            char save = *p;
            *p = 0;
            if (!(save == 0 && p == start && l.n > 0)) {
                if (l.n == cap) {
                    cap *= 2;
                    l.v = realloc(l.v, cap * sizeof(char *));
                    if (!l.v) exit(1);
                }
                l.v[l.n++] = start;
                int w = (int)strlen(start);
                if (w > l.maxw) l.maxw = w;
            }
            if (save == 0) break;
            start = p + 1;
        }
    }
    while (l.n > 0 && l.v[l.n - 1][0] == 0) l.n--;
    if (l.n == 0) {
        l.n = 1;
        l.v[0] = "";
    }
    return l;
}

static char at(Lines *l, int r, int c) {
    if (r < 0 || r >= l->n || c < 0) return ' ';
    int len = (int)strlen(l->v[r]);
    if (c >= len) return ' ';
    return l->v[r][c];
}

static void esc(FILE *out, const char *s, int n) {
    for (int i = 0; i < n; i++) {
        unsigned char c = (unsigned char)s[i];
        if (c == '&') fputs("&amp;", out);
        else if (c == '<') fputs("&lt;", out);
        else if (c == '>') fputs("&gt;", out);
        else if (c == '"') fputs("&quot;", out);
        else if (c == '\'') fputs("&#39;", out);
        else fputc(c, out);
    }
}

static int num(double x) {
    if (x < 0) return (int)(x - 0.000001);
    return (int)(x + 0.000001);
}

static void svg_header(FILE *o, Opt *opt, int width, int height) {
    double s = opt->scale;
    fprintf(o, "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"%d\" height=\"%d\" class=\"svgbob\">\n", num(width * s), num(height * s));
    fprintf(o, "  <style>.svgbob line, .svgbob path, .svgbob circle, .svgbob rect, .svgbob polygon {\n");
    fprintf(o, "  stroke: %s;\n  stroke-width: %g;\n  stroke-opacity: 1;\n  fill-opacity: 1;\n  stroke-linecap: round;\n  stroke-linejoin: miter;\n}\n\n", opt->stroke, opt->stroke_width);
    fprintf(o, ".svgbob text {\n  white-space: pre;\n  fill: %s;\n  font-family: %s;\n  font-size: %gpx;\n}\n\n", opt->stroke, opt->font, opt->font_size);
    fprintf(o, ".svgbob rect.backdrop {\n  stroke: none;\n  fill: %s;\n}\n\n", opt->background);
    fprintf(o, ".svgbob .broken {\n  stroke-dasharray: 8;\n}\n\n");
    fprintf(o, ".svgbob .filled {\n  fill: %s;\n}\n\n", opt->fill);
    fprintf(o, ".svgbob .bg_filled {\n  fill: %s;\n  stroke-width: 1;\n}\n\n", opt->background);
    fprintf(o, ".svgbob .nofill {\n  fill: %s;\n}\n\n", opt->background);
    fprintf(o, ".svgbob .end_marked_arrow {\n  marker-end: url(#arrow);\n}\n\n.svgbob .start_marked_arrow {\n  marker-start: url(#arrow);\n}\n\n");
    fprintf(o, ".svgbob .end_marked_diamond {\n  marker-end: url(#diamond);\n}\n\n.svgbob .start_marked_diamond {\n  marker-start: url(#diamond);\n}\n\n");
    fprintf(o, ".svgbob .end_marked_circle {\n  marker-end: url(#circle);\n}\n\n.svgbob .start_marked_circle {\n  marker-start: url(#circle);\n}\n\n");
    fprintf(o, ".svgbob .end_marked_open_circle {\n  marker-end: url(#open_circle);\n}\n\n.svgbob .start_marked_open_circle {\n  marker-start: url(#open_circle);\n}\n\n");
    fprintf(o, ".svgbob .end_marked_big_open_circle {\n  marker-end: url(#big_open_circle);\n}\n\n.svgbob .start_marked_big_open_circle {\n  marker-start: url(#big_open_circle);\n}\n\n</style>\n");
    fprintf(o, "  <defs>\n");
    fprintf(o, "    <marker id=\"arrow\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <polygon points=\"0,0 0,4 4,2 0,0\"></polygon>\n    </marker>\n");
    fprintf(o, "    <marker id=\"diamond\" viewBox=\"-2 -2 8 8\" refX=\"4\" refY=\"2\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <polygon points=\"0,2 2,0 4,2 2,4 0,2\"></polygon>\n    </marker>\n");
    fprintf(o, "    <marker id=\"circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"filled\"></circle>\n    </marker>\n");
    fprintf(o, "    <marker id=\"open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"2\" class=\"bg_filled\"></circle>\n    </marker>\n");
    fprintf(o, "    <marker id=\"big_open_circle\" viewBox=\"0 0 8 8\" refX=\"4\" refY=\"4\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\">\n      <circle cx=\"4\" cy=\"4\" r=\"3\" class=\"bg_filled\"></circle>\n    </marker>\n  </defs>\n");
    fprintf(o, "  <rect class=\"backdrop\" x=\"0\" y=\"0\" width=\"%d\" height=\"%d\"></rect>\n", num(width * s), num(height * s));
}

static void line(FILE *o, Opt *opt, int x1, int y1, int x2, int y2) {
    double s = opt->scale;
    fprintf(o, "  <line x1=\"%d\" y1=\"%d\" x2=\"%d\" y2=\"%d\" class=\"solid\"></line>\n", num(x1*s), num(y1*s), num(x2*s), num(y2*s));
}

static void polygon_arrow(FILE *o, Opt *opt, int dir, int c, int r) {
    double s = opt->scale;
    int cy = r * 16 + 8;
    if (dir > 0) {
        int x = c * 8;
        fprintf(o, "  <polygon points=\"%d,%d %d,%d %d,%d\" class=\"filled\"></polygon>\n", num(x*s), num((cy-4)*s), num((x+8)*s), num(cy*s), num(x*s), num((cy+4)*s));
    } else {
        int x = c * 8 + 8;
        fprintf(o, "  <polygon points=\"%d,%d %d,%d %d,%d\" class=\"filled\"></polygon>\n", num(x*s), num((cy-4)*s), num((x-8)*s), num(cy*s), num(x*s), num((cy+4)*s));
    }
}

static void render(FILE *o, char *input, Opt *opt) {
    Lines l = split_lines(input);
    int width = (l.maxw + 1) * 8;
    int height = (l.n + 1) * 16;
    if (width < 8) width = 8;
    if (height < 16) height = 16;
    int cells = l.n * (l.maxw + 1);
    unsigned char *used = calloc(cells ? cells : 1, 1);
    if (!used) exit(1);
#define USED(r,c) used[(r) * (l.maxw + 1) + (c)]
    svg_header(o, opt, width, height);

    for (int r = 0; r < l.n; r++) {
        for (int c = 0; c < (int)strlen(l.v[r]); c++) {
            if (at(&l, r, c) != '+') continue;
            for (int c2 = c + 2; c2 < l.maxw; c2++) {
                if (at(&l, r, c2) != '+') continue;
                int top = 1;
                for (int k = c + 1; k < c2; k++) if (at(&l, r, k) != '-') top = 0;
                if (!top) continue;
                for (int r2 = r + 1; r2 < l.n; r2++) {
                    if (at(&l, r2, c) != '+' || at(&l, r2, c2) != '+') continue;
                    int ok = 1;
                    for (int rr = r + 1; rr < r2; rr++) if (at(&l, rr, c) != '|' || at(&l, rr, c2) != '|') ok = 0;
                    for (int k = c + 1; k < c2; k++) if (at(&l, r2, k) != '-') ok = 0;
                    if (!ok) continue;
                    double s = opt->scale;
                    fprintf(o, "  <rect x=\"%d\" y=\"%d\" width=\"%d\" height=\"%d\" class=\"solid nofill\" rx=\"0\"></rect>\n",
                            num((c*8+4)*s), num((r*16+8)*s), num(((c2-c)*8)*s), num(((r2-r)*16)*s));
                    for (int k = c; k <= c2; k++) USED(r,k)=USED(r2,k)=1;
                    for (int rr = r; rr <= r2; rr++) USED(rr,c)=USED(rr,c2)=1;
                    c = c2;
                    goto next_cell;
                }
            }
next_cell:;
        }
    }

    for (int r = 0; r < l.n; r++) {
        int len = (int)strlen(l.v[r]);
        for (int c = 0; c < len; c++) {
            if (USED(r,c)) continue;
            char ch = at(&l, r, c);
            if (ch == '<') {
                int j = c + 1;
                while (j < len && at(&l,r,j) == '-') j++;
                if (j > c + 1) {
                    polygon_arrow(o, opt, -1, c, r);
                    line(o, opt, (c+1)*8, r*16+8, j*8, r*16+8);
                    for (int k=c;k<j;k++) USED(r,k)=1;
                    c = j - 1;
                    continue;
                }
            }
            if (ch == '-') {
                int j = c;
                while (j < len && at(&l,r,j) == '-') j++;
                int arrow = (j < len && at(&l,r,j) == '>');
                line(o, opt, c*8, r*16+8, j*8, r*16+8);
                for (int k=c;k<j;k++) USED(r,k)=1;
                if (arrow) { polygon_arrow(o, opt, 1, j, r); USED(r,j)=1; c = j; }
                else c = j - 1;
            } else if (ch == '+') {
                int j = c + 1;
                while (j < len && at(&l,r,j) == '-') j++;
                if (j > c + 1 && j < len && at(&l,r,j) == '+') {
                    line(o, opt, c*8+4, r*16+8, j*8+4, r*16+8);
                    for (int k=c;k<=j;k++) USED(r,k)=1;
                    c = j;
                }
            }
        }
    }

    for (int c = 0; c < l.maxw; c++) {
        for (int r = 0; r < l.n; r++) {
            if (USED(r,c)) continue;
            char ch = at(&l, r, c);
            if (ch == '|') {
                int r2 = r;
                while (r2 < l.n && at(&l, r2, c) == '|' && !USED(r2,c)) r2++;
                if (r2 > r) {
                    line(o, opt, c*8+4, r*16, c*8+4, r2*16);
                    for (int rr=r; rr<r2; rr++) USED(rr,c)=1;
                    r = r2 - 1;
                }
            }
        }
    }

    for (int r = 0; r < l.n; r++) {
        int len = (int)strlen(l.v[r]);
        for (int c = 0; c < len; c++) {
            if (USED(r,c)) continue;
            char ch = at(&l, r, c);
            if (ch == '/') {
                line(o, opt, c*8+8, r*16, c*8, (r+1)*16);
                USED(r,c) = 1;
            } else if (ch == '\\') {
                line(o, opt, c*8, r*16, c*8+8, (r+1)*16);
                USED(r,c) = 1;
            }
        }
    }

    for (int r = 0; r < l.n; r++) {
        int len = (int)strlen(l.v[r]);
        for (int c = 0; c < len; c++) {
            if (USED(r,c) || at(&l,r,c) == ' ') continue;
            int j = c;
            while (j < len && !USED(r,j) && at(&l,r,j) != ' ') j++;
            double s = opt->scale;
            fprintf(o, "  <text x=\"%d\" y=\"%d\" >", num((c*8+2)*s), num((r*16+12)*s));
            esc(o, l.v[r] + c, j - c);
            fprintf(o, "</text>\n");
            c = j - 1;
        }
    }
    fprintf(o, "</svg>\n");
    free(used);
    free(l.v);
}

static void help(void) {
    puts("svgbob 0.7.6\nSvgBobRus is an ascii to svg converter\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]\n\nFLAGS:\n    -h, --help       Prints help information\n    -s               parse an inline string\n    -V, --version    Prints version information\n\nOPTIONS:\n        --background <background>        backdrop background will be filled with this color (default: 'white')\n        --fill-color <fill-color>        solid shapes will be filled with this color (default: 'black')\n        --font-family <font-family>      text will be rendered with this font (default: 'arial')\n        --font-size <font-size>          text will be rendered with this font size (default: 14)\n    -o, --output <output>                where to write svg output [default: STDOUT]\n        --scale <scale>                  scale the entire svg (dimensions, font size, stroke width) by this factor\n                                         (default: 1)\n        --stroke-color <stroke-color>    stroke color for all lines (default: 'black')\n        --stroke-width <stroke-width>    stroke width for all lines (default: 2)\n\nARGS:\n    <input>    svgbob text file or inline string to parse [default: STDIN]\n\nSUBCOMMANDS:\n    build    Batch convert files to svg.\n    help     Prints this message or the help of the given subcommand(s)");
}

static void build_help(void) {
    puts("executable-build 0.0.1\nBatch convert files to svg.\n\nUSAGE:\n    executable build [OPTIONS]\n\nFLAGS:\n    -h, --help       Prints help information\n    -V, --version    Prints version information\n\nOPTIONS:\n    -i, --input <input>      set input file pattern like: *.bob or dir/*.bob\n    -o, --outdir <outdir>    set dir of svg files");
}

static const char *basename2(const char *p) {
    const char *s = strrchr(p, '/');
    return s ? s + 1 : p;
}

static int run_build(int argc, char **argv, Opt opt) {
    const char *pat = NULL, *outdir = ".";
    for (int i = 2; i < argc; i++) {
        if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { build_help(); return 0; }
        if ((!strcmp(argv[i], "-V") || !strcmp(argv[i], "--version"))) { puts("executable-build 0.0.1"); return 0; }
        if ((!strcmp(argv[i], "-i") || !strcmp(argv[i], "--input")) && i + 1 < argc) pat = argv[++i];
        else if ((!strcmp(argv[i], "-o") || !strcmp(argv[i], "--outdir")) && i + 1 < argc) outdir = argv[++i];
    }
    if (!pat) pat = "*.bob";
    mkdir(outdir, 0777);
    glob_t g;
    if (glob(pat, 0, NULL, &g) != 0) return 0;
    for (size_t i = 0; i < g.gl_pathc; i++) {
        char *in = read_file(g.gl_pathv[i]);
        const char *base = basename2(g.gl_pathv[i]);
        char name[4096];
        snprintf(name, sizeof(name), "%s/%s", outdir, base);
        char *dot = strrchr(name, '.');
        if (dot) strcpy(dot, ".svg"); else strcat(name, ".svg");
        FILE *f = fopen(name, "wb");
        if (f) {
            render(f, in, &opt);
            fclose(f);
            printf("%s => %s\n", g.gl_pathv[i], name);
        }
        free(in);
    }
    globfree(&g);
    return 0;
}

int main(int argc, char **argv) {
    Opt opt = {"white", "black", "black", "Iosevka Fixed, monospace", 14, 2, 1, NULL, 0};
    if (argc > 1 && !strcmp(argv[1], "build")) return run_build(argc, argv, opt);
    const char *input_arg = NULL;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help") || !strcmp(a, "help")) { help(); return 0; }
        else if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("svgbob 0.7.6"); return 0; }
        else if (!strcmp(a, "-s") || !strcmp(a, "--inline")) opt.inline_mode = 1;
        else if (!strcmp(a, "-o") || !strcmp(a, "--output")) { if (i + 1 < argc) opt.output = argv[++i]; }
        else if (!strcmp(a, "--background")) { if (i + 1 < argc) opt.background = argv[++i]; }
        else if (!strcmp(a, "--fill-color")) { if (i + 1 < argc) opt.fill = argv[++i]; }
        else if (!strcmp(a, "--stroke-color")) { if (i + 1 < argc) opt.stroke = argv[++i]; }
        else if (!strcmp(a, "--font-family")) { if (i + 1 < argc) opt.font = argv[++i]; }
        else if (!strcmp(a, "--font-size")) { if (i + 1 < argc) opt.font_size = atof(argv[++i]); }
        else if (!strcmp(a, "--stroke-width")) { if (i + 1 < argc) opt.stroke_width = atof(argv[++i]); }
        else if (!strcmp(a, "--scale")) { if (i + 1 < argc) opt.scale = atof(argv[++i]); }
        else if (a[0] == '-' && strcmp(a, "-")) {
            fprintf(stderr, "error: Found argument '%s' which wasn't expected, or isn't valid in this context\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [input] [SUBCOMMAND]\n\nFor more information try --help\n", a);
            return 1;
        } else {
            input_arg = a;
        }
    }
    char *input;
    if (opt.inline_mode && input_arg) input = decode_inline(input_arg);
    else if (input_arg) input = read_file(input_arg);
    else input = read_stream(stdin);
    FILE *out = stdout;
    if (opt.output && strcmp(opt.output, "STDOUT")) {
        out = fopen(opt.output, "wb");
        if (!out) { perror(opt.output); return 1; }
    }
    render(out, input, &opt);
    if (out != stdout) fclose(out);
    free(input);
    return 0;
}
