#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <dlfcn.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <zlib.h>

typedef struct { unsigned char r,g,b,a; } Pixel;
typedef struct { int w,h; Pixel *p; } Image;
typedef struct { int sx, sy; } gdImageHead;
typedef struct {
    int dither, scale, go, nobg, tc, tr;
    Pixel matte;
    const char *path;
} Opt;

static const char *banner =
"   ___  _____  ____\n"
"  / _ \\/  _/ |/_/ /____ ______ _      Made with love by Eliuk Blau\n"
" / ___// /_>  </ __/ -_) __/  ' \\ https://github.com/eliukblau/pixterm\n"
"/_/  /___/_/|_|\\__/\\__/_/ /_/_/_/                1.3.2\n";

static void help(const char *argv0) {
    printf("%s\nUSAGE:\n\n  %s [options] image/url\n\n"
"  Supported image formats: JPEG, PNG, GIF, BMP, TIFF, WebP.\n"
"  Supported URL protocols: HTTP, HTTPS.\n\n"
"OPTIONS:\n\n"
"  -credits\n    \tshow some love to contributors <3\n"
"  -d mode\n    \tdithering mode:\n    \t   0 - no dithering (default)\n    \t   1 - with blocks\n    \t   2 - with chars\n"
"  -go\n    \toutput Go code to 'fmt.Print()' the image\n"
"  -m color\n    \tmatte color for transparency or background\n    \t(optional, hex format, default: 000000)\n"
"  -nobg\n    \tdisable background color\n    \t(optional, only in dithering mode, ignores matte color)\n"
"  -s method\n    \tscale method:\n    \t   0 - resize (default)\n    \t   1 - fill\n    \t   2 - fit\n"
"  -tc columns\n    \tterminal columns (optional, >=2; when piping, default: 80)\n"
"  -tr rows\n    \tterminal rows (optional, >=2; when piping, default: 24)\n"
"  -version\n    \tshow PIXterm version\n"
"  -help\n\tprints this message :D LOL\n\n", banner, argv0);
}

static void credits(void) {
    printf("%s\nCONTRIBUTORS:\n\n"
"  > @disq - https://github.com/disq\n      + Original code for image transparency support.\n\n"
"  > @timob - https://github.com/timob\n      + Fix for ANSIpixel type: use 8bit color component for output.\n\n"
"  > @HongjiangHuang - https://github.com/HongjiangHuang\n      + Original code for image download support.\n\n"
"  > @brutestack - https://github.com/brutestack\n      + Color support for Windows (Command Prompt & PowerShell).\n      + Original code for disable background color in dithering mode.\n      + Original code for output Go code to 'fmt.Print()' the image.\n\n"
"  > @diamondburned - https://github.com/diamondburned\n      + NewFromImage() & NewScaledFromImage() for ANSImage API.\n\n"
"  > @MichaelMure - https://github.com/MichaelMure\n      + More conventional 'go.mod' file at repository.\n\n"
"  > @Calinou - https://github.com/Calinou\n      + Use HTTPS URLs everywhere.\n      + Other awesome contributions.\n\n"
"  > @danirod - https://github.com/danirod\n  > @Xpktro - https://github.com/Xpktro\n      + Moral support.\n\n", banner);
}

static uint32_t be32(const unsigned char *b){ return ((uint32_t)b[0]<<24)|((uint32_t)b[1]<<16)|((uint32_t)b[2]<<8)|b[3]; }
static uint16_t le16(const unsigned char *b){ return b[0]|((uint16_t)b[1]<<8); }
static uint32_t le32(const unsigned char *b){ return b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16)|((uint32_t)b[3]<<24); }

static int read_file(const char *path, unsigned char **buf, size_t *len) {
    FILE *f=fopen(path,"rb"); if(!f) return -1;
    fseek(f,0,SEEK_END); long n=ftell(f); rewind(f);
    if(n<0){ fclose(f); return -1; }
    *buf=malloc((size_t)n+1); if(!*buf){ fclose(f); return -1; }
    *len=fread(*buf,1,(size_t)n,f); fclose(f);
    return *len==(size_t)n?0:-1;
}

static unsigned get_bits(const unsigned char *row, int bit, int depth) {
    unsigned v=0; for(int i=0;i<depth;i++){ int p=bit+i; v=(v<<1)|((row[p>>3]>>(7-(p&7)))&1); } return v;
}

static int paeth(int a,int b,int c){ int p=a+b-c, pa=abs(p-a), pb=abs(p-b), pc=abs(p-c); return (pa<=pb&&pa<=pc)?a:(pb<=pc?b:c); }

static int load_png(const char *path, Image *img) {
    unsigned char *file=NULL; size_t flen=0;
    if(read_file(path,&file,&flen)<0) return -1;
    const unsigned char sig[8]={137,80,78,71,13,10,26,10};
    if(flen<33 || memcmp(file,sig,8)){ free(file); return -2; }
    int w=0,h=0,depth=0,ctype=0,interlace=0; unsigned char pal[256][4]; int pals=0;
    unsigned char *idat=NULL; size_t idlen=0;
    for(size_t pos=8; pos+12<=flen;) {
        uint32_t len=be32(file+pos); pos+=4; char typ[5]={0}; memcpy(typ,file+pos,4); pos+=4;
        if(pos+len+4>flen) break;
        unsigned char *dat=file+pos;
        if(!strcmp(typ,"IHDR")) { w=(int)be32(dat); h=(int)be32(dat+4); depth=dat[8]; ctype=dat[9]; interlace=dat[12]; }
        else if(!strcmp(typ,"PLTE")) { pals=(int)(len/3); if(pals>256)pals=256; for(int i=0;i<pals;i++){ pal[i][0]=dat[i*3]; pal[i][1]=dat[i*3+1]; pal[i][2]=dat[i*3+2]; pal[i][3]=255; } }
        else if(!strcmp(typ,"tRNS")) { if(ctype==3){ for(uint32_t i=0;i<len&&i<256;i++) pal[i][3]=dat[i]; } }
        else if(!strcmp(typ,"IDAT")) { unsigned char *n=realloc(idat,idlen+len); if(!n){free(file);free(idat);return -1;} idat=n; memcpy(idat+idlen,dat,len); idlen+=len; }
        else if(!strcmp(typ,"IEND")) break;
        pos += len + 4;
    }
    if(w<=0||h<=0||!idat||interlace){ free(file); free(idat); return -3; }
    int channels = (ctype==0?1:ctype==2?3:ctype==3?1:ctype==4?2:ctype==6?4:0);
    if(!channels || !(depth==8 || (ctype==3 && (depth==1||depth==2||depth==4)))) { free(file); free(idat); return -3; }
    int bitspp=channels*depth, rowbytes=(w*bitspp+7)/8, bpp=(bitspp+7)/8;
    size_t rawlen=(size_t)(rowbytes+1)*h;
    unsigned char *raw=malloc(rawlen);
    uLongf dest=(uLongf)rawlen;
    int zr=uncompress(raw,&dest,idat,(uLong)idlen);
    free(file); free(idat);
    if(zr!=Z_OK){ free(raw); return -4; }
    Pixel *pix=calloc((size_t)w*h,sizeof(Pixel)); if(!pix){ free(raw); return -1; }
    unsigned char *prev=calloc(rowbytes,1), *cur=malloc(rowbytes);
    for(int y=0;y<h;y++) {
        unsigned char *src=raw+(size_t)y*(rowbytes+1)+1; int filt=raw[(size_t)y*(rowbytes+1)];
        for(int x=0;x<rowbytes;x++) {
            int a=x>=bpp?cur[x-bpp]:0, b=prev[x], c=x>=bpp?prev[x-bpp]:0, v=src[x];
            if(filt==1) v=(v+a)&255; else if(filt==2) v=(v+b)&255; else if(filt==3) v=(v+((a+b)>>1))&255; else if(filt==4) v=(v+paeth(a,b,c))&255;
            cur[x]=(unsigned char)v;
        }
        for(int x=0;x<w;x++) {
            Pixel p={0,0,0,255};
            if(ctype==0){ unsigned g= depth==8?cur[x]:(get_bits(cur,x*depth,depth)*255/((1<<depth)-1)); p.r=p.g=p.b=(unsigned char)g; }
            else if(ctype==2){ p.r=cur[x*3]; p.g=cur[x*3+1]; p.b=cur[x*3+2]; }
            else if(ctype==3){ unsigned idx=get_bits(cur,x*depth,depth); if((int)idx<pals){ p.r=pal[idx][0];p.g=pal[idx][1];p.b=pal[idx][2];p.a=pal[idx][3]; } }
            else if(ctype==4){ p.r=p.g=p.b=cur[x*2]; p.a=cur[x*2+1]; }
            else if(ctype==6){ p.r=cur[x*4]; p.g=cur[x*4+1]; p.b=cur[x*4+2]; p.a=cur[x*4+3]; }
            pix[(size_t)y*w+x]=p;
        }
        unsigned char *tmp=prev; prev=cur; cur=tmp;
    }
    free(prev); free(cur); free(raw); img->w=w; img->h=h; img->p=pix; return 0;
}

static int load_bmp(const char *path, Image *img) {
    unsigned char *b=NULL; size_t n=0; if(read_file(path,&b,&n)<0) return -1;
    if(n<54 || b[0]!='B'||b[1]!='M'){ free(b); return -2; }
    uint32_t off=le32(b+10), hdr=le32(b+14); int w=(int)le32(b+18), h=(int)le32(b+22); int top=0;
    if(h<0){ h=-h; top=1; }
    int bits=le16(b+28), comp=(int)le32(b+30); if(hdr<40||w<=0||h<=0||comp||!(bits==24||bits==32)||off>=n){ free(b); return -3; }
    Pixel *p=calloc((size_t)w*h,sizeof(Pixel)); int stride=((w*bits+31)/32)*4;
    for(int y=0;y<h;y++){ int sy=top?y:h-1-y; unsigned char *row=b+off+(size_t)sy*stride; if(row>=b+n)break;
        for(int x=0;x<w;x++){ unsigned char *q=row+x*(bits/8); if(q+2<b+n){ Pixel px={q[2],q[1],q[0], bits==32?q[3]:255}; p[(size_t)y*w+x]=px; }}}
    free(b); img->w=w; img->h=h; img->p=p; return 0;
}

static int load_ppm(const char *path, Image *img) {
    FILE *f=fopen(path,"rb"); if(!f) return -1; char magic[3]={0}; if(fscanf(f,"%2s",magic)!=1){fclose(f);return -1;}
    if(strcmp(magic,"P6")&&strcmp(magic,"P3")){fclose(f);return -2;}
    int c; do{ c=fgetc(f); if(c=='#') while((c=fgetc(f))!='\n'&&c!=EOF); }while(isspace(c)); ungetc(c,f);
    int w,h,max; if(fscanf(f,"%d%d%d",&w,&h,&max)!=3||w<=0||h<=0||max<=0){fclose(f);return -3;} fgetc(f);
    Pixel *p=calloc((size_t)w*h,sizeof(Pixel));
    for(int i=0;i<w*h;i++){ int r=0,g=0,bv=0; if(!strcmp(magic,"P6")){ r=fgetc(f);g=fgetc(f);bv=fgetc(f);} else if(fscanf(f,"%d%d%d",&r,&g,&bv)!=3) break; p[i]=(Pixel){r*255/max,g*255/max,bv*255/max,255}; }
    fclose(f); img->w=w; img->h=h; img->p=p; return 0;
}

static int load_image(const char *path, Image *img) {
    void *lib=dlopen("libgd.so.3", RTLD_LAZY);
    if(lib) {
        typedef void *(*create_fn)(FILE *);
        typedef int (*pix_fn)(void *, int, int);
        typedef void (*destroy_fn)(void *);
        create_fn creators[6];
        creators[0]=(create_fn)dlsym(lib,"gdImageCreateFromPng");
        creators[1]=(create_fn)dlsym(lib,"gdImageCreateFromJpeg");
        creators[2]=(create_fn)dlsym(lib,"gdImageCreateFromGif");
        creators[3]=(create_fn)dlsym(lib,"gdImageCreateFromBmp");
        creators[4]=(create_fn)dlsym(lib,"gdImageCreateFromTiff");
        creators[5]=(create_fn)dlsym(lib,"gdImageCreateFromWebp");
        pix_fn getpix=(pix_fn)dlsym(lib,"gdImageGetTrueColorPixel");
        destroy_fn destroy=(destroy_fn)dlsym(lib,"gdImageDestroy");
        int order[6]={0,1,2,3,4,5}, count=6;
        const char *dot=strrchr(path,'.');
        if(dot){ dot++; char e[16]; int i=0; while(dot[i]&&i<15){ e[i]=(char)tolower((unsigned char)dot[i]); i++; } e[i]=0;
            if(!strcmp(e,"png")){order[0]=0;count=1;} else if(!strcmp(e,"jpg")||!strcmp(e,"jpeg")){order[0]=1;count=1;}
            else if(!strcmp(e,"gif")){order[0]=2;count=1;} else if(!strcmp(e,"bmp")){order[0]=3;count=1;}
            else if(!strcmp(e,"tif")||!strcmp(e,"tiff")){order[0]=4;count=1;} else if(!strcmp(e,"webp")){order[0]=5;count=1;}
        }
        for(int kk=0;kk<count && getpix && destroy;kk++) { int k=order[kk]; if(!creators[k]) continue;
            FILE *f=fopen(path,"rb"); if(!f) break;
            void *im=creators[k](f); fclose(f);
            if(!im) continue;
            gdImageHead *h=(gdImageHead *)im;
            if(h->sx>0 && h->sy>0 && h->sx<100000 && h->sy<100000) {
                Pixel *p=calloc((size_t)h->sx*h->sy,sizeof(Pixel));
                if(p) {
                    for(int y=0;y<h->sy;y++) for(int x=0;x<h->sx;x++) {
                        int c=getpix(im,x,y);
                        int a=(c>>24)&0x7f;
                        p[(size_t)y*h->sx+x]=(Pixel){(c>>16)&255,(c>>8)&255,c&255,(unsigned char)(255 - a*255/127)};
                    }
                    img->w=h->sx; img->h=h->sy; img->p=p; destroy(im); dlclose(lib); return 0;
                }
            }
            destroy(im);
        }
        dlclose(lib);
    }
    int r=load_png(path,img); if(r==0) return 0;
    r=load_bmp(path,img); if(r==0) return 0;
    r=load_ppm(path,img); if(r==0) return 0;
    return -1;
}

static Pixel matte_over(Pixel p, Pixel m) {
    if(p.a==255) return p;
    unsigned a=p.a; Pixel o;
    o.r=(unsigned char)((p.r*a + m.r*(255-a))/255);
    o.g=(unsigned char)((p.g*a + m.g*(255-a))/255);
    o.b=(unsigned char)((p.b*a + m.b*(255-a))/255);
    o.a=255; return o;
}

static Pixel sample_area(Image *src, double x0, double y0, double x1, double y1, Pixel matte) {
    int ix0=(int)floor(x0), iy0=(int)floor(y0), ix1=(int)ceil(x1), iy1=(int)ceil(y1);
    double sr=0,sg=0,sb=0,sa=0,sw=0;
    for(int y=iy0;y<iy1;y++) for(int x=ix0;x<ix1;x++) {
        double ax0=fmax(x0,x), ay0=fmax(y0,y), ax1=fmin(x1,x+1.0), ay1=fmin(y1,y+1.0);
        double wt=(ax1-ax0)*(ay1-ay0);
        if(wt<=0) continue;
        Pixel p = (x<0||y<0||x>=src->w||y>=src->h) ? matte : matte_over(src->p[(size_t)y*src->w+x],matte);
        sr+=p.r*wt; sg+=p.g*wt; sb+=p.b*wt; sa+=p.a*wt; sw+=wt;
    }
    if(sw<=0) return matte;
    Pixel o={(unsigned char)lrint(sr/sw),(unsigned char)lrint(sg/sw),(unsigned char)lrint(sb/sw),(unsigned char)lrint(sa/sw)};
    return o;
}

static Image resize_image(Image *src, int cols, int rows2, int method, Pixel matte) {
    Image out={cols,rows2,calloc((size_t)cols*rows2,sizeof(Pixel))};
    double sx=(double)src->w/cols, sy=(double)src->h/rows2;
    double scale_x=sx, scale_y=sy, ox=0, oy=0;
    if(method==1 || method==2) {
        double fit = method==1 ? fmin(sx,sy) : fmax(sx,sy);
        scale_x=scale_y=fit; ox=((double)src->w-cols*fit)/2.0; oy=((double)src->h-rows2*fit)/2.0;
    }
    for(int y=0;y<rows2;y++) for(int x=0;x<cols;x++) {
        double x0=x*scale_x+ox, y0=y*scale_y+oy, x1=(x+1)*scale_x+ox, y1=(y+1)*scale_y+oy;
        if(scale_x>=1.0 || scale_y>=1.0) out.p[(size_t)y*cols+x]=sample_area(src,x0,y0,x1,y1,matte);
        else {
            double fx=(x+0.5)*scale_x+ox, fy=(y+0.5)*scale_y+oy;
            if(fx<0||fy<0||fx>=src->w||fy>=src->h){ out.p[(size_t)y*cols+x]=matte; continue; }
            int ix=(int)fx, iy=(int)fy; out.p[(size_t)y*cols+x]=matte_over(src->p[(size_t)iy*src->w+ix],matte);
        }
    }
    return out;
}

static int lumin(Pixel p){ return (int)(0.299*p.r+0.587*p.g+0.114*p.b); }
static const char *shade_block(int l){ return l>224?"█":l>160?"▓":l>96?"▒":l>32?"░":" "; }
static char shade_char(int l){ const char *s=".:;irsXA253hMHGS#9B&@"; int idx=l*22/256; if(idx<0)idx=0; if(idx>21)idx=21; return s[idx]; }

static void put_go_escaped(const char *s) {
    for(;*s;s++){ unsigned char c=*s; if(c=='\\') printf("\\\\"); else if(c=='"') printf("\\\""); else if(c=='\033') printf("\\033"); else if(c=='\n') printf("\\n"); else putchar(c); }
}

static void out_piece(Opt *o, const char *s) { if(o->go) put_go_escaped(s); else fputs(s,stdout); }
static void out_color(Opt *o, int bg, Pixel p) { char b[64]; snprintf(b,sizeof b,"\033[%d;2;%d;%d;%dm",bg?48:38,p.r,p.g,p.b); out_piece(o,b); }

static void render(Image *img, Opt *o) {
    Image r=resize_image(img,o->tc,o->tr*2,o->scale,o->matte);
    for(int y=0;y<o->tr;y++) {
        if(o->go) printf("fmt.Print(\"");
        for(int x=0;x<o->tc;x++) {
            Pixel top=r.p[(size_t)(y*2)*r.w+x], bot=r.p[(size_t)(y*2+1)*r.w+x];
            if(o->dither==0){ out_color(o,1,top); out_color(o,0,bot); out_piece(o,"▄"); }
            else {
                Pixel avg={(top.r+bot.r)/2,(top.g+bot.g)/2,(top.b+bot.b)/2,255};
                if(!o->nobg) out_color(o,1,o->matte);
                out_color(o,0,avg);
                if(o->dither==1) out_piece(o,shade_block(lumin(avg))); else { char c[2]={shade_char(lumin(avg)),0}; out_piece(o,c); }
            }
        }
        out_piece(o,"\033[0m\n");
        if(o->go) printf("\")\n");
    }
    free(r.p);
}

static int parse_hex(const char *s, Pixel *p) {
    if(s[0]=='#') s++;
    if(strlen(s)!=6) return -1;
    char *e; long v=strtol(s,&e,16); if(*e) return -1;
    p->r=(v>>16)&255; p->g=(v>>8)&255; p->b=v&255; p->a=255; return 0;
}

static void term_size(int *c, int *r) {
    struct winsize ws; if(ioctl(1,TIOCGWINSZ,&ws)==0 && ws.ws_col>=2 && ws.ws_row>=2){ *c=ws.ws_col; *r=ws.ws_row; }
}

int main(int argc, char **argv) {
    Opt o={0,0,0,0,80,24,{0,0,0,255},NULL}; term_size(&o.tc,&o.tr);
    const char *prog=strrchr(argv[0], '/'); prog = prog ? prog+1 : argv[0];
    for(int i=1;i<argc;i++) {
        if(!strcmp(argv[i],"-help")||!strcmp(argv[i],"--help")){ help(prog); return 0; }
        else if(!strcmp(argv[i],"-version")){ puts("1.3.2"); return 0; }
        else if(!strcmp(argv[i],"-credits")){ credits(); return 0; }
        else if(!strcmp(argv[i],"-go")) o.go=1;
        else if(!strcmp(argv[i],"-nobg")) o.nobg=1;
        else if(!strcmp(argv[i],"-d") && i+1<argc) o.dither=atoi(argv[++i]);
        else if(!strcmp(argv[i],"-s") && i+1<argc) o.scale=atoi(argv[++i]);
        else if(!strcmp(argv[i],"-tc") && i+1<argc) { o.tc=atoi(argv[++i]); if(o.tc<2){ help(prog); return 1; } }
        else if(!strcmp(argv[i],"-tr") && i+1<argc) { o.tr=atoi(argv[++i]); if(o.tr<2){ help(prog); return 1; } }
        else if(!strcmp(argv[i],"-m") && i+1<argc) { if(parse_hex(argv[++i],&o.matte)<0){ help(prog); return 1; } }
        else if(argv[i][0]=='-') { help(prog); return 1; }
        else o.path=argv[i];
    }
    if(o.dither<0||o.dither>2||o.scale<0||o.scale>2||!o.path){ help(prog); return 1; }
    Image img={0};
    if(load_image(o.path,&img)<0) {
        printf("%s\n[PIXTERM ERROR] open %s: %s\n", banner, o.path, strerror(errno?errno:ENOENT));
        return 1;
    }
    render(&img,&o); free(img.p); return 0;
}
