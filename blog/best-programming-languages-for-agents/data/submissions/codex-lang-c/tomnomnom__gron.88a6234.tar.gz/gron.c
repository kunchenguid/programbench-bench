#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef enum { N_NULL, N_BOOL, N_NUM, N_STR, N_ARR, N_OBJ } NType;
typedef struct Node Node;
typedef struct { char *key; Node *val; } Pair;
struct Node {
    NType type;
    char *s;
    int b;
    Node **items;
    int len, cap;
    Pair *pairs;
    int plen, pcap;
};

typedef struct { char *path; Node *val; } Stmt;
typedef struct { Stmt *v; int n, cap; } Stmts;
typedef struct { const char *p, *end; char err[256]; } Parser;

static void dieoom(void){ fprintf(stderr,"out of memory\n"); exit(2); }
static void *xcalloc(size_t n,size_t s){ void *p=calloc(n,s); if(!p) dieoom(); return p; }
static void *xrealloc(void *p,size_t s){ p=realloc(p,s); if(!p) dieoom(); return p; }
static char *xstrdup(const char *s){ char *p=strdup(s?s:""); if(!p) dieoom(); return p; }
static char *xstrndup(const char *s,size_t n){ char *p=malloc(n+1); if(!p) dieoom(); memcpy(p,s,n); p[n]=0; return p; }

static Node *node(NType t){ Node *n=xcalloc(1,sizeof(*n)); n->type=t; return n; }
static void arr_add(Node *a, Node *v){ if(a->len==a->cap){a->cap=a->cap?a->cap*2:8; a->items=xrealloc(a->items,a->cap*sizeof(Node*));} a->items[a->len++]=v; }
static void obj_add(Node *o, char *k, Node *v){ if(o->plen==o->pcap){o->pcap=o->pcap?o->pcap*2:8; o->pairs=xrealloc(o->pairs,o->pcap*sizeof(Pair));} o->pairs[o->plen].key=k; o->pairs[o->plen++].val=v; }

typedef struct { char *b; size_t n, cap; } Buf;
static void binit(Buf *b){ b->cap=128; b->n=0; b->b=xcalloc(b->cap,1); }
static void bneed(Buf *b,size_t add){ if(b->n+add+1>b->cap){ while(b->n+add+1>b->cap) b->cap*=2; b->b=xrealloc(b->b,b->cap); } }
static void bputc(Buf *b,char c){ bneed(b,1); b->b[b->n++]=c; b->b[b->n]=0; }
static void bputs(Buf *b,const char *s){ size_t l=strlen(s); bneed(b,l); memcpy(b->b+b->n,s,l); b->n+=l; b->b[b->n]=0; }
static void bprintf(Buf *b,const char *fmt,...){ va_list ap; while(1){ bneed(b,128); va_start(ap,fmt); int r=vsnprintf(b->b+b->n,b->cap-b->n,fmt,ap); va_end(ap); if(r<0) return; if(b->n+(size_t)r<b->cap){ b->n+=r; return; } bneed(b,(size_t)r+1); } }

static void perr(Parser *p,const char *fmt,...){ if(p->err[0]) return; va_list ap; va_start(ap,fmt); vsnprintf(p->err,sizeof(p->err),fmt,ap); va_end(ap); }
static void ws(Parser *p){ while(p->p<p->end && isspace((unsigned char)*p->p)) p->p++; }
static void utf8(Buf *b,unsigned cp){ if(cp<0x80)bputc(b,cp); else if(cp<0x800){bputc(b,0xc0|(cp>>6));bputc(b,0x80|(cp&63));} else {bputc(b,0xe0|(cp>>12));bputc(b,0x80|((cp>>6)&63));bputc(b,0x80|(cp&63));} }
static int hexv(char c){ if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return -1; }

static char *parse_string(Parser *p){
    if(p->p>=p->end || *p->p!='"'){ perr(p,"invalid character '%c' looking for beginning of value", p->p<p->end?*p->p:' '); return xstrdup(""); }
    p->p++; Buf b; binit(&b);
    while(p->p<p->end){
        unsigned char c=*p->p++;
        if(c=='"') return b.b;
        if(c=='\\'){
            if(p->p>=p->end){ perr(p,"unexpected EOF"); return b.b; }
            char e=*p->p++;
            switch(e){
                case '"': bputc(&b,'"'); break; case '\\': bputc(&b,'\\'); break; case '/': bputc(&b,'/'); break;
                case 'b': bputc(&b,'\b'); break; case 'f': bputc(&b,'\f'); break; case 'n': bputc(&b,'\n'); break; case 'r': bputc(&b,'\r'); break; case 't': bputc(&b,'\t'); break;
                case 'u': { unsigned cp=0; for(int i=0;i<4;i++){ if(p->p>=p->end||hexv(*p->p)<0){perr(p,"invalid character in string escape code"); return b.b;} cp=(cp<<4)|hexv(*p->p++);} utf8(&b,cp); break; }
                default: perr(p,"invalid character '%c' in string escape code", e); return b.b;
            }
        } else {
            if(c<0x20){ perr(p,"invalid character in string literal"); return b.b; }
            bputc(&b,c);
        }
    }
    perr(p,"unexpected EOF"); return b.b;
}

static Node *parse_val(Parser *p);
static Node *parse_arr(Parser *p){ Node *a=node(N_ARR); p->p++; ws(p); if(p->p<p->end&&*p->p==']'){p->p++;return a;} while(!p->err[0]){ arr_add(a,parse_val(p)); ws(p); if(p->p>=p->end){perr(p,"unexpected EOF");break;} if(*p->p==']'){p->p++;break;} if(*p->p!=','){perr(p,"invalid character '%c' after array element",*p->p);break;} p->p++; ws(p);} return a; }
static Node *parse_obj(Parser *p){ Node *o=node(N_OBJ); p->p++; ws(p); if(p->p<p->end&&*p->p=='}'){p->p++;return o;} while(!p->err[0]){ ws(p); if(p->p>=p->end){perr(p,"unexpected EOF");break;} if(*p->p!='"'){perr(p,"invalid character '%c' looking for beginning of object key string",*p->p);break;} char *k=parse_string(p); ws(p); if(p->p>=p->end){perr(p,"unexpected EOF");break;} if(*p->p!=':'){perr(p,"invalid character '%c' after object key",*p->p);break;} p->p++; obj_add(o,k,parse_val(p)); ws(p); if(p->p>=p->end){perr(p,"unexpected EOF");break;} if(*p->p=='}'){p->p++;break;} if(*p->p!=','){perr(p,"invalid character '%c' after object key:value pair",*p->p);break;} p->p++; } return o; }
static bool lit(Parser *p,const char *s){ size_t l=strlen(s); if((size_t)(p->end-p->p)>=l && memcmp(p->p,s,l)==0){p->p+=l;return true;} return false; }
static Node *parse_num(Parser *p){
    const char *st=p->p;
    if(*p->p=='-') p->p++;
    if(p->p>=p->end || !isdigit((unsigned char)*p->p)){ perr(p,"invalid character '%c' in numeric literal", p->p<p->end?*p->p:' '); }
    if(p->p<p->end && *p->p=='0') p->p++;
    else while(p->p<p->end && isdigit((unsigned char)*p->p)) p->p++;
    if(p->p<p->end && *p->p=='.'){
        p->p++;
        if(p->p>=p->end || !isdigit((unsigned char)*p->p)) perr(p,"invalid character '%c' after decimal point in numeric literal", p->p<p->end?*p->p:' ');
        while(p->p<p->end && isdigit((unsigned char)*p->p)) p->p++;
    }
    if(p->p<p->end && (*p->p=='e'||*p->p=='E')){
        p->p++;
        if(p->p<p->end && (*p->p=='+'||*p->p=='-')) p->p++;
        if(p->p>=p->end || !isdigit((unsigned char)*p->p)) perr(p,"invalid character '%c' in exponent of numeric literal", p->p<p->end?*p->p:' ');
        while(p->p<p->end && isdigit((unsigned char)*p->p)) p->p++;
    }
    Node *n=node(N_NUM); n->s=xstrndup(st,p->p-st); return n;
}
static Node *parse_val(Parser *p){ ws(p); if(p->p>=p->end){perr(p,"unexpected EOF"); return node(N_NULL);} char c=*p->p; if(c=='{')return parse_obj(p); if(c=='[')return parse_arr(p); if(c=='"'){Node*n=node(N_STR);n->s=parse_string(p);return n;} if(c=='t'&&lit(p,"true")){Node*n=node(N_BOOL);n->b=1;return n;} if(c=='f'&&lit(p,"false")){Node*n=node(N_BOOL);return n;} if(c=='n'&&lit(p,"null"))return node(N_NULL); if(c=='-'||isdigit((unsigned char)c))return parse_num(p); perr(p,"invalid character '%c' looking for beginning of value",c); return node(N_NULL); }
static Node *parse_json(const char *s, char *err, size_t esz){ Parser p={s,s+strlen(s),{0}}; Node *n=parse_val(&p); ws(&p); if(!p.err[0] && p.p<p.end) perr(&p,"invalid character '%c' after top-level value",*p.p); if(p.err[0]) snprintf(err,esz,"%s",p.err); else err[0]=0; return n; }

static void enc_str(Buf *b,const char *s){
    bputc(b,'"');
    for(const unsigned char *p=(const unsigned char*)s; *p; p++){
        switch(*p){ case '"': bputs(b,"\\\""); break; case '\\': bputs(b,"\\\\"); break; case '\b': bputs(b,"\\b"); break; case '\f': bputs(b,"\\f"); break; case '\n': bputs(b,"\\n"); break; case '\r': bputs(b,"\\r"); break; case '\t': bputs(b,"\\t"); break; default: if(*p<0x20)bprintf(b,"\\u%04x",*p); else bputc(b,*p); }
    }
    bputc(b,'"');
}
static void val_json(Buf *b,Node*n){ switch(n->type){case N_NULL:bputs(b,"null");break;case N_BOOL:bputs(b,n->b?"true":"false");break;case N_NUM:bputs(b,n->s);break;case N_STR:enc_str(b,n->s);break;case N_ARR:bputs(b,"[]");break;case N_OBJ:bputs(b,"{}");break;} }
static bool ident(const char *s){ if(!*s)return false; unsigned char c=s[0]; if(isdigit(c)||c=='-'||isspace(c))return false; for(const unsigned char*p=(const unsigned char*)s;*p;p++){ if(!(isalnum(*p)||*p=='_'||*p=='$'||*p>=128)) return false; } return true; }
static char *path_key(const char *base,const char *k){ Buf b; binit(&b); bputs(&b,base); if(ident(k)){bputc(&b,'.'); bputs(&b,k);} else {bputc(&b,'['); enc_str(&b,k); bputc(&b,']');} return b.b; }
static char *path_idx(const char *base,int i){ Buf b; binit(&b); bprintf(&b,"%s[%d]",base,i); return b.b; }
static void st_add(Stmts*s,char*p,Node*v){ if(s->n==s->cap){s->cap=s->cap?s->cap*2:32; s->v=xrealloc(s->v,s->cap*sizeof(Stmt));} s->v[s->n].path=p; s->v[s->n++].val=v; }
static void collect(Node*n,const char*path,Stmts*s){ st_add(s,xstrdup(path),n); if(n->type==N_OBJ){ for(int i=0;i<n->plen;i++){ char*p=path_key(path,n->pairs[i].key); collect(n->pairs[i].val,p,s); free(p);} } else if(n->type==N_ARR){ for(int i=0;i<n->len;i++){ char*p=path_idx(path,i); collect(n->items[i],p,s); free(p);} } }
static int stmtcmp(const void*a,const void*b){ const Stmt*x=a,*y=b; return strcmp(x->path,y->path); }

static void json_path_emit(const char *path, Node *v){
    Buf out; binit(&out); bputc(&out,'['); bputc(&out,'[');
    const char *p=path+4; bool first=true;
    while(*p){
        if(*p=='.'){ p++; const char*st=p; while(*p&&*p!='.'&&*p!='[')p++; if(!first)bputc(&out,','); char*t=xstrndup(st,p-st); enc_str(&out,t); free(t); first=false; }
        else if(*p=='['){ p++; if(*p=='"'){ Parser ps={p, p+strlen(p), {0}}; char *k=parse_string(&ps); p=ps.p; if(*p==']')p++; if(!first)bputc(&out,','); enc_str(&out,k); free(k); first=false; } else { const char*st=p; while(*p&&*p!=']')p++; if(!first)bputc(&out,','); bprintf(&out,"%.*s",(int)(p-st),st); if(*p==']')p++; first=false; } }
        else p++;
    }
    bputc(&out,']'); bputc(&out,','); val_json(&out,v); bputc(&out,']'); puts(out.b); free(out.b);
}
static void print_gron2(Node *root,bool json,bool values,bool sort){
    Stmts s={0}; collect(root,"json",&s); if(sort) qsort(s.v,s.n,sizeof(Stmt),stmtcmp);
    for(int i=0;i<s.n;i++){
        if(values){ if(s.v[i].val->type==N_ARR||s.v[i].val->type==N_OBJ) continue; if(s.v[i].val->type==N_STR) printf("%s\n",s.v[i].val->s); else { Buf b; binit(&b); val_json(&b,s.v[i].val); printf("%s\n",b.b); free(b.b);} }
        else if(json) json_path_emit(s.v[i].path,s.v[i].val);
        else { Buf b; binit(&b); val_json(&b,s.v[i].val); printf("%s = %s;\n",s.v[i].path,b.b); free(b.b); }
    }
}

static char *read_all(FILE*f){ Buf b; binit(&b); char tmp[4096]; size_t r; while((r=fread(tmp,1,sizeof(tmp),f))>0){ bneed(&b,r); memcpy(b.b+b.n,tmp,r); b.n+=r; b.b[b.n]=0; } return b.b; }

typedef enum { T_KEY, T_IDX } TokT;
typedef struct { TokT t; char *key; int idx; } Tok;
static int parse_path(const char *line, Tok **out){
    const char *p=line; while(isspace((unsigned char)*p))p++; if(strncmp(p,"json",4)!=0)return -1; p+=4; Tok *v=NULL; int n=0,cap=0;
    while(*p && *p!='=' && !isspace((unsigned char)*p)){
        Tok t={0};
        if(*p=='.'){ p++; const char*st=p; while(*p&&*p!='.'&&*p!='['&&!isspace((unsigned char)*p)&&*p!='=')p++; t.t=T_KEY; t.key=xstrndup(st,p-st); }
        else if(*p=='['){ p++; if(*p=='"'){ Parser ps={p,p+strlen(p),{0}}; t.t=T_KEY; t.key=parse_string(&ps); p=ps.p; if(*p==']')p++; } else { t.t=T_IDX; t.idx=atoi(p); while(*p&&*p!=']')p++; if(*p==']')p++; } }
        else break;
        if(n==cap){cap=cap?cap*2:8; v=xrealloc(v,cap*sizeof(Tok));} v[n++]=t;
    }
    *out=v; return n;
}
static Node *obj_get(Node*o,const char*k){ for(int i=0;i<o->plen;i++) if(strcmp(o->pairs[i].key,k)==0) return o->pairs[i].val; return NULL; }
static Node *ensure_child(Node *par, Tok tok, Tok *next){
    NType nt=(next&&next->t==T_IDX)?N_ARR:N_OBJ;
    if(tok.t==T_KEY){ if(par->type!=N_OBJ) par->type=N_OBJ; Node *c=obj_get(par,tok.key); if(!c){ c=node(nt); obj_add(par,xstrdup(tok.key),c);} return c; }
    else { if(par->type!=N_ARR) par->type=N_ARR; while(par->len<=tok.idx) arr_add(par,node(N_NULL)); if(par->items[tok.idx]->type==N_NULL && next) par->items[tok.idx]->type=nt; return par->items[tok.idx]; }
}
static void assign_path(Node **root, Tok*t,int ntok,Node*val){
    if(ntok==0){ *root=val; return; }
    if(!*root) *root=node(t[0].t==T_IDX?N_ARR:N_OBJ);
    Node *cur=*root;
    for(int i=0;i<ntok-1;i++) cur=ensure_child(cur,t[i],&t[i+1]);
    Tok last=t[ntok-1];
    if(last.t==T_KEY){ if(cur->type!=N_OBJ)cur->type=N_OBJ; Node *old=obj_get(cur,last.key); if(old) *old=*val; else obj_add(cur,xstrdup(last.key),val); }
    else { if(cur->type!=N_ARR)cur->type=N_ARR; while(cur->len<=last.idx) arr_add(cur,node(N_NULL)); cur->items[last.idx]=val; }
}
static int paircmp(const void*a,const void*b){ const Pair*x=a,*y=b; return strcmp(x->key,y->key); }
static void print_pretty(Node*n,int ind){
    switch(n->type){
        case N_NULL: printf("null"); break; case N_BOOL: printf(n->b?"true":"false"); break; case N_NUM: printf("%s",n->s); break; case N_STR:{Buf b;binit(&b);enc_str(&b,n->s);printf("%s",b.b);free(b.b);break;}
        case N_ARR: printf("["); if(n->len){ printf("\n"); for(int i=0;i<n->len;i++){ printf("%*s",ind+2,""); print_pretty(n->items[i],ind+2); if(i<n->len-1)printf(","); printf("\n"); } printf("%*s",ind,""); } printf("]"); break;
        case N_OBJ: qsort(n->pairs,n->plen,sizeof(Pair),paircmp); printf("{"); if(n->plen){ printf("\n"); for(int i=0;i<n->plen;i++){ printf("%*s",ind+2,""); Buf b;binit(&b);enc_str(&b,n->pairs[i].key);printf("%s: ",b.b);free(b.b); print_pretty(n->pairs[i].val,ind+2); if(i<n->plen-1)printf(","); printf("\n"); } printf("%*s",ind,""); } printf("}"); break;
    }
}

static int ungron_text(const char *input,bool jsstream){
    Node *root=NULL; char *copy=xstrdup(input), *save=NULL, *line=strtok_r(copy,"\n",&save);
    for(; line; line=strtok_r(NULL,"\n",&save)){
        while(isspace((unsigned char)*line)) line++;
        if(!*line) continue;
        Tok *t=NULL; int nt=0; Node *v=NULL;
        if(jsstream){ char err[256]; Node *row=parse_json(line,err,sizeof(err)); if(err[0]||!row||row->type!=N_ARR||row->len<2||row->items[0]->type!=N_ARR){ fprintf(stderr,"failed to parse statements: %s\n",err[0]?err:"invalid statement"); free(copy); return 5; } Node *pa=row->items[0]; nt=pa->len; t=xcalloc(nt,sizeof(Tok)); for(int i=0;i<nt;i++){ if(pa->items[i]->type==N_NUM){t[i].t=T_IDX;t[i].idx=atoi(pa->items[i]->s);} else {t[i].t=T_KEY;t[i].key=xstrdup(pa->items[i]->s?pa->items[i]->s:"");} } v=row->items[1]; }
        else { nt=parse_path(line,&t); char *eq=strchr(line,'='); if(nt<0||!eq) continue; eq++; char *semi=strrchr(eq,';'); if(semi)*semi=0; char err[256]; v=parse_json(eq,err,sizeof(err)); if(err[0]){ fprintf(stderr,"failed to parse statements: %s\n",err); free(copy); return 5; } }
        assign_path(&root,t,nt,v);
    }
    if(!root) root=node(N_OBJ);
    print_pretty(root,0);
    printf("\n");
    free(copy);
    return 0;
}

static void print_value(Node *v){
    if(v->type==N_ARR || v->type==N_OBJ) return;
    if(v->type==N_STR) printf("%s\n", v->s);
    else { Buf b; binit(&b); val_json(&b,v); printf("%s\n",b.b); free(b.b); }
}

static int values_text(const char *input,bool jsstream){
    char *copy=xstrdup(input), *save=NULL, *line=strtok_r(copy,"\n",&save);
    for(; line; line=strtok_r(NULL,"\n",&save)){
        while(isspace((unsigned char)*line)) line++;
        if(!*line) continue;
        Node *v=NULL;
        if(jsstream){
            char err[256]; Node *row=parse_json(line,err,sizeof(err));
            if(err[0] || !row || row->type!=N_ARR || row->len<2){
                fprintf(stderr,"failed to parse statements: %s\n",err[0]?err:"invalid statement");
                free(copy); return 5;
            }
            v=row->items[1];
        } else {
            char *eq=strchr(line,'=');
            if(!eq) continue;
            eq++;
            char *semi=strrchr(eq,';'); if(semi)*semi=0;
            char err[256]; v=parse_json(eq,err,sizeof(err));
            if(err[0]){ fprintf(stderr,"failed to parse statements: %s\n",err); free(copy); return 5; }
        }
        print_value(v);
    }
    free(copy); return 0;
}

static void usage(void){ puts("Transform JSON (from a file, URL, or stdin) into discrete assignments to make it greppable\n\nUsage:\n  gron [OPTIONS] [FILE|URL|-]\n\nOptions:\n  -u, --ungron     Reverse the operation (turn assignments back into JSON)\n  -v, --values     Print just the values of provided assignments\n  -c, --colorize   Colorize output (default on tty)\n  -m, --monochrome Monochrome (don't colorize output)\n  -s, --stream     Treat each line of input as a separate JSON object\n  -k, --insecure   Disable certificate validation\n  -x, --proxy      Set proxy configuration\n      --noproxy    Comma-separated list of hosts for which not to use a proxy, if one is specified.\n  -j, --json       Represent gron data as JSON stream\n      --no-sort    Don't sort output (faster)\n      --version    Print version information\n\nExit Codes:\n  0\tOK\n  1\tFailed to open file\n  2\tFailed to read input\n  3\tFailed to form statements\n  4\tFailed to fetch URL\n  5\tFailed to parse statements\n  6\tFailed to encode JSON\n\nExamples:\n  gron /tmp/apiresponse.json\n  gron http://jsonplaceholder.typicode.com/users/1 \n  curl -s http://jsonplaceholder.typicode.com/users/1 | gron\n  gron http://jsonplaceholder.typicode.com/users/1 | grep company | gron --ungron"); }

int main(int argc,char**argv){
    bool un=false, values=false, js=false, stream=false, sort=true; char *file=NULL;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--help")||!strcmp(a,"-h")){usage();return 0;} else if(!strcmp(a,"--version")){puts("gron version dev");return 0;}
        else if(!strcmp(a,"-u")||!strcmp(a,"--ungron"))un=true; else if(!strcmp(a,"-v")||!strcmp(a,"--values"))values=true; else if(!strcmp(a,"-j")||!strcmp(a,"--json"))js=true; else if(!strcmp(a,"-s")||!strcmp(a,"--stream"))stream=true; else if(!strcmp(a,"--no-sort"))sort=false;
        else if(!strcmp(a,"-c")||!strcmp(a,"--colorize")||!strcmp(a,"-m")||!strcmp(a,"--monochrome")||!strcmp(a,"-k")||!strcmp(a,"--insecure")){}
        else if(!strcmp(a,"-x")||!strcmp(a,"--proxy")||!strcmp(a,"--noproxy")){ if(i+1<argc)i++; }
        else file=a;
    }
    FILE *f=stdin; if(file && strcmp(file,"-")){ if(strstr(file,"://")){ fprintf(stderr,"failed to fetch URL: Get \"%s\": unsupported protocol scheme\n",file); return 4; } f=fopen(file,"rb"); if(!f){ fprintf(stderr,"open %s: %s\n",file,strerror(errno)); return 1; } }
    char *input=read_all(f); if(f!=stdin) fclose(f);
    if(values) return values_text(input,js);
    if(un) return ungron_text(input,js);
    if(stream){
        Node *root=node(N_ARR); char *copy=xstrdup(input), *save=NULL, *line=strtok_r(copy,"\n",&save);
        for(; line; line=strtok_r(NULL,"\n",&save)){ if(!*line)continue; char err[256]; Node*n=parse_json(line,err,sizeof(err)); if(err[0]){ print_gron2(root,js,values,sort); fprintf(stderr,"failed to form statements: %s\n",err); return 3; } arr_add(root,n); }
        print_gron2(root,js,values,sort); return 0;
    }
    char err[256]; Node *root=parse_json(input,err,sizeof(err)); if(err[0]){ fprintf(stderr,"failed to form statements: %s\n",err); return 3; }
    print_gron2(root,js,values,sort); return 0;
}
