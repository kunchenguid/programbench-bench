#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fnmatch.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    char *name, *path, *pattern, *kind, *kind_long, *scope, *typeref;
    int line;
    bool file_scope;
} Tag;

typedef struct {
    Tag *v;
    size_t n, cap;
} Tags;

typedef struct {
    char **v;
    size_t n, cap;
} Strs;

typedef struct {
    char *tagfile;
    bool to_stdout, append, recurse, filter, sort, xref, json, format1;
    bool line_field, lang_field, print_language, totals, verbose;
    char *language_force, *filter_term;
    Strs excludes;
} Opt;

static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) exit(1); return p; }
static void *xrealloc(void *p, size_t n) { void *q = realloc(p, n); if (!q) exit(1); return q; }

static void strs_add(Strs *s, const char *v) {
    if (s->n == s->cap) { s->cap = s->cap ? s->cap * 2 : 16; s->v = xrealloc(s->v, s->cap * sizeof(char*)); }
    s->v[s->n++] = xstrdup(v);
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static int leading_spaces(const char *s) {
    int n = 0; while (*s == ' ' || *s == '\t') n += (*s++ == '\t') ? 8 : 1; return n;
}

static bool starts(const char *s, const char *p) { return strncmp(s, p, strlen(p)) == 0; }

static char *basename_dup(const char *p) {
    const char *b = strrchr(p, '/');
    return xstrdup(b ? b + 1 : p);
}

static const char *ext_of(const char *p) {
    const char *b = strrchr(p, '/'); b = b ? b + 1 : p;
    const char *e = strrchr(b, '.');
    return e ? e + 1 : "";
}

static char *escape_pattern(const char *line, const char *name, const char *kind) {
    size_t len = strlen(line), cap = len * 2 + 16, j = 0;
    char *r = malloc(cap);
    r[j++] = '/'; r[j++] = '^';
    const char *end = line + len;
    if (strcmp(kind, "d") == 0 && starts(line, "#define ")) {
        const char *p = line + 8;
        while (*p && isspace((unsigned char)*p)) p++;
        p += strlen(name);
        if (*p == '(') while (*p && *p != ')' && p < end) p++;
        while (*p && isspace((unsigned char)*p)) p++;
        end = p;
    }
    for (const char *p = line; p < end; p++) {
        if (j + 4 >= cap) { cap *= 2; r = xrealloc(r, cap); }
        if (*p == '/' || *p == '\\') r[j++] = '\\';
        r[j++] = *p;
    }
    if (strcmp(kind, "d") != 0) r[j++] = '$';
    r[j++] = '/'; r[j] = 0;
    return r;
}

static void add_tag(Tags *t, const char *name, const char *path, int line, const char *src,
                    const char *kind, const char *kind_long, const char *scope,
                    const char *typeref, bool file_scope) {
    if (!name || !*name) return;
    if (t->n == t->cap) { t->cap = t->cap ? t->cap * 2 : 128; t->v = xrealloc(t->v, t->cap * sizeof(Tag)); }
    Tag *g = &t->v[t->n++];
    g->name = xstrdup(name); g->path = xstrdup(path); g->line = line;
    g->pattern = escape_pattern(src, name, kind);
    g->kind = xstrdup(kind); g->kind_long = xstrdup(kind_long);
    g->scope = scope ? xstrdup(scope) : NULL; g->typeref = typeref ? xstrdup(typeref) : NULL;
    g->file_scope = file_scope;
}

static bool ident_ok(const char *s) {
    if (!s || !(isalpha((unsigned char)*s) || *s == '_')) return false;
    for (; *s; s++) if (!(isalnum((unsigned char)*s) || *s == '_' || *s == '$')) return false;
    return true;
}

static char *first_ident_after(char *s, const char *kw) {
    char *p = strstr(s, kw);
    if (!p) return NULL;
    p += strlen(kw);
    while (isspace((unsigned char)*p)) p++;
    char buf[256]; int i = 0;
    while ((isalnum((unsigned char)*p) || *p == '_' || *p == '$') && i < 255) buf[i++] = *p++;
    buf[i] = 0;
    return ident_ok(buf) ? xstrdup(buf) : NULL;
}

static const char *long_kind(const char *k) {
    if (!strcmp(k,"d")) return "macro"; if (!strcmp(k,"f")) return "function";
    if (!strcmp(k,"c")) return "class"; if (!strcmp(k,"m")) return "member";
    if (!strcmp(k,"v")) return "variable"; if (!strcmp(k,"s")) return "struct";
    if (!strcmp(k,"u")) return "union"; if (!strcmp(k,"g")) return "enum";
    if (!strcmp(k,"e")) return "enumerator"; if (!strcmp(k,"t")) return "typedef";
    if (!strcmp(k,"p")) return "package"; if (!strcmp(k,"i")) return "interface";
    if (!strcmp(k,"M")) return "module"; if (!strcmp(k,"n")) return "namespace";
    return "tag";
}

static void parse_enum_members(Tags *tags, const char *path, int lno, const char *orig, char *line, const char *ename) {
    char *lb = strchr(line, '{'), *rb = strrchr(line, '}');
    if (!lb || !rb || rb <= lb) return;
    char *body = strndup(lb + 1, (size_t)(rb - lb - 1));
    for (char *tok = strtok(body, ","); tok; tok = strtok(NULL, ",")) {
        char *x = trim(tok), *eq = strchr(x, '='); if (eq) *eq = 0; x = trim(x);
        char name[256]; int i = 0; while ((isalnum((unsigned char)x[i]) || x[i] == '_') && i < 255) { name[i] = x[i]; i++; }
        name[i] = 0;
        if (ident_ok(name)) {
            char scope[320]; snprintf(scope, sizeof(scope), "enum:%s", ename ? ename : "");
            add_tag(tags, name, path, lno, orig, "e", "enumerator", scope, NULL, true);
        }
    }
    free(body);
}

static void parse_struct_members(Tags *tags, const char *path, int lno, const char *orig, char *line, const char *sname) {
    char *lb = strchr(line, '{'), *rb = strrchr(line, '}');
    if (!lb || !rb || rb <= lb) return;
    char *body = strndup(lb + 1, (size_t)(rb - lb - 1));
    for (char *tok = strtok(body, ";"); tok; tok = strtok(NULL, ";")) {
        char *x = trim(tok); if (!*x || strchr(x, '(')) continue;
        char *last = x + strlen(x);
        while (last > x && (isspace((unsigned char)last[-1]) || last[-1] == '*' || last[-1] == ']')) last--;
        while (last > x && (isalnum((unsigned char)last[-1]) || last[-1] == '_')) last--;
        char name[256]; int i = 0; for (char *p = last; (isalnum((unsigned char)*p) || *p == '_') && i < 255; p++) name[i++] = *p;
        name[i] = 0;
        if (ident_ok(name)) {
            char scope[320], type[320]; snprintf(scope, sizeof(scope), "struct:%s", sname ? sname : "");
            char *before = strndup(x, (size_t)(last - x)); snprintf(type, sizeof(type), "typename:%s", trim(before)); free(before);
            add_tag(tags, name, path, lno, orig, "m", "member", scope, type, true);
        }
    }
    free(body);
}

static void parse_c_like(Tags *tags, const char *path) {
    FILE *f = fopen(path, "r"); if (!f) return;
    char *line = NULL; size_t n = 0; int lno = 0, brace = 0;
    while (getline(&line, &n, f) >= 0) {
        lno++; line[strcspn(line, "\r\n")] = 0;
        char *orig = line, *s = trim(line);
        if (!*s || starts(s, "//") || starts(s, "/*") || starts(s, "*")) continue;
        char work[8192]; snprintf(work, sizeof(work), "%s", s);
        if (starts(s, "#define")) {
            char *p = s + 7; while (isspace((unsigned char)*p)) p++;
            char name[256]; int i = 0; while ((isalnum((unsigned char)*p) || *p == '_') && i < 255) name[i++] = *p++;
            name[i] = 0; if (ident_ok(name)) add_tag(tags, name, path, lno, s, "d", "macro", NULL, NULL, true);
        }
        char *nm = NULL;
        if ((nm = first_ident_after(work, "struct "))) {
            add_tag(tags, nm, path, lno, s, "s", "struct", NULL, NULL, true);
            parse_struct_members(tags, path, lno, s, work, nm); free(nm);
        }
        snprintf(work, sizeof(work), "%s", s);
        if ((nm = first_ident_after(work, "union "))) { add_tag(tags, nm, path, lno, s, "u", "union", NULL, NULL, true); free(nm); }
        snprintf(work, sizeof(work), "%s", s);
        if ((nm = first_ident_after(work, "enum "))) {
            add_tag(tags, nm, path, lno, s, "g", "enum", NULL, NULL, true);
            parse_enum_members(tags, path, lno, s, work, nm); free(nm);
        }
        if (starts(s, "typedef ")) {
            char tcopy[8192]; snprintf(tcopy, sizeof(tcopy), "%s", s);
            char *semi = strrchr(tcopy, ';'); if (semi) *semi = 0;
            char *p = tcopy + strlen(tcopy); while (p > tcopy && isspace((unsigned char)p[-1])) p--;
            char *e = p; while (p > tcopy && (isalnum((unsigned char)p[-1]) || p[-1] == '_')) p--;
            char name[256]; snprintf(name, sizeof(name), "%.*s", (int)(e-p), p);
            if (ident_ok(name)) {
                char tref[320] = "";
                char *st = strstr(tcopy, "struct ");
                if (st) {
                    char *sn = first_ident_after(tcopy, "struct ");
                    if (sn) { snprintf(tref, sizeof(tref), "struct:%s", sn); free(sn); }
                }
                add_tag(tags, name, path, lno, orig, "t", "typedef", NULL, *tref ? tref : NULL, true);
            }
        }
        if (brace == 0 && strchr(s, '(') && (strchr(s, '{') || !strchr(s, ';')) && !starts(s, "if") && !starts(s, "for") && !starts(s, "while") && !starts(s, "switch")) {
            char *lp = strchr(s, '('), *p = lp;
            while (p > s && isspace((unsigned char)p[-1])) p--;
            char *e = p; while (p > s && (isalnum((unsigned char)p[-1]) || p[-1] == '_' || p[-1] == '~')) p--;
            char name[256]; snprintf(name, sizeof(name), "%.*s", (int)(e-p), p);
            if (ident_ok(name)) {
                char *before = strndup(s, (size_t)(p - s)); char *bt = trim(before);
                if (starts(bt, "static ")) bt = trim(bt + 7);
                char type[512]; snprintf(type, sizeof(type), "typename:%s", bt); free(before);
                add_tag(tags, name, path, lno, s, "f", "function", NULL, type, strstr(s, "static ") == s);
            }
        } else if (brace == 0 && strchr(s, ';') && !strchr(s, '(') && !strchr(s, '{') && !strchr(s, '}') && !starts(s, "typedef") && !starts(s, "return") && !starts(s, "#")) {
            char vcopy[8192]; snprintf(vcopy, sizeof(vcopy), "%s", s);
            char *semi = strchr(vcopy, ';'); *semi = 0;
            char *eq = strchr(vcopy, '='); if (eq) *eq = 0;
            char *p = vcopy + strlen(vcopy); while (p > vcopy && isspace((unsigned char)p[-1])) p--;
            char *e = p; while (p > vcopy && (isalnum((unsigned char)p[-1]) || p[-1] == '_')) p--;
            char name[256]; snprintf(name, sizeof(name), "%.*s", (int)(e-p), p);
            if (ident_ok(name)) {
                char *before = strndup(vcopy, (size_t)(p - vcopy)); char type[512]; snprintf(type, sizeof(type), "typename:%s", trim(before)); free(before);
                add_tag(tags, name, path, lno, orig, "v", "variable", NULL, type, false);
            }
        }
        for (char *p = s; *p; p++) { if (*p == '{') brace++; else if (*p == '}' && brace > 0) brace--; }
    }
    free(line); fclose(f);
}

static void parse_python(Tags *tags, const char *path) {
    FILE *f = fopen(path, "r"); if (!f) return;
    char *line = NULL, cls[256] = ""; size_t n = 0; int lno = 0, cls_indent = -1;
    while (getline(&line, &n, f) >= 0) {
        lno++; line[strcspn(line, "\r\n")] = 0; char *s = trim(line); int ind = leading_spaces(line);
        if (cls_indent >= 0 && ind <= cls_indent && !starts(s, "def ") && !starts(s, "async def ")) cls[0] = 0, cls_indent = -1;
        if (!*s || *s == '#') continue;
        if (starts(s, "class ")) { char *nm = first_ident_after(s, "class "); if (nm) { add_tag(tags,nm,path,lno,line,"c","class",NULL,NULL,false); snprintf(cls,sizeof(cls),"%s",nm); cls_indent=ind; free(nm);} }
        else if (starts(s, "def ") || starts(s, "async def ")) { char *nm = first_ident_after(s, starts(s,"async") ? "async def " : "def "); if (nm) { char scope[320]; snprintf(scope,sizeof(scope),"class:%s",cls); add_tag(tags,nm,path,lno,line,cls[0]?"m":"f",cls[0]?"member":"function",cls[0]?scope:NULL,NULL,false); free(nm);} }
        else if (ind == 0 && (isalpha((unsigned char)*s) || *s == '_')) { char *eq = strchr(s,'='); if (eq && eq > s && eq[-1] != '=' && eq[1] != '=') { char *tmp = strndup(s,(size_t)(eq-s)); char *nm=trim(tmp); if (ident_ok(nm)) add_tag(tags,nm,path,lno,line,"v","variable",NULL,NULL,false); free(tmp);} }
    }
    free(line); fclose(f);
}

static void parse_script(Tags *tags, const char *path) {
    FILE *f = fopen(path, "r"); if (!f) return; char *line = NULL; size_t n = 0; int lno = 0;
    while (getline(&line, &n, f) >= 0) {
        lno++; line[strcspn(line, "\r\n")] = 0; char *s = trim(line); if (!*s || *s == '#') continue;
        char *nm = NULL;
        if (starts(s,"function ")) nm = first_ident_after(s,"function ");
        else if (strstr(s,"()") && strchr(s,'{')) { char *p = strstr(s,"()"); while (p>s && isspace((unsigned char)p[-1])) p--; char *e=p; while(p>s&&(isalnum((unsigned char)p[-1])||p[-1]=='_'))p--; nm=strndup(p,(size_t)(e-p)); }
        if (nm && ident_ok(nm)) add_tag(tags,nm,path,lno,line,"f","function",NULL,NULL,false);
        free(nm);
    }
    free(line); fclose(f);
}

static void parse_java(Tags *tags, const char *path) {
    FILE *f = fopen(path, "r"); if (!f) return;
    char *line = NULL, scope[256] = ""; size_t n = 0; int lno = 0, depth = 0, scope_depth = -1;
    while (getline(&line, &n, f) >= 0) {
        lno++; line[strcspn(line, "\r\n")] = 0; char *s = trim(line); if (!*s || starts(s, "//")) continue;
        if (scope_depth >= 0 && depth < scope_depth) scope[0] = 0, scope_depth = -1;
        char *nm = NULL;
        if (starts(s, "package ")) {
            char *semi = strchr(s, ';'); char *p = s + 8; while (isspace((unsigned char)*p)) p++;
            if (semi && semi > p) { char *name = strndup(p, (size_t)(semi-p)); add_tag(tags, trim(name), path, lno, line, "p", "package", NULL, NULL, false); free(name); }
        }
        if ((nm = first_ident_after(s, "class "))) {
            add_tag(tags, nm, path, lno, line, "c", "class", NULL, NULL, false);
            snprintf(scope, sizeof(scope), "class:%s", nm); scope_depth = depth + (strchr(s, '{') ? 1 : 0); free(nm);
        } else if ((nm = first_ident_after(s, "interface "))) {
            add_tag(tags, nm, path, lno, line, "i", "interface", NULL, NULL, false);
            snprintf(scope, sizeof(scope), "interface:%s", nm); scope_depth = depth + (strchr(s, '{') ? 1 : 0); free(nm);
        } else if (scope[0] && strchr(s, '(') && (strchr(s, '{') || strchr(s, ';'))) {
            char *lp = strchr(s, '('), *p = lp; while (p > s && isspace((unsigned char)p[-1])) p--;
            char *e = p; while (p > s && (isalnum((unsigned char)p[-1]) || p[-1] == '_')) p--;
            char name[256]; snprintf(name, sizeof(name), "%.*s", (int)(e-p), p);
            if (ident_ok(name) && strcmp(name, "if") && strcmp(name, "for") && strcmp(name, "while"))
                add_tag(tags, name, path, lno, line, "m", "member", scope, NULL, false);
        } else if (scope[0] && strchr(s, ';') && !strchr(s, '(')) {
            char vcopy[4096]; snprintf(vcopy, sizeof(vcopy), "%s", s);
            char *semi = strchr(vcopy, ';'); if (semi) *semi = 0; char *eq = strchr(vcopy, '='); if (eq) *eq = 0;
            char *p = vcopy + strlen(vcopy); while (p > vcopy && isspace((unsigned char)p[-1])) p--;
            char *e = p; while (p > vcopy && (isalnum((unsigned char)p[-1]) || p[-1] == '_')) p--;
            char name[256]; snprintf(name, sizeof(name), "%.*s", (int)(e-p), p);
            if (ident_ok(name)) add_tag(tags, name, path, lno, line, "f", "field", scope, NULL, true);
        }
        for (char *p=s; *p; p++) { if (*p == '{') depth++; else if (*p == '}' && depth > 0) depth--; }
    }
    free(line); fclose(f);
}

static void parse_go(Tags *tags, const char *path) {
    FILE *f = fopen(path, "r"); if (!f) return;
    char *line = NULL, pkg[128] = ""; size_t n = 0; int lno = 0;
    while (getline(&line, &n, f) >= 0) {
        lno++; line[strcspn(line, "\r\n")] = 0; char *s = trim(line); if (!*s || starts(s, "//")) continue;
        char scope[256]; snprintf(scope, sizeof(scope), "package:%s", pkg);
        if (starts(s, "package ")) { char *nm=first_ident_after(s,"package "); if (nm) { snprintf(pkg,sizeof(pkg),"%s",nm); add_tag(tags,nm,path,lno,line,"p","package",NULL,NULL,false); free(nm);} }
        else if (starts(s, "const ") || starts(s, "var ")) { bool is_const=starts(s,"const "); char *nm=first_ident_after(s,is_const?"const ":"var "); if (nm) { add_tag(tags,nm,path,lno,line,is_const?"c":"v",is_const?"constant":"variable",*pkg?scope:NULL,NULL,false); free(nm);} }
        else if (starts(s, "type ")) {
            char *nm=first_ident_after(s,"type "); if (nm) {
                bool is_struct = strstr(s, " struct") != NULL; add_tag(tags,nm,path,lno,line,is_struct?"s":"t",is_struct?"struct":"typedef",*pkg?scope:NULL,NULL,false);
                if (is_struct && strchr(s,'{')) {
                    char *lb=strchr(s,'{'), *rb=strrchr(s,'}'); if (rb && rb>lb) {
                        char *body=strndup(lb+1,(size_t)(rb-lb-1)); char *x=trim(body);
                        char *sp=x; while (*sp && !isspace((unsigned char)*sp)) sp++;
                        char save=*sp; *sp=0; if (ident_ok(x)) { char sc[256]; snprintf(sc,sizeof(sc),"struct:%s.%s",pkg,nm); add_tag(tags,x,path,lno,line,"m","member",sc,NULL,false); } *sp=save; free(body);
                    }
                }
                free(nm);
            }
        } else if (starts(s, "func ")) {
            char *p = s + 5; char recv[128] = "";
            if (*p == '(') { char *rp = strchr(p, ')'); if (rp) { char *tmp=strndup(p+1,(size_t)(rp-p-1)); char *words=trim(tmp); char *sp=strrchr(words,' '); snprintf(recv,sizeof(recv),"%s",sp?trim(sp):words); free(tmp); p = rp + 1; } }
            while (isspace((unsigned char)*p)) p++; char *e=p; while (isalnum((unsigned char)*e)||*e=='_') e++;
            char name[256]; snprintf(name,sizeof(name),"%.*s",(int)(e-p),p);
            if (ident_ok(name)) { char sc[256]; if (*recv) snprintf(sc,sizeof(sc),"struct:%s.%s",pkg,recv); else snprintf(sc,sizeof(sc),"package:%s",pkg); add_tag(tags,name,path,lno,line,"f","function",*pkg?sc:NULL,NULL,false); }
        }
    }
    free(line); fclose(f);
}

static void parse_rust(Tags *tags, const char *path) {
    FILE *f = fopen(path, "r"); if (!f) return;
    char *line = NULL; size_t n = 0; int lno = 0;
    while (getline(&line, &n, f) >= 0) {
        lno++; line[strcspn(line, "\r\n")] = 0; char *s = trim(line); if (!*s || starts(s, "//")) continue;
        if (starts(s, "pub ")) s = trim(s + 4);
        char *nm = NULL; const char *k = NULL;
        if (starts(s,"fn ")) { nm=first_ident_after(s,"fn "); k="f"; }
        else if (starts(s,"mod ")) { nm=first_ident_after(s,"mod "); k="n"; }
        else if (starts(s,"struct ")) {
            nm=first_ident_after(s,"struct "); k="s";
            if (nm && strchr(s,'{')) {
                char *lb=strchr(s,'{'), *rb=strrchr(s,'}');
                if (rb && rb>lb) {
                    char *body=strndup(lb+1,(size_t)(rb-lb-1));
                    for (char *tok=strtok(body,","); tok; tok=strtok(NULL,",")) {
                        char *x=trim(tok), *colon=strchr(x,':'); if (colon) *colon=0;
                        x=trim(x); if (starts(x,"pub ")) x=trim(x+4);
                        if (ident_ok(x)) { char sc[256]; snprintf(sc,sizeof(sc),"struct:%s",nm); add_tag(tags,x,path,lno,line,"m","member",sc,NULL,false); }
                    }
                    free(body);
                }
            }
        } else if (starts(s,"enum ")) {
            nm=first_ident_after(s,"enum "); k="g";
            if (nm && strchr(s,'{')) {
                char *lb=strchr(s,'{'), *rb=strrchr(s,'}');
                if (rb && rb>lb) {
                    char *body=strndup(lb+1,(size_t)(rb-lb-1));
                    for (char *tok=strtok(body,","); tok; tok=strtok(NULL,",")) {
                        char *x=trim(tok); char name[128]; int i=0; while((isalnum((unsigned char)x[i])||x[i]=='_')&&i<127){name[i]=x[i];i++;} name[i]=0;
                        if (ident_ok(name)) { char sc[256]; snprintf(sc,sizeof(sc),"enum:%s",nm); add_tag(tags,name,path,lno,line,"e","enumerator",sc,NULL,false); }
                    }
                    free(body);
                }
            }
        } else if (starts(s,"const ") || starts(s,"static ")) { nm=first_ident_after(s, starts(s,"const ")?"const ":"static "); k="C"; }
        if (nm && k) add_tag(tags,nm,path,lno,line,k,long_kind(k),NULL,NULL,false);
        free(nm);
    }
    free(line); fclose(f);
}

static void parse_regex_lang(Tags *tags, const char *path, const char *lang) {
    FILE *f = fopen(path, "r"); if (!f) return; char *line = NULL; size_t n = 0; int lno = 0;
    while (getline(&line, &n, f) >= 0) {
        lno++; line[strcspn(line, "\r\n")] = 0; char *s = trim(line); char *nm = NULL; const char *k = "f";
        if (starts(s, "pub ")) s = trim(s + 4);
        if (starts(s,"class ")) {
            nm=first_ident_after(s,"class "); k="c";
            if (nm && strchr(s,'{')) {
                char *lb = strchr(s,'{'), *lp = strchr(lb,'(');
                if (lp) { char *p=lp; while(p>lb && isspace((unsigned char)p[-1])) p--; char *e=p; while(p>lb&&(isalnum((unsigned char)p[-1])||p[-1]=='_')) p--; if (e>p) { char m[256], sc[320]; snprintf(m,sizeof(m),"%.*s",(int)(e-p),p); snprintf(sc,sizeof(sc),"class:%s",nm); add_tag(tags,m,path,lno,line,"m","member",sc,NULL,false); } }
            }
        }
        else if (starts(s,"interface ")) { nm=first_ident_after(s,"interface "); k="i"; }
        else if (starts(s,"package ")) { nm=first_ident_after(s,"package "); k="p"; }
        else if (starts(s,"func ")) { nm=first_ident_after(s,"func "); k="f"; }
        else if (starts(s,"fn ")) { nm=first_ident_after(s,"fn "); k="f"; }
        else if (starts(s,"mod ")) { nm=first_ident_after(s,"mod "); k="M"; }
        else if (starts(s,"struct ")) { nm=first_ident_after(s,"struct "); k="s"; }
        else if (starts(s,"enum ")) { nm=first_ident_after(s,"enum "); k="g"; }
        else if (starts(s,"def ")) { nm=first_ident_after(s,"def "); k="f"; }
        else if (starts(s,"module ")) { nm=first_ident_after(s,"module "); k="M"; }
        else if (starts(s,"function ")) { nm=first_ident_after(s,"function "); k="f"; }
        else if (starts(s,"const ") || starts(s,"let ") || starts(s,"var ")) {
            nm=first_ident_after(s, starts(s,"const ")?"const ":(starts(s,"let ")?"let ":"var "));
            k=(strstr(s,"=>")||strstr(s,"function"))?"f":"v";
        }
        else if (strstr(s, "=>") || strstr(s, "function")) {
            char *eq = strchr(s, '='); if (eq) { char *tmp = strndup(s, (size_t)(eq-s)); char *x = trim(tmp); char *sp = strrchr(x, ' '); nm = xstrdup(sp ? sp + 1 : x); free(tmp); k="f"; }
        }
        if (nm && ident_ok(nm)) add_tag(tags,nm,path,lno,line,k,long_kind(k),NULL,NULL,false);
        (void)lang; free(nm);
    }
    free(line); fclose(f);
}

static const char *guess_lang(const char *path) {
    const char *e = ext_of(path);
    if (!strcmp(e,"c")||!strcmp(e,"h")||!strcmp(e,"cc")||!strcmp(e,"cpp")||!strcmp(e,"cxx")||!strcmp(e,"hpp")||!strcmp(e,"java")) return !strcmp(e,"java") ? "Java" : "C";
    if (!strcmp(e,"py")||!strcmp(e,"pyw")) return "Python";
    if (!strcmp(e,"js")||!strcmp(e,"jsx")) return "JavaScript";
    if (!strcmp(e,"ts")||!strcmp(e,"tsx")) return "TypeScript";
    if (!strcmp(e,"go")) return "Go"; if (!strcmp(e,"rs")) return "Rust";
    if (!strcmp(e,"rb")) return "Ruby"; if (!strcmp(e,"sh")||!strcmp(e,"bash")) return "Sh";
    if (!strcmp(e,"php")) return "PHP"; return "NONE";
}

static void parse_file(Tags *tags, const char *path, Opt *opt) {
    const char *lang = opt->language_force && strcmp(opt->language_force,"auto") ? opt->language_force : guess_lang(path);
    if (opt->print_language) { printf("%s\n", lang); return; }
    if (!strcmp(lang,"NONE")) return;
    if (opt->verbose) fprintf(stderr, "OPENING %s as %s language file\n", path, lang);
    if (!strcmp(lang,"Python")) parse_python(tags,path);
    else if (!strcmp(lang,"Java")) parse_java(tags,path);
    else if (!strcmp(lang,"Go")) parse_go(tags,path);
    else if (!strcmp(lang,"Rust")) parse_rust(tags,path);
    else if (!strcmp(lang,"C") || !strcmp(lang,"C++")) parse_c_like(tags,path);
    else if (!strcmp(lang,"Sh") || !strcmp(lang,"Bash")) parse_script(tags,path);
    else parse_regex_lang(tags,path,lang);
}

static bool excluded(Opt *opt, const char *p) {
    char *b = basename_dup(p); bool r = false;
    for (size_t i=0;i<opt->excludes.n;i++) if (!fnmatch(opt->excludes.v[i], p, 0) || !fnmatch(opt->excludes.v[i], b, 0)) r = true;
    free(b); return r;
}

static void collect_path(Strs *files, const char *p, Opt *opt, int depth) {
    if (excluded(opt,p)) return;
    struct stat st; if (stat(p,&st) != 0) return;
    if (S_ISDIR(st.st_mode)) {
        if (!opt->recurse && depth >= 0) return;
        DIR *d = opendir(p); if (!d) return; struct dirent *de;
        while ((de = readdir(d))) {
            if (!strcmp(de->d_name,".") || !strcmp(de->d_name,"..")) continue;
            char buf[4096]; snprintf(buf,sizeof(buf),"%s/%s",p,de->d_name); collect_path(files,buf,opt,depth+1);
        }
        closedir(d);
    } else if (S_ISREG(st.st_mode)) strs_add(files,p);
}

static int tag_cmp(const void *a, const void *b) {
    const Tag *x = a, *y = b; int c = strcmp(x->name,y->name); if (c) return c;
    c = strcmp(x->path,y->path); if (c) return c; return x->line - y->line;
}

static void print_tag(FILE *out, Tag *g, Opt *opt) {
    if (opt->json) {
        fprintf(out, "{\"_type\": \"tag\", \"name\": \"%s\", \"path\": \"%s\", \"pattern\": \"%s\"", g->name,g->path,g->pattern);
        if (g->file_scope) fprintf(out, ", \"file\": true");
        if (g->scope) { char *c=strchr(g->scope,':'); fprintf(out, ", \"scope\": \"%s\"", c?c+1:g->scope); }
        if (g->typeref) fprintf(out, ", \"typeref\": \"%s\"", g->typeref);
        fprintf(out, ", \"kind\": \"%s\"}\n", g->kind_long);
    } else if (opt->xref) {
        fprintf(out, "%-16s %-12s %4d %-16s %s\n", g->name, g->kind_long, g->line, g->path, g->pattern+2);
    } else if (opt->format1) {
        fprintf(out, "%s\t%s\t%s\n", g->name,g->path,g->pattern);
    } else {
        fprintf(out, "%s\t%s\t%s;\"\t%s", g->name,g->path,g->pattern,g->kind);
        if (opt->line_field) fprintf(out, "\tline:%d", g->line);
        if (opt->lang_field) fprintf(out, "\tlanguage:%s", guess_lang(g->path));
        if (g->scope) fprintf(out, "\t%s", g->scope);
        if (g->typeref) fprintf(out, "\ttyperef:%s", g->typeref);
        if (g->file_scope) fprintf(out, "\tfile:");
        fputc('\n', out);
    }
}

static void output_tags(Tags *tags, Opt *opt, FILE *out) {
    if (opt->sort) qsort(tags->v, tags->n, sizeof(Tag), tag_cmp);
    for (size_t i=0;i<tags->n;i++) print_tag(out, &tags->v[i], opt);
}

static void version(void) {
    puts("Universal Ctags 6.2.0(d922013), Copyright (C) 2015-2025 Universal Ctags Team");
    puts("Universal Ctags is derived from Exuberant Ctags.");
    puts("Exuberant Ctags 5.8, Copyright (C) 1996-2009 Darren Hiebert");
    puts("  Compiled: Apr 20 2026, 16:52:56");
    puts("  URL: https://ctags.io/");
    puts("  Output version: 1.1");
    puts("  Optional compiled features: +wildcards, +regex, +iconv, +option-directory, +xpath, +json, +interactive, +sandbox, +yaml, +packcc, +optscript");
}

static void help(void) {
    version();
    puts("\nUsage: executable [options] [file(s)]\n");
    puts("Input/Output Options\n  --exclude=<pattern>\n  --filter[=(yes|no)]\n  --recurse[=(yes|no)]\n  -R   Equivalent to --recurse.\n  -L <file>\n  --append[=(yes|no)]\n  -a   Append the tags to an existing tag file.\n  -f <tagfile>\n  -o   Alternative for -f.\n");
    puts("Output Format Options\n  --format=(1|2)\n  --output-format=(u-ctags|e-ctags|etags|xref|json)\n  -x   Print a tabular cross reference file to standard output.\n  --sort=(yes|no|foldcase)\n  -u   Equivalent to --sort=no.\n");
    puts("Language Selection and Mapping Options\n  --language-force=(<language>|auto)\n  --languages=[+|-](<list>|all)\n  --list-languages\n  --list-kinds[=(<language>|all)]\n  --list-fields[=(<language>|all)]\n  --list-extras[=(<language>|all)]\n");
    puts("Miscellaneous Options\n  --help\n  -?   Print this option summary.\n  --help-full\n  --license\n  --print-language\n  --totals[=(yes|no|extra)]\n  --verbose[=(yes|no)]\n  --version[=<language>]\n");
}

static void list_languages(void) {
    const char *langs[]={"Abaqus","Abc","Ada","Asm","Awk","C","C#","C++","CMake","CSS","Go","HTML","Java","JavaScript","JSON","Lua","Make","Markdown","PHP","Python","Ruby","Rust","Sh","TypeScript","XML","Yaml",NULL};
    for (int i=0; langs[i]; i++) puts(langs[i]);
}
static void list_features(void) { puts("iconv\ninteractive\njson\noption-directory\noptscript\npackcc\nregex\nsandbox\nwildcards\nxpath\nyaml"); }
static void list_formats(void) { puts("#OFORMAT DEFAULT AVAILABLE NULLTAG \ne-ctags       no       yes      no \netags         no       yes      no \njson          no       yes     yes \nu-ctags      yes       yes      no \nxref          no       yes     yes "); }
static void list_kinds(void) { puts("d  macro definitions\ne  enumerators (values inside an enumeration)\nf  function definitions\ng  enumeration names\nm  struct, and union members\ns  structure names\nt  typedefs\nu  union names\nv  variable definitions\nc  classes"); }
static void list_fields(void) { puts("#LETTER NAME ENABLED\nN name yes\nF input yes\nP pattern yes\nf file yes\nk kind yes\nn line no\ns scope yes\nt typeref yes\nz kind no"); }
static void list_extras(void) { puts("#LETTER NAME ENABLED\nF fileScope yes\nf inputFile no\np pseudo yes\nq qualified no\nr reference no"); }

static bool yes_arg(const char *s) { return !s || !strcmp(s,"yes") || !strcmp(s,"1") || !strcmp(s,"true"); }

int main(int argc, char **argv) {
    Opt opt = {.tagfile="tags", .sort=true}; Strs inputs = {0};
    for (int i=1;i<argc;i++) {
        char *a = argv[i];
        if (!strcmp(a,"--help") || !strcmp(a,"-?") || !strcmp(a,"--help-full")) { help(); return 0; }
        else if (starts(a,"--version")) { version(); return 0; }
        else if (!strcmp(a,"--license")) { puts("This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License."); return 0; }
        else if (!strcmp(a,"--list-languages")) { list_languages(); return 0; }
        else if (starts(a,"--list-kinds")) { list_kinds(); return 0; }
        else if (starts(a,"--list-fields")) { list_fields(); return 0; }
        else if (starts(a,"--list-extras")) { list_extras(); return 0; }
        else if (!strcmp(a,"--list-features")) { list_features(); return 0; }
        else if (!strcmp(a,"--list-output-formats")) { list_formats(); return 0; }
        else if (starts(a,"--list-")) return 0;
        else if (!strcmp(a,"-R")) opt.recurse = true;
        else if (starts(a,"--recurse")) opt.recurse = !strstr(a,"=no");
        else if (!strcmp(a,"-a")) opt.append = true;
        else if (!strcmp(a,"-u")) opt.sort = false;
        else if (!strcmp(a,"-x")) opt.xref = true, opt.to_stdout = true;
        else if (!strcmp(a,"-f") || !strcmp(a,"-o")) { if (++i < argc) opt.tagfile = argv[i]; }
        else if (starts(a,"-f") && strlen(a)>2) opt.tagfile = a+2;
        else if (starts(a,"--output-format=")) { char *v=a+16; opt.json=!strcmp(v,"json"); opt.xref=!strcmp(v,"xref"); if (opt.json||opt.xref) opt.to_stdout = true; }
        else if (starts(a,"--format=1")) opt.format1 = true;
        else if (starts(a,"--sort=no")) opt.sort = false;
        else if (starts(a,"--filter")) opt.filter = yes_arg(strchr(a,'=') ? strchr(a,'=')+1 : NULL), opt.to_stdout = true;
        else if (starts(a,"--filter-terminator=")) opt.filter_term = a + 20;
        else if (starts(a,"--language-force=")) opt.language_force = a + 17;
        else if (starts(a,"--fields=")) { if (strchr(a,'n')) opt.line_field = true; if (strchr(a,'l')) opt.lang_field = true; }
        else if (starts(a,"--exclude=")) strs_add(&opt.excludes, a+10);
        else if (!strcmp(a,"--print-language")) opt.print_language = true;
        else if (starts(a,"--totals")) opt.totals = !strstr(a,"=no");
        else if (!strcmp(a,"-V") || starts(a,"--verbose")) opt.verbose = !strstr(a,"=no");
        else if (!strcmp(a,"-L")) {
            if (++i < argc) {
                FILE *lf = !strcmp(argv[i],"-") ? stdin : fopen(argv[i],"r"); char *l=NULL; size_t n=0;
                if (lf) { while (getline(&l,&n,lf)>=0) { l[strcspn(l,"\r\n")]=0; if (*trim(l)) strs_add(&inputs, trim(l)); } if (lf!=stdin) fclose(lf); free(l); }
            }
        } else if (a[0] == '-' && strcmp(a,"-")) {
            /* accepted but ignored compatibility option */
        } else strs_add(&inputs, a);
    }
    if (!strcmp(opt.tagfile, "-")) opt.to_stdout = true;
    FILE *out = stdout;
    if (!opt.to_stdout && !opt.print_language) { out = fopen(opt.tagfile, opt.append ? "a" : "w"); if (!out) { perror(opt.tagfile); return 1; } }
    size_t total_files = 0, total_tags = 0;
    if (opt.filter) {
        char *l=NULL; size_t n=0;
        fprintf(stderr, "executable: Warning: filter mode ignores output tag file name\n");
        while (getline(&l,&n,stdin)>=0) {
            l[strcspn(l,"\r\n")]=0; char *p=trim(l); if (!*p) continue;
            Tags tags={0}; parse_file(&tags,p,&opt); output_tags(&tags,&opt,out); if (opt.filter_term) fputs(opt.filter_term,out);
        }
        free(l);
    } else {
        Strs files = {0};
        for (size_t i=0;i<inputs.n;i++) collect_path(&files, inputs.v[i], &opt, 0);
        Tags tags = {0};
        for (size_t i=0;i<files.n;i++) { size_t before=tags.n; parse_file(&tags, files.v[i], &opt); total_files++; total_tags += tags.n - before; }
        if (!opt.print_language) output_tags(&tags,&opt,out);
    }
    if (out != stdout) fclose(out);
    if (opt.totals) fprintf(stderr, "%zu files, %zu tags\n", total_files, total_tags);
    return 0;
}
