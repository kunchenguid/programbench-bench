#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <libgen.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef struct { char *data; size_t len, cap; } Str;
typedef struct { char *title; char *path; int level; } Chapter;
typedef struct { Chapter *v; size_t len, cap; } Chapters;

static const char *VERSION = "mdbook v0.5.0-alpha.1";

static void die(const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap);
    exit(1);
}

static char *xstrdup(const char *s) {
    char *r = strdup(s ? s : "");
    if (!r) die("out of memory\n");
    return r;
}

static void sappend(Str *s, const char *text) {
    size_t n = strlen(text);
    if (s->len + n + 1 > s->cap) {
        s->cap = (s->len + n + 1) * 2 + 64;
        s->data = realloc(s->data, s->cap);
        if (!s->data) die("out of memory\n");
    }
    memcpy(s->data + s->len, text, n + 1);
    s->len += n;
}

static void sapprintf(Str *s, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    char stack[4096];
    int n = vsnprintf(stack, sizeof stack, fmt, ap);
    va_end(ap);
    if (n < 0) return;
    if ((size_t)n < sizeof stack) { sappend(s, stack); return; }
    char *buf = malloc((size_t)n + 1);
    if (!buf) die("out of memory\n");
    va_start(ap, fmt);
    vsnprintf(buf, (size_t)n + 1, fmt, ap);
    va_end(ap);
    sappend(s, buf);
    free(buf);
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)n + 1);
    if (!buf) die("out of memory\n");
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = 0;
    fclose(f);
    return buf;
}

static int write_file(const char *path, const char *data) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    fwrite(data, 1, strlen(data), f);
    fclose(f);
    return 0;
}

static char *path_join(const char *a, const char *b) {
    if (!a || !*a) return xstrdup(b);
    if (!b || !*b) return xstrdup(a);
    Str s = {0};
    sappend(&s, a);
    if (a[strlen(a)-1] != '/') sappend(&s, "/");
    sappend(&s, b);
    return s.data;
}

static void mkdir_p(const char *path) {
    char *tmp = xstrdup(path);
    for (char *p = tmp + 1; *p; p++) if (*p == '/') {
        *p = 0; mkdir(tmp, 0777); *p = '/';
    }
    if (*tmp) mkdir(tmp, 0777);
    free(tmp);
}

static void ensure_parent(const char *path) {
    char *tmp = xstrdup(path);
    char *slash = strrchr(tmp, '/');
    if (slash) { *slash = 0; mkdir_p(tmp); }
    free(tmp);
}

static bool exists(const char *p) { struct stat st; return stat(p, &st) == 0; }
static bool is_dir(const char *p) { struct stat st; return stat(p, &st) == 0 && S_ISDIR(st.st_mode); }

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static char *html_escape(const char *in) {
    Str s = {0};
    for (const char *p = in; *p; p++) {
        if (*p == '&') sappend(&s, "&amp;");
        else if (*p == '<') sappend(&s, "&lt;");
        else if (*p == '>') sappend(&s, "&gt;");
        else if (*p == '"') sappend(&s, "&quot;");
        else { char c[2] = {*p,0}; sappend(&s,c); }
    }
    return s.data ? s.data : xstrdup("");
}

static char *replace_ext_html(const char *p) {
    if (strstr(p, "://") || p[0] == '#' || !strncmp(p, "mailto:", 7)) return xstrdup(p);
    char *r = xstrdup(p);
    char *dot = strrchr(r, '.');
    if (dot && strcmp(dot, ".html") == 0) {}
    else if (dot && strcmp(dot, ".md") == 0) {
        size_t prefix = (size_t)(dot - r);
        char *nr = malloc(prefix + 6);
        if (!nr) die("out of memory\n");
        memcpy(nr, r, prefix);
        strcpy(nr + prefix, ".html");
        free(r);
        r = nr;
    }
    else {
        r = realloc(r, strlen(r) + 6);
        strcat(r, ".html");
    }
    if (strcmp(r, "README.html") == 0) { free(r); return xstrdup("index.html"); }
    size_t n = strlen(r);
    if (n > 12 && strcmp(r + n - 12, "/README.html") == 0) strcpy(r + n - 12, "/index.html");
    return r;
}

static char *config_value(const char *root, const char *section, const char *key, const char *def) {
    char *cfg = path_join(root, "book.toml");
    char *txt = read_file(cfg); free(cfg);
    if (!txt) return xstrdup(def);
    bool in = !section;
    char *save = NULL;
    for (char *line = strtok_r(txt, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *t = trim(line);
        if (*t == '[') {
            in = false;
            char want[128]; snprintf(want, sizeof want, "[%s]", section);
            if (strcmp(t, want) == 0) in = true;
            continue;
        }
        if (in && strncmp(t, key, strlen(key)) == 0) {
            char *eq = strchr(t, '=');
            if (eq) {
                char *v = trim(eq + 1);
                if (*v == '"') {
                    v++;
                    char *q = strchr(v, '"'); if (q) *q = 0;
                }
                char *out = xstrdup(v); free(txt); return out;
            }
        }
    }
    free(txt);
    return xstrdup(def);
}

static void chapters_add(Chapters *c, const char *title, const char *path, int level) {
    if (!path || !*path) return;
    if (c->len == c->cap) {
        c->cap = c->cap ? c->cap * 2 : 16;
        c->v = realloc(c->v, c->cap * sizeof *c->v);
        if (!c->v) die("out of memory\n");
    }
    c->v[c->len].title = xstrdup(title);
    c->v[c->len].path = xstrdup(path);
    c->v[c->len].level = level;
    c->len++;
}

static Chapters parse_summary(const char *srcdir) {
    Chapters c = {0};
    char *sp = path_join(srcdir, "SUMMARY.md");
    char *txt = read_file(sp); free(sp);
    if (!txt) return c;
    char *save = NULL;
    for (char *line = strtok_r(txt, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *lb = strchr(line, '['), *rb = lb ? strchr(lb, ']') : NULL;
        char *lp = rb ? strchr(rb, '(') : NULL, *rp = lp ? strchr(lp, ')') : NULL;
        if (!lb || !rb || !lp || !rp) continue;
        *rb = 0; *rp = 0;
        char *path = trim(lp + 1);
        if (!*path || strstr(path, "://")) continue;
        int level = 0; for (char *p = line; p < lb; p++) if (*p == ' ') level++;
        chapters_add(&c, lb + 1, path, level / 2);
    }
    free(txt);
    return c;
}

static char *inline_md(const char *line) {
    Str out = {0};
    for (size_t i = 0; line[i]; ) {
        if (line[i] == '[') {
            const char *rb = strchr(line+i, ']');
            const char *lp = rb ? strchr(rb, '(') : NULL;
            const char *rp = lp ? strchr(lp, ')') : NULL;
            if (rb && lp == rb + 1 && rp) {
                char *text = strndup(line+i+1, (size_t)(rb-line-i-1));
                char *href = strndup(lp+1, (size_t)(rp-lp-1));
                char *h2 = replace_ext_html(href);
                char *et = html_escape(text), *eh = html_escape(h2);
                sapprintf(&out, "<a href=\"%s\">%s</a>", eh, et);
                free(text); free(href); free(h2); free(et); free(eh);
                i = (size_t)(rp - line + 1); continue;
            }
        }
        if (line[i] == '`') {
            const char *e = strchr(line+i+1, '`');
            if (e) {
                char *code = strndup(line+i+1, (size_t)(e-line-i-1));
                char *ec = html_escape(code);
                sapprintf(&out, "<code>%s</code>", ec);
                free(code); free(ec); i = (size_t)(e-line+1); continue;
            }
        }
        char ch[2] = {line[i++], 0};
        char *e = html_escape(ch); sappend(&out, e); free(e);
    }
    return out.data ? out.data : xstrdup("");
}

static char *markdown_to_html(const char *md) {
    Str out = {0};
    bool in_code = false, in_ul = false;
    char *copy = xstrdup(md), *save = NULL;
    for (char *line = strtok_r(copy, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *t = trim(line);
        if (strncmp(t, "```", 3) == 0) {
            if (!in_code) { if (in_ul) { sappend(&out, "</ul>\n"); in_ul=false; } sappend(&out, "<pre><code>"); in_code = true; }
            else { sappend(&out, "</code></pre>\n"); in_code = false; }
            continue;
        }
        if (in_code) { char *e = html_escape(line); sappend(&out, e); sappend(&out, "\n"); free(e); continue; }
        if (!*t) { if (in_ul) { sappend(&out, "</ul>\n"); in_ul=false; } continue; }
        int h = 0; while (t[h] == '#') h++;
        if (h > 0 && h <= 6 && t[h] == ' ') {
            if (in_ul) { sappend(&out, "</ul>\n"); in_ul=false; }
            char *body = inline_md(trim(t+h));
            sapprintf(&out, "<h%d id=\"%s\"><a class=\"header\" href=\"#%s\">%s</a></h%d>\n", h, body, body, body, h);
            free(body); continue;
        }
        if ((t[0] == '-' || t[0] == '*') && t[1] == ' ') {
            if (!in_ul) { sappend(&out, "<ul>\n"); in_ul = true; }
            char *body = inline_md(trim(t+2));
            sapprintf(&out, "<li>%s</li>\n", body); free(body); continue;
        }
        if (in_ul) { sappend(&out, "</ul>\n"); in_ul=false; }
        char *body = inline_md(t);
        sapprintf(&out, "<p>%s</p>\n", body); free(body);
    }
    if (in_code) sappend(&out, "</code></pre>\n");
    if (in_ul) sappend(&out, "</ul>\n");
    free(copy);
    return out.data ? out.data : xstrdup("");
}

static void log_line(const char *level, const char *module, const char *msg) {
    time_t now = time(NULL); struct tm tm; localtime_r(&now, &tm);
    char ts[32]; strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", &tm);
    printf("%s [%s] (%s): %s\n", ts, level, module, msg);
}

static void remove_rf(const char *path) {
    struct stat st; if (lstat(path, &st) != 0) return;
    if (S_ISDIR(st.st_mode)) {
        DIR *d = opendir(path); if (!d) return;
        struct dirent *e;
        while ((e = readdir(d))) {
            if (!strcmp(e->d_name,".") || !strcmp(e->d_name,"..")) continue;
            char *p = path_join(path, e->d_name); remove_rf(p); free(p);
        }
        closedir(d); rmdir(path);
    } else unlink(path);
}

static void copy_file(const char *src, const char *dst) {
    FILE *a = fopen(src, "rb"); if (!a) return;
    ensure_parent(dst);
    FILE *b = fopen(dst, "wb"); if (!b) { fclose(a); return; }
    char buf[8192]; size_t n;
    while ((n = fread(buf,1,sizeof buf,a))) fwrite(buf,1,n,b);
    fclose(a); fclose(b);
}

static void copy_non_md(const char *srcroot, const char *sub, const char *dstroot) {
    char *dirp = *sub ? path_join(srcroot, sub) : xstrdup(srcroot);
    DIR *d = opendir(dirp); if (!d) { free(dirp); return; }
    struct dirent *e;
    while ((e = readdir(d))) {
        if (!strcmp(e->d_name,".") || !strcmp(e->d_name,"..")) continue;
        char *rel = *sub ? path_join(sub, e->d_name) : xstrdup(e->d_name);
        char *sp = path_join(srcroot, rel);
        if (is_dir(sp)) copy_non_md(srcroot, rel, dstroot);
        else {
            const char *dot = strrchr(e->d_name, '.');
            if (!dot || strcmp(dot, ".md") != 0) {
                char *dp = path_join(dstroot, rel); copy_file(sp, dp); free(dp);
            }
        }
        free(rel); free(sp);
    }
    closedir(d); free(dirp);
}

static void write_assets(const char *dst) {
    const char *files[] = {"book.js","searchindex.js","searcher.js","toc.js","highlight.js","elasticlunr.min.js","mark.min.js","clipboard.min.js","highlight.css","tomorrow-night.css","ayu-highlight.css","favicon.svg","favicon.png","404.html","print.html","toc.html",".nojekyll",NULL};
    for (int i=0; files[i]; i++) {
        char *p = path_join(dst, files[i]); ensure_parent(p);
        if (strstr(files[i], ".html")) write_file(p, "<!DOCTYPE html><html><body></body></html>\n");
        else if (strstr(files[i], ".css")) write_file(p, "body{font-family:sans-serif;max-width:900px;margin:auto;padding:2rem}pre{background:#f5f5f5;padding:1rem;overflow:auto}.sidebar{float:left}\n");
        else if (strstr(files[i], ".svg")) write_file(p, "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 16 16\"><text y=\"14\">M</text></svg>\n");
        else write_file(p, "");
        free(p);
    }
    const char *css[] = {"css/variables.css","css/general.css","css/chrome.css","css/print.css","fonts/fonts.css","fonts/OPEN-SANS-LICENSE.txt","fonts/SOURCE-CODE-PRO-LICENSE.txt",NULL};
    for (int i=0; css[i]; i++) { char *p = path_join(dst, css[i]); ensure_parent(p); write_file(p, ""); free(p); }
}

static void render_page(const char *dst, const char *relhtml, const char *book_title, const char *chap_title, const char *body, Chapters *chs) {
    char *outp = path_join(dst, relhtml); ensure_parent(outp);
    int depth = 0; for (const char *p = relhtml; *p; p++) if (*p == '/') depth++;
    Str root = {0}; for (int i=0;i<depth;i++) sappend(&root, "../");
    Str nav = {0}; sappend(&nav, "<ol class=\"chapter\">\n");
    for (size_t i=0;i<chs->len;i++) {
        char *h = replace_ext_html(chs->v[i].path);
        char *et = html_escape(chs->v[i].title);
        sapprintf(&nav, "<li class=\"chapter-item\"><a href=\"%s%s\">%s</a></li>\n", root.data?root.data:"", h, et);
        free(h); free(et);
    }
    sappend(&nav, "</ol>\n");
    char *ebt = html_escape(book_title), *ect = html_escape(chap_title);
    Str page = {0};
    sapprintf(&page, "<!DOCTYPE HTML>\n<html lang=\"en\" class=\"light sidebar-visible\" dir=\"ltr\">\n<head>\n<meta charset=\"UTF-8\">\n<title>%s - %s</title>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n<link rel=\"stylesheet\" href=\"%scss/general.css\">\n<link rel=\"stylesheet\" href=\"%scss/chrome.css\">\n<script>const path_to_root = \"%s\"; window.path_to_searchindex_js = \"%ssearchindex.js\";</script>\n</head>\n<body>\n<nav id=\"sidebar\" class=\"sidebar\">%s</nav>\n<div id=\"page-wrapper\" class=\"page-wrapper\"><div class=\"page\"><div id=\"menu-bar\" class=\"menu-bar\"><h1 class=\"menu-title\">%s</h1></div>\n<main><h1 class=\"chapter-title\">%s</h1>\n%s\n</main></div></div>\n</body></html>\n", ect, ebt, root.data?root.data:"", root.data?root.data:"", root.data?root.data:"", root.data?root.data:"", nav.data?nav.data:"", ebt, ect, body);
    write_file(outp, page.data);
    free(outp); free(ebt); free(ect); free(root.data); free(nav.data); free(page.data);
}

static int cmd_build(const char *root, const char *dest_arg) {
    char *srcname = config_value(root, "book", "src", "src");
    char *title = config_value(root, "book", "title", "mdBook Documentation");
    char *builddir = dest_arg ? xstrdup(dest_arg) : config_value(root, "build", "build-dir", "book");
    char *srcdir = path_join(root, srcname);
    char *dest = builddir[0]=='/' ? xstrdup(builddir) : path_join(root, builddir);
    log_line("INFO", "mdbook_driver::mdbook", "Book building has started");
    mkdir_p(dest);
    Chapters chs = parse_summary(srcdir);
    for (size_t i=0;i<chs.len;i++) {
        char *mdp = path_join(srcdir, chs.v[i].path);
        if (!exists(mdp)) {
            ensure_parent(mdp);
            Str stub={0}; sapprintf(&stub, "# %s\n", chs.v[i].title);
            write_file(mdp, stub.data); free(stub.data);
        }
        char *md = read_file(mdp);
        char *html = markdown_to_html(md ? md : "");
        char *rel = replace_ext_html(chs.v[i].path);
        render_page(dest, rel, title, chs.v[i].title, html, &chs);
        free(mdp); free(md); free(html); free(rel);
    }
    copy_non_md(srcdir, "", dest);
    write_assets(dest);
    log_line("INFO", "mdbook_driver::mdbook", "Running the html backend");
    char msg[4096]; snprintf(msg, sizeof msg, "HTML book written to `%s`", dest);
    log_line("INFO", "mdbook_html::html_handlebars::hbs_renderer", msg);
    free(srcname); free(title); free(builddir); free(srcdir); free(dest);
    return 0;
}

static int cmd_clean(const char *root, const char *dest_arg) {
    char *builddir = dest_arg ? xstrdup(dest_arg) : config_value(root, "build", "build-dir", "book");
    char *dest = builddir[0]=='/' ? xstrdup(builddir) : path_join(root, builddir);
    remove_rf(dest);
    free(builddir); free(dest);
    return 0;
}

static int cmd_init(const char *dir, const char *title, const char *ignore, bool theme) {
    mkdir_p(dir);
    char *src = path_join(dir, "src"); mkdir_p(src);
    char *book = path_join(dir, "book"); mkdir_p(book); free(book);
    if (!title) title = "My First Book";
    char *bt = path_join(dir, "book.toml");
    if (!exists(bt)) {
        Str s={0}; sapprintf(&s, "[book]\nauthors = []\nlanguage = \"en\"\nsrc = \"src\"\ntitle = \"%s\"\n", title);
        write_file(bt, s.data); free(s.data);
    }
    char *sum = path_join(src, "SUMMARY.md");
    if (!exists(sum)) write_file(sum, "# Summary\n\n- [Chapter 1](./chapter_1.md)\n");
    char *ch = path_join(src, "chapter_1.md");
    if (!exists(ch)) write_file(ch, "# Chapter 1\n");
    if (ignore && strcmp(ignore, "git") == 0) { char *gi = path_join(dir, ".gitignore"); write_file(gi, "book\n"); free(gi); }
    if (theme) { char *td = path_join(src, "theme"); mkdir_p(td); char *ih = path_join(td, "index.hbs"); write_file(ih, "{{ content }}\n"); free(ih); free(td); }
    log_line("INFO", "mdbook_driver::init", "Creating a new book with stub content");
    printf("\nAll done, no errors...\n");
    free(src); free(bt); free(sum); free(ch);
    return 0;
}

static int cmd_test(const char *root, const char *chapter) {
    (void)chapter;
    char *srcname = config_value(root, "book", "src", "src");
    char *srcdir = path_join(root, srcname);
    Chapters chs = parse_summary(srcdir);
    int failures = 0, tests = 0;
    for (size_t i=0;i<chs.len;i++) {
        char *mdp = path_join(srcdir, chs.v[i].path);
        char *md = read_file(mdp); free(mdp);
        if (!md) continue;
        char *p = md;
        while ((p = strstr(p, "```"))) {
            char *lang = p + 3; char *nl = strchr(lang, '\n'); if (!nl) break;
            bool rust = (strncmp(lang, "rust", 4)==0 || *lang=='\n' || *lang==0);
            bool ign = strstr(lang, "ignore") && strstr(lang, "ignore") < nl;
            char *end = strstr(nl+1, "```"); if (!end) break;
            if (rust && !ign) {
                tests++;
                char *code = strndup(nl+1, (size_t)(end-nl-1));
                char tmpl[256]; snprintf(tmpl, sizeof tmpl, "/tmp/mdbook_test_%d_XXXXXX.rs", getpid());
                int fd = mkstemps(tmpl, 3);
                if (fd >= 0) {
                    FILE *f = fdopen(fd, "w");
                    fputs(code, f); fclose(f);
                    char cmd[512]; snprintf(cmd, sizeof cmd, "rustc --edition=2018 --test '%s' -o /tmp/mdbook_test_bin_%d >/dev/null 2>&1", tmpl, getpid());
                    int st = system(cmd);
                    if (st != 0) failures++;
                    unlink(tmpl);
                }
                free(code);
            }
            p = end + 3;
        }
        free(md);
    }
    printf("Testing %d code samples\n", tests);
    if (failures) fprintf(stderr, "%d test(s) failed\n", failures);
    free(srcname); free(srcdir);
    return failures ? 101 : 0;
}

static void main_help(FILE *f, const char *prog) {
    fprintf(f, "Creates a book from markdown files\n\nUsage: %s [COMMAND]\n\nCommands:\n  init         Creates the boilerplate structure and files for a new book\n  build        Builds a book from its markdown files\n  test         Tests that a book's Rust code samples compile\n  clean        Deletes a built book\n  completions  Generate shell completions for your shell to stdout\n  watch        Watches a book's files and rebuilds it on changes\n  serve        Serves a book at http://localhost:3000, and rebuilds it on changes\n  help         Print this message or the help of the given subcommand(s)\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n\nFor more information about a specific command, try `mdbook <command> --help`\nThe source code for mdBook is available at: https://github.com/rust-lang/mdBook\n", prog);
}

static void sub_help(const char *prog, const char *cmd) {
    if (!strcmp(cmd,"init")) printf("Creates the boilerplate structure and files for a new book\n\nUsage: %s init [OPTIONS] [dir]\n\nArguments:\n  [dir]  Directory to create the book in\n         (Defaults to the current directory when omitted)\n\nOptions:\n      --theme            Copies the default theme into your source folder\n      --force            Skips confirmation prompts\n      --title <title>    Sets the book title\n      --ignore <ignore>  Creates a VCS ignore file (i.e. .gitignore) [possible values: none, git]\n  -h, --help             Print help\n  -V, --version          Print version\n", prog);
    else if (!strcmp(cmd,"build")||!strcmp(cmd,"test")||!strcmp(cmd,"clean")||!strcmp(cmd,"watch")) {
        const char *desc = !strcmp(cmd,"build")?"Builds a book from its markdown files":!strcmp(cmd,"test")?"Tests that a book's Rust code samples compile":!strcmp(cmd,"clean")?"Deletes a built book":"Watches a book's files and rebuilds it on changes";
        printf("%s\n\nUsage: %s %s [OPTIONS] [dir]\n\nArguments:\n  [dir]  Root directory for the book\n         (Defaults to the current directory when omitted)\n\nOptions:\n  -d, --dest-dir <dest-dir>  Output directory for the book\n                             Relative paths are interpreted relative to the book's root directory.\n                             If omitted, mdBook uses build.build-dir from book.toml or defaults to\n                             `./book`.\n", desc, prog, cmd);
        if (!strcmp(cmd,"build")||!strcmp(cmd,"watch")) printf("  -o, --open                 Opens the compiled book in a web browser\n");
        if (!strcmp(cmd,"test")) printf("  -c, --chapter <chapter>    \n  -L, --library-path <dir>   A comma-separated list of directories to add to the crate search path\n                             when building tests\n");
        if (!strcmp(cmd,"watch")) printf("      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:\n                             poll, native]\n");
        printf("  -h, --help                 Print help\n  -V, --version              Print version\n");
    } else if (!strcmp(cmd,"serve")) printf("Serves a book at http://localhost:3000, and rebuilds it on changes\n\nUsage: %s serve [OPTIONS] [dir]\n\nArguments:\n  [dir]  Root directory for the book\n         (Defaults to the current directory when omitted)\n\nOptions:\n  -d, --dest-dir <dest-dir>  Output directory for the book\n                             Relative paths are interpreted relative to the book's root directory.\n                             If omitted, mdBook uses build.build-dir from book.toml or defaults to\n                             `./book`.\n  -n, --hostname <hostname>  Hostname to listen on for HTTP connections [default: localhost]\n  -p, --port <port>          Port to use for HTTP connections [default: 3000]\n  -o, --open                 Opens the compiled book in a web browser\n      --watcher <watcher>    The filesystem watching technique [default: poll] [possible values:\n                             poll, native]\n  -h, --help                 Print help\n  -V, --version              Print version\n", prog);
    else if (!strcmp(cmd,"completions")) printf("Generate shell completions for your shell to stdout\n\nUsage: %s completions <SHELL>\n\nArguments:\n  <SHELL>  the shell to generate completions for [possible values: bash, elvish, fish, powershell,\n           zsh]\n\nOptions:\n  -h, --help     Print help\n  -V, --version  Print version\n", prog);
}

static void completions(const char *shell) {
    if (!strcmp(shell,"bash")) printf("_mdbook() {\n    COMPREPLY=( $(compgen -W \"-h -V --help --version init build test clean completions watch serve help\" -- \"${COMP_WORDS[COMP_CWORD]}\") )\n}\ncomplete -F _mdbook -o bashdefault -o default mdbook\n");
    else if (!strcmp(shell,"zsh")) printf("#compdef mdbook\n_arguments '1: :((init build test clean completions watch serve help))' '*::arg:->args'\n");
    else if (!strcmp(shell,"fish")) printf("complete -c mdbook -f -a 'init build test clean completions watch serve help'\ncomplete -c mdbook -s h -l help -d 'Print help'\ncomplete -c mdbook -s V -l version -d 'Print version'\n");
    else if (!strcmp(shell,"elvish")) printf("set edit:completion:arg-completer[mdbook] = {|@words| put init build test clean completions watch serve help }\n");
    else if (!strcmp(shell,"powershell")) printf("Register-ArgumentCompleter -Native -CommandName 'mdbook' -ScriptBlock { param($wordToComplete) 'init','build','test','clean','completions','watch','serve','help' }\n");
    else { fprintf(stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh]\n\nFor more information, try '--help'.\n", shell); exit(2); }
}

static char *next_val(int *i, int argc, char **argv) {
    char *a = argv[*i]; char *eq = strchr(a, '=');
    if (eq) return eq + 1;
    if (*i + 1 >= argc) return NULL;
    (*i)++; return argv[*i];
}

int main(int argc, char **argv) {
    char *progbase = xstrdup(argv[0]); const char *prog = basename(progbase);
    if (argc == 1) { main_help(stderr, prog); free(progbase); return 2; }
    if (!strcmp(argv[1],"-h") || !strcmp(argv[1],"--help")) { main_help(stdout, prog); return 0; }
    if (!strcmp(argv[1],"-V") || !strcmp(argv[1],"--version")) { puts(VERSION); return 0; }
    if (!strcmp(argv[1],"help")) {
        if (argc >= 3) sub_help(prog, argv[2]); else main_help(stdout, prog);
        return 0;
    }
    const char *cmd = argv[1];
    if (!strcmp(cmd,"completions")) {
        if (argc >= 3 && (!strcmp(argv[2],"-h") || !strcmp(argv[2],"--help"))) { sub_help(prog, cmd); return 0; }
        if (argc < 3) { fprintf(stderr, "error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: %s completions <SHELL>\n\nFor more information, try '--help'.\n", prog); return 2; }
        completions(argv[2]); return 0;
    }
    if (!strcmp(cmd,"init")) {
        const char *dir=".", *title=NULL, *ignore=NULL; bool theme=false;
        for (int i=2;i<argc;i++) {
            if (!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")) { sub_help(prog,cmd); return 0; }
            else if (!strcmp(argv[i],"-V")||!strcmp(argv[i],"--version")) { puts(VERSION); return 0; }
            else if (!strncmp(argv[i],"--title",7)) title = next_val(&i,argc,argv);
            else if (!strncmp(argv[i],"--ignore",8)) ignore = next_val(&i,argc,argv);
            else if (!strcmp(argv[i],"--theme")) theme=true;
            else if (!strcmp(argv[i],"--force")) {}
            else if (argv[i][0]=='-') { fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: %s init [OPTIONS] [dir]\n\nFor more information, try '--help'.\n", argv[i], prog); return 2; }
            else dir=argv[i];
        }
        return cmd_init(dir,title,ignore,theme);
    }
    if (!strcmp(cmd,"build")||!strcmp(cmd,"clean")||!strcmp(cmd,"test")||!strcmp(cmd,"watch")||!strcmp(cmd,"serve")) {
        const char *dir=".", *dest=NULL, *chapter=NULL;
        for (int i=2;i<argc;i++) {
            if (!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")) { sub_help(prog,cmd); return 0; }
            else if (!strcmp(argv[i],"-V")||!strcmp(argv[i],"--version")) { puts(VERSION); return 0; }
            else if (!strcmp(argv[i],"-d")||!strncmp(argv[i],"--dest-dir",10)) dest = next_val(&i,argc,argv);
            else if (!strcmp(argv[i],"-c")||!strncmp(argv[i],"--chapter",9)) chapter = next_val(&i,argc,argv);
            else if (!strcmp(argv[i],"-L")||!strncmp(argv[i],"--library-path",14)||!strcmp(argv[i],"-p")||!strcmp(argv[i],"--port")||!strcmp(argv[i],"-n")||!strcmp(argv[i],"--hostname")||!strcmp(argv[i],"--watcher")) { (void)next_val(&i,argc,argv); }
            else if (!strcmp(argv[i],"-o")||!strcmp(argv[i],"--open")) {}
            else if (argv[i][0]=='-') { fprintf(stderr,"error: unexpected argument '%s' found\n\nUsage: %s %s [OPTIONS] [dir]\n\nFor more information, try '--help'.\n", argv[i], prog, cmd); return 2; }
            else dir=argv[i];
        }
        if (!strcmp(cmd,"clean")) return cmd_clean(dir,dest);
        if (!strcmp(cmd,"test")) return cmd_test(dir,chapter);
        if (!strcmp(cmd,"serve")) {
            cmd_build(dir,dest);
            printf("Serving HTTP on localhost:3000\n");
            return 0;
        }
        if (!strcmp(cmd,"watch")) return cmd_build(dir,dest);
        return cmd_build(dir,dest);
    }
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: %s [COMMAND]\n\nFor more information, try '--help'.\n", cmd, prog);
    return 2;
}
