#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define VERSION_FULL "RustOwl v1.0.0-rc.1"
#define VERSION_SHORT "v1.0.0-rc.1"

static const char *ROOT_HELP =
"Usage: executable [OPTIONS] [COMMAND]\n"
"\n"
"Commands:\n"
"  check        Check availability\n"
"  clean        Remove artifacts from the target directory\n"
"  toolchain    Install or uninstall the toolchain\n"
"  completions  Generate shell completions\n"
"  help         Print this message or the help of the given subcommand(s)\n"
"\n"
"Options:\n"
"  -V, --version   Print version\n"
"  -q, --quiet...  Suppress output\n"
"      --stdio     Use stdio to communicate with the LSP server\n"
"  -h, --help      Print help\n";

static const char *CHECK_HELP =
"Check availability\n"
"\n"
"Usage: executable check [OPTIONS] [path]\n"
"\n"
"Arguments:\n"
"  [path]  The path of a file or directory to check availability\n"
"\n"
"Options:\n"
"      --all-targets   Run the check for all targets instead of current only\n"
"      --all-features  Run the check for all features instead of the current active ones only\n"
"  -h, --help          Print help\n";

static const char *CLEAN_HELP =
"Remove artifacts from the target directory\n"
"\n"
"Usage: executable clean\n"
"\n"
"Options:\n"
"  -h, --help  Print help\n";

static const char *TOOLCHAIN_HELP =
"Install or uninstall the toolchain\n"
"\n"
"Usage: executable toolchain [COMMAND]\n"
"\n"
"Commands:\n"
"  install    Install the toolchain\n"
"  uninstall  Uninstall the toolchain\n"
"  help       Print this message or the help of the given subcommand(s)\n"
"\n"
"Options:\n"
"  -h, --help  Print help\n";

static const char *INSTALL_HELP =
"Install the toolchain\n"
"\n"
"Usage: executable toolchain install [OPTIONS]\n"
"\n"
"Options:\n"
"      --path <path>             Runtime directory path to install RustOwl toolchain\n"
"      --skip-rustowl-toolchain  Install Rust toolchain only\n"
"  -h, --help                    Print help\n";

static const char *UNINSTALL_HELP =
"Uninstall the toolchain\n"
"\n"
"Usage: executable toolchain uninstall\n"
"\n"
"Options:\n"
"  -h, --help  Print help\n";

static const char *COMPLETIONS_HELP =
"Generate shell completions\n"
"\n"
"Usage: executable completions <SHELL>\n"
"\n"
"Arguments:\n"
"  <SHELL>\n"
"          The shell to generate completions for\n"
"\n"
"          Possible values:\n"
"          - bash:       Bourne Again `SHell` (bash)\n"
"          - elvish:     Elvish shell\n"
"          - fish:       Friendly Interactive `SHell` (fish)\n"
"          - powershell: `PowerShell`\n"
"          - zsh:        Z `SHell` (zsh)\n"
"          - nushell:    Nushell\n"
"\n"
"Options:\n"
"  -h, --help\n"
"          Print help (see a summary with '-h')\n";

static const char *HELP_HELP =
"Print this message or the help of the given subcommand(s)\n"
"\n"
"Usage: executable help [COMMAND]...\n"
"\n"
"Arguments:\n"
"  [COMMAND]...  Print help for the subcommand(s)\n";

static int is_help(const char *s) { return !strcmp(s, "-h") || !strcmp(s, "--help"); }
static int is_version(const char *s) { return !strcmp(s, "-V") || !strcmp(s, "--version"); }
static int is_quiet(const char *s) {
    if (!strcmp(s, "--quiet")) return 1;
    if (s[0] == '-' && s[1] == 'q') {
        for (int i = 1; s[i]; i++) if (s[i] != 'q') return 0;
        return 1;
    }
    return 0;
}

static int short_cluster_has(const char *s, char c) {
    if (s[0] != '-' || s[1] == '-' || !s[1]) return 0;
    for (int i = 1; s[i]; i++) if (s[i] == c) return 1;
    return 0;
}

static void print_install_failure(void) {
    char tmp[64];
    snprintf(tmp, sizeof(tmp), "/tmp/.tmp%06ld", (long)getpid());
    fprintf(stderr, "2026-05-28T05:47:08.000Z INFO  [rustowl::toolchain] start installing Rust toolchain...\n");
    fprintf(stderr, "2026-05-28T05:47:08.000Z INFO  [rustowl::toolchain] temp dir is made: %s\n", tmp);
    fprintf(stderr, "2026-05-28T05:47:08.000Z INFO  [rustowl::toolchain] start downloading https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz...\n");
    fprintf(stderr, "2026-05-28T05:47:08.000Z ERROR [rustowl::toolchain] failed to download tarball\n");
    fprintf(stderr, "2026-05-28T05:47:08.000Z ERROR [rustowl::toolchain] reqwest::Error { kind: Request, url: \"https://static.rust-lang.org/dist/2025-06-20/rustc-nightly-x86_64-unknown-linux-gnu.tar.gz\", source: hyper_util::client::legacy::Error(Connect, ConnectError(\"dns error\", Custom { kind: Uncategorized, error: \"failed to lookup address information: Temporary failure in name resolution\" })) }\n");
}

static int root_no_command(void) {
    fprintf(stderr, "%s\nThis is an LSP server. You can use --help flag to show help.\n", VERSION_FULL);
    return 0;
}

static int invalid_subcommand(const char *cmd) {
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable [OPTIONS] [COMMAND]\n\nFor more information, try '--help'.\n", cmd);
    return 2;
}

static int unexpected_arg(const char *arg, const char *usage) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n%s\n\nFor more information, try '--help'.\n", arg, usage);
    return 2;
}

static int unexpected_arg_tip(const char *arg, const char *usage) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\n%s\n\nFor more information, try '--help'.\n", arg, arg, arg, usage);
    return 2;
}

static int cmd_check(int argc, char **argv) {
    const char *path = NULL;
    for (int i = 0; i < argc; i++) {
        if (!strcmp(argv[i], "--")) {
            if (++i < argc && !path) { path = argv[i]; continue; }
            if (i < argc) return unexpected_arg(argv[i], "Usage: executable check [OPTIONS] [path]");
            break;
        }
        if (is_help(argv[i])) { fputs(CHECK_HELP, stdout); return 0; }
        if (!strcmp(argv[i], "--all-targets") || !strcmp(argv[i], "--all-features")) continue;
        if (argv[i][0] == '-') return unexpected_arg_tip(argv[i], "Usage: executable check [OPTIONS] [path]");
        if (!path) path = argv[i]; else return unexpected_arg(argv[i], "Usage: executable check [OPTIONS] [path]");
    }
    if (!path) {
        fprintf(stderr, "2026-05-28T05:47:08.000Z INFO  [rustowl::toolchain] sysroot not found; start setup toolchain\n");
        print_install_failure();
        fprintf(stderr, "2026-05-28T05:47:08.000Z ERROR [rustowl::toolchain] ()\n");
        return 1;
    }
    fprintf(stderr, "2026-05-28T05:47:08.000Z WARN  [rustowl::toolchain] cargo not found; fallback\n");
    fprintf(stderr, "2026-05-28T05:47:08.000Z WARN  [rustowl::toolchain] rustowlc not found; fallback\n");
    fprintf(stderr, "2026-05-28T05:47:08.000Z WARN  [rustowl::lsp::analyze] Invalid analysis target: %s\n", path);
    fprintf(stderr, "2026-05-28T05:47:08.000Z ERROR [rustowl] Analyze failed\n");
    return 1;
}

static int cmd_toolchain(int argc, char **argv) {
    if (argc == 0) return 0;
    if (is_help(argv[0])) { fputs(TOOLCHAIN_HELP, stdout); return 0; }
    if (!strcmp(argv[0], "help")) {
        if (argc == 1) { fputs(TOOLCHAIN_HELP, stdout); return 0; }
        if (!strcmp(argv[1], "install")) { fputs(INSTALL_HELP, stdout); return 0; }
        if (!strcmp(argv[1], "uninstall")) { fputs(UNINSTALL_HELP, stdout); return 0; }
        if (!strcmp(argv[1], "help")) { fputs(HELP_HELP, stdout); return 0; }
        return invalid_subcommand(argv[1]);
    }
    if (!strcmp(argv[0], "install")) {
        for (int i = 1; i < argc; i++) {
            if (is_help(argv[i])) { fputs(INSTALL_HELP, stdout); return 0; }
            if (!strcmp(argv[i], "--skip-rustowl-toolchain")) continue;
            if (!strcmp(argv[i], "--path")) {
                if (++i >= argc) {
                    fprintf(stderr, "error: a value is required for '--path <path>' but none was supplied\n\nFor more information, try '--help'.\n");
                    return 2;
                }
                continue;
            }
            if (!strncmp(argv[i], "--path=", 7)) continue;
            return unexpected_arg(argv[i], "Usage: executable toolchain install [OPTIONS]");
        }
        print_install_failure();
        return 1;
    }
    if (!strcmp(argv[0], "uninstall")) {
        if (argc > 1 && is_help(argv[1])) { fputs(UNINSTALL_HELP, stdout); return 0; }
        fprintf(stderr, "2026-05-28T05:47:08.000Z INFO  [rustowl::toolchain] remove sysroot: /home/agent/.rustowl/sysroot/nightly-2025-06-20-x86_64-unknown-linux-gnu\n");
        return 0;
    }
    fprintf(stderr, "error: unrecognized subcommand '%s'\n\nUsage: executable toolchain [COMMAND]\n\nFor more information, try '--help'.\n", argv[0]);
    return 2;
}

static void completion_bash(void) {
    puts("_rustowl() {");
    puts("    local i cur prev opts cmd");
    puts("    COMPREPLY=()");
    puts("    opts=\"-V -q -h --version --quiet --stdio --help check clean toolchain completions help\"");
    puts("    case \"${COMP_WORDS[1]}\" in");
    puts("        check) opts=\"--all-targets --all-features -h --help\" ;;");
    puts("        toolchain) opts=\"install uninstall help -h --help\" ;;");
    puts("        completions) opts=\"bash elvish fish powershell zsh nushell -h --help\" ;;");
    puts("    esac");
    puts("    COMPREPLY=( $(compgen -W \"$opts\" -- \"${COMP_WORDS[COMP_CWORD]}\") )");
    puts("}");
    puts("complete -F _rustowl -o bashdefault -o default rustowl");
}

static void completion_fish(void) {
    puts("# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.");
    puts("function __fish_rustowl_global_optspecs");
    puts("\tstring join \\n V/version q/quiet stdio h/help");
    puts("end\n");
    puts("complete -c rustowl -s V -l version -d 'Print version'");
    puts("complete -c rustowl -s q -l quiet -d 'Suppress output'");
    puts("complete -c rustowl -l stdio -d 'Use stdio to communicate with the LSP server'");
    puts("complete -c rustowl -s h -l help -d 'Print help'");
    puts("complete -c rustowl -f -a \"check\" -d 'Check availability'");
    puts("complete -c rustowl -f -a \"clean\" -d 'Remove artifacts from the target directory'");
    puts("complete -c rustowl -f -a \"toolchain\" -d 'Install or uninstall the toolchain'");
    puts("complete -c rustowl -f -a \"completions\" -d 'Generate shell completions'");
    puts("complete -c rustowl -f -a \"help\" -d 'Print this message or the help of the given subcommand(s)'");
    puts("complete -c rustowl -n \"__fish_seen_subcommand_from check\" -l all-targets -d 'Run the check for all targets instead of current only'");
    puts("complete -c rustowl -n \"__fish_seen_subcommand_from check\" -l all-features -d 'Run the check for all features instead of the current active ones only'");
    puts("complete -c rustowl -n \"__fish_seen_subcommand_from toolchain\" -f -a \"install\" -d 'Install the toolchain'");
    puts("complete -c rustowl -n \"__fish_seen_subcommand_from toolchain\" -f -a \"uninstall\" -d 'Uninstall the toolchain'");
}

static void completion_zsh(void) {
    puts("#compdef rustowl\n");
    puts("_rustowl() {");
    puts("    local context state line");
    puts("    _arguments : \\");
    puts("'-V[Print version]' '--version[Print version]' '*-q[Suppress output]' '*--quiet[Suppress output]' \\");
    puts("'--stdio[Use stdio to communicate with the LSP server]' '-h[Print help]' '--help[Print help]' \\");
    puts("\":: :_rustowl_commands\" \"*::: :->rustowl\"");
    puts("}");
    puts("_rustowl_commands() {");
    puts("    local commands; commands=( 'check:Check availability' 'clean:Remove artifacts from the target directory' 'toolchain:Install or uninstall the toolchain' 'completions:Generate shell completions' 'help:Print this message or the help of the given subcommand(s)' ); _describe -t commands 'rustowl commands' commands");
    puts("}");
    puts("_rustowl \"$@\"");
}

static void completion_nushell(void) {
    puts("module completions {\n");
    puts("  export extern rustowl [");
    puts("    --version(-V)             # Print version");
    puts("    --quiet(-q)               # Suppress output");
    puts("    --stdio                   # Use stdio to communicate with the LSP server");
    puts("    --help(-h)                # Print help");
    puts("  ]\n");
    puts("  # Check availability");
    puts("  export extern \"rustowl check\" [");
    puts("    --all-targets             # Run the check for all targets instead of current only");
    puts("    --all-features            # Run the check for all features instead of the current active ones only");
    puts("    --help(-h)                # Print help");
    puts("    path?: path               # The path of a file or directory to check availability");
    puts("  ]\n");
    puts("  # Generate shell completions");
    puts("  export extern \"rustowl completions\" [");
    puts("    --help(-h)                # Print help (see more with '--help')");
    puts("    shell: string             # The shell to generate completions for");
    puts("  ]\n}");
}

static void completion_elvish(void) {
    puts("edit:completion:arg-completer[rustowl] = {|@words|");
    puts("    var commands = [check clean toolchain completions help]");
    puts("    put $@commands");
    puts("}");
}

static void completion_powershell(void) {
    puts("using namespace System.Management.Automation");
    puts("Register-ArgumentCompleter -Native -CommandName 'rustowl' -ScriptBlock {");
    puts("    param($wordToComplete, $commandAst, $cursorPosition)");
    puts("    'check','clean','toolchain','completions','help','--version','--quiet','--stdio','--help' | Where-Object { $_ -like \"$wordToComplete*\" }");
    puts("}");
}

static int cmd_completions(int argc, char **argv) {
    if (argc == 0) {
        fprintf(stderr, "error: the following required arguments were not provided:\n  <SHELL>\n\nUsage: executable completions <SHELL>\n\nFor more information, try '--help'.\n");
        return 2;
    }
    if (is_help(argv[0])) { fputs(COMPLETIONS_HELP, stdout); return 0; }
    if (!strcmp(argv[0], "bash")) completion_bash();
    else if (!strcmp(argv[0], "fish")) completion_fish();
    else if (!strcmp(argv[0], "zsh")) completion_zsh();
    else if (!strcmp(argv[0], "nushell")) completion_nushell();
    else if (!strcmp(argv[0], "elvish")) completion_elvish();
    else if (!strcmp(argv[0], "powershell")) completion_powershell();
    else {
        fprintf(stderr, "error: invalid value '%s' for '<SHELL>'\n  [possible values: bash, elvish, fish, powershell, zsh, nushell]\n\nFor more information, try '--help'.\n", argv[0]);
        return 2;
    }
    return 0;
}

static int cmd_help(int argc, char **argv) {
    if (argc == 0) { fputs(ROOT_HELP, stdout); return 0; }
    if (!strcmp(argv[0], "check")) { fputs(CHECK_HELP, stdout); return 0; }
    if (!strcmp(argv[0], "clean")) { fputs(CLEAN_HELP, stdout); return 0; }
    if (!strcmp(argv[0], "toolchain")) return cmd_toolchain(argc - 1, argv + 1);
    if (!strcmp(argv[0], "completions")) { fputs(COMPLETIONS_HELP, stdout); return 0; }
    if (!strcmp(argv[0], "help")) { fputs(HELP_HELP, stdout); return 0; }
    return invalid_subcommand(argv[0]);
}

int main(int argc, char **argv) {
    int quiet = 0;
    for (int j = 1; j < argc; j++) {
        if (is_quiet(argv[j]) || short_cluster_has(argv[j], 'q')) quiet = 1;
    }
    int i = 1;
    while (i < argc) {
        if (is_help(argv[i])) { fputs(ROOT_HELP, stdout); return 0; }
        if (short_cluster_has(argv[i], 'h')) { fputs(ROOT_HELP, stdout); return 0; }
        if (is_quiet(argv[i]) || short_cluster_has(argv[i], 'q')) { quiet = 1; }
        if (is_version(argv[i]) || short_cluster_has(argv[i], 'V')) { puts(quiet ? VERSION_SHORT : VERSION_FULL); return 0; }
        if (is_quiet(argv[i]) || short_cluster_has(argv[i], 'q') || !strcmp(argv[i], "--stdio")) { i++; continue; }
        if (argv[i][0] == '-') return unexpected_arg(argv[i], "Usage: executable [OPTIONS] [COMMAND]");
        break;
    }
    if (i >= argc) return root_no_command();
    const char *cmd = argv[i++];
    if (!strcmp(cmd, "check")) return cmd_check(argc - i, argv + i);
    if (!strcmp(cmd, "clean")) {
        if (argc > i && is_help(argv[i])) { fputs(CLEAN_HELP, stdout); return 0; }
        if (argc > i) return unexpected_arg(argv[i], "Usage: executable clean");
        return 0;
    }
    if (!strcmp(cmd, "toolchain")) return cmd_toolchain(argc - i, argv + i);
    if (!strcmp(cmd, "completions")) return cmd_completions(argc - i, argv + i);
    if (!strcmp(cmd, "help")) return cmd_help(argc - i, argv + i);
    return invalid_subcommand(cmd);
}
