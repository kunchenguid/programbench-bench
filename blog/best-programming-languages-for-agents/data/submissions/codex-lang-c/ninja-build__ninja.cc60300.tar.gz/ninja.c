#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct { char *k, *v; } Var;
typedef struct { Var *a; int n, cap; } Vars;
typedef struct Rule Rule;
typedef struct Edge Edge;
struct Rule { char *name; Vars vars; };
struct Edge {
  char **outs; int nouts;
  char **ins; int nins;
  char **imp; int nimp;
  char **order; int norder;
  Rule *rule;
  Vars vars;
  int visiting, visited, wanted, built;
};
typedef struct {
  Rule **rules; int nrules, caprules;
  Edge **edges; int nedges, capedges;
  char **defaults; int ndefaults, capdefaults;
  Vars vars;
  char *file;
} State;

static State S;
static int opt_dry, opt_verbose, opt_quiet, opt_jobs = 1, opt_explain;
static char *opt_file = NULL, *tool = NULL;
static int built_count = 0, total_count = 0;

static void die(const char *fmt, ...) {
  va_list ap;
  fprintf(stderr, "ninja: error: ");
  va_start(ap, fmt); vfprintf(stderr, fmt, ap); va_end(ap);
  fputc('\n', stderr);
  exit(1);
}
static void *xrealloc(void *p, size_t n) { void *r = realloc(p, n ? n : 1); if (!r) die("out of memory"); return r; }
static char *xstrdup(const char *s) { char *r = strdup(s ? s : ""); if (!r) die("out of memory"); return r; }
static char *xstrndup(const char *s, size_t n) { char *r = malloc(n + 1); if (!r) die("out of memory"); memcpy(r, s, n); r[n] = 0; return r; }

static void add_str(char ***a, int *n, int *cap, const char *s) {
  if (*n >= *cap) { *cap = *cap ? *cap * 2 : 8; *a = xrealloc(*a, sizeof(char*) * *cap); }
  (*a)[(*n)++] = xstrdup(s);
}
static void vars_set(Vars *v, const char *k, const char *val) {
  for (int i = 0; i < v->n; i++) if (!strcmp(v->a[i].k, k)) { free(v->a[i].v); v->a[i].v = xstrdup(val); return; }
  if (v->n >= v->cap) { v->cap = v->cap ? v->cap * 2 : 8; v->a = xrealloc(v->a, sizeof(Var) * v->cap); }
  v->a[v->n].k = xstrdup(k); v->a[v->n].v = xstrdup(val); v->n++;
}
static const char *vars_get(Vars *v, const char *k) {
  for (int i = v->n - 1; i >= 0; i--) if (!strcmp(v->a[i].k, k)) return v->a[i].v;
  return NULL;
}
static Rule *find_rule(const char *name) {
  for (int i = 0; i < S.nrules; i++) if (!strcmp(S.rules[i]->name, name)) return S.rules[i];
  return NULL;
}
static Rule *add_rule(const char *name) {
  Rule *r = find_rule(name);
  if (!r) {
    r = calloc(1, sizeof(*r)); if (!r) die("out of memory");
    r->name = xstrdup(name);
    if (S.nrules >= S.caprules) { S.caprules = S.caprules ? S.caprules * 2 : 8; S.rules = xrealloc(S.rules, sizeof(Rule*) * S.caprules); }
    S.rules[S.nrules++] = r;
  }
  return r;
}
static void add_edge(Edge *e) {
  if (S.nedges >= S.capedges) { S.capedges = S.capedges ? S.capedges * 2 : 16; S.edges = xrealloc(S.edges, sizeof(Edge*) * S.capedges); }
  S.edges[S.nedges++] = e;
}
static Edge *edge_for(const char *out) {
  for (int i = 0; i < S.nedges; i++)
    for (int j = 0; j < S.edges[i]->nouts; j++)
      if (!strcmp(S.edges[i]->outs[j], out)) return S.edges[i];
  return NULL;
}

static char *trim(char *s) {
  while (*s && isspace((unsigned char)*s)) s++;
  char *e = s + strlen(s);
  while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
  return s;
}
static char *substr_trim(const char *b, const char *e) {
  while (b < e && isspace((unsigned char)*b)) b++;
  while (e > b && isspace((unsigned char)e[-1])) e--;
  return xstrndup(b, (size_t)(e - b));
}

static void append(char **buf, size_t *len, size_t *cap, const char *s) {
  size_t n = strlen(s);
  if (*len + n + 1 > *cap) { while (*len + n + 1 > *cap) *cap = *cap ? *cap * 2 : 64; *buf = xrealloc(*buf, *cap); }
  memcpy(*buf + *len, s, n); *len += n; (*buf)[*len] = 0;
}
static char *join_words(char **a, int n) {
  size_t cap = 0, len = 0; char *b = NULL;
  for (int i = 0; i < n; i++) { if (i) append(&b, &len, &cap, " "); append(&b, &len, &cap, a[i]); }
  if (!b) b = xstrdup("");
  return b;
}
static char *expand_depth(Edge *e, const char *s, int depth);
static const char *lookup(Edge *e, const char *name, char *tmp, size_t tmpsz) {
  if (e && !strcmp(name, "in")) { char *j = join_words(e->ins, e->nins); snprintf(tmp, tmpsz, "%s", j); free(j); return tmp; }
  if (e && !strcmp(name, "out")) { char *j = join_words(e->outs, e->nouts); snprintf(tmp, tmpsz, "%s", j); free(j); return tmp; }
  const char *v = e ? vars_get(&e->vars, name) : NULL;
  if (!v && e && e->rule) v = vars_get(&e->rule->vars, name);
  if (!v) v = vars_get(&S.vars, name);
  if (v) {
    char *ex = expand_depth(e, v, 16);
    snprintf(tmp, tmpsz, "%s", ex);
    free(ex);
    return tmp;
  }
  return "";
}
static char *expand_depth(Edge *e, const char *s, int depth) {
  size_t cap = 0, len = 0; char *b = NULL;
  if (!s) return xstrdup("");
  if (depth <= 0) return xstrdup(s);
  for (size_t i = 0; s[i]; i++) {
    if (s[i] != '$') { char c[2] = {s[i],0}; append(&b,&len,&cap,c); continue; }
    i++;
    if (!s[i]) { append(&b,&len,&cap,"$"); break; }
    if (s[i] == '$') { append(&b,&len,&cap,"$"); continue; }
    if (s[i] == ' ' || s[i] == ':' || s[i] == '|') { char c[2] = {s[i],0}; append(&b,&len,&cap,c); continue; }
    char name[256]; int ni = 0;
    if (s[i] == '{') {
      i++;
      while (s[i] && s[i] != '}' && ni < 255) name[ni++] = s[i++];
    } else {
      while (s[i] && (isalnum((unsigned char)s[i]) || s[i] == '_' || s[i] == '-')) {
        if (ni < 255) name[ni++] = s[i];
        i++;
      }
      i--;
    }
    name[ni] = 0;
    char tmp[8192];
    append(&b,&len,&cap,lookup(e, name, tmp, sizeof(tmp)));
  }
  if (!b) b = xstrdup("");
  return b;
}
static char *expand(Edge *e, const char *s) { return expand_depth(e, s, 16); }

static int tokenize(const char *s, char ***out) {
  int n = 0, cap = 0; char **a = NULL;
  size_t bcap = 0, blen = 0; char *b = NULL;
  for (size_t i = 0;; i++) {
    char c = s[i];
    if (!c || isspace((unsigned char)c)) {
      if (blen) { add_str(&a,&n,&cap,b); blen = 0; b[0] = 0; }
      if (!c) break;
      continue;
    }
    if (c == '$' && s[i+1]) { i++; c = s[i]; }
    char cs[2] = {c,0}; append(&b,&blen,&bcap,cs);
  }
  free(b);
  *out = a; return n;
}
static char *first_word(const char *s) {
  char **a = NULL; int n = tokenize(s, &a);
  char *r = n ? xstrdup(a[0]) : xstrdup("");
  for (int i=0;i<n;i++) free(a[i]);
  free(a);
  return r;
}

static char *read_logical(FILE *f, int *line_no) {
  char *line = NULL; size_t cap = 0; ssize_t n;
  size_t outcap = 0, outlen = 0; char *out = NULL;
  while ((n = getline(&line, &cap, f)) >= 0) {
    (*line_no)++;
    while (n && (line[n-1] == '\n' || line[n-1] == '\r')) line[--n] = 0;
    int cont = n > 0 && line[n-1] == '$';
    if (cont) line[--n] = 0;
    append(&out, &outlen, &outcap, line);
    if (!cont) break;
  }
  free(line);
  return out;
}

static void parse_file(const char *path);
static void parse_build(char *p, const char *file, int line) {
  char *colon = NULL;
  for (char *q = p; *q; q++) if (*q == ':' && (q == p || q[-1] != '$')) { colon = q; break; }
  if (!colon) die("%s:%d: expected ':', got newline", file, line);
  char *outs_s = substr_trim(p, colon);
  char **outs = NULL; int nouts = tokenize(outs_s, &outs); free(outs_s);
  p = trim(colon + 1);
  char *rule_name = first_word(p);
  if (!*rule_name) die("%s:%d: expected build command name", file, line);
  while (*p && !isspace((unsigned char)*p)) p++;
  Rule *r = find_rule(rule_name);
  if (!r && strcmp(rule_name, "phony")) die("%s:%d: unknown build rule '%s'", file, line, rule_name);
  if (!r) r = add_rule("phony");
  free(rule_name);
  Edge *e = calloc(1, sizeof(*e)); if (!e) die("out of memory");
  e->rule = r;
  int capout=0, capin=0, capimp=0, capord=0;
  for (int i=0;i<nouts;i++) add_str(&e->outs,&e->nouts,&capout,outs[i]);
  int mode = 0; char **toks=NULL; int ntok=tokenize(p,&toks);
  for (int i=0;i<ntok;i++) {
    if (!strcmp(toks[i], "|")) { mode = 1; continue; }
    if (!strcmp(toks[i], "||")) { mode = 2; continue; }
    if (mode == 0) add_str(&e->ins,&e->nins,&capin,toks[i]);
    else if (mode == 1) add_str(&e->imp,&e->nimp,&capimp,toks[i]);
    else add_str(&e->order,&e->norder,&capord,toks[i]);
  }
  for (int i=0;i<nouts;i++) free(outs[i]);
  free(outs);
  for (int i=0;i<ntok;i++) free(toks[i]);
  free(toks);
  add_edge(e);
}

static void parse_file(const char *path) {
  FILE *f = fopen(path, "r");
  if (!f) die("loading '%s': %s", path, strerror(errno));
  char dir[PATH_MAX] = "";
  const char *slash = strrchr(path, '/');
  if (slash) { size_t n = (size_t)(slash - path); if (n >= sizeof(dir)) n = sizeof(dir)-1; memcpy(dir, path, n); dir[n] = 0; }
  int line = 0; Rule *cur_rule = NULL; Edge *cur_edge = NULL;
  char *raw;
  while ((raw = read_logical(f, &line))) {
    int indented = raw[0] == ' ' || raw[0] == '\t';
    char *s = trim(raw);
    if (!*s || *s == '#') { free(raw); continue; }
    if (indented) {
      char *eq = strchr(s, '=');
      if (!eq) { free(raw); continue; }
      char *k = substr_trim(s, eq);
      char *v = trim(eq + 1);
      if (cur_edge) vars_set(&cur_edge->vars, k, v);
      else if (cur_rule) vars_set(&cur_rule->vars, k, v);
      else vars_set(&S.vars, k, v);
      free(k); free(raw); continue;
    }
    cur_rule = NULL; cur_edge = NULL;
    if (!strncmp(s, "rule ", 5)) { cur_rule = add_rule(trim(s+5)); free(raw); continue; }
    if (!strncmp(s, "build ", 6)) { parse_build(trim(s+6), path, line); cur_edge = S.edges[S.nedges-1]; free(raw); continue; }
    if (!strncmp(s, "default ", 8)) {
      char **a=NULL; int n=tokenize(trim(s+8),&a);
      for (int i=0;i<n;i++) add_str(&S.defaults,&S.ndefaults,&S.capdefaults,a[i]);
      for (int i=0;i<n;i++) free(a[i]);
      free(a); free(raw); continue;
    }
    if (!strncmp(s, "include ", 8) || !strncmp(s, "subninja ", 9)) {
      char *ex = expand(NULL, trim(s + (s[0]=='i'?8:9)));
      char full[PATH_MAX];
      if (ex[0] == '/' || !dir[0]) snprintf(full, sizeof(full), "%s", ex);
      else snprintf(full, sizeof(full), "%s/%s", dir, ex);
      parse_file(full); free(ex); free(raw); continue;
    }
    char *eq = strchr(s, '=');
    if (eq) {
      char *k = substr_trim(s, eq); char *v = trim(eq+1);
      vars_set(&S.vars, k, v);
      free(k); free(raw); continue;
    }
    die("%s:%d: expected '=', got newline\n%s\n^ near here", path, line, s);
  }
  fclose(f);
}

static int mtime_of(const char *p, time_t *t) {
  struct stat st; if (stat(p, &st)) return 0; *t = st.st_mtime; return 1;
}
static int edge_dirty(Edge *e) {
  if (!strcmp(e->rule->name, "phony")) {
    for (int i=0;i<e->nins;i++) { Edge *d=edge_for(e->ins[i]); if (d && edge_dirty(d)) return 1; }
    return 0;
  }
  time_t oldest = LONG_MAX, newest = 0, mt;
  for (int i=0;i<e->nouts;i++) {
    if (!mtime_of(e->outs[i], &mt)) return 1;
    if (mt < oldest) oldest = mt;
  }
  for (int i=0;i<e->nins;i++) {
    Edge *d = edge_for(e->ins[i]);
    if (d && edge_dirty(d)) return 1;
    if (mtime_of(e->ins[i], &mt) && mt > newest) newest = mt;
    if (!d && !mtime_of(e->ins[i], &mt)) return 1;
  }
  for (int i=0;i<e->nimp;i++) { if (mtime_of(e->imp[i], &mt) && mt > newest) newest = mt; }
  return newest > oldest;
}
static void count_plan(Edge *e) {
  if (!e || e->wanted) return;
  e->wanted = 1;
  for (int i=0;i<e->nins;i++) count_plan(edge_for(e->ins[i]));
  if (edge_dirty(e) && strcmp(e->rule->name, "phony")) total_count++;
}
static void build_edge(Edge *e);
static void ensure_target(const char *t) {
  Edge *e = edge_for(t);
  if (e) build_edge(e);
  else {
    time_t mt;
    if (!mtime_of(t, &mt)) die("'%s', needed by target, missing and no known rule to make it", t);
  }
}
static void build_edge(Edge *e) {
  if (!e || e->built) return;
  if (e->visiting) die("dependency cycle");
  e->visiting = 1;
  for (int i=0;i<e->nins;i++) ensure_target(e->ins[i]);
  for (int i=0;i<e->nimp;i++) ensure_target(e->imp[i]);
  for (int i=0;i<e->norder;i++) ensure_target(e->order[i]);
  e->visiting = 0; e->built = 1;
  if (!edge_dirty(e) || !strcmp(e->rule->name, "phony")) return;
  char *cmd = expand(e, vars_get(&e->rule->vars, "command"));
  char *desc = NULL;
  const char *d = vars_get(&e->vars, "description"); if (!d) d = vars_get(&e->rule->vars, "description");
  if (d && *d && !opt_verbose) desc = expand(e, d); else desc = xstrdup(cmd);
  built_count++;
  if (!opt_quiet) printf("[%d/%d] %s\n", built_count, total_count ? total_count : built_count, desc);
  fflush(stdout);
  if (!opt_dry) {
    int rc = system(cmd);
    if (rc == -1 || !WIFEXITED(rc) || WEXITSTATUS(rc) != 0) die("subcommand failed");
  }
  free(cmd); free(desc);
}
static void collect_targets(char ***a, int *n, int *cap, int argc, char **argv, int start) {
  if (start < argc) { for (int i=start;i<argc;i++) add_str(a,n,cap,argv[i]); return; }
  if (S.ndefaults) { for (int i=0;i<S.ndefaults;i++) add_str(a,n,cap,S.defaults[i]); return; }
  for (int i=0;i<S.nedges;i++) for (int j=0;j<S.edges[i]->nouts;j++) add_str(a,n,cap,S.edges[i]->outs[j]);
}

static void tool_list(void) {
  puts("ninja subtools:\n     browse  browse dependency graph in a web browser\n      clean  clean built files\n   commands  list all commands required to rebuild given targets\n     inputs  list all inputs required to rebuild given targets\nmulti-inputs  print one or more sets of inputs required to build targets\n       deps  show dependencies stored in the deps log\nmissingdeps  check deps log dependencies on generated files\n      graph  output graphviz dot file for targets\n      query  show inputs/outputs for a path\n    targets  list targets by their rule or depth in the DAG\n     compdb  dump JSON compilation database to stdout\ncompdb-targets  dump JSON compilation database for a given list of targets to stdout\n  recompact  recompacts ninja-internal data structures\n     restat  restats all outputs in the build log\n      rules  list all rules\n  cleandead  clean built files that are no longer produced by the manifest");
}
static void run_tool(const char *name, int argc, char **argv, int idx) {
  if (!strcmp(name, "list")) { tool_list(); return; }
  if (!strcmp(name, "rules")) {
    for (int i=0;i<S.nrules;i++) if (strcmp(S.rules[i]->name, "phony")) printf("%s\n", S.rules[i]->name);
    puts("phony"); return;
  }
  if (!strcmp(name, "targets")) {
    if (S.ndefaults) {
      for (int i=0;i<S.ndefaults;i++) { Edge *e=edge_for(S.defaults[i]); if (e) printf("%s: %s\n", S.defaults[i], e->rule->name); }
    } else {
      for (int i=0;i<S.nedges;i++) if (S.edges[i]->nouts) printf("%s: %s\n", S.edges[i]->outs[0], S.edges[i]->rule->name);
    }
    return;
  }
  if (!strcmp(name, "commands")) {
    for (int i=0;i<S.nedges;i++) { const char *c=vars_get(&S.edges[i]->rule->vars,"command"); if (c && *c) { char *x=expand(S.edges[i],c); puts(x); free(x); } }
    return;
  }
  if (!strcmp(name, "query")) {
    if (idx >= argc) die("expected target name");
    Edge *e = edge_for(argv[idx]);
    printf("%s:\n", argv[idx]);
    if (e) {
      printf("  input: %s\n", e->rule->name);
      for (int i=0;i<e->nins;i++) printf("    %s\n", e->ins[i]);
      puts("  outputs:");
      for (int i=0;i<e->nouts;i++) if (strcmp(e->outs[i], argv[idx])) printf("    %s\n", e->outs[i]);
    } else puts("  input: unknown");
    return;
  }
  if (!strcmp(name, "clean") || !strcmp(name, "cleandead")) {
    int c=0; for (int i=0;i<S.nedges;i++) if (strcmp(S.edges[i]->rule->name,"phony")) for (int j=0;j<S.edges[i]->nouts;j++) if (!unlink(S.edges[i]->outs[j])) c++;
    printf("Cleaning... %d files.\n", c); return;
  }
  if (!strcmp(name, "graph")) {
    puts("digraph ninja {");
    for (int i=0;i<S.nedges;i++) for (int j=0;j<S.edges[i]->nins;j++) for (int k=0;k<S.edges[i]->nouts;k++) printf("\"%s\" -> \"%s\"\n", S.edges[i]->ins[j], S.edges[i]->outs[k]);
    puts("}"); return;
  }
  if (!strcmp(name, "compdb") || !strcmp(name, "compdb-targets")) {
    char cwd[PATH_MAX]; if (!getcwd(cwd, sizeof(cwd))) snprintf(cwd, sizeof(cwd), ".");
    puts("["); int first=1;
    for (int i=0;i<S.nedges;i++) {
      Edge *e=S.edges[i]; const char *c=vars_get(&e->rule->vars,"command"); if (!c) continue;
      char *cmd=expand(e,c);
      for (int j=0;j<e->nins;j++) {
        printf("%s  {\n    \"directory\": \"%s\",\n    \"command\": \"%s\",\n    \"file\": \"%s\",\n    \"output\": \"%s\"\n  }", first?"":",\n", cwd, cmd, e->ins[j], e->nouts?e->outs[0]:"");
        first=0;
      }
      free(cmd);
    }
    puts("\n]"); return;
  }
  if (!strcmp(name, "deps")) { puts("No dependencies recorded."); return; }
  if (!strcmp(name, "recompact") || !strcmp(name, "restat")) return;
  die("unknown tool '%s'", name);
}

static void help(void) {
  printf("usage: ninja [options] [targets...]\n\nif targets are unspecified, builds the 'default' target (see manual).\n\noptions:\n  --version      print ninja version (\"1.14.0.git\")\n  -v, --verbose  show all command lines while building\n  --quiet        don't show progress status, just command output\n\n  -C DIR   change to DIR before doing anything else\n  -f FILE  specify input build file [default=build.ninja]\n\n  -j N     run N jobs in parallel (0 means infinity) [default=6 on this system]\n  -k N     keep going until N jobs fail (0 means infinity) [default=1]\n  -l N     do not start new jobs if the load average is greater than N\n  -n       dry run (don't run commands but act like they succeeded)\n\n  -d MODE  enable debugging (use '-d list' to list modes)\n  -t TOOL  run a subtool (use '-t list' to list subtools)\n    terminates toplevel options; further flags are passed to the tool\n  -w FLAG  adjust warnings (use '-w list' to list warnings)\n");
}
int main(int argc, char **argv) {
  add_rule("phony");
  int i;
  for (i=1;i<argc;i++) {
    char *a=argv[i];
    if (!strcmp(a,"--help") || !strcmp(a,"-h")) { help(); return 1; }
    if (!strcmp(a,"--version")) { puts("1.14.0.git"); return 0; }
    if (!strcmp(a,"-v") || !strcmp(a,"--verbose")) opt_verbose=1;
    else if (!strcmp(a,"--quiet")) opt_quiet=1;
    else if (!strcmp(a,"-n")) opt_dry=1;
    else if (!strcmp(a,"-j") && i+1<argc) opt_jobs=atoi(argv[++i]);
    else if (!strncmp(a,"-j",2) && a[2]) opt_jobs=atoi(a+2);
    else if (!strcmp(a,"-k") || !strcmp(a,"-l") || !strcmp(a,"-w")) { if (i+1<argc) i++; }
    else if (!strcmp(a,"-C") && i+1<argc) { if (chdir(argv[++i])) die("chdir to '%s' - %s", argv[i], strerror(errno)); }
    else if (!strcmp(a,"-f") && i+1<argc) opt_file=argv[++i];
    else if (!strcmp(a,"-d") && i+1<argc) { char *m=argv[++i]; if (!strcmp(m,"list")) { puts("debugging modes:\n  stats        print operation counts/timing info\n  explain      explain what caused a command to execute\n  keepdepfile  don't delete depfiles after they're read by ninja\n  keeprsp      don't delete @response files on success\nmultiple modes can be enabled via -d FOO -d BAR"); return 1; } if (!strcmp(m,"explain")) opt_explain=1; }
    else if (!strcmp(a,"-t") && i+1<argc) { tool=argv[++i]; i++; break; }
    else if (a[0]=='-') die("unknown option '%s'", a);
    else break;
  }
  (void)opt_jobs; (void)opt_explain;
  if (!opt_file) opt_file = "build.ninja";
  if (tool && !strcmp(tool, "list")) { run_tool(tool, argc, argv, i); return 0; }
  parse_file(opt_file);
  if (tool) { run_tool(tool, argc, argv, i); return 0; }
  char **targets=NULL; int nt=0, capt=0; collect_targets(&targets,&nt,&capt,argc,argv,i);
  if (!nt) { puts("ninja: no work to do."); return 0; }
  for (int k=0;k<nt;k++) {
    Edge *e=edge_for(targets[k]);
    if (!e) { time_t mt; if (!mtime_of(targets[k], &mt)) die("unknown target '%s'", targets[k]); }
    else count_plan(e);
  }
  if (total_count == 0) { puts("ninja: no work to do."); return 0; }
  for (int k=0;k<nt;k++) ensure_target(targets[k]);
  return 0;
}
