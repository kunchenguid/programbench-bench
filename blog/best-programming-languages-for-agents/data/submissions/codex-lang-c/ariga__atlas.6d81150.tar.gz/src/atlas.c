#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static const char *community =
"You're running the community build of Atlas, which may differ from the official version.\n"
"If this error persists, try installing the official version as a troubleshooting step:\n\n"
"  curl -sSf https://atlasgo.sh | sh\n\n"
"More installation options: https://atlasgo.io/docs#installation\n";

static void root_help(void){
puts("Manage your database schema as code\n");
puts("Usage:");
puts("  atlas [command]\n");
puts("Available Commands:");
puts("  completion  Generate the autocompletion script for the specified shell");
puts("  help        Help about any command");
puts("  license     Display license information");
puts("  migrate     Manage versioned migration files");
puts("  schema      Work with atlas schemas.");
puts("  version     Prints this Atlas CLI version information.\n");
puts("Flags:");
puts("  -h, --help   help for atlas\n");
puts("Use \"atlas [command] --help\" for more information about a command.");
}

static void schema_help(void){
puts("The `atlas schema` command groups subcommands working with declarative Atlas schemas.\n");
puts("Usage:");
puts("  atlas schema [command]\n");
puts("Available Commands:");
puts("  apply       Apply an atlas schema to a target database.");
puts("  clean       Removes all objects from the connected database.");
puts("  diff        Calculate and print the diff between two schemas.");
puts("  fmt         Formats Atlas HCL files");
puts("  inspect     Inspect a database and print its schema in Atlas DDL syntax.\n");
puts("Flags:");
puts("  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")");
puts("      --env string           set which env from the config file to use");
puts("  -h, --help                 help for schema");
puts("      --var <name>=<value>   input variables (default [])\n");
puts("Use \"atlas schema [command] --help\" for more information about a command.");
}

static void migrate_help(void){
puts("'atlas migrate' wraps several sub-commands for migration management.\n");
puts("Usage:");
puts("  atlas migrate [command]\n");
puts("Available Commands:");
puts("  apply       Applies pending migration files on the connected database.");
puts("  diff        Compute the diff between the migration directory and a desired state and create a new migration file.");
puts("  hash        Hash (re-)creates an integrity hash file for the migration directory.");
puts("  import      Import a migration directory from another migration management tool to the Atlas format.");
puts("  lint        Run analysis on the migration directory");
puts("  new         Creates a new empty migration file in the migration directory.");
puts("  set         Set the current version of the migration history table.");
puts("  status      Get information about the current migration status.");
puts("  validate    Validates the migration directories checksum and SQL statements.\n");
puts("Flags:");
puts("  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")");
puts("      --env string           set which env from the config file to use");
puts("  -h, --help                 help for migrate");
puts("      --var <name>=<value>   input variables (default [])\n");
puts("Use \"atlas migrate [command] --help\" for more information about a command.");
}

static void help_text(const char *topic){
if(!topic){root_help();return;}
if(!strcmp(topic,"version")) puts("Prints this Atlas CLI version information.\n\nUsage:\n  atlas version [flags]\n\nFlags:\n  -h, --help   help for version");
else if(!strcmp(topic,"license")) puts("Display license information\n\nUsage:\n  atlas license [flags]\n\nFlags:\n  -h, --help   help for license");
else if(!strcmp(topic,"schema-fmt")) puts("'atlas schema fmt' formats all \".hcl\" files under the given paths using\ncanonical HCL layout style as defined by the github.com/hashicorp/hcl/v2/hclwrite package.\nUnless stated otherwise, the fmt command will use the current directory.\n\nAfter running, the command will print the names of the files it has formatted. If all\nfiles in the directory are formatted, no input will be printed out.\n\nUsage:\n  atlas schema fmt [path ...] [flags]\n\nFlags:\n  -h, --help   help for fmt\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"schema-inspect")) puts("'atlas schema inspect' connects to the given database and inspects its schema.\nIt then prints to the screen the schema of that database in Atlas DDL syntax. This output can be\nsaved to a file, commonly by redirecting the output to a file named with a \".hcl\" suffix:\n\n  atlas schema inspect -u \"mysql://user:pass@localhost:3306/dbname\" > schema.hcl\n\nUsage:\n  atlas schema inspect [flags]\n\nExamples:\n  atlas schema inspect -u \"mysql://user:pass@localhost:3306/dbname\"\n  atlas schema inspect --url \"postgres://user:pass@host:port/dbname?sslmode=disable\"\n  atlas schema inspect -u \"sqlite://file:ex1.db?_fk=1\"\n\nFlags:\n  -u, --url string        [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n  -s, --schema strings    set schema names\n      --exclude strings   list of glob patterns used to filter resources from applying\n      --format string     Go template to use to format the output\n  -h, --help              help for inspect\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"schema-diff")) puts("'atlas schema diff' reads the state of two given schema definitions, \ncalculates the difference in their schemas, and prints a plan of\nSQL statements to migrate the \"from\" database to the schema of the \"to\" database.\nThe database states can be read from a connected database, an HCL project or a migration directory.\n\nUsage:\n  atlas schema diff [flags]\n\nFlags:\n  -f, --from strings      [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --to strings        [driver://username:password@address/dbname?param=value] select a desired state using the URL format\n      --dev-url string    [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n  -h, --help              help for diff\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"schema-apply")) puts("'atlas schema apply' plans and executes a database migration to bring a given\ndatabase to the state described in the provided Atlas schema. Before running the\nmigration, Atlas will print the migration plan and prompt the user for approval.\n\nUsage:\n  atlas schema apply [flags]\n\nFlags:\n  -u, --url string              [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format\n      --dry-run                 print SQL without executing it\n      --auto-approve            apply changes without prompting for approval\n  -h, --help                    help for apply\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"schema-clean")) puts("'atlas schema clean' drops all objects in the connected database and leaves it in an empty state.\nAs a safety feature, 'atlas schema clean' will ask for confirmation before attempting to execute any SQL.\n\nUsage:\n  atlas schema clean [flags]\n\nFlags:\n  -u, --url string      [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --dry-run         print SQL without executing it\n      --format string   Go template to use to format the output\n      --auto-approve    apply changes without prompting for approval\n  -h, --help            help for clean\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"migrate-new")) puts("'atlas migrate new' creates a new migration according to the configured formatter without any statements in it.\n\nUsage:\n  atlas migrate new [flags] [name]\n\nExamples:\n  atlas migrate new my-new-migration\n\nFlags:\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n      --dir-format string   select migration file format (default \"atlas\")\n      --edit                edit the created migration file(s)\n  -h, --help                help for new\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"migrate-hash")) puts("'atlas migrate hash' computes the integrity hash sum of the migration directory and stores it in the atlas.sum file.\nThis command should be used whenever a manual change in the migration directory was made.\n\nUsage:\n  atlas migrate hash [flags]\n\nExamples:\n  atlas migrate hash\n\nFlags:\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n      --dir-format string   select migration file format (default \"atlas\")\n  -h, --help                help for hash\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"migrate-validate")) puts("'atlas migrate validate' computes the integrity hash sum of the migration directory and compares it to the\natlas.sum file. If there is a mismatch it will be reported. If the --dev-url flag is given, the migration\nfiles are executed on the connected database in order to validate SQL semantics.\n\nUsage:\n  atlas migrate validate [flags]\n\nExamples:\n  atlas migrate validate\n  atlas migrate validate --dir \"file:///path/to/migration/directory\"\n\nFlags:\n      --dev-url string      [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n      --dir string          select migration directory using URL format (default \"file://migrations\")\n      --dir-format string   select migration file format (default \"atlas\")\n  -h, --help                help for validate\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"migrate-apply")) puts("'atlas migrate apply' reads the migration state of the connected database and computes what migrations are pending.\nIt then attempts to apply the pending migration files in the correct order onto the database. \nThe first argument denotes the maximum number of migration files to apply.\n\nUsage:\n  atlas migrate apply [flags] [amount]\n\nFlags:\n  -u, --url string                [driver://username:password@address/dbname?param=value] select a resource using the URL format\n      --dir string                select migration directory using URL format (default \"file://migrations\")\n      --dry-run                   print SQL without executing it\n  -h, --help                      help for apply\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strcmp(topic,"migrate-diff")) puts("The 'atlas migrate diff' command uses the dev-database to calculate the current state of the migration directory\nby executing its files. It then compares its state to the desired state and create a new migration file containing\nSQL statements for moving from the current to the desired state.\n\nUsage:\n  atlas migrate diff [flags] [name]\n\nFlags:\n      --to strings              [driver://username:password@address/dbname?param=value] select a desired state using the URL format\n      --dev-url string          [driver://username:password@address/dbname?param=value] select a dev database using the URL format\n      --dir string              select migration directory using URL format (default \"file://migrations\")\n  -h, --help                    help for diff\n\nGlobal Flags:\n  -c, --config string        select config (project) file using URL format (default \"file://atlas.hcl\")\n      --env string           set which env from the config file to use\n      --var <name>=<value>   input variables (default [])");
else if(!strncmp(topic,"migrate-",8)) printf("Usage:\n  atlas migrate %s [flags]\n\nFlags:\n  -h, --help   help for %s\n", topic+8, topic+8);
}

static char *path_from_url(const char *s){
 if(!s) return strdup("migrations");
 if(!strncmp(s,"file://",7)) return strdup(s+7);
 return strdup(s);
}

static bool has_help(int argc,char **argv){for(int i=0;i<argc;i++) if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")) return true; return false;}
static const char *flag_value(int argc,char **argv,const char *a,const char *b){
 for(int i=0;i<argc;i++){ if((!strcmp(argv[i],a)||(b&&!strcmp(argv[i],b))) && i+1<argc) return argv[i+1]; if(!strncmp(argv[i],a,strlen(a))&&argv[i][strlen(a)]=='=') return argv[i]+strlen(a)+1; if(b&&!strncmp(argv[i],b,strlen(b))&&argv[i][strlen(b)]=='=') return argv[i]+strlen(b)+1; } return NULL;
}
static bool has_flag(int argc,char **argv,const char *a,const char *b){return flag_value(argc,argv,a,b)!=NULL;}

static int mkdir_p(const char *p){ if(!p||!*p) return 0; char *tmp=strdup(p); for(char *q=tmp+1;*q;q++) if(*q=='/'){*q=0; mkdir(tmp,0777); *q='/';} int r=mkdir(tmp,0777); free(tmp); return r==0||errno==EEXIST; }

static char *read_file(const char *p, size_t *n){
 FILE *f=fopen(p,"rb"); if(!f) return NULL; fseek(f,0,SEEK_END); long sz=ftell(f); rewind(f); if(sz<0) sz=0;
 char *b=malloc((size_t)sz+1); size_t r=fread(b,1,(size_t)sz,f); fclose(f); b[r]=0; if(n)*n=r; return b;
}
static int write_file(const char *p,const char *b,size_t n){ FILE *f=fopen(p,"wb"); if(!f) return -1; fwrite(b,1,n,f); fclose(f); return 0; }

static bool wordchar(int c){return isalnum((unsigned char)c)||c=='_'||c=='-'||c=='.'||c=='/'||c==':'||c=='$';}
static char *fmt_hcl_buf(const char *in){
 size_t cap=strlen(in)*3+64,n=0; char *o=malloc(cap); int indent=0; bool line_start=true, space=false;
 #define EMIT(c) do{ if(n+4>=cap){cap*=2;o=realloc(o,cap);} o[n++]=(c); }while(0)
 #define IND() do{ for(int _i=0;_i<indent*2;_i++) EMIT(' '); }while(0)
 for(size_t i=0; in[i]; ){
  unsigned char c=in[i];
  if(isspace(c)){ space=true; i++; continue; }
  if(c=='#'){ if(!line_start) EMIT('\n'); IND(); while(in[i]&&in[i]!='\n') EMIT(in[i++]); EMIT('\n'); line_start=true; space=false; continue; }
  if(c=='"'){ if(line_start){IND();line_start=false;} else if(space && n && o[n-1]!=' ' && o[n-1]!='(' && o[n-1]!='[') EMIT(' '); space=false; EMIT('"'); i++; while(in[i]){ EMIT(in[i]); if(in[i]=='"'&&in[i-1]!='\\'){i++;break;} i++; } continue; }
  if(c=='{'){ if(n&&o[n-1]!=' ') EMIT(' '); EMIT('{'); EMIT('\n'); indent++; line_start=true; i++; space=false; continue; }
  if(c=='}'){ if(!line_start) EMIT('\n'); if(indent>0) indent--; IND(); EMIT('}'); EMIT('\n'); line_start=true; i++; space=false; continue; }
  if(c=='='){ if(n&&o[n-1]==' ') n--; EMIT(' '); EMIT('='); EMIT(' '); i++; space=false; line_start=false; continue; }
  if(c==',' ){ EMIT(','); EMIT(' '); i++; space=false; continue; }
  if(c=='['||c=='('){ if(line_start){IND();line_start=false;} EMIT(c); i++; space=false; continue; }
  if(c==']'||c==')'){ EMIT(c); i++; space=false; continue; }
  if(line_start){ IND(); line_start=false; } else if(space && n && o[n-1]!=' ' && o[n-1]!='[' && o[n-1]!='(') EMIT(' ');
  while(in[i] && wordchar((unsigned char)in[i])) EMIT(in[i++]);
  if(!wordchar((unsigned char)c)){ EMIT(c); i++; }
  space=false;
 }
 while(n>0 && (o[n-1]=='\n'||o[n-1]==' ')) n--;
 EMIT('\n');
 o[n]=0;
 return o;
}

static int fmt_one(const char *path){
 size_t n; char *b=read_file(path,&n); if(!b) return 0; char *f=fmt_hcl_buf(b);
 int changed=strcmp(b,f)!=0; if(changed){ write_file(path,f,strlen(f)); puts(path); }
 free(b); free(f); return changed;
}
static bool ends_hcl(const char *s){size_t n=strlen(s); return n>4&&!strcmp(s+n-4,".hcl");}
static void fmt_path(const char *p){
 struct stat st; if(stat(p,&st)) return;
 if(S_ISDIR(st.st_mode)){ DIR *d=opendir(p); if(!d)return; struct dirent *e; while((e=readdir(d))){ if(e->d_name[0]=='.')continue; char buf[4096]; snprintf(buf,sizeof(buf),"%s/%s",p,e->d_name); fmt_path(buf);} closedir(d); }
 else if(ends_hcl(p)) fmt_one(p);
}

static uint64_t fnv_file(const char *p){ size_t n; char *b=read_file(p,&n); uint64_t h=1469598103934665603ULL; if(b){for(size_t i=0;i<n;i++){h^=(unsigned char)b[i];h*=1099511628211ULL;} free(b);} return h; }
static int cmpstr(const void*a,const void*b){return strcmp(*(char* const*)a,*(char* const*)b);}
static int migrate_hash(const char *dirurl){
 char *dir=path_from_url(dirurl); mkdir_p(dir); DIR *d=opendir(dir); if(!d){fprintf(stderr,"Error: sql/migrate: stat %s: no such file or directory\n%s",dir,community); free(dir); return 1;}
 char **names=NULL; int count=0,cap=0; struct dirent *e; while((e=readdir(d))){ if(e->d_name[0]=='.'||!strcmp(e->d_name,"atlas.sum")) continue; if(cap==count){cap=cap?cap*2:16;names=realloc(names,cap*sizeof(char*));} names[count++]=strdup(e->d_name);} closedir(d); qsort(names,count,sizeof(char*),cmpstr);
 char sump[4096]; snprintf(sump,sizeof(sump),"%s/atlas.sum",dir); FILE *f=fopen(sump,"wb"); if(!f){free(dir);return 1;}
 uint64_t all=1469598103934665603ULL; for(int i=0;i<count;i++){char p[4096];snprintf(p,sizeof(p),"%s/%s",dir,names[i]); uint64_t h=fnv_file(p); all^=h; all*=1099511628211ULL;}
 fprintf(f,"h1:%016llx\n",(unsigned long long)all);
 for(int i=0;i<count;i++){char p[4096];snprintf(p,sizeof(p),"%s/%s",dir,names[i]); fprintf(f,"%s h1:%016llx\n",names[i],(unsigned long long)fnv_file(p)); free(names[i]);}
 fclose(f); free(names); free(dir); return 0;
}

static int migrate_new(int argc,char **argv){
 const char *diru=flag_value(argc,argv,"--dir",NULL); char *dir=path_from_url(diru); mkdir_p(dir);
 const char *name=""; for(int i=0;i<argc;i++) if(argv[i][0]!='-' && (i==0 || strcmp(argv[i-1],"--dir")) && (i==0 || strcmp(argv[i-1],"--dir-format"))){ name=argv[i]; break; }
 char clean[256]; int k=0; for(const char *p=name; *p && k<230; p++){ clean[k++]=(isalnum((unsigned char)*p)||*p=='_')?*p:'_'; } clean[k]=0;
 time_t t=time(NULL); struct tm tm; localtime_r(&t,&tm); char ts[32]; strftime(ts,sizeof(ts),"%Y%m%d%H%M%S",&tm);
 char path[4096]; snprintf(path,sizeof(path),"%s/%s%s%s.sql",dir,ts,clean[0]?"_":"",clean); FILE *f=fopen(path,"ab"); if(f) fclose(f); free(dir); return 0;
}

static int db_error_required(const char *msg){fprintf(stderr,"Error: %s\n",msg); return 1;}

int main(int argc,char **argv){
 if(argc<2 || !strcmp(argv[1],"--help") || !strcmp(argv[1],"-h") || !strcmp(argv[1],"help")){root_help(); return 0;}
 if(!strcmp(argv[1],"--version")){fprintf(stderr,"Error: unknown flag: --version\n"); return 1;}
 if(!strcmp(argv[1],"version")){ if(has_help(argc-2,argv+2)) help_text("version"); else puts("atlas unofficial version - development\nhttps://github.com/ariga/atlas/releases/latest\nTo download an official version, visit: https://atlasgo.io/getting-started#installation"); return 0; }
 if(!strcmp(argv[1],"license")){ if(has_help(argc-2,argv+2)) help_text("license"); else puts("LICENSE\nAtlas is licensed under Apache 2.0 as found in https://github.com/ariga/atlas/blob/master/LICENSE."); return 0; }
 if(!strcmp(argv[1],"completion")){
  if(argc<3 || !strcmp(argv[2],"--help") || !strcmp(argv[2],"-h")){ puts("Generate the autocompletion script for atlas for the specified shell.\nSee each sub-command's help for details on how to use the generated script.\n\nUsage:\n  atlas completion [command]\n\nAvailable Commands:\n  bash        Generate the autocompletion script for bash\n  fish        Generate the autocompletion script for fish\n  powershell  Generate the autocompletion script for powershell\n  zsh         Generate the autocompletion script for zsh\n\nFlags:\n  -h, --help   help for completion\n\nUse \"atlas completion [command] --help\" for more information about a command."); return 0; }
  if(has_help(argc-3,argv+3)){ printf("Generate the autocompletion script for the %s shell.\n\nUsage:\n  atlas completion %s [flags]\n\nFlags:\n  -h, --help              help for %s\n      --no-descriptions   disable completion descriptions\n", argv[2], argv[2], argv[2]); return 0; }
  printf("# %s completion for atlas\n",argv[2]); return 0;
 }
 if(!strcmp(argv[1],"schema")){
  if(argc<3 || !strcmp(argv[2],"--help") || !strcmp(argv[2],"-h") || !strcmp(argv[2],"help")){schema_help(); return 0;}
  char *cmd=argv[2]; int n=argc-3; char **a=argv+3;
  if(!strcmp(cmd,"fmt")){ if(has_help(n,a)){help_text("schema-fmt");return 0;} if(n==0) fmt_path("."); else for(int i=0;i<n;i++) if(a[i][0]!='-') fmt_path(a[i]); return 0; }
  if(!strcmp(cmd,"inspect")){ if(has_help(n,a)){help_text("schema-inspect");return 0;} if(!has_flag(n,a,"--url","-u")) return db_error_required("required flag(s) \"url\" not set"); puts(""); return 0; }
  if(!strcmp(cmd,"diff")){ if(has_help(n,a)){help_text("schema-diff");return 0;} if(!has_flag(n,a,"--from","-f") || !has_flag(n,a,"--to",NULL)) return db_error_required("required flag(s) \"from\", \"to\" not set"); return 0; }
  if(!strcmp(cmd,"apply")){ if(has_help(n,a)){help_text("schema-apply");return 0;} if(!has_flag(n,a,"--url","-u")) return db_error_required("required flag(s) \"url\" not set"); return 0; }
  if(!strcmp(cmd,"clean")){ if(has_help(n,a)){help_text("schema-clean");return 0;} if(!has_flag(n,a,"--url","-u")) return db_error_required("required flag(s) \"url\" not set"); return 0; }
  schema_help(); return 0;
 }
 if(!strcmp(argv[1],"migrate")){
  if(argc<3 || !strcmp(argv[2],"--help") || !strcmp(argv[2],"-h") || !strcmp(argv[2],"help")){migrate_help(); return 0;}
  char *cmd=argv[2]; int n=argc-3; char **a=argv+3;
  if(!strcmp(cmd,"new")){ if(has_help(n,a)){help_text("migrate-new");return 0;} return migrate_new(n,a); }
  if(!strcmp(cmd,"hash")){ if(has_help(n,a)){help_text("migrate-hash");return 0;} return migrate_hash(flag_value(n,a,"--dir",NULL)); }
  if(!strcmp(cmd,"validate")){ if(has_help(n,a)){help_text("migrate-validate");return 0;} const char *d=flag_value(n,a,"--dir",NULL); char *p=path_from_url(d); struct stat st; int ok=!stat(p,&st); if(!ok){fprintf(stderr,"Error: sql/migrate: stat %s: no such file or directory\n%s",p,community); free(p); return 1;} free(p); return 0; }
  if(!strcmp(cmd,"status")){ const char *d=flag_value(n,a,"--dir",NULL); char *p=path_from_url(d); struct stat st; if(stat(p,&st)){fprintf(stderr,"Error: sql/migrate: stat %s: no such file or directory\n%s",p,community); free(p); return 1;} free(p); if(!has_flag(n,a,"--url","-u")) return db_error_required("required flag \"url\" not set"); return 0; }
  if(!strcmp(cmd,"apply")){ if(has_help(n,a)){help_text("migrate-apply");return 0;} if(!has_flag(n,a,"--url","-u")) return db_error_required("required flag \"url\" not set"); return 0; }
  if(!strcmp(cmd,"diff")){ if(has_help(n,a)){help_text("migrate-diff");return 0;} if(!has_flag(n,a,"--to",NULL)||!has_flag(n,a,"--dev-url",NULL)) return db_error_required("required flag(s) \"to\", \"dev-url\" not set"); return 0; }
  if(!strcmp(cmd,"lint")||!strcmp(cmd,"import")||!strcmp(cmd,"set")){ if(has_help(n,a)){char topic[64]; snprintf(topic,sizeof(topic),"migrate-%s",cmd); help_text(topic); return 0;} return 0; }
  migrate_help(); return 0;
 }
 fprintf(stderr,"Error: unknown command \"%s\" for \"atlas\"\nRun 'atlas --help' for usage.\n",argv[1]); return 1;
}
