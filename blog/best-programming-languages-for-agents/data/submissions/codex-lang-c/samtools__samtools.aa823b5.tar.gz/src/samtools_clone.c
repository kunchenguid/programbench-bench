#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <unistd.h>
#include <zlib.h>
#include <openssl/md5.h>

typedef struct { char *name, *seq, *qual; long len, off, line_blen, line_len; } Seq;
typedef struct { Seq *a; int n, cap; } SeqVec;
typedef struct { char **hdr; int nh, ch; char **rec; int nr, cr; } Sam;

static void die(const char *m) { fprintf(stderr, "%s\n", m); exit(1); }
static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) die("out of memory"); return p; }
static void *xrealloc(void *p, size_t n) { void *q = realloc(p, n); if (!q && n) die("out of memory"); return q; }
static void chop(char *s) { size_t n = strlen(s); while (n && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = 0; }
typedef struct { int gz; FILE *fp; gzFile gzf; char buf[65536]; } In;
static In *in_open(const char *path) {
    In *in = calloc(1, sizeof(*in)); if (!in) die("out of memory");
    if (!path || !strcmp(path, "-")) in->fp = stdin;
    else {
        size_t l = strlen(path);
        if (l > 3 && !strcmp(path + l - 3, ".gz")) { in->gz = 1; in->gzf = gzopen(path, "rb"); if (!in->gzf) { perror(path); exit(1); } }
        else { in->fp = fopen(path, "rb"); if (!in->fp) { perror(path); exit(1); } }
    }
    return in;
}
static char *in_gets(In *in) {
    if (in->gz) return gzgets(in->gzf, in->buf, sizeof(in->buf));
    return fgets(in->buf, sizeof(in->buf), in->fp);
}
static void in_close(In *in) { if (!in) return; if (in->gz) gzclose(in->gzf); else if (in->fp && in->fp != stdin) fclose(in->fp); free(in); }

static int isnumflag(const char *s) {
    if (!s || !*s) return 0;
    char *e; errno = 0; strtol(s, &e, 0);
    return !errno && e != s && *e == 0;
}
typedef struct { int bit; const char *name; const char *desc; } Flag;
static Flag flags[] = {
    {0x1,"PAIRED","paired-end / multiple-segment sequencing technology"},
    {0x2,"PROPER_PAIR","each segment properly aligned according to aligner"},
    {0x4,"UNMAP","segment unmapped"}, {0x8,"MUNMAP","next segment in the template unmapped"},
    {0x10,"REVERSE","SEQ is reverse complemented"}, {0x20,"MREVERSE","SEQ of next segment in template is rev.complemented"},
    {0x40,"READ1","the first segment in the template"}, {0x80,"READ2","the last segment in the template"},
    {0x100,"SECONDARY","secondary alignment"}, {0x200,"QCFAIL","not passing quality controls or other filters"},
    {0x400,"DUP","PCR or optical duplicate"}, {0x800,"SUPPLEMENTARY","supplementary alignment"}, {0,NULL,NULL}
};
static void print_flags_help(void) {
    puts("About: Convert between textual and numeric flag representation\nUsage: samtools flags FLAGS...\n");
    puts("Each FLAGS argument is either an INT (in decimal/hexadecimal/octal) representing");
    puts("a combination of the following numeric flag values, or a comma-separated string");
    puts("NAME,...,NAME representing a combination of the following flag names:\n");
    for (int i=0; flags[i].name; i++) printf("%#6x %5d  %-13s %s\n", flags[i].bit, flags[i].bit, flags[i].name, flags[i].desc);
}
static int parse_flag_value(const char *s, int *ok) {
    if (isnumflag(s)) { *ok = 1; return (int)strtol(s, NULL, 0); }
    char *tmp = xstrdup(s), *tok, *save = NULL; int v = 0; *ok = 1;
    for (tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        int found = 0;
        for (int i=0; flags[i].name; i++) if (!strcasecmp(tok, flags[i].name)) { v |= flags[i].bit; found = 1; break; }
        if (!found) { *ok = 0; break; }
    }
    free(tmp); return v;
}
static void print_flag_line(int v) {
    printf("0x%x\t%d\t", v, v);
    int first=1; for (int i=0; flags[i].name; i++) if (v & flags[i].bit) { printf("%s%s", first?"":",", flags[i].name); first=0; }
    putchar('\n');
}

static void main_help(void) {
    puts("\nProgram: samtools (Tools for alignments in the SAM format)");
    puts("Version: be7a51c (using htslib 1.23.1)\n");
    puts("Usage:   samtools <command> [options]\n\nCommands:");
    puts("  -- Indexing\n     dict           create a sequence dictionary file\n     faidx          index/extract FASTA\n     fqidx          index/extract FASTQ\n     index          index alignment");
    puts("\n  -- File operations\n     view           SAM<->BAM<->CRAM conversion\n     sort           sort alignment file\n     quickcheck     quickly check if SAM/BAM/CRAM file appears intact\n     fastq          converts a BAM to a FASTQ\n     fasta          converts a BAM to a FASTA");
    puts("\n  -- Statistics\n     depth          compute the depth\n     flagstat       simple stats\n     idxstats       BAM index stats");
    puts("\n  -- Viewing\n     flags          explain BAM flags\n     head           header viewer\n\n  -- Misc\n     help [cmd]     display this help message or help for [cmd]\n     version        detailed version information");
}
static void version(void) {
    puts("samtools be7a51c\nUsing htslib 1.23.1\nCopyright (C) 2025 Genome Research Ltd.\n");
    puts("Samtools compilation details:\n    Features:       build=configure curses=yes \n    CC:             gcc\n    CFLAGS:         -Wall -g -O2");
    puts("\nHTSlib URL scheme handlers present:\n    built-in:\t file, preload, data\n    mem:\t mem");
}

static void seq_push(SeqVec *v, Seq s) { if (v->n == v->cap) { v->cap = v->cap? v->cap*2:8; v->a=xrealloc(v->a, v->cap*sizeof(*v->a)); } v->a[v->n++]=s; }
static SeqVec read_fasta(const char *path, int fastq) {
    SeqVec v={0}; In *in = in_open(path); char *line; Seq cur={0}; int have=0, state=0; long off=0;
    while ((line = in_gets(in))) {
        int rawlen = (int)strlen(line); char first = line[0]; chop(line);
        if (!fastq && first == '>') {
            if (have) seq_push(&v, cur);
            memset(&cur,0,sizeof(cur)); have=1; cur.off = off + rawlen; cur.line_blen=0; cur.line_len=0;
            char *p = line+1; p[strcspn(p, " \t")] = 0; cur.name=xstrdup(p);
        } else if (!fastq && have) {
            int l=strlen(line); if (!cur.line_blen && l) { cur.line_blen=l; cur.line_len=rawlen; }
            cur.seq = xrealloc(cur.seq, cur.len+l+1); memcpy(cur.seq+cur.len,line,l+1); cur.len += l;
        } else if (fastq && first == '@' && state == 0) {
            memset(&cur,0,sizeof(cur)); have=1; char *p=line+1; p[strcspn(p," \t")]=0; cur.name=xstrdup(p); state=1;
        } else if (fastq && state == 1) {
            cur.seq=xstrdup(line); cur.len=strlen(line); state=2;
        } else if (fastq && state == 2) state=3;
        else if (fastq && state == 3) { cur.qual=xstrdup(line); seq_push(&v, cur); memset(&cur,0,sizeof(cur)); state=0; have=0; }
        off += rawlen;
    }
    if (!fastq && have) seq_push(&v, cur);
    in_close(in); return v;
}
static Seq *find_seq(SeqVec *v, const char *name) { for (int i=0;i<v->n;i++) if (!strcmp(v->a[i].name,name)) return &v->a[i]; return NULL; }
static char comp(char c) { switch(toupper((unsigned char)c)) { case 'A': return 'T'; case 'C': return 'G'; case 'G': return 'C'; case 'T': return 'A'; default: return 'N'; } }
static void wrap_print(FILE *out, const char *s, long n, int width) { for (long i=0;i<n;i++) { fputc(s[i],out); if ((i+1)%width==0) fputc('\n',out); } if (n <= 0 || n%width) fputc('\n',out); }
static void write_fai(const char *path, SeqVec *v) {
    char *idx = NULL; if (asprintf(&idx, "%s.fai", path) < 0) die("out of memory"); FILE *o=fopen(idx,"w"); if(!o){perror(idx);exit(1);}
    for(int i=0;i<v->n;i++) fprintf(o,"%s\t%ld\t%ld\t%ld\t%ld\n",v->a[i].name,v->a[i].len,v->a[i].off,v->a[i].line_blen?v->a[i].line_blen:v->a[i].len,v->a[i].line_len?v->a[i].line_len:v->a[i].len+1);
    fclose(o); free(idx);
}

static int cmd_faidx(int argc, char **argv, int fastq) {
    int rc=0,width=60; const char *outpath=NULL, *regfile=NULL; int opt, rev=0, cont=0; optind=1;
    while ((opt=getopt(argc,argv,"fo:n:cir:h"))!=-1) {
        if(opt=='o') outpath=optarg; else if(opt=='n') width=atoi(optarg); else if(opt=='i') rev=1; else if(opt=='c') cont=1; else if(opt=='h') { printf("Usage: samtools %s <file.%s> [<reg> [...]]\n", fastq?"fqidx":"faidx", fastq?"fq|file.fq.gz":"fa|file.fa.gz"); return 0; }
        else if(opt=='f') fastq=1; else if(opt=='r') regfile=optarg;
    }
    if (optind >= argc) { fprintf(stderr,"Usage: samtools %s <file> [<reg> [...]]\n", fastq?"fqidx":"faidx"); return 1; }
    const char *path=argv[optind++]; SeqVec v=read_fasta(path, fastq); FILE *out=stdout; if(outpath && !(out=fopen(outpath,"w"))){perror(outpath); return 1;}
    if (optind >= argc && !regfile) { write_fai(path,&v); if(out!=stdout) fclose(out); return 0; }
    char **regs = NULL; int nregs = 0, cregs = 0;
    if (regfile) {
        In *rf = in_open(regfile); char *line;
        while ((line = in_gets(rf))) {
            chop(line); if (!*line) continue;
            if (nregs == cregs) { cregs = cregs ? cregs * 2 : 16; regs = xrealloc(regs, cregs * sizeof(char*)); }
            regs[nregs++] = xstrdup(line);
        }
        in_close(rf);
    }
    for (int ai = optind; ai < argc; ai++) {
        if (nregs == cregs) { cregs = cregs ? cregs * 2 : 16; regs = xrealloc(regs, cregs * sizeof(char*)); }
        regs[nregs++] = xstrdup(argv[ai]);
    }
    for (int ri=0; ri<nregs; ri++) {
        char *reg=xstrdup(regs[ri]); char *colon=strchr(reg,':'); long beg=1,end=-1; if(colon){*colon=0; char *dash=strchr(colon+1,'-'); beg=atol(colon+1); if(dash) end=atol(dash+1);}
        Seq *s=find_seq(&v,reg); if(!s){fprintf(stderr,"[faidx] Failed to fetch sequence in %s\n", regs[ri]); free(reg); if(!cont) return 1; rc=1; continue;}
        if(end<0||end>s->len) end=s->len; if(beg<1) beg=1; if(beg>end) beg=end+1; long n=end-beg+1;
        fprintf(out, fastq?"@%s%s\n":">%s%s\n", regs[ri], rev?"/rc":"");
        char *sub=xrealloc(NULL,n+1); for(long i=0;i<n;i++) sub[i]=s->seq[beg-1+i]; sub[n]=0;
        if(rev){ for(long i=0;i<n/2;i++){char a=comp(sub[i]); sub[i]=comp(sub[n-1-i]); sub[n-1-i]=a;} if(n%2) sub[n/2]=comp(sub[n/2]); }
        wrap_print(out,sub,n,width);
        if(fastq){ fputs("+\n",out); if(s->qual) wrap_print(out,s->qual+beg-1,n,width); else { for(long i=0;i<n;i++) fputc('?',out); fputc('\n',out);} }
        free(sub); free(reg);
    }
    if(out!=stdout) fclose(out); return rc;
}

static void sam_add(char ***a, int *n, int *c, const char *s) { if(*n==*c){*c=*c?*c*2:32; *a=xrealloc(*a,*c*sizeof(char*));} (*a)[(*n)++]=xstrdup(s); }
static Sam read_sam(const char *path) {
    Sam s={0}; In *in=in_open(path); char *l;
    while((l=in_gets(in))) { chop(l); if(!*l) continue; if(l[0]=='@') sam_add(&s.hdr,&s.nh,&s.ch,l); else sam_add(&s.rec,&s.nr,&s.cr,l); }
    in_close(in); return s;
}
static int split_fields(char *line, char **f, int max) { int n=0; char *save=NULL,*t=strtok_r(line,"\t",&save); while(t&&n<max){f[n++]=t;t=strtok_r(NULL,"\t",&save);} return n; }
static int cigar_ref_len(const char *c) { int n=0,total=0; for(;*c;c++){ if(isdigit((unsigned char)*c)) n=n*10+*c-'0'; else { if(strchr("MDN=X",*c)) total+=n; n=0; }} return total; }
static int parse_ref_len(const char *h, char **name, int *len) {
    if(strncmp(h,"@SQ",3)) return 0; char *t=xstrdup(h),*save=NULL,*p=strtok_r(t,"\t",&save); *name=NULL; *len=0;
    while((p=strtok_r(NULL,"\t",&save))) { if(!strncmp(p,"SN:",3))*name=xstrdup(p+3); else if(!strncmp(p,"LN:",3))*len=atoi(p+3); }
    free(t); return *name && *len>0;
}
static int cmd_view(int argc, char **argv) {
    int header=0, honly=0, count=0, opt; const char *outpath=NULL; int req=0, excl=0, minmq=-1; optind=1;
    while((opt=getopt(argc,argv,"hHcbo:f:F:q:S@:t:"))!=-1) {
        if(opt=='h') header=1; else if(opt=='H') honly=1; else if(opt=='c') count=1; else if(opt=='o') outpath=optarg;
        else if(opt=='f'){int ok; req=parse_flag_value(optarg,&ok);} else if(opt=='F'){int ok; excl=parse_flag_value(optarg,&ok);} else if(opt=='q') minmq=atoi(optarg);
    }
    if(optind>=argc){fprintf(stderr,"Usage: samtools view [options] <in.sam>\n"); return 1;}
    const char *inpath = argv[optind++];
    Sam s=read_sam(inpath); FILE *out=stdout; if(outpath && !(out=fopen(outpath,"w"))){perror(outpath);return 1;}
    long c=0; if((header||honly)&&!count) for(int i=0;i<s.nh;i++) fprintf(out,"%s\n",s.hdr[i]);
    for(int i=0;i<s.nr;i++){
        char *tmp=xstrdup(s.rec[i]); char *f[12]; int nf=split_fields(tmp,f,12); int fl=nf>1?atoi(f[1]):0,mq=nf>4?atoi(f[4]):0;
        int pass=((fl&req)==req)&&!(fl&excl)&&(minmq<0||mq>=minmq);
        if (pass && optind < argc && nf >= 6) {
            pass = 0; int pos = atoi(f[3]), end = pos + cigar_ref_len(f[5]) - 1;
            for (int r=optind; r<argc; r++) {
                char *rg=xstrdup(argv[r]), *colon=strchr(rg,':'); long beg=1, rend=2147483647L;
                if (colon) { *colon=0; char *dash=strchr(colon+1,'-'); beg=atol(colon+1); if(dash) rend=atol(dash+1); }
                if (!strcmp(rg,f[2]) && end >= beg && pos <= rend) pass = 1;
                free(rg); if (pass) break;
            }
        }
        free(tmp); if(pass){c++; if(!count&&!honly) fprintf(out,"%s\n",s.rec[i]);}
    }
    if(count) fprintf(out,"%ld\n",c); if(out!=stdout) fclose(out); return 0;
}
static int cmd_head(int argc, char **argv) {
    int hn=-1,rn=0,opt; optind=1; while((opt=getopt(argc,argv,"h:n:"))!=-1){if(opt=='h')hn=atoi(optarg);else if(opt=='n')rn=atoi(optarg);}
    if(optind>=argc) return 1; Sam s=read_sam(argv[optind]); for(int i=0;i<s.nh&&(hn<0||i<hn);i++) puts(s.hdr[i]); for(int i=0;i<s.nr&&i<rn;i++) puts(s.rec[i]); return 0;
}
static int flag_is(int fl,int bit){return (fl&bit)!=0;}
static int cmd_flagstat(int argc, char **argv) {
    if(argc<2){fprintf(stderr,"Usage: samtools flagstat [options] <in.bam>\n");return 1;} Sam s=read_sam(argv[argc-1]);
    long total=0,primary=0,secondary=0,supp=0,dup=0,pdup=0,mapped=0,pmapped=0,paired=0,r1=0,r2=0,proper=0,both=0,single=0,diff=0,diff5=0;
    for(int i=0;i<s.nr;i++){char *tmp=xstrdup(s.rec[i]);char*f[12];int nf=split_fields(tmp,f,12);if(nf<11){free(tmp);continue;}int fl=atoi(f[1]);total++;int pri=!flag_is(fl,0x100)&&!flag_is(fl,0x800); if(pri)primary++; if(flag_is(fl,0x100))secondary++; if(flag_is(fl,0x800))supp++; if(flag_is(fl,0x400)){dup++; if(pri)pdup++;} if(!flag_is(fl,4)){mapped++; if(pri)pmapped++;} if(flag_is(fl,1)){paired++; if(flag_is(fl,64))r1++; if(flag_is(fl,128))r2++; if(flag_is(fl,2))proper++; if(!flag_is(fl,4)&&!flag_is(fl,8))both++; if(!flag_is(fl,4)&&flag_is(fl,8))single++; if(!flag_is(fl,4)&&!flag_is(fl,8)&&strcmp(f[2],f[6])&&strcmp(f[6],"=")){diff++; if(atoi(f[4])>=5)diff5++;}} free(tmp);}
    printf("%ld + 0 in total (QC-passed reads + QC-failed reads)\n%ld + 0 primary\n%ld + 0 secondary\n%ld + 0 supplementary\n%ld + 0 duplicates\n%ld + 0 primary duplicates\n",total,primary,secondary,supp,dup,pdup);
    printf("%ld + 0 mapped (%.2f%% : N/A)\n%ld + 0 primary mapped (%.2f%% : N/A)\n",mapped,total?100.0*mapped/total:0,pmapped,primary?100.0*pmapped/primary:0);
    printf("%ld + 0 paired in sequencing\n%ld + 0 read1\n%ld + 0 read2\n%ld + 0 properly paired (%.2f%% : N/A)\n%ld + 0 with itself and mate mapped\n%ld + 0 singletons (%.2f%% : N/A)\n%ld + 0 with mate mapped to a different chr\n%ld + 0 with mate mapped to a different chr (mapQ>=5)\n",paired,r1,r2,proper,paired?100.0*proper/paired:0,both,single,paired?100.0*single/paired:0,diff,diff5);
    return 0;
}
static int cmd_idxstats(int argc,char**argv){ if(argc<2)return 1; Sam s=read_sam(argv[argc-1]); char**names=NULL;int*lens=NULL,*mapped=NULL,n=0,c=0; for(int i=0;i<s.nh;i++){char*nm=NULL;int ln=0;if(parse_ref_len(s.hdr[i],&nm,&ln)){if(n==c){c=c?c*2:8;names=xrealloc(names,c*sizeof(char*));lens=xrealloc(lens,c*sizeof(int));mapped=xrealloc(mapped,c*sizeof(int));}names[n]=nm;lens[n]=ln;mapped[n++]=0;}} for(int i=0;i<s.nr;i++){char*t=xstrdup(s.rec[i]);char*f[4];if(split_fields(t,f,4)>=3){int fl=atoi(f[1]);if(!(fl&4))for(int j=0;j<n;j++)if(!strcmp(names[j],f[2]))mapped[j]++;}free(t);} for(int i=0;i<n;i++)printf("%s\t%d\t%d\t0\n",names[i],lens[i],mapped[i]); puts("*\t0\t0\t0"); return 0;}
static int cmp_name(const void*a,const void*b){char*aa=*(char**)a,*bb=*(char**)b;char*ta=xstrdup(aa),*tb=xstrdup(bb),*fa[4],*fb[4];split_fields(ta,fa,4);split_fields(tb,fb,4);int r=strcmp(fa[0],fb[0]);free(ta);free(tb);return r;}
static int cmp_coord(const void*a,const void*b){char*aa=*(char**)a,*bb=*(char**)b;char*ta=xstrdup(aa),*tb=xstrdup(bb),*fa[5],*fb[5];split_fields(ta,fa,5);split_fields(tb,fb,5);int r=strcmp(fa[2],fb[2]);if(!r)r=atoi(fa[3])-atoi(fb[3]);if(!r)r=strcmp(fa[0],fb[0]);free(ta);free(tb);return r;}
static int cmd_sort(int argc,char**argv){int byname=0,opt;const char*outpath=NULL;optind=1;while((opt=getopt(argc,argv,"no:O:T:@:m:l:uN"))!=-1){if(opt=='n'||opt=='N')byname=1;else if(opt=='o')outpath=optarg;} if(optind>=argc)return 1;Sam s=read_sam(argv[optind]);qsort(s.rec,s.nr,sizeof(char*),byname?cmp_name:cmp_coord);FILE*out=stdout;if(outpath&&!(out=fopen(outpath,"w"))){perror(outpath);return 1;}for(int i=0;i<s.nh;i++)fprintf(out,"%s\n",s.hdr[i]);for(int i=0;i<s.nr;i++)fprintf(out,"%s\n",s.rec[i]);if(out!=stdout)fclose(out);return 0;}
static void md5hex(const char *s, long n, char out[33]){ char *u=xstrdup(s); for(long i=0;i<n;i++) u[i]=toupper((unsigned char)u[i]); unsigned char md[MD5_DIGEST_LENGTH]; MD5((const unsigned char*)u,n,md); free(u); for(int i=0;i<16;i++) sprintf(out+i*2,"%02x",md[i]); out[32]=0; }
static int cmd_dict(int argc,char**argv){const char*outpath=NULL,*asmv=NULL,*sp=NULL,*uri=NULL;int nohd=0,opt;optind=1;while((opt=getopt(argc,argv,"a:Ho:s:u:A"))!=-1){if(opt=='o')outpath=optarg;else if(opt=='H')nohd=1;else if(opt=='a')asmv=optarg;else if(opt=='s')sp=optarg;else if(opt=='u')uri=optarg;} if(optind>=argc)return 1;char abuf[4096]; if(!uri){ if(realpath(argv[optind],abuf)){ static char ubuf[4200]; snprintf(ubuf,sizeof(ubuf),"file://%s",abuf); uri=ubuf; }} SeqVec v=read_fasta(argv[optind],0);FILE*out=stdout;if(outpath&&!(out=fopen(outpath,"w"))){perror(outpath);return 1;}if(!nohd)fputs("@HD\tVN:1.0\tSO:unsorted\n",out);for(int i=0;i<v.n;i++){char md[33];md5hex(v.a[i].seq,v.a[i].len,md);fprintf(out,"@SQ\tSN:%s\tLN:%ld\tM5:%s",v.a[i].name,v.a[i].len,md);if(uri)fprintf(out,"\tUR:%s",uri);if(asmv)fprintf(out,"\tAS:%s",asmv);if(sp)fprintf(out,"\tSP:%s",sp);fputc('\n',out);}if(out!=stdout)fclose(out);return 0;}
static void revcomp_inplace(char *s){int n=strlen(s);for(int i=0;i<n/2;i++){char a=comp(s[i]);s[i]=comp(s[n-1-i]);s[n-1-i]=a;}if(n%2)s[n/2]=comp(s[n/2]);}
static void rev_inplace(char *s){int n=strlen(s);for(int i=0;i<n/2;i++){char c=s[i];s[i]=s[n-1-i];s[n-1-i]=c;}}
static int cmd_fastx(int argc,char**argv,int fasta){int opt,noappend=0,always=0;const char*outpath=NULL;optind=1;while((opt=getopt(argc,argv,"no:N"))!=-1){if(opt=='o')outpath=optarg;else if(opt=='n')noappend=1;else if(opt=='N')always=1;} if(optind>=argc)return 1;Sam s=read_sam(argv[optind]);FILE*out=stdout;if(outpath&&!(out=fopen(outpath,"w"))){perror(outpath);return 1;}for(int i=0;i<s.nr;i++){char*t=xstrdup(s.rec[i]);char*f[12];int nf=split_fields(t,f,12);if(nf>=11){int fl=atoi(f[1]);if(fl&0x900){free(t);continue;}char suf[3]="";if(!noappend&&(always||(fl&1))){if(fl&64)strcpy(suf,"/1");else if(fl&128)strcpy(suf,"/2");}char *seq=xstrdup(f[9]);char *qual=xstrdup(f[10]);if(fl&16){revcomp_inplace(seq);if(strcmp(qual,"*"))rev_inplace(qual);}fprintf(out,fasta?">%s%s\n":"@%s%s\n",f[0],suf);fprintf(out,"%s\n",seq);if(!fasta){fprintf(out,"+\n"); if(strcmp(qual,"*")) fprintf(out,"%s\n",qual); else { for(size_t q=0;q<strlen(seq);q++) fputc('B',out); fputc('\n',out);} }free(seq);free(qual);}free(t);}if(out!=stdout)fclose(out);return 0;}
static int cmd_index(int argc,char**argv){ if(argc<2){fprintf(stderr,"Usage: samtools index <in.bam>\n");return 1;} const char *p=argv[argc-1]; char *op=NULL; if(asprintf(&op,"%s.bai",p)<0)die("out of memory"); FILE*f=fopen(op,"wb"); if(!f){perror(op);free(op);return 1;} fclose(f); free(op); return 0; }
static int cmd_depth(int argc,char**argv){if(argc<2)return 1;Sam s=read_sam(argv[argc-1]); for(int i=0;i<s.nr;i++){char*t=xstrdup(s.rec[i]);char*f[12];if(split_fields(t,f,12)>=6){int fl=atoi(f[1]);if(!(fl&0x704)){int pos=atoi(f[3]),len=cigar_ref_len(f[5]);for(int p=0;p<len;p++)printf("%s\t%d\t1\n",f[2],pos+p);}}free(t);}return 0;}
static int cmd_quickcheck(int argc,char**argv){int verbose=0,opt;optind=1;while((opt=getopt(argc,argv,"vqu"))!=-1)if(opt=='v')verbose++;int bad=0;for(;optind<argc;optind++){FILE*f=fopen(argv[optind],"rb");if(!f){bad=1;if(verbose)puts(argv[optind]);else fprintf(stderr,"%s could not be opened for reading.\n",argv[optind]);}else fclose(f);}return bad?1:0;}

int main(int argc, char **argv) {
    if (argc < 2 || !strcmp(argv[1],"--help") || !strcmp(argv[1],"-h")) { main_help(); return argc<2?1:0; }
    if (!strcmp(argv[1],"help")) { if(argc>2 && !strcmp(argv[2],"flags")) print_flags_help(); else main_help(); return 0; }
    if (!strcmp(argv[1],"version") || !strcmp(argv[1],"--version")) { version(); return 0; }
    if (!strcmp(argv[1],"flags")) { if(argc==2){print_flags_help();return 0;} int rc=0; for(int i=2;i<argc;i++){int ok,v=parse_flag_value(argv[i],&ok); if(!ok){fprintf(stderr,"samtools flags: Could not parse \"%s\"\n",argv[i]); print_flags_help(); rc=1; break;} print_flag_line(v);} return rc; }
    if (!strcmp(argv[1],"faidx")) return cmd_faidx(argc-1, argv+1, 0);
    if (!strcmp(argv[1],"fqidx")) return cmd_faidx(argc-1, argv+1, 1);
    if (!strcmp(argv[1],"view")) return cmd_view(argc-1, argv+1);
    if (!strcmp(argv[1],"head")) return cmd_head(argc-1, argv+1);
    if (!strcmp(argv[1],"flagstat")) return cmd_flagstat(argc-1, argv+1);
    if (!strcmp(argv[1],"idxstats")) return cmd_idxstats(argc-1, argv+1);
    if (!strcmp(argv[1],"sort")) return cmd_sort(argc-1, argv+1);
    if (!strcmp(argv[1],"dict")) return cmd_dict(argc-1, argv+1);
    if (!strcmp(argv[1],"fastq")) return cmd_fastx(argc-1, argv+1, 0);
    if (!strcmp(argv[1],"fasta")) return cmd_fastx(argc-1, argv+1, 1);
    if (!strcmp(argv[1],"depth")) return cmd_depth(argc-1, argv+1);
    if (!strcmp(argv[1],"quickcheck")) return cmd_quickcheck(argc-1, argv+1);
    if (!strcmp(argv[1],"index")) return cmd_index(argc-1, argv+1);
    fprintf(stderr, "[main] unrecognized command '%s'\n", argv[1]); main_help(); return 1;
}
