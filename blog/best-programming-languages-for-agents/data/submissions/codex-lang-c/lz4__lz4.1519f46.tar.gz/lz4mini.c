#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

#define MAGIC 0x184D2204u
#define LEGACY_MAGIC 0x184C2102u
#define SKIPPABLE_MIN 0x184D2A50u
#define SKIPPABLE_MAX 0x184D2A5Fu

typedef unsigned char byte;

static const char *prog = "executable";

static uint32_t rd32(const byte *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static void wr32(byte *p, uint32_t v) {
    p[0] = (byte)v; p[1] = (byte)(v >> 8); p[2] = (byte)(v >> 16); p[3] = (byte)(v >> 24);
}

static uint32_t rotl32(uint32_t x, int r) { return (x << r) | (x >> (32 - r)); }

static uint32_t xxh32(const void *input, size_t len, uint32_t seed) {
    const byte *p = (const byte *)input;
    const byte *end = p + len;
    const uint32_t P1 = 2654435761U, P2 = 2246822519U, P3 = 3266489917U, P4 = 668265263U, P5 = 374761393U;
    uint32_t h;
    if (len >= 16) {
        const byte *limit = end - 16;
        uint32_t v1 = seed + P1 + P2, v2 = seed + P2, v3 = seed, v4 = seed - P1;
        do {
            v1 = rotl32(v1 + rd32(p) * P2, 13) * P1; p += 4;
            v2 = rotl32(v2 + rd32(p) * P2, 13) * P1; p += 4;
            v3 = rotl32(v3 + rd32(p) * P2, 13) * P1; p += 4;
            v4 = rotl32(v4 + rd32(p) * P2, 13) * P1; p += 4;
        } while (p <= limit);
        h = rotl32(v1, 1) + rotl32(v2, 7) + rotl32(v3, 12) + rotl32(v4, 18);
    } else {
        h = seed + P5;
    }
    h += (uint32_t)len;
    while (p + 4 <= end) { h = rotl32(h + rd32(p) * P3, 17) * P4; p += 4; }
    while (p < end) { h = rotl32(h + (*p++) * P5, 11) * P1; }
    h ^= h >> 15; h *= P2; h ^= h >> 13; h *= P3; h ^= h >> 16;
    return h;
}

typedef struct {
    byte *p;
    size_t n, cap;
} Buf;

static int grow(Buf *b, size_t add) {
    if (add > (size_t)-1 - b->n) return -1;
    size_t need = b->n + add;
    if (need <= b->cap) return 0;
    size_t nc = b->cap ? b->cap * 2 : 65536;
    while (nc < need) {
        if (nc > (size_t)-1 / 2) { nc = need; break; }
        nc *= 2;
    }
    byte *np = (byte *)realloc(b->p, nc);
    if (!np) return -1;
    b->p = np; b->cap = nc;
    return 0;
}
static int append(Buf *b, const void *p, size_t n) {
    if (grow(b, n)) return -1;
    memcpy(b->p + b->n, p, n); b->n += n; return 0;
}
static int append_le32(Buf *b, uint32_t v) { byte tmp[4]; wr32(tmp, v); return append(b, tmp, 4); }

static int read_all(FILE *f, Buf *out) {
    byte tmp[65536];
    for (;;) {
        size_t r = fread(tmp, 1, sizeof tmp, f);
        if (r && append(out, tmp, r)) return -1;
        if (r < sizeof tmp) {
            if (ferror(f)) return -1;
            return 0;
        }
    }
}

static int read_file(const char *name, Buf *out) {
    FILE *f;
    if (!name || strcmp(name, "-") == 0) f = stdin;
    else {
        f = fopen(name, "rb");
        if (!f) { fprintf(stderr, "%s: %s: %s\n", prog, name, strerror(errno)); return -1; }
    }
    int rc = read_all(f, out);
    if (f != stdin) fclose(f);
    if (rc) fprintf(stderr, "%s: read error\n", prog);
    return rc;
}

static int write_file(const char *name, const byte *p, size_t n, int force) {
    FILE *f;
    if (!name || strcmp(name, "-") == 0 || strcmp(name, "stdout") == 0) f = stdout;
    else if (strcmp(name, "null") == 0) return 0;
    else {
        if (!force && access(name, F_OK) == 0) {
            fprintf(stderr, "%s: %s already exists; use -f to overwrite\n", prog, name);
            return -1;
        }
        f = fopen(name, "wb");
        if (!f) { fprintf(stderr, "%s: %s: %s\n", prog, name, strerror(errno)); return -1; }
    }
    int rc = fwrite(p, 1, n, f) == n ? 0 : -1;
    if (f != stdout && fclose(f)) rc = -1;
    if (rc) fprintf(stderr, "%s: write error\n", prog);
    return rc;
}

static int lz4_decompress_block(const byte *src, size_t sn, Buf *out) {
    size_t ip = 0;
    while (ip < sn) {
        byte token = src[ip++];
        size_t lit = token >> 4;
        if (lit == 15) {
            byte s;
            do { if (ip >= sn) return -1; s = src[ip++]; lit += s; } while (s == 255);
        }
        if (ip + lit > sn) return -1;
        if (append(out, src + ip, lit)) return -1;
        ip += lit;
        if (ip == sn) break;
        if (ip + 2 > sn) return -1;
        size_t off = (size_t)src[ip] | ((size_t)src[ip + 1] << 8);
        ip += 2;
        if (off == 0 || off > out->n) return -1;
        size_t ml = (token & 15) + 4;
        if ((token & 15) == 15) {
            byte s;
            do { if (ip >= sn) return -1; s = src[ip++]; ml += s; } while (s == 255);
        }
        if (grow(out, ml)) return -1;
        size_t ref = out->n - off;
        for (size_t i = 0; i < ml; i++) out->p[out->n++] = out->p[ref + i];
    }
    return 0;
}

static size_t max_block_size(byte bd) {
    switch ((bd >> 4) & 7) {
        case 4: return 64u * 1024u;
        case 5: return 256u * 1024u;
        case 6: return 1024u * 1024u;
        case 7: return 4u * 1024u * 1024u;
        default: return 4u * 1024u * 1024u;
    }
}

static int decompress_frame(const byte *src, size_t sn, size_t *pos, Buf *out) {
    if (*pos + 4 > sn) return -1;
    uint32_t magic = rd32(src + *pos); *pos += 4;
    if (magic >= SKIPPABLE_MIN && magic <= SKIPPABLE_MAX) {
        if (*pos + 4 > sn) return -1;
        uint32_t skip = rd32(src + *pos); *pos += 4;
        if (*pos + skip > sn) return -1;
        *pos += skip;
        return 0;
    }
    if (magic == LEGACY_MAGIC) {
        while (*pos + 4 <= sn) {
            uint32_t bs = rd32(src + *pos); *pos += 4;
            if (bs == 0) break;
            if (*pos + bs > sn) return -1;
            if (lz4_decompress_block(src + *pos, bs, out)) return -1;
            *pos += bs;
        }
        return 0;
    }
    if (magic != MAGIC || *pos + 3 > sn) return -1;
    size_t desc_start = *pos;
    byte flg = src[(*pos)++], bd = src[(*pos)++];
    if ((flg & 0xC0) != 0x40) return -1;
    int block_checksum = !!(flg & 0x10);
    int content_size = !!(flg & 0x08);
    int content_checksum = !!(flg & 0x04);
    int dictid = !!(flg & 0x01);
    uint64_t expected_size = 0;
    if (content_size) {
        if (*pos + 8 > sn) return -1;
        for (int i = 0; i < 8; i++) expected_size |= ((uint64_t)src[*pos + i]) << (8 * i);
        *pos += 8;
    }
    if (dictid) {
        if (*pos + 4 > sn) return -1;
        *pos += 4;
    }
    if (*pos >= sn) return -1;
    byte hc = (byte)((xxh32(src + desc_start, *pos - desc_start, 0) >> 8) & 0xff);
    (void)hc;
    (*pos)++;
    size_t before = out->n;
    size_t mb = max_block_size(bd);
    for (;;) {
        if (*pos + 4 > sn) return -1;
        uint32_t bs0 = rd32(src + *pos); *pos += 4;
        if (bs0 == 0) break;
        int raw = (bs0 & 0x80000000u) != 0;
        size_t bs = bs0 & 0x7fffffffu;
        if (bs > mb || *pos + bs > sn) return -1;
        if (raw) {
            if (append(out, src + *pos, bs)) return -1;
        } else {
            if (lz4_decompress_block(src + *pos, bs, out)) return -1;
        }
        *pos += bs;
        if (block_checksum) {
            if (*pos + 4 > sn) return -1;
            *pos += 4;
        }
    }
    if (content_checksum) {
        if (*pos + 4 > sn) return -1;
        uint32_t got = rd32(src + *pos), calc = xxh32(out->p + before, out->n - before, 0);
        *pos += 4;
        if (got != calc) return -2;
    }
    if (content_size && (uint64_t)(out->n - before) != expected_size) return -1;
    return 0;
}

static int lz4_decompress(const byte *src, size_t sn, Buf *out) {
    size_t pos = 0;
    while (pos < sn) {
        int rc = decompress_frame(src, sn, &pos, out);
        if (rc) return rc;
    }
    return 0;
}

static int lz4_compress_store(const byte *src, size_t sn, Buf *out, int block_code, int no_crc, int content_size) {
    size_t block = max_block_size((byte)(block_code << 4));
    byte hdr[15];
    size_t hn = 0, desc = 0;
    wr32(hdr + hn, MAGIC); hn += 4;
    desc = hn;
    byte flg = 0x60 | (no_crc ? 0 : 0x04) | (content_size ? 0x08 : 0);
    byte bd = (byte)(block_code << 4);
    hdr[hn++] = flg; hdr[hn++] = bd;
    if (content_size) {
        uint64_t s = (uint64_t)sn;
        for (int i = 0; i < 8; i++) hdr[hn++] = (byte)(s >> (8 * i));
    }
    byte hchk = (byte)((xxh32(hdr + desc, hn - desc, 0) >> 8) & 0xff);
    hdr[hn++] = hchk;
    if (append(out, hdr, hn)) return -1;
    for (size_t pos = 0; pos < sn;) {
        size_t n = sn - pos;
        if (n > block) n = block;
        if (append_le32(out, (uint32_t)n | 0x80000000u) || append(out, src + pos, n)) return -1;
        pos += n;
    }
    if (append_le32(out, 0)) return -1;
    if (!no_crc) {
        if (append_le32(out, xxh32(src, sn, 0))) return -1;
    }
    return 0;
}

static int ends_with(const char *s, const char *suf) {
    size_t n = strlen(s), m = strlen(suf);
    return n >= m && strcmp(s + n - m, suf) == 0;
}
static char *default_out(const char *in, int dec) {
    if (!in || strcmp(in, "-") == 0) {
        char *r = (char *)malloc(2);
        if (r) { r[0] = '-'; r[1] = 0; }
        return r;
    }
    size_t n = strlen(in);
    if (dec) {
        if (ends_with(in, ".lz4")) {
            char *r = (char *)malloc(n - 3);
            if (!r) return NULL;
            memcpy(r, in, n - 4); r[n - 4] = 0; return r;
        }
        char *r = (char *)malloc(n + 5);
        if (!r) return NULL;
        sprintf(r, "%s.out", in); return r;
    } else {
        char *r = (char *)malloc(n + 5);
        if (!r) return NULL;
        sprintf(r, "%s.lz4", in); return r;
    }
}

static void usage(int longhelp) {
    printf("*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***\n");
    printf("Usage : \n      %s [arg] [input] [output] \n\n", prog);
    printf("input   : a filename \n          with no FILE, or when FILE is - or stdin, read standard input\n");
    printf("Arguments : \n -1     : fast compression (default) \n -12    : slowest compression level \n");
    printf(" -T#    : use # threads for compression (default:0==auto) \n");
    printf(" -d     : decompression (default for .lz4 extension)\n -f     : overwrite output without prompting \n");
    printf(" -k     : preserve source files(s)  (default) \n--rm    : remove source file(s) after successful de/compression \n");
    printf(" -h/-H  : display help/long help and exit \n\n");
    printf("Advanced arguments :\n -V     : display Version number and exit \n -v     : verbose mode \n");
    printf(" -q     : suppress warnings; specify twice to suppress errors too\n -c     : force write to standard output, even if it is the console\n");
    printf(" -t     : test compressed file integrity\n -m     : multiple input files (implies automatic output filenames)\n");
    printf(" -r     : operate recursively on directories (sets also -m) \n -l     : compress using Legacy format (Linux kernel compression)\n");
    printf(" -z     : force compression \n -D FILE: use FILE as dictionary (compression & decompression)\n");
    printf(" -B#    : cut file into blocks of size # bytes [32+] \n                     or predefined block size [4-7] (default: 7) \n");
    printf(" -BI    : Block Independence (default) \n -BD    : Block dependency (improves compression ratio) \n -BX    : enable block checksum (default:disabled) \n");
    printf("--no-frame-crc : disable stream checksum (default:enabled) \n--content-size : compressed frame includes original size (default:not present)\n");
    printf("--list FILE : lists information about .lz4 files (useful for files compressed with --content-size flag)\n");
    printf("--[no-]sparse  : sparse mode (default:enabled on file, disabled on stdout)\n--favor-decSpeed: compressed files decompress faster, but are less compressed \n");
    printf("--fast[=#]: switch to ultra fast compression level (default: 1)\n--best  : same as -12\n");
    printf("Benchmark arguments : \n -b#    : benchmark file(s), using # compression level (default : 1) \n -e#    : test all compression levels from -bX to # (default : 1)\n -i#    : minimum evaluation time in seconds (default : 3s) \n");
    if (longhelp) printf("\nThis clean-room implementation supports standard LZ4 frame compression and decompression.\n");
}

typedef struct {
    int dec, comp, test, force, stdout_flag, quiet, rm, multiple;
    int no_crc, content_size, list;
    int block_code;
    const char *files[256];
    int nf;
} Opt;

static int parse(int argc, char **argv, Opt *o) {
    memset(o, 0, sizeof *o);
    o->block_code = 7;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (a[0] != '-' || strcmp(a, "-") == 0) {
            if (o->nf < 256) o->files[o->nf++] = a;
            continue;
        }
        if (strcmp(a, "--help") == 0) { usage(0); exit(0); }
        if (strcmp(a, "--best") == 0 || strncmp(a, "--fast", 6) == 0 || strcmp(a, "--compress") == 0) { o->comp = 1; continue; }
        if (strcmp(a, "--decompress") == 0 || strcmp(a, "--uncompress") == 0) { o->dec = 1; continue; }
        if (strcmp(a, "--rm") == 0) { o->rm = 1; continue; }
        if (strcmp(a, "--keep") == 0) { o->rm = 0; continue; }
        if (strcmp(a, "--no-frame-crc") == 0) { o->no_crc = 1; continue; }
        if (strcmp(a, "--content-size") == 0) { o->content_size = 1; continue; }
        if (strcmp(a, "--list") == 0) { o->list = 1; o->dec = 1; continue; }
        if (strcmp(a, "--sparse") == 0 || strcmp(a, "--no-sparse") == 0 || strcmp(a, "--favor-decSpeed") == 0) continue;
        if (a[1] == '-') return -1;
        for (size_t j = 1; a[j]; j++) {
            char c = a[j];
            if (c >= '0' && c <= '9') { o->comp = 1; while (a[j+1] >= '0' && a[j+1] <= '9') j++; continue; }
            if (c == 'd') o->dec = 1;
            else if (c == 'z') o->comp = 1;
            else if (c == 't') { o->test = 1; o->dec = 1; }
            else if (c == 'c') o->stdout_flag = 1;
            else if (c == 'f') o->force = 1;
            else if (c == 'k') o->rm = 0;
            else if (c == 'q') o->quiet++;
            else if (c == 'v') ;
            else if (c == 'm' || c == 'r') o->multiple = 1;
            else if (c == 'h') { usage(0); exit(0); }
            else if (c == 'H') { usage(1); exit(0); }
            else if (c == 'V') { printf("*** lz4 v1.10.0 64-bit multithread, by Yann Collet ***\n"); exit(0); }
            else if (c == 'B') {
                if (a[j+1] >= '4' && a[j+1] <= '7') { o->block_code = a[j+1] - '0'; while (a[j+1]) j++; }
                else while (a[j+1] && a[j+1] >= '0' && a[j+1] <= '9') j++;
            } else if (c == 'D' || c == 'T' || c == 'b' || c == 'e' || c == 'i') {
                if (!a[j+1] && i + 1 < argc && c == 'D') i++;
                while (a[j+1]) j++;
            } else if (c == 'l') {
                ;
            } else return -1;
        }
    }
    return 0;
}

static int list_file(const char *name) {
    Buf in = {0}, out = {0};
    if (read_file(name, &in)) return 1;
    int rc = lz4_decompress(in.p, in.n, &out);
    if (rc) { fprintf(stderr, "Error 44 : Unrecognized header : file cannot be decoded\n"); free(in.p); free(out.p); return 1; }
    printf("Frames  Type  Block  Compressed  Uncompressed  Ratio  Filename\n");
    printf("     1  LZ4   -      %10zu  %12zu  %.2f%%  %s\n", in.n, out.n, out.n ? (100.0 * in.n / out.n) : 0.0, name ? name : "-");
    free(in.p); free(out.p); return 0;
}

int main(int argc, char **argv) {
    prog = strrchr(argv[0], '/'); prog = prog ? prog + 1 : argv[0];
    Opt o;
    if (parse(argc, argv, &o)) {
        fprintf(stderr, "Incorrect parameters\n");
        usage(0);
        return 1;
    }
    if (o.list) {
        int rc = 0;
        for (int i = 0; i < o.nf; i++) rc |= list_file(o.files[i]);
        return rc;
    }
    if (o.nf == 0) { o.files[o.nf++] = "-"; o.stdout_flag = 1; }
    if (!o.dec && !o.comp && o.nf >= 1 && ends_with(o.files[0], ".lz4")) o.dec = 1;
    int status = 0;
    int inputs = (o.multiple || o.nf > 2 || o.stdout_flag || o.test) ? o.nf : (o.nf ? 1 : 0);
    for (int fi = 0; fi < inputs; fi++) {
        const char *inname = o.files[fi];
        int dec = o.dec && !o.comp;
        if (!o.dec && !o.comp && inname && ends_with(inname, ".lz4")) dec = 1;
        const char *outname = NULL;
        char *allocated = NULL;
        if (o.test) outname = "null";
        else if (o.stdout_flag) outname = "-";
        else if (!o.multiple && o.nf >= 2) outname = o.files[1];
        else { allocated = default_out(inname, dec); outname = allocated; }
        Buf in = {0}, out = {0};
        if (read_file(inname, &in)) { status = 1; free(allocated); continue; }
        int rc;
        if (dec) {
            rc = lz4_decompress(in.p, in.n, &out);
            if (rc) {
                if (o.quiet < 2) fprintf(stderr, "Error 44 : Unrecognized header : file cannot be decoded\n");
                status = 1;
            } else if (!o.test && write_file(outname, out.p, out.n, o.force)) status = 1;
            else if (!o.quiet && o.test) fprintf(stderr, "%s: decoded %zu bytes \n", inname, out.n);
        } else {
            rc = lz4_compress_store(in.p, in.n, &out, o.block_code, o.no_crc, o.content_size);
            if (rc || write_file(outname, out.p, out.n, o.force)) status = 1;
            else if (!o.quiet && !o.stdout_flag) fprintf(stderr, "Compressed %zu bytes into %zu bytes\n", in.n, out.n);
        }
        if (!status && o.rm && inname && strcmp(inname, "-") != 0) unlink(inname);
        free(in.p); free(out.p); free(allocated);
        if (!o.multiple && !o.stdout_flag && !o.test) break;
    }
    return status;
}
