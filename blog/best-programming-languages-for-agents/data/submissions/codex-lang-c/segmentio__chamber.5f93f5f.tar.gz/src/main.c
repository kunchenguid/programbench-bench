#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>
#include <errno.h>

extern char **environ;

static const char *backend = NULL;
static int verbose_flag = 0;

static void root_help(void);
static void global_flags(void) {
    printf("Global Flags:\n");
    printf("  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND\n");
    printf("                                   \tnull: no-op\n");
    printf("                                   \tssm: SSM Parameter Store\n");
    printf("                                   \tsecretsmanager: Secrets Manager\n");
    printf("                                   \ts3: S3; requires --backend-s3-bucket\n");
    printf("                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default \"ssm\")\n");
    printf("      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET\n");
    printf("      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default \"alias/parameter_store_key\")\n");
    printf("  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)\n");
    printf("      --retry-mode string          For SSM, the model used to retry requests\n");
    printf("                                    standard\n");
    printf("                                    adaptive (default \"standard\")\n");
    printf("      --verbose                    Print more information to STDERR\n");
}

static int is_global_with_value(const char *s) {
    return !strcmp(s,"--backend") || !strcmp(s,"-b") || !strcmp(s,"--backend-s3-bucket") ||
           !strcmp(s,"--kms-key-alias") || !strcmp(s,"--retries") || !strcmp(s,"-r") || !strcmp(s,"--retry-mode");
}
static char **filter_args(int argc, char **argv, int *outc) {
    char **v = calloc((size_t)argc + 1, sizeof(char*));
    int n = 0, after_dd = 0;
    v[n++] = argv[0];
    const char *envb = getenv("CHAMBER_SECRET_BACKEND");
    backend = envb && *envb ? envb : "ssm";
    for (int i=1;i<argc;i++) {
        char *a = argv[i];
        if (!after_dd && !strcmp(a,"--")) { after_dd=1; v[n++]=a; continue; }
        if (!after_dd) {
            if (!strcmp(a,"--backend") || !strcmp(a,"-b")) { if (i+1<argc) backend=argv[++i]; continue; }
            if (!strncmp(a,"--backend=",10)) { backend=a+10; continue; }
            if (!strcmp(a,"--verbose")) { verbose_flag=1; continue; }
            if (is_global_with_value(a)) { if (i+1<argc) i++; continue; }
            if (!strncmp(a,"--backend-s3-bucket=",20) || !strncmp(a,"--kms-key-alias=",16) || !strncmp(a,"--retries=",10) || !strncmp(a,"--retry-mode=",13)) continue;
        }
        v[n++] = a;
    }
    v[n] = NULL; *outc = n; return v;
}

static int has_help(int argc, char **argv) { for(int i=1;i<argc;i++) if(!strcmp(argv[i],"--help")||!strcmp(argv[i],"-h")) return 1; return 0; }
static int count_nonflags(int argc, char **argv, int start) {
    int c=0; for(int i=start;i<argc;i++) { if(!strcmp(argv[i],"--")) continue; if(argv[i][0]=='-') { if(i+1<argc && (is_global_with_value(argv[i]) || !strcmp(argv[i],"--format")||!strcmp(argv[i],"-f")||!strcmp(argv[i],"--output-file")||!strcmp(argv[i],"-o")||!strcmp(argv[i],"--version")||!strcmp(argv[i],"-v")||!strcmp(argv[i],"--tags")||!strcmp(argv[i],"-t")||!strcmp(argv[i],"--strict-value"))) i++; continue; } c++; } return c;
}
static int find_dd(int argc, char **argv) { for(int i=1;i<argc;i++) if(!strcmp(argv[i],"--")) return i; return -1; }

static void err_accepts(const char *usage_help, int accepts, int got) { fprintf(stderr,"Error: accepts %d arg(s), received %d\n", accepts, got); printf("%s", usage_help); }
static void err_min(const char *usage_help, int min, int got) { fprintf(stderr,"Error: requires at least %d arg(s), only received %d\n", min, got); printf("%s", usage_help); }

static const char *H_READ = "Usage:\n  chamber read <service> <key> [flags]\n\nFlags:\n  -h, --help          help for read\n  -q, --quiet         Only print the secret\n  -v, --version int   The version number of the secret. Defaults to latest. (default -1)\n\n";
static const char *H_WRITE = "Usage:\n  chamber write <service> <key> [--] <value|-> [flags]\n\nFlags:\n  -h, --help                  help for write\n  -s, --singleline            Insert single line parameter (end with \\n)\n      --skip-unchanged        Skip writing secret if value is unchanged\n  -t, --tags stringToString   Add tags to the secret; new secrets only (default [])\n\n";
static const char *H_LIST = "Usage:\n  chamber list <service> [flags]\n\nFlags:\n  -e, --expand    Expand parameter list with values\n  -h, --help      help for list\n  -t, --time      Sort by modified time\n  -u, --user      Sort by user\n  -v, --version   Sort by version\n\n";
static const char *H_LSVC = "Usage:\n  chamber list-services <service> [flags]\n\nFlags:\n  -h, --help      help for list-services\n  -s, --secrets   Include secret names in the list\n\n";
static const char *H_ENV = "Usage:\n  chamber env <service> [flags]\n\nFlags:\n  -p, --preserve-case    preserve variable name case\n  -e, --escape-strings   escape special characters in values\n  -h, --help             help for env\n\n";
static const char *H_EXPORT = "Usage:\n  chamber export <service...> [flags]\n\nFlags:\n  -f, --format string        Output format (json, yaml, java-properties, csv, tsv, dotenv, tfvars) (default \"json\")\n  -o, --output-file string   Output file (default is standard output)\n  -h, --help                 help for export\n\n";
static const char *H_DELETE = "Usage:\n  chamber delete <service> <key> [flags]\n\nFlags:\n      --exact-key   Prevent normalization of the provided key in order to delete any keys that match the exact provided casing.\n  -h, --help        help for delete\n\n";
static const char *H_FIND = "Usage:\n  chamber find <secret name> [flags]\n\nFlags:\n  -v, --by-value   Find parameters by value\n  -h, --help       help for find\n\n";
static const char *H_HISTORY = "Usage:\n  chamber history <service> <key> [flags]\n\nFlags:\n  -h, --help   help for history\n\n";
static const char *H_IMPORT = "Usage:\n  chamber import <service> <file|-> [flags]\n\nFlags:\n  -h, --help                           help for import\n      --normalize-keys chamber write   Normalize keys to match how chamber write would handle them. If not specified, keys will be written exactly how they are defined in the import source.\n\n";

static void print_cmd_help(const char *desc, const char *h) { printf("%s\n\n%s", desc, h); global_flags(); }

static int cmd_read(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("Read a specific secret from the parameter store",H_READ);return 0;} int n=count_nonflags(argc,argv,2); if(n!=2){err_accepts(H_READ,2,n);global_flags();return 1;} fprintf(stderr,"Error: Failed to read: Not implemented for Null Store\n"); return 1; }
static int cmd_write(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("write a secret",H_WRITE);return 0;} int n=count_nonflags(argc,argv,2); if(n!=3){err_accepts(H_WRITE,3,n);global_flags();return 1;} fprintf(stderr,"Error: Write is not implemented for Null Store\n"); return 1; }
static int cmd_list(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("List the secrets set for a service",H_LIST);return 0;} int n=count_nonflags(argc,argv,2); if(n!=1){err_accepts(H_LIST,1,n);global_flags();return 1;} printf("Key\tVersion\t\tLastModified\tUser\n"); return 0; }
static int cmd_lsvc(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("List services",H_LSVC);return 0;} printf("Service\n"); return 0; }
static int cmd_env(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("Print the secrets from the parameter store in a format to export as environment variables",H_ENV);return 0;} int n=count_nonflags(argc,argv,2); if(n!=1){err_accepts(H_ENV,1,n);global_flags();return 1;} return 0; }
static int cmd_export(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("Exports parameters in the specified format",H_EXPORT);return 0;} int n=count_nonflags(argc,argv,2); if(n<1){err_min(H_EXPORT,1,n);global_flags();return 1;} const char *fmt="json", *out=NULL; for(int i=2;i<argc;i++){ if((!strcmp(argv[i],"--format")||!strcmp(argv[i],"-f"))&&i+1<argc)fmt=argv[++i]; else if(!strncmp(argv[i],"--format=",9))fmt=argv[i]+9; else if((!strcmp(argv[i],"--output-file")||!strcmp(argv[i],"-o"))&&i+1<argc)out=argv[++i]; else if(!strncmp(argv[i],"--output-file=",14))out=argv[i]+14; } FILE *f=stdout; if(out){f=fopen(out,"w"); if(!f){perror(out); return 1;}} if(!strcmp(fmt,"json")) fprintf(f,"{}\n"); else if(!strcmp(fmt,"yaml")) fprintf(f,"{}\n"); else fprintf(f,"\n"); if(out) fclose(f); return 0; }
static int cmd_delete(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("Delete a secret, including all versions",H_DELETE);return 0;} int n=count_nonflags(argc,argv,2); if(n!=2){err_accepts(H_DELETE,2,n);global_flags();return 1;} fprintf(stderr,"Error: Not implemented for Null Store\n"); return 1; }
static int cmd_find(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("Find the given secret across all services",H_FIND);return 0;} int n=count_nonflags(argc,argv,2); if(n!=1){err_accepts(H_FIND,1,n);global_flags();return 1;} printf("Service\n"); return 0; }
static int cmd_history(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("View the history of a secret",H_HISTORY);return 0;} int n=count_nonflags(argc,argv,2); if(n!=2){err_accepts(H_HISTORY,2,n);global_flags();return 1;} printf("Event\tVersion\t\tDate\tUser\n"); return 0; }
static int cmd_import(int argc, char **argv) { if(has_help(argc,argv)){print_cmd_help("import secrets from json or yaml",H_IMPORT);return 0;} int n=count_nonflags(argc,argv,2); if(n!=2){err_accepts(H_IMPORT,2,n);global_flags();return 1;} fprintf(stderr,"Error: Failed to write secret: Write is not implemented for Null Store\n"); return 1; }

static int cmd_exec(int argc, char **argv) {
    if(has_help(argc,argv)){
        printf("Executes a command with secrets loaded into the environment\n\nUsage:\n  chamber exec <service...> -- <command> [<arg...>] [flags]\n\nFlags:\n  -h, --help                  help for exec\n      --pristine              only use variables retrieved from the backend; do not inherit existing environment variables\n      --strict                enable strict mode:\n                              only inject secrets for which there is a corresponding env var with value\n                              <strict-value>, and fail if there are any env vars with that value missing\n                              from secrets\n      --strict-value string   value to expect in --strict mode (default \"chamberme\")\n\n"); global_flags(); return 0; }
    int dd=find_dd(argc,argv); if(dd<0 || dd==argc-1){ fprintf(stderr,"Error: accepts at least 2 arg(s), received %d\n", count_nonflags(argc,argv,2)); return 1; }
    int pristine=0; for(int i=2;i<dd;i++) if(!strcmp(argv[i],"--pristine")) pristine=1;
    char **cmd=&argv[dd+1];
    if(pristine){ char *empty[] = { NULL }; environ = empty; }
    execvp(cmd[0], cmd); fprintf(stderr,"Error: exec: %s\n", strerror(errno)); return 1;
}

static int cmd_tag(int argc, char **argv) {
    if(argc<3 || has_help(argc,argv)) { printf("work with tags on secrets\n\nUsage:\n  chamber tag [command]\n\nAvailable Commands:\n  delete      Delete tags for a specific secret\n  read        Read tags for a specific secret\n  write       Write tags for a specific secret\n\nFlags:\n  -h, --help   help for tag\n\n"); global_flags(); printf("\nUse \"chamber tag [command] --help\" for more information about a command.\n"); return 0; }
    const char *sub=argv[2];
    if(!strcmp(sub,"read")) { if(has_help(argc,argv)){printf("Read tags for a specific secret\n\nUsage:\n  chamber tag read <service> <key> [flags]\n\nFlags:\n  -h, --help   help for read\n\n");global_flags();return 0;} fprintf(stderr,"Error: Failed to read tags: Not implemented for Null Store\n"); return 1; }
    if(!strcmp(sub,"write")) { if(has_help(argc,argv)){printf("Write tags for a specific secret\n\nUsage:\n  chamber tag write <service> <key> <tag>... [flags]\n\nFlags:\n      --delete-other-tags   Delete tags not specified in the command\n  -h, --help                help for write\n\n");global_flags();return 0;} fprintf(stderr,"Error: Failed to write tags: Not implemented for Null Store\n"); return 1; }
    if(!strcmp(sub,"delete")) { if(has_help(argc,argv)){printf("Delete tags for a specific secret\n\nUsage:\n  chamber tag delete <service> <key> <tag key>... [flags]\n\nFlags:\n  -h, --help   help for delete\n\n");global_flags();return 0;} fprintf(stderr,"Error: Failed to delete tags: Not implemented for Null Store\n"); return 1; }
    fprintf(stderr,"Error: unknown command \"%s\" for \"chamber tag\"\n", sub); return 1;
}

static int cmd_completion(int argc, char **argv) {
    if(argc<3 || has_help(argc,argv)) { printf("Generate the autocompletion script for chamber for the specified shell.\nSee each sub-command's help for details on how to use the generated script.\n\nUsage:\n  chamber completion [command]\n\nAvailable Commands:\n  bash        Generate the autocompletion script for bash\n  fish        Generate the autocompletion script for fish\n  powershell  Generate the autocompletion script for powershell\n  zsh         Generate the autocompletion script for zsh\n\nFlags:\n  -h, --help   help for completion\n\n"); global_flags(); printf("\nUse \"chamber completion [command] --help\" for more information about a command.\n"); return 0; }
    printf("# completion script for chamber %s\n", argv[2]); return 0;
}

static void root_help(void) {
    printf("CLI for storing secrets\n\nUsage:\n  chamber [command]\n\nAvailable Commands:\n  completion    Generate the autocompletion script for the specified shell\n  delete        Delete a secret, including all versions\n  env           Print the secrets from the parameter store in a format to export as environment variables\n  exec          Executes a command with secrets loaded into the environment\n  export        Exports parameters in the specified format\n  find          Find the given secret across all services\n  help          Help about any command\n  history       View the history of a secret\n  import        import secrets from json or yaml\n  list          List the secrets set for a service\n  list-services List services\n  read          Read a specific secret from the parameter store\n  tag           work with tags on secrets\n  version       print version\n  write         write a secret\n\nFlags:\n");
    printf("  -b, --backend string             Backend to use; AKA $CHAMBER_SECRET_BACKEND\n                                   \tnull: no-op\n                                   \tssm: SSM Parameter Store\n                                   \tsecretsmanager: Secrets Manager\n                                   \ts3: S3; requires --backend-s3-bucket\n                                   \ts3-kms: S3 using AWS-KMS encryption; requires --backend-s3-bucket and --kms-key-alias set (if you want to write or delete keys). (default \"ssm\")\n      --backend-s3-bucket string   bucket for S3 backend; AKA $CHAMBER_S3_BUCKET\n  -h, --help                       help for chamber\n      --kms-key-alias string       KMS Key Alias for writing and deleting secrets; AKA $CHAMBER_KMS_KEY_ALIAS. This option is currently only supported for the S3-KMS backend. (default \"alias/parameter_store_key\")\n  -r, --retries int                For SSM or Secrets Manager, the number of retries we'll make before giving up; AKA $CHAMBER_RETRIES (default 10)\n      --retry-mode string          For SSM, the model used to retry requests\n                                     standard\n                                     adaptive (default \"standard\")\n      --verbose                    Print more information to STDERR\n\nUse \"chamber [command] --help\" for more information about a command.\n");
}

int main(int argc, char **argv) {
    int ac; char **av=filter_args(argc,argv,&ac);
    if(ac==1 || (ac>1 && (!strcmp(av[1],"--help")||!strcmp(av[1],"-h")))) { root_help(); return 0; }
    if(!strcmp(av[1],"version")) { printf("chamber dev\n"); return 0; }
    if(!strcmp(av[1],"--version")) { fprintf(stderr,"Error: unknown flag: --version\n"); return 1; }
    if(!strcmp(av[1],"help")) { if(ac>2){ char *nv[4]={av[0],av[2],"--help",NULL}; return main(3,nv);} root_help(); return 0; }
    const char *c=av[1];
    if(!strcmp(c,"read")) return cmd_read(ac,av);
    if(!strcmp(c,"write")) return cmd_write(ac,av);
    if(!strcmp(c,"list")) return cmd_list(ac,av);
    if(!strcmp(c,"list-services")) return cmd_lsvc(ac,av);
    if(!strcmp(c,"env")) return cmd_env(ac,av);
    if(!strcmp(c,"export")) return cmd_export(ac,av);
    if(!strcmp(c,"exec")) return cmd_exec(ac,av);
    if(!strcmp(c,"delete")) return cmd_delete(ac,av);
    if(!strcmp(c,"find")) return cmd_find(ac,av);
    if(!strcmp(c,"history")) return cmd_history(ac,av);
    if(!strcmp(c,"import")) return cmd_import(ac,av);
    if(!strcmp(c,"tag")) return cmd_tag(ac,av);
    if(!strcmp(c,"completion")) return cmd_completion(ac,av);
    fprintf(stderr,"Error: unknown command \"%s\" for \"chamber\"\nRun 'chamber --help' for usage.\n", c); return 1;
}
