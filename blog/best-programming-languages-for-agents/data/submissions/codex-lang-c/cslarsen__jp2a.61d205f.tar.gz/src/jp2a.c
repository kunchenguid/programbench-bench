#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <math.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <jpeglib.h>
#include <setjmp.h>

#define VERSION "1.0.8"
#define DEFAULT_CHARS "   ...',;:clodxkO0KXNWM"

typedef struct {
    unsigned char r,g,b;
} Pixel;

typedef struct {
    int width, height, comps;
    Pixel *px;
} Image;

typedef struct {
    const char *chars;
    int width, height;
    bool have_width, have_height, have_size;
    bool invert, border, colors, html, raw_html, fill, grayscale;
    bool flipx, flipy, clear, verbose, debug, html_bold;
    int html_fontsize;
    const char *html_title;
    const char *output;
    double rw, gw, bw;
    enum {MODE_NONE, MODE_FIT, MODE_TERM_WIDTH, MODE_TERM_HEIGHT, MODE_ZOOM} term_mode;
} Options;

struct my_error_mgr { struct jpeg_error_mgr pub; jmp_buf setjmp_buffer; char msg[JMSG_LENGTH_MAX]; };
static void my_error_exit(j_common_ptr cinfo) {
    struct my_error_mgr *e = (struct my_error_mgr*) cinfo->err;
    (*cinfo->err->format_message)(cinfo, e->msg);
    longjmp(e->setjmp_buffer, 1);
}

static const char *help_text =
"jp2a 1.0.8\n"
"Copyright 2006-2016 Christian Stigen Larsen\n"
"Distributed under the GNU General Public License (GPL) v2.\n"
"\n"
"Usage: jp2a [ options ] [ file(s) | URL(s) ]\n"
"\n"
"Convert files or URLs from JPEG format to ASCII.\n"
"\n"
"OPTIONS\n"
"  -                 Read images from standard input.\n"
"      --blue=N.N    Set RGB to grayscale conversion weight, default is 0.1145\n"
"  -b, --border      Print a border around the output image.\n"
"      --chars=...   Select character palette used to paint the image.\n"
"                    Leftmost character corresponds to black pixel, right-\n"
"                    most to white.  Minimum two characters must be specified.\n"
"      --clear       Clears screen before drawing each output image.\n"
"      --colors      Use ANSI colors in output.\n"
"  -d, --debug       Print additional debug information.\n"
"      --fill        When used with --color and/or --html, color each character's\n"
"                    background color.\n"
"  -x, --flipx       Flip image in X direction.\n"
"  -y, --flipy       Flip image in Y direction.\n"
"  -f, --term-fit    Use the largest image dimension that fits in your terminal\n"
"                    display with correct aspect ratio.\n"
"      --term-height Use terminal display height.\n"
"      --term-width  Use terminal display width.\n"
"  -z, --term-zoom   Use terminal display dimension for output.\n"
"      --grayscale   Convert image to grayscale when using --html or --colors\n"
"      --green=N.N   Set RGB to grayscale conversion weight, default is 0.5866\n"
"      --height=N    Set output height, calculate width from aspect ratio.\n"
"  -h, --help        Print program help.\n"
"      --html        Produce strict XHTML 1.0 output.\n"
"      --html-fill   Same as --fill (will be phased out)\n"
"      --html-fontsize=N   Set fontsize to N pt, default is 4.\n"
"      --html-no-bold      Do not use bold characters with HTML output\n"
"      --html-raw    Output raw HTML codes, i.e. without the <head> section etc.\n"
"      --html-title=...  Set HTML output title\n"
"  -i, --invert      Invert output image.  Use if your display has a dark\n"
"                    background.\n"
"      --background=dark   These are just mnemonics whether to use --invert\n"
"      --background=light  or not.  If your console has light characters on\n"
"                    a dark background, use --background=dark.\n"
"      --output=...  Write output to file.\n"
"      --red=N.N     Set RGB to grayscale conversion weight, default 0.2989f.\n"
"      --size=WxH    Set output width and height.\n"
"  -v, --verbose     Verbose output.\n"
"  -V, --version     Print program version.\n"
"      --width=N     Set output width, calculate height from ratio.\n"
"\n"
"  The default mode is `jp2a --term-fit --background=dark'.\n"
"  See the man-page for jp2a for more detailed help text.\n"
"\n"
"Project homepage on https://github.com/cslarsen/jp2a\n"
"Report bugs to <csl@csl.name>\n";

static void version(void) { printf("jp2a %s\nCopyright 2006-2016 Christian Stigen Larsen\nDistributed under the GNU General Public License (GPL) v2.\n", VERSION); }
static bool starts(const char *s,const char*p){return strncmp(s,p,strlen(p))==0;}
static int parse_int(const char *s){ char *e; long v=strtol(s,&e,10); if(!*s||*e||v<0||v>1000000) return -1; return (int)v; }
static double parse_double(const char*s){ char *e; double v=strtod(s,&e); if(!*s||*e) return NAN; return v; }

static void html_esc(FILE *out, const char *s) {
    for (; *s; s++) {
        if (*s=='&') fputs("&amp;", out); else if (*s=='<') fputs("&lt;", out);
        else if (*s=='>') fputs("&gt;", out); else if (*s=='\"') fputs("&quot;", out);
        else fputc(*s,out);
    }
}
static void html_char(FILE*out, char c){ if(c=='&')fputs("&amp;",out); else if(c=='<')fputs("&lt;",out); else if(c=='>')fputs("&gt;",out); else fputc(c,out); }

static int terminal_size(int *w,int*h) {
    struct winsize ws;
    if (ioctl(STDOUT_FILENO, TIOCGWINSZ, &ws)==0 && ws.ws_col && ws.ws_row) { *w=ws.ws_col; *h=ws.ws_row; return 0; }
    const char *cw=getenv("COLUMNS"), *lh=getenv("LINES");
    if (cw && lh) { int a=parse_int(cw), b=parse_int(lh); if(a>0&&b>0){*w=a;*h=b;return 0;} }
    if (!getenv("TERM")) { fprintf(stderr,"Environment variable TERM not set.\n"); return 1; }
    *w=80; *h=24; return 0;
}

static int read_jpeg(FILE *fp, Image *img, char *err, size_t errsz) {
    struct jpeg_decompress_struct cinfo; struct my_error_mgr jerr;
    memset(&cinfo,0,sizeof(cinfo));
    cinfo.err = jpeg_std_error(&jerr.pub); jerr.pub.error_exit = my_error_exit;
    if (setjmp(jerr.setjmp_buffer)) { snprintf(err,errsz,"%s",jerr.msg); jpeg_destroy_decompress(&cinfo); return 1; }
    jpeg_create_decompress(&cinfo); jpeg_stdio_src(&cinfo, fp); jpeg_read_header(&cinfo, TRUE);
    jpeg_start_decompress(&cinfo);
    img->width = (int)cinfo.output_width; img->height = (int)cinfo.output_height; img->comps = (int)cinfo.output_components;
    img->px = calloc((size_t)img->width * img->height, sizeof(Pixel));
    if (!img->px) { snprintf(err,errsz,"Out of memory"); jpeg_destroy_decompress(&cinfo); return 1; }
    int stride = img->width * cinfo.output_components;
    JSAMPARRAY row = (*cinfo.mem->alloc_sarray)((j_common_ptr)&cinfo, JPOOL_IMAGE, stride, 1);
    while (cinfo.output_scanline < cinfo.output_height) {
        JDIMENSION y = cinfo.output_scanline;
        jpeg_read_scanlines(&cinfo, row, 1);
        for (int x=0;x<img->width;x++) {
            Pixel *p=&img->px[(size_t)y*img->width+x];
            if (cinfo.output_components==1) p->r=p->g=p->b=row[0][x];
            else { p->r=row[0][x*cinfo.output_components+0]; p->g=row[0][x*cinfo.output_components+1]; p->b=row[0][x*cinfo.output_components+2]; }
        }
    }
    jpeg_finish_decompress(&cinfo); jpeg_destroy_decompress(&cinfo); return 0;
}

static void free_image(Image*i){ free(i->px); i->px=NULL; }
static double lum_pixel(Pixel p, const Options *o){ double y=o->rw*p.r + o->gw*p.g + o->bw*p.b; if(y<0)y=0; if(y>255)y=255; return y; }
static char map_char(double y,const Options*o){ size_t n=strlen(o->chars); if(o->invert) y=255-y; int idx=(int)floor((y/256.0)*n); if(idx<0)idx=0; if(idx>=(int)n)idx=(int)n-1; return o->chars[idx]; }

static Pixel sample_pixel(const Image *img, int ox, int oy, int ow, int oh, const Options *o) {
    if (o->flipx) ox = ow - 1 - ox;
    if (o->flipy) oy = oh - 1 - oy;

    int x0 = (int)((long long)ox * img->width / (ow > 0 ? ow : 1));
    int x1 = (int)((long long)(ox + 1) * img->width / (ow > 0 ? ow : 1));
    int y0 = (int)((long long)oy * img->height / (oh > 0 ? oh : 1));
    int y1 = (int)((long long)(oy + 1) * img->height / (oh > 0 ? oh : 1));
    if (x1 <= x0) x1 = x0 + 1;
    if (y1 <= y0) y1 = y0 + 1;
    if (x0 < 0) x0 = 0;
    if (y0 < 0) y0 = 0;
    if (x1 > img->width) x1 = img->width;
    if (y1 > img->height) y1 = img->height;

    unsigned long long sr = 0, sg = 0, sb = 0, n = 0;
    for (int y = y0; y < y1; y++) {
        for (int x = x0; x < x1; x++) {
            Pixel p = img->px[(size_t)y * img->width + x];
            sr += p.r; sg += p.g; sb += p.b; n++;
        }
    }
    if (!n) n = 1;
    Pixel out;
    out.r = (unsigned char)(sr / n);
    out.g = (unsigned char)(sg / n);
    out.b = (unsigned char)(sb / n);
    return out;
}

static void calc_dims(const Image *img, Options *o) {
    if (o->term_mode != MODE_NONE) {
        int tw=80, th=24; if (terminal_size(&tw,&th)!=0) { o->width=0; o->height=0; return; }
        if (o->term_mode==MODE_ZOOM) { o->width=tw; o->height=th; return; }
        if (o->term_mode==MODE_TERM_WIDTH) { o->width=tw; o->height=(int)(0.5 + (double)o->width*img->height/img->width/2.0); if(o->height<1)o->height=1; return; }
        if (o->term_mode==MODE_TERM_HEIGHT) { o->height=th; o->width=(int)(0.5 + (double)o->height*img->width/img->height*2.0); if(o->width<1)o->width=1; return; }
        int h_for_w=(int)((double)tw*img->height/img->width/2.0);
        int w_for_h=(int)((double)th*img->width/img->height*2.0);
        if (h_for_w <= th) { o->width=tw; o->height=h_for_w; } else { o->height=th; o->width=w_for_h; }
        if (o->width < 1) o->width = 1;
        if (o->height < 1) o->height = 1;
        return;
    }
    if (o->have_width && !o->have_height) { o->height=(int)(0.5 + (double)o->width*img->height/img->width/2.0); if(o->height<1)o->height=1; }
    else if (!o->have_width && o->have_height) { o->width=(int)(0.5 + (double)o->height*img->width/img->height*2.0); if(o->width<1)o->width=1; }
    else if (!o->have_width && !o->have_height) { o->term_mode=MODE_FIT; calc_dims(img,o); }
}

static void emit_html_header(FILE*out,const Options*o){
    if(o->raw_html) return;
    fputs("<?xml version='1.0' encoding='ISO-8859-1'?>\n",out);
    fputs("<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n",out);
    fputs("<html xmlns='http://www.w3.org/1999/xhtml' lang='en' xml:lang='en'>\n<head>\n<title>",out); html_esc(out,o->html_title); fputs("</title>\n",out);
    fputs("<style type='text/css'>\nbody {\n",out);
    fprintf(out,"background-color: %s;\n}\n.ascii {\n   font-family: Courier;\n", o->invert?"white":"black");
    if (!o->colors) fprintf(out, "   color: %s;\n", o->invert?"black":"white");
    fprintf(out, "   font-size:%dpt;\n", o->html_fontsize*2);
    if(o->html_bold) fputs("   font-weight: bold;\n",out);
    fputs("}\n</style>\n</head>\n<body>\n<div class='ascii'><pre>\n",out);
}
static void emit_html_footer(FILE*out,const Options*o){ if(!o->raw_html) fputs("</pre>\n</div>\n</body>\n</html>\n",out); }

static int render_one(const char *name, const Options *base, FILE *out) {
    FILE *fp = NULL; bool closefp=false;
    if (strcmp(name,"-")==0) fp=stdin; else { fp=fopen(name,"rb"); closefp=true; }
    if(!fp) { fprintf(stderr,"Can't open %s\n", name); return 1; }
    Image img={0}; char err[256]; int rc=read_jpeg(fp,&img,err,sizeof(err)); if(closefp) fclose(fp);
    if(rc){ fprintf(stderr,"%s\n",err); return 1; }
    Options o=*base; calc_dims(&img,&o); if(o.width<=0||o.height<=0){ free_image(&img); return 1; }
    if(o.verbose){
        fprintf(stderr,"File: %s\nSource width: %d\nSource height: %d\nSource color components: %d\nOutput width: %d\nOutput height: %d\nOutput palette (%zu chars): '%s'\n", name, img.width,img.height,img.comps,o.width,o.height,strlen(o.chars),o.chars);
    }
    if(o.clear) fputs("\033[H\033[J", out);
    if(o.html) emit_html_header(out,&o);
    if(o.border && !o.html){ fputc('+',out); for(int x=0;x<o.width;x++) fputc('-',out); fputs("+\n",out); }
    for(int y=0;y<o.height;y++){
        if(o.border && !o.html) fputc('|',out);
        for(int x=0;x<o.width;x++){
            Pixel p=sample_pixel(&img,x,y,o.width,o.height,&o); double yy=lum_pixel(p,&o); char ch=map_char(yy,&o);
            if(o.html && o.colors){
                Pixel cp=p; if(o.grayscale){ unsigned char g=(unsigned char)(yy+0.5); cp.r=cp.g=cp.b=g; }
                fprintf(out,"<span style='color:#%02x%02x%02x;",cp.r,cp.g,cp.b);
                if(o.fill) fprintf(out,"background-color:#%02x%02x%02x;",cp.r,cp.g,cp.b);
                fputs("'>",out); html_char(out,ch); fputs("</span>",out);
            } else if(o.colors && !o.html) {
                Pixel cp=p; if(o.grayscale){ unsigned char g=(unsigned char)(yy+0.5); cp.r=cp.g=cp.b=g; }
                if(o.fill) fprintf(out,"\033[48;2;%d;%d;%dm",cp.r,cp.g,cp.b);
                fprintf(out,"\033[38;2;%d;%d;%dm%c\033[0m",cp.r,cp.g,cp.b,ch);
            } else if(o.html) html_char(out,ch); else fputc(ch,out);
        }
        if(o.border && !o.html) fputc('|',out);
        if(o.html && o.colors) fputs("<br/>",out); else fputc('\n',out);
    }
    if(o.border && !o.html){ fputc('+',out); for(int x=0;x<o.width;x++) fputc('-',out); fputs("+\n",out); }
    if(o.html) emit_html_footer(out,&o);
    free_image(&img); return 0;
}

static int parse_args(int argc,char**argv,Options*o,char***files,int*nf){
    *nf=0; *files=calloc(argc?argc:1,sizeof(char*)); if(!*files) return 1;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(strcmp(a,"--help")==0||strcmp(a,"-h")==0){ fputs(help_text,stdout); exit(0); }
        else if(strcmp(a,"--version")==0||strcmp(a,"-V")==0){ version(); exit(0); }
        else if(strcmp(a,"-")==0){ (*files)[(*nf)++]=a; }
        else if(strcmp(a,"-b")==0||strcmp(a,"--border")==0) o->border=true;
        else if(strcmp(a,"-i")==0||strcmp(a,"--invert")==0) o->invert=true;
        else if(strcmp(a,"-x")==0||strcmp(a,"--flipx")==0) o->flipx=true;
        else if(strcmp(a,"-y")==0||strcmp(a,"--flipy")==0) o->flipy=true;
        else if(strcmp(a,"-v")==0||strcmp(a,"--verbose")==0) o->verbose=true;
        else if(strcmp(a,"-d")==0||strcmp(a,"--debug")==0) o->debug=true;
        else if(strcmp(a,"-f")==0||strcmp(a,"--term-fit")==0) o->term_mode=MODE_FIT;
        else if(strcmp(a,"-z")==0||strcmp(a,"--term-zoom")==0||strcmp(a,"--zoom")==0) o->term_mode=MODE_ZOOM;
        else if(strcmp(a,"--term-width")==0) o->term_mode=MODE_TERM_WIDTH;
        else if(strcmp(a,"--term-height")==0) o->term_mode=MODE_TERM_HEIGHT;
        else if(strcmp(a,"--colors")==0||strcmp(a,"--color")==0) o->colors=true;
        else if(strcmp(a,"--html")==0) o->html=true;
        else if(strcmp(a,"--html-raw")==0) o->raw_html=true;
        else if(strcmp(a,"--fill")==0||strcmp(a,"--html-fill")==0) o->fill=true;
        else if(strcmp(a,"--grayscale")==0) o->grayscale=true;
        else if(strcmp(a,"--html-no-bold")==0) o->html_bold=false;
        else if(strcmp(a,"--clear")==0) o->clear=true;
        else if(starts(a,"--chars=")){ o->chars=a+8; if(strlen(o->chars)<2){ fprintf(stderr,"Minimum two characters must be specified.\n"); return 1; } }
        else if(starts(a,"--width=")){ int v=parse_int(a+8); if(v<0){fprintf(stderr,"Invalid width specified\n\n");return 1;} o->width=v; o->have_width=true; o->term_mode=MODE_NONE; }
        else if(starts(a,"--height=")){ int v=parse_int(a+9); if(v<0){fprintf(stderr,"Invalid height specified\n\n");return 1;} o->height=v; o->have_height=true; o->term_mode=MODE_NONE; }
        else if(starts(a,"--size=")){ int w=-1,h=-1; if(sscanf(a+7,"%dx%d",&w,&h)!=2 || w<0 || h<0){ fprintf(stderr,"Invalid width or height specified\n\n"); return 1; } o->width=w; o->height=h; o->have_width=o->have_height=true; o->term_mode=MODE_NONE; }
        else if(starts(a,"--output=")) o->output=a+9;
        else if(starts(a,"--html-fontsize=")){ int v=parse_int(a+16); if(v>=0)o->html_fontsize=v; }
        else if(starts(a,"--html-title=")) o->html_title=a+13;
        else if(starts(a,"--red=")){ double v=parse_double(a+6); if(!isnan(v))o->rw=v; }
        else if(starts(a,"--green=")){ double v=parse_double(a+8); if(!isnan(v))o->gw=v; }
        else if(starts(a,"--blue=")){ double v=parse_double(a+7); if(!isnan(v))o->bw=v; }
        else if(strcmp(a,"--background=dark")==0) o->invert=false;
        else if(strcmp(a,"--background=light")==0) o->invert=true;
        else if(a[0]=='-'){ fprintf(stderr,"Unknown option %s\n\n",a); fputs(help_text,stderr); return 1; }
        else (*files)[(*nf)++]=a;
    }
    if(fabs((o->rw+o->gw+o->bw)-1.0)>0.001){ fprintf(stderr,"Weights RED + GREEN + BLUE must equal 1.0\n"); return 1; }
    return 0;
}

int main(int argc,char**argv){
    Options o; memset(&o,0,sizeof(o)); o.chars=DEFAULT_CHARS; o.rw=0.2989; o.gw=0.5866; o.bw=0.1145; o.term_mode=MODE_FIT; o.invert=false; o.html_fontsize=4; o.html_title="jp2a converted image"; o.html_bold=true;
    char **files=NULL; int nf=0; if(parse_args(argc,argv,&o,&files,&nf)) return 1;
    if(nf==0){ files=calloc(1,sizeof(char*)); files[0]="-"; nf=1; }
    FILE *out=stdout; if(o.output && strcmp(o.output,"-")!=0){ out=fopen(o.output,"wb"); if(!out){ fprintf(stderr,"Could not open output file %s: %s\n",o.output,strerror(errno)); return 1; } }
    int status=0; for(int i=0;i<nf;i++) if(render_one(files[i],&o,out)) status=1;
    if (out != stdout) fclose(out);
    free(files);
    return status;
}
