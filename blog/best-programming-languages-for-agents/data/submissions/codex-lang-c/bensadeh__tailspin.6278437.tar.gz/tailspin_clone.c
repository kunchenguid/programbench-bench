#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

#define RESET "\033[0m"

enum group {
    G_NUMBERS,
    G_URLS,
    G_POINTERS,
    G_DATES,
    G_PATHS,
    G_QUOTES,
    G_KV,
    G_UUIDS,
    G_IPS,
    G_PROCESSES,
    G_JSON,
    G_COUNT
};

struct custom {
    char *word;
    const char *ansi;
};

struct opts {
    bool follow;
    bool print;
    bool disable_builtin;
    bool enable_seen;
    bool disable_seen;
    bool enabled[G_COUNT];
    bool disabled[G_COUNT];
    const char *file;
    const char *exec_cmd;
    struct custom custom[128];
    int custom_count;
};

static const char *group_names[G_COUNT] = {
    "numbers", "urls", "pointers", "dates", "paths", "quotes", "key-value-pairs",
    "uuids", "ip-addresses", "processes", "json"
};

static void print_help_short(void) {
    puts("A log file highlighter\n");
    puts("Usage: executable [OPTIONS] [FILE]\n");
    puts("Arguments:");
    puts("  [FILE]  Filepath\n");
    puts("Options:");
    puts("  -f, --follow");
    puts("          Follow the contents of a file");
    puts("  -p, --print");
    puts("          Print the output to stdout");
    puts("      --config-path <CONFIG_PATH>");
    puts("          Provide a custom path to a configuration file");
    puts("  -e, --exec <EXEC>");
    puts("          Run command and view the output in a pager");
    puts("      --highlight <COLOR_WORD>");
    puts("          Highlights in the form color:word1,word2");
    puts("      --enable <ENABLED_HIGHLIGHTERS>");
    puts("          Enable specific highlighters [possible values: numbers, urls, pointers, dates, paths,");
    puts("          quotes, key-value-pairs, uuids, ip-addresses, processes, json]");
    puts("      --disable <DISABLED_HIGHLIGHTERS>");
    puts("          Disable specific highlighters [possible values: numbers, urls, pointers, dates, paths,");
    puts("          quotes, key-value-pairs, uuids, ip-addresses, processes, json]");
    puts("      --disable-builtin-keywords");
    puts("          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities");
    puts("          and common REST verbs)");
    puts("      --pager <PAGER>");
    puts("          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`) [env:");
    puts("          TAILSPIN_PAGER=]");
    puts("  -h, --help");
    puts("          Print help (see more with '--help')");
    puts("  -V, --version");
    puts("          Print version");
}

static void print_help_long(void) {
    puts("A log file highlighter\n");
    puts("Usage: executable [OPTIONS] [FILE]\n");
    puts("Arguments:");
    puts("  [FILE]");
    puts("          Filepath\n");
    puts("Options:");
    puts("  -f, --follow");
    puts("          Follow the contents of a file\n");
    puts("  -p, --print");
    puts("          Print the output to stdout\n");
    puts("      --config-path <CONFIG_PATH>");
    puts("          Provide a custom path to a configuration file\n");
    puts("  -e, --exec <EXEC>");
    puts("          Run command and view the output in a pager\n");
    puts("      --highlight <COLOR_WORD>");
    puts("          Highlights in the form color:word1,word2");
    puts("          ");
    puts("          [possible values: red, green, yellow, blue, magenta, cyan]\n");
    puts("      --enable <ENABLED_HIGHLIGHTERS>");
    puts("          Enable specific highlighters");
    puts("          ");
    puts("          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,");
    puts("          ip-addresses, processes, json]\n");
    puts("      --disable <DISABLED_HIGHLIGHTERS>");
    puts("          Disable specific highlighters");
    puts("          ");
    puts("          [possible values: numbers, urls, pointers, dates, paths, quotes, key-value-pairs, uuids,");
    puts("          ip-addresses, processes, json]\n");
    puts("      --disable-builtin-keywords");
    puts("          Disable the highlighting of all builtin keyword groups (booleans, nulls, log severities");
    puts("          and common REST verbs)\n");
    puts("      --pager <PAGER>");
    puts("          Override the default pager command used by tspin. (e.g. `--pager=\"ov -f [FILE]\"`)");
    puts("          ");
    puts("          [env: TAILSPIN_PAGER=]\n");
    puts("  -h, --help");
    puts("          Print help (see a summary with '-h')\n");
    puts("  -V, --version");
    puts("          Print version");
}

static int group_index(const char *s) {
    for (int i = 0; i < G_COUNT; i++) {
        if (strcmp(s, group_names[i]) == 0) return i;
    }
    return -1;
}

static const char *color_ansi(const char *c) {
    if (strcmp(c, "red") == 0) return "\033[31m";
    if (strcmp(c, "green") == 0) return "\033[32m";
    if (strcmp(c, "yellow") == 0) return "\033[33m";
    if (strcmp(c, "blue") == 0) return "\033[34m";
    if (strcmp(c, "magenta") == 0) return "\033[35m";
    if (strcmp(c, "cyan") == 0) return "\033[36m";
    return NULL;
}

static void die_unexpected(const char *arg) {
    fprintf(stderr, "error: unexpected argument '%s' found\n\n", arg);
    fprintf(stderr, "  tip: to pass '%s' as a value, use '-- %s'\n\n", arg, arg);
    fprintf(stderr, "Usage: executable [OPTIONS] [FILE]\n\n");
    fprintf(stderr, "For more information, try '--help'.\n");
    exit(2);
}

static char *take_value(int *i, int argc, char **argv, const char *opt) {
    if (*i + 1 >= argc) {
        fprintf(stderr, "error: a value is required for '%s <VALUE>' but none was supplied\n\n", opt);
        fprintf(stderr, "For more information, try '--help'.\n");
        exit(2);
    }
    (*i)++;
    return argv[*i];
}

static void parse_group_list(struct opts *o, const char *s, bool en) {
    char *copy = strdup(s);
    for (char *tok = strtok(copy, ","); tok; tok = strtok(NULL, ",")) {
        int idx = group_index(tok);
        if (idx < 0) {
            fprintf(stderr, "error: invalid value '%s' for '%s'\n\n", tok, en ? "--enable" : "--disable");
            fprintf(stderr, "For more information, try '--help'.\n");
            free(copy);
            exit(2);
        }
        if (en) {
            o->enable_seen = true;
            o->enabled[idx] = true;
        } else {
            o->disable_seen = true;
            o->disabled[idx] = true;
        }
    }
    free(copy);
}

static void parse_highlight(struct opts *o, const char *s) {
    char *copy = strdup(s);
    char *colon = strchr(copy, ':');
    if (!colon) {
        fprintf(stderr, "error: invalid value '%s' for '--highlight <COLOR_WORD>': expected color:words\n\n", s);
        fprintf(stderr, "For more information, try '--help'.\n");
        free(copy);
        exit(2);
    }
    *colon = 0;
    const char *ansi = color_ansi(copy);
    if (!ansi) {
        fprintf(stderr, "error: invalid value '%s' for '--highlight <COLOR_WORD>': invalid variant: %s\n\n", s, copy);
        fprintf(stderr, "For more information, try '--help'.\n");
        free(copy);
        exit(2);
    }
    for (char *tok = strtok(colon + 1, ","); tok; tok = strtok(NULL, ",")) {
        if (*tok && o->custom_count < 128) {
            o->custom[o->custom_count].word = strdup(tok);
            o->custom[o->custom_count].ansi = ansi;
            o->custom_count++;
        }
    }
    free(copy);
}

static void parse_args(struct opts *o, int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "--") == 0) {
            if (++i < argc) o->file = argv[i];
            if (i + 1 < argc) die_unexpected(argv[i + 1]);
            break;
        } else if (strcmp(a, "-h") == 0) {
            print_help_short();
            exit(0);
        } else if (strcmp(a, "--help") == 0) {
            print_help_long();
            exit(0);
        } else if (strcmp(a, "-V") == 0 || strcmp(a, "--version") == 0) {
            puts("tspin 5.6.0");
            exit(0);
        } else if (strcmp(a, "-f") == 0 || strcmp(a, "--follow") == 0) {
            o->follow = true;
        } else if (strcmp(a, "-p") == 0 || strcmp(a, "--print") == 0) {
            o->print = true;
        } else if (strcmp(a, "--disable-builtin-keywords") == 0) {
            o->disable_builtin = true;
        } else if (strcmp(a, "-e") == 0 || strcmp(a, "--exec") == 0) {
            o->exec_cmd = take_value(&i, argc, argv, a);
        } else if (strcmp(a, "--config-path") == 0) {
            const char *p = take_value(&i, argc, argv, a);
            struct stat st;
            if (stat(p, &st) != 0) {
                fprintf(stderr, "Error:   ✗ could not find the TOML file\n\n");
                exit(1);
            }
        } else if (strcmp(a, "--pager") == 0) {
            (void)take_value(&i, argc, argv, a);
        } else if (strcmp(a, "--highlight") == 0) {
            parse_highlight(o, take_value(&i, argc, argv, a));
        } else if (strcmp(a, "--enable") == 0) {
            parse_group_list(o, take_value(&i, argc, argv, a), true);
        } else if (strcmp(a, "--disable") == 0) {
            parse_group_list(o, take_value(&i, argc, argv, a), false);
        } else if (strncmp(a, "--highlight=", 12) == 0) {
            parse_highlight(o, a + 12);
        } else if (strncmp(a, "--enable=", 9) == 0) {
            parse_group_list(o, a + 9, true);
        } else if (strncmp(a, "--disable=", 10) == 0) {
            parse_group_list(o, a + 10, false);
        } else if (strncmp(a, "--config-path=", 14) == 0) {
            struct stat st;
            if (stat(a + 14, &st) != 0) {
                fprintf(stderr, "Error:   ✗ could not find the TOML file\n\n");
                exit(1);
            }
        } else if (strncmp(a, "--pager=", 8) == 0) {
        } else if (a[0] == '-') {
            die_unexpected(a);
        } else {
            if (o->file) die_unexpected(a);
            o->file = a;
        }
    }
    if (o->enable_seen && o->disable_seen) {
        fprintf(stderr, "Error:   × cannot both enable and disable highlighters\n\n");
        exit(1);
    }
}

static bool group_on(struct opts *o, int g) {
    if (o->enable_seen) return o->enabled[g];
    return !o->disabled[g];
}

static bool is_word_char(int c) {
    return isalnum((unsigned char)c) || c == '_' || c == '-';
}

static bool boundary(const char *s, int pos, int len) {
    bool left = pos == 0 || !is_word_char((unsigned char)s[pos - 1]);
    bool right = s[pos + len] == 0 || !is_word_char((unsigned char)s[pos + len]);
    return left && right;
}

static void emit_span(const char *ansi, const char *s, int n) {
    fputs(ansi, stdout);
    fwrite(s, 1, n, stdout);
    fputs(RESET, stdout);
}

static int match_custom(struct opts *o, const char *s, const char **ansi) {
    int best = 0;
    *ansi = NULL;
    for (int i = 0; i < o->custom_count; i++) {
        int n = (int)strlen(o->custom[i].word);
        if (n > best && strncmp(s, o->custom[i].word, n) == 0) {
            best = n;
            *ansi = o->custom[i].ansi;
        }
    }
    return best;
}

static int match_word_ci(const char *s, const char *w) {
    int n = (int)strlen(w);
    return strncasecmp(s, w, n) == 0 && boundary(s, 0, n) ? n : 0;
}

static int match_word_cs(const char *s, const char *w) {
    int n = (int)strlen(w);
    return strncmp(s, w, n) == 0 && boundary(s, 0, n) ? n : 0;
}

static int match_builtin(const char *s, const char **ansi) {
    const char *white[] = {"INFO", "DEBUG", "TRACE", NULL};
    const char *yellow[] = {"WARN", "WARNING", NULL};
    const char *red[] = {"ERROR", "ERR", "FATAL", "CRITICAL", "FAIL", "FAILED", NULL};
    const char *green_bg[] = {"GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS", NULL};
    const char *bools[] = {"true", "false", "null", NULL};
    for (int i = 0; white[i]; i++) if (match_word_cs(s, white[i])) { *ansi = "\033[37m"; return (int)strlen(white[i]); }
    for (int i = 0; yellow[i]; i++) if (match_word_cs(s, yellow[i])) { *ansi = "\033[33m"; return (int)strlen(yellow[i]); }
    for (int i = 0; red[i]; i++) if (match_word_cs(s, red[i])) { *ansi = "\033[31m"; return (int)strlen(red[i]); }
    for (int i = 0; green_bg[i]; i++) if (match_word_cs(s, green_bg[i])) { *ansi = "\033[42;30m"; return (int)strlen(green_bg[i]); }
    for (int i = 0; bools[i]; i++) if (match_word_ci(s, bools[i])) { *ansi = "\033[3;31m"; return (int)strlen(bools[i]); }
    return 0;
}

static int match_uuid(const char *s) {
    int groups[] = {8, 4, 4, 4, 12};
    int p = 0;
    for (int g = 0; g < 5; g++) {
        for (int i = 0; i < groups[g]; i++, p++) if (!isxdigit((unsigned char)s[p])) return 0;
        if (g < 4) {
            if (s[p] != '-') return 0;
            p++;
        }
    }
    return boundary(s, 0, p) ? p : 0;
}

static int match_number(const char *s) {
    int i = 0;
    if (!isdigit((unsigned char)s[0])) return 0;
    while (isdigit((unsigned char)s[i])) i++;
    if (s[i] == '.' && isdigit((unsigned char)s[i + 1])) {
        i++;
        while (isdigit((unsigned char)s[i])) i++;
    }
    if (isalpha((unsigned char)s[i]) || s[i] == '_' || s[i] == '-') return 0;
    return i;
}

static int match_date(const char *s) {
    if (isdigit((unsigned char)s[0]) && isdigit((unsigned char)s[1]) &&
        isdigit((unsigned char)s[2]) && isdigit((unsigned char)s[3]) &&
        (s[4] == '-' || s[4] == '/') &&
        isdigit((unsigned char)s[5]) && isdigit((unsigned char)s[6]) &&
        (s[7] == '-' || s[7] == '/') &&
        isdigit((unsigned char)s[8]) && isdigit((unsigned char)s[9])) return 10;
    if (isdigit((unsigned char)s[0]) && isdigit((unsigned char)s[1]) && s[2] == ':' &&
        isdigit((unsigned char)s[3]) && isdigit((unsigned char)s[4]) && s[5] == ':' &&
        isdigit((unsigned char)s[6]) && isdigit((unsigned char)s[7])) {
        int i = 8;
        if (s[i] == '.' || s[i] == ',') {
            i++;
            while (isdigit((unsigned char)s[i])) i++;
        }
        return i;
    }
    return 0;
}

static int match_url(const char *s) {
    int p = 0;
    if (strncmp(s, "http://", 7) == 0) p = 7;
    else if (strncmp(s, "https://", 8) == 0) p = 8;
    else return 0;
    while (s[p] && !isspace((unsigned char)s[p]) && s[p] != '"' && s[p] != '\'' && s[p] != ']' && s[p] != ')') p++;
    return p;
}

static int match_ip(const char *s) {
    int p = 0, dots = 0;
    for (int part = 0; part < 4; part++) {
        int n = 0;
        while (isdigit((unsigned char)s[p]) && n < 3) { p++; n++; }
        if (n == 0) return 0;
        if (part < 3) {
            if (s[p] != '.') return 0;
            p++; dots++;
        }
    }
    return dots == 3 ? p : 0;
}

static int match_path(const char *s) {
    if (s[0] != '/' && !(isalpha((unsigned char)s[0]) && s[1] == ':' && (s[2] == '\\' || s[2] == '/'))) return 0;
    int p = 0;
    while (s[p] && !isspace((unsigned char)s[p]) && s[p] != '"' && s[p] != '\'') p++;
    return p > 1 ? p : 0;
}

static int match_kv_key(const char *s) {
    int p = 0;
    if (!isalpha((unsigned char)s[p]) && s[p] != '_') return 0;
    while (isalnum((unsigned char)s[p]) || s[p] == '_' || s[p] == '-' || s[p] == '.') p++;
    if (p > 0 && s[p] == '=') return p;
    return 0;
}

static void highlight_line(struct opts *o, const char *line) {
    int len = (int)strlen(line);
    for (int i = 0; i < len;) {
        const char *ansi = NULL;
        int n = match_custom(o, line + i, &ansi);
        if (n) {
            emit_span(ansi, line + i, n);
            i += n;
            continue;
        }
        if (!o->disable_builtin && (n = match_builtin(line + i, &ansi))) {
            emit_span(ansi, line + i, n);
            i += n;
            continue;
        }
        if (group_on(o, G_UUIDS) && (n = match_uuid(line + i))) {
            emit_span("\033[2;33m", line + i, n);
            i += n;
            continue;
        }
        if (group_on(o, G_URLS) && (n = match_url(line + i))) {
            emit_span("\033[2;34m", line + i, n);
            i += n;
            continue;
        }
        if (group_on(o, G_DATES) && (n = match_date(line + i))) {
            emit_span("\033[35m", line + i, n);
            i += n;
            continue;
        }
        if (group_on(o, G_IPS) && (n = match_ip(line + i))) {
            emit_span("\033[2;35m", line + i, n);
            i += n;
            continue;
        }
        if (group_on(o, G_PATHS) && (i == 0 || isspace((unsigned char)line[i - 1]) || line[i - 1] == '"' || line[i - 1] == '\'') && (n = match_path(line + i))) {
            emit_span("\033[2;34m", line + i, n);
            i += n;
            continue;
        }
        if (group_on(o, G_KV) && (n = match_kv_key(line + i))) {
            emit_span("\033[2m", line + i, n);
            i += n;
            continue;
        }
        if (group_on(o, G_NUMBERS) && (n = match_number(line + i))) {
            emit_span("\033[36m", line + i, n);
            i += n;
            continue;
        }
        fputc(line[i++], stdout);
    }
}

static int process_stream(struct opts *o, FILE *fp) {
    char *line = NULL;
    size_t cap = 0;
    ssize_t n;
    while ((n = getline(&line, &cap, fp)) != -1) {
        (void)n;
        highlight_line(o, line);
    }
    free(line);
    return ferror(fp) ? 1 : 0;
}

static int process_file(struct opts *o, const char *path) {
    FILE *fp = fopen(path, "r");
    if (!fp) {
        fprintf(stderr, "Error:   ⚠ \033[33m%s\033[0m: %s\n\n", path, strerror(errno));
        return 1;
    }
    int rc = process_stream(o, fp);
    if (o->follow) {
        clearerr(fp);
        for (;;) {
            int c = fgetc(fp);
            if (c == EOF) {
                clearerr(fp);
                usleep(200000);
            } else {
                ungetc(c, fp);
                process_stream(o, fp);
                fflush(stdout);
            }
        }
    }
    fclose(fp);
    return rc;
}

int main(int argc, char **argv) {
    struct opts o;
    memset(&o, 0, sizeof(o));
    parse_args(&o, argc, argv);

    if (o.exec_cmd && !o.file && isatty(STDIN_FILENO)) {
        FILE *fp = popen(o.exec_cmd, "r");
        if (!fp) {
            fprintf(stderr, "Error:   ⚠ could not run command\n\n");
            return 1;
        }
        int rc = process_stream(&o, fp);
        int st = pclose(fp);
        if (rc) return rc;
        if (WIFEXITED(st)) return WEXITSTATUS(st);
        return 1;
    }

    if (o.file) return process_file(&o, o.file);
    return process_stream(&o, stdin);
}
