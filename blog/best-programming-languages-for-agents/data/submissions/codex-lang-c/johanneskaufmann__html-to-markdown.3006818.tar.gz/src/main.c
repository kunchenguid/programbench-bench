#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <glob.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct {
    char *s;
    size_t len, cap;
} Buf;

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    exit(1);
}

static void binit(Buf *b) { b->s = NULL; b->len = b->cap = 0; }
static void bneed(Buf *b, size_t n) {
    if (b->len + n + 1 <= b->cap) return;
    size_t nc = b->cap ? b->cap * 2 : 256;
    while (nc < b->len + n + 1) nc *= 2;
    char *p = realloc(b->s, nc);
    if (!p) die("out of memory\n");
    b->s = p; b->cap = nc;
}
static void bch(Buf *b, char c) { bneed(b, 1); b->s[b->len++] = c; b->s[b->len] = 0; }
static void bstrn(Buf *b, const char *s, size_t n) { bneed(b, n); memcpy(b->s + b->len, s, n); b->len += n; b->s[b->len] = 0; }
static void bstr(Buf *b, const char *s) { bstrn(b, s, strlen(s)); }
static void bfmt(Buf *b, const char *fmt, ...) {
    va_list ap, cp;
    va_start(ap, fmt);
    va_copy(cp, ap);
    int n = vsnprintf(NULL, 0, fmt, cp);
    va_end(cp);
    if (n < 0) die("format error\n");
    bneed(b, (size_t)n);
    vsnprintf(b->s + b->len, (size_t)n + 1, fmt, ap);
    b->len += (size_t)n;
    va_end(ap);
}

typedef struct {
    const char *html;
    size_t pos, len;
    Buf *out;
    const char *strong;
    bool table, strike;
    char *domain;
    int list_depth;
    int list_type[64];
    int list_num[64];
    bool at_line_start;
    bool in_pre;
} Parser;

static bool starts_ci(const char *s, const char *p) {
    while (*p) {
        if (tolower((unsigned char)*s++) != tolower((unsigned char)*p++)) return false;
    }
    return true;
}
static void lower_name(char *s) { for (; *s; s++) *s = (char)tolower((unsigned char)*s); }

static void trim_trailing_spaces(Buf *b) {
    while (b->len && (b->s[b->len - 1] == ' ' || b->s[b->len - 1] == '\t')) b->s[--b->len] = 0;
}
static int trailing_newlines(Buf *b) {
    int n = 0;
    for (size_t i = b->len; i && b->s[i - 1] == '\n'; i--) n++;
    return n;
}
static void ensure_newlines(Parser *p, int n) {
    trim_trailing_spaces(p->out);
    int have = trailing_newlines(p->out);
    while (have++ < n) bch(p->out, '\n');
    p->at_line_start = true;
}
static void block_before(Parser *p) {
    if (p->out->len) ensure_newlines(p, 2);
}
static void block_after(Parser *p) { ensure_newlines(p, 2); }
static void append_raw(Parser *p, const char *s) {
    bstr(p->out, s);
    if (*s) p->at_line_start = s[strlen(s) - 1] == '\n';
}

static void append_indent(Parser *p) {
    for (int i = 1; i < p->list_depth; i++) bstr(p->out, "  ");
}

static void append_text_char(Parser *p, char c) {
    if (!p->in_pre && (c == '\n' || c == '\r' || c == '\t' || c == '\f')) c = ' ';
    if (!p->in_pre) {
        if (c == ' ') {
            if (!p->out->len || p->out->s[p->out->len - 1] == ' ' || p->out->s[p->out->len - 1] == '\n') return;
        }
        if (c == '*' || c == '_' || c == '[' || c == ']' || c == '`' || c == '\\') bch(p->out, '\\');
        if ((c == '#' || c == '-' || c == '+' || c == '>') && p->at_line_start) bch(p->out, '\\');
    }
    bch(p->out, c);
    p->at_line_start = (c == '\n');
}

static void append_entity(Parser *p, const char *e, size_t n) {
    if (n == 3 && !strncmp(e, "amp", 3)) append_text_char(p, '&');
    else if (n == 2 && !strncmp(e, "lt", 2)) append_raw(p, "&lt;");
    else if (n == 2 && !strncmp(e, "gt", 2)) append_raw(p, "&gt;");
    else if (n == 4 && !strncmp(e, "quot", 4)) append_text_char(p, '"');
    else if (n == 4 && !strncmp(e, "nbsp", 4)) append_text_char(p, ' ');
    else if (n == 4 && !strncmp(e, "apos", 4)) append_text_char(p, '\'');
    else if (n > 1 && e[0] == '#') {
        long v = 0;
        if (e[1] == 'x' || e[1] == 'X') v = strtol(e + 2, NULL, 16);
        else v = strtol(e + 1, NULL, 10);
        if (v == 39) append_text_char(p, '\'');
        else if (v == 160) append_text_char(p, ' ');
        else if (v > 0 && v < 128) append_text_char(p, (char)v);
    } else {
        bch(p->out, '&'); bstrn(p->out, e, n); bch(p->out, ';');
    }
}

static void append_text(Parser *p, const char *s, size_t n) {
    for (size_t i = 0; i < n; i++) {
        if (s[i] == '&') {
            size_t j = i + 1;
            while (j < n && j - i < 16 && s[j] != ';' && !isspace((unsigned char)s[j])) j++;
            if (j < n && s[j] == ';') { append_entity(p, s + i + 1, j - i - 1); i = j; continue; }
        }
        append_text_char(p, s[i]);
    }
}

typedef struct { char *name, *href, *src, *alt, *role; bool closing, self; } Tag;
static char *xstrndup(const char *s, size_t n) {
    char *r = malloc(n + 1);
    if (!r) die("out of memory\n");
    memcpy(r, s, n); r[n] = 0; return r;
}
static void tag_free(Tag *t) { free(t->name); free(t->href); free(t->src); free(t->alt); free(t->role); }

static char *read_attr_value(const char *s, size_t *i, size_t n) {
    while (*i < n && isspace((unsigned char)s[*i])) (*i)++;
    if (*i >= n) return xstrndup("", 0);
    char q = 0;
    if (s[*i] == '"' || s[*i] == '\'') q = s[(*i)++];
    size_t st = *i;
    if (q) while (*i < n && s[*i] != q) (*i)++;
    else while (*i < n && !isspace((unsigned char)s[*i]) && s[*i] != '/') (*i)++;
    char *v = xstrndup(s + st, *i - st);
    if (q && *i < n) (*i)++;
    return v;
}

static Tag parse_tag(const char *inside, size_t n) {
    Tag t = {0};
    size_t i = 0;
    while (i < n && isspace((unsigned char)inside[i])) i++;
    if (i < n && inside[i] == '/') { t.closing = true; i++; }
    while (i < n && isspace((unsigned char)inside[i])) i++;
    size_t st = i;
    while (i < n && (isalnum((unsigned char)inside[i]) || inside[i] == '-' || inside[i] == ':')) i++;
    t.name = xstrndup(inside + st, i - st); lower_name(t.name);
    while (i < n) {
        while (i < n && isspace((unsigned char)inside[i])) i++;
        if (i < n && inside[i] == '/') { t.self = true; i++; continue; }
        st = i;
        while (i < n && (isalnum((unsigned char)inside[i]) || inside[i] == '-' || inside[i] == ':')) i++;
        if (i == st) { i++; continue; }
        char *key = xstrndup(inside + st, i - st); lower_name(key);
        while (i < n && isspace((unsigned char)inside[i])) i++;
        char *val = xstrndup("", 0);
        if (i < n && inside[i] == '=') { i++; free(val); val = read_attr_value(inside, &i, n); }
        if (!strcmp(key, "href")) { free(t.href); t.href = val; }
        else if (!strcmp(key, "src")) { free(t.src); t.src = val; }
        else if (!strcmp(key, "alt")) { free(t.alt); t.alt = val; }
        else if (!strcmp(key, "role")) { free(t.role); t.role = val; }
        else free(val);
        free(key);
    }
    return t;
}

static size_t find_tag_end(const char *s, size_t i, size_t n) {
    char q = 0;
    for (; i < n; i++) {
        if (q) { if (s[i] == q) q = 0; }
        else if (s[i] == '"' || s[i] == '\'') q = s[i];
        else if (s[i] == '>') return i;
    }
    return n;
}

static char *absolute_url(const char *base, const char *url) {
    if (!url) return xstrndup("", 0);
    if (!base || strstr(url, "://") || starts_ci(url, "mailto:") || starts_ci(url, "#")) return xstrndup(url, strlen(url));
    if (url[0] == '/') {
        const char *p = strstr(base, "://");
        if (!p) return xstrndup(url, strlen(url));
        p += 3;
        const char *slash = strchr(p, '/');
        size_t hostn = slash ? (size_t)(slash - base) : strlen(base);
        Buf b; binit(&b); bstrn(&b, base, hostn); bstr(&b, url); return b.s;
    }
    const char *slash = strrchr(base, '/');
    if (!slash || (slash > base + 2 && slash[-1] == '/' && slash[-2] == ':')) {
        Buf b; binit(&b); bstr(&b, base); bch(&b, '/'); bstr(&b, url); return b.s;
    }
    Buf b; binit(&b); bstrn(&b, base, (size_t)(slash - base + 1)); bstr(&b, url); return b.s;
}

static void parse_content(Parser *p, const char *end);

static char *render_inner(Parser *p, const char *end) {
    Buf tmp; binit(&tmp);
    Buf *old = p->out; int old_depth = p->list_depth; bool old_start = p->at_line_start;
    p->out = &tmp; p->list_depth = old_depth; p->at_line_start = true;
    parse_content(p, end);
    trim_trailing_spaces(&tmp);
    while (tmp.len && tmp.s[tmp.len - 1] == '\n') tmp.s[--tmp.len] = 0;
    p->out = old; p->list_depth = old_depth; p->at_line_start = old_start;
    if (!tmp.s) return xstrndup("", 0);
    return tmp.s;
}

static char *render_inner_at_depth(Parser *p, const char *end, int depth) {
    Buf tmp; binit(&tmp);
    Buf *old = p->out; int old_depth = p->list_depth; bool old_start = p->at_line_start;
    p->out = &tmp; p->list_depth = depth; p->at_line_start = true;
    parse_content(p, end);
    trim_trailing_spaces(&tmp);
    while (tmp.len && tmp.s[tmp.len - 1] == '\n') tmp.s[--tmp.len] = 0;
    p->out = old; p->list_depth = old_depth; p->at_line_start = old_start;
    if (!tmp.s) return xstrndup("", 0);
    return tmp.s;
}

static bool is_block(const char *n) {
    const char *blocks[] = {"p","div","section","article","header","footer","main","nav","aside","figure","figcaption",NULL};
    for (int i = 0; blocks[i]; i++) if (!strcmp(n, blocks[i])) return true;
    return false;
}

typedef struct { char **cells; int n, cap; } Row;
typedef struct { Row *rows; int n, cap; } Table;
static void row_add(Row *r, char *s) { if (r->n == r->cap) { r->cap = r->cap ? r->cap * 2 : 4; r->cells = realloc(r->cells, r->cap * sizeof(char*)); } r->cells[r->n++] = s; }
static void table_add(Table *t, Row r) { if (t->n == t->cap) { t->cap = t->cap ? t->cap * 2 : 4; t->rows = realloc(t->rows, t->cap * sizeof(Row)); } t->rows[t->n++] = r; }

static void render_table(Parser *p) {
    Table tab = {0};
    while (p->pos < p->len) {
        size_t lt = p->pos;
        while (lt < p->len && p->html[lt] != '<') lt++;
        p->pos = lt;
        if (p->pos >= p->len) break;
        size_t gt = find_tag_end(p->html, p->pos + 1, p->len);
        if (gt >= p->len) break;
        Tag t = parse_tag(p->html + p->pos + 1, gt - p->pos - 1);
        p->pos = gt + 1;
        if (t.closing && !strcmp(t.name, "table")) { tag_free(&t); break; }
        if (!t.closing && !strcmp(t.name, "tr")) {
            Row r = {0};
            while (p->pos < p->len) {
                size_t lt2 = p->pos;
                while (lt2 < p->len && p->html[lt2] != '<') lt2++;
                p->pos = lt2;
                if (p->pos >= p->len) break;
                size_t gt2 = find_tag_end(p->html, p->pos + 1, p->len);
                Tag c = parse_tag(p->html + p->pos + 1, gt2 - p->pos - 1);
                p->pos = gt2 + 1;
                if (c.closing && !strcmp(c.name, "tr")) { tag_free(&c); break; }
                if (!c.closing && (!strcmp(c.name, "td") || !strcmp(c.name, "th"))) row_add(&r, render_inner(p, c.name));
                tag_free(&c);
            }
            table_add(&tab, r);
        }
        tag_free(&t);
    }
    if (!tab.n) return;
    block_before(p);
    int cols = 0; for (int i = 0; i < tab.n; i++) if (tab.rows[i].n > cols) cols = tab.rows[i].n;
    for (int i = 0; i < tab.n; i++) {
        bstr(p->out, "|");
        for (int c = 0; c < cols; c++) { bch(p->out, ' '); if (c < tab.rows[i].n) bstr(p->out, tab.rows[i].cells[c]); bstr(p->out, " |"); }
        bch(p->out, '\n');
        if (i == 0) { bstr(p->out, "|"); for (int c = 0; c < cols; c++) bstr(p->out, "---|"); bch(p->out, '\n'); }
    }
    block_after(p);
    for (int i = 0; i < tab.n; i++) { for (int c = 0; c < tab.rows[i].n; c++) free(tab.rows[i].cells[c]); free(tab.rows[i].cells); }
    free(tab.rows);
}

static const char *find_ci(const char *hay, const char *needle) {
    size_t nn = strlen(needle);
    if (!nn) return hay;
    for (const char *h = hay; *h; h++) {
        size_t i = 0;
        while (i < nn && h[i] && tolower((unsigned char)h[i]) == tolower((unsigned char)needle[i])) i++;
        if (i == nn) return h;
    }
    return NULL;
}

static void skip_until_close(Parser *p, const char *name) {
    char pat[128]; snprintf(pat, sizeof(pat), "</%s", name);
    for (;;) {
        const char *q = find_ci(p->html + p->pos, pat);
        if (!q) { p->pos = p->len; return; }
        size_t gt = find_tag_end(p->html, (size_t)(q - p->html) + 1, p->len);
        p->pos = gt < p->len ? gt + 1 : p->len;
        return;
    }
}

static void parse_content(Parser *p, const char *end) {
    while (p->pos < p->len) {
        if (p->html[p->pos] != '<') {
            size_t st = p->pos;
            while (p->pos < p->len && p->html[p->pos] != '<') p->pos++;
            append_text(p, p->html + st, p->pos - st);
            continue;
        }
        if (p->in_pre) {
            bool maybe_tag = false;
            if (p->pos + 2 < p->len && p->html[p->pos + 1] == '/') maybe_tag = true;
            if (starts_ci(p->html + p->pos, "<code")) maybe_tag = true;
            if (!maybe_tag) { append_text_char(p, p->html[p->pos++]); continue; }
        }
        if (p->pos + 4 <= p->len && !strncmp(p->html + p->pos, "<!--", 4)) {
            char *q = strstr((char*)p->html + p->pos + 4, "-->");
            p->pos = q ? (size_t)(q - p->html) + 3 : p->len; continue;
        }
        size_t gt = find_tag_end(p->html, p->pos + 1, p->len);
        if (gt >= p->len) { append_text_char(p, p->html[p->pos++]); continue; }
        Tag t = parse_tag(p->html + p->pos + 1, gt - p->pos - 1);
        p->pos = gt + 1;
        if (!t.name || !*t.name) { tag_free(&t); continue; }
        if (t.closing) {
            bool done = end && !strcmp(t.name, end);
            tag_free(&t);
            if (done) return;
            continue;
        }
        char *n = t.name;
        if (!strcmp(n, "script") || !strcmp(n, "style")) skip_until_close(p, n);
        else if (!strcmp(n, "br")) { trim_trailing_spaces(p->out); bstr(p->out, "  \n"); p->at_line_start = true; append_indent(p); }
        else if (!strcmp(n, "hr")) { block_before(p); append_raw(p, "* * *"); block_after(p); }
        else if (n[0] == 'h' && isdigit((unsigned char)n[1]) && !n[2] && n[1] >= '1' && n[1] <= '6') {
            int level = n[1] - '0'; block_before(p); for (int i = 0; i < level; i++) bch(p->out, '#'); bch(p->out, ' ');
            parse_content(p, n); block_after(p);
        } else if (is_block(n)) { block_before(p); parse_content(p, n); block_after(p);
        } else if (!strcmp(n, "strong") || !strcmp(n, "b")) { append_raw(p, p->strong); parse_content(p, n); append_raw(p, p->strong);
        } else if (!strcmp(n, "em") || !strcmp(n, "i")) { append_raw(p, "*"); parse_content(p, n); append_raw(p, "*");
        } else if (!strcmp(n, "code")) {
            bool old = p->in_pre;
            if (!old) append_raw(p, "`");
            p->in_pre = true; parse_content(p, n); p->in_pre = old;
            if (!old) append_raw(p, "`");
        } else if (!strcmp(n, "pre")) { block_before(p); append_raw(p, "```\n"); bool old = p->in_pre; p->in_pre = true; parse_content(p, n); p->in_pre = old; trim_trailing_spaces(p->out); ensure_newlines(p, 1); append_raw(p, "```"); block_after(p);
        } else if (!strcmp(n, "blockquote")) {
            char *inner = render_inner(p, n); block_before(p);
            char *save = inner; while (*save) { bstr(p->out, "> "); char *nl = strchr(save, '\n'); if (!nl) { bstr(p->out, save); break; } bstrn(p->out, save, (size_t)(nl - save)); bch(p->out, '\n'); save = nl + 1; }
            free(inner); block_after(p);
        } else if (!strcmp(n, "a")) {
            char *inner = render_inner(p, n); char *url = absolute_url(p->domain, t.href ? t.href : "");
            bch(p->out, '['); bstr(p->out, inner); bstr(p->out, "]("); bstr(p->out, url); bch(p->out, ')');
            free(inner); free(url);
        } else if (!strcmp(n, "img")) {
            char *url = absolute_url(p->domain, t.src ? t.src : ""); bstr(p->out, "!["); if (t.alt) bstr(p->out, t.alt); bstr(p->out, "]("); bstr(p->out, url); bch(p->out, ')'); free(url);
        } else if (!strcmp(n, "ul") || !strcmp(n, "ol")) {
            if (p->out->len) ensure_newlines(p, p->list_depth ? 2 : 2);
            if (p->list_depth < 63) { p->list_depth++; p->list_type[p->list_depth] = !strcmp(n, "ol"); p->list_num[p->list_depth] = 1; }
            parse_content(p, n);
            if (p->list_depth > 0) p->list_depth--;
            if (!p->list_depth) block_after(p);
        } else if (!strcmp(n, "li")) {
            trim_trailing_spaces(p->out); if (p->out->len && p->out->s[p->out->len - 1] != '\n') bch(p->out, '\n');
            append_indent(p);
            if (p->list_depth && p->list_type[p->list_depth]) bfmt(p->out, "%d. ", p->list_num[p->list_depth]++);
            else bstr(p->out, "- ");
            p->at_line_start = false;
            char *inner = render_inner_at_depth(p, n, p->list_depth - 1);
            for (char *s = inner; *s;) {
                char *nl = strchr(s, '\n');
                if (!nl) { bstr(p->out, s); break; }
                bstrn(p->out, s, (size_t)(nl - s));
                bch(p->out, '\n');
                if (nl[1]) {
                    for (int i = 0; i < p->list_depth; i++) bstr(p->out, "  ");
                }
                s = nl + 1;
            }
            free(inner);
            ensure_newlines(p, 1);
        } else if (!strcmp(n, "table")) {
            if (p->table && (!t.role || strcmp(t.role, "presentation"))) render_table(p);
            else parse_content(p, n);
        } else if (!strcmp(n, "del") || !strcmp(n, "s") || !strcmp(n, "strike")) {
            if (p->strike) append_raw(p, "~~");
            parse_content(p, n);
            if (p->strike) append_raw(p, "~~");
        } else {
            if (!t.self) parse_content(p, n);
        }
        tag_free(&t);
    }
}

static char *read_all(FILE *f) {
    Buf b; binit(&b);
    char tmp[8192];
    size_t n;
    while ((n = fread(tmp, 1, sizeof(tmp), f)) > 0) bstrn(&b, tmp, n);
    if (!b.s) return xstrndup("", 0);
    return b.s;
}

static char *convert(const char *html, const char *strong, bool table, bool strike, char *domain) {
    Buf out; binit(&out);
    Parser p = {.html = html, .len = strlen(html), .out = &out, .strong = strong, .table = table, .strike = strike, .domain = domain, .at_line_start = true};
    parse_content(&p, NULL);
    trim_trailing_spaces(&out);
    while (out.len && out.s[out.len - 1] == '\n') out.s[--out.len] = 0;
    bch(&out, '\n');
    return out.s;
}

static void version(void) {
    puts("html2markdown\n\nGitVersion:  dev\nGitCommit:   none\nBuildDate:   unknown");
}
static void help(void) {
    puts("\n# html2markdown - convert html to markdown [version dev]\n\nConvert HTML to Markdown. Even works with entire websites!\n\n## Flags\n\n    -v, --version\n        show the version of html2markdown and exit\n\n    --help\n\n    --input PATH\n        Input file, directory, or glob pattern (instead of stdin)\n\n    --output PATH\n        Output file or directory (instead of stdout)\n\n    --output-overwrite\n        Replace existing files\n\n    --domain\n        The url of the web page, used to convert relative links to absolute links.\n\n    --plugin-strikethrough\n        enable the plugin ~~strikethrough~~\n\n    --plugin-table\n        enable the plugin table\n");
}

static char *replace_ext(const char *path) {
    const char *base = strrchr(path, '/'); base = base ? base + 1 : path;
    char *r = xstrndup(base, strlen(base));
    char *dot = strrchr(r, '.');
    if (dot) strcpy(dot, ".md"); else { r = realloc(r, strlen(r) + 4); strcat(r, ".md"); }
    return r;
}

static bool is_dir(const char *p) { struct stat st; return stat(p, &st) == 0 && S_ISDIR(st.st_mode); }

int main(int argc, char **argv) {
    char *input = NULL, *output = NULL, *domain = NULL;
    const char *strong = "**";
    bool overwrite = false, table = false, strike = false;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "--help")) { help(); return 0; }
        else if (!strcmp(a, "-v") || !strcmp(a, "--version")) { version(); return 0; }
        else if (!strcmp(a, "--plugin-table")) table = true;
        else if (!strcmp(a, "--plugin-strikethrough")) strike = true;
        else if (!strcmp(a, "--output-overwrite")) overwrite = true;
        else if (!strncmp(a, "--input=", 8)) input = a + 8;
        else if (!strcmp(a, "--input")) { if (++i >= argc) die("error: flag needs an argument: -input\n"); input = argv[i]; }
        else if (!strncmp(a, "--output=", 9)) output = a + 9;
        else if (!strcmp(a, "--output")) { if (++i >= argc) die("error: flag needs an argument: -output\n"); output = argv[i]; }
        else if (!strncmp(a, "--domain=", 9)) domain = a + 9;
        else if (!strcmp(a, "--domain")) { if (++i >= argc) die("error: flag needs an argument: -domain\n"); domain = argv[i]; }
        else if (!strncmp(a, "--opt-strong-delimiter=", 23)) strong = a + 23;
        else if (!strcmp(a, "--opt-strong-delimiter")) { if (++i >= argc) die("error: flag needs an argument: -opt-strong-delimiter\n"); strong = argv[i]; }
        else if (!strncmp(a, "--opt-table", 11) || !strcmp(a, "--exclude-selector") || !strcmp(a, "--include-selector")) { if (!strchr(a, '=') && i + 1 < argc) i++; }
        else if (a[0] == '-') die("\nerror: unknown flag: %s\n\n", a);
        else input = a;
    }
    if (!input) {
        char *html = read_all(stdin);
        char *md = convert(html, strong, table, strike, domain);
        fputs(md, stdout);
        free(html); free(md); return 0;
    }
    glob_t g;
    int gr = glob(input, 0, NULL, &g);
    if (gr || g.gl_pathc == 0) die("error: no files found matching pattern \"%s\"\n\nHere is how you can use a glob to match multiple files:\n\n    html2markdown --input \"src/*.html\" --output \"dist/\"\n", input);
    bool outdir = output && (is_dir(output) || g.gl_pathc > 1);
    if (g.gl_pathc > 1 && (!output || !is_dir(output))) die("error: if --input is a directory or glob pattern, --output must be a directory\n");
    for (size_t i = 0; i < g.gl_pathc; i++) {
        FILE *f = fopen(g.gl_pathv[i], "rb");
        if (!f) die("error: failed to open input %s: %s\n", g.gl_pathv[i], strerror(errno));
        char *html = read_all(f); fclose(f);
        char *md = convert(html, strong, table, strike, domain);
        if (!output) fputs(md, stdout);
        else {
            char *path = NULL;
            if (outdir) {
                char *name = replace_ext(g.gl_pathv[i]);
                size_t need = strlen(output) + strlen(name) + 2;
                path = malloc(need); snprintf(path, need, "%s/%s", output, name); free(name);
            } else path = xstrndup(output, strlen(output));
            if (!overwrite) { FILE *chk = fopen(path, "rb"); if (chk) { fclose(chk); die("error: output file already exists: %s\n", path); } }
            FILE *of = fopen(path, "wb"); if (!of) die("error: failed to open output %s: %s\n", path, strerror(errno));
            fputs(md, of); fclose(of); free(path);
        }
        free(html); free(md);
    }
    globfree(&g);
    return 0;
}
