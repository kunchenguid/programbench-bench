#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

typedef struct Field {
    char *name, *desc, *access;
    unsigned offset, width;
    struct Field *next;
} Field;

typedef struct Register {
    char *name, *desc, *access;
    uint64_t addr, reset;
    unsigned size;
    Field *fields;
    struct Register *next;
} Register;

typedef struct Peripheral {
    char *name, *desc, *group;
    uint64_t base;
    Register *regs;
    struct Peripheral *next;
} Peripheral;

typedef struct Interrupt {
    char *name, *desc;
    int value;
    struct Interrupt *next;
} Interrupt;

typedef struct {
    char *name, *desc;
    Peripheral *peripherals;
    Interrupt *interrupts;
} Device;

typedef struct {
    char *input, *outdir, *config, *settings, *edition, *target, *log_level, *source_type;
    bool make_mod, generic_mod, skip_attrs, atomics, ignore_groups, keep_list;
    bool feature_group, feature_peripheral, strict, reexport_core, reexport_interrupt, impl_debug;
} Opts;

static char *xstrdup(const char *s) { return s ? strcpy(malloc(strlen(s)+1), s) : NULL; }

static char *read_all(FILE *f) {
    size_t cap = 8192, len = 0;
    char *buf = malloc(cap + 1);
    if (!buf) exit(1);
    for (;;) {
        if (len == cap) { cap *= 2; buf = realloc(buf, cap + 1); if (!buf) exit(1); }
        size_t n = fread(buf + len, 1, cap - len, f);
        len += n;
        if (n == 0) break;
    }
    buf[len] = 0;
    return buf;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) {
        fprintf(stderr, "[ERROR svd2rust] Cannot open the SVD file\n    \n    Caused by:\n        %s (os error %d)\n", strerror(errno), errno);
        exit(1);
    }
    char *s = read_all(f);
    fclose(f);
    return s;
}

static char *trim_copy(const char *a, size_t n) {
    while (n && isspace((unsigned char)*a)) { a++; n--; }
    while (n && isspace((unsigned char)a[n-1])) n--;
    char *r = malloc(n + 1);
    memcpy(r, a, n); r[n] = 0;
    return r;
}

static char *tag_text_range(const char *start, const char *end, const char *tag) {
    char open[128], close[128];
    snprintf(open, sizeof open, "<%s", tag);
    snprintf(close, sizeof close, "</%s>", tag);
    const char *p = start;
    while ((p = strstr(p, open)) && p < end) {
        if (p[strlen(open)] != '>' && !isspace((unsigned char)p[strlen(open)])) { p += strlen(open); continue; }
        p = strchr(p, '>');
        if (!p || p >= end) return NULL;
        p++;
        const char *q = strstr(p, close);
        if (!q || q > end) return NULL;
        return trim_copy(p, (size_t)(q - p));
    }
    return NULL;
}

static char *tag_text(const char *start, const char *tag) {
    return tag_text_range(start, start + strlen(start), tag);
}

static const char *find_tag(const char *start, const char *end, const char *tag, const char **content, const char **after) {
    char open[128], close[128];
    snprintf(open, sizeof open, "<%s", tag);
    snprintf(close, sizeof close, "</%s>", tag);
    const char *p = start;
    while ((p = strstr(p, open)) && p < end) {
        if (p[strlen(open)] != '>' && !isspace((unsigned char)p[strlen(open)])) { p += strlen(open); continue; }
        const char *gt = strchr(p, '>');
        if (!gt || gt >= end) return NULL;
        const char *q = strstr(gt + 1, close);
        if (!q || q > end) return NULL;
        *content = gt + 1;
        *after = q + strlen(close);
        return p;
    }
    return NULL;
}

static uint64_t parse_u64(const char *s, uint64_t dflt) {
    if (!s || !*s) return dflt;
    while (isspace((unsigned char)*s)) s++;
    if (!strncmp(s, "#", 1)) s++;
    char *end = NULL;
    uint64_t v = strtoull(s, &end, 0);
    return end == s ? dflt : v;
}

static char *ident(const char *s, bool pascal) {
    if (!s || !*s) return xstrdup(pascal ? "X" : "x");
    char tmp[512]; size_t j = 0; bool cap = pascal, last_us = false;
    for (size_t i = 0; s[i] && j < sizeof(tmp)-1; i++) {
        unsigned char c = (unsigned char)s[i];
        if (isalnum(c)) {
            if (pascal) tmp[j++] = cap ? (char)toupper(c) : (char)tolower(c);
            else tmp[j++] = (char)tolower(c);
            cap = false; last_us = false;
        } else {
            cap = pascal;
            if (!pascal && !last_us && j) { tmp[j++] = '_'; last_us = true; }
        }
    }
    while (j && tmp[j-1] == '_') j--;
    tmp[j] = 0;
    if (!j || isdigit((unsigned char)tmp[0])) {
        char *r = malloc(j + 3);
        sprintf(r, pascal ? "X%s" : "_%s", tmp);
        return r;
    }
    return xstrdup(tmp);
}

static char *doc(const char *s) {
    if (!s) return xstrdup("");
    char *r = xstrdup(s);
    for (char *p = r; *p; p++) if (*p == '\n' || *p == '\r' || *p == '"') *p = *p == '"' ? '\'' : ' ';
    return r;
}

static Register *parse_registers(const char *start, const char *end) {
    Register *head = NULL, **tail = &head;
    const char *c, *after, *p = start;
    while (find_tag(p, end, "register", &c, &after)) {
        Register *r = calloc(1, sizeof *r);
        r->name = tag_text_range(c, after, "name");
        r->desc = tag_text_range(c, after, "description");
        r->access = tag_text_range(c, after, "access");
        char *t = tag_text_range(c, after, "addressOffset"); r->addr = parse_u64(t, 0); free(t);
        t = tag_text_range(c, after, "resetValue"); r->reset = parse_u64(t, 0); free(t);
        t = tag_text_range(c, after, "size"); r->size = (unsigned)parse_u64(t, 32); free(t);
        const char *fc, *fa, *fp = c;
        Field **ft = &r->fields;
        while (find_tag(fp, after, "field", &fc, &fa)) {
            Field *f = calloc(1, sizeof *f);
            f->name = tag_text_range(fc, fa, "name");
            f->desc = tag_text_range(fc, fa, "description");
            f->access = tag_text_range(fc, fa, "access");
            t = tag_text_range(fc, fa, "bitOffset");
            if (t) { f->offset = (unsigned)parse_u64(t, 0); free(t); }
            else {
                t = tag_text_range(fc, fa, "lsb"); f->offset = (unsigned)parse_u64(t, 0); free(t);
            }
            t = tag_text_range(fc, fa, "bitWidth");
            if (t) { f->width = (unsigned)parse_u64(t, 1); free(t); }
            else {
                char *msb = tag_text_range(fc, fa, "msb");
                char *lsb = tag_text_range(fc, fa, "lsb");
                if (msb && lsb) f->width = (unsigned)(parse_u64(msb,0) - parse_u64(lsb,0) + 1);
                else f->width = 1;
                free(msb); free(lsb);
            }
            *ft = f; ft = &f->next; fp = fa;
        }
        *tail = r; tail = &r->next; p = after;
    }
    return head;
}

static Device parse_device(const char *xml) {
    Device d = {0};
    d.name = tag_text(xml, "name");
    d.desc = tag_text(xml, "description");
    const char *pc, *pa, *p = xml + 1;
    Peripheral **pt = &d.peripherals;
    while (find_tag(p, xml + strlen(xml), "peripheral", &pc, &pa)) {
        Peripheral *per = calloc(1, sizeof *per);
        per->name = tag_text_range(pc, pa, "name");
        per->desc = tag_text_range(pc, pa, "description");
        per->group = tag_text_range(pc, pa, "groupName");
        char *t = tag_text_range(pc, pa, "baseAddress"); per->base = parse_u64(t, 0); free(t);
        per->regs = parse_registers(pc, pa);
        *pt = per; pt = &per->next; p = pa;
    }
    const char *ic, *ia; p = xml + 1; Interrupt **it = &d.interrupts;
    while (find_tag(p, xml + strlen(xml), "interrupt", &ic, &ia)) {
        Interrupt *in = calloc(1, sizeof *in);
        in->name = tag_text_range(ic, ia, "name");
        in->desc = tag_text_range(ic, ia, "description");
        char *t = tag_text_range(ic, ia, "value"); in->value = (int)parse_u64(t, 0); free(t);
        *it = in; it = &in->next; p = ia;
    }
    if (!d.name) d.name = xstrdup("Device");
    return d;
}

static bool is_readable(const char *a) { return !a || !strstr(a, "write-only"); }
static bool is_writable(const char *a) { return !a || strstr(a, "write") || strstr(a, "read-write"); }
static const char *ux(unsigned bits) { return bits <= 8 ? "u8" : bits <= 16 ? "u16" : bits <= 32 ? "u32" : "u64"; }

static char *hex_us(uint64_t v) {
    char raw[32], tmp[48];
    snprintf(raw, sizeof raw, "%llx", (unsigned long long)v);
    size_t n = strlen(raw), first = n % 4, j = 0;
    if (!first) first = 4;
    tmp[j++] = '0'; tmp[j++] = 'x';
    for (size_t i = 0; i < n; i++) {
        if (i && (i - first) % 4 == 0) tmp[j++] = '_';
        tmp[j++] = raw[i];
    }
    tmp[j] = 0;
    return xstrdup(tmp);
}

static void out(FILE *f, const char *fmt, ...) {
    va_list ap; va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
}

static void write_common(FILE *f, const Opts *o) {
    (void)o;
    out(f, "use core::marker::PhantomData;\n");
    out(f, "pub struct Periph<PER: PeripheralSpec>{_marker:PhantomData<PER>}\n");
    out(f, "pub trait PeripheralSpec{type RB; const ADDRESS:usize; const NAME:&'static str;}\n");
    out(f, "impl<PER:PeripheralSpec> Periph<PER>{pub const PTR:*const PER::RB=PER::ADDRESS as *const _; pub const fn ptr()->*const PER::RB{Self::PTR} pub unsafe fn steal()->Self{Self{_marker:PhantomData}}}\n");
    out(f, "impl<PER:PeripheralSpec> core::ops::Deref for Periph<PER>{type Target=PER::RB; fn deref(&self)->&Self::Target{unsafe{&*Self::PTR}}}\n");
    out(f, "pub trait RegisterSpec{type Ux:Copy+Default;}\npub trait Readable:RegisterSpec{}\npub trait Writable:RegisterSpec{type Safety;}\npub trait Resettable:RegisterSpec{const RESET_VALUE:Self::Ux;}\npub struct Unsafe; pub struct Safe;\n");
    out(f, "pub struct R<REG:RegisterSpec>{bits:REG::Ux} impl<REG:RegisterSpec> R<REG>{pub const fn bits(&self)->REG::Ux{self.bits}}\n");
    out(f, "pub struct W<REG:RegisterSpec>{bits:REG::Ux} impl<REG:RegisterSpec> W<REG>{pub unsafe fn bits(&mut self,bits:REG::Ux)->&mut Self{self.bits=bits;self}}\n");
    out(f, "#[repr(transparent)] pub struct Reg<REG:RegisterSpec>{register:core::cell::UnsafeCell<REG::Ux>,_marker:PhantomData<REG>} unsafe impl<REG:RegisterSpec> Sync for Reg<REG>{}\n");
    out(f, "impl<REG:RegisterSpec> Reg<REG>{pub fn as_ptr(&self)->*mut REG::Ux{self.register.get()}}\n");
    out(f, "impl<REG:Readable> Reg<REG>{pub fn read(&self)->R<REG>{R{bits:unsafe{core::ptr::read_volatile(self.as_ptr())}}}}\n");
    out(f, "impl<REG:Writable> Reg<REG>{pub unsafe fn write_with_zero<F>(&self,f:F)->REG::Ux where F:FnOnce(&mut W<REG>)->&mut W<REG>, REG::Ux:Default{let mut w=W{bits:Default::default()}; let v=f(&mut w).bits; core::ptr::write_volatile(self.as_ptr(),v); v}}\n");
    out(f, "impl<REG:Writable+Resettable> Reg<REG>{pub fn reset(&self){unsafe{core::ptr::write_volatile(self.as_ptr(),REG::RESET_VALUE)}} pub fn write<F>(&self,f:F)->REG::Ux where F:FnOnce(&mut W<REG>)->&mut W<REG>{let mut w=W{bits:REG::RESET_VALUE}; let v=f(&mut w).bits; unsafe{core::ptr::write_volatile(self.as_ptr(),v)}; v}}\n");
    out(f, "impl<REG:Readable+Writable> Reg<REG>{pub fn modify<F>(&self,f:F)->REG::Ux where F:for<'w> FnOnce(&R<REG>,&'w mut W<REG>)->&'w mut W<REG>{let bits=unsafe{core::ptr::read_volatile(self.as_ptr())}; let r=R{bits}; let mut w=W{bits}; let v=f(&r,&mut w).bits; unsafe{core::ptr::write_volatile(self.as_ptr(),v)}; v}}\n");
    out(f, "pub struct FieldReader<T=u8>{bits:T} impl<T:Copy> FieldReader<T>{pub const fn new(bits:T)->Self{Self{bits}} pub const fn bits(&self)->T{self.bits}}\n");
    out(f, "pub struct BitReader{bits:bool} impl BitReader{pub const fn new(bits:bool)->Self{Self{bits}} pub const fn bit(&self)->bool{self.bits} pub const fn bit_is_set(&self)->bool{self.bits} pub const fn bit_is_clear(&self)->bool{!self.bits}}\n");
    out(f, "pub struct FieldWriter<'a,REG:RegisterSpec,const WI:u8,T=u8>{w:&'a mut W<REG>,o:u8,_p:PhantomData<T>} impl<'a,REG:RegisterSpec,const WI:u8,T> FieldWriter<'a,REG,WI,T> where REG::Ux:From<T>+core::ops::BitAnd<Output=REG::Ux>+core::ops::BitOr<Output=REG::Ux>+core::ops::Not<Output=REG::Ux>+core::ops::Shl<u8,Output=REG::Ux>+Copy, T:Copy{pub fn new(w:&'a mut W<REG>,o:u8)->Self{Self{w,o,_p:PhantomData}} pub unsafe fn bits(self,value:T)->&'a mut W<REG>{self.w.bits=REG::Ux::from(value); self.w}}\n");
    out(f, "pub struct BitWriter<'a,REG:RegisterSpec>{w:&'a mut W<REG>,o:u8} impl<'a,REG:RegisterSpec> BitWriter<'a,REG> where REG::Ux:From<u8>+core::ops::BitOrAssign+core::ops::BitAndAssign+core::ops::Not<Output=REG::Ux>+core::ops::Shl<u8,Output=REG::Ux>+Copy{pub fn new(w:&'a mut W<REG>,o:u8)->Self{Self{w,o}} pub fn set_bit(self)->&'a mut W<REG>{self.bit(true)} pub fn clear_bit(self)->&'a mut W<REG>{self.bit(false)} pub fn bit(self,value:bool)->&'a mut W<REG>{let one=REG::Ux::from(1u8)<<self.o; if value{self.w.bits|=one}else{self.w.bits&=!one}; self.w}}\n");
}

static void write_build_files(const char *dir) {
    char path[1024];
    snprintf(path, sizeof path, "%s/build.rs", dir);
    FILE *f = fopen(path, "w");
    if (f) { fputs("#![doc = r\" Builder file for Peripheral access crate generated by svd2rust tool\"]\nfn main(){println!(\"cargo:rerun-if-changed=build.rs\");}\n", f); fclose(f); }
    snprintf(path, sizeof path, "%s/device.x", dir);
    f = fopen(path, "w"); if (f) fclose(f);
}

static void write_rust(const char *dir, const Opts *o, const Device *d) {
    mkdir(dir, 0777);
    write_build_files(dir);
    if (o->generic_mod) {
        char gp[1024]; snprintf(gp, sizeof gp, "%s/generic.rs", dir);
        FILE *g = fopen(gp, "w"); if (g) { write_common(g, o); fclose(g); }
    }
    char path[1024]; snprintf(path, sizeof path, "%s/%s", dir, o->make_mod ? "mod.rs" : "lib.rs");
    FILE *f = fopen(path, "w");
    if (!f) { fprintf(stderr, "[ERROR svd2rust] Cannot create output file\n"); exit(1); }
    char *dn = doc(d->name);
    out(f, "#![doc = \"Peripheral access API for %s microcontrollers (generated using svd2rust v0.37.1 (e29353d 2026-03-03))\"]\n", dn);
    if (!o->skip_attrs && !o->make_mod) out(f, "#![allow(non_camel_case_types)]\n#![allow(non_snake_case)]\n#![no_std]\n");
    if (o->generic_mod) out(f, "pub mod generic; pub use generic::*;\n"); else write_common(f, o);
    out(f, "#[derive(Copy,Clone,Debug,PartialEq,Eq)] pub enum Interrupt{");
    for (Interrupt *in = d->interrupts; in; in = in->next) { char *id = ident(in->name, true); out(f, "%s=%d,", id, in->value); free(id); }
    out(f, "}\n");
    for (Peripheral *p = d->peripherals; p; p = p->next) {
        char *ptype = ident(p->name, true), *pmod = ident(p->name, false), *pdoc = doc(p->desc ? p->desc : p->name);
        char *base_hex = hex_us(p->base);
        out(f, "#[doc = \"%s\"] pub type %s = crate::Periph<%sSpec>;\npub struct %sSpec; impl crate::PeripheralSpec for %sSpec{type RB=%s::RegisterBlock; const ADDRESS:usize=%s; const NAME:&'static str=\"%s\";}\n", pdoc, ptype, ptype, ptype, ptype, pmod, base_hex, ptype);
        free(base_hex);
        out(f, "#[doc = \"%s\"] pub mod %s{\nuse super::*;\n#[repr(C)] pub struct RegisterBlock{\n", pdoc, pmod);
        uint64_t off = 0; int resn = 0;
        for (Register *r = p->regs; r; r = r->next) {
            if (r->addr > off) { out(f, "_reserved%d:[u8;0x%llx],\n", resn++, (unsigned long long)(r->addr - off)); off = r->addr; }
            char *rn = ident(r->name, false), *rt = ident(r->name, true);
            out(f, "pub %s:%s,\n", rn, rt);
            off += (r->size ? r->size : 32) / 8; free(rn); free(rt);
        }
        out(f, "}\nimpl RegisterBlock{\n");
        for (Register *r = p->regs; r; r = r->next) {
            char *rn = ident(r->name, false), *rt = ident(r->name, true), *rd = doc(r->desc);
            out(f, "#[doc=\"0x%02llx - %s\"] pub const fn %s(&self)->&%s{&self.%s}\n", (unsigned long long)r->addr, rd, rn, rt, rn);
            free(rn); free(rt); free(rd);
        }
        out(f, "}\n");
        for (Register *r = p->regs; r; r = r->next) {
            char *rn = ident(r->name, false), *rt = ident(r->name, true), *rd = doc(r->desc), *raw = (char*)ux(r->size);
            out(f, "#[doc=\"%s\"] pub type %s=crate::Reg<%s::%sSpec>;\npub mod %s{\nuse super::*;\npub type R=crate::R<%sSpec>; pub type W=crate::W<%sSpec>;\n", rd, rt, rn, rt, rn, rt, rt);
            for (Field *fl = r->fields; fl; fl = fl->next) {
                char *ft = ident(fl->name, true), *fd = doc(fl->desc);
                out(f, "#[doc=\"Field `%s` reader - %s\"] pub type %sR=crate::%s;\n", fl->name?fl->name:"FIELD", fd, ft, fl->width == 1 ? "BitReader" : "FieldReader");
                if (fl->width == 1) out(f, "#[doc=\"Field `%s` writer - %s\"] pub type %sW<'a,REG>=crate::BitWriter<'a,REG>;\n", fl->name?fl->name:"FIELD", fd, ft);
                else out(f, "#[doc=\"Field `%s` writer - %s\"] pub type %sW<'a,REG>=crate::FieldWriter<'a,REG,%u>;\n", fl->name?fl->name:"FIELD", fd, ft, fl->width);
                free(ft); free(fd);
            }
            out(f, "impl R{\n");
            for (Field *fl = r->fields; fl; fl = fl->next) {
                char *fn = ident(fl->name, false), *ft = ident(fl->name, true), *fd = doc(fl->desc);
                uint64_t mask = fl->width >= 64 ? UINT64_MAX : ((1ULL << fl->width) - 1);
                if (fl->width == 1) out(f, "#[doc=\"Bit %u - %s\"] pub fn %s(&self)->%sR{%sR::new(((self.bits()>>%u)&1)!=0)}\n", fl->offset, fd, fn, ft, ft, fl->offset);
                else out(f, "#[doc=\"Bits %u:%u - %s\"] pub fn %s(&self)->%sR{%sR::new(((self.bits()>>%u)&0x%llx) as u8)}\n", fl->offset, fl->offset+fl->width-1, fd, fn, ft, ft, fl->offset, (unsigned long long)mask);
                free(fn); free(ft); free(fd);
            }
            out(f, "}\nimpl W{\n");
            for (Field *fl = r->fields; fl; fl = fl->next) {
                char *fn = ident(fl->name, false), *ft = ident(fl->name, true), *fd = doc(fl->desc);
                out(f, "#[doc=\"%s\"] pub fn %s(&mut self)->%sW<'_,%sSpec>{%sW::new(self,%u)}\n", fd, fn, ft, rt, ft, fl->offset);
                free(fn); free(ft); free(fd);
            }
            out(f, "}\npub struct %sSpec; impl crate::RegisterSpec for %sSpec{type Ux=%s;}\n", rt, rt, raw);
            if (is_readable(r->access)) out(f, "impl crate::Readable for %sSpec{}\n", rt);
            if (is_writable(r->access)) out(f, "impl crate::Writable for %sSpec{type Safety=crate::Unsafe;}\n", rt);
            out(f, "impl crate::Resettable for %sSpec{const RESET_VALUE:Self::Ux=0x%llx;}\n}\n", rt, (unsigned long long)r->reset);
            if (!r->desc && strcmp(o->log_level, "off") && strcmp(o->log_level, "error")) fprintf(stderr, "[WARN  svd2rust::generate::register] Missing description for register %s\n", r->name ? r->name : "");
            free(rn); free(rt); free(rd);
        }
        out(f, "}\n");
        free(ptype); free(pmod); free(pdoc);
    }
    out(f, "static mut DEVICE_PERIPHERALS:bool=false;\npub struct Peripherals{");
    for (Peripheral *p = d->peripherals; p; p = p->next) { char *pn = ident(p->name, false), *pt = ident(p->name, true); out(f, "pub %s:%s,", pn, pt); free(pn); free(pt); }
    out(f, "} impl Peripherals{pub unsafe fn steal()->Self{DEVICE_PERIPHERALS=true; Self{");
    for (Peripheral *p = d->peripherals; p; p = p->next) { char *pn = ident(p->name, false), *pt = ident(p->name, true); out(f, "%s:%s::steal(),", pn, pt); free(pn); free(pt); }
    out(f, "}}}\n");
    fclose(f); free(dn);
}

static void help(bool longh) {
    printf("Generate a Rust API from SVD files\n\nUsage: executable [OPTIONS]\n\nOptions:\n");
    printf("  -i <FILE>\n          Input SVD file\n");
    printf("  -o, --output-dir <PATH>\n          Directory to place generated files\n");
    printf("  -c, --config <TOML_FILE>\n          Config TOML file\n");
    printf("      --settings <YAML_FILE>\n          Target-specific settings YAML file\n");
    printf("      --edition <YEAR>\n          Rust edition of generated code\n");
    printf("      --target <ARCH>\n          Target architecture\n");
    printf("      --atomics\n          Generate atomic register modification API\n");
    printf("      --atomics-feature <FEATURE>\n          add feature gating for atomic register modification API\n");
    printf("      --ignore-groups\n          Don't add alternateGroup name as prefix to register name\n");
    printf("      --keep-list\n          Keep lists when generating code of dimElement, instead of trying to generate arrays\n");
    printf("  -g, --generic-mod\n          Push generic mod in separate file\n");
    printf("      --feature-group\n          Use group_name of peripherals as feature\n");
    printf("      --feature-peripheral\n          Use independent cfg feature flags for each peripheral\n");
    printf("  -f, --ident-format <ident_format>\n          Specify `-f type:prefix:case:suffix` to change default ident formatting.\n");
    if (longh) printf("          Allowed values of `type` are [\"enum_name\", \"enum_value_accessor\", \"peripheral\", \"peripheral_mod\", \"interrupt\", \"enum_read_name\", \"enum_write_name\", \"register_mod\", \"cluster\", \"peripheral_spec\", \"register_spec\", \"peripheral_feature\", \"register_accessor\", \"field_accessor\", \"cluster_mod\", \"field_reader\", \"peripheral_singleton\", \"field_writer\", \"enum_value\", \"cluster_accessor\", \"register\"].\n          Allowed cases are `unchanged` (''), `pascal` ('p'), `constant` ('c') and `snake` ('s').\n          \n");
    printf("      --ident-formats-theme <THEME>\n          A set of `ident_format` settings. `new` or `legacy`\n");
    printf("      --field-names-for-enums\n          Use field name for enumerations even when enumeratedValues has a name\n");
    printf("      --max-cluster-size\n          Use array increment for cluster size\n");
    printf("      --impl-debug\n          implement Debug for readable blocks and registers\n");
    printf("      --impl-debug-feature <FEATURE>\n          Add feature gating for block and register debug implementation\n");
    printf("      --impl-defmt <FEATURE>\n          Add automatic defmt implementation for enumerated values\n");
    printf("  -m, --make-mod\n          Create mod.rs instead of lib.rs, without inner attributes\n");
    printf("      --skip-crate-attributes\n          Do not generate crate attributes\n");
    printf("  -s, --strict\n          Make advanced checks due to parsing SVD\n");
    printf("      --source-type <source_type>\n          Specify file/stream format\n");
    printf("      --reexport-core-peripherals\n          For Cortex-M target reexport peripherals from cortex-m crate\n");
    printf("      --reexport-interrupt\n          Reexport interrupt macro from cortex-m-rt like crates\n");
    printf("  -b, --base-address-shift <base_address_shift>\n          Add offset to all base addresses on all peripherals in the SVD file.\n");
    printf("  -l, --log <log_level>\n          Choose which messages to log (overrides RUST_LOG) [possible values: off, error, warn, info, debug, trace]\n");
    printf("  -h, --help\n          Print help (see %s with '%s')\n", longh ? "a summary" : "more", longh ? "-h" : "--help");
    printf("  -V, --version\n          Print version\n");
}

static char *needarg(int *i, int argc, char **argv) {
    if (*i + 1 >= argc) { fprintf(stderr, "error: a value is required for '%s' but none was supplied\n", argv[*i]); exit(2); }
    return argv[++*i];
}

int main(int argc, char **argv) {
    Opts o = {.outdir = ".", .log_level = "info"};
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h")) { help(false); return 0; }
        if (!strcmp(a, "--help")) { help(true); return 0; }
        if (!strcmp(a, "-V") || !strcmp(a, "--version")) { puts("svd2rust 0.37.1 (e29353d 2026-03-03)"); return 0; }
        if (!strcmp(a, "-i")) o.input = needarg(&i, argc, argv);
        else if (!strcmp(a, "-o") || !strcmp(a, "--output-dir")) o.outdir = needarg(&i, argc, argv);
        else if (!strcmp(a, "-c") || !strcmp(a, "--config")) o.config = needarg(&i, argc, argv);
        else if (!strcmp(a, "--settings")) o.settings = needarg(&i, argc, argv);
        else if (!strcmp(a, "--edition")) o.edition = needarg(&i, argc, argv);
        else if (!strcmp(a, "--target")) o.target = needarg(&i, argc, argv);
        else if (!strcmp(a, "--atomics")) o.atomics = true;
        else if (!strcmp(a, "--atomics-feature")) (void)needarg(&i, argc, argv);
        else if (!strcmp(a, "--ignore-groups")) o.ignore_groups = true;
        else if (!strcmp(a, "--keep-list")) o.keep_list = true;
        else if (!strcmp(a, "-g") || !strcmp(a, "--generic-mod")) o.generic_mod = true;
        else if (!strcmp(a, "--feature-group")) o.feature_group = true;
        else if (!strcmp(a, "--feature-peripheral")) o.feature_peripheral = true;
        else if (!strcmp(a, "-f") || !strcmp(a, "--ident-format")) (void)needarg(&i, argc, argv);
        else if (!strcmp(a, "--ident-formats-theme")) (void)needarg(&i, argc, argv);
        else if (!strcmp(a, "--field-names-for-enums")) {}
        else if (!strcmp(a, "--max-cluster-size")) {}
        else if (!strcmp(a, "--impl-debug")) o.impl_debug = true;
        else if (!strcmp(a, "--impl-debug-feature") || !strcmp(a, "--impl-defmt")) (void)needarg(&i, argc, argv);
        else if (!strcmp(a, "-m") || !strcmp(a, "--make-mod")) o.make_mod = true;
        else if (!strcmp(a, "--skip-crate-attributes")) o.skip_attrs = true;
        else if (!strcmp(a, "-s") || !strcmp(a, "--strict")) o.strict = true;
        else if (!strcmp(a, "--source-type")) o.source_type = needarg(&i, argc, argv);
        else if (!strcmp(a, "--reexport-core-peripherals")) o.reexport_core = true;
        else if (!strcmp(a, "--reexport-interrupt")) o.reexport_interrupt = true;
        else if (!strcmp(a, "-b") || !strcmp(a, "--base-address-shift")) (void)needarg(&i, argc, argv);
        else if (!strcmp(a, "-l") || !strcmp(a, "--log")) o.log_level = needarg(&i, argc, argv);
        else { fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable [OPTIONS]\n\nFor more information, try '--help'.\n", a); return 2; }
    }
    if (o.edition && strcmp(o.edition, "2021") && strcmp(o.edition, "2024")) {
        fprintf(stderr, "[ERROR svd2rust] Failed to deserialize value\n    \n    Caused by:\n        unknown variant `%s`, expected `2021` or `2024`\n", o.edition); return 1;
    }
    if (o.source_type && strcmp(o.source_type, "xml") && strcmp(o.source_type, "yaml") && strcmp(o.source_type, "json")) {
        fprintf(stderr, "[ERROR svd2rust] Failed to deserialize value\n    \n    Caused by:\n        unknown variant `%s`, expected one of `xml`, `yaml`, `json`\n", o.source_type); return 1;
    }
    if (strcmp(o.log_level, "off")) fprintf(stderr, "[INFO  svd2rust] Parsing device from SVD file\n");
    char *xml = o.input ? read_file(o.input) : read_all(stdin);
    if (!strstr(xml, "<device")) {
        fprintf(stderr, "[ERROR svd2rust] Error parsing SVD XML file\n    \n    Caused by:\n        the document does not have a root node\n"); return 1;
    }
    Device d = parse_device(xml);
    if (strcmp(o.log_level, "off")) fprintf(stderr, "[INFO  svd2rust] Rendering device\n");
    write_rust(o.outdir, &o, &d);
    return 0;
}
