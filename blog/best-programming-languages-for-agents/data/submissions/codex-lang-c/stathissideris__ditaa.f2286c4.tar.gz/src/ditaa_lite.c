#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>

typedef struct { unsigned char r,g,b,a; } Color;
typedef struct {
    char **line;
    int rows, cols;
} Diagram;
typedef struct {
    double scale;
    int tabs, svg, html, overwrite, shadows, transparent, debug, round;
    Color bg;
    const char *font_url;
    const char *input;
    const char *output;
} Options;

static const char *HELP =
"usage: java -jar ditaa.jar <INPFILE> [OUTFILE] [-A] [-b <BACKGROUND>] [-d]\n"
"       [-E] [-e <ENCODING>] [-h] [--help] [-o] [-r] [-S] [-s <SCALE>]\n"
"       [--svg] [--svg-font-url <FONT>] [-T] [-t <TABS>] [-v] [-W]\n"
" -A,--no-antialias              Turns anti-aliasing off.\n"
" -b,--background <BACKGROUND>   The background colour of the image. The\n"
"                                format should be a six-digit hexadecimal\n"
"                                number (as in HTML, FF0000 for red). Pass\n"
"                                an eight-digit hex to define transparency.\n"
"                                This is overridden by --transparent.\n"
" -d,--debug                     Renders the debug grid over the resulting\n"
"                                image.\n"
" -E,--no-separation             Prevents the separation of common edges of\n"
"                                shapes.\n"
" -e,--encoding <ENCODING>       The encoding of the input file.\n"
" -h,--html                      In this case the input is an HTML file.\n"
"                                The contents of the <pre\n"
"                                class=\"textdiagram\"> tags are rendered as\n"
"                                diagrams and saved in the images directory\n"
"                                and a new HTML file is produced with the\n"
"                                appropriate <img> tags.\n"
"    --help                      Prints usage help.\n"
" -o,--overwrite                 If the filename of the destination image\n"
"                                already exists, an alternative name is\n"
"                                chosen. If the overwrite option is\n"
"                                selected, the image file is instead\n"
"                                overwriten.\n"
" -r,--round-corners             Causes all corners to be rendered as round\n"
"                                corners.\n"
" -S,--no-shadows                Turns off the drop-shadow effect.\n"
" -s,--scale <SCALE>             A natural number that determines the size\n"
"                                of the rendered image. The units are\n"
"                                fractions of the default size (2.5 renders\n"
"                                1.5 times bigger than the default).\n"
"    --svg                       Write an SVG image as destination file.\n"
"    --svg-font-url <FONT>       SVG font URL.\n"
" -T,--transparent               Causes the diagram to be rendered on a\n"
"                                transparent background. Overrides\n"
"                                --background.\n"
" -t,--tabs <TABS>               Tabs are normally interpreted as 8 spaces\n"
"                                but it is possible to change that using\n"
"                                this option. It is not advisable to use\n"
"                                tabs in your diagrams.\n"
" -v,--verbose                   Makes ditaa more verbose.\n"
" -W,--fixed-slope               Makes sides of parallelograms and\n"
"                                trapezoids fixed slope instead of fixed\n"
"                                width.\n";

static void *xmalloc(size_t n){ void *p=malloc(n?n:1); if(!p){perror("malloc"); exit(1);} return p; }
static char *xstrdup(const char *s){ size_t n=strlen(s)+1; char *p=xmalloc(n); memcpy(p,s,n); return p; }
static int is_line_char(char c){ return c=='-'||c=='='||c=='|'||c==':'||c=='+'||c=='/'||c=='\\'||c=='<'||c=='>'||c=='^'||c=='v'||c=='*'; }
static char ch_at(const Diagram *d,int r,int c){ if(r<0||r>=d->rows||c<0||c>=d->cols) return ' '; int n=(int)strlen(d->line[r]); return c<n?d->line[r][c]:' '; }
static int sx(double v,double s){ return (int)floor(v*s+0.00001); }
static int img_w(const Diagram *d,const Options *o){ return sx(d->cols*10.0+40.0,o->scale); }
static int img_h(const Diagram *d,const Options *o){ return sx(d->rows*14.0+56.0,o->scale); }
static double x_of(int c){ return 25.0+c*10.0; }
static double y_of(int r){ return 35.0+r*14.0; }

static int parse_hex(const char *s, Color *c){
    size_t n=strlen(s); if(n!=6 && n!=8) return 0;
    unsigned v=0; for(size_t i=0;i<n;i++){ if(!isxdigit((unsigned char)s[i])) return 0; v=(v<<4)|(unsigned)(isdigit((unsigned char)s[i])?s[i]-'0':tolower((unsigned char)s[i])-'a'+10); }
    if(n==6){ c->r=(v>>16)&255; c->g=(v>>8)&255; c->b=v&255; c->a=255; }
    else { c->r=(v>>24)&255; c->g=(v>>16)&255; c->b=(v>>8)&255; c->a=v&255; }
    return 1;
}
static const char *color_name(Color c, char *buf){ sprintf(buf,"#%02x%02x%02x",c.r,c.g,c.b); return buf; }
static Color code_color(const Diagram *d,int r1,int c1,int r2,int c2){
    struct { const char *k; Color c; } map[]={{"cRED",{255,170,170,255}},{"cGRE",{170,255,170,255}},{"cBLU",{170,170,255,255}},{"cPNK",{255,170,255,255}},{"cYEL",{255,255,170,255}},{"cBLK",{0,0,0,255}}};
    for(int r=r1;r<=r2;r++) for(int c=c1;c+3<=c2;c++){
        char b[5]={ch_at(d,r,c),ch_at(d,r,c+1),ch_at(d,r,c+2),ch_at(d,r,c+3),0};
        for(size_t i=0;i<sizeof(map)/sizeof(map[0]);i++) if(strcmp(b,map[i].k)==0) return map[i].c;
    }
    return (Color){255,255,255,255};
}
static const char *shape_code(const Diagram *d,int r1,int c1,int r2,int c2){
    static const char *codes[]={"io","mo","tr","d","s","o","c",NULL};
    for(int r=r1;r<=r2;r++) for(int c=c1;c+3<=c2;c++) if(ch_at(d,r,c)=='{'){
        char b[8]={0}; int k=0;
        for(int j=c+1;j<=c2 && j<c+7 && ch_at(d,r,j)!='}';j++) b[k++]=ch_at(d,r,j);
        if(ch_at(d,r,c+1+k)=='}') for(int i=0;codes[i];i++) if(strcmp(b,codes[i])==0) return codes[i];
    }
    return "";
}
static Diagram read_diagram(const char *path,int tabs){
    FILE *f=fopen(path,"rb"); if(!f){ fprintf(stderr,"Could not open input file: %s\n",path); exit(1); }
    Diagram d={0}; char *buf=NULL; size_t cap=0; ssize_t n;
    while((n=getline(&buf,&cap,f))!=-1){
        while(n>0 && (buf[n-1]=='\n'||buf[n-1]=='\r')) buf[--n]=0;
        size_t outcap=(size_t)n*(tabs>0?tabs:8)+1, k=0; char *out=xmalloc(outcap);
        for(ssize_t i=0;i<n;i++) if(buf[i]=='\t'){ int sp=tabs-(int)(k%tabs); while(sp-->0) out[k++]=' '; } else out[k++]=buf[i];
        out[k]=0; d.line=realloc(d.line,(size_t)(d.rows+1)*sizeof(char*)); d.line[d.rows++]=out; if((int)k>d.cols)d.cols=(int)k;
    }
    free(buf); fclose(f); if(d.rows==0){ d.line=xmalloc(sizeof(char*)); d.line[0]=xstrdup(""); d.rows=1; }
    return d;
}
static void free_diagram(Diagram *d){ for(int i=0;i<d->rows;i++) free(d->line[i]); free(d->line); }

typedef struct { int x,y,w,h; const char *shape; Color fill; } Box;
static int box_exists(Box *b,int nb,int x,int y,int w,int h){ for(int i=0;i<nb;i++) if(b[i].x==x&&b[i].y==y&&b[i].w==w&&b[i].h==h) return 1; return 0; }
static Box *find_boxes(const Diagram *d,int *count){
    Box *b=NULL; int nb=0;
    for(int r=0;r<d->rows;r++) for(int c=0;c<d->cols;c++) if(ch_at(d,r,c)=='+'){
        for(int c2=c+2;c2<d->cols;c2++) if(ch_at(d,r,c2)=='+'){
            int ok=1; for(int x=c+1;x<c2;x++){ char ch=ch_at(d,r,x); if(ch!='-'&&ch!='='){ok=0;break;} } if(!ok) continue;
            for(int r2=r+2;r2<d->rows;r2++) if(ch_at(d,r2,c)=='+'&&ch_at(d,r2,c2)=='+'){
                ok=1; for(int x=c+1;x<c2;x++){ char ch=ch_at(d,r2,x); if(ch!='-'&&ch!='='){ok=0;break;} }
                for(int y=r+1;ok&&y<r2;y++){ char l=ch_at(d,y,c), rr=ch_at(d,y,c2); if(!((l=='|'||l==':')&&(rr=='|'||rr==':'))) ok=0; }
                if(ok && !box_exists(b,nb,c,r,c2-c,r2-r)){
                    b=realloc(b,(size_t)(nb+1)*sizeof(Box)); b[nb]=(Box){c,r,c2-c,r2-r,shape_code(d,r,c,r2,c2),code_color(d,r,c,r2,c2)}; nb++;
                }
                break;
            }
            break;
        }
    }
    *count=nb; return b;
}
static int in_any_box_border(Box *b,int nb,int r,int c){
    for(int i=0;i<nb;i++) if(r>=b[i].y&&r<=b[i].y+b[i].h&&c>=b[i].x&&c<=b[i].x+b[i].w)
        if(r==b[i].y||r==b[i].y+b[i].h||c==b[i].x||c==b[i].x+b[i].w) return 1;
    return 0;
}

static void esc(FILE *f,const char *s){
    for(;*s;s++){ if(*s=='&') fputs("&amp;",f); else if(*s=='<') fputs("&lt;",f); else if(*s=='>') fputs("&gt;",f); else fputc(*s,f); }
}
static void svg_path(FILE *f,const Options *o,const char *stroke,Color fill,const char *d,const char *extra){
    char cb[16]; fprintf(f,"    <path stroke='%s' stroke-width='%.1f' stroke-linecap='round' stroke-linejoin='round' fill='%s' d='%s'%s />\n",stroke,1.0*o->scale, fill.a?color_name(fill,cb):"none", d, extra?extra:"");
}
static void render_svg(const Diagram *d,const Options *o,const char *out){
    FILE *f=fopen(out,"wb"); if(!f){ perror(out); exit(1); }
    int w=img_w(d,o), h=img_h(d,o), nb=0; Box *boxes=find_boxes(d,&nb); char cb[16];
    fprintf(f,"<?xml version='1.0' encoding='UTF-8' standalone='no'?>\n<svg \n    xmlns='http://www.w3.org/2000/svg'\n    width='%d'\n    height='%d'\n    shape-rendering='geometricPrecision'\n    version='1.0'>\n",w,h);
    if(o->font_url) fprintf(f,"  <defs><style>@import url('%s');</style></defs>\n",o->font_url);
    fprintf(f,"  <g stroke-width='1' stroke-linecap='square' stroke-linejoin='round'>\n");
    if(!o->transparent) fprintf(f,"    <rect x='0' y='0' width='%d' height='%d' style='fill: %s'/>\n",w,h,color_name(o->bg,cb));
    for(int i=0;i<nb;i++){
        double x1=x_of(boxes[i].x)*o->scale,y1=y_of(boxes[i].y)*o->scale,x2=x_of(boxes[i].x+boxes[i].w)*o->scale,y2=y_of(boxes[i].y+boxes[i].h)*o->scale;
        char path[512]; const char *sh=boxes[i].shape;
        if(strcmp(sh,"c")==0) snprintf(path,sizeof(path),"M%.1f %.1f L%.1f %.1f L%.1f %.1f L%.1f %.1f z",(x1+x2)/2,y1,x2,(y1+y2)/2,(x1+x2)/2,y2,x1,(y1+y2)/2);
        else if(strcmp(sh,"io")==0) snprintf(path,sizeof(path),"M%.1f %.1f L%.1f %.1f L%.1f %.1f L%.1f %.1f z",x1+10*o->scale,y1,x2,y1,x2-10*o->scale,y2,x1,y2);
        else if(strcmp(sh,"tr")==0) snprintf(path,sizeof(path),"M%.1f %.1f L%.1f %.1f L%.1f %.1f L%.1f %.1f z",x1+8*o->scale,y1,x2-8*o->scale,y1,x2,y2,x1,y2);
        else if(strcmp(sh,"o")==0){ fprintf(f,"    <ellipse cx='%.1f' cy='%.1f' rx='%.1f' ry='%.1f' stroke='#000000' fill='%s'/>\n",(x1+x2)/2,(y1+y2)/2,(x2-x1)/2,(y2-y1)/2,color_name(boxes[i].fill,cb)); continue; }
        else snprintf(path,sizeof(path),"M%.1f %.1f L%.1f %.1f L%.1f %.1f L%.1f %.1f z",x1,y1,x1,y2,x2,y2,x2,y1);
        if(o->shadows) fprintf(f,"    <path stroke='gray' fill='gray' d='%s' opacity='0.35' transform='translate(5,5)' />\n",path);
        svg_path(f,o,"#000000",boxes[i].fill,path,"");
    }
    for(int r=0;r<d->rows;r++) for(int c=0;c<d->cols;c++){
        char ch=ch_at(d,r,c); double x=x_of(c)*o->scale,y=y_of(r)*o->scale;
        if((ch=='-'||ch=='=') && !in_any_box_border(boxes,nb,r,c)) fprintf(f,"    <line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='#000000'%s/>\n",x,y,x+10*o->scale,y,ch=='='?" stroke-dasharray='4,4'":"");
        else if((ch=='|'||ch==':') && !in_any_box_border(boxes,nb,r,c)) fprintf(f,"    <line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='#000000'%s/>\n",x,y,x,y+14*o->scale,ch==':'?" stroke-dasharray='4,4'":"");
        else if(ch=='/'||ch=='\\') fprintf(f,"    <line x1='%.1f' y1='%.1f' x2='%.1f' y2='%.1f' stroke='#000000'/>\n",x,y+(ch=='/'?14:0)*o->scale,x+10*o->scale,y+(ch=='/'?0:14)*o->scale);
        else if(ch=='>'||ch=='<'||ch=='^'||ch=='v'||ch=='*') fprintf(f,"    <circle cx='%.1f' cy='%.1f' r='%.1f' fill='#000000'/>\n",x,y,2.5*o->scale);
    }
    for(int r=0;r<d->rows;r++){
        int c=0; while(c<d->cols){ while(c<d->cols && (ch_at(d,r,c)==' '||is_line_char(ch_at(d,r,c)))) c++; int start=c; while(c<d->cols && !is_line_char(ch_at(d,r,c))) c++; int end=c; while(end>start && ch_at(d,r,end-1)==' ') end--; if(end>start){
            char *txt=xmalloc((size_t)(end-start+1)); for(int i=start;i<end;i++) txt[i-start]=ch_at(d,r,i); txt[end-start]=0;
            if(txt[0]=='{' || !strncmp(txt,"cRED",4)||!strncmp(txt,"cGRE",4)||!strncmp(txt,"cBLU",4)||!strncmp(txt,"cPNK",4)||!strncmp(txt,"cYEL",4)||!strncmp(txt,"cBLK",4)){ free(txt); continue; }
            fprintf(f,"    <text x='%d' y='%d' font-family='Courier' font-size='%d' stroke='none' fill='#000000' >",sx(x_of(start)*o->scale-3*o->scale,o->scale/o->scale),sx(y_of(r)*o->scale+5*o->scale,o->scale/o->scale),sx(15,o->scale)); esc(f,txt); fputs("</text>\n",f); free(txt);
        }}
    }
    if(o->debug){ for(int r=0;r<d->rows;r++) fprintf(f,"    <line x1='0' y1='%.1f' x2='%d' y2='%.1f' stroke='#dddddd'/>\n",y_of(r)*o->scale,w,y_of(r)*o->scale); }
    fputs("  </g>\n</svg>\n",f); fclose(f); free(boxes);
}

typedef struct { int w,h; unsigned char *p; } Img;
static void pix(Img *im,int x,int y,Color c){ if(x<0||y<0||x>=im->w||y>=im->h)return; unsigned char *p=im->p+4*((size_t)y*im->w+x); p[0]=c.r;p[1]=c.g;p[2]=c.b;p[3]=c.a; }
static void rect(Img *im,int x1,int y1,int x2,int y2,Color c){ if(x1>x2){int t=x1;x1=x2;x2=t;} if(y1>y2){int t=y1;y1=y2;y2=t;} for(int y=y1;y<=y2;y++) for(int x=x1;x<=x2;x++) pix(im,x,y,c); }
static void line(Img *im,int x0,int y0,int x1,int y1,Color c){ int dx=abs(x1-x0), sxn=x0<x1?1:-1, dy=-abs(y1-y0), syn=y0<y1?1:-1, err=dx+dy; for(;;){ for(int yy=-1;yy<=1;yy++) for(int xx=-1;xx<=1;xx++) pix(im,x0+xx,y0+yy,c); if(x0==x1&&y0==y1)break; int e2=2*err; if(e2>=dy){err+=dy;x0+=sxn;} if(e2<=dx){err+=dx;y0+=syn;} } }
static void glyph(Img *im,int x,int y,int sc,unsigned char ch,Color c){
    if(ch==' ') return;
    unsigned int seed=(unsigned int)ch*1103515245u+12345u;
    for(int yy=0;yy<7;yy++) for(int xx=0;xx<5;xx++){
        int on = yy==0 || yy==6 || xx==0 || xx==4 || ((seed >> ((xx+yy*3)&15)) & 1);
        if(on) rect(im,x+xx*sc,y+yy*sc,x+(xx+1)*sc-1,y+(yy+1)*sc-1,c);
    }
}
static void png_text(Img *im,const Diagram *d,double scale){
    Color black={0,0,0,255}; int sc=(int)floor(scale+0.5); if(sc<1) sc=1;
    for(int r=0;r<d->rows;r++){
        int c=0; while(c<d->cols){ while(c<d->cols && (ch_at(d,r,c)==' '||is_line_char(ch_at(d,r,c)))) c++; int start=c; while(c<d->cols && !is_line_char(ch_at(d,r,c))) c++; int end=c; while(end>start && ch_at(d,r,end-1)==' ') end--; if(end>start){
            char buf[8]={0}; for(int i=0;i<4 && start+i<end;i++) buf[i]=ch_at(d,r,start+i);
            if(buf[0]=='{' || !strncmp(buf,"cRED",4)||!strncmp(buf,"cGRE",4)||!strncmp(buf,"cBLU",4)||!strncmp(buf,"cPNK",4)||!strncmp(buf,"cYEL",4)||!strncmp(buf,"cBLK",4)) continue;
            int x=sx(x_of(start)-3,scale), y=sx(y_of(r)-8,scale);
            for(int i=start;i<end;i++) glyph(im,x+(i-start)*sx(8,scale),y,sc,(unsigned char)ch_at(d,r,i),black);
        }}
    }
}
static void crc_table(uint32_t t[256]){ for(uint32_t n=0;n<256;n++){ uint32_t c=n; for(int k=0;k<8;k++) c=(c&1)?0xedb88320U^(c>>1):c>>1; t[n]=c; } }
static uint32_t crc32b(const unsigned char *buf,size_t len){ static uint32_t tab[256]; static int init=0; if(!init){crc_table(tab);init=1;} uint32_t c=0xffffffffU; for(size_t i=0;i<len;i++) c=tab[(c^buf[i])&255]^(c>>8); return c^0xffffffffU; }
static void be32(FILE *f,uint32_t v){ fputc((v>>24)&255,f);fputc((v>>16)&255,f);fputc((v>>8)&255,f);fputc(v&255,f); }
static void chunk(FILE *f,const char type[4],const unsigned char *data,uint32_t len){ be32(f,len); fwrite(type,1,4,f); if(len)fwrite(data,1,len,f); unsigned char *tmp=xmalloc(len+4); memcpy(tmp,type,4); if(len)memcpy(tmp+4,data,len); be32(f,crc32b(tmp,len+4)); free(tmp); }
static void render_png(const Diagram *d,const Options *o,const char *out){
    Img im={img_w(d,o),img_h(d,o),NULL}; im.p=xmalloc((size_t)im.w*im.h*4); Color black={0,0,0,255}; for(int y=0;y<im.h;y++) for(int x=0;x<im.w;x++) pix(&im,x,y,o->transparent?(Color){255,255,255,0}:o->bg);
    int nb=0; Box *boxes=find_boxes(d,&nb);
    for(int i=0;i<nb;i++){ int x1=sx(x_of(boxes[i].x),o->scale), y1=sx(y_of(boxes[i].y),o->scale), x2=sx(x_of(boxes[i].x+boxes[i].w),o->scale), y2=sx(y_of(boxes[i].y+boxes[i].h),o->scale); rect(&im,x1,y1,x2,y2,boxes[i].fill); line(&im,x1,y1,x2,y1,black); line(&im,x2,y1,x2,y2,black); line(&im,x2,y2,x1,y2,black); line(&im,x1,y2,x1,y1,black); }
    for(int r=0;r<d->rows;r++) for(int c=0;c<d->cols;c++){ char ch=ch_at(d,r,c); if(in_any_box_border(boxes,nb,r,c)) continue; int x=sx(x_of(c),o->scale), y=sx(y_of(r),o->scale); if(ch=='-'||ch=='=') line(&im,x,y,x+sx(10,o->scale),y,black); else if(ch=='|'||ch==':') line(&im,x,y,x,y+sx(14,o->scale),black); else if(ch=='/'||ch=='\\') line(&im,x,y+(ch=='/'?sx(14,o->scale):0),x+sx(10,o->scale),y+(ch=='/'?0:sx(14,o->scale)),black); else if(ch=='>'||ch=='<'||ch=='^'||ch=='v'||ch=='*') rect(&im,x-2,y-2,x+2,y+2,black); }
    png_text(&im,d,o->scale);
    size_t rawrow=(size_t)im.w*4+1, rawlen=rawrow*im.h; unsigned char *raw=xmalloc(rawlen); for(int y=0;y<im.h;y++){ raw[y*rawrow]=0; memcpy(raw+y*rawrow+1,im.p+(size_t)y*im.w*4,(size_t)im.w*4); }
    size_t max=2+rawlen+5*((rawlen+65534)/65535)+4, pos=0; unsigned char *z=xmalloc(max); z[pos++]=0x78; z[pos++]=0x01; size_t off=0; while(off<rawlen){ unsigned len=(rawlen-off>65535)?65535:(unsigned)(rawlen-off); int final=(off+len==rawlen); z[pos++]=final; z[pos++]=len&255; z[pos++]=(len>>8)&255; unsigned nlen=~len; z[pos++]=nlen&255; z[pos++]=(nlen>>8)&255; memcpy(z+pos,raw+off,len); pos+=len; off+=len; }
    uint32_t a=1,b=0; for(size_t i=0;i<rawlen;i++){ a=(a+raw[i])%65521; b=(b+a)%65521; } z[pos++]=(b>>8)&255; z[pos++]=b&255; z[pos++]=(a>>8)&255; z[pos++]=a&255;
    FILE *f=fopen(out,"wb"); if(!f){perror(out);exit(1);} static const unsigned char sig[8]={137,80,78,71,13,10,26,10}; fwrite(sig,1,8,f); unsigned char ihdr[13]={im.w>>24,im.w>>16,im.w>>8,im.w,im.h>>24,im.h>>16,im.h>>8,im.h,8,6,0,0,0}; chunk(f,"IHDR",ihdr,13); chunk(f,"IDAT",z,(uint32_t)pos); chunk(f,"IEND",NULL,0); fclose(f);
    free(z); free(raw); free(im.p); free(boxes);
}
static char *default_output(const char *in,int svg){
    char *s=xstrdup(in); char *slash=strrchr(s,'/'); char *dot=strrchr(slash?slash:s,'.'); if(dot) *dot=0; s=realloc(s,strlen(s)+5); strcat(s,svg?".svg":".png"); return s;
}
static char *next_name(const char *path){
    struct stat st; if(stat(path,&st)!=0) return xstrdup(path);
    const char *dot=strrchr(path,'.'); size_t base=dot?(size_t)(dot-path):strlen(path); const char *ext=dot?dot:""; for(int i=2;;i++){ char b[4096]; snprintf(b,sizeof(b),"%.*s_%d%s",(int)base,path,i,ext); if(stat(b,&st)!=0) return xstrdup(b); }
}
static void render_one(const Options *o,const char *in,const char *out){
    Diagram d=read_diagram(in,o->tabs); if(o->svg) render_svg(&d,o,out); else render_png(&d,o,out); free_diagram(&d);
}
static void html_mode(const Options *o){
    FILE *f=fopen(o->input,"rb"); if(!f){perror(o->input);exit(1);} fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET); char *buf=xmalloc((size_t)n+1); fread(buf,1,(size_t)n,f); buf[n]=0; fclose(f);
    char *outpath=o->output?xstrdup(o->output):default_output(o->input,0); FILE *out=fopen(outpath,"wb"); if(!out){perror(outpath);exit(1);} char *p=buf; int idx=1; mkdir("images",0777);
    while(1){ char *pre=strstr(p,"<pre"); if(!pre){ fputs(p,out); break; } char *gt=strchr(pre,'>'); if(!gt || !strstr(pre,"textdiagram") || strstr(pre,"textdiagram")>gt){ fwrite(p,1,(size_t)(gt?gt+1-p:strlen(p)),out); p=gt?gt+1:p+strlen(p); continue; } char *end=strstr(gt+1,"</pre>"); if(!end){ fputs(p,out); break; } fwrite(p,1,(size_t)(pre-p),out); char name[256]; snprintf(name,sizeof(name),"ditaa_diagram_%d.%s",idx++,o->svg?"svg":"png"); char *id=strstr(pre,"id="); if(id&&id<gt){ char q=id[3]; if(q=='\"'||q=='\''){ char *e=strchr(id+4,q); if(e&&e<gt) snprintf(name,sizeof(name),"%.*s.%s",(int)(e-id-4),id+4,o->svg?"svg":"png"); }} char full[512]; snprintf(full,sizeof(full),"images/%s",name); char tmp[]="/tmp/ditaa_html_XXXXXX"; int fd=mkstemp(tmp); FILE *tf=fdopen(fd,"wb"); fwrite(gt+1,1,(size_t)(end-gt-1),tf); fclose(tf); render_one(o,tmp,full); remove(tmp); fprintf(out,"<img src=\"images/%s\" />",name); p=end+6; }
    fclose(out); free(outpath); free(buf);
}
int main(int argc,char **argv){
    Options o={0}; o.scale=1.0; o.tabs=8; o.shadows=1; o.bg=(Color){255,255,255,255};
    if(argc==1){ fputs(HELP,stdout); return 0; }
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"--help")){ fputs(HELP,stdout); return 0; }
        else if(!strcmp(a,"-A")||!strcmp(a,"--no-antialias")||!strcmp(a,"-E")||!strcmp(a,"--no-separation")||!strcmp(a,"-v")||!strcmp(a,"--verbose")||!strcmp(a,"-W")||!strcmp(a,"--fixed-slope")){}
        else if(!strcmp(a,"-d")||!strcmp(a,"--debug")) o.debug=1;
        else if(!strcmp(a,"-r")||!strcmp(a,"--round-corners")) o.round=1;
        else if(!strcmp(a,"-S")||!strcmp(a,"--no-shadows")) o.shadows=0;
        else if(!strcmp(a,"--svg")) o.svg=1;
        else if(!strcmp(a,"-h")||!strcmp(a,"--html")) o.html=1;
        else if(!strcmp(a,"-o")||!strcmp(a,"--overwrite")) o.overwrite=1;
        else if(!strcmp(a,"-T")||!strcmp(a,"--transparent")) o.transparent=1;
        else if(!strcmp(a,"-s")||!strcmp(a,"--scale")){ if(++i>=argc){ fprintf(stderr,"Missing argument for option: s\n%s",HELP); return 2;} o.scale=atof(argv[i]); if(o.scale<=0)o.scale=1; }
        else if(!strcmp(a,"-t")||!strcmp(a,"--tabs")){ if(++i>=argc){ fprintf(stderr,"Missing argument for option: t\n%s",HELP); return 2;} o.tabs=atoi(argv[i]); if(o.tabs<=0)o.tabs=8; }
        else if(!strcmp(a,"-b")||!strcmp(a,"--background")){ if(++i>=argc){ fprintf(stderr,"Missing argument for option: b\n%s",HELP); return 2;} if(!parse_hex(argv[i],&o.bg)){ fprintf(stderr,"Invalid background colour: %s\n",argv[i]); return 1; } }
        else if(!strcmp(a,"-e")||!strcmp(a,"--encoding")){ if(++i>=argc){ fprintf(stderr,"Missing argument for option: e\n%s",HELP); return 2;} }
        else if(!strcmp(a,"--svg-font-url")){ if(++i>=argc){ fprintf(stderr,"Missing argument for option: svg-font-url\n%s",HELP); return 2;} o.font_url=argv[i]; }
        else if(a[0]=='-'){ fprintf(stderr,"Unrecognized option: %s\n%s",a,HELP); return 2; }
        else if(!o.input) o.input=a; else if(!o.output) o.output=a; else { fprintf(stderr,"Too many arguments\n%s",HELP); return 2; }
    }
    if(!o.input){ fputs(HELP,stdout); return 0; }
    if(o.html){ html_mode(&o); return 0; }
    char *def=NULL,*out=NULL; if(!o.output) o.output=def=default_output(o.input,o.svg); out=o.overwrite?xstrdup(o.output):next_name(o.output);
    printf("\nditaa version 0.11, Copyright (C) 2004--2017  Efstathios (Stathis) Sideris\n\nRunning with options:\nReading file: %s\nRendering to file: %s\n",o.input,out);
    render_one(&o,o.input,out); puts("Done in 0sec"); free(def); free(out); return 0;
}
