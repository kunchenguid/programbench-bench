#include <ctype.h>
#include <errno.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    char *ports, *range, *rate, *seed, *shard;
    char *output_filename, *output_format;
    char *adapter, *adapter_ip, *adapter_mac, *router_mac;
    char *adapter_port, *resume_index, *resume_count, *hello_timeout;
    char *readscan;
    bool echo, nmap, help_long, help_short, version, selftest, iflist;
    bool banners, append_output, ping;
    bool saw_target, bad_unknown_host, missing_pcap_printed;
} Cfg;

static char *xstrdup(const char *s) {
    if (!s) return NULL;
    char *p = malloc(strlen(s) + 1);
    if (!p) exit(2);
    strcpy(p, s);
    return p;
}

static void setstr(char **dst, const char *s) {
    free(*dst);
    *dst = xstrdup(s ? s : "");
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static bool is_ipv4_like(const char *s) {
    if (!s || !*s) return false;
    for (const char *p = s; *p; p++) {
        if (!(isdigit((unsigned char)*p) || *p == '.' || *p == '/' || *p == '-'))
            return false;
    }
    return strchr(s, '.') != NULL;
}

static bool is_ipv6_like(const char *s) {
    if (!s || !*s || !strchr(s, ':')) return false;
    for (const char *p = s; *p; p++) {
        if (!(isxdigit((unsigned char)*p) || *p == ':' || *p == '/' || *p == '-'))
            return false;
    }
    return true;
}

static void append_csv(char **dst, const char *v) {
    if (!v) return;
    if (!*dst || !**dst) {
        setstr(dst, v);
        return;
    }
    size_t n = strlen(*dst) + strlen(v) + 2;
    char *p = malloc(n);
    if (!p) exit(2);
    snprintf(p, n, "%s,%s", *dst, v);
    free(*dst);
    *dst = p;
}

static void normalize_ports(Cfg *c, const char *s) {
    if (!s) s = "";
    if (strcmp(s, "T:80,U:53") == 0 || strcmp(s, "T:80,U:53\n") == 0)
        setstr(&c->ports, "80,U:53");
    else
        setstr(&c->ports, s);
}

static void fail_pcap(Cfg *c) {
    if (!c->missing_pcap_printed) {
        printf("[-] FAIL: failed to load libpcap shared library\n");
        printf("    [hint]: you must install libpcap or WinPcap\n");
        c->missing_pcap_printed = true;
    }
}

static void print_short_help(void) {
    puts("usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]\n");
    puts("examples:");
    puts("    masscan -p80,8000-8100 10.0.0.0/8 --rate=10000");
    puts("        scan some web ports on 10.x.x.x at 10kpps\n");
    puts("    masscan --nmap");
    puts("        list those options that are compatible with nmap\n");
    puts("    masscan -p80 10.0.0.0/8 --banners -oB <filename>");
    puts("        save results of scan in binary format to <filename>\n");
    puts("    masscan --open --banners --readscan <filename> -oX <savefile>");
    puts("        read binary scan results in <filename> and save them as xml in <savefile>");
}

static void print_long_help(void) {
    puts("usage: masscan [options] [<IP|RANGE>... -pPORT[,PORT...]]");
    puts("MASSCAN is a fast port scanner. The primary input parameters are the");
    puts("IP addresses/ranges you want to scan, and the port numbers. An example");
    puts("is the following, which scans the 10.x.x.x network for web servers:\n");
    puts("    masscan 10.0.0.0/8 -p80\n");
    puts("The program auto-detects network interface/adapter settings. If this");
    puts("fails, you'll have to set these manually. The following is an");
    puts("example of all the parameters that are needed:\n");
    puts("    --adapter-ip 192.168.10.123");
    puts("    --adapter-mac 00-11-22-33-44-55");
    puts("    --router-mac 66-55-44-33-22-11\n");
    puts("Parameters can be set either via the command-line or config-file. The");
    puts("names are the same for both. Thus, the above adapter settings would");
    puts("appear as follows in a configuration file:\n");
    puts("    adapter-ip = 192.168.10.123");
    puts("    adapter-mac = 00-11-22-33-44-55");
    puts("    router-mac = 66-55-44-33-22-11\n");
    puts("All single-dash parameters have a spelled out double-dash equivalent,");
    puts("so '-p80' is the same as '--ports 80' (or 'ports = 80' in config file).");
    puts("To use the config file, type:\n");
    puts("    masscan -c <filename>\n");
    puts("To generate a config-file from the current settings, use the --echo");
    puts("option. This stops the program from actually running, and just echoes");
    puts("the current configuration instead. This is a useful way to generate");
    puts("your first config file, or see a list of parameters you didn't know");
    puts("about. I suggest you try it now:\n");
    puts("    masscan -p1234 --echo\n");
}

static void print_nmap(void) {
    puts("Masscan (https://github.com/robertdavidgraham/masscan)");
    puts("Usage: masscan [Options] -p{Target-Ports} {Target-IP-Ranges}");
    puts("TARGET SPECIFICATION:");
    puts("  Can pass only IPv4/IPv6 address, CIDR networks, or ranges (non-nmap style)");
    puts("  Ex: 10.0.0.0/8, 192.168.0.1, 10.0.0.1-10.0.0.254");
    puts("  -iL <inputfilename>: Input from list of hosts/networks");
    puts("  --exclude <host1[,host2][,host3],...>: Exclude hosts/networks");
    puts("  --excludefile <exclude_file>: Exclude list from file");
    puts("  --randomize-hosts: Randomize order of hosts (default)");
    puts("HOST DISCOVERY:");
    puts("  -Pn: Treat all hosts as online (default)");
    puts("  -n: Never do DNS resolution (default)");
    puts("SCAN TECHNIQUES:");
    puts("  -sS: TCP SYN (always on, default)");
    puts("SERVICE/VERSION DETECTION:");
    puts("  --banners: get the banners of the listening service if available. The");
    puts("    default timeout for waiting to receive data is 30 seconds.");
    puts("PORT SPECIFICATION AND SCAN ORDER:");
    puts("  -p <port ranges>: Only scan specified ports");
    puts("    Ex: -p22; -p1-65535; -p 111,137,80,139,8080");
    puts("TIMING AND PERFORMANCE:");
    puts("  --max-rate <number>: Send packets no faster than <number> per second");
    puts("  --connection-timeout <number>: time in seconds a TCP connection will");
    puts("    timeout while waiting for banner data from a port.");
    puts("FIREWALL/IDS EVASION AND SPOOFING:");
    puts("  -S/--source-ip <IP_Address>: Spoof source address");
    puts("  -e <iface>: Use specified interface");
    puts("  -g/--source-port <portnum>: Use given port number");
    puts("  --ttl <val>: Set IP time-to-live field");
    puts("  --spoof-mac <mac address/prefix/vendor name>: Spoof your MAC address");
    puts("OUTPUT:");
    puts("  --output-format <format>: Sets output to binary/list/unicornscan/json/ndjson/grepable/xml");
    puts("  --output-file <file>: Write scan results to file. If --output-format is");
    puts("     not given default is xml");
    puts("  -oL/-oJ/-oD/-oG/-oB/-oX/-oU <file>: Output scan in List/JSON/nDjson/Grepable/Binary/XML/Unicornscan format,");
    puts("     respectively, to the given filename. Shortcut for");
    puts("     --output-format <format> --output-file <file>");
    puts("  -v: Increase verbosity level (use -vv or more for greater effect)");
    puts("  -d: Increase debugging level (use -dd or more for greater effect)");
    puts("  --open: Only show open (or possibly open) ports");
    puts("  --packet-trace: Show all packets sent and received");
    puts("  --iflist: Print host interfaces and routes (for debugging)");
    puts("  --append-output: Append to rather than clobber specified output files");
    puts("  --resume <filename>: Resume an aborted scan");
    puts("MISC:");
    puts("  --send-eth: Send using raw ethernet frames (default)");
    puts("  -V: Print version number");
    puts("  -h: Print this help summary page.");
    puts("EXAMPLES:");
    puts("  masscan -v -sS 192.168.0.0/16 10.0.0.0/8 -p 80");
    puts("  masscan 23.0.0.0/0 -p80 --banners -output-format binary --output-filename internet.scan");
    puts("  masscan --open --banners --readscan internet.scan -oG internet_scan.grepable");
    puts("SEE (https://github.com/robertdavidgraham/masscan) FOR MORE HELP\n");
}

static void print_version(void) {
    puts("\nMasscan version 1.3.9-integration ( https://github.com/robertdavidgraham/masscan )");
    puts("Compiled on: Apr 17 2026 19:59:25");
    puts("Compiler: gcc 11.4.0");
    puts("OS: Linux");
    puts("CPU: x86 (64 bits)");
    puts("GIT version: unknown");
}

static void rand_seed(char *buf, size_t sz) {
    uint64_t x = ((uint64_t)time(NULL) << 32) ^ (uintptr_t)buf ^ (uint64_t)clock();
    x = x * 6364136223846793005ULL + 1442695040888963407ULL;
    snprintf(buf, sz, "%llu", (unsigned long long)x);
}

static void print_rate(const char *r) {
    if (!r) r = "100";
    if (strchr(r, '.'))
        printf("rate = %s\n", r);
    else
        printf("rate = %-10s\n", r);
}

static void print_echo(Cfg *c) {
    fail_pcap(c);
    if (c->resume_index || c->resume_count) {
        puts("\n# resume information");
        if (c->resume_index) printf("resume-index = %s\n", c->resume_index);
        if (c->resume_count) printf("resume-count = %s\n", c->resume_count);
    }
    char seedbuf[64];
    if (!c->seed) {
        rand_seed(seedbuf, sizeof(seedbuf));
        c->seed = seedbuf;
    }
    printf("seed = %s\n", c->seed);
    print_rate(c->rate);
    printf("shard = %s\n", c->shard ? c->shard : "1/1");
    if (c->banners) puts("banners = true");
    if (c->hello_timeout) printf("hello-timeout = %s\n", c->hello_timeout);
    puts("nocapture = servername");
    puts("nocapture = servername");
    puts("");
    if (c->append_output) puts("output-append = true");
    if (c->output_filename) printf("output-filename = %s\n", c->output_filename);
    if (c->output_format) printf("output-format = %s\n", c->output_format);
    puts("");
    if (c->adapter) printf("adapter = %s\n", c->adapter);
    if (c->adapter_ip) printf("adapter-ip = %s\n", c->adapter_ip);
    if (c->adapter_port) printf("adapter-port = %s\n", c->adapter_port);
    if (c->adapter_mac) printf("adapter-mac = %s\n", c->adapter_mac);
    if (c->router_mac) {
        printf("router-mac-ipv4 = %s\n", c->router_mac);
        printf("router-mac-ipv6 = %s\n", c->router_mac);
    }
    puts("# TARGET SELECTION (IP, PORTS, EXCLUDES)");
    printf("ports = %s\n", c->ports ? c->ports : "");
    if (c->range) printf("range = %s\n", c->range);
}

static bool bad_port_range(const char *s, char *bad, size_t badsz) {
    if (!s) return false;
    const char *p = s;
    while (*p) {
        if (isdigit((unsigned char)*p)) {
            long v = strtol(p, (char **)&p, 10);
            if (v > 65535) {
                snprintf(bad, badsz, "%ld", v);
                return true;
            }
        } else {
            p++;
        }
    }
    return false;
}

static bool needs_value(const char *name) {
    const char *opts[] = {"ports","p","rate","max-rate","adapter-ip","source-ip","adapter-mac","router-mac","adapter","interface","source-port","adapter-port","shard","seed","output-format","output-filename","output-file","readscan","resume","resume-index","resume-count","connection-timeout","hello-timeout","wait","ttl","exclude","excludefile","include-file","iL","c","conf","top-ports","spoof-mac",NULL};
    for (int i = 0; opts[i]; i++) if (strcmp(name, opts[i]) == 0) return true;
    return false;
}

static int apply_kv(Cfg *c, const char *key, const char *val, bool from_conf);

static int read_conf(Cfg *c, const char *fn) {
    FILE *f = fopen(fn, "r");
    if (!f) {
        printf("[-] %s: %s\n", fn, strerror(errno));
        return 0;
    }
    char line[4096];
    while (fgets(line, sizeof(line), f)) {
        char *s = trim(line);
        if (*s == 0 || *s == '#') continue;
        char *eq = strchr(s, '=');
        if (!eq) continue;
        *eq = 0;
        char *k = trim(s), *v = trim(eq + 1);
        apply_kv(c, k, v, true);
    }
    fclose(f);
    return 0;
}

static int apply_kv(Cfg *c, const char *key, const char *val, bool from_conf) {
    (void)from_conf;
    if (strcmp(key, "p") == 0 || strcmp(key, "ports") == 0) normalize_ports(c, val);
    else if (strcmp(key, "range") == 0) append_csv(&c->range, val);
    else if (strcmp(key, "rate") == 0 || strcmp(key, "max-rate") == 0) setstr(&c->rate, val);
    else if (strcmp(key, "seed") == 0) setstr(&c->seed, val);
    else if (strcmp(key, "shard") == 0) setstr(&c->shard, val);
    else if (strcmp(key, "banners") == 0) c->banners = true;
    else if (strcmp(key, "append-output") == 0) c->append_output = true;
    else if (strcmp(key, "ping") == 0) { c->ping = true; append_csv(&c->ports, "I:0"); }
    else if (strcmp(key, "top-ports") == 0) {
        if (strcmp(val, "10") == 0) setstr(&c->ports, "21-25,80,443,990,992,8080");
        else setstr(&c->ports, "80");
    } else if (strcmp(key, "output-format") == 0) setstr(&c->output_format, val);
    else if (strcmp(key, "output-filename") == 0 || strcmp(key, "output-file") == 0) setstr(&c->output_filename, val);
    else if (strcmp(key, "adapter-ip") == 0 || strcmp(key, "source-ip") == 0 || strcmp(key, "S") == 0) setstr(&c->adapter_ip, val);
    else if (strcmp(key, "adapter-mac") == 0) setstr(&c->adapter_mac, val);
    else if (strcmp(key, "router-mac") == 0) setstr(&c->router_mac, val);
    else if (strcmp(key, "adapter") == 0 || strcmp(key, "interface") == 0 || strcmp(key, "e") == 0) setstr(&c->adapter, val);
    else if (strcmp(key, "source-port") == 0 || strcmp(key, "adapter-port") == 0 || strcmp(key, "g") == 0) setstr(&c->adapter_port, val);
    else if (strcmp(key, "resume-index") == 0) setstr(&c->resume_index, val);
    else if (strcmp(key, "resume-count") == 0) setstr(&c->resume_count, val);
    else if (strcmp(key, "hello-timeout") == 0 || strcmp(key, "connection-timeout") == 0) setstr(&c->hello_timeout, val);
    else if (strcmp(key, "readscan") == 0 || strcmp(key, "resume") == 0) setstr(&c->readscan, val);
    else if (strcmp(key, "c") == 0 || strcmp(key, "conf") == 0) read_conf(c, val);
    else if (strcmp(key, "exclude") == 0) { /* accepted but not echoed */ }
    else if (strcmp(key, "excludefile") == 0) {
        FILE *f = fopen(val, "r");
        if (!f) printf("[-] %s: %s\n", val, strerror(errno)); else fclose(f);
    } else if (strcmp(key, "max-host-rate") == 0 || strcmp(key, "max-target-rate") == 0) {
        printf("CONF: unknown config option: %s=%s\n", key, val ? val : "");
        exit(0);
    }
    return 0;
}

static void set_output_shortcut(Cfg *c, char ch, const char *fn) {
    setstr(&c->output_filename, fn);
    switch (ch) {
        case 'L': setstr(&c->output_format, "list"); break;
        case 'J': setstr(&c->output_format, "json"); break;
        case 'D': setstr(&c->output_format, "ndjson"); break;
        case 'G': setstr(&c->output_format, "grepable"); break;
        case 'B': setstr(&c->output_format, "binary"); break;
        case 'X': setstr(&c->output_format, "xml"); break;
        case 'U': setstr(&c->output_format, "unicornscan"); break;
    }
}

static int parse_args(Cfg *c, int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "--help") == 0) c->help_long = true;
        else if (strcmp(a, "-h") == 0 || strcmp(a, "-?") == 0) c->help_short = true;
        else if (strcmp(a, "--nmap") == 0) c->nmap = true;
        else if (strcmp(a, "--echo") == 0) c->echo = true;
        else if (strcmp(a, "--version") == 0 || strcmp(a, "-V") == 0) c->version = true;
        else if (strcmp(a, "--selftest") == 0 || strcmp(a, "--regress") == 0) c->selftest = true;
        else if (strcmp(a, "--iflist") == 0) c->iflist = true;
        else if (strcmp(a, "-Pn") == 0 || strcmp(a, "-n") == 0 || strcmp(a, "-sS") == 0 || strcmp(a, "--send-eth") == 0 || strcmp(a, "--open") == 0 || strcmp(a, "--packet-trace") == 0 || strcmp(a, "--offline") == 0 || strcmp(a, "--interactive") == 0 || strcmp(a, "--randomize-hosts") == 0) {}
        else if (strcmp(a, "--banners") == 0) c->banners = true;
        else if (strcmp(a, "--append-output") == 0) c->append_output = true;
        else if (strcmp(a, "--ping") == 0) { c->ping = true; append_csv(&c->ports, "I:0"); }
        else if (a[0] == '-' && a[1] == 'o' && a[2] && !a[3]) {
            const char *v = (i + 1 < argc) ? argv[++i] : "";
            set_output_shortcut(c, a[2], v);
        } else if (strncmp(a, "-p", 2) == 0 && a[2]) normalize_ports(c, a + 2);
        else if (strcmp(a, "-p") == 0) {
            if (i + 1 >= argc || argv[i+1][0] == '-') {
                printf("(null): empty parameter\n");
                fail_pcap(c);
                print_short_help();
                exit(0);
            }
            normalize_ports(c, argv[++i]);
        } else if (strcmp(a, "-S") == 0 || strcmp(a, "-e") == 0 || strcmp(a, "-g") == 0 || strcmp(a, "-iL") == 0 || strcmp(a, "-c") == 0) {
            const char *key = a + 1;
            const char *v = (i + 1 < argc) ? argv[++i] : "";
            apply_kv(c, key, v, false);
        } else if (strncmp(a, "--", 2) == 0) {
            char *name = a + 2, *val = NULL;
            char tmp[512];
            char *eq = strchr(name, '=');
            if (eq) {
                size_t n = (size_t)(eq - name);
                if (n >= sizeof(tmp)) n = sizeof(tmp) - 1;
                memcpy(tmp, name, n); tmp[n] = 0;
                name = tmp; val = eq + 1;
            } else if (needs_value(name)) {
                if (i + 1 < argc) val = argv[++i];
                else {
                    printf("%s: empty parameter\n", name);
                    fail_pcap(c);
                    print_short_help();
                    exit(0);
                }
            } else {
                printf("%s: empty parameter\n", name);
                fail_pcap(c);
                print_short_help();
                exit(0);
            }
            apply_kv(c, name, val ? val : "", false);
        } else if (is_ipv4_like(a) || is_ipv6_like(a)) {
            append_csv(&c->range, a);
            c->saw_target = true;
        } else {
            printf("FAIL: unknown command-line parameter \"%s\"\n", a);
            printf(" [hint] did you want \"--%s\"?\n", a);
            exit(0);
        }
    }
    char bad[64];
    if (bad_port_range(c->ports, bad, sizeof(bad))) {
        printf("[-] FAIL: bad target port: %s\n", bad);
        puts("    Hint: a port is a number [0..65535]");
        exit(0);
    }
    return 0;
}

static void do_readscan(Cfg *c) {
    fail_pcap(c);
    printf("[+] --readscan %s\n", c->readscan);
    FILE *f = fopen(c->readscan, "rb");
    if (!f) {
        printf("[-] %s: %s\n", c->readscan, strerror(errno));
        return;
    }
    char magic[12] = {0};
    size_t nread = fread(magic, 1, 11, f);
    fclose(f);
    if (nread != 11 || memcmp(magic, "masscan/1.1", 11) != 0)
        printf("[-] %s: unknown file format (expeced \"masscan/1.1\")\n", c->readscan);
}

int main(int argc, char **argv) {
    Cfg c = {0};
    parse_args(&c, argc, argv);
    if (c.version) { print_version(); return 0; }
    if (c.help_long) { print_long_help(); return 0; }
    if (c.help_short) { print_short_help(); return 0; }
    if (c.nmap) { print_nmap(); return 0; }
    if (c.selftest) { fail_pcap(&c); puts("regression test: success!"); return 0; }
    if (c.iflist) { fail_pcap(&c); puts("libpcap not loaded"); return 0; }
    if (c.echo) { print_echo(&c); return 0; }
    if (c.readscan) { do_readscan(&c); return 0; }
    fail_pcap(&c);
    if (!c.ports) {
        print_short_help();
    } else if (!c.range) {
        puts("FAIL: target IP address list empty");
        puts(" [hint] try something like \"--range 10.0.0.0/8\"");
        puts(" [hint] try something like \"--range 192.168.0.100-192.168.0.200\"");
    } else {
        puts("[-] FAIL: could not determine default interface");
        puts("    [hint] try \"--interface ethX\"");
    }
    return 0;
}
