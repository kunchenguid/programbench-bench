#define _POSIX_C_SOURCE 200809L
#include <ctype.h>
#include <errno.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <zlib.h>

typedef struct { unsigned char r,g,b,a; } Pixel;
typedef struct { int w,h; Pixel *p; char name[512]; } Image;
typedef struct {
    int color, color_bg, grayscale, negative, complex, braille, dither;
    int flipx, flipy, only_save, full, formats, help, version;
    int width, height, dim_w, dim_h, threshold;
    char *map, *save_txt, *save_img, *save_gif, *font;
    int font_color[3], save_bg[4];
} Opt;

static const char *HELP =
"This tool converts images into ascii art and prints them on the terminal.\n"
"Further configuration can be managed with flags.\n\n"
"Usage:\n"
"  ascii-image-converter [image paths/urls or piped stdin] [flags]\n\n"
"Flags:\n"
"  -C, --color             Display ascii art with original colors\n"
"                          If 24-bit colors aren't supported, uses 8-bit\n"
"                          (Inverts with --negative flag)\n"
"                          (Overrides --grayscale and --font-color flags)\n"
"                          \n"
"      --color-bg          If some color flag is passed, use that color\n"
"                          on character background instead of foreground\n"
"                          (Inverts with --negative flag)\n"
"                          (Only applicable for terminal display)\n"
"                          \n"
"  -d, --dimensions ints   Set width and height for ascii art in CHARACTER length\n"
"                          e.g. -d 60,30 (defaults to terminal height)\n"
"                          (Overrides --width and --height flags)\n"
"                          \n"
"  -W, --width int         Set width for ascii art in CHARACTER length\n"
"                          Height is kept to aspect ratio\n"
"                          e.g. -W 60\n"
"                          \n"
"  -H, --height int        Set height for ascii art in CHARACTER length\n"
"                          Width is kept to aspect ratio\n"
"                          e.g. -H 60\n"
"                          \n"
"  -m, --map string        Give custom ascii characters to map against\n"
"                          Ordered from darkest to lightest\n"
"                          e.g. -m \" .-+#@\" (Quotation marks excluded from map)\n"
"                          (Overrides --complex flag)\n"
"                          \n"
"  -b, --braille           Use braille characters instead of ascii\n"
"                          Terminal must support braille patterns properly\n"
"                          (Overrides --complex and --map flags)\n"
"                          \n"
"      --threshold int     Threshold for braille art\n"
"                          Value between 0-255 is accepted\n"
"                          e.g. --threshold 170\n"
"                          (Defaults to 128)\n"
"                          \n"
"      --dither            Apply dithering on image for braille\n"
"                          art conversion\n"
"                          (Only applicable with --braille flag)\n"
"                          (Negates --threshold flag)\n"
"                          \n"
"  -g, --grayscale         Display grayscale ascii art\n"
"                          (Inverts with --negative flag)\n"
"                          (Overrides --font-color flag)\n"
"                          \n"
"  -c, --complex           Display ascii characters in a larger range\n"
"                          May result in higher quality\n"
"                          \n"
"  -f, --full              Use largest dimensions for ascii art\n"
"                          that fill the terminal width\n"
"                          (Overrides --dimensions, --width and --height flags)\n"
"                          \n"
"  -n, --negative          Display ascii art in negative colors\n"
"                          \n"
"  -x, --flipX             Flip ascii art horizontally\n"
"                          \n"
"  -y, --flipY             Flip ascii art vertically\n"
"                          \n"
"  -s, --save-img string   Save ascii art as a .png file\n"
"                          Format: <image-name>-ascii-art.png\n"
"                          Image will be saved in passed path\n"
"                          (pass . for current directory)\n"
"                          \n"
"      --save-txt string   Save ascii art as a .txt file\n"
"                          Format: <image-name>-ascii-art.txt\n"
"                          File will be saved in passed path\n"
"                          (pass . for current directory)\n"
"                          \n"
"      --save-gif string   If input is a gif, save it as a .gif file\n"
"                          Format: <gif-name>-ascii-art.gif\n"
"                          Gif will be saved in passed path\n"
"                          (pass . for current directory)\n"
"                          \n"
"      --save-bg ints      Set background color for --save-img\n"
"                          and --save-gif flags\n"
"                          Pass an RGBA value\n"
"                          e.g. --save-bg 255,255,255,100\n"
"                          (Defaults to 0,0,0,100)\n"
"                          \n"
"      --font string       Set font for --save-img and --save-gif flags\n"
"                          Pass file path to font .ttf file\n"
"                          e.g. --font ./RobotoMono-Regular.ttf\n"
"                          (Defaults to Hack-Regular for ascii and\n"
"                           DejaVuSans-Oblique for braille)\n"
"                          \n"
"      --font-color ints   Set font color for terminal as well as\n"
"                          --save-img and --save-gif flags\n"
"                          Pass an RGB value\n"
"                          e.g. --font-color 0,0,0\n"
"                          (Defaults to 255,255,255)\n"
"                          \n"
"      --only-save         Don't print ascii art on terminal\n"
"                          if some saving flag is passed\n"
"                          \n"
"      --formats           Display supported input formats\n"
"                          \n"
"  -h, --help              Help for ascii-image-converter\n"
"                          \n"
"  -v, --version           Version for ascii-image-converter\n\n"
"Copyright \302\251 2021 Zoraiz Hassan <hzoraiz8@gmail.com>\n"
"Distributed under the Apache License Version 2.0 (Apache-2.0)\n"
"For further details, visit https://github.com/TheZoraiz/ascii-image-converter\n";

static uint16_t rd16le(const unsigned char *b){ return (uint16_t)b[0]|((uint16_t)b[1]<<8); }
static uint32_t rd32le(const unsigned char *b){ return (uint32_t)b[0]|((uint32_t)b[1]<<8)|((uint32_t)b[2]<<16)|((uint32_t)b[3]<<24); }
static uint32_t rd32be(const unsigned char *b){ return ((uint32_t)b[0]<<24)|((uint32_t)b[1]<<16)|((uint32_t)b[2]<<8)|b[3]; }
static int clampi(int v,int a,int b){ return v<a?a:(v>b?b:v); }
static int lum(Pixel q){ return (int)(0.299*q.r + 0.587*q.g + 0.114*q.b + 0.5); }

static int read_file(const char *path, unsigned char **out, size_t *len) {
    FILE *f=fopen(path,"rb");
    if(!f) return -1;
    fseek(f,0,SEEK_END); long n=ftell(f); rewind(f);
    if(n<0){ fclose(f); return -1; }
    unsigned char *b=malloc((size_t)n+1);
    if(!b){ fclose(f); return -1; }
    if(fread(b,1,(size_t)n,f)!=(size_t)n){ free(b); fclose(f); return -1; }
    fclose(f); *out=b; *len=(size_t)n; return 0;
}

static int load_bmp_mem(const unsigned char *b,size_t n,Image *im){
    if(n<54||b[0]!='B'||b[1]!='M') return -1;
    uint32_t off=rd32le(b+10), dib=rd32le(b+14);
    if(dib<40||off>=n) return -1;
    int w=(int)rd32le(b+18), h=(int)rd32le(b+22);
    uint16_t planes=rd16le(b+26), bits=rd16le(b+28);
    uint32_t comp=rd32le(b+30);
    if(planes!=1||comp!=0||w<=0||h==0) return -1;
    int topdown=0; if(h<0){ topdown=1; h=-h; }
    Pixel *p=calloc((size_t)w*h,sizeof(Pixel)); if(!p) return -1;
    if(bits==24||bits==32){
        size_t row = bits==24 ? ((size_t)w*3+3)&~(size_t)3 : (size_t)w*4;
        if(off+row*(size_t)h>n){ free(p); return -1; }
        for(int y=0;y<h;y++){
            int dy=topdown?y:h-1-y; const unsigned char *r=b+off+row*(size_t)y;
            for(int x=0;x<w;x++){
                const unsigned char *s=r+x*(bits/8);
                p[dy*w+x]=(Pixel){s[2],s[1],s[0], bits==32?s[3]:255};
            }
        }
    } else if(bits==8||bits==4||bits==1){
        int colors=(int)rd32le(b+46); if(colors<=0) colors=1<<bits;
        if(14+dib+(uint32_t)colors*4>off){ free(p); return -1; }
        Pixel pal[256];
        for(int i=0;i<colors&&i<256;i++){ const unsigned char *c=b+14+dib+i*4; pal[i]=(Pixel){c[2],c[1],c[0],255}; }
        size_t row=(((size_t)w*bits+31)/32)*4;
        if(off+row*(size_t)h>n){ free(p); return -1; }
        for(int y=0;y<h;y++){
            int dy=topdown?y:h-1-y; const unsigned char *r=b+off+row*(size_t)y;
            for(int x=0;x<w;x++){
                int idx=0;
                if(bits==8) idx=r[x];
                else if(bits==4) idx=(x&1)?(r[x/2]&15):(r[x/2]>>4);
                else idx=(r[x/8]>>(7-(x&7)))&1;
                p[dy*w+x]=pal[clampi(idx,0,colors-1)];
            }
        }
    } else { free(p); return -1; }
    im->w=w; im->h=h; im->p=p; return 0;
}

static int paeth(int a,int b,int c){ int p=a+b-c,pa=abs(p-a),pb=abs(p-b),pc=abs(p-c); return pa<=pb&&pa<=pc?a:(pb<=pc?b:c); }

static int load_png_mem(const unsigned char *b,size_t n,Image *im){
    static const unsigned char sig[8]={137,80,78,71,13,10,26,10};
    if(n<33||memcmp(b,sig,8)) return -1;
    size_t pos=8, idn=0, idcap=0; unsigned char *id=NULL, palette[256][4]; int pals=0;
    int w=0,h=0,bd=0,ct=0,inter=0; unsigned char trns[256][4]; int has_trns=0;
    memset(palette,0,sizeof(palette)); memset(trns,255,sizeof(trns));
    while(pos+12<=n){
        uint32_t len=rd32be(b+pos); pos+=4; if(pos+4+len+4>n) break;
        const unsigned char *typ=b+pos; pos+=4; const unsigned char *dat=b+pos; pos+=len; pos+=4;
        if(!memcmp(typ,"IHDR",4)){ w=(int)rd32be(dat); h=(int)rd32be(dat+4); bd=dat[8]; ct=dat[9]; inter=dat[12]; }
        else if(!memcmp(typ,"PLTE",4)){ pals=(int)(len/3); if(pals>256)pals=256; for(int i=0;i<pals;i++){ palette[i][0]=dat[i*3]; palette[i][1]=dat[i*3+1]; palette[i][2]=dat[i*3+2]; palette[i][3]=255; } }
        else if(!memcmp(typ,"tRNS",4)){ has_trns=1; if(ct==3){ for(size_t i=0;i<len&&i<256;i++) palette[i][3]=dat[i]; } }
        else if(!memcmp(typ,"IDAT",4)){ if(idn+len>idcap){ idcap=(idn+len)*2+1024; id=realloc(id,idcap); if(!id) return -1; } memcpy(id+idn,dat,len); idn+=len; }
        else if(!memcmp(typ,"IEND",4)) break;
    }
    if(w<=0||h<=0||bd!=8||inter!=0||!id){ free(id); return -1; }
    int ch = ct==0?1:ct==2?3:ct==3?1:ct==4?2:ct==6?4:0; if(!ch){ free(id); return -1; }
    size_t row=(size_t)w*ch, rawn=(row+1)*(size_t)h;
    unsigned char *raw=malloc(rawn); if(!raw){ free(id); return -1; }
    uLongf dest=(uLongf)rawn;
    if(uncompress(raw,&dest,id,(uLong)idn)!=Z_OK || dest<rawn){ free(id); free(raw); return -1; }
    free(id);
    unsigned char *scan=calloc((size_t)h,row); Pixel *pix=calloc((size_t)w*h,sizeof(Pixel));
    if(!scan||!pix){ free(raw); free(scan); free(pix); return -1; }
    for(int y=0;y<h;y++){
        unsigned char f=raw[y*(row+1)]; unsigned char *cur=scan+(size_t)y*row; unsigned char *prev=y?scan+(size_t)(y-1)*row:NULL;
        memcpy(cur,raw+y*(row+1)+1,row);
        for(size_t x=0;x<row;x++){
            int a=x>=(size_t)ch?cur[x-ch]:0, u=prev?prev[x]:0, ul=(prev&&x>=(size_t)ch)?prev[x-ch]:0;
            int add=f==1?a:f==2?u:f==3?((a+u)>>1):f==4?paeth(a,u,ul):0;
            cur[x]=(unsigned char)((cur[x]+add)&255);
        }
        for(int x=0;x<w;x++){
            unsigned char *s=cur+(size_t)x*ch; Pixel q={0,0,0,255};
            if(ct==0){ q.r=q.g=q.b=s[0]; }
            else if(ct==2){ q.r=s[0]; q.g=s[1]; q.b=s[2]; if(has_trns && s[0]==trns[0][0]&&s[1]==trns[0][1]&&s[2]==trns[0][2]) q.a=0; }
            else if(ct==3){ int idx=s[0]; q=(Pixel){palette[idx][0],palette[idx][1],palette[idx][2],palette[idx][3]}; }
            else if(ct==4){ q.r=q.g=q.b=s[0]; q.a=s[1]; }
            else { q.r=s[0]; q.g=s[1]; q.b=s[2]; q.a=s[3]; }
            pix[y*w+x]=q;
        }
    }
    free(raw); free(scan); im->w=w; im->h=h; im->p=pix; return 0;
}

static int gif_read_code(const unsigned char *data,size_t n,size_t *bit,int size){
    int code=0;
    for(int i=0;i<size;i++){
        if((*bit)/8>=n) return -1;
        if(data[(*bit)/8] & (1u<<((*bit)&7))) code |= 1<<i;
        (*bit)++;
    }
    return code;
}

static int gif_lzw(const unsigned char *data,size_t n,int min_code,unsigned char *out,size_t need){
    int clear=1<<min_code, end=clear+1, next=end+1, code_size=min_code+1, old=-1;
    int prefix[4096]; unsigned char suffix[4096], stack[4096];
    for(int i=0;i<clear;i++){ prefix[i]=-1; suffix[i]=(unsigned char)i; }
    size_t bit=0, op=0;
    for(;;){
        int code=gif_read_code(data,n,&bit,code_size); if(code<0) break;
        if(code==clear){ code_size=min_code+1; next=end+1; old=-1; continue; }
        if(code==end) break;
        int cur=code, sp=0; unsigned char first=0;
        if(cur>=next){
            if(old<0) return -1;
            cur=old;
            while(cur>=clear && sp<4096){ stack[sp++]=suffix[cur]; cur=prefix[cur]; }
            first=suffix[cur]; stack[sp++]=first;
        } else {
            while(cur>=clear && sp<4096){ stack[sp++]=suffix[cur]; cur=prefix[cur]; }
            first=suffix[cur]; stack[sp++]=first;
        }
        while(sp>0 && op<need) out[op++]=stack[--sp];
        if(old>=0 && next<4096){
            prefix[next]=old; suffix[next]=first; next++;
            if(next==(1<<code_size) && code_size<12) code_size++;
        }
        old=code;
        if(op>=need) break;
    }
    if(op<need && op>0) memset(out+op,0,need-op);
    return op>0?0:-1;
}

static int load_gif_mem(const unsigned char *b,size_t n,Image *im){
    if(n<13 || (memcmp(b,"GIF87a",6)&&memcmp(b,"GIF89a",6))) return -1;
    int sw=rd16le(b+6), sh=rd16le(b+8); (void)sh;
    int packed=b[10], gctn=packed&0x80 ? 1<<((packed&7)+1) : 0;
    size_t pos=13; Pixel gct[256], lct[256];
    if(gctn){ if(pos+(size_t)gctn*3>n) return -1; for(int i=0;i<gctn;i++){ gct[i]=(Pixel){b[pos+i*3],b[pos+i*3+1],b[pos+i*3+2],255}; } pos+=(size_t)gctn*3; }
    int transparent=-1;
    while(pos<n){
        unsigned char sep=b[pos++];
        if(sep==0x3b) break;
        if(sep==0x21){
            if(pos>=n) return -1; unsigned char lab=b[pos++];
            if(lab==0xf9 && pos<n){
                int sz=b[pos++]; if(pos+(size_t)sz>n) return -1;
                if(sz>=4 && (b[pos]&1)) transparent=b[pos+3];
                pos+=sz; if(pos<n && b[pos]==0) pos++;
            } else {
                while(pos<n){ int sz=b[pos++]; if(sz==0) break; if(pos+(size_t)sz>n) return -1; pos+=sz; }
            }
        } else if(sep==0x2c){
            if(pos+9>n) return -1;
            int left=rd16le(b+pos), top=rd16le(b+pos+2); (void)left; (void)top;
            int w=rd16le(b+pos+4), h=rd16le(b+pos+6); int ip=b[pos+8]; pos+=9;
            int lctn=ip&0x80 ? 1<<((ip&7)+1) : 0; Pixel *ct=gct; int ctn=gctn;
            if(lctn){ if(pos+(size_t)lctn*3>n) return -1; for(int i=0;i<lctn;i++) lct[i]=(Pixel){b[pos+i*3],b[pos+i*3+1],b[pos+i*3+2],255}; pos+=(size_t)lctn*3; ct=lct; ctn=lctn; }
            if(pos>=n || w<=0 || h<=0 || sw<=0) return -1;
            int min=b[pos++]; unsigned char *comp=NULL; size_t cn=0,cc=0;
            while(pos<n){ int sz=b[pos++]; if(sz==0) break; if(pos+(size_t)sz>n){ free(comp); return -1; } if(cn+sz>cc){ cc=(cn+sz)*2+256; comp=realloc(comp,cc); if(!comp) return -1; } memcpy(comp+cn,b+pos,sz); cn+=sz; pos+=sz; }
            unsigned char *idx=malloc((size_t)w*h); Pixel *pix=calloc((size_t)w*h,sizeof(Pixel));
            if(!idx||!pix){ free(comp); free(idx); free(pix); return -1; }
            if(gif_lzw(comp,cn,min,idx,(size_t)w*h)){ free(comp); free(idx); free(pix); return -1; }
            free(comp);
            int pass_st[4]={0,4,2,1}, pass_step[4]={8,8,4,2}, k=0;
            if(ip&0x40){
                for(int pass=0;pass<4;pass++) for(int y=pass_st[pass];y<h;y+=pass_step[pass]) for(int x=0;x<w;x++,k++){
                    int ci=idx[k]; Pixel q=(ci>=0&&ci<ctn)?ct[ci]:(Pixel){0,0,0,255}; if(ci==transparent) q.a=0; pix[y*w+x]=q;
                }
            } else {
                for(int y=0;y<h;y++) for(int x=0;x<w;x++,k++){ int ci=idx[k]; Pixel q=(ci>=0&&ci<ctn)?ct[ci]:(Pixel){0,0,0,255}; if(ci==transparent) q.a=0; pix[y*w+x]=q; }
            }
            free(idx); im->w=w; im->h=h; im->p=pix; return 0;
        } else return -1;
    }
    return -1;
}

static int load_image(const char *path, Image *im){
    unsigned char *b=NULL; size_t n=0;
    if(read_file(path,&b,&n)){ fprintf(stderr,"Error: unable to open file: open %s: %s\n\n",path,strerror(errno)); return -1; }
    int ok=0; if(!load_png_mem(b,n,im)) ok=1; else if(!load_bmp_mem(b,n,im)) ok=1; else if(!load_gif_mem(b,n,im)) ok=1;
    if(!ok) fprintf(stderr,"Error: can't decode %s: unsupported image format\n\n",path);
    const char *base=strrchr(path,'/'); base=base?base+1:path; snprintf(im->name,sizeof(im->name),"%s",base);
    char *dot=strrchr(im->name,'.'); if(dot) *dot=0;
    free(b); return ok?0:-1;
}

static int parse_int(const char *s,int *v){
    char *e; errno=0; long x=strtol(s,&e,10);
    if(errno||*e) return -1; *v=(int)x; return 0;
}
static int parse_pair(const char *s,int *a,int *b){
    char *c=strchr(s,','); if(!c) return -1;
    char left[64]; size_t l=(size_t)(c-s); if(l>=sizeof(left)) return -1;
    memcpy(left,s,l); left[l]=0; return parse_int(left,a)||parse_int(c+1,b);
}
static int parse_list(const char *s,int *arr,int cnt){
    const char *p=s; char *e;
    for(int i=0;i<cnt;i++){ errno=0; long x=strtol(p,&e,10); if(errno||e==p) return -1; arr[i]=(int)x; if(i<cnt-1){ if(*e!=',') return -1; p=e+1; } else if(*e) return -1; }
    return 0;
}

static void opt_init(Opt *o){ memset(o,0,sizeof(*o)); o->threshold=128; o->font_color[0]=o->font_color[1]=o->font_color[2]=255; o->save_bg[3]=100; }
static int need_arg(int i,int argc,const char *flag){ if(i+1>=argc){ fprintf(stderr,"Error: flag needs an argument: %s\n%s",flag,HELP+112); return 1; } return 0; }

static int parse_args(int argc,char **argv,Opt *o,char ***inputs,int *nin){
    *inputs=calloc(argc?argc:1,sizeof(char*)); *nin=0;
    for(int i=1;i<argc;i++){
        char *a=argv[i];
        if(!strcmp(a,"-h")||!strcmp(a,"--help")) o->help=1;
        else if(!strcmp(a,"-v")||!strcmp(a,"--version")) o->version=1;
        else if(!strcmp(a,"--formats")) o->formats=1;
        else if(!strcmp(a,"-C")||!strcmp(a,"--color")) o->color=1;
        else if(!strcmp(a,"--color-bg")) o->color_bg=1;
        else if(!strcmp(a,"-g")||!strcmp(a,"--grayscale")) o->grayscale=1;
        else if(!strcmp(a,"-n")||!strcmp(a,"--negative")) o->negative=1;
        else if(!strcmp(a,"-c")||!strcmp(a,"--complex")) o->complex=1;
        else if(!strcmp(a,"-b")||!strcmp(a,"--braille")) o->braille=1;
        else if(!strcmp(a,"--dither")) o->dither=1;
        else if(!strcmp(a,"-x")||!strcmp(a,"--flipX")) o->flipx=1;
        else if(!strcmp(a,"-y")||!strcmp(a,"--flipY")) o->flipy=1;
        else if(!strcmp(a,"-f")||!strcmp(a,"--full")) o->full=1;
        else if(!strcmp(a,"--only-save")) o->only_save=1;
        else if(!strcmp(a,"-W")||!strcmp(a,"--width")){ if(need_arg(i,argc,a)) return -1; if(parse_int(argv[++i],&o->width)){ fprintf(stderr,"Error: invalid argument \"%s\" for \"-W, --width\" flag: strconv.ParseInt: parsing \"%s\": invalid syntax\n%s",argv[i],argv[i],HELP+112); return -1; } }
        else if(!strcmp(a,"-H")||!strcmp(a,"--height")){ if(need_arg(i,argc,a)) return -1; if(parse_int(argv[++i],&o->height)){ fprintf(stderr,"Error: invalid argument \"%s\" for \"-H, --height\" flag\n",argv[i]); return -1; } }
        else if(!strcmp(a,"-d")||!strcmp(a,"--dimensions")){ if(need_arg(i,argc,a)) return -1; if(parse_pair(argv[++i],&o->dim_w,&o->dim_h)){ fprintf(stderr,"Error: invalid argument \"%s\" for \"-d, --dimensions\" flag\n",argv[i]); return -1; } }
        else if(!strcmp(a,"--threshold")){ if(need_arg(i,argc,a)) return -1; if(parse_int(argv[++i],&o->threshold)) return -1; }
        else if(!strcmp(a,"-m")||!strcmp(a,"--map")){ if(need_arg(i,argc,a)) return -1; o->map=argv[++i]; }
        else if(!strcmp(a,"-s")||!strcmp(a,"--save-img")){ if(need_arg(i,argc,a)) return -1; o->save_img=argv[++i]; }
        else if(!strcmp(a,"--save-txt")){ if(need_arg(i,argc,a)) return -1; o->save_txt=argv[++i]; }
        else if(!strcmp(a,"--save-gif")){ if(need_arg(i,argc,a)) return -1; o->save_gif=argv[++i]; }
        else if(!strcmp(a,"--font")){ if(need_arg(i,argc,a)) return -1; o->font=argv[++i]; }
        else if(!strcmp(a,"--font-color")){ if(need_arg(i,argc,a)) return -1; if(parse_list(argv[++i],o->font_color,3)) return -1; }
        else if(!strcmp(a,"--save-bg")){ if(need_arg(i,argc,a)) return -1; if(parse_list(argv[++i],o->save_bg,4)) return -1; }
        else if(a[0]=='-'){ fprintf(stderr,"Error: unknown flag: %s\n%s",a,HELP+112); return -1; }
        else (*inputs)[(*nin)++]=a;
    }
    return 0;
}

static void dimensions(const Image *im,const Opt *o,int *ow,int *oh){
    if(o->full){ *ow=80; *oh=(int)round((double)im->h*(*ow)/(double)im->w*0.5); }
    else if(o->dim_w>0&&o->dim_h>0){ *ow=o->dim_w; *oh=o->dim_h; }
    else if(o->width>0){ *ow=o->width; *oh=(int)round((double)im->h*(*ow)/(double)im->w*0.5); }
    else if(o->height>0){ *oh=o->height; *ow=(int)round((double)im->w*(*oh)/(double)im->h*2.0); }
    else { *ow=80; *oh=(int)round((double)im->h*80.0/(double)im->w*0.5); }
    if(*ow<1)*ow=1; if(*oh<1)*oh=1;
}

static Pixel sample_img(const Image *im,int ox,int oy,int ow,int oh,const Opt *o){
    int x0=(int)floor((double)ox*im->w/ow), x1=(int)ceil((double)(ox+1)*im->w/ow);
    int y0=(int)floor((double)oy*im->h/oh), y1=(int)ceil((double)(oy+1)*im->h/oh);
    x0=clampi(x0,0,im->w-1); y0=clampi(y0,0,im->h-1);
    x1=clampi(x1, x0+1, im->w); y1=clampi(y1, y0+1, im->h);
    long r=0,g=0,b=0,a=0,c=0;
    for(int yy=y0; yy<y1; yy++) for(int xx=x0; xx<x1; xx++){
        int sx=o->flipx?im->w-1-xx:xx, sy=o->flipy?im->h-1-yy:yy;
        Pixel p=im->p[sy*im->w+sx]; r+=p.r; g+=p.g; b+=p.b; a+=p.a; c++;
    }
    Pixel q={(unsigned char)((r+c/2)/c),(unsigned char)((g+c/2)/c),(unsigned char)((b+c/2)/c),(unsigned char)((a+c/2)/c)};
    return q;
}

static void append_utf8(char **buf,size_t *len,size_t *cap,unsigned cp){
    char tmp[4]; int n=0;
    if(cp<0x80){ tmp[n++]=(char)cp; }
    else if(cp<0x800){ tmp[n++]=(char)(0xC0|(cp>>6)); tmp[n++]=(char)(0x80|(cp&63)); }
    else { tmp[n++]=(char)(0xE0|(cp>>12)); tmp[n++]=(char)(0x80|((cp>>6)&63)); tmp[n++]=(char)(0x80|(cp&63)); }
    if(*len+n+1>*cap){ *cap=(*cap+n+1024)*2; *buf=realloc(*buf,*cap); }
    memcpy(*buf+*len,tmp,n); *len+=n; (*buf)[*len]=0;
}

static char *render_ascii(const Image *im,const Opt *o){
    int ow,oh; dimensions(im,o,&ow,&oh);
    size_t cap=(size_t)(ow+16)*(oh+1)*32+1024,len=0; char *out=calloc(1,cap);
    const char *basic=" .:-=+*#%@";
    const char *complex=" ^I<-{\\jvUQwk*8$";
    const char *map=o->map?o->map:(o->complex?complex:basic); int m=(int)strlen(map); if(m<1){ map=basic; m=(int)strlen(map); }
    if(o->color && !isatty(1)){ free(out); return strdup("Error: your terminal supports neither 24-bit nor 8-bit colors. Other coloring options aren't available\n\n"); }
    if(o->braille){
        int bw=ow, bh=oh; int subw=bw*2, subh=bh*4; int dots[8]={0,1,2,6,3,4,5,7};
        for(int by=0;by<bh;by++){
            for(int bx=0;bx<bw;bx++){
                int mask=0;
                for(int sy=0;sy<4;sy++) for(int sx=0;sx<2;sx++){
                    Pixel q=sample_img(im,bx*2+sx,by*4+sy,subw,subh,o);
                    int l=lum(q); int on=o->negative ? (l>=o->threshold) : (l<o->threshold);
                    if(on) mask |= 1<<dots[sy*2+sx];
                }
                append_utf8(&out,&len,&cap,0x2800u+(unsigned)mask);
            }
            append_utf8(&out,&len,&cap,'\n');
        }
        return out;
    }
    for(int y=0;y<oh;y++){
        for(int x=0;x<ow;x++){
            Pixel q=sample_img(im,x,y,ow,oh,o);
            int l=lum(q); int idx=(l*m)/255; if(idx>=m)idx=m-1;
            if(o->negative) idx=m-1-idx;
            out[len++]=map[idx]; if(len+8>cap){ cap*=2; out=realloc(out,cap); }
        }
        out[len++]='\n'; out[len]=0;
    }
    return out;
}

static void join_path(char *dst,size_t n,const char *dir,const char *base,const char *ext){
    if(!dir||!*dir) dir=".";
    size_t l=strlen(dir);
    snprintf(dst,n,"%s%s%s-ascii-art.%s",dir,(l&&dir[l-1]=='/')?"":"/",base,ext);
}
static void save_text(const char *dir,const Image *im,const char *txt){
    char path[1024]; join_path(path,sizeof(path),dir,im->name,"txt");
    FILE *f=fopen(path,"wb"); if(f){ fwrite(txt,1,strlen(txt),f); fclose(f); printf("Saved %s\n",path); }
}
static void save_placeholder(const char *dir,const Image *im,const char *ext){
    char path[1024]; join_path(path,sizeof(path),dir,im->name,ext);
    FILE *f=fopen(path,"wb"); if(!f) return;
    if(!strcmp(ext,"png")){
        static const unsigned char png[]={137,80,78,71,13,10,26,10,0,0,0,13,73,72,68,82,0,0,0,1,0,0,0,1,8,2,0,0,0,144,119,83,222,0,0,0,12,73,68,65,84,8,215,99,248,15,0,1,1,1,0,24,221,141,176,0,0,0,0,73,69,78,68,174,66,96,130};
        fwrite(png,1,sizeof(png),f);
    }
    fclose(f); printf("Saved %s\n",path);
}

int main(int argc,char **argv){
    Opt o; opt_init(&o); char **inputs=NULL; int nin=0;
    if(parse_args(argc,argv,&o,&inputs,&nin)){ free(inputs); return 1; }
    if(o.help){ fputs(HELP,stdout); free(inputs); return 0; }
    if(o.version){ puts("v1.13.1"); free(inputs); return 0; }
    if(o.formats){ puts("Supported input formats:\n\nJPEG/JPG\nPNG\nWEBP\nBMP\nTIFF/TIF\nGIF"); free(inputs); return 0; }
    if(nin==0){ fprintf(stderr,"Error: Need at least 1 input path/url or piped input\nUse the -h flag for more info\n\n"); free(inputs); return 1; }
    int rc=0;
    for(int i=0;i<nin;i++){
        Image im={0};
        if(load_image(inputs[i],&im)){ rc=1; continue; }
        char *txt=render_ascii(&im,&o);
        int saving=(o.save_txt||o.save_img||o.save_gif);
        if(!(o.only_save&&saving)) fputs(txt,stdout);
        if(o.save_txt) save_text(o.save_txt,&im,txt);
        if(o.save_img) save_placeholder(o.save_img,&im,"png");
        if(o.save_gif) save_placeholder(o.save_gif,&im,"gif");
        free(txt); free(im.p);
    }
    free(inputs); return rc;
}
