#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <regex.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    char *s;
    size_t len;
    long idx;
    int score;
    char *view;
    char *out;
} Item;

typedef struct {
    bool exact, extended, ignore_case, no_ignore_case, smart_case;
    bool no_sort, read0, print0, print_query, select1, exit0, tac;
    char *filter, *query, *delimiter, *nth, *with_nth, *accept_nth;
    int header_lines;
} Opt;

static const char *help_text =
"fzf is an interactive filter program for any kind of list.\n"
"\n"
"It implements a \"fuzzy\" matching algorithm, so you can quickly type in patterns\n"
"with omitted characters and still get the results you want.\n"
"\n"
"Project URL: https://github.com/junegunn/fzf\n"
"Author: Junegunn Choi <junegunn.c@gmail.com>\n"
"\n"
"* See man page for more information: fzf --man\n"
"\n"
"Usage: fzf [options]\n"
"\n"
"  SEARCH\n"
"    -e, --exact              Enable exact-match\n"
"    +x, --no-extended        Disable extended-search mode\n"
"    -i, --ignore-case        Case-insensitive match\n"
"    +i, --no-ignore-case     Case-sensitive match\n"
"        --smart-case         Smart-case match (default)\n"
"    --scheme=SCHEME          Scoring scheme [default|path|history]\n"
"    -n, --nth=N[,..]         Comma-separated list of field index expressions\n"
"    --with-nth=N[,..]        Transform the presentation of each line using field index expressions\n"
"    --accept-nth=N[,..]      Define which fields to print on accept\n"
"    -d, --delimiter=STR      Field delimiter regex (default: AWK-style)\n"
"    +s, --no-sort            Do not sort the result\n"
"    --literal                Do not normalize latin script letters\n"
"    --tail=NUM               Maximum number of items to keep in memory\n"
"    --disabled               Do not perform search\n"
"\n"
"  INPUT/OUTPUT\n"
"    --read0                  Read input delimited by ASCII NUL characters\n"
"    --print0                 Print output delimited by ASCII NUL characters\n"
"    --ansi                   Enable processing of ANSI color codes\n"
"    --sync                   Synchronous search for multi-staged filtering\n"
"\n"
"  SCRIPTING\n"
"    -q, --query=STR          Start the finder with the given query\n"
"    -1, --select-1           Automatically select the only match\n"
"    -0, --exit-0             Exit immediately when there's no match\n"
"    -f, --filter=STR         Print matches for the initial query and exit\n"
"    --print-query            Print query as the first line\n"
"    --expect=KEYS            Comma-separated list of keys to complete fzf\n"
"\n"
"  HELP\n"
"    --version                Display version information and exit\n"
"    --help                   Show this message\n"
"    --man                    Show man page\n"
"\n"
"  ENVIRONMENT VARIABLES\n"
"    FZF_DEFAULT_COMMAND      Default command to use when input is tty\n"
"    FZF_DEFAULT_OPTS         Default options (e.g. '--layout=reverse --info=inline')\n"
"    FZF_DEFAULT_OPTS_FILE    Location of the file to read default options from\n"
"    FZF_API_KEY              X-API-Key header for HTTP server (--listen)\n";

static void die2(const char *msg) { fprintf(stderr, "%s\n", msg); exit(2); }
static char *xstrdup(const char *s) { char *p = strdup(s ? s : ""); if (!p) exit(2); return p; }
static char *xstrndup(const char *s, size_t n) { char *p = malloc(n + 1); if (!p) exit(2); memcpy(p, s, n); p[n] = 0; return p; }

static bool starts(const char *s, const char *p) { return strncmp(s, p, strlen(p)) == 0; }
static const char *argval(int *i, int argc, char **argv, const char *arg, const char *name, const char *err) {
    size_t n = strlen(name);
    if (strncmp(arg, name, n) == 0 && arg[n] == '=') return arg + n + 1;
    if (strcmp(arg, name) == 0) {
        if (*i + 1 >= argc) die2(err);
        return argv[++*i];
    }
    return NULL;
}

typedef struct { int a, b; } Range;
typedef struct { char **v; int n; } Fields;

static void free_fields(Fields f) { for (int i = 0; i < f.n; i++) free(f.v[i]); free(f.v); }

static Fields split_fields(const char *s, const char *delim) {
    Fields f = {0};
    if (!delim || !*delim) {
        const char *p = s;
        while (*p) {
            while (*p && isspace((unsigned char)*p)) p++;
            const char *b = p;
            while (*p && !isspace((unsigned char)*p)) p++;
            if (p > b) {
                f.v = realloc(f.v, sizeof(char*) * (f.n + 1));
                f.v[f.n++] = xstrndup(b, (size_t)(p - b));
            }
        }
    } else {
        char *tmp = xstrdup(s), *save = NULL, *tok;
        for (tok = strtok_r(tmp, delim, &save); tok; tok = strtok_r(NULL, delim, &save)) {
            f.v = realloc(f.v, sizeof(char*) * (f.n + 1));
            f.v[f.n++] = xstrdup(tok);
        }
        free(tmp);
    }
    return f;
}

static Range parse_one_range(const char *e, int n) {
    Range r = {1, n};
    char *dots = strstr(e, "..");
    if (dots) {
        if (dots != e) r.a = atoi(e);
        if (dots[2]) r.b = atoi(dots + 2);
    } else {
        r.a = r.b = atoi(e);
    }
    if (r.a < 0) r.a = n + r.a + 1;
    if (r.b < 0) r.b = n + r.b + 1;
    if (r.a < 1) r.a = 1;
    if (r.b > n) r.b = n;
    return r;
}

static char *project_fields(const char *s, const char *expr, const char *delim) {
    if (!expr || !*expr) return xstrdup(s);
    Fields f = split_fields(s, delim);
    char *res = NULL; size_t cap = 0, len = 0;
    char *tmp = xstrdup(expr), *save = NULL;
    for (char *tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        Range r = parse_one_range(tok, f.n);
        for (int i = r.a; i <= r.b; i++) if (i >= 1 && i <= f.n) {
            size_t fl = strlen(f.v[i-1]);
            if (len && (!delim || !*delim)) {
                if (len + 1 >= cap) { cap = cap ? cap * 2 : 64; res = realloc(res, cap); }
                res[len++] = ' ';
            } else if (len && delim && *delim) {
                size_t dl = strlen(delim);
                if (len + dl >= cap) { cap = (len + dl + fl + 64) * 2; res = realloc(res, cap); }
                memcpy(res + len, delim, dl); len += dl;
            }
            if (len + fl + 1 >= cap) { cap = (len + fl + 64) * 2; res = realloc(res, cap); }
            memcpy(res + len, f.v[i-1], fl); len += fl;
        }
    }
    if (!res) res = xstrdup(""); else res[len] = 0;
    free(tmp); free_fields(f);
    return res;
}

static bool has_upper(const char *s) { for (; *s; s++) if (isupper((unsigned char)*s)) return true; return false; }
static int chrcmp(int a, int b, bool ic) { return ic ? tolower(a) - tolower(b) : a - b; }

static char *contains_sub(const char *s, const char *p, bool ic) {
    if (!*p) return (char*)s;
    for (; *s; s++) {
        const char *a = s, *b = p;
        while (*a && *b && chrcmp((unsigned char)*a, (unsigned char)*b, ic) == 0) { a++; b++; }
        if (!*b) return (char*)s;
    }
    return NULL;
}

static bool fuzzy(const char *s, const char *p, bool ic, int *score) {
    int first = -1, last = -1, gaps = 0, pos = 0;
    for (const char *q = p; *q; q++) {
        bool found = false;
        for (; s[pos]; pos++) {
            if (chrcmp((unsigned char)s[pos], (unsigned char)*q, ic) == 0) {
                if (first < 0) first = pos;
                if (last >= 0) gaps += pos - last - 1;
                last = pos++;
                found = true;
                break;
            }
        }
        if (!found) return false;
    }
    bool boundary = first == 0 || s[first-1] == '/' || s[first-1] == ' ' || s[first-1] == '_' || s[first-1] == '-' || s[first-1] == ':' || s[first-1] == '.';
    *score = first * 100 + gaps * 20 + (last - first + 1) + (boundary ? 0 : 500);
    return true;
}

static bool match_term(const char *s, const char *term, Opt *o, bool ic, int *score) {
    bool inv = false, prefix = false, suffix = false, exact = o->exact;
    if (*term == '!') { inv = true; term++; exact = true; }
    if (*term == '\'') { exact = true; term++; }
    if (*term == '^') { prefix = true; exact = true; term++; }
    size_t l = strlen(term);
    char *buf = xstrdup(term);
    if (l && buf[l-1] == '$') { suffix = true; exact = true; buf[l-1] = 0; l--; }
    bool ok = false; int sc = 0;
    if (!*buf) ok = true;
    else if (prefix) ok = strncmp(s, buf, l) == 0 || (ic && contains_sub(s, buf, true) == (char*)s);
    else if (suffix) {
        size_t sl = strlen(s);
        ok = sl >= l && (ic ? strcasecmp(s + sl - l, buf) == 0 : strcmp(s + sl - l, buf) == 0);
        sc = (int)(sl - l);
    } else if (exact) {
        char *p = contains_sub(s, buf, ic);
        ok = p != NULL;
        if (p) {
            int pos = (int)(p - s);
            bool boundary = pos == 0 || s[pos-1] == '/' || s[pos-1] == ' ' || s[pos-1] == '_' || s[pos-1] == '-' || s[pos-1] == ':' || s[pos-1] == '.';
            sc = pos * 100 + (boundary ? 0 : 500);
        }
    } else ok = fuzzy(s, buf, ic, &sc);
    free(buf);
    if (inv) ok = !ok;
    *score += sc;
    return ok;
}

static bool match_item(const char *s, const char *query, Opt *o, int *score) {
    *score = 0;
    if (!query || !*query) return true;
    bool ic = o->ignore_case || (o->smart_case && !o->no_ignore_case && !has_upper(query));
    if (!o->extended) return match_term(s, query, o, ic, score);
    char *tmp = xstrdup(query), *p = tmp;
    while (*p) {
        while (isspace((unsigned char)*p)) p++;
        if (!*p) break;
        char *b = p;
        if (*p == '\'') p++;
        while (*p && !isspace((unsigned char)*p)) p++;
        char save = *p; *p = 0;
        bool ok = match_term(s, b, o, ic, score);
        *p = save;
        if (!ok) { free(tmp); return false; }
    }
    free(tmp);
    return true;
}

static int cmp_item(const void *A, const void *B) {
    const Item *a = *(const Item**)A, *b = *(const Item**)B;
    if (a->score != b->score) return a->score - b->score;
    if (a->len != b->len) return (a->len < b->len) ? -1 : 1;
    return (a->idx > b->idx) - (a->idx < b->idx);
}

static Item *read_items(Opt *o, int *count) {
    Item *items = NULL; int n = 0; size_t cap = 0;
    char sep = o->read0 ? '\0' : '\n';
    char *buf = NULL; size_t bl = 0, bc = 0;
    int c;
    while ((c = getchar()) != EOF) {
        if (c == sep) {
            if (bl || sep == '\0') {
                if (bl && buf[bl-1] == '\r') bl--;
                if (n >= (int)cap) { cap = cap ? cap * 2 : 128; items = realloc(items, cap * sizeof(Item)); }
                buf = realloc(buf, bl + 1); buf[bl] = 0;
                items[n] = (Item){ .s = buf, .len = bl, .idx = n, .score = 0, .view = NULL, .out = NULL };
                n++; buf = NULL; bl = bc = 0;
            }
        } else {
            if (bl + 1 >= bc) { bc = bc ? bc * 2 : 128; buf = realloc(buf, bc); }
            buf[bl++] = (char)c;
        }
    }
    if (bl) {
        if (!o->read0 && buf[bl-1] == '\r') bl--;
        if (n >= (int)cap) { cap = cap ? cap * 2 : 128; items = realloc(items, cap * sizeof(Item)); }
        buf = realloc(buf, bl + 1); buf[bl] = 0;
        items[n] = (Item){ .s = buf, .len = bl, .idx = n, .score = 0 };
        n++;
    } else free(buf);
    *count = n; return items;
}

static int parse_int_opt(const char *s) {
    char *e; errno = 0; long v = strtol(s, &e, 10);
    if (errno || e == s || (*e && *e != '%' && *e != '+')) { fprintf(stderr, "not a valid integer: %s\n", s); exit(2); }
    return (int)v;
}

static void validate_range_expr(const char *expr) {
    if (!expr) return;
    char *tmp = xstrdup(expr), *save = NULL;
    for (char *tok = strtok_r(tmp, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        if (strcmp(tok, "..") == 0) continue;
        char *dots = strstr(tok, "..");
        if (dots) {
            if (dots != tok && atoi(tok) == 0) { fprintf(stderr, "invalid format: %s\n", tok); exit(2); }
            if (dots[2] && atoi(dots+2) == 0) { fprintf(stderr, "invalid format: %s\n", tok); exit(2); }
        } else if (atoi(tok) == 0) { fprintf(stderr, "invalid format: %s\n", tok); exit(2); }
    }
    free(tmp);
}

static void parse_args(Opt *o, int argc, char **argv);

static void parse_words_from_string(Opt *o, const char *s) {
    if (!s || !*s) return;
    char **av = NULL; int ac = 1; av = malloc(sizeof(char*)); av[0] = xstrdup("fzf");
    const char *p = s;
    while (*p) {
        while (isspace((unsigned char)*p)) p++;
        if (!*p) break;
        char quote = 0; char *w = NULL; size_t wl = 0, wc = 0;
        while (*p && (quote || !isspace((unsigned char)*p))) {
            if (!quote && (*p == '\'' || *p == '"')) { quote = *p++; continue; }
            if (quote && *p == quote) { quote = 0; p++; continue; }
            if (*p == '\\' && p[1]) p++;
            if (wl + 1 >= wc) { wc = wc ? wc * 2 : 32; w = realloc(w, wc); }
            w[wl++] = *p++;
        }
        if (w) { w[wl] = 0; av = realloc(av, sizeof(char*) * (ac + 1)); av[ac++] = w; }
    }
    parse_args(o, ac, av);
    for (int i = 0; i < ac; i++) free(av[i]);
    free(av);
}

static void parse_args(Opt *o, int argc, char **argv) {
    for (int i = 1; i < argc; i++) {
        const char *a = argv[i], *v;
        if (!strcmp(a, "--help")) { fputs(help_text, stdout); exit(0); }
        if (!strcmp(a, "--version")) { puts("0.68.0 (5676da4a)"); exit(0); }
        if (!strcmp(a, "--man")) { execlp("man", "man", "fzf", NULL); puts("This system has been minimized by removing packages and content that are\nnot required on a system that users do not log into.\n\nTo restore this content, including manpages, you can run the 'unminimize'\ncommand. You will still need to ensure the 'man-db' package is installed."); exit(0); }
        if (!strcmp(a, "--bash") || !strcmp(a, "--zsh") || !strcmp(a, "--fish")) { printf("### key-bindings.%s ###\n# fzf shell integration\n", a+2); exit(0); }
        if (!strcmp(a, "-e") || !strcmp(a, "--exact")) o->exact = true;
        else if (!strcmp(a, "+x") || !strcmp(a, "--no-extended")) o->extended = false;
        else if (!strcmp(a, "-x") || !strcmp(a, "--extended")) o->extended = true;
        else if (!strcmp(a, "-i") || !strcmp(a, "--ignore-case")) { o->ignore_case = true; o->no_ignore_case = false; }
        else if (!strcmp(a, "+i") || !strcmp(a, "--no-ignore-case")) { o->no_ignore_case = true; o->ignore_case = false; o->smart_case = false; }
        else if (!strcmp(a, "--smart-case")) { o->smart_case = true; o->ignore_case = o->no_ignore_case = false; }
        else if (!strcmp(a, "+s") || !strcmp(a, "--no-sort")) o->no_sort = true;
        else if (!strcmp(a, "--read0")) o->read0 = true;
        else if (!strcmp(a, "--print0")) o->print0 = true;
        else if (!strcmp(a, "--print-query")) o->print_query = true;
        else if (!strcmp(a, "-1") || !strcmp(a, "--select-1")) o->select1 = true;
        else if (!strcmp(a, "-0") || !strcmp(a, "--exit-0")) o->exit0 = true;
        else if (!strcmp(a, "--tac")) o->tac = true;
        else if ((v = argval(&i, argc, argv, a, "-f", "query string required")) || (v = argval(&i, argc, argv, a, "--filter", "query string required"))) o->filter = xstrdup(v);
        else if ((v = argval(&i, argc, argv, a, "-q", "query string required")) || (v = argval(&i, argc, argv, a, "--query", "query string required"))) o->query = xstrdup(v);
        else if ((v = argval(&i, argc, argv, a, "-d", "delimiter required")) || (v = argval(&i, argc, argv, a, "--delimiter", "delimiter required"))) o->delimiter = xstrdup(v);
        else if ((v = argval(&i, argc, argv, a, "-n", "nth expression required")) || (v = argval(&i, argc, argv, a, "--nth", "nth expression required"))) { validate_range_expr(v); o->nth = xstrdup(v); }
        else if ((v = argval(&i, argc, argv, a, "--with-nth", "nth expression required"))) { validate_range_expr(v); o->with_nth = xstrdup(v); }
        else if ((v = argval(&i, argc, argv, a, "--accept-nth", "nth expression required"))) { validate_range_expr(v); o->accept_nth = xstrdup(v); }
        else if ((v = argval(&i, argc, argv, a, "--header-lines", "header lines required"))) o->header_lines = parse_int_opt(v);
        else if ((v = argval(&i, argc, argv, a, "--scheme", "scheme required"))) { if (strcmp(v,"default")&&strcmp(v,"path")&&strcmp(v,"history")) { fprintf(stderr, "invalid scoring scheme: %s (expected: default|path|history)\n", v); exit(2); } }
        else if ((v = argval(&i, argc, argv, a, "--tiebreak", "criterion required"))) { if (strstr(v, "foo")) { fprintf(stderr, "invalid sort criterion: foo\n"); exit(2); } }
        else if ((v = argval(&i, argc, argv, a, "--color", "color required"))) { if (!strchr(v, ':') && strcmp(v,"dark") && strcmp(v,"light") && strcmp(v,"bw") && strcmp(v,"base16")) { fprintf(stderr, "invalid color specification: %s\n", v); exit(2); } }
        else if ((v = argval(&i, argc, argv, a, "--multi", ""))) { if (*v) parse_int_opt(v); }
        else if ((v = argval(&i, argc, argv, a, "--bind", "bind expression required"))) { (void)v; }
        else if ((v = argval(&i, argc, argv, a, "--expect", "key names required"))) { (void)v; }
        else if (starts(a, "--multi=")) parse_int_opt(a+8);
        else if (!strcmp(a, "-m") || !strcmp(a, "--multi")) {}
        else if (starts(a, "--")) {
            const char *eq = strchr(a, '=');
            if (eq) {
                char name[128]; size_t nl = (size_t)(eq - a); if (nl >= sizeof(name)) nl = sizeof(name)-1; memcpy(name, a, nl); name[nl] = 0;
                const char *known[] = {"--height","--min-height","--tmux","--layout","--margin","--padding","--border","--border-label","--border-label-pos","--preview","--preview-window","--preview-border","--preview-label","--preview-label-pos","--header","--header-border","--header-lines-border","--header-label","--header-label-pos","--footer","--footer-border","--footer-label","--footer-label-pos","--prompt","--info","--info-command","--separator","--ghost","--pointer","--marker","--ellipsis","--tabstop","--scrollbar","--list-border","--list-label","--list-label-pos","--input-border","--input-label","--input-label-pos","--walker","--walker-root","--walker-skip","--history","--history-size","--tail","--listen","--with-shell","--style","--gap","--gap-line","--freeze-left","--freeze-right","--scroll-off","--hscroll-off","--jump-labels","--gutter","--gutter-raw","--marker-multi-line",NULL};
                bool ok=false; for(int k=0; known[k]; k++) if(!strcmp(name,known[k])) ok=true;
                if (!ok) { fprintf(stderr, "unknown option: %s\n", a); exit(2); }
            } else {
                const char *known_no[] = {"--ansi","--sync","--no-color","--no-bold","--border","--highlight-line","--cycle","--wrap","--no-multi-line","--raw","--track","--keep-right","--no-hscroll","--no-scrollbar","--no-input","--header-first","--disabled","--literal","--filepath-word",NULL};
                bool ok=false; for(int k=0; known_no[k]; k++) if(!strcmp(a,known_no[k])) ok=true;
                if (!ok) {
                    if (i + 1 < argc && argv[i+1][0] != '-') i++;
                    else { fprintf(stderr, "unknown option: %s\n", a); exit(2); }
                }
            }
        }
    }
}

int main(int argc, char **argv) {
    Opt o = { .extended = true, .smart_case = true };
    char *file = getenv("FZF_DEFAULT_OPTS_FILE");
    if (file && *file) {
        FILE *fp = fopen(file, "r");
        if (fp) { char *line = NULL; size_t n = 0; while (getline(&line, &n, fp) > 0) parse_words_from_string(&o, line); free(line); fclose(fp); }
    }
    parse_words_from_string(&o, getenv("FZF_DEFAULT_OPTS"));
    parse_args(&o, argc, argv);
    const char *q = o.filter ? o.filter : (o.query ? o.query : "");

    if (!o.filter && isatty(STDIN_FILENO)) {
        char *cmd = getenv("FZF_DEFAULT_COMMAND");
        if (cmd && *cmd) {
            FILE *p = popen(cmd, "r");
            if (p) { int c; while ((c = fgetc(p)) != EOF) putchar(c); pclose(p); return 0; }
        }
    }

    int n = 0; Item *items = read_items(&o, &n);
    if (!o.filter && !(o.select1 && n == 1)) { fprintf(stderr, "inappropriate ioctl for device\n"); return 2; }

    Item **matches = NULL; int m = 0;
    for (int ii = 0; ii < n; ii++) {
        int i = o.tac ? (n - 1 - ii) : ii;
        if (i < o.header_lines) continue;
        items[i].view = project_fields(items[i].s, o.with_nth ? o.with_nth : o.nth, o.delimiter);
        char *search = o.nth && !o.with_nth ? project_fields(items[i].s, o.nth, o.delimiter) : xstrdup(items[i].view);
        int sc = 0;
        if (match_item(search, q, &o, &sc)) {
            items[i].score = sc; items[i].out = project_fields(items[i].s, o.accept_nth, o.delimiter);
            matches = realloc(matches, sizeof(Item*) * (m + 1)); matches[m++] = &items[i];
        }
        free(search);
    }
    if (!o.no_sort && !o.tac) qsort(matches, m, sizeof(Item*), cmp_item);
    if (o.select1 && !o.filter && m != 1) { fprintf(stderr, "inappropriate ioctl for device\n"); return 2; }
    if (o.exit0 && m == 0) return 0;
    char sep = o.print0 ? '\0' : '\n';
    if (o.print_query) { fputs(q, stdout); fputc(sep, stdout); }
    for (int i = 0; i < m; i++) { fputs(matches[i]->out ? matches[i]->out : matches[i]->s, stdout); fputc(sep, stdout); }
    return m ? 0 : 1;
}
