#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <regex.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct {
    char *name;
    char *path;
    char **tags;
    int ntags;
    int readonly;
} CheatPath;

typedef struct {
    char *title;
    char *file;
    int path_index;
    char **tags;
    int ntags;
    char *body;
} Sheet;

static CheatPath *paths = NULL;
static int npaths = 0;
static Sheet *sheets = NULL;
static int nsheets = 0;
static const char *prog = "cheat";
static char *config_editor = NULL;

static void die(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vfprintf(stderr, fmt, ap);
    va_end(ap);
    fputc('\n', stderr);
    exit(1);
}

static char *xstrdup(const char *s) {
    if (!s) return NULL;
    char *p = strdup(s);
    if (!p) die("out of memory");
    return p;
}

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = 0;
    return s;
}

static bool starts(const char *s, const char *p) {
    return strncmp(s, p, strlen(p)) == 0;
}

static char *strip_quotes(char *s) {
    s = trim(s);
    size_t n = strlen(s);
    if (n >= 2 && ((s[0] == '\'' && s[n-1] == '\'') || (s[0] == '"' && s[n-1] == '"'))) {
        s[n-1] = 0;
        return s + 1;
    }
    return s;
}

static char *expand_path(const char *in) {
    if (!in) return NULL;
    if (in[0] == '~' && (in[1] == '/' || in[1] == 0)) {
        const char *home = getenv("HOME");
        if (!home) home = "";
        char *out;
        if (asprintf(&out, "%s%s", home, in + 1) < 0) die("out of memory");
        return out;
    }
    return xstrdup(in);
}

static void add_tag(char ***tags, int *n, const char *tag) {
    if (!tag || !*tag) return;
    *tags = realloc(*tags, sizeof(char*) * (*n + 1));
    if (!*tags) die("out of memory");
    (*tags)[(*n)++] = xstrdup(tag);
}

static void parse_tags_value(const char *value, char ***tags, int *ntags) {
    char *tmp = xstrdup(value);
    char *s = trim(tmp);
    char *lb = strchr(s, '[');
    char *rb = strrchr(s, ']');
    if (lb && rb && rb > lb) {
        *rb = 0;
        s = lb + 1;
    }
    char *save = NULL;
    for (char *tok = strtok_r(s, ",", &save); tok; tok = strtok_r(NULL, ",", &save)) {
        tok = strip_quotes(tok);
        add_tag(tags, ntags, tok);
    }
    free(tmp);
}

static int tagcmp(const void *a, const void *b) {
    const char * const *aa = a, * const *bb = b;
    return strcmp(*aa, *bb);
}

static void sort_tags(char **tags, int n) {
    if (n > 1) qsort(tags, n, sizeof(char*), tagcmp);
}

static char *join_tags(char **tags, int n) {
    if (n == 0) return xstrdup("");
    size_t len = 1;
    for (int i = 0; i < n; i++) len += strlen(tags[i]) + 1;
    char *out = calloc(1, len);
    if (!out) die("out of memory");
    for (int i = 0; i < n; i++) {
        if (i) strcat(out, ",");
        strcat(out, tags[i]);
    }
    return out;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) != 0) { fclose(f); return NULL; }
    long n = ftell(f);
    if (n < 0) { fclose(f); return NULL; }
    rewind(f);
    char *buf = malloc((size_t)n + 1);
    if (!buf) die("out of memory");
    size_t got = fread(buf, 1, (size_t)n, f);
    buf[got] = 0;
    fclose(f);
    return buf;
}

static char *config_path(void) {
    const char *env = getenv("CHEAT_CONFIG_PATH");
    if (env && *env) return expand_path(env);
    const char *xdg = getenv("XDG_CONFIG_HOME");
    const char *home = getenv("HOME");
    char *candidates[4] = {0};
    int n = 0;
    if (xdg && *xdg) asprintf(&candidates[n++], "%s/cheat/conf.yml", xdg);
    if (home && *home) {
        asprintf(&candidates[n++], "%s/.config/cheat/conf.yml", home);
        asprintf(&candidates[n++], "%s/.cheat/conf.yml", home);
    }
    candidates[n++] = xstrdup("/etc/cheat/conf.yml");
    for (int i = 0; i < n; i++) {
        if (access(candidates[i], R_OK) == 0) {
            char *r = candidates[i];
            for (int j = 0; j < n; j++) if (j != i) free(candidates[j]);
            return r;
        }
    }
    char *def;
    if (home && *home) asprintf(&def, "%s/.config/cheat/conf.yml", home);
    else def = xstrdup("/etc/cheat/conf.yml");
    for (int j = 0; j < n; j++) free(candidates[j]);
    return def;
}

static void add_path(CheatPath cp) {
    paths = realloc(paths, sizeof(CheatPath) * (npaths + 1));
    if (!paths) die("out of memory");
    paths[npaths++] = cp;
}

static void maybe_add_dotcheat(void) {
    char cwd[4096];
    if (!getcwd(cwd, sizeof(cwd))) return;
    char cur[4096];
    snprintf(cur, sizeof(cur), "%s", cwd);
    while (1) {
        char cand[8192];
        snprintf(cand, sizeof(cand), "%s/.cheat", cur);
        struct stat st;
        if (stat(cand, &st) == 0 && S_ISDIR(st.st_mode)) {
            CheatPath cp = {0};
            cp.name = xstrdup(".cheat");
            cp.path = xstrdup(cand);
            cp.readonly = 0;
            add_tag(&cp.tags, &cp.ntags, ".cheat");
            add_path(cp);
            return;
        }
        if (strcmp(cur, "/") == 0) break;
        char *slash = strrchr(cur, '/');
        if (!slash || slash == cur) { strcpy(cur, "/"); }
        else *slash = 0;
    }
}

static void load_config(bool allow_missing) {
    char *cp = config_path();
    char *txt = read_file(cp);
    if (!txt) {
        if (allow_missing) { free(cp); return; }
        fprintf(stderr, "A config file was not found. Would you like to create one now? [Y/n]: failed to create config: failed to prompt: EOF\n");
        free(cp);
        exit(1);
    }
    CheatPath cur = {0};
    bool have = false;
    char *save = NULL;
    for (char *line = strtok_r(txt, "\n", &save); line; line = strtok_r(NULL, "\n", &save)) {
        char *s = trim(line);
        if (!*s || *s == '#') continue;
        if (!have && starts(s, "editor:")) {
            free(config_editor);
            config_editor = xstrdup(strip_quotes(s + 7));
        }
        if (starts(s, "- name:")) {
            if (have) add_path(cur);
            memset(&cur, 0, sizeof(cur));
            have = true;
            cur.name = xstrdup(strip_quotes(s + 7));
        } else if (have && starts(s, "name:")) {
            free(cur.name);
            cur.name = xstrdup(strip_quotes(s + 5));
        } else if (have && starts(s, "path:")) {
            free(cur.path);
            cur.path = expand_path(strip_quotes(s + 5));
        } else if (have && starts(s, "tags:")) {
            parse_tags_value(s + 5, &cur.tags, &cur.ntags);
        } else if (have && starts(s, "readonly:")) {
            char *v = trim(s + 9);
            cur.readonly = starts(v, "true");
        }
    }
    if (have) add_path(cur);
    free(txt);
    free(cp);
    maybe_add_dotcheat();
}

static char *body_without_frontmatter(const char *raw, char ***tags, int *ntags) {
    const char *body = raw;
    if (starts(raw, "---\n") || strcmp(raw, "---") == 0) {
        const char *p = raw + 4;
        const char *end = NULL;
        while (*p) {
            const char *line_end = strchr(p, '\n');
            size_t len = line_end ? (size_t)(line_end - p) : strlen(p);
            if (len == 3 && strncmp(p, "---", 3) == 0) {
                end = line_end ? line_end + 1 : p + len;
                break;
            }
            char *line = strndup(p, len);
            char *s = trim(line);
            if (starts(s, "tags:")) parse_tags_value(s + 5, tags, ntags);
            free(line);
            if (!line_end) break;
            p = line_end + 1;
        }
        if (end) body = end;
    }
    return xstrdup(body);
}

static void add_sheet(const char *title, const char *file, int pi) {
    char *raw = read_file(file);
    if (!raw) return;
    Sheet sh = {0};
    sh.title = xstrdup(title);
    sh.file = xstrdup(file);
    sh.path_index = pi;
    for (int i = 0; i < paths[pi].ntags; i++) add_tag(&sh.tags, &sh.ntags, paths[pi].tags[i]);
    sh.body = body_without_frontmatter(raw, &sh.tags, &sh.ntags);
    sort_tags(sh.tags, sh.ntags);
    free(raw);
    sheets = realloc(sheets, sizeof(Sheet) * (nsheets + 1));
    if (!sheets) die("out of memory");
    sheets[nsheets++] = sh;
}

static void scan_dir(int pi, const char *base, const char *rel) {
    char dirpath[8192];
    snprintf(dirpath, sizeof(dirpath), "%s%s%s", base, *rel ? "/" : "", rel);
    DIR *d = opendir(dirpath);
    if (!d) return;
    struct dirent *de;
    while ((de = readdir(d))) {
        if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) continue;
        if (de->d_name[0] == '.') continue;
        char childrel[8192], childpath[8192];
        snprintf(childrel, sizeof(childrel), "%s%s%s", rel, *rel ? "/" : "", de->d_name);
        snprintf(childpath, sizeof(childpath), "%s/%s", base, childrel);
        struct stat st;
        if (stat(childpath, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) scan_dir(pi, base, childrel);
        else if (S_ISREG(st.st_mode)) add_sheet(childrel, childpath, pi);
    }
    closedir(d);
}

static int sheetcmp(const void *a, const void *b) {
    const Sheet *aa = a, *bb = b;
    int c = strcmp(aa->title, bb->title);
    if (c) return c;
    return aa->path_index - bb->path_index;
}

static void load_sheets(void) {
    for (int i = 0; i < npaths; i++) scan_dir(i, paths[i].path, "");
    if (nsheets > 1) qsort(sheets, nsheets, sizeof(Sheet), sheetcmp);
}

static bool has_tag(Sheet *s, const char *tag) {
    if (!tag) return true;
    for (int i = 0; i < s->ntags; i++) if (strcmp(s->tags[i], tag) == 0) return true;
    return false;
}

static bool path_match(Sheet *s, const char *path) {
    if (!path) return true;
    return strcmp(paths[s->path_index].name, path) == 0;
}

static bool title_filter(Sheet *s, const char *f) {
    if (!f) return true;
    return strstr(s->title, f) != NULL;
}

static void print_table(bool brief, const char *tag, const char *path, const char *filter) {
    int tw = 6, fw = 5;
    for (int i = 0; i < nsheets; i++) {
        Sheet *s = &sheets[i];
        if (!has_tag(s, tag) || !path_match(s, path) || !title_filter(s, filter)) continue;
        int tl = (int)strlen(s->title);
        if (tl > tw) tw = tl;
        int fl = (int)strlen(s->file);
        if (fl > fw) fw = fl;
    }
    if (brief) {
        printf("%-*s %s\n", tw, "title:", "tags:");
        for (int i = 0; i < nsheets; i++) {
            Sheet *s = &sheets[i];
            if (!has_tag(s, tag) || !path_match(s, path) || !title_filter(s, filter)) continue;
            char *jt = join_tags(s->tags, s->ntags);
            printf("%-*s %s\n", tw, s->title, jt);
            free(jt);
        }
    } else {
        printf("%-*s %-*s %s\n", tw, "title:", fw, "file:", "tags:");
        for (int i = 0; i < nsheets; i++) {
            Sheet *s = &sheets[i];
            if (!has_tag(s, tag) || !path_match(s, path) || !title_filter(s, filter)) continue;
            char *jt = join_tags(s->tags, s->ntags);
            printf("%-*s %-*s %s\n", tw, s->title, fw, s->file, jt);
            free(jt);
        }
    }
}

static void print_body_indented(const char *body) {
    const char *p = body;
    while (*p) {
        putchar('\t');
        const char *nl = strchr(p, '\n');
        if (nl) {
            fwrite(p, 1, (size_t)(nl - p + 1), stdout);
            p = nl + 1;
        } else {
            fputs(p, stdout);
            break;
        }
    }
}

static bool content_match(Sheet *s, const char *phrase, bool regex_mode) {
    if (!phrase) return true;
    if (!regex_mode) return strstr(s->body, phrase) != NULL;
    regex_t re;
    if (regcomp(&re, phrase, REG_EXTENDED | REG_NOSUB) != 0) return false;
    int ok = regexec(&re, s->body, 0, NULL, 0) == 0;
    regfree(&re);
    return ok;
}

static void print_multi(Sheet **arr, int n) {
    for (int i = 0; i < n; i++) {
        Sheet *s = arr[i];
        printf("%s (%s)\n", s->title, paths[s->path_index].name);
        print_body_indented(s->body);
        if (i != n - 1) printf("\n");
    }
}

static int view_sheet(const char *title, bool all, const char *tag, const char *path) {
    Sheet **matches = NULL;
    int n = 0;
    for (int i = 0; i < nsheets; i++) {
        Sheet *s = &sheets[i];
        if (strcmp(s->title, title) || !has_tag(s, tag) || !path_match(s, path)) continue;
        matches = realloc(matches, sizeof(Sheet*) * (n + 1));
        matches[n++] = s;
    }
    if (n == 0) {
        fprintf(stderr, "No cheatsheet found for '%s'.\n", title);
        free(matches);
        return 2;
    }
    if (all || n > 1 && tag) print_multi(matches, n);
    else fputs(matches[n-1]->body, stdout);
    free(matches);
    return 0;
}

static void search_sheets(const char *phrase, bool regex_mode, const char *tag, const char *path) {
    Sheet **matches = NULL;
    int n = 0;
    for (int i = 0; i < nsheets; i++) {
        Sheet *s = &sheets[i];
        if (!has_tag(s, tag) || !path_match(s, path) || !content_match(s, phrase, regex_mode)) continue;
        matches = realloc(matches, sizeof(Sheet*) * (n + 1));
        matches[n++] = s;
    }
    print_multi(matches, n);
    free(matches);
}

static void list_dirs(void) {
    int w = 0;
    for (int i = 0; i < npaths; i++) {
        int l = (int)strlen(paths[i].name) + 1;
        if (l > w) w = l;
    }
    for (int i = 0; i < npaths; i++) {
        char *label;
        if (asprintf(&label, "%s:", paths[i].name) < 0) die("out of memory");
        printf("%-*s %s\n", w, label, paths[i].path);
        free(label);
    }
}

static void list_tags(void) {
    char **tags = NULL;
    int n = 0;
    for (int i = 0; i < nsheets; i++) {
        for (int j = 0; j < sheets[i].ntags; j++) {
            bool seen = false;
            for (int k = 0; k < n; k++) if (strcmp(tags[k], sheets[i].tags[j]) == 0) seen = true;
            if (!seen) add_tag(&tags, &n, sheets[i].tags[j]);
        }
    }
    sort_tags(tags, n);
    for (int i = 0; i < n; i++) printf("%s\n", tags[i]);
}

static void print_help(void) {
    puts("cheat allows you to create and view interactive cheatsheets on the\n"
         "command-line. It was designed to help remind *nix system administrators of\n"
         "options for commands that they use frequently, but not frequently enough to\n"
         "remember.\n\n"
         "Usage:\n  cheat [cheatsheet] [flags]\n\n"
         "Flags:\n"
         "  -a, --all                Search among all cheatpaths\n"
         "  -b, --brief              List cheatsheets without file paths\n"
         "  -c, --colorize           Colorize output\n"
         "      --completion shell   Generate shell completion script (shell: bash, zsh, fish, powershell)\n"
         "      --conf               Display the config file path\n"
         "  -d, --directories        List cheatsheet directories\n"
         "  -e, --edit cheatsheet    Edit cheatsheet\n"
         "  -h, --help               help for cheat\n"
         "      --init               Write a default config file to stdout\n"
         "  -l, --list               List cheatsheets\n"
         "  -p, --path name          Return only sheets found on cheatpath name\n"
         "  -r, --regex              Treat search <phrase> as a regex\n"
         "      --rm cheatsheet      Remove (delete) cheatsheet\n"
         "  -s, --search phrase      Search cheatsheets for phrase\n"
         "  -t, --tag tag            Return only sheets matching tag\n"
         "  -T, --tags               List all tags in use\n"
         "  -u, --update             Update git-backed cheatpaths\n"
         "  -v, --version            Print the version number");
}

static void print_init(void) {
    const char *home = getenv("HOME");
    if (!home) home = "/home/agent";
    printf("---\n"
           "# The editor to use with 'cheat -e <sheet>'. Overridden by $VISUAL or $EDITOR.\n"
           "editor: EDITOR_PATH\n\n"
           "colorize: false\n\n"
           "style: monokai\n\n"
           "formatter: terminal256\n\n"
           "pager: /usr/bin/pager\n\n"
           "cheatpaths:\n\n"
           "  - name: personal\n"
           "    path: %s/.config/cheat/cheatsheets/personal\n"
           "    tags: [ personal ]\n"
           "    readonly: false\n\n"
           "  - name: work\n"
           "    path: %s/.config/cheat/cheatsheets/work\n"
           "    tags: [ work ]\n"
           "    readonly: false\n", home, home);
}

static void completion(const char *shell) {
    if (!shell) shell = "";
    if (strcmp(shell, "bash") == 0) puts("# bash completion V2 for cheat\ncomplete -F _cheat cheat");
    else if (strcmp(shell, "zsh") == 0) puts("#compdef cheat\ncompdef _cheat cheat");
    else if (strcmp(shell, "fish") == 0) puts("# fish completion for cheat");
    else if (strcmp(shell, "powershell") == 0) puts("# powershell completion for cheat");
    else die("invalid argument \"%s\" for \"--completion\" flag: valid values are bash, zsh, fish, powershell", shell);
}

static CheatPath *find_write_path(const char *pname) {
    CheatPath *fallback = NULL;
    for (int i = 0; i < npaths; i++) {
        if (pname && strcmp(paths[i].name, pname) != 0) continue;
        if (!paths[i].readonly) fallback = &paths[i];
    }
    return fallback;
}

static char *path_join(const char *a, const char *b) {
    char *out;
    asprintf(&out, "%s/%s", a, b);
    return out;
}

static void mkdir_parent(const char *file) {
    char *tmp = xstrdup(file);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    free(tmp);
}

static int edit_sheet(const char *title, const char *pname) {
    CheatPath *cp = find_write_path(pname);
    if (!cp) die("no writeable cheatpath found");
    char *file = path_join(cp->path, title);
    mkdir_parent(file);
    const char *ed = getenv("VISUAL");
    if (!ed || !*ed) ed = getenv("EDITOR");
    if (!ed || !*ed) ed = config_editor;
    if (!ed || !*ed) ed = "vi";
    char *cmd;
    asprintf(&cmd, "%s '%s'", ed, file);
    int rc = system(cmd);
    free(cmd);
    free(file);
    if (rc == -1) return 1;
    if (WIFEXITED(rc)) return WEXITSTATUS(rc);
    return 1;
}

static int remove_sheet(const char *title, const char *tag, const char *path) {
    Sheet *target = NULL;
    for (int i = 0; i < nsheets; i++) {
        Sheet *s = &sheets[i];
        if (strcmp(s->title, title) == 0 && has_tag(s, tag) && path_match(s, path)) target = s;
    }
    if (!target) {
        fprintf(stderr, "No cheatsheet found for '%s'.\n", title);
        return 2;
    }
    if (unlink(target->file) != 0) die("failed to remove %s: %s", title, strerror(errno));
    return 0;
}

static void update_paths(const char *pname) {
    for (int i = 0; i < npaths; i++) {
        if (pname && strcmp(paths[i].name, pname) != 0) continue;
        char gitdir[8192];
        snprintf(gitdir, sizeof(gitdir), "%s/.git", paths[i].path);
        struct stat st;
        if (stat(gitdir, &st) != 0) printf("%s: skipped (not a git repository)\n", paths[i].name);
        else printf("%s: updating\n", paths[i].name);
    }
}

int main(int argc, char **argv) {
    prog = argv[0];
    bool opt_all=false, opt_brief=false, opt_dirs=false, opt_list=false, opt_regex=false, opt_tags=false, opt_update=false, opt_color=false;
    char *opt_path=NULL, *opt_tag=NULL, *opt_search=NULL, *opt_edit=NULL, *opt_rm=NULL, *completion_shell=NULL;
    char *positional=NULL;
    bool opt_conf=false, opt_init=false, opt_version=false, opt_help=false;
    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (strcmp(a, "--") == 0) continue;
        if (strcmp(a, "-h") == 0 || strcmp(a, "--help") == 0) opt_help = true;
        else if (strcmp(a, "-v") == 0 || strcmp(a, "--version") == 0) opt_version = true;
        else if (strcmp(a, "--init") == 0) opt_init = true;
        else if (strcmp(a, "--conf") == 0) opt_conf = true;
        else if (strcmp(a, "-a") == 0 || strcmp(a, "--all") == 0) opt_all = true;
        else if (strcmp(a, "-b") == 0 || strcmp(a, "--brief") == 0) opt_brief = true;
        else if (strcmp(a, "-c") == 0 || strcmp(a, "--colorize") == 0) opt_color = true;
        else if (strcmp(a, "-d") == 0 || strcmp(a, "--directories") == 0) opt_dirs = true;
        else if (strcmp(a, "-l") == 0 || strcmp(a, "--list") == 0) opt_list = true;
        else if (strcmp(a, "-r") == 0 || strcmp(a, "--regex") == 0) opt_regex = true;
        else if (strcmp(a, "-T") == 0 || strcmp(a, "--tags") == 0) opt_tags = true;
        else if (strcmp(a, "-u") == 0 || strcmp(a, "--update") == 0) opt_update = true;
        else if ((strcmp(a, "-p") == 0 || strcmp(a, "--path") == 0) && i+1 < argc) opt_path = argv[++i];
        else if (starts(a, "--path=")) opt_path = a + 7;
        else if ((strcmp(a, "-t") == 0 || strcmp(a, "--tag") == 0) && i+1 < argc) opt_tag = argv[++i];
        else if (starts(a, "--tag=")) opt_tag = a + 6;
        else if ((strcmp(a, "-s") == 0 || strcmp(a, "--search") == 0) && i+1 < argc) opt_search = argv[++i];
        else if (starts(a, "--search=")) opt_search = a + 9;
        else if ((strcmp(a, "-e") == 0 || strcmp(a, "--edit") == 0) && i+1 < argc) opt_edit = argv[++i];
        else if (starts(a, "--edit=")) opt_edit = a + 7;
        else if (strcmp(a, "--rm") == 0 && i+1 < argc) opt_rm = argv[++i];
        else if (starts(a, "--rm=")) opt_rm = a + 5;
        else if (strcmp(a, "--completion") == 0 && i+1 < argc) completion_shell = argv[++i];
        else if (starts(a, "--completion=")) completion_shell = a + 13;
        else if (a[0] == '-') die("unknown flag: %s", a);
        else positional = a;
    }
    (void)prog; (void)opt_color;
    if (opt_help) { print_help(); return 0; }
    if (opt_version) { puts("5.1.0"); return 0; }
    if (opt_init) { print_init(); return 0; }
    if (completion_shell) { completion(completion_shell); return 0; }
    if (opt_conf) {
        char *cp = config_path();
        if (access(cp, R_OK) != 0) {
            fprintf(stderr, "A config file was not found. Would you like to create one now? [Y/n]: failed to create config: failed to prompt: EOF\n");
            free(cp);
            return 1;
        }
        puts(cp);
        free(cp);
        return 0;
    }
    load_config(false);
    if (opt_dirs) { list_dirs(); return 0; }
    if (opt_edit) return edit_sheet(opt_edit, opt_path);
    load_sheets();
    if (opt_rm) return remove_sheet(opt_rm, opt_tag, opt_path);
    if (opt_update) { update_paths(opt_path); return 0; }
    if (opt_tags) { list_tags(); return 0; }
    if (opt_list || opt_brief) { print_table(opt_brief, opt_tag, opt_path, positional); return 0; }
    if (opt_search) { search_sheets(opt_search, opt_regex, opt_tag, opt_path); return 0; }
    if (positional) return view_sheet(positional, opt_all, opt_tag, opt_path);
    print_help();
    return 0;
}
