#define _GNU_SOURCE
#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
    int code, line, col, start, end;
    char title[96], msg[256], repl[256];
    int fixable;
} Diag;

typedef struct {
    Diag *v;
    size_t n, cap;
} Diags;

static const char *lint_list =
"W01 bool_comparison\n"
"W02 empty_let_in\n"
"W03 manual_inherit\n"
"W04 manual_inherit_from\n"
"W05 legacy_let_syntax\n"
"W06 collapsible_let_in\n"
"W07 eta_reduction\n"
"W08 useless_parens\n"
"W10 empty_pattern\n"
"W11 redundant_pattern_bind\n"
"W12 unquoted_uri\n"
"W14 empty_inherit\n"
"W17 deprecated_to_path\n"
"W18 bool_simplification\n"
"W19 useless_has_attr\n"
"W20 repeated_keys\n"
"W23 empty_list_concat\n";

static char *read_stream(FILE *f) {
    size_t cap = 8192, n = 0;
    char *b = malloc(cap + 1);
    if (!b) exit(2);
    for (;;) {
        if (n == cap) { cap *= 2; b = realloc(b, cap + 1); if (!b) exit(2); }
        size_t r = fread(b + n, 1, cap - n, f);
        n += r;
        if (r == 0) break;
    }
    b[n] = 0;
    return b;
}

static char *read_file(const char *path) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    char *s = read_stream(f);
    fclose(f);
    return s;
}

static int write_file(const char *path, const char *s) {
    FILE *f = fopen(path, "wb");
    if (!f) return -1;
    fputs(s, f);
    fclose(f);
    return 0;
}

static void add_diag(Diags *ds, Diag d) {
    if (ds->n == ds->cap) {
        ds->cap = ds->cap ? ds->cap * 2 : 16;
        ds->v = realloc(ds->v, ds->cap * sizeof(Diag));
        if (!ds->v) exit(2);
    }
    ds->v[ds->n++] = d;
}

static int is_ident_char(int c) { return isalnum((unsigned char)c) || c == '_' || c == '-' || c == '\''; }
static int is_ident_start(int c) { return isalpha((unsigned char)c) || c == '_'; }

static void loc_of(const char *s, int pos, int *line, int *col) {
    *line = 1; *col = 1;
    for (int i = 0; i < pos && s[i]; i++) {
        if (s[i] == '\n') { (*line)++; *col = 1; }
        else (*col)++;
    }
}

static int word_at(const char *s, int i, const char *w) {
    int n = (int)strlen(w);
    if (strncmp(s + i, w, n) != 0) return 0;
    if (i > 0 && is_ident_char(s[i - 1])) return 0;
    if (is_ident_char(s[i + n])) return 0;
    return 1;
}

static char *substr(const char *s, int a, int b) {
    if (b < a) b = a;
    char *r = malloc((size_t)(b - a) + 1);
    memcpy(r, s + a, (size_t)(b - a));
    r[b - a] = 0;
    return r;
}

static char *trim_dup(const char *s, int a, int b) {
    while (a < b && isspace((unsigned char)s[a])) a++;
    while (b > a && isspace((unsigned char)s[b - 1])) b--;
    return substr(s, a, b);
}

static int parse_ident_left(const char *s, int op, int *a, int *b) {
    int j = op - 1;
    while (j >= 0 && isspace((unsigned char)s[j])) j--;
    int e = j + 1;
    while (j >= 0 && is_ident_char(s[j])) j--;
    int st = j + 1;
    if (st >= e || !is_ident_start(s[st])) return 0;
    *a = st; *b = e; return 1;
}

static int parse_ident_right(const char *s, int op_end, int *a, int *b) {
    int j = op_end;
    while (s[j] && isspace((unsigned char)s[j])) j++;
    int st = j;
    if (!is_ident_start(s[j])) return 0;
    while (is_ident_char(s[j])) j++;
    *a = st; *b = j; return 1;
}

static void scan_lints(const char *text, Diags *ds) {
    int len = (int)strlen(text);
    for (int i = 0; i < len; i++) {
        if ((text[i] == '=' && text[i+1] == '=') || (text[i] == '!' && text[i+1] == '=')) {
            int la, lb, ra, rb;
            if (parse_ident_left(text, i, &la, &lb) && parse_ident_right(text, i+2, &ra, &rb)) {
                char *left = substr(text, la, lb), *right = substr(text, ra, rb);
                int lit_right = !strcmp(right, "true") || !strcmp(right, "false");
                if (lit_right) {
                    Diag d = {0}; d.code = 1; d.start = la; d.end = rb; d.fixable = 1;
                    loc_of(text, la, &d.line, &d.col);
                    strcpy(d.title, "Unnecessary comparison with boolean");
                    snprintf(d.msg, sizeof d.msg, "Comparing `%s` with boolean literal `%s`", left, right);
                    int eq = text[i] == '=';
                    int truth = !strcmp(right, "true");
                    snprintf(d.repl, sizeof d.repl, "%s%s", (eq == truth) ? "" : "!", left);
                    add_diag(ds, d);
                }
                free(left); free(right);
            }
        }
        if (word_at(text, i, "let")) {
            int j = i + 3;
            while (text[j] && isspace((unsigned char)text[j])) j++;
            if (word_at(text, j, "in")) {
                int k = j + 2;
                while (text[k] && isspace((unsigned char)text[k])) k++;
                int e = k;
                while (text[e] && text[e] != '\n' && text[e] != ';' && text[e] != '}') e++;
                char *body = trim_dup(text, k, e);
                Diag d = {0}; d.code = 2; d.start = i; d.end = e; d.fixable = 1;
                loc_of(text, i, &d.line, &d.col);
                strcpy(d.title, "Useless let-in expression");
                strcpy(d.msg, "This let-in expression has no entries");
                snprintf(d.repl, sizeof d.repl, "%s", body);
                add_diag(ds, d);
                free(body);
            }
        }
        if (text[i] == '=' && text[i+1] != '=') {
            int la, lb, ra, rb;
            if (parse_ident_left(text, i, &la, &lb) && parse_ident_right(text, i+1, &ra, &rb)) {
                int j = rb; while (isspace((unsigned char)text[j])) j++;
                if (text[j] == ';' && lb-la == rb-ra && strncmp(text+la, text+ra, (size_t)(lb-la)) == 0) {
                    char *name = substr(text, la, lb);
                    int st = la; while (st > 0 && (text[st-1] == ' ' || text[st-1] == '\t')) st--;
                    Diag d = {0}; d.code = 3; d.start = st; d.end = j + 1; d.fixable = 1;
                    loc_of(text, la, &d.line, &d.col);
                    strcpy(d.title, "Assignment instead of inherit");
                    strcpy(d.msg, "This assignment is better written with `inherit`");
                    snprintf(d.repl, sizeof d.repl, "%.*sinherit %s;", la-st, text+st, name);
                    add_diag(ds, d); free(name);
                }
            }
            if (parse_ident_left(text, i, &la, &lb)) {
                int r = i + 1;
                while (isspace((unsigned char)text[r])) r++;
                int path_start = r, last_start = r, ok = 0;
                while (is_ident_char(text[r]) || text[r] == '.') {
                    if (text[r] == '.') { last_start = r + 1; ok = 1; }
                    r++;
                }
                int j = r; while (isspace((unsigned char)text[j])) j++;
                if (ok && text[j] == ';' && lb-la == r-last_start && strncmp(text+la, text+last_start, (size_t)(lb-la)) == 0) {
                    char *name = substr(text, la, lb);
                    char *base = substr(text, path_start, last_start - 1);
                    int st = la; while (st > 0 && (text[st-1] == ' ' || text[st-1] == '\t')) st--;
                    Diag d = {0}; d.code = 4; d.start = st; d.end = j + 1; d.fixable = 1;
                    loc_of(text, la, &d.line, &d.col);
                    strcpy(d.title, "Assignment instead of inherit from");
                    strcpy(d.msg, "This assignment is better written with `inherit`");
                    snprintf(d.repl, sizeof d.repl, "%.*sinherit (%s) %s;", la-st, text+st, base, name);
                    add_diag(ds, d);
                    free(name); free(base);
                }
            }
        }
        if (word_at(text, i, "inherit")) {
            int j = i + 7; while (isspace((unsigned char)text[j])) j++;
            if (text[j] == ';') {
                int st = i; while (st > 0 && (text[st-1] == ' ' || text[st-1] == '\t')) st--;
                Diag d = {0}; d.code = 14; d.start = st; d.end = j + 1; d.fixable = 1;
                loc_of(text, i, &d.line, &d.col);
                strcpy(d.title, "Empty inherit");
                strcpy(d.msg, "Remove this empty `inherit` statement");
                d.repl[0] = 0; add_diag(ds, d);
            }
        }
        if (strncmp(text + i, "builtins.toPath", 15) == 0) {
            Diag d = {0}; d.code = 17; d.start = i; d.end = i + 15; d.fixable = 0;
            loc_of(text, i, &d.line, &d.col);
            strcpy(d.title, "Deprecated `toPath`");
            strcpy(d.msg, "`builtins.toPath` is deprecated, see `:doc builtins.toPath` within the REPL for more");
            add_diag(ds, d);
        }
        if (text[i] == '{') {
            int j = i + 1; while (isspace((unsigned char)text[j])) j++;
            if (text[j] == '.' && text[j+1] == '.' && text[j+2] == '.') {
                int k = j + 3; while (isspace((unsigned char)text[k])) k++;
                if (text[k] == '}') {
                    int m = k + 1; while (isspace((unsigned char)text[m])) m++;
                    int p = i - 1; while (p >= 0 && isspace((unsigned char)text[p])) p--;
                    if (text[m] == ':' && p >= 0 && text[p] != '@') {
                        Diag d = {0}; d.code = 10; d.start = i; d.end = k + 1; d.fixable = 1;
                        loc_of(text, i, &d.line, &d.col);
                        strcpy(d.title, "Empty pattern");
                        strcpy(d.msg, "This pattern is empty, use `_` instead");
                        strcpy(d.repl, "_"); add_diag(ds, d);
                    }
                }
            }
        }
        if (is_ident_start(text[i])) {
            int a = i, b = i; while (is_ident_char(text[b])) b++;
            int j = b; while (isspace((unsigned char)text[j])) j++;
            if (text[j] == '@') {
                int k = j + 1; while (isspace((unsigned char)text[k])) k++;
                if (text[k] == '{') {
                    int p = k + 1; while (isspace((unsigned char)text[p])) p++;
                    if (text[p] == '.' && text[p+1] == '.' && text[p+2] == '.') {
                        p += 3; while (isspace((unsigned char)text[p])) p++;
                        if (text[p] == '}') {
                            char *name = substr(text, a, b);
                            Diag d = {0}; d.code = 11; d.start = a; d.end = p + 1; d.fixable = 1;
                            loc_of(text, a, &d.line, &d.col);
                            strcpy(d.title, "Redundant pattern bind");
                            snprintf(d.msg, sizeof d.msg, "This pattern bind is redundant, use `%s` instead", name);
                            snprintf(d.repl, sizeof d.repl, "%s", name); add_diag(ds, d);
                            free(name);
                        }
                    }
                }
            }
            i = b - 1;
        }
        if (text[i] == '[') {
            int j = i + 1; while (isspace((unsigned char)text[j])) j++;
            if (text[j] == ']') {
                int k = j + 1; while (isspace((unsigned char)text[k])) k++;
                if (text[k] == '+' && text[k+1] == '+') {
                    int v = k + 2; while (isspace((unsigned char)text[v])) v++;
                    int e = v; while (text[e] && text[e] != '\n' && text[e] != ';' && text[e] != ')') e++;
                    char *rhs = trim_dup(text, v, e);
                    Diag d = {0}; d.code = 23; d.start = i; d.end = e; d.fixable = 1;
                    loc_of(text, i, &d.line, &d.col);
                    strcpy(d.title, "Empty list concat");
                    strcpy(d.msg, "Concatenation with the empty list, `[]`, is a no-op");
                    snprintf(d.repl, sizeof d.repl, "%s", rhs); add_diag(ds, d);
                    free(rhs);
                }
            }
        }
    }
}

static void print_diag(const char *path, const char *text, const Diag *d, int errfmt) {
    (void)text;
    if (errfmt) {
        printf("%s>%d:%d:W:%d:%s\n", path, d->line, d->col, d->code, d->msg);
    } else {
        printf("[W%02d] Warning: %s\n   --> %s:%d:%d\n    |\n%4d | %s\n    = %s\n",
               d->code, d->title, path, d->line, d->col, d->line, "", d->msg);
    }
}

static char *apply_fixes(const char *text, Diags *ds) {
    size_t cap = strlen(text) + 1024, n = 0;
    char *out = malloc(cap);
    int pos = 0;
    for (size_t i = 0; i < ds->n; i++) {
        Diag *d = &ds->v[i];
        if (!d->fixable || d->start < pos) continue;
        size_t chunk = (size_t)(d->start - pos), rlen = strlen(d->repl);
        while (n + chunk + rlen + 2 > cap) { cap *= 2; out = realloc(out, cap); }
        memcpy(out + n, text + pos, chunk); n += chunk;
        memcpy(out + n, d->repl, rlen); n += rlen;
        pos = d->end;
    }
    size_t rest = strlen(text + pos);
    while (n + rest + 1 > cap) { cap *= 2; out = realloc(out, cap); }
    memcpy(out + n, text + pos, rest + 1);
    return out;
}

static void print_diff(const char *path, const char *old, const char *new) {
    printf("--- %s\n+++ %s [fixed]\n", path, path);
    int old_lines = 1, new_lines = 1;
    for (const char *p = old; *p; p++) if (*p == '\n' && p[1]) old_lines++;
    for (const char *p = new; *p; p++) if (*p == '\n' && p[1]) new_lines++;
    printf("@@ -1,%d +1,%d @@\n", old_lines, new_lines);
    char *o = strdup(old), *nn = strdup(new);
    char *save = NULL, *line = strtok_r(o, "\n", &save);
    while (line) { printf("-%s\n", line); line = strtok_r(NULL, "\n", &save); }
    save = NULL; line = strtok_r(nn, "\n", &save);
    while (line) { printf("+%s\n", line); line = strtok_r(NULL, "\n", &save); }
    printf("\n");
    free(o); free(nn);
}

static int process_one(const char *path, int check, int errfmt, int dry, int inplace, int stdin_mode) {
    char *text = stdin_mode ? read_stream(stdin) : read_file(path);
    if (!text) { fprintf(stderr, "error: could not read `%s`: %s\n", path, strerror(errno)); return 1; }
    Diags ds = {0}; scan_lints(text, &ds);
    if (check) {
        for (size_t i = 0; i < ds.n; i++) print_diag(path, text, &ds.v[i], errfmt);
    } else {
        char *fixed = apply_fixes(text, &ds);
        if (strcmp(text, fixed) != 0) {
            if (stdin_mode) printf("%s", fixed);
            else if (dry) print_diff(path, text, fixed);
            else if (inplace) write_file(path, fixed);
        }
        free(fixed);
    }
    int ret = ds.n ? 1 : 0;
    free(ds.v); free(text);
    return ret;
}

static int has_suffix(const char *s, const char *suf) {
    size_t a = strlen(s), b = strlen(suf);
    return a >= b && strcmp(s + a - b, suf) == 0;
}

static int walk(const char *path, int check, int errfmt, int dry, int inplace) {
    struct stat st;
    if (stat(path, &st) != 0) { fprintf(stderr, "error: could not access `%s`\n", path); return 1; }
    if (S_ISDIR(st.st_mode)) {
        int any = 0;
        DIR *d = opendir(path); if (!d) return 1;
        struct dirent *e;
        while ((e = readdir(d))) {
            if (e->d_name[0] == '.') continue;
            char buf[4096]; snprintf(buf, sizeof buf, "%s/%s", path, e->d_name);
            any |= walk(buf, check, errfmt, dry, inplace);
        }
        closedir(d); return any;
    }
    if (!has_suffix(path, ".nix")) return 0;
    return process_one(path, check, errfmt, dry, inplace, 0);
}

static void top_help(void) {
    puts("statix 0.5.8\n\nAkshay <nerdy@peppe.rs>\n\nLints and suggestions for the Nix programming language\n\nUSAGE:\n    executable <SUBCOMMAND>\n\nOPTIONS:\n    -h, --help       Print help information\n    -V, --version    Print version information\n\nSUBCOMMANDS:\n    check      Lints and suggestions for the nix programming language\n    dump       Dump a sample config to stdout\n    explain    Print detailed explanation for a lint warning\n    fix        Find and fix issues raised by statix-check\n    help       Print this message or the help of the given subcommand(s)\n    list       List all available lints\n    single     Fix exactly one issue at provided position");
}

static void sub_help(const char *c) {
    if (!strcmp(c, "check")) puts("executable-check \n\nLints and suggestions for the nix programming language\n\nUSAGE:\n    executable check [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run check on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -o, --format <FORMAT>       Output format. Supported values: stderr, errfmt [default: stderr]\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files");
    else if (!strcmp(c, "fix")) puts("executable-fix \n\nFind and fix issues raised by statix-check\n\nUSAGE:\n    executable fix [OPTIONS] [--] [TARGET]\n\nARGS:\n    <TARGET>    File or directory to run fix on [default: .]\n\nOPTIONS:\n    -c, --config <CONF_PATH>    Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run               Do not fix files in place, display a diff instead\n    -h, --help                  Print help information\n    -i, --ignore <IGNORE>...    Globs of file patterns to skip\n    -s, --stdin                 Enable \"streaming\" mode, accept file on stdin, output diagnostics on\n                                stdout\n    -u, --unrestricted          Don't respect .gitignore files");
    else if (!strcmp(c, "dump")) puts("executable-dump \n\nDump a sample config to stdout\n\nUSAGE:\n    executable dump\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c, "list")) puts("executable-list \n\nList all available lints\n\nUSAGE:\n    executable list\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c, "explain")) puts("executable-explain \n\nPrint detailed explanation for a lint warning\n\nUSAGE:\n    executable explain <TARGET>\n\nARGS:\n    <TARGET>    Warning code to explain\n\nOPTIONS:\n    -h, --help    Print help information");
    else if (!strcmp(c, "single")) puts("executable-single \n\nFix exactly one issue at provided position\n\nUSAGE:\n    executable single [OPTIONS] --position <POSITION> [TARGET]\n\nARGS:\n    <TARGET>    File to run single-fix on\n\nOPTIONS:\n    -c, --config <CONF_PATH>     Path to statix.toml or its parent directory [default: .]\n    -d, --dry-run                Do not fix files in place, display a diff instead\n    -h, --help                   Print help information\n    -p, --position <POSITION>    Position to attempt a fix at\n    -s, --stdin                  Enable \"streaming\" mode, accept file on stdin, output diagnostics\n                                 on stdout");
}

static void explain(int code) {
    switch (code) {
    case 1: puts("## What it does\nChecks for expressions of the form `x == true`, `x != true` and\nsuggests using the variable directly.\n\n## Why is this bad?\nUnnecessary code.\n\n## Example\nInstead of checking the value of `x`:\n\n```nix\nif x == true then 0 else 1\n```\n\nUse `x` directly:\n\n```nix\nif x then 0 else 1\n```"); break;
    case 2: puts("## What it does\nChecks for `let-in` expressions which create no new bindings.\n\n## Why is this bad?\n`let-in` expressions that create no new bindings are useless.\nThese are probably remnants from debugging or editing expressions.\n\n## Example\n\n```nix\nlet in pkgs.statix\n```\n\nPreserve only the body of the `let-in` expression:\n\n```nix\npkgs.statix\n```"); break;
    case 3: puts("## What it does\nChecks for bindings of the form `a = a`.\n\n## Why is this bad?\nIf the aim is to bring attributes from a larger scope into\nthe current scope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  a = 2;\nin\n  { a = a; b = 3; }\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  a = 2;\nin\n  { inherit a; b = 3; }\n```"); break;
    case 4: puts("## What it does\nChecks for bindings of the form `a = someAttr.a`.\n\n## Why is this bad?\nIf the aim is to extract or bring attributes of an attrset into\nscope, prefer an inherit statement.\n\n## Example\n\n```nix\nlet\n  mtl = pkgs.haskellPackages.mtl;\nin\n  null\n```\n\nTry `inherit` instead:\n\n```nix\nlet\n  inherit (pkgs.haskellPackages) mtl;\nin\n  null\n```"); break;
    case 10: puts("## What it does\nChecks for an empty variadic pattern: `{...}`, in a function\nargument.\n\n## Why is this bad?\nThe intention with empty patterns is not instantly obvious. Prefer\nan underscore identifier instead, to indicate that the argument\nis being ignored.\n\n## Example\n\n```nix\nclient = { ... }: {\n  services.irmaseal-pkg.enable = true;\n};\n```\n\nReplace the empty variadic pattern with `_` to indicate that you\nintend to ignore the argument:\n\n```nix\nclient = _: {\n  services.irmaseal-pkg.enable = true;\n};\n```"); break;
    default: printf("explain error: lint with code `%d` not found\n", code); exit(1);
    }
}

int main(int argc, char **argv) {
    if (argc < 2 || !strcmp(argv[1], "--help") || !strcmp(argv[1], "-h") || !strcmp(argv[1], "help")) { top_help(); return 0; }
    if (!strcmp(argv[1], "--version") || !strcmp(argv[1], "-V")) { puts("statix 0.5.8"); return 0; }
    const char *cmd = argv[1];
    for (int i = 2; i < argc; i++) if (!strcmp(argv[i], "--help") || !strcmp(argv[i], "-h")) { sub_help(cmd); return 0; }
    if (!strcmp(cmd, "list")) { fputs(lint_list, stdout); return 0; }
    if (!strcmp(cmd, "dump")) { puts("disabled = []\nignore = ['.direnv']"); return 0; }
    if (!strcmp(cmd, "explain")) {
        if (argc < 3) { fprintf(stderr, "error: missing target\n"); return 2; }
        const char *s = argv[2]; if (s[0] == 'W' || s[0] == 'w') s++;
        for (const char *p = s; *p; p++) if (!isdigit((unsigned char)*p)) { puts("syntax error"); return 1; }
        explain(atoi(s)); return 0;
    }
    if (!strcmp(cmd, "check") || !strcmp(cmd, "fix") || !strcmp(cmd, "single")) {
        int check = !strcmp(cmd, "check"), errfmt = 0, dry = 0, stdin_mode = 0;
        const char *target = ".";
        for (int i = 2; i < argc; i++) {
            if (!strcmp(argv[i], "-o") || !strcmp(argv[i], "--format")) { if (i + 1 < argc && !strcmp(argv[i+1], "errfmt")) errfmt = 1; i++; }
            else if (!strcmp(argv[i], "-d") || !strcmp(argv[i], "--dry-run")) dry = 1;
            else if (!strcmp(argv[i], "-s") || !strcmp(argv[i], "--stdin")) stdin_mode = 1;
            else if (!strcmp(argv[i], "-c") || !strcmp(argv[i], "--config") || !strcmp(argv[i], "-i") || !strcmp(argv[i], "--ignore") || !strcmp(argv[i], "-p") || !strcmp(argv[i], "--position")) i++;
            else if (!strcmp(argv[i], "--") && i + 1 < argc) target = argv[++i];
            else if (argv[i][0] != '-') target = argv[i];
        }
        if (stdin_mode) return process_one("<stdin>", check, errfmt, dry, 0, 1);
        return walk(target, check, errfmt, dry, !check);
    }
    fprintf(stderr, "error: unrecognized subcommand `%s`\n", cmd);
    return 2;
}
