#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdbool.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct { const char *border, *background, *text, *indicator; } Win;
typedef struct { const char *border, *background, *text; } Ws;
typedef struct {
    const char *name, *description;
    const char *bar_background, *bar_statusline, *bar_separator;
    Ws focused_workspace, active_workspace, inactive_workspace, urgent_workspace;
    Win focused, focused_inactive, unfocused, urgent;
} Theme;

static Theme themes[] = {
{"slate","Slate theme by Jody Ribton <jody@ribton.me>","#002b36","#aea79f","#586e75",{"#586e75","#586e75","#ffffff"},{"#073642","#073642","#ffffff"},{"#002b36","#002b36","#aea79f"},{"#77216f","#77216f","#ffffff"},{"#586e75","#586e75","#fdf6e3","#268bd2"},{"#073642","#073642","#93a1a1","#002b36"},{"#002b36","#002b36","#586e75","#002b36"},{"#dc322f","#dc322f","#fdf6e3","#dc322f"}},
{"alphare","A beige theme by Alphare","#FDF6E3","#002B36","#000000",{"#000000","#268BD2","#FFFFFF"},{"#333333","#222222","#FFFFFF"},{"#333333","#222222","#888888"},{"#2F343A","#900000","#FFFFFF"},{"#000000","#FDF6E3","#002B36","#000000"},{"#000000","#5F676A","#FDF6E3","#484E50"},{"#000000","#000000","#FDF6E3","#000000"},{"#000000","#DC322F","#FDF6E3","#DC322F"}},
{"ubuntu","Ubuntu theme by lasers","#2c001e","#aea79f","#333333",{"#dd4814","#dd4814","#ffffff"},{"#902a07","#902a07","#aea79f"},{"#902a07","#902a07","#aea79f"},{"#77216f","#77216f","#ffffff"},{"#dd4814","#dd4814","#ffffff","#902a07"},{"#5e2750","#5e2750","#aea79f","#5e2750"},{"#5e2750","#5e2750","#aea79f","#5e2750"},{"#77216f","#77216f","#ffffff","#efb73e"}},
{"flat-gray","flat gray based theme","#333333","#AAAAAA","#000000",{"#282828","#282828","#FFFFFF"},{"#000000","#000000","#000000"},{"#333333","#333333","#AAAAAA"},{"#000000","#000000","#000000"},{"#000000","#000000","#FFFFFF","#000000"},{"#333333","#333333","#FFFFFF","#000000"},{"#333333","#333333","#FFFFFF","#333333"},{"#000000","#000000","#000000","#000000"}},
{"purple","Purple theme by AAlakkad <http://aalakkad.me>","#222133","#FFFFFF","#AAAAAA",{"#664477","#664477","#cccccc"},{"#DCCD69","#DCCD69","#181715"},{"#222133","#222133","#AAAAAA"},{"#CE4045","#CE4045","#FFFFFF"},{"#664477","#664477","#cccccc","#e7d8b1"},{"#e7d8b1","#e7d8b1","#181715","#A074C4"},{"#222133","#222133","#AAAAAA","#A074C4"},{"#CE4045","#CE4045","#e7d8b1","#DCCD69"}},
{"archlinux","Archlinux theme by okraits <http://okraits.de>","#222222","#dddddd","#666666",{"#0088CC","#0088CC","#ffffff"},{"#333333","#333333","#ffffff"},{"#333333","#333333","#888888"},{"#2f343a","#900000","#ffffff"},{"#0088CC","#0088CC","#ffffff","#dddddd"},{"#333333","#333333","#888888","#292d2e"},{"#333333","#333333","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"default","Default theme for i3wm <http://i3wm.org>","#000000","#ffffff","#666666",{"#4c7899","#285577","#ffffff"},{"#333333","#5f676a","#ffffff"},{"#333333","#222222","#888888"},{"#2f343a","#900000","#ffffff"},{"#4c7899","#285577","#ffffff","#2e9ef4"},{"#333333","#5f676a","#ffffff","#484e50"},{"#333333","#222222","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"debian","Debian theme by lasers","#222222","#666666","#444444",{"#d70a53","#d70a53","#ffffff"},{"#333333","#333333","#888888"},{"#333333","#333333","#888888"},{"#eb709b","#eb709b","#ffffff"},{"#d70a53","#d70a53","#ffffff","#8c0333"},{"#333333","#333333","#888888","#333333"},{"#333333","#333333","#888888","#333333"},{"#eb709b","#eb709b","#ffffff","#eb709b"}},
{"oceanic-next","Theme by Valentin Weber inspired by voronianski (https://github.com/voronianski/oceanic-next-color-scheme)","#1B2B34","#D8DEE9","#65737E",{"#6699CC","#6699CC","#1B2B34"},{"#5FB3B3","#5FB3B3","#1B2B34"},{"#343D46","#343D46","#D8DEE9"},{"#EC5f67","#EC5f67","#1B2B34"},{"#6699CC","#6699CC","#1B2B34","#6699CC"},{"#5FB3B3","#5FB3B3","#D8DEE9","#A7ADBA"},{"#343D46","#343D46","#D8DEE9","#343D46"},{"#EC5f67","#EC5f67","#1B2B34","#EC5f67"}},
{"base16-tomorrow","Base16 Tomorrow, by Chris Kempson (http://chriskempson.com)","#1d1f21","#c5c8c6","#969896",{"#81a2be","#81a2be","#1d1f21"},{"#373b41","#373b41","#ffffff"},{"#282a2e","#282a2e","#969896"},{"#cc6666","#cc6666","#ffffff"},{"#81a2be","#81a2be","#1d1f21","#282a2e"},{"#373b41","#373b41","#969896","#282a2e"},{"#282a2e","#282a2e","#969896","#282a2e"},{"#373b41","#cc6666","#ffffff","#cc6666"}},
{"okraits","A simple theme by okraits <http://okraits.de>","#333333","#bbbbbb","#666666",{"#888888","#dddddd","#222222"},{"#333333","#555555","#bbbbbb"},{"#333333","#555555","#bbbbbb"},{"#2f343a","#900000","#ffffff"},{"#888888","#dddddd","#222222","#2e9ef4"},{"#333333","#555555","#bbbbbb","#484e50"},{"#333333","#333333","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"icelines","icelines theme by mbfraga","#141414","#00b0ef","#7d7d7d",{"#00b0ef","#141414","#00b0ef"},{"#141414","#141414","#00b0ef"},{"#141414","#141414","#7d7d7d"},{"#ff7066","#141414","#ff7066"},{"#00b0ef","#00b0ef","#141414","#ff7066"},{"#141414","#141414","#00b0ef","#472b2a"},{"#141414","#141414","#7d7d7d","#141414"},{"#ff7066","#ff7066","#141414","#ff7066"}},
{"solarized","Solarized theme by lasers","#002b36","#268bd2","#dc322f",{"#fdf6e3","#859900","#fdf6e3"},{"#fdf6e3","#6c71c4","#fdf6e3"},{"#586e75","#93a1a1","#002b36"},{"#d33682","#d33682","#fdf6e3"},{"#859900","#859900","#fdf6e3","#6c71c4"},{"#073642","#073642","#eee8d5","#6c71c4"},{"#073642","#073642","#93a1a1","#586e75"},{"#d33682","#d33682","#fdf6e3","#dc322f"}},
{"deep-purple","Inspired by the Purple and Default themes. By jcpst <http://jcpst.com>","#000000","#ffffff","#666666",{"#551a8b","#551a8b","#ffffff"},{"#333333","#5f676a","#ffffff"},{"#000000","#000000","#888888"},{"#2f343a","#900000","#ffffff"},{"#3b1261","#3b1261","#ffffff","#662b9c"},{"#333333","#5f676a","#ffffff","#484e50"},{"#222222","#222222","#888888","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"tomorrow-night-80s","Tomorrow Night 80s theme by jmfurlott <http://jmfurlott.com>","#2d2d2d","#cccccc","#515151",{"#99cc99","#99cc99","#000000"},{"#333333","#333333","#ffffff"},{"#2d2d2d","#2d2d2d","#999999"},{"#f2777a","#f2777a","#ffffff"},{"#99cc99","#99cc99","#000000","#2d2d2d"},{"#393939","#393939","#888888","#292d2e"},{"#2d2d2d","#2d2d2d","#999999","#292d2e"},{"#2f343a","#900000","#ffffff","#900000"}},
{"seti","seti theme by Jody Ribton - based on the seti Atom theme at https://atom.io/themes/seti-ui","#1f2326","#FFFFFF","#AAAAAA",{"#9FCA56","#9FCA56","#151718"},{"#DCCD69","#DCCD69","#151718"},{"#1f2326","#1f2326","#AAAAAA"},{"#CE4045","#CE4045","#FFFFFF"},{"#4F99D3","#4F99D3","#151718","#9FCA56"},{"#9FCA56","#9FCA56","#151718","#A074C4"},{"#1f2326","#1f2326","#AAAAAA","#A074C4"},{"#CE4045","#CE4045","#FFFFFF","#DCCD69"}},
{"lime","Lime theme by wei2912 <http://wei2912.github.io>, based on Archlinux theme by okraits <http://okraits.de>","#333333","#FFFFFF","#888888",{"#4E9C00","#4E9C00","#FFFFFF"},{"#333333","#333333","#FFFFFF"},{"#333333","#333333","#888888"},{"#C20000","#C20000","#FFFFFF"},{"#4E9C00","#4E9C00","#FFFFFF","#FFFFFF"},{"#1B3600","#1B3600","#888888","#FFFFFF"},{"#333333","#333333","#888888","#FFFFFF"},{"#C20000","#C20000","#FFFFFF","#FFFFFF"}},
{"gruvbox","Made by freeware-preacher <https://github.com/freeware-preacher> to match gruvbox by morhetz <https://github.com/morhetz>","#282828","#ebdbb2","#928374",{"#689d6a","#689d6a","#282828"},{"#1d2021","#1d2021","#928374"},{"#32302f","#32302f","#928374"},{"#cc241d","#cc241d","#ebdbb2"},{"#689d6a","#689d6a","#282828","#282828"},{"#1d2021","#1d2021","#928374","#282828"},{"#32302f","#32302f","#928374","#282828"},{"#cc241d","#cc241d","#ebdbb2","#282828"}},
{"mate","Theme for blending i3 into MATE","#3c3b37","#ffffff","#ffffff",{"#526532","#526532","#ffffff"},{"#aea79f","#aea79f","#3c3b37"},{"#3c3b37","#3c3b37","#aea79f"},{"#FF0000","#FF0000","#ffffff"},{"#526532","#526532","#ffffff","#a4cb64"},{"#aea79f","#aea79f","#3c3b37","#aea79f"},{"#3c3b37","#3c3b37","#aea79f","#3c3b37"},{"#FF0000","#FF0000","#ffffff","#FF0000"}},
};

static char *xstrdup(const char *s){ char *r=strdup(s?s:""); if(!r){perror("strdup"); exit(2);} return r; }
static char *trim(char *s){ while(isspace((unsigned char)*s)) s++; char *e=s+strlen(s); while(e>s && isspace((unsigned char)e[-1])) *--e=0; return s; }
static bool starts(const char *s,const char *p){ return strncmp(s,p,strlen(p))==0; }

typedef struct { char **v; int n, cap; } Lines;
static void add_line(Lines *l, char *s){ if(l->n==l->cap){ l->cap=l->cap?l->cap*2:64; l->v=realloc(l->v,l->cap*sizeof(char*)); if(!l->v) exit(2);} l->v[l->n++]=s; }
static char *read_file(const char *path){
    FILE *f=fopen(path,"rb"); if(!f) return NULL; fseek(f,0,SEEK_END); long n=ftell(f); fseek(f,0,SEEK_SET);
    char *b=malloc((n<0?0:n)+1); if(!b) exit(2); size_t r=fread(b,1,n<0?0:n,f); b[r]=0; fclose(f); return b;
}
static Lines split_lines(const char *buf){
    Lines l={0}; const char *p=buf;
    while(*p){ const char *q=strchr(p,'\n'); size_t n=q?(size_t)(q-p+1):strlen(p); char *s=malloc(n+1); memcpy(s,p,n); s[n]=0; add_line(&l,s); p=q?q+1:p+n; }
    return l;
}
static char *fmt(const char *f,...){
    va_list ap; va_start(ap,f); char *s=NULL; if(vasprintf(&s,f,ap)<0) exit(2); va_end(ap); return s;
}

static int leading(const char *s){ int n=0; while(s[n]==' '||s[n]=='\t') n++; return n; }
static const char *indent_of(const char *s){ static char b[128]; int n=leading(s); if(n>120)n=120; memcpy(b,s,n); b[n]=0; return b; }
static char *first_hex_after_two(const char *s){
    int seen=0; const char *p=s;
    while(*p){ if(*p=='#'){ seen++; const char *q=p; while(*q && !isspace((unsigned char)*q)) q++; if(seen==3){ size_t n=q-p; char *r=malloc(n+1); memcpy(r,p,n); r[n]=0; return r; } p=q; } else p++; }
    return NULL;
}
static const Ws *ws_for(const Theme *t,const char *k){
    if(!strcmp(k,"focused_workspace")) return &t->focused_workspace;
    if(!strcmp(k,"active_workspace")) return &t->active_workspace;
    if(!strcmp(k,"inactive_workspace")) return &t->inactive_workspace;
    if(!strcmp(k,"urgent_workspace")) return &t->urgent_workspace;
    return NULL;
}
static const Win *win_for(const Theme *t,const char *k){
    if(!strcmp(k,"client.focused")) return &t->focused;
    if(!strcmp(k,"client.focused_inactive")) return &t->focused_inactive;
    if(!strcmp(k,"client.unfocused")) return &t->unfocused;
    if(!strcmp(k,"client.urgent")) return &t->urgent;
    return NULL;
}
static char *bar_line(const char *ind,const char *k,const Theme *t,const char *old){
    if(!strcmp(k,"separator")) return fmt("%sseparator %s\n",ind,t->bar_separator);
    if(!strcmp(k,"background")) return fmt("%sbackground %s\n",ind,t->bar_background);
    if(!strcmp(k,"statusline")) return fmt("%sstatusline %s\n",ind,t->bar_statusline);
    const Ws *w=ws_for(t,k); if(w){ char *extra=first_hex_after_two(old); char *r=fmt("%s%s %s %s %s%s%s\n",ind,k,w->border,w->background,w->text,extra?" ":"",extra?extra:""); free(extra); return r; }
    return xstrdup(old);
}
static char *win_line(const char *ind,const char *k,const Theme *t){
    const Win *w=win_for(t,k); return fmt("%s%s %s %s %s %s\n",ind,k,w->border,w->background,w->text,w->indicator);
}
static int key_index(const char *k){
    const char *keys[]={"separator","background","statusline","focused_workspace","active_workspace","inactive_workspace","urgent_workspace"};
    for(int i=0;i<7;i++) if(!strcmp(k,keys[i])) return i; return -1;
}
static char *line_key(char *line){
    char tmp[256]; snprintf(tmp,sizeof tmp,"%s",line); char *t=trim(tmp); if(!*t || *t=='#') return NULL;
    static char key[80]; int i=0; while(t[i] && !isspace((unsigned char)t[i]) && t[i]!='{') { key[i]=t[i]; i++; if(i>70) break; } key[i]=0; return key;
}
static void emit_missing_bar(Lines *out,bool seen[7],const Theme*t,const char *ind){
    const char *keys[]={"separator","background","statusline","focused_workspace","active_workspace","inactive_workspace","urgent_workspace"};
    for(int i=0;i<7;i++) if(!seen[i]) add_line(out,bar_line(ind,keys[i],t,""));
}
static void emit_default_colors(Lines*out,const Theme*t){
    add_line(out,xstrdup("  colors {\n")); bool seen[7]={0}; emit_missing_bar(out,seen,t,"    "); add_line(out,xstrdup("  }\n"));
}

static Lines transform(Lines in,const Theme*t){
    Lines out={0}; bool winseen[4]={0}; bool in_bar=false,in_colors=false,bar_had_colors=false; int bar_depth=0; bool bar_seen[7]={0};
    for(int i=0;i<in.n;i++){
        char *line=in.v[i]; char *copy=xstrdup(line); char *tr=trim(copy); char *key=line_key(line);
        const Win *w=key?win_for(t,key):NULL;
        if(w){ int idx=!strcmp(key,"client.focused")?0:!strcmp(key,"client.focused_inactive")?1:!strcmp(key,"client.unfocused")?2:3; winseen[idx]=true; add_line(&out,win_line(indent_of(line),key,t)); free(copy); continue; }
        if(in_colors){
            for(char *p=line;*p;p++){ if(*p=='{') bar_depth++; if(*p=='}') bar_depth--; }
            if(key){ int ki=key_index(key); if(ki>=0){ bar_seen[ki]=true; add_line(&out,bar_line(indent_of(line),key,t,line)); free(copy); continue; } }
            if(strchr(tr,'}')){ emit_missing_bar(&out,bar_seen,t,"    "); in_colors=false; }
            add_line(&out,xstrdup(line)); free(copy); continue;
        }
        if(in_bar && starts(tr,"colors") && strchr(tr,'{')){ in_colors=true; bar_had_colors=true; bar_depth++; memset(bar_seen,0,sizeof bar_seen); add_line(&out,xstrdup(line)); free(copy); continue; }
        if(!in_bar && starts(tr,"bar") && strchr(tr,'{')){ in_bar=true; bar_had_colors=false; bar_depth=1; add_line(&out,xstrdup(line)); free(copy); continue; }
        if(in_bar){
            for(char *p=line;*p;p++){ if(*p=='{') bar_depth++; if(*p=='}') bar_depth--; }
            if(bar_depth<=0){ if(!bar_had_colors) emit_default_colors(&out,t); in_bar=false; }
        }
        add_line(&out,xstrdup(line)); free(copy);
    }
    const char *wins[]={"client.focused","client.focused_inactive","client.unfocused","client.urgent"};
    for(int i=0;i<4;i++) if(!winseen[i]) add_line(&out,win_line("",wins[i],t));
    return out;
}

static Theme *find_theme(const char *name){ for(size_t i=0;i<sizeof(themes)/sizeof(themes[0]);i++) if(!strcmp(themes[i].name,name)) return &themes[i]; return NULL; }

typedef struct { char name[64], val[64]; } Pair;
static const char *lookup(Pair *p,int n,const char *v){ if(!v) return "#000000"; if(v[0]=='#') return v; for(int i=0;i<n;i++) if(!strcmp(p[i].name,v)) return p[i].val; return v; }
static char *unquote(char *v){ v=trim(v); if((*v=='"'||*v=='\'') && v[strlen(v)-1]==*v){ v[strlen(v)-1]=0; v++; } return v; }
static bool parse_theme_file(const char *path, Theme *t){
    char *buf=read_file(path); if(!buf) return false; *t=themes[6]; t->name=path; t->description="Custom theme";
    Pair colors[128]; int nc=0; char section[32]="", sub[64]="";
    Lines l=split_lines(buf);
    for(int i=0;i<l.n;i++){
        char *line=l.v[i]; int ind=leading(line);
        char *s=trim(line); if(!*s) continue; char *colon=strchr(s,':'); if(!colon) continue; *colon=0; char *k=trim(s); char *v=unquote(colon+1);
        if(ind==0){ snprintf(section,sizeof section,"%s",k); sub[0]=0; continue; }
        if(ind==2 && !*v){ snprintf(sub,sizeof sub,"%s",k); continue; }
        if(!strcmp(section,"colors") && nc<128){ snprintf(colors[nc].name,sizeof colors[nc].name,"%s",k); snprintf(colors[nc].val,sizeof colors[nc].val,"%s",v); nc++; continue; }
        const char *val=lookup(colors,nc,v);
        if(!strcmp(section,"bar_colors")){
            if(!strcmp(k,"background")) t->bar_background=xstrdup(val); else if(!strcmp(k,"statusline")) t->bar_statusline=xstrdup(val); else if(!strcmp(k,"separator")) t->bar_separator=xstrdup(val);
            else if(*sub){ Ws *w=!strcmp(sub,"focused_workspace")?&t->focused_workspace:!strcmp(sub,"active_workspace")?&t->active_workspace:!strcmp(sub,"inactive_workspace")?&t->inactive_workspace:!strcmp(sub,"urgent_workspace")?&t->urgent_workspace:NULL; if(w){ if(!strcmp(k,"border")) w->border=xstrdup(val); else if(!strcmp(k,"background")) w->background=xstrdup(val); else if(!strcmp(k,"text")) w->text=xstrdup(val); } }
        } else if(!strcmp(section,"window_colors") && *sub){
            Win *w=!strcmp(sub,"focused")?&t->focused:!strcmp(sub,"focused_inactive")?&t->focused_inactive:!strcmp(sub,"unfocused")?&t->unfocused:!strcmp(sub,"urgent")?&t->urgent:NULL; if(w){ if(!strcmp(k,"border")) w->border=xstrdup(val); else if(!strcmp(k,"background")) w->background=xstrdup(val); else if(!strcmp(k,"text")) w->text=xstrdup(val); else if(!strcmp(k,"indicator")) w->indicator=xstrdup(val); }
        }
    }
    free(buf); return true;
}

static void print_help(void){
    puts("i3-style 1.0\nMake your i3 config a bit more stylish\n\nUSAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nFLAGS:\n    -h, --help        Prints help information\n    -l, --list-all    Print a list of all available themes\n    -r, --reload      Apply the theme by reloading the config\n    -s, --save        Set the output file to the path of the input file\n    -V, --version     Prints version information\n\nOPTIONS:\n    -c, --config <file>      The config file the theme should be applied to. Defaults to the default i3 location.\n    -o, --output <file>      Apply the theme, attempt to validate the result, and write it to <file>\n    -t, --to-theme <file>    Prints an i3-style theme based on the given config suitable for sharing with others\n                             [default: ]\n\nARGS:\n    <theme>    The theme to use");
}
static void list_all(void){ puts("Available themes:\n"); for(size_t i=0;i<sizeof(themes)/sizeof(themes[0]);i++) printf("  %-18s - %s\n",themes[i].name,themes[i].description); }
static char *default_config(void){
    const char *home=getenv("HOME"); static char p[512]; if(home){ snprintf(p,sizeof p,"%s/.config/i3/config",home); if(access(p,R_OK)==0) return p; snprintf(p,sizeof p,"%s/.i3/config",home); if(access(p,R_OK)==0) return p; } return NULL;
}
static void to_theme(const char *path){
    char *buf=read_file(path); if(!buf){ puts("Could not find i3 config"); exit(1); }
    const char *wnames[]={"focused","focused_inactive","unfocused","urgent"};
    const char *wkeys[]={"client.focused","client.focused_inactive","client.unfocused","client.urgent"};
    char wv[4][4][64]={0}, bv[3][64]={0}, sv[4][3][64]={0};
    const char *skeys[]={"focused_workspace","active_workspace","inactive_workspace","urgent_workspace"};
    Lines l=split_lines(buf);
    for(int i=0;i<l.n;i++){
        char tmp[512]; snprintf(tmp,sizeof tmp,"%s",l.v[i]); char *s=trim(tmp); if(!*s||*s=='#') continue;
        char key[80], a[64], b[64], c[64], d[64];
        if(sscanf(s,"%79s %63s %63s %63s %63s",key,a,b,c,d)>=2){
            for(int j=0;j<4;j++) if(!strcmp(key,wkeys[j]) && sscanf(s,"%*s %63s %63s %63s %63s",a,b,c,d)==4){
                snprintf(wv[j][0],64,"%s",a); snprintf(wv[j][1],64,"%s",b); snprintf(wv[j][2],64,"%s",c); snprintf(wv[j][3],64,"%s",d);
            }
            if(!strcmp(key,"background")) snprintf(bv[0],64,"%s",a);
            else if(!strcmp(key,"statusline")) snprintf(bv[1],64,"%s",a);
            else if(!strcmp(key,"separator")) snprintf(bv[2],64,"%s",a);
            else for(int j=0;j<4;j++) if(!strcmp(key,skeys[j]) && sscanf(s,"%*s %63s %63s %63s",a,b,c)==3){
                snprintf(sv[j][0],64,"%s",a); snprintf(sv[j][1],64,"%s",b); snprintf(sv[j][2],64,"%s",c);
            }
        }
    }
    puts("---\nmeta:\n  description: AUTOMATICALLY GENERATED THEME\ncolors: {}");
    puts("window_colors:");
    bool any=false;
    for(int i=0;i<4;i++) if(wv[i][0][0]){ any=true; printf("  %s:\n    border: \"%s\"\n    background: \"%s\"\n    text: \"%s\"\n    indicator: \"%s\"\n",wnames[i],wv[i][0],wv[i][1],wv[i][2],wv[i][3]); }
    if(!any) puts("  {}");
    puts("bar_colors:");
    any=false;
    if(bv[0][0]){ any=true; printf("  background: \"%s\"\n",bv[0]); }
    if(bv[1][0]){ any=true; printf("  statusline: \"%s\"\n",bv[1]); }
    if(bv[2][0]){ any=true; printf("  separator: \"%s\"\n",bv[2]); }
    for(int i=0;i<4;i++) if(sv[i][0][0]){ any=true; printf("  %s:\n    border: \"%s\"\n    background: \"%s\"\n    text: \"%s\"\n",skeys[i],sv[i][0],sv[i][1],sv[i][2]); }
    if(!any) puts("  {}");
    free(buf);
}
int main(int argc,char **argv){
    const char *config=NULL,*output=NULL,*theme_arg=NULL,*to=NULL; bool save=false,reload=false;
    for(int i=1;i<argc;i++){
        if(!strcmp(argv[i],"-h")||!strcmp(argv[i],"--help")){ print_help(); return 0; }
        else if(!strcmp(argv[i],"-V")||!strcmp(argv[i],"--version")){ puts("i3-style 1.0"); return 0; }
        else if(!strcmp(argv[i],"-l")||!strcmp(argv[i],"--list-all")){ list_all(); return 0; }
        else if((!strcmp(argv[i],"-c")||!strcmp(argv[i],"--config")) && i+1<argc) config=argv[++i];
        else if((!strcmp(argv[i],"-o")||!strcmp(argv[i],"--output")) && i+1<argc) output=argv[++i];
        else if((!strcmp(argv[i],"-t")||!strcmp(argv[i],"--to-theme")) && i+1<argc) to=argv[++i];
        else if(!strcmp(argv[i],"-s")||!strcmp(argv[i],"--save")) save=true;
        else if(!strcmp(argv[i],"-r")||!strcmp(argv[i],"--reload")) reload=true;
        else if(argv[i][0]=='-'){ fprintf(stderr,"Found argument '%s' which wasn't expected\n",argv[i]); return 1; }
        else theme_arg=argv[i];
    }
    if(to){ to_theme(to); return 0; }
    if(!theme_arg){ puts("USAGE:\n    executable [FLAGS] [OPTIONS] [theme]\n\nSelect a theme as the first argument. Use `--list-all` to see the themes."); return 1; }
    if(!config) config=default_config(); if(!config){ puts("Could not find i3 config"); return 1; }
    char *buf=read_file(config); if(!buf){ puts("Could not find i3 config"); return 1; }
    Theme custom; Theme *t=find_theme(theme_arg); if(!t){ if(parse_theme_file(theme_arg,&custom)) t=&custom; else { puts("Could not find i3 config"); free(buf); return 1; } }
    Lines in=split_lines(buf), out=transform(in,t);
    if(save) output=config;
    FILE *f=stdout; if(output){ f=fopen(output,"wb"); if(!f){ fprintf(stderr,"Could not write output: %s\n",strerror(errno)); return 1; } }
    for(int i=0;i<out.n;i++) fputs(out.v[i],f);
    if(output) fclose(f);
    if(reload) system("i3-msg reload >/dev/null 2>&1");
    free(buf); return 0;
}
