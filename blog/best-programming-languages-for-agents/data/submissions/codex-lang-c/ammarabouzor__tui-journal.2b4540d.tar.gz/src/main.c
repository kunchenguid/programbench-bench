#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

typedef struct {
    char backend_type[16];
    int scroll_per_page;
    bool sync_os_clipboard;
    int history_limit;
    bool colored_tags;
    char datum_visibility[64];
    char app_state_dir[PATH_MAX];
    bool export_show_confirmation;
    bool external_auto_save;
    char external_temp_file_extension[64];
    char json_file_path[PATH_MAX];
    char sqlite_file_path[PATH_MAX];
    char config_dir[PATH_MAX];
} Config;

static const char *THEME_DEFAULT =
"[general.input_block_active]\n"
"fg = \"LightYellow\"\n"
"modifiers = \"\"\n"
"\n"
"[general.input_block_invalid]\n"
"fg = \"LightRed\"\n"
"modifiers = \"\"\n"
"\n"
"[general.input_corsur_active]\n"
"fg = \"Black\"\n"
"bg = \"LightYellow\"\n"
"modifiers = \"\"\n"
"\n"
"[general.input_corsur_invalid]\n"
"fg = \"Black\"\n"
"bg = \"LightRed\"\n"
"modifiers = \"\"\n"
"\n"
"[general.list_item_selected]\n"
"fg = \"LightYellow\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[general.list_highlight_active]\n"
"fg = \"Black\"\n"
"bg = \"LightGreen\"\n"
"modifiers = \"\"\n"
"\n"
"[general.list_highlight_inactive]\n"
"fg = \"Black\"\n"
"bg = \"LightBlue\"\n"
"modifiers = \"\"\n"
"\n"
"[journals_list.block_active]\n"
"fg = \"Reset\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[journals_list.block_inactive]\n"
"fg = \"#AAAAC8\"\n"
"modifiers = \"\"\n"
"\n"
"[journals_list.block_multi_select]\n"
"fg = \"Yellow\"\n"
"modifiers = \"BOLD | ITALIC\"\n"
"\n"
"[journals_list.highlight_active]\n"
"fg = \"Black\"\n"
"bg = \"LightGreen\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[journals_list.highlight_inactive]\n"
"fg = \"Black\"\n"
"bg = \"LightBlue\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[journals_list.title_active]\n"
"fg = \"Reset\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[journals_list.title_inactive]\n"
"fg = \"#AAAAC8\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[journals_list.title_selected]\n"
"fg = \"Yellow\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[journals_list.date_priority]\n"
"fg = \"LightBlue\"\n"
"modifiers = \"\"\n"
"\n"
"[journals_list.tags_default]\n"
"fg = \"LightCyan\"\n"
"modifiers = \"DIM\"\n"
"\n"
"[editor.block_insert]\n"
"fg = \"LightGreen\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[editor.block_visual]\n"
"fg = \"Blue\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[editor.block_normal_active]\n"
"fg = \"Reset\"\n"
"modifiers = \"BOLD\"\n"
"\n"
"[editor.block_normal_inactive]\n"
"fg = \"#AAAAC8\"\n"
"modifiers = \"\"\n"
"\n"
"[editor.cursor_normal]\n"
"fg = \"Black\"\n"
"bg = \"White\"\n"
"modifiers = \"\"\n"
"\n"
"[editor.cursor_insert]\n"
"fg = \"Black\"\n"
"bg = \"LightGreen\"\n"
"modifiers = \"\"\n"
"\n"
"[editor.cursor_visual]\n"
"fg = \"Black\"\n"
"bg = \"Blue\"\n"
"modifiers = \"\"\n"
"\n"
"[editor.selection_style]\n"
"fg = \"Black\"\n"
"bg = \"White\"\n"
"modifiers = \"\"\n"
"\n"
"[msgbox]\n"
"error = \"LightRed\"\n"
"warning = \"Yellow\"\n"
"info = \"LightGreen\"\n"
"question = \"LightBlue\"\n"
"\n";

static const char *MAIN_HELP =
"Tui app allows writing and managing journals/notes from within the terminal With different local back-ends\n"
"\n"
"Usage: executable [OPTIONS] [COMMAND]\n"
"\n"
"Commands:\n"
"  print-config     Print the current settings including the paths for the back-end files [aliases: pc]\n"
"  import-journals  Import journals from the given transfer JSON file to the current back-end file [aliases: imj]\n"
"  assign-priority  Assign priority for all the entries with empty priority field [aliases: ap]\n"
"  theme            Provides commands regarding changing themes and styles of the app [aliases: style]\n"
"  help             Print this message or the help of the given subcommand(s)\n"
"\n"
"Options:\n"
"  -j, --json-file-path <FILE PATH>    Sets the entries Json file path and starts using it\n"
"  -s, --sqlite-file-path <FILE PATH>  Sets the entries sqlite file path and starts using it\n"
"  -b, --backend-type <BACKEND_TYPE>   Sets the backend type and starts using it [possible values: json, sqlite]\n"
"  -c, --config <DIR PATH>             Specifies the path for the configuration directory.\n"
"                                      Configuration files is considered as root for themes file too.\n"
"                                      It still accepts the path for configuration file for backward compatibility.\n"
"                                      (default path: /home/agent/.config/tui-journal)\n"
"  -v, --verbose...                    Increases logging verbosity each use for up to 3 times\n"
"  -l, --log <FILE PATH>               Specifies a file to use for logging\n"
"                                      (default file: /home/agent/.cache/tui-journal/tui-journal.log)\n"
"  -h, --help                          Print help\n"
"  -V, --version                       Print version\n";

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    char *e = s + strlen(s);
    while (e > s && isspace((unsigned char)e[-1])) *--e = '\0';
    return s;
}

static void strip_quotes(char *s) {
    size_t n = strlen(s);
    if (n >= 2 && s[0] == '"' && s[n - 1] == '"') {
        memmove(s, s + 1, n - 2);
        s[n - 2] = '\0';
    }
}

static bool path_is_dir(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 && S_ISDIR(st.st_mode);
}

static bool path_is_file(const char *p) {
    struct stat st;
    return stat(p, &st) == 0 && S_ISREG(st.st_mode);
}

static void dirname_of(const char *path, char *out, size_t outsz) {
    snprintf(out, outsz, "%s", path);
    char *slash = strrchr(out, '/');
    if (!slash) {
        snprintf(out, outsz, ".");
    } else if (slash == out) {
        slash[1] = '\0';
    } else {
        *slash = '\0';
    }
}

static void set_defaults(Config *cfg) {
    memset(cfg, 0, sizeof(*cfg));
    strcpy(cfg->backend_type, "Sqlite");
    cfg->scroll_per_page = 5;
    cfg->sync_os_clipboard = false;
    cfg->history_limit = 10;
    cfg->colored_tags = true;
    strcpy(cfg->datum_visibility, "show");
    strcpy(cfg->app_state_dir, "/home/agent/.local/state/tui-journal");
    cfg->export_show_confirmation = true;
    cfg->external_auto_save = false;
    strcpy(cfg->external_temp_file_extension, "txt");
    strcpy(cfg->json_file_path, "/home/agent/tui-journal/entries.json");
    strcpy(cfg->sqlite_file_path, "/home/agent/tui-journal/entries.db");
    strcpy(cfg->config_dir, "/home/agent/.config/tui-journal");
}

static void parse_config_file(Config *cfg, const char *file) {
    FILE *f = fopen(file, "r");
    if (!f) return;
    char line[8192], section[128] = "";
    while (fgets(line, sizeof(line), f)) {
        char *hash = strchr(line, '#');
        if (hash) *hash = '\0';
        char *s = trim(line);
        if (!*s) continue;
        if (*s == '[') {
            char *r = strchr(s, ']');
            if (r) {
                *r = '\0';
                snprintf(section, sizeof(section), "%s", s + 1);
            }
            continue;
        }
        char *eq = strchr(s, '=');
        if (!eq) continue;
        *eq = '\0';
        char *key = trim(s), *val = trim(eq + 1);
        strip_quotes(val);
        bool b = strcmp(val, "true") == 0;
        if (!strcmp(section, "")) {
            if (!strcmp(key, "backend_type")) snprintf(cfg->backend_type, sizeof(cfg->backend_type), "%s", val);
            else if (!strcmp(key, "scroll_per_page")) cfg->scroll_per_page = atoi(val);
            else if (!strcmp(key, "sync_os_clipboard")) cfg->sync_os_clipboard = b;
            else if (!strcmp(key, "history_limit")) cfg->history_limit = atoi(val);
            else if (!strcmp(key, "colored_tags")) cfg->colored_tags = b;
            else if (!strcmp(key, "datum_visibility")) snprintf(cfg->datum_visibility, sizeof(cfg->datum_visibility), "%s", val);
            else if (!strcmp(key, "app_state_dir")) snprintf(cfg->app_state_dir, sizeof(cfg->app_state_dir), "%s", val);
        } else if (!strcmp(section, "export")) {
            if (!strcmp(key, "show_confirmation")) cfg->export_show_confirmation = b;
        } else if (!strcmp(section, "external_editor")) {
            if (!strcmp(key, "auto_save")) cfg->external_auto_save = b;
            else if (!strcmp(key, "temp_file_extension")) snprintf(cfg->external_temp_file_extension, sizeof(cfg->external_temp_file_extension), "%s", val);
        } else if (!strcmp(section, "json_backend")) {
            if (!strcmp(key, "file_path")) snprintf(cfg->json_file_path, sizeof(cfg->json_file_path), "%s", val);
        } else if (!strcmp(section, "sqlite_backend")) {
            if (!strcmp(key, "file_path")) snprintf(cfg->sqlite_file_path, sizeof(cfg->sqlite_file_path), "%s", val);
        }
    }
    fclose(f);
}

static int load_config(Config *cfg, const char *config_arg) {
    set_defaults(cfg);
    if (!config_arg) return 0;
    if (path_is_dir(config_arg)) {
        snprintf(cfg->config_dir, sizeof(cfg->config_dir), "%s", config_arg);
        char file[PATH_MAX];
        snprintf(file, sizeof(file), "%s/config.toml", config_arg);
        parse_config_file(cfg, file);
        return 0;
    }
    if (path_is_file(config_arg)) {
        dirname_of(config_arg, cfg->config_dir, sizeof(cfg->config_dir));
        parse_config_file(cfg, config_arg);
        return 0;
    }
    fprintf(stderr, "Error: Provided custom directory doesn't exit. Path: %s\n", config_arg);
    return 1;
}

static void print_config(const Config *cfg) {
    printf("backend_type = \"%s\"\n", cfg->backend_type);
    printf("scroll_per_page = %d\n", cfg->scroll_per_page);
    printf("sync_os_clipboard = %s\n", cfg->sync_os_clipboard ? "true" : "false");
    printf("history_limit = %d\n", cfg->history_limit);
    printf("colored_tags = %s\n", cfg->colored_tags ? "true" : "false");
    printf("datum_visibility = \"%s\"\n", cfg->datum_visibility);
    printf("app_state_dir = \"%s\"\n\n", cfg->app_state_dir);
    printf("[export]\nshow_confirmation = %s\n\n", cfg->export_show_confirmation ? "true" : "false");
    printf("[external_editor]\nauto_save = %s\ntemp_file_extension = \"%s\"\n\n", cfg->external_auto_save ? "true" : "false", cfg->external_temp_file_extension);
    printf("[json_backend]\nfile_path = \"%s\"\n\n", cfg->json_file_path);
    printf("[sqlite_backend]\nfile_path = \"%s\"\n", cfg->sqlite_file_path);
}

static void print_help_for(const char *topic, const char *sub) {
    if (!topic) {
        fputs(MAIN_HELP, stdout);
    } else if (!strcmp(topic, "print-config") || !strcmp(topic, "pc")) {
        puts("Print the current settings including the paths for the back-end files\n");
        puts("Usage: executable print-config\n");
        puts("Options:\n  -h, --help  Print help");
    } else if (!strcmp(topic, "import-journals") || !strcmp(topic, "imj")) {
        puts("Import journals from the given transfer JSON file to the current back-end file\n");
        puts("Usage: executable import-journals --path <FILE PATH>\n");
        puts("Options:\n  -p, --path <FILE PATH>  Path of the JSON file to import from\n  -h, --help              Print help");
    } else if (!strcmp(topic, "assign-priority") || !strcmp(topic, "ap")) {
        puts("Assign priority for all the entries with empty priority field\n");
        puts("Usage: executable assign-priority <PRIORITY>\n");
        puts("Arguments:\n  <PRIORITY>  Priority value (Positive number)\n");
        puts("Options:\n  -h, --help  Print help");
    } else if (!strcmp(topic, "theme") || !strcmp(topic, "style")) {
        if (!sub) {
            puts("Provides commands regarding changing themes and styles of the app\n");
            puts("Usage: executable theme <COMMAND>\n");
            puts("Commands:\n  print-path      Prints the path to the user themes file [aliases: path]\n  print-default   Dumps the styles with the default values to be used as a reference and base for user custom themes [aliases: default]\n  write-defaults  Creates user custom themes file if doesn't exist then writes the default styles to it [aliases: write]\n  help            Print this message or the help of the given subcommand(s)\n");
            puts("Options:\n  -h, --help  Print help");
        } else if (!strcmp(sub, "print-path") || !strcmp(sub, "path")) {
            puts("Prints the path to the user themes file\n");
            puts("Usage: executable theme print-path\n");
            puts("Options:\n  -h, --help  Print help");
        } else if (!strcmp(sub, "print-default") || !strcmp(sub, "default")) {
            puts("Dumps the styles with the default values to be used as a reference and base for user custom themes\n");
            puts("Usage: executable theme print-default\n");
            puts("Options:\n  -h, --help  Print help");
        } else if (!strcmp(sub, "write-defaults") || !strcmp(sub, "write")) {
            puts("Creates user custom themes file if doesn't exist then writes the default styles to it\n");
            puts("Usage: executable theme write-defaults\n");
            puts("Options:\n  -h, --help  Print help");
        }
    }
}

static int ensure_parent_dir(const char *path) {
    char dir[PATH_MAX];
    dirname_of(path, dir, sizeof(dir));
    char tmp[PATH_MAX];
    snprintf(tmp, sizeof(tmp), "%s", dir);
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = '\0';
            mkdir(tmp, 0777);
            *p = '/';
        }
    }
    return mkdir(tmp, 0777) == 0 || errno == EEXIST ? 0 : -1;
}

static char *read_all(const char *path, long *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    char *buf = malloc((size_t)n + 1);
    if (!buf) {
        fclose(f);
        return NULL;
    }
    if (n > 0 && fread(buf, 1, (size_t)n, f) != (size_t)n) {
        fclose(f);
        free(buf);
        return NULL;
    }
    buf[n] = '\0';
    fclose(f);
    if (len) *len = n;
    return buf;
}

static int copy_file(const char *src, const char *dst) {
    long n = 0;
    char *buf = read_all(src, &n);
    if (!buf) {
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
        return 1;
    }
    ensure_parent_dir(dst);
    FILE *f = fopen(dst, "wb");
    if (!f) {
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
        free(buf);
        return 1;
    }
    fwrite(buf, 1, (size_t)n, f);
    fclose(f);
    free(buf);
    return 0;
}

static int json_assign_priority(const char *path, const char *priority) {
    long n = 0;
    char *buf = read_all(path, &n);
    if (!buf) {
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
        return 1;
    }
    size_t cap = (size_t)n * 2 + 1024;
    char *out = malloc(cap);
    if (!out) {
        free(buf);
        return 1;
    }
    size_t oi = 0;
    for (long i = 0; i < n; i++) {
        if (strncmp(&buf[i], "\"priority\"", 10) == 0) {
            long j = i + 10;
            while (j < n && isspace((unsigned char)buf[j])) j++;
            if (j < n && buf[j] == ':') j++;
            while (j < n && isspace((unsigned char)buf[j])) j++;
            bool empty = false;
            long k = j;
            if (k + 1 < n && buf[k] == '"' && buf[k + 1] == '"') {
                empty = true;
                k += 2;
            } else if (k + 4 <= n && strncmp(&buf[k], "null", 4) == 0) {
                empty = true;
                k += 4;
            }
            if (empty) {
                const char *prefix = "\"priority\": ";
                size_t need = oi + strlen(prefix) + strlen(priority) + 8;
                if (need > cap) {
                    cap = need * 2;
                    out = realloc(out, cap);
                }
                memcpy(out + oi, prefix, strlen(prefix));
                oi += strlen(prefix);
                memcpy(out + oi, priority, strlen(priority));
                oi += strlen(priority);
                i = k - 1;
                continue;
            }
        }
        if (oi + 2 > cap) {
            cap *= 2;
            out = realloc(out, cap);
        }
        out[oi++] = buf[i];
    }
    ensure_parent_dir(path);
    FILE *f = fopen(path, "wb");
    if (!f) {
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
        free(buf);
        free(out);
        return 1;
    }
    fwrite(out, 1, oi, f);
    fclose(f);
    free(buf);
    free(out);
    return 0;
}

static int write_sqlite_placeholder(const char *path) {
    ensure_parent_dir(path);
    FILE *f = fopen(path, "ab");
    if (!f) {
        fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno);
        return 1;
    }
    fclose(f);
    return 0;
}

static bool is_cmd(const char *s) {
    return !strcmp(s, "print-config") || !strcmp(s, "pc") ||
           !strcmp(s, "import-journals") || !strcmp(s, "imj") ||
           !strcmp(s, "assign-priority") || !strcmp(s, "ap") ||
           !strcmp(s, "theme") || !strcmp(s, "style") ||
           !strcmp(s, "help");
}

int main(int argc, char **argv) {
    const char *config_arg = NULL, *json_arg = NULL, *sqlite_arg = NULL, *backend_arg = NULL;
    int i = 1;
    if (argc == 1) {
        fprintf(stderr, "Error: No such device or address (os error 6)\n");
        return 1;
    }
    while (i < argc) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) {
            print_help_for(NULL, NULL);
            return 0;
        } else if (!strcmp(a, "-V") || !strcmp(a, "--version")) {
            puts("tui-journal 0.16.1");
            return 0;
        } else if (!strcmp(a, "-c") || !strcmp(a, "--config")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '--config <DIR PATH>'\n"); return 2; }
            config_arg = argv[i++];
        } else if (!strcmp(a, "-j") || !strcmp(a, "--json-file-path")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '--json-file-path <FILE PATH>'\n"); return 2; }
            json_arg = argv[i++];
        } else if (!strcmp(a, "-s") || !strcmp(a, "--sqlite-file-path")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '--sqlite-file-path <FILE PATH>'\n"); return 2; }
            sqlite_arg = argv[i++];
        } else if (!strcmp(a, "-b") || !strcmp(a, "--backend-type")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '--backend-type <BACKEND_TYPE>'\n"); return 2; }
            backend_arg = argv[i++];
            if (strcmp(backend_arg, "json") && strcmp(backend_arg, "sqlite")) {
                fprintf(stderr, "error: invalid value '%s' for '--backend-type <BACKEND_TYPE>'\n  [possible values: json, sqlite]\n\nFor more information, try '--help'.\n", backend_arg);
                return 2;
            }
        } else if (!strcmp(a, "-v") || !strcmp(a, "--verbose")) {
            i++;
        } else if (!strncmp(a, "-v", 2) && a[2] != '\0') {
            i++;
        } else if (!strcmp(a, "-l") || !strcmp(a, "--log")) {
            if (++i >= argc) { fprintf(stderr, "error: a value is required for '--log <FILE PATH>'\n"); return 2; }
            i++;
        } else if (is_cmd(a)) {
            break;
        } else {
            fprintf(stderr, "error: unexpected argument '%s' found\n\nFor more information, try '--help'.\n", a);
            return 2;
        }
    }

    Config cfg;
    if (load_config(&cfg, config_arg) != 0) return 1;
    if (json_arg) {
        snprintf(cfg.json_file_path, sizeof(cfg.json_file_path), "%s", json_arg);
        strcpy(cfg.backend_type, "Json");
    }
    if (sqlite_arg) {
        snprintf(cfg.sqlite_file_path, sizeof(cfg.sqlite_file_path), "%s", sqlite_arg);
        strcpy(cfg.backend_type, "Sqlite");
    }
    if (backend_arg) {
        strcpy(cfg.backend_type, !strcmp(backend_arg, "json") ? "Json" : "Sqlite");
    }

    if (i >= argc) {
        fprintf(stderr, "Error: No such device or address (os error 6)\n");
        return 1;
    }
    const char *cmd = argv[i++];
    if (!strcmp(cmd, "help")) {
        if (i >= argc) print_help_for(NULL, NULL);
        else if ((!strcmp(argv[i], "theme") || !strcmp(argv[i], "style")) && i + 1 < argc) print_help_for("theme", argv[i + 1]);
        else print_help_for(argv[i], NULL);
        return 0;
    }
    if (!strcmp(cmd, "print-config") || !strcmp(cmd, "pc")) {
        if (i < argc && (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))) { print_help_for("print-config", NULL); return 0; }
        if (i < argc) { fprintf(stderr, "error: unexpected argument '%s' found\n\nUsage: executable print-config\n\nFor more information, try '--help'.\n", argv[i]); return 2; }
        print_config(&cfg);
        return 0;
    }
    if (!strcmp(cmd, "theme") || !strcmp(cmd, "style")) {
        if (i >= argc || !strcmp(argv[i], "-h") || !strcmp(argv[i], "--help") || !strcmp(argv[i], "help")) {
            if (i + 1 < argc && !strcmp(argv[i], "help")) print_help_for("theme", argv[i + 1]);
            else print_help_for("theme", NULL);
            return 0;
        }
        const char *sub = argv[i++];
        char path[PATH_MAX];
        snprintf(path, sizeof(path), "%s/themes.toml", cfg.config_dir);
        if (!strcmp(sub, "print-path") || !strcmp(sub, "path")) {
            if (i < argc && (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))) { print_help_for("theme", "print-path"); return 0; }
            puts(path);
            return 0;
        }
        if (!strcmp(sub, "print-default") || !strcmp(sub, "default")) {
            if (i < argc && (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))) { print_help_for("theme", "print-default"); return 0; }
            fputs(THEME_DEFAULT, stdout);
            return 0;
        }
        if (!strcmp(sub, "write-defaults") || !strcmp(sub, "write")) {
            if (i < argc && (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))) { print_help_for("theme", "write-defaults"); return 0; }
            ensure_parent_dir(path);
            FILE *f = fopen(path, "wb");
            if (!f) { fprintf(stderr, "Error: %s (os error %d)\n", strerror(errno), errno); return 1; }
            fputs(THEME_DEFAULT, f);
            fclose(f);
            printf("Default themes have been written to %s\n", path);
            return 0;
        }
        fprintf(stderr, "error: unrecognized subcommand '%s'\n", sub);
        return 2;
    }
    if (!strcmp(cmd, "import-journals") || !strcmp(cmd, "imj")) {
        const char *path = NULL;
        if (i < argc && (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))) { print_help_for("import-journals", NULL); return 0; }
        while (i < argc) {
            if (!strcmp(argv[i], "-p") || !strcmp(argv[i], "--path")) {
                if (++i >= argc) { fprintf(stderr, "error: a value is required for '--path <FILE PATH>'\n"); return 2; }
                path = argv[i++];
            } else {
                fprintf(stderr, "error: unexpected argument '%s' found\n", argv[i]);
                return 2;
            }
        }
        if (!path) {
            fprintf(stderr, "error: the following required arguments were not provided:\n  --path <FILE PATH>\n\nUsage: executable import-journals --path <FILE PATH>\n\nFor more information, try '--help'.\n");
            return 2;
        }
        return !strcmp(cfg.backend_type, "Json") ? copy_file(path, cfg.json_file_path) : write_sqlite_placeholder(cfg.sqlite_file_path);
    }
    if (!strcmp(cmd, "assign-priority") || !strcmp(cmd, "ap")) {
        if (i < argc && (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help"))) { print_help_for("assign-priority", NULL); return 0; }
        if (i >= argc) {
            fprintf(stderr, "error: the following required arguments were not provided:\n  <PRIORITY>\n\nUsage: executable assign-priority <PRIORITY>\n\nFor more information, try '--help'.\n");
            return 2;
        }
        const char *priority = argv[i++];
        if (priority[0] == '-') {
            fprintf(stderr, "error: unexpected argument '%s' found\n\n  tip: to pass '%s' as a value, use '-- %s'\n\nUsage: executable assign-priority <PRIORITY>\n\nFor more information, try '--help'.\n", priority, priority, priority);
            return 2;
        }
        for (const char *p = priority; *p; p++) {
            if (!isdigit((unsigned char)*p)) {
                fprintf(stderr, "error: invalid value '%s' for '<PRIORITY>': invalid digit found in string\n\nFor more information, try '--help'.\n", priority);
                return 2;
            }
        }
        if (i < argc) { fprintf(stderr, "error: unexpected argument '%s' found\n", argv[i]); return 2; }
        return !strcmp(cfg.backend_type, "Json") ? json_assign_priority(cfg.json_file_path, priority) : write_sqlite_placeholder(cfg.sqlite_file_path);
    }
    return 2;
}
