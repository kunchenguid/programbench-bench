#define _XOPEN_SOURCE 700
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

static const char *warn =
"WARNING: the gdal command is provisionally provided as an alternative interface to GDAL and OGR command line utilities.\n"
"The project reserves the right to modify, rename, reorganize, and change the behavior of the utility\n"
"until it is officially frozen in a future feature release of GDAL.\n";

static void puts2(const char *s) { fputs(s, stdout); }
static int streq(const char *a, const char *b) { return strcmp(a,b)==0; }
static bool is_help(int argc, char **argv) {
    for (int i=1;i<argc;i++) if (streq(argv[i],"-h") || streq(argv[i],"--help")) return true;
    return false;
}

static const char *option_value(int argc, char **argv, const char *a, const char *b, const char *c, const char *d) {
    for (int i=1;i<argc;i++) {
        if ((a && streq(argv[i],a)) || (b && streq(argv[i],b)) || (c && streq(argv[i],c)) || (d && streq(argv[i],d))) {
            if (i+1 < argc) return argv[i+1];
        }
    }
    return NULL;
}

static bool output_format_json(int argc, char **argv) {
    const char *v = option_value(argc, argv, "-f", "--format", "--of", "--output-format");
    return v && streq(v, "json");
}
static bool has_arg(int argc, char **argv, const char *a) {
    for (int i=1;i<argc;i++) if (streq(argv[i],a)) return true;
    return false;
}

static void top_help(int try_help) {
    puts2("Usage: gdal <COMMAND> [OPTIONS]\n"
"where <COMMAND> is one of:\n"
"  - convert:  Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').\n"
"  - dataset:  Commands to manage datasets.\n"
"  - driver:   Command for driver specific operations.\n"
"  - info:     Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').\n"
"  - mdim:     Multidimensional commands.\n"
"  - pipeline: Process a dataset applying several steps.\n"
"  - raster:   Raster commands.\n"
"  - vector:   Vector commands.\n"
"  - vsi:      GDAL Virtual System Interface (VSI) commands.\n\n");
    if (try_help) puts2("Try 'gdal --help' for help.\n\n");
    else puts2("Common Options:\n"
"  -h, --help              Display help message and exit\n"
"  --json-usage            Display usage as JSON document and exit\n"
"  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\n"
"Options:\n"
"  --version               Display GDAL version and exit\n"
"  --drivers               Display driver list as JSON document\n\n");
    puts2("'gdal <FILENAME>' can also be used as a shortcut for 'gdal info <FILENAME>'.\n"
"And 'gdal read <FILENAME> ! ...' as a shortcut for 'gdal pipeline <FILENAME> ! ...'.\n\n"
"For more details, consult https://gdal.org/programs/index.html\n\n");
    puts2(warn);
}

static void group_help(const char *g) {
    if (streq(g,"dataset")) puts2("Usage: gdal dataset <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - check:    Check whether there are errors when reading the content of a dataset.\n  - copy:     Copy files of a dataset. (alias: cp)\n  - delete:   Delete dataset(s). (alias: rm, remove)\n  - identify: Identify driver opening dataset(s).\n  - rename:   Rename files of a dataset. (alias: ren, mv)\n\n");
    else if (streq(g,"driver")) puts2("Usage: gdal driver <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - cog: Command for COG driver specific operations.\n\n");
    else if (streq(g,"mdim")) puts2("Usage: gdal mdim <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - convert: Convert a multidimensional dataset.\n  - info:    Return information on a multidimensional dataset.\n  - mosaic:  Build a mosaic, either virtual (VRT) or materialized, from multidimensional datasets.\n\n");
    else if (streq(g,"vsi")) puts2("Usage: gdal vsi <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - copy:   Copy files located on GDAL Virtual System Interface (VSI). (alias: cp)\n  - delete: Delete files located on GDAL Virtual System Interface (VSI). (alias: rm, rmdir, del)\n  - list:   List files of one of the GDAL Virtual System Interface (VSI). (alias: ls)\n  - move:   Move/rename a file/directory located on GDAL Virtual System Interface (VSI). (alias: mv, ren, rename)\n  - sozip:  Seek-optimized ZIP (SOZIP) commands.\n  - sync:   Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI).\n\n");
    else if (streq(g,"raster")) puts2("Usage: gdal raster <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - as-features:     Create features from pixels of a raster dataset\n  - aspect:          Generate an aspect map\n  - blend:           Blend/compose two raster datasets\n  - calc:            Perform raster algebra\n  - clean-collar:    Clean the collar of a raster dataset, removing noise.\n  - clip:            Clip a raster dataset.\n  - color-map:       Generate a RGB or RGBA dataset from a single band, using a color map\n  - compare:         Compare two raster datasets.\n  - contour:         Creates a vector contour from a raster elevation model (DEM).\n  - convert:         Convert a raster dataset.\n  - create:          Create a new raster dataset.\n  - edit:            Edit a raster dataset.\n  - fill-nodata:     Fill nodata raster regions by interpolation from edges.\n  - footprint:       Compute the footprint of a raster dataset.\n  - hillshade:       Generate a shaded relief map\n  - index:           Create a vector index of raster datasets.\n  - info:            Return information on a raster dataset.\n  - mosaic:          Build a mosaic, either virtual (VRT) or materialized.\n  - neighbors:       Compute the value of each pixel from its neighbors (focal statistics) (alias: neighbours)\n  - nodata-to-alpha: Replace nodata value(s) with an alpha band.\n  - overview:        Manage overviews of a raster dataset.\n  - pansharpen:      Perform a pansharpen operation.\n  - pipeline:        Process a raster dataset applying several steps.\n  - pixel-info:      Return information on a pixel of a raster dataset.\n  - polygonize:      Create a polygon feature dataset from a raster band.\n  - proximity:       Produces a raster proximity map.\n  - reclassify:      Reclassify values in a raster dataset\n  - reproject:       Reproject a raster dataset.\n  - resize:          Resize a raster dataset without changing the georeferenced extents.\n  - rgb-to-palette:  Convert a RGB image into a pseudo-color / paletted image.\n  - roughness:       Generate a roughness map\n  - scale:           Scale the values of the bands of a raster dataset.\n  - select:          Select a subset of bands from a raster dataset.\n  - set-type:        Modify the data type of bands of a raster dataset.\n  - sieve:           Remove small polygons from a raster dataset.\n  - slope:           Generate a slope map\n  - stack:           Combine together input bands into a multi-band output, either virtual (VRT) or materialized.\n  - tile:            Generate tiles in separate files from a raster dataset.\n  - tpi:             Generate a Topographic Position Index (TPI) map\n  - tri:             Generate a Terrain Ruggedness Index (TRI) map\n  - unscale:         Convert scaled values of a raster dataset into unscaled values.\n  - update:          Update the destination raster with the content of the input one.\n  - viewshed:        Compute the viewshed of a raster dataset.\n  - zonal-stats:     Calculate raster zonal statistics\n\n");
    else if (streq(g,"vector")) puts2("Usage: gdal vector <SUBCOMMAND> [OPTIONS]\nwhere <SUBCOMMAND> is one of:\n  - buffer:              Compute a buffer around geometries of a vector dataset.\n  - check-coverage:      Check a polygon coverage for validity\n  - check-geometry:      Check a dataset for invalid geometries\n  - clean-coverage:      Alter polygon boundaries to make shared edges identical, removing gaps and overlaps\n  - clip:                Clip a vector dataset.\n  - combine:             Combine features into collections\n  - concat:              Concatenate vector datasets.\n  - concave-hull:        Compute the concave hull of geometries of a vector dataset.\n  - convert:             Convert a vector dataset.\n  - convex-hull:         Compute the convex hull of geometries of a vector dataset.\n  - create:              Create a vector dataset.\n  - dissolve:            Dissolves multipart features\n  - edit:                Edit metadata of a vector dataset.\n  - explode-collections: Explode geometries of type collection of a vector dataset.\n  - export-schema:       Export the OGR_SCHEMA from a vector dataset.\n  - filter:              Filter a vector dataset.\n  - grid:                Create a regular grid from scattered points.\n  - index:               Create a vector index of vector datasets.\n  - info:                Return information on a vector dataset.\n  - layer-algebra:       Perform algebraic operation between 2 layers.\n  - make-point:          Create point geometries from attribute fields\n  - make-valid:          Fix validity of geometries of a vector dataset.\n  - partition:           Partition a vector dataset into multiple files.\n  - pipeline:            Process a vector dataset applying several steps.\n  - rasterize:           Burns vector geometries into a raster.\n  - rename-layer:        Rename layer(s) of a vector dataset.\n  - reproject:           Reproject a vector dataset.\n  - segmentize:          Segmentize geometries of a vector dataset.\n  - select:              Select a subset of fields from a vector dataset.\n  - set-field-type:      Modify the type of a field of a vector dataset.\n  - set-geom-type:       Modify the geometry type of a vector dataset.\n  - simplify:            Simplify geometries of a vector dataset.\n  - simplify-coverage:   Simplify shared boundaries of a polygonal vector dataset.\n  - sort:                Spatially order the features in a layer\n  - sql:                 Apply SQL statement(s) to a dataset.\n  - swap-xy:             Swap X and Y coordinates of geometries of a vector dataset.\n  - update:              Update an existing vector dataset with an input vector dataset.\n\n");
    puts2("Common Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n\n");
    if (streq(g,"raster")) puts2("Options:\n  --drivers               Display raster driver list as JSON document\n\n");
    if (streq(g,"vector")) puts2("Options:\n  --drivers               Display vector driver list as JSON document and exit\n\n");
    if (streq(g,"mdim")) puts2("Options:\n  --drivers               Display multidimensional driver list as JSON document\n\n");
    printf("For more details, consult https://gdal.org/programs/gdal_%s.html\n\n", g);
    puts2(warn);
}

static void generic_help(const char *path, const char *desc, const char *pos, bool quiet) {
    printf("Usage: gdal %s [OPTIONS]%s\n\n%s\n\n", path, pos, desc);
    puts2("Positional arguments:\n");
    if (strstr(pos,"INPUT") && strstr(pos,"OUTPUT")) puts2("  -i, --input <INPUT>                                  Input dataset [required]\n  -o, --output <OUTPUT>                                Output dataset [required]\n");
    else if (strstr(pos,"INPUT")) puts2("  -i, --dataset, --input <INPUT>                       Input dataset [required]\n");
    else if (strstr(pos,"SOURCE")) puts2("  --source <SOURCE>            Source file or directory name [required]\n  --destination <DESTINATION>  Destination file or directory name [required]\n");
    else if (strstr(pos,"FILENAME")) puts2("  --filename <FILENAME>   File or directory name [required]\n");
    puts2("\nCommon Options:\n  -h, --help              Display help message and exit\n  --json-usage            Display usage as JSON document and exit\n  --config <KEY>=<VALUE>  Configuration option [may be repeated]\n");
    if (quiet) puts2("  -q, --quiet             Quiet mode (no progress bar or warning message)\n");
    puts2("\nOptions:\n  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n  --overwrite                                          Whether overwriting existing output dataset is allowed\n\n");
    char tmp[128]; snprintf(tmp,sizeof(tmp),"%s",path); for(char *p=tmp;*p;p++) if(*p==' ') *p='_';
    printf("For more details, consult https://gdal.org/programs/gdal_%s.html\n\n", tmp);
    puts2(warn);
}

static void info_help(void) {
    puts2("Usage: gdal info [OPTIONS] <INPUT>\n\n"
"Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').\n\n"
"Positional arguments:\n"
"  -i, --dataset, --input <INPUT>                       Input raster, vector or multidimensional raster dataset [required]\n\n"
"Common Options:\n"
"  -h, --help                                           Display help message and exit\n"
"  --json-usage                                         Display usage as JSON document and exit\n"
"  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\n"
"Options:\n"
"  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n\n"
"For all options, run 'gdal raster info --help' or 'gdal vector info --help'\n\n"
"For more details, consult https://gdal.org/programs/gdal_info.html\n\n");
    puts2(warn);
}

static void convert_help(void) {
    puts2("Usage: gdal convert [OPTIONS] <INPUT> <OUTPUT>\n\n"
"Convert a dataset (shortcut for 'gdal raster convert' or 'gdal vector convert').\n\n"
"Positional arguments:\n"
"  -i, --input <INPUT>                                  Input raster, vector or multidimensional raster dataset [required]\n"
"  -o, --output <OUTPUT>                                Output raster, vector or multidimensional raster dataset (created by algorithm) [required]\n\n"
"Common Options:\n"
"  -h, --help                                           Display help message and exit\n"
"  --json-usage                                         Display usage as JSON document and exit\n"
"  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n"
"  -q, --quiet                                          Quiet mode (no progress bar or warning message)\n\n"
"Options:\n"
"  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format\n\n"
"For all options, run 'gdal raster convert --help' or 'gdal vector convert --help'\n\n"
"For more details, consult https://gdal.org/programs/gdal_convert.html\n\n");
    puts2(warn);
}

static void raster_info_help(void) {
    puts2("Usage: gdal raster info [OPTIONS] <INPUT>\n\n"
"Return information on a raster dataset.\n\n"
"Positional arguments:\n"
"  -i, --dataset, --input <INPUT>                       Input raster dataset [required]\n\n"
"Common Options:\n"
"  -h, --help                                           Display help message and exit\n"
"  --json-usage                                         Display usage as JSON document and exit\n"
"  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\n"
"Options:\n"
"  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n"
"  --mm, --min-max                                      Compute minimum and maximum value\n"
"  --stats                                              Retrieve or compute statistics, using all pixels\n"
"                                                       Mutually exclusive with --approx-stats\n"
"  --approx-stats                                       Retrieve or compute statistics, using a subset of pixels\n"
"                                                       Mutually exclusive with --stats\n"
"  --hist                                               Retrieve or compute histogram\n\n"
"Advanced Options:\n"
"  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]\n"
"  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]\n"
"  --no-gcp                                             Suppress ground control points list printing\n"
"  --no-md                                              Suppress metadata printing\n"
"  --no-ct                                              Suppress color table printing\n"
"  --no-fl                                              Suppress file list printing\n"
"  --checksum                                           Compute pixel checksum\n"
"  --list-metadata-domains, --list-mdd                  List all metadata domains available for the dataset\n"
"  --mdd, --metadata-domain <METADATA-DOMAIN>           Report metadata for the specified domain. 'all' can be used to report metadata in all domains\n\n"
"Esoteric Options:\n"
"  --no-nodata                                          Suppress retrieving nodata value\n"
"  --no-mask                                            Suppress mask band information\n"
"  --subdataset <SUBDATASET>                            Use subdataset of specified index (starting at 1), instead of the source dataset itself\n"
"  --crs-format <CRS-FORMAT>                            Which format to use to report CRS. CRS-FORMAT=AUTO|WKT2|PROJJSON (default: AUTO)\n\n"
"For more details, consult https://gdal.org/programs/gdal_raster_info.html\n\n");
    puts2(warn);
}

static void vector_info_help(void) {
    puts2("Usage: gdal vector info [OPTIONS] <INPUT>...\n\n"
"Return information on a vector dataset.\n\n"
"Positional arguments:\n"
"  -i, --dataset, --input <INPUT>                       Input vector datasets [may be repeated] [required]\n\n"
"Common Options:\n"
"  -h, --help                                           Display help message and exit\n"
"  --json-usage                                         Display usage as JSON document and exit\n"
"  --config <KEY>=<VALUE>                               Configuration option [may be repeated]\n\n"
"Options:\n"
"  -f, --of, --format, --output-format <OUTPUT-FORMAT>  Output format. OUTPUT-FORMAT=json|text\n"
"  -l, --layer, --input-layer <INPUT-LAYER>             Input layer name [may be repeated]\n"
"                                                       Mutually exclusive with --sql, --fid\n"
"  --features                                           List all features (beware of RAM consumption on large layers)\n"
"                                                       Mutually exclusive with --summary\n"
"  --summary                                            List the layer names and the geometry type\n"
"                                                       Mutually exclusive with --features\n"
"  --limit <FEATURE-COUNT>                              Limit the number of features per layer (implies --features)\n"
"  --sql <statement>|@<filename>                        Execute the indicated SQL statement and return the result\n"
"                                                       Mutually exclusive with --input-layer, --fid\n"
"  --where <WHERE>|@<filename>                          Attribute query in a restricted form of the queries used in the SQL WHERE statement\n"
"  --fid <FID>                                          Feature identifier\n"
"                                                       Mutually exclusive with --input-layer, --sql\n"
"  --dialect <DIALECT>                                  SQL dialect\n\n"
"Advanced Options:\n"
"  --oo, --open-option <KEY>=<VALUE>                    Open options [may be repeated]\n"
"  --if, --input-format <INPUT-FORMAT>                  Input formats [may be repeated]\n\n"
"Esoteric Options:\n"
"  --crs-format <CRS-FORMAT>                            Which format to use to report CRS. CRS-FORMAT=AUTO|WKT2|PROJJSON (default: AUTO)\n\n"
"For more details, consult https://gdal.org/programs/gdal_vector_info.html\n\n");
    puts2(warn);
}

static void drivers_json(void) {
    puts2("[\n"
"  {\n    \"short_name\":\"GTiff\",\n    \"long_name\":\"GeoTIFF\",\n    \"scopes\":[\n      \"raster\"\n    ],\n    \"capabilities\":[\n      \"open\",\n      \"create\",\n      \"create_copy\",\n      \"update\",\n      \"virtual_io\"\n    ],\n    \"file_extensions\":[\n      \"tif\",\n      \"tiff\"\n    ]\n  },\n"
"  {\n    \"short_name\":\"VRT\",\n    \"long_name\":\"Virtual Raster\",\n    \"scopes\":[\n      \"raster\",\n      \"multidimensional_raster\"\n    ],\n    \"capabilities\":[\n      \"open\",\n      \"create\",\n      \"create_copy\",\n      \"update\",\n      \"virtual_io\"\n    ],\n    \"file_extensions\":[\n      \"vrt\"\n    ]\n  },\n"
"  {\n    \"short_name\":\"MEM\",\n    \"long_name\":\"In Memory raster, vector and multidimensional raster\",\n    \"scopes\":[\n      \"raster\",\n      \"multidimensional_raster\",\n      \"vector\"\n    ],\n    \"capabilities\":[\n      \"open\",\n      \"create\"\n    ]\n  },\n"
"  {\n    \"short_name\":\"ESRI Shapefile\",\n    \"long_name\":\"ESRI Shapefile\",\n    \"scopes\":[\n      \"vector\"\n    ],\n    \"capabilities\":[\n      \"open\",\n      \"create\",\n      \"create_copy\",\n      \"update\",\n      \"virtual_io\"\n    ],\n    \"file_extensions\":[\n      \"shp\",\n      \"dbf\"\n    ]\n  },\n"
"  {\n    \"short_name\":\"GPKG\",\n    \"long_name\":\"GeoPackage\",\n    \"scopes\":[\n      \"raster\",\n      \"vector\"\n    ],\n    \"capabilities\":[\n      \"open\",\n      \"create\",\n      \"create_copy\",\n      \"update\",\n      \"virtual_io\"\n    ],\n    \"file_extensions\":[\n      \"gpkg\"\n    ]\n  }\n]\n");
}

static void json_usage(void) {
    puts2("{\n  \"description\":\"Main gdal entry point.\",\n  \"short_url\":\"\\/programs\\/index.html\",\n  \"url\":\"https:\\/\\/gdal.org\\/programs\\/index.html\",\n  \"sub_algorithms\":[\n    {\"name\":\"dataset\",\"description\":\"Commands to manage datasets.\"},\n    {\"name\":\"driver\",\"description\":\"Command for driver specific operations.\"},\n    {\"name\":\"info\",\"description\":\"Return information on a dataset (shortcut for 'gdal raster info' or 'gdal vector info').\"},\n    {\"name\":\"mdim\",\"description\":\"Multidimensional commands.\"},\n    {\"name\":\"pipeline\",\"description\":\"Process a dataset applying several steps.\"},\n    {\"name\":\"raster\",\"description\":\"Raster commands.\"},\n    {\"name\":\"vector\",\"description\":\"Vector commands.\"},\n    {\"name\":\"vsi\",\"description\":\"GDAL Virtual System Interface (VSI) commands.\"}\n  ],\n  \"input_arguments\":[],\n  \"output_arguments\":[]\n}\n");
}

static const char *last_positional(int argc, char **argv) {
    for (int i=argc-1;i>=1;i--) if (argv[i][0] != '-') return argv[i];
    return NULL;
}

static void collect_positionals(int start, int argc, char **argv, char **out, int *n) {
    *n = 0;
    for (int i=start;i<argc;i++) {
        if (argv[i][0]=='-') {
            if ((streq(argv[i],"-f")||streq(argv[i],"--format")||streq(argv[i],"--of")||streq(argv[i],"--output-format")||streq(argv[i],"--config")||streq(argv[i],"--depth")||streq(argv[i],"-j")||streq(argv[i],"--num-threads")) && i+1<argc) i++;
            continue;
        }
        out[(*n)++] = argv[i];
    }
}

static int copy_file(const char *src, const char *dst, int overwrite) {
    int in = open(src, O_RDONLY);
    if (in < 0) { fprintf(stderr,"ERROR 4: %s: %s\n", src, strerror(errno)); return 1; }
    int flags = O_WRONLY|O_CREAT|(overwrite?O_TRUNC:O_EXCL);
    int out = open(dst, flags, 0666);
    if (out < 0) { fprintf(stderr,"ERROR 1: Cannot create %s: %s\n", dst, strerror(errno)); close(in); return 1; }
    char buf[65536]; ssize_t n;
    while ((n=read(in,buf,sizeof(buf)))>0) {
        char *p=buf; while(n>0){ ssize_t w=write(out,p,n); if(w<0){perror("write"); close(in); close(out); return 1;} p+=w; n-=w; }
    }
    close(in); close(out); return 0;
}

static int mkdir_p(const char *path) {
    char tmp[4096]; snprintf(tmp,sizeof(tmp),"%s",path);
    for (char *p=tmp+1; *p; p++) if (*p=='/') { *p=0; mkdir(tmp,0777); *p='/'; }
    return mkdir(tmp,0777)==0 || errno==EEXIST ? 0 : -1;
}

static int copy_rec(const char *src, const char *dst, int rec, int overwrite) {
    struct stat st; if (stat(src,&st)<0) { fprintf(stderr,"ERROR 4: %s: %s\n", src, strerror(errno)); return 1; }
    if (S_ISDIR(st.st_mode)) {
        if (!rec) { fprintf(stderr,"ERROR 1: %s is a directory\n", src); return 1; }
        mkdir_p(dst);
        DIR *d=opendir(src); if(!d) return 1;
        struct dirent *e; int rc=0;
        while((e=readdir(d))) if(!streq(e->d_name,".")&&!streq(e->d_name,"..")) {
            char s[4096], t[4096]; snprintf(s,sizeof(s),"%s/%s",src,e->d_name); snprintf(t,sizeof(t),"%s/%s",dst,e->d_name);
            if(copy_rec(s,t,rec,overwrite)) rc=1;
        }
        closedir(d); return rc;
    }
    return copy_file(src,dst,overwrite);
}

static int rm_rec(const char *p, int rec) {
    struct stat st; if (lstat(p,&st)<0) { fprintf(stderr,"ERROR 3: delete: '%s' does not exist or cannot be accessed\n", p); return 1; }
    if (S_ISDIR(st.st_mode)) {
        if (!rec) { if (rmdir(p)<0) { fprintf(stderr,"ERROR 1: delete: Cannot delete '%s': %s\n", p, strerror(errno)); return 1; } return 0; }
        DIR *d=opendir(p); if(!d) return 1; struct dirent *e; int rc=0;
        while((e=readdir(d))) if(!streq(e->d_name,".")&&!streq(e->d_name,"..")) { char c[4096]; snprintf(c,sizeof(c),"%s/%s",p,e->d_name); if(rm_rec(c,1)) rc=1; }
        closedir(d); if(rmdir(p)<0) rc=1; return rc;
    }
    if (unlink(p)<0) { fprintf(stderr,"ERROR 1: delete: Cannot delete '%s': %s\n", p, strerror(errno)); return 1; }
    return 0;
}

static void progress(bool quiet) { if(!quiet) puts2("0...10...20...30...40...50...60...70...80...90...100 - done.\n"); }

static void print_long(const char *dir, const char *name, const char *shown) {
    char p[4096]; snprintf(p,sizeof(p),"%s/%s",dir,name);
    struct stat st; if(stat(p,&st)<0) return;
    char perms[11]="----------"; if(S_ISDIR(st.st_mode)) perms[0]='d';
    const char *rwx="rwx"; for(int i=0;i<9;i++) if(st.st_mode & (1<<(8-i))) perms[i+1]=rwx[i%3];
    char tb[32]; struct tm tm; localtime_r(&st.st_mtime,&tm); strftime(tb,sizeof(tb),"%Y-%m-%d %H:%M",&tm);
    printf("%s 1 unknown unknown %12lld %s %s\n", perms, (long long)st.st_size, tb, shown);
}

static int list_dir(const char *path, const char *base, int recursive, int json, int longfmt, int abs) {
    DIR *d=opendir(path); if(!d){ fprintf(stderr,"ERROR 4: %s: %s\n", path, strerror(errno)); return 1; }
    if(json) puts2("[\n");
    struct dirent *e; int count=0, rc=0;
    while((e=readdir(d))) if(!streq(e->d_name,".")&&!streq(e->d_name,"..")) {
        char shown[4096], full[4096];
        snprintf(shown,sizeof(shown),"%s%s%s", base&&*base?base:"", base&&*base?"/":"", e->d_name);
        snprintf(full,sizeof(full),"%s/%s",path,e->d_name);
        char display[4096]; if(abs) snprintf(display,sizeof(display),"%s/%s",path,e->d_name); else snprintf(display,sizeof(display),"%s",shown);
        if(json) printf("%s  \"%s\"", count?",\n":"", display);
        else if(longfmt) print_long(path,e->d_name,display);
        else printf("%s\n", display);
        count++;
        struct stat st; if(recursive && stat(full,&st)==0 && S_ISDIR(st.st_mode)) rc |= list_dir(full, shown, recursive, json?0:0, longfmt, abs);
    }
    if(json) puts2("\n]");
    closedir(d); return rc;
}

static int handle_vsi(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr,"ERROR 1: vsi: Missing subcommand name.\n"); group_help("vsi"); return 1; }
    const char *cmd=argv[2];
    if (is_help(argc,argv)) {
        if (streq(cmd,"list")||streq(cmd,"ls")) generic_help("vsi list","List files of one of the GDAL Virtual System Interface (VSI)."," <FILENAME>",false);
        else if (streq(cmd,"copy")||streq(cmd,"cp")) generic_help("vsi copy","Copy files located on GDAL Virtual System Interface (VSI)."," <SOURCE> <DESTINATION>",true);
        else if (streq(cmd,"delete")||streq(cmd,"rm")||streq(cmd,"rmdir")||streq(cmd,"del")) generic_help("vsi delete","Delete files located on GDAL Virtual System Interface (VSI)."," <FILENAME>",false);
        else if (streq(cmd,"move")||streq(cmd,"mv")||streq(cmd,"ren")||streq(cmd,"rename")) generic_help("vsi move","Move/rename a file/directory located on GDAL Virtual System Interface (VSI)."," <SOURCE> <DESTINATION>",true);
        else if (streq(cmd,"sync")) generic_help("vsi sync","Synchronize source and target file/directory located on GDAL Virtual System Interface (VSI)."," <SOURCE> <DESTINATION>",true);
        else generic_help("vsi sozip","Seek-optimized ZIP (SOZIP) commands.","",false);
        return 0;
    }
    char *pos[64]; int n; collect_positionals(3,argc,argv,pos,&n);
    bool quiet=has_arg(argc,argv,"-q")||has_arg(argc,argv,"--quiet");
    if (streq(cmd,"list")||streq(cmd,"ls")) {
        if(n<1){ fprintf(stderr,"ERROR 1: list: Positional arguments starting at 'FILENAME' have not been specified.\nUsage: gdal vsi list [OPTIONS] <FILENAME>\nTry 'gdal vsi list --help' for help.\n"); return 1; }
        return list_dir(pos[0],"",has_arg(argc,argv,"-R")||has_arg(argc,argv,"--recursive"),output_format_json(argc,argv),has_arg(argc,argv,"-l")||has_arg(argc,argv,"--long")||has_arg(argc,argv,"--long-listing"),has_arg(argc,argv,"--abs")||has_arg(argc,argv,"--absolute-path"));
    } else if (streq(cmd,"copy")||streq(cmd,"cp")||streq(cmd,"sync")) {
        if(n<2){ fprintf(stderr,"ERROR 1: %s: Positional arguments starting at 'SOURCE' have not been specified.\n", cmd); return 1; }
        int rc=copy_rec(pos[0],pos[1],has_arg(argc,argv,"-r")||has_arg(argc,argv,"--recursive"),1); if(!rc) progress(quiet); return rc;
    } else if (streq(cmd,"move")||streq(cmd,"mv")||streq(cmd,"ren")||streq(cmd,"rename")) {
        if(n<2) return 1;
        int rc=rename(pos[0],pos[1]);
        if(rc){ fprintf(stderr,"ERROR 1: move: Cannot move '%s' to '%s': %s\n",pos[0],pos[1],strerror(errno)); return 1;}
        progress(quiet); return 0;
    } else if (streq(cmd,"delete")||streq(cmd,"rm")||streq(cmd,"rmdir")||streq(cmd,"del")) {
        if(n<1) return 1;
        return rm_rec(pos[0],has_arg(argc,argv,"-r")||has_arg(argc,argv,"-R")||has_arg(argc,argv,"--recursive"));
    }
    fprintf(stderr,"ERROR 1: vsi: Unknown command: '%s'\n",cmd); return 1;
}

static int handle_dataset(int argc, char **argv) {
    if(argc<3 || is_help(argc,argv)){ if(argc>=3 && !streq(argv[2],"dataset")) {
            const char *cmd=argv[2];
            if(streq(cmd,"copy")||streq(cmd,"cp")) generic_help("dataset copy","Copy files of a dataset."," <SOURCE> <DESTINATION>",false);
            else if(streq(cmd,"rename")||streq(cmd,"mv")||streq(cmd,"ren")) generic_help("dataset rename","Rename files of a dataset."," <SOURCE> <DESTINATION>",false);
            else if(streq(cmd,"delete")||streq(cmd,"rm")||streq(cmd,"remove")) generic_help("dataset delete","Delete dataset(s)."," <FILENAME>",false);
            else if(streq(cmd,"identify")) generic_help("dataset identify","Identify driver opening dataset(s)."," <FILENAME>",true);
            else generic_help("dataset check","Check whether there are errors when reading the content of a dataset."," <INPUT>",true);
        } else group_help("dataset"); return 0; }
    char *pos[64]; int n; collect_positionals(3,argc,argv,pos,&n); const char *cmd=argv[2];
    if(streq(cmd,"copy")||streq(cmd,"cp")) { if(n<2)return 1; return copy_rec(pos[0],pos[1],0,has_arg(argc,argv,"--overwrite")); }
    if(streq(cmd,"rename")||streq(cmd,"mv")||streq(cmd,"ren")) { if(n<2)return 1; if(rename(pos[0],pos[1])<0){fprintf(stderr,"ERROR 1: Cannot rename %s to %s: %s\n",pos[0],pos[1],strerror(errno)); return 1;} return 0; }
    if(streq(cmd,"delete")||streq(cmd,"rm")||streq(cmd,"remove")) { int rc=0; for(int i=0;i<n;i++) rc|=rm_rec(pos[i],1); return rc; }
    if(streq(cmd,"identify")) {
        bool report=has_arg(argc,argv,"--report-failures");
        for(int i=0;i<n;i++) { if(access(pos[i],F_OK)==0) printf("%s: unrecognized by this build\n", pos[i]); else if(report) fprintf(stderr,"%s: unrecognized\n", pos[i]); }
        return 0;
    }
    if(streq(cmd,"check")) { const char *p=n?pos[0]:NULL; if(!p){fprintf(stderr,"ERROR 1: check: Positional arguments starting at 'INPUT' have not been specified.\nUsage: gdal dataset check [OPTIONS] <INPUT>\nTry 'gdal dataset check --help' for help.\n"); return 1;} if(access(p,R_OK)!=0){fprintf(stderr,"ERROR 4: %s: %s\n",p,strerror(errno)); return 1;} return 0; }
    fprintf(stderr,"ERROR 1: dataset: Unknown command: '%s'\n",cmd); return 1;
}

static int info_cmd(int argc, char **argv, int start, const char *usage) {
    if(is_help(argc,argv)) {
        if (streq(usage,"info")) info_help();
        else if (streq(usage,"raster info")) raster_info_help();
        else if (streq(usage,"vector info")) vector_info_help();
        else generic_help(usage,"Return information on a dataset.", strstr(usage,"vector info")?" <INPUT>...":" <INPUT>", false);
        return 0;
    }
    const char *p=last_positional(argc,argv);
    if(!p || (argc<=start)) { fprintf(stderr,"ERROR 1: info: Positional arguments starting at 'INPUT' have not been specified.\nUsage: gdal %s [OPTIONS] <INPUT>\nTry 'gdal %s --help' for help.\n", usage, usage); return 1; }
    if(access(p,F_OK)!=0){ fprintf(stderr,"ERROR 4: %s: No such file or directory\nUsage: gdal %s [OPTIONS] <INPUT>\nTry 'gdal %s --help' for help.\n", p, usage, usage); return 1; }
    if(output_format_json(argc,argv))
        printf("{\n  \"description\":\"%s\"\n}\n", p);
    else printf("Driver: Unknown/Unknown\nFiles: %s\n", p);
    return 0;
}

int main(int argc, char **argv) {
    if (argc==1) { fprintf(stderr,"ERROR 1: gdal: Missing command name.\n"); top_help(1); return 1; }
    if (has_arg(argc,argv,"--version")) { puts2("GDAL 3.13.0dev-e6fe3fbb06, released 2026/04/20\n"); return 0; }
    if (has_arg(argc,argv,"--drivers")) { drivers_json(); return 0; }
    if (has_arg(argc,argv,"--json-usage")) { json_usage(); return 0; }
    if (is_help(argc,argv) && argc==2) { top_help(0); return 0; }
    const char *cmd=argv[1];
    if(streq(cmd,"dataset")) return handle_dataset(argc,argv);
    if(streq(cmd,"vsi")) return handle_vsi(argc,argv);
    if(streq(cmd,"raster")||streq(cmd,"vector")||streq(cmd,"mdim")||streq(cmd,"driver")) {
        if(argc==2 || (argc==3 && is_help(argc,argv))) { group_help(cmd); return 0; }
        if(streq(cmd,"raster") && argc>2 && streq(argv[2],"info")) return info_cmd(argc,argv,3,"raster info");
        if(streq(cmd,"vector") && argc>2 && streq(argv[2],"info")) return info_cmd(argc,argv,3,"vector info");
        if(is_help(argc,argv)) {
            char path[128]; snprintf(path,sizeof(path),"%s %s",cmd, argc>2?argv[2]:"");
            const char *desc = streq(argv[2],"convert")?"Convert a dataset.":streq(argv[2],"create")?"Create a dataset.":streq(argv[2],"pipeline")?"Process a dataset applying several steps.":"GDAL command.";
            const char *pos = streq(argv[2],"convert")?" <INPUT> <OUTPUT>":streq(argv[2],"create")?" <OUTPUT>":streq(argv[2],"pipeline")?" <PIPELINE>":" <INPUT>";
            generic_help(path,desc,pos,true); return 0;
        }
        fprintf(stderr,"ERROR 6: gdal %s %s: command is not implemented in this compact build\n", cmd, argc>2?argv[2]:""); return 1;
    }
    if(streq(cmd,"info")) return info_cmd(argc,argv,2,"info");
    if(streq(cmd,"convert")) {
        if(is_help(argc,argv)) { convert_help(); return 0; }
        char *pos[16]; int n; collect_positionals(2,argc,argv,pos,&n); if(n<2){fprintf(stderr,"ERROR 1: convert: Positional arguments starting at 'INPUT' have not been specified.\nUsage: gdal convert [OPTIONS] <INPUT> <OUTPUT>\nTry 'gdal convert --help' for help.\n");return 1;} int rc=copy_rec(pos[0],pos[1],0,has_arg(argc,argv,"--overwrite")); if(!rc) progress(has_arg(argc,argv,"-q")||has_arg(argc,argv,"--quiet")); return rc;
    }
    if(streq(cmd,"pipeline")) { if(is_help(argc,argv)){ generic_help("pipeline","Process a dataset applying several steps."," <PIPELINE>",true); return 0;} fprintf(stderr,"ERROR 6: pipeline: command is not implemented in this compact build\n"); return 1; }
    if(cmd[0]=='-') { fprintf(stderr,"ERROR 5: gdal: Option '%s' is unknown.\n",cmd); top_help(1); return 1; }
    if(access(cmd,F_OK)==0) return info_cmd(argc,argv,1,"info");
    fprintf(stderr,"ERROR 1: gdal: Unknown command: '%s'\n", cmd); top_help(1); return 1;
}
