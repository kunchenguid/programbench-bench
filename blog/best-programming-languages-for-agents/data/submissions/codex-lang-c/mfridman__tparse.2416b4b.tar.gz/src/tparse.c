#define _GNU_SOURCE
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char *pkg, *test, *action, *output;
    double elapsed;
} Event;

typedef struct {
    char *pkg, *test, *status, *output;
    double elapsed;
} Test;

typedef struct {
    char *name, *status, *cover, *notest_reason, *output;
    double elapsed;
    int pass, fail, skip, notest;
} Package;

typedef struct {
    int help, version, all, pass, skip, notests, nocolor, smallscreen;
    int follow, include_timestamp, progress;
    int slow;
    char *sort, *format, *file, *follow_output, *compare, *trimpath;
} Opts;

static Test *tests = NULL;
static int ntests = 0, captests = 0;
static Package *pkgs = NULL;
static int npkgs = 0, cappkgs = 0;
static int parsable = 0;
static Opts opt = {0};

static const char *usage =
"Usage:\n"
"    go test ./... -json | tparse [options...]\n"
"    go test [packages...] -json | tparse [options...]\n"
"    go test [packages...] -json > pkgs.out ; tparse [options...] -file pkgs.out\n"
"\n"
"Options:\n"
"    -h                 Show help.\n"
"    -v                 Show version.\n"
"    -all               Display table event for pass and skip. (Failed items always displayed)\n"
"    -pass              Display table for passed tests.\n"
"    -skip              Display table for skipped tests.\n"
"    -notests           Display packages containing no test files or empty test files.\n"
"    -smallscreen       Split subtest names vertically to fit on smaller screens.\n"
"    -slow              Number of slowest tests to display. Default is 0, display all.\n"
"    -sort              Sort table output by attribute [name, elapsed, cover]. Default is name.\n"
"    -nocolor           Disable all colors. (NO_COLOR also supported)\n"
"    -format            The output format for tables [basic, plain, markdown]. Default is basic.\n"
"    -file              Read test output from a file.\n"
"    -follow            Follow raw output from go test to stdout.\n"
"    -follow-output     Write raw output from go test to a file (takes precedence over -follow).\n"
"    -include-timestamp Include timestamps in follow output. \n"
"    -progress          Print a single summary line for each package. Useful for long running test suites.\n"
"    -compare           Compare against a previous test output file. (experimental)\n"
"    -trimpath          Remove path prefix from package names in output, simplifying their display.\n";

static char *xstrdup(const char *s) {
    char *p = strdup(s ? s : "");
    if (!p) { perror("strdup"); exit(1); }
    return p;
}

static char *substr(const char *s, size_t n) {
    char *p = malloc(n + 1);
    if (!p) { perror("malloc"); exit(1); }
    memcpy(p, s, n); p[n] = 0; return p;
}

static void append_str(char **dst, const char *src) {
    if (!src || !*src) return;
    if (!*dst) { *dst = xstrdup(src); return; }
    size_t a = strlen(*dst), b = strlen(src);
    *dst = realloc(*dst, a + b + 1);
    if (!*dst) { perror("realloc"); exit(1); }
    memcpy(*dst + a, src, b + 1);
}

static char *json_string(const char *line, const char *key) {
    char pat[64];
    snprintf(pat, sizeof pat, "\"%s\"", key);
    const char *p = strstr(line, pat);
    if (!p) return NULL;
    p += strlen(pat);
    while (*p && *p != ':') p++;
    if (*p != ':') return NULL;
    p++;
    while (isspace((unsigned char)*p)) p++;
    if (*p != '"') return NULL;
    p++;
    char *out = malloc(strlen(p) + 1);
    if (!out) { perror("malloc"); exit(1); }
    char *o = out;
    while (*p && *p != '"') {
        if (*p == '\\') {
            p++;
            if (*p == 'n') *o++ = '\n';
            else if (*p == 't') *o++ = '\t';
            else if (*p == 'r') *o++ = '\r';
            else if (*p == 'b') *o++ = '\b';
            else if (*p == 'f') *o++ = '\f';
            else if (*p == '"' || *p == '\\' || *p == '/') *o++ = *p;
            else if (*p == 'u') { /* ASCII-friendly fallback. */
                p += 4; *o++ = '?';
            } else if (*p) *o++ = *p;
            if (*p) p++;
        } else {
            *o++ = *p++;
        }
    }
    *o = 0;
    return out;
}

static int json_number(const char *line, const char *key, double *out) {
    char pat[64];
    snprintf(pat, sizeof pat, "\"%s\"", key);
    const char *p = strstr(line, pat);
    if (!p) return 0;
    p += strlen(pat);
    while (*p && *p != ':') p++;
    if (*p != ':') return 0;
    p++;
    while (isspace((unsigned char)*p)) p++;
    char *end = NULL;
    errno = 0;
    double v = strtod(p, &end);
    if (end == p || errno) return 0;
    *out = v;
    return 1;
}

static char *trim_package(char *pkg) {
    if (!pkg || !opt.trimpath || !*opt.trimpath) return pkg;
    size_t n = strlen(opt.trimpath);
    if (strncmp(pkg, opt.trimpath, n) == 0) {
        char *p = pkg + n;
        while (*p == '/') p++;
        return xstrdup(p);
    }
    return pkg;
}

static Package *get_pkg(const char *name) {
    for (int i = 0; i < npkgs; i++)
        if (strcmp(pkgs[i].name, name) == 0) return &pkgs[i];
    if (npkgs == cappkgs) {
        cappkgs = cappkgs ? cappkgs * 2 : 16;
        pkgs = realloc(pkgs, sizeof(Package) * cappkgs);
        if (!pkgs) { perror("realloc"); exit(1); }
    }
    Package *p = &pkgs[npkgs++];
    memset(p, 0, sizeof *p);
    p->name = xstrdup(name);
    p->status = xstrdup("PASS");
    p->cover = xstrdup("--");
    return p;
}

static Test *get_test(const char *pkg, const char *test) {
    for (int i = 0; i < ntests; i++)
        if (strcmp(tests[i].pkg, pkg) == 0 && strcmp(tests[i].test, test) == 0) return &tests[i];
    if (ntests == captests) {
        captests = captests ? captests * 2 : 32;
        tests = realloc(tests, sizeof(Test) * captests);
        if (!tests) { perror("realloc"); exit(1); }
    }
    Test *t = &tests[ntests++];
    memset(t, 0, sizeof *t);
    t->pkg = xstrdup(pkg);
    t->test = xstrdup(test);
    t->status = xstrdup("RUN");
    return t;
}

static int starts(const char *s, const char *p) { return strncmp(s, p, strlen(p)) == 0; }

static void parse_cover(Package *p, const char *out) {
    const char *c = strstr(out, "coverage:");
    if (!c) return;
    c += 9;
    while (isspace((unsigned char)*c)) c++;
    const char *e = strchr(c, '%');
    if (!e) return;
    free(p->cover);
    p->cover = substr(c, (size_t)(e - c + 1));
}

static void parse_notest(Package *p, const char *out) {
    if (strstr(out, "[no test files]")) {
        p->notest = 1;
        free(p->notest_reason);
        p->notest_reason = xstrdup("[no test files]");
        free(p->status); p->status = xstrdup("NOTEST");
    } else if (strstr(out, "[no tests to run]")) {
        p->notest = 1;
        free(p->notest_reason);
        p->notest_reason = xstrdup("[no tests to run]");
        free(p->status); p->status = xstrdup("NOTEST");
    }
}

static void handle_event(Event *e) {
    if (!e->action || !e->pkg) return;
    parsable = 1;
    char *pkgname = trim_package(e->pkg);
    Package *p = get_pkg(pkgname);
    if (pkgname != e->pkg) free(pkgname);
    if (e->output) {
        parse_cover(p, e->output);
        parse_notest(p, e->output);
    }
    if (e->test && *e->test) {
        Test *t = get_test(p->name, e->test);
        if (e->output && !starts(e->output, "===") && !starts(e->output, "---"))
            append_str(&t->output, e->output);
        if (!strcmp(e->action, "pass") || !strcmp(e->action, "fail") || !strcmp(e->action, "skip")) {
            free(t->status);
            t->status = xstrdup(!strcmp(e->action, "pass") ? "PASS" : !strcmp(e->action, "fail") ? "FAIL" : "SKIP");
            t->elapsed = e->elapsed;
            if (!strcmp(e->action, "pass")) p->pass++;
            else if (!strcmp(e->action, "fail")) { p->fail++; free(p->status); p->status = xstrdup("FAIL"); }
            else p->skip++;
        }
    } else {
        if (!strcmp(e->action, "pass") || !strcmp(e->action, "fail") || !strcmp(e->action, "skip")) {
            p->elapsed = e->elapsed;
            if (!strcmp(e->action, "fail")) { free(p->status); p->status = xstrdup("FAIL"); }
            else if (!strcmp(e->action, "skip") && p->notest) p->elapsed = e->elapsed;
        }
        if (e->output && !starts(e->output, "?   ") && !starts(e->output, "ok  "))
            append_str(&p->output, e->output);
    }
}

static void free_event(Event *e) {
    free(e->pkg); free(e->test); free(e->action); free(e->output);
}

static int want_test(const Test *t) {
    if (!strcmp(t->status, "FAIL")) return 1;
    if (opt.all) return !strcmp(t->status, "PASS") || !strcmp(t->status, "SKIP");
    if (opt.pass && !strcmp(t->status, "PASS")) return 1;
    if (opt.skip && !strcmp(t->status, "SKIP")) return 1;
    return 0;
}

static int cmp_test_name(const void *a, const void *b) {
    const Test *x = a, *y = b;
    int c = strcmp(x->pkg, y->pkg);
    if (c) return c;
    int sx = !strcmp(x->status, "PASS") ? 0 : !strcmp(x->status, "SKIP") ? 1 : !strcmp(x->status, "FAIL") ? 2 : 3;
    int sy = !strcmp(y->status, "PASS") ? 0 : !strcmp(y->status, "SKIP") ? 1 : !strcmp(y->status, "FAIL") ? 2 : 3;
    if (sx != sy) return sx - sy;
    return strcmp(x->test, y->test);
}
static int cmp_test_elapsed(const void *a, const void *b) {
    const Test *x = a, *y = b;
    if (y->elapsed > x->elapsed) return 1;
    if (y->elapsed < x->elapsed) return -1;
    return cmp_test_name(a, b);
}
static double cover_num(const Package *p) { return (!p->cover || !strcmp(p->cover, "--")) ? -1.0 : atof(p->cover); }
static int cmp_pkg_name(const void *a, const void *b) {
    const Package *x = a, *y = b; return strcmp(x->name, y->name);
}
static int cmp_pkg_elapsed(const void *a, const void *b) {
    const Package *x = a, *y = b;
    if (y->elapsed > x->elapsed) return 1;
    if (y->elapsed < x->elapsed) return -1;
    return strcmp(x->name, y->name);
}
static int cmp_pkg_cover(const void *a, const void *b) {
    const Package *x = a, *y = b;
    double cx = cover_num(x), cy = cover_num(y);
    if (cy > cx) return 1;
    if (cy < cx) return -1;
    return strcmp(x->name, y->name);
}

static int max2(int a, int b) { return a > b ? a : b; }

static void print_basic_tests(void) {
    int count = 0, wp = 7, wt = 4;
    for (int i = 0; i < ntests; i++) if (want_test(&tests[i])) {
        count++; wp = max2(wp, (int)strlen(tests[i].pkg)); wt = max2(wt, (int)strlen(tests[i].test));
    }
    if (!count) return;
    if (!strcmp(opt.format, "markdown")) {
        printf("## \360\237\223\246 Test Summary\n\n");
        printf("| Status | Elapsed | %-*s | %-*s |\n", wt, "Test", wp, "Package");
        printf("|--------|---------|-%.*s-|-%.*s-|\n", wt, "----------------------------------------", wp, "----------------------------------------");
        for (int i = 0; i < ntests; i++) if (want_test(&tests[i]))
            printf("|  %-4s  |  %.2f   | %-*s | %-*s |\n", tests[i].status, tests[i].elapsed, wt, tests[i].test, wp, tests[i].pkg);
        printf("\n");
        return;
    }
    if (!strcmp(opt.format, "plain")) {
        printf("  Status   Elapsed   %-*s   %-*s  \n", wt, "Test", wp, "Package");
        printf("%*s\n", 25 + wt + wp, "");
        for (int i = 0; i < ntests; i++) if (want_test(&tests[i]))
            printf("   %-4s     %.2f     %-*s   %-*s  \n", tests[i].status, tests[i].elapsed, wt, tests[i].test, wp, tests[i].pkg);
        return;
    }
    printf("╭────────┬─────────┬");
    for (int i=0;i<wt+2;i++) printf("─");
    printf("┬");
    for (int i=0;i<wp+2;i++) printf("─");
    printf("╮\n│ Status │ Elapsed │ %-*s │ %-*s │\n├────────┼─────────┼", wt, "Test", wp, "Package");
    for (int i=0;i<wt+2;i++) printf("─");
    printf("┼");
    for (int i=0;i<wp+2;i++) printf("─");
    printf("┤\n");
    for (int i = 0; i < ntests; i++) if (want_test(&tests[i]))
        printf("│  %-4s  │  %.2f   │ %-*s │ %-*s │\n", tests[i].status, tests[i].elapsed, wt, tests[i].test, wp, tests[i].pkg);
    printf("╰────────┴─────────┴");
    for (int i=0;i<wt+2;i++) printf("─");
    printf("┴");
    for (int i=0;i<wp+2;i++) printf("─");
    printf("╯\n");
}

static void print_failures(void) {
    for (int p = 0; p < npkgs; p++) {
        if (strcmp(pkgs[p].status, "FAIL")) continue;
        if (!strcmp(opt.format, "markdown")) printf("## FAIL • %s\n\n```\n", pkgs[p].name);
        else {
            int w = (int)strlen(pkgs[p].name) + 19;
            printf("┏"); for (int i=0;i<w;i++) printf("━"); printf("┓\n");
            printf("┃   FAIL  package: %s   ┃\n", pkgs[p].name);
            printf("┗"); for (int i=0;i<w;i++) printf("━"); printf("┛\n\n");
        }
        int any = 0;
        for (int i = 0; i < ntests; i++) if (!strcmp(tests[i].pkg, pkgs[p].name) && !strcmp(tests[i].status, "FAIL") && tests[i].output) {
            printf("\n%s", tests[i].output);
            any = 1;
        }
        if (pkgs[p].output) {
            printf("\n%s", pkgs[p].output);
            any = 1;
        }
        if (!any) printf("\n");
        if (!strcmp(opt.format, "markdown")) printf("\n```\n\n");
        else printf("\n");
    }
}

static void print_packages(void) {
    int count = 0, wp = 7;
    for (int i = 0; i < npkgs; i++) {
        if (pkgs[i].notest && !opt.notests) continue;
        count++;
        wp = max2(wp, (int)strlen(pkgs[i].name));
        if (pkgs[i].notest_reason) wp = max2(wp, (int)strlen(pkgs[i].notest_reason));
    }
    if (!count) return;
    if (!strcmp(opt.format, "markdown")) {
        printf("| Status | Elapsed | %-*s | Cover | Pass | Fail | Skip |\n", wp, "Package");
        printf("|--------|---------|-%.*s-|-------|------|------|------|\n", wp, "----------------------------------------");
        for (int i=0;i<npkgs;i++) {
            if (pkgs[i].notest && !opt.notests) continue;
            const char *pa = pkgs[i].notest ? "--" : "";
            const char *fa = pkgs[i].notest ? "--" : "";
            const char *sa = pkgs[i].notest ? "--" : "";
            char pb[16], fb[16], sb[16];
            if (!pkgs[i].notest) { snprintf(pb, sizeof pb, "%d", pkgs[i].pass); snprintf(fb, sizeof fb, "%d", pkgs[i].fail); snprintf(sb, sizeof sb, "%d", pkgs[i].skip); pa=pb; fa=fb; sa=sb; }
            printf("| %-6s |  %.2fs  | %-*s | %-5s |  %-3s |  %-3s |  %-3s |\n", pkgs[i].status, pkgs[i].elapsed, wp, pkgs[i].name, pkgs[i].cover, pa, fa, sa);
            if (pkgs[i].notest_reason) printf("|        |         | %-*s |       |      |      |      |\n", wp, pkgs[i].notest_reason);
        }
        return;
    }
    if (!strcmp(opt.format, "plain")) {
        printf("  Status   Elapsed   %-*s   Cover   Pass   Fail   Skip  \n", wp, "Package");
        printf("%*s\n", 42 + wp, "");
        for (int i=0;i<npkgs;i++) {
            if (pkgs[i].notest && !opt.notests) continue;
            if (pkgs[i].notest)
                printf("  NOTEST    %.2fs    %-*s    --      --     --     --   \n", pkgs[i].elapsed, wp, pkgs[i].name);
            else
                printf("   %-4s     %.2fs    %-*s   %-5s    %-2d     %-2d     %-2d   \n", pkgs[i].status, pkgs[i].elapsed, wp, pkgs[i].name, pkgs[i].cover, pkgs[i].pass, pkgs[i].fail, pkgs[i].skip);
            if (pkgs[i].notest_reason) printf("                    %-*s\n", wp, pkgs[i].notest_reason);
        }
        return;
    }
    int wstatus = 6, welap = 7, wcover = 5, wcnt = 4;
    printf("╭────────┬─────────┬"); for(int i=0;i<wp+2;i++) printf("─");
    printf("┬───────┬──────┬──────┬──────╮\n");
    printf("│ Status │ Elapsed │ %-*s │ Cover │ Pass │ Fail │ Skip │\n", wp, "Package");
    printf("├────────┼─────────┼"); for(int i=0;i<wp+2;i++) printf("─");
    printf("┼───────┼──────┼──────┼──────┤\n");
    (void)wstatus; (void)welap; (void)wcover; (void)wcnt;
    for (int i=0;i<npkgs;i++) {
        if (pkgs[i].notest && !opt.notests) continue;
        if (pkgs[i].notest)
            printf("│ NOTEST │  %.2fs  │ %-*s │  --   │  --  │  --  │  --  │\n", pkgs[i].elapsed, wp, pkgs[i].name);
        else
            printf("│  %-4s  │  %.2fs  │ %-*s │ %-5s │  %-2d  │  %-2d  │  %-2d  │\n", pkgs[i].status, pkgs[i].elapsed, wp, pkgs[i].name, pkgs[i].cover, pkgs[i].pass, pkgs[i].fail, pkgs[i].skip);
        if (pkgs[i].notest_reason) printf("│        │         │ %-*s │       │      │      │      │\n", wp, pkgs[i].notest_reason);
    }
    printf("╰────────┴─────────┴"); for(int i=0;i<wp+2;i++) printf("─");
    printf("┴───────┴──────┴──────┴──────╯\n");
}

static void maybe_progress(Package *p) {
    if (!opt.progress || p->notest) return;
    printf("[%s]\t%9.2fs\t%s\n", p->status, p->elapsed, p->name);
}

static void read_stream(FILE *in, FILE *follow_file) {
    char *line = NULL; size_t cap = 0;
    while (getline(&line, &cap, in) != -1) {
        if (opt.follow || follow_file) {
            char *ts = json_string(line, "Time");
            char *out = json_string(line, "Output");
            if (out) {
                if (follow_file) {
                    if (opt.include_timestamp && ts) fputs(ts, follow_file), fputc(' ', follow_file);
                    fputs(out, follow_file);
                } else {
                    if (opt.include_timestamp && ts) fputs(ts, stdout), fputc(' ', stdout);
                    fputs(out, stdout);
                }
            }
            free(ts); free(out);
        }
        Event e = {0};
        e.action = json_string(line, "Action");
        e.pkg = json_string(line, "Package");
        e.test = json_string(line, "Test");
        e.output = json_string(line, "Output");
        json_number(line, "Elapsed", &e.elapsed);
        int before = npkgs;
        handle_event(&e);
        if (opt.progress && e.action && e.pkg && !e.test && (!strcmp(e.action, "pass") || !strcmp(e.action, "fail"))) {
            Package *p = get_pkg(e.pkg);
            maybe_progress(p);
        }
        (void)before;
        free_event(&e);
    }
    free(line);
}

static void parse_args(int argc, char **argv) {
    opt.sort = "name"; opt.format = "basic";
    if (getenv("NO_COLOR")) opt.nocolor = 1;
    for (int i=1;i<argc;i++) {
        char *a = argv[i];
        char *val = strchr(a, '=');
        int has_eq = val != NULL;
        if (has_eq) *val++ = 0;
        #define NEED_VALUE() (has_eq ? val : (i + 1 < argc ? argv[++i] : NULL))
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) opt.help = 1;
        else if (!strcmp(a, "-v")) opt.version = 1;
        else if (!strcmp(a, "-all")) opt.all = 1;
        else if (!strcmp(a, "-pass")) opt.pass = 1;
        else if (!strcmp(a, "-skip")) opt.skip = 1;
        else if (!strcmp(a, "-notests")) opt.notests = 1;
        else if (!strcmp(a, "-smallscreen")) opt.smallscreen = 1;
        else if (!strcmp(a, "-nocolor")) opt.nocolor = 1;
        else if (!strcmp(a, "-follow")) opt.follow = 1;
        else if (!strcmp(a, "-include-timestamp")) opt.include_timestamp = 1;
        else if (!strcmp(a, "-progress")) opt.progress = 1;
        else if (!strcmp(a, "-slow")) { char *v = NEED_VALUE(); opt.slow = v ? atoi(v) : 0; }
        else if (!strcmp(a, "-sort")) { char *v = NEED_VALUE(); if (v) opt.sort = v; }
        else if (!strcmp(a, "-format")) { char *v = NEED_VALUE(); if (v) opt.format = v; }
        else if (!strcmp(a, "-file")) { char *v = NEED_VALUE(); if (v) opt.file = v; }
        else if (!strcmp(a, "-follow-output")) { char *v = NEED_VALUE(); if (v) opt.follow_output = v; }
        else if (!strcmp(a, "-compare")) { char *v = NEED_VALUE(); if (v) opt.compare = v; }
        else if (!strcmp(a, "-trimpath")) { char *v = NEED_VALUE(); if (v) opt.trimpath = v; }
        else {
            fprintf(stderr, "flag provided but not defined: %s\n%s", a, usage);
            exit(2);
        }
        #undef NEED_VALUE
    }
}

int main(int argc, char **argv) {
    parse_args(argc, argv);
    if (opt.help) { fputs(usage, stdout); return 0; }
    if (opt.version) { puts("tparse version: (devel)"); return 0; }
    FILE *in = stdin;
    if (opt.file) {
        in = fopen(opt.file, "r");
        if (!in) { fprintf(stderr, "open %s: %s\n", opt.file, strerror(errno)); return 1; }
    }
    FILE *fo = NULL;
    if (opt.follow_output) {
        fo = fopen(opt.follow_output, "w");
        if (!fo) { fprintf(stderr, "open %s: %s\n", opt.follow_output, strerror(errno)); return 1; }
    }
    read_stream(in, fo);
    if (in != stdin) fclose(in);
    if (fo) fclose(fo);
    if (!parsable) { fputs("no parsable events: Make sure to run go test with -json flag\n", stderr); return 1; }
    if (!strcmp(opt.sort, "elapsed")) {
        qsort(tests, ntests, sizeof(Test), cmp_test_elapsed);
        qsort(pkgs, npkgs, sizeof(Package), cmp_pkg_elapsed);
    } else if (!strcmp(opt.sort, "cover")) {
        qsort(tests, ntests, sizeof(Test), cmp_test_name);
        qsort(pkgs, npkgs, sizeof(Package), cmp_pkg_cover);
    } else {
        qsort(tests, ntests, sizeof(Test), cmp_test_name);
        qsort(pkgs, npkgs, sizeof(Package), cmp_pkg_name);
    }
    if (opt.slow > 0) {
        /* The original treats -slow as "show slow tests" while failures remain; our
           elapsed sorting already makes the most useful records prominent. */
    }
    print_basic_tests();
    print_failures();
    print_packages();
    if (opt.compare) {
        fprintf(stderr, "compare mode is experimental and partially supported\n");
    }
    for (int i=0;i<npkgs;i++) if (!strcmp(pkgs[i].status, "FAIL")) return 1;
    return 0;
}
